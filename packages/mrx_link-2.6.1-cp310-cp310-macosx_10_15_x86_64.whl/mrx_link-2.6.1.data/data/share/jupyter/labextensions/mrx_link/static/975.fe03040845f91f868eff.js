"use strict";(self.webpackChunkmrx_link=self.webpackChunkmrx_link||[]).push([[975],{41770:(e,t,n)=>{n.r(t),n.d(t,{default:()=>vs});var a=n(93345),r=n.n(a),l=n(5338),o=n(26376),i=n(50608),s=n(54367),c=n(46055),d=n.n(c),p=(n(7200),n(95005)),m=n.n(p);const u=class{constructor(){m().options={closeButton:!1,debug:!1,newestOnTop:!1,progressBar:!1,positionClass:"toast-top-right",preventDuplicates:!1,hideDuration:300,showEasing:"swing",hideEasing:"linear",showMethod:"slideDown",hideMethod:"fadeOut",timeOut:3e3,toastClass:"link-toast",iconClasses:{error:"link-toast-error",info:"link-toast-info",success:"link-toast-info",warning:"link-toast-error"},messageClass:"link-toast-message"}}info(e,t,n){m().info(e,t,n)}warning(e,t,n){m().warning(e,t,n)}success(e,t,n){m().success(e,t,n)}error(e,t,n){m().error(e,t,n)}static getInstance(){return this.instance||(this.instance=new this)}}.getInstance(),h=d().create({baseURL:o.PageConfig.getBaseUrl()});async function g(e="",t={}){const n=i.ServerConnection.makeSettings(),a=o.URLExt.join(n.baseUrl,e);let r;try{r=await i.ServerConnection.makeRequest(a,t,n)}catch(e){throw new i.ServerConnection.NetworkError(e)}let l=await r.text();if(l.length>0)try{l=JSON.parse(l)}catch(e){console.error("Not a JSON response body.",r)}if(!r.ok)throw new i.ServerConnection.ResponseError(r,l.message||l);return l}async function v(){const e=i.ServerConnection.makeSettings(),t=o.URLExt.join(e.baseUrl+"mrx-link/info/extension");let n;try{n=await i.ServerConnection.makeRequest(t,{method:"GET"},e)}catch(e){throw new i.ServerConnection.NetworkError(e)}const a=await n.json();if(!n.ok)throw new i.ServerConnection.ResponseError(n,a.message||n.text());return a}async function f(e){const t=i.ServerConnection.makeSettings(),n=o.URLExt.join(t.baseUrl,"/mrx-link/pipeline/import"),a={kfp_yaml:e},r={method:"POST",body:JSON.stringify(a)};let l;try{l=await i.ServerConnection.makeRequest(n,r,t)}catch(e){throw new i.ServerConnection.NetworkError(e)}let s=await l.text();if(s.length>0)try{s=JSON.parse(s)}catch(e){console.error("Not a JSON response body.",l)}if(!l.ok)throw u.error("Failed to import pipeline"),new i.ServerConnection.ResponseError(l,s.message||s);if(!l.ok)throw alert("error: "+s.message),new i.ServerConnection.ResponseError(l,s.message||s);return s}async function x(e){const t=i.ServerConnection.makeSettings(),n=o.URLExt.join(t.baseUrl,"/mrx-link/link-pipeline/import"),a={pipeline:e},r={method:"POST",body:JSON.stringify(a)};let l;try{l=await i.ServerConnection.makeRequest(n,r,t)}catch(e){throw new i.ServerConnection.NetworkError(e)}let s=await l.text();if(s.length>0)try{s=JSON.parse(s)}catch(e){console.error("Not a JSON response body.",l)}if(!l.ok)throw new i.ServerConnection.ResponseError(l,s.message||s);if(!l.ok)throw u.error("Failed to import pipeline"),new i.ServerConnection.ResponseError(l,s.message||s);return s}async function b(e){try{return{kernelId:e,components:(await g("/mrx-link/dag/kernels/"+e)).updated_components.added}}catch(e){return 400!==e.response.status&&u.error(e||"DAG API Error"),{kernelId:"",components:{}}}}h.defaults.headers.post["X-CSRFToken"]=function(e){const t=document.cookie.match("\\b_xsrf=([^;]*)\\b");return t?t[1]:void 0}();var C=n(79948);async function E(){const e=i.ServerConnection.makeSettings(),t=`${s.PageConfig.getBaseUrl()}mrx-link/runway/user/logout`;return(await i.ServerConnection.makeRequest(t,{method:"POST"},e)).ok}const w=(0,C.signal)(null),y=(0,C.signal)(!1),k=()=>async function(){const e=i.ServerConnection.makeSettings(),t=`${s.PageConfig.getBaseUrl()}mrx-link/runway/user`;return(await i.ServerConnection.makeRequest(t,{method:"GET"},e)).json()}().then((e=>w.value=e));(0,C.effect)((()=>{const e=w.value,t=void 0!==(null==e?void 0:e.runway_url)&&void 0!==(null==e?void 0:e.runway_project_id);g("/mrx-link/runway/info").then((e=>{y.value=e.on_runway||t}))}));const L=class{constructor(){this.runwayInfo=g("/mrx-link/runway/info")}async getRunwayInfo(){return await this.getIsRunway()?this.runwayInfo:this.getRunwayLiteInfo()}async getIsRunway(){return(await this.runwayInfo).on_runway}getRunwayLiteInfo(){var e,t,n,a,r;return{on_runway:!1,env:{RUNWAY_URL:null===(t=null===(e=w.value)||void 0===e?void 0:e.runway_url)||void 0===t?void 0:t.replace("https://","").replace("http://",""),WORKSPACE_ID:null===(n=w.value)||void 0===n?void 0:n.runway_workspace_id,PROJECT_ID:null===(a=w.value)||void 0===a?void 0:a.runway_project_id,JWT_TOKEN:null===(r=w.value)||void 0===r?void 0:r.runway_token}}}static getInstance(){return this.instance||(this.instance=new this)}}.getInstance();var _=n(62356),M=n(78115),S=n.n(M),N=n(88034);const A=()=>r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"160",height:"160",viewBox:"0 0 160 160",fill:"none"},r().createElement("rect",{width:"160",height:"160"}),r().createElement("g",{filter:"url(#filter0_ii_9_1560)"},r().createElement("path",{d:"M124.03 93.8131L68.5146 86.0356C64.5271 85.4285 61.5813 81.9827 61.5813 77.9135V44.8181C61.5813 40.7488 64.5271 37.3031 68.5146 36.696L124.03 28.9185C127.968 28.3278 131.5 31.3961 131.5 35.4161V87.3154C131.5 91.3355 127.968 94.4038 124.03 93.8131Z",fill:"url(#paint0_linear_9_1560)"})),r().createElement("path",{d:"M121.84 94.0312L68.1847 86.5399C64.3308 85.9552 61.4836 82.6363 61.4836 78.7168V46.8395C61.4836 42.9201 64.3308 39.6012 68.1847 39.0164L121.84 31.5252C125.647 30.9562 129.061 33.9116 129.061 37.7837V87.7727C129.061 91.6447 125.647 94.6001 121.84 94.0312Z",fill:"url(#paint1_linear_9_1560)"}),r().createElement("g",{opacity:"0.5",filter:"url(#filter1_f_9_1560)"},r().createElement("path",{d:"M95.6951 63.2531L62 58V76.2222C62 80.9942 65.1037 85.035 69.3049 85.7469L103 91V72.7778C103 68.0058 99.8963 63.965 95.6951 63.2531Z",fill:"#424291"})),r().createElement("g",{filter:"url(#filter2_ii_9_1560)"},r().createElement("path",{d:"M94.4854 65.9801C98.4729 66.5872 101.419 70.0327 101.419 74.1018V107.195C101.419 111.264 98.4729 114.71 94.4854 115.317L38.9704 123.078C35.0317 123.685 31.5 120.6 31.5 116.597V64.6839C31.5 60.6641 36.4428 57.81 40.3814 58.4007L94.4854 65.9801Z",fill:"url(#paint2_linear_9_1560)"})),r().createElement("path",{d:"M38.7202 60.5788L92.3759 68.07C96.2299 68.6548 99.077 71.9737 99.077 75.8932V107.77C99.077 111.69 96.2299 115.009 92.3759 115.594L38.7202 123.069C34.9135 123.654 31.5 120.683 31.5 116.826V66.8215C31.5 62.9494 34.9135 59.994 38.7202 60.563V60.5788Z",fill:"url(#paint3_linear_9_1560)"}),r().createElement("g",{style:{mixBlendMode:"overlay"},filter:"url(#filter3_f_9_1560)"},r().createElement("path",{d:"M92.3738 68.0873L61.4639 63.7727V78.7394C61.4639 82.6588 64.311 85.9777 68.1649 86.5625L99.0748 90.8771V75.9104C99.0748 71.9909 96.2277 68.672 92.3738 68.0873Z",fill:"#5C5CD7"})),r().createElement("defs",null,r().createElement("filter",{id:"filter0_ii_9_1560",x:"61.0813",y:"28.3455",width:"70.9187",height:"66.0408",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB"},r().createElement("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),r().createElement("feBlend",{mode:"normal",in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),r().createElement("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),r().createElement("feOffset",{dx:"1",dy:"1"}),r().createElement("feGaussianBlur",{stdDeviation:"0.25"}),r().createElement("feComposite",{in2:"hardAlpha",operator:"arithmetic",k2:"-1",k3:"1"}),r().createElement("feColorMatrix",{type:"matrix",values:"0 0 0 0 0.915609 0 0 0 0 0.915609 0 0 0 0 1 0 0 0 1 0"}),r().createElement("feBlend",{mode:"normal",in2:"shape",result:"effect1_innerShadow_9_1560"}),r().createElement("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),r().createElement("feOffset",{dx:"-1",dy:"-1"}),r().createElement("feGaussianBlur",{stdDeviation:"0.25"}),r().createElement("feComposite",{in2:"hardAlpha",operator:"arithmetic",k2:"-1",k3:"1"}),r().createElement("feColorMatrix",{type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.59 0"}),r().createElement("feBlend",{mode:"normal",in2:"effect1_innerShadow_9_1560",result:"effect2_innerShadow_9_1560"})),r().createElement("filter",{id:"filter1_f_9_1560",x:"52",y:"48",width:"61",height:"53",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB"},r().createElement("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),r().createElement("feBlend",{mode:"normal",in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),r().createElement("feGaussianBlur",{stdDeviation:"5",result:"effect1_foregroundBlur_9_1560"})),r().createElement("filter",{id:"filter2_ii_9_1560",x:"31",y:"57.8232",width:"70.9187",height:"65.8311",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB"},r().createElement("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),r().createElement("feBlend",{mode:"normal",in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),r().createElement("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),r().createElement("feOffset",{dx:"1",dy:"1"}),r().createElement("feGaussianBlur",{stdDeviation:"0.25"}),r().createElement("feComposite",{in2:"hardAlpha",operator:"arithmetic",k2:"-1",k3:"1"}),r().createElement("feColorMatrix",{type:"matrix",values:"0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0"}),r().createElement("feBlend",{mode:"normal",in2:"shape",result:"effect1_innerShadow_9_1560"}),r().createElement("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),r().createElement("feOffset",{dx:"-1",dy:"-1"}),r().createElement("feGaussianBlur",{stdDeviation:"0.25"}),r().createElement("feComposite",{in2:"hardAlpha",operator:"arithmetic",k2:"-1",k3:"1"}),r().createElement("feColorMatrix",{type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"}),r().createElement("feBlend",{mode:"normal",in2:"effect1_innerShadow_9_1560",result:"effect2_innerShadow_9_1560"})),r().createElement("filter",{id:"filter3_f_9_1560",x:"58.2118",y:"60.5207",width:"44.1149",height:"33.6083",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB"},r().createElement("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),r().createElement("feBlend",{mode:"normal",in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),r().createElement("feGaussianBlur",{stdDeviation:"1.62602",result:"effect1_foregroundBlur_9_1560"})),r().createElement("linearGradient",{id:"paint0_linear_9_1560",x1:"74.9959",y1:"30.878",x2:"117.679",y2:"83.317",gradientUnits:"userSpaceOnUse"},r().createElement("stop",{stopColor:"#BABAFF"}),r().createElement("stop",{offset:"0.576666",stopColor:"#8181FF"}),r().createElement("stop",{offset:"1",stopColor:"#3A3ADF"})),r().createElement("linearGradient",{id:"paint1_linear_9_1560",x1:"69.3049",y1:"37.3819",x2:"129.061",y2:"98.3575",gradientUnits:"userSpaceOnUse"},r().createElement("stop",{stopColor:"#C2C8FF"}),r().createElement("stop",{offset:"0.37",stopColor:"#5C67D3"}),r().createElement("stop",{offset:"1",stopColor:"#99A3FF"})),r().createElement("linearGradient",{id:"paint2_linear_9_1560",x1:"39.6301",y1:"61.3657",x2:"96.1342",y2:"91.8535",gradientUnits:"userSpaceOnUse"},r().createElement("stop",{stopColor:"#DFD7FF"}),r().createElement("stop",{offset:"1",stopColor:"#4C2BC6"})),r().createElement("linearGradient",{id:"paint3_linear_9_1560",x1:"38.8171",y1:"65.0242",x2:"95.3211",y2:"112.585",gradientUnits:"userSpaceOnUse"},r().createElement("stop",{stopColor:"#D8C7FF"}),r().createElement("stop",{offset:"0.425",stopColor:"#8C62FF"}),r().createElement("stop",{offset:"1",stopColor:"#B5A1FF"})))),I="RUNWAY_LITE_URL",O="RUNWAY_LITE_USER_EMAIL",P={".MuiPaper-root":{maxWidth:"inherit",maxHeight:"inherit"}},T=S().div`
  display: flex;
  padding: 80px;
  background-color: var(--background-surface);

  .icon-section {
    width: 160px;
    margin-right: 60px;
  }

  form {
    width: 420px;

    h1 {
      margin-bottom: 32px;
      color: var(--text-primary);
      font-size: 24px;
      font-style: normal;
      font-weight: 600;
    }

    input[type='text'],
    input[type='password'] {
      display: block;
      width: 100%;
      padding: 8px;
      margin-bottom: 16px;
      box-sizing: border-box;
    }

    input[type='checkbox'] {
      display: inline-block;
      margin: 0 8px 0 0;
    }

    label {
      display: block;
      margin-bottom: 4px;
      color: var(--text-secondary);
      font-size: 13px;
      font-style: normal;
      font-weight: 500;
    }

    label[for='remember'] {
      display: inline-block;
    }

    button {
      display: block;
      width: 100%;
      padding: 8px;
      background-color: var(--link-color);
      color: white;
      border: none;
      cursor: pointer;
    }

    .form-group.checkbox {
      display: flex;
      align-items: center;
      margin: 32px 0;
    }
  }

  menu {
    padding: 0;
    display: flex;
    justify-content: flex-end;
    gap: 16px;

    button {
      width: 140px;
      border-radius: 4px;
    }

    button.primary {
      color: var(--white);
      background-color: var(--link-color);
    }
    button.secondary {
      border: 1px solid var(--link-color);
      color: var(--link-color);
      background-color: var(--background-base);
    }
  }

  .error-message {
    margin-top: 16px;
    color: var(--feedback-fail);
    font-size: 13px;
    font-style: normal;
    font-weight: 500;
    width: 100%;
    word-wrap: break-word;
    white-space: pre-wrap;
    overflow-wrap: break-word;
    text-align: end;
  }
`,F=({open:e})=>{const[t,n]=(0,a.useState)(""),[l,o]=(0,a.useState)(""),[c,d]=(0,a.useState)(""),[p,m]=(0,a.useState)(!0),[u,h]=(0,a.useState)(null);return(0,a.useEffect)((()=>{e?function(){const e=localStorage.getItem(O);e&&o(e);const t=localStorage.getItem(I);t&&n(t)}():(n(""),o(""),d(""),m(!0),h(null))}),[e]),r().createElement(N.Dialog,{open:e,sx:P},r().createElement(T,null,r().createElement("div",{className:"icon-section"},r().createElement(A,null)),r().createElement("form",{onSubmit:function(e){e.preventDefault(),localStorage.setItem(I,t),p?localStorage.setItem(O,l):localStorage.removeItem(O),h(null),async function(e,t,n){const a=i.ServerConnection.makeSettings(),r=`${s.PageConfig.getBaseUrl()}mrx-link/runway/user/login`,l=JSON.stringify({runway_url:e,email:t,password:n}),o=await i.ServerConnection.makeRequest(r,{method:"POST",body:l},a),c=await o.json(),d=o.ok;return{success:d,user:d?c:null,message:c.message}}(t,l,c).then((e=>{var n;e.success&&e.user?w.value={id:e.user.id,runway_token:e.user.token,runway_url:t,email:l,first_name:void 0,last_name:void 0,runway_workspace_id:void 0,runway_project_id:void 0}:h(null!==(n=e.message)&&void 0!==n?n:"Fail to login.")}))}},r().createElement("h1",null,"Login"),r().createElement("div",{className:"form-group"},r().createElement("label",{htmlFor:"runway_url"},"Runway URL"),r().createElement("input",{required:!0,type:"text",id:"runway_url",value:t,onChange:e=>n(e.target.value)})),r().createElement("div",{className:"form-group"},r().createElement("label",{htmlFor:"email"},"Email"),r().createElement("input",{required:!0,type:"text",id:"email",value:l,onChange:e=>o(e.target.value)})),r().createElement("div",{className:"form-group"},r().createElement("label",{htmlFor:"password"},"Password"),r().createElement("input",{required:!0,type:"password",id:"password",value:c,onChange:e=>d(e.target.value)})),r().createElement("div",{className:"form-group checkbox"},r().createElement("input",{type:"checkbox",id:"remember",checked:p,onChange:e=>m(e.target.checked)}),r().createElement("label",{htmlFor:"remember"},"Save ID")),r().createElement("menu",null,r().createElement("button",{className:"secondary",type:"button",onClick:B},"Close"),r().createElement("button",{className:"primary",type:"submit"},"Login")),u&&r().createElement("div",{className:"error-message"},u))))},V=()=>r().createElement("svg",{width:"600",height:"151",viewBox:"0 0 600 151",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("g",{clipPath:"url(#clip0_9_1142)"},r().createElement("rect",{y:"0.5",width:"600",height:"150",rx:"12",fill:"#E1EAFF"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M382.549 11.5L516.467 11.5C520.627 11.5 523.999 14.8722 523.999 19.0321C523.999 19.0717 523.999 19.1113 523.998 19.1508L523.999 19.1508L523.999 26.8024L375.017 26.8024L375.017 19.1508L375.018 19.1508C375.017 19.1113 375.017 19.0717 375.017 19.0321C375.017 14.8722 378.389 11.5 382.549 11.5Z",fill:"#DDD3FF"}),r().createElement("circle",{cx:"385.308",cy:"19.7158",r:"2",fill:"#1D2B47"}),r().createElement("circle",{cx:"391.837",cy:"19.7158",r:"2",fill:"#1D2B47"}),r().createElement("circle",{cx:"398.366",cy:"19.7158",r:"2",fill:"#1D2B47"}),r().createElement("path",{d:"M375 26.8014L523.978 26.8014L523.978 160.361C523.978 164.777 520.398 168.357 515.982 168.357L382.995 168.357C378.579 168.357 374.999 164.777 374.999 160.361L375 26.8014Z",fill:"white"}),r().createElement("path",{d:"M375.133 19.4953C375.133 15.1532 378.653 11.6333 382.995 11.6333L515.982 11.6333C520.324 11.6333 523.844 15.1532 523.844 19.4953L523.844 26.5906L523.844 160.602C523.844 164.944 520.324 168.464 515.982 168.464L382.995 168.464C378.653 168.464 375.133 164.944 375.133 160.602L375.133 26.5906L375.133 19.4953Z",stroke:"black",strokeWidth:"0.266511"}),r().createElement("path",{d:"M449.193 51.1906L449.193 66.2547",stroke:"black",strokeWidth:"0.266511"}),r().createElement("path",{d:"M414.173 102.366L414.173 144.928",stroke:"black",strokeWidth:"0.266511"}),r().createElement("path",{d:"M414.173 91.3626C414.272 87.0585 416.962 78.2113 426.934 77.2549",stroke:"black",strokeWidth:"0.266511"}),r().createElement("path",{d:"M439.695 125.081C451.665 124.284 477.622 119.103 485.695 104.756",stroke:"black",strokeWidth:"0.266511"}),r().createElement("path",{d:"M485.694 91.3627C485.595 87.0587 482.904 78.2115 472.933 77.255",stroke:"black",strokeWidth:"0.266511"}),r().createElement("rect",{x:"387.463",y:"90.4028",width:"53.4184",height:"14.3468",rx:"5.33021",fill:"white"}),r().createElement("path",{d:"M387.463 95.733C387.463 92.7892 389.85 90.4028 392.794 90.4028L395.773 90.4028L395.773 104.75L392.794 104.75C389.85 104.75 387.463 102.363 387.463 99.4194L387.463 95.733Z",fill:"#CFEDFF"}),r().createElement("rect",{x:"387.597",y:"90.5361",width:"53.1519",height:"14.0803",rx:"5.19696",stroke:"black",strokeWidth:"0.266511"}),r().createElement("rect",{x:"387.463",y:"116.711",width:"53.4184",height:"14.3468",rx:"5.33021",fill:"white"}),r().createElement("path",{d:"M387.463 122.041C387.463 119.097 389.85 116.711 392.794 116.711L395.773 116.711L395.773 131.057L392.794 131.057C389.85 131.057 387.463 128.671 387.463 125.727L387.463 122.041Z",fill:"#CFEDFF"}),r().createElement("rect",{x:"387.597",y:"116.844",width:"53.1519",height:"14.0803",rx:"5.19696",stroke:"black",strokeWidth:"0.266511"}),r().createElement("rect",{x:"458.689",y:"90.4028",width:"53.4184",height:"14.3468",rx:"5.33021",fill:"white"}),r().createElement("path",{d:"M458.689 95.733C458.689 92.7892 461.076 90.4028 464.02 90.4028L466.999 90.4028L466.999 104.75L464.02 104.75C461.076 104.75 458.689 102.363 458.689 99.4194L458.689 95.733Z",fill:"#DDD3FF"}),r().createElement("rect",{x:"458.823",y:"90.5361",width:"53.1519",height:"14.0803",rx:"5.19696",stroke:"black",strokeWidth:"0.266511"}),r().createElement("rect",{x:"422.483",y:"37.8046",width:"53.4184",height:"14.3468",rx:"5.33021",fill:"white"}),r().createElement("path",{d:"M422.483 43.1348C422.483 40.191 424.869 37.8046 427.813 37.8046L430.792 37.8046L430.792 52.1514L427.813 52.1514C424.869 52.1514 422.483 49.7649 422.483 46.8212L422.483 43.1348Z",fill:"#FFD996"}),r().createElement("rect",{x:"422.616",y:"37.9378",width:"53.1519",height:"14.0803",rx:"5.19696",stroke:"black",strokeWidth:"0.266511"}),r().createElement("rect",{x:"422.483",y:"64.1022",width:"53.4184",height:"14.3468",rx:"5.33021",fill:"white"}),r().createElement("path",{d:"M422.483 69.4324C422.483 66.4886 424.869 64.1022 427.813 64.1022L430.792 64.1022L430.792 78.449L427.813 78.449C424.869 78.449 422.483 76.0626 422.483 73.1188L422.483 69.4324Z",fill:"#FFD996"}),r().createElement("rect",{x:"422.616",y:"64.2354",width:"53.1519",height:"14.0803",rx:"5.19696",stroke:"black",strokeWidth:"0.266511"}),r().createElement("rect",{x:"387.463",y:"143.015",width:"53.4184",height:"14.3468",rx:"5.33021",fill:"white"}),r().createElement("path",{d:"M387.463 148.345C387.463 145.402 389.85 143.015 392.794 143.015L395.773 143.015L395.773 157.362L392.794 157.362C389.85 157.362 387.463 154.976 387.463 152.032L387.463 148.345Z",fill:"#CFEDFF"}),r().createElement("rect",{x:"387.597",y:"143.148",width:"53.1519",height:"14.0803",rx:"5.19696",stroke:"black",strokeWidth:"0.266511"}),r().createElement("g",{filter:"url(#filter0_d_9_1142)"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M257.73 56.5001L374.588 56.5001C378.305 56.5001 381.318 59.513 381.318 63.2296C381.318 63.2647 381.317 63.2998 381.317 63.3349L381.318 63.3349L381.318 70.1712L251 70.1711L251 63.3348L251.001 63.3348C251.001 63.2998 251 63.2647 251 63.2296C251 59.513 254.013 56.5001 257.73 56.5001Z",fill:"#DDD3FF"}),r().createElement("path",{d:"M251 70.1729L381.317 70.1729L381.317 141.036C381.317 146.263 377.08 150.499 371.854 150.499L260.463 150.499C255.237 150.499 251 146.263 251 141.036L251 70.1729Z",fill:"white"}),r().createElement("path",{d:"M251.158 65.9631C251.158 60.8239 255.324 56.6578 260.463 56.6578L371.854 56.6578C376.993 56.6578 381.159 60.8239 381.159 65.9631L381.159 69.9591L381.159 141.036C381.159 146.175 376.993 150.342 371.854 150.342L260.463 150.342C255.324 150.342 251.158 146.175 251.158 141.036L251.158 69.959L251.158 65.9631Z",stroke:"black",strokeWidth:"0.315434"}),r().createElement("rect",{x:"259.991",y:"79.3687",width:"49.5231",height:"60.8787",rx:"6.15096",stroke:"black",strokeWidth:"0.315434"}),r().createElement("path",{d:"M265.511 131.889L269.611 119.903L278.444 117.379L284.752 106.655L290.745 115.802L295.792 94.9837L299.578 99.0843L303.994 88.0441",stroke:"black",strokeWidth:"0.315434"}),r().createElement("rect",{x:"314.718",y:"82.9962",width:"57.4089",height:"6.93954",rx:"3.46977",fill:"#DDD3FF"}),r().createElement("rect",{x:"314.718",y:"112.018",width:"57.4089",height:"6.93954",rx:"3.46977",fill:"#DDD3FF"}),r().createElement("rect",{x:"314.827",y:"93.7235",width:"57.2541",height:"14.5272",rx:"7.26358",fill:"#DDD3FF"}),r().createElement("rect",{x:"314.827",y:"122.742",width:"57.2541",height:"14.5272",rx:"7.26358",fill:"#DDD3FF"})),r().createElement("path",{d:"M171.999 122.788C175.333 120.788 179.299 113.988 168.499 102.788L168.499 93.7878C168.166 92.1211 166.399 88.0878 161.999 85.2878C156.499 81.7878 149.999 77.7878 146.999 76.2878L107.499 59.2878L89.5 93.7878L130.499 105.288C130.833 106.621 132.999 110.788 138.999 116.788C138.499 117.288 137.799 118.788 138.999 120.788L144.499 130.288C145.833 131.288 149.299 132.988 152.499 131.788C153.666 131.121 155.5 129.588 155.5 128.788L159.999 128.788C159.999 128.788 160.656 128.768 162 128C163.273 127.272 164.158 126 165 126C166 126 167 126.5 170 125C173 123.5 171.999 122.788 171.999 122.788Z",fill:"#FFAFAF"}),r().createElement("path",{d:"M107.499 59.0501C93.443 53.1324 2.79153 12.7953 -7.50098 8.49999L-13.501 86L85.9985 122.788C79.5985 119.188 83.3319 107.621 85.9985 102.288L87.4995 98.5L97.6187 78.9189L107.499 59.0501Z",fill:"#9B9FFF"}),r().createElement("path",{d:"M85.9985 122.788C79.5985 119.188 83.3319 107.621 85.9985 102.288L90 94L109 99.5L99.9985 117.288C95.9985 124.088 88.9985 123.788 85.9985 122.788Z",fill:"#1D2B47"}),r().createElement("path",{d:"M138.999 116.788C135.999 113.954 129.799 106.888 128.999 101.288",stroke:"black",strokeWidth:"0.5"}),r().createElement("path",{d:"M130.499 105.288L89.5 94",stroke:"black",strokeWidth:"0.5"}),r().createElement("mask",{id:"path-45-inside-1_9_1142",fill:"white"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M181.984 109.578C180.213 107.989 178.588 106.225 177.131 104.286L130.669 136.819C128.407 138.403 125.289 137.853 123.705 135.591C122.121 133.329 122.671 130.212 124.933 128.628L138.139 119.381L168.499 98.1228L172.247 95.4983C164.299 75.0367 174.66 48.1183 198.192 31.641C224.857 12.9701 258.335 14.7756 272.968 35.6738C287.601 56.5719 277.848 88.649 251.183 107.32C227.499 123.904 198.439 124.333 181.984 109.578ZM247.364 101.53C224.78 117.509 196.32 116.114 183.796 98.4144C171.273 80.7146 179.428 53.4123 202.012 37.433C224.596 21.4538 253.056 22.8485 265.58 40.5483C278.103 58.2481 269.948 85.5503 247.364 101.53Z"})),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M181.984 109.578C180.213 107.989 178.588 106.225 177.131 104.286L130.669 136.819C128.407 138.403 125.289 137.853 123.705 135.591C122.121 133.329 122.671 130.212 124.933 128.628L138.139 119.381L168.499 98.1228L172.247 95.4983C164.299 75.0367 174.66 48.1183 198.192 31.641C224.857 12.9701 258.335 14.7756 272.968 35.6738C287.601 56.5719 277.848 88.649 251.183 107.32C227.499 123.904 198.439 124.333 181.984 109.578ZM247.364 101.53C224.78 117.509 196.32 116.114 183.796 98.4144C171.273 80.7146 179.428 53.4123 202.012 37.433C224.596 21.4538 253.056 22.8485 265.58 40.5483C278.103 58.2481 269.948 85.5503 247.364 101.53Z",fill:"#9B9FFF"}),r().createElement("path",{d:"M177.131 104.286L176.844 103.876L177.24 103.599L177.531 103.986L177.131 104.286ZM181.984 109.578L182.318 109.205L181.984 109.578ZM130.669 136.819L130.955 137.229L130.669 136.819ZM123.705 135.591L124.115 135.305L123.705 135.591ZM124.933 128.628L125.22 129.037L124.933 128.628ZM138.139 119.381L138.426 119.79L138.139 119.381ZM168.499 98.1228L168.212 97.7132L168.499 98.1228ZM172.247 95.4983L172.713 95.3172L172.855 95.6829L172.534 95.9078L172.247 95.4983ZM198.192 31.641L198.479 32.0505L198.192 31.641ZM272.968 35.6738L273.378 35.387L272.968 35.6738ZM251.183 107.32L250.896 106.91L251.183 107.32ZM247.364 101.53L247.075 101.121L247.364 101.53ZM202.012 37.433L202.301 37.8412L202.012 37.433ZM265.58 40.5483L265.172 40.8371L265.58 40.5483ZM177.531 103.986C178.968 105.898 180.571 107.638 182.318 109.205L181.65 109.95C179.855 108.34 178.208 106.552 176.731 104.586L177.531 103.986ZM130.382 136.41L176.844 103.876L177.418 104.695L130.955 137.229L130.382 136.41ZM124.115 135.305C125.54 137.34 128.346 137.835 130.382 136.41L130.955 137.229C128.467 138.971 125.038 138.366 123.295 135.878L124.115 135.305ZM125.22 129.037C123.184 130.463 122.689 133.269 124.115 135.305L123.295 135.878C121.553 133.39 122.158 129.961 124.646 128.218L125.22 129.037ZM138.426 119.79L125.22 129.037L124.646 128.218L137.852 118.971L138.426 119.79ZM168.785 98.5323L138.426 119.79L137.852 118.971L168.212 97.7132L168.785 98.5323ZM172.534 95.9078L168.785 98.5323L168.212 97.7132L171.96 95.0887L172.534 95.9078ZM198.479 32.0505C175.073 48.4397 164.873 75.1343 172.713 95.3172L171.781 95.6793C163.725 74.9391 174.247 47.7969 197.905 31.2314L198.479 32.0505ZM272.559 35.9606C258.145 15.3759 225.016 13.469 198.479 32.0505L197.905 31.2314C224.698 12.4711 258.525 14.1753 273.378 35.387L272.559 35.9606ZM250.896 106.91C277.433 88.3288 286.972 56.5452 272.559 35.9606L273.378 35.387C288.231 56.5987 278.262 88.9692 251.47 107.729L250.896 106.91ZM182.318 109.205C198.548 123.759 227.338 123.406 250.896 106.91L251.47 107.729C227.659 124.402 198.331 124.907 181.65 109.95L182.318 109.205ZM184.204 98.1256C196.507 115.513 224.618 117.011 247.075 101.121L247.653 101.938C224.942 118.007 196.133 116.715 183.388 98.7032L184.204 98.1256ZM202.301 37.8412C179.844 53.7305 171.902 80.7383 184.204 98.1256L183.388 98.7032C170.643 80.6909 179.012 53.0942 201.723 37.0249L202.301 37.8412ZM265.172 40.8371C252.869 23.4498 224.758 21.9519 202.301 37.8412L201.723 37.0249C224.434 20.9556 253.243 22.2472 265.988 40.2595L265.172 40.8371ZM247.075 101.121C269.532 85.2322 277.474 58.2244 265.172 40.8371L265.988 40.2595C278.732 58.2717 270.364 85.8685 247.653 101.938L247.075 101.121Z",fill:"black",mask:"url(#path-45-inside-1_9_1142)"}),r().createElement("g",{filter:"url(#filter1_b_9_1142)"},r().createElement("ellipse",{cx:"50.0924",cy:"39.2592",rx:"50.0924",ry:"39.2592",transform:"matrix(-0.816325 0.577593 0.577593 0.816325 242.904 8.5)",fill:"#E2F4FF",style:{mixBlendMode:"multiply"}})),r().createElement("path",{d:"M159.999 128.5L171.999 119.5L169.999 114.5C168.999 113.333 165.399 109.8 158.999 105C153.799 103.4 153.166 106.333 153.499 108C147.899 106.4 147.166 109.667 147.499 111.5C143.999 111.5 143.999 112.5 143.499 113.5C143.099 114.3 143.332 115.167 143.499 115.5C142.499 115.333 140.299 115.1 139.499 115.5C138.499 116 138.499 118 138.499 119C138.499 119.8 142.832 127 144.999 130.5C146.332 131 149.499 132 151.499 132C153.499 132 154.999 130.333 155.499 129.5L155.999 128.5H159.999Z",fill:"#FFAFAF"}),r().createElement("path",{d:"M143.117 115.5C141.283 114.666 137.817 114.3 138.617 119.5C138.617 119.5 142.734 127.5 144.617 130C146.499 132.5 152.417 133.8 155.617 129",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"}),r().createElement("path",{d:"M164.499 126C158.999 131.5 153.617 127.925 152.617 126.925L146.617 119.925C142.217 115.925 143.117 113.259 144.117 112.425C145.059 111.483 146.182 111.251 147.393 111.5",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"}),r().createElement("path",{d:"M153.117 108.149C151.151 107.294 149.358 107.184 148.117 108.425C147.117 109.259 146.217 111.925 150.617 115.925C150.617 115.925 155.735 121.851 158.617 123.925C161.499 126 167.999 126.5 169.499 125.5C170.999 124.5 172.399 123.3 171.999 122.5",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"}),r().createElement("path",{d:"M172.116 107.5C172.411 107.833 173.399 109.3 174.999 112.5C176.999 118.9 173.911 121.784 172.116 122.425C168.516 123.625 165.616 121.925 164.616 120.925L156.616 112.925C152.216 108.925 153.116 106.259 154.116 105.425C155.306 104.236 157.002 104.287 158.872 105.047L170.999 115",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"}),r().createElement("path",{d:"M158.999 99C157.666 101.333 152.799 105.4 144 103",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"}),r().createElement("path",{d:"M85.4995 122.5L-2.5 89.9999",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"}),r().createElement("path",{d:"M173 109C171 107.5 169.333 98.5001 168.5 93.5001C165 92.6667 158.075 89.7016 158.5 96.5001C158.657 99.0121 160.82 100.442 162 102.5C163 108.5 167.484 111.085 170 112C171.2 112 173.333 109.667 173 109Z",fill:"#FFAFAF"}),r().createElement("path",{d:"M158 97.0001C158.098 98.6814 161.158 100.395 162 102C162.5 108 167.5 111.5 170 112C172.5 112.5 174.5 111 173 109C170 104.5 169 96 168.5 93.5001C168 91.0001 164.679 86.9756 159.5 83.5C153.092 79.2003 144.041 75.143 135 71C125.394 66.5985 116.5 63 107.5 59.5",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"}),r().createElement("path",{d:"M-3 10.5L107.5 59C103.34 65.9334 99.102 75.6964 94.5 85C81.5 108 79.5 120.5 86 122.5C94.1799 125.017 99 120.5 102 112.5C103.753 109.16 107.249 103.32 109 99.5",stroke:"black",strokeWidth:"0.5",strokeLinecap:"round"})),r().createElement("defs",null,r().createElement("filter",{id:"filter0_d_9_1142",x:"251",y:"56.5001",width:"134.317",height:"97.9995",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB"},r().createElement("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),r().createElement("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),r().createElement("feOffset",{dx:"4",dy:"4"}),r().createElement("feComposite",{in2:"hardAlpha",operator:"out"}),r().createElement("feColorMatrix",{type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"}),r().createElement("feBlend",{mode:"normal",in2:"BackgroundImageFix",result:"effect1_dropShadow_9_1142"}),r().createElement("feBlend",{mode:"normal",in:"SourceGraphic",in2:"effect1_dropShadow_9_1142",result:"shape"})),r().createElement("filter",{id:"filter1_b_9_1142",x:"173.921",y:"22.3044",width:"101.533",height:"94.3538",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB"},r().createElement("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),r().createElement("feGaussianBlur",{in:"BackgroundImageFix",stdDeviation:"2"}),r().createElement("feComposite",{in2:"SourceAlpha",operator:"in",result:"effect1_backgroundBlur_9_1142"}),r().createElement("feBlend",{mode:"normal",in:"SourceGraphic",in2:"effect1_backgroundBlur_9_1142",result:"shape"})),r().createElement("clipPath",{id:"clip0_9_1142"},r().createElement("rect",{y:"0.5",width:"600",height:"150",rx:"12",fill:"white"})))),H={".MuiPaper-root":{maxWidth:"inherit",maxHeight:"inherit"}},R=S().div`
  width: 600px;
  height: 590px;
  padding: 80px;
  background-color: var(--background-surface);

  header {
    .header-graphic-section {
      width: 100%;
      height: 150px;
      background-color: #f5f5f5;
      margin-bottom: 32px;
    }

    h1 {
      color: var(--text-primary);
      font-size: 24px;
      font-weight: 500;
    }

    p {
      color: var(--text-secondary);
      font-size: 13px;
      font-weight: 400;
    }
  }

  ul.project-list {
    display: flex;
    max-height: 264px;
    flex-direction: column;
    align-items: flex-start;
    margin: 32px 0;
    padding: 0;
    border-radius: 8px;
    border: 1px solid var(--list-border);
    overflow-y: auto;
    overflow-x: hidden;
  }

  li.project-item {
    display: flex;
    width: 560px;
    padding: 12px 20px;
    gap: 12px;
    justify-content: space-between;
    border-bottom: 1px solid var(--list-border);

    .project-title {
      flex: 1;
      color: var(--text-primary);
      font-size: 16px;
      font-weight: 500;
      display: flex;
      align-items: center;
    }

    .project-selection-icon {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 24px;
      height: 24px;
      background-color: #fff;
      border: 1px solid var(--list-border);
      border-radius: 50%;
    }

    &:last-child {
      border-bottom: none;
    }

    &:hover {
      background-color: var(--background-surface-hover);
      cursor: pointer;
    }
  }

  li.no-project,
  li.loading {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 240px;
    color: var(--text-secondary);
    font-size: 16px;
  }

  footer {
    display: flex;
    width: 100%;
    flex-direction: column;
    align-items: center;
    gap: 4px;
  }

  footer p {
    color: var(--text-secondary);
    font-size: 13px;
    font-weight: 400;
  }

  footer button.text-button {
    background: none;
    border: none;
    padding: 0;
    margin: 0;
    cursor: pointer;

    color: var(--link-color);
    font-size: 13px;
    font-weight: 700;
  }
`,z=({open:e})=>{const[t,n]=(0,a.useState)(!0),[l,o]=(0,a.useState)([]);return(0,a.useEffect)((()=>{e&&async function(){await async function(){const e=await async function(){const e=`${s.PageConfig.getBaseUrl()}mrx-link/runway/workspaces`,t=await fetch(e,{method:"GET"}),n=await t.json();if(!t.ok)throw new Error(`Failed to get runway workspaces. ${null==n?void 0:n.error}`);return n}();if(0===e.length)throw new Error("No workspace available");return async function(e){const t=i.ServerConnection.makeSettings(),n=`${s.PageConfig.getBaseUrl()}mrx-link/runway/workspaces`,a=JSON.stringify({workspace_id:e});return(await i.ServerConnection.makeRequest(n,{method:"POST",body:a},t)).ok}(e[0].id)}();const e=(await async function(){const e=`${s.PageConfig.getBaseUrl()}mrx-link/runway/projects`,t=await fetch(e,{method:"GET"}),n=await t.json();if(!t.ok)throw new Error(`Failed to get runway projects. ${null==n?void 0:n.error}`);return n}()).filter((e=>"reader"!==e.project_role));o(e),n(!1)}()}),[e]),r().createElement(N.Dialog,{open:e,sx:H},r().createElement(R,null,r().createElement("header",null,r().createElement("div",{className:"header-graphic-section"},r().createElement(V,null)),r().createElement("h1",null,"Joined projects"),r().createElement("p",null,"Choose a project you want to use")),r().createElement("main",null,r().createElement("ul",{className:"project-list"},l.map((e=>r().createElement("li",{className:"project-item",key:e.id,onClick:()=>async function(e){await async function(e){const t=i.ServerConnection.makeSettings(),n=`${s.PageConfig.getBaseUrl()}mrx-link/runway/projects`,a=JSON.stringify({project_id:e});return(await i.ServerConnection.makeRequest(n,{method:"POST",body:a},t)).json()}(e),k()}(e.id)},r().createElement("div",{className:"project-title"},e.title),r().createElement("div",{className:"project-selection-icon"},r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"12",height:"13",viewBox:"0 0 12 13",fill:"none"},r().createElement("path",{d:"M6.28125 3.125L9.65625 6.5L6.28125 9.875M9.1875 6.5L2.34375 6.5",stroke:"black",strokeWidth:"1.125",strokeLinecap:"round",strokeLinejoin:"round"})))))),t&&0===l.length&&r().createElement("li",{className:"loading"},"Loading..."),!t&&0===l.length&&r().createElement("li",{className:"no-project"},"No projects available."))),r().createElement("footer",null,r().createElement("p",null,"Can't you see the project?"),r().createElement("button",{className:"text-button",onClick:async function(){await E(),w.value=null}},"Log in using a different account"))))},Z=(0,C.signal)(!1),B=()=>Z.value=!0,j=(0,_.x)((()=>{var e,t;const[n,l]=(0,a.useState)(!0);(0,a.useEffect)((()=>{k().then((()=>l(!1)))}),[]);const o=null===(e=w.value)||void 0===e?void 0:e.id,i=!Z.value&&!n&&void 0===o,s=null===(t=w.value)||void 0===t?void 0:t.runway_project_id,c=!Z.value&&!n&&!i&&void 0===s;return r().createElement(r().Fragment,null,r().createElement(F,{open:i}),r().createElement(z,{open:c}))})),D={id:"runway-lite-env-manager",requires:[],autoStart:!0,activate:async function(e){if(await L.getIsRunway())return;const t=document.createElement("div");t.id="runway-lite-env-manager-root",document.body.appendChild(t),(0,l.H)(t).render(r().createElement(j,null))}};var W=n(54291),U=n(62522),$=n(40874),G=n(45032),q=n(29215),K=n(60352),Y=n(90390),X=n(8385),J=n(35256);const Q=e=>{if(null===e||"object"!=typeof e)return e;const t=Array.isArray(e)?[]:{};for(const n of Object.keys(e))t[n]=Q(e[n]);return t},ee=Q;const te=(e,t)=>{const n=document.createElement("div"),a=(0,l.H)(n),o=()=>{a.unmount(),n.remove()};return(()=>{const l=r().createElement(ne,{open:!0,onClose:o,width:null==t?void 0:t.width},e(o));a.render(l),document.body.append(n)})(),{closeDialog:o}},ne=e=>{const{children:t,width:n}=e,a=function(e,t){var n={};for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&t.indexOf(a)<0&&(n[a]=e[a]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(a=Object.getOwnPropertySymbols(e);r<a.length;r++)t.indexOf(a[r])<0&&Object.prototype.propertyIsEnumerable.call(e,a[r])&&(n[a[r]]=e[a[r]])}return n}(e,["children","width"]);return r().createElement(N.Dialog,Object.assign({sx:re},a),r().createElement(ae,{width:n},t))},ae=S().div`
  font-family: 'Roboto', sans-serif;
  input,
  textarea,
  button {
    font-family: 'Roboto', sans-serif;
  }
  position: static;
  transform: none;
  box-sizing: border-box;
  top: 50%;
  left: 50%;
  width: ${({width:e})=>e?`${e}px`:"550px"};
  padding: 28px 24px;
  box-shadow: var(--popover-shadow);
  background-color: var(--layout-background-base);

  h1 {
    display: flex;
    align-items: center;
    font-weight: 700;
    font-size: 20px;
    line-height: 20px;
    color: var(--text-primary);
    margin: 0;
  }

  h1 svg {
    margin-right: 8px;
  }

  /* section */
  section {
    margin: 20px 0;
    font-size: 13px;
    line-height: 15px;
    color: var(--text-secondary);
  }

  section.align-right {
    display: flex;
    justify-content: flex-end;
  }

  section .note {
    margin: 40px 0 20px 0;
    padding: 8px 12px;
    background-color: var(--background-surface);
    font-size: 11px;
    line-height: 130%;
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 16px;

    .MuiInputLabel-root,
    .MuiInputLabel-root.Mui-focused {
      font-size: 13px;
      font-weight: 500;
      color: var(--link-color);
    }

    input:disabled,
    textarea:disabled {
      background-color: var(--control-background-disabled);
      color: var(--control-disabled);
    }
  }

  menu {
    margin: 24px 0 0;
    text-align: right;
    display: flex;
    justify-content: flex-end;

    button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      box-sizing: border-box;
      width: 120px;
      height: 36px;
      padding: 0;
      margin: 0;
      font-weight: 700;
      font-size: 13px;
      border-radius: 5px;
      border: 1px solid var(--link-color);
      color: var(--link-color);
      background-color: transparent;
    }
    button.full-width {
      width: 100%;
    }
    button.primary {
      border-color: var(--link-color);
      color: var(--white);
      background-color: var(--link-color);
    }
    button.secondary {
      border-color: var(--border-primary);
      color: var(--text-primary);
      background-color: transparent;
    }
    button.danger {
      border-color: var(--button-error-border);
      color: var(--button-error-text);
      background-color: var(--button-error-background);
    }
    button:disabled {
      color: var(--control-text-disabled);
      border-color: var(--control-border);
      background-color: var(--control-background-disabled);
    }
    button + button {
      margin-left: 12px;
    }
    button:not(.loading) svg {
      margin-right: 4px;
    }
  }
`,re={".MuiPaper-root":{borderRadius:"8px",background:"transparent",border:"1px solid var(--background-surface-border)",fontFamily:"Roboto, sans-serif"},"button, input, textarea, pre":{fontFamily:"Roboto, sans-serif"}},le=r().createElement("svg",{className:"inform",width:"30",height:"30",viewBox:"0 0 30 30",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("rect",{width:"30",height:"30",rx:"15",fill:"var(--chip-info-background)"}),r().createElement("path",{d:"M13.25 9.3125C13.25 8.5915 13.8415 8 14.5625 8H15.4375C16.1585 8 16.75 8.5915 16.75 9.3125V10.1875C16.75 10.9085 16.1585 11.5 15.4375 11.5H14.5625C14.2148 11.4986 13.8818 11.3599 13.6359 11.1141C13.3901 10.8682 13.2514 10.5352 13.25 10.1875V9.3125ZM18.5 22H11.5V20.25H13.25V15H11.5V13.25H16.75V20.25H18.5V22Z",fill:"var(--feedback-info)"})),oe=r().createElement("svg",{className:"warning",width:"30",height:"30",viewBox:"0 0 30 30",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("rect",{width:"30",height:"30",rx:"15",fill:"var(--chip-fail-background)"}),r().createElement("path",{d:"M15.0005 16.2635C15.24 16.2635 15.4696 16.1683 15.6389 15.999C15.8082 15.8297 15.9033 15.6001 15.9033 15.3607V11.1801C15.9033 10.9407 15.8082 10.7111 15.6389 10.5418C15.4696 10.3725 15.24 10.2773 15.0005 10.2773C14.7611 10.2773 14.5315 10.3725 14.3622 10.5418C14.1929 10.7111 14.0978 10.9407 14.0978 11.1801V15.3468C14.0959 15.4665 14.1179 15.5854 14.1625 15.6965C14.207 15.8077 14.2732 15.9088 14.3572 15.9941C14.4412 16.0795 14.5414 16.1472 14.6518 16.1934C14.7623 16.2397 14.8808 16.2635 15.0005 16.2635Z",fill:"var(--feedback-fail)"}),r().createElement("path",{d:"M14.9635 19.3529C15.5388 19.3529 16.0052 18.8865 16.0052 18.3112C16.0052 17.7359 15.5388 17.2695 14.9635 17.2695C14.3882 17.2695 13.9219 17.7359 13.9219 18.3112C13.9219 18.8865 14.3882 19.3529 14.9635 19.3529Z",fill:"var(--feedback-fail)"}),r().createElement("path",{d:"M23.5633 19.1942L16.7994 6.73584C16.6203 6.40682 16.3559 6.13217 16.0338 5.9408C15.7118 5.74944 15.3441 5.64844 14.9695 5.64844C14.595 5.64844 14.2273 5.74944 13.9053 5.9408C13.5832 6.13217 13.3188 6.40682 13.1397 6.73584L6.36885 19.1942C6.19163 19.5123 6.10088 19.8713 6.10565 20.2354C6.11041 20.5995 6.21052 20.956 6.39601 21.2693C6.58149 21.5827 6.84586 21.8419 7.16277 22.0213C7.47968 22.2006 7.83806 22.2937 8.20218 22.2914H21.73C22.0911 22.2917 22.4461 22.1982 22.7602 22.0199C23.0743 21.8416 23.3366 21.5848 23.5215 21.2746C23.7064 20.9643 23.8074 20.6114 23.8148 20.2503C23.8221 19.8892 23.7354 19.5325 23.5633 19.215V19.1942ZM22.3272 20.5414C22.2657 20.6451 22.1783 20.7309 22.0736 20.7906C21.9689 20.8503 21.8505 20.8816 21.73 20.8817H8.20218C8.08147 20.882 7.96276 20.8509 7.85776 20.7913C7.75275 20.7318 7.66508 20.6459 7.60339 20.5421C7.54169 20.4384 7.50811 20.3203 7.50595 20.1996C7.50379 20.079 7.53313 19.9598 7.59107 19.8539L14.355 7.39556C14.4145 7.28531 14.5027 7.19322 14.6103 7.12903C14.7179 7.06485 14.8408 7.03096 14.9661 7.03096C15.0914 7.03096 15.2143 7.06485 15.3219 7.12903C15.4295 7.19322 15.5177 7.28531 15.5772 7.39556L22.3411 19.8539C22.3986 19.9598 22.4276 20.0789 22.4252 20.1995C22.4228 20.32 22.389 20.4379 22.3272 20.5414Z",fill:"var(--feedback-fail)"})),ie=r().createElement("svg",{className:"runway-logo",width:"32",height:"32",viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("circle",{cx:"14",cy:"14",r:"14",fill:"var(--chip-tag-background)"}),r().createElement("path",{d:"M11.5066 21.9662L7.64578 20.1254C7.25229 19.9361 7 19.5367 7 19.0975V11.2832C7 10.615 7.68976 10.1735 8.28693 10.4608L12.1477 12.3017C12.5412 12.4909 12.7935 12.8904 12.7935 13.3296V21.1439C12.7935 21.812 12.1037 22.2536 11.5066 21.9662Z",fill:"#9578FF"}),r().createElement("path",{d:"M15.6081 19.781L11.7473 17.9402C11.3539 17.751 11.1016 17.3515 11.1016 16.9123V9.09566C11.1016 8.42753 11.7913 7.986 12.3885 8.27334L16.2493 10.1142C16.6428 10.3034 16.8951 10.7029 16.8951 11.1421V18.9564C16.8951 19.6245 16.2053 20.0661 15.6081 19.7787V19.781Z",fill:"#4A6DFD"}),r().createElement("path",{d:"M19.7131 17.597L15.8523 15.7561C15.4588 15.5669 15.2065 15.1674 15.2065 14.7282V6.91157C15.2065 6.24345 15.8963 5.80192 16.4935 6.08926L20.3543 7.93012C20.7477 8.11935 21 8.51882 21 8.95801V16.7723C21 17.4404 20.3103 17.882 19.7131 17.5946V17.597Z",fill:"#6C79F9"}),r().createElement("path",{d:"M12.1489 12.297L11.105 11.7994V16.9085C11.105 17.3477 11.3573 17.7495 11.7508 17.9364L12.7947 18.434V13.3273C12.7947 12.8881 12.5424 12.4863 12.1489 12.2994V12.297Z",fill:"#5652FF"}),r().createElement("path",{d:"M16.2504 10.1138L15.2065 9.61621V14.7253C15.2065 15.1645 15.4588 15.5663 15.8523 15.7532L16.8962 16.2508V11.144C16.8962 10.7048 16.6439 10.303 16.2504 10.1161V10.1138Z",fill:"#365DEA"})),se=ne;var ce=n(89539);class de{constructor(){this.components={},this.commandRegistry=null,(0,ce.makeAutoObservable)(this)}clearKernelComponents(e){e&&""!==e&&this.components[e]&&delete this.components[e]}setKernelComponents(e,t){e&&""!==e&&(this.components[e]=t,this.components=Object.assign({},this.components))}getKernelComponents(e){return e&&""!==e&&this.components[e]?this.components[e]:de.emptyDag}getComponent(e,t){if(e&&""!==e&&t&&""!==t&&this.components[e])return this.components[e][t]}setCommandRegistry(e){this.commandRegistry=e}async executeDagUpdateCommand(){var e;await(null===(e=this.commandRegistry)||void 0===e?void 0:e.execute(Rt.dagUpdate))}}de.emptyDag={};const pe=new de,me=new class{constructor(){this.isParameterExecutable={}}checkKernelReady(e){return!(!e||"idle"!==e.status&&"busy"!==e.status)||(u.info("The kernel is not ready. Please try again later."),!1)}checkParametersExecutable(e){return!(e&&di&&di.currentWidget&&di.currentWidget.metadata.parameters&&0!==di.currentWidget.metadata.parameters.length&&!1===this.isParameterExecutable[e.id]&&(u.info("The parameters are not loaded. Please try again later."),1))}checkCodeExecutable(e){return!!this.checkKernelReady(e)&&!!this.checkParametersExecutable(e)}};function ue(e,t){const n=e.currentWidget;return!0===t?null==n?void 0:n.sessionContext.path:null==n?void 0:n.sessionContext.name}const he=(e,t)=>{const n=t.currentWidget.content,{model:a}=n,r=[],l=a.cells[Symbol.iterator]();let o=null==l?void 0:l.next();for(;o&&o.value;)r.push(o.value.sharedModel.getMetadata("canvas").id),o=null==l?void 0:l.next();return r};const ge=e=>[e.substring(0,e.indexOf(".")),e.substring(e.indexOf("."),e.length)],ve=new Y.LabIcon({name:"canvas:run component",svgstr:'<svg class="link-component-context-menu" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M6.93621 4.17486C6.07568 3.67803 5 4.29907 5 5.29274V18.7073C5 19.7009 6.07568 20.322 6.93621 19.8251L18.5535 13.1179C19.4141 12.621 19.4141 11.379 18.5535 10.8821L6.93621 4.17486Z" fill="var(--link-icon)"/>\n</svg>\n'}),fe=new Y.LabIcon({name:"canvas:save-file",svgstr:'<svg class="link-component-context-menu" width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M17 3H4.99999C3.89 3 3 3.9 3 4.99999V19C3 20.1 3.89 21 4.99999 21H19C20.1 21 21 20.1 21 19V7.00001L17 3ZM12 19C10.34 19 9 17.66 9 16C9 14.34 10.34 13 12 13C13.66 13 15 14.34 15 16C15 17.66 13.66 19 12 19ZM15 9H4.99999V4.99999H15V9Z" fill="var(--link-icon)"/>\n</svg>\n'}),xe=new Y.LabIcon({name:"canvas:enable component cache",svgstr:'<svg class="link-component-context-menu" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M20 5.57143V7.17857C20 8.59487 16.4167 9.75 12 9.75C7.58332 9.75 4 8.59487 4 7.17857V5.57143C4 4.15513 7.58332 3 12 3C16.4167 3 20 4.15513 20 5.57143ZM20 9.1875V12.8036C20 14.2199 16.4167 15.375 12 15.375C7.58332 15.375 4 14.2199 4 12.8036V9.1875C5.71875 10.3527 8.86457 10.8951 12 10.8951C15.1354 10.8951 18.2812 10.3527 20 9.1875ZM20 14.8125V18.4286C20 19.8449 16.4167 21 12 21C7.58332 21 4 19.8449 4 18.4286V14.8125C5.71875 15.9777 8.86457 16.5201 12 16.5201C15.1354 16.5201 18.2812 15.9777 20 14.8125Z" fill="#6C79F9"/>\n</svg>\n'}),be=new Y.LabIcon({name:"canvas:disable component cache",svgstr:'<svg class="link-component-context-menu" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M21.4185 2.58071C21.9261 3.08839 21.9261 3.91151 21.4185 4.41919L4.41846 21.4192C3.91078 21.9269 3.08766 21.9269 2.57998 21.4192C2.0723 20.9115 2.0723 20.0884 2.57998 19.5807L19.58 2.58071C20.0877 2.07303 20.9108 2.07303 21.4185 2.58071Z" fill="var(--link-icon)"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M15.8447 3.31679C14.7036 3.11495 13.3933 3 12 3C7.58332 3 4 4.15513 4 5.57143V7.17857C4 8.31922 6.32425 9.29048 9.5362 9.62533L15.8447 3.31679ZM8.50507 10.6565C6.68282 10.3938 5.06662 9.91059 4 9.1875V12.8036C4 13.2712 4.39057 13.7103 5.07276 14.0888L8.50507 10.6565ZM7.83924 14.9992L11.9434 10.8951C11.9623 10.8951 11.9811 10.8951 12 10.8951C15.1354 10.8951 18.2812 10.3527 20 9.1875V12.8036C20 14.2199 16.4167 15.375 12 15.375C10.4762 15.375 9.05168 15.2375 7.83924 14.9992ZM4.2125 14.949C4.13945 14.9045 4.06859 14.859 4 14.8125V15.1615L4.2125 14.949ZM4.06974 18.7687L6.86828 15.9702C8.40173 16.3419 10.2026 16.5201 12 16.5201C15.1354 16.5201 18.2812 15.9777 20 14.8125V18.4286C20 19.8449 16.4167 21 12 21C7.94282 21 4.58886 20.0253 4.06974 18.7687ZM13.1133 9.72521L18.6804 4.15808C19.5144 4.56407 20 5.05006 20 5.57143V7.17857C20 8.47373 17.0034 9.55049 13.1133 9.72521Z" fill="var(--link-icon)"/>\n</svg>\n'}),Ce=new class{toggleEnableParallelProcessing(){this.enableParallelProcessing=!this.enableParallelProcessing}constructor(){this.enableData={pipelineImport:!0,pipeline:!1,cacheExport:!1,cacheImport:!1,pipelineSelected:!1,selectionExport:!0},this.remoteServers=[],this.enableParallelProcessing=!1,(0,ce.makeAutoObservable)(this)}},Ee=S().div`
  display: block;

  .cache-size-wrapper {
    display: block;
    width: 250px;

    margin: 0 auto;
  }

  .cache-size-info {
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;

    width: 100%;
    height: 43px;
    margin: 18px 0;
    padding: 15px 30px;

    border: 1px solid var(--control-border);

    & > p {
      color: var(--control-text);
      font-weight: bold;
      font-size: 11px;
      font-style: normal;
      line-height: 13px;
    }
  }

  .progress-container {
    display: block;
    margin: 40px 55px 20px;
    text-align: right;

    & > div:first-of-type {
      font-weight: 400;
      font-size: 12px;
      line-height: 15px;
      color: #999;
      margin-bottom: 12px;
    }

    p {
      margin: 12px 0 0;
      font-weight: 400;
      font-size: 13px;
      line-height: 15px;
      color: #999;
      text-align: left;
    }
  }

  .progress-bar {
    height: 14px;
    border-radius: 7px;
    background-color: var(--section-message-info-background);
    .MuiLinearProgress-bar {
      background-color: var(--link-color);
    }
  }

  .download-cache-info {
    margin-top: 20px;
  }

  .receiving {
    margin: 28px 0;
    text-align: center;
    font-weight: 400;
    font-size: 13px;
    line-height: 15px;
    color: #999;
  }
  .receiving p {
    margin: 12px 0 0;
  }

  .error-on-name {
    position: absolute;
    display: flex;
    /* identical to box height */
    height: 13px;
    /* identical to box height */

    color: #ff0000;
    font-weight: normal;
    font-size: 10px;
    font-style: normal;
    line-height: 12px;
  }
  .error-on-name .SVGInline {
    display: flex;
    align-items: center;
  }
  .error-on-name .SVGInline svg {
    width: 12px;
    padding-right: 6px;
  }

  .download-cache-name-input {
    box-sizing: border-box;
    width: 100%;
    height: 30px;

    margin-bottom: 4px;
    padding-top: 9px;
    padding-bottom: 8px;
    padding-left: 12px;
    border: 1px solid var(--control-border);
    /* identical to box height */

    color: var(--control-text);
    font-weight: normal;
    font-size: 11px;

    font-style: normal;
    line-height: 13px;

    background: var(--background-base);
  }

  .download-file-name {
    padding-bottom: 5px;

    color: var(--link-color);
    font-weight: bold;
    font-size: 11px;
    font-style: normal;
    line-height: 13px;
    /* identical to box height */
    text-align: left;
  }

  .download-file-btn {
    width: 60px;
    height: 16px;
    margin-top: 30px;
    margin-bottom: 42px;
    padding: 12px 30px;
    border: 1px solid var(--link-color);

    color: #ffffff;

    background: #6c79f9;
  }

  .extension-placeholder {
    padding-left: 2px;

    color: var(--control-placeholder);
    font-weight: bold;
    font-size: 13px;
    font-style: normal;
    line-height: 15px;
  }

  .download-file-info {
    display: flex;
    align-items: center;
  }
  .waiting-http-request {
    height: 40px;
    margin: 65px auto;
    color: #999;
    text-align: center;
  }
`;var we,ye=n(91241);!function(e){e.PipelineUpdated="pipeline:updated",e.ParametersUpdated="parameters:updated",e.PanelKernelInitialized="kernel:info",e.ExportCacheProgress="export:cache",e.ImportCacheProgress="import:cache",e.HPOExecutionTrial="HPO:trial_executed",e.HPOCompleted="HPO:completed",e.HPOEarlyStopping="HPO:early_stopped",e.HPOCanceling="HPO:canceled",e.HPOInputError="HPO:input_error",e.HPOTargetValueError="HPO:target_value",e.HPOError="HPO:error"}(we||(we={}));const ke=class{constructor(){this.isFailed=!1,this.handlers={}}static getInstance(){return this.instance||(this.instance=new this)}addEvent(e){this.handlers[e]=[]}removeEvent(e){delete this.handlers[e]}connect(e){return this.url=e,this.ws=new WebSocket(e),this.ws.onmessage=this.onmessage.bind(this),this.ws.onclose=()=>{setTimeout((()=>{this.isFailed=!0,this.connect(this.url)}),1e3)},new Promise(((e,t)=>{this.ws.onopen=()=>{this.isFailed&&(this.updatePipelinePanelKernel?this.updatePipelinePanelKernel():console.error("updatePipelinePanelKernel doesn't exist. Please set function from PipelinePanel"),this.isFailed=!1),e()},this.ws.onerror=()=>{t()}}))}onmessage(e){const t=JSON.parse(e.data);t.procedure&&this.emitListener(t.procedure,[t])}emitListener(e,t){if(this.handlers[e])for(let n=0;n<this.handlers[e].length;n++)try{this.handlers[e][n].apply(null,t)}catch(t){console.error("event error: ["+e+"] "+t.toString()),console.error(t)}}addListener(e,t){this.handlers[e]&&this.handlers[e].push(t)}removeListener(e,t){if(this.handlers[e]){const n=this.handlers[e];if(n)for(let e=0;e<n.length;e++)if(n[e]===t)return void n.splice(e,1)}}setUpdatePipelinePanelKernel(e){this.updatePipelinePanelKernel=e}}.getInstance();var Le=n(88416),_e=n.n(Le);class Me extends a.Component{render(){const e=this.props,{className:t,svg:n}=e,a=function(e,t){var n={};for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&t.indexOf(a)<0&&(n[a]=e[a]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(a=Object.getOwnPropertySymbols(e);r<a.length;r++)t.indexOf(a[r])<0&&Object.prototype.propertyIsEnumerable.call(e,a[r])&&(n[a[r]]=e[a[r]])}return n}(e,["className","svg"]),l=n;return r().createElement("span",Object.assign(Object.assign({},a),{className:`SVGInline ${t}`,dangerouslySetInnerHTML:{__html:l}}))}}Me.idCount=0;const Se=Me,Ne='<?xml version="1.0" encoding="utf-8"?>\n\x3c!-- Generator: Adobe Illustrator 26.0.1, SVG Export Plug-In . SVG Version: 6.00 Build 0)  --\x3e\n<svg version="1.1" id="layer_1" xmlns="http://www.w3.org/2000/svg" x="0px"\n     y="0px" viewBox="0 0 18 18" style="enable-background:new 0 0 18 18;" xml:space="preserve">\n    <path style="fill:#f44336" d="M9,0C4.03,0,0,4.03,0,9c0,4.97,4.03,9,9,9s9-4.03,9-9C18,4.03,13.97,0,9,0z M10.07,4.68l-0.25,5.83h-1.6\n\tL7.96,4.68H10.07z M9.78,13.04C9.57,13.23,9.31,13.32,9,13.32s-0.57-0.09-0.78-0.28S7.9,12.62,7.9,12.33s0.1-0.53,0.31-0.71\n\tS8.69,11.34,9,11.34s0.57,0.09,0.78,0.28s0.31,0.42,0.31,0.71S9.99,12.85,9.78,13.04z"/>\n</svg>\n',Ae=e=>{const t=new RegExp(/^[^\\/:*"?<>|]+$/),[n,l,o]=((e="",t=1/0)=>{const[n,r]=(0,a.useState)(e);return[n,(0,a.useCallback)((e=>{e.target.value.length<=t&&r(e.target.value)}),[]),r]})(""),[i,s]=(0,a.useState)(""),[c,d]=(0,a.useState)(""),[p,m]=(0,a.useState)(e.downloadData),{originType:u}=(0,a.useContext)(Ue);(0,a.useEffect)((()=>{if(e.fileOriginName&&e.downloadData){let t=decodeURI(e.fileOriginName[0]);-1!==["selection-pipeline","selection-pipelines","python","python-selection"].indexOf(u)&&(t+="-component"),o(t),s(e.fileOriginName[1]),m(e.downloadData)}}),[e.fileOriginName,e.downloadData,u]);const h=(0,a.useCallback)((async()=>{p&&""===c&&(_e()(await p,n+i),e.closeDialog())}),[n,c,p]);return(0,a.useEffect)((()=>{n.length<1?d("Required"):t.test(n.split(i)[0])?/^[.]/.test(n.split(i)[0])?d('Invalid (File name can\'t begin with a dot ".")'):d(""):d('Invalid(\\ / : * " ? < > |)')}),[n,i]),r().createElement(r().Fragment,null,r().createElement("section",{className:"download-cache-info"},r().createElement("div",{className:"download-cache-name"},r().createElement("p",{className:"download-file-name"},"File Name"),r().createElement("div",{className:"download-file-info"},r().createElement("input",{className:"download-cache-name-input",value:n,onChange:e=>l(e)}),r().createElement("p",{className:"extension-placeholder"},i)),""!==c&&r().createElement("div",{className:"error-on-name"},r().createElement(Se,{svg:Ne}),r().createElement("p",null,c)))),r().createElement("menu",{className:"download-cancel-container"},r().createElement("button",{onClick:()=>e.closeDialog()},"Cancel"),r().createElement("button",{className:"primary",onClick:h,disabled:0===n.length},-1!==Ge.indexOf(u)?"Save":"Export")))},Ie=r().createElement("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("circle",{cx:"10",cy:"10",r:"9",fill:"none",stroke:"var(--feedback-info)",strokeWidth:"2",strokeLinecap:"round"},r().createElement("animateTransform",{attributeName:"transform",attributeType:"XML",type:"rotate",from:"0 10 10",to:"360 10 10",dur:"2s",repeatCount:"indefinite"}),r().createElement("animate",{attributeName:"stroke-dasharray",attributeType:"XML",values:"1, 55.5; 40, 55.5; 40, 55.5",dur:"1.5s",repeatCount:"indefinite"}),r().createElement("animate",{attributeName:"stroke-dashoffset",attributeType:"XML",values:"0; -15.5; -55.5",dur:"1.5s",repeatCount:"indefinite"}))),Oe=r().createElement("svg",{width:"16",height:"12",viewBox:"0 0 16 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M0.579102 1C0.579102 0.447715 1.02682 0 1.5791 0H5.38096H6.6628C6.95723 0 7.2367 0.129755 7.42671 0.354673L8.42809 1.54006C8.6181 1.76498 8.89757 1.89474 9.192 1.89474H14.4212C14.9735 1.89474 15.4212 2.34245 15.4212 2.89474V11C15.4212 11.5523 14.9735 12 14.4212 12H1.5791C1.02682 12 0.579102 11.5523 0.579102 11V1Z",fill:"url(#paint0_linear_9991_7217)"}),r().createElement("defs",null,r().createElement("linearGradient",{id:"paint0_linear_9991_7217",x1:"0.579102",y1:"5.86363",x2:"15.4212",y2:"5.86363",gradientUnits:"userSpaceOnUse"},r().createElement("stop",{stopColor:"#6C79F9"}),r().createElement("stop",{offset:"1",stopColor:"#AA7BF6"})))),Pe=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"17",viewBox:"0 0 16 17",fill:"none"},r().createElement("path",{d:"M2.66659 13.9333C2.29992 13.9333 1.98603 13.8027 1.72492 13.5416C1.46381 13.2805 1.33325 12.9666 1.33325 12.5999V4.59993C1.33325 4.23327 1.46381 3.91938 1.72492 3.65827C1.98603 3.39716 2.29992 3.2666 2.66659 3.2666H6.66658L7.99992 4.59993H13.3333C13.6999 4.59993 14.0138 4.73049 14.2749 4.9916C14.536 5.25271 14.6666 5.5666 14.6666 5.93327H7.44992L6.11658 4.59993H2.66659V12.5999L4.26659 7.2666H15.6666L13.9499 12.9833C13.861 13.2722 13.6971 13.5027 13.4583 13.6749C13.2194 13.8472 12.9555 13.9333 12.6666 13.9333H2.66659ZM4.06659 12.5999H12.6666L13.8666 8.59994H5.26659L4.06659 12.5999Z",fill:"white"})),Te=r().createElement("svg",{width:"15",height:"15",viewBox:"0 0 21 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M10.8421 14.4479L15.0705 17L13.9484 12.19L17.6842 8.95368L12.7647 8.53632L10.8421 4L8.91947 8.53632L4 8.95368L7.73579 12.19L6.61368 17L10.8421 14.4479Z",fill:"#FFA800"})),Fe=(r().createElement("svg",{width:"26",height:"26",viewBox:"0 0 26 26",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M11.9306 6.48705C12.409 5.6686 13.5918 5.6686 14.0702 6.48705L21.8294 19.7622C22.3122 20.5883 21.7164 21.6266 20.7596 21.6266H5.2412C4.28439 21.6266 3.6886 20.5883 4.17142 19.7623L11.9306 6.48705ZM11.7595 11.7153C11.7595 11.2013 12.1762 10.7847 12.6901 10.7847C13.2041 10.7847 13.6207 11.2013 13.6207 11.7153V15.9821C13.6207 16.4961 13.2041 16.9127 12.6901 16.9127C12.1762 16.9127 11.7595 16.4961 11.7595 15.9821V11.7153ZM12.6899 19.9768C13.2038 19.9768 13.6205 19.5651 13.6205 19.0572C13.6205 18.5494 13.2038 18.1376 12.6899 18.1376C12.176 18.1376 11.7593 18.5494 11.7593 19.0572C11.7593 19.5651 12.176 19.9768 12.6899 19.9768Z",fill:"#DBA948"})),r().createElement("svg",{width:"12",height:"12",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("g",{id:"surface1"},r().createElement("circle",{cx:"6",cy:"6",r:"6",fill:"#4AC44C"}),r().createElement("path",{d:"M 7.824219 4.140625 C 7.910156 4.058594 8.023438 4.011719 8.144531 4.015625 C 8.261719 4.015625 8.378906 4.0625 8.460938 4.144531 C 8.546875 4.230469 8.597656 4.34375 8.601562 4.460938 C 8.601562 4.582031 8.558594 4.699219 8.480469 4.785156 L 6.03125 7.847656 C 5.988281 7.894531 5.9375 7.929688 5.882812 7.953125 C 5.824219 7.980469 5.765625 7.992188 5.703125 7.996094 C 5.640625 7.996094 5.578125 7.984375 5.519531 7.960938 C 5.464844 7.9375 5.410156 7.902344 5.367188 7.859375 L 3.746094 6.234375 C 3.699219 6.195312 3.664062 6.144531 3.636719 6.085938 C 3.613281 6.03125 3.597656 5.96875 3.597656 5.90625 C 3.597656 5.84375 3.609375 5.785156 3.632812 5.726562 C 3.65625 5.667969 3.6875 5.617188 3.734375 5.574219 C 3.777344 5.53125 3.828125 5.496094 3.886719 5.472656 C 3.941406 5.449219 4.003906 5.4375 4.066406 5.4375 C 4.128906 5.441406 4.1875 5.453125 4.246094 5.480469 C 4.300781 5.503906 4.351562 5.539062 4.394531 5.585938 L 5.679688 6.871094 L 7.8125 4.15625 C 7.816406 4.148438 7.820312 4.144531 7.824219 4.140625 Z M 7.824219 4.140625 ",fill:"white"}))),r().createElement("svg",{width:"12",height:"12",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M6 0C2.7 0 0 2.7 0 6C0 9.3 2.7 12 6 12C9.3 12 12 9.3 12 6C12 2.7 9.3 0 6 0ZM5.64 2.94H6.36C6.54 2.94 6.66 3.06 6.66 3.24L6.54 6.96C6.54 7.14 6.42 7.26 6.24 7.26H5.76C5.58 7.26 5.46 7.14 5.46 6.96L5.34 3.24C5.34 3.06 5.46 2.94 5.64 2.94ZM6.48 9.06C6.36 9.18 6.18 9.24 6 9.24C5.82 9.24 5.64 9.18 5.52 9.06C5.4 8.94 5.34 8.76 5.34 8.58C5.34 8.4 5.4 8.22 5.52 8.1C5.64 7.98 5.82 7.92 6 7.92C6.18 7.92 6.36 7.98 6.48 8.1C6.6 8.22 6.66 8.4 6.66 8.58C6.72 8.82 6.66 8.94 6.48 9.06Z",fill:"#F44336"}))),Ve=r().createElement("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M3.81827 5.64639C3.91203 5.55266 4.03919 5.5 4.17177 5.5C4.30435 5.5 4.4315 5.55266 4.52527 5.64639L7.00027 8.12139L9.47527 5.64639C9.56957 5.55531 9.69587 5.50492 9.82697 5.50606C9.95807 5.5072 10.0835 5.55978 10.1762 5.65248C10.2689 5.74519 10.3215 5.87059 10.3226 6.00169C10.3237 6.13279 10.2733 6.25909 10.1823 6.35339L7.35377 9.18189C7.26 9.27563 7.13285 9.32829 7.00027 9.32829C6.86769 9.32829 6.74053 9.27563 6.64677 9.18189L3.81827 6.35339C3.72453 6.25963 3.67188 6.13248 3.67188 5.99989C3.67188 5.86731 3.72453 5.74016 3.81827 5.64639Z",fill:"#9291A1"})),He=r().createElement("svg",{focusable:"false","aria-hidden":"true",width:"28",height:"28",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"m7 10 5 5 5-5z",fill:"var(--text-secondary)"})),Re=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"18",height:"18",viewBox:"0 0 18 18",fill:"none"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M11.1222 11.1222C12.6951 9.54934 12.6951 6.99919 11.1222 5.42631C9.54934 3.85342 6.99919 3.85342 5.42631 5.42631C3.85342 6.99919 3.85342 9.54934 5.42631 11.1222C6.99919 12.6951 9.54934 12.6951 11.1222 11.1222ZM12.0037 12.0037C14.0635 9.94401 14.0635 6.60453 12.0037 4.5448C9.94401 2.48507 6.60453 2.48507 4.5448 4.5448C2.48507 6.60453 2.48507 9.94401 4.5448 12.0037C6.60453 14.0635 9.94401 14.0635 12.0037 12.0037Z",fill:"#77758A"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M11.2237 11.2236C11.4671 10.9802 11.8618 10.9802 12.1052 11.2236L14.8176 13.9359C15.061 14.1793 15.061 14.574 14.8176 14.8174C14.5742 15.0609 14.1795 15.0609 13.9361 14.8174L11.2237 12.1051C10.9803 11.8617 10.9803 11.467 11.2237 11.2236Z",fill:"#77758A"}));function ze(e,t,n){return r().cloneElement(e,{width:t,height:n||t})}const Ze=["KB","MB","GB"],Be=(e,t)=>{const n=Math.round(e/1024);let a="";return 1024<=n?(a=Be(n,t+1),a):n.toString()+Ze[t]},je=({closeDialog:e})=>{const[t,n]=(0,a.useState)(0),[l,o]=(0,a.useState)(""),[i,s]=(0,a.useState)(),[c,d]=(0,a.useState)(),[p,m]=(0,a.useState)(0),{exportData:g,exportType:v}=(0,a.useContext)(Ue);(0,a.useEffect)((()=>{h.get(`mrx-link/info/cache?kernel_id=${g.kernelId}`).then((e=>{o(Be(parseInt(e.data.cache_size.replace("B",""),10),0))})).catch((t=>{e(),u.error("Failed to load cache size")}))}),[]);const f=(0,a.useCallback)((()=>{ke.addListener(we.ExportCacheProgress,x),n(1),h.get(`mrx-link/${v}/export?ipynb_name=${g.pathName}&kernel_id=${g.kernelId}`,{responseType:"blob"}).then((async e=>{n(2);const t=await e,a=await new Response(t.data).blob(),r=ge(t.headers["content-disposition"].split("filename=")[1]);s(a),d(r),setTimeout((()=>{n(3)}),800),ke.removeListener(we.ExportCacheProgress,x)})).catch((t=>{throw e(),u.error("Failed to export cache"),ke.removeListener(we.ExportCacheProgress,x),t}))}),[]),x=(0,a.useCallback)((t=>{"failed"!==t.msg.status?m(parseInt(t.msg.progress,10)):"failed"===t.msg.status&&(e(),u.error("Fail to export "+v))}),[]);return r().createElement(r().Fragment,null,0===t&&r().createElement(r().Fragment,null,r().createElement("section",{className:"cache-size-wrapper"},r().createElement("div",{className:"cache-size-info"},r().createElement("p",null,"Estimate Size"),r().createElement("p",null,l))),r().createElement("menu",null,r().createElement("button",{onClick:()=>e()},"Cancel"),r().createElement("button",{className:"primary",onClick:f},"Export"))),1===t&&r().createElement("section",null,r().createElement("div",{className:"progress-container"},r().createElement("div",null,p,"%"),r().createElement(ye.A,{variant:"determinate",value:p,className:"progress-bar"}),r().createElement("p",null,"Compressing cache…"))),2===t&&r().createElement("section",{className:"receiving"},Ie,r().createElement("p",null,"Making a cache file...")),3===t&&r().createElement(Ae,{fileOriginName:c,downloadData:i,closeDialog:e}))};var De=n(78717);const We=({closeDialog:e})=>{const[t,n]=(0,a.useState)(),[l,o]=(0,a.useState)(),[i,s]=(0,a.useState)(!0),{exportData:c,exportType:d}=(0,a.useContext)(Ue);return(0,a.useEffect)((()=>{var t;const a=`mrx-link/${d}/export`,r=new URLSearchParams;r.append("ipynb_name",c.pathName),r.append("kernel_id",c.kernelId),null===(t=c.cellId)||void 0===t||t.forEach((e=>r.append("cell_id",e)));const l=`${a}?${r.toString()}`;h.get(l,{responseType:"blob"}).then((async e=>{const t=await e,a=await new Response(t.data).blob(),r=ge(t.headers["content-disposition"].split("filename=")[1]);s(!1),n(a),o(r)})).catch((t=>{throw console.error(t),e(),u.error("Failed to export the file."),t}))}),[]),t?r().createElement(Ae,{fileOriginName:l,downloadData:t,closeDialog:e}):i?r().createElement("section",{className:"waiting-http-request"},r().createElement(De.A,null),r().createElement("br",null),"Please wait..."):r().createElement(r().Fragment,null,r().createElement("section",null,"An error occurred while exporting the file. Please try again later."),r().createElement("menu",null,r().createElement("button",{onClick:()=>e()},"Cancel")))},Ue=(0,a.createContext)({exportData:{cellId:[],pathName:"",kernelId:""},exportType:"",originType:""}),$e={pipeline:"Kubeflow Pipeline","link-pipeline":"Link Pipeline",cache:"Cache","selection-pipelines":"Link Components","selection-pipeline":"Link Component",python:"Save as an Executable Script","python-selection":"Save as an Executable Script","python-all":"Save as an Executable Script"},Ge=["python","python-all","python-selection"],qe=async(e,t,n)=>{var a,l;const o=ue(e,!0),i=["link-pipeline","selection-pipelines","selection-pipeline"],s=null===(l=null===(a=e.currentWidget)||void 0===a?void 0:a.sessionContext.session)||void 0===l?void 0:l.kernel,c=t;if(s){let a;await e.currentWidget.context.save(),-1!==[...i,...Ge].indexOf(t)?(t=-1!==Ge.indexOf(t)?t:"link-pipeline",a={cellId:n.filter((e=>e)),pathName:o||"",kernelId:s.id}):a="cache"!==t?{cellId:[],pathName:o||"",kernelId:s.id}:{kernelId:s.id,pathName:o||""},te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,le,-1!==Ge.indexOf(t)?"Save as an Executable Script":"Export "+$e[t]),r().createElement(Ue.Provider,{value:{exportData:a,exportType:-1!==Ge.indexOf(t)?"python":t,originType:c}},r().createElement(Ee,null,"cache"===t?r().createElement(je,{closeDialog:e}):r().createElement(We,{closeDialog:e}))))))}},Ke=["KB","MB","GB"],Ye=(e,t)=>{const n=Math.round(e/1024);let a="";return 1024<=n?(a=Ye(n,t+1),a):n.toString()+Ke[t]},Xe=({app:e,tracker:t,kernelId:n,fileData:l,closeDialog:s})=>{const[c,d]=(0,a.useState)(0),[p,m]=(0,a.useState)(0),u=e=>{"failed"!==e.msg.status&&d(parseInt(e.msg.progress,10))};return(0,a.useEffect)((()=>(ke.addListener(we.ImportCacheProgress,u),()=>{ke.removeListener(we.ImportCacheProgress,u)})),[]),r().createElement(r().Fragment,null,0===p&&r().createElement(r().Fragment,null,r().createElement("section",null,"Do you want to import cache? (It cannot be stopped until it has been completed.)"),r().createElement("section",{className:"cache-size-wrapper"},r().createElement("div",{className:"cache-size-info"},r().createElement("p",null,"Estimate Size"),r().createElement("p",null,Ye(parseInt(l.size,10),0)))),r().createElement("menu",null,r().createElement("button",{onClick:()=>s()},"Cancel"),r().createElement("button",{className:"primary",onClick:()=>{m(1),(async()=>{const a=new FormData;a.append("kernel_id",n),a.append("cache_archive",l);try{const n=await async function(e){const t=i.ServerConnection.makeSettings(),n=o.URLExt.join(t.baseUrl,"mrx-link/cache/import"),a={method:"POST",body:e};let r;try{r=await i.ServerConnection.makeRequest(n,a,t)}catch(e){throw new i.ServerConnection.NetworkError(e)}let l=await r;const s=await r.text();if(l.length>0)try{l=JSON.parse(l)}catch(e){console.error("Not a JSON response body.",r)}return s}(a),l=JSON.parse(n);"Success."!==l.message?(s(),te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,oe," Import Cache failed"),r().createElement("section",null,l.message),r().createElement("menu",null,r().createElement("button",{onClick:()=>e()},"Close")))))):await async function(e,t,n,a){var r;if(t.currentWidget){const e=await(null===(r=t.currentWidget.sessionContext.session)||void 0===r?void 0:r.kernel),n=`%mrxlink_cache_dir -s ${a}`;null==e||e.requestExecute({code:n,store_history:!1},!1,{})}}(0,t,e.commands,l.result),m(2)}catch(e){s(),te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,oe," Import Cache failed"),r().createElement("section",null,"Network error or cache file size exceeded maximum."),r().createElement("menu",null,r().createElement("button",{onClick:()=>e()},"Close")))))}})()}},"Import"))),1===p&&(c<1?r().createElement("section",{className:"receiving"},Ie,r().createElement("p",null,"Reading a cache file...")):r().createElement(r().Fragment,null,r().createElement("div",{className:"progress-container",style:{margin:"20px 50px"}},r().createElement("div",null,c,"%"),r().createElement(ye.A,{variant:"determinate",value:c,className:"progress-bar"}),r().createElement("p",null,"Decompressing cache…")))),2===p&&r().createElement(r().Fragment,null,r().createElement("section",null,"Successfully imported cache"),r().createElement("menu",null,r().createElement("button",{onClick:()=>s()},"Close"))))},Je=(e,t,n)=>{var a,l,o,i;const s=null===(l=null===(a=t.currentWidget)||void 0===a?void 0:a.sessionContext.session)||void 0===l?void 0:l.kernel;if(s)switch(n){case"cache":{const n=document.createElement("input");n.setAttribute("type","file"),n.id="upload-cache-hidden",n.accept=".gz",n.addEventListener("change",(a=>{const l=n.files||a.target.files;l&&te((n=>r().createElement(r().Fragment,null,r().createElement("h1",null,le," Import Cache"),r().createElement(Ee,null,r().createElement(Xe,{app:e,tracker:t,kernelId:s.id,fileData:l[0],closeDialog:n})))))})),null===(o=document.querySelector(".jp-NotebookPanel"))||void 0===o||o.append(n);const a=document.querySelector("#upload-cache-hidden");null==a||a.dispatchEvent(new MouseEvent("click")),null===(i=document.querySelector(".jp-NotebookPanel"))||void 0===i||i.removeChild(n);break}}};function Qe(e){return!(!e||"string"!=typeof e.component_type||"PipelineParameters"===e.component_type&&!function(e){if("PipelineParameters"!==e.component_type||!Array.isArray(e.cell_code))return!1;if(e.cell_code&&!Array.isArray(e.cell_code))return!1;const t=e.cell_code;for(let e=0;e<t.length;e++)if(!((n=t[e])&&"object"==typeof n&&n.name&&"string"==typeof n.name&&n.value&&"string"==typeof n.value))return!1;var n;return!0}(e)||"CodeCell"===e.component_type&&!function(e){if("CodeCell"!==e.component_type)return!1;if(!e.component_id||"string"!=typeof e.component_id)return!1;if(!e.component_name||"string"!=typeof e.component_name)return!1;if(e.parents_name&&!Array.isArray(e.parents_name))return!1;if(e.parents_name)for(let t=0;t<e.parents_name.length;t++)if("string"!=typeof e.parents_name[t])return!1;return!(!e.cell_code||"string"!=typeof e.cell_code)&&(!e.headercolor||"string"==typeof e.headercolor)}(e))}function et(e,t){const{commands:n}=e;async function a(n,a){const l=await n(a).catch((e=>{}));if(l)if("Success."===l.message)try{return void function(e,t,n,a){var l;if(t.currentWidget){const o=t.currentWidget.content,{model:i}=o,s=he(e,t);o.activeCellIndex=i.cells.length;const c=i.cells.length,d=[],p=i.getMetadata("canvas")||{parameters:[]},m=p.parameters||[],h=(null===(l=a.find((e=>"PipelineParameters"===e.component_type)))||void 0===l?void 0:l.cell_code)||[],g=h.map((e=>e.name)),v=m.map((e=>e.name));let f=g.concat(v).sort();f=f.filter(((e,t)=>e===f[t+1])),f.length>0?te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,oe," Pipeline Parameters Conflict"),r().createElement("section",null,"There are already pipeline parameters with the same name in this file. Are you sure to overwrite?"),r().createElement("section",null,`${f.length} duplicated`,": ",f.join(", ")),r().createElement("menu",null,r().createElement("button",{onClick:e},"Cancel"),r().createElement("button",{className:"primary",onClick:()=>{const t=h.concat(m).reduce(((e,t)=>(e.some((e=>e.name===t.name))||e.push(t),e)),[]);Object.assign(p,{parameters:[...t]}),i.deleteMetadata("canvas"),i.setMetadata("canvas",p),n.execute(Rt.dagParameters,t.map((e=>({name:e.name,value:e.value})))),e()}},"Overwrite"))))):(null==i||i.setMetadata("canvas",{parameters:h}),n.execute(Rt.dagParameters,h.map((e=>({name:e.name,value:e.value}))))),a.forEach((e=>{var t;if("PipelineParameters"===e.component_type)return;const n=i.cells.length,a=new X.CodeCellModel;a.sharedModel.setSource(e.cell_code),a.sharedModel.setMetadata("canvas",{name:e.component_name,parents:[],isComponent:!0,componentType:e.component_type,id:null,headerColor:e.headercolor,isImportedJustNow:!0}),i.sharedModel.insertCell(n,a.toJSON());const r=i.sharedModel.cells[n],l=r.getMetadata("canvas");s.includes(e.component_id)||i.sharedModel.cells[n].setMetadata("canvas",Object.assign(Object.assign({},l),{id:e.component_id})),d.push({id:null===(t=r.getMetadata("canvas"))||void 0===t?void 0:t.id,name:e.component_name})}));const x=function(e){var t;const n=null===(t=e.shell.currentWidget.model)||void 0===t?void 0:t.cells[Symbol.iterator]();return n?Array.from(n).map((e=>e.getMetadata("canvas"))):[]}(e);o.activeCellIndex=c,a.forEach((e=>{if("PipelineParameters"===e.component_type)return;const t=e.parents_name?function(e,t,n){return e.map((e=>{const a=t.filter((t=>t.name===e))[0].id;return{name:n.filter((e=>e.id===a))[0].name,id:a}}))}(e.parents_name,d,x):[],n=i.sharedModel.cells[o.activeCellIndex].getMetadata("canvas");i.sharedModel.cells[o.activeCellIndex++].setMetadata("canvas",Object.assign(Object.assign({},n),{parents:t}))})),o.mode="edit",pe.executeDagUpdateCommand(),u.success("Successfully imported pipeline")}}(e,t,e.commands,l.result)}catch(e){return function(e){try{if(!Array.isArray(e)||0===e.length)return!1;for(let t=0;t<e.length;t++)if(!Qe(e[t]))return!1;return!0}catch(e){return console.error(e),!1}}(l.result)?void u.error("Link can not open this file."):void u.error("Link can not open this file because this file is not a valid pipeline format.")}else u.error(l.message);else u.error("Link can not open this file.")}n.addCommand(Rt.canvasExport,{label:"Export Kubeflow Pipeline (.yaml)",isEnabled:()=>Ce.enableData.pipeline,execute:async e=>{t.currentWidget?qe(t,"pipeline"):alert("notebook file is empty")}}),n.addCommand(Rt.canvasImport,{label:"Import Kubeflow Pipeline (.yaml)",caption:"Import",isEnabled:()=>Ce.enableData.pipelineImport,execute:e=>{var t,n;const r=document.createElement("input");r.setAttribute("type","file"),r.id="upload-file-hidden",r.accept=".yaml",r.addEventListener("change",(e=>{const t=(r.files||e.target.files)[0],n=new FileReader;n.onload=function(e){var t;a(f,null===(t=e.target)||void 0===t?void 0:t.result)},n.readAsText(t)})),null===(t=document.querySelector(".jp-NotebookPanel"))||void 0===t||t.append(r);const l=document.querySelector("#upload-file-hidden");null==l||l.dispatchEvent(new MouseEvent("click")),null===(n=document.querySelector(".jp-NotebookPanel"))||void 0===n||n.removeChild(r)}}),n.addCommand(Rt.linkExport,{label:"Export Link Pipeline (.json)",isEnabled:()=>Ce.enableData.cacheImport,execute:async n=>{if(!t.currentWidget)return void alert("notebook file is empty");await t.currentWidget.context.save();const a=function(e,t){var n;const a=e.currentWidget;a&&t.shell.activateById(a.id);const r=null===(n=t.shell.currentWidget.model)||void 0===n?void 0:n.cells[Symbol.iterator]();if(!r)return[];return Array.from(r).map((e=>e.getMetadata("canvas").isComponent?e.getMetadata("canvas").id:void 0))}(t,e);qe(t,"link-pipeline",a)}}),n.addCommand(Rt.linkImport,{label:"Import Link Pipeline (.json)",caption:"Import",isEnabled:()=>Ce.enableData.pipelineImport,execute:e=>{var t,n;const r=document.createElement("input");r.setAttribute("type","file"),r.id="upload-file-hidden",r.accept=".json",r.addEventListener("change",(e=>{const t=(r.files||e.target.files)[0],n=new FileReader;n.onload=function(e){var t;a(x,null===(t=e.target)||void 0===t?void 0:t.result)},n.readAsText(t)})),null===(t=document.querySelector(".jp-NotebookPanel"))||void 0===t||t.append(r);const l=document.querySelector("#upload-file-hidden");null==l||l.dispatchEvent(new MouseEvent("click")),null===(n=document.querySelector(".jp-NotebookPanel"))||void 0===n||n.removeChild(r)}}),n.addCommand(Rt.cacheExport,{label:"Export Cache (.tar.gz)",isEnabled:()=>Ce.enableData.cacheExport,execute:async e=>{t.currentWidget?qe(t,"cache"):alert("notebook file is empty")}}),n.addCommand(Rt.cacheImport,{label:"Import Cache (.tar.gz)",isEnabled:()=>Ce.enableData.cacheImport,execute:async n=>{Je(e,t,"cache")}}),n.addCommand(Rt.exportPY,{label:"Save as an Executable Script (.py)",icon:e=>e.isNode?fe:void 0,isEnabled:()=>{var e;return!!(null===(e=di.currentWidget)||void 0===e?void 0:e.cells.isExistComponent)},execute:n=>{let a=[],r="";n.isNode?(r="python",a.push(n.nodeInfo.original.id)):(r="python-all",a=he(e,t)),qe(t,r,a)}})}var tt=n(60508),nt=n(53324),at=n.n(nt);class rt{constructor(){this._executionQueue=[]}static getInstance(){return this.instance||(this.instance=new rt),this.instance}enqueue(e){this._executionQueue.push(e)}dequeue(){return this._executionQueue.shift()}}const lt=rt.getInstance();var ot=n(66689);const it=(0,ot.signal)(void 0),st=(0,ot.signal)(void 0),ct=(0,ot.signal)(void 0),dt=(0,ot.signal)(void 0),pt=(0,ot.computed)((()=>it.value===ct.value&&void 0!==dt.value&&void 0!==mt.value[dt.value]&&"python"===mt.value[dt.value].language)),mt=(0,ot.signal)({});async function ut(e,t){const n=t.newValue;it.value=null==n?void 0:n.id,st.value=null==n?void 0:n.title.label}async function ht(e,t){var n,a;ct.value=null==t?void 0:t.id,await(null==t?void 0:t.sessionContext.ready),ct.value===(null==t?void 0:t.id)&&(dt.value=null===(a=null===(n=null==t?void 0:t.sessionContext.session)||void 0===n?void 0:n.kernel)||void 0===a?void 0:a.id,vt(t),void 0!==dt.value&&(null==t||t.sessionContext.statusChanged.connect(((e,t)=>ft(dt.value,"status",t))),null==t||t.sessionContext.connectionStatusChanged.connect(gt.bind(null,t)),ft(dt.value,"statusChangeConnected",!0)))}async function gt(e,t,n){var a,r;const l=null===(r=null===(a=null==e?void 0:e.sessionContext.session)||void 0===a?void 0:a.kernel)||void 0===r?void 0:r.id;if("connected"===n){if(void 0===dt.value&&it.value===e.id&&(dt.value=l),void 0===dt.value)return;b(dt.value).then((e=>{pe.setKernelComponents(e.kernelId,e.components)})),vt(e)}else if("disconnected"===n){if(xt(l,!1),it.value!==e.id)return;dt.value=void 0,ft(l,"language",void 0)}}async function vt(e){var t,n,a,r;const l=await(null===(n=null===(t=null==e?void 0:e.sessionContext.session)||void 0===t?void 0:t.kernel)||void 0===n?void 0:n.spec);ft(null===(r=null===(a=null==e?void 0:e.sessionContext.session)||void 0===a?void 0:a.kernel)||void 0===r?void 0:r.id,"language",null==l?void 0:l.language)}function ft(e,t,n){void 0!==e&&(void 0===mt.value[e]&&(mt.value[e]={statusChangeConnected:!1,magicCommandLoaded:!1}),mt.value[e][t]=n,mt.value=Object.assign({},mt.value))}function xt(e,t){ft(e,"magicCommandLoaded",t)}(0,ot.effect)((()=>{void 0!==dt.value&&b(dt.value).then((e=>{pe.setKernelComponents(e.kernelId,e.components)}))}));const bt=S().div`
  display: flex;
  flex-direction: column;

  .logo-title-about-ml {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 128px;
    padding: 20px 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    background: #f0f0f9;
  }
  .about-ml-header-info {
    display: flex;
    flex-direction: column;
    gap: 24px;
    margin: 148px 0 0 0;
    padding-top: 24px;
    font-size: 13px;
  }

  .header-info {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 0;
    margin: 0;
  }

  .header-info-label {
    color: var(--text-secondary);
    font-weight: 500;
    width: 64px;
  }

  .header-info-detail {
    flex: 1;
    color: var(--text-primary);
    font-weight: 400;
    margin: 0;
  }
`,Ct=()=>r().createElement("svg",{width:"214",height:"128",viewBox:"0 0 214 128",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("g",{clipPath:"url(#clip0_13_1250)"},r().createElement("path",{d:"M69.4234 76.8374L28.2292 71.086C25.2704 70.637 23.0845 68.089 23.0845 65.0798V40.606C23.0845 37.5969 25.2704 35.0488 28.2292 34.5998L69.4234 28.8484C72.346 28.4116 74.9667 30.6806 74.9667 33.6534V72.0324C74.9667 75.0052 72.346 77.2742 69.4234 76.8374Z",fill:"#6C79F9"}),r().createElement("path",{d:"M5.60895 51.1628L46.8031 56.9142C49.762 57.3632 51.9479 59.9112 51.9479 62.9204V87.3942C51.9479 90.4033 49.762 92.9514 46.8031 93.4004L5.60895 99.1396C2.68635 99.5886 0.0656738 97.3074 0.0656738 94.3468V55.9556C0.0656738 52.9829 2.68635 50.7139 5.60895 51.1507V51.1628Z",fill:"#9578FF"}),r().createElement("path",{d:"M46.8031 56.9141L23.072 53.6016V65.0922C23.072 68.1014 25.2579 70.6495 28.2168 71.0984L51.9478 74.4109V62.9203C51.9478 59.9111 49.7619 57.363 46.8031 56.9141Z",fill:"#5D5DF4"}),r().createElement("path",{d:"M134.228 52.7276C136.135 52.7276 137.682 51.1739 137.682 49.2574C137.682 47.3408 136.135 45.7871 134.228 45.7871C132.32 45.7871 130.774 47.3408 130.774 49.2574C130.774 51.1739 132.32 52.7276 134.228 52.7276Z",fill:"#2B2B3B"}),r().createElement("path",{d:"M165.808 59.0127C163.936 56.5859 160.977 55.0449 157.04 55.0449C153.103 55.0449 150.434 56.4403 148.55 58.685C148.55 57.1319 147.294 55.87 145.749 55.87C144.13 55.87 142.826 57.1805 142.826 58.8064V83.5956H148.55V66.7661C148.719 63.0168 151.159 60.044 155.482 60.044C159.806 60.044 162.415 63.2352 162.415 67.1787V83.5956H168.151V66.4749C168.151 63.6235 167.342 61.0269 165.808 59.0248V59.0127Z",fill:"#2B2B3B"}),r().createElement("path",{d:"M213.416 54.9721C213.211 54.9721 213.029 55.0934 212.945 55.2754L211.109 59.4009L209.274 55.2754C209.189 55.0934 209.008 54.9721 208.803 54.9721C208.513 54.9721 208.283 55.2026 208.283 55.4938V60.5294H209.104V56.6466L210.831 60.5294H211.399L213.114 56.6587V60.5294H213.935V55.4817C213.935 55.2026 213.706 54.96 213.416 54.96V54.9721Z",fill:"#2B2B3B"}),r().createElement("path",{d:"M206.906 54.9717H202.426C202.232 54.9717 202.087 55.1294 202.087 55.3114C202.087 55.4934 202.244 55.6512 202.426 55.6512H204.261V60.5168H205.082V55.6512H206.906C207.099 55.6512 207.244 55.4934 207.244 55.3114C207.244 55.1294 207.087 54.9717 206.906 54.9717Z",fill:"#2B2B3B"}),r().createElement("path",{d:"M106.028 78.7419V50.2883C106.028 48.6988 104.748 47.4126 103.154 47.4126C101.572 47.4126 100.292 48.6988 100.292 50.2883V83.5712H125.617V78.7419H106.028Z",fill:"#2B2B3B"}),r().createElement("path",{d:"M137.09 83.5836V58.7458C137.09 57.1563 135.809 55.8701 134.215 55.8701C132.633 55.8701 131.353 57.1563 131.353 58.7458V83.5836H137.09Z",fill:"#2B2B3B"}),r().createElement("path",{d:"M200.023 83.5712L185.699 69.9692L196.46 59.6434C197.511 58.6242 197.535 56.9376 196.52 55.882L196.496 55.8577C195.482 54.802 193.803 54.7778 192.752 55.797L179.637 68.4161V50.2883C179.637 48.6988 178.357 47.4126 176.775 47.4126C175.193 47.4126 173.912 48.6988 173.912 50.2883V83.5712H179.649V71.7044L192.148 83.559H200.047L200.023 83.5712Z",fill:"#2B2B3B"})),r().createElement("defs",null,r().createElement("clipPath",{id:"clip0_13_1250"},r().createElement("rect",{width:"213.869",height:"70.4",fill:"white",transform:"translate(0.0654297 28.7998)"})))),Et=e=>r().createElement(bt,null,r().createElement("div",{className:"logo-title-about-ml"},r().createElement(Ct,null)),r().createElement("div",{className:"about-ml-header-info"},r().createElement("div",{className:"header-info"},r().createElement("div",{className:"header-info-label"},"Version"),r().createElement("p",{className:"header-info-detail"},e.version)),r().createElement("div",{className:"header-info"},r().createElement("div",{className:"header-info-label"},"Build Date"),r().createElement("p",{className:"header-info-detail"},e.release_date))),r().createElement("menu",null,r().createElement("button",{className:"primary",onClick:e.closeDialog},"Close")));async function wt(){const{release_date:e,version:t}=await v(),n=new Date(e).toISOString().split("T")[0];te((e=>r().createElement(Et,{release_date:n,version:t,closeDialog:e})),{width:400})}var yt,kt,Lt,_t,Mt;!function(e){e.NAME="MRXCellMetadataHook_name",e.PARENTS="MRXCellMetadataHook_parents",e.IS_COMPONENT="MRXCellMetadataHook_isParent",e.ID="MRXCellMetadataHook_id",e.HEADER_COLOR="MRXCellMetadataHook_headerColor",e.COMPONENT_TYPE="MRXCellMetadataHook_componentType",e.DISKCACHE="MRXCellMetadataHook_diskcache"}(yt||(yt={})),function(e){e.PARAMS="MRXWidgetMetadataHook_params",e.COLOR_PALETTE="MRXWidgetMetadataHook_colorPalette"}(kt||(kt={})),function(e){e.UPDATE="MRXDAGManagerHook_update"}(Lt||(Lt={})),function(e){e.CURRENT="MRXWidgetManagerHook_currentChange"}(_t||(_t={})),function(e){e.ACTIVE_CELL="MRXWidgetHook_activeCellChange",e.KERNEL_CONNECTION_STATE="MRXWidgetHook_kernelConnectionState",e.TITLE="MRXWidgetHook_titleChange",e.COMPONENT_CHANGE="MRXWidgetHook_componentChange"}(Mt||(Mt={}));class St{_deepCopy(e){if(null===e||"object"!=typeof e)return e;const t=Array.isArray(e)?[]:{};for(const n of Object.keys(e))t[n]=this._deepCopy(e[n]);return t}}class Nt extends St{constructor(){super(...arguments),this._handlers=new Map}connect(e,...t){this._handlers.has(e)||this._handlers.set(e,[]),t.forEach((t=>{var n;return null===(n=this._handlers.get(e))||void 0===n?void 0:n.push(t)}))}disconnect(e,...t){const n=this._handlers.get(e);n&&t.forEach((t=>{this._handlers.set(e,n.filter((e=>e!==t)))}))}disconnectAll(){this._handlers.clear()}}class At extends Nt{constructor(e){super(),this._model=e}dispose(){super.disconnectAll()}_emitHook(e){const t=this._handlers.get(e);t&&t.forEach((e=>{e(this.toObject())}))}toObject(){var e;const t=null===(e=this._model)||void 0===e?void 0:e.getMetadata("canvas");return this._deepCopy(t||{})}merge(e){var t;null===(t=this._model)||void 0===t||t.setMetadata("canvas",Object.assign(this.toObject(),e))}}class It extends At{constructor(e,t,n){var a;super(e),this._parents=[],this._widget=new Ft(t,n),null===(a=this._model)||void 0===a||a.metadataChanged.connect(((e,t)=>{if("canvas"!==t.key)return;this.initialize();const n=t.oldValue,a=t.newValue;n&&(n.id||this._emitHook(yt.ID),n.id&&n.id!==a.id&&this._emitHook(yt.ID),n.name||this._emitHook(yt.NAME),n.name&&n.name!==a.name&&this._emitHook(yt.NAME),n.isComponent||this._emitHook(yt.IS_COMPONENT),n.isComponent&&n.isComponent!==a.isComponent&&this._emitHook(yt.IS_COMPONENT),n.componentType||this._emitHook(yt.COMPONENT_TYPE),n.componentType&&n.componentType!==a.componentType&&this._emitHook(yt.COMPONENT_TYPE),n.parents||this._emitHook(yt.PARENTS),(n.parents&&n.parents.length!==a.parents.length||n.parents&&n.parents.length===a.parents.length&&JSON.stringify(n.parents)!==JSON.stringify(a.parents))&&this._emitHook(yt.PARENTS),n.headerColor||this._emitHook(yt.HEADER_COLOR),n.headerColor&&n.headerColor!==a.headerColor&&this._emitHook(yt.HEADER_COLOR),n.diskcache&&n.diskcache!==a.diskcache&&this._emitHook(yt.DISKCACHE))})),this.initialize()}initialize(){const e=this.toObject();Object.keys(e).length?this._isEmpty=!1:this._isEmpty=!0;const{id:t,name:n,parents:a,isComponent:r,componentType:l,copiedOriginId:o,headerColor:i,diskcache:s}=e;this._id=t,this._name=n,this._parents=a,this._isComponent=r,this._componentType=l,this._copiedOriginId=o,this._headerColor=i,this._diskcache=s}get isEmpty(){return this._isEmpty}get id(){return this._id}set id(e){this._id=e,this.merge({id:e})}get parents(){return this._parents}set parents(e){this._parents=e,this.merge({parents:e})}get name(){return this._name}set name(e){this._widget&&this._widget.cells.each((t=>{t.parents=t.parents.map((t=>{if(this.id===t.id){if(!e)return null;t.id=this.id,t.name=e}return t})).filter((e=>null!=e))})),this._name=e,this.merge({name:e})}get isComponent(){return this._isComponent}set isComponent(e){this._widget&&!e&&this._widget.cells.each((e=>{e.parents=e.parents.map((e=>this.id===e.id?null:e)).filter((e=>null!=e))})),this._isComponent=e,this.merge({isComponent:e})}get componentType(){return this._componentType}set componentType(e){this._componentType=e,this.merge({componentType:e})}get copiedOriginId(){return this._copiedOriginId}set copiedOriginId(e){this._copiedOriginId=e,this.merge({copiedOriginId:e})}get headerColor(){return this._headerColor}set headerColor(e){this._headerColor=e,this.merge({headerColor:e})}get diskcache(){return this._diskcache}set diskcache(e){this._diskcache=e,this.merge({diskcache:e})}}const Ot=new class{constructor(){this.metadata={},(0,ce.makeAutoObservable)(this)}create(e,t,n){return this.metadata[n.id]||(this.metadata[n.id]={}),this.metadata[n.id][e.id]=new It(e,t,n),this.metadata[n.id][e.id]}get(e,t){var n;return null===(n=this.metadata[t])||void 0===n?void 0:n[e]}getOrCreate(e,t,n){var a;return null!==(a=this.get(e.id,n.id))&&void 0!==a?a:this.create(e,t,n)}clearMetadataByPanelId(e){this.metadata[e]&&delete this.metadata[e]}};class Pt{constructor(e,t){this._panel=e,this._labShell=t}get activeCellMetadata(){const e=this._panel.content.activeCell;return e?Ot.getOrCreate(e.model,this._labShell,this._panel):null}get activeCell(){return this._panel.content.activeCell}get activeCellIndex(){var e;if(!this._panel||!this._panel.model)return null;const t=this._panel.content.activeCell;if(t){const n=Ot.getOrCreate(t.model,this._labShell,this._panel),a=null===(e=this._panel.model)||void 0===e?void 0:e.cells[Symbol.iterator]();let r=0;for(;;){const e=null==a?void 0:a.next();if(!e||!e.value)break;const t=Ot.getOrCreate(e.value,this._labShell,this._panel);if(n.id===t.id)break;r+=1}return r}return null}get codeCellCount(){var e;if(!this._panel.model)return null;const t=null===(e=this._panel.model)||void 0===e?void 0:e.cells[Symbol.iterator]();let n=0;for(;;){const e=null==t?void 0:t.next();if(!e||!e.value)break;"text/x-ipython"===e.value.mimeType&&(n+=1)}return n}get cellCount(){var e;return(null===(e=this._panel.model)||void 0===e?void 0:e.cells.length)||0}get componentCount(){var e;if(!this._panel.model)return null;const t=null===(e=this._panel)||void 0===e?void 0:e.model.cells[Symbol.iterator]();let n=0;for(;;){const e=null==t?void 0:t.next();if(!e||!e.value)break;"text/x-ipython"===e.value.mimeType&&e.value.getMetadata("canvas").isComponent&&(n+=1)}return n}get isExistComponent(){return!!this.componentCount}_getCell(e){return this._panel.content.widgets.find((t=>t.model===e))}each(e){var t;const n=null===(t=this._panel.model)||void 0===t?void 0:t.cells[Symbol.iterator]();for(;;){const t=null==n?void 0:n.next();if(!t||!t.value)break;const a=t.value;e(Ot.getOrCreate(a,this._labShell,this._panel),a,this._getCell(a))}}filter(e){var t;if(!this._panel||!this._panel.model)return[];const n=null===(t=this._panel.model)||void 0===t?void 0:t.cells[Symbol.iterator](),a=[];for(;;){const t=null==n?void 0:n.next();if(!t||!t.value)break;const r=Ot.getOrCreate(t.value,this._labShell,this._panel),l=this._getCell(t.value);e(r,t.value,l)&&a.push({metadata:r,cellModel:t.value,cell:l})}return a}map(e){var t;if(!this._panel||!this._panel.model)return[];const n=null===(t=this._panel.model)||void 0===t?void 0:t.cells[Symbol.iterator](),a=[];for(;;){const t=null==n?void 0:n.next();if(!t||!t.value)break;a.push(e(Ot.getOrCreate(t.value,this._labShell,this._panel),t.value,this._getCell(t.value)))}return a}getCellMetadataByID(e){if(!this._panel||!this._panel.model)return null;const t=this._panel.model.cells[Symbol.iterator]();let n=null;for(;;){const a=t.next();if(!a||!a.value)break;const r=null==a?void 0:a.value.getMetadata("canvas");if(r&&e===r.id){n=Ot.getOrCreate(a.value,this._labShell,this._panel);break}}return n}getCellByID(e){var t;if(!this._panel||!this._panel.model)return null;const n=null===(t=this._panel.model)||void 0===t?void 0:t.cells[Symbol.iterator]();let a=null;for(;;){const t=null==n?void 0:n.next();if(!t||!t.value)break;if(t.value.getMetadata("canvas").id===e){a=t.value;break}}return a?this._getCell(a):null}getCellByIndex(e){var t;if(!this._panel||!this._panel.model)return null;const n=null===(t=this._panel.model)||void 0===t?void 0:t.cells[Symbol.iterator]();let a=0,r=null;for(;;){const t=null==n?void 0:n.next();if(!t||!t.value)break;if(a===e){r=this._getCell(t.value);break}a+=1}return r}activateCell(e){this._panel.content.activeCellIndex=e}getIndexByID(e){var t;if(!this._panel||!this._panel.model)return null;const n=null===(t=this._panel.model)||void 0===t?void 0:t.cells[Symbol.iterator]();let a=0;for(;;){const t=null==n?void 0:n.next();if(!t||!t.value)break;const r=t.value.getMetadata("canvas");if(r){if(e===r.id)break;a++}}return a}getCellMetadataByIndex(e){var t;if(!this._panel||!this._panel.model)return null;const n=null===(t=this._panel.model)||void 0===t?void 0:t.cells[Symbol.iterator]();let a=0,r=null;for(;;){const t=null==n?void 0:n.next();if(!t||!t.value)break;if(a===e){r=Ot.getOrCreate(t.value,this._labShell,this._panel);break}a+=1}return r}}class Tt extends At{constructor(e){var t;super(e),null===(t=this._model)||void 0===t||t.metadataChanged.connect(((e,t)=>{if("canvas"===t.key&&"canvas"===t.key){const e=t.oldValue,n=t.newValue;if(!e)return;if(this.initialize(),e.parameters||this._emitHook(kt.PARAMS),e.colorPalette||this._emitHook(kt.COLOR_PALETTE),e.parameters&&e.parameters.length!==n.parameters.length)this._emitHook(kt.PARAMS);else{let t=0;for(;;){const a=e.parameters[t],r=n.parameters[t];if(!a&&!r)break;if((null==a?void 0:a.name)!==(null==r?void 0:r.name)||(null==a?void 0:a.type)!==(null==r?void 0:r.type)||(null==a?void 0:a.value)!==(null==r?void 0:r.value)){this._emitHook(kt.PARAMS);break}t++}}e.colorPalette||this._emitHook(kt.COLOR_PALETTE),e.colorPalette&&e.colorPalette!==n.colorPalette&&this._emitHook(kt.COLOR_PALETTE)}})),this.initialize()}initialize(){const{parameters:e,colorPalette:t}=this.toObject();this._parameters=e,this._colorPalette=t}get parameters(){return this._parameters}set parameters(e){this._parameters=e,this.merge({parameters:this._parameters})}get colorPalette(){return this._colorPalette}set colorPalette(e){this._colorPalette=e,this.merge({colorPalette:e})}}class Ft extends Nt{constructor(e,t){super(),this._panelIdToKernelIdMap={},this._panel=t,this._cells=new Pt(this._panel,e),this._panel.sessionContext.connectionStatusChanged.connect(this._connectStatusChangedHandler,this),this._panel.content.activeCellChanged.connect(this._activeCellChangedHandler,this),this._panel.sessionContext.statusChanged.connect(((e,t)=>{var n,a;if("restarting"===t&&(null===(n=di.currentWidget)||void 0===n?void 0:n.metadata.parameters)&&di.currentWidget.metadata.parameters.length>0){const e=null===(a=di.currentWidget.kernel)||void 0===a?void 0:a.id;e&&(me.isParameterExecutable[e]=!1)}}),this)}dispose(){super.disconnectAll()}_connectStatusChangedHandler(e,t,n){var a,r;if("connected"===t){const e=this._panel.id,t=null===(r=null===(a=this._panel.sessionContext.session)||void 0===a?void 0:a.kernel)||void 0===r?void 0:r.id;if(!t)return;e&&(this._panelIdToKernelIdMap[e]=t)}"disconnected"===t&&(pe.clearKernelComponents(this._panelIdToKernelIdMap[this._panel.id]),this._panelIdToKernelIdMap[this._panel.id]=void 0,Ot.clearMetadataByPanelId(this._panel.id)),this._emitHook(Mt.KERNEL_CONNECTION_STATE,e,t)}_activeCellChangedHandler(e,t){this._emitHook(Mt.ACTIVE_CELL,e,t)}emitComponentChange(){this._emitHook(Mt.COMPONENT_CHANGE)}get metadata(){return new Tt(this._panel.model)}_emitHook(e,t,n){const a=this._handlers.get(e);a&&(e===Mt.ACTIVE_CELL?null==a||a.forEach((e=>{e(t,n,this._cells.activeCellMetadata)})):e===Mt.KERNEL_CONNECTION_STATE?null==a||a.forEach((e=>{e(t,n)})):e===Mt.COMPONENT_CHANGE&&(null==a||a.forEach((e=>{e()}))))}get lifeCycle(){return{revealed:e=>{this._panel.revealed.then(e)},ready:e=>{this._panel.context.ready.then(e)}}}get id(){return this._panel.id}get cells(){return this._cells}get panel(){return this._panel}get sessionContext(){return this._panel.sessionContext}get kernel(){var e;return null===(e=this._panel.sessionContext.session)||void 0===e?void 0:e.kernel}get title(){return this._panel.title.label}get type(){return this._panel.sessionContext.type}}class Vt extends Nt{constructor(){super(...arguments),this._enabledCache=!0,this._enabledSummary=!0,this._settingConfigMap=new Map,this._handlerTimer=0}_initialize(e,t){this._labShell=e,this._tracker=t,(()=>{const e=localStorage.getItem("mrx-link-last-opened-notebook"),t=(n,a)=>{a&&e&&a.title.label===e&&(this._currentChangeHandler(a),this._tracker.currentChanged.disconnect(t,this))};this._tracker.currentChanged.connect(t,this),setTimeout((()=>{this._tracker.currentChanged.disconnect(t,this)}),5e3)})(),this._labShell.currentChanged.connect(((e,t)=>{this._handlerTimer&&clearTimeout(this._handlerTimer),this._handlerTimer=window.setTimeout((()=>{if(t.newValue){const e=this._settingConfigMap.get(t.newValue.id);e?(this._enabledCache=e.enabledCache,this._enabledSummary=e.enabledSummary):(this._settingConfigMap.set(t.newValue.id,{enabledCache:!0,enabledSummary:!0}),this._enabledCache=!0,this._enabledSummary=!0)}this._emitHook(_t.CURRENT,e,t),this._handlerTimer=0}),0)}),this)}get currentWidget(){return this._currentWidget}get enabledCache(){return this._enabledCache}set enabledCache(e){if(this.currentWidget){const t=this._settingConfigMap.get(this.currentWidget.id);t&&(t.enabledCache=e,this._enabledCache=e)}}get enabledSummary(){return this._enabledSummary}set enabledSummary(e){if(this.currentWidget){const t=this._settingConfigMap.get(this.currentWidget.id);t&&(t.enabledSummary=e,this._enabledSummary=e)}}isCurrent(e){return!!this.currentWidget&&this.currentWidget.id===e}dispose(){var e;null===(e=this.currentWidget)||void 0===e||e.dispose(),this._currentWidget=null,super.disconnectAll(),this._labShell.currentChanged.disconnect(this._currentChangeHandler)}static getInstance(){return this.instance||(this.instance=new Vt),this.instance}static initialize(e,t){this.getInstance()._initialize(e,t)}_currentChangeHandler(e){var t,n,a;null===(t=this._currentWidget)||void 0===t||t.metadata.dispose(),null===(n=this._currentWidget)||void 0===n||n.dispose(),e&&e.title.label.includes(".ipynb")?(this._currentWidget=new Ft(this._labShell,this._tracker.currentWidget),localStorage.setItem("mrx-link-last-opened-notebook",e.title.label)):this._currentWidget=null,null===(a=this._handlers.get(_t.CURRENT))||void 0===a||a.forEach((e=>{e(this.currentWidget)}))}_emitHook(e,t,n){if(e===_t.CURRENT){const e=n.newValue;this._currentChangeHandler(e)}}save(){this._tracker.currentWidget&&this._tracker.currentWidget.context.save()}isCurrentPanel(e){var t;return(null===(t=this._tracker.currentWidget)||void 0===t?void 0:t.id)===e}}class Ht{constructor(e){this._components=new Map,this._graph=new(at().Graph);const t=this._components,n=e?e.cellCount:0;for(let a=0;a<n;a++){const n=null==e?void 0:e.getCellMetadataByIndex(a);if(null==n?void 0:n.isComponent){t.set(n.id,n),this._graph.setNode(n.id,"");for(const e of n.parents)this._graph.setEdge(e.id,n.id)}}}get componentCount(){return this._graph.nodeCount()}getComponent(e){return this._components.get(e)}isLeafComponent(e){return!this._graph.hasNode(e)}leafComponents(){const e=this._graph.sinks();return this.componentsByIds(e)}allComponents(){const e=at().alg.topsort(this._graph);return this.componentsByIds(e)}downstreamComponents(e){const t=[this.getComponent(e)];return this.getStreamComponents(t,e,!0)}upstreamComponents(e){const t=[this.getComponent(e)];return this.getStreamComponents(t,e,!1).reverse()}getStreamComponents(e,t,n){const a=n?this._graph.successors(t):this._graph.predecessors(t);if(!a)return[];const r=this.componentsByIds(a);if(r.length>0)for(const t of r)t&&(e.find((e=>e.id===t.id))||e.push(t),this.getStreamComponents(e,t.id,n));return e}componentsByIds(e,t=[]){if(e)for(const n of e){const e=this.getComponent(n);e&&t.push(e)}return t}}var Rt,zt;function Zt(e,t){et(e,t),function(e,t){const{commands:n}=e;X.CodeCell.execute=async function(e,n,a){var r,l,o,i,s;if(!me.checkCodeExecutable(null===(r=n.session)||void 0===r?void 0:r.kernel))return;const c=e.model,d=c.getMetadata("canvas"),p=null===(o=null===(l=n.session)||void 0===l?void 0:l.kernel)||void 0===o?void 0:o.id;if(!p||!0!==(null===(i=mt.value[p])||void 0===i?void 0:i.magicCommandLoaded))return void lt.enqueue(d.id);let m,u=c.sharedModel.getSource();await pe.executeDagUpdateCommand();const h=d.isComponent;if(h&&(m="%%mrxlink_execute_component",m+=" -i "+d.id,m+=" --send-to-front",Ce.enableParallelProcessing&&(m+=" --parallel"),m+="\n",u=u.trim()?u:"\n",u=m+u.toString()),!u.trim()||!(null===(s=n.session)||void 0===s?void 0:s.kernel))return void c.clearExecution();const g={cellId:c.id};a=Object.assign(Object.assign(Object.assign({},c.metadata),a),g);const{recordTiming:v}=a;let f;c.clearExecution(),e.outputHidden=!1,e.setPrompt("*"),c.trusted=!0;try{const r=tt.OutputArea.execute(u,e.outputArea,n,a),l=["error","stream"],o=["display_data","execute_input","execute_result","status"],i=[],s=e=>{if(-1!==l.indexOf(e.header.msg_type))return!1;if(-1!==o.indexOf(e.header.msg_type)){if(!("metadata"in e.content)||!("component_id"in e.content.metadata))return!1;const n=e.content.metadata.component_id;let a;if(t.forEach((e=>{e.content.widgets.forEach((e=>{if(e instanceof X.CodeCell){const t=e.model.getMetadata("canvas");t&&t.isComponent&&t.id===n&&(a=e)}}))})),!a)return!1;if(-1===i.indexOf(n)&&(a.model.clearExecution(),i.push(n)),"display_data"===e.header.msg_type){const t="application/vnd.jupyter.stdout",n="application/vnd.jupyter.stderr",r=e.content.data;t in r?a.model.outputs.add({output_type:"stream",name:"stdout",text:r[t]}):n in r?a.model.outputs.add({output_type:"stream",name:"stderr",text:r[n]}):a.model.outputs.add({output_type:"display_data",data:r,metadata:e.content.metadata})}else"execute_input"===e.header.msg_type?a.model.executionCount=e.content.execution_count:"execute_result"===e.header.msg_type?a.model.outputs.add({output_type:"execute_result",execution_count:e.content.execution_count,data:e.content.data,metadata:e.content.metadata}):"status"===e.header.msg_type&&"busy"===e.content.execution_state&&(a.model.clearExecution(),a.setPrompt("*"));return!1}return!0};if(h&&e.outputArea.future.registerMessageHook(s),v){const t=e=>{let t;switch(e.header.msg_type){case"status":t=`status.${e.content.execution_state}`;break;case"execute_input":t="execute_input";break;default:return!0}const n=e.header.date||(new Date).toISOString(),a=Object.assign({},c.getMetadata("execution"));return a[`iopub.${t}`]=n,c.setMetadata("execution",a),!0};e.outputArea.future.registerMessageHook(t)}else c.deleteMetadata("execution");f=e.outputArea.future;const d=await r;if(c.executionCount=d.content.execution_count,v){const e=Object.assign({},c.metadata.execution),t=d.metadata.started;t&&(e["shell.execute_reply.started"]=t);const n=d.header.date;e["shell.execute_reply"]=n||(new Date).toISOString(),c.setMetadata("execution",e)}return d}catch(t){throw f&&!e.isDisposed&&e.outputArea.future===f&&e.setPrompt(""),t}},n.addCommand(Rt.dagUpdate,{label:"Update DAG",execute:async()=>{const e=t.currentWidget;if(!e)return;const n=(e=>{const t=new(at().Graph),n={nodes:[],edges:[]};return e.forEach((e=>{const a={id:e.id,name:e.name,code:e.code.trim().length?e.code:"\n",metadata:Object.assign(Object.assign({componentType:e.componentType}),{headerColor:e.headerColor,diskcache:e.diskcache})};e.parents&&e.parents.length>0&&e.parents.forEach((a=>{const r={parent:a.id,child:e.id};n.edges.push(r),t.setEdge(r.parent,r.child,{label:""})})),n.nodes.push(a),t.setNode(a.id,{label:""})})),n})((a=e,Array.from(null!==(l=null===(r=a.model)||void 0===r?void 0:r.cells[Symbol.iterator]())&&void 0!==l?l:[]).filter((e=>{var t;return null===(t=e.getMetadata("canvas"))||void 0===t?void 0:t.isComponent})).map((e=>Object.assign(Object.assign({},e.getMetadata("canvas")),{cell:e,code:e.sharedModel.getSource(),code_array:e.sharedModel.getSource().split("\n")})))));var a,r,l;await(async t=>{var n;const a=null===(n=e.sessionContext.session)||void 0===n?void 0:n.kernel;if(a){let e="%%mrxlink_update_dag \n";e+=JSON.stringify(t);const n=a.requestExecute({code:e,store_history:!1},!1,{});await n.done}})(n),await(async()=>{var t,n;const a=`%mrxlink_logging_filename ${null===(t=e.sessionContext.session)||void 0===t?void 0:t.name}`,r=null===(n=e.sessionContext.session)||void 0===n?void 0:n.kernel,l=null==r?void 0:r.requestExecute({code:a,store_history:!1},!1,{});await(null==l?void 0:l.done)})()}}),n.addCommand(Rt.dagParameters,{label:"Set DAG Parameters",execute:async e=>{var n;const a=t.currentWidget;if(!a)return;const r=null===(n=a.sessionContext.session)||void 0===n?void 0:n.kernel;if(r){let t="%%mrxlink_set_parameters \n";t+=JSON.stringify(e);const n=r.requestExecute({code:t,store_history:!1},!1,{});await n.done}}})}(e,t),function(e){const{commands:t}=e;t.addCommand(Rt.aboutMLHelp,{label:"About Link",execute:wt})}(e),function(e,t){const{commands:n}=e;function a(e,t){return e.nodeInfo.original.metadata.diskcache!==t}function l(e,n){var a;const r=t.currentWidget;if(!r)return;const l=[];l.push(e.nodeInfo.original.id);const o=null===(a=r.sessionContext.session)||void 0===a?void 0:a.kernel;l.forEach((e=>{null==o||o.requestExecute({code:`%mrxlink_use_diskcache -i ${e}${n?" -u":""}`},!1,{})}))}n.addCommand(Rt.runAll,{label:"Run All",execute:async()=>{const e=t.currentWidget;if(e)return await async function(e,t){var n,a;if(!me.checkCodeExecutable(null===(n=t.sessionContext.session)||void 0===n?void 0:n.kernel))return!1;const r=null===(a=Vt.getInstance().currentWidget)||void 0===a?void 0:a.cells,l=new Ht(r).allComponents();return await async function(e,t,n){var a,r,l;if(!me.checkCodeExecutable(null===(a=t.sessionContext.session)||void 0===a?void 0:a.kernel))return!1;const o=[];for(const e of n)(null===(r=di.currentWidget)||void 0===r?void 0:r.cells.getCellByID(e.id)).model.clearExecution(),o.push(e.id);const i=["error","stream"],s=["display_data","execute_input","execute_result","status"],c=[],d=null===(l=di.currentWidget)||void 0===l?void 0:l.cells.getCellByID(o[0]);let p=`%mrxlink_execute_components --ids ${o.toString()} --send-to-front`;Ce.enableParallelProcessing&&(p+=" --parallel");const m=tt.OutputArea.execute(p,d.outputArea,t.sessionContext);return d.outputArea.future.registerMessageHook((t=>{if(-1!==i.indexOf(t.header.msg_type))return!1;if(-1!==s.indexOf(t.header.msg_type)){if(!("metadata"in t.content)||!("component_id"in t.content.metadata))return!1;const n=t.content.metadata.component_id;let a;if(e.forEach((e=>{e.content.widgets.forEach((e=>{if(e instanceof X.CodeCell){const t=e.model.getMetadata("canvas");t&&t.isComponent&&t.id===n&&(a=e)}}))})),!a)return!1;if(-1===c.indexOf(n)&&(a.model.clearExecution(),c.push(n)),"display_data"===t.header.msg_type){const e="application/vnd.jupyter.stdout",n="application/vnd.jupyter.stderr",r=t.content.data;e in r?a.model.outputs.add({output_type:"stream",name:"stdout",text:r[e]}):n in r?a.model.outputs.add({output_type:"stream",name:"stderr",text:r[n]}):a.model.outputs.add({output_type:"display_data",data:r,metadata:t.content.metadata})}else"execute_input"===t.header.msg_type?a.model.executionCount=t.content.execution_count:"execute_result"===t.header.msg_type?a.model.outputs.add({output_type:"execute_result",execution_count:t.content.execution_count,data:t.content.data,metadata:t.content.metadata}):"status"===t.header.msg_type&&"busy"===t.content.execution_state&&(a.model.clearExecution(),a.setPrompt("*"));return!1}return!0})),"ok"===(await m).content.status}(e,t,l)}(t,e);console.error("current widget is null")}}),n.addCommand(Rt.runComponent,{label:"Run Component",icon:ve,execute:async e=>{var n;const a=null===(n=null==e?void 0:e.nodeInfo)||void 0===n?void 0:n.original,r=t.currentWidget;if(r&&a)return await async function(e,t){var n,a;if(!me.checkCodeExecutable(null===(n=e.sessionContext.session)||void 0===n?void 0:n.kernel))return!1;const r=null===(a=Vt.getInstance().currentWidget)||void 0===a?void 0:a.cells,l=new Ht(r).getComponent(t);return await async function(e,t){var n;if(!me.checkCodeExecutable(null===(n=e.sessionContext.session)||void 0===n?void 0:n.kernel))return!1;const a=e.context.model.cells,r=null==e?void 0:e.sessionContext;let l=!1;for(let n=0;n<a.length;n++)if(a.get(n).getMetadata("canvas").id===t){e.content.activeCellIndex=n,l=await U.NotebookActions.run(e.content,r),!1===l&&console.error("failed to execute cell index: "+n);break}return l}(e,null==l?void 0:l.id)}(r,a.id);console.error("Invalid param")}}),n.addCommand(Rt.clearPipeline,{label:"Clear All Pipelines",caption:"Clear All Pipelines",isEnabled:()=>{var e;return!!(null===(e=di.currentWidget)||void 0===e?void 0:e.cells.isExistComponent)},execute:e=>{te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,oe," Clear All Pipelines"),r().createElement("section",null,"Are you sure to clear all pipelines? There is no way to recover."),r().createElement("menu",null,r().createElement("button",{className:"secondary",onClick:()=>e()},"Cancel"),r().createElement("button",{className:"danger",onClick:()=>{((e,t)=>{var n,a,r;if(me.checkKernelReady(null===(a=null===(n=e.currentWidget)||void 0===n?void 0:n.context.sessionContext.session)||void 0===a?void 0:a.kernel)){if(e.currentWidget){const t=null===(r=e.currentWidget)||void 0===r?void 0:r.context.model.cells[Symbol.iterator]();for(;;){const e=t.next();if(!e.value)break;{const t=ee(e.value.getMetadata("canvas"));t.headerColor="transparent",t.isComponent=!1,t.name="",t.id=Za(),t.parents=[],e.value.setMetadata("canvas",t)}}}pe.executeDagUpdateCommand()}})(t),e()}},"Clear")))))}}),n.addCommand(Rt.enableComponentCache,{label:e=>"Enable Component Caching",isEnabled:e=>a(e,!0),icon:xe,execute:e=>{l(e,!0)}}),n.addCommand(Rt.disableComponentCache,{label:e=>"Disable Component Caching",isEnabled:e=>a(e,!1),icon:be,execute:e=>{l(e,!1)}}),n.addCommand(Rt.clearAllCache,{label:"Clear All Cache",execute:e=>{var n;const a=t.currentWidget;if(!a)return;const r=null===(n=a.sessionContext.session)||void 0===n?void 0:n.kernel;null==r||r.requestExecute({code:"%mrxlink_clear_all_cache"},!1,{})}})}(e,t)}async function Bt(e){var t,n;const a=null===(t=di.currentWidget)||void 0===t?void 0:t.kernel;if(!a)return;if("python"!==(null===(n=await a.spec)||void 0===n?void 0:n.language))return;const r=a.requestExecute({code:e,store_history:!1},!1,{});return new Promise(((e,t)=>{r.onIOPub=n=>{if(G.KernelMessage.isExecuteResultMsg(n)){const a=Function("return "+n.content.data["text/plain"]),r=JSON.parse(a());!0===r.status_ok?e(r.result):!1===r.status_ok?t(r.err_msg):e(r)}else G.KernelMessage.isStreamMsg(n)&&"stderr"===n.content.name?t(n.content.text):G.KernelMessage.isErrorMsg(n)&&t(n.content.evalue)}}))}!function(e){e.dagUpdate="Dag:update",e.dagParameters="Dag:parameters",e.runAll="Dag:run-all",e.runComponent="Dag:run-component",e.canvasExport="Link:export",e.canvasImport="Link:import",e.linkExport="Link:pipeline-export",e.linkImport="Link:pipeline-import",e.addTemplateNotebook="Link:open-template-notebook",e.cacheExport="Link:cache-export",e.cacheImport="Link:cache-import",e.aboutMLHelp="Link:about-makinarocks-ml",e.separator="separator",e.headerColor="panel:color",e.clearPipeline="Link:clear-pipeline",e.enableComponentCache="Link:enable-component-cache",e.disableComponentCache="Link:disable-component-cache",e.clearAllCache="Link:clear-all-cache",e.exportPY="Link:export-selection-py"}(Rt||(Rt={})),function(e){e[e.component=0]="component",e[e.componentForm=1]="componentForm",e[e.importDataset=2]="importDataset",e[e.importRunwayModel=3]="importRunwayModel",e[e.uploadDataset=4]="uploadDataset",e[e.uploadRunwayModel=5]="uploadRunwayModel",e[e.customSnippetParameter=6]="customSnippetParameter",e[e.default=7]="default"}(zt||(zt={}));var jt=n(34442);const Dt=r().createContext({}),Wt={"& div.MuiTooltip-tooltip[class]":{marginBottom:"3px"}};var Ut=n(11848),$t=n(58331),Gt=function(e,t){var n={};for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&t.indexOf(a)<0&&(n[a]=e[a]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(a=Object.getOwnPropertySymbols(e);r<a.length;r++)t.indexOf(a[r])<0&&Object.prototype.propertyIsEnumerable.call(e,a[r])&&(n[a[r]]=e[a[r]])}return n};const qt=(0,Ut.Ay)((e=>{var{className:t}=e,n=Gt(e,["className"]);return r().createElement(N.Tooltip,Object.assign({},n,{classes:{popper:t}}))}))((({theme:e})=>({[`& .${$t.A.tooltip}`]:{margin:"7px",borderRadius:"4px",color:"var(--link-panel-toolbar-tooltip-font-color)",fontWeight:700,fontSize:"11px",backgroundColor:"var(--link-panel-toolbar-tooltip-background)",boxShadow:"1px 1px 2px rgba(0.2, 0.2, 0.2, 0.2)"}}))),Kt=e=>{const{children:t}=e,n=Gt(e,["children"]);return r().createElement(qt,Object.assign({},n),t)},Yt=(0,jt.observer)((({commands:e,handleEditComponent:t,removeFromPipeline:n})=>{var l,o,i;const{metaWrapper:s,widgetWrapper:c}=(0,a.useContext)(Dt),[d,p]=(0,a.useState)(s.isComponent),m=null===(i=pe.components[null!==(o=null===(l=c.kernel)||void 0===l?void 0:l.id)&&void 0!==o?o:""])||void 0===i?void 0:i[s.id],u=e=>{p(e.isComponent)};return(0,a.useEffect)((()=>{if(s)return s.connect(yt.IS_COMPONENT,u),()=>{s.disconnect(yt.IS_COMPONENT,u)}}),[s,c]),r().createElement(r().Fragment,null,d&&s.name&&s.name.length&&r().createElement(Xt,{className:0===(null==m?void 0:m.metadata.headerColor.indexOf("#"))?"has-color":""},r().createElement("span",{className:"component"},r().createElement("span",{className:"header-color",style:{backgroundColor:null==m?void 0:m.metadata.headerColor}}),r().createElement("span",{className:"name"},s.name),r().createElement("span",{className:"status"},m&&r().createElement(Kt,{title:{invalid:"Ready",running:"Running",successful:"Success",failed:"Fail"}[null==m?void 0:m.execution_status]||"",describeChild:!0,placement:"top",sx:Wt},"successful"===(h=null==m?void 0:m.execution_status)||"failed"===h||"running"===h?Jt[h]:Jt.invalid))),r().createElement("button",{className:`diskcache ${(null==m?void 0:m.metadata.diskcache)?"on":""} ${(null==m?void 0:m.diskcache_status)||""}`,onClick:()=>{(null==m?void 0:m.metadata.diskcache)?e.execute(Rt.disableComponentCache,{nodeInfo:{original:{id:s.id}}}):e.execute(Rt.enableComponentCache,{nodeInfo:{original:{id:s.id}}})}},r().createElement("span",{className:"cache-status"},Qt[(null==m?void 0:m.metadata.diskcache)?"cached":"uncached"],!1===(null==m?void 0:m.metadata.diskcache)?"Cache off":"uncached"===(null==m?void 0:m.diskcache_status)?"Cache on":"updating"===(null==m?void 0:m.diskcache_status)?"Caching":"cached"===(null==m?void 0:m.diskcache_status)?"Success":"failed"===(null==m?void 0:m.diskcache_status)?"Fail":""),r().createElement("span",{className:"cache-action"},Qt[(null==m?void 0:m.metadata.diskcache)?"uncached":"cached"],!1===(null==m?void 0:m.metadata.diskcache)?"Cache on":"Cache off")),Ce.remoteServers.filter((e=>e.components.find((e=>s.id===e)))).length>0&&r().createElement("span",{className:"remote"},r().createElement(Kt,{title:"Run on remote",describeChild:!0,placement:"top",sx:Wt},en)),r().createElement("span",{className:"action"},r().createElement(Kt,{title:"Edit Component",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:t,className:"primary"},tn)),r().createElement(Kt,{title:"Remove from Pipeline",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:n,className:"danger"},nn)))));var h})),Xt=S().div`
  display: inline-block;

  .component {
    position: relative;
    display: inline-block;
    border: 1px solid #e0e0e1;
    border-radius: 4px;
    padding: 0 2px 0 12px;
    height: 30px;
    overflow: hidden;
    font-size: 13px;
    vertical-align: middle;
    color: #38383d;
    background: #fff;
  }
  body[data-theme='dark'] & .component {
    color: #f7f7f8;
    border-color: #606066;
    background-color: #111;
  }
  .jp-Notebook .jp-Cell.jp-mod-active & .component {
    background-color: #f5f6ff;
    color: var(--link-color);
    border-color: var(--link-color);
  }
  body[data-theme='dark'] .jp-Notebook .jp-Cell.jp-mod-active & .component {
    background-color: #26264e;
    color: var(--link-color);
    border-color: var(--link-color);
  }
  &.has-color .component {
    padding-left: 16px;
  }

  .component > * {
    vertical-align: middle;
    line-height: 30px;
  }

  .component .header-color {
    position: absolute;
    top: 0;
    left: 0;
    width: 8px;
    height: 32px;
  }

  .component .name {
    display: inline-block;
  }

  .component .status {
    position: relative;
    top: 1px;
    margin: 0 8px;
  }

  .component .status svg {
    width: 11px;
    height: 11px;
  }

  .diskcache {
    position: relative;
    top: 2px;
    padding: 0 0 0 5px;
    width: auto;

    /* FIXME: Temporary disable component status */
    display: none;
  }

  .diskcache .cache-status {
    display: inline;
  }
  .diskcache:hover .cache-status {
    display: none;
  }

  .diskcache .cache-action {
    display: none;
  }
  .diskcache:hover .cache-action {
    display: inline;
  }

  .diskcache svg {
    vertical-align: text-bottom;
  }

  .diskcache path {
    transform: translate(4px, 4px);
  }
  body[data-theme='dark'] & .diskcache path {
    fill: #555;
  }
  .diskcache.cached path {
    fill: var(--link-panel-dag-successful-background);
  }
  .diskcache.failed path {
    fill: var(--link-panel-dag-failed-background);
  }

  .diskcache circle {
    visibility: hidden;
  }
  .diskcache.updating circle {
    visibility: visible;
  }

  .remote {
    /* FIXME: Remote server status is temporary disabled. */
    display: none;
  }
  .remote svg {
    position: relative;
    top: 2px;
    width: 14px;
    height: 14px;
    margin-left: 6px;
    margin-right: 3px;
  }
  body[data-theme='dark'] & .remote svg {
    fill: #9c9ca0;
  }

  .action button {
    width: 24px;
    height: 24px;
    border-radius: 4px;
    margin-left: 4px;
    display: none;
  }
  .action button:hover {
    background: #f7f7f8;
  }
  body[data-theme='dark'] & .action button:hover {
    background: #202024;
  }
  &:hover .action button {
    display: inline;
  }
  .action button:first-of-type {
    margin-left: 14px;
  }

  .action button svg {
    fill: #9c9ca0;
    width: 24px;
    height: 24px;
  }
  body[data-theme='dark'] & .action button svg {
    fill: #79797c;
  }
`,Jt={successful:r().createElement("svg",{width:"11",height:"11",viewBox:"0 0 11 11",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M5.5 11C8.53757 11 11 8.53757 11 5.5C11 2.46243 8.53757 0 5.5 0C2.46243 0 0 2.46243 0 5.5C0 8.53757 2.46243 11 5.5 11Z",fill:"#43B145"}),r().createElement("path",{d:"M3.66797 5.44079L4.9663 6.72569L7.92112 4.28125",stroke:"white",strokeLinecap:"round",strokeLinejoin:"round"})),invalid:r().createElement("svg",{width:"11",height:"11",viewBox:"0 0 11 11",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("rect",{width:"11",height:"11",rx:"5.5",fill:"#6C79F9"}),r().createElement("path",{d:"M6.25187 3L6.09142 6.71269H5.06903L4.90858 3H6.25187ZM4.875 7.8694C4.875 7.6903 4.93968 7.54105 5.06903 7.42164C5.19838 7.29975 5.36629 7.23881 5.57276 7.23881C5.77923 7.23881 5.9459 7.29975 6.07276 7.42164C6.20211 7.54105 6.26679 7.6903 6.26679 7.8694C6.26679 8.04851 6.20211 8.19901 6.07276 8.3209C5.9459 8.4403 5.77923 8.5 5.57276 8.5C5.36629 8.5 5.19838 8.4403 5.06903 8.3209C4.93968 8.19901 4.875 8.04851 4.875 7.8694Z",fill:"white"})),running:Ie,failed:r().createElement("svg",{width:"11",height:"11",viewBox:"0 0 11 11",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M5.5 11C8.53757 11 11 8.53757 11 5.5C11 2.46243 8.53757 0 5.5 0C2.46243 0 0 2.46243 0 5.5C0 8.53757 2.46243 11 5.5 11Z",fill:"#C55B5F"}),r().createElement("path",{d:"M3.80859 7.1893L7.19321 3.80469",stroke:"white",strokeLinecap:"round",strokeLinejoin:"round"}),r().createElement("path",{d:"M3.80859 3.80469L7.19321 7.1893",stroke:"white",strokeLinecap:"round",strokeLinejoin:"round"}))},Qt={uncached:r().createElement("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.7711 0.23324C13.082 0.544228 13.082 1.04844 12.7711 1.35943L2.35747 11.773C2.04648 12.084 1.54227 12.084 1.23129 11.773C0.9203 11.462 0.9203 10.9578 1.23129 10.6468L11.6449 0.23324C11.9559 -0.0777468 12.4601 -0.0777468 12.7711 0.23324Z",fill:"#E0E0E1"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9.15038 0.641436C8.50554 0.540844 7.78199 0.484375 7.0177 0.484375C4.3122 0.484375 2.11719 1.19196 2.11719 2.05954V3.04401C2.11719 3.71484 3.42951 4.29001 5.27543 4.51639L9.15038 0.641436ZM4.65191 5.13991C3.62807 4.97282 2.72632 4.68756 2.11719 4.27461V6.48968C2.11719 6.73678 2.29524 6.9709 2.61243 7.17939L4.65191 5.13991ZM4.67754 7.87343L7.23172 5.31925C9.0803 5.29542 10.9044 4.96185 11.9182 4.27461V6.48968C11.9182 7.35726 9.72319 8.06485 7.0177 8.06485C6.17031 8.06485 5.37301 7.99544 4.67754 7.87343ZM2.25028 10.3007L4.07515 8.47582C4.96899 8.67196 5.99425 8.7663 7.0177 8.7663C8.93834 8.7663 10.8653 8.43403 11.9182 7.72028V9.93535C11.9182 10.8029 9.72319 11.5105 7.0177 11.5105C4.70416 11.5105 2.76392 10.9931 2.25028 10.3007ZM7.96106 4.58992L11.2724 1.27859C11.6833 1.509 11.9182 1.77571 11.9182 2.05954V3.04401C11.9182 3.80812 10.2155 4.44813 7.96106 4.58992Z",fill:"#E0E0E1"})),cached:r().createElement("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M11.3704 1.83073V2.87239C11.3704 3.79037 9.04785 4.53906 6.18518 4.53906C3.32252 4.53906 1 3.79037 1 2.87239V1.83073C1 0.912757 3.32252 0.164062 6.18518 0.164062C9.04785 0.164062 11.3704 0.912757 11.3704 1.83073ZM11.3704 4.17448V6.51823C11.3704 7.4362 9.04785 8.1849 6.18518 8.1849C3.32252 8.1849 1 7.4362 1 6.51823V4.17448C2.114 4.92969 4.15296 5.28126 6.18518 5.28126C8.21741 5.28126 10.2563 4.92969 11.3704 4.17448ZM11.3704 7.82031V10.1641C11.3704 11.082 9.04785 11.8307 6.18518 11.8307C3.32252 11.8307 1 11.082 1 10.1641V7.82031C2.114 8.57552 4.15296 8.9271 6.18518 8.9271C8.21741 8.9271 10.2563 8.57552 11.3704 7.82031Z",fill:"var(--feedback-info)"}),r().createElement("circle",{cx:"10",cy:"10",r:"9",fill:"none",stroke:"var(--feedback-info)",strokeWidth:"2",strokeLinecap:"round"},r().createElement("animateTransform",{attributeName:"transform",attributeType:"XML",type:"rotate",from:"0 10 10",to:"360 10 10",dur:"2s",repeatCount:"indefinite"}),r().createElement("animate",{attributeName:"stroke-dasharray",attributeType:"XML",values:"1, 55.5; 40, 55.5; 40, 55.5",dur:"1.5s",repeatCount:"indefinite"}),r().createElement("animate",{attributeName:"stroke-dashoffset",attributeType:"XML",values:"0; -15.5; -55.5",dur:"1.5s",repeatCount:"indefinite"})))},en=r().createElement("svg",{width:"18",height:"18",viewBox:"0 0 18 18",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M1 3.5C1 2.94772 1.44772 2.5 2 2.5H16C16.5523 2.5 17 2.94772 17 3.5V7.09978C17 7.65206 16.5523 8.09978 16 8.09978H2C1.44772 8.09978 1 7.65206 1 7.09978V3.5ZM10 5.30048C10 4.78504 10.4179 4.36719 10.9333 4.36719H11.0667C11.5821 4.36719 12 4.78504 12 5.30048C12 5.81593 11.5821 6.23378 11.0667 6.23378H10.9333C10.4179 6.23378 10 5.81593 10 5.30048ZM13.4333 4.36719C12.9179 4.36719 12.5 4.78504 12.5 5.30048C12.5 5.81593 12.9179 6.23378 13.4333 6.23378H13.5667C14.0821 6.23378 14.5 5.81593 14.5 5.30048C14.5 4.78504 14.0821 4.36719 13.5667 4.36719H13.4333Z",fill:"#79797c"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M1 10.8984C1 10.3462 1.44772 9.89844 2 9.89844H16C16.5523 9.89844 17 10.3462 17 10.8984V14.4982C17 15.0505 16.5523 15.4982 16 15.4982H2C1.44772 15.4982 1 15.0505 1 14.4982V10.8984ZM10 12.6989C10 12.1835 10.4179 11.7656 10.9333 11.7656H11.0667C11.5821 11.7656 12 12.1835 12 12.6989C12 13.2144 11.5821 13.6322 11.0667 13.6322H10.9333C10.4179 13.6322 10 13.2144 10 12.6989ZM13.4333 11.7656C12.9179 11.7656 12.5 12.1835 12.5 12.6989C12.5 13.2144 12.9179 13.6322 13.4333 13.6322H13.5667C14.0821 13.6322 14.5 13.2144 14.5 12.6989C14.5 12.1835 14.0821 11.7656 13.5667 11.7656H13.4333Z",fill:"#79797c"})),tn=r().createElement("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.2002 11.5231L12.6771 9L7.25231 14.4247L7 16.6955V16.8217C7 17.074 7.25231 17.2002 7.50462 17.2002L9.77545 16.9479L15.2002 11.5231Z",fill:"#9C9CA0"}),r().createElement("path",{d:"M16.8074 8.44157L15.6561 7.29027C15.4691 7.10436 15.2162 7 14.9526 7C14.6888 7 14.4359 7.10436 14.249 7.29027L13.0977 8.44157L15.6561 11L16.8074 9.8487C16.9933 9.66174 17.0977 9.4088 17.0977 9.14514C17.0977 8.88147 16.9933 8.62853 16.8074 8.44157Z",fill:"#9C9CA0"})),nn=r().createElement("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M13.627 8.25H15.502C15.877 8.25 16.127 8.5 16.127 8.875V9.5H8.00195V8.875C8.00195 8.5 8.31445 8.25 8.62695 8.25H10.502C10.627 7.5625 11.3145 7 12.0645 7C12.8145 7 13.502 7.5625 13.627 8.25ZM11.127 8.25H13.002C12.877 7.875 12.4395 7.625 12.0645 7.625C11.6895 7.625 11.252 7.875 11.127 8.25ZM8.62695 10.125H15.502L14.9395 16.4375C14.9395 16.75 14.627 17 14.3145 17H9.81445C9.50195 17 9.25195 16.75 9.18945 16.4375L8.62695 10.125Z",fill:"#9C9CA0"})),an=Yt,rn='<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">\n<g clip-path="url(#clip0_3632_5334)">\n<path class="bg" d="M14 28.0001C21.732 28.0001 28 21.732 28 14.0001C28 6.26807 21.732 6.10352e-05 14 6.10352e-05C6.26801 6.10352e-05 0 6.26807 0 14.0001C0 21.732 6.26801 28.0001 14 28.0001Z" fill="#EEEFFA"/>\n<path class="icon" fill-rule="evenodd" clip-rule="evenodd" d="M19.8481 10.4527C20.2506 10.9191 20.1824 11.6101 19.696 11.996L13.1576 17.8479C12.705 18.2069 12.0423 18.1786 11.6248 17.7824L8.38323 14.7064C7.93448 14.2806 7.93072 13.5865 8.37483 13.1563C8.81894 12.726 9.54275 12.7224 9.9915 13.1482L12.4975 15.5263L18.2386 10.3068C18.7251 9.92093 19.4457 9.98625 19.8481 10.4527Z" fill="#6C79F9"/>\n</g>\n<defs>\n<clipPath id="clip0_3632_5334">\n<rect width="28" height="28" fill="white"/>\n</clipPath>\n</defs>\n</svg>\n',ln='<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">\n<g clip-path="url(#clip0_3632_5464)">\n<path class="bg" d="M14.0015 28C21.7335 28 28.0015 21.732 28.0015 14C28.0015 6.26801 21.7335 0 14.0015 0C6.26948 0 0.00146484 6.26801 0.00146484 14C0.00146484 21.732 6.26948 28 14.0015 28Z" fill="#FFEAEE"/>\n<path class="icon" fill-rule="evenodd" clip-rule="evenodd" d="M18.7321 9.4227C19.2294 9.92002 19.2294 10.7263 18.7321 11.2236L11.2237 18.732C10.7264 19.2293 9.92011 19.2293 9.42279 18.732C8.92548 18.2347 8.92548 17.4283 9.42279 16.931L16.9311 9.4227C17.4284 8.92538 18.2347 8.92538 18.7321 9.4227Z" fill="#D17C7F"/>\n<path class="icon" fill-rule="evenodd" clip-rule="evenodd" d="M9.42279 9.4227C9.92011 8.92538 10.7264 8.92538 11.2237 9.4227L18.7321 16.931C19.2294 17.4283 19.2294 18.2347 18.7321 18.732C18.2347 19.2293 17.4284 19.2293 16.9311 18.732L9.42279 11.2236C8.92548 10.7263 8.92548 9.92002 9.42279 9.4227Z" fill="#D17C7F"/>\n</g>\n<defs>\n<clipPath id="clip0_3632_5464">\n<rect width="28" height="28" fill="white"/>\n</clipPath>\n</defs>\n</svg>\n',on=S().div`
  position: relative;

  .counter {
    position: absolute;
    top: 0;
    right: 0;
    color: var(--text-secondary);
    font-size: 11px;
    line-height: 12.89px;
    margin: 0;
  }

  .error-message {
    color: var(--feedback-fail);
    font-size: 10px;
    line-height: 1;
  }

  .SVGInline {
    position: relative;
    top: 2px;
  }

  .SVGInline svg {
    width: 12px;
    height: 12px;
  }
`,sn=({children:e,valueLength:t,maxLength:n,errorMessage:a=""})=>r().createElement(on,null,e,r().createElement("p",{className:"counter"},t,"/",n),""!==a&&r().createElement("p",{className:"error-message"},r().createElement(Se,{svg:Ne})," ",a)),cn=S().div`
  flex: 1 1 0%;

  .MuiFormControl-root {
    margin: 0;
  }

  ${"\n.MuiFormLabel-root,\n.MuiInputLabel-root,\n.MuiInputLabel-root.Mui-focused,\n.MuiInputLabel-root.Mui-error {\n  color: var(--text-secondary);\n}\n.MuiFormLabel-root,\n.MuiInputLabel-root {\n  display: inline-block;\n  position: relative;\n  transform: translate(0, 0) scale(1);\n  font-size: 11px;\n  font-weight: 500;\n  line-height: 13px;\n  letter-spacing: 0;\n  margin: 0 12px 4px 0;\n}\n.MuiInputLabel-asterisk {\n  display: none;\n}\n"}
  ${"\n.MuiFormControlLabel-root {\n  margin-left: 0;\n  margin-right: 8px;\n}\n\n.MuiRadio-root {\n  padding: 0;\n}\n.MuiRadio-root svg {\n  width: 16px;\n  height: 16px;\n}\n.MuiRadio-root.Mui-checked svg path {\n  fill: var(--link-color);\n}\n\n.MuiFormControlLabel-root .MuiTypography-root {\n  font-weight: 400;\n  font-size: 13px;\n  line-height: 15px;\n  margin-left: 8px;\n}\n"}
  ${"\n.MuiInputBase-root {\n  border-radius: 0px;\n  padding: 0px 4px 0px 4px;\n  border-radius: 0px;\n  color: var(--link-cell-widghet-add-to-component-name-input-font-color);\n  font-size: 13px;\n  background-color: var(--link-cell-widghet-add-to-component-name-input-background);\n  outline: none;\n}\n\n.MuiInputBase-root .MuiInputBase-input.Mui-disabled {\n  color: var(--control-text-disabled);\n  -webkit-text-fill-color: var(--control-text-disabled);\n}\n\n.MuiInputBase-root:not(:has(textarea)) {\n  height: 28px;\n}\n\n.MuiFormControl-root .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline {\n  border: 1px solid var(--link-custom-select-notchedoutline);\n  top: 0\n}\n.MuiFormControl-root .Mui-focused .MuiOutlinedInput-notchedOutline {\n  border: 1px solid var(--link-custom-select-focus-notchedoutline);\n}\n.MuiOutlinedInput-input {\n  padding: 4px 10px;\n  background: #fff;\n}\nbody[data-theme=dark] & .MuiOutlinedInput-input {\n  background: inherit;\n}\n.MuiOutlinedInput-notchedOutline legend {\n  display: none;\n}\n"}
  ${"\n.MuiOutlinedInput-root {\n  padding: 0;\n}\n.MuiInputBase-root .MuiInputBase-input.Mui-disabled {\n  color: var(--control-text-disabled);\n  -webkit-text-fill-color: var(--control-text-disabled);\n}\n.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline,\n.MuiAutocomplete-root .MuiOutlinedInput-notchedOutline {\n  top: 0;\n  border: 1px solid var(--link-custom-select-notchedoutline)!important;\n}\n.MuiOutlinedInput-root .MuiSelect-iconOpen + .MuiOutlinedInput-notchedOutline,\n.MuiAutocomplete-root .Mui-focused .MuiOutlinedInput-notchedOutline{\n  border: 1px solid var(--link-custom-select-focus-notchedoutline) !important;\n}\n.MuiSelect-select {\n  padding-top: 4px;\n  padding-bottom: 6px;\n  padding-left: 8px;\n}\nsvg {\n  right: 4px;\n  fill: var(--text-secondary);\n}\n"}
  ${"\n.MuiAutocomplete-root .MuiIconButton-root {\n  color: var(--link-cell-widghet-add-to-component-name-input-font-color);\n}\n.MuiAutocomplete-root .MuiOutlinedInput-root.MuiInputBase-root.MuiInputBase-sizeSmall {\n  padding: 0px 35px 0px 8px;\n}\n.MuiAutocomplete-root .MuiChip-sizeSmall {\n  height: 20px;\n  color: #fff;\n  font-weight: 700;\n  font-size: 13px;\n  background: var(--link-color);\n}\n.MuiAutocomplete-root .MuiChip-deleteIcon {\n  color: #fff !important;\n}\n.MuiAutocomplete-root .MuiOutlinedInput-root .MuiAutocomplete-endAdornment {\n  right: 4px;\n}\n.MuiAutocomplete-root .MuiOutlinedInput-root.MuiInputBase-sizeSmall .MuiAutocomplete-input {\n  padding-left: 0;\n  border: none;\n}\n"}
`,dn=S().div`
  font-size: 13px !important;
  border: 1px solid var(--border-primary);
  border-width: 0 1px 1px;
  [data-popper-placement='top'] & {
    border-width: 1px 1px 0;
  }

  ul.MuiAutocomplete-listbox {
    padding: 0;
    max-height: 244px;
    overflow-x: hidden;
    text-overflow: ellipsis;
    box-sizing: border-box;
    color: var(--link-cell-widghet-add-to-component-name-input-font-color);
    background-color: var(--background-base);
  }
  li.MuiAutocomplete-option {
    display: flex;
    padding: 7px 8px;
    white-space: nowrap;
  }
  li.MuiAutocomplete-option:hover {
    background-color: var(--background-surface-hover);
  }
  li.MuiAutocomplete-option[data-border='before'] {
    border-top: 1px solid var(--border-primary);
  }
  li.MuiAutocomplete-option[data-border='after'] {
    border-bottom: 1px solid var(--border-primary);
  }
  li.MuiAutocomplete-option.Mui-focused {
    background-color: var(--background-surface-hover);
  }
  li.MuiAutocomplete-option[aria-selected='true'] {
    color: #fff;
    background-color: var(--link-color);
  }
  li.MuiAutocomplete-option.Mui-focused[aria-selected='true'] {
    color: #fff;
    background-color: var(--link-color);
  }

  .MuiAutocomplete-noOptions {
    color: var(--link-cell-widghet-add-to-component-name-input-font-color);
    background-color: var(--background-base);
  }
  .lm-SplitPanel-handle ::after {
    pointer-events: all;
  }
`,pn=cn,mn=S().li`
  padding: 0;
  border-bottom: 1px solid var(--border-primary);

  button {
    color: var(--text-primary);
    padding: 7px 13px;
    border: 0 none;
    background: transparent;
    width: 100%;
    text-align: left;
    box-sizing: border-box;
    svg {
      fill: var(--text-secondary);
    }
  }
  button:hover {
    background-color: var(--background-surface-hover);
  }
`,un=S().li`
  .icon {
    margin-right: 8px;
    visibility: hidden;
  }
  .icon.selected {
    visibility: visible;
  }
  .name {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`,hn=S().div`
  margin-right: 5px;
  padding: 2px 4px;
  border-radius: 4px;

  color: var(--white);
  font-size: 10px;

  background-color: var(--link-color);

  cursor: pointer;
`,gn=r().createElement("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.8891 8.11089C16.0843 8.30615 16.0843 8.62273 15.8891 8.818L12.7071 12L15.8891 15.182C16.0843 15.3772 16.0843 15.6938 15.8891 15.8891C15.6938 16.0843 15.3772 16.0843 15.182 15.8891L12 12.7071L8.81802 15.8891C8.62276 16.0843 8.30618 16.0843 8.11091 15.8891C7.91565 15.6938 7.91565 15.3772 8.11091 15.182L11.2929 12L8.11091 8.818C7.91565 8.62273 7.91565 8.30615 8.11091 8.11089C8.30618 7.91563 8.62276 7.91563 8.81802 8.11089L12 11.2929L15.182 8.11089C15.3772 7.91563 15.6938 7.91563 15.8891 8.11089Z",fill:"var(--text-secondary)"})),vn=({label:e,options:t,value:n,onChange:l,placeholder:o,suggestion:i,disabled:s})=>{const[c,d]=(0,a.useState)(!1);return r().createElement(N.Autocomplete,{multiple:!0,limitTags:0,clearIcon:gn,getLimitTagsText:e=>{return t=e,r().createElement("div",null,t," Selected");var t},size:"small",disabled:s,open:c,onOpen:()=>{d(!0)},onClose:(e,t)=>{"blur"!==t&&"toggleInput"!==t||d(!1)},onChange:l,options:i&&i.items.length>0?[{id:-1,name:i.label},...i.items,...t.filter((e=>-1===i.items.map((e=>e.id)).indexOf(e.id)))]:t,getOptionLabel:e=>-1===e.id?"WHAT??":e.name,isOptionEqualToValue:(e,t)=>e.id===t.id,PaperComponent:dn,value:n,noOptionsText:"No results",getOptionDisabled:e=>-1===e.id,renderInput:t=>r().createElement(N.TextField,Object.assign({},t,{variant:"outlined",label:e,placeholder:n.length>0?"":o,InputLabelProps:{shrink:!0}})),renderTags:(e,t)=>((e,t)=>r().createElement(hn,null,e.length," Selected"))(e),renderOption:(e,t,{selected:n})=>r().createElement(r().Fragment,null,t.action?r().createElement(mn,null,t.action):r().createElement(un,Object.assign({},e,{"data-border":i&&i.items.length>0&&t.id===i.items[i.items.length-1].id?"after":""}),r().createElement("span",{className:"icon"+(n?" selected":"")},r().createElement(Se,{svg:'<svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M1 3.64286L3 6.5L9 1.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>\n</svg>\n'})),r().createElement("span",{className:"name"},t.name)))})},fn=(0,jt.observer)((({setRenderType:e,restoreFocus:t})=>{var n;const{metaWrapper:l,widgetWrapper:o}=(0,a.useContext)(Dt),[i,s]=(0,a.useState)(""),[c,d]=(0,a.useState)([]),[p,m]=(0,a.useState)(!1),[u,h]=(0,a.useState)(""),[g,v]=(0,a.useState)([]),f=(0,a.useRef)(null),x=null===(n=o.kernel)||void 0===n?void 0:n.id,b=pe.getKernelComponents(x);(0,a.useEffect)((()=>{C()}),[b]);const C=()=>{v(E())},E=(0,a.useCallback)((()=>{const e=new Ht(o.cells),t=e.downstreamComponents(l.id),n=e.allComponents();return n?n.filter((e=>(null==e?void 0:e.id)!==l.id&&t.indexOf(e)<0)).map((e=>({name:null==e?void 0:e.name,id:null==e?void 0:e.id}))):[]}),[o,l]),w=(0,a.useCallback)((()=>{const e=new Ht(o.cells),t=e.downstreamComponents(l.id),n=e.leafComponents();return n?n.filter((e=>(null==e?void 0:e.id)!==l.id&&t.indexOf(e)<0)).map((e=>({name:null==e?void 0:e.name,id:null==e?void 0:e.id}))):[]}),[o,l]),y=e=>{v(E()),d([...e.parents])};(0,a.useEffect)((()=>(s(l.name?l.name:""),v(E()),d((e=>{const t=l.parents.map((t=>{const n=e.filter((e=>e.id===t.id));return n.length?(n[0].name=t.name,null):t})).filter((e=>null!==e));return[...e,...t]})),m(!0),l.connect(yt.PARENTS,y),()=>{l.disconnect(yt.PARENTS,y)})),[l]),(0,a.useEffect)((()=>{v(E())}),[]);const k=(0,a.useCallback)((e=>new RegExp(/^[-\w\s]*[a-zA-Z\d][-\w\s]*$/g).test(e)),[]),L=(0,a.useCallback)((()=>{let e=!1;return o.cells.each(((t,n,a)=>{t.parents.forEach(((n,a)=>{n.id===l.id&&c.forEach((n=>{n.id===t.id&&(h("Invalid(Not allowed cyclic pipeline)"),e=!0)}))}))})),e}),[c]),_=n=>{var a;null==n||n.preventDefault(),A(i),i&&(null==i?void 0:i.length)&&k(i)&&!I(i)&&l&&(l.name=i,l.parents=c&&c.length?[...c]:[],L()?l.parents=[]:(h(""),l.isComponent=!0,null===(a=o.cells.getCellByID(l.id))||void 0===a||a.model.setMetadata("canvas",{name:l.name,parents:l.parents,isComponent:l.isComponent,id:l.id,componentType:l.componentType,copiedOriginId:l.copiedOriginId,headerColor:l.headerColor,diskcache:l.diskcache}),pe.executeDagUpdateCommand(),e(zt.component))),t()},M=(0,a.useCallback)((()=>{s(""),h(""),e(l.isComponent?zt.component:zt.default),t()}),[]),S=(0,a.useCallback)(((e,t)=>{d([...t])}),[]),A=e=>I(e)?(h("Duplicated"),!1):k(e)?e.length>30?(h("Maximum 30 characters"),!1):(h(""),!0):(h("Invalid(English letters, numbers, blank, ‘-’, ‘_’ only)"),!1),I=e=>{const t=l.id,n=pe.getComponent(x,t);return(!n||e!==n.name)&&void 0!==Object.keys(b).find((t=>e===b[t].name))};return r().createElement(xn,{ref:f,className:c.length>0?"selected":""},p&&r().createElement("form",{onSubmit:_},r().createElement(pn,{className:"form-control"},r().createElement(sn,{valueLength:i.length,maxLength:30,errorMessage:u},r().createElement(N.TextField,{label:"Component Name",name:"component-name",value:i,onChange:e=>{A(e.target.value),e.target.value.length<=30?s(e.target.value):s(Array.from(e.target.value).splice(0,30).join(""))},onKeyDown:e=>{"Enter"===e.key&&(e.preventDefault(),_())},placeholder:"Enter the component name",required:!0,error:u.length>0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",autoFocus:!0,InputLabelProps:{shrink:!0},inputProps:{maxLength:30}}))),r().createElement(pn,{className:"form-control"},r().createElement(vn,{label:"Parent Components",options:g.sort(((e,t)=>-t.name.localeCompare(e.name))),value:[...c],onChange:S,placeholder:"Search or Select parent components",suggestion:{label:"Recommended Components",items:w()}})),r().createElement("div",{className:"widget-btn-container"},r().createElement(Kt,{title:l.isComponent?"Edit":"Add",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"submit",className:"primary"},r().createElement(Se,{svg:rn}))),r().createElement(Kt,{title:"Cancel",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"button",onClick:M,className:"danger"},r().createElement(Se,{svg:ln}))))))})),xn=S().div`
  position: relative;
  width: 100%;

  form {
    display: flex;
    align-items: flex-start;
    width: 100%;
  }

  .MuiAutocomplete-root {
    flex: 1 1 0%;
    min-width: 100px;
    padding-left: 0px;

    & input {
      padding-right: 30px !important;
      padding-left: 0px !important;
    }
  }

  .MuiAutocomplete-root .MuiInputBase-root {
    padding-right: 0 !important;
  }
  &.selected .MuiAutocomplete-root .MuiInputBase-root {
    padding-right: 25px !important;
  }

  .cell-widget-btn {
    width: 30px;
    height: 25px;
    margin-left: 12px;
    padding: 5px 0 0;
    border: none;
    background: transparent;
  }

  .cell-widget-btn .circle {
    fill: var(--link-cell-widget-form-button-background);
  }

  .cell-widget-btn:hover .circle,
  .cell-widget-btn:focus .circle {
    fill: var(--link-cell-widget-form-button-hover-background);
  }

  .cell-widget-btn + .cell-widget-btn {
    margin-left: 0;
  }

  .widget-btn-container {
    display: flex;
    padding-top: 15px;
  }
`,bn=fn,Cn=S().ul`
  margin: 0;
  padding: 0;
  list-style: none;
  position: absolute;
  z-index: 9;
  visibility: hidden;
  background: var(--background-base);
  border: 1px solid var(--border-secondary);
  border-radius: 4px;
  box-shadow: var(--popover-shadow);
  overflow: hidden;

  &.on {
    visibility: visible;
  }

  li button {
    width: 100%;
    height: 31px;
    padding: 0 10px;
    color: var(--button-secondary-text);
    text-align: left;
    background: transparent;
    border: 0 none;
    font-size: 13px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
  }
  li button:hover,
  li button:focus {
    background: var(--button-secondary-background-hover);
  }
  [data-theme='dark'] & li button:hover,
  li.off button {
    opacity: 0.2;
  }
  li.off button:hover,
  li.off button:focus {
    background: transparent;
  }

  li button .SVGInline {
    margin-right: 8px;
  }
  li button .SVGInline svg {
    width: auto;
    height: 15px;
    vertical-align: middle;
  }
`,En=({open:e,dimension:t,menus:n})=>r().createElement(Cn,{className:e?"on":"",style:t},n.filter((e=>!0!==e.hide)).map(((e,t)=>r().createElement("li",{key:t,className:e.disabled?"off":""},r().createElement("button",{onClick:e.click,disabled:e.disabled},e.icon&&r().createElement(Se,{svg:e.icon}),e.label)))));async function wn(e){return(await g("/mrx-link/snippets/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)})).code}function yn(e){return e.trim().toLowerCase()}const kn=S().div`
  --snippet-font-xs: 11px;
  --snippet-font-sm: 13px;
  --snippet-space-1: 4px;
  --snippet-space-2: 8px;
  --snippet-space-3: 12px;
  --snippet-space-4: 16px;
  --snippet-card-border: var(--Color-border-border-secondary, #f0f0f5);
  --snippet-pane-border: var(--Color-border-border-primary, #d1d4db);
  --snippet-surface: var(--Color-background-layer-background-surface, #f9fafb);
  --snippet-surface-hover: var(--Color-background-layer-background-surface-hover, #f3f4f6);
  --snippet-base: var(--Color-background-layer-background-base, #ffffff);
  --snippet-title-text: var(--Color-text-primary, #111827);
  --snippet-secondary-text: var(--Color-text-secondary, #48556a);
  --snippet-selected-bg: #e6e9fe;
  --snippet-selected-text: #6c79f9;
  --snippet-count-idle-bg: var(--Color-status-or-chip-bg-neutral, #e5e7eb);

  width: 100%;
  height: 100%;
  color: var(--text-primary);

  .selector {
    height: 100%;
    display: flex;
    flex-direction: column;
    gap: var(--snippet-space-4);
    padding: var(--snippet-space-4);
    box-sizing: border-box;
    border-radius: 16px;
    background: var(--snippet-base);
    box-shadow: 4px 4px 16px rgba(0, 0, 0, 0.25);
    outline: 1px solid var(--snippet-card-border);
    outline-offset: -1px;
  }

  .selector-body {
    display: grid;
    grid-template-columns: 183px minmax(250px, 1fr);
    height: 100%;
    min-height: 0;
    flex: 1 1 auto;
    overflow: hidden;
    border-radius: 16px;
    outline: 1px solid var(--snippet-card-border);
    outline-offset: -1px;
    background: var(--snippet-base);
  }

  .search-input-wrapper {
    padding: 0;
    background: transparent;
  }
  .search-input {
    height: 32px;
    display: flex;
    align-items: center;
    gap: var(--snippet-space-2);
    padding: 6px 12px;
    border: 1px solid var(--control-border, var(--border-primary));
    border-radius: 4px;
    background: var(--control-background, var(--background-base));
    color: var(--text-secondary);
    box-sizing: border-box;
  }
  .search-input:focus-within {
    border-color: var(--link-color);
  }
  .search-input .search-icon {
    display: inline-flex;
    flex: 0 0 auto;
    color: var(--text-secondary);
  }
  .search-input input {
    width: 100%;
    min-width: 0;
    border: 0;
    padding: 0;
    background: transparent;
    color: var(--text-primary);
    font-size: var(--snippet-font-sm);
    line-height: 16px;
    outline: none;
  }
  .search-input input::placeholder {
    color: var(--control-placeholder, #b0aebc);
  }

  .category-pane,
  .snippet-pane {
    background: var(--snippet-base);
    display: flex;
    flex-direction: column;
    min-height: 0;
  }
  .category-pane {
    background: var(--snippet-surface);
  }
  .snippet-pane {
    border-left: 1px solid var(--snippet-pane-border);
  }

  .pane-title {
    height: 40px;
    min-height: 40px;
    padding: 8px var(--snippet-space-4);
    display: flex;
    align-items: center;
    font-size: var(--snippet-font-xs);
    font-weight: 600;
    color: var(--snippet-title-text);
    border-bottom: 1px solid var(--snippet-card-border);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    box-sizing: border-box;
  }
  .pane-title .pane-title-text {
    width: 100%;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    line-height: 16px;
  }

  .category-list,
  .snippet-list {
    list-style: none;
    margin: 0;
    padding: 0;
    flex: 1 1 auto;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
  }

  .category-list li + li,
  .snippet-list li + li {
    border-top: 1px solid var(--snippet-card-border);
  }

  .category-list button {
    width: 100%;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-align: left;
    padding: 0 var(--snippet-space-4);
    gap: var(--snippet-space-2);
    font-size: var(--snippet-font-sm);
    font-weight: 500;
    color: var(--snippet-secondary-text);
    background: transparent;
  }
  .category-list button .name {
    min-width: 0;
    flex: 1 1 auto;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding-right: var(--snippet-space-2);
  }
  .category-list button:hover {
    background: var(--snippet-surface-hover);
  }
  .category-list button.selected {
    color: var(--snippet-selected-text);
    background: var(--snippet-selected-bg);
  }
  .category-list button .count {
    margin-left: auto;
    min-width: 16px;
    height: 16px;
    border-radius: 16px;
    background: var(--snippet-count-idle-bg);
    color: var(--snippet-secondary-text);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: var(--snippet-font-xs);
    font-weight: 500;
  }
  .category-list button.selected .count {
    color: var(--white);
    background: var(--link-color);
  }

  .snippet-item {
    width: 100%;
    height: auto;
    display: block;
    text-align: left;
    padding: var(--snippet-space-4) var(--snippet-space-3);
    background: transparent;
  }
  .snippet-item:hover {
    background: var(--snippet-surface-hover);
  }
  .snippet-item:disabled {
    opacity: 0.72;
    cursor: progress;
  }
  .snippet-name {
    display: block;
    width: 100%;
    font-size: var(--snippet-font-sm);
    line-height: 16px;
    font-weight: 500;
    color: var(--snippet-title-text);
    margin-bottom: var(--snippet-space-1);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .snippet-name .search-highlight {
    padding: 0 1px;
  }
  .snippet-description {
    display: -webkit-box;
    font-size: var(--snippet-font-xs);
    line-height: 16px;
    color: var(--snippet-secondary-text);
    overflow: hidden;
    text-overflow: ellipsis;
    overflow-wrap: anywhere;
    word-break: break-word;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .empty-message {
    padding: var(--snippet-space-4);
    color: var(--snippet-secondary-text);
    font-size: var(--snippet-font-xs);
  }
  .search-highlight {
    background: #ffe96c;
    border-radius: 2px;
    color: inherit;
    box-decoration-break: clone;
    -webkit-box-decoration-break: clone;
    mix-blend-mode: multiply;
  }
`,Ln=({onClose:e,cell:t,onSelectSnippetForParameter:n})=>{const[l,o]=(0,a.useState)([]),[i,s]=(0,a.useState)(""),[c,d]=(0,a.useState)(""),[p,m]=(0,a.useState)(!1),[h,v]=(0,a.useState)(!1),[f,x]=(0,a.useState)(""),b=(0,a.useRef)(null),C=(0,a.useMemo)((()=>yn(i)),[i]),E=(0,a.useCallback)((e=>{var t;o(e),d((null===(t=e[0])||void 0===t?void 0:t.name)||"")}),[]),w=(0,a.useCallback)((async()=>{m(!0),x("");try{const e=await async function(){return(await g("/mrx-link/snippets",{method:"GET"})).categories||[]}();E(e)}catch(e){const t=e instanceof Error?e.message:"Failed to load snippets";x(t),u.error(t),E([])}finally{m(!1)}}),[E]);(0,a.useEffect)((()=>{w()}),[w]),(0,a.useEffect)((()=>{b.current&&(b.current.scrollTop=0)}),[c]);const y=(0,a.useMemo)((()=>C?l.map((e=>Object.assign(Object.assign({},e),{snippets:e.snippets.filter((e=>e.display_name.toLowerCase().includes(C)))}))).filter((e=>e.snippets.length>0)):l),[l,C]);(0,a.useEffect)((()=>{0!==y.length?y.some((e=>e.name===c))||d(y[0].name):""!==c&&d("")}),[y,c]);const k=(0,a.useMemo)((()=>y.find((e=>e.name===c))||null),[y,c]);return r().createElement(kn,null,r().createElement("div",{className:"selector"},r().createElement("div",{className:"search-input-wrapper"},r().createElement("label",{className:"search-input",htmlFor:"custom-snippet-search-input"},r().createElement("span",{className:"search-icon"},Re),r().createElement("input",{id:"custom-snippet-search-input",type:"text",value:i,onChange:e=>s(e.target.value),placeholder:"Search...",autoComplete:"off",spellCheck:!1}))),r().createElement("div",{className:"selector-body"},r().createElement("div",{className:"category-pane"},r().createElement("div",{className:"pane-title pane-title-category"},r().createElement("span",{className:"pane-title-text"},"카테고리")),p?r().createElement("div",{className:"empty-message"},"Loading snippets..."):f?r().createElement("div",{className:"empty-message"},f):0===y.length?r().createElement("div",{className:"empty-message"},"No snippets found"):r().createElement("ul",{className:"category-list"},y.map((e=>r().createElement("li",{key:e.name},r().createElement("button",{type:"button",className:c===e.name?"selected":"",onClick:()=>d(e.name)},r().createElement("span",{className:"name"},e.name),r().createElement("span",{className:"count"},e.snippets.length))))))),r().createElement("div",{className:"snippet-pane"},r().createElement("div",{className:"pane-title pane-title-snippet"},r().createElement("span",{className:"pane-title-text",title:(null==k?void 0:k.name)||"Snippets"},(null==k?void 0:k.name)||"Snippets")),k&&0!==k.snippets.length?r().createElement("ul",{className:"snippet-list",ref:b},k.snippets.map((a=>r().createElement("li",{key:`${a.category}/${a.snippet_id}`},r().createElement("button",{className:"snippet-item",type:"button",onClick:()=>{(async a=>{Object.keys(a.parameters||{}).length>0?(n(a),e()):await(async n=>{try{v(!0);const a=await wn({category:n.category,snippet_id:n.snippet_id,parameters:{}}),r=t.model.sharedModel,l=r.getSource();r.setSource(`${l}${l.length>0?"\n\n":""}${a}`),e()}catch(e){const t=e instanceof Error?e.message:"Failed to generate snippet code";u.error(t)}finally{v(!1)}})(a)})(a)},disabled:h},r().createElement("div",{className:"snippet-name",title:a.display_name},function(e,t){const n=yn(t);if(!n)return e;const a=e.toLowerCase(),l=[];let o=0,i=0;for(;o<e.length;){const t=a.indexOf(n,o);if(-1===t){l.push(e.slice(o));break}t>o&&l.push(e.slice(o,t)),l.push(r().createElement("mark",{className:"search-highlight",key:`highlight-${i}`},e.slice(t,t+n.length))),o=t+n.length,i+=1}return l}(a.display_name,i)),a.description&&r().createElement("div",{className:"snippet-description"},a.description)))))):r().createElement("div",{className:"empty-message"},"No snippets in this category")))))},_n=({setRenderType:e})=>r().createElement(Kt,{title:"Add to Pipeline",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:()=>{e(zt.componentForm)},className:"add-button"},On)),Mn=(0,_.x)((e=>{const{widgetElement:t,setRenderType:n}=e,[l,o]=(0,a.useState)(!1),i=(0,a.useRef)(null);return(0,a.useEffect)((()=>{function e(e){var t;const n=e.target;l&&!(null===(t=i.current)||void 0===t?void 0:t.contains(n))&&o(!1)}const t=document.body;return t.addEventListener("mousedown",e,!0),()=>{t.removeEventListener("mousedown",e,!0)}}),[l]),(0,a.useEffect)((()=>{t.style.overflow=l?"visible":"hidden"}),[l]),y.value?r().createElement(An,{ref:i},r().createElement(Kt,{title:"Add Runway Snippet",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:()=>o(!0),className:"runway-menu icon-circle-button"},Pn)),r().createElement(En,{open:l,dimension:{width:"200px",left:"12px",top:"33px"},menus:[{label:"Import Dataset",click:()=>n(zt.importDataset)},{label:"Upload Dataset",click:()=>n(zt.uploadDataset)}]})):null})),Sn=({widgetElement:e,cell:t,onSelectSnippetForParameter:n})=>{const[l,o]=(0,a.useState)(!1),i=(0,a.useRef)(null),s=(0,a.useRef)(null);return(0,a.useEffect)((()=>{function e(e){var t;const n=e.target;l&&!(null===(t=i.current)||void 0===t?void 0:t.contains(n))&&o(!1)}const t=document.body;return t.addEventListener("mousedown",e,!0),()=>{t.removeEventListener("mousedown",e,!0)}}),[l]),(0,a.useEffect)((()=>(null===s.current&&(s.current=e.style.overflow),e.style.overflow=l?"visible":"hidden",()=>{null!==s.current&&(e.style.overflow=s.current)})),[l,e]),r().createElement(In,{ref:i},r().createElement(Kt,{title:"Add Custom Snippet",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:()=>o((e=>!e)),className:"custom-snippet-button icon-circle-button"},Tn)),l&&r().createElement("div",{className:"custom-snippet-popover"},r().createElement(Ln,{onClose:()=>o(!1),cell:t,onSelectSnippetForParameter:n})))},Nn=S().div`
  .add-button svg:hover circle {
    fill: #95a0ff;
  }
  body[data-theme='dark'] & .add-button svg:hover circle {
    fill: #5361ce;
  }

  .icon-circle-button {
    margin-left: 12px;
  }
  .icon-circle-button svg:hover circle {
    fill: var(--icon-circle-hover);
  }
  body[data-theme='dark'] & .icon-circle-button svg:hover circle {
    fill: var(--icon-circle-hover-dark, var(--icon-circle-hover));
  }

  .runway-menu {
    --icon-circle-hover: #a96ef5;
    --icon-circle-hover-dark: #763bc2;
  }

  .custom-snippet-button {
    --icon-circle-hover: #3150f5;
    --icon-circle-hover-dark: #3150f5;
  }
  .custom-snippet-button svg circle {
    fill: #5f73ff;
  }
  .custom-snippet-button svg:active circle,
  .custom-snippet-button:active svg circle {
    fill: #1b36d8;
  }
`,An=S().div`
  position: relative;
  display: inline-block;

  ul button {
    padding-left: 8px;
  }
  ul li button .SVGInline {
    margin-right: 4px;
  }
  ul li button .SVGInline svg {
    height: 24px;
  }
`,In=S().div`
  position: relative;
  display: inline-block;

  .custom-snippet-popover {
    position: absolute;
    top: 36px;
    left: -8px;
    width: 480px;
    height: 410px;
    z-index: 1000;
    overflow: hidden;
    display: flex;
    border-radius: 16px;
    box-shadow: var(--popover-shadow);
  }
`,On=r().createElement("svg",{className:"add-button",width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("circle",{cx:"14",cy:"14",r:"14",fill:"#6C79F9"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M13.2829 19H14.7115C15.1401 19 15.4258 18.7143 15.4258 18.2857V15.4289H18.2857C18.7143 15.4289 19 15.1432 19 14.7146V13.2861C19 12.8575 18.7143 12.5718 18.2857 12.5718H15.4258V9.71429C15.4258 9.28571 15.1401 9 14.7115 9H13.2829C12.8544 9 12.5686 9.28571 12.5686 9.71429L12.5686 12.5718H9.71429C9.28571 12.5718 9 12.8575 9 13.2861V14.7146C9 15.1432 9.28571 15.4289 9.71429 15.4289H12.5686L12.5686 18.2857C12.5686 18.7143 12.8544 19 13.2829 19Z",fill:"#FFFFFF"})),Pn=r().createElement("svg",{width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("circle",{cx:"14",cy:"14",r:"14",fill:"#944AF2"}),r().createElement("path",{d:"M11.4 16.6749L9.888 18.0999L6 14.4999L9.888 10.8999L11.4 12.3249L9.051 14.4999L11.4 16.6749Z",fill:"white"}),r().createElement("path",{d:"M16.8002 16.6749L18.3122 18.0999L22.2002 14.4999L18.3122 10.8999L16.8002 12.3249L19.1492 14.4999L16.8002 16.6749Z",fill:"white"}),r().createElement("path",{d:"M16.5921 10L13.3161 19H11.4009L14.6769 10H16.5921Z",fill:"white"})),Tn=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"28",height:"28",viewBox:"0 0 28 28",fill:"none"},r().createElement("circle",{cx:"14",cy:"14",r:"14",fill:"#5F73FF"}),r().createElement("rect",{x:"10",y:"7",width:"9",height:"2",rx:"1",fill:"white"}),r().createElement("rect",{x:"7",y:"10",width:"9",height:"2",rx:"1",fill:"white"}),r().createElement("rect",{x:"6",y:"16",width:"11",height:"2",rx:"1",fill:"white"}),r().createElement("rect",{x:"11",y:"19",width:"7",height:"2",rx:"1",fill:"white"}),r().createElement("rect",{x:"9",y:"13",width:"12",height:"2",rx:"1",fill:"white"})),Fn=({widgetElement:e,cell:t,setRenderType:n,onSelectSnippetForParameter:a})=>r().createElement(Nn,null,r().createElement(_n,{setRenderType:n}),r().createElement(Mn,{widgetElement:e,setRenderType:n}),r().createElement(Sn,{widgetElement:e,cell:t,onSelectSnippetForParameter:a}));var Vn=n(12055);const Hn=`${s.PageConfig.getBaseUrl()}mrx-link/runway`,Rn={"Cache-Control":"no-cache, no-store, must-revalidate, max-age=0"};async function zn(){return fetch(`${Hn}/datasets`,{method:"GET",headers:Rn}).then((e=>e.json().then((e=>e.data_snapshots||[])).catch((e=>[]))))}function Zn(e){const t=e.file_path_at_link;if(!t.endsWith(`/v${e.version}`))return t;const n=t.lastIndexOf(`/v${e.version}`);return t.substring(0,n)+"/latest"}const Bn=S().div`
  box-sizing: border-box;
  width: 100%;
  height: 33px;
  padding: 0 12px;
  border-radius: 4px;

  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;

  background: var(--control-background);
  color: var(--control-text);
  border: 1px solid ${e=>e.active?"var(--control-border-focused)":"var(--control-border)"};

  .selected-value {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .chevron-icon {
    display: flex;

    &.up {
      transform: rotate(180deg);
    }
  }
`,jn=S().div`
  display: flex;
  max-height: 320px;

  .option-list {
    box-sizing: border-box;
    display: flex;
    overflow-y: auto;
    flex-direction: column;
    padding: 8px 0;
    border-radius: 4px;
    border: 1px solid var(--background-surface-border);
    background: var(--background-base);

    &.dataset-list {
      width: ${e=>`${e.datasetListWidth}px`};
    }

    &.version-list {
      position: fixed;
      top: ${e=>e.datasetElBox.top}px;
      left: ${e=>e.datasetElBox.right}px;
      display: ${e=>e.showVersions?"flex":"none"};
      width: 160px;
      max-height: 320px;
      overflow-y: auto;
    }
  }

  .option-item {
    box-sizing: border-box;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: 38px;
    line-height: 38px;
    padding: 0 16px;
    cursor: pointer;

    &:hover,
    &.hovered {
      background: var(--control-background-hover);
    }

    &.empty {
      justify-content: center;
      color: var(--text-secondary);

      &:hover {
        background: none;
      }

      cursor: default;
    }
  }

  .option-item .value {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .search-bar {
    margin: 4px 12px;
    padding: 6px 8px;
    display: flex;
    align-items: center;
    gap: 4px;
    border-radius: 4px;
    border: 1px solid var(--control-border);

    .search-icon {
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
    }

    input {
      flex: 1;
      border: none;
      overflow: hidden;
      text-overflow: ellipsis;

      &:focus {
        outline: none;
      }
    }
  }

  .chevron-icon {
    display: flex;
    transform: rotate(270deg);
  }
`,Dn=({initialValue:e,onChange:t,style:n})=>{const[l,o]=r().useState(null),i=(0,a.useMemo)((()=>Boolean(l)),[l]),s=(0,a.useMemo)((()=>{var e;return null!==(e=null==l?void 0:l.offsetWidth)&&void 0!==e?e:0}),[l]),[c,d]=(0,a.useState)(""),[p,m]=(0,a.useState)([]),[u,h]=(0,a.useState)(null),[g,v]=(0,a.useState)(null),f=(0,a.useMemo)((()=>{var e;return null!==(e=null==u?void 0:u.data_snapshot_versions.filter((e=>"ready"===e.status)).sort(((e,t)=>t.version-e.version)))&&void 0!==e?e:[]}),[u]),x=(0,a.useMemo)((()=>({top:(null==g?void 0:g.getBoundingClientRect().top)||0,right:(null==g?void 0:g.getBoundingClientRect().right)||0})),[g]),b=(0,a.useMemo)((()=>p.filter((e=>!c||e.name.toLowerCase().includes(c.toLowerCase())))),[p,c]),C=(0,a.useMemo)((()=>u&&0!==f.length?f.reduce(((e,t)=>e.version>t.version?e:t),u.data_snapshot_versions[0]):null),[u,f]),E=(0,a.useMemo)((()=>e&&e.dataset&&e.isLatest?`${e.dataset.name}/latest`:e&&e.dataset&&e.version?`${e.dataset.name}/v.${e.version.version}`:""),[e]);function w(){o(null),y(null,null)}function y(e,t){h(e),v(t)}return(0,a.useEffect)((()=>{zn().then((e=>{const t=e.filter((e=>e.data_snapshot_versions.filter((e=>"ready"===e.status)).length>0));m(t)})).catch((()=>{m([])}))}),[]),(0,a.useEffect)((()=>{i||d("")}),[i]),r().createElement(r().Fragment,null,r().createElement(Bn,{active:i,onClick:e=>o(e.currentTarget),style:n,"aria-hidden":"true"},r().createElement("div",{className:"selected-value",title:E},E),r().createElement("div",{className:"chevron-icon "+(i?"up":"down")},He)),r().createElement(Vn.Ay,{anchorEl:l,open:i,onClose:w,anchorOrigin:{vertical:"bottom",horizontal:"left"},transformOrigin:{vertical:"top",horizontal:"left"}},r().createElement(jn,{showVersions:Boolean(u),datasetListWidth:s,onMouseLeave:()=>y(null,null),datasetElBox:x},r().createElement("div",{className:"option-list dataset-list"},r().createElement("div",{className:"search-bar"},Re,r().createElement("input",{type:"text",placeholder:"Search dataset name",value:c,onChange:e=>d(e.target.value)})),b.map((e=>r().createElement("div",{key:e.id,className:"option-item dataset "+((null==u?void 0:u.id)===e.id?"hovered":""),onMouseEnter:t=>y(e,t.currentTarget),"aria-hidden":"true"},r().createElement("div",{className:"value",title:e.name},e.name),r().createElement("div",{className:"chevron-icon right"},Ve)))),0===b.length&&r().createElement("div",{className:"option-item empty"},"No datasets")),r().createElement("div",{className:"option-list version-list"},u&&f.length>0&&C&&r().createElement("div",{className:"option-item version latest",onClick:()=>{t(u,C,!0),w()},"aria-hidden":"true"},r().createElement("div",{className:"value",title:"latest version"},"Latest")),u&&f.length>0&&f.map((e=>r().createElement("div",{key:e.id,className:"option-item version",onClick:()=>{t(u,e,!1),w()},"aria-hidden":"true"},r().createElement("div",{className:"value",title:`v.${e.version}`},"v.",e.version))))))))},Wn=S().form`
  display: flex;
`,Un=({setRenderType:e,cell:t,commands:n})=>{const[l,o]=(0,a.useState)(!1),[i,s]=(0,a.useState)(null),[c,d]=(0,a.useState)(null),[p,m]=(0,a.useState)(!1);return(0,a.useEffect)((()=>{o(null!==i&&null!==c)}),[i,c]),r().createElement(Wn,{onSubmit:async a=>{if(a.preventDefault(),null===i||null===c)return;const r=(()=>{const e="RUNWAY_DATASET_DIR",t=di.currentWidget.metadata.parameters.filter((t=>0===t.name.indexOf(e)));if(0===t.length)return e;const n=t.map((e=>Number(e.name.substring(19)))).filter((e=>Number.isInteger(e))),a=n.length>0?Math.max.apply(null,n):0;return`${e}_${a+1}`})();((e,t,a,r)=>{const l=[...di.currentWidget.metadata.parameters,{name:r,value:`"${a?Zn(t):t.file_path_at_link}"`,type:"str",metadata:{resource_type:"runway_dataset",resource_id:e.id,dataset_version_id:t.id,is_latest:a,resource_name:e.name}}];n.execute(Rt.dagParameters,l),di.currentWidget.metadata.parameters=l})(i,c,p,r),await(async(e,n,a)=>{const r=await async function(e,t){const n=`${Hn}/datasets/code-snippet?${[`dataset_id=${e}`,`dataset_version_id=${t}`].join("&")}`;return fetch(n,{method:"GET",headers:Rn}).then((e=>e.json())).then((e=>e.code_snippet))}(e.id,n.id);if(r){const e=r.replace(/RUNWAY_DATA_PATH|RUNWAY_DATASET_DIR/g,a),n=t.model.sharedModel,l=n.getSource();n.setSource(`${l}${l.length>0?"\n\n":""}${e}`)}})(i,c,r),e(zt.default)}},r().createElement(pn,{className:"form-control"},r().createElement(Dn,{initialValue:{dataset:i,version:c,isLatest:p},onChange:(e,t,n)=>{s(e),d(t),m(n)}})),r().createElement(Kt,{title:l?"Save":"",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"submit",className:"primary",disabled:!l},r().createElement(Se,{svg:rn}))),r().createElement(Kt,{title:"Cancel",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:()=>{e(zt.default)},className:"danger"},r().createElement(Se,{svg:ln}))))};function $n(e){var t;if(!e.env||!e.env.RUNWAY_URL)throw new Error("RUNWAY_URL is not defined");return`//${null===(t=e.env)||void 0===t?void 0:t.RUNWAY_URL}/v1`}async function Gn(){const e=await L.getRunwayInfo(),t=`${$n(e)}/link/workspaces/${e.env.WORKSPACE_ID}/projects/${e.env.PROJECT_ID}`;return fetch(t,{method:"GET",headers:{Authorization:`Bearer ${e.env.JWT_TOKEN}`}}).then((e=>e.json())).then((e=>e.project))}const qn=S().form`
  display: flex;

  & > button {
    margin-top: 17px;
  }

  .method-sample {
    position: relative;
    top: -3px;
    min-width: 400px;
    max-width: 600px;
    margin-left: 8px;
  }

  .method-sample .row {
    position: relative;
    display: flex;
    align-items: end;
    padding: 0 4px 4px;
  }

  .method-sample .row:before {
    position: absolute;
    z-index: 0;
    content: ' ';
    background: var(--background-surface);
    top: 16px;
    right: 0;
    bottom: 0;
    left: 0;
  }
  .method-sample .row:not(:first-of-type):before {
    top: 0;
  }

  .method-sample .row .MuiInputLabel-root {
    margin-bottom: 7px;
  }
  .method-sample .row:not(:first-of-type) .MuiInputLabel-root {
    display: none;
  }

  .method-sample .form-control {
    z-index: 1;
  }

  .method-sample .row button {
    position: relative;
    z-index: 1;
    margin: 0 0 4px 4px;
    width: 20px;
    height: 20px;
  }

  .method-sample .row button svg {
    width: 20px;
    height: 20px;
  }
  .method-sample .row button:disabled svg {
    opacity: 0.3;
  }

  body[data-theme='dark'] & .method-sample .row button svg rect {
    fill: #333;
    stroke: #555;
  }

  .method-sample > button {
    position: absolute;
    top: -11px;
    right: 0;
    font-weight: 700;
    font-size: 13px;
    line-height: 15px;
    color: var(--link-color);
    width: auto;
    height: auto;
    padding: 6px;
    border-radius: 4px;
  }
  .method-sample > button:hover {
    background: #f8f7f8;
  }
  body[data-theme='dark'] & .method-sample > button:hover {
    background: #222;
  }
`,Kn=r().createElement("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("rect",{x:"0.5",y:"0.5",width:"19",height:"19",rx:"3.5",fill:"white",stroke:"#E0E0E0"}),r().createElement("path",{d:"M13.6364 9.48623H9.63636H9.36364H6.36364C6.07996 9.48623 5.85 9.71619 5.85 9.99987C5.85 10.2835 6.07996 10.5135 6.36364 10.5135H9.36364H9.63636H13.6364C13.92 10.5135 14.15 10.2835 14.15 9.99987C14.15 9.71619 13.92 9.48623 13.6364 9.48623Z",fill:"#999999",stroke:"#999999",strokeWidth:"0.3",strokeLinecap:"round"})),Yn=({setRenderType:e,cell:t})=>{const[n,l]=(0,a.useState)({modelName:"",variableName:"",method:[""],inputSample:[""]}),[o,i]=(0,a.useState)(!1),[s,c]=(0,a.useState)(!1),[d,p]=(0,a.useState)(""),m=(0,a.useRef)(null),u=e=>{let t=e.target.value;if("modelName"===e.target.name&&i(!0),"modelName"===e.target.name&&t.length>30&&(t=t.substring(0,30)),null!==m.current&&("method"===e.target.name||"inputSample"===e.target.name)){const n=m.current[e.target.name];t=n.length?[...n].map((e=>e.value)):[n.value]}l((n=>Object.assign(Object.assign({},n),{[e.target.name]:t})))},h=e=>{n.method.splice(e,1),n.inputSample.splice(e,1),l(Object.assign({},n))};return(0,a.useEffect)((()=>{const e=n.variableName.length>0,t=n.method.length>0&&0===n.method.filter((e=>0===e.length)).length,a=n.inputSample.length>0&&0===n.inputSample.filter((e=>0===e.length)).length;c((0===n.modelName.length?(p(""),!1):o&&!new RegExp(/^[a-zA-Z\d-]+$/g).test(n.modelName)?(p("Invalid (English letters, numbers, ‘-’ only)"),!1):(p(""),!0))&&e&&t&&a)}),[n]),r().createElement(qn,{ref:m,onSubmit:a=>{a.preventDefault(),(async(e,n,a,r)=>{const l=await async function(e,t,n,a){const r=await L.getRunwayInfo(),l=[`model_name=${e}`,`variable_name=${t}`,n.map((e=>`methods=${e}`)).join("&"),a.map((e=>`input_samples=${e}`)).join("&")],o=`${$n(r)}/link-internal/projects/${r.env.PROJECT_ID}/models/code-snippet?${l.join("&")}`;return fetch(o).then((e=>e.json())).then((e=>e.code_snippet))}(e,n,a,r);if(l){const e=t.model.sharedModel,n=e.getSource();e.setSource(`${n}${n.length>0?"\n\n":""}${l}`)}})(n.modelName,n.variableName,n.method,n.inputSample),e(zt.default)}},r().createElement(pn,{className:"form-control"},r().createElement(sn,{valueLength:n.modelName.length,maxLength:30,errorMessage:d},r().createElement(N.TextField,{label:"Model Name",name:"modelName",value:n.modelName,onChange:u,placeholder:"Enter the model name",required:!0,error:d.length>0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",autoFocus:!0,InputLabelProps:{shrink:!0},inputProps:{maxLength:30}}))),r().createElement(pn,{className:"form-control"},r().createElement(N.TextField,{label:"Model Variable Name",name:"variableName",value:n.variableName,onChange:u,placeholder:"Enter the model variable name",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0}})),r().createElement("div",{className:"method-sample"},(()=>{const e=[];for(let t=0;t<n.method.length;t++)e.push({method:n.method[t],inputSample:n.inputSample[t]});return e})().map(((e,t)=>r().createElement("div",{className:"row",key:t},r().createElement(pn,{className:"form-control"},r().createElement(N.TextField,{label:"Method",name:"method",value:e.method,onChange:u,placeholder:"Enter the method",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0}})),r().createElement(pn,{className:"form-control"},r().createElement(N.TextField,{label:"Input Sample",name:"inputSample",value:e.inputSample,onChange:u,placeholder:"Enter the input sample",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0}})),r().createElement(Kt,{title:n.method.length>1?"Delete":"",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{key:t,type:"button",onClick:h.bind(null,t),disabled:1===n.method.length},Kn))))),r().createElement("button",{onClick:()=>{n.method.push(""),n.inputSample.push(""),l(Object.assign({},n))},type:"button"},"+ Add")),r().createElement(Kt,{title:s?"Upload":"",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"submit",className:"primary",disabled:!s},r().createElement(Se,{svg:rn}))),r().createElement(Kt,{title:"Cancel",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:()=>{e(zt.default)},className:"danger"},r().createElement(Se,{svg:ln}))))},Xn=S().form`
  display: flex;

  & > button {
    margin-top: 17px;
  }
`,Jn=S().li`
  div {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`,Qn=({setRenderType:e,cell:t})=>{const[n,l]=(0,a.useState)(""),[o,i]=(0,a.useState)(!1),[s,c]=(0,a.useState)([]),[d,p]=(0,a.useState)(null);return(0,a.useEffect)((()=>{!async function(){const e=await async function(){const e=await L.getRunwayInfo(),t=`${$n(e)}/link-internal/projects/${e.env.PROJECT_ID}/models`;return fetch(t).then((e=>e.json())).then((e=>e.models))}();e&&c(e)}()}),[]),(0,a.useEffect)((()=>{i(n.length>0&&null!==d)}),[n,d]),r().createElement(Xn,{onSubmit:async a=>{a.preventDefault(),null!==d&&(await(async(e,n)=>{const a=await async function(e,t){const n=await L.getRunwayInfo(),a=`${$n(n)}/link-internal/projects/${n.env.PROJECT_ID}/models/${e}/code-snippet?variable_name=${t}`;return fetch(a).then((e=>e.json())).then((e=>e.code_snippet))}(e.id,n);if(a){const e=t.model.sharedModel,n=e.getSource();e.setSource(`${n}${n.length>0?"\n\n":""}${a}`)}})(d,n),e(zt.default))}},r().createElement(pn,{className:"form-control"},r().createElement(N.TextField,{label:"Variable Name",value:n,onChange:e=>{l(e.target.value)},placeholder:"Define the model variable name",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",autoFocus:!0,InputLabelProps:{shrink:!0}})),r().createElement(pn,{className:"form-control"},r().createElement(N.Autocomplete,{size:"small",onChange:(e,t)=>{p(t)},options:s,getOptionLabel:e=>e?e.name:"",isOptionEqualToValue:(e,t)=>e.id===t.id,PaperComponent:dn,value:d,noOptionsText:"No Results",renderInput:e=>r().createElement(N.TextField,Object.assign({},e,{label:"Model",placeholder:"Search or select a model",required:!0,size:"small",fullWidth:!0,margin:"normal",variant:"outlined",autoComplete:"off",InputLabelProps:{shrink:!0}})),renderOption:(e,t,{selected:n})=>r().createElement(Jn,Object.assign({},e),r().createElement("div",null,t.name))})),r().createElement(Kt,{title:o?"Save":"",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"submit",className:"primary",disabled:!o},r().createElement(Se,{svg:rn}))),r().createElement(Kt,{title:"Cancel",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:()=>{e(zt.default)},className:"danger"},r().createElement(Se,{svg:ln}))))},ea=[{id:"csv",label:"CSV file(*.csv)"},{id:"npy",label:"NumPy file (*.npy)"},{id:"parquet",label:"Parquet file(*.parquet)"},{id:"pickle",label:"Pickle file(*.pkl)"}],ta=S().form`
  display: flex;

  & > button {
    margin-top: 17px;
  }
`,na=({setRenderType:e,cell:t})=>{const[n,l]=(0,a.useState)(""),[o,i]=(0,a.useState)(""),[s,c]=(0,a.useState)(null),[d,p]=(0,a.useState)(!1),[m,u]=(0,a.useState)(!1),h=()=>{e(zt.default)},g=()=>/^[a-zA-Z0-9-_]{1,30}$/.test(n);return(0,a.useEffect)((()=>{const e=(()=>{const e=g(),t=o.length>0;return e&&t&&null!==s})();p(e)}),[n,o,s]),(0,a.useEffect)((()=>{const e=g(),t=n.length>0&&!e;u(t)}),[n]),r().createElement(ta,{onSubmit:async e=>{if(e.preventDefault(),!s)return;const a=await(async(e,t,n)=>{const a=await async function(e,t,n){const a=`${Hn}/datasets/tabular/code-snippet?${[`name=${e}`,`data=${t}`,`file_type=${n}`].join("&")}`;return fetch(a,{method:"GET",headers:Rn}).then((e=>e.json())).then((e=>e.code_snippet))}(e,t,n);return a||"# Failed to get upload dataset code snippet"})(n,o,s.id);(async e=>{const n=t.model.sharedModel,a=n.getSource();n.setSource(`${a}${a.length>0?"\n\n":""}${e}`)})(a),h()}},r().createElement(pn,{className:"form-control"},r().createElement(sn,{valueLength:n.length,maxLength:30},r().createElement(N.TextField,{label:"Dataset Name",value:n,onChange:e=>l(e.target.value),placeholder:"Enter the dataset name",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",autoFocus:!0,inputProps:{maxLength:30},InputLabelProps:{shrink:!0},error:m,helperText:m&&"Invalid (English letters, numbers, ‘-’, ‘_’ only)"}))),r().createElement(pn,{className:"form-control"},r().createElement(N.TextField,{label:"Object Name",value:o,onChange:e=>i(e.target.value),placeholder:"pandas.DataFrame or numpy.array",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0}})),r().createElement(pn,{className:"form-control"},r().createElement(N.Autocomplete,{size:"small",onChange:(e,t)=>c(t),options:ea,getOptionLabel:e=>e.label,isOptionEqualToValue:(e,t)=>e.id===t.id,PaperComponent:dn,value:s,noOptionsText:"No Results",renderInput:e=>r().createElement(N.TextField,Object.assign({},e,{label:"Save As Type",placeholder:"Search or select a file type",required:!0,size:"small",fullWidth:!0,margin:"normal",variant:"outlined",autoComplete:"off",InputLabelProps:{shrink:!0}})),renderOption:(e,t)=>r().createElement(Jn,Object.assign({},e),t.label)})),r().createElement(Kt,{title:d?"Save":"",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"submit",className:"primary",disabled:!d},r().createElement(Se,{svg:rn}))),r().createElement(Kt,{title:"Cancel",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{onClick:h,className:"danger"},r().createElement(Se,{svg:ln}))))},aa="docs.live.mrxrunway.ai",ra=new class{constructor(){this.setManualHostFromAPI=async()=>async function(){const e=`${$n(await L.getRunwayInfo())}/cluster/hosts/manual`;return fetch(e,{method:"GET"}).then((e=>e.json()))}().then((e=>this.host=e.host||aa)).catch((()=>this.host=aa)),this.getCurrentProtocol=()=>location.protocol.startsWith("http")?"http://":"https://",(0,ce.makeAutoObservable)(this,{host:ce.observable,origin:ce.computed}),this.host=aa,this.setManualHostFromAPI()}get origin(){return`${this.getCurrentProtocol()}${this.host}`}},la=(0,jt.observer)((({path:e,title:t})=>r().createElement(ia,{href:`${ra.origin}/${e}`,target:"_blank",rel:"noreferrer"},t," ",oa))),oa=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"14",height:"15",viewBox:"0 0 14 15",fill:"none"},r().createElement("path",{d:"M2.91667 12.75C2.59583 12.75 2.32118 12.6358 2.09271 12.4073C1.86424 12.1788 1.75 11.9042 1.75 11.5833V3.41667C1.75 3.09583 1.86424 2.82118 2.09271 2.59271C2.32118 2.36424 2.59583 2.25 2.91667 2.25H7V3.41667H2.91667V11.5833H11.0833V7.5H12.25V11.5833C12.25 11.9042 12.1358 12.1788 11.9073 12.4073C11.6788 12.6358 11.4042 12.75 11.0833 12.75H2.91667ZM5.65833 9.65833L4.84167 8.84167L10.2667 3.41667H8.16667V2.25H12.25V6.33333H11.0833V4.23333L5.65833 9.65833Z",fill:"var(--text-link)"})),ia=S().a`
  display: flex;
  gap: 4px;
  align-items: center;

  color: var(--text-link);
  font-size: 13px;
  font-weight: 400;
  text-decoration-line: underline;

  &:hover {
    color: var(--text-link);
    text-decoration-line: underline;
  }
`,sa=la,ca=S().div`
  display: flex;
  gap: 6px;

  .guide-chip {
    height: 16px;
    line-height: 16px;
    background-color: var(--background-surface);
    padding: 0 2px;
    border-radius: 4px;
  }
`,da=({title:e})=>r().createElement(ca,null,r().createElement(va,null,e),r().createElement("span",{className:"guide-chip"},r().createElement(sa,{path:"Guide/ml_development/dev_instances/dataset",title:"Tips for using a dataset"}))),pa=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"18",height:"15",viewBox:"0 0 24 20",fill:"none"},r().createElement("rect",{x:"6",width:"14",height:"3",rx:"1.5",fill:"#5A6EFF"}),r().createElement("rect",{x:"2",y:"4",width:"14",height:"3",rx:"1.5",fill:"#57A5FF"}),r().createElement("rect",{y:"9",width:"17",height:"3",rx:"1.5",fill:"#FDBA4A"}),r().createElement("rect",{x:"8",y:"13",width:"11",height:"3",rx:"1.5",fill:"#A855F7"}),r().createElement("rect",{x:"6",y:"17",width:"12",height:"3",rx:"1.5",fill:"#EC4899"})),ma=S().form`
  --snippet-font-xs: 11px;
  --snippet-font-sm: 13px;
  --snippet-font-lg: 15px;
  --snippet-space-1: 4px;
  --snippet-space-2: 8px;
  --snippet-space-4: 16px;

  display: flex;
  flex-direction: column;
  gap: var(--snippet-space-4);

  .snippet-info {
    display: flex;
    flex-direction: column;
    gap: var(--snippet-space-1);
  }
  .snippet-info .title-row {
    display: flex;
    align-items: center;
    gap: var(--snippet-space-1);
  }
  .snippet-info h2 {
    margin: 0;
    font-size: var(--snippet-font-lg);
    line-height: 20px;
    font-weight: 600;
    color: var(--text-primary);
  }
  .snippet-info p {
    margin: 0;
    font-size: var(--snippet-font-sm);
    line-height: 17px;
    color: var(--text-secondary);
  }

  .editor-row {
    display: flex;
    width: 100%;
    align-items: flex-end;
    gap: var(--snippet-space-4);
  }

  .parameter-grid {
    flex: 1 1 auto;
    display: grid;
    grid-template-columns: repeat(3, minmax(180px, 1fr));
    gap: var(--snippet-space-4);
  }

  .parameter-item label {
    display: block;
    margin-bottom: var(--snippet-space-1);
    font-size: var(--snippet-font-sm);
    line-height: 17px;
    font-weight: 500;
    color: var(--text-primary);
  }
  .parameter-item .required {
    color: #d17c7f;
    margin-left: var(--snippet-space-1);
  }
  .parameter-item .description {
    margin: 0 0 var(--snippet-space-1);
    color: var(--text-secondary);
    font-size: var(--snippet-font-xs);
    line-height: 14px;
    min-height: 14px;
  }
  .parameter-item .snippet-input .MuiInputBase-root {
    height: 28px;
  }
  .parameter-item .snippet-input .MuiInputBase-input {
    padding: var(--snippet-space-1) var(--snippet-space-2);
    font-size: 12px;
    line-height: 16px;
  }
  .parameter-item .error-text {
    margin: 2px 0 0;
    font-size: var(--snippet-font-xs);
    line-height: 14px;
    color: #d17c7f;
  }

  .parameter-actions {
    display: flex;
    align-items: center;
    gap: var(--snippet-space-2);
    padding-bottom: 2px;
    flex: 0 0 auto;
  }
  .parameter-actions button.primary {
    margin-left: 0 !important;
  }

  @media (max-width: 1200px) {
    .editor-row {
      flex-direction: column;
      align-items: stretch;
      gap: var(--snippet-space-2);
    }

    .parameter-grid {
      grid-template-columns: repeat(2, minmax(180px, 1fr));
    }

    .parameter-actions {
      justify-content: flex-end;
      padding-bottom: 0;
    }
  }

  @media (max-width: 860px) {
    .parameter-grid {
      grid-template-columns: 1fr;
    }
  }
`,ua=({snippet:e,cell:t,onCancel:n,onComplete:l})=>{const[o,i]=(0,a.useState)({}),[s,c]=(0,a.useState)({}),[d,p]=(0,a.useState)(!1),m=(0,a.useMemo)((()=>Object.entries(e.parameters||{})),[e]);return(0,a.useEffect)((()=>{const e={};m.forEach((([t])=>{e[t]=""})),i(e),c({})}),[m]),r().createElement(ma,{onSubmit:async n=>{n.preventDefault();const a={};if(m.forEach((([e,t])=>{t.required&&!(o[e]||"").trim()&&(a[e]="Required")})),Object.keys(a).length>0)c(a);else try{p(!0);const n=await wn({category:e.category,snippet_id:e.snippet_id,parameters:o}),a=t.model.sharedModel,r=a.getSource();a.setSource(`${r}${r.length>0?"\n\n":""}${n}`),l()}catch(e){const t=e instanceof Error?e.message:"Failed to generate snippet code";u.error(t)}finally{p(!1)}},noValidate:!0},r().createElement("div",{className:"snippet-info"},r().createElement("div",{className:"title-row"},pa,r().createElement("h2",null,e.display_name)),e.description&&r().createElement("p",null,e.description)),r().createElement("div",{className:"editor-row"},r().createElement("div",{className:"parameter-grid"},m.map((([e,t])=>r().createElement("div",{key:e,className:"parameter-item"},r().createElement("label",{htmlFor:`custom-snippet-parameter-${e}`},t.label,t.required&&r().createElement("span",{className:"required"},"*")),t.description&&r().createElement("p",{className:"description"},t.description),r().createElement(N.TextField,{id:`custom-snippet-parameter-${e}`,className:"snippet-input",value:o[e]||"",onChange:t=>((e,t)=>{i((n=>Object.assign(Object.assign({},n),{[e]:t}))),c((t=>Object.assign(Object.assign({},t),{[e]:""})))})(e,t.target.value),inputProps:{"aria-required":t.required?"true":"false"},autoComplete:"off",size:"small",error:!!s[e],fullWidth:!0}),s[e]&&r().createElement("p",{className:"error-text"},s[e]))))),r().createElement("div",{className:"parameter-actions"},r().createElement(Kt,{title:"Confirm",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"submit",className:"primary",disabled:d},r().createElement(Se,{svg:rn}))),r().createElement(Kt,{title:"Cancel",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"button",className:"danger",onClick:n,disabled:d},r().createElement(Se,{svg:ln}))))))},ha=S().div`
  display: flex;
  align-items: flex-end;
  min-height: 45px;
  margin: 8px 0 16px;
  font-family: 'Roboto', sans-serif;
  input,
  textarea,
  button {
    font-family: 'Roboto', sans-serif;
  }

  .collaper-spacer {
    flex: 0 0 var(--jp-cell-collapser-width);
    margin: 0px;
    padding: 0px;
    border: none;
    outline: none;
  }

  .prompt-spacer {
    flex: 0 0 var(--jp-cell-prompt-width);
    margin: 0px;
    padding: 0px;
    border: none;
    outline: none;
  }

  .widget-spacer {
    display: flex;
    flex: 1 1 auto;
    flex-direction: column;
    margin: 0px;
    padding: 0px;
    border: none;
    outline: none;
  }

  .form-control {
    min-width: 100px;
    max-width: 400px;
  }
  .form-control + .form-control {
    margin-left: 8px;
  }

  button {
    width: 28px;
    height: 28px;
    background: transparent;
    border: 0 none;
    padding: 0;
    opacity: 1;
    vertical-align: middle;
  }
  button svg {
    width: 28px;
    height: 28px;
  }

  /* blue button */
  button.primary {
    margin-left: 20px;
  }
  body[data-theme='dark'] & button.primary svg .bg {
    fill: #232550;
  }
  body[data-theme='dark'] & button.primary svg .icon {
    fill: var(--link-color);
  }
  button.primary svg:hover .bg,
  body[data-theme='dark'] & button.primary svg:hover .bg {
    fill: var(--link-color);
  }
  button.primary svg:hover .icon,
  body[data-theme='dark'] & button.primary svg:hover .icon {
    fill: #fff;
  }
  button.primary svg:hover .icon-stroke,
  body[data-theme='dark'] & button.primary svg:hover .icon-stroke {
    stroke: #fff;
  }

  /* disabled blue button */
  button.primary[disabled] svg .bg,
  button.primary[disabled] svg:hover .bg {
    fill: var(--control-background-disabled);
  }
  button.primary[disabled] svg .icon,
  button.primary[disabled] svg:hover .icon {
    fill: var(--control-text-disabled);
  }
  button.primary[disabled] svg .icon-stroke,
  button.primary[disabled] svg:hover .icon-stroke {
    stroke: var(--control-text-disabled);
  }

  /* red button */
  button.danger {
    margin-left: 8px;
  }
  body[data-theme='dark'] & button.danger svg .bg {
    fill: #43161f;
  }
  body[data-theme='dark'] & button.danger svg .icon {
    fill: #d17c7f;
  }
  button.danger svg:hover .bg,
  body[data-theme='dark'] & button.danger svg:hover .bg {
    fill: #d17c7f;
  }
  button.danger svg:hover .icon,
  body[data-theme='dark'] & button.danger svg:hover .icon {
    fill: #fff;
  }
`,ga=S().div`
  display: flex;
  gap: 18px;
  align-items: center;
`,va=S().h2`
  font-weight: 700;
  font-size: 13px;
  color: var(--text-primary);
  margin: 0 0 10px;

  svg {
    position: relative;
    top: -2px;
    height: 24px;
    vertical-align: middle;
  }
`,fa=e=>{const t=(0,a.useRef)(null),[n,l]=(0,a.useState)(zt.default),[o,i]=(0,a.useState)(null),[s]=(0,a.useState)(e.metaWrapper),[c]=(0,a.useState)(e.widgetWrapper),[d]=(0,a.useState)(e.commands),[,p]=(0,a.useState)(e.metaWrapper.componentType),m=()=>{l(zt.component)},u=()=>{l(zt.default)},h=e=>{p(e.componentType)};(0,a.useEffect)((()=>(s.name&&""!==s.name&&l(zt.component),s.connect(yt.NAME,m),s.connect(yt.IS_COMPONENT,u),s.connect(yt.COMPONENT_TYPE,h),()=>{s.disconnect(yt.NAME,m),s.disconnect(yt.IS_COMPONENT,u),s.disconnect(yt.COMPONENT_TYPE,h)})),[s,c]);const g=(0,a.useCallback)((e=>()=>{l(e)}),[]),v=(0,a.useCallback)((()=>{te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,oe," Remove from Pipeline"),r().createElement("section",null,"Are you sure to remove from pipeline?"),r().createElement("menu",null,r().createElement("button",{className:"secondary",onClick:()=>e()},"Cancel"),r().createElement("button",{className:"danger",onClick:()=>{s.name=null,s.parents=[],s.isComponent=!1,s.headerColor="transparent",s.diskcache=!1,pe.executeDagUpdateCommand(),s.id=Za(),b(),e()}},"Clear")))))}),[]);const f=(0,a.useCallback)((e=>{i(e),l(zt.customSnippetParameter)}),[]),x=(0,a.useCallback)((()=>{i(null),l(zt.default)}),[]),b=()=>{var e,n;null===(n=null===(e=t.current)||void 0===e?void 0:e.closest(".jp-NotebookPanel-notebook"))||void 0===n||n.focus()};return r().createElement(ha,{ref:t,className:"canvas-cell-widget","data-render-type":n},r().createElement("div",{className:"collaper-spacer"}),r().createElement("div",{className:"prompt-spacer"}),r().createElement("div",{className:"widget-spacer"},r().createElement(Dt.Provider,{value:{metaWrapper:s,widgetWrapper:c,commands:d}},n===zt.default&&s.isComponent||n===zt.component?r().createElement(ga,null,r().createElement(an,{commands:e.commands,handleEditComponent:function(){g(zt.componentForm)()},removeFromPipeline:v}),r().createElement(Mn,{widgetElement:e.widgetElement,setRenderType:l}),r().createElement(Sn,{widgetElement:e.widgetElement,cell:e.cell,onSelectSnippetForParameter:f})):n===zt.componentForm?r().createElement(bn,{setRenderType:l,restoreFocus:b}):n===zt.customSnippetParameter&&o?r().createElement(ua,{snippet:o,cell:e.cell,onCancel:x,onComplete:x}):n===zt.importDataset?r().createElement(r().Fragment,null,r().createElement(da,{title:"Import Dataset"}),r().createElement(Un,{setRenderType:l,cell:e.cell,commands:e.commands})):n===zt.importRunwayModel?r().createElement(r().Fragment,null,r().createElement(va,null,"Import Model"),r().createElement(Qn,{setRenderType:l,cell:e.cell})):n===zt.uploadDataset?r().createElement(r().Fragment,null,r().createElement(da,{title:"Upload Dataset"}),r().createElement(na,{setRenderType:l,cell:e.cell})):n===zt.uploadRunwayModel?r().createElement(r().Fragment,null,r().createElement(va,null,"Upload Model"),r().createElement(Yn,{setRenderType:l,cell:e.cell})):r().createElement(Fn,{widgetElement:e.widgetElement,cell:e.cell,setRenderType:l,onSelectSnippetForParameter:f}))))};class xa extends J.Widget{constructor(e,t,n){super(),this._commManager=null,this.widgetName="CellWidget",this._id="",this._debouncingId=null,this._widgetRoot=null,this._panel=e,this._commands=t,this._wrapper=n,this.update()}_cellUIFix(){var e,t;this._metaWrapper.isComponent?null===(e=this.parent)||void 0===e||e.node.classList.add("link-component"):null===(t=this.parent)||void 0===t||t.node.classList.remove("link-component")}async dispose(){var e,t;null===(e=this._commManager)||void 0===e||e.dispose(),null===(t=this._widgetRoot)||void 0===t||t.unmount(),this._panel=null}onUpdateRequest(){const e=this.parent.model.getMetadata("canvas");this._id=e.id;const t=this._wrapper.cells.getCellMetadataByID(this._id);t&&(this._metaWrapper=t,this._metaWrapper.connect(yt.IS_COMPONENT,(e=>{this._cellUIFix()}))),this.parent.model.sharedModel.changed.connect(((e,t)=>{this._debouncingId?clearTimeout(this._debouncingId):pe.executeDagUpdateCommand(),this._debouncingId=window.setTimeout((async()=>{this._metaWrapper.isComponent&&pe.executeDagUpdateCommand(),this._debouncingId=null}),300)})),this._id=this._metaWrapper.id;const n=r().createElement(fa,{widgetElement:this.node,cell:this.parent,panel:this._panel,commands:this._commands,widgetWrapper:this._wrapper,metaWrapper:this._metaWrapper});this._widgetRoot=(0,l.H)(this.node),this._widgetRoot.render(n),this._cellUIFix()}}var ba=n(40813);const Ca=S().div`
  z-index: 111;
  width: 250px;
  height: 100%;
  border-left: 1px solid var(--border-primary);
  background-color: var(--background-base);
  font-family: 'Roboto', sans-serif;
  input,
  textarea,
  button {
    font-family: 'Roboto', sans-serif;
  }

  .panel-content {
    height: calc(100% - 30px);
    overflow: auto;
  }
`,Ea=S().div`
  display: flex;
  align-items: center;
  height: 30px;
  padding: 0 12px;
  border-bottom: 1px solid var(--border-primary);
  color: var(--text-primary);
  font-weight: bold;
  font-size: 13px;
  background-color: var(--background-surface));

  p {
    width: 210px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  p svg {
    width: 14px;
    height: 14px;
    margin-right: 4px;
    vertical-align: middle;
    margin-top: -2px;
  }

  a {
    margin-right: 6px;
  }

  a svg {
    vertical-align: middle;
  }

  button {
    border: 0 none;
    background: transparent;
    width: 20px;
    height: 20px;
    padding: 1px;
    flex-shrink: 0;
  }

  button svg {
    vertical-align: middle;
  }
`,wa=r().createElement("svg",{width:"18",height:"18",viewBox:"0 0 18 18",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M3.375 5.625C3.375 5.625 4.21875 4.5 6.1875 4.5C8.15625 4.5 9 5.625 9 5.625V13.5C9 13.5 8.15625 12.9375 6.1875 12.9375C4.21875 12.9375 3.375 13.5 3.375 13.5V5.625ZM9 5.625C9 5.625 9.84375 4.5 11.8125 4.5C13.7813 4.5 14.625 5.625 14.625 5.625V13.5C14.625 13.5 13.7813 12.9375 11.8125 12.9375C9.84375 12.9375 9 13.5 9 13.5V5.625Z",stroke:"var(--link-panel-toolbar-icon)",strokeWidth:"0.9",strokeLinecap:"round",strokeLinejoin:"round"})),ya=r().createElement("svg",{width:"18",height:"18",viewBox:"0 0 18 18",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.8891 5.18206C13.0843 5.37732 13.0843 5.6939 12.8891 5.88916L9.70711 9.07114L12.8891 12.2531C13.0843 12.4484 13.0843 12.765 12.8891 12.9602C12.6938 13.1555 12.3772 13.1555 12.182 12.9602L9 9.77825L5.81802 12.9602C5.62276 13.1555 5.30618 13.1555 5.11091 12.9602C4.91565 12.765 4.91565 12.4484 5.11091 12.2531L8.29289 9.07114L5.11091 5.88916C4.91565 5.6939 4.91565 5.37732 5.11091 5.18206C5.30618 4.98679 5.62276 4.98679 5.81802 5.18206L9 8.36404L12.182 5.18206C12.3772 4.98679 12.6938 4.98679 12.8891 5.18206Z",fill:"var(--link-panel-toolbar-icon)"})),ka=({children:e,icon:t,title:n,guideLink:a,close:l})=>r().createElement(Ca,null,r().createElement(Ea,null,r().createElement("p",null,t,n),a&&r().createElement(Kt,{title:"Guide",describeChild:!0,placement:"bottom-start"},r().createElement("a",{href:a,target:"_blank",rel:"noreferrer"},wa)),r().createElement(Kt,{title:"Close",describeChild:!0,placement:"bottom-start"},r().createElement("button",{onClick:l},ya))),r().createElement("div",{className:"panel-content"},e)),La='<?xml version="1.0" encoding="utf-8"?>\n\x3c!-- Generator: Adobe Illustrator 26.0.2, SVG Export Plug-In . SVG Version: 6.00 Build 0)  --\x3e\n<svg version="1.1" id="레이어_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"\n     width="18px" x="0px"\n     y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20;" xml:space="preserve">\n    <path style="fill-rule:evenodd;clip-rule:evenodd;" d="M16.9,10c0,2-2.8,4.1-5.5,3.2c-1.4-0.5-1.8,0.9-0.9,1.8c0.9,0.9,0.5,1.8-0.5,1.8c-3.8,0-6.9-3.1-6.9-6.9\n\tc0-3.8,3.1-6.9,6.9-6.9C13.8,3.1,16.9,6.2,16.9,10z M9.5,5.9c0,0.5-0.4,0.9-0.9,0.9c-0.5,0-0.9-0.4-0.9-0.9s0.4-0.9,0.9-0.9\n\tC9.1,4.9,9.5,5.4,9.5,5.9z M5.9,8.6c0.5,0,0.9-0.4,0.9-0.9c0-0.5-0.4-0.9-0.9-0.9c-0.5,0-0.9,0.4-0.9,0.9C4.9,8.2,5.4,8.6,5.9,8.6z\n\t M12.3,5.9c0,0.5-0.4,0.9-0.9,0.9c-0.5,0-0.9-0.4-0.9-0.9s0.4-0.9,0.9-0.9C11.9,4.9,12.3,5.4,12.3,5.9z M14.1,8.6\n\tc0.5,0,0.9-0.4,0.9-0.9c0-0.5-0.4-0.9-0.9-0.9c-0.5,0-0.9,0.4-0.9,0.9C13.2,8.2,13.6,8.6,14.1,8.6z"  fill="var(--link-panel-toolbar-icon)"/>\n</svg>\n';var _a=n(49395);const Ma=S().div`
  margin: 20px auto;

  .color-palette-color-wrapper {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    margin: 0 12px;
    gap: 12px 8px;
  }
`,Sa=S().p`
  margin-bottom: 20px;
  padding-left: 12px;

  color: var(--text-secondary);
  font-weight: 700;
  font-size: 11px;
  font-style: normal;
  line-height: 13px;
`,Na=(S().p((({color:e})=>_a.css`
    width: 30px;
    height: 30px;

    margin-left: 12px;
    border-radius: 50px;

    background-color: ${e};
  `)),S().button((({color:e})=>{const t=_a.css`
    box-sizing: border-box;
    width: 35px;
    height: 35px;
    border: 0;
    border-radius: 50%;

    cursor: ${"inherit"===e?"not-allowed":"pointer"};
  `;return"transparent"===e?_a.css`
      ${t};
      background-color: transparent;

      position: relative;

      border: 1px solid #777;

      &::before {
        position: absolute;
        top: 50%;
        left: 50%;

        display: block;
        width: 100%;
        height: 1px;

        background: #777;
        transform: translate(-50%, -50%) rotate(-45deg);

        content: '';
      }
    `:"inherit"===e?_a.css`
      ${t};
      background-color: inherit;

      border: 1px solid #777;
    `:_a.css`
    ${t};
    background-color: ${e};
  `}))),Aa=S().div((({selected:e})=>{const t=_a.css`
    display: flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
  `;return e?_a.css`
      ${t}
      box-sizing: border-box;

      outline: 3px solid #00a3ff;

      border-radius: 50%;
    `:t})),Ia=({subTitle:e,colors:t,selectedColor:n,changeHighLights:a})=>r().createElement(Ma,null,r().createElement(Sa,null,e),r().createElement("div",{className:"color-palette-color-wrapper"},t.map(((e,t)=>r().createElement(Aa,{key:e+t.toString(),selected:n===e},r().createElement(Na,{color:e,disabled:"inherit"===e,onClick:()=>a(e)})))))),Oa=S().div`
  overflow-x: hidden;
  overflow-y: auto;

  .custom-input {
    box-sizing: border-box;
    width: 82px;
    height: 30px;
    margin: 0 8px;
    border: 1px solid var(--link-color-picker-input-border);
    border-radius: 5px;

    color: var(--link-color-picker-input-text-color);

    text-align: center;
    text-transform: uppercase;
  }

  .color-picker-selection-info {
    display: flex;
    align-items: center;
    margin: 20px 0;
  }

  .color-picker-link {
    width: calc(100% - 48px);
    margin: 20px 0 0;
    padding: 0 24px;
  }
  .react-colorful__pointer {
    width: 20px;
    height: 20px;
  }

  .apply-color {
    width: 60px;
    height: 28px;

    border: 0;
    border-radius: 5px;

    color: white;

    font-size: 13px;
    line-height: 15px;

    background-color: var(--link-color);
    outline: 0;
  }
`,Pa=S().p`
  width: 100%;
  height: 1px;

  background-color: var(--link-global-parameter-remove-button);
`,Ta=["transparent","#FF004F","#FF8200","#FAFF00","#00DE62","#00E3FF","#0093FF","#0030CC","#6C00FF","#FF00C3"],Fa=new Array(10).fill("inherit"),Va=({close:e})=>{var t,n,l;function o(e){return function(e){const t=null==e?void 0:e.headerColor;return t&&-1===["none","inherit","transparent"].indexOf(t)?t:"transparent"}(e)}r().useEffect((()=>{var e;const t=(e,t,n)=>{s(o(n))};return null===(e=di.currentWidget)||void 0===e||e.connect(Mt.ACTIVE_CELL,t),()=>{var e;null===(e=di.currentWidget)||void 0===e||e.disconnect(Mt.ACTIVE_CELL,t)}}),[]);const[i,s]=(0,a.useState)(o(null===(n=null===(t=di.currentWidget)||void 0===t?void 0:t.cells)||void 0===n?void 0:n.activeCellMetadata)),[c,d]=(0,a.useState)((null===(l=di.currentWidget)||void 0===l?void 0:l.metadata.colorPalette)||Fa),p=(0,a.useCallback)((e=>{s(e),di.currentWidget.cells.activeCellMetadata.headerColor=e,pe.executeDagUpdateCommand()}),[]),m=(0,a.useRef)("");return r().createElement(ka,{icon:r().createElement(Se,{svg:La}),title:"Header Color",close:e},r().createElement(Oa,{id:"header-color-panel"},r().createElement("div",{className:"recommended-color"},r().createElement(Ia,{subTitle:"Recommended Colors",colors:Ta,selectedColor:i,changeHighLights:p})),r().createElement(Pa,null),r().createElement("div",{className:"recent-color"},r().createElement(Ia,{subTitle:"Recent Colors",colors:c,selectedColor:i,changeHighLights:p})),r().createElement("div",null,r().createElement(ba.HexColorPicker,{color:i,onChange:e=>{m.current=e},onMouseUp:e=>{if(-1===e.target.className.split(" ").indexOf("react-colorful__saturation-pointer"))return;const t=m.current,n=[...c];n.unshift(t),n.pop(),d(n),di.currentWidget.metadata.colorPalette=n,p(t)},className:"color-picker-link"}))))};let Ha=null,Ra=null,za=null;function Za(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,(e=>{const t=16*Math.random()|0;return("x"===e?t:3&t|8).toString(16)}))}class Ba{get loaded(){return this._loaded}constructor(e,t,n,a){var r;this._isDisposed=!1,this._loaded=!1,this._initPromise=null,this._initFailureNotified=!1,this._dagUpdateTimerId=0,this._shell=e,this._panel=t,this._commands=n,this._wrapper=new Ft(this._shell,this._panel),this._typeChangeTempArray=[],U.StaticNotebook.defaultNotebookConfig.overscanCount=1e4,U.StaticNotebook.defaultNotebookConfig.windowingMode="full",this._wrapper.lifeCycle.ready((()=>{var e;null===(e=this._panel)||void 0===e||e.context.model.cells.changed.connect(((e,t)=>this.updateConnectedCells(t)),this)})),this._wrapper.connect(Mt.KERNEL_CONNECTION_STATE,(async(e,t)=>{var n,a,r,l,o,i;if("connected"===t){const t=null===(n=this._panel)||void 0===n?void 0:n.context.model.cells[Symbol.iterator](),o="python"===(null===(l=await(null===(r=null===(a=e.session)||void 0===a?void 0:a.kernel)||void 0===r?void 0:r.spec))||void 0===l?void 0:l.language);this.initializeCells(t,o)}else"connecting"===t&&(this._initPromise=null,this._loaded=!1,this._initFailureNotified=!1,xt(null===(i=null===(o=e.session)||void 0===o?void 0:o.kernel)||void 0===i?void 0:i.id,!1))})),di.connect(_t.CURRENT,(e=>{e&&di.isCurrent(this._wrapper.id)&&this._wrapper.kernel&&this._loaded&&this._dagUpdate()}));const l=this._panel,o=null===(r=null==l?void 0:l.sessionContext.session)||void 0===r?void 0:r.kernel;l&&o&&(async()=>{var e;const t=l.context.model.cells[Symbol.iterator](),n="python"===(null===(e=await o.spec)||void 0===e?void 0:e.language);this.initializeCells(t,n)})()}updateDagFromKernel(e){e&&b(e).then((e=>{pe.setKernelComponents(e.kernelId,e.components)}))}_metaForNoHasMetadata(){this._wrapper.metadata.parameters||(this._wrapper.metadata.parameters=[],this._wrapper.metadata.colorPalette=Fa),this._wrapper.cells.each(((e,t)=>{if(e.isEmpty)e.merge({name:"",parents:[],isComponent:!1,componentType:"CodeCell",id:Za(),copiedOriginId:null,headerColor:"transparent",diskcache:!1});else{const t=e.toObject(),n={};t.name||(n.name=""),t.isComponent||(n.isComponent=!1),t.componentType||(n.componentType="CodeCell"),"CodeCell"!==t.componentType&&(n.componentType="CodeCell"),t.id||(n.id=Za()),t.parents||(n.parents=[]),t.copiedOriginId||(n.copiedOriginId=null),t.headerColor&&-1===["none","inherit"].indexOf(t.headerColor)?"number"==typeof t.headerColor&&(n.headerColor=Ta[t.headerColor]):n.headerColor="transparent",t.diskcache||(n.diskcache=!1),e.merge(n)}}))}async _dagUpdate(){var e,t;if(this._initPromise)try{await this._initPromise}catch(e){return}else{if(!(null===(t=null===(e=this._panel)||void 0===e?void 0:e.sessionContext.session)||void 0===t?void 0:t.kernel))return;try{await this._startInit()}catch(e){return}}this._commands&&this._wrapper.kernel&&(this.updateDagFromKernel(this._wrapper.kernel.id),await this._commands.execute(Rt.dagUpdate),this.updateDagFromKernel(this._wrapper.kernel.id))}_startInit(){var e,t;if(this._initPromise)return this._initPromise;const n=null===(t=null===(e=this._panel)||void 0===e?void 0:e.sessionContext.session)||void 0===t?void 0:t.kernel;return n?(this._initPromise=(async()=>{var e,t;await n.requestExecute({code:"%load_ext mrx_link_magic",store_history:!1},!0,{}).done;const a=((null===(t=null===(e=this._panel)||void 0===e?void 0:e.model)||void 0===t?void 0:t.getMetadata("canvas"))||{parameters:[]}).parameters||[],r=await async function(){const e=i.ServerConnection.makeSettings(),t=o.URLExt.join(e.baseUrl+"mrx-link/info/serverapp");let n;try{n=await i.ServerConnection.makeRequest(t,{method:"GET"},e)}catch(e){throw new i.ServerConnection.NetworkError(e)}const a=await n.text();if(!n.ok)throw new i.ServerConnection.ResponseError(n,a.message||a);return{url:JSON.parse(a).url,token:JSON.parse(a).token,cookie:JSON.parse(a).cookie}}(),l=encodeURI(r.url);let s="Accept-Encoding=gzip, deflate, br;";s+="Host="+location.host,r.token&&(s+="; Authorization=token "+r.token);const c=encodeURI(s),d=document.cookie+"; "+r.cookie,p=`%mrxlink_init_dag --base_url ${l} --header ${c} --cookie ${encodeURI(d)}`;await n.requestExecute({code:p,store_history:!1},!1,{}).done;let m="%%mrxlink_set_parameters -n \n";m+=JSON.stringify(a),await n.requestExecute({code:m,store_history:!1},!1,{}).done})().then((()=>{this._initFailureNotified=!1})).catch((e=>{throw this._initFailureNotified||(u.error("Failed to initialize MRX Link. Please restart the kernel."),this._initFailureNotified=!0),console.error("[MRX Link] DAG init failed:",e),this._initPromise=null,e})),this._initPromise):Promise.resolve()}async _magicCommandLoad(){var e,t,n;const a=null===(t=null===(e=this._panel)||void 0===e?void 0:e.sessionContext.session)||void 0===t?void 0:t.kernel;if(a){try{await this._startInit()}catch(e){return}if(await this._dagUpdate(),!this._loaded)for(this._loaded=!0,xt(a.id,!0);;){const e=lt.dequeue();if(!e)break;const t=this._wrapper.cells.getCellByID(e);t&&X.CodeCell.execute(t,null===(n=this._panel)||void 0===n?void 0:n.sessionContext)}}}_getCell(e){var t;return null===(t=this._panel)||void 0===t?void 0:t.content.widgets.find((t=>t.model===e))}_nameAndIdDuplecateCheck(e,t){this._wrapper.cells.each(((n,a)=>{n.name===e.name&&a.id!==t&&(e.name=n.name+"_copy",this._nameAndIdDuplecateCheck(e,t))}))}initializeCells(e,t){var n,a,r,l,o,i,s,c;if(!e)return;const d=null===(a=null===(n=this._panel)||void 0===n?void 0:n.model)||void 0===a?void 0:a.getMetadata("canvas");d&&(null===(l=null===(r=this._panel)||void 0===r?void 0:r.model)||void 0===l||l.setMetadata("canvas",{parameters:d.parameters,colorPalette:d.colorPalette,version:"1.0"}));const p=null===(s=null===(i=null===(o=this._panel)||void 0===o?void 0:o.content)||void 0===i?void 0:i.model)||void 0===s?void 0:s.cells[Symbol.iterator]();if(p){for(;;){const e=p.next();if(!e||!e.value)break;const t=e.value.getMetadata("canvas");t&&e.value.setMetadata("canvas",{name:t.name,parents:t.parents,isComponent:t.isComponent,componentType:"CodeCell",id:t.id,copiedOriginId:t.copiedOriginId,headerColor:t.headerColor,diskcache:t.diskcache})}null===(c=this._panel)||void 0===c||c.context.save()}this._metaForNoHasMetadata(),this._magicCommandLoad(),t&&this._wrapper.cells.each(((e,t,n)=>{if(n){const e=(null==n?void 0:n.layout).widgets.find((e=>"CellWidget"===e.widgetName));(void 0===e&&!n.node.id.length&&"text/x-ipython"===n.model.mimeType||"text/plain"===n.model.mimeType)&&(n.inputHidden&&(n.inputHidden=!1),(null==n?void 0:n.layout).insertWidget(0,new xa(this._panel,this._commands,this._wrapper)))}}))}async updateConnectedCells(e){const t=await function(e){if(null!==Ha&&"add"===e.type){null!==za&&(clearTimeout(za),za=null);const t={type:"move",newIndex:e.newIndex,oldIndex:Ha.oldIndex,newValues:e.newValues,oldValues:Ha.oldValues};return Ha=null,Promise.resolve(t)}if(null!==Ra&&"remove"===e.type){null!==za&&(clearTimeout(za),za=null);const t={type:"move",newIndex:Ra.newIndex,oldIndex:e.oldIndex,newValues:Ra.newValues,oldValues:e.oldValues};return Ra=null,Promise.resolve(t)}return null===Ha&&"remove"===e.type?(Ha=e,new Promise((t=>{za=setTimeout((()=>{Ha=null,t(e)}),10)}))):null===Ra&&"add"===e.type?(Ra=e,new Promise((t=>{za=setTimeout((()=>{Ra=null,t(e)}),10)}))):Promise.resolve(e)}(e);if("add"===t.type)t.newValues.forEach((e=>{let t=e.getMetadata("canvas");const n=this._getCell(e);void 0!==t&&t.isImportedJustNow?(e.setMetadata("canvas",Object.assign(Object.assign({},t),{isImportedJustNow:!1})),this._syncParentInfo(),this._dagUpdate()):void 0!==t&&t.isComponent?(t={name:t.name+"_copy",parents:t.parents,isComponent:!0,componentType:t.componentType,id:Za(),copiedOriginId:t.id,headerColor:"transparent",diskcache:!1},e.setMetadata("canvas",t),this._syncParentInfo(),this._dagUpdate()):(t={name:"",parents:[],isComponent:!1,componentType:"CodeCell",id:Za(),copiedOriginId:null,headerColor:"transparent",diskcache:!1},e.setMetadata("canvas",t)),t.name&&t.name.length&&this._nameAndIdDuplecateCheck(t,null==n?void 0:n.model.id),"CodeCell"!==t.componentType&&(n.inputHidden=!1),this._dagUpdateTimerId&&clearTimeout(this._dagUpdateTimerId),this._dagUpdateTimerId=window.setTimeout((()=>{t.isComponent&&"CodeCell"===t.componentType&&this._dagUpdate()}),0),this._insertCellWidget(this._panel,e)}));else if("remove"===t.type)this._syncParentInfo(),this._dagUpdate();else if("set"===t.type)for(;;){const e=t.newValues.shift();if(!e)break;const n=Ot.getOrCreate(e,this._shell,this._panel);if(!n.isEmpty)if("text/x-ipython"===(null==e?void 0:e.mimeType)){const e=this._wrapper.cells.getCellByID(n.id);e&&(e.layout.widgets[0].dispose(),e.layout.insertWidget(0,new xa(this._panel,this._commands,this._wrapper)))}else n.isComponent&&(this._typeChangeTempArray.push(e),te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,oe," Change Cell Type"),r().createElement("section",null,"This is the cell included in the pipeline. If you change the cell type, it will be disappeared on the pipeline. Are you sure to change the cell type?"),r().createElement("menu",null,r().createElement("button",{className:"secondary",onClick:()=>{var t;this._commands&&(this._typeChangeTempArray=[],null===(t=this._commands)||void 0===t||t.execute("notebook:undo-cell-action")),e()}},"Cancel"),r().createElement("button",{className:"danger",onClick:()=>{this._typeChangeTempArray.forEach((e=>{Ot.getOrCreate(e,this._shell,this._panel).isComponent=!1})),this._typeChangeTempArray=[],this._dagUpdate(),e()}},"Change"))))))}else"move"===t.type&&(t.newValues.forEach((e=>this._insertCellWidget(this._panel,e))),this._syncParentInfo(),this._dagUpdate())}_insertCellWidget(e,t){if(!e||"text/x-ipython"!==t.mimeType)return;const n=this._getCell(t),a=null==n?void 0:n.layout;a instanceof J.PanelLayout&&a.insertWidget(0,new xa(e,this._commands,this._wrapper))}_syncParentInfo(){const e=this._wrapper.cells.map((e=>e.id));this._wrapper.cells.each((t=>{t.parents=(t.parents||[]).map((t=>-1!==e.indexOf(t.id)?t:null)).filter((e=>null!=e))}))}get isDisposed(){return this._isDisposed}dispose(){var e,t,n;null===(e=this._panel)||void 0===e||e.context.model.cells.changed.disconnect(((e,t)=>this.updateConnectedCells(t)),this),null===(n=null===(t=this._panel)||void 0===t?void 0:t.node.querySelector(".jp_Notebook"))||void 0===n||n.remove(),this._panel=null,this._commands=null,this._wrapper.disconnectAll(),this._wrapper.metadata.disconnectAll()}}class ja{constructor(e,t,n){this._shell=e,this._commands=t,this._tracker=n}createNew(e,t){return new Ba(this._shell,e,this._commands,this._tracker)}}const Da=new class{constructor(){this.type=null,this.visible=!1,(0,ce.makeAutoObservable)(this)}makeHidden(){this.visible=!1}makeVisible(){this.visible=!0}close(){this.type=null,this.visible=!1}open(e){this.type=e,this.visible=!0}},Wa=S().div`
  font-family: 'Roboto', sans-serif;
  input,
  textarea,
  button {
    font-family: 'Roboto', sans-serif;
  }
  .pipeline-panel-header {
    position: relative;
    z-index: 1;
    height: 62px;
    overflow: hidden;
  }

  .pipeline-panel-title {
    padding: 8px 0;

    color: var(--link-panel-toolbar-font-color);

    font-weight: 600;
    font-size: 11px;
    letter-spacing: 0.5px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;

    background-color: var(--link-panel-toolbar-background);
  }
  .pipeline-panel-align {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 12px 0 8px;
    border-bottom: ${"var(--jp-border-width) solid var(--jp-toolbar-border-color)"};

    color: var(--link-panel-toolbar-font-color);

    background-color: var(--link-panel-toolbar-background);

    box-shadow: var(--jp-toolbar-box-shadow);
  }
  .pipeline-panel-toolbar {
    display: flex;
    gap: 10px;
    align-items: center;
    height: 30px;
    margin-right: auto;
  }

  .graph-pipeline {
    height: 100%;
  }

  .graph-container-loading {
    position: absolute;

    display: flex;
    align-items: center;
    justify-content: center;

    width: 100%;
    height: 100%;
  }

  .graph-container-loading .visible {
    display: block;
    width: 100%;
    height: 100%;
  }

  .graph-container-loading .hidden {
    display: none;
  }
  .graph-container {
    background-color: var(--link-panel-background);
  }
`,Ua=S().button`
  width: 20px;
  height: 20px;
  padding: 0;
  border: none;
  background: transparent;

  &:disabled {
    opacity: 0.5;
    pointer-events: none;
  }
`,$a=S().div`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding-bottom: 68px;
  text-align: center;

  .panel-empty-title {
    display: block;
    padding: 20px;

    color: var(--text-secondary);
    font-weight: 700;
    font-size: 24px;
  }
  .panel-empty-image {
    display: block;
    flex: 0.6;
    padding: 20px;

    & > div {
      display: block;
      width: 102px;
      height: 94px;
      margin: 0 auto;
    }
  }
  .panel-empty-description {
    display: block;

    color: var(--text-secondary);
    font-size: 13px;
  }
`,Ga=S().div`
  position: absolute;
  z-index: 2;
  right: 0;
  width: 100%;
  max-width: 570px;
  height: calc(100% - 60px);
  overflow: auto;
  display: flex;
  flex-direction: column;
  color: var(--link-global-parameter-font-color);
  border-left: 1px solid var(--link-global-parameter-border);
  background-color: var(--link-global-parameter-background);
  box-shadow: var(--popover-shadow);

  .title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 48px;
    padding-left: 12px;

    color: var(--link-global-parameter-title-font-color);
    background-color: var(--link-global-parameter-title-background);
    font-weight: bold;
    font-size: 15px;
    flex-shrink: 0;
  }

  .main {
    flex: 1;

    .parameter-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
      padding: 10px 0;
      overflow: auto;
    }
  }

  .remove-button {
    display: block;
    width: 16px;
    height: 16px;
    border-radius: 20px;

    color: var(--text-secondary);
    font-size: 16px;
    line-height: 16px;
    text-align: center;
    text-indent: 0;

    background: var(--link-global-parameter-remove-button);
    border: 1px solid var(--text-secondary);
    cursor: pointer;
  }

  .pipeline-no-parameter {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 50px;

    color: var(--text-secondary);

    font-size: 13px;
    text-align: center;
  }

  .error-txt {
    display: flex;
    gap: 5px;
    align-items: center;

    color: red;
    font-size: 10px;
  }
  .error-txt .SVGInline {
    align-items: center;
  }
  .error-txt .SVGInline svg {
    width: 12px;
  }

  .button-container {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
    padding: 10px 10px;

    border-top: 1px solid var(--link-global-parameter-border);
    box-shadow: var(--popover-shadow);
  }

  .cancel-button-param,
  .save-button-param {
    display: flex;
    align-items: center;
    justify-content: center;

    width: 110px;
    height: 38px;
    border: none;

    border-radius: 4px;

    color: white;
    font-weight: 700;
    font-size: 13px;

    background-color: var(--link-global-parameter-save-button-background);
    cursor: pointer;

    transition: all 0.3s;
  }

  .cancel-button-param {
    border: 1px solid var(--link-global-parameter-cancel-button-border-color);

    color: var(--link-global-parameter-cancel-font-color);

    background-color: var(--link-global-parameter-cancel-button-background);
  }
  .save-button-param:hover {
    background-color: var(--link-global-parameter-button-hover-background);
  }
  .cancel-button-param:hover {
    border: 1px solid var(--link-global-parameter-button-hover-background);

    color: var(--link-global-parameter-button-hover-background);
  }
`,qa=S().div`
  display: grid;
  grid-template-columns: 1fr 2fr 24px;
  height: 30px;
  line-height: 30px;
  border-top: 1px solid var(--link-global-parameter-border);
  border-bottom: 1px solid var(--link-global-parameter-border);
  font-weight: 500;

  background-color: var(--link-global-parameter-table-header-background);
  color: var(--link-text-light);

  .column-title {
    padding: 0 10px;
    &:first-child {
      border-right: 1px solid var(--link-global-parameter-border);
    }
  }
`,Ka=S().div`
  display: grid;
  grid-template-columns: 1fr 2fr 24px;

  .input-item {
    padding: 0 5px 0 5px;
    &.input-item-dataset {
      overflow: hidden;
    }
  }

  .remove-button-container {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    padding-right: 5px;
  }

  .input-result-box {
    display: flex;
    justify-content: space-between;
    height: 13px;
    line-height: 13px;
  }
`,Ya=S().div`
  /* position */
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;

  /* background */
  background-color: var(--link-panel-background);
  background-image: radial-gradient(var(--link-panel-dot) 1px, transparent 1%),
    radial-gradient(var(--link-panel-dot) 1px, transparent 1%);
  background-repeat: repeat;
  background-position: 0 0, 8px 8px;
  background-size: 16px 16px;

  /* layout */
  display: flex;
  align-items: center;
  justify-content: center;
`,Xa=S().div`
  width: 100%;
  height: 100%;

  .graph-background {
    background-color: var(--link-panel-background);
    background-image: radial-gradient(var(--link-panel-dot) 1px, transparent 1%),
      radial-gradient(var(--link-panel-dot) 1px, transparent 1%);
    background-repeat: repeat;
    background-position: 0 0, 8px 8px;
    background-size: 16px 16px;
  }

  .label-container p {
    display: flex;
    align-items: center;
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    flex: 2;
    align-items: center;
    font-size: 14px;
    font-weight: 700;
    color: var(--link-panel-dag-not-selected-font-color);
    margin: 0;
    padding: 0px 28px 0 5px;
    word-break: break-word;
  }
  .label-container p.active {
    color: var(--link-panel-dag-selected-font-color);
  }
  .label-container p.successful {
    color: var(--link-panel-dag-successful-font-color);
  }
  .label-container p.failed {
    color: var(--link-panel-dag-failed-font-color);
  }

  .link-toolbar.diskcache .link-cache-disabled {
    visibility: visible;
  }
  .link-toolbar.diskcache .link-cache-enabled {
    visibility: hidden;
  }
  .link-toolbar.running .link-run-bg + path {
    fill: var(--link-color);
  }

  .link-cache-status.uncached .disk,
  .link-cache-status.updating .disk {
    fill: var(--feedback-info);
  }
  .link-cache-status.cached .disk {
    fill: var(--link-panel-dag-successful-background);
  }
  .link-cache-status.failed .disk {
    fill: var(--link-panel-dag-failed-background);
  }

  .link-cache-status .loading {
    visibility: hidden;
  }
  .link-cache-status.updating .loading {
    visibility: visible;
  }

  .link-remote-status path {
    fill: #999;
  }
  body[data-theme='dark'] & .link-remote-status path {
    fill: #999;
  }

  .link-node-status {
    transform: translate(67px, -10px);
  }
  .link-node-status.invalid svg {
    fill: var(--feedback-info);
  }
  .link-node-status.running circle {
    stroke: var(--feedback-info);
  }
  .link-node-status.active.running circle {
    stroke: var(--feedback-info);
  }
  .link-node-status.successful svg {
    fill: var(--link-panel-dag-successful-background);
  }
  .link-node-status.failed svg {
    fill: var(--link-panel-dag-failed-background);
  }
  .link-node-status.active svg {
    fill: var(--white);
  }
`;var Ja=n(21079);const Qa=S().div`
  margin: 24px 0 0;
  text-align: right;

  button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    width: 120px;
    height: 36px;
    padding: 0;
    font-weight: 700;
    font-size: 13px;
    border-radius: 5px;
    border: 1px solid var(--link-color);
    color: var(--link-color);
    background-color: transparent;
  }
  button.full-width {
    width: 100%;
  }
  button.primary {
    border-color: var(--link-color);
    color: var(--white);
    background-color: var(--link-color);
  }
  button.danger {
    border-color: var(--button-error-border);
    color: var(--button-error-text);
    background-color: var(--button-error-background);
  }
  button:disabled {
    color: var(--control-text-disabled);
    border-color: var(--control-border);
    background-color: var(--control-background-disabled);
  }
  button + button {
    margin-left: 12px;
  }
  button svg {
    margin-right: 4px;
  }
`;var er=n(34835),tr=n.n(er);const nr=(e,t=10)=>{t<7&&(console.error("The size should be integer greater than or equal to 7. The size is adjusted to 7."),t=7);const n=e.toString();if(n.length<=t)return n;if(e>=Math.pow(10,t)||e<=-Math.pow(10,t-1)||0===parseFloat(e.toFixed(t-2))){const n=e.toExponential();if(n.length<=t)return n;const[a,r]=n.split("e"),[l,o]=a.split(".");if(!o)return r;const i=t-l.length-r.length-2,s=o.slice(0,i);return s&&s.length>0&&0!==parseFloat(s)?l+"."+s+"e"+r:l+"e"+r}const a=n.indexOf(".");return a===t-1?n.slice(0,t-1):a>=0?n.slice(0,t):n},ar=["#FD6483","#FECD56","#39A1EA","#9A64FF","#4BBFBF","#C9CACE","#FF6785","#3DA0E9"],rr=S().svg`
  display: block;

  .x-axis text,
  .y-axis text {
    font-size: 11px;
    fill: #999;
    font-family: sans-serif;
  }

  .x-axis text {
    text-anchor: middle;
  }

  .y-axis text {
    text-anchor: end;
  }

  .x-axis text.legend,
  .y-axis text.legend {
    text-anchor: start;
  }

  .x-axis line,
  .y-axis line {
    stroke: #999;
    stroke-width: 1;
  }
`,lr=S().ul`
  margin: 14px 50px 0;
  padding: 0;
  list-style: none;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
  gap: 0 10px;

  li {
    display: inline-block;
    max-width: 100%;
  }

  button {
    display: flex;
    align-items: center;
    border: 0 none;
    background: none;
    font-weight: 400;
    font-size: 8px;
    line-height: 9px;
    white-space: pre;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 2px 4px;
    border-radius: 2px;
    color: var(--text-detail);
  }
  button:hover {
    background: var(--control-background-hover);
  }
  button.off {
    opacity: 0.3;
  }
  button:hover.off {
    background: transparent;
  }

  span.icon {
    width: 6px;
    height: 6px;
    border-radius: 3px;
    vertical-align: middle;
    margin-right: 2px;
    display: inline-block;
  }
  span.text {
    max-width: 100px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: pre;
  }
`,or=({data:e,legends:t})=>{const[n,l]=(0,a.useState)([]),[o,i]=(0,a.useState)([]),[s,c]=(0,a.useState)([]),[d,p]=(0,a.useState)([]),m=e=>{const t=Math.floor(Math.min.apply(null,e)),n=Math.ceil(Math.max.apply(null,e));return[t,n,Math.ceil((n-t)/10)]},u=t=>{const[a,r]=n,[l,i]=o;return[...e.map((e=>[e[0],e[1][t]]))].sort(((e,t)=>t[0]-e[0])).map((e=>[r===a?216:(e[0]-a)/(r-a)*346+43,i===l?110:170-(e[1]-l)/(i-l)*170+25])).join(" ")},h=e=>{s.indexOf(e)>-1?c([...s.filter((t=>t!==e))]):c([...s,e])};return(0,a.useEffect)((()=>{l(m(d.map((e=>e[0])))),i(m(d.reduce(((e,t)=>[...e,...t[1]]),[])))}),[d]),(0,a.useEffect)((()=>{c([])}),[t]),(0,a.useEffect)((()=>{p(e.map((e=>[e[0],e[1].filter(((e,t)=>-1===s.indexOf(t)))])))}),[e,s]),r().createElement(r().Fragment,null,r().createElement(rr,{width:"100%",height:"230",viewBox:"0 0 416 230",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("rect",{x:"33",y:"15",width:366,height:190,stroke:"#999"}),r().createElement("g",{className:"x-axis"},(()=>{const[e,t,a]=n;if(e===t)return r().createElement(r().Fragment,null,r().createElement("line",{x1:216,y1:"205",x2:216,y2:"208"}),r().createElement("text",{x:216,y:"217"},e));const l=[];for(let n=0;n*a<t-e+a;n++){const o=43+346*n*a/(t-e);e+a*n>t||l.push(r().createElement(r().Fragment,null,r().createElement("line",{x1:o,y1:"205",x2:o,y2:"208"}),r().createElement("text",{x:o,y:"217"},e+a*n)))}return l})(),r().createElement("text",{className:"legend",x:"373",y:"227"},"Iteration")),r().createElement("g",{className:"y-axis"},(()=>{const[e,t,n]=o;if(e===t)return r().createElement(r().Fragment,null,r().createElement("line",{x1:"30",y1:110,x2:"33",y2:110}),r().createElement("text",{x:"29",y:113},e));const a=[];for(let l=0;l*n<t-e+n;l++){const o=195-170*l*n/(t-e),i=e+n*l;i>t||a.push(r().createElement(r().Fragment,null,r().createElement("line",{x1:"30",y1:o,x2:"33",y2:o}),r().createElement("text",{x:"29",y:o+3},nr(i,10))))}return a})(),r().createElement("text",{className:"legend",x:"5",y:"8"},"Target Value")),r().createElement("g",{strokeWidth:"1"},t.map(((e,t)=>{if(-1===s.indexOf(t))return r().createElement("polyline",{key:t,points:u(t),stroke:ar[t%ar.length]})})))),t.length>1&&r().createElement(lr,null,t.map(((e,t)=>r().createElement("li",{key:t},r().createElement("button",{className:s.indexOf(t)>-1?"off":"",onClick:h.bind(null,t)},r().createElement("span",{className:"icon",style:{backgroundColor:ar[t]}}),r().createElement("span",{className:"text"},e)))))))},ir=S().span`
  position: relative;
  top: 1px;
  vertical-align: middle;

  button {
    border: 0 none;
    background: transparent;
  }

  .popper {
    position: absolute;
    z-index: 1;
    display: none;
    top: 20px;
    left: 0;
    width: 244px;
    margin: 0;
    padding: 8px 12px;
    background: var(--background-base);
    border: 0.5px solid var(--background-surface-border);
    box-shadow: var(--popover-shadow);
    border-radius: 4px;
    color: var(--text-primary);
    font-weight: 400;
    font-size: 13px;
    line-height: 150%;
    text-align: left;
  }
  button:hover + .popper {
    display: inline;
  }

  .header {
    display: block;
    font-weight: 700;
    font-size: 13px;
    line-height: 150%;
    margin: 0 0 8px;
  }

  ul {
    margin: 0;
    padding: 0 0 0 18px;
    list-style: disc;
  }
`,sr=r().createElement("svg",{width:"16",height:"16",viewBox:"0 0 10 11",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("circle",{cx:"5",cy:"5.5",r:"4.5",fill:"none",stroke:"var(--link-color)"}),r().createElement("path",{d:"M5.41658 6.77149H4.40819C4.4112 6.52844 4.43532 6.32459 4.48054 6.15994C4.52576 5.99267 4.60112 5.84109 4.70664 5.70519C4.81516 5.56928 4.95836 5.42554 5.13622 5.27396C5.2749 5.15896 5.4 5.0505 5.51155 4.94858C5.62309 4.84404 5.71202 4.73427 5.77834 4.61928C5.84466 4.50167 5.87783 4.36707 5.87783 4.21549C5.87783 4.05084 5.84617 3.91102 5.78286 3.79602C5.71956 3.68103 5.6261 3.59348 5.5025 3.53337C5.38192 3.47326 5.23118 3.4432 5.05031 3.4432C4.89957 3.4432 4.75789 3.46934 4.62524 3.52161C4.4926 3.57126 4.38558 3.64967 4.30418 3.75682C4.22279 3.86136 4.17907 3.99988 4.17305 4.17237H3.08325C3.08928 3.84307 3.17972 3.56604 3.35457 3.34128C3.52942 3.11651 3.76456 2.94794 4.06 2.83556C4.35543 2.72318 4.68553 2.66699 5.05031 2.66699C5.45427 2.66699 5.79944 2.7271 6.08584 2.84732C6.37223 2.96493 6.59079 3.13742 6.74152 3.3648C6.89527 3.58956 6.97214 3.86136 6.97214 4.18021C6.97214 4.4102 6.91938 4.61928 6.81387 4.80745C6.70836 4.99301 6.57119 5.16681 6.40237 5.32884C6.23355 5.48827 6.05117 5.64769 5.85522 5.80711C5.6864 5.9404 5.57184 6.08545 5.51155 6.24226C5.45125 6.39646 5.4196 6.57287 5.41658 6.77149ZM4.31775 7.99461C4.31775 7.85348 4.37352 7.73457 4.48506 7.63787C4.5966 7.53856 4.74884 7.4889 4.94178 7.4889C5.13472 7.4889 5.28696 7.53856 5.3985 7.63787C5.51004 7.73457 5.56581 7.85348 5.56581 7.99461C5.56581 8.13574 5.51004 8.25596 5.3985 8.35528C5.28696 8.45198 5.13472 8.50033 4.94178 8.50033C4.74884 8.50033 4.5966 8.45198 4.48506 8.35528C4.37352 8.25596 4.31775 8.13574 4.31775 7.99461Z",fill:"var(--link-color)"})),cr=({left:e,width:t,title:n,messages:a})=>r().createElement(ir,{className:"hint"},r().createElement("button",{type:"button"},sr),r().createElement("span",{className:"popper",style:Object.assign(Object.assign({},void 0!==e&&{left:`${e}px`}),void 0!==t&&{width:`${t}px`})},n&&r().createElement("span",{className:"header"},n),r().createElement("ul",null,a.map(((e,t)=>r().createElement("li",{key:t},e)))))),dr=S().div`
  position: relative;
  background: var(--background-surface);
  border-radius: 8px;
  margin: 8px 0 0;
  padding: 8px 40px 8px 12px;

  table {
    border-collapse: collapse;
    table-layout: fixed;
  }

  th,
  td {
    font-weight: 400;
    font-size: 13px;
    line-height: 15px;
    padding: 4px;
    text-align: left;
    height: 28px;
  }
  th {
    color: #999;
    width: 90px;
  }
  td {
    word-wrap: anywhere;
  }

  td strong {
    font-weight: 700;
  }

  .range > div {
    width: 80px;
    display: inline-block;
    vertical-align: middle;
  }

  button {
    position: absolute;
    top: 12px;
    right: 12px;
    width: 18px;
    height: 18px;
    padding: 0;
    background: transparent;
    border: 0 none;
  }
  button:hover path {
    fill: #464555;
  }
  body[data-theme='dark'] & button path {
    fill: #777;
  }
  body[data-theme='dark'] & button:hover path {
    fill: #999;
  }
`,pr=r().createElement("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M7.29313 8.00021L5.87913 6.58621C5.78805 6.49191 5.73765 6.3656 5.73879 6.23451C5.73993 6.10341 5.79251 5.978 5.88522 5.8853C5.97792 5.79259 6.10333 5.74001 6.23442 5.73887C6.36552 5.73773 6.49182 5.78813 6.58613 5.87921L8.00013 7.29321L9.41412 5.87921C9.46025 5.83145 9.51542 5.79336 9.57642 5.76716C9.63742 5.74095 9.70304 5.72716 9.76942 5.72658C9.83581 5.726 9.90165 5.73866 9.9631 5.7638C10.0246 5.78894 10.0804 5.82606 10.1273 5.87301C10.1743 5.91996 10.2114 5.97578 10.2365 6.03723C10.2617 6.09868 10.2743 6.16452 10.2738 6.23091C10.2732 6.2973 10.2594 6.36291 10.2332 6.42391C10.207 6.48491 10.1689 6.54008 10.1211 6.58621L8.70712 8.00021L10.1211 9.41421C10.1689 9.46033 10.207 9.5155 10.2332 9.5765C10.2594 9.63751 10.2732 9.70312 10.2738 9.76951C10.2743 9.8359 10.2617 9.90174 10.2365 9.96318C10.2114 10.0246 10.1743 10.0805 10.1273 10.1274C10.0804 10.1744 10.0246 10.2115 9.9631 10.2366C9.90165 10.2618 9.83581 10.2744 9.76942 10.2738C9.70304 10.2733 9.63742 10.2595 9.57642 10.2333C9.51542 10.2071 9.46025 10.169 9.41412 10.1212L8.00013 8.70721L6.58613 10.1212C6.49182 10.2123 6.36552 10.2627 6.23442 10.2615C6.10333 10.2604 5.97792 10.2078 5.88522 10.1151C5.79251 10.0224 5.73993 9.89701 5.73879 9.76591C5.73765 9.63481 5.78805 9.50851 5.87913 9.41421L7.29313 8.00021Z",fill:"#999999"}),r().createElement("path",{d:"M8 14C8.78793 14 9.56815 13.8448 10.2961 13.5433C11.0241 13.2417 11.6855 12.7998 12.2426 12.2426C12.7998 11.6855 13.2417 11.0241 13.5433 10.2961C13.8448 9.56815 14 8.78793 14 8C14 7.21207 13.8448 6.43185 13.5433 5.7039C13.2417 4.97595 12.7998 4.31451 12.2426 3.75736C11.6855 3.20021 11.0241 2.75825 10.2961 2.45672C9.56815 2.15519 8.78793 2 8 2C6.4087 2 4.88258 2.63214 3.75736 3.75736C2.63214 4.88258 2 6.4087 2 8C2 9.5913 2.63214 11.1174 3.75736 12.2426C4.88258 13.3679 6.4087 14 8 14ZM8 15C6.14348 15 4.36301 14.2625 3.05025 12.9497C1.7375 11.637 1 9.85652 1 8C1 6.14348 1.7375 4.36301 3.05025 3.05025C4.36301 1.7375 6.14348 1 8 1C9.85652 1 11.637 1.7375 12.9497 3.05025C14.2625 4.36301 15 6.14348 15 8C15 9.85652 14.2625 11.637 12.9497 12.9497C11.637 14.2625 9.85652 15 8 15Z",fill:"#999999"})),mr=({parameters:e,setParameters:t,parameter:n,selectedParameters:a,setSelectedParameters:l,tuningMethod:o,isDisabled:i})=>{const s=(e,t,n)=>{const r=a.findIndex((e=>e.name===t.name));a[r][n]=e.target.value,"distribution"!==n||"TPESearch"!==o&&"RandomSearch"!==o||"discrete_uniform"!==e.target.value||(a[r].interval=Math.pow(10,Math.ceil(Math.log10(Math.abs(Number(a[r].value)))))/2),l([...a])};return r().createElement(dr,null,r().createElement(Kt,{title:"Delete",describeChild:!0,placement:"top",sx:Wt},r().createElement("button",{type:"button",onClick:()=>(e=>{l(a.filter((t=>t.name!==e.name)))})(n),disabled:i},pr)),r().createElement("table",null,r().createElement("tr",null,r().createElement("th",null,"Name"),r().createElement("td",null,r().createElement("strong",null,n.name))),r().createElement("tr",null,r().createElement("th",null,"Value"),r().createElement("td",null,n.value)),r().createElement("tr",null,r().createElement("th",null,"Range *"),r().createElement("td",{className:"range"},r().createElement(pn,null,r().createElement(N.TextField,{type:"number",value:n.start,onChange:e=>s(e,n,"start"),required:!0,size:"small",margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},placeholder:"start",disabled:i})),"~",r().createElement(pn,null,r().createElement(N.TextField,{type:"number",value:n.end,onChange:e=>s(e,n,"end"),required:!0,size:"small",margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},placeholder:"end",disabled:i})))),"GridSearch"!==o&&r().createElement("tr",null,r().createElement("th",null,r().createElement("label",{htmlFor:`link-distribution-${n.name}-label`},"Distribution")," *"),r().createElement("td",null,r().createElement(pn,null,r().createElement(N.Select,{id:`link-distribution-${n.name}-label`,value:n.distribution,onChange:e=>((e,t)=>{"loguniform"===e.target.value?(t.start=1,t.end=100):(t.start=-1,t.end=1),s(e,t,"distribution")})(e,n),fullWidth:!0,MenuProps:{className:"link-select-menu-popover"},disabled:i},r().createElement(N.MenuItem,{value:"discrete_uniform"},"Discrete Uniform"),r().createElement(N.MenuItem,{value:"float"},"Float"),r().createElement(N.MenuItem,{value:"int"},"Int"),r().createElement(N.MenuItem,{value:"loguniform"},"Loguniform"),r().createElement(N.MenuItem,{value:"uniform"},"Uniform"))))),("GridSearch"===o||"discrete_uniform"===n.distribution)&&r().createElement("tr",null,r().createElement("th",null,r().createElement("label",{htmlFor:`link-interval-${n.name}-label`},"Interval")," *"),r().createElement("td",null,r().createElement(pn,null,r().createElement(N.TextField,{id:`link-interval-${n.name}-label`,type:"number",value:n.interval,onChange:e=>s(e,n,"interval"),required:!0,size:"small",margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},disabled:i}))))))},ur=(0,jt.observer)((({componentKey:e,setComponentKey:t,type:n,setType:l,target:o,setTarget:i,tuningMethod:s,setTuningMethod:c,iteration:d,setIteration:p,earlyStopping:m,setEarlyStopping:u,selectedParameters:h,setSelectedParameters:g,errorMessage:v,expression:f,setExpression:x,isDisabled:b})=>{const[C,E]=(0,a.useState)([]),[w,y]=(0,a.useState)([]);return(0,a.useEffect)((()=>{0!==e.length?async function(){const t=await Bt(`%mrxlink_get_target_exp_in_last_exp -i ${e}`),n=t.target_exp||[];x(t.last_exp),l(n.map((()=>"min"))),i(n)}():x("The target to optimize will be displayed")}),[e]),(0,a.useEffect)((()=>{var e;y((null===(e=di.currentWidget)||void 0===e?void 0:e.metadata.parameters.filter((e=>"int"===e.type||"float"===e.type)))||[])}),[]),(0,a.useEffect)((()=>{var e,t;const n=null===(t=null===(e=di.currentWidget)||void 0===e?void 0:e.kernel)||void 0===t?void 0:t.id,a=pe.getKernelComponents(n);a&&E(Object.keys(a).map((e=>({key:e,value:a[e]}))))}),[]),r().createElement(hr,{className:"main"},r().createElement(pn,null,r().createElement(N.InputLabel,{id:"link-target-component-label"},"Target Component"),r().createElement(cr,{left:-65,messages:["Select the component containing the target expression to optimize in the last expression.","You can list multiple objects separated by commas."]}),r().createElement(N.Select,{labelId:"link-target-component-label",value:e,onChange:e=>t(e.target.value),fullWidth:!0,MenuProps:{className:"link-select-menu-popover"},disabled:b},C.sort(((e,t)=>e.value.name.localeCompare(t.value.name))).map((e=>r().createElement(N.MenuItem,{key:e.key,value:e.key},e.value.name))))),r().createElement("div",{className:"target"},r().createElement("p",null,r().createElement("b",null,"Target Expression")),r().createElement("pre",null,f||"No target expression")),0!==o.length&&r().createElement("table",{className:"target-type"},r().createElement("thead",null,r().createElement("tr",null,r().createElement("th",null,"Target"),r().createElement("th",null,"Type"))),r().createElement("tbody",null,o.map(((e,t)=>r().createElement("tr",{key:t},r().createElement("td",null,e),r().createElement("td",null,r().createElement(pn,null,r().createElement(N.RadioGroup,{name:`link-min-max-${t}`,value:n[t],onChange:e=>{n[t]=e.target.value,l([...n])},row:!0},r().createElement(N.FormControlLabel,{value:"min",control:r().createElement(N.Radio,{disabled:b}),label:"Min"}),r().createElement(N.FormControlLabel,{value:"max",control:r().createElement(N.Radio,{disabled:b}),label:"Max"}))))))))),r().createElement(pn,null,r().createElement(N.InputLabel,{id:"link-tuning-method-label"},"Sampler"),r().createElement(N.Select,{labelId:"link-tuning-method-label",value:s,onChange:e=>c(e.target.value),fullWidth:!0,MenuProps:{className:"link-select-menu-popover"},disabled:b},r().createElement(N.MenuItem,{value:"TPESearch"},"Bayesian"),r().createElement(N.MenuItem,{value:"GridSearch"},"Grid Search"),r().createElement(N.MenuItem,{value:"RandomSearch"},"Random Search"))),r().createElement("div",{className:"row iteration"},r().createElement(pn,null,r().createElement(N.TextField,{label:"Iteration",type:"number",value:d||"",onChange:e=>p(Number(e.target.value)||void 0),placeholder:"Enter the times",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},inputProps:{min:2},disabled:b}),r().createElement("span",{className:"unit"},"Times"),v.iteration&&r().createElement("p",{className:"error-message"},"Invalid (Must be greater than 1)")),r().createElement(pn,null,r().createElement(N.TextField,{label:"Early Stopping Rounds (Optional)",type:"number",value:m||"",onChange:e=>u(Number(e.target.value)||void 0),placeholder:"Enter the times",size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},inputProps:{min:1},disabled:b}),r().createElement("span",{className:"unit"},"Times"),v.earlyStopping&&r().createElement("p",{className:"error-message"},"Invalid (positive number only)"))),r().createElement(pn,null,r().createElement(vn,{label:"Pipeline Parameter",options:w.sort(((e,t)=>e.name.localeCompare(t.name))).map((e=>Object.assign(Object.assign({},e),{id:e.name}))),value:h,onChange:(e,t)=>(e=>{if(e.length>h.length){const t=e[e.length-1];switch(t.start=-Math.pow(10,Math.ceil(Math.log10(Math.abs(Number(t.value))))),t.end=Math.pow(10,Math.ceil(Math.log10(Math.abs(Number(t.value))))),s){case"TPESearch":case"RandomSearch":t.distribution="float";break;case"GridSearch":t.interval=Math.pow(10,Math.ceil(Math.log10(Math.abs(Number(t.value)))))/2}g([...e.slice(0,-1),t])}else g(e)})(t),placeholder:"Select pipeline parameters you want to optimize",disabled:b})),0===h.length?r().createElement(gr,null,r().createElement("span",null,vr,"No added parameters",r().createElement("i",null,"(Only int and float types will be displayed)"))):h.map((e=>r().createElement(mr,{key:e.name,parameters:w,setParameters:y,parameter:e,selectedParameters:h,setSelectedParameters:g,tuningMethod:s,isDisabled:b}))))})),hr=S().form`
  border: 1px solid var(--border-primary);
  border-radius: 4px;
  padding: 12px;
  overflow: auto;
  margin: 0;

  #link-target-component-label + .hint {
    top: -5px;
    left: -10px;
  }

  #link-target-component-label + .hint svg {
    width: 12px;
    height: 12px;
  }

  #link-target-component-label + .hint svg circle {
    stroke: #999;
  }

  #link-target-component-label + .hint svg path {
    fill: #999;
  }

  .target {
    margin: 12px 0;
  }

  .target p {
    margin: 0 0 8px;
    line-height: 13px;
  }

  .target p b {
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
    color: var(--text-secondary);
  }

  .target pre {
    margin: 0;
    padding: 6px 8px;
    background-color: var(--background-surface);
    border: 1px solid var(--link-box-border);
    max-height: 4em;
    overflow: auto;
    font-weight: 400;
    font-size: 13px;
    line-height: 15px;
  }

  table.target-type {
    width: 100%;
    table-layout: fixed;
    border-collapse: collapse;
    margin: 12px 0;
  }
  table.target-type th {
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
    color: var(--text-secondary);
    text-align: left;
    padding: 0 0 5px;
  }
  table.target-type th:first-of-type {
    width: 215px;
  }
  table.target-type td {
    font-weight: 400;
    font-size: 13px;
    line-height: 15px;
    vertical-align: top;
    word-wrap: break-word;
    padding: 4px 4px 4px 0;
    color: var(--text-secondary);
  }

  .row {
    display: grid;
    gap: 12px 16px;
    grid-template-columns: 3fr 2fr;
    margin: 12px 0;
  }
  .row.iteration {
    grid-template-columns: 1fr 1fr;
  }

  .iteration > div {
    position: relative;
  }

  .iteration .MuiOutlinedInput-input {
    padding-right: 46px;
  }

  .iteration .unit {
    position: absolute;
    top: 24px;
    right: 9px;
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
  }

  .error-message {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAP1BMVEUAAAD0Qzb0Qzb0Qzb0Qzb0Qzb1QTf3RDP2QDf0QzbzRDX0Qzb0Qzb0Qzb1Qzb0Qjf0Qzb0Qzf0Qzb/TTP0QzZZ+DEfAAAAFHRSTlMA5bjxpHZKHhy8acbv39zXz6iKCkABVjAAAACWSURBVCjPfZJZDsMwCEQfNI6dfeP+Z61URZg2Td6XR/JgD8BJTipmoikTKY05TcFpXxZ4tZz09kN/3rcLH0/xOiJerQD+bged/wCy+xXURSbZP4elcGmAIdjFzyusLgRzFliqooaeYKrxkeD+EmrOvpujpCrG0ZwUAs7HMYeANCGH1pbEJm5bbeJd258HdR3t4zLcrs8bSbYfLgXYsgcAAAAASUVORK5CYII=);
    background-repeat: no-repeat;
    background-size: 12px 12px;
    background-position: 0 50%;
    padding-left: 17px;
    font-weight: 400;
    font-size: 10px;
    line-height: 12px;
    color: var(--feedback-fail);
    margin: 4px 0 0;
  }
`,gr=S().p`
  margin: 0;
  height: 160px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 500;
  font-size: 11px;
  line-height: 15px;
  color: var(--text-primary);

  svg {
    vertical-align: text-bottom;
    margin-right: 5px;
  }

  i {
    display: block;
    margin-left: 18px;
    color: #999;
    font-style: normal;
  }
`,vr=r().createElement("svg",{width:"15",height:"15",viewBox:"0 0 15 15",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M6.625 4.65625C6.625 4.29575 6.92075 4 7.28125 4H7.71875C8.07925 4 8.375 4.29575 8.375 4.65625V5.09375C8.375 5.45425 8.07925 5.75 7.71875 5.75H7.28125C7.10741 5.74931 6.9409 5.67995 6.81797 5.55703C6.69505 5.4341 6.62569 5.26759 6.625 5.09375V4.65625ZM9.25 11H5.75V10.125H6.625V7.5H5.75V6.625H8.375V10.125H9.25V11Z",fill:"#6C79F9"}),r().createElement("rect",{x:"1",y:"1",width:"13",height:"13",rx:"6.5",stroke:"#6C79F9"})),fr=ur,xr=[{background:"rgba(255, 99, 132, 0.2)",border:"rgba(255, 99, 132)"},{background:"rgba(255, 159, 64, 0.2)",border:"rgba(255, 159, 64)"},{background:"rgba(255, 205, 86, 0.2)",border:"rgba(255, 205, 86)"},{background:"rgba(75, 192, 192, 0.2)",border:"rgba(75, 192, 192)"},{background:"rgba(54, 162, 235, 0.2)",border:"rgba(54, 162, 235)"},{background:"rgba(153, 102, 255, 0.2)",border:"rgba(153, 102, 255)"},{background:"rgba(201, 203, 207, 0.2)",border:"rgba(201, 203, 207)"}],br=S().div`
  padding: 0 12px;
`,Cr=S().div`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--background-surface);
  border-radius: 4px;
  padding: 4px 8px;
  color: var(--text-secondary);
  font-weight: 400;
  font-size: 13px;
  gap: 4px;
  & > span {
    margin-left: 4px;
    color: var(--text-primary);
  }
  & > div {
    width: 160px;
    margin-left: 4px;
  }
`,Er=S().div`
  display: flex;
  gap: 8px;
  padding: 12px 0;
`,wr=S().div`
  width: 145px;
  & > h4 {
    margin: 0;
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
    color: var(--text-detail);
  }

  & > div {
    margin-top: 4px;
    gap: 12px;
    display: flex;
    flex-direction: column;
    padding: 18px 0 16px;
    & > p {
      height: 30px;
      line-height: 11px;
      font-weight: 400;
      font-size: 11px;
      color: var(--text-secondary);
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      word-break: break-all;
      &::after {
        content: '';
        height: 100%;
        display: inline-block;
        vertical-align: middle;
      }
    }
  }
`,yr=S().div`
  width: 360px;
  .chart-grid {
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-height: 62px;
    background-image: linear-gradient(to right, #efefef 1px, transparent 1px);
    background-size: 35px;
    border: 1px solid #efefef;
    border-width: 1px 0;
    padding: 16px 0;
    margin-top: 4px;
  }
  body[data-theme='dark'] & .chart-grid {
    background-image: linear-gradient(to right, #555 1px, transparent 1px);
    border-color: #555;
  }
  .chart-axis-wrap {
    margin-top: 4px;
    display: flex;
    gap: 22px;
    & > span {
      font-weight: 400;
      font-size: 9px;
      color: #999;
    }
    body[data-theme='dark'] & > span {
      color: #555;
    }
  }
`,kr=S().div`
  width: calc(${e=>e.width}% - 10px);
  height: 30px;
  background: ${e=>e.backgroundColor};
  border: 1px solid ${e=>e.borderColor};
  box-sizing: border-box;
`,Lr=S().button`
  display: flex;
  align-items: center;
  font-weight: 500;
  font-size: 11px;
  padding: 0;
  color: #6c79f9;
  border: none;
  background: transparent;

  .svg-icon {
    display: flex;
    align-items: center;
    transform: ${e=>e.rotate?"rotate(-180deg)":""};
  }

  &:hover {
    color: #95a0ff;
  }
`,_r=r().createElement("svg",{width:"13",height:"13",viewBox:"0 0 13 13",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M6.5013 2.16634L6.5013 10.833M10.293 5.95801L6.5013 2.16634L2.70964 5.95801",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})),Mr=({target:e,importancePlot:t})=>{const[n,l]=(0,a.useState)(0),[o,i]=(0,a.useState)([]),[s,c]=(0,a.useState)(!0);return(0,a.useEffect)((()=>{i(Object.keys(t[n]).map(((e,a)=>({name:e,value:Number(Number(t[n][e]).toFixed(2)),background:xr[(a+xr.length)%xr.length].background,border:xr[(a+xr.length)%xr.length].border}))).sort(((e,t)=>t.value-e.value))),c(!0)}),[n]),r().createElement(br,{id:"importance-plot"},r().createElement(Cr,null,"Parameter importance about",1===e.length?r().createElement("span",null,e[0]):r().createElement("div",null,r().createElement(pn,null,r().createElement(N.Select,{value:n,onChange:e=>l(Number(e.target.value)),fullWidth:!0,MenuProps:{className:"link-select-menu-popover"}},e.map(((e,t)=>r().createElement(N.MenuItem,{key:t,value:t},e))))))),r().createElement(Er,null,r().createElement(wr,null,r().createElement("h4",null,"Parameter Name"),r().createElement("div",null,o.map(((e,t)=>r().createElement("p",{key:t},e.name))))),r().createElement(yr,null,r().createElement("div",null,r().createElement(Lr,{rotate:!s,onClick:()=>(c((e=>!e)),void i((e=>e.reverse())))},"Importance",r().createElement("i",{className:"svg-icon"},_r))),r().createElement("div",{className:"chart-grid"},o.map(((e,t)=>r().createElement(N.Tooltip,{key:t,title:e.value,placement:"top-end",componentsProps:{tooltip:{sx:{backgroundColor:"#222",color:"#fff",fontSize:"13px",marginBottom:"4px !important",border:"1px solid #555"}}}},r().createElement(kr,{width:100*e.value,backgroundColor:e.background,borderColor:e.border}))))),r().createElement("div",{className:"chart-axis-wrap"},Array.from(Array(11),((e,t)=>t/10)).map(((e,t)=>r().createElement("span",{key:t},e)))))))};function Sr(e,t){const n=Number(e);return e.length>t&&n.toExponential().length<=t?n.toExponential():e.length>t?n.toExponential(t):e}const Nr=S().div`
  button {
    font-weight: 500;
    font-size: 13px;
    line-height: 15px;
    color: #999;
    background: transparent;
    border: 0 none;
    padding: 4px 2px 6px;
    border-bottom: 2px solid transparent;
    margin-right: 12px;
    border-radius: 0;
  }
  button.on,
  button:hover {
    color: var(--link-color);
    border-bottom-color: var(--link-color);
  }

  button svg {
    vertical-align: middle;
    margin-right: 2px;
  }
  button.on svg g,
  button:hover svg g,
  button.on svg path,
  button:hover svg path {
    fill: var(--link-color);
  }
`,Ar=S().div`
  height: 262px;
  overflow: auto;
  border: 1px solid var(--border-primary);
  border-radius: 4px;
  padding: 12px;
  margin: 0 0 12px;

  div.no-data {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 500;
    font-size: 13px;
    line-height: 15px;
    color: #999;
    & > svg {
      margin-right: 4px;
    }
  }

  &.LOG {
    padding: 0;
    table {
      border: none;
    }
  }
`,Ir=S().div`
  width: 100%;
  overflow: auto;

  & > p {
    margin: 22px 0 8px;
    color: var(--text-detail);
  }
`,Or=S().table`
  border-spacing: 0;
  border: 1px solid var(--border-primary);
  border-radius: 8px;
  width: 100%;
  box-sizing: border-box;

  thead {
    position: sticky;
    top: 0;
  }

  thead > tr:nth-of-type(1) {
    th:first-of-type {
      /* Fix Blink bug */
      border-top-left-radius: 8px;
    }
    th:last-of-type {
      /* Fix Blink bug */
      border-top-right-radius: 8px;
    }
    th {
      font-size: 11px;
      line-height: 12px;
      padding: 10px 12px 5px;
    }
  }

  thead > tr:nth-of-type(2) {
    th {
      font-size: 13px;
      line-height: 15px;
      border-bottom: 1px solid var(--border-primary);
      padding: 12px;
    }
  }
  th {
    background: var(--background-surface);
    text-align: left;
    color: #999;
    font-weight: 500;
    word-wrap: anywhere;
    white-space: nowrap;
    .multi-ellipsis {
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      word-break: break-all;
      white-space: normal;
    }
  }
  th.trial {
    word-wrap: normal;
  }
  th.trial.radio {
    padding-left: 35px;
  }

  td {
    font-weight: 400;
    font-size: 13px;
    line-height: 15px;
    padding: 6px 12px;
    white-space: nowrap;
  }
  td:first-of-type {
    .single-ellipsis {
      font-weight: bold;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: pre;
    }
    &.serial-num {
      width: 50px;
    }
  }
  th > div,
  td > div {
    max-width: 156px;
    min-width: 26px;
  }
  tbody tr:first-of-type td {
    padding-top: 12px;
  }
  tbody tr:last-child td {
    padding-bottom: 12px;
  }

  td.no-data {
    text-align: center;
    vertical-align: middle;
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
    color: #999;
  }

  td.no-data svg {
    margin-right: 5px;
    vertical-align: text-bottom;
  }
`,Pr=S().pre`
  position: relative;
  color: var(--link-box-text);
  background: var(--background-surface);
  border-radius: 4px;
  padding: 12px 10px 12px 28px;
  color: #f44336;
  font-weight: 400;
  font-size: 9px;
  line-height: 11px;
  white-space: pre-wrap;

  svg {
    position: absolute;
    top: 13px;
    left: 13px;
  }
`,Tr=r().createElement("svg",{width:"13",height:"13",viewBox:"0 0 13 13",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M11.4722 3C10.9352 3 10.5 3.43536 10.5 3.97222C10.5 4.08247 10.5224 4.1865 10.556 4.28528L8.18611 6.32597C8.01986 6.19356 7.81239 6.11111 7.58333 6.11111C7.3191 6.11111 7.08012 6.21728 6.90511 6.38839L5.04875 5.45894C5.0126 4.95475 4.59668 4.55556 4.08333 4.55556C3.54648 4.55556 3.11111 4.99092 3.11111 5.52778C3.11111 5.67478 3.14611 5.81264 3.20444 5.93747L1.31172 8.11992C1.20556 8.08025 1.09219 8.05556 0.972222 8.05556C0.435361 8.05556 0 8.49092 0 9.02778C0 9.56464 0.435361 10 0.972222 10C1.50908 10 1.94444 9.56464 1.94444 9.02778C1.94444 8.89847 1.918 8.7754 1.87211 8.66261L3.79556 6.45178C3.88714 6.48017 3.98242 6.5 4.08333 6.5C4.36625 6.5 4.61863 6.37711 4.79635 6.18403L6.61207 7.09442C6.6185 7.62603 7.05015 8.05556 7.58333 8.05556C8.1204 8.05556 8.55556 7.62019 8.55556 7.08333C8.55556 7.06603 8.55147 7.04989 8.5505 7.03278L11.0794 4.86025C11.1998 4.91353 11.332 4.94444 11.4722 4.94444C12.0093 4.94444 12.4444 4.50928 12.4444 3.97222C12.4444 3.43536 12.0093 3 11.4722 3H11.4722Z",fill:"#999999"})),Fr=r().createElement("svg",{width:"12",height:"13",viewBox:"0 0 12 13",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M2 11H9.9465C10.498 11 10.9465 10.5515 10.9465 10V3C10.9465 2.4485 10.498 2 9.9465 2H2C1.4485 2 1 2.4485 1 3V10C1 10.5515 1.4485 11 2 11ZM2 10V7.5H4V10H2ZM7 4V6.5H5V4H7ZM4 4V6.5H2V4H4ZM5 10V7.5H7V10H5ZM8 10V7.5H9.947V10H8ZM9.9465 6.5H8V4H9.9465V6.5Z",fill:"#999999"})),Vr=r().createElement("svg",{width:"15",height:"10",viewBox:"0 0 15 10",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M6 0C5.58516 0 5.25 0.335156 5.25 0.75V9.25C5.25 9.66484 5.58516 10 6 10H9C9.41484 10 9.75 9.66484 9.75 9.25V0.75C9.75 0.335156 9.41484 0 9 0H6ZM0.75 2.5C0.335156 2.5 0 2.83516 0 3.25V9.25C0 9.66484 0.335156 10 0.75 10H3.75C4.16484 10 4.5 9.66484 4.5 9.25V3.25C4.5 2.83516 4.16484 2.5 3.75 2.5H0.75ZM10.5 5.75V9.25C10.5 9.66484 10.8352 10 11.25 10H14.25C14.6648 10 15 9.66484 15 9.25V5.75C15 5.33516 14.6648 5 14.25 5H11.25C10.8352 5 10.5 5.33516 10.5 5.75Z",fill:"#999999"})),Hr=r().createElement("svg",{width:"11",height:"11",viewBox:"0 0 11 11",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("g",{fill:"#999999"},r().createElement("circle",{cx:"1.82",cy:"1.82",r:"1.12"}),r().createElement("circle",{cx:"5.51",cy:"1.82",r:"1.12"}),r().createElement("circle",{cx:"9.20",cy:"1.82",r:"1.12"}),r().createElement("circle",{cx:"1.82",cy:"5.51",r:"1.12"}),r().createElement("circle",{cx:"5.51",cy:"5.51",r:"1.12"}),r().createElement("circle",{cx:"9.20",cy:"5.51",r:"1.12"}),r().createElement("circle",{cx:"1.82",cy:"9.20",r:"1.12"}),r().createElement("circle",{cx:"5.51",cy:"9.20",r:"1.12"}),r().createElement("circle",{cx:"9.20",cy:"9.20",r:"1.12"}))),Rr=r().createElement("svg",{width:"10",height:"10",viewBox:"0 0 10 10",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M5 0C2.25 0 0 2.25 0 5C0 7.75 2.25 10 5 10C7.75 10 10 7.75 10 5C10 2.25 7.75 0 5 0ZM4.7 2.45H5.3C5.45 2.45 5.55 2.55 5.55 2.7L5.45 5.8C5.45 5.95 5.35 6.05 5.2 6.05H4.8C4.65 6.05 4.55 5.95 4.55 5.8L4.45 2.7C4.45 2.55 4.55 2.45 4.7 2.45ZM5.4 7.55C5.3 7.65 5.15 7.7 5 7.7C4.85 7.7 4.7 7.65 4.6 7.55C4.5 7.45 4.45 7.3 4.45 7.15C4.45 7 4.5 6.85 4.6 6.75C4.7 6.65 4.85 6.6 5 6.6C5.15 6.6 5.3 6.65 5.4 6.75C5.5 6.85 5.55 7 5.55 7.15C5.6 7.35 5.55 7.45 5.4 7.55Z",fill:"#F44336"})),zr=({initialParameters:e,trial:t,target:n,results:l,paretoPlot:o,importancePlot:i,errorResult:s,selectedBestTrials:c,setSelectedBestTrials:d})=>{const[p,m]=(0,a.useState)("GRAPH"),u=()=>void 0===l?[]:Object.keys(Object.entries(l)[0][1].parameters);return(0,a.useEffect)((()=>{if(!o||"PARETO"!==p)return;const{data:e,layout:t}=o,n=e.map((e=>Object.assign(Object.assign({},e),{marker:Object.assign(Object.assign({},e.marker),{size:6})}))),a=Object.assign(Object.assign({},t),{title:"",height:262,margin:{t:14,r:14,l:14,b:14}});tr().newPlot("pareto-plot",n,a)}),[o,p]),(0,a.useEffect)((()=>{if(void 0===l)return;const e=Object.entries(l);1===e.length&&d(e[0][0])}),[l]),r().createElement(r().Fragment,null,r().createElement(Nr,null,r().createElement("button",{className:"GRAPH"===p?"on":"",onClick:()=>m("GRAPH")},Tr," Iteration Graph"),r().createElement("button",{className:"LOG"===p?"on":"",onClick:()=>m("LOG")},Fr," Log Table"),r().createElement("button",{className:"IMPORTANCE"===p?"on":"",onClick:()=>m("IMPORTANCE")},Vr," Parameter Importance"),n.length>1&&n.length<4&&r().createElement("button",{className:"PARETO"===p?"on":"",onClick:()=>m("PARETO")},Hr," Pareto Front Plot")),r().createElement(Ar,{className:p},"GRAPH"===p&&r().createElement(or,{data:t,legends:n}),"LOG"===p&&(t.length>0?r().createElement(Or,null,r().createElement("thead",null,r().createElement("tr",null,r().createElement("th",null),n.length>0&&r().createElement("th",{colSpan:n.length},"TARGET"),t.length>0&&r().createElement("th",{colSpan:t.length},"PARAMETERS")),r().createElement("tr",null,r().createElement("th",{className:"trial"},"Trial"),1===n.length?r().createElement("th",null,"Target value"):n.map(((e,t)=>r().createElement("th",{key:t},r().createElement("div",{className:"multi-ellipsis"},e)))),t.length>0&&Object.keys(t[0][2]).map(((e,t)=>r().createElement("th",{key:t},r().createElement("div",{className:"multi-ellipsis"},e)))))),r().createElement("tbody",null,t.length>0?t.map(((e,t)=>r().createElement("tr",{key:t},r().createElement("td",{className:"serial-num"},e[0]),Object.keys(e[1]).map(((t,n)=>r().createElement("td",{key:n},r().createElement("div",null,Sr(e[1][t].toString(),10))))),Object.keys(e[2]).map(((t,n)=>r().createElement("td",{key:n},r().createElement("div",null,Sr(e[2][t].toString(),10)))))))):r().createElement("tr",null,r().createElement("td",{colSpan:1+n.length,style:{height:"166px"}})))):r().createElement("div",{className:"no-data"},vr," This table will be displayed after the run is complete.")),"IMPORTANCE"===p&&(i?r().createElement(Mr,{target:n,importancePlot:i}):r().createElement("div",{className:"no-data"},vr," This chart will be displayed after the run is complete.")),"PARETO"===p&&(o?r().createElement("div",{key:"pareto-plot-graph",id:"pareto-plot"}):r().createElement("div",{key:"no-data-graph",className:"no-data"},vr," This plot will be displayed after the run is complete."))),s.length>0?r().createElement(Pr,null,Rr,s):r().createElement(Ir,null,n.length>1?r().createElement(r().Fragment,null,r().createElement("p",null,"Number of Best Trials: ",l?Object.entries(l).length:""),r().createElement(Or,null,r().createElement("thead",null,r().createElement("tr",null,r().createElement("th",null),r().createElement("th",{colSpan:n.length},"TARGET"),u().length>0&&r().createElement("th",{colSpan:u().length},"PARAMETERS")),r().createElement("tr",null,r().createElement("th",{className:"trial radio"},"Trial"),n.map(((e,t)=>r().createElement("th",{key:t},r().createElement("div",{className:"multi-ellipsis"},e)))),u().map(((e,t)=>r().createElement("th",{key:t},r().createElement("div",{className:"multi-ellipsis"},e)))))),r().createElement("tbody",null,l?Object.entries(l).map(((e,t)=>r().createElement("tr",{key:t},r().createElement("td",null,r().createElement(pn,null,r().createElement(N.FormControlLabel,{value:e[0],control:r().createElement(N.Radio,{name:"selectedbesttrials",onChange:()=>d(e[0]),checked:c===e[0]}),label:Number(e[0])+1}))),e[1].values.map(((e,t)=>r().createElement("td",{key:t},Sr(e.toString(),10)))),Object.values(e[1].parameters).map(((e,t)=>r().createElement("td",{key:t},Sr(e.toString(),10))))))):r().createElement("td",{colSpan:n.length+1,className:"no-data"},vr,"The results will be displayed after the run is complete")))):r().createElement(r().Fragment,null,r().createElement("p",null,"Best Target Value: ",l?Sr(Object.values(l)[0].values[0].toString(),10):""),r().createElement(Or,null,r().createElement("thead",null,r().createElement("tr",null,r().createElement("th",null,"Parameter Name"),r().createElement("th",null,"Origin Value"),r().createElement("th",null,"Optimal Value"))),r().createElement("tbody",null,l?(void 0===l?[]:Object.entries(Object.entries(l)[0][1].parameters).map((t=>{var n;return[t[0],null===(n=e.find((e=>e.name===t[0])))||void 0===n?void 0:n.value,t[1]]}))).map(((e,t)=>r().createElement("tr",{key:t},r().createElement("td",null,r().createElement("div",{className:"single-ellipsis"},e[0])),r().createElement("td",{title:e[1]},Sr(e[1].toString(),10)),r().createElement("td",{title:e[2]},Sr(e[2].toString(),10))))):r().createElement("tr",null,r().createElement("td",{colSpan:3,className:"no-data"},vr,"The results will be displayed after the run is complete")))))))};ke.addEvent(we.HPOExecutionTrial),ke.addEvent(we.HPOCompleted),ke.addEvent(we.HPOEarlyStopping),ke.addEvent(we.HPOCanceling),ke.addEvent(we.HPOInputError),ke.addEvent(we.HPOTargetValueError),ke.addEvent(we.HPOError);const Zr=S().div`
  width: 964px;
  height: 691px;
  padding: 28px 20px;
  display: grid;
  grid-template-columns: 376px 1fr;
  grid-column-gap: 20px;
  grid-template-rows: 55px calc(100% - 55px);
  overflow: auto;
  color: var(--text-primary);
  box-shadow: var(--popover-shadow);
  background-color: var(--layout-background-base);

  div.header {
    height: 30px;
    grid-column: 1 / 3;
    grid-row: 1;
    margin: 0 0 25px;
    display: flex;
    justify-content: space-between;
  }

  h1 {
    display: flex;
    align-items: center;
    font-weight: 700;
    font-size: 18px;
  }

  h1 svg {
    margin-right: 8px;
  }
  body[data-theme='dark'] & h1 svg circle {
    fill: #3b3b4a;
  }

  a.guide {
    display: inline-block;
    font-weight: 500;
    font-size: 13px;
    line-height: 100%;
    padding: 6px 10px;
    border: 1px solid var(--border-primary);
    border-radius: 4px;
    color: var(--text-secondary);
  }
  a.guide:hover {
    background: var(--background-surface);
  }

  a.guide svg {
    vertical-align: bottom;
    margin-right: 8px;
  }
  a.guide svg path {
    stroke: var(--text-secondary);
  }

  section {
    display: grid;
    grid-template-rows: 38px 1fr 83px;
    grid-row: 2;
  }
  .setting {
    grid-column: 1;
  }
  .result {
    grid-column: 2;
  }

  h2 {
    margin: 0;
    padding: 4px 4px 0;
    height: 18px;
    font-weight: 700;
    font-size: 15px;
    line-height: 18px;
    color: var(--text-primary);
  }

  h2 i {
    display: inline-block;
    font-weight: 700;
    font-size: 13px;
    line-height: 15px;
    color: #ffb077;
    padding: 4px 8px;
    background: #fff1dc;
    border-radius: 2px;
    margin-left: 8px;
    font-style: normal;
  }
  body[data-theme='dark'] & h2 i.ready {
    color: #ffb077;
    background-color: #644415;
  }
  h2 i.run {
    color: #6c79f9;
    background-color: #f5f6ff;
  }
  body[data-theme='dark'] & h2 i.run {
    background-color: #26264e;
  }
  h2 i.complete {
    color: #419640;
    background-color: #eaffea;
  }
  body[data-theme='dark'] & h2 i.complete {
    background-color: #25392f;
  }
  h2 i.stop {
    color: #464555;
    background-color: #f6f9fa;
  }
  body[data-theme='dark'] & h2 i.stop {
    color: #999;
    background-color: #333;
  }
  h2 i.fail {
    color: #f44336;
    background-color: #fcf7f8;
  }
  body[data-theme='dark'] & h2 i.fail {
    background-color: #230a0a;
  }

  .result .main {
    overflow: auto;
  }

  .main + div {
    margin-top: 47px;
  }
`,Br=Object.assign(Object.assign({},re),{".MuiPaper-root":Object.assign(Object.assign({},re[".MuiPaper-root"]),{maxWidth:"inherit"})}),jr=r().createElement("svg",{width:"30",height:"30",viewBox:"0 0 30 30",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("circle",{cx:"15",cy:"15",r:"15",fill:"#EBECFC"}),r().createElement("rect",{x:"7",y:"8",width:"14.4226",height:"2",rx:"1",fill:"#6C79F9"}),r().createElement("rect",{x:"7",y:"12",width:"8.11271",height:"2",rx:"1",fill:"#6C79F9"}),r().createElement("rect",{x:"7",y:"16",width:"5.40847",height:"2",rx:"1",fill:"#6C79F9"}),r().createElement("path",{d:"M22.786 13.4744C22.7654 13.4147 22.7309 13.3614 22.6857 13.3196C22.6404 13.2778 22.586 13.2489 22.5276 13.2357C22.4691 13.2221 22.4085 13.2251 22.3519 13.2444C22.2952 13.2636 22.2445 13.2984 22.2048 13.3453L20.515 15.3111L19.1817 15.101L18.8376 13.7203L20.5461 11.7329C20.5861 11.6865 20.614 11.6297 20.627 11.5681C20.64 11.5064 20.6376 11.4421 20.6202 11.3813C20.6028 11.3205 20.5709 11.2653 20.5276 11.2212C20.4843 11.177 20.4312 11.1455 20.3733 11.1295C20.0357 11.0314 19.6866 10.9886 19.3382 11.0026C17.4414 11.1035 15.9947 12.826 16.1133 14.8423C16.1272 15.0786 16.1674 15.3163 16.2379 15.5767C15.8712 15.9359 14.7239 17.2652 14.3271 17.6179C13.7598 18.122 13.117 18.6925 12.2457 19.5671C11.9955 19.8234 11.8005 20.1343 11.6737 20.4789C11.547 20.8235 11.4914 21.1938 11.5109 21.565C11.5939 22.9766 12.7416 24.0674 14.0694 23.9968C14.4189 23.977 14.7591 23.8762 15.0662 23.7015C15.3733 23.5267 15.6398 23.2822 15.8471 22.9852C16.4114 22.1924 16.9492 21.3786 17.4593 20.5452C17.738 20.0967 18.781 18.6842 19.0677 18.2662C19.3189 18.3123 19.5462 18.3281 19.7684 18.3162C21.6652 18.2154 23.1119 16.4929 22.9933 14.4765C22.97 14.1342 22.9001 13.7966 22.786 13.4744ZM13.9619 22.1683C13.7794 22.178 13.5999 22.1103 13.4628 21.98C13.3257 21.8497 13.2423 21.6675 13.2309 21.4736C13.2195 21.2796 13.281 21.0897 13.402 20.9457C13.5229 20.8017 13.6934 20.7153 13.8758 20.7056C14.0583 20.6959 14.2378 20.7637 14.3749 20.894C14.512 21.0243 14.5955 21.2064 14.6069 21.4004C14.6183 21.5944 14.5567 21.7842 14.4358 21.9283C14.3148 22.0723 14.1444 22.1586 13.9619 22.1683Z",fill:"#927AF8"})),Dr=r().createElement("svg",{width:"14",height:"12",viewBox:"0 0 14 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M1 2.25C1 2.25 1.9375 1 4.125 1C6.3125 1 7.25 2.25 7.25 2.25V11C7.25 11 6.3125 10.375 4.125 10.375C1.9375 10.375 1 11 1 11V2.25ZM7.25 2.25C7.25 2.25 8.1875 1 10.375 1C12.5625 1 13.5 2.25 13.5 2.25V11C13.5 11 12.5625 10.375 10.375 10.375C8.1875 10.375 7.25 11 7.25 11V2.25Z",stroke:"#555555",strokeLinecap:"round",strokeLinejoin:"round"})),Wr=r().createElement("svg",{width:"13",height:"12",viewBox:"0 0 13 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{opacity:"0.9",d:"M6.5 12C3.1865 12 0.5 9.3135 0.5 6C0.5 2.6865 3.1865 0 6.5 0C9.8135 0 12.5 2.6865 12.5 6C12.5 9.3135 9.8135 12 6.5 12ZM5 3.0045V8.9955L9.5 6L5 3.0045Z",fill:"white"})),Ur=r().createElement("svg",{width:"13",height:"12",viewBox:"0 0 13 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M6.5 0.1875C3.28906 0.1875 0.6875 2.78906 0.6875 6C0.6875 9.21094 3.28906 11.8125 6.5 11.8125C9.71094 11.8125 12.3125 9.21094 12.3125 6C12.3125 2.78906 9.71094 0.1875 6.5 0.1875ZM8.75 7.875C8.75 8.08125 8.58125 8.25 8.375 8.25H4.625C4.41875 8.25 4.25 8.08125 4.25 7.875V4.125C4.25 3.91875 4.41875 3.75 4.625 3.75H8.375C8.58125 3.75 8.75 3.91875 8.75 4.125V7.875Z",fill:"white"})),$r=({close:e,commands:t})=>{const[n,l]=(0,a.useState)(""),[o,i]=(0,a.useState)(""),[s,c]=(0,a.useState)([]),[d,p]=(0,a.useState)(10),[m,u]=(0,a.useState)(),[h,g]=(0,a.useState)([]),[v,f]=(0,a.useState)("ready"),[x,b]=(0,a.useState)([]),[C,E]=(0,a.useState)(),[w,y]=(0,a.useState)(),[k,L]=(0,a.useState)(),[_,M]=(0,a.useState)(!1),[S,A]=(0,a.useState)(),[I,O]=(0,a.useState)(""),[P,T]=(0,a.useState)(0),[F,V]=(0,a.useState)([]),[H,R]=(0,a.useState)([]),[z,Z]=(0,a.useState)({}),[B,j]=(0,a.useState)(),[D,W]=(0,a.useState)(""),U=()=>{$(F.map((e=>({name:e.name,value:e.value}))))},$=e=>{const n=di.currentWidget.metadata.parameters;let a=!1;for(const t of e){const{name:e,value:r}=t,l=n.findIndex((t=>t.name===e));n[l]&&(n[l].value=r.toString(),a=!0)}a&&(null==t||t.execute(Rt.dagParameters,n),di.currentWidget.metadata.parameters=n)},G=e=>{const{trials:t,values:n,parameters:a}=e.successful;b([...x,[t+1,n,a]])},q=e=>{const{best_trials:t,pareto_front_plot:n,parameter_importance:a}=e.successful;E(t),y(n),L(a),f("complete")},K=e=>{},Y=e=>{f("stop"),U()},X=e=>{O(e.msg),f("fail"),U()},J=()=>"number"==typeof d&&Number.isInteger(d)&&d>1;return(0,a.useEffect)((()=>{const e=n.length>0&&null!==D&&D.length>0,t=o.length>0,a=J(),r=void 0===m||void 0!==m&&Number.isInteger(m)&&m>0;Z(Object.assign(Object.assign({},z),{iteration:!a,earlyStopping:!r}));const l=e&&t&&a&&r,i=h.filter((e=>{const t="GridSearch"===o||"discrete_uniform"===e.distribution,n=!t||t&&e.interval>0,a="GridSearch"===o||"GridSearch"!==o&&void 0!==e.distribution,r=void 0!==e.start&&e.start.toString().length>0,l=void 0!==e.end&&e.end.toString().length>0,i=r&&l&&Number(e.start)<Number(e.end);return!n||!a||!i})),c=h.length>0&&0===i.length,p="complete"!==v||void 0===S||!(0,Ja.isEqual)(S,{componentKey:n,iteration:d,tuningMethod:o,type:s,earlyStopping:m,selectedParameters:h}),u=H.length>0;M(l&&c&&p&&u)}),[n,s,o,d,m,h,v]),(0,a.useEffect)((()=>(ke.addListener(we.HPOExecutionTrial,G),ke.addListener(we.HPOCompleted,q),ke.addListener(we.HPOEarlyStopping,K),ke.addListener(we.HPOCanceling,Y),ke.addListener(we.HPOInputError,X),ke.addListener(we.HPOTargetValueError,X),ke.addListener(we.HPOError,X),()=>{ke.removeListener(we.HPOExecutionTrial,G),ke.removeListener(we.HPOCompleted,q),ke.removeListener(we.HPOEarlyStopping,K),ke.removeListener(we.HPOCanceling,Y),ke.removeListener(we.HPOInputError,X),ke.removeListener(we.HPOTargetValueError,X),ke.removeListener(we.HPOError,X)}))),r().createElement(N.Dialog,{sx:Br,open:!0},r().createElement(Zr,null,r().createElement("div",{className:"header"},r().createElement("h1",null,jr,"Hyper-Parameter Optimizer"),r().createElement("a",{href:ra.origin+"/guide/ml-development/dev-instances/set-pipeline-parameters",target:"_blank",className:"guide",rel:"noreferrer"},Dr,"Guide")),r().createElement("section",{className:"setting"},r().createElement("h2",null,"Settings"),r().createElement(fr,{componentKey:n,setComponentKey:l,type:s,setType:c,target:H,setTarget:R,tuningMethod:o,setTuningMethod:i,iteration:d,setIteration:p,earlyStopping:m,setEarlyStopping:u,errorMessage:z,selectedParameters:h,setSelectedParameters:g,expression:D,setExpression:W,isDisabled:"run"===v}),r().createElement(Qa,null,"run"===v?r().createElement("button",{className:"primary full-width danger",onClick:()=>{var e,t;null===(t=null===(e=di.currentWidget)||void 0===e?void 0:e.kernel)||void 0===t||t.interrupt()}},Ur,"Stop"):r().createElement("button",{className:"primary full-width",onClick:()=>{const e=h.map((e=>{const t=Object.assign({},e);return t.interval&&!isNaN(t.interval)&&(t.interval=Number(t.interval)),t.start&&!isNaN(t.start)&&(t.start=Number(t.start)),t.end&&!isNaN(t.end)&&(t.end=Number(t.end)),t}));"number"==typeof d&&J()?(b([]),E(void 0),L(void 0),y(void 0),j(void 0),O(""),T(d),V(e),async function(e,t,n,a,r,l){var o;const i=null===(o=di.currentWidget)||void 0===o?void 0:o.kernel;if(!me.checkCodeExecutable(i)||!i)return!1;const s=`%%mrxlink_optimize_parameters -i ${e} -n ${t} -o ${n}${a.length>0?` -m ${a.map((e=>"max"===e?1:0)).join(" ")}`:""}${r?` -e ${r}`:""}\n{\n    ${l.map((e=>`"${e.name}": {\n        "type": "${e.type}",\n        ${"GridSearch"===n?`"interval": ${e.interval}`:`"distribution": "${e.distribution}"`},\n        ${"discrete_uniform"===e.distribution?`"interval": ${e.interval},`:""}\n        "low": "${e.start}",\n        "high": "${e.end}"\n    }`)).join(",\n    ")}\n}\n`;i.requestExecute({code:s,store_history:!1},!1,{}).done}(n,d,o,s,m,e),f("run"),A((0,Ja.cloneDeep)({componentKey:n,iteration:d,tuningMethod:o,type:s,earlyStopping:m,selectedParametersWithNumber:e}))):Z({iteration:!0})},disabled:!_},Wr,"Run"))),r().createElement("section",{className:"result"},r().createElement("h2",null,"Result ",(()=>{let e="";switch(v){case"ready":e="Ready";break;case"run":e=`Running (${x.length}/${P})`;break;case"complete":e=`Completed (${x.length}/${P})`;break;case"stop":e="Stopped";break;case"fail":e="Failed"}return r().createElement("i",{className:v},e)})()," "),r().createElement("div",{className:"main"},r().createElement(zr,{initialParameters:F,trial:x,target:H,results:C,paretoPlot:w,importancePlot:k,errorResult:I,selectedBestTrials:B,setSelectedBestTrials:j})),r().createElement(Qa,null,r().createElement("button",{onClick:()=>{U(),e()},disabled:"run"===v},"Close"),r().createElement("button",{className:"primary",onClick:()=>{B&&($(Object.entries(C[B].parameters).map((e=>({name:e[0],value:e[1]})))),e())},disabled:!B},"Apply")))))};function Gr(e){e.style.height="auto",e.style.height=`${e.scrollHeight+3}px`}function qr(e){const t=new ResizeObserver((e=>{for(const t of e)Gr(t.target)}));return e&&t.observe(e),()=>{e&&t.unobserve(e)}}const Kr=({backgroundColor:e,border:t,multiline:n})=>{let a=_a.css`
    box-sizing: border-box;
    width: 100%;
    min-height: 32px;
    padding: 4px 8px 4px 8px;
    line-height: 22px;
    border-radius: 4px;
    border: 1px solid var(--link-global-parameter-border);
    background-color: transparent;

    color: var(--text-primary);
    font-weight: 400;
    font-size: 12px;
    background-color: ${e};

    resize: none;

    :focus {
      background-color: var(--link-global-parameter-empty-input-background);
    }
  `;return n&&(a=_a.css`
      ${a};
      max-height: 200px;
      overflow: auto;
    `),t&&(a=_a.css`
      ${a};
      border: ${t};
    `),a},Yr=S().textarea((({backgroundColor:e,border:t})=>Kr({backgroundColor:e,border:t,multiline:!0}))),Xr=S().input((({backgroundColor:e,border:t})=>Kr({backgroundColor:e,border:t,multiline:!1}))),Jr=e=>{var t,n;const l=(0,a.useRef)(null),o=(0,a.useRef)(null),[i,s]=(0,a.useState)(null),[c,d]=(0,a.useState)(null),[p,m]=(0,a.useState)(null),u=(0,a.useCallback)((()=>{e.deleteFunc(e.parameter.id)}),[e.parameter]);return(0,a.useEffect)((()=>{var t;"runway_dataset"===(null===(t=e.parameter.metadata)||void 0===t?void 0:t.resource_type)&&zn().then((e=>s(e)))}),[]),(0,a.useEffect)((()=>{let e;return l.current&&(Gr(l.current),e=qr(l.current)),()=>{null==e||e()}}),[l]),(0,a.useEffect)((()=>{let e;return o.current&&(Gr(o.current),e=qr(o.current)),()=>{null==e||e()}}),[o]),(0,a.useEffect)((()=>{const t=function(){var t,n,a,r,l;if(void 0===e.parameter.metadata||"runway_dataset"!==(null===(t=e.parameter.metadata)||void 0===t?void 0:t.resource_type)||"number"!=typeof(null===(n=e.parameter.metadata)||void 0===n?void 0:n.resource_id))return null;const o=null==i?void 0:i.find((t=>{var n;return t.id===(null===(n=e.parameter.metadata)||void 0===n?void 0:n.resource_id)}));if(void 0===o)return null;let s;return(null===(a=e.parameter.metadata)||void 0===a?void 0:a.dataset_version_id)?s=null===(r=o.data_snapshot_versions)||void 0===r?void 0:r.find((t=>{var n;return t.id===(null===(n=e.parameter.metadata)||void 0===n?void 0:n.dataset_version_id)})):(null===(l=o.data_snapshot_versions)||void 0===l?void 0:l.length)>0&&(s=o.data_snapshot_versions.reduce(((e,t)=>e.version>t.version?e:t),o.data_snapshot_versions[0])),{dataset:o,version:s}}();if(!t||!t.dataset||!t.version)return d(null),void m(null);d(t.dataset),m(t.version)}),[i,e.parameter]),r().createElement(Ka,{index:e.index},r().createElement("div",{className:"input-item"},r().createElement(Xr,{ref:l,value:e.parameter.name,onChange:t=>(t=>{Gr(t.target);const n=e.parameter;n.saved=!1,n.name=t.target.value.replace(/(\s*)/g,"").length>0?t.target.value:"",e.setParameter(n),e.setIsEnableSave(!0)})(t),backgroundColor:e.parameter.saved?"var(--link-global-parameter-exist-input-background)":"var(--link-global-parameter-empty-input-background)",border:e.parameter.isNameError()?"1px solid var(--link-global-parameter-invalid-input-border-color)":e.parameter.saved?"1px solid var(--link-global-parameter-exist-input-border-color)":"1px solid var(--link-global-parameter-valid-input-border-color)"}),e.parameter.isNameError()&&r().createElement("div",{className:"input-result-box"},r().createElement("div",{className:"error-txt"},Fe,r().createElement("div",null,e.parameter.errorName)))),r().createElement("div",{className:"input-item input-item-dataset"},"runway_dataset"===(null===(t=e.parameter.metadata)||void 0===t?void 0:t.resource_type)&&r().createElement(r().Fragment,null,r().createElement(Dn,{initialValue:{dataset:c,version:p,isLatest:(null===(n=e.parameter.metadata)||void 0===n?void 0:n.is_latest)||!1},onChange:(t,n,a)=>{d(t),m(n);const r=e.parameter;r.saved=!1,r.value=`"${a?Zn(n):n.file_path_at_link}"`,r.metadata={resource_type:"runway_dataset",resource_id:t.id,dataset_version_id:n.id,is_latest:a,resource_name:t.name},e.setParameter(r),e.setIsEnableSave(!0)},style:{height:"33px",padding:"3px",color:"#777",backgroundColor:e.parameter.saved?"var(--link-global-parameter-exist-input-background)":"var(--link-global-parameter-empty-input-background)",border:e.parameter.isValueError()?"1px solid var(--link-global-parameter-invalid-input-border-color)":e.parameter.saved?"1px solid var(--link-global-parameter-exist-input-border-color)":"1px solid var(--link-global-parameter-valid-input-border-color)"}}),(e.parameter.isValueError()||e.parameter.value&&i&&-1===(null==c?void 0:c.id))&&r().createElement("div",{className:"input-result-box",style:{marginTop:"5px"}},e.parameter.isValueError()&&r().createElement("div",{className:"error-txt"},Fe,r().createElement("div",null,e.parameter.errorValue)),!e.parameter.isValueError()&&e.parameter.value&&i&&-1===(null==c?void 0:c.id)&&r().createElement("div",{className:"error-txt"},Fe,r().createElement("div",null,"Invalid dataset")))),(!e.parameter.metadata||"runway_dataset"!==e.parameter.metadata.resource_type)&&r().createElement(r().Fragment,null,r().createElement(Yr,{ref:o,rows:1,value:e.parameter.value,onChange:t=>(t=>{Gr(t.target);const n=e.parameter;n.saved=!1,n.value=t.target.value.replace(/(\s*)/g,"").length>0?t.target.value:"",e.setParameter(n),e.setIsEnableSave(!0)})(t),backgroundColor:e.parameter.saved?"var(--link-global-parameter-exist-input-background)":"var(--link-global-parameter-empty-input-background)",border:e.parameter.isValueError()?"1px solid var(--link-global-parameter-invalid-input-border-color)":e.parameter.saved?"1px solid var(--link-global-parameter-exist-input-border-color)":"1px solid var(--link-global-parameter-valid-input-border-color)"}),e.parameter.isValueError()&&r().createElement("div",{className:"input-result-box"},r().createElement("div",{className:"error-txt"},Fe,r().createElement("div",null,e.parameter.errorValue))))),r().createElement("div",{className:"remove-button-container"},r().createElement("div",{className:"remove-button",onClick:u},"﹣")))};var Qr;!function(e){e.None="None",e.Required="Required",e.Invalid="Invalid",e.DuplicatedName="Duplicated Name"}(Qr||(Qr={}));class el{constructor(e,t,n,a){this.name="",this.value="",this.type="",this.id=Za(),this.errorName=Qr.None,this.errorValue=Qr.None,this.saved=!1,this.metadata=void 0,this.name=e,this.value=t,this.type=n||"",this.metadata="runway_dataset"===(null==a?void 0:a.resource_type)?a:void 0,this.saved=!!n}checkError(){var e,t;let n;n=Qr.None;const a=null===(e=this.name)||void 0===e?void 0:e.trim();a?(el.regEx.test(a)||(n=Qr.Invalid),""===a.replace(/_/g,"")&&(n=Qr.Invalid)):n=Qr.Required,n===Qr.None&&(this.name=a),this.errorName=n,n=Qr.None;const r=null===(t=this.value)||void 0===t?void 0:t.trim();return r?'"'===r.charAt(0)&&'"'===r.charAt(r.length-1)||"'"===r.charAt(0)&&"'"===r.charAt(r.length-1)||"{"===r.charAt(0)&&"}"===r.charAt(r.length-1)||"["===r.charAt(0)&&"]"===r.charAt(r.length-1)||"("===r.charAt(0)&&")"===r.charAt(r.length-1)||this.isNumber(r)||"True"===r||"False"===r||(n=Qr.Invalid):n=Qr.Required,n===Qr.None&&(this.value=r),this.errorValue=n,this.isError()&&(this.type=""),this.isError()}isNameError(){return this.errorName!==Qr.None}isValueError(){return this.errorValue!==Qr.None}isError(){return this.isNameError()||this.isValueError()}isNumber(e){return!isNaN(parseFloat(String(e)))&&isFinite(Number(e))}}el.regEx=new RegExp("^[a-zA-Z_$][a-zA-Z_$0-9]*$");const tl=el,nl=(0,_.x)((e=>{const[t,n]=(0,a.useState)([]),[l,o]=(0,a.useState)(!1),[i,s]=(0,a.useState)(!1);(0,a.useEffect)((()=>{var e,t;const a=null===(e=di.currentWidget)||void 0===e?void 0:e.metadata;a&&n(null===(t=a.parameters)||void 0===t?void 0:t.map((e=>new tl(e.name,e.value,e.type,e.metadata))))}),[]),(0,a.useEffect)((()=>(ke.removeListener(we.ParametersUpdated,c),ke.addListener(we.ParametersUpdated,c),()=>{ke.removeListener(we.ParametersUpdated,c)})),[t]);const c=(0,a.useCallback)((a=>{var r,l;const o=a[a.status].entries;if("successful"===a.status){const t=null===(r=di.currentWidget)||void 0===r?void 0:r.metadata;t&&(t.parameters=o),n(o.map((e=>new tl(e.name,e.value,e.type,e.metadata)))),null===(l=e.tracker.currentWidget)||void 0===l||l.context.save()}else"failed"===a.status&&(u.error(a.msg),o.forEach((e=>{const n=null==t?void 0:t.find((t=>e.name===t.name));n&&(n.type="",n.errorName=Qr.Invalid,n.errorValue=Qr.Invalid)})),n([...t]))}),[t]),d=(0,a.useCallback)((e=>{let t=!1;return e.forEach((n=>{const a=e.filter((e=>n.name&&e.name===n.name));if(a.length>1)return a.forEach(((e,t)=>{e.errorName=Qr.DuplicatedName})),void(t=!0)})),t}),[]),p=(0,a.useCallback)(function(r,i){const s=(0,a.useRef)(null);return(...a)=>{s.current&&clearTimeout(s.current),s.current=setTimeout((()=>{(()=>{var a;if(!l)return;let r=!1;const i=null==t?void 0:t.map((e=>(e.checkError()&&(r=!0),e)));d(i)&&(r=!0),r?n(i):null===(a=e.commands)||void 0===a||a.execute(Rt.dagParameters,null==i?void 0:i.map((e=>({name:e.name,value:e.value,metadata:e.metadata})))),o(!1)})(...a),s.current=null}),300)}}(),[t,l]),m=(0,a.useCallback)((()=>{e.afterCancel()}),[]),h=(0,a.useCallback)((e=>{o(!0),n((t=>t.filter((t=>t.id!==e))))}),[]);return r().createElement(Ga,{id:"link-global-parameter"},r().createElement("div",{className:"title"},"Pipeline Parameters",r().createElement("div",{className:"hpo-button"},r().createElement(Kt,{title:"Hyper-Parameter Optimizer"},r().createElement(rl,{onClick:()=>{(async function(){var e;const t=null===(e=di.currentWidget)||void 0===e?void 0:e.kernel;if(!t)throw new Error("Kernel not found");const n=t.requestExecute({code:"%mrxlink_import_hpo_dependencies"});return new Promise(((e,t)=>{n.registerMessageHook((n=>{if("execute_result"===n.header.msg_type){const a=n.content.data["text/plain"];return"True"!==a&&"False"!==a?(t(new Error("Unexpected result when checking HPO installation")),!1):(e("True"===a),!1)}return"error"!==n.header.msg_type||(t(new Error("Error while executing kernel command to check HPO installation")),!1)}))}))})().then((e=>e?s(!0):void te((e=>r().createElement(r().Fragment,null,r().createElement("h1",null,le," Install Hyperparameter Optimization"),r().createElement("section",null,"To activate Hyperparameter Optimization (HPO), you need to install the package. The instructions for installing HPO can be found in the installation guide."),r().createElement("section",{className:"align-right"},r().createElement(sa,{path:"guide/ml-development/dev-instances/set-pipeline-parameters/",title:"View guide"})),r().createElement("menu",null,r().createElement("button",{onClick:e},"Close"))))))).catch((e=>u.error(`Failed to check if the package is installed. ${e.message||""}`)))}},ll,"HPO"))),i&&r().createElement($r,{close:()=>{s(!1)},commands:e.commands})),r().createElement("div",{className:"main"},r().createElement(qa,null,r().createElement("div",{className:"column-title"},"Name"),r().createElement("div",{className:"column-title"},"Value"),r().createElement("div",{className:"column-title"})),(!t||!t.length)&&r().createElement("div",{className:"pipeline-no-parameter"},"No Pipeline Parameters"),r().createElement("div",{className:"parameter-list"},null==t?void 0:t.map(((e,a)=>r().createElement(Jr,{parameter:e,setParameter:e=>n(null==t?void 0:t.map(((t,n)=>a===n?e:t))),deleteFunc:h,key:e.id,setIsEnableSave:o,index:a})))),r().createElement(al,null,y.value&&r().createElement("div",{className:"button",onClick:()=>(o(!0),void n((e=>e?(e.push(new tl("","","",{resource_type:"runway_dataset"})),e.map((e=>e))):[new tl("","","",{resource_type:"runway_dataset"})])))},r().createElement("span",{className:"icon"},ol),r().createElement("span",{className:"name"},"dataset")),r().createElement("div",{className:"button",onClick:()=>(o(!0),void n((e=>e?(e.push(new tl("","","")),e.map((e=>e))):[new tl("","","")])))},r().createElement("span",{className:"icon"},ol),r().createElement("span",{className:"name"},"parameter")))),r().createElement("div",{className:"button-container"},r().createElement("div",{onClick:m,className:"cancel-button-param"},"Close"),r().createElement("div",{onClick:p,className:"save-button-param",style:{opacity:l?1:.3,cursor:l?"pointer":"default"}},"Apply")))})),al=S().div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 8px;
  padding: 12px;

  .button {
    display: flex;
    justify-content: center;
    box-sizing: border-box;

    height: 32px;
    border-radius: 4px;
    padding: 11px 12px;

    font-weight: 500;
    font-size: 13px;
    text-align: center;
    align-items: center;

    transition: all 0.3s;
    cursor: pointer;

    background-color: var(--link-global-parameter-low-saturation-button-background);
    border: 1px solid var(--link-global-parameter-low-saturation-button-border-color);
    color: var(--link-global-parameter-low-saturation-button-text-color);

    &:hover {
      background-color: var(--link-global-parameter-low-saturation-button-hover-background);
    }

    .icon {
      margin-right: 8px;
      display: flex;
      align-items: center;
    }
  }
`,rl=S().button`
  height: 32px;
  padding: 3px 17px;
  margin-right: 16px;
  display: flex;
  align-items: center;
  background: var(--link-global-parameter-low-saturation-button-background);
  border: 1px solid var(--link-global-parameter-low-saturation-button-border-color);
  border-radius: 4px;
  color: var(--link-global-parameter-low-saturation-button-text-color);
  font-weight: 700;
  font-size: 11px;
  line-height: 13px;

  &:hover {
    background-color: var(--link-global-parameter-low-saturation-button-hover-background);
  }

  svg {
    margin-right: 4px;
  }
`,ll=r().createElement("svg",{width:"10",height:"11",viewBox:"0 0 10 11",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("rect",{y:"0.5",width:"9.01436",height:"1.25003",rx:"0.625017",fill:"#6C79F9"}),r().createElement("rect",{y:"3",width:"5.07058",height:"1.25003",rx:"0.625017",fill:"#6C79F9"}),r().createElement("rect",{y:"5.5",width:"3.38039",height:"1.25003",rx:"0.625017",fill:"#6C79F9"}),r().createElement("path",{d:"M9.86589 3.92151C9.85307 3.88421 9.83149 3.85091 9.80321 3.82479C9.77494 3.79868 9.74092 3.78062 9.70441 3.77236C9.66787 3.76387 9.62998 3.76573 9.59457 3.77776C9.55915 3.78979 9.52746 3.81155 9.50269 3.84086L8.44653 5.06952L7.61319 4.93821L7.39808 4.0752L8.46595 2.83308C8.49096 2.80407 8.50838 2.76857 8.51649 2.73004C8.52461 2.69152 8.52316 2.65129 8.51228 2.61329C8.50139 2.57529 8.48145 2.54082 8.4544 2.51324C8.42734 2.48566 8.3941 2.46592 8.35793 2.45594C8.14694 2.39461 7.92876 2.36786 7.71097 2.37662C6.52543 2.43966 5.62122 3.51626 5.69536 4.77652C5.70404 4.92417 5.72917 5.07278 5.77326 5.23551C5.54404 5.46 4.82696 6.29084 4.57896 6.51129C4.22437 6.82637 3.82261 7.18292 3.27804 7.72958C3.12166 7.88977 2.99977 8.08408 2.92056 8.29946C2.84134 8.51483 2.80664 8.7463 2.81877 8.97831C2.87066 9.86054 3.588 10.5423 4.41792 10.4982C4.63633 10.4858 4.84896 10.4228 5.0409 10.3136C5.23283 10.2044 5.39943 10.0516 5.529 9.86593C5.88171 9.37046 6.2178 8.8618 6.53667 8.34088C6.71084 8.06062 7.36274 7.17776 7.54192 6.91649C7.6989 6.94529 7.84096 6.95516 7.97986 6.94777C9.1654 6.88473 10.0696 5.80814 9.99547 4.54787C9.9809 4.33391 9.93725 4.12293 9.86589 3.92151ZM4.3507 9.3554C4.23665 9.36146 4.12444 9.31912 4.03876 9.23768C3.95307 9.15625 3.90093 9.04238 3.8938 8.92115C3.88667 8.79991 3.92513 8.68124 4.00073 8.59122C4.07633 8.50121 4.18288 8.44723 4.29692 8.44117C4.41097 8.43511 4.52318 8.47745 4.60886 8.55889C4.69455 8.64033 4.74669 8.75419 4.75382 8.87542C4.76095 8.99665 4.72249 9.11533 4.64689 9.20535C4.57129 9.29536 4.46474 9.34934 4.3507 9.3554Z",fill:"#927AF8"})),ol=r().createElement("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M5 8H11.0005",stroke:"var(--link-global-parameter-low-saturation-button-text-color)",strokeLinecap:"round"}),r().createElement("path",{d:"M8 5L8 11.0005",stroke:"var(--link-global-parameter-low-saturation-button-text-color)",strokeLinecap:"round"})),il=nl,sl=(0,_.x)((()=>{const{email:e,first_name:t,last_name:n}=w.value||{},[l,o]=(0,a.useState)(!1);return t?r().createElement(r().Fragment,null,r().createElement(dl,{id:"icon-profile",onClick:()=>o(!l)},null==t?void 0:t.charAt(0),null==n?void 0:n.charAt(0)),r().createElement(N.Popover,{anchorEl:l?document.querySelector("#icon-profile"):null,open:l,onClose:()=>o(!1),anchorOrigin:{vertical:"bottom",horizontal:"right"},transformOrigin:{vertical:"top",horizontal:"right"},sx:{top:"4px","& .MuiPopover-paper":{borderRadius:"20px"}}},r().createElement(pl,null,r().createElement("div",{className:"label"},"Account"),r().createElement("div",{className:"profile"},r().createElement(dl,null,null==t?void 0:t.charAt(0),null==n?void 0:n.charAt(0)),r().createElement("div",{className:"info"},r().createElement("div",{className:"name"},`${t} ${n}`),r().createElement("div",{className:"email"},e))),r().createElement("div",{className:"divider"}),r().createElement("button",{className:"logout-button",onClick:async function(){await E(),await k(),o(!1)}},r().createElement("div",{className:"icon"},r().createElement(cl,null)),r().createElement("div",{className:"label"},"Logout"))))):r().createElement(ml,{onClick:()=>Z.value=!1},"Login")})),cl=()=>r().createElement("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M8.29796 2.30005H2.60059V13.7H8.30059",stroke:"#70708F",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round"}),r().createElement("path",{d:"M10.3896 10.8501L13.2396 8.00015L10.3896 5.15015",stroke:"#70708F",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round"}),r().createElement("path",{d:"M5.76953 7.99658H12.6095",stroke:"#70708F",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round"})),dl=S().div`
  cursor: pointer;
  display: flex;
  width: 22px;
  height: 22px;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  flex-shrink: 0;

  border-radius: 50%;
  background: var(--key-color);
  color: var(--white);
  font-size: 10px;
  font-weight: 700;
`,pl=S().div`
  display: flex;
  box-sizing: border-box;
  width: 330px;
  padding: 12px 24px;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  gap: 8px;
  background: var(--background-surface);
  color: var(--text-primary);

  .label {
    color: var(--text-secondary);
    font-size: 11px;
    font-style: normal;
    font-weight: 500;
    line-height: 130%;
  }

  .profile {
    display: flex;
    align-items: center;
    gap: 8px;

    .info {
      display: flex;
      flex-direction: column;
      gap: 2px;

      .name {
        font-size: 14px;
        font-weight: 700;
        line-height: 130%;
      }

      .email {
        font-size: 12px;
        font-weight: 400;
        line-height: 130%;
        color: var(--text-secondary);
      }
    }
  }

  .divider {
    width: calc(100% + 48px);
    height: 1px;
    border-bottom: 1px solid var(--border-primary);

    margin-left: -24px;
    margin-top: 4px;
    margin-bottom: 4px;
  }

  .logout-button {
    background: none;
    border: none;
    padding: 0;

    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 0;
    cursor: pointer;

    .icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 16px;
      height: 16px;
    }

    .label {
      color: var(--text-secondary);
      font-size: 13px;
      font-weight: 500;
    }
  }
`,ml=S().button`
  width: 57px;
  height: 24px;
  border-radius: 4px;
  border: 1px solid var(--border-primary);
  background-color: var(--background-base);
  color: var(--text-primary);
  &:hover {
    background-color: var(--button-secondary-background-hover);
  }
`,ul=sl,hl='<svg class="link-remote-status" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">\n\t<path fill-rule="evenodd" clip-rule="evenodd" d="M1 3.5C1 2.94772 1.44772 2.5 2 2.5H16C16.5523 2.5 17 2.94772 17 3.5V7.09978C17 7.65206 16.5523 8.09978 16 8.09978H2C1.44772 8.09978 1 7.65206 1 7.09978V3.5ZM10 5.30048C10 4.78504 10.4179 4.36719 10.9333 4.36719H11.0667C11.5821 4.36719 12 4.78504 12 5.30048C12 5.81593 11.5821 6.23378 11.0667 6.23378H10.9333C10.4179 6.23378 10 5.81593 10 5.30048ZM13.4333 4.36719C12.9179 4.36719 12.5 4.78504 12.5 5.30048C12.5 5.81593 12.9179 6.23378 13.4333 6.23378H13.5667C14.0821 6.23378 14.5 5.81593 14.5 5.30048C14.5 4.78504 14.0821 4.36719 13.5667 4.36719H13.4333Z" fill="var(--link-panel-toolbar-icon)"/>\n\t<path fill-rule="evenodd" clip-rule="evenodd" d="M1 10.8984C1 10.3462 1.44772 9.89844 2 9.89844H16C16.5523 9.89844 17 10.3462 17 10.8984V14.4982C17 15.0505 16.5523 15.4982 16 15.4982H2C1.44772 15.4982 1 15.0505 1 14.4982V10.8984ZM10 12.6989C10 12.1835 10.4179 11.7656 10.9333 11.7656H11.0667C11.5821 11.7656 12 12.1835 12 12.6989C12 13.2144 11.5821 13.6322 11.0667 13.6322H10.9333C10.4179 13.6322 10 13.2144 10 12.6989ZM13.4333 11.7656C12.9179 11.7656 12.5 12.1835 12.5 12.6989C12.5 13.2144 12.9179 13.6322 13.4333 13.6322H13.5667C14.0821 13.6322 14.5 13.2144 14.5 12.6989C14.5 12.1835 14.0821 11.7656 13.5667 11.7656H13.4333Z" fill="var(--link-panel-toolbar-icon)"/>\n</svg>\n',gl=S().div`
  .upload-type {
    margin: 20px auto 0;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    justify-content: space-between;
  }

  .upload-type button {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100px;
    text-align: center;
    font-weight: 700;
    font-size: 15px;
    line-height: 18px;
    color: var(--text-primary);
    border: 1px solid var(--border-primary);
    background: transparent;
    border-radius: 5px;
  }
  .upload-type button:hover {
    background-color: #eeeffa;
  }
  body[data-theme='dark'] & .upload-type button:hover {
    background-color: #25253d;
  }

  .upload-type button svg {
    vertical-align: middle;
    margin: -4px 0 0 4px;
  }
`,vl=r().createElement("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("circle",{cx:"10",cy:"10",r:"10",fill:"#6C79F9"}),r().createElement("path",{d:"M6.5 6V14.8806H8.32836V8.93532H8.35323L12.0473 14.8806H14V6H12.1716V11.9577H12.1468L8.4403 6H6.5Z",fill:"white"})),fl=r().createElement("svg",{width:"21",height:"20",viewBox:"0 0 21 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("ellipse",{cx:"10.4177",cy:"10",rx:"9.91768",ry:"10",fill:"#6C79F9"}),r().createElement("path",{d:"M12.3281 15L8.57142 15L8.57142 9.94949L5.54102 9.94949L10.4498 5L15.3585 9.94949L12.3281 9.94949L12.3281 15Z",fill:"white"})),xl=({updateStep:e,closeDialog:t})=>r().createElement(r().Fragment,null,r().createElement("section",null,r().createElement(gl,null,"Please choose a type to upload the pipeline.",r().createElement("div",{className:"upload-type"},r().createElement("button",{onClick:()=>e(Zl.UPLOAD_PIPELINE)},"New Pipeline ",vl),r().createElement("button",{onClick:()=>e(Zl.UPLOAD_VERSION)},"Version Update ",fl)))),r().createElement("menu",null,r().createElement("button",{onClick:t},"Close")));function bl(e,t,n){return 0===e.length?{isValid:!1,message:""}:t.test(e)?n&&n.includes(e)?{isValid:!1,message:"Name already exists."}:{isValid:!0,message:""}:{isValid:!1,message:t.message}}const Cl={test:e=>/^[a-zA-Z0-9-]{1,30}$/g.test(e),message:"Use 1-30 characters, including alphabets, numbers, and the hyphen(-)."},El={test:e=>/^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,28}[a-zA-Z0-9])?$/g.test(e),message:"Use 1-30 characters, including alphabets, numbers, and the hyphen(-). It must start and end with an alphanumeric character."};var wl;!function(e){e.NotSubmitted="before_submit_button_clicked",e.Loading="loading",e.Succeed="succeed",e.Failed="failed",e.Test="test"}(wl||(wl={}));const yl=()=>r().createElement(kl,null,r().createElement("div",null,Ie),r().createElement("div",null,"Uploading ...")),kl=S().div`
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
`,Ll=S().form`
  .help-icon {
    display: inline-block;
    width: 16px;
    height: 16px;
    line-height: 16px;
    border-radius: 50%;
    text-align: center;
    margin-left: 4px;
    background-color: var(--background-surface);
    color: var(--text-secondary);
  }
  .dependency-editor {
    height: 200px;
    padding: 12px;
    margin: 8px 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
    border-color: 1px solid var(--border-primary);
    background-color: var(--background-surface);
    overflow-y: auto;
    .dependency-editor-header {
      height: 20px;
      line-height: 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      .dependency-editor-title {
        font-size: 13px;
        font-weight: 400;
      }
    }
    .dependency-list-no-item {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    ul.dependency-list {
      margin: 0;
      padding: 0;
      list-style-type: none;
      display: flex;
      flex-direction: column;
      gap: 4px;
      li.dependency-item {
        display: flex;
        flex-direction: column;
        gap: 4px;
        .dependency-item-title {
          font-size: 11px;
          font-weight: 500;
        }
        .dependency-item-content {
          list-style: none;
          display: flex;
          align-items: center;
          gap: 10px;
          .dependency-item-input {
            flex: 1;
          }
        }
        .dependency-item-error-message {
          color: var(--errorRedColor);
          font-size: 10px;
          display: flex;
          align-items: center;
          gap: 4px;
        }
      }
    }
    button {
      /* delete default styles */
      background: none;
      color: inherit;
      border: none;
      padding: 0;
      font: inherit;
      outline: inherit;
      /* define custom styles */
      width: 20px;
      height: 20px;
      border-radius: 50%;
      /* center text (or icon) */
      display: flex;
      align-items: center;
      justify-content: center;
      &.dependency-item-add-button {
        background-color: var(--link-color);
      }
      &.dependency-item-remove-button {
        background-color: var(--box-background);
      }
    }
  }
  .below-description-list {
    /* delete default styles */
    margin: 0;
    padding: 0;
    list-style-type: none;
    .below-description-list-item {
      /* delete default style */
      margin: 0;
      padding: 0;
      /* custom styles */
      color: var(--text-secondary);
      font-size: 11px;
      font-weight: 400;
    }
  }
  .submit-result-message {
    color: var(--text-secondary);
  }
  .submit-error-message {
    padding: 10px;
    background-color: var(--background-surface);
    border: 1px solid var(--border-primary);
    border-radius: 5px;
    color: var(--text-secondary);
  }
`,_l=r().createElement("svg",{width:"8",height:"8",viewBox:"0 0 8 8",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M3.20039 0.8C3.20039 0.358172 3.55856 0 4.00039 0C4.44221 0 4.80039 0.358172 4.80039 0.8V7.2C4.80039 7.64183 4.44221 8 4.00039 8C3.55856 8 3.20039 7.64183 3.20039 7.2V0.8Z",fill:"white"}),r().createElement("path",{d:"M7.2 3.2C7.64183 3.2 8 3.55817 8 4C8 4.44183 7.64183 4.8 7.2 4.8L0.8 4.8C0.358172 4.8 -1.93129e-08 4.44183 0 4C1.93129e-08 3.55817 0.358172 3.2 0.8 3.2L7.2 3.2Z",fill:"white"})),Ml=r().createElement("svg",{width:"8",height:"8",viewBox:"0 0 8 2",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("line",{x1:"1",y1:"1",x2:"7",y2:"1",stroke:"white",strokeWidth:"2",strokeLinecap:"round"})),Sl=r().createElement("svg",{width:"15",height:"13",viewBox:"0 0 15 13",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M14.2931 10.7497L8.79934 1.24972C8.66782 1.02123 8.4784 0.831453 8.25017 0.699491C8.02194 0.567528 7.76297 0.498047 7.49934 0.498047C7.23571 0.498047 6.97673 0.567528 6.7485 0.699491C6.52028 0.831453 6.33086 1.02123 6.19934 1.24972L0.705589 10.7497C0.572131 10.977 0.501206 11.2356 0.500015 11.4992C0.498824 11.7628 0.567411 12.022 0.698809 12.2506C0.830207 12.4791 1.01974 12.6688 1.24815 12.8003C1.47657 12.9319 1.73574 13.0007 1.99934 12.9997H12.9993C13.2629 13.0007 13.5221 12.9319 13.7505 12.8003C13.9789 12.6688 14.1685 12.4791 14.2999 12.2506C14.4313 12.022 14.4999 11.7628 14.4987 11.4992C14.4975 11.2356 14.4265 10.977 14.2931 10.7497ZM6.99934 5.49972C6.99934 5.36711 7.05202 5.23993 7.14578 5.14616C7.23955 5.05239 7.36673 4.99972 7.49934 4.99972C7.63195 4.99972 7.75912 5.05239 7.85289 5.14616C7.94666 5.23993 7.99934 5.36711 7.99934 5.49972V7.99972C7.99934 8.13232 7.94666 8.2595 7.85289 8.35327C7.75912 8.44704 7.63195 8.49972 7.49934 8.49972C7.36673 8.49972 7.23955 8.44704 7.14578 8.35327C7.05202 8.2595 6.99934 8.13232 6.99934 7.99972V5.49972ZM7.49934 10.9997C7.351 10.9997 7.206 10.9557 7.08266 10.8733C6.95932 10.7909 6.86319 10.6738 6.80643 10.5367C6.74966 10.3997 6.73481 10.2489 6.76375 10.1034C6.79269 9.95791 6.86412 9.82428 6.96901 9.71939C7.0739 9.6145 7.20753 9.54307 7.35302 9.51413C7.49851 9.48519 7.64931 9.50004 7.78635 9.55681C7.92339 9.61357 8.04053 9.7097 8.12294 9.83304C8.20535 9.95638 8.24934 10.1014 8.24934 10.2497C8.24934 10.4486 8.17032 10.6394 8.02967 10.78C7.88902 10.9207 7.69825 10.9997 7.49934 10.9997Z",fill:"#DBA948"})),Nl=({dialogDescription:e,dependencyHelperText:t,pipelineVersionDesc:n,dependencyPaths:l,isValid:o,customInputComponent:c,pipelineVersion:p,notebookTracker:m,onSubmit:u,onPipelineVersionDescChange:h,setDependencyPaths:g,closeDialog:v})=>{const[f,x]=(0,a.useState)(""),[b,C]=(0,a.useState)(wl.NotSubmitted),[E,w]=(0,a.useState)(),[y,k]=(0,a.useState)([]);const L=async e=>{if(e.preventDefault(),await async function(){const e=await Promise.all(l.map(((e,t)=>async function(e,t,n){if(""===e)return"Required";if(t.slice(0,n).includes(e))return"This path has already been registered.";const a=e.split("/"),r=a.length>0?a[1]:"",l=a.length>1?a[2]:"",o=a.length>2?a[3]:"",i=a.length>3?a[4]:"";if("home"===r&&"jovyan"===l&&"workspace"===o&&("dataset"===i||"shared"===i))return"This folder is included by default.";const c=await async function(e){try{const t=new URLSearchParams({path:e}),n=`${s.PageConfig.getBaseUrl()}mrx-link/runway/path_check?${t.toString()}`,a=await fetch(n,{method:"GET"});return!0===(await a.json()).is_exist}catch(e){return!1}}(e);return c?"":"This folder doesn't exist."}(e,l,t))));return k(e),e.every((e=>""===e))}()){w(null),C(wl.Loading);try{const e=await(async()=>{var e,t,n;const a=null===(e=m.currentWidget.content.activeCell)||void 0===e?void 0:e.model.getMetadata("canvas"),r=ue(m,!0),l=null===(n=null===(t=m.currentWidget)||void 0===t?void 0:t.sessionContext.session)||void 0===n?void 0:n.kernel;if(!l||!r)return;const o=await(async e=>{var t;const n=i.ServerConnection.makeSettings(),a=new URLSearchParams;a.append("kernel_id",e.kernel_id),a.append("ipynb_name",e.ipynb_name),null===(t=e.cell_id)||void 0===t||t.forEach((e=>a.append("cell_id",e)));const r=`${n.baseUrl}mrx-link/link-pipeline/export?${a.toString()}`;return d().get(r,{responseType:"blob"}).catch((e=>e.response&&e.response.data?new Promise(((t,n)=>{const a=new FileReader;a.onload=function(){const e=JSON.parse(a.result);n(e)},a.readAsText(e.response.data)})):Promise.reject(e)))})({cell_id:[a.id],ipynb_name:r||"",kernel_id:l.id});return o?o.data:void 0})();if(!e)return void C(wl.Failed);if(void 0===await u(e))return void C(wl.Failed);C(wl.Succeed)}catch(e){"string"==typeof e.message&&w(e.message),C(wl.Failed)}}};return(0,a.useEffect)((()=>{Gn().then((e=>{x((null==e?void 0:e.title)||"")})).catch((()=>{x("")}))}),[]),(0,a.useEffect)((()=>{const e=y.findIndex((e=>""!==e));if(-1!==e){const t=document.getElementsByClassName("dependency-item-input")[e];if(!t)return;t.scrollIntoView({behavior:"smooth"}),t.focus()}}),[y]),r().createElement(r().Fragment,null,r().createElement("section",null,r().createElement(Ll,{onSubmit:L},b===wl.Loading&&r().createElement(yl,null),b===wl.Succeed&&r().createElement("div",{className:"submit-result-message"},"Successfully uploaded."),b===wl.Failed&&r().createElement(r().Fragment,null,r().createElement("div",{className:"submit-result-message"},"An error occurred while uploading. Please try again later."),E&&r().createElement("div",{className:"submit-error-message"},E)),b===wl.NotSubmitted&&r().createElement(r().Fragment,null,e,r().createElement(pn,null,r().createElement(N.InputLabel,null,"Project"),r().createElement("div",{className:"value"},Oe," ",f)),r().createElement(pn,null,c),r().createElement(pn,null,r().createElement(N.TextField,{label:"Pipeline version",value:p,disabled:!0,required:!1,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},inputProps:{maxLength:100}})),r().createElement(pn,null,r().createElement(sn,{valueLength:n.length,maxLength:100},r().createElement(N.TextField,{label:"Version Description (optional)",value:n,onChange:e=>{e.target.value.length<=100&&h(e)},required:!1,size:"small",fullWidth:!0,multiline:!0,rows:3,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},inputProps:{maxLength:100}}))),r().createElement(pn,null,r().createElement(N.InputLabel,null,"Including directory",r().createElement(Kt,{title:t},r().createElement("div",{className:"help-icon"},"?"))),r().createElement("div",{className:"dependency-editor"},r().createElement("div",{className:"dependency-editor-header"},r().createElement("div",{className:"dependency-editor-title"},"Directory"),r().createElement("button",{type:"button",className:"dependency-item-add-button",onClick:()=>{g([...l,""]),k([...y,""])}},_l)),0===l.length?r().createElement("div",{className:"dependency-list-no-item"},r().createElement("div",{className:"icon"},Sl),r().createElement("div",{className:"text"},"No Items")):r().createElement("ul",{className:"dependency-list"},l.map(((e,t)=>{var n;return r().createElement("li",{className:"dependency-item",key:t},r().createElement("div",{className:"dependency-item-title"},"Path"),r().createElement("div",{className:"dependency-item-content"},r().createElement(N.TextField,{className:"dependency-item-input",value:e,onChange:e=>((e,t)=>{const n=[...l];n[e]=t;const a=[...y];a[e]="",g(n),k(a)})(t,e.target.value)}),r().createElement("button",{type:"button",className:"dependency-item-remove-button",onClick:()=>(e=>{const t=[...l];t.splice(e,1);const n=[...y];n.splice(e,1),g(t),k(n)})(t)},Ml)),(null===(n=y[t])||void 0===n?void 0:n.length)>0&&r().createElement("div",{className:"dependency-item-error-message"},ze(Fe,11,10),r().createElement("div",{className:"text"},y[t])))})))),r().createElement("ul",{className:"below-description-list"},r().createElement("li",{className:"below-description-list-item"},"･ Dataset and shared folders are included by default")))))),r().createElement("menu",null,b!==wl.Loading&&r().createElement("button",{type:"button",onClick:v},"Close"),b===wl.NotSubmitted&&r().createElement("button",{onClick:L,className:"primary",disabled:!o},"Upload")))},Al=({tracker:e,existingRunwayPipelines:t,gitParamForUploadPipeline:n,closeDialog:l})=>{const[o,i]=(0,a.useState)(""),[s,c]=(0,a.useState)(""),[d,p]=(0,a.useState)([]),[m,u]=(0,a.useState)(""),h=(0,a.useMemo)((()=>o.length>0&&0===m.length),[o,m]);return(0,a.useEffect)((()=>{var e;null===(e=async function(){var e;const t=null===(e=di.currentWidget)||void 0===e?void 0:e.kernel;if(!t)return[];const n=t.requestExecute({code:"%mrxlink_get_python_path -r"});return new Promise(((e,t)=>{try{n.registerMessageHook((t=>{if("execute_result"===t.header.msg_type){const n=t.content.data["text/plain"],a=n.slice(1,n.length-1).split(",").map((e=>e.trim())).map((e=>e.slice(1,e.length-1))).filter((e=>e.length>0));e(a)}return!1}))}catch(t){return console.error("PYTHONPATH 목록을 가져오는데 실패했습니다.",t),e([])}}))}())||void 0===e||e.then((e=>p(e)))}),[]),(0,a.useEffect)((()=>{const e=t.map((e=>e.name)),{message:n}=bl(o,El,e);u(n)}),[o]),r().createElement(Nl,{notebookTracker:e,dialogDescription:"Upload as a new pipeline.",dependencyHelperText:"‘PYTHONPATH’ is added automatically. You can also add or delete manually.",pipelineVersion:"v.1",pipelineVersionDesc:s,dependencyPaths:d,isValid:h,onPipelineVersionDescChange:e=>c(e.target.value),setDependencyPaths:p,onSubmit:async e=>{const t=await async function(e){const t=await L.getRunwayInfo(),n=new FormData;n.append("link_pipeline_json",e.data,"pipeline.json"),n.append("user_id",t.env.USER_ID),n.append("name",e.name),n.append("link_notebook_name",t.env.LINK_INSTANCE_NAME),e.description&&n.append("description",e.description),e.dependencyPaths&&e.dependencyPaths.length>0&&e.dependencyPaths.forEach((e=>n.append("dependency_paths",e))),e.gitParam&&(n.append("git_remote_url",e.gitParam.git_remote_url),n.append("git_commit_id",e.gitParam.git_commit_id),n.append("git_main_file_path",e.gitParam.git_main_file_path));const a=`${$n(t)}/link/workspaces/${t.env.WORKSPACE_ID}/projects/${t.env.PROJECT_ID}/pipelines`;return fetch(a,{method:"POST",headers:{Authorization:`Bearer ${t.env.JWT_TOKEN}`},body:n}).then((e=>{if(e.ok)return e.json()}))}({data:e,name:o,description:s,dependencyPaths:d,gitParam:n});return null==t?void 0:t.pipeline},closeDialog:l,customInputComponent:r().createElement(sn,{valueLength:o.length,maxLength:30,errorMessage:m},r().createElement(N.TextField,{label:"Pipeline",value:o,onChange:e=>i(e.target.value),placeholder:"Enter the pipeline name",required:!0,error:m.length>0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",autoFocus:!0,InputLabelProps:{shrink:!0},inputProps:{maxLength:30}}))})},Il=S().li`
  padding: 6px 12px;
  display: flex;
  align-items: center;
  gap: 4px;

  .favorite-icon {
    width: 15px;
  }

  .name {
    flex: 1;
  }
`,Ol=({tracker:e,existingRunwayPipelines:t,gitParamForUploadPipeline:n,closeDialog:l})=>{const[o,i]=(0,a.useState)(""),[s,c]=(0,a.useState)(null),[d,p]=(0,a.useState)([]),m=(0,a.useMemo)((()=>null!==s),[s]),u=(0,a.useMemo)((()=>null===s||"number"!=typeof s.next_version&&"string"!=typeof s.next_version?"-":`v.${s.next_version}`),[s]);return(0,a.useEffect)((()=>{var e;if(!s||!s.versions||0===s.versions.length)return void p([]);const t=s.versions[s.versions.length-1];p((null===(e=t.image_snapshot)||void 0===e?void 0:e.dependency_paths)||[])}),[s]),r().createElement(Nl,{notebookTracker:e,dialogDescription:"Upload as an existing pipeline's new version.",dependencyHelperText:"The directories in the last version of the selected pipeline are added automatically. You can also add or delete manually.",pipelineVersion:u,pipelineVersionDesc:o,dependencyPaths:d,isValid:m,onPipelineVersionDescChange:e=>i(e.target.value),setDependencyPaths:p,onSubmit:async e=>{if(!s)return void console.error("selectedPipeline is null");const t=await async function(e){const t=await L.getRunwayInfo(),n=new FormData;n.append("link_pipeline_json",e.data,"pipeline.json"),n.append("link_notebook_name",t.env.LINK_INSTANCE_NAME),e.description&&n.append("description",e.description),e.dependencyPaths&&e.dependencyPaths.length>0&&e.dependencyPaths.forEach((e=>n.append("dependency_paths",e))),e.gitParam&&(n.append("git_remote_url",e.gitParam.git_remote_url),n.append("git_commit_id",e.gitParam.git_commit_id),n.append("git_main_file_path",e.gitParam.git_main_file_path));const a=`${$n(t)}/link/workspaces/${t.env.WORKSPACE_ID}/projects/${t.env.PROJECT_ID}/pipelines/${e.pipelineId}/versions`;return fetch(a,{method:"POST",headers:{Authorization:`Bearer ${t.env.JWT_TOKEN}`},body:n}).then((e=>{if(e.ok)return e.json()}))}({data:e,pipelineId:s.id,description:o,dependencyPaths:d,gitParam:n});return null==t?void 0:t.version},closeDialog:l,customInputComponent:r().createElement(N.Autocomplete,{size:"small",onChange:(e,t)=>c(t),options:t,getOptionLabel:e=>e?e.name:"",isOptionEqualToValue:(e,t)=>e.id===t.id,PaperComponent:dn,value:s,noOptionsText:"No results",renderInput:e=>r().createElement(N.TextField,Object.assign({},e,{label:"Pipeline",placeholder:"Search or select the pipeline name to update the version",required:!0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0}})),renderOption:(e,t)=>r().createElement(Il,Object.assign({},e),r().createElement("span",{className:"favorite-icon"},t.favorited&&Te),r().createElement("span",{className:"name"},t.name))})})},Pl=`${s.PageConfig.getBaseUrl()}link-git`,Tl={"Cache-Control":"no-cache, no-store, must-revalidate, max-age=0"};var Fl;function Vl(e,t,n,a){return e.slice(t,n+1).join(a)}function Hl(e){var t,n;return(null===(n=null===(t=e.currentWidget)||void 0===t?void 0:t.sessionContext.session)||void 0===n?void 0:n.path)||""}!function(e){e.LOADING="loading",e.NO_GIT_INFO="no_git_info",e.PUSHED="pushed",e.NOT_PUSHED="not_pushed",e.UPLOAD_ANYWAY="upload_anyway"}(Fl||(Fl={}));const Rl=({closeDialog:e})=>r().createElement(se,{open:!0,onClose:e},r().createElement("h1",null,ie," Loading to git status"),r().createElement("section",{style:{display:"flex",justifyContent:"center",alignItems:"center",height:"100px"}},Ie)),zl=({closeDialog:e,updateGitPushStatus:t})=>r().createElement(se,{open:!0,onClose:e},r().createElement("h1",null,oe," Warning:Unpushed git commits"),r().createElement("section",null,"There are changes in the local repository that have not yet been committed or pushed to the remote repository. These changes may not be included in the upload. Do you want to continue uploading?",r().createElement("div",{className:"note"},"Even if there are no modifications, changes in Git status can occur due to metadata alterations caused by pipeline execution. it is a standard procedure, so you can proceed with the upload.")),r().createElement("menu",null,r().createElement("button",{onClick:e},"Cancel"),r().createElement("button",{className:"primary",onClick:()=>t(Fl.UPLOAD_ANYWAY)},"Upload anyway")));var Zl;!function(e){e.SELECT_NEXT_STEP="select-next-step",e.UPLOAD_PIPELINE="upload-pipeline",e.UPLOAD_VERSION="upload-version"}(Zl||(Zl={}));const Bl=({closeDialog:e,tracker:t})=>{const[n,l]=(0,a.useState)(Zl.SELECT_NEXT_STEP),[o,i]=(0,a.useState)([]),[s,c]=(0,a.useState)(null),[d,p]=(0,a.useState)(Fl.LOADING),m=(0,a.useMemo)((()=>function({tracker:e,gitPushStatus:t,gitInfo:n}){var a,r;if(t!==Fl.PUSHED)return;if(!(n&&n.git_top_level&&n.remote_url&&n.last_commit_id))return;const l=n.git_top_level;let o=function(e,t){if(!t||""===t)return e;const n=t.split("/");if(1===n.length)return e;for(let t=0;t<n.length;t++){const a=Vl(n,t,n.length-1,"/");if(e.includes(a)){const a=Vl(n,t,n.length-1,"/");return e.replace(a,"")}}return e}((null===(r=null===(a=e.currentWidget)||void 0===a?void 0:a.sessionContext.session)||void 0===r?void 0:r.path)||"",l);return"/"===o[0]&&(o=o.slice(1)),{git_remote_url:n.remote_url,git_commit_id:n.last_commit_id,git_main_file_path:o}}({tracker:t,gitPushStatus:d,gitInfo:s})),[t,d,s]);return(0,a.useEffect)((()=>{(async function(e){try{const t=Hl(e),n=await async function(e){const t=new URLSearchParams({file_path:e}).toString();return fetch(`${Pl}/check_push?${t}`,{method:"GET",headers:Tl}).then((e=>e.json()))}(t);return!0===n.is_pushed?Fl.PUSHED:!1===n.is_pushed?Fl.NOT_PUSHED:Fl.NO_GIT_INFO}catch(e){return Fl.NO_GIT_INFO}})(t).then((e=>p(e))),async function(e){try{const t=function(e){const t=Hl(e);if(!t||""===t)return"";const n=t.split("/");return n.pop(),n.join("/")}(e);return await async function(e){return fetch(`${Pl}/${e}/info`,{method:"GET",headers:Tl}).then((e=>e.json()))}(t)}catch(e){return null}}(t).then((e=>c(e))),async function(){const e=await async function(){const e=await L.getRunwayInfo(),t=`${$n(e)}/link/workspaces/${e.env.WORKSPACE_ID}/projects/${e.env.PROJECT_ID}/pipelines`;return fetch(t,{method:"GET",headers:{Authorization:`Bearer ${e.env.JWT_TOKEN}`}}).then((e=>e.json())).then((e=>e.pipelines))}();if(!e)return;const t=null==e?void 0:e.sort(((e,t)=>e.favorited&&!t.favorited?-1:!e.favorited&&t.favorited?1:t.created_at-e.created_at));i(t)}()}),[]),d===Fl.LOADING?r().createElement(Rl,{closeDialog:e}):d===Fl.NOT_PUSHED?r().createElement(zl,{closeDialog:e,updateGitPushStatus:p}):r().createElement(se,{open:!0,onClose:e},r().createElement("h1",null,ie,"Upload pipeline"),n===Zl.SELECT_NEXT_STEP&&r().createElement(xl,{updateStep:l,closeDialog:e}),n===Zl.UPLOAD_PIPELINE&&r().createElement(Al,{tracker:t,existingRunwayPipelines:o,gitParamForUploadPipeline:m,closeDialog:e}),n===Zl.UPLOAD_VERSION&&r().createElement(Ol,{tracker:t,existingRunwayPipelines:o,gitParamForUploadPipeline:m,closeDialog:e}))},jl=(Dl=({lab:e,title:t,showHeader:n,onRunAll:l,toggleSetting:o,onToggleHeaderColor:i,closeHeaderColorSubPanel:s,isRunning:c,isExistComponent:d,panelWidth:p,onToggleRemote:m,isSettingPanelOpened:u,setIsSettingPanelOpened:h,isParameterOpen:g,toggleParameter:v,paramCount:f,tracker:x})=>{var b,C;const E=(0,a.useRef)(null),[w,k]=(0,a.useState)(!1),[_,M]=(0,a.useState)(!1),[S,N]=(0,a.useState)(!1),[A,I]=(0,a.useState)(!1),O=pe.getKernelComponents(null===(C=null===(b=null==di?void 0:di.currentWidget)||void 0===b?void 0:b.kernel)||void 0===C?void 0:C.id),P=(0,a.useCallback)(r().forwardRef(((e,t)=>{const{id:n,svg:a,title:l,onClick:o,style:i,disabled:s}=e;return r().createElement(Kt,{title:l,describeChild:!0,placement:"bottom-start"},r().createElement("span",null,r().createElement(Ua,{id:n,onClick:o,style:i,disabled:s,ref:t},r().createElement(Se,{svg:a}))))})),[]),T=()=>y.value?p>420:p>300;return(0,a.useEffect)((()=>{const e=(e,t)=>{N((e=>{if(!e)return!1;const t=e.model.getMetadata("canvas");return!!t&&!0===t.isComponent})(t))};return x.activeCellChanged.connect(e),()=>{x.activeCellChanged.disconnect(e)}}),[]),(0,a.useEffect)((()=>{I(S)}),[S]),(0,a.useEffect)((()=>{A||s()}),[A]),(0,a.useEffect)((()=>{function e(e){var t;const n=e.target,a=document.querySelector("#link-setting-panel");!u||(null===(t=E.current)||void 0===t?void 0:t.contains(n))||(null==a?void 0:a.contains(n))||h(!1)}const t=document.body;return t.addEventListener("mousedown",e,!0),()=>{t.removeEventListener("mousedown",e,!0)}}),[u]),(0,a.useEffect)((()=>{const e=document.querySelector("#canvas-pipeline-extension"),t=document.querySelector("#link-setting-panel");if(!e||!t||!u)return;const n=Number(window.getComputedStyle(t).getPropertyValue("left").replace("px",""));e.offsetWidth<t.offsetWidth+n+4?t.classList.add("narrow"):t.classList.remove("narrow")}),[u]),(0,a.useEffect)((()=>{!async function(){const e=await L.getIsRunway();k(e)}()}),[]),r().createElement("header",{className:"pipeline-panel-header"+(T()?" show-parameter-text":"")},r().createElement("div",{className:"pipeline-panel-align"},r().createElement("div",{className:"pipeline-panel-title"},t),!w&&r().createElement(ul,null)),r().createElement("div",{className:"pipeline-panel-align"},n&&r().createElement(r().Fragment,null,r().createElement("div",{className:"pipeline-panel-toolbar"},r().createElement(P,{svg:'<?xml version="1.0" encoding="utf-8"?>\n<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="20" height="20" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20;position:relative;top:1px;left:2px" xml:space="preserve">\n<g>\n\t<path class="st0" d="M3,3.5c0-0.4,0.4-0.6,0.7-0.4l7.8,4.5c0.3,0.2,0.3,0.7,0,0.9L3.7,13c-0.3,0.2-0.7,0-0.7-0.4V3.5z" fill="var(--link-panel-toolbar-icon)"/>\n\t<path class="st0" d="M12.1,16h-1.8L10,17H8.9l1.9-5h1l1.9,5h-1.1L12.1,16z M10.6,15.1h1.3l-0.6-1.9L10.6,15.1z M15,17h-1v-5.3h1V17 z M16.9,17h-1v-5.3h1V17z" fill="var(--link-panel-toolbar-icon)"/>\n</g>\n</svg>\n',title:"Run All Components",onClick:l,disabled:!d||c}),r().createElement(P,{id:"toggle-header-color-panel",svg:La,title:"Select Header Color",style:{fill:"#565656"},onClick:i,disabled:!A}),r().createElement(P,{svg:'<svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M5.59961 13.293L6.07505 13.3815L7.08202 13.5689L14.0649 14.8679L15.0718 15.0552L15.5473 15.1436L5.59961 13.293ZM7.7306 12.0123L11.4246 12.6995L11.6396 11.5435L11.6895 11.2752C11.7486 10.9576 12.0539 10.7481 12.3715 10.8072C12.689 10.8662 12.8986 11.1715 12.8396 11.4891L12.6624 12.4415L12.5746 12.9134L13.368 13.061L14.0194 13.1822L14.2203 10.0138L8.73541 8.99354L8.68259 8.98372L7.7306 12.0123ZM15.4522 9.53114L15.1303 14.6084L7.16432 13.1265L6.1812 12.9435L6.48103 11.9895L7.70663 8.09026C8.01182 7.11942 8.99383 6.52925 9.99429 6.71539L11.1964 6.93901L12.0955 2.10574C12.1704 1.70329 12.5573 1.43777 12.9597 1.51263C13.3621 1.5875 13.6276 1.97443 13.5528 2.37686L12.6537 7.21012L13.8121 7.42562C14.8125 7.61172 15.5166 8.51553 15.4522 9.53114Z" fill="var(--link-panel-toolbar-icon)"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M9.71316 1.62134V2.59072C9.71316 3.445 7.66556 4.14174 5.14174 4.14174C2.61792 4.14174 0.570312 3.445 0.570312 2.59072V1.62134C0.570312 0.767055 2.61792 0.0703125 5.14174 0.0703125C7.66556 0.0703125 9.71316 0.767055 9.71316 1.62134ZM7.26641 7.35673C7.7596 6.48434 8.70339 5.949 9.71316 5.9819V3.80246C8.73099 4.50527 6.93339 4.83244 5.14174 4.83244C3.35007 4.83244 1.55245 4.50527 0.570312 3.80246V5.98357C0.570312 6.83786 2.61792 7.5346 5.14174 7.5346C5.90863 7.5346 6.63155 7.47027 7.26641 7.35673ZM6.9685 8.10593C6.38151 8.18617 5.76127 8.22528 5.14174 8.22528C3.35007 8.22528 1.55245 7.89814 0.570312 7.19534V9.37643C0.570312 10.2307 2.61792 10.9275 5.14174 10.9275C5.46765 10.9275 5.78562 10.9158 6.09227 10.8938L6.9685 8.10593Z" fill="var(--link-panel-toolbar-icon)"/>\n</svg>\n',title:"Clear All Caches",style:{marginTop:"5px"},onClick:()=>{e.commands.execute(Rt.clearAllCache)},disabled:!d||(F=O,!(null!==F&&Object.values(F).some((e=>"cached"===e.diskcache_status))))||(e=>null!==e&&Object.values(e).some((e=>"running"===e.execution_status)))(O)}),r().createElement(P,{svg:hl,title:"Remote Resources",onClick:m}),r().createElement(P,{svg:'<svg width="16" height="16" viewBox="0 0 26 28" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M15.4266 27.3332H10.5733C10.2692 27.3332 9.9742 27.2293 9.73726 27.0387C9.50033 26.8481 9.33567 26.5822 9.27059 26.2852L8.72793 23.7732C8.004 23.456 7.31757 23.0593 6.68126 22.5905L4.23193 23.3705C3.94201 23.463 3.62919 23.4535 3.34542 23.3436C3.06165 23.2337 2.824 23.0301 2.67193 22.7665L0.239927 18.5652C0.0894543 18.3013 0.0329705 17.9943 0.079717 17.6942C0.126463 17.3941 0.273672 17.1187 0.49726 16.9132L2.39726 15.1798C2.31086 14.3947 2.31086 13.6024 2.39726 12.8172L0.49726 11.0878C0.273356 10.8822 0.125947 10.6066 0.0791925 10.3062C0.0324383 10.0058 0.0891129 9.69846 0.239927 9.4345L2.66659 5.2305C2.81866 4.96692 3.05631 4.76329 3.34009 4.65342C3.62386 4.54355 3.93668 4.53405 4.22659 4.6265L6.67593 5.4065C7.00126 5.1665 7.33993 4.9425 7.68926 4.73984C8.02659 4.5505 8.37326 4.3785 8.72793 4.22517L9.27193 1.71584C9.33669 1.41877 9.50104 1.15275 9.73772 0.961902C9.97441 0.77105 10.2692 0.666824 10.5733 0.666504H15.4266C15.7306 0.666824 16.0254 0.77105 16.2621 0.961902C16.4988 1.15275 16.6632 1.41877 16.7279 1.71584L17.2773 4.2265C18.0003 4.54553 18.6865 4.94207 19.3239 5.40917L21.7746 4.62917C22.0643 4.53706 22.3768 4.54673 22.6603 4.65659C22.9438 4.76644 23.1812 4.96988 23.3333 5.23317L25.7599 9.43717C26.0693 9.97984 25.9626 10.6665 25.5026 11.0892L23.6026 12.8225C23.689 13.6077 23.689 14.4 23.6026 15.1852L25.5026 16.9185C25.9626 17.3425 26.0693 18.0278 25.7599 18.5705L23.3333 22.7745C23.1812 23.0381 22.9435 23.2417 22.6598 23.3516C22.376 23.4615 22.0632 23.471 21.7733 23.3785L19.3239 22.5985C18.6881 23.067 18.0021 23.4632 17.2786 23.7798L16.7279 26.2852C16.6629 26.582 16.4984 26.8477 16.2618 27.0383C16.0251 27.2289 15.7305 27.3329 15.4266 27.3332ZM12.9946 8.6665C11.5801 8.6665 10.2236 9.22841 9.22336 10.2286C8.22316 11.2288 7.66126 12.5854 7.66126 13.9998C7.66126 15.4143 8.22316 16.7709 9.22336 17.7711C10.2236 18.7713 11.5801 19.3332 12.9946 19.3332C14.4091 19.3332 15.7656 18.7713 16.7658 17.7711C17.766 16.7709 18.3279 15.4143 18.3279 13.9998C18.3279 12.5854 17.766 11.2288 16.7658 10.2286C15.7656 9.22841 14.4091 8.6665 12.9946 8.6665Z" fill="var(--link-panel-toolbar-icon)"/>\n</svg>\n',title:u?"":"Settings",style:{fill:"#565656"},onClick:o,ref:E})),y.value&&r().createElement(Wl,{className:"runway",onClick:()=>{M(!0)},disabled:(e=>0===Object.keys(e).length)(O)},Ul,r().createElement("span",{className:"label"},"Upload Pipeline")),r().createElement(Kt,{title:g||T()?"":"Pipeline Parameters"},r().createElement(Wl,{onClick:v},$l,r().createElement("span",{className:"label parameter"},"Parameter"),r().createElement("span",{className:"count"},f))))),_&&r().createElement(Bl,{closeDialog:()=>{M(!1)},tracker:x}));var F},(0,_.x)((0,jt.observer)(Dl)));var Dl;const Wl=S().button`
  height: 24px;
  padding: 0 8px;
  border: none;
  border-radius: 4px;
  color: var(--button-link-text);
  font-weight: 500;
  font-size: 13px;
  line-height: 15px;
  background-color: var(--button-link-background);
  display: flex;
  align-items: center;
  margin-left: 6px;
  &.runway {
    background-color: var(--key-color);
  }

  &:disabled {
    opacity: 0.3;
  }

  &:hover {
    background-color: var(--button-link-background-hover);
  }
  &.runway:hover {
    background-color: var(--purple-400);
  }
  &.runway:disabled:hover {
    background-color: var(--key-color);
  }

  .label {
    margin-left: 6px;
    white-space: pre;
  }
  .label.parameter {
    display: none;
  }
  .show-parameter-text & .label.parameter {
    display: inline;
  }

  .count {
    display: inline-block;
    font-size: 11px;
    font-weight: 500;
    line-height: 13px;
    padding: 1px 5px;
    color: var(--link-color);
    margin-left: 6px;
    background: var(--white);
    border-radius: 10px;
  }
  &:hover .count {
    color: var(--button-link-background-hover);
  }
`,Ul=r().createElement("svg",{width:"12",height:"12",viewBox:"0 0 14 13",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M2.76107 12.5H12.0944C12.448 12.5 12.7872 12.3595 13.0372 12.1095C13.2873 11.8594 13.4277 11.5203 13.4277 11.1667V3.83333L10.0944 0.5H2.76107C2.40745 0.5 2.06831 0.640476 1.81826 0.890524C1.56821 1.14057 1.42773 1.47971 1.42773 1.83333V11.1667C1.42773 11.5203 1.56821 11.8594 1.81826 12.1095C2.06831 12.3595 2.40745 12.5 2.76107 12.5ZM4.0944 1.83333H6.76107V3.16667H8.0944V1.83333H9.42773V4.5H4.0944V1.83333ZM4.0944 7.16667H10.7611V11.1667H4.0944V7.16667Z",fill:"#fff"})),$l=r().createElement("svg",{width:"12",height:"12",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M1.5 2.5H3.5M10.5 2.5H5.5M1.5 6H7.5M10.5 6H9.5M1.5 9.5H2.5M10.5 9.5H4.5",stroke:"white",strokeWidth:"0.947368",strokeLinecap:"round"}),r().createElement("path",{d:"M4.5 3.5C5.05228 3.5 5.5 3.05228 5.5 2.5C5.5 1.94772 5.05228 1.5 4.5 1.5C3.94772 1.5 3.5 1.94772 3.5 2.5C3.5 3.05228 3.94772 3.5 4.5 3.5Z",stroke:"white",strokeWidth:"0.947368",strokeLinecap:"round"}),r().createElement("path",{d:"M8.5 7C9.05228 7 9.5 6.55228 9.5 6C9.5 5.44772 9.05228 5 8.5 5C7.94772 5 7.5 5.44772 7.5 6C7.5 6.55228 7.94772 7 8.5 7Z",stroke:"white",strokeWidth:"0.947368",strokeLinecap:"round"}),r().createElement("path",{d:"M3.5 10.5C4.05228 10.5 4.5 10.0523 4.5 9.5C4.5 8.94772 4.05228 8.5 3.5 8.5C2.94772 8.5 2.5 8.94772 2.5 9.5C2.5 10.0523 2.94772 10.5 3.5 10.5Z",stroke:"white",strokeWidth:"0.947368",strokeLinecap:"round"})),Gl=jl;var ql=n(66840);const Kl=new class{constructor(){this.visible=!1,this.componentName="",this.summary={objects:[],functions:[],classes:[],modules:[]},this.position={x:0,y:0,width:0},(0,ce.makeAutoObservable)(this)}close(){this.visible=!1}open({componentName:e,position:t,summary:n}){di.enabledSummary&&(this.componentName=e,this.position=t,this.summary=n||{objects:[],functions:[],classes:[],modules:[]},this.visible=!0)}};var Yl=n(30982),Xl=n.n(Yl);var Jl;!function(e){e.BACKGROUND="BACKGROUND",e.NODE="NODE",e.EDGE="EDGE"}(Jl||(Jl={})),ql.selection.prototype.appendHTML=function(e){const t=this.append("foreignObject");return t.node().appendChild(document.importNode((new DOMParser).parseFromString(e,"text/html").body.childNodes[0],!0)),t},ql.selection.prototype.appendSVG=function(e){const t=this.append("g");return t.node().appendChild(document.importNode((new DOMParser).parseFromString(e,"application/xml").documentElement,!0)),t};class Ql{constructor(e,t){let n;this._nodes=[],this._edges=[],this.ZOOM_SCALE_FACTOR=t.ZOOM_SCALE_FACTOR,this.ZOOM_SCALE_MAX=t.ZOOM_SCALE_MAX,this.ZOOM_SCALE_MIN=t.ZOOM_SCALE_MIN,this.ZOOM_AUTOFIT_SCALE=.8,this.dblclick=t.dblclick,this.mouseenter=t.mouseenter,this.mouseleave=t.mouseleave,this.mousedown=t.mousedown,this.mouseup=t.mouseup,this.mousemove=t.mousemove,this.wheel=t.wheel,this.render=t.render,this.transform=t.transform,this.transformend=t.transformend,n="string"==typeof e?document.getElementById(e):e,this.container={width:n.clientWidth,height:n.clientHeight,div:n},this.element=ql.select(n).append("svg:svg").attr("class","graph-background").style("width","100%").style("height","100%").attr("preserveAspectRatio","xMinYMin"),this.element.append("defs").append("marker").attr("id","normal").attr("viewBox","0 0 10 10").attr("refX",9).attr("refY",5).attr("markerUnits","strokeWidth").attr("markerWidth",8).attr("markerHeight",6).attr("orient","auto").append("path").attr("d","M 0 0 L 10 5 L 0 10 z").style("stroke-width",1).style("stroke-dasharray","1,0").attr("fill","var(--link-color)"),this.zoom=ql.zoom().scaleExtent([this.ZOOM_SCALE_MIN,this.ZOOM_SCALE_MAX]).on("start",(()=>{if(this.scrollbar.customTransform){const{x:e,y:t,scale:n}=this.scrollbar.customTransform;this._transform(e,t,n),this.scrollbar.customTransform=void 0}})).on("zoom",(e=>{const{x:t,y:n}=this.limitScrollBound(e.transform.x,e.transform.y);e.transform.x=t,e.transform.y=n,this.transform&&this.transform(e,this),this.updateScrollbar()})).on("end",(e=>{this.transformend&&this.transformend(e,this)})).filter((e=>{if("wheel"===e.type&&!e.ctrlKey&&!e.metaKey)return!1;const t=e.target,n=this.scrollbar.x.node()&&this.scrollbar.x.node().contains(t),a=this.scrollbar.y.node()&&this.scrollbar.y.node().contains(t);return n||a?(this.scrollbar.direction=n?"x":"y",!1):!e.button})),this.element.on("dblclick",(e=>this.dblclick&&this.dblclick(e,this))).on("mouseenter",(e=>this.mouseenter&&this.mouseenter(e,this))).on("mouseleave",(e=>{this.mouseleave&&this.mouseleave(e,this)})).on("mousedown",(e=>{this.mousedown&&this.mousedown(e,this)})).on("mouseup",(e=>{this.mouseup&&this.mouseup(e,this)})).on("mousemove",(e=>{this.mousemove&&this.mousemove(e,this)})).on("wheel",(e=>{e.preventDefault(),this.wheel&&this.wheel(e,this)})),this.element.call(ql.drag().on("start",(e=>this.scrollStart(e.sourceEvent))).on("drag",(e=>{this.scrollbar.direction?this.scrollMove(e.sourceEvent):this.dragMove(e)})).on("end",(()=>this.scrollEnd())).filter((()=>!this.scrollbar.direction))),this.vis=this.element.append("g"),this.element.call(this.zoom).on("dblclick.zoom",null),this.edgeGroup=this.vis.append("g"),this.nodeGroup=this.vis.append("g"),this.render&&this.render(Jl.BACKGROUND,this),this.scrollbar=this.appendScrollbar()}getTransformedGraphBounds(){const e=this.vis.node();if(!e)return{startX:0,startY:0,endX:0,endY:0};const t=e.getBBox(),n=ql.zoomTransform(e),a=n.applyX(t.x),r=n.applyY(t.y);return{startX:a,startY:r,endX:a+n.k*t.width,endY:r+n.k*t.height}}limitScrollBound(e,t){const n=this.container.div;if(!this.vis.node()||!n)return{x:e,y:t};const a=n.clientWidth,r=n.clientHeight,l=this.getTransformedGraphBounds(),o={x:e,y:t},i=50;return l.startX>a-i?o.x-=l.startX-a+i:l.endX<i&&(o.x-=l.endX-i),l.startY>r-i?o.y-=l.startY-r+i:l.endY<i&&(o.y-=l.endY-i),o}appendScrollbar(){function e(e){return e.attr("rx","4").attr("ry","4").attr("fill","rgba(0, 0, 0, 0.24)")}return{x:e(this.element.append("rect")).attr("width","100%").attr("height","9").attr("x","0").attr("y","100%").attr("transform","translate(0, -13)"),y:e(this.element.append("rect")).attr("width","9").attr("height","100%").attr("x","100%").attr("y","0").attr("transform","translate(-13, 0)"),direction:null,clientX:0,clientY:0,initialX:0,initialY:0,scale:0,viewportWidth:0,viewportHeight:0,viewportOverflow:{top:0,right:0,bottom:0,left:0},scrollWidth:0,scrollHeight:0}}getTransform(){const e=this.vis.attr("transform");if(!e)return{x:0,y:0,scale:0};const[t,n]=e.split(") scale("),[a,r]=t.split(",");return{x:Number(a.split("translate(")[1]),y:Number(r.replace(")","")),scale:Number(n.replace(")",""))}}dragMove({dx:e,dy:t}){const n=this.getTransform(),a=Math.max(.001,n.scale);this.scrollBy(e/a,t/a)}updateScrollbar(){const{clientWidth:e,clientHeight:t}=this.container.div,{width:n,height:a,x:r,y:l}=this.vis.node().getBBox(),{x:o,y:i,scale:s}=this.getTransform(),c=e/2-s*(r+n/2),d=t/2-s*(l+a/2);this.scrollbar.viewportOverflow={top:-1*(i-d-a*s/this.ZOOM_AUTOFIT_SCALE/2+t/2),right:o-c+n*s/this.ZOOM_AUTOFIT_SCALE/2-e/2,bottom:i-d+a*s/this.ZOOM_AUTOFIT_SCALE/2-t/2,left:-1*(o-c-n*s/this.ZOOM_AUTOFIT_SCALE/2+e/2)};const p=Math.max(this.scrollbar.viewportOverflow.top,0),m=Math.max(this.scrollbar.viewportOverflow.right,0),u=Math.max(this.scrollbar.viewportOverflow.bottom,0),h=Math.max(this.scrollbar.viewportOverflow.left,0),g=h+m+e,v=p+u+t;this.scrollbar.x.attr("visibility",e/g==1?"hidden":"visible").attr("width",e/g*100+"%").attr("x",h/g*100+"%"),this.scrollbar.y.attr("visibility",t/v==1?"hidden":"visible").attr("height",t/v*100+"%").attr("y",p/v*100+"%"),this.scrollbar.viewportWidth=e,this.scrollbar.viewportHeight=t,this.scrollbar.scrollWidth=g,this.scrollbar.scrollHeight=v}scrollStart(e){const t=e.target,n=this.scrollbar.x.node()&&this.scrollbar.x.node().contains(t),a=this.scrollbar.y.node()&&this.scrollbar.y.node().contains(t);if(!n&&!a)return;const r=this.getTransform();this.scrollbar.direction=n?"x":"y",this.scrollbar.clientX=e.clientX,this.scrollbar.clientY=e.clientY,this.scrollbar.initialX=r.x,this.scrollbar.initialY=r.y,this.scrollbar.scale=r.scale}scrollMove(e){if(null===this.scrollbar.direction)return;0===e.buttons&&this.scrollEnd();const t=this.scrollbar,n=t.initialX-(e.clientX-t.clientX)/t.viewportWidth*t.scrollWidth,a=t.initialY-(e.clientY-t.clientY)/t.viewportHeight*t.scrollHeight,r="x"===t.direction?n:t.initialX,l="y"===t.direction?a:t.initialY;this.vis.attr("transform",`translate(${r},${l}) scale(${this.scrollbar.scale})`),this.scrollbar.customTransform={x:r,y:l,scale:this.scrollbar.scale},this.updateScrollbar()}scrollEnd(){this.scrollbar.direction=null}zoomIn(){this.zoom.scaleBy(this.element,1+this.ZOOM_SCALE_FACTOR)}zoomOut(){this.zoom.scaleBy(this.element,1-this.ZOOM_SCALE_FACTOR)}zoomFit(){if(this.vis&&this.container.div){const e=this.vis.node();if(e){const t=e.getBBox(),n=this.container.div.clientWidth,a=this.container.div.clientHeight,r=t.width,l=t.height,o=t.x+r/2,i=t.y+l/2;if(0===r||0===l)return;let s=this.ZOOM_AUTOFIT_SCALE/Math.max(r/n,l/a);s<this.ZOOM_SCALE_MIN?s=this.ZOOM_SCALE_MIN:s>this.ZOOM_SCALE_MAX&&(s=this.ZOOM_SCALE_MAX);const c=[n/2-s*o,a/2-s*i];this._transform(c[0],c[1],s)}}}_transform(e,t,n){this.element.call(this.zoom.transform,ql.zoomIdentity.translate(e,t).scale(n))}scrollBy(e,t){this.zoom.translateBy(this.element,e,t)}scroll(e){var t,n;if(e.ctrlKey||e.metaKey)return;let a=e.deltaX,r=e.deltaY;e.deltaMode===e.DOM_DELTA_LINE&&(a*=16,r*=16),e.shiftKey&&0===a&&([a,r]=[r,a]);const l=this.element.node(),o=null!==(n=null===(t=null==l?void 0:l.__zoom)||void 0===t?void 0:t.k)&&void 0!==n?n:1;this.scrollBy(-1*a*.4/o,-1*r*.4/o)}renderGraph(e,t){const n=((e,t)=>{const n=(new(Xl().graphlib.Graph)).setGraph({rankdir:"TB",ranksep:100,nodesep:100,edgesep:-20}).setDefaultEdgeLabel((()=>({})));e.forEach((e=>{n.setNode(e.id,e)})),t.forEach((e=>{n.setEdge(e.source,e.target,e)})),Xl().layout(n);const a=((e,t)=>(t.forEach((t=>{const n=e.find((e=>e.id===t.source)),a=e.find((e=>e.id===t.target));if(!n||!a)return;t.points[0]={x:n.x,y:n.y+n.height/2},t.points[t.points.length-1]={x:a.x,y:a.y-a.height/2};const r={x:t.points[0].x,y:t.points[0].y+20};t.points.splice(1,0,r);const l={x:t.points[t.points.length-1].x,y:t.points[t.points.length-1].y-20};t.points.splice(t.points.length-1,0,l);const o=n.x<a.x?n.x:a.x,i=n.x<a.x?a.x:n.x,s=t.points.map((e=>(e.x<o&&(e.x=o),e.x>i&&(e.x=i),e)));t.points=s})),t))(e,t);return a.forEach((e=>{var t;e.path=(t=e.points,ql.line().curve(ql.curveBasis)(t.filter((e=>!Number.isNaN(e.x)&&!Number.isNaN(e.y))).map((e=>[e.x,e.y]))))})),{nodes:e,edges:a}})(e,t),a=this._hasMovedNode(this._nodes,n.nodes);this._nodes=n.nodes,this._edges=n.edges,this.renderNode(),this.renderEdge(),a&&this.zoomFit()}_hasMovedNode(e,t){return t.some(((t,n)=>{const a=e[n];return!a||a.x!==t.x||a.y!==t.y}))}renderNode(){const e=this.nodeGroup.selectAll(".node").data(this._nodes,(e=>e.id));e.exit().remove(),e.enter().insert("svg:g").attr("class","node").each(((e,t,n)=>{const a=n[t],r=ql.select(a);e.element=r,e.render=e.render?e.render:this.render,e.render&&e.render(Jl.NODE,e),r.select(".bounding-rect").on("mouseleave",(t=>e.mouseleave&&e.mouseleave(t,e))).attr("id",e.id).on("mouseenter",(t=>e.mouseenter&&e.mouseenter(t,e))).on("mousedown",(t=>e.mousedown&&e.mousedown(t,e))).on("mouseup",(t=>e.mouseup&&e.mouseup(t,e))).on("dblclick",(t=>e.dblclick&&e.dblclick(t,e))).on("click",(t=>e.click&&e.click(t,e)))})),e.each(((e,t,n)=>{const a=n[t],r=ql.select(a);e.element=r,e.render=e.render?e.render:this.render,e.render&&e.render(Jl.NODE,e),r.select(".bounding-rect").on("mouseleave",(t=>e.mouseleave&&e.mouseleave(t,e))).on("mouseenter",(t=>e.mouseenter&&e.mouseenter(t,e))).on("mousedown",(t=>e.mousedown&&e.mousedown(t,e))).on("mouseup",(t=>e.mouseup&&e.mouseup(t,e))).on("dblclick",(t=>e.dblclick&&e.dblclick(t,e))).on("click",(t=>e.click&&e.click(t,e)))}))}renderEdge(){const e=this.edgeGroup.selectAll(".edge").data(this._edges,(e=>e.id));e.exit().remove(),e.enter().insert("svg:g").attr("class","edge").each(((e,t,n)=>{const a=n[t],r=ql.select(a);e.element=r,r.on("mouseenter",(t=>e.mouseenter&&e.mouseenter(t,e))).on("mouseleave",(t=>e.mouseleave&&e.mouseleave(t,e))).on("mousedown",(t=>e.mousedown&&e.mousedown(t,e))).on("mouseup",(t=>e.mouseup&&e.mouseup(t,e))).on("dblclick",(t=>e.dblclick&&e.dblclick(t,e))).on("click",(t=>e.click&&e.click(t,e))),e.render=e.render?e.render:this.render,e.render&&e.render(Jl.EDGE,e)})),e.each(((e,t,n)=>{const a=n[t],r=ql.select(a);r.on("mouseenter",(t=>e.mouseenter&&e.mouseenter(t,e))).on("mouseleave",(t=>e.mouseleave&&e.mouseleave(t,e))).on("dblclick",(t=>e.dblclick&&e.dblclick(t,e))).on("click",(t=>e.click&&e.click(t,e))),e.element=r,e.render=e.render?e.render:this.render,e.render&&e.render(Jl.EDGE,e)}))}}const eo={invalid:'<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M10,0C4.5,0,0,4.5,0,10s4.5,10,10,10c5.5,0,10-4.5,10-10S15.5,0,10,0z M9.4,4.9h1.2c0.3,0,0.5,0.2,0.5,0.5l-0.2,6.2\n\tc0,0.3-0.2,0.5-0.5,0.5H9.6c-0.3,0-0.5-0.2-0.5-0.5L8.9,5.4C8.9,5.1,9.1,4.9,9.4,4.9z M10.8,15.1c-0.2,0.2-0.5,0.3-0.8,0.3\n\tc-0.3,0-0.6-0.1-0.8-0.3c-0.2-0.2-0.3-0.5-0.3-0.8c0-0.3,0.1-0.6,0.3-0.8s0.5-0.3,0.8-0.3c0.3,0,0.6,0.1,0.8,0.3\n\tc0.2,0.2,0.3,0.5,0.3,0.8C11.2,14.7,11.1,14.9,10.8,15.1z"/>\n</svg>\n',running:'<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n\t<circle cx="10" cy="10" r="9" fill="none" stroke="var(--feedback-info)" stroke-width="2" stroke-linecap="round">\n\t\t<animateTransform attributeName="transform" attributeType="XML" type="rotate" from="0 10 10" to="360 10 10" dur="2s" repeatCount="indefinite" />\n\t\t<animate attributeName="stroke-dasharray" attributeType="XML" values="1, 55.5; 40, 55.5; 40, 55.5" dur="1.5s" repeatCount="indefinite" />\n\t\t<animate attributeName="stroke-dashoffset" attributeType="XML" values="0; -15.5; -55.5" dur="1.5s" repeatCount="indefinite" />\n\t</circle>\n</svg>\n',failed:'<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n\t<path d="M10,0C4.5,0,0,4.5,0,10s4.5,10,10,10s10-4.5,10-10S15.5,0,10,0z M13.1,11.9c0.3,0.3,0.3,0.9,0,1.2\n\t\tc-0.2,0.2-0.4,0.2-0.6,0.2s-0.4-0.1-0.6-0.2L10,11.2l-1.9,1.9c-0.2,0.2-0.4,0.2-0.6,0.2s-0.4-0.1-0.6-0.2c-0.3-0.3-0.3-0.9,0-1.2\n\t\tL8.8,10L6.9,8.1c-0.3-0.3-0.3-0.9,0-1.2s0.9-0.3,1.2,0L10,8.8l1.9-1.9c0.3-0.3,0.9-0.3,1.2,0c0.3,0.3,0.3,0.9,0,1.2L11.2,10\n\t\tL13.1,11.9z"/>\n</svg>\n',successful:'<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n<g>\n\t<path d="M10,0C4.5,0,0,4.5,0,10s4.5,10,10,10s10-4.5,10-10S15.5,0,10,0z M14.6,8.4l-5.9,4.5c-0.2,0.1-0.3,0.2-0.5,0.2\n\t\tc-0.2,0-0.4-0.1-0.6-0.2l-2.2-2.2C5,10.3,5,9.8,5.4,9.5s0.9-0.3,1.2,0l1.7,1.7l5.3-4c0.4-0.3,0.9-0.2,1.2,0.2\n\t\tC15,7.6,14.9,8.2,14.6,8.4z"/>\n</g>\n</svg>\n'},to=(e,t=!0)=>{var n,a,r,l;const o=(null===(n=e.element)||void 0===n?void 0:n.select(".label-container").node())?null===(a=e.element)||void 0===a?void 0:a.select(".label-container"):e.element.appendHTML("<p />").attr("class","label-container").style("pointer-events","none");o.attr("x",-e.width/2+12).attr("y",-e.height/2).attr("width",e.width-24).attr("height",e.height).attr("visibility",t?"visible":"hidden"),o.select("p").attr("class",e.metadata.active?"active":e.metadata.status).text(e.metadata.label),null===(r=e.element)||void 0===r||r.select(".link-node-status").remove(),null===(l=e.element)||void 0===l||l.appendSVG(eo[e.metadata.status]).attr("class",`link-node-status${e.metadata.active?" active":""} ${e.metadata.status}`).style("pointer-events","none")};function no(e){return"invalid"===e?"var(--link-panel-dag-selected-background)":"successful"===e?"var(--link-panel-dag-successful-background)":"running"===e?"var(--link-panel-dag-selected-background)":"failed"===e?"var(--link-panel-dag-failed-background)":void 0}let ao="";function ro(){return ao}function lo(e){ao=e}function oo(e,t){co(e,!0,t)}function io(e,t){co(e,!1,t)}function so(e,t){e.on("mouseenter",(()=>{t.attr("fill","var(--link-panel-toolbar-icon-hover-bg)")})).on("mouseleave",(()=>{t.attr("fill","var(--link-panel-toolbar-background)")}))}const co=(e,t,n)=>{var a,r;const l=(null===(a=e.element)||void 0===a?void 0:a.select(".link-toolbar").node())?null===(r=e.element)||void 0===r?void 0:r.select(".link-toolbar"):e.element.appendSVG('<svg class="link-toolbar" width="215.5" height="64.1" viewBox="0 0 168 50" fill="none" xmlns="http://www.w3.org/2000/svg" x="-107.8">\n  <rect x="8" width="152" height="34" rx="8" fill="var(--link-panel-toolbar-background)" stroke="var(--link-dag-summary-title-bottom-border-color)" shape-rendering="crispEdges"/>\n  <g class="link-cache">\n    <rect class="link-cache-bg" x="20" y="5" width="32" height="24" rx="4" fill="var(--link-panel-toolbar-background)"/>\n    <path class="link-cache-enabled" d="M43 10.4286V11.9464C43 13.284 39.6406 14.375 35.5 14.375C31.3594 14.375 28 13.284 28 11.9464V10.4286C28 9.09095 31.3594 8 35.5 8C39.6406 8 43 9.09095 43 10.4286ZM43 13.8437V17.2589C43 18.5965 39.6406 19.6875 35.5 19.6875C31.3594 19.6875 28 18.5965 28 17.2589V13.8437C29.6113 14.9442 32.5605 15.4565 35.5 15.4565C38.4395 15.4565 41.3886 14.9442 43 13.8437ZM43 19.1562V22.5714C43 23.909 39.6406 25 35.5 25C31.3594 25 28 23.909 28 22.5714V19.1562C29.6113 20.2567 32.5605 20.769 35.5 20.769C38.4395 20.769 41.3886 20.2567 43 19.1562Z" fill="var(--link-panel-toolbar-icon)" />\n    <path class="link-cache-disabled" visibility="hidden" fill-rule="evenodd" clip-rule="evenodd" d="M44.7188 9.69492C45.1026 9.29777 45.0918 8.6647 44.6946 8.28091C44.2975 7.89712 43.6644 7.90794 43.2806 8.30509L27.2809 24.8614C26.8971 25.2586 26.9079 25.8916 27.3051 26.2754C27.7022 26.6592 28.3353 26.6484 28.7191 26.2513L30.5213 24.3863C31.8459 24.7678 33.5898 25 35.5 25C39.6407 25 43 23.909 43 22.5714V19.1563C41.3887 20.2567 38.4395 20.769 35.5 20.769C35.0174 20.769 34.5346 20.7552 34.0574 20.7272L35.0661 19.6835C35.2097 19.6862 35.3544 19.6875 35.5 19.6875C39.6407 19.6875 43 18.5965 43 17.2589V13.8438C42.1399 14.4311 40.8987 14.851 39.4812 15.1147L40.9235 13.6223C42.2098 13.1859 43 12.5952 43 11.9464V11.4735L44.7188 9.69492ZM35.5 8C37.5508 8 39.41 8.26763 40.7643 8.7003L35.0931 14.3715C31.1415 14.3028 28 13.2399 28 11.9464V10.4286C28 9.09096 31.3594 8 35.5 8ZM28 13.8438C29.3455 14.7626 31.6237 15.2714 34.0502 15.4143L30.4203 19.0442C28.9325 18.5999 28 17.9636 28 17.2589V13.8438ZM28 19.1563C28.4302 19.4501 28.9558 19.702 29.5512 19.9134L28 21.4645V19.1563Z" fill="var(--link-panel-toolbar-icon)" />\n  </g>\n  <g class="link-run">\n    <rect class="link-run-bg" x="68" y="5" width="32" height="24" rx="4" fill="var(--link-panel-toolbar-background)"/>\n    <path fill-rule="evenodd" clip-rule="evenodd" d="M79.6364 10.153C78.9091 9.71827 78 10.2617 78 11.1311V22.8688C78 23.7383 78.9091 24.2817 79.6364 23.847L89.4545 17.9781C90.1818 17.5434 90.1818 16.4566 89.4545 16.0219L79.6364 10.153Z" fill="var(--link-panel-toolbar-icon)"/>\n  </g>\n  <g class="link-header-color">\n    <rect class="link-header-color-bg" x="116" y="5" width="32" height="24" rx="4" fill="var(--link-panel-toolbar-background)"/>\n    <g transform="scale(1.1) translate(110, 5)">\n      <path style="fill-rule:evenodd;clip-rule:evenodd;" d="M16.9,10c0,2-2.8,4.1-5.5,3.2c-1.4-0.5-1.8,0.9-0.9,1.8c0.9,0.9,0.5,1.8-0.5,1.8c-3.8,0-6.9-3.1-6.9-6.9\n          c0-3.8,3.1-6.9,6.9-6.9C13.8,3.1,16.9,6.2,16.9,10z M9.5,5.9c0,0.5-0.4,0.9-0.9,0.9c-0.5,0-0.9-0.4-0.9-0.9s0.4-0.9,0.9-0.9\n          C9.1,4.9,9.5,5.4,9.5,5.9z M5.9,8.6c0.5,0,0.9-0.4,0.9-0.9c0-0.5-0.4-0.9-0.9-0.9c-0.5,0-0.9,0.4-0.9,0.9C4.9,8.2,5.4,8.6,5.9,8.6z\n          M12.3,5.9c0,0.5-0.4,0.9-0.9,0.9c-0.5,0-0.9-0.4-0.9-0.9s0.4-0.9,0.9-0.9C11.9,4.9,12.3,5.4,12.3,5.9z M14.1,8.6\n          c0.5,0,0.9-0.4,0.9-0.9c0-0.5-0.4-0.9-0.9-0.9c-0.5,0-0.9,0.4-0.9,0.9C13.2,8.2,13.6,8.6,14.1,8.6z"\n        fill="var(--link-panel-toolbar-icon)"\n      />\n    </g>\n  </g>\n</svg>').select("svg"),o=l.node();l.attr("y",t?41.5:-10).attr("visibility",t?"visible":"hidden").attr("opacity",t?1:0).style("filter","drop-shadow(0px 4px 6px rgba(0, 0, 0, 0.2))"),e.metadata.diskcache?o.classList.add("diskcache"):o.classList.remove("diskcache"),"running"===e.metadata.status?o.classList.add("running"):o.classList.remove("running");const i=l.select(".link-cache"),s=l.select(".link-cache-bg"),c=l.select(".link-run"),d=l.select(".link-run-bg"),p=l.select(".link-header-color"),m=l.select(".link-header-color-bg");so(i,s),so(c,d),so(p,m),i.on("click",(()=>{e.metadata.diskcache?n.commands.execute(Rt.disableComponentCache,{nodeInfo:{original:{id:e.id}}}):n.commands.execute(Rt.enableComponentCache,{nodeInfo:{original:{id:e.id}}}),io(e,n),lo("")})),c.on("click",(t=>{2===t.buttons||t.shiftKey||t.ctrlKey||(n.commands.execute(Rt.runComponent,{nodeInfo:{original:{id:e.id},event:t}}),io(e,n),lo(""))})),p.on("click",(()=>{Da.open("header-color"),io(e,n),lo("")}))};let po;const mo={nodes:{},edges:{}};let uo=[];const ho={};let go,vo=0,fo=null;const xo=()=>{clearTimeout(vo),vo=0},bo=(0,jt.observer)((0,a.forwardRef)(((e,t)=>{const n=(0,a.useRef)([]);(0,a.useImperativeHandle)(t,(()=>({zoomIn(){po.zoomIn()},zoomOut(){po.zoomOut()},fitZoom(){po.zoomFit()}})));const{tracker:l,lab:o,kernelId:i,isPanelVisible:s}=e,c=pe.getKernelComponents(i),d=(0,a.createRef)(),p=()=>{const e=po.vis.node();if(!e)return!0;const t=e.getBBox();return 0===t.width&&0===t.height},m=(t,a)=>{switch(t){case Jl.NODE:(t=>{var a,r;null===(a=t.element)||void 0===a||a.attr("transform",(e=>"translate("+t.x+","+t.y+")")),((e,t)=>{var n,a,r;const l=(null===(n=e.element)||void 0===n?void 0:n.select(".bounding-rect").node())?null===(a=e.element)||void 0===a?void 0:a.select(".bounding-rect"):e.element.append("rect");let o="",i="";e.metadata.active?"failed"===e.metadata.status?(o="var(--link-panel-dag-failed-background)",i="var(--link-panel-dag-failed-background)"):"successful"===e.metadata.status?(o="var(--link-panel-dag-successful-background)",i="var(--link-panel-dag-successful-background)"):"running"===e.metadata.status?(o="var(--link-panel-dag-selected-background)",i=""):"invalid"===e.metadata.status&&(o="var(--link-panel-dag-selected-background)",i="var(--link-panel-dag-selected-background)"):"failed"===e.metadata.status?(o="var(--link-panel-dag-failed-not-selected-background)",i="var(--link-panel-dag-failed-background)"):"successful"===e.metadata.status?(o="var(--link-panel-dag-successful-not-selected-background)",i="var(--link-panel-dag-successful-background)"):("running"===e.metadata.status||"invalid"===e.metadata.status)&&(o="var(--link-panel-dag-not-selected-background)",i="var(--link-panel-dag-selected-background)"),l.attr("class","bounding-rect").attr("x",-e.width/2).attr("y",-e.height/2).attr("rx",5).attr("ry",5).attr("width",e.width).attr("height",e.height),null===(r=e.element)||void 0===r||r.select(".bounding-rect").style("fill",o).style("stroke",i).style("stroke-width",1).style("stroke-dasharray","0, 0"),l.style("fill",o).style("stroke",i).style("stroke-width",1).style("stroke-dasharray","0, 0")})(t,e.lab),to(t,!0),ro()===t.metadata.id&&(null===(r=t.element)||void 0===r||r.select("#play-container").style("opacity",1)),(e=>{var t,n,a,r;if(e.metadata&&e.element){let l=null===(t=e.metadata)||void 0===t?void 0:t.headerColor;const o=null===(n=e.metadata)||void 0===n?void 0:n.status,i=!l||["none","inherit","transparent"].find((e=>e===l)),s=i?.1:1;i&&(l=e.metadata.active?"var(--link-header-color-none-active-stroke-color)":no(o));const c=(null===(a=e.element)||void 0===a?void 0:a.select(".header-color").node())?null===(r=e.element)||void 0===r?void 0:r.select(".header-color"):e.element.append("path").attr("class","header-color"),d=ql.path();d.moveTo(-e.width/2+10,-e.height/2),d.lineTo(-e.width/2+5,-e.height/2),d.bezierCurveTo(-e.width/2,-e.height/2+1.5,-e.width/2,-e.height/2+2.5,-e.width/2,-e.height/2+5),d.lineTo(-e.width/2,-e.height/2+ +e.height-5),d.bezierCurveTo(-e.width/2,-e.height/2+e.height-2.5,-e.width/2,-e.height/2+e.height-1.5,-e.width/2+5,-e.height/2+e.height),d.lineTo(-e.width/2+10,-e.height/2+e.height),c.attr("d",d.toString()).attr("opacity",s).style("fill",l),c.style("stroke",no(o))}})(t),(e=>{var t,n;const a=!0===e.metadata.diskcache?e.metadata.diskcache_status:"";null===(t=e.element)||void 0===t||t.select(".link-cache-status").remove(),null===(n=e.element)||void 0===n||n.appendSVG((e=>`<svg class="link-cache-status" width="26" height="26" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n    <path class="disk" d="M15.0143 5.95179V6.92263C15.0143 7.7782 12.8835 8.47599 10.2571 8.47599C7.6308 8.47599 5.5 7.7782 5.5 6.92263V5.95179C5.5 5.09623 7.6308 4.39844 10.2571 4.39844C12.8835 4.39844 15.0143 5.09623 15.0143 5.95179ZM15.0143 8.13619V10.3206C15.0143 11.1762 12.8835 11.8739 10.2571 11.8739C7.6308 11.8739 5.5 11.1762 5.5 10.3206V8.13619C6.52204 8.84006 8.39268 9.16773 10.2571 9.16773C12.1216 9.16773 13.9922 8.84006 15.0143 8.13619ZM15.0143 11.5342V13.7186C15.0143 14.5741 12.8835 15.2719 10.2571 15.2719C7.6308 15.2719 5.5 14.5741 5.5 13.7186V11.5342C6.52204 12.238 8.39268 12.5657 10.2571 12.5657C12.1216 12.5657 13.9922 12.238 15.0143 11.5342Z" fill="#6C79F9"/>\n    ${"updating"===e?'<g class="loading">\n    <circle cx="10" cy="10" r="9" fill="none" stroke="var(--feedback-info)" stroke-width="2" stroke-linecap="round">\n      <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="0 10 10" to="360 10 10" dur="2s" repeatCount="indefinite" />\n      <animate attributeName="stroke-dasharray" attributeType="XML" values="1, 55.5; 40, 55.5; 40, 55.5" dur="1.5s" repeatCount="indefinite" />\n      <animate attributeName="stroke-dashoffset" attributeType="XML" values="0; -15.5; -55.5" dur="1.5s" repeatCount="indefinite" />\n    </circle>\n  </g>':""}\n  </svg>`)(a)).attr("transform","translate(71, -66)").attr("visibility",a.length>0?"visible":"hidden").attr("class",`link-cache-status ${a}`)})(t),((e,t)=>{var n,a,r;const l=t.reduce(((e,t)=>[...e,...t.components]),[]);((null===(n=e.element)||void 0===n?void 0:n.select(".link-remote-status").node())?null===(a=e.element)||void 0===a?void 0:a.select(".link-remote-status"):null===(r=e.element)||void 0===r?void 0:r.appendSVG(hl).attr("transform","translate(45, -62)")).attr("visibility",l.indexOf(e.id)>-1?"visible":"hidden")})(t,n.current),fo&&fo.id===t.id&&ro()===t.id?oo(t,o):io(t,o)})(a);break;case Jl.EDGE:(e=>{if(!e.element||!e.path)return;const t=e.element.select("path");t.node()?t.attr("d",e.path):e.element.append("path").attr("marker-end","url(#normal)").attr("d",e.path)})(a);case Jl.BACKGROUND:}},u=(e,t)=>{t.metadata.active&&(to(t,!0),t.metadata.enter=!0)},h=(e,t)=>{t.metadata.enter=!1,to(t,!0),vo=window.setTimeout((()=>{Kl.close()}),200)},g=(e,t)=>{var n,a;if(e.stopImmediatePropagation(),e.preventDefault(),e.stopPropagation(),e.ctrlKey||e.metaKey||e.shiftKey?(uo.forEach((e=>{io(e,o)})),fo=null):(uo.forEach((e=>{t.id!==e.id&&io(e,o)})),fo=t),!e.ctrlKey&&!e.metaKey&&!e.shiftKey){const e=l.currentWidget;ro()!==t.id?oo(t,o):io(t,o);const r=function(e,t){var n;const a=null===(n=e.currentWidget)||void 0===n?void 0:n.context.model.cells[Symbol.iterator](),r={idx:-1,cell:null};let l=0;for(;;){const e=null==a?void 0:a.next();if(!(a&&e&&e.value))break;{const n=e.value,a=n.getMetadata("canvas");if(a&&a.id===t){r.idx=l,r.cell=n;break}}l++}return r}(l,t.id),i=function(e,t){var n,a;const r=null===(n=e.currentWidget)||void 0===n?void 0:n.context.model.cells[Symbol.iterator](),l={meta:null,node:null};let o=0;for(;;){const n=null==r?void 0:r.next();if(!(r&&n&&n.value))break;{const r=n.value.getMetadata("canvas");if(r&&r.id===t){l.meta=r,l.node=null===(a=e.currentWidget)||void 0===a?void 0:a.node.children[2].children[o];break}}o++}return l}(l,t.id);let s=r.idx;if(e){if("CodeCell"!==i.meta.componentType){const e=null===(n=l.currentWidget)||void 0===n?void 0:n.content,t=i.node.querySelector(".vuetify-styles");s=he(o,l).indexOf(i.meta.id),t&&e.scrollToPosition(t.getBoundingClientRect().bottom,45)}e.content.activeCellIndex=s,null===(a=e.content.activeCell)||void 0===a||a.node.scrollIntoView({behavior:"auto",block:"center",inline:"center"}),uo.forEach((e=>{e.metadata.active=e.id===t.id})),mo.nodes[t.id].metadata.active=!0,to(t,!1),t.metadata.enter=!0}}ro()===t.id?lo(""):lo(t.id),po.renderNode()},v=()=>{var e;void 0!==go&&ho[go]?null===(e=po.element)||void 0===e||e.call(po.zoom.transform,ql.zoomIdentity.translate(ho[go].x,ho[go].y).scale(ho[go].k)):s&&c&&setTimeout((()=>{po.zoomFit()}),50)};return(0,a.useEffect)((()=>()=>{xo()}),[]),(0,a.useEffect)((()=>{if(d.current){const t={ZOOM_SCALE_FACTOR:.1,ZOOM_SCALE_MAX:1.25,ZOOM_SCALE_MIN:.1,render:m,dblclick:(e,t)=>{setTimeout((()=>{po.zoomFit()}),50)},wheel:(e,t)=>{po.scroll(e)},transform:(t,n)=>{var a;Kl.close(),p()&&go&&ho[go]&&(t.transform.x=ho[go].x,t.transform.y=ho[go].y,t.transform.k=ho[go].k),null!==t.sourceEvent&&"wheel"!==t.sourceEvent.type||(po.vis.attr("transform",t.transform),a=t,go&&(p()||(ho[go]={x:a.transform.x,y:a.transform.y,k:a.transform.k},e.onScaleChange(a.transform.k))))}};po=new Ql(d.current,t),di.connect(_t.CURRENT,(e=>{e&&e.kernel&&lo(""),(e=>{e&&(e.connect(Mt.ACTIVE_CELL,((e,t,n)=>{n&&!n.isEmpty&&(uo.forEach((e=>{e.metadata.active=e.id===n.id})),po.renderNode())})),fo=null)})(e)}))}}),[]),(0,a.useEffect)((()=>{(e=>{var t,n,a;if(null==e)return void po.renderGraph([],[]);const r=[],l=[];for(const o of Object.keys(e).sort()){const i=e[o],s={id:o,width:195,height:71,x:0,y:0,metadata:{label:i.name,status:i.execution_status,headerColor:i.metadata.headerColor,diskcache:i.metadata.diskcache,diskcache_status:i.diskcache_status,summary:i.summary,active:(null===(a=null===(n=null===(t=di.currentWidget)||void 0===t?void 0:t.cells)||void 0===n?void 0:n.activeCellMetadata)||void 0===a?void 0:a.id)===o,enter:!1},mouseenter:(e,t)=>u(0,t),mouseleave:(e,t)=>h(0,t),click:(e,t)=>g(e,t)};mo.nodes[o]&&(s.metadata.enter=mo.nodes[o].metadata.enter),mo.nodes[o]=s,r.push(s),i.parent_ids&&i.parent_ids.sort().forEach((e=>{const t={id:e+":"+o,source:e,target:o,points:[]};mo.edges[t.id]=t,l.push(t)}))}uo=r,po.renderGraph(r,l)})(c),v()}),[c]),(0,a.useEffect)((()=>{go=i}),[i]),(0,a.useEffect)((()=>{s&&v()}),[s]),(0,a.useEffect)((()=>{n.current=Ce.remoteServers,po.renderNode()}),[Ce.remoteServers]),r().createElement(Xa,{ref:d,className:"dagre-graph-container"})}))),Co=bo,Eo=S().div`
  position: absolute;
  top: 4px;
  right: 4px;
  width: 5px;
  height: 5px;
  background-color: var(--red-500);
  border-radius: 50%;
  display: ${e=>e.show?"block":"none"};
`,wo=()=>{const[e,t]=(0,a.useState)("closed"),[n,l]=(0,a.useState)(),o=async()=>{t("updating");try{const e=await async function(){return 200===(await h.post(`${s.PageConfig.getBaseUrl()}mrx-link/runway/update`)).status}();t(e?"updated":"failed")}catch(e){console.warn("Failed to update the version.",e),t("failed")}},i=()=>t("closed");return(0,a.useEffect)((()=>{(async e=>{e||(l(void 0),t("closed"));try{const e=await async function(){const e=`${s.PageConfig.getBaseUrl()}mrx-link/runway/update`;return(await fetch(e,{method:"GET"})).json()}();l(e)}catch(e){t("closed"),console.warn("Failed to fetch update info from the server.",e)}})(y.value)}),[y.value]),{isRunway:y.value,requiredToUpdateLink:null==n?void 0:n.update_required,latestLinkVersion:null==n?void 0:n.latest_version,openDialogToUpdateLink:()=>t("update"),DialogToUpdateLink:()=>{switch(e){case"update":return r().createElement(yo,{latestVersion:null==n?void 0:n.latest_version,onOk:o,onClose:i});case"updating":return r().createElement(ko,{onClose:i});case"updated":return r().createElement(Lo,{onClose:i});case"failed":return r().createElement(_o,{onClose:i});default:return null}}}},yo=({latestVersion:e,onOk:t,onClose:n})=>{const[l,o]=(0,a.useState)("");return(0,a.useEffect)((()=>{v().then((e=>o(e.version)))}),[]),r().createElement(se,{open:!0,onClose:n},r().createElement("h1",null,"Update Available"),r().createElement("section",null,r().createElement("p",null,"Your Link version is ",l,". A new version of Link",e?`, ${e}`:""," is now available. Updating takes a few minutes and need to restart this dev instance.")),r().createElement("section",{style:{display:"flex",justifyContent:"right"}},r().createElement(sa,{path:"release-note",title:"Release notes"})),r().createElement("menu",null,r().createElement("button",{onClick:n},"Close"),r().createElement("button",{className:"primary",onClick:t},"Update now")))},ko=({onClose:e})=>r().createElement(se,{open:!0,onClose:e},r().createElement("h1",null,"Updating"),r().createElement("section",{style:{display:"flex",justifyContent:"center",padding:"8px 0"}},r().createElement(N.CircularProgress,{size:32})),r().createElement("menu",null,r().createElement("button",{onClick:e},"Close"))),Lo=({onClose:e})=>r().createElement(se,{open:!0,onClose:e},r().createElement("h1",null,"Restart Dev instance"),r().createElement("section",null,r().createElement("p",null,"The update has been completed. To apply the changes, please restart this dev instance.")),r().createElement("menu",null,r().createElement("button",{onClick:e},"Close"))),_o=({onClose:e})=>r().createElement(se,{open:!0,onClose:e},r().createElement("h1",null,"Failed to update"),r().createElement("section",null,r().createElement("p",null,"Failed to update Link version. Please retry or ask to admin.")),r().createElement("menu",null,r().createElement("button",{onClick:e},"Close"))),Mo=S().div`
  position: absolute;
  bottom: 16px;
  left: 16px;
  width: 32px;
  height: 32px;

  .update-tooltip {
    position: absolute;
    top: -25px;
    left: -14px;
    display: none;
  }
  &.has-update .update-tooltip {
    display: block;
  }

  & > button {
    width: 100%;
    height: 100%;
    line-height: 100%;
    padding: 7px 10px;
    background-color: var(--link-background);
    border: 1px solid var(--border-primary);
    border-radius: 4px;
  }

  & > button:hover {
    background-color: var(--button-secondary-background-hover);
  }
`,So={"& div.MuiTooltip-tooltip[class]":{marginTop:"8px"}},No=()=>{const[e,t]=(0,a.useState)(!1),{isRunway:n,requiredToUpdateLink:l,openDialogToUpdateLink:o,DialogToUpdateLink:i}=wo(),s=()=>{t(!1)};(0,a.useEffect)((()=>{function t(t){const n=document.querySelector("#link-help-center"),a=t.target;e&&!(null==n?void 0:n.contains(a))&&s()}const n=document.body;return n.addEventListener("mousedown",t,!0),()=>{n.removeEventListener("mousedown",t,!0)}}),[e]);const c=e=>{s(),window.open(ra.origin+e,"_blank")};return r().createElement(Mo,{id:"link-help-center",className:e?"on":""},r().createElement(Se,{svg:'<svg width="71" height="25" viewBox="0 0 71 25" fill="none" xmlns="http://www.w3.org/2000/svg">\n<rect width="71" height="20" rx="4" fill="#FF0000"/>\n<path d="M12.7119 5.89062H13.9326V10.6416C13.9326 11.182 13.8154 11.6344 13.5811 11.999C13.3467 12.3636 13.0277 12.6387 12.624 12.8242C12.2236 13.0065 11.776 13.0977 11.2812 13.0977C10.7702 13.0977 10.3145 13.0065 9.91406 12.8242C9.51367 12.6387 9.19792 12.3636 8.9668 11.999C8.73893 11.6344 8.625 11.182 8.625 10.6416V5.89062H9.8457V10.6416C9.8457 10.9834 9.9043 11.265 10.0215 11.4863C10.1387 11.7044 10.3047 11.8656 10.5195 11.9697C10.7344 12.0739 10.9883 12.126 11.2812 12.126C11.5742 12.126 11.8265 12.0739 12.0381 11.9697C12.2529 11.8656 12.4189 11.7044 12.5361 11.4863C12.6533 11.265 12.7119 10.9834 12.7119 10.6416V5.89062ZM16.3301 8.73242V15.0312H15.1533V7.7168H16.2373L16.3301 8.73242ZM19.7725 10.3096V10.4121C19.7725 10.7962 19.7269 11.1527 19.6357 11.4814C19.5479 11.807 19.416 12.0918 19.2402 12.3359C19.0677 12.5768 18.8545 12.764 18.6006 12.8975C18.3467 13.0309 18.0537 13.0977 17.7217 13.0977C17.3929 13.0977 17.1048 13.0374 16.8574 12.917C16.6133 12.7933 16.4066 12.6191 16.2373 12.3945C16.068 12.1699 15.9313 11.9062 15.8271 11.6035C15.7262 11.2975 15.6546 10.9622 15.6123 10.5977V10.2021C15.6546 9.81478 15.7262 9.46322 15.8271 9.14746C15.9313 8.83171 16.068 8.5599 16.2373 8.33203C16.4066 8.10417 16.6133 7.92839 16.8574 7.80469C17.1016 7.68099 17.3864 7.61914 17.7119 7.61914C18.0439 7.61914 18.3385 7.68424 18.5957 7.81445C18.8529 7.94141 19.0693 8.1237 19.2451 8.36133C19.4209 8.5957 19.5527 8.87891 19.6406 9.21094C19.7285 9.53971 19.7725 9.90592 19.7725 10.3096ZM18.5957 10.4121V10.3096C18.5957 10.0654 18.5729 9.83919 18.5273 9.63086C18.4818 9.41927 18.4102 9.23372 18.3125 9.07422C18.2148 8.91471 18.0895 8.79102 17.9365 8.70312C17.7868 8.61198 17.6061 8.56641 17.3945 8.56641C17.1862 8.56641 17.0072 8.60221 16.8574 8.67383C16.7077 8.74219 16.5824 8.83822 16.4814 8.96191C16.3805 9.08561 16.3024 9.23047 16.2471 9.39648C16.1917 9.55924 16.1527 9.73665 16.1299 9.92871V10.876C16.1689 11.1104 16.2357 11.3252 16.3301 11.5205C16.4245 11.7158 16.5579 11.8721 16.7305 11.9893C16.9062 12.1032 17.1309 12.1602 17.4043 12.1602C17.6159 12.1602 17.7965 12.1146 17.9463 12.0234C18.096 11.9323 18.2181 11.807 18.3125 11.6475C18.4102 11.4847 18.4818 11.2975 18.5273 11.0859C18.5729 10.8743 18.5957 10.6497 18.5957 10.4121ZM23.9961 11.9062V5.5H25.1777V13H24.1084L23.9961 11.9062ZM20.5586 10.417V10.3145C20.5586 9.91406 20.6058 9.54948 20.7002 9.2207C20.7946 8.88867 20.9313 8.60384 21.1104 8.36621C21.2894 8.12533 21.5075 7.94141 21.7646 7.81445C22.0218 7.68424 22.3115 7.61914 22.6338 7.61914C22.9528 7.61914 23.2327 7.68099 23.4736 7.80469C23.7145 7.92839 23.9196 8.10579 24.0889 8.33691C24.2581 8.56478 24.3932 8.83822 24.4941 9.15723C24.5951 9.47298 24.6667 9.82454 24.709 10.2119V10.5391C24.6667 10.9167 24.5951 11.2617 24.4941 11.5742C24.3932 11.8867 24.2581 12.1569 24.0889 12.3848C23.9196 12.6126 23.7129 12.7884 23.4688 12.9121C23.2279 13.0358 22.9463 13.0977 22.624 13.0977C22.305 13.0977 22.0169 13.0309 21.7598 12.8975C21.5059 12.764 21.2894 12.5768 21.1104 12.3359C20.9313 12.0951 20.7946 11.8118 20.7002 11.4863C20.6058 11.1576 20.5586 10.8011 20.5586 10.417ZM21.7354 10.3145V10.417C21.7354 10.6579 21.7565 10.8825 21.7988 11.0908C21.8444 11.2992 21.9144 11.4831 22.0088 11.6426C22.1032 11.7988 22.2253 11.9225 22.375 12.0137C22.528 12.1016 22.7103 12.1455 22.9219 12.1455C23.1888 12.1455 23.4085 12.0869 23.5811 11.9697C23.7536 11.8525 23.8887 11.6947 23.9863 11.4961C24.0872 11.2943 24.1556 11.0697 24.1914 10.8223V9.93848C24.1719 9.74642 24.1312 9.56738 24.0693 9.40137C24.0107 9.23535 23.931 9.09049 23.8301 8.9668C23.7292 8.83984 23.6038 8.74219 23.4541 8.67383C23.3076 8.60221 23.1335 8.56641 22.9316 8.56641C22.7168 8.56641 22.5345 8.61198 22.3848 8.70312C22.235 8.79427 22.1113 8.9196 22.0137 9.0791C21.9193 9.23861 21.8493 9.42415 21.8037 9.63574C21.7581 9.84733 21.7354 10.0736 21.7354 10.3145ZM29.3867 11.9404V9.4209C29.3867 9.2321 29.3525 9.06934 29.2842 8.93262C29.2158 8.7959 29.1117 8.6901 28.9717 8.61523C28.835 8.54036 28.6624 8.50293 28.4541 8.50293C28.262 8.50293 28.096 8.53548 27.9561 8.60059C27.8161 8.66569 27.707 8.75358 27.6289 8.86426C27.5508 8.97493 27.5117 9.10026 27.5117 9.24023H26.3398C26.3398 9.0319 26.3903 8.83008 26.4912 8.63477C26.5921 8.43945 26.7386 8.2653 26.9307 8.1123C27.1227 7.95931 27.3522 7.83887 27.6191 7.75098C27.8861 7.66309 28.1855 7.61914 28.5176 7.61914C28.9147 7.61914 29.2663 7.68587 29.5723 7.81934C29.8815 7.9528 30.124 8.15462 30.2998 8.4248C30.4788 8.69173 30.5684 9.02702 30.5684 9.43066V11.7793C30.5684 12.0202 30.5846 12.2367 30.6172 12.4287C30.653 12.6175 30.7035 12.7819 30.7686 12.9219V13H29.5625C29.5072 12.873 29.4632 12.7119 29.4307 12.5166C29.4014 12.318 29.3867 12.126 29.3867 11.9404ZM29.5576 9.78711L29.5674 10.5146H28.7227C28.5046 10.5146 28.3125 10.5358 28.1465 10.5781C27.9805 10.6172 27.8421 10.6758 27.7314 10.7539C27.6208 10.832 27.5378 10.9264 27.4824 11.0371C27.4271 11.1478 27.3994 11.2731 27.3994 11.4131C27.3994 11.5531 27.432 11.6816 27.4971 11.7988C27.5622 11.9128 27.6566 12.0023 27.7803 12.0674C27.9072 12.1325 28.0602 12.165 28.2393 12.165C28.4801 12.165 28.6901 12.1162 28.8691 12.0186C29.0514 11.9176 29.1947 11.7956 29.2988 11.6523C29.403 11.5059 29.4583 11.3675 29.4648 11.2373L29.8457 11.7598C29.8066 11.8932 29.7399 12.0365 29.6455 12.1895C29.5511 12.3424 29.4274 12.4889 29.2744 12.6289C29.1247 12.7656 28.944 12.8779 28.7324 12.9658C28.5241 13.0537 28.2832 13.0977 28.0098 13.0977C27.6647 13.0977 27.3571 13.0293 27.0869 12.8926C26.8167 12.7526 26.6051 12.5654 26.4521 12.3311C26.2992 12.0934 26.2227 11.8249 26.2227 11.5254C26.2227 11.2454 26.2747 10.998 26.3789 10.7832C26.4863 10.5651 26.6426 10.3828 26.8477 10.2363C27.056 10.0898 27.3099 9.97917 27.6094 9.9043C27.9089 9.82617 28.2507 9.78711 28.6348 9.78711H29.5576ZM34.2207 7.7168V8.57617H31.2422V7.7168H34.2207ZM32.1016 6.42285H33.2783V11.54C33.2783 11.7028 33.3011 11.8281 33.3467 11.916C33.3955 12.0007 33.4622 12.0576 33.5469 12.0869C33.6315 12.1162 33.7308 12.1309 33.8447 12.1309C33.9261 12.1309 34.0042 12.126 34.0791 12.1162C34.154 12.1064 34.2142 12.0967 34.2598 12.0869L34.2646 12.9854C34.167 13.0146 34.0531 13.0407 33.9229 13.0635C33.7959 13.0863 33.6494 13.0977 33.4834 13.0977C33.2132 13.0977 32.974 13.0505 32.7656 12.9561C32.5573 12.8584 32.3945 12.7005 32.2773 12.4824C32.1602 12.2643 32.1016 11.9746 32.1016 11.6133V6.42285ZM37.458 13.0977C37.0674 13.0977 36.7142 13.0342 36.3984 12.9072C36.0859 12.777 35.819 12.5964 35.5977 12.3652C35.3796 12.1341 35.2119 11.8623 35.0947 11.5498C34.9775 11.2373 34.9189 10.9004 34.9189 10.5391V10.3438C34.9189 9.93034 34.9792 9.55599 35.0996 9.2207C35.2201 8.88542 35.3877 8.59896 35.6025 8.36133C35.8174 8.12044 36.0713 7.93652 36.3643 7.80957C36.6572 7.68262 36.9746 7.61914 37.3164 7.61914C37.694 7.61914 38.0244 7.68262 38.3076 7.80957C38.5908 7.93652 38.8252 8.11556 39.0107 8.34668C39.1995 8.57454 39.3395 8.84635 39.4307 9.16211C39.5251 9.47786 39.5723 9.82617 39.5723 10.207V10.71H35.4902V9.86523H38.4102V9.77246C38.4036 9.56087 38.3613 9.3623 38.2832 9.17676C38.2083 8.99121 38.0928 8.84147 37.9365 8.72754C37.7803 8.61361 37.5719 8.55664 37.3115 8.55664C37.1162 8.55664 36.9421 8.59896 36.7891 8.68359C36.6393 8.76497 36.514 8.88379 36.4131 9.04004C36.3122 9.19629 36.234 9.38509 36.1787 9.60645C36.1266 9.82454 36.1006 10.0703 36.1006 10.3438V10.5391C36.1006 10.7702 36.1315 10.985 36.1934 11.1836C36.2585 11.3789 36.3529 11.5498 36.4766 11.6963C36.6003 11.8428 36.75 11.9583 36.9258 12.043C37.1016 12.1243 37.3018 12.165 37.5264 12.165C37.8096 12.165 38.0618 12.1081 38.2832 11.9941C38.5046 11.8802 38.6966 11.7191 38.8594 11.5107L39.4795 12.1113C39.3656 12.2773 39.2174 12.4368 39.0352 12.5898C38.8529 12.7396 38.6299 12.8617 38.3662 12.9561C38.1058 13.0505 37.8031 13.0977 37.458 13.0977ZM48.7373 5.89062V13H47.5117L44.3232 7.90723V13H43.0977V5.89062H44.3232L47.5215 10.9932V5.89062H48.7373ZM49.8555 10.417V10.3047C49.8555 9.92383 49.9108 9.57064 50.0215 9.24512C50.1322 8.91634 50.2917 8.63151 50.5 8.39062C50.7116 8.14648 50.9688 7.95768 51.2715 7.82422C51.5775 7.6875 51.9225 7.61914 52.3066 7.61914C52.694 7.61914 53.0391 7.6875 53.3418 7.82422C53.6478 7.95768 53.9066 8.14648 54.1182 8.39062C54.3298 8.63151 54.4909 8.91634 54.6016 9.24512C54.7122 9.57064 54.7676 9.92383 54.7676 10.3047V10.417C54.7676 10.7979 54.7122 11.151 54.6016 11.4766C54.4909 11.8021 54.3298 12.0869 54.1182 12.3311C53.9066 12.5719 53.6494 12.7607 53.3467 12.8975C53.0439 13.0309 52.7005 13.0977 52.3164 13.0977C51.929 13.0977 51.5824 13.0309 51.2764 12.8975C50.9736 12.7607 50.7165 12.5719 50.5049 12.3311C50.2933 12.0869 50.1322 11.8021 50.0215 11.4766C49.9108 11.151 49.8555 10.7979 49.8555 10.417ZM51.0322 10.3047V10.417C51.0322 10.6546 51.0566 10.8792 51.1055 11.0908C51.1543 11.3024 51.2308 11.488 51.335 11.6475C51.4391 11.807 51.5726 11.9323 51.7354 12.0234C51.8981 12.1146 52.0918 12.1602 52.3164 12.1602C52.5345 12.1602 52.7233 12.1146 52.8828 12.0234C53.0456 11.9323 53.179 11.807 53.2832 11.6475C53.3874 11.488 53.4639 11.3024 53.5127 11.0908C53.5648 10.8792 53.5908 10.6546 53.5908 10.417V10.3047C53.5908 10.0703 53.5648 9.84896 53.5127 9.64062C53.4639 9.42904 53.3857 9.24186 53.2783 9.0791C53.1742 8.91634 53.0407 8.78939 52.8779 8.69824C52.7184 8.60384 52.528 8.55664 52.3066 8.55664C52.0853 8.55664 51.8932 8.60384 51.7305 8.69824C51.571 8.78939 51.4391 8.91634 51.335 9.0791C51.2308 9.24186 51.1543 9.42904 51.1055 9.64062C51.0566 9.84896 51.0322 10.0703 51.0322 10.3047ZM57.1895 11.8281L58.4102 7.7168H59.1621L58.957 8.94727L57.7266 13H57.0527L57.1895 11.8281ZM56.4717 7.7168L57.4238 11.8477L57.502 13H56.75L55.3193 7.7168H56.4717ZM60.3047 11.7988L61.2275 7.7168H62.375L60.9492 13H60.1973L60.3047 11.7988ZM59.2891 7.7168L60.4951 11.7793L60.6465 13H59.9727L58.7275 8.94238L58.5225 7.7168H59.2891Z" fill="white"/>\n<path d="M64.526 19L57.5979 25.0002L57.5978 19L64.526 19Z" fill="#FF0000"/>\n</svg>\n',className:"update-tooltip"}),r().createElement(Kt,{title:e?"":"Help center",describeChild:!0,placement:"bottom",sx:So},r().createElement("button",{onClick:n=>{e?s():t(!0)}},r().createElement(Eo,{show:!0===l}),r().createElement("svg",{width:"6",height:"12",viewBox:"0 -3 10 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M5.66602 11.459H3.66797C3.67513 10.7715 3.736 10.2093 3.85059 9.77246C3.97233 9.32845 4.16927 8.92383 4.44141 8.55859C4.71354 8.19336 5.0752 7.77799 5.52637 7.3125C5.85579 6.97591 6.15658 6.66081 6.42871 6.36719C6.70801 6.06641 6.93359 5.74414 7.10547 5.40039C7.27734 5.04948 7.36328 4.63053 7.36328 4.14355C7.36328 3.64941 7.27376 3.22331 7.09473 2.86523C6.92285 2.50716 6.66504 2.23145 6.32129 2.03809C5.9847 1.84473 5.56576 1.74805 5.06445 1.74805C4.64909 1.74805 4.25521 1.82324 3.88281 1.97363C3.51042 2.12402 3.20964 2.35677 2.98047 2.67188C2.7513 2.97982 2.63314 3.38444 2.62598 3.88574H0.638672C0.652995 3.0765 0.853516 2.38184 1.24023 1.80176C1.63411 1.22168 2.16406 0.777669 2.83008 0.469727C3.49609 0.161784 4.24089 0.0078125 5.06445 0.0078125C5.97396 0.0078125 6.7474 0.172526 7.38477 0.501953C8.0293 0.83138 8.51986 1.30404 8.85645 1.91992C9.19303 2.52865 9.36133 3.25195 9.36133 4.08984C9.36133 4.73438 9.22884 5.32878 8.96387 5.87305C8.70605 6.41016 8.37305 6.91504 7.96484 7.3877C7.55664 7.86035 7.12337 8.31152 6.66504 8.74121C6.27116 9.10645 6.00619 9.51823 5.87012 9.97656C5.73405 10.4349 5.66602 10.929 5.66602 11.459ZM3.58203 14.8643C3.58203 14.542 3.68229 14.2699 3.88281 14.0479C4.08333 13.8258 4.37337 13.7148 4.75293 13.7148C5.13965 13.7148 5.43327 13.8258 5.63379 14.0479C5.83431 14.2699 5.93457 14.542 5.93457 14.8643C5.93457 15.1722 5.83431 15.4372 5.63379 15.6592C5.43327 15.8812 5.13965 15.9922 4.75293 15.9922C4.37337 15.9922 4.08333 15.8812 3.88281 15.6592C3.68229 15.4372 3.58203 15.1722 3.58203 14.8643Z",fill:"var(--button-secondary-text)"})))),r().createElement(En,{open:e,dimension:{width:"182px",left:"0",bottom:"42px"},menus:[{icon:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<g clip-path="url(#clip0_8473_9627)">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M7.69922 4.76953C7.97536 4.76953 8.19922 4.99339 8.19922 5.26953V8.34937L10.5277 10.0637C10.75 10.2274 10.7976 10.5404 10.6339 10.7628C10.4701 10.9851 10.1572 11.0327 9.93478 10.869L7.40277 9.00479C7.27478 8.91055 7.19922 8.76108 7.19922 8.60215V5.26953C7.19922 4.99339 7.42308 4.76953 7.69922 4.76953Z" fill="var(--text-secondary)"/>\n<path d="M12.1307 3.45986L13.8301 1.76584V4.46581H11.1248L12.1302 3.46041L12.1307 3.45986Z" fill="var(--text-secondary)" stroke="var(--text-secondary)"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M7.96503 1.76953C4.56007 1.76953 1.7998 4.5298 1.7998 7.93476C1.7998 11.3397 4.56007 14.1 7.96503 14.1C11.37 14.1 14.1303 11.3397 14.1303 7.93476C14.1303 7.65862 14.3541 7.43476 14.6303 7.43476C14.9064 7.43476 15.1303 7.65862 15.1303 7.93476C15.1303 11.892 11.9223 15.1 7.96503 15.1C4.00779 15.1 0.799805 11.892 0.799805 7.93476C0.799805 3.97751 4.00779 0.769531 7.96503 0.769531C10.2377 0.769531 12.2634 1.82817 13.5753 3.47725C13.7472 3.69335 13.7114 4.0079 13.4953 4.17982C13.2792 4.35173 12.9646 4.31591 12.7927 4.0998C11.6624 2.67895 9.92007 1.76953 7.96503 1.76953Z" fill="var(--text-secondary)"/>\n<path d="M13 15.5C14.3807 15.5 15.5 14.3807 15.5 13C15.5 11.6193 14.3807 10.5 13 10.5C11.6193 10.5 10.5 11.6193 10.5 13C10.5 14.3807 11.6193 15.5 13 15.5Z" fill="#FF0000"/>\n</g>\n<defs>\n<clipPath id="clip0_8473_9627">\n<rect width="16" height="16" fill="white"/>\n</clipPath>\n</defs>\n</svg>\n',label:"Update Link",click:()=>{s(),o()},disabled:!l,hide:!n},{icon:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M8 3.875C8 3.875 6.96875 2.5 4.5625 2.5C2.15625 2.5 1.125 3.875 1.125 3.875V13.5C1.125 13.5 2.15625 12.8125 4.5625 12.8125C6.96875 12.8125 8 13.5 8 13.5M8 3.875V13.5M8 3.875C8 3.875 9.03125 2.5 11.4375 2.5C13.8438 2.5 14.875 3.875 14.875 3.875V13.5C14.875 13.5 13.8438 12.8125 11.4375 12.8125C9.03125 12.8125 8 13.5 8 13.5" stroke="var(--text-secondary)" stroke-linecap="round" stroke-linejoin="round"/>\n</svg>\n',label:"Link Documentation",click:()=>c("/guide/ml-development/dev-instances/link-layout-and-menu")},{icon:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M10.9092 7.64062L13.9999 7.64062L13.9999 2.00449L10.9092 2.00449L10.9092 7.64062ZM9.90918 7.84062C9.90918 8.28245 10.2674 8.64062 10.7092 8.64062L14.1999 8.64062C14.6418 8.64062 14.9999 8.28245 14.9999 7.84062L14.9999 1.80449C14.9999 1.36266 14.6418 1.00449 14.1999 1.00449L10.7092 1.00449C10.2674 1.00449 9.90918 1.36266 9.90918 1.80449L9.90918 7.84062Z" fill="var(--text-secondary)"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M10.9092 14L13.9999 14L13.9999 10.9092L10.9092 10.9092L10.9092 14ZM9.90918 14.2C9.90918 14.6418 10.2674 15 10.7092 15L14.1999 15C14.6418 15 14.9999 14.6418 14.9999 14.2L14.9999 10.7092C14.9999 10.2674 14.6418 9.90924 14.1999 9.90924L10.7092 9.90924C10.2674 9.90924 9.90918 10.2674 9.90918 10.7092L9.90918 14.2Z" fill="var(--text-secondary)"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M2 8.35937L7.63614 8.35937L7.63614 13.9955L2 13.9955L2 8.35937ZM1 8.15938C1 7.71755 1.35817 7.35937 1.8 7.35937L7.83614 7.35937C8.27796 7.35937 8.63614 7.71755 8.63614 8.15937L8.63614 14.1955C8.63614 14.6373 8.27797 14.9955 7.83614 14.9955L1.8 14.9955C1.35817 14.9955 1 14.6373 1 14.1955L1 8.15938Z" fill="var(--text-secondary)"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M2 2L7.63614 2L7.63614 5.09076L2 5.09076L2 2ZM1 1.8C1 1.35817 1.35817 1 1.8 1L7.83614 1C8.27796 1 8.63614 1.35817 8.63614 1.8L8.63614 5.29076C8.63614 5.73259 8.27797 6.09076 7.83614 6.09076L1.8 6.09076C1.35817 6.09076 1 5.73259 1 5.29076L1 1.8Z" fill="var(--text-secondary)"/>\n</svg>\n',label:"Tutorial",click:()=>c("/tutorial/pipeline-authoring")},{icon:'<svg width="12" height="12" viewBox="0 0 14 14" x="1" y="1" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M11.1118 8.18905L4.51199 7.20871C4.03795 7.13219 3.68774 6.69786 3.68774 6.18494V2.01332C3.68774 1.5004 4.03795 1.06607 4.51199 0.989544L11.1118 0.00920291C11.58 -0.0652534 11.9999 0.321506 11.9999 0.828222V7.37003C11.9999 7.87675 11.58 8.26351 11.1118 8.18905Z" fill="#6C79F9"/>\n<path d="M0.888097 3.81254L7.48787 4.79288C7.96191 4.86941 8.31212 5.30373 8.31212 5.81666V9.98828C8.31212 10.5012 7.96191 10.9355 7.48787 11.012L0.888097 11.9903C0.419863 12.0668 0 11.678 0 11.1734V4.62949C0 4.12277 0.419863 3.73602 0.888097 3.81047V3.81254Z" fill="#9578FF"/>\n<path d="M7.48802 4.79314L3.68604 4.22852V6.18713C3.68604 6.70005 4.03624 7.13438 4.51028 7.2109L8.31227 7.77553V5.81692C8.31227 5.30399 7.96206 4.86967 7.48802 4.79314Z" fill="#5D5DF4"/>\n</svg>\n',label:"About Link",click:()=>{s(),wt()}}]}),r().createElement(i,null))},Ao=S().div`
  position: absolute;
  bottom: 16px;
  left: 64px;
  height: 32px;

  button {
    border-style: solid;
    border-color: var(--border-primary);
    width: 32px;
    height: 32px;
    padding: 0;
    box-sizing: border-box;
    background-color: var(--background-base);
    border-radius: 0;
  }
  button:hover {
    background-color: var(--button-secondary-background-hover);
  }
  button:disabled:hover,
  button.disabled:hover {
    background-color: var(--background-base);
  }

  button.zoom-out {
    border-width: 1px 0 1px 1px;
    border-radius: 4px 0 0 4px;
  }

  button.zoom-in {
    border-width: 1px 0;
  }

  button.zoom-fit {
    border-width: 1px 1px 1px 0;
    border-radius: 0 4px 4px 0;
  }

  button:disabled svg,
  button.disabled svg {
    opacity: 0.3;
  }
`,Io=({graphRef:e,isExistComponent:t,scale:n})=>r().createElement(Ao,null,r().createElement(Kt,{title:t?"Zoom Out":"",describeChild:!0,placement:"bottom"},r().createElement("button",{className:"zoom-out"+(!t||n<=.1?" disabled":""),onClick:()=>{var t;null===(t=e.current)||void 0===t||t.zoomOut()}},r().createElement("svg",{width:"32",height:"32",viewBox:"0 0 36 36",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M23 18H18H13",stroke:"var(--button-secondary-text)",strokeWidth:"1.2",strokeLinecap:"round"})))),r().createElement(Kt,{title:t?"Zoom In":"",describeChild:!0,placement:"bottom"},r().createElement("button",{className:"zoom-in"+(!t||n>=1.25?" disabled":""),onClick:()=>{var t;null===(t=e.current)||void 0===t||t.zoomIn()}},r().createElement("svg",{width:"32",height:"32",viewBox:"0 0 36 36",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M18 23V18M18 18V13M18 18H23M18 18H13",stroke:"var(--button-secondary-text)",strokeWidth:"1.2",strokeLinecap:"round"})))),r().createElement(Kt,{title:t?"Auto Fit":"",describeChild:!0,placement:"bottom"},r().createElement("button",{className:"zoom-fit",onClick:()=>{var t;null===(t=e.current)||void 0===t||t.fitZoom()},disabled:!t},r().createElement("svg",{width:"32",height:"32",viewBox:"0 0 36 36",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("g",{stroke:"var(--button-secondary-text)",strokeLinecap:"round"},r().createElement("path",{d:"M15.6358 12.8013H14.2178H12.7998"}),r().createElement("path",{d:"M12.7998 15.6374V14.2193V12.8013"}),r().createElement("path",{d:"M16.1084 16.1101L14.5014 14.503L12.7998 12.8013"}),r().createElement("path",{d:"M12.7998 20.3643V21.7823V23.2004"}),r().createElement("path",{d:"M15.6358 23.2002H14.2178H12.7998"}),r().createElement("path",{d:"M16.1084 19.8921L14.4069 21.5938L12.7998 23.2009"}),r().createElement("path",{d:"M20.3623 23.2002H21.7803H23.1983"}),r().createElement("path",{d:"M23.1982 20.3643V21.7823V23.2004"}),r().createElement("path",{d:"M19.8896 19.8921L21.5912 21.5938L23.1983 23.2009"}),r().createElement("path",{d:"M23.1982 15.6374V14.2193V12.8013"}),r().createElement("path",{d:"M20.3623 12.8013H21.7803H23.1983"}),r().createElement("path",{d:"M19.8896 16.1101L21.5912 14.4084L23.1983 12.8013"}))))));var Oo=n(72205);const Po=(0,jt.observer)((({isSettingPanelOpened:e})=>{const[t,n]=(0,a.useState)(di.enabledSummary),[l,o]=(0,a.useState)(),[i,s]=(0,a.useState)(!1),c=()=>{h.get("mrx-link/info/cache").then((e=>{const t=function(e,t=0,n){const a=["Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"];if(void 0===e||0===e)return{value:0,unit:n?a[n]:a[1]};const r=t<0?0:t,l=Math.max(void 0!==n?n:Math.floor(Math.log(e)/Math.log(1024)),1);return{value:parseFloat((e/Math.pow(1024,l)).toFixed(r)),unit:a[l]}}(parseInt(e.data.cache_size.replace("B",""),10));o(`${t.value} ${t.unit}`)})).catch((e=>{u.error("Failed to load cache size")}))},d=()=>s(!1);return(0,a.useEffect)((()=>{di.connect(_t.CURRENT,(e=>{n(di.enabledSummary)})),c()}),[]),(0,a.useEffect)((()=>{e&&c()}),[e]),r().createElement(r().Fragment,null,r().createElement(To,{id:"link-setting-panel",className:(e?"on ":"")+"link-panel-setting-summary"},r().createElement("h2",null,"Settings"),r().createElement("div",{className:"contents-wrap"},r().createElement("div",null,r().createElement("h3",null,"Pipeline View"),r().createElement("div",{className:"content-box summary"},"Showing Component Summary",r().createElement(Fo,{checked:t,onChange:e=>{di.enabledSummary=e.target.checked,n(e.target.checked)},size:"small"})),r().createElement("p",null,"Hover over executed components to see included objects, functions, classes, and modules.")),r().createElement("div",null,r().createElement("h3",null,"Environments"),r().createElement("div",{className:"content-box environments"},"Run Component in Parallel",r().createElement(Fo,{checked:Ce.enableParallelProcessing,onChange:()=>Ce.toggleEnableParallelProcessing(),size:"small"})),r().createElement("p",null,"Recommended for large amounts of computational tasks."),r().createElement("div",{className:"content-box environments"},"Empty Cache Folder"),r().createElement("p",null,"Frees up ",r().createElement("b",null,l),". (It will also delete the cache data of all activated .ipynb files.)"),r().createElement("div",{className:"btn-wrap"},r().createElement("button",{type:"button",className:"empty-btn",onClick:()=>{h.post("mrx-link/cache/clear").then((e=>{const{data:t}=e;"Success"===t.message?(s(!0),c()):u.error(t.message)})).catch((e=>{u.error("Failed to empty cache folder successfully")}))}},"Empty Folder"))))),r().createElement(se,{open:i,onClose:d},r().createElement("h1",null,le,"Empty Cache Folder"),r().createElement("section",{className:"body"},r().createElement("p",null,"Successfully emptied cache folder. ",r().createElement("b",null,"Please restart JupyterLab for the changes to take effect."))),r().createElement(Qa,null,r().createElement("button",{type:"button",onClick:d},"Close"))))})),To=S().div`
  display: none;
  position: absolute;
  top: 4px;
  left: 151px;
  width: 232px;
  background-color: var(--background-base);
  padding: 20px 16px;
  border: 1px solid var(--border-primary);
  box-shadow: var(--popover-shadow);
  border-radius: 4px;
  color: var(--text-primary);

  &.on {
    display: block;
  }
  &.narrow {
    left: auto;
    right: 4px;
  }
  h2 {
    margin: 0;
    font-size: 13px;
    font-weight: 700;
  }
  .contents-wrap {
    margin-top: 20px;
    & > div {
      &:not(:last-child) {
        margin-bottom: 20px;
      }
      &:not(:first-of-type) {
        padding-top: 20px;
        border-top: 1px solid var(--border-primary);
      }
      & > h3 {
        margin: 0;
        font-weight: 500;
        font-size: 11px;
        color: var(--text-secondary);
      }
      .content-box {
        display: flex;
        justify-content: space-between;
        margin-top: 12px;
        font-weight: 500;
        font-size: 13px;
        color: var(--text-primary);
      }
      & > p {
        margin-top: 8px;
        font-weight: 400;
        font-size: 12px;
        color: var(--text-secondary);
      }
      .btn-wrap {
        display: flex;
        justify-content: end;
        margin-top: 12px;
        .empty-btn {
          font-weight: 500;
          font-size: 13px;
          line-height: 100%;
          padding: 6px 10px;
          border: 1px solid var(--border-primary);
          border-radius: 4px;
          color: var(--text-secondary);
          background-color: var(--background-base);
        }
        .empty-btn:hover {
          background-color: var(--background-surface);
        }
      }
    }
  }
`,Fo=(0,N.styled)(Oo.A)((({theme:e})=>({width:28,height:16,padding:0,display:"flex",marginLeft:10,fontWeight:"bold","&:active":{"& .MuiSwitch-thumb":{width:15},"& .MuiSwitch-switchBase.Mui-checked":{transform:"translateX(9px)"}},"& .MuiSwitch-switchBase":{padding:2,"&.Mui-checked":{color:"#fff",transform:"translateX(12px)","& + .MuiSwitch-track":{backgroundColor:"var(--link-color)",opacity:1}}},"& .MuiSwitch-thumb":{width:12,height:12,borderRadius:6,boxShadow:"0 2px 4px 0 rgb(0 35 11 / 20%)",transition:e.transitions.create(["width"],{duration:200})},"& .MuiSwitch-track":{boxSizing:"border-box",borderRadius:8,backgroundColor:"var(--control-switch-background)",opacity:1}}))),Vo=Po,Ho=S().button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  box-sizing: border-box;
  width: auto;
  height: 27px;
  padding: 0 12px;
  font-weight: 500;
  font-size: 13px;
  line-height: 15px;
  border-radius: 5px;
  border: 1px solid var(--link-color);
  color: var(--button-link-text);
  background-color: var(--link-color);
`,Ro={badinput:"badInput",patternmismatch:"patternMismatch",rangeoverflow:"rangeOverflow",rangeunderflow:"rangeUnderflow",stepmismatch:"stepMismatch",toolong:"tooLong",tooshort:"tooShort",typemismatch:"typeMismatch",valuemissing:"valueMissing"};function zo(e){const t=e.target;t.classList.contains("invalid")||t.classList.contains("visited")?(t.customValidate&&t.setCustomValidity(t.customValidate(t)),Zo(t,t.checkValidity()),jo(t.form)):jo(t.form)}function Zo(e,t){const n=document.getElementById(`${e.dataset.validate}`);n&&(t?(e.classList.remove("invalid"),n.innerHTML="",n.classList.remove("on")):(e.classList.add("invalid"),n.innerHTML=function(e,t){for(const n in t.dataset){if(e.validity.customError)return e.validationMessage;if(e.validity[Ro[n]])return t.dataset[n]}return t.dataset.default||"Invalid input."}(e,n),n.classList.add("on")))}function Bo(e){e.target.classList.add("visited"),zo(e)}function jo(e){!0===e.setFormState&&(e.checkValidity()?e.classList.remove("invalid"):e.classList.add("invalid"))}const Do=(0,jt.observer)((({close:e,editItem:t})=>{const n=(0,a.useRef)(null),[l,o]=(0,a.useState)(!1),[i,s]=(0,a.useState)(!1);(0,a.useEffect)((()=>{n.current&&(n.current.queue.invalidValue=[],n.current.storage.invalidValue=[],function(e,t){e.setFormState=t.setFormState,jo(e);for(const n of e)n.dataset.validate&&(n.onblur=Bo,n.oninput=zo,n.oninvalid=e=>{e.preventDefault(),Zo(n,!1)},t&&t.customValidate&&(n.customValidate=t.customValidate[n.name]))}(n.current,{customValidate:{servername:e=>{const n=Ce.remoteServers.find((n=>e.value!==t&&n.servername===e.value));return void 0!==n?"This server name already exists.":""},queue:e=>e.invalidValue.indexOf(e.value)>-1?"Connection Failed(Check server address).":"",storage:e=>e.invalidValue.indexOf(e.value)>-1?"Connection Failed(Check server address).":""}}))}),[]),(0,a.useEffect)((()=>{if(!i)return;const e=window.setTimeout((()=>{var e,t;i&&(o(!0),null===(t=null===(e=di.currentWidget)||void 0===e?void 0:e.kernel)||void 0===t||t.interrupt(),s(!1))}),3e3);return()=>window.clearTimeout(e)}),[i]);const c=Ce.remoteServers.find((e=>e.servername===t));return r().createElement(Wo,{ref:n,onSubmit:async a=>{if(a.preventDefault(),!n.current)return;if(i)return;s(!0),o(!1);const r=n.current.servername.value,l=n.current.queue.value,c=n.current.storage.value;if(t){const n=await function(e,t,n,a){return Bt(`%mrxlink_remote_update_config -n ${e} -d ${a} -m ${n}${e!==t?` -u ${t}`:""}`)}(t,r,l,c);if(n){const n=Ce.remoteServers.findIndex((e=>e.servername===t));Ce.remoteServers[n]={servername:r,queue:l,storage:c,components:Ce.remoteServers[n].components},Ce.remoteServers=[...Ce.remoteServers],e()}}else{const t=await function(e,t,n){return Bt(`%mrxlink_remote_save_config -n ${e} -d ${n} -m ${t}`)}(r,l,c);t&&(Ce.remoteServers=[{servername:r,queue:l,storage:c,components:[]},...Ce.remoteServers],e())}s(!1)}},r().createElement("div",{className:"form-control servername"},r().createElement("label",null,r().createElement("span",{className:"label"},"Server Name"),r().createElement("input",{type:"text",name:"servername",defaultValue:null==c?void 0:c.servername,required:!0,placeholder:"Enter a server name",maxLength:100,pattern:"[a-zA-Z0-9\\-_]+","data-validate":"link-remote-servername-error"+(t?`-${t}`:"")})),r().createElement("p",{id:"link-remote-servername-error"+(t?`-${t}`:""),className:"error-message","data-valueMissing":"Required","data-patternMismatch":"Invalid(English letters, numbers, ‘-’, ‘_’ only)"})),r().createElement("div",{className:"form-control queue"},r().createElement("label",null,r().createElement("span",{className:"label"},"Message Queue Server"),r().createElement("input",{type:"url",name:"queue",defaultValue:null==c?void 0:c.queue,required:!0,placeholder:"redis://localhost:6379","data-validate":"link-remote-queue-error"+(t?`-${t}`:"")})),r().createElement("p",{id:"link-remote-queue-error"+(t?`-${t}`:""),className:"error-message","data-valueMissing":"Required","data-typeMismatch":"Invalid URL"})),r().createElement("div",{className:"form-control storage"},r().createElement("label",null,r().createElement("span",{className:"label"},"Data Storage Server"),r().createElement("input",{type:"url",name:"storage",defaultValue:null==c?void 0:c.storage,required:!0,placeholder:"redis://localhost:6379",maxLength:100,"data-validate":"link-remote-storage-error"+(t?`-${t}`:"")})),r().createElement("p",{id:"link-remote-storage-error"+(t?`-${t}`:""),className:"error-message","data-valueMissing":"Required","data-typeMismatch":"Invalid URL"})),l&&r().createElement("p",{className:"connection-error"},r().createElement("svg",{width:"12",height:"13",viewBox:"0 0 12 13",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M6 0.5C2.7 0.5 0 3.2 0 6.5C0 9.8 2.7 12.5 6 12.5C9.3 12.5 12 9.8 12 6.5C12 3.2 9.3 0.5 6 0.5ZM5.64 3.44H6.36C6.54 3.44 6.66 3.56 6.66 3.74L6.54 7.46C6.54 7.64 6.42 7.76 6.24 7.76H5.76C5.58 7.76 5.46 7.64 5.46 7.46L5.34 3.74C5.34 3.56 5.46 3.44 5.64 3.44ZM6.48 9.56C6.36 9.68 6.18 9.74 6 9.74C5.82 9.74 5.64 9.68 5.52 9.56C5.4 9.44 5.34 9.26 5.34 9.08C5.34 8.9 5.4 8.72 5.52 8.6C5.64 8.48 5.82 8.42 6 8.42C6.18 8.42 6.36 8.48 6.48 8.6C6.6 8.72 6.66 8.9 6.66 9.08C6.72 9.32 6.66 9.44 6.48 9.56Z",fill:"#C55B5F"})),"Connection Failed"),r().createElement(Qa,{className:"even"},r().createElement("button",{type:"button",onClick:e},"Close"),r().createElement("button",{className:"primary"},i?Ie:"Save")))})),Wo=S().form`
  margin: 0;

  .form-control {
    margin: 12px 0 0;
  }
  .form-control:first-of-type {
    margin-top: 0;
  }

  .label {
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
    color: var(--text-secondary);
  }

  input[type='text'],
  input[type='url'] {
    background-color: transparent;
    border: 1px solid var(--border-primary);
    padding: 6px 12px;
    color: var(--text-primary);
    display: block;
    box-sizing: border-box;
    width: 100%;
    margin-top: 4px;
  }

  .error-message {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAP1BMVEUAAAD0Qzb0Qzb0Qzb0Qzb0Qzb1QTf3RDP2QDf0QzbzRDX0Qzb0Qzb0Qzb1Qzb0Qjf0Qzb0Qzf0Qzb/TTP0QzZZ+DEfAAAAFHRSTlMA5bjxpHZKHhy8acbv39zXz6iKCkABVjAAAACWSURBVCjPfZJZDsMwCEQfNI6dfeP+Z61URZg2Td6XR/JgD8BJTipmoikTKY05TcFpXxZ4tZz09kN/3rcLH0/xOiJerQD+bged/wCy+xXURSbZP4elcGmAIdjFzyusLgRzFliqooaeYKrxkeD+EmrOvpujpCrG0ZwUAs7HMYeANCGH1pbEJm5bbeJd258HdR3t4zLcrs8bSbYfLgXYsgcAAAAASUVORK5CYII=);
    background-repeat: no-repeat;
    background-size: 12px 12px;
    background-position: 0 50%;
    padding-left: 17px;
    font-weight: 400;
    font-size: 10px;
    line-height: 12px;
    color: var(--feedback-fail);
    margin: 4px 0 0;
    display: none;
  }
  .error-message.on {
    display: block;
  }

  .connection-error {
    background: var(--section-message-error-background);
    border-radius: 4px;
    padding: 8px 12px;
    margin: 12px 0;
    font-weight: 500;
    font-size: 13px;
    line-height: 15px;
    color: var(--text-primary);
  }

  .connection-error svg {
    margin: 0 4px -2px 0;
  }

  .even {
    display: flex;
    align-content: stretch;
    margin-top: 12px;
  }

  .even button + button {
    margin-left: 8px;
  }

  .even button svg {
    margin-right: 0;
  }

  .even button svg circle {
    stroke: #fff;
  }
`,Uo=Do,$o=S().section`
  position: absolute;
  z-index: 2;
  top: 43px;
  right: 0;
  bottom: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.3);

  .wrap {
    padding: 12px 16px;
    background: var(--background-base);
    border-bottom: 1px solid var(--border-primary);
  }

  h3 {
    font-weight: 700;
    font-size: 13px;
    line-height: 15px;
    margin: 0 0 12px;
  }
`,Go=({close:e})=>r().createElement($o,null,r().createElement("div",{className:"wrap"},r().createElement("h3",null,"Add Remote Server"),r().createElement(Uo,{close:e}))),qo=S().button`
  display: flex;
  align-items: center;
  padding: 0px;
  border: none;

  background: transparent;

  .svg-icon {
    display: flex;
    align-items: center;
  }
`,Ko=(0,jt.observer)((()=>{var e,t;const n=pe.getKernelComponents(null===(t=null===(e=null==di?void 0:di.currentWidget)||void 0===e?void 0:e.kernel)||void 0===t?void 0:t.id),[l,o]=(0,a.useState)(""),i=async(e,t,a)=>{const r=Ce.remoteServers.findIndex((t=>t.servername===e.servername)),l=c(e).map((e=>e.id)).filter((e=>Ce.remoteServers[r].components.indexOf(e)>-1)),[o,i]=s(l,a.map((e=>e.id))),d=await Promise.all([...o.map((t=>Bt(`%mrxlink_remote_add_component -n ${e.servername} -i ${t}`))),...i.map((t=>Bt(`%mrxlink_remote_remove_component -n ${e.servername} -i ${t}`)))]);d&&(Ce.remoteServers[r].components=[...Ce.remoteServers[r].components.filter((e=>-1===Object.keys(n).indexOf(e))),...a.map((e=>e.id))],Ce.remoteServers=[...Ce.remoteServers])},s=(e,t)=>{const n=e,a=[];for(const e of t){const t=n.findIndex((t=>t===e));-1===t&&a.push(e),n.splice(t,1)}return[a,n]},c=e=>{const t=Ce.remoteServers.filter((t=>t.servername!==e.servername)).reduce(((e,t)=>[...e,...t.components]),[]);return Object.keys(n).map((e=>({id:e,name:n[e].name}))).filter((e=>void 0===t.find((t=>t===e.id))))},d=e=>{const t=c(e),n={id:-1,action:r().createElement("button",{onClick:i.bind(null,e,null,t)},"+ All Components")};return 0===t.length?[]:[n,...t]},p=e=>Object.keys(n).filter((t=>e.components.indexOf(t)>-1)).map((e=>({id:e})));return r().createElement(Yo,null,Ce.remoteServers.map((e=>r().createElement("li",{key:e.servername},l===e.servername?r().createElement(Uo,{close:()=>o(""),editItem:l}):r().createElement(r().Fragment,null,r().createElement("h3",null,e.servername),r().createElement("h4",null,"Message Queue Server"),r().createElement("p",null,e.queue),r().createElement("h4",null,"Data Storage Server"),r().createElement("p",null,e.storage),r().createElement("div",{className:"buttons"},r().createElement(Kt,{title:"Edit",describeChild:!0,placement:"bottom-start"},r().createElement(qo,{onClick:()=>{return t=e.servername,void o(t);var t}},r().createElement(Se,{svg:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill-rule="evenodd" clip-rule="evenodd" d="M11.2012 7.3241L8.67804 4.80096L3.25329 10.2257L3.00098 12.4965V12.6227C3.00098 12.875 3.25329 13.0012 3.5056 13.0012L5.77643 12.7489L11.2012 7.3241Z" fill="var(--link-comment-icon-fill-color)"/>\n<path d="M12.8343 4.42169L11.6989 3.28627C11.5145 3.10292 11.2651 3 11.0051 3C10.745 3 10.4956 3.10292 10.3112 3.28627L9.17578 4.42169L11.6989 6.94483L12.8343 5.80941C13.0177 5.62503 13.1206 5.37558 13.1206 5.11555C13.1206 4.85552 13.0177 4.60607 12.8343 4.42169Z" fill="var(--link-comment-icon-fill-color)"/>\n</svg>\n',className:"svg-icon"}))),r().createElement(Kt,{title:"Remove",describeChild:!0,placement:"bottom-start"},r().createElement(qo,{onClick:()=>{return t=e.servername,void function(e,t,n="Warn",a){new $.Dialog({title:e,body:t,buttons:[$.Dialog.cancelButton({label:"Cancel"}),$.Dialog.warnButton({label:n})],hasClose:!1}).launch().then((e=>{e.button.label===n&&a()}))}("Remove Server Content","Are you sure to remove this server?","Remove",(async()=>{var e;await(e=t,Bt(`%mrxlink_remote_remove_config -n ${e}`))&&(Ce.remoteServers=Ce.remoteServers.filter((e=>e.servername!==t)))}));var t}},r().createElement(Se,{svg:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path fill="var(--link-comment-icon-fill-color)" d="M9.62598 4.25H11.501C11.876 4.25 12.126 4.5 12.126 4.875V5.5H4.00098V4.875C4.00098 4.5 4.31348 4.25 4.62598 4.25H6.50098C6.62598 3.5625 7.31348 3 8.06348 3C8.81348 3 9.50098 3.5625 9.62598 4.25ZM7.12598 4.25H9.00098C8.87598 3.875 8.43848 3.625 8.06348 3.625C7.68848 3.625 7.25098 3.875 7.12598 4.25ZM4.62598 6.125H11.501L10.9385 12.4375C10.9385 12.75 10.626 13 10.3135 13H5.81348C5.50098 13 5.25098 12.75 5.18848 12.4375L4.62598 6.125Z"/>\n</svg>\n',className:"svg-icon"}))))),r().createElement(pn,{className:"form-control"},r().createElement(vn,{label:"Execution Components",options:d(e),value:p(e),onChange:i.bind(null,e),placeholder:"Select components"}))))))})),Yo=S().ul`
  margin: 0;
  padding: 0;
  list-style: none;
  color: var(--text-primary);
  height: calc(100% - 42px);
  overflow: auto;

  li {
    position: relative;
    padding: 16px 12px;
    background: var(--background-base);
    border-bottom: 1px solid var(--border-primary);
  }
  li + li {
    margin-top: 6px;
  }

  h3 {
    font-weight: 500;
    font-size: 13px;
    line-height: 15px;
    margin: 0 44px 0 0;
    word-wrap: break-word;
  }

  h4 {
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
    margin: 13px 0 5px;
    color: var(--text-detail);
  }

  p {
    font-weight: 400;
    font-size: 13px;
    line-height: 15px;
    margin: 0;
    color: var(--text-secondary);
    word-wrap: break-word;
  }

  .buttons {
    position: absolute;
    top: 16px;
    right: 8px;
    display: flex;
    gap: 8px;
    align-items: center;
    justify-content: flex-end;
  }

  .form-control {
    margin-top: 18px;
  }

  .form-control .MuiFormLabel-root,
  .form-control .Mui-focused .MuiFormLabel-root {
    font-weight: 500;
    font-size: 11px;
    line-height: 13px;
    color: var(--text-secondary);
    margin-bottom: 8px;
  }
`,Xo=Ko,Jo=(0,jt.observer)((({close:e})=>{const[t,n]=(0,a.useState)(!1);return r().createElement(ka,{icon:r().createElement(Se,{svg:hl}),title:"Remote Resources",guideLink:ra.origin+"/guide/ml-development/dev-instances/run-a-link-pipeline",close:e},r().createElement(Qo,null,r().createElement("header",null,r().createElement("h2",null,"Remote Servers"),r().createElement(Ho,{onClick:()=>{n(!t)}},ei," Add")),t&&r().createElement(Go,{close:()=>n(!1)}),0===Ce.remoteServers.length?r().createElement("section",{className:"no-server"},r().createElement("h3",null,"No Remote Servers"),r().createElement("p",null,"Please add a remote server for running pipeline components")):r().createElement(Xo,null)))})),Qo=S().section`
  position: relative;
  height: 100%;
  color: var(--text-primary);
  background: var(--background-surface);

  header {
    background: var(--background-base);
    padding: 7px 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid var(--border-primary);
  }

  h2 {
    font-weight: 700;
    font-size: 13px;
    line-height: 15px;
    margin: 0;
  }

  .no-server {
    height: calc(100% - 43px);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
    font-size: 13px;
  }

  .no-server h3 {
    font-weight: 700;
    line-height: 15px;
    margin: 0 0 8px;
    color: var(--text-secondary);
  }

  .no-server p {
    font-weight: 400;
    line-height: 18px;
    margin: 0 12px;
    color: var(--text-detail);
  }
`,ei=r().createElement("svg",{width:"15",height:"11",viewBox:"0 0 15 11",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{d:"M7.72266 2.52522C7.72266 2.07982 8.08373 1.71875 8.52913 1.71875V1.71875C8.97453 1.71875 9.3356 2.07982 9.3356 2.52522V2.52522C9.3356 2.97062 8.97453 3.33169 8.52913 3.33169V3.33169C8.08373 3.33169 7.72266 2.97062 7.72266 2.52522V2.52522Z",fill:"white"}),r().createElement("path",{d:"M9.74023 2.52522C9.74023 2.07982 10.1013 1.71875 10.5467 1.71875V1.71875C10.9921 1.71875 11.3532 2.07982 11.3532 2.52522V2.52522C11.3532 2.97062 10.9921 3.33169 10.5467 3.33169V3.33169C10.1013 3.33169 9.74023 2.97062 9.74023 2.52522V2.52522Z",fill:"white"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M11.8337 4.56641C12.1045 4.56641 12.3241 4.78599 12.3241 5.05686V7.24163H14.5089C14.7798 7.24163 14.9993 7.46122 14.9993 7.73209C14.9993 8.00296 14.7798 8.22255 14.5089 8.22255H12.3241V10.4073C12.3241 10.6782 12.1045 10.8978 11.8337 10.8978C11.5628 10.8978 11.3432 10.6782 11.3432 10.4073V8.22255H9.15843C8.88755 8.22255 8.66797 8.00296 8.66797 7.73209C8.66797 7.46122 8.88755 7.24163 9.15843 7.24163H11.3432V5.05686C11.3432 4.78599 11.5628 4.56641 11.8337 4.56641Z",fill:"white"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10.1362 5.75391H1.46484C0.912559 5.75391 0.464844 6.20162 0.464844 6.75391V9.59273C0.464844 10.145 0.912559 10.5927 1.46484 10.5927H10.2961C10.1935 10.4333 10.1362 10.23 10.1362 9.97236V9.64273H1.46484C1.43723 9.64273 1.41484 9.62035 1.41484 9.59273V6.75391C1.41484 6.72629 1.43723 6.70391 1.46484 6.70391H7.86736C8.17888 6.3865 8.64211 6.20802 9.15935 6.20802H10.1362V5.75391ZM11.3441 9.64273V10.4082C11.3441 10.4735 11.3569 10.5358 11.38 10.5927H12.2892C12.3123 10.5358 12.325 10.4735 12.325 10.4082V9.64273H11.3441ZM12.4184 8.22348H13.3684V7.24256H12.4184V8.22348ZM12.325 6.70391H11.3441V5.75391H12.325V6.70391Z",fill:"white"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M1.46484 1.05547H12.3684C12.396 1.05547 12.4184 1.07785 12.4184 1.10547V3.46237C12.8059 3.6042 13.1273 3.88317 13.3238 4.2405C13.3528 4.1469 13.3684 4.04742 13.3684 3.94429V1.10547C13.3684 0.553184 12.9207 0.105469 12.3684 0.105469H1.46484C0.912559 0.105469 0.464844 0.553185 0.464844 1.10547V3.94429C0.464844 4.49658 0.912559 4.94429 1.46484 4.94429H10.1399C10.1635 4.58585 10.2984 4.25779 10.5103 3.99429H1.46484C1.43723 3.99429 1.41484 3.97191 1.41484 3.94429V1.10547C1.41484 1.07785 1.43723 1.05547 1.46484 1.05547ZM12.3118 4.94429H11.3573C11.4085 4.72815 11.6028 4.56733 11.8346 4.56733C12.0664 4.56733 12.2606 4.72815 12.3118 4.94429Z",fill:"white"})),ti=Jo,ni=(0,jt.observer)((0,_.x)((e=>{var t,n,l;const[o,i]=(0,a.useState)(!1),[s,c]=(0,a.useState)(300),[d,p]=(0,a.useState)(1),[m,u]=(0,a.useState)(!1),[h,g]=(0,a.useState)(!1),[v,f]=(0,a.useState)(0),[x,b]=(0,a.useState)(!0),[C,E]=(0,a.useState)(!1),w=(0,a.useRef)(),[y,k]=(0,a.useState)([]),L=pe.getKernelComponents(null===(n=null===(t=null==di?void 0:di.currentWidget)||void 0===t?void 0:t.kernel)||void 0===n?void 0:n.id),_=(0,a.useRef)(new MutationObserver((e=>{e.forEach((e=>{const t=e.target;if("class"===e.attributeName){const e=t.className.includes("lm-mod-hidden");i(!e)}if("style"===e.attributeName){const e=+t.style.width.replace("px","");c(e)}}))}))),M=(0,a.useCallback)((()=>{var e;const t=null===(e=di.currentWidget)||void 0===e?void 0:e.metadata.parameters;f(t?t.length:0)}),[]),S=(0,a.useCallback)((e=>{f(e.parameters.length)}),[]),N=(0,a.useCallback)((e=>{Ce.enableData.pipelineImport=!!e,u(!1),e?(b(e.cells.isExistComponent),M(),e.metadata.connect(kt.PARAMS,S),e.connect(Mt.COMPONENT_CHANGE,(()=>{var e;di.currentWidget&&b(null===(e=di.currentWidget)||void 0===e?void 0:e.cells.isExistComponent)}))):b(!1)}),[it.value]),A=(0,a.useCallback)((e=>{var t;e&&(null===(t=null==e?void 0:e._hsplitPanel)||void 0===t||t.setRelativeSizes(y),k([]))}),[y]),I=(0,a.useCallback)((e=>{var t,n;if(!e)return;const a=null===(t=null==e?void 0:e._hsplitPanel)||void 0===t?void 0:t.relativeSizes(),r=a[0],l=a[1],o=a[2];null===(n=null==e?void 0:e._hsplitPanel)||void 0===n||n.setRelativeSizes([r+450/document.documentElement.clientWidth,l,o])}),[y]),O=e=>{N(e),Da.close()};(0,a.useEffect)((()=>{ke.setUpdatePipelinePanelKernel((()=>{P()}));const e=document.querySelector("#canvas-pipeline-extension");return e&&_.current.observe(e,{attributes:!0}),void 0!==di.currentWidget&&O(di.currentWidget),di.connect(_t.CURRENT,O),()=>{_.current.disconnect()}}),[]);const P=(0,a.useCallback)((()=>{if(!ke.ws||ke.ws.readyState!==ke.ws.OPEN)return;const e={procedure:"kernel:info",msg:{kernel_id:dt.value}};try{ke.ws.send(JSON.stringify(e))}catch(e){console.error("Failed to set kernel ID.")}}),[]),T=(0,a.useCallback)((e=>{const t=Object.values(e),n=t.length>0,a=t.every((e=>"successful"===e.execution_status));Ce.enableData.pipeline=n&&a,Ce.enableData.cacheImport=n;const r=t.some((e=>"cached"===e.diskcache_status)),l=t.some((e=>"updating"===e.diskcache_status)),o=t.some((e=>!0===e.metadata.diskcache&&"running"===e.execution_status));Ce.enableData.cacheExport=n&&r&&!l&&!o}),[]),F=(0,a.useCallback)((()=>{var t;me.checkCodeExecutable(null===(t=di.currentWidget)||void 0===t?void 0:t.kernel)&&(g(!0),e.lab.commands.execute(Rt.runAll).then((e=>{g(!1)})).catch((e=>{g(!1),console.error("run all. error="+e)})))}),[]),V=(0,a.useCallback)((()=>{u((e=>!e))}),[]);(0,a.useEffect)((()=>{(e=>{var t;T(e),M(),0===Object.keys(e).length&&Da.close(),null===(t=di.currentWidget)||void 0===t||t.emitComponentChange()})(L)}),[L]),(0,a.useEffect)((()=>{m&&Da.close()}),[m]),(0,a.useEffect)((()=>{var t,n;Da.visible||A(e.shell),Da.visible&&(k(null===(n=null===(t=e.shell)||void 0===t?void 0:t._hsplitPanel)||void 0===n?void 0:n.relativeSizes()),I(e.shell),u(!1))}),[Da.visible]),(0,a.useEffect)((()=>{C&&(Da.close(),u(!1))}),[C]);const H=()=>{"header-color"===Da.type&&Da.close()};(0,a.useEffect)((()=>{P()}),[dt.value]),(0,a.useEffect)((()=>{!async function e(){var t;function n(){window.setTimeout(e,300)}const a=await(null===(t=Bt("%mrxlink_remote_load_config"))||void 0===t?void 0:t.catch(n));void 0===a?n():Ce.remoteServers=Object.entries(a).map((e=>({servername:e[0],queue:e[1].broker,storage:e[1].backend,components:e[1].components})))}()}),[]);const R=()=>{let e="No Pipelines",t="Open a notebook file and create your pipeline.";return void 0===it.value&&(e="No notebook selected",t="Please select a notebook from the notebook panel."),{title:e,description:t}};return r().createElement(r().Fragment,null,r().createElement(Wa,{className:"pipeline-panel-container"},r().createElement(Gl,{lab:e.lab,title:pt.value&&st.value?st.value:"PIPELINE PANEL",showHeader:pt.value,onRunAll:F,isRunning:h,onToggleHeaderColor:()=>{Da.visible&&"header-color"===Da.type?Da.close():Da.open("header-color")},closeHeaderColorSubPanel:H,toggleSetting:()=>{E((e=>!e))},isExistComponent:x,panelWidth:s,onToggleRemote:()=>{Da.visible&&"remote"===Da.type?Da.close():Da.open("remote")},isSettingPanelOpened:C,setIsSettingPanelOpened:E,isParameterOpen:m,toggleParameter:V,paramCount:v,tracker:e.tracker}),m&&pt.value&&r().createElement(il,{commands:e.commands,tracker:e.tracker,notebook:e.notebook,afterCancel:V}),r().createElement("div",{className:"graph-container","data-jp-suppress-context-menu":!0,onContextMenu:t=>{if(!di.currentWidget)return;t.preventDefault();const n=new J.Menu({commands:e.lab.commands});!function(e,t,n){e.forEach((e=>{"separator"===e?t.addItem({type:"separator"}):t.addItem({command:e,args:n})}))}([Rt.linkExport,Rt.linkImport,Rt.separator,Rt.canvasExport,Rt.canvasImport,Rt.separator,Rt.exportPY,Rt.separator,Rt.cacheExport,Rt.cacheImport,Rt.separator,Rt.clearPipeline],n,{isNode:!1}),n.open(t.clientX,t.clientY)}},r().createElement("div",{className:"graph-container-loading"},r().createElement("div",{className:pt.value&&x?"visible":"hidden"},r().createElement(Co,{ref:w,lab:e.lab,tracker:e.tracker,kernelId:dt.value,isPanelVisible:o,onScaleChange:p})),dt.value&&!0!==(null===(l=mt.value[dt.value])||void 0===l?void 0:l.magicCommandLoaded)?r().createElement(Ya,null,Ie):!(pt.value&&x)&&r().createElement($a,null,r().createElement("div",{className:"panel-empty-image"},r().createElement("div",null,r().createElement(Se,{svg:'<svg width="102" height="100" viewBox="0 0 102 94" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path opacity="0.5" d="M25.3247 20.4805V26.4384C25.3247 28.123 25.3247 28.9652 25.6525 29.6087C25.9409 30.1746 26.401 30.6347 26.967 30.9231C27.6104 31.2509 28.4527 31.2509 30.1372 31.2509H42.2177C43.9022 31.2509 44.7445 31.2509 45.3879 31.5788C45.9538 31.8672 46.414 32.3273 46.7023 32.8932C47.0302 33.5367 47.0302 34.3789 47.0302 36.0634V42.2748M50.805 60.8988L50.8024 78.1409M76.2854 20.4805V26.4384C76.2854 28.123 76.2854 28.9652 75.9575 29.6087C75.6692 30.1746 75.209 30.6347 74.6431 30.9231C73.9997 31.2509 73.1574 31.2509 71.4729 31.2509H59.3924C57.7079 31.2509 56.8656 31.2509 56.2222 31.5788C55.6562 31.8672 55.1961 32.3273 54.9077 32.8932C54.5799 33.5367 54.5799 34.3789 54.5799 36.0634V42.2748" stroke="#999999" stroke-width="2" stroke-linecap="square"/>\n<path d="M1 5.37499C1 2.95875 2.95875 1 5.375 1H41.8559C44.2722 1 46.2309 2.95875 46.2309 5.375V19.2405C46.2309 21.6567 44.2722 23.6155 41.8559 23.6155H5.37499C2.95875 23.6155 1 21.6567 1 19.2405V5.37499Z" fill="var( --link-panel-dag-no-pipeline-icon-background)" stroke="#6C79F9" stroke-width="2" stroke-linecap="round" stroke-dasharray="5 7"/>\n<path d="M28.303 43.0117C28.303 40.5955 30.2617 38.6367 32.678 38.6367H69.1589C71.5751 38.6367 73.5339 40.5955 73.5339 43.0117V56.8772C73.5339 59.2934 71.5751 61.2522 69.1589 61.2522H32.678C30.2617 61.2522 28.303 59.2934 28.303 56.8772V43.0117Z" fill="var( --link-panel-dag-no-pipeline-icon-background)" stroke="#6C79F9" stroke-width="2" stroke-linecap="round" stroke-dasharray="5 7"/>\n<path d="M28.303 74.4297C28.303 72.0134 30.2617 70.0547 32.678 70.0547H69.1589C71.5751 70.0547 73.5339 72.0134 73.5339 74.4297V88.2951C73.5339 90.7114 71.5751 92.6701 69.1589 92.6701H32.678C30.2617 92.6701 28.303 90.7114 28.303 88.2951V74.4297Z" fill="var( --link-panel-dag-no-pipeline-icon-background)" stroke="#6C79F9" stroke-width="2" stroke-linecap="round" stroke-dasharray="5 7"/>\n<path d="M55.7693 5.375C55.7693 2.95875 57.728 1 60.1443 1H96.6252C99.0414 1 101 2.95875 101 5.375V19.2405C101 21.6567 99.0414 23.6155 96.6252 23.6155H60.1443C57.728 23.6155 55.7693 21.6567 55.7693 19.2405V5.375Z" fill="var( --link-panel-dag-no-pipeline-icon-background)" stroke="#6C79F9" stroke-width="2" stroke-linecap="round" stroke-dasharray="5 7"/>\n</svg>\n'}))),r().createElement("div",{className:"panel-empty-title"},r().createElement("p",null,R().title)),r().createElement("div",{className:"panel-empty-description"},r().createElement("p",null,R().description))),Da.visible&&r().createElement(r().Fragment,null,"header-color"===Da.type&&r().createElement(Va,{close:H}),"remote"===Da.type&&r().createElement(ti,{close:()=>{"remote"===Da.type&&Da.close()}})),r().createElement(Vo,{isSettingPanelOpened:C})),r().createElement(No,null),r().createElement(Io,{graphRef:w,isExistComponent:x,scale:d}))))}))),ai=ni,ri=(0,a.forwardRef)(((e,t)=>{const n=(0,a.useRef)(null);(0,a.useEffect)((()=>{Kl.visible&&n&&(n.current.scrollTop=0)}),[Kl.visible]);const l=(0,a.useCallback)((()=>{xo()}),[]),o=(0,a.useCallback)((()=>{Kl.close()}),[]);(0,a.useEffect)((()=>(n.current.addEventListener("mouseenter",l),n.current.addEventListener("mouseleave",o),()=>{n.current.removeEventListener("mouseenter",l),n.current.addEventListener("mouseleave",o)})),[n]);const i=(0,a.useCallback)((e=>{let t="";switch(e){case"objects":t="object";break;case"functions":t="function";break;case"classes":t="class";break;case"modules":t="module"}return t.charAt(0).toUpperCase()+t.slice(1,t.length)}),[]),s=(0,a.useCallback)((e=>{let t="";switch(e){case"objects":t="var(--link-dag-summary-desc-object-background)";break;case"functions":t="var(--link-dag-summary-desc-function-background)";break;case"classes":t="var(--link-dag-summary-desc-class-background)";break;case"modules":t="var(--link-dag-summary-desc-module-background)"}return t}),[]),c=(0,a.useCallback)((e=>{let t="";switch(e){case"objects":t="var(--link-dag-summary-desc-object-font-color)";break;case"functions":t="var(--link-dag-summary-desc-function-font-color)";break;case"classes":t="var(--link-dag-summary-desc-class-font-color)";break;case"modules":t="var(--link-dag-summary-desc-module-font-color)"}return t}),[]);return r().createElement("div",{className:"summary-container",ref:n,style:{visibility:Kl.visible?"visible":"collapse",top:Kl.position.y+"px",left:Kl.position.x+Kl.position.width+5+"px"}},r().createElement("div",{className:"summary-title"},r().createElement("div",{style:{fontSize:"14px",fontStyle:"normal",fontWeight:"bold",lineHeight:"16px",color:"var(--link-dag-summary-title-font-color)"}},Kl.componentName)),r().createElement("div",{className:"summary-desc"},Object.entries(Kl.summary).map(((e,t)=>{const[n,a]=e;return a.length?r().createElement("div",{key:n},r().createElement("div",{style:{fontStyle:"normal",fontWeight:"bold",fontSize:"12px",lineHeight:"15px",color:"var(--link-dag-summary-category-font-color)",margin:0===t?"0px 0px 5px":"10px 0px 5px"}},i(n)),r().createElement("section",null,a.map(((e,t)=>r().createElement("span",{key:t,style:{display:"inline-block",color:c(n),padding:"2px 4px",borderRadius:"5px",textAlign:"center",fontWeight:700,border:"1px solid "+c(n),background:s(n),margin:"2px 3px",maxWidth:"200px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",fontSize:"11px"}},e))))):null}))))})),li=(0,jt.observer)(ri),oi=(0,_.x)((()=>{const[e,t]=(0,a.useState)("");return(0,a.useEffect)((()=>{y.value?Gn().then((e=>{t((null==e?void 0:e.title)||"")})).catch((()=>{t("")})):t("")}),[y.value]),r().createElement(ii,null,e.length?r().createElement("div",{style:{padding:"2px"}},r().createElement(si,null,r().createElement("span",{className:"runway-project-title-icon"},Oe),r().createElement("span",{className:"runway-project-title-text"},e))):r().createElement("div",{style:{padding:"2px",cursor:"grap"}},"Link"))})),ii=S().div`
  display: flex;
  align-items: center;
  height: 100%;
  gap: 8px;
`,si=S().div`
  display: flex;
  align-items: center;
  gap: 8px;
  .runway-project-title-icon {
    display: flex;
    justify-content: center;
  }
  .runway-project-title-text {
    font-size: 14px;
  }
`,ci=oi,di=Vt.getInstance(),pi={id:"canvas:extensions",requires:[W.ILabShell,W.ILayoutRestorer,U.INotebookTracker,q.IMainMenu,$.IThemeManager,K.IStatusBar],autoStart:!0,activate:async function(e,t,n,a,o,i,s){const{docRegistry:c,restored:d,commands:p}=e;function m(e){return!e||i.isLight(e)?"light":"dark"}ke.addEvent(we.PipelineUpdated),ke.addEvent(we.ParametersUpdated),ke.addEvent(we.ExportCacheProgress),ke.addEvent(we.ImportCacheProgress),ke.addListener(we.PipelineUpdated,(e=>{!function(e){if(!e.successful)return void u.error("WS Error");if(!di.currentWidget)return;const t=Object.assign(Object.assign({},pe.getKernelComponents(e.successful.identifier)),e.successful.updated_components.added);Object.keys(e.successful.updated_components.revised).map((n=>t[n]=e.successful.updated_components.revised[n])),e.successful.updated_components.deleted.forEach((e=>delete t[e])),pe.setKernelComponents(e.successful.identifier,t),function(e){const t=di.currentWidget;if(t)for(const n of Object.keys(e)){const a=t.cells.getCellMetadataByID(n);a&&(a.diskcache=e[n].metadata.diskcache)}}(t)}(e)})),ke.addListener(we.ParametersUpdated,(e=>{var t,n;const a=null===(n=null===(t=di.currentWidget)||void 0===t?void 0:t.kernel)||void 0===n?void 0:n.id;"successful"===e.status&&a&&(me.isParameterExecutable[a]=!0)})),ke.addListener(we.PipelineUpdated,(e=>{var t,n;const a=null===(n=null===(t=di.currentWidget)||void 0===t?void 0:t.kernel)||void 0===n?void 0:n.id;"successful"===e.status&&a&&(me.isParameterExecutable[a]=!0)})),Vt.initialize(t,a),pe.setCommandRegistry(p),document.body.dataset.theme=m(null==i?void 0:i.theme),i.themeChanged.connect(((e,t)=>{document.body.dataset.theme=m(t.newValue)})),window.l=t;const h=document.createElement("div");window.document.body.appendChild(h),(0,l.H)(h).render(r().createElement(li,{top:0,left:0,bottom:0})),Zt(e,a),c.addWidgetExtension("Notebook",new ja(t,p,a));const g=$.ReactWidget.create(r().createElement(ai,{lab:e,shell:t,commands:p,tracker:a,notebook:a.currentWidget}));g.id="canvas-pipeline-extension",g.title.caption="Link",g.title.icon=new Y.LabIcon({name:"link:logo",svgstr:'<svg width="63" height="59" viewBox="0 0 63 59" fill="none" xmlns="http://www.w3.org/2000/svg">\n<g clip-path="url(#clip0_1288_15241)">\n<path d="M57.4296 39.5906L23.3196 34.8506C20.8696 34.4806 19.0596 32.3806 19.0596 29.9006V9.73059C19.0596 7.25059 20.8696 5.15059 23.3196 4.78059L57.4296 0.0405903C59.8496 -0.31941 62.0196 1.55059 62.0196 4.00059V35.6306C62.0196 38.0806 59.8496 39.9506 57.4296 39.5906V39.5906Z" fill="#6C79F9"/>\n<path d="M4.59 18.4295L38.7 23.1695C41.15 23.5395 42.96 25.6395 42.96 28.1195V48.2895C42.96 50.7695 41.15 52.8695 38.7 53.2395L4.59 57.9695C2.17 58.3395 0 56.4595 0 54.0195V22.3795C0 19.9295 2.17 18.0595 4.59 18.4195V18.4295Z" fill="#9578FF"/>\n<path d="M38.6998 23.1695L19.0498 20.4395V29.9095C19.0498 32.3895 20.8598 34.4895 23.3098 34.8595L42.9598 37.5895V28.1195C42.9598 25.6395 41.1498 23.5395 38.6998 23.1695V23.1695Z" fill="#5D5DF4"/>\n</g>\n<defs>\n<clipPath id="clip0_1288_15241">\n<rect width="62.02" height="58.02" fill="white"/>\n</clipPath>\n</defs>\n</svg>\n'}),n.add(g,g.id),t.add(g,"left",{rank:200}),t.currentChanged.connect(ut),a.currentChanged.connect(ht),d.then((async()=>{g.isAttached||t.expandLeft();const e=G.ServerConnection.makeSettings().wsUrl.replace(/\/$/g,"");ke.connect(e+"/mrx-link/ws").then((()=>{g.activate()})).catch((()=>{console.error("Error websocket: "+e+"/mrx-link/ws"),g.activate()}))})),s.registerStatusItem("id-status-item",{item:new mi,align:"left"}),(e=>{const t=[{type:"command",command:Rt.aboutMLHelp}];e.helpMenu.addGroup(t,-1)})(o)}};class mi extends $.VDomRenderer{constructor(){super()}render(){return r().createElement(ci,null)}}var ui=n(59935);const hi=new class{constructor(){this.uploadingFiles={},(0,ce.makeAutoObservable)(this)}registerFileBrowserFactory(e){var t;null===(t=e.tracker.currentWidget)||void 0===t||t.model.uploadChanged.connect(((e,t)=>{var n,a;const r=t.name;if("start"!==r&&"finish"!==r)return;const l="start"===r?(null===(n=t.newValue)||void 0===n?void 0:n.path)||"":(null===(a=t.oldValue)||void 0===a?void 0:a.path)||"";try{const e=this.splitByFirstMatch(l,"dataset-staged/")[1],[t,n]=this.splitByFirstMatch(e,"/");"start"===r?this.addUploadingFile(t,n):"finish"===r&&this.removeUploadingFile(t,n)}catch(e){console.error(e)}}))}hasUploadingFiles(e){var t;return(null===(t=this.uploadingFiles[e])||void 0===t?void 0:t.size)>0}isUploadingFile(e,t){var n;return null===(n=this.uploadingFiles[e])||void 0===n?void 0:n.has(t)}addUploadingFile(e,t){this.uploadingFiles[e]||(this.uploadingFiles[e]=new Set),this.uploadingFiles[e].add(t)}removeUploadingFile(e,t){this.uploadingFiles[e]&&this.uploadingFiles[e].delete(t)}splitByFirstMatch(e,t){const n=e.indexOf(t);return-1!==n?[e.substring(0,n),e.substring(n+t.length)]:[e,""]}},gi=new Y.LabIcon({name:"link-dataset:logo",svgstr:'<svg width="63" height="65" viewBox="0 0 63 65" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M29.1363 35.403C30.3159 34.8657 31.6837 34.8657 32.8633 35.403L60.7538 48.1057C62.4154 48.8627 62.4154 51.1373 60.7538 51.894L32.8633 64.597C31.6837 65.1343 30.3159 65.1343 29.1363 64.597L1.24612 51.894C-0.415369 51.1373 -0.415369 48.8627 1.24609 48.1057L29.1363 35.403Z" fill="#6E79F1"/>\n<path d="M29.6568 17.4053C30.8253 16.8649 32.1749 16.8649 33.3434 17.4053L61.7406 30.5389C63.4198 31.3157 63.4198 33.6843 61.7406 34.4608L33.3434 47.5947C32.1749 48.1351 30.8253 48.1351 29.6568 47.5947L1.25944 34.4608C-0.419797 33.6843 -0.419831 31.3157 1.25944 30.5389L29.6568 17.4053Z" fill="#9079F7"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M48 41.5682L34.0284 47.6151C32.8427 48.1283 31.4733 48.1283 30.2875 47.6151L16 41.4315L29.9716 35.3849C31.1573 34.8717 32.5267 34.8717 33.7125 35.3849L48 41.5682Z" fill="#6550EA"/>\n<path d="M29.1363 0.403015C30.3159 -0.134338 31.6837 -0.134338 32.8633 0.403015L60.7538 13.106C62.4154 13.8627 62.4154 16.1373 60.7538 16.894L32.8633 29.597C31.6837 30.1343 30.3159 30.1343 29.1363 29.597L1.24612 16.894C-0.415369 16.1373 -0.415369 13.8627 1.24609 13.106L29.1363 0.403015Z" fill="#C2B4FF"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M47 23.477L33.1698 29.6148C32.0126 30.1284 30.676 30.1284 29.5187 29.6148L16 23.6152L29.8049 17.3952C30.9748 16.8683 32.3315 16.8683 33.5014 17.3952L47 23.477Z" fill="#846BF0"/>\n</svg>\n'}),vi=new Y.LabIcon({name:"link-dataset:logo-dot",svgstr:'<svg width="63" height="65" viewBox="0 0 63 65" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M29.1363 35.403C30.3159 34.8657 31.6837 34.8657 32.8633 35.403L60.7538 48.1057C62.4154 48.8627 62.4154 51.1373 60.7538 51.894L32.8633 64.597C31.6837 65.1343 30.3159 65.1343 29.1363 64.597L1.24612 51.894C-0.415369 51.1373 -0.415369 48.8627 1.24609 48.1057L29.1363 35.403Z" fill="#6E79F1"/>\n<path d="M29.6568 17.4053C30.8253 16.8649 32.1749 16.8649 33.3434 17.4053L61.7406 30.5389C63.4198 31.3157 63.4198 33.6843 61.7406 34.4608L33.3434 47.5947C32.1749 48.1351 30.8253 48.1351 29.6568 47.5947L1.25944 34.4608C-0.419797 33.6843 -0.419831 31.3157 1.25944 30.5389L29.6568 17.4053Z" fill="#9079F7"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M48 41.5682L34.0284 47.6151C32.8427 48.1283 31.4733 48.1283 30.2875 47.6151L16 41.4315L29.9716 35.3849C31.1573 34.8717 32.5267 34.8717 33.7125 35.3849L48 41.5682Z" fill="#6550EA"/>\n<path d="M29.1363 0.403015C30.3159 -0.134338 31.6837 -0.134338 32.8633 0.403015L60.7538 13.106C62.4154 13.8627 62.4154 16.1373 60.7538 16.894L32.8633 29.597C31.6837 30.1343 30.3159 30.1343 29.1363 29.597L1.24612 16.894C-0.415369 16.1373 -0.415369 13.8627 1.24609 13.106L29.1363 0.403015Z" fill="#C2B4FF"/>\n<path fill-rule="evenodd" clip-rule="evenodd" d="M47 23.477L33.1698 29.6148C32.0126 30.1284 30.676 30.1284 29.5187 29.6148L16 23.6152L29.8049 17.3952C30.9748 16.8683 32.3315 16.8683 33.5014 17.3952L47 23.477Z" fill="#846BF0"/>\n<circle cx="53" cy="10" r="10" fill="#EB5B4B"/>\n</svg>\n'});var fi;!function(e){e[e.NOT_SUBMITTING=0]="NOT_SUBMITTING",e[e.SUBMITTING=1]="SUBMITTING",e[e.SUCCESS=2]="SUCCESS",e[e.FAILURE=3]="FAILURE"}(fi||(fi={}));const xi="NETWORK_ERROR",bi=({code:e})=>r().createElement(Ci,null,r().createElement("div",{className:"failure-message-title"},Fe," ",e===xi?"Network Error":"Failed to create a dataset version"),r().createElement("div",{className:"failure-message-description"},e===xi?"Update was unsuccessful due to a connection loss.":r().createElement(r().Fragment,null,"An unknown error occurred. Please contact the System Administrator.",r().createElement("br",null),e&&`Error code: '${e}'`))),Ci=S().div`
  padding: 12px;
  border-radius: 4px;
  background-color: var(--section-message-error-background);
  border: 1px solid var(--section-message-error-border);
  color: var(--text-primary);
  font-size: 13px;

  display: flex;
  flex-direction: column;
  gap: 8px;

  .failure-message-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 500;
  }

  .failure-message-description {
    color: var(--text-secondary);
    font-weight: 400;
    padding-left: 20px; // icon size + gap size in title
  }
`,Ei=({dataset:e,closeModal:t,onSubmitted:n})=>{const[l,o]=(0,a.useState)(""),[c,d]=(0,a.useState)(fi.NOT_SUBMITTING),[p,m]=(0,a.useState)(""),[u,h]=(0,a.useState)(null);function g(){d(fi.SUBMITTING),async function(e,t){const n=i.ServerConnection.makeSettings(),a=`${s.PageConfig.getBaseUrl()}mrx-link/runway/datasets/versions?dataset_id=${e}`,r=JSON.stringify({description:t}),l=await i.ServerConnection.makeRequest(a,{method:"POST",body:r},n);return l.ok?{response:l.json()}:{error:!0,code:"Error"}}(e.id,p).then((e=>{e.response?(h(null),d(fi.SUCCESS),t()):(h(e.code),d(fi.FAILURE))})).catch((()=>{h(xi),d(fi.FAILURE)})).finally((()=>{n&&n()}))}return(0,a.useEffect)((()=>{Gn().then((e=>{o((null==e?void 0:e.title)||"")})).catch((()=>{o("")}))}),[]),r().createElement(se,{open:!0,onClose:t},r().createElement("h1",null,ie," Create version"),r().createElement("section",null,c===fi.FAILURE&&r().createElement(bi,{code:u})),r().createElement("section",null,r().createElement("form",null,r().createElement(pn,null,r().createElement(N.InputLabel,null,"Project"),r().createElement("div",{className:"value"},Oe," ",l)),r().createElement(pn,null,r().createElement(N.TextField,{disabled:!0,label:"Dataset version",value:`${e.name}/v.${e.version+1}`,size:"small",fullWidth:!0})),r().createElement(pn,null,r().createElement(sn,{valueLength:p.length,maxLength:100},r().createElement(N.TextField,{label:"Version description (optional)",value:p,onChange:e=>m(e.target.value),required:!1,size:"small",fullWidth:!0,multiline:!0,rows:3,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},inputProps:{maxLength:100}}))))),r().createElement("menu",null,r().createElement("button",{onClick:t,disabled:c===fi.SUBMITTING},"Cancel"),{[fi.NOT_SUBMITTING]:r().createElement("button",{className:"primary",onClick:g},"Create"),[fi.SUBMITTING]:r().createElement("button",{className:"primary loading",disabled:!0},r().createElement(N.CircularProgress,{color:"inherit",size:16})),[fi.SUCCESS]:r().createElement("button",{className:"primary",disabled:!0},"Succeed"),[fi.FAILURE]:r().createElement("button",{className:"primary",onClick:g},"Retry")}[c]))},wi=S().div`
  display: flex;
  align-items: center;
  gap: 4px;
`,yi=S().div`
  cursor: ${e=>e.loading?"not-allowed":"pointer"};
  background-color: var(--button-link-background);
  color: var(--white);
  opacity: ${e=>e.loading?.5:1};

  height: 24px;
  line-height: 20px;
  padding: 0 8px;

  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 4px;
  border-radius: 4px;

  font-size: 11px;
  font-weight: 500;

  &:hover {
    background-color: var(--button-link-background-hover);
  }
`,ki=({dataset:e,onSubmitted:t})=>{const[n,l]=(0,a.useState)(!1),o=hi.hasUploadingFiles(e.name);return r().createElement(wi,null,"uploading"===e.uploadingStatus&&r().createElement(Kt,{title:"You can create a version after the version creation is complete.",placement:"top"},r().createElement(yi,{loading:!0},"Create version")),"uploading"!==e.uploadingStatus&&!0===o&&r().createElement(Kt,{title:"You can create a version after the file upload is complete.",placement:"top"},r().createElement(yi,{loading:!0},"Create version")),"uploading"!==e.uploadingStatus&&!1===o&&r().createElement(yi,{onClick:()=>l(!0),title:`Create version of ${e.name} with ${e.changed.length} changes.`},"Create version"),n&&r().createElement(Ei,{dataset:e,closeModal:()=>l(!1),onSubmitted:t}))},Li=({closeDialog:e})=>{const[t,n]=(0,a.useState)(""),[l,o]=(0,a.useState)(fi.NOT_SUBMITTING),[c,d]=(0,a.useState)(""),[p,m]=(0,a.useState)(""),[u,h]=(0,a.useState)(""),[g,v]=(0,a.useState)(null),[f,x]=(0,a.useState)([]),b=(0,a.useMemo)((()=>0===u.length&&c.length>0),[c,u]);function C(t){t.preventDefault(),b&&(o(fi.SUBMITTING),async function(e,t){const n=i.ServerConnection.makeSettings(),a=`${s.PageConfig.getBaseUrl()}mrx-link/runway/datasets`,r=JSON.stringify({name:e,description:t,exist_ok:!1}),l=await i.ServerConnection.makeRequest(a,{method:"POST",body:r},n);return l.ok?{response:l.json()}:{error:!0,code:"Error"}}(c,p).then((t=>{t.response?(v(null),o(fi.SUCCESS),e()):(v(t.code),o(fi.FAILURE))})).catch((()=>{v(xi),o(fi.FAILURE)})))}return(0,a.useEffect)((()=>{zn().then((e=>{e&&x(e.map((e=>e.name)))})),Gn().then((e=>{n((null==e?void 0:e.title)||"")})).catch((()=>{n("")}))}),[]),(0,a.useEffect)((()=>{const{message:e}=bl(c,Cl,f);h(e)}),[c]),r().createElement(se,{open:!0,onClose:e},r().createElement("h1",null,ie," Create dataset"),l===fi.FAILURE&&r().createElement("section",null,r().createElement(bi,{code:g})),r().createElement("section",null,r().createElement("form",{onSubmit:C},r().createElement(pn,null,r().createElement(N.InputLabel,null,"Project"),r().createElement("div",{className:"value"},Oe," ",t)),r().createElement(pn,null,r().createElement(sn,{valueLength:c.length,maxLength:30,errorMessage:u},r().createElement(N.TextField,{label:"Dataset name",value:c,onChange:e=>d(e.target.value),placeholder:"Enter the dataset name",required:!0,error:u.length>0,size:"small",fullWidth:!0,margin:"normal",autoComplete:"off",autoFocus:!0,InputLabelProps:{shrink:!0},inputProps:{maxLength:30}}))),r().createElement(pn,null,r().createElement(sn,{valueLength:p.length,maxLength:100},r().createElement(N.TextField,{label:"Description (optional)",value:p,onChange:e=>m(e.target.value),required:!1,size:"small",fullWidth:!0,multiline:!0,rows:3,margin:"normal",autoComplete:"off",InputLabelProps:{shrink:!0},inputProps:{maxLength:100}}))))),r().createElement("menu",null,r().createElement("button",{onClick:e,disabled:l===fi.SUBMITTING},"Cancel"),{[fi.NOT_SUBMITTING]:r().createElement("button",{className:"primary",onClick:C,disabled:!b},"Create"),[fi.SUBMITTING]:r().createElement("button",{className:"primary loading",disabled:!0},r().createElement(N.CircularProgress,{color:"inherit",size:16})),[fi.SUCCESS]:r().createElement("button",{className:"primary",disabled:!0},"Succeed"),[fi.FAILURE]:r().createElement("button",{className:"primary",onClick:C},"Retry")}[l]))},_i=()=>{const[e,t]=(0,a.useState)(!1);return r().createElement(r().Fragment,null,r().createElement(yi,{onClick:()=>t(!0)},"Create dataset"),e&&r().createElement(Li,{closeDialog:()=>t(!1)}))},Mi=S().div`
  width: 250px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  border-radius: 8px;
  background-color: var(--background-base);

  .popover-title {
    font-size: 15px;
    font-weight: 500;
    color: var(--text-primary);
  }

  .popover-description {
    font-size: 13px;
    font-weight: 400;
    color: var(--text-secondary);
  }
`,Si=S().header`
  height: 35px;
  line-height: 35px;
  padding: 8px 12px;
  border-bottom: 1px solid var(--border-primary);
  background-color: var(--background-surface);

  display: flex;
  gap: 4px;
  align-items: center;

  .panel-title {
    font-size: 15px;
    line-height: 20px;
    font-weight: 500;
  }

  .info-icon {
    cursor: pointer;
    display: flex;
    width: 14px;
    height: 14px;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 4px;
    flex-shrink: 0;

    border-radius: 14px;
    border: 1px solid var(--text-detail);

    color: var(--text-secondary);
    font-size: 11px;
    font-weight: 500;
  }

  .button-container {
    margin-left: auto;
  }
`,Ni=()=>{const[e,t]=(0,a.useState)(null);return r().createElement(Si,null,r().createElement("div",{className:"panel-title"},"Dataset versioning"),r().createElement("div",{className:"info-icon",onClick:e=>t(e.currentTarget)},"?"),r().createElement(N.Popover,{anchorEl:e,open:Boolean(e),onClose:()=>t(null),anchorOrigin:{vertical:"bottom",horizontal:"left"},transformOrigin:{vertical:"top",horizontal:"left"},style:{borderRadius:"8px"}},r().createElement(Mi,null,r().createElement("div",{className:"popover-title"},"Dataset versioning"),r().createElement("div",{className:"popover-description"},"You can update the dataset to create a new version in Link."),r().createElement(sa,{path:"Guide/ml_development/dev_instances/dataset",title:"How to create dataset version"}))),r().createElement("div",{className:"button-container"},r().createElement(_i,null)))},Ai=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 24 24"},r().createElement("path",{className:"jp-icon3 jp-icon-selectable",fill:"#616161",d:"M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"})),Ii=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("path",{className:"jp-icon3 jp-icon-selectable",fill:"#616161",d:"M19.3 8.2l-5.5-5.5c-.3-.3-.7-.5-1.2-.5H3.9c-.8.1-1.6.9-1.6 1.8v14.1c0 .9.7 1.6 1.6 1.6h14.2c.9 0 1.6-.7 1.6-1.6V9.4c.1-.5-.1-.9-.4-1.2zm-5.8-3.3l3.4 3.6h-3.4V4.9zm3.9 12.7H4.7c-.1 0-.2 0-.2-.2V4.7c0-.2.1-.3.2-.3h7.2v4.4s0 .8.3 1.1c.3.3 1.1.3 1.1.3h4.3v7.2s-.1.2-.2.2z"})),Oi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("g",{className:"jp-notebook-icon-color jp-icon-selectable",fill:"#EF6C00"},r().createElement("path",{d:"M18.7 3.3v15.4H3.3V3.3h15.4m1.5-1.5H1.8v18.3h18.3l.1-18.3z"}),r().createElement("path",{d:"M16.5 16.5l-5.4-4.3-5.6 4.3v-11h11z"}))),Pi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"-10 -10 131.16136169433594 132.38899993896484"},r().createElement("path",{className:"jp-icon-selectable",fill:"#306998",d:"M 54.918785,9.1927421e-4 C 50.335132,0.02221727 45.957846,0.41313697 42.106285,1.0946693 30.760069,3.0991731 28.700036,7.2947714 28.700035,15.032169 v 10.21875 h 26.8125 v 3.40625 h -26.8125 -10.0625 c -7.792459,0 -14.6157588,4.683717 -16.7499998,13.59375 -2.46181998,10.212966 -2.57101508,16.586023 0,27.25 1.9059283,7.937852 6.4575432,13.593748 14.2499998,13.59375 h 9.21875 v -12.25 c 0,-8.849902 7.657144,-16.656248 16.75,-16.65625 h 26.78125 c 7.454951,0 13.406253,-6.138164 13.40625,-13.625 v -25.53125 c 0,-7.2663386 -6.12998,-12.7247771 -13.40625,-13.9374997 C 64.281548,0.32794397 59.502438,-0.02037903 54.918785,9.1927421e-4 Z m -14.5,8.21875012579 c 2.769547,0 5.03125,2.2986456 5.03125,5.1249996 -2e-6,2.816336 -2.261703,5.09375 -5.03125,5.09375 -2.779476,-1e-6 -5.03125,-2.277415 -5.03125,-5.09375 -10e-7,-2.826353 2.251774,-5.1249996 5.03125,-5.1249996 z"}),r().createElement("path",{className:"jp-icon-selectable",fill:"#ffd43b",d:"m 85.637535,28.657169 v 11.90625 c 0,9.230755 -7.825895,16.999999 -16.75,17 h -26.78125 c -7.335833,0 -13.406249,6.278483 -13.40625,13.625 v 25.531247 c 0,7.266344 6.318588,11.540324 13.40625,13.625004 8.487331,2.49561 16.626237,2.94663 26.78125,0 6.750155,-1.95439 13.406253,-5.88761 13.40625,-13.625004 V 86.500919 h -26.78125 v -3.40625 h 26.78125 13.406254 c 7.792461,0 10.696251,-5.435408 13.406241,-13.59375 2.79933,-8.398886 2.68022,-16.475776 0,-27.25 -1.92578,-7.757441 -5.60387,-13.59375 -13.406241,-13.59375 z m -15.0625,64.65625 c 2.779478,3e-6 5.03125,2.277417 5.03125,5.093747 -2e-6,2.826354 -2.251775,5.125004 -5.03125,5.125004 -2.76955,0 -5.03125,-2.29865 -5.03125,-5.125004 2e-6,-2.81633 2.261697,-5.093747 5.03125,-5.093747 z"})),Ti=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("path",{className:"jp-icon-contrast3 jp-icon-selectable",fill:"#2196F3",d:"M4.4 2.5c1.2-.1 2.9-.3 4.9-.3 2.5 0 4.1.4 5.2 1.3 1 .7 1.5 1.9 1.5 3.5 0 2-1.4 3.5-2.9 4.1 1.2.4 1.7 1.6 2.2 3 .6 1.9 1 3.9 1.3 4.6h-3.8c-.3-.4-.8-1.7-1.2-3.7s-1.2-2.6-2.6-2.6h-.9v6.4H4.4V2.5zm3.7 6.9h1.4c1.9 0 2.9-.9 2.9-2.3s-1-2.3-2.8-2.3c-.7 0-1.3 0-1.6.2v4.5h.1v-.1z"})),Fi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 325 300"},r().createElement("g",{className:"jp-brand0 jp-icon-selectable",fill:"#cb3c33"},r().createElement("path",{d:"M 150.898438 225 C 150.898438 266.421875 117.320312 300 75.898438 300 C 34.476562 300 0.898438 266.421875 0.898438 225 C 0.898438 183.578125 34.476562 150 75.898438 150 C 117.320312 150 150.898438 183.578125 150.898438 225"})),r().createElement("g",{className:"jp-brand0 jp-icon-selectable",fill:"#389826"},r().createElement("path",{d:"M 237.5 75 C 237.5 116.421875 203.921875 150 162.5 150 C 121.078125 150 87.5 116.421875 87.5 75 C 87.5 33.578125 121.078125 0 162.5 0 C 203.921875 0 237.5 33.578125 237.5 75"})),r().createElement("g",{className:"jp-brand0 jp-icon-selectable",fill:"#9558b2"},r().createElement("path",{d:"M 324.101562 225 C 324.101562 266.421875 290.523438 300 249.101562 300 C 207.679688 300 174.101562 266.421875 174.101562 225 C 174.101562 183.578125 207.679688 150 249.101562 150 C 290.523438 150 324.101562 183.578125 324.101562 225"}))),Vi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("path",{className:"jp-icon-contrast0 jp-icon-selectable",fill:"#7B1FA2",d:"M5 14.9h12l-6.1 6zm9.4-6.8c0-1.3-.1-2.9-.1-4.5-.4 1.4-.9 2.9-1.3 4.3l-1.3 4.3h-2L8.5 7.9c-.4-1.3-.7-2.9-1-4.3-.1 1.6-.1 3.2-.2 4.6L7 12.4H4.8l.7-11h3.3L10 5c.4 1.2.7 2.7 1 3.9.3-1.2.7-2.6 1-3.9l1.2-3.7h3.3l.6 11h-2.4l-.3-4.2z"})),Hi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 22 22",width:"16"},r().createElement("path",{transform:"rotate(45)",className:"jp-icon-selectable",fill:"#FF2A2A",d:"m 22.344369,-3.0163642 h 5.638604 v 1.5792433 h -3.549227 v 1.50869299 h 3.337576 V 1.6508154 h -3.337576 v 3.4352613 h -2.089377 z m -7.136444,1.5792433 v 4.9439543 h 0.74892 q 1.280761,0 1.953703,-0.6349535 0.678369,-0.6349535 0.678369,-1.8451641 0,-1.20478355 -0.672942,-1.83431011 -0.672942,-0.62952659 -1.95913,-0.62952659 z m -2.089377,-1.5792433 h 2.203343 q 1.845164,0 2.746039,0.2659207 0.906301,0.2604937 1.552108,0.8900203 0.56983,0.5481223 0.846605,1.26448006 0.276774,0.71635781 0.276774,1.62265894 0,0.9171551 -0.276774,1.6389399 -0.276775,0.7163578 -0.846605,1.26448 -0.651234,0.6295266 -1.562962,0.8954473 -0.911728,0.2604937 -2.735185,0.2604937 h -2.203343 z m -8.1458565,0 h 3.467823 q 1.5466816,0 2.3715785,0.689223 0.830324,0.6837961 0.830324,1.95370314 0,1.27533397 -0.830324,1.96455706 Q 9.9871961,2.274915 8.4405145,2.274915 H 7.0620684 V 5.0860767 H 4.9726915 Z m 2.0893769,1.5141199 v 2.26303943 h 1.155941 q 0.6078188,0 0.9388629,-0.29305547 0.3310441,-0.29848241 0.3310441,-0.84117772 0,-0.54269531 -0.3310441,-0.83575074 -0.3310441,-0.2930555 -0.9388629,-0.2930555 z"})),Ri=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("path",{className:"jp-icon-brand4 jp-icon-selectable-inverse",fill:"#FFF",d:"M2.2 2.2h17.5v17.5H2.2z"}),r().createElement("path",{className:"jp-icon-brand0 jp-icon-selectable",fill:"#3F51B5",d:"M2.2 2.2v17.5h17.5l.1-17.5H2.2zm12.1 2.2c1.2 0 2.2 1 2.2 2.2s-1 2.2-2.2 2.2-2.2-1-2.2-2.2 1-2.2 2.2-2.2zM4.4 17.6l3.3-8.8 3.3 6.6 2.2-3.2 4.4 5.4H4.4z"})),zi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("path",{className:"jp-icon-contrast1 jp-icon-selectable",fill:"#4CAF50",d:"M2.2 2.2v17.6h17.6V2.2H2.2zm15.4 7.7h-5.5V4.4h5.5v5.5zM9.9 4.4v5.5H4.4V4.4h5.5zm-5.5 7.7h5.5v5.5H4.4v-5.5zm7.7 5.5v-5.5h5.5v5.5h-5.5z"})),Zi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("g",{className:"jp-json-icon-color jp-icon-selectable",fill:"#F9A825"},r().createElement("path",{d:"M20.2 11.8c-1.6 0-1.7.5-1.7 1 0 .4.1.9.1 1.3.1.5.1.9.1 1.3 0 1.7-1.4 2.3-3.5 2.3h-.9v-1.9h.5c1.1 0 1.4 0 1.4-.8 0-.3 0-.6-.1-1 0-.4-.1-.8-.1-1.2 0-1.3 0-1.8 1.3-2-1.3-.2-1.3-.7-1.3-2 0-.4.1-.8.1-1.2.1-.4.1-.7.1-1 0-.8-.4-.7-1.4-.8h-.5V4.1h.9c2.2 0 3.5.7 3.5 2.3 0 .4-.1.9-.1 1.3-.1.5-.1.9-.1 1.3 0 .5.2 1 1.7 1v1.8zM1.8 10.1c1.6 0 1.7-.5 1.7-1 0-.4-.1-.9-.1-1.3-.1-.5-.1-.9-.1-1.3 0-1.6 1.4-2.3 3.5-2.3h.9v1.9h-.5c-1 0-1.4 0-1.4.8 0 .3 0 .6.1 1 0 .2.1.6.1 1 0 1.3 0 1.8-1.3 2C6 11.2 6 11.7 6 13c0 .4-.1.8-.1 1.2-.1.3-.1.7-.1 1 0 .8.3.8 1.4.8h.5v1.9h-.9c-2.1 0-3.5-.6-3.5-2.3 0-.4.1-.9.1-1.3.1-.5.1-.9.1-1.3 0-.5-.2-1-1.7-1v-1.9z"}),r().createElement("circle",{cx:"11",cy:"13.8",r:"2.1"}),r().createElement("circle",{cx:"11",cy:"8.2",r:"2.1"}))),Bi=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 22 22"},r().createElement("g",{className:"jp-icon-contrast2 jp-icon-selectable",fill:"#D81B60"},r().createElement("path",{d:"M7.2 18.6v-5.4L3 5.6h3.3l1.4 3.1c.3.9.6 1.6 1 2.5.3-.8.6-1.6 1-2.5l1.4-3.1h3.4l-4.4 7.6v5.5l-2.9-.1z"}),r().createElement("circle",{className:"st0",cx:"17.6",cy:"16.5",r:"2.1"}),r().createElement("circle",{className:"st0",cx:"17.6",cy:"11",r:"2.1"}))),ji=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",viewBox:"0 0 512 512"},r().createElement("path",{className:"jp-icon0 jp-icon-selectable",fill:"#000",d:"M108.4 0h23v22.8h21.2V0h23v69h-23V46h-21v23h-23.2M206 23h-20.3V0h63.7v23H229v46h-23m53.5-69h24.1l14.8 24.3L313.2 0h24.1v69h-23V34.8l-16.1 24.8-16.1-24.8V69h-22.6m89.2-69h23v46.2h32.6V69h-55.6"}),r().createElement("path",{className:"jp-icon-selectable",fill:"#e44d26",d:"M107.6 471l-33-370.4h362.8l-33 370.2L255.7 512"}),r().createElement("path",{className:"jp-icon-selectable",fill:"#f16529",d:"M256 480.5V131h148.3L376 447"}),r().createElement("path",{className:"jp-icon-selectable-inverse",fill:"#ebebeb",d:"M142 176.3h114v45.4h-64.2l4.2 46.5h60v45.3H154.4m2 22.8H202l3.2 36.3 50.8 13.6v47.4l-93.2-26"}),r().createElement("path",{className:"jp-icon-selectable-inverse",fill:"#fff",d:"M369.6 176.3H255.8v45.4h109.6m-4.1 46.5H255.8v45.4h56l-5.3 59-50.7 13.6v47.2l93-25.8"})),Di=({fileType:e})=>{switch(e){case"folder":return Ai;case"notebook":return Oi;case"python":return Pi;case"r":return Ti;case"julia":return Fi;case"markdown":return Vi;case"pdf":return Hi;case"image":return Ri;case"spreadsheet":return zi;case"json":return Zi;case"yaml":return Bi;case"html":return ji;default:return Ii}};function Wi(e,t){const n=e.split("/");return n.pop(),"folder"===t&&n.pop(),n.join("/")}function Ui(e,t){const n=e.split("/");return"folder"===t?n[n.length-2]||"":n[n.length-1]||""}const $i=(0,jt.observer)((({datasetName:e,file:t})=>{const{icon:n,name:a,path:l}=function(e){const t=function(e){if(e.length>0&&"/"===e[e.length-1])return"folder";switch(e.split(".").pop()){case"ipynb":return"notebook";case"py":return"python";case"r":return"r";case"jl":return"julia";case"md":return"markdown";case"pdf":return"pdf";case"png":case"bmp":case"jpg":case"jpeg":case"gif":case"svg":case"tif":case"tiff":case"webp":return"image";case"csv":case"tsv":return"spreadsheet";case"json":case"jsonl":return"json";case"yaml":case"yml":return"yaml";case"html":return"html";default:return"file"}}(e);return{path:Wi(e,t),name:Ui(e,t),icon:r().createElement(Di,{fileType:t})}}(t.path),o=hi.isUploadingFile(e,t.path);return r().createElement(Gi,null,r().createElement("div",{className:"file-label",title:t.path},r().createElement("div",{className:"file-icon"},n),r().createElement("div",{className:"file-name"},a),r().createElement("div",{className:"file-path"},l)),o&&r().createElement(De.A,{size:10,color:"inherit",role:"progressbar"}),!o&&t.status&&t.status.length>0&&r().createElement("div",{className:`file-status ${t.status}`},t.status[0].toUpperCase()))})),Gi=S().li`
  /* 말줄임 규칙 */
  /* 1. 왼쪽 오프너 아이콘과 오른쪽 업데이트 버튼은 고정 너비 */
  /* 2. 화면이 좁아지면 폴더 경로가 먼저 말줄임됨 */
  /* 3. 화면이 더 좁아져서 폴더 경로가 안보이면 파일 이름이 말줄임 됨 */

  --file-icon-width: 16px;
  --file-status-width: 8px;

  display: flex;
  align-items: center;
  height: 24px;
  width: 100%;
  justify-content: space-between;

  .file-icon {
    width: var(--file-icon-width);
    display: flex;
    align-items: center;
  }

  .file-label {
    width: calc(100% - var(--file-status-width) - var(--file-icon-width));
    display: flex;
    align-items: center;
    gap: 6px;

    .file-name {
      font-size: 13px;
      line-height: 17px;
      font-weight: 400;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .file-path {
      font-size: 11px;
      line-height: 15px;
      font-weight: 300;
      color: var(--text-detail);
      flex: 1;
      flex-grow: 1;
      flex-shrink: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }

  .file-status {
    width: var(--file-status-width);
    display: flex;
    align-items: center;
    text-align: center;

    &.added {
      color: #6c79f9;
    }
    &.deleted {
      color: #eb5b4b;
    }
    &.modified {
      color: #259530;
    }
  }
`,qi=$i,Ki=ze(Fe,12),Yi=S().li`
  --action-width: ${e=>e.unchanged?"0px":"130px"};
  --open-icon-width: 14px;

  opacity: ${e=>e.unchanged?.5:1};
  display: flex;
  flex-direction: column;

  .dataset-header {
    height: 35px;
    line-height: 27px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    position: sticky;
    top: 35px; // section(changed or unchanged)의 title 높이와 동일하게 맞춤
    background-color: var(--background-base);
    z-index: 1;

    .dataset-label-with-opener {
      width: calc(100% - var(--action-width));
      display: flex;
      align-items: center;
      gap: 6px;

      .open-icon {
        width: var(--open-icon-width);
        display: flex;
        align-items: center;
        cursor: ${e=>"uploading"===e.datasetStatus?"not-allowed":"pointer"};
        transform: ${e=>e.open?"rotate(0deg)":"rotate(270deg)"};
      }

      .dataset-label {
        width: calc(100% - var(--open-icon-width));
        display: flex;
        align-items: center;
        gap: 4px;

        .dataset-name {
          font-size: 13px;
          line-height: 17px;
          font-weight: 500;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .file-count {
          color: var(--text-detail);
        }

        .icon {
          margin-left: 4px;
        }
      }
    }

    .dataset-action {
      width: var(--action-width);
      display: ${e=>e.unchanged?"none":"flex"};
      justify-content: flex-end;
    }
  }

  .file-list {
    display: ${e=>e.open?"block":"none"};
    height: ${e=>e.open?"auto":0};
    overflow: hidden;
    padding: 0 8px 0 24px;
  }

  .dataset-footer {
    display: ${e=>e.open?"block":"none"};
    height: ${e=>e.open?"auto":0};
    padding: 4px 8px 8px 24px;

    .load-more-button {
      background: none;
      height: 24px;
      line-height: 24px;
      border-radius: 4px;
      border: 1px solid var(--border-primary);
      padding: 0 10px;
      font-size: 11px;
      font-weight: 400;
      color: var(--text-detail);

      &:hover {
        background-color: var(--background-surface);
      }
    }
  }
`,Xi=({dataset:e,refreshDatasets:t})=>{const[n,l]=(0,a.useState)(!1),[o,i]=(0,a.useState)(100),s=(0,a.useMemo)((()=>0===e.changed.length),[e]),c=(0,a.useMemo)((()=>e.changed.slice(0,o)),[e,o]),d=(0,a.useMemo)((()=>e.changed.length>0&&`(${e.changed.length.toString().replace(/\B(?=(\d{3})+(?!\d))/g,",")})`),[e]);return r().createElement(Yi,{unchanged:s,open:n&&"uploading"!==e.uploadingStatus,datasetStatus:e.uploadingStatus},r().createElement("div",{className:"dataset-header"},r().createElement("div",{className:"dataset-label-with-opener"},r().createElement("div",{className:"open-icon",onClick:function(){s||"uploading"===e.uploadingStatus?l(!1):l(!n)}},Ve),r().createElement("div",{className:"dataset-label"},r().createElement("div",{className:"dataset-name",title:e.name},e.name),"uploading"!==e.uploadingStatus&&d&&r().createElement("div",{className:"file-count"},d),"uploading"===e.uploadingStatus&&r().createElement(Kt,{className:"icon creating-icon",title:"Last version of this dataset is being created."},r().createElement(De.A,{size:12,color:"primary",className:"icon loading-icon"})),"failed"===e.uploadingStatus&&r().createElement(Kt,{className:"icon fail-icon",title:"Last version of this dataset failed to upload."},Ki))),r().createElement("div",{className:"dataset-action"},r().createElement(ki,{dataset:e,onSubmitted:t}))),r().createElement("ul",{className:"file-list"},c.map((t=>r().createElement(qi,{datasetName:e.name,key:t.path,file:t})))),e.changed.length>o&&r().createElement("div",{className:"dataset-footer"},r().createElement("button",{className:"load-more-button",onClick:()=>i(o+100),title:`Load ${Math.min(100,e.changed.length-o)} more files`},"Load more")))};class Ji{constructor(){this.labShell=null}static getInstance(){return Ji.instance||(Ji.instance=new Ji),Ji.instance}setLabShell(e){this.labShell=e}getLabShell(){return this.labShell}activateFileBrowser(){this.labShell?this.labShell.activateById("filebrowser"):console.error("lab shell is not set")}}const Qi=Ji.getInstance(),es=r().createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"44",height:"64",viewBox:"0 0 44 64",fill:"none"},r().createElement("path",{d:"M20.6103 33.2425C21.364 32.8857 22.238 32.8857 22.9918 33.2425L40.8134 41.6781C41.8751 42.1806 41.8751 43.6912 40.8134 44.1938L22.9918 52.6294C22.238 52.9862 21.364 52.9862 20.6103 52.6294L2.78864 44.1938C1.72698 43.6912 1.72698 42.1806 2.78864 41.6781L20.6103 33.2425Z",fill:"#6E79F1",fillOpacity:"0.4"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M4.27378 44.8967L2.78864 44.1938C1.72698 43.6912 1.72698 42.1806 2.78864 41.6781L4.27378 40.9751L4.74439 41.9694L3.25926 42.6723C3.03678 42.7776 3.03678 43.0942 3.25926 43.1995L4.74439 43.9025L4.27378 44.8967ZM5.75891 40.2722L6.22953 41.2664L9.1998 39.8605L8.72918 38.8662L5.75891 40.2722ZM10.2143 38.1632L10.6849 39.1575L13.6552 37.7516L13.1846 36.7573L10.2143 38.1632ZM14.6697 36.0543L15.1403 37.0486L18.1106 35.6426L17.64 34.6484L14.6697 36.0543ZM19.1251 33.9454L19.5957 34.9397L21.0809 34.2367C21.5367 34.0209 22.0653 34.0209 22.5212 34.2367L24.0063 34.9397L24.4769 33.9454L22.9918 33.2425C22.238 32.8857 21.364 32.8857 20.6103 33.2425L19.1251 33.9454ZM25.9621 34.6484L25.4914 35.6426L28.4617 37.0486L28.9323 36.0543L25.9621 34.6484ZM30.4175 36.7573L29.9468 37.7516L32.9171 39.1575L33.3877 38.1632L30.4175 36.7573ZM34.8729 38.8662L34.4023 39.8605L37.3725 41.2664L37.8431 40.2721L34.8729 38.8662ZM39.3283 40.9751L38.8577 41.9694L40.3428 42.6723C40.5653 42.7776 40.5653 43.0942 40.3428 43.1995L38.8577 43.9025L39.3283 44.8967L40.8134 44.1938C41.8751 43.6912 41.8751 42.1806 40.8134 41.6781L39.3283 40.9751ZM37.8431 45.5997L37.3725 44.6055L34.4022 46.0114L34.8729 47.0056L37.8431 45.5997ZM33.3877 47.7086L32.9171 46.7144L29.9468 48.1203L30.4175 49.1145L33.3877 47.7086ZM28.9323 49.8175L28.4617 48.8233L25.4914 50.2292L25.9621 51.2235L28.9323 49.8175ZM24.4769 51.9264L24.0063 50.9322L22.5212 51.6351C22.0653 51.8509 21.5367 51.8509 21.0809 51.6351L19.5957 50.9322L19.1251 51.9264L20.6103 52.6294C21.364 52.9862 22.238 52.9862 22.9918 52.6294L24.4769 51.9264ZM17.64 51.2235L18.1106 50.2292L15.1403 48.8233L14.6697 49.8175L17.64 51.2235ZM13.1846 49.1146L13.6552 48.1203L10.6849 46.7144L10.2143 47.7086L13.1846 49.1146ZM8.72918 47.0056L9.1998 46.0114L6.22953 44.6055L5.75891 45.5997L8.72918 47.0056Z",fill:"#6E79F1"}),r().createElement("path",{d:"M19.8241 22.0951C20.5697 21.7475 21.4308 21.7475 22.1763 22.0951L40.295 30.5426C41.3664 31.0422 41.3664 32.5656 40.295 33.0652L22.1763 41.5127C21.4308 41.8603 20.5697 41.8603 19.8241 41.5127L1.70551 33.0652C0.63407 32.5656 0.63407 31.0422 1.70551 30.5426L19.8241 22.0951Z",fill:"#9079F7",fillOpacity:"0.3"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.21539 33.7691L1.70551 33.0652C0.634068 32.5656 0.634071 31.0422 1.70551 30.5426L3.2154 29.8387L3.68022 30.8356L2.17033 31.5396C1.9458 31.6443 1.94581 31.9635 2.17033 32.0682L3.68021 32.7722L3.21539 33.7691ZM4.72528 29.1347L5.1901 30.1317L8.20988 28.7238L7.74505 27.7268L4.72528 29.1347ZM9.25494 27.0228L9.71976 28.0198L12.7395 26.6119L12.2747 25.6149L9.25494 27.0228ZM13.7846 24.911L14.2494 25.9079L17.2692 24.5L16.8044 23.503L13.7846 24.911ZM18.3143 22.7991L18.7791 23.7961L20.289 23.0921C20.7399 22.8819 21.2606 22.8819 21.7115 23.0921L23.2214 23.7961L23.6862 22.7991L22.1763 22.0951C21.4308 21.7475 20.5697 21.7475 19.8241 22.0951L18.3143 22.7991ZM25.1961 23.503L24.7313 24.5L27.7511 25.9079L28.2159 24.911L25.1961 23.503ZM29.7258 25.6149L29.261 26.6119L32.2807 28.0198L32.7455 27.0228L29.7258 25.6149ZM34.2554 27.7268L33.7906 28.7238L36.8104 30.1317L37.2752 29.1347L34.2554 27.7268ZM38.7851 29.8387L38.3203 30.8356L39.8302 31.5396C40.0547 31.6443 40.0547 31.9635 39.8302 32.0682L38.3203 32.7722L38.7851 33.7691L40.295 33.0652C41.3664 32.5656 41.3664 31.0422 40.295 30.5426L38.7851 29.8387ZM37.2752 34.4731L36.8104 33.4761L33.7906 34.884L34.2554 35.881L37.2752 34.4731ZM32.7455 36.585L32.2807 35.588L29.261 36.9959L29.7258 37.9929L32.7455 36.585ZM28.2159 38.6968L27.7511 37.6999L24.7313 39.1078L25.1961 40.1048L28.2159 38.6968ZM23.6862 40.8087L23.2214 39.8117L21.7115 40.5157C21.2606 40.7259 20.7399 40.7259 20.289 40.5157L18.7791 39.8117L18.3143 40.8087L19.8241 41.5127C20.5697 41.8603 21.4308 41.8603 22.1763 41.5127L23.6862 40.8087ZM16.8044 40.1048L17.2692 39.1078L14.2494 37.6999L13.7846 38.6968L16.8044 40.1048ZM12.2747 37.9929L12.7395 36.9959L9.71976 35.588L9.25494 36.585L12.2747 37.9929ZM7.74505 35.881L8.20987 34.884L5.1901 33.4761L4.72528 34.4731L7.74505 35.881Z",fill:"#8268F6"}),r().createElement("path",{d:"M20.6103 10.9768C21.364 10.6201 22.238 10.6201 22.9918 10.9768L40.8134 19.4125C41.8751 19.915 41.8751 21.4256 40.8134 21.9281L22.9918 30.3638C22.238 30.7206 21.364 30.7206 20.6103 30.3638L2.78864 21.9281C1.72698 21.4256 1.72698 19.915 2.78864 19.4125L20.6103 10.9768Z",fill:"#C2B4FF",fillOpacity:"0.3"}),r().createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M4.27378 22.6311L2.78864 21.9281C1.72698 21.4256 1.72698 19.915 2.78864 19.4125L4.27378 18.7095L4.74439 19.7037L3.25926 20.4067C3.03678 20.512 3.03678 20.8286 3.25926 20.9339L4.74439 21.6369L4.27378 22.6311ZM5.75891 18.0065L6.22953 19.0008L9.1998 17.5948L8.72918 16.6006L5.75891 18.0065ZM10.2143 15.8976L10.6849 16.8919L13.6552 15.4859L13.1846 14.4917L10.2143 15.8976ZM14.6697 13.7887L15.1403 14.783L18.1106 13.377L17.64 12.3828L14.6697 13.7887ZM19.1251 11.6798L19.5957 12.6741L21.0809 11.9711C21.5367 11.7553 22.0653 11.7553 22.5212 11.9711L24.0063 12.6741L24.4769 11.6798L22.9918 10.9768C22.238 10.6201 21.364 10.6201 20.6103 10.9768L19.1251 11.6798ZM25.9621 12.3828L25.4914 13.377L28.4617 14.783L28.9323 13.7887L25.9621 12.3828ZM30.4175 14.4917L29.9468 15.4859L32.9171 16.8919L33.3877 15.8976L30.4175 14.4917ZM34.8729 16.6006L34.4023 17.5948L37.3725 19.0008L37.8431 18.0065L34.8729 16.6006ZM39.3283 18.7095L38.8577 19.7037L40.3428 20.4067C40.5653 20.512 40.5653 20.8286 40.3428 20.9339L38.8577 21.6369L39.3283 22.6311L40.8134 21.9281C41.8751 21.4256 41.8751 19.915 40.8134 19.4125L39.3283 18.7095ZM37.8431 23.3341L37.3725 22.3398L34.4022 23.7458L34.8729 24.74L37.8431 23.3341ZM33.3877 25.443L32.9171 24.4487L29.9468 25.8547L30.4175 26.8489L33.3877 25.443ZM28.9323 27.5519L28.4617 26.5576L25.4914 27.9636L25.9621 28.9578L28.9323 27.5519ZM24.4769 29.6608L24.0063 28.6666L22.5212 29.3695C22.0653 29.5853 21.5367 29.5853 21.0809 29.3695L19.5957 28.6666L19.1251 29.6608L20.6103 30.3638C21.364 30.7206 22.238 30.7206 22.9918 30.3638L24.4769 29.6608ZM17.64 28.9578L18.1106 27.9636L15.1403 26.5576L14.6697 27.5519L17.64 28.9578ZM13.1846 26.8489L13.6552 25.8547L10.6849 24.4487L10.2143 25.443L13.1846 26.8489ZM8.72918 24.74L9.1998 23.7458L6.22953 22.3398L5.75891 23.3341L8.72918 24.74Z",fill:"#AC9AFF"})),ts=S().div`
  padding: 24px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  gap: 8px;

  .title {
    font-size: 15px;
    font-weight: 700;
    color: var(--text-detail);
  }

  .description {
    font-size: 13px;
    font-weight: 400;
    color: var(--text-detail);
  }

  .button {
    margin-top: 6px;
  }
`,ns=()=>r().createElement(ts,null,r().createElement("div",{className:"icon"},es),r().createElement("div",{className:"title"},"No dataset changed"),r().createElement("div",{className:"description"},"Datasets with changes in the ",r().createElement("br",null),"'dataset-staged' folder will be displayed."),r().createElement(Ho,{className:"button",onClick:()=>Qi.activateFileBrowser()},Pe," Go to file browser")),as=({interval:e,refresh:t})=>{const[n,l]=(0,a.useState)(!1),[o,i]=(0,a.useState)(e),[s,c]=(0,a.useState)();async function d(){l(!0),await t(),l(!1)}async function p(){await d(),i(e);const t=setInterval((async()=>{i((n=>{const a=n-1;return 0===a&&(clearInterval(t),d().finally((()=>{i(e),p()}))),a}))}),1e3);c(t)}return(0,a.useEffect)((()=>(p(),()=>{s&&clearInterval(s)})),[]),r().createElement("svg",{width:"22",height:"22",viewBox:"0 0 22 22",fill:"none",xmlns:"http://www.w3.org/2000/svg",onClick:function(){n||(s&&clearInterval(s),p())},style:{cursor:n?"not-allowed":"pointer"}},r().createElement("path",{d:"M11 19C8.76667 19 6.875 18.225 5.325 16.675C3.775 15.125 3 13.2333 3 11C3 8.76667 3.775 6.875 5.325 5.325C6.875 3.775 8.76667 3 11 3C12.15 3 13.25 3.2375 14.3 3.7125C15.35 4.1875 16.25 4.86667 17 5.75V4.26984H19V10H14.5397V8H16.2C15.6667 7.06667 14.9375 6.33333 14.0125 5.8C13.0875 5.26667 12.0833 5 11 5C9.33333 5 7.91667 5.58333 6.75 6.75C5.58333 7.91667 5 9.33333 5 11C5 12.6667 5.58333 14.0833 6.75 15.25C7.91667 16.4167 9.33333 17 11 17C12.2833 17 13.4417 16.6333 14.475 15.9C15.5083 15.1667 16.2333 14.2 16.65 13H18.75C18.2833 14.7667 17.3333 16.2083 15.9 17.325C14.4667 18.4417 12.8333 19 11 19Z",fill:"#77758A",stroke:"#EFEFF5",strokeWidth:"0.571429"},n&&r().createElement("animateTransform",{attributeType:"xml",attributeName:"transform",type:"rotate",dur:"1s",from:"0 11 11",to:"360 11 11",additive:"sum",repeatCount:"indefinite"})),!n&&r().createElement("text",{x:"50%",y:"50%",textAnchor:"middle",dominantBaseline:"central",fill:"#9291A1",fontSize:"10px",fontWeight:"bold"},o))},rs=new Set(["added","edited","deleted"]);function ls(e){return e.data_snapshot_versions.reduce(((e,t)=>e.version>t.version?e:t),{version:0})}function os(e){switch(e){case"added":return"added";case"deleted":return"deleted";default:return"modified"}}function is(e){const t=ls(e);if(!("status"in t))return"none";switch(t.status){case"processing":return"uploading";case"error":return"failed";default:return"none"}}const ss=S().div`
  * {
    box-sizing: border-box;
  }

  width: 100%;
  min-width: 370px;
  height: 100%;
  color: var(--text-primary);

  font-size: 13px;
  line-height: 17px;
  font-weight: 300;

  display: flex;
  flex-direction: column;

  /* delete default styles for list */
  ol,
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }

  main {
    height: 100%;
    overflow: auto;

    padding: 0px 12px 8px 12px;
    background-color: var(--background-base);
    flex: 1;

    display: flex;
    flex-direction: column;
    gap: 12px;

    section {
      width: 100%;

      .section-title {
        height: 35px;
        line-height: 27px;
        padding-top: 8px;
        font-size: 13px;
        font-weight: 500;
        border-bottom: 1px solid var(--border-primary);
        display: flex;
        justify-content: space-between;

        position: sticky;
        top: 0;
        background-color: var(--background-base);
        z-index: 10;

        .refresh-timer {
          width: 24px;
          height: 24px;
          border-radius: 4px;
          display: flex;
          justify-content: center;
          align-items: center;
          background-color: var(--badge-counter-background);
          color: var(--badge-counter-text);
        }
      }
    }
  }
`;function cs(e){return e.changed.length>0||"uploading"===e.uploadingStatus}const ds=()=>{const[e,t]=(0,a.useState)([]),n=(0,a.useMemo)((()=>e.filter((e=>cs(e)))),[e]),l=(0,a.useMemo)((()=>e.filter((e=>!cs(e)))),[e]);async function o(){return await async function(){return function(e,t){const n=[...e];return t.forEach((e=>{const t=n.findIndex((t=>t.name===e.name));-1!==t?n[t]=Object.assign(Object.assign({},e),{id:n[t].id,uploadingStatus:n[t].uploadingStatus}):n.push(e)})),n}(await async function(){return(await zn().catch((e=>[]))).map((e=>({id:e.id,name:e.name,version:ls(e).version,uploadingStatus:is(e),changed:[]})))}(),await async function(){return(await async function(){return fetch(`${Hn}/dataset/diff`,{method:"GET",headers:Rn}).then((e=>e.json().then((e=>e.datasets||[])).catch((e=>[]))))}().catch((e=>[]))).map((e=>({id:-1,name:e.dataset_name,version:e.current_version,uploadingStatus:"none",changed:e.changes.filter((e=>rs.has(e.status))).map((e=>({path:e.path,status:os(e.status)})))})))}()).sort(((e,t)=>e.name<t.name?-1:1))}().then((e=>t(e))).catch((e=>t([])))}return(0,a.useEffect)((()=>{var e;e=n.length>0,ms&&(ms.title.icon=e?vi:gi)}),[n]),r().createElement(ss,null,r().createElement(Ni,null),r().createElement("main",null,r().createElement("section",null,r().createElement("div",{className:"section-title"},"Changed",r().createElement("div",{className:"refresh-timer"},r().createElement(as,{interval:5,refresh:o}))),n.length>0?r().createElement("ul",{className:"dataset-list"},n.map((e=>r().createElement(Xi,{key:e.name,dataset:e,refreshDatasets:o})))):r().createElement(ns,null)),r().createElement("section",null,r().createElement("div",{className:"section-title"},"Unchanged"),r().createElement("ul",{className:"dataset-list"},l.map((e=>r().createElement(Xi,{key:e.name,dataset:e})))))))},ps=function(){const e=$.ReactWidget.create(r().createElement(ds,null));return e.id="link-dataset",e.title.caption="dataset versioning",e.title.icon=gi,e}(),ms=ps,us={id:"link-dataset",requires:[W.ILabShell,ui.IFileBrowserFactory],autoStart:!0,activate:async function(e,t,n){Qi.setLabShell(t);let a=null;y.subscribe((async()=>{y.value?(a=ms,t.add(a,"left",{rank:201})):(null==a||a.dispose(),a=null)})),hi.registerFileBrowserFactory(n)}},hs=()=>{const{requiredToUpdateLink:e,latestLinkVersion:t,openDialogToUpdateLink:n,DialogToUpdateLink:l}=wo();return(0,a.useEffect)((()=>{e&&t&&n()}),[e,t]),r().createElement(l,null)},gs=(0,_.x)((()=>y.value?r().createElement(hs,null):null)),vs=[D,pi,us,{id:"link-version-checker",requires:[],autoStart:!0,activate:async function(e){const t=document.createElement("div");t.id="version-checker-root",document.body.appendChild(t),(0,l.H)(t).render(r().createElement(gs,null))}}]},39371:e=>{e.exports="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADsSURBVEhLY2AYBfQMgf///3P8+/evAIgvA/FsIF+BavYDDWMBGroaSMMBiE8VC7AZDrIFaMFnii3AZTjUgsUUWUDA8OdAH6iQbQEhw4HyGsPEcKBXBIC4ARhex4G4BsjmweU1soIFaGg/WtoFZRIZdEvIMhxkCCjXIVsATV6gFGACs4Rsw0EGgIIH3QJYJgHSARQZDrWAB+jawzgs+Q2UO49D7jnRSRGoEFRILcdmEMWGI0cm0JJ2QpYA1RDvcmzJEWhABhD/pqrL0S0CWuABKgnRki9lLseS7g2AlqwHWQSKH4oKLrILpRGhEQCw2LiRUIa4lwAAAABJRU5ErkJggg=="},57389:e=>{e.exports="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGYSURBVEhL5ZSvTsNQFMbXZGICMYGYmJhAQIJAICYQPAACiSDB8AiICQQJT4CqQEwgJvYASAQCiZiYmJhAIBATCARJy+9rTsldd8sKu1M0+dLb057v6/lbq/2rK0mS/TRNj9cWNAKPYIJII7gIxCcQ51cvqID+GIEX8ASG4B1bK5gIZFeQfoJdEXOfgX4QAQg7kH2A65yQ87lyxb27sggkAzAuFhbbg1K2kgCkB1bVwyIR9m2L7PRPIhDUIXgGtyKw575yz3lTNs6X4JXnjV+LKM/m3MydnTbtOKIjtz6VhCBq4vSm3ncdrD2lk0VgUXSVKjVDJXJzijW1RQdsU7F77He8u68koNZTz8Oz5yGa6J3H3lZ0xYgXBK2QymlWWA+RWnYhskLBv2vmE+hBMCtbA7KX5drWyRT/2JsqZ2IvfB9Y4bWDNMFbJRFmC9E74SoS0CqulwjkC0+5bpcV1CZ8NMej4pjy0U+doDQsGyo1hzVJttIjhQ7GnBtRFN1UarUlH8F3xict+HY07rEzoUGPlWcjRFRr4/gChZgc3ZL2d8oAAAAASUVORK5CYII="},86138:e=>{e.exports="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGwSURBVEhLtZa9SgNBEMc9sUxxRcoUKSzSWIhXpFMhhYWFhaBg4yPYiWCXZxBLERsLRS3EQkEfwCKdjWJAwSKCgoKCcudv4O5YLrt7EzgXhiU3/4+b2ckmwVjJSpKkQ6wAi4gwhT+z3wRBcEz0yjSseUTrcRyfsHsXmD0AmbHOC9Ii8VImnuXBPglHpQ5wwSVM7sNnTG7Za4JwDdCjxyAiH3nyA2mtaTJufiDZ5dCaqlItILh1NHatfN5skvjx9Z38m69CgzuXmZgVrPIGE763Jx9qKsRozWYw6xOHdER+nn2KkO+Bb+UV5CBN6WC6QtBgbRVozrahAbmm6HtUsgtPC19tFdxXZYBOfkbmFJ1VaHA1VAHjd0pp70oTZzvR+EVrx2Ygfdsq6eu55BHYR8hlcki+n+kERUFG8BrA0BwjeAv2M8WLQBtcy+SD6fNsmnB3AlBLrgTtVW1c2QN4bVWLATaIS60J2Du5y1TiJgjSBvFVZgTmwCU+dAZFoPxGEEs8nyHC9Bwe2GvEJv2WXZb0vjdyFT4Cxk3e/kIqlOGoVLwwPevpYHT+00T+hWwXDf4AJAOUqWcDhbwAAAAASUVORK5CYII="},98663:e=>{e.exports="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAHOSURBVEhLrZa/SgNBEMZzh0WKCClSCKaIYOED+AAKeQQLG8HWztLCImBrYadgIdY+gIKNYkBFSwu7CAoqCgkkoGBI/E28PdbLZmeDLgzZzcx83/zZ2SSXC1j9fr+I1Hq93g2yxH4iwM1vkoBWAdxCmpzTxfkN2RcyZNaHFIkSo10+8kgxkXIURV5HGxTmFuc75B2RfQkpxHG8aAgaAFa0tAHqYFfQ7Iwe2yhODk8+J4C7yAoRTWI3w/4klGRgR4lO7Rpn9+gvMyWp+uxFh8+H+ARlgN1nJuJuQAYvNkEnwGFck18Er4q3egEc/oO+mhLdKgRyhdNFiacC0rlOCbhNVz4H9FnAYgDBvU3QIioZlJFLJtsoHYRDfiZoUyIxqCtRpVlANq0EU4dApjrtgezPFad5S19Wgjkc0hNVnuF4HjVA6C7QrSIbylB+oZe3aHgBsqlNqKYH48jXyJKMuAbiyVJ8KzaB3eRc0pg9VwQ4niFryI68qiOi3AbjwdsfnAtk0bCjTLJKr6mrD9g8iq/S/B81hguOMlQTnVyG40wAcjnmgsCNESDrjme7wfftP4P7SP4N3CJZdvzoNyGq2c/HWOXJGsvVg+RA/k2MC/wN6I2YA2Pt8GkAAAAASUVORK5CYII="}}]);