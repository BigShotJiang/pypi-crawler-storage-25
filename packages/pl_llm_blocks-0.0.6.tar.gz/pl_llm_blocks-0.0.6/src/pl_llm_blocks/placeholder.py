def placeholder() -> None:
    pass
