<!-- mcp-name: io.github.onetrueclaude-creator/mcp-curiosity-engine -->

# mcp-curiosity-engine

**Surface the notes you forgot you wrote — DMN replay for markdown vaults.**

Surface the notes you've forgotten you wrote. Uses wikilink graph
structure + file mtime to identify dormant notes (low link-in count,
old, isolated) and the DMN-inspired replay cycle pattern from
cognitive neuroscience: sample dormant notes with bias (40% random /
30% least-linked / 30% orphaned), generate cross-domain bridge
queries between them, and surface the unexpected connections. Breaks
the confirmation-bias loop where you only revisit the notes you
already remember.


## Install

```bash
pip install mcp-curiosity-engine
# or
uvx mcp-curiosity-engine
```

## Usage

### Claude Code

```bash
claude mcp add mcp-curiosity-engine -- mcp-curiosity-engine
```

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "curiosity_engine": {
      "command": "uvx",
      "args": ["mcp-curiosity-engine"]
    }
  }
}
```

## MCP Tools

| Tool | Tier | Description |
|------|------|-------------|
| `find_dormant_notes` | Free | List notes that are structurally dormant — low incoming wikilink count AND old mtime. These are the notes most at risk of being forgotten. |
| `find_orphan_notes` | Free | List notes with zero incoming wikilinks — structurally isolated, the extreme case of dormancy. |
| `suggest_replay_cycle` | **Pro** | Run the full DMN-inspired replay cycle: sample dormant notes with bias (40% random / 30% least-linked / 30% orphans), extract their concepts, generate cross-domain bridge queries between them, return notes to revisit. The core moat. |
| `find_cross_domain_bridges` | **Pro** | Surface pairs of notes from DIFFERENT top-level directories that share concepts. These are the surprise connections — ideas that span your vault's silos. |
| `random_deep_cut` | **Pro** | Pull a single random dormant note for serendipitous rediscovery. Think of it as your vault's shuffle-play button. |


## Pro tier

Unlocks the full DMN replay cycle, cross-domain bridge discovery, and random deep-cut sampling.

License activation — any one of these works:

```bash
# 1. Environment variable
export CURIOSITY_ENGINE_LICENSE="eyJhbGc..."

# 2. CLI flag
mcp-curiosity-engine --license-key "eyJhbGc..."

# 3. Config file
echo "eyJhbGc..." > ~/.mcp-curiosity-engine/license.jwt
```

Licenses are verified fully offline — no phone-home, no activation server. Get a license at **https://github.com/onetrueclaude-creator/mcp-curiosity-engine#pro-tier**.

## Requirements

- Python 3.10+

## License

MIT
