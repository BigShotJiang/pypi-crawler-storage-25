"""mcp-curiosity-engine MCP Server.

Surface the notes you forgot you wrote. Graph-structural replay for markdown
vaults — no persistent tracking state required.
"""
import json
import time
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

from .license import License, require_feature_error
from .replay import (
    compute_dormancy,
    find_bridges,
    find_dormant,
    find_orphans,
    random_deep_cut,
    run_replay_cycle,
)
from .vault_graph import load_vault_graph

_license: License | None = None


def set_license(license: License | None) -> None:
    global _license
    _license = license


mcp_server = FastMCP(
    "mcp-curiosity-engine",
    instructions="Surface the notes you forgot you wrote — DMN replay for markdown vaults.",
)


@mcp_server.custom_route("/health", methods=["GET"])
async def health_check(request: Request) -> JSONResponse:
    return JSONResponse({"status": "healthy"})


def _validate_vault(vault_path: str) -> dict | None:
    p = Path(vault_path).expanduser()
    if not p.exists():
        return {"error": f"vault_path does not exist: {vault_path}", "status": "bad_request"}
    if not p.is_dir():
        return {"error": f"vault_path is not a directory: {vault_path}", "status": "bad_request"}
    return None


def _dormancy_to_dict(s) -> dict:
    return {
        "note_id": s.note_id,
        "title": s.title,
        "bucket": s.bucket,
        "incoming_links": s.incoming_links,
        "age_days": s.age_days,
        "dormancy_score": s.score,
    }


@mcp_server.tool(name="find_dormant_notes", annotations={"readOnlyHint": True})
def tool_find_dormant_notes(vault_path: str, max_inlinks: int = 1, limit: int = 20) -> str:
    """List notes that are structurally dormant — low incoming wikilink count AND old mtime.
    These are the notes most at risk of being forgotten."""
    err = _validate_vault(vault_path)
    if err:
        return json.dumps(err, indent=2)

    graph = load_vault_graph(vault_path)
    dormant = find_dormant(graph, max_inlinks=max_inlinks, limit=limit)
    return json.dumps({
        "vault_path": str(Path(vault_path).expanduser().resolve()),
        "total_notes": graph.total_notes,
        "max_inlinks_threshold": max_inlinks,
        "returned": len(dormant),
        "dormant_notes": [_dormancy_to_dict(s) for s in dormant],
    }, indent=2)


@mcp_server.tool(name="find_orphan_notes", annotations={"readOnlyHint": True})
def tool_find_orphan_notes(vault_path: str, limit: int = 30) -> str:
    """List notes with zero incoming wikilinks — structurally isolated."""
    err = _validate_vault(vault_path)
    if err:
        return json.dumps(err, indent=2)

    graph = load_vault_graph(vault_path)
    orphans = find_orphans(graph, limit=limit)
    return json.dumps({
        "vault_path": str(Path(vault_path).expanduser().resolve()),
        "total_notes": graph.total_notes,
        "total_orphans": sum(1 for n in graph.notes.values() if n.incoming_links == 0),
        "returned": len(orphans),
        "orphan_notes": [_dormancy_to_dict(s) for s in orphans],
    }, indent=2)


@mcp_server.tool(name="suggest_replay_cycle", annotations={"readOnlyHint": True})
def tool_suggest_replay_cycle(vault_path: str, sample_size: int = 10, seed: int = 0) -> str:
    """[Pro] Run the full DMN-inspired replay cycle: sample dormant notes with bias,
    extract their concepts, generate cross-domain bridge queries, return notes to revisit."""
    if _license is None or not _license.has_feature("replay_cycle"):
        return json.dumps(require_feature_error("replay_cycle"), indent=2)

    err = _validate_vault(vault_path)
    if err:
        return json.dumps(err, indent=2)

    graph = load_vault_graph(vault_path)
    seed_arg = seed if seed != 0 else None
    cycle = run_replay_cycle(graph, sample_size=sample_size, seed=seed_arg)
    cycle["vault_path"] = str(Path(vault_path).expanduser().resolve())
    cycle["sample_strategy"] = "40% random / 30% least-linked / 30% orphans"
    return json.dumps(cycle, indent=2)


@mcp_server.tool(name="find_cross_domain_bridges", annotations={"readOnlyHint": True})
def tool_find_cross_domain_bridges(vault_path: str, limit: int = 10) -> str:
    """[Pro] Surface pairs of notes from DIFFERENT top-level directories that share a concept.
    These are the surprise connections — ideas that span your vault's silos."""
    if _license is None or not _license.has_feature("bridge_discovery"):
        return json.dumps(require_feature_error("bridge_discovery"), indent=2)

    err = _validate_vault(vault_path)
    if err:
        return json.dumps(err, indent=2)

    graph = load_vault_graph(vault_path)
    bridges = find_bridges(graph, limit=limit)
    return json.dumps({
        "vault_path": str(Path(vault_path).expanduser().resolve()),
        "total_notes": graph.total_notes,
        "total_buckets": len(graph.buckets),
        "returned": len(bridges),
        "bridges": bridges,
    }, indent=2)


@mcp_server.tool(name="random_deep_cut", annotations={"readOnlyHint": True})
def tool_random_deep_cut(vault_path: str, seed: int = 0) -> str:
    """[Pro] Pull a single random dormant note for serendipitous rediscovery.
    Your vault's shuffle-play button."""
    if _license is None or not _license.has_feature("random_deep_cut"):
        return json.dumps(require_feature_error("random_deep_cut"), indent=2)

    err = _validate_vault(vault_path)
    if err:
        return json.dumps(err, indent=2)

    graph = load_vault_graph(vault_path)
    seed_arg = seed if seed != 0 else None
    note = random_deep_cut(graph, seed=seed_arg)

    if note is None:
        return json.dumps({"status": "empty_vault"}, indent=2)

    return json.dumps({
        "vault_path": str(Path(vault_path).expanduser().resolve()),
        "note": {
            "note_id": note.note_id,
            "title": note.title,
            "bucket": note.bucket,
            "incoming_links": note.incoming_links,
            "age_days": round((time.time() - note.mtime) / 86400.0, 1),
            "path": str(note.path),
            "concepts": note.concepts[:5],
        },
        "suggestion": "Open this note and spend 2 minutes re-reading it. You wrote it — what did you intend?",
    }, indent=2)
