"""Surface the notes you've forgotten you wrote. Uses wikilink graph
structure + file mtime to identify dormant notes (low link-in count,
old, isolated) and the DMN-inspired replay cycle pattern from
cognitive neuroscience: sample dormant notes with bias (40% random /
30% least-linked / 30% orphaned), generate cross-domain bridge
queries between them, and surface the unexpected connections. Breaks
the confirmation-bias loop where you only revisit the notes you
already remember.
"""
__version__ = "0.1.0"
