"""DMN-inspired replay cycle.

Ported from Gnosia's engine/curiosity.py, generalized to use wikilink graph
structure + file mtime instead of retrieval_count / decay_factor. Works on
any markdown vault with no persistent tracking state required — just the
graph you already have.

Core idea: revisiting only the notes you already remember reinforces what
you already know. This engine surfaces DORMANT notes (few inbound links,
old mtimes) with biased sampling and cross-domain bridge generation, so
the user can break their own confirmation-bias loop.
"""
from __future__ import annotations

import random
import time
from dataclasses import dataclass
from itertools import combinations

from .vault_graph import Note, VaultGraph


@dataclass
class DormancyScore:
    note_id: str
    title: str
    bucket: str
    incoming_links: int
    age_days: float
    score: float


def compute_dormancy(graph: VaultGraph) -> list[DormancyScore]:
    """Score each note for dormancy. Higher score = MORE dormant.

    Dormancy = (1 / (incoming_links + 1)) * (age_days ** 0.5)

    A note with 0 incoming links, 100 days old scores ≈ 1.0 * 10 = 10.
    A note with 5 incoming links, 30 days old scores ≈ 0.17 * 5.5 = 0.92.
    A brand new orphan: 1.0 * 1 = 1.0.
    """
    now = time.time()
    scores: list[DormancyScore] = []
    for n in graph.notes.values():
        age_days = max(1.0, (now - n.mtime) / 86400.0)
        inlinks = n.incoming_links
        score = (1.0 / (inlinks + 1)) * (age_days ** 0.5)
        scores.append(DormancyScore(
            note_id=n.note_id,
            title=n.title,
            bucket=n.bucket,
            incoming_links=inlinks,
            age_days=round(age_days, 1),
            score=round(score, 3),
        ))
    scores.sort(key=lambda s: -s.score)
    return scores


def find_dormant(graph: VaultGraph, max_inlinks: int = 1, limit: int = 20) -> list[DormancyScore]:
    """Return notes with <= max_inlinks incoming links, ranked by dormancy score."""
    scores = compute_dormancy(graph)
    dormant = [s for s in scores if s.incoming_links <= max_inlinks]
    return dormant[:limit]


def find_orphans(graph: VaultGraph, limit: int = 30) -> list[DormancyScore]:
    """Return notes with ZERO incoming links — maximally isolated."""
    scores = compute_dormancy(graph)
    return [s for s in scores if s.incoming_links == 0][:limit]


def biased_sample(graph: VaultGraph, n: int = 10, seed: int | None = None) -> list[Note]:
    """DMN-inspired sampling: 40% random / 30% least-linked / 30% orphans.

    Generalized from Gnosia's retrieval_count + decay_factor strategy.
    Here "least-linked" replaces "least-retrieved" and "orphan" replaces
    "at-risk" — both are purely graph-structural and don't need state.
    """
    all_notes = list(graph.notes.values())
    if not all_notes:
        return []
    if len(all_notes) <= n:
        return all_notes[:n]

    rng = random.Random(seed) if seed is not None and seed != 0 else random

    samples: dict[str, Note] = {}

    # 40% random
    k_random = max(1, n * 4 // 10)
    for note in rng.sample(all_notes, min(k_random, len(all_notes))):
        samples[note.note_id] = note

    # 30% least-linked (by incoming_links ascending)
    target = n * 7 // 10
    by_inlinks = sorted(all_notes, key=lambda nt: nt.incoming_links)
    for note in by_inlinks:
        if len(samples) >= target:
            break
        samples[note.note_id] = note

    # 30% orphans (zero incoming, sorted by oldest — most at-risk)
    orphans = [nt for nt in all_notes if nt.incoming_links == 0]
    orphans.sort(key=lambda nt: nt.mtime)  # oldest first
    for note in orphans:
        if len(samples) >= n:
            break
        samples[note.note_id] = note

    # Top up with random if we're still short
    while len(samples) < n:
        note = rng.choice(all_notes)
        samples[note.note_id] = note

    return list(samples.values())[:n]


def generate_bridge_queries(sampled: list[Note]) -> list[dict]:
    """Generate cross-bucket bridge queries between sampled notes.

    For each pair of sampled notes FROM DIFFERENT BUCKETS, if both have
    at least one concept, emit a query combining one concept from each.
    These are the "unexpected bridges" — connections between vault silos.
    """
    queries: list[dict] = []
    for a, b in combinations(sampled, 2):
        if a.bucket == b.bucket:
            continue
        if not a.concepts or not b.concepts:
            continue
        c_a = a.concepts[0]
        c_b = b.concepts[0]
        queries.append({
            "type": "bridge",
            "query": f"{c_a} {c_b}",
            "source_a": a.note_id,
            "source_b": b.note_id,
            "bucket_a": a.bucket,
            "bucket_b": b.bucket,
        })
    return queries


def generate_recall_queries(sampled: list[Note]) -> list[dict]:
    """Single-note recall queries from top concepts of each sampled note."""
    queries: list[dict] = []
    for n in sampled:
        if not n.concepts:
            continue
        top_concepts = n.concepts[:3]
        queries.append({
            "type": "recall",
            "query": " ".join(top_concepts),
            "source": n.note_id,
            "title": n.title,
            "bucket": n.bucket,
        })
    return queries


def find_bridges(graph: VaultGraph, limit: int = 10) -> list[dict]:
    """Scan the concept index for concepts that appear in multiple BUCKETS.

    A "bridge" is a concept shared across different top-level folders —
    an idea that spans your vault's silos. Returns pairs of notes that
    co-reference such bridging concepts.
    """
    bridges: list[dict] = []
    seen_pairs: set[tuple[str, str]] = set()

    for concept, note_ids in graph.concept_index.items():
        if len(note_ids) < 2:
            continue
        # Build the list of (bucket, note_id) tuples
        bucket_map: dict[str, str] = {}
        for nid in note_ids:
            n = graph.notes.get(nid)
            if not n:
                continue
            # Keep only ONE representative per bucket per concept
            bucket_map.setdefault(n.bucket, nid)
        if len(bucket_map) < 2:
            continue
        # Emit all cross-bucket pairs
        items = list(bucket_map.items())
        for (b1, n1), (b2, n2) in combinations(items, 2):
            pair_key = tuple(sorted([n1, n2]))
            if pair_key in seen_pairs:
                continue
            seen_pairs.add(pair_key)
            note_a = graph.notes[n1]
            note_b = graph.notes[n2]
            bridges.append({
                "concept": concept,
                "note_a": {"id": n1, "title": note_a.title, "bucket": b1},
                "note_b": {"id": n2, "title": note_b.title, "bucket": b2},
            })

    # Prioritize bridges where the concept is rare (more interesting signal)
    bridges.sort(
        key=lambda br: len(graph.concept_index.get(br["concept"], set()))
    )
    return bridges[:limit]


def random_deep_cut(graph: VaultGraph, seed: int | None = None) -> Note | None:
    """Pick a single random dormant note (≤1 incoming link) for serendipitous
    rediscovery."""
    candidates = [n for n in graph.notes.values() if n.incoming_links <= 1]
    if not candidates:
        # Fallback: any note
        candidates = list(graph.notes.values())
    if not candidates:
        return None
    rng = random.Random(seed) if seed is not None and seed != 0 else random
    return rng.choice(candidates)


def run_replay_cycle(graph: VaultGraph, sample_size: int = 10, seed: int | None = None) -> dict:
    """Execute the full DMN replay cycle.

    Phases:
      1. Sample with bias (40/30/30 random/least-linked/orphan)
      2. Generate recall queries from each sampled note
      3. Generate bridge queries between pairs from different buckets
      4. Return everything as a structured suggestion bundle
    """
    sampled = biased_sample(graph, n=sample_size, seed=seed)
    recall_qs = generate_recall_queries(sampled)
    bridge_qs = generate_bridge_queries(sampled)

    return {
        "sampled_notes": [
            {
                "note_id": n.note_id,
                "title": n.title,
                "bucket": n.bucket,
                "incoming_links": n.incoming_links,
                "age_days": round((time.time() - n.mtime) / 86400.0, 1),
                "concepts": n.concepts[:5],
            }
            for n in sampled
        ],
        "recall_queries": recall_qs,
        "bridge_queries": bridge_qs,
        "total_notes_in_vault": graph.total_notes,
    }
