"""Vault structure loader — wikilink graph, file mtimes, tag/concept index.

Shared utility for all tools. Loads once per query; fast enough for vaults
up to a few thousand notes (dominates at ~10-30k for larger cases).
"""
from __future__ import annotations

import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path


_FRONTMATTER_RE = re.compile(r'^---\s*\n(.*?)\n---', re.DOTALL)
_TAGS_RE = re.compile(r'^tags:\s*\n((?:\s*-\s*[^\n]+\n)+)', re.MULTILINE)
_TAG_ITEM_RE = re.compile(r'^\s*-\s*(.+)$', re.MULTILINE)
_TITLE_RE = re.compile(r'^title:\s*"?(.+?)"?\s*$', re.MULTILINE)
_WIKILINK_RE = re.compile(r'\[\[([^\]|]+?)(?:\|[^\]]*)?\]\]')
_BOLD_RE = re.compile(r'\*\*(.+?)\*\*')


@dataclass
class Note:
    note_id: str           # filename stem
    path: Path
    title: str             # from frontmatter `title:` or filename stem
    bucket: str            # top-level directory (or "_root_")
    mtime: float           # file modification time
    concepts: list[str]    # lowercase: tags + top-5 bold terms + wikilink targets
    tags: list[str]
    outgoing_links: list[str]  # wikilink targets
    incoming_links: int = 0    # filled in after full graph load


@dataclass
class VaultGraph:
    notes: dict[str, Note]          # keyed by note_id
    # For bridge discovery — concept → set of note_ids that reference it
    concept_index: dict[str, set[str]]
    # For bucket diversity — bucket name → set of note_ids
    buckets: dict[str, set[str]]
    loaded_at: float = field(default_factory=time.time)

    @property
    def total_notes(self) -> int:
        return len(self.notes)

    def notes_in_bucket(self, bucket: str) -> list[Note]:
        return [self.notes[n] for n in self.buckets.get(bucket, set())]


def _normalize_concept(text: str) -> str:
    t = text.lower().strip()
    t = re.sub(r'\s+', ' ', t)
    return t


def _extract_frontmatter_tags(content: str) -> list[str]:
    """Pull tags from YAML frontmatter. Handles list-style (tags:\\n  - foo)
    and inline-style (tags: [foo, bar])."""
    fm = _FRONTMATTER_RE.match(content)
    if not fm:
        return []
    body = fm.group(1)
    # List style
    m = _TAGS_RE.search("\n" + body + "\n")
    if m:
        items = _TAG_ITEM_RE.findall(m.group(1))
        return [_normalize_concept(i) for i in items if i.strip()]
    # Inline style
    inline = re.search(r'^tags:\s*\[(.+?)\]', body, re.MULTILINE)
    if inline:
        return [_normalize_concept(x.strip().strip('"').strip("'"))
                for x in inline.group(1).split(",") if x.strip()]
    return []


def load_vault_graph(vault_path: Path | str) -> VaultGraph:
    """Build a graph of the vault: notes, wikilinks, concepts, buckets.

    Pass 1: read each file, parse metadata, record outgoing links.
    Pass 2: walk outgoing links to populate incoming_links counts.
    """
    vault = Path(vault_path).expanduser().resolve()
    notes: dict[str, Note] = {}
    concept_index: dict[str, set[str]] = defaultdict(set)
    buckets: dict[str, set[str]] = defaultdict(set)

    for f in vault.rglob("*.md"):
        try:
            content = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        try:
            rel = f.relative_to(vault)
            bucket = rel.parts[0] if len(rel.parts) > 1 else "_root_"
        except ValueError:
            bucket = "_root_"

        title_match = _TITLE_RE.search(content)
        title = title_match.group(1) if title_match else f.stem

        tags = _extract_frontmatter_tags(content)

        wikilinks = [_normalize_concept(w) for w in _WIKILINK_RE.findall(content)]

        # Top bold terms — skip label-style (trailing colon)
        bolds: list[str] = []
        for raw in _BOLD_RE.findall(content):
            raw = raw.strip()
            if not raw or raw[-1] in ":;,.!?" or ":" in raw:
                continue
            bolds.append(_normalize_concept(raw))

        bold_top5 = [c for c, _ in Counter(bolds).most_common(5)]

        # Concepts = tags (most curated) + top bold + outgoing wikilink targets
        concepts: list[str] = []
        seen = set()
        for src in (tags, bold_top5, wikilinks):
            for c in src:
                if c and c not in seen:
                    concepts.append(c)
                    seen.add(c)

        note = Note(
            note_id=f.stem,
            path=f,
            title=title.strip(),
            bucket=bucket,
            mtime=f.stat().st_mtime,
            concepts=concepts,
            tags=tags,
            outgoing_links=wikilinks,
        )
        notes[f.stem] = note
        buckets[bucket].add(f.stem)
        for c in concepts:
            concept_index[c].add(f.stem)

    # Pass 2: incoming link counts. Wikilinks target either a stem or a title —
    # match by normalized stem first, then by normalized title.
    title_to_id: dict[str, str] = {}
    for n in notes.values():
        title_to_id[_normalize_concept(n.title)] = n.note_id
        title_to_id[_normalize_concept(n.note_id)] = n.note_id

    for n in notes.values():
        for link in n.outgoing_links:
            target_id = title_to_id.get(link)
            if target_id and target_id != n.note_id and target_id in notes:
                notes[target_id].incoming_links += 1

    return VaultGraph(
        notes=notes,
        concept_index=dict(concept_index),
        buckets=dict(buckets),
    )
