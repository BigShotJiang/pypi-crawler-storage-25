# MahanAI Finale

Terminal AI agent using NVIDIA NIM (`integrate.api.nvidia.com`) with OpenAI-compatible chat, **streaming**, and **tools** (run shell commands, read/write files, list directories).

## Install

```bash
pip install mahanai-finale
mahanai
```

## API key

1. **Environment:** `MAHANAI_API_KEY=...`
2. **Project `.env`:** `MAHANAI_API_KEY=...`
3. **Saved config (persists):** inside the app run `/api-key your-key` or `/api-key` for a hidden prompt. Keys are stored under `%APPDATA%\MahanAI\config.json` on Windows or `~/.config/mahanai/config.json` on Linux/macOS.

Use this one for now: mai-api-91023847562910

## Optional

- `MAHANAI_MODEL` — model id from `GET https://integrate.api.nvidia.com/v1/models`
- `MAHANAI_STREAM=0` — disable streaming (wait for full replies)
- `MAHANAI_CONFIG_DIR` — override directory for `config.json`

## Commands

- `/exit` or `/quit` — leave
- `/api-key [key]` — save API key (omit `key` for prompt)
- `/api-key clear` — remove saved key from disk
- `/help` — short help

## Develop

```bash
pip install -e .
python -m mahanai
```

## Publish to PyPI

Bump `version` in `pyproject.toml` and `mahanai/__init__.py`, then:

```bash
pip install build twine
python -m build
python -m twine check dist/*
```

Upload **only** the new release files (example for v1.1.0):

**Windows (PowerShell)** — use an [API token](https://pypi.org/manage/account/token/) with “Entire account” or project scope:

```powershell
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = "pypi-YOUR_TOKEN_HERE"
python -m twine upload dist/mahanai_finale-1.1.0*
```

**macOS / Linux:**

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-YOUR_TOKEN_HERE
python -m twine upload dist/mahanai_finale-1.1.0*
```

`twine` cannot publish without your token; keep it out of git.
