"""Scripts for mood."""
