"""Data models for all extracted documentation artifacts."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class FileRole(Enum):
    BACKEND = "backend"
    FRONTEND = "frontend"
    CONFIG = "config"
    TEST = "test"
    MIGRATION = "migration"
    SHARED = "shared"
    UNKNOWN = "unknown"


class ParamSource(Enum):
    PATH = "path"
    QUERY = "query"
    HEADER = "header"
    BODY = "body"


@dataclass
class Param:
    name: str
    source: ParamSource
    type_hint: str | None = None
    required: bool = True


@dataclass
class APIEndpoint:
    repo: str
    file_path: str
    line: int
    http_method: str
    route_pattern: str
    handler_name: str
    framework: str
    parameters: list[Param] = field(default_factory=list)
    request_body_fields: list[str] = field(default_factory=list)
    response_fields: list[str] = field(default_factory=list)
    auth_decorators: list[str] = field(default_factory=list)
    db_tables: list[str] = field(default_factory=list)
    request_body_type: str | None = None
    response_type: str | None = None
    middleware: list[str] = field(default_factory=list)


@dataclass
class APICall:
    repo: str
    file_path: str
    line: int
    component_or_page: str
    http_method: str
    url_pattern: str
    client_library: str
    body_fields: list[str] = field(default_factory=list)
    traced_from: str | None = None
    response_type: str | None = None
    body_type: str | None = None


@dataclass
class Dependency:
    repo: str
    name: str
    version_constraint: str
    source_file: str
    dev_only: bool = False


@dataclass
class FileClassification:
    file_path: str
    role: FileRole
    language: str
    framework_hints: list[str] = field(default_factory=list)


@dataclass
class DBOperation:
    repo: str
    file_path: str
    line: int
    operation_type: str  # select, insert, update, delete
    table_name: str
    orm_library: str
    filters: list[str] = field(default_factory=list)


@dataclass
class ServiceRelationship:
    source_repo: str
    target_repo: str
    connection_type: str  # api_call, shared_db, shared_package
    source_file: str
    target_endpoint: str
    confidence: float = 0.0


@dataclass
class RepoDocumentation:
    repo_name: str
    repo_path: str
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    endpoints: list[APIEndpoint] = field(default_factory=list)
    api_calls: list[APICall] = field(default_factory=list)
    dependencies: list[Dependency] = field(default_factory=list)
    file_classifications: list[FileClassification] = field(default_factory=list)
    db_operations: list[DBOperation] = field(default_factory=list)
    service_relationships: list[ServiceRelationship] = field(default_factory=list)
