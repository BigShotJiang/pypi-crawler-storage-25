"""Rich terminal output for repository documentation."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.columns import Columns
from rich.tree import Tree as RichTree

from commiter.models import RepoDocumentation


def print_report(docs: list[RepoDocumentation], console: Console | None = None,
                 sections: dict[str, str | None] | None = None) -> None:
    """Print a formatted summary of all scanned repositories to the terminal."""
    if console is None:
        console = Console()

    for doc in docs:
        _print_repo(doc, console, sections)
        console.print()


def _show_section(sections: dict[str, str | None] | None, key: str) -> bool:
    """Check if a section should be shown based on the sections config."""
    if sections is None:
        return True
    return sections.get(key) is not None


def _print_repo(doc: RepoDocumentation, console: Console,
                sections: dict[str, str | None] | None = None) -> None:
    """Print a single repository's documentation."""
    # Header
    header = Text(f"  {doc.repo_name}", style="bold cyan")
    console.print(Panel(header, title="Repository", border_style="cyan"))

    # Overview
    overview = Table(show_header=False, box=None, padding=(0, 2))
    overview.add_column("Key", style="bold")
    overview.add_column("Value")
    overview.add_row("Path", doc.repo_path)
    overview.add_row("Languages", ", ".join(doc.languages) if doc.languages else "none detected")
    overview.add_row("Frameworks", ", ".join(doc.frameworks) if doc.frameworks else "none detected")
    overview.add_row("Files scanned", str(len(doc.file_classifications)))

    # Summary counts
    counts = []
    if doc.endpoints:
        counts.append(f"{len(doc.endpoints)} endpoints")
    if doc.api_calls:
        counts.append(f"{len(doc.api_calls)} API calls")
    if doc.db_operations:
        counts.append(f"{len(doc.db_operations)} DB operations")
    if doc.dependencies:
        counts.append(f"{len(doc.dependencies)} dependencies")
    if counts:
        overview.add_row("Summary", ", ".join(counts))

    console.print(overview)
    console.print()

    # Dependencies
    if doc.dependencies and _show_section(sections, "deps"):
        _print_dependencies(doc, console)

    # API Endpoints
    if doc.endpoints and _show_section(sections, "endpoints"):
        _print_endpoints(doc, console)

    # API Calls (frontend)
    if doc.api_calls and _show_section(sections, "calls"):
        _print_api_calls(doc, console)

    # DB Operations
    if doc.db_operations and _show_section(sections, "db"):
        _print_db_operations(doc, console)

    # Shared DB relationships
    shared_db = [r for r in doc.service_relationships if r.connection_type == "shared_db"]
    if shared_db and _show_section(sections, "db"):
        _print_shared_db(shared_db, console)


def _print_dependencies(doc: RepoDocumentation, console: Console) -> None:
    """Print dependency table."""
    table = Table(title="Dependencies", title_style="bold magenta")
    table.add_column("Package", style="green")
    table.add_column("Version")
    table.add_column("Source")
    table.add_column("Dev?", justify="center")

    runtime = [d for d in doc.dependencies if not d.dev_only]
    dev = [d for d in doc.dependencies if d.dev_only]

    for dep in sorted(runtime, key=lambda d: d.name.lower()):
        source_short = dep.source_file.split("/")[-1] if "/" in dep.source_file else dep.source_file
        table.add_row(dep.name, dep.version_constraint, source_short, "")

    for dep in sorted(dev, key=lambda d: d.name.lower()):
        source_short = dep.source_file.split("/")[-1] if "/" in dep.source_file else dep.source_file
        table.add_row(dep.name, dep.version_constraint, source_short, "yes")

    console.print(table)
    console.print()


def _print_endpoints(doc: RepoDocumentation, console: Console) -> None:
    """Print API endpoints — compact table + detailed cards."""
    # Summary table with just the essentials
    table = Table(title="API Endpoints", title_style="bold magenta")
    table.add_column("Method", style="bold yellow", no_wrap=True)
    table.add_column("Route", style="green")
    table.add_column("Handler")
    table.add_column("File", style="dim")

    for ep in doc.endpoints:
        rel_path = _rel_path(ep.file_path, doc.repo_name)
        table.add_row(ep.http_method.upper(), ep.route_pattern, ep.handler_name, f"{rel_path}:{ep.line}")

    console.print(table)
    console.print()

    # Detailed cards for endpoints that have interesting details
    has_details = any(
        ep.parameters or ep.request_body_fields or ep.middleware or
        ep.auth_decorators or ep.db_tables or ep.request_body_type
        for ep in doc.endpoints
    )

    if has_details:
        console.print(Text("  Endpoint Details", style="bold magenta"))
        console.print()

        for ep in doc.endpoints:
            details = _build_endpoint_details(ep)
            if not details:
                continue

            method_style = {
                "GET": "green", "POST": "yellow", "PUT": "blue",
                "DELETE": "red", "PATCH": "cyan",
            }.get(ep.http_method.upper(), "white")

            title = f"[bold {method_style}]{ep.http_method.upper()}[/bold {method_style}] [green]{ep.route_pattern}[/green]"
            panel = Panel(
                "\n".join(details),
                title=title,
                title_align="left",
                border_style="dim",
                padding=(0, 2),
            )
            console.print(panel)


def _build_endpoint_details(ep) -> list[str]:
    """Build detail lines for an endpoint panel."""
    details = []

    rel_path = ep.file_path.split("/")[-1] if "/" in ep.file_path else ep.file_path
    details.append(f"[bold]Handler:[/bold] {ep.handler_name}  [dim]({rel_path}:{ep.line})[/dim]")

    if ep.parameters:
        params = ", ".join(f"[cyan]{p.name}[/cyan] ({p.source.value})" for p in ep.parameters)
        details.append(f"[bold]Params:[/bold]  {params}")

    if ep.request_body_type:
        details.append(f"[bold]Body Type:[/bold] [cyan]{ep.request_body_type}[/cyan]")

    if ep.request_body_fields:
        fields = ", ".join(f"[cyan]{f}[/cyan]" for f in ep.request_body_fields)
        details.append(f"[bold]Body:[/bold]     {fields}")

    if ep.response_fields:
        fields = ", ".join(f"[cyan]{f}[/cyan]" for f in ep.response_fields[:6])
        suffix = f" (+{len(ep.response_fields) - 6} more)" if len(ep.response_fields) > 6 else ""
        details.append(f"[bold]Response:[/bold] {fields}{suffix}")

    if ep.auth_decorators:
        auth = ", ".join(f"[yellow]{a}[/yellow]" for a in ep.auth_decorators)
        details.append(f"[bold]Auth:[/bold]     {auth}")

    if ep.middleware:
        mw = ", ".join(f"[magenta]{m}[/magenta]" for m in ep.middleware)
        details.append(f"[bold]Middleware:[/bold] {mw}")

    if ep.db_tables:
        tables = ", ".join(f"[blue]{t}[/blue]" for t in ep.db_tables)
        details.append(f"[bold]DB Tables:[/bold] {tables}")

    # Only return details if there's more than just the handler line
    if len(details) <= 1:
        return []

    return details


def _print_api_calls(doc: RepoDocumentation, console: Console) -> None:
    """Print frontend API calls table."""
    table = Table(title="Frontend API Calls", title_style="bold magenta")
    table.add_column("Method", style="bold yellow", no_wrap=True)
    table.add_column("URL", style="green")
    table.add_column("Component/Page")
    table.add_column("Traced From", style="dim")

    for call in doc.api_calls:
        traced = call.traced_from or "-"
        table.add_row(call.http_method.upper(), call.url_pattern, call.component_or_page, traced)

    console.print(table)
    console.print()


def _print_db_operations(doc: RepoDocumentation, console: Console) -> None:
    """Print database operations table."""
    table = Table(title="Database Operations", title_style="bold magenta")
    table.add_column("Operation", style="bold yellow", no_wrap=True)
    table.add_column("Table", style="green")
    table.add_column("ORM")
    table.add_column("File", style="dim")
    table.add_column("Filters", style="dim")

    for op in doc.db_operations:
        rel_path = _rel_path(op.file_path, doc.repo_name)
        filters = ", ".join(op.filters) if op.filters else "-"
        table.add_row(op.operation_type.upper(), op.table_name, op.orm_library, f"{rel_path}:{op.line}", filters)

    console.print(table)
    console.print()


def _print_shared_db(relationships: list, console: Console) -> None:
    """Print shared database tables between repos."""
    table = Table(title="Shared Database Tables", title_style="bold magenta")
    table.add_column("Table", style="green")
    table.add_column("Used In", style="cyan")
    table.add_column("Also Used In", style="cyan")
    table.add_column("Confidence", justify="center")

    for rel in relationships:
        table_name = rel.target_endpoint.replace("table:", "")
        table.add_row(table_name, f"{rel.source_repo}/", f"{rel.target_repo}/", f"{rel.confidence:.0%}")

    console.print(table)
    console.print()


def _rel_path(file_path: str, repo_name: str) -> str:
    """Make a file path relative for display."""
    if repo_name + "/" in file_path:
        return file_path.split(repo_name + "/", 1)[-1]
    return file_path
