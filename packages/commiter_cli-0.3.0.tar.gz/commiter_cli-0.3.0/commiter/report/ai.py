"""Compact plain-text output optimized for LLM context windows.

Minimal tokens, no decorative formatting, all essential data with file:line references.
"""

from __future__ import annotations

from pathlib import Path

from commiter.models import RepoDocumentation


def generate_ai(docs: list[RepoDocumentation],
                sections: dict[str, str | None] | None = None) -> str:
    """Generate compact AI-friendly plain text output."""
    lines: list[str] = []

    for doc in docs:
        lines.extend(_repo_section(doc, sections))

    return "\n".join(lines)


def _show(sections: dict | None, key: str) -> bool:
    if sections is None:
        return True
    return sections.get(key) is not None


def _rel(file_path: str, repo_name: str) -> str:
    """Make file path relative to repo."""
    if repo_name + "/" in file_path:
        return file_path.split(repo_name + "/", 1)[-1]
    return Path(file_path).name


def _repo_section(doc: RepoDocumentation,
                  sections: dict[str, str | None] | None = None) -> list[str]:
    lines: list[str] = []

    # Header
    lines.append(f"REPO: {doc.repo_name}")
    if doc.frameworks:
        lines.append(f"FRAMEWORKS: {', '.join(doc.frameworks)}")
    if doc.languages:
        lines.append(f"LANGUAGES: {', '.join(doc.languages)}")
    lines.append("")

    # Endpoints
    if doc.endpoints and _show(sections, "endpoints"):
        lines.append("ENDPOINTS:")
        for ep in doc.endpoints:
            rel = _rel(ep.file_path, doc.repo_name)
            lines.append(f"  {ep.http_method} {ep.route_pattern} → {ep.handler_name} [{rel}:{ep.line}]")

            if ep.parameters:
                params = ", ".join(f"{p.name} ({p.source.value})" for p in ep.parameters)
                lines.append(f"    params: {params}")

            if ep.request_body_type and ep.request_body_fields:
                fields = ", ".join(ep.request_body_fields)
                lines.append(f"    body: {ep.request_body_type} {{{fields}}}")
            elif ep.request_body_type:
                lines.append(f"    body: {ep.request_body_type}")
            elif ep.request_body_fields:
                fields = ", ".join(ep.request_body_fields)
                lines.append(f"    body: {{{fields}}}")

            if ep.response_fields:
                lines.append(f"    response: {{{', '.join(ep.response_fields)}}}")

            if ep.auth_decorators:
                lines.append(f"    auth: {', '.join(ep.auth_decorators)}")

            if ep.middleware:
                lines.append(f"    middleware: {', '.join(ep.middleware)}")

            if ep.db_tables:
                lines.append(f"    db: {', '.join(ep.db_tables)}")

        lines.append("")

    # Frontend API Calls
    if doc.api_calls and _show(sections, "calls"):
        lines.append("API CALLS:")
        for call in doc.api_calls:
            rel = _rel(call.file_path, doc.repo_name)
            traced = f" via {call.traced_from}" if call.traced_from else ""
            lines.append(f"  {call.http_method} {call.url_pattern} ← {call.component_or_page} [{rel}:{call.line}]{traced}")
        lines.append("")

    # DB Operations
    if doc.db_operations and _show(sections, "db"):
        lines.append("DB OPERATIONS:")
        for op in doc.db_operations:
            rel = _rel(op.file_path, doc.repo_name)
            filters = f" WHERE {', '.join(op.filters)}" if op.filters else ""
            lines.append(f"  {op.operation_type.upper()} {op.table_name}{filters} ({op.orm_library}) [{rel}:{op.line}]")
        lines.append("")

    # Dependencies
    if doc.dependencies and _show(sections, "deps"):
        runtime = [d for d in doc.dependencies if not d.dev_only]
        dev = [d for d in doc.dependencies if d.dev_only]
        if runtime:
            deps_str = ", ".join(f"{d.name} {d.version_constraint}" for d in sorted(runtime, key=lambda x: x.name))
            lines.append(f"DEPS: {deps_str}")
        if dev:
            dev_str = ", ".join(f"{d.name} {d.version_constraint}" for d in sorted(dev, key=lambda x: x.name))
            lines.append(f"DEV DEPS: {dev_str}")
        lines.append("")

    # Cross-repo relationships
    shared_db = [r for r in doc.service_relationships if r.connection_type == "shared_db"]
    if shared_db:
        tables = set(r.target_endpoint.replace("table:", "") for r in shared_db)
        lines.append(f"SHARED DB TABLES: {', '.join(sorted(tables))}")
        lines.append("")

    return lines
