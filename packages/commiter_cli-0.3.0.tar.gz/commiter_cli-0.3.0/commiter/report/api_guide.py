"""Generate curl command guides for API endpoints.

Produces ready-to-paste curl commands with all known data pre-filled:
method, route, body template, auth headers, path params, query params.
"""

from __future__ import annotations

import json
from pathlib import Path

from commiter.models import RepoDocumentation, APIEndpoint, ParamSource


# Common auth-related middleware/decorator names
_AUTH_INDICATORS = {
    "auth", "authenticate", "authMiddleware", "requireAuth", "isAuthenticated",
    "verifyToken", "requireLogin", "protect", "jwt_required", "login_required",
    "require_auth", "token_required", "Depends(get_current_user",
}

# Env var names that might contain the API base URL
_BASE_URL_ENV_KEYS = [
    "API_URL", "BASE_URL", "SERVER_URL",
    "NEXT_PUBLIC_API_URL", "VITE_API_URL", "REACT_APP_API_URL",
    "NUXT_PUBLIC_API_BASE",
]

# Env var names for port
_PORT_ENV_KEYS = ["PORT", "SERVER_PORT", "APP_PORT"]


def generate_api_guide(
    docs: list[RepoDocumentation],
    env_vars: dict[str, str] | None = None,
) -> str:
    """Generate curl command guides for all endpoints across repos."""
    lines: list[str] = []
    base_url = _detect_base_url(env_vars or {})

    for doc in docs:
        if not doc.endpoints:
            continue

        lines.append(f"API Guide: {doc.repo_name}")
        lines.append(f"Base URL: {base_url}")
        lines.append("")

        for ep in doc.endpoints:
            lines.extend(_endpoint_guide(ep, doc.repo_name, base_url))
            lines.append("")

    return "\n".join(lines)


def _detect_base_url(env_vars: dict[str, str]) -> str:
    """Detect the API base URL from environment variables."""
    # Check explicit URL vars
    for key in _BASE_URL_ENV_KEYS:
        if key in env_vars:
            return env_vars[key].rstrip("/")

    # Check for PORT
    for key in _PORT_ENV_KEYS:
        if key in env_vars:
            return f"http://localhost:{env_vars[key]}"

    return "http://localhost:3000"


def _endpoint_guide(ep: APIEndpoint, repo_name: str, base_url: str) -> list[str]:
    """Generate a guide + curl command for a single endpoint."""
    lines: list[str] = []
    rel = _rel_path(ep.file_path, repo_name)

    # Header
    lines.append(f"{ep.http_method} {ep.route_pattern} → {ep.handler_name} [{rel}:{ep.line}]")

    # Auth info
    has_auth = _detect_auth(ep)
    if has_auth:
        lines.append(f"  Auth: {', '.join(has_auth)}")

    # Path parameters
    path_params = [p for p in ep.parameters if p.source == ParamSource.PATH]
    if path_params:
        params_str = ", ".join(f"{p.name}: {p.type_hint or 'string'}" for p in path_params)
        lines.append(f"  Path params: {params_str}")

    # Body fields
    if ep.request_body_fields:
        body_type = ep.request_body_type or "object"
        lines.append(f"  Body: {body_type}")
        for field_str in ep.request_body_fields:
            # Parse "name: type" or "name: type?" format
            optional = "?" in field_str
            clean = field_str.rstrip("?").strip()
            req_label = "(optional)" if optional else "(required)"
            lines.append(f"    - {clean} {req_label}")

    # Curl command
    lines.append("")
    lines.extend(_build_curl(ep, base_url, has_auth))

    return lines


def _build_curl(ep: APIEndpoint, base_url: str, auth: list[str]) -> list[str]:
    """Build the curl command for an endpoint."""
    # Build URL with path param placeholders
    url = _build_url(ep, base_url)

    parts: list[str] = [f"  curl -X {ep.http_method} '{url}'"]

    # Content-Type header for methods with body
    if ep.http_method in ("POST", "PUT", "PATCH"):
        parts.append('    -H "Content-Type: application/json"')

    # Auth header if needed
    if auth:
        parts.append('    -H "Authorization: Bearer <YOUR_TOKEN>"')

    # Request body
    if ep.request_body_fields and ep.http_method in ("POST", "PUT", "PATCH"):
        body = _build_body_template(ep)
        body_json = json.dumps(body, indent=6)
        # Indent the JSON to align with the -d flag
        body_lines = body_json.split("\n")
        parts.append(f"    -d '{body_lines[0]}")
        for bl in body_lines[1:]:
            parts[-1] += f"\n    {bl}"
        parts[-1] += "'"

    # Join with line continuation
    return [" \\\n".join(parts)]


def _build_url(ep: APIEndpoint, base_url: str) -> str:
    """Build the full URL with path param placeholders."""
    route = ep.route_pattern

    # Replace framework-specific param syntax with readable placeholders
    # Express :id → <id>
    import re
    route = re.sub(r":(\w+)", r"<\1>", route)
    # Flask <param> already in the right format
    # FastAPI {param} → <param>
    route = re.sub(r"\{(\w+)\}", r"<\1>", route)

    # Add query params if any
    query_params = [p for p in ep.parameters if p.source == ParamSource.QUERY]
    if query_params:
        query_str = "&".join(f"{p.name}=<{p.type_hint or 'value'}>" for p in query_params)
        route += f"?{query_str}"

    return f"{base_url}{route}"


def _build_body_template(ep: APIEndpoint) -> dict:
    """Build a JSON body template from request body fields."""
    body = {}
    for field_str in ep.request_body_fields:
        # Parse "name: type" format
        if ":" in field_str:
            name, type_info = field_str.split(":", 1)
            name = name.strip()
            type_info = type_info.strip().rstrip("?").strip()
            body[name] = _type_placeholder(type_info)
        else:
            body[field_str.strip()] = "<value>"
    return body


def _type_placeholder(type_str: str) -> str | int | bool | list:
    """Generate a placeholder value based on the type string."""
    t = type_str.lower().strip()

    if t == "string" or t == "str":
        return "<string>"
    elif t in ("number", "int", "float", "integer"):
        return 0
    elif t in ("boolean", "bool"):
        return False
    elif t.endswith("[]") or t.startswith("array"):
        return []
    elif "|" in type_str:
        # Enum-like: "admin" | "editor" | "viewer"
        options = [o.strip().strip("'\"") for o in type_str.split("|")]
        return f"<{'|'.join(options)}>"
    elif type_str[0].isupper():
        # CamelCase type name — likely an enum or custom type
        return f"<{type_str}>"
    else:
        return f"<{type_str}>"


def _detect_auth(ep: APIEndpoint) -> list[str]:
    """Detect auth requirements from decorators and middleware."""
    auth_items = []

    for dec in ep.auth_decorators:
        auth_items.append(dec)

    for mw in ep.middleware:
        # Check if this middleware name suggests authentication
        mw_clean = mw.rstrip("()")
        if any(indicator.lower() in mw_clean.lower() for indicator in _AUTH_INDICATORS):
            if mw not in auth_items:
                auth_items.append(mw)

    return auth_items


def _rel_path(file_path: str, repo_name: str) -> str:
    if repo_name + "/" in file_path:
        return file_path.split(repo_name + "/", 1)[-1]
    return Path(file_path).name
