"""Generate structured JSON output from scanned repositories."""

from __future__ import annotations

import json
from dataclasses import asdict

from commiter.models import RepoDocumentation


def generate_json(docs: list[RepoDocumentation], indent: int = 2,
                  sections: dict[str, str | None] | None = None) -> str:
    """Generate a JSON string from the documentation results."""
    output = []
    for doc in docs:
        repo_data = _serialize_repo(doc, sections)
        output.append(repo_data)

    return json.dumps(output, indent=indent, default=str)


def _show(sections: dict | None, key: str) -> bool:
    if sections is None:
        return True
    return sections.get(key) is not None


def _serialize_repo(doc: RepoDocumentation, sections: dict | None = None) -> dict:
    """Serialize a RepoDocumentation to a JSON-friendly dict."""
    result = {
        "repo_name": doc.repo_name,
        "repo_path": doc.repo_path,
        "languages": doc.languages,
        "frameworks": doc.frameworks,
        "summary": {
            "total_files": len(doc.file_classifications),
            "total_endpoints": len(doc.endpoints),
            "total_api_calls": len(doc.api_calls),
            "total_dependencies": len(doc.dependencies),
            "total_db_operations": len(doc.db_operations),
            "total_relationships": len(doc.service_relationships),
        },
    }

    if _show(sections, "endpoints"):
        result["endpoints"] = [
            {
                "http_method": ep.http_method,
                "route_pattern": ep.route_pattern,
                "handler_name": ep.handler_name,
                "framework": ep.framework,
                "file_path": ep.file_path,
                "line": ep.line,
                "parameters": [
                    {"name": p.name, "source": p.source.value, "type_hint": p.type_hint, "required": p.required}
                    for p in ep.parameters
                ],
                "request_body_fields": ep.request_body_fields,
                "response_fields": ep.response_fields,
                "auth_decorators": ep.auth_decorators,
                "db_tables": ep.db_tables,
                "request_body_type": ep.request_body_type,
                "response_type": ep.response_type,
                "middleware": ep.middleware,
            }
            for ep in doc.endpoints
        ]

    if _show(sections, "calls"):
        result["api_calls"] = [
            {
                "http_method": call.http_method,
                "url_pattern": call.url_pattern,
                "component_or_page": call.component_or_page,
                "client_library": call.client_library,
                "file_path": call.file_path,
                "line": call.line,
                "traced_from": call.traced_from,
                "response_type": call.response_type,
                "body_type": call.body_type,
            }
            for call in doc.api_calls
        ]

    if _show(sections, "deps"):
        result["dependencies"] = {
            "runtime": [
                {"name": d.name, "version": d.version_constraint, "source": d.source_file}
                for d in doc.dependencies if not d.dev_only
            ],
            "dev": [
                {"name": d.name, "version": d.version_constraint, "source": d.source_file}
                for d in doc.dependencies if d.dev_only
            ],
        }

    if _show(sections, "db"):
        result["db_operations"] = [
            {
                "operation_type": op.operation_type,
                "table_name": op.table_name,
                "orm_library": op.orm_library,
                "file_path": op.file_path,
                "line": op.line,
                "filters": op.filters,
            }
            for op in doc.db_operations
        ]

    result["service_relationships"] = [
        {
            "source_repo": rel.source_repo,
            "target_repo": rel.target_repo,
            "connection_type": rel.connection_type,
            "source_file": rel.source_file,
            "target_endpoint": rel.target_endpoint,
            "confidence": rel.confidence,
        }
        for rel in doc.service_relationships
    ]

    return result
