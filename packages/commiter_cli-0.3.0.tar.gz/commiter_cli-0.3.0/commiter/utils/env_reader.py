"""Read .env files and resolve environment variable references."""

from __future__ import annotations

import os
from pathlib import Path

# .env files to check, in priority order (later overrides earlier)
ENV_FILES = [
    ".env",
    ".env.local",
    ".env.development",
    ".env.development.local",
]


def load_env_files(repo_root: str) -> dict[str, str]:
    """Read all .env files in the repo root and return a merged dict.

    Later files override earlier ones. Only reads key=value pairs,
    ignores comments and empty lines.
    """
    env: dict[str, str] = {}
    root = Path(repo_root)

    for filename in ENV_FILES:
        env_path = root / filename
        if env_path.is_file():
            try:
                content = env_path.read_text(encoding="utf-8", errors="replace")
                env.update(_parse_env_content(content))
            except OSError:
                continue

    return env


def _parse_env_content(content: str) -> dict[str, str]:
    """Parse .env file content into key-value pairs."""
    result: dict[str, str] = {}
    for line in content.splitlines():
        line = line.strip()
        # Skip empty lines and comments
        if not line or line.startswith("#"):
            continue
        # Handle export prefix: export VAR=value
        if line.startswith("export "):
            line = line[7:].strip()
        # Split on first =
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        # Strip surrounding quotes
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if key:
            result[key] = value

    return result


def resolve_env_var(var_name: str, env: dict[str, str]) -> str | None:
    """Resolve a variable name to its .env value.

    Handles common patterns:
      process.env.API_URL -> looks up "API_URL"
      process.env.NEXT_PUBLIC_API_URL -> looks up "NEXT_PUBLIC_API_URL"
      import.meta.env.VITE_API_URL -> looks up "VITE_API_URL"
    """
    # Strip common prefixes
    for prefix in ("process.env.", "import.meta.env."):
        if var_name.startswith(prefix):
            var_name = var_name[len(prefix):]
            break

    return env.get(var_name)
