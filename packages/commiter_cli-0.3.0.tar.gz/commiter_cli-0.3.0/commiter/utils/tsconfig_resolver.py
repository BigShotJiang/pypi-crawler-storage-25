"""Parse tsconfig.json / jsconfig.json and resolve path aliases.

Supports:
- compilerOptions.baseUrl and compilerOptions.paths
- "extends" inheritance chains (recursive)
- Monorepo multi-tsconfig via TSConfigRegistry
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

# Extensions to try when probing for a file
RESOLVE_EXTENSIONS = [".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.js", "/index.tsx"]

# Directories to skip when scanning for tsconfig files in monorepos
SKIP_DIRS = {
    "node_modules", ".git", "dist", "build", ".next", ".nuxt",
    "__pycache__", ".tox", ".venv", "venv", "coverage",
}

# Max depth for extends chains to prevent infinite loops
MAX_EXTENDS_DEPTH = 5


def _strip_jsonc_comments(text: str) -> str:
    """Strip // and /* */ comments from JSONC, preserving strings.

    Uses a regex that matches strings first (to skip them), then comments.
    This prevents stripping // inside strings like "@/*": ["src/*"].
    """
    # Match either a double-quoted string, a single-line comment, or a block comment.
    # Strings are captured and preserved; comments are replaced with empty string.
    def _replacer(match: re.Match) -> str:
        if match.group(1) is not None:
            return match.group(1)  # preserve string
        return ""  # remove comment

    return re.sub(
        r'("(?:[^"\\]|\\.)*")'   # group 1: double-quoted string (preserved)
        r'|//.*?$'                # single-line comment
        r'|/\*.*?\*/',            # block comment
        _replacer,
        text,
        flags=re.MULTILINE | re.DOTALL,
    )


def _load_json(config_path: str) -> dict | None:
    """Load and parse a JSONC file (tsconfig/jsconfig). Returns None on failure."""
    try:
        raw = Path(config_path).read_text(encoding="utf-8", errors="replace")
        raw = _strip_jsonc_comments(raw)
        return json.loads(raw)
    except (json.JSONDecodeError, OSError):
        return None


def _resolve_extends(data: dict, config_dir: str, seen: set[str] | None = None, depth: int = 0) -> dict:
    """Recursively follow the 'extends' field and merge parent configs.

    Merge rules (matching TypeScript behavior):
    - compilerOptions: child overrides parent per-key (shallow merge)
    - paths: child completely replaces parent if present
    - include/exclude: child replaces parent
    """
    if depth >= MAX_EXTENDS_DEPTH:
        return data

    extends_value = data.get("extends")
    if not extends_value:
        return data

    if seen is None:
        seen = set()

    # Resolve the extends path
    if extends_value.startswith("."):
        # Relative path: "./tsconfig.base.json" or "../shared/tsconfig.json"
        parent_path = os.path.normpath(os.path.join(config_dir, extends_value))
        # TypeScript also tries appending .json if not present
        if not parent_path.endswith(".json"):
            if os.path.isfile(parent_path + ".json"):
                parent_path += ".json"
    else:
        # Package extends like "@tsconfig/next" — skip, can't resolve without node_modules
        return data

    parent_path = os.path.abspath(parent_path)

    # Guard against circular extends
    if parent_path in seen or not os.path.isfile(parent_path):
        return data

    seen.add(parent_path)

    parent_data = _load_json(parent_path)
    if parent_data is None:
        return data

    # Recursively resolve parent's extends
    parent_dir = os.path.dirname(parent_path)
    parent_data = _resolve_extends(parent_data, parent_dir, seen, depth + 1)

    # Merge: parent as base, child overrides
    merged = dict(parent_data)

    # Merge compilerOptions (shallow: child keys override parent keys)
    parent_opts = merged.get("compilerOptions", {})
    child_opts = data.get("compilerOptions", {})
    merged_opts = dict(parent_opts)
    merged_opts.update(child_opts)
    merged["compilerOptions"] = merged_opts

    # Top-level fields: child replaces parent entirely
    for key in ("include", "exclude", "files", "references"):
        if key in data:
            merged[key] = data[key]

    # Remove extends from merged result
    merged.pop("extends", None)

    return merged


class TSConfigResolver:
    """Resolves TypeScript/JavaScript path aliases from a single tsconfig.json.

    Handles compilerOptions.baseUrl, compilerOptions.paths, and "extends" chains.
    """

    def __init__(self, repo_root: str) -> None:
        self.repo_root = os.path.abspath(repo_root)
        self.base_url: str | None = None
        self.paths: dict[str, list[str]] = {}
        self._alias_rules: list[tuple[str, list[str]]] = []

        self._load()

    def _load(self) -> None:
        """Find and parse tsconfig.json or jsconfig.json."""
        for name in ("tsconfig.json", "jsconfig.json"):
            config_path = os.path.join(self.repo_root, name)
            if os.path.isfile(config_path):
                self._parse(config_path)
                return

    def _parse(self, config_path: str) -> None:
        """Parse a tsconfig/jsconfig file, following extends if present."""
        data = _load_json(config_path)
        if data is None:
            return

        config_dir = os.path.dirname(os.path.abspath(config_path))

        # Follow extends chain
        if "extends" in data:
            data = _resolve_extends(data, config_dir)

        compiler_opts = data.get("compilerOptions", {})

        # baseUrl is relative to the tsconfig location
        base_url = compiler_opts.get("baseUrl")
        if base_url:
            self.base_url = os.path.normpath(os.path.join(config_dir, base_url))

        # paths entries
        self.paths = compiler_opts.get("paths", {})

        # Build alias rules: (prefix, [replacement_dirs])
        for pattern, replacements in self.paths.items():
            prefix = pattern.replace("*", "")
            resolved_replacements = []
            for repl in replacements:
                repl_prefix = repl.replace("*", "")
                base = self.base_url or config_dir
                resolved_replacements.append(os.path.normpath(os.path.join(base, repl_prefix)))
            self._alias_rules.append((prefix, resolved_replacements))

    def resolve(self, import_path: str, caller_file: str = "") -> str | None:
        """Resolve a non-relative import path using tsconfig aliases."""
        if import_path.startswith("."):
            return None

        for prefix, replacement_dirs in self._alias_rules:
            if not import_path.startswith(prefix):
                continue

            suffix = import_path[len(prefix):]
            for repl_dir in replacement_dirs:
                candidate_base = os.path.join(repl_dir, suffix)
                result = self._probe_file(candidate_base)
                if result:
                    return result

        if self.base_url:
            candidate_base = os.path.join(self.base_url, import_path)
            result = self._probe_file(candidate_base)
            if result:
                return result

        return None

    def _probe_file(self, base_path: str) -> str | None:
        """Try to find a file at base_path with various extensions."""
        if os.path.isfile(base_path):
            return os.path.abspath(base_path)

        for ext in RESOLVE_EXTENSIONS:
            candidate = base_path + ext
            if os.path.isfile(candidate):
                return os.path.abspath(candidate)

        return None

    @property
    def has_config(self) -> bool:
        """Whether a tsconfig/jsconfig was found and parsed."""
        return self.base_url is not None or bool(self.paths)


class TSConfigRegistry:
    """Manages multiple TSConfigResolvers for monorepo support.

    Finds all tsconfig.json/jsconfig.json files in the repo, creates a resolver
    for each, and routes resolve() calls to the nearest resolver for a given file.

    Drop-in replacement for TSConfigResolver — same resolve() interface.
    """

    def __init__(self, repo_root: str) -> None:
        self.repo_root = os.path.abspath(repo_root)
        self._resolvers: dict[str, TSConfigResolver] = {}
        self._build()

    def _build(self) -> None:
        """Find all tsconfig/jsconfig files and create resolvers."""
        for root, dirs, files in os.walk(self.repo_root):
            # Skip irrelevant directories
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]

            for name in ("tsconfig.json", "jsconfig.json"):
                if name in files:
                    config_dir = os.path.abspath(root)
                    self._resolvers[config_dir] = TSConfigResolver(config_dir)
                    break  # one config per directory

    def get_resolver_for_file(self, file_path: str) -> TSConfigResolver | None:
        """Find the nearest tsconfig resolver for a given file."""
        current = Path(os.path.abspath(file_path)).parent
        repo = Path(self.repo_root)

        while current >= repo:
            key = str(current)
            if key in self._resolvers:
                return self._resolvers[key]
            current = current.parent

        return None

    def resolve(self, import_path: str, caller_file: str = "") -> str | None:
        """Resolve using the nearest tsconfig for the caller file.

        Same interface as TSConfigResolver.resolve() — drop-in replacement.
        """
        resolver = self.get_resolver_for_file(caller_file)
        if resolver:
            return resolver.resolve(import_path, caller_file)
        return None

    @property
    def has_config(self) -> bool:
        """Whether any tsconfig/jsconfig was found."""
        return bool(self._resolvers)

    @property
    def resolver_count(self) -> int:
        return len(self._resolvers)
