"""Path utilities: repo root detection, ignore patterns, file walking."""

from __future__ import annotations

from pathlib import Path

# Directories to always skip
IGNORE_DIRS = {
    ".git", "node_modules", "__pycache__", ".next", ".nuxt",
    "dist", "build", ".tox", ".venv", "venv", "env",
    ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "vendor", "target", ".idea", ".vscode",
    "coverage", ".nyc_output", ".turbo",
}

# File extensions to skip
IGNORE_EXTENSIONS = {
    ".pyc", ".pyo", ".class", ".o", ".so", ".dll",
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico",
    ".woff", ".woff2", ".ttf", ".eot",
    ".zip", ".tar", ".gz", ".bz2",
    ".lock", ".sum",
    ".map",
}

# Binary / non-code files to skip by name
IGNORE_FILES = {
    ".DS_Store", "Thumbs.db", "package-lock.json", "yarn.lock",
    "pnpm-lock.yaml", "poetry.lock", "Pipfile.lock",
    "Cargo.lock", "Gemfile.lock", "composer.lock",
}


def walk_repo(repo_root: str, extra_excludes: list[str] | None = None) -> list[str]:
    """Walk a repository and return all relevant file paths.

    Skips directories and files in the ignore lists.
    """
    root = Path(repo_root)
    if not root.is_dir():
        return []

    exclude_set = set(extra_excludes) if extra_excludes else set()
    files: list[str] = []

    for path in root.rglob("*"):
        if not path.is_file():
            continue

        # Check if any parent directory should be skipped
        parts = path.relative_to(root).parts
        if any(part in IGNORE_DIRS for part in parts):
            continue

        # Check file-level ignores
        if path.name in IGNORE_FILES:
            continue
        if path.suffix.lower() in IGNORE_EXTENSIONS:
            continue

        # Check extra excludes (glob-style not needed, simple substring match)
        rel = str(path.relative_to(root))
        if any(excl in rel for excl in exclude_set):
            continue

        files.append(str(path))

    return sorted(files)


def detect_repo_name(repo_root: str) -> str:
    """Detect a human-friendly repository name from the root path."""
    return Path(repo_root).name
