"""Detect language and framework from file contents and project structure."""

from __future__ import annotations

import json
from pathlib import Path

from commiter.models import FileClassification, FileRole

# Extension to language mapping
EXTENSION_LANG: dict[str, str] = {
    ".py": "python",
    ".js": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".go": "go",
    ".rb": "ruby",
    ".rs": "rust",
    ".java": "java",
    ".kt": "kotlin",
    ".php": "php",
    ".cs": "csharp",
    ".swift": "swift",
}

# Patterns that indicate test files
TEST_PATTERNS = {
    "test_", "_test.", ".test.", ".spec.", "__tests__", "tests/", "test/",
    "spec/", "specs/",
}

# Config file names
CONFIG_FILES = {
    ".env", ".env.local", ".env.production", ".env.development",
    "docker-compose.yml", "docker-compose.yaml", "Dockerfile",
    "tsconfig.json", "jsconfig.json", ".eslintrc", ".prettierrc",
    "webpack.config.js", "vite.config.ts", "vite.config.js",
    "next.config.js", "next.config.mjs", "next.config.ts",
    "tailwind.config.js", "tailwind.config.ts",
    "pyproject.toml", "setup.py", "setup.cfg", "tox.ini",
    "Makefile", "Procfile", ".gitignore", ".dockerignore",
}

# Migration directory patterns
MIGRATION_PATTERNS = {"migrations/", "alembic/", "migrate/", "db/migrate/"}


def classify_file(file_path: str, repo_root: str) -> FileClassification:
    """Classify a single file by role, language, and framework hints."""
    path = Path(file_path).resolve()
    root = Path(repo_root).resolve()
    try:
        rel = str(path.relative_to(root))
    except ValueError:
        rel = str(path)
    name = path.name
    ext = path.suffix.lower()

    language = EXTENSION_LANG.get(ext, ext.lstrip(".") if ext else "unknown")
    role = _detect_role(rel, name, ext)
    framework_hints = _detect_framework_hints(rel, name)

    return FileClassification(
        file_path=file_path,
        role=role,
        language=language,
        framework_hints=framework_hints,
    )


def _detect_role(rel_path: str, name: str, ext: str) -> FileRole:
    """Determine the file's role based on path and name patterns."""
    rel_lower = rel_path.lower().replace("\\", "/")

    # Config files
    if name in CONFIG_FILES or ext in (".yml", ".yaml", ".toml", ".ini", ".cfg"):
        return FileRole.CONFIG

    # Test files
    for pattern in TEST_PATTERNS:
        if pattern in rel_lower:
            return FileRole.TEST

    # Migration files
    for pattern in MIGRATION_PATTERNS:
        if pattern in rel_lower:
            return FileRole.MIGRATION

    # Next.js conventions
    if "pages/api/" in rel_lower or "app/" in rel_lower and "route." in name:
        return FileRole.BACKEND
    if "pages/" in rel_lower or ("app/" in rel_lower and "page." in name):
        return FileRole.FRONTEND

    # Common backend patterns
    backend_indicators = ("routes/", "api/", "controllers/", "handlers/", "views/", "endpoints/", "server.")
    for indicator in backend_indicators:
        if indicator in rel_lower:
            return FileRole.BACKEND

    # Common frontend patterns
    frontend_indicators = ("components/", "pages/", "src/app/", "views/", "layouts/", "hooks/")
    for indicator in frontend_indicators:
        if indicator in rel_lower:
            return FileRole.FRONTEND

    # Fallback by extension
    if ext in (".py", ".go", ".rb", ".java", ".php", ".rs"):
        return FileRole.BACKEND
    if ext in (".jsx", ".tsx"):
        return FileRole.FRONTEND

    return FileRole.UNKNOWN


def _detect_framework_hints(rel_path: str, name: str) -> list[str]:
    """Detect possible framework associations from path conventions."""
    hints = []
    rel_path = rel_path.replace("\\", "/")
    if "pages/api/" in rel_path or "app/" in rel_path and "route." in name:
        hints.append("nextjs")
    if name in ("next.config.js", "next.config.mjs", "next.config.ts"):
        hints.append("nextjs")
    return hints


def detect_repo_frameworks(repo_root: str) -> list[str]:
    """Detect which frameworks a repository uses by checking dependency manifests and imports."""
    frameworks = []
    root = Path(repo_root)

    # Check package.json
    pkg_json = root / "package.json"
    if pkg_json.exists():
        try:
            data = json.loads(pkg_json.read_text(encoding="utf-8", errors="replace"))
            all_deps = set(data.get("dependencies", {}).keys()) | set(data.get("devDependencies", {}).keys())
            if "express" in all_deps:
                frameworks.append("express")
            if "next" in all_deps:
                frameworks.append("nextjs")
            if "react" in all_deps:
                frameworks.append("react")
            if "fastify" in all_deps:
                frameworks.append("fastify")
            if "hono" in all_deps:
                frameworks.append("hono")
            if "@prisma/client" in all_deps or "prisma" in all_deps:
                frameworks.append("prisma")
            if "@supabase/supabase-js" in all_deps:
                frameworks.append("supabase-js")
            if "drizzle-orm" in all_deps:
                frameworks.append("drizzle")
            if "axios" in all_deps:
                frameworks.append("axios")
        except (json.JSONDecodeError, OSError):
            pass

    # Check Python manifests
    for manifest in ("requirements.txt", "pyproject.toml", "setup.cfg", "Pipfile"):
        manifest_path = root / manifest
        if manifest_path.exists():
            try:
                content = manifest_path.read_text(encoding="utf-8", errors="replace").lower()
                if "flask" in content:
                    frameworks.append("flask")
                if "fastapi" in content:
                    frameworks.append("fastapi")
                if "django" in content:
                    frameworks.append("django")
                if "supabase" in content:
                    frameworks.append("supabase-py")
                if "sqlalchemy" in content:
                    frameworks.append("sqlalchemy")
            except OSError:
                pass

    # Check for Next.js by directory structure
    if not any(f in frameworks for f in ("nextjs",)):
        if (root / "pages").is_dir() or (root / "app").is_dir():
            if (root / "next.config.js").exists() or (root / "next.config.mjs").exists() or (root / "next.config.ts").exists():
                frameworks.append("nextjs")

    return list(dict.fromkeys(frameworks))  # deduplicate preserving order
