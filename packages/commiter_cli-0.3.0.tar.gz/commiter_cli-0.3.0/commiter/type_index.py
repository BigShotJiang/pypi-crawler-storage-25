"""Cross-file type index: resolves type/interface definitions across files.

Mirrors the WrapperIndex pattern — indexes all type definitions in Pass 1,
then resolves type references from other files in Pass 2.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from commiter.parser import (
    TypeField,
    find_ts_interface_fields,
    find_ts_enum_declarations,
    find_ts_type_aliases,
    find_ts_const_objects,
    find_js_re_exports,
    find_py_class_fields,
    extract_type_parameters,
    find_nodes_by_type,
    node_text,
    JSReExport,
)

if TYPE_CHECKING:
    from tree_sitter import Tree
    from commiter.utils.tsconfig_resolver import TSConfigResolver

# Extensions to try when resolving import paths
RESOLVE_EXTENSIONS = [".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.js", "/index.tsx"]

# Python class base classes that indicate a type definition worth indexing
PY_TYPE_BASES = {"BaseModel", "Schema", "TypedDict"}


@dataclass
class TypeDefinition:
    """A type/interface/class/enum definition found in a source file."""
    name: str
    file_path: str
    line: int
    fields: list[TypeField]
    language: str
    kind: str = "interface"  # "interface" | "enum" | "type_alias" | "const"
    generic_params: list[str] = field(default_factory=list)  # ["T"], ["T", "U"]


class TypeIndex:
    """Index of type definitions across all files in a repository.

    Usage:
        idx = TypeIndex(alias_resolver=resolver)
        # Pass 1: index all files
        for path in files:
            idx.index_file(path, tree, source, language)
        # Pass 2: resolve types from other files
        typedef = idx.resolve("CreateUserBody", "../types/api", "/project/routes/users.ts")
    """

    def __init__(self, alias_resolver: "TSConfigResolver | None" = None) -> None:
        # type_name -> list of definitions (same name can exist in multiple files)
        self._types: dict[str, list[TypeDefinition]] = {}
        # normalized absolute path (no extension) -> actual absolute path
        self._indexed_paths: dict[str, str] = {}
        self._alias_resolver = alias_resolver
        # barrel file re-export cache: abs_path -> list[JSReExport]
        self._re_exports: dict[str, list[JSReExport]] = {}

    def index_file(self, file_path: str, tree: "Tree", source: bytes, language: str) -> None:
        """Pass 1: extract all type definitions from a file."""
        abs_path = os.path.abspath(file_path)

        # Store path for import resolution
        stem = _strip_extension(abs_path)
        self._indexed_paths[stem] = abs_path
        if Path(abs_path).stem == "index":
            self._indexed_paths[str(Path(abs_path).parent)] = abs_path

        if language in ("typescript", "tsx", "javascript"):
            # Cache re-exports for barrel file resolution
            re_exports = find_js_re_exports(tree.root_node, source)
            if re_exports:
                self._re_exports[abs_path] = re_exports
            self._index_ts_file(abs_path, tree, source, language)
        elif language == "python":
            self._index_py_file(abs_path, tree, source)

    def _index_ts_file(self, abs_path: str, tree: "Tree", source: bytes, language: str) -> None:
        """Index TypeScript/JavaScript interfaces, enums, type aliases, and const objects."""
        root = tree.root_node

        # Build a map of type name -> generic params from declarations
        generic_params_map = self._extract_all_generic_params(root, source)

        # Interfaces
        for name, fields in find_ts_interface_fields(root, source).items():
            line = self._find_type_line(root, source, name)
            self._types.setdefault(name, []).append(TypeDefinition(
                name=name, file_path=abs_path, line=line,
                fields=fields, language=language, kind="interface",
                generic_params=generic_params_map.get(name, []),
            ))

        # Enums
        for name, members in find_ts_enum_declarations(root, source).items():
            line = self._find_type_line(root, source, name)
            self._types.setdefault(name, []).append(TypeDefinition(
                name=name, file_path=abs_path, line=line,
                fields=members, language=language, kind="enum",
            ))

        # Type aliases
        for name, fields in find_ts_type_aliases(root, source).items():
            line = self._find_type_line(root, source, name)
            self._types.setdefault(name, []).append(TypeDefinition(
                name=name, file_path=abs_path, line=line,
                fields=fields, language=language, kind="type_alias",
                generic_params=generic_params_map.get(name, []),
            ))

        # Const objects (as const)
        for name, fields in find_ts_const_objects(root, source).items():
            line = self._find_type_line(root, source, name)
            self._types.setdefault(name, []).append(TypeDefinition(
                name=name, file_path=abs_path, line=line,
                fields=fields, language=language, kind="const",
            ))

    def _extract_all_generic_params(self, root, source: bytes) -> dict[str, list[str]]:
        """Extract generic parameters for all interfaces and type aliases in a file."""
        result: dict[str, list[str]] = {}
        for child in root.children:
            target = child
            if child.type == "export_statement":
                for sub in child.children:
                    if sub.type in ("interface_declaration", "type_alias_declaration"):
                        target = sub
                        break
            if target.type in ("interface_declaration", "type_alias_declaration"):
                name_node = target.child_by_field_name("name")
                if name_node:
                    name = node_text(name_node, source)
                    params = extract_type_parameters(target, source)
                    if params:
                        result[name] = params
        return result

    def _index_py_file(self, abs_path: str, tree: "Tree", source: bytes) -> None:
        """Index Python class definitions (Pydantic, TypedDict, dataclasses)."""
        import re
        text = source.decode("utf-8", errors="replace")
        for match in re.finditer(r'class\s+(\w+)\s*\([^)]*(?:' + '|'.join(PY_TYPE_BASES) + r')', text):
            class_name = match.group(1)
            fields = find_py_class_fields(tree.root_node, source, class_name)
            if fields:
                line = text[:match.start()].count("\n") + 1
                self._types.setdefault(class_name, []).append(TypeDefinition(
                    name=class_name,
                    file_path=abs_path,
                    line=line,
                    fields=fields,
                    language="python",
                ))

    def resolve(self, type_name: str, import_path: str | None, caller_file: str) -> TypeDefinition | None:
        """Pass 2: resolve a type reference to its definition.

        Args:
            type_name: The type/interface name (e.g. "CreateUserBody").
            import_path: The import module path (e.g. "../types/api", "@/types"), or None.
            caller_file: Absolute path of the file that references the type.

        Returns:
            The TypeDefinition if found, None otherwise.
        """
        if type_name not in self._types:
            return None

        # If no import path, return first match (best effort)
        if import_path is None:
            return self._types[type_name][0] if self._types[type_name] else None

        resolved_path = self._resolve_import_path(import_path, caller_file)
        if resolved_path is None:
            # Fallback: return first match
            return self._types[type_name][0] if self._types[type_name] else None

        # Filter to definitions in the resolved file
        for typedef in self._types[type_name]:
            if typedef.file_path == resolved_path:
                return typedef

        # Barrel file fallback: check if resolved_path re-exports this type
        actual_path = self._resolve_through_barrel(type_name, resolved_path)
        if actual_path:
            for typedef in self._types[type_name]:
                if typedef.file_path == actual_path:
                    return typedef

        return None

    def resolve_local(self, type_name: str, file_path: str) -> TypeDefinition | None:
        """Look up a type defined in the same file."""
        if type_name not in self._types:
            return None
        abs_path = os.path.abspath(file_path)
        for typedef in self._types[type_name]:
            if typedef.file_path == abs_path:
                return typedef
        return None

    def _resolve_through_barrel(self, name: str, barrel_path: str) -> str | None:
        """Follow re-exports in a barrel file to find the actual source file."""
        re_exports = self._re_exports.get(barrel_path)
        if not re_exports:
            return None

        barrel_dir = str(Path(barrel_path).parent)

        for re_export in re_exports:
            if name not in re_export.names and "*" not in re_export.names:
                continue

            target_base = os.path.normpath(os.path.join(barrel_dir, re_export.module_path))
            target_stem = _strip_extension(target_base)

            if target_stem in self._indexed_paths:
                return self._indexed_paths[target_stem]

            for ext in RESOLVE_EXTENSIONS:
                candidate_stem = _strip_extension(target_base + ext)
                if candidate_stem in self._indexed_paths:
                    return self._indexed_paths[candidate_stem]

        return None

    def _resolve_import_path(self, import_path: str, caller_file: str) -> str | None:
        """Resolve an import path to an absolute file path."""
        if import_path.startswith("."):
            # Relative import
            caller_dir = str(Path(os.path.abspath(caller_file)).parent)
            base = os.path.normpath(os.path.join(caller_dir, import_path))
        elif self._alias_resolver:
            # Try tsconfig alias
            resolved = self._alias_resolver.resolve(import_path, caller_file)
            if resolved:
                return resolved
            return None
        else:
            # Python relative imports: .schemas -> schemas.py in same dir
            if import_path.startswith("."):
                caller_dir = str(Path(os.path.abspath(caller_file)).parent)
                # Count leading dots for relative depth
                dots = len(import_path) - len(import_path.lstrip("."))
                module = import_path[dots:].replace(".", "/")
                parent = Path(caller_dir)
                for _ in range(dots - 1):
                    parent = parent.parent
                base = str(parent / module)
            else:
                return None

        # Try matching indexed paths
        stem = _strip_extension(base)
        if stem in self._indexed_paths:
            return self._indexed_paths[stem]

        # Try with extensions
        for ext in RESOLVE_EXTENSIONS:
            candidate = base + ext
            candidate_stem = _strip_extension(candidate)
            if candidate_stem in self._indexed_paths:
                return self._indexed_paths[candidate_stem]

        # Python: try .py extension
        py_candidate = base + ".py"
        if os.path.isfile(py_candidate):
            return os.path.abspath(py_candidate)

        return None

    def _find_type_line(self, root_node, source: bytes, type_name: str) -> int:
        """Find the line number of a type definition."""
        from commiter.parser import find_nodes_by_type
        for node in find_nodes_by_type(root_node, "interface_declaration"):
            name_node = node.child_by_field_name("name")
            if name_node and node_text(name_node, source) == type_name:
                return node.start_point[0] + 1
        return 0

    @property
    def type_count(self) -> int:
        return sum(len(defs) for defs in self._types.values())


def _strip_extension(path: str) -> str:
    """Strip JS/TS/Python file extensions from a path."""
    p = Path(path)
    while p.suffix in (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".py"):
        p = p.with_suffix("")
    return str(p)
