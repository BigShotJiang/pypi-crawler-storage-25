"""
Public library API for `commiter-cli`.

Programmatic callers (e.g. the Commiter backend running enrich on behalf of
users) should import from this module. Everything else under `commiter.cli`,
`commiter.scanner`, `commiter.report.*` etc. is considered internal and is
not a stable surface — it may change between releases.
"""

import json
from pathlib import Path
from typing import Union

from commiter.scanner import scan_repos_full
from commiter.report.architecture import generate_architecture


PathLike = Union[str, Path]


def generate_snapshot(
    repo_paths: list[PathLike],
    *,
    extra_excludes: list[str] | None = None,
) -> dict:
    """
    Scan one or more local repository directories and return the architecture
    snapshot as a Python dict — the same shape the CLI POSTs to
    `/v1/architecture/upload` on commiter.dev.

    Does *not* upload. The caller is responsible for persisting the result.

    Args:
        repo_paths: One or more on-disk paths, each pointing at the root of a
            repository (i.e. a directory containing the project's source).
        extra_excludes: Additional path-substring exclusions forwarded to the
            scanner. Useful if the caller wants to skip vendored dirs beyond
            the scanner's built-in list.

    Returns:
        A dict with top-level keys `nodes`, `edges`, `fileTree`,
        `nodeAnalysis`, `nodeHashes`, and `repoFullNames`. See the upload
        endpoint's contract for field-level details.

    Raises:
        FileNotFoundError: if any of the supplied paths doesn't exist.
    """
    if not repo_paths:
        raise ValueError("repo_paths must contain at least one path")

    str_paths: list[str] = []
    for p in repo_paths:
        path = Path(p)
        if not path.exists():
            raise FileNotFoundError(f"Repository path does not exist: {path}")
        str_paths.append(str(path))

    results = scan_repos_full(str_paths, extra_excludes or [])
    json_str = generate_architecture(results)
    return json.loads(json_str)


__all__ = ["generate_snapshot"]
