"""Browser-based CLI authentication for Commiter."""

from __future__ import annotations

import json
import socket
import threading
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

FRONTEND_URL = "https://commiter-three.vercel.app"
CREDENTIALS_DIR = Path.home() / ".config" / "commiter"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.json"


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def login() -> bool:
    """Run the browser-based login flow.

    Opens the browser to the Commiter consent page. A temporary local
    HTTP server receives the callback with the CLI token.

    Returns True on success, False on failure/timeout.
    """
    # Check if already logged in
    existing = get_saved_token()
    if existing:
        creds = _read_credentials()
        email = creds.get("email", "unknown")
        print(f"Already logged in as {email}")
        print("Run commiter --logout first to switch accounts.")
        return True

    port = _find_free_port()
    result: dict = {}

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path == "/callback":
                params = parse_qs(parsed.query)
                token = params.get("token", [None])[0]
                email = params.get("email", [""])[0]
                if token:
                    result["token"] = token
                    result["email"] = email
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html")
                    self.end_headers()
                    self.wfile.write(
                        b"<html><body><h2>Login successful!</h2>"
                        b"<p>You can close this window and return to your terminal.</p>"
                        b"</body></html>"
                    )
                else:
                    self.send_response(400)
                    self.send_header("Content-Type", "text/html")
                    self.end_headers()
                    self.wfile.write(b"<html><body><h2>Login failed</h2><p>No token received.</p></body></html>")
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, format, *args):
            pass  # Suppress request logs

    server = HTTPServer(("127.0.0.1", port), CallbackHandler)
    server.timeout = 120  # 2 minute timeout

    authorize_url = f"{FRONTEND_URL}/cli/authorize?port={port}"
    print(f"Opening browser to log in...")
    print(f"If the browser doesn't open, visit: {authorize_url}")
    webbrowser.open(authorize_url)

    # Wait for the callback
    def serve():
        while not result and server.timeout > 0:
            server.handle_request()

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    thread.join(timeout=120)
    server.server_close()

    if result.get("token"):
        _save_credentials(result["token"], result.get("email", ""))
        print(f"Logged in as {result.get('email', 'unknown')}")
        return True
    else:
        print("Login timed out or was denied.")
        return False


def logout() -> None:
    """Remove saved credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
        print("Logged out successfully.")
    else:
        print("Not currently logged in.")


def get_saved_token() -> str | None:
    """Read the saved CLI token. Returns None if missing or expired."""
    creds = _read_credentials()
    return creds.get("token") if creds else None


def _read_credentials() -> dict | None:
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        return json.loads(CREDENTIALS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def _save_credentials(token: str, email: str) -> None:
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(json.dumps({
        "token": token,
        "email": email,
    }, indent=2))