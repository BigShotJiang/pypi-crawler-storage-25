"""Flask adapter — recognizes Flask route patterns."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import BaseAdapter, RouteMatch
from commiter.parser import node_text, find_nodes_by_type

if TYPE_CHECKING:
    from tree_sitter import Node, Tree

# Matches Flask route decorators: @app.route, @bp.route, @blueprint.route
ROUTE_DECORATOR_RE = re.compile(
    r"^(\w+)\.(route|get|post|put|delete|patch)\s*\("
)

# Extracts path parameters like <item_id> or <int:item_id>
PATH_PARAM_RE = re.compile(r"<(?:\w+:)?(\w+)>")

# HTTP method names
METHOD_MAP = {
    "get": "GET",
    "post": "POST",
    "put": "PUT",
    "delete": "DELETE",
    "patch": "PATCH",
    "route": None,  # determined by methods= kwarg
}

# Common Flask auth decorator patterns
AUTH_DECORATORS = {
    "login_required", "require_auth", "auth_required",
    "jwt_required", "token_required", "requires_auth",
}


class FlaskAdapter(BaseAdapter):
    framework_name = "flask"
    language = "python"

    def find_route_definitions(self, tree: Tree, source: bytes) -> list[RouteMatch]:
        routes = []
        root = tree.root_node

        for child in root.children:
            if child.type != "decorated_definition":
                continue

            decorators = []
            func_node = None
            for sub in child.children:
                if sub.type == "decorator":
                    decorators.append(sub)
                elif sub.type == "function_definition":
                    func_node = sub

            if func_node is None:
                continue

            for dec_node in decorators:
                dec_text = node_text(dec_node, source).lstrip("@").strip()
                match = ROUTE_DECORATOR_RE.match(dec_text)
                if not match:
                    continue

                router_var_name = match.group(1)
                method_shorthand = match.group(2)
                route_pattern = self._extract_route_string(dec_node, source)
                if not route_pattern:
                    continue

                methods = self._extract_methods(dec_node, source, method_shorthand)
                handler_name = self._get_func_name(func_node, source)

                for method in methods:
                    routes.append(RouteMatch(
                        http_method=method,
                        route_pattern=route_pattern,
                        handler_name=handler_name,
                        handler_node=func_node,
                        decorator_nodes=decorators,
                        line=func_node.start_point[0] + 1,
                        router_var=router_var_name,
                    ))

        return routes

    def extract_auth_info(self, route: RouteMatch, source: bytes) -> list[str]:
        auth = []
        for dec_node in route.decorator_nodes:
            dec_text = node_text(dec_node, source).lstrip("@").strip()
            # Check if any known auth decorator name appears
            for auth_name in AUTH_DECORATORS:
                if auth_name in dec_text:
                    auth.append(dec_text)
                    break
        return auth

    def extract_request_body_fields(self, route: RouteMatch, source: bytes) -> list[str]:
        """Find request.json["field"] and request.form["field"] accesses."""
        fields = []
        body = route.handler_node
        body_text = node_text(body, source)

        # Match request.json["field"], request.json.get("field"), request.form["field"]
        for match in re.finditer(r'request\.(?:json|form)(?:\[(["\'])(\w+)\1\]|\.get\(["\'](\w+)["\'])', body_text):
            field_name = match.group(2) or match.group(3)
            if field_name and field_name not in fields:
                fields.append(field_name)

        return fields

    def extract_response_fields(self, route: RouteMatch, source: bytes) -> list[str]:
        """Find keys in jsonify({...}) or return {...} dicts."""
        fields = []
        body_text = node_text(route.handler_node, source)

        # Match jsonify(key=value) pattern
        for match in re.finditer(r'jsonify\s*\(([^)]+)\)', body_text):
            args = match.group(1)
            for kv in re.finditer(r'(\w+)\s*=', args):
                key = kv.group(1)
                if key not in fields:
                    fields.append(key)

        # Match jsonify({"key": ...}) pattern
        for match in re.finditer(r'["\'](\w+)["\']\s*:', body_text):
            key = match.group(1)
            if key not in fields:
                fields.append(key)

        return fields

    def extract_path_params(self, route_pattern: str) -> list[str]:
        return PATH_PARAM_RE.findall(route_pattern)

    def _extract_route_string(self, dec_node: Node, source: bytes) -> str | None:
        """Extract the route pattern string from a decorator."""
        # Find the first string argument in the decorator call
        call_nodes = find_nodes_by_type(dec_node, "string")
        if call_nodes:
            text = node_text(call_nodes[0], source)
            # Strip quotes
            if len(text) >= 2:
                return text[1:-1]
        return None

    def _extract_methods(self, dec_node: Node, source: bytes, method_shorthand: str) -> list[str]:
        """Extract HTTP methods from the decorator."""
        if method_shorthand != "route":
            mapped = METHOD_MAP.get(method_shorthand)
            return [mapped] if mapped else ["GET"]

        # For @app.route(..., methods=["GET", "POST"])
        dec_text = node_text(dec_node, source)
        methods_match = re.search(r'methods\s*=\s*\[([^\]]+)\]', dec_text)
        if methods_match:
            raw = methods_match.group(1)
            return [m.strip().strip("\"'").upper() for m in raw.split(",")]

        return ["GET"]

    def _get_func_name(self, func_node: Node, source: bytes) -> str:
        name_node = func_node.child_by_field_name("name")
        if name_node:
            return node_text(name_node, source)
        return "<anonymous>"
