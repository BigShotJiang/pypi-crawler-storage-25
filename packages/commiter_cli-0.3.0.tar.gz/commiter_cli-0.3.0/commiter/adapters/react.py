"""React frontend adapter — detects fetch/axios API calls in components."""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node

from commiter.adapters.base import FrontendAdapter, APICallMatch
from commiter.parser import node_text, find_nodes_by_type, resolve_url_from_node

if TYPE_CHECKING:
    from tree_sitter import Tree

# HTTP methods for axios
AXIOS_METHODS = {"get", "post", "put", "delete", "patch", "request"}


class ReactAdapter(FrontendAdapter):
    framework_name = "react"
    language = "javascript"  # handles JS/TS/JSX/TSX

    def find_api_calls(self, tree: Tree, source: bytes, file_path: str = "",
                       constants: dict[str, str] | None = None) -> list[APICallMatch]:
        calls: list[APICallMatch] = []
        calls.extend(self._find_fetch_calls(tree.root_node, source, constants))
        calls.extend(self._find_axios_calls(tree.root_node, source, constants))
        return calls

    def _find_fetch_calls(self, root_node: Node, source: bytes,
                          constants: dict[str, str] | None = None) -> list[APICallMatch]:
        """Find fetch() calls with static, template, and concatenated URLs."""
        results = []
        call_nodes = find_nodes_by_type(root_node, "call_expression")

        for call in call_nodes:
            func = call.child_by_field_name("function")
            if not func:
                continue

            func_text = node_text(func, source)
            if func_text != "fetch":
                continue

            args = call.child_by_field_name("arguments")
            if not args:
                continue

            url = None
            method = "GET"

            for arg in args.children:
                if arg.type in ("string", "template_string", "binary_expression", "identifier", "member_expression"):
                    if url is None:  # first matching arg is the URL
                        url = resolve_url_from_node(arg, source, constants)
                elif arg.type == "object":
                    obj_text = node_text(arg, source)
                    method_match = re.search(r'method\s*:\s*["\'](\w+)["\']', obj_text)
                    if method_match:
                        method = method_match.group(1).upper()

            if url:
                results.append(APICallMatch(
                    http_method=method,
                    url_pattern=url,
                    call_node=call,
                    line=call.start_point[0] + 1,
                ))

        return results

    def _find_axios_calls(self, root_node: Node, source: bytes,
                          constants: dict[str, str] | None = None) -> list[APICallMatch]:
        """Find axios.get(), axios.post(), etc. with dynamic URL resolution."""
        results = []
        call_nodes = find_nodes_by_type(root_node, "call_expression")

        for call in call_nodes:
            func = call.child_by_field_name("function")
            if not func or func.type != "member_expression":
                continue

            func_text = node_text(func, source)

            match = re.match(r"(\w+)\.(get|post|put|delete|patch|request)", func_text)
            if not match:
                continue

            obj_name = match.group(1)
            if obj_name not in ("axios", "api", "client", "http", "axiosInstance", "apiClient"):
                continue

            method = match.group(2).upper()
            if method == "REQUEST":
                method = "GET"

            args = call.child_by_field_name("arguments")
            if not args:
                continue

            url = None
            for arg in args.children:
                if arg.type in ("string", "template_string", "binary_expression", "identifier", "member_expression"):
                    url = resolve_url_from_node(arg, source, constants)
                    if url:
                        break

            if url:
                response_type = self._extract_generic_type(call, source)
                results.append(APICallMatch(
                    http_method=method,
                    url_pattern=url,
                    call_node=call,
                    line=call.start_point[0] + 1,
                    response_type=response_type,
                ))

        return results

    def _extract_generic_type(self, call_node: Node, source: bytes) -> str | None:
        """Extract generic type parameter from calls like axios.post<UserResponse>(...)."""
        for child in call_node.children:
            if child.type == "type_arguments":
                for sub in child.children:
                    if sub.type not in ("<", ">", ","):
                        return node_text(sub, source).strip()
        return None
