"""Express.js adapter — recognizes Express route patterns."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import BaseAdapter, RouteMatch
from commiter.parser import node_text, find_nodes_by_type

if TYPE_CHECKING:
    from tree_sitter import Node, Tree

# Matches: app.get("/path", ...), router.post("/path", ...)
ROUTE_CALL_RE = re.compile(
    r"^(\w+)\.(get|post|put|delete|patch|all)\s*$"
)

# Express path params: /users/:id
PATH_PARAM_RE = re.compile(r":(\w+)")

# Common auth middleware names
AUTH_MIDDLEWARE = {
    "authenticate", "auth", "requireAuth", "isAuthenticated",
    "verifyToken", "requireLogin", "passport.authenticate",
    "authMiddleware", "protect",
}


class ExpressAdapter(BaseAdapter):
    framework_name = "express"
    language = "javascript"  # also works for TS via the extractor's language matching

    def find_route_definitions(self, tree: Tree, source: bytes) -> list[RouteMatch]:
        routes = []
        call_nodes = find_nodes_by_type(tree.root_node, "call_expression")

        for call in call_nodes:
            func_node = call.child_by_field_name("function")
            if not func_node or func_node.type != "member_expression":
                continue

            func_text = node_text(func_node, source)
            match = ROUTE_CALL_RE.match(func_text)
            if not match:
                continue

            router_var_name = match.group(1)
            method = match.group(2).upper()
            if method == "ALL":
                method = "ALL"

            args = call.child_by_field_name("arguments")
            if not args:
                continue

            # Skip app.all("*", ...) — that's middleware, not a route
            if method == "ALL":
                first_arg_text = ""
                for a in args.children:
                    if a.type in ("string", "template_string"):
                        first_arg_text = node_text(a, source).strip("'\"`")
                        break
                if first_arg_text == "*":
                    continue

            # First argument should be the route string
            route_pattern = None
            handler_node = None
            middleware_names: list[str] = []

            for i, arg in enumerate(args.children):
                if arg.type in ("string", "template_string"):
                    text = node_text(arg, source)
                    if text.startswith(("'", '"', "`")):
                        route_pattern = text[1:-1]
                elif arg.type in ("arrow_function", "function_expression", "function"):
                    handler_node = arg
                elif arg.type == "member_expression":
                    # Class-based handler: userController.getAll
                    handler_node = arg
                elif arg.type == "identifier":
                    name = node_text(arg, source)
                    if route_pattern is not None and handler_node is None:
                        # Could be middleware or the handler
                        middleware_names.append(name)

            if not route_pattern:
                continue

            # The handler name: try to find from handler node or infer from route
            handler_name = self._infer_handler_name(call, source, route_pattern, method, handler_node)

            routes.append(RouteMatch(
                http_method=method,
                route_pattern=route_pattern,
                handler_name=handler_name,
                handler_node=handler_node or call,
                decorator_nodes=[],
                line=call.start_point[0] + 1,
                router_var=router_var_name,
            ))

        return routes

    def extract_auth_info(self, route: RouteMatch, source: bytes) -> list[str]:
        """Check if any middleware arguments match known auth patterns."""
        auth = []
        # Re-examine the call node's arguments for middleware identifiers
        if route.handler_node and route.handler_node.parent:
            parent = route.handler_node.parent
            for child in parent.children:
                if child.type == "identifier":
                    name = node_text(child, source)
                    if name in AUTH_MIDDLEWARE:
                        auth.append(name)
        return auth

    def extract_request_body_fields(self, route: RouteMatch, source: bytes,
                                     type_definitions: dict | None = None) -> list[str]:
        """Find req.body fields from runtime accesses and TS type annotations."""
        fields = []
        if route.handler_node is None:
            return fields
        body_text = node_text(route.handler_node, source)

        # Try TS type annotation first: (req: Request<{}, {}, CreateUserBody>)
        body_type = self._extract_request_body_type(route.handler_node, source)
        if body_type:
            route.param_types["_request_body_type"] = body_type
            # Resolve from same-file type definitions if available
            if type_definitions and body_type in type_definitions:
                for tf in type_definitions[body_type]:
                    opt = "?" if tf.optional else ""
                    fields.append(f"{tf.name}: {tf.type_str}{opt}")
                return fields

        # Fallback: runtime field accesses
        # req.body.fieldName
        for match in re.finditer(r'req\.body\.(\w+)', body_text):
            field = match.group(1)
            if field not in fields:
                fields.append(field)

        # req.body["fieldName"] or req.body['fieldName']
        for match in re.finditer(r'req\.body\[(["\'])(\w+)\1\]', body_text):
            field = match.group(2)
            if field not in fields:
                fields.append(field)

        # Destructuring: const { name, email } = req.body
        for match in re.finditer(r'\{([^}]+)\}\s*=\s*req\.body', body_text):
            for name in match.group(1).split(","):
                field = name.strip().split(":")[0].strip()
                if field and field not in fields:
                    fields.append(field)

        return fields

    def _extract_request_body_type(self, handler_node: Node, source: bytes) -> str | None:
        """Extract the body type from Request<Params, ResBody, ReqBody> annotation."""
        handler_text = node_text(handler_node, source)
        # Match: req: Request<any, any, CreateUserBody> or req: Request<{}, {}, CreateUserBody>
        match = re.search(r':\s*Request\s*<[^,]*,[^,]*,\s*(\w+)\s*>', handler_text)
        if match:
            return match.group(1)
        return None

    def extract_response_fields(self, route: RouteMatch, source: bytes) -> list[str]:
        """Find fields in res.json({...}) calls."""
        fields = []
        if route.handler_node is None:
            return fields
        body_text = node_text(route.handler_node, source)

        for match in re.finditer(r'(\w+)\s*:', body_text):
            key = match.group(1)
            # Filter out common non-response keys
            if key not in ("const", "let", "var", "if", "else", "return", "function", "async", "await"):
                if key not in fields:
                    fields.append(key)

        return fields

    def extract_path_params(self, route_pattern: str) -> list[str]:
        return PATH_PARAM_RE.findall(route_pattern)

    def _infer_handler_name(self, call: Node, source: bytes, route: str, method: str,
                            handler_node: "Node | None" = None) -> str:
        """Try to get a handler name from the handler node, assignment, or route."""
        # Class-based handler: userController.getAll -> "UserController.getAll"
        if handler_node and handler_node.type == "member_expression":
            return node_text(handler_node, source)

        # Check if this call is part of an assignment
        parent = call.parent
        if parent and parent.type in ("variable_declarator", "assignment_expression"):
            name_node = parent.child_by_field_name("name") or parent.child_by_field_name("left")
            if name_node:
                return node_text(name_node, source)

        # Fallback: method + route
        clean_route = route.replace("/", "_").strip("_")
        return f"{method.lower()}_{clean_route}" if clean_route else method.lower()
