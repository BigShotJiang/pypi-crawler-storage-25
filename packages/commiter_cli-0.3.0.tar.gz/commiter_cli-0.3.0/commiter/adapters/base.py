"""Base adapter interface — teaches extractors what framework patterns look like."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node, Tree


@dataclass
class RouteMatch:
    """A matched route definition in source code."""
    http_method: str
    route_pattern: str
    handler_name: str
    handler_node: "Node"
    decorator_nodes: list["Node"] = field(default_factory=list)
    line: int = 0
    param_types: dict[str, str] = field(default_factory=dict)
    router_var: str = ""  # variable name the route is defined on (e.g. "bp", "router", "app")


@dataclass
class APICallMatch:
    """A matched outbound API call in frontend code."""
    http_method: str
    url_pattern: str
    call_node: "Node"
    line: int = 0
    response_type: str | None = None
    body_type: str | None = None


@dataclass
class DBOpMatch:
    """A matched database operation."""
    operation_type: str  # select, insert, update, delete
    table_name: str
    call_node: "Node"
    line: int = 0
    filters: list[str] = field(default_factory=list)


class BaseAdapter(ABC):
    """Abstract adapter that framework-specific adapters inherit from."""

    framework_name: str = "base"
    language: str = "unknown"

    @abstractmethod
    def find_route_definitions(self, tree: "Tree", source: bytes) -> list[RouteMatch]:
        """Find all route/endpoint definitions in a parsed file."""
        ...

    def extract_auth_info(self, route: RouteMatch, source: bytes) -> list[str]:
        """Find auth decorators/middleware on a handler. Override per framework."""
        return []

    def extract_request_body_fields(self, route: RouteMatch, source: bytes) -> list[str]:
        """Infer request body field names from handler. Override per framework."""
        return []

    def extract_response_fields(self, route: RouteMatch, source: bytes) -> list[str]:
        """Infer response field names from return statements. Override per framework."""
        return []

    def extract_path_params(self, route_pattern: str) -> list[str]:
        """Extract path parameter names from a route pattern. Override per framework."""
        return []


class FrontendAdapter(ABC):
    """Adapter for detecting outbound API calls in frontend code."""

    framework_name: str = "base-frontend"
    language: str = "unknown"

    @abstractmethod
    def find_api_calls(self, tree: "Tree", source: bytes) -> list[APICallMatch]:
        """Find outbound HTTP/API calls in frontend code."""
        ...


class DBAdapter(ABC):
    """Adapter for detecting database operations."""

    orm_name: str = "base-db"
    language: str = "unknown"

    @abstractmethod
    def find_db_operations(self, tree: "Tree", source: bytes) -> list[DBOpMatch]:
        """Find database operations."""
        ...
