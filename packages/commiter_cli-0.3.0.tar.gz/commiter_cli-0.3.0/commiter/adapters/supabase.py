"""Supabase adapter — detects Supabase client DB operations (Python + JS)."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import DBAdapter, DBOpMatch
from commiter.parser import node_text, find_nodes_by_type

if TYPE_CHECKING:
    from tree_sitter import Tree

# Operation method names in Supabase client chain
OPERATION_MAP = {
    "select": "select",
    "insert": "insert",
    "update": "update",
    "delete": "delete",
    "upsert": "upsert",
}


class SupabaseAdapter(DBAdapter):
    orm_name = "supabase"
    language = "python"  # works for both Python and JS

    def find_db_operations(self, tree: Tree, source: bytes) -> list[DBOpMatch]:
        ops = []
        call_nodes = find_nodes_by_type(tree.root_node, "call_expression" if b"supabase" in source else "call")

        # Use regex on source for reliability across both Python and JS ASTs
        text = source.decode("utf-8", errors="replace")

        # Match patterns like:
        #   supabase.table("users").select(...)
        #   supabase.from("users").select(...)
        #   supabase.from_("users").select(...)   (Python client)
        for match in re.finditer(
            r'(?:supabase|db|client)\s*\.\s*(?:table|from_?)\s*\(\s*["\'](\w+)["\']\s*\)\s*\.\s*(\w+)',
            text,
        ):
            table_name = match.group(1)
            method = match.group(2)
            op_type = OPERATION_MAP.get(method)
            if not op_type:
                continue

            line = text[:match.start()].count("\n") + 1
            filters = self._extract_filters(text, match.end())

            ops.append(DBOpMatch(
                operation_type=op_type,
                table_name=table_name,
                call_node=tree.root_node,  # placeholder
                line=line,
                filters=filters,
            ))

        return ops

    def _extract_filters(self, text: str, start: int) -> list[str]:
        """Extract .eq(), .neq(), .gt() etc. filter calls after the operation."""
        filters = []
        remaining = text[start:start + 500]  # look ahead
        for match in re.finditer(r'\.\s*(eq|neq|gt|gte|lt|lte|in_|like|ilike|is_|contains)\s*\(\s*["\'](\w+)["\']', remaining):
            filters.append(f"{match.group(1)}({match.group(2)})")
        return filters
