"""SQLAlchemy adapter — detects SQLAlchemy ORM database operations."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import DBAdapter, DBOpMatch

if TYPE_CHECKING:
    from tree_sitter import Tree

# SQLAlchemy session methods to operation types
SA_OP_MAP = {
    "query": "select",
    "add": "insert",
    "add_all": "insert",
    "merge": "upsert",
    "delete": "delete",
    "execute": "query",
}


class SQLAlchemyAdapter(DBAdapter):
    orm_name = "sqlalchemy"
    language = "python"

    def find_db_operations(self, tree: Tree, source: bytes) -> list[DBOpMatch]:
        ops = []
        text = source.decode("utf-8", errors="replace")

        # Pattern 1: session.query(Model).filter_by(...) / session.query(Model).filter(...)
        for match in re.finditer(
            r'(?:session|db)\s*\.\s*query\s*\(\s*(\w+)\s*\)',
            text,
        ):
            model_name = match.group(1)
            line = text[:match.start()].count("\n") + 1
            filters = self._extract_sa_filters(text, match.end())

            ops.append(DBOpMatch(
                operation_type="select",
                table_name=model_name,
                call_node=tree.root_node,
                line=line,
                filters=filters,
            ))

        # Pattern 2: session.add(instance), session.delete(instance)
        for match in re.finditer(
            r'(?:session|db)\s*\.\s*(add|add_all|delete|merge)\s*\(',
            text,
        ):
            method = match.group(1)
            op_type = SA_OP_MAP.get(method, "unknown")
            line = text[:match.start()].count("\n") + 1

            ops.append(DBOpMatch(
                operation_type=op_type,
                table_name="<from_instance>",
                call_node=tree.root_node,
                line=line,
            ))

        # Pattern 3: Model.query.filter_by(...) (Flask-SQLAlchemy style)
        for match in re.finditer(
            r'(\b[A-Z]\w+)\s*\.\s*query\s*\.',
            text,
        ):
            model_name = match.group(1)
            line = text[:match.start()].count("\n") + 1
            filters = self._extract_sa_filters(text, match.end())

            ops.append(DBOpMatch(
                operation_type="select",
                table_name=model_name,
                call_node=tree.root_node,
                line=line,
                filters=filters,
            ))

        return ops

    def _extract_sa_filters(self, text: str, start: int) -> list[str]:
        """Extract filter field names from .filter_by(field=...) or .filter(Model.field == ...)."""
        filters = []
        remaining = text[start:start + 500]

        # filter_by(field=value)
        fb_match = re.search(r'\.filter_by\s*\(([^)]+)\)', remaining)
        if fb_match:
            for field in re.finditer(r'(\w+)\s*=', fb_match.group(1)):
                filters.append(field.group(1))

        # filter(Model.field == value)
        for match in re.finditer(r'\.filter\s*\([^)]*?\.(\w+)\s*[=!<>]', remaining):
            filters.append(match.group(1))

        return filters
