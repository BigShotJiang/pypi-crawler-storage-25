"""Raw SQL adapter — detects database operations from raw SQL execution calls.

Detects patterns like:
  Python:  cursor.execute("SELECT * FROM users"), db.execute(text("INSERT INTO ..."))
  JS/TS:   pool.query("SELECT * FROM orders"), knex.raw("DELETE FROM sessions")
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import DBAdapter, DBOpMatch

if TYPE_CHECKING:
    from tree_sitter import Tree

# Regex for SQL execution method calls across Python and JS
# Matches: cursor.execute(, db.execute(, pool.query(, client.query(, knex.raw(, etc.
_SQL_EXEC_RE = re.compile(
    r'(?:cursor|stmt|db|conn|connection|pool|client|session|knex)'
    r'\s*\.\s*'
    r'(?:execute|query|raw|all|run|get|fetchall|fetchone|fetchmany)'
    r'\s*\(',
    re.IGNORECASE,
)

# SQL operation classification
_SQL_OP_RE = re.compile(
    r'^\s*(SELECT|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|TRUNCATE)',
    re.IGNORECASE,
)

# Table name extraction patterns
_TABLE_FROM_RE = re.compile(r'\bFROM\s+[`"\']?(\w+)[`"\']?', re.IGNORECASE)
_TABLE_INTO_RE = re.compile(r'\bINTO\s+[`"\']?(\w+)[`"\']?', re.IGNORECASE)
_TABLE_UPDATE_RE = re.compile(r'\bUPDATE\s+[`"\']?(\w+)[`"\']?', re.IGNORECASE)
_TABLE_JOIN_RE = re.compile(r'\bJOIN\s+[`"\']?(\w+)[`"\']?', re.IGNORECASE)
_TABLE_TRUNCATE_RE = re.compile(r'\bTRUNCATE\s+(?:TABLE\s+)?[`"\']?(\w+)[`"\']?', re.IGNORECASE)


class RawSQLAdapter(DBAdapter):
    """Detects database operations from raw SQL strings in execute/query calls."""

    orm_name = "raw_sql"
    language = "python"  # works for both Python and JS via regex on source text

    def find_db_operations(self, tree: "Tree", source: bytes) -> list[DBOpMatch]:
        ops = []
        text = source.decode("utf-8", errors="replace")

        for match in _SQL_EXEC_RE.finditer(text):
            line = text[:match.start()].count("\n") + 1

            # Extract the SQL string from the first argument
            sql = self._extract_sql_string(text, match.end())
            if not sql:
                continue

            # Classify the operation
            op_type = self._classify_sql(sql)
            if not op_type:
                continue

            # Extract table names
            tables = self._extract_table_names(sql)
            if not tables:
                # We found SQL but couldn't parse a table name
                ops.append(DBOpMatch(
                    operation_type=op_type,
                    table_name="<dynamic>",
                    call_node=tree.root_node,
                    line=line,
                ))
                continue

            # Create an operation for each table found
            for table in tables:
                filters = self._extract_where_fields(sql)
                ops.append(DBOpMatch(
                    operation_type=op_type,
                    table_name=table,
                    call_node=tree.root_node,
                    line=line,
                    filters=filters,
                ))

        return ops

    def _extract_sql_string(self, text: str, start: int) -> str | None:
        """Extract the SQL string from the first argument after an opening paren.

        Handles:
          execute("SELECT ...")
          execute(text("SELECT ..."))
          execute(`SELECT ...`)
          query('SELECT ...')
        """
        remaining = text[start:start + 1000]  # look ahead

        # Skip whitespace
        remaining = remaining.lstrip()

        # Handle text() wrapper: execute(text("SELECT ..."))
        if remaining.startswith("text("):
            remaining = remaining[5:].lstrip()

        # Find the string delimiter
        if not remaining:
            return None

        delimiter = None
        if remaining[0] in ("'", '"', "`"):
            delimiter = remaining[0]
        elif remaining[0] == 'f' and len(remaining) > 1 and remaining[1] in ("'", '"'):
            # Python f-string: f"SELECT ..."
            delimiter = remaining[1]
            remaining = remaining[1:]
        else:
            return None

        # Handle triple quotes
        if remaining[:3] in ('"""', "'''"):
            end_delim = remaining[:3]
            content_start = 3
            end_idx = remaining.find(end_delim, content_start)
            if end_idx != -1:
                return remaining[content_start:end_idx].strip()
            return None

        # Single delimiter
        content_start = 1
        i = content_start
        while i < len(remaining):
            if remaining[i] == "\\" :
                i += 2  # skip escaped char
                continue
            if remaining[i] == delimiter:
                return remaining[content_start:i].strip()
            i += 1

        return None

    def _classify_sql(self, sql: str) -> str | None:
        """Classify SQL statement type."""
        match = _SQL_OP_RE.match(sql)
        if not match:
            return None

        op = match.group(1).upper()
        if op == "SELECT":
            return "select"
        elif op == "INSERT":
            return "insert"
        elif op == "UPDATE":
            return "update"
        elif op in ("DELETE", "TRUNCATE"):
            return "delete"
        elif op in ("CREATE", "ALTER", "DROP"):
            return "ddl"
        return "query"

    def _extract_table_names(self, sql: str) -> list[str]:
        """Extract table names from a SQL statement."""
        tables = []
        seen = set()

        for pattern in (_TABLE_FROM_RE, _TABLE_INTO_RE, _TABLE_UPDATE_RE, _TABLE_JOIN_RE, _TABLE_TRUNCATE_RE):
            for match in pattern.finditer(sql):
                table = match.group(1)
                # Filter out SQL keywords that might match
                if table.upper() not in ("SELECT", "WHERE", "SET", "VALUES", "AND", "OR",
                                          "NOT", "NULL", "TABLE", "INDEX", "VIEW", "AS",
                                          "ON", "IN", "EXISTS", "LIKE", "BETWEEN"):
                    if table not in seen:
                        seen.add(table)
                        tables.append(table)

        return tables

    def _extract_where_fields(self, sql: str) -> list[str]:
        """Extract column names from WHERE clause."""
        filters = []
        where_match = re.search(r'\bWHERE\b(.+?)(?:ORDER|GROUP|LIMIT|HAVING|$)', sql, re.IGNORECASE)
        if where_match:
            where_clause = where_match.group(1)
            for col_match in re.finditer(r'(\w+)\s*(?:=|!=|<>|>|<|>=|<=|LIKE|IN|IS)\s', where_clause, re.IGNORECASE):
                col = col_match.group(1)
                if col.upper() not in ("AND", "OR", "NOT"):
                    filters.append(col)
        return filters
