"""Next.js adapter — recognizes API routes and page components."""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

from commiter.adapters.base import BaseAdapter, RouteMatch
from commiter.parser import node_text, find_nodes_by_type

if TYPE_CHECKING:
    from tree_sitter import Node, Tree

# HTTP method export names in App Router route.ts files
APP_ROUTER_METHODS = {"GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"}


class NextJSAdapter(BaseAdapter):
    framework_name = "nextjs"
    language = "typescript"  # also handles tsx, js, jsx via can_handle_language

    _file_path: str = ""

    def can_handle_language(self, language: str) -> bool:
        return language in ("typescript", "tsx", "javascript")

    def find_route_definitions(self, tree: Tree, source: bytes, file_path: str = "") -> list[RouteMatch]:
        """Detect Next.js API routes from file conventions."""
        self._file_path = file_path

        if self._is_app_router_route(file_path):
            return self._find_app_router_routes(tree, source, file_path)
        elif self._is_pages_api_route(file_path):
            return self._find_pages_api_routes(tree, source, file_path)
        return []

    def _is_app_router_route(self, file_path: str) -> bool:
        """Check if this is an App Router route file (app/**/route.ts)."""
        name = Path(file_path).stem
        return name == "route" and "/app/" in file_path

    def _is_pages_api_route(self, file_path: str) -> bool:
        """Check if this is a Pages Router API route (pages/api/**/*.ts)."""
        return "/pages/api/" in file_path

    def _find_app_router_routes(self, tree: Tree, source: bytes, file_path: str) -> list[RouteMatch]:
        """Find named exports like `export async function GET(request) {...}`."""
        routes = []
        route_pattern = self._path_to_route(file_path, "app")

        root = tree.root_node
        for child in root.children:
            if child.type != "export_statement":
                continue

            # Look for function declarations inside exports
            for sub in child.children:
                func_node = None
                if sub.type == "function_declaration":
                    func_node = sub
                elif sub.type == "lexical_declaration":
                    # const GET = async (...) => {...}
                    for decl in sub.children:
                        if decl.type == "variable_declarator":
                            name_node = decl.child_by_field_name("name")
                            if name_node:
                                name = node_text(name_node, source)
                                if name in APP_ROUTER_METHODS:
                                    routes.append(RouteMatch(
                                        http_method=name,
                                        route_pattern=route_pattern,
                                        handler_name=name,
                                        handler_node=decl,
                                        line=decl.start_point[0] + 1,
                                    ))

                if func_node:
                    name_node = func_node.child_by_field_name("name")
                    if name_node:
                        name = node_text(name_node, source)
                        if name in APP_ROUTER_METHODS:
                            routes.append(RouteMatch(
                                http_method=name,
                                route_pattern=route_pattern,
                                handler_name=name,
                                handler_node=func_node,
                                line=func_node.start_point[0] + 1,
                            ))

        return routes

    def _find_pages_api_routes(self, tree: Tree, source: bytes, file_path: str) -> list[RouteMatch]:
        """Find default export handler in pages/api/ files."""
        routes = []
        route_pattern = self._path_to_route(file_path, "pages")
        root = tree.root_node

        # Look for `export default function handler(req, res)` or
        # `export default async (req, res) => {}`
        for child in root.children:
            if child.type != "export_statement":
                continue

            text = node_text(child, source)
            if "default" not in text:
                continue

            for sub in child.children:
                if sub.type in ("function_declaration", "arrow_function", "function_expression"):
                    handler_name = "handler"
                    if sub.type == "function_declaration":
                        name_node = sub.child_by_field_name("name")
                        if name_node:
                            handler_name = node_text(name_node, source)

                    # Pages API routes handle all methods — check for req.method inside
                    methods = self._detect_methods_from_body(sub, source)
                    if not methods:
                        methods = ["ALL"]

                    for method in methods:
                        routes.append(RouteMatch(
                            http_method=method,
                            route_pattern=route_pattern,
                            handler_name=handler_name,
                            handler_node=sub,
                            line=sub.start_point[0] + 1,
                        ))

        return routes

    def _detect_methods_from_body(self, node: Node, source: bytes) -> list[str]:
        """Check for req.method === 'GET' patterns inside handler."""
        body_text = node_text(node, source)
        methods = []
        for method in ("GET", "POST", "PUT", "DELETE", "PATCH"):
            if f'"{method}"' in body_text or f"'{method}'" in body_text:
                methods.append(method)
        return methods

    def _path_to_route(self, file_path: str, router_type: str) -> str:
        """Convert file path to API route pattern.

        app/api/users/[id]/route.ts -> /api/users/[id]
        pages/api/users/[id].ts -> /api/users/[id]
        """
        path = Path(file_path)
        parts = path.parts

        # Find the router root
        try:
            if router_type == "app":
                idx = parts.index("app")
                route_parts = parts[idx + 1:]
                # Remove the "route.ts" file
                route_parts = route_parts[:-1]
            else:
                idx = parts.index("pages")
                route_parts = parts[idx + 1:]
                # Remove file extension from last part
                last = Path(route_parts[-1]).stem
                route_parts = list(route_parts[:-1]) + [last]
                # Remove "index" from the end
                if route_parts and route_parts[-1] == "index":
                    route_parts = route_parts[:-1]
        except (ValueError, IndexError):
            return file_path

        route = "/" + "/".join(route_parts)
        # Convert [param] to :param for display consistency
        route = re.sub(r"\[\.\.\.(\w+)\]", r"*\1", route)  # catch-all
        route = re.sub(r"\[(\w+)\]", r":\1", route)
        return route

    def extract_path_params(self, route_pattern: str) -> list[str]:
        """Extract params from Next.js patterns like :id or [id]."""
        params = re.findall(r":(\w+)", route_pattern)
        params += re.findall(r"\[(\w+)\]", route_pattern)
        return params
