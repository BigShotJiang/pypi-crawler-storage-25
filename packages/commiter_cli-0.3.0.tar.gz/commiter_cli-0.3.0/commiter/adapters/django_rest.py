"""Django REST Framework adapter — recognizes DRF ViewSet and APIView patterns."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import BaseAdapter, RouteMatch
from commiter.parser import node_text, find_nodes_by_type

if TYPE_CHECKING:
    from tree_sitter import Node, Tree

# DRF ViewSet action methods
VIEWSET_ACTIONS = {
    "list": "GET",
    "create": "POST",
    "retrieve": "GET",
    "update": "PUT",
    "partial_update": "PATCH",
    "destroy": "DELETE",
}

# DRF APIView method mapping
APIVIEW_METHODS = {"get", "post", "put", "patch", "delete", "head", "options"}

# Common DRF auth/permission classes
AUTH_CLASSES = {
    "IsAuthenticated", "IsAdminUser", "IsAuthenticatedOrReadOnly",
    "AllowAny", "DjangoModelPermissions", "TokenAuthentication",
    "SessionAuthentication", "JWTAuthentication",
}


class DjangoRESTAdapter(BaseAdapter):
    framework_name = "django-rest"
    language = "python"

    def find_route_definitions(self, tree: Tree, source: bytes) -> list[RouteMatch]:
        routes = []
        text = source.decode("utf-8", errors="replace")

        # Strategy 1: Find ViewSet classes and their action methods
        routes.extend(self._find_viewset_routes(tree, source, text))

        # Strategy 2: Find APIView classes with get/post/put/delete methods
        routes.extend(self._find_apiview_routes(tree, source, text))

        # Strategy 3: Find @api_view decorated functions
        routes.extend(self._find_api_view_functions(tree, source))

        return routes

    def _find_viewset_routes(self, tree: Tree, source: bytes, text: str) -> list[RouteMatch]:
        routes = []
        root = tree.root_node

        for child in root.children:
            if child.type != "class_definition":
                continue

            class_text = node_text(child, source)
            class_name = ""
            name_node = child.child_by_field_name("name")
            if name_node:
                class_name = node_text(name_node, source)

            # Check if it inherits from a ViewSet
            superclasses = node_text(child.child_by_field_name("superclasses"), source) if child.child_by_field_name("superclasses") else ""
            if not any(vs in superclasses for vs in ("ViewSet", "ModelViewSet", "GenericViewSet", "ReadOnlyModelViewSet")):
                continue

            # Find action methods in the class body
            body = child.child_by_field_name("body")
            if not body:
                continue

            for member in body.children:
                if member.type == "function_definition":
                    method_name_node = member.child_by_field_name("name")
                    if not method_name_node:
                        continue
                    method_name = node_text(method_name_node, source)

                    if method_name in VIEWSET_ACTIONS:
                        http_method = VIEWSET_ACTIONS[method_name]
                        route = self._infer_viewset_route(class_name, method_name)
                        routes.append(RouteMatch(
                            http_method=http_method,
                            route_pattern=route,
                            handler_name=f"{class_name}.{method_name}",
                            handler_node=member,
                            line=member.start_point[0] + 1,
                        ))

                # Also check for decorated definitions (custom actions)
                elif member.type == "decorated_definition":
                    decorators = []
                    func_node = None
                    for sub in member.children:
                        if sub.type == "decorator":
                            decorators.append(node_text(sub, source))
                        elif sub.type == "function_definition":
                            func_node = sub

                    if func_node:
                        func_name_node = func_node.child_by_field_name("name")
                        if func_name_node:
                            func_name = node_text(func_name_node, source)
                            for dec in decorators:
                                if "@action" in dec:
                                    methods_match = re.search(r'methods\s*=\s*\[([^\]]+)\]', dec)
                                    methods = ["POST"]
                                    if methods_match:
                                        methods = [m.strip().strip("\"'").upper() for m in methods_match.group(1).split(",")]
                                    for m in methods:
                                        route = self._infer_viewset_route(class_name, func_name)
                                        routes.append(RouteMatch(
                                            http_method=m,
                                            route_pattern=f"{route}{func_name}/",
                                            handler_name=f"{class_name}.{func_name}",
                                            handler_node=func_node,
                                            line=func_node.start_point[0] + 1,
                                        ))

        return routes

    def _find_apiview_routes(self, tree: Tree, source: bytes, text: str) -> list[RouteMatch]:
        routes = []
        root = tree.root_node

        for child in root.children:
            if child.type != "class_definition":
                continue

            name_node = child.child_by_field_name("name")
            if not name_node:
                continue
            class_name = node_text(name_node, source)

            superclasses = child.child_by_field_name("superclasses")
            if not superclasses:
                continue
            super_text = node_text(superclasses, source)
            if "APIView" not in super_text:
                continue

            body = child.child_by_field_name("body")
            if not body:
                continue

            for member in body.children:
                if member.type == "function_definition":
                    method_name_node = member.child_by_field_name("name")
                    if not method_name_node:
                        continue
                    method_name = node_text(method_name_node, source)

                    if method_name in APIVIEW_METHODS:
                        route = self._infer_class_route(class_name)
                        routes.append(RouteMatch(
                            http_method=method_name.upper(),
                            route_pattern=route,
                            handler_name=f"{class_name}.{method_name}",
                            handler_node=member,
                            line=member.start_point[0] + 1,
                        ))

        return routes

    def _find_api_view_functions(self, tree: Tree, source: bytes) -> list[RouteMatch]:
        """Find @api_view(['GET', 'POST']) decorated functions."""
        routes = []
        root = tree.root_node

        for child in root.children:
            if child.type != "decorated_definition":
                continue

            decorators = []
            func_node = None
            for sub in child.children:
                if sub.type == "decorator":
                    decorators.append(sub)
                elif sub.type == "function_definition":
                    func_node = sub

            if not func_node:
                continue

            for dec in decorators:
                dec_text = node_text(dec, source)
                if "api_view" not in dec_text:
                    continue

                methods_match = re.search(r'\[([^\]]+)\]', dec_text)
                methods = ["GET"]
                if methods_match:
                    methods = [m.strip().strip("\"'").upper() for m in methods_match.group(1).split(",")]

                func_name_node = func_node.child_by_field_name("name")
                handler_name = node_text(func_name_node, source) if func_name_node else "<anonymous>"

                for method in methods:
                    routes.append(RouteMatch(
                        http_method=method,
                        route_pattern=f"/{handler_name.replace('_', '-')}/",
                        handler_name=handler_name,
                        handler_node=func_node,
                        decorator_nodes=decorators,
                        line=func_node.start_point[0] + 1,
                    ))

        return routes

    def extract_auth_info(self, route: RouteMatch, source: bytes) -> list[str]:
        """Detect permission_classes and authentication_classes."""
        auth = []
        # Check if parent class has permission_classes
        handler_text = node_text(route.handler_node, source) if route.handler_node else ""

        # Check class-level attributes (look in parent)
        parent = route.handler_node.parent if route.handler_node else None
        if parent:
            parent_text = node_text(parent, source)
            for cls in AUTH_CLASSES:
                if cls in parent_text:
                    auth.append(cls)

        return auth

    def extract_path_params(self, route_pattern: str) -> list[str]:
        return re.findall(r"<(?:\w+:)?(\w+)>", route_pattern)

    def _infer_viewset_route(self, class_name: str, action: str) -> str:
        """Infer route from ViewSet class name: UserViewSet -> /users/"""
        name = class_name.replace("ViewSet", "").replace("View", "")
        name = re.sub(r"(?<!^)(?=[A-Z])", "-", name).lower()
        if action in ("retrieve", "update", "partial_update", "destroy"):
            return f"/{name}s/<pk>/"
        return f"/{name}s/"

    def _infer_class_route(self, class_name: str) -> str:
        """Infer route from APIView class name."""
        name = class_name.replace("APIView", "").replace("View", "")
        name = re.sub(r"(?<!^)(?=[A-Z])", "-", name).lower()
        return f"/{name}/"
