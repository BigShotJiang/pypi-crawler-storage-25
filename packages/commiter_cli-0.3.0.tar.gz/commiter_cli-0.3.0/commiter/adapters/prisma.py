"""Prisma adapter — detects Prisma ORM database operations."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import DBAdapter, DBOpMatch

if TYPE_CHECKING:
    from tree_sitter import Tree

# Prisma methods to operation types
PRISMA_OP_MAP = {
    "findUnique": "select",
    "findFirst": "select",
    "findMany": "select",
    "create": "insert",
    "createMany": "insert",
    "update": "update",
    "updateMany": "update",
    "upsert": "upsert",
    "delete": "delete",
    "deleteMany": "delete",
    "count": "select",
    "aggregate": "select",
    "groupBy": "select",
}


class PrismaAdapter(DBAdapter):
    orm_name = "prisma"
    language = "javascript"  # TypeScript too

    def find_db_operations(self, tree: Tree, source: bytes) -> list[DBOpMatch]:
        ops = []
        text = source.decode("utf-8", errors="replace")

        # Match: prisma.user.findMany(...), prisma.post.create(...)
        for match in re.finditer(
            r'(?:prisma|db|client)\s*\.\s*(\w+)\s*\.\s*(\w+)\s*\(',
            text,
        ):
            model_name = match.group(1)
            method = match.group(2)

            # Skip non-model methods
            if model_name.startswith("$") or model_name in ("_", "use"):
                continue

            op_type = PRISMA_OP_MAP.get(method)
            if not op_type:
                continue

            line = text[:match.start()].count("\n") + 1
            filters = self._extract_where_fields(text, match.end())

            ops.append(DBOpMatch(
                operation_type=op_type,
                table_name=model_name,
                call_node=tree.root_node,
                line=line,
                filters=filters,
            ))

        return ops

    def _extract_where_fields(self, text: str, start: int) -> list[str]:
        """Extract field names from where: { field: ... } clauses."""
        filters = []
        remaining = text[start:start + 500]
        where_match = re.search(r'where\s*:\s*\{([^}]+)\}', remaining)
        if where_match:
            for field in re.finditer(r'(\w+)\s*:', where_match.group(1)):
                filters.append(field.group(1))
        return filters
