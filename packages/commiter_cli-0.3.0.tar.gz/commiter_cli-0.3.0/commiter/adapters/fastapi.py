"""FastAPI adapter — recognizes FastAPI route patterns."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from commiter.adapters.base import BaseAdapter, RouteMatch
from commiter.parser import node_text, find_nodes_by_type

if TYPE_CHECKING:
    from tree_sitter import Node, Tree

# Matches FastAPI route decorators: @app.get, @router.post, etc.
ROUTE_DECORATOR_RE = re.compile(
    r"^(\w+)\.(get|post|put|delete|patch)\s*\("
)

# Path parameters: {item_id} or {item_id:int}
PATH_PARAM_RE = re.compile(r"\{(\w+)(?::\w+)?\}")

# Common FastAPI auth dependency patterns
AUTH_PATTERNS = {
    "Depends(get_current_user", "Depends(require_auth",
    "Depends(authenticate", "Security(",
}


class FastAPIAdapter(BaseAdapter):
    framework_name = "fastapi"
    language = "python"

    def find_route_definitions(self, tree: Tree, source: bytes) -> list[RouteMatch]:
        routes = []
        root = tree.root_node

        for child in root.children:
            if child.type != "decorated_definition":
                continue

            decorators = []
            func_node = None
            for sub in child.children:
                if sub.type == "decorator":
                    decorators.append(sub)
                elif sub.type == "function_definition":
                    func_node = sub

            if func_node is None:
                continue

            for dec_node in decorators:
                dec_text = node_text(dec_node, source).lstrip("@").strip()
                match = ROUTE_DECORATOR_RE.match(dec_text)
                if not match:
                    continue

                router_var_name = match.group(1)
                method = match.group(2).upper()
                route_pattern = self._extract_route_string(dec_node, source)
                if not route_pattern:
                    continue

                handler_name = self._get_func_name(func_node, source)

                routes.append(RouteMatch(
                    http_method=method,
                    route_pattern=route_pattern,
                    handler_name=handler_name,
                    handler_node=func_node,
                    decorator_nodes=decorators,
                    line=func_node.start_point[0] + 1,
                    router_var=router_var_name,
                ))

        return routes

    def extract_auth_info(self, route: RouteMatch, source: bytes) -> list[str]:
        """Detect Depends() auth patterns in function parameters."""
        auth = []
        # Check decorators
        for dec_node in route.decorator_nodes:
            dec_text = node_text(dec_node, source)
            for pattern in AUTH_PATTERNS:
                if pattern in dec_text:
                    auth.append(dec_text.lstrip("@").strip())

        # Check function parameters for Depends(get_current_user)
        params_node = route.handler_node.child_by_field_name("parameters")
        if params_node:
            params_text = node_text(params_node, source)
            for pattern in AUTH_PATTERNS:
                if pattern in params_text:
                    auth.append(pattern.rstrip("("))

        return auth

    def extract_request_body_fields(self, route: RouteMatch, source: bytes,
                                     type_definitions: dict | None = None) -> list[str]:
        """Extract field names from Pydantic model type hints in parameters.

        If type_definitions is provided (same-file type info), resolves model fields.
        """
        fields = []
        body_type = None
        params_node = route.handler_node.child_by_field_name("parameters")
        if not params_node:
            return fields

        params_text = node_text(params_node, source)

        for match in re.finditer(r'(\w+)\s*:\s*(\w+)', params_text):
            param_name = match.group(1)
            type_name = match.group(2)
            if type_name in ("str", "int", "float", "bool", "list", "dict", "Optional", "Request", "Response"):
                continue
            if param_name in ("self", "request", "response", "db", "session"):
                continue
            if type_name[0].isupper():
                body_type = type_name
                # Try to resolve the model's fields from same-file definitions
                if type_definitions and type_name in type_definitions:
                    for tf in type_definitions[type_name]:
                        opt = "?" if tf.optional else ""
                        fields.append(f"{tf.name}: {tf.type_str}{opt}")
                else:
                    fields.append(f"{param_name}: {type_name}")

        # Store the body type name on the route for the extractor to pick up
        if body_type:
            route.param_types["_request_body_type"] = body_type

        return fields

    def extract_response_fields(self, route: RouteMatch, source: bytes) -> list[str]:
        """Extract response fields from return dicts or response_model."""
        fields = []
        body_text = node_text(route.handler_node, source)

        # Match dict literal keys in return statements
        for match in re.finditer(r'["\'](\w+)["\']\s*:', body_text):
            key = match.group(1)
            if key not in fields:
                fields.append(key)

        # Check decorator for response_model
        for dec_node in route.decorator_nodes:
            dec_text = node_text(dec_node, source)
            rm_match = re.search(r'response_model\s*=\s*(\w+)', dec_text)
            if rm_match:
                fields.insert(0, f"response_model: {rm_match.group(1)}")

        return fields

    def extract_path_params(self, route_pattern: str) -> list[str]:
        return PATH_PARAM_RE.findall(route_pattern)

    def _extract_route_string(self, dec_node: Node, source: bytes) -> str | None:
        call_nodes = find_nodes_by_type(dec_node, "string")
        if call_nodes:
            text = node_text(call_nodes[0], source)
            if len(text) >= 2:
                return text[1:-1]
        return None

    def _get_func_name(self, func_node: Node, source: bytes) -> str:
        name_node = func_node.child_by_field_name("name")
        if name_node:
            return node_text(name_node, source)
        return "<anonymous>"
