"""Resolve generic and utility types to concrete field lists.

Handles:
  Pick<User, "id" | "name">  → User's fields filtered to id, name
  Omit<User, "password">     → User's fields minus password
  Partial<User>              → User's fields all optional
  Required<User>             → User's fields all required
  ApiResponse<User>          → ApiResponse's fields with T substituted by User
  User[]                     → Recognized as array of User
"""

from __future__ import annotations

from copy import copy
from typing import Callable, TYPE_CHECKING

from commiter.parser import parse_generic_type

if TYPE_CHECKING:
    from commiter.parser import TypeField

# Built-in utility types that we can resolve
UTILITY_TYPES = {"Pick", "Omit", "Partial", "Required", "Readonly"}

# Wrapper types that we unwrap to get the inner type
WRAPPER_TYPES = {"Array", "Promise", "Set"}


def resolve_generic_type(
    type_str: str,
    type_lookup: Callable[[str], "list[TypeField] | None"],
    generic_def_lookup: Callable[[str], "tuple[list[TypeField], list[str]] | None"] = None,
) -> "list[TypeField] | None":
    """Resolve a generic type string to concrete fields.

    Args:
        type_str: The type string (e.g. "Pick<User, \\"id\\" | \\"name\\">").
        type_lookup: Callback to look up a type name and get its fields.
        generic_def_lookup: Callback to look up a generic type definition,
                            returns (fields, generic_params) or None.

    Returns:
        Resolved list of TypeField, or None if not resolvable.
    """
    parsed = parse_generic_type(type_str)
    if not parsed:
        return None

    base, args = parsed
    if not args:
        return None

    # Built-in utility types
    if base in UTILITY_TYPES:
        return _resolve_utility_type(base, args, type_lookup)

    # Wrapper types — unwrap to inner type
    if base in WRAPPER_TYPES:
        inner_type = args[0]
        return type_lookup(inner_type)

    # Custom generic type: ApiResponse<User>
    if generic_def_lookup:
        return _resolve_custom_generic(base, args, type_lookup, generic_def_lookup)

    return None


def _resolve_utility_type(
    utility: str,
    args: list[str],
    type_lookup: Callable[[str], "list[TypeField] | None"],
) -> "list[TypeField] | None":
    """Resolve a built-in utility type."""

    if utility == "Pick" and len(args) >= 2:
        return _resolve_pick(args[0], args[1], type_lookup)

    elif utility == "Omit" and len(args) >= 2:
        return _resolve_omit(args[0], args[1], type_lookup)

    elif utility == "Partial" and len(args) >= 1:
        return _resolve_partial(args[0], type_lookup)

    elif utility == "Required" and len(args) >= 1:
        return _resolve_required(args[0], type_lookup)

    elif utility == "Readonly" and len(args) >= 1:
        # Readonly doesn't change field structure, just marks them readonly
        return type_lookup(args[0])

    return None


def _resolve_pick(
    base_type: str,
    selector: str,
    type_lookup: Callable[[str], "list[TypeField] | None"],
) -> "list[TypeField] | None":
    """Resolve Pick<User, "id" | "name"> to filtered fields."""
    fields = type_lookup(base_type)
    if not fields:
        return None

    selected = _parse_field_selector(selector)
    return [f for f in fields if f.name in selected]


def _resolve_omit(
    base_type: str,
    selector: str,
    type_lookup: Callable[[str], "list[TypeField] | None"],
) -> "list[TypeField] | None":
    """Resolve Omit<User, "password" | "email"> to fields minus excluded."""
    fields = type_lookup(base_type)
    if not fields:
        return None

    excluded = _parse_field_selector(selector)
    return [f for f in fields if f.name not in excluded]


def _resolve_partial(
    base_type: str,
    type_lookup: Callable[[str], "list[TypeField] | None"],
) -> "list[TypeField] | None":
    """Resolve Partial<User> to all fields marked optional."""
    fields = type_lookup(base_type)
    if not fields:
        return None

    result = []
    for f in fields:
        new_f = copy(f)
        new_f.optional = True
        result.append(new_f)
    return result


def _resolve_required(
    base_type: str,
    type_lookup: Callable[[str], "list[TypeField] | None"],
) -> "list[TypeField] | None":
    """Resolve Required<User> to all fields marked required."""
    fields = type_lookup(base_type)
    if not fields:
        return None

    result = []
    for f in fields:
        new_f = copy(f)
        new_f.optional = False
        result.append(new_f)
    return result


def _resolve_custom_generic(
    base: str,
    args: list[str],
    type_lookup: Callable[[str], "list[TypeField] | None"],
    generic_def_lookup: Callable[[str], "tuple[list[TypeField], list[str]] | None"],
) -> "list[TypeField] | None":
    """Resolve a custom generic like ApiResponse<User>.

    Looks up ApiResponse's definition (which has generic_params ["T"]),
    then substitutes T → User in all field type_str values.
    """
    definition = generic_def_lookup(base)
    if not definition:
        return None

    def_fields, generic_params = definition

    if not generic_params or len(generic_params) != len(args):
        # Param count mismatch — return fields as-is
        return list(def_fields)

    # Build substitution map: T → User
    subs = dict(zip(generic_params, args))

    result = []
    for f in def_fields:
        new_f = copy(f)
        # Substitute generic params in type_str
        new_type = new_f.type_str
        for param, replacement in subs.items():
            if new_type == param:
                new_type = replacement
            elif param in new_type:
                new_type = new_type.replace(param, replacement)
        new_f.type_str = new_type
        result.append(new_f)

    return result


def _parse_field_selector(selector: str) -> set[str]:
    """Parse a field selector like '"id" | "name"' into a set of field names."""
    names = set()
    for part in selector.split("|"):
        name = part.strip().strip("'\"")
        if name:
            names.add(name)
    return names
