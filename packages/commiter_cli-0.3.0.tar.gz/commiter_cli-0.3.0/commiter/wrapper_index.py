"""Wrapper function index: traces API calls through helper/wrapper functions.

Builds an index of exported JS/TS functions that internally call fetch() or axios,
then resolves calls to those wrappers from component files back to the underlying URLs.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from commiter.adapters.base import APICallMatch
from commiter.adapters.react import ReactAdapter
from commiter.parser import (
    find_js_exported_functions,
    find_js_re_exports,
    build_constants_from_file,
    get_source,
    node_text,
    JSReExport,
)

if TYPE_CHECKING:
    from tree_sitter import Tree
    from commiter.utils.tsconfig_resolver import TSConfigResolver

# Directories likely to contain API wrapper functions
WRAPPER_DIR_HINTS = {"lib", "services", "utils", "api", "helpers", "client", "hooks"}

# File extensions to try when resolving import paths
RESOLVE_EXTENSIONS = [".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.js", "/index.tsx"]

_react_adapter = ReactAdapter()


@dataclass
class WrapperDefinition:
    """An exported function that contains direct fetch/axios calls."""
    function_name: str
    file_path: str
    line: int
    api_calls: list[APICallMatch] = field(default_factory=list)


class WrapperIndex:
    """Index of API wrapper functions within a single repository.

    Usage:
        idx = WrapperIndex()
        # Pass 1: index all potential wrapper files
        for path in files:
            idx.index_file(path, tree, source)
        # Pass 2: resolve calls from components
        calls = idx.resolve("getUser", "../lib/api", "/project/components/Dash.tsx")
    """

    def __init__(self, alias_resolver: "TSConfigResolver | None" = None,
                 env_vars: dict[str, str] | None = None) -> None:
        # func_name -> list of wrapper definitions (same name can exist in multiple files)
        self._wrappers: dict[str, list[WrapperDefinition]] = {}
        # normalized absolute path (no extension) -> actual absolute path
        self._indexed_paths: dict[str, str] = {}
        self._alias_resolver = alias_resolver
        self._env_vars = env_vars or {}
        # barrel file re-export cache: abs_path -> list[JSReExport]
        self._re_exports: dict[str, list[JSReExport]] = {}
        # unmatched exports for chained wrapper resolution
        self._unmatched_exports: dict[str, list] = {}

    def index_file(self, file_path: str, tree: Tree, source: bytes) -> None:
        """Pass 1: scan a file for exported functions containing API calls.

        Scans all JS/TS files — the actual filter is whether exported functions
        contain fetch()/axios calls, not which directory the file is in.
        Unmatched exports are stored for chain resolution in resolve_chains().
        """
        abs_path = os.path.abspath(file_path)
        # Store path without extension for import resolution
        stem = _strip_extension(abs_path)
        self._indexed_paths[stem] = abs_path
        # Also store index-stripped version: /lib/api/index.ts -> /lib/api
        if Path(abs_path).stem == "index":
            parent_stem = str(Path(abs_path).parent)
            self._indexed_paths[parent_stem] = abs_path

        # Cache re-exports for barrel file resolution
        re_exports = find_js_re_exports(tree.root_node, source)
        if re_exports:
            self._re_exports[abs_path] = re_exports

        # Build per-file constants for URL resolution in wrappers
        constants = build_constants_from_file(tree.root_node, source, self._env_vars)

        exports = find_js_exported_functions(tree.root_node, source, file_path=file_path)
        for export in exports:
            # Scan the exported function body for fetch/axios calls
            fetch_calls = _react_adapter._find_fetch_calls(export.body_node, source, constants)
            axios_calls = _react_adapter._find_axios_calls(export.body_node, source, constants)
            all_calls = fetch_calls + axios_calls

            if all_calls:
                wrapper = WrapperDefinition(
                    function_name=export.name,
                    file_path=abs_path,
                    line=export.line,
                    api_calls=all_calls,
                )
                self._wrappers.setdefault(export.name, []).append(wrapper)
            else:
                # Store unmatched exports for chained wrapper resolution
                body_text = node_text(export.body_node, source)
                self._unmatched_exports.setdefault(abs_path, []).append(
                    (export, body_text, constants)
                )

    def resolve_chains(self) -> None:
        """Resolve chained wrappers: functions that call other wrapper functions.

        Called by the scanner after all files have been indexed.
        Exported functions that didn't directly contain fetch/axios calls are
        re-checked to see if they call any known wrapper function.
        """
        if not self._unmatched_exports:
            return

        # Build a set of all known wrapper function names
        known_wrappers = set(self._wrappers.keys())
        if not known_wrappers:
            return

        # Multiple passes to resolve chains of depth > 1
        for _pass in range(3):
            newly_resolved = 0
            remaining: dict[str, list] = {}

            for file_path, exports in self._unmatched_exports.items():
                still_unmatched = []
                for export, body_text, constants in exports:
                    # Check if the function body calls any known wrapper
                    found_calls = self._find_chained_calls(body_text, known_wrappers)
                    if found_calls:
                        wrapper = WrapperDefinition(
                            function_name=export.name,
                            file_path=file_path,
                            line=export.line,
                            api_calls=found_calls,
                        )
                        self._wrappers.setdefault(export.name, []).append(wrapper)
                        known_wrappers.add(export.name)
                        newly_resolved += 1
                    else:
                        still_unmatched.append((export, body_text, constants))

                if still_unmatched:
                    remaining[file_path] = still_unmatched

            self._unmatched_exports = remaining
            if newly_resolved == 0:
                break  # no progress, stop

    def _find_chained_calls(self, body_text: str, known_wrappers: set[str]) -> list:
        """Check if a function body calls any known wrapper function.

        Returns the underlying API calls from the wrapper being called.
        """
        all_calls = []
        for wrapper_name in known_wrappers:
            # Check if the wrapper name appears as a function call in the body
            # Match: wrapperName( or obj.wrapperName(
            if wrapper_name + "(" in body_text or "." + wrapper_name + "(" in body_text:
                # Get the API calls from this wrapper
                for wrapper_def in self._wrappers.get(wrapper_name, []):
                    all_calls.extend(wrapper_def.api_calls)
        return all_calls

    def resolve(self, func_name: str, import_path: str, caller_file: str) -> list[WrapperDefinition] | None:
        """Pass 2: resolve a function call to its wrapper definitions.

        Args:
            func_name: The imported function name (e.g. "getUser").
            import_path: The import module path (e.g. "../lib/api").
            caller_file: Absolute path of the file that imports it.

        Returns:
            List of matching WrapperDefinitions, or None if not a known wrapper.
        """
        if func_name not in self._wrappers:
            return None

        resolved_path = self._resolve_import_path(import_path, caller_file)
        if resolved_path is None:
            return None

        # Filter wrappers to those defined in the resolved file
        matches = [
            w for w in self._wrappers[func_name]
            if w.file_path == resolved_path
        ]
        if matches:
            return matches

        # Barrel file fallback: check if resolved_path re-exports this name
        actual_path = self._resolve_through_barrel(func_name, resolved_path)
        if actual_path:
            matches = [
                w for w in self._wrappers[func_name]
                if w.file_path == actual_path
            ]
            return matches if matches else None

        return None

    def _resolve_import_path(self, import_path: str, caller_file: str) -> str | None:
        """Resolve an import path to an absolute file path."""
        if not import_path.startswith("."):
            # Non-relative import — try tsconfig alias resolution
            if self._alias_resolver is None:
                return None
            resolved = self._alias_resolver.resolve(import_path, caller_file)
            if resolved:
                stem = _strip_extension(resolved)
                if stem in self._indexed_paths:
                    return self._indexed_paths[stem]
            return None

        caller_dir = str(Path(os.path.abspath(caller_file)).parent)
        base = os.path.normpath(os.path.join(caller_dir, import_path))

        # Try exact match first
        if base in self._indexed_paths:
            return self._indexed_paths[base]

        # Try with extensions
        for ext in RESOLVE_EXTENSIONS:
            candidate = base + ext
            candidate_stem = _strip_extension(candidate)
            if candidate_stem in self._indexed_paths:
                return self._indexed_paths[candidate_stem]

        return None

    def _resolve_through_barrel(self, name: str, barrel_path: str) -> str | None:
        """Follow re-exports in a barrel file to find the actual source file."""
        re_exports = self._re_exports.get(barrel_path)
        if not re_exports:
            return None

        barrel_dir = str(Path(barrel_path).parent)

        for re_export in re_exports:
            # Check if this re-export includes the name we're looking for
            if name not in re_export.names and "*" not in re_export.names:
                continue

            # Resolve the re-export's module path relative to the barrel file
            target_base = os.path.normpath(os.path.join(barrel_dir, re_export.module_path))
            target_stem = _strip_extension(target_base)

            if target_stem in self._indexed_paths:
                return self._indexed_paths[target_stem]

            # Try with extensions
            for ext in RESOLVE_EXTENSIONS:
                candidate_stem = _strip_extension(target_base + ext)
                if candidate_stem in self._indexed_paths:
                    return self._indexed_paths[candidate_stem]

        return None

    def _is_wrapper_candidate(self, file_path: str) -> bool:
        """Check if a file is likely to contain API wrapper functions."""
        parts = Path(file_path).parts
        return any(part.lower() in WRAPPER_DIR_HINTS for part in parts)

    @property
    def wrapper_count(self) -> int:
        """Total number of indexed wrapper functions."""
        return sum(len(defs) for defs in self._wrappers.values())


def _strip_extension(path: str) -> str:
    """Strip JS/TS file extensions from a path."""
    p = Path(path)
    while p.suffix in (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"):
        p = p.with_suffix("")
    return str(p)
