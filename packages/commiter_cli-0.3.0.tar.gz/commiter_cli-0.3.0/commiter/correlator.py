"""Cross-repo correlator: matches frontend API calls to backend endpoints."""

from __future__ import annotations

import re

from commiter.models import (
    APICall,
    APIEndpoint,
    RepoDocumentation,
    ServiceRelationship,
)


def correlate(docs: list[RepoDocumentation]) -> list[ServiceRelationship]:
    """Match frontend API calls to backend endpoints across all repos.

    Returns a list of ServiceRelationship objects describing connections.
    """
    all_endpoints: list[APIEndpoint] = []
    all_calls: list[APICall] = []

    for doc in docs:
        all_endpoints.extend(doc.endpoints)
        all_calls.extend(doc.api_calls)

    relationships = []

    for call in all_calls:
        best_match = _find_best_endpoint_match(call, all_endpoints)
        if best_match:
            endpoint, confidence = best_match
            relationships.append(ServiceRelationship(
                source_repo=call.repo,
                target_repo=endpoint.repo,
                connection_type="api_call",
                source_file=f"{call.file_path}:{call.line}",
                target_endpoint=f"{endpoint.http_method} {endpoint.route_pattern}",
                confidence=confidence,
            ))

    # Detect shared dependencies between repos
    relationships.extend(_find_shared_dependencies(docs))

    # Detect shared database tables between repos
    relationships.extend(_find_shared_db_tables(docs))

    return relationships


def _find_best_endpoint_match(
    call: APICall, endpoints: list[APIEndpoint]
) -> tuple[APIEndpoint, float] | None:
    """Find the best matching backend endpoint for a frontend API call."""
    best: tuple[APIEndpoint, float] | None = None

    call_path = _normalize_url(call.url_pattern)
    call_method = call.http_method.upper()

    for ep in endpoints:
        ep_path = _normalize_route(ep.route_pattern)
        ep_method = ep.http_method.upper()

        # Method must match (or one is ALL)
        if call_method != ep_method and call_method != "ALL" and ep_method != "ALL":
            continue

        confidence = _path_similarity(call_path, ep_path)
        if confidence > 0 and (best is None or confidence > best[1]):
            best = (ep, confidence)

    return best


def _normalize_url(url: str) -> str:
    """Normalize a frontend URL for comparison.

    Strips protocol, host, base path variables, and normalizes parameters.
    """
    # Remove protocol + host
    url = re.sub(r"^https?://[^/]+", "", url)
    # Remove template literal expressions like ${API_URL}
    url = re.sub(r"\$\{[^}]+\}", "", url)
    # Remove env variable references
    url = re.sub(r"process\.env\.\w+", "", url)
    # Strip leading/trailing slashes and normalize
    url = url.strip("/")
    # Replace template literal params ${id} with :param placeholder
    url = re.sub(r"\$\{(\w+)\}", r":\1", url)
    return url


def _normalize_route(route: str) -> str:
    """Normalize a backend route pattern for comparison.

    Converts all param syntaxes to a common format.
    """
    route = route.strip("/")
    # Flask: <param> or <int:param>
    route = re.sub(r"<(?:\w+:)?(\w+)>", r":\1", route)
    # FastAPI: {param}
    route = re.sub(r"\{(\w+)\}", r":\1", route)
    # Next.js: [param]
    route = re.sub(r"\[(\w+)\]", r":\1", route)
    return route


def _path_similarity(call_path: str, endpoint_path: str) -> float:
    """Calculate similarity between a frontend call URL and backend route.

    Returns 0.0 (no match) to 1.0 (exact match).
    """
    call_parts = [p for p in call_path.split("/") if p]
    ep_parts = [p for p in endpoint_path.split("/") if p]

    if not call_parts or not ep_parts:
        return 0.0

    # Different lengths — check if one is a suffix of the other
    if len(call_parts) != len(ep_parts):
        # Try suffix matching (frontend might include /api prefix that backend doesn't)
        shorter, longer = (call_parts, ep_parts) if len(call_parts) <= len(ep_parts) else (ep_parts, call_parts)
        for offset in range(len(longer) - len(shorter) + 1):
            if _segments_match(shorter, longer[offset:offset + len(shorter)]):
                return 0.7  # partial match
        return 0.0

    if _segments_match(call_parts, ep_parts):
        return 1.0

    return 0.0


def _segments_match(a: list[str], b: list[str]) -> bool:
    """Check if two path segment lists match, treating :params as wildcards."""
    if len(a) != len(b):
        return False
    for sa, sb in zip(a, b):
        if sa.startswith(":") or sb.startswith(":"):
            continue  # parameter — always matches
        if sa != sb:
            return False
    return True


def _find_shared_dependencies(docs: list[RepoDocumentation]) -> list[ServiceRelationship]:
    """Find packages used by multiple repos."""
    relationships = []
    if len(docs) < 2:
        return relationships

    # Build dep name -> list of repos
    dep_repos: dict[str, list[str]] = {}
    for doc in docs:
        for dep in doc.dependencies:
            if dep.dev_only:
                continue
            dep_repos.setdefault(dep.name, []).append(doc.repo_name)

    for dep_name, repos in dep_repos.items():
        if len(repos) > 1:
            for i in range(len(repos)):
                for j in range(i + 1, len(repos)):
                    relationships.append(ServiceRelationship(
                        source_repo=repos[i],
                        target_repo=repos[j],
                        connection_type="shared_package",
                        source_file=dep_name,
                        target_endpoint=dep_name,
                        confidence=0.5,
                    ))

    return relationships


def _find_shared_db_tables(docs: list[RepoDocumentation]) -> list[ServiceRelationship]:
    """Find database tables accessed by multiple repos (shared data layer)."""
    relationships = []
    if len(docs) < 2:
        return relationships

    # Build table_name -> list of (repo_name, first_file_reference)
    table_repos: dict[str, list[tuple[str, str]]] = {}
    for doc in docs:
        # Collect unique tables per repo (normalized to lowercase)
        repo_tables: dict[str, str] = {}
        for op in doc.db_operations:
            table_lower = op.table_name.lower()
            if table_lower not in repo_tables:
                repo_tables[table_lower] = f"{op.file_path}:{op.line}"

        for table, first_ref in repo_tables.items():
            table_repos.setdefault(table, []).append((doc.repo_name, first_ref))

    for table_name, repos in table_repos.items():
        if len(repos) > 1:
            for i in range(len(repos)):
                for j in range(i + 1, len(repos)):
                    relationships.append(ServiceRelationship(
                        source_repo=repos[i][0],
                        target_repo=repos[j][0],
                        connection_type="shared_db",
                        source_file=repos[i][1],
                        target_endpoint=f"table:{table_name}",
                        confidence=0.8,
                    ))

    return relationships
