"""Upload architecture JSON to commiter.dev for AI enrichment."""

from __future__ import annotations

import hashlib
import json
import urllib.request
import urllib.error

UPLOAD_URL = "https://commiter-api.up.railway.app/v1/architecture/upload"


def upload_architecture(json_str: str, api_token: str | None = None) -> dict:
    """POST architecture JSON to the Commiter API and return the response.

    Args:
        json_str: The raw architecture JSON string.
        api_token: Optional JWT for authenticated enrichment.

    Returns:
        Dict with keys: snapshot_id, url, status, tier
        Or dict with key: error
    """
    headers = {"Content-Type": "application/json"}
    if api_token:
        headers["Authorization"] = f"Bearer {api_token}"

    data = json_str.encode("utf-8")
    headers["X-Content-Hash"] = hashlib.sha256(data).hexdigest()

    req = urllib.request.Request(UPLOAD_URL, data=data, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            error_data = json.loads(body)
            return {"error": error_data.get("error", f"HTTP {e.code}")}
        except json.JSONDecodeError:
            return {"error": f"HTTP {e.code}: {body[:200]}"}
    except urllib.error.URLError as e:
        return {"error": f"Connection failed: {e.reason}"}
    except Exception as e:
        return {"error": str(e)}