"""Cross-file handler type index: maps class controller methods to their parameter types.

Resolves the body type when a route uses a class-based handler like:
  router.post("/", projectController.create)

where the type annotation Request<{}, {}, CreateProjectBody> lives in the
controller's class definition in a separate file.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from commiter.parser import (
    find_ts_class_methods,
    find_ts_class_instances,
    ClassMethod,
    ClassInstance,
)

if TYPE_CHECKING:
    from tree_sitter import Tree


class HandlerIndex:
    """Index of class method type annotations across all files.

    Built during Pass 1, queried during Pass 2 to resolve body types
    for class-based route handlers.

    Usage:
        idx = HandlerIndex()
        idx.index_file(path, tree, source, "typescript")
        body_type = idx.get_body_type("projectController.create")
        # Returns "CreateProjectBody"
    """

    def __init__(self) -> None:
        # "ClassName.methodName" -> ClassMethod
        self._methods: dict[str, ClassMethod] = {}
        # "varName" -> "ClassName" (e.g. "projectController" -> "ProjectController")
        self._instances: dict[str, str] = {}

    def index_file(self, file_path: str, tree: "Tree", source: bytes, language: str) -> None:
        """Scan a file for class method signatures and instance variables."""
        if language not in ("javascript", "typescript", "tsx"):
            return

        abs_path = os.path.abspath(file_path)

        # Index class methods
        methods = find_ts_class_methods(tree.root_node, source, file_path=abs_path)
        for method in methods:
            key = f"{method.class_name}.{method.method_name}"
            self._methods[key] = method

        # Index instance variables: const x = new ClassName()
        instances = find_ts_class_instances(tree.root_node, source, file_path=abs_path)
        for inst in instances:
            self._instances[inst.var_name] = inst.class_name

    def get_body_type(self, handler_ref: str) -> str | None:
        """Resolve a handler reference like 'projectController.create' to its body type.

        Steps:
        1. Split into var_name='projectController', method='create'
        2. Look up var_name in _instances -> 'ProjectController'
        3. Look up 'ProjectController.create' in _methods
        4. Return request_body_type
        """
        if "." not in handler_ref:
            return None

        var_name, method_name = handler_ref.rsplit(".", 1)

        # Resolve variable to class name
        class_name = self._instances.get(var_name)
        if not class_name:
            # Try using the variable name as-is (might already be the class name)
            class_name = var_name

        # Look up the method
        key = f"{class_name}.{method_name}"
        method = self._methods.get(key)
        if method:
            return method.request_body_type

        return None

    @property
    def method_count(self) -> int:
        return len(self._methods)

    @property
    def instance_count(self) -> int:
        return len(self._instances)
