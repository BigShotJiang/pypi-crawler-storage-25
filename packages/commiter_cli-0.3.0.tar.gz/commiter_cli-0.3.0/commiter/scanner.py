"""Orchestrator: discovers files, runs extractors, assembles documentation."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from commiter.extractors.base import BaseExtractor
from commiter.extractors.dependencies import DependencyExtractor
from commiter.models import RepoDocumentation, APIEndpoint, APICall, Dependency, FileClassification, DBOperation
from commiter.parser import (
    parse_file, get_source, find_js_imports,
    find_nodes_by_type, node_text, resolve_url_from_node, build_constants_from_file,
)
from commiter.utils.env_reader import load_env_files
from commiter.utils.file_classifier import classify_file, detect_repo_frameworks
from commiter.utils.path_helpers import walk_repo, detect_repo_name
from commiter.utils.tsconfig_resolver import TSConfigRegistry
from commiter.handler_index import HandlerIndex
from commiter.middleware_index import MiddlewareIndex
from commiter.prefix_index import PrefixIndex
from commiter.type_index import TypeIndex
from commiter.wrapper_index import WrapperIndex


@dataclass
class ScanResult:
    """Extended scan output that includes indexes needed by the architecture format."""
    doc: RepoDocumentation
    type_index: TypeIndex
    middleware_index: MiddlewareIndex
    file_list: list[str] = field(default_factory=list)
    alias_resolver: TSConfigRegistry | None = None


def _default_extractors() -> list[BaseExtractor]:
    """Return all available extractors."""
    # Import here to avoid circular imports when more extractors are added
    from commiter.extractors.dependencies import DependencyExtractor

    extractors: list[BaseExtractor] = [
        DependencyExtractor(),
    ]

    # Conditionally import extractors that may not exist yet
    try:
        from commiter.extractors.api_endpoints import APIEndpointExtractor
        extractors.append(APIEndpointExtractor())
    except ImportError:
        pass

    try:
        from commiter.extractors.api_calls import APICallExtractor
        extractors.append(APICallExtractor())
    except ImportError:
        pass

    try:
        from commiter.extractors.backend_files import BackendFileExtractor
        extractors.append(BackendFileExtractor())
    except ImportError:
        pass

    try:
        from commiter.extractors.db_operations import DBOperationExtractor
        extractors.append(DBOperationExtractor())
    except ImportError:
        pass

    return extractors


def _scan_repo_full(
    repo_root: str,
    extra_excludes: list[str] | None = None,
    extractors: list[BaseExtractor] | None = None,
) -> ScanResult:
    """Scan a single repository and return documentation with indexes.

    This is the internal implementation that preserves indexes for consumers
    like the architecture output format.
    """
    repo_name = detect_repo_name(repo_root)
    frameworks = detect_repo_frameworks(repo_root)
    files = walk_repo(repo_root, extra_excludes)

    # Load tsconfig/jsconfig for path alias resolution
    alias_resolver = TSConfigRegistry(repo_root)

    # Load .env files for environment variable resolution
    env_vars = load_env_files(repo_root)

    if extractors is None:
        extractors = _default_extractors()

    doc = RepoDocumentation(
        repo_name=repo_name,
        repo_path=repo_root,
        frameworks=frameworks,
    )

    languages_seen: set[str] = set()
    js_family = {"javascript", "typescript", "tsx"}

    # Cache parse results to avoid double-parsing JS/TS files
    parse_cache: dict[str, tuple] = {}  # file_path -> (tree, language, source)

    # === Pass 1: build wrapper index, type index, and prefix index ===
    wrapper_idx = WrapperIndex(alias_resolver=alias_resolver, env_vars=env_vars)
    type_idx = TypeIndex(alias_resolver=alias_resolver)
    prefix_idx = PrefixIndex()
    middleware_idx = MiddlewareIndex()
    handler_idx = HandlerIndex()
    for file_path in files:
        parse_result = parse_file(file_path)
        if parse_result:
            tree, lang = parse_result
            source = get_source(file_path)
            parse_cache[file_path] = (tree, lang, source)
            # Index wrappers (JS/TS only)
            if lang in js_family:
                wrapper_idx.index_file(file_path, tree, source)
            # Index type definitions (all parseable languages)
            type_idx.index_file(file_path, tree, source, lang)
            # Index router/blueprint prefixes
            prefix_idx.index_file(file_path, tree, source, lang)
            # Index middleware registrations
            middleware_idx.index_file(file_path, tree, source, lang)
            # Index class handler method signatures
            handler_idx.index_file(file_path, tree, source, lang)

    # Resolve chained wrappers (functions that call other wrapper functions)
    wrapper_idx.resolve_chains()

    # Make indexes and env vars available to extractors
    for extractor in extractors:
        if hasattr(extractor, 'set_type_index'):
            extractor.set_type_index(type_idx)
        if hasattr(extractor, 'set_prefix_index'):
            extractor.set_prefix_index(prefix_idx)
        if hasattr(extractor, 'set_middleware_index'):
            extractor.set_middleware_index(middleware_idx)
        if hasattr(extractor, 'set_handler_index'):
            extractor.set_handler_index(handler_idx)
        if hasattr(extractor, 'set_env_vars'):
            extractor.set_env_vars(env_vars)

    # === Pass 2: run extractors + resolve wrapper calls ===
    for file_path in files:
        # Classify the file
        classification = classify_file(file_path, repo_root)
        doc.file_classifications.append(classification)
        if classification.language != "unknown":
            languages_seen.add(classification.language)

        # Use cached parse result if available, otherwise parse now
        if file_path in parse_cache:
            tree, language, source = parse_cache[file_path]
        else:
            parse_result = parse_file(file_path)
            tree = parse_result[0] if parse_result else None
            language = parse_result[1] if parse_result else None

        # Run each extractor
        for extractor in extractors:
            if not extractor.can_handle(file_path, language):
                continue

            artifacts = extractor.extract(file_path, repo_name, tree=tree, language=language)
            for artifact in artifacts:
                if isinstance(artifact, APIEndpoint):
                    doc.endpoints.append(artifact)
                elif isinstance(artifact, APICall):
                    doc.api_calls.append(artifact)
                elif isinstance(artifact, Dependency):
                    doc.dependencies.append(artifact)
                elif isinstance(artifact, FileClassification):
                    pass  # already added above
                elif isinstance(artifact, DBOperation):
                    doc.db_operations.append(artifact)

        # Resolve wrapper function calls in JS/TS files
        if language in js_family and tree is not None:
            if file_path not in parse_cache:
                source = get_source(file_path)
            else:
                source = parse_cache[file_path][2]

            caller_constants = build_constants_from_file(tree.root_node, source, env_vars)
            imports = find_js_imports(tree.root_node, source)
            for imp in imports:
                for name in imp.names:
                    wrappers = wrapper_idx.resolve(name, imp.module_path, file_path)
                    if not wrappers:
                        continue
                    for wrapper in wrappers:
                        # Try to find actual call sites with resolved arguments
                        call_sites = _find_wrapper_call_urls(
                            tree.root_node, source, name, caller_constants,
                        )
                        if call_sites:
                            # Emit one API call per call site with the resolved URL
                            method = wrapper.api_calls[0].http_method if wrapper.api_calls else "GET"
                            for call_line, call_url in call_sites:
                                doc.api_calls.append(APICall(
                                    repo=repo_name,
                                    file_path=file_path,
                                    line=call_line,
                                    component_or_page=Path(file_path).stem,
                                    http_method=method,
                                    url_pattern=call_url,
                                    client_library="fetch",
                                    traced_from=f"{name}() in {Path(wrapper.file_path).name}:{wrapper.line}",
                                ))
                        else:
                            # Fallback: use wrapper definition URLs (existing behavior)
                            for api_call in wrapper.api_calls:
                                doc.api_calls.append(APICall(
                                    repo=repo_name,
                                    file_path=file_path,
                                    line=imp.line,
                                    component_or_page=Path(file_path).stem,
                                    http_method=api_call.http_method,
                                    url_pattern=api_call.url_pattern,
                                    client_library="fetch",
                                    traced_from=f"{name}() in {Path(wrapper.file_path).name}:{wrapper.line}",
                                ))

    doc.languages = sorted(languages_seen)

    # Post-processing: link DB tables to endpoints
    _link_db_to_endpoints(doc)

    return ScanResult(
        doc=doc,
        type_index=type_idx,
        middleware_index=middleware_idx,
        file_list=files,
        alias_resolver=alias_resolver,
    )


def scan_repo(
    repo_root: str,
    extra_excludes: list[str] | None = None,
    extractors: list[BaseExtractor] | None = None,
) -> RepoDocumentation:
    """Scan a single repository and return its documentation.

    Args:
        repo_root: Path to the repository root.
        extra_excludes: Additional path patterns to exclude.
        extractors: Override the default set of extractors.
    """
    return _scan_repo_full(repo_root, extra_excludes, extractors).doc



def _find_wrapper_call_urls(root_node, source, func_name, constants):
    """Find call expressions for a wrapper function and extract the first URL argument.

    Returns a list of (line_number, resolved_url) for each call site where
    the first argument is a string or template literal that resolves to a URL.
    """
    results = []
    for call in find_nodes_by_type(root_node, 'call_expression'):
        func = call.child_by_field_name('function')
        if not func or node_text(func, source) != func_name:
            continue

        args = call.child_by_field_name('arguments')
        if not args:
            continue

        # Extract first string-like argument as the URL path
        for arg in args.children:
            if arg.type in ('string', 'template_string', 'binary_expression'):
                url = resolve_url_from_node(arg, source, constants)
                if url:
                    results.append((call.start_point[0] + 1, url))
                break
    return results


_UNRESOLVED_URL_RE = re.compile(r':\d+:\w+|(?<![/]):[a-z]{2,}$')


def _is_unresolved_url(url: str) -> bool:
    """Check if a URL contains unresolved function parameter placeholders.

    Detects patterns like 'http://localhost:5000:path' where :path is a
    function parameter that wasn't resolved, as opposed to route params
    like ':id' or ':userId' which appear after a slash.
    """
    return bool(_UNRESOLVED_URL_RE.search(url))


def _link_db_to_endpoints(doc: RepoDocumentation) -> None:
    """Associate DB table names with the endpoints whose handler contains them.

    Uses line ranges: a DB operation belongs to an endpoint if it falls between
    that endpoint's line and the next endpoint's start line in the same file.
    Falls back to same-file grouping for files with only one endpoint.
    """
    ops_by_file: dict[str, list[DBOperation]] = {}
    for op in doc.db_operations:
        ops_by_file.setdefault(op.file_path, []).append(op)

    # Group endpoints by file and sort by line number
    endpoints_by_file: dict[str, list[APIEndpoint]] = {}
    for ep in doc.endpoints:
        endpoints_by_file.setdefault(ep.file_path, []).append(ep)

    for file_path, file_endpoints in endpoints_by_file.items():
        file_ops = ops_by_file.get(file_path, [])
        if not file_ops:
            continue

        sorted_eps = sorted(file_endpoints, key=lambda e: e.line)

        for i, endpoint in enumerate(sorted_eps):
            start_line = endpoint.line
            # End line is the start of the next endpoint (or end of file)
            if i + 1 < len(sorted_eps):
                end_line = sorted_eps[i + 1].line
            else:
                end_line = float("inf")

            # Find DB operations within this endpoint's line range
            tables = set()
            for op in file_ops:
                if start_line <= op.line < end_line:
                    tables.add(op.table_name)

            if tables:
                endpoint.db_tables = sorted(tables)


def scan_repos(
    repo_roots: list[str],
    extra_excludes: list[str] | None = None,
) -> list[RepoDocumentation]:
    """Scan multiple repositories and correlate cross-repo relationships."""
    docs = []
    for root in repo_roots:
        docs.append(scan_repo(root, extra_excludes))

    # Cross-repo correlation
    if len(docs) > 1:
        from commiter.correlator import correlate
        relationships = correlate(docs)
        # Distribute relationships to source repos
        for rel in relationships:
            for doc in docs:
                if doc.repo_name == rel.source_repo:
                    doc.service_relationships.append(rel)
                    break

    return docs


def scan_repos_full(
    repo_roots: list[str],
    extra_excludes: list[str] | None = None,
) -> list[ScanResult]:
    """Scan multiple repositories with full index access for architecture output."""
    results = []
    for root in repo_roots:
        results.append(_scan_repo_full(root, extra_excludes))

    # Cross-repo correlation
    docs = [r.doc for r in results]
    if len(docs) > 1:
        from commiter.correlator import correlate
        relationships = correlate(docs)
        for rel in relationships:
            for doc in docs:
                if doc.repo_name == rel.source_repo:
                    doc.service_relationships.append(rel)
                    break

    return results
