"""Repo Documenter - Generate documentation from repository code analysis."""

__version__ = "0.1.0"
