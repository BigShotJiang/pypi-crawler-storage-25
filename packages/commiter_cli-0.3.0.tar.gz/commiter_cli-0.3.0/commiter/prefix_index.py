"""Cross-file router/blueprint prefix index.

Detects prefix declarations across files and resolves them to prepend
to route patterns found on routers/blueprints.

Patterns detected:
  Flask:   Blueprint("name", __name__, url_prefix="/api/users")
           app.register_blueprint(bp, url_prefix="/api/users")
  FastAPI: app.include_router(users_router, prefix="/api/users")
  Express: app.use("/api/users", usersRouter)
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from commiter.parser import node_text, find_nodes_by_type

if TYPE_CHECKING:
    from tree_sitter import Tree, Node


@dataclass
class PrefixBinding:
    """A binding between a router/blueprint variable name and its URL prefix."""
    variable_name: str
    prefix: str
    file_path: str
    line: int


class PrefixIndex:
    """Index of router/blueprint prefix bindings across all files.

    Usage:
        idx = PrefixIndex()
        # Pass 1: index all files
        for path in files:
            idx.index_file(path, tree, source, language)
        # Pass 2: look up prefix for a route
        prefix = idx.get_prefix_for_file(file_path, router_var_name)
    """

    def __init__(self) -> None:
        # variable_name -> list of PrefixBinding
        self._bindings: dict[str, list[PrefixBinding]] = {}
        # file_path -> list of PrefixBinding (all bindings found in a file)
        self._by_file: dict[str, list[PrefixBinding]] = {}
        # For cross-file: imported router name -> (source_file, original_name)
        self._router_imports: dict[str, dict[str, str]] = {}  # file -> {local_name: source_file}

    def index_file(self, file_path: str, tree: "Tree", source: bytes, language: str) -> None:
        """Scan a file for prefix declarations."""
        abs_path = os.path.abspath(file_path)
        text = source.decode("utf-8", errors="replace")

        if language == "python":
            self._index_python_prefixes(abs_path, tree, source, text)
        elif language in ("javascript", "typescript", "tsx"):
            self._index_js_prefixes(abs_path, tree, source, text)

    def get_prefix_for_file(self, file_path: str, router_var: str | None = None) -> str:
        """Get the accumulated URL prefix for routes in a file.

        Checks if any other file mounts a router from this file with a prefix.

        Args:
            file_path: The file containing the routes.
            router_var: Optional variable name of the router (e.g. "bp", "router").

        Returns:
            The prefix string (e.g. "/api/v1") or empty string if none found.
        """
        abs_path = os.path.abspath(file_path)
        file_name = Path(abs_path).stem

        # Strategy 1: Check if a specific router variable has a known prefix
        if router_var and router_var in self._bindings:
            for binding in self._bindings[router_var]:
                return binding.prefix

        # Strategy 2: Check if any binding references this file (cross-file)
        # Look through all bindings for ones that import from this file
        for importing_file, imports in self._router_imports.items():
            for local_name, source_file in imports.items():
                # Check if source_file matches our file
                if self._files_match(source_file, abs_path, importing_file):
                    if local_name in self._bindings:
                        for binding in self._bindings[local_name]:
                            if binding.file_path == importing_file:
                                return binding.prefix

        # Strategy 3: Check same-file Blueprint/Router definitions with inline prefix
        for binding in self._by_file.get(abs_path, []):
            return binding.prefix

        return ""

    def _index_python_prefixes(self, abs_path: str, tree: "Tree", source: bytes, text: str) -> None:
        """Index Flask Blueprint and FastAPI include_router prefixes."""

        # Pattern 1: Blueprint("name", __name__, url_prefix="/api/users")
        for match in re.finditer(
            r'(\w+)\s*=\s*Blueprint\s*\([^)]*url_prefix\s*=\s*["\']([^"\']+)["\']',
            text,
        ):
            var_name = match.group(1)
            prefix = match.group(2)
            line = text[:match.start()].count("\n") + 1
            binding = PrefixBinding(variable_name=var_name, prefix=prefix, file_path=abs_path, line=line)
            self._bindings.setdefault(var_name, []).append(binding)
            self._by_file.setdefault(abs_path, []).append(binding)

        # Pattern 2: app.register_blueprint(bp, url_prefix="/api/users")
        for match in re.finditer(
            r'\.register_blueprint\s*\(\s*(\w+)(?:\s*,\s*url_prefix\s*=\s*["\']([^"\']+)["\'])?',
            text,
        ):
            var_name = match.group(1)
            prefix = match.group(2)
            if prefix:
                line = text[:match.start()].count("\n") + 1
                binding = PrefixBinding(variable_name=var_name, prefix=prefix, file_path=abs_path, line=line)
                self._bindings.setdefault(var_name, []).append(binding)
                self._by_file.setdefault(abs_path, []).append(binding)

        # Pattern 3: app.include_router(users_router, prefix="/api/users")
        for match in re.finditer(
            r'\.include_router\s*\(\s*(\w+)(?:\s*,\s*prefix\s*=\s*["\']([^"\']+)["\'])?',
            text,
        ):
            var_name = match.group(1)
            prefix = match.group(2)
            if prefix:
                line = text[:match.start()].count("\n") + 1
                binding = PrefixBinding(variable_name=var_name, prefix=prefix, file_path=abs_path, line=line)
                self._bindings.setdefault(var_name, []).append(binding)
                self._by_file.setdefault(abs_path, []).append(binding)

        # Track imports: from .routes import router, from routes.users import users_router
        for match in re.finditer(r'from\s+(\S+)\s+import\s+(.+)', text):
            module_path = match.group(1)
            names = [n.strip().split(" as ")[-1].strip() for n in match.group(2).split(",")]
            for name in names:
                if name:
                    self._router_imports.setdefault(abs_path, {})[name] = module_path

    def _index_js_prefixes(self, abs_path: str, tree: "Tree", source: bytes, text: str) -> None:
        """Index Express app.use("/prefix", router) patterns."""

        # Pattern: app.use("/api/users", usersRouter)
        for match in re.finditer(
            r'(\w+)\.use\s*\(\s*["\']([^"\']+)["\']\s*,\s*(\w+)\s*\)',
            text,
        ):
            mount_obj = match.group(1)  # app, server, etc.
            prefix = match.group(2)
            router_var = match.group(3)
            line = text[:match.start()].count("\n") + 1
            binding = PrefixBinding(variable_name=router_var, prefix=prefix, file_path=abs_path, line=line)
            self._bindings.setdefault(router_var, []).append(binding)
            self._by_file.setdefault(abs_path, []).append(binding)

        # Track imports: import usersRouter from "./routes/users"
        # const usersRouter = require("./routes/users")
        for match in re.finditer(r'import\s+(\w+)\s+from\s+["\']([^"\']+)["\']', text):
            name = match.group(1)
            source_path = match.group(2)
            self._router_imports.setdefault(abs_path, {})[name] = source_path

        for match in re.finditer(r'(?:const|let|var)\s+(\w+)\s*=\s*require\s*\(\s*["\']([^"\']+)["\']\s*\)', text):
            name = match.group(1)
            source_path = match.group(2)
            self._router_imports.setdefault(abs_path, {})[name] = source_path

    def _files_match(self, import_path: str, target_abs_path: str, importer_abs_path: str) -> bool:
        """Check if an import path could resolve to the target file."""
        target_stem = Path(target_abs_path).stem
        target_name = Path(target_abs_path).name

        # Direct name match
        if import_path.endswith(target_stem) or import_path.endswith(target_name):
            return True

        # Relative path resolution
        if import_path.startswith("."):
            importer_dir = str(Path(importer_abs_path).parent)
            resolved = os.path.normpath(os.path.join(importer_dir, import_path))
            # Try with common extensions
            for ext in ("", ".py", ".js", ".ts", ".tsx", "/index.ts", "/index.js"):
                if os.path.normpath(resolved + ext) == os.path.normpath(target_abs_path):
                    return True
                # Also compare stems
                if Path(resolved + ext).stem == target_stem:
                    return True

        # Python dotted imports: .routes -> routes.py in same dir
        if import_path.startswith("."):
            module = import_path.lstrip(".").replace(".", "/")
            if module == target_stem or module.endswith("/" + target_stem):
                return True

        return False

    @property
    def binding_count(self) -> int:
        return sum(len(b) for b in self._bindings.values())
