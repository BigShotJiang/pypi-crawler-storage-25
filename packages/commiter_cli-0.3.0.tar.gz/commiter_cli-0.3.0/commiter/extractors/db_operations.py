"""Extract database operations from code using ORM/DB adapters."""

from __future__ import annotations

from typing import TYPE_CHECKING

from commiter.adapters.base import DBAdapter
from commiter.adapters.supabase import SupabaseAdapter
from commiter.adapters.prisma import PrismaAdapter
from commiter.adapters.sqlalchemy import SQLAlchemyAdapter
from commiter.adapters.raw_sql import RawSQLAdapter
from commiter.extractors.base import BaseExtractor
from commiter.models import DBOperation
from commiter.parser import get_source

if TYPE_CHECKING:
    from tree_sitter import Tree

_DB_ADAPTERS: list[DBAdapter] = [
    SupabaseAdapter(),
    PrismaAdapter(),
    SQLAlchemyAdapter(),
    RawSQLAdapter(),
]


class DBOperationExtractor(BaseExtractor):
    name = "db_operations"

    def can_handle(self, file_path: str, language: str | None) -> bool:
        return language in ("python", "javascript", "typescript", "tsx")

    def extract(self, file_path: str, repo_name: str, tree: Tree | None = None, language: str | None = None) -> list[DBOperation]:
        if tree is None:
            return []

        source = get_source(file_path)
        operations = []

        for adapter in _DB_ADAPTERS:
            # Check if the source contains hints of this ORM
            if not self._source_has_orm_hints(source, adapter):
                continue

            matches = adapter.find_db_operations(tree, source)
            for match in matches:
                operations.append(DBOperation(
                    repo=repo_name,
                    file_path=file_path,
                    line=match.line,
                    operation_type=match.operation_type,
                    table_name=match.table_name,
                    orm_library=adapter.orm_name,
                    filters=match.filters,
                ))

        return operations

    def _source_has_orm_hints(self, source: bytes, adapter: DBAdapter) -> bool:
        """Quick check if the source file likely uses this ORM."""
        hints = {
            "supabase": (b"supabase", b".table(", b".from(", b".from_("),
            "prisma": (b"prisma.", b"@prisma"),
            "sqlalchemy": (b"session.", b"sqlalchemy", b".query(", b"Model.query"),
            "raw_sql": (b"cursor.execute", b".execute(", b"pool.query", b"client.query",
                        b"knex.raw", b"db.query", b"connection.query", b".raw("),
        }
        orm_hints = hints.get(adapter.orm_name, ())
        return any(hint in source for hint in orm_hints)
