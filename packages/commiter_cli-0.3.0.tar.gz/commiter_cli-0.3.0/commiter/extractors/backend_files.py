"""Classify files as backend, frontend, config, test, etc."""

from __future__ import annotations

from typing import TYPE_CHECKING

from commiter.extractors.base import BaseExtractor
from commiter.models import FileClassification
from commiter.utils.file_classifier import classify_file

if TYPE_CHECKING:
    from tree_sitter import Tree


class BackendFileExtractor(BaseExtractor):
    """Classifies files by role. Returns FileClassification objects.

    Note: The scanner already classifies files, so this extractor is mainly
    useful for enriching classifications with AST-based hints (e.g., detecting
    that a .py file imports Flask and is therefore a backend file).
    """

    name = "backend_files"

    def can_handle(self, file_path: str, language: str | None) -> bool:
        # We handle all files — classification is universal
        return True

    def extract(self, file_path: str, repo_name: str, tree: Tree | None = None, language: str | None = None) -> list[FileClassification]:
        # The scanner already does basic classification. This extractor could
        # enrich it with AST-based detection in the future (e.g., checking imports).
        # For now, return empty to avoid duplicates — the scanner handles it.
        return []
