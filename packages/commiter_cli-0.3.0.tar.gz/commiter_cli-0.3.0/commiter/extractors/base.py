"""Base class for all documentation extractors."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Tree
    from commiter.models import FileClassification


class BaseExtractor(ABC):
    """Base class that all extractors inherit from.

    Each extractor is responsible for finding a specific type of documentation
    artifact (endpoints, dependencies, DB operations, etc.) from parsed files.
    """

    name: str = "base"

    @abstractmethod
    def can_handle(self, file_path: str, language: str | None) -> bool:
        """Whether this extractor should run on the given file."""
        ...

    @abstractmethod
    def extract(self, file_path: str, repo_name: str, tree: "Tree | None" = None, language: str | None = None) -> list[Any]:
        """Extract documentation artifacts from a file.

        Args:
            file_path: Absolute path to the file.
            repo_name: Name of the repository this file belongs to.
            tree: Pre-parsed Tree-sitter tree (None for non-AST extractors).
            language: Detected language of the file.

        Returns:
            A list of model instances (APIEndpoint, Dependency, etc.).
        """
        ...
