"""Extract API endpoint definitions from backend files."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from commiter.adapters.base import BaseAdapter
from commiter.adapters.flask import FlaskAdapter
from commiter.adapters.fastapi import FastAPIAdapter
from commiter.adapters.express import ExpressAdapter
from commiter.adapters.nextjs import NextJSAdapter
from commiter.adapters.django_rest import DjangoRESTAdapter
from commiter.extractors.base import BaseExtractor
from commiter.models import APIEndpoint, Param, ParamSource
from commiter.parser import (
    get_source, find_ts_interface_fields, find_ts_enum_declarations,
    find_ts_type_aliases, find_ts_const_objects, find_py_class_fields,
    parse_generic_type, TypeField,
)
from commiter.generic_resolver import resolve_generic_type

if TYPE_CHECKING:
    from tree_sitter import Tree

# Map framework names to adapter instances
_ADAPTERS: dict[str, BaseAdapter] = {
    "flask": FlaskAdapter(),
    "fastapi": FastAPIAdapter(),
    "express": ExpressAdapter(),
    "nextjs": NextJSAdapter(),
    "django-rest": DjangoRESTAdapter(),
}


def _register_adapter(name: str, adapter: BaseAdapter) -> None:
    """Register an adapter (used by later phases to add Express, Next.js, etc.)."""
    _ADAPTERS[name] = adapter


def get_adapters() -> dict[str, BaseAdapter]:
    """Return all registered adapters."""
    return dict(_ADAPTERS)


class APIEndpointExtractor(BaseExtractor):
    name = "api_endpoints"

    def __init__(self) -> None:
        self._type_index = None
        self._prefix_index = None
        self._middleware_index = None
        self._handler_index = None

    def set_type_index(self, type_index) -> None:
        """Set the cross-file type index (called by scanner after Pass 1)."""
        self._type_index = type_index

    def set_prefix_index(self, prefix_index) -> None:
        """Set the cross-file prefix index (called by scanner after Pass 1)."""
        self._prefix_index = prefix_index

    def set_middleware_index(self, middleware_index) -> None:
        """Set the cross-file middleware index (called by scanner after Pass 1)."""
        self._middleware_index = middleware_index

    def set_handler_index(self, handler_index) -> None:
        """Set the cross-file handler type index (called by scanner after Pass 1)."""
        self._handler_index = handler_index

    def can_handle(self, file_path: str, language: str | None) -> bool:
        if language is None:
            return False
        # Only handle languages we have adapters for
        return language in ("python", "javascript", "typescript", "tsx")

    def extract(self, file_path: str, repo_name: str, tree: Tree | None = None, language: str | None = None) -> list[APIEndpoint]:
        if tree is None or language is None:
            return []

        source = get_source(file_path)
        endpoints = []

        # Build type definitions for resolution (same-file + cross-file fallback)
        type_defs = self._build_type_definitions(tree, source, language, file_path)

        # Detect which framework the file actually uses (from imports/requires)
        file_frameworks = self._detect_file_framework(source, language)

        # Languages that JS adapters should also handle
        js_family = {"javascript", "typescript", "tsx"}

        # Try each adapter that matches the language
        for adapter in _ADAPTERS.values():
            # Match adapter language to file language
            adapter_matches = (
                adapter.language == language
                or (adapter.language in js_family and language in js_family)
            )
            if not adapter_matches:
                continue

            # Skip adapters that don't match the file's actual framework
            if file_frameworks is not None and adapter.framework_name not in file_frameworks:
                continue

            # NextJS adapter needs file_path for convention-based routing
            if isinstance(adapter, NextJSAdapter):
                routes = adapter.find_route_definitions(tree, source, file_path=file_path)
            else:
                routes = adapter.find_route_definitions(tree, source)
            for route in routes:
                # Resolve prefix from blueprint/router mounting
                if self._prefix_index and route.router_var:
                    prefix = self._prefix_index.get_prefix_for_file(file_path, route.router_var)
                    if prefix:
                        route.route_pattern = _join_prefix(prefix, route.route_pattern)

                # Extract details, passing type definitions for resolution
                path_param_names = adapter.extract_path_params(route.route_pattern)
                auth = adapter.extract_auth_info(route, source)

                # Pass type_defs to adapters that support it
                if hasattr(adapter.extract_request_body_fields, '__code__') and \
                   'type_definitions' in adapter.extract_request_body_fields.__code__.co_varnames:
                    body_fields = adapter.extract_request_body_fields(route, source, type_definitions=type_defs)
                else:
                    body_fields = adapter.extract_request_body_fields(route, source)

                response_fields = adapter.extract_response_fields(route, source)

                params = [
                    Param(name=p, source=ParamSource.PATH, type_hint=route.param_types.get(p))
                    for p in path_param_names
                ]

                # Pick up type names from route.param_types (set by adapters)
                request_body_type = route.param_types.get("_request_body_type")
                response_type = route.param_types.get("_response_type")

                # For class-based handlers: look up body type from handler index
                if not request_body_type and self._handler_index and "." in route.handler_name:
                    request_body_type = self._handler_index.get_body_type(route.handler_name)
                    # If we found a body type, also resolve its fields
                    if request_body_type and request_body_type in type_defs:
                        body_fields = []
                        for tf in type_defs[request_body_type]:
                            opt = "?" if tf.optional else ""
                            body_fields.append(f"{tf.name}: {tf.type_str}{opt}")

                # Query middleware index for middleware covering this route
                mw = []
                if self._middleware_index:
                    mw = self._middleware_index.get_middleware_for_route(
                        file_path, route.route_pattern, route.router_var, route.line,
                    )

                endpoints.append(APIEndpoint(
                    repo=repo_name,
                    file_path=file_path,
                    line=route.line,
                    http_method=route.http_method,
                    route_pattern=route.route_pattern,
                    handler_name=route.handler_name,
                    framework=adapter.framework_name,
                    parameters=params,
                    request_body_fields=body_fields,
                    response_fields=response_fields,
                    auth_decorators=auth,
                    request_body_type=request_body_type,
                    response_type=response_type,
                    middleware=mw,
                ))

        return endpoints

    @staticmethod
    def _detect_file_framework(source: bytes, language: str) -> set[str] | None:
        """Detect which framework a file uses based on its imports.

        Returns a set of framework names, or None if we can't determine (allow all).
        """
        text = source.decode("utf-8", errors="replace")

        if language == "python":
            frameworks = set()
            if "from flask" in text or "import flask" in text:
                frameworks.add("flask")
            if "from fastapi" in text or "import fastapi" in text:
                frameworks.add("fastapi")
            if "from django" in text or "from rest_framework" in text:
                frameworks.add("django-rest")
            return frameworks if frameworks else None

        if language in ("javascript", "typescript", "tsx"):
            frameworks = set()
            if "express" in text and ("require(" in text or "from " in text):
                frameworks.add("express")
            if "next" in text or "/pages/api/" in text or "/app/" in text:
                frameworks.add("nextjs")
            # If we found any backend indicators, return them; if none found,
            # return empty set to prevent backend adapters from matching frontend files
            if frameworks:
                return frameworks
            # Check if this looks like a backend file at all (has route-like patterns)
            has_route_patterns = ("router." in text or "app." in text) and ("require" in text or "express" in text)
            if not has_route_patterns:
                return set()  # empty = no backend adapters should run
            return None

        return None

    def _build_type_definitions(self, tree, source: bytes, language: str, file_path: str) -> dict[str, list[TypeField]]:
        """Build a dict of type definitions for resolution.

        Combines same-file definitions with cross-file lookups from the TypeIndex.
        """
        type_defs: dict[str, list[TypeField]] = {}

        if language in ("typescript", "tsx"):
            type_defs = find_ts_interface_fields(tree.root_node, source)
            type_defs.update(find_ts_enum_declarations(tree.root_node, source))
            type_defs.update(find_ts_type_aliases(tree.root_node, source))
            type_defs.update(find_ts_const_objects(tree.root_node, source))
        elif language == "python":
            import re
            text = source.decode("utf-8", errors="replace")
            for match in re.finditer(r'class\s+(\w+)\s*\([^)]*(?:BaseModel|Schema|TypedDict)', text):
                class_name = match.group(1)
                fields = find_py_class_fields(tree.root_node, source, class_name)
                if fields:
                    type_defs[class_name] = fields

        # Wrap with cross-file fallback if TypeIndex is available
        if self._type_index is not None:
            return _TypeDefsWithFallback(type_defs, self._type_index, file_path)

        return type_defs


class _TypeDefsWithFallback(dict):
    """Dict-like that falls back to TypeIndex for missing keys."""

    def __init__(self, local_defs: dict, type_index, file_path: str):
        super().__init__(local_defs)
        self._type_index = type_index
        self._file_path = file_path

    def __bool__(self):
        # Always truthy so `if type_definitions and ...` doesn't short-circuit
        return True

    def __contains__(self, key):
        if super().__contains__(key):
            return True
        # Check cross-file index
        typedef = self._type_index.resolve(key, None, self._file_path)
        if typedef is not None:
            return True
        # Check if it's a generic type we can resolve
        if "<" in key or key.endswith("[]"):
            resolved = self._try_generic_resolve(key)
            if resolved is not None:
                return True
        return False

    def __getitem__(self, key):
        try:
            fields = super().__getitem__(key)
        except KeyError:
            typedef = self._type_index.resolve(key, None, self._file_path)
            if typedef is not None:
                fields = typedef.fields
            else:
                # Try generic resolution: Pick<User, "id">, Partial<User>, etc.
                if "<" in key or key.endswith("[]"):
                    resolved = self._try_generic_resolve(key)
                    if resolved is not None:
                        return self._resolve_type_refs(resolved)
                raise
        # Resolve any __type_ref__ markers (from intersections/unions)
        return self._resolve_type_refs(fields)

    def _try_generic_resolve(self, type_str: str) -> list | None:
        """Try to resolve a generic type like Pick<User, "id"> to fields."""
        def type_lookup(name):
            try:
                return list(self[name])  # recursive — uses our own __getitem__
            except KeyError:
                return None

        def generic_def_lookup(name):
            """Look up a generic type definition and return (fields, generic_params)."""
            # Try local
            try:
                fields = list(super(_TypeDefsWithFallback, self).__getitem__(name))
                # Check type_index for generic_params
                typedef = self._type_index.resolve(name, None, self._file_path)
                params = typedef.generic_params if typedef else []
                return (fields, params)
            except KeyError:
                pass
            # Try cross-file
            typedef = self._type_index.resolve(name, None, self._file_path)
            if typedef:
                return (list(typedef.fields), typedef.generic_params)
            return None

        return resolve_generic_type(type_str, type_lookup, generic_def_lookup)

    def _resolve_type_refs(self, fields: list, depth: int = 0) -> list:
        """Recursively resolve __type_ref__ and __generic__ markers to actual fields."""
        if depth > 5:
            return fields  # guard against circular refs

        resolved = []
        for field in fields:
            if field.type_str == "__type_ref__":
                ref_fields = self._lookup_type(field.name)
                if ref_fields:
                    resolved.extend(self._resolve_type_refs(ref_fields, depth + 1))
                else:
                    resolved.append(field)
            elif field.type_str == "__generic__" and field.value:
                # Generic type alias: Pick<User, "id">, Partial<User>, ApiResponse<User>
                generic_fields = self._try_generic_resolve(field.value)
                if generic_fields:
                    resolved.extend(self._resolve_type_refs(generic_fields, depth + 1))
                else:
                    resolved.append(field)
            else:
                resolved.append(field)
        return resolved

    def _lookup_type(self, type_name: str) -> list | None:
        """Look up a type by name in local defs or cross-file index."""
        # Try local first
        try:
            return list(super().__getitem__(type_name))
        except KeyError:
            pass
        # Try cross-file
        typedef = self._type_index.resolve(type_name, None, self._file_path)
        if typedef is not None:
            return list(typedef.fields)
        return None


def _join_prefix(prefix: str, route: str) -> str:
    """Join a URL prefix with a route pattern, avoiding double slashes."""
    prefix = prefix.rstrip("/")
    if not route.startswith("/"):
        route = "/" + route
    return prefix + route
