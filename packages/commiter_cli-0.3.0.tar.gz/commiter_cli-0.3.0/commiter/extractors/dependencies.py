"""Extract dependencies from manifest files (package.json, requirements.txt, pyproject.toml, etc.)."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

from tree_sitter import Tree

from commiter.extractors.base import BaseExtractor
from commiter.models import Dependency

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

# Files this extractor handles
MANIFEST_FILES = {
    "package.json",
    "requirements.txt",
    "pyproject.toml",
    "setup.cfg",
    "Pipfile",
    "go.mod",
    "Cargo.toml",
    "Gemfile",
    "composer.json",
}


class DependencyExtractor(BaseExtractor):
    name = "dependencies"

    def can_handle(self, file_path: str, language: str | None) -> bool:
        return Path(file_path).name in MANIFEST_FILES

    def extract(self, file_path: str, repo_name: str, tree: Tree | None = None, language: str | None = None) -> list[Dependency]:
        filename = Path(file_path).name
        try:
            content = Path(file_path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []

        dispatch = {
            "package.json": self._parse_package_json,
            "requirements.txt": self._parse_requirements_txt,
            "pyproject.toml": self._parse_pyproject_toml,
            "setup.cfg": self._parse_setup_cfg,
            "Pipfile": self._parse_pipfile,
            "go.mod": self._parse_go_mod,
            "Cargo.toml": self._parse_cargo_toml,
            "Gemfile": self._parse_gemfile,
            "composer.json": self._parse_composer_json,
        }

        parser = dispatch.get(filename)
        if parser is None:
            return []
        return parser(content, file_path, repo_name)

    def _parse_package_json(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            return []

        for name, version in data.get("dependencies", {}).items():
            deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path, dev_only=False))
        for name, version in data.get("devDependencies", {}).items():
            deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path, dev_only=True))
        return deps

    def _parse_requirements_txt(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            # Handle name==version, name>=version, name~=version, bare name
            match = re.match(r"^([a-zA-Z0-9_.-]+)\s*([><=!~]+.+)?", line)
            if match:
                name = match.group(1)
                version = match.group(2) or "*"
                deps.append(Dependency(repo=repo_name, name=name, version_constraint=version.strip(), source_file=file_path))
        return deps

    def _parse_pyproject_toml(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        try:
            data = tomllib.loads(content)
        except Exception:
            return []

        for dep_str in data.get("project", {}).get("dependencies", []):
            name, version = self._split_pep508(dep_str)
            deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path))

        for group_deps in data.get("project", {}).get("optional-dependencies", {}).values():
            for dep_str in group_deps:
                name, version = self._split_pep508(dep_str)
                deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path, dev_only=True))
        return deps

    def _parse_setup_cfg(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        in_install_requires = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped == "install_requires =":
                in_install_requires = True
                continue
            if in_install_requires:
                if not stripped or (not line[0].isspace() and "=" in stripped):
                    break
                name, version = self._split_pep508(stripped)
                deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path))
        return deps

    def _parse_pipfile(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        section = None
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("["):
                section = stripped.strip("[]").lower()
                continue
            if section in ("packages", "dev-packages") and "=" in stripped:
                name, _, version = stripped.partition("=")
                name = name.strip().strip('"')
                version = version.strip().strip('"')
                deps.append(Dependency(
                    repo=repo_name, name=name, version_constraint=version,
                    source_file=file_path, dev_only=(section == "dev-packages"),
                ))
        return deps

    def _parse_go_mod(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        in_require = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("require ("):
                in_require = True
                continue
            if in_require:
                if stripped == ")":
                    in_require = False
                    continue
                parts = stripped.split()
                if len(parts) >= 2:
                    deps.append(Dependency(repo=repo_name, name=parts[0], version_constraint=parts[1], source_file=file_path))
            elif stripped.startswith("require "):
                parts = stripped.split()
                if len(parts) >= 3:
                    deps.append(Dependency(repo=repo_name, name=parts[1], version_constraint=parts[2], source_file=file_path))
        return deps

    def _parse_cargo_toml(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        try:
            data = tomllib.loads(content)
        except Exception:
            return []

        for section_key in ("dependencies", "dev-dependencies"):
            dev = section_key == "dev-dependencies"
            for name, val in data.get(section_key, {}).items():
                if isinstance(val, str):
                    version = val
                elif isinstance(val, dict):
                    version = val.get("version", "*")
                else:
                    version = "*"
                deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path, dev_only=dev))
        return deps

    def _parse_gemfile(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        for line in content.splitlines():
            stripped = line.strip()
            match = re.match(r"""gem\s+['"]([^'"]+)['"](?:\s*,\s*['"]([^'"]+)['"])?""", stripped)
            if match:
                name = match.group(1)
                version = match.group(2) or "*"
                deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path))
        return deps

    def _parse_composer_json(self, content: str, file_path: str, repo_name: str) -> list[Dependency]:
        deps = []
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            return []

        for name, version in data.get("require", {}).items():
            if name == "php":
                continue
            deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path))
        for name, version in data.get("require-dev", {}).items():
            deps.append(Dependency(repo=repo_name, name=name, version_constraint=version, source_file=file_path, dev_only=True))
        return deps

    @staticmethod
    def _split_pep508(dep_str: str) -> tuple[str, str]:
        """Split a PEP 508 dependency string into (name, version_constraint)."""
        match = re.match(r"^([a-zA-Z0-9_.-]+)\s*(.*)", dep_str.strip())
        if match:
            name = match.group(1)
            rest = match.group(2).strip().rstrip(";").strip()
            # Remove environment markers
            if ";" in rest:
                rest = rest[:rest.index(";")].strip()
            return name, rest if rest else "*"
        return dep_str.strip(), "*"
