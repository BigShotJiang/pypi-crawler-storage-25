"""Extract frontend API calls (fetch, axios, etc.) from component files."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from commiter.adapters.react import ReactAdapter
from commiter.extractors.base import BaseExtractor
from commiter.models import APICall
from commiter.parser import get_source, build_constants_from_file

if TYPE_CHECKING:
    from tree_sitter import Tree

_FRONTEND_ADAPTER = ReactAdapter()


class APICallExtractor(BaseExtractor):
    name = "api_calls"
    _env_vars: dict[str, str] = {}

    def set_env_vars(self, env_vars: dict[str, str]) -> None:
        """Set environment variables from .env files (called by scanner)."""
        self._env_vars = env_vars

    def can_handle(self, file_path: str, language: str | None) -> bool:
        if language not in ("javascript", "typescript", "tsx"):
            return False
        # Focus on frontend-like files (components, pages, hooks, lib)
        lower = file_path.lower()
        frontend_hints = (
            "components/", "pages/", "src/", "app/", "hooks/",
            "lib/", "utils/", "services/", "features/",
        )
        # Exclude API route files (backend)
        if "/pages/api/" in lower or "/route." in Path(file_path).name.lower():
            return False
        return any(hint in lower for hint in frontend_hints) or language in ("tsx",)

    def extract(self, file_path: str, repo_name: str, tree: Tree | None = None, language: str | None = None) -> list[APICall]:
        if tree is None:
            return []

        source = get_source(file_path)

        # Build per-file constants for URL resolution
        constants = build_constants_from_file(tree.root_node, source, self._env_vars)
        matches = _FRONTEND_ADAPTER.find_api_calls(tree, source, file_path=file_path, constants=constants)

        # Derive component/page name from file path
        component_name = self._infer_component_name(file_path)

        calls = []
        for match in matches:
            calls.append(APICall(
                repo=repo_name,
                file_path=file_path,
                line=match.line,
                component_or_page=component_name,
                http_method=match.http_method,
                url_pattern=match.url_pattern,
                client_library=self._detect_library(match),
                response_type=match.response_type,
                body_type=match.body_type,
            ))

        return calls

    def _infer_component_name(self, file_path: str) -> str:
        """Derive a component/page name from the file path."""
        path = Path(file_path)
        # Use parent dir + stem for index files
        if path.stem in ("index", "page"):
            return path.parent.name
        return path.stem

    def _detect_library(self, match) -> str:
        """Detect which HTTP library was used."""
        # Based on the adapter that found it — for now just check the call text
        # ReactAdapter already distinguishes fetch vs axios
        if hasattr(match, "call_node"):
            from commiter.parser import node_text
            # Simple heuristic based on node content
            try:
                source = match.call_node.text
                if source and b"axios" in source:
                    return "axios"
            except (AttributeError, TypeError):
                pass
        return "fetch"
