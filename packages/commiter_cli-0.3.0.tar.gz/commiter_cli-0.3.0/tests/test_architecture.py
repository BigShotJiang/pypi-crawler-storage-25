"""Tests for the architecture output format."""

from __future__ import annotations

import json
import os

import pytest

from commiter.report.architecture import (
    _build_file_tree,
    _build_nodes,
    _compute_layout,
    _build_edges,
    _build_node_analysis,
    generate_architecture,
)
from commiter.models import (
    APICall,
    APIEndpoint,
    DBOperation,
    Dependency,
    FileClassification,
    FileRole,
    RepoDocumentation,
)
from commiter.scanner import ScanResult, _scan_repo_full, scan_repos_full
from commiter.type_index import TypeIndex
from commiter.middleware_index import MiddlewareIndex
from commiter.utils.tsconfig_resolver import TSConfigRegistry


FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_doc(
    repo_name: str = "test-repo",
    repo_path: str = "/tmp/test-repo",
    endpoints: list | None = None,
    api_calls: list | None = None,
    db_operations: list | None = None,
    file_classifications: list | None = None,
) -> RepoDocumentation:
    doc = RepoDocumentation(repo_name=repo_name, repo_path=repo_path)
    if endpoints:
        doc.endpoints = endpoints
    if api_calls:
        doc.api_calls = api_calls
    if db_operations:
        doc.db_operations = db_operations
    if file_classifications:
        doc.file_classifications = file_classifications
    return doc


def _make_scan_result(doc: RepoDocumentation, file_list: list[str] | None = None) -> ScanResult:
    return ScanResult(
        doc=doc,
        type_index=TypeIndex(alias_resolver=TSConfigRegistry("/tmp")),
        middleware_index=MiddlewareIndex(),
        file_list=file_list or [],
    )


# ---------------------------------------------------------------------------
# _build_file_tree
# ---------------------------------------------------------------------------

class TestBuildFileTree:
    def test_flat_files(self):
        files = ["/repo/a.py", "/repo/b.py"]
        tree = _build_file_tree(files, "/repo")
        assert len(tree) == 2
        assert tree[0] == {"name": "a.py", "type": "file", "path": "a.py"}
        assert tree[1] == {"name": "b.py", "type": "file", "path": "b.py"}

    def test_nested_folders(self):
        files = ["/repo/src/app/page.tsx", "/repo/src/lib/api.ts"]
        tree = _build_file_tree(files, "/repo")
        assert len(tree) == 1  # just "src" folder
        assert tree[0]["name"] == "src"
        assert tree[0]["type"] == "folder"
        assert len(tree[0]["children"]) == 2  # app + lib

    def test_paths_are_relative(self):
        files = ["/repo/components/Button.tsx"]
        tree = _build_file_tree(files, "/repo")
        assert tree[0]["children"][0]["path"] == "components/Button.tsx"


# ---------------------------------------------------------------------------
# _build_nodes
# ---------------------------------------------------------------------------

class TestBuildNodes:
    def test_frontend_page_gets_individual_node(self):
        doc = _make_doc(
            file_classifications=[
                FileClassification(file_path="/tmp/test-repo/app/page.tsx", role=FileRole.FRONTEND, language="tsx"),
            ],
        )
        files = ["/tmp/test-repo/app/page.tsx"]
        nodes = _build_nodes(doc, files, "/tmp/test-repo", "")
        page_nodes = [n for n in nodes if n["type"] == "page"]
        assert len(page_nodes) == 1
        assert page_nodes[0]["category"] == "frontend"

    def test_backend_routes_grouped(self):
        doc = _make_doc(
            endpoints=[
                APIEndpoint(repo="test", file_path="/tmp/test-repo/routes/users.py", line=1,
                            http_method="GET", route_pattern="/users", handler_name="list_users", framework="flask"),
                APIEndpoint(repo="test", file_path="/tmp/test-repo/routes/auth.py", line=1,
                            http_method="POST", route_pattern="/login", handler_name="login", framework="flask"),
            ],
            file_classifications=[
                FileClassification(file_path="/tmp/test-repo/routes/users.py", role=FileRole.BACKEND, language="python"),
                FileClassification(file_path="/tmp/test-repo/routes/auth.py", role=FileRole.BACKEND, language="python"),
            ],
        )
        doc.frameworks = ["flask"]
        files = ["/tmp/test-repo/routes/users.py", "/tmp/test-repo/routes/auth.py"]
        nodes = _build_nodes(doc, files, "/tmp/test-repo", "")
        service_nodes = [n for n in nodes if n["type"] == "service"]
        assert len(service_nodes) == 1  # grouped into one
        assert len(service_nodes[0]["files"]) == 2
        assert "Flask" in service_nodes[0]["label"]

    def test_provider_gets_own_node(self):
        doc = _make_doc(
            file_classifications=[
                FileClassification(file_path="/tmp/test-repo/components/providers/auth-provider.tsx",
                                   role=FileRole.FRONTEND, language="tsx"),
            ],
        )
        files = ["/tmp/test-repo/components/providers/auth-provider.tsx"]
        nodes = _build_nodes(doc, files, "/tmp/test-repo", "")
        assert any(n["type"] == "provider" for n in nodes)

    def test_db_node_created_from_operations(self):
        doc = _make_doc(
            db_operations=[
                DBOperation(repo="test", file_path="/tmp/test-repo/app.py", line=10,
                            operation_type="select", table_name="users", orm_library="supabase"),
            ],
            file_classifications=[],
        )
        nodes = _build_nodes(doc, ["/tmp/test-repo/app.py"], "/tmp/test-repo", "")
        db_nodes = [n for n in nodes if n["type"] == "database"]
        assert len(db_nodes) == 1
        assert "supabase" in db_nodes[0]["label"].lower()

    def test_multi_repo_prefix(self):
        doc = _make_doc(
            file_classifications=[
                FileClassification(file_path="/tmp/test-repo/app/page.tsx", role=FileRole.FRONTEND, language="tsx"),
            ],
        )
        files = ["/tmp/test-repo/app/page.tsx"]
        nodes = _build_nodes(doc, files, "/tmp/test-repo", "my-frontend")
        assert nodes[0]["id"].startswith("my-frontend-")

    def test_files_with_endpoints_become_backend(self):
        """Files classified as UNKNOWN but containing endpoints should become service nodes."""
        doc = _make_doc(
            endpoints=[
                APIEndpoint(repo="test", file_path="/tmp/test-repo/api/routes.ts", line=5,
                            http_method="GET", route_pattern="/health", handler_name="health", framework="express"),
            ],
            file_classifications=[
                FileClassification(file_path="/tmp/test-repo/api/routes.ts", role=FileRole.UNKNOWN, language="typescript"),
            ],
        )
        doc.frameworks = ["express"]
        files = ["/tmp/test-repo/api/routes.ts"]
        nodes = _build_nodes(doc, files, "/tmp/test-repo", "")
        service_nodes = [n for n in nodes if n["type"] == "service"]
        assert len(service_nodes) == 1


# ---------------------------------------------------------------------------
# _compute_layout
# ---------------------------------------------------------------------------

class TestComputeLayout:
    def test_all_nodes_get_coordinates(self):
        nodes = [
            {"id": "n1", "type": "page", "category": "frontend", "x": 0, "y": 0},
            {"id": "n2", "type": "service", "category": "backend", "x": 0, "y": 0},
            {"id": "n3", "type": "database", "category": "data", "x": 0, "y": 0},
        ]
        _compute_layout(nodes)
        for n in nodes:
            assert n["x"] > 0
            assert n["y"] > 0

    def test_layers_have_different_y(self):
        nodes = [
            {"id": "n1", "type": "page", "category": "frontend", "x": 0, "y": 0},
            {"id": "n2", "type": "service", "category": "backend", "x": 0, "y": 0},
            {"id": "n3", "type": "database", "category": "data", "x": 0, "y": 0},
        ]
        _compute_layout(nodes)
        ys = [n["y"] for n in nodes]
        assert len(set(ys)) == 3  # each on a different layer

    def test_no_x_overlap_in_same_layer(self):
        nodes = [
            {"id": f"p{i}", "type": "page", "category": "frontend", "x": 0, "y": 0}
            for i in range(5)
        ]
        _compute_layout(nodes)
        xs = [n["x"] for n in nodes]
        assert len(set(xs)) == 5  # all unique


# ---------------------------------------------------------------------------
# Integration: generate_architecture with real fixtures
# ---------------------------------------------------------------------------

class TestGenerateArchitecture:
    def test_flask_app_valid_json(self):
        fixture = os.path.join(FIXTURES, "flask_app")
        if not os.path.isdir(fixture):
            pytest.skip("flask_app fixture not found")
        results = scan_repos_full([fixture])
        output = generate_architecture(results)
        data = json.loads(output)

        assert "nodes" in data
        assert "edges" in data
        assert "fileTree" in data
        assert "nodeAnalysis" in data
        assert isinstance(data["nodes"], list)
        assert isinstance(data["edges"], list)
        assert isinstance(data["fileTree"], list)
        assert isinstance(data["nodeAnalysis"], dict)

    def test_flask_app_has_service_node(self):
        fixture = os.path.join(FIXTURES, "flask_app")
        if not os.path.isdir(fixture):
            pytest.skip("flask_app fixture not found")
        results = scan_repos_full([fixture])
        data = json.loads(generate_architecture(results))
        types = [n["type"] for n in data["nodes"]]
        assert "service" in types

    def test_flask_app_has_data_edge(self):
        fixture = os.path.join(FIXTURES, "flask_app")
        if not os.path.isdir(fixture):
            pytest.skip("flask_app fixture not found")
        results = scan_repos_full([fixture])
        data = json.loads(generate_architecture(results))
        edge_types = [e["type"] for e in data["edges"]]
        assert "data" in edge_types

    def test_express_real_has_endpoints_in_analysis(self):
        fixture = os.path.join(FIXTURES, "express_real")
        if not os.path.isdir(fixture):
            pytest.skip("express_real fixture not found")
        results = scan_repos_full([fixture])
        data = json.loads(generate_architecture(results))
        # Find the service node analysis
        for node_id, analysis in data["nodeAnalysis"].items():
            if "endpoints" in analysis and analysis["endpoints"]:
                # Verify endpoint shape
                ep = analysis["endpoints"][0]
                assert "method" in ep
                assert "path" in ep
                assert "category" in ep
                assert "usedBy" in ep
                return
        pytest.fail("No endpoints found in any node analysis")

    def test_multi_repo_cross_edges(self):
        frontend = os.path.join(FIXTURES, "nextjs_app")
        backend = os.path.join(FIXTURES, "flask_app")
        if not os.path.isdir(frontend) or not os.path.isdir(backend):
            pytest.skip("fixtures not found")
        results = scan_repos_full([frontend, backend])
        data = json.loads(generate_architecture(results))

        # Should have nodes from both repos
        node_ids = [n["id"] for n in data["nodes"]]
        assert any("nextjs" in nid for nid in node_ids)
        assert any("flask" in nid for nid in node_ids)

        # Should have at least one cross-repo api edge
        api_edges = [e for e in data["edges"] if e["type"] == "api"]
        assert len(api_edges) > 0

    def test_node_analysis_keys_match_node_ids(self):
        fixture = os.path.join(FIXTURES, "flask_app")
        if not os.path.isdir(fixture):
            pytest.skip("flask_app fixture not found")
        results = scan_repos_full([fixture])
        data = json.loads(generate_architecture(results))
        node_ids = {n["id"] for n in data["nodes"]}
        analysis_ids = set(data["nodeAnalysis"].keys())
        assert analysis_ids == node_ids


# ---------------------------------------------------------------------------
# Comprehensive dual-repo integration test
# ---------------------------------------------------------------------------

class TestDualRepoArchitecture:
    """End-to-end test with a realistic frontend + backend split repo.

    Frontend (arch_frontend): Next.js with pages, providers, components,
        API client layer, and Supabase client.
    Backend (arch_backend): Flask with blueprints, auth, 4 route modules,
        Supabase DB operations, and login_required decorator.
    """

    @pytest.fixture(autouse=True)
    def setup(self):
        self.frontend = os.path.join(FIXTURES, "arch_frontend")
        self.backend = os.path.join(FIXTURES, "arch_backend")
        if not os.path.isdir(self.frontend) or not os.path.isdir(self.backend):
            pytest.skip("arch_frontend / arch_backend fixtures not found")
        results = scan_repos_full([self.frontend, self.backend])
        self.data = json.loads(generate_architecture(results))
        self.nodes = self.data["nodes"]
        self.edges = self.data["edges"]
        self.tree = self.data["fileTree"]
        self.analysis = self.data["nodeAnalysis"]

    # --- Structural validity ---

    def test_output_has_all_top_level_keys(self):
        assert set(self.data.keys()) == {"nodes", "edges", "fileTree", "nodeAnalysis", "nodeHashes"}

    def test_every_node_has_required_fields(self):
        required = {"id", "label", "type", "category", "x", "y", "description", "files"}
        for node in self.nodes:
            assert required.issubset(node.keys()), f"Node {node['id']} missing keys"

    def test_every_edge_has_required_fields(self):
        required = {"id", "from", "to", "type"}
        for edge in self.edges:
            assert required.issubset(edge.keys()), f"Edge {edge['id']} missing keys"

    def test_edge_refs_point_to_existing_nodes(self):
        node_ids = {n["id"] for n in self.nodes}
        for edge in self.edges:
            assert edge["from"] in node_ids, f"Edge {edge['id']} 'from' refs unknown node {edge['from']}"
            assert edge["to"] in node_ids, f"Edge {edge['id']} 'to' refs unknown node {edge['to']}"

    def test_analysis_keys_match_nodes(self):
        node_ids = {n["id"] for n in self.nodes}
        assert set(self.analysis.keys()) == node_ids

    # --- Node detection ---

    def test_has_frontend_pages(self):
        pages = [n for n in self.nodes if n["type"] == "page"]
        page_labels = {n["label"] for n in pages}
        assert len(pages) >= 4
        # Should detect Dashboard, Login, Settings, and the root App page
        assert any("dashboard" in l.lower() for l in page_labels)
        assert any("login" in l.lower() for l in page_labels)
        assert any("settings" in l.lower() for l in page_labels)

    def test_has_providers(self):
        providers = [n for n in self.nodes if n["type"] == "provider"]
        assert len(providers) >= 2
        labels = {n["label"].lower() for n in providers}
        assert any("auth" in l for l in labels)
        assert any("project" in l for l in labels)

    def test_has_components(self):
        components = [n for n in self.nodes if n["type"] == "component"]
        assert len(components) >= 2
        labels = {n["label"].lower() for n in components}
        assert any("sidebar" in l for l in labels)
        assert any("project" in l for l in labels)

    def test_has_api_layer_nodes(self):
        api_nodes = [n for n in self.nodes if n["type"] == "api"]
        assert len(api_nodes) >= 2
        labels = {n["label"].lower() for n in api_nodes}
        assert any("client" in l for l in labels)
        assert any("auth" in l for l in labels)

    def test_backend_routes_grouped_into_one_service(self):
        services = [n for n in self.nodes if n["type"] == "service" and n["category"] == "backend"]
        assert len(services) == 1
        svc = services[0]
        assert "flask" in svc["label"].lower()
        # Should contain all 4 route files (plus app.py, middleware, __init__.py)
        route_files = {os.path.basename(f) for f in svc["files"] if "routes/" in f.replace("\\", "/")}
        assert {"auth.py", "users.py", "projects.py", "analytics.py"}.issubset(route_files)

    def test_has_database_nodes(self):
        db_nodes = [n for n in self.nodes if n["type"] == "database"]
        assert len(db_nodes) >= 1

    def test_all_nodes_have_repo_prefix(self):
        for node in self.nodes:
            assert node["id"].startswith("arch-frontend-") or node["id"].startswith("arch-backend-")

    # --- Edge detection ---

    def test_has_cross_repo_api_edges(self):
        """Frontend nodes should have API edges to the backend service."""
        api_edges = [e for e in self.edges if e["type"] == "api"]
        assert len(api_edges) >= 3
        # At least some should cross from frontend to backend
        cross_repo = [
            e for e in api_edges
            if e["from"].startswith("arch-frontend-") and e["to"].startswith("arch-backend-")
        ]
        assert len(cross_repo) >= 3

    def test_has_data_edges_to_database(self):
        data_edges = [e for e in self.edges if e["type"] == "data"]
        assert len(data_edges) >= 1
        for e in data_edges:
            target = next(n for n in self.nodes if n["id"] == e["to"])
            assert target["type"] == "database"

    def test_has_auth_edge(self):
        auth_edges = [e for e in self.edges if e["type"] == "auth"]
        assert len(auth_edges) >= 1

    def test_has_dependency_edges(self):
        dep_edges = [e for e in self.edges if e["type"] == "dependency"]
        assert len(dep_edges) >= 2

    def test_no_self_loops(self):
        for edge in self.edges:
            assert edge["from"] != edge["to"], f"Edge {edge['id']} is a self-loop"

    # --- Layout ---

    def test_pages_on_top_layer(self):
        pages = [n for n in self.nodes if n["type"] == "page"]
        other = [n for n in self.nodes if n["type"] != "page"]
        if pages and other:
            max_page_y = max(n["y"] for n in pages)
            min_other_y = min(n["y"] for n in other)
            assert max_page_y <= min_other_y

    def test_database_on_bottom_layer(self):
        db = [n for n in self.nodes if n["type"] == "database"]
        other = [n for n in self.nodes if n["type"] != "database"]
        if db and other:
            min_db_y = min(n["y"] for n in db)
            max_other_y = max(n["y"] for n in other)
            assert min_db_y >= max_other_y

    # --- Node analysis content ---

    def test_backend_service_has_all_endpoints(self):
        svc = next(n for n in self.nodes if n["type"] == "service" and n["category"] == "backend")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        assert len(endpoints) >= 15  # 3 auth + 5 users + 5 projects + 2 analytics
        methods = {ep["method"] for ep in endpoints}
        assert {"GET", "POST", "PUT", "DELETE"}.issubset(methods)

    def test_endpoints_have_categories(self):
        svc = next(n for n in self.nodes if n["type"] == "service")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        categories = {ep["category"] for ep in endpoints}
        assert "Auth" in categories
        assert "Users" in categories
        assert "Projects" in categories
        assert "Analytics" in categories

    def test_endpoints_have_db_operations(self):
        svc = next(n for n in self.nodes if n["type"] == "service")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        eps_with_db = [ep for ep in endpoints if ep.get("dbOperations")]
        assert len(eps_with_db) >= 10  # most endpoints touch the DB
        # Check DB op shape
        op = eps_with_db[0]["dbOperations"][0]
        assert "type" in op
        assert "table" in op

    def test_endpoints_have_request_shapes(self):
        svc = next(n for n in self.nodes if n["type"] == "service")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        post_eps = [ep for ep in endpoints if ep["method"] == "POST"]
        eps_with_body = [ep for ep in post_eps if ep.get("requestShape")]
        assert len(eps_with_body) >= 2  # login, create_project, etc.

    def test_backend_has_login_required_rule(self):
        svc = next(n for n in self.nodes if n["type"] == "service")
        rules = self.analysis[svc["id"]].get("rules", [])
        assert len(rules) >= 1
        rule_names = {r["name"] for r in rules}
        assert "login_required" in rule_names
        lr = next(r for r in rules if r["name"] == "login_required")
        assert lr["type"] == "guard"
        assert len(lr["appliedTo"]) >= 10  # most routes require auth

    def test_pages_have_data_sources(self):
        pages = [n for n in self.nodes if n["type"] == "page"]
        pages_with_data = [
            n for n in pages
            if self.analysis[n["id"]].get("dataUsed")
        ]
        assert len(pages_with_data) >= 3  # dashboard, settings, home all fetch data

    def test_analysis_has_empty_commits_and_issues(self):
        """Commits and issues require user accounts — should be empty."""
        for node_id, a in self.analysis.items():
            assert a["commits"] == []
            assert a["issues"] == []

    # --- File tree ---

    def test_file_tree_has_both_repos(self):
        top_names = {n["name"] for n in self.tree}
        # Frontend has src/, backend has routes/
        all_names = set()
        def collect(nodes):
            for n in nodes:
                all_names.add(n["name"])
                if "children" in n:
                    collect(n["children"])
        collect(self.tree)
        assert "src" in all_names  # frontend
        assert "routes" in all_names  # backend

    def test_file_tree_structure_is_valid(self):
        def validate(nodes, prefix=""):
            for n in nodes:
                assert "name" in n
                assert "type" in n
                assert "path" in n
                assert n["type"] in ("file", "folder")
                if n["type"] == "folder":
                    assert "children" in n
                    validate(n["children"], n["path"])
        validate(self.tree)

    # --- DB tables ---

    def test_backend_touches_expected_tables(self):
        svc = next(n for n in self.nodes if n["type"] == "service")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        all_tables = set()
        for ep in endpoints:
            for op in ep.get("dbOperations", []):
                all_tables.add(op["table"])
        assert "users" in all_tables
        assert "sessions" in all_tables
        assert "projects" in all_tables
        assert "connections" in all_tables


# ---------------------------------------------------------------------------
# Monorepo integration test (single scan, frontend + backend in one repo)
# ---------------------------------------------------------------------------

class TestMonorepoArchitecture:
    """End-to-end test with a realistic monorepo simulating a SaaS project management app.

    Structure:
        apps/web/     - Next.js frontend (6 pages, 2 providers, 5 components, 5 API modules)
        apps/api/     - Flask backend (6 route modules, middleware, services)
        packages/shared-types/ - Shared TypeScript types

    This tests single-repo monorepo scanning (not multi-repo).
    """

    @pytest.fixture(autouse=True)
    def setup(self):
        self.fixture = os.path.join(FIXTURES, "arch_monorepo")
        if not os.path.isdir(self.fixture):
            pytest.skip("arch_monorepo fixture not found")
        results = scan_repos_full([self.fixture])
        self.data = json.loads(generate_architecture(results))
        self.nodes = self.data["nodes"]
        self.edges = self.data["edges"]
        self.tree = self.data["fileTree"]
        self.analysis = self.data["nodeAnalysis"]

    # --- Structural validity ---

    def test_valid_json_structure(self):
        assert set(self.data.keys()) == {"nodes", "edges", "fileTree", "nodeAnalysis", "nodeHashes"}
        assert isinstance(self.data["nodes"], list)
        assert isinstance(self.data["edges"], list)
        assert isinstance(self.data["fileTree"], list)
        assert isinstance(self.data["nodeAnalysis"], dict)

    def test_all_nodes_have_coordinates(self):
        for node in self.nodes:
            assert node["x"] > 0, f"Node {node['id']} has x=0"
            assert node["y"] > 0, f"Node {node['id']} has y=0"

    def test_no_self_loop_edges(self):
        for edge in self.edges:
            assert edge["from"] != edge["to"], f"Self-loop: {edge['id']}"

    def test_edge_refs_valid(self):
        ids = {n["id"] for n in self.nodes}
        for edge in self.edges:
            assert edge["from"] in ids, f"Edge {edge['id']} from unknown node"
            assert edge["to"] in ids, f"Edge {edge['id']} to unknown node"

    def test_analysis_covers_all_nodes(self):
        assert set(self.analysis.keys()) == {n["id"] for n in self.nodes}

    # --- Node detection across monorepo ---

    def test_detects_frontend_pages(self):
        pages = [n for n in self.nodes if n["type"] == "page"]
        labels = {n["label"].lower() for n in pages}
        assert len(pages) >= 5
        assert "dashboard" in labels
        assert "login" in labels
        assert "projects" in labels
        assert "settings" in labels
        assert "invite" in labels

    def test_detects_providers(self):
        providers = [n for n in self.nodes if n["type"] == "provider"]
        labels = {n["label"].lower() for n in providers}
        assert len(providers) >= 2
        assert any("auth" in l for l in labels)
        assert any("workspace" in l for l in labels)

    def test_detects_feature_components(self):
        components = [n for n in self.nodes if n["type"] == "component"]
        labels = {n["label"].lower() for n in components}
        assert any("kanban" in l for l in labels)
        assert any("sidebar" in l for l in labels)

    def test_detects_api_layer(self):
        api_nodes = [n for n in self.nodes if n["type"] == "api"]
        labels = {n["label"].lower() for n in api_nodes}
        assert len(api_nodes) >= 4
        assert any("client" in l for l in labels)

    def test_backend_grouped_into_one_service(self):
        services = [n for n in self.nodes if n["type"] == "service" and n["category"] == "backend"]
        assert len(services) == 1
        svc = services[0]
        route_files = [f for f in svc["files"] if "routes/" in f.replace("\\", "/")]
        assert len(route_files) >= 6

    def test_detects_database_node(self):
        db_nodes = [n for n in self.nodes if n["type"] == "database"]
        assert len(db_nodes) >= 1

    # --- Edge detection ---

    def test_has_api_edges(self):
        api_edges = [e for e in self.edges if e["type"] == "api"]
        assert len(api_edges) >= 5

    def test_has_data_edges(self):
        data_edges = [e for e in self.edges if e["type"] == "data"]
        assert len(data_edges) >= 1

    def test_has_auth_edge(self):
        auth_edges = [e for e in self.edges if e["type"] == "auth"]
        assert len(auth_edges) >= 1

    def test_has_dependency_edges(self):
        dep_edges = [e for e in self.edges if e["type"] == "dependency"]
        assert len(dep_edges) >= 3

    # --- Backend analysis ---

    def test_backend_has_many_endpoints(self):
        svc = next(n for n in self.nodes if n["type"] == "service" and n["category"] == "backend")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        assert len(endpoints) >= 20

    def test_endpoints_span_multiple_categories(self):
        svc = next(n for n in self.nodes if n["type"] == "service" and n["category"] == "backend")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        categories = {ep["category"] for ep in endpoints}
        assert len(categories) >= 4

    def test_endpoints_cover_all_http_methods(self):
        svc = next(n for n in self.nodes if n["type"] == "service" and n["category"] == "backend")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        methods = {ep["method"] for ep in endpoints}
        assert {"GET", "POST", "PUT", "DELETE"}.issubset(methods)

    def test_endpoints_have_db_operations(self):
        svc = next(n for n in self.nodes if n["type"] == "service" and n["category"] == "backend")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        with_db = [ep for ep in endpoints if ep.get("dbOperations")]
        assert len(with_db) >= 15

    def test_db_tables_cover_domain(self):
        svc = next(n for n in self.nodes if n["type"] == "service" and n["category"] == "backend")
        endpoints = self.analysis[svc["id"]].get("endpoints", [])
        tables = set()
        for ep in endpoints:
            for op in ep.get("dbOperations", []):
                tables.add(op["table"])
        assert "users" in tables
        assert "projects" in tables
        assert "tasks" in tables
        assert "sessions" in tables
        assert "notifications" in tables
        assert "columns" in tables

    def test_has_login_required_guard(self):
        svc = next(n for n in self.nodes if n["type"] == "service" and n["category"] == "backend")
        rules = self.analysis[svc["id"]].get("rules", [])
        assert any(r["name"] == "login_required" and r["type"] == "guard" for r in rules)

    # --- Frontend analysis ---

    def test_pages_have_data_sources(self):
        pages = [n for n in self.nodes if n["type"] == "page"]
        pages_with_data = [n for n in pages if self.analysis[n["id"]].get("dataUsed")]
        assert len(pages_with_data) >= 4

    def test_api_modules_have_resolved_urls(self):
        """API wrapper modules should have resolved call-site URLs, not :path placeholders."""
        api_nodes = [n for n in self.nodes if n["type"] == "api"]
        for node in api_nodes:
            for ds in self.analysis[node["id"]].get("dataUsed", []):
                assert ":path" not in ds["source"], f"Unresolved :path in {node['id']}: {ds['source']}"

    # --- File tree ---

    def test_file_tree_has_monorepo_structure(self):
        top_names = {n["name"] for n in self.tree}
        assert "apps" in top_names or "packages" in top_names

    def test_file_tree_valid_structure(self):
        def validate(nodes):
            for n in nodes:
                assert "name" in n and "type" in n and "path" in n
                if n["type"] == "folder":
                    assert "children" in n
                    validate(n["children"])
        validate(self.tree)

    # --- Layout sanity ---

    def test_pages_above_backend(self):
        pages = [n for n in self.nodes if n["type"] == "page"]
        services = [n for n in self.nodes if n["type"] == "service" and n["category"] == "backend"]
        if pages and services:
            assert max(n["y"] for n in pages) < min(n["y"] for n in services)

    def test_database_at_bottom(self):
        db = [n for n in self.nodes if n["type"] == "database"]
        other = [n for n in self.nodes if n["type"] != "database"]
        if db and other:
            assert min(n["y"] for n in db) >= max(n["y"] for n in other)