from flask import Blueprint, request, jsonify

bp = Blueprint("users", __name__)


@bp.before_request
def require_auth():
    """All routes on this blueprint require authentication."""
    if not request.headers.get("Authorization"):
        return jsonify(error="Unauthorized"), 401


@bp.route("/", methods=["GET"])
def list_users():
    return jsonify(users=[])


@bp.route("/<user_id>", methods=["GET"])
def get_user(user_id):
    return jsonify(id=user_id, name="John")


@bp.route("/", methods=["POST"])
def create_user():
    name = request.json["name"]
    return jsonify(id=1, name=name)
