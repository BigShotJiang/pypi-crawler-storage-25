from flask import Flask
from .routes.users import users_bp
from .routes.items import items_bp

app = Flask(__name__)
app.register_blueprint(users_bp, url_prefix="/api/v1/users")
app.register_blueprint(items_bp, url_prefix="/api/v1/items")
