from flask import Blueprint, request, jsonify

items_bp = Blueprint("items", __name__)


@items_bp.get("/")
def list_items():
    return jsonify(items=[])


@items_bp.delete("/<item_id>")
def delete_item(item_id):
    return jsonify(status="deleted")
