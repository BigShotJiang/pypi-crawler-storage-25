from flask import Blueprint, request, jsonify

users_bp = Blueprint("users", __name__)


@users_bp.route("/", methods=["GET"])
def list_users():
    return jsonify(users=[])


@users_bp.route("/<user_id>", methods=["GET"])
def get_user(user_id):
    return jsonify(id=user_id, name="John")


@users_bp.route("/", methods=["POST"])
def create_user():
    name = request.json["name"]
    email = request.json["email"]
    return jsonify(id=1, name=name)
