import psycopg2
from flask import Flask, request, jsonify

app = Flask(__name__)
conn = psycopg2.connect("postgresql://localhost/mydb")


@app.route("/api/users", methods=["GET"])
def list_users():
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, email FROM users ORDER BY created_at DESC")
    rows = cursor.fetchall()
    return jsonify(users=rows)


@app.route("/api/users/<user_id>", methods=["GET"])
def get_user(user_id):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()
    return jsonify(user=user)


@app.route("/api/users", methods=["POST"])
def create_user():
    name = request.json["name"]
    email = request.json["email"]
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (name, email) VALUES (%s, %s) RETURNING id", (name, email))
    user_id = cursor.fetchone()[0]
    conn.commit()
    return jsonify(id=user_id)


@app.route("/api/orders", methods=["GET"])
def list_orders():
    cursor = conn.cursor()
    cursor.execute("""
        SELECT o.id, o.total, u.name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.status = 'active'
        ORDER BY o.created_at DESC
    """)
    return jsonify(orders=cursor.fetchall())


@app.route("/api/orders/<order_id>", methods=["DELETE"])
def cancel_order(order_id):
    cursor = conn.cursor()
    cursor.execute("UPDATE orders SET status = 'cancelled' WHERE id = %s", (order_id,))
    cursor.execute("DELETE FROM order_items WHERE order_id = %s", (order_id,))
    conn.commit()
    return jsonify(status="cancelled")
