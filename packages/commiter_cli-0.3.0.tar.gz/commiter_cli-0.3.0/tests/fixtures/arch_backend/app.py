from flask import Flask
from flask_cors import CORS
from routes.auth import auth_bp
from routes.users import users_bp
from routes.projects import projects_bp
from routes.analytics import analytics_bp
from middleware.rate_limit import rate_limit

app = Flask(__name__)
CORS(app, supports_credentials=True, origins=["https://myapp.vercel.app"])

@app.before_request
def log_request():
    pass

app.register_blueprint(auth_bp, url_prefix="/v1/auth")
app.register_blueprint(users_bp, url_prefix="/v1/users")
app.register_blueprint(projects_bp, url_prefix="/v1/projects")
app.register_blueprint(analytics_bp, url_prefix="/v1/analytics")

if __name__ == "__main__":
    app.run(port=5000)