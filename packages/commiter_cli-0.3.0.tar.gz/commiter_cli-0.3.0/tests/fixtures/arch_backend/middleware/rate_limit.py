def rate_limit(max_requests=60, window=60):
    def decorator(f):
        return f
    return decorator