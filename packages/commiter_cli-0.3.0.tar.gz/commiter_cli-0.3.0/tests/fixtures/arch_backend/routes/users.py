from flask import Blueprint, request, jsonify

users_bp = Blueprint("users", __name__)


@users_bp.route("/", methods=["GET"])
@login_required
def list_users():
    """List all users with pagination."""
    users = db.table("users").select("id, display_name, avatar_url").execute()
    return jsonify(users=users.data, total=len(users.data))


@users_bp.route("/<user_id>", methods=["GET"])
@login_required
def get_user(user_id):
    """Get a single user profile."""
    user = db.table("users").select("*").eq("id", user_id).single().execute()
    return jsonify(user=user.data)


@users_bp.route("/me", methods=["PUT"])
@login_required
def update_profile():
    """Update the authenticated user's profile."""
    display_name = request.json.get("display_name")
    bio = request.json.get("bio")
    avatar_url = request.json.get("avatar_url")
    user = db.table("users").update({
        "display_name": display_name,
        "bio": bio,
        "avatar_url": avatar_url,
    }).eq("id", request.user_id).execute()
    return jsonify(user=user.data[0])


@users_bp.route("/me/connections", methods=["GET"])
@login_required
def list_connections():
    """List the authenticated user's connections."""
    connections = db.table("connections").select("*").eq("user_id", request.user_id).execute()
    return jsonify(connections=connections.data)


@users_bp.route("/me/connections", methods=["POST"])
@login_required
def create_connection():
    """Send a connection request."""
    target_id = request.json["target_user_id"]
    conn = db.table("connections").insert({
        "user_id": request.user_id,
        "target_user_id": target_id,
        "status": "pending",
    }).execute()
    return jsonify(connection=conn.data[0])