from flask import Blueprint, request, jsonify

analytics_bp = Blueprint("analytics", __name__)


@analytics_bp.route("/commits", methods=["GET"])
@login_required
def get_commit_stats():
    """Get commit analysis for a project."""
    project_id = request.args.get("project_id")
    stats = db.table("commit_analysis").select("*").eq("project_id", project_id).execute()
    return jsonify(stats=stats.data)


@analytics_bp.route("/activity", methods=["GET"])
@login_required
def get_activity():
    """Get recent activity feed for the user."""
    activity = db.table("activity_log").select("*").eq("user_id", request.user_id).execute()
    return jsonify(activity=activity.data)