from flask import Blueprint, request, jsonify

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    """Exchange credentials for a JWT token."""
    email = request.json["email"]
    password = request.json["password"]
    user = db.table("users").select("*").eq("email", email).single().execute()
    session = db.table("sessions").insert({"user_id": user.data["id"]}).execute()
    return jsonify(access_token="jwt...", expires_in=3600)


@auth_bp.route("/refresh", methods=["POST"])
def refresh_token():
    """Refresh an expired access token using the refresh cookie."""
    session = db.table("sessions").select("*").eq("token", request.cookies.get("refresh")).single().execute()
    db.table("sessions").update({"refreshed_at": "now()"}).eq("id", session.data["id"]).execute()
    return jsonify(access_token="jwt...", expires_in=3600)


@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    """Invalidate the current session."""
    db.table("sessions").delete().eq("user_id", request.user_id).execute()
    return jsonify(success=True)