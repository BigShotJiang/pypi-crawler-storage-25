from flask import Blueprint, request, jsonify

projects_bp = Blueprint("projects", __name__)


@projects_bp.route("/", methods=["GET"])
@login_required
def list_projects():
    """List projects for the authenticated user."""
    projects = db.table("projects").select("*").eq("owner_id", request.user_id).execute()
    return jsonify(projects=projects.data)


@projects_bp.route("/", methods=["POST"])
@login_required
def create_project():
    """Create a new project."""
    name = request.json["name"]
    description = request.json.get("description", "")
    repo_url = request.json.get("repo_url")
    project = db.table("projects").insert({
        "name": name,
        "description": description,
        "repo_url": repo_url,
        "owner_id": request.user_id,
    }).execute()
    return jsonify(project=project.data[0])


@projects_bp.route("/<project_id>", methods=["GET"])
@login_required
def get_project(project_id):
    """Get a single project with its milestones."""
    project = db.table("projects").select("*").eq("id", project_id).single().execute()
    milestones = db.table("milestones").select("*").eq("project_id", project_id).execute()
    return jsonify(project=project.data, milestones=milestones.data)


@projects_bp.route("/<project_id>", methods=["DELETE"])
@login_required
def delete_project(project_id):
    """Delete a project and its milestones."""
    db.table("milestones").delete().eq("project_id", project_id).execute()
    db.table("projects").delete().eq("id", project_id).execute()
    return jsonify(success=True)


@projects_bp.route("/<project_id>/milestones", methods=["POST"])
@login_required
def create_milestone(project_id):
    """Add a milestone to a project."""
    title = request.json["title"]
    due_date = request.json.get("due_date")
    milestone = db.table("milestones").insert({
        "project_id": project_id,
        "title": title,
        "due_date": due_date,
        "status": "open",
    }).execute()
    return jsonify(milestone=milestone.data[0])