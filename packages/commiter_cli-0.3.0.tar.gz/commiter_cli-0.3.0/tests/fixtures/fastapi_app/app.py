from fastapi import FastAPI, Depends
from pydantic import BaseModel
from typing import Optional

app = FastAPI()


class ItemCreate(BaseModel):
    name: str
    price: float
    description: Optional[str] = None
    category: str


class ItemResponse(BaseModel):
    id: int
    name: str
    price: float


class UserCreate(BaseModel):
    email: str
    password: str
    display_name: str


def get_current_user():
    pass


@app.post("/api/items")
def create_item(item: ItemCreate):
    return {"id": 1, "name": item.name, "price": item.price}


@app.get("/api/items/{item_id}")
def get_item(item_id: int):
    return {"id": item_id, "name": "Test", "price": 9.99}


@app.post("/api/users", response_model=UserCreate)
def create_user(user: UserCreate, current_user=Depends(get_current_user)):
    return user


@app.delete("/api/items/{item_id}")
def delete_item(item_id: int, current_user=Depends(get_current_user)):
    return {"status": "deleted"}
