from flask import Flask, jsonify

app = Flask(__name__)


@app.route("/api/reports", methods=["GET"])
def list_reports():
    reports = db.table("reports").select("*").execute()
    return jsonify(data=reports.data)


@app.route("/api/user-stats/<user_id>", methods=["GET"])
def user_stats(user_id):
    # This service also reads from the 'users' table — shared with flask_app
    user = db.table("users").select("name, email").eq("id", user_id).execute()
    stats = db.table("reports").select("*").eq("user_id", user_id).execute()
    return jsonify(user=user.data[0], report_count=len(stats.data))
