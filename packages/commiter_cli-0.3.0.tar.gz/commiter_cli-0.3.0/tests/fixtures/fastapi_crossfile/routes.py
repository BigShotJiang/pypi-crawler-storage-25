from fastapi import FastAPI, Depends
from .schemas import UserCreate, UserResponse, ItemCreate

app = FastAPI()


def get_current_user():
    pass


@app.post("/api/users")
def create_user(user: UserCreate):
    return {"id": 1, "email": user.email}


@app.post("/api/items")
def create_item(item: ItemCreate, current_user=Depends(get_current_user)):
    return {"id": 1, "name": item.name}
