from functools import wraps
from flask import request, jsonify

def rate_limit(max_requests=60, window=60):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            return f(*args, **kwargs)
        return decorated
    return decorator