from flask import Blueprint, request, jsonify

tasks_bp = Blueprint("tasks", __name__)


@tasks_bp.route("/", methods=["GET"])
@login_required
def list_tasks():
    project_id = request.args.get("project_id")
    column_id = request.args.get("column_id")
    query = db.table("tasks").select("*, assignee:users(display_name, avatar_url)")
    if project_id:
        query = query.eq("project_id", project_id)
    if column_id:
        query = query.eq("column_id", column_id)
    tasks = query.order("position").execute()
    return jsonify(tasks=tasks.data)


@tasks_bp.route("/", methods=["POST"])
@login_required
def create_task():
    title = request.json["title"]
    description = request.json.get("description", "")
    project_id = request.json["project_id"]
    column_id = request.json["column_id"]
    assignee_id = request.json.get("assignee_id")
    priority = request.json.get("priority", "medium")
    due_date = request.json.get("due_date")
    task = db.table("tasks").insert({
        "title": title,
        "description": description,
        "project_id": project_id,
        "column_id": column_id,
        "assignee_id": assignee_id,
        "priority": priority,
        "due_date": due_date,
        "creator_id": request.user_id,
    }).execute()
    # Notify assignee
    if assignee_id and assignee_id != request.user_id:
        db.table("notifications").insert({
            "user_id": assignee_id,
            "type": "task_assigned",
            "data": {"task_id": task.data[0]["id"], "assigned_by": request.user_id},
        }).execute()
    return jsonify(task=task.data[0])


@tasks_bp.route("/<task_id>", methods=["PUT"])
@login_required
def update_task(task_id):
    allowed = ("title", "description", "column_id", "assignee_id", "priority", "due_date", "position", "completed")
    updates = {k: v for k, v in request.json.items() if k in allowed}
    task = db.table("tasks").update(updates).eq("id", task_id).execute()
    # Log activity
    db.table("activity_log").insert({
        "user_id": request.user_id,
        "action": "task_updated",
        "entity_type": "task",
        "entity_id": task_id,
        "changes": updates,
    }).execute()
    return jsonify(task=task.data[0])


@tasks_bp.route("/<task_id>", methods=["DELETE"])
@login_required
def delete_task(task_id):
    db.table("comments").delete().eq("task_id", task_id).execute()
    db.table("tasks").delete().eq("id", task_id).execute()
    return jsonify(success=True)


@tasks_bp.route("/<task_id>/comments", methods=["GET"])
@login_required
def list_comments(task_id):
    comments = db.table("comments").select("*, author:users(display_name, avatar_url)").eq("task_id", task_id).order("created_at").execute()
    return jsonify(comments=comments.data)


@tasks_bp.route("/<task_id>/comments", methods=["POST"])
@login_required
def create_comment(task_id):
    body = request.json["body"]
    comment = db.table("comments").insert({
        "task_id": task_id,
        "author_id": request.user_id,
        "body": body,
    }).execute()
    return jsonify(comment=comment.data[0])