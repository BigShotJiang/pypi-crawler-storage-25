"""Email notification service — sends via Celery background tasks."""


def send_invite_email(email, workspace_name, invited_by_name):
    """Queue an invite email for async delivery."""
    pass


def send_task_notification(user_email, task_title, action):
    """Queue a task notification email."""
    pass