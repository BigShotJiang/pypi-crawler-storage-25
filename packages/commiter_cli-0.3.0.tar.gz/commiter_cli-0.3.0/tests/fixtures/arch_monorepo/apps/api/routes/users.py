from flask import Blueprint, request, jsonify

users_bp = Blueprint("users", __name__)


@users_bp.route("/me", methods=["GET"])
@login_required
def get_profile():
    user = db.table("users").select("*").eq("id", request.user_id).single().execute()
    return jsonify(user=user.data)


@users_bp.route("/me", methods=["PUT"])
@login_required
def update_profile():
    display_name = request.json.get("display_name")
    bio = request.json.get("bio")
    avatar_url = request.json.get("avatar_url")
    user = db.table("users").update({
        "display_name": display_name,
        "bio": bio,
        "avatar_url": avatar_url,
    }).eq("id", request.user_id).execute()
    return jsonify(user=user.data[0])


@users_bp.route("/me/avatar", methods=["POST"])
@login_required
def upload_avatar():
    file = request.files["avatar"]
    url = storage.upload(f"avatars/{request.user_id}", file)
    db.table("users").update({"avatar_url": url}).eq("id", request.user_id).execute()
    return jsonify(avatar_url=url)


@users_bp.route("/<user_id>", methods=["GET"])
@login_required
def get_user(user_id):
    user = db.table("users").select("id, display_name, bio, avatar_url").eq("id", user_id).single().execute()
    return jsonify(user=user.data)


@users_bp.route("/search", methods=["GET"])
@login_required
def search_users():
    query = request.args.get("q", "")
    users = db.table("users").select("id, display_name, avatar_url").ilike("display_name", f"%{query}%").execute()
    return jsonify(users=users.data)