from flask import Flask
from flask_cors import CORS
from routes.auth import auth_bp
from routes.users import users_bp
from routes.projects import projects_bp
from routes.tasks import tasks_bp
from routes.notifications import notifications_bp
from routes.invites import invites_bp
from middleware.auth import require_auth
from middleware.rate_limit import rate_limit

app = Flask(__name__)
CORS(app, supports_credentials=True, origins=[
    "https://teamboard.dev",
    "http://localhost:3000",
])

@app.before_request
def log_request():
    pass

app.register_blueprint(auth_bp, url_prefix="/v1/auth")
app.register_blueprint(users_bp, url_prefix="/v1/users")
app.register_blueprint(projects_bp, url_prefix="/v1/projects")
app.register_blueprint(tasks_bp, url_prefix="/v1/tasks")
app.register_blueprint(notifications_bp, url_prefix="/v1/notifications")
app.register_blueprint(invites_bp, url_prefix="/v1/invites")

if __name__ == "__main__":
    app.run(port=5000)