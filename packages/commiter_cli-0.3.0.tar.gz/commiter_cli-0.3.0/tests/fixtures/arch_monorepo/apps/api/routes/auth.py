from flask import Blueprint, request, jsonify

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    email = request.json["email"]
    password = request.json["password"]
    user = db.table("users").select("*").eq("email", email).single().execute()
    session = db.table("sessions").insert({
        "user_id": user.data["id"],
        "ip_address": request.remote_addr,
    }).execute()
    return jsonify(access_token="jwt...", refresh_token="rt...", expires_in=3600)


@auth_bp.route("/refresh", methods=["POST"])
def refresh_token():
    refresh = request.cookies.get("refresh_token")
    session = db.table("sessions").select("*").eq("refresh_token", refresh).single().execute()
    db.table("sessions").update({"refreshed_at": "now()"}).eq("id", session.data["id"]).execute()
    return jsonify(access_token="jwt...", expires_in=3600)


@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    db.table("sessions").delete().eq("user_id", request.user_id).execute()
    return jsonify(success=True)


@auth_bp.route("/signup", methods=["POST"])
def signup():
    email = request.json["email"]
    password = request.json["password"]
    display_name = request.json["display_name"]
    user = db.table("users").insert({
        "email": email,
        "display_name": display_name,
    }).execute()
    db.table("workspaces").insert({
        "name": f"{display_name}'s Workspace",
        "owner_id": user.data[0]["id"],
    }).execute()
    return jsonify(user=user.data[0], access_token="jwt...")