from flask import Blueprint, request, jsonify

invites_bp = Blueprint("invites", __name__)


@invites_bp.route("/", methods=["POST"])
@login_required
def create_invite():
    email = request.json["email"]
    workspace_id = request.json["workspace_id"]
    invite = db.table("invites").insert({
        "email": email,
        "workspace_id": workspace_id,
        "invited_by": request.user_id,
        "status": "pending",
    }).execute()
    return jsonify(invite=invite.data[0])


@invites_bp.route("/<invite_id>/accept", methods=["POST"])
@login_required
def accept_invite(invite_id):
    invite = db.table("invites").select("*").eq("id", invite_id).single().execute()
    db.table("invites").update({"status": "accepted"}).eq("id", invite_id).execute()
    db.table("workspace_members").insert({
        "workspace_id": invite.data["workspace_id"],
        "user_id": request.user_id,
        "role": "member",
    }).execute()
    return jsonify(success=True)