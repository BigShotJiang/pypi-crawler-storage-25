from flask import Blueprint, request, jsonify

notifications_bp = Blueprint("notifications", __name__)


@notifications_bp.route("/", methods=["GET"])
@login_required
def list_notifications():
    notifications = db.table("notifications").select("*").eq("user_id", request.user_id).order("created_at", desc=True).limit(50).execute()
    return jsonify(notifications=notifications.data)


@notifications_bp.route("/read", methods=["POST"])
@login_required
def mark_read():
    notification_ids = request.json["ids"]
    db.table("notifications").update({"read": True}).in_("id", notification_ids).execute()
    return jsonify(success=True)


@notifications_bp.route("/unread-count", methods=["GET"])
@login_required
def unread_count():
    result = db.table("notifications").select("id", count="exact").eq("user_id", request.user_id).eq("read", False).execute()
    return jsonify(count=result.count)