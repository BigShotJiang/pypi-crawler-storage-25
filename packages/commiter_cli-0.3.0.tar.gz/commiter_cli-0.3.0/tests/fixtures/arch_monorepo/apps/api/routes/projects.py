from flask import Blueprint, request, jsonify

projects_bp = Blueprint("projects", __name__)


@projects_bp.route("/", methods=["GET"])
@login_required
def list_projects():
    workspace_id = request.args.get("workspace_id")
    projects = db.table("projects").select("*").eq("workspace_id", workspace_id).execute()
    return jsonify(projects=projects.data)


@projects_bp.route("/", methods=["POST"])
@login_required
def create_project():
    name = request.json["name"]
    description = request.json.get("description", "")
    workspace_id = request.json["workspace_id"]
    color = request.json.get("color", "#3b82f6")
    project = db.table("projects").insert({
        "name": name,
        "description": description,
        "workspace_id": workspace_id,
        "color": color,
        "owner_id": request.user_id,
    }).execute()
    # Create default columns for kanban
    for col_name in ["To Do", "In Progress", "Done"]:
        db.table("columns").insert({
            "project_id": project.data[0]["id"],
            "name": col_name,
        }).execute()
    return jsonify(project=project.data[0])


@projects_bp.route("/<project_id>", methods=["GET"])
@login_required
def get_project(project_id):
    project = db.table("projects").select("*").eq("id", project_id).single().execute()
    members = db.table("project_members").select("*, users(display_name, avatar_url)").eq("project_id", project_id).execute()
    columns = db.table("columns").select("*").eq("project_id", project_id).order("position").execute()
    return jsonify(project=project.data, members=members.data, columns=columns.data)


@projects_bp.route("/<project_id>", methods=["PUT"])
@login_required
def update_project(project_id):
    updates = {k: v for k, v in request.json.items() if k in ("name", "description", "color", "archived")}
    project = db.table("projects").update(updates).eq("id", project_id).execute()
    return jsonify(project=project.data[0])


@projects_bp.route("/<project_id>", methods=["DELETE"])
@login_required
def delete_project(project_id):
    db.table("tasks").delete().eq("project_id", project_id).execute()
    db.table("columns").delete().eq("project_id", project_id).execute()
    db.table("project_members").delete().eq("project_id", project_id).execute()
    db.table("projects").delete().eq("id", project_id).execute()
    return jsonify(success=True)


@projects_bp.route("/<project_id>/members", methods=["POST"])
@login_required
def add_member(project_id):
    user_id = request.json["user_id"]
    role = request.json.get("role", "member")
    member = db.table("project_members").insert({
        "project_id": project_id,
        "user_id": user_id,
        "role": role,
    }).execute()
    # Send notification to the invited user
    db.table("notifications").insert({
        "user_id": user_id,
        "type": "project_invite",
        "data": {"project_id": project_id, "invited_by": request.user_id},
    }).execute()
    return jsonify(member=member.data[0])