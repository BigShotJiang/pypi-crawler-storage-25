from pydantic import BaseModel
from typing import Optional


class UserCreate(BaseModel):
    email: str
    password: str
    display_name: str


class UserResponse(BaseModel):
    id: int
    email: str
    display_name: str
    is_active: bool = True
