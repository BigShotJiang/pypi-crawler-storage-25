from fastapi import APIRouter

# One level up: from app/api/ -> app/shared/models.py (../shared.models)
from ..shared.models import PaginationParams

router = APIRouter()


@router.get("/health")
def health_check():
    return {"status": "ok"}
