from fastapi import APIRouter

# Two levels up to schemas
from ...schemas.item import ItemCreate, ItemUpdate

router = APIRouter()


@router.post("/items")
def create_item(item: ItemCreate):
    result = db.table("items").insert({"name": item.name, "price": item.price}).execute()
    return {"id": 1, "name": item.name}


@router.put("/items/{item_id}")
def update_item(item_id: int, item: ItemUpdate):
    db.table("items").update({"name": item.name}).eq("id", item_id).execute()
    return {"status": "updated"}
