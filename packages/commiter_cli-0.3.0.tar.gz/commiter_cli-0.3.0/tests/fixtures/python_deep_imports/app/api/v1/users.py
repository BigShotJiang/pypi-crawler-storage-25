from fastapi import APIRouter, Depends

# Two levels up: from app/api/v1/ -> app/schemas/user.py (../../schemas.user)
from ...schemas.user import UserCreate, UserResponse

# Three levels relative: from app/api/v1/ -> app/shared/models.py (../../shared.models)
from ...shared.models import PaginationParams

router = APIRouter()


@router.get("/users")
def list_users(pagination: PaginationParams):
    users = db.table("users").select("*").execute()
    return {"users": users.data, "page": pagination.page}


@router.post("/users")
def create_user(user: UserCreate):
    result = db.table("users").insert({"email": user.email}).execute()
    return {"id": result.data[0]["id"], "email": user.email}


@router.get("/users/{user_id}")
def get_user(user_id: int):
    user = db.table("users").select("*").eq("id", user_id).execute()
    return {"user": user.data[0]}
