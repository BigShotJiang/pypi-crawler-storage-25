from flask import Flask, request, jsonify

app = Flask(__name__)


@app.route("/api/users", methods=["GET"])
@login_required
def list_users():
    users = db.table("users").select("*").execute()
    return jsonify(data=users.data, count=len(users.data))


@app.route("/api/users/<user_id>", methods=["GET"])
@login_required
def get_user(user_id):
    user = db.table("users").select("*").eq("id", user_id).execute()
    return jsonify(data=user.data[0])


@app.route("/api/users", methods=["POST"])
def create_user():
    name = request.json["name"]
    email = request.json["email"]
    password = request.json["password"]
    user = db.table("users").insert({"name": name, "email": email}).execute()
    return jsonify(id=user.data[0]["id"], status="created")


@app.route("/api/items/<item_id>", methods=["DELETE"])
@login_required
def delete_item(item_id):
    db.table("items").delete().eq("id", item_id).execute()
    return jsonify(status="deleted")
