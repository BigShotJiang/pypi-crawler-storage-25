from dotenv import load_dotenv

load_dotenv()

from closepoo import telechat

def main ():
  telechat.run_chat()

if __name__ == '__main__':
  main()
