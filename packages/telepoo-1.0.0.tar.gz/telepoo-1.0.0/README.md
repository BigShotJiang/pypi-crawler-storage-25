# CLOSEPOO TELEGRAM BOT

Detailed tips, tricks, and examples, can be found at project's repository
https://github.com/asinerum/telepoo

"We don't use OpenClaw, because we have ClosePoo, a simple-as-poo AI Agent that makes your time easy and controllable"

## Installation
```bash
pip install telepoo
```

## Start Bot
```bash
export GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
export TELEGRAM_BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"
export TELEGRAM_AUTH_USER_LIST=[YOUR_TELEGRAM_AUTH_USER_LIST]
telepoo
```

(C) 2026 Asinerum Conlang Project