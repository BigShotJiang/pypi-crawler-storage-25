"""Source adapters for ingestion."""
