"""Ingestion pipeline package."""
