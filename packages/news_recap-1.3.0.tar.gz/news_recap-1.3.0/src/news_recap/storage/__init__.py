"""File-based storage utilities."""
