# Repository Guidelines

## Project Structure & Module Organization
- `src/news_recap/`: main package code. CLI entrypoint is `main.py`; package version lives in `__about__.py`.
- `src/news_recap/automation.py`: cross-platform scheduled automation (`schedule set/get/delete` CLI commands).
- `src/news_recap/scripts/`: runner script templates (shell/PowerShell) loaded by automation module.
- `src/news_recap/storage/`: file-based storage utilities (`io.py` — atomic writes, GC, msgspec helpers).
- `src/news_recap/ingestion/`: ingestion pipeline and `IngestionStore` (daily-partitioned article storage).
- `src/news_recap/recap/`: recap pipeline (ThreadPoolExecutor-based parallel LLM agent orchestration).
  - `tasks/`: pipeline step implementations and prompt templates.
  - `agents/`: LLM agent execution, subprocess runner, routing, mock agents.
  - `storage/`: workdir materialization, pipeline I/O, output schemas.
  - `loaders/`: resource loading (HTTP fetch + text extraction).
- `tests/`: pytest test suite (including CLI checks).
- `docs/`: MkDocs content, with language folders under `docs/src/en/` and `docs/src/ru/`.
- `scripts/`: helper scripts for docs, version bumps, packaging, and uploads.
- `tasks.py`: Invoke task definitions (`pre`, `ver-release`, `docs-en`, etc.).

Data directory defaults to `~/.news_recap_data/` (configurable via `NEWS_RECAP_DATA_DIR`). Pipeline workdirs live under `~/.news_recap_data/workdir/`.

## CLI Commands
- `news-recap ingest --rss URL`: run one ingestion cycle from RSS feeds.
- `news-recap create --agent claude`: create a news digest from recent articles.
- `news-recap list`: show completed digests.
- `news-recap delete DIGEST_ID`: delete a digest so its articles become available for the next one.
- `news-recap serve [DIGEST_ID]`: start the digest web viewer.
- `news-recap prompt`: export a ready-to-paste LLM prompt.
- `news-recap schedule set --rss URL`: install daily scheduled automation (launchd / systemd / Task Scheduler).
- `news-recap schedule get`: show current schedule configuration.
- `news-recap schedule delete`: remove daily scheduled automation.

## Build, Test, and Development Commands
- `./activate.sh`: activate the local development environment used by this repo.
- `uv sync --frozen`: install locked dependencies from `uv.lock`.
- `uv run pytest --cov=src tests/`: run tests with coverage (mirrors CI intent).
- `pre-commit run --verbose --all-files`: run lint/format/type checks locally.
- `invoke pre`: shortcut to run pre-commit checks.
- `invoke --list`: list available invoke tasks.
- `./scripts/build-docs.sh`: build documentation site for configured languages.
- `./scripts/build-docs.sh --copy-assets en` then `mkdocs serve -f docs/_mkdocs.yml`: local docs preview flow.

## Coding Style & Naming Conventions
- Python 3.13+ with 4-space indentation and explicit, readable names.
- Naming: `snake_case` for modules/functions/variables, `UPPER_CASE` for constants, `CapWords` for classes.
- Use `msgspec.Struct` for domain models (immutable data); `dataclasses` only for mutable counters.
- Type hints for public functions and CLI-related logic where practical.
- Formatting and linting are enforced through pre-commit with Ruff; run hooks before pushing.
- Keep line length formatter-friendly (Ruff hooks are configured for ~100 chars).

## Testing Guidelines
- Framework: `pytest` (with `click.testing` for CLI behavior tests).
- Test files: `test_*.py`; test functions: `test_*`.
- `pytest.ini` enables doctests (`--doctest-modules`), so doc examples must remain executable.
- CI publishes coverage reports/comments; target at least 85% total coverage to stay in the green band.

## Commit & Pull Request Guidelines
- Keep commit messages short and imperative, consistent with existing history (for example, `pre-commit`, `Version v0.0.1`).
- Prefer one logical change per commit.
- PRs should include: purpose, summary of changes, test commands run, and linked issue(s) when applicable.
- Update docs (`README.md` and `docs/`) in the same PR when behavior or CLI usage changes.
