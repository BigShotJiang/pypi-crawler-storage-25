# Contributing

Thanks for thinking about contributing! This is a small alpha project and contributions are genuinely welcome — bug reports, dashboard polish, rubric tweaks, support for new tools (Codex CLI etc.), and roadmap suggestions are all on the table.

## Quick start

```bash
git clone https://github.com/NuoWenLei/eng-trajectory-analyzer
cd eng-trajectory-analyzer
python -m venv .venv
source .venv/bin/activate         # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
pytest                            # 88 tests, ~2s
```

The test suite runs fully offline — the Anthropic client is mocked in `tests/conftest.py`, so you don't need an API key to develop.

## What's helpful

- **Bug reports** with a minimal repro (the JSONL session file or a stripped-down version) are gold.
- **Rubric improvements** — anchors that misfire, dimensions that are too noisy, domain categories that don't fit. The rubric lives at `src/dev_trajectory/rubric/v1.yaml`. If you change scoring behavior, bump the version (`v2.yaml`) so existing scores aren't silently invalidated.
- **New tool support** behind the same `discover.py` / `parse.py` interface — Codex CLI is the obvious next one (see [docs/ROADMAP.md](docs/ROADMAP.md)).
- **Dashboard polish** — chart types, filter UX, evidence rendering.
- **Honest critique of the methodology.** The whole project is balanced on subjective LLM scoring; if you spot a hole in the approach, an issue is the right place.

## Pull requests

Keep PRs focused — one logical change per PR. A good PR includes:

- A short description of the *why* (the *what* should be readable from the diff).
- Tests that fail before the change and pass after, when applicable.
- A note in `CHANGELOG.md` under `[Unreleased]` if the change is user-visible.

## Two tests to leave alone

These are load-bearing and protect properties that aren't otherwise enforced:

- `tests/test_sampling.py::test_sampling_is_deterministic_across_input_order` — if this breaks, `analyze` stops being idempotent and re-runs cost real money.
- `tests/test_rubric.py::test_rubric_rendering_is_deterministic` — if this breaks, prompt caching collapses and the cost story breaks with it.

If you're refactoring near sampling or rubric rendering, please make sure both still pass.

## Asking questions

Open a GitHub issue. For roadmap input, see [docs/ROADMAP.md](docs/ROADMAP.md) — issues that propose changes to it are welcome.

## Code style

No formatter is enforced yet (alpha). Match the surrounding style. The codebase favors:

- Type hints on public functions.
- `from __future__ import annotations` at the top of every module.
- Comments that explain *why*, not *what*. Most code doesn't need any.
- Errors raised at the storage / API boundary, not papered over with fallbacks.
