"""Config: TOML round-trip and env-var precedence for the API key."""
from __future__ import annotations

from pathlib import Path

import pytest

from dev_trajectory.config import Config, load_config, resolve_api_key, save_config


@pytest.fixture
def isolated_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    config_dir = tmp_path / ".config" / "dev-trajectory"
    monkeypatch.setattr("dev_trajectory.config.config_dir", lambda: config_dir)
    monkeypatch.setattr("dev_trajectory.config.config_path", lambda: config_dir / "config.toml")
    return config_dir / "config.toml"


def test_round_trip_through_toml(isolated_config: Path):
    cfg = Config(
        api_key="sk-ant-abc",
        rubric_version="v1",
        min_confidence=0.6,
        tool_output_token_limit=1500,
        sessions_per_week=5,
        telemetry_enabled=True,
        custom_session_paths=["/some/path", "/another"],
    )
    save_config(cfg)
    loaded = load_config()

    assert loaded.api_key == "sk-ant-abc"
    assert loaded.rubric_version == "v1"
    assert loaded.min_confidence == 0.6
    assert loaded.tool_output_token_limit == 1500
    assert loaded.sessions_per_week == 5
    assert loaded.telemetry_enabled is True
    assert loaded.custom_session_paths == ["/some/path", "/another"]


def test_load_config_returns_defaults_when_file_missing(isolated_config: Path):
    cfg = load_config()
    assert cfg.api_key is None
    assert cfg.sessions_per_week == 3
    assert cfg.telemetry_enabled is False


def test_resolve_api_key_prefers_env_var(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "from-env")
    cfg = Config(api_key="from-config")
    assert resolve_api_key(cfg) == "from-env"


def test_resolve_api_key_falls_back_to_config(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    cfg = Config(api_key="from-config")
    assert resolve_api_key(cfg) == "from-config"


def test_resolve_api_key_returns_none_when_neither_set(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    cfg = Config(api_key=None)
    assert resolve_api_key(cfg) is None


def test_string_with_quotes_round_trips(isolated_config: Path):
    """Make sure the simple TOML serializer handles quotes and backslashes."""
    cfg = Config(api_key='value "with" quotes\\and\\backslashes')
    save_config(cfg)
    loaded = load_config()
    assert loaded.api_key == 'value "with" quotes\\and\\backslashes'
