"""Discovery: walking ~/.claude/projects/, stable session ID, fail-soft on bad files."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from dev_trajectory.discover import discover_claude_code_sessions, stable_session_id


def test_walks_nested_jsonl_files(claude_session_root: Path):
    (claude_session_root / "proj-a").mkdir()
    (claude_session_root / "proj-b").mkdir()
    _write_jsonl(claude_session_root / "proj-a" / "s1.jsonl", "u1", "2026-04-01T12:00:00Z")
    _write_jsonl(claude_session_root / "proj-b" / "s2.jsonl", "u2", "2026-04-02T09:00:00Z")

    found = list(discover_claude_code_sessions())
    assert {p.file_path.name for p in found} == {"s1.jsonl", "s2.jsonl"}


def test_session_id_is_stable_for_same_file_and_uuid():
    p = Path("/tmp/foo/abc.jsonl")
    a = stable_session_id(p, "uuid-1")
    b = stable_session_id(p, "uuid-1")
    assert a == b


def test_session_id_changes_with_path_or_uuid():
    p = Path("/tmp/foo/abc.jsonl")
    base = stable_session_id(p, "uuid-1")
    assert stable_session_id(p, "uuid-2") != base
    assert stable_session_id(Path("/tmp/foo/def.jsonl"), "uuid-1") != base


def test_skips_files_with_no_parseable_records(claude_session_root: Path):
    (claude_session_root / "proj").mkdir()
    bad = claude_session_root / "proj" / "broken.jsonl"
    bad.write_text("not json\nstill not json\n", encoding="utf-8")

    found = list(discover_claude_code_sessions())
    assert found == []


def test_skips_records_missing_timestamp_then_takes_first_valid(claude_session_root: Path):
    (claude_session_root / "proj").mkdir()
    path = claude_session_root / "proj" / "s.jsonl"
    path.write_text(
        # First record has no uuid/timestamp — must be skipped, not error.
        json.dumps({"type": "summary", "content": "old"}) + "\n"
        + json.dumps({"uuid": "u1", "timestamp": "2026-04-01T12:00:00Z", "type": "user"}) + "\n",
        encoding="utf-8",
    )
    found = list(discover_claude_code_sessions())
    assert len(found) == 1
    assert found[0].first_message_uuid == "u1"
    assert found[0].anchor_ts == datetime(2026, 4, 1, 12, 0, 0, tzinfo=timezone.utc)


def test_returns_empty_when_root_missing(tmp_path: Path, monkeypatch):
    missing = tmp_path / "nope" / "projects"
    monkeypatch.setattr("dev_trajectory.discover.CLAUDE_CODE_DIR", missing)
    assert list(discover_claude_code_sessions()) == []


def _write_jsonl(path: Path, uuid: str, timestamp: str) -> None:
    path.write_text(
        json.dumps({"uuid": uuid, "timestamp": timestamp, "type": "user", "message": {"role": "user", "content": "hi"}}) + "\n",
        encoding="utf-8",
    )
