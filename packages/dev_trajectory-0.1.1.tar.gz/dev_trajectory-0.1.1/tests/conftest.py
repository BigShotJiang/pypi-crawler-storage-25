"""Shared fixtures and test helpers.

The fakes here mirror just enough of the Anthropic SDK shape that the
pipeline's call sites work without a network. If the SDK shape ever drifts
under us, these fakes will break loud — that's the point.
"""
from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Sequence

import pytest

from dev_trajectory.discover import DiscoveredSession
from dev_trajectory.models import Score


def make_score(**overrides: Any) -> Score:
    """Build a valid Score with sensible defaults and per-test overrides."""
    base: dict[str, Any] = dict(
        problem_decomposition=3,
        systems_thinking=3,
        debugging_methodology=3,
        technical_communication=3,
        model_redirection=3,
        domain_category="backend",
        domain_detail=None,
        language="python",
        mode="debugging",
        confidence=0.8,
        evidence_quotes=["q"],
        seniority_band="senior",
        inferred_ic_level="IC4",
    )
    base.update(overrides)
    return Score(**base)


def make_discovered_session(
    *,
    sid: str,
    anchor_ts: datetime,
    file_path: Path | None = None,
    tool: str = "claude_code",
    first_message_uuid: str = "u",
) -> DiscoveredSession:
    return DiscoveredSession(
        id=sid,
        file_path=file_path or Path(f"/tmp/{sid}.jsonl"),
        tool=tool,
        anchor_ts=anchor_ts,
        first_message_uuid=first_message_uuid,
    )


def write_claude_code_session(path: Path, records: Sequence[dict[str, Any]]) -> Path:
    """Write a list of record dicts as JSONL to `path`. Returns the path."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(json.dumps(r) for r in records) + "\n", encoding="utf-8")
    return path


def make_record(
    *,
    uuid: str,
    role: str,
    text_or_blocks: str | list[dict[str, Any]],
    timestamp: datetime | None = None,
) -> dict[str, Any]:
    ts = (timestamp or datetime(2026, 4, 1, 12, 0, 0, tzinfo=timezone.utc)).isoformat().replace("+00:00", "Z")
    return {
        "uuid": uuid,
        "timestamp": ts,
        "type": role,
        "message": {"role": role, "content": text_or_blocks},
    }


# --- Anthropic SDK fakes -----------------------------------------------------


@dataclass
class FakeStage1Block:
    text: str
    type: str = "text"


@dataclass
class FakeStage1Response:
    content: list[FakeStage1Block]


@dataclass
class FakeStage2Response:
    parsed_output: Score


class FakeMessages:
    """Minimal stand-in for `client.messages` exposing `.create` and `.parse`.

    Thread-safe: counters and the score-cycling index are guarded by a lock so
    parallel pipeline tests get accurate counts.
    """

    def __init__(self, *, summary_text: str = "stub summary", scores: list[Score] | None = None) -> None:
        self._summary_text = summary_text
        self._scores = scores or []
        self._score_idx = 0
        self._lock = threading.Lock()
        self.create_calls = 0
        self.parse_calls = 0
        self.last_create_kwargs: dict[str, Any] | None = None
        self.last_parse_kwargs: dict[str, Any] | None = None

    def create(self, **kwargs: Any) -> FakeStage1Response:
        with self._lock:
            self.create_calls += 1
            self.last_create_kwargs = kwargs
        return FakeStage1Response(content=[FakeStage1Block(text=self._summary_text)])

    def parse(self, **kwargs: Any) -> FakeStage2Response:
        with self._lock:
            self.parse_calls += 1
            self.last_parse_kwargs = kwargs
            if not self._scores:
                score = make_score()
            else:
                score = self._scores[self._score_idx % len(self._scores)]
                self._score_idx += 1
        return FakeStage2Response(parsed_output=score)


class FakeClient:
    def __init__(self, *, summary_text: str = "stub summary", scores: list[Score] | None = None) -> None:
        self.messages = FakeMessages(summary_text=summary_text, scores=scores)


@pytest.fixture
def claude_session_root(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Provide an isolated Claude Code session root and patch discovery to use it."""
    root = tmp_path / ".claude" / "projects"
    root.mkdir(parents=True)
    monkeypatch.setattr("dev_trajectory.discover.CLAUDE_CODE_DIR", root)
    return root


@pytest.fixture
def fake_client() -> FakeClient:
    return FakeClient()


def utc(year: int, month: int, day: int, hour: int = 12) -> datetime:
    return datetime(year, month, day, hour, 0, 0, tzinfo=timezone.utc)


def days(n: int) -> timedelta:
    return timedelta(days=n)
