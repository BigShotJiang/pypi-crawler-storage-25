"""Score schema validation — closed enums and nullable language."""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from dev_trajectory.models import Score
from tests.conftest import make_score


def test_round_trip_through_json():
    s = make_score()
    data = s.model_dump_json()
    again = Score.model_validate_json(data)
    assert again == s


def test_rejects_out_of_range_dimension_score():
    with pytest.raises(ValidationError):
        make_score(problem_decomposition=6)
    with pytest.raises(ValidationError):
        make_score(problem_decomposition=0)


def test_rejects_unknown_domain_category():
    with pytest.raises(ValidationError):
        make_score(domain_category="cybernetics")


def test_rejects_unknown_language():
    with pytest.raises(ValidationError):
        make_score(language="haskell")


def test_language_can_be_null():
    s = make_score(language=None)
    assert s.language is None


def test_rejects_unknown_seniority_band():
    with pytest.raises(ValidationError):
        make_score(seniority_band="distinguished")


def test_rejects_confidence_outside_unit_interval():
    with pytest.raises(ValidationError):
        make_score(confidence=1.5)
    with pytest.raises(ValidationError):
        make_score(confidence=-0.1)


def test_extra_fields_are_forbidden():
    with pytest.raises(ValidationError):
        Score(
            **make_score().model_dump(),
            extra_field="should not be allowed",
        )


def test_evidence_quotes_must_be_a_list_of_strings():
    with pytest.raises(ValidationError):
        make_score(evidence_quotes="just a string")
