"""Storage idempotency, score upsert, and read filters."""
from __future__ import annotations

from pathlib import Path

from dev_trajectory.stage2 import MedianScore
from dev_trajectory.storage import Storage
from tests.conftest import make_discovered_session, make_score, utc


def _median_score(score=None) -> MedianScore:
    s = score or make_score()
    return MedianScore(
        runs=[s, s, s],
        median_dimensions={
            "problem_decomposition": s.problem_decomposition,
            "systems_thinking": s.systems_thinking,
            "debugging_methodology": s.debugging_methodology,
            "technical_communication": s.technical_communication,
            "model_redirection": s.model_redirection,
        },
        max_dimension_spread=0,
        confidence=s.confidence,
        domain_category=s.domain_category,
        domain_detail=s.domain_detail,
        language=s.language,
        mode=s.mode,
        seniority_band=s.seniority_band,
        inferred_ic_level=s.inferred_ic_level,
        evidence_quotes=list(s.evidence_quotes),
    )


def test_upsert_session_is_idempotent(tmp_path: Path):
    storage = Storage(tmp_path / "db.sqlite3")
    session = make_discovered_session(sid="s1", anchor_ts=utc(2026, 4, 6))
    storage.upsert_session(session, user_turn_count=5, total_user_chars=100)
    storage.upsert_session(session, user_turn_count=10, total_user_chars=200)
    assert storage.session_ids() == {"s1"}


def test_score_upsert_replaces_on_conflict(tmp_path: Path):
    storage = Storage(tmp_path / "db.sqlite3")
    session = make_discovered_session(sid="s1", anchor_ts=utc(2026, 4, 6))
    storage.upsert_session(session, user_turn_count=5, total_user_chars=100)

    storage.upsert_score("s1", "v1", _median_score(make_score(seniority_band="mid")), "claude-sonnet-4-6")
    storage.upsert_score("s1", "v1", _median_score(make_score(seniority_band="senior")), "claude-sonnet-4-6")

    scores = storage.all_scores(rubric_version="v1", min_confidence=0.0)
    assert len(scores) == 1
    assert scores[0].seniority_band == "senior"


def test_has_score_reflects_upsert(tmp_path: Path):
    storage = Storage(tmp_path / "db.sqlite3")
    session = make_discovered_session(sid="s1", anchor_ts=utc(2026, 4, 6))
    storage.upsert_session(session, user_turn_count=5, total_user_chars=100)

    assert storage.has_score("s1", "v1") is False
    storage.upsert_score("s1", "v1", _median_score(), "claude-sonnet-4-6")
    assert storage.has_score("s1", "v1") is True
    assert storage.has_score("s1", "v2") is False


def test_min_confidence_filters_results(tmp_path: Path):
    storage = Storage(tmp_path / "db.sqlite3")
    for sid, conf in [("a", 0.3), ("b", 0.7)]:
        session = make_discovered_session(sid=sid, anchor_ts=utc(2026, 4, 6))
        storage.upsert_session(session, user_turn_count=1, total_user_chars=10)
        storage.upsert_score(sid, "v1", _median_score(make_score(confidence=conf)), "claude-sonnet-4-6")

    assert {s.session_id for s in storage.all_scores(min_confidence=0.5)} == {"b"}
    assert {s.session_id for s in storage.all_scores(min_confidence=0.0)} == {"a", "b"}


def test_scores_needing_rescore_returns_only_old_versions(tmp_path: Path):
    storage = Storage(tmp_path / "db.sqlite3")
    for sid, version in [("a", "v1"), ("b", "v1"), ("c", "v2")]:
        session = make_discovered_session(sid=sid, anchor_ts=utc(2026, 4, 6))
        storage.upsert_session(session, user_turn_count=1, total_user_chars=10)
        storage.upsert_score(sid, version, _median_score(), "claude-sonnet-4-6")

    stale = set(storage.scores_needing_rescore("v2"))
    assert stale == {"a", "b"}


def test_evidence_quotes_round_trip_through_sqlite(tmp_path: Path):
    storage = Storage(tmp_path / "db.sqlite3")
    session = make_discovered_session(sid="s1", anchor_ts=utc(2026, 4, 6))
    storage.upsert_session(session, user_turn_count=1, total_user_chars=10)

    quotes = ["first quote", "second quote with \"inner\" punctuation", "third"]
    s = make_score(evidence_quotes=quotes)
    median = _median_score(s)
    median.evidence_quotes = quotes
    storage.upsert_score("s1", "v1", median, "claude-sonnet-4-6")

    [stored] = storage.all_scores(min_confidence=0.0)
    assert stored.evidence_quotes == quotes
