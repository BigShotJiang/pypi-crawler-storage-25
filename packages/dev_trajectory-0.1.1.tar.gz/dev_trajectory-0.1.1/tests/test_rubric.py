"""Rubric loading: required structure, deterministic rendering."""
from __future__ import annotations

import pytest

from dev_trajectory.rubric import load_rubric


def test_v1_rubric_renders_a_non_empty_system_prompt():
    rubric = load_rubric("v1")
    assert rubric.version == "v1"
    assert len(rubric.system_prompt) > 1000


def test_rubric_rendering_is_deterministic():
    """Prompt caching depends on byte-stable output. If this test starts failing,
    something in _render_system_prompt picked up non-determinism (dict iter order,
    timestamps, etc.) and cache hit rates will silently collapse.
    """
    a = load_rubric("v1").system_prompt
    load_rubric.cache_clear()  # bypass the lru_cache
    b = load_rubric("v1").system_prompt
    assert a == b


def test_rubric_mentions_all_five_dimensions():
    prompt = load_rubric("v1").system_prompt
    for dim in (
        "problem_decomposition",
        "systems_thinking",
        "debugging_methodology",
        "technical_communication",
        "model_redirection",
    ):
        assert dim in prompt


def test_rubric_mentions_all_five_bands():
    prompt = load_rubric("v1").system_prompt
    for band in ("junior", "mid", "senior", "staff", "principal"):
        assert band in prompt


def test_unknown_version_raises():
    load_rubric.cache_clear()
    with pytest.raises(FileNotFoundError):
        load_rubric("v99")
