"""Dashboard API tests using FastAPI's TestClient.

We exercise:
- /api/health smoke
- /api/filters returns values present in storage
- /api/trajectory shape (sessions, buckets, regression_per_domain)
- /api/trajectory honors filters (domain, min_confidence)
- /api/evidence/bucket and /api/evidence/session
- /api/session/{id}/text re-parses the JSONL on disk
- chart-type-agnostic dimension switching (regression on integer scores)
"""
from __future__ import annotations

from datetime import timedelta
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from dev_trajectory.config import Config
from dev_trajectory.server.api import create_app
from dev_trajectory.server.regression import ols
from dev_trajectory.stage2 import MedianScore
from dev_trajectory.storage import Storage
from tests.conftest import make_discovered_session, make_score, utc, write_claude_code_session, make_record


@pytest.fixture
def populated_storage(tmp_path: Path) -> Storage:
    """Build a SQLite store with 12 sessions across 4 weeks × 3 domains."""
    storage = Storage(tmp_path / "db.sqlite3")
    base = utc(2026, 4, 6)
    for week in range(4):
        for d_i, domain in enumerate(["backend", "frontend", "data_ml"]):
            sid = f"w{week}-{domain}"
            session = make_discovered_session(sid=sid, anchor_ts=base + timedelta(weeks=week, hours=d_i))
            storage.upsert_session(session, user_turn_count=5, total_user_chars=200)
            score = make_score(
                domain_category=domain,
                language={"backend": "python", "frontend": "typescript", "data_ml": "go"}[domain],
                problem_decomposition=2 + (week % 3),
                model_redirection=3,
                confidence=0.8,
            )
            median = MedianScore(
                runs=[score, score, score],
                median_dimensions={
                    "problem_decomposition": score.problem_decomposition,
                    "systems_thinking": score.systems_thinking,
                    "debugging_methodology": score.debugging_methodology,
                    "technical_communication": score.technical_communication,
                    "model_redirection": score.model_redirection,
                },
                max_dimension_spread=0,
                confidence=score.confidence,
                domain_category=domain,
                domain_detail=None,
                language=score.language,
                mode=score.mode,
                seniority_band=score.seniority_band,
                inferred_ic_level=score.inferred_ic_level,
                evidence_quotes=[f"quote for {sid}"],
            )
            storage.upsert_score(sid, "v1", median, "claude-sonnet-4-6")
    return storage


@pytest.fixture
def client(populated_storage: Storage, tmp_path: Path) -> TestClient:
    cfg = Config(rubric_version="v1")
    app = create_app(cfg=cfg, storage=populated_storage)
    return TestClient(app)


def test_health(client: TestClient):
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json() == {"ok": True, "rubric_version": "v1"}


def test_filters_returns_values_present(client: TestClient):
    r = client.get("/api/filters")
    assert r.status_code == 200
    data = r.json()
    assert set(data["domains"]) == {"backend", "frontend", "data_ml"}
    assert set(data["languages"]) == {"python", "typescript", "go"}
    assert "problem_decomposition" in data["dimensions"]


def test_trajectory_shape(client: TestClient):
    r = client.get("/api/trajectory", params={"dimension": "problem_decomposition"})
    assert r.status_code == 200
    data = r.json()
    assert data["dimension"] == "problem_decomposition"
    assert data["n_sessions"] == 12
    assert len(data["sessions"]) == 12
    # 4 weeks × 3 domains = 12 buckets (one session per bucket).
    assert len(data["buckets"]) == 12
    # 3 domains, 4 points each → enough for a regression per domain.
    assert set(data["regression_per_domain"].keys()) == {"backend", "frontend", "data_ml"}
    backend_reg = data["regression_per_domain"]["backend"]
    assert "slope_per_day" in backend_reg
    assert "intercept" in backend_reg
    assert backend_reg["n"] == 4


def test_trajectory_filters_by_domain(client: TestClient):
    r = client.get("/api/trajectory", params={"dimension": "model_redirection", "domains": "backend"})
    data = r.json()
    assert data["n_sessions"] == 4
    assert {s["domain_category"] for s in data["sessions"]} == {"backend"}


def test_trajectory_min_confidence_filter(client: TestClient, populated_storage: Storage):
    # All seeded scores have confidence=0.8, so threshold 0.9 should drop everything.
    r = client.get("/api/trajectory", params={"dimension": "model_redirection", "min_confidence": 0.9})
    assert r.json()["n_sessions"] == 0


def test_trajectory_rejects_unknown_dimension(client: TestClient):
    r = client.get("/api/trajectory", params={"dimension": "vibes"})
    assert r.status_code == 400


def test_filters_includes_overall_dimension(client: TestClient):
    """The 'overall' synthetic dimension must be advertised so the dropdown can list it."""
    r = client.get("/api/filters")
    assert "overall" in r.json()["dimensions"]


def test_trajectory_overall_dimension(client: TestClient):
    """The synthetic 'overall' dimension sums the five rubric scores per session."""
    r = client.get("/api/trajectory", params={"dimension": "overall"})
    assert r.status_code == 200
    data = r.json()
    assert data["dimension"] == "overall"
    assert data["n_sessions"] == 12
    # Fixture seeds: problem_decomposition=2+(week%3), all others=3, model_redirection=3.
    # So per-session sum = (2 + week%3) + 3 + 3 + 3 + 3 = 14 + (week%3).
    # Range across 4 weeks: 14, 15, 16, 14 → min 14, max 16.
    values = [s["value"] for s in data["sessions"]]
    assert min(values) == 14
    assert max(values) == 16
    # Bucket medians should fall in the same range — never outside the per-session sums.
    bucket_medians = [b["median"] for b in data["buckets"]]
    assert all(14 <= m <= 16 for m in bucket_medians)
    # Regression should still produce one entry per domain.
    assert set(data["regression_per_domain"].keys()) == {"backend", "frontend", "data_ml"}


def test_evidence_for_bucket(client: TestClient):
    r = client.get(
        "/api/evidence/bucket",
        params={"week_start": "2026-04-06", "domain_category": "backend"},
    )
    assert r.status_code == 200
    data = r.json()
    assert len(data["sessions"]) == 1
    assert data["sessions"][0]["evidence_quotes"] == ["quote for w0-backend"]


def test_evidence_for_session(client: TestClient):
    r = client.get("/api/evidence/session/w0-backend")
    assert r.status_code == 200
    assert r.json()["session_id"] == "w0-backend"

    r = client.get("/api/evidence/session/does-not-exist")
    assert r.status_code == 404


def test_session_text_reparses_jsonl(tmp_path: Path):
    """The full-session-text endpoint re-reads the file on disk on demand."""
    storage = Storage(tmp_path / "db.sqlite3")

    # Write a real JSONL the parser can read.
    session_file = tmp_path / "real-session.jsonl"
    write_claude_code_session(
        session_file,
        [
            make_record(uuid="u1", role="user", text_or_blocks="first user message"),
            make_record(uuid="u2", role="user", text_or_blocks="second user message"),
        ],
    )

    session = make_discovered_session(sid="real", anchor_ts=utc(2026, 4, 6), file_path=session_file)
    storage.upsert_session(session, user_turn_count=2, total_user_chars=40)

    cfg = Config(rubric_version="v1")
    app = create_app(cfg=cfg, storage=storage)
    client = TestClient(app)

    r = client.get("/api/session/real/text")
    assert r.status_code == 200
    data = r.json()
    assert len(data["turns"]) == 2
    assert "first user message" in data["turns"][0]["user_text"]


def test_session_text_404_when_file_missing(tmp_path: Path):
    storage = Storage(tmp_path / "db.sqlite3")
    session = make_discovered_session(sid="ghost", anchor_ts=utc(2026, 4, 6), file_path=tmp_path / "missing.jsonl")
    storage.upsert_session(session, user_turn_count=1, total_user_chars=10)
    cfg = Config(rubric_version="v1")
    client = TestClient(create_app(cfg=cfg, storage=storage))
    r = client.get("/api/session/ghost/text")
    assert r.status_code == 404


def test_index_html_served(client: TestClient):
    r = client.get("/")
    assert r.status_code == 200
    assert "dev-trajectory" in r.text


def test_index_loads_required_scripts(client: TestClient):
    """Both plotly.js and app.js must be referenced or the page renders blank."""
    r = client.get("/")
    body = r.text
    assert "/api/plotly.js" in body, "index.html must reference the bundled Plotly"
    assert "/static/app.js" in body, "index.html must load the app.js that wires up the UI"


def test_static_route_rejects_traversal(client: TestClient):
    r = client.get("/static/../config.py")
    assert r.status_code == 404


def test_plotly_js_served(client: TestClient):
    r = client.get("/api/plotly.js")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/javascript")
    assert "plotly" in r.text.lower()
    assert len(r.text) > 100_000  # bundled plotly is several MB


# --- regression module unit tests -------------------------------------------


def test_ols_recovers_known_line():
    xs = [0.0, 1.0, 2.0, 3.0, 4.0]
    ys = [1.0, 3.0, 5.0, 7.0, 9.0]  # y = 2x + 1
    reg = ols(xs, ys)
    assert reg is not None
    assert abs(reg.slope - 2.0) < 1e-9
    assert abs(reg.intercept - 1.0) < 1e-9
    assert reg.n == 5


def test_ols_returns_none_for_constant_x():
    reg = ols([5.0, 5.0, 5.0], [1.0, 2.0, 3.0])
    assert reg is None


def test_ols_returns_none_below_two_points():
    assert ols([1.0], [2.0]) is None
    assert ols([], []) is None


def test_ols_length_mismatch_raises():
    with pytest.raises(ValueError):
        ols([1.0, 2.0], [1.0])
