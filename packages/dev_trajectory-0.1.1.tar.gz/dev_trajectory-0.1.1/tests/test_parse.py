"""Parser: enforce the strip / preserve rules and signal-turn selection."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from dev_trajectory.parse import parse_claude_code_session, select_signal_turns
from tests.conftest import make_record, write_claude_code_session


def _write(path: Path, records):
    return write_claude_code_session(path, records)


def test_parses_user_prose_and_drops_oversized_tool_results(tmp_path: Path):
    records = [
        make_record(uuid="u1", role="user", text_or_blocks="please fix the rate limit"),
        make_record(
            uuid="a1",
            role="assistant",
            text_or_blocks=[{"type": "text", "text": "Reading the file."}, {"type": "tool_use", "id": "t1", "name": "read", "input": {}}],
        ),
        # Tool-result-only user turn with massive content should be dropped entirely.
        make_record(
            uuid="u2",
            role="user",
            text_or_blocks=[{"type": "tool_result", "tool_use_id": "t1", "content": "x" * 50_000}],
        ),
        make_record(uuid="u3", role="user", text_or_blocks="Wait — I think the race is in worker.py"),
    ]
    parsed = parse_claude_code_session(_write(tmp_path / "s.jsonl", records))
    assert parsed.user_turn_count == 2
    assert "rate limit" in parsed.turns[0].user_text
    assert "race" in parsed.turns[1].user_text


def test_short_tool_results_are_kept(tmp_path: Path):
    """Short tool-result content sits inside a turn that *also* has prose."""
    records = [
        make_record(
            uuid="u1",
            role="user",
            text_or_blocks=[
                {"type": "tool_result", "tool_use_id": "t1", "content": "ok, exit 0"},
                {"type": "text", "text": "looks good — now run the tests"},
            ],
        ),
    ]
    parsed = parse_claude_code_session(_write(tmp_path / "s.jsonl", records))
    assert parsed.user_turn_count == 1
    assert "exit 0" in parsed.turns[0].user_text
    assert "run the tests" in parsed.turns[0].user_text


def test_preceding_assistant_text_attached_to_user_turn(tmp_path: Path):
    records = [
        make_record(uuid="a1", role="assistant", text_or_blocks="the race is in worker.py:142"),
        make_record(uuid="u1", role="user", text_or_blocks="let's add a lock there"),
    ]
    parsed = parse_claude_code_session(_write(tmp_path / "s.jsonl", records))
    assert parsed.user_turn_count == 1
    assert "worker.py" in parsed.turns[0].preceding_assistant_text


def test_anchor_timestamp_taken_from_first_record(tmp_path: Path):
    early = datetime(2026, 4, 1, 9, 0, 0, tzinfo=timezone.utc)
    late = datetime(2026, 4, 1, 11, 0, 0, tzinfo=timezone.utc)
    records = [
        make_record(uuid="u1", role="user", text_or_blocks="hi", timestamp=early),
        make_record(uuid="u2", role="user", text_or_blocks="hello", timestamp=late),
    ]
    parsed = parse_claude_code_session(_write(tmp_path / "s.jsonl", records))
    assert parsed.anchor_ts == early


def test_malformed_json_lines_are_skipped(tmp_path: Path):
    path = tmp_path / "s.jsonl"
    path.write_text(
        "garbage{not json}\n"
        '{"uuid":"u1","timestamp":"2026-04-01T12:00:00Z","type":"user","message":{"role":"user","content":"hello"}}\n',
        encoding="utf-8",
    )
    parsed = parse_claude_code_session(path)
    assert parsed.user_turn_count == 1


def test_signal_turn_selection_picks_first_longest_last(tmp_path: Path):
    records = [
        make_record(uuid="u1", role="user", text_or_blocks="open the file"),
        make_record(uuid="u2", role="user", text_or_blocks="x" * 500),
        make_record(uuid="u3", role="user", text_or_blocks="ok"),
        make_record(uuid="u4", role="user", text_or_blocks="thanks, that worked"),
    ]
    parsed = parse_claude_code_session(_write(tmp_path / "s.jsonl", records))
    picks = select_signal_turns(parsed, max_turns=5)
    indices = [t.index for t in picks]
    # First, longest, last must all be present.
    assert 0 in indices  # first
    assert 1 in indices  # longest
    assert 3 in indices  # last


def test_signal_turn_selection_caps_at_max_turns(tmp_path: Path):
    # First and last are obvious picks. Two more turns contain pushback markers
    # that would otherwise be eligible — but the cap of 3 should drop all but one.
    records = [
        make_record(uuid="u0", role="user", text_or_blocks="open the file"),
        make_record(uuid="u1", role="user", text_or_blocks="actually that's wrong, try again"),
        make_record(uuid="u2", role="user", text_or_blocks="hmm, doesn't work"),
        make_record(uuid="u3", role="user", text_or_blocks="thanks, that worked"),
    ]
    parsed = parse_claude_code_session(_write(tmp_path / "s.jsonl", records))
    picks = select_signal_turns(parsed, max_turns=3)
    assert len(picks) == 3


def test_pushback_markers_promote_turn_to_signal(tmp_path: Path):
    records = [
        make_record(uuid="u1", role="user", text_or_blocks="add a feature"),
        make_record(uuid="u2", role="user", text_or_blocks="ok cool"),
        make_record(uuid="u3", role="user", text_or_blocks="actually that's wrong, the API takes bytes not strings"),
        make_record(uuid="u4", role="user", text_or_blocks="ok"),
    ]
    parsed = parse_claude_code_session(_write(tmp_path / "s.jsonl", records))
    picks = select_signal_turns(parsed, max_turns=4)
    indices = [t.index for t in picks]
    assert 2 in indices  # the pushback turn
