"""Median-of-3 aggregation: dimension medians, modal vote on categoricals,
spread tracking, evidence-quote dedup. The actual LLM call is mocked.
"""
from __future__ import annotations

from dev_trajectory.rubric import load_rubric
from dev_trajectory.stage2 import _aggregate, score_session
from dev_trajectory.parse import Turn
from tests.conftest import FakeClient, make_score, utc


def test_aggregate_takes_median_per_dimension():
    runs = [
        make_score(problem_decomposition=1, systems_thinking=4),
        make_score(problem_decomposition=3, systems_thinking=4),
        make_score(problem_decomposition=5, systems_thinking=2),
    ]
    median = _aggregate(runs)
    assert median.median_dimensions["problem_decomposition"] == 3
    assert median.median_dimensions["systems_thinking"] == 4


def test_aggregate_tracks_max_dimension_spread():
    runs = [
        make_score(problem_decomposition=1),
        make_score(problem_decomposition=3),
        make_score(problem_decomposition=5),
    ]
    median = _aggregate(runs)
    assert median.max_dimension_spread == 4


def test_aggregate_picks_modal_band():
    runs = [
        make_score(seniority_band="senior"),
        make_score(seniority_band="senior"),
        make_score(seniority_band="staff"),
    ]
    assert _aggregate(runs).seniority_band == "senior"


def test_aggregate_modal_language_allows_all_null():
    runs = [
        make_score(language=None),
        make_score(language=None),
        make_score(language=None),
    ]
    assert _aggregate(runs).language is None


def test_aggregate_modal_language_picks_majority_when_present():
    runs = [
        make_score(language="python"),
        make_score(language="python"),
        make_score(language=None),
    ]
    assert _aggregate(runs).language == "python"


def test_aggregate_dedups_evidence_quotes_and_caps_at_five():
    runs = [
        make_score(evidence_quotes=["a", "b"]),
        make_score(evidence_quotes=["b", "c"]),
        make_score(evidence_quotes=["d", "e", "f", "g", "h"]),
    ]
    quotes = _aggregate(runs).evidence_quotes
    assert len(quotes) <= 5
    assert quotes[:3] == ["a", "b", "c"]
    assert "b" in quotes  # the dedup property — appears once even though present in two runs
    assert quotes.count("b") == 1


def test_score_session_mocks_three_calls_and_caches_rubric():
    """End-to-end through score_session with a fake client; verify the cache_control marker is on the system prompt."""
    rubric = load_rubric("v1")
    client = FakeClient(scores=[
        make_score(problem_decomposition=2),
        make_score(problem_decomposition=4),
        make_score(problem_decomposition=3),
    ])
    turns = [Turn(index=0, user_text="hello", preceding_assistant_text="", char_count=5, timestamp=utc(2026, 4, 1))]
    median = score_session(client, rubric, "summary text", turns, n=3)

    assert client.messages.parse_calls == 3
    assert median.median_dimensions["problem_decomposition"] == 3

    last_kwargs = client.messages.last_parse_kwargs
    assert last_kwargs is not None
    system = last_kwargs["system"]
    # System is a list with one block carrying cache_control: ephemeral.
    assert isinstance(system, list)
    assert system[0]["cache_control"] == {"type": "ephemeral"}
