"""The per-week sampler is load-bearing for the idempotency promise:
re-running `analyze` must pick the same sessions every time. Lock that in.
"""
from __future__ import annotations

import random
from collections import Counter

from dev_trajectory.pipeline import sample_per_week
from tests.conftest import days, make_discovered_session, utc


def _three_weeks_of_sessions():
    """10 sessions in week A (Apr 6 = Mon), 8 in week B, 7 in week C."""
    base = utc(2026, 4, 6)
    out = []
    for i in range(10):
        out.append(make_discovered_session(sid=f"a{i:02d}", anchor_ts=base + days(0) + days(i // 5)))
    for i in range(8):
        out.append(make_discovered_session(sid=f"b{i:02d}", anchor_ts=base + days(7) + days(i // 4)))
    for i in range(7):
        out.append(make_discovered_session(sid=f"c{i:02d}", anchor_ts=base + days(14) + days(i // 4)))
    return out


def test_cap_zero_returns_everything():
    sessions = _three_weeks_of_sessions()
    assert len(sample_per_week(sessions, cap=0)) == len(sessions)


def test_negative_cap_treated_as_disabled():
    sessions = _three_weeks_of_sessions()
    assert len(sample_per_week(sessions, cap=-1)) == len(sessions)


def test_cap_three_picks_three_per_week():
    sessions = _three_weeks_of_sessions()
    sampled = sample_per_week(sessions, cap=3)
    by_prefix = Counter(s.id[0] for s in sampled)
    assert by_prefix == {"a": 3, "b": 3, "c": 3}


def test_cap_larger_than_week_keeps_everything_in_that_week():
    sessions = _three_weeks_of_sessions()  # week C has 7
    sampled = sample_per_week(sessions, cap=20)
    by_prefix = Counter(s.id[0] for s in sampled)
    assert by_prefix == {"a": 10, "b": 8, "c": 7}


def test_sampling_is_deterministic_across_input_order():
    sessions = _three_weeks_of_sessions()
    a = [s.id for s in sample_per_week(sessions, cap=3)]

    shuffled = sessions[:]
    random.Random(42).shuffle(shuffled)
    b = [s.id for s in sample_per_week(shuffled, cap=3)]

    assert a == b


def test_week_boundary_monday_starts_new_week():
    """A Sunday session and the next Monday session should be in different ISO weeks."""
    # 2026-04-12 is a Sunday; 2026-04-13 is the Monday that starts the new week.
    sun = make_discovered_session(sid="z_sun", anchor_ts=utc(2026, 4, 12, 23))
    mon = make_discovered_session(sid="a_mon", anchor_ts=utc(2026, 4, 13, 1))
    sampled = sample_per_week([sun, mon], cap=1)
    # Both must survive — they're in different weeks, so cap=1 keeps both.
    assert {s.id for s in sampled} == {"z_sun", "a_mon"}


def test_empty_input_returns_empty():
    assert sample_per_week([], cap=3) == []
