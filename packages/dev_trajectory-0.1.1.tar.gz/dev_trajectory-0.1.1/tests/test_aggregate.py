"""Aggregation: weekly bucketing, medians, IQR, modal band."""
from __future__ import annotations

from datetime import date

from dev_trajectory.aggregate import Bucket, bucket_weekly
from dev_trajectory.storage import StoredScore
from tests.conftest import utc


def _stored(
    *,
    sid: str,
    ts,
    domain="backend",
    language="python",
    band="senior",
    pd=3, st=3, dm=3, tc=3, mr=3,
    confidence=0.8,
):
    return StoredScore(
        session_id=sid,
        rubric_version="v1",
        anchor_ts=ts,
        dimensions={
            "problem_decomposition": pd,
            "systems_thinking": st,
            "debugging_methodology": dm,
            "technical_communication": tc,
            "model_redirection": mr,
        },
        domain_category=domain,
        domain_detail=None,
        language=language,
        mode="debugging",
        confidence=confidence,
        evidence_quotes=["q"],
        seniority_band=band,
        inferred_ic_level="IC4",
        max_dimension_spread=0,
    )


def test_weekly_bucketing_groups_by_iso_week_and_domain():
    scores = [
        _stored(sid="a1", ts=utc(2026, 4, 6), domain="backend"),     # week A
        _stored(sid="a2", ts=utc(2026, 4, 9), domain="backend"),     # week A
        _stored(sid="a3", ts=utc(2026, 4, 9), domain="frontend"),    # week A
        _stored(sid="b1", ts=utc(2026, 4, 13), domain="backend"),    # week B
    ]
    buckets = bucket_weekly(scores, slice_by="domain")
    keyed = {(b.week_start, b.slice_key): b for b in buckets}
    assert (date(2026, 4, 6), "backend") in keyed
    assert (date(2026, 4, 6), "frontend") in keyed
    assert (date(2026, 4, 13), "backend") in keyed
    assert len(keyed[(date(2026, 4, 6), "backend")].sessions) == 2
    assert len(keyed[(date(2026, 4, 6), "frontend")].sessions) == 1


def test_slice_by_language_falls_back_to_none_when_language_missing():
    scores = [
        _stored(sid="a1", ts=utc(2026, 4, 6), language=None),
        _stored(sid="a2", ts=utc(2026, 4, 6), language="python"),
    ]
    buckets = bucket_weekly(scores, slice_by="language")
    keys = {b.slice_key for b in buckets}
    assert keys == {"none", "python"}


def test_slice_by_all_collapses_into_single_slice_per_week():
    scores = [
        _stored(sid="a1", ts=utc(2026, 4, 6), domain="backend"),
        _stored(sid="a2", ts=utc(2026, 4, 7), domain="frontend"),
        _stored(sid="a3", ts=utc(2026, 4, 8), domain="data_ml"),
    ]
    buckets = bucket_weekly(scores, slice_by="all")
    assert len(buckets) == 1
    assert buckets[0].slice_key == "all"
    assert len(buckets[0].sessions) == 3


def test_medians_per_dimension():
    bucket = Bucket(
        week_start=date(2026, 4, 6),
        slice_key="backend",
        sessions=[
            _stored(sid=f"s{i}", ts=utc(2026, 4, 6), pd=v, st=v, dm=v, tc=v, mr=v)
            for i, v in enumerate([1, 3, 5])
        ],
    )
    medians = bucket.medians()
    assert medians["problem_decomposition"] == 3
    assert medians["model_redirection"] == 3


def test_modal_band_picks_most_common():
    bucket = Bucket(
        week_start=date(2026, 4, 6),
        slice_key="backend",
        sessions=[
            _stored(sid="a", ts=utc(2026, 4, 6), band="senior"),
            _stored(sid="b", ts=utc(2026, 4, 6), band="senior"),
            _stored(sid="c", ts=utc(2026, 4, 6), band="staff"),
        ],
    )
    assert bucket.modal_band() == "senior"


def test_empty_bucket_returns_zero_medians_and_no_modal_band():
    bucket = Bucket(week_start=date(2026, 4, 6), slice_key="backend", sessions=[])
    medians = bucket.medians()
    assert all(v == 0.0 for v in medians.values())
    assert bucket.modal_band() is None


def test_iqr_with_few_samples_returns_min_max():
    bucket = Bucket(
        week_start=date(2026, 4, 6),
        slice_key="backend",
        sessions=[_stored(sid="a", ts=utc(2026, 4, 6), pd=2), _stored(sid="b", ts=utc(2026, 4, 6), pd=4)],
    )
    low, high = bucket.iqr("problem_decomposition")
    assert low == 2.0
    assert high == 4.0
