"""Pipeline analyze() with the Anthropic client mocked. Locks in:
- Sampling cap is honored end-to-end.
- Sessions already scored at the current rubric_version are skipped.
- --rebuild ignores the skip and re-scores.
- Failures on one session don't kill the rest.
"""
from __future__ import annotations

from datetime import timedelta
from pathlib import Path

from dev_trajectory.config import Config
from dev_trajectory.pipeline import analyze
from dev_trajectory.storage import Storage
from tests.conftest import FakeClient, make_record, make_score, utc, write_claude_code_session


def _seed_session(root: Path, *, name: str, ts):
    sub = root / "proj"
    sub.mkdir(exist_ok=True)
    return write_claude_code_session(
        sub / f"{name}.jsonl",
        [
            make_record(uuid=f"{name}-u1", role="user", text_or_blocks="initial framing of the problem", timestamp=ts),
            make_record(uuid=f"{name}-u2", role="user", text_or_blocks="follow-up question", timestamp=ts + timedelta(minutes=5)),
        ],
    )


def test_analyze_honors_per_week_sampling_cap(claude_session_root: Path, tmp_path: Path):
    """6 sessions in a single ISO week → cap=2 → only 2 scored."""
    base = utc(2026, 4, 6)  # Monday
    for i in range(6):
        _seed_session(claude_session_root, name=f"s{i:02d}", ts=base + timedelta(hours=i))

    storage = Storage(tmp_path / "db.sqlite3")
    cfg = Config(sessions_per_week=2)
    client = FakeClient()
    result = analyze(cfg=cfg, storage=storage, client=client, rebuild=False)

    assert result.discovered == 6
    assert result.sampled == 2
    assert result.scored == 2
    assert client.messages.parse_calls == 2 * 3  # median-of-3 per scored session


def test_analyze_skips_already_scored_sessions(claude_session_root: Path, tmp_path: Path):
    _seed_session(claude_session_root, name="only", ts=utc(2026, 4, 6))

    storage = Storage(tmp_path / "db.sqlite3")
    cfg = Config(sessions_per_week=10)

    client1 = FakeClient()
    first = analyze(cfg=cfg, storage=storage, client=client1)
    assert first.scored == 1

    # Second run with the same client and storage — should skip.
    client2 = FakeClient()
    second = analyze(cfg=cfg, storage=storage, client=client2)
    assert second.scored == 0
    assert second.skipped_existing == 1
    assert client2.messages.parse_calls == 0


def test_rebuild_ignores_skip_and_re_scores(claude_session_root: Path, tmp_path: Path):
    _seed_session(claude_session_root, name="only", ts=utc(2026, 4, 6))

    storage = Storage(tmp_path / "db.sqlite3")
    cfg = Config(sessions_per_week=10)

    analyze(cfg=cfg, storage=storage, client=FakeClient())

    rebuild_client = FakeClient()
    second = analyze(cfg=cfg, storage=storage, client=rebuild_client, rebuild=True)
    assert second.scored == 1
    assert rebuild_client.messages.parse_calls == 3


def test_failure_on_one_session_does_not_stop_the_rest(claude_session_root: Path, tmp_path: Path, monkeypatch):
    """When the LLM call raises on session A, session B should still get scored."""
    import threading

    _seed_session(claude_session_root, name="aaa", ts=utc(2026, 4, 6))
    _seed_session(claude_session_root, name="bbb", ts=utc(2026, 4, 6))

    storage = Storage(tmp_path / "db.sqlite3")
    # Force serial execution so the failure injection is unambiguous.
    cfg = Config(sessions_per_week=10, max_concurrent_sessions=1)

    state = {"failed_for_first": False}
    state_lock = threading.Lock()
    client = FakeClient()
    real_create = client.messages.create

    def maybe_failing_create(**kwargs):
        # Atomic check-and-set so only the first caller raises, even if this
        # ever runs concurrently.
        with state_lock:
            if not state["failed_for_first"]:
                state["failed_for_first"] = True
                should_fail = True
            else:
                should_fail = False
        if should_fail:
            raise RuntimeError("simulated network failure")
        return real_create(**kwargs)

    client.messages.create = maybe_failing_create  # type: ignore[method-assign]

    result = analyze(cfg=cfg, storage=storage, client=client)
    assert result.scored == 1
    assert result.failed == 1
    assert len(result.failures) == 1


def test_analyze_runs_sessions_in_parallel(claude_session_root: Path, tmp_path: Path):
    """Confirm the per-session ThreadPoolExecutor actually parallelizes.

    The slow Stage 1 stub holds the call open just long enough that, under
    serial execution, max_in_flight would stay at 1. With max_concurrent_sessions=4,
    we should observe at least 2 concurrent calls and never more than 4.
    """
    import threading
    import time
    from datetime import timedelta

    for i in range(8):
        _seed_session(claude_session_root, name=f"s{i:02d}", ts=utc(2026, 4, 6) + timedelta(hours=i))

    storage = Storage(tmp_path / "db.sqlite3")
    cfg = Config(sessions_per_week=20, max_concurrent_sessions=4)

    in_flight = [0]
    max_in_flight = [0]
    counter_lock = threading.Lock()

    client = FakeClient()
    real_create = client.messages.create

    def slow_create(**kwargs):
        with counter_lock:
            in_flight[0] += 1
            if in_flight[0] > max_in_flight[0]:
                max_in_flight[0] = in_flight[0]
        # Sleep with the lock released so other threads can enter.
        time.sleep(0.05)
        try:
            return real_create(**kwargs)
        finally:
            with counter_lock:
                in_flight[0] -= 1

    client.messages.create = slow_create  # type: ignore[method-assign]

    result = analyze(cfg=cfg, storage=storage, client=client)
    assert result.scored == 8
    assert max_in_flight[0] >= 2, "expected at least 2 concurrent sessions; got {}".format(max_in_flight[0])
    assert max_in_flight[0] <= 4, "exceeded max_concurrent_sessions cap"


def test_max_concurrent_sessions_cli_override_takes_precedence(claude_session_root: Path, tmp_path: Path):
    """The function-arg override beats Config.max_concurrent_sessions."""
    from datetime import timedelta

    for i in range(3):
        _seed_session(claude_session_root, name=f"s{i:02d}", ts=utc(2026, 4, 6) + timedelta(hours=i))

    storage = Storage(tmp_path / "db.sqlite3")
    # Config says 1, override says 3 — should run with 3.
    cfg = Config(sessions_per_week=20, max_concurrent_sessions=1)

    result = analyze(cfg=cfg, storage=storage, client=FakeClient(), max_concurrent_sessions=3)
    assert result.scored == 3


def test_empty_session_file_does_not_score(claude_session_root: Path, tmp_path: Path):
    sub = claude_session_root / "proj"
    sub.mkdir()
    write_claude_code_session(
        sub / "empty.jsonl",
        [
            # Only an assistant message — no user turns at all.
            make_record(uuid="a1", role="assistant", text_or_blocks="hello"),
        ],
    )

    storage = Storage(tmp_path / "db.sqlite3")
    cfg = Config(sessions_per_week=10)
    client = FakeClient()
    result = analyze(cfg=cfg, storage=storage, client=client)

    assert result.scored == 0
    assert client.messages.parse_calls == 0
