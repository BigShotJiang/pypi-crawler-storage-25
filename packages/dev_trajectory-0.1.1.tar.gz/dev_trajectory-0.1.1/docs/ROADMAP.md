# Roadmap

A short, user-facing view of what's done, what's next, and what's a maybe. For the longer technical proposal see [PROJECT.md](PROJECT.md).

Timelines are best-effort guesses, not commitments. This is alpha software shipped by a small team — order and scope can change based on what real users actually need.

**Suggestions welcome.** Open an issue if you'd like to argue for reprioritizing, adding, or removing anything here.

## Done

- **Phase 0 — Spike.** Rubric v1 + Claude Code session discovery validated.
- **Phase 1 — Core CLI (Claude Code).** `init`, `analyze`, `report`, `explain`, `rescore`. Two-stage scoring with median-of-3, prompt caching, SQLite persistence with rubric versioning, deterministic per-week sampling cap.
- **Phase 2 — Dashboard.** `devtraj serve` — local browser dashboard with weekly-median lines and per-session scatter modes, evidence side panel, filter set, synthetic "overall" dimension.

## Next (v0.1.0 release prep — current focus)

- **OSS polish.** README caveats, install verification, CHANGELOG, contribution guide, screenshot.
- **Roadmap and PROJECT documents** moved into `docs/`.
- Verify fresh-install path on a clean machine.

## Soon

- **MCP server (~1 week).** Read-only MCP tools (filters, trajectory, evidence, raw session text) over stdio so Claude Desktop / Claude Code can query trajectory data conversationally. Built; awaiting community validation before merge — see the `claude/mcp-server` branch.
- **Claude skill (~few days).** Thin wrapper in `~/.claude/skills/` that invokes the CLI.

## Maybe / future

- **Codex CLI support.** Add a parser behind the same `discover` / `parse` interface so Codex sessions get the same treatment. Conditional on the Codex session format stabilizing — won't ship while it's a moving target.
- **Rubric v2.** Improvements driven by real user data: anchor rewrites, dimension reweighting, possibly a sixth dimension. Existing scores would be re-run via `devtraj rescore`.
- **Configurable dimension weights** in the dashboard so power users can build their own composite scores.
- **Session exclusions.** Allow users to mark specific sessions as "don't score" (e.g., personal projects).

## Explicitly not on the roadmap

- **Multi-user / hosted deployment.** Privacy posture (local-only storage, no telemetry) is a feature, not a stepping stone. A hosted version would be a different product.
- **Automatic redaction of evidence quotes.** Verbatim quotes are what make the dashboard credible; since data never leaves the machine, redaction would degrade the product without reducing real risk.
- **Hand-labeled ground-truth dataset.** Building one is its own project. We rely on structural mitigations (anchored rubric, evidence quotes, median-of-3, confidence gating) instead.
