# dev-trajectory

*(Repo is still named `eng-trajectory-analyzer`; the published package and project name is `dev-trajectory`.)*

A local, single-user tool that ingests Claude Code and Codex CLI session histories, scores each session along multiple engineering capability dimensions using an LLM judge, and renders the developer's trajectory over time as a per-domain dashboard with evidence on hover.

Distributed primarily as a Python CLI, with an MCP server wrapper for in-editor use and an optional skill for Claude/Codex chat invocation.

**Build order:** Claude Code support is built end-to-end through every phase before Codex support is added. The Codex format is moving too fast to invest in until the rest of the pipeline is stable.

---

## 1. Motivation

Developers using AI coding assistants generate dense, longitudinal records of how they think, decompose problems, debug, and push back on bad suggestions. These records sit in `~/.claude/projects/` and `~/.codex/sessions/` and are read by no one.

Across hundreds of sessions, patterns aggregate: how someone frames an ambiguous task, whether they catch the model's hallucinations, how they redirect when the first approach fails. These correlate with engineering seniority more reliably than topic complexity does — a junior engineer asking a senior question still asks it like a junior.

**Thesis:** a sufficiently careful aggregation of these patterns produces a useful trajectory view of a developer's growth, surfaced in dimensions they can act on.

---

## 2. Honest Caveats (Up Front)

These shape the architecture, not just the README:

- **Sampling bias.** People use AI assistants for things they *don't* already know. The tool measures blind spots, not strengths. A staff backend engineer learning Rust will look junior in their Rust sessions.
- **LLM judge variance.** Single-shot LLM scoring on subjective tasks drifts. Mitigation is structural (median-of-3, forced evidence quotes, anchored rubric) but not eliminable.
- **Psychological impact.** A flat or declining line during a hard quarter is real information the user did not ask to know. UX framing matters.

These directly inform the architecture: per-domain aggregation, meta-signals, default views.

---

## 3. Core Hypothesis

Two signals carry most of the weight:

1. **Topic-conditional difficulty.** What the user is working on, conditioned on domain. Useful but heavily biased by what they choose to use AI for.
2. **Topic-independent meta-signals.** Did they catch the model's mistakes? Redirect a wrong approach? Ask "why" instead of "fix it"? Push back on architectural suggestions? These are far less topic-dependent and likely the cleanest seniority signal available.

**The scoring rubric weights (2) more heavily than (1).**

---

## 4. Technical Architecture

Five-stage pipeline: **discover → parse → sample → score → aggregate.**

### 4.1 Discover

Walk known session paths. Both tools write JSONL.

- Claude Code: `~/.claude/projects/<encoded-path>/<session-uuid>.jsonl`
- Codex CLI: `~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl`

Paths and formats drift across versions — implement version detection and graceful degradation. Use the first message's internal timestamp as the session **anchor** (file mtime is unreliable; gets clobbered by edits). Use `sha256(file_path + first_message_uuid)` as the stable **identity** key for SQLite persistence — robust to re-edits and appended turns.

### 4.2 Parse

Extract user turns + minimal assistant context (immediately preceding assistant message for grounding).

**Strip:**
- Tool outputs over 2k tokens (bloat) — threshold configurable
- File contents pasted by the assistant (not user signal)
- Long pasted logs

**Preserve:**
- All user-authored prose
- Code the *user* wrote inline (very different signal from pasted output)
- Short assistant messages the user is responding to

### 4.3 Sample (two-stage, with per-week cap)

Sessions are long *and* there are a lot of them. Two layers of sampling:

**Per-week sampling cap (configurable, default 3).** Within each ISO week, the
pipeline scores at most `sessions_per_week` sessions. Sampling is
deterministic: sessions in a week are sorted by their stable `session_id`
(already a sha256 hash, so the order is uniform) and the first N are picked.
Re-runs of `analyze` are therefore idempotent — the same sessions get scored
every time, no surprise re-work or surprise additions when a new session lands.
Setting `sessions_per_week = 0` disables the cap. Override per-run with
`devtraj analyze --sessions-per-week N`.

**Parallelism across sessions (configurable, default 10).** Sessions are
processed concurrently via a `ThreadPoolExecutor` — each worker handles one
session end-to-end (parse → summarize → median-of-3 score → persist). Inside
each worker the median-of-3 scoring already runs 3 calls in parallel, so total
in-flight LLM calls is roughly `max_concurrent_sessions * 4`. SQLite is
configured in WAL mode at startup so concurrent writers don't lock each other
out. Override per-run with `devtraj analyze --max-concurrent-sessions N`.

**Two-stage pipeline** (applied to each sampled session): cheap summary then
strong score.

**Stage 1 — cheap model (Haiku 4.5 default):** Summarize each session into a ~200-token "engineering profile":
- What was the user trying to do?
- How did they frame the problem?
- Where did they get stuck?
- What did they push back on?
- What's the domain?
- What language(s) were involved (if any)?

**Stage 2 — stronger model (Sonnet 4.6 default):** Score from the summary plus 3–5 verbatim user turns chosen for signal density (first message, first pushback, longest message, last message).

Both model IDs are configurable; defaults track the current best price-performance pick at release time.

This keeps cost linear in session count and gives something inspectable when scores look wrong.

### 4.4 Score

Structured output, JSON-schema enforced:

```json
{
  "problem_decomposition": 1-5,
  "systems_thinking": 1-5,
  "debugging_methodology": 1-5,
  "technical_communication": 1-5,
  "model_redirection": 1-5,
  "domain_category": "frontend|backend|mobile|data_ml|infra_devops|systems|security|tooling|docs|other",
  "domain_detail": "string (free-form, optional, local-only)",
  "language": "python|typescript|javascript|java|go|rust|c|cpp|csharp|ruby|swift|kotlin|php|shell|sql|other|null",
  "mode": "prototyping|debugging|refactoring|learning|exploration",
  "confidence": 0.0-1.0,
  "evidence_quotes": ["..."],
  "seniority_band": "junior|mid|senior|staff|principal",
  "inferred_ic_level": "IC2|IC3|IC4|IC5|IC6",
  "rubric_version": "string"
}
```

**Domain handling.** `domain_category` is a closed enum of 10 buckets, chosen to be coarse enough that buckets actually fill up in a real session corpus and to give the dashboard's per-domain view something stable to aggregate over. `domain_detail` is optional free-form text the judge can use to make the local hover-card readable (e.g. *"React component testing"*, *"PostgreSQL query planning"*) — it never leaves the machine and is omitted from any telemetry payload. If the corpus surfaces domains the enum doesn't cover well, extend the enum in a schema-version bump rather than letting `domain_detail` carry the load.

**Language handling.** `language` is a closed enum and is **nullable** — set to `null` for sessions where no specific language dominates (planning conversations, doc edits, tooling/CLI work that's mostly shell, infra discussions). The judge picks the language with the most user-authored signal in the session; multi-language sessions take the dominant one rather than emitting a list (keeps aggregation tractable). Sent through telemetry along with the other enum fields.

**Seniority surfacing.** `seniority_band` (junior / mid / senior / staff / principal) is the primary signal shown to the user — it maps to language people actually use and extends past senior so the ladder doesn't compress everyone above mid into one bucket. `inferred_ic_level` is kept as a secondary, more-granular field (rough mapping: IC2≈junior, IC3≈mid, IC4≈senior, IC5≈staff, IC6≈principal) for users who want it, but the dashboard defaults to bands.

**Rubric anchors.** The few-shot examples in the system prompt are derived from CircleCI's published engineering competency matrix — chosen because it has explicit observable behavioral indicators per level (which is exactly what the judge needs) rather than vague trait language. Anchors are paraphrased, not copied verbatim, and CircleCI is credited in the README and rubric file. `rubric_version` is emitted with every score so that re-scores after rubric changes are trackable (see §6 for the re-scoring policy).

Required to make this work:

- **Anchored rubric.** 2–3 few-shot examples at known levels in the system prompt, derived from CircleCI's matrix. Cache it.
- **Forced evidence quotes.** Each dimension score must cite a verbatim user turn. This kills 80% of vibes-based drift.
- **Median-of-3.** Run scoring three times per session, take the median per dimension. Flag high-variance sessions for review.
- **Confidence gating.** Sessions with `confidence < 0.5` are hidden from the dashboard by default; a "show low-confidence" toggle exposes them with a visible flag.

### 4.5 Aggregate

Don't plot per-session — too noisy.

- Bucket **weekly** (default; biweekly available behind a flag for sparser users).
- Per bucket: median + IQR band, weighted by session length.
- **Default view: per-domain**, not aggregate. The aggregate line lies; per-domain lines tell the truth.
- Per-language view available as a secondary breakdown.
- Hover on any point reveals the evidence quotes for that bucket.

The hover-to-evidence is the thing that makes this useful rather than a parlor trick. Without it, users dismiss the scores. With it, they engage with the underlying reasoning.

---

## 5. Distribution Strategy

Three shapes, in order:

### 5.1 Python CLI (primary)

```
pip install dev-trajectory
devtraj init                    # configure API key, scan paths, telemetry prompt
devtraj analyze                 # run pipeline on new sessions
devtraj report                  # serve local dashboard
devtraj explain <week>          # show evidence for a specific bucket
devtraj telemetry on|off|status # toggle aggregate-study contribution
```

(Console-script name `devtraj` is provisional — happy to rename if it clashes with anything common on $PATH.)

**`init` flow.** The `init` command walks the user through three things:
1. API key configuration.
2. Session-path scan (Claude Code; Codex once Phase 6 lands).
3. Telemetry prompt: *"Contribute anonymous trajectory data (no quotes, no code, no identifiers) to the aggregate dev-trajectory study? Default: no. You can change this any time with `devtraj telemetry on|off`."* The choice is stored locally in the config file. The last line of the `init` log restates the toggle command so it's visible even if the user clicked through.

The README must document `devtraj telemetry` in the same section as the privacy posture — see §8 and §10.

Why primary: full control over the two-stage pipeline, prompt caching, persistence, retries. The dashboard is the actual product, and dashboards want persistent local state.

### 5.2 MCP Server (second)

Expose `analyze_sessions`, `get_trajectory`, `explain_week` as MCP tools. Any MCP-compatible client (Claude Desktop, Claude Code, eventually Codex) can call them. Shares ~90% of code with the CLI.

Most future-proof shape for cross-ecosystem use.

### 5.3 Skill wrapper (third)

Thin Claude/Codex skill that shells out to the CLI and summarizes results in chat. Distribution surface, not a standalone implementation. Shipping this first would cost more (every run hits the user's token budget) and constrain the architecture.

---

## 6. Implementation Phases

### Phase 0 — Spike (~1 week)

- Verify Claude Code session file locations across macOS/Linux/Windows.
- Parse 50 real sessions to confirm the format assumptions.
- Draft v1 of the rubric (dimensions, anchors, few-shot examples) and run it against ~20 sessions.
- **Decision gate:** do the rubric scores look internally consistent across re-runs of the same session (median-of-3 spread ≤ 1 level on most dimensions) and do the band assignments (junior / mid / senior / staff / principal) match a quick eyeball read of the sessions? If not, iterate on the rubric before building anything else.
- *Hand-scoring is explicitly skipped* — building a hand-labeled ground-truth set is its own project. We trust the structural mitigations (anchored rubric, evidence quotes, median-of-3, confidence gating) plus inspectable summaries to keep drift in check.

### Phase 1 — Core CLI, Claude Code only (~2–3 weeks)

- Discovery + parsing for **Claude Code only**.
- Two-stage scoring with prompt caching.
- SQLite persistence (sessions, scores, evidence). Stable session ID = `sha256(file_path + first_message_uuid)`.
- Basic CLI: `init`, `analyze`, `report`, `explain`, `telemetry`, `rescore`.
- Median-of-3 with variance flagging.
- **Re-scoring policy:** every score row stores its `rubric_version`. The tool never auto-re-scores when the rubric changes. `devtraj rescore --since <version>` re-runs scoring on rows older than the given version; `devtraj rescore --all` blows away cached scores and re-runs everything (warns about cost first).

### Phase 2 — Dashboard (delivered)

- Plotly served by a local FastAPI/uvicorn server on `127.0.0.1:8765` (single-user, no auth, no CDN — Plotly's JS is bundled via the `plotly` Python package). `devtraj serve` opens the browser by default; `--no-open` to disable.
- Two chart modes the user can toggle between: (a) weekly-median lines per domain, and (b) per-session scatter with per-domain best-fit lines (in-house OLS, no numpy/statsmodels).
- Click → evidence side panel: a bucket click loads every session in that (week, domain); a scatter click loads that one session. Each card expands to the full re-parsed user-turn text from the JSONL on disk.
- Filters: dimension, domain, language, mode, date range, min_confidence. Multi-select for the categorical filters; range slider for confidence.
- Aggregate-mode (no per-domain coloring) was deferred — Plotly's legend toggling already covers focus-on-one-domain, and a real "all combined" line would mostly mislead per the §2 caveat.

### Phase 3 — OSS Polish (~1 week)

- README with bias caveats prominently above features.
- Config: model selection, dimension weights, session exclusions.
- Privacy posture (see §8): user's own API key, local-only storage, zero telemetry. No automatic redaction — the scope is single-user, results never leave the machine, and redaction would degrade the evidence-quote feature that makes the dashboard credible.
- License (MIT or Apache-2.0).
- Contribution guide.

### Phase 4 — MCP Server (~1 week)

- Wrap core pipeline as MCP tools.
- Test with Claude Desktop and Claude Code.
- Document setup for both clients.

### Phase 5 — Skill (~few days)

- Thin Claude skill in `~/.claude/skills/` that invokes the CLI.

### Phase 6 — Codex CLI support (~1 week, only if format has stabilized)

- Add Codex parser behind the same discover/parse interface used by Claude Code.
- Verify scoring output looks sane on a sample of Codex sessions (rubric should be tool-agnostic, but worth checking).
- Backfill MCP and skill surfaces.
- Skipped if the Codex session format is still actively churning at this point.

---

## 7. Tools & Stack

| Layer     | Choice                                 | Rationale                                |
| --------- | -------------------------------------- | ---------------------------------------- |
| Language  | Python 3.11+                           | Anthropic SDK, ecosystem, fast iteration |
| CLI       | Typer                                  | Better DX than Click for this scope      |
| Schema    | Pydantic v2                            | Structured output validation             |
| LLM       | Anthropic SDK                          | Prompt caching is non-negotiable here    |
| Storage   | SQLite (consider DuckDB for analytics) | Local, zero-config                       |
| Dashboard | Plotly + FastAPI                       | Hover interactions, local-only serve     |
| Testing   | pytest + recorded fixtures             | Replay real sessions in CI               |
| Packaging | uv / hatch                             | Fast installs                            |
| MCP       | `mcp` Python SDK                       | Standard                                 |

**Prompt caching the rubric is the single biggest cost win** — the rubric is identical across thousands of calls and is the largest part of the prompt.

**Rough cost model:** A year of heavy Claude Code use is ~500–2000 sessions. Two-stage with caching, median-of-3, full re-scoring: low single-digit dollars total. Incremental scoring (only new sessions) is effectively free. The per-week sampling cap (§4.3) cuts spend further on dense weeks — at the default of 3/week, even a heavy user is bounded to ~150 scored sessions/year.

---

## 8. Risks & Mitigations

| Risk                             | Mitigation                                                                |
| -------------------------------- | ------------------------------------------------------------------------- |
| Sampling bias toward blind spots | Per-domain default view, meta-signal weighting, prominent caveats in UI   |
| LLM scoring drift                | Median-of-3, evidence quotes, anchored few-shot rubric, confidence gating |
| Session format drift             | Version detection, parser per known version, fail-soft on unknown         |
| User psychological impact        | "Growth areas" framing, default to per-domain, no public sharing features |
| Privacy                          | Single-user scope, user's own API key, local-only storage by default. Telemetry is **opt-in only** at `init` (default off), toggleable via `devtraj telemetry`, and restricted to anonymized aggregate trajectory data — never quotes, code, paths, or identifiers. No public sharing surface, no automatic redaction. See §10 for payload spec and residual risks. |
| Cost runaway                     | Two-stage pipeline, prompt caching, incremental scoring, configurable model |

---

## 9. Naming

Published package: **`dev-trajectory`**. Console script: **`devtraj`**. Repo currently named `eng-trajectory-analyzer` (will be renamed once the package name is locked on PyPI). Tagline: "developer trajectory analysis."

The seniority surfacing uses **junior / mid / senior / staff / principal** as the primary band (language people actually use, and wide enough not to compress everyone above mid into one bucket); the IC2–IC6 ladder is retained as a secondary, more-granular field but is not the dominant signal in the UI.

---

## 10. Scope Decisions & Non-Goals

Explicitly **out of scope** for v1:

- **Team / multi-user views.** Single-user only. Aggregating across people is a different product with different consent, privacy, and rubric concerns.
- **User-labeled ground truth / RLHF on rubric scores.** Interesting, but a separate project. v1 trusts the structural mitigations.
- **Hand-scored calibration set.** Skipped in Phase 0 — see Phase 0 notes.
- **Automatic redaction of pasted code, filenames, or secrets.** All data stays local under a user-owned API key; redaction would degrade the evidence-quote feature that makes the dashboard credible. Users who want redaction can configure session exclusions instead.
- **Default-on telemetry.** Telemetry is opt-in only — see telemetry subsection below.
- **Public sharing surfaces** (export to web, "share my chart" links, etc.).

### Telemetry (opt-in aggregate study)

`devtraj init` prompts the user, default **off**. Stored locally; toggle with `devtraj telemetry on|off|status`. README and the final line of the `init` log surface the toggle command.

**Status:** opt-in toggle, config command, and payload schema all ship in v1, but the uploader is **disabled (no-op)** until the aggregate-study endpoint, owner, and published output are decided. `devtraj telemetry status` will surface this clearly ("opted in; uploads currently disabled — no data has left your machine").

**What is sent (only if opted in *and* uploader is live):**
- Per-bucket aggregated scores: weekly median + IQR per dimension, sliced by `seniority_band`, `domain_category`, and `language` (the closed enums from §4.4 — never the free-form `domain_detail`).
- Coarse counters: total sessions analyzed in the bucket, tool (Claude Code / Codex), schema version, rubric version.
- A fresh random payload ID per upload — no persistent user ID, no machine ID.

**What is never sent:**
- Evidence quotes, user prose, code, file paths, repo names, project names.
- `domain_detail` (the free-form local-only label), raw timestamps below week granularity.
- API keys, machine fingerprints, IP addresses (the receiver should drop IPs at ingest).
- Per-session data — only bucket aggregates.

**Residual risks (be honest about these in the README):**
- Even aggregated trajectory vectors are partially identifying when rich enough. Mitigation: report only bucket aggregates, not per-session; suppress buckets with fewer than N sessions; use a controlled domain vocabulary so users can't be fingerprinted by unusual domain strings.
- A future change to the payload schema must re-prompt, not silently expand. Schema version is included so receivers can reject unknown versions and the client can warn the user when its outgoing schema changes.

Open questions still on the table:

- Codex CLI parser cadence — addressed structurally by deferring Codex support to Phase 6 and only building it once the format has stabilized.
- Whether `seniority_band` boundaries (junior / mid / senior / staff / principal) need user-configurable cutoffs, or whether the LLM judge assigning bands directly is enough. Staff and principal especially are fuzzy across companies — the rubric anchors will need to lean on observable behaviors (scope of considerations, framing of trade-offs) rather than ladder language.
- Where the aggregate-study endpoint lives, who owns it, and what the published study output looks like. Telemetry shouldn't ship until that's decided — uploading data with no clear destination or output is not a credible "contribute to a study" pitch.

---

## 11. Success Criteria

- A user with 6+ months of Claude Code session history can run `devtraj analyze` once and produce a chart that surfaces at least one non-obvious pattern about their work (a domain they're stronger in than they thought, a mode where they consistently push back on the model, etc.).
- Median-of-3 spread on the same session is ≤ 1 level on most dimensions, and `seniority_band` is stable across re-runs (no flipping more than one band on the same session — e.g. mid↔senior is acceptable noise; junior↔staff is not).
- Setup-to-first-chart time under 10 minutes for a new user with an API key.
- Zero negative-feedback incidents traceable to the framing of results in the dashboard.
