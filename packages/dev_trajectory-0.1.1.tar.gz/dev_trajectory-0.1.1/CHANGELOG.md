# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] — 2026-04-29

First public release.

### Added
- **Discover** Claude Code sessions under `~/.claude/projects/` (and any
  configured `custom_session_paths`), keyed by the file's first message UUID
  so re-runs are idempotent.
- **Parse** JSONL transcripts into ordered user turns with optional
  tool-output truncation.
- **Sample** with a deterministic per-week cap (default 3 sessions per ISO
  week; `0` disables) so re-running `analyze` always picks the same sessions.
- **Stage 1 / Stage 2 scoring** via the Anthropic API: a per-session profile
  summary (Haiku 4.5) followed by median-of-3 rubric scoring (Sonnet 4.6).
  Five dimensions on a 1–5 scale: `problem_decomposition`,
  `systems_thinking`, `debugging_methodology`, `technical_communication`,
  `model_redirection`. Forced verbatim evidence quotes for every score.
- **Storage** in SQLite under the platform user-data directory, with
  rubric-version columns so older scores can be re-scored without losing
  history.
- **CLI** (`devtraj`):
  - `init` — interactive setup, API key handling, session discovery preview.
  - `analyze` — discover + summarize + score new sessions in parallel
    (default 10 concurrent sessions, ~4× LLM calls in flight per session).
  - `report` — weekly trajectory tables sliced by domain, language, or all.
  - `explain YYYY-MM-DD` — evidence quotes for one ISO-week.
  - `rescore` — re-score sessions whose stored rubric version is older.
  - `serve` — local dashboard at `127.0.0.1:8765`.
  - `paths` — print config and database paths.
  - `telemetry on|off|status` — local consent flag (uploader is hard-disabled
    in this build).
- **Dashboard** (`devtraj serve`): two chart modes — weekly-median lines per
  domain, and per-session scatter with per-domain best-fit. Click any point or
  bucket to load evidence quotes in the side panel; expand a session card for
  the full re-parsed user-turn text.
- **Privacy posture**: local-only storage, user-supplied API key, no
  telemetry uploader, deliberate non-redaction of evidence quotes (data never
  leaves the machine).

[Unreleased]: https://github.com/NuoWenLei/eng-trajectory-analyzer/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/NuoWenLei/eng-trajectory-analyzer/releases/tag/v0.1.0
