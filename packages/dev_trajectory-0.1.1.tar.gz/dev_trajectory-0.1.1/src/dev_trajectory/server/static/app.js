"use strict";

// ----- state ----------------------------------------------------------------

const state = {
  dimension: "overall",
  chartType: "line", // 'line' | 'scatter'
  filters: {
    domains: [],
    languages: [],
    modes: [],
    minConfidence: 0.5,
    dateFrom: null,
    dateTo: null,
  },
  data: null, // last /api/trajectory response
};

// Stable color per domain so traces stay the same between filter changes.
const DOMAIN_COLORS = {
  frontend: "#7c9cff",
  backend: "#f4a261",
  mobile: "#e76f51",
  data_ml: "#6fbf73",
  infra_devops: "#bc8cff",
  systems: "#e9c46a",
  security: "#d96d77",
  tooling: "#7fdbda",
  docs: "#c8cee0",
  other: "#8a92a4",
};

function colorForDomain(domain) {
  return DOMAIN_COLORS[domain] || "#8a92a4";
}

// ----- helpers --------------------------------------------------------------

function $(id) {
  return document.getElementById(id);
}

function setStatus(text, cls = "") {
  const el = $("status");
  el.textContent = text;
  el.className = "status " + cls;
}

function selectedValues(containerEl) {
  return Array.from(
    containerEl.querySelectorAll('input[type="checkbox"]:checked')
  ).map((c) => c.value);
}

function populateCheckboxList(containerEl, options) {
  const previouslyChecked = new Set(selectedValues(containerEl));
  containerEl.innerHTML = "";
  options.forEach((opt) => {
    const label = document.createElement("label");
    label.className = "checkbox-item";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.value = opt;
    if (previouslyChecked.has(opt)) cb.checked = true;
    label.appendChild(cb);
    const span = document.createElement("span");
    span.className = "checkbox-span";
    span.innerText = " " + opt;
    label.appendChild(span);
    containerEl.appendChild(label);
  });
}

function clearCheckboxList(containerEl) {
  containerEl.querySelectorAll('input[type="checkbox"]').forEach((c) => {
    c.checked = false;
  });
}

function buildQueryString(params) {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v === null || v === undefined || v === "") return;
    if (Array.isArray(v)) {
      if (v.length) q.set(k, v.join(","));
    } else {
      q.set(k, v);
    }
  });
  return q.toString();
}

// ----- data loading ---------------------------------------------------------

async function loadFilterOptions() {
  const r = await fetch("/api/filters");
  if (!r.ok) throw new Error("filter options failed: " + r.status);
  const data = await r.json();
  populateCheckboxList($("domains"), data.domains);
  populateCheckboxList($("languages"), data.languages);
  populateCheckboxList($("modes"), data.modes);
  updateClearButtonStates();
}

async function loadTrajectory() {
  setStatus("loading…");
  const qs = buildQueryString({
    dimension: state.dimension,
    domains: state.filters.domains,
    languages: state.filters.languages,
    modes: state.filters.modes,
    min_confidence: state.filters.minConfidence,
    date_from: state.filters.dateFrom,
    date_to: state.filters.dateTo,
  });
  const r = await fetch(`/api/trajectory?${qs}`);
  if (!r.ok) {
    setStatus(`error: ${r.status}`, "error");
    return;
  }
  state.data = await r.json();
  $("n-sessions").textContent = state.data.n_sessions;
  setStatus(
    `${state.data.n_sessions} sessions, rubric ${state.data.rubric_version}`,
    "ok"
  );
  renderChart();
}

// ----- chart rendering ------------------------------------------------------

function renderChart() {
  if (!state.data) return;
  if (state.chartType === "line") return renderLineChart();
  return renderScatterChart();
}

function renderLineChart() {
  const buckets = state.data.buckets;
  const byDomain = {};
  buckets.forEach((b) => {
    if (!byDomain[b.slice_key]) byDomain[b.slice_key] = [];
    byDomain[b.slice_key].push(b);
  });

  const traces = Object.entries(byDomain).map(([domain, items]) => {
    items.sort((a, b) => a.week_start.localeCompare(b.week_start));
    return {
      type: "scatter",
      mode: "lines+markers",
      name: domain,
      x: items.map((b) => b.week_start),
      y: items.map((b) => b.median),
      customdata: items.map((b) => [
        b.n,
        b.modal_band || "?",
        b.iqr_low,
        b.iqr_high,
        domain,
      ]),
      hovertemplate:
        "<b>%{x}</b> · %{customdata[4]}<br>" +
        "median %{y:.2f} · n=%{customdata[0]}<br>" +
        "IQR [%{customdata[2]}, %{customdata[3]}]<br>" +
        "modal band: %{customdata[1]}<extra></extra>",
      line: { color: colorForDomain(domain), width: 2 },
      marker: { size: 8, color: colorForDomain(domain) },
    };
  });

  const layout = baseLayout(`${state.dimension} — weekly median per domain`);
  applyYAxisForDimension(layout, "median score");

  Plotly.react("chart", traces, layout, plotlyConfig());
  attachLineClickHandler();
}

function renderScatterChart() {
  const sessions = state.data.sessions;
  const byDomain = {};
  sessions.forEach((s) => {
    if (!byDomain[s.domain_category]) byDomain[s.domain_category] = [];
    byDomain[s.domain_category].push(s);
  });

  const traces = [];
  Object.entries(byDomain).forEach(([domain, items]) => {
    // Slight y-jitter so overlapping integer scores are distinguishable.
    const jitter = items.map(() => (Math.random() - 0.5) * 0.25);
    traces.push({
      type: "scattergl",
      mode: "markers",
      name: domain,
      legendgroup: domain,
      x: items.map((s) => s.anchor_ts),
      y: items.map((s, i) => s.value + jitter[i]),
      customdata: items.map((s) => [
        s.session_id,
        s.value,
        s.seniority_band,
        s.confidence,
        s.language || "—",
        domain,
      ]),
      hovertemplate:
        "<b>%{customdata[5]}</b> · %{x|%Y-%m-%d}<br>" +
        "score %{customdata[1]} · band %{customdata[2]}<br>" +
        "lang %{customdata[4]} · conf %{customdata[3]:.2f}<extra></extra>",
      marker: {
        color: colorForDomain(domain),
        size: 8,
        opacity: 0.75,
        line: { width: 0 },
      },
    });
  });

  // Per-domain best-fit lines from the server's regression payload.
  Object.entries(state.data.regression_per_domain).forEach(([domain, reg]) => {
    traces.push({
      type: "scatter",
      mode: "lines",
      name: `${domain} fit`,
      legendgroup: domain,
      showlegend: false,
      x: [reg.x_min_iso, reg.x_max_iso],
      y: [reg.y_at_x_min, reg.y_at_x_max],
      hoverinfo: "skip",
      line: { color: colorForDomain(domain), width: 2, dash: "dot" },
    });
  });

  const layout = baseLayout(
    `${state.dimension} — per-session scatter with per-domain best fit`
  );
  applyYAxisForDimension(layout, "score (jittered)");

  Plotly.react("chart", traces, layout, plotlyConfig());
  attachScatterClickHandler();
}

function applyYAxisForDimension(layout, title) {
  // "overall" sums the five 1–5 dimensions, so its range is 5–25 with major
  // ticks every 5. Per-dimension scores stay 1–5 with dtick=1.
  if (state.dimension === "overall") {
    layout.yaxis.range = [4.5, 25.5];
    layout.yaxis.dtick = 5;
  } else {
    layout.yaxis.range = [0.5, 5.5];
    layout.yaxis.dtick = 1;
  }
  layout.yaxis.title = title;
}

function baseLayout(title) {
  return {
    title: { text: title, font: { size: 14, color: "#e6e8ef" } },
    paper_bgcolor: "#0f1117",
    plot_bgcolor: "#0f1117",
    font: { color: "#e6e8ef", family: "ui-sans-serif, system-ui" },
    margin: { t: 50, r: 20, b: 50, l: 50 },
    xaxis: { gridcolor: "#2a2e3c", zerolinecolor: "#2a2e3c", title: "date" },
    yaxis: { gridcolor: "#2a2e3c", zerolinecolor: "#2a2e3c", dtick: 1 },
    legend: { orientation: "h", y: -0.18 },
    hovermode: "closest",
  };
}

function plotlyConfig() {
  return {
    displayModeBar: true,
    modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"],
    responsive: true,
    displaylogo: false,
  };
}

// ----- click → evidence -----------------------------------------------------

function attachLineClickHandler() {
  const chart = $("chart");
  chart.removeAllListeners && chart.removeAllListeners("plotly_click");
  chart.on("plotly_click", async (ev) => {
    if (!ev.points || !ev.points.length) return;
    const pt = ev.points[0];
    const customdata = pt.customdata;
    if (!customdata) return;
    const domain = customdata[4];
    const week = pt.x;
    await loadEvidenceBucket(week, domain);
  });
}

function attachScatterClickHandler() {
  const chart = $("chart");
  chart.removeAllListeners && chart.removeAllListeners("plotly_click");
  chart.on("plotly_click", async (ev) => {
    if (!ev.points || !ev.points.length) return;
    const pt = ev.points[0];
    const customdata = pt.customdata;
    if (!customdata) return;
    const sessionId = customdata[0];
    await loadEvidenceSession(sessionId);
  });
}

async function loadEvidenceBucket(weekStart, domain) {
  const evd = $("evidence");
  evd.innerHTML = `<h2>Evidence</h2><p class="muted">Loading ${weekStart} · ${domain}…</p>`;
  const qs = new URLSearchParams({
    week_start: weekStart,
    domain_category: domain,
  });
  const r = await fetch(`/api/evidence/bucket?${qs}`);
  if (!r.ok) {
    evd.innerHTML = `<h2>Evidence</h2><p class="muted">Error: ${r.status}</p>`;
    return;
  }
  const data = await r.json();
  renderEvidence(`${weekStart} · ${domain}`, data.sessions);
}

async function loadEvidenceSession(sessionId) {
  const evd = $("evidence");
  evd.innerHTML = `<h2>Evidence</h2><p class="muted">Loading session…</p>`;
  const r = await fetch(
    `/api/evidence/session/${encodeURIComponent(sessionId)}`
  );
  if (!r.ok) {
    evd.innerHTML = `<h2>Evidence</h2><p class="muted">Error: ${r.status}</p>`;
    return;
  }
  const session = await r.json();
  renderEvidence(`session ${sessionId.slice(0, 10)}…`, [session]);
}

function renderEvidence(headline, sessions) {
  const evd = $("evidence");
  if (!sessions.length) {
    evd.innerHTML = `<h2>Evidence</h2><p class="muted">${headline}: no sessions matched.</p>`;
    return;
  }
  const cards = sessions.map(sessionCardHtml).join("");
  evd.innerHTML = `<h2>${escapeHtml(headline)}</h2>${cards}`;
  // Wire up "load full session" buttons.
  evd.querySelectorAll("details[data-session]").forEach((d) => {
    d.addEventListener(
      "toggle",
      async () => {
        if (d.open && !d.dataset.loaded) {
          d.dataset.loaded = "1";
          const sid = d.dataset.session;
          const slot = d.querySelector(".full-text");
          slot.textContent = "Loading…";
          const r = await fetch(`/api/session/${encodeURIComponent(sid)}/text`);
          if (!r.ok) {
            slot.textContent = `Error loading session: ${r.status}`;
            return;
          }
          const data = await r.json();
          slot.textContent = data.turns
            .map(
              (t, i) =>
                `── turn ${t.index} (${t.char_count} chars)\n` + t.user_text
            )
            .join("\n\n");
        }
      },
      { once: false }
    );
  });
}

function sessionCardHtml(s) {
  const dims = s.dimensions || {};
  const dimList = Object.entries(dims)
    .map(([k, v]) => `${k.slice(0, 6)}=${v}`)
    .join(" · ");
  const detail = s.domain_detail ? ` · ${escapeHtml(s.domain_detail)}` : "";
  const quotes = (s.evidence_quotes || [])
    .map((q) => `<blockquote>${escapeHtml(q)}</blockquote>`)
    .join("");
  const tsLine = s.anchor_ts
    ? new Date(s.anchor_ts).toISOString().slice(0, 10)
    : "—";
  return `
    <div class="session-card">
      <div class="meta-row">
        <span class="pill">${tsLine}</span>
        <span class="pill">${escapeHtml(s.seniority_band || "?")}</span>
        <span class="pill">${escapeHtml(
          s.domain_category || "?"
        )}${detail}</span>
        <span class="pill">${escapeHtml(s.language || "—")}</span>
        <span class="pill">conf ${(s.confidence || 0).toFixed(2)}</span>
      </div>
      <div class="muted" style="font-size: 11px; margin-bottom: 6px;">${escapeHtml(
        dimList
      )}</div>
      ${quotes}
      <details data-session="${escapeHtml(s.session_id)}">
        <summary>view full session text</summary>
        <pre class="full-text"></pre>
      </details>
    </div>
  `;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// ----- wiring ---------------------------------------------------------------

function wire() {
  $("dimension").addEventListener("change", (e) => {
    state.dimension = e.target.value;
    loadTrajectory();
  });

  document.querySelectorAll(".toggle button").forEach((btn) => {
    btn.addEventListener("click", () => {
      document
        .querySelectorAll(".toggle button")
        .forEach((b) => b.classList.remove("toggle-on"));
      btn.classList.add("toggle-on");
      state.chartType = btn.dataset.chart;
      renderChart();
    });
  });

  $("min-confidence").addEventListener("input", (e) => {
    $("conf-value").textContent = Number(e.target.value).toFixed(2);
  });
  $("min-confidence").addEventListener("change", (e) => {
    state.filters.minConfidence = Number(e.target.value);
    loadTrajectory();
  });

  ["domains", "languages", "modes"].forEach((id) => {
    $(id).addEventListener("change", () => {
      state.filters.domains = selectedValues($("domains"));
      state.filters.languages = selectedValues($("languages"));
      state.filters.modes = selectedValues($("modes"));
      updateClearButtonStates();
      loadTrajectory();
    });
  });

  document.querySelectorAll(".clear-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.target;
      const container = $(target);
      if (!container) return;
      clearCheckboxList(container);
      // Manually fire a change event so the listener above re-runs.
      container.dispatchEvent(new Event("change", { bubbles: true }));
    });
  });
}

function updateClearButtonStates() {
  document.querySelectorAll(".clear-btn").forEach((btn) => {
    const container = $(btn.dataset.target);
    if (!container) return;
    const anyChecked =
      container.querySelector('input[type="checkbox"]:checked') !== null;
    btn.disabled = !anyChecked;
  });

  $("date-from").addEventListener("change", (e) => {
    state.filters.dateFrom = e.target.value || null;
    loadTrajectory();
  });
  $("date-to").addEventListener("change", (e) => {
    state.filters.dateTo = e.target.value || null;
    loadTrajectory();
  });
}

(async function main() {
  wire();
  try {
    await loadFilterOptions();
    await loadTrajectory();
  } catch (err) {
    setStatus("error: " + err.message, "error");
  }
})();
