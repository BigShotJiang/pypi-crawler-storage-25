"""FastAPI app for the local dashboard.

Single-user, 127.0.0.1 only, no auth. The server is read-only against the
SQLite store; nothing here mutates state.
"""
from __future__ import annotations

from datetime import date
from importlib import resources
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse, Response

from ..config import Config, db_path, load_config
from ..models import DIMENSION_FIELDS
from ..storage import Storage
from . import queries
from .queries import ALLOWED_DIMENSIONS, Filters


def create_app(*, cfg: Config | None = None, storage: Storage | None = None) -> FastAPI:
    """Build a fresh FastAPI app. Tests construct their own Config + Storage."""
    cfg = cfg or load_config()
    storage = storage or Storage(db_path())

    app = FastAPI(title="dev-trajectory dashboard", docs_url=None, redoc_url=None)

    static_dir = _static_dir()

    def _config() -> Config:
        return cfg

    def _storage() -> Storage:
        return storage

    @app.get("/", response_class=HTMLResponse)
    def index() -> HTMLResponse:
        html = (static_dir / "index.html").read_text(encoding="utf-8")
        return HTMLResponse(html)

    @app.get("/static/{name}", include_in_schema=False)
    def static(name: str) -> Response:
        # Constrain to known files to avoid path traversal.
        if name not in {"app.js", "style.css"}:
            raise HTTPException(status_code=404)
        return FileResponse(static_dir / name)

    @app.get("/api/plotly.js", include_in_schema=False)
    def plotly_js() -> PlainTextResponse:
        # Lazy import to avoid the cost when the dashboard isn't being used.
        from plotly.offline import get_plotlyjs

        return PlainTextResponse(get_plotlyjs(), media_type="application/javascript")

    @app.get("/api/health")
    def health(cfg: Config = Depends(_config)) -> dict:
        return {"ok": True, "rubric_version": cfg.rubric_version}

    @app.get("/api/filters")
    def filters(
        cfg: Config = Depends(_config),
        storage: Storage = Depends(_storage),
    ) -> dict:
        return queries.all_filter_options(storage, rubric_version=cfg.rubric_version)

    @app.get("/api/trajectory")
    def trajectory(
        dimension: str = Query(..., description="One of the five dimension fields."),
        domains: Optional[str] = Query(None, description="Comma-separated domain_category list."),
        languages: Optional[str] = Query(None),
        modes: Optional[str] = Query(None),
        seniority_bands: Optional[str] = Query(None),
        min_confidence: float = Query(0.5, ge=0.0, le=1.0),
        date_from: Optional[date] = Query(None),
        date_to: Optional[date] = Query(None),
        cfg: Config = Depends(_config),
        storage: Storage = Depends(_storage),
    ) -> dict:
        if dimension not in ALLOWED_DIMENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"dimension must be one of {list(ALLOWED_DIMENSIONS)}",
            )
        f = Filters(
            dimension=dimension,
            domains=_split(domains),
            languages=_split(languages),
            modes=_split(modes),
            seniority_bands=_split(seniority_bands),
            min_confidence=min_confidence,
            date_from=date_from,
            date_to=date_to,
        )
        return queries.trajectory(storage, rubric_version=cfg.rubric_version, filters=f)

    @app.get("/api/evidence/bucket")
    def evidence_bucket(
        week_start: date,
        domain_category: str,
        cfg: Config = Depends(_config),
        storage: Storage = Depends(_storage),
    ) -> dict:
        items = queries.evidence_for_bucket(
            storage,
            rubric_version=cfg.rubric_version,
            week_start=week_start,
            domain_category=domain_category,
        )
        return {"week_start": week_start.isoformat(), "domain_category": domain_category, "sessions": items}

    @app.get("/api/evidence/session/{session_id}")
    def evidence_session(
        session_id: str,
        cfg: Config = Depends(_config),
        storage: Storage = Depends(_storage),
    ) -> dict:
        payload = queries.evidence_for_session(
            storage,
            rubric_version=cfg.rubric_version,
            session_id=session_id,
        )
        if payload is None:
            raise HTTPException(status_code=404, detail="session not found")
        return payload

    @app.get("/api/session/{session_id}/text")
    def session_text(
        session_id: str,
        cfg: Config = Depends(_config),
        storage: Storage = Depends(_storage),
    ) -> dict:
        payload = queries.full_session_text(
            storage,
            session_id,
            tool_output_token_limit=cfg.tool_output_token_limit,
        )
        if payload is None:
            raise HTTPException(status_code=404, detail="session not found or file missing")
        return payload

    return app


def _split(raw: str | None) -> list[str] | None:
    if not raw:
        return None
    return [v.strip() for v in raw.split(",") if v.strip()]


def _static_dir() -> Path:
    """Return the path to the bundled static assets, working under both editable and wheel installs."""
    return Path(str(resources.files("dev_trajectory.server").joinpath("static")))
