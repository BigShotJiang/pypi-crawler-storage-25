"""Read-side data shaping for the dashboard.

Built on top of `Storage` — we don't reach past that boundary so the dashboard
honors the same rubric_version / confidence semantics the CLI does.
"""
from __future__ import annotations

import statistics
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable

from ..aggregate import bucket_weekly
from ..models import DIMENSION_FIELDS
from ..parse import parse_claude_code_session
from ..storage import StoredScore, Storage
from .regression import ols


EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)

# Synthetic dimension name: sum of the five rubric dimensions per session.
# Range is 5–25 (each component is 1–5). Median-of-sums semantics: we compute
# the sum per session, then take the median over a bucket — never the
# sum-of-medians, which would be a different (and less honest) statistic.
OVERALL = "overall"

# Dimension names the dashboard accepts on the wire. Storage still only knows
# about DIMENSION_FIELDS — `overall` is computed from those at read time.
ALLOWED_DIMENSIONS: tuple[str, ...] = DIMENSION_FIELDS + (OVERALL,)


def _dim_value(score: StoredScore, dimension: str) -> float:
    if dimension == OVERALL:
        return float(sum(score.dimensions[d] for d in DIMENSION_FIELDS))
    return float(score.dimensions[dimension])


@dataclass
class Filters:
    dimension: str
    domains: list[str] | None = None
    languages: list[str] | None = None
    modes: list[str] | None = None
    seniority_bands: list[str] | None = None
    min_confidence: float = 0.5
    date_from: date | None = None
    date_to: date | None = None


def all_filter_options(storage: Storage, *, rubric_version: str) -> dict[str, list[str]]:
    """Return the set of values present in storage for each filter dropdown."""
    scores = storage.all_scores(rubric_version=rubric_version, min_confidence=0.0)
    domains = sorted({s.domain_category for s in scores})
    languages = sorted({s.language for s in scores if s.language})
    modes = sorted({s.mode for s in scores})
    bands = sorted({s.seniority_band for s in scores})
    return {
        "dimensions": list(ALLOWED_DIMENSIONS),
        "domains": domains,
        "languages": languages,
        "modes": modes,
        "seniority_bands": bands,
    }


def trajectory(
    storage: Storage,
    *,
    rubric_version: str,
    filters: Filters,
) -> dict[str, Any]:
    """Return raw sessions, weekly buckets, and per-domain regressions for one dimension.

    `filters.dimension` may be any of the five rubric dimensions, or the
    synthetic "overall" (sum of the five). For "overall" we compute the sum
    per session and aggregate from there — bucket median is the median of
    per-session sums, IQR likewise, and the regression is fit to per-session
    sums.
    """
    if filters.dimension not in ALLOWED_DIMENSIONS:
        raise ValueError(f"Unknown dimension: {filters.dimension!r}")

    scores = storage.all_scores(rubric_version=rubric_version, min_confidence=filters.min_confidence)
    scores = [s for s in scores if _matches(s, filters)]

    sessions_payload = [
        {
            "session_id": s.session_id,
            "anchor_ts": s.anchor_ts.isoformat(),
            "value": _dim_value(s, filters.dimension),
            "domain_category": s.domain_category,
            "domain_detail": s.domain_detail,
            "language": s.language,
            "mode": s.mode,
            "seniority_band": s.seniority_band,
            "inferred_ic_level": s.inferred_ic_level,
            "confidence": s.confidence,
            "max_dimension_spread": s.max_dimension_spread,
        }
        for s in scores
    ]

    buckets = bucket_weekly(scores, slice_by="domain")
    buckets_payload = []
    for b in buckets:
        if not b.sessions:
            continue
        median, iqr_low, iqr_high = _bucket_stats(b.sessions, filters.dimension)
        buckets_payload.append({
            "week_start": b.week_start.isoformat(),
            "slice_key": b.slice_key,
            "n": len(b.sessions),
            "median": median,
            "iqr_low": iqr_low,
            "iqr_high": iqr_high,
            "modal_band": b.modal_band(),
        })

    # Per-domain regression on raw session points.
    by_domain: dict[str, list[StoredScore]] = defaultdict(list)
    for s in scores:
        by_domain[s.domain_category].append(s)

    regressions: dict[str, dict[str, Any]] = {}
    for domain, ss in by_domain.items():
        xs = [_timestamp_to_days(s.anchor_ts) for s in ss]
        ys = [_dim_value(s, filters.dimension) for s in ss]
        reg = ols(xs, ys)
        if reg is None:
            continue
        regressions[domain] = {
            "slope_per_day": reg.slope,
            "intercept": reg.intercept,
            "n": reg.n,
            "x_min_iso": _days_to_iso(reg.x_min),
            "x_max_iso": _days_to_iso(reg.x_max),
            "y_at_x_min": reg.slope * reg.x_min + reg.intercept,
            "y_at_x_max": reg.slope * reg.x_max + reg.intercept,
        }

    return {
        "dimension": filters.dimension,
        "rubric_version": rubric_version,
        "n_sessions": len(scores),
        "sessions": sessions_payload,
        "buckets": buckets_payload,
        "regression_per_domain": regressions,
    }


def _bucket_stats(sessions: list[StoredScore], dimension: str) -> tuple[float, float, float]:
    """Median + IQR for a bucket. Handles the synthetic "overall" sum dimension."""
    values = sorted(_dim_value(s, dimension) for s in sessions)
    if not values:
        return (0.0, 0.0, 0.0)
    median = statistics.median(values)
    if len(values) < 4:
        return (median, float(values[0]), float(values[-1]))
    q1 = statistics.quantiles(values, n=4)[0]
    q3 = statistics.quantiles(values, n=4)[2]
    return (median, q1, q3)


def evidence_for_bucket(
    storage: Storage,
    *,
    rubric_version: str,
    week_start: date,
    domain_category: str,
    min_confidence: float = 0.0,
) -> list[dict[str, Any]]:
    """Return all sessions in a (week, domain) bucket with their evidence quotes."""
    scores = storage.all_scores(rubric_version=rubric_version, min_confidence=min_confidence)
    week_end = week_start + timedelta(days=7)
    matched = [
        s for s in scores
        if s.domain_category == domain_category
        and week_start <= _iso_week_start(s.anchor_ts) < week_end
    ]
    return [_session_payload(s) for s in matched]


def evidence_for_session(
    storage: Storage,
    *,
    rubric_version: str,
    session_id: str,
) -> dict[str, Any] | None:
    scores = storage.all_scores(rubric_version=rubric_version, min_confidence=0.0)
    for s in scores:
        if s.session_id == session_id:
            return _session_payload(s)
    return None


def full_session_text(storage: Storage, session_id: str, *, tool_output_token_limit: int) -> dict[str, Any] | None:
    """Re-parse the JSONL file on demand and return user turns. None if the file is missing."""
    import sqlite3

    # Look up the file_path from storage. We don't have a typed accessor, so fall back to a quick read.
    with sqlite3.connect(storage.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT file_path, anchor_ts, tool FROM sessions WHERE id = ?",
            (session_id,),
        ).fetchone()
    if row is None:
        return None
    from pathlib import Path

    path = Path(row["file_path"])
    if not path.exists():
        return None
    parsed = parse_claude_code_session(path, tool_output_token_limit=tool_output_token_limit)
    return {
        "session_id": session_id,
        "file_path": str(path),
        "anchor_ts": row["anchor_ts"],
        "tool": row["tool"],
        "turns": [
            {
                "index": t.index,
                "user_text": t.user_text,
                "preceding_assistant_text": t.preceding_assistant_text,
                "char_count": t.char_count,
                "timestamp": t.timestamp.isoformat() if t.timestamp else None,
            }
            for t in parsed.turns
        ],
    }


# --- helpers -----------------------------------------------------------------


def _matches(s: StoredScore, f: Filters) -> bool:
    if f.domains and s.domain_category not in f.domains:
        return False
    if f.languages and (s.language or "none") not in f.languages:
        return False
    if f.modes and s.mode not in f.modes:
        return False
    if f.seniority_bands and s.seniority_band not in f.seniority_bands:
        return False
    if f.date_from and s.anchor_ts.date() < f.date_from:
        return False
    if f.date_to and s.anchor_ts.date() > f.date_to:
        return False
    return True


def _session_payload(s: StoredScore) -> dict[str, Any]:
    return {
        "session_id": s.session_id,
        "anchor_ts": s.anchor_ts.isoformat(),
        "domain_category": s.domain_category,
        "domain_detail": s.domain_detail,
        "language": s.language,
        "mode": s.mode,
        "seniority_band": s.seniority_band,
        "inferred_ic_level": s.inferred_ic_level,
        "confidence": s.confidence,
        "max_dimension_spread": s.max_dimension_spread,
        "evidence_quotes": list(s.evidence_quotes),
        "dimensions": dict(s.dimensions),
    }


def _timestamp_to_days(ts: datetime) -> float:
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return (ts - EPOCH).total_seconds() / 86400.0


def _days_to_iso(days: float) -> str:
    return (EPOCH + timedelta(days=days)).isoformat()


def _iso_week_start(ts: datetime) -> date:
    d = ts.date()
    return d - timedelta(days=d.weekday())
