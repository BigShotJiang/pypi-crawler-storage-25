"""Tiny ordinary-least-squares helper.

Pure-Python — we don't pull in numpy just for slope/intercept. Inputs are
floats; callers convert timestamps to days-since-epoch (or any monotonic
numeric x-axis) before calling.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Regression:
    slope: float
    intercept: float
    n: int
    x_min: float
    x_max: float


def ols(xs: list[float], ys: list[float]) -> Regression | None:
    """Return slope/intercept from y = slope * x + intercept, or None if not enough points or x has zero variance."""
    if len(xs) != len(ys):
        raise ValueError(f"xs and ys length mismatch: {len(xs)} vs {len(ys)}")
    n = len(xs)
    if n < 2:
        return None
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    denominator = sum((x - mean_x) ** 2 for x in xs)
    if denominator == 0.0:
        # All points share the same x — no defined slope.
        return None
    slope = numerator / denominator
    intercept = mean_y - slope * mean_x
    return Regression(
        slope=slope,
        intercept=intercept,
        n=n,
        x_min=min(xs),
        x_max=max(xs),
    )
