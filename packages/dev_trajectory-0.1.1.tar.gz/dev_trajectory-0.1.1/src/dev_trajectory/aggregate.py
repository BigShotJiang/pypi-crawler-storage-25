from __future__ import annotations

import statistics
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from .models import DIMENSION_FIELDS
from .storage import StoredScore


@dataclass
class Bucket:
    """One ISO week of scores, optionally sliced by domain or language."""

    week_start: date
    slice_key: str  # e.g. domain_category value, language value, or "all"
    sessions: list[StoredScore] = field(default_factory=list)

    def medians(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for dim in DIMENSION_FIELDS:
            values = [s.dimensions[dim] for s in self.sessions]
            out[dim] = statistics.median(values) if values else 0.0
        return out

    def iqr(self, dimension: str) -> tuple[float, float]:
        values = sorted(s.dimensions[dimension] for s in self.sessions)
        if not values:
            return (0.0, 0.0)
        if len(values) < 4:
            return (float(values[0]), float(values[-1]))
        q1 = statistics.quantiles(values, n=4)[0]
        q3 = statistics.quantiles(values, n=4)[2]
        return (q1, q3)

    def modal_band(self) -> str | None:
        if not self.sessions:
            return None
        counts: dict[str, int] = {}
        for s in self.sessions:
            counts[s.seniority_band] = counts.get(s.seniority_band, 0) + 1
        return max(counts.items(), key=lambda kv: kv[1])[0]


def bucket_weekly(
    scores: list[StoredScore],
    *,
    slice_by: str = "domain",
) -> list[Bucket]:
    """Group scores into ISO-week buckets, sliced by `slice_by`.

    `slice_by` ∈ {"domain", "language", "all"}.
    """
    grouped: dict[tuple[date, str], list[StoredScore]] = defaultdict(list)
    for score in scores:
        week_start = _iso_week_start(score.anchor_ts)
        slice_key = _slice_key(score, slice_by)
        grouped[(week_start, slice_key)].append(score)

    buckets = [Bucket(week_start=ws, slice_key=sk, sessions=ss) for (ws, sk), ss in grouped.items()]
    buckets.sort(key=lambda b: (b.week_start, b.slice_key))
    return buckets


def _slice_key(score: StoredScore, slice_by: str) -> str:
    if slice_by == "domain":
        return score.domain_category
    if slice_by == "language":
        return score.language or "none"
    return "all"


def _iso_week_start(ts: datetime) -> date:
    d = ts.date()
    return d - timedelta(days=d.weekday())
