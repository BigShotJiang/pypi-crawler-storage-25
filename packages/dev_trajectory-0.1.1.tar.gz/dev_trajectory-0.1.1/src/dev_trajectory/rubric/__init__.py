from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from importlib import resources
from typing import Any

import yaml


@dataclass(frozen=True)
class Rubric:
    version: str
    raw: dict[str, Any]
    system_prompt: str


@lru_cache(maxsize=1)
def load_rubric(version: str = "v1") -> Rubric:
    text = resources.files("dev_trajectory.rubric").joinpath(f"{version}.yaml").read_text(encoding="utf-8")
    data = yaml.safe_load(text)
    if not isinstance(data, dict):
        raise ValueError(f"Rubric {version}.yaml is malformed")
    if data.get("version") != version:
        raise ValueError(f"Rubric file declares version {data.get('version')!r}, expected {version!r}")
    return Rubric(version=version, raw=data, system_prompt=_render_system_prompt(data))


def _render_system_prompt(data: dict[str, Any]) -> str:
    """Render the rubric into a stable system prompt suitable for prompt caching.

    Keep the output deterministic — anything non-deterministic in here breaks
    the cache. No timestamps, no dict iteration order, no random IDs.
    """
    lines: list[str] = []
    lines.append("You are an engineering-trajectory judge.")
    lines.append("")
    lines.append(
        "You receive a short profile of a developer's coding-assistant session "
        "plus a few verbatim user turns. Score the session on five dimensions, "
        "assign a seniority band (and IC level), and cite verbatim user-turn "
        "quotes as evidence. Do not invent quotes — if you can't find one for a "
        "dimension, pick the closest available."
    )
    lines.append("")
    lines.append("## Important framing")
    lines.append("")
    lines.append(
        "- The user is using an AI coding assistant. People use AI for things "
        "they don't already know — so this measures their behavior on their "
        "blind spots, not their absolute capability."
    )
    lines.append(
        "- The `model_redirection` dimension is the cleanest seniority signal "
        "because it's least confounded by topic familiarity. Weight it more "
        "heavily than topic-conditional dimensions."
    )
    lines.append(
        "- Be calibrated, not generous. A staff/principal score on a 200-line "
        "session is rare — require strong evidence."
    )
    lines.append("")
    lines.append("## Bands")
    lines.append("")
    for name, band in data["bands"].items():
        lines.append(f"### {name} ({band['ic_level']})")
        lines.append(band["summary"].strip())
        lines.append("")

    lines.append("## Dimensions")
    lines.append("")
    for dim_name, dim in data["dimensions"].items():
        lines.append(f"### {dim_name}")
        lines.append(dim["description"].strip())
        lines.append("")
        lines.append("Anchors (1=junior … 5=principal):")
        for band_name in ("junior", "mid", "senior", "staff", "principal"):
            anchor = dim["anchors"][band_name]
            score = {"junior": 1, "mid": 2, "senior": 3, "staff": 4, "principal": 5}[band_name]
            lines.append(f"- {score} ({band_name}): {anchor.strip()}")
        lines.append("")

    lines.append("## Few-shot calibration examples")
    lines.append("")
    for example in data["few_shot_examples"]:
        lines.append(f"### Level: {example['level']} | Domain: {example['domain_category']}")
        lines.append("Excerpt:")
        lines.append(example["excerpt"].strip())
        lines.append("")
        lines.append(f"Why: {example['rationale'].strip()}")
        lines.append("")

    lines.append("## Output schema reminder")
    lines.append("")
    lines.append("- All five dimension scores are integers 1–5.")
    lines.append("- `seniority_band` ∈ junior|mid|senior|staff|principal (the primary surfaced signal).")
    lines.append("- `inferred_ic_level` ∈ IC2|IC3|IC4|IC5|IC6 (kept for callers who want more granularity).")
    lines.append("- `domain_category` is a closed enum — use `other` if nothing fits, never invent values.")
    lines.append("- `domain_detail` is optional free-form text for human display (e.g. 'React component testing').")
    lines.append("- `language` is the dominant programming language in the session, or null if no language dominates.")
    lines.append("- `confidence` (0.0–1.0) reflects how confident you are in the score given the session content. Below 0.5 means 'I don't have enough signal to score this reliably'.")
    lines.append("- `evidence_quotes` should contain 3–5 short verbatim user-turn excerpts, ideally one per dimension.")
    return "\n".join(lines).strip() + "\n"
