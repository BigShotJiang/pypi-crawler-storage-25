from __future__ import annotations

import statistics
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from anthropic import Anthropic

from .models import DIMENSION_FIELDS, Score
from .parse import Turn
from .rubric import Rubric


STAGE2_MODEL = "claude-sonnet-4-6"
STAGE2_MAX_TOKENS = 2048
MEDIAN_OF_N = 3


@dataclass
class MedianScore:
    """Aggregated result of MEDIAN_OF_N independent scoring runs."""

    runs: list[Score]
    median_dimensions: dict[str, int]
    max_dimension_spread: int
    confidence: float
    domain_category: str
    domain_detail: str | None
    language: str | None
    mode: str
    seniority_band: str
    inferred_ic_level: str
    evidence_quotes: list[str]


def score_session(
    client: Anthropic,
    rubric: Rubric,
    summary: str,
    signal_turns: list[Turn],
    *,
    n: int = MEDIAN_OF_N,
) -> MedianScore:
    """Run the Stage 2 judge `n` times in parallel and aggregate.

    The rubric system prompt is identical across runs and is marked for
    prompt caching — only the first call pays full system-prompt cost.
    """
    user_message = _build_user_message(summary, signal_turns)

    with ThreadPoolExecutor(max_workers=n) as pool:
        runs = list(pool.map(lambda _: _single_run(client, rubric, user_message), range(n)))

    return _aggregate(runs)


def _single_run(client: Anthropic, rubric: Rubric, user_message: str) -> Score:
    response = client.messages.parse(
        model=STAGE2_MODEL,
        max_tokens=STAGE2_MAX_TOKENS,
        system=[
            {
                "type": "text",
                "text": rubric.system_prompt,
                "cache_control": {"type": "ephemeral"},
            }
        ],
        messages=[{"role": "user", "content": user_message}],
        output_format=Score,
    )
    parsed = response.parsed_output
    if parsed is None:
        raise RuntimeError("Stage 2 scoring returned no parsed output")
    return parsed


def _build_user_message(summary: str, signal_turns: list[Turn]) -> str:
    lines = ["## Engineering profile (Stage 1 summary)", "", summary.strip(), "", "## Verbatim user turns"]
    for turn in signal_turns:
        lines.append("")
        lines.append(f"### Turn {turn.index} (chars={turn.char_count})")
        lines.append(turn.user_text)
    lines.append("")
    lines.append("Now score this session per the rubric. Cite verbatim from the turns above for evidence_quotes.")
    return "\n".join(lines)


def _aggregate(runs: list[Score]) -> MedianScore:
    if not runs:
        raise ValueError("Cannot aggregate zero runs")

    medians: dict[str, int] = {}
    spreads: list[int] = []
    for field in DIMENSION_FIELDS:
        values = [getattr(r, field) for r in runs]
        medians[field] = int(statistics.median(values))
        spreads.append(max(values) - min(values))

    confidence = statistics.mean(r.confidence for r in runs)

    band_pick = _modal(r.seniority_band for r in runs)
    ic_pick = _modal(r.inferred_ic_level for r in runs)
    domain_pick = _modal(r.domain_category for r in runs)
    mode_pick = _modal(r.mode for r in runs)
    language_pick = _modal((r.language for r in runs), allow_none=True)

    detail_pick = next((r.domain_detail for r in runs if r.domain_detail), None)

    evidence: list[str] = []
    seen: set[str] = set()
    for run in runs:
        for quote in run.evidence_quotes:
            quote = quote.strip()
            if quote and quote not in seen:
                evidence.append(quote)
                seen.add(quote)
            if len(evidence) >= 5:
                break
        if len(evidence) >= 5:
            break

    return MedianScore(
        runs=runs,
        median_dimensions=medians,
        max_dimension_spread=max(spreads) if spreads else 0,
        confidence=confidence,
        domain_category=domain_pick,
        domain_detail=detail_pick,
        language=language_pick,
        mode=mode_pick,
        seniority_band=band_pick,
        inferred_ic_level=ic_pick,
        evidence_quotes=evidence,
    )


def _modal(values, *, allow_none: bool = False):
    counts: dict = {}
    for v in values:
        if v is None and not allow_none:
            continue
        counts[v] = counts.get(v, 0) + 1
    if not counts:
        return None
    return max(counts.items(), key=lambda kv: kv[1])[0]
