from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


DimensionScore = Literal[1, 2, 3, 4, 5]

DomainCategory = Literal[
    "frontend",
    "backend",
    "mobile",
    "data_ml",
    "infra_devops",
    "systems",
    "security",
    "tooling",
    "docs",
    "other",
]

Mode = Literal[
    "prototyping",
    "debugging",
    "refactoring",
    "learning",
    "exploration",
]

Language = Literal[
    "python",
    "typescript",
    "javascript",
    "java",
    "go",
    "rust",
    "c",
    "cpp",
    "csharp",
    "ruby",
    "swift",
    "kotlin",
    "php",
    "shell",
    "sql",
    "other",
]

SeniorityBand = Literal["junior", "mid", "senior", "staff", "principal"]
ICLevel = Literal["IC2", "IC3", "IC4", "IC5", "IC6"]


class Score(BaseModel):
    """Per-session structured score, emitted by the Stage 2 LLM judge.

    Anything that's a free-form `Optional[str]` here is local-only and is
    omitted from telemetry payloads (see docs/PROJECT.md §10).
    """

    model_config = ConfigDict(extra="forbid")

    problem_decomposition: DimensionScore
    systems_thinking: DimensionScore
    debugging_methodology: DimensionScore
    technical_communication: DimensionScore
    model_redirection: DimensionScore

    domain_category: DomainCategory
    domain_detail: Optional[str] = Field(
        default=None,
        description="Free-form, human-readable domain label for the local hover-card. Never sent in telemetry.",
    )

    language: Optional[Language] = Field(
        default=None,
        description="Dominant programming language in the session. Null when no specific language applies (planning, docs, infra discussions).",
    )

    mode: Mode
    confidence: float = Field(ge=0.0, le=1.0)
    evidence_quotes: list[str] = Field(
        description="Verbatim user-turn excerpts that justify the dimension scores. One short quote per dimension where possible.",
    )

    seniority_band: SeniorityBand
    inferred_ic_level: ICLevel


DIMENSION_FIELDS: tuple[str, ...] = (
    "problem_decomposition",
    "systems_thinking",
    "debugging_methodology",
    "technical_communication",
    "model_redirection",
)
