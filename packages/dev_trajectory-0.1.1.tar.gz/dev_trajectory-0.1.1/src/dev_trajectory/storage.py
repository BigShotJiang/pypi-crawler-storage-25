from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from .discover import DiscoveredSession
from .models import DIMENSION_FIELDS
from .stage2 import MedianScore


SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  file_path TEXT NOT NULL,
  tool TEXT NOT NULL,
  anchor_ts TEXT NOT NULL,
  user_turn_count INTEGER NOT NULL,
  total_user_chars INTEGER NOT NULL,
  discovered_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS sessions_anchor_ts_idx ON sessions(anchor_ts);

CREATE TABLE IF NOT EXISTS summaries (
  session_id TEXT PRIMARY KEY,
  profile_text TEXT NOT NULL,
  model TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  rubric_version TEXT NOT NULL,
  problem_decomposition INTEGER NOT NULL,
  systems_thinking INTEGER NOT NULL,
  debugging_methodology INTEGER NOT NULL,
  technical_communication INTEGER NOT NULL,
  model_redirection INTEGER NOT NULL,
  domain_category TEXT NOT NULL,
  domain_detail TEXT,
  language TEXT,
  mode TEXT NOT NULL,
  confidence REAL NOT NULL,
  evidence_quotes TEXT NOT NULL,
  seniority_band TEXT NOT NULL,
  inferred_ic_level TEXT NOT NULL,
  max_dimension_spread INTEGER NOT NULL,
  model TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
  UNIQUE(session_id, rubric_version)
);

CREATE INDEX IF NOT EXISTS scores_rubric_version_idx ON scores(rubric_version);
CREATE INDEX IF NOT EXISTS scores_session_id_idx ON scores(session_id);
"""


@dataclass
class StoredScore:
    session_id: str
    rubric_version: str
    anchor_ts: datetime
    dimensions: dict[str, int]
    domain_category: str
    domain_detail: str | None
    language: str | None
    mode: str
    confidence: float
    evidence_quotes: list[str]
    seniority_band: str
    inferred_ic_level: str
    max_dimension_spread: int


class Storage:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as conn:
            conn.executescript(SCHEMA)
            # WAL lets concurrent readers/writers coexist without "database is
            # locked" errors when analyze fans out across sessions. The setting
            # persists across connections.
            conn.execute("PRAGMA journal_mode=WAL")

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def upsert_session(self, session: DiscoveredSession, *, user_turn_count: int, total_user_chars: int) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO sessions (id, file_path, tool, anchor_ts, user_turn_count, total_user_chars, discovered_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                  file_path = excluded.file_path,
                  user_turn_count = excluded.user_turn_count,
                  total_user_chars = excluded.total_user_chars
                """,
                (
                    session.id,
                    str(session.file_path),
                    session.tool,
                    session.anchor_ts.isoformat(),
                    user_turn_count,
                    total_user_chars,
                    _utcnow(),
                ),
            )

    def upsert_summary(self, session_id: str, profile_text: str, model: str) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO summaries (session_id, profile_text, model, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                  profile_text = excluded.profile_text,
                  model = excluded.model,
                  created_at = excluded.created_at
                """,
                (session_id, profile_text, model, _utcnow()),
            )

    def get_summary(self, session_id: str) -> str | None:
        with self._conn() as conn:
            row = conn.execute("SELECT profile_text FROM summaries WHERE session_id = ?", (session_id,)).fetchone()
            return row["profile_text"] if row else None

    def upsert_score(self, session_id: str, rubric_version: str, score: MedianScore, model: str) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO scores (
                  session_id, rubric_version,
                  problem_decomposition, systems_thinking, debugging_methodology,
                  technical_communication, model_redirection,
                  domain_category, domain_detail, language, mode,
                  confidence, evidence_quotes, seniority_band, inferred_ic_level,
                  max_dimension_spread, model, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(session_id, rubric_version) DO UPDATE SET
                  problem_decomposition = excluded.problem_decomposition,
                  systems_thinking = excluded.systems_thinking,
                  debugging_methodology = excluded.debugging_methodology,
                  technical_communication = excluded.technical_communication,
                  model_redirection = excluded.model_redirection,
                  domain_category = excluded.domain_category,
                  domain_detail = excluded.domain_detail,
                  language = excluded.language,
                  mode = excluded.mode,
                  confidence = excluded.confidence,
                  evidence_quotes = excluded.evidence_quotes,
                  seniority_band = excluded.seniority_band,
                  inferred_ic_level = excluded.inferred_ic_level,
                  max_dimension_spread = excluded.max_dimension_spread,
                  model = excluded.model,
                  created_at = excluded.created_at
                """,
                (
                    session_id,
                    rubric_version,
                    score.median_dimensions["problem_decomposition"],
                    score.median_dimensions["systems_thinking"],
                    score.median_dimensions["debugging_methodology"],
                    score.median_dimensions["technical_communication"],
                    score.median_dimensions["model_redirection"],
                    score.domain_category,
                    score.domain_detail,
                    score.language,
                    score.mode,
                    score.confidence,
                    json.dumps(score.evidence_quotes),
                    score.seniority_band,
                    score.inferred_ic_level,
                    score.max_dimension_spread,
                    model,
                    _utcnow(),
                ),
            )

    def has_score(self, session_id: str, rubric_version: str) -> bool:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT 1 FROM scores WHERE session_id = ? AND rubric_version = ?",
                (session_id, rubric_version),
            ).fetchone()
            return row is not None

    def session_ids(self) -> set[str]:
        with self._conn() as conn:
            return {r["id"] for r in conn.execute("SELECT id FROM sessions").fetchall()}

    def all_scores(self, *, rubric_version: str | None = None, min_confidence: float = 0.5) -> list[StoredScore]:
        query = """
            SELECT
              s.session_id, s.rubric_version,
              ses.anchor_ts,
              s.problem_decomposition, s.systems_thinking, s.debugging_methodology,
              s.technical_communication, s.model_redirection,
              s.domain_category, s.domain_detail, s.language, s.mode,
              s.confidence, s.evidence_quotes, s.seniority_band, s.inferred_ic_level,
              s.max_dimension_spread
            FROM scores s
            JOIN sessions ses ON ses.id = s.session_id
            WHERE s.confidence >= ?
        """
        params: list = [min_confidence]
        if rubric_version is not None:
            query += " AND s.rubric_version = ?"
            params.append(rubric_version)
        query += " ORDER BY ses.anchor_ts ASC"

        with self._conn() as conn:
            rows = conn.execute(query, params).fetchall()
        return [_row_to_stored(r) for r in rows]

    def scores_needing_rescore(self, current_version: str) -> list[str]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT session_id FROM scores WHERE rubric_version != ?",
                (current_version,),
            ).fetchall()
        return [r["session_id"] for r in rows]


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _row_to_stored(row: sqlite3.Row) -> StoredScore:
    return StoredScore(
        session_id=row["session_id"],
        rubric_version=row["rubric_version"],
        anchor_ts=datetime.fromisoformat(row["anchor_ts"]),
        dimensions={field: row[field] for field in DIMENSION_FIELDS},
        domain_category=row["domain_category"],
        domain_detail=row["domain_detail"],
        language=row["language"],
        mode=row["mode"],
        confidence=row["confidence"],
        evidence_quotes=json.loads(row["evidence_quotes"]),
        seniority_band=row["seniority_band"],
        inferred_ic_level=row["inferred_ic_level"],
        max_dimension_spread=row["max_dimension_spread"],
    )
