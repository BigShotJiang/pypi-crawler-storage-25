from __future__ import annotations

import threading
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path
from typing import Callable, Iterable, Iterator

from anthropic import Anthropic

from .config import Config
from .discover import DiscoveredSession, discover_claude_code_sessions
from .parse import parse_claude_code_session, select_signal_turns
from .rubric import Rubric, load_rubric
from .stage1 import STAGE1_MODEL, summarize_session
from .stage2 import STAGE2_MODEL, score_session
from .storage import Storage


@dataclass
class AnalyzeResult:
    discovered: int
    sampled: int
    skipped_existing: int
    scored: int
    failed: int
    failures: list[tuple[str, str]]


ProgressCallback = Callable[[str, DiscoveredSession], None]


def sample_per_week(sessions: Iterable[DiscoveredSession], cap: int) -> list[DiscoveredSession]:
    """Cap the number of sessions analyzed per ISO week.

    Deterministic — sorts by session_id (already a sha256, so the order is
    uniform) and takes the first `cap`. This makes re-runs of `analyze`
    idempotent: the same sessions get scored every time. `cap <= 0` disables
    the cap.
    """
    all_sessions = list(sessions)
    if cap <= 0:
        return all_sessions
    by_week: dict[date, list[DiscoveredSession]] = defaultdict(list)
    for s in all_sessions:
        week_start = s.anchor_ts.date() - timedelta(days=s.anchor_ts.date().weekday())
        by_week[week_start].append(s)
    sampled: list[DiscoveredSession] = []
    for week in sorted(by_week.keys()):
        weeks_sessions = sorted(by_week[week], key=lambda s: s.id)
        sampled.extend(weeks_sessions[:cap])
    return sampled


def discover_all(cfg: Config) -> Iterator[DiscoveredSession]:
    yield from discover_claude_code_sessions()
    for raw in cfg.custom_session_paths:
        path = Path(raw).expanduser()
        yield from discover_claude_code_sessions(path)


def analyze(
    *,
    cfg: Config,
    storage: Storage,
    client: Anthropic,
    rebuild: bool = False,
    sessions_per_week: int | None = None,
    max_concurrent_sessions: int | None = None,
    progress: ProgressCallback | None = None,
) -> AnalyzeResult:
    """Run the full discover → parse → summarize → score → persist pipeline.

    With rebuild=False, skips sessions that already have a score at the current
    rubric_version. The storage layer also dedupes on (session_id, rubric_version),
    so re-runs are idempotent.

    Sessions are processed in parallel up to `max_concurrent_sessions` (default
    from config). Each worker still calls the Stage 2 LLM 3× in parallel for
    median-of-3, so the total in-flight LLM calls is roughly
    max_concurrent_sessions * 4 (1 summary + 3 scores).

    `sessions_per_week` and `max_concurrent_sessions` override Config values
    for this run.
    """
    rubric = load_rubric(cfg.rubric_version)
    cap = sessions_per_week if sessions_per_week is not None else cfg.sessions_per_week
    workers = max_concurrent_sessions if max_concurrent_sessions is not None else cfg.max_concurrent_sessions
    workers = max(1, workers)

    discovered = list(discover_all(cfg))
    sampled = sample_per_week(discovered, cap)

    result = AnalyzeResult(
        discovered=len(discovered),
        sampled=len(sampled),
        skipped_existing=0,
        scored=0,
        failed=0,
        failures=[],
    )

    state_lock = threading.Lock()

    def _safe_progress(stage: str, session: DiscoveredSession) -> None:
        if progress is None:
            return
        with state_lock:
            progress(stage, session)

    def _process(session: DiscoveredSession) -> None:
        _safe_progress("discovered", session)

        if not rebuild and storage.has_score(session.id, cfg.rubric_version):
            with state_lock:
                result.skipped_existing += 1
            _safe_progress("skipped", session)
            return

        try:
            parsed = parse_claude_code_session(
                session.file_path,
                tool_output_token_limit=cfg.tool_output_token_limit,
            )
            storage.upsert_session(
                session,
                user_turn_count=parsed.user_turn_count,
                total_user_chars=parsed.total_user_chars,
            )
            if not parsed.turns:
                _safe_progress("empty", session)
                return

            summary = storage.get_summary(session.id)
            if summary is None or rebuild:
                _safe_progress("summarizing", session)
                summary = summarize_session(client, parsed)
                storage.upsert_summary(session.id, summary, STAGE1_MODEL)

            _safe_progress("scoring", session)
            signal_turns = select_signal_turns(parsed, max_turns=5)
            score = score_session(client, rubric, summary, signal_turns)
            storage.upsert_score(session.id, cfg.rubric_version, score, STAGE2_MODEL)
            with state_lock:
                result.scored += 1
            _safe_progress("scored", session)
        except Exception as exc:  # noqa: BLE001 — surface every failure to the user
            with state_lock:
                result.failed += 1
                result.failures.append((session.id, f"{type(exc).__name__}: {exc}"))
            _safe_progress("failed", session)

    if not sampled:
        return result

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="devtraj") as pool:
        # list() forces submission of all futures and waits for completion.
        # Worker exceptions are swallowed inside _process; nothing should
        # leak out, but list() will surface anything that does.
        list(pool.map(_process, sampled))

    return result


def rescore(
    *,
    cfg: Config,
    storage: Storage,
    client: Anthropic,
    since_version: str | None = None,
    max_concurrent_sessions: int | None = None,
    progress: ProgressCallback | None = None,
) -> AnalyzeResult:
    """Re-score sessions whose stored rubric_version is older than the current one.

    `since_version` is a placeholder for future ordered-version comparison; for
    v1 we treat it as "anything not equal to the current rubric_version".

    Parallelized across sessions up to `max_concurrent_sessions` (default from
    config), like `analyze`.
    """
    rubric = load_rubric(cfg.rubric_version)
    workers = max_concurrent_sessions if max_concurrent_sessions is not None else cfg.max_concurrent_sessions
    workers = max(1, workers)

    stale = storage.scores_needing_rescore(cfg.rubric_version)
    sessions_by_id = {s.id: s for s in discover_all(cfg) if s.id in set(stale)}

    result = AnalyzeResult(
        discovered=len(stale),
        sampled=len(stale),
        skipped_existing=0,
        scored=0,
        failed=0,
        failures=[],
    )

    state_lock = threading.Lock()

    def _safe_progress(stage: str, session: DiscoveredSession) -> None:
        if progress is None:
            return
        with state_lock:
            progress(stage, session)

    def _process(session_id: str) -> None:
        session = sessions_by_id.get(session_id)
        if session is None:
            with state_lock:
                result.failed += 1
                result.failures.append((session_id, "session file no longer discoverable"))
            return
        try:
            parsed = parse_claude_code_session(
                session.file_path,
                tool_output_token_limit=cfg.tool_output_token_limit,
            )
            if not parsed.turns:
                with state_lock:
                    result.skipped_existing += 1
                return
            _safe_progress("scoring", session)
            summary = storage.get_summary(session.id) or summarize_session(client, parsed)
            storage.upsert_summary(session.id, summary, STAGE1_MODEL)
            signal_turns = select_signal_turns(parsed, max_turns=5)
            score = score_session(client, rubric, summary, signal_turns)
            storage.upsert_score(session.id, cfg.rubric_version, score, STAGE2_MODEL)
            with state_lock:
                result.scored += 1
        except Exception as exc:  # noqa: BLE001
            with state_lock:
                result.failed += 1
                result.failures.append((session.id, f"{type(exc).__name__}: {exc}"))

    if not stale:
        return result

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="devtraj-rescore") as pool:
        list(pool.map(_process, stale))

    return result
