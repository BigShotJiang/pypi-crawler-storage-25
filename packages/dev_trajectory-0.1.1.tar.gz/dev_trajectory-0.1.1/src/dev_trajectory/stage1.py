from __future__ import annotations

from anthropic import Anthropic

from .parse import ParsedSession


STAGE1_MODEL = "claude-haiku-4-5"
STAGE1_SYSTEM = """You are summarizing a developer's coding-assistant session into a short engineering profile.

Your output is consumed by another LLM that will score the session, so optimize for signal density, not narrative.

Cover, in roughly this order, in 150–200 tokens:
1. What was the user trying to do?
2. How did they frame the problem (precise / vague, decomposed / one-shot)?
3. Where did they get stuck, and how did they react?
4. Did they push back on, correct, or redirect the model? Cite the moment if so.
5. Domain (one of: frontend, backend, mobile, data_ml, infra_devops, systems, security, tooling, docs, other).
6. Dominant programming language, or "none" if no specific language dominates.

Be specific. Avoid generalities like "the user worked on a backend feature" — say what feature, what blocked them, what they pushed back on.
"""

STAGE1_MAX_TOKENS = 400


def summarize_session(client: Anthropic, session: ParsedSession) -> str:
    """Produce a ~200-token engineering profile from the parsed session."""
    user_turns = [
        f"User turn {turn.index} (chars={turn.char_count}):\n{turn.user_text}"
        for turn in session.turns
    ]
    user_block = "\n\n---\n\n".join(user_turns) or "(no user turns extracted)"

    response = client.messages.create(
        model=STAGE1_MODEL,
        max_tokens=STAGE1_MAX_TOKENS,
        system=STAGE1_SYSTEM,
        messages=[{"role": "user", "content": user_block}],
    )

    parts = [block.text for block in response.content if getattr(block, "type", None) == "text"]
    return "\n".join(parts).strip()
