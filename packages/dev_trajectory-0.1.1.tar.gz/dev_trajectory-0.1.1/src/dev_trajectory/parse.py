from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator


DEFAULT_TOOL_OUTPUT_TOKEN_LIMIT = 2000
APPROX_CHARS_PER_TOKEN = 4


@dataclass
class Turn:
    """A single user-authored turn plus the immediately preceding assistant response (for grounding)."""

    index: int
    user_text: str
    preceding_assistant_text: str
    char_count: int
    timestamp: datetime | None


@dataclass
class ParsedSession:
    file_path: Path
    turns: list[Turn]
    total_user_chars: int
    anchor_ts: datetime

    @property
    def user_turn_count(self) -> int:
        return len(self.turns)


def parse_claude_code_session(
    file_path: Path,
    *,
    tool_output_token_limit: int = DEFAULT_TOOL_OUTPUT_TOKEN_LIMIT,
) -> ParsedSession:
    """Walk a Claude Code JSONL session file into a list of user turns + grounding context.

    Strips assistant tool outputs longer than `tool_output_token_limit` and any
    file content blocks the assistant pasted (they're not user signal). Preserves
    user prose and short assistant turns the user is responding to.
    """
    char_limit = tool_output_token_limit * APPROX_CHARS_PER_TOKEN
    turns: list[Turn] = []
    total_user_chars = 0
    last_assistant_text = ""
    anchor_ts: datetime | None = None
    user_turn_index = 0

    for record in _iter_records(file_path):
        ts = _record_timestamp(record)
        if anchor_ts is None and ts is not None:
            anchor_ts = ts

        message = record.get("message")
        if not isinstance(message, dict):
            continue

        role = message.get("role") or record.get("type")
        content = message.get("content")
        text = _extract_text(content, char_limit=char_limit)

        if role == "assistant":
            if text:
                last_assistant_text = text
        elif role == "user":
            if not text or _is_tool_result_only(content):
                # Pure tool-result turns aren't user signal; skip them.
                continue
            turn = Turn(
                index=user_turn_index,
                user_text=text,
                preceding_assistant_text=last_assistant_text,
                char_count=len(text),
                timestamp=ts,
            )
            turns.append(turn)
            total_user_chars += turn.char_count
            user_turn_index += 1
            last_assistant_text = ""

    if anchor_ts is None:
        # Fall back to first turn timestamp, or epoch — caller should handle this gracefully.
        anchor_ts = turns[0].timestamp if turns and turns[0].timestamp else datetime.fromtimestamp(0)

    return ParsedSession(
        file_path=file_path,
        turns=turns,
        total_user_chars=total_user_chars,
        anchor_ts=anchor_ts,
    )


def select_signal_turns(session: ParsedSession, max_turns: int = 5) -> list[Turn]:
    """Pick a small set of high-signal user turns for the Stage 2 prompt.

    Strategy: first message (frames the task), longest message (most thought
    invested), and the last message (resolution). De-duplicates by index and
    fills remaining slots with turns containing pushback markers.
    """
    if not session.turns:
        return []

    candidates: list[Turn] = []
    seen: set[int] = set()

    def _add(turn: Turn | None) -> None:
        if turn is None or turn.index in seen:
            return
        candidates.append(turn)
        seen.add(turn.index)

    _add(session.turns[0])
    longest = max(session.turns, key=lambda t: t.char_count)
    _add(longest)
    _add(session.turns[-1])

    pushback_markers = ("no,", "actually", "wait", "hmm", "that's wrong", "incorrect", "doesn't", "won't work")
    for turn in session.turns:
        if len(candidates) >= max_turns:
            break
        lowered = turn.user_text.lower()
        if any(marker in lowered for marker in pushback_markers):
            _add(turn)

    return candidates[:max_turns]


def _iter_records(file_path: Path) -> Iterator[dict[str, Any]]:
    with file_path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(record, dict):
                yield record


def _record_timestamp(record: dict[str, Any]) -> datetime | None:
    raw = record.get("timestamp")
    if not isinstance(raw, str):
        return None
    try:
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        return datetime.fromisoformat(raw)
    except ValueError:
        return None


def _extract_text(content: Any, *, char_limit: int) -> str:
    """Pull readable text out of Claude Code's polymorphic content shape.

    Drops oversized tool outputs and anything that doesn't look like prose or
    short tool-result text the user is reacting to.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content.strip()
    if not isinstance(content, list):
        return ""

    parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        block_type = block.get("type")
        if block_type == "text":
            text = block.get("text") or ""
            if text:
                parts.append(text)
        elif block_type == "tool_use":
            # Tool calls aren't direct user signal but the surrounding prose can be.
            continue
        elif block_type == "tool_result":
            inner = block.get("content")
            inner_text = _extract_text(inner, char_limit=char_limit)
            if inner_text and len(inner_text) <= char_limit:
                parts.append(inner_text)
        elif block_type in {"image", "thinking", "redacted_thinking"}:
            continue
    return "\n\n".join(p.strip() for p in parts if p.strip())


def _is_tool_result_only(content: Any) -> bool:
    if not isinstance(content, list):
        return False
    has_blocks = False
    for block in content:
        if not isinstance(block, dict):
            continue
        has_blocks = True
        if block.get("type") != "tool_result":
            return False
    return has_blocks
