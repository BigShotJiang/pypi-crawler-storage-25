from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterator


CLAUDE_CODE_DIR = Path.home() / ".claude" / "projects"


@dataclass(frozen=True)
class DiscoveredSession:
    id: str
    file_path: Path
    tool: str
    anchor_ts: datetime
    first_message_uuid: str


def claude_code_session_root() -> Path:
    return CLAUDE_CODE_DIR


def discover_claude_code_sessions(root: Path | None = None) -> Iterator[DiscoveredSession]:
    """Walk Claude Code's projects directory and yield one DiscoveredSession per JSONL file.

    Skips files we can't parse — version drift in Claude Code's session format is
    expected, so failure here is logged-and-skipped rather than fatal.
    """
    base = root or claude_code_session_root()
    if not base.exists():
        return

    for jsonl_path in base.rglob("*.jsonl"):
        if not jsonl_path.is_file():
            continue
        try:
            session = _read_session_header(jsonl_path)
        except (OSError, ValueError, json.JSONDecodeError):
            continue
        if session is not None:
            yield session


def _read_session_header(path: Path) -> DiscoveredSession | None:
    """Read the first usable record from the JSONL file to extract the anchor timestamp and UUID."""
    with path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue

            uuid = record.get("uuid")
            ts_raw = record.get("timestamp")
            if not uuid or not ts_raw:
                # Some records (system metadata, summaries) lack these — keep scanning.
                continue

            try:
                anchor = _parse_timestamp(ts_raw)
            except ValueError:
                continue

            session_id = stable_session_id(path, uuid)
            return DiscoveredSession(
                id=session_id,
                file_path=path,
                tool="claude_code",
                anchor_ts=anchor,
                first_message_uuid=uuid,
            )
    return None


def _parse_timestamp(raw: str) -> datetime:
    # Claude Code emits ISO 8601 with a trailing Z; Python's fromisoformat handles offsets but not bare Z.
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    return datetime.fromisoformat(raw)


def stable_session_id(file_path: Path, first_message_uuid: str) -> str:
    payload = f"{file_path.resolve()}|{first_message_uuid}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
