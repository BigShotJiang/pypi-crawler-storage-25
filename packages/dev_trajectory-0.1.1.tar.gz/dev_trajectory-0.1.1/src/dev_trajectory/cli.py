from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer
from anthropic import Anthropic

from . import __version__
from .aggregate import bucket_weekly
from .config import Config, config_path, db_path, load_config, resolve_api_key, save_config
from .discover import DiscoveredSession, discover_claude_code_sessions
from .models import DIMENSION_FIELDS
from .pipeline import analyze as run_analyze
from .pipeline import rescore as run_rescore
from .rubric import load_rubric
from .storage import Storage


app = typer.Typer(
    name="devtraj",
    help="Local, single-user analysis of Claude Code session histories.",
    no_args_is_help=True,
    add_completion=False,
)

telemetry_app = typer.Typer(help="Toggle the (currently disabled) aggregate-study telemetry.")
app.add_typer(telemetry_app, name="telemetry")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"devtraj {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: bool = typer.Option(
        False,
        "--version",
        help="Print the version and exit.",
        is_eager=True,
        callback=_version_callback,
    ),
) -> None:
    """Top-level options apply before any subcommand."""
    return


@app.command()
def init() -> None:
    """Configure the API key, scan session paths, and surface the telemetry toggle."""
    cfg = load_config()

    typer.echo("dev-trajectory init")
    typer.echo("===================")
    typer.echo("")
    typer.echo("This tool stores all analysis locally. Your sessions never leave the")
    typer.echo("machine. Scoring uses your own Anthropic API key — no proxying.")
    typer.echo("")

    env_key = resolve_api_key(cfg)
    if env_key:
        typer.echo(f"Using ANTHROPIC_API_KEY from environment ({_redact(env_key)}).")
    else:
        entered = typer.prompt(
            "Anthropic API key (leave blank to set ANTHROPIC_API_KEY env var instead)",
            default="",
            show_default=False,
            hide_input=True,
        )
        cfg.api_key = entered.strip() or None

    # Fail fast if the rubric is missing or malformed — better to surface that
    # at init time than to fail mid-`analyze` after burning through API calls.
    try:
        rubric = load_rubric(cfg.rubric_version)
    except (FileNotFoundError, ValueError) as e:
        typer.echo(f"\nRubric error: {e}", err=True)
        typer.echo("Reinstall the package or set `rubric_version` to one that exists.", err=True)
        raise typer.Exit(code=1)
    typer.echo(f"\nRubric: {rubric.version} (run `devtraj rubric` to inspect)")

    sessions = list(discover_claude_code_sessions())
    typer.echo(f"\nDiscovered {len(sessions)} Claude Code session file(s) in ~/.claude/projects/.")
    if sessions:
        typer.echo(f"  Earliest: {min(s.anchor_ts for s in sessions).date()}")
        typer.echo(f"  Latest:   {max(s.anchor_ts for s in sessions).date()}")
    else:
        typer.echo("  (No sessions found — `devtraj analyze` will pick them up once they exist.)")

    typer.echo(
        f"\nSampling cap: {cfg.sessions_per_week} session(s) per ISO week "
        f"({'no cap' if cfg.sessions_per_week <= 0 else 'deterministic; same picks every re-run'})."
    )
    typer.echo("Edit `sessions_per_week` in config.toml to change, or pass `--sessions-per-week N` to `analyze`.")

    typer.echo("\nTelemetry is currently disabled in this build (no upload endpoint exists).")
    typer.echo("Toggle the local consent flag any time with `devtraj telemetry on|off|status`.")
    cfg.telemetry_enabled = False  # uploader is a no-op regardless; default off

    saved_path = save_config(cfg)
    typer.echo(f"\nWrote config to {saved_path}")
    typer.echo(f"Database will live at {db_path()}")
    typer.echo("\nNext: `devtraj analyze`")


@app.command()
def analyze(
    rebuild: bool = typer.Option(False, "--rebuild", help="Re-summarize and re-score every sampled session."),
    sessions_per_week: Optional[int] = typer.Option(
        None,
        "--sessions-per-week",
        help="Override the per-week sampling cap. 0 disables the cap (score everything).",
    ),
    max_concurrent_sessions: Optional[int] = typer.Option(
        None,
        "--max-concurrent-sessions",
        help="Override how many sessions are processed in parallel (default 10).",
    ),
) -> None:
    """Discover, summarize, and score new Claude Code sessions.

    To control cost, the pipeline samples at most N sessions per ISO week
    (default 3, configurable via `sessions_per_week` in config.toml). Sampling
    is deterministic — the same N sessions get picked on every re-run, so
    `analyze` is idempotent.

    Sessions are processed in parallel up to `max_concurrent_sessions`
    (default 10). Inside each session, the median-of-3 scoring runs another
    3 calls in parallel — so total in-flight LLM calls is roughly
    max_concurrent_sessions * 4.
    """
    import threading

    cfg = load_config()
    api_key = resolve_api_key(cfg)
    if not api_key:
        typer.echo("No Anthropic API key configured. Run `devtraj init` or set ANTHROPIC_API_KEY.", err=True)
        raise typer.Exit(code=1)

    client = Anthropic(api_key=api_key)
    storage = Storage(db_path())

    progress_state = {"count": 0}
    progress_lock = threading.Lock()

    def progress(stage: str, session: DiscoveredSession) -> None:
        # Pipeline already serializes calls to this callback, but we keep our
        # own lock around the counter increment so the displayed numbers stay
        # monotonic if the contract ever changes.
        if stage in {"summarizing", "scoring", "skipped", "failed", "empty"}:
            with progress_lock:
                progress_state["count"] += 1
                count = progress_state["count"]
            typer.echo(f"  [{count:>4}] {stage:<11} {session.file_path.name}")

    cap = sessions_per_week if sessions_per_week is not None else cfg.sessions_per_week
    cap_str = "no cap" if cap <= 0 else f"{cap} per week"
    workers = max_concurrent_sessions if max_concurrent_sessions is not None else cfg.max_concurrent_sessions
    typer.echo(
        f"Analyzing sessions (this hits the Anthropic API; sampling {cap_str}; "
        f"up to {max(1, workers)} sessions in parallel)…"
    )
    result = run_analyze(
        cfg=cfg,
        storage=storage,
        client=client,
        rebuild=rebuild,
        sessions_per_week=sessions_per_week,
        max_concurrent_sessions=max_concurrent_sessions,
        progress=progress,
    )
    typer.echo("")
    typer.echo(f"Discovered:       {result.discovered}")
    typer.echo(f"Sampled:          {result.sampled}  (after per-week cap)")
    typer.echo(f"Skipped (cached): {result.skipped_existing}")
    typer.echo(f"Scored:           {result.scored}")
    typer.echo(f"Failed:           {result.failed}")
    if result.failures:
        typer.echo("\nFailures:")
        for sid, msg in result.failures[:20]:
            typer.echo(f"  {sid[:12]} … {msg}")
        if len(result.failures) > 20:
            typer.echo(f"  …and {len(result.failures) - 20} more")


@app.command()
def report(
    slice_by: str = typer.Option("domain", "--slice-by", help="domain | language | all"),
    min_confidence: float = typer.Option(0.5, "--min-confidence", help="Drop scores below this confidence."),
) -> None:
    """Print a per-week trajectory summary."""
    cfg = load_config()
    storage = Storage(db_path())
    scores = storage.all_scores(rubric_version=cfg.rubric_version, min_confidence=min_confidence)

    if not scores:
        typer.echo("No scored sessions yet. Run `devtraj analyze` first.")
        return

    if slice_by not in {"domain", "language", "all"}:
        typer.echo(f"Invalid --slice-by value: {slice_by!r}", err=True)
        raise typer.Exit(code=1)

    buckets = bucket_weekly(scores, slice_by=slice_by)
    header = f"{'week':<12} {slice_by:<14} {'n':>3}  " + "  ".join(f"{d[:6]:>6}" for d in DIMENSION_FIELDS) + "  band"
    typer.echo(header)
    typer.echo("-" * len(header))
    for bucket in buckets:
        medians = bucket.medians()
        scores_str = "  ".join(f"{medians[d]:>6.1f}" for d in DIMENSION_FIELDS)
        typer.echo(
            f"{bucket.week_start.isoformat():<12} {bucket.slice_key:<14} "
            f"{len(bucket.sessions):>3}  {scores_str}  {bucket.modal_band() or '?':<8}"
        )

    typer.echo(f"\n{len(scores)} session(s) at confidence ≥ {min_confidence}, rubric={cfg.rubric_version}")
    typer.echo("Dimension columns: prob_d, system, debug_, tech_c, model_  (1=junior … 5=principal)")


@app.command()
def explain(
    week: str = typer.Argument(..., help="ISO date for the start of the week (YYYY-MM-DD)."),
    slice_by: str = typer.Option("domain", "--slice-by", help="domain | language | all"),
    slice_value: Optional[str] = typer.Option(None, "--slice-value", help="Filter to a single slice (e.g. 'backend')."),
) -> None:
    """Show evidence quotes for a given week."""
    from datetime import date as date_cls

    cfg = load_config()
    storage = Storage(db_path())
    scores = storage.all_scores(rubric_version=cfg.rubric_version, min_confidence=0.0)

    try:
        target = date_cls.fromisoformat(week)
    except ValueError:
        typer.echo(f"Invalid week: {week!r}. Use YYYY-MM-DD.", err=True)
        raise typer.Exit(code=1)

    buckets = bucket_weekly(scores, slice_by=slice_by)
    matched = [b for b in buckets if b.week_start == target and (slice_value is None or b.slice_key == slice_value)]
    if not matched:
        typer.echo(f"No sessions in week {target.isoformat()} (slice_by={slice_by}).")
        return

    for bucket in matched:
        typer.echo(f"\n=== {bucket.week_start.isoformat()}  {slice_by}={bucket.slice_key}  n={len(bucket.sessions)} ===")
        for s in bucket.sessions:
            typer.echo(
                f"\n  {s.anchor_ts.date().isoformat()}  band={s.seniority_band:<8} "
                f"conf={s.confidence:.2f}  spread={s.max_dimension_spread} "
                f"domain={s.domain_category} lang={s.language or '-'}"
            )
            for q in s.evidence_quotes[:3]:
                typer.echo(f"    > {_truncate(q, 240)}")


@app.command()
def rescore() -> None:
    """Re-score every session whose stored rubric_version differs from the current one."""
    cfg = load_config()
    api_key = resolve_api_key(cfg)
    if not api_key:
        typer.echo("No Anthropic API key configured. Run `devtraj init` or set ANTHROPIC_API_KEY.", err=True)
        raise typer.Exit(code=1)
    client = Anthropic(api_key=api_key)
    storage = Storage(db_path())

    rubric = load_rubric(cfg.rubric_version)
    typer.echo(f"Re-scoring sessions older than rubric {rubric.version}…")
    result = run_rescore(cfg=cfg, storage=storage, client=client)
    typer.echo(f"Re-scored {result.scored}; failed {result.failed}")
    for sid, msg in result.failures[:10]:
        typer.echo(f"  {sid[:12]} … {msg}")


@telemetry_app.command("on")
def telemetry_on() -> None:
    """Opt in. (Note: uploader is a no-op in this build — see `devtraj telemetry status`.)"""
    cfg = load_config()
    cfg.telemetry_enabled = True
    save_config(cfg)
    typer.echo("Telemetry consent flag: ON")
    typer.echo("(No data has left or will leave your machine — uploader is disabled in this build.)")


@telemetry_app.command("off")
def telemetry_off() -> None:
    """Opt out."""
    cfg = load_config()
    cfg.telemetry_enabled = False
    save_config(cfg)
    typer.echo("Telemetry consent flag: OFF")


@telemetry_app.command("status")
def telemetry_status() -> None:
    """Show the current telemetry state."""
    cfg = load_config()
    flag = "ON" if cfg.telemetry_enabled else "OFF"
    typer.echo(f"Consent flag: {flag}")
    typer.echo("Uploader: disabled in this build — no data has left your machine regardless of this flag.")


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Bind address. Default 127.0.0.1 — single-user; do not expose."),
    port: int = typer.Option(8765, "--port", help="Port to bind."),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open the dashboard in the default browser on startup."),
    reload: bool = typer.Option(False, "--reload", help="Auto-reload on code changes (dev only)."),
) -> None:
    """Serve the local dashboard at http://127.0.0.1:8765/."""
    import threading
    import time
    import webbrowser

    import uvicorn

    from .server.api import create_app

    storage = Storage(db_path())
    cfg = load_config()
    n_scores = len(storage.all_scores(rubric_version=cfg.rubric_version, min_confidence=0.0))
    if n_scores == 0:
        typer.echo("Warning: no scored sessions in storage. Run `devtraj analyze` first.", err=True)

    url = f"http://{host}:{port}/"
    typer.echo(f"Serving on {url}")
    typer.echo(f"  rubric={cfg.rubric_version}  scored sessions={n_scores}")
    typer.echo("  Ctrl-C to stop.")

    if open_browser:
        # Delay slightly so the server is up before the browser hits it.
        def _open():
            time.sleep(0.6)
            try:
                webbrowser.open(url)
            except Exception:  # noqa: BLE001
                pass
        threading.Thread(target=_open, daemon=True).start()

    if reload:
        # uvicorn's reload mode requires an app import string.
        uvicorn.run(
            "dev_trajectory.server.api:create_app",
            factory=True,
            host=host,
            port=port,
            reload=True,
            log_level="info",
        )
    else:
        uvicorn.run(create_app(cfg=cfg, storage=storage), host=host, port=port, log_level="warning")


@app.command()
def paths() -> None:
    """Print the config and database paths."""
    typer.echo(f"config: {config_path()}")
    typer.echo(f"db:     {db_path()}")


@app.command()
def rubric(
    prompt: bool = typer.Option(
        False,
        "--prompt",
        help="Print the full rendered system prompt the LLM judge sees.",
    ),
) -> None:
    """Show which rubric version is active and what's in it.

    By default prints a short summary (version, source path, bands,
    dimensions, few-shot example count). Pass `--prompt` to dump the
    full rendered system prompt — handy for auditing what's actually
    asked of the judge.
    """
    from importlib import resources

    cfg = load_config()
    try:
        r = load_rubric(cfg.rubric_version)
    except (FileNotFoundError, ValueError) as e:
        typer.echo(f"Rubric error: {e}", err=True)
        raise typer.Exit(code=1)

    if prompt:
        typer.echo(r.system_prompt)
        return

    rubric_path = resources.files("dev_trajectory.rubric").joinpath(f"{r.version}.yaml")
    typer.echo(f"version:    {r.version}")
    typer.echo(f"source:     {rubric_path}")
    typer.echo(f"bands:      {', '.join(r.raw['bands'].keys())}")
    typer.echo(f"dimensions: {', '.join(r.raw['dimensions'].keys())}")
    typer.echo(f"few-shot examples: {len(r.raw['few_shot_examples'])}")
    typer.echo("")
    typer.echo("Run `devtraj rubric --prompt` to see the full system prompt sent to the judge.")


def _redact(key: str) -> str:
    if len(key) < 12:
        return "***"
    return f"{key[:7]}…{key[-4:]}"


def _truncate(s: str, n: int) -> str:
    s = s.replace("\n", " ").strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def main() -> None:
    try:
        app()
    except KeyboardInterrupt:
        typer.echo("\nInterrupted.", err=True)
        sys.exit(130)


if __name__ == "__main__":
    main()
