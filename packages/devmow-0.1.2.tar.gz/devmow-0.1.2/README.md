# devmow

`devmow` is a powerful, terminal-based CLI tool designed to simplify local web development testing. It automatically detects active local development servers (e.g., React, Vue, Node.js), creates a secure internet tunnel via Pinggy, and generates a terminal-based QR code for instant mobile access.

## Features

- **Auto-Detection**: Automatically scans for active development servers on common ports (3000, 5000, 5173, 8000, 8080) and beyond.
- **Instant Secure Tunnel**: Seamlessly establishes a secure public URL via Pinggy—no authentication tokens required!
- **Terminal QR Code**: Generates an ASCII QR code directly in your terminal for quick scanning with your mobile device.
- **Built-in Static Server**: Serve your HTML/static files instantly with a single flag.
- **Clipboard Auto-copy**: The generated URL is automatically copied to your clipboard.
- **Arch-Inspired Aesthetic**: Enjoy a sleek, Arch Linux-inspired ASCII banner when you run the tool.

## Installation

You can install `devmow` directly from PyPI:

```bash
pip install devmow
```

## Usage

Simply run `devmow` in your terminal while your local development server is running:

```bash
devmow
```

If you want to manually specify the port instead of relying on auto-detection:

```bash
devmow -p 3000
```

### Options

- `-p <port>` or `--port <port>`: Manually specify the port to tunnel.
- `--serve`: Start a built-in static file server in the current directory and tunnel it instantly.
- `--no-qr`: Skip displaying the QR code in the terminal.

### Using with Plain HTML Files

If you are working with simple `.html` files, you no longer need to start a separate local server! Just open your terminal in the HTML folder and run:

```bash
devmow --serve
```

This will instantly start a local server and create a secure tunnel for it.

## Requirements

- Python 3.6+
- `ssh` (OpenSSH) installed on your system (required for creating the Pinggy tunnel).

## Author

Created by **Pankaj**.
