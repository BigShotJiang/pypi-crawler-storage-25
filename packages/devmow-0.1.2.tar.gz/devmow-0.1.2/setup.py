from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="devmow",
    version="0.1.2",
    description="Instantly expose your local dev server and generate a QR code for mobile testing.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Pankaj",
    packages=find_packages(),
    install_requires=[
        "psutil",
        "qrcode[pil]",
        "colorama",
        "pyperclip"
    ],
    entry_points={
        "console_scripts": [
            "devmow=devmow.main:main",
        ],
    },
    python_requires=">=3.6",
)
