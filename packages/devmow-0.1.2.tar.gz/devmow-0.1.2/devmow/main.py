import argparse
import psutil
import subprocess
import time
import re
import qrcode
import sys
import threading
import queue
import shutil
import http.server
import socketserver
import pyperclip
from colorama import init, Fore, Style

init(autoreset=True)

COMMON_PORTS = [3000, 5000, 5173, 8000, 8080]

def detect_port():
    print(f"{Fore.CYAN}Scanning for active development servers...{Style.RESET_ALL}")
    active_ports = []
    
    try:
        for conn in psutil.net_connections(kind='inet'):
            if conn.status == 'LISTEN':
                port = conn.laddr.port
                if port in COMMON_PORTS:
                    active_ports.append(port)
                    
        if not active_ports:
            for conn in psutil.net_connections(kind='inet'):
                if conn.status == 'LISTEN' and conn.laddr.port > 1024 and conn.laddr.port < 10000:
                    active_ports.append(conn.laddr.port)
                    
        active_ports = list(set(active_ports))
        
        if not active_ports:
            return None
        
        for p in COMMON_PORTS:
            if p in active_ports:
                return p
                
        return active_ports[0]
    except Exception as e:
        print(f"{Fore.YELLOW}Warning: Could not automatically scan network ports ({e}).{Style.RESET_ALL}")
        return None

def check_ssh():
    if not shutil.which("ssh"):
        print(f"\n{Fore.RED}{Style.BRIGHT}Error: 'ssh' command not found!{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}Devmow requires OpenSSH to create secure tunnels.{Style.RESET_ALL}")
        print(f"\n{Fore.CYAN}How to fix on Windows 10/11:{Style.RESET_ALL}")
        print("1. Open Settings > Apps > Optional features")
        print("2. Click 'Add a feature' (or 'View features')")
        print("3. Search for 'OpenSSH Client' and install it")
        print("4. Restart your terminal and try again.")
        print(f"\n{Fore.CYAN}How to fix on Linux:{Style.RESET_ALL}")
        print("Run: sudo apt install openssh-client (Ubuntu/Debian) or sudo pacman -S openssh (Arch)\n")
        sys.exit(1)

def start_local_server(port):
    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            pass
            
    try:
        with socketserver.TCPServer(("", port), QuietHandler) as httpd:
            httpd.serve_forever()
    except Exception as e:
        print(f"{Fore.RED}Failed to start local server: {e}{Style.RESET_ALL}")
        sys.exit(1)

def generate_qr(url, skip_qr=False):
    if not skip_qr:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=2,
        )
        qr.add_data(url)
        qr.make(fit=True)
        
        print(f"\n{Fore.GREEN}{Style.BRIGHT}Scan this QR code with your mobile device:{Style.RESET_ALL}\n")
        qr.print_ascii(invert=True)
    
    print(f"\n{Fore.YELLOW}URL: {Style.BRIGHT}{url}{Style.RESET_ALL}\n")

def enqueue_output(out, queue):
    for line in iter(out.readline, ''):
        queue.put(line)
    out.close()

def start_tunnel(port, skip_qr=False):
    print(f"{Fore.CYAN}Starting secure tunnel for port {port} (via Pinggy)...{Style.RESET_ALL}")
    
    cmd = [
        "ssh", 
        "-p", "443", 
        f"-R0:localhost:{port}", 
        "a.pinggy.io", 
        "-o", "StrictHostKeyChecking=no",
        "-o", "ServerAliveInterval=30"
    ]
    
    try:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
        
        q = queue.Queue()
        t1 = threading.Thread(target=enqueue_output, args=(process.stdout, q))
        t2 = threading.Thread(target=enqueue_output, args=(process.stderr, q))
        t1.daemon = True
        t2.daemon = True
        t1.start()
        t2.start()
        
        url = None
        start_time = time.time()
        
        while True:
            if process.poll() is not None:
                if not url:
                    print(f"{Fore.RED}Failed to start tunnel. Is SSH installed and allowed?{Style.RESET_ALL}")
                    sys.exit(1)
                break
                
            try:
                line = q.get(timeout=0.1)
                if "http://" in line or "https://" in line:
                    if "dashboard.pinggy.io" not in line and "openssh.com" not in line:
                        match = re.search(r'(https?://[a-zA-Z0-9.-]+\.pinggy-free\.link)', line)
                        if match:
                            url = match.group(1)
                            if "https://" in url:
                                break
                            elif not url.startswith("https://") and "http://" in url:
                                url = match.group(1)
                        else:
                            match = re.search(r'(https?://[^\s]+)', line)
                            if match:
                                url = match.group(1)
                                break
            except queue.Empty:
                pass
                
            if url and "https://" in url:
                break
                
            if time.time() - start_time > 15:
                print(f"{Fore.RED}Timeout waiting for tunnel URL.{Style.RESET_ALL}")
                process.terminate()
                sys.exit(1)
                
        if url:
            copy_msg = ""
            try:
                pyperclip.copy(url)
                copy_msg = f" {Fore.GREEN}(Copied to clipboard!){Style.RESET_ALL}"
            except Exception:
                pass
                
            generate_qr(url, skip_qr)
            print(f"{Fore.CYAN}Tunnel is active. Press Ctrl+C to stop.{copy_msg}{Style.RESET_ALL}")
            try:
                while process.poll() is None:
                    time.sleep(1)
            except KeyboardInterrupt:
                print(f"\n{Fore.YELLOW}Stopping tunnel...{Style.RESET_ALL}")
                process.terminate()
                sys.exit(0)
    except Exception as e:
        print(f"{Fore.RED}Error starting tunnel: {e}{Style.RESET_ALL}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Instantly expose your local dev server and generate a QR code for mobile testing.")
    parser.add_argument("-p", "--port", type=int, help="Specify the port manually.")
    parser.add_argument("--serve", action="store_true", help="Start a built-in static file server in the current directory.")
    parser.add_argument("--no-qr", action="store_true", help="Do not display the QR code.")
    args = parser.parse_args()

    check_ssh()

    banner = f"""{Fore.CYAN}{Style.BRIGHT}
██████╗ ███████╗██╗   ██╗███╗   ███╗ ██████╗ ██╗    ██╗
██╔══██╗██╔════╝██║   ██║████╗ ████║██╔═══██╗██║    ██║
██║  ██║█████╗  ██║   ██║██╔████╔██║██║   ██║██║ █╗ ██║
██║  ██║██╔══╝  ╚██╗ ██╔╝██║╚██╔╝██║██║   ██║██║███╗██║
██████╔╝███████╗ ╚████╔╝ ██║ ╚═╝ ██║╚██████╔╝╚███╔███╔╝
╚═════╝ ╚══════╝  ╚═══╝  ╚═╝     ╚═╝ ╚═════╝  ╚══╝╚══╝ 
                                            by pankaj
{Style.RESET_ALL}"""
    print(banner)

    if args.serve:
        port = args.port if args.port else 8000
        print(f"{Fore.GREEN}Starting built-in static server on port: {Style.BRIGHT}{port}{Style.RESET_ALL}")
        server_thread = threading.Thread(target=start_local_server, args=(port,))
        server_thread.daemon = True
        server_thread.start()
        # Give the server a moment to start before scanning or tunneling
        time.sleep(0.5)
    else:
        port = args.port
        if not port:
            port = detect_port()
            if not port:
                print(f"{Fore.RED}No active local development server found.{Style.RESET_ALL}")
                print(f"Please specify the port manually using: {Fore.YELLOW}devmow -p <port>{Style.RESET_ALL}")
                print(f"Or start a built-in server using: {Fore.YELLOW}devmow --serve{Style.RESET_ALL}")
                sys.exit(1)
            print(f"{Fore.GREEN}Detected active server on port: {Style.BRIGHT}{port}{Style.RESET_ALL}")
        else:
            print(f"{Fore.GREEN}Using specified port: {Style.BRIGHT}{port}{Style.RESET_ALL}")

    start_tunnel(port, args.no_qr)

if __name__ == "__main__":
    main()
