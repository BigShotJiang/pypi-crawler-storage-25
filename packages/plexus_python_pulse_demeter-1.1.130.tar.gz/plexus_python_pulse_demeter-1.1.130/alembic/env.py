import logging.config
import os

import alembic
import sqlalchemy as sa
from plexus.pulse.common.utils.ormutils import collect_model_tables

from plexus.pulse.demeter.app.models.registry import BaseModel
from plexus.pulse.demeter.app.models.registry import archive, dataset, tagging, user

database_host = os.getenv("PULSE_DEMETER_DATABASE_HOST", "localhost")
database_port = os.getenv("PULSE_DEMETER_DATABASE_PORT", "5432")
database_username = os.getenv("PULSE_DEMETER_DATABASE_USERNAME", "pulse")
database_password = os.getenv("PULSE_DEMETER_DATABASE_PASSWORD", "pulse")
database_database = os.getenv("PULSE_DEMETER_DATABASE_DATABASE", "pulse-demeter")

print(archive.__all__ + tagging.__all__ + dataset.__all__ + user.__all__)

url = sa.URL.create(
    drivername="postgresql+psycopg",
    host=database_host,
    port=int(database_port),
    username=database_username,
    password=database_password,
    database=database_database,
)

metadata = collect_model_tables(BaseModel)


def run_migrations_offline():
    alembic.context.configure(
        url=url,
        target_metadata=metadata,
        literal_binds=True,
        compare_type=True,
        include_schemas=True,
    )

    with alembic.context.begin_transaction():
        alembic.context.run_migrations()


def run_migrations_online():
    engine = sa.create_engine(url, echo=True, future=True)

    with engine.connect() as connection:
        alembic.context.configure(
            connection=connection,
            target_metadata=metadata,
            compare_type=True,
            include_schemas=True,
        )

        with alembic.context.begin_transaction():
            alembic.context.run_migrations()


config = alembic.context.config
logging.config.fileConfig(config.config_file_name)
if alembic.context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
