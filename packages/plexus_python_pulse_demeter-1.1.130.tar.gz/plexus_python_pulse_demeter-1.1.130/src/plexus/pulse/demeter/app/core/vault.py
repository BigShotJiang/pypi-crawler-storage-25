from plexus.pulse.common.utils.s3utils import s3_make_client, s3_make_progressed_client
from pydantic_settings import BaseSettings

from plexus.pulse.demeter.utils.config import config


class Settings(BaseSettings):
    access_key_id: str = config().get("pulse.demeter.vault", "access_key_id", "")
    secret_access_key: str = config().get("pulse.demeter.vault", "secret_access_key", "")
    endpoint_url: str = config().get("pulse.demeter.vault", "endpoint_url", "http://localhost:9000")

    class Config:
        env_prefix = "PULSE_DEMETER_VAULT_"
        env_file = ".env"


settings = Settings()


def make_client():
    return s3_make_client(access_key_id=settings.access_key_id,
                          secret_access_key=settings.secret_access_key,
                          endpoint_url=settings.endpoint_url)


def make_progressed_client():
    return s3_make_progressed_client(access_key_id=settings.access_key_id,
                                     secret_access_key=settings.secret_access_key,
                                     endpoint_url=settings.endpoint_url)
