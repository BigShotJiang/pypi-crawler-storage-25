import datetime
import typing
import uuid as py_uuid
from typing import Self

import jsonschema
import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.dialects.postgresql as sa_pg
import sqlalchemy.orm as sa_orm
from plexus.common.utils.jsonutils import JsonObject
from plexus.pulse.common.utils.datautils import (
    validate_bag_name,
    validate_colon_tag,
    validate_dt_timezone,
    validate_semver,
    validate_slash_tag,
    validate_snake_case,
    validate_strict_fragmented_relpath,
    validate_strict_relpath,
    validate_vehicle_name,
)
from plexus.pulse.common.utils.jsonutils import json_datetime_encoder
from plexus.pulse.common.utils.ormutils import RevisionModelMixinProtocol
from plexus.pulse.common.utils.ormutils import make_revision_model_mixin, revision_model_mixin
from sqlmodel import Field, SQLModel

from plexus.pulse.demeter.app.models.registry import BaseModel

__all__ = [
    "SampleLayout",
    "ClassifierTaxonomy",
    "AnnotationGuideline",
    "ModelArchitecture",
    "ModelBenchmark",
    "RegisteredDataset",
    "RegisteredSample",
    "RegisteredDatasetSample",
    "RegisteredDatasetLayout",
    "DatasetRegistration",
    "DatasetPromotion",
    "SampleClassifier",
    "SampleAnnotation",
    "ModelTraining",
    "ModelExperiment",
    "ModelExperimentPromotion",
    "ModelEvaluation",
    "ModelAssessment",
    "ModelAssessmentPromotion",
    "SampleLayoutTable",
    "ClassifierTaxonomyTable",
    "AnnotationGuidelineTable",
    "ModelArchitectureTable",
    "ModelBenchmarkTable",
    "RegisteredDatasetTable",
    "RegisteredSampleTable",
    "RegisteredDatasetSampleTable",
    "RegisteredDatasetLayoutTable",
    "DatasetRegistrationTable",
    "DatasetPromotionTable",
    "SampleClassifierTable",
    "SampleAnnotationTable",
    "ModelTrainingTable",
    "ModelExperimentTable",
    "ModelExperimentPromotionTable",
    "ModelEvaluationTable",
    "ModelAssessmentTable",
    "ModelAssessmentPromotionTable",
]


class SampleLayout(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the sample layout",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Name of the sample layout",
        schema_extra=dict(examples=["layout_name/layout_name"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the sample layout",
        schema_extra=dict(examples=["This is an example description of the sample layout."]),
    )
    child_layout_uuids: list[py_uuid.UUID] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.UUID(as_uuid=True))),
        default=None,
        description="List of child sample layout UUIDs",
        schema_extra=dict(examples=[["abcd1234-5678-90ab-cdef-1234567890ab", "12345678-90ab-cdef-1234-567890abcdef"]]),
    )
    layout_spec: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="JSON specification defining the sample layout",
        schema_extra=dict(
            examples=[
                {
                    "layout": {
                        "type": "directory",
                        "children": [
                            {
                                "matcher": {"type": "regex", "pattern": r"^\d{8}T\d{6}\.\d{6}$", "min_items": 1},
                                "layout": {
                                    "type": "directory",
                                    "children": [
                                        {
                                            "matcher": {
                                                "type": "exact",
                                                "pattern": "front_left_camera.png",
                                                "min_items": 1,
                                            },
                                            "layout": {"type": "file"},
                                        },
                                        {
                                            "matcher": {
                                                "type": "exact",
                                                "pattern": "front_right_camera.png",
                                                "min_items": 1,
                                            },
                                            "layout": {"type": "file"},
                                        },
                                        {
                                            "matcher": {
                                                "type": "exact",
                                                "pattern": "side_left_camera.png",
                                                "min_items": 1,
                                            },
                                            "layout": {"type": "file"},
                                        },
                                        {
                                            "matcher": {
                                                "type": "exact",
                                                "pattern": "side_right_camera.png",
                                                "min_items": 1,
                                            },
                                            "layout": {"type": "file"},
                                        },
                                        {
                                            "matcher": {
                                                "type": "exact",
                                                "pattern": "rear_left_camera.png",
                                                "min_items": 1,
                                            },
                                            "layout": {"type": "file"},
                                        },
                                        {
                                            "matcher": {
                                                "type": "exact",
                                                "pattern": "rear_right_camera.png",
                                                "min_items": 1,
                                            },
                                            "layout": {"type": "file"},
                                        },
                                        {
                                            "matcher": {"type": "exact", "pattern": "lidar_points.pcd"},
                                            "layout": {"type": "file"},
                                        },
                                    ],
                                    "allow_extra": False,
                                },
                            },
                        ],
                        "allow_extra": False,
                    },
                },
                {
                    "layout": {
                        "type": "directory",
                        "children": [
                            {
                                "matcher": {"type": "regex", "pattern": r"^\d{8}T\d{6}\.\d{6}$", "min_items": 1},
                                "layout": "abcd1234-5678-90ab-cdef-1234567890ab",  # reference to another layout
                            },
                        ],
                        "allow_extra": False,
                    },
                },
                {
                    "layout": {
                        "type": "directory",
                        "children": [
                            {
                                "matcher": {"type": "exact", "pattern": "front_left_camera.png", "min_items": 1},
                                "layout": {"type": "file"},
                            },
                            {
                                "matcher": {"type": "exact", "pattern": "front_right_camera.png", "min_items": 1},
                                "layout": {"type": "file"},
                            },
                            {
                                "matcher": {"type": "exact", "pattern": "side_left_camera.png", "min_items": 1},
                                "layout": {"type": "file"},
                            },
                            {
                                "matcher": {"type": "exact", "pattern": "side_right_camera.png", "min_items": 1},
                                "layout": {"type": "file"},
                            },
                            {
                                "matcher": {"type": "exact", "pattern": "rear_left_camera.png", "min_items": 1},
                                "layout": {"type": "file"},
                            },
                            {
                                "matcher": {"type": "exact", "pattern": "rear_right_camera.png", "min_items": 1},
                                "layout": {"type": "file"},
                            },
                            {
                                "matcher": {"type": "exact", "pattern": "lidar_points.pcd"},
                                "layout": {"type": "file"},
                            },
                        ],
                        "allow_extra": False,
                    },
                },
            ]
        ),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v


class ClassifierTaxonomy(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the classifier taxonomy",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Name of the classifier taxonomy",
        schema_extra=dict(examples=["taxonomy_name/taxonomy_name"]),
    )
    version: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(32), nullable=False),
        description="Version of the classifier taxonomy",
        schema_extra=dict(examples=["1.2.3-alpha+post0"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the classifier taxonomy",
        schema_extra=dict(examples=["This is an example description of the classifier taxonomy."]),
    )
    taxonomy_hierarchy: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="JSON object defining the classifiers and their hierarchy",
        schema_extra=dict(
            examples=[
                {
                    "weather": ["sunny", "rainy", "foggy"],
                    "obstacle": [
                        {"vehicle": ["car", "truck", "bus", "motorcycle"]},
                        "pedestrian",
                        "bicycle",
                    ],
                    "lane_marking": ["solid", "dashed"],
                    "road_sign": ["stop", "yield"],
                },
            ]
        ),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("version", mode="after")
    @classmethod
    def validate_version(cls, v: str) -> str:
        validate_semver(v)
        return v


class AnnotationGuideline(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the annotation guideline",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Name of the annotation guideline",
        schema_extra=dict(examples=["guideline_name/guideline_name"]),
    )
    version: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(32), nullable=False),
        description="Version of the annotation guideline",
        schema_extra=dict(examples=["1.2.3-alpha+post0"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the annotation guideline",
        schema_extra=dict(examples=["This is an example description of the annotation guideline."]),
    )
    supported_layout_uuids: list[py_uuid.UUID] = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.UUID(as_uuid=True)), nullable=False),
        description="List of supported sample layout UUIDs",
        schema_extra=dict(examples=[["abcd1234-5678-90ab-cdef-1234567890ab", "12345678-90ab-cdef-1234-567890abcdef"]]),
    )
    annotation_schema: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="JSON schema defining the annotation format",
        schema_extra=dict(
            examples=[
                {
                    "type": "object",
                    "required": ["object_id", "object_category", "cuboid"],
                    "properties": {
                        "object_id": {"type": "string"},
                        "object_category": {
                            "type": "string",
                            "enum": ["car", "truck", "bus", "motorcycle", "pedestrian", "bicycle"],
                        },
                        "cuboid": {
                            "type": "object",
                            "required": ["dimensions", "center", "rotation"],
                            "properties": {
                                "dimensions": {"type": "object"},
                                "center": {"type": "object"},
                                "rotation": {"type": "object"},
                            },
                        },
                    },
                },
            ]
        ),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("version", mode="after")
    @classmethod
    def validate_version(cls, v: str) -> str:
        validate_semver(v)
        return v

    @pdt.field_validator("annotation_schema", mode="after")
    @classmethod
    def validate_annotation_schema(cls, v: JsonObject) -> JsonObject:
        try:
            jsonschema.Draft7Validator.check_schema(v)
        except Exception as e:
            raise ValueError("not a valid JSON schema") from e
        return v


class ModelArchitecture(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model architecture",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Name of the model architecture",
        schema_extra=dict(examples=["architecture_name/architecture_name"]),
    )
    version: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(32), nullable=False),
        description="Version of the model architecture",
        schema_extra=dict(examples=["1.2.3-alpha+post0"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the model architecture",
        schema_extra=dict(examples=["This is an example description of the model architecture."]),
    )
    supported_guideline_uuids: list[py_uuid.UUID] = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.UUID(as_uuid=True)), nullable=False),
        description="List of supported annotation guideline UUIDs",
        schema_extra=dict(examples=[["abcd1234-5678-90ab-cdef-1234567890ab", "12345678-90ab-cdef-1234-567890abcdef"]]),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("version", mode="after")
    @classmethod
    def validate_version(cls, v: str) -> str:
        validate_semver(v)
        return v


class ModelBenchmark(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model benchmark",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Name of the model benchmark",
        schema_extra=dict(examples=["benchmark_name/benchmark_name"]),
    )
    version: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(32), nullable=False),
        description="Version of the model benchmark",
        schema_extra=dict(examples=["1.2.3-alpha+post0"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the model benchmark",
        schema_extra=dict(examples=["This is an example description of the model benchmark."]),
    )
    supported_architecture_uuids: list[py_uuid.UUID] = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.UUID(as_uuid=True)), nullable=False),
        description="List of supported model architecture UUIDs",
        schema_extra=dict(examples=[["abcd1234-5678-90ab-cdef-1234567890ab", "12345678-90ab-cdef-1234-567890abcdef"]]),
    )
    benchmark_schema: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="JSON schema defining the benchmark format",
        schema_extra=dict(
            examples=[
                {
                    "type": "object",
                    "required": ["accuracy", "precision", "recall", "f1_score"],
                    "properties": {
                        "accuracy": {"type": "number", "minimum": 0, "maximum": 1},
                        "precision": {"type": "number", "minimum": 0, "maximum": 1},
                        "recall": {"type": "number", "minimum": 0, "maximum": 1},
                        "f1_score": {"type": "number", "minimum": 0, "maximum": 1},
                    },
                },
            ]
        ),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("version", mode="after")
    @classmethod
    def validate_version(cls, v: str) -> str:
        validate_semver(v)
        return v

    @pdt.field_validator("benchmark_schema", mode="after")
    @classmethod
    def validate_benchmark_schema(cls, v: JsonObject) -> JsonObject:
        try:
            jsonschema.Draft7Validator.check_schema(v)
        except Exception as e:
            raise ValueError("not a valid JSON schema") from e
        return v


class DatasetRegistration(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the dataset registration",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    dataset_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the dataset",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    resource_path: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(512), nullable=False),
        description="Root URL of the dataset resource relative to storage base path",
        schema_extra=dict(examples=["relative/path/to/dataset"]),
    )
    flags: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=0,
        description="Integer bitmask storing status or metadata flags for this record",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("resource_path", mode="after")
    @classmethod
    def validate_resource_path(cls, v: str) -> str:
        validate_strict_relpath(v)
        return v


class DatasetPromotion(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the dataset promotion",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    dataset_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the dataset",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    reviewer_sso_sid: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT, nullable=False),
        description="SSO SID of the reviewer",
        schema_extra=dict(examples=[1234567890]),
    )
    flags: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=0,
        description="Integer bitmask storing status or metadata flags for this record",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )


class RegisteredDataset(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the dataset",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Name of the dataset",
        schema_extra=dict(examples=["dataset_name_dataset_name"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the dataset",
        schema_extra=dict(examples=["This is an example description of the dataset."]),
    )
    contributor_sso_sid: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT, nullable=False),
        description="SSO SID of the contributor",
        schema_extra=dict(examples=[1234567890]),
    )
    tags: list[str] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.VARCHAR(64))),
        default=None,
        description="List of tags associated with the dataset",
        schema_extra=dict(examples=[["example_tag", "example_tag:example_tag", "example_tag:example_tag:example_tag"]]),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v


class RegisteredSample(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the sample",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    path: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(512), nullable=False),
        description="Relative path to the sample resource directory",
        schema_extra=dict(examples=["relative/path/to/sample"]),
    )
    layout_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated sample layout",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    bag_name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(256), nullable=False),
        description="Name of associated bag",
        schema_extra=dict(
            examples=[
                "20200101T000000-brand_name-0",
                "20200101T000000-brand_name_alias-0",
                "20200101T000000-brand_name_00001-0",
                "20200101T000000-brand_name_V00000000000000000-0",
            ]
        ),
    )
    vehicle_name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(256), nullable=False),
        description="Name of associated vehicle",
        schema_extra=dict(
            examples=["brand_name", "brand_name_alias", "brand_name_00001", "brand_name_V00000000000000000"]
        ),
    )
    begin_frame_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_pg.TIMESTAMP(timezone=True), nullable=False),
        description="Datetime of the begin frame of the sample",
    )
    end_frame_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_pg.TIMESTAMP(timezone=True), nullable=False),
        description="Datetime of the end frame of the sample",
    )
    child_sample_uuids: list[py_uuid.UUID] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.UUID(as_uuid=True))),
        default=None,
        description="List of UUIDs of associated child samples",
        schema_extra=dict(examples=[["abcd1234-5678-90ab-cdef-1234567890ab", "12345678-90ab-cdef-1234-567890abcdef"]]),
    )
    tags: list[str] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.VARCHAR(64))),
        default=None,
        description="List of tags associated with the sample",
        schema_extra=dict(examples=[["example_tag", "example_tag:example_tag", "example_tag:example_tag:example_tag"]]),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("path", mode="after")
    @classmethod
    def validate_path(cls, v: str) -> str:
        validate_strict_relpath(v)
        return v

    @pdt.field_validator("bag_name", mode="after")
    @classmethod
    def validate_bag_name(cls, v: str) -> str:
        validate_bag_name(v)
        return v

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("begin_frame_dt", mode="after")
    @classmethod
    def validate_begin_frame_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.field_validator("end_frame_dt", mode="after")
    @classmethod
    def validate_end_frame_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_frame_dt_end_frame_dt(self) -> Self:
        if self.begin_frame_dt > self.end_frame_dt:
            raise ValueError(
                f"begin_frame_dt '{self.begin_frame_dt}' is greater than end_frame_dt '{self.end_frame_dt}'")
        return self

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v

    @pdt.field_serializer("begin_frame_dt", mode="plain")
    def serialize_begin_frame_dt(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)

    @pdt.field_serializer("end_frame_dt", mode="plain")
    def serialize_end_frame_dt(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)


class RegisteredDatasetSample(BaseModel):
    dataset_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of associated dataset",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    sample_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of associated sample",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    annotation_uuid: py_uuid.UUID | None = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True)),
        default=None,
        description="UUID of associated annotation",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )


class RegisteredDatasetLayout(BaseModel):
    dataset_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of associated dataset",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    layout_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of associated sample layout",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    samples_count: int = Field(
        sa_column=sa.Column(sa_pg.INTEGER, nullable=False),
        description="Number of samples in the dataset with this layout",
    )


class SampleClassifier(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the classifier",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    sample_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated sample",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    taxonomy_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the classifier taxonomy used",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    classifier_data: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="Classifier data stored as JSON",
        schema_extra=dict(
            examples=[
                {"classifiers": ["weather:sunny", "obstacle:vehicle:car", "lane_marking:solid"]},
            ]
        ),
    )


class SampleAnnotation(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the annotation",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    sample_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated sample",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    guideline_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the annotation guideline used",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    path: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(512)),
        default=None,
        description="Relative path to the annotation resource file",
        schema_extra=dict(
            examples=["relative/path/to/annotation.json", "relative/path/to/archive.zip#annotation.json"],
        ),
    )
    annotation_data: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="Annotation data stored as JSON",
        schema_extra=dict(
            examples=[
                {
                    "objects": [
                        {
                            "object_id": "obj_001",
                            "object_category": "car",
                            "cuboid": {
                                "dimensions": {"length": 4.5, "width": 2.0, "height": 1.5},
                                "center": {"x": 10.0, "y": 5.0, "z": 0.0},
                                "rotation": {"roll": 0.0, "pitch": 0.0, "yaw": 1.57},
                            },
                        },
                        {
                            "object_id": "obj_002",
                            "object_category": "pedestrian",
                            "cuboid": {
                                "dimensions": {"length": 0.5, "width": 0.5, "height": 1.8},
                                "center": {"x": 15.0, "y": 3.0, "z": 0.0},
                                "rotation": {"roll": 0.0, "pitch": 0.0, "yaw": 0.0},
                            },
                        },
                    ],
                },
            ]
        ),
    )

    @pdt.field_validator("path", mode="after")
    @classmethod
    def validate_path(cls, v: str | None) -> str | None:
        if v is not None:
            validate_strict_fragmented_relpath(v)
        return v


class ModelTraining(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model training",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    experiment_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the model experiment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    flags: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=0,
        description="Integer bitmask storing status or metadata flags for this record",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )


class ModelExperiment(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model experiment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    parent_uuid: py_uuid.UUID | None = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True)),
        default=None,
        description="UUID of the parent model experiment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    architecture_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated model architecture",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    dataset_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the dataset used for training/validation",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Name of the model experiment",
        schema_extra=dict(examples=["model_experiment_name"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the model experiment",
        schema_extra=dict(examples=["This is an example description of the model experiment."]),
    )
    contributor_sso_sid: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT, nullable=False),
        description="SSO SID of the contributor",
        schema_extra=dict(examples=[1234567890]),
    )
    path: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(512)),
        default=None,
        description="Relative path to the model experiment artifact directory",
        schema_extra=dict(examples=["relative/path/to/model_experiment"]),
    )
    checkpoint_path: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(512)),
        default=None,
        description="Relative path to the model experiment checkpoint file within the artifact directory",
        schema_extra=dict(examples=["relative/path/to/checkpoint.ckpt"]),
    )
    tags: list[str] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.VARCHAR(64))),
        default=None,
        description="List of tags associated with the model experiment",
        schema_extra=dict(examples=[["example_tag", "example_tag:example_tag", "example_tag:example_tag:example_tag"]]),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("path", mode="after")
    @classmethod
    def validate_path(cls, v: str | None) -> str | None:
        if v is not None:
            validate_strict_relpath(v)
        return v

    @pdt.field_validator("checkpoint_path", mode="after")
    @classmethod
    def validate_checkpoint_path(cls, v: str | None) -> str | None:
        if v is not None:
            validate_strict_relpath(v)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v


class ModelExperimentPromotion(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model experiment promotion",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    experiment_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the model experiment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    reviewer_sso_sid: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT, nullable=False),
        description="SSO SID of the reviewer",
        schema_extra=dict(examples=[1234567890]),
    )
    flags: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=0,
        description="Integer bitmask storing status or metadata flags for this record",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )


class ModelEvaluation(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model evaluation",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    assessment_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the model assessment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    flags: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=0,
        description="Integer bitmask storing status or metadata flags for this record",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )


class ModelAssessment(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model assessment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    benchmark_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated model benchmark",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    experiment_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated model experiment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    dataset_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the dataset used for model assessment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Name of the model assessment",
        schema_extra=dict(examples=["model_assessment_name"]),
    )
    description: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(1024), nullable=False),
        description="Description of the model assessment",
        schema_extra=dict(examples=["This is an example description of the model assessment."]),
    )
    contributor_sso_sid: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT, nullable=False),
        description="SSO SID of the contributor",
        schema_extra=dict(examples=[1234567890]),
    )
    path: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(512)),
        default=None,
        description="Relative path to the model assessment artifact directory",
        schema_extra=dict(examples=["relative/path/to/model_assessment"]),
    )
    assessment_data: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Assessment data stored as JSON",
        schema_extra=dict(examples=[{"accuracy": 0.95, "precision": 0.95, "recall": 0.95, "f1_score": 0.95}]),
    )
    tags: list[str] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.VARCHAR(64))),
        default=None,
        description="List of tags associated with the model assessment",
        schema_extra=dict(examples=[["example_tag", "example_tag:example_tag", "example_tag:example_tag:example_tag"]]),
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("path", mode="after")
    @classmethod
    def validate_path(cls, v: str | None) -> str | None:
        if v is not None:
            validate_strict_relpath(v)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v


class ModelAssessmentPromotion(BaseModel):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        default_factory=py_uuid.uuid4,
        description="UUID of the model assessment promotion",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    assessment_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the model assessment",
        schema_extra=dict(examples=["abcd1234-5678-90ab-cdef-1234567890ab"]),
    )
    reviewer_sso_sid: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT, nullable=False),
        description="SSO SID of the reviewer",
        schema_extra=dict(examples=[1234567890]),
    )
    flags: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=0,
        description="Integer bitmask storing status or metadata flags for this record",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional properties stored as JSON",
        schema_extra=dict(examples=[{"example_prop_key": "example_prop_value"}]),
    )


class SampleLayoutTable(SampleLayout, make_revision_model_mixin(), table=True):
    __tablename__ = "sample_layout"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_sample_layout_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_sample_layout_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_sample_layout_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_sample_layout_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_sample_layout_name", "name"),
    )


class ClassifierTaxonomyTable(ClassifierTaxonomy, make_revision_model_mixin(), table=True):
    __tablename__ = "classifier_taxonomy"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_classifier_taxonomy_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_classifier_taxonomy_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_classifier_taxonomy_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_classifier_taxonomy_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_classifier_taxonomy_name_version", "name", "version"),
    )


class AnnotationGuidelineTable(AnnotationGuideline, make_revision_model_mixin(), table=True):
    __tablename__ = "annotation_guideline"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_annotation_guideline_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_annotation_guideline_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_annotation_guideline_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_annotation_guideline_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_annotation_guideline_name_version", "name", "version"),
    )


class ModelArchitectureTable(ModelArchitecture, make_revision_model_mixin(), table=True):
    __tablename__ = "model_architecture"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_architecture_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_model_architecture_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_architecture_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_architecture_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_architecture_name", "name"),
    )


class ModelBenchmarkTable(ModelBenchmark, make_revision_model_mixin(), table=True):
    __tablename__ = "model_benchmark"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_benchmark_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_model_benchmark_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_benchmark_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_benchmark_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_benchmark_name_version", "name", "version"),
    )


class DatasetRegistrationTable(DatasetRegistration, make_revision_model_mixin(), table=True):
    __tablename__ = "dataset_registration"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_dataset_registration_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_dataset_registration_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_dataset_registration_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_dataset_registration_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_dataset_registration_dataset_uuid", "dataset_uuid"),
    )


class DatasetPromotionTable(DatasetPromotion, make_revision_model_mixin(), table=True):
    __tablename__ = "dataset_promotion"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_dataset_promotion_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_dataset_promotion_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_dataset_promotion_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_dataset_promotion_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_dataset_promotion_dataset_uuid", "dataset_uuid"),
    )


class RegisteredDatasetTable(RegisteredDataset, make_revision_model_mixin(), table=True):
    __tablename__ = "registered_dataset"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_registered_dataset_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_registered_dataset_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_registered_dataset_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_registered_dataset_uuid", "uuid"),
    )


class RegisteredSampleTable(RegisteredSample, make_revision_model_mixin(), table=True):
    __tablename__ = "registered_sample"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_registered_sample_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_registered_sample_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_registered_sample_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_registered_sample_uuid", "uuid"),
    )


class RegisteredDatasetSampleTable(RegisteredDatasetSample, table=True):
    __tablename__ = "registered_dataset_sample"
    __table_args__ = (
        sa.PrimaryKeyConstraint("dataset_uuid", "sample_uuid", name="registered_dataset_sample_pkey"),
    )


class RegisteredDatasetLayoutTable(RegisteredDatasetLayout, table=True):
    __tablename__ = "registered_dataset_layout"
    __table_args__ = (
        sa.PrimaryKeyConstraint("dataset_uuid", "layout_uuid", name="registered_dataset_layout_pkey"),
    )


class SampleClassifierTable(SampleClassifier, make_revision_model_mixin(), table=True):
    __tablename__ = "sample_classifier"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_sample_classifier_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_sample_classifier_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_sample_classifier_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_sample_classifier_uuid", "uuid"),
        revision_model_mixin.make_active_index_for("ix_a_sample_classifier_sample_uuid", "sample_uuid"),
    )


class SampleAnnotationTable(SampleAnnotation, make_revision_model_mixin(), table=True):
    __tablename__ = "sample_annotation"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_sample_annotation_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_sample_annotation_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_sample_annotation_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_sample_annotation_uuid", "uuid"),
        revision_model_mixin.make_active_index_for("ix_a_sample_annotation_sample_uuid", "sample_uuid"),
    )


class ModelTrainingTable(ModelTraining, make_revision_model_mixin(), table=True):
    __tablename__ = "model_training"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_training_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_model_training_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_training_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_training_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_training_experiment_uuid", "experiment_uuid"),
    )


class ModelExperimentTable(ModelExperiment, make_revision_model_mixin(), table=True):
    __tablename__ = "model_experiment"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_experiment_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_model_experiment_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_experiment_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_experiment_uuid", "uuid"),
    )


class ModelExperimentPromotionTable(ModelExperimentPromotion, make_revision_model_mixin(), table=True):
    __tablename__ = "model_experiment_promotion"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_experiment_promotion_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision(
            "ix_u_model_experiment_promotion_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_experiment_promotion_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_experiment_promotion_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_experiment_promotion_experiment_uuid",
                                                          "experiment_uuid"),
    )


class ModelEvaluationTable(ModelEvaluation, make_revision_model_mixin(), table=True):
    __tablename__ = "model_evaluation"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_evaluation_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_model_evaluation_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_evaluation_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_evaluation_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_evaluation_assessment_uuid", "assessment_uuid"),
    )


class ModelAssessmentTable(ModelAssessment, make_revision_model_mixin(), table=True):
    __tablename__ = "model_assessment"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_assessment_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_model_assessment_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_assessment_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_assessment_uuid", "uuid"),
    )


class ModelAssessmentPromotionTable(ModelAssessmentPromotion, make_revision_model_mixin(), table=True):
    __tablename__ = "model_assessment_promotion"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_model_assessment_promotion_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision(
            "ix_u_model_assessment_promotion_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_model_assessment_promotion_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_assessment_promotion_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_model_assessment_promotion_assessment_uuid",
                                                          "assessment_uuid"),
    )


if typing.TYPE_CHECKING:
    RegistryBase = SQLModel


    class SampleLayoutTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        child_layout_uuids: sa_orm.Mapped[list[py_uuid.UUID] | None] = ...
        layout_spec: sa_orm.Mapped[JsonObject] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ClassifierTaxonomyTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        version: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        taxonomy_hierarchy: sa_orm.Mapped[JsonObject] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class AnnotationGuidelineTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        version: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        supported_layout_uuids: sa_orm.Mapped[list[py_uuid.UUID]] = ...
        annotation_schema: sa_orm.Mapped[JsonObject] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ModelArchitectureTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        version: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        supported_guideline_uuids: sa_orm.Mapped[list[py_uuid.UUID]] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ModelBenchmarkTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        version: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        supported_architecture_uuids: sa_orm.Mapped[list[py_uuid.UUID]] = ...
        benchmark_schema: sa_orm.Mapped[JsonObject] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class DatasetRegistrationTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        dataset_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        resource_path: sa_orm.Mapped[str] = ...
        flags: sa_orm.Mapped[int] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class DatasetPromotionTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        dataset_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        reviewer_sso_sid: sa_orm.Mapped[int] = ...
        flags: sa_orm.Mapped[int] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class RegisteredDatasetTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        contributor_sso_sid: sa_orm.Mapped[int] = ...
        tags: sa_orm.Mapped[list[str] | None] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class RegisteredSampleTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        path: sa_orm.Mapped[str] = ...
        layout_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        bag_name: sa_orm.Mapped[str] = ...
        vehicle_name: sa_orm.Mapped[str] = ...
        begin_frame_dt: sa_orm.Mapped[datetime.datetime] = ...
        end_frame_dt: sa_orm.Mapped[datetime.datetime] = ...
        child_sample_uuids: sa_orm.Mapped[list[py_uuid.UUID] | None] = ...
        tags: sa_orm.Mapped[list[str] | None] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class RegisteredDatasetSampleTable(RegistryBase):
        dataset_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        sample_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        annotation_uuid: sa_orm.Mapped[py_uuid.UUID | None] = ...


    class RegisteredDatasetLayoutTable(RegistryBase):
        dataset_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        layout_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        samples_count: sa_orm.Mapped[int] = ...


    class SampleClassifierTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        sample_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        taxonomy_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        classifier_data: sa_orm.Mapped[JsonObject] = ...


    class SampleAnnotationTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        sample_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        guideline_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        path: sa_orm.Mapped[str | None] = ...
        annotation_data: sa_orm.Mapped[JsonObject] = ...


    class ModelTrainingTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        experiment_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        flags: sa_orm.Mapped[int] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ModelExperimentTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        parent_uuid: sa_orm.Mapped[py_uuid.UUID | None] = ...
        architecture_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        dataset_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        contributor_sso_sid: sa_orm.Mapped[int] = ...
        path: sa_orm.Mapped[str | None] = ...
        checkpoint_path: sa_orm.Mapped[str | None] = ...
        tags: sa_orm.Mapped[list[str] | None] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ModelExperimentPromotionTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        experiment_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        reviewer_sso_sid: sa_orm.Mapped[int] = ...
        flags: sa_orm.Mapped[int] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ModelEvaluationTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        assessment_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        flags: sa_orm.Mapped[int] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ModelAssessmentTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        benchmark_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        experiment_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        dataset_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        description: sa_orm.Mapped[str] = ...
        contributor_sso_sid: sa_orm.Mapped[int] = ...
        path: sa_orm.Mapped[str | None] = ...
        assessment_data: sa_orm.Mapped[JsonObject | None] = ...
        tags: sa_orm.Mapped[list[str] | None] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class ModelAssessmentPromotionTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        assessment_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        reviewer_sso_sid: sa_orm.Mapped[int] = ...
        flags: sa_orm.Mapped[int] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...
