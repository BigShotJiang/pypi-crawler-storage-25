import enum
from typing import Self

import textcase
from plexus.common.utils.funcutils import singleton
from plexus.pulse.common.utils.ormutils import make_base_model

__all__ = [
    "BaseModel",
    "JobStatusFlag",
]

BaseModel = make_base_model()
BaseModel.metadata.schema = "pulse_demeter"
BaseModel.model_config.update(dict(alias_generator=textcase.camel, populate_by_name=True))


class JobStatusFlag(enum.Flag):
    """
    Comprehensive job status bitflags.

    Flags are grouped by functional categories with distinct bit ranges:
    - Progression: job lifecycle states (0x01 - 0x80).
    - Control: control and administrative requests (0x0100 - 0x8000).
    - Outcome: terminal states (0x010000 - 0x800000).
    """
    # Progression / lifecycle (ongoing states)
    Submitted = 0x01
    Queued = 0x02
    Scheduled = 0x04
    Running = 0x08
    Paused = 0x10
    Retrying = 0x20

    # Control / administrative
    EarlyStopRequested = 0x02_00
    CancelRequested = 0x04_00

    # Terminal / outcome
    Completed = 0x01_00_00
    EarlyStopped = 0x02_00_00
    Cancelled = 0x04_00_00
    Timeout = 0x08_00_00
    Failed = 0x10_00_00

    # Composite helpers
    Progressing = Submitted | Queued | Scheduled | Running | Paused | Retrying
    Terminal = Completed | EarlyStopped | Cancelled | Timeout | Failed

    @classmethod
    @singleton
    def progressing_states(cls) -> list[Self]:
        return [
            cls.Submitted,
            cls.Queued,
            cls.Scheduled,
            cls.Running,
            cls.Paused,
            cls.Retrying,
        ]

    @classmethod
    @singleton
    def terminal_states(cls) -> list[Self]:
        return [
            cls.Completed,
            cls.EarlyStopped,
            cls.Cancelled,
            cls.Timeout,
            cls.Failed,
        ]

    @classmethod
    @singleton
    def transitions(cls) -> dict[Self, set[Self]]:
        return {
            cls.Submitted: {
                cls.Queued,
                cls.CancelRequested,
            },
            cls.Queued: {
                cls.Scheduled,
                cls.CancelRequested,
            },
            cls.Scheduled: {
                cls.Running,
                cls.CancelRequested,
            },
            cls.Running: {
                cls.Paused,
                cls.EarlyStopRequested,
                cls.CancelRequested,
                cls.Completed,
                cls.Timeout,
                cls.Failed,
            },
            cls.Paused: {
                cls.Running,
                cls.EarlyStopRequested,
                cls.CancelRequested,
            },
            cls.Retrying: {
                cls.Queued,
                cls.CancelRequested,
            },
            cls.EarlyStopRequested: {
                cls.EarlyStopped,
            },
            cls.CancelRequested: {
                cls.Cancelled,
            },
        }
