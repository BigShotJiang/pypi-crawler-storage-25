import datetime
import uuid as py_uuid
from typing import Self

import pydantic as pdt
from plexus.common.utils.jsonutils import JsonType
from plexus.pulse.common.utils.datautils import (
    validate_bag_name,
    validate_colon_tag,
    validate_dt_timezone,
    validate_json_type_dump_size,
    validate_slash_tag,
    validate_snake_case,
    validate_strict_relpath,
    validate_user_name,
    validate_vehicle_name,
)
from plexus.pulse.common.utils.jsonutils import json_datetime_encoder
from plexus.pulse.common.utils.ormutils import make_base_model
from sqlmodel import Field

__all__ = [
    "BaseModel",
    "DatasetMetafile",
    "SampleMetafile",
    "StandaloneDataset",
    "StandaloneSample",
]

BaseModel = make_base_model()


class DatasetMetafile(BaseModel):
    name: str
    description: str
    contributor: str
    tags: list[str] | None = Field(default=None)
    props: JsonType

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("contributor", mode="after")
    @classmethod
    def validate_contributor(cls, v: str) -> str:
        validate_user_name(v)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v

    @pdt.field_validator("props", mode="after")
    @classmethod
    def validate_props(cls, v: JsonType) -> JsonType:
        validate_json_type_dump_size(v, 10000)
        return v


class SampleMetafile(BaseModel):
    layout_uuid: py_uuid.UUID | None = Field(default=None)
    layout_name: str | None = Field(default=None)
    bag_name: str
    vehicle_name: str
    begin_frame_dt: datetime.datetime
    end_frame_dt: datetime.datetime
    tags: list[str] | None = Field(default=None)
    props: JsonType

    @pdt.field_validator("layout_name", mode="after")
    @classmethod
    def validate_layout_name(cls, v: str | None) -> str | None:
        if v is not None:
            validate_slash_tag(v)
        return v

    @pdt.model_validator(mode="after")
    def validate_layout_uuid_layout_name(self) -> Self:
        if (self.layout_uuid is None) and (self.layout_name is None):
            raise ValueError("either layout_uuid or layout_name must be provided")
        return self

    @pdt.field_validator("bag_name", mode="after")
    @classmethod
    def validate_bag_name(cls, v: str) -> str:
        validate_bag_name(v)
        return v

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("begin_frame_dt", mode="after")
    @classmethod
    def validate_begin_frame_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.field_validator("end_frame_dt", mode="after")
    @classmethod
    def validate_end_frame_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_frame_dt_end_frame_dt(self) -> Self:
        if self.begin_frame_dt > self.end_frame_dt:
            raise ValueError(
                f"begin_frame_dt '{self.begin_frame_dt}' is greater than end_frame_dt '{self.end_frame_dt}'")
        return self

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v

    @pdt.field_validator("props", mode="after")
    @classmethod
    def validate_props(cls, v: JsonType) -> JsonType:
        validate_json_type_dump_size(v, 10000)
        return v

    @pdt.field_serializer("begin_frame_dt", mode="plain")
    def serialize_begin_frame_dt(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)

    @pdt.field_serializer("end_frame_dt", mode="plain")
    def serialize_end_frame_dt(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)


class StandaloneDataset(BaseModel):
    name: str
    description: str
    contributor: str
    tags: list[str] | None = Field(default=None)
    props: JsonType

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("contributor", mode="after")
    @classmethod
    def validate_contributor(cls, v: str) -> str:
        validate_user_name(v)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v

    @pdt.field_validator("props", mode="after")
    @classmethod
    def validate_props(cls, v: JsonType) -> JsonType:
        validate_json_type_dump_size(v, 10000)
        return v


class StandaloneSample(BaseModel):
    path: str
    layout_uuid: py_uuid.UUID
    bag_name: str
    vehicle_name: str
    begin_frame_dt: datetime.datetime
    end_frame_dt: datetime.datetime
    child_sample_paths: list[str] | None = Field(default=None)
    tags: list[str] | None = Field(default=None)
    props: JsonType

    @pdt.field_validator("path", mode="after")
    @classmethod
    def validate_path(cls, v: str) -> str:
        validate_strict_relpath(v)
        return v

    @pdt.field_validator("bag_name", mode="after")
    @classmethod
    def validate_bag_name(cls, v: str) -> str:
        validate_bag_name(v)
        return v

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("begin_frame_dt", mode="after")
    @classmethod
    def validate_begin_frame_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.field_validator("end_frame_dt", mode="after")
    @classmethod
    def validate_end_frame_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_frame_dt_end_frame_dt(self) -> Self:
        if self.begin_frame_dt > self.end_frame_dt:
            raise ValueError(
                f"begin_frame_dt '{self.begin_frame_dt}' is greater than end_frame_dt '{self.end_frame_dt}'")
        return self

    @pdt.field_validator("child_sample_paths", mode="after")
    @classmethod
    def validate_child_sample_paths(cls, v: list[str] | None) -> list[str] | None:
        for path in (v or []):
            validate_strict_relpath(path)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v

    @pdt.field_validator("props", mode="after")
    @classmethod
    def validate_props(cls, v: JsonType) -> JsonType:
        validate_json_type_dump_size(v, 10000)
        return v

    @pdt.field_serializer("begin_frame_dt", mode="plain")
    def serialize_begin_frame_dt(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)

    @pdt.field_serializer("end_frame_dt", mode="plain")
    def serialize_end_frame_dt(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)
