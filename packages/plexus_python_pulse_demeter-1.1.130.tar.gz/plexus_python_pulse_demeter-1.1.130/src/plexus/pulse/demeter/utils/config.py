from plexus.common.utils.config import Config
from plexus.common.utils.funcutils import singleton
from plexus.common.utils.pathutils import make_path


@singleton
def config() -> Config:
    default_items: list[tuple[str, str, str]] = [
        ("pulse.demeter.database", "host", ""),
        ("pulse.demeter.database", "port", "5432"),
        ("pulse.demeter.database", "username", ""),
        ("pulse.demeter.database", "password", ""),
        ("pulse.demeter.database", "database", "pulse-demeter"),
        ("pulse.demeter.vault", "access_key_id", ""),
        ("pulse.demeter.vault", "secret_access_key", ""),
        ("pulse.demeter.vault", "endpoint_url", "http://localhost:9000"),
    ]

    from plexus.pulse.common.utils.config import config as pulse_config

    instance = pulse_config(make_path("~/.plexus-pulse.cfg", expand=True, normalize=True, absolute=True))
    instance.restore()
    instance.update(default_items, overwrite=False)

    return instance
