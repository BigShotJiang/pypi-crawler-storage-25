import math
import timeit

import pytest_postgresql.factories
from fastapi.testclient import TestClient
from plexus.common.utils.dtutils import dt_parse_iso
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare, generate_dummy_uuid_str
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker, patched_value_factory

from plexus.pulse.demeter.app.api import current_dt_clock
from plexus.pulse.demeter.app.api.dataset_internal_endpoints import router as internal_router
from plexus.pulse.demeter.app.api.dataset_public_endpoints import router as public_router
from plexus.pulse.demeter.app.api.dataset_workflow_endpoints import router as workflow_router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models.registry import BaseModel, JobStatusFlag as Flag

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_make_session = patched_postgresql_session_maker("fixture_postgresql_test",
                                                        BaseModel,
                                                        app,
                                                        make_session,
                                                        expire_on_commit=False)
fixture_current_dt_clock = patched_value_factory(app, current_dt_clock)

client = TestClient(app)


def test_layouts(fixture_make_session):
    layouts_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/layouts/")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    for i in range(layouts_count):
        response = client.get(f"{public_router.prefix}/layout/", params={"uuid": request_data[i]["uuid"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])

        response = client.get(f"{public_router.prefix}/layout/", params={"name": request_data[i]["name"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])


def test_taxonomies(fixture_make_session):
    taxonomies_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(2, i),
        "name": f"taxonomy/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test taxonomy {i}",
        "taxonomy_hierarchy": {"categories": [{"id": "a", "children": []}]},
        "props": {"index": i},
    } for i in range(taxonomies_count)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(2, i),
        "name": f"taxonomy/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test taxonomy {i}",
        "taxonomy_hierarchy": {"categories": [{"id": "a", "children": []}]},
        "props": {"index": i},
    } for i in range(taxonomies_count)]

    response = client.post(f"{internal_router.prefix}/taxonomies/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/taxonomies/")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    for i in range(taxonomies_count):
        response = client.get(f"{public_router.prefix}/taxonomy/", params={"uuid": request_data[i]["uuid"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])

        response = client.get(f"{public_router.prefix}/taxonomy/", params={"name": request_data[i]["name"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])


def test_guidelines(fixture_make_session):
    guidelines_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(3, i),
        "name": f"guideline/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test guideline {i}",
        "supported_layout_uuids": [generate_dummy_uuid_str(1, i), generate_dummy_uuid_str(1, i + 1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    } for i in range(guidelines_count)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3, i),
        "name": f"guideline/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test guideline {i}",
        "supported_layout_uuids": [generate_dummy_uuid_str(1, i), generate_dummy_uuid_str(1, i + 1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    } for i in range(guidelines_count)]

    response = client.post(f"{internal_router.prefix}/guidelines/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/guidelines/")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    for i in range(guidelines_count):
        response = client.get(f"{public_router.prefix}/guideline/", params={"uuid": request_data[i]["uuid"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])

        response = client.get(f"{public_router.prefix}/guideline/", params={"name": request_data[i]["name"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])


def test_architectures(fixture_make_session):
    architectures_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"architecture/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(architectures_count)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"architecture/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(architectures_count)]

    response = client.post(f"{internal_router.prefix}/architectures/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/architectures/")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    for i in range(architectures_count):
        response = client.get(f"{public_router.prefix}/architecture/", params={"uuid": request_data[i]["uuid"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])

        response = client.get(f"{public_router.prefix}/architecture/", params={"name": request_data[i]["name"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])


def test_benchmarks(fixture_make_session):
    benchmarks_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(5, i),
        "name": f"benchmark/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test benchmark {i}",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, i)],
        "benchmark_schema": {
            "type": "object",
            "properties": {
                "metric": {"type": "number"},
                "test_id": {"type": "integer", "const": i},
            },
        },
        "props": {"suite_number": i},
    } for i in range(benchmarks_count)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(5, i),
        "name": f"benchmark/test_{i}",
        "version": f"1.0.{i}",
        "description": f"Test benchmark {i}",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, i)],
        "benchmark_schema": {
            "type": "object",
            "properties": {
                "metric": {"type": "number"},
                "test_id": {"type": "integer", "const": i},
            },
        },
        "props": {"suite_number": i},
    } for i in range(benchmarks_count)]

    response = client.post(f"{internal_router.prefix}/benchmarks/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/benchmarks/")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    for i in range(benchmarks_count):
        response = client.get(f"{public_router.prefix}/benchmark/", params={"uuid": request_data[i]["uuid"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])

        response = client.get(f"{public_router.prefix}/benchmark/", params={"name": request_data[i]["name"]})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect[i])


def test_list_datasets(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    registrations_count = 100

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_dataset_registration/",
                                   json={
                                       "uuid": generate_dummy_uuid_str(6, i),
                                       "resource_path": f"datasets/dummy_dataset_{i}" if i % 2 == 0 else f"datasets/another_dummy_dataset_{i}",
                                       "props": {},
                                       "dataset": {
                                           "uuid": generate_dummy_uuid_str(7, i),
                                           "name": f"dummy_dataset_{i}" if i % 2 == 0 else f"another_dummy_dataset_{i}",
                                           "description": "A dummy dataset",
                                           "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                           "tags": ["division:training", "mission:name:test"],
                                           "props": {},
                                       },
                                   })
        assert response.status_code == 200, response.text

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_dataset_registration/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(6, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    samples_count = 20

    for i in range(registrations_count):
        request_data = [{
            "uuid": generate_dummy_uuid_str(8, i, j),
            "path": f"pulse/demeter/datasets/dataset_{i}/samples/image_{j}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, j % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        } for j in range(samples_count)]

        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(
                f"{public_router.prefix}/append_dataset_with_samples/{generate_dummy_uuid_str(7, i)}",
                json=request_data,
            )
        assert response.status_code == 200, response.text

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_dataset_promotion/",
                                   params={
                                       "uuid": generate_dummy_uuid_str(15, i),
                                       "dataset_uuid": generate_dummy_uuid_str(7, i),
                                       "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                   })
        assert response.status_code == 200, response.text

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_dataset_promotion/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(15, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    def make_response_dataset_details(i: int):
        return {
            "dataset": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(7, i),
                "name": f"dummy_dataset_{i}" if i % 2 == 0 else f"another_dummy_dataset_{i}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "tags": ["division:training", "mission:name:test"],
                "props": {},
            },
            "samples_count": samples_count,
            "registration": {
                "sqn": registrations_count + i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(6, i),
                "dataset_uuid": generate_dummy_uuid_str(7, i),
                "resource_path": f"datasets/dummy_dataset_{i}" if i % 2 == 0 else f"datasets/another_dummy_dataset_{i}",
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "promotion": {
                "sqn": registrations_count + i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-03-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(15, i),
                "dataset_uuid": generate_dummy_uuid_str(7, i),
                "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "layouts": [
                {
                    "layout": {
                        "sqn": j + 1,
                        "created_at": "2020-01-01T00:00:00.000000+00:00",
                        "updated_at": "2020-01-01T00:00:00.000000+00:00",
                        "expired_at": None,
                        "record_sqn": j + 1,
                        "revision": 1,
                        "uuid": generate_dummy_uuid_str(1, j),
                        "name": f"multi_camera/layout_{j}",
                        "description": f"Multi camera layout {j}",
                        "child_layout_uuids": [],
                        "layout_spec": {
                            "type": "object",
                            "properties": {
                                "camera_type": {"type": "string"},
                                "resolution": {"type": "string"},
                            },
                        },
                        "props": {"camera_count": j + 1},
                    },
                    "samples_count": samples_count // layouts_count,
                }
                for j in range(layouts_count)
            ],
        }

    # First page
    response_expect = {
        "dataset_details": [make_response_dataset_details(i) for i in range(0, 10)],
        "pagination": {"skip": 0, "limit": 10, "total": registrations_count},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_datasets/",
                          params={
                              "limit": 10,
                              "begin_at": "2020-01-01T00:00:00.000000+00:00",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_datasets timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Name match
    response_expect = {
        "dataset_details": [make_response_dataset_details(i) for i in map(lambda x: x * 2 + 1, range(0, 10))],
        "pagination": {"skip": 0, "limit": 10, "total": registrations_count // 2},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_datasets/",
                          params={
                              "limit": 10,
                              "name_match": "another_dummy_dataset",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_datasets timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Get by UUID
    timer_total = 0.0
    timer_count = 0
    for i in range(10):
        response_expect = make_response_dataset_details(i)

        timer_start = timeit.default_timer()
        response = client.get(f"{public_router.prefix}/get_dataset/{generate_dummy_uuid_str(7, i)}")
        assert response.status_code == 200, response.text
        timer_total += timeit.default_timer() - timer_start
        timer_count += 1

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)

    print(f"get_dataset timer: {timer_total} for {timer_count} requests")

    # Second page contributed by a specific contributor
    response_expect = {
        "dataset_details": [make_response_dataset_details(i) for i in map(lambda x: (x + 10) * 2, range(0, 10))],
        "pagination": {"skip": 10, "limit": 10, "total": registrations_count // 2},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_datasets/",
                          params={
                              "skip": 10,
                              "limit": 10,
                              "end_at": "2020-04-01T00:00:00.000000+00:00",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_datasets timer: {timeit.default_timer() - timer_start}")

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_datasets/",
                          params={
                              "skip": 10,
                              "limit": 10,
                              "end_at": "2020-04-01T00:00:00.000000+00:00",
                              "contributor_sso_sid": 1234567890,
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_datasets timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Completed and shared jobs only
    response_expect = {
        "dataset_details": [make_response_dataset_details(i) for i in map(lambda x: x * 5, range(0, 10))],
        "pagination": {"skip": 0, "limit": 10, "total": registrations_count // 5},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_datasets/", params={"limit": 10})
    assert response.status_code == 200, response.text
    print(f"list_datasets timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Descending order by record_sqn
    response_expect = {
        "dataset_details": [make_response_dataset_details(i)
                            for i in map(lambda x: registrations_count - 1 - x, range(0, 10))],
        "pagination": {"skip": 0, "limit": 10, "total": registrations_count},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_datasets/",
                          params={
                              "limit": 10,
                              "only_completed_jobs": False,
                              "only_shared": False,
                              "order_by": ["-record_sqn"],
                          })
    assert response.status_code == 200, response.text
    print(f"list_datasets timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # No result before 2020-02-01
    response_expect = {
        "dataset_details": [],
        "pagination": {"skip": 0, "limit": 100, "total": 0},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_datasets/",
                          params={
                              "end_at": "2020-01-01T00:00:00.000000+00:00",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_datasets timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_list_model_experiments(fixture_make_session, fixture_current_dt_clock):
    datasets_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_dataset_{i}" if i % 2 == 0 else f"another_dummy_dataset_{i}",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
        "tags": ["division:training", "mission:name:test"],
        "props": {},
    } for i in range(datasets_count)]

    response = client.post(f"{internal_router.prefix}/datasets/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    architectures_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"perception/model_{i}",
        "version": f"1.0.{i}",
        "description": f"Model architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(architectures_count)]

    response = client.post(f"{internal_router.prefix}/architectures/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    trainings_count = 100

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_model_training/",
                                   json={
                                       "uuid": generate_dummy_uuid_str(12, i),
                                       "props": {},
                                       "experiment": {
                                           "uuid": generate_dummy_uuid_str(11, i),
                                           "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
                                           "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                                           "name": "dummy_model",
                                           "description": "A dummy model experiment",
                                           "contributor_sso_sid": 1234567890,
                                           "path": f"pulse/demeter/models/experiment_{i}",
                                           "checkpoint_path": f"epoch_{i}/model.pth",
                                           "tags": ["model:bev_perception", "framework:pytorch"],
                                           "props": {},
                                       },
                                   })
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_model_training/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(12, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        request_data = {
            "uuid": generate_dummy_uuid_str(11, i),
            "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
            "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
            "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
            "name": f"dummy_model_{i}" if i % 2 == 0 else f"another_dummy_model_{i}",
            "description": "A dummy model",
            "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
            "path": f"pulse/demeter/models/experiment_{i}",
            "checkpoint_path": f"epoch_{i}/model.pth",
            "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
            "props": {
                "version": f"1.0.{i}",
                "hyperparameters": {
                    "learning_rate": 0.001,
                    "batch_size": 32,
                    "optimizer": "Adam",
                },
            },
        }

        response = client.put(f"{internal_router.prefix}/experiment/{i + 1}",
                              json=request_data,
                              params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_experiment_promotion/",
                                   params={
                                       "uuid": generate_dummy_uuid_str(16, i),
                                       "experiment_uuid": generate_dummy_uuid_str(11, i),
                                       "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                   })
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_experiment_promotion/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(16, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    def make_response_experiment_details(i: int):
        return {
            "experiment": {
                "sqn": trainings_count + i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(11, i),
                "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
                "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
                "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                "name": f"dummy_model_{i}" if i % 2 == 0 else f"another_dummy_model_{i}",
                "description": "A dummy model",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "path": f"pulse/demeter/models/experiment_{i}",
                "checkpoint_path": f"epoch_{i}/model.pth",
                "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
                "props": {
                    "version": f"1.0.{i}",
                    "hyperparameters": {
                        "learning_rate": 0.001,
                        "batch_size": 32,
                        "optimizer": "Adam",
                    },
                },
            },
            "training": {
                "sqn": trainings_count + i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(12, i),
                "experiment_uuid": generate_dummy_uuid_str(11, i),
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "promotion": {
                "sqn": trainings_count + i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-03-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(16, i),
                "experiment_uuid": generate_dummy_uuid_str(11, i),
                "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "architecture": {
                "sqn": i % architectures_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % architectures_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(4, i % architectures_count),
                "name": f"perception/model_{i % architectures_count}",
                "version": f"1.0.{i % architectures_count}",
                "description": f"Model architecture {i % architectures_count}",
                "supported_guideline_uuids": [generate_dummy_uuid_str(3, i % architectures_count)],
                "props": {
                    "version": f"1.0.{i % architectures_count}",
                    "backbone": f"resnet{50 + i % architectures_count}",
                },
            },
            "dataset": {
                "sqn": i % datasets_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % datasets_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(7, i % datasets_count),
                "name": f"dummy_dataset_{i % datasets_count}" if i % 2 == 0 else f"another_dummy_dataset_{i % datasets_count}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "tags": ["division:training", "mission:name:test"],
                "props": {},
            },
            "layouts": [],
            "samples_count": 0,
        }

    # First page
    response_expect = {
        "experiment_details": [make_response_experiment_details(i) for i in range(0, 10)],
        "pagination": {"skip": 0, "limit": 10, "total": trainings_count},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_experiments/",
                          params={
                              "limit": 10,
                              "begin_at": "2020-01-01T00:00:00.000000+00:00",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_experiments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Name match
    response_expect = {
        "experiment_details": [make_response_experiment_details(i) for i in map(lambda x: x * 2 + 1, range(0, 10))],
        "pagination": {"skip": 0, "limit": 10, "total": trainings_count // 2},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_experiments/",
                          params={
                              "limit": 10,
                              "name_match": "another_dummy_model",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_experiments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Get by UUID
    timer_total = 0.0
    timer_count = 0
    for i in range(10):
        response_expect = make_response_experiment_details(i)

        timer_start = timeit.default_timer()
        response = client.get(f"{public_router.prefix}/get_model_experiment/{generate_dummy_uuid_str(11, i)}")
        assert response.status_code == 200, response.text
        timer_total += timeit.default_timer() - timer_start
        timer_count += 1

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)

    print(f"get_model_experiment timer: {timer_total} for {timer_count} requests")

    # Second page contributed by a specific contributor
    response_expect = {
        "experiment_details": [make_response_experiment_details(i) for i in map(lambda x: (x + 10) * 2, range(0, 10))],
        "pagination": {"skip": 10, "limit": 10, "total": trainings_count // 2},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_experiments/",
                          params={
                              "skip": 10,
                              "limit": 10,
                              "end_at": "2020-04-01T00:00:00.000000+00:00",
                              "contributor_sso_sid": 1234567890,
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_experiments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Completed and shared jobs only
    response_expect = {
        "experiment_details": [make_response_experiment_details(i) for i in map(lambda x: (x + 10) * 5, range(0, 10))],
        "pagination": {"skip": 10, "limit": 10, "total": trainings_count // 5},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_experiments/", params={"skip": 10, "limit": 10})
    assert response.status_code == 200, response.text
    print(f"list_model_experiments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Descending order by record_sqn
    response_expect = {
        "experiment_details": [make_response_experiment_details(i)
                               for i in map(lambda x: trainings_count - 1 - x, range(0, 10))],
        "pagination": {"skip": 0, "limit": 10, "total": trainings_count},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_experiments/",
                          params={
                              "limit": 10,
                              "only_completed_jobs": False,
                              "only_shared": False,
                              "order_by": "-record_sqn",
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_experiments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # No result before 2020-02-01
    response_expect = {
        "experiment_details": [],
        "pagination": {"skip": 0, "limit": 100, "total": 0},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_experiments/",
                          params={
                              "end_at": "2020-01-01T00:00:00.000000+00:00",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_experiments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_list_model_assessments(fixture_make_session, fixture_current_dt_clock):
    datasets_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_dataset_{i}" if i % 2 == 0 else f"another_dummy_dataset_{i}",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
        "tags": ["division:training", "mission:name:test"],
        "props": {},
    } for i in range(datasets_count)]

    response = client.post(f"{internal_router.prefix}/datasets/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    architectures_count = 20

    request_data = [{
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"perception/model_{i}",
        "version": f"1.0.{i}",
        "description": f"Model architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(architectures_count)]

    response = client.post(f"{internal_router.prefix}/architectures/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    benchmarks_count = 20

    request_data = [{
        "uuid": generate_dummy_uuid_str(5, i),
        "name": f"benchmark/spec_{i}",
        "version": f"1.0.{i}",
        "description": f"Test benchmark {i}",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, i)],
        "benchmark_schema": {"type": "object"},
        "props": {},
    } for i in range(benchmarks_count)]

    response = client.post(f"{internal_router.prefix}/benchmarks/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    experiments_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(11, i),
        "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
        "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
        "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
        "name": f"dummy_model_{i}",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
        "path": f"pulse/demeter/models/experiment_{i}",
        "checkpoint_path": f"epoch_{i}/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {"version": f"1.0.{i}"},
    } for i in range(experiments_count)]

    response = client.post(f"{internal_router.prefix}/experiments/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    evaluations_count = 100

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_model_evaluation/",
                                   json={
                                       "uuid": generate_dummy_uuid_str(14, i),
                                       "props": {},
                                       "assessment": {
                                           "uuid": generate_dummy_uuid_str(13, i),
                                           "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
                                           "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
                                           "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                                           "name": f"model_assessment_{i}",
                                           "description": f"Model assessment {i}",
                                           "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                           "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
                                           "assessment_data": {"version": f"1.0.{i}", "metric": "mAP"},
                                           "tags": ["benchmark:standard", "scope:full"],
                                           "props": {},
                                       },
                                   })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_model_evaluation/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(14, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        request_data = {
            "uuid": generate_dummy_uuid_str(13, i),
            "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
            "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
            "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
            "name": f"model_assessment_{i}" if i % 2 == 0 else f"another_model_assessment_{i}",
            "description": f"Model assessment {i}",
            "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
            "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
            "assessment_data": {"version": f"1.0.{i}", "metric": "mAP"},
            "tags": ["benchmark:standard", "scope:full"],
            "props": {},
        }

        response = client.put(f"{internal_router.prefix}/assessment/{i + 1}",
                              json=request_data,
                              params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_assessment_promotion/",
                                   params={
                                       "uuid": generate_dummy_uuid_str(17, i),
                                       "assessment_uuid": generate_dummy_uuid_str(13, i),
                                       "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                   })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_assessment_promotion/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(17, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    def make_response_assessment_details(i: int):
        return {
            "assessment": {
                "sqn": evaluations_count + i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(13, i),
                "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
                "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
                "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                "name": f"model_assessment_{i}" if i % 2 == 0 else f"another_model_assessment_{i}",
                "description": f"Model assessment {i}",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
                "assessment_data": {"version": f"1.0.{i}", "metric": "mAP"},
                "tags": ["benchmark:standard", "scope:full"],
                "props": {},
            },
            "evaluation": {
                "sqn": evaluations_count + i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(14, i),
                "assessment_uuid": generate_dummy_uuid_str(13, i),
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "promotion": {
                "sqn": evaluations_count + i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-03-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(17, i),
                "assessment_uuid": generate_dummy_uuid_str(13, i),
                "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "benchmark": {
                "sqn": i % benchmarks_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % benchmarks_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
                "name": f"benchmark/spec_{i % benchmarks_count}",
                "version": f"1.0.{i % benchmarks_count}",
                "description": f"Test benchmark {i % benchmarks_count}",
                "supported_architecture_uuids": [generate_dummy_uuid_str(4, i % architectures_count)],
                "benchmark_schema": {"type": "object"},
                "props": {},
            },
            "experiment": {
                "sqn": i % experiments_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % experiments_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(11, i % experiments_count),
                "parent_uuid": (generate_dummy_uuid_str(11, i % experiments_count - 1)
                                if i % experiments_count > 0 else None),
                "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
                "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                "name": f"dummy_model_{i}",
                "description": "A dummy model",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "path": f"pulse/demeter/models/experiment_{i}",
                "checkpoint_path": f"epoch_{i}/model.pth",
                "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
                "props": {"version": f"1.0.{i}"},
            },
            "dataset": {
                "sqn": i % datasets_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % datasets_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(7, i % datasets_count),
                "name": f"dummy_dataset_{i % datasets_count}" if i % 2 == 0 else f"another_dummy_dataset_{i % datasets_count}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "tags": ["division:training", "mission:name:test"],
                "props": {},
            },
            "layouts": [],
            "samples_count": 0,
            "architecture": {
                "sqn": i % architectures_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % architectures_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(4, i % architectures_count),
                "name": f"perception/model_{i % architectures_count}",
                "version": f"1.0.{i % architectures_count}",
                "description": f"Model architecture {i % architectures_count}",
                "supported_guideline_uuids": [generate_dummy_uuid_str(3, i % architectures_count)],
                "props": {
                    "version": f"1.0.{i % architectures_count}",
                    "backbone": f"resnet{50 + i % architectures_count}",
                },
            },
        }

    # First page
    response_expect = {
        "assessment_details": [make_response_assessment_details(i) for i in range(0, 10)],
        "pagination": {"skip": 0, "limit": 10, "total": evaluations_count},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_assessments/",
                          params={
                              "limit": 10,
                              "begin_at": "2020-01-01T00:00:00.000000+00:00",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_assessments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Name match
    response_expect = {
        "assessment_details": [make_response_assessment_details(i) for i in map(lambda x: x * 2 + 1, range(0, 10))],
        "pagination": {"skip": 0, "limit": 10, "total": evaluations_count // 2},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_assessments/",
                          params={
                              "limit": 10,
                              "name_match": "another_model_assessment",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_assessments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Get by UUID
    timer_total = 0.0
    timer_count = 0
    for i in range(10):
        response_expect = make_response_assessment_details(i)

        timer_start = timeit.default_timer()
        response = client.get(f"{public_router.prefix}/get_model_assessment/{generate_dummy_uuid_str(13, i)}")
        assert response.status_code == 200, response.text
        timer_total += timeit.default_timer() - timer_start
        timer_count += 1

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)

    print(f"get_model_assessment timer: {timer_total} for {timer_count} requests")

    # Second page contributed by a specific contributor
    response_expect = {
        "assessment_details": [make_response_assessment_details(i) for i in map(lambda x: (x + 10) * 2, range(0, 10))],
        "pagination": {"skip": 10, "limit": 10, "total": evaluations_count // 2},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_assessments/",
                          params={
                              "skip": 10,
                              "limit": 10,
                              "end_at": "2020-04-01T00:00:00.000000+00:00",
                              "contributor_sso_sid": 1234567890,
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_assessments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Completed and shared jobs only
    response_expect = {
        "assessment_details": [make_response_assessment_details(i) for i in map(lambda x: (x + 10) * 5, range(0, 10))],
        "pagination": {"skip": 10, "limit": 10, "total": evaluations_count // 5},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_assessments/", params={"skip": 10, "limit": 10})
    assert response.status_code == 200, response.text
    print(f"list_model_assessments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # Descending order by record_sqn
    response_expect = {
        "assessment_details": [make_response_assessment_details(i)
                               for i in map(lambda x: evaluations_count - 1 - x, range(0, 10))],
        "pagination": {"skip": 0, "limit": 10, "total": evaluations_count},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_assessments/",
                          params={
                              "limit": 10,
                              "only_completed_jobs": False,
                              "only_shared": False,
                              "order_by": "-record_sqn",
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_assessments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    # No result before 2020-02-01
    response_expect = {
        "assessment_details": [],
        "pagination": {"skip": 0, "limit": 100, "total": 0},
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/list_model_assessments/",
                          params={
                              "end_at": "2020-01-01T00:00:00.000000+00:00",
                              "only_completed_jobs": False,
                              "only_shared": False,
                          })
    assert response.status_code == 200, response.text
    print(f"list_model_assessments timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_dataset_with_samples(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    samples_count = 100

    request_data = {
        "dataset": {
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "samples": [{
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        } for i in range(samples_count)],
    }

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count // layouts_count,
        } for i in range(layouts_count)],
        "samples": [{
            "sqn": i + 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        } for i in range(samples_count)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_with_samples/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/get_dataset_with_samples/{generate_dummy_uuid_str(7)}")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_append_dataset_with_samples(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "dataset": {
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "samples": [],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_with_samples/",
                               json=request_data)
    assert response.status_code == 200, response.text

    samples_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(8, i),
        "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
        "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    } for i in range(samples_count)]

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count // layouts_count,
        } for i in range(layouts_count)],
        "samples": [{
            "sqn": i + 1,
            "created_at": "2020-02-01T00:00:00.000000+00:00",
            "updated_at": "2020-02-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        } for i in range(samples_count)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/append_dataset_with_samples/{generate_dummy_uuid_str(7)}",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    request_data = [{
        "uuid": generate_dummy_uuid_str(8, i),
        "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
        "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    } for i in range(samples_count, samples_count * 2)]

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count * 2 // layouts_count,
        } for i in range(layouts_count)],
        "samples": [{
            "sqn": i + 1,
            "created_at": "2020-02-01T00:00:00.000000+00:00",
            "updated_at": "2020-02-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        } for i in range(samples_count * 2)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/append_dataset_with_samples/{generate_dummy_uuid_str(7)}",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_dataset_with_sample_and_annotations(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    samples_count = 100

    request_data = {
        "dataset": {
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "sample_and_annotations": [{
            "sample": {
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "annotation": {
                "uuid": generate_dummy_uuid_str(10, i),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "guideline_uuid": generate_dummy_uuid_str(3),
                "path": f"pulse/demeter/datasets/dataset/annotations/annotation_{i}.json",
                "annotation_data": {
                    "annotator": "john.doe",
                    "annotation_type": "3d_bounding_box",
                    "objects": [
                        {
                            "id": f"obj_{i}_001",
                            "type": "3d_bounding_box",
                            "category": "vehicle",
                            "cuboid": {
                                "dimensions": {
                                    "length": 4.5 + 0.0001 * i,
                                    "width": 1.8 + 0.0001 * i,
                                    "height": 1.5 + 0.0001 * i,
                                },
                                "center": {"x": 10.0 + 0.001 * i, "y": 5.0 + 0.001 * i, "z": 0.75 + 0.001 * i},
                                "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                        {
                            "id": f"obj_{i}_002",
                            "type": "3d_bounding_box",
                            "category": "pedestrian",
                            "cuboid": {
                                "dimensions": {
                                    "length": 0.5 + 0.0001 * i,
                                    "width": 0.5 + 0.0001 * i,
                                    "height": 1.7 + 0.0001 * i,
                                },
                                "center": {"x": 15.0 + 0.001 * i, "y": 3.0 + 0.001 * i, "z": 0.85 + 0.001 * i},
                                "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                    ],
                    "metadata": {
                        "annotation_time_seconds": 120 + 0.01 * i,
                        "quality_score": 0.95 + 0.00001 * i,
                    },
                },
            },
        } for i in range(samples_count)],
    }

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count // layouts_count,
        } for i in range(layouts_count)],
        "sample_and_annotations": [{
            "sample": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "annotation": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(10, i),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "guideline_uuid": generate_dummy_uuid_str(3),
                "path": f"pulse/demeter/datasets/dataset/annotations/annotation_{i}.json",
                "annotation_data": {
                    "annotator": "john.doe",
                    "annotation_type": "3d_bounding_box",
                    "objects": [
                        {
                            "id": f"obj_{i}_001",
                            "type": "3d_bounding_box",
                            "category": "vehicle",
                            "cuboid": {
                                "dimensions": {
                                    "length": 4.5 + 0.0001 * i,
                                    "width": 1.8 + 0.0001 * i,
                                    "height": 1.5 + 0.0001 * i,
                                },
                                "center": {"x": 10.0 + 0.001 * i, "y": 5.0 + 0.001 * i, "z": 0.75 + 0.001 * i},
                                "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                        {
                            "id": f"obj_{i}_002",
                            "type": "3d_bounding_box",
                            "category": "pedestrian",
                            "cuboid": {
                                "dimensions": {
                                    "length": 0.5 + 0.0001 * i,
                                    "width": 0.5 + 0.0001 * i,
                                    "height": 1.7 + 0.0001 * i,
                                },
                                "center": {"x": 15.0 + 0.001 * i, "y": 3.0 + 0.001 * i, "z": 0.85 + 0.001 * i},
                                "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                    ],
                    "metadata": {
                        "annotation_time_seconds": 120 + 0.01 * i,
                        "quality_score": 0.95 + 0.00001 * i,
                    },
                },
            },
        } for i in range(samples_count)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_with_sample_and_annotations/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(
        f"{public_router.prefix}/get_dataset_with_sample_and_annotations/{generate_dummy_uuid_str(7)}")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_append_dataset_with_sample_and_annotations(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "dataset": {
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "sample_and_annotations": [],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_with_sample_and_annotations/",
                               json=request_data)
    assert response.status_code == 200, response.text

    samples_count = 100

    request_data = [{
        "sample": {
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        },
        "annotation": {
            "uuid": generate_dummy_uuid_str(10, i),
            "sample_uuid": generate_dummy_uuid_str(8, i),
            "guideline_uuid": generate_dummy_uuid_str(3),
            "path": f"pulse/demeter/datasets/dataset/annotations/annotation_{i}.json",
            "annotation_data": {
                "annotator": "john.doe",
                "annotation_type": "3d_bounding_box",
                "objects": [
                    {
                        "id": f"obj_{i}_001",
                        "type": "3d_bounding_box",
                        "category": "vehicle",
                        "cuboid": {
                            "dimensions": {
                                "length": 4.5 + 0.0001 * i,
                                "width": 1.8 + 0.0001 * i,
                                "height": 1.5 + 0.0001 * i,
                            },
                            "center": {"x": 10.0 + 0.001 * i, "y": 5.0 + 0.001 * i, "z": 0.75 + 0.001 * i},
                            "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                        },
                    },
                    {
                        "id": f"obj_{i}_002",
                        "type": "3d_bounding_box",
                        "category": "pedestrian",
                        "cuboid": {
                            "dimensions": {
                                "length": 0.5 + 0.0001 * i,
                                "width": 0.5 + 0.0001 * i,
                                "height": 1.7 + 0.0001 * i,
                            },
                            "center": {"x": 15.0 + 0.001 * i, "y": 3.0 + 0.001 * i, "z": 0.85 + 0.001 * i},
                            "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                        },
                    },
                ],
                "metadata": {
                    "annotation_time_seconds": 120 + 0.01 * i,
                    "quality_score": 0.95 + 0.00001 * i,
                },
            },
        },
    } for i in range(samples_count)]

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count // layouts_count,
        } for i in range(layouts_count)],
        "sample_and_annotations": [{
            "sample": {
                "sqn": i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "annotation": {
                "sqn": i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(10, i),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "guideline_uuid": generate_dummy_uuid_str(3),
                "path": f"pulse/demeter/datasets/dataset/annotations/annotation_{i}.json",
                "annotation_data": {
                    "annotator": "john.doe",
                    "annotation_type": "3d_bounding_box",
                    "objects": [
                        {
                            "id": f"obj_{i}_001",
                            "type": "3d_bounding_box",
                            "category": "vehicle",
                            "cuboid": {
                                "dimensions": {
                                    "length": 4.5 + 0.0001 * i,
                                    "width": 1.8 + 0.0001 * i,
                                    "height": 1.5 + 0.0001 * i,
                                },
                                "center": {"x": 10.0 + 0.001 * i, "y": 5.0 + 0.001 * i, "z": 0.75 + 0.001 * i},
                                "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                        {
                            "id": f"obj_{i}_002",
                            "type": "3d_bounding_box",
                            "category": "pedestrian",
                            "cuboid": {
                                "dimensions": {
                                    "length": 0.5 + 0.0001 * i,
                                    "width": 0.5 + 0.0001 * i,
                                    "height": 1.7 + 0.0001 * i,
                                },
                                "center": {"x": 15.0 + 0.001 * i, "y": 3.0 + 0.001 * i, "z": 0.85 + 0.001 * i},
                                "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                    ],
                    "metadata": {
                        "annotation_time_seconds": 120 + 0.01 * i,
                        "quality_score": 0.95 + 0.00001 * i,
                    },
                },
            },
        } for i in range(samples_count)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(
            f"{public_router.prefix}/append_dataset_with_sample_and_annotations/{generate_dummy_uuid_str(7)}",
            json=request_data,
        )
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    request_data = [{
        "sample": {
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        },
        "annotation": {
            "uuid": generate_dummy_uuid_str(10, i),
            "sample_uuid": generate_dummy_uuid_str(8, i),
            "guideline_uuid": generate_dummy_uuid_str(3),
            "path": f"pulse/demeter/datasets/dataset/annotations/annotation_{i}.json",
            "annotation_data": {
                "annotator": "john.doe",
                "annotation_type": "3d_bounding_box",
                "objects": [
                    {
                        "id": f"obj_{i}_001",
                        "type": "3d_bounding_box",
                        "category": "vehicle",
                        "cuboid": {
                            "dimensions": {
                                "length": 4.5 + 0.0001 * i,
                                "width": 1.8 + 0.0001 * i,
                                "height": 1.5 + 0.0001 * i,
                            },
                            "center": {"x": 10.0 + 0.001 * i, "y": 5.0 + 0.001 * i, "z": 0.75 + 0.001 * i},
                            "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                        },
                    },
                    {
                        "id": f"obj_{i}_002",
                        "type": "3d_bounding_box",
                        "category": "pedestrian",
                        "cuboid": {
                            "dimensions": {
                                "length": 0.5 + 0.0001 * i,
                                "width": 0.5 + 0.0001 * i,
                                "height": 1.7 + 0.0001 * i,
                            },
                            "center": {"x": 15.0 + 0.001 * i, "y": 3.0 + 0.001 * i, "z": 0.85 + 0.001 * i},
                            "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                        },
                    },
                ],
                "metadata": {
                    "annotation_time_seconds": 120 + 0.01 * i,
                    "quality_score": 0.95 + 0.00001 * i,
                },
            },
        },
    } for i in range(samples_count, samples_count * 2)]

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count * 2 // layouts_count,
        } for i in range(layouts_count)],
        "sample_and_annotations": [{
            "sample": {
                "sqn": i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "annotation": {
                "sqn": i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(10, i),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "guideline_uuid": generate_dummy_uuid_str(3),
                "path": f"pulse/demeter/datasets/dataset/annotations/annotation_{i}.json",
                "annotation_data": {
                    "annotator": "john.doe",
                    "annotation_type": "3d_bounding_box",
                    "objects": [
                        {
                            "id": f"obj_{i}_001",
                            "type": "3d_bounding_box",
                            "category": "vehicle",
                            "cuboid": {
                                "dimensions": {
                                    "length": 4.5 + 0.0001 * i,
                                    "width": 1.8 + 0.0001 * i,
                                    "height": 1.5 + 0.0001 * i,
                                },
                                "center": {"x": 10.0 + 0.001 * i, "y": 5.0 + 0.001 * i, "z": 0.75 + 0.001 * i},
                                "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                        {
                            "id": f"obj_{i}_002",
                            "type": "3d_bounding_box",
                            "category": "pedestrian",
                            "cuboid": {
                                "dimensions": {
                                    "length": 0.5 + 0.0001 * i,
                                    "width": 0.5 + 0.0001 * i,
                                    "height": 1.7 + 0.0001 * i,
                                },
                                "center": {"x": 15.0 + 0.001 * i, "y": 3.0 + 0.001 * i, "z": 0.85 + 0.001 * i},
                                "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                            },
                        },
                    ],
                    "metadata": {
                        "annotation_time_seconds": 120 + 0.01 * i,
                        "quality_score": 0.95 + 0.00001 * i,
                    },
                },
            },
        } for i in range(samples_count * 2)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(
            f"{public_router.prefix}/append_dataset_with_sample_and_annotations/{generate_dummy_uuid_str(7)}",
            json=request_data,
        )
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_dataset_with_samples_with_classifiers(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    samples_count = 100
    classifiers_count = 10

    request_data = {
        "dataset": {
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "samples_with_classifiers": [{
            "sample": {
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "classifiers": [{
                "uuid": generate_dummy_uuid_str(9, i, j),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "taxonomy_uuid": generate_dummy_uuid_str(2),
                "classifier_data": {
                    "classifier_type": "object_detection",
                    "model": "yolov8",
                    "confidence_threshold": 0.5 + 0.0001 * i + 0.00001 * j,
                    "detections": [
                        {
                            "class": "vehicle",
                            "confidence": 0.9 + 0.0001 * i + 0.00001 * j,
                            "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                        },
                    ],
                },
            } for j in range(classifiers_count)],
        } for i in range(samples_count)],
    }

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count // layouts_count,
        } for i in range(layouts_count)],
        "samples_with_classifiers": [{
            "sample": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "classifiers": [{
                "sqn": i * classifiers_count + j + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i * classifiers_count + j + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(9, i, j),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "taxonomy_uuid": generate_dummy_uuid_str(2),
                "classifier_data": {
                    "classifier_type": "object_detection",
                    "model": "yolov8",
                    "confidence_threshold": 0.5 + 0.0001 * i + 0.00001 * j,
                    "detections": [
                        {
                            "class": "vehicle",
                            "confidence": 0.9 + 0.0001 * i + 0.00001 * j,
                            "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                        },
                    ],
                },
            } for j in range(classifiers_count)],
        } for i in range(samples_count)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_with_samples_with_classifiers/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(
        f"{public_router.prefix}/get_dataset_with_samples_with_classifiers/{generate_dummy_uuid_str(7)}")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_append_dataset_with_samples_with_classifiers(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "dataset": {
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "samples_with_classifiers": [],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_with_samples_with_classifiers/",
                               json=request_data)
    assert response.status_code == 200, response.text

    samples_count = 100
    classifiers_count = 10

    request_data = [{
        "sample": {
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        },
        "classifiers": [{
            "uuid": generate_dummy_uuid_str(9, i, j),
            "sample_uuid": generate_dummy_uuid_str(8, i),
            "taxonomy_uuid": generate_dummy_uuid_str(2),
            "classifier_data": {
                "classifier_type": "object_detection",
                "model": "yolov8",
                "confidence_threshold": 0.5 + 0.0001 * i + 0.00001 * j,
                "detections": [
                    {
                        "class": "vehicle",
                        "confidence": 0.9 + 0.0001 * i + 0.00001 * j,
                        "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                    },
                ],
            },
        } for j in range(classifiers_count)],
    } for i in range(samples_count)]

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count // layouts_count,
        } for i in range(layouts_count)],
        "samples_with_classifiers": [{
            "sample": {
                "sqn": i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "classifiers": [{
                "sqn": i * classifiers_count + j + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i * classifiers_count + j + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(9, i, j),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "taxonomy_uuid": generate_dummy_uuid_str(2),
                "classifier_data": {
                    "classifier_type": "object_detection",
                    "model": "yolov8",
                    "confidence_threshold": 0.5 + 0.0001 * i + 0.00001 * j,
                    "detections": [
                        {
                            "class": "vehicle",
                            "confidence": 0.9 + 0.0001 * i + 0.00001 * j,
                            "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                        },
                    ],
                },
            } for j in range(classifiers_count)],
        } for i in range(samples_count)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(
            f"{public_router.prefix}/append_dataset_with_samples_with_classifiers/{generate_dummy_uuid_str(7)}",
            json=request_data,
        )
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(
        f"{public_router.prefix}/get_dataset_with_samples_with_classifiers/{generate_dummy_uuid_str(7)}")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    request_data = [{
        "sample": {
            "uuid": generate_dummy_uuid_str(8, i),
            "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        },
        "classifiers": [{
            "uuid": generate_dummy_uuid_str(9, i, j),
            "sample_uuid": generate_dummy_uuid_str(8, i),
            "taxonomy_uuid": generate_dummy_uuid_str(2),
            "classifier_data": {
                "classifier_type": "object_detection",
                "model": "yolov8",
                "confidence_threshold": 0.5 + 0.0001 * i + 0.00001 * j,
                "detections": [
                    {
                        "class": "vehicle",
                        "confidence": 0.9 + 0.0001 * i + 0.00001 * j,
                        "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                    },
                ],
            },
        } for j in range(classifiers_count)],
    } for i in range(samples_count, samples_count * 2)]

    response_expect = {
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count * 2 // layouts_count,
        } for i in range(layouts_count)],
        "samples_with_classifiers": [{
            "sample": {
                "sqn": i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(8, i),
                "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": "20200101T000000-dummy_vehicle-0.bag",
                "vehicle_name": "dummy_vehicle",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            },
            "classifiers": [{
                "sqn": i * classifiers_count + j + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i * classifiers_count + j + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(9, i, j),
                "sample_uuid": generate_dummy_uuid_str(8, i),
                "taxonomy_uuid": generate_dummy_uuid_str(2),
                "classifier_data": {
                    "classifier_type": "object_detection",
                    "model": "yolov8",
                    "confidence_threshold": 0.5 + 0.0001 * i + 0.00001 * j,
                    "detections": [
                        {
                            "class": "vehicle",
                            "confidence": 0.9 + 0.0001 * i + 0.00001 * j,
                            "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                        },
                    ],
                },
            } for j in range(classifiers_count)],
        } for i in range(samples_count * 2)],
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(
            f"{public_router.prefix}/append_dataset_with_samples_with_classifiers/{generate_dummy_uuid_str(7)}",
            json=request_data
        )
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(
        f"{public_router.prefix}/get_dataset_with_samples_with_classifiers/{generate_dummy_uuid_str(7)}")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_dataset_from_conditions(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    datasets_count = 10
    samples_count = 100

    for j in range(datasets_count):
        request_data = {
            "dataset": {
                "uuid": generate_dummy_uuid_str(7, j),
                "name": f"dummy_dataset_{j}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890,
                "tags": ["division:training", "mission:name:nation_cover_2020"],
                "props": {},
            },
            "samples": [{
                "uuid": generate_dummy_uuid_str(8, j, i),
                "path": f"pulse/demeter/datasets/dataset_{j}/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1, i % layouts_count),
                "bag_name": f"20200101T000000-dummy_vehicle_{j}-0.bag",
                "vehicle_name": f"dummy_vehicle_{j}",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": [
                    "tod:daytime" if i % 3 == 0 else "tod:nighttime",
                    "weather:sunny" if i % 2 == 0 else "weather:rainy",
                    "road:traffic:leading",
                    "road:layout:straight",
                ],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            } for i in range(samples_count)],
        }

        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{public_router.prefix}/create_dataset_with_samples/",
                                   json=request_data)
        assert response.status_code == 200, response.text

    response_expect = {
        "dataset": {
            "sqn": datasets_count + 1,
            "created_at": "2020-02-01T00:00:00.000000+00:00",
            "updated_at": "2020-02-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": datasets_count + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7, datasets_count),
            "name": "dummy_dataset_from_conditions",
            "description": "A dummy dataset created from conditions",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:test"],
            "props": {},
        },
        "layouts": [{
            "layout": {
                "sqn": i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(1, i),
                "name": f"multi_camera/layout_{i}",
                "description": f"Multi camera layout {i}",
                "child_layout_uuids": [],
                "layout_spec": {
                    "type": "object",
                    "properties": {
                        "camera_type": {"type": "string"},
                        "resolution": {"type": "string"},
                    },
                },
                "props": {"camera_count": i + 1},
            },
            "samples_count": samples_count // layouts_count
                             * sum(1 for j in range(datasets_count) if j % 3 == 0 and j % 2 != 0),
        } for i in range(layouts_count)],
        "samples_count": sum(1 for j in range(datasets_count) if j % 3 == 0 and j % 2 != 0) * samples_count,
        "registration": None,
        "promotion": None,
    }

    timer_start = timeit.default_timer()
    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_from_conditions/",
                               json={
                                   "dataset": {
                                       "uuid": generate_dummy_uuid_str(7, datasets_count),
                                       "name": "dummy_dataset_from_conditions",
                                       "description": "A dummy dataset created from conditions",
                                       "contributor_sso_sid": 1234567890,
                                       "tags": ["division:training", "mission:name:test"],
                                       "props": {}
                                   },
                                   "conditions": {
                                       "included_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                                  for i in range(datasets_count) if i % 3 == 0],
                                       "excluded_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                                  for i in range(datasets_count) if i % 2 == 0],
                                   }
                               })
    assert response.status_code == 200, response.text
    print(f"create_dataset_from_conditions timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "dataset": {
            "sqn": datasets_count + 2,
            "created_at": "2020-03-01T00:00:00.000000+00:00",
            "updated_at": "2020-03-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": datasets_count + 2,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7, datasets_count + 1),
            "name": "another_dummy_dataset_from_conditions",
            "description": "Another dummy dataset created from conditions",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:test"],
            "props": {},
        },
        "layouts": sorted(
            [{
                "layout": {
                    "sqn": i + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(1, i),
                    "name": f"multi_camera/layout_{i}",
                    "description": f"Multi camera layout {i}",
                    "child_layout_uuids": [],
                    "layout_spec": {
                        "type": "object",
                        "properties": {
                            "camera_type": {"type": "string"},
                            "resolution": {"type": "string"},
                        },
                    },
                    "props": {"camera_count": i + 1},
                },
                "samples_count": sum(1 for x in range(samples_count)
                                     if x % 3 == 0 and x % 2 != 0 and x % layouts_count == i)
                                 * sum(1 for x in range(datasets_count) if x % 3 == 0 and x % 2 != 0),
            } for i in set(x % layouts_count for x in range(samples_count) if x % 3 == 0 and x % 2 != 0)],
            key=lambda x: x["samples_count"],
            reverse=True,
        ),
        "samples_count": sum(1 for j in range(datasets_count) if j % 3 == 0 and j % 2 != 0) *
                         sum(1 for i in range(samples_count) if i % 3 == 0 and i % 2 != 0),
        "registration": None,
        "promotion": None,
    }

    timer_start = timeit.default_timer()
    with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_dataset_from_conditions/",
                               json={
                                   "dataset": {
                                       "uuid": generate_dummy_uuid_str(7, datasets_count + 1),
                                       "name": "another_dummy_dataset_from_conditions",
                                       "description": "Another dummy dataset created from conditions",
                                       "contributor_sso_sid": 1234567890,
                                       "tags": ["division:training", "mission:name:test"],
                                       "props": {}
                                   },
                                   "conditions": {
                                       "included_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                                  for i in range(datasets_count) if i % 3 == 0],
                                       "excluded_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                                  for i in range(datasets_count) if i % 2 == 0],
                                       "required_tags": ["tod:daytime"],
                                       "unwanted_tags": ["weather:sunny"],
                                   }
                               })
    assert response.status_code == 200, response.text
    print(f"create_dataset_from_conditions timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_stat_datasets_classifiers(fixture_make_session, fixture_current_dt_clock):
    datasets_count = 10
    samples_count = 100

    for j in range(datasets_count):
        request_data = {
            "dataset": {
                "uuid": generate_dummy_uuid_str(7, j),
                "name": f"dummy_dataset_{j}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890,
                "tags": ["division:training", "mission:name:nation_cover_2020"],
                "props": {},
            },
            "samples": [{
                "uuid": generate_dummy_uuid_str(8, j, i),
                "path": f"pulse/demeter/datasets/dataset_{j}/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1),
                "bag_name": f"20200101T000000-dummy_vehicle_{j}-0.bag",
                "vehicle_name": f"dummy_vehicle_{j}",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": [
                    "tod:daytime" if i % 3 == 0 else "tod:nighttime",
                    "weather:sunny" if i % 2 == 0 else "weather:rainy",
                    "road:traffic:leading",
                    "road:layout:straight",
                ],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            } for i in range(samples_count)],
        }

        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{public_router.prefix}/create_dataset_with_samples/",
                                   json=request_data)
        assert response.status_code == 200, response.text

        request_data = [{
            "uuid": generate_dummy_uuid_str(9, j, i),
            "sample_uuid": generate_dummy_uuid_str(8, j, i),
            "taxonomy_uuid": generate_dummy_uuid_str(2),
            "classifier_data": {
                "classifiers": [
                    {"name": ("data_fidelity:camera_issue:glare"
                              if i % 2 == 0 else "data_fidelity:camera_issue:lens_smear")},
                    {"name": ("data_fidelity:radar_issue:clutter"
                              if i % 3 == 0 else "data_fidelity:radar_issue:interference")},
                    {"name": ("environment:tod:daytime"
                              if i % 4 == 0 else "environment:tod:nighttime")},
                    {"name": ("environment:weather:clear"
                              if i % 5 == 0 else "environment:weather:rainy")},
                    {"name": ("roadway:classification:highway"
                              if i % 6 == 0 else "roadway:classification:residential")},
                    {"name": ("roadway:infrastructure:bridge"
                              if i % 7 == 0 else "roadway:infrastructure:tunnel")},
                    {"name": ("roadway:junction:merge"
                              if i % 8 == 0 else "roadway:junction:split")},
                    {"name": ("traffic:accident:debris_on_road"
                              if i % 9 == 0 else "traffic:accident:police_stop")},
                    {"name": ("traffic:density:dense"
                              if i % 10 == 0 else "traffic:density:sparse")},
                ],
            },
        } for i in range(samples_count)]

        response = client.post(f"{internal_router.prefix}/classifiers/",
                               json=request_data,
                               params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    response_expect = {
        "stats": [{
            "dataset": {
                "sqn": j + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": j + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(7, j),
                "name": f"dummy_dataset_{j}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890,
                "tags": ["division:training", "mission:name:nation_cover_2020"],
                "props": {},
            },
            "items": [
                {"classifier": "data_fidelity:camera_issue:glare",
                 "count": math.ceil(samples_count / 2)},
                {"classifier": "data_fidelity:camera_issue:lens_smear",
                 "count": samples_count - math.ceil(samples_count / 2)},
                {"classifier": "data_fidelity:radar_issue:clutter",
                 "count": math.ceil(samples_count / 3)},
                {"classifier": "data_fidelity:radar_issue:interference",
                 "count": samples_count - math.ceil(samples_count / 3)},
                {"classifier": "environment:tod:daytime",
                 "count": math.ceil(samples_count / 4)},
                {"classifier": "environment:tod:nighttime",
                 "count": samples_count - math.ceil(samples_count / 4)},
                {"classifier": "environment:weather:clear",
                 "count": math.ceil(samples_count / 5)},
                {"classifier": "environment:weather:rainy",
                 "count": samples_count - math.ceil(samples_count / 5)},
                {"classifier": "roadway:classification:highway",
                 "count": math.ceil(samples_count / 6)},
                {"classifier": "roadway:classification:residential",
                 "count": samples_count - math.ceil(samples_count / 6)},
                {"classifier": "roadway:infrastructure:bridge",
                 "count": math.ceil(samples_count / 7)},
                {"classifier": "roadway:infrastructure:tunnel",
                 "count": samples_count - math.ceil(samples_count / 7)},
                {"classifier": "roadway:junction:merge",
                 "count": math.ceil(samples_count / 8)},
                {"classifier": "roadway:junction:split",
                 "count": samples_count - math.ceil(samples_count / 8)},
                {"classifier": "traffic:accident:debris_on_road",
                 "count": math.ceil(samples_count / 9)},
                {"classifier": "traffic:accident:police_stop",
                 "count": samples_count - math.ceil(samples_count / 9)},
                {"classifier": "traffic:density:dense",
                 "count": math.ceil(samples_count / 10)},
                {"classifier": "traffic:density:sparse",
                 "count": samples_count - math.ceil(samples_count / 10)},
            ]
        } for j in range(datasets_count)]
    }

    timer_start = timeit.default_timer()
    response = client.get(f"{public_router.prefix}/stat_datasets_classifiers/",
                          params={"dataset_uuids": [generate_dummy_uuid_str(7, i) for i in range(datasets_count)]})
    assert response.status_code == 200, response.text
    print(f"stat_datasets_classifiers timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)
