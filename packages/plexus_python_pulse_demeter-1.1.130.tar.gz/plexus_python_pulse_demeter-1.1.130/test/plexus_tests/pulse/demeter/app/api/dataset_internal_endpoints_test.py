import pytest_postgresql.factories
from fastapi.testclient import TestClient
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare, generate_dummy_uuid_str
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker

from plexus.pulse.demeter.app.api.dataset_internal_endpoints import router as internal_router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models.registry import BaseModel

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_make_session = patched_postgresql_session_maker("fixture_postgresql_test",
                                                        BaseModel,
                                                        app,
                                                        make_session,
                                                        expire_on_commit=False)

client = TestClient(app)


def test_create_layout(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(1),
        "name": "test_layout/test_layout",
        "description": "Test layout",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_type": "front_center", "resolution": "1920x1080"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(1),
        "name": "test_layout/test_layout",
        "description": "Test layout",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_type": "front_center", "resolution": "1920x1080"},
    }

    response = client.post(f"{internal_router.prefix}/layout",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/layout/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_layouts(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"test_layout/test_layout_{i}",
        "description": f"Test layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"test_layout/test_layout_{i}",
        "description": f"Test layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/layouts/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_layout(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(1),
        "name": "test_layout/test_layout",
        "description": "Test layout",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_type": "front_center", "resolution": "1920x1080"},
    }

    client.post(f"{internal_router.prefix}/layout/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(1),
        "name": "test_layout/test_layout",
        "description": "Updated test layout",
        "child_layout_uuids": [generate_dummy_uuid_str(1, 1), generate_dummy_uuid_str(1, 2)],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
                "camera_fov": {"type": "integer"},
            },
        },
        "props": {"camera_type": "front_long_range", "resolution": "800x600"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(1),
        "name": "test_layout/test_layout",
        "description": "Updated test layout",
        "child_layout_uuids": [generate_dummy_uuid_str(1, 1), generate_dummy_uuid_str(1, 2)],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
                "camera_fov": {"type": "integer"},
            },
        },
        "props": {"camera_type": "front_long_range", "resolution": "800x600"},
    }

    response = client.put(f"{internal_router.prefix}/layout/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_layout(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(1),
        "name": "test_layout/test_layout",
        "description": "Test layout",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_type": "front_center", "resolution": "1920x1080"},
    }

    client.post(f"{internal_router.prefix}/layout/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(1),
        "name": "test_layout/test_layout",
        "description": "Test layout",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_type": "front_center", "resolution": "1920x1080"},
    }

    response = client.delete(f"{internal_router.prefix}/layout/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_taxonomy(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(2),
        "name": "test_taxonomy/test_taxonomy",
        "version": "1.0.0",
        "description": "Test taxonomy",
        "taxonomy_hierarchy": {
            "categories": [
                {"id": "vehicle", "children": [{"id": "car"}, {"id": "truck"}]},
                {"id": "person", "children": []},
            ],
        },
        "props": {"source": "internal"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(2),
        "name": "test_taxonomy/test_taxonomy",
        "version": "1.0.0",
        "description": "Test taxonomy",
        "taxonomy_hierarchy": {
            "categories": [
                {"id": "vehicle", "children": [{"id": "car"}, {"id": "truck"}]},
                {"id": "person", "children": []},
            ],
        },
        "props": {"source": "internal"},
    }

    response = client.post(f"{internal_router.prefix}/taxonomy/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/taxonomy/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_taxonomies(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(2, i),
        "name": f"test_taxonomy/test_taxonomy_{i}",
        "version": f"1.0.{i}",
        "description": f"Test taxonomy {i}",
        "taxonomy_hierarchy": {"categories": [{"id": "a", "children": []}]},
        "props": {"index": i},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(2, i),
        "name": f"test_taxonomy/test_taxonomy_{i}",
        "version": f"1.0.{i}",
        "description": f"Test taxonomy {i}",
        "taxonomy_hierarchy": {"categories": [{"id": "a", "children": []}]},
        "props": {"index": i},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/taxonomies/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/taxonomies/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_taxonomy(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(2),
        "name": "test_taxonomy/test_taxonomy",
        "version": "1.0.0",
        "description": "Test taxonomy",
        "taxonomy_hierarchy": {"categories": [{"id": "vehicle", "children": []}]},
        "props": {"source": "internal"},
    }

    client.post(f"{internal_router.prefix}/taxonomy/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(2),
        "name": "test_taxonomy/test_taxonomy",
        "version": "2.0.0",
        "description": "Updated test taxonomy",
        "taxonomy_hierarchy": {"categories": [{"id": "vehicle", "children": [{"id": "car"}]}]},
        "props": {"source": "internal", "notes": "v2"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(2),
        "name": "test_taxonomy/test_taxonomy",
        "version": "2.0.0",
        "description": "Updated test taxonomy",
        "taxonomy_hierarchy": {"categories": [{"id": "vehicle", "children": [{"id": "car"}]}]},
        "props": {"source": "internal", "notes": "v2"},
    }

    response = client.put(f"{internal_router.prefix}/taxonomy/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_taxonomy(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(2),
        "name": "test_taxonomy/test_taxonomy",
        "version": "1.0.0",
        "description": "Test taxonomy",
        "taxonomy_hierarchy": {"categories": [{"id": "vehicle", "children": []}]},
        "props": {"source": "internal"},
    }

    client.post(f"{internal_router.prefix}/taxonomy/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(2),
        "name": "test_taxonomy/test_taxonomy",
        "version": "1.0.0",
        "description": "Test taxonomy",
        "taxonomy_hierarchy": {"categories": [{"id": "vehicle", "children": []}]},
        "props": {"source": "internal"},
    }

    response = client.delete(f"{internal_router.prefix}/taxonomy/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_guideline(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "name": "test_guideline/test_guideline",
        "version": "1.0.0",
        "description": "Test guideline",
        "supported_layout_uuids": [generate_dummy_uuid_str(1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3),
        "name": "test_guideline/test_guideline",
        "version": "1.0.0",
        "description": "Test guideline",
        "supported_layout_uuids": [generate_dummy_uuid_str(1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    }

    response = client.post(f"{internal_router.prefix}/guideline/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/guideline/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_guidelines(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(3, i),
        "name": f"test_guideline/test_guideline_{i}",
        "version": f"1.0.{i}",
        "description": f"Test guideline {i}",
        "supported_layout_uuids": [generate_dummy_uuid_str(1, i), generate_dummy_uuid_str(1, i + 1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3, i),
        "name": f"test_guideline/test_guideline_{i}",
        "version": f"1.0.{i}",
        "description": f"Test guideline {i}",
        "supported_layout_uuids": [generate_dummy_uuid_str(1, i), generate_dummy_uuid_str(1, i + 1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/guidelines/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/guidelines/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_guideline(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "name": "test_guideline/test_guideline",
        "version": "1.0.0",
        "description": "Test guideline",
        "supported_layout_uuids": [generate_dummy_uuid_str(1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    }

    client.post(f"{internal_router.prefix}/guideline/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "name": "test_guideline/test_guideline",
        "version": "2.0.0",
        "description": "Updated test guideline",
        "supported_layout_uuids": [generate_dummy_uuid_str(1, 1), generate_dummy_uuid_str(1, 2)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string"},
                "attributes": {"type": "object"},
            },
        },
        "props": {"annotation_tool": "demeter_advanced"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(3),
        "name": "test_guideline/test_guideline",
        "version": "2.0.0",
        "description": "Updated test guideline",
        "supported_layout_uuids": [generate_dummy_uuid_str(1, 1), generate_dummy_uuid_str(1, 2)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string"},
                "attributes": {"type": "object"},
            },
        },
        "props": {"annotation_tool": "demeter_advanced"},
    }

    response = client.put(f"{internal_router.prefix}/guideline/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_guideline(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "name": "test_guideline/test_guideline",
        "version": "1.0.0",
        "description": "Test guideline",
        "supported_layout_uuids": [generate_dummy_uuid_str(1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    }

    client.post(f"{internal_router.prefix}/guideline/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3),
        "name": "test_guideline/test_guideline",
        "version": "1.0.0",
        "description": "Test guideline",
        "supported_layout_uuids": [generate_dummy_uuid_str(1)],
        "annotation_schema": {
            "type": "object",
            "required": ["id", "type", "category", "cuboid"],
            "properties": {
                "id": {"type": "string"},
                "type": {"type": "string", "enum": ["3d_bounding_box"]},
                "category": {"type": "string"},
                "cuboid": {
                    "type": "object",
                    "required": ["dimensions", "center", "rotation"],
                    "properties": {
                        "dimensions": {"type": "object"},
                        "center": {"type": "object"},
                        "rotation": {"type": "object"},
                    },
                },
            },
        },
        "props": {"annotation_tool": "demeter"},
    }

    response = client.delete(f"{internal_router.prefix}/guideline/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_architecture(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(4),
        "name": "test_architecture/test_architecture",
        "version": "1.0.0",
        "description": "Test architecture",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, 1), generate_dummy_uuid_str(3, 2)],
        "props": {
            "framework": "pytorch",
            "backbone": "resnet50",
            "input_size": [224, 224],
            "num_classes": 100,
        },
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(4),
        "name": "test_architecture/test_architecture",
        "version": "1.0.0",
        "description": "Test architecture",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, 1), generate_dummy_uuid_str(3, 2)],
        "props": {
            "framework": "pytorch",
            "backbone": "resnet50",
            "input_size": [224, 224],
            "num_classes": 100,
        },
    }

    response = client.post(f"{internal_router.prefix}/architecture/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/architecture/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_architectures(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"test_architecture/test_architecture{i}",
        "version": f"1.0.{i}",
        "description": f"Test architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"test_architecture/test_architecture{i}",
        "version": f"1.0.{i}",
        "description": f"Test architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/architectures/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/architectures/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_architecture(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(4),
        "name": "test_architecture/test_architecture",
        "version": "1.0.0",
        "description": "Test architecture",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3)],
        "props": {"framework": "pytorch"},
    }

    client.post(f"{internal_router.prefix}/architecture/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(4),
        "name": "test_architecture/test_architecture",
        "version": "2.0.0",
        "description": "Updated test architecture",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, 1), generate_dummy_uuid_str(3, 2)],
        "props": {
            "framework": "pytorch",
            "backbone": "resnet101",
            "num_layers": 12,
            "attention_heads": 8,
        },
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(4),
        "name": "test_architecture/test_architecture",
        "version": "2.0.0",
        "description": "Updated test architecture",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, 1), generate_dummy_uuid_str(3, 2)],
        "props": {
            "framework": "pytorch",
            "backbone": "resnet101",
            "num_layers": 12,
            "attention_heads": 8,
        },
    }

    response = client.put(f"{internal_router.prefix}/architecture/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_architecture(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(4),
        "name": "test_architecture/test_architecture",
        "version": "1.0.0",
        "description": "Test architecture",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3)],
        "props": {"framework": "pytorch"},
    }

    client.post(f"{internal_router.prefix}/architecture/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(4),
        "name": "test_architecture/test_architecture",
        "version": "1.0.0",
        "description": "Test architecture",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3)],
        "props": {"framework": "pytorch"},
    }

    response = client.delete(f"{internal_router.prefix}/architecture/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_benchmark(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(5),
        "name": "test_benchmark/test_benchmark",
        "version": "1.0.0",
        "description": "Test benchmark",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, 1), generate_dummy_uuid_str(4, 2)],
        "benchmark_schema": {
            "type": "object",
            "required": ["accuracy", "precision", "recall", "f1_score"],
            "properties": {
                "accuracy": {"type": "number", "minimum": 0, "maximum": 1},
                "precision": {"type": "number", "minimum": 0, "maximum": 1},
                "recall": {"type": "number", "minimum": 0, "maximum": 1},
                "f1_score": {"type": "number", "minimum": 0, "maximum": 1},
            },
        },
        "props": {
            "dataset": "coco",
            "metric_type": "mAP",
        },
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(5),
        "name": "test_benchmark/test_benchmark",
        "version": "1.0.0",
        "description": "Test benchmark",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, 1), generate_dummy_uuid_str(4, 2)],
        "benchmark_schema": {
            "type": "object",
            "required": ["accuracy", "precision", "recall", "f1_score"],
            "properties": {
                "accuracy": {"type": "number", "minimum": 0, "maximum": 1},
                "precision": {"type": "number", "minimum": 0, "maximum": 1},
                "recall": {"type": "number", "minimum": 0, "maximum": 1},
                "f1_score": {"type": "number", "minimum": 0, "maximum": 1},
            },
        },
        "props": {
            "dataset": "coco",
            "metric_type": "mAP",
        },
    }

    response = client.post(f"{internal_router.prefix}/benchmark/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/benchmark/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_benchmarks(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(5, i),
        "name": f"test_benchmark/test_benchmark{i}",
        "version": f"1.0.{i}",
        "description": f"Test benchmark {i}",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, i)],
        "benchmark_schema": {
            "type": "object",
            "properties": {
                "metric": {"type": "number"},
                "test_id": {"type": "integer", "const": i},
            },
        },
        "props": {"suite_number": i},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(5, i),
        "name": f"test_benchmark/test_benchmark{i}",
        "version": f"1.0.{i}",
        "description": f"Test benchmark {i}",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, i)],
        "benchmark_schema": {
            "type": "object",
            "properties": {
                "metric": {"type": "number"},
                "test_id": {"type": "integer", "const": i},
            },
        },
        "props": {"suite_number": i},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/benchmarks/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/benchmarks/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_benchmark(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(5),
        "name": "test_benchmark/test_benchmark",
        "version": "1.0.0",
        "description": "Test benchmark",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4)],
        "benchmark_schema": {
            "type": "object",
            "properties": {"accuracy": {"type": "number"}},
        },
        "props": {"dataset": "coco"},
    }

    client.post(f"{internal_router.prefix}/benchmark/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(5),
        "name": "test_benchmark/test_benchmark",
        "version": "2.0.0",
        "description": "Updated test benchmark",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, 1), generate_dummy_uuid_str(4, 2)],
        "benchmark_schema": {
            "type": "object",
            "required": ["accuracy", "precision", "recall", "f1_score", "mAP"],
            "properties": {
                "accuracy": {"type": "number", "minimum": 0, "maximum": 1},
                "precision": {"type": "number", "minimum": 0, "maximum": 1},
                "recall": {"type": "number", "minimum": 0, "maximum": 1},
                "f1_score": {"type": "number", "minimum": 0, "maximum": 1},
                "mAP": {"type": "number", "minimum": 0, "maximum": 1},
            },
        },
        "props": {
            "dataset": "coco",
            "metric_type": "mAP@0.5:0.95",
            "iou_threshold": 0.5,
        },
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(5),
        "name": "test_benchmark/test_benchmark",
        "version": "2.0.0",
        "description": "Updated test benchmark",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, 1), generate_dummy_uuid_str(4, 2)],
        "benchmark_schema": {
            "type": "object",
            "required": ["accuracy", "precision", "recall", "f1_score", "mAP"],
            "properties": {
                "accuracy": {"type": "number", "minimum": 0, "maximum": 1},
                "precision": {"type": "number", "minimum": 0, "maximum": 1},
                "recall": {"type": "number", "minimum": 0, "maximum": 1},
                "f1_score": {"type": "number", "minimum": 0, "maximum": 1},
                "mAP": {"type": "number", "minimum": 0, "maximum": 1},
            },
        },
        "props": {
            "dataset": "coco",
            "metric_type": "mAP@0.5:0.95",
            "iou_threshold": 0.5,
        },
    }

    response = client.put(f"{internal_router.prefix}/benchmark/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_benchmark(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(5),
        "name": "test_benchmark/test_benchmark",
        "version": "1.0.0",
        "description": "Test benchmark",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4)],
        "benchmark_schema": {
            "type": "object",
            "properties": {"accuracy": {"type": "number"}},
        },
        "props": {"dataset": "coco"},
    }

    client.post(f"{internal_router.prefix}/benchmark/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(5),
        "name": "test_benchmark/test_benchmark",
        "version": "1.0.0",
        "description": "Test benchmark",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4)],
        "benchmark_schema": {
            "type": "object",
            "properties": {"accuracy": {"type": "number"}},
        },
        "props": {"dataset": "coco"},
    }

    response = client.delete(f"{internal_router.prefix}/benchmark/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_registration(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(6),
        "resource_path": "datasets/demo_dataset",
        "dataset_uuid": generate_dummy_uuid_str(7),
        "flags": 0,
        "props": {},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(6),
        "resource_path": "datasets/demo_dataset",
        "dataset_uuid": generate_dummy_uuid_str(7),
        "flags": 0,
        "props": {},
    }

    response = client.post(f"{internal_router.prefix}/registration/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/registration/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_registrations(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(6, i),
        "resource_path": f"datasets/demo_dataset_{i}",
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "flags": i,
        "props": {},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(6, i),
        "resource_path": f"datasets/demo_dataset_{i}",
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "flags": i,
        "props": {},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/registrations/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/registrations/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_registration(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(6),
        "resource_path": "datasets/demo_dataset",
        "dataset_uuid": generate_dummy_uuid_str(7),
        "flags": 0,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/registration/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(6),
        "resource_path": "datasets/updated_dataset",
        "dataset_uuid": generate_dummy_uuid_str(7, 1),
        "flags": 0x010000,
        "props": {},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(6),
        "resource_path": "datasets/updated_dataset",
        "dataset_uuid": generate_dummy_uuid_str(7, 1),
        "flags": 0x010000,
        "props": {},
    }

    response = client.put(f"{internal_router.prefix}/registration/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_registration(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(6),
        "resource_path": "datasets/demo_dataset",
        "dataset_uuid": generate_dummy_uuid_str(7),
        "flags": 0,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/registration/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(6),
        "resource_path": "datasets/demo_dataset",
        "dataset_uuid": generate_dummy_uuid_str(7),
        "flags": 0,
        "props": {},
    }

    response = client.delete(f"{internal_router.prefix}/registration/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_dataset_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    response = client.post(f"{internal_router.prefix}/dataset_promotion/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/dataset_promotion/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_dataset_promotions(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(15, i),
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(15, i),
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/dataset_promotions/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/dataset_promotions/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_dataset_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/dataset_promotion/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 9876543210,
        "flags": 0x010000,
        "props": {},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 9876543210,
        "flags": 0x010000,
        "props": {},
    }

    response = client.put(f"{internal_router.prefix}/dataset_promotion/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_dataset_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/dataset_promotion/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    response = client.delete(f"{internal_router.prefix}/dataset_promotion/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_dataset(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(7),
        "name": "dummy_dataset",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890,
        "tags": ["division:training", "mission:name:nation_cover_2020"],
        "props": {},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(7),
        "name": "dummy_dataset",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890,
        "tags": ["division:training", "mission:name:nation_cover_2020"],
        "props": {},
    }

    response = client.post(f"{internal_router.prefix}/dataset/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/dataset/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_datasets(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_dataset_{i}",
        "description": f"A dummy dataset {i}",
        "contributor_sso_sid": 1234567890,
        "tags": ["division:training", "mission:name:nation_cover_2020"],
        "props": {},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_dataset_{i}",
        "description": f"A dummy dataset {i}",
        "contributor_sso_sid": 1234567890,
        "tags": ["division:training", "mission:name:nation_cover_2020"],
        "props": {},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/datasets/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/datasets/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_dataset(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(7),
        "name": "dummy_dataset",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890,
        "tags": ["division:training", "mission:name:nation_cover_2020"],
        "props": {},
    }

    client.post(f"{internal_router.prefix}/dataset/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(7),
        "name": "another_dummy_dataset",
        "description": "Another dummy dataset",
        "contributor_sso_sid": 9876543210,
        "tags": ["division:training", "mission:name:nation_cover_2020", "dummy:dummy"],
        "props": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(7),
        "name": "another_dummy_dataset",
        "description": "Another dummy dataset",
        "contributor_sso_sid": 9876543210,
        "tags": ["division:training", "mission:name:nation_cover_2020", "dummy:dummy"],
        "props": {"dummy": "dummy"},
    }

    response = client.put(f"{internal_router.prefix}/dataset/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_dataset(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(7),
        "name": "dummy_dataset",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890,
        "tags": ["division:training", "mission:name:nation_cover_2020"],
        "props": {},
    }

    client.post(f"{internal_router.prefix}/dataset/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(7),
        "name": "dummy_dataset",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890,
        "tags": ["division:training", "mission:name:nation_cover_2020"],
        "props": {},
    }

    response = client.delete(f"{internal_router.prefix}/dataset/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_sample(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(8),
        "path": "pulse/demeter/datasets/dataset/samples/image.jpg",
        "layout_uuid": generate_dummy_uuid_str(1),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(8),
        "path": "pulse/demeter/datasets/dataset/samples/image.jpg",
        "layout_uuid": generate_dummy_uuid_str(1),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    }

    response = client.post(f"{internal_router.prefix}/sample/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/sample/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_samples(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(8, i),
        "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
        "layout_uuid": generate_dummy_uuid_str(1, i),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(8, i),
        "path": f"pulse/demeter/datasets/dataset/samples/image_{i}.jpg",
        "layout_uuid": generate_dummy_uuid_str(1, i),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/samples/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/samples/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_sample(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(8),
        "path": "pulse/demeter/datasets/dataset/samples/image.jpg",
        "layout_uuid": generate_dummy_uuid_str(1),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    }

    client.post(f"{internal_router.prefix}/sample/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(8),
        "path": "pulse/demeter/datasets/another_dataset/samples/image.jpg",
        "layout_uuid": generate_dummy_uuid_str(1, 1),
        "bag_name": "20200101T000000-another_dummy_vehicle-0.bag",
        "vehicle_name": "another_dummy_vehicle",
        "begin_frame_dt": "2020-01-01T23:59:59.999999+00:00",
        "end_frame_dt": "2020-01-01T23:59:59.999999+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:rainy", "road:traffic:shouldering", "road:layout:ramp"],
        "props": {"camera": "rear_center", "resolution": "800x600"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(8),
        "path": "pulse/demeter/datasets/another_dataset/samples/image.jpg",
        "layout_uuid": generate_dummy_uuid_str(1, 1),
        "bag_name": "20200101T000000-another_dummy_vehicle-0.bag",
        "vehicle_name": "another_dummy_vehicle",
        "begin_frame_dt": "2020-01-01T23:59:59.999999+00:00",
        "end_frame_dt": "2020-01-01T23:59:59.999999+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:rainy", "road:traffic:shouldering", "road:layout:ramp"],
        "props": {"camera": "rear_center", "resolution": "800x600"},
    }

    response = client.put(f"{internal_router.prefix}/sample/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_sample(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(8),
        "path": "pulse/demeter/datasets/dataset/samples/image.jpg",
        "layout_uuid": generate_dummy_uuid_str(1),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    }

    client.post(f"{internal_router.prefix}/sample/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(8),
        "path": "pulse/demeter/datasets/dataset/samples/image.jpg",
        "layout_uuid": generate_dummy_uuid_str(1),
        "bag_name": "20200101T000000-dummy_vehicle-0.bag",
        "vehicle_name": "dummy_vehicle",
        "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
        "child_sample_uuids": None,
        "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
        "props": {"camera": "front_center", "resolution": "1920x1080"},
    }

    response = client.delete(f"{internal_router.prefix}/sample/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_classifier(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(9),
        "sample_uuid": generate_dummy_uuid_str(8),
        "taxonomy_uuid": generate_dummy_uuid_str(2),
        "classifier_data": {
            "classifier_type": "object_detection",
            "model": "yolov8",
            "confidence_threshold": 0.5,
            "detections": [
                {
                    "class": "vehicle",
                    "confidence": 0.95,
                    "bbox": [100, 100, 200, 200],
                },
                {
                    "class": "pedestrian",
                    "confidence": 0.87,
                    "bbox": [300, 150, 350, 250],
                },
            ],
        },
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(9),
        "sample_uuid": generate_dummy_uuid_str(8),
        "taxonomy_uuid": generate_dummy_uuid_str(2),
        "classifier_data": {
            "classifier_type": "object_detection",
            "model": "yolov8",
            "confidence_threshold": 0.5,
            "detections": [
                {
                    "class": "vehicle",
                    "confidence": 0.95,
                    "bbox": [100, 100, 200, 200],
                },
                {
                    "class": "pedestrian",
                    "confidence": 0.87,
                    "bbox": [300, 150, 350, 250],
                },
            ],
        },
    }

    response = client.post(f"{internal_router.prefix}/classifier/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/classifier/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_classifiers(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(9, i),
        "sample_uuid": generate_dummy_uuid_str(8, i),
        "taxonomy_uuid": generate_dummy_uuid_str(2, i),
        "classifier_data": {
            "classifier_type": "object_detection",
            "model": "yolov8",
            "confidence_threshold": 0.5,
            "detections": [
                {
                    "class": "vehicle",
                    "confidence": 0.95,
                    "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                },
            ],
        },
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(9, i),
        "sample_uuid": generate_dummy_uuid_str(8, i),
        "taxonomy_uuid": generate_dummy_uuid_str(2, i),
        "classifier_data": {
            "classifier_type": "object_detection",
            "model": "yolov8",
            "confidence_threshold": 0.5,
            "detections": [
                {
                    "class": "vehicle",
                    "confidence": 0.95,
                    "bbox": [100 + i, 100 + i, 200 + i, 200 + i],
                },
            ],
        },
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/classifiers/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/classifiers/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_classifier(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(9),
        "sample_uuid": generate_dummy_uuid_str(8),
        "taxonomy_uuid": generate_dummy_uuid_str(2),
        "classifier_data": {
            "classifier_type": "object_detection",
            "model": "yolov8",
            "confidence_threshold": 0.5,
            "detections": [],
        },
    }

    client.post(f"{internal_router.prefix}/classifier/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(9),
        "sample_uuid": generate_dummy_uuid_str(8, 1),
        "taxonomy_uuid": generate_dummy_uuid_str(2, 1),
        "classifier_data": {
            "classifier_type": "semantic_segmentation",
            "model": "deeplabv3",
            "confidence_threshold": 0.7,
            "segmentation_map": "path/to/segmentation.png",
            "classes": ["road", "sidewalk", "vehicle", "pedestrian"],
        },
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(9),
        "sample_uuid": generate_dummy_uuid_str(8, 1),
        "taxonomy_uuid": generate_dummy_uuid_str(2, 1),
        "classifier_data": {
            "classifier_type": "semantic_segmentation",
            "model": "deeplabv3",
            "confidence_threshold": 0.7,
            "segmentation_map": "path/to/segmentation.png",
            "classes": ["road", "sidewalk", "vehicle", "pedestrian"],
        },
    }

    response = client.put(f"{internal_router.prefix}/classifier/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_classifier(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(9),
        "sample_uuid": generate_dummy_uuid_str(8),
        "taxonomy_uuid": generate_dummy_uuid_str(2),
        "classifier_data": {
            "classifier_type": "object_detection",
            "model": "yolov8",
            "detections": [],
        },
    }

    client.post(f"{internal_router.prefix}/classifier/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(9),
        "sample_uuid": generate_dummy_uuid_str(8),
        "taxonomy_uuid": generate_dummy_uuid_str(2),
        "classifier_data": {
            "classifier_type": "object_detection",
            "model": "yolov8",
            "detections": [],
        },
    }

    response = client.delete(f"{internal_router.prefix}/classifier/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_annotation(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(10),
        "sample_uuid": generate_dummy_uuid_str(8),
        "guideline_uuid": generate_dummy_uuid_str(3),
        "path": "pulse/demeter/annotations/annotation/archive.zip#sample_1.json",
        "annotation_data": {
            "annotator": "john.doe",
            "annotation_type": "3d_bounding_box",
            "objects": [
                {
                    "id": "obj_001",
                    "type": "3d_bounding_box",
                    "category": "vehicle",
                    "cuboid": {
                        "dimensions": {"length": 4.5, "width": 1.8, "height": 1.5},
                        "center": {"x": 10.0, "y": 5.0, "z": 0.75},
                        "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                    },
                },
                {
                    "id": "obj_002",
                    "type": "3d_bounding_box",
                    "category": "pedestrian",
                    "cuboid": {
                        "dimensions": {"length": 0.5, "width": 0.5, "height": 1.7},
                        "center": {"x": 15.0, "y": 3.0, "z": 0.85},
                        "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                    },
                },
            ],
            "metadata": {
                "annotation_time_seconds": 120,
                "quality_score": 0.95,
            },
        },
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(10),
        "sample_uuid": generate_dummy_uuid_str(8),
        "guideline_uuid": generate_dummy_uuid_str(3),
        "path": "pulse/demeter/annotations/annotation/archive.zip#sample_1.json",
        "annotation_data": {
            "annotator": "john.doe",
            "annotation_type": "3d_bounding_box",
            "objects": [
                {
                    "id": "obj_001",
                    "type": "3d_bounding_box",
                    "category": "vehicle",
                    "cuboid": {
                        "dimensions": {"length": 4.5, "width": 1.8, "height": 1.5},
                        "center": {"x": 10.0, "y": 5.0, "z": 0.75},
                        "rotation": {"yaw": 0.0, "pitch": 0.0, "roll": 0.0},
                    },
                },
                {
                    "id": "obj_002",
                    "type": "3d_bounding_box",
                    "category": "pedestrian",
                    "cuboid": {
                        "dimensions": {"length": 0.5, "width": 0.5, "height": 1.7},
                        "center": {"x": 15.0, "y": 3.0, "z": 0.85},
                        "rotation": {"yaw": 90.0, "pitch": 0.0, "roll": 0.0},
                    },
                },
            ],
            "metadata": {
                "annotation_time_seconds": 120,
                "quality_score": 0.95,
            },
        },
    }

    response = client.post(f"{internal_router.prefix}/annotation/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/annotation/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_annotations(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(10, i),
        "sample_uuid": generate_dummy_uuid_str(8, i),
        "guideline_uuid": generate_dummy_uuid_str(3, i),
        "path": f"pulse/demeter/annotations/annotation/archive.zip#sample_{i}.json",
        "annotation_data": {
            "annotator": "john.doe",
            "annotation_type": "2d_bounding_box",
            "objects": [
                {
                    "id": f"obj_{i:03d}",
                    "type": "2d_bounding_box",
                    "category": "vehicle",
                    "bbox": {
                        "x": 100 + i,
                        "y": 100 + i,
                        "width": 200,
                        "height": 150,
                    },
                },
            ],
        },
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(10, i),
        "sample_uuid": generate_dummy_uuid_str(8, i),
        "guideline_uuid": generate_dummy_uuid_str(3, i),
        "path": f"pulse/demeter/annotations/annotation/archive.zip#sample_{i}.json",
        "annotation_data": {
            "annotator": "john.doe",
            "annotation_type": "2d_bounding_box",
            "objects": [
                {
                    "id": f"obj_{i:03d}",
                    "type": "2d_bounding_box",
                    "category": "vehicle",
                    "bbox": {
                        "x": 100 + i,
                        "y": 100 + i,
                        "width": 200,
                        "height": 150,
                    },
                },
            ],
        },
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/annotations/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/annotations/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_annotation(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(10),
        "sample_uuid": generate_dummy_uuid_str(8),
        "guideline_uuid": generate_dummy_uuid_str(3),
        "path": "pulse/demeter/annotations/annotation/archive.zip#sample_1.json",
        "annotation_data": {
            "annotator": "john.doe",
            "annotation_type": "2d_bounding_box",
            "objects": [],
        },
    }

    client.post(f"{internal_router.prefix}/annotation/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(10),
        "sample_uuid": generate_dummy_uuid_str(8, 1),
        "guideline_uuid": generate_dummy_uuid_str(3, 1),
        "path": "pulse/demeter/annotations/annotation/archive_v2.zip#sample_1.json",
        "annotation_data": {
            "annotator": "jane.smith",
            "annotation_type": "semantic_segmentation",
            "segmentation_mask": "path/to/mask.png",
            "classes": ["road", "vehicle", "pedestrian", "building"],
            "metadata": {
                "annotation_time_seconds": 180,
                "quality_score": 0.98,
                "review_status": "approved",
            },
        },
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(10),
        "sample_uuid": generate_dummy_uuid_str(8, 1),
        "guideline_uuid": generate_dummy_uuid_str(3, 1),
        "path": "pulse/demeter/annotations/annotation/archive_v2.zip#sample_1.json",
        "annotation_data": {
            "annotator": "jane.smith",
            "annotation_type": "semantic_segmentation",
            "segmentation_mask": "path/to/mask.png",
            "classes": ["road", "vehicle", "pedestrian", "building"],
            "metadata": {
                "annotation_time_seconds": 180,
                "quality_score": 0.98,
                "review_status": "approved",
            },
        },
    }

    response = client.put(f"{internal_router.prefix}/annotation/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_annotation(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(10),
        "sample_uuid": generate_dummy_uuid_str(8),
        "guideline_uuid": generate_dummy_uuid_str(3),
        "path": "pulse/demeter/annotations/annotation/archive.zip#sample_1.json",
        "annotation_data": {
            "annotator": "john.doe",
            "annotation_type": "2d_bounding_box",
            "objects": [],
        },
    }

    client.post(f"{internal_router.prefix}/annotation/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(10),
        "sample_uuid": generate_dummy_uuid_str(8),
        "guideline_uuid": generate_dummy_uuid_str(3),
        "path": "pulse/demeter/annotations/annotation/archive.zip#sample_1.json",
        "annotation_data": {
            "annotator": "john.doe",
            "annotation_type": "2d_bounding_box",
            "objects": [],
        },
    }

    response = client.delete(f"{internal_router.prefix}/annotation/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_experiment(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(11),
        "parent_uuid": None,
        "architecture_uuid": generate_dummy_uuid_str(4),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_model",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/models/experiment_1",
        "checkpoint_path": "epoch_1/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {
            "version": "1.0.0",
            "hyperparameters": {
                "learning_rate": 0.001,
                "batch_size": 32,
                "optimizer": "Adam",
            },
        },
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(11),
        "parent_uuid": None,
        "architecture_uuid": generate_dummy_uuid_str(4),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_model",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/models/experiment_1",
        "checkpoint_path": "epoch_1/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {
            "version": "1.0.0",
            "hyperparameters": {
                "learning_rate": 0.001,
                "batch_size": 32,
                "optimizer": "Adam",
            },
        },
    }

    response = client.post(f"{internal_router.prefix}/experiment/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/experiment/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_experiments(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(11, i),
        "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
        "architecture_uuid": generate_dummy_uuid_str(4, i),
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_model_{i}",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890,
        "path": f"pulse/demeter/models/experiment_{i}",
        "checkpoint_path": f"epoch_{i}/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {
            "version": f"1.0.{i}",
            "hyperparameters": {
                "learning_rate": 0.001,
                "batch_size": 32,
                "optimizer": "Adam",
            },
        },
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(11, i),
        "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
        "architecture_uuid": generate_dummy_uuid_str(4, i),
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_model_{i}",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890,
        "path": f"pulse/demeter/models/experiment_{i}",
        "checkpoint_path": f"epoch_{i}/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {
            "version": f"1.0.{i}",
            "hyperparameters": {
                "learning_rate": 0.001,
                "batch_size": 32,
                "optimizer": "Adam",
            },
        },
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/experiments/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/experiments/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_experiment(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(11),
        "parent_uuid": None,
        "architecture_uuid": generate_dummy_uuid_str(4),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_model",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/models/experiment_1",
        "checkpoint_path": "epoch_1/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {
            "version": "1.0.0",
            "hyperparameters": {
                "learning_rate": 0.001,
                "batch_size": 32,
                "optimizer": "Adam",
            },
        },
    }

    client.post(f"{internal_router.prefix}/experiment/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(11),
        "parent_uuid": generate_dummy_uuid_str(11, 1),
        "architecture_uuid": generate_dummy_uuid_str(4, 1),
        "dataset_uuid": generate_dummy_uuid_str(7, 1),
        "name": "updated_dummy_model",
        "description": "An updated dummy model",
        "contributor_sso_sid": 9876543210,
        "path": "pulse/demeter/models/experiment_2",
        "checkpoint_path": "epoch_2/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet101", "dummy:dummy"],
        "props": {
            "version": "2.0.0",
            "hyperparameters": {
                "learning_rate": 0.0001,
                "batch_size": 64,
                "optimizer": "AdamW",
            },
            "dummy": "dummy",
        },
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(11),
        "parent_uuid": generate_dummy_uuid_str(11, 1),
        "architecture_uuid": generate_dummy_uuid_str(4, 1),
        "dataset_uuid": generate_dummy_uuid_str(7, 1),
        "name": "updated_dummy_model",
        "description": "An updated dummy model",
        "contributor_sso_sid": 9876543210,
        "path": "pulse/demeter/models/experiment_2",
        "checkpoint_path": "epoch_2/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet101", "dummy:dummy"],
        "props": {
            "version": "2.0.0",
            "hyperparameters": {
                "learning_rate": 0.0001,
                "batch_size": 64,
                "optimizer": "AdamW",
            },
            "dummy": "dummy",
        },
    }

    response = client.put(f"{internal_router.prefix}/experiment/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_experiment(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(11),
        "parent_uuid": None,
        "architecture_uuid": generate_dummy_uuid_str(4),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_model",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/models/experiment_1",
        "checkpoint_path": "epoch_1/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {
            "version": "1.0.0",
            "hyperparameters": {
                "learning_rate": 0.001,
                "batch_size": 32,
                "optimizer": "Adam",
            },
        },
    }

    client.post(f"{internal_router.prefix}/experiment/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(11),
        "parent_uuid": None,
        "architecture_uuid": generate_dummy_uuid_str(4),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_model",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/models/experiment_1",
        "checkpoint_path": "epoch_1/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {
            "version": "1.0.0",
            "hyperparameters": {
                "learning_rate": 0.001,
                "batch_size": 32,
                "optimizer": "Adam",
            },
        },
    }

    response = client.delete(f"{internal_router.prefix}/experiment/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_training(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(12),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "flags": 0,
        "props": {},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(12),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "flags": 0,
        "props": {},
    }

    response = client.post(f"{internal_router.prefix}/training/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/training/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_trainings(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(12, i),
        "experiment_uuid": generate_dummy_uuid_str(11, i),
        "flags": i,
        "props": {},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(12, i),
        "experiment_uuid": generate_dummy_uuid_str(11, i),
        "flags": i,
        "props": {},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/trainings/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/trainings/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_training(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(12),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "flags": 0,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/training/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(12),
        "experiment_uuid": generate_dummy_uuid_str(11, 1),
        "flags": 0x010000,
        "props": {},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(12),
        "experiment_uuid": generate_dummy_uuid_str(11, 1),
        "flags": 0x010000,
        "props": {},
    }

    response = client.put(f"{internal_router.prefix}/training/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_training(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(12),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "flags": 0,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/training/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(12),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "flags": 0,
        "props": {},
    }

    response = client.delete(f"{internal_router.prefix}/training/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_experiment_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    response = client.post(f"{internal_router.prefix}/experiment_promotion/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/experiment_promotion/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_experiment_promotions(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(16, i),
        "experiment_uuid": generate_dummy_uuid_str(11, i),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(16, i),
        "experiment_uuid": generate_dummy_uuid_str(11, i),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/experiment_promotions/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/experiment_promotions/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_experiment_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/experiment_promotion/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 9876543210,
        "flags": 0x010000,
        "props": {},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 9876543210,
        "flags": 0x010000,
        "props": {},
    }

    response = client.put(f"{internal_router.prefix}/experiment_promotion/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_experiment_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/experiment_promotion/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    response = client.delete(f"{internal_router.prefix}/experiment_promotion/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_assessment(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(13),
        "benchmark_uuid": generate_dummy_uuid_str(5),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_assessment",
        "description": "A dummy model assessment",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/assessments/assessment_v1/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.95,
                "precision": 0.93,
                "recall": 0.94,
                "f1_score": 0.935,
            },
            "confusion_matrix": [[100, 5], [3, 92]],
        },
        "tags": ["evaluation:performance", "metric:accuracy"],
        "props": {
            "hardware": "nvidia_a100",
            "evaluation_time_seconds": 120.5,
        },
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(13),
        "benchmark_uuid": generate_dummy_uuid_str(5),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_assessment",
        "description": "A dummy model assessment",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/assessments/assessment_v1/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.95,
                "precision": 0.93,
                "recall": 0.94,
                "f1_score": 0.935,
            },
            "confusion_matrix": [[100, 5], [3, 92]],
        },
        "tags": ["evaluation:performance", "metric:accuracy"],
        "props": {
            "hardware": "nvidia_a100",
            "evaluation_time_seconds": 120.5,
        },
    }

    response = client.post(f"{internal_router.prefix}/assessment/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/assessment/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_assessments(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(13, i),
        "benchmark_uuid": generate_dummy_uuid_str(5, i),
        "experiment_uuid": generate_dummy_uuid_str(11, i),
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_assessment_{i}",
        "description": "A dummy model assessment",
        "contributor_sso_sid": 1234567890,
        "path": f"pulse/demeter/assessments/assessment_v{i}/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.90 + i * 0.001,
                "precision": 0.88 + i * 0.001,
                "recall": 0.89 + i * 0.001,
                "f1_score": 0.885 + i * 0.001,
            },
            "confusion_matrix": [[100, 5], [3, 92]],
        },
        "tags": ["evaluation:performance", "metric:accuracy"],
        "props": {
            "hardware": "nvidia_a100",
            "evaluation_time_seconds": 120.5 + i,
        },
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(13, i),
        "benchmark_uuid": generate_dummy_uuid_str(5, i),
        "experiment_uuid": generate_dummy_uuid_str(11, i),
        "dataset_uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_assessment_{i}",
        "description": "A dummy model assessment",
        "contributor_sso_sid": 1234567890,
        "path": f"pulse/demeter/assessments/assessment_v{i}/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.90 + i * 0.001,
                "precision": 0.88 + i * 0.001,
                "recall": 0.89 + i * 0.001,
                "f1_score": 0.885 + i * 0.001,
            },
            "confusion_matrix": [[100, 5], [3, 92]],
        },
        "tags": ["evaluation:performance", "metric:accuracy"],
        "props": {
            "hardware": "nvidia_a100",
            "evaluation_time_seconds": 120.5 + i,
        },
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/assessments/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/assessments/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_assessment(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(13),
        "benchmark_uuid": generate_dummy_uuid_str(5),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_assessment",
        "description": "A dummy model assessment",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/assessments/assessment_v1/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.95,
                "precision": 0.93,
                "recall": 0.94,
                "f1_score": 0.935,
            },
            "confusion_matrix": [[100, 5], [3, 92]],
        },
        "tags": ["evaluation:performance", "metric:accuracy"],
        "props": {
            "hardware": "nvidia_a100",
            "evaluation_time_seconds": 120.5,
        },
    }

    client.post(f"{internal_router.prefix}/assessment/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(13),
        "benchmark_uuid": generate_dummy_uuid_str(5, 1),
        "experiment_uuid": generate_dummy_uuid_str(11, 1),
        "dataset_uuid": generate_dummy_uuid_str(7, 1),
        "name": "updated_dummy_assessment",
        "description": "An updated dummy model assessment",
        "contributor_sso_sid": 9876543210,
        "path": "pulse/demeter/assessments/assessment_v2/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.97,
                "precision": 0.96,
                "recall": 0.95,
                "f1_score": 0.955,
            },
            "confusion_matrix": [[105, 3], [2, 95]],
            "additional_metric": "new_value",
        },
        "tags": ["evaluation:performance", "metric:accuracy", "metric:f1", "updated:true"],
        "props": {
            "hardware": "nvidia_a100 40GB",
            "evaluation_time_seconds": 115.3,
            "additional_info": "updated",
        },
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(13),
        "benchmark_uuid": generate_dummy_uuid_str(5, 1),
        "experiment_uuid": generate_dummy_uuid_str(11, 1),
        "dataset_uuid": generate_dummy_uuid_str(7, 1),
        "name": "updated_dummy_assessment",
        "description": "An updated dummy model assessment",
        "contributor_sso_sid": 9876543210,
        "path": "pulse/demeter/assessments/assessment_v2/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.97,
                "precision": 0.96,
                "recall": 0.95,
                "f1_score": 0.955,
            },
            "confusion_matrix": [[105, 3], [2, 95]],
            "additional_metric": "new_value",
        },
        "tags": ["evaluation:performance", "metric:accuracy", "metric:f1", "updated:true"],
        "props": {
            "hardware": "nvidia_a100 40GB",
            "evaluation_time_seconds": 115.3,
            "additional_info": "updated",
        },
    }

    response = client.put(f"{internal_router.prefix}/assessment/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_assessment(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(13),
        "benchmark_uuid": generate_dummy_uuid_str(5),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_assessment",
        "description": "A dummy model assessment",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/assessments/assessment_v1/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.95,
                "precision": 0.93,
                "recall": 0.94,
                "f1_score": 0.935,
            },
            "confusion_matrix": [[100, 5], [3, 92]],
        },
        "tags": ["evaluation:performance", "metric:accuracy"],
        "props": {
            "hardware": "nvidia_a100",
            "evaluation_time_seconds": 120.5,
        },
    }

    client.post(f"{internal_router.prefix}/assessment/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(13),
        "benchmark_uuid": generate_dummy_uuid_str(5),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "name": "dummy_assessment",
        "description": "A dummy model assessment",
        "contributor_sso_sid": 1234567890,
        "path": "pulse/demeter/assessments/assessment_v1/results.json",
        "assessment_data": {
            "metrics": {
                "accuracy": 0.95,
                "precision": 0.93,
                "recall": 0.94,
                "f1_score": 0.935,
            },
            "confusion_matrix": [[100, 5], [3, 92]],
        },
        "tags": ["evaluation:performance", "metric:accuracy"],
        "props": {
            "hardware": "nvidia_a100",
            "evaluation_time_seconds": 120.5,
        },
    }

    response = client.delete(f"{internal_router.prefix}/assessment/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_evaluation(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(14),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "flags": 0,
        "props": {},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(14),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "flags": 0,
        "props": {},
    }

    response = client.post(f"{internal_router.prefix}/evaluation/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/evaluation/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_evaluations(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(14, i),
        "assessment_uuid": generate_dummy_uuid_str(13, i),
        "flags": i,
        "props": {},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(14, i),
        "assessment_uuid": generate_dummy_uuid_str(13, i),
        "flags": i,
        "props": {},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/evaluations/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/evaluations/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_evaluation(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(14),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "flags": 0,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/evaluation/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(14),
        "assessment_uuid": generate_dummy_uuid_str(13, 1),
        "flags": 0x010000,
        "props": {},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(14),
        "assessment_uuid": generate_dummy_uuid_str(13, 1),
        "flags": 0x010000,
        "props": {},
    }

    response = client.put(f"{internal_router.prefix}/evaluation/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_evaluation(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(14),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "flags": 0,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/evaluation/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(14),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "flags": 0,
        "props": {},
    }

    response = client.delete(f"{internal_router.prefix}/evaluation/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_assessment_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    response = client.post(f"{internal_router.prefix}/assessment_promotion/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/assessment_promotion/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_assessment_promotions(fixture_make_session):
    request_data = [{
        "uuid": generate_dummy_uuid_str(17, i),
        "assessment_uuid": generate_dummy_uuid_str(13, i),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(17, i),
        "assessment_uuid": generate_dummy_uuid_str(13, i),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/assessment_promotions/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/assessment_promotions/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_assessment_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/assessment_promotion/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 9876543210,
        "flags": 0x010000,
        "props": {},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 9876543210,
        "flags": 0x010000,
        "props": {},
    }

    response = client.put(f"{internal_router.prefix}/assessment_promotion/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_assessment_promotion(fixture_make_session):
    request_data = {
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "props": {},
    }

    client.post(f"{internal_router.prefix}/assessment_promotion/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    response = client.delete(f"{internal_router.prefix}/assessment_promotion/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)
