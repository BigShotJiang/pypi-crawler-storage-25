import hashlib

import pytest_postgresql.factories
from fastapi.testclient import TestClient
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare
from plexus.pulse.common.utils.testutils import generate_dummy_uuid_str, generate_dummy_vin_code
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker

from plexus.pulse.demeter.app.api.archive_internal_endpoints import router as internal_router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models.registry import BaseModel

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_session_maker = patched_postgresql_session_maker("fixture_postgresql_test",
                                                         BaseModel,
                                                         app,
                                                         make_session,
                                                         expire_on_commit=False)

client = TestClient(app)


def test_create_vehicle_template(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(1),
        "vehicle_type": "dummy_vehicle_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(1),
        "vehicle_type": "dummy_vehicle_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    response = client.post(f"{internal_router.prefix}/vehicle_template/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/vehicle_template/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_vehicle_templates(fixture_session_maker):
    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "vehicle_type": "dummy_vehicle_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": f"dummy_model_name_{i}/series",
        "model_code": f"dummy_model_code_{i}/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(1, i),
        "vehicle_type": "dummy_vehicle_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": f"dummy_model_name_{i}/series",
        "model_code": f"dummy_model_code_{i}/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/vehicle_templates/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/vehicle_templates/", params=[("limit", 1000)])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_vehicle_template(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(1),
        "vehicle_type": "dummy_vehicle_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/vehicle_template/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(1, 1),
        "vehicle_type": "another_dummy_vehicle_type/subtype",
        "manufacturer": "another_dummy_manufacturer",
        "model_name": "another_dummy_model_name/series",
        "model_code": "another_dummy_model_code/subcode",
        "production_stage": "production",
        "specification": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(1, 1),
        "vehicle_type": "another_dummy_vehicle_type/subtype",
        "manufacturer": "another_dummy_manufacturer",
        "model_name": "another_dummy_model_name/series",
        "model_code": "another_dummy_model_code/subcode",
        "production_stage": "production",
        "specification": {"dummy": "dummy", "another": "another"},
    }

    response = client.put(f"{internal_router.prefix}/vehicle_template/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_vehicle_template(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(1),
        "vehicle_type": "dummy_vehicle_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/vehicle_template/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(1),
        "vehicle_type": "dummy_vehicle_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    response = client.delete(f"{internal_router.prefix}/vehicle_template/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_sensor_template(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(2),
        "sensor_type": "dummy_sensor_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(2),
        "sensor_type": "dummy_sensor_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    response = client.post(f"{internal_router.prefix}/sensor_template/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/sensor_template/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_sensor_templates(fixture_session_maker):
    request_data = [{
        "uuid": generate_dummy_uuid_str(2, i),
        "sensor_type": "dummy_sensor_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": f"dummy_model_name_{i}/series",
        "model_code": f"dummy_model_code_{i}/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(2, i),
        "sensor_type": "dummy_sensor_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": f"dummy_model_name_{i}/series",
        "model_code": f"dummy_model_code_{i}/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/sensor_templates/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/sensor_templates/", params=[("limit", 1000)])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_sensor_template(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(2),
        "sensor_type": "dummy_sensor_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/sensor_template/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(2, 1),
        "sensor_type": "another_dummy_sensor_type/subtype",
        "manufacturer": "another_dummy_manufacturer",
        "model_name": "another_dummy_model_name/series",
        "model_code": "another_dummy_model_code/subcode",
        "production_stage": "production",
        "specification": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(2, 1),
        "sensor_type": "another_dummy_sensor_type/subtype",
        "manufacturer": "another_dummy_manufacturer",
        "model_name": "another_dummy_model_name/series",
        "model_code": "another_dummy_model_code/subcode",
        "production_stage": "production",
        "specification": {"dummy": "dummy", "another": "another"},
    }

    response = client.put(f"{internal_router.prefix}/sensor_template/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_sensor_template(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(2),
        "sensor_type": "dummy_sensor_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/sensor_template/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(2),
        "sensor_type": "dummy_sensor_type/subtype",
        "manufacturer": "dummy_manufacturer",
        "model_name": "dummy_model_name/series",
        "model_code": "dummy_model_code/subcode",
        "production_stage": "prototype",
        "specification": {"dummy": "dummy"},
    }

    response = client.delete(f"{internal_router.prefix}/sensor_template/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_vehicle(fixture_session_maker):
    request_data = {
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response = client.post(f"{internal_router.prefix}/vehicle/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/vehicle/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_vehicles(fixture_session_maker):
    request_data = [{
        "vin_code": generate_dummy_vin_code(i),
        "asset_id": f"2020-veh-{i + 1:05d}",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": f"dummy_vehicle_{i}",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "vin_code": generate_dummy_vin_code(i),
        "asset_id": f"2020-veh-{i + 1:05d}",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": f"dummy_vehicle_{i}",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/vehicles/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/vehicles/", params=[("limit", 1000)])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_vehicle(fixture_session_maker):
    request_data = {
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/vehicle/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "vin_code": generate_dummy_vin_code(1),
        "asset_id": "2020-veh-00002",
        "vehicle_template_uuid": generate_dummy_uuid_str(1, 1),
        "name": "another_dummy_vehicle",
        "purchase_date": "2020-02-01",
        "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "vin_code": generate_dummy_vin_code(1),
        "asset_id": "2020-veh-00002",
        "vehicle_template_uuid": generate_dummy_uuid_str(1, 1),
        "name": "another_dummy_vehicle",
        "purchase_date": "2020-02-01",
        "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response = client.put(f"{internal_router.prefix}/vehicle/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_vehicle(fixture_session_maker):
    request_data = {
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/vehicle/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response = client.delete(f"{internal_router.prefix}/vehicle/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_sensor(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response = client.post(f"{internal_router.prefix}/sensor/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/sensor/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_sensors(fixture_session_maker):
    request_data = [{
        "uuid": generate_dummy_uuid_str(3, i),
        "asset_id": f"2020-sen-{i + 1:05d}",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": f"SN-DUMMY-{i + 1:04d}",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3, i),
        "asset_id": f"2020-sen-{i + 1:05d}",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": f"SN-DUMMY-{i + 1:04d}",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/sensors/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/sensors/", params=[("limit", 1000)])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_sensor(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/sensor/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00002",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-ANOTHER-DUMMY-0001",
        "purchase_date": "2020-02-01",
        "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00002",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-ANOTHER-DUMMY-0001",
        "purchase_date": "2020-02-01",
        "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response = client.put(f"{internal_router.prefix}/sensor/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_sensor(fixture_session_maker):
    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/sensor/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response = client.delete(f"{internal_router.prefix}/sensor/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_bag(fixture_session_maker):
    request_data = {
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 0,
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    response = client.post(f"{internal_router.prefix}/bag/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/bag/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_bags(fixture_session_maker):
    request_data = [{
        "name": f"20200101T000000-dummy_vehicle-{i}.bag",
        "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-{i}.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-{i}.bag".encode()).hexdigest(),
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "name": f"20200101T000000-dummy_vehicle-{i}.bag",
        "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-{i}.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-{i}.bag".encode()).hexdigest(),
        "flags": 0,
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    } for i in range(100)]

    response = client.post(f"{internal_router.prefix}/bags/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{internal_router.prefix}/bags/", params=[("limit", 1000)])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_bag(fixture_session_maker):
    request_data = {
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/bag/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "name": "20200101T000000-another_dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(1),
        "vehicle_name": "another_dummy_vehicle",
        "begin_at": "2020-02-01T00:00:00.000000+00:00",
        "end_at": "2020-02-01T12:00:00.000000+00:00",
        "file_size": 2147483648,
        "file_checksum": hashlib.sha256("20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 1,
        "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "name": "20200101T000000-another_dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(1),
        "vehicle_name": "another_dummy_vehicle",
        "begin_at": "2020-02-01T00:00:00.000000+00:00",
        "end_at": "2020-02-01T12:00:00.000000+00:00",
        "file_size": 2147483648,
        "file_checksum": hashlib.sha256("20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 1,
        "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response = client.put(f"{internal_router.prefix}/bag/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_bag(fixture_session_maker):
    request_data = {
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    client.post(f"{internal_router.prefix}/bag/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 0,
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    response = client.delete(f"{internal_router.prefix}/bag/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)
