import pytest_postgresql.factories
from fastapi.testclient import TestClient
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker

from plexus.pulse.demeter.app.api.user_endpoints import router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models.registry import BaseModel

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_make_session = patched_postgresql_session_maker("fixture_postgresql_test",
                                                        BaseModel,
                                                        app,
                                                        make_session,
                                                        expire_on_commit=False)

client = TestClient(app)


def test_create_user(fixture_make_session):
    request_data = {
        "name": "some.one",
        "sso_sid": 1234567890,
        "role": "contributor",
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "name": "some.one",
        "sso_sid": 1234567890,
        "role": "contributor",
    }

    response = client.post(f"{router.prefix}/user/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{router.prefix}/user/1")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_users(fixture_make_session):
    request_data = [{
        "name": f"some{i + 1}.one",
        "sso_sid": 1000000000 + i,
        "role": "contributor",
    } for i in range(100)]

    response_expect = [{
        "sqn": i + 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": i + 1,
        "revision": 1,
        "name": f"some{i + 1}.one",
        "sso_sid": 1000000000 + i,
        "role": "contributor",
    } for i in range(100)]

    response = client.post(f"{router.prefix}/users/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{router.prefix}/users/", params={"limit": 1000})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_update_user(fixture_make_session):
    request_data = {
        "name": "some.one",
        "sso_sid": 1234567890,
        "role": "contributor",
    }

    client.post(f"{router.prefix}/user/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    request_data = {
        "name": "another.one",
        "sso_sid": 9876543210,
        "role": "admin",
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "name": "another.one",
        "sso_sid": 9876543210,
        "role": "admin",
    }

    response = client.put(f"{router.prefix}/user/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_delete_user(fixture_make_session):
    request_data = {
        "name": "some.one",
        "sso_sid": 1234567890,
        "role": "contributor",
    }

    client.post(f"{router.prefix}/user/",
                json=request_data,
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"})

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": "2020-02-01T00:00:00.000000+00:00",
        "record_sqn": 1,
        "revision": 1,
        "name": "some.one",
        "sso_sid": 1234567890,
        "role": "contributor",
    }

    response = client.delete(f"{router.prefix}/user/1",
                             params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)
