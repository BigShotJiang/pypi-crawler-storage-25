import math
import timeit

import pytest_postgresql.factories
import sqlalchemy as sa
from fastapi.testclient import TestClient
from plexus.common.utils.dtutils import dt_parse_iso
from plexus.pulse.common.utils.tagutils import predefined_tagsets
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare, generate_dummy_uuid_str
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker, patched_value_factory

from plexus.pulse.demeter.app.api import current_dt_clock
from plexus.pulse.demeter.app.api.dataset_internal_endpoints import router as internal_router
from plexus.pulse.demeter.app.api.dataset_public_endpoints import (
    AssessmentTable,
    DetailedMetricPivotHeader,
    DetailedMetricPivotTable,
    MetricsDisplayOperation,
)
from plexus.pulse.demeter.app.api.dataset_public_endpoints import registered_metrics_display_operations
from plexus.pulse.demeter.app.api.dataset_public_endpoints import router as public_router
from plexus.pulse.demeter.app.api.dataset_workflow_endpoints import router as workflow_router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models import ColumnOrdering, TableColumn
from plexus.pulse.demeter.app.models.registry import BaseModel, JobStatusFlag as Flag

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_make_session = patched_postgresql_session_maker("fixture_postgresql_test",
                                                        BaseModel,
                                                        app,
                                                        make_session,
                                                        expire_on_commit=False)
fixture_current_dt_clock = patched_value_factory(app, current_dt_clock)

client = TestClient(app)


def test_compare_dataset_classifiers(fixture_make_session, fixture_current_dt_clock):
    datasets_count = 10
    samples_count = 100

    for j in range(datasets_count):
        request_data = {
            "dataset": {
                "uuid": generate_dummy_uuid_str(7, j),
                "name": f"dummy_dataset_{j}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890,
                "tags": ["division:training", "mission:name:nation_cover_2020"],
                "props": {},
            },
            "samples": [{
                "uuid": generate_dummy_uuid_str(8, j, i),
                "path": f"pulse/demeter/datasets/dataset_{j}/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1),
                "bag_name": f"20200101T000000-dummy_vehicle_{j}-0.bag",
                "vehicle_name": f"dummy_vehicle_{j}",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": [
                    "tod:daytime" if i % 3 == 0 else "tod:nighttime",
                    "weather:sunny" if i % 2 == 0 else "weather:rainy",
                    "road:traffic:leading",
                    "road:layout:straight",
                ],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            } for i in range(samples_count)],
        }

        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{public_router.prefix}/create_dataset_with_samples/",
                                   json=request_data)
        assert response.status_code == 200, response.text

        request_data = [{
            "uuid": generate_dummy_uuid_str(9, j, i),
            "sample_uuid": generate_dummy_uuid_str(8, j, i),
            "taxonomy_uuid": generate_dummy_uuid_str(2),
            "classifier_data": {
                "classifiers": [
                    {"name": ("data_fidelity:camera_issue:glare"
                              if i % 2 == 0 else "data_fidelity:camera_issue:lens_smear")},
                    {"name": ("data_fidelity:radar_issue:clutter"
                              if i % 3 == 0 else "data_fidelity:radar_issue:interference")},
                    {"name": ("environment:tod:daytime"
                              if i % 4 == 0 else "environment:tod:nighttime")},
                    {"name": ("environment:weather:clear"
                              if i % 5 == 0 else "environment:weather:rainy")},
                    {"name": ("roadway:classification:highway"
                              if i % 6 == 0 else "roadway:classification:residential")},
                    {"name": ("roadway:infrastructure:bridge"
                              if i % 7 == 0 else "roadway:infrastructure:tunnel")},
                    {"name": ("roadway:junction:merge"
                              if i % 8 == 0 else "roadway:junction:split")},
                    {"name": ("traffic:accident:debris_on_road"
                              if i % 9 == 0 else "traffic:accident:police_stop")},
                    {"name": ("traffic:density:dense"
                              if i % 10 == 0 else "traffic:density:sparse")},
                ],
            },
        } for i in range(samples_count)]

        response = client.post(f"{internal_router.prefix}/classifiers/",
                               json=request_data,
                               params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    response_expect = {
        "comparison_view": "default",
        "datasets": [{
            "sqn": i + 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7, i),
            "name": f"dummy_dataset_{i}",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        } for i in range(datasets_count)],
        "collections": [
            {
                "name": "data_fidelity:camera_issue",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "glare", "data": math.ceil(samples_count / 2)},
                        {"name": "lens_smear", "data": samples_count - math.ceil(samples_count / 2)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "data_fidelity:radar_issue",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "clutter", "data": math.ceil(samples_count / 3)},
                        {"name": "interference", "data": samples_count - math.ceil(samples_count / 3)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "environment:tod",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "daytime", "data": math.ceil(samples_count / 4)},
                        {"name": "nighttime", "data": samples_count - math.ceil(samples_count / 4)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "environment:weather",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "clear", "data": math.ceil(samples_count / 5)},
                        {"name": "rainy", "data": samples_count - math.ceil(samples_count / 5)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:classification",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "highway", "data": math.ceil(samples_count / 6)},
                        {"name": "residential", "data": samples_count - math.ceil(samples_count / 6)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:infrastructure",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "bridge", "data": math.ceil(samples_count / 7)},
                        {"name": "tunnel", "data": samples_count - math.ceil(samples_count / 7)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:junction",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "merge", "data": math.ceil(samples_count / 8)},
                        {"name": "split", "data": samples_count - math.ceil(samples_count / 8)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "traffic:accident",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "debris_on_road", "data": math.ceil(samples_count / 9)},
                        {"name": "police_stop", "data": samples_count - math.ceil(samples_count / 9)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "traffic:density",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "dense", "data": math.ceil(samples_count / 10)},
                        {"name": "sparse", "data": samples_count - math.ceil(samples_count / 10)},
                    ],
                } for i in range(datasets_count)],
            },
        ],
    }

    timer_start = timeit.default_timer()
    response = client.post(f"{public_router.prefix}/compare_dataset_classifiers/",
                           json={
                               "comparison_view": "default",
                               "dataset_uuids": [generate_dummy_uuid_str(7, i) for i in range(datasets_count)],
                           })
    assert response.status_code == 200, response.text
    print(f"compare_dataset_classifiers timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_compare_dataset_classifiers_with_conditions(fixture_make_session, fixture_current_dt_clock):
    datasets_count = 10
    samples_count = 100

    for j in range(datasets_count):
        request_data = {
            "dataset": {
                "uuid": generate_dummy_uuid_str(7, j),
                "name": f"dummy_dataset_{j}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890,
                "tags": ["division:training", "mission:name:nation_cover_2020"],
                "props": {},
            },
            "samples": [{
                "uuid": generate_dummy_uuid_str(8, j, i),
                "path": f"pulse/demeter/datasets/dataset_{j}/samples/image_{i}.jpg",
                "layout_uuid": generate_dummy_uuid_str(1),
                "bag_name": f"20200101T000000-dummy_vehicle_{j}-0.bag",
                "vehicle_name": f"dummy_vehicle_{j}",
                "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
                "child_sample_uuids": None,
                "tags": [
                    "tod:daytime" if i % 3 == 0 else "tod:nighttime",
                    "weather:sunny" if i % 2 == 0 else "weather:rainy",
                    "road:traffic:leading",
                    "road:layout:straight",
                ],
                "props": {"camera": "front_center", "resolution": "1920x1080"},
            } for i in range(samples_count)],
        }

        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{public_router.prefix}/create_dataset_with_samples/",
                                   json=request_data)
        assert response.status_code == 200, response.text

        request_data = [{
            "uuid": generate_dummy_uuid_str(9, j, i),
            "sample_uuid": generate_dummy_uuid_str(8, j, i),
            "taxonomy_uuid": generate_dummy_uuid_str(2),
            "classifier_data": {
                "classifiers": [
                    {"name": ("data_fidelity:camera_issue:glare"
                              if i % 2 == 0 else "data_fidelity:camera_issue:lens_smear")},
                    {"name": ("data_fidelity:radar_issue:clutter"
                              if i % 3 == 0 else "data_fidelity:radar_issue:interference")},
                    {"name": ("environment:tod:daytime"
                              if i % 4 == 0 else "environment:tod:nighttime")},
                    {"name": ("environment:weather:clear"
                              if i % 5 == 0 else "environment:weather:rainy")},
                    {"name": ("roadway:classification:highway"
                              if i % 6 == 0 else "roadway:classification:residential")},
                    {"name": ("roadway:infrastructure:bridge"
                              if i % 7 == 0 else "roadway:infrastructure:tunnel")},
                    {"name": ("roadway:junction:merge"
                              if i % 8 == 0 else "roadway:junction:split")},
                    {"name": ("traffic:accident:debris_on_road"
                              if i % 9 == 0 else "traffic:accident:police_stop")},
                    {"name": ("traffic:density:dense"
                              if i % 10 == 0 else "traffic:density:sparse")},
                ],
            },
        } for i in range(samples_count)]

        response = client.post(f"{internal_router.prefix}/classifiers/",
                               json=request_data,
                               params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    response_expect = {
        "comparison_view": "default",
        "datasets": [{
            "sqn": i + 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7, i),
            "name": f"dummy_dataset_{i}",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        } for i in range(datasets_count)],
        "collections": [
            {
                "name": "data_fidelity:camera_issue",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "glare", "data": math.ceil(samples_count / 2) * 2},
                                       {"name": "lens_smear",
                                        "data": (samples_count - math.ceil(samples_count / 2)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "glare", "data": math.ceil(samples_count / 2)},
                        {"name": "lens_smear", "data": samples_count - math.ceil(samples_count / 2)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "data_fidelity:radar_issue",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "clutter", "data": math.ceil(samples_count / 3) * 2},
                                       {"name": "interference",
                                        "data": (samples_count - math.ceil(samples_count / 3)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "clutter", "data": math.ceil(samples_count / 3)},
                        {"name": "interference", "data": samples_count - math.ceil(samples_count / 3)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "environment:tod",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "daytime", "data": math.ceil(samples_count / 4) * 2},
                                       {"name": "nighttime",
                                        "data": (samples_count - math.ceil(samples_count / 4)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "daytime", "data": math.ceil(samples_count / 4)},
                        {"name": "nighttime", "data": samples_count - math.ceil(samples_count / 4)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "environment:weather",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "clear", "data": math.ceil(samples_count / 5) * 2},
                                       {"name": "rainy",
                                        "data": (samples_count - math.ceil(samples_count / 5)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "clear", "data": math.ceil(samples_count / 5)},
                        {"name": "rainy", "data": samples_count - math.ceil(samples_count / 5)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:classification",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "highway", "data": math.ceil(samples_count / 6) * 2},
                                       {"name": "residential",
                                        "data": (samples_count - math.ceil(samples_count / 6)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "highway", "data": math.ceil(samples_count / 6)},
                        {"name": "residential", "data": samples_count - math.ceil(samples_count / 6)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:infrastructure",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "bridge", "data": math.ceil(samples_count / 7) * 2},
                                       {"name": "tunnel",
                                        "data": (samples_count - math.ceil(samples_count / 7)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "bridge", "data": math.ceil(samples_count / 7)},
                        {"name": "tunnel", "data": samples_count - math.ceil(samples_count / 7)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:junction",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "merge", "data": math.ceil(samples_count / 8) * 2},
                                       {"name": "split",
                                        "data": (samples_count - math.ceil(samples_count / 8)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "merge", "data": math.ceil(samples_count / 8)},
                        {"name": "split", "data": samples_count - math.ceil(samples_count / 8)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "traffic:accident",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "debris_on_road", "data": math.ceil(samples_count / 9) * 2},
                                       {"name": "police_stop",
                                        "data": (samples_count - math.ceil(samples_count / 9)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "debris_on_road", "data": math.ceil(samples_count / 9)},
                        {"name": "police_stop", "data": samples_count - math.ceil(samples_count / 9)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "traffic:density",
                "metrics": [
                               {
                                   "dataset_uuid": generate_dummy_uuid_str(),
                                   "items": [
                                       {"name": "dense", "data": math.ceil(samples_count / 10) * 2},
                                       {"name": "sparse",
                                        "data": (samples_count - math.ceil(samples_count / 10)) * 2},
                                   ],
                               },
                           ] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "dense", "data": math.ceil(samples_count / 10)},
                        {"name": "sparse", "data": samples_count - math.ceil(samples_count / 10)},
                    ],
                } for i in range(datasets_count)],
            },
        ],
    }

    timer_start = timeit.default_timer()
    response = client.post(f"{public_router.prefix}/compare_dataset_classifiers_with_conditions/",
                           json={
                               "comparison_view": "default",
                               "dataset_uuids": [generate_dummy_uuid_str(7, i) for i in range(datasets_count)],
                               "conditions": {
                                   "included_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                              for i in range(datasets_count) if i % 3 == 0],
                                   "excluded_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                              for i in range(datasets_count) if i % 2 == 0],
                               },
                           })
    assert response.status_code == 200, response.text
    print(f"compare_dataset_classifiers_with_conditions timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "comparison_view": "default",
        "datasets": [{
            "sqn": i + 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7, i),
            "name": f"dummy_dataset_{i}",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:nation_cover_2020"],
            "props": {},
        } for i in range(datasets_count)],
        "collections": [
            {
                "name": "data_fidelity:camera_issue",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "glare",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 2 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "lens_smear",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 2 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "glare", "data": math.ceil(samples_count / 2)},
                        {"name": "lens_smear", "data": samples_count - math.ceil(samples_count / 2)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "data_fidelity:radar_issue",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "clutter",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 3 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "interference",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 3 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "clutter", "data": math.ceil(samples_count / 3)},
                        {"name": "interference", "data": samples_count - math.ceil(samples_count / 3)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "environment:tod",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "daytime",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 4 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "nighttime",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 4 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "daytime", "data": math.ceil(samples_count / 4)},
                        {"name": "nighttime", "data": samples_count - math.ceil(samples_count / 4)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "environment:weather",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "clear",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 5 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "rainy",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 5 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "clear", "data": math.ceil(samples_count / 5)},
                        {"name": "rainy", "data": samples_count - math.ceil(samples_count / 5)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:classification",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "highway",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 6 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "residential",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 6 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "highway", "data": math.ceil(samples_count / 6)},
                        {"name": "residential", "data": samples_count - math.ceil(samples_count / 6)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:infrastructure",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "bridge",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 7 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "tunnel",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 7 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "bridge", "data": math.ceil(samples_count / 7)},
                        {"name": "tunnel", "data": samples_count - math.ceil(samples_count / 7)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "roadway:junction",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "merge",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 8 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "split",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 8 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "merge", "data": math.ceil(samples_count / 8)},
                        {"name": "split", "data": samples_count - math.ceil(samples_count / 8)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "traffic:accident",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "debris_on_road",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 9 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "police_stop",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 9 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "debris_on_road", "data": math.ceil(samples_count / 9)},
                        {"name": "police_stop", "data": samples_count - math.ceil(samples_count / 9)},
                    ],
                } for i in range(datasets_count)],
            },
            {
                "name": "traffic:density",
                "metrics": [{
                    "dataset_uuid": generate_dummy_uuid_str(),
                    "items": list(filter(
                        lambda x: x["data"] > 0,
                        [
                            {"name": "dense",
                             "data": sum(1 for i in range(samples_count) if
                                         i % 10 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                            {"name": "sparse",
                             "data": sum(1 for i in range(samples_count) if
                                         not i % 10 == 0 and not i % 2 == 0 and i % 3 == 0) * 2},
                        ])),
                }] + [{
                    "dataset_uuid": generate_dummy_uuid_str(7, i),
                    "items": [
                        {"name": "dense", "data": math.ceil(samples_count / 10)},
                        {"name": "sparse", "data": samples_count - math.ceil(samples_count / 10)},
                    ],
                } for i in range(datasets_count)],
            },
        ],
    }

    timer_start = timeit.default_timer()
    response = client.post(f"{public_router.prefix}/compare_dataset_classifiers_with_conditions/",
                           json={
                               "comparison_view": "default",
                               "dataset_uuids": [generate_dummy_uuid_str(7, i) for i in range(datasets_count)],
                               "conditions": {
                                   "included_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                              for i in range(datasets_count) if i % 3 == 0],
                                   "excluded_dataset_uuids": [generate_dummy_uuid_str(7, i)
                                                              for i in range(datasets_count) if i % 2 == 0],
                                   "required_tags": ["tod:daytime"],
                                   "unwanted_tags": ["weather:sunny"],
                               },
                           })
    assert response.status_code == 200, response.text
    print(f"compare_dataset_classifiers_with_conditions timer: {timeit.default_timer() - timer_start}")

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_get_model_experiment_lineage(fixture_make_session, fixture_current_dt_clock):
    datasets_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_dataset_{i}" if i % 2 == 0 else f"another_dummy_dataset_{i}",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
        "tags": ["division:training", "mission:name:test"],
        "props": {},
    } for i in range(datasets_count)]

    response = client.post(f"{internal_router.prefix}/datasets/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    architectures_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"perception/model_{i}",
        "version": f"1.0.{i}",
        "description": f"Model architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(architectures_count)]

    response = client.post(f"{internal_router.prefix}/architectures/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    trainings_count = 50

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_model_training/",
                                   json={
                                       "uuid": generate_dummy_uuid_str(12, i),
                                       "props": {},
                                       "experiment": {
                                           "uuid": generate_dummy_uuid_str(11, i),
                                           "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
                                           "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                                           "name": "dummy_model",
                                           "description": "A dummy model experiment",
                                           "contributor_sso_sid": 1234567890,
                                           "path": f"pulse/demeter/models/experiment_{i}",
                                           "checkpoint_path": f"epoch_{i}/model.pth",
                                           "tags": ["model:bev_perception", "framework:pytorch"],
                                           "props": {},
                                       },
                                   })
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_model_training/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(12, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        request_data = {
            "uuid": generate_dummy_uuid_str(11, i),
            "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
            "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
            "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
            "name": f"dummy_model_{i}" if i % 2 == 0 else f"another_dummy_model_{i}",
            "description": "A dummy model",
            "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
            "path": f"pulse/demeter/models/experiment_{i}",
            "checkpoint_path": f"epoch_{i}/model.pth",
            "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
            "props": {
                "version": f"1.0.{i}",
                "hyperparameters": {
                    "learning_rate": 0.001,
                    "batch_size": 32,
                    "optimizer": "Adam",
                },
            },
        }

        response = client.put(f"{internal_router.prefix}/experiment/{i + 1}",
                              json=request_data,
                              params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_experiment_promotion/",
                                   params={
                                       "uuid": generate_dummy_uuid_str(16, i),
                                       "experiment_uuid": generate_dummy_uuid_str(11, i),
                                       "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                   })
        assert response.status_code == 200, response.text

    for i in range(trainings_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_experiment_promotion/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(16, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    def make_response_experiment_details(i: int):
        return {
            "experiment": {
                "sqn": trainings_count + i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(11, i),
                "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
                "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
                "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                "name": f"dummy_model_{i}" if i % 2 == 0 else f"another_dummy_model_{i}",
                "description": "A dummy model",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "path": f"pulse/demeter/models/experiment_{i}",
                "checkpoint_path": f"epoch_{i}/model.pth",
                "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
                "props": {
                    "version": f"1.0.{i}",
                    "hyperparameters": {
                        "learning_rate": 0.001,
                        "batch_size": 32,
                        "optimizer": "Adam",
                    },
                },
            },
            "training": {
                "sqn": trainings_count + i + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(12, i),
                "experiment_uuid": generate_dummy_uuid_str(11, i),
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "promotion": {
                "sqn": trainings_count + i + 1,
                "created_at": "2020-02-01T00:00:00.000000+00:00",
                "updated_at": "2020-03-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i + 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(16, i),
                "experiment_uuid": generate_dummy_uuid_str(11, i),
                "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                "props": {},
            },
            "architecture": {
                "sqn": i % architectures_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % architectures_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(4, i % architectures_count),
                "name": f"perception/model_{i % architectures_count}",
                "version": f"1.0.{i % architectures_count}",
                "description": f"Model architecture {i % architectures_count}",
                "supported_guideline_uuids": [generate_dummy_uuid_str(3, i % architectures_count)],
                "props": {
                    "version": f"1.0.{i % architectures_count}",
                    "backbone": f"resnet{50 + i % architectures_count}",
                },
            },
            "dataset": {
                "sqn": i % datasets_count + 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": i % datasets_count + 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(7, i % datasets_count),
                "name": f"dummy_dataset_{i % datasets_count}" if i % 2 == 0 else f"another_dummy_dataset_{i % datasets_count}",
                "description": "A dummy dataset",
                "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                "tags": ["division:training", "mission:name:test"],
                "props": {},
            },
            "layouts": [],
            "samples_count": 0,
        }

    # Get by UUID
    timer_total = 0.0
    timer_count = 0
    for i in range(trainings_count):
        response_expect = [make_response_experiment_details(j) for j in reversed(range(0, i + 1))]

        timer_start = timeit.default_timer()
        response = client.get(f"{public_router.prefix}/get_model_experiment_lineage/{generate_dummy_uuid_str(11, i)}")
        assert response.status_code == 200, response.text
        timer_total += timeit.default_timer() - timer_start
        timer_count += 1

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)

    print(f"get_model_experiment_lineage timer: {timer_total} over {timer_count} calls")


def test_benchmark_rankings(fixture_make_session, fixture_current_dt_clock):
    datasets_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(7, i),
        "name": f"dummy_dataset_{i}" if i % 2 == 0 else f"another_dummy_dataset_{i}",
        "description": "A dummy dataset",
        "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
        "tags": ["division:training", "mission:name:test"],
        "props": {},
    } for i in range(datasets_count)]

    response = client.post(f"{internal_router.prefix}/datasets/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    architectures_count = 20

    request_data = [{
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"perception/model_{i}",
        "version": f"1.0.{i}",
        "description": f"Model architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(architectures_count)]

    response = client.post(f"{internal_router.prefix}/architectures/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    benchmarks_count = 20

    request_data = [{
        "uuid": generate_dummy_uuid_str(5, i),
        "name": f"benchmark/spec_{i}",
        "version": f"1.0.{i}",
        "description": f"Test benchmark {i}",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, i)],
        "benchmark_schema": {"type": "object"},
        "props": {},
    } for i in range(benchmarks_count)]

    response = client.post(f"{internal_router.prefix}/benchmarks/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    def metric_values_maker(assessment: AssessmentTable, columns: list[TableColumn]) -> list[float]:
        all_all = next(filter(lambda x: x["category"] == "all" and x["range"] == "all",
                              assessment.assessment_data["data"]),
                       None)
        if all_all is None:
            return [0 for _ in columns]
        return [all_all[column.name] for column in columns]

    def detailed_metric_pivot_tables_maker(
        assessment: AssessmentTable,
        headers: list[DetailedMetricPivotHeader],
    ) -> list[DetailedMetricPivotTable]:
        pivot_tables = []
        for header in headers:
            pivot_dim_name, pivot_dim_value = header.name.split("/")
            filtered_records = list(filter(lambda x: x[pivot_dim_name] == pivot_dim_value,
                                           assessment.assessment_data["data"]))
            pivot_table = DetailedMetricPivotTable(
                name=header.name,
                title_values_sets=[[record[column.name] for column in header.title_columns]
                                   for record in filtered_records],
                metric_values_sets=[[record[column.name] for column in header.metric_columns]
                                    for record in filtered_records],
            )
            pivot_tables.append(pivot_table)
        return pivot_tables

    metrics_display_operations = {
        request_data[i]["name"]: MetricsDisplayOperation(
            order_maker=lambda assessment_table: [sa.desc(assessment_table.sqn)],
            metric_columns=(
                [
                    TableColumn(name="metric_alpha",
                                ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                    TableColumn(name="metric_beta",
                                ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                ] if i % 2 == 0 else
                [
                    TableColumn(name="metric_gamma",
                                ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                    TableColumn(name="metric_delta",
                                ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                ]
            ),
            detailed_metric_pivot_headers=[
                DetailedMetricPivotHeader(
                    name="category/all",
                    title_columns=[
                        TableColumn(name="range",
                                    ordering=ColumnOrdering(semantic="lexical", direction="ascending")),
                    ],
                    metric_columns=(
                        [
                            TableColumn(name="metric_alpha",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                            TableColumn(name="metric_beta",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                        ] if i % 2 == 0 else
                        [
                            TableColumn(name="metric_gamma",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                            TableColumn(name="metric_delta",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                        ]
                    ),
                ),
                DetailedMetricPivotHeader(
                    name="category/car",
                    title_columns=[
                        TableColumn(name="range",
                                    ordering=ColumnOrdering(semantic="lexical", direction="ascending")),
                    ],
                    metric_columns=(
                        [
                            TableColumn(name="metric_alpha",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                            TableColumn(name="metric_beta",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                        ] if i % 2 == 0 else
                        [
                            TableColumn(name="metric_gamma",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                            TableColumn(name="metric_delta",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                        ]
                    ),
                ),
                DetailedMetricPivotHeader(
                    name="category/pedestrian",
                    title_columns=[
                        TableColumn(name="range",
                                    ordering=ColumnOrdering(semantic="lexical", direction="ascending")),
                    ],
                    metric_columns=(
                        [
                            TableColumn(name="metric_alpha",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                            TableColumn(name="metric_beta",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                        ] if i % 2 == 0 else
                        [
                            TableColumn(name="metric_gamma",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                            TableColumn(name="metric_delta",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                        ]
                    ),
                ),
                DetailedMetricPivotHeader(
                    name="range/all",
                    title_columns=[
                        TableColumn(name="category",
                                    ordering=ColumnOrdering(semantic="lexical", direction="ascending")),
                    ],
                    metric_columns=(
                        [
                            TableColumn(name="metric_alpha",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                            TableColumn(name="metric_beta",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                        ] if i % 2 == 0 else
                        [
                            TableColumn(name="metric_gamma",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                            TableColumn(name="metric_delta",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                        ]
                    ),
                ),
                DetailedMetricPivotHeader(
                    name="range/back_50m",
                    title_columns=[
                        TableColumn(name="category",
                                    ordering=ColumnOrdering(semantic="lexical", direction="ascending")),
                    ],
                    metric_columns=(
                        [
                            TableColumn(name="metric_alpha",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                            TableColumn(name="metric_beta",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                        ] if i % 2 == 0 else
                        [
                            TableColumn(name="metric_gamma",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                            TableColumn(name="metric_delta",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                        ]
                    ),
                ),
                DetailedMetricPivotHeader(
                    name="range/front_50m",
                    title_columns=[
                        TableColumn(name="category",
                                    ordering=ColumnOrdering(semantic="lexical", direction="ascending")),
                    ],
                    metric_columns=(
                        [
                            TableColumn(name="metric_alpha",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                            TableColumn(name="metric_beta",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                        ] if i % 2 == 0 else
                        [
                            TableColumn(name="metric_gamma",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                            TableColumn(name="metric_delta",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                        ]
                    ),
                ),
                DetailedMetricPivotHeader(
                    name="range/front_100m",
                    title_columns=[
                        TableColumn(name="category",
                                    ordering=ColumnOrdering(semantic="lexical", direction="ascending")),
                    ],
                    metric_columns=(
                        [
                            TableColumn(name="metric_alpha",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                            TableColumn(name="metric_beta",
                                        ordering=ColumnOrdering(semantic="lexical", direction="descending")),
                        ] if i % 2 == 0 else
                        [
                            TableColumn(name="metric_gamma",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                            TableColumn(name="metric_delta",
                                        ordering=ColumnOrdering(semantic="numeric", direction="ascending")),
                        ]
                    ),
                ),
            ],
            metric_values_maker=metric_values_maker,
            detailed_metric_pivot_tables_maker=detailed_metric_pivot_tables_maker,
        )
        for i in range(benchmarks_count)
    }

    registered_metrics_display_operations().clear()
    registered_metrics_display_operations().update(metrics_display_operations)

    experiments_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(11, i),
        "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
        "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
        "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
        "name": f"dummy_model_{i}",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
        "path": f"pulse/demeter/models/experiment_{i}",
        "checkpoint_path": f"epoch_{i}/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {"version": f"1.0.{i}"},
    } for i in range(experiments_count)]

    response = client.post(f"{internal_router.prefix}/experiments/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    evaluations_count = 100

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_model_evaluation/",
                                   json={
                                       "uuid": generate_dummy_uuid_str(14, i),
                                       "props": {},
                                       "assessment": {
                                           "uuid": generate_dummy_uuid_str(13, i),
                                           "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
                                           "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
                                           "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                                           "name": f"model_assessment_{i}",
                                           "description": f"Model assessment {i}",
                                           "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                           "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
                                           "assessment_data": {},
                                           "tags": ["benchmark:standard", "scope:full"],
                                           "props": {},
                                       },
                                   })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_model_evaluation/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(14, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        request_data = {
            "uuid": generate_dummy_uuid_str(13, i),
            "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
            "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
            "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
            "name": f"model_assessment_{i}" if i % 2 == 0 else f"another_model_assessment_{i}",
            "description": f"Model assessment {i}",
            "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
            "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
            "assessment_data": {
                "version": f"1.0.{i}",
                "data": [
                    {
                        "category": "all",
                        "range": "all",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "all",
                        "range": "back_50m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "all",
                        "range": "front_50m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "all",
                        "range": "front_100m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "car",
                        "range": "all",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "car",
                        "range": "back_50m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "car",
                        "range": "front_50m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "car",
                        "range": "front_100m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "pedestrian",
                        "range": "all",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "pedestrian",
                        "range": "back_50m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "pedestrian",
                        "range": "front_50m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                    {
                        "category": "pedestrian",
                        "range": "front_100m",
                        "metric_alpha": i * 0.1,
                        "metric_beta": i * 10,
                        "metric_gamma": i * -0.1,
                        "metric_delta": i * -10,
                    },
                ],
            },
            "tags": ["benchmark:standard", "scope:full"],
            "props": {},
        }

        response = client.put(f"{internal_router.prefix}/assessment/{i + 1}",
                              json=request_data,
                              params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_assessment_promotion/",
                                   params={
                                       "uuid": generate_dummy_uuid_str(17, i),
                                       "assessment_uuid": generate_dummy_uuid_str(13, i),
                                       "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                   })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_assessment_promotion/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(17, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    def make_response_metric_columns(i: int):
        return (
            [
                {
                    "name": "metric_alpha",
                    "ordering": {"semantic": "lexical", "direction": "descending"},
                    "formatter": None,
                },
                {
                    "name": "metric_beta",
                    "ordering": {"semantic": "lexical", "direction": "descending"},
                    "formatter": None,
                },
            ] if i % 2 == 0 else
            [
                {
                    "name": "metric_gamma",
                    "ordering": {"semantic": "numeric", "direction": "ascending"},
                    "formatter": None,
                },
                {
                    "name": "metric_delta",
                    "ordering": {"semantic": "numeric", "direction": "ascending"},
                    "formatter": None,
                },
            ]
        )

    def make_response_detailed_metric_pivot_headers(i: int):
        return [
            {
                "name": "category/all",
                "title_columns": [
                    {
                        "name": "range",
                        "ordering": {"semantic": "lexical", "direction": "ascending"},
                        "formatter": None,
                    },
                ],
                "metric_columns": make_response_metric_columns(i),
            },
            {
                "name": "category/car",
                "title_columns": [
                    {
                        "name": "range",
                        "ordering": {"semantic": "lexical", "direction": "ascending"},
                        "formatter": None,
                    },
                ],
                "metric_columns": make_response_metric_columns(i),
            },
            {
                "name": "category/pedestrian",
                "title_columns": [
                    {
                        "name": "range",
                        "ordering": {"semantic": "lexical", "direction": "ascending"},
                        "formatter": None,
                    },
                ],
                "metric_columns": make_response_metric_columns(i),
            },
            {
                "name": "range/all",
                "title_columns": [
                    {
                        "name": "category",
                        "ordering": {"semantic": "lexical", "direction": "ascending"},
                        "formatter": None,
                    },
                ],
                "metric_columns": make_response_metric_columns(i),
            },
            {
                "name": "range/back_50m",
                "title_columns": [
                    {
                        "name": "category",
                        "ordering": {"semantic": "lexical", "direction": "ascending"},
                        "formatter": None,
                    },
                ],
                "metric_columns": make_response_metric_columns(i),
            },
            {
                "name": "range/front_50m",
                "title_columns": [
                    {
                        "name": "category",
                        "ordering": {"semantic": "lexical", "direction": "ascending"},
                        "formatter": None,
                    },
                ],
                "metric_columns": make_response_metric_columns(i),
            },
            {
                "name": "range/front_100m",
                "title_columns": [
                    {
                        "name": "category",
                        "ordering": {"semantic": "lexical", "direction": "ascending"},
                        "formatter": None,
                    },
                ],
                "metric_columns": make_response_metric_columns(i),
            },
        ]

    def make_response_assessment_details_with_metrics(i: int):
        return {
            "assessment_detail": {
                "assessment": {
                    "sqn": evaluations_count + i + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-02-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i + 1,
                    "revision": 2,
                    "uuid": generate_dummy_uuid_str(13, i),
                    "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
                    "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
                    "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                    "name": f"model_assessment_{i}" if i % 2 == 0 else f"another_model_assessment_{i}",
                    "description": f"Model assessment {i}",
                    "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                    "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
                    "assessment_data": {
                        "version": f"1.0.{i}",
                        "data": [
                            {
                                "category": "all",
                                "range": "all",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "all",
                                "range": "back_50m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "all",
                                "range": "front_50m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "all",
                                "range": "front_100m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "car",
                                "range": "all",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "car",
                                "range": "back_50m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "car",
                                "range": "front_50m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "car",
                                "range": "front_100m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "pedestrian",
                                "range": "all",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "pedestrian",
                                "range": "back_50m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "pedestrian",
                                "range": "front_50m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                            {
                                "category": "pedestrian",
                                "range": "front_100m",
                                "metric_alpha": i * 0.1,
                                "metric_beta": i * 10,
                                "metric_gamma": i * -0.1,
                                "metric_delta": i * -10,
                            },
                        ],
                    },
                    "tags": ["benchmark:standard", "scope:full"],
                    "props": {},
                },
                "evaluation": {
                    "sqn": evaluations_count + i + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-02-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i + 1,
                    "revision": 2,
                    "uuid": generate_dummy_uuid_str(14, i),
                    "assessment_uuid": generate_dummy_uuid_str(13, i),
                    "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                    "props": {},
                },
                "promotion": {
                    "sqn": evaluations_count + i + 1,
                    "created_at": "2020-02-01T00:00:00.000000+00:00",
                    "updated_at": "2020-03-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i + 1,
                    "revision": 2,
                    "uuid": generate_dummy_uuid_str(17, i),
                    "assessment_uuid": generate_dummy_uuid_str(13, i),
                    "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                    "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                    "props": {},
                },
                "benchmark": {
                    "sqn": i % benchmarks_count + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i % benchmarks_count + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
                    "name": f"benchmark/spec_{i % benchmarks_count}",
                    "version": f"1.0.{i % benchmarks_count}",
                    "description": f"Test benchmark {i % benchmarks_count}",
                    "supported_architecture_uuids": [generate_dummy_uuid_str(4, i % architectures_count)],
                    "benchmark_schema": {"type": "object"},
                    "props": {},
                },
                "experiment": {
                    "sqn": i % experiments_count + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i % experiments_count + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(11, i % experiments_count),
                    "parent_uuid": (generate_dummy_uuid_str(11, i % experiments_count - 1)
                                    if i % experiments_count > 0 else None),
                    "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
                    "dataset_uuid": generate_dummy_uuid_str(7, i % datasets_count),
                    "name": f"dummy_model_{i}",
                    "description": "A dummy model",
                    "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                    "path": f"pulse/demeter/models/experiment_{i}",
                    "checkpoint_path": f"epoch_{i}/model.pth",
                    "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
                    "props": {"version": f"1.0.{i}"},
                },
                "dataset": {
                    "sqn": i % datasets_count + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i % datasets_count + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(7, i % datasets_count),
                    "name": f"dummy_dataset_{i % datasets_count}" if i % 2 == 0 else f"another_dummy_dataset_{i % datasets_count}",
                    "description": "A dummy dataset",
                    "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                    "tags": ["division:training", "mission:name:test"],
                    "props": {},
                },
                "layouts": [],
                "samples_count": 0,
                "architecture": {
                    "sqn": i % architectures_count + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i % architectures_count + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(4, i % architectures_count),
                    "name": f"perception/model_{i % architectures_count}",
                    "version": f"1.0.{i % architectures_count}",
                    "description": f"Model architecture {i % architectures_count}",
                    "supported_guideline_uuids": [generate_dummy_uuid_str(3, i % architectures_count)],
                    "props": {
                        "version": f"1.0.{i % architectures_count}",
                        "backbone": f"resnet{50 + i % architectures_count}",
                    },
                },
            },
            "metric_values": ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
            "detailed_metric_pivot_tables": [
                {
                    "name": "category/all",
                    "title_values_sets": [
                        ["all"],
                        ["back_50m"],
                        ["front_50m"],
                        ["front_100m"],
                    ],
                    "metric_values_sets": [
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                    ],
                },
                {
                    "name": "category/car",
                    "title_values_sets": [
                        ["all"],
                        ["back_50m"],
                        ["front_50m"],
                        ["front_100m"],
                    ],
                    "metric_values_sets": [
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                    ],
                },
                {
                    "name": "category/pedestrian",
                    "title_values_sets": [
                        ["all"],
                        ["back_50m"],
                        ["front_50m"],
                        ["front_100m"],
                    ],
                    "metric_values_sets": [
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                    ],
                },
                {
                    "name": "range/all",
                    "title_values_sets": [
                        ["all"],
                        ["car"],
                        ["pedestrian"],
                    ],
                    "metric_values_sets": [
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                    ],
                },
                {
                    "name": "range/back_50m",
                    "title_values_sets": [
                        ["all"],
                        ["car"],
                        ["pedestrian"],
                    ],
                    "metric_values_sets": [
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                    ],
                },
                {
                    "name": "range/front_50m",
                    "title_values_sets": [
                        ["all"],
                        ["car"],
                        ["pedestrian"],
                    ],
                    "metric_values_sets": [
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                    ],
                },
                {
                    "name": "range/front_100m",
                    "title_values_sets": [
                        ["all"],
                        ["car"],
                        ["pedestrian"],
                    ],
                    "metric_values_sets": [
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                        ([i * 0.1, i * 10.0] if (i % benchmarks_count) % 2 == 0 else [i * -0.1, i * -10.0]),
                    ],
                },
            ]
        }

    # For each benchmark, list model assessments ranked by metrics
    timer_total = 0.0
    timer_count = 0
    for i in range(benchmarks_count):
        response_expect = {
            "metric_columns": make_response_metric_columns(i),
            "detailed_metric_pivot_headers": make_response_detailed_metric_pivot_headers(i),
            "assessment_details_with_metrics": sorted([make_response_assessment_details_with_metrics(j)
                                                       for j in range(i, evaluations_count, benchmarks_count)],
                                                      key=lambda x: x["assessment_detail"]["assessment"]["sqn"],
                                                      reverse=True,
                                                      ),
            "pagination": {"skip": 0, "limit": 1000, "total": evaluations_count // benchmarks_count},
        }

        timer_start = timeit.default_timer()
        response = client.get(f"{public_router.prefix}/benchmark_rankings/",
                              params={
                                  "benchmark": f"benchmark/spec_{i}",
                                  "only_completed_jobs": False,
                                  "only_shared": False,
                              })
        assert response.status_code == 200, response.text
        timer_total += timeit.default_timer() - timer_start
        timer_count += 1

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)

    print(f"benchmark_rankings timer: {timer_total} over {timer_count} calls")

    # For each benchmark, list model assessments ranked by metrics for a specific contributor
    timer_total = 0.0
    timer_count = 0
    for i in range(0, benchmarks_count, 2):
        response_expect = {
            "metric_columns": make_response_metric_columns(i),
            "detailed_metric_pivot_headers": make_response_detailed_metric_pivot_headers(i),
            "assessment_details_with_metrics": [make_response_assessment_details_with_metrics(j)
                                                for j in range(i, evaluations_count, benchmarks_count)],
            "pagination": {"skip": 0, "limit": 1000, "total": evaluations_count // benchmarks_count},
        }

        timer_start = timeit.default_timer()
        response = client.get(f"{public_router.prefix}/benchmark_rankings/",
                              params={
                                  "benchmark": f"benchmark/spec_{i}",
                                  "contributor_sso_sid": 1234567890,
                                  "only_completed_jobs": False,
                                  "only_shared": False,
                              })
        assert response.status_code == 200, response.text
        timer_total += timeit.default_timer() - timer_start
        timer_count += 1

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)

    print(f"benchmark_rankings timer: {timer_total} over {timer_count} calls")

    # For each benchmark, list model assessments ranked by metrics for a specific contributor
    timer_total = 0.0
    timer_count = 0
    for i in range(1, benchmarks_count, 2):
        response_expect = {
            "metric_columns": make_response_metric_columns(i),
            "detailed_metric_pivot_headers": make_response_detailed_metric_pivot_headers(i),
            "assessment_details_with_metrics": [make_response_assessment_details_with_metrics(j)
                                                for j in range(i, evaluations_count, benchmarks_count)],
            "pagination": {"skip": 0, "limit": 1000, "total": evaluations_count // benchmarks_count},
        }

        timer_start = timeit.default_timer()
        response = client.get(f"{public_router.prefix}/benchmark_rankings/",
                              params={
                                  "benchmark": f"benchmark/spec_{i}",
                                  "contributor_sso_sid": 9876543210,
                                  "only_completed_jobs": False,
                                  "only_shared": False,
                              })
        assert response.status_code == 200, response.text
        timer_total += timeit.default_timer() - timer_start
        timer_count += 1

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)

    print(f"benchmark_rankings timer: {timer_total} over {timer_count} calls")


def test_dashboard(fixture_make_session, fixture_current_dt_clock):
    layouts_count = 10

    request_data = [{
        "uuid": generate_dummy_uuid_str(1, i),
        "name": f"multi_camera/layout_{i}",
        "description": f"Multi camera layout {i}",
        "child_layout_uuids": [],
        "layout_spec": {
            "type": "object",
            "properties": {
                "camera_type": {"type": "string"},
                "resolution": {"type": "string"},
            },
        },
        "props": {"camera_count": i + 1},
    } for i in range(layouts_count)]

    response = client.post(f"{internal_router.prefix}/layouts/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    registrations_count = 100

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_dataset_registration/",
                                   json={
                                       "uuid": generate_dummy_uuid_str(6, i),
                                       "resource_path": f"datasets/dummy_dataset_{i}" if i % 2 == 0 else f"datasets/another_dummy_dataset_{i}",
                                       "props": {},
                                       "dataset": {
                                           "uuid": generate_dummy_uuid_str(7, i),
                                           "name": f"dummy_dataset_{i}" if i % 2 == 0 else f"another_dummy_dataset_{i}",
                                           "description": "A dummy dataset",
                                           "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                           "tags": ["division:training", "mission:name:test"],
                                           "props": {},
                                       },
                                   })
        assert response.status_code == 200, response.text

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_dataset_registration/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(6, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    samples_count = 20

    for i in range(registrations_count):
        request_data = [{
            "uuid": generate_dummy_uuid_str(8, i, j),
            "path": f"pulse/demeter/datasets/dataset_{i}/samples/image_{j}.jpg",
            "layout_uuid": generate_dummy_uuid_str(1, j % layouts_count),
            "bag_name": "20200101T000000-dummy_vehicle-0.bag",
            "vehicle_name": "dummy_vehicle",
            "begin_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "end_frame_dt": "2020-01-01T00:00:00.000000+00:00",
            "child_sample_uuids": None,
            "tags": ["weather:sunny", "road:traffic:leading", "road:layout:straight"],
            "props": {"camera": "front_center", "resolution": "1920x1080"},
        } for j in range(samples_count)]

        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(
                f"{public_router.prefix}/append_dataset_with_samples/{generate_dummy_uuid_str(7, i)}",
                json=request_data,
            )
        assert response.status_code == 200, response.text

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_dataset_promotion/",
                                   params={
                                       "uuid": generate_dummy_uuid_str(15, i),
                                       "dataset_uuid": generate_dummy_uuid_str(7, i),
                                       "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                   })
        assert response.status_code == 200, response.text

    for i in range(registrations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_dataset_promotion/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(15, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    architectures_count = 20

    request_data = [{
        "uuid": generate_dummy_uuid_str(4, i),
        "name": f"perception/model_{i}",
        "version": f"1.0.{i}",
        "description": f"Model architecture {i}",
        "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
        "props": {"version": f"1.0.{i}", "backbone": f"resnet{50 + i}"},
    } for i in range(architectures_count)]

    response = client.post(f"{internal_router.prefix}/architectures/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    benchmarks_count = 20

    request_data = [{
        "uuid": generate_dummy_uuid_str(5, i),
        "name": f"benchmark/spec_{i}",
        "version": f"1.0.{i}",
        "description": f"Test benchmark {i}",
        "supported_architecture_uuids": [generate_dummy_uuid_str(4, i)],
        "benchmark_schema": {"type": "object"},
        "props": {},
    } for i in range(benchmarks_count)]

    response = client.post(f"{internal_router.prefix}/benchmarks/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    experiments_count = 100

    request_data = [{
        "uuid": generate_dummy_uuid_str(11, i),
        "parent_uuid": generate_dummy_uuid_str(11, i - 1) if i > 0 else None,
        "architecture_uuid": generate_dummy_uuid_str(4, i % architectures_count),
        "dataset_uuid": generate_dummy_uuid_str(7, i % registrations_count),
        "name": f"dummy_model_{i}",
        "description": "A dummy model",
        "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
        "path": f"pulse/demeter/models/experiment_{i}",
        "checkpoint_path": f"epoch_{i}/model.pth",
        "tags": ["model:bev_perception", "framework:pytorch", "architecture:resnet50"],
        "props": {"version": f"1.0.{i}"},
    } for i in range(experiments_count)]

    response = client.post(f"{internal_router.prefix}/experiments/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    evaluations_count = 100

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_model_evaluation/",
                                   json={
                                       "uuid": generate_dummy_uuid_str(14, i),
                                       "props": {},
                                       "assessment": {
                                           "uuid": generate_dummy_uuid_str(13, i),
                                           "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
                                           "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
                                           "dataset_uuid": generate_dummy_uuid_str(7, i % registrations_count),
                                           "name": f"model_assessment_{i}",
                                           "description": f"Model assessment {i}",
                                           "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                           "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
                                           "assessment_data": {"version": f"1.0.{i}", "metric": "mAP"},
                                           "tags": ["benchmark:standard", "scope:full"],
                                           "props": {},
                                       },
                                   })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_model_evaluation/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(14, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        request_data = {
            "uuid": generate_dummy_uuid_str(13, i),
            "benchmark_uuid": generate_dummy_uuid_str(5, i % benchmarks_count),
            "experiment_uuid": generate_dummy_uuid_str(11, i % experiments_count),
            "dataset_uuid": generate_dummy_uuid_str(7, i % registrations_count),
            "name": f"model_assessment_{i}" if i % 2 == 0 else f"another_model_assessment_{i}",
            "description": f"Model assessment {i}",
            "contributor_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
            "path": f"pulse/demeter/assessments/assessment_{i}/results.json",
            "assessment_data": {"version": f"1.0.{i}", "metric": "mAP"},
            "tags": ["benchmark:standard", "scope:full"],
            "props": {},
        }

        response = client.put(f"{internal_router.prefix}/assessment/{i + 1}",
                              json=request_data,
                              params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
            response = client.post(f"{workflow_router.prefix}/submit_assessment_promotion/",
                                   params={
                                       "uuid": generate_dummy_uuid_str(17, i),
                                       "assessment_uuid": generate_dummy_uuid_str(13, i),
                                       "reviewer_sso_sid": 1234567890 if i % 2 == 0 else 9876543210,
                                   })
        assert response.status_code == 200, response.text

    for i in range(evaluations_count):
        with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
            response = client.put(f"{workflow_router.prefix}/mark_assessment_promotion/",
                                  params={
                                      "uuid": generate_dummy_uuid_str(17, i),
                                      "flags": Flag.terminal_states()[i % len(Flag.terminal_states())].value,
                                  })
        assert response.status_code == 200, response.text

    response_expect = {
        "samples_counts_by_layouts": [
            {
                "layout": {
                    "sqn": i + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(1, i),
                    "name": f"multi_camera/layout_{i}",
                    "description": f"Multi camera layout {i}",
                    "child_layout_uuids": [],
                    "layout_spec": {
                        "type": "object",
                        "properties": {
                            "camera_type": {"type": "string"},
                            "resolution": {"type": "string"},
                        },
                    },
                    "props": {"camera_count": i + 1},
                },
                "count": 200,
            }
            for i in range(layouts_count)
        ],
        "experiments_counts_by_architectures": [
            {
                "architecture": {
                    "sqn": i + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(4, i),
                    "name": f"perception/model_{i}",
                    "version": f"1.0.{i}",
                    "description": f"Model architecture {i}",
                    "supported_guideline_uuids": [generate_dummy_uuid_str(3, i)],
                    "props": {
                        "version": f"1.0.{i}",
                        "backbone": f"resnet{50 + i}",
                    },
                },
                "count": 5,
            }
            for i in range(architectures_count)
        ],
        "assessments_counts_by_benchmarks": [
            {
                "benchmark": {
                    "sqn": i + 1,
                    "created_at": "2020-01-01T00:00:00.000000+00:00",
                    "updated_at": "2020-01-01T00:00:00.000000+00:00",
                    "expired_at": None,
                    "record_sqn": i + 1,
                    "revision": 1,
                    "uuid": generate_dummy_uuid_str(5, i),
                    "name": f"benchmark/spec_{i}",
                    "version": f"1.0.{i}",
                    "description": f"Test benchmark {i}",
                    "supported_architecture_uuids": [generate_dummy_uuid_str(4, i % architectures_count)],
                    "benchmark_schema": {"type": "object"},
                    "props": {},
                },
                "count": 5,
            }
            for i in range(benchmarks_count)
        ],
        "samples_counts_by_layouts_for_annotation": [],
        "samples_counts_by_layouts_for_evaluation": [],
    }

    response = client.get(f"{public_router.prefix}/dashboard/")
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_get_tagset():
    for predefined_tagset in predefined_tagsets().values():
        response_expect = {
            "namespace": predefined_tagset.namespace,
            "tags": [tag.name for tag in predefined_tagset],
        }

        response = client.get(f"{public_router.prefix}/get_tagset/",
                              params={"namespace": predefined_tagset.namespace})
        assert response.status_code == 200, response.text

        response_data = response.json()
        assert case_insensitive_json_compare(response_data, response_expect)
