# Plexus Pulse Demeter - Data Management

![Codecov](https://img.shields.io/codecov/c/github/ruyangshou/plexus-python-pulse-demeter?token=jCdqTpopDw&style=for-the-badge)

## Deployment

### Alembic Migrations

```shell
# Prepare environment
python3 -m venv .venv
source .venv/bin/activate

pip install alembic

# Install Plexus Pulse Demeter to access its models
pip install plexus-pulse-demeter/[all]

cd alembic

export PULSE_DEMETER_DATABASE_HOST="<your_database_host>"
export PULSE_DEMETER_DATABASE_PORT="<your_database_port>"
export PULSE_DEMETER_DATABASE_USERNAME="<your_database_username>"
export PULSE_DEMETER_DATABASE_PASSWORD="<your_database_password>"
export PULSE_DEMETER_DATABASE_DATABASE="<your_database_database>"

# (Only if you don't have alembic files) Create alembic scaffold
alembic init alembic

# Create a migration (autogenerate uses models configured in env.py)
alembic revision --autogenerate -m "describe changes"

# Apply migrations
alembic upgrade head

# Check status / history
alembic current
alembic history --verbose

# Revert one revision
alembic downgrade -1
```

### Docker

```shell
# Build Docker images for Plexus Pulse Demeter
docker build -t ruyangshou/plexus-pulse-demeter-app:latest -f docker/plexus-pulse-demeter-app.dockerfile .

# Push images to Docker Hub
# You can change the repository to your own Docker Hub repository,
# remember update Kubernetes manifests accordingly
docker push ruyangshou/plexus-pulse-demeter-app:latest
```

### Kubernetes

```shell
# Configure kubectl to connect to your Kubernetes cluster
kubectl config use-context "<your-cluster-context>"

# Create a namespace for Plexus Pulse
kubectl create namespace plexus-pulse

# Generate secrets for Docker registry (if needed) and database connections
# Replace placeholders with actual values
kubectl create secret docker-registry plexus-registry-secrets \
    --docker-server="<your_registry_server>" \
    --docker-username="<your_username>" \
    --docker-password="<your_password>" \
    --docker-email="<your_email>" \
    -n plexus-pulse

kubectl create secret generic plexus-pulse-demeter-secrets \
    --from-literal PULSE_DEMETER_DATABASE_HOST="<your_database_host>" \
    --from-literal PULSE_DEMETER_DATABASE_PORT="<your_database_port>" \
    --from-literal PULSE_DEMETER_DATABASE_USERNAME="<your_database_username>" \
    --from-literal PULSE_DEMETER_DATABASE_PASSWORD="<your_database_password>" \
    --from-literal PULSE_DEMETER_DATABASE_DATABASE="<your_database_database>" \
    -n plexus-pulse

# Apply Kubernetes manifests for Plexus Pulse components
kubectl apply -f k8s/deployment/plexus-pulse-demeter-app.deployment.yaml -n plexus-pulse
```
