"""Core utilities for Velum."""
