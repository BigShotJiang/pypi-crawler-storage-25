"""Velum — Local PII redaction tool."""

__version__ = "0.1.0"
