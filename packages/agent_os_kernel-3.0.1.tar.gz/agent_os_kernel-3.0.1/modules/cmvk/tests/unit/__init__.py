"""Unit tests for CMVK."""
