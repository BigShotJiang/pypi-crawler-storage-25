# ── Build ulogger-cloud distribution (Windows / PowerShell) ────────────────
# Requires: Docker Desktop
#
# ulogger-cloud is pure Python, so a single build produces a py3-none-any
# wheel that works on every Python version, OS, and CPU architecture.
#
# The version is derived from the nearest git tag (e.g. v1.2.3 → 1.2.3).
# If no tag is found it falls back to 0.0.0.dev0.
#
# Usage:
#   .\scripts\build_all.ps1
#
# Artefacts are written to .\dist\ on the host.

$ErrorActionPreference = 'Stop'

$RootDir = (Resolve-Path "$PSScriptRoot\..").Path
$DistDir = Join-Path $RootDir 'dist'

New-Item -ItemType Directory -Force -Path $DistDir | Out-Null

# ── Resolve version from git tag ─────────────────────────────────────────────
try {
    $raw = git -C $RootDir describe --tags --long 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $raw) { throw }
    # v1.2.3-0-gabcdef  → 1.2.3
    # v1.2.3-4-gabcdef  → 1.2.3.dev4
    $Version = $raw -replace '^v',''
    $Version = $Version -replace '-([0-9]+)-g[0-9a-f]+$','.dev$1'
    $Version = $Version -replace '\.dev0$',''
} catch {
    $Version = '0.0.0.dev0'
}

Write-Host ('=' * 60)
Write-Host ' ulogger-cloud Docker build'
Write-Host " Version : $Version"
Write-Host " Output  : $DistDir"
Write-Host ('=' * 60)

docker build `
    --build-arg "VERSION=$Version" `
    --tag ulogger-cloud-build `
    $RootDir

# Convert to forward-slash path for Docker volume mount
$dockerDistDir = $DistDir -replace '\\', '/'

docker run --rm `
    -v "${dockerDistDir}:/dist" `
    ulogger-cloud-build

Write-Host ""
Write-Host ('=' * 60)
Write-Host ' Build complete. Artefacts:'
Get-ChildItem $DistDir -Include '*.whl','*.tar.gz' -Recurse | Format-Table Name, Length -AutoSize
Write-Host ('=' * 60)
