#!/usr/bin/env bash
# ── Build ulogger-cloud distribution ───────────────────────────────────────
# Requires: Docker
#
# ulogger-cloud is pure Python, so a single build produces a py3-none-any
# wheel that works on every Python version, OS, and CPU architecture.
#
# The version is derived from the nearest git tag (e.g. v1.2.3 → 1.2.3).
# If no tag is found it falls back to 0.0.0.dev0.
#
# Usage:
#   ./scripts/build_all.sh
#
# Artefacts are written to ./dist/ on the host.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
DIST_DIR="${ROOT_DIR}/dist"

mkdir -p "${DIST_DIR}"

# ── Resolve version from git tag ─────────────────────────────────────────────
if git -C "${ROOT_DIR}" describe --tags --long > /dev/null 2>&1; then
    # setuptools-scm format: strip leading 'v', keep dev/commit info
    VERSION=$(git -C "${ROOT_DIR}" describe --tags --long | sed 's/^v//' | \
              sed 's/\-\([0-9]*\)\-g[0-9a-f]*$/\.dev\1/' | sed 's/\.dev0$//')
else
    VERSION="0.0.0.dev0"
fi

echo "============================================================"
echo " ulogger-cloud Docker build"
echo " Version : ${VERSION}"
echo " Output  : ${DIST_DIR}"
echo "============================================================"

docker build \
    --build-arg "VERSION=${VERSION}" \
    --tag ulogger-cloud-build \
    "${ROOT_DIR}"

docker run --rm \
    -v "${DIST_DIR}:/dist" \
    ulogger-cloud-build

echo ""
echo "============================================================"
echo " Build complete. Artefacts:"
ls -lh "${DIST_DIR}"
echo "============================================================"
