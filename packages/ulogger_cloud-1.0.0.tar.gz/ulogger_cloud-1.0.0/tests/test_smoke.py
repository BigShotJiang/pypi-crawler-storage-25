"""Smoke-tests – verify the package is importable and its public API is intact."""

import importlib

import ulogger_cloud


def test_package_importable():
    assert importlib.import_module("ulogger_cloud") is not None


def test_public_api():
    expected = [
        "DeviceInfo",
        "MqttConfig",
        "SessionStore",
        "DEFAULT_FILE_STORE_PATH",
        "get_default_store",
        "get_or_fetch_token",
        "upload_log",
        "HEADER_SIZE",
        "get_session_token",
        "patch_session_token",
        "publish_binary_log",
        "validate_checksum",
    ]
    for name in expected:
        assert hasattr(ulogger_cloud, name), f"Missing public symbol: {name}"
