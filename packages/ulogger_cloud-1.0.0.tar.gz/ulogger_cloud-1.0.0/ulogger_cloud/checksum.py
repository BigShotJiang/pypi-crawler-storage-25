"""Header checksum validation and session-token patching.

Header layout (13 bytes, packed)::

    Byte  0    : version         (u8)
    Bytes 1-4  : session_token   (u32 little-endian)
    Bytes 5-8  : sequence_number (u32 little-endian)
    Bytes 9-10 : used_bytes      (u16 little-endian)
    Bytes 11-12: checksum        (u16 little-endian)  <- XOR of buffer data bytes
"""

from __future__ import annotations  # allows X | Y union syntax on Python 3.9

import logging
import struct

_log = logging.getLogger(__name__)
_log.setLevel(logging.ERROR)

HEADER_SIZE = 13


def validate_checksum(buf: bytes | bytearray) -> bool:
    """Parse the buffer header and verify the data checksum.

    The firmware computes a 16-bit checksum as the XOR of every byte in its
    circular buffer.  Unused bytes are zero-initialised, so the effective
    checksum equals the XOR of the *used* data bytes that follow the header.

    Returns ``True`` if the checksum is valid, ``False`` otherwise.
    """
    if len(buf) < HEADER_SIZE:
        _log.error("Buffer too short for header (%d < %d bytes)", len(buf), HEADER_SIZE)
        return False

    used_bytes = struct.unpack_from("<H", buf, 9)[0]
    expected_checksum = struct.unpack_from("<H", buf, 11)[0]

    data_start = HEADER_SIZE
    data_end = data_start + used_bytes

    if data_end > len(buf):
        _log.error(
            "Buffer truncated: header reports %d data bytes but only %d bytes are present",
            used_bytes, len(buf) - HEADER_SIZE,
        )
        return False

    computed = 0
    for b in buf[data_start:data_end]:
        computed ^= b

    if computed != expected_checksum:
        _log.error(
            "Checksum mismatch: computed=0x%04X  expected=0x%04X",
            computed, expected_checksum,
        )
        return False

    _log.info("Checksum OK (0x%04X, %d data bytes)", expected_checksum, used_bytes)
    return True


def patch_session_token(buf: bytearray, token: int) -> None:
    """Write the session token into bytes 1-4 of the buffer header (little-endian u32)."""
    struct.pack_into("<I", buf, 1, token & 0xFFFFFFFF)
    _log.info("Session token 0x%08X patched into header", token)
