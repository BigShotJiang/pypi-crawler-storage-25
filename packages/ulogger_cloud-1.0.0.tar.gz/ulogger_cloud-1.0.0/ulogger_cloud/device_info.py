"""Device identification data shared between BLE and cloud layers."""

from dataclasses import dataclass


@dataclass
class DeviceInfo:
    """Identification payload read from the firmware config characteristic.

    Payload layout written by firmware::

        Byte 0-3 : application_id  (uint32 little-endian)
        Byte 4+  : device_serial\\0 device_type\\0 git_version\\0 git_hash\\0
    """

    application_id: int
    device_serial: str
    device_type: str
    git_version: str
    git_hash: str

    def __str__(self) -> str:
        return (
            f"application_id={self.application_id}  "
            f"device_serial={self.device_serial!r}  "
            f"device_type={self.device_type!r}  "
            f"git_version={self.git_version!r}  "
            f"git_hash={self.git_hash!r}"
        )
