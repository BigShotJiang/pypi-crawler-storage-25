"""ulogger-cloud – MQTT session management, binary-log upload, and checksum validation."""

try:
    from ._version import __version__  # written by setuptools-scm at build time
except ImportError:
    # Package is being used directly from source without having been built.
    __version__ = "0.0.0.dev0"

from .device_info import DeviceInfo
from .checksum import HEADER_SIZE, validate_checksum, patch_session_token
from .mqtt import MqttConfig, get_session_token, publish_binary_log, publish_core_dump
from .session_store import SessionStore, get_default_store, DEFAULT_FILE_STORE_PATH
from .api import get_or_fetch_token, upload_log

__all__ = [
    "__version__",
    # Data types
    "DeviceInfo",
    "MqttConfig",
    "SessionStore",
    # Token & upload helpers
    "DEFAULT_FILE_STORE_PATH",
    "get_default_store",
    "get_or_fetch_token",
    "upload_log",
    # Lower-level building blocks
    "HEADER_SIZE",
    "get_session_token",
    "patch_session_token",
    "publish_binary_log",
    "publish_core_dump",
    "validate_checksum",
]
