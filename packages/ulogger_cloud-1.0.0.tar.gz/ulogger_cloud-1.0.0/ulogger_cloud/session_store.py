"""Mapping of device serial numbers to session tokens.

By default the store lives entirely in memory using an ordered dictionary – no
disk I/O, no external dependencies.  File persistence is opt-in: pass a
``path`` to :class:`SessionStore` and the store will load from that file on
construction and write atomically on every mutation.

Token invalidation
------------------
Each entry records the ``git_hash`` of the firmware version for which the token
was issued.  If a device is upgraded (new ``git_hash``), the old entry is
evicted and a fresh MQTT boot registration is triggered automatically.

Only one token is ever stored per serial number.  Setting a token for an
existing serial – whether the ``git_hash`` matches or not – always replaces
the previous entry.

Memory cap
----------
Pass ``max_entries`` to bound how many tokens may be held at once.  When the
limit is reached, the *least-recently-used* entry is evicted to make room.

File layout (JSON, only used when *path* is supplied)::

    {
      "<serial>": {
        "token":    <uint32>,
        "git_hash": "<hex string>"
      },
      ...
    }

Convenience constant for file-backed stores::

    from ulogger_cloud import SessionStore, DEFAULT_FILE_STORE_PATH
    store = SessionStore(path=DEFAULT_FILE_STORE_PATH)
"""

import json
import logging
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Optional

# Convenience path users can pass when they want file persistence.
DEFAULT_FILE_STORE_PATH = Path.home() / ".ulogger" / "session_tokens.json"

_log = logging.getLogger(__name__)
_log.setLevel(logging.ERROR)


class SessionStore:
    """Thread-safe store for serial-number → session-token mappings.

    The default mode is **in-memory only** – tokens are kept for the lifetime
    of the process and never written to disk.

    To enable file persistence, pass an explicit *path*::

        # In-memory (default)
        store = SessionStore()

        # File-backed
        from ulogger_cloud import DEFAULT_FILE_STORE_PATH
        store = SessionStore(path=DEFAULT_FILE_STORE_PATH)

        # Memory-capped (keeps the 1 000 most-recently-used tokens)
        store = SessionStore(max_entries=1000)

    Args:
        path:        Optional path to a JSON backing file.  When ``None``
                     (the default) the store is in-memory only.
        max_entries: Maximum number of tokens to hold in memory.  When the
                     limit is reached, the least-recently-used entry is
                     evicted.  ``None`` (default) means unlimited.

    Example::

        store = SessionStore()

        # Look up a cached token (returns None if missing or version changed)
        token = store.get_token(serial="ABC123", git_hash="abcdef0")

        # Store a freshly-issued token
        store.set_token(serial="ABC123", git_hash="abcdef0", token=0xDEADBEEF)
    """

    def __init__(
        self,
        path: Optional[Path] = None,
        max_entries: Optional[int] = None,
    ) -> None:
        if max_entries is not None and max_entries < 1:
            raise ValueError("max_entries must be >= 1 or None")
        self.path = Path(path) if path is not None else None
        self.max_entries = max_entries
        self._lock = threading.Lock()
        # OrderedDict preserves insertion/access order for LRU eviction.
        # Layout: { serial: {"token": int, "git_hash": str} }
        self._data: OrderedDict[str, dict] = OrderedDict()
        if self.path is not None:
            self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_token(self, serial: str, git_hash: str) -> Optional[int]:
        """Return the cached token for *serial* if the firmware version matches.

        A cache hit moves the entry to the *most-recently-used* position so
        that it is the last candidate for LRU eviction.

        Returns ``None`` when:
        * the serial has never been registered, or
        * the stored ``git_hash`` differs from *git_hash* (firmware upgrade).
        """
        with self._lock:
            entry = self._data.get(serial)
            if entry is not None:
                # Mark as most-recently used.
                self._data.move_to_end(serial)
        if entry is None:
            return None
        if entry.get("git_hash") != git_hash:
            _log.warning(
                "Version change detected for %r (stored=%r, current=%r) – will re-register with server",
                serial, entry.get("git_hash"), git_hash,
            )
            return None
        return entry["token"]

    def set_token(self, serial: str, git_hash: str, token: int) -> None:
        """Store a token for *serial* at firmware version *git_hash*.

        Any previous entry for *serial* is replaced, regardless of its
        ``git_hash``.  The new entry is placed at the *most-recently-used*
        position.  If *max_entries* is set and the store is full, the
        least-recently-used entry is evicted first.
        """
        with self._lock:
            # Remove any stale entry for this serial before inserting so that
            # the new one always lands at the MRU end.
            self._data.pop(serial, None)
            # Evict the LRU entry if we are at capacity.
            if self.max_entries is not None and len(self._data) >= self.max_entries:
                evicted_serial, _ = self._data.popitem(last=False)
                _log.info("Evicted LRU token for serial=%r (max_entries=%d)",
                          evicted_serial, self.max_entries)
            self._data[serial] = {"token": token, "git_hash": git_hash}
            if self.path is not None:
                self._save_locked()
        _log.info("Token 0x%08X stored for serial=%r git_hash=%r", token, serial, git_hash)

    def remove(self, serial: str) -> None:
        """Remove the entry for *serial* (e.g. to force re-registration)."""
        with self._lock:
            if serial in self._data:
                del self._data[serial]
                if self.path is not None:
                    self._save_locked()

    def clear(self) -> None:
        """Remove all stored tokens."""
        with self._lock:
            self._data.clear()
            if self.path is not None:
                self._save_locked()

    def __len__(self) -> int:
        with self._lock:
            return len(self._data)

    def __repr__(self) -> str:
        backend = f"file={self.path!r}" if self.path is not None else "in-memory"
        cap = f", max_entries={self.max_entries}" if self.max_entries is not None else ""
        return f"SessionStore({backend}, entries={len(self)}{cap})"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load entries from the backing file.  No-op when path is None."""
        assert self.path is not None
        if not self.path.exists():
            return
        try:
            with self.path.open("r", encoding="utf-8") as fh:
                loaded = json.load(fh)
            if isinstance(loaded, dict):
                self._data = OrderedDict(loaded)
                _log.info("Loaded %d token(s) from %s", len(self._data), self.path)
            else:
                _log.warning("Session store at %s has unexpected format – ignoring", self.path)
        except Exception as exc:
            _log.warning("Could not load session store from %s: %s", self.path, exc)

    def _save_locked(self) -> None:
        """Atomically write the store to disk.  Must be called with lock held."""
        assert self.path is not None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            with tmp.open("w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=2)
            tmp.replace(self.path)
        except Exception as exc:
            _log.warning("Could not save session store to %s: %s", self.path, exc)


# Module-level default instance – shared across the process unless overridden.
_default_store: Optional[SessionStore] = None
_default_store_lock = threading.Lock()


def get_default_store() -> SessionStore:
    """Return (creating on first call) the process-wide default :class:`SessionStore`.

    The default store is **in-memory only**.  To share a file-backed store
    across the process, create one explicitly and pass it to each call instead
    of relying on this function.
    """
    global _default_store
    if _default_store is None:
        with _default_store_lock:
            if _default_store is None:
                _default_store = SessionStore()  # in-memory, no path
    return _default_store
