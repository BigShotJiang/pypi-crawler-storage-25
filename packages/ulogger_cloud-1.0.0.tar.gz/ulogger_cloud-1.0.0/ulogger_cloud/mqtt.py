"""MQTT helpers – session-token retrieval and binary-log publish."""

import json
import logging
import random
import ssl
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import paho.mqtt.client as mqtt

from .device_info import DeviceInfo

_log = logging.getLogger(__name__)
_log.setLevel(logging.ERROR)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class MqttConfig:
    """Connection parameters for the uLogger MQTT broker."""

    broker: str = "mqtt.ulogger.ai"
    port: int = 8883
    cert_file: Optional[Path] = None
    key_file: Optional[Path] = None
    customer_id: int = 0
    token_timeout: float = 15.0  # seconds to wait for session token


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _configure_tls(mqttc: mqtt.Client, cfg: MqttConfig) -> None:
    """Apply TLS settings to *mqttc* when certificate files are present."""
    if cfg.cert_file and cfg.key_file and cfg.cert_file.exists() and cfg.key_file.exists():
        mqttc.tls_set(
            ca_certs=None,
            certfile=str(cfg.cert_file),
            keyfile=str(cfg.key_file),
            tls_version=ssl.PROTOCOL_TLSv1_2,
        )
    else:
        cert = cfg.cert_file or "(not set)"
        key = cfg.key_file or "(not set)"
        _log.warning("MQTT certificates not found at %s / %s", cert, key)
        _log.warning("Connecting without TLS – for development only")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_session_token(
    device_info: DeviceInfo,
    cfg: MqttConfig,
) -> Optional[int]:
    """Register the device via MQTT and retrieve the session token from the server.

    Workflow:
      1. Subscribe to  ``boot/v0/{customer_id}/{app_id}/{serial}``
      2. Publish boot registration JSON to ``boot/v0/{customer_id}/{app_id}``
      3. Wait for the server to deliver ``{"token": <uint32>}``

    Returns the parsed token (``int``) or ``None`` on failure / timeout.
    """
    app_id = device_info.application_id
    serial = device_info.device_serial
    pub_topic = f"boot/v0/{cfg.customer_id}/{app_id}"
    sub_topic = f"boot/v0/{cfg.customer_id}/{app_id}/{serial}"
    boot_payload = json.dumps({
        "device_type": device_info.device_type,
        "git": device_info.git_hash,
        "serial": serial,
        "version": device_info.git_version,
    })

    token_event = threading.Event()
    token_holder: list[Optional[int]] = [None]

    def _on_connect(client, userdata, flags, rc, *args):
        if rc == 0:
            _log.info("Connected to %s", cfg.broker)
            client.subscribe(sub_topic, qos=1)
        else:
            _log.error("Connection refused (rc=%d)", rc)

    def _on_subscribe(client, userdata, mid, granted_qos, *args):
        _log.info("Subscribed to %s", sub_topic)
        result, _ = client.publish(pub_topic, boot_payload, qos=1)
        if result == mqtt.MQTT_ERR_SUCCESS:
            _log.info("Boot registration sent to %s: %s", pub_topic, boot_payload)
        else:
            _log.error("Boot publish failed (rc=%d)", result)

    def _on_message(client, userdata, msg, *args):
        try:
            payload_str = msg.payload.decode("utf-8")
            _log.debug("Message on %s: %s", msg.topic, payload_str)
            data = json.loads(payload_str)
            if "token" in data:
                token_holder[0] = int(data["token"])
                _log.info("Session token received: %d", token_holder[0])
                token_event.set()
        except Exception as exc:
            _log.error("Failed to parse token message: %s", exc)

    def _on_disconnect(client, userdata, rc, *args):
        _log.info("Disconnected (rc=%d)", rc)

    client_id = f"cust-{cfg.customer_id}-{serial}-{random.randint(0, 4294967295)}"
    mqttc = mqtt.Client(client_id=client_id)
    mqttc.on_connect = _on_connect
    mqttc.on_subscribe = _on_subscribe
    mqttc.on_message = _on_message
    mqttc.on_disconnect = _on_disconnect
    mqttc.enable_logger(logging.getLogger("mqtt.session"))

    _configure_tls(mqttc, cfg)

    try:
        mqttc.connect(cfg.broker, port=cfg.port)
    except Exception as exc:
        _log.error("Connection failed: %s", exc)
        return None

    mqttc.loop_start()
    received = token_event.wait(timeout=cfg.token_timeout)
    mqttc.loop_stop()
    mqttc.disconnect()

    if not received:
        _log.warning("Timed out waiting %.1f s for session token", cfg.token_timeout)
        return None

    return token_holder[0]


def publish_binary_log(
    device_info: DeviceInfo,
    payload: bytes,
    cfg: MqttConfig,
) -> bool:
    """Publish the binary log buffer to ``binlog/v0/{customer_id}/{app_id}``.

    Returns ``True`` on success, ``False`` otherwise.
    """
    topic = f"binlog/v0/{cfg.customer_id}/{device_info.application_id}"
    serial = device_info.device_serial

    connected_event = threading.Event()
    published_event = threading.Event()
    success_holder = [False]

    def _on_connect(client, userdata, flags, rc, *args):
        if rc == 0:
            connected_event.set()
        else:
            _log.error("binlog connection refused (rc=%d)", rc)

    def _on_publish(client, userdata, mid, *args):
        success_holder[0] = True
        published_event.set()

    def _on_disconnect(client, userdata, rc, *args):
        _log.info("binlog disconnected (rc=%d)", rc)

    client_id = f"cust-{cfg.customer_id}-{serial}-{random.randint(0, 9999)}"
    mqttc = mqtt.Client(client_id=client_id)
    mqttc.on_connect = _on_connect
    mqttc.on_publish = _on_publish
    mqttc.on_disconnect = _on_disconnect
    mqttc.enable_logger(logging.getLogger("mqtt.binlog"))

    _configure_tls(mqttc, cfg)

    try:
        mqttc.connect(cfg.broker, port=cfg.port)
    except Exception as exc:
        _log.error("binlog connection failed: %s", exc)
        return False

    mqttc.loop_start()

    if not connected_event.wait(timeout=10.0):
        _log.warning("Timed out waiting for binlog broker connection")
        mqttc.loop_stop()
        mqttc.disconnect()
        return False

    result, _ = mqttc.publish(topic, payload, qos=1)
    if result != mqtt.MQTT_ERR_SUCCESS:
        _log.error("binlog publish enqueue failed (rc=%d)", result)
        mqttc.loop_stop()
        mqttc.disconnect()
        return False

    _log.info("Publishing %d bytes to %s...", len(payload), topic)
    published_event.wait(timeout=10.0)
    mqttc.loop_stop()
    mqttc.disconnect()

    if success_holder[0]:
        _log.info("Binary log published successfully")
    else:
        _log.warning("PUBACK not received within timeout")
    return success_holder[0]


def publish_core_dump(
    payload: bytes,
    cfg: MqttConfig,
) -> bool:
    """Publish a raw core dump buffer to ``core-dump/v0/{customer_id}``.

    Returns ``True`` on success, ``False`` otherwise.
    """
    topic = f"core-dump/v0/{cfg.customer_id}"

    connected_event = threading.Event()
    published_event = threading.Event()
    success_holder = [False]

    def _on_connect(client, userdata, flags, rc, *args):
        if rc == 0:
            connected_event.set()
        else:
            _log.error("core-dump connection refused (rc=%d)", rc)

    def _on_publish(client, userdata, mid, *args):
        success_holder[0] = True
        published_event.set()

    def _on_disconnect(client, userdata, rc, *args):
        _log.info("core-dump disconnected (rc=%d)", rc)

    client_id = f"cust-{cfg.customer_id}-cd-{random.randint(0, 9999)}"
    mqttc = mqtt.Client(client_id=client_id)
    mqttc.on_connect = _on_connect
    mqttc.on_publish = _on_publish
    mqttc.on_disconnect = _on_disconnect
    mqttc.enable_logger(logging.getLogger("mqtt.coredump"))

    _configure_tls(mqttc, cfg)

    try:
        mqttc.connect(cfg.broker, port=cfg.port)
    except Exception as exc:
        _log.error("core-dump connection failed: %s", exc)
        return False

    mqttc.loop_start()

    if not connected_event.wait(timeout=10.0):
        _log.warning("Timed out waiting for core-dump broker connection")
        mqttc.loop_stop()
        mqttc.disconnect()
        return False

    result, _ = mqttc.publish(topic, payload, qos=1)
    if result != mqtt.MQTT_ERR_SUCCESS:
        _log.error("core-dump publish enqueue failed (rc=%d)", result)
        mqttc.loop_stop()
        mqttc.disconnect()
        return False

    _log.info("Publishing %d bytes to %s...", len(payload), topic)
    published_event.wait(timeout=10.0)
    mqttc.loop_stop()
    mqttc.disconnect()

    if success_holder[0]:
        _log.info("Core dump published successfully")
    else:
        _log.warning("PUBACK not received within timeout")
    return success_holder[0]
