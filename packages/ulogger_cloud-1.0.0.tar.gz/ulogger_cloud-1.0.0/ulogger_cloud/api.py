"""High-level API: validate, register, and upload a binary log in one call."""

import logging
from typing import Optional

from .checksum import validate_checksum, patch_session_token
from .device_info import DeviceInfo
from .mqtt import MqttConfig, get_session_token, publish_binary_log
from .session_store import SessionStore, get_default_store

_log = logging.getLogger(__name__)
_log.setLevel(logging.ERROR)


def get_or_fetch_token(
    device_info: DeviceInfo,
    cfg: MqttConfig,
    store: Optional[SessionStore] = None,
) -> Optional[int]:
    """Return a valid session token for *device_info*, fetching one if needed.

    The function first checks the :class:`~ulogger_cloud.SessionStore` for a
    cached token that was issued for the same firmware version
    (``git_hash``). If the entry is missing or the firmware has been upgraded,
    a fresh MQTT boot registration is performed and the new token is
    persisted in the store.

    Args:
        device_info: Identification data read from the device.
        cfg:         MQTT connection configuration.
        store:       Token store to use.  Defaults to the process-wide store
                     at ``~/.ulogger/session_tokens.json``.

    Returns:
        The session token as an ``int``, or ``None`` if registration failed.
    """
    if store is None:
        store = get_default_store()

    serial   = device_info.device_serial
    git_hash = device_info.git_hash

    cached = store.get_token(serial, git_hash)
    if cached is not None:
        _log.info("Using cached session token 0x%08X for serial=%r", cached, serial)
        return cached

    _log.info("No valid cached token for serial=%r – performing boot registration...", serial)
    token = get_session_token(device_info, cfg)
    if token is not None:
        store.set_token(serial, git_hash, token)
    return token


def upload_log(
    device_info: Optional[DeviceInfo],
    buf: bytearray,
    cfg: MqttConfig,
    store: Optional[SessionStore] = None,
) -> bool:
    """Validate, patch, and publish *buf* to the uLogger cloud platform.

    Steps performed:
    1. Validate the header checksum (``validate_checksum``).
    2. Obtain a session token via :func:`get_or_fetch_token` (cached or MQTT).
    3. Patch the token into the buffer header.
    4. Publish the buffer to ``binlog/v0/{customer_id}/{app_id}`` via MQTT.

    Args:
        device_info: Identification data read from the device.  ``None`` is
                     accepted but will skip token registration and MQTT upload.
        buf:         Raw binary log buffer received over BLE.  The buffer is
                     modified in-place to embed the session token.
        cfg:         MQTT connection configuration.
        store:       Token store to use.  Defaults to the process-wide store.

    Returns:
        ``True`` if the binary log was published successfully, ``False`` otherwise.
    """
    if not validate_checksum(bytes(buf)):
        _log.error("Checksum validation failed – aborting upload.")
        return False

    if device_info is None:
        _log.warning("No device info – skipping session token and MQTT upload.")
        return False

    token = get_or_fetch_token(device_info, cfg, store)
    if token is not None:
        patch_session_token(buf, token)
    else:
        _log.warning("No session token obtained – header will contain token=0")

    return publish_binary_log(device_info, bytes(buf), cfg)
