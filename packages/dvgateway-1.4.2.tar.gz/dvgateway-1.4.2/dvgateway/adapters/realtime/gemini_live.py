"""
Google Gemini Live API — Speech-to-Speech Adapter

Drop-in alternative to OpenAIRealtimeAdapter. Same RealtimeSpeechAdapter
interface, same callbacks, same pipeline_type="s2s" dashboard integration.

Architecture:
  DVGateway audio in (16kHz PCM)
      ↓ (Gemini Live native input rate — no resampling)
  Gemini Live API (WebSocket, BidiGenerateContent)
      ↓ gemini-live-2.5-flash-preview processes end-to-end
  DVGateway audio out (24kHz → 16kHz downsample)

Supported endpoints:
- "ai-studio" (default): AI Studio global endpoint (API key auth)
- "vertex": Vertex AI regional endpoint (Bearer access token auth)

Audio format:
  Input:  PCM16 16kHz mono, base64, MIME "audio/pcm;rate=16000"
  Output: PCM16 24kHz mono, base64 (downsampled to 16kHz for DVGateway)

API Reference:
  https://ai.google.dev/gemini-api/docs/live-api
  https://ai.google.dev/api/live
"""

from __future__ import annotations

import asyncio
import base64
import json
import time
from dataclasses import dataclass
from typing import Any, AsyncIterable, Callable, Literal
from urllib.parse import quote

import websockets
import websockets.client

from dvgateway.audio.codec import float32_to_slin16, resample, slin16_to_float32
from dvgateway.types import AudioChunk, TranscriptResult

from dvgateway.adapters.realtime.openai_realtime import (
    RealtimeSpeechAdapter,
    RealtimeSpeechActivityEvent,
    RealtimeToolCall,
)

AI_STUDIO_URL = (
    "wss://generativelanguage.googleapis.com/ws/"
    "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
)
GEMINI_OUTPUT_SAMPLE_RATE = 24000
DV_SAMPLE_RATE = 16000
INPUT_CHUNK_MS = 20
INPUT_SAMPLES_16K = round(DV_SAMPLE_RATE * INPUT_CHUNK_MS / 1000)  # 320 samples

# Prebuilt voices available on half-cascade Gemini Live models.
# Native-audio models support the full Google Cloud TTS catalog.
GeminiLiveVoice = Literal[
    "Puck",     # Conversational, friendly (default)
    "Charon",   # Deep, authoritative
    "Kore",     # Neutral, professional
    "Fenrir",   # Warm, approachable
    "Aoede",    # Bright, energetic
    "Leda",     # Soft, calm
    "Orus",     # Resonant, mature
    "Zephyr",   # Light, airy
]

GeminiLiveModel = Literal[
    "gemini-live-2.5-flash-preview",        # Current preview, multimodal I/O
    "gemini-2.5-flash-native-audio",        # Native audio (replaces Sept 2025 preview)
    "gemini-2.0-flash-live-001",            # Legacy
]

GeminiLiveEndpoint = Literal["ai-studio", "vertex"]


@dataclass
class GeminiLiveTurnDetectionOptions:
    """Turn detection / VAD configuration for Gemini Live.

    mode="server_vad" (default): server-side VAD auto-detects boundaries.
    mode="none": client-side — set automaticActivityDetection.disabled and
    call send_activity_start() / send_activity_end() manually.
    """
    mode: Literal["server_vad", "none"] = "server_vad"
    start_sensitivity: Literal["LOW", "MEDIUM", "HIGH"] | None = None
    end_sensitivity: Literal["LOW", "MEDIUM", "HIGH"] | None = None
    prefix_padding_ms: int | None = None
    silence_duration_ms: int | None = None


@dataclass
class GeminiLiveTool:
    """Function/tool declaration (same schema as Gemini Generative API)."""
    name: str
    description: str = ""
    parameters: dict[str, object] | None = None


class GeminiLiveAdapter(RealtimeSpeechAdapter):
    """Google Gemini Live speech-to-speech adapter.

    Drop-in replacement for OpenAIRealtimeAdapter. Use the same S2S wiring
    (stream_audio(pipeline_type="s2s"), inject_tts, on_speech_activity →
    post_vad) — only the adapter import changes.

    Example::

        from dvgateway.adapters.realtime import GeminiLiveAdapter

        adapter = GeminiLiveAdapter(
            api_key=os.environ["GEMINI_API_KEY"],
            model="gemini-live-2.5-flash-preview",
            voice="Puck",
            language="ko-KR",
        )
    """

    def __init__(
        self,
        api_key: str = "",
        *,
        access_token: str = "",
        project: str = "",
        location: str = "",
        endpoint: GeminiLiveEndpoint = "ai-studio",
        model: GeminiLiveModel = "gemini-live-2.5-flash-preview",
        voice: GeminiLiveVoice = "Puck",
        instructions: str = "You are a helpful voice assistant. Keep answers concise and conversational.",
        turn_detection: GeminiLiveTurnDetectionOptions | dict[str, object] | None = None,
        input_transcription: bool = True,
        output_transcription: bool = True,
        language: str = "",
        temperature: float = 0.8,
        max_output_tokens: int | None = None,
        tools: list[GeminiLiveTool | dict[str, object]] | None = None,
    ) -> None:
        if endpoint == "ai-studio" and not api_key:
            raise ValueError('GeminiLiveAdapter: api_key is required when endpoint="ai-studio"')
        if endpoint == "vertex" and not (access_token and project and location):
            raise ValueError(
                'GeminiLiveAdapter: access_token, project, and location are required when endpoint="vertex"'
            )

        self._endpoint = endpoint
        self._api_key = api_key
        self._access_token = access_token
        self._project = project
        self._location = location
        self._model = model
        self._voice = voice
        self._instructions = instructions
        if isinstance(turn_detection, dict):
            self._turn_detection = GeminiLiveTurnDetectionOptions(**turn_detection)
        else:
            self._turn_detection = turn_detection or GeminiLiveTurnDetectionOptions()
        self._input_transcription = input_transcription
        self._output_transcription = output_transcription
        self._language = language
        self._temperature = temperature
        self._max_output_tokens = max_output_tokens

        # Normalize tool list
        self._tools: list[dict[str, object]] = []
        for t in (tools or []):
            if isinstance(t, dict):
                self._tools.append(t)
            else:
                td: dict[str, object] = {"name": t.name}
                if t.description:
                    td["description"] = t.description
                if t.parameters is not None:
                    td["parameters"] = t.parameters
                self._tools.append(td)

        self._audio_output_handler: Callable[[bytes, str], None] | None = None
        self._transcript_handler: Callable[[TranscriptResult], None] | None = None
        self._error_handler: Callable[[Exception, str | None], None] | None = None
        self._tool_call_handler: Callable[[RealtimeToolCall], None] | None = None
        self._speech_activity_handler: Callable[[RealtimeSpeechActivityEvent], None] | None = None

        self._sessions: dict[str, websockets.client.WebSocketClientProtocol] = {}  # type: ignore[type-arg]
        self._input_transcript_buf: dict[str, str] = {}
        self._output_transcript_buf: dict[str, str] = {}
        self._caller_speaking: dict[str, bool] = {}
        self._ws_lock = asyncio.Lock()
        self._stopped = False

    def on_audio_output(self, handler: Callable[[bytes, str], None]) -> None:
        self._audio_output_handler = handler

    def on_transcript(self, handler: Callable[[TranscriptResult], None]) -> None:
        self._transcript_handler = handler

    def on_error(self, handler: Callable[[Exception, str | None], None]) -> None:
        self._error_handler = handler

    def on_tool_call(self, handler: Callable[[RealtimeToolCall], None]) -> None:
        self._tool_call_handler = handler

    def on_speech_activity(
        self,
        handler: Callable[[RealtimeSpeechActivityEvent], None],
    ) -> None:
        """Register a handler for speech activity events.

        Gemini Live does NOT emit explicit speech_started/stopped events like
        OpenAI Realtime. This adapter approximates caller speech activity from:

        - ``serverContent.interrupted=True`` → caller barged in while AI was
          responding. Fires ``speaking=True``.
        - ``serverContent.turnComplete=True`` → turn boundary. Fires
          ``speaking=False`` if caller was marked speaking.

        For precise VAD, set ``turn_detection.mode="none"`` and call
        :meth:`send_activity_start` / :meth:`send_activity_end` manually.
        """
        self._speech_activity_handler = handler

    def submit_tool_result(self, linked_id: str, call_id: str, result: object) -> None:
        """Submit a tool-call result back to the model."""
        ws = self._sessions.get(linked_id)
        if not ws:
            return

        if isinstance(result, dict):
            response = result
        else:
            response = {"result": result}

        self._send_event(ws, {
            "tool_response": {
                "function_responses": [{
                    "id": call_id,
                    "name": "",
                    "response": response,
                }],
            },
        })

    def send_activity_start(self, linked_id: str) -> None:
        """Mark caller speech onset (manual VAD mode only).

        No-op unless ``turn_detection.mode == "none"``. Sends
        ``realtime_input.activity_start`` and fires on_speech_activity.
        """
        if self._turn_detection.mode != "none":
            return
        ws = self._sessions.get(linked_id)
        if not ws:
            return
        self._send_event(ws, {"realtime_input": {"activity_start": {}}})
        self._caller_speaking[linked_id] = True
        if self._speech_activity_handler:
            self._speech_activity_handler(RealtimeSpeechActivityEvent(
                linked_id=linked_id,
                side="caller",
                speaking=True,
                timestamp_ms=time.time() * 1000,
            ))

    def send_activity_end(self, linked_id: str) -> None:
        """Mark caller speech end (manual VAD mode only)."""
        if self._turn_detection.mode != "none":
            return
        ws = self._sessions.get(linked_id)
        if not ws:
            return
        self._send_event(ws, {"realtime_input": {"activity_end": {}}})
        self._caller_speaking[linked_id] = False
        if self._speech_activity_handler:
            self._speech_activity_handler(RealtimeSpeechActivityEvent(
                linked_id=linked_id,
                side="caller",
                speaking=False,
                timestamp_ms=time.time() * 1000,
            ))

    async def start_session(self, linked_id: str, audio_in: AsyncIterable[AudioChunk]) -> None:
        self._stopped = False
        ws = await self._connect_live(linked_id)
        self._sessions[linked_id] = ws
        self._input_transcript_buf[linked_id] = ""
        self._output_transcript_buf[linked_id] = ""
        self._caller_speaking[linked_id] = False

        # ── Build setup message ──
        setup: dict[str, object] = {
            "model": self._resolve_model_path(),
            "generation_config": {
                "response_modalities": ["AUDIO"],
                "speech_config": self._build_speech_config(),
                "temperature": self._temperature,
            },
            "system_instruction": {"parts": [{"text": self._instructions}]},
            "realtime_input_config": self._build_realtime_input_config(),
        }
        if self._max_output_tokens is not None:
            gen_cfg = setup["generation_config"]
            if isinstance(gen_cfg, dict):
                gen_cfg["max_output_tokens"] = self._max_output_tokens
        if self._input_transcription:
            setup["input_audio_transcription"] = {}
        if self._output_transcription:
            setup["output_audio_transcription"] = {}
        if self._tools:
            setup["tools"] = [{"function_declarations": self._tools}]

        self._send_event(ws, {"setup": setup})

        # Pipe audio in background (guarded for exception visibility)
        asyncio.ensure_future(self._pipe_audio_guarded(linked_id, ws, audio_in))

        # Read server messages
        try:
            async for message in ws:
                if self._stopped or linked_id not in self._sessions:
                    break
                try:
                    event = json.loads(message if isinstance(message, str) else message.decode("utf-8"))
                    self._handle_server_message(event, linked_id)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    pass
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self._sessions.pop(linked_id, None)
            self._input_transcript_buf.pop(linked_id, None)
            self._output_transcript_buf.pop(linked_id, None)
            self._caller_speaking.pop(linked_id, None)

    async def stop(self, linked_id: str | None = None) -> None:
        if linked_id:
            ws = self._sessions.pop(linked_id, None)
            if ws:
                await ws.close(1000, "session ended")
            self._input_transcript_buf.pop(linked_id, None)
            self._output_transcript_buf.pop(linked_id, None)
            self._caller_speaking.pop(linked_id, None)
        else:
            self._stopped = True
            for lid, ws in list(self._sessions.items()):
                await ws.close(1000, "adapter stopped")
            self._sessions.clear()
            self._input_transcript_buf.clear()
            self._output_transcript_buf.clear()
            self._caller_speaking.clear()

    # ── Private helpers ─────────────────────────────────────────────────────

    def _resolve_model_path(self) -> str:
        if self._endpoint == "vertex":
            return (
                f"projects/{self._project}/locations/{self._location}/"
                f"publishers/google/models/{self._model}"
            )
        return f"models/{self._model}"

    def _build_speech_config(self) -> dict[str, object]:
        cfg: dict[str, object] = {
            "voice_config": {"prebuilt_voice_config": {"voice_name": self._voice}},
        }
        if self._language:
            cfg["language_code"] = self._language
        return cfg

    def _build_realtime_input_config(self) -> dict[str, object]:
        td = self._turn_detection
        if td.mode == "none":
            return {"automatic_activity_detection": {"disabled": True}}
        vad: dict[str, object] = {"disabled": False}
        if td.start_sensitivity:
            vad["start_of_speech_sensitivity"] = f"START_SENSITIVITY_{td.start_sensitivity}"
        if td.end_sensitivity:
            vad["end_of_speech_sensitivity"] = f"END_SENSITIVITY_{td.end_sensitivity}"
        if td.prefix_padding_ms is not None:
            vad["prefix_padding_ms"] = td.prefix_padding_ms
        if td.silence_duration_ms is not None:
            vad["silence_duration_ms"] = td.silence_duration_ms
        return {"automatic_activity_detection": vad}

    async def _connect_live(self, linked_id: str) -> websockets.client.WebSocketClientProtocol:  # type: ignore[type-arg]
        if self._endpoint == "vertex":
            url = (
                f"wss://{self._location}-aiplatform.googleapis.com/ws/"
                "google.cloud.aiplatform.v1.LlmBidiService/BidiGenerateContent"
            )
            extra_headers = {"Authorization": f"Bearer {self._access_token}"}
        else:
            url = f"{AI_STUDIO_URL}?key={quote(self._api_key)}"
            extra_headers = {}

        ws = await websockets.client.connect(url, extra_headers=extra_headers)
        return ws

    async def _pipe_audio_guarded(
        self,
        linked_id: str,
        ws: websockets.client.WebSocketClientProtocol,  # type: ignore[type-arg]
        audio_in: AsyncIterable[Any],
    ) -> None:
        """Wrapper that routes exceptions from the background audio pump to on_error."""
        try:
            await self._pipe_audio_in(linked_id, ws, audio_in)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if self._error_handler:
                try:
                    self._error_handler(exc, linked_id)
                except Exception:
                    pass
            else:
                import traceback
                traceback.print_exc()

    async def _pipe_audio_in(
        self,
        linked_id: str,
        ws: websockets.client.WebSocketClientProtocol,  # type: ignore[type-arg]
        audio_in: AsyncIterable[Any],
    ) -> None:
        async for chunk in audio_in:
            if self._stopped or linked_id not in self._sessions:
                break

            # Accept AudioChunk or raw slin16 bytes (same tolerance as OpenAI adapter)
            if isinstance(chunk, (bytes, bytearray, memoryview)):
                samples_16k = slin16_to_float32(bytes(chunk))
            else:
                samples_attr = getattr(chunk, "samples", None)
                if samples_attr is None:
                    raise TypeError(
                        f"Gemini Live adapter expected AudioChunk or bytes, "
                        f"got {type(chunk).__name__}"
                    )
                # If upstream sends non-16kHz audio, resample; otherwise pass through.
                chunk_sr = getattr(chunk, "sample_rate", DV_SAMPLE_RATE)
                if chunk_sr == DV_SAMPLE_RATE:
                    samples_16k = samples_attr
                else:
                    samples_16k = resample(samples_attr, chunk_sr, DV_SAMPLE_RATE)

            # Split into 20ms frames
            offset = 0
            length = len(samples_16k)
            while offset < length:
                end = min(offset + INPUT_SAMPLES_16K, length)
                frame = samples_16k[offset:end]
                offset = end

                pcm16 = float32_to_slin16(frame)
                b64 = base64.b64encode(pcm16).decode("ascii")

                self._send_event(ws, {
                    "realtime_input": {
                        "media_chunks": [
                            {"mime_type": "audio/pcm;rate=16000", "data": b64},
                        ],
                    },
                })

    def _handle_server_message(self, msg: dict[str, Any], linked_id: str) -> None:
        # setupComplete
        if "setupComplete" in msg:
            return

        sc = msg.get("serverContent")
        if isinstance(sc, dict):
            # Audio output
            model_turn = sc.get("modelTurn")
            if isinstance(model_turn, dict):
                parts = model_turn.get("parts", [])
                if isinstance(parts, list):
                    for part in parts:
                        inline = part.get("inlineData") if isinstance(part, dict) else None
                        if isinstance(inline, dict) and inline.get("data"):
                            pcm_24k = base64.b64decode(inline["data"])
                            samples_24k = slin16_to_float32(pcm_24k)
                            samples_16k = resample(
                                samples_24k, GEMINI_OUTPUT_SAMPLE_RATE, DV_SAMPLE_RATE
                            )
                            pcm_16k = float32_to_slin16(samples_16k)
                            if self._audio_output_handler:
                                self._audio_output_handler(pcm_16k, linked_id)

            # Interruption / barge-in
            if sc.get("interrupted") is True:
                if not self._caller_speaking.get(linked_id):
                    self._caller_speaking[linked_id] = True
                    if self._speech_activity_handler:
                        self._speech_activity_handler(RealtimeSpeechActivityEvent(
                            linked_id=linked_id,
                            side="caller",
                            speaking=True,
                            timestamp_ms=time.time() * 1000,
                        ))

            # Turn / generation complete → clear caller speaking state
            if sc.get("turnComplete") is True or sc.get("generationComplete") is True:
                if self._caller_speaking.get(linked_id):
                    self._caller_speaking[linked_id] = False
                    if self._speech_activity_handler:
                        self._speech_activity_handler(RealtimeSpeechActivityEvent(
                            linked_id=linked_id,
                            side="caller",
                            speaking=False,
                            timestamp_ms=time.time() * 1000,
                        ))

            # Incremental transcription accumulation
            input_tx = sc.get("inputTranscription")
            if isinstance(input_tx, dict) and input_tx.get("text") is not None:
                self._input_transcript_buf[linked_id] = (
                    self._input_transcript_buf.get(linked_id, "") + input_tx["text"]
                )
            output_tx = sc.get("outputTranscription")
            if isinstance(output_tx, dict) and output_tx.get("text") is not None:
                self._output_transcript_buf[linked_id] = (
                    self._output_transcript_buf.get(linked_id, "") + output_tx["text"]
                )

            # Flush accumulated transcripts on turn completion
            if sc.get("turnComplete") is True:
                input_text = self._input_transcript_buf.get(linked_id, "")
                if input_text.strip() and self._transcript_handler:
                    self._transcript_handler(TranscriptResult(
                        linked_id=linked_id,
                        text=input_text,
                        is_final=True,
                        speaker="customer",
                        timestamp_ms=time.time() * 1000,
                    ))
                output_text = self._output_transcript_buf.get(linked_id, "")
                if output_text.strip() and self._transcript_handler:
                    self._transcript_handler(TranscriptResult(
                        linked_id=linked_id,
                        text=output_text,
                        is_final=True,
                        speaker="agent",
                        timestamp_ms=time.time() * 1000,
                    ))
                self._input_transcript_buf[linked_id] = ""
                self._output_transcript_buf[linked_id] = ""

        # Tool calls
        tool_call = msg.get("toolCall")
        if isinstance(tool_call, dict):
            fns = tool_call.get("functionCalls", [])
            if isinstance(fns, list):
                for fc in fns:
                    if isinstance(fc, dict) and fc.get("name"):
                        if self._tool_call_handler:
                            self._tool_call_handler(RealtimeToolCall(
                                call_id=fc.get("id", ""),
                                name=fc["name"],
                                args=fc.get("args", {}) or {},
                                linked_id=linked_id,
                            ))

        # goAway — server signals session will close
        go_away = msg.get("goAway")
        if isinstance(go_away, dict):
            time_left = go_away.get("timeLeft", "unknown")
            if self._error_handler:
                self._error_handler(
                    RuntimeError(f"Gemini Live goAway: session closing in {time_left}"),
                    linked_id,
                )

    def _send_event(
        self,
        ws: websockets.client.WebSocketClientProtocol,  # type: ignore[type-arg]
        event: dict[str, object],
    ) -> None:
        asyncio.ensure_future(self._send_event_locked(ws, event))

    async def _send_event_locked(
        self,
        ws: websockets.client.WebSocketClientProtocol,  # type: ignore[type-arg]
        event: dict[str, object],
    ) -> None:
        async with self._ws_lock:
            try:
                await ws.send(json.dumps(event))
            except websockets.exceptions.ConnectionClosed:
                pass
