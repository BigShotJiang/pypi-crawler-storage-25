# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
"""Module containing the points service implementation for v0."""

import grpc

from ansys.geometry.core.errors import protect_grpc

from ..base.conversions import (
    from_measurement_to_server_angle,
    from_measurement_to_server_length,
    to_distance,
)
from ..base.points import GRPCPointsService
from .conversions import build_grpc_id, from_grpc_point_to_point3d, from_line_to_grpc_line


class GRPCPointsServiceV0(GRPCPointsService):
    """Points service for gRPC communication with the Geometry server.

    This class provides methods to interact with the Geometry server's
    points service. It is specifically designed for the v0 version of the
    Geometry API.

    Parameters
    ----------
    channel : grpc.Channel
        The gRPC channel to the server.
    """

    @protect_grpc
    def __init__(self, channel: grpc.Channel):  # noqa: D102
        from ansys.api.geometry.v0.commands_pb2_grpc import CommandsStub

        self.stub = CommandsStub(channel)

    @protect_grpc
    def create_design_points(self, **kwargs) -> dict:  # noqa: D102
        from ansys.api.geometry.v0.commands_pb2 import CreateDesignPointsRequest

        from .conversions import from_point3d_to_grpc_point

        # Create the request - assumes all inputs are valid and of the proper type
        request = CreateDesignPointsRequest(
            points=[from_point3d_to_grpc_point(point) for point in kwargs["points"]],
            parent=kwargs["parent_id"],
        )

        # Call the gRPC service
        response = self.stub.CreateDesignPoints(request)

        # Return the response - formatted as a dictionary
        return {"point_ids": [p for p in response.ids]}

    @protect_grpc
    def revolve_points(self, **kwargs) -> dict:  # noqa: D102
        from ansys.api.geometry.v0.commands_pb2 import RevolvePointsRequest

        # Create the request - assumes all inputs are valid and of the proper type
        request = RevolvePointsRequest(
            selection=[build_grpc_id(id) for id in kwargs["selection_ids"]],
            axis=from_line_to_grpc_line(kwargs["axis"]),
            angle=from_measurement_to_server_angle(kwargs["angle"]),
        )

        # Call the gRPC service
        response = self.stub.RevolvePoints(request)

        # Return the response - formatted as a dictionary
        return {
            "success": response.result.success,
            "created_curves": [
                {
                    "id": curve.id,
                    "name": curve.owner_name,
                    "length": to_distance(curve.length),
                    "start_point": from_grpc_point_to_point3d(curve.points[0]),
                    "end_point": from_grpc_point_to_point3d(curve.points[1])
                    if len(curve.points) > 1
                    else None,
                    "parent_id": curve.parent_id.id,
                }
                for curve in response.created_curves
            ],
        }

    @protect_grpc
    def revolve_points_by_helix(self, **kwargs) -> dict:  # noqa: D102
        from ansys.api.geometry.v0.commands_pb2 import RevolvePointsByHelixRequest

        # The v0 backend only processes one point per call, so iterate over each
        # selection ID and aggregate results.
        all_curves = []
        success = True
        for selection_id in kwargs["selection_ids"]:
            request = RevolvePointsByHelixRequest(
                selection=[build_grpc_id(selection_id)],
                axis=from_line_to_grpc_line(kwargs["axis"]),
                height=from_measurement_to_server_length(kwargs["height"]),
                pitch=from_measurement_to_server_length(kwargs["pitch"]),
                taper_angle=from_measurement_to_server_angle(kwargs["taper_angle"]),
                right_handed=kwargs["right_handed"],
                pull_symmetric=kwargs["pull_symmetric"],
            )
            response = self.stub.RevolvePointsByHelix(request)
            if not response.result.success:
                success = False
            all_curves.extend(
                {
                    "id": curve.id,
                    "name": curve.owner_name,
                    "length": to_distance(curve.length),
                    "start_point": from_grpc_point_to_point3d(curve.points[0]),
                    "end_point": from_grpc_point_to_point3d(curve.points[1])
                    if len(curve.points) > 1
                    else None,
                    "parent_id": curve.parent_id.id,
                }
                for curve in response.created_curves
            )

        return {"success": success, "created_curves": all_curves}

    @protect_grpc
    def sweep_points(self, **kwargs) -> dict:  # noqa: D102
        from ansys.api.geometry.v0.commands_pb2 import SweepPointsRequest

        # Create the request - assumes all inputs are valid and of the proper type
        request = SweepPointsRequest(
            selection=[build_grpc_id(id) for id in kwargs["selection_ids"]],
            trajectories=[build_grpc_id(id) for id in kwargs["trajectory_ids"]],
            distance=from_measurement_to_server_length(kwargs["distance"]),
        )

        # Call the gRPC service
        response = self.stub.SweepPoints(request)

        # Return the response - formatted as a dictionary
        return {
            "success": response.result.success,
            "created_curves": [
                {
                    "id": curve.id,
                    "name": curve.owner_name,
                    "length": to_distance(curve.length),
                    "start_point": from_grpc_point_to_point3d(curve.points[0]),
                    "end_point": from_grpc_point_to_point3d(curve.points[1])
                    if len(curve.points) > 1
                    else None,
                    "parent_id": curve.parent_id.id,
                }
                for curve in response.created_curves
            ],
        }
