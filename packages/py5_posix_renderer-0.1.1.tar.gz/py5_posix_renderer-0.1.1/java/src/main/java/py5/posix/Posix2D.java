/******************************************************************************

  Part of the py5 posix renderer library
  Copyright (C) 2025-2026 Jim Schmitz

  This library is free software: you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or (at
  your option) any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
  General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with this library. If not, see <https://www.gnu.org/licenses/>.

******************************************************************************/
package py5.posix;

import processing.core.PApplet;
import processing.core.PSurface;
import py5.core.SketchBase;
import py5.core.graphics.HiddenPy5GraphicsJava2D;
import py5.posix.surfaces.HiddenSurfaceJava2D;

public class Posix2D extends HiddenPy5GraphicsJava2D {

  protected SketchBase sketch;
  protected PosixBridge bridge;
  protected PosixExtras extras;

  public Posix2D() {
    extras = new PosixExtras();
  }

  //////////////////////////////////////////////////////////////

  @Override
  public PSurface createSurface() {
    return surface = new HiddenSurfaceJava2D(this, bridge);
  }

  @Override
  public void setSize(int w, int h) {
    super.setSize(w, h);

    if (sketch.recorder != null) {
      sketch.recorder.setSize(w * extras._getPxPerChr(), h * extras._getPxPerChr());
      sketch.postWindowResized(width, height);
    }
  }

  //////////////////////////////////////////////////////////////

  public PosixExtras _getPosixExtras() {
    return extras;
  }

  //////////////////////////////////////////////////////////////

  @Override
  public void setParent(PApplet parent) {
    super.setParent(parent);

    try {
      sketch = (SketchBase) parent;
    } catch (ClassCastException e) {
      throw new RuntimeException("Can only use this renderer with py5");
    }

    RegisteredMethods registeredMethods = new RegisteredMethods();
    sketch.registerMethod("pre", registeredMethods);
    sketch.registerMethod("dispose", registeredMethods);

    bridge = (PosixBridge) sketch.callPython("py5_posix_renderer_create_bridge", sketch, this);
  }

  @Override
  public void beginDraw() {
    super.beginDraw();

    extras.resetTextArrays();

    if (sketch.recorder == null) {
      sketch.beginRecord(sketch.createGraphics(
          width * extras._getPxPerChr(),
          height * extras._getPxPerChr(),
          SketchBase.JAVA2D));
    } else {
      sketch.recorder.beginDraw();
    }
  }

  @Override
  public void endDraw() {
    Object retVal = bridge.end_frame(sketch.recorder);
    if (retVal instanceof RuntimeException) {
      sketch.exit();
      return;
    }

    sketch.recorder.endDraw();
    super.endDraw(); // does nothing
  }

  protected class RegisteredMethods {

    public void pre() {
      sketch.recorder.scale(extras._getPxPerChr(), extras._getPxPerChr());
    }

    public void dispose() {
      bridge.cleanup();
    }

  }

}
