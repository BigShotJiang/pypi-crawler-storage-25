/******************************************************************************

  Part of the py5 posix renderer library
  Copyright (C) 2025-2026 Jim Schmitz

  This library is free software: you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or (at
  your option) any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
  General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with this library. If not, see <https://www.gnu.org/licenses/>.

******************************************************************************/
package py5.posix;

import java.util.ArrayList;
import java.util.List;

public class PosixExtras extends PosixConstants {

  protected static int pxPerChr = 10;
  protected int fixedPxPerChr;
  protected int drawingMode;
  protected String printlnFilename;
  protected String charsByDensity;
  protected String filename;
  protected int currentForegroundTextColor;
  protected int currentBackgroundTextColor;
  protected int currentTextAlignment;
  protected int currentTextDirection;

  protected List<String> textStringRecords;
  protected List<Integer> textXCoords;
  protected List<Integer> textYCoords;
  protected List<Integer> textAlignment;
  protected List<Integer> textDirection;
  protected List<Integer> textForegroundColors;
  protected List<Integer> textBackgroundColors;

  public PosixExtras() {
    fixedPxPerChr = pxPerChr;
    drawingMode = TEXT_MODE;
    printlnFilename = "println.txt";
    charsByDensity = CHARS_ABBREVIATED;
    filename = null;
    currentForegroundTextColor = 0xFF000000;
    currentForegroundTextColor = 0x00000000;
    currentTextAlignment = LEFT;
    currentTextDirection = HORIZONTAL;

    textStringRecords = new ArrayList<String>();
    textXCoords = new ArrayList<Integer>();
    textYCoords = new ArrayList<Integer>();
    textAlignment = new ArrayList<Integer>();
    textDirection = new ArrayList<Integer>();
    textForegroundColors = new ArrayList<Integer>();
    textBackgroundColors = new ArrayList<Integer>();
  }

  public void resetTextArrays() {
    textStringRecords.clear();
    textXCoords.clear();
    textYCoords.clear();
    textForegroundColors.clear();
    textBackgroundColors.clear();
  }

  //////////////////////////////////////////////////////////////////////////
  // methods for public Python methods
  //////////////////////////////////////////////////////////////////////////

  public static void pxPerChr(int pxPerChr) {
    PosixExtras.pxPerChr = pxPerChr;
  }

  public void drawingMode(int mode) {
    if (mode != COLOR_MODE && mode != TEXT_MODE && mode != CUSTOM_MODE) {
      throw new IllegalArgumentException("Invalid drawing mode. Use COLOR_MODE or TEXT_MODE.");
    }
    drawingMode = mode;
  }

  public void printlnFilename(String filename) {
    printlnFilename = filename;
  }

  public void charsByDensity(String chars) {
    charsByDensity = chars;
  }

  public void saveFrame(String filename) {
    this.filename = filename;
  }

  public void text(String text, int x, int y) {
    textStringRecords.add(text);
    textXCoords.add(x);
    textYCoords.add(y);
    textAlignment.add(currentTextAlignment);
    textDirection.add(currentTextDirection);
    textForegroundColors.add(currentForegroundTextColor);
    textBackgroundColors.add(currentBackgroundTextColor);
  }

  public void textAlignment(int textAlignment) {
    currentTextAlignment = textAlignment;
  }

  public void textDirection(int textDirection) {
    currentTextDirection = textDirection;
  }

  public void textForegroundColor(int color) {
    currentForegroundTextColor = color;
  }

  public void textBackgroundColor(int color) {
    currentBackgroundTextColor = color;
  }

  //////////////////////////////////////////////////////////////////////////
  // getters for Python properties
  //////////////////////////////////////////////////////////////////////////

  public int _getPxPerChr() {
    return fixedPxPerChr;
  }

  public int _getDrawingMode() {
    return drawingMode;
  }

  public String _getPrintlnFilename() {
    return printlnFilename;
  }

  public String _getCharsByDensity() {
    return charsByDensity;
  }

  public String _getSaveFrameFilename() {
    String out = filename;
    filename = null;

    return out;
  }

  public String[] _getTextStringRecords() {
    return textStringRecords.toArray(new String[textStringRecords.size()]);
  }

  public Integer[] _getTextXCoords() {
    return textXCoords.toArray(new Integer[textXCoords.size()]);
  }

  public Integer[] _getTextYCoords() {
    return textYCoords.toArray(new Integer[textYCoords.size()]);
  }

  public Integer[] _getTextAlignments() {
    return textAlignment.toArray(new Integer[textAlignment.size()]);
  }

  public Integer[] _getTextDirections() {
    return textDirection.toArray(new Integer[textDirection.size()]);
  }

  public Integer[] _getTextForegroundColors() {
    return textForegroundColors.toArray(new Integer[textForegroundColors.size()]);
  }

  public Integer[] _getTextBackgroundColors() {
    return textBackgroundColors.toArray(new Integer[textBackgroundColors.size()]);
  }
}
