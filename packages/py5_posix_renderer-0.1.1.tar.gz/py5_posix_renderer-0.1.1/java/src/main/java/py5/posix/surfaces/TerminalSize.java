package py5.posix.surfaces;

public class TerminalSize {
    public int columns;
    public int rows;
}
