/******************************************************************************

  Part of the py5 posix renderer library
  Copyright (C) 2025-2026 Jim Schmitz

  This library is free software: you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or (at
  your option) any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
  General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with this library. If not, see <https://www.gnu.org/licenses/>.

******************************************************************************/
package py5.posix;

import processing.core.PApplet;
import processing.core.PGraphics;
import processing.core.PImage;
import processing.core.PSurface;
import processing.opengl.PGraphics3D;
import py5.core.Sketch;
import py5.core.SketchBase;
import py5.posix.surfaces.SmallSurfaceJOGL;

public class Posix3D extends PGraphics3D {

  protected SketchBase sketch;
  protected PosixBridge bridge;
  protected PosixExtras extras;
  protected PImage logo;
  protected PGraphics backgroundImg;

  protected int terminalWidth;
  protected int terminalHeight;

  public Posix3D() {
    extras = new PosixExtras();
  }

  //////////////////////////////////////////////////////////////

  @Override
  public PSurface createSurface() {
    return surface = new SmallSurfaceJOGL(this, bridge);
  }

  @Override
  public void setSize(int w, int h) {
    super.setSize(w, h);

    if (sketch.recorder != null) {
      sketch.recorder.setSize(w * extras._getPxPerChr(), h * extras._getPxPerChr());
    }
  }

  //////////////////////////////////////////////////////////////

  public PosixExtras _getPosixExtras() {
    return extras;
  }

  //////////////////////////////////////////////////////////////

  @Override
  public void setParent(PApplet parent) {
    super.setParent(parent);

    logo = parent.loadImage("logo.png");

    try {
      sketch = (SketchBase) parent;
    } catch (ClassCastException e) {
      throw new RuntimeException("Can only use this renderer with py5");
    }

    RegisteredMethods registeredMethods = new RegisteredMethods();
    sketch.registerMethod("dispose", registeredMethods);

    bridge = (PosixBridge) sketch.callPython("py5_posix_renderer_create_bridge", sketch, this);
  }

  @Override
  public void beginDraw() {
    super.beginDraw();

    extras.resetTextArrays();

    if (sketch.recorder == null) {
      sketch.beginRecord(sketch.createGraphics(
          width * extras._getPxPerChr(),
          height * extras._getPxPerChr(),
          SketchBase.P3D));
    } else {
      sketch.recorder.beginDraw();
    }

    sketch.recorder.scale(extras._getPxPerChr(), extras._getPxPerChr());
  }

  @Override
  public void endDraw() {
    Object retVal = bridge.end_frame(sketch.recorder);
    if (retVal instanceof RuntimeException) {
      sketch.exit();
      return;
    }

    sketch.recorder.endDraw();

    if (backgroundImg == null || backgroundImg.pixelWidth != sketch.pixelWidth || backgroundImg.pixelHeight != sketch.pixelHeight) {
      makeBackground();
    }

    sketch.loadPixels();
    System.arraycopy(backgroundImg.pixels, 0, sketch.pixels, 0, backgroundImg.pixels.length);
    sketch.updatePixels();

    super.endDraw();
  }

  protected void makeBackground() {
    backgroundImg = sketch.createGraphics(sketch.width, sketch.height, Sketch.P2D);
    backgroundImg.beginDraw();
    backgroundImg.background(255);
    backgroundImg.imageMode(Sketch.CENTER);
    int side = Math.min(backgroundImg.width, backgroundImg.height);
    backgroundImg.image(logo, backgroundImg.width / 2, backgroundImg.height / 2, side, side);
    backgroundImg.endDraw();
    backgroundImg.loadPixels();
  }

  protected class RegisteredMethods {

    public void dispose() {
      bridge.cleanup();
    }

  }

}
