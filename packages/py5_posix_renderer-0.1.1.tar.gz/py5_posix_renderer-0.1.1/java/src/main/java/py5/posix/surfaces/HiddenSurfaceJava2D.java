package py5.posix.surfaces;

import processing.core.PApplet;
import processing.core.PSurfaceNone;
import py5.posix.Posix2D;
import py5.posix.PosixBridge;

public class HiddenSurfaceJava2D extends PSurfaceNone {

    protected PosixBridge bridge;

    public HiddenSurfaceJava2D(Posix2D graphics, PosixBridge bridge) {
        super(graphics);
        this.bridge = bridge;
    }

    @Override
    public void initOffscreen(PApplet sketch) {
        this.sketch = sketch;

        boolean fullScreen = sketch.sketchFullScreen();

        if (fullScreen) {
            TerminalSize terminalSize = new TerminalSize();
            bridge.setup_fullscreen(terminalSize);
            setSize(terminalSize.columns, terminalSize.rows);
        } else {
            setSize(sketch.sketchWidth(), sketch.sketchHeight());
        }
    }

    @Override
    public void setSize(int wide, int high) {
        if (wide == sketch.width && high == sketch.height && wide == sketch.pixelWidth && high == sketch.pixelHeight) {
            return; // unchanged, don't rebuild everything
        }

        // call the proper function so pixelWidth and pixelHeight get set
        sketch.setSize(wide, high);

        // set PGraphics variables for width/height/pixelWidth/pixelHeight
        graphics.setSize(wide, high);
    }

}
