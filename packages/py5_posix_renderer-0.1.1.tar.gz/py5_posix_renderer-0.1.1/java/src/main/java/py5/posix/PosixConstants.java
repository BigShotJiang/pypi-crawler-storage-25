/******************************************************************************

  Part of the py5 posix renderer library
  Copyright (C) 2025-2026 Jim Schmitz

  This library is free software: you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or (at
  your option) any later version.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
  General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with this library. If not, see <https://www.gnu.org/licenses/>.

******************************************************************************/
package py5.posix;

public class PosixConstants {

  // REMEMBER, these must be duplicated in py5.renderers.posix.constants

  static public final int COLOR_MODE = 1001;
  static public final int TEXT_MODE = 1002;
  static public final int CUSTOM_MODE = 1003;

  static public final int LEFT = 37;
  static public final int CENTER = 3;
  static public final int RIGHT = 39;

  static public final int HORIZONTAL = 101;
  static public final int VERTICAL = 102;

  static public final String CHARS_ABBREVIATED = " .:-=+*#%@";
  static public final String CHARS_FULL = " .`-_':,;^=+/\"|)\\<>)iv%xclrs{*}I?!][1taeo7zjLunT#JCwfy325Fp6mqSghVd4EgXPGZbYkOA&8U$@KHDBWNMR0Q";
}
