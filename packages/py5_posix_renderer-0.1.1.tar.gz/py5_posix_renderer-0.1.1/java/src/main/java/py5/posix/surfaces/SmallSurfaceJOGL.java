package py5.posix.surfaces;

import java.awt.Rectangle;

import com.jogamp.nativewindow.ScalableSurface;
import com.jogamp.nativewindow.WindowClosingProtocol;
import com.jogamp.newt.opengl.GLWindow;

import processing.core.PGraphics;
import processing.opengl.PSurfaceJOGL;
import py5.posix.PosixBridge;

public class SmallSurfaceJOGL extends PSurfaceJOGL {

    protected PosixBridge bridge;

    public SmallSurfaceJOGL(PGraphics graphics, PosixBridge bridge) {
        super(graphics);
        this.bridge = bridge;
    }

    @Override
    protected void initWindow() {
        window = GLWindow.create(screen, pgl.getCaps());

        // Make sure that we pass the window close through to exit(), otherwise
        // we're likely to have OpenGL try to shut down halfway through rendering
        // a frame. Particularly problematic for complex/slow apps.
        // https://github.com/processing/processing/issues/4690
        window.setDefaultCloseOperation(WindowClosingProtocol.WindowClosingMode.DO_NOTHING_ON_CLOSE);

        screenRect = new Rectangle(
                (int) displayRect.getX(), (int) displayRect.getY(),
                (int) displayRect.getWidth(), (int) displayRect.getHeight());

        // Set the displayWidth/Height variables inside PApplet, so that they're
        // usable and can even be returned by the sketchWidth()/Height() methods.
        sketch.displayWidth = screenRect.width;
        sketch.displayHeight = screenRect.height;

        // Sometimes the window manager or OS will resize the window.
        // Keep track of the requested width/height to notify the user.
        sketchWidthRequested = sketch.sketchWidth();
        sketchHeightRequested = sketch.sketchHeight();

        sketchWidth = sketch.sketchWidth();
        sketchHeight = sketch.sketchHeight();

        if (sketch.sketchFullScreen()) {
            TerminalSize terminalSize = new TerminalSize();
            bridge.setup_fullscreen(terminalSize);

            sketchWidth = terminalSize.columns;
            sketchHeight = terminalSize.rows;
        }

        sketch.setSize(sketchWidth, sketchHeight);

        // https://jogamp.org/deployment/jogamp-next/javadoc/jogl/javadoc/com/jogamp/newt/opengl/GLWindow.html#setSurfaceScale(float%5B%5D)
        float surfaceScale = ScalableSurface.IDENTITY_PIXELSCALE;
        window.setSurfaceScale(new float[] { surfaceScale, surfaceScale });

        windowScaleFactor = 1;
        window.setSize(sketchWidth, sketchHeight);
        window.setResizable(true);
        setSize(sketchWidth, sketchHeight);

        window.setSharedAutoDrawable(sharedDrawable);
    }

}
