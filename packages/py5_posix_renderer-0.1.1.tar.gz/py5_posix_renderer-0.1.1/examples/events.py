import py5

import py5_renderers.posix as py5pr

last_event = ""


def setup():
    py5.full_screen(py5pr.POSIX2D)

    # direct `py5.println()` to a file in `/tmp/`
    py5pr.println_filename("/tmp/println.txt")
    py5pr.drawing_mode(py5pr.COLOR_MODE)

    py5.color_mode(py5.HSB, 360, 100, 100)

    # background color sets alpha=0, making the text adopt the color of
    # whatever is behind it.
    py5pr.text_background_color(py5.color(0, 0))

    py5pr.text_direction(py5pr.HORIZONTAL)  # default
    # py5pr.text_direction(py5pr.VERTICAL)
    py5pr.text_alignment(py5pr.CENTER)


def draw():
    hue = (py5.frame_count / 10) % 360
    py5.background(hue, 80, 80)

    py5pr.text_foreground_color(py5.color((hue + 180) % 360, 80, 80))
    py5pr.text(last_event, py5.mouse_x, py5.mouse_y)


# The below functions demonstrate the mouse and keyboard events. This is very
# similar to what a regular Sketch can provide. For keyboards there is only
# the `key_typed()` event because the terminal cannot capture key down or up
# events.
#
# The `window_resized()` event is called when the terminal window is resized.
# This can only happen when `full_screen()` is used.


def key_typed(e: py5.Py5KeyEvent):
    global last_event

    if e.get_key() == py5.CODED:
        last_event = f"coded key typed: {e.get_key_code()}"
    else:
        last_event = f"key typed: {e.get_key()}"

    py5.println(last_event, flush=True)


def mouse_clicked(e: py5.Py5MouseEvent):
    global last_event

    last_event = f"mouse clicked - count = {e.get_count()}, button = {e.get_button()}"
    py5.println(last_event, flush=True)


def mouse_dragged(e: py5.Py5MouseEvent):
    global last_event

    last_event = f"mouse dragged - button = {e.get_button()}, {e.get_x()} {e.get_y()}"
    py5.println(last_event, flush=True)


def mouse_moved():
    global last_event

    last_event = f"mouse moved {py5.mouse_x} {py5.mouse_y}"
    py5.println(last_event, flush=True)


def mouse_pressed(e: py5.Py5MouseEvent):
    global last_event

    last_event = f"mouse pressed - button = {e.get_button()}"
    py5.println(last_event, flush=True)


def mouse_released(e: py5.Py5MouseEvent):
    global last_event

    last_event = f"mouse released - button = {e.get_button()}"
    py5.println(last_event, flush=True)


def mouse_wheel(e):
    global last_event

    direction = "down" if e.get_count() == 1 else "up"
    last_event = f"mouse wheel rotating {direction}"
    py5.println(last_event, flush=True)


def window_resized():
    # this event is only triggered when `full_screen()` is called
    global last_event

    last_event = "window resized"
    py5.println(last_event)


py5.run_sketch()
