import cv2
import py5

import py5_renderers.posix as py5pr
from py5_renderers.posix.renderers import BaseRenderer

RATIO = 2.1

HEIGHT = 50
WIDTH = int(HEIGHT * RATIO)

cap = cv2.VideoCapture(0)

webcam: py5.Py5Image = None  # type: ignore


class VillaresRenderer(BaseRenderer):
    """
    Custom Renderer

    Homage to the work of Alexandre Villares as part of his Sketch a Day practice
    https://pynews.com.br/@villares/114990480734699157
    https://abav.lugaralgum.com/sketch-a-day/

    https://github.com/villares/sketch-a-day/blob/main/2025/sketch_2025_08_07/sketch_2025_08_07.png
    https://github.com/villares/sketch-a-day/blob/main/2025/sketch_2025_08_07/sketch_2025_08_07.py
    """

    def render_frame(self, g: py5.Py5Graphics) -> str:
        # This custom renderer inherits useful methods from BaseRenderer. You
        # can also write your own. You must implement this `render_frame()`
        # method and match the signature.

        # get grid of colors from underlying JAVA2D graphics object
        foreground_color_grid = self.get_color_grid(g)

        # convert grid of colors into characters according to the string passed
        # to `py5pr.chars_by_density()`
        char_grid = self.get_char_grid(foreground_color_grid)

        # convert color grid into ANSI foreground color codes
        foreground_color_codes = self.get_color_codes_24bit(
            foreground_color_grid, background=False
        )

        # the `eol` parameter makes anything to the right of the output look better
        output = self.assemble_output(foreground_color_codes, char_grid, eol="\033[0m")

        # necessary for `py5pr.save_frame()` to work correctly
        self.check_save_frame(output)

        return output


def setup():
    py5.size(WIDTH, HEIGHT, py5pr.POSIX2D)

    # experiment with any of the following drawing modes

    # py5pr.drawing_mode(py5pr.TEXT_MODE)
    # py5pr.drawing_mode(py5pr.COLOR_MODE)

    # this demonstrates how to create and use a custom renderer
    py5pr.custom_drawing_mode(VillaresRenderer())
    py5pr.chars_by_density(py5pr.CHARS_FULL)

    # in a separate thread, pull webcam frames
    read_webcam()
    py5.launch_repeating_thread(read_webcam, name="webcam")


def draw():
    py5.image(webcam, 0, 0, py5.width, py5.height)

    if py5.frame_count % 10 == 0:
        # save "picture" as a text file
        py5pr.save_frame(f"/tmp/frames/frame-{py5.frame_count:04d}.txt")


def read_webcam():
    global webcam

    ret, frame = cap.read()
    if frame is not None:
        h, w, _ = frame.shape
        d = (w - h) // 2
        frame2 = frame[:, d : (w - d), ::-1].copy()
        if webcam is not None:
            webcam.np_pixels[:, :, 1:] = frame2
            webcam.update_np_pixels()
        else:
            webcam = py5.create_image_from_numpy(frame2, bands="RGB")


py5.run_sketch()
