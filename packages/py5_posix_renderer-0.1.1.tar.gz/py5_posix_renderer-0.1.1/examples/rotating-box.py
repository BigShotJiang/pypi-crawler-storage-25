import py5

import py5_renderers.posix as py5pr

RATIO = 2.1
HEIGHT = 50
WIDTH = int(HEIGHT * RATIO)

xrot = 0
yrot = 0
zrot = 0

py5pr.px_per_chr(1)


def setup():
    # experiment calls to either `size()` or `full_screen()`
    py5.size(WIDTH, HEIGHT, py5pr.POSIX3D)

    # "full screen" means the entire terminal window and will adjust as the
    # terminal window changes size
    # py5.full_screen(py5pr.POSIX3D)

    py5pr.drawing_mode(py5pr.COLOR_MODE)

    py5.color_mode(py5.HSB, 360, 100, 100)

    # background color sets alpha=0, making the text adopt the color of
    # whatever is behind it.
    py5pr.text_background_color(py5.color(0, 0))

    # text direction can be horizontal (default) or vertical
    py5pr.text_direction(py5pr.HORIZONTAL)
    # py5pr.text_direction(py5pr.VERTICAL)


def draw():
    global xrot, yrot, zrot

    hue = (py5.frame_count / 10) % 360
    py5.background(hue, 80, 80)

    xrot += 0.1
    yrot += 0.2
    zrot += 0.3

    py5.translate(py5.width / 2, py5.height / 2, 0)

    # this `scale()` call compensates for the fact that characters not square
    py5.scale(RATIO, 1)

    py5.rotate_x(py5.radians(xrot))  # type: ignore
    py5.rotate_y(py5.radians(yrot))  # type: ignore
    py5.rotate_z(py5.radians(zrot))  # type: ignore

    py5.box(10)

    py5pr.text_alignment(py5pr.LEFT)
    py5pr.text_foreground_color(py5.color((hue + 180) % 360, 80, 80))
    py5pr.text(f"frame rate {py5.get_frame_rate():0.4f}", 0, 0)

    py5pr.text_alignment(py5pr.CENTER)
    # observe that the `text()` method supports strings with newlines in them
    py5pr.text("py5 is awesome!\n...and fun to code with!", py5.mouse_x, py5.mouse_y)


py5.run_sketch()
