from itertools import product

import py5
from py5 import Py5Vector

import py5_renderers.posix as py5pr

RATIO = 2.1


def setup():
    global pos, vel

    # experiment calls to either `size()` or `full_screen()`
    # py5.size(int(40 * RATIO), 40, py5pr.POSIX2D)

    # "full screen" means the entire terminal window and will adjust as the
    # terminal window changes size
    py5.full_screen(py5pr.POSIX2D)

    # direct `py5.println()` to a file in `/tmp/`
    py5pr.println_filename("/tmp/println.txt")

    py5.no_stroke()

    py5pr.chars_by_density(py5pr.CHARS_FULL)

    py5pr.text_alignment(py5pr.LEFT)
    py5pr.text_foreground_color(py5.color(255, 0, 0))
    # background color sets alpha=0, making the text adopt the color of
    # whatever is behind it.
    py5pr.text_background_color(py5.color(0, 0))

    py5.background(255)

    pos = Py5Vector(py5.width / 2, py5.height / 2)
    vel = Py5Vector(0, 0)


def draw():
    global pos

    py5.fill(255, 12)
    py5.rect(0, 0, py5.width, py5.height)

    vel.x = py5.noise(py5.frame_count * 0.01) * 2 - 1  # type: ignore
    vel.y = py5.noise(py5.frame_count * 0.01 + 1000) * 2 - 1  # type: ignore
    pos += vel

    py5.fill(255, 0, 0)
    for i, j in product([-1, 0, 1], repeat=2):
        # the product stuff makes wrapping work correctly
        py5.ellipse(pos.x + i * py5.width, pos.y + j * py5.height, 5 * RATIO, 5)

    if pos.x < 0:
        pos.x = py5.width
    elif pos.x > py5.width:
        pos.x = 0
    if pos.y < 0:
        pos.y = py5.height
    elif pos.y > py5.height:
        pos.y = 0

    py5pr.text(f"frame rate {py5.get_frame_rate():0.4f}", 0, 0)


def mouse_clicked(e: py5.Py5MouseEvent):
    global pos, vel

    pos = Py5Vector(e.get_x(), e.get_y())
    vel = Py5Vector(0, 0)

    py5.println("Mouse clicked")


def window_resized():
    # this event is only triggered when `full_screen()` is called
    global pos, vel

    py5.background(255)
    pos = Py5Vector(py5.width / 2, py5.height / 2)
    vel = Py5Vector(0, 0)

    py5.println("Sketch window resized")


py5.run_sketch()
