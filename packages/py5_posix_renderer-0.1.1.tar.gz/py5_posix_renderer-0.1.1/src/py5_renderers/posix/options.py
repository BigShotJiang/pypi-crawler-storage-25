# *****************************************************************************
#
#   Part of the py5 posix renderer library
#   Copyright (C) 2025-2026 Jim Schmitz
#
#   This library is free software: you can redistribute it and/or modify it
#   under the terms of the GNU Lesser General Public License as published by
#   the Free Software Foundation, either version 2.1 of the License, or (at
#   your option) any later version.
#
#   This library is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
#   General Public License for more details.
#
#   You should have received a copy of the GNU Lesser General Public License
#   along with this library. If not, see <https://www.gnu.org/licenses/>.
#
# *****************************************************************************
from typing import Any

_DEFAULT_OPTIONS = {}
_OPTIONS = {}


def display_options():
    print("Posix Renderer Options:")
    for k, v in _OPTIONS.items():
        print(f"{k}: {v}")


def set_default_option(key: str, value: Any):
    _OPTIONS[key] = value
    _DEFAULT_OPTIONS[key] = value


def reset_options():
    _OPTIONS.clear()
    for k, v in _DEFAULT_OPTIONS.items():
        _OPTIONS[k] = v


def set_option(key: str, value: Any):
    if key in _OPTIONS:
        if isinstance(value, type(_OPTIONS[key])):
            _OPTIONS[key] = value
        else:
            raise ValueError(f"Option {key} must be of type {type(_OPTIONS[key])}")
    else:
        raise KeyError(f"Unknown option: {key}")


def get_option(key: str):
    if key in _OPTIONS:
        return _OPTIONS[key]
    else:
        raise KeyError(f"Unknown option: {key}")
