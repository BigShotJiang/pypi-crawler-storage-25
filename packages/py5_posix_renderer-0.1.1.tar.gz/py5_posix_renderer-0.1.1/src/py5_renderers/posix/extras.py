# *****************************************************************************
#
#   Part of the py5 posix renderer library
#   Copyright (C) 2025-2026 Jim Schmitz
#
#   This library is free software: you can redistribute it and/or modify it
#   under the terms of the GNU Lesser General Public License as published by
#   the Free Software Foundation, either version 2.1 of the License, or (at
#   your option) any later version.
#
#   This library is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
#   General Public License for more details.
#
#   You should have received a copy of the GNU Lesser General Public License
#   along with this library. If not, see <https://www.gnu.org/licenses/>.
#
# *****************************************************************************
from pathlib import Path
from typing import List

from . import constants
from .renderers import BaseRenderer, ColorRenderer, PosixRenderer


def px_per_chr(px):
    from jpype import JClass

    JClass("py5.posix.PosixExtras").pxPerChr(px)


class PosixExtras:

    def __init__(self, bridge, g):
        self._g = g
        self._instance = g._instance._getPosixExtras()
        self._bridge = bridge

        self._renderer = None

        from py5 import Sketch

        self._sketch = Sketch(_instance=g._instance.parent)

    # *************************************************************************
    # Private Properties
    # *************************************************************************

    def _get_px_per_chr(self) -> int:
        return self._instance._getPxPerChr()

    _px_per_chr = property(_get_px_per_chr)

    def _get_println_filename(self) -> str:
        return str(self._instance._getPrintlnFilename())

    _println_filename = property(_get_println_filename)

    def _get_renderer(self):
        if self._renderer is None:
            if self._instance._getDrawingMode() == constants.TEXT_MODE:
                self._renderer = PosixRenderer()
            if self._instance._getDrawingMode() == constants.COLOR_MODE:
                self._renderer = ColorRenderer()

            self._renderer._set_extras(self)  # type: ignore

        return self._renderer

    def _get_chars_by_density(self) -> List[str]:
        return list(str(self._instance._getCharsByDensity()))

    _chars_by_density = property(_get_chars_by_density)

    def _get_save_frame_filename(self):
        filename = self._instance._getSaveFrameFilename()

        if filename:
            filename = Path(
                str(
                    self._sketch._instance.savePath(
                        self._sketch._insert_frame(
                            str(filename), self._sketch.frame_count
                        )
                    )
                )
            )

            return filename
        else:
            return None

    def _get_text_records(self):
        return [
            (
                str(s),
                int(x),
                int(y),
                int(a),
                int(d),
            )
            for s, x, y, a, d in zip(
                self._instance._getTextStringRecords(),
                self._instance._getTextXCoords(),
                self._instance._getTextYCoords(),
                self._instance._getTextAlignments(),
                self._instance._getTextDirections(),
            )
        ]

    def _get_colored_text_records(self):
        return [
            (
                str(s),
                int(x),
                int(y),
                int(a),
                int(d),
                (
                    (int(fgc) & 0xFF000000) >> 24,
                    (int(fgc) & 0xFF0000) >> 16,
                    (int(fgc) & 0xFF00) >> 8,
                    (int(fgc) & 0xFF),
                ),
                (
                    (int(bgc) & 0xFF000000) >> 24,
                    (int(bgc) & 0xFF0000) >> 16,
                    (int(bgc) & 0xFF00) >> 8,
                    (int(bgc) & 0xFF),
                ),
            )
            for s, x, y, a, d, fgc, bgc in zip(
                self._instance._getTextStringRecords(),
                self._instance._getTextXCoords(),
                self._instance._getTextYCoords(),
                self._instance._getTextAlignments(),
                self._instance._getTextDirections(),
                self._instance._getTextForegroundColors(),
                self._instance._getTextBackgroundColors(),
            )
        ]

    # *************************************************************************
    # Public Methods
    # *************************************************************************

    def println_filename(self, filename):
        self._instance.printlnFilename(filename)
        self._bridge._setup_println()

    def drawing_mode(self, mode):
        self._instance.drawingMode(mode)
        self._renderer = None

    def custom_drawing_mode(self, renderer: BaseRenderer):
        self._instance.drawingMode(constants.CUSTOM_MODE)

        renderer._set_extras(self)
        self._renderer = renderer

    def chars_by_density(self, chars):
        self._instance.charsByDensity(chars)

    def save_frame(self, filename):
        self._instance.saveFrame(filename)

    def text(self, text, x, y):
        self._instance.text(text, x, y)

    def text_alignment(self, alignment):
        self._instance.textAlignment(alignment)

    def text_direction(self, direction):
        self._instance.textDirection(direction)

    def text_foreground_color(self, color):
        self._instance.textForegroundColor(color)

    def text_background_color(self, color):
        self._instance.textBackgroundColor(color)
