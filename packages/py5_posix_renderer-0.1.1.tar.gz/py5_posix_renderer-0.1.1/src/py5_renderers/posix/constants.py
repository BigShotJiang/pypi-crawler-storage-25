# *****************************************************************************
#
#   Part of the py5 posix renderer library
#   Copyright (C) 2025-2026 Jim Schmitz
#
#   This library is free software: you can redistribute it and/or modify it
#   under the terms of the GNU Lesser General Public License as published by
#   the Free Software Foundation, either version 2.1 of the License, or (at
#   your option) any later version.
#
#   This library is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
#   General Public License for more details.
#
#   You should have received a copy of the GNU Lesser General Public License
#   along with this library. If not, see <https://www.gnu.org/licenses/>.
#
# *****************************************************************************
POSIX2D = "py5.posix.renderers.Posix2DRenderer"
POSIX3D = "py5.posix.renderers.Posix3DRenderer"

COLOR_MODE = 1001
TEXT_MODE = 1002
CUSTOM_MODE = 1003

LEFT = 37
CENTER = 3
RIGHT = 39

HORIZONTAL = 101
VERTICAL = 102

CHARS_ABBREVIATED = " .:-=+*#%@"
CHARS_FULL = " .`-_':,;^=+/\"|)\\<>)iv%xclrs{*}I?!][1taeo7zjLunT#JCwfy325Fp6mqSghVd4EgXPGZbYkOA&8U$@KHDBWNMR0Q"
