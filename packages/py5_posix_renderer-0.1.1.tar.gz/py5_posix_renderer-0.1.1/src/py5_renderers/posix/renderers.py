# *****************************************************************************
#
#   Part of the py5 posix renderer library
#   Copyright (C) 2025-2026 Jim Schmitz
#
#   This library is free software: you can redistribute it and/or modify it
#   under the terms of the GNU Lesser General Public License as published by
#   the Free Software Foundation, either version 2.1 of the License, or (at
#   your option) any later version.
#
#   This library is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
#   General Public License for more details.
#
#   You should have received a copy of the GNU Lesser General Public License
#   along with this library. If not, see <https://www.gnu.org/licenses/>.
#
# *****************************************************************************
from __future__ import annotations

from io import StringIO
from typing import TYPE_CHECKING, Tuple

import numpy as np
import py5
from PIL import Image

from . import constants

if TYPE_CHECKING:
    from .extras import PosixExtras


# *****************************************************************************
# BASE RENDERING CLASS
# *****************************************************************************


class BaseRenderer:

    def __init__(self):
        self.frame_count = 0

    def _set_extras(self, extras: PosixExtras):
        self.extras = extras

    def __call__(self, g: py5.Py5Graphics, frame_count: int):
        self.frame_count = frame_count

        return self.render_frame(g)

    def render_frame(self, g: py5.Py5Graphics) -> str:
        raise NotImplementedError("Subclasses must implement this method")

    # OUTPUT FUNCTIONS

    def _text_x_slice(
        self, x: int, a: int, d: int, string: str, grid_size: Tuple[int, int]
    ) -> Tuple[slice | None, slice | None]:
        max_x = grid_size[1]
        outside_x = max(0, x - max_x)

        if d == constants.HORIZONTAL:
            if a == constants.LEFT:
                if outside_x:
                    return None, None
                else:
                    x_slice = slice(x, min(x + len(string), max_x))
                    string_slice = slice(0, x_slice.stop - x_slice.start)

                    return x_slice, string_slice

            elif a == constants.RIGHT:
                if outside_x > len(string):
                    return None, None

                x_slice = slice(max(0, x - len(string) + 1), min(x + 1, max_x))
                string_slice = slice(
                    -(x_slice.stop - x_slice.start + outside_x),
                    -outside_x if outside_x else None,
                )

                return x_slice, string_slice

            else:  # a == constants.CENTER
                start = x - len(string) // 2
                end = start + len(string)

                if start > max_x:
                    return None, None

                if start < 0:
                    x_slice_start = 0
                    string_slice_start = -start
                else:
                    x_slice_start = start
                    string_slice_start = 0

                if end > max_x:
                    x_slice_end = max_x
                    string_slice_end = -(end - max_x)
                else:
                    x_slice_end = end
                    string_slice_end = len(string)

                x_slice = slice(x_slice_start, x_slice_end)
                string_slice = slice(string_slice_start, string_slice_end)

                return x_slice, string_slice

        else:
            if outside_x:
                return None, None
            else:
                return slice(x, x + 1), None

    def _text_y_slice(
        self, y: int, a: int, d: int, string: str, grid_size: Tuple[int, int]
    ) -> Tuple[slice | None, slice | None]:
        max_y = grid_size[0]
        outside_y = max(0, y - max_y)

        if d == constants.HORIZONTAL:
            if outside_y:
                return None, None
            else:
                return slice(y, y + 1), None

        else:
            if a == constants.LEFT:
                if outside_y:
                    return None, None
                else:
                    y_slice = slice(max(0, y), min(y + len(string), max_y))
                    string_slice = slice(0, y_slice.stop - y_slice.start)

                    return y_slice, string_slice

            elif a == constants.RIGHT:
                if outside_y > len(string):
                    return None, None

                y_slice = slice(max(0, y - len(string) + 1), min(y + 1, max_y))
                string_slice = slice(
                    -(y_slice.stop - y_slice.start + outside_y),
                    -outside_y if outside_y else None,
                )

                return y_slice, string_slice

            else:  # a == constants.CENTER
                start = y - len(string) // 2
                end = start + len(string)

                if start > max_y:
                    return None, None

                if start < 0:
                    y_slice_start = 0
                    string_slice_start = -start
                else:
                    y_slice_start = start
                    string_slice_start = 0

                if end > max_y:
                    y_slice_end = max_y
                    string_slice_end = -(end - max_y)
                else:
                    y_slice_end = end
                    string_slice_end = len(string)

                y_slice = slice(y_slice_start, y_slice_end)
                string_slice = slice(string_slice_start, string_slice_end)

                return y_slice, string_slice

    def add_text(self, char_grid: np.ndarray) -> np.ndarray:
        for string, x, y, a, d in self.extras._get_text_records():
            for offset, s in enumerate(string.split("\n")):
                xp = x + (0 if d == constants.HORIZONTAL else -offset)
                yp = y + (offset if d == constants.HORIZONTAL else 0)

                if d == constants.HORIZONTAL and not 0 <= yp < char_grid.shape[0]:
                    continue
                if d == constants.VERTICAL and not 0 <= xp < char_grid.shape[1]:
                    continue

                x_slice, string_slice_x = self._text_x_slice(
                    xp, a, d, s, char_grid.shape
                )
                y_slice, string_slice_y = self._text_y_slice(
                    yp, a, d, s, char_grid.shape
                )

                if x_slice is None or y_slice is None:
                    continue

                string_slice: slice = (
                    string_slice_x if string_slice_y is None else string_slice_y
                )  # type: ignore
                if not string_slice:
                    continue

                if d == constants.HORIZONTAL:
                    char_grid[y_slice, x_slice] = list(s)[string_slice]
                else:
                    char_grid[y_slice, x_slice] = np.array(
                        list(s)[string_slice]
                    ).reshape(-1, 1)

        return char_grid

    def add_colored_text(
        self,
        char_grid: np.ndarray,
        foreground_color_grid: np.ndarray,
        background_color_grid: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        for string, x, y, a, d, fgc, bgc in self.extras._get_colored_text_records():
            for offset, s in enumerate(string.split("\n")):
                xp = x + (0 if d == constants.HORIZONTAL else -offset)
                yp = y + (offset if d == constants.HORIZONTAL else 0)

                if d == constants.HORIZONTAL and not 0 <= yp < char_grid.shape[0]:
                    continue
                if d == constants.VERTICAL and not 0 <= xp < char_grid.shape[1]:
                    continue

                x_slice, string_slice_x = self._text_x_slice(
                    xp, a, d, s, char_grid.shape
                )
                y_slice, string_slice_y = self._text_y_slice(
                    yp, a, d, s, char_grid.shape
                )
                string_slice: slice = (
                    string_slice_x if string_slice_y is None else string_slice_y
                )  # type: ignore
                if not string_slice:
                    continue

                if d == constants.HORIZONTAL:
                    char_grid[y_slice, x_slice] = list(s)[string_slice]
                else:
                    char_grid[y_slice, x_slice] = np.array(
                        list(s)[string_slice]
                    ).reshape(-1, 1)

                if fgc[0] > 0:
                    foreground_color_grid[y_slice, x_slice] = fgc[1:]
                if bgc[0] > 0:
                    background_color_grid[y_slice, x_slice] = bgc[1:]

        return char_grid, foreground_color_grid, background_color_grid

    def assemble_output(self, *matrices: np.ndarray, eol: str | None = None) -> str:
        assert (
            len({m.shape for m in matrices}) == 1
        ), "All matrices must have the same shape"

        row_count = matrices[0].shape[0]
        output = StringIO()

        for i, line in enumerate(zip(*matrices)):
            output.writelines(np.dstack(line).flatten())

            if eol:
                output.write(eol)

            if i < row_count - 1:
                output.write("\n")

        return output.getvalue()

    def check_save_frame(self, value: str) -> None:
        filename = self.extras._get_save_frame_filename()
        if filename is not None:
            if not filename.parent.exists:
                filename.parent.mkdir(parents=True, exist_ok=True)

            with open(filename, "w") as f:
                f.write(value + "\n")

    # CHARACTER FUNCTIONS

    def get_char_grid(self, color_grid: np.ndarray):
        chars_by_density = self.extras._chars_by_density
        index = (
            ((3.0 * 255) - color_grid.sum(axis=2))
            / (3.0 * 255)
            * (len(chars_by_density) - 1)
        ).astype(np.int16)
        char_grid = np.array(chars_by_density)[index]

        return char_grid

    def get_blank_char_grid(self, color_grid: np.ndarray):
        return np.full(color_grid.shape[0:2], " ")

    # COLOR FUNCTIONS

    def get_color_grid(self, g: py5.Py5Graphics, resample=Image.Resampling.BOX):
        img = g.to_pil()

        if resample is not None:
            img = img.resize(
                (
                    g.width // self.extras._px_per_chr,
                    g.height // self.extras._px_per_chr,
                ),
                resample=resample,
            )

        color_grid = np.asarray(img)[:, :, :3]

        return color_grid

    def get_color_codes_8bit(
        self, color_grid: np.ndarray, background: bool = True
    ) -> np.ndarray:
        # This skips the gray colors. Perhaps a grayscale version would be interesting one day
        # https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797
        where = 48 if background else 38  # foreground (text)
        color_codes = np.apply_along_axis(
            lambda c: f"\033[{where};5;{36 * c[0] + 6 * c[1] + c[2] + 16:3d}m",
            2,
            (color_grid / 51.0).round().astype(int),
        )

        color_codes = np.char.replace(color_codes, " ", "")  # replace spaces with zeros

        return color_codes

    def get_color_codes_24bit(
        self, color_grid: np.ndarray, background: bool = True
    ) -> np.ndarray:
        # The 3d string formatting is necessary so they are all the same length and
        # the numpy data type is correct. Remove the extra spaces afterwards
        where = 48 if background else 38  # foreground (text)
        color_codes = np.apply_along_axis(
            lambda c: f"\033[{where};2;{c[0]:3d};{c[1]:3d};{c[2]:3d}m", 2, color_grid
        )
        color_codes = np.char.replace(color_codes, " ", "")  # replace spaces with zeros

        return color_codes


# *****************************************************************************
# BUILTIN RENDERING FUNCTIONS
# *****************************************************************************


class PosixRenderer(BaseRenderer):

    def render_frame(self, g: py5.Py5Graphics) -> str:
        color_grid = self.get_color_grid(g)
        char_grid = self.get_char_grid(color_grid)

        char_grid = self.add_text(char_grid)
        output = self.assemble_output(char_grid)
        self.check_save_frame(output)

        return output


class ColorRenderer(BaseRenderer):

    def render_frame(self, g: py5.Py5Graphics) -> str:
        background_color_grid = self.get_color_grid(g).copy()
        foreground_color_grid = np.zeros_like(background_color_grid)

        char_grid = self.get_blank_char_grid(background_color_grid)
        char_grid, foreground_color_grid, background_color_grid = self.add_colored_text(
            char_grid, foreground_color_grid, background_color_grid
        )

        background_color_codes = self.get_color_codes_24bit(background_color_grid)
        foreground_color_codes = self.get_color_codes_24bit(
            foreground_color_grid, background=False
        )

        output = self.assemble_output(
            background_color_codes, foreground_color_codes, char_grid, eol="\033[0m"
        )
        self.check_save_frame(output)

        return output
