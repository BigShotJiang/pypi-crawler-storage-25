# *****************************************************************************
#
#   Part of the py5 posix renderer library
#   Copyright (C) 2025-2026 Jim Schmitz
#
#   This library is free software: you can redistribute it and/or modify it
#   under the terms of the GNU Lesser General Public License as published by
#   the Free Software Foundation, either version 2.1 of the License, or (at
#   your option) any later version.
#
#   This library is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
#   General Public License for more details .
#
#   You should have received a copy of the GNU Lesser General Public License
#   along with this library. If not, see <https://www.gnu.org/licenses/>.
#
# *****************************************************************************
import os
import sys
import termios

import py5
import stackprinter
from jpype import JClass, JImplements, JOverride
from py5_tools.printstreams import _PrintlnFileStream

from .device_events import DeviceEventMgr
from .extras import PosixExtras
from .resize_watcher import ResizeWatcherHook


@JImplements("py5.posix.PosixBridge")
class PosixBridge:

    def __init__(self, sketch: py5.Sketch, g: py5.Py5Graphics):
        self.sketch = sketch
        self.g = g

    def start(self):
        # Because of JPype, the __init__ method is called twice. DO NOT move
        # this code to __init__, it will ruin the terminal & stdin.
        self.extras = PosixExtras(self, self.g)
        self.g.extras = self.extras  # type: ignore

        # pixel_density() can only be called from within settings() and this is
        # the most straightforward way of making sure it is called at the right
        # time. Use pre and not post in case the user wants to change it.
        self.sketch._add_pre_hook(
            "settings", "posix_pre_settings_hook", lambda s: s.pixel_density(1)
        )

        self.original_term_settings = termios.tcgetattr(sys.stdin)

        # https://en.wikipedia.org/wiki/ANSI_escape_code
        # switch to alternate buffer, move cursor to home, hide cursor, clear screen
        print("\033[?1049h" + "\033[H" + "\033[?25l" + "\033[2J", end="", flush=True)

        # set mouse tracking mode
        print("\033[?1003h\033[?1015h\033[?1006h", end="", flush=True)

        self.key_event_mgr = DeviceEventMgr(self.sketch)
        self.sketch.launch_thread(self.key_event_mgr.fill_chr_queue)
        self.sketch.launch_thread(self.key_event_mgr.process_queue)

        self._setup_println()
        self._setup_error_handler()

    def _setup_println(self):
        self.sketch.set_println_stream(
            _PrintlnFileStream(self.extras._println_filename)
        )

    def _setup_error_handler(self):
        class ErrorCapture:
            def __init__(self):
                self.msg = None

            def __call__(self, msg, **kwargs):
                self.msg = msg

        self.error_capture = ErrorCapture()

        def handler(_, exc_type, exc_value, exc_tb):
            py5.bridge.handle_exception(self.error_capture, exc_type, exc_value, exc_tb)
            # don't move this to end_frame()
            self.sketch.exit_sketch()

        self.sketch._py5_bridge.set_handle_exception_function(handler)  # type: ignore

    @JOverride
    def end_frame(self, recorder):
        try:
            # move cursor to home and reset
            print("\033[H" + "\033[0m", end="", flush=True)

            output = self.extras._get_renderer()(
                py5.object_conversion.convert_to_python_type(recorder),  # type: ignore
                self.sketch.frame_count,
            )
            print(output, end="", flush=True)

            if self.error_capture.msg:
                self.cleanup()
                print(self.error_capture.msg)
        except Exception as e:
            exc_type, exc_value, exc_tb = sys.exc_info()
            errmsg = stackprinter.format(
                thing=(exc_type, exc_value, exc_tb),
                show_vals="line",
                style="plaintext",
                suppressed_paths=[
                    r"lib/python.*?/site-packages/numpy/",
                    r"lib/python.*?/site-packages/py5/",
                    r"lib/python.*?/site-packages/py5tools/",
                ],
            )

            self.sketch.exit_sketch()
            self.cleanup()

            print(
                f"Internal error in py5 posix renderer on frame {self.sketch.frame_count}\n"
                + errmsg
            )

            return JClass("java.lang.RuntimeException")(str(e))

    @JOverride
    def setup_fullscreen(self, terminal_size):
        w, h = os.get_terminal_size()
        terminal_size.columns = w
        terminal_size.rows = h

        # using a hook to check the size after every draw() call is more reliable
        # than relying on signal to notify us the size changed
        self.sketch._add_post_hook("draw", "posix_post_draw_hook", ResizeWatcherHook())

    @JOverride
    def cleanup(self):
        self.key_event_mgr.keep_running = False
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.original_term_settings)
        # reset or normal + show cursor + disable mouse tracking + switch back to
        # normal buffer
        print("\033[0m" + "\033[?25h" + "\033[?1003l" + "\033[?1049l", flush=True)
