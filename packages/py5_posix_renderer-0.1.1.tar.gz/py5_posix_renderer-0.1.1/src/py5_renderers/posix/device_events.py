# *****************************************************************************
#
#   Part of the py5 posix renderer library
#   Copyright (C) 2025-2026 Jim Schmitz
#
#   This library is free software: you can redistribute it and/or modify it
#   under the terms of the GNU Lesser General Public License as published by
#   the Free Software Foundation, either version 2.1 of the License, or (at
#   your option) any later version.
#
#   This library is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
#   General Public License for more details.
#
#   You should have received a copy of the GNU Lesser General Public License
#   along with this library. If not, see <https://www.gnu.org/licenses/>.
#
# *****************************************************************************
import enum
import re
import sys
import time
import tty
from collections import deque

import py5

from .options import get_option, set_default_option

set_default_option("device-events.double-click-time", 0.5)


KEY_CODES = {
    9: "Tab",
    10: "Enter",
    27: "Escape",
    127: "Backspace",
}


ANSI_ESCAPE_CODES = {
    "[A": "ArrowUp",
    "[B": "ArrowDown",
    "[C": "ArrowRight",
    "[D": "ArrowLeft",
    "[1~": "Home",
    "[2~": "Insert",
    "[3~": "Delete",
    "[4~": "End",
    "[5~": "PageUp",
    "[5;2~": "Pause",  # test this
    "[6~": "PageDown",
    "[6;2~": "Break",  # can processing handle this?
    "OP": "F1",
    "OQ": "F2",
    "OR": "F3",
    "OS": "F4",
    "[15~": "F5",
    "[17~": "F6",
    "[18~": "F7",
    "[19~": "F8",
    "[20~": "F9",
    "[21~": "F10",
    "[23~": "F11",
    "[24~": "F12",
}


class MouseButtons(enum.IntFlag):
    Button1 = 1
    Button2 = 2
    Button3 = 4
    MouseWheelUp = 8
    MouseWheelDown = 16


_button_map = {
    0: MouseButtons.Button1,
    1: MouseButtons.Button2,
    2: MouseButtons.Button3,
    64: MouseButtons.MouseWheelUp,
    65: MouseButtons.MouseWheelDown,
}


class DeviceEventMgr:

    def __init__(self, sketch: py5.Sketch):
        self.sketch = sketch
        self.vals = deque()
        self.keep_running = True

        self._last_event_button = 0
        self._click_count = 0
        self._last_click_time = 0

    def fill_chr_queue(self):
        tty.setcbreak(sys.stdin)
        while self.keep_running:
            self.vals.append(ord(sys.stdin.read(1)))

    def _handle_mouse_event(self, params: dict):
        # Much of the mouse event handling logic is adapted from terminedia
        #
        # https://github.com/jsbueno/terminedia-paint
        # https://github.com/jsbueno/terminedia/blob/main/terminedia/input.py
        #
        # Many thanks to @jsbueno for the helpful conversation about how this is
        # even possible!
        # https://github.com/jsbueno
        #
        # More information:
        # https://invisible-island.net/xterm/ctlseqs/ctlseqs.html#h2-Mouse-Tracking

        pressed = params["press"] == "M"
        button = _button_map.get(int(params["button"]) & (~0x20), 0)
        moving = bool(int(params["button"]) & 0x20)

        event_mod = 0
        # this duplicates what the py5 sketchportal does but it seems to work
        # correctly if it is always zero
        is_gl = 1 if self.sketch.get_graphics()._instance.isGL() else 0

        col = int(params["column"]) - 1
        row = int(params["row"]) - 1

        # raw_button = int(params["button"])
        # self.sketch.println(
        #     f"mouse event: raw_button={raw_button} moving={moving} button={button} column={col} row={row} press={pressed}",
        #     flush=True,
        # )

        if moving:
            self.sketch._instance.fakeMouseEvent(
                py5.Py5MouseEvent.DRAG if button else py5.Py5MouseEvent.MOVE,
                event_mod,
                col,
                row,
                button,
                is_gl,
            )
        elif pressed:
            if button in [MouseButtons.MouseWheelUp, MouseButtons.MouseWheelDown]:
                direction = -1 if button == MouseButtons.MouseWheelUp else 1
                self.sketch._instance.fakeMouseEvent(
                    py5.Py5MouseEvent.WHEEL, event_mod, col, row, button, direction
                )
            else:
                self.sketch._instance.fakeMouseEvent(
                    py5.Py5MouseEvent.PRESS,
                    event_mod,
                    col,
                    row,
                    button,
                    self._click_count,
                )
                self._note_mouse_down(button)
        else:
            self.sketch._instance.fakeMouseEvent(
                py5.Py5MouseEvent.RELEASE,
                event_mod,
                col,
                row,
                button,
                self._click_count,
            )
            if self._test_double_click(button):
                self.sketch._instance.fakeMouseEvent(
                    py5.Py5MouseEvent.CLICK,
                    event_mod,
                    col,
                    row,
                    button,
                    self._click_count,
                )
            self._last_press = None

    def _test_double_click(self, event_button):
        return self._last_event_button == event_button and (
            time.time() - self._last_click_time
        ) < get_option("device-events.double-click-time")

    def _note_mouse_down(self, event_button):
        t = time.time()
        if (
            t < self._last_click_time + get_option("device-events.double-click-time")
            and event_button == self._last_event_button
        ):
            self._click_count += 1
        else:
            self._click_count = 1
        self._last_click_time = t
        self._last_event_button = event_button

    def process_queue(self):
        try:
            while self.keep_running:
                if len(self.vals):
                    val = self.vals.popleft()
                    if val == 27:  # ESC
                        if self.vals:  # there's more on the queue
                            val = self.vals.popleft()
                            if val == 91:  # [
                                code = [91]
                                while self.vals[0] < 0x40 or 0x7E < self.vals[0]:
                                    code.append(self.vals.popleft())
                                code.append(self.vals.popleft())
                            elif val == 79:
                                code = [79, self.vals.popleft()]
                            else:
                                # unknown sequence
                                # print(
                                #     f"error: how do you parse this? {val} {self.vals}"
                                # )
                                break

                            code_str = "".join([chr(c) for c in code])

                            m = re.match(
                                r"\[\<(?P<button>\d+);(?P<column>\d+);(?P<row>\d+)(?P<press>[Mm])",
                                code_str,
                            )

                            if m:
                                self._handle_mouse_event(m.groupdict())
                            elif code_str in ANSI_ESCAPE_CODES:
                                # valid key
                                self.sketch._instance.fakeKeyEvent(
                                    py5.Py5KeyEvent.TYPE,
                                    0,
                                    ANSI_ESCAPE_CODES[code_str],
                                    False,
                                )
                            else:
                                # unknown sequence
                                self.sketch.println(
                                    f"unknown coded key = {code_str}", flush=True
                                )
                                break
                        else:
                            self.sketch.exit_sketch()
                            return
                    else:
                        # valid key
                        self.sketch._instance.fakeKeyEvent(
                            py5.Py5KeyEvent.TYPE,
                            0,
                            KEY_CODES.get(val, chr(val)),
                            False,
                        )
                time.sleep(0.01)
        except Exception as e:
            print(f"exception: {e}")
