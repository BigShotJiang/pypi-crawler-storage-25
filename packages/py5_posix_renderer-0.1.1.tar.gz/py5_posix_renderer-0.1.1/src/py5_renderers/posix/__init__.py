# *****************************************************************************
#
#   Part of the py5 posix renderer library
#   Copyright (C) 2025-2026 Jim Schmitz
#
#   This library is free software: you can redistribute it and/or modify it
#   under the terms of the GNU Lesser General Public License as published by
#   the Free Software Foundation, either version 2.1 of the License, or (at
#   your option) any later version.
#
#   This library is distributed in the hope that it will be useful, but
#   WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser
#   General Public License for more details.
#
#   You should have received a copy of the GNU Lesser General Public License
#   along with this library. If not, see <https://www.gnu.org/licenses/>.
#
# *****************************************************************************
from __future__ import annotations

import sys
import warnings
from typing import TYPE_CHECKING

if sys.platform == "win32":
    raise RuntimeError(
        "The py5-posix-renderer is only supported on Linux and macOS. "
        "Windows users should use the standard py5 renderers or run via WSL."
    )

import py5_tools

from . import constants
from .constants import *
from .extras import PosixExtras, px_per_chr
from .options import display_options, get_option, reset_options, set_option

if TYPE_CHECKING:
    from py5 import Sketch

    from py5_renderers.posix.renderers import BaseRenderer

__version__ = "0.1.1"


class Py5RuntimeWarning(RuntimeWarning):
    pass


warnings.filterwarnings("once", category=Py5RuntimeWarning)


def _warn(func_name: str) -> None:
    warnings.warn(
        f"{func_name}() can only be used with the py5 posix renderer",
        Py5RuntimeWarning,
        stacklevel=3,
    )


def create_posix_bridge(sketch, g):
    # the jvm needs to be running for this import to succeed
    from .bridge import PosixBridge

    bridge = PosixBridge(sketch, g)
    bridge.start()

    return bridge


py5_tools.register_processing_mode_key(
    "py5_posix_renderer_create_bridge", create_posix_bridge
)


def get_extras(*, sketch: Sketch | None = None) -> None | PosixExtras:
    if sketch is None:
        import py5

        sketch = py5.get_current_sketch()
        using_current_sketch = True
    else:
        using_current_sketch = False

    if not sketch.is_running:
        raise RuntimeError(
            f"The{' current' if using_current_sketch else ''} Sketch is not running. Posix renderer commands can only be used on a running Sketch."
        )

    if hasattr(g := sketch.get_graphics(), "extras") and isinstance(
        extras := g.extras, PosixExtras
    ):
        return extras
    else:
        return None


def drawing_mode(mode: int):
    extras = get_extras()
    if extras:
        extras.drawing_mode(mode)
    else:
        _warn("drawing_mode")


def custom_drawing_mode(renderer: BaseRenderer):
    extras = get_extras()
    if extras:
        extras.custom_drawing_mode(renderer)
    else:
        _warn("custom_drawing_mode")


def println_filename(filename: str):
    extras = get_extras()
    if extras:
        extras.println_filename(filename)
    else:
        _warn("println_filename")


def chars_by_density(chars: str):
    extras = get_extras()
    if extras:
        extras.chars_by_density(chars)
    else:
        _warn("chars_by_density")


def save_frame(filename: str):
    extras = get_extras()
    if extras:
        extras.save_frame(filename)
    else:
        _warn("save_frame")


def text(text: str, x: int, y: int):
    extras = get_extras()
    if extras:
        extras.text(text, x, y)
    else:
        _warn("text")


def text_alignment(alignment: int):
    extras = get_extras()
    if extras:
        extras.text_alignment(alignment)
    else:
        _warn("text_alignment")


def text_direction(direction: int):
    extras = get_extras()
    if extras:
        extras.text_direction(direction)
    else:
        _warn("text_direction")


def text_foreground_color(color: int):
    extras = get_extras()
    if extras:
        extras.text_foreground_color(color)
    else:
        _warn("text_foreground_color")


def text_background_color(color: int):
    extras = get_extras()
    if extras:
        extras.text_background_color(color)
    else:
        _warn("text_background_color")


__all__ = [
    "__version__",
    *[c for c in dir(constants) if c[0] != "_"],
    "chars_by_density",
    "custom_drawing_mode",
    "display_options",
    "drawing_mode",
    "get_extras",
    "get_option",
    "println_filename",
    "px_per_chr",
    "reset_options",
    "save_frame",
    "set_option",
    "text",
    "text_alignment",
    "text_direction",
    "text_background_color",
    "text_foreground_color",
]  # type: ignore


def __dir__():
    return __all__
