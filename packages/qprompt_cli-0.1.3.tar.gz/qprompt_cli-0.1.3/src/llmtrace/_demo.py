"""Demo flow used by `qprompt run --demo` so the CLI produces a complete,
multi-hop trace out of the box. Production users should compose primitives
directly; see `examples/sql_agent.py` for the public reference path.

The flow is intentionally shaped like a small agent loop so the CLI's chain-
of-thought renderer has something to show:

    gather -> think -> gather more -> clean -> clean -> gather more -> think -> answer

Every step is traced with synthetic but plausible token usage and reasoning
strings so the rendered trail looks like a real pipeline. The trace carries
`is_demo: true` so consumers cannot mistake it for production data.
"""
from __future__ import annotations

from time import perf_counter
from typing import Any

from .schema import add_step, new_trace
from .tools import ToolRunResult, ToolTracer, traced_tool
from .tracer import Tracer, _content_text


@traced_tool("sql")
def _demo_sql(query: str) -> ToolRunResult:
    _ = query
    rows = [
        {"segment": "enterprise", "month": "March", "revenue_change_pct": -18},
        {"segment": "mid_market", "month": "March", "revenue_change_pct": -6},
        {"segment": "smb", "month": "March", "revenue_change_pct": -2},
    ]
    return ToolRunResult(value=rows, output_summary=f"returned {len(rows)} rows")


@traced_tool("sql")
def _demo_sql_drilldown(query: str) -> ToolRunResult:
    _ = query
    rows = [
        {"account": "acct_4421", "segment": "enterprise", "churn_risk": "high"},
        {"account": "acct_7813", "segment": "enterprise", "churn_risk": "high"},
        {"account": "acct_1090", "segment": "enterprise", "churn_risk": "medium"},
    ]
    return ToolRunResult(value=rows, output_summary=f"returned {len(rows)} rows")


@traced_tool("dedupe")
def _demo_dedupe(rows: list[dict[str, Any]]) -> ToolRunResult:
    seen: set[tuple[Any, ...]] = set()
    deduped: list[dict[str, Any]] = []
    for r in rows:
        key = tuple(sorted(r.items()))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    return ToolRunResult(value=deduped, output_summary=f"{len(deduped)} rows after dedupe")


@traced_tool("normalize")
def _demo_normalize(rows: list[dict[str, Any]]) -> ToolRunResult:
    normalized = [
        {**r, "segment": str(r.get("segment", "")).lower().strip()} for r in rows
    ]
    return ToolRunResult(value=normalized, output_summary=f"normalized {len(normalized)} rows")


@traced_tool("lookup")
def _demo_lookup(account_ids: list[str]) -> ToolRunResult:
    _ = account_ids
    rows = [
        {"account": "acct_4421", "renewal_date": "2026-03-31", "owner": "alex"},
        {"account": "acct_7813", "renewal_date": "2026-03-15", "owner": "jamie"},
    ]
    return ToolRunResult(value=rows, output_summary=f"resolved {len(rows)} accounts")


def _mock_thinker(label: str, thought: str, *, in_tokens: int, out_tokens: int):
    """Build an llm_callable that returns a fixed reasoning string + answer.

    Used to simulate the model's intermediate "think" hops in the demo. The
    answer text is short and structural so downstream audit doesn't flag it
    as an unsupported process claim.
    """

    def call(*, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> dict[str, Any]:
        _ = messages, tools
        return {
            "text": label,
            "reasoning": thought,
            "usage": {"input_tokens": in_tokens, "output_tokens": out_tokens},
        }

    return call


def run_demo(tracer: Tracer, question: str) -> tuple[dict[str, Any], str]:
    trace = new_trace(question=question, model=tracer.model)
    trace["is_demo"] = True
    add_step(trace, {"type": "input_received", "question": question})

    t0 = perf_counter()
    parsed = tracer.parse_question(question)
    trace["parsed"] = parsed
    add_step(
        trace,
        {
            "type": "question_parser",
            "output": parsed,
            "latency_ms": int((perf_counter() - t0) * 1000),
        },
    )

    tool_tracer = ToolTracer(trace)

    # Hop 1: gather
    sql_rows = _demo_sql(
        "SELECT month, segment, revenue_change_pct FROM revenue_by_segment WHERE month='March'",
        _tool_tracer=tool_tracer,
    )

    # Hop 2: think (model decides what to do next)
    tracer.chat(
        messages=[
            {"role": "system", "content": "Plan next action."},
            {"role": "user", "content": f"Initial rows: {sql_rows}. What should we look at next?"},
        ],
        llm_callable=_mock_thinker(
            label="plan: drill into enterprise segment",
            thought=(
                "Enterprise shows the largest drop (-18%) while mid_market and smb are "
                "modest. The enterprise segment is the outlier — I should pull the "
                "underlying accounts to see if a small number of high-value accounts "
                "are driving the decline."
            ),
            in_tokens=120,
            out_tokens=24,
        ),
        trace=trace,
        tools=[{"name": "sql", "description": "Query analytical warehouse"}],
    )

    # Hop 3: gather more
    drilldown_rows = _demo_sql_drilldown(
        "SELECT account, segment, churn_risk FROM accounts WHERE segment='enterprise' AND month='March'",
        _tool_tracer=tool_tracer,
    )

    # Hop 4: clean (dedupe)
    deduped = _demo_dedupe(drilldown_rows, _tool_tracer=tool_tracer)

    # Hop 5: clean (normalize)
    normalized = _demo_normalize(deduped, _tool_tracer=tool_tracer)

    # Hop 6: gather more (lookup account metadata)
    high_risk_ids = [r["account"] for r in normalized if r.get("churn_risk") == "high"]
    _demo_lookup(high_risk_ids, _tool_tracer=tool_tracer)

    # Hop 7: think (model synthesizes)
    period = parsed.get("entities", {}).get("period")
    period_suffix = f" in {period}" if isinstance(period, str) and period else ""

    final_text = (
        f"Revenue dropped mainly in enterprise (about 18% down{period_suffix}), "
        "concentrated in two high-risk accounts whose renewals fell in March. "
        "Mid-market and SMB declines were modest."
    )

    trace["evidence"].extend(
        [
            {
                "source": "query_result",
                "claim": "Enterprise revenue dropped 18%",
                "evidence_id": "query_result_enterprise_drop",
            },
            {
                "source": "query_result",
                "claim": "Two high-risk enterprise accounts had March renewals",
                "evidence_id": "query_result_high_risk_renewals",
            },
        ]
    )

    def synthesizer(*, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> dict[str, Any]:
        _ = tools
        joined = " ".join(_content_text(m.get("content", "")) for m in messages)
        return {
            "text": final_text,
            "reasoning": (
                "Two enterprise accounts (acct_4421, acct_7813) flagged high churn risk "
                "and renewed in March. Their combined ARR loss matches the 18% segment "
                "drop. Mid-market and SMB segments stayed near baseline."
            ),
            "usage": {
                "input_tokens": max(1, len(joined.split())),
                "output_tokens": max(1, len(final_text.split())),
            },
        }

    answer = tracer.chat(
        messages=[
            {"role": "system", "content": "You are a concise analytics assistant."},
            {"role": "user", "content": question},
        ],
        llm_callable=synthesizer,
        trace=trace,
        tools=[{"name": "sql", "description": "Query analytical warehouse"}],
    )
    trace["final_answer"] = answer

    path = tracer.finalize(trace)
    return trace, path
