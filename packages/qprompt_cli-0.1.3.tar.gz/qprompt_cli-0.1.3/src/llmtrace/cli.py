from __future__ import annotations

import argparse
import difflib
import json
import sys
import textwrap
from typing import Any

from ._demo import run_demo
from .storage import TraceStorage
from .tracer import Tracer


# Bookkeeping step types not worth surfacing as a row in the CoT view —
# they're still present in the saved trace JSON for `qprompt show`.
_HIDDEN_STEP_TYPES: frozenset[str] = frozenset({"request_sent"})

_GATHER_TOOLS: frozenset[str] = frozenset({"sql", "lookup", "search", "retrieve", "fetch"})
_CLEAN_TOOLS: frozenset[str] = frozenset({"dedupe", "normalize", "filter", "transform", "clean"})


def _step_label(step: dict[str, Any]) -> str:
    """Return the left-column label (the verb in the chain of thought)."""
    stype = step.get("type", "?")
    if stype == "input_received":
        return "prompt"
    if stype == "question_parser":
        return "parsed"
    if stype == "model_response":
        return "thought" if step.get("reasoning") else "responded"
    if stype == "model_error":
        return "model error"
    if stype == "answer_audit":
        return "audit"
    if stype == "tool_call":
        tool = step.get("tool", "")
        if tool in _GATHER_TOOLS:
            return "gathered"
        if tool in _CLEAN_TOOLS:
            return "cleaned"
        return "ran"
    return stype


def _summarize_step(step: dict[str, Any]) -> str:
    """Return a short, one-line summary of what happened in this step."""
    stype = step.get("type", "?")

    if stype == "input_received":
        q = str(step.get("question", "")).strip()
        return q if len(q) <= 80 else q[:77] + "..."

    if stype == "question_parser":
        out = step.get("output", {}) or {}
        bits = [f"intent={out.get('intent', '?')}"]
        entities = out.get("entities") or {}
        if entities:
            bits.append("entities=" + ",".join(f"{k}={v}" for k, v in entities.items()))
        return " ".join(bits)

    if stype == "tool_call":
        tool = step.get("tool", "?")
        summary = str(step.get("output_summary", "")).strip()
        status = step.get("status", "ok")
        suffix = " FAILED" if status != "ok" else ""
        return f"{tool}{suffix}: {summary}" if summary else f"{tool}{suffix}"

    if stype == "model_response":
        reasoning = step.get("reasoning")
        if reasoning:
            first_line = str(reasoning).strip().splitlines()[0]
            if len(first_line) > 100:
                first_line = first_line[:97] + "..."
            return first_line
        text = str(step.get("text", "")).strip()
        if text:
            first_line = text.splitlines()[0]
            if len(first_line) > 100:
                first_line = first_line[:97] + "..."
            return first_line
        return ""

    if stype == "model_error":
        return f"error: {step.get('error', 'unknown')}"

    if stype == "answer_audit":
        out = step.get("output", {}) or {}
        unsupported = len(out.get("unsupported_claims") or [])
        risks = len(out.get("risk_flags") or [])
        return f"unsupported={unsupported} risks={risks}"

    return ""


def _step_meta(step: dict[str, Any]) -> str:
    """Return the right-aligned metadata column: tokens + latency, if any."""
    parts: list[str] = []
    tokens = step.get("tokens") or {}
    in_tok = tokens.get("input_estimate")
    out_tok = tokens.get("output_estimate")
    if in_tok is not None or out_tok is not None:
        parts.append(f"tok in {in_tok or 0} / out {out_tok or 0}")
    latency = step.get("latency_ms")
    if latency is not None:
        parts.append(f"{latency} ms")
    return "  ·  ".join(parts)


def _render_cot(trace: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append(f"Question: {trace.get('question', '')}")
    lines.append(f"Model:    {trace.get('model', '')}")
    if trace.get("is_demo"):
        lines.append("Mode:     DEMO (synthetic tool data)")
    lines.append("")
    lines.append("Chain of thought:")

    steps = trace.get("steps", []) or []
    visible_steps = [s for s in steps if s.get("type") not in _HIDDEN_STEP_TYPES]
    total_in = 0
    total_out = 0
    reasoning_blocks: list[tuple[int, str]] = []

    for idx, step in enumerate(visible_steps, start=1):
        label = _step_label(step)
        summary = _summarize_step(step)
        meta = _step_meta(step)

        left = f"  [{idx:>2}] {label:<10} {summary}"
        if meta:
            if len(left) < 70:
                left = f"{left:<70} {meta}"
            else:
                left = f"{left}\n{' ' * 70} {meta}"
        lines.append(left)

        tokens = step.get("tokens") or {}
        total_in += int(tokens.get("input_estimate") or 0)
        total_out += int(tokens.get("output_estimate") or 0)

        if step.get("reasoning"):
            reasoning_blocks.append((idx, str(step["reasoning"])))

    lines.append("")
    lines.append(f"Tokens (cumulative): in {total_in}  out {total_out}  total {total_in + total_out}")

    if reasoning_blocks:
        lines.append("")
        lines.append("Reasoning detail:")
        for idx, text in reasoning_blocks:
            wrapped = textwrap.fill(
                text.strip(),
                width=88,
                initial_indent=f"  [{idx:>2}] ",
                subsequent_indent="       ",
            )
            lines.append(wrapped)

    final_answer = trace.get("final_answer", "")
    if final_answer:
        lines.append("")
        lines.append("Answer:")
        lines.append(textwrap.fill(final_answer, width=88, initial_indent="  ", subsequent_indent="  "))

    risks = trace.get("risks") or []
    if risks:
        lines.append("")
        lines.append("Risks:")
        for r in risks:
            lines.append(f"  - {r}")

    return "\n".join(lines)


def _cmd_run(args: argparse.Namespace) -> int:
    tracer = Tracer(model=args.model)
    if args.demo:
        print(
            "[demo mode] Synthetic tool calls and evidence will be added to the trace. "
            "Do not use for real debugging.",
            file=sys.stderr,
        )
        trace, path = run_demo(tracer, args.question)
    else:
        trace, path = tracer.run(args.question)

    print(_render_cot(trace))
    label = " [DEMO]" if trace.get("is_demo") else ""
    print(f"\nTrace: {path}{label}")
    print(f"Trace ID: {trace['trace_id']}")
    return 0


def _cmd_show(args: argparse.Namespace) -> int:
    storage = TraceStorage()
    trace = storage.load_trace(args.trace)
    print(json.dumps(trace, indent=2))
    return 0


def _cmd_list(args: argparse.Namespace) -> int:
    storage = TraceStorage()
    files = storage.list_trace_paths(limit=args.limit)
    if not files:
        print("No traces found.")
        return 0

    for p in files:
        print(str(p))
    return 0


def _cmd_diff(args: argparse.Namespace) -> int:
    storage = TraceStorage()
    a = storage.load_trace(args.trace_a)
    b = storage.load_trace(args.trace_b)

    text_a = json.dumps(a, indent=2).splitlines()
    text_b = json.dumps(b, indent=2).splitlines()

    diff = difflib.unified_diff(
        text_a,
        text_b,
        fromfile=args.trace_a,
        tofile=args.trace_b,
        lineterm="",
    )

    print("\n".join(diff))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="qprompt", description="LLM tracing CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser("run", help="Run a traced question")
    run_p.add_argument("question", type=str)
    run_p.add_argument("--model", default="mock-gpt")
    run_p.add_argument(
        "--demo",
        action="store_true",
        help=(
            "Use the bundled multi-hop demo (synthetic tool calls + evidence). "
            "Off by default — real traces should never carry fake data."
        ),
    )
    run_p.set_defaults(func=_cmd_run)

    show_p = sub.add_parser("show", help="Show a trace JSON")
    show_p.add_argument("trace", type=str, help="Trace ID or path")
    show_p.set_defaults(func=_cmd_show)

    list_p = sub.add_parser("list", help="List traces")
    list_p.add_argument("--limit", type=int, default=20)
    list_p.set_defaults(func=_cmd_list)

    diff_p = sub.add_parser("diff", help="Diff two traces")
    diff_p.add_argument("trace_a", type=str)
    diff_p.add_argument("trace_b", type=str)
    diff_p.set_defaults(func=_cmd_diff)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
