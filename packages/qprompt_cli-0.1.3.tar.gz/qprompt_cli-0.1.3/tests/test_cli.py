"""CLI behavior tests. Drives `_cmd_run` directly with a synthesized argparse
namespace and a tmp-path storage so traces don't leak into the repo's `.traces`.
"""
import json
from argparse import Namespace
from unittest.mock import patch

from llmtrace import cli
from llmtrace.storage import TraceStorage
from llmtrace.tracer import Tracer


def _run(args, tmp_path):
    storage = TraceStorage(root=str(tmp_path))
    with patch("llmtrace.cli.Tracer", lambda model: Tracer(storage=storage, model=model)):
        rc = cli._cmd_run(args)
    return rc, storage


def test_default_run_is_not_demo(tmp_path, capsys):
    args = Namespace(question="why did revenue drop in March?", model="m", demo=False)
    rc, storage = _run(args, tmp_path)
    assert rc == 0

    saved = storage.list_trace_paths()
    assert len(saved) == 1
    data = json.loads(saved[0].read_text())
    assert data.get("is_demo") is not True, "default CLI invocation must NOT be a demo trace"
    assert not any(
        s.get("type") == "tool_call" and s.get("tool") == "sql" for s in data["steps"]
    )
    assert data["evidence"] == []

    out = capsys.readouterr().out
    assert "[DEMO]" not in out


def test_demo_flag_produces_marked_trace(tmp_path, capsys):
    args = Namespace(question="why did revenue drop in March?", model="m", demo=True)
    rc, storage = _run(args, tmp_path)
    assert rc == 0

    saved = storage.list_trace_paths()
    assert len(saved) == 1
    data = json.loads(saved[0].read_text())
    assert data.get("is_demo") is True, "demo invocation must mark the saved trace"
    assert any(
        s.get("type") == "tool_call" and s.get("tool") == "sql" for s in data["steps"]
    )

    captured = capsys.readouterr()
    assert "[DEMO]" in captured.out, "stdout summary must label demo traces"
    assert "demo mode" in captured.err.lower(), "stderr banner must announce demo mode"


def test_argparse_default_for_demo_flag_is_false():
    parser = cli.build_parser()
    ns = parser.parse_args(["run", "any question"])
    assert ns.demo is False


def test_argparse_no_demo_sql_flag_removed():
    """The old opt-out flag should no longer be accepted; users must use --demo."""
    import argparse

    import pytest as _pt

    parser = cli.build_parser()
    with _pt.raises((SystemExit, argparse.ArgumentError)):
        parser.parse_args(["run", "any question", "--no-demo-sql"])


def test_cot_rendering_shows_steps_tokens_and_answer(tmp_path, capsys):
    args = Namespace(question="why did revenue drop in March?", model="m", demo=True)
    rc, _ = _run(args, tmp_path)
    assert rc == 0
    out = capsys.readouterr().out

    # Chain-of-thought header present.
    assert "Chain of thought:" in out
    # Demo flow produces multiple numbered hops.
    assert "[ 1]" in out
    assert "[ 2]" in out
    assert "[ 5]" in out, "multi-hop demo should produce at least 5 numbered steps"
    # Cumulative tokens summary present.
    assert "Tokens (cumulative):" in out
    # Reasoning emitted by mock thinkers shows up in detail section.
    assert "Reasoning detail:" in out
    # Final answer section present.
    assert "Answer:" in out
    # Tool steps are labeled with their semantic verb, summary names the tool.
    assert "gathered   sql:" in out
    assert "cleaned    dedupe:" in out
    # `request_sent` bookkeeping rows are hidden from the CoT view.
    assert "request_sent" not in out
    assert "sent to model" not in out


def test_cot_rendering_default_run_no_reasoning_section(tmp_path, capsys):
    """Default (stub) run has no provider reasoning — render must not show that section."""
    args = Namespace(question="what is the capital of France?", model="m", demo=False)
    rc, _ = _run(args, tmp_path)
    assert rc == 0
    out = capsys.readouterr().out
    assert "Chain of thought:" in out
    assert "Reasoning detail:" not in out, "stub callable emits no reasoning"
    assert "Tokens (cumulative):" in out


def test_cot_step_label_for_tool_call_classifies_clean_vs_gather():
    step_sql = {"type": "tool_call", "tool": "sql", "status": "ok", "output_summary": "14 rows"}
    step_dedupe = {"type": "tool_call", "tool": "dedupe", "status": "ok", "output_summary": "8 rows"}
    step_unknown = {"type": "tool_call", "tool": "weird", "status": "ok", "output_summary": "done"}
    assert cli._step_label(step_sql) == "gathered"
    assert cli._step_label(step_dedupe) == "cleaned"
    assert cli._step_label(step_unknown) == "ran"
    assert cli._summarize_step(step_sql) == "sql: 14 rows"
    assert cli._summarize_step(step_dedupe) == "dedupe: 8 rows"


def test_cot_step_meta_includes_tokens_and_latency():
    step = {
        "type": "model_response",
        "latency_ms": 812,
        "tokens": {"input_estimate": 142, "output_estimate": 38},
    }
    meta = cli._step_meta(step)
    assert "tok in 142 / out 38" in meta
    assert "812 ms" in meta
