import json

import pytest

from llmtrace import Tracer
from llmtrace.storage import TraceStorage


def test_default_run_produces_validated_trace(tmp_path):
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")
    trace, path = tracer.run("what is the capital of France?")
    assert trace["final_answer"]
    assert trace["parsed"]["intent"] == "general_qa"
    assert any(s["type"] == "answer_audit" for s in trace["steps"])
    assert path.endswith(".json")


def test_custom_llm_callable_used(tmp_path):
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")

    def my_llm(*, messages, tools):
        _ = messages, tools
        return {"text": "custom answer", "usage": {"input_tokens": 7, "output_tokens": 3}}

    trace, _ = tracer.run("any question", llm_callable=my_llm)
    assert trace["final_answer"] == "custom answer"
    response_step = next(s for s in trace["steps"] if s["type"] == "model_response")
    assert response_step["tokens"]["input_estimate"] == 7
    assert response_step["tokens"]["output_estimate"] == 3


def test_block_list_content_does_not_crash(tmp_path):
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")

    captured = {}

    def llm(*, messages, tools):
        _ = tools
        captured["messages"] = messages
        return {"text": "ok", "usage": {}}

    # Manually inject a block-list shaped message via chat() to verify _content_text path.
    from llmtrace.schema import new_trace, add_step

    trace = new_trace(question="q", model="m")
    messages = [
        {"role": "user", "content": [{"type": "text", "text": "hello"}, {"text": "world"}]},
    ]
    answer = tracer.chat(messages=messages, llm_callable=llm, trace=trace)
    add_step(trace, {"type": "input_received", "question": "q"})
    trace["final_answer"] = answer

    response_step = next(s for s in trace["steps"] if s["type"] == "model_response")
    assert response_step["tokens"]["input_estimate"] >= 2  # "hello", "world"


def test_demo_flow_runs_and_persists(tmp_path):
    from llmtrace._demo import run_demo

    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")
    trace, path = run_demo(tracer, "why did revenue drop in March?")
    assert path.endswith(".json")
    assert trace["parsed"]["intent"] == "metric_explanation"
    assert any(s["type"] == "tool_call" and s["tool"] == "sql" for s in trace["steps"])
    assert trace["evidence"]
    # The canned demo answer must NOT trigger a process-claim risk.
    assert not any("unsupported process claim" in r.lower() for r in trace["risks"])


def test_run_persists_trace_when_llm_raises(tmp_path):
    storage = TraceStorage(root=str(tmp_path))
    tracer = Tracer(storage=storage, model="m")

    def boom(*, messages, tools):
        _ = messages, tools
        raise RuntimeError("network down")

    with pytest.raises(RuntimeError, match="network down"):
        tracer.run("any question", llm_callable=boom)

    saved = storage.list_trace_paths()
    assert len(saved) == 1, "trace should be persisted even when LLM raises"
    data = json.loads(saved[0].read_text())
    assert any(s["type"] == "model_error" for s in data["steps"])
    err_step = next(s for s in data["steps"] if s["type"] == "model_error")
    assert "network down" in err_step["error"]
    assert any("model call failed" in r.lower() for r in data["risks"])
    assert any(s["type"] == "answer_audit" for s in data["steps"])


def test_reasoning_field_is_captured_on_model_response_step(tmp_path):
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")

    def thinking_llm(*, messages, tools):
        _ = messages, tools
        return {
            "text": "the answer",
            "reasoning": "I considered A and B and chose B because...",
            "usage": {"input_tokens": 10, "output_tokens": 3},
        }

    trace, _ = tracer.run("any question", llm_callable=thinking_llm)
    response_step = next(s for s in trace["steps"] if s["type"] == "model_response")
    assert response_step["reasoning"] == "I considered A and B and chose B because..."
    assert trace["reasoning"] == ["I considered A and B and chose B because..."]


def test_missing_reasoning_does_not_set_top_level_field(tmp_path):
    """Backwards compat: callables that don't return reasoning leave the trace clean."""
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")

    def plain_llm(*, messages, tools):
        _ = messages, tools
        return {"text": "answer", "usage": {}}

    trace, _ = tracer.run("any question", llm_callable=plain_llm)
    response_step = next(s for s in trace["steps"] if s["type"] == "model_response")
    assert "reasoning" not in response_step
    assert "reasoning" not in trace


def test_multi_hop_reasoning_accumulates_in_order(tmp_path):
    """When chat() is called multiple times, all reasoning strings are collected."""
    from llmtrace.schema import new_trace

    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")
    trace = new_trace(question="q", model="m")

    def hop(thought, label):
        def call(*, messages, tools):
            _ = messages, tools
            return {"text": label, "reasoning": thought, "usage": {"input_tokens": 5, "output_tokens": 2}}

        return call

    tracer.chat(messages=[{"role": "user", "content": "q"}], llm_callable=hop("first", "a"), trace=trace)
    tracer.chat(messages=[{"role": "user", "content": "q"}], llm_callable=hop("second", "b"), trace=trace)

    assert trace["reasoning"] == ["first", "second"]
    response_steps = [s for s in trace["steps"] if s["type"] == "model_response"]
    assert [s["reasoning"] for s in response_steps] == ["first", "second"]


def test_response_text_and_reasoning_capped_at_max_message_chars(tmp_path):
    """Long response text and reasoning are truncated using the same cap as messages."""
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m", max_message_chars=50)
    long_text = "x" * 500
    long_reasoning = "y" * 500

    def chatty(*, messages, tools):
        _ = messages, tools
        return {"text": long_text, "reasoning": long_reasoning, "usage": {}}

    trace, _ = tracer.run("q", llm_callable=chatty)
    response_step = next(s for s in trace["steps"] if s["type"] == "model_response")

    assert len(response_step["text"]) < 100, "response text should be capped"
    assert "[truncated," in response_step["text"]
    assert len(response_step["reasoning"]) < 100, "reasoning should be capped"
    assert "[truncated," in response_step["reasoning"]

    # final_answer (the return value of chat()) is NOT truncated — the cap
    # applies only to the trace snapshot.
    assert trace["final_answer"] == long_text


def test_stub_answer_does_not_trigger_analysis_without_evidence(tmp_path):
    """Default stub on a 'metric' question must not be flagged as an
    unsupported analytic claim — the stub explicitly disclaims tool use."""
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")
    trace, _ = tracer.run("why did revenue drop in March?")  # no llm_callable -> stub
    assert trace["final_answer"].startswith("[stub]")
    assert not any("analysis answer without evidence" in r.lower() for r in trace["risks"])
    audit = next(s for s in trace["steps"] if s["type"] == "answer_audit")["output"]
    assert audit["unsupported_claims"] == []
