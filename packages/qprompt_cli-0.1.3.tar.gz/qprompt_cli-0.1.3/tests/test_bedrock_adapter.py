"""Tests for the Bedrock content-block mapping. Does not import boto3."""
import importlib.util
import sys
from pathlib import Path


def _load_adapter():
    """Import bedrock_adapter.py without invoking boto3 (the import is local)."""
    path = Path(__file__).resolve().parent.parent / "examples" / "bedrock_adapter.py"
    spec = importlib.util.spec_from_file_location("bedrock_adapter", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules["bedrock_adapter"] = module
    spec.loader.exec_module(module)
    return module


def test_string_content_wrapped_as_block():
    adapter = _load_adapter()
    assert adapter._to_bedrock_content("hello") == [{"text": "hello"}]


def test_typed_text_block_passes_through():
    adapter = _load_adapter()
    out = adapter._to_bedrock_content([{"type": "text", "text": "hello"}])
    assert out == [{"text": "hello"}]


def test_text_only_dict_block_passes_through():
    adapter = _load_adapter()
    out = adapter._to_bedrock_content([{"text": "world"}])
    assert out == [{"text": "world"}]


def test_mixed_blocks_extracted_in_order():
    adapter = _load_adapter()
    out = adapter._to_bedrock_content(
        [{"type": "text", "text": "a"}, {"text": "b"}, "c"]
    )
    assert out == [{"text": "a"}, {"text": "b"}, {"text": "c"}]


def test_unknown_block_shape_does_not_corrupt_with_repr():
    """A list with an image block should NOT produce a repr-stringified output."""
    adapter = _load_adapter()
    out = adapter._to_bedrock_content(
        [{"type": "text", "text": "hi"}, {"type": "image", "source": "..."}]
    )
    # Image block is dropped (rather than repr'd) — text block survives intact.
    assert out == [{"text": "hi"}]


def test_empty_list_yields_single_empty_block():
    adapter = _load_adapter()
    assert adapter._to_bedrock_content([]) == [{"text": ""}]


def test_extract_reasoning_text_block():
    adapter = _load_adapter()
    content = [
        {"reasoningContent": {"reasoningText": {"text": "I think...", "signature": "sig"}}},
        {"text": "the answer"},
    ]
    assert adapter._extract_reasoning(content) == "I think..."


def test_extract_reasoning_redacted_block():
    adapter = _load_adapter()
    content = [{"reasoningContent": {"redactedContent": b"opaque"}}]
    assert adapter._extract_reasoning(content) == "[redacted reasoning block]"


def test_extract_reasoning_empty_when_no_blocks():
    adapter = _load_adapter()
    assert adapter._extract_reasoning([{"text": "just answer"}]) == ""


def test_extract_reasoning_concatenates_multiple_blocks():
    adapter = _load_adapter()
    content = [
        {"reasoningContent": {"reasoningText": {"text": "first thought"}}},
        {"reasoningContent": {"reasoningText": {"text": "second thought"}}},
        {"text": "answer"},
    ]
    assert adapter._extract_reasoning(content) == "first thought\n\nsecond thought"
