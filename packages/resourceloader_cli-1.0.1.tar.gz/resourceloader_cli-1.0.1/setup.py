from setuptools import setup, find_packages

setup(
    name="resourceloader-cli",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[
        "requests",
        "numpy",
        "pandas",
        "matplotlib",
        "scikit-learn",
        "nltk",
    ],
    extras_require={
        "dl": ["torch", "tensorflow"],
        "all": ["torch", "tensorflow", "gensim"],
    },
    entry_points={
        "console_scripts": [
            "mycodes=mycodes.cli:main"
        ]
    },
    author="Jhony",
    description="CLI tool to download DL, NLP, and HPC codes",
    python_requires=">=3.7",
)