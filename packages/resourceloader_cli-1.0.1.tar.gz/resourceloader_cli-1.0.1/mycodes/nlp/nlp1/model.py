import nltk

nltk.download('punkt')
nltk.download('wordnet')
nltk.download('omw-1.4')
# nltk.download('all')
# Different Tokenizers
sentence = "If you want to know what a man’s like, take a good looks at how he treats his inferiors, not his equals. It is our choices, Harry, that show what we truly are, far more than our abilities!"
## 1. WhiteSpace Tokenization
from nltk.tokenize import WhitespaceTokenizer
whitespace_tokenized = WhitespaceTokenizer().tokenize(sentence)
print(whitespace_tokenized)

## 2. TreeBankWord Tokenization
from nltk.tokenize import TreebankWordTokenizer
treebank_tokenized = TreebankWordTokenizer().tokenize(sentence)
print(treebank_tokenized)
## 3. MWE Tokenization
from nltk.tokenize import MWETokenizer
from nltk.tokenize import wordpunct_tokenize

mwe_tokenizer = MWETokenizer([('take', 'a', 'good'), ('Harry',)])
mwe_tokenized = mwe_tokenizer.tokenize(wordpunct_tokenize(sentence))
print(mwe_tokenized)
## 4. Tweet Tokenization
from nltk.tokenize import TweetTokenizer
tweet_tokenized = TweetTokenizer().tokenize(sentence)
print(tweet_tokenized)
## 5. Punctuation Based Word Tokenization
from nltk.tokenize import wordpunct_tokenize
print(wordpunct_tokenize(sentence))
## 6. Punctuation Based Sentence Tokenization
sent_detector = nltk.data.load('tokenizers/punkt/english.pickle')
sent_tokenized = sent_detector.tokenize(sentence)
print(sent_tokenized)
# Different Stemming Techniques
## 1. SnowBallStemming
from nltk.stem.snowball import SnowballStemmer
snowballstemmer = SnowballStemmer(language='english')
stem_words = []
for w in tweet_tokenized:
    x = snowballstemmer.stem(w)
    stem_words.append(x)
print('Before Snowball Stemming')
print(tweet_tokenized,'\n')

print('After Snowball Stemming')
print(stem_words)

## 2. Porter Stemming
from nltk.stem import PorterStemmer
porterstemmer = PorterStemmer()
stem_words = []
for w in tweet_tokenized:
    x = porterstemmer.stem(w)
    stem_words.append(x)
print('Before Potter Stemming')
print(tweet_tokenized,'\n')

print('After Potter Stemming')
print(stem_words)

# Lemmatization
from nltk.stem import WordNetLemmatizer

wordnet_lemmatizer = WordNetLemmatizer()
lemma_words = []
for w in tweet_tokenized:
    x = wordnet_lemmatizer.lemmatize(w)
    lemma_words.append(x)
print('Before Lemmatization')
print(tweet_tokenized, '\n')

print('After Lemmatization')
print(lemma_words)