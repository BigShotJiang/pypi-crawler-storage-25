"""Natural Language Processing practicals"""

from .nlp1.model import *
from .nlp2.dataset import download_data as nlp2_download
from .nlp2.model import *
from .nlp3.dataset import download_data as nlp3_download
from .nlp3.model import *
from .nlp4.model import *

__all__ = ["nlp2_download", "nlp3_download"]
