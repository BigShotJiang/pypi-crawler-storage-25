# =========================================
# 1. IMPORT LIBRARIES
# =========================================
import pandas as pd
import numpy as np
import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder

import nltk
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('punkt')

from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
# =========================================
# 2. LOAD DATASET (IMPORTANT PATH)
# =========================================
df = pd.read_pickle("C:/Users/vishw/Downloads/News_dataset.pickle")

print("Dataset Preview:")
print(df.head())

print("\nColumns:")
print(df.columns)
# =========================================
# 3. TEXT CLEANING FUNCTION
# =========================================
def clean_text(text):
    text = str(text)
    text = text.lower()
    text = re.sub(r'[^a-z\s]', '', text)   # remove punctuation & numbers
    return text
df.loc[1]['Content']
# 4. STOPWORDS + LEMMATIZATION
# =========================================
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def preprocess_text(text):
    words = word_tokenize(text)
    
    words = [lemmatizer.lemmatize(word) 
             for word in words 
             if word not in stop_words]
    
    return " ".join(words)
# =========================================
# 5. APPLY PREPROCESSING
# =========================================
le = LabelEncoder()
label_col = 'Category'
df['clean_text'] = df['Content'].apply(clean_text)
df['label_encoded'] = le.fit_transform(df[label_col])
df['final_text'] = df['clean_text'].apply(preprocess_text)

print("\nProcessed Text Sample:")
print(df[['Content', 'final_text']].head())
# 4. STOPWORDS + LEMMATIZATION
# =========================================
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def preprocess_text(text):
    words = word_tokenize(text)
    
    words = [lemmatizer.lemmatize(word) 
             for word in words 
             if word not in stop_words]
    
    return " ".join(words)
# =========================================
# 5. APPLY PREPROCESSING
# =========================================
df['clean_text'] = df['Content'].apply(clean_text)
df['final_text'] = df['clean_text'].apply(preprocess_text)

print("\nProcessed Text Sample:")
print(df[['Content', 'final_text']].head())
# =========================================
# 6. LABEL ENCODING
# =========================================
le = LabelEncoder()
df['label_encoded'] = le.fit_transform(df['Category'])

print("\nEncoded Labels:")
print(df[[label_col, 'label_encoded']].head())
# =========================================
# 7. TF-IDF REPRESENTATION
# =========================================
tfidf = TfidfVectorizer(max_features=5000)

X_tfidf = tfidf.fit_transform(df['final_text'])

print("\nTF-IDF Shape:", X_tfidf.shape)
# =========================================
# 8. SAVE OUTPUT FILES
# =========================================

# Save cleaned dataset
df.to_csv("cleaned_news_dataset.csv", index=False)

# Save TF-IDF features
tfidf_df = pd.DataFrame(
    X_tfidf.toarray(),
    columns=tfidf.get_feature_names_out()
)

tfidf_df.to_csv("tfidf_features.csv", index=False)

print("\n✅ Files saved successfully!")