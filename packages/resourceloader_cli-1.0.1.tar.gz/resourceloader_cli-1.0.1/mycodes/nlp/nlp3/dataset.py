import os
import requests

DATASETS = {
    "cleaned_news_dataset": {
        "url": "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-VI/NLP/NLP3/cleaned_news_dataset.csv",
        "filename": "cleaned_news_dataset.csv"
    },
    "tfidf_features": {
        "url": "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-VI/NLP/NLP3/tfidf_features.csv",
        "filename": "tfidf_features.csv"
    },
    "news_dataset": {
        "url": "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-VI/NLP/NLP3/News_dataset.pickle",
        "filename": "News_dataset.pickle"
    }
}

def download_data(name, save_dir="data"):
    if name not in DATASETS:
        print("Dataset not found")
        return

    dataset = DATASETS[name]

    url = dataset["url"]
    filename = dataset["filename"]

    path = os.path.join(os.getcwd(), save_dir, filename)

    if os.path.exists(path):
        print(f"{name} already exists")
        return path

    os.makedirs(os.path.dirname(path), exist_ok=True)

    print(f"Downloading {name}...")
    r = requests.get(url)

    with open(path, "wb") as f:
        f.write(r.content)

    print("Saved at:", path)
    return path