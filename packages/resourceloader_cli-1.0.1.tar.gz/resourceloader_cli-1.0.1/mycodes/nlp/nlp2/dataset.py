import os
import requests

URL = "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-VI/NLP/NLP2/Car_Dataset.csv"

PATH = os.path.join(os.getcwd(), "data", "car.csv")

def download_data():
    if os.path.exists(PATH):
        print("Already exists")
        return PATH

    os.makedirs(os.path.dirname(PATH), exist_ok=True)

    r = requests.get(URL)

    with open(PATH, "wb") as f:
        f.write(r.content)

    return PATH