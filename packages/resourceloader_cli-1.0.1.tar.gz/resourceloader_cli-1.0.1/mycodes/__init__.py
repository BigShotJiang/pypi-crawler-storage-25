"""
MyCode CLI - Download DL, NLP, and HPC practicals
"""

from .cli import main
from .downloader import get_item

__all__ = ["main", "get_item"]
__version__ = "1.0"
