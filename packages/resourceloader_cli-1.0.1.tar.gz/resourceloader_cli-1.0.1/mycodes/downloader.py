# downloader.py

from mycodes.dl.boston import download_data as boston_data
from mycodes.nlp.nlp2 import download_data as nlp2_data
from mycodes.hpc.dataset import download_cpp, CPP_FILES

# 🔹 Category-wise items
DL_ITEMS = {
    "boston": boston_data,
    # add more DL here
}

NLP_ITEMS = {
    "nlp2": nlp2_data,
    # add more NLP here
}

HPC_ITEMS = CPP_FILES  # already dict


# 🔹 Menu function
def show_menu(items, title):
    print(f"\nSelect a {title} project:")

    keys = list(items.keys())

    for i, key in enumerate(keys, 1):
        print(f"{i}. {key}")

    try:
        choice = int(input("Enter choice number: "))
    except:
        print("Invalid input")
        return None

    if 1 <= choice <= len(keys):
        return keys[choice - 1]
    else:
        print("Invalid choice")
        return None


# 🔹 Main function
def get_item(name):

    # ===== DL =====
    if name == "dl":
        selected = show_menu(DL_ITEMS, "DL")
        if selected:
            return DL_ITEMS[selected]()
        return None

    # ===== NLP =====
    elif name == "nlp":
        selected = show_menu(NLP_ITEMS, "NLP")
        if selected:
            return NLP_ITEMS[selected]()
        return None

    # ===== HPC =====
    elif name == "hpc":
        selected = show_menu(HPC_ITEMS, "HPC")
        if selected:
            return download_cpp(selected)
        return None

    # ===== Direct Calls =====
    elif name in DL_ITEMS:
        return DL_ITEMS[name]()

    elif name in NLP_ITEMS:
        return NLP_ITEMS[name]()

    elif name in HPC_ITEMS:
        return download_cpp(name)

    else:
        print("Not found")
        return None