import os
import requests

CPP_FILES = {
    "1bfs": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/1_BFS_DFS.cpp",
        "filename": "bfs_dfs.cpp"
    },
    "2bubblemerge": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/2_parallel_bubble_merge.cpp",
        "filename": "parallel_bubble_merge.cpp"
    },
    "3parallelreduction": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/3_parallel_reduction.cu",
        "filename": "reduction.cu"
    },
    "4matrixmultiplication": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/4_matrix_multiplication.cu",
        "filename": "matrix_multiplication.cu"
    },
    "4vectoraddition": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/4_vector_addition.cu",
        "filename": "vector_addition.cu"
    },
    "5mandelbrot": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/5_mandelbrot_numba.py",
        "filename": "mandelbrot_numba.py"
    }


}

def download_cpp(name, save_dir="data"):
    if name not in CPP_FILES:
        print("File not found")
        return

    file = CPP_FILES[name]
    path = os.path.join(os.getcwd(), save_dir, file["filename"])

    if os.path.exists(path):
        print("Already exists")
        return path

    os.makedirs(os.path.dirname(path), exist_ok=True)

    print(f"Downloading {file['filename']}...")
    r = requests.get(file["url"])

    if r.status_code != 200:
        print("Download failed")
        return

    with open(path, "wb") as f:
        f.write(r.content)

    print("Saved at:", path)
    return path