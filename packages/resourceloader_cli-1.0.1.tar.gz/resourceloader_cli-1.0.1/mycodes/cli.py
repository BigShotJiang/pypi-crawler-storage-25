# cli.py

import sys
from .downloader import get_item


def main():
    """Main CLI entry point"""
    if len(sys.argv) < 3:
        print("Usage: mycodes get <dl|nlp|hpc> [name]")
        print("       mycodes get dl [boston|imdb|stock]")
        print("       mycodes get nlp [nlp2|nlp3]")
        print("       mycodes get hpc [1bfs|2bubblemerge|...]")
        sys.exit(1)

    command = sys.argv[1]
    name = sys.argv[2]

    if command == "get":
        try:
            result = get_item(name)
            if result:
                print(f"Success: {result}")
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"Invalid command: {command}")
        print("Available commands: get")
        sys.exit(1)


if __name__ == "__main__":
    main()
