"""Deep Learning practicals"""

from .boston.dataset import download_data as boston_download
from .imdb.dataset import download_data as imdb_download
from .stock.dataset import download_data as stock_download

__all__ = ["boston_download", "imdb_download", "stock_download"]
