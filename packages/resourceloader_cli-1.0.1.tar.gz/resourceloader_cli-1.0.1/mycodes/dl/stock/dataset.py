import os
import requests

URL = "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/DL/4.Google_Stock_Price/Google_Stock_Price.csv"

PATH = os.path.join(os.getcwd(), "data", "stock.csv")

def download_data():
    if os.path.exists(PATH):
        print("Already exists")
        return PATH

    os.makedirs(os.path.dirname(PATH), exist_ok=True)

    r = requests.get(URL)

    with open(PATH, "wb") as f:
        f.write(r.content)

    return PATH