import os
import requests

URL = "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-V/DL/2.IMDB/IMDB_Dataset.csv"

PATH = os.path.join(os.getcwd(), "data", "imdb.csv")

def download_data():
    if os.path.exists(PATH):
        print("Already exists")
        return PATH

    os.makedirs(os.path.dirname(PATH), exist_ok=True)

    r = requests.get(URL)

    with open(PATH, "wb") as f:
        f.write(r.content)

    return PATH