from typing import Generic, List, Self, cast

import numpy as np
from agentic_base.dataset.polars import PolarsTextDataset
from agentic_base.evaluation.evaluators.python import PythonEvaluator
from agentic_base.evaluation.retrievers.dense import DenseRetriever
from agentic_base.evaluation.settings import (
    BM25EvaluatorSettings,
    HybridRetrieverEvaluatorSettings,
    QdrantEvaluatorSettings,
)
from agentic_base.evaluation.vector_stores import FaissVectorStore
from agentic_base.types import TCFaissEvaluator, TCPythonDenseEvaluator
from langchain_core.documents import Document


class DensePythonEvaluator(PythonEvaluator[TCPythonDenseEvaluator]):

    def __init__(self, config: TCPythonDenseEvaluator) -> None:
        super().__init__(config)
        if not isinstance(self.retriever, DenseRetriever):
            raise TypeError(
                f"{self.__class__.__name__} requires a DenseRetriever, " f"got {type(self.retriever).__name__} instead."
            )


class QdrantPythonEvaluator(DensePythonEvaluator[QdrantEvaluatorSettings]):
    def __init__(self, config: QdrantEvaluatorSettings):
        super().__init__(config)


class FaissPythonEvaluator(DensePythonEvaluator[TCFaissEvaluator], Generic[TCFaissEvaluator]):
    def __init__(self, config: TCFaissEvaluator):
        super().__init__(config)

    @classmethod
    async def create(cls, config: TCFaissEvaluator) -> Self:
        self = cls(config)
        docs = self.get_docs()
        texts = [d.page_content for d in docs]
        embeddings = np.asarray(
            await self.retriever.embedder.aembed_documents(texts, processor=self.retriever.processor),  # type: ignore[attr-defined]
            dtype="float32",
        )
        vector_store = cast(FaissVectorStore, self.retriever.vector_store)  # type: ignore[attr-defined]
        vector_store.index = vector_store.build_faiss_index(embeddings.shape[-1])
        vector_store.add_documents(docs, embeddings)
        return self

    def get_docs(self) -> List[Document]:
        docs_idx = []
        seen = set()
        for i, row in enumerate(self.dataset.iter_rows(named=True)):
            doc_id = row["metadata"]["doc_id"]
            if doc_id not in seen:
                seen.add(doc_id)
                docs_idx.append(i)
        return PolarsTextDataset(self.dataset.polars[docs_idx]).to_langchain_documents()


class BM25Evaluator(PythonEvaluator[BM25EvaluatorSettings]):
    def __init__(self, config: BM25EvaluatorSettings) -> None:
        super().__init__(config)


class HybridRetrieverEvaluator(PythonEvaluator[HybridRetrieverEvaluatorSettings]):
    def __init__(self, config: HybridRetrieverEvaluatorSettings) -> None:
        super().__init__(config)
