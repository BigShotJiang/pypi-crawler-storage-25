import logging
from abc import ABC, abstractmethod
from typing import (
    Any,
    Coroutine,
    Dict,
    Generic,
    Iterator,
    List,
    Optional,
    Tuple,
    overload,
)

import numpy as np
from agentic_base.evaluation import VectorStore
from agentic_base.evaluation.evaluators import Evaluator
from agentic_base.evaluation.settings import ScoreSettings
from agentic_base.mixins import FromConfigMixin
from agentic_base.types import TCPythonEvaluator, TCScore
from agentic_base.utils import load_class
from pydantic import BaseModel
from tqdm.asyncio import tqdm_asyncio

_logger = logging.getLogger(__name__)


class Score(FromConfigMixin[TCScore], ABC, Generic[TCScore]):

    class ScoreResult(BaseModel):
        name: str
        value: float

    def __init__(self, config: TCScore) -> None:
        self.config = config
        _logger.info(f"Initialized Score | class={self.__class__.__name__} | config={config}")

    @overload
    def __call__(self, hits: List[bool]) -> List[ScoreResult]: ...

    @overload
    def __call__(self, hits: List[bool], total_relevant: int) -> List[ScoreResult]: ...

    # ---- runtime ----
    @abstractmethod
    def __call__(
        self,
        hits: List[bool],
        total_relevant: Optional[int] = None,
    ) -> List[ScoreResult]:
        raise NotImplementedError()


class PythonEvaluator(Evaluator[TCPythonEvaluator], ABC, Generic[TCPythonEvaluator]):

    NB_LOGS_PER_QUERIES = 100
    BATCH_SIZE = 96

    def __init__(self, config: TCPythonEvaluator) -> None:
        super().__init__(config)
        self.scores: List[Score[ScoreSettings]] = [load_class(s.module_path)(s) for s in self.config.scores]
        _logger.info(
            f"Evaluator ready | dataset_size={len(self.dataset)} | " f"scores={[type(s).__name__ for s in self.scores]}"
        )

    def batch_iter(self) -> Iterator[List[Dict[str, Any]]]:
        batch: List[Dict[str, Any]] = []
        for row in self.dataset.iter_rows(named=True):
            batch.append(row)
            if len(batch) == self.BATCH_SIZE:
                yield batch
                batch = []
        if batch:
            yield batch

    def _get_max_k(self) -> int:
        return max(max(score.config.ks) for score in self.scores)

    def _build_retrieval_tasks(
        self, max_k: int
    ) -> Tuple[List[List[Dict[str, Any]]], List[Coroutine[Any, Any, List[VectorStore.QueryResponse]]]]:
        tasks: List[Coroutine[Any, Any, List[VectorStore.QueryResponse]]] = []
        batches: List[List[Dict[str, Any]]] = []

        for batch in self.batch_iter():
            queries = [sample["metadata"]["query"] for sample in batch]
            task = self.retriever.retrieve_batch(queries, limit=self.config.limit, final_limit=max_k)
            tasks.append(task)
            batches.append(batch)

        return batches, tasks

    async def _collect_responses(
        self, tasks: List[Coroutine[Any, Any, List[VectorStore.QueryResponse]]]
    ) -> List[List[VectorStore.QueryResponse]]:
        return await tqdm_asyncio.gather(
            *tasks,
            desc="Evaluating batches",
        )

    def _score_batches(
        self,
        batches: List[List[Dict[str, Any]]],
        responses: List[List[VectorStore.QueryResponse]],
    ) -> List[Dict[str, float]]:

        scores_all: List[Dict[str, float]] = []
        processed = 0

        for batch, batch_responses in zip(batches, responses):
            for sample, response in zip(batch, batch_responses):
                hits = [p.document.page_content == sample["page_content"] for p in response.points]
                row_scores: Dict[str, float] = {}
                for score in self.scores:
                    results = score(hits, total_relevant=1)
                    for r in results:
                        row_scores[r.name] = r.value
                scores_all.append(row_scores)
                processed += 1
                if processed % self.NB_LOGS_PER_QUERIES == 0:
                    _logger.info(f"Progress {processed}/{len(self.dataset)}")
        return scores_all

    def _aggregate_scores(
        self,
        scores_all: List[Dict[str, float]],
    ) -> Dict[str, float]:

        if not scores_all:
            return {}

        # collect all metric names
        metric_names = scores_all[0].keys()

        results: Dict[str, float] = {}

        for name in metric_names:
            values = [row[name] for row in scores_all]
            results[name] = float(np.mean(values))

        return results

    async def eval(self) -> Dict[str, float]:
        max_k = self._get_max_k()
        _logger.info(f"Starting Dense evaluation | max_k={max_k}")
        batches, tasks = self._build_retrieval_tasks(max_k)
        responses = await self._collect_responses(tasks)
        scores_all = self._score_batches(batches, responses)
        return self._aggregate_scores(scores_all)
