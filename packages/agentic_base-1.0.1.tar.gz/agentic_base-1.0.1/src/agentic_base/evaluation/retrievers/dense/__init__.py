import asyncio
import logging
from typing import Any, Generic, List, Optional

from agentic_base.evaluation import Embedder, Processor, VectorStore
from agentic_base.evaluation.retrievers import Retriever
from agentic_base.types import TCDenseRetriever
from agentic_base.utils import load_class

_logger = logging.getLogger(__name__)


class DenseRetriever(Retriever[TCDenseRetriever], Generic[TCDenseRetriever]):

    def __init__(self, config: TCDenseRetriever) -> None:
        super().__init__(config)
        _logger.info(f"Initializing Retriever | class={self.__class__.__name__}")

        self.embedder: Embedder[Any] = load_class(self.config.embedder.module_path).from_config(self.config.embedder)

        self.vector_store: VectorStore[Any] = load_class(self.config.vector_store.module_path).from_config(
            self.config.vector_store
        )

        self.processor: Processor[Any] = load_class(self.config.processor.module_path).from_config(
            self.config.processor
        )

        _logger.info(
            f"Retriever initialized | embedder={type(self.embedder).__name__} | "
            f"vector_store={type(self.vector_store).__name__}"
        )

    async def retrieve_batch(
        self, queries: List[str], limit: int, final_limit: Optional[int] = None
    ) -> List[VectorStore.QueryResponse]:
        embedding = await self.embedder.aembed_queries(queries, self.processor)
        responses = await self.vector_store.abatch_query_points(embedding, limit)
        if self.reranker:
            if final_limit is None:
                raise ValueError("final_limit must be provided when a reranker is configured.")
            responses = await asyncio.gather(
                *[self.reranker.rerank(query, response, final_limit) for query, response in zip(queries, responses)]
            )
        return responses

    async def _retrieve(self, query: str, limit: int) -> VectorStore.QueryResponse:
        embedding = await self.embedder.aembed_query(query, self.processor)
        return await self.vector_store.aquery_points(embedding, limit)

    async def aclose(self) -> None:
        await self.embedder.aclose()
        await self.vector_store.aclose()
