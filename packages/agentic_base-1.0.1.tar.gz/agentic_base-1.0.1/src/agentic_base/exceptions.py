from typing import List, Set


class AgenticBaseError(Exception):
    """Base exception for agentic-base package."""


class RerankerError(AgenticBaseError):
    """Generic reranker error."""


class RerankerHTTPError(RerankerError):
    """HTTP error when calling reranker."""

    def __init__(self, status_code: int, message: str, payload: dict | None = None):
        self.status_code = status_code
        self.message = message
        self.payload = payload
        super().__init__(f"[RerankerHTTPError] {status_code}: {message}")


class RerankerValidationError(RerankerError):
    """Raised when reranker rejects input (e.g., 422)."""

    def __init__(self, message: str, payload: dict | None = None):
        self.message = message
        self.payload = payload
        super().__init__(f"[RerankerValidationError] {message}")


class RerankerResponseFormatError(RerankerError):
    """Invalid response format from reranker."""

    def __init__(self, response: object):
        self.response = response
        super().__init__(f"[RerankerResponseFormatError] Invalid response: {response}")


class DatasetError(AgenticBaseError):
    pass


class DatasetSchemaError(DatasetError):
    def __init__(
        self,
        missing_columns: Set[str],
        available_columns: List[str],
        flattened_columns: List[str],
    ) -> None:
        self.missing_columns = missing_columns
        self.available_columns = available_columns
        self.flattened_columns = flattened_columns

        message = (
            f"Missing columns: {missing_columns}\n"
            f"Available columns (top-level): {available_columns}\n"
            f"Available columns (flattened): {flattened_columns}"
        )

        super().__init__(message)


class AgenticValueError(AgenticBaseError, ValueError):
    """Invalid value in agentic-base."""
