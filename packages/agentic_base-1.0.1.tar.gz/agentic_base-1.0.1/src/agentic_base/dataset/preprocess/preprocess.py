from typing import Any, List

import polars as pl
from agentic_base.dataset import TextDataset
from agentic_base.dataset.preprocess import TextPreprocessor, TokenCounter
from agentic_base.dataset.settings import (
    MaxTokenFilterSettings,
    MinTokenFilterSettings,
    PreprocessPipelineSettings,
    QuantileTokenFilterSettings,
    SigmaBandTokenFilterSettings,
)
from agentic_base.utils import load_class


class MinTokenFilter(TextPreprocessor[MinTokenFilterSettings[Any]]):

    def __init__(self, config: MinTokenFilterSettings[Any]):
        super().__init__(config)
        self.token_counter: TokenCounter[Any] = load_class(self.config.token_counter.module_path).from_config(
            self.config.token_counter
        )

    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        return ds.__class__.from_polars(
            ds.polars.with_columns(pl.col("page_content").map_elements(self.token_counter.count).alias("n_tokens"))
            .filter(pl.col("n_tokens") >= self.config.min_tokens)
            .drop("n_tokens")
        )


class MaxTokenFilter(TextPreprocessor[MaxTokenFilterSettings[Any]]):
    def __init__(self, config: MaxTokenFilterSettings[Any]):
        super().__init__(config)
        self.token_counter: TokenCounter[Any] = load_class(self.config.token_counter.module_path).from_config(
            self.config.token_counter
        )

    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        return ds.__class__.from_polars(
            ds.polars.with_columns(pl.col("page_content").map_elements(self.token_counter.count).alias("n_tokens"))
            .filter(pl.col("n_tokens") <= self.config.max_tokens)
            .drop("n_tokens")
        )


class QuantileTokenFilter(TextPreprocessor[QuantileTokenFilterSettings[Any]]):
    def __init__(self, config: QuantileTokenFilterSettings[Any]):
        super().__init__(config)
        self.token_counter: TokenCounter[Any] = load_class(self.config.token_counter.module_path).from_config(
            self.config.token_counter
        )

    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        df = ds.polars.with_columns(pl.col("page_content").map_elements(self.token_counter.count).alias("n_tokens"))
        cutoff = df.select(pl.col("n_tokens").quantile(self.config.q)).item()
        return ds.__class__.from_polars(df.filter(pl.col("n_tokens") <= cutoff).drop("n_tokens"))


class SigmaBandTokenFilter(TextPreprocessor[SigmaBandTokenFilterSettings[Any]]):
    def __init__(self, config: SigmaBandTokenFilterSettings[Any]):
        super().__init__(config)
        self.token_counter: TokenCounter[Any] = load_class(self.config.token_counter.module_path).from_config(
            self.config.token_counter
        )

    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        df = ds.polars.with_columns(pl.col("page_content").map_elements(self.token_counter.count).alias("n_tokens"))
        mu, sigma = df.select(
            pl.col("n_tokens").mean(),
            pl.col("n_tokens").std(),
        ).row(0)
        return ds.__class__.from_polars(
            df.filter(pl.col("n_tokens").is_between(mu - self.config.z * sigma, mu + self.config.z * sigma)).drop(
                "n_tokens"
            )
        )


class PreprocessPipeline(TextPreprocessor[PreprocessPipelineSettings]):

    def __init__(self, config: PreprocessPipelineSettings):
        super().__init__(config)
        self.steps = self._load_steps()

    def _load_steps(self) -> List[TextPreprocessor[Any]]:
        steps = []
        for step_config in self.config.steps:
            step: TextPreprocessor[Any] = load_class(step_config.module_path)(step_config)
            steps.append(step)
        return steps

    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        current = ds
        for step in self.steps:
            current = step.apply(current)
        return current
