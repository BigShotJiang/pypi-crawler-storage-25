from typing import Dict, Generic, List, Literal, Optional, Union

from agentic_base.settings import FromConfigMixinSettings
from agentic_base.types import TCDatasetConnector, TCTextPreprocessor, TCTokenCounter


class TextPreprocessorSettings(FromConfigMixinSettings):
    kind: str


class TokenCounterSettings(FromConfigMixinSettings):
    pass


class HeuristicTokenCounterSettings(TokenCounterSettings):
    chars_per_token: int


class HuggingFaceTokenCounterSettings(TokenCounterSettings):
    name: str
    add_special_tokens: bool
    revision: Optional[str]


class TokenFilterSettings(TextPreprocessorSettings, Generic[TCTokenCounter]):
    token_counter: TCTokenCounter


class MinTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    kind: Literal["min_tokens"]
    min_tokens: int


class MaxTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    kind: Literal["max_tokens"]
    max_tokens: int


class QuantileTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    kind: Literal["quantile"]
    q: float


class SigmaBandTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    kind: Literal["sigma"]
    z: float


BaseTextPreprocessorUnion = Union[
    MinTokenFilterSettings[HuggingFaceTokenCounterSettings],
    MaxTokenFilterSettings[HuggingFaceTokenCounterSettings],
    QuantileTokenFilterSettings[HuggingFaceTokenCounterSettings],
    SigmaBandTokenFilterSettings[HuggingFaceTokenCounterSettings],
]


class PreprocessPipelineSettings(TextPreprocessorSettings, Generic[TCTextPreprocessor]):
    kind: Literal["steps"]
    steps: List[TCTextPreprocessor]


class HuggingFaceDatasetAdaptaterSettings(FromConfigMixinSettings, Generic[TCDatasetConnector]):
    connector: TCDatasetConnector
    columns_mapping: Dict[str, str]
