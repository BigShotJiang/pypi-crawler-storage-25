from .node_serie import NodeSerie
import logging
from a5client import Crud, observacionesListToDataFrame, createEmptyObsDataFrame
from .node_serie_prono_metadata import NodeSeriePronoMetadata
from .config import config
from datetime import datetime
import pytz
from .descriptors.string_descriptor import StringDescriptor
from .descriptors.datetime_descriptor import DatetimeDescriptor
from .descriptors.int_descriptor import IntDescriptor
from .descriptors.list_descriptor import ListDescriptor
from .util import coalesce
from typing import Optional, cast
from .types.api_config_dict import ApiConfigDict
from a5client.util_types import Dateable, TVPGroupedByQualifier
from a5client.util import tryParseAndLocalizeDate

input_crud = Crud(**config["input_api"])
# output_crud = Crud(**config["output_api"])


class NodeSerieProno(NodeSerie):
    """Forecasted timeseries"""

    @property
    def metadata(self) -> Optional[dict]:
        """series metadata"""
        return self._metadata.to_dict() if self._metadata is not None else None
    
    @metadata.setter
    def metadata(
        self,
        metadata : Optional[dict]
    ) -> None:
        if metadata is not None:
            if "id" in metadata:
                metadata["series_id"] = metadata["id"]
                del metadata["id"]
            if "tipo" in metadata:
                metadata["series_table"] = self.getSeriesTable()
                del metadata["tipo"]
        self._metadata = NodeSeriePronoMetadata(**metadata) if metadata is not None else None
    
    main_qualifier = StringDescriptor()
    """If qualifier == 'all', select this qualifier as the main qualifier"""

    previous_runs_timestart = DatetimeDescriptor()
    """If set, retrieves previous forecast runs with forecast_date posterior to the chosen date and concatenates the results into a single series"""
    
    forecast_timestart = DatetimeDescriptor()
    """Begin date of last forecast run. If last forecast date is older than this value, it raises an error"""

    @property
    def adjust_results_string(self) -> Optional[str]:
        if self.adjust_results is not None:
            if self.adjust_results["method"] == "lfit":
                return "r2: %.04f, y = %.05f + %.05f x" % (self.adjust_results["r2"], self.adjust_results["intercept"], self.adjust_results["coef"][0])
            elif self.adjust_results["method"] == "arima":
                return "mse: %.2e, const: %.04f, ar.L1: %.04f, ma.L1: %.04f, sigma2: %.04f" % (
                    self.adjust_results["mse"],
                    self.adjust_results["const"],
                    self.adjust_results["ar.L1"],
                    self.adjust_results["ma.L1"],
                    self.adjust_results["sigma2"]
                )
            else:
                return None
        else:
            return None
    
    @property
    def adjust_result_dict(self) -> Optional[dict]:
        if self.adjust_results is not None:
            if self.adjust_results["method"] == "lfit":
                return {
                    "quant_Err": self.adjust_results["quant_Err"].to_dict(),
                    "r2": self.adjust_results["r2"],
                    "coef": [x for x in self.adjust_results["coef"]],
                    "intercept": self.adjust_results["intercept"]
                }
            elif self.adjust_results["method"] == "arima":
                return {
                    "quant_Err": self.adjust_results["quant_Err"].to_dict(),
                    "mse": self.adjust_results["mse"],
                    "const": self.adjust_results["const"],
                    "ar.L1": self.adjust_results["ar.L1"],
                    "ma.L1": self.adjust_results["ma.L1"],
                    "sigma2": self.adjust_results["sigma2"]
                }
            else:
                return None
        else:
            return None

    warmup = IntDescriptor()

    tail = IntDescriptor()

    sim_range = ListDescriptor()

    def __init__(
        self,
        cal_id : int,
        qualifier : Optional[str] = None,
        adjust : bool = False,
        plot_params : Optional[dict] = None,
        upload : bool = True,
        cor_id : Optional[int] = None,
        main_qualifier : Optional[str] = None,
        previous_runs_timestart : Optional[Dateable] = None,
        forecast_timestart : Optional[Dateable] = None,
        warmup : Optional[int] = None,
        tail : Optional[int] = None,
        sim_range : Optional[int] = None,
        **kwargs):
        super().__init__(**kwargs)        
        self.cal_id : int = cal_id
        """Identifier of simulation procedure configuration at the source (input api)"""
        self.qualifier : Optional[str] = qualifier
        """Forecast qualifier at the source. Used to identify multiple timeseries of the same variable at the same node simulated by the same procedure. For example, the members of an ensemble simulation."""
        self.main_qualifier = main_qualifier
        self.adjust : bool = adjust
        """By means of a linear regression, adjust the forecasted timeseries to the observations (if available)"""
        self.cor_id : Optional[int] = cor_id
        """Identifier of simulation procedure run"""
        self.forecast_date : Optional[datetime] = None
        """Date of production of the simulation"""
        self.adjust_results : Optional[dict] = None
        """Model resultant of the adjustment procedure"""
        self.name : str = "cal_id: %i, %s" % (self.cal_id if self.cal_id is not None else 0, self.qualifier if self.qualifier is not None else "main")
        """Name of the forecasted series"""
        self.plot_params : Optional[dict] = plot_params
        """Plot configuration parameters"""
        if self.plot_params is not None and "output_file" in self.plot_params:
            self.plot_params["output_file"] = self.resolve_path(self.plot_params["output_file"])
        self.metadata = None
        """Forecasted series metadata"""
        self.upload : bool = bool(upload)
        """If True, include this series when uploading the analysis results to the output api"""
        self.previous_runs_timestart = previous_runs_timestart
        self.forecast_timestart = forecast_timestart
        self.warmup = warmup
        self.tail = tail
        self.sim_range = sim_range

    def loadData(
        self,
        timestart : Dateable,
        timeend : Dateable,
        input_api_config : Optional[ApiConfigDict] = None,
        no_metadata : bool = False,
        tag : str = "sim",
        previous_runs_timestart : Optional[datetime] = None,
        forecast_timestart : Optional[datetime] = None 
        ) -> None:
        """Load forecasted data from source (input api). Retrieves forecast from input api using series_id, cal_id, timestart, and timeend
        
        Parameters:
        -----------
        timestart : datetime
            Begin time of forecast
        
        timeend : datetime
            End time of forecast
        
        input_api_config : dict
            Api connection parameters. Overrides global config.input_api
            
            Properties:
            - url : str
            - token : str
            - proxy_dict : dict
        
        tag : str = "sim"
            Tag forecast records with this string
        
        previous_runs_timestart = DatetimeDescriptor()
            If set, retrieves previous forecast runs with forecast_date posterior to the chosen date and concatenates the results into a single series
        
        forecast_timestart : datetime = None
            Forecast date must be greater or equal to this value"""
        timestart = tryParseAndLocalizeDate(timestart)
        timeend = tryParseAndLocalizeDate(timeend)
        previous_runs_timestart = coalesce(previous_runs_timestart,self.previous_runs_timestart)
        forecast_timestart = coalesce(forecast_timestart, self.forecast_timestart)
        if self.observations is not None or self.csv_file is not None or self.json_file is not None:
            super().loadData(timestart, timeend, tag = "sim")
            # self.data = observacionesListToDataFrame(self.observations, tag = "sim")
            if self.metadata is None:
                self.metadata = {"cal_id": self.cal_id}
            else:
                self.metadata["cal_id"] = self.cal_id
            return
        elif self.cal_id == 0:
            # Lee observaciones
            logging.debug("Load prono data from observaciones, series_id: %i, tipo: %s" % (self.series_id, self.type))
            crud = Crud(**input_api_config) if input_api_config is not None else self._variable._node._crud if self._variable is not None and self._variable._node is not None else input_crud
            metadata = crud.readSerie(
                series_id=self.series_id, 
                timestart=timestart,
                timeend=timeend,
                tipo=self.type)
            if len(metadata["observaciones"]):
                self.data = observacionesListToDataFrame(metadata["observaciones"], tag="prono")
            else:
                logging.warning("No data found for series_id=%i, tipo=%s" % (self.series_id, self.type))
                self.data = createEmptyObsDataFrame()
            del metadata["observaciones"]
            self.metadata = { "series_id": metadata["id"], "cal_id": 0 , "series_table": "series_areal" if metadata["tipo"] == "areal" else "series", "forecast_date": datetime.now(pytz.timezone("America/Argentina/Buenos_Aires")) }
        else:
            logging.debug("Load prono data for series_id: %i, tipo: %s, cal_id: %i, cor_id: %s" % (self.series_id, self.type, self.cal_id, str(self.cor_id) if self.cor_id is not None else "last"))
            crud = Crud(**input_api_config) if input_api_config is not None else self._variable._node._crud if self._variable is not None and self._variable._node is not None else input_crud
            if previous_runs_timestart is not None:
                if self.qualifier is not None and self.qualifier == "all":
                    metadata = crud.readSeriePronoConcat(
                        self.cal_id,
                        self.series_id,
                        forecast_timestart = previous_runs_timestart,
                        tipo = self.type,
                        group_by_qualifier=True)
                    
                    # main_qualifier_index = 0
                    # if self.main_qualifier is not None:
                    #     for i, m in enumerate(metadata["pronosticos"]):
                    #         qualifier = m.get("qualifier")
                    #         if qualifier == self.main_qualifier:
                    #             main_qualifier_index = i
                    
                    # if not len(metadata["pronosticos"]) or "pronosticos" not in metadata["pronosticos"][main_qualifier_index] or not len(metadata["pronosticos"][main_qualifier_index]["pronosticos"]):
                    #     logging.warning("No forecast values found for series_id %i, tipo %s, cal_id %i, timestart %s, timeend %s, cor_id %s, main qualifier index %i" % (self.series_id, self.type, self.cal_id, timestart.isoformat(), timeend.isoformat(), self.cor_id, main_qualifier_index))
                    #     self.data = createEmptyObsDataFrame()
                    # else:
                    #     self.data = observacionesListToDataFrame(metadata["pronosticos"][main_qualifier_index]["pronosticos"],tag="prono")
                    #     for member in metadata["pronosticos"]:
                    #         self.data = self.data.join(observacionesListToDataFrame(member["pronosticos"]).rename(columns={"valor": member["qualifier"]}))
                    # return
                else:
                    metadata = crud.readSeriePronoConcat(
                        self.cal_id,
                        self.series_id,
                        forecast_timestart = previous_runs_timestart,
                        qualifier = self.qualifier if self.qualifier is not None and self.qualifier != "all" else None,
                        tipo = self.type,
                        group_by_qualifier=False)
            else:
                metadata = crud.readSerieProno(
                    self.series_id,
                    self.cal_id,
                    timestart = timestart,
                    timeend = timeend,
                    qualifier = self.qualifier, 
                    cor_id = self.cor_id,
                    forecast_timestart = forecast_timestart,
                    tipo = self.type)
            
            if not len(metadata["pronosticos"]):
                logging.warning("No data found for series_id=%i, tipo=%s, cal_id=%i" % (self.series_id, self.type, self.cal_id))
                self.data = createEmptyObsDataFrame()
            else:
                # check if pronosticos is List[SeriesPronoGroupedByQualifierDict]
                if "pronosticos" in metadata["pronosticos"][0]:
                    main_qualifier_index = 0
                    if self.main_qualifier is not None:
                        for i, m in enumerate(metadata["pronosticos"]):
                            qualifier = m.get("qualifier")
                            if qualifier == self.main_qualifier:
                                main_qualifier_index = i

                    prono_main = cast(TVPGroupedByQualifier,metadata["pronosticos"][main_qualifier_index])    
                    if "pronosticos" not in prono_main or not len(prono_main["pronosticos"]):
                        logging.warning("No forecast values found for series_id %i, tipo %s, cal_id %i, timestart %s, timeend %s, cor_id %s, main qualifier index %i" % (self.series_id, self.type, self.cal_id, timestart.isoformat(), timeend.isoformat(), self.cor_id, main_qualifier_index))
                        self.data = createEmptyObsDataFrame()
                    else:
                        self.data = observacionesListToDataFrame(prono_main["pronosticos"],tag="prono")
                        for member in metadata["pronosticos"]:
                            prono_q = cast(TVPGroupedByQualifier, member)
                            self.data = self.data.join(observacionesListToDataFrame(prono_q["pronosticos"]).rename(columns={"valor": prono_q["qualifier"]}))
                else:
                    self.data = observacionesListToDataFrame(metadata["pronosticos"],tag="prono")
        
            md = {**metadata}
            del md["pronosticos"]
            self.metadata = md
        self.original_data = self.data.copy(deep=True)
    
    def setData(self,data):
        self.data = data

