import { IconType } from 'react-icons';

declare const Calendar: IconType;
export default Calendar;
