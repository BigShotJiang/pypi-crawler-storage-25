import { IconType } from 'react-icons';

declare const StyledBrush: IconType;
export default StyledBrush;
