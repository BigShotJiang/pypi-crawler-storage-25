import { IconType } from 'react-icons';

declare const EditOff: IconType;
export default EditOff;
