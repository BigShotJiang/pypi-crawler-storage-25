import { IconType } from 'react-icons';

declare const Window: IconType;
export default Window;
