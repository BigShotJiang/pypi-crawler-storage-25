import { IconType } from 'react-icons';

declare const ColorPalette: IconType;
export default ColorPalette;
