import { IconType } from 'react-icons';

declare const Gauge: IconType;
export default Gauge;
