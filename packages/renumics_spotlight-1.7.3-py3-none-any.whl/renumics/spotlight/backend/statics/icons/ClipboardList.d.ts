import { IconType } from 'react-icons';

declare const ClipboardList: IconType;
export default ClipboardList;
