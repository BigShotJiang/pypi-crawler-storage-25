import { IconType } from 'react-icons';

declare const WordCloud: IconType;
export default WordCloud;
