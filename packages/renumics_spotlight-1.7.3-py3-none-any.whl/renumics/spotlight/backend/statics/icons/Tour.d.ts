import { IconType } from 'react-icons';

declare const Tour: IconType;
export default Tour;
