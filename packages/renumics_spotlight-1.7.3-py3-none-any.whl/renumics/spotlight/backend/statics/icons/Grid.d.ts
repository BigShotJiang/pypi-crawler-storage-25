import { IconType } from 'react-icons';

declare const Grid: IconType;
export default Grid;
