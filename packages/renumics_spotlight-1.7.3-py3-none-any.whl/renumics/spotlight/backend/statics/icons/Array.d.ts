import { IconType } from 'react-icons';

declare const ArrayIcon: IconType;
export default ArrayIcon;
