import { IconType } from 'react-icons';

declare const StyledTable: IconType;
export default StyledTable;
