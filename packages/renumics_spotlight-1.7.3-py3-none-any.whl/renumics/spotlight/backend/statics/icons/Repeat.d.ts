import { IconType } from 'react-icons';

declare const Repeat: IconType;
export default Repeat;
