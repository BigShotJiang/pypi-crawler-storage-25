import { IconType } from 'react-icons';

declare const Soundwave: IconType;
export default Soundwave;
