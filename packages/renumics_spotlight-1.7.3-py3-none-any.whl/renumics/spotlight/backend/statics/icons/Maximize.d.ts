import { IconType } from 'react-icons';

declare const MaximizeIcon: IconType;
export default MaximizeIcon;
