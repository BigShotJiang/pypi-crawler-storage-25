import { IconType } from 'react-icons';

declare const Warning: IconType;
export default Warning;
