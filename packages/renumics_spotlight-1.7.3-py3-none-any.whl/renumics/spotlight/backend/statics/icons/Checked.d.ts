import { IconType } from 'react-icons';

declare const CheckedIcon: IconType;
export default CheckedIcon;
