import { IconType } from 'react-icons';

declare const AddCell: IconType;
export default AddCell;
