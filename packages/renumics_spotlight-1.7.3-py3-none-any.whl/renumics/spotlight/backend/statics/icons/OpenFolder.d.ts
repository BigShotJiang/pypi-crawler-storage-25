import { IconType } from 'react-icons';

declare const OpenFolder: IconType;
export default OpenFolder;
