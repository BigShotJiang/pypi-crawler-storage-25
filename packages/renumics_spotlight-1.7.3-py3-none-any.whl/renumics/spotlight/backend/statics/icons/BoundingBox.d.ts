import { IconType } from 'react-icons';

declare const BoundingBox: IconType;
export default BoundingBox;
