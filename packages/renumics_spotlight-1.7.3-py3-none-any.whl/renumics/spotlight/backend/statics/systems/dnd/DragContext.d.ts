import { default as React } from 'react';

interface Props {
    children: React.ReactNode;
}
export default function DragContext({ children }: Props): JSX.Element;
export {};
