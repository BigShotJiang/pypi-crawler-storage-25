import { Value } from './Value';

/**
 * Set config request model.
 * @export
 * @interface SetConfigRequest
 */
export interface SetConfigRequest {
    /**
     *
     * @type {Value}
     * @memberof SetConfigRequest
     */
    value: Value | null;
}
/**
 * Check if a given object implements the SetConfigRequest interface.
 */
export declare function instanceOfSetConfigRequest(value: object): boolean;
export declare function SetConfigRequestFromJSON(json: any): SetConfigRequest;
export declare function SetConfigRequestFromJSONTyped(json: any, ignoreDiscriminator: boolean): SetConfigRequest;
export declare function SetConfigRequestToJSON(value?: SetConfigRequest | null): any;
