import { FileEntry } from './FileEntry';

/**
 * A single folder
 * @export
 * @interface Folder
 */
export interface Folder {
    /**
     *
     * @type {string}
     * @memberof Folder
     */
    name: string;
    /**
     *
     * @type {string}
     * @memberof Folder
     */
    path: string;
    /**
     *
     * @type {string}
     * @memberof Folder
     */
    parent: string | null;
    /**
     *
     * @type {Array<FileEntry>}
     * @memberof Folder
     */
    files: Array<FileEntry>;
}
/**
 * Check if a given object implements the Folder interface.
 */
export declare function instanceOfFolder(value: object): boolean;
export declare function FolderFromJSON(json: any): Folder;
export declare function FolderFromJSONTyped(json: any, ignoreDiscriminator: boolean): Folder;
export declare function FolderToJSON(value?: Folder | null): any;
