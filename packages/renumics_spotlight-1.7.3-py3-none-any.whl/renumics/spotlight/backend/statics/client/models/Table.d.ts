import { Column } from './Column';

/**
 * a table slice
 * @export
 * @interface Table
 */
export interface Table {
    /**
     *
     * @type {string}
     * @memberof Table
     */
    uid: string;
    /**
     *
     * @type {string}
     * @memberof Table
     */
    filename: string;
    /**
     *
     * @type {Array<Column>}
     * @memberof Table
     */
    columns: Array<Column>;
    /**
     *
     * @type {number}
     * @memberof Table
     */
    generationId: number;
}
/**
 * Check if a given object implements the Table interface.
 */
export declare function instanceOfTable(value: object): boolean;
export declare function TableFromJSON(json: any): Table;
export declare function TableFromJSONTyped(json: any, ignoreDiscriminator: boolean): Table;
export declare function TableToJSON(value?: Table | null): any;
