import { DataIssue } from './DataIssue';

/**
 * The current analysis status with all issues
 * @export
 * @interface AnalysisInfo
 */
export interface AnalysisInfo {
    /**
     *
     * @type {boolean}
     * @memberof AnalysisInfo
     */
    running: boolean;
    /**
     *
     * @type {Array<DataIssue>}
     * @memberof AnalysisInfo
     */
    issues: Array<DataIssue>;
}
/**
 * Check if a given object implements the AnalysisInfo interface.
 */
export declare function instanceOfAnalysisInfo(value: object): boolean;
export declare function AnalysisInfoFromJSON(json: any): AnalysisInfo;
export declare function AnalysisInfoFromJSONTyped(json: any, ignoreDiscriminator: boolean): AnalysisInfo;
export declare function AnalysisInfoToJSON(value?: AnalysisInfo | null): any;
