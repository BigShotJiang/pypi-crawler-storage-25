import { LocationInner } from './LocationInner';

/**
 *
 * @export
 * @interface ValidationError
 */
export interface ValidationError {
    /**
     *
     * @type {Array<LocationInner>}
     * @memberof ValidationError
     */
    loc: Array<LocationInner>;
    /**
     *
     * @type {string}
     * @memberof ValidationError
     */
    msg: string;
    /**
     *
     * @type {string}
     * @memberof ValidationError
     */
    type: string;
}
/**
 * Check if a given object implements the ValidationError interface.
 */
export declare function instanceOfValidationError(value: object): boolean;
export declare function ValidationErrorFromJSON(json: any): ValidationError;
export declare function ValidationErrorFromJSONTyped(json: any, ignoreDiscriminator: boolean): ValidationError;
export declare function ValidationErrorToJSON(value?: ValidationError | null): any;
