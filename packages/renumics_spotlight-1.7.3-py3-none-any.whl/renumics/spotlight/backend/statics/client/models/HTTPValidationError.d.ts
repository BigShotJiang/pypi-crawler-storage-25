import { ValidationError } from './ValidationError';

/**
 *
 * @export
 * @interface HTTPValidationError
 */
export interface HTTPValidationError {
    /**
     *
     * @type {Array<ValidationError>}
     * @memberof HTTPValidationError
     */
    detail?: Array<ValidationError>;
}
/**
 * Check if a given object implements the HTTPValidationError interface.
 */
export declare function instanceOfHTTPValidationError(value: object): boolean;
export declare function HTTPValidationErrorFromJSON(json: any): HTTPValidationError;
export declare function HTTPValidationErrorFromJSONTyped(json: any, ignoreDiscriminator: boolean): HTTPValidationError;
export declare function HTTPValidationErrorToJSON(value?: HTTPValidationError | null): any;
