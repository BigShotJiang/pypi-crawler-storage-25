import { default as Histogram } from './Histogram';

export default Histogram;
