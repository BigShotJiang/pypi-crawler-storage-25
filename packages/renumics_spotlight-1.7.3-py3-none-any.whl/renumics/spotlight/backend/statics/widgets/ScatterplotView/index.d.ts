import { default as ScatterplotView } from './ScatterplotView';

export default ScatterplotView;
