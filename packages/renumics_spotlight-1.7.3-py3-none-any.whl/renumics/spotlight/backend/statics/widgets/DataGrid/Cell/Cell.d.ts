import { FunctionComponent } from 'react';
import { GridChildComponentProps as CellProps } from 'react-window';

type Props = CellProps;
declare const Cell: FunctionComponent<Props>;
export default Cell;
