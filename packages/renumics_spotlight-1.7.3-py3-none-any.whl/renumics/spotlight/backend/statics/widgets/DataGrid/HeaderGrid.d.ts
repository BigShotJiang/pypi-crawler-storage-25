import { VariableSizeGrid as Grid } from 'react-window';
import * as React from 'react';
interface Props {
    height: number;
    width: number;
}
declare const _default: React.ForwardRefExoticComponent<Props & React.RefAttributes<Grid<any>>>;
export default _default;
