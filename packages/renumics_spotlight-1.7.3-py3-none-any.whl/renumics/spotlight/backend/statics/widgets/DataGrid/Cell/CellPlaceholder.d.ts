import { GridChildComponentProps as CellProps } from 'react-window';

type Props = CellProps;
declare const _default: import('react').NamedExoticComponent<Props>;
export default _default;
