import { default as DataGrid } from './DataGrid';

export default DataGrid;
