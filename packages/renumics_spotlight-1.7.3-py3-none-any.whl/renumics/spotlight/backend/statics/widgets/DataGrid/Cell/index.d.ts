import { default as Cell } from './Cell';

export default Cell;
