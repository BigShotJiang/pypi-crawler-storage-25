import { default as MenuBar } from './MenuBar';

export default MenuBar;
