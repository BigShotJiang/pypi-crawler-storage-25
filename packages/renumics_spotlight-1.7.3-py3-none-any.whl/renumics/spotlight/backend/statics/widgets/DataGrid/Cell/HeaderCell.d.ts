import { FunctionComponent } from 'react';
import { GridChildComponentProps as CellProps } from 'react-window';

type Props = CellProps;
declare const HeaderCell: FunctionComponent<Props>;
export default HeaderCell;
