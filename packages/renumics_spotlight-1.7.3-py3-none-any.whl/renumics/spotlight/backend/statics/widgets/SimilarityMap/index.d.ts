import { default as SimilarityMap } from './SimilarityMap';

export default SimilarityMap;
