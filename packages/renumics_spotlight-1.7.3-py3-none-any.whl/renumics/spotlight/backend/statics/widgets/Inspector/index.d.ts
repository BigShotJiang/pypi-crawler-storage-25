import { default as Inspector } from './Inspector';

export default Inspector;
