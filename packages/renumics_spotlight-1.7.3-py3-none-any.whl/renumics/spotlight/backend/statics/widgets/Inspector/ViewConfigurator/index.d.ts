import { default as ViewConfigurator } from './ViewConfigurator';

export default ViewConfigurator;
