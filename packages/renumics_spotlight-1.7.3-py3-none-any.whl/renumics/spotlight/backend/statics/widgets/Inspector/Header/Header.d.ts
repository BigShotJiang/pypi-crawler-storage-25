import { ListOnScrollProps } from 'react-window';
import * as React from 'react';
type Props = {
    height: number;
    width: number;
    itemCount: number;
    onScroll: (props: ListOnScrollProps) => void;
};
export type Ref = {
    scrollTo: (scrollTo: number) => void;
    scrollToItemBottom: (index: number) => void;
    resetAfterIndex: (index: number) => void;
};
declare const _default: React.ForwardRefExoticComponent<Props & React.RefAttributes<Ref>>;
export default _default;
