import { default as WorldCloudView } from './WordCloudView';

export default WorldCloudView;
