import { default as Plot } from './Plot';
import { default as Points } from './Points';
import { default as Zoom } from './Zoom';

export type { MergeStrategy } from './types';
export type { Handle as ZoomHandle } from './Zoom';
export { Points, Zoom };
export default Plot;
