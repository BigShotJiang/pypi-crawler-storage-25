import { default as FileBrowser } from './FileBrowser';

export default FileBrowser;
