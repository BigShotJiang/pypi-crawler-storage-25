import { default as Slider } from './Slider';
import * as React from 'react';
declare const LabeledSlider: React.FunctionComponent<React.ComponentProps<typeof Slider> & {
    className?: string;
}>;
export default LabeledSlider;
