import { ComponentProps, FunctionComponent } from 'react';
import { default as ReactJoyride } from 'react-joyride';

type JoyrideProps = ComponentProps<typeof ReactJoyride>;
declare const Tour: FunctionComponent<JoyrideProps>;
export default Tour;
