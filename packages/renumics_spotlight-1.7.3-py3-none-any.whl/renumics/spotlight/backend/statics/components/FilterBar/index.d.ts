import { default as FilterBar } from './FilterBar';

export default FilterBar;
