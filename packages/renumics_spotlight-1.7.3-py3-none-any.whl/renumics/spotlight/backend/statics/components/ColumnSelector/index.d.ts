import { default as ColumnSelector } from './ColumnSelector';

export default ColumnSelector;
