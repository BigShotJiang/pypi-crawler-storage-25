"""Contract tests for EmbeddingGateway."""

from __future__ import annotations

import pytest

from csg.infrastructure.embeddings.embedding_gateway import EmbeddingGateway
from csg.bootstrap import build_container


def test_embeddings_gateway_exposes_required_interface() -> None:
    gateway = EmbeddingGateway()
    assert hasattr(gateway, "embed")
    with pytest.raises(NotImplementedError):
        gateway.embed(["hello"])


def test_container_wires_embeddings_gateway() -> None:
    container = build_container()
    gateway = container.get_embedding_gateway()
    assert isinstance(gateway, EmbeddingGateway)
