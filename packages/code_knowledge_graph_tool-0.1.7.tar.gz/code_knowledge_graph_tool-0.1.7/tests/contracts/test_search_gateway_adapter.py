"""Contract tests for SearchGateway."""

from __future__ import annotations

import pytest

from csg.infrastructure.search.search_gateway import SearchGateway
from csg.bootstrap import build_container


def test_search_gateway_exposes_required_interface() -> None:
    gateway = SearchGateway()
    assert hasattr(gateway, "search")
    with pytest.raises(NotImplementedError):
        gateway.search("test")


def test_container_wires_search_gateway() -> None:
    container = build_container()
    gateway = container.get_search_gateway()
    assert isinstance(gateway, SearchGateway)
