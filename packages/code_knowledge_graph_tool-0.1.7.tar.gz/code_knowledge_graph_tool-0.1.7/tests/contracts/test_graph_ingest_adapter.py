"""Contract tests for GraphIngestAdapter."""

from __future__ import annotations

from csg.infrastructure.graph.ingest_adapter import GraphIngestAdapter


def test_replace_uses_saver_and_returns_bridge_stats():
    calls: dict[str, object] = {}

    def fake_saver(repo_path: str, payload: dict) -> str:
        calls["repo_path"] = repo_path
        calls["payload"] = payload
        return f"{repo_path}/graph.json"

    adapter = GraphIngestAdapter(saver=fake_saver)
    result = adapter.replace(
        "repo-x",
        {"summary": {"files": 3}, "nodes_by_label": {"File": 3}},
    )

    assert result["status"] == "ok"
    assert result["graph_json_path"].endswith("graph.json")
    assert result["summary"] == {"files": 3}
    assert calls["payload"]["nodes_by_label"]["File"] == 3

