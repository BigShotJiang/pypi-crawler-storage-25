"""Contract tests for AgentGateway."""

from __future__ import annotations

import asyncio
import pytest

from csg.infrastructure.agent.agent_gateway import AgentGateway
from csg.bootstrap import build_container


def test_agent_gateway_exposes_required_interface() -> None:
    gateway = AgentGateway()
    assert hasattr(gateway, "run")
    assert hasattr(gateway, "stream")
    assert hasattr(gateway, "generate_srs")


def test_container_wires_agent_gateway() -> None:
    container = build_container()
    gateway = container.get_agent_gateway()
    assert isinstance(gateway, AgentGateway)
