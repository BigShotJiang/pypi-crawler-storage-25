﻿"""Contract tests for GraphIndexAdapter."""

from __future__ import annotations

import shutil
from pathlib import Path
from uuid import uuid4

from csg.infrastructure.graph.index_adapter import GraphIndexAdapter


def _local_tmp_dir(prefix: str) -> Path:
    base = Path("tests/.tmp_contracts").resolve()
    base.mkdir(parents=True, exist_ok=True)
    path = base / f"{prefix}_{uuid4().hex[:8]}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def test_create_indexes_delegates_to_injected_creator():
    calls: dict[str, object] = {}

    def fake_create(repo_path: str) -> None:
        calls["repo_path"] = repo_path

    adapter = GraphIndexAdapter(create_fn=fake_create)
    adapter.create_indexes("repo-y")

    assert isinstance(calls["repo_path"], str)
    assert calls["repo_path"].endswith("repo-y")


def test_index_status_reports_db_presence():
    repo_dir = _local_tmp_dir("graph_index")
    try:
        # Build expected storage dir shape via existing helper.
        from csg.infrastructure.repository.internal.repo_registry_runtime import get_storage_path

        db_path = get_storage_path(str(repo_dir)) / "lbug"
        db_path.mkdir(parents=True, exist_ok=True)

        adapter = GraphIndexAdapter(create_fn=lambda _repo: None)
        status = adapter.index_status(str(repo_dir))

        assert status["exists"] is True
        assert status["index_ready"] is True
        assert status["db_path"].endswith("lbug")
    finally:
        shutil.rmtree(repo_dir, ignore_errors=True)

