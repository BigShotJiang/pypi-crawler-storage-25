"""Contract tests for ParserGateway."""

from __future__ import annotations

import pytest

from csg.infrastructure.parsing.parser_gateway import ParserGateway
from csg.bootstrap import build_container


def test_parser_gateway_exposes_required_interface() -> None:
    gateway = ParserGateway()
    assert hasattr(gateway, "parse")
    with pytest.raises(NotImplementedError):
        gateway.parse({})


def test_container_wires_parser_gateway() -> None:
    container = build_container()
    gateway = container.get_parser_gateway()
    assert isinstance(gateway, ParserGateway)
