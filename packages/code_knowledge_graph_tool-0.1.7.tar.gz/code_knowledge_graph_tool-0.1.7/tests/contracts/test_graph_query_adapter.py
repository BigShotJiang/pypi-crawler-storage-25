"""Contract tests for GraphQueryAdapter."""

from __future__ import annotations

import pytest

from csg.infrastructure.graph.query_adapter import GraphQueryAdapter


def test_query_delegates_to_executor_and_returns_rows():
    calls: dict[str, object] = {}

    def fake_executor(repo_id, cypher, params):
        calls["repo_id"] = repo_id
        calls["cypher"] = cypher
        calls["params"] = params
        return [{"id": 1}]

    adapter = GraphQueryAdapter(executor=fake_executor)
    rows = adapter.query("repo-a", "MATCH (n) RETURN n", {"limit": 1})

    assert rows == [{"id": 1}]
    assert calls["repo_id"] == "repo-a"
    assert calls["cypher"] == "MATCH (n) RETURN n"
    assert calls["params"] == {"limit": 1}


def test_query_rejects_write_operations():
    adapter = GraphQueryAdapter(executor=lambda *_args, **_kwargs: [])

    with pytest.raises(ValueError, match="Write operations are not allowed"):
        adapter.query("repo-a", "CREATE (n:Tmp {id: '1'}) RETURN n")
