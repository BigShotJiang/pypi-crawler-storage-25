"""Contract tests for InMemoryEventPublisher adapter."""

from __future__ import annotations

import pytest

from csg.infrastructure.events.event_publisher import InMemoryEventPublisher


def test_publish_records_event_payload_copy():
    publisher = InMemoryEventPublisher()
    payload = {"a": {"b": 1}}

    publisher.publish("evt.ok", payload)
    payload["a"]["b"] = 99

    assert publisher.published == [("evt.ok", {"a": {"b": 1}})]
    assert publisher.attempted == [("evt.ok", {"a": {"b": 1}})]


def test_publish_failure_raises_and_does_not_mark_published():
    publisher = InMemoryEventPublisher(fail_on={"evt.fail"})

    with pytest.raises(RuntimeError, match="Publish failed for event"):
        publisher.publish("evt.fail", {"x": 1})

    assert publisher.attempted == [("evt.fail", {"x": 1})]
    assert publisher.published == []

