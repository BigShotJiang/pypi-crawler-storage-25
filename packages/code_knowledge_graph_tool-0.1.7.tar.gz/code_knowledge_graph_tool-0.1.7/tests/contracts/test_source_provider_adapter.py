"""Contract tests for SourceProviderAdapter."""

from __future__ import annotations

import shutil
from pathlib import Path
from uuid import uuid4

import pytest

from csg.infrastructure.sources.source_provider_adapter import SourceProviderAdapter


def _local_tmp_dir(prefix: str) -> Path:
    base = Path("tests/.tmp_contracts").resolve()
    base.mkdir(parents=True, exist_ok=True)
    path = base / f"{prefix}_{uuid4().hex[:8]}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def test_prepare_normalizes_local_directory():
    base = _local_tmp_dir("csg_source_prepare")
    repo_dir = base / "repo"
    repo_dir.mkdir()

    adapter = SourceProviderAdapter()
    try:
        prepared = adapter.prepare(str(repo_dir), kind="local", branch="main")

        assert prepared["kind"] == "local"
        assert prepared["repo_path"] == str(repo_dir.resolve())
        assert prepared["branch"] == "main"
        assert prepared["ephemeral"] is False
        assert prepared["cleanup_path"] is None
    finally:
        shutil.rmtree(base, ignore_errors=True)


def test_prepare_rejects_unknown_kind():
    base = _local_tmp_dir("csg_source_kind")
    repo_dir = base / "repo"
    repo_dir.mkdir()
    adapter = SourceProviderAdapter()

    try:
        with pytest.raises(ValueError):
            adapter.prepare(str(repo_dir), kind="remote-git")
    finally:
        shutil.rmtree(base, ignore_errors=True)


def test_prepare_rejects_missing_path():
    base = _local_tmp_dir("csg_source_missing")
    adapter = SourceProviderAdapter()
    missing = base / "missing"

    try:
        with pytest.raises(FileNotFoundError):
            adapter.prepare(str(missing), kind="local")
    finally:
        shutil.rmtree(base, ignore_errors=True)


def test_cleanup_only_deletes_explicit_ephemeral():
    adapter = SourceProviderAdapter()
    base = _local_tmp_dir("csg_source_cleanup")
    keep_dir = base / "keep"
    keep_dir.mkdir()
    remove_dir = base / "remove"
    remove_dir.mkdir()

    try:
        adapter.cleanup({"cleanup_path": str(keep_dir), "ephemeral": False})
        assert keep_dir.exists()

        adapter.cleanup({"cleanup_path": str(remove_dir), "ephemeral": True})
        assert not remove_dir.exists()
    finally:
        shutil.rmtree(base, ignore_errors=True)
