from __future__ import annotations

import ast
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
LEGACY_FORWARDERS = (
    REPO_ROOT / "csg" / "web" / "routes" / "analysis.py",
    REPO_ROOT / "csg" / "web" / "routes" / "agent.py",
    REPO_ROOT / "csg" / "web" / "schemas.py",
    REPO_ROOT / "csg" / "mcp" / "backend" / "context.py",
    REPO_ROOT / "csg" / "mcp" / "backend" / "explore.py",
    REPO_ROOT / "csg" / "mcp" / "backend" / "impact.py",
    REPO_ROOT / "csg" / "mcp" / "backend" / "mutations.py",
    REPO_ROOT / "csg" / "mcp" / "backend" / "search.py",
    REPO_ROOT / "csg" / "mcp" / "backend" / "srs.py",
    REPO_ROOT / "csg" / "cli.py",
)
ALLOWED_FORWARD_TARGETS = (
    "csg.presentation.web",
    "csg.presentation.mcp",
    "csg.presentation.cli",
    "csg.infrastructure.di.container",
)


def _read_tree(file_path: Path) -> ast.Module:
    return ast.parse(file_path.read_text(encoding="utf-8-sig"), filename=str(file_path))


def _is_docstring_expr(node: ast.stmt) -> bool:
    return isinstance(node, ast.Expr) and isinstance(getattr(node, "value", None), ast.Constant) and isinstance(node.value.value, str)


def _is_all_assignment(node: ast.stmt) -> bool:
    if not isinstance(node, ast.Assign) or len(node.targets) != 1:
        return False
    target = node.targets[0]
    return isinstance(target, ast.Name) and target.id == "__all__"


def _is_main_guard(node: ast.stmt) -> bool:
    if not isinstance(node, ast.If):
        return False
    test = node.test
    if not isinstance(test, ast.Compare):
        return False
    if not isinstance(test.left, ast.Name) or test.left.id != "__name__":
        return False
    if len(test.comparators) != 1:
        return False
    comparator = test.comparators[0]
    return isinstance(comparator, ast.Constant) and comparator.value == "__main__"


def test_legacy_inbound_modules_are_forwarders_only() -> None:
    offenders: list[str] = []

    for file_path in LEGACY_FORWARDERS:
        if not file_path.exists():
            continue
        tree = _read_tree(file_path)
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                continue
            if _is_docstring_expr(node):
                continue
            if _is_all_assignment(node):
                continue
            if _is_main_guard(node):
                continue
            offenders.append(f"{file_path.relative_to(REPO_ROOT)} contains {type(node).__name__}")

    assert not offenders, "Legacy inbound modules must be thin forwarders only:\n" + "\n".join(offenders)


def test_legacy_inbound_modules_forward_only_to_canonical_adapters() -> None:
    offenders: list[str] = []

    for file_path in LEGACY_FORWARDERS:
        if not file_path.exists():
            continue
        tree = _read_tree(file_path)
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                module = node.module
                if module.startswith("csg.") and not any(
                    module == prefix or module.startswith(f"{prefix}.")
                    for prefix in ALLOWED_FORWARD_TARGETS
                ):
                    offenders.append(f"{file_path.relative_to(REPO_ROOT)} -> {module}")
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name
                    if module.startswith("csg.") and not any(
                        module == prefix or module.startswith(f"{prefix}.")
                        for prefix in ALLOWED_FORWARD_TARGETS
                    ):
                        offenders.append(f"{file_path.relative_to(REPO_ROOT)} -> {module}")

    assert not offenders, "Legacy inbound forwarders import non-canonical targets:\n" + "\n".join(sorted(offenders))
