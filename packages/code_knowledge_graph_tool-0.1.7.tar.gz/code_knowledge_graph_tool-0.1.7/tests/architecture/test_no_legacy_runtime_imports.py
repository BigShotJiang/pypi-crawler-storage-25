from __future__ import annotations

import ast
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
CANONICAL_LAYER_PATHS = (
    "csg/application",
    "csg/adapters",
    "csg/infrastructure",
    "csg/domain",
)
FORBIDDEN_LEGACY_PREFIXES = (
    "csg.web",
    "csg.mcp",
    "csg.cli",
    "csg.config",
    "csg.types",
)


def _python_files_in(package_path: str) -> list[Path]:
    base_dir = REPO_ROOT / package_path
    if not base_dir.exists():
        return []
    return sorted(path for path in base_dir.rglob("*.py") if path.is_file())


def _module_name_for_file(file_path: Path) -> str:
    relative = file_path.relative_to(REPO_ROOT).with_suffix("")
    parts = list(relative.parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _package_parts_for_file(file_path: Path) -> list[str]:
    module_name = _module_name_for_file(file_path)
    if file_path.stem == "__init__":
        return module_name.split(".")
    return module_name.split(".")[:-1]


def _resolve_from_import(file_path: Path, module: str | None, level: int) -> str | None:
    if level == 0:
        return module

    package_parts = _package_parts_for_file(file_path)
    if level > len(package_parts) + 1:
        return None

    base_parts = package_parts[: len(package_parts) - (level - 1)]
    if module:
        base_parts.extend(module.split("."))
    return ".".join(base_parts)


def _read_imports(file_path: Path) -> set[str]:
    tree = ast.parse(file_path.read_text(encoding="utf-8-sig"), filename=str(file_path))
    imports: set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            resolved = _resolve_from_import(file_path, node.module, node.level)
            if not resolved:
                continue
            imports.add(resolved)
            for alias in node.names:
                if alias.name != "*":
                    imports.add(f"{resolved}.{alias.name}")
    return imports


def _is_forbidden_legacy_import(imported: str) -> bool:
    return any(
        imported == prefix or imported.startswith(f"{prefix}.")
        for prefix in FORBIDDEN_LEGACY_PREFIXES
    )


def test_canonical_production_layers_do_not_import_legacy_modules() -> None:
    offenders: list[str] = []

    for layer_path in CANONICAL_LAYER_PATHS:
        for file_path in _python_files_in(layer_path):
            for imported in _read_imports(file_path):
                if _is_forbidden_legacy_import(imported):
                    offenders.append(f"{file_path.relative_to(REPO_ROOT)} -> {imported}")

    assert not offenders, (
        "Legacy import violation(s) in canonical production layers:\n"
        + "\n".join(sorted(offenders))
    )


def test_kernel_layer_has_been_deleted() -> None:
    assert not (REPO_ROOT / "csg" / "kernel").exists(), "csg/kernel must be removed"
