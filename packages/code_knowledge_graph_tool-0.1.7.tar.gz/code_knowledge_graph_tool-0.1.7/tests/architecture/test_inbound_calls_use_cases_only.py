from __future__ import annotations

import ast
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
INBOUND_ROOT = REPO_ROOT / "presentation"


def _python_files() -> list[Path]:
    return sorted(path for path in INBOUND_ROOT.rglob("*.py") if path.is_file())


def _imports(file_path: Path) -> set[str]:
    tree = ast.parse(file_path.read_text(encoding="utf-8-sig"), filename=str(file_path))
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module)
            for alias in node.names:
                if alias.name != "*":
                    imports.add(f"{node.module}.{alias.name}")
    return imports


def test_inbound_does_not_import_outbound_or_kernel() -> None:
    offenders: list[str] = []
    for file_path in _python_files():
        for imported in _imports(file_path):
            if imported == "csg.infrastructure" or imported.startswith("csg.infrastructure."):
                offenders.append(f"{file_path.relative_to(REPO_ROOT)} -> {imported}")
            if imported == "csg.kernel" or imported.startswith("csg.kernel."):
                offenders.append(f"{file_path.relative_to(REPO_ROOT)} -> {imported}")
    assert not offenders, "Inbound boundary violation(s):\n" + "\n".join(sorted(offenders))


def test_runtime_entrypoints_import_use_cases() -> None:
    entrypoints = [
        REPO_ROOT / "presentation/cli/entry.py",
        REPO_ROOT / "presentation/web/app.py",
        REPO_ROOT / "presentation/mcp/factory.py",
    ]
    missing: list[str] = []
    for file_path in entrypoints:
        imports = _imports(file_path)
        if not any(
            imported == "csg.application.use_cases"
            or imported.startswith("csg.application.use_cases.")
            for imported in imports
        ):
            missing.append(str(file_path.relative_to(REPO_ROOT)))
    assert not missing, "Runtime entrypoints must import application use cases:\n" + "\n".join(missing)

