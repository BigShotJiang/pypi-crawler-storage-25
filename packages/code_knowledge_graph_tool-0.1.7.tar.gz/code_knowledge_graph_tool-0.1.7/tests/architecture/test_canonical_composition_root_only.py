from __future__ import annotations

import ast
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
COMPOSITION_ROOT_MODULES = (
    "csg.bootstrap",
)
EXPECTED_BUILD_FUNCTION = "build_container"
CANONICAL_BOOT_TARGETS = (
    "csg/__main__.py",
    "csg/presentation/cli/entry.py",
    "csg/presentation/mcp/factory.py",
)


def _read_tree(file_path: Path) -> ast.AST:
    return ast.parse(file_path.read_text(encoding="utf-8-sig"), filename=str(file_path))


def _imported_from_module(tree: ast.AST, module_name: str) -> set[str]:
    imported_names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.level == 0 and node.module == module_name:
            for alias in node.names:
                if alias.name != "*":
                    imported_names.add(alias.name)
    return imported_names


def _has_function_call(tree: ast.AST, function_name: str) -> bool:
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if isinstance(func, ast.Name) and func.id == function_name:
            return True
        if isinstance(func, ast.Attribute) and func.attr == function_name:
            return True
    return False


def test_container_module_exposes_canonical_build_function() -> None:
    module_path = REPO_ROOT / "csg" / "bootstrap.py"
    assert module_path.exists(), "Canonical bootstrap module must live at csg/bootstrap.py"
    assert not (REPO_ROOT / "bootstrap.py").exists(), "Root-level bootstrap.py should not exist"
    tree = _read_tree(module_path)
    defined_functions = {
        node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)
    }
    assert EXPECTED_BUILD_FUNCTION in defined_functions, (
        f"Canonical bootstrap module must expose `{EXPECTED_BUILD_FUNCTION}`"
    )


def test_boot_targets_use_canonical_container_build_function() -> None:
    offenders: list[str] = []
    for relative_path in CANONICAL_BOOT_TARGETS:
        file_path = REPO_ROOT / relative_path
        if not file_path.exists():
            continue
        tree = _read_tree(file_path)
        # Check if any allowed composition root module is imported
        imported_any_root = any(
            _imported_from_module(tree, module) for module in COMPOSITION_ROOT_MODULES
        )
        if not imported_any_root or not _has_function_call(tree, EXPECTED_BUILD_FUNCTION):
            offenders.append(relative_path)

    assert not offenders, (
        "Canonical boot target(s) must import and call build_container from one of:\n"
        + "\n".join(COMPOSITION_ROOT_MODULES)
        + "\nOffenders:\n"
        + "\n".join(sorted(offenders))
    )
