from __future__ import annotations

import ast
import importlib
import inspect
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]
OUTBOUND_ROOT = REPO_ROOT / "csg" / "adapters" / "outbound"
PORTS_PACKAGE_PREFIX = "csg.application.ports."


def _python_files() -> list[Path]:
    if not OUTBOUND_ROOT.exists():
        return []
    return sorted(
        path
        for path in OUTBOUND_ROOT.rglob("*.py")
        if path.is_file()
        and path.name != "__init__.py"
        and "internal" not in path.relative_to(OUTBOUND_ROOT).parts
    )


def _module_name_for_file(file_path: Path) -> str:
    relative = file_path.relative_to(REPO_ROOT).with_suffix("")
    parts = list(relative.parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _package_parts_for_file(file_path: Path) -> list[str]:
    module_name = _module_name_for_file(file_path)
    if file_path.stem == "__init__":
        return module_name.split(".")
    return module_name.split(".")[:-1]


def _resolve_from_import(file_path: Path, module: str | None, level: int) -> str | None:
    if level == 0:
        return module

    package_parts = _package_parts_for_file(file_path)
    if level > len(package_parts) + 1:
        return None

    base_parts = package_parts[: len(package_parts) - (level - 1)]
    if module:
        base_parts.extend(module.split("."))
    return ".".join(base_parts)


def _read_port_imports(file_path: Path) -> set[tuple[str, str]]:
    tree = ast.parse(file_path.read_text(encoding="utf-8-sig"), filename=str(file_path))
    imported_ports: set[tuple[str, str]] = set()

    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom):
            continue
        resolved = _resolve_from_import(file_path, node.module, node.level)
        if not resolved or not resolved.startswith(PORTS_PACKAGE_PREFIX):
            continue
        for alias in node.names:
            if alias.name.endswith("Port"):
                imported_ports.add((resolved, alias.name))

    return imported_ports


def _required_port_methods(port_type: type[Any]) -> list[str]:
    required: list[str] = []
    for name, member in port_type.__dict__.items():
        if not callable(member):
            continue
        if name in {"__enter__", "__exit__"} or not name.startswith("_"):
            required.append(name)
    return sorted(required)


def _method_owner(cls: type[Any], method_name: str) -> type[Any] | None:
    for base in cls.__mro__:
        if method_name in base.__dict__:
            return base
    return None


def _is_concrete_port_method_implementation(
    cls: type[Any],
    *,
    port_type: type[Any],
    method_name: str,
) -> bool:
    owner = _method_owner(cls, method_name)
    if owner is None or owner is port_type:
        return False
    method = owner.__dict__.get(method_name)
    if not callable(method):
        return False
    if getattr(method, "__isabstractmethod__", False):
        return False
    if method_name in getattr(cls, "__abstractmethods__", frozenset()):
        return False
    return True


def test_outbound_adapters_import_and_implement_application_ports() -> None:
    missing_port_imports: list[str] = []
    missing_implementations: list[str] = []
    missing_methods: list[str] = []
    abstract_adapters: list[str] = []

    for file_path in _python_files():
        module_name = _module_name_for_file(file_path)
        imported_ports = _read_port_imports(file_path)
        if not imported_ports:
            missing_port_imports.append(f"{file_path.relative_to(REPO_ROOT)}")
            continue

        module = importlib.import_module(module_name)
        module_classes = [
            obj
            for _, obj in inspect.getmembers(module, inspect.isclass)
            if obj.__module__ == module_name
        ]

        port_types: list[type[Any]] = []
        for port_module_name, port_type_name in sorted(imported_ports):
            port_module = importlib.import_module(port_module_name)
            port_type = getattr(port_module, port_type_name, None)
            if inspect.isclass(port_type):
                port_types.append(port_type)

        if not port_types:
            missing_implementations.append(
                f"{file_path.relative_to(REPO_ROOT)} -> no resolvable *Port type imports"
            )
            continue

        implemented_pairs: list[tuple[type[Any], type[Any]]] = []
        for cls in module_classes:
            for port_type in port_types:
                if cls is port_type:
                    continue
                if port_type in cls.__mro__[1:]:
                    implemented_pairs.append((cls, port_type))

        if not implemented_pairs:
            missing_implementations.append(
                f"{file_path.relative_to(REPO_ROOT)} -> expected subclass of one of: "
                + ", ".join(sorted(port.__name__ for port in port_types))
            )
            continue

        for cls, port_type in implemented_pairs:
            if inspect.isabstract(cls):
                abstract_adapters.append(f"{module_name}.{cls.__name__}")
            required = _required_port_methods(port_type)
            missing = [
                name
                for name in required
                if not _is_concrete_port_method_implementation(
                    cls,
                    port_type=port_type,
                    method_name=name,
                )
            ]
            if missing:
                missing_methods.append(
                    f"{module_name}.{cls.__name__} missing concrete {port_type.__name__} "
                    "method implementation(s): "
                    + ", ".join(missing)
                )

    assert not missing_port_imports, (
        "Outbound adapter module(s) without application port import:\n"
        + "\n".join(sorted(missing_port_imports))
    )
    assert not missing_implementations, (
        "Outbound adapter module(s) not aligned to imported application ports:\n"
        + "\n".join(sorted(missing_implementations))
    )
    assert not abstract_adapters, (
        "Outbound adapter class(es) must be concrete:\n"
        + "\n".join(sorted(abstract_adapters))
    )
    assert not missing_methods, "Outbound adapter contract mismatch:\n" + "\n".join(
        sorted(missing_methods)
    )
