from pathlib import Path


def test_exploration_runtime_lives_outside_application() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    assert not (repo_root / "csg" / "application" / "use_cases" / "exploration" / "backend").exists()
