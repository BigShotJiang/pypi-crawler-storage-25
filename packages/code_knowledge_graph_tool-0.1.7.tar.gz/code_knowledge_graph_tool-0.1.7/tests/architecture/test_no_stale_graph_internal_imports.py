from pathlib import Path


def test_no_stale_graph_internal_imports() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    offenders = []

    for path in (repo_root / "csg").rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        text = path.read_text(encoding="utf-8")
        if "csg.infrastructure.graph.internal" in text:
            offenders.append(str(path.relative_to(repo_root)))

    assert offenders == []
