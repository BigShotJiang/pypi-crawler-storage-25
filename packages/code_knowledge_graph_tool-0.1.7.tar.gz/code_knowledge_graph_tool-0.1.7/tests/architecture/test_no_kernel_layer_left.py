from __future__ import annotations

from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]


def test_no_kernel_layer_left() -> None:
    assert not (REPO_ROOT / "csg" / "kernel").exists(), "csg/kernel must not exist"

