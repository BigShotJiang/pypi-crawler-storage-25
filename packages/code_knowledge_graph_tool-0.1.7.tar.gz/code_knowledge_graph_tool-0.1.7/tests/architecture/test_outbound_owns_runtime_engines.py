from __future__ import annotations

from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
OUTBOUND_ROOT = REPO_ROOT / "csg" / "adapters" / "outbound"


def test_runtime_engines_live_under_outbound_internal_packages() -> None:
    expected_internal_dirs = [
        OUTBOUND_ROOT / "analysis" / "internal",
        OUTBOUND_ROOT / "agent" / "internal",
        OUTBOUND_ROOT / "embeddings" / "internal",
        OUTBOUND_ROOT / "graph" / "internal",
        OUTBOUND_ROOT / "parsing" / "internal",
        OUTBOUND_ROOT / "repository" / "internal",
        OUTBOUND_ROOT / "search" / "internal",
        OUTBOUND_ROOT / "sources" / "internal",
    ]
    missing = [str(path.relative_to(REPO_ROOT)) for path in expected_internal_dirs if not path.exists()]
    assert not missing, "Expected outbound runtime internal directories are missing:\n" + "\n".join(missing)

