from __future__ import annotations

import ast
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
DOMAIN_ROOT = REPO_ROOT / "csg" / "domain"


def test_domain_has_no_outer_layer_imports() -> None:
    offenders: list[str] = []
    for file_path in sorted(DOMAIN_ROOT.rglob("*.py")):
        tree = ast.parse(file_path.read_text(encoding="utf-8-sig"), filename=str(file_path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module, *[f"{node.module}.{alias.name}" for alias in node.names if alias.name != "*"]]
            else:
                continue
            for imported in names:
                if imported.startswith("csg.adapters.") or imported.startswith("csg.infrastructure.") or imported.startswith("csg.kernel."):
                    offenders.append(f"{file_path.relative_to(REPO_ROOT)} -> {imported}")
    assert not offenders, "Domain purity violation(s):\n" + "\n".join(sorted(offenders))

