from __future__ import annotations

from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
INBOUND_ROOT = REPO_ROOT / "csg" / "adapters" / "inbound"


def test_inbound_does_not_import_application_services() -> None:
    offenders: list[str] = []
    for file_path in sorted(INBOUND_ROOT.rglob("*.py")):
        content = file_path.read_text(encoding="utf-8-sig")
        if "csg.application.services" in content:
            offenders.append(str(file_path.relative_to(REPO_ROOT)))
    assert not offenders, "Inbound must not import csg.application.services:\n" + "\n".join(offenders)

