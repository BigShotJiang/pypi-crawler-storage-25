"""Shared fixtures and marker registration for CSG test suite."""

from __future__ import annotations

import shutil
import zipfile
from pathlib import Path
from uuid import uuid4

import pytest

from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph
from csg.domain.codebase.value_objects import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    NodeProperties,
    RelationshipType,
)

TESTCASE_DIR = Path(__file__).parent.parent / "testcase"
WORKSPACE_TMP_DIR = Path(__file__).parent.parent / ".test_tmp"


# -- Fixtures ----------------------------------------------------------------


@pytest.fixture(scope="session")
def python_test_repo() -> Path:
    """Extract testcase/python_test.zip to a temp directory (session-scoped)."""
    zip_path = TESTCASE_DIR / "python_test.zip"
    if not zip_path.exists():
        pytest.skip(f"Test fixture not found: {zip_path}")
    dest = WORKSPACE_TMP_DIR / f"python_test_{uuid4().hex}"
    dest.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(dest)
        children = list(dest.iterdir())
        if len(children) == 1 and children[0].is_dir():
            yield children[0]
        else:
            yield dest
    finally:
        shutil.rmtree(dest, ignore_errors=True)


@pytest.fixture
def workspace_temp_dir() -> Path:
    """Create an isolated temp directory under the repo workspace."""
    path = WORKSPACE_TMP_DIR / uuid4().hex
    path.mkdir(parents=True, exist_ok=True)
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


@pytest.fixture
def temp_db_path(workspace_temp_dir: Path) -> Path:
    """Fresh temporary directory for a KuzuDB instance."""
    yield workspace_temp_dir / "lbug"


@pytest.fixture
def kuzu_adapter(temp_db_path):
    """A connected LadybugAdapter on a fresh temp DB."""
    from csg.infrastructure.graph.lbug_adapter import LadybugAdapter

    adapter = LadybugAdapter(str(temp_db_path))
    adapter.connect()
    adapter.create_schema()
    yield adapter
    adapter.close()


@pytest.fixture
def sample_knowledge_graph() -> KnowledgeGraph:
    """Small KnowledgeGraph with 5 nodes and 3 relationships."""
    kg = KnowledgeGraph()

    kg.add_node(GraphNode(
        id="File:src/main.py:main.py",
        label=NodeLabel.FILE,
        properties=NodeProperties(name="main.py", file_path="src/main.py"),
    ))
    kg.add_node(GraphNode(
        id="Function:src/main.py:main",
        label=NodeLabel.FUNCTION,
        properties=NodeProperties(
            name="main", file_path="src/main.py",
            start_line=1, end_line=10, is_exported=True,
            content="def main():\n    pass",
        ),
    ))
    kg.add_node(GraphNode(
        id="Class:src/app.py:App",
        label=NodeLabel.CLASS,
        properties=NodeProperties(
            name="App", file_path="src/app.py",
            start_line=1, end_line=50, is_exported=True,
            content="class App:\n    pass",
        ),
    ))
    kg.add_node(GraphNode(
        id="Method:src/app.py:run",
        label=NodeLabel.METHOD,
        properties=NodeProperties(
            name="run", file_path="src/app.py",
            start_line=10, end_line=30,
            content="def run(self):\n    pass",
        ),
    ))
    kg.add_node(GraphNode(
        id="File:src/app.py:app.py",
        label=NodeLabel.FILE,
        properties=NodeProperties(name="app.py", file_path="src/app.py"),
    ))

    kg.add_relationship(GraphRelationship(
        id="rel-1",
        source_id="File:src/main.py:main.py",
        target_id="Function:src/main.py:main",
        type=RelationshipType.CONTAINS,
    ))
    kg.add_relationship(GraphRelationship(
        id="rel-2",
        source_id="Function:src/main.py:main",
        target_id="Method:src/app.py:run",
        type=RelationshipType.CALLS,
    ))
    kg.add_relationship(GraphRelationship(
        id="rel-3",
        source_id="Class:src/app.py:App",
        target_id="Method:src/app.py:run",
        type=RelationshipType.HAS_METHOD,
    ))

    return kg

