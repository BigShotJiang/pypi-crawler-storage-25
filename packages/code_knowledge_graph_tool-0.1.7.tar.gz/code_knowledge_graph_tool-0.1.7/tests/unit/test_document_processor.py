"""Tests for csg/ingestion/document_processor.py - orchestrator logic."""

import pytest

from csg.infrastructure.sources.internal.document_processor import _generate_id, _make_search_text


@pytest.mark.unit
class TestGenerateId:
    def test_basic(self):
        result = _generate_id("DocFile", "docs/spec.pdf")
        assert result == "DocFile:docs/spec.pdf"

    def test_multiple_parts(self):
        result = _generate_id("DocSection", "spec.pdf", "L1", "Introduction")
        assert result == "DocSection:spec.pdf:L1:Introduction"


@pytest.mark.unit
class TestMakeSearchText:
    def test_heading_only(self):
        result = _make_search_text("Introduction", "")
        assert "Introduction" in result

    def test_heading_with_content(self):
        result = _make_search_text("Overview", "This is the system overview.")
        assert "Overview" in result
        assert "system overview" in result

    def test_long_content_truncated(self):
        long = "x" * 500
        result = _make_search_text("Title", long)
        assert len(result) < 500  # content truncated to 200 chars

