"""Tests for csg/search/mmr.py - maximal marginal relevance."""

import pytest

from csg.infrastructure.search.internal.mmr_runtime import MMRCandidate, _cosine_similarity, mmr_rerank


@pytest.mark.unit
class TestCosineSimilarity:
    def test_identical(self):
        assert _cosine_similarity([1, 0], [1, 0]) == pytest.approx(1.0)

    def test_orthogonal(self):
        assert _cosine_similarity([1, 0], [0, 1]) == pytest.approx(0.0)

    def test_opposite(self):
        assert _cosine_similarity([1, 0], [-1, 0]) == pytest.approx(-1.0)

    def test_zero_vector(self):
        assert _cosine_similarity([0, 0], [1, 0]) == pytest.approx(0.0)


@pytest.mark.unit
class TestMmrRerank:
    def _candidate(self, id, vec, sim):
        return MMRCandidate(id=id, vector=vec, similarity=sim, metadata={})

    def test_empty(self):
        assert mmr_rerank([]) == []

    def test_k_zero(self):
        c = [self._candidate("a", [1, 0], 0.9)]
        assert mmr_rerank(c, k=0) == []

    def test_fewer_than_k(self):
        candidates = [
            self._candidate("a", [1, 0], 0.9),
            self._candidate("b", [0, 1], 0.7),
        ]
        results = mmr_rerank(candidates, k=10)
        assert len(results) == 2

    def test_returns_correct_count(self):
        candidates = [self._candidate(f"c{i}", [i, 1], 0.9 - i * 0.05) for i in range(10)]
        results = mmr_rerank(candidates, k=3)
        assert len(results) == 3

    def test_relevance_focused(self):
        candidates = [
            self._candidate("best", [1, 0], 0.99),
            self._candidate("good", [0.9, 0.1], 0.8),
            self._candidate("ok", [0.5, 0.5], 0.5),
        ]
        results = mmr_rerank(candidates, k=3, lambda_param=1.0)
        assert results[0].id == "best"

