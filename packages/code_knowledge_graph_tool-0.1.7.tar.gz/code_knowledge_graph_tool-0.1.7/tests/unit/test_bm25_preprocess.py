﻿"""Tests for pure functions in kernel search BM25 runtime."""

import pytest

from csg.infrastructure.search.internal.bm25_runtime import _escape_fts_query, _preprocess_query


@pytest.mark.unit
class TestPreprocessQuery:
    def test_camel_case_split(self):
        result = _preprocess_query("getLeaderboard")
        assert "get" in result.lower()
        assert "leaderboard" in result.lower()

    def test_stop_word_removal(self):
        result = _preprocess_query("how does the authentication work")
        assert "how" not in result.split()
        assert "does" not in result.split()
        assert "the" not in result.split()
        assert "authentication" in result

    def test_compound_split(self):
        result = _preprocess_query("websocket")
        assert "web" in result
        assert "socket" in result

    def test_prefix_truncation(self):
        result = _preprocess_query("authentication")
        assert "auth" in result

    def test_short_word_no_prefix(self):
        result = _preprocess_query("auth")
        # "auth" is <=10 chars, no prefix truncation
        parts = result.split()
        assert parts.count("auth") == 1

    def test_preserves_original(self):
        result = _preprocess_query("getUser")
        assert "getUser" in result or "getuser" in result.lower()


@pytest.mark.unit
class TestEscapeFtsQuery:
    def test_single_quote(self):
        assert _escape_fts_query("it's") == "it''s"

    def test_backslash(self):
        assert _escape_fts_query("path\\to") == "path\\\\to"

    def test_no_escaping_needed(self):
        assert _escape_fts_query("simple query") == "simple query"

    def test_combined(self):
        assert _escape_fts_query("it's a\\b") == "it''s a\\\\b"

