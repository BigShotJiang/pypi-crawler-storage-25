from __future__ import annotations

import time
from pathlib import Path

from csg.infrastructure.analysis.internal.analysis.watcher import (
    RepoWatcher,
    _is_database_lock_error,
    should_watch_path,
)
from csg.infrastructure.repository.internal.repo_registry_runtime import RegistryEntry


def test_should_watch_path_filters_noise_and_keeps_source_files(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()

    assert should_watch_path(repo_path / "src" / "app.py", repo_path=repo_path) is True
    assert should_watch_path(repo_path / "frontend" / "GraphView.tsx", repo_path=repo_path) is True

    assert should_watch_path(repo_path / ".git" / "HEAD", repo_path=repo_path) is False
    assert should_watch_path(repo_path / ".codex" / "skills" / "csg" / "SKILL.md", repo_path=repo_path) is False
    assert should_watch_path(repo_path / ".claude" / "settings.json", repo_path=repo_path) is False
    assert should_watch_path(repo_path / ".omx" / "state" / "run.json", repo_path=repo_path) is False
    assert should_watch_path(repo_path / "data" / "registry.json", repo_path=repo_path) is False
    assert should_watch_path(repo_path / "data" / "mcp.log", repo_path=repo_path) is False
    assert should_watch_path(repo_path / "node_modules" / "pkg" / "index.js", repo_path=repo_path) is False
    assert should_watch_path(repo_path / ".venv" / "Lib" / "site.py", repo_path=repo_path) is False
    assert should_watch_path(repo_path / "src" / "app.py~", repo_path=repo_path) is False
    assert should_watch_path(repo_path / "image.png", repo_path=repo_path) is False


def test_watch_once_filters_batch_and_runs_incremental_once(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    source_file = repo_path / "src" / "app.py"
    ignored_file = repo_path / ".git" / "HEAD"

    repo = RegistryEntry(
        name="repo",
        path=str(repo_path),
        storage_path=str(tmp_path / "storage"),
        indexed_at="now",
        last_commit="uploaded",
    )
    calls: list[str] = []

    watcher = RepoWatcher(
        debounce=0,
        repo_loader=lambda: [repo],
        event_watcher=lambda path, stop_event: [
            {
                ("modified", str(ignored_file)),
                ("modified", str(source_file)),
                ("modified", str(source_file)),
            }
        ],
        incremental_runner=lambda path: calls.append(path),
    )

    watcher.watch_once()

    assert calls == [str(repo_path)]


def test_handle_changes_coalesces_batches_until_repo_is_quiet(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    first_file = repo_path / "src" / "app.py"
    second_file = repo_path / "src" / "other.py"
    repo = RegistryEntry(
        name="repo",
        path=str(repo_path),
        storage_path=str(tmp_path / "storage"),
        indexed_at="now",
        last_commit="uploaded",
    )
    calls: list[str] = []

    watcher = RepoWatcher(
        debounce=0.05,
        repo_loader=lambda: [repo],
        event_watcher=lambda path, stop_event: [],
        incremental_runner=lambda path: calls.append(path),
    )

    future = watcher._handle_changes(repo, {("modified", str(first_file))})
    time.sleep(0.02)
    watcher._handle_changes(repo, {("modified", str(second_file))})

    assert future is not None
    future.result(timeout=1)
    watcher.stop()

    assert calls == [str(repo_path)]


def test_watch_once_ignores_empty_filtered_batches(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    repo = RegistryEntry(
        name="repo",
        path=str(repo_path),
        storage_path=str(tmp_path / "storage"),
        indexed_at="now",
        last_commit="uploaded",
    )
    calls: list[str] = []

    watcher = RepoWatcher(
        debounce=0,
        repo_loader=lambda: [repo],
        event_watcher=lambda path, stop_event: [{("modified", str(repo_path / ".git" / "HEAD"))}],
        incremental_runner=lambda path: calls.append(path),
    )

    watcher.watch_once()

    assert calls == []


def test_watch_once_reports_db_lock_conflict_without_traceback(tmp_path: Path, monkeypatch) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    repo = RegistryEntry(
        name="repo",
        path=str(repo_path),
        storage_path=str(repo_path / ".csg"),
        indexed_at="now",
        last_commit="uploaded",
    )
    warnings: list[str] = []
    exceptions: list[str] = []

    import csg.infrastructure.analysis.internal.analysis.watcher as watcher_module

    monkeypatch.setattr(
        watcher_module.logger,
        "warning",
        lambda message, *args, **_kwargs: warnings.append(message % args),
    )
    monkeypatch.setattr(
        watcher_module.logger,
        "exception",
        lambda message, *args, **_kwargs: exceptions.append(message % args),
    )

    watcher = RepoWatcher(
        debounce=0,
        repo_loader=lambda: [repo],
        event_watcher=lambda path, stop_event: [{("modified", str(repo_path / "app.py"))}],
        incremental_runner=lambda path: (_ for _ in ()).throw(
            RuntimeError("Database at repo/.csg/lbug is read-only (another process holds the write lock)")
        ),
    )

    watcher.watch_once()

    assert warnings == ["Incremental re-ingestion skipped for 'repo': database is locked by another process"]
    assert exceptions == []


def test_database_lock_error_detection_is_specific() -> None:
    assert _is_database_lock_error(RuntimeError("Database is read-only (another process holds the write lock)"))
    assert not _is_database_lock_error(RuntimeError("parse failed"))
