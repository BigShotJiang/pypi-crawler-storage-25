"""Tests for csg/ingestion/content_filter.py - binary detection."""

from pathlib import Path

import pytest

from csg.infrastructure.sources.internal.content_filter import (
    _has_unicode_bom,
    _shannon_entropy,
    is_binary_content,
    is_binary_path,
)


@pytest.mark.unit
class TestShannonEntropy:
    def test_empty(self):
        assert _shannon_entropy(b"") == 0.0

    def test_all_same_byte(self):
        assert _shannon_entropy(b"\x41" * 100) == 0.0

    def test_uniform_random(self):
        data = bytes(range(256)) * 32
        entropy = _shannon_entropy(data)
        assert 7.9 < entropy <= 8.0

    def test_text_range(self):
        entropy = _shannon_entropy(b"Hello World! This is a test of entropy.")
        assert 2.0 < entropy < 5.0


@pytest.mark.unit
class TestHasUnicodeBom:
    def test_utf16_le(self):
        assert _has_unicode_bom(b"\xff\xfe" + b"data") is True

    def test_utf16_be(self):
        assert _has_unicode_bom(b"\xfe\xff" + b"data") is True

    def test_utf32_le(self):
        assert _has_unicode_bom(b"\xff\xfe\x00\x00" + b"data") is True

    def test_no_bom(self):
        assert _has_unicode_bom(b"plain text") is False

    def test_empty(self):
        assert _has_unicode_bom(b"") is False


@pytest.mark.unit
class TestIsBinaryPath:
    def test_text_file(self, workspace_temp_dir: Path):
        p = workspace_temp_dir / "main.py"
        p.write_text("def main():\n    pass\n")
        assert is_binary_path(p) is False

    def test_binary_file(self, workspace_temp_dir: Path):
        p = workspace_temp_dir / "data.bin"
        p.write_bytes(b"\x00\x01\x02\x03" * 100)
        assert is_binary_path(p) is True

    def test_empty_file(self, workspace_temp_dir: Path):
        p = workspace_temp_dir / "empty.txt"
        p.write_bytes(b"")
        assert is_binary_path(p) is False

    def test_utf16_bom_file(self, workspace_temp_dir: Path):
        p = workspace_temp_dir / "utf16.txt"
        p.write_bytes(b"\xff\xfe" + "hello".encode("utf-16-le"))
        assert is_binary_path(p) is False

    def test_nonexistent(self, workspace_temp_dir: Path):
        assert is_binary_path(Path(workspace_temp_dir) / "missing.txt") is False


@pytest.mark.unit
class TestIsBinaryContent:
    def test_normal_text(self):
        assert is_binary_content("def main():\n    pass") is False

    def test_replacement_chars(self):
        bad = "\ufffd" * 50 + "a" * 50
        assert is_binary_content(bad) is True

    def test_empty(self):
        assert is_binary_content("") is False
