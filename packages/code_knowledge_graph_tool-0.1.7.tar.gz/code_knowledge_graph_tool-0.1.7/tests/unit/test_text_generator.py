"""Tests for csg/embeddings/text_generator.py - embedding text generation."""

import pytest

from csg.infrastructure.embeddings.internal.text_generator_runtime import (
    EmbeddableNode,
    generate_batch_embedding_texts,
    generate_embedding_text,
)


def _node(label, name="test", content="", file_path="src/main.py"):
    return EmbeddableNode(
        id=f"{label}:{file_path}:{name}",
        name=name, label=label, file_path=file_path,
        content=content, start_line=1, end_line=10,
    )


@pytest.mark.unit
class TestGenerateEmbeddingText:
    def test_function_node(self):
        text = generate_embedding_text(_node("Function", "main", "def main(): pass"))
        assert text.startswith("Function: main")
        assert "def main()" in text

    def test_file_node(self):
        text = generate_embedding_text(_node("File", "main.py", file_path="src/main.py"))
        assert text.startswith("File: main.py")
        assert "Path: src/main.py" in text

    def test_section_node(self):
        text = generate_embedding_text(_node("Section", "README", "# Hello", "docs/README.md"))
        assert text.startswith("Documentation: README")
        assert "Directory: docs" in text

    def test_content_truncation(self):
        long_content = "x" * 1000
        text = generate_embedding_text(_node("Function", "foo", long_content), max_snippet_length=100)
        assert len(text) < 300  # includes metadata + truncated content

    def test_content_cleaning(self):
        dirty = "line1\r\nline2\n\n\n\nline3"
        text = generate_embedding_text(_node("Function", "foo", dirty))
        assert "\r\n" not in text
        assert "\n\n\n" not in text

    def test_directory_included(self):
        text = generate_embedding_text(_node("Class", "App", "class App: pass", "src/app.py"))
        assert "Directory: src" in text

    def test_no_content(self):
        text = generate_embedding_text(_node("Function", "foo", ""))
        assert "Function: foo" in text
        # No empty snippet section
        lines = text.strip().split("\n")
        assert all(line.strip() for line in lines)

    def test_batch_generation(self):
        nodes = [_node("Function", f"fn{i}", f"code{i}") for i in range(3)]
        texts = generate_batch_embedding_texts(nodes)
        assert len(texts) == 3
        assert all("Function:" in t for t in texts)

