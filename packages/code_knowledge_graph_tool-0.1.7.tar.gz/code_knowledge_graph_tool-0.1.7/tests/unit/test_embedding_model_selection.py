"""Tests for embedding model selection and fallback."""

from __future__ import annotations

import sys
from types import SimpleNamespace

import pytest

from csg.infrastructure.embeddings.internal import pipeline_runtime
from csg.infrastructure.runtime.user_context import UserRuntimeSecrets, UserRuntimeSettings, bind_user_runtime


class _OpenAIEmbeddings:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.document_calls = 0
        self.query_calls = 0

    def embed_documents(self, texts):
        self.document_calls += 1
        return [[0.1] * 768 for _ in texts]

    def embed_query(self, text):
        self.query_calls += 1
        return [0.2] * 768


class _FailingOpenAIEmbeddings(_OpenAIEmbeddings):
    def embed_documents(self, texts):
        raise RuntimeError("openai unavailable")

    def embed_query(self, text):
        raise RuntimeError("openai unavailable")


class _UnconfiguredOpenAIEmbeddings(_OpenAIEmbeddings):
    def __init__(self, **kwargs):
        raise RuntimeError("missing api key")


class _HuggingFaceEmbeddings:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.document_calls = 0
        self.query_calls = 0

    def embed_documents(self, texts):
        self.document_calls += 1
        return [[0.3] * 768 for _ in texts]

    def embed_query(self, text):
        self.query_calls += 1
        return [0.4] * 768


@pytest.fixture(autouse=True)
def _reset_embedding_runtime(monkeypatch, tmp_path):
    pipeline_runtime.dispose_model()
    monkeypatch.setattr(pipeline_runtime, "_MODEL_CACHE_DIR", tmp_path)
    monkeypatch.setattr(pipeline_runtime, "_is_model_cached", lambda model_id, cache_dir: True)
    monkeypatch.setitem(
        sys.modules,
        "langchain_huggingface",
        SimpleNamespace(HuggingFaceEmbeddings=_HuggingFaceEmbeddings),
    )
    yield
    pipeline_runtime.dispose_model()


def test_default_embedding_model_uses_openai_with_768_dimensions(monkeypatch) -> None:
    monkeypatch.setitem(
        sys.modules,
        "langchain_openai",
        SimpleNamespace(OpenAIEmbeddings=_OpenAIEmbeddings),
    )

    with bind_user_runtime(
        UserRuntimeSettings(embedding_provider="openai"),
        UserRuntimeSecrets(openai_api_key="sk-user-runtime"),
    ):
        model = pipeline_runtime.get_or_create_model()
        vectors = model.embed_documents(["def main(): pass"])

    assert vectors == [[0.1] * 768]
    assert model.primary.kwargs["model"] == "text-embedding-3-small"
    assert model.primary.kwargs["dimensions"] == 768


def test_openai_embedding_failure_falls_back_to_local_model(monkeypatch) -> None:
    monkeypatch.setitem(
        sys.modules,
        "langchain_openai",
        SimpleNamespace(OpenAIEmbeddings=_FailingOpenAIEmbeddings),
    )

    with bind_user_runtime(
        UserRuntimeSettings(embedding_provider="openai"),
        UserRuntimeSecrets(openai_api_key="sk-user-runtime"),
    ):
        model = pipeline_runtime.get_or_create_model()
        vectors = model.embed_documents(["def main(): pass"])

    assert vectors == [[0.3] * 768]
    assert model.fallback.kwargs["model_name"] == "nomic-ai/CodeRankEmbed"
    assert model.active_model_id == "nomic-ai/CodeRankEmbed"


def test_openai_initialization_failure_without_user_key_raises_clear_error(monkeypatch) -> None:
    monkeypatch.setitem(
        sys.modules,
        "langchain_openai",
        SimpleNamespace(OpenAIEmbeddings=_UnconfiguredOpenAIEmbeddings),
    )

    with bind_user_runtime(
        UserRuntimeSettings(embedding_provider="openai"),
        UserRuntimeSecrets(),
    ):
        with pytest.raises(RuntimeError, match="OpenAI features use only the API key saved in your user Settings"):
            pipeline_runtime.get_or_create_model()
