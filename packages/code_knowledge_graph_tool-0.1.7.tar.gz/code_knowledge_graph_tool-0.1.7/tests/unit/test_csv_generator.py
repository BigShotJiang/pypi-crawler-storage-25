"""Tests for csg/graph/csv_generator.py - CSV generation for KuzuDB."""

import pytest

from csg.domain.codebase.value_objects import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    NodeProperties,
    RelationshipType,
)
from csg.infrastructure.graph.csv_generator import escape_csv_field, generate_csvs
from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph


@pytest.mark.unit
class TestEscapeCsvField:
    def test_none(self):
        assert escape_csv_field(None) == ""

    def test_boolean_true(self):
        assert escape_csv_field(True) == "true"

    def test_boolean_false(self):
        assert escape_csv_field(False) == "false"

    def test_simple_string(self):
        assert escape_csv_field("hello") == "hello"

    def test_comma(self):
        result = escape_csv_field("a,b")
        assert result == '"a,b"'

    def test_quotes(self):
        result = escape_csv_field('say "hi"')
        assert '""' in result  # doubled quotes

    def test_newline(self):
        result = escape_csv_field("line1\nline2")
        assert result.startswith('"')  # quoted

    def test_none_string(self):
        assert escape_csv_field("None") == ""

    def test_integer(self):
        assert escape_csv_field(42) == "42"

    def test_float(self):
        assert escape_csv_field(3.14) == "3.14"


@pytest.mark.unit
def test_code_relation_csv_includes_nullable_review_label(workspace_temp_dir):
    graph = KnowledgeGraph()
    graph.add_node(GraphNode("file-1", NodeLabel.FILE, NodeProperties(name="a.py")))
    graph.add_node(GraphNode("func-1", NodeLabel.FUNCTION, NodeProperties(name="foo")))
    graph.add_relationship(GraphRelationship(
        id="rel-1",
        source_id="file-1",
        target_id="func-1",
        type=RelationshipType.CALLS,
        reason="global-ambiguous",
        review_label="AMBIGUOUS",
    ))

    result = generate_csvs(graph, str(workspace_temp_dir))
    csv_text = open(result.files["CodeRelation"], encoding="utf-8").read()

    assert csv_text.splitlines()[0].endswith(",reviewLabel")
    assert csv_text.splitlines()[1].endswith(",AMBIGUOUS")

