from pathlib import Path

from csg.presentation.web.paths import project_root_from_web_file


def test_project_root_from_web_file_points_to_repository_root() -> None:
    web_app_file = Path(__file__).resolve().parents[2] / "csg" / "presentation" / "web" / "app.py"
    expected_root = Path(__file__).resolve().parents[2]

    assert project_root_from_web_file(web_app_file) == expected_root
