"""Tests for analysis result issue serialization."""

from __future__ import annotations

import pytest

from csg.application.use_cases.analysis.graph_results import serialize_results
from csg.domain.codebase.value_objects import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    NodeProperties,
    RelationshipType,
)
from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph


def _file(path: str, content: str = "") -> GraphNode:
    return GraphNode(
        f"File:{path}",
        NodeLabel.FILE,
        NodeProperties(name=path.rsplit("/", 1)[-1], file_path=path, content=content),
    )


def _function(path: str, name: str, content: str = "") -> GraphNode:
    return GraphNode(
        f"Function:{path}:{name}",
        NodeLabel.FUNCTION,
        NodeProperties(name=name, file_path=path, content=content),
    )


def _rel(source: GraphNode, target: GraphNode, rel_type: RelationshipType, suffix: str = "") -> GraphRelationship:
    extra = f":{suffix}" if suffix else ""
    return GraphRelationship(
        id=f"{rel_type.value}:{source.id}->{target.id}{extra}",
        source_id=source.id,
        target_id=target.id,
        type=rel_type,
    )


@pytest.mark.unit
def test_serialize_results_includes_documented_issue_groups():
    graph = KnowledgeGraph()

    large_file = _file(
        "src/services/large.py",
        "if a:\n  pass\nfor x in xs:\n  pass\nwhile ok:\n  pass\ncatch_error = True\n"
        + " && ".join(["a"] * 18)
        + " || "
        + " || ".join(["b"] * 16),
    )
    hub_file = _file("src/utils/hub.py")
    cycle_a = _file("src/a.py")
    cycle_b = _file("src/b.py")
    data_file = _file("src/data/repo.py")
    ui_file = _file("src/ui/view.py")

    for node in [large_file, hub_file, cycle_a, cycle_b, data_file, ui_file]:
        graph.add_node(node)

    unused = _function("src/services/large.py", "orphan")
    graph.add_node(unused)
    graph.add_relationship(_rel(large_file, unused, RelationshipType.DEFINES))

    for index in range(16):
        fn = _function("src/services/large.py", f"helper_{index}")
        graph.add_node(fn)
        graph.add_relationship(_rel(large_file, fn, RelationshipType.DEFINES, str(index)))

    for index in range(9):
        source_file = _file(f"src/feature_{index}.py")
        graph.add_node(source_file)
        graph.add_relationship(_rel(source_file, hub_file, RelationshipType.IMPORTS, str(index)))

    graph.add_relationship(_rel(cycle_a, cycle_b, RelationshipType.IMPORTS, "forward"))
    graph.add_relationship(_rel(cycle_b, cycle_a, RelationshipType.IMPORTS, "back"))
    graph.add_relationship(_rel(data_file, ui_file, RelationshipType.IMPORTS))

    duplicate_content = "def sync(value):\n    return value + 1\n"
    for path in ["src/one.py", "src/two.py", "src/three.py"]:
        file_node = _file(path)
        fn = _function(path, "sync", duplicate_content)
        graph.add_node(file_node)
        graph.add_node(fn)
        graph.add_relationship(_rel(file_node, fn, RelationshipType.DEFINES))

    for path, name in [("src/copy_a.py", "copy_a"), ("src/copy_b.py", "copy_b")]:
        file_node = _file(path)
        fn = _function(path, name, "def copied(items):\n    total = 0\n    for item in items:\n        total += item\n    return total\n")
        graph.add_node(file_node)
        graph.add_node(fn)
        graph.add_relationship(_rel(file_node, fn, RelationshipType.DEFINES))

    result = serialize_results({"knowledge_graph": graph, "file_paths": []})

    categories = {issue["category"] for issue in result["issues"]}
    assert {
        "Unused Functions",
        "Large Files",
        "Highly Coupled",
        "Circular Dependencies",
        "Duplicate Function Names",
        "Similar Code Blocks",
        "Architecture Violations",
        "High Complexity Files",
    }.issubset(categories)

    unused_issue = next(issue for issue in result["issues"] if issue["category"] == "Unused Functions")
    assert unused_issue["filePath"] == "src/services/large.py"
    assert unused_issue["nodeIds"] == [unused.id]
