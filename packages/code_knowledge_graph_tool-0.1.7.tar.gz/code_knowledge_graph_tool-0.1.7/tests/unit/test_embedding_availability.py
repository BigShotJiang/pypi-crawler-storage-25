"""Tests for embedding availability gating."""

from __future__ import annotations

from csg.infrastructure.analysis.internal.analysis import pipeline
from csg.infrastructure.analysis.internal.analysis.state import PipelineConfig
from csg.infrastructure.embeddings.internal import pipeline_runtime
from csg.infrastructure.runtime.user_context import UserRuntimeSecrets, UserRuntimeSettings, bind_user_runtime


def test_can_run_embeddings_with_user_openai_key_without_local_runtime(monkeypatch):
    monkeypatch.setattr(pipeline_runtime, "_has_local_embedding_runtime", lambda: False)

    with bind_user_runtime(
        UserRuntimeSettings(embedding_provider="openai"),
        UserRuntimeSecrets(openai_api_key="sk-user-runtime"),
    ):
        assert pipeline_runtime.can_run_embeddings("text-embedding-3-small") is True


def test_can_run_embeddings_ignores_environment_key_without_user_secret(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-env-only")
    monkeypatch.setattr(pipeline_runtime, "_has_local_embedding_runtime", lambda: False)

    with bind_user_runtime(
        UserRuntimeSettings(embedding_provider="openai"),
        UserRuntimeSecrets(),
    ):
        assert pipeline_runtime.can_run_embeddings("text-embedding-3-small") is False


def test_should_embed_uses_openai_availability_instead_of_sentence_transformers(monkeypatch):
    monkeypatch.setattr(pipeline_runtime, "can_run_embeddings", lambda model_id: True)
    state = {
        "config": PipelineConfig(embeddings=True, embedding_model="text-embedding-3-small"),
        "stats": {"nodes": 0},
    }

    assert pipeline._should_embed(state) == "generate_embeddings"


def test_should_embed_skips_when_no_embedding_backend_available(monkeypatch):
    monkeypatch.setattr(pipeline_runtime, "can_run_embeddings", lambda model_id: False)
    state = {
        "config": PipelineConfig(embeddings=True, embedding_model="text-embedding-3-small"),
        "stats": {"nodes": 10},
    }

    assert pipeline._should_embed(state) == pipeline.END
