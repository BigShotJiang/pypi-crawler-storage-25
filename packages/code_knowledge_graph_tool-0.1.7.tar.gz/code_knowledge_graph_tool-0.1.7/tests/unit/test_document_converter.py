"""Tests for csg/ingestion/document_converter.py - markdown conversion and preprocessing."""

import asyncio
from types import SimpleNamespace

import pytest

from csg.infrastructure.sources.internal import document_converter
from csg.infrastructure.sources.internal.document_converter import (
    convert_to_markdown,
    extract_sections,
    preprocess_markdown,
)


@pytest.mark.unit
def test_convert_to_markdown_uses_ocr_when_pdf_conversion_is_empty(monkeypatch, tmp_path):
    async def fake_extract_from_file(_file_path):
        return SimpleNamespace(content="   ")

    async def fake_ocr_file_to_markdown(file_path, language_hint=""):
        assert file_path == pdf_path
        assert language_hint == ""
        return "# Scanned Spec\n\nRead from image text."

    pdf_path = tmp_path / "spec.pdf"
    pdf_path.write_bytes(b"%PDF-1.7 scanned")

    monkeypatch.setattr(document_converter, "_extract_from_file", fake_extract_from_file)
    monkeypatch.setattr(document_converter, "ocr_file_to_markdown", fake_ocr_file_to_markdown)

    assert asyncio.run(convert_to_markdown(pdf_path)) == "# Scanned Spec\n\nRead from image text."


@pytest.mark.unit
def test_convert_to_markdown_uses_ocr_when_pdf_conversion_is_low_quality(monkeypatch, tmp_path):
    async def fake_extract_from_file(_file_path):
        return SimpleNamespace(content="Page 1\n\nPage 2\n\n1")

    async def fake_ocr_file_to_markdown(file_path, language_hint=""):
        assert file_path == pdf_path
        return "# OCR Spec\n\nActual scanned document content."

    pdf_path = tmp_path / "scan.pdf"
    pdf_path.write_bytes(b"%PDF-1.7 scanned pages")

    monkeypatch.setattr(document_converter, "_extract_from_file", fake_extract_from_file)
    monkeypatch.setattr(document_converter, "ocr_file_to_markdown", fake_ocr_file_to_markdown)

    assert asyncio.run(convert_to_markdown(pdf_path)) == "# OCR Spec\n\nActual scanned document content."


@pytest.mark.unit
def test_convert_to_markdown_skips_ocr_when_conversion_has_content(monkeypatch, tmp_path):
    async def fake_extract_from_file(_file_path):
        return SimpleNamespace(content="# Text PDF\n\nSelectable text.")

    async def fail_if_called(_file_path, language_hint=""):
        raise AssertionError("OCR should not run when conversion already produced text")

    pdf_path = tmp_path / "spec.pdf"
    pdf_path.write_bytes(b"%PDF-1.7 text")

    monkeypatch.setattr(document_converter, "_extract_from_file", fake_extract_from_file)
    monkeypatch.setattr(document_converter, "ocr_file_to_markdown", fail_if_called)

    assert asyncio.run(convert_to_markdown(pdf_path)) == "# Text PDF\n\nSelectable text."


@pytest.mark.unit
class TestPreprocessMarkdown:
    def test_strips_emoji(self):
        result = preprocess_markdown("Hello \U0001F600 World")
        assert "\U0001F600" not in result
        assert "Hello" in result
        assert "World" in result

    def test_strips_dingbats(self):
        result = preprocess_markdown("Check \u2702 this")
        assert "\u2702" not in result

    def test_strips_zero_width(self):
        result = preprocess_markdown("Hello\u200BWorld")
        assert "\u200B" not in result

    def test_collapses_newlines(self):
        result = preprocess_markdown("A\n\n\n\n\nB")
        assert "\n\n\n" not in result
        assert "A\n\nB" == result

    def test_strips_trailing_whitespace(self):
        result = preprocess_markdown("line1   \nline2  ")
        assert "   \n" not in result

    def test_normalizes_crlf(self):
        result = preprocess_markdown("line1\r\nline2")
        assert "\r\n" not in result
        assert "line1\nline2" == result

    def test_empty_input(self):
        assert preprocess_markdown("") == ""
        assert preprocess_markdown("   ") == ""

    def test_preserves_content(self):
        md = "# Title\n\nSome **bold** text with `code`."
        result = preprocess_markdown(md)
        assert "# Title" in result
        assert "**bold**" in result

    def test_preserves_vietnamese(self):
        md = "# Gi\u1edbi thi\u1ec7u\n\n\u0110\u00e2y l\u00e0 t\u00e0i li\u1ec7u thi\u1ebft k\u1ebf."
        result = preprocess_markdown(md)
        assert "Gi\u1edbi thi\u1ec7u" in result
        assert "thi\u1ebft k\u1ebf" in result

    def test_preserves_japanese(self):
        md = "# \u6982\u8981\n\n\u30b7\u30b9\u30c6\u30e0\u306e\u8a2d\u8a08\u66f8\u3067\u3059\u3002"
        result = preprocess_markdown(md)
        assert "\u6982\u8981" in result
        assert "\u8a2d\u8a08\u66f8" in result


@pytest.mark.unit
class TestExtractSections:
    def test_single_heading(self):
        md = "# Title\n\nBody text here."
        sections = extract_sections(md, "doc.md")
        assert len(sections) == 1
        assert sections[0].heading == "Title"
        assert sections[0].level == 1
        assert "Body text" in sections[0].content

    def test_multiple_headings(self):
        md = "# H1\n\nBody1\n\n## H2\n\nBody2\n\n## H2b\n\nBody3"
        sections = extract_sections(md, "doc.md")
        assert len(sections) == 3
        assert sections[0].heading == "H1"
        assert sections[1].heading == "H2"
        assert sections[2].heading == "H2b"

    def test_heading_levels(self):
        md = "# L1\n\nA\n\n## L2\n\nB\n\n### L3\n\nC"
        sections = extract_sections(md, "doc.md")
        assert sections[0].level == 1
        assert sections[1].level == 2
        assert sections[2].level == 3
        assert sections[0].description == "h1"
        assert sections[1].description == "h2"

    def test_no_headings_chunks(self):
        md = "Paragraph one.\n\nParagraph two.\n\nParagraph three."
        sections = extract_sections(md, "doc.md", max_content=50)
        assert len(sections) >= 1
        assert sections[0].description == "chunk"

    def test_empty_markdown(self):
        assert extract_sections("", "doc.md") == []
        assert extract_sections("   \n\n  ", "doc.md") == []

    def test_content_truncation(self):
        md = "# Title\n\n" + "x" * 5000
        sections = extract_sections(md, "doc.md", max_content=100)
        assert len(sections[0].content) <= 100

    def test_tables_preserved(self):
        md = "# Data\n\n| Col1 | Col2 |\n|------|------|\n| A | B |"
        sections = extract_sections(md, "doc.md")
        assert "|" in sections[0].content
