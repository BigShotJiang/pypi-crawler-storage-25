"""Tests for csg/ingestion/symbol_table.py - multi-index symbol registry."""

import pytest

from csg.infrastructure.analysis.internal.analysis.analysis.symbol_table import SymbolTable


@pytest.mark.unit
class TestSymbolTable:
    @pytest.fixture
    def st(self) -> SymbolTable:
        return SymbolTable()

    def test_add_and_lookup_exact(self, st):
        st.add("src/main.py", "main", "Function:src/main.py:main", "Function")
        assert st.lookup_exact("src/main.py", "main") == "Function:src/main.py:main"

    def test_lookup_exact_miss(self, st):
        assert st.lookup_exact("nonexistent.py", "foo") is None
        st.add("src/main.py", "main", "id1", "Function")
        assert st.lookup_exact("src/main.py", "missing") is None

    def test_lookup_exact_full(self, st):
        st.add("src/main.py", "main", "id1", "Function", return_type="int")
        defn = st.lookup_exact_full("src/main.py", "main")
        assert defn is not None
        assert defn.return_type == "int"

    def test_lookup_exact_all_overloads(self, st):
        st.add("src/a.py", "foo", "id1", "Function")
        st.add("src/a.py", "foo", "id2", "Function")
        results = st.lookup_exact_all("src/a.py", "foo")
        assert len(results) == 2

    def test_lookup_fuzzy_global(self, st):
        st.add("src/a.py", "MyClass", "id1", "Class")
        st.add("src/b.py", "MyClass", "id2", "Class")
        results = st.lookup_fuzzy("MyClass")
        assert len(results) == 2

    def test_lookup_fuzzy_miss(self, st):
        assert st.lookup_fuzzy("NonExistent") == []

    def test_lookup_fuzzy_callable(self, st):
        st.add("src/a.py", "foo", "id1", "Function")
        st.add("src/a.py", "foo", "id2", "Property")
        results = st.lookup_fuzzy_callable("foo")
        assert len(results) == 1
        assert results[0].type == "Function"

    def test_callable_cache_invalidation(self, st):
        st.add("src/a.py", "foo", "id1", "Function")
        assert len(st.lookup_fuzzy_callable("foo")) == 1
        st.add("src/b.py", "foo", "id2", "Method")
        assert len(st.lookup_fuzzy_callable("foo")) == 2

    def test_property_excluded_from_global(self, st):
        st.add("src/a.py", "value", "id1", "Property")
        assert st.lookup_fuzzy("value") == []

    def test_lookup_field_by_owner(self, st):
        st.add("src/a.py", "run", "id1", "Method", owner_id="Class:App")
        result = st.lookup_field_by_owner("Class:App", "run")
        assert result is not None
        assert result.node_id == "id1"

    def test_lookup_field_by_owner_miss(self, st):
        assert st.lookup_field_by_owner("unknown", "field") is None

    def test_get_stats(self, st):
        st.add("src/a.py", "foo", "id1", "Function")
        st.add("src/a.py", "bar", "id2", "Function")
        st.add("src/b.py", "baz", "id3", "Class")
        stats = st.get_stats()
        assert stats["files"] == 2
        assert stats["symbols"] == 3
        assert stats["global_names"] == 3

    def test_clear(self, st):
        st.add("src/a.py", "foo", "id1", "Function")
        st.clear()
        assert st.lookup_exact("src/a.py", "foo") is None
        assert st.lookup_fuzzy("foo") == []
        assert st.get_stats()["symbols"] == 0

