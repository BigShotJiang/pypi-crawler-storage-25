"""Tests for presentation/mcp/hints.py — next-step hint generation."""

import pytest

from csg.presentation.mcp.hints import get_next_step_hint, _pick_symbols


@pytest.mark.unit
class TestGetNextStepHint:
    def test_explore_with_error(self):
        hint = get_next_step_hint("csg_explore", {}, {"error": "not found"})
        assert "csg_list_repos" in hint

    def test_explore_weak_signal(self):
        result = {"_meta": {"search": {"signal": "weak"}}}
        hint = get_next_step_hint("csg_explore", {}, result)
        assert "broader" in hint.lower() or "weak" in hint.lower()

    def test_explore_with_symbols(self):
        result = {"contracts": {"symbols": [{"name": "main"}, {"name": "app"}]}}
        hint = get_next_step_hint("csg_explore", {}, result)
        assert "layer=" in hint or "contract" in hint
        assert "main" in hint

    def test_context_with_error(self):
        hint = get_next_step_hint("csg_context", {"symbol": "foo"}, {"error": "not found"})
        assert "csg_explore" in hint

    def test_context_with_callers(self):
        result = {"callers": [{"name": "handler"}], "callees": []}
        hint = get_next_step_hint("csg_context", {"symbol": "foo"}, result)
        assert "csg_impact" in hint
        assert "handler" in hint

    def test_context_multiple_candidates(self):
        result = {
            "callers": [], "callees": [],
            "candidates": [
                {"filePath": "src/a.py"},
                {"filePath": "src/b.py"},
            ],
        }
        hint = get_next_step_hint("csg_context", {"symbol": "foo"}, result)
        assert "Multiple" in hint or "scope" in hint

    def test_impact_with_stats(self):
        result = {
            "risk": "HIGH", "stats": {"d1": 15, "total": 30, "unresolved": 2},
            "affected": [{"depth": 1, "name": "handler", "type": "Function"}],
        }
        hint = get_next_step_hint("csg_impact", {}, result)
        assert "HIGH" in hint
        assert "15" in hint

    def test_detect_changes_no_changes(self):
        result = {"total_files": 0, "total_symbols": 0}
        hint = get_next_step_hint("csg_detect_changes", {}, result)
        assert "No uncommitted changes" in hint

    def test_rename_dry_run(self):
        result = {"dry_run": True, "counts": {"definitions": 1, "usages": 5}}
        hint = get_next_step_hint("csg_rename", {}, result)
        assert "dry_run=false" in hint

    def test_rename_applied(self):
        result = {"dry_run": False, "counts": {"definitions": 1, "usages": 5}}
        hint = get_next_step_hint("csg_rename", {}, result)
        assert "Renamed" in hint

    def test_list_repos_empty(self):
        hint = get_next_step_hint("csg_list_repos", {}, {"repos": []})
        assert "csg_analyze" in hint

    def test_list_repos_with_repos(self):
        result = {"repos": [{"name": "myrepo"}]}
        hint = get_next_step_hint("csg_list_repos", {}, result)
        assert "myrepo" in hint

    def test_unknown_tool(self):
        assert get_next_step_hint("unknown_tool", {}, {}) == ""


@pytest.mark.unit
class TestPickSymbols:
    def test_from_contracts(self):
        result = {"contracts": {"symbols": [{"name": "foo"}, {"name": "bar"}]}}
        assert _pick_symbols(result) == ["foo", "bar"]

    def test_max_count(self):
        symbols = [{"name": f"sym{i}"} for i in range(10)]
        result = {"contracts": {"symbols": symbols}}
        assert len(_pick_symbols(result, max_count=2)) == 2

    def test_empty_result(self):
        assert _pick_symbols({}) == []
