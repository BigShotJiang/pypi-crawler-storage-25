from __future__ import annotations

import threading

import pytest

from csg.infrastructure.analysis.internal.analysis.state import (
    PipelineCancelled,
    PipelineConfig,
    check_cancelled,
)


def test_check_cancelled_ignores_missing_cancel_event() -> None:
    config = PipelineConfig(cancel_event=None)  # type: ignore[arg-type]

    check_cancelled({"config": config})


def test_check_cancelled_raises_when_event_is_set() -> None:
    event = threading.Event()
    event.set()

    with pytest.raises(PipelineCancelled):
        check_cancelled({"config": PipelineConfig(cancel_event=event)})
