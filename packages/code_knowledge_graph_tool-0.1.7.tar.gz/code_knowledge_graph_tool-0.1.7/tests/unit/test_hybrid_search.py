"""Tests for csg/search/hybrid_search.py - reciprocal rank fusion."""

import pytest

from csg.infrastructure.search.internal.bm25_runtime import BM25SearchResult
from csg.infrastructure.search.internal.hybrid_runtime import SemanticSearchResult, merge_with_rrf


def _bm25(name, score, file_path="src/a.py"):
    return BM25SearchResult(file_path=file_path, score=score, rank=0)


def _semantic(name, distance, file_path="src/a.py"):
    return SemanticSearchResult(
        node_id=f"Function:{file_path}:{name}",
        name=name, label="Function", file_path=file_path,
        distance=distance, start_line=1, end_line=10,
    )


@pytest.mark.unit
class TestMergeWithRrf:
    def test_bm25_only(self):
        bm25 = [_bm25("foo", 2.0), _bm25("bar", 1.5, "src/b.py")]
        results = merge_with_rrf(bm25, [], limit=10)
        assert len(results) == 2
        assert results[0].file_path == "src/a.py"

    def test_semantic_only(self):
        sem = [_semantic("foo", 0.1), _semantic("bar", 0.5, "src/b.py")]
        results = merge_with_rrf([], sem, limit=10)
        assert len(results) == 2

    def test_merged_boost(self):
        bm25 = [_bm25("foo", 2.0), _bm25("bar", 1.5, "src/b.py")]
        sem = [_semantic("foo", 0.1), _semantic("baz", 0.3, "src/c.py")]
        results = merge_with_rrf(bm25, sem, limit=10)
        # "foo" in src/a.py appears in both -> highest combined score
        assert results[0].file_path == "src/a.py"
        assert "bm25" in results[0].sources
        assert "semantic" in results[0].sources
        assert len(results) == 3

    def test_limit_respected(self):
        bm25 = [_bm25(f"item{i}", float(10 - i), f"src/{i}.py") for i in range(10)]
        results = merge_with_rrf(bm25, [], limit=3)
        assert len(results) == 3

    def test_empty_inputs(self):
        results = merge_with_rrf([], [], limit=10)
        assert results == []

    def test_rrf_score_formula(self):
        bm25 = [_bm25("foo", 5.0)]
        results = merge_with_rrf(bm25, [], limit=10)
        # rank 0 -> RRF = 1/(60 + 0 + 1) = 1/61
        assert results[0].score == pytest.approx(1.0 / 61)

