"""Tests for csg/config.py - language detection and extension mapping."""

import pytest

from csg.infrastructure.config.language import (
    AMBIGUOUS_EXTENSIONS,
    EXTENSION_MAP,
    SupportedLanguages,
    get_language_from_filename,
    is_tsx_file,
)


@pytest.mark.unit
class TestSupportedLanguages:
    def test_has_36_members(self):
        assert len(SupportedLanguages) == 36

    def test_extension_map_covers_all_non_ambiguous_languages(self):
        mapped_langs = set(EXTENSION_MAP.values())
        # Also include languages only reachable via ambiguous extensions
        for candidates in AMBIGUOUS_EXTENSIONS.values():
            for lang, _ in candidates:
                mapped_langs.add(lang)
        for lang in SupportedLanguages:
            assert lang in mapped_langs, f"{lang} not in EXTENSION_MAP or AMBIGUOUS_EXTENSIONS"


@pytest.mark.unit
class TestGetLanguageFromFilename:
    @pytest.mark.parametrize("filename, expected", [
        # -- Original 14 ---------------------------------------------
        ("main.py", SupportedLanguages.PYTHON),
        ("stubs.pyi", SupportedLanguages.PYTHON),
        ("app.ts", SupportedLanguages.TYPESCRIPT),
        ("component.tsx", SupportedLanguages.TYPESCRIPT),
        ("index.mts", SupportedLanguages.TYPESCRIPT),
        ("utils.cts", SupportedLanguages.TYPESCRIPT),
        ("index.js", SupportedLanguages.JAVASCRIPT),
        ("component.jsx", SupportedLanguages.JAVASCRIPT),
        ("module.mjs", SupportedLanguages.JAVASCRIPT),
        ("compat.cjs", SupportedLanguages.JAVASCRIPT),
        ("App.java", SupportedLanguages.JAVA),
        ("main.c", SupportedLanguages.C),
        ("header.h", SupportedLanguages.C),
        ("main.cpp", SupportedLanguages.C_PLUS_PLUS),
        ("main.cxx", SupportedLanguages.C_PLUS_PLUS),
        ("main.cc", SupportedLanguages.C_PLUS_PLUS),
        ("header.hpp", SupportedLanguages.C_PLUS_PLUS),
        ("header.hxx", SupportedLanguages.C_PLUS_PLUS),
        ("header.hh", SupportedLanguages.C_PLUS_PLUS),
        ("Program.cs", SupportedLanguages.C_SHARP),
        ("main.go", SupportedLanguages.GO),
        ("app.rb", SupportedLanguages.RUBY),
        ("lib.rs", SupportedLanguages.RUST),
        ("index.php", SupportedLanguages.PHP),
        ("Main.kt", SupportedLanguages.KOTLIN),
        ("build.kts", SupportedLanguages.KOTLIN),
        ("App.swift", SupportedLanguages.SWIFT),
        ("Module1.bas", SupportedLanguages.VB6),
        ("Form1.frm", SupportedLanguages.VB6),
        # -- New languages (unambiguous extensions) -------------------
        ("sim.f90", SupportedLanguages.FORTRAN),
        ("sim.f", SupportedLanguages.FORTRAN),
        ("App.scala", SupportedLanguages.SCALA),
        ("view.mm", SupportedLanguages.OBJECTIVE_C),
        ("Token.sol", SupportedLanguages.SOLIDITY),
        ("script.mlx", SupportedLanguages.MATLAB),
        ("utils.lisp", SupportedLanguages.COMMON_LISP),
        ("main.dpr", SupportedLanguages.DELPHI),
        ("pkg.ads", SupportedLanguages.ADA),
        ("Mod.pm", SupportedLanguages.PERL),
        ("prog.cob", SupportedLanguages.COBOL),
        ("srv.erl", SupportedLanguages.ERLANG),
        ("MyTrigger.trigger", SupportedLanguages.APEX),
        ("unit.pas", SupportedLanguages.PASCAL),
        ("rules.pro", SupportedLanguages.PROLOG),
        ("pgm.rpgle", SupportedLanguages.RPG),
        ("report.abap", SupportedLanguages.ABAP),
        ("routine.mps", SupportedLanguages.MUMPS),
        ("boot.asm", SupportedLanguages.ASSEMBLY),
        ("gui.tcl", SupportedLanguages.TCL),
        ("prog.alg", SupportedLanguages.ALGOL),
        ("core.fs", SupportedLanguages.FORTH),
        ("doc.ps", SupportedLanguages.POSTSCRIPT),
    ])
    def test_known_extensions(self, filename, expected):
        assert get_language_from_filename(filename) == expected

    def test_unknown_extension_returns_none(self):
        assert get_language_from_filename("data.xyz") is None
        assert get_language_from_filename("page.html") is None
        assert get_language_from_filename("style.css") is None

    def test_case_insensitive(self):
        assert get_language_from_filename("Main.PY") == SupportedLanguages.PYTHON
        assert get_language_from_filename("App.Ts") == SupportedLanguages.TYPESCRIPT

    def test_no_extension(self):
        assert get_language_from_filename("Makefile") is None


@pytest.mark.unit
class TestAmbiguousExtensions:
    def test_dot_m_objective_c(self):
        content = '#import <Foundation/Foundation.h>\n@interface Foo : NSObject\n@end'
        assert get_language_from_filename("test.m", content) == SupportedLanguages.OBJECTIVE_C

    def test_dot_m_matlab(self):
        content = 'function y = square(x)\ny = x^2;\nend'
        assert get_language_from_filename("test.m", content) == SupportedLanguages.MATLAB

    def test_dot_m_no_content_defaults_to_first(self):
        result = get_language_from_filename("test.m")
        assert result == SupportedLanguages.OBJECTIVE_C

    def test_dot_cls_vb6(self):
        content = 'VERSION 1.0 CLASS\nBEGIN\nMultiUse = -1\nEND'
        assert get_language_from_filename("test.cls", content) == SupportedLanguages.VB6

    def test_dot_cls_apex(self):
        content = 'public class AccountTriggerHandler {\n  public void handle() {}\n}'
        assert get_language_from_filename("test.cls", content) == SupportedLanguages.APEX

    def test_dot_pl_perl(self):
        content = '#!/usr/bin/perl\nuse strict;\nuse warnings;\nmy $x = 42;'
        assert get_language_from_filename("test.pl", content) == SupportedLanguages.PERL

    def test_dot_pl_prolog(self):
        content = ':- module(facts, [parent/2]).\nparent(tom, bob).'
        assert get_language_from_filename("test.pl", content) == SupportedLanguages.PROLOG


@pytest.mark.unit
class TestIsTsxFile:
    def test_tsx_true(self):
        assert is_tsx_file("component.tsx") is True

    def test_ts_false(self):
        assert is_tsx_file("utils.ts") is False

    def test_jsx_false(self):
        assert is_tsx_file("component.jsx") is False

    def test_case_insensitive(self):
        assert is_tsx_file("App.TSX") is True


