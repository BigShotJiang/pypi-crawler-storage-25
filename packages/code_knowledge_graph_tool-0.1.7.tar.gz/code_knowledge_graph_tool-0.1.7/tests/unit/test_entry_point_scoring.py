"""Tests for csg/ingestion/entry_point_scoring.py - score calculation."""

import pytest

from csg.infrastructure.config.language import SupportedLanguages
from csg.infrastructure.analysis.internal.analysis.analysis.entry_point_scoring import (
    calculate_entry_point_score,
    is_test_file,
    is_utility_file,
)


@pytest.mark.unit
class TestCalculateEntryPointScore:
    def test_zero_callees_non_entry(self):
        result = calculate_entry_point_score(
            name="helper_func", language=SupportedLanguages.PYTHON,
            is_exported=True, caller_count=0, callee_count=0,
        )
        assert result.score == 0
        assert "no-outgoing-calls" in result.reasons

    def test_zero_callees_entry_pattern_gets_floor_score(self):
        result = calculate_entry_point_score(
            name="main", language=SupportedLanguages.PYTHON,
            is_exported=True, caller_count=0, callee_count=0,
        )
        assert result.score == 0.5
        assert "entry-pattern-override" in result.reasons

    def test_base_calculation(self):
        result = calculate_entry_point_score(
            name="foo", language=SupportedLanguages.PYTHON,
            is_exported=False, caller_count=1, callee_count=4,
        )
        # base = 4 / (1+1) = 2.0, no export, no pattern match
        assert result.score == pytest.approx(2.0)

    def test_export_multiplier(self):
        result = calculate_entry_point_score(
            name="foo", language=SupportedLanguages.PYTHON,
            is_exported=True, caller_count=1, callee_count=4,
        )
        assert result.score == pytest.approx(4.0)
        assert "exported" in result.reasons

    def test_entry_pattern_match(self):
        result = calculate_entry_point_score(
            name="handleRequest", language=SupportedLanguages.PYTHON,
            is_exported=False, caller_count=0, callee_count=2,
        )
        # base=2.0, pattern=1.5x
        assert result.score == pytest.approx(3.0)
        assert "entry-pattern" in result.reasons

    def test_utility_pattern_penalty(self):
        result = calculate_entry_point_score(
            name="getString", language=SupportedLanguages.PYTHON,
            is_exported=False, caller_count=0, callee_count=2,
        )
        # base=2.0, utility=0.3x
        assert result.score == pytest.approx(0.6)
        assert "utility-pattern" in result.reasons

    def test_python_language_pattern(self):
        result = calculate_entry_point_score(
            name="app", language=SupportedLanguages.PYTHON,
            is_exported=True, caller_count=0, callee_count=2,
        )
        assert "entry-pattern" in result.reasons


@pytest.mark.unit
class TestIsTestFile:
    @pytest.mark.parametrize("path", [
        "src/auth.spec.ts",
        "src/auth.test.js",
        "tests/test_main.py",
        "__tests__/app.test.js",
        "main_test.go",
        "src/test/java/AppTest.java",
        "spec/models/user_spec.rb",
    ])
    def test_true(self, path):
        assert is_test_file(path) is True

    @pytest.mark.parametrize("path", [
        "src/main.py",
        "src/controllers/auth.ts",
        "lib/utils.go",
    ])
    def test_false(self, path):
        assert is_test_file(path) is False


@pytest.mark.unit
class TestIsUtilityFile:
    @pytest.mark.parametrize("path", [
        "src/utils/helpers.ts",
        "src/util/format.ts",
        "src/helpers/date.ts",
        "src/common/types.ts",
        "src/shared/constants.ts",
    ])
    def test_true(self, path):
        assert is_utility_file(path) is True

    @pytest.mark.parametrize("path", [
        "src/controllers/auth.ts",
        "src/main.py",
    ])
    def test_false(self, path):
        assert is_utility_file(path) is False



