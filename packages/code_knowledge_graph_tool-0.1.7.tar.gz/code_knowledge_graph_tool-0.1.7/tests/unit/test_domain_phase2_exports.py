"""Domain export tests for clean-architecture boundary hardening."""

from csg.domain.analysis.events import PipelineCancelled as DomainEventPipelineCancelled
from csg.domain.analysis.job import PipelineConfig as DomainPipelineConfig
from csg.domain.analysis.job import PipelineState as DomainPipelineState
from csg.domain.analysis.policies import check_cancelled as DomainCheckCancelled
from csg.domain.analysis.progress import PipelineProgress as DomainPipelineProgress
from csg.domain.analysis.result import PipelineResult as DomainPipelineResult
from csg.domain.codebase.value_objects import GraphNode as DomainGraphNode
from csg.domain.codebase.value_objects import GraphRelationship as DomainGraphRelationship
from csg.domain.codebase.value_objects import NodeLabel as DomainNodeLabel
from csg.domain.codebase.value_objects import NodeProperties as DomainNodeProperties
from csg.domain.codebase.value_objects import RelationshipType as DomainRelationshipType
from csg.domain.errors import PipelineCancelled as DomainErrorPipelineCancelled


def test_domain_phase2_exports_are_pure_domain_types():
    assert DomainPipelineConfig.__module__.startswith("csg.domain.")
    assert DomainPipelineState.__module__.startswith("csg.domain.")
    assert DomainPipelineProgress.__module__.startswith("csg.domain.")
    assert DomainCheckCancelled.__module__.startswith("csg.domain.")
    assert DomainEventPipelineCancelled.__module__.startswith("csg.domain.")
    assert DomainErrorPipelineCancelled.__module__.startswith("csg.domain.")
    assert DomainEventPipelineCancelled is DomainErrorPipelineCancelled

    assert DomainPipelineResult.__name__ == "PipelineResult"
    assert DomainNodeLabel.__name__ == "NodeLabel"
    assert DomainRelationshipType.__name__ == "RelationshipType"
    assert DomainNodeProperties.__name__ == "NodeProperties"
    assert DomainGraphNode.__name__ == "GraphNode"
    assert DomainGraphRelationship.__name__ == "GraphRelationship"

