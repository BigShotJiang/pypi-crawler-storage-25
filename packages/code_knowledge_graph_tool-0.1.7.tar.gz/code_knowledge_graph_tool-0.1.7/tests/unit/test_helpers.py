"""Tests for presentation/mcp/backend/_helpers.py — response compression."""

import pytest

from csg.presentation.mcp.backend._helpers import (
    _ResponseAccumulator,
    _estimate_tokens,
)


@pytest.mark.unit
class TestEstimateTokens:
    def test_string(self):
        tokens = _estimate_tokens("hello world")
        assert tokens > 0

    def test_dict(self):
        tokens = _estimate_tokens({"key": "value", "nested": {"a": 1}})
        assert tokens > 0

    def test_empty(self):
        assert _estimate_tokens("") >= 0

    def test_large_data(self):
        data = {"items": [{"name": f"item{i}"} for i in range(100)]}
        tokens = _estimate_tokens(data)
        assert tokens > 100  # should be substantial


@pytest.mark.unit
class TestResponseAccumulator:
    def test_can_add_within_budget(self):
        acc = _ResponseAccumulator(max_tokens=1000)
        assert acc.can_add(500) is True

    def test_can_add_exceeds_budget(self):
        acc = _ResponseAccumulator(max_tokens=100)
        acc.add("section1", {"data": "x" * 500})
        assert acc.can_add(500) is False

    def test_add_section(self):
        acc = _ResponseAccumulator(max_tokens=10000)
        acc.add("topology", {"communities": []})
        assert "topology" in acc.sections

    def test_finalize(self):
        acc = _ResponseAccumulator(max_tokens=10000)
        acc.add("topology", {"communities": ["A", "B"]})
        result = acc.finalize()
        assert "topology" in result
        assert "_meta" in result
        assert result["_meta"]["tokens_used"] >= 0
