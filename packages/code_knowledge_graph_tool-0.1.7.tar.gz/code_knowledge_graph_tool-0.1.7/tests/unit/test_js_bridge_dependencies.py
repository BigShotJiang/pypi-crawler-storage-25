"""Tests for Node dependency checks in parser bridges."""

import pytest

from csg.infrastructure.parsing.internal import vb6_bridge
from csg.infrastructure.parsing.internal import wasm_bridge


@pytest.mark.unit
def test_vb6_unavailable_when_web_tree_sitter_is_missing(tmp_path, monkeypatch):
    bridge_dir = tmp_path / "js_bridge"
    bridge_dir.mkdir()
    (bridge_dir / "tree-sitter-vb_dotnet.wasm").write_bytes(b"wasm")

    monkeypatch.setattr(vb6_bridge, "_NODE_BIN", "node")
    monkeypatch.setattr(vb6_bridge, "_JS_BRIDGE_DIR", bridge_dir)
    monkeypatch.setattr(wasm_bridge, "_JS_BRIDGE_DIR", bridge_dir)

    assert vb6_bridge.is_vb6_available() is False


@pytest.mark.unit
def test_vb6_parse_reports_missing_web_tree_sitter(tmp_path, monkeypatch):
    bridge_dir = tmp_path / "js_bridge"
    bridge_dir.mkdir()

    monkeypatch.setattr(vb6_bridge, "_NODE_BIN", "node")
    monkeypatch.setattr(vb6_bridge, "_JS_BRIDGE_DIR", bridge_dir)
    monkeypatch.setattr(vb6_bridge, "_PARSE_SCRIPT", bridge_dir / "parse_vb.mjs")
    monkeypatch.setattr(wasm_bridge, "_JS_BRIDGE_DIR", bridge_dir)

    with pytest.raises(RuntimeError, match="npm.cmd install"):
        vb6_bridge.parse_vb6("Sub Main()\nEnd Sub\n", "Module1.bas")


@pytest.mark.unit
def test_has_node_package_requires_installed_package_json(tmp_path, monkeypatch):
    bridge_dir = tmp_path / "js_bridge"
    package_dir = bridge_dir / "node_modules" / "web-tree-sitter"
    package_dir.mkdir(parents=True)

    monkeypatch.setattr(wasm_bridge, "_JS_BRIDGE_DIR", bridge_dir)
    assert wasm_bridge._has_node_package("web-tree-sitter") is False

    (package_dir / "package.json").write_text("{}", encoding="utf-8")
    assert wasm_bridge._has_node_package("web-tree-sitter") is True
