"""Tests for csg/graph/knowledge_graph.py - in-memory graph."""

import pytest

from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph
from csg.domain.codebase.value_objects import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    NodeProperties,
    RelationshipType,
)


@pytest.mark.unit
class TestKnowledgeGraph:
    def test_add_node_and_count(self, sample_knowledge_graph):
        assert sample_knowledge_graph.node_count == 5

    def test_add_node_idempotent(self):
        kg = KnowledgeGraph()
        node = GraphNode(id="n1", label=NodeLabel.FILE, properties=NodeProperties(name="a"))
        kg.add_node(node)
        kg.add_node(node)
        assert kg.node_count == 1

    def test_add_relationship_and_count(self, sample_knowledge_graph):
        assert sample_knowledge_graph.relationship_count == 3

    def test_add_relationship_idempotent(self):
        kg = KnowledgeGraph()
        rel = GraphRelationship(id="r1", source_id="a", target_id="b", type=RelationshipType.CALLS)
        kg.add_relationship(rel)
        kg.add_relationship(rel)
        assert kg.relationship_count == 1

    def test_get_node(self, sample_knowledge_graph):
        node = sample_knowledge_graph.get_node("Function:src/main.py:main")
        assert node is not None
        assert node.properties.name == "main"

    def test_get_node_miss(self, sample_knowledge_graph):
        assert sample_knowledge_graph.get_node("nonexistent") is None

    def test_remove_node_cascades(self, sample_knowledge_graph):
        # "Function:src/main.py:main" is in rel-1 (target) and rel-2 (source)
        removed = sample_knowledge_graph.remove_node("Function:src/main.py:main")
        assert removed is True
        assert sample_knowledge_graph.node_count == 4
        assert sample_knowledge_graph.relationship_count == 1  # only rel-3 remains

    def test_remove_node_miss(self, sample_knowledge_graph):
        assert sample_knowledge_graph.remove_node("nonexistent") is False

    def test_remove_nodes_by_file(self, sample_knowledge_graph):
        count = sample_knowledge_graph.remove_nodes_by_file("src/main.py")
        assert count == 2  # File + Function
        assert sample_knowledge_graph.node_count == 3

    def test_iter_nodes(self, sample_knowledge_graph):
        names = [n.properties.name for n in sample_knowledge_graph.iter_nodes()]
        assert "main" in names
        assert "App" in names

    def test_iter_relationships(self, sample_knowledge_graph):
        types = [r.type for r in sample_knowledge_graph.iter_relationships()]
        assert RelationshipType.CALLS in types
        assert RelationshipType.CONTAINS in types

    def test_nodes_property_returns_list(self, sample_knowledge_graph):
        nodes = sample_knowledge_graph.nodes
        assert isinstance(nodes, list)
        assert len(nodes) == 5

    def test_clear(self, sample_knowledge_graph):
        sample_knowledge_graph.clear()
        assert sample_knowledge_graph.node_count == 0
        assert sample_knowledge_graph.relationship_count == 0

