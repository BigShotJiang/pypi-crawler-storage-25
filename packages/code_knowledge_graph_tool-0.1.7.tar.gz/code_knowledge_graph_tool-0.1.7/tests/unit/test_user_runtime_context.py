from __future__ import annotations

import importlib
import sys
import threading
import types
from pathlib import Path

import pytest

from csg.infrastructure.runtime.user_context import (
    bind_current_context,
    UserRuntimeSecrets,
    UserRuntimeSettings,
    bind_user_runtime,
    get_user_runtime_secrets,
)


def test_get_llm_uses_request_scoped_openai_api_key(monkeypatch) -> None:
    captured: dict[str, object] = {}

    class FakeChatOpenAI:
        def __init__(self, **kwargs):
            captured.update(kwargs)

    fake_module = types.ModuleType("langchain_openai")
    fake_module.ChatOpenAI = FakeChatOpenAI
    monkeypatch.setitem(sys.modules, "langchain_openai", fake_module)
    llm_module = importlib.reload(importlib.import_module("csg.infrastructure.agent.internal.llm"))

    with bind_user_runtime(
        UserRuntimeSettings(llm_provider="openai"),
        UserRuntimeSecrets(openai_api_key="sk-user-runtime"),
    ):
        llm_module.get_llm()

    assert captured["api_key"] == "sk-user-runtime"
    assert captured["model"] == "gpt-5.4-nano"


def test_get_llm_does_not_fall_back_to_environment_openai_api_key(monkeypatch) -> None:
    class FakeChatOpenAI:
        def __init__(self, **_kwargs):
            raise AssertionError("ChatOpenAI should not be constructed without a user-scoped key")

    fake_module = types.ModuleType("langchain_openai")
    fake_module.ChatOpenAI = FakeChatOpenAI
    monkeypatch.setitem(sys.modules, "langchain_openai", fake_module)
    monkeypatch.setenv("OPENAI_API_KEY", "sk-env-only")
    llm_module = importlib.reload(importlib.import_module("csg.infrastructure.agent.internal.llm"))

    with bind_user_runtime(
        UserRuntimeSettings(llm_provider="openai"),
        UserRuntimeSecrets(),
    ):
        with pytest.raises(RuntimeError, match="OpenAI features use only the API key saved in your user Settings"):
            llm_module.get_llm()


def test_bind_current_context_preserves_runtime_secrets_in_new_thread() -> None:
    captured: dict[str, str] = {}

    with bind_user_runtime(
        UserRuntimeSettings(embedding_provider="openai"),
        UserRuntimeSecrets(openai_api_key="sk-user-runtime"),
    ):
        runner = bind_current_context(
            lambda: captured.setdefault("api_key", get_user_runtime_secrets().openai_api_key)
        )

    thread = threading.Thread(target=runner)
    thread.start()
    thread.join(timeout=2)

    assert captured["api_key"] == "sk-user-runtime"


def test_walk_repository_paths_respects_request_scoped_max_file_size(workspace_temp_dir: Path) -> None:
    class FakePathSpec:
        @staticmethod
        def from_lines(*_args, **_kwargs):
            class _Spec:
                def match_file(self, _path: str) -> bool:
                    return False

            return _Spec()

    fake_pathspec = types.ModuleType("pathspec")
    fake_pathspec.PathSpec = FakePathSpec
    sys.modules.setdefault("pathspec", fake_pathspec)
    walker_module = importlib.reload(importlib.import_module("csg.infrastructure.sources.internal.filesystem_walker"))

    small_file = workspace_temp_dir / "small.py"
    large_file = workspace_temp_dir / "large.py"
    small_file.write_text("print('ok')\n", encoding="utf-8")
    large_file.write_text("x" * 2048, encoding="utf-8")

    with bind_user_runtime(
        UserRuntimeSettings(max_file_size_kb=1),
        UserRuntimeSecrets(),
    ):
        scanned = walker_module.walk_repository_paths(workspace_temp_dir)

    paths = {item.path for item in scanned}
    assert "small.py" in paths
    assert "large.py" not in paths
