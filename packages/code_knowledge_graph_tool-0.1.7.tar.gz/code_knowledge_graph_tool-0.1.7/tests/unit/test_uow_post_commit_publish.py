"""Unit tests for unit-of-work post-commit publish sequencing."""

from __future__ import annotations

import pytest

from csg.infrastructure.events.event_publisher import InMemoryEventPublisher
from csg.infrastructure.repository.unit_of_work import InMemoryUnitOfWork


def test_commit_happens_before_publish():
    op_log: list[str] = []
    uow = InMemoryUnitOfWork(operation_log=op_log)
    publisher = InMemoryEventPublisher(operation_log=op_log)

    uow.add_event("analysis.completed", {"job_id": "job-1"})
    uow.commit()
    uow.publish_post_commit(publisher)

    assert op_log == ["commit", "publish:analysis.completed"]
    assert uow.committed is True
    assert uow.rolled_back is False
    assert publisher.published == [("analysis.completed", {"job_id": "job-1"})]


def test_publish_failure_does_not_rollback_committed_state():
    op_log: list[str] = []
    uow = InMemoryUnitOfWork(operation_log=op_log)
    publisher = InMemoryEventPublisher(
        fail_on={"analysis.completed"},
        operation_log=op_log,
    )

    uow.add_event("analysis.completed", {"job_id": "job-2"})
    uow.commit()

    with pytest.raises(RuntimeError, match="Publish failed for event"):
        uow.publish_post_commit(publisher)

    assert uow.committed is True
    assert uow.rolled_back is False
    # Failed event remains buffered for potential retry.
    buffered = uow.collect_events()
    assert buffered == [("analysis.completed", {"job_id": "job-2"})]
    assert op_log == ["commit", "publish:analysis.completed"]


def test_publish_before_commit_is_rejected():
    uow = InMemoryUnitOfWork()
    publisher = InMemoryEventPublisher()
    uow.add_event("analysis.completed", {"job_id": "job-3"})

    with pytest.raises(RuntimeError, match="before commit"):
        uow.publish_post_commit(publisher)


def test_rollback_clears_events_and_blocks_publish():
    op_log: list[str] = []
    uow = InMemoryUnitOfWork(operation_log=op_log)
    publisher = InMemoryEventPublisher(operation_log=op_log)

    uow.add_event("analysis.completed", {"job_id": "job-4"})
    uow.rollback()

    assert uow.committed is False
    assert uow.rolled_back is True
    assert uow.collect_events() == []

    with pytest.raises(RuntimeError, match="before commit"):
        uow.publish_post_commit(publisher)

    assert publisher.attempted == []
    assert publisher.published == []
