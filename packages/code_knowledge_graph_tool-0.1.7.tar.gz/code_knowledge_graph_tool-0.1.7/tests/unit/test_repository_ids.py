from __future__ import annotations

from pathlib import Path

from csg.domain.repository_ids import repository_id_from_storage_path


def test_repository_id_for_local_csg_storage_includes_repo_name(tmp_path: Path) -> None:
    repo = tmp_path / "target-repo"
    storage = repo / ".csg"

    repo_id = repository_id_from_storage_path(storage)

    assert repo_id.startswith("target-repo-")
    assert repo_id == repository_id_from_storage_path(storage)


def test_repository_id_for_central_storage_preserves_storage_dir_name() -> None:
    assert repository_id_from_storage_path(Path("data") / "repos" / "abc123") == "abc123"
