from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from csg.infrastructure.exploration.backend import Backend


def test_scoped_repo_uses_injected_adapter_factory() -> None:
    created: list[tuple[str, str | None]] = []

    class FakeAdapter:
        def __init__(self, db_path: str, repo_source_path: str | None = None) -> None:
            self._db_path = db_path
            self.repo_source_path = repo_source_path
            self.connected_read_only: bool | None = None
            self._name_cache: dict[str, str] = {}

        def connect(self, read_only: bool = False) -> None:
            self.connected_read_only = read_only

    def build_adapter(db_path: str, repo_source_path: str | None = None) -> FakeAdapter:
        created.append((db_path, repo_source_path))
        return FakeAdapter(db_path=db_path, repo_source_path=repo_source_path)

    entry = SimpleNamespace(
        storage_path=str(Path("data") / "repos" / "demo"),
        path="C:/work/demo-repo",
    )

    class FakeRepositoryRegistry:
        def get_repo_entry_by_name(self, repo: str):
            assert repo == "demo"
            return entry

    backend = Backend(
        object(),
        repository_registry=FakeRepositoryRegistry(),
        adapter_factory=build_adapter,
    )

    with backend._scoped_repo("demo"):
        scoped_adapter = backend._adapter
        assert isinstance(scoped_adapter, FakeAdapter)
        assert scoped_adapter.connected_read_only is True
        assert scoped_adapter.repo_source_path == entry.path

    assert created == [(str(Path(entry.storage_path) / "lbug"), entry.path)]
