"""Tests for edge review labels."""

from __future__ import annotations

import pytest

from csg.application.use_cases.analysis.graph_results import _build_graph_data
from csg.domain.codebase.value_objects import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    NodeProperties,
    RelationshipType,
)
from csg.infrastructure.analysis.internal.analysis.analysis.call_processor import process_calls
from csg.infrastructure.analysis.internal.analysis.analysis.resolution_context import ResolutionContext
from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph
from csg.infrastructure.parsing.internal.ingestion.parsing_processor import ExtractedCall
from csg.infrastructure.sources.internal.semantic_linker import link_sections_to_symbols


@pytest.mark.unit
def test_ambiguous_call_resolution_gets_review_label():
    graph = KnowledgeGraph()
    source_id = "Function:src/app.py:caller"
    target_id = "Function:src/app.py:target"
    alternate_id = "Function:src/app.py:target_alt"
    graph.add_node(GraphNode(source_id, NodeLabel.FUNCTION, NodeProperties(name="caller", file_path="src/app.py")))
    graph.add_node(GraphNode(target_id, NodeLabel.FUNCTION, NodeProperties(name="target", file_path="src/app.py")))
    graph.add_node(GraphNode(alternate_id, NodeLabel.FUNCTION, NodeProperties(name="target", file_path="src/app.py")))

    ctx = ResolutionContext()
    ctx.symbols.add("src/app.py", "target", target_id, "Function")
    ctx.symbols.add("src/app.py", "target", alternate_id, "Function")

    process_calls(
        graph,
        [ExtractedCall(file_path="src/app.py", called_name="target", source_id=source_id)],
        ctx,
    )

    rel = graph.relationships[0]
    assert rel.reason == "same-file-ambiguous"
    assert rel.review_label == "AMBIGUOUS"


class _SemanticAdapter:
    def vector_search(self, **_kwargs):
        return [
            {
                "nodeId": "Function:src/app.py:foo",
                "label": "Function",
                "filePath": "src/app.py",
                "similarity": 0.66,
            }
        ]


@pytest.mark.unit
def test_semantic_links_near_threshold_get_review_label():
    graph = KnowledgeGraph()
    graph.add_node(GraphNode(
        "Section:docs/guide.md:intro",
        NodeLabel.SECTION,
        NodeProperties(
            name="intro",
            file_path="docs/guide.md",
            content="This section explains the foo implementation details.",
        ),
    ))
    graph.add_node(GraphNode(
        "Function:src/app.py:foo",
        NodeLabel.FUNCTION,
        NodeProperties(name="foo", file_path="src/app.py"),
    ))

    link_sections_to_symbols(graph, _SemanticAdapter(), similarity_threshold=0.65)

    labels = {rel.type.value: rel.review_label for rel in graph.relationships}
    assert labels == {"DESCRIBES": "AMBIGUOUS", "DOCUMENTED_BY": "AMBIGUOUS"}


@pytest.mark.unit
def test_graph_payload_includes_review_label_for_edges():
    source = GraphNode("File:src/app.py", NodeLabel.FILE, NodeProperties(name="app.py"))
    target = GraphNode("Function:src/app.py:foo", NodeLabel.FUNCTION, NodeProperties(name="foo"))
    rel = GraphRelationship(
        id="rel-1",
        source_id=source.id,
        target_id=target.id,
        type=RelationshipType.CALLS,
        review_label="AMBIGUOUS",
    )

    graph_data = _build_graph_data([source, target], [rel])

    assert graph_data["edges"][0]["reviewLabel"] == "AMBIGUOUS"
