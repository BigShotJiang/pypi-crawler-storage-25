"""Tests for csg/search/tokenizer.py - identifier splitting."""

import pytest

from csg.infrastructure.search.internal.tokenizer_runtime import split_identifier


@pytest.mark.unit
class TestSplitIdentifier:
    def test_camel_case(self):
        result = split_identifier("useAuth")
        assert result.startswith("useAuth ")
        assert "use" in result
        assert "auth" in result

    def test_pascal_case(self):
        result = split_identifier("AuthGuard")
        assert result.startswith("AuthGuard ")
        assert "auth" in result
        assert "guard" in result

    def test_snake_case(self):
        result = split_identifier("get_user_by_id")
        assert result.startswith("get_user_by_id ")
        assert "get" in result
        assert "user" in result
        assert "by" in result
        assert "id" in result

    def test_kebab_case(self):
        result = split_identifier("my-component")
        assert result.startswith("my-component ")
        assert "my" in result
        assert "component" in result

    def test_acronym(self):
        result = split_identifier("HTMLParser")
        assert result.startswith("HTMLParser ")
        assert "html" in result
        assert "parser" in result

    def test_empty(self):
        assert split_identifier("") == ""

    def test_single_word(self):
        result = split_identifier("main")
        assert result.startswith("main ")
        assert "main" in result

    def test_dot_separated(self):
        result = split_identifier("com.example.App")
        assert result.startswith("com.example.App ")
        assert "com" in result
        assert "example" in result
        assert "app" in result

    def test_all_caps(self):
        result = split_identifier("HTTP")
        assert result.startswith("HTTP ")
        assert "http" in result

