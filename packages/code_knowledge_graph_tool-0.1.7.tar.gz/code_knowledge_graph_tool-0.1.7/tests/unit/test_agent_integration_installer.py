from __future__ import annotations

import json

from click.testing import CliRunner

from csg.application.use_cases.agent_integration import install_agent_integration
from csg.application.use_cases.agent_integration.setup_mcp_clients import setup_mcp_clients
from csg.presentation.cli.entry import main


def test_cli_version_uses_distribution_package_name():
    runner = CliRunner()

    result = runner.invoke(main, ["--version"])

    assert result.exit_code == 0
    assert result.output.startswith("csg, version ")


def test_installs_codex_and_claude_agent_files(tmp_path):
    result = install_agent_integration(tmp_path, repo_name="demo")

    assert result["created"]
    assert (tmp_path / "AGENTS.md").exists()
    assert (tmp_path / "CLAUDE.md").exists()
    assert (tmp_path / ".codex" / "skills" / "csg" / "csg-exploring" / "SKILL.md").exists()
    assert (tmp_path / ".claude" / "skills" / "csg" / "csg-impact-analysis" / "SKILL.md").exists()
    assert (tmp_path / ".claude" / "settings.json").exists()
    assert (tmp_path / ".claude" / "hooks" / "csg-hook.py").exists()

    agents_text = (tmp_path / "AGENTS.md").read_text(encoding="utf-8")
    claude_text = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")

    assert "<!-- csg:start -->" in agents_text
    assert "csg_explore" in agents_text
    assert "csg_impact" in agents_text
    assert "csg_detect_changes" in claude_text

    settings = json.loads((tmp_path / ".claude" / "settings.json").read_text(encoding="utf-8"))
    assert "PreToolUse" in settings["hooks"]
    assert "PostToolUse" in settings["hooks"]


def test_generated_skill_frontmatter_is_not_indented(tmp_path):
    install_agent_integration(tmp_path, repo_name="demo")

    skill_text = (
        tmp_path / ".codex" / "skills" / "csg" / "csg-impact-analysis" / "SKILL.md"
    ).read_text(encoding="utf-8")

    assert skill_text.startswith("---\nname: csg-impact-analysis\n")
    assert "\n---\n\n# CSG Impact Analysis\n" in skill_text


def test_replaces_existing_marker_block_without_erasing_user_content(tmp_path):
    agents = tmp_path / "AGENTS.md"
    agents.write_text(
        "user rules\n\n<!-- csg:start -->\nold generated text\n<!-- csg:end -->\n",
        encoding="utf-8",
    )

    install_agent_integration(tmp_path, repo_name="demo")

    text = agents.read_text(encoding="utf-8")
    assert text.startswith("user rules")
    assert "old generated text" not in text
    assert text.count("<!-- csg:start -->") == 1
    assert "csg://repo/demo/context" in text


def test_setup_agents_cli_installs_in_requested_path(tmp_path):
    runner = CliRunner()

    result = runner.invoke(main, ["setup-agents", str(tmp_path), "--repo-name", "demo"])

    assert result.exit_code == 0
    assert (tmp_path / "AGENTS.md").exists()
    assert (tmp_path / ".claude" / "skills" / "csg" / "csg-guide" / "SKILL.md").exists()
    assert "Agent integration installed" in result.output


def test_merges_hook_settings_without_erasing_existing_config(tmp_path):
    claude_dir = tmp_path / ".claude"
    codex_dir = tmp_path / ".codex"
    claude_dir.mkdir()
    codex_dir.mkdir()
    (claude_dir / "settings.json").write_text(
        json.dumps({"permissions": {"allow": ["Bash(pytest*)"]}, "hooks": {"Stop": []}}),
        encoding="utf-8",
    )
    (codex_dir / "hooks.json").write_text(
        json.dumps({"version": 1, "hooks": {"Stop": [{"type": "command", "command": "echo done"}]}}),
        encoding="utf-8",
    )

    install_agent_integration(tmp_path, repo_name="demo")

    claude_settings = json.loads((claude_dir / "settings.json").read_text(encoding="utf-8"))
    codex_hooks = json.loads((codex_dir / "hooks.json").read_text(encoding="utf-8"))

    assert claude_settings["permissions"]["allow"] == ["Bash(pytest*)"]
    assert "Stop" in claude_settings["hooks"]
    assert "PreToolUse" in claude_settings["hooks"]
    assert codex_hooks["hooks"]["Stop"][0]["command"] == "echo done"
    assert "SessionStart" in codex_hooks["hooks"]


def test_setup_mcp_clients_runs_detected_agent_commands():
    calls: list[list[str]] = []

    def fake_which(name: str) -> str | None:
        return f"/bin/{name}" if name in {"claude", "codex"} else None

    def fake_runner(cmd, **_kwargs):
        calls.append(cmd)

        class Result:
            returncode = 0
            stdout = ""
            stderr = ""

        return Result()

    result = setup_mcp_clients(which=fake_which, runner=fake_runner)

    assert calls == [
        ["/bin/claude", "mcp", "add", "--transport", "stdio", "--scope", "user", "csg", "--", "csg", "mcp"],
        ["/bin/codex", "mcp", "add", "csg", "--", "csg", "mcp"],
    ]
    assert result["claude"]["status"] == "configured"
    assert result["codex"]["status"] == "configured"


def test_setup_mcp_clients_reports_launch_failures_without_crashing():
    def fake_which(name: str) -> str | None:
        return f"/bin/{name}" if name == "claude" else None

    def fake_runner(_cmd, **_kwargs):
        raise FileNotFoundError("not found")

    result = setup_mcp_clients(which=fake_which, runner=fake_runner)

    assert result["claude"]["status"] == "failed"
    assert "not found" in result["claude"]["message"]
    assert result["codex"]["status"] == "missing"


def test_setup_cli_installs_local_files_and_attempts_mcp_registration(tmp_path, monkeypatch):
    import csg.presentation.cli.entry as entry

    def fake_setup_mcp_clients():
        return {"claude": {"status": "missing"}, "codex": {"status": "missing"}}

    monkeypatch.setattr(entry, "setup_mcp_clients", fake_setup_mcp_clients)
    runner = CliRunner()

    result = runner.invoke(main, ["setup", str(tmp_path), "--repo-name", "demo"])

    assert result.exit_code == 0
    assert (tmp_path / "AGENTS.md").exists()
    assert (tmp_path / ".codex" / "skills" / "csg" / "csg-guide" / "SKILL.md").exists()
    assert "Agent files installed" in result.output
    assert "claude: missing" in result.output
