"""Tests for canonical domain type definitions."""

import pytest

from csg.domain.codebase.value_objects import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    NodeProperties,
    RelationshipType,
)
from csg.domain.analysis.result import PipelineResult


@pytest.mark.unit
class TestNodeLabel:
    def test_member_count(self):
        assert len(NodeLabel) >= 30  # currently 38, just ensure stability

    def test_common_labels_exist(self):
        for label in ["File", "Class", "Function", "Method", "Community", "Process"]:
            assert label in [nl.value for nl in NodeLabel]


@pytest.mark.unit
class TestRelationshipType:
    def test_member_count(self):
        assert len(RelationshipType) == 18

    def test_key_types_exist(self):
        for rt in ["CALLS", "CONTAINS", "INHERITS", "IMPORTS", "MEMBER_OF"]:
            assert rt in [r.value for r in RelationshipType]


@pytest.mark.unit
class TestNodeProperties:
    def test_defaults(self):
        props = NodeProperties()
        assert props.name == ""
        assert props.file_path == ""
        assert props.start_line is None
        assert props.is_exported is None
        assert props.content is None

    def test_get_snake_case(self):
        props = NodeProperties(file_path="src/main.py", name="main")
        assert props.get("file_path") == "src/main.py"
        assert props.get("name") == "main"

    def test_get_camel_case_alias(self):
        props = NodeProperties(file_path="src/main.py", start_line=10)
        assert props.get("filePath") == "src/main.py"
        assert props.get("startLine") == 10

    def test_get_unknown_key_default(self):
        props = NodeProperties()
        assert props.get("nonexistent") is None
        assert props.get("nonexistent", "fallback") == "fallback"

    def test_get_from_extra(self):
        props = NodeProperties(_extra={"lineCount": 42})
        assert props.get("lineCount") == 42

    def test_get_none_field_returns_default(self):
        props = NodeProperties(start_line=None)
        assert props.get("start_line", 0) == 0


@pytest.mark.unit
class TestGraphNode:
    def test_creation(self):
        node = GraphNode(
            id="Function:src/main.py:main",
            label=NodeLabel.FUNCTION,
            properties=NodeProperties(name="main"),
        )
        assert node.id == "Function:src/main.py:main"
        assert node.label == NodeLabel.FUNCTION
        assert node.properties.name == "main"


@pytest.mark.unit
class TestGraphRelationship:
    def test_defaults(self):
        rel = GraphRelationship(
            id="r1", source_id="a", target_id="b",
            type=RelationshipType.CALLS,
        )
        assert rel.confidence == 1.0
        assert rel.reason == ""
        assert rel.step is None
        assert rel.in_cycle is None
        assert rel.review_label is None


@pytest.mark.unit
class TestPipelineResult:
    def test_fields(self):
        result = PipelineResult(
            node_count=100, relationship_count=200, file_count=10,
            community_count=3, process_count=5, duration_ms=1234,
        )
        assert result.embedding_count == 0  # default
        assert result.node_count == 100
