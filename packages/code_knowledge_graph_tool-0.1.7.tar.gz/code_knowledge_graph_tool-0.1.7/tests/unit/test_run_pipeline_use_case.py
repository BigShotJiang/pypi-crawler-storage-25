from csg.application.use_cases.analysis import run_pipeline


def test_run_incremental_pipeline_sync_delegates_to_pipeline_module(monkeypatch) -> None:
    calls: list[tuple[str, object]] = []

    def fake_runner(repo_path: str) -> dict:
        calls.append(("incremental", repo_path))
        return {"repo_path": repo_path}

    assert run_pipeline.run_incremental_pipeline_sync("repo-path", runner=fake_runner) == {"repo_path": "repo-path"}
    assert calls == [("incremental", "repo-path")]


def test_run_analysis_pipeline_sync_delegates_to_injected_runner(monkeypatch) -> None:
    cancel_event = object()
    calls: list[tuple[str, object]] = []

    def fake_runner(repo_path: str, cancel_event=None) -> dict:
        calls.append((repo_path, cancel_event))
        return {"repo_path": repo_path}

    assert run_pipeline.run_analysis_pipeline_sync(
        "repo-path",
        runner=fake_runner,
        cancel_event=cancel_event,
    ) == {"repo_path": "repo-path"}
    assert calls == [("repo-path", cancel_event)]
