from pathlib import Path

from csg.infrastructure.analysis.internal.analysis import pipeline


def test_lbug_backup_and_cleanup_support_file_database(tmp_path, monkeypatch) -> None:
    repo_path = "repo"
    storage = tmp_path / "storage"
    storage.mkdir()
    lbug = storage / "lbug"
    lbug.write_bytes(b"db-file")

    monkeypatch.setattr(pipeline, "get_storage_path", lambda _: storage)

    backup_path = pipeline._backup_lbug(repo_path)

    assert backup_path == str(storage / "lbug_backup")
    assert (storage / "lbug_backup").read_bytes() == b"db-file"

    pipeline._cleanup_backup(repo_path)

    assert not (storage / "lbug_backup").exists()


def test_lbug_restore_supports_file_database(tmp_path, monkeypatch) -> None:
    repo_path = "repo"
    storage = tmp_path / "storage"
    storage.mkdir()
    lbug = storage / "lbug"
    backup = storage / "lbug_backup"
    lbug.write_bytes(b"broken-db")
    backup.write_bytes(b"previous-db")

    monkeypatch.setattr(pipeline, "get_storage_path", lambda _: storage)

    pipeline._restore_lbug(repo_path)

    assert lbug.read_bytes() == b"previous-db"
    assert not backup.exists()


def test_lbug_backup_still_supports_directory_database(tmp_path, monkeypatch) -> None:
    repo_path = "repo"
    storage = tmp_path / "storage"
    storage.mkdir()
    lbug = storage / "lbug"
    lbug.mkdir()
    (lbug / "data").write_text("db-dir", encoding="utf-8")

    monkeypatch.setattr(pipeline, "get_storage_path", lambda _: storage)

    backup_path = pipeline._backup_lbug(repo_path)

    assert backup_path == str(storage / "lbug_backup")
    assert (storage / "lbug_backup" / "data").read_text(encoding="utf-8") == "db-dir"
