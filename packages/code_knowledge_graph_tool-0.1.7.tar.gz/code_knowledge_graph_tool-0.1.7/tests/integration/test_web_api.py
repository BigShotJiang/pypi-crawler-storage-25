"""Tests for csg/web/app.py baseline endpoints."""

import uuid

import pytest


@pytest.mark.integration
class TestWebAPI:
    @pytest.fixture
    def client(self):
        """Create an authenticated test client for the FastAPI app."""
        from starlette.testclient import TestClient
        import csg.presentation.web.app as web_app
        from csg.bootstrap import build_container

        container = build_container()
        web_app.app.state.container = container
        app = web_app.app
        client = TestClient(app, raise_server_exceptions=False)
        suffix = uuid.uuid4().hex[:8]
        resp = client.post(
            "/api/auth/register",
            json={
                "username": f"webuser_{suffix}",
                "email": f"webuser_{suffix}@example.com",
                "password": "password123",
            },
        )
        assert resp.status_code == 201
        return client

    def test_root_returns_html(self, client):
        resp = client.get("/")
        assert resp.status_code == 200

    def test_api_repos_endpoint(self, client):
        resp = client.get("/api/repos")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
