﻿"""Baseline integration tests for observable MCP factory behavior."""

from __future__ import annotations

from contextlib import contextmanager
import importlib
import sys
import types

import pytest


@pytest.mark.integration
class TestMCPBaseline:
    def test_create_mcp_server_registers_current_public_surface_with_fake_fastmcp(
        self,
        monkeypatch,
    ) -> None:
        class FakeFastMCP:
            def __init__(self, name: str, instructions: str) -> None:
                self.name = name
                self.instructions = instructions
                self.tool_names: list[str] = []
                self.resource_names: list[str] = []
                self.prompt_names: list[str] = []
                self.tools: dict[str, object] = {}
                self.resources: dict[str, object] = {}
                self.prompts: dict[str, object] = {}

            def tool(self, *, name: str, description: str):
                def decorator(func):
                    self.tool_names.append(name)
                    self.tools[name] = func
                    return func

                return decorator

            def resource(self, uri: str, *, name: str, description: str):
                def decorator(func):
                    self.resource_names.append(name)
                    self.resources[name] = func
                    return func

                return decorator

            def prompt(self, *, name: str, description: str):
                def decorator(func):
                    self.prompt_names.append(name)
                    self.prompts[name] = func
                    return func

                return decorator

        fake_mcp = types.ModuleType("mcp")
        fake_server = types.ModuleType("mcp.server")
        fake_fastmcp = types.ModuleType("mcp.server.fastmcp")
        fake_pydantic = types.ModuleType("pydantic")
        fake_lbug_adapter = types.ModuleType("csg.infrastructure.graph.lbug_adapter")
        fake_backend_module = types.ModuleType("presentation.mcp.backend")
        fake_fastmcp.FastMCP = FakeFastMCP
        fake_pydantic.Field = lambda default=..., **kwargs: default
        fake_lbug_adapter.LadybugAdapter = type("LadybugAdapter", (), {})
        fake_backend_module.Backend = type(
            "Backend",
            (),
            {
                "analyze": staticmethod(lambda path, repo="": {"status": "ok", "path": path, "repo": repo}),
            },
        )
        fake_mcp.server = fake_server
        fake_server.fastmcp = fake_fastmcp

        monkeypatch.setitem(sys.modules, "mcp", fake_mcp)
        monkeypatch.setitem(sys.modules, "mcp.server", fake_server)
        monkeypatch.setitem(sys.modules, "mcp.server.fastmcp", fake_fastmcp)
        monkeypatch.setitem(sys.modules, "pydantic", fake_pydantic)
        monkeypatch.setitem(sys.modules, "csg.infrastructure.graph.lbug_adapter", fake_lbug_adapter)
        monkeypatch.setitem(
            sys.modules, "presentation.mcp.backend", fake_backend_module
        )

        try:
            import csg.presentation.mcp.factory as factory

            factory = importlib.reload(factory)

            class DummyBackend:
                @contextmanager
                def _scoped_repo(self, repo):
                    yield

                def explore_auto(self, *, query: str, scope: str, layer: str) -> dict:
                    return {
                        "_meta": {"depth_reached": "topology"},
                        "query": query,
                        "communities": [
                            {"name": "core", "topMembers": ["demo_symbol", "helper_symbol"]},
                        ],
                    }

                def list_repos(self) -> dict:
                    return {"repos": [{"name": "demo-repo"}]}

            server = factory.create_mcp_server(DummyBackend())

            assert server.name == "csg"
            assert "code intelligence server" in server.instructions.lower()
            assert set(server.tool_names) == {
                "csg_explore",
                "csg_context",
                "csg_impact",
                "csg_detect_changes",
                "csg_rename",
                "csg_list_repos",
                "csg_analyze",
                "csg_delete",
                "csg_srs",
                "csg_analyze_docs",
            }
            assert set(server.resource_names) == {
                "Repo Overview",
                "Repo Modules",
                "Repo Processes",
                "Process Trace",
                "Graph Schema",
            }
            assert set(server.prompt_names) == {
                "explore_codebase",
                "pre_commit_review",
                "architecture_map",
            }

            list_repos_result = server.tools["csg_list_repos"]()
            assert '"repos"' in list_repos_result
            assert '"demo-repo"' in list_repos_result

            explore_result = server.tools["csg_explore"](
                query="find demo",
                scope="community:core",
                layer="relevance",
                repo="demo-repo",
            )
            assert '"query": "find demo"' in explore_result
            assert '"communities"' in explore_result
            assert '"name": "core"' in explore_result
            assert "**Next:**" in explore_result
            assert "csg_explore(layer='context', scope='community:<name>')" in explore_result
            assert "Top communities: core." in explore_result

            resource_result = server.resources["Graph Schema"]("demo-repo")
            assert isinstance(resource_result, str)
            assert resource_result

            prompt_result = server.prompts["explore_codebase"]("How does demo work?")
            assert isinstance(prompt_result, str)
            assert "How does demo work?" in prompt_result
        finally:
            sys.modules.pop("presentation.mcp.factory", None)
            sys.modules.pop("pydantic", None)
            sys.modules.pop("csg.infrastructure.graph.lbug_adapter", None)
            sys.modules.pop("presentation.mcp.backend", None)

