"""Tests for csg/graph/lbug_adapter.py - KuzuDB adapter."""

import pytest

from csg.domain.codebase.value_objects import GraphRelationship, RelationshipType
from csg.infrastructure.graph.kuzu_pool import KuzuPool


@pytest.fixture(autouse=True)
def _reset_pool():
    yield
    KuzuPool.reset()


@pytest.mark.integration
@pytest.mark.requires_db
class TestLadybugAdapter:
    def test_schema_creation(self, kuzu_adapter):
        """Verify node tables exist after schema creation."""
        results = kuzu_adapter.execute_query("MATCH (n:File) RETURN count(*) AS cnt")
        assert results[0]["cnt"] == 0

    def test_load_graph(self, kuzu_adapter, sample_knowledge_graph, workspace_temp_dir):
        """Load graph and verify counts."""
        csv_dir = str(workspace_temp_dir / "csv")
        stats = kuzu_adapter.load_graph(sample_knowledge_graph, csv_dir)
        assert stats["node_count"] > 0

    def test_execute_query_after_load(self, kuzu_adapter, sample_knowledge_graph, workspace_temp_dir):
        """After load, query returns results."""
        csv_dir = str(workspace_temp_dir / "csv")
        kuzu_adapter.load_graph(sample_knowledge_graph, csv_dir)
        results = kuzu_adapter.execute_query(
            "MATCH (n:Function) RETURN n.name AS name"
        )
        names = [r["name"] for r in results]
        assert "main" in names

    def test_match_by_name(self, kuzu_adapter, sample_knowledge_graph, workspace_temp_dir):
        """match_by_name finds the correct symbol."""
        csv_dir = str(workspace_temp_dir / "csv")
        kuzu_adapter.load_graph(sample_knowledge_graph, csv_dir)
        results = kuzu_adapter.match_by_name("main")
        assert len(results) > 0
        assert any(r.get("name") == "main" for r in results)

    def test_load_graph_persists_relationship_review_label(
        self,
        kuzu_adapter,
        sample_knowledge_graph,
        workspace_temp_dir,
    ):
        """Relationship review labels are persisted on CodeRelation edges."""
        sample_knowledge_graph.add_relationship(GraphRelationship(
            id="rel-ambiguous",
            source_id="Function:src/main.py:main",
            target_id="Method:src/app.py:run",
            type=RelationshipType.CALLS,
            reason="global-ambiguous",
            review_label="AMBIGUOUS",
        ))

        csv_dir = str(workspace_temp_dir / "csv")
        kuzu_adapter.load_graph(sample_knowledge_graph, csv_dir)

        results = kuzu_adapter.execute_query(
            "MATCH ()-[r:CodeRelation]->() "
            "WHERE r.id = 'rel-ambiguous' "
            "RETURN r.reviewLabel AS reviewLabel"
        )
        assert results == [{"reviewLabel": "AMBIGUOUS"}]

