﻿from __future__ import annotations

import io
import importlib
import json
import shutil
import sys
import types
from pathlib import Path
import zipfile

import pytest


def _parse_sse_events(body: str) -> list[tuple[str, str]]:
    events: list[tuple[str, str]] = []
    for chunk in body.strip().split("\n\n"):
        event_name = ""
        data_lines: list[str] = []
        for line in chunk.splitlines():
            if line.startswith("event: "):
                event_name = line.removeprefix("event: ")
            elif line.startswith("data: "):
                data_lines.append(line.removeprefix("data: "))
        if event_name:
            events.append((event_name, "\n".join(data_lines)))
    return events


@pytest.mark.integration
def test_end_to_end_analysis_flow_with_fake_pipeline(monkeypatch, workspace_temp_dir: Path) -> None:
    pytest.importorskip("fastapi")
    pytest.importorskip("starlette.testclient")

    workspace = workspace_temp_dir / "phase12"
    workspace.mkdir(parents=True, exist_ok=True)
    try:
        monkeypatch.setenv("CSG_DATA_DIR", str(workspace / "data"))
        fake_dotenv = types.ModuleType("dotenv")
        fake_dotenv.load_dotenv = lambda *args, **kwargs: None
        fake_dotenv.dotenv_values = lambda *args, **kwargs: {}
        monkeypatch.setitem(sys.modules, "dotenv", fake_dotenv)

        import csg.infrastructure.config.paths as config_paths
        import csg.infrastructure.repository.internal.repo_registry_runtime as repo_manager
        import csg.presentation.web.app as web_app
        from csg.bootstrap import build_container

        importlib.reload(config_paths)
        importlib.reload(repo_manager)
        web_app = importlib.reload(web_app)

        # Create real app with real container initially
        real_container = build_container()
        web_app.app.state.container = real_container
        app = web_app.app
        web_app.app = app  # expose for test manipulations

        called: dict[str, object] = {}

        class FakeRepositoryRegistry:
            def get_storage_path_for_repo(self, repo_path: str):
                return web_app.Path(web_app.os.environ["CSG_DATA_DIR"]) / "repos" / "fake-storage"

        class FakeContainer:
            def get_repository_registry(self) -> FakeRepositoryRegistry:
                return FakeRepositoryRegistry()

            def run_analysis_pipeline_sync(self, repo_path: str, *, cancel_event=None) -> dict:
                return {"repo_path": repo_path, "knowledge_graph": None}

        fake_domain_errors = types.ModuleType("csg.domain.errors")
        fake_domain_errors.PipelineCancelled = type("PipelineCancelled", (Exception,), {})

        monkeypatch.setitem(sys.modules, "csg.domain.errors", fake_domain_errors)
        monkeypatch.setattr(web_app.app.state, "container", FakeContainer())
        monkeypatch.setattr(
            web_app,
            "run_analysis_pipeline_sync",
            lambda repo_path, *, runner, cancel_event=None: (
                called.update({"repo_path": repo_path, "cancel_event": cancel_event})
                or {"repo_path": repo_path, "knowledge_graph": None}
            ),
        )
        monkeypatch.setattr(
            web_app,
            "serialize_results",
            lambda final_state: {
                "summary": {"files": 1, "communities": 0, "processes": 0},
                "graph": {"nodes": [], "links": []},
            },
        )
        monkeypatch.setattr(web_app, "save_graph_json", lambda repo_path, results: None)
        runtime_tmp = web_app.Path(web_app.os.environ["CSG_DATA_DIR"]) / "runtime-test"
        runtime_tmp.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(web_app, "_make_runtime_temp_dir", lambda prefix: str(runtime_tmp))

        from starlette.testclient import TestClient

        client = TestClient(web_app.app, raise_server_exceptions=False)

        archive = io.BytesIO()
        with zipfile.ZipFile(archive, "w") as zf:
            zf.writestr("tiny-repo/README.md", "hello\n")
        archive.seek(0)

        response = client.post(
            "/api/analyze",
            files={"file": ("tiny-repo.zip", archive.getvalue(), "application/zip")},
        )

        assert response.status_code == 200

        events = _parse_sse_events(response.text)
        event_names = [name for name, _ in events]

        assert event_names.count("result") == 1
        assert event_names.count("done") == 1
        assert event_names.index("result") < event_names.index("done")

        result_payload = json.loads(next(data for name, data in events if name == "result"))
        assert result_payload["summary"]["files"] == 1
        assert "repo_id" in result_payload
        assert called["cancel_event"] is not None
        assert str(called["repo_path"]).endswith("tiny-repo")
    finally:
        shutil.rmtree(workspace, ignore_errors=True)
