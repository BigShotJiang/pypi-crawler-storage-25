"""Tests for csg/graph/kuzu_pool.py - KuzuDB singleton pool."""

import pytest

from csg.infrastructure.graph.kuzu_pool import KuzuPool


@pytest.fixture(autouse=True)
def _reset_pool():
    """Reset singleton after each test to avoid cross-test contamination."""
    yield
    KuzuPool.reset()


@pytest.mark.integration
@pytest.mark.requires_db
class TestKuzuPool:
    def test_singleton(self):
        a = KuzuPool.get()
        b = KuzuPool.get()
        assert a is b

    def test_get_database(self, temp_db_path):
        pool = KuzuPool.get()
        db = pool.get_database(str(temp_db_path))
        assert db is not None

    def test_get_database_idempotent(self, temp_db_path):
        pool = KuzuPool.get()
        db1 = pool.get_database(str(temp_db_path))
        db2 = pool.get_database(str(temp_db_path))
        assert db1 is db2

    def test_get_connection(self, temp_db_path):
        pool = KuzuPool.get()
        conn = pool.get_connection(str(temp_db_path))
        assert conn is not None

    def test_close_database(self, temp_db_path):
        pool = KuzuPool.get()
        pool.get_database(str(temp_db_path))
        pool.close(str(temp_db_path))
        # After close, should create new instance
        db2 = pool.get_database(str(temp_db_path))
        assert db2 is not None

    def test_close_all(self, temp_db_path):
        pool = KuzuPool.get()
        pool.get_database(str(temp_db_path))
        pool.close_all()

    def test_reset(self):
        pool1 = KuzuPool.get()
        KuzuPool.reset()
        pool2 = KuzuPool.get()
        assert pool1 is not pool2

