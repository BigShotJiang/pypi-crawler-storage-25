﻿"""Baseline integration tests for public web API behavior."""

from __future__ import annotations

import io
import importlib
import json
import sys
from pathlib import Path
import types
import uuid
import zipfile

import pytest


def _repo_stats(
    *,
    files: int,
    nodes: int,
    edges: int,
    communities: int,
    processes: int,
    embeddings: int = 0,
) -> dict[str, int]:
    return {
        "files": files,
        "nodes": nodes,
        "edges": edges,
        "communities": communities,
        "processes": processes,
        "embeddings": embeddings,
    }


def _register_repo(repo_manager, repo_path: Path, *, indexed_at: str, last_commit: str, stats: dict[str, int]) -> None:
    repo_path.mkdir()
    meta = repo_manager.RepoMeta(
        repo_path=str(repo_path),
        last_commit=last_commit,
        indexed_at=indexed_at,
        stats=stats,
    )
    repo_manager.save_meta(repo_path, meta)
    repo_manager.register_repo(repo_path, meta)


def _get_repo_from_api(client, name: str) -> dict:
    repos = client.get("/api/repos").json()
    return next(repo for repo in repos if repo["name"] == name)


def _parse_sse_events(body: str) -> list[tuple[str, str]]:
    events: list[tuple[str, str]] = []
    for chunk in body.strip().split("\n\n"):
        event_name = ""
        data_lines: list[str] = []
        for line in chunk.splitlines():
            if line.startswith("event: "):
                event_name = line.removeprefix("event: ")
            elif line.startswith("data: "):
                data_lines.append(line.removeprefix("data: "))
        if event_name:
            events.append((event_name, "\n".join(data_lines)))
    return events


def _authenticate_client(client) -> None:
    suffix = uuid.uuid4().hex[:8]
    resp = client.post(
        "/api/auth/register",
        json={
            "username": f"user_{suffix}",
            "email": f"user_{suffix}@example.com",
            "password": "password123",
        },
    )
    assert resp.status_code == 201, resp.text


@pytest.mark.integration
class TestAPIBaseline:
    @pytest.fixture
    def temp_root(self, workspace_temp_dir: Path):
        yield workspace_temp_dir

    @pytest.fixture
    def app_module(self, temp_root: Path, monkeypatch):
        monkeypatch.setenv("CSG_DATA_DIR", str(temp_root / "data"))

        import csg.infrastructure.config.paths as config_paths
        import csg.infrastructure.repository.internal.repo_registry_runtime as repo_manager
        import csg.presentation.web.app as web_app
        from csg.bootstrap import build_container

        importlib.reload(config_paths)
        importlib.reload(repo_manager)
        importlib.reload(web_app)

        container = build_container()
        web_app.app.state.container = container

        # Return the module itself; it has .app, .Path, .os, etc.
        return web_app

    @pytest.fixture
    def client(self, app_module):
        from starlette.testclient import TestClient

        client = TestClient(app_module.app, raise_server_exceptions=True)
        _authenticate_client(client)
        return client

    def test_health_endpoint_reports_ok(self, client) -> None:
        resp = client.get("/api/health")

        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}

    def test_repos_and_stats_reflect_registered_repositories(self, app_module, client, temp_root: Path) -> None:
        repo_manager = importlib.import_module("csg.infrastructure.repository.internal.repo_registry_runtime")

        repo_one = temp_root / "checkout-alpha"
        repo_two = temp_root / "checkout-beta"

        _register_repo(
            repo_manager,
            repo_one,
            indexed_at="2026-04-01T10:00:00+00:00",
            last_commit="abc1234",
            stats=_repo_stats(files=3, nodes=10, edges=20, communities=2, processes=1, embeddings=4),
        )
        _register_repo(
            repo_manager,
            repo_two,
            indexed_at="2026-04-02T10:00:00+00:00",
            last_commit="def5678",
            stats=_repo_stats(files=5, nodes=7, edges=11, communities=1, processes=3, embeddings=2),
        )

        repos_resp = client.get("/api/repos")
        stats_resp = client.get("/api/stats")

        assert repos_resp.status_code == 200
        assert stats_resp.status_code == 200

        repos = repos_resp.json()
        stats = stats_resp.json()

        assert len(repos) == 2
        repos_by_name = {repo["name"]: repo for repo in repos}
        assert set(repos_by_name) == {"checkout-alpha", "checkout-beta"}
        assert isinstance(repos_by_name["checkout-alpha"]["id"], str)
        assert repos_by_name["checkout-alpha"]["id"]
        assert isinstance(repos_by_name["checkout-beta"]["id"], str)
        assert repos_by_name["checkout-beta"]["id"]
        assert repos_by_name["checkout-alpha"]["path"] == str(repo_one.resolve())
        assert repos_by_name["checkout-alpha"]["indexed_at"] == "2026-04-01T10:00:00+00:00"
        assert repos_by_name["checkout-alpha"]["last_commit"] == "abc1234"
        assert repos_by_name["checkout-alpha"]["stats"] == _repo_stats(
            files=3,
            nodes=10,
            edges=20,
            communities=2,
            processes=1,
            embeddings=4,
        )
        assert repos_by_name["checkout-beta"]["path"] == str(repo_two.resolve())
        assert repos_by_name["checkout-beta"]["indexed_at"] == "2026-04-02T10:00:00+00:00"
        assert repos_by_name["checkout-beta"]["last_commit"] == "def5678"
        assert repos_by_name["checkout-beta"]["stats"] == _repo_stats(
            files=5,
            nodes=7,
            edges=11,
            communities=1,
            processes=3,
            embeddings=2,
        )
        assert stats["total_repos"] == 2
        assert stats["total_nodes"] == 17
        assert stats["total_relationships"] == 31
        assert stats["total_communities"] == 3
        assert stats["total_processes"] == 4
        assert stats["total_files"] == 8
        assert stats["total_embeddings"] == 6
        assert len(stats["repos"]) == 2
        stats_by_name = {repo["name"]: repo for repo in stats["repos"]}
        assert set(stats_by_name) == {"checkout-alpha", "checkout-beta"}
        assert isinstance(stats_by_name["checkout-alpha"]["id"], str)
        assert stats_by_name["checkout-alpha"]["id"]
        assert stats_by_name["checkout-alpha"]["indexed_at"] == "2026-04-01T10:00:00+00:00"
        assert stats_by_name["checkout-alpha"]["files"] == 3
        assert stats_by_name["checkout-alpha"]["nodes"] == 10
        assert stats_by_name["checkout-alpha"]["edges"] == 20
        assert stats_by_name["checkout-alpha"]["communities"] == 2
        assert stats_by_name["checkout-alpha"]["processes"] == 1
        assert stats_by_name["checkout-alpha"]["embeddings"] == 4
        assert isinstance(stats_by_name["checkout-beta"]["id"], str)
        assert stats_by_name["checkout-beta"]["id"]
        assert stats_by_name["checkout-beta"]["indexed_at"] == "2026-04-02T10:00:00+00:00"
        assert stats_by_name["checkout-beta"]["files"] == 5
        assert stats_by_name["checkout-beta"]["nodes"] == 7
        assert stats_by_name["checkout-beta"]["edges"] == 11
        assert stats_by_name["checkout-beta"]["communities"] == 1
        assert stats_by_name["checkout-beta"]["processes"] == 3
        assert stats_by_name["checkout-beta"]["embeddings"] == 2

    def test_analyze_endpoint_streams_result_and_done_events(self, app_module, client, monkeypatch) -> None:
        current_container = app_module.app.state.container

        class FakeRepositoryRegistry:
            def get_storage_path_for_repo(self, repo_path: str):
                return app_module.Path(app_module.os.environ["CSG_DATA_DIR"]) / "repos" / "fake-storage"

        class FakeContainer:
            def get_repository_registry(self) -> FakeRepositoryRegistry:
                return FakeRepositoryRegistry()

            def run_analysis_pipeline_sync(self, repo_path: str, *, cancel_event=None) -> dict:
                return {"repo_path": repo_path, "knowledge_graph": None}

            def get_user_store(self):
                return current_container.get_user_store()

            def get_session_store(self):
                return current_container.get_session_store()

            def get_token_service(self):
                return current_container.get_token_service()

        fake_domain_errors = types.ModuleType("csg.domain.errors")
        fake_domain_errors.PipelineCancelled = type("PipelineCancelled", (Exception,), {})

        monkeypatch.setitem(sys.modules, "csg.domain.errors", fake_domain_errors)
        monkeypatch.setattr(app_module.app.state, "container", FakeContainer())
        monkeypatch.setattr(
            app_module,
            "run_analysis_pipeline_sync",
            lambda repo_path, *, runner, cancel_event=None: {"repo_path": repo_path, "knowledge_graph": None},
        )
        monkeypatch.setattr(
            app_module,
            "serialize_results",
            lambda final_state: {
                "summary": {"files": 1, "communities": 0, "processes": 0},
                "graph": {"nodes": [], "links": []},
            },
        )
        monkeypatch.setattr(app_module, "save_graph_json", lambda repo_path, results: None)
        runtime_tmp = app_module.Path(app_module.os.environ["CSG_DATA_DIR"]) / "runtime-test"
        runtime_tmp.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(app_module, "_make_runtime_temp_dir", lambda prefix: str(runtime_tmp))

        archive = io.BytesIO()
        with zipfile.ZipFile(archive, "w") as zf:
            zf.writestr("tiny-repo/README.md", "hello\n")
        archive.seek(0)

        resp = client.post(
            "/api/analyze",
            files={"file": ("tiny-repo.zip", archive.getvalue(), "application/zip")},
        )

        assert resp.status_code == 200
        events = _parse_sse_events(resp.text)
        event_names = [name for name, _ in events]

        assert event_names.count("result") == 1
        assert event_names.count("done") == 1
        assert event_names.index("result") < event_names.index("done")

        result_payload = json.loads(next(data for name, data in events if name == "result"))
        assert "summary" in result_payload
        assert "graph" in result_payload
        assert result_payload["summary"]["files"] == 1

    def test_analyze_git_endpoint_reaches_shared_pipeline_sse_path(
        self,
        app_module,
        client,
        monkeypatch,
    ) -> None:
        current_container = app_module.app.state.container

        class FakeRepositoryRegistry:
            def get_storage_path_for_repo(self, repo_path: str):
                return app_module.Path(app_module.os.environ["CSG_DATA_DIR"]) / "repos" / "git-storage"

        class FakeContainer:
            def get_repository_registry(self) -> FakeRepositoryRegistry:
                return FakeRepositoryRegistry()

            def run_analysis_pipeline_sync(self, repo_path: str, *, cancel_event=None) -> dict:
                return {"repo_path": repo_path, "knowledge_graph": None}

            def get_user_store(self):
                return current_container.get_user_store()

            def get_session_store(self):
                return current_container.get_session_store()

            def get_token_service(self):
                return current_container.get_token_service()

        fake_domain_errors = types.ModuleType("csg.domain.errors")
        fake_domain_errors.PipelineCancelled = type("PipelineCancelled", (Exception,), {})

        def fake_subprocess_run(cmd, capture_output=True, text=True, timeout=0):
            if cmd[:3] == ["git", "clone", "--depth"]:
                clone_target = app_module.Path(cmd[-1])
                clone_target.mkdir(parents=True, exist_ok=True)
                (clone_target / "README.md").write_text("hello\n", encoding="utf-8")
                return types.SimpleNamespace(returncode=0, stdout="", stderr="")
            if cmd[:4] == ["git", "-C", str(app_module.Path(cmd[2])), "rev-parse"]:
                return types.SimpleNamespace(returncode=0, stdout="abc123\n", stderr="")
            return types.SimpleNamespace(returncode=0, stdout="", stderr="")

        monkeypatch.setitem(sys.modules, "csg.domain.errors", fake_domain_errors)
        monkeypatch.setattr(app_module.app.state, "container", FakeContainer())
        monkeypatch.setattr(app_module.subprocess, "run", fake_subprocess_run)
        monkeypatch.setattr(
            app_module,
            "run_analysis_pipeline_sync",
            lambda repo_path, *, runner, cancel_event=None: {"repo_path": repo_path, "knowledge_graph": None},
        )
        monkeypatch.setattr(
            app_module,
            "serialize_results",
            lambda final_state: {
                "summary": {"files": 1, "communities": 0, "processes": 0},
                "graph": {"nodes": [], "edges": []},
            },
        )
        monkeypatch.setattr(app_module, "save_graph_json", lambda repo_path, results: None)
        monkeypatch.setattr(app_module, "register_repository_analysis", lambda **kwargs: None)
        runtime_tmp = app_module.Path(app_module.os.environ["CSG_DATA_DIR"]) / "runtime-git-test"
        runtime_tmp.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(app_module, "_make_runtime_temp_dir", lambda prefix: str(runtime_tmp))

        resp = client.post("/api/analyze-git", json={"url": "https://example.com/demo.git", "branch": "main"})

        assert resp.status_code == 200
        events = _parse_sse_events(resp.text)
        event_names = [name for name, _ in events]

        assert event_names.count("result") == 1
        assert event_names.count("done") == 1
        assert event_names.index("result") < event_names.index("done")

    def test_repo_graph_endpoint_returns_cached_graph_payload(self, client, temp_root: Path) -> None:
        repo_manager = importlib.import_module("csg.infrastructure.repository.internal.repo_registry_runtime")

        repo_path = temp_root / "cached-graph-repo"
        _register_repo(
            repo_manager,
            repo_path,
            indexed_at="2026-04-03T10:00:00+00:00",
            last_commit="graph123",
            stats=_repo_stats(files=1, nodes=2, edges=1, communities=1, processes=1),
        )

        cached_payload = {
            "summary": {"files": 1, "nodes": 2},
            "graph": {
                "nodes": [{"id": "n1", "label": "File"}],
                "edges": [],
            },
        }
        storage = repo_manager.get_storage_path(repo_path)
        storage.mkdir(parents=True, exist_ok=True)
        (storage / "graph.json").write_text(json.dumps(cached_payload), encoding="utf-8")

        repo = _get_repo_from_api(client, "cached-graph-repo")
        resp = client.get(f"/api/repos/{repo['id']}/graph")

        assert resp.status_code == 200
        assert resp.json() == {
            **cached_payload,
            "repo_id": repo["id"],
        }

    def test_repo_graph_endpoint_rebuilds_uncached_existing_repository(
        self,
        app_module,
        client,
        temp_root: Path,
        monkeypatch,
    ) -> None:
        repo_manager = importlib.import_module("csg.infrastructure.repository.internal.repo_registry_runtime")

        repo_path = temp_root / "uncached-graph-repo"
        _register_repo(
            repo_manager,
            repo_path,
            indexed_at="2026-04-06T10:00:00+00:00",
            last_commit="uncached123",
            stats=_repo_stats(files=1, nodes=1, edges=0, communities=0, processes=0),
        )

        class FakeContainer:
            def get_repository_registry(self):
                return app_module.app.state.container.get_repository_registry()

            def run_analysis_pipeline_sync(self, repo_path: str, *, cancel_event=None) -> dict:
                return {"repo_path": repo_path}

            def get_user_store(self):
                return current_container.get_user_store()

            def get_session_store(self):
                return current_container.get_session_store()

            def get_token_service(self):
                return current_container.get_token_service()

        async def fake_rebuild_repository_graph(repo_path_arg: str, *, runner, serializer, saver):
            assert repo_path_arg == str(repo_path.resolve())
            assert callable(runner)
            assert callable(serializer)
            assert callable(saver)
            return {
                "summary": {"files": 1, "nodes": 1},
                "graph": {"nodes": [{"id": "n1", "label": "File"}], "edges": []},
            }

        current_container = app_module.app.state.container
        FakeContainer.get_repository_registry = lambda self: current_container.get_repository_registry()
        monkeypatch.setattr(app_module.app.state, "container", FakeContainer())
        monkeypatch.setattr(app_module, "get_cached_repository_graph", lambda repo_path, *, loader: None)
        monkeypatch.setattr(app_module, "rebuild_repository_graph", fake_rebuild_repository_graph)

        repo = _get_repo_from_api(client, "uncached-graph-repo")
        resp = client.get(f"/api/repos/{repo['id']}/graph")

        assert resp.status_code == 200
        assert resp.json() == {
            "summary": {"files": 1, "nodes": 1},
            "graph": {"nodes": [{"id": "n1", "label": "File"}], "edges": []},
            "repo_id": repo["id"],
        }

    def test_repo_graph_endpoint_ignores_malformed_cached_graph(
        self,
        app_module,
        client,
        temp_root: Path,
        monkeypatch,
    ) -> None:
        repo_manager = importlib.import_module("csg.infrastructure.repository.internal.repo_registry_runtime")

        repo_path = temp_root / "malformed-cache-repo"
        _register_repo(
            repo_manager,
            repo_path,
            indexed_at="2026-04-07T10:00:00+00:00",
            last_commit="badcache123",
            stats=_repo_stats(files=1, nodes=1, edges=0, communities=0, processes=0),
        )

        async def fake_rebuild_repository_graph(repo_path_arg: str, *, runner, serializer, saver):
            assert repo_path_arg == str(repo_path.resolve())
            assert callable(runner)
            return {
                "summary": {"files": 1, "nodes": 1},
                "graph": {"nodes": [{"id": "rebuilt", "label": "File"}], "edges": []},
            }

        monkeypatch.setattr(
            app_module,
            "get_cached_repository_graph",
            lambda repo_path, *, loader: {"error": "No analysis results"},
        )
        monkeypatch.setattr(app_module, "rebuild_repository_graph", fake_rebuild_repository_graph)

        repo = _get_repo_from_api(client, "malformed-cache-repo")
        resp = client.get(f"/api/repos/{repo['id']}/graph")

        assert resp.status_code == 200
        assert resp.json()["graph"]["nodes"][0]["id"] == "rebuilt"

    def test_query_endpoint_rejects_write_operations(self, client, temp_root: Path) -> None:
        repo_manager = importlib.import_module("csg.infrastructure.repository.internal.repo_registry_runtime")

        repo_path = temp_root / "query-guard-repo"
        _register_repo(
            repo_manager,
            repo_path,
            indexed_at="2026-04-04T10:00:00+00:00",
            last_commit="query123",
            stats=_repo_stats(files=0, nodes=0, edges=0, communities=0, processes=0),
        )

        repo = _get_repo_from_api(client, "query-guard-repo")
        resp = client.post(
            f"/api/repos/{repo['id']}/query",
            json={"cypher": "CREATE (n:Test)", "params": {}},
        )

        assert resp.status_code == 400
        assert "Write operations are not allowed" in resp.json()["detail"]

    def test_query_endpoint_returns_rows_for_read_only_query(
        self, app_module, client, temp_root: Path, monkeypatch
    ) -> None:
        repo_manager = importlib.import_module("csg.infrastructure.repository.internal.repo_registry_runtime")

        repo_path = temp_root / "query-read-repo"
        _register_repo(
            repo_manager,
            repo_path,
            indexed_at="2026-04-05T10:00:00+00:00",
            last_commit="query-ok",
            stats=_repo_stats(files=1, nodes=1, edges=0, communities=0, processes=0),
        )

        storage = repo_manager.get_storage_path(repo_path)
        (storage / "lbug").mkdir(parents=True, exist_ok=True)

        class FakeGraphQueryPort:
            def query(self, repo_id: str, cypher: str, params: dict) -> list[dict]:
                assert isinstance(repo_id, str) and repo_id
                assert "MATCH" in cypher
                assert params == {"limit": 1}
                return [{"path": "alpha.py", "refs": 3}]

        class FakeRepositoryRegistry:
            def list_registered_repos_for_api(self, *, validate: bool = False):
                return repo_manager.list_registered_repos(validate=validate)

        class FakeContainer:
            def get_graph_ports(self) -> dict[str, object]:
                return {"query": FakeGraphQueryPort()}

            def get_repository_registry(self):
                return FakeRepositoryRegistry()

            def get_user_store(self):
                return current_container.get_user_store()

            def get_session_store(self):
                return current_container.get_session_store()

            def get_token_service(self):
                return current_container.get_token_service()

        current_container = app_module.app.state.container
        monkeypatch.setattr(app_module.app.state, "container", FakeContainer())

        repo = _get_repo_from_api(client, "query-read-repo")
        resp = client.post(
            f"/api/repos/{repo['id']}/query",
            json={"cypher": "MATCH (n) RETURN n.path AS path, 3 AS refs", "params": {"limit": 1}},
        )

        assert resp.status_code == 200
        assert resp.json() == {
            "columns": ["path", "refs"],
            "rows": [["alpha.py", 3]],
            "count": 1,
            "truncated": False,
        }

    def test_file_endpoint_requires_active_repo_session(self, client) -> None:
        resp = client.get("/api/file", params={"path": "src/main.py"})

        assert resp.status_code == 404
        assert resp.json() == {"detail": "No analysis session active"}

    @pytest.mark.parametrize(
        ("url", "payload", "expected_detail"),
        [
            ("/api/analyze", {"files": {"file": ("repo.txt", b"hello", "text/plain")}}, "Please upload a .zip file"),
            ("/api/analyze-git", {"json": {"url": "   "}}, "Repository URL is required"),
            ("/api/analyze-url", {"json": {"url": "   "}}, "URL is required"),
        ],
    )
    def test_analysis_endpoints_validate_input_before_starting_work(
        self,
        client,
        url: str,
        payload: dict,
        expected_detail: str,
    ) -> None:
        resp = client.post(url, **payload)

        assert resp.status_code == 400
        assert resp.json() == {"detail": expected_detail}

    def test_cancel_unknown_job_returns_not_found(self, client) -> None:
        resp = client.post("/api/jobs/missing-job/cancel")

        assert resp.status_code == 404
        assert resp.json() == {"detail": "Job not found or already finished"}

    def test_settings_and_account_endpoints_update_user_scoped_configuration(
        self,
        app_module,
        client,
    ) -> None:
        settings_resp = client.get("/api/settings/me")
        assert settings_resp.status_code == 200
        assert settings_resp.json()["default_branch"] == "main"
        assert settings_resp.json()["embeddings_enabled"] is True

        update_resp = client.put(
            "/api/settings/me",
            json={
                "default_branch": "develop",
                "max_file_size_kb": 2048,
                "embeddings_enabled": False,
                "embedding_provider": "local",
                "ocr_provider": "paddle",
                "llm_provider": "openai",
            },
        )
        assert update_resp.status_code == 200
        assert update_resp.json()["default_branch"] == "develop"
        assert update_resp.json()["max_file_size_kb"] == 2048
        assert update_resp.json()["embedding_provider"] == "local"
        assert update_resp.json()["embeddings_enabled"] is False

        status_before_resp = client.get("/api/settings/me/secrets/status")
        assert status_before_resp.status_code == 200
        assert status_before_resp.json()["openai_api_key_configured"] is False
        assert "Important:" in status_before_resp.json()["important_reminder"]

        secret_resp = client.put(
            "/api/settings/me/secrets/openai",
            json={"api_key": "sk-test-user-secret"},
        )
        assert secret_resp.status_code == 200
        assert secret_resp.json()["openai_api_key_configured"] is True

        status_after_resp = client.get("/api/settings/me/secrets/status")
        assert status_after_resp.status_code == 200
        assert status_after_resp.json()["openai_api_key_configured"] is True
        assert status_after_resp.json()["important_reminder"] is None

        profile_resp = client.patch(
            "/api/account/me/profile",
            json={"username": "renamed_user"},
        )
        assert profile_resp.status_code == 200
        assert profile_resp.json()["user"]["username"] == "renamed_user"

        password_resp = client.post(
            "/api/account/me/password",
            json={
                "current_password": "password123",
                "new_password": "new-password-123",
            },
        )
        assert password_resp.status_code == 200
        assert password_resp.json() == {"status": "password_updated"}

        me_resp = client.get("/api/auth/me")
        assert me_resp.status_code == 401

        relogin_resp = client.post(
            "/api/auth/login",
            json={"identifier": "renamed_user", "password": "new-password-123"},
        )
        assert relogin_resp.status_code == 200

        delete_resp = client.delete("/api/account/me")
        assert delete_resp.status_code == 200
        assert delete_resp.json() == {"status": "account_deleted"}

        relogin_after_delete = client.post(
            "/api/auth/login",
            json={"identifier": "renamed_user", "password": "new-password-123"},
        )
        assert relogin_after_delete.status_code == 401

    def test_analyze_git_uses_user_default_branch_when_request_branch_is_blank(
        self,
        app_module,
        client,
        monkeypatch,
    ) -> None:
        current_container = app_module.app.state.container
        captured_clone_commands: list[list[str]] = []

        class FakeRepositoryRegistry:
            def get_storage_path_for_repo(self, repo_path: str):
                return app_module.Path(app_module.os.environ["CSG_DATA_DIR"]) / "repos" / "git-storage"

        class FakeContainer:
            def get_repository_registry(self) -> FakeRepositoryRegistry:
                return FakeRepositoryRegistry()

            def run_analysis_pipeline_sync(self, repo_path: str, *, cancel_event=None) -> dict:
                return {"repo_path": repo_path, "knowledge_graph": None}

            def get_user_store(self):
                return current_container.get_user_store()

            def get_session_store(self):
                return current_container.get_session_store()

            def get_token_service(self):
                return current_container.get_token_service()

            def get_user_settings_store(self):
                return current_container.get_user_settings_store()

            def get_secret_cipher(self):
                return current_container.get_secret_cipher()

            def get_user_secrets_store(self):
                return current_container.get_user_secrets_store()

        def fake_subprocess_run(cmd, capture_output=True, text=True, timeout=0):
            captured_clone_commands.append(list(cmd))
            if cmd[:3] == ["git", "clone", "--depth"]:
                clone_target = app_module.Path(cmd[-1])
                clone_target.mkdir(parents=True, exist_ok=True)
                (clone_target / "README.md").write_text("hello\n", encoding="utf-8")
                return types.SimpleNamespace(returncode=0, stdout="", stderr="")
            if cmd[:4] == ["git", "-C", str(app_module.Path(cmd[2])), "rev-parse"]:
                return types.SimpleNamespace(returncode=0, stdout="abc123\n", stderr="")
            return types.SimpleNamespace(returncode=0, stdout="", stderr="")

        monkeypatch.setattr(app_module.app.state, "container", FakeContainer())
        monkeypatch.setattr(app_module.subprocess, "run", fake_subprocess_run)
        monkeypatch.setattr(
            app_module,
            "run_analysis_pipeline_sync",
            lambda repo_path, *, runner, cancel_event=None: {"repo_path": repo_path, "knowledge_graph": None},
        )
        monkeypatch.setattr(
            app_module,
            "serialize_results",
            lambda final_state: {
                "summary": {"files": 1, "communities": 0, "processes": 0},
                "graph": {"nodes": [], "edges": []},
            },
        )
        monkeypatch.setattr(app_module, "save_graph_json", lambda repo_path, results: None)
        monkeypatch.setattr(app_module, "register_repository_analysis", lambda **kwargs: None)
        runtime_tmp = app_module.Path(app_module.os.environ["CSG_DATA_DIR"]) / "runtime-git-default-branch"
        runtime_tmp.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(app_module, "_make_runtime_temp_dir", lambda prefix: str(runtime_tmp))

        settings_resp = client.put(
            "/api/settings/me",
            json={
                "default_branch": "release",
                "max_file_size_kb": 102400,
                "embeddings_enabled": True,
                "embedding_provider": "openai",
                "ocr_provider": "openai",
                "llm_provider": "openai",
            },
        )
        assert settings_resp.status_code == 200

        resp = client.post("/api/analyze-git", json={"url": "https://example.com/demo.git", "branch": ""})
        assert resp.status_code == 200

        clone_command = next(cmd for cmd in captured_clone_commands if cmd[:3] == ["git", "clone", "--depth"])
        assert "--branch" in clone_command
        assert clone_command[clone_command.index("--branch") + 1] == "release"
