﻿"""Tests for csg/storage/git.py - git utilities."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from csg.infrastructure.repository.internal.git_runtime import get_current_commit, get_git_root, is_git_repo


@pytest.fixture
def git_repo(workspace_temp_dir: Path) -> Path:
    repo = workspace_temp_dir / "repo"
    repo.mkdir()

    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True, text=True)
    subprocess.run(["git", "config", "user.name", "test-user"], cwd=repo, check=True, capture_output=True, text=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=repo, check=True, capture_output=True, text=True)

    (repo / "README.md").write_text("hello\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo, check=True, capture_output=True, text=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=repo, check=True, capture_output=True, text=True)
    return repo


@pytest.mark.integration
class TestGitUtilities:
    def test_is_git_repo_true(self, git_repo: Path) -> None:
        assert is_git_repo(git_repo) is True

    def test_is_git_repo_false(self, workspace_temp_dir: Path) -> None:
        assert is_git_repo(workspace_temp_dir / "missing") is False

    def test_get_git_root(self, git_repo: Path) -> None:
        root = get_git_root(git_repo)
        assert root is not None
        assert Path(root).name == "repo"

    def test_get_current_commit(self, git_repo: Path) -> None:
        commit = get_current_commit(git_repo)
        assert commit is not None
        assert len(commit) >= 7  # at least short hash


