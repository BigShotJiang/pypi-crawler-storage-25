"""Tests for csg/storage/repo_manager.py - repository registry."""

from pathlib import Path

import pytest


@pytest.mark.integration
class TestRepoManager:
    def test_get_storage_path_deterministic(self, monkeypatch, workspace_temp_dir: Path):
        monkeypatch.setenv("CSG_DATA_DIR", str(workspace_temp_dir))
        import importlib
        import csg.infrastructure.config.paths as config_paths
        import csg.infrastructure.repository.internal.repo_registry_runtime as rm

        importlib.reload(config_paths)
        importlib.reload(rm)

        path1 = rm.get_storage_path("/some/repo")
        path2 = rm.get_storage_path("/some/repo")
        assert path1 == path2
        assert path1 == Path("/some/repo").resolve() / ".csg"

    def test_get_storage_path_keeps_uploaded_repos_in_central_storage(self, monkeypatch, workspace_temp_dir: Path):
        monkeypatch.setenv("CSG_DATA_DIR", str(workspace_temp_dir))
        import importlib
        import csg.infrastructure.config.paths as config_paths
        import csg.infrastructure.repository.internal.repo_registry_runtime as rm

        importlib.reload(config_paths)
        importlib.reload(rm)

        uploaded_repo = config_paths.REPOS_DIR / "abc123" / "repo"

        assert rm.get_storage_path(uploaded_repo) == config_paths.REPOS_DIR / "abc123"

    def test_has_index_false(self, monkeypatch, workspace_temp_dir: Path):
        monkeypatch.setenv("CSG_DATA_DIR", str(workspace_temp_dir))
        import importlib
        import csg.infrastructure.config.paths as config_paths
        import csg.infrastructure.repository.internal.repo_registry_runtime as rm

        importlib.reload(config_paths)
        importlib.reload(rm)

        assert rm.has_index("/nonexistent/repo") is False
