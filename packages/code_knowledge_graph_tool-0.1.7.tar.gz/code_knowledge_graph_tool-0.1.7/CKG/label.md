## Mục tiêu

Áp dụng nhãn `AMBIGUOUS` cho `code-knowledge-graph`.

- edge bình thường: không có nhãn
- edge mơ hồ: có nhãn `AMBIGUOUS`


## Mô hình dữ liệu nên dùng

Hiện tại `GraphRelationship` có:

- `id`
- `source_id`
- `target_id`
- `type`
- `confidence`
- `reason`
- `step`
- `in_cycle`

Nên thêm một field tùy chọn, ví dụ:

- `review_label: str | None = None`

hoặc nếu muốn bám đúng chữ “label”:

- `edge_label: str | None = None`

Khuyến nghị:

- dùng `review_label`

vì ý nghĩa rõ hơn:

- đây là nhãn để review edge
- không phải nhãn bắt buộc cho mọi edge

### Cách dùng

Edge bình thường:

- `review_label = None`

Edge cần review:

- `review_label = "AMBIGUOUS"`


## Persistence / schema / bulk load

`CodeRelation` hiện lưu:

- `type`
- `confidence`
- `reason`
- `step`
- `inCycle`

Nếu muốn persist nhãn `AMBIGUOUS`, vẫn phải thêm một cột nullable, ví dụ:

- `reviewLabel STRING`

Điều này cần sửa ở các chỗ:

- `csg/domain/codebase/value_objects.py`
- `csg/infrastructure/graph/lbug_schema.py`
- `csg/infrastructure/graph/csv_generator.py`
- `csg/infrastructure/graph/lbug_adapter.py`

Quan trọng:

- cột này nên để nullable
- phần lớn edge sẽ không có giá trị


## Những nơi trong pipeline có thể cần gán `AMBIGUOUS`

Chỉ những nơi thật sự có edge mơ hồ mới nên set nhãn.

### 1. Call resolution

Đây là nơi rõ nhất.

File liên quan:

- `csg/infrastructure/analysis/internal/analysis/analysis/call_processor.py`

Hiện tại call resolver có các nhóm:

- `same-file`
- `import-scoped`
- `member-resolved`
- `type-inferred`
- `global`
- `*-ambiguous`

Theo hướng mới:

- `same-file`: không gán nhãn
- `import-scoped`: không gán nhãn
- `member-resolved`: không gán nhãn
- `type-inferred`: không gán nhãn
- `global`: không gán nhãn
- `*-ambiguous`: gán `AMBIGUOUS`

Tức là:

| reason | Gán nhãn |
|---|---|
| `same-file` | không |
| `import-scoped` | không |
| `member-resolved` | không |
| `type-inferred` | không |
| `global` | không |
| `*-ambiguous` | `AMBIGUOUS` |

Đây là nơi quan trọng nhất cần giữ nhãn.

### 2. Semantic linking

File liên quan:

- `csg/infrastructure/sources/internal/semantic_linker.py`

Sinh ra:

- `DESCRIBES`
- `DOCUMENTED_BY`

Hiện tại:

- `confidence = similarity`
- `reason = "embedding-similarity"`

Theo hướng mới:

- similarity cao, vượt ngưỡng chắc chắn: không gán nhãn
- similarity gần threshold, còn lăn tăn: gán `AMBIGUOUS`
- dưới threshold: không tạo edge

Tức là:

| Similarity | Gán nhãn |
|---|---|
| cao, vượt threshold | không |
| gần threshold | `AMBIGUOUS` |
| dưới threshold | không tạo edge |

Đây là nơi tự nhiên thứ hai để dùng `AMBIGUOUS`.

## Kết luận

Với `CKG`, hướng thực dụng nhất là:

- không dán nhãn cho toàn bộ graph
- chỉ đánh dấu `AMBIGUOUS` cho những edge thật sự mơ hồ

Hiện tại, những nơi phù hợp nhất để áp dụng là:

1. `CALLS` với `*-ambiguous`
2. semantic linking ở vùng gần threshold

Mọi edge khác:

- giữ nguyên
- không gán nhãn
