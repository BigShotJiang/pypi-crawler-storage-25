# Chức năng của instruction, skill, hook

| Thành phần | Chức năng chính | Dùng để làm gì | Nội dung thường chứa |
|---|---|---|---|
| `instruction` | Đặt quy tắc nền cho agent | Hướng dẫn agent nên ưu tiên gì, tránh gì, và dùng `code-knowledge-graph` theo cách nào khi làm việc trên repo đích | Nguyên tắc chung, guardrail, thứ tự ưu tiên, cách đọc output từ graph/context/impact/rename/detect changes |
| `skill` | Đóng gói một workflow cụ thể | Cho agent một bài làm rõ ràng theo từng tác vụ như `explore`, `impact`, `rename`, `detect changes` | Mục đích của workflow, điều kiện nên dùng, các bước thực hiện, tool cần dùng, checklist cuối |
| `hook` | Tự động chạy theo sự kiện | Kiểm tra, chặn, log, hoặc trigger hành động phụ trước/sau tool hay ở đầu/cuối session | Danh sách event, điều kiện kích hoạt, logic kiểm tra/chặn/log/tự động hóa |


# Platform integration for `code-knowledge-graph`

| Platform | Instruction | Skill | Hook | Nơi ghi hook |
|---|---|---|---|---|
| Claude | `CLAUDE.md` ở root repo | `.claude/skills/<name>/SKILL.md` | `PreToolUse`, `PostToolUse`, `Notification`, `UserPromptSubmit`, `Stop`, `SubagentStop` | `.claude/settings.json` |
| Codex | `AGENTS.md` ở root repo | `.codex/skills/<name>/SKILL.md` | `SessionStart`, `PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Stop` | `.codex/hooks.json` |
| Gemini | `GEMINI.md` ở root repo | `.gemini/skills/<name>/SKILL.md` | `SessionStart`, `SessionEnd`, `BeforeAgent`, `BeforeModel`, `BeforeToolSelection`, `BeforeTool`, `AfterTool`, `AfterModel` | `.gemini/settings.json` |
| Copilot family | `.github/copilot-instructions.md` | `.github/skills/<name>/SKILL.md` | `sessionStart`, `sessionEnd`, `userPromptSubmitted`, `preToolUse`, `postToolUse`, `errorOccurred`, `agentStop`, `subagentStop` | `.github/hooks/*.json` |
| Cursor | `.cursor/rules/*.mdc` hoặc `AGENTS.md` ở root repo | `.cursor/skills/<name>/SKILL.md` hoặc `.agents/skills/<name>/SKILL.md` | `SessionStart`, `SessionEnd`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `SubagentStart`, `stop`, `beforeShellExecution`, `afterShellExecution`, `afterFileEdit`, `beforeMCPExecution` | `.cursor/hooks.json` |
| Antigravity | `GEMINI.md` ở root repo | `.agent/skills/<name>/SKILL.md` | `X` | `X` |


# Ví dụ cách dùng hook

### Ví dụ file hook config

Ví dụ kiểu repo-level cho Copilot:

Path:

- `.github/hooks/csg-context.json`

Nội dung:

```json
{
  "version": 1,
  "hooks": {
    "preToolUse": [
      {
        "type": "command",
        "bash": ".github/hooks/scripts/csg-pretool.sh",
        "powershell": ".github/hooks/scripts/csg-pretool.ps1",
        "cwd": ".",
        "timeoutSec": 10
      }
    ]
  }
}
```

Ý nghĩa:

- khi event `preToolUse` xảy ra
- platform gọi script shell tương ứng
- script đọc input JSON từ stdin
- script quyết định có trả thêm context, chặn, hoặc cho phép chạy tiếp

### Ví dụ script hook

Path:

- `.github/hooks/scripts/csg-pretool.sh`

Nội dung:

```bash
#!/usr/bin/env bash
set -euo pipefail

INPUT="$(cat)"

if [ -f ".csg/graph.json" ] || [ -f "csg-out/graph.json" ]; then
  printf '%s\n' '{
    "hookSpecificOutput": {
      "hookEventName": "preToolUse",
      "additionalContext": "Code-knowledge-graph already exists. Read the graph/context resources before grepping raw files."
    }
  }'
else
  printf '%s\n' '{}'
fi
```

Ý nghĩa:

- `cat` stdin để nhận dữ liệu event mà platform gửi vào
- kiểm tra xem graph của repo đã tồn tại chưa
- nếu đã có:
  - trả JSON có `additionalContext`
- nếu chưa có:
  - trả `{}` để không thêm gì

## Cách hiểu đúng về hook config và hook script

Có 2 phần khác nhau:

| Thành phần | Vai trò |
|---|---|
| Hook config | Nói với platform: ở event nào thì chạy command nào |
| Hook script | Logic thực tế: đọc input event, kiểm tra điều kiện, rồi log/chặn/thêm context |

Nói ngắn:

- file config là nơi đăng ký hook
- script là nơi viết hành vi của hook

## Trong `code-knowledge-graph` có thể dùng hook để làm gì

Các hướng dùng thực tế nhất:

1. Trước khi agent search file:
   - nhắc đọc graph/context/processes trước
2. Trước khi chạy tool nguy hiểm:
   - chặn nếu chưa chạy `impact`
3. Sau khi file code bị sửa:
   - log thay đổi
   - trigger incremental analyze hoặc watch pipeline
4. Khi session bắt đầu:
   - inject context về repo đã index, graph path, MCP resource path
