# 🔍 ISSUES

## Chức năng đang làm gì

`ISSUES` là tab tổng hợp các vấn đề về chất lượng code và kiến trúc. Nó lấy dữ liệu từ pipeline phân tích đã chạy xong rồi gom thành các nhóm issue để hiển thị.

Các nhóm issue hiện có gồm:

- `Unused Functions`
- `Large Files`
- `Highly Coupled`
- `Circular Dependencies`
- `Duplicate Function Names`
- `Similar Code Blocks`
- `Architecture Violations`
- `High Complexity Files`

## Cách thực hiện

### Unused Functions

Hệ thống lấy các function top-level có zero calls và cố gắng loại trừ một số trường hợp dễ false positive như:

- test functions
- Python migration hooks
- framework entry points
- exported JS/TS functions

Nếu function còn lại không có ai gọi, nó bị đưa vào danh sách `Unused Functions`.

### Large Files

Một file có hơn 15 functions sẽ bị coi là file quá lớn và bị flag.

### Highly Coupled

Hệ thống đếm số cạnh dependency đi vào từng file. Nếu một file bị import bởi hơn 8 file khác, nó bị coi là highly coupled.

### Circular Dependencies

Từ tập các cạnh `source -> target`, hệ thống dựng `connSet`, rồi kiểm tra xem có cặp ngược `target -> source` không. Nếu có, nó kết luận có circular dependency.

### Duplicate Function Names

Function được group theo tên. Một số tên phổ biến như `render`, `init`, `test`, lifecycle methods, class methods, decorators sẽ bị bỏ qua để giảm nhiễu. Nếu cùng một tên xuất hiện ở ít nhất 3 file và code similarity của các mẫu đủ cao, nó bị coi là duplicate name issue.

### Similar Code Blocks

Hệ thống tạo structural fingerprint cho code của function, rồi dùng một phép so sánh dựa trên LCS để đo độ giống nhau. Nếu similarity cao hơn ngưỡng thì nó bị coi là copy-paste / duplicate logic.

### Architecture Violations

Mỗi file được gán một layer suy diễn từ path như `ui`, `services`, `data`, `utils`, `config`... Sau đó hệ thống kiểm tra dependency direction. Nếu layer thấp hơn lại import layer cao hơn, và chênh lệch vượt ngưỡng, nó bị coi là violation.

### High Complexity Files

Mỗi file được chấm complexity bằng cách cộng số lần xuất hiện của các pattern như:

- `if`
- `for`
- `while`
- `catch`
- `&&`
- `||`

và một số pattern tương tự của Python. Nếu score vượt 30, file bị đưa vào issue.

## Điểm yếu của cách làm

### Unused Functions

- Chỉ đáng tin ở mức tương đối vì call detection không thể bao phủ mọi kiểu dynamic dispatch, reflection, framework registration hoặc indirect invocation.
- Mới tập trung vào function-level, chưa thật sự hiểu public API của toàn repo.

### Large Files

- Ngưỡng `15 functions` là ngưỡng cứng, không theo ngữ cảnh dự án.
- Một file nhiều function chưa chắc là xấu nếu nó là module hợp lý.

### Highly Coupled

- Chỉ nhìn số import vào file, chưa đo coupling ở mức symbol hoặc subsystem.
- Có thể flag sai các file hub hợp lệ như config, types, shared contracts.

### Circular Dependencies

- Chỉ phát hiện vòng trực tiếp hai chiều, không phản ánh đầy đủ cycle phức tạp hơn trong graph.
- Thiếu phân biệt giữa cycle nguy hiểm và cycle vô hại ở mức build/runtime.

### Duplicate Function Names / Similar Code Blocks

- Vẫn có thể false positive nếu code giống nhau về form nhưng khác về intent.
- Bỏ qua nhiều trường hợp duplicate logic tinh vi không lộ ra ở similarity text/fingerprint.

### Architecture Violations

- Layer hiện tại được suy luận từ path, nên phụ thuộc mạnh vào naming convention.
- Nếu repo không tuân layout folder rõ ràng thì kết quả sẽ yếu.

### High Complexity Files

- Đây là complexity kiểu heuristic, không phải cyclomatic complexity chuẩn.
- Đếm keyword ở level file khiến signal khá thô, thiếu chính xác ở level function.
