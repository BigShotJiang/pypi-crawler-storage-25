## Mục tiêu

Mục tiêu của `watch` là để khi repo đích thay đổi, `code-knowledge-graph`
có thể tự động chạy lại incremental re-ingestion thay vì bắt người dùng
phải gọi `analyze` lại bằng tay.

Ý tưởng chính là:

- theo dõi thay đổi file trong repo đích
- gom các thay đổi thành batch nhỏ bằng debounce
- khi thay đổi đã ổn định thì chạy incremental pipeline
- giữ trải nghiệm "save file -> graph được cập nhật lại" gần với thời gian thực

## `watchfiles` trả về gì

`(Change.added, '/path/to/new_file.py')`

`(Change.modified, '/path/to/updated_file.py')`

`(Change.deleted, '/path/to/removed_file.py')`

## Luồng hoạt động đề xuất

Ở mức high level, luồng có thể là:

1. Người dùng chạy `csg watch`.
2. `watchfiles` theo dõi repo đích.
3. Khi file thay đổi, watcher nhận một batch event.
4. `watch_filter` loại các path chắc chắn là noise.
5. Watcher kiểm tra batch sau lọc ở mức nghiệp vụ.
6. Watcher chờ debounce để tránh chạy quá nhiều lần.
7. Khi batch đã ổn định, watcher kích hoạt incremental pipeline.
8. Graph, search index, context, impact data được làm mới.

## `watch_filter` nên được dùng như thế nào

`watch_filter` là lớp lọc đầu tiên và nên được dùng ngay ở đầu vào.

- thư mục hệ thống hoặc metadata
- file tạm của editor
- binary rõ ràng không thuộc đầu vào pipeline
- cache, virtualenv, dependency trees

## Những gì nên bỏ qua

Filesystem watcher không nên phản ứng với mọi thứ.

Nó nên bỏ qua các thư mục và file như:

- `.git/`
- cache directories
- virtualenv
- `node_modules/`
- output của chính hệ thống
- temp files của editor
- binary hoặc file type không thuộc đầu vào pipeline

Điểm này rất quan trọng vì nếu không lọc kỹ, watcher sẽ tự gây re-index loop
hoặc re-index quá thường xuyên.

## Debounce là bắt buộc

Khi editor lưu file, thường không chỉ có một event.
Có thể có:

- nhiều lần write liên tiếp
- formatter chạy ngay sau save
- rename tạm rồi ghi đè
- nhiều file cùng đổi trong một refactor

Vì vậy watcher nên có debounce để:

- gom event thành một batch
- tránh re-index liên tục
- tránh chạy khi file còn đang được ghi

## Tích hợp hợp lý nhất cho `code-knowledge-graph`

Nếu ưu tiên kiến trúc và khả năng mở rộng, hướng hợp lý nhất là:

1. dùng `watchfiles.watch(...)` để lấy batch thay đổi filesystem
2. dùng `watch_filter` để loại noise từ sớm
3. debounce batch
4. publish một event như `source_changed`
5. re-ingestion (trog quá trình index, hoạt động bình thường)