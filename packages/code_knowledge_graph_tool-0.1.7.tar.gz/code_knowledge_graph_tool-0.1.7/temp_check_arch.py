"""Clean Architecture dependency checker."""
import ast
import os
from collections import defaultdict

edges = []
modules = set()

for root, dirs, files in os.walk('csg'):
    for f in files:
        if f.endswith('.py'):
            path = os.path.join(root, f)
            rel_path = path.replace('\\', '/').replace('.py', '').replace('/', '.')
            if rel_path.startswith('csg.'):
                module_name = rel_path
                modules.add(module_name)
                try:
                    with open(path, 'r', encoding='utf-8') as file:
                        tree = ast.parse(file.read(), filename=path)
                        for node in ast.walk(tree):
                            if isinstance(node, ast.ImportFrom):
                                if node.module and node.module.startswith('csg.'):
                                    edges.append((module_name, node.module))
                except Exception as e:
                    print(f'Error parsing {path}: {e}')

# Build layer mapping
layers = {}
for m in modules:
    if m.startswith('csg.domain.'):
        layers[m] = 'domain'
    elif m.startswith('csg.application.'):
        layers[m] = 'application'
    elif m.startswith('csg.adapters.inbound.'):
        layers[m] = 'inbound'
    elif m.startswith('csg.adapters.outbound.'):
        layers[m] = 'outbound'
    elif m.startswith('csg.infrastructure.'):
        layers[m] = 'infrastructure'
    else:
        layers[m] = 'core'

# Check violations
violations = []
for src, dst in edges:
    if src in layers and dst in layers:
        src_layer = layers[src]
        dst_layer = layers[dst]
        # Clean Architecture rules: inward dependencies only
        if src_layer == 'domain':
            if dst_layer not in ['domain', 'core']:
                violations.append(f'DOMAIN VIOLATION: {src} -> {dst}')
        elif src_layer == 'application':
            if dst_layer not in ['domain', 'application', 'core']:
                violations.append(f'APPLICATION VIOLATION: {src} -> {dst}')
        elif src_layer == 'inbound':
            if dst_layer not in ['domain', 'application', 'inbound', 'core']:
                violations.append(f'INBOUND VIOLATION: {src} -> {dst}')
        elif src_layer == 'outbound':
            if dst_layer not in ['domain', 'application', 'outbound', 'core']:
                violations.append(f'OUTBOUND VIOLATION: {src} -> {dst}')
        elif src_layer == 'infrastructure':
            if dst_layer not in ['domain', 'application', 'infrastructure', 'core']:
                violations.append(f'INFRASTRUCTURE VIOLATION: {src} -> {dst}')

if violations:
    print('CLEAN ARCHITECTURE VIOLATIONS:')
    for v in sorted(set(violations))[:100]:
        print(v)
    print(f'\nTotal violations: {len(set(violations))}')
else:
    print('No dependency violations found!')
