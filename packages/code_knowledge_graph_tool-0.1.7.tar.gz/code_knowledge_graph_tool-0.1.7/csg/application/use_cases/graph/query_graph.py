"""Application use-case for graph query execution."""

from __future__ import annotations

import asyncio
from typing import Any

from csg.application.ports.graph_query_port import GraphQueryPort


async def query_graph(
    *,
    repo_id: str,
    cypher: str,
    params: dict[str, Any],
    query_adapter: GraphQueryPort,
) -> list[dict[str, Any]]:
    """Execute a read-only graph query via bound graph query adapter."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: query_adapter.query(repo_id, cypher, params or {}))
