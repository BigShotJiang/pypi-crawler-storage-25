"""Graph use-case entrypoints."""

from csg.application.use_cases.graph.query_graph import query_graph

__all__ = ["query_graph"]

