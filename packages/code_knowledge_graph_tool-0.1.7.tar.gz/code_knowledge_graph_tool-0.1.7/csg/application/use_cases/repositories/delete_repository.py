"""Application use-case for deleting registered repositories."""

from __future__ import annotations

import shutil
from typing import Any

from csg.application.ports.repository_registry_port import RepositoryRegistryPort
from csg.application.use_cases.repositories._helpers import to_repo_id


def delete_repository(
    repo_id: str,
    *,
    repository_registry: RepositoryRegistryPort,
) -> dict[str, Any]:
    """Delete a repository entry and its storage directory."""
    target = next(
        (
            {
                "id": to_repo_id(entry.storage_path),
                "name": entry.name,
                "path": entry.path,
                "indexed_at": entry.indexed_at,
                "last_commit": entry.last_commit,
                "owner_user_id": getattr(entry, "owner_user_id", None),
                "stats": entry.stats,
                "storage_path": entry.storage_path,
            }
            for entry in repository_registry.list_registered_repos_for_api(validate=False)
            if to_repo_id(entry.storage_path) == repo_id
        ),
        None,
    )
    if target is None:
        return {"status": "not_found"}

    repository_registry.unregister_repo_entry(target["path"])
    storage = repository_registry.get_storage_path_for_repo(target["path"])
    if storage.exists():
        shutil.rmtree(storage, ignore_errors=True)

    return {"status": "removed", "storage_cleaned": True, "repo": target}
