"""Application use-case for cleaning a repository index."""

from __future__ import annotations

import shutil

from csg.application.ports.repository_registry_port import RepositoryRegistryPort


def clean_repository_index(repo_path: str, *, repository_registry: RepositoryRegistryPort) -> dict:
    """Delete local index storage and unregister repository."""
    storage = repository_registry.get_storage_path_for_repo(repo_path)
    if not storage.exists():
        return {"exists": False}
    shutil.rmtree(storage, ignore_errors=True)
    repository_registry.unregister_repo_entry(repo_path)
    return {"exists": True}
