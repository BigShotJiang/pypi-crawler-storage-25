"""Application use-case for repository index staleness."""

from __future__ import annotations

from csg.application.ports.repository_registry_port import RepositoryRegistryPort


def check_staleness(repo_path: str, *, repository_registry: RepositoryRegistryPort) -> dict:
    """Compare indexed commit vs current git commit for a repo."""
    meta = repository_registry.load_repo_meta(repo_path)
    if meta is None:
        return {
            "is_stale": True,
            "indexed_commit": "",
            "current_commit": "",
            "message": "No index found. Run `csg analyze` first.",
        }

    indexed_commit = meta.last_commit or ""
    current_commit = repository_registry.get_current_commit_for_repo(repo_path) or ""

    if not indexed_commit:
        return {
            "is_stale": True,
            "indexed_commit": "",
            "current_commit": current_commit,
            "message": "Index has no commit recorded. Re-run `csg analyze`.",
        }

    if indexed_commit != current_commit:
        return {
            "is_stale": True,
            "indexed_commit": indexed_commit[:8],
            "current_commit": current_commit[:8],
            "message": (
                f"Index is stale (indexed: {indexed_commit[:8]}, "
                f"current: {current_commit[:8]}). Run `csg analyze` to update."
            ),
        }

    return {
        "is_stale": False,
        "indexed_commit": indexed_commit[:8],
        "current_commit": current_commit[:8],
        "message": "Index is up to date.",
    }
