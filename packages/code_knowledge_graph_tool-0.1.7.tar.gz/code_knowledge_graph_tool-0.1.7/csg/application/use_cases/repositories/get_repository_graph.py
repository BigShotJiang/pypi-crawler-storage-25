"""Application use-case for obtaining repository graph results."""

from __future__ import annotations

import asyncio
from typing import Any, Callable

from csg.application.use_cases.analysis.run_pipeline import run_analysis_pipeline_sync


def get_cached_repository_graph(
    repo_path: str,
    *,
    loader: Callable[[str], dict[str, Any] | None],
) -> dict[str, Any] | None:
    """Load cached graph.json for a repository source path."""
    return loader(repo_path)


async def rebuild_repository_graph(
    repo_path: str,
    *,
    runner: Callable[..., dict[str, Any]],
    serializer: Callable[[dict[str, Any]], dict[str, Any]],
    saver: Callable[[str, dict[str, Any]], Any],
) -> dict[str, Any]:
    """Re-run analysis pipeline and return serialized graph payload."""
    loop = asyncio.get_event_loop()
    final_state = await loop.run_in_executor(
        None,
        lambda: run_analysis_pipeline_sync(repo_path, runner=runner),
    )
    results = serializer(final_state)
    saver(repo_path, results)
    return results
