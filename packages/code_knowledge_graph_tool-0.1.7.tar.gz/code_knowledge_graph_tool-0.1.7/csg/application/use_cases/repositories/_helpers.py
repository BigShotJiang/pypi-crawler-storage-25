"""Repository use-case helper functions."""

from __future__ import annotations

from pathlib import Path

from csg.domain.repository_ids import repository_id_from_storage_path


def to_repo_id(storage_path: str | Path) -> str:
    """Compute stable repository id from storage path."""
    return repository_id_from_storage_path(storage_path)
