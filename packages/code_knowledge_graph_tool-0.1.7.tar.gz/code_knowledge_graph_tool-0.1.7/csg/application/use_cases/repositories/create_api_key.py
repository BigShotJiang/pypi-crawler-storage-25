"""Application use-case for creating API keys."""

from __future__ import annotations

from csg.application.ports.api_key_store_port import ApiKeyStorePort


def create_api_key(description: str, *, owner_user_id: str, api_key_store: ApiKeyStorePort) -> dict:
    """Create and persist a new API key record."""
    return api_key_store.create_key(description, owner_user_id=owner_user_id)
