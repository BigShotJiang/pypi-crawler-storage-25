"""Repository use-case entrypoints."""

from csg.application.use_cases.repositories.check_staleness import check_staleness
from csg.application.use_cases.repositories.create_api_key import create_api_key
from csg.application.use_cases.repositories.clean_repository_index import clean_repository_index
from csg.application.use_cases.repositories.delete_api_key import delete_api_key
from csg.application.use_cases.repositories.delete_repository import delete_repository
from csg.application.use_cases.repositories.get_repository_status import get_repository_status
from csg.application.use_cases.repositories.get_repository_graph import (
    get_cached_repository_graph,
    rebuild_repository_graph,
)
from csg.application.use_cases.repositories.list_api_keys import list_api_keys
from csg.application.use_cases.repositories.list_repositories import list_repositories
from csg.application.use_cases.repositories.register_repository_analysis import (
    register_repository_analysis,
)

__all__ = [
    "check_staleness",
    "clean_repository_index",
    "create_api_key",
    "delete_api_key",
    "delete_repository",
    "get_cached_repository_graph",
    "get_repository_status",
    "list_api_keys",
    "list_repositories",
    "rebuild_repository_graph",
    "register_repository_analysis",
]
