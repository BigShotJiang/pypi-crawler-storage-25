"""Application use-case for repository index status."""

from __future__ import annotations

from csg.application.ports.repository_registry_port import RepositoryRegistryPort
from csg.application.use_cases.repositories.check_staleness import check_staleness


def get_repository_status(repo_path: str, *, repository_registry: RepositoryRegistryPort) -> dict:
    """Return repository metadata and staleness signal."""
    meta = repository_registry.load_repo_meta(repo_path)
    if meta is None:
        return {"exists": False}
    return {
        "exists": True,
        "meta": {
            "commit": getattr(meta, "last_commit", "") or "",
            "files": (getattr(meta, "stats", {}) or {}).get("files", 0),
            "nodes": (getattr(meta, "stats", {}) or {}).get("nodes", 0),
            "relationships": (getattr(meta, "stats", {}) or {}).get("edges", 0),
            "communities": (getattr(meta, "stats", {}) or {}).get("communities", 0),
            "processes": (getattr(meta, "stats", {}) or {}).get("processes", 0),
            "embeddings": (getattr(meta, "stats", {}) or {}).get("embeddings", 0),
        },
        "staleness": check_staleness(repo_path, repository_registry=repository_registry),
    }
