"""Application use-case for deleting API keys."""

from __future__ import annotations

from csg.application.ports.api_key_store_port import ApiKeyStorePort


def delete_api_key(key_id: str, *, owner_user_id: str, api_key_store: ApiKeyStorePort) -> bool:
    """Delete a key by id. Returns True when deleted."""
    return api_key_store.delete_key(key_id, owner_user_id=owner_user_id)
