"""Application use-case for listing registered repositories."""

from __future__ import annotations

from typing import Any

from csg.application.ports.repository_registry_port import RepositoryRegistryPort
from csg.application.use_cases.repositories._helpers import to_repo_id


def list_repositories(
    *,
    validate: bool = False,
    repository_registry: RepositoryRegistryPort,
) -> list[dict[str, Any]]:
    """Return transport-ready repository summaries."""
    repos = repository_registry.list_registered_repos_for_api(validate=validate)
    return [
        {
            "id": to_repo_id(entry.storage_path),
            "name": entry.name,
            "path": entry.path,
            "indexed_at": entry.indexed_at,
            "last_commit": entry.last_commit,
            "owner_user_id": getattr(entry, "owner_user_id", None),
            "stats": entry.stats,
            "storage_path": entry.storage_path,
        }
        for entry in repos
    ]
