"""Application use-case for listing API keys."""

from __future__ import annotations

from csg.application.ports.api_key_store_port import ApiKeyStorePort


def list_api_keys(*, owner_user_id: str, api_key_store: ApiKeyStorePort) -> list[dict]:
    """List stored API keys."""
    return api_key_store.list_keys(owner_user_id=owner_user_id)
