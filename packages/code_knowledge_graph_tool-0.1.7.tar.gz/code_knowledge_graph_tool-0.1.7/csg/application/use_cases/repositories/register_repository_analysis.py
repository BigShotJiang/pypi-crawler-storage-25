"""Application use-case for persisting repository analysis metadata."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from csg.application.ports.repository_registry_port import RepositoryRegistryPort

def register_repository_analysis(
    *,
    repo_path: str,
    source_label: str,
    final_state: dict[str, Any],
    results: dict[str, Any],
    repository_registry: RepositoryRegistryPort,
    owner_user_id: str | None = None,
) -> None:
    """Persist repository metadata and register repository entry."""
    kg = final_state.get("knowledge_graph")
    node_count = kg.node_count if kg else 0
    rel_count = kg.relationship_count if kg else 0
    meta = repository_registry.build_repo_meta(
        repo_path=repo_path,
        last_commit=source_label,
        indexed_at=datetime.now(timezone.utc).isoformat(),
        owner_user_id=owner_user_id,
        stats={
            "files": results.get("summary", {}).get("files", 0),
            "nodes": node_count,
            "edges": rel_count,
            "communities": results.get("summary", {}).get("communities", 0),
            "processes": results.get("summary", {}).get("processes", 0),
            "embeddings": 0,
        },
    )
    repository_registry.save_repo_meta(repo_path, meta)
    repository_registry.register_repo_entry(repo_path, meta)
