"""Use-cases for user-owned account mutations."""

from __future__ import annotations

from datetime import datetime, timezone

from csg.application.ports.session_store_port import SessionStorePort
from csg.application.ports.user_store_port import UserStorePort
from csg.infrastructure.security.password_hasher import PasswordHasher


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def change_username(
    *,
    user_id: str,
    username: str,
    user_store: UserStorePort,
) -> dict:
    """Rename a user account while preserving its stable user id."""
    normalized = username.strip()
    if len(normalized) < 3:
        raise ValueError("Username must be at least 3 characters")
    existing = user_store.get_by_username(normalized)
    if existing and existing.get("id") != user_id:
        raise ValueError("Username already exists")
    updated = user_store.update_username(user_id, username=normalized, updated_at=_utcnow())
    if updated is None:
        raise ValueError("User not found")
    return updated


def change_password(
    *,
    user_id: str,
    current_password: str,
    new_password: str,
    user_store: UserStorePort,
    session_store: SessionStorePort,
    password_hasher: PasswordHasher,
) -> None:
    """Change a user's password and revoke all existing sessions."""
    user = user_store.get_by_id(user_id)
    if not user or user.get("status") != "active":
        raise ValueError("User not found")
    if not password_hasher.verify_password(current_password, user.get("password_hash", "")):
        raise ValueError("Current password is incorrect")
    if len(new_password) < 8:
        raise ValueError("Password must be at least 8 characters")
    now = _utcnow()
    updated = user_store.update_password_hash(
        user_id,
        password_hash=password_hasher.hash_password(new_password),
        updated_at=now,
    )
    if updated is None:
        raise ValueError("User not found")
    session_store.revoke_sessions_for_user(user_id, revoked_at=now)


def soft_delete_account(
    *,
    user_id: str,
    user_store: UserStorePort,
    session_store: SessionStorePort,
) -> None:
    """Soft-delete an account and invalidate all active sessions."""
    now = _utcnow()
    updated = user_store.update_status(user_id, status="deleted", updated_at=now)
    if updated is None:
        raise ValueError("User not found")
    session_store.revoke_sessions_for_user(user_id, revoked_at=now)
