"""Application use-case for registering a new user."""

from __future__ import annotations

from csg.application.ports.user_store_port import UserStorePort


def register_user(
    *,
    username: str,
    email: str,
    password_hash: str,
    user_store: UserStorePort,
) -> dict:
    """Create a member account after uniqueness checks."""
    normalized_username = username.strip()
    normalized_email = email.strip().lower()
    if user_store.get_by_username(normalized_username):
        raise ValueError("Username already exists")
    if user_store.get_by_email(normalized_email):
        raise ValueError("Email already exists")
    return user_store.create_user(
        username=normalized_username,
        email=normalized_email,
        password_hash=password_hash,
        role="member",
        status="active",
    )
