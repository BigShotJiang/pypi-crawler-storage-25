"""Application use-case for listing users."""

from __future__ import annotations

from csg.application.ports.user_store_port import UserStorePort


def list_users(*, user_store: UserStorePort) -> list[dict]:
    """Return all persisted users."""
    return user_store.list_users()
