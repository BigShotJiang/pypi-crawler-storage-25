"""Application use-case for loading a user for authentication."""

from __future__ import annotations

from csg.application.ports.user_store_port import UserStorePort


def login_user(identifier: str, *, user_store: UserStorePort) -> dict | None:
    """Load an active user by username or email."""
    key = identifier.strip()
    user = user_store.get_by_email(key.lower()) if "@" in key else user_store.get_by_username(key)
    if not user:
        return None
    if user.get("status") != "active":
        return None
    return user
