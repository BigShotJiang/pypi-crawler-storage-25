"""Application use-case for running agent workflows."""

from __future__ import annotations

from typing import Any

from csg.application.ports.agent_gateway_port import AgentGatewayPort


async def run_agent(
    *,
    conversation_id: str,
    user_message: str,
    agent_gateway: AgentGatewayPort,
    selected_node: dict[str, Any] | None = None,
    repo_id: str | None = None,
) -> dict[str, Any]:
    """Run agent orchestration using infrastructure implementation."""
    return dict(await agent_gateway.run({
        "conversation_id": conversation_id,
        "user_message": user_message,
        "selected_node": selected_node,
        "repo_id": repo_id,
    }))
