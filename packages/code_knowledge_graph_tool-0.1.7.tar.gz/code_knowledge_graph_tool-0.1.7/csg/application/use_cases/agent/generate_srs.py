"""Application use-case for SRS generation."""

from __future__ import annotations

from csg.application.ports.agent_gateway_port import AgentGatewayPort


def generate_srs(*, context: str, repo_path: str, agent_gateway: AgentGatewayPort) -> str:
    """Generate SRS document using infrastructure implementation."""
    return agent_gateway.generate_srs(context=context, repo_path=repo_path)
