"""Search use-case entrypoints."""

__all__: list[str] = []
