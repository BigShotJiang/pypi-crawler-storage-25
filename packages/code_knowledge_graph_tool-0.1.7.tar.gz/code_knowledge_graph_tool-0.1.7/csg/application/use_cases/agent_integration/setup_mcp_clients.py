"""Register the CSG MCP server with installed agent CLIs."""

from __future__ import annotations

import shutil
import subprocess
from collections.abc import Callable
from typing import Any

Runner = Callable[..., Any]
Which = Callable[[str], str | None]


def setup_mcp_clients(
    *,
    csg_command: str = "csg",
    server_name: str = "csg",
    which: Which = shutil.which,
    runner: Runner = subprocess.run,
) -> dict[str, dict[str, str]]:
    """Install CSG MCP server entries for supported agent CLIs found on PATH."""
    results: dict[str, dict[str, str]] = {}

    command_args = {
        "claude": [
            "mcp",
            "add",
            "--transport",
            "stdio",
            "--scope",
            "user",
            server_name,
            "--",
            csg_command,
            "mcp",
        ],
        "codex": [
            "mcp",
            "add",
            server_name,
            "--",
            csg_command,
            "mcp",
        ],
    }

    for agent, args in command_args.items():
        executable = which(agent)
        if executable is None:
            results[agent] = {"status": "missing", "message": f"{agent} CLI not found on PATH"}
            continue
        command = [executable, *args]
        try:
            result = runner(command, capture_output=True, text=True, timeout=30)
        except (FileNotFoundError, OSError, subprocess.TimeoutExpired) as exc:
            results[agent] = {"status": "failed", "message": str(exc)}
            continue
        if getattr(result, "returncode", 0) == 0:
            results[agent] = {"status": "configured", "message": "MCP server registered"}
            continue
        stderr = str(getattr(result, "stderr", "") or "")
        stdout = str(getattr(result, "stdout", "") or "")
        output = f"{stdout}\n{stderr}".lower()
        if "already" in output or "exists" in output:
            results[agent] = {"status": "already-configured", "message": "MCP server already exists"}
        else:
            results[agent] = {
                "status": "failed",
                "message": (stderr or stdout or "MCP registration failed").strip(),
            }

    return results
