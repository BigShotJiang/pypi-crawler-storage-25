"""Generate repo-local instruction, skill, and hook files for CSG-aware agents."""

from __future__ import annotations

import json
from pathlib import Path
from textwrap import dedent

START_MARKER = "<!-- csg:start -->"
END_MARKER = "<!-- csg:end -->"


def install_agent_integration(repo_path: str | Path, repo_name: str | None = None) -> dict[str, list[str]]:
    """Install Codex and Claude Code integration files into a target repository.

    Existing user-authored instruction files are preserved. The generated CSG
    section is bounded by markers and replaced on subsequent runs.
    """
    root = Path(repo_path).resolve()
    root.mkdir(parents=True, exist_ok=True)
    name = repo_name or root.name

    created: list[str] = []
    updated: list[str] = []

    for rel_path, content in _integration_files(name).items():
        path = root / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and path.read_text(encoding="utf-8") == content:
            continue
        (updated if path.exists() else created).append(rel_path)
        path.write_text(content, encoding="utf-8")

    for rel_path, generated in {
        ".claude/settings.json": _claude_settings(),
        ".codex/hooks.json": _codex_hooks(),
    }.items():
        path = root / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        previous = _read_json_object(path)
        merged = _merge_hook_config(previous, generated)
        content = json.dumps(merged, indent=2) + "\n"
        if path.exists() and path.read_text(encoding="utf-8") == content:
            continue
        (updated if path.exists() else created).append(rel_path)
        path.write_text(content, encoding="utf-8")

    for rel_path, block in {
        "AGENTS.md": _instruction_block(name, "Codex"),
        "CLAUDE.md": _instruction_block(name, "Claude Code"),
    }.items():
        path = root / rel_path
        previous = path.read_text(encoding="utf-8") if path.exists() else ""
        next_text = _upsert_marker_block(previous, block)
        if previous == next_text:
            continue
        (updated if path.exists() else created).append(rel_path)
        path.write_text(next_text, encoding="utf-8")

    return {"created": created, "updated": updated}


def _upsert_marker_block(existing: str, block: str) -> str:
    block = f"{START_MARKER}\n{block.strip()}\n{END_MARKER}\n"
    if START_MARKER in existing and END_MARKER in existing:
        before, rest = existing.split(START_MARKER, 1)
        _, after = rest.split(END_MARKER, 1)
        return f"{before.rstrip()}\n\n{block}{after.lstrip()}"
    if existing.strip():
        return f"{existing.rstrip()}\n\n{block}"
    return block


def _read_json_object(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def _merge_hook_config(existing: dict, generated: dict) -> dict:
    merged = dict(existing)
    if "version" in generated and "version" not in merged:
        merged["version"] = generated["version"]

    hooks = dict(merged.get("hooks", {})) if isinstance(merged.get("hooks"), dict) else {}
    for event, generated_items in generated.get("hooks", {}).items():
        current = hooks.get(event, [])
        if not isinstance(current, list):
            current = []
        hooks[event] = _append_missing_hooks(current, generated_items)
    merged["hooks"] = hooks
    return merged


def _append_missing_hooks(current: list, generated: list) -> list:
    result = list(current)
    seen = {json.dumps(item, sort_keys=True) for item in result}
    for item in generated:
        key = json.dumps(item, sort_keys=True)
        if key not in seen:
            result.append(item)
            seen.add(key)
    return result


def _instruction_block(repo_name: str, platform: str) -> str:
    return dedent(
        f"""
        # CSG MCP Integration ({platform})

        This repository is intended to be used with the CSG MCP server. CSG
        builds a local code knowledge graph and exposes tools for exploration,
        impact analysis, change detection, graph-aware rename, and SRS support.

        ## First Steps

        - Use `csg_list_repos()` to discover indexed repositories.
        - Read `csg://repo/{repo_name}/context` before broad code exploration.
        - If the repo is not indexed or the index is stale, run `csg analyze`
          from the repository root, then restart the MCP client if needed.

        ## Always Do

        - Prefer `csg_explore(layer="topology")` for the project map before
          repo-wide grep or raw file scanning.
        - Use `csg_explore(layer="relevance", query="...")` to find relevant
          modules, flows, and symbols by concept.
        - Use `csg_context(symbol="...")` before changing a specific function,
          method, class, or interface.
        - Run `csg_impact(target="...", direction="upstream")` before editing
          any symbol with callers or cross-module dependencies.
        - Run `csg_detect_changes(scope="all")` before commit or handoff.
        - Use `csg_rename(symbol_name="old", new_name="new", dry_run=true)`
          before any symbol rename. Do not use blind find-and-replace.

        ## Risk Rules

        - HIGH or CRITICAL impact means report the blast radius before editing.
        - Depth 1 impact items are direct dependents and must be checked.
        - If CSG results are weak, ambiguous, or stale, verify with normal code
          reading before making changes.

        ## Useful Resources

        - `csg://repo/{repo_name}/context`: overview, staleness, available tools.
        - `csg://repo/{repo_name}/clusters`: functional areas.
        - `csg://repo/{repo_name}/processes`: execution flows.
        - `csg://repo/{repo_name}/schema`: graph schema and Cypher examples.
        """
    ).strip()


def _integration_files(repo_name: str) -> dict[str, str]:
    files: dict[str, str] = {}
    for platform_dir in (".codex", ".claude"):
        for skill_name, body in _skill_templates(repo_name).items():
            files[f"{platform_dir}/skills/csg/{skill_name}/SKILL.md"] = body

    files[".claude/hooks/csg-hook.py"] = _hook_script()
    return files


def _skill_templates(repo_name: str) -> dict[str, str]:
    return {
        "csg-cli": _skill(
            "csg-cli",
            "Use when indexing repositories, checking CSG status, starting MCP, or watching for changes.",
            f"""
            # CSG CLI

            Use these commands from the repository root:

            - `csg analyze`: build or refresh the graph index.
            - `csg analyze --force`: rebuild from scratch.
            - `csg analyze --embeddings`: include semantic embeddings.
            - `csg status`: show current repo index freshness and stats.
            - `csg list`: list indexed repositories.
            - `csg mcp`: start the stdio MCP server.
            - `csg watch`: watch indexed repos and re-ingest changed files.

            After indexing, read `csg://repo/{repo_name}/context` and use
            `csg_explore(layer="topology")` to verify the graph is usable.
            """,
        ),
        "csg-exploring": _skill(
            "csg-exploring",
            "Use when understanding architecture, finding implementations, or answering how code works.",
            """
            # CSG Exploring

            1. Start with `csg_list_repos()` if repo selection is unclear.
            2. Read `csg://repo/<name>/context` for staleness and stats.
            3. Use `csg_explore(layer="topology")` for communities.
            4. Use `csg_explore(layer="relevance", query="<concept>")` for search.
            5. Drill into a community with
               `csg_explore(layer="context", scope="community:<name>")`.
            6. Pull contracts or source with `layer="contract"` or
               `layer="implementation"` when symbol names are known.

            Prefer graph search first, then raw file reads for final verification.
            """,
        ),
        "csg-impact-analysis": _skill(
            "csg-impact-analysis",
            "Use before modifying a symbol, API, dependency edge, or shared module.",
            """
            # CSG Impact Analysis

            1. Identify the target symbol with `csg_context` or `csg_explore`.
            2. Run `csg_impact(target="<symbol>", direction="upstream")`.
            3. Treat direct dependents as must-check callers.
            4. Warn before editing if risk is HIGH or CRITICAL.
            5. After edits, run `csg_detect_changes(scope="all")`.

            Do not claim a low-risk change if the index is stale or the target
            symbol could not be resolved cleanly.
            """,
        ),
        "csg-refactoring": _skill(
            "csg-refactoring",
            "Use for rename, extract, split, move, or cross-file refactors.",
            """
            # CSG Refactoring

            - Rename: run `csg_rename(..., dry_run=true)` first, review
              definitions/usages/candidates, then apply only when unambiguous.
            - Extract or split: run `csg_context` and upstream `csg_impact`
              before moving code.
            - After refactor: run `csg_detect_changes(scope="all")` and verify
              direct callers from the impact report.

            Avoid blind text replacement for symbols represented in the graph.
            """,
        ),
        "csg-debugging": _skill(
            "csg-debugging",
            "Use when tracing a bug through callers, callees, processes, or architecture boundaries.",
            """
            # CSG Debugging

            1. Search the failure concept with `csg_explore(layer="relevance")`.
            2. Inspect likely symbols with `csg_context`.
            3. Read process traces from `csg://repo/<name>/processes` and
               `csg://repo/<name>/process/<process>`.
            4. Use `csg_impact` to find upstream callers that can trigger the bug.
            5. Confirm with source reads and tests.
            """,
        ),
        "csg-guide": _skill(
            "csg-guide",
            "Use when the agent needs the CSG tool, resource, and workflow reference.",
            """
            # CSG Guide

            Tools:

            - `csg_explore`: layered graph retrieval.
            - `csg_context`: 360-degree symbol view.
            - `csg_impact`: blast radius analysis.
            - `csg_detect_changes`: git diff to affected symbols/processes.
            - `csg_rename`: graph-aware rename.
            - `csg_analyze`: index repositories.
            - `csg_list_repos`: discover repositories.

            Resources:

            - `csg://repo/<name>/context`
            - `csg://repo/<name>/clusters`
            - `csg://repo/<name>/processes`
            - `csg://repo/<name>/process/<name>`
            - `csg://repo/<name>/schema`
            """,
        ),
    }


def _skill(name: str, description: str, body: str) -> str:
    return (
        "---\n"
        f"name: {name}\n"
        f"description: {description}\n"
        "---\n\n"
        f"{dedent(body).strip()}\n"
    )


def _claude_settings() -> dict:
    return {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Grep|Glob|Read|Bash",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "python .claude/hooks/csg-hook.py pre",
                        }
                    ],
                }
            ],
            "PostToolUse": [
                {
                    "matcher": "Edit|MultiEdit|Write|Bash",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "python .claude/hooks/csg-hook.py post",
                        }
                    ],
                }
            ],
        }
    }


def _codex_hooks() -> dict:
    return {
        "version": 1,
        "hooks": {
            "SessionStart": [
                {
                    "type": "command",
                    "command": "python .claude/hooks/csg-hook.py session",
                    "timeoutSec": 5,
                }
            ],
            "PreToolUse": [
                {
                    "type": "command",
                    "command": "python .claude/hooks/csg-hook.py pre",
                    "timeoutSec": 5,
                }
            ],
            "PostToolUse": [
                {
                    "type": "command",
                    "command": "python .claude/hooks/csg-hook.py post",
                    "timeoutSec": 5,
                }
            ],
        },
    }


def _hook_script() -> str:
    return dedent(
        r'''
        #!/usr/bin/env python
        """CSG agent hook.

        Reads a hook event from stdin and returns JSON with additional context.
        The hook only reminds the agent; it does not run indexing automatically.
        """

        from __future__ import annotations

        import json
        import subprocess
        import sys


        def has_index() -> bool:
            try:
                result = subprocess.run(
                    ["csg", "status"],
                    capture_output=True,
                    text=True,
                    timeout=3,
                )
            except Exception:
                return False
            return result.returncode == 0 and "No index found" not in result.stdout


        def main() -> None:
            mode = sys.argv[1] if len(sys.argv) > 1 else "pre"
            try:
                sys.stdin.read()
            except Exception:
                pass

            if not has_index():
                message = "CSG index not found. Run `csg analyze` before relying on graph context."
            elif mode == "post":
                message = (
                    "If code changed, run `csg_detect_changes(scope=\"all\")`. "
                    "After commits/merges or large edits, refresh with `csg analyze`."
                )
            else:
                message = (
                    "Use CSG MCP before broad search or edits: read csg://repo/<name>/context, "
                    "then use csg_explore/csg_context/csg_impact as appropriate."
                )

            print(json.dumps({"hookSpecificOutput": {"additionalContext": message}}))


        if __name__ == "__main__":
            main()
        '''
    ).lstrip()
