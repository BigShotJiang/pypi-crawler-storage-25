"""Use-cases for per-user settings and provider secrets."""

from __future__ import annotations

from typing import Any

from csg.application.ports.user_secrets_store_port import UserSecretsStorePort
from csg.application.ports.user_settings_store_port import UserSettingsStorePort
from csg.infrastructure.repository.user_settings_store import DEFAULT_USER_SETTINGS
from csg.infrastructure.security.secret_cipher import SecretCipher
from csg.infrastructure.runtime.user_context import (
    MISSING_OPENAI_API_KEY_MESSAGE,
    UserRuntimeSecrets,
    UserRuntimeSettings,
)

DEFAULT_SETTINGS_PAYLOAD = dict(DEFAULT_USER_SETTINGS)
ALLOWED_EMBEDDING_PROVIDERS = {"openai", "local"}
ALLOWED_OCR_PROVIDERS = {"openai", "gemini", "paddle"}
ALLOWED_LLM_PROVIDERS = {"openai"}


def get_user_settings(*, user_id: str, settings_store: UserSettingsStorePort) -> dict[str, Any]:
    """Load settings for a user, creating logical defaults when missing."""
    return settings_store.get_settings(user_id=user_id) or dict(DEFAULT_SETTINGS_PAYLOAD)


def update_user_settings(
    *,
    user_id: str,
    payload: dict[str, Any],
    settings_store: UserSettingsStorePort,
) -> dict[str, Any]:
    """Validate and persist user settings."""
    current = get_user_settings(user_id=user_id, settings_store=settings_store)
    merged = {
        **current,
        **payload,
    }

    default_branch = str(merged.get("default_branch") or "main").strip() or "main"
    max_file_size_kb = int(merged.get("max_file_size_kb") or DEFAULT_SETTINGS_PAYLOAD["max_file_size_kb"])
    embedding_provider = str(merged.get("embedding_provider") or "openai").strip().lower()
    ocr_provider = str(merged.get("ocr_provider") or "openai").strip().lower()
    llm_provider = str(merged.get("llm_provider") or "openai").strip().lower()

    if embedding_provider not in ALLOWED_EMBEDDING_PROVIDERS:
        raise ValueError("Unsupported embedding provider")
    if ocr_provider not in ALLOWED_OCR_PROVIDERS:
        raise ValueError("Unsupported OCR provider")
    if llm_provider not in ALLOWED_LLM_PROVIDERS:
        raise ValueError("Unsupported LLM provider")
    if max_file_size_kb < 1:
        raise ValueError("Max file size must be at least 1 KB")

    return settings_store.upsert_settings(
        user_id=user_id,
        settings={
            "default_branch": default_branch,
            "max_file_size_kb": max_file_size_kb,
            "embeddings_enabled": bool(merged.get("embeddings_enabled", True)),
            "embedding_provider": embedding_provider,
            "ocr_provider": ocr_provider,
            "llm_provider": llm_provider,
        },
    )


def get_secret_status(*, user_id: str, secrets_store: UserSecretsStorePort) -> dict[str, Any]:
    """Return whether the user has configured an OpenAI API key."""
    record = secrets_store.get_secret_record(user_id=user_id)
    configured = bool(record and record.get("openai_api_key_encrypted"))
    return {
        "openai_api_key_configured": configured,
        "updated_at": record.get("updated_at") if record else None,
        "important_reminder": None if configured else MISSING_OPENAI_API_KEY_MESSAGE,
    }


def set_openai_secret(
    *,
    user_id: str,
    api_key: str,
    secrets_store: UserSecretsStorePort,
    cipher: SecretCipher,
) -> dict[str, Any]:
    """Encrypt and persist a user's OpenAI API key."""
    value = api_key.strip()
    if not value:
        raise ValueError("OpenAI API key is required")
    secrets_store.upsert_secret_record(
        user_id=user_id,
        record={"openai_api_key_encrypted": cipher.encrypt(value)},
    )
    return get_secret_status(user_id=user_id, secrets_store=secrets_store)


def clear_openai_secret(*, user_id: str, secrets_store: UserSecretsStorePort) -> bool:
    """Remove a user's stored OpenAI API key."""
    return secrets_store.delete_secret_record(user_id=user_id)


def get_openai_secret(
    *,
    user_id: str,
    secrets_store: UserSecretsStorePort,
    cipher: SecretCipher,
) -> str:
    """Resolve a user's decrypted OpenAI API key."""
    record = secrets_store.get_secret_record(user_id=user_id)
    encrypted = str(record.get("openai_api_key_encrypted", "") if record else "")
    if not encrypted:
        return ""
    return cipher.decrypt(encrypted)


def build_runtime_settings(
    *,
    user_id: str,
    settings_store: UserSettingsStorePort,
) -> UserRuntimeSettings:
    """Map persisted settings into the runtime context model."""
    settings = get_user_settings(user_id=user_id, settings_store=settings_store)
    return UserRuntimeSettings(
        default_branch=str(settings.get("default_branch") or "main"),
        max_file_size_kb=int(settings.get("max_file_size_kb") or DEFAULT_SETTINGS_PAYLOAD["max_file_size_kb"]),
        embeddings_enabled=bool(settings.get("embeddings_enabled", True)),
        embedding_provider=str(settings.get("embedding_provider") or "openai"),
        ocr_provider=str(settings.get("ocr_provider") or "openai"),
        llm_provider=str(settings.get("llm_provider") or "openai"),
    )


def build_runtime_secrets(
    *,
    user_id: str,
    secrets_store: UserSecretsStorePort,
    cipher: SecretCipher,
) -> UserRuntimeSecrets:
    """Map persisted secrets into the runtime context model."""
    return UserRuntimeSecrets(
        openai_api_key=get_openai_secret(user_id=user_id, secrets_store=secrets_store, cipher=cipher),
    )
