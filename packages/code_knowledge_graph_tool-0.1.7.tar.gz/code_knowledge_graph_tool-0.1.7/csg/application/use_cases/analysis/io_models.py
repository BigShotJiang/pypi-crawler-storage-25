"""Application boundary IO models for analysis use-cases."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, TypeAlias


JobId: TypeAlias = str
RunHandle: TypeAlias = str


@dataclass(frozen=True)
class AnalyzeRepositoryRequest:
    """Use-case input model for starting an analysis job."""

    source_ref: str
    source_kind: str
    branch: str | None = None
    options: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AnalyzeRepositoryResponse:
    """Use-case output model for a started analysis job."""

    job_id: JobId
    run_handle: RunHandle | None
    status: str
    message: str = ""


@dataclass(frozen=True)
class CancelAnalysisJobRequest:
    """Use-case input model for cancelling an analysis job."""

    job_id: JobId


@dataclass(frozen=True)
class CancelAnalysisJobResponse:
    """Use-case output model for cancellation requests."""

    job_id: JobId
    cancelled: bool
    status: str


@dataclass(frozen=True)
class GetAnalysisStatusRequest:
    """Use-case input model for querying analysis status."""

    job_id: JobId


@dataclass(frozen=True)
class GetAnalysisStatusResponse:
    """Use-case output model for analysis status."""

    job_id: JobId
    run_handle: RunHandle | None
    status: str
    progress: Mapping[str, Any] = field(default_factory=dict)
    result: Mapping[str, Any] | None = None
    error: str | None = None


@dataclass(frozen=True)
class RunPipelineRequest:
    """Application command for a full analysis run."""

    repo_path: str
    force: bool = False
    embeddings: bool = False
    exclude_dirs: frozenset[str] = frozenset()
    incremental: bool = True
    cache_dir: str = ""
    embedding_model: str = "text-embedding-3-small"
    embedding_device: str = "auto"
    embedding_batch_size: int = 32
    cancel_event: Any | None = None


@dataclass(frozen=True)
class RunAnalysisPipelineRequest:
    """Application command for the core analysis pipeline."""

    repo_path: str
    cancel_event: Any | None = None


@dataclass(frozen=True)
class RunIncrementalPipelineRequest:
    """Application command for incremental analysis."""

    repo_path: str
