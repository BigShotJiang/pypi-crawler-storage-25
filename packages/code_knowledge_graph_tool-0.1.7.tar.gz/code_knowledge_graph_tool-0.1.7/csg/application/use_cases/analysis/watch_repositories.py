"""Application use-cases for watcher lifecycle."""

from __future__ import annotations

from typing import Any, Callable


def get_repo_watcher(
    interval: int | None = None,
    debounce: float | None = None,
    *,
    watcher_factory: Callable[[int | None, float | None], Any],
) -> Any:
    """Get repository watcher from infrastructure analysis module."""
    return watcher_factory(interval, debounce)
