"""Graph result serialization and cache helpers."""

from __future__ import annotations

import json
import logging
import math
import random
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)


NODE_COLORS = {
    "Project": "#c084fc",
    "Package": "#818cf8",
    "Module": "#67e8f9",
    "Folder": "#6366f1",
    "File": "#38bdf8",
    "Class": "#fbbf24",
    "Function": "#34d399",
    "Method": "#2dd4bf",
    "Interface": "#f472b6",
    "Enum": "#fb923c",
    "Type": "#a78bfa",
    "Variable": "#94a3b8",
    "Import": "#64748b",
    "Decorator": "#facc15",
    "Community": "#818cf8",
    "Process": "#fb7185",
}

NODE_SIZES = {
    "Project": 12,
    "Package": 10,
    "Module": 8,
    "Folder": 7,
    "File": 5,
    "Class": 8,
    "Function": 5,
    "Method": 4,
    "Interface": 7,
    "Enum": 6,
    "Type": 5,
    "Variable": 3,
    "Import": 2,
    "Decorator": 4,
    "Community": 10,
    "Process": 9,
}

EDGE_COLORS = {
    "CONTAINS": "#4ade80",
    "DEFINES": "#22d3ee",
    "IMPORTS": "#60a5fa",
    "CALLS": "#a78bfa",
    "EXTENDS": "#f97316",
    "IMPLEMENTS": "#ec4899",
    "HAS_METHOD": "#14b8a6",
    "HAS_PROPERTY": "#14b8a6",
    "MEMBER_OF": "#818cf8",
    "STEP_IN_PROCESS": "#fb7185",
    "OVERRIDES": "#eab308",
    "INHERITS": "#f97316",
    "USES": "#94a3b8",
    "ACCESSES": "#94a3b8",
    "DECORATES": "#facc15",
}

SKIP_LABELS = {"Import", "Variable"}
_CONTENT_LABELS = {
    "Function",
    "Class",
    "Method",
    "Interface",
    "Section",
    "Struct",
    "Enum",
    "Trait",
    "Constructor",
}
_ISSUE_FUNCTION_LABELS = {"Function", "Method", "Constructor"}
_DEPENDENCY_EDGE_TYPES = {"IMPORTS", "USES"}
_COMMON_FUNCTION_NAMES = {
    "render",
    "init",
    "test",
    "setup",
    "teardown",
    "main",
    "index",
    "handler",
    "constructor",
    "__init__",
}
_LAYER_ORDER = {
    "config": 0,
    "utils": 1,
    "data": 2,
    "services": 3,
    "api": 4,
    "ui": 5,
}


def serialize_results(state: dict[str, Any]) -> dict[str, Any]:
    """Convert final pipeline state into a JSON-serializable summary."""
    graph: Any = state.get("knowledge_graph")
    if graph is None:
        return {"error": "No analysis results"}

    by_label: dict[str, list[dict[str, Any]]] = {}
    for node in graph.iter_nodes():
        label = node.label.value if hasattr(node.label, "value") else str(node.label)
        by_label.setdefault(label, []).append(_serialize_node(node))

    by_type: dict[str, int] = {}
    for rel in graph.iter_relationships():
        key = rel.type.value if hasattr(rel.type, "value") else str(rel.type)
        by_type[key] = by_type.get(key, 0) + 1

    file_count = len(state.get("file_paths", []))
    total_lines = 0
    for node in graph.iter_nodes():
        label = node.label.value if hasattr(node.label, "value") else str(node.label)
        if label == "File":
            line_count = node.properties.get("lineCount") or node.properties.get("line_count") or 0
            total_lines += int(line_count) if line_count else 0

    communities = state.get("community_nodes", [])
    processes = state.get("process_nodes", [])
    memberships = state.get("memberships", [])
    node_to_community: dict[str, str] = {}
    community_members_map: dict[str, list[str]] = {}
    for membership in memberships:
        node_to_community[membership.node_id] = membership.community_id
        community_members_map.setdefault(membership.community_id, []).append(membership.node_id)

    return {
        "summary": {
            "files": file_count,
            "total_lines": total_lines,
            "total_nodes": graph.node_count,
            "total_relationships": graph.relationship_count,
            "communities": len(communities),
            "processes": len(processes),
        },
        "nodes_by_label": {key: len(value) for key, value in by_label.items()},
        "relationships_by_type": by_type,
        "communities": [
            {
                "id": community.id,
                "label": community.label,
                "heuristic_label": community.heuristic_label,
                "cohesion": round(community.cohesion, 3),
                "symbol_count": community.symbol_count,
            }
            for community in communities
        ],
        "processes": [
            {
                "id": process.id,
                "label": process.label,
                "heuristic_label": process.heuristic_label,
                "process_type": process.process_type,
                "step_count": process.step_count,
            }
            for process in processes
        ],
        "symbols": _top_symbols(by_label),
        "graph": _build_graph_data(
            list(graph.iter_nodes()),
            list(graph.iter_relationships()),
            node_to_community,
        ),
        "file_tree": _build_file_tree(state.get("file_paths", [])),
        "community_members": community_members_map,
        "issues": _build_issues(
            list(graph.iter_nodes()),
            list(graph.iter_relationships()),
        ),
    }


def _build_issues(nodes: list[Any], rels: list[Any]) -> list[dict[str, Any]]:
    node_by_id = {node.id: node for node in nodes}
    issues: list[dict[str, Any]] = []

    function_nodes = [node for node in nodes if _node_label(node) in _ISSUE_FUNCTION_LABELS]
    file_nodes = [node for node in nodes if _node_label(node) == "File"]
    incoming_calls = {rel.target_id for rel in rels if _relationship_type(rel) == "CALLS"}

    for node in function_nodes:
        name = _node_name(node)
        if node.id in incoming_calls or _is_likely_entry_point(node):
            continue
        issues.append(
            _issue(
                "Unused Functions",
                "warning",
                f"Unused function: {name}",
                "No incoming CALLS edge was found for this function.",
                file_path=_node_file_path(node),
                node_ids=[node.id],
            )
        )

    function_count_by_file: dict[str, list[Any]] = defaultdict(list)
    for node in function_nodes:
        file_path = _node_file_path(node)
        if file_path:
            function_count_by_file[file_path].append(node)
    for file_path, file_functions in sorted(function_count_by_file.items()):
        count = len(file_functions)
        if count > 15:
            issues.append(
                _issue(
                    "Large Files",
                    "warning",
                    f"Large file: {file_path}",
                    f"This file defines {count} function-like symbols.",
                    file_path=file_path,
                    node_ids=[node.id for node in file_functions[:20]],
                    metadata={"functionCount": count, "threshold": 15},
                )
            )

    import_sources_by_target: dict[str, set[str]] = defaultdict(set)
    dependency_pairs: set[tuple[str, str]] = set()
    for rel in rels:
        rel_type = _relationship_type(rel)
        if rel_type not in _DEPENDENCY_EDGE_TYPES:
            continue
        source_path = _relationship_file_path(rel.source_id, node_by_id)
        target_path = _relationship_file_path(rel.target_id, node_by_id)
        if not source_path or not target_path or source_path == target_path:
            continue
        import_sources_by_target[target_path].add(source_path)
        dependency_pairs.add((source_path, target_path))

    for target_path, source_paths in sorted(import_sources_by_target.items()):
        count = len(source_paths)
        if count > 8:
            issues.append(
                _issue(
                    "Highly Coupled",
                    "warning",
                    f"Highly coupled file: {target_path}",
                    f"This file is imported by {count} distinct files.",
                    file_path=target_path,
                    metadata={"incomingImports": count, "threshold": 8},
                )
            )

    seen_cycles: set[tuple[str, str]] = set()
    for source_path, target_path in sorted(dependency_pairs):
        if (target_path, source_path) not in dependency_pairs:
            continue
        cycle_key = tuple(sorted((source_path, target_path)))
        if cycle_key in seen_cycles:
            continue
        seen_cycles.add(cycle_key)
        issues.append(
            _issue(
                "Circular Dependencies",
                "critical",
                f"Direct circular dependency: {cycle_key[0]} <-> {cycle_key[1]}",
                "Both files depend on each other through dependency edges.",
                file_path=cycle_key[0],
                metadata={"files": list(cycle_key)},
            )
        )

    functions_by_name: dict[str, list[Any]] = defaultdict(list)
    for node in function_nodes:
        name = _node_name(node)
        if name and not _is_generic_function_name(name):
            functions_by_name[name].append(node)
    for name, matches in sorted(functions_by_name.items()):
        files = sorted({_node_file_path(node) for node in matches if _node_file_path(node)})
        if len(files) < 3:
            continue
        fingerprints = {_normalized_code_fingerprint(_node_content(node)) for node in matches}
        fingerprints.discard("")
        if fingerprints and len(fingerprints) > 1:
            continue
        issues.append(
            _issue(
                "Duplicate Function Names",
                "info",
                f"Duplicate function name: {name}",
                f"The same non-generic function name appears in {len(files)} files.",
                file_path=files[0] if files else None,
                node_ids=[node.id for node in matches],
                metadata={"files": files, "count": len(matches)},
            )
        )

    functions_by_fingerprint: dict[str, list[Any]] = defaultdict(list)
    for node in function_nodes:
        fingerprint = _normalized_code_fingerprint(_node_content(node))
        if fingerprint:
            functions_by_fingerprint[fingerprint].append(node)
    for matches in functions_by_fingerprint.values():
        files = sorted({_node_file_path(node) for node in matches if _node_file_path(node)})
        names = sorted({_node_name(node) for node in matches if _node_name(node)})
        if len(files) < 2 or len(names) < 2:
            continue
        issues.append(
            _issue(
                "Similar Code Blocks",
                "info",
                f"Similar code block: {', '.join(names[:3])}",
                f"Identical normalized function bodies appear in {len(files)} files.",
                file_path=files[0],
                node_ids=[node.id for node in matches],
                metadata={"files": files, "count": len(matches)},
            )
        )

    for source_path, target_path in sorted(dependency_pairs):
        source_layer = _infer_layer(source_path)
        target_layer = _infer_layer(target_path)
        if source_layer is None or target_layer is None:
            continue
        source_rank = _LAYER_ORDER[source_layer]
        target_rank = _LAYER_ORDER[target_layer]
        if target_rank - source_rank >= 2:
            issues.append(
                _issue(
                    "Architecture Violations",
                    "warning",
                    f"{source_layer} imports {target_layer}",
                    "A lower-level layer imports a higher-level layer.",
                    file_path=source_path,
                    metadata={
                        "source": source_path,
                        "target": target_path,
                        "sourceLayer": source_layer,
                        "targetLayer": target_layer,
                    },
                )
            )

    for node in file_nodes:
        content = _node_content(node)
        score = _complexity_score(content)
        if score > 30:
            issues.append(
                _issue(
                    "High Complexity Files",
                    "warning",
                    f"High complexity file: {_node_file_path(node)}",
                    f"Heuristic complexity score is {score}.",
                    file_path=_node_file_path(node),
                    node_ids=[node.id],
                    metadata={"score": score, "threshold": 30},
                )
            )

    return issues


def _issue(
    category: str,
    severity: str,
    title: str,
    message: str,
    *,
    file_path: str | None = None,
    node_ids: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    raw_id = f"{category}:{file_path or title}:{','.join(node_ids or [])}"
    issue_id = re.sub(r"[^a-zA-Z0-9_.:-]+", "-", raw_id).strip("-").lower()
    return {
        "id": issue_id,
        "category": category,
        "severity": severity,
        "title": title,
        "message": message,
        "filePath": file_path,
        "nodeIds": node_ids or [],
        "metadata": metadata or {},
    }


def _node_label(node: Any) -> str:
    return node.label.value if hasattr(node.label, "value") else str(node.label)


def _node_name(node: Any) -> str:
    return str(_prop(node.properties, "name") or "")


def _node_file_path(node: Any) -> str:
    return str(_prop(node.properties, "file_path", "filePath") or "")


def _node_content(node: Any) -> str:
    return str(_prop(node.properties, "content") or "")


def _relationship_type(rel: Any) -> str:
    return rel.type.value if hasattr(rel.type, "value") else str(rel.type)


def _relationship_file_path(node_id: str, node_by_id: dict[str, Any]) -> str:
    node = node_by_id.get(node_id)
    if not node:
        return ""
    return _node_file_path(node)


def _is_likely_entry_point(node: Any) -> bool:
    name = _node_name(node)
    lower = name.lower()
    if _prop(node.properties, "is_exported", "isExported"):
        return True
    return (
        lower in _COMMON_FUNCTION_NAMES
        or lower.startswith("test_")
        or lower.startswith("pytest_")
        or lower.startswith("__")
        or lower in {"upgrade", "downgrade", "run", "handle", "loader"}
    )


def _is_generic_function_name(name: str) -> bool:
    lower = name.lower()
    return lower in _COMMON_FUNCTION_NAMES or lower.startswith("test_") or lower.startswith("__")


def _normalized_code_fingerprint(content: str) -> str:
    if len(content.strip()) < 24:
        return ""
    normalized = re.sub(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", "id", content)
    normalized = re.sub(r"\b\d+\b", "num", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized if len(normalized) >= 24 else ""


def _infer_layer(file_path: str) -> str | None:
    normalized = file_path.replace("\\", "/").lower()
    parts = set(normalized.split("/"))
    for layer in ("ui", "api", "services", "data", "utils", "config"):
        if layer in parts:
            return layer
    return None


def _complexity_score(content: str) -> int:
    if not content:
        return 0
    score = 0
    for pattern in (r"\bif\b", r"\bfor\b", r"\bwhile\b", r"\bcatch\b", r"\bexcept\b", r"\bcase\b"):
        score += len(re.findall(pattern, content))
    score += content.count("&&")
    score += content.count("||")
    return score


def save_graph_json(
    repo_path: str,
    results: dict[str, Any],
    *,
    storage_path_resolver: Callable[[str], Path],
) -> str:
    """Persist serialized graph results as graph.json."""
    storage = storage_path_resolver(repo_path)
    storage.mkdir(parents=True, exist_ok=True)
    path = storage / "graph.json"
    tmp_path = path.with_suffix(".json.tmp")
    tmp_path.write_text(json.dumps(results, default=str), encoding="utf-8")
    tmp_path.replace(path)
    logger.debug("Saved graph JSON to %s", path)
    return str(path)


def load_graph_json(
    repo_path: str,
    *,
    storage_path_resolver: Callable[[str], Path],
) -> dict[str, Any] | None:
    """Load cached graph results from graph.json."""
    path = storage_path_resolver(repo_path) / "graph.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _build_graph_data(
    nodes: list[Any],
    rels: list[Any],
    node_to_community: dict[str, str] | None = None,
) -> dict[str, Any]:
    viz_nodes = []
    node_ids = set()

    for node in nodes:
        label = node.label.value if hasattr(node.label, "value") else str(node.label)
        if label in SKIP_LABELS:
            continue

        name = node.properties.get("name", "")
        file_path = node.properties.get("file_path", "")
        angle = random.random() * 2 * math.pi
        radius = random.random() * 100
        start_line = _prop(node.properties, "start_line", "startLine")
        end_line = _prop(node.properties, "end_line", "endLine")

        node_dict = {
            "id": node.id,
            "label": name or label,
            "x": math.cos(angle) * radius,
            "y": math.sin(angle) * radius,
            "size": NODE_SIZES.get(label, 4),
            "color": NODE_COLORS.get(label, "#64748b"),
            "nodeType": label,
            "filePath": file_path,
            "startLine": start_line,
            "endLine": end_line,
            "communityId": (node_to_community or {}).get(node.id),
        }

        if label in _CONTENT_LABELS:
            content = node.properties.get("content", "")
            if content:
                max_content = 500
                node_dict["content"] = content[:max_content] + ("..." if len(content) > max_content else "")

        viz_nodes.append(node_dict)
        node_ids.add(node.id)

    viz_edges = []
    for rel in rels:
        if rel.source_id not in node_ids or rel.target_id not in node_ids:
            continue
        rel_type = rel.type.value if hasattr(rel.type, "value") else str(rel.type)
        viz_edges.append(
            {
                "id": rel.id,
                "source": rel.source_id,
                "target": rel.target_id,
                "color": EDGE_COLORS.get(rel_type, "#475569"),
                "type": rel_type,
                "size": 0.5,
                "reviewLabel": rel.review_label,
            }
        )

    return {"nodes": viz_nodes, "edges": viz_edges}


def _serialize_node(node: Any) -> dict[str, Any]:
    label = node.label.value if hasattr(node.label, "value") else str(node.label)
    if hasattr(node.properties, "get"):
        name = node.properties.get("name", "")
        file_path = node.properties.get("filePath", "") or node.properties.get("file_path", "")
        kind = node.properties.get("kind", "")
    elif isinstance(node.properties, dict):
        name = node.properties.get("name", "")
        file_path = node.properties.get("filePath", "") or node.properties.get("file_path", "")
        kind = node.properties.get("kind", "")
    else:
        name = getattr(node.properties, "name", "")
        file_path = getattr(node.properties, "file_path", "")
        kind = ""

    return {
        "id": node.id,
        "label": label,
        "name": name,
        "filePath": file_path,
        "kind": kind,
    }


def _prop(props: Any, *keys: str) -> Any:
    for key in keys:
        value = props.get(key)
        if value is not None:
            return value
    return None


def _top_symbols(by_label: dict[str, list[dict[str, Any]]], limit: int = 50) -> list[dict[str, Any]]:
    result = []
    for label in ("Class", "Function", "Method", "Interface"):
        items = by_label.get(label, [])
        result.extend(items[:limit])
    return result[:limit]


def _build_file_tree(file_paths: list[str]) -> list[dict[str, Any]]:
    root: dict[str, Any] = {}
    for file_path in sorted(file_paths):
        parts = file_path.replace("\\", "/").split("/")
        node = root
        for part in parts:
            node = node.setdefault(part, {})

    def to_list(tree: dict[str, Any], prefix: str = "") -> list[dict[str, Any]]:
        items = []
        entries = sorted(tree.keys(), key=lambda key: (0 if tree[key] else 1, key.lower()))
        for name in entries:
            children = tree[name]
            path = f"{prefix}/{name}" if prefix else name
            if children:
                items.append(
                    {
                        "name": name,
                        "path": path,
                        "type": "folder",
                        "children": to_list(children, path),
                    }
                )
            else:
                items.append({"name": name, "path": path, "type": "file"})
        return items

    return to_list(root)
