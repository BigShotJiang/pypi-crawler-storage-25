"""Analysis execution use-cases."""

from __future__ import annotations

from typing import Callable

from csg.application.use_cases.analysis.io_models import (
    RunAnalysisPipelineRequest,
    RunIncrementalPipelineRequest,
    RunPipelineRequest,
)


def run_pipeline_sync(config: RunPipelineRequest, *, runner: Callable[[RunPipelineRequest], dict]) -> dict:
    """Run ingestion pipeline synchronously."""
    return runner(config)


def run_analysis_pipeline_sync(
    repo_path: str | RunAnalysisPipelineRequest,
    *,
    runner: Callable[..., dict],
    cancel_event=None,
) -> dict:
    """Run core analysis pipeline synchronously and return final state."""
    if isinstance(repo_path, RunAnalysisPipelineRequest):
        request = repo_path
    else:
        request = RunAnalysisPipelineRequest(repo_path=repo_path, cancel_event=cancel_event)
    return runner(request.repo_path, cancel_event=request.cancel_event)


def run_incremental_pipeline_sync(
    repo_path: str | RunIncrementalPipelineRequest,
    *,
    runner: Callable[[str], dict],
) -> dict:
    """Run incremental ingestion pipeline synchronously."""
    request = repo_path if isinstance(repo_path, RunIncrementalPipelineRequest) else RunIncrementalPipelineRequest(repo_path=repo_path)
    return runner(request.repo_path)
