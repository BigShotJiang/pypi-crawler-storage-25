"""Source-related use-case entrypoints."""

from csg.application.use_cases.sources.is_binary_source import is_binary_source_path
from csg.application.use_cases.sources.process_documents import process_documents_sync

__all__ = ["is_binary_source_path", "process_documents_sync"]
