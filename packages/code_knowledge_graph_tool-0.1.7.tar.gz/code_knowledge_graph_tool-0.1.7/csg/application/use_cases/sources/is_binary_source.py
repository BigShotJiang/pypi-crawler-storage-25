"""Application use-case for source file binary detection."""

from __future__ import annotations

from typing import Callable


def is_binary_source_path(path: str, *, checker: Callable[[str], bool]) -> bool:
    """Return True when source path is binary."""
    return checker(path)
