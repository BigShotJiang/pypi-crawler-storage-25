"""Document ingestion use-cases."""

from __future__ import annotations

from typing import Any, Callable


def process_documents_sync(
    *,
    doc_paths: list[str],
    repo_path: str,
    docs_adapter: Any,
    processor: Callable[..., Any],
) -> Any:
    """Process document files into docs graph."""
    return processor(
        doc_paths=doc_paths,
        repo_path=repo_path,
        docs_adapter=docs_adapter,
    )
