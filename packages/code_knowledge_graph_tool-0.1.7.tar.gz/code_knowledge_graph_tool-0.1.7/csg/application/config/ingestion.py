"""Ingestion limits and document support configuration - business rules."""

# File size limits (bytes)
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100 MB
MAX_CONTENT_SIZE = 10 * 1024 * 1024  # 10 MB
MAX_DOCUMENT_FILE_SIZE = 50 * 1024 * 1024  # 50 MB
MAX_DOCUMENT_PAGES = 100
MAX_DOCUMENT_SECTION_CONTENT = 10 * 1024 * 1024  # 10 MB

# Supported document extensions (non-code files)
DOCUMENT_EXTENSIONS = {
    ".pdf",
    ".docx",
    ".doc",
    ".xlsx",
    ".xls",
    ".pptx",
    ".ppt",
    ".md",
    ".mdx",
    ".txt",
    ".rtf",
    ".html",
    ".htm",
}
