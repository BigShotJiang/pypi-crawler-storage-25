"""Language configuration - business rules about supported languages.

This module contains domain/business configuration for language support.
Infrastructure concerns (paths, data dirs) live in infrastructure.config.paths.
"""

from __future__ import annotations

import os
from enum import StrEnum
from pathlib import Path

# Resolve CSG project root
_PACKAGE_DIR = Path(__file__).resolve().parent.parent.parent  # csg/
PROJECT_ROOT = _PACKAGE_DIR.parent  # CSG/


class SupportedLanguages(StrEnum):
    """All supported languages."""

    # ── Original 14 ──────────────────────────────────────────────────
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    PYTHON = "python"
    JAVA = "java"
    C = "c"
    C_PLUS_PLUS = "cpp"
    C_SHARP = "c_sharp"
    GO = "go"
    RUBY = "ruby"
    RUST = "rust"
    PHP = "php"
    KOTLIN = "kotlin"
    SWIFT = "swift"
    VB6 = "vb6"

    # ── Tier 1: Native PyPI tree-sitter packages ─────────────────────
    FORTRAN = "fortran"
    SCALA = "scala"
    OBJECTIVE_C = "objective_c"
    SOLIDITY = "solidity"
    MATLAB = "matlab"
    COMMON_LISP = "common_lisp"
    DELPHI = "delphi"
    ADA = "ada"

    # ── Tier 2: WASM bridge (npm grammars) ───────────────────────────
    PERL = "perl"
    COBOL = "cobol"
    ERLANG = "erlang"
    APEX = "apex"
    PASCAL = "pascal"
    PROLOG = "prolog"

    # ── Tier 3: Regex parser (no grammar) ────────────────────────────
    RPG = "rpg"
    ABAP = "abap"
    MUMPS = "mumps"
    ASSEMBLY = "assembly"
    TCL = "tcl"
    ALGOL = "algol"
    FORTH = "forth"
    POSTSCRIPT = "postscript"


EXTENSION_MAP: dict[str, SupportedLanguages] = {
    # ── Original 14 ──────────────────────────────────────────────────
    ".js": SupportedLanguages.JAVASCRIPT,
    ".jsx": SupportedLanguages.JAVASCRIPT,
    ".mjs": SupportedLanguages.JAVASCRIPT,
    ".cjs": SupportedLanguages.JAVASCRIPT,
    ".ts": SupportedLanguages.TYPESCRIPT,
    ".tsx": SupportedLanguages.TYPESCRIPT,
    ".mts": SupportedLanguages.TYPESCRIPT,
    ".cts": SupportedLanguages.TYPESCRIPT,
    ".py": SupportedLanguages.PYTHON,
    ".pyi": SupportedLanguages.PYTHON,
    ".java": SupportedLanguages.JAVA,
    ".c": SupportedLanguages.C,
    ".h": SupportedLanguages.C,
    ".cpp": SupportedLanguages.C_PLUS_PLUS,
    ".cxx": SupportedLanguages.C_PLUS_PLUS,
    ".cc": SupportedLanguages.C_PLUS_PLUS,
    ".hpp": SupportedLanguages.C_PLUS_PLUS,
    ".hxx": SupportedLanguages.C_PLUS_PLUS,
    ".hh": SupportedLanguages.C_PLUS_PLUS,
    ".cs": SupportedLanguages.C_SHARP,
    ".go": SupportedLanguages.GO,
    ".rb": SupportedLanguages.RUBY,
    ".rs": SupportedLanguages.RUST,
    ".php": SupportedLanguages.PHP,
    ".kt": SupportedLanguages.KOTLIN,
    ".kts": SupportedLanguages.KOTLIN,
    ".swift": SupportedLanguages.SWIFT,
    ".vb": SupportedLanguages.VB6,
    ".bas": SupportedLanguages.VB6,
    # ── Tier 1 ───────────────────────────────────────────────────────
    ".f90": SupportedLanguages.FORTRAN,
    ".f95": SupportedLanguages.FORTRAN,
    ".f03": SupportedLanguages.FORTRAN,
    ".scala": SupportedLanguages.SCALA,
    ".m": SupportedLanguages.OBJECTIVE_C,
    ".sol": SupportedLanguages.SOLIDITY,
    ".mat": SupportedLanguages.MATLAB,
    ".lisp": SupportedLanguages.COMMON_LISP,
    ".lsp": SupportedLanguages.COMMON_LISP,
    ".pas": SupportedLanguages.PASCAL,
    ".pro": SupportedLanguages.PROLOG,
    # ── Tier 2 ───────────────────────────────────────────────────────
    ".pl": SupportedLanguages.PERL,
    ".cbl": SupportedLanguages.COBOL,
    ".erl": SupportedLanguages.ERLANG,
    ".cls": SupportedLanguages.APEX,
    # ── Tier 3 ───────────────────────────────────────────────────────
    ".rpg": SupportedLanguages.RPG,
    ".abap": SupportedLanguages.ABAP,
    ".mps": SupportedLanguages.MUMPS,
    ".s": SupportedLanguages.ASSEMBLY,
    ".asm": SupportedLanguages.ASSEMBLY,
    ".tcl": SupportedLanguages.TCL,
    ".alg": SupportedLanguages.ALGOL,
    ".fs": SupportedLanguages.FORTH,
    ".ps": SupportedLanguages.POSTSCRIPT,
}

# Language families for heuristics
SCRIPT_LANGUAGES = {SupportedLanguages.JAVASCRIPT, SupportedLanguages.TYPESCRIPT, SupportedLanguages.PYTHON}
COMPILED_LANGUAGES = {
    SupportedLanguages.JAVA,
    SupportedLanguages.C,
    SupportedLanguages.C_PLUS_PLUS,
    SupportedLanguages.GO,
    SupportedLanguages.RUST,
    SupportedLanguages.SWIFT,
    SupportedLanguages.KOTLIN,
}
VM_LANGUAGES = {SupportedLanguages.JAVA, SupportedLanguages.C_SHARP, SupportedLanguages.RUBY}


def get_language_from_filename(filename: str, *, content_head: bytes | str | None = None) -> SupportedLanguages | None:
    """Detect language from file extension and optional content heuristics."""
    path = Path(filename)
    ext = path.suffix.lower()

    if ext in EXTENSION_MAP:
        return EXTENSION_MAP[ext]

    # Special cases
    name = path.stem.lower()
    if name == "makefile" or name.endswith("mk"):
        return None  # No tree-sitter grammar

    return None


def get_language_from_extension(ext: str) -> SupportedLanguages | None:
    """Get language from file extension."""
    return EXTENSION_MAP.get(ext.lower())


def is_supported_extension(ext: str) -> bool:
    """Check if extension is supported."""
    return ext.lower() in EXTENSION_MAP


# Built-in names that are not user-defined symbols
BUILT_IN_NAMES = {
    # Python
    "self",
    "cls",
    "True",
    "False",
    "None",
    "print",
    "len",
    "range",
    "dict",
    "list",
    "set",
    "tuple",
    "int",
    "float",
    "str",
    "bool",
    # JavaScript/TypeScript
    "console",
    "log",
    "window",
    "document",
    "require",
    "module",
    "exports",
    # Java
    "System",
    "out",
    "println",
    "String",
    "Integer",
    "Boolean",
    # General
    "printf",
    "scanf",
    "cout",
    "cin",
}
