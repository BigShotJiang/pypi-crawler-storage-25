"""Application configuration package."""

from .language import SupportedLanguages, get_language_from_filename, BUILT_IN_NAMES
from .ingestion import (
    MAX_FILE_SIZE,
    MAX_CONTENT_SIZE,
    MAX_DOCUMENT_FILE_SIZE,
    MAX_DOCUMENT_PAGES,
    MAX_DOCUMENT_SECTION_CONTENT,
    DOCUMENT_EXTENSIONS,
)

__all__ = [
    "SupportedLanguages",
    "get_language_from_filename",
    "BUILT_IN_NAMES",
    "MAX_FILE_SIZE",
    "MAX_CONTENT_SIZE",
    "MAX_DOCUMENT_FILE_SIZE",
    "MAX_DOCUMENT_PAGES",
    "MAX_DOCUMENT_SECTION_CONTENT",
    "DOCUMENT_EXTENSIONS",
]
