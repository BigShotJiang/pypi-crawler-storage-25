"""Application port for per-user provider secret persistence."""

from __future__ import annotations

from typing import Any, Protocol


class UserSecretsStorePort(Protocol):
    """Contract for reading and writing encrypted user secrets."""

    def get_secret_record(self, *, user_id: str) -> dict[str, Any] | None:
        """Return the stored secret payload for a user, if configured."""

    def upsert_secret_record(self, *, user_id: str, record: dict[str, Any]) -> dict[str, Any]:
        """Create or replace the stored secret payload for a user."""

    def delete_secret_record(self, *, user_id: str) -> bool:
        """Delete the stored secret payload for a user."""
