"""Application port for search capabilities."""

from __future__ import annotations

from typing import Any, Mapping, Protocol, Sequence


class SearchGatewayPort(Protocol):
    """Contract for search outbound adapters."""

    def search(self, query: str, *, limit: int = 10) -> Sequence[Mapping[str, Any]]:
        """Run search and return ranked results."""

