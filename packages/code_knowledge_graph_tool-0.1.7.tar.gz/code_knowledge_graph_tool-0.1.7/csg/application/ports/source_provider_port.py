"""Application port for preparing and cleaning analysis sources."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class SourceProviderPort(Protocol):
    """Contract for normalizing different source inputs into local repos."""

    def prepare(self, source_ref: str, *, kind: str, branch: str | None = None) -> Mapping[str, Any]:
        """Prepare source and return normalized source metadata."""

    def cleanup(self, prepared_source: Mapping[str, Any]) -> None:
        """Clean up any temporary source artifacts."""

    def is_binary_path(self, path: str) -> bool:
        """Return True when a source path is binary."""

    def process_documents(self, *, doc_paths: list[str], repo_path: str, docs_adapter: Any) -> Any:
        """Process documents into the docs graph."""

