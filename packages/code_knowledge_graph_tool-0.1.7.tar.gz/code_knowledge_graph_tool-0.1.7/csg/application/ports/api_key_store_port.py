"""Application port for API key persistence."""

from __future__ import annotations

from typing import Any, Protocol


class ApiKeyStorePort(Protocol):
    """Contract for listing, creating, and deleting API keys."""

    def list_keys(self, *, owner_user_id: str) -> list[dict[str, Any]]:
        """Return all stored API keys."""

    def create_key(self, description: str, *, owner_user_id: str) -> dict[str, Any]:
        """Create and persist a new API key."""

    def delete_key(self, key_id: str, *, owner_user_id: str) -> bool:
        """Delete API key by id."""

