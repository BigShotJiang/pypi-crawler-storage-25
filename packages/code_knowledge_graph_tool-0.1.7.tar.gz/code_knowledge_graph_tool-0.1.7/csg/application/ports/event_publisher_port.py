"""Application port for post-commit event publishing."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class EventPublisherPort(Protocol):
    """Contract for publishing application/domain events."""

    def publish(self, event_name: str, payload: Mapping[str, Any]) -> None:
        """Publish one event payload."""

