"""Application port for read-only graph query operations."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class GraphQueryPort(Protocol):
    """Contract for read/query access to graph data."""

    def query(self, repo_id: str, cypher: str, params: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        """Execute a read-only graph query and return rows."""

