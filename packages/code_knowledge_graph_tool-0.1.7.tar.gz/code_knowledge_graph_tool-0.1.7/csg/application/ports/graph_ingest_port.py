"""Application port for graph ingest/load operations."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class GraphIngestPort(Protocol):
    """Contract for writing/replacing graph content."""

    def replace(self, repo_path: str, graph_payload: Mapping[str, Any]) -> Mapping[str, Any]:
        """Replace graph data for a repository and return ingest stats."""

