"""Application port for persisting job identity and lifecycle state."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class AnalysisJobStorePort(Protocol):
    """Contract for JobId <-> RunHandle mapping and job state storage."""

    def create(self, job_id: str, payload: Mapping[str, Any]) -> None:
        """Create initial job record."""

    def link(self, job_id: str, run_handle: str) -> None:
        """Persist mapping between job_id and run_handle."""

    def get_run_handle(self, job_id: str) -> str | None:
        """Get run_handle mapped to a job_id."""

    def get_job(self, job_id: str) -> Mapping[str, Any] | None:
        """Get stored job record."""

    def update(self, job_id: str, patch: Mapping[str, Any]) -> None:
        """Apply partial update to a job record."""

