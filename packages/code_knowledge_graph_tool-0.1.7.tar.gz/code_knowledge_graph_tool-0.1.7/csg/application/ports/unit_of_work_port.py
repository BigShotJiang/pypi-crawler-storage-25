"""Application port for unit-of-work boundaries."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class UnitOfWorkPort(Protocol):
    """Contract for commit/rollback lifecycle and staged events."""

    def __enter__(self) -> "UnitOfWorkPort":
        """Enter unit-of-work scope."""

    def __exit__(self, exc_type, exc, tb) -> bool | None:
        """Exit unit-of-work scope."""

    def commit(self) -> None:
        """Commit accumulated state changes."""

    def rollback(self) -> None:
        """Rollback accumulated state changes."""

    def add_event(self, event_name: str, payload: Mapping[str, Any]) -> None:
        """Record an event to be published post-commit."""

    def collect_events(self) -> list[tuple[str, Mapping[str, Any]]]:
        """Return and clear buffered events in publish order."""

