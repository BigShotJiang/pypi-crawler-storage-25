"""Application port for user persistence."""

from __future__ import annotations

from typing import Any, Protocol


class UserStorePort(Protocol):
    """Contract for user CRUD and lookup operations."""

    def create_user(
        self,
        *,
        username: str,
        email: str,
        password_hash: str,
        role: str,
        status: str,
    ) -> dict[str, Any]:
        """Create and persist a user record."""

    def get_by_id(self, user_id: str) -> dict[str, Any] | None:
        """Load a user by identifier."""

    def get_by_username(self, username: str) -> dict[str, Any] | None:
        """Load a user by username."""

    def get_by_email(self, email: str) -> dict[str, Any] | None:
        """Load a user by email."""

    def list_users(self) -> list[dict[str, Any]]:
        """List all users."""

    def update_last_login(self, user_id: str, *, last_login_at: str) -> None:
        """Update last-login metadata."""

    def update_username(self, user_id: str, *, username: str, updated_at: str) -> dict[str, Any] | None:
        """Update a user's username."""

    def update_password_hash(self, user_id: str, *, password_hash: str, updated_at: str) -> dict[str, Any] | None:
        """Update a user's password hash."""

    def update_status(self, user_id: str, *, status: str, updated_at: str) -> dict[str, Any] | None:
        """Update a user's status."""
