"""Application port for auth session persistence."""

from __future__ import annotations

from typing import Any, Protocol


class SessionStorePort(Protocol):
    """Contract for access/refresh-token-backed sessions."""

    def create_session(
        self,
        *,
        user_id: str,
        access_token_hash: str,
        refresh_token_hash: str,
        access_expires_at: str,
        refresh_expires_at: str,
    ) -> dict[str, Any]:
        """Create and persist a new auth session."""

    def get_by_access_token_hash(self, access_token_hash: str) -> dict[str, Any] | None:
        """Load a session by access-token hash."""

    def get_by_refresh_token_hash(self, refresh_token_hash: str) -> dict[str, Any] | None:
        """Load a session by refresh-token hash."""

    def rotate_session(
        self,
        session_id: str,
        *,
        access_token_hash: str,
        refresh_token_hash: str,
        access_expires_at: str,
        refresh_expires_at: str,
    ) -> dict[str, Any] | None:
        """Rotate access/refresh tokens for an existing session."""

    def revoke_session(self, session_id: str, *, revoked_at: str) -> None:
        """Revoke a session."""

    def revoke_sessions_for_user(self, user_id: str, *, revoked_at: str) -> None:
        """Revoke every session belonging to a user."""
