"""Application port for embedding capabilities."""

from __future__ import annotations

from typing import Protocol, Sequence


class EmbeddingGatewayPort(Protocol):
    """Contract for embedding outbound adapters."""

    def embed(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
        """Embed texts into vector representations."""

