"""Application port for parsing capabilities."""

from __future__ import annotations

from typing import Any, Mapping, Protocol


class ParsingGatewayPort(Protocol):
    """Contract for parser outbound adapters."""

    def parse(self, payload: Mapping[str, Any]) -> Mapping[str, Any]:
        """Parse payload into a normalized representation."""

