"""Application port for repository registry and git metadata operations."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol


class RepositoryRegistryPort(Protocol):
    """Contract for repository registry, metadata, and git-related lookup."""

    def get_repo_entry_by_name(self, repo_name: str) -> Any | None:
        """Return registry entry by repository name."""

    def has_index_for_repo(self, repo_path: str) -> bool:
        """Check whether repository has an index."""

    def load_repo_meta(self, repo_path: str) -> Any | None:
        """Load repository metadata."""

    def list_registered_repos_for_api(self, *, validate: bool = False) -> list[Any]:
        """List registered repositories."""

    def unregister_repo_entry(self, repo_path: str) -> None:
        """Remove repository from registry."""

    def get_storage_path_for_repo(self, repo_path: str) -> Path:
        """Resolve storage path for repository."""

    def get_current_commit_for_repo(self, repo_path: str) -> str | None:
        """Get current commit hash."""

    def get_repo_git_root(self, repo_path: str) -> str | None:
        """Get git root for repository."""

    def get_repo_diff_files(
        self,
        repo_path: str,
        *,
        scope: str = "all",
        base_ref: str = "",
    ) -> list[str]:
        """List changed files for repository."""

    def register_repo_entry(self, repo_path: str, meta: Any) -> None:
        """Register repository metadata entry."""

    def save_repo_meta(self, repo_path: str, meta: Any) -> None:
        """Persist repository metadata."""

    def build_repo_meta(
        self,
        *,
        repo_path: str,
        last_commit: str,
        indexed_at: str,
        stats: dict[str, Any],
        owner_user_id: str | None = None,
    ) -> Any:
        """Create repository metadata object for persistence."""
