"""Application port for AI agent operations."""

from __future__ import annotations

from typing import Protocol, Mapping, Any, AsyncIterator


class AgentGatewayPort(Protocol):
    """Contract for non-streaming and streaming agent execution."""

    async def run(self, payload: Mapping[str, Any]) -> Mapping[str, Any]:
        """Execute agent interaction and return final response."""

    async def stream(self, payload: Mapping[str, Any]) -> AsyncIterator[Mapping[str, Any]]:
        """Execute agent interaction as an event stream."""

    def generate_srs(self, *, context: str, repo_path: str) -> str:
        """Generate an SRS document payload."""

