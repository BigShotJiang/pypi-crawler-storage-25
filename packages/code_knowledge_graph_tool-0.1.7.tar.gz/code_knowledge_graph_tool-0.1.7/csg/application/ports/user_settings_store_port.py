"""Application port for per-user settings persistence."""

from __future__ import annotations

from typing import Any, Protocol


class UserSettingsStorePort(Protocol):
    """Contract for reading and updating user-scoped settings."""

    def get_settings(self, *, user_id: str) -> dict[str, Any] | None:
        """Return persisted settings for the given user, if present."""

    def upsert_settings(self, *, user_id: str, settings: dict[str, Any]) -> dict[str, Any]:
        """Create or replace settings for the given user."""
