"""Application port for run-handle based analysis control."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class AnalysisControlPort(Protocol):
    """Contract for cancelling and checking status by run_handle."""

    def cancel(self, run_handle: str) -> bool:
        """Request cancellation for a running handle."""

    def status(self, run_handle: str) -> Mapping[str, Any]:
        """Return runtime status for a run handle."""

