"""Application port for graph indexing operations."""

from __future__ import annotations

from typing import Protocol, Mapping, Any


class GraphIndexPort(Protocol):
    """Contract for graph index creation/rebuild capabilities."""

    def create_indexes(self, repo_path: str) -> None:
        """Create or refresh indexes for a repository graph."""

    def index_status(self, repo_path: str) -> Mapping[str, Any]:
        """Return index status/metadata for a repository graph."""

