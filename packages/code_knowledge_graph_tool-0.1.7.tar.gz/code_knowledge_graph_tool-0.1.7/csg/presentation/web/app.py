"""FastAPI app - upload zip, run analysis pipeline, stream results via SSE.

Also mounts the MCP HTTP transport at /mcp for remote MCP clients.
"""

from __future__ import annotations

import asyncio
from contextvars import copy_context
import importlib
import logging
import os
import re
import subprocess
import threading
import uuid
import zipfile
from contextlib import asynccontextmanager
from pathlib import Path

from csg.presentation.web.paths import project_root_from_web_file
from csg.presentation.web.services.app_helpers import (
    is_graph_payload as _is_graph_payload,
    make_runtime_temp_dir as _make_runtime_temp_dir,
    repo_id_for_path,
    resolve_repo_path_from_id,
    serialize_value as _serialize_value,
    serve_index as _serve_index,
    sse as _sse,
)

try:
    from dotenv import load_dotenv
except ModuleNotFoundError:  # pragma: no cover - optional dependency in test envs

    def load_dotenv(*_args, **_kwargs):
        return False


PROJECT_ROOT = project_root_from_web_file(Path(__file__))

# Load .env from project root so the web server sees env vars (API keys, etc.)
load_dotenv(PROJECT_ROOT / ".env")

from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi import Query as QueryParam
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from csg.bootstrap import build_container
from csg.application.use_cases.analysis.run_pipeline import run_analysis_pipeline_sync
from csg.application.use_cases.analysis.watch_repositories import get_repo_watcher
from csg.application.use_cases.graph.query_graph import query_graph as run_graph_query
from csg.application.use_cases.repositories._helpers import to_repo_id
from csg.application.use_cases.repositories.create_api_key import create_api_key
from csg.application.use_cases.repositories.delete_api_key import delete_api_key
from csg.application.use_cases.repositories.delete_repository import delete_repository
from csg.application.use_cases.repositories.get_repository_graph import (
    get_cached_repository_graph,
    rebuild_repository_graph,
)
from csg.application.use_cases.repositories.list_api_keys import list_api_keys
from csg.application.use_cases.repositories.list_repositories import list_repositories
from csg.application.use_cases.repositories.register_repository_analysis import (
    register_repository_analysis,
)
from csg.application.use_cases.sources.is_binary_source import is_binary_source_path
from csg.presentation.web.auth import AuthenticatedUser, require_current_user
from csg.presentation.web.routes.account import router as account_router
from csg.presentation.web.routes.auth import admin_router, router as auth_router
from csg.presentation.web.routes.agent import router
from csg.presentation.web.routes.analysis import load_graph_json, save_graph_json, serialize_results
from csg.presentation.web.routes.settings import resolve_runtime_context, router as settings_router
from csg.infrastructure.runtime.user_context import bind_user_runtime

logger = logging.getLogger(__name__)
_container = build_container()
_runtime = _container.runtime()
CYPHER_WRITE_RE = re.compile(r"\b(CREATE|DELETE|SET|MERGE|REMOVE|DROP|ALTER|COPY|DETACH)\b", re.I)


def _build_mcp_mount():
    transport = importlib.import_module("csg.presentation.mcp.http_transport")
    return transport.MCPMount()


def _setup_mcp_http(mcp_mount, db_path: str):
    transport = importlib.import_module("csg.presentation.mcp.http_transport")
    return transport.setup_mcp_http(mcp_mount, db_path)


# MCP HTTP transport - lazy ASGI wrapper mounted at /mcp
_mcp_app = _build_mcp_mount()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """App lifespan - starts the MCP HTTP session manager + background watcher."""
    container = getattr(app.state, "container", build_container())
    repository_registry = container.get_repository_registry()
    db_path = _runtime.db_path_override or str(repository_registry.get_storage_path_for_repo(os.getcwd()) / "lbug")

    # Initialize shared database pool (singleton)
    graph_pool = container.get_graph_pool()

    # Start background repo watcher
    watcher = get_repo_watcher(watcher_factory=container.get_repo_watcher)
    watcher.start()

    try:
        async with _setup_mcp_http(_mcp_app, db_path):
            yield
    except Exception:
        logger.debug("MCP HTTP transport failed to start (no index?)", exc_info=True)
        yield
    finally:
        watcher.stop()
        graph_pool.close_all()


app = FastAPI(
    title="CSG Web",
    description="Code Structure with Graph - Web UI",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(_runtime.cors_origins),
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(admin_router)
app.include_router(account_router)
app.include_router(settings_router)
app.include_router(router, prefix="/v1")
app.state.container = _container


@app.get("/api/health")
async def health() -> dict:
    """Liveness / readiness probe for Docker and CI health checks."""
    return {"status": "ok"}


STATIC_DIR = Path(__file__).resolve().parent / "static"
FRONTEND_DIST = PROJECT_ROOT / "frontend" / "dist"

_current_repo_path: str | None = None

# Job registry - maps job_id -> active pipeline state
_job_registry: dict[str, dict[str, object]] = {}
_job_lock = threading.Lock()


def _repo_id(path: str) -> str:
    """Deterministic short ID from a repo path."""
    container = getattr(app.state, "container", build_container())
    return repo_id_for_path(
        path,
        storage_path_resolver=container.get_repository_registry().get_storage_path_for_repo,
        to_repo_id=to_repo_id,
    )


def _user_can_view_repo(repo: dict, user: AuthenticatedUser) -> bool:
    owner_user_id = repo.get("owner_user_id")
    return user.role == "admin" or owner_user_id is None or owner_user_id == user.id


def _user_can_manage_repo(repo: dict, user: AuthenticatedUser) -> bool:
    owner_user_id = repo.get("owner_user_id")
    return user.role == "admin" or owner_user_id == user.id


def _list_visible_repos(user: AuthenticatedUser) -> list[dict]:
    container = getattr(app.state, "container", build_container())
    repos = list_repositories(validate=False, repository_registry=container.get_repository_registry())
    return [repo for repo in repos if _user_can_view_repo(repo, user)]


def _get_repo_for_user(repo_id: str, user: AuthenticatedUser, *, require_manage: bool = False) -> dict:
    repo = next((repo for repo in _list_visible_repos(user) if repo["id"] == repo_id), None)
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    if require_manage and not _user_can_manage_repo(repo, user):
        raise HTTPException(status_code=403, detail="Repository access denied")
    return repo


@app.get("/", response_class=HTMLResponse)
async def index():
    """Serve the frontend - Vite build if available, otherwise legacy SPA."""
    return _serve_index(FRONTEND_DIST, STATIC_DIR)


@app.post("/api/analyze")
async def analyze(current_user: AuthenticatedUser = Depends(require_current_user), file: UploadFile = File(...)):
    """Accept a zip file, run analysis pipeline, return SSE stream."""
    global _current_repo_path

    if not file.filename or not file.filename.endswith(".zip"):
        raise HTTPException(status_code=400, detail="Please upload a .zip file")

    async def event_stream():
        global _current_repo_path
        from csg.domain.errors import PipelineCancelled

        job_id = uuid.uuid4().hex[:16]
        cancel_event = threading.Event()
        with _job_lock:
            _job_registry[job_id] = {"cancel_event": cancel_event, "owner_user_id": current_user.id}

        try:
            import shutil

            tmp_dir = _make_runtime_temp_dir("csg_")
            zip_path = os.path.join(tmp_dir, "upload.zip")

            content = await file.read()
            with open(zip_path, "wb") as f:
                f.write(content)

            yield _sse("job_id", {"job_id": job_id})
            yield _sse("status", {"phase": "upload", "message": f"Received {file.filename} ({len(content)} bytes)"})

            # Extract to temp first to discover project name
            extract_tmp = os.path.join(tmp_dir, "repo")
            os.makedirs(extract_tmp, exist_ok=True)

            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(extract_tmp)

            entries = os.listdir(extract_tmp)
            if len(entries) == 1 and os.path.isdir(os.path.join(extract_tmp, entries[0])):
                project_name = entries[0]
            else:
                project_name = os.path.splitext(file.filename or "upload")[0]

            # Move codebase into storage/<hash>/<project_name>/
            container = getattr(app.state, "container", build_container())
            storage = container.get_repository_registry().get_storage_path_for_repo(zip_path)
            storage.mkdir(parents=True, exist_ok=True)
            dest = storage / project_name
            if dest.exists():
                shutil.rmtree(dest)
            src = (
                os.path.join(extract_tmp, entries[0])
                if len(entries) == 1 and os.path.isdir(os.path.join(extract_tmp, entries[0]))
                else extract_tmp
            )
            shutil.move(src, str(dest))

            repo_path = str(dest)

            _current_repo_path = repo_path

            yield _sse("status", {"phase": "extract", "message": f"Extracted to {repo_path}"})
            yield _sse("status", {"phase": "analyzing", "message": "Running analysis pipeline..."})

            loop = asyncio.get_event_loop()
            runtime_settings, runtime_secrets = resolve_runtime_context(container, current_user.id)
            with bind_user_runtime(runtime_settings, runtime_secrets):
                context = copy_context()
            final_state = await loop.run_in_executor(None, lambda: context.run(
                lambda: run_analysis_pipeline_sync(
                    repo_path,
                    runner=container.run_analysis_pipeline_sync,
                    cancel_event=cancel_event,
                ),
            ))

            yield _sse("status", {"phase": "serializing", "message": "Preparing results..."})

            results = serialize_results(final_state)

            try:
                save_graph_json(repo_path, results)
            except Exception:
                logger.debug("Could not save graph JSON", exc_info=True)

            try:
                container = getattr(app.state, "container", build_container())
                register_repository_analysis(
                    repo_path=repo_path,
                    source_label="uploaded",
                    final_state=final_state,
                    results=results,
                    repository_registry=container.get_repository_registry(),
                    owner_user_id=current_user.id,
                )
            except Exception:
                logger.debug("Could not register uploaded repo", exc_info=True)

            results["repo_id"] = _repo_id(repo_path)

            yield _sse("result", results)
            yield _sse("done", {"message": "Analysis complete"})

        except PipelineCancelled:
            logger.info("Analysis cancelled (job %s)", job_id)
            yield _sse("cancelled", {"message": "Analysis cancelled and rolled back"})
        except Exception as e:
            logger.exception("Analysis failed")
            yield _sse("error", {"message": str(e)})
        finally:
            with _job_lock:
                _job_registry.pop(job_id, None)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


async def _run_pipeline_sse(repo_path: str, tmp_dir: str, source_label: str, owner_user_id: str):
    """Shared SSE generator: run analysis pipeline on *repo_path* and yield events."""
    global _current_repo_path
    _current_repo_path = repo_path
    container = getattr(app.state, "container", build_container())

    from csg.domain.errors import PipelineCancelled

    job_id = uuid.uuid4().hex[:16]
    cancel_event = threading.Event()
    with _job_lock:
        _job_registry[job_id] = {"cancel_event": cancel_event, "owner_user_id": owner_user_id}

    try:
        yield _sse("job_id", {"job_id": job_id})
        yield _sse("status", {"phase": "analyzing", "message": "Running analysis pipeline..."})

        loop = asyncio.get_event_loop()
        runtime_settings, runtime_secrets = resolve_runtime_context(container, owner_user_id)
        with bind_user_runtime(runtime_settings, runtime_secrets):
            context = copy_context()
        final_state = await loop.run_in_executor(None, lambda: context.run(
            lambda: run_analysis_pipeline_sync(
                repo_path,
                runner=container.run_analysis_pipeline_sync,
                cancel_event=cancel_event,
            ),
        ))

        yield _sse("status", {"phase": "serializing", "message": "Preparing results..."})

        results = serialize_results(final_state)

        try:
            save_graph_json(repo_path, results)
        except Exception:
            logger.debug("Could not save graph JSON", exc_info=True)

        try:
            container = getattr(app.state, "container", build_container())
            register_repository_analysis(
                repo_path=repo_path,
                source_label=source_label,
                final_state=final_state,
                results=results,
                repository_registry=container.get_repository_registry(),
                owner_user_id=owner_user_id,
            )
        except Exception:
            logger.debug("Could not register repo", exc_info=True)

        results["repo_id"] = _repo_id(repo_path)
        yield _sse("result", results)
        yield _sse("done", {"message": "Analysis complete"})
    except PipelineCancelled:
        logger.info("Pipeline cancelled (job %s)", job_id)
        yield _sse("cancelled", {"message": "Analysis cancelled and rolled back"})
    finally:
        with _job_lock:
            _job_registry.pop(job_id, None)


class CypherQueryRequest(BaseModel):
    cypher: str
    params: dict = {}


class AnalyzeGitRequest(BaseModel):
    url: str
    branch: str = ""


@app.post("/api/analyze-git")
async def analyze_git(req: AnalyzeGitRequest, current_user: AuthenticatedUser = Depends(require_current_user)):
    """Clone a git repository and run analysis pipeline, return SSE stream."""
    global _current_repo_path

    url = req.url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="Repository URL is required")

    async def event_stream():
        global _current_repo_path
        try:
            container = getattr(app.state, "container", build_container())
            tmp_dir = _make_runtime_temp_dir("csg_git_")
            clone_target = os.path.join(tmp_dir, "repo")
            runtime_settings, _runtime_secrets = resolve_runtime_context(container, current_user.id)
            branch = req.branch.strip() or runtime_settings.default_branch

            yield _sse("status", {"phase": "clone", "message": f"Cloning {url}..."})

            cmd = ["git", "clone", "--depth", "1"]
            if branch:
                cmd.extend(["--branch", branch])
            cmd.extend([url, clone_target])

            loop = asyncio.get_event_loop()
            proc = await loop.run_in_executor(
                None,
                lambda: subprocess.run(cmd, capture_output=True, text=True, timeout=300),
            )

            if proc.returncode != 0:
                yield _sse("error", {"message": f"Clone failed: {proc.stderr.strip()}"})
                return

            yield _sse("status", {"phase": "clone", "message": "Clone complete"})

            repo_path = clone_target
            _current_repo_path = repo_path

            # Determine branch label
            source_label = branch or "main"
            try:
                head = subprocess.run(
                    ["git", "-C", repo_path, "rev-parse", "--short", "HEAD"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if head.returncode == 0:
                    source_label = head.stdout.strip()
            except Exception:
                pass

            async for event in _run_pipeline_sse(repo_path, tmp_dir, source_label, current_user.id):
                yield event

        except Exception as e:
            logger.exception("Git analysis failed")
            yield _sse("error", {"message": str(e)})

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


class AnalyzeUrlRequest(BaseModel):
    url: str


@app.post("/api/analyze-url")
async def analyze_url(req: AnalyzeUrlRequest, current_user: AuthenticatedUser = Depends(require_current_user)):
    """Download a zip from a URL and run analysis pipeline, return SSE stream."""
    global _current_repo_path

    url = req.url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="URL is required")

    async def event_stream():
        global _current_repo_path
        try:
            import shutil

            tmp_dir = _make_runtime_temp_dir("csg_url_")

            yield _sse("status", {"phase": "download", "message": f"Downloading from {url}..."})

            import urllib.request

            zip_path = os.path.join(tmp_dir, "download.zip")

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: urllib.request.urlretrieve(url, zip_path),
            )

            file_size = os.path.getsize(zip_path)
            yield _sse("status", {"phase": "download", "message": f"Downloaded {file_size} bytes"})

            yield _sse("status", {"phase": "extract", "message": "Extracting archive..."})

            # Extract to temp first to discover project name
            extract_tmp = os.path.join(tmp_dir, "repo")
            os.makedirs(extract_tmp, exist_ok=True)

            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(extract_tmp)

            entries = os.listdir(extract_tmp)
            if len(entries) == 1 and os.path.isdir(os.path.join(extract_tmp, entries[0])):
                project_name = entries[0]
            else:
                project_name = "download"

            # Move codebase into storage/<hash>/<project_name>/
            container = getattr(app.state, "container", build_container())
            storage = container.get_repository_registry().get_storage_path_for_repo(zip_path)
            storage.mkdir(parents=True, exist_ok=True)
            dest = storage / project_name
            if dest.exists():
                shutil.rmtree(dest)
            src = (
                os.path.join(extract_tmp, entries[0])
                if len(entries) == 1 and os.path.isdir(os.path.join(extract_tmp, entries[0]))
                else extract_tmp
            )
            shutil.move(src, str(dest))

            repo_path = str(dest)

            _current_repo_path = repo_path

            async for event in _run_pipeline_sse(repo_path, tmp_dir, "cloud", current_user.id):
                yield event

        except zipfile.BadZipFile:
            yield _sse("error", {"message": "Downloaded file is not a valid .zip archive"})
        except Exception as e:
            logger.exception("URL analysis failed")
            yield _sse("error", {"message": str(e)})

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/file")
async def read_file(
    path: str = QueryParam(..., description="Relative file path"),
    repo_id: str | None = QueryParam(None, description="Repository ID (optional)"),
    current_user: AuthenticatedUser = Depends(require_current_user),
):
    """Serve a source file from the extracted repo."""
    repo_path = _current_repo_path
    if repo_id:
        repo_path = _get_repo_for_user(repo_id, current_user)["path"]
    elif repo_path:
        visible = next((repo for repo in _list_visible_repos(current_user) if repo["path"] == repo_path), None)
        if visible is None:
            raise HTTPException(status_code=403, detail="Repository access denied")
    if not repo_path:
        raise HTTPException(status_code=404, detail="No analysis session active")

    clean = os.path.normpath(path).lstrip(os.sep)
    if ".." in clean.split(os.sep):
        raise HTTPException(status_code=400, detail="Invalid path")

    full_path = os.path.join(repo_path, clean)
    if not os.path.isfile(full_path):
        raise HTTPException(status_code=404, detail="File not found")

    container = getattr(app.state, "container", build_container())
    if is_binary_source_path(full_path, checker=container.get_source_provider().is_binary_path):
        return JSONResponse({"binary": True, "path": clean})

    try:
        content = Path(full_path).read_text(errors="replace")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return PlainTextResponse(content)


@app.get("/api/repos")
async def list_repos(current_user: AuthenticatedUser = Depends(require_current_user)):
    """List all registered repositories."""
    return _list_visible_repos(current_user)


@app.delete("/api/repos/{repo_id}")
async def delete_repo(repo_id: str, current_user: AuthenticatedUser = Depends(require_current_user)):
    """Remove a repository from the registry and clean up storage."""
    container = getattr(app.state, "container", build_container())
    _get_repo_for_user(repo_id, current_user, require_manage=True)
    result = delete_repository(repo_id, repository_registry=container.get_repository_registry())
    if result.get("status") == "not_found":
        raise HTTPException(status_code=404, detail="Repository not found")
    return {"status": result["status"], "storage_cleaned": result.get("storage_cleaned", False)}


@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str, current_user: AuthenticatedUser = Depends(require_current_user)):
    """Signal a running pipeline to cancel and roll back."""
    with _job_lock:
        entry = _job_registry.get(job_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Job not found or already finished")
    if current_user.role != "admin" and entry.get("owner_user_id") != current_user.id:
        raise HTTPException(status_code=403, detail="Job access denied")
    cancel_event = entry.get("cancel_event")
    if not isinstance(cancel_event, threading.Event):
        raise HTTPException(status_code=500, detail="Job registry is corrupted")
    cancel_event.set()
    return {"status": "cancelling", "job_id": job_id}


@app.get("/api/repos/{repo_id}/graph")
async def get_repo_graph(repo_id: str, current_user: AuthenticatedUser = Depends(require_current_user)):
    """Load analysis results for a registered repo.

    Returns cached graph.json when available, only re-running the pipeline
    if no cached results exist AND the source path is still on disk.
    """
    global _current_repo_path
    container = getattr(app.state, "container", build_container())
    target = _get_repo_for_user(repo_id, current_user)

    # Try loading cached graph.json FIRST - the source dir may have been
    # cleaned up (temp dirs from zip uploads / git clones), but the cached
    # results in data/repos/{hash}/graph.json are still valid.
    cached = get_cached_repository_graph(target["path"], loader=load_graph_json)
    if _is_graph_payload(cached):
        _current_repo_path = target["path"]
        cached["repo_id"] = repo_id
        return cached

    # No cache - need source on disk to re-run the pipeline
    if not os.path.isdir(target["path"]):
        raise HTTPException(
            status_code=404,
            detail="Cached results not found and source path no longer exists on disk",
        )

    _current_repo_path = target["path"]
    try:
        results = await rebuild_repository_graph(
            target["path"],
            runner=container.run_analysis_pipeline_sync,
            serializer=serialize_results,
            saver=save_graph_json,
        )
    except RuntimeError as exc:
        msg = str(exc).lower()
        if "read-only" in msg or "lock" in msg:
            raise HTTPException(
                status_code=409,
                detail=("Another process holds the database lock. Try refreshing - the data may be available shortly."),
            )
        raise

    if not _is_graph_payload(results):
        raise HTTPException(
            status_code=500,
            detail=results.get("error", "Analysis did not produce graph results"),
        )

    results["repo_id"] = repo_id
    return results


_MAX_QUERY_ROWS = 500


@app.post("/api/repos/{repo_id}/query")
async def execute_cypher_query(
    repo_id: str,
    req: CypherQueryRequest,
    current_user: AuthenticatedUser = Depends(require_current_user),
):
    """Execute a read-only Cypher query against a repo's knowledge graph."""
    if CYPHER_WRITE_RE.search(req.cypher):
        raise HTTPException(
            status_code=400,
            detail="Write operations are not allowed. Only read queries are supported.",
        )

    container = getattr(app.state, "container", build_container())
    target = _get_repo_for_user(repo_id, current_user)

    db_path = os.path.join(target["storage_path"], "lbug")
    if not os.path.exists(db_path):
        raise HTTPException(
            status_code=404,
            detail="Knowledge graph not found. Please analyze the repository first.",
        )

    try:
        query_adapter = container.get_graph_ports()["query"]
        rows = await run_graph_query(
            repo_id=repo_id,
            cypher=req.cypher,
            params=req.params or {},
            query_adapter=query_adapter,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Query failed: {exc}")

    columns = list(rows[0].keys()) if rows else []
    capped = rows[:_MAX_QUERY_ROWS]
    table_rows = [[_serialize_value(v) for v in row.values()] for row in capped]

    return {
        "columns": columns,
        "rows": table_rows,
        "count": len(capped),
        "truncated": len(rows) > _MAX_QUERY_ROWS,
    }


@app.get("/api/stats")
async def get_stats(current_user: AuthenticatedUser = Depends(require_current_user)):
    """Aggregate statistics across all registered repos with per-repo breakdown."""
    repos = _list_visible_repos(current_user)

    per_repo = []
    for r in repos:
        s = r["stats"] or {}
        per_repo.append(
            {
                "id": r["id"],
                "name": r["name"],
                "indexed_at": r["indexed_at"],
                "files": s.get("files", 0),
                "nodes": s.get("nodes", 0),
                "edges": s.get("edges", 0),
                "communities": s.get("communities", 0),
                "processes": s.get("processes", 0),
                "embeddings": s.get("embeddings", 0),
            }
        )

    return {
        "total_repos": len(repos),
        "total_nodes": sum((r["stats"] or {}).get("nodes", 0) for r in repos),
        "total_relationships": sum((r["stats"] or {}).get("edges", 0) for r in repos),
        "total_communities": sum((r["stats"] or {}).get("communities", 0) for r in repos),
        "total_processes": sum((r["stats"] or {}).get("processes", 0) for r in repos),
        "total_files": sum((r["stats"] or {}).get("files", 0) for r in repos),
        "total_embeddings": sum((r["stats"] or {}).get("embeddings", 0) for r in repos),
        "repos": per_repo,
    }


class CreateKeyRequest(BaseModel):
    description: str


@app.get("/api/keys")
async def list_keys(current_user: AuthenticatedUser = Depends(require_current_user)):
    """List all API keys."""
    container = getattr(app.state, "container", build_container())
    return list_api_keys(owner_user_id=current_user.id, api_key_store=container.get_api_key_store())


@app.post("/api/keys")
async def create_key(req: CreateKeyRequest, current_user: AuthenticatedUser = Depends(require_current_user)):
    """Create a new API key."""
    container = getattr(app.state, "container", build_container())
    return create_api_key(req.description, owner_user_id=current_user.id, api_key_store=container.get_api_key_store())


@app.delete("/api/keys/{key_id}")
async def delete_key(key_id: str, current_user: AuthenticatedUser = Depends(require_current_user)):
    """Revoke an API key."""
    container = getattr(app.state, "container", build_container())
    deleted = delete_api_key(key_id, owner_user_id=current_user.id, api_key_store=container.get_api_key_store())
    if not deleted:
        raise HTTPException(status_code=404, detail="Key not found")
    return {"status": "revoked"}


def _resolve_repo_path_from_id(repo_id: str, user: AuthenticatedUser | None = None) -> str | None:
    """Resolve a repo filesystem path from its short MD5 ID."""
    repos = _list_visible_repos(user) if user else list_repositories(
        validate=False,
        repository_registry=getattr(app.state, "container", build_container()).get_repository_registry(),
    )
    return resolve_repo_path_from_id(repo_id, repos=repos)


@app.get("/api/srs-docx")
async def download_srs_docx(
    repo_id: str = QueryParam(None, description="Repository ID (optional)"),
    current_user: AuthenticatedUser = Depends(require_current_user),
):
    """Download the previously generated SRS .docx file."""
    repo_path = None
    if repo_id:
        repo_path = _resolve_repo_path_from_id(repo_id, current_user)
    if not repo_path:
        repo_path = _current_repo_path
        if repo_path:
            visible = next((repo for repo in _list_visible_repos(current_user) if repo["path"] == repo_path), None)
            if visible is None:
                raise HTTPException(status_code=403, detail="Repository access denied")
    if not repo_path:
        raise HTTPException(status_code=404, detail="No repository found. Please analyze a repository first.")
    repo_name = Path(repo_path).name

    docx_path = os.path.join(repo_path, f"srs_{repo_name}.docx")
    if not os.path.isfile(docx_path):
        raise HTTPException(
            status_code=404, detail="SRS document not yet generated. Ask the agent to generate an SRS first."
        )

    return FileResponse(
        docx_path,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        filename=f"srs_{repo_name}.docx",
    )


# MCP HTTP transport - mounted before the SPA catch-all
app.mount("/mcp", _mcp_app, name="mcp")

if FRONTEND_DIST.exists() and (FRONTEND_DIST / "assets").exists():
    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIST / "assets")), name="frontend-assets")


@app.get("/{path:path}", response_class=HTMLResponse)
async def spa_fallback(path: str):
    """Serve index.html for all non-API routes (SPA client-side routing)."""
    if path.startswith("api/") or path.startswith("assets/") or path.startswith("mcp"):
        raise HTTPException(status_code=404)
    return _serve_index(FRONTEND_DIST, STATIC_DIR)
