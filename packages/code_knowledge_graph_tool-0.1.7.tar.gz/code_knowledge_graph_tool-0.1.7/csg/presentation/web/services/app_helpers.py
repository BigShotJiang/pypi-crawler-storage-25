"""Pure helpers shared by the web presentation layer."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from fastapi import HTTPException
from fastapi.responses import HTMLResponse


def repo_id_for_path(path: str, *, storage_path_resolver, to_repo_id) -> str:
    """Deterministic short repo ID from a repository path."""
    storage_path = storage_path_resolver(path)
    return to_repo_id(storage_path)


def make_runtime_temp_dir(prefix: str) -> str:
    """Create temp dirs under CSG_DATA_DIR so web flows do not depend on OS temp."""
    temp_root = Path(os.environ.get("CSG_DATA_DIR", "data")) / "tmp"
    temp_root.mkdir(parents=True, exist_ok=True)
    return tempfile.mkdtemp(prefix=prefix, dir=str(temp_root))


def sse(event: str, data: dict) -> str:
    """Format a Server-Sent Event."""
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


def serve_index(frontend_dist: Path, static_dir: Path) -> HTMLResponse:
    """Serve the frontend index.html."""
    vite_index = frontend_dist / "index.html"
    if vite_index.exists():
        return HTMLResponse(vite_index.read_text(encoding="utf-8"))
    html_path = static_dir / "index.html"
    if html_path.exists():
        return HTMLResponse(html_path.read_text(encoding="utf-8"))
    raise HTTPException(status_code=404, detail="Frontend not built")


def is_graph_payload(payload: dict | None) -> bool:
    """Return True when payload has the shape the frontend graph requires."""
    if not isinstance(payload, dict):
        return False
    graph = payload.get("graph")
    return (
        isinstance(payload.get("summary"), dict)
        and isinstance(graph, dict)
        and isinstance(graph.get("nodes"), list)
        and isinstance(graph.get("edges"), list)
    )


def serialize_value(val: object) -> object:
    """Make a KuzuDB result value JSON-serializable."""
    if val is None or isinstance(val, (str, int, float, bool)):
        return val
    if isinstance(val, (list, tuple)):
        return [serialize_value(v) for v in val]
    if isinstance(val, dict):
        return {str(k): serialize_value(v) for k, v in val.items()}
    return str(val)


def resolve_repo_path_from_id(repo_id: str, *, repos: list[dict]) -> str | None:
    """Resolve a repo filesystem path from its short ID."""
    target = next((repo for repo in repos if repo["id"] == repo_id), None)
    return target["path"] if target else None
