"""Shared web presentation services."""
