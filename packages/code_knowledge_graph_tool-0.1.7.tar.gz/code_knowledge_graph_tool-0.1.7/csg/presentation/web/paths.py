"""Path helpers for the web presentation layer."""

from pathlib import Path


def project_root_from_web_file(web_file: Path) -> Path:
    """Return the repository root from a file under csg/presentation/web."""
    return web_file.resolve().parents[3]
