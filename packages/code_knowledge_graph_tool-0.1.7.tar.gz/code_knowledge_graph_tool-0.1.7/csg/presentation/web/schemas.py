"""Pydantic schemas for v1 API."""

from typing import Optional
from pydantic import BaseModel, Field


class SelectedNodeContext(BaseModel):
    """Context about the currently selected node in the graph UI."""

    id: str
    label: str
    nodeType: str
    filePath: str
    startLine: Optional[int] = None
    endLine: Optional[int] = None
    communityId: Optional[str] = None


class AgentRequest(BaseModel):
    """Request body for POST /v1/ckg-agent."""

    user_id: Optional[str] = Field(None, description="Deprecated client-side identifier")
    user_message: str = Field(..., description="User message for the agent")
    selected_node: Optional[SelectedNodeContext] = Field(
        None, description="Currently selected node in the graph UI"
    )
    repo_id: Optional[str] = Field(
        None, description="Repository identifier for data lookup"
    )
