"""Web-layer auth helpers and dependencies."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from fastapi import Depends, HTTPException, Request, Response, status

from csg.application.use_cases.auth.login_user import login_user
from csg.application.use_cases.auth.register_user import register_user

ACCESS_COOKIE_NAME = "csg_access_token"
REFRESH_COOKIE_NAME = "csg_refresh_token"
ACCESS_TOKEN_TTL = timedelta(minutes=15)
REFRESH_TOKEN_TTL = timedelta(days=7)


@dataclass(frozen=True)
class AuthenticatedUser:
    """Minimal authenticated principal used by protected routes."""

    id: str
    username: str
    email: str
    role: str
    status: str


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _sanitize_user(user: dict) -> dict:
    return {
        "id": user["id"],
        "username": user["username"],
        "email": user["email"],
        "role": user["role"],
        "status": user["status"],
        "created_at": user.get("created_at"),
        "updated_at": user.get("updated_at"),
        "last_login_at": user.get("last_login_at"),
    }


def _set_auth_cookies(response: Response, *, access_token: str, refresh_token: str, secure: bool) -> None:
    response.set_cookie(
        ACCESS_COOKIE_NAME,
        access_token,
        httponly=True,
        secure=secure,
        samesite="lax",
        max_age=int(ACCESS_TOKEN_TTL.total_seconds()),
        path="/",
    )
    response.set_cookie(
        REFRESH_COOKIE_NAME,
        refresh_token,
        httponly=True,
        secure=secure,
        samesite="lax",
        max_age=int(REFRESH_TOKEN_TTL.total_seconds()),
        path="/",
    )


def clear_auth_cookies(response: Response, *, secure: bool) -> None:
    response.delete_cookie(ACCESS_COOKIE_NAME, path="/", secure=secure, httponly=True, samesite="lax")
    response.delete_cookie(REFRESH_COOKIE_NAME, path="/", secure=secure, httponly=True, samesite="lax")


def _build_session_tokens(*, request: Request, user: dict) -> tuple[dict, str, str]:
    token_service = request.app.state.container.get_token_service()
    session_store = request.app.state.container.get_session_store()
    now = _utcnow()
    access_token = token_service.issue_token()
    refresh_token = token_service.issue_token()
    session = session_store.create_session(
        user_id=user["id"],
        access_token_hash=token_service.hash_token(access_token),
        refresh_token_hash=token_service.hash_token(refresh_token),
        access_expires_at=(now + ACCESS_TOKEN_TTL).isoformat(),
        refresh_expires_at=(now + REFRESH_TOKEN_TTL).isoformat(),
    )
    return session, access_token, refresh_token


def _ensure_password_policy(password: str) -> None:
    if len(password) < 8:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Password must be at least 8 characters")


def _ensure_email_policy(email: str) -> None:
    value = email.strip()
    if "@" not in value or value.startswith("@") or value.endswith("@"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email is invalid")


def authenticate_credentials(*, identifier: str, password: str, request: Request) -> dict:
    user_store = request.app.state.container.get_user_store()
    password_hasher = request.app.state.container.get_password_hasher()
    user = login_user(identifier, user_store=user_store)
    if not user or not password_hasher.verify_password(password, user.get("password_hash", "")):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    if user.get("status") != "active":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User account is disabled")
    user_store.update_last_login(user["id"], last_login_at=_utcnow().isoformat())
    return user_store.get_by_id(user["id"]) or user


def register_and_login_user(*, username: str, email: str, password: str, request: Request) -> tuple[dict, str, str]:
    _ensure_password_policy(password)
    _ensure_email_policy(email)
    password_hasher = request.app.state.container.get_password_hasher()
    user_store = request.app.state.container.get_user_store()
    try:
        user = register_user(
            username=username,
            email=email,
            password_hash=password_hasher.hash_password(password),
            user_store=user_store,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    _session, access_token, refresh_token = _build_session_tokens(request=request, user=user)
    user_store.update_last_login(user["id"], last_login_at=_utcnow().isoformat())
    return _sanitize_user(user_store.get_by_id(user["id"]) or user), access_token, refresh_token


def login_and_issue_tokens(*, identifier: str, password: str, request: Request) -> tuple[dict, str, str]:
    user = authenticate_credentials(identifier=identifier, password=password, request=request)
    _session, access_token, refresh_token = _build_session_tokens(request=request, user=user)
    return _sanitize_user(user), access_token, refresh_token


def refresh_tokens(request: Request) -> tuple[dict, str, str]:
    refresh_token = request.cookies.get(REFRESH_COOKIE_NAME) or _extract_bearer_token(request)
    if not refresh_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing refresh token")
    token_service = request.app.state.container.get_token_service()
    session_store = request.app.state.container.get_session_store()
    user_store = request.app.state.container.get_user_store()
    session = session_store.get_by_refresh_token_hash(token_service.hash_token(refresh_token))
    if not session or session.get("revoked_at") is not None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")
    if _is_expired(session.get("refresh_expires_at")):
        session_store.revoke_session(session["id"], revoked_at=_utcnow().isoformat())
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh token expired")
    user = user_store.get_by_id(session["user_id"])
    if not user or user.get("status") != "active":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not available")

    access_token = token_service.issue_token()
    new_refresh_token = token_service.issue_token()
    rotated = session_store.rotate_session(
        session["id"],
        access_token_hash=token_service.hash_token(access_token),
        refresh_token_hash=token_service.hash_token(new_refresh_token),
        access_expires_at=(_utcnow() + ACCESS_TOKEN_TTL).isoformat(),
        refresh_expires_at=(_utcnow() + REFRESH_TOKEN_TTL).isoformat(),
    )
    if rotated is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh session not found")
    return _sanitize_user(user), access_token, new_refresh_token


def logout_current_session(request: Request) -> None:
    token_service = request.app.state.container.get_token_service()
    session_store = request.app.state.container.get_session_store()
    access_token = request.cookies.get(ACCESS_COOKIE_NAME)
    refresh_token = request.cookies.get(REFRESH_COOKIE_NAME)
    session = None
    if access_token:
        session = session_store.get_by_access_token_hash(token_service.hash_token(access_token))
    if session is None and refresh_token:
        session = session_store.get_by_refresh_token_hash(token_service.hash_token(refresh_token))
    if session is not None:
        session_store.revoke_session(session["id"], revoked_at=_utcnow().isoformat())


def _extract_bearer_token(request: Request) -> str | None:
    auth_header = request.headers.get("authorization", "")
    if auth_header.lower().startswith("bearer "):
        return auth_header[7:].strip()
    return None


def _is_expired(iso_value: str | None) -> bool:
    if not iso_value:
        return True
    try:
        return datetime.fromisoformat(iso_value) <= _utcnow()
    except ValueError:
        return True


def _load_authenticated_user(request: Request) -> AuthenticatedUser:
    token = request.cookies.get(ACCESS_COOKIE_NAME) or _extract_bearer_token(request)
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    token_service = request.app.state.container.get_token_service()
    session_store = request.app.state.container.get_session_store()
    user_store = request.app.state.container.get_user_store()
    session = session_store.get_by_access_token_hash(token_service.hash_token(token))
    if not session or session.get("revoked_at") is not None or _is_expired(session.get("access_expires_at")):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Access token expired or invalid")
    user = user_store.get_by_id(session["user_id"])
    if not user or user.get("status") != "active":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not available")
    return AuthenticatedUser(
        id=user["id"],
        username=user["username"],
        email=user["email"],
        role=user["role"],
        status=user["status"],
    )


def require_current_user(request: Request) -> AuthenticatedUser:
    """Resolve the authenticated principal for the current request."""
    return _load_authenticated_user(request)


def require_admin(user: AuthenticatedUser = Depends(require_current_user)) -> AuthenticatedUser:
    """Require an administrator principal."""
    if user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin privileges required")
    return user


def sanitize_user(user: dict) -> dict:
    """Expose a user record without credential material."""
    return _sanitize_user(user)


def apply_auth_cookies(response: Response, *, access_token: str, refresh_token: str, request: Request) -> None:
    """Attach auth cookies using the app runtime security mode."""
    secure = request.url.scheme == "https"
    _set_auth_cookies(response, access_token=access_token, refresh_token=refresh_token, secure=secure)
