"""Per-user settings routes for the web API."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from csg.application.use_cases.settings.manage_user_settings import (
    build_runtime_secrets,
    build_runtime_settings,
    clear_openai_secret,
    get_secret_status,
    get_user_settings,
    set_openai_secret,
    update_user_settings,
)
from csg.presentation.web.auth import require_current_user

router = APIRouter(prefix="/api/settings", tags=["settings"])


class UpdateSettingsRequest(BaseModel):
    default_branch: str = Field(default="main", min_length=1, max_length=255)
    max_file_size_kb: int = Field(default=100 * 1024, ge=1, le=1024 * 1024)
    embeddings_enabled: bool = True
    embedding_provider: str = Field(default="openai", min_length=1, max_length=32)
    ocr_provider: str = Field(default="openai", min_length=1, max_length=32)
    llm_provider: str = Field(default="openai", min_length=1, max_length=32)


class UpdateOpenAISecretRequest(BaseModel):
    api_key: str = Field(..., min_length=1, max_length=2048)


@router.get("/me")
async def get_my_settings(request: Request, current_user=Depends(require_current_user)):
    container = request.app.state.container
    return get_user_settings(
        user_id=current_user.id,
        settings_store=container.get_user_settings_store(),
    )


@router.put("/me")
async def put_my_settings(
    payload: UpdateSettingsRequest,
    request: Request,
    current_user=Depends(require_current_user),
):
    container = request.app.state.container
    try:
        return update_user_settings(
            user_id=current_user.id,
            payload=payload.model_dump(),
            settings_store=container.get_user_settings_store(),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/me/secrets/status")
async def get_my_secret_status(request: Request, current_user=Depends(require_current_user)):
    container = request.app.state.container
    return get_secret_status(
        user_id=current_user.id,
        secrets_store=container.get_user_secrets_store(),
    )


@router.put("/me/secrets/openai")
async def put_my_openai_secret(
    payload: UpdateOpenAISecretRequest,
    request: Request,
    current_user=Depends(require_current_user),
):
    container = request.app.state.container
    try:
        return set_openai_secret(
            user_id=current_user.id,
            api_key=payload.api_key,
            secrets_store=container.get_user_secrets_store(),
            cipher=container.get_secret_cipher(),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.delete("/me/secrets/openai")
async def delete_my_openai_secret(request: Request, current_user=Depends(require_current_user)):
    container = request.app.state.container
    deleted = clear_openai_secret(
        user_id=current_user.id,
        secrets_store=container.get_user_secrets_store(),
    )
    if not deleted:
        raise HTTPException(status_code=404, detail="OpenAI API key not configured")
    return {"status": "deleted"}


def resolve_runtime_context(container, user_id: str):
    """Build request-scoped runtime settings and secrets for downstream provider calls."""
    return (
        build_runtime_settings(user_id=user_id, settings_store=container.get_user_settings_store()),
        build_runtime_secrets(
            user_id=user_id,
            secrets_store=container.get_user_secrets_store(),
            cipher=container.get_secret_cipher(),
        ),
    )
