"""Agent route for v1 API: POST /v1/agent."""

from fastapi import APIRouter, Depends, HTTPException, Request, status

from csg.application.use_cases.agent.run_agent import run_agent
from csg.application.use_cases.repositories.list_repositories import list_repositories
from csg.presentation.web.auth import require_current_user
from csg.presentation.web.routes.settings import resolve_runtime_context
from csg.presentation.web.schemas import AgentRequest
from csg.infrastructure.runtime.user_context import bind_user_runtime

router = APIRouter()


@router.post("/ckg-agent",
            operation_id="ckg_agent",
            status_code=status.HTTP_200_OK,
            tags=["included"],
            summary="Run the CKG agent")
async def agent_endpoint(payload: AgentRequest, request: Request, current_user=Depends(require_current_user)):
    """Run the CKG agent. Exposed as MCP tool saleops_agent."""
    try:
        if payload.repo_id:
            repos = list_repositories(
                validate=False,
                repository_registry=request.app.state.container.get_repository_registry(),
            )
            target = next((repo for repo in repos if repo["id"] == payload.repo_id), None)
            if target is None:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Repository not found")
            owner_user_id = target.get("owner_user_id")
            if current_user.role != "admin" and owner_user_id not in (None, current_user.id):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Repository access denied")
        conversation_id = f"{current_user.id}:{payload.repo_id or 'global'}"
        runtime_settings, runtime_secrets = resolve_runtime_context(request.app.state.container, current_user.id)

        with bind_user_runtime(runtime_settings, runtime_secrets):
            return await run_agent(
                conversation_id=conversation_id,
                user_message=payload.user_message,
                agent_gateway=request.app.state.container.get_agent_gateway(),
                selected_node=payload.selected_node,
                repo_id=payload.repo_id,
            )
    except ModuleNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Agent runtime dependencies are not installed",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred: {exc}",
        ) from exc
