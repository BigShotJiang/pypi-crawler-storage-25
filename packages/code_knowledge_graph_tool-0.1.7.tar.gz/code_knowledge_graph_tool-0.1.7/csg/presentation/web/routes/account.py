"""Account self-service routes for the web API."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from csg.application.use_cases.account.manage_account import (
    change_password,
    change_username,
    soft_delete_account,
)
from csg.presentation.web.auth import require_current_user, sanitize_user

router = APIRouter(prefix="/api/account", tags=["account"])


class UpdateProfileRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=64)


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(..., min_length=1, max_length=256)
    new_password: str = Field(..., min_length=8, max_length=256)


@router.patch("/me/profile")
async def patch_my_profile(
    payload: UpdateProfileRequest,
    request: Request,
    current_user=Depends(require_current_user),
):
    container = request.app.state.container
    try:
        updated = change_username(
            user_id=current_user.id,
            username=payload.username,
            user_store=container.get_user_store(),
        )
    except ValueError as exc:
        message = str(exc)
        code = 409 if "exists" in message else 400
        raise HTTPException(status_code=code, detail=message) from exc
    return {"user": sanitize_user(updated)}


@router.post("/me/password")
async def post_my_password(
    payload: ChangePasswordRequest,
    request: Request,
    current_user=Depends(require_current_user),
):
    container = request.app.state.container
    try:
        change_password(
            user_id=current_user.id,
            current_password=payload.current_password,
            new_password=payload.new_password,
            user_store=container.get_user_store(),
            session_store=container.get_session_store(),
            password_hasher=container.get_password_hasher(),
        )
    except ValueError as exc:
        message = str(exc)
        status_code = 401 if "incorrect" in message else 400
        raise HTTPException(status_code=status_code, detail=message) from exc
    return {"status": "password_updated"}


@router.delete("/me")
async def delete_my_account(request: Request, current_user=Depends(require_current_user)):
    container = request.app.state.container
    soft_delete_account(
        user_id=current_user.id,
        user_store=container.get_user_store(),
        session_store=container.get_session_store(),
    )
    return {"status": "account_deleted"}
