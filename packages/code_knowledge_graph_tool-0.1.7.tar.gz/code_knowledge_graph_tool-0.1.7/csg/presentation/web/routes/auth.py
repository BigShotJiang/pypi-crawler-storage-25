"""Authentication routes for the web API."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response, status
from pydantic import BaseModel, Field

from csg.application.use_cases.auth.list_users import list_users as run_list_users
from csg.application.use_cases.repositories.list_repositories import list_repositories
from csg.presentation.web.auth import (
    apply_auth_cookies,
    clear_auth_cookies,
    login_and_issue_tokens,
    logout_current_session,
    refresh_tokens,
    register_and_login_user,
    require_admin,
    require_current_user,
    sanitize_user,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])
admin_router = APIRouter(prefix="/api/admin", tags=["admin"])


class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=64)
    email: str = Field(..., min_length=3, max_length=255)
    password: str = Field(..., min_length=8, max_length=256)


class LoginRequest(BaseModel):
    identifier: str = Field(..., min_length=3, max_length=255)
    password: str = Field(..., min_length=1, max_length=256)


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, request: Request, response: Response):
    user, access_token, refresh_token = register_and_login_user(
        username=payload.username,
        email=payload.email,
        password=payload.password,
        request=request,
    )
    apply_auth_cookies(response, access_token=access_token, refresh_token=refresh_token, request=request)
    return {"user": user}


@router.post("/login")
async def login(payload: LoginRequest, request: Request, response: Response):
    user, access_token, refresh_token = login_and_issue_tokens(
        identifier=payload.identifier,
        password=payload.password,
        request=request,
    )
    apply_auth_cookies(response, access_token=access_token, refresh_token=refresh_token, request=request)
    return {"user": user}


@router.post("/refresh")
async def refresh(request: Request, response: Response):
    user, access_token, refresh_token = refresh_tokens(request)
    apply_auth_cookies(response, access_token=access_token, refresh_token=refresh_token, request=request)
    return {"user": user}


@router.post("/logout")
async def logout(request: Request, response: Response, _user=Depends(require_current_user)):
    logout_current_session(request)
    clear_auth_cookies(response, secure=request.url.scheme == "https")
    return {"status": "logged_out"}


@router.get("/me")
async def me(request: Request, user=Depends(require_current_user)):
    full_user = request.app.state.container.get_user_store().get_by_id(user.id)
    return {"user": sanitize_user(full_user or user.__dict__)}


@admin_router.get("/users")
async def list_users(request: Request, _admin=Depends(require_admin)):
    users = run_list_users(user_store=request.app.state.container.get_user_store())
    return {"users": [sanitize_user(user) for user in users]}


@admin_router.get("/repos")
async def list_all_repos(request: Request, _admin=Depends(require_admin)):
    repos = list_repositories(
        validate=False,
        repository_registry=request.app.state.container.get_repository_registry(),
    )
    return {"repos": repos}
