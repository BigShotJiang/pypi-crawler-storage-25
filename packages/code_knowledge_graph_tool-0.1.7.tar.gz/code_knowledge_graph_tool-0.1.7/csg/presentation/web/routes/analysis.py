"""Presentation adapters for graph result serialization and caching."""

from __future__ import annotations

from typing import Any

from csg.bootstrap import get_container
from csg.application.use_cases.analysis.graph_results import (
    load_graph_json as _load_graph_json,
    save_graph_json as _save_graph_json,
    serialize_results,
)


def _resolve_storage_path(repo_path: str, container=None):
    active_container = container or get_container()
    return active_container.get_repository_registry().get_storage_path_for_repo(repo_path)


def save_graph_json(repo_path: str, results: dict[str, Any], container=None) -> str:
    """Save serialized graph results to the repository storage path."""
    return _save_graph_json(
        repo_path,
        results,
        storage_path_resolver=lambda path: _resolve_storage_path(path, container),
    )


def load_graph_json(repo_path: str, container=None) -> dict[str, Any] | None:
    """Load cached graph results from the repository storage path."""
    return _load_graph_json(
        repo_path,
        storage_path_resolver=lambda path: _resolve_storage_path(path, container),
    )


__all__ = ["serialize_results", "save_graph_json", "load_graph_json"]
