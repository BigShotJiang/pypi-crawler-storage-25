"""Inbound adapters subpackage."""
