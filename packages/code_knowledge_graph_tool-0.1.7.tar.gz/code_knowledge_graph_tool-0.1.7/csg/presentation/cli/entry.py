"""Canonical inbound CLI entrypoint."""

from __future__ import annotations

import asyncio
import importlib
import os
import sys
from pathlib import Path

import click
from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table

from csg.application.use_cases.analysis.io_models import RunPipelineRequest
from csg.application.use_cases.analysis.run_pipeline import run_pipeline_sync
from csg.application.use_cases.analysis.watch_repositories import get_repo_watcher
from csg.application.use_cases.agent_integration import install_agent_integration, setup_mcp_clients
from csg.application.use_cases.repositories.clean_repository_index import (
    clean_repository_index,
)
from csg.application.use_cases.repositories.get_repository_status import (
    get_repository_status,
)
from csg.application.use_cases.repositories.list_repositories import list_repositories
from csg.bootstrap import build_container

# Load .env from project root so all subcommands see env vars (API keys, etc.)
load_dotenv(Path(__file__).resolve().parents[4] / ".env")

console = Console()


def _load_attr(module_name: str, attr_name: str):
    module = importlib.import_module(module_name)
    return getattr(module, attr_name)


@click.group()
@click.version_option(package_name="code-knowledge-graph-tool", prog_name="csg")
def main():
    """CSG - Code Structure with Graph. Embedded graph-powered code intelligence."""
    pass


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--force", is_flag=True, help="Force re-analysis even if index exists")
@click.option("--embeddings", is_flag=True, help="Generate embeddings")
def analyze(path: str, force: bool, embeddings: bool):
    """Analyze a repository and build the code graph."""
    container = build_container()
    repository_registry = container.get_repository_registry()

    repo_path = os.path.abspath(path)
    if repository_registry.has_index_for_repo(repo_path) and not force:
        console.print(
            "[yellow]Index already exists.[/yellow] Use --force to re-analyze."
        )
        return

    console.print(f"[bold]Analyzing[/bold] {repo_path}")
    config = RunPipelineRequest(
        repo_path=repo_path,
        force=force,
        embeddings=embeddings,
    )
    with console.status("[bold green]Running pipeline..."):
        stats = run_pipeline_sync(config, runner=container.run_pipeline_sync)

    integration = install_agent_integration(repo_path, repo_name=Path(repo_path).name)

    console.print("\n[bold green]Analysis complete![/bold green]")
    table = Table(title="Index Stats")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")
    for key, value in stats.items():
        table.add_row(key, str(value))
    console.print(table)
    changed = len(integration["created"]) + len(integration["updated"])
    if changed:
        console.print(f"[green]Agent integration installed/updated ({changed} files).[/green]")
    else:
        console.print("[green]Agent integration already up to date.[/green]")


@main.command(name="setup-agents")
@click.argument("path", default=".", type=click.Path(file_okay=False, dir_okay=True))
@click.option("--repo-name", default="", help="Repository name used in generated CSG resource URIs")
def setup_agents(path: str, repo_name: str):
    """Install Codex and Claude Code CSG instruction, skill, and hook files."""
    target = Path(path).resolve()
    result = install_agent_integration(target, repo_name=repo_name or target.name)
    changed = len(result["created"]) + len(result["updated"])
    console.print(f"[green]Agent integration installed[/green] at {target}")
    console.print(f"Created: {len(result['created'])}, updated: {len(result['updated'])}, changed: {changed}")


@main.command(name="setup")
@click.argument("path", default=".", type=click.Path(file_okay=False, dir_okay=True))
@click.option("--repo-name", default="", help="Repository name used in generated CSG resource URIs")
def setup(path: str, repo_name: str):
    """Install local agent files and register the CSG MCP server with detected CLIs."""
    target = Path(path).resolve()
    integration = install_agent_integration(target, repo_name=repo_name or target.name)
    changed = len(integration["created"]) + len(integration["updated"])
    console.print(f"[green]Agent files installed[/green] at {target}")
    console.print(f"Created: {len(integration['created'])}, updated: {len(integration['updated'])}, changed: {changed}")

    mcp_results = setup_mcp_clients()
    console.print("\nMCP client registration:")
    for agent, status in mcp_results.items():
        console.print(f"  {agent}: {status['status']} - {status.get('message', '')}")


@main.command()
@click.option("--db-path", default=None, help="Path to the local database directory")
@click.option(
    "--transport",
    type=click.Choice(["stdio", "http"]),
    default="stdio",
    help="Transport type: stdio (default) or http",
)
@click.option("--port", default=8080, type=int, help="Port for HTTP transport")
def mcp(db_path: str | None, transport: str, port: int):
    """Start the MCP server."""
    if db_path is None:
        container = build_container()
        db_path = str(container.get_repository_registry().get_storage_path_for_repo(os.getcwd()) / "lbug")

    if transport == "stdio":
        run_stdio_server = _load_attr(
            "csg.presentation.mcp.stdio_runner", "run_stdio_server"
        )
        asyncio.run(run_stdio_server(db_path=db_path))
    else:
        run_http_server = _load_attr(
            "csg.presentation.mcp.http_transport", "run_http_server"
        )
        console.print(f"[bold]Starting MCP HTTP server[/bold] on port {port}")
        asyncio.run(run_http_server(db_path=db_path, port=port))


@main.command(name="list")
def list_repos():
    """List all indexed repositories."""
    container = build_container()
    repos = list_repositories(validate=False, repository_registry=container.get_repository_registry())
    if not repos:
        console.print("[yellow]No indexed repositories found.[/yellow]")
        return

    table = Table(title="Indexed Repositories")
    table.add_column("Name", style="cyan")
    table.add_column("Path", style="white")
    table.add_column("Indexed At", style="green")
    for repo in repos:
        table.add_row(str(repo.get("name", "")), str(repo.get("path", "")), str(repo.get("indexed_at", "")))
    console.print(table)


@main.command()
def status():
    """Show index status for the current repository."""
    repo_path = os.getcwd()
    container = build_container()
    status_payload = get_repository_status(repo_path, repository_registry=container.get_repository_registry())
    if not status_payload.get("exists"):
        console.print("[yellow]No index found for this directory.[/yellow]")
        console.print("Run [bold]csg analyze[/bold] to create one.")
        return

    meta = status_payload["meta"]
    staleness = status_payload["staleness"]
    table = Table(title="Index Status")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="white")
    table.add_row("Commit", str(meta.get("commit", "unknown"))[:8])
    table.add_row("Files", str(meta.get("files", 0)))
    table.add_row("Nodes", str(meta.get("nodes", 0)))
    table.add_row("Relationships", str(meta.get("relationships", 0)))
    table.add_row("Communities", str(meta.get("communities", 0)))
    table.add_row("Processes", str(meta.get("processes", 0)))
    table.add_row("Embeddings", str(meta.get("embeddings", 0)))
    if staleness["is_stale"]:
        table.add_row("Status", "[red]STALE[/red]")
        table.add_row("Message", staleness["message"])
    else:
        table.add_row("Status", "[green]UP TO DATE[/green]")
    console.print(table)


@main.command()
@click.option("--host", default="127.0.0.1", help="Bind host")
@click.option("--port", default=8080, type=int, help="Bind port")
def web(host: str, port: int):
    """Start the web UI for uploading and analyzing codebases."""
    try:
        import uvicorn
    except ImportError:
        console.print(
            "[red]Missing web dependencies.[/red] Install with: pip install csg[web]"
        )
        sys.exit(1)
    console.print(f"[bold]Starting CSG Web UI[/bold] at http://{host}:{port}")
    uvicorn.run("csg.presentation.web.app:app", host=host, port=port, log_level="info")


@main.command()
def clean():
    """Delete the index for the current repository."""
    repo_path = os.getcwd()
    container = build_container()
    repository_registry = container.get_repository_registry()
    status_payload = get_repository_status(repo_path, repository_registry=repository_registry)
    if not status_payload.get("exists"):
        console.print("[yellow]No index found for this directory.[/yellow]")
        return

    if click.confirm("Delete the CSG index for this repository?"):
        clean_repository_index(repo_path, repository_registry=repository_registry)
        console.print("[green]Index deleted.[/green]")


@main.command()
@click.option("-n", "--lines", default=50, type=int, help="Number of recent lines to show")
@click.option("-f", "--follow", is_flag=True, help="Follow log output in real time")
def logs(lines: int, follow: bool):
    """Show MCP server logs."""
    default_log_path = _load_attr(
        "csg.presentation.mcp.logging_setup", "_default_log_path"
    )
    log_file = Path(os.environ.get("CSG_LOG_FILE", default_log_path()))
    if not log_file.exists():
        console.print("[yellow]No log file found.[/yellow] Start the MCP server first.")
        return

    with open(log_file, encoding="utf-8") as file_handle:
        all_lines = file_handle.readlines()
    for line in all_lines[-lines:]:
        sys.stdout.write(line)
    if not follow:
        return

    import time
    try:
        with open(log_file, encoding="utf-8") as file_handle:
            file_handle.seek(0, 2)
            while True:
                line = file_handle.readline()
                if line:
                    sys.stdout.write(line)
                    sys.stdout.flush()
                else:
                    time.sleep(0.3)
    except KeyboardInterrupt:
        pass


@main.command()
@click.option("--interval", default=30, type=int, help="Poll interval in seconds")
@click.option(
    "--debounce",
    default=5.0,
    type=float,
    help="Debounce filesystem events in seconds",
)
def watch(interval: int, debounce: float):
    """Watch indexed repos for changes and auto re-ingest."""
    container = build_container()
    repos = list_repositories(validate=True, repository_registry=container.get_repository_registry())
    if not repos:
        console.print("[yellow]No indexed repositories to watch.[/yellow]")
        console.print("Run [bold]csg analyze[/bold] first.")
        return

    console.print(f"[bold]Watching {len(repos)} repo(s)[/bold] (debounce={debounce}s)")
    for repo in repos:
        console.print(f"  - {repo.get('name')} ({repo.get('path')})")

    container = build_container()
    watcher = get_repo_watcher(
        interval=interval,
        debounce=debounce,
        watcher_factory=container.get_repo_watcher,
    )
    watcher.start()
    try:
        import signal
        signal.pause()
    except (KeyboardInterrupt, AttributeError):
        try:
            while watcher.is_running:
                import time
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    watcher.stop()
    console.print("[green]Watcher stopped.[/green]")


def run() -> None:
    """Run canonical CLI entrypoint via composition root."""
    build_container()
    main()


__all__ = ["main", "run"]
