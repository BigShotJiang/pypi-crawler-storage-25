"""MCP resource content formatters.

Builder functions that produce formatted content for each resource.
Registration happens in factory.py via @server.resource() decorators.
"""

from __future__ import annotations

import json
import logging

from csg.presentation.mcp.backend import Backend

logger = logging.getLogger(__name__)


def build_context_resource(backend: Backend, repo_name: str, container=None) -> str:
    """Repo overview with stats and staleness check.

    Args:
        backend: MCP backend instance
        repo_name: Repository name
        container: Optional container. If not provided, will be obtained from backend
    """
    if container is None:
        # Get container from backend if available
        if hasattr(backend, 'container'):
            container = backend.container
        else:
            from csg.bootstrap import get_container
            container = get_container()

    NODE_TABLES, escape_table_name = container.get_lbug_schema_primitives()

    lines = [f"project: {repo_name}"]

    # Staleness check
    try:
        from csg.presentation.mcp.staleness import check_staleness
        entry = container.get_repository_registry().get_repo_entry_by_name(repo_name) if repo_name else None
        if entry:
            staleness = check_staleness(entry.path, repository_registry=container.get_repository_registry())
            if staleness["is_stale"]:
                lines.append(f'staleness: "{staleness["message"]}"')
            else:
                lines.append("staleness: up to date")
    except Exception:
        pass

    # Node stats
    lines.append("")
    lines.append("stats:")
    for table in NODE_TABLES:
        tn = escape_table_name(table)
        try:
            rows = backend._query(
                f"MATCH (n:{tn}) RETURN count(n) AS cnt"
            )
            cnt = rows[0]["cnt"] if rows else 0
            if cnt > 0:
                lines.append(f"  {table}: {cnt}")
        except Exception:
            pass

    # Available tools
    lines.append("")
    lines.append("tools_available:")
    lines.append("  - csg_explore: 6-layer knowledge graph retrieval (use layer= to target: topology, relevance, context, crosscut, contract, implementation)")
    lines.append("  - csg_context: 360-degree symbol view (callers, callees, processes, signature)")
    lines.append("  - csg_impact: Blast radius analysis")
    lines.append("  - csg_detect_changes: Git-diff impact analysis")
    lines.append("  - csg_rename: Multi-file coordinated rename")
    lines.append("  - csg_list_repos: Discover repositories")
    lines.append("  - csg_analyze: Ingest/index a repository")

    # Available resources
    lines.append("")
    lines.append("resources_available:")
    lines.append(f"  - csg://repo/{repo_name}/clusters: All functional areas")
    lines.append(f"  - csg://repo/{repo_name}/processes: All execution flows")
    lines.append(f"  - csg://repo/{repo_name}/schema: Graph schema for Cypher")

    lines.append("")
    lines.append("re_index: Run `csg analyze` if data is stale")

    return "\n".join(lines)


def build_clusters_resource(backend: Backend) -> str:
    """All functional areas (communities) with cohesion and members."""
    result = backend.cypher(
        "MATCH (c:Community) "
        "RETURN c.id AS id, c.name AS name, c.heuristicLabel AS label, "
        "c.symbolCount AS symbolCount, c.cohesion AS cohesion "
        "ORDER BY c.symbolCount DESC"
    )
    clusters = result.get("results", [])
    if not clusters:
        return "modules: []\n# No functional areas detected. Run: csg analyze"

    lines = ["modules:"]
    for cluster in clusters[:20]:
        label = cluster.get("label") or cluster.get("name") or cluster.get("id", "?")
        lines.append(f'  - name: "{label}"')
        lines.append(f"    symbols: {cluster.get('symbolCount', 0)}")
        cohesion = cluster.get("cohesion")
        if cohesion is not None:
            lines.append(f"    cohesion: {float(cohesion) * 100:.0f}%")

        # Top-5 member preview
        try:
            cid = cluster.get("id", "")
            members = backend._query(
                "MATCH (s)-[r:CodeRelation]->(c:Community) "
                "WHERE r.type = 'MEMBER_OF' AND c.id = $cid "
                "RETURN s.name AS name, label(s) AS type "
                "LIMIT 5",
                {"cid": cid},
            )
            if members:
                member_names = [f'{m["name"]} ({m["type"]})' for m in members]
                lines.append(f"    members: [{', '.join(member_names)}]")
        except Exception:
            pass

    if len(clusters) > 20:
        lines.append(
            f"\n# Showing top 20 of {len(clusters)} modules. "
            "Use csg_explore for deeper search."
        )

    return "\n".join(lines)


def build_processes_resource(backend: Backend) -> str:
    """All execution flows grouped by type."""
    result = backend.cypher(
        "MATCH (p:Process) "
        "RETURN p.id AS id, p.name AS name, p.heuristicLabel AS label, "
        "p.stepCount AS stepCount, p.processType AS processType "
        "ORDER BY p.stepCount DESC"
    )
    processes = result.get("results", [])
    if not processes:
        return "processes: []\n# No processes detected. Run: csg analyze"

    # Group by type
    cross = [p for p in processes if p.get("processType") == "cross_community"]
    intra = [p for p in processes if p.get("processType") != "cross_community"]

    lines = ["processes:"]

    if cross:
        lines.append("  cross_community:")
        for proc in cross[:10]:
            label = proc.get("label") or proc.get("name") or proc.get("id", "?")
            lines.append(f'    - name: "{label}"')
            lines.append(f"      steps: {proc.get('stepCount', 0)}")

    if intra:
        lines.append("  intra_community:")
        for proc in intra[:10]:
            label = proc.get("label") or proc.get("name") or proc.get("id", "?")
            lines.append(f'    - name: "{label}"')
            lines.append(f"      steps: {proc.get('stepCount', 0)}")

    total = len(processes)
    shown = min(len(cross), 10) + min(len(intra), 10)
    if total > shown:
        lines.append(f"\n# Showing {shown} of {total} processes. Use csg_explore for deeper search.")

    return "\n".join(lines)


def build_process_detail_resource(backend: Backend, process_name: str) -> str:
    """Step-by-step execution trace for a specific process."""
    result = backend._query(
        "MATCH (n)-[r:CodeRelation]->(p:Process) "
        "WHERE r.type = 'STEP_IN_PROCESS' AND p.name = $name "
        "RETURN n.id AS id, n.name AS name, label(n) AS type, "
        "n.filePath AS filePath, r.reason AS step "
        "ORDER BY r.reason",
        {"name": process_name},
    )

    if not result:
        return json.dumps({"error": f"Process '{process_name}' not found or has no steps."})

    lines = [
        f'name: "{process_name}"',
        f"step_count: {len(result)}",
        "",
        "trace:",
    ]
    for step in result:
        name = step.get("name", "?")
        fpath = step.get("filePath", "?")
        stype = step.get("type", "?")
        step_num = step.get("step", "?")
        lines.append(f"  {step_num}: {name} ({stype}) — {fpath}")

    return "\n".join(lines)


def build_schema_resource() -> str:
    """Graph schema for Cypher queries — derived from the actual type definitions."""
    from csg.domain.codebase.value_objects import RelationshipType

    _REL_DESCRIPTIONS: dict[str, str] = {
        "CONTAINS": "File/Folder contains child",
        "CALLS": "Function/method invocation (with confidence)",
        "IMPORTS": "Module imports",
        "EXTENDS": "Class inheritance",
        "IMPLEMENTS": "Interface/trait implementation",
        "HAS_METHOD": "Class/Struct/Interface owns a Method",
        "HAS_PROPERTY": "Class/Struct owns a Property",
        "ACCESSES": "Function reads/writes a Property",
        "OVERRIDES": "Method overrides a parent method (MRO)",
        "MEMBER_OF": "Symbol belongs to community",
        "STEP_IN_PROCESS": "Symbol is step N in execution process",
        "DESCRIBES": "Section/docstring describes a symbol",
        "DOCUMENTED_BY": "Symbol is documented by a section",
        "COMMUNITY_INTERACTS": "Community interacts with another community",
        "INHERITS": "Inheritance relationship",
        "USES": "Symbol uses another symbol",
        "DEFINES": "File defines a symbol",
        "DECORATES": "Decorator applied to a symbol",
    }

    rel_lines = []
    for r in RelationshipType:
        desc = _REL_DESCRIPTIONS.get(r.value, r.value)
        rel_lines.append(f"  - {r.value}: {desc}")

    rel_section = "\n".join(rel_lines)

    return f"""# CSG Graph Schema

nodes:
  - File: Source code files
  - Folder: Directory containers
  - Function: Functions and arrow functions
  - Class: Class definitions
  - Interface: Interface/type definitions
  - Method: Class methods
  - CodeElement: Catch-all for other code elements
  - Community: Auto-detected functional area (Leiden algorithm)
  - Process: Execution flow trace
  - Section: Markdown/doc sections
  - Struct, Enum, Macro, Typedef, Union, Namespace
  - Trait, Impl, TypeAlias, Const, Static
  - Property, Record, Delegate, Annotation, Constructor, Template, Module

node_properties:
  common: "name (STRING), filePath (STRING), startLine (INT32), endLine (INT32)"
  Method: "parameterCount (INT32), returnType (STRING)"
  Function: "parameterCount (INT32), returnType (STRING)"
  Community: "heuristicLabel (STRING), cohesion (DOUBLE), symbolCount (INT32), keywords (STRING[])"
  Process: "heuristicLabel (STRING), processType (STRING), stepCount (INT32), communities (STRING[])"

relationships:
{rel_section}

relationship_table: "All relationships use CodeRelation table with properties: type (STRING), confidence (DOUBLE), reason (STRING), step (STRING), inCycle (BOOLEAN), reviewLabel (STRING, nullable)"

example_queries:
  find_callers: |
    MATCH (caller)-[:CodeRelation {{type: 'CALLS'}}]->(f:Function {{name: "myFunc"}})
    RETURN caller.name, caller.filePath

  find_community_members: |
    MATCH (s)-[:CodeRelation {{type: 'MEMBER_OF'}}]->(c:Community)
    WHERE c.heuristicLabel = "Auth"
    RETURN s.name, labels(s)[0] AS type

  trace_process: |
    MATCH (s)-[r:CodeRelation {{type: 'STEP_IN_PROCESS'}}]->(p:Process)
    WHERE p.heuristicLabel = "LoginFlow"
    RETURN s.name, r.step
    ORDER BY r.step

  find_class_methods: |
    MATCH (c:Class {{name: "UserService"}})-[r:CodeRelation {{type: 'HAS_METHOD'}}]->(m:Method)
    RETURN m.name, m.parameterCount, m.returnType
"""
