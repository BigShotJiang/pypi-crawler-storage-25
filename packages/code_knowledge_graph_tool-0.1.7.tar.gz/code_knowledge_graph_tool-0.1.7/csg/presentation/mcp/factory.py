"""MCP server factory — transport-agnostic.

Creates a fully configured FastMCP server with tools, resources, and prompts
registered via decorators. The caller attaches a transport (stdio or HTTP).
"""

from __future__ import annotations

import importlib
import json
import logging
import sys
import time
from typing import Annotated

from pydantic import Field
from mcp.server.fastmcp import FastMCP

from csg.application.use_cases.sources.process_documents import process_documents_sync
from csg.bootstrap import build_container

logger = logging.getLogger(__name__)

from csg.presentation.mcp.backend import Backend
LadybugAdapter = object

_REPO_DESC = (
    "Repository name to query. Leave empty for the default repo. "
    "Use csg_list_repos to see available repos."
)

_INSTRUCTIONS = (
    "CSG is a code intelligence server that builds a knowledge graph "
    "from source code and exposes it for search, navigation, and "
    "impact analysis.\n\n"
    "## Workflow\n"
    "1. `csg_explore` — 6 independent retrieval layers. Use `layer=` "
    "to jump directly to any layer:\n"
    "   - `layer='topology'` → community map (names, sizes, cohesion, topMembers)\n"
    "   - `layer='relevance', query='...'` → BM25+semantic search grouped by community\n"
    "   - `layer='context', scope='community:<name>'` → execution flows + symbols\n"
    "   - `layer='crosscut'` → cycles, shared symbols, duplicates\n"
    "   - `layer='contract', query='sym1, sym2'` → signatures, callers, callees\n"
    "   - `layer='implementation', query='sym1, sym2'` → source code\n"
    "   - Omit `layer` for auto mode (chains layers by confidence).\n"
    "2. `csg_context(symbol)` — 360° view of a specific symbol: "
    "callers, callees, processes, signature, heritage, overrides, "
    "and full source code.\n"
    "3. `csg_impact(target)` — Blast radius analysis. "
    "Risk levels: CRITICAL/HIGH/MEDIUM/LOW.\n"
    "4. `csg_detect_changes()` — Pre-commit review. Maps git diff to "
    "affected symbols.\n"
    "5. `csg_rename(symbol_name, new_name)` — Graph-aware rename. "
    "Always dry_run first.\n\n"
    "## Tips\n"
    "- Each layer is independent — you can jump to `layer='implementation'` "
    "directly if you already know the symbol names.\n"
    "- Follow hints in each response — they suggest the next step.\n"
    "- `csg_list_repos()` to discover indexed repos. "
    "`csg_analyze(path)` to index a new one.\n"
    "- `csg_srs()` to generate an SRS document. For best results: "
    "gather context layer by layer with csg_explore, then pass it "
    "as the 'context' param.\n"
    "- Response confidence: strong (trust it), moderate (verify), "
    "weak (broaden your search)."
)


def _log(msg: str) -> None:
    """Write a status line to stderr so MCP clients can see progress."""
    print(f"[csg-mcp] {msg}", file=sys.stderr, flush=True)


def _format_result(tool_name: str, args: dict, result: dict) -> str:
    """JSON-serialize result and append next-step hint."""
    result_text = json.dumps(result, default=str)
    hint = _load_next_step_hint(tool_name, args, result)
    if hint:
        result_text += f"\n\n---\n{hint}"
    return result_text


def _load_next_step_hint(tool_name: str, args: dict, result: dict) -> str:
    """Load hint builder from canonical path."""
    module = importlib.import_module("csg.presentation.mcp.hints")
    return module.get_next_step_hint(tool_name, args, result)


def create_mcp_server(backend: Backend, adapter: LadybugAdapter | None = None) -> FastMCP:
    """Create FastMCP server with all tools, resources, prompts registered.

    Args:
        backend: Backend instance wrapping the LadybugDB adapter.
        adapter: Deprecated — no longer used.

    Returns:
        Configured FastMCP server ready to connect to any transport.
    """
    server = FastMCP(name="csg", instructions=_INSTRUCTIONS)

    _register_tools(server, backend)
    _register_resources(server, backend)
    _register_prompts(server)

    _log("server ready — 10 tools, 5 resources, 3 prompts")
    return server


# ── Tools ──────────────────────────────────────────────────────────────


def _register_tools(server: FastMCP, backend: Backend) -> None:
    """Register all 9 tools on the FastMCP server."""

    @server.tool(
        name="csg_explore",
        description=(
            "Search and explore the codebase through a 6-layer knowledge graph.\n\n"
            "LAYER MODE (independent — you control each step):\n"
            "- layer='topology'        → L0: community map (names, sizes, cohesion, topMembers)\n"
            "- layer='relevance'       → L1: BM25+semantic search grouped by community (requires query)\n"
            "- layer='context'         → L2: execution flows + symbols (requires scope='community:<name>' or 'file:<path>')\n"
            "- layer='crosscut'        → L3: cycles, shared symbols, duplicates (optional query)\n"
            "- layer='contract'        → L4: signatures, callers, callees, heritage (query=comma-separated symbol names)\n"
            "- layer='implementation'  → L5: source code (query=comma-separated symbol names)\n\n"
            "AUTO MODE (no layer — chains layers by confidence):\n"
            "- No args → topology.\n"
            "- query only → relevance → auto context/crosscut/contract by signal strength.\n"
            "- scope='community:<name>' → context + auto contract.\n"
            "- scope='symbol:<name>' → 360° view with source code (same as csg_context).\n\n"
            "RESPONSE SIGNALS: _meta.search.signal = strong/moderate/weak.\n"
            "WHEN TO USE: Understanding code, finding implementations, tracing features.\n"
            "AFTER THIS: Use csg_context() on specific symbols, or call the next layer."
        ),
    )
    def csg_explore(
        query: Annotated[str, Field(default="", description="Question or search query. For contract/implementation layers: comma-separated symbol names.")] = "",
        scope: Annotated[str, Field(default="", description="Optional scope: 'community:<name>', 'file:<path>', or 'symbol:<name>'. Required for context layer.")] = "",
        layer: Annotated[str, Field(default="", description="Run a specific layer independently: topology, relevance, context, crosscut, contract, implementation. Empty = auto mode.")] = "",
        repo: Annotated[str, Field(default="", description=_REPO_DESC)] = "",
    ) -> str:
        t0 = time.perf_counter()
        try:
            with backend._scoped_repo(repo or None):
                result = backend.explore_auto(query=query, scope=scope, layer=layer)
        except Exception as e:
            logger.exception("ERROR csg_explore | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_explore | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_explore", {"query": query, "scope": scope, "layer": layer, "repo": repo}, result)

    @server.tool(
        name="csg_context",
        description=(
            "360-degree view of a specific symbol: callers, callees, processes, "
            "signature, heritage, overrides, and full source code.\n\n"
            "DISAMBIGUATION: When multiple symbols share the same name, "
            "the response includes a candidates[] list with file paths. "
            "Re-query with csg_explore(scope='file:<path>') to target a specific one.\n\n"
            "WHEN TO USE: You have a symbol name and want its full context.\n"
            "AFTER THIS: Use csg_impact() to check blast radius before changes."
        ),
    )
    def csg_context(
        symbol: Annotated[str, Field(description="Symbol name to inspect.")],
        repo: Annotated[str, Field(default="", description=_REPO_DESC)] = "",
    ) -> str:
        t0 = time.perf_counter()
        try:
            with backend._scoped_repo(repo or None):
                result = backend.context_360(symbol)
        except Exception as e:
            logger.exception("ERROR csg_context | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_context | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_context", {"symbol": symbol, "repo": repo}, result)

    @server.tool(
        name="csg_impact",
        description=(
            "Blast radius analysis before editing a symbol. "
            "Returns affected symbols grouped by depth with risk assessment.\n\n"
            "RISK LEVELS: CRITICAL (d1>=30 or processes>=5), HIGH (d1>=15 or processes>=3), "
            "MEDIUM (d1>=5), LOW (d1<5).\n\n"
            "WHEN TO USE: Before making code changes — shows what would break.\n"
            "AFTER THIS: Review d=1 items (WILL BREAK). Use csg_detect_changes() for git diff."
        ),
    )
    def csg_impact(
        target: Annotated[str, Field(description="Symbol name to analyze")],
        direction: Annotated[str, Field(default="upstream", description="'upstream' (callers) or 'downstream' (callees)")] = "upstream",
        repo: Annotated[str, Field(default="", description=_REPO_DESC)] = "",
    ) -> str:
        t0 = time.perf_counter()
        try:
            with backend._scoped_repo(repo or None):
                result = backend.impact(target, direction)
        except Exception as e:
            logger.exception("ERROR csg_impact | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_impact | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_impact", {"target": target, "direction": direction, "repo": repo}, result)

    @server.tool(
        name="csg_detect_changes",
        description=(
            "Analyze uncommitted git changes and find affected symbols and execution flows.\n\n"
            "REQUIRES: The indexed repo must be a git repository with commits.\n\n"
            "WHEN TO USE: Pre-commit review, PR preparation on real git repos.\n"
            "AFTER THIS: Use csg_impact() on high-risk symbols found."
        ),
    )
    def csg_detect_changes(
        scope: Annotated[str, Field(default="all", description="'all', 'staged', 'unstaged', or 'compare'")] = "all",
        base_ref: Annotated[str, Field(default="", description="Base ref for 'compare' scope")] = "",
        repo: Annotated[str, Field(default="", description=_REPO_DESC)] = "",
    ) -> str:
        t0 = time.perf_counter()
        try:
            with backend._scoped_repo(repo or None):
                result = backend.detect_changes(scope, base_ref)
        except Exception as e:
            logger.exception("ERROR csg_detect_changes | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_detect_changes | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_detect_changes", {"scope": scope, "base_ref": base_ref, "repo": repo}, result)

    @server.tool(
        name="csg_rename",
        description=(
            "Graph-aware multi-file symbol rename with dry_run preview.\n\n"
            "Always dry_run=true first. candidates[] shows alternatives when ambiguous.\n\n"
            "WHEN TO USE: Renaming across the codebase. Safer than find-and-replace.\n"
            "AFTER THIS: Run csg_detect_changes() to verify."
        ),
    )
    def csg_rename(
        symbol_name: Annotated[str, Field(description="Current symbol name")],
        new_name: Annotated[str, Field(description="New name")],
        dry_run: Annotated[bool, Field(default=True, description="Preview changes without applying")] = True,
        repo: Annotated[str, Field(default="", description=_REPO_DESC)] = "",
    ) -> str:
        t0 = time.perf_counter()
        try:
            with backend._scoped_repo(repo or None):
                result = backend.rename(symbol_name, new_name, dry_run)
        except Exception as e:
            logger.exception("ERROR csg_rename | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_rename | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_rename", {"symbol_name": symbol_name, "new_name": new_name, "dry_run": dry_run, "repo": repo}, result)

    @server.tool(
        name="csg_list_repos",
        description=(
            "List all indexed repositories with stats.\n\n"
            "WHEN TO USE: First step to discover available repos.\n"
            "AFTER THIS: Use csg_explore() to navigate any repo."
        ),
    )
    def csg_list_repos() -> str:
        t0 = time.perf_counter()
        try:
            result = backend.list_repos()
        except Exception as e:
            logger.exception("ERROR csg_list_repos | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_list_repos | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_list_repos", {}, result)

    @server.tool(
        name="csg_analyze",
        description=(
            "Ingest / index a repository so it becomes queryable by all other tools.\n"
            "Accepts a directory path or a .zip file (auto-extracted).\n\n"
            "BATCH MODE: Pass 'paths' (list) to index multiple repos in one call.\n\n"
            "WHEN TO USE: Before any other tool — the repo must be indexed first.\n"
            "AFTER THIS: Use csg_list_repos() to verify, then csg_explore() to navigate."
        ),
    )
    def csg_analyze(
        path: Annotated[str, Field(description="Path to the repository directory or a .zip file to analyze.")] = "",
        paths: Annotated[list[str] | None, Field(description="List of paths to ingest in batch.")] = None,
        exclude: Annotated[list[str] | None, Field(description="Directory names to exclude from indexing.")] = None,
        force: Annotated[bool, Field(description="Re-analyze even if an index already exists.")] = False,
        embeddings: Annotated[bool, Field(description="Generate semantic embeddings (enables semantic search).")] = True,
    ) -> str:
        t0 = time.perf_counter()
        paths = paths or []
        exclude = exclude or []
        try:
            result = Backend.analyze(
                path=path, force=force, embeddings=embeddings,
                exclude=exclude, paths=paths or None,
            )
        except Exception as e:
            logger.exception("ERROR csg_analyze | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_analyze | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_analyze", {"path": path, "force": force}, result)

    @server.tool(
        name="csg_delete",
        description=(
            "Delete indexed repositories from the registry and optionally clean up "
            "storage on disk. Supports deleting a single repo by name or all repos.\n\n"
            "WHEN TO USE: Removing stale or unwanted repos from the index.\n"
            "AFTER THIS: Use csg_list_repos() to verify removal."
        ),
    )
    def csg_delete(
        repo: Annotated[str, Field(default="", description="Repository name to delete. Leave empty with delete_all=true to remove all repos.")] = "",
        clean_storage: Annotated[bool, Field(default=True, description="Also delete the storage directory on disk.")] = True,
        delete_all: Annotated[bool, Field(default=False, description="Delete ALL indexed repositories.")] = False,
    ) -> str:
        t0 = time.perf_counter()
        try:
            result = Backend.delete_repo(repo, clean_storage, delete_all)
        except Exception as e:
            logger.exception("ERROR csg_delete | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_delete | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_delete", {"repo": repo, "delete_all": delete_all}, result)

    @server.tool(
        name="csg_srs",
        description=(
            "Generate a Software Requirements Specification (SRS) document.\n\n"
            "RECOMMENDED WORKFLOW: First gather context with csg_explore + csg_context, "
            "then pass it as the 'context' parameter. The tool also auto-gathers context.\n\n"
            "RETURNS: srs_markdown, srs_md_path, docx_path, success, message.\n\n"
            "REQUIRES: a user-scoped OpenAI API key saved in Settings.\n\n"
            "WHEN TO USE: After indexing a repo, when the user requests an SRS."
        ),
    )
    def csg_srs(
        repo: Annotated[str, Field(default="", description=_REPO_DESC)] = "",
        context: Annotated[str, Field(default="", description="Additional context gathered by the agent.")] = "",
    ) -> str:
        t0 = time.perf_counter()
        try:
            with backend._scoped_repo(repo or None):
                result = backend.generate_srs(extra_context=context)
        except Exception as e:
            logger.exception("ERROR csg_srs | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_srs | %.3fs", time.perf_counter() - t0)
        return _format_result("csg_srs", {"repo": repo, "context": context}, result)

    @server.tool(
        name="csg_analyze_docs",
        description=(
            "Ingest business documents (Word, PDF, Excel, PowerPoint, email, HTML, etc.) "
            "into a separate document knowledge graph associated with a code repository.\n\n"
            "Supports 91+ file formats. Documents are converted to markdown, cleaned "
            "(emoji/icons removed), sectioned by headings, and stored in a dedicated "
            "document database separate from the code graph.\n\n"
            "WHEN TO USE: After indexing a code repo, to add related design docs, specs, etc.\n"
            "AFTER THIS: Use csg_explore(include_docs=true) to search across code and docs."
        ),
    )
    def csg_analyze_docs(
        path: Annotated[str, Field(description="Path to a document file or directory containing documents.")],
        repo: Annotated[str, Field(default="", description="Associate documents with this code repo. Leave empty for default repo.")] = "",
    ) -> str:
        t0 = time.perf_counter()
        try:
            result = _run_doc_ingestion(path, repo, backend)
        except Exception as e:
            logger.exception("ERROR csg_analyze_docs | %s", e)
            return json.dumps({"error": str(e)}, default=str)
        logger.info("OK csg_analyze_docs | %.3fs", time.perf_counter() - t0)
        return json.dumps(result, default=str)


def _run_doc_ingestion(path: str, repo: str, backend: Backend) -> dict:
    """Execute document ingestion pipeline."""
    import os
    from pathlib import Path as P

    from csg.application.config.ingestion import (
        DOCUMENT_EXTENSIONS,
        MAX_DOCUMENT_FILE_SIZE,
    )
    container = build_container()
    # Resolve repo
    repository_registry = container.get_repository_registry()
    entry = repository_registry.get_repo_entry_by_name(repo) if repo else None
    if entry:
        repo_path = entry.path
        storage = P(entry.storage_path)
    else:
        # Use default repo or the path's parent
        repo_path = path
        storage = repository_registry.get_storage_path_for_repo(path)

    # Find document files
    target = P(path)
    if target.is_file():
        doc_paths = [str(target.relative_to(repo_path))] if target.suffix.lower() in DOCUMENT_EXTENSIONS else []
    elif target.is_dir():
        doc_paths = []
        for root, _, files in os.walk(target):
            for f in files:
                fp = P(root) / f
                ext = fp.suffix.lower()
                if ext in DOCUMENT_EXTENSIONS and fp.stat().st_size <= MAX_DOCUMENT_FILE_SIZE:
                    try:
                        doc_paths.append(str(fp.relative_to(repo_path)))
                    except ValueError:
                        doc_paths.append(str(fp))
    else:
        return {"error": f"Path not found: {path}"}

    if not doc_paths:
        return {"error": f"No document files found at: {path}"}

    # Setup docs adapter
    docs_db_path = str(storage / "docs")
    docs_adapter_cls = container.get_docs_adapter_class()
    adapter = docs_adapter_cls(docs_db_path)
    adapter.connect(read_only=False)
    adapter.create_schema()

    # Run ingestion
    result = process_documents_sync(
        doc_paths=doc_paths,
        repo_path=repo_path,
        docs_adapter=adapter,
        processor=container.get_source_provider().process_documents,
    )

    # Create FTS indexes
    adapter.create_fts_indexes()

    return {
        "status": "ok",
        "files_processed": result.files_processed,
        "sections_created": result.sections_created,
        "errors": result.errors,
        "docs_db": docs_db_path,
    }


# ── Resources ──────────────────────────────────────────────────────────


def _register_resources(server: FastMCP, backend: Backend) -> None:
    """Register 5 resource templates."""
    resources = _load_resources_module()

    @server.resource(
        "csg://repo/{repo_name}/context",
        name="Repo Overview",
        description="Codebase stats, staleness check, and available tools",
    )
    def repo_context(repo_name: str) -> str:
        with backend._scoped_repo(repo_name or None):
            return resources.build_context_resource(backend, repo_name)

    @server.resource(
        "csg://repo/{repo_name}/clusters",
        name="Repo Modules",
        description="All functional areas (Leiden communities) with cohesion and member counts",
    )
    def repo_clusters(repo_name: str) -> str:
        with backend._scoped_repo(repo_name or None):
            return resources.build_clusters_resource(backend)

    @server.resource(
        "csg://repo/{repo_name}/processes",
        name="Repo Processes",
        description="All execution flows grouped by type",
    )
    def repo_processes(repo_name: str) -> str:
        with backend._scoped_repo(repo_name or None):
            return resources.build_processes_resource(backend)

    @server.resource(
        "csg://repo/{repo_name}/process/{process_name}",
        name="Process Trace",
        description="Step-by-step execution trace for a specific process",
    )
    def process_trace(repo_name: str, process_name: str) -> str:
        with backend._scoped_repo(repo_name or None):
            return resources.build_process_detail_resource(backend, process_name)

    @server.resource(
        "csg://repo/{repo_name}/schema",
        name="Graph Schema",
        description="Node/edge schema and example Cypher queries",
    )
    def graph_schema(repo_name: str) -> str:
        return resources.build_schema_resource()


def _load_resources_module():
    """Load resource builders from canonical path."""
    return importlib.import_module("csg.presentation.mcp.resources")


# ── Prompts ────────────────────────────────────────────────────────────


def _register_prompts(server: FastMCP) -> None:
    """Register 3 prompts."""

    @server.prompt(
        name="explore_codebase",
        description="Explore the codebase to answer a question using independent retrieval layers.",
    )
    def explore_codebase(question: str) -> str:
        return f"""Explore this codebase to answer: {question}

Use `csg_explore` with `layer=` to retrieve exactly what you need:

1. **Overview** — `csg_explore(layer="topology")` → community map
2. **Search** — `csg_explore(layer="relevance", query="{question}")` → find relevant code
3. **Flows** — `csg_explore(layer="context", scope="community:<name>")` → execution paths
4. **Contracts** — `csg_explore(layer="contract", query="<symbols>")` → signatures, callers
5. **Source** — `csg_explore(layer="implementation", query="<symbols>")` → actual code
6. **Impact** — `csg_impact(target="<name>")` → what would break

You can jump to any layer directly. Follow hints in each response for next steps."""

    @server.prompt(
        name="pre_commit_review",
        description="Pre-commit impact analysis: detect changes, analyze blast radius, and assess risk.",
    )
    def pre_commit_review(
        scope: str = "staged",
        base_ref: str = "",
    ) -> str:
        detect_args = f'scope="{scope}"'
        if base_ref:
            detect_args += f', base_ref="{base_ref}"'
        return f"""Analyze the impact of my current code changes before committing.

1. **Detect changes**: `csg_detect_changes({detect_args})`
2. **Assess blast radius** for each changed symbol with many callers:
   `csg_impact(target="<symbol_name>", direction="upstream")`
3. **Deep-dive high-risk**: `csg_context(symbol="<name>")`
4. **Summarize** — Risk report with changed symbols, affected processes, and recommendations."""

    @server.prompt(
        name="architecture_map",
        description="Generate architecture documentation from the code graph.",
    )
    def architecture_map() -> str:
        return """Generate architecture documentation for this codebase using the knowledge graph.

1. **Topology**: `csg_explore(layer="topology")` — communities, sizes, connections
2. **Flows**: `csg_explore(layer="context", scope="community:<name>")` — for each key community
3. **Cross-cutting**: `csg_explore(layer="crosscut")` — shared patterns, cycles
4. **Interfaces**: `csg_explore(layer="contract", query="<key symbols>")` — API signatures
5. **Generate documentation**: Overview, Functional Areas, Execution Flows, Mermaid diagrams"""


# ── Backend creation ───────────────────────────────────────────────────


def create_backend(
    db_path: str,
    read_only: bool = False,
    repo_source_path: str | None = None,
) -> tuple[Backend, LadybugAdapter]:
    """Create Backend + LadybugAdapter from a database path."""
    import os
    container = build_container()
    if read_only and not os.path.exists(db_path):
        _log(f"database not found at {db_path}, creating empty graph")
        read_only = False

    mode = "read-only" if read_only else "read-write"
    _log(f"connecting to {db_path} ({mode}, via KuzuPool)")
    adapter = container.build_ladybug_adapter(db_path=db_path, repo_source_path=repo_source_path)
    adapter.connect(read_only=read_only)
    backend = container.build_mcp_backend(adapter)
    _log("backend connected")

    return backend, adapter
