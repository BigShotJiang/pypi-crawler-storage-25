"""MCP Streamable HTTP transport.

Provides a lazy ASGI mount and lifespan setup for hosting FastMCP
alongside a FastAPI web application.
"""

from __future__ import annotations

import importlib
import json
import logging
from contextlib import asynccontextmanager

from csg.presentation.mcp.factory import create_mcp_server, create_backend

logger = logging.getLogger(__name__)


class MCPMount:
    """Lazy ASGI wrapper — delegates to the Starlette sub-app once running.

    Created at import time (sync). The actual MCP app is set during
    the async lifespan. Returns 503 if not yet initialized.
    """

    def __init__(self) -> None:
        self._app = None

    async def __call__(self, scope: dict, receive, send) -> None:
        if self._app is None:
            await _send_error(send, 503, "MCP server not yet initialized")
            return
        await self._app(scope, receive, send)


@asynccontextmanager
async def setup_mcp_http(
    mcp_mount: MCPMount, db_path: str, read_only: bool = True
):
    """Create FastMCP server and wire its HTTP app into the mount.

    Usage in FastAPI lifespan::

        @asynccontextmanager
        async def lifespan(app):
            async with setup_mcp_http(mcp_mount, db_path):
                yield
    """
    setup_mcp_logging = _load_setup_mcp_logging()
    setup_mcp_logging()

    backend, adapter = create_backend(db_path, read_only=read_only)
    server = create_mcp_server(backend, adapter)

    starlette_app = server.streamable_http_app()
    mcp_mount._app = starlette_app
    logger.info("MCP HTTP transport ready")

    yield

    mcp_mount._app = None
    logger.info("MCP HTTP transport stopped")


async def run_http_server(
    db_path: str, port: int = 8080, read_only: bool = True
) -> None:
    """Run a standalone HTTP MCP server (no web UI)."""
    import uvicorn
    from starlette.applications import Starlette
    from starlette.routing import Mount

    mcp_mount = MCPMount()

    @asynccontextmanager
    async def lifespan(app):
        async with setup_mcp_http(mcp_mount, db_path, read_only=read_only):
            yield

    app = Starlette(
        lifespan=lifespan,
        routes=[Mount("/mcp", app=mcp_mount)],
    )

    config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="info")
    srv = uvicorn.Server(config)
    await srv.serve()


async def _send_error(send, status: int, message: str) -> None:
    """Send an HTTP error response via ASGI."""
    body = json.dumps(
        {"jsonrpc": "2.0", "error": {"code": -32000, "message": message}, "id": None}
    ).encode()
    await send({
        "type": "http.response.start",
        "status": status,
        "headers": [
            [b"content-type", b"application/json"],
            [b"content-length", str(len(body)).encode()],
        ],
    })
    await send({"type": "http.response.body", "body": body})


def _load_setup_mcp_logging():
    """Load logging setup from canonical path."""
    module = importlib.import_module("csg.presentation.mcp.logging_setup")
    return module.setup_mcp_logging
