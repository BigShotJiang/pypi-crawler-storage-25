"""MCP logging configuration.

Configures Python logging to write to data/mcp.log so tool call
inputs, outputs, and timing are visible without interfering with
the stdio MCP transport (which uses stdout).

Environment variables:
    CSG_LOG_FILE  — Override log file path (default: data/mcp.log)
    CSG_LOG_LEVEL — Override log level (default: INFO)
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

_configured = False


def _default_log_path() -> Path:
    project_root = Path(__file__).resolve().parents[4]
    data_dir = Path(os.environ.get("CSG_DATA_DIR", project_root / "data"))
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / "mcp.log"


def setup_mcp_logging() -> Path:
    """Configure logging for the MCP server. Returns the log file path.

    Safe to call multiple times — only configures once.
    """
    global _configured
    if _configured:
        return Path(os.environ.get("CSG_LOG_FILE", _default_log_path()))

    log_file = Path(os.environ.get("CSG_LOG_FILE", _default_log_path()))
    log_level = os.environ.get("CSG_LOG_LEVEL", "INFO").upper()

    log_file.parent.mkdir(parents=True, exist_ok=True)

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(fmt)

    root = logging.getLogger("csg")
    root.setLevel(getattr(logging, log_level, logging.INFO))
    root.addHandler(file_handler)

    _configured = True
    logging.getLogger(__name__).info(
        "Logging initialized — level=%s file=%s", log_level, log_file
    )
    return log_file
