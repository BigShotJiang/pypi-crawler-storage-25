"""Inbound forwarder for context mixin."""

from csg.infrastructure.exploration.backend.context import ContextMixin

__all__ = ["ContextMixin"]
