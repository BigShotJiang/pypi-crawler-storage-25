"""Inbound forwarder for search mixin."""

from csg.infrastructure.exploration.backend.search import SearchMixin

__all__ = ["SearchMixin"]
