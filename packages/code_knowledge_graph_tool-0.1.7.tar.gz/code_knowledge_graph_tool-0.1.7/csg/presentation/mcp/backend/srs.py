"""Inbound forwarder for SRS mixin."""

from csg.infrastructure.exploration.backend.srs import SrsMixin

__all__ = ["SrsMixin"]
