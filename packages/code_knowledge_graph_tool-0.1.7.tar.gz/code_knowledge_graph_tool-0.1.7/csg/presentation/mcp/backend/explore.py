"""Inbound forwarder for explore mixin."""

from csg.infrastructure.exploration.backend.explore import ExploreMixin

__all__ = ["ExploreMixin"]
