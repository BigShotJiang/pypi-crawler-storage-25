"""Inbound forwarder for impact mixin."""

from csg.infrastructure.exploration.backend.impact import ImpactMixin

__all__ = ["ImpactMixin"]
