"""Inbound forwarder for mutations mixin."""

from csg.infrastructure.exploration.backend.mutations import MutationsMixin

__all__ = ["MutationsMixin"]
