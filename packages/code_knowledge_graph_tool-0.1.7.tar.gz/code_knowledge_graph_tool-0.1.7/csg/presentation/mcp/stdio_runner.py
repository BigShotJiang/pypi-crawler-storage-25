"""MCP stdio transport runner.

Runs the MCP server on stdin/stdout for CLI use (Claude Code, Cursor, etc.).

Unlike the web server, the MCP server uses **event-driven** re-ingestion
instead of polling.  Mutations (e.g. ``csg_rename``) publish a
``source_changed`` event on the KuzuPool EventBus; a background thread
picks it up and runs the incremental pipeline.
"""

from __future__ import annotations

import asyncio
import logging
import signal
from concurrent.futures import ThreadPoolExecutor

from mcp.server.stdio import stdio_server

from csg.application.use_cases.analysis.run_pipeline import run_incremental_pipeline_sync
from csg.bootstrap import build_container
from csg.presentation.mcp.factory import create_mcp_server, create_backend
from csg.presentation.mcp.logging_setup import setup_mcp_logging

logger = logging.getLogger(__name__)

# Background executor for event-driven re-ingestion (1 worker to serialise)
_reindex_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="csg-reindex")
_running_repos: set[str] = set()


def _on_source_changed(data: dict) -> None:
    """Handle ``source_changed`` events — trigger incremental re-ingestion."""
    repo_path: str = data.get("repo_path", "")
    reason: str = data.get("reason", "unknown")
    if not repo_path:
        return

    if repo_path in _running_repos:
        logger.debug("Skipping re-index for '%s' — already running", repo_path)
        return
    _running_repos.add(repo_path)

    def _run() -> None:
        try:
            logger.info(
                "Event-driven re-ingestion starting for '%s' (reason: %s)",
                repo_path, reason,
            )
            container = build_container()
            run_incremental_pipeline_sync(repo_path, runner=container.run_incremental_pipeline_sync)
            logger.info("Event-driven re-ingestion complete for '%s'", repo_path)
        except Exception:
            logger.exception("Event-driven re-ingestion failed for '%s'", repo_path)
        finally:
            _running_repos.discard(repo_path)

    _reindex_pool.submit(_run)


async def run_stdio_server(db_path: str, read_only: bool = True) -> None:
    """Run the MCP server on stdio transport."""
    log_file = setup_mcp_logging()
    logger.info("MCP stdio server starting — log file: %s", log_file)

    # Event-driven re-ingestion (no polling watcher in MCP mode)
    container = build_container()
    pool = container.get_graph_pool()
    sub_id = pool.event_bus.subscribe("source_changed", _on_source_changed)

    backend, adapter = create_backend(db_path, read_only=read_only)
    fastmcp = create_mcp_server(backend, adapter)

    # Access the low-level Server for custom shutdown integration.
    # FastMCP wraps it but doesn't expose run() with shutdown_event.
    low_level = fastmcp._mcp_server

    # Graceful shutdown
    shutdown_event = asyncio.Event()

    def _signal_handler(sig: int, _frame) -> None:
        logger.info("Received signal %s, shutting down", sig)
        shutdown_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _signal_handler)
        except (OSError, ValueError):
            pass  # Signal not available on this platform

    async with stdio_server() as (read_stream, write_stream):
        server_task = asyncio.create_task(
            low_level.run(read_stream, write_stream, low_level.create_initialization_options())
        )
        shutdown_task = asyncio.create_task(shutdown_event.wait())

        done, pending = await asyncio.wait(
            [server_task, shutdown_task],
            return_when=asyncio.FIRST_COMPLETED,
        )

        for task in pending:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass

    # Cleanup
    pool.event_bus.unsubscribe(sub_id)
    _reindex_pool.shutdown(wait=False)
    logger.info("MCP stdio server stopped")
