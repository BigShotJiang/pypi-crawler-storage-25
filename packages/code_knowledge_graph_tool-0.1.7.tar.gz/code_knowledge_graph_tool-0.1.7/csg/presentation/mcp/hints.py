"""Next-step hints appended to tool responses.

Agents often stop after one tool call. These hints guide them to the
logical next action, creating a self-guiding workflow without hooks.

Hints are context-aware: they pull symbol names, stats, and signals
from the actual result so the agent gets actionable next steps.
"""

from __future__ import annotations


def get_next_step_hint(
    tool_name: str, args: dict, result: dict
) -> str:
    """Return a next-step hint for the given tool response, or empty string."""
    try:
        return _HINT_BUILDERS.get(tool_name, _no_hint)(args, result)
    except Exception:
        return ""


# ── Helpers ───────────────────────────────────────────────────────────


def _pick_symbols(result: dict, max_count: int = 3) -> list[str]:
    """Extract symbol names from various result shapes."""
    names: list[str] = []

    # From explore contracts layer
    contracts = result.get("contracts", {})
    for sym in contracts.get("symbols", []):
        name = sym.get("name")
        if name and name not in names:
            names.append(name)
        if len(names) >= max_count:
            return names

    # From explore context layers (context, context:CommName)
    for key, section in result.items():
        if key.startswith("context") and isinstance(section, dict):
            for sym in section.get("symbols", []):
                name = sym.get("name")
                if name and name not in names:
                    names.append(name)
                if len(names) >= max_count:
                    return names

    # From explore relevance layer
    relevance = result.get("relevance", {})
    for comm in relevance.get("communities", []):
        for hit in comm.get("hits", []):
            name = hit.get("name")
            if name and name not in names:
                names.append(name)
            if len(names) >= max_count:
                return names

    # From topology communities topMembers
    for comm in result.get("communities", []):
        for name in comm.get("topMembers", []):
            if name and name not in names:
                names.append(name)
            if len(names) >= max_count:
                return names

    return names


# ── Per-tool hint builders ──────────────────────────────────────────


def _hint_explore(args: dict, result: dict) -> str:
    if "error" in result:
        return "**Next:** Check the error. Use `csg_list_repos()` to verify the repo exists."

    meta = result.get("_meta", {})
    depth = meta.get("depth_reached", "")
    search = meta.get("search", {})
    signal = search.get("signal", "") or result.get("signal", "")

    # Layer-specific hints
    if depth == "topology":
        comms = result.get("communities", [])
        if comms:
            names = [c.get("name", "") for c in comms[:3] if c.get("name")]
            return (
                f"**Next:** Drill into communities: "
                f"`csg_explore(layer='context', scope='community:<name>')`. "
                f"Top communities: {', '.join(names)}."
            )
        return "**Next:** Use `csg_explore(layer='relevance', query='<question>')` to search."

    if depth == "crosscut":
        return (
            "**Next:** Use `csg_explore(layer='context', scope='community:<name>')` "
            "to inspect specific communities, or `csg_explore(layer='contract', query='<symbols>')` "
            "for interface details."
        )

    if depth == "implementation":
        return "**Next:** Use `csg_impact(target='<symbol>')` to check blast radius before editing."

    # Weak signal — guide to broader search
    if signal == "weak":
        return (
            "**Next:** Weak signal — try a broader query with "
            "`csg_explore(layer='relevance', query='<broader terms>')`, "
            "or `csg_explore(layer='topology')` for the project map."
        )

    # Pull concrete symbol names from the result
    symbols = _pick_symbols(result, max_count=3)
    if symbols:
        comma_names = ", ".join(symbols)
        return (
            f"**Next:** Get details on key symbols: "
            f"`csg_explore(layer='contract', query='{comma_names}')` for signatures, "
            f"or `csg_explore(layer='implementation', query='{comma_names}')` for source code."
        )

    return (
        "**Next:** Use `csg_explore(layer='contract', query='<symbol>')` for signatures, "
        "or `csg_context(symbol='<name>')` for full 360° view."
    )


def _hint_context(args: dict, result: dict) -> str:
    if "error" in result:
        return (
            "**Next:** Symbol not found. Use `csg_explore(query: '<keyword>')` "
            "to search for it, or check spelling."
        )

    symbol = args.get("symbol", "<symbol>")
    callers = result.get("callers", [])
    callees = result.get("callees", [])

    parts = [f'**Next:** Use `csg_impact(target: "{symbol}")` to check blast radius.']

    if not callers and not callees:
        parts.append(
            "No callers/callees found — this may be a top-level entry point "
            "or dynamically invoked (framework callback, decorator, etc.)."
        )
    elif callers:
        caller_names = [c.get("name", "") for c in callers[:3] if c.get("name")]
        if caller_names:
            parts.append(f"Key callers: {', '.join(caller_names)}.")

    candidates = result.get("candidates")
    if candidates and len(candidates) > 1:
        paths = [c.get("filePath", "") for c in candidates[:3]]
        parts.append(
            f"Multiple matches found — use scope='file:<path>' to target: "
            f"{', '.join(paths)}."
        )

    return " ".join(parts)


def _hint_impact(args: dict, result: dict) -> str:
    if "error" in result:
        return (
            "**Next:** Symbol not found. Use `csg_explore(query: '<keyword>')` "
            "to search for it."
        )

    stats = result.get("stats", {})
    risk = result.get("risk", "LOW")
    d1 = stats.get("d1", 0)
    unresolved = stats.get("unresolved", 0)
    total = stats.get("total", 0)

    parts = [f"**Next:** Risk: **{risk}** — {d1} direct dependents, {total} total affected."]

    if unresolved > 0:
        parts.append(
            f"{unresolved} item(s) are file-level (unresolved) — "
            "the exact symbol inside those files couldn't be determined."
        )

    if d1 > 0:
        # Suggest looking at specific high-risk symbols
        d1_items = [a for a in result.get("affected", []) if a.get("depth") == 1 and a.get("type") != "File"]
        if d1_items:
            names = list({a["name"] for a in d1_items[:3]})
            parts.append(
                f'Review d=1 items (WILL BREAK): {", ".join(names)}. '
                f'Use `csg_context(symbol: "<name>")` on high-risk ones.'
            )

    return " ".join(parts)


def _hint_detect_changes(args: dict, result: dict) -> str:
    if "error" in result:
        return (
            "**Next:** This repo is not a git repository or has no commits. "
            "Use `csg_explore()` or `csg_impact()` instead for code analysis."
        )

    total_files = result.get("total_files", 0)
    total_symbols = result.get("total_symbols", 0)

    if total_symbols == 0 and total_files == 0:
        return "**Next:** No uncommitted changes detected."
    if total_symbols == 0:
        return f"**Next:** {total_files} file(s) changed but no indexed symbols affected."

    # Pick top symbols to suggest
    symbols = result.get("affected_symbols", [])
    names = list({s.get("name", "") for s in symbols[:5] if s.get("name")})
    if names:
        quoted = ", ".join(f'"{n}"' for n in names[:3])
        return (
            f"**Next:** {total_symbols} symbol(s) affected across {total_files} file(s). "
            f"Use `csg_impact(target: ...)` on: {quoted} to check blast radius."
        )

    return (
        f"**Next:** {total_symbols} symbol(s) affected across {total_files} file(s). "
        'Use `csg_impact(target: "<symbol>")` for blast radius.'
    )


def _hint_rename(args: dict, result: dict) -> str:
    if "error" in result:
        return (
            "**Next:** Symbol not found. Use `csg_explore(query: '<keyword>')` "
            "to search for the correct name."
        )

    counts = result.get("counts", {})
    defs = counts.get("definitions", 0)
    usages = counts.get("usages", 0)
    dry_run = result.get("dry_run", True)

    if dry_run:
        return (
            f"**Next:** Dry run: {defs} definition(s), {usages} usage(s) found. "
            "Set dry_run=false to apply the rename. "
            "Then run `csg_detect_changes()` to verify."
        )
    return (
        f"**Next:** Renamed: {defs} definition(s), {usages} usage(s) updated. "
        'Verify with `csg_detect_changes(scope: "unstaged")`.'
    )


def _hint_list_repos(args: dict, result: dict) -> str:
    repos = result.get("repos", [])
    if not repos:
        return (
            "**Next:** No repos indexed. Use `csg_analyze(path: '<path>')` "
            "to index a repository first."
        )

    names = [r.get("name", "") for r in repos[:3]]
    return (
        f"**Next:** {len(repos)} repo(s) indexed: {', '.join(names)}. "
        "Use `csg_explore()` on any repo to see the project map."
    )


def _hint_analyze(args: dict, result: dict) -> str:
    if result.get("status") == "ok":
        stats = result.get("stats", {})
        nodes = stats.get("nodes", "?")
        comms = stats.get("communities", "?")
        procs = stats.get("processes", "?")
        warning = result.get("warning", "")
        hint = (
            f"**Next:** Indexed: {nodes} nodes, {comms} communities, {procs} processes. "
            "Use `csg_list_repos()` to verify, then `csg_explore()` to navigate."
        )
        if warning:
            hint += f" ⚠️ {warning}"
        return hint
    return "**Next:** Check the error and fix the path or input, then retry."


def _hint_delete(args: dict, result: dict) -> str:
    if result.get("status") == "ok":
        count = result.get("count", 0)
        return (
            f"**Next:** {count} repo(s) removed. "
            "Use `csg_list_repos()` to verify. "
            "Use `csg_analyze(path: '<path>')` to re-index if needed."
        )
    if result.get("status") == "not_found":
        available = result.get("available", [])
        if available:
            return f"**Next:** Repo not found. Available: {', '.join(available)}"
    return "**Next:** Check the error and retry."


def _hint_srs(args: dict, result: dict) -> str:
    if not result.get("success"):
        msg = result.get("message", "Unknown error")
        return f"**Next:** SRS generation failed: {msg}"

    md_path = result.get("srs_md_path", "")
    docx_path = result.get("docx_path", "")
    parts = ["**Next:** SRS generated successfully."]
    if md_path:
        parts.append(f"Markdown saved: {md_path}")
    if docx_path:
        parts.append(f"DOCX saved: {docx_path}")
    return " ".join(parts)


def _no_hint(_args: dict, _result: dict) -> str:
    return ""


_HINT_BUILDERS: dict[str, callable] = {
    "csg_explore": _hint_explore,
    "csg_context": _hint_context,
    "csg_impact": _hint_impact,
    "csg_detect_changes": _hint_detect_changes,
    "csg_rename": _hint_rename,
    "csg_list_repos": _hint_list_repos,
    "csg_analyze": _hint_analyze,
    "csg_delete": _hint_delete,
    "csg_srs": _hint_srs,
}
