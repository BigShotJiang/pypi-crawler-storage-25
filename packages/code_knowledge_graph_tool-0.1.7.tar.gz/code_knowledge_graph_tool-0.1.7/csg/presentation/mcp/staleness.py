"""Inbound MCP forwarder for repository staleness use-case."""

from __future__ import annotations

from csg.application.use_cases.repositories.check_staleness import check_staleness

__all__ = ["check_staleness"]
