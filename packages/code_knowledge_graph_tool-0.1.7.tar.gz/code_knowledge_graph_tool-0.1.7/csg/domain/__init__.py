"""Domain layer package."""
