"""Domain-level analysis errors."""


class PipelineCancelled(Exception):
    """Raised when an analysis run is cancelled."""

    def __init__(self, phase: str = "") -> None:
        self.phase = phase
        message = f"Pipeline cancelled during {phase}" if phase else "Pipeline cancelled"
        super().__init__(message)

__all__ = ["PipelineCancelled"]

