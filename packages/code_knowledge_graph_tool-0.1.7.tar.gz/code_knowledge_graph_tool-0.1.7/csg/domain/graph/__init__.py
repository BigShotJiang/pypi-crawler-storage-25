"""Domain graph subpackage."""
