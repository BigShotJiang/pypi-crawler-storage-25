"""Domain codebase subpackage."""
