"""Analysis domain policies."""

from csg.domain.analysis.models import PipelineProgress, PipelineState
from csg.domain.errors import PipelineCancelled


def check_cancelled(state: PipelineState) -> None:
    """Raise PipelineCancelled when cancel_event has been signaled."""
    cfg = state.get("config")
    cancel_event = getattr(cfg, "cancel_event", None) if cfg else None
    if cancel_event is not None and cancel_event.is_set():
        phase = state.get("progress", PipelineProgress()).phase
        raise PipelineCancelled(phase)

__all__ = ["check_cancelled"]
