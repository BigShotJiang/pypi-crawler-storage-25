"""Analysis domain events."""

from csg.domain.errors import PipelineCancelled

__all__ = ["PipelineCancelled"]

