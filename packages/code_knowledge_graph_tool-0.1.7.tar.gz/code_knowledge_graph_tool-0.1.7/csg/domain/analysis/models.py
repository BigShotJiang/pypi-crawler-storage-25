"""Pure domain models for analysis jobs and progress tracking."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TypedDict


@dataclass
class PipelineConfig:
    """Domain configuration for an analysis run."""

    repo_path: str = ""
    force: bool = False
    embeddings: bool = False
    exclude_dirs: frozenset[str] = frozenset()


@dataclass
class PipelineProgress:
    """Domain progress information for long-running analysis."""

    phase: str = ""
    phase_index: int = 0
    total_phases: int = 12
    message: str = ""
    percent: int = 0


class PipelineState(TypedDict, total=False):
    """Domain-level pipeline state contract."""

    config: PipelineConfig
    progress: PipelineProgress
    stats: dict[str, Any]
