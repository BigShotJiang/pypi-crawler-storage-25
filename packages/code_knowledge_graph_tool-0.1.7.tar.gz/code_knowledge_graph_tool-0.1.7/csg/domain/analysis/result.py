"""Analysis result domain types."""

from dataclasses import dataclass


@dataclass
class PipelineResult:
    """Result of a completed analysis pipeline run."""

    node_count: int
    relationship_count: int
    file_count: int
    community_count: int
    process_count: int
    duration_ms: int
    embedding_count: int = 0

__all__ = ["PipelineResult"]
