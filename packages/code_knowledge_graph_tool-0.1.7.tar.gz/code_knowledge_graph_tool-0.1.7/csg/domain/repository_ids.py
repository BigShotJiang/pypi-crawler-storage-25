"""Stable repository identifier helpers."""

from __future__ import annotations

import hashlib
from pathlib import Path


def repository_id_from_storage_path(storage_path: str | Path) -> str:
    """Compute a stable transport id from a repository storage path."""
    path = Path(storage_path)
    if path.name == ".csg":
        resolved = str(path.resolve())
        suffix = hashlib.md5(resolved.encode()).hexdigest()[:8]
        return f"{path.parent.name}-{suffix}"
    return path.name
