"""Allow running as `python -m csg`."""

from csg.bootstrap import build_container
from csg.presentation.cli.entry import main

build_container()
main()
