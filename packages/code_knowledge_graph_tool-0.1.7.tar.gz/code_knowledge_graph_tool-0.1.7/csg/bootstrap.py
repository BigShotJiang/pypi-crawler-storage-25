"""Canonical composition root for the CSG package."""

from __future__ import annotations

from csg.infrastructure.di.container import AppContainer, build_container as _build_container
from csg.infrastructure.di.container import get_container as _get_container


def get_container() -> AppContainer:
    """Return the process-wide application container."""
    return _get_container()


def build_container() -> AppContainer:
    """Build or return the canonical application container."""
    return _build_container()

__all__ = [
    "AppContainer",
    "get_container",
    "build_container",
]
