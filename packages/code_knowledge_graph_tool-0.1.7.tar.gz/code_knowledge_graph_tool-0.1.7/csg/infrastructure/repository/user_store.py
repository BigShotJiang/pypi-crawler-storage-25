"""JSON-file-backed user store."""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from csg.application.ports.user_store_port import UserStorePort
from csg.infrastructure.security.password_hasher import PasswordHasher


class JsonUserStore(UserStorePort):
    """Persist users in a local JSON file."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or (Path(os.environ.get("CSG_DATA_DIR", "data")) / "users.json")
        self._password_hasher = PasswordHasher()
        self._bootstrap_admin_if_configured()

    def create_user(
        self,
        *,
        username: str,
        email: str,
        password_hash: str,
        role: str,
        status: str,
    ) -> dict[str, Any]:
        users = self._read_users()
        now = datetime.now(timezone.utc).isoformat()
        user = {
            "id": uuid.uuid4().hex,
            "username": username,
            "email": email,
            "password_hash": password_hash,
            "role": role,
            "status": status,
            "created_at": now,
            "updated_at": now,
            "last_login_at": None,
        }
        users.append(user)
        self._write_users(users)
        return dict(user)

    def get_by_id(self, user_id: str) -> dict[str, Any] | None:
        return next((dict(user) for user in self._read_users() if user.get("id") == user_id), None)

    def get_by_username(self, username: str) -> dict[str, Any] | None:
        needle = username.strip().lower()
        return next((dict(user) for user in self._read_users() if str(user.get("username", "")).lower() == needle), None)

    def get_by_email(self, email: str) -> dict[str, Any] | None:
        needle = email.strip().lower()
        return next((dict(user) for user in self._read_users() if str(user.get("email", "")).lower() == needle), None)

    def list_users(self) -> list[dict[str, Any]]:
        return [dict(user) for user in self._read_users()]

    def update_last_login(self, user_id: str, *, last_login_at: str) -> None:
        users = self._read_users()
        changed = False
        for user in users:
            if user.get("id") == user_id:
                user["last_login_at"] = last_login_at
                user["updated_at"] = last_login_at
                changed = True
                break
        if changed:
            self._write_users(users)

    def update_username(self, user_id: str, *, username: str, updated_at: str) -> dict[str, Any] | None:
        users = self._read_users()
        normalized = username.strip()
        for user in users:
            if user.get("id") == user_id:
                user["username"] = normalized
                user["updated_at"] = updated_at
                self._write_users(users)
                return dict(user)
        return None

    def update_password_hash(self, user_id: str, *, password_hash: str, updated_at: str) -> dict[str, Any] | None:
        users = self._read_users()
        for user in users:
            if user.get("id") == user_id:
                user["password_hash"] = password_hash
                user["updated_at"] = updated_at
                self._write_users(users)
                return dict(user)
        return None

    def update_status(self, user_id: str, *, status: str, updated_at: str) -> dict[str, Any] | None:
        users = self._read_users()
        for user in users:
            if user.get("id") == user_id:
                user["status"] = status
                user["updated_at"] = updated_at
                self._write_users(users)
                return dict(user)
        return None

    def _read_users(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, TypeError):
            return []
        return data if isinstance(data, list) else []

    def _write_users(self, users: list[dict[str, Any]]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self._path.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(users, indent=2), encoding="utf-8")
        tmp_path.replace(self._path)

    def _bootstrap_admin_if_configured(self) -> None:
        username = os.environ.get("CSG_ADMIN_USERNAME", "").strip()
        email = os.environ.get("CSG_ADMIN_EMAIL", "").strip().lower()
        password = os.environ.get("CSG_ADMIN_PASSWORD", "")
        if not username or not email or not password:
            return
        if self.get_by_username(username) or self.get_by_email(email):
            return
        self.create_user(
            username=username,
            email=email,
            password_hash=self._password_hasher.hash_password(password),
            role="admin",
            status="active",
        )
