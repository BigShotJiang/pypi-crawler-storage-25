"""JSON-file-backed per-user settings store."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from csg.application.ports.user_settings_store_port import UserSettingsStorePort


DEFAULT_USER_SETTINGS: dict[str, Any] = {
    "default_branch": "main",
    "max_file_size_kb": 100 * 1024,
    "embeddings_enabled": True,
    "embedding_provider": "openai",
    "ocr_provider": "openai",
    "llm_provider": "openai",
}


class JsonUserSettingsStore(UserSettingsStorePort):
    """Persist user settings in a local JSON file."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or (Path(os.environ.get("CSG_DATA_DIR", "data")) / "user_settings.json")

    def get_settings(self, *, user_id: str) -> dict[str, Any] | None:
        record = next((item for item in self._read_all() if item.get("user_id") == user_id), None)
        if record is None:
            return None
        return self._normalize_record(record)

    def upsert_settings(self, *, user_id: str, settings: dict[str, Any]) -> dict[str, Any]:
        rows = self._read_all()
        now = datetime.now(timezone.utc).isoformat()
        normalized = self._normalize_record({"user_id": user_id, **settings})

        for row in rows:
            if row.get("user_id") != user_id:
                continue
            created_at = row.get("created_at") or now
            row.clear()
            row.update({
                **normalized,
                "user_id": user_id,
                "created_at": created_at,
                "updated_at": now,
            })
            self._write(rows)
            return dict(row)

        record = {
            "user_id": user_id,
            **normalized,
            "created_at": now,
            "updated_at": now,
        }
        rows.append(record)
        self._write(rows)
        return dict(record)

    def _normalize_record(self, record: dict[str, Any]) -> dict[str, Any]:
        return {
            **DEFAULT_USER_SETTINGS,
            **{
                "default_branch": str(record.get("default_branch") or DEFAULT_USER_SETTINGS["default_branch"]).strip() or "main",
                "max_file_size_kb": max(1, int(record.get("max_file_size_kb") or DEFAULT_USER_SETTINGS["max_file_size_kb"])),
                "embeddings_enabled": bool(record.get("embeddings_enabled", DEFAULT_USER_SETTINGS["embeddings_enabled"])),
                "embedding_provider": str(record.get("embedding_provider") or DEFAULT_USER_SETTINGS["embedding_provider"]).strip().lower(),
                "ocr_provider": str(record.get("ocr_provider") or DEFAULT_USER_SETTINGS["ocr_provider"]).strip().lower(),
                "llm_provider": str(record.get("llm_provider") or DEFAULT_USER_SETTINGS["llm_provider"]).strip().lower(),
            },
        }

    def _read_all(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, TypeError):
            return []
        return data if isinstance(data, list) else []

    def _write(self, rows: list[dict[str, Any]]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self._path.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")
        tmp_path.replace(self._path)
