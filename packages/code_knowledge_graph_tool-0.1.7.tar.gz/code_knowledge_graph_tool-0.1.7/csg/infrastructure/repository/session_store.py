"""JSON-file-backed auth session store."""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from csg.application.ports.session_store_port import SessionStorePort


class JsonSessionStore(SessionStorePort):
    """Persist opaque-token sessions in a local JSON file."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or (Path(os.environ.get("CSG_DATA_DIR", "data")) / "sessions.json")

    def create_session(
        self,
        *,
        user_id: str,
        access_token_hash: str,
        refresh_token_hash: str,
        access_expires_at: str,
        refresh_expires_at: str,
    ) -> dict[str, Any]:
        sessions = self._read_sessions()
        now = datetime.now(timezone.utc).isoformat()
        session = {
            "id": uuid.uuid4().hex,
            "user_id": user_id,
            "access_token_hash": access_token_hash,
            "refresh_token_hash": refresh_token_hash,
            "access_expires_at": access_expires_at,
            "refresh_expires_at": refresh_expires_at,
            "created_at": now,
            "updated_at": now,
            "revoked_at": None,
        }
        sessions.append(session)
        self._write_sessions(sessions)
        return dict(session)

    def get_by_access_token_hash(self, access_token_hash: str) -> dict[str, Any] | None:
        return next(
            (dict(session) for session in self._read_sessions() if session.get("access_token_hash") == access_token_hash),
            None,
        )

    def get_by_refresh_token_hash(self, refresh_token_hash: str) -> dict[str, Any] | None:
        return next(
            (dict(session) for session in self._read_sessions() if session.get("refresh_token_hash") == refresh_token_hash),
            None,
        )

    def rotate_session(
        self,
        session_id: str,
        *,
        access_token_hash: str,
        refresh_token_hash: str,
        access_expires_at: str,
        refresh_expires_at: str,
    ) -> dict[str, Any] | None:
        sessions = self._read_sessions()
        now = datetime.now(timezone.utc).isoformat()
        for session in sessions:
            if session.get("id") != session_id:
                continue
            session["access_token_hash"] = access_token_hash
            session["refresh_token_hash"] = refresh_token_hash
            session["access_expires_at"] = access_expires_at
            session["refresh_expires_at"] = refresh_expires_at
            session["updated_at"] = now
            self._write_sessions(sessions)
            return dict(session)
        return None

    def revoke_session(self, session_id: str, *, revoked_at: str) -> None:
        sessions = self._read_sessions()
        changed = False
        for session in sessions:
            if session.get("id") == session_id and session.get("revoked_at") is None:
                session["revoked_at"] = revoked_at
                session["updated_at"] = revoked_at
                changed = True
                break
        if changed:
            self._write_sessions(sessions)

    def revoke_sessions_for_user(self, user_id: str, *, revoked_at: str) -> None:
        sessions = self._read_sessions()
        changed = False
        for session in sessions:
            if session.get("user_id") != user_id or session.get("revoked_at") is not None:
                continue
            session["revoked_at"] = revoked_at
            session["updated_at"] = revoked_at
            changed = True
        if changed:
            self._write_sessions(sessions)

    def _read_sessions(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, TypeError):
            return []
        return data if isinstance(data, list) else []

    def _write_sessions(self, sessions: list[dict[str, Any]]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self._path.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(sessions, indent=2), encoding="utf-8")
        tmp_path.replace(self._path)
