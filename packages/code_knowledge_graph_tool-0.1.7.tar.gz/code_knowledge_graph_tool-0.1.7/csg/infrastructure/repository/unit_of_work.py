"""In-memory unit-of-work adapter with post-commit publish sequencing."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping

from csg.application.ports.event_publisher_port import EventPublisherPort
from csg.application.ports.unit_of_work_port import UnitOfWorkPort


class InMemoryUnitOfWork(UnitOfWorkPort):
    """Bridge UnitOfWork implementation suitable for sequencing tests."""

    def __init__(self, *, operation_log: list[str] | None = None) -> None:
        self.operation_log = operation_log
        self._events: list[tuple[str, Mapping[str, Any]]] = []
        self.committed = False
        self.rolled_back = False

    def __enter__(self) -> "InMemoryUnitOfWork":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool | None:
        if exc_type is not None and not self.committed:
            self.rollback()
        return None

    def commit(self) -> None:
        """Mark state as committed."""
        self.committed = True
        self.rolled_back = False
        if self.operation_log is not None:
            self.operation_log.append("commit")

    def rollback(self) -> None:
        """Mark state as rolled back."""
        self.committed = False
        self.rolled_back = True
        self._events = []
        if self.operation_log is not None:
            self.operation_log.append("rollback")

    def add_event(self, event_name: str, payload: Mapping[str, Any]) -> None:
        """Record an event for post-commit publication."""
        self._events.append((event_name, deepcopy(dict(payload))))

    def collect_events(self) -> list[tuple[str, Mapping[str, Any]]]:
        """Return buffered events and clear the internal queue."""
        items = self._events
        self._events = []
        return [(name, deepcopy(dict(payload))) for name, payload in items]

    def publish_post_commit(self, publisher: EventPublisherPort) -> None:
        """Publish buffered events; requires commit to have happened first."""
        if not self.committed:
            raise RuntimeError("Cannot publish events before commit")

        events = self.collect_events()
        for idx, (event_name, payload) in enumerate(events):
            try:
                publisher.publish(event_name, payload)
            except Exception:
                # Preserve failed + remaining events for retry semantics.
                self._events = events[idx:] + self._events
                raise
