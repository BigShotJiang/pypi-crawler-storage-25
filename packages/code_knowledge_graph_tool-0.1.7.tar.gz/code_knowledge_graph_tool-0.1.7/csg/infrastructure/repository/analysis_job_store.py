"""In-memory analysis job store adapter.

Phase 8 bridge adapter for explicit JobId <-> RunHandle mapping.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping

from csg.application.ports.analysis_job_store_port import AnalysisJobStorePort


class InMemoryAnalysisJobStore(AnalysisJobStorePort):
    """Dict-backed AnalysisJobStorePort with deterministic merge semantics."""

    def __init__(self) -> None:
        self._jobs: dict[str, dict[str, Any]] = {}
        self._job_to_run: dict[str, str] = {}

    def create(self, job_id: str, payload: Mapping[str, Any]) -> None:
        """Create/replace a job record for job_id."""
        self._jobs[job_id] = deepcopy(dict(payload))

    def link(self, job_id: str, run_handle: str) -> None:
        """Persist JobId -> RunHandle mapping and mirror handle on the job."""
        self._job_to_run[job_id] = run_handle
        job = self._jobs.setdefault(job_id, {"job_id": job_id})
        job["run_handle"] = run_handle

    def get_run_handle(self, job_id: str) -> str | None:
        """Return mapped run handle for job_id, if present."""
        return self._job_to_run.get(job_id)

    def get_job(self, job_id: str) -> Mapping[str, Any] | None:
        """Return copy-safe job record so callers cannot mutate store state."""
        job = self._jobs.get(job_id)
        return deepcopy(job) if job is not None else None

    def update(self, job_id: str, patch: Mapping[str, Any]) -> None:
        """Merge patch fields into existing job record."""
        job = self._jobs.setdefault(job_id, {"job_id": job_id})
        job.update(deepcopy(dict(patch)))
