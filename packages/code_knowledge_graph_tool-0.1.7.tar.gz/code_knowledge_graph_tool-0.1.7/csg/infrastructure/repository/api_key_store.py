"""Outbound adapter implementing API key store port."""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from csg.application.ports.api_key_store_port import ApiKeyStorePort


class JsonApiKeyStore(ApiKeyStorePort):
    """JSON-file-backed API key store."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or (Path(os.environ.get("CSG_DATA_DIR", "data")) / "api_keys.json")

    def list_keys(self, *, owner_user_id: str) -> list[dict[str, Any]]:
        return [key for key in self._read_all_keys() if key.get("owner_user_id") == owner_user_id]

    def create_key(self, description: str, *, owner_user_id: str) -> dict[str, Any]:
        keys = self._read_all_keys()
        new_key = {
            "id": uuid.uuid4().hex[:12],
            "key": uuid.uuid4().hex,
            "description": description,
            "owner_user_id": owner_user_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        keys.append(new_key)
        self._write(keys)
        return new_key

    def delete_key(self, key_id: str, *, owner_user_id: str) -> bool:
        keys = self._read_all_keys()
        filtered = [k for k in keys if not (k.get("id") == key_id and k.get("owner_user_id") == owner_user_id)]
        if len(filtered) == len(keys):
            return False
        self._write(filtered)
        return True

    def _read_all_keys(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, TypeError):
            return []
        return data if isinstance(data, list) else []

    def _write(self, keys: list[dict[str, Any]]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(keys, indent=2), encoding="utf-8")

