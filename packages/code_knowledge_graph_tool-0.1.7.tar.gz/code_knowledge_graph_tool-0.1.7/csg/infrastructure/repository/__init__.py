"""Infrastructure repository adapters."""

from __future__ import annotations

from functools import lru_cache
from importlib import import_module

from csg.infrastructure.repository.analysis_job_store import InMemoryAnalysisJobStore
from csg.infrastructure.repository.unit_of_work import InMemoryUnitOfWork

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from csg.infrastructure.repository.internal.repo_registry_runtime import RepoMeta


@lru_cache(maxsize=1)
def _repo_manager_module() -> Any:
    return import_module("csg.infrastructure.repository.internal.repo_registry_runtime")


@lru_cache(maxsize=1)
def _git_module() -> Any:
    return import_module("csg.infrastructure.repository.internal.git_runtime")


def get_storage_path_for_repo(repo_path: str):
    """Canonical adapter wrapper for resolving repo storage path."""
    return _repo_manager_module().get_storage_path(repo_path)


def has_index_for_repo(repo_path: str) -> bool:
    """Canonical adapter wrapper for checking whether repo index exists."""
    return _repo_manager_module().has_index(repo_path)


def get_repo_entry_by_name(repo_name: str):
    """Canonical adapter wrapper for resolving a repo entry by name."""
    return _repo_manager_module().get_repo_by_name(repo_name)


def list_registered_repos_for_api(*, validate: bool = False):
    """Canonical adapter wrapper for listing registered repositories."""
    return _repo_manager_module().list_registered_repos(validate=validate)


def register_repo_entry(repo_path: str, meta: RepoMeta) -> None:
    """Canonical adapter wrapper for registering a repository entry."""
    _repo_manager_module().register_repo(repo_path, meta)


def save_repo_meta(repo_path: str, meta: RepoMeta) -> None:
    """Canonical adapter wrapper for persisting repository metadata."""
    _repo_manager_module().save_meta(repo_path, meta)


def load_repo_meta(repo_path: str):
    """Canonical adapter wrapper for loading repository metadata."""
    return _repo_manager_module().load_meta(repo_path)


def get_current_commit_for_repo(repo_path: str):
    """Canonical adapter wrapper for reading current repository commit."""
    return _git_module().get_current_commit(repo_path)


def get_repo_git_root(repo_path: str):
    """Canonical adapter wrapper for resolving repository git root."""
    return _git_module().get_git_root(repo_path)


def get_repo_diff_files(repo_path: str, scope: str = "all", base_ref: str = ""):
    """Canonical adapter wrapper for listing changed files for a repository."""
    return _git_module().get_diff_files(repo_path, scope=scope, base_ref=base_ref)


def unregister_repo_entry(repo_path: str) -> None:
    """Canonical adapter wrapper for unregistering a repository entry."""
    _repo_manager_module().unregister_repo(repo_path)


def __getattr__(name: str):
    if name == "RepoMeta":
        return _repo_manager_module().RepoMeta
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# Import RepositoryRegistryAdapter at the end to avoid circular dependency
from csg.infrastructure.repository.repository_registry_adapter import RepositoryRegistryAdapter


__all__ = [
    "InMemoryAnalysisJobStore",
    "InMemoryUnitOfWork",
    "RepositoryRegistryAdapter",
    "RepoMeta",
    "get_repo_entry_by_name",
    "get_storage_path_for_repo",
    "has_index_for_repo",
    "get_current_commit_for_repo",
    "get_repo_git_root",
    "get_repo_diff_files",
    "load_repo_meta",
    "list_registered_repos_for_api",
    "register_repo_entry",
    "save_repo_meta",
    "unregister_repo_entry",
]
