"""JSON-file-backed per-user secret store."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from csg.application.ports.user_secrets_store_port import UserSecretsStorePort


class JsonUserSecretsStore(UserSecretsStorePort):
    """Persist encrypted per-user secrets in a local JSON file."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or (Path(os.environ.get("CSG_DATA_DIR", "data")) / "user_secrets.json")

    def get_secret_record(self, *, user_id: str) -> dict[str, Any] | None:
        record = next((item for item in self._read_all() if item.get("user_id") == user_id), None)
        return dict(record) if record else None

    def upsert_secret_record(self, *, user_id: str, record: dict[str, Any]) -> dict[str, Any]:
        rows = self._read_all()
        now = datetime.now(timezone.utc).isoformat()

        for row in rows:
            if row.get("user_id") != user_id:
                continue
            created_at = row.get("created_at") or now
            row.clear()
            row.update({
                "user_id": user_id,
                **record,
                "created_at": created_at,
                "updated_at": now,
            })
            self._write(rows)
            return dict(row)

        stored = {
            "user_id": user_id,
            **record,
            "created_at": now,
            "updated_at": now,
        }
        rows.append(stored)
        self._write(rows)
        return dict(stored)

    def delete_secret_record(self, *, user_id: str) -> bool:
        rows = self._read_all()
        filtered = [row for row in rows if row.get("user_id") != user_id]
        if len(filtered) == len(rows):
            return False
        self._write(filtered)
        return True

    def _read_all(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, TypeError):
            return []
        return data if isinstance(data, list) else []

    def _write(self, rows: list[dict[str, Any]]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self._path.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")
        tmp_path.replace(self._path)
