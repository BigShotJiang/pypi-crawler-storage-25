"""Infrastructure adapter implementing repository registry port."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from csg.application.ports.repository_registry_port import RepositoryRegistryPort
from csg.infrastructure.repository import (
    get_current_commit_for_repo,
    get_repo_diff_files,
    get_repo_entry_by_name,
    get_repo_git_root,
    get_storage_path_for_repo,
    has_index_for_repo,
    list_registered_repos_for_api,
    load_repo_meta,
    register_repo_entry,
    save_repo_meta,
    unregister_repo_entry,
)


class RepositoryRegistryAdapter(RepositoryRegistryPort):
    """Port adapter over repository registry and git helper functions."""

    def get_repo_entry_by_name(self, repo_name: str) -> Any | None:
        return get_repo_entry_by_name(repo_name)

    def has_index_for_repo(self, repo_path: str) -> bool:
        return has_index_for_repo(repo_path)

    def load_repo_meta(self, repo_path: str) -> Any | None:
        return load_repo_meta(repo_path)

    def list_registered_repos_for_api(self, *, validate: bool = False) -> list[Any]:
        return list_registered_repos_for_api(validate=validate)

    def unregister_repo_entry(self, repo_path: str) -> None:
        unregister_repo_entry(repo_path)

    def get_storage_path_for_repo(self, repo_path: str) -> Path:
        return get_storage_path_for_repo(repo_path)

    def get_current_commit_for_repo(self, repo_path: str) -> str | None:
        return get_current_commit_for_repo(repo_path)

    def get_repo_git_root(self, repo_path: str) -> str | None:
        return get_repo_git_root(repo_path)

    def get_repo_diff_files(
        self,
        repo_path: str,
        *,
        scope: str = "all",
        base_ref: str = "",
    ) -> list[str]:
        return get_repo_diff_files(repo_path, scope=scope, base_ref=base_ref)

    def register_repo_entry(self, repo_path: str, meta: Any) -> None:
        register_repo_entry(repo_path, meta)

    def save_repo_meta(self, repo_path: str, meta: Any) -> None:
        save_repo_meta(repo_path, meta)

    def build_repo_meta(
        self,
        *,
        repo_path: str,
        last_commit: str,
        indexed_at: str,
        stats: dict[str, Any],
        owner_user_id: str | None = None,
    ) -> Any:
        from csg.infrastructure.repository.internal.repo_registry_runtime import RepoMeta

        return RepoMeta(
            repo_path=repo_path,
            last_commit=last_commit,
            indexed_at=indexed_at,
            owner_user_id=owner_user_id,
            stats=stats,
        )
