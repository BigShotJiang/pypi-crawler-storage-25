"""Repository runtime internals owned by outbound adapters."""

