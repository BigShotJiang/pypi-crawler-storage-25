"""In-memory event publisher adapter."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping

from csg.application.ports.event_publisher_port import EventPublisherPort


class InMemoryEventPublisher(EventPublisherPort):
    """Bridge event publisher that records published events in memory."""

    def __init__(
        self,
        *,
        fail_on: set[str] | None = None,
        operation_log: list[str] | None = None,
    ) -> None:
        self._fail_on = set(fail_on or set())
        self.operation_log = operation_log
        self.published: list[tuple[str, Mapping[str, Any]]] = []
        self.attempted: list[tuple[str, Mapping[str, Any]]] = []

    def publish(self, event_name: str, payload: Mapping[str, Any]) -> None:
        """Publish one event payload (in-memory recording)."""
        payload_copy = deepcopy(dict(payload))
        self.attempted.append((event_name, payload_copy))
        if self.operation_log is not None:
            self.operation_log.append(f"publish:{event_name}")
        if event_name in self._fail_on:
            raise RuntimeError(f"Publish failed for event: {event_name}")
        self.published.append((event_name, payload_copy))

