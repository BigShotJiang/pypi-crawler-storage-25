"""Outbound event adapters."""

from csg.infrastructure.events.event_publisher import InMemoryEventPublisher

__all__ = ["InMemoryEventPublisher"]

