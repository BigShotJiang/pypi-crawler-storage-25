"""Infrastructure parsing adapter."""

from csg.infrastructure.parsing.parser_gateway import ParserGateway

__all__ = ["ParserGateway"]
