﻿"""Per-language regex pattern configurations for Tier 3 languages.

Each module defines a RegexLanguageConfig and registers it with the
regex_parser module on import. Importing this package auto-registers
all configs.
"""

from csg.infrastructure.parsing.internal.regex_configs import rpg  # noqa: F401
from csg.infrastructure.parsing.internal.regex_configs import abap  # noqa: F401
from csg.infrastructure.parsing.internal.regex_configs import mumps  # noqa: F401
from csg.infrastructure.parsing.internal.regex_configs import assembly  # noqa: F401
from csg.infrastructure.parsing.internal.regex_configs import tcl  # noqa: F401
from csg.infrastructure.parsing.internal.regex_configs import algol  # noqa: F401
from csg.infrastructure.parsing.internal.regex_configs import forth  # noqa: F401
from csg.infrastructure.parsing.internal.regex_configs import postscript  # noqa: F401

