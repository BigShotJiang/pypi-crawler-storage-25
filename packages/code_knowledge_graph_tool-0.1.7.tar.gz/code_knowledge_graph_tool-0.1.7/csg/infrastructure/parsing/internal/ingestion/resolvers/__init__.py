﻿"""Per-language import resolvers.

Re-exports commonly used types for convenience.
"""

from csg.infrastructure.parsing.internal.ingestion.resolvers.utils import SuffixIndex, try_resolve_with_extensions, suffix_resolve
from csg.infrastructure.parsing.internal.ingestion.resolvers.go import GoModuleConfig
from csg.infrastructure.parsing.internal.ingestion.resolvers.php import ComposerConfig
from csg.infrastructure.parsing.internal.ingestion.resolvers.swift import SwiftPackageConfig
from csg.infrastructure.parsing.internal.ingestion.resolvers.csharp import CSharpProjectConfig

__all__ = [
    "SuffixIndex",
    "try_resolve_with_extensions",
    "suffix_resolve",
    "GoModuleConfig",
    "ComposerConfig",
    "SwiftPackageConfig",
    "CSharpProjectConfig",
]

