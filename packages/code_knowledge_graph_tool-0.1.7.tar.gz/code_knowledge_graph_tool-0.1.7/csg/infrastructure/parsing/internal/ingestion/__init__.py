"""Ingestion parsing internals owned by outbound adapters."""

