"""Parsing runtime internals owned by outbound adapters."""

