"""Canonical outbound gateway for parser capabilities."""

from __future__ import annotations

from typing import Any, Mapping

from csg.application.ports.parsing_gateway_port import ParsingGatewayPort

class ParserGateway(ParsingGatewayPort):
    """Minimal parser gateway contract for canonical outbound wiring."""

    def parse(self, payload: Mapping[str, Any]) -> Mapping[str, Any]:
        """Parse payload into a normalized representation."""
        raise NotImplementedError("ParserGateway.parse is not implemented yet")
