"""Runtime configuration helpers for DI composition."""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class RuntimeSettings:
    """Resolved runtime settings used by composition roots."""

    db_path_override: str | None
    cors_origins: tuple[str, ...]


def _parse_cors_origins(raw: str | None) -> tuple[str, ...]:
    if raw is None:
        return ("http://localhost:4173", "http://localhost:5173")
    items = tuple(v.strip() for v in raw.split(",") if v.strip())
    return items or ("http://localhost:4173", "http://localhost:5173")


@lru_cache(maxsize=1)
def get_runtime_settings() -> RuntimeSettings:
    """Build cached runtime settings from environment variables."""
    db_path = os.environ.get("CSG_DB_PATH")
    cors_origins = _parse_cors_origins(os.environ.get("CSG_WEB_CORS_ORIGINS"))
    return RuntimeSettings(
        db_path_override=db_path.strip() if db_path and db_path.strip() else None,
        cors_origins=cors_origins,
    )

