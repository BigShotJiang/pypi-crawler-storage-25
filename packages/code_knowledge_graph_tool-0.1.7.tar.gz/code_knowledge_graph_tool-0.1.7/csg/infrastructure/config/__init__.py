"""Infrastructure runtime configuration exports."""

from csg.infrastructure.config.ingestion import (
    DOCUMENT_EXTENSIONS,
    MAX_CONTENT_SIZE,
    MAX_DOCUMENT_FILE_SIZE,
    MAX_DOCUMENT_PAGES,
    MAX_DOCUMENT_SECTION_CONTENT,
    MAX_FILE_SIZE,
)
from csg.infrastructure.config.paths import DATA_DIR, PROJECT_ROOT, REPOS_DIR
from csg.infrastructure.config.runtime import RuntimeSettings, get_runtime_settings

__all__ = [
    "RuntimeSettings",
    "get_runtime_settings",
    "PROJECT_ROOT",
    "DATA_DIR",
    "REPOS_DIR",
    "MAX_FILE_SIZE",
    "MAX_CONTENT_SIZE",
    "DOCUMENT_EXTENSIONS",
    "MAX_DOCUMENT_FILE_SIZE",
    "MAX_DOCUMENT_PAGES",
    "MAX_DOCUMENT_SECTION_CONTENT",
]
