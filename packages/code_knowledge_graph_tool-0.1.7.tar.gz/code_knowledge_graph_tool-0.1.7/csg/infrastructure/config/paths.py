"""Filesystem and storage path configuration."""

from __future__ import annotations

import os
from pathlib import Path

_PACKAGE_DIR = Path(__file__).resolve().parents[2]  # csg/
PROJECT_ROOT = _PACKAGE_DIR.parent

DATA_DIR = Path(os.environ.get("CSG_DATA_DIR", PROJECT_ROOT / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

REPOS_DIR = DATA_DIR / "repos"
REPOS_DIR.mkdir(parents=True, exist_ok=True)

__all__ = ["PROJECT_ROOT", "DATA_DIR", "REPOS_DIR"]
