﻿"""Ingestion limits and document support configuration."""

from csg.infrastructure.config.language import (
    DOCUMENT_EXTENSIONS,
    MAX_CONTENT_SIZE,
    MAX_DOCUMENT_FILE_SIZE,
    MAX_DOCUMENT_PAGES,
    MAX_DOCUMENT_SECTION_CONTENT,
    MAX_FILE_SIZE,
)

__all__ = [
    "MAX_FILE_SIZE",
    "MAX_CONTENT_SIZE",
    "DOCUMENT_EXTENSIONS",
    "MAX_DOCUMENT_FILE_SIZE",
    "MAX_DOCUMENT_PAGES",
    "MAX_DOCUMENT_SECTION_CONTENT",
]

