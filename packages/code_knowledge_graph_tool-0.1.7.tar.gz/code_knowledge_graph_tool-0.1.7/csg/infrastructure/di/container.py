"""Centralized composition root (Phase 11 bridge)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from csg.infrastructure.embeddings.embedding_gateway import EmbeddingGateway
from csg.infrastructure.events import InMemoryEventPublisher
from csg.infrastructure.agent.agent_gateway import AgentGateway
from csg.infrastructure.graph import (
    GraphIndexAdapter,
    GraphIngestAdapter,
    GraphQueryAdapter,
    get_docs_adapter_class,
    get_escape_table_name,
    get_graph_pool,
    get_lbug_schema_primitives,
    get_ladybug_adapter_class,
    get_search_tables,
)
from csg.infrastructure.parsing.parser_gateway import ParserGateway
from csg.infrastructure.repository.api_key_store import JsonApiKeyStore
from csg.infrastructure.repository.session_store import JsonSessionStore
from csg.infrastructure.repository.user_secrets_store import JsonUserSecretsStore
from csg.infrastructure.repository.user_settings_store import JsonUserSettingsStore
from csg.infrastructure.repository.user_store import JsonUserStore
from csg.infrastructure.repository.repository_registry_adapter import RepositoryRegistryAdapter
from csg.infrastructure.repository import (
    InMemoryAnalysisJobStore,
    InMemoryUnitOfWork,
)
from csg.infrastructure.security.password_hasher import PasswordHasher
from csg.infrastructure.security.secret_cipher import SecretCipher
from csg.infrastructure.security.token_service import TokenService
from csg.infrastructure.search.search_gateway import SearchGateway
from csg.infrastructure.search import (
    get_semantic_search_result_class,
    merge_rrf,
    search_full_text,
    search_full_text_symbols,
)
from csg.infrastructure.config import RuntimeSettings, get_runtime_settings
from csg.infrastructure.sources import SourceProviderAdapter


@dataclass
class AppContainer:
    """Small bridge container exposing adapter factory methods."""

    _runtime: RuntimeSettings = field(default_factory=get_runtime_settings)
    _source_provider: SourceProviderAdapter | None = None
    _job_store: InMemoryAnalysisJobStore | None = None
    _repository_registry: RepositoryRegistryAdapter | None = None
    _api_key_store: JsonApiKeyStore | None = None
    _user_store: JsonUserStore | None = None
    _user_settings_store: JsonUserSettingsStore | None = None
    _user_secrets_store: JsonUserSecretsStore | None = None
    _session_store: JsonSessionStore | None = None
    _graph_query: GraphQueryAdapter | None = None
    _graph_ingest: GraphIngestAdapter | None = None
    _graph_index: GraphIndexAdapter | None = None
    _parser_gateway: ParserGateway | None = None
    _search_gateway: SearchGateway | None = None
    _embedding_gateway: EmbeddingGateway | None = None
    _event_publisher: InMemoryEventPublisher | None = None
    _agent_gateway: AgentGateway | None = None
    _password_hasher: PasswordHasher | None = None
    _token_service: TokenService | None = None
    _secret_cipher: SecretCipher | None = None

    def runtime(self) -> RuntimeSettings:
        """Return resolved runtime settings."""
        return self._runtime

    def get_source_provider(self) -> SourceProviderAdapter:
        if self._source_provider is None:
            self._source_provider = SourceProviderAdapter()
        return self._source_provider

    def get_job_store(self) -> InMemoryAnalysisJobStore:
        if self._job_store is None:
            self._job_store = InMemoryAnalysisJobStore()
        return self._job_store

    def get_repository_registry(self) -> RepositoryRegistryAdapter:
        if self._repository_registry is None:
            self._repository_registry = RepositoryRegistryAdapter()
        return self._repository_registry

    def get_api_key_store(self) -> JsonApiKeyStore:
        if self._api_key_store is None:
            self._api_key_store = JsonApiKeyStore()
        return self._api_key_store

    def get_user_store(self) -> JsonUserStore:
        if self._user_store is None:
            self._user_store = JsonUserStore()
        return self._user_store

    def get_user_settings_store(self) -> JsonUserSettingsStore:
        if self._user_settings_store is None:
            self._user_settings_store = JsonUserSettingsStore()
        return self._user_settings_store

    def get_user_secrets_store(self) -> JsonUserSecretsStore:
        if self._user_secrets_store is None:
            self._user_secrets_store = JsonUserSecretsStore()
        return self._user_secrets_store

    def get_session_store(self) -> JsonSessionStore:
        if self._session_store is None:
            self._session_store = JsonSessionStore()
        return self._session_store

    def get_graph_ports(self) -> dict[str, Any]:
        """Return graph capability adapters (query/ingest/index)."""
        if self._graph_query is None:
            self._graph_query = GraphQueryAdapter()
        if self._graph_ingest is None:
            self._graph_ingest = GraphIngestAdapter()
        if self._graph_index is None:
            self._graph_index = GraphIndexAdapter()
        return {
            "query": self._graph_query,
            "ingest": self._graph_ingest,
            "index": self._graph_index,
        }

    @staticmethod
    def get_graph_pool():
        return get_graph_pool()

    @staticmethod
    def get_lbug_schema_primitives():
        return get_lbug_schema_primitives()

    @staticmethod
    def get_escape_table_name():
        return get_escape_table_name()

    @staticmethod
    def get_search_tables():
        return get_search_tables()

    @staticmethod
    def get_docs_adapter_class():
        return get_docs_adapter_class()

    @staticmethod
    def get_search_helpers() -> dict[str, Any]:
        return {
            "search_full_text": search_full_text,
            "search_full_text_symbols": search_full_text_symbols,
            "merge_rrf": merge_rrf,
            "semantic_search_result_class": get_semantic_search_result_class(),
        }

    def get_event_publisher(self) -> InMemoryEventPublisher:
        if self._event_publisher is None:
            self._event_publisher = InMemoryEventPublisher()
        return self._event_publisher

    def get_parser_gateway(self) -> ParserGateway:
        if self._parser_gateway is None:
            self._parser_gateway = ParserGateway()
        return self._parser_gateway

    def get_search_gateway(self) -> SearchGateway:
        if self._search_gateway is None:
            self._search_gateway = SearchGateway()
        return self._search_gateway

    def get_embedding_gateway(self) -> EmbeddingGateway:
        if self._embedding_gateway is None:
            self._embedding_gateway = EmbeddingGateway()
        return self._embedding_gateway

    def get_agent_gateway(self) -> AgentGateway:
        if self._agent_gateway is None:
            self._agent_gateway = AgentGateway()
        return self._agent_gateway

    def get_password_hasher(self) -> PasswordHasher:
        if self._password_hasher is None:
            self._password_hasher = PasswordHasher()
        return self._password_hasher

    def get_token_service(self) -> TokenService:
        if self._token_service is None:
            self._token_service = TokenService()
        return self._token_service

    def get_secret_cipher(self) -> SecretCipher:
        if self._secret_cipher is None:
            self._secret_cipher = SecretCipher()
        return self._secret_cipher

    @staticmethod
    def get_repo_watcher(
        interval: int | None = None,
        debounce: float | None = None,
    ) -> Any:
        from csg.infrastructure.analysis.internal.analysis.watcher import get_watcher

        return get_watcher(interval, debounce)

    @staticmethod
    def run_pipeline_sync(config: Any) -> dict[str, Any]:
        from csg.infrastructure.analysis.internal.analysis.pipeline import run_pipeline

        return run_pipeline(config)

    @staticmethod
    def run_analysis_pipeline_sync(repo_path: str, *, cancel_event: Any = None) -> dict[str, Any]:
        from csg.infrastructure.analysis.internal.analysis.pipeline import run_analysis_pipeline_compat

        return run_analysis_pipeline_compat(repo_path, cancel_event=cancel_event)

    @staticmethod
    def run_incremental_pipeline_sync(repo_path: str) -> dict[str, Any]:
        from csg.infrastructure.analysis.internal.analysis.pipeline import run_incremental_pipeline

        return run_incremental_pipeline(repo_path)

    @staticmethod
    def new_unit_of_work() -> InMemoryUnitOfWork:
        """Create a fresh UoW instance per use-case transaction."""
        return InMemoryUnitOfWork()

    @staticmethod
    def build_ladybug_adapter(db_path: str, repo_source_path: str | None = None):
        """Construct the existing Ladybug adapter."""
        LadybugAdapter = get_ladybug_adapter_class()

        return LadybugAdapter(db_path=db_path, repo_source_path=repo_source_path)

    @staticmethod
    def build_mcp_backend(adapter):
        """Construct MCP backend class from inbound bridge layer."""
        from csg.infrastructure.exploration.backend import Backend
        container = get_container()
        search_helpers = container.get_search_helpers()
        return Backend(
            adapter,
            graph_pool=container.get_graph_pool(),
            repository_registry=container.get_repository_registry(),
            search_full_text=search_helpers["search_full_text"],
            search_full_text_symbols=search_helpers["search_full_text_symbols"],
            merge_rrf=search_helpers["merge_rrf"],
            semantic_search_result_class=search_helpers["semantic_search_result_class"],
            escape_table_name=container.get_escape_table_name(),
            search_tables=container.get_search_tables(),
            is_binary_source_path=container.get_source_provider().is_binary_path,
            run_pipeline_sync=container.run_pipeline_sync,
            agent_gateway=container.get_agent_gateway(),
            adapter_factory=container.build_ladybug_adapter,
        )


_CONTAINER: AppContainer | None = None


def get_container() -> AppContainer:
    """Get process-wide app container singleton."""
    global _CONTAINER
    if _CONTAINER is None:
        _CONTAINER = AppContainer()
    return _CONTAINER


def build_container() -> AppContainer:
    """Canonical composition-root API for boot targets."""
    return get_container()
