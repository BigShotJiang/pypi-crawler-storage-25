﻿"""Pipeline state - TypedDict for LangGraph StateGraph.

Port of GitNexus pipeline state, adapted for LangGraph.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import TypedDict, Any

from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph
from csg.infrastructure.analysis.internal.analysis.analysis.community_processor import CommunityMembership, CommunityNode
from csg.infrastructure.analysis.internal.analysis.analysis.process_processor import ProcessNode, ProcessStep
from csg.infrastructure.analysis.internal.analysis.analysis.resolution_context import ResolutionContext
from csg.infrastructure.parsing.internal.ingestion.resolvers.utils import SuffixIndex
from csg.infrastructure.analysis.internal.analysis.analysis.symbol_table import SymbolTable
from csg.infrastructure.parsing.internal.ingestion.parsing_processor import (
    ParseResult,
    ExtractedImport,
    ExtractedCall,
    ExtractedHeritage,
)


@dataclass
class PipelineConfig:
    """Configuration for the ingestion pipeline."""

    repo_path: str = ""
    force: bool = False
    embeddings: bool = False
    embedding_model: str = "text-embedding-3-small"
    embedding_device: str = "auto"
    embedding_batch_size: int = 32
    exclude_dirs: frozenset[str] = frozenset()
    incremental: bool = True     # Use parse cache for unchanged files
    cache_dir: str = ""          # Parse cache directory (auto-resolved if empty)
    cancel_event: threading.Event = field(default_factory=threading.Event)


@dataclass
class PipelineProgress:
    """Track pipeline progress."""

    phase: str = ""
    phase_index: int = 0
    total_phases: int = 12
    message: str = ""
    percent: int = 0


class PipelineState(TypedDict, total=False):
    """LangGraph state for the ingestion pipeline.

    Each node function takes this state and returns a partial update.
    """
    config: PipelineConfig

    repo_path: str
    repo_name: str
    knowledge_graph: KnowledgeGraph

    file_paths: list[str]
    scanned_files: list
    file_contents: dict[str, str]

    parse_result: ParseResult
    imports: list[ExtractedImport]
    calls: list[ExtractedCall]
    heritage: list[ExtractedHeritage]

    type_envs: dict

    symbol_table: SymbolTable
    resolution_context: ResolutionContext
    suffix_index: SuffixIndex

    community_nodes: list[CommunityNode]
    memberships: list[CommunityMembership]

    process_nodes: list[ProcessNode]
    process_steps: list[ProcessStep]

    cycle_edges: list[tuple[str, str]]

    progress: PipelineProgress

    cached_embeddings: list[dict]

    stats: dict[str, Any]


class PipelineCancelled(Exception):
    """Raised when a pipeline run is cancelled via cancel_event."""

    def __init__(self, phase: str = ""):
        self.phase = phase
        super().__init__(f"Pipeline cancelled during {phase}" if phase else "Pipeline cancelled")


def check_cancelled(state: PipelineState) -> None:
    """Raise PipelineCancelled if the cancel event has been set."""
    cfg = state.get("config")
    cancel_event = getattr(cfg, "cancel_event", None) if cfg else None
    if cancel_event is not None and cancel_event.is_set():
        phase = state.get("progress", PipelineProgress()).phase
        raise PipelineCancelled(phase)


