"""Analysis processor internals owned by outbound adapters."""

