"""Background repo watcher - auto-detects file changes and re-ingests."""

from __future__ import annotations

import logging
import time
import threading
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable, Iterable

from csg.infrastructure.repository.internal.repo_registry_runtime import (
    RegistryEntry,
    list_registered_repos,
)

logger = logging.getLogger(__name__)

_DEFAULT_INTERVAL = 30  # seconds
_DEFAULT_DEBOUNCE = 5.0  # seconds
_FAILURE_COOLDOWN = 300  # seconds - wait after a failed re-ingestion

_IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".csg",
    ".claude",
    ".codex",
    ".mypy_cache",
    ".omx",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "coverage",
    "dist",
    "htmlcov",
    "node_modules",
    "target",
    "venv",
}
_IGNORED_SUFFIXES = {
    ".7z",
    ".bmp",
    ".class",
    ".dll",
    ".dylib",
    ".exe",
    ".gif",
    ".ico",
    ".jar",
    ".jpeg",
    ".jpg",
    ".lock",
    ".log",
    ".o",
    ".obj",
    ".pdf",
    ".png",
    ".pyc",
    ".pyd",
    ".so",
    ".swp",
    ".tmp",
    ".zip",
}
_IGNORED_NAMES = {
    ".DS_Store",
    "Thumbs.db",
}
_IGNORED_RELATIVE_PATHS = {
    ("data", "api_keys.json"),
    ("data", "mcp.log"),
    ("data", "registry.json"),
    ("data", "registry.json.tmp"),
    ("data", "sessions.json"),
    ("data", "user_secrets.json"),
    ("data", "user_settings.json"),
    ("data", "users.json"),
}

WatchBatch = set[tuple[Any, str]]
RepoLoader = Callable[[], list[RegistryEntry]]
EventWatcher = Callable[[str, threading.Event], Iterable[WatchBatch]]
IncrementalRunner = Callable[[str], Any]


def _is_database_lock_error(exc: Exception) -> bool:
    message = str(exc).lower()
    return "read-only" in message and "write lock" in message


def should_watch_path(path: str | Path, *, repo_path: str | Path) -> bool:
    """Return True when a filesystem event path is relevant to ingestion."""
    event_path = Path(path)
    root = Path(repo_path)
    try:
        relative = event_path.resolve().relative_to(root.resolve())
    except (OSError, ValueError):
        return False

    parts = {part.lower() for part in relative.parts[:-1]}
    if parts & _IGNORED_DIRS:
        return False

    relative_key = tuple(part.lower() for part in relative.parts)
    if relative_key in _IGNORED_RELATIVE_PATHS:
        return False

    name = relative.name
    if name in _IGNORED_NAMES or name.startswith(".#") or name.endswith(("~", ".bak")):
        return False

    return relative.suffix.lower() not in _IGNORED_SUFFIXES


def _watchfiles_batches(
    path: str,
    stop_event: threading.Event,
    *,
    debounce: float,
) -> Iterable[WatchBatch]:
    from watchfiles import watch

    yield from watch(
        path,
        debounce=max(0, int(debounce * 1000)),
        stop_event=stop_event,
    )


class RepoWatcher:
    """Background watcher that auto-detects changes in indexed repos.

    Usage:
        watcher = RepoWatcher(interval=30)
        watcher.start()    # non-blocking
        ...
        watcher.stop()     # graceful shutdown
    """

    def __init__(
        self,
        interval: int = _DEFAULT_INTERVAL,
        *,
        debounce: float = _DEFAULT_DEBOUNCE,
        repo_loader: RepoLoader | None = None,
        event_watcher: EventWatcher | None = None,
        incremental_runner: IncrementalRunner | None = None,
    ) -> None:
        self._interval = interval
        self._debounce = debounce
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._running_repos: set[str] = set()  # prevents concurrent ingestion
        self._scheduled_repos: set[str] = set()
        self._watched_repos: set[str] = set()
        self._lock = threading.Lock()
        self._watch_pool = ThreadPoolExecutor(
            max_workers=8,
            thread_name_prefix="csg-watch",
        )
        self._ingest_pool = ThreadPoolExecutor(
            max_workers=2,
            thread_name_prefix="csg-incr",
        )
        self._repo_loader = repo_loader or (lambda: list_registered_repos(validate=True))
        self._event_watcher = event_watcher or (
            lambda path, stop_event: _watchfiles_batches(
                path,
                stop_event,
                debounce=self._debounce,
            )
        )
        self._incremental_runner = incremental_runner
        # Cooldown tracking: repo_path -> earliest next attempt (monotonic time)
        self._cooldowns: dict[str, float] = {}
        # Repo-level quiet-period tracking. watchfiles already batches low-level
        # events, but editors/formatters may still emit multiple batches for
        # one save. Track the last relevant path event per repo and re-ingest
        # only after the repo has been quiet for the configured debounce.
        self._last_change_at: dict[str, float] = {}

    def start(self) -> None:
        """Start the background watcher thread (daemon)."""
        if self._thread and self._thread.is_alive():
            logger.debug("Watcher already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._watch_loop,
            daemon=True,
            name="csg-watcher",
        )
        self._thread.start()
        logger.info("RepoWatcher started (debounce=%.2fs)", self._debounce)

    def stop(self) -> None:
        """Signal the watcher to stop gracefully."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        self._watch_pool.shutdown(wait=False)
        self._ingest_pool.shutdown(wait=False)
        logger.info("RepoWatcher stopped")

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def watch_once(self) -> None:
        """Process one event batch for each registered repo.

        This is primarily a small test seam; production uses ``start``.
        """
        for repo in self._load_watchable_repos():
            for changes in self._event_watcher(repo.path, self._stop_event):
                future = self._handle_changes(repo, changes)
                if future:
                    future.result(timeout=30)
                break

    def _watch_loop(self) -> None:
        """Main loop: keep a watchfiles subscription active per indexed repo."""
        while not self._stop_event.is_set():
            try:
                for repo in self._load_watchable_repos():
                    with self._lock:
                        if repo.path in self._watched_repos:
                            continue
                        self._watched_repos.add(repo.path)
                    self._watch_pool.submit(self._watch_repo, repo)
            except Exception:
                logger.exception("Watcher cycle failed")
            self._stop_event.wait(self._interval)

    def _load_watchable_repos(self) -> list[RegistryEntry]:
        repos: list[RegistryEntry] = []
        for repo in self._repo_loader():
            if self._is_watchable_repo(repo):
                repos.append(repo)
        return repos

    def _is_watchable_repo(self, repo: RegistryEntry) -> bool:
        return Path(repo.path).exists()

    def _watch_repo(self, repo: RegistryEntry) -> None:
        try:
            for changes in self._event_watcher(repo.path, self._stop_event):
                if self._stop_event.is_set():
                    break
                self._handle_changes(repo, changes)
        except Exception:
            logger.exception("Filesystem watch failed for '%s'", repo.name)
        finally:
            with self._lock:
                self._watched_repos.discard(repo.path)

    def _handle_changes(self, repo: RegistryEntry, changes: WatchBatch) -> Future | None:
        filtered = {
            str(path)
            for _, path in changes
            if should_watch_path(path, repo_path=repo.path)
        }
        if not filtered:
            logger.debug("Ignoring filesystem batch for '%s' after filtering", repo.name)
            return None

        if self._is_in_cooldown(repo.path):
            logger.debug("Skipping '%s' - incremental retry cooldown active", repo.name)
            return None

        logger.info(
            "Source changes detected in '%s' (%d path(s))",
            repo.name,
            len(filtered),
        )
        return self._schedule_incremental(repo)

    def _schedule_incremental(self, repo: RegistryEntry) -> Future | None:
        """Schedule one incremental run after the repo-level quiet period."""
        if self._debounce <= 0:
            return self._trigger_incremental(repo)

        with self._lock:
            self._last_change_at[repo.path] = time.monotonic()
            if repo.path in self._scheduled_repos:
                logger.debug("Skipping '%s' - debounce run already scheduled", repo.name)
                return None
            self._scheduled_repos.add(repo.path)

        return self._ingest_pool.submit(self._run_after_quiet_period, repo)

    def _run_after_quiet_period(self, repo: RegistryEntry) -> None:
        """Wait until no relevant events arrive for debounce seconds, then ingest."""
        while not self._stop_event.is_set():
            with self._lock:
                last_change = self._last_change_at.get(repo.path, time.monotonic())
            quiet_for = time.monotonic() - last_change
            remaining = self._debounce - quiet_for
            if remaining <= 0:
                break
            self._stop_event.wait(remaining)

        if self._stop_event.is_set():
            with self._lock:
                self._scheduled_repos.discard(repo.path)
                self._last_change_at.pop(repo.path, None)
            return

        self._run_incremental(repo)

    def _is_in_cooldown(self, repo_path: str) -> bool:
        now = time.monotonic()
        with self._lock:
            return now < self._cooldowns.get(repo_path, 0)

    def _trigger_incremental(self, repo: RegistryEntry) -> Future | None:
        """Run incremental pipeline in background for this repo."""
        with self._lock:
            if repo.path in self._running_repos:
                logger.debug("Skipping '%s' - already re-ingesting", repo.name)
                return None

        return self._ingest_pool.submit(self._run_incremental, repo)

    def _run_incremental(self, repo: RegistryEntry) -> None:
        run_started = time.monotonic()
        with self._lock:
            if repo.path in self._running_repos:
                logger.debug("Skipping '%s' - already re-ingesting", repo.name)
                return
            self._running_repos.add(repo.path)

        try:
            logger.info("Incremental re-ingestion starting for '%s'", repo.name)
            if self._incremental_runner is None:
                from csg.infrastructure.analysis.internal.analysis.pipeline import (
                    run_incremental_pipeline,
                )

                run_incremental_pipeline(repo.path)
            else:
                self._incremental_runner(repo.path)
            logger.info("Incremental re-ingestion complete for '%s'", repo.name)
            # Clear cooldown on success
            with self._lock:
                self._cooldowns.pop(repo.path, None)
        except Exception as exc:
            if _is_database_lock_error(exc):
                logger.warning(
                    "Incremental re-ingestion skipped for '%s': database is locked by another process",
                    repo.name,
                )
            else:
                logger.exception("Incremental re-ingestion failed for '%s'", repo.name)
            # Set cooldown to avoid spamming retries
            with self._lock:
                self._cooldowns[repo.path] = (
                    time.monotonic() + _FAILURE_COOLDOWN
                )
        finally:
            with self._lock:
                last_change = self._last_change_at.get(repo.path, 0)
                self._running_repos.discard(repo.path)
                self._scheduled_repos.discard(repo.path)
                self._last_change_at.pop(repo.path, None)
                should_rerun = last_change > run_started and not self._is_in_cooldown_locked(repo.path)
            if should_rerun and not self._stop_event.is_set():
                self._schedule_incremental(repo)

    def _is_in_cooldown_locked(self, repo_path: str) -> bool:
        return time.monotonic() < self._cooldowns.get(repo_path, 0)


# Module-level singleton for shared use across web/MCP
_watcher: RepoWatcher | None = None


def get_watcher(interval: int | None = None, debounce: float | None = None) -> RepoWatcher:
    """Get or create the global RepoWatcher singleton."""
    global _watcher
    if _watcher is None:
        _watcher = RepoWatcher(
            interval=interval or _DEFAULT_INTERVAL,
            debounce=_DEFAULT_DEBOUNCE if debounce is None else debounce,
        )
    return _watcher



