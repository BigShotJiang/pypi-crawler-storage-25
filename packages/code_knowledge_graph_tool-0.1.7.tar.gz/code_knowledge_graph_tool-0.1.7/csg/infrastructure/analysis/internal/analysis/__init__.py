"""Analysis runtime internals owned by outbound adapters."""

