﻿"""Infrastructure metadata extraction - Phase 2.7.

Scans File nodes for infrastructure config files (Dockerfile, docker-compose,
.env, OpenAPI, migrations, CI/CD, Kubernetes, .proto) and extracts structured
metadata. Results are stored as a JSON string in ``node._extra["infrastructure"]``
which gets persisted as the ``infrastructure`` column on File nodes in KuzuDB.

This makes infrastructure metadata queryable via Cypher and visible in
csg_explore and csg_srs without adding new node types.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import PurePosixPath

from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph

logger = logging.getLogger(__name__)

# -- File matching --------------------------------------------------------

_INFRA_MATCHERS: list[tuple[callable, str]] = []  # populated at module level below


def _match_filename(name_lower: str, path_lower: str) -> str | None:
    """Return extractor key if the file is a recognized infrastructure file."""
    for matcher, key in _INFRA_MATCHERS:
        if matcher(name_lower, path_lower):
            return key
    return None


# -- Extractors -----------------------------------------------------------

def _extract_docker_compose(content: str) -> dict | None:
    """Parse docker-compose.yml into structured service topology."""
    try:
        import yaml
        data = yaml.safe_load(content)
    except Exception:
        return None
    if not isinstance(data, dict):
        return None

    services_raw = data.get("services") or data.get("version") and data.get("services")
    if not services_raw or not isinstance(services_raw, dict):
        return None

    services = []
    for name, cfg in services_raw.items():
        if not isinstance(cfg, dict):
            continue
        svc = {"name": name}
        if cfg.get("image"):
            svc["image"] = str(cfg["image"])
        if cfg.get("build"):
            b = cfg["build"]
            svc["build"] = b if isinstance(b, str) else str(b.get("context", "."))
        if cfg.get("ports"):
            svc["ports"] = [str(p) for p in cfg["ports"]]
        deps = cfg.get("depends_on")
        if deps:
            if isinstance(deps, list):
                svc["depends_on"] = deps
            elif isinstance(deps, dict):
                svc["depends_on"] = list(deps.keys())
        env = cfg.get("environment")
        if isinstance(env, list):
            svc["environment"] = [str(e).split("=")[0] for e in env]
        elif isinstance(env, dict):
            svc["environment"] = list(env.keys())
        services.append(svc)

    networks = list((data.get("networks") or {}).keys()) if data.get("networks") else []
    return {"type": "docker_compose", "services": services, "networks": networks}


def _extract_dockerfile(content: str) -> dict | None:
    """Extract key directives from a Dockerfile."""
    result: dict = {"type": "dockerfile"}
    images = re.findall(r"^FROM\s+(\S+)", content, re.M | re.I)
    if images:
        result["base_images"] = images
    ports = re.findall(r"^EXPOSE\s+(.+)", content, re.M | re.I)
    if ports:
        result["ports"] = [p.strip() for line in ports for p in line.split()]
    envs = re.findall(r"^ENV\s+(\w+)", content, re.M | re.I)
    if envs:
        result["env_vars"] = envs
    health = re.findall(r"^HEALTHCHECK\s+(.+)", content, re.M | re.I)
    if health:
        result["healthcheck"] = health[0].strip()
    cmds = re.findall(r"^(?:CMD|ENTRYPOINT)\s+(.+)", content, re.M | re.I)
    if cmds:
        result["entrypoint"] = cmds[-1].strip()
    return result if len(result) > 1 else None


def _extract_env_file(content: str) -> dict | None:
    """Parse .env.example / .env.template into variable list."""
    variables: list[dict] = []
    last_comment = ""
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            last_comment = ""
            continue
        if stripped.startswith("#"):
            last_comment = stripped.lstrip("# ").strip()
            continue
        if "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key and re.match(r"^[A-Z_][A-Z0-9_]*$", key):
                entry: dict = {"name": key}
                if last_comment:
                    entry["comment"] = last_comment
                variables.append(entry)
        last_comment = ""
    return {"type": "env_file", "variables": variables} if variables else None


def _extract_openapi(content: str) -> dict | None:
    """Extract endpoints and schemas from OpenAPI/Swagger spec."""
    try:
        import yaml
        data = yaml.safe_load(content)
    except Exception:
        try:
            data = json.loads(content)
        except Exception:
            return None

    if not isinstance(data, dict):
        return None
    if not (data.get("openapi") or data.get("swagger")):
        return None

    info = data.get("info", {})
    result: dict = {
        "type": "openapi",
        "title": info.get("title", ""),
        "version": info.get("version", ""),
    }

    endpoints = []
    for path, methods in (data.get("paths") or {}).items():
        if not isinstance(methods, dict):
            continue
        for method, detail in methods.items():
            if method.startswith("x-") or method == "parameters":
                continue
            summary = ""
            if isinstance(detail, dict):
                summary = detail.get("summary", "") or detail.get("operationId", "")
            endpoints.append({"method": method.upper(), "path": path, "summary": summary})
            if len(endpoints) >= 50:
                break
        if len(endpoints) >= 50:
            break
    result["endpoints"] = endpoints

    schemas = []
    components = data.get("components", {}).get("schemas") or data.get("definitions") or {}
    for name in list(components.keys())[:30]:
        schemas.append(name)
    result["schemas"] = schemas

    return result


def _extract_migration(content: str, file_path: str) -> dict | None:
    """Extract table/column definitions from database migration files."""
    tables: list[dict] = []

    # SQL patterns
    for m in re.finditer(
        r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\"']?(\w+)[`\"']?\s*\(([^;]+)\)",
        content, re.I | re.S
    ):
        table_name = m.group(1)
        cols_text = m.group(2)
        columns = []
        for col_match in re.finditer(r"[`\"']?(\w+)[`\"']?\s+((?:VARCHAR|INT|TEXT|BOOLEAN|DATE|TIMESTAMP|DOUBLE|FLOAT|DECIMAL|SERIAL|BIGINT|SMALLINT|UUID|JSONB?|BLOB|CHAR)\w*)", cols_text, re.I):
            columns.append({"name": col_match.group(1), "type": col_match.group(2).upper()})
        tables.append({"table": table_name, "operation": "CREATE", "columns": columns})

    # ALTER TABLE
    for m in re.finditer(
        r"ALTER\s+TABLE\s+[`\"']?(\w+)[`\"']?\s+ADD\s+(?:COLUMN\s+)?[`\"']?(\w+)[`\"']?\s+(\w+)",
        content, re.I
    ):
        tables.append({
            "table": m.group(1),
            "operation": "ALTER_ADD",
            "columns": [{"name": m.group(2), "type": m.group(3).upper()}],
        })

    # Django/Alembic: op.create_table or CreateModel
    for m in re.finditer(r"(?:op\.create_table|CreateModel)\s*\(\s*['\"](\w+)['\"]", content):
        if not any(t["table"] == m.group(1) for t in tables):
            tables.append({"table": m.group(1), "operation": "CREATE", "columns": []})

    # Rails: create_table
    for m in re.finditer(r"create_table\s+[:\"](\w+)", content):
        if not any(t["table"] == m.group(1) for t in tables):
            tables.append({"table": m.group(1), "operation": "CREATE", "columns": []})

    return {"type": "migration", "tables": tables} if tables else None


def _extract_ci_cd(content: str, file_path: str) -> dict | None:
    """Extract stages and triggers from CI/CD config files."""
    path_lower = file_path.lower().replace("\\", "/")

    if ".github/workflows" in path_lower:
        provider = "github_actions"
    elif "gitlab-ci" in path_lower:
        provider = "gitlab_ci"
    elif "jenkinsfile" in path_lower.split("/")[-1].lower():
        provider = "jenkins"
    elif "azure-pipelines" in path_lower:
        provider = "azure_devops"
    elif "bitbucket-pipelines" in path_lower:
        provider = "bitbucket"
    else:
        provider = "unknown"

    result: dict = {"type": "ci_cd", "provider": provider}

    try:
        import yaml
        data = yaml.safe_load(content)
        if not isinstance(data, dict):
            return result
    except Exception:
        return result

    # GitHub Actions
    if provider == "github_actions":
        triggers = list((data.get("on") or {}).keys()) if isinstance(data.get("on"), dict) else []
        jobs = list((data.get("jobs") or {}).keys())
        result["triggers"] = triggers[:10]
        result["jobs"] = jobs[:10]

    # GitLab CI
    elif provider == "gitlab_ci":
        stages = data.get("stages", [])
        jobs = [k for k in data.keys() if not k.startswith(".") and k != "stages" and k != "variables"]
        result["stages"] = stages[:10] if isinstance(stages, list) else []
        result["jobs"] = jobs[:15]

    return result


def _extract_kubernetes(content: str) -> dict | None:
    """Extract resource definitions from Kubernetes manifests."""
    try:
        import yaml
        docs = list(yaml.safe_load_all(content))
    except Exception:
        return None

    resources = []
    for doc in docs:
        if not isinstance(doc, dict) or "kind" not in doc:
            continue
        res: dict = {"kind": doc["kind"]}
        metadata = doc.get("metadata", {})
        if metadata.get("name"):
            res["name"] = metadata["name"]

        spec = doc.get("spec", {})
        if doc["kind"] == "Deployment":
            res["replicas"] = spec.get("replicas")
            container = ((spec.get("template", {}).get("spec", {}).get("containers")) or [{}])[0]
            if container.get("image"):
                res["image"] = container["image"]
            limits = (container.get("resources", {}).get("limits")) or {}
            if limits:
                res["resource_limits"] = {k: str(v) for k, v in limits.items()}
        elif doc["kind"] == "Service":
            ports = spec.get("ports", [])
            res["ports"] = [{"port": p.get("port"), "targetPort": p.get("targetPort")} for p in ports[:5]]
        elif doc["kind"] == "Ingress":
            rules = spec.get("rules", [])
            hosts = [r.get("host", "") for r in rules if r.get("host")]
            res["hosts"] = hosts

        resources.append(res)

    return {"type": "kubernetes", "resources": resources} if resources else None


def _extract_proto(content: str) -> dict | None:
    """Extract service and message definitions from .proto files."""
    services = []
    for m in re.finditer(r"service\s+(\w+)\s*\{([^}]+)\}", content):
        name = m.group(1)
        body = m.group(2)
        methods = re.findall(r"rpc\s+(\w+)\s*\((\w+)\)\s*returns\s*\((\w+)\)", body)
        services.append({
            "name": name,
            "methods": [{"name": n, "request": req, "response": resp} for n, req, resp in methods],
        })

    messages = []
    for m in re.finditer(r"message\s+(\w+)\s*\{([^}]+)\}", content):
        name = m.group(1)
        body = m.group(2)
        fields = re.findall(r"(\w+)\s+(\w+)\s*=\s*(\d+)", body)
        messages.append({
            "name": name,
            "fields": [{"type": t, "name": n} for t, n, _ in fields],
        })

    if not services and not messages:
        return None
    return {"type": "proto", "services": services, "messages": messages}


# -- Matcher registration -------------------------------------------------

def _is_docker_compose(name: str, path: str) -> bool:
    return name in ("docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml")

def _is_dockerfile(name: str, path: str) -> bool:
    return name == "dockerfile" or name.startswith("dockerfile.")

def _is_env_file(name: str, path: str) -> bool:
    return name in (".env.example", ".env.template", ".env.sample", ".env.dev", ".env.production")

def _is_openapi(name: str, path: str) -> bool:
    return name in ("openapi.yaml", "openapi.yml", "openapi.json", "swagger.yaml", "swagger.yml", "swagger.json")

def _is_migration(name: str, path: str) -> bool:
    return (
        "/migrations/" in path or "/migrate/" in path or "/alembic/versions/" in path
        or "/db/migrate/" in path
    ) and (name.endswith(".sql") or name.endswith(".py") or name.endswith(".rb"))

def _is_ci_cd(name: str, path: str) -> bool:
    return (
        ".github/workflows/" in path
        or name == ".gitlab-ci.yml"
        or name.lower() == "jenkinsfile"
        or name == "azure-pipelines.yml"
        or name == "bitbucket-pipelines.yml"
    )

def _is_kubernetes(name: str, path: str) -> bool:
    return (
        "/k8s/" in path or "/kubernetes/" in path or "/deploy/" in path
        or "/helm/" in path or "/manifests/" in path
    ) and (name.endswith(".yaml") or name.endswith(".yml"))

def _is_proto(name: str, path: str) -> bool:
    return name.endswith(".proto")


_INFRA_MATCHERS = [
    (_is_docker_compose, "docker_compose"),
    (_is_dockerfile, "dockerfile"),
    (_is_env_file, "env_file"),
    (_is_openapi, "openapi"),
    (_is_migration, "migration"),
    (_is_ci_cd, "ci_cd"),
    (_is_kubernetes, "kubernetes"),
    (_is_proto, "proto"),
]

_EXTRACTORS: dict[str, callable] = {
    "docker_compose": lambda c, p: _extract_docker_compose(c),
    "dockerfile": lambda c, p: _extract_dockerfile(c),
    "env_file": lambda c, p: _extract_env_file(c),
    "openapi": lambda c, p: _extract_openapi(c),
    "migration": _extract_migration,
    "ci_cd": _extract_ci_cd,
    "kubernetes": lambda c, p: _extract_kubernetes(c),
    "proto": lambda c, p: _extract_proto(c),
}


# -- Main entry point -----------------------------------------------------

def extract_infrastructure(graph: KnowledgeGraph) -> dict:
    """Scan File nodes for infrastructure files and extract metadata.

    Stores results as a JSON string in ``node._extra["infrastructure"]``,
    which gets serialized to the ``infrastructure`` column on File nodes.

    Returns summary dict with counts per extractor type.
    """
    counts: dict[str, int] = {}

    for node in graph.iter_nodes():
        if node.label != "File":
            continue
        content = node.properties.content
        if not content:
            continue

        file_path = node.properties.file_path or ""
        name_lower = PurePosixPath(file_path).name.lower()
        path_lower = file_path.lower().replace("\\", "/")

        extractor_key = _match_filename(name_lower, path_lower)
        if not extractor_key:
            continue

        extractor = _EXTRACTORS.get(extractor_key)
        if not extractor:
            continue

        try:
            result = extractor(content, file_path)
        except Exception as exc:
            logger.debug("Infrastructure extraction failed for %s: %s", file_path, exc)
            continue

        if result:
            if node.properties._extra is None:
                node.properties._extra = {}
            node.properties._extra["infrastructure"] = json.dumps(result, default=str)
            counts[extractor_key] = counts.get(extractor_key, 0) + 1

    total = sum(counts.values())
    if total:
        logger.info("Infrastructure extraction: %d files - %s", total, counts)
    else:
        logger.info("Infrastructure extraction: no infrastructure files found")

    return counts

