"""Schema definitions for the document knowledge graph (docs/ database).

Separate from the code graph schema (lbug_schema.py).
Tables: DocFile, DocSection, DocRelation, DocEmbedding.
"""

from __future__ import annotations


DOC_NODE_TABLES: dict[str, list[tuple[str, str]]] = {
    "DocFile": [
        ("id", "STRING"),
        ("name", "STRING"),
        ("filePath", "STRING"),
        ("docType", "STRING"),
        ("pageCount", "INT32"),
    ],
    "DocSection": [
        ("id", "STRING"),
        ("name", "STRING"),
        ("searchText", "STRING"),
        ("filePath", "STRING"),
        ("startLine", "INT32"),
        ("endLine", "INT32"),
        ("level", "INT32"),
        ("content", "STRING"),
        ("description", "STRING"),
        ("docType", "STRING"),
    ],
    "DocEmbedding": [
        ("id", "STRING"),
        ("text", "STRING"),
        ("vector", "FLOAT[384]"),
    ],
}

DOC_REL_TABLE = "DocRelation"
DOC_REL_COLUMNS: list[tuple[str, str]] = [
    ("id", "STRING"),
    ("type", "STRING"),
    ("confidence", "DOUBLE"),
    ("reason", "STRING"),
]

# All valid (FROM, TO) pairs for DocRelation edges.
DOC_REL_FROM_TO: list[tuple[str, str]] = [
    ("DocFile", "DocSection"),
    ("DocSection", "DocSection"),
]

DOC_FTS_TABLES: list[tuple[str, str]] = [
    ("doc_section_fts", "DocSection"),
]


def create_doc_schema_sql() -> list[str]:
    """Return the ordered list of Cypher statements to create the doc schema."""
    stmts: list[str] = []

    for table, cols in DOC_NODE_TABLES.items():
        col_defs = ", ".join(f"{name} {dtype}" for name, dtype in cols)
        stmts.append(f"CREATE NODE TABLE IF NOT EXISTS {table}({col_defs}, PRIMARY KEY (id))")

    # Relation table
    from_to = ", ".join(f"FROM {f} TO {t}" for f, t in DOC_REL_FROM_TO)
    rel_cols = ", ".join(f"{name} {dtype}" for name, dtype in DOC_REL_COLUMNS)
    stmts.append(
        f"CREATE REL TABLE IF NOT EXISTS {DOC_REL_TABLE}({from_to}, {rel_cols})"
    )

    return stmts


def create_doc_fts_sql() -> list[str]:
    """Return Cypher statements to create FTS indexes on doc tables."""
    stmts: list[str] = []
    for idx_name, table in DOC_FTS_TABLES:
        stmts.append(
            f"CALL CREATE_FTS_INDEX('{table}', 'name', '{idx_name}', "
            f"stemmer := 'none', stopwords := '')"
        )
    return stmts
