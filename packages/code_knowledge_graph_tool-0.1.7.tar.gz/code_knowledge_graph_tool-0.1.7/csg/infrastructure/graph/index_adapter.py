"""Outbound adapter for graph index management capability."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Mapping, Any

from csg.application.ports.graph_index_port import GraphIndexPort

IndexCreator = Callable[[str], None]


class GraphIndexAdapter(GraphIndexPort):
    """Bridge adapter for creating indexes and reporting index status."""

    def __init__(self, create_fn: IndexCreator | None = None) -> None:
        self._create_fn = create_fn or self._default_create_indexes

    def create_indexes(self, repo_path: str) -> None:
        """Create/rebuild indexes for a repository graph database."""
        resolved = str(Path(repo_path).resolve())
        self._create_fn(resolved)

    def index_status(self, repo_path: str) -> Mapping[str, Any]:
        """Return deterministic status for graph index persistence path."""
        from csg.infrastructure.repository import get_storage_path_for_repo

        resolved = str(Path(repo_path).resolve())
        db_path = str(get_storage_path_for_repo(resolved) / "lbug")
        exists = os.path.exists(db_path)
        return {
            "repo_path": resolved,
            "db_path": db_path,
            "exists": exists,
            "index_ready": exists,
        }

    @staticmethod
    def _default_create_indexes(repo_path: str) -> None:
        """Create bridge indexes with existing Ladybug adapter behavior."""
        from csg.infrastructure.graph import get_ladybug_adapter_class
        from csg.infrastructure.repository import get_storage_path_for_repo

        db_path = str(get_storage_path_for_repo(repo_path) / "lbug")
        if not os.path.exists(db_path):
            raise FileNotFoundError(f"Graph database not found at {db_path}")

        LadybugAdapter = get_ladybug_adapter_class()
        adapter = LadybugAdapter(db_path=db_path)
        adapter.connect()
        try:
            adapter.create_fts_indexes()
            try:
                adapter.create_vector_index()
            except RuntimeError:
                # Vector extension may be unavailable in some environments.
                pass
        finally:
            adapter.close()
