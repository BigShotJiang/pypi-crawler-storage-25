"""Outbound adapter for graph read/query capability."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable, Mapping

from csg.application.ports.graph_query_port import GraphQueryPort
from csg.domain.repository_ids import repository_id_from_storage_path

QueryExecutor = Callable[[str, str, Mapping[str, Any] | None], list[dict[str, Any]]]
WRITE_QUERY_RE = re.compile(
    r"\b(CREATE|MERGE|SET|DELETE|REMOVE|DROP|ALTER|CALL\s+CREATE)\b",
    re.IGNORECASE,
)


class GraphQueryAdapter(GraphQueryPort):
    """Bridge adapter for read-only graph querying."""

    def __init__(
        self,
        executor: QueryExecutor | None = None,
        write_query_re: re.Pattern[str] | None = None,
    ) -> None:
        self._executor = executor or self._default_executor
        if write_query_re is not None:
            self._write_query_re = write_query_re
        else:
            self._write_query_re = WRITE_QUERY_RE

    def query(
        self,
        repo_id: str,
        cypher: str,
        params: Mapping[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute read-only query against resolved repository graph DB."""
        if self._write_query_re.search(cypher):
            raise ValueError("Write operations are not allowed. Only read queries are supported.")
        return self._executor(repo_id, cypher, params)

    def _default_executor(
        self,
        repo_id: str,
        cypher: str,
        params: Mapping[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Default bridge executor via KuzuPool + registered repo resolution."""
        from csg.infrastructure.graph import get_graph_pool
        from csg.infrastructure.repository import (
            get_storage_path_for_repo,
            list_registered_repos_for_api,
        )

        repo_path: str | None = None
        for entry in list_registered_repos_for_api(validate=False):
            storage_name = Path(entry.storage_path).name
            storage_id = repository_id_from_storage_path(entry.storage_path)
            if repo_id in {entry.path, entry.name, storage_name, storage_id}:
                repo_path = entry.path
                break
        if repo_path is None:
            repo_path = repo_id

        db_path = str(get_storage_path_for_repo(repo_path) / "lbug")
        conn = get_graph_pool().get_connection(db_path, read_only=True)
        result = conn.execute(cypher, params or {})
        columns = result.get_column_names()
        rows: list[dict[str, Any]] = []
        while result.has_next():
            rows.append(dict(zip(columns, result.get_next())))
        return rows
