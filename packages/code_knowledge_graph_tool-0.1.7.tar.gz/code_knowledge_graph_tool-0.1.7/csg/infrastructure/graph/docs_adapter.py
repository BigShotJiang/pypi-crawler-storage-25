"""Adapter for the document knowledge graph (docs/ database).

Wraps a separate KuzuDB instance at data/repos/{hash}/docs/.
Mirrors the LadybugAdapter pattern but with the document schema.
"""

from __future__ import annotations

import logging
import os

from csg.infrastructure.graph.docs_schema import (
    create_doc_fts_sql,
    create_doc_schema_sql,
)

logger = logging.getLogger(__name__)


class DocsAdapter:
    """KuzuDB adapter for the document graph."""

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        self._conn = None

    @property
    def db_path(self) -> str:
        return self._db_path

    def connect(self, read_only: bool = False) -> None:
        """Open the database via KuzuPool."""
        from csg.infrastructure.graph.kuzu_pool import KuzuPool

        pool = KuzuPool.get()
        if not read_only:
            os.makedirs(self._db_path, exist_ok=True)
        self._conn = pool.get_connection(self._db_path, read_only=read_only)
        logger.info("DocsAdapter connected to %s (read_only=%s)", self._db_path, read_only)

    def close(self) -> None:
        """Release the connection."""
        self._conn = None

    def create_schema(self) -> None:
        """Create document tables if they don't exist."""
        if self._conn is None:
            raise RuntimeError("Not connected - call connect() first")
        for stmt in create_doc_schema_sql():
            try:
                self._conn.execute(stmt)
            except Exception as exc:
                logger.debug("Schema statement skipped: %s - %s", stmt[:80], exc)

    def create_fts_indexes(self) -> None:
        """Create FTS indexes on document tables."""
        if self._conn is None:
            raise RuntimeError("Not connected")
        for stmt in create_doc_fts_sql():
            try:
                self._conn.execute(stmt)
            except Exception as exc:
                logger.debug("FTS index skipped: %s - %s", stmt[:80], exc)

    def execute_query(self, cypher: str, params: dict | None = None) -> list[dict]:
        """Execute a Cypher query and return results as list of dicts."""
        if self._conn is None:
            raise RuntimeError("Not connected")
        if params:
            result = self._conn.execute(cypher, params)
        else:
            result = self._conn.execute(cypher)
        rows: list[dict] = []
        while result.has_next():
            rows.append(result.get_next())
        return rows

    def insert_doc_file(
        self,
        file_id: str,
        name: str,
        file_path: str,
        doc_type: str,
        page_count: int,
    ) -> None:
        """Insert a DocFile node."""
        self.execute_query(
            "CREATE (n:DocFile {id: $id, name: $name, filePath: $fp, "
            "docType: $dt, pageCount: $pc})",
            {"id": file_id, "name": name, "fp": file_path, "dt": doc_type, "pc": page_count},
        )

    def insert_doc_section(
        self,
        section_id: str,
        name: str,
        search_text: str,
        file_path: str,
        start_line: int,
        end_line: int,
        level: int,
        content: str,
        description: str,
        doc_type: str,
    ) -> None:
        """Insert a DocSection node."""
        self.execute_query(
            "CREATE (n:DocSection {id: $id, name: $name, searchText: $st, "
            "filePath: $fp, startLine: $sl, endLine: $el, level: $lv, "
            "content: $ct, description: $desc, docType: $dt})",
            {
                "id": section_id, "name": name, "st": search_text,
                "fp": file_path, "sl": start_line, "el": end_line,
                "lv": level, "ct": content, "desc": description, "dt": doc_type,
            },
        )

    def insert_doc_relation(
        self,
        from_table: str,
        from_id: str,
        to_table: str,
        to_id: str,
        rel_id: str,
        rel_type: str,
        confidence: float = 1.0,
        reason: str = "",
    ) -> None:
        """Insert a DocRelation edge."""
        self.execute_query(
            f"MATCH (a:{from_table} {{id: $fid}}), (b:{to_table} {{id: $tid}}) "
            "CREATE (a)-[:DocRelation {id: $rid, type: $rt, confidence: $conf, reason: $rsn}]->(b)",
            {"fid": from_id, "tid": to_id, "rid": rel_id, "rt": rel_type, "conf": confidence, "rsn": reason},
        )

    def search_fts(self, query: str, limit: int = 10) -> list[dict]:
        """Full-text search across DocSection nodes."""
        escaped = query.replace("\\", "\\\\").replace("'", "''")
        try:
            return self.execute_query(
                f"CALL FTS_SEARCH('DocSection', 'doc_section_fts', '{escaped}', "
                f"conjunctive := false, top_k := {limit}) "
                "RETURN node.id AS id, node.name AS name, node.filePath AS filePath, "
                "node.content AS content, node.docType AS docType, score"
            )
        except Exception:
            logger.debug("FTS search failed, falling back to CONTAINS", exc_info=True)
            return self.execute_query(
                "MATCH (n:DocSection) WHERE n.name CONTAINS $q "
                "RETURN n.id AS id, n.name AS name, n.filePath AS filePath, "
                "n.content AS content, n.docType AS docType "
                "LIMIT $lim",
                {"q": query, "lim": limit},
            )

    def count_sections(self) -> int:
        """Return total DocSection count."""
        rows = self.execute_query("MATCH (n:DocSection) RETURN count(n) AS cnt")
        return rows[0]["cnt"] if rows else 0

    def count_files(self) -> int:
        """Return total DocFile count."""
        rows = self.execute_query("MATCH (n:DocFile) RETURN count(n) AS cnt")
        return rows[0]["cnt"] if rows else 0

