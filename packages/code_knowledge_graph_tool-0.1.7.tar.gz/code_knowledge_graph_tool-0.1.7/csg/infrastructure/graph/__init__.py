"""Infrastructure graph adapters."""

from csg.infrastructure.graph.ingest_adapter import GraphIngestAdapter
from csg.infrastructure.graph.index_adapter import GraphIndexAdapter
from csg.infrastructure.graph.query_adapter import GraphQueryAdapter


def get_graph_pool():
    """Return the shared graph pool singleton."""
    from csg.infrastructure.graph.kuzu_pool import KuzuPool

    return KuzuPool.get()


def get_lbug_schema_primitives():
    """Return legacy lbug schema primitives for bounded adapter usage."""
    from csg.infrastructure.graph.lbug_schema import NODE_TABLES, escape_table_name

    return NODE_TABLES, escape_table_name


def get_escape_table_name():
    """Return the legacy lbug table-name escaper for bounded adapter usage."""
    from csg.infrastructure.graph.lbug_schema import escape_table_name

    return escape_table_name


def get_search_tables():
    """Return legacy lbug search tables for bounded adapter usage."""
    from csg.infrastructure.graph.lbug_adapter import SEARCH_TABLES

    return SEARCH_TABLES


def get_ladybug_adapter_class():
    """Return LadybugAdapter class via canonical outbound wrapper."""
    from csg.infrastructure.graph.lbug_adapter import LadybugAdapter

    return LadybugAdapter


def get_docs_adapter_class():
    """Return DocsAdapter class via canonical outbound wrapper."""
    from csg.infrastructure.graph.docs_adapter import DocsAdapter

    return DocsAdapter


__all__ = [
    "GraphQueryAdapter",
    "GraphIngestAdapter",
    "GraphIndexAdapter",
    "get_graph_pool",
    "get_lbug_schema_primitives",
    "get_escape_table_name",
    "get_search_tables",
    "get_ladybug_adapter_class",
    "get_docs_adapter_class",
]
