"""Outbound adapter for graph ingest/replace capability."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Mapping

from csg.application.ports.graph_ingest_port import GraphIngestPort

GraphSaver = Callable[[str, dict[str, Any]], str]


class GraphIngestAdapter(GraphIngestPort):
    """Bridge adapter persisting graph payload via graph.json cache path."""

    def __init__(self, saver: GraphSaver | None = None) -> None:
        self._saver = saver or self._default_saver

    def replace(self, repo_path: str, graph_payload: Mapping[str, Any]) -> Mapping[str, Any]:
        """Replace persisted graph payload for repo and return ingest stats."""
        resolved = str(Path(repo_path).resolve())
        payload = dict(graph_payload)
        saved_path = self._saver(resolved, payload)
        summary = payload.get("summary") if isinstance(payload.get("summary"), Mapping) else {}
        return {
            "status": "ok",
            "repo_path": resolved,
            "graph_json_path": saved_path,
            "summary": dict(summary),
        }

    @staticmethod
    def _default_saver(repo_path: str, graph_payload: dict[str, Any]) -> str:
        """Persist graph payload into storage graph.json via outbound concerns only."""
        from csg.infrastructure.repository import get_storage_path_for_repo

        storage = get_storage_path_for_repo(repo_path)
        storage.mkdir(parents=True, exist_ok=True)
        path = storage / "graph.json"
        tmp_path = path.with_suffix(".json.tmp")
        tmp_path.write_text(json.dumps(graph_payload, default=str), encoding="utf-8")
        tmp_path.replace(path)
        return str(path)
