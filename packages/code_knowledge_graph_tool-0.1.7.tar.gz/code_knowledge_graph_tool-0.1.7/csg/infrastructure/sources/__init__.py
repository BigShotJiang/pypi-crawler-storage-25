"""Outbound source adapters."""

from csg.infrastructure.sources.source_provider_adapter import SourceProviderAdapter

__all__ = ["SourceProviderAdapter"]

