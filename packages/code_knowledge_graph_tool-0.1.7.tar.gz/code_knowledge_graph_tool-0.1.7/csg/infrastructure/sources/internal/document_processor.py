"""Document ingestion pipeline - orchestrates conversion, cleaning, and storage.

Pipeline per file:
1. Kreuzberg converts any document to markdown
2. preprocess_markdown cleans emoji, icons, whitespace
3. extract_sections parses headings into sections
4. DocsAdapter stores DocFile + DocSection nodes in the docs/ database
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from csg.infrastructure.config.ingestion import DOCUMENT_EXTENSIONS
from csg.infrastructure.graph.docs_adapter import DocsAdapter
from csg.infrastructure.sources.internal.document_converter import (
    ExtractedSection,
    convert_to_markdown_sync,
    extract_sections,
    preprocess_markdown,
)
from csg.infrastructure.search.internal.tokenizer_runtime import split_identifier

logger = logging.getLogger(__name__)


@dataclass
class DocumentResult:
    """Summary of document ingestion."""
    files_processed: int = 0
    sections_created: int = 0
    errors: int = 0


def _generate_id(prefix: str, *parts: str) -> str:
    """Generate a deterministic node ID."""
    joined = ":".join(parts)
    return f"{prefix}:{joined}"


def _make_search_text(heading: str, content: str) -> str:
    """Build searchable text from heading + content snippet."""
    parts = [split_identifier(heading)]
    if content:
        parts.append(content[:200])
    return " ".join(parts)


def process_documents(
    doc_paths: list[str],
    repo_path: str,
    docs_adapter: DocsAdapter,
    on_progress: callable | None = None,
) -> DocumentResult:
    """Ingest document files into the docs/ knowledge graph.

    For each file:
    1. Convert to markdown via Kreuzberg (91+ formats)
    2. Pre-process: strip emoji/icons, normalize whitespace
    3. Extract heading-based sections
    4. Insert DocFile + DocSection nodes + CONTAINS edges

    Args:
        doc_paths: Relative paths to document files.
        repo_path: Absolute path to the repository root.
        docs_adapter: Connected DocsAdapter for the docs/ database.
        on_progress: Optional callback(current, total, file_path).

    Returns:
        DocumentResult with processing counts.
    """
    result = DocumentResult()
    total = len(doc_paths)

    for i, rel_path in enumerate(doc_paths):
        abs_path = Path(repo_path) / rel_path
        if on_progress:
            on_progress(i + 1, total, rel_path)

        if not abs_path.exists():
            logger.warning("Document not found: %s", abs_path)
            result.errors += 1
            continue

        ext = abs_path.suffix.lower()
        if ext not in DOCUMENT_EXTENSIONS:
            continue

        try:
            _ingest_one_file(rel_path, abs_path, ext, docs_adapter, result)
        except Exception as exc:
            logger.error("Failed to ingest %s: %s", rel_path, exc, exc_info=True)
            result.errors += 1

    logger.info(
        "Document ingestion: %d files, %d sections, %d errors",
        result.files_processed, result.sections_created, result.errors,
    )
    return result


def _ingest_one_file(
    rel_path: str,
    abs_path: Path,
    ext: str,
    adapter: DocsAdapter,
    result: DocumentResult,
) -> None:
    """Convert, clean, section, and store a single document."""
    # 1. Convert to markdown
    raw_md = convert_to_markdown_sync(abs_path)
    if not raw_md.strip():
        logger.debug("Empty conversion result for %s", rel_path)
        return

    # 2. Pre-process
    clean_md = preprocess_markdown(raw_md)
    if not clean_md.strip():
        logger.debug("Empty after preprocessing for %s", rel_path)
        return

    # 3. Extract sections
    sections = extract_sections(clean_md, rel_path)
    if not sections:
        # No headings or text - create a single section from the whole content
        sections = [ExtractedSection(
            heading=abs_path.stem,
            level=1,
            content=clean_md[:2000],
            page_or_index=1,
            description="document",
        )]

    # 4. Insert DocFile node
    file_id = _generate_id("DocFile", rel_path)
    adapter.insert_doc_file(
        file_id=file_id,
        name=abs_path.name,
        file_path=rel_path,
        doc_type=ext.lstrip("."),
        page_count=len(sections),
    )
    result.files_processed += 1

    # 5. Insert DocSection nodes + CONTAINS edges
    parent_stack: list[tuple[int, str]] = []  # (level, section_id)

    for idx, section in enumerate(sections):
        section_id = _generate_id("DocSection", rel_path, f"L{section.page_or_index}", section.heading[:50])
        search_text = _make_search_text(section.heading, section.content)

        adapter.insert_doc_section(
            section_id=section_id,
            name=section.heading,
            search_text=search_text,
            file_path=rel_path,
            start_line=section.page_or_index,
            end_line=section.page_or_index,
            level=section.level,
            content=section.content,
            description=section.description,
            doc_type=ext.lstrip("."),
        )
        result.sections_created += 1

        # Build hierarchy: File -> h1 -> h2 -> h3 ...
        # Pop stack until we find a parent with lower level
        while parent_stack and parent_stack[-1][0] >= section.level:
            parent_stack.pop()

        if parent_stack:
            parent_id = parent_stack[-1][1]
            parent_table = "DocSection"
        else:
            parent_id = file_id
            parent_table = "DocFile"

        rel_id = _generate_id("DocRel", parent_id, section_id)
        adapter.insert_doc_relation(
            from_table=parent_table,
            from_id=parent_id,
            to_table="DocSection",
            to_id=section_id,
            rel_id=rel_id,
            rel_type="CONTAINS",
        )

        parent_stack.append((section.level, section_id))




