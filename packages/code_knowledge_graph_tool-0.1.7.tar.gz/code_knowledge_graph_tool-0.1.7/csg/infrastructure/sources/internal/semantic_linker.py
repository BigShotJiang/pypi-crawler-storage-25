﻿"""Semantic linker - connect documentation sections to code symbols.

After embeddings are generated (Phase 12), this phase compares every
Section node's embedding against code symbol embeddings and creates
DESCRIBES edges where similarity exceeds a threshold.

This bridges the gap between "what the code does" (Phases 3-9) and
"why the code exists" (documentation), enabling multi-resolution
graph traversal:

  Resolution 0 - Module Map     -> Folders, Communities, aggregated edges
  Resolution 1 - Symbol Map     -> Functions, Classes, CALLS/EXTENDS edges
  Resolution 2 - Execution Map  -> Process steps, ordered flows
  Resolution 3 - Semantic Map   -> Sections + DESCRIBES edges to code symbols
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph
from csg.infrastructure.parsing.internal.ast_helpers import generate_id
from csg.domain.codebase.value_objects import GraphRelationship, RelationshipType

logger = logging.getLogger(__name__)

DEFAULT_SIMILARITY_THRESHOLD = 0.65
AMBIGUOUS_REVIEW_LABEL = "AMBIGUOUS"
AMBIGUOUS_SIMILARITY_MARGIN = 0.05

MAX_DESCRIBES_PER_SECTION = 5

MIN_SECTION_CONTENT_LENGTH = 20

DESCRIBABLE_LABELS = frozenset({
    "Function", "Class", "Method", "Interface", "Struct",
    "Enum", "Trait", "Module",
})


@dataclass
class SemanticLinkResult:
    """Result of the semantic linking phase."""
    sections_processed: int
    describes_edges_created: int
    documented_by_edges_created: int
    avg_similarity: float


def link_sections_to_symbols(
    graph: KnowledgeGraph,
    adapter,
    similarity_threshold: float = DEFAULT_SIMILARITY_THRESHOLD,
) -> SemanticLinkResult:
    """Create DESCRIBES edges between Section nodes and code symbols.

    Uses the vector index in LadybugDB to find code symbols whose
    embeddings are similar to each Section's embedding.

    Args:
        graph: In-memory knowledge graph (Section + code symbol nodes).
        adapter: LadybugAdapter with vector search capability.
        similarity_threshold: Minimum cosine similarity for a DESCRIBES edge.

    Returns:
        SemanticLinkResult with counts.
    """
    sections = []
    for node in graph.iter_nodes():
        if node.label != "Section":
            continue
        props = node.properties
        content = props.get("content", "")
        name = props.get("name", "")
        if not content or len(content) < MIN_SECTION_CONTENT_LENGTH:
            continue
        sections.append(node)

    if not sections:
        logger.debug("Semantic linker: no qualifying Section nodes found")
        return SemanticLinkResult(0, 0, 0, 0.0)

    logger.info("Semantic linker: linking %d sections to code symbols", len(sections))

    total_describes = 0
    total_documented_by = 0
    total_similarity = 0.0

    for section in sections:
        props = section.properties
        content = props.get("content", "")
        name = props.get("name", "")
        file_path = props.get("file_path", "")

        query_text = f"{name}\n{content[:500]}" if content else name

        try:
            results = adapter.vector_search(
                query_text=query_text,
                top_k=MAX_DESCRIBES_PER_SECTION * 2,
                use_mmr=False,
            )
        except Exception as exc:
            logger.debug("Vector search failed for section: %s", exc)
            continue

        edges_for_section = 0
        for result in results:
            if edges_for_section >= MAX_DESCRIBES_PER_SECTION:
                break

            similarity = result.get("similarity", 0.0)
            if similarity < similarity_threshold:
                continue

            target_label = result.get("label", "")
            if target_label not in DESCRIBABLE_LABELS:
                continue

            target_id = result.get("nodeId", "")
            if not target_id:
                continue

            target_file = result.get("filePath", "")
            if target_file and file_path and target_file == file_path:
                continue

            review_label = (
                AMBIGUOUS_REVIEW_LABEL
                if similarity <= similarity_threshold + AMBIGUOUS_SIMILARITY_MARGIN
                else None
            )

            edge_id = generate_id("DESCRIBES", f"{section.id}->{target_id}")
            graph.add_relationship(GraphRelationship(
                id=edge_id,
                source_id=section.id,
                target_id=target_id,
                type=RelationshipType.DESCRIBES,
                confidence=round(similarity, 3),
                reason="embedding-similarity",
                review_label=review_label,
            ))

            rev_edge_id = generate_id("DOCUMENTED_BY", f"{target_id}->{section.id}")
            graph.add_relationship(GraphRelationship(
                id=rev_edge_id,
                source_id=target_id,
                target_id=section.id,
                type=RelationshipType.DOCUMENTED_BY,
                confidence=round(similarity, 3),
                reason="embedding-similarity",
                review_label=review_label,
            ))

            total_describes += 1
            total_documented_by += 1
            total_similarity += similarity
            edges_for_section += 1

    avg_sim = total_similarity / total_describes if total_describes > 0 else 0.0

    logger.info(
        "Semantic linker: %d DESCRIBES + %d DOCUMENTED_BY edges (avg similarity: %.3f)",
        total_describes, total_documented_by, avg_sim,
    )

    return SemanticLinkResult(
        sections_processed=len(sections),
        describes_edges_created=total_describes,
        documented_by_edges_created=total_documented_by,
        avg_similarity=round(avg_sim, 3),
    )



