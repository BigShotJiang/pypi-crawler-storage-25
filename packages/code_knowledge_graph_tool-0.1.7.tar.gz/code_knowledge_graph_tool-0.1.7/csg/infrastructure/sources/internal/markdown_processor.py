﻿"""Markdown processor - extract Section nodes from .md files.

Port of GitNexus ingestion/markdown-processor.ts.
Uses regex (no tree-sitter dependency) to extract heading hierarchy
and cross-file links from markdown files.
"""

from __future__ import annotations

import logging
import os
import posixpath
import re
from dataclasses import dataclass

from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph
from csg.infrastructure.parsing.internal.ast_helpers import generate_id
from csg.domain.codebase.value_objects import (
    GraphNode,
    GraphRelationship,
    NodeLabel,
    NodeProperties,
    RelationshipType,
)

logger = logging.getLogger(__name__)

HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$")
LINK_RE = re.compile(r"\[([^\]]*)\]\(([^)]+)\)")
MD_EXTENSIONS = frozenset({".md", ".mdx"})

MAX_SECTION_CONTENT = 500


@dataclass
class MarkdownResult:
    """Result of markdown processing."""

    sections: int
    links: int


def process_markdown(
    graph: KnowledgeGraph,
    files: list[dict[str, str]],
    all_path_set: set[str],
) -> MarkdownResult:
    """Extract Section nodes and cross-file link edges from markdown files.

    Creates a heading hierarchy using CONTAINS relationships:
      File -> Section (h1) -> Section (h2) -> Section (h3) ...

    Creates IMPORTS relationships for local file links found in markdown.

    Args:
        graph: The knowledge graph to populate.
        files: List of dicts with ``path`` and ``content`` keys.
        all_path_set: Set of all known file paths in the repo (for link resolution).

    Returns:
        MarkdownResult with counts of sections and links created.
    """
    total_sections = 0
    total_links = 0

    for file in files:
        file_path: str = file["path"]
        content: str = file["content"]

        _, ext = os.path.splitext(file_path)
        if ext.lower() not in MD_EXTENSIONS:
            continue

        file_node_id = generate_id("File", file_path)

        if graph.get_node(file_node_id) is None:
            continue

        lines = content.split("\n")

        headings: list[dict] = []
        for i, line in enumerate(lines):
            match = HEADING_RE.match(line)
            if not match:
                continue
            headings.append({
                "level": len(match.group(1)),
                "heading": match.group(2).strip(),
                "line_num": i + 1,
            })

        section_stack: list[dict] = []

        for h_idx, h in enumerate(headings):
            level = h["level"]
            heading = h["heading"]
            line_num = h["line_num"]

            end_line = len(lines)
            for j in range(h_idx + 1, len(headings)):
                if headings[j]["level"] <= level:
                    end_line = headings[j]["line_num"] - 1
                    break

            section_id = generate_id("Section", f"{file_path}:L{line_num}:{heading}")

            body_lines = lines[line_num:end_line]
            body = "\n".join(body_lines).strip()
            if len(body) > MAX_SECTION_CONTENT:
                body = body[:MAX_SECTION_CONTENT]

            node = GraphNode(
                id=section_id,
                label=NodeLabel.SECTION,
                properties=NodeProperties(
                    name=heading,
                    file_path=file_path,
                    start_line=line_num,
                    end_line=end_line,
                    level=level,
                    description=f"h{level}",
                    content=body if body else None,
                ),
            )
            graph.add_node(node)
            total_sections += 1

            while section_stack and section_stack[-1]["level"] >= level:
                section_stack.pop()

            parent_id = section_stack[-1]["id"] if section_stack else file_node_id

            graph.add_relationship(GraphRelationship(
                id=generate_id("CONTAINS", f"{parent_id}->{section_id}"),
                source_id=parent_id,
                target_id=section_id,
                type=RelationshipType.CONTAINS,
                confidence=1.0,
                reason="markdown-heading",
            ))

            section_stack.append({"level": level, "id": section_id})

        file_dir = posixpath.dirname(file_path.replace("\\", "/"))
        seen_links: set[str] = set()

        for match in LINK_RE.finditer(content):
            href = match.group(2)

            if (
                href.startswith("http://")
                or href.startswith("https://")
                or href.startswith("#")
                or href.startswith("mailto:")
            ):
                continue

            clean_href = href.split("#")[0]
            if not clean_href:
                continue

            resolved = posixpath.normpath(posixpath.join(file_dir, clean_href))

            if resolved in all_path_set:
                target_file_id = generate_id("File", resolved)

                if graph.get_node(target_file_id) is None:
                    continue

                link_key = f"{file_node_id}->{target_file_id}"
                if link_key in seen_links:
                    continue
                seen_links.add(link_key)

                graph.add_relationship(GraphRelationship(
                    id=generate_id("IMPORTS", link_key),
                    source_id=file_node_id,
                    target_id=target_file_id,
                    type=RelationshipType.IMPORTS,
                    confidence=0.8,
                    reason="markdown-link",
                ))
                total_links += 1

    logger.info("Markdown: %d sections, %d cross-file links", total_sections, total_links)
    return MarkdownResult(sections=total_sections, links=total_links)



