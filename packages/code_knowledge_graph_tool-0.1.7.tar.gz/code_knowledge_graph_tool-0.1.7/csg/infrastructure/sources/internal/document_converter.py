"""Document-to-markdown converter with pre-processing.

Pipeline: raw file → Kreuzberg → clean markdown → extracted sections.
Handles 91+ file formats via Kreuzberg (Rust core, zero system deps).
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from pathlib import Path

from csg.infrastructure.config.ingestion import MAX_DOCUMENT_SECTION_CONTENT
from csg.infrastructure.sources.internal.ocr_backend import ocr_file_to_markdown

logger = logging.getLogger(__name__)

# Heading regex — same pattern as markdown_processor.py
HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)

# Emoji and decorative Unicode ranges to strip
_EMOJI_RE = re.compile(
    "["
    "\U0001F600-\U0001F9FF"  # Emoticons, symbols, pictographs
    "\U0001FA00-\U0001FA6F"  # Chess, extended-A
    "\U0001FA70-\U0001FAFF"  # Symbols extended-A
    "\U00002702-\U000027B0"  # Dingbats
    "\U0000FE00-\U0000FE0F"  # Variation selectors
    "\U0000200D"             # Zero-width joiner
    "\U00002640-\U00002642"  # Gender symbols
    "\U000023CF-\U000023FA"  # Misc technical
    "\U0000200B-\U0000200F"  # Zero-width chars
    "\U0000FEFF"             # BOM / zero-width no-break space
    "]+",
    re.UNICODE,
)

# Control chars except \t \n \r
_CONTROL_RE = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+")
_OCR_FALLBACK_EXTENSIONS = {".pdf"}
_MIN_USEFUL_PDF_CHARS = 200
_PAGE_ARTIFACT_RE = re.compile(r"^(?:page\s*)?\d+$|^page\s+\d+\s*(?:of\s+\d+)?$", re.IGNORECASE)
_LOW_INFORMATION_RE = re.compile(r"^(?:scan|scanned|image|figure|untitled|document)$", re.IGNORECASE)


@dataclass
class ExtractedSection:
    """A section extracted from a document."""
    heading: str
    level: int
    content: str
    page_or_index: int
    description: str  # "h1", "h2", "page", "sheet"


async def convert_to_markdown(file_path: Path) -> str:
    """Convert any document to markdown using Kreuzberg.

    Supports 91+ formats (DOCX, PDF, PPTX, XLSX, HTML, RTF, EML, etc.).
    Returns raw markdown string before pre-processing.
    """
    result = await _extract_from_file(file_path)
    content = result.content or ""
    if not _should_try_ocr_fallback(content, file_path):
        return content

    logger.info("Low-quality document conversion for %s; trying OCR fallback", file_path)
    ocr_content = await ocr_file_to_markdown(file_path)
    return ocr_content or content


async def _extract_from_file(file_path: Path):
    """Small wrapper around Kreuzberg to keep OCR fallback behavior testable."""
    from kreuzberg import extract_from_file

    return await extract_from_file(file_path)


def convert_to_markdown_sync(file_path: Path) -> str:
    """Synchronous wrapper for convert_to_markdown."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import anyio
        return anyio.from_thread.run(convert_to_markdown, file_path)
    return asyncio.run(convert_to_markdown(file_path))


def _should_try_ocr_fallback(markdown: str, file_path: Path) -> bool:
    """Return whether extracted PDF text looks too weak to trust."""
    if file_path.suffix.lower() not in _OCR_FALLBACK_EXTENSIONS:
        return False

    text = markdown.strip()
    if not text:
        return True

    if "\ufffd" in text:
        return True

    useful_chars = sum(1 for ch in text if ch.isalnum())
    if useful_chars < _MIN_USEFUL_PDF_CHARS:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if not lines:
            return True
        artifact_lines = sum(1 for line in lines if _looks_like_extraction_artifact(line))
        if artifact_lines / len(lines) >= 0.5:
            return True

    return False


def _looks_like_extraction_artifact(line: str) -> bool:
    compact = line.strip()
    if len(compact) <= 2:
        return True
    return bool(_PAGE_ARTIFACT_RE.match(compact) or _LOW_INFORMATION_RE.match(compact))


def preprocess_markdown(raw_md: str) -> str:
    """Clean raw markdown output.

    - Strip emoji, dingbats, variation selectors, zero-width chars
    - Remove control characters
    - Collapse triple+ newlines to double
    - Strip trailing whitespace per line
    - Remove empty heading sections (heading followed immediately by another heading)
    """
    if not raw_md:
        return ""

    text = _EMOJI_RE.sub("", raw_md)
    text = _CONTROL_RE.sub("", text)

    # Normalize line endings
    text = text.replace("\r\n", "\n")

    # Collapse excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)

    # Strip trailing whitespace per line
    lines = [line.rstrip() for line in text.split("\n")]
    text = "\n".join(lines)

    # Remove empty heading sections (heading with no body before next heading)
    text = re.sub(r"^(#{1,6}\s+.+)\n+(#{1,6}\s)", r"\1\n\2", text, flags=re.MULTILINE)

    return text.strip()


def extract_sections(
    markdown: str,
    file_path: str,
    max_content: int = MAX_DOCUMENT_SECTION_CONTENT,
) -> list[ExtractedSection]:
    """Parse clean markdown into heading-based sections.

    If no headings are found, chunks the entire text into sections
    of approximately max_content characters at paragraph boundaries.
    """
    if not markdown.strip():
        return []

    headings = list(HEADING_RE.finditer(markdown))

    if not headings:
        return _chunk_to_sections(markdown, file_path, max_content)

    sections: list[ExtractedSection] = []

    for i, match in enumerate(headings):
        level = len(match.group(1))
        heading = match.group(2).strip()
        start = match.start()

        # Find end: next heading or end of text
        if i + 1 < len(headings):
            end = headings[i + 1].start()
        else:
            end = len(markdown)

        body = markdown[start:end]
        # Remove the heading line itself from body
        body = body[match.end() - match.start():].strip()

        if not body and not heading:
            continue

        content = body[:max_content] if body else ""
        line_num = markdown[:start].count("\n") + 1

        sections.append(ExtractedSection(
            heading=heading,
            level=level,
            content=content,
            page_or_index=line_num,
            description=f"h{level}",
        ))

    return sections


def _chunk_to_sections(
    text: str,
    file_path: str,
    max_content: int,
) -> list[ExtractedSection]:
    """Split text without headings into chunks at paragraph boundaries."""
    paragraphs = re.split(r"\n\n+", text.strip())
    sections: list[ExtractedSection] = []
    current_chunk: list[str] = []
    current_len = 0
    chunk_idx = 1

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        if current_len + len(para) > max_content and current_chunk:
            sections.append(ExtractedSection(
                heading=f"Section {chunk_idx}",
                level=1,
                content="\n\n".join(current_chunk),
                page_or_index=chunk_idx,
                description="chunk",
            ))
            current_chunk = []
            current_len = 0
            chunk_idx += 1

        current_chunk.append(para)
        current_len += len(para)

    if current_chunk:
        sections.append(ExtractedSection(
            heading=f"Section {chunk_idx}",
            level=1,
            content="\n\n".join(current_chunk),
            page_or_index=chunk_idx,
            description="chunk",
        ))

    return sections

