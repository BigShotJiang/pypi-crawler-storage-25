"""Configurable OCR backend — dispatches to local or cloud provider.

Configured via CSG_OCR_PROVIDER env var:
  - openai  (default) — OpenAI vision/PDF input, configurable via CSG_OCR_MODEL
  - paddle  — PaddleOCR, local, free, best CJK
  - gemini  — Google Gemini Flash (free tier, multimodal)
"""

from __future__ import annotations

import base64
import logging
import mimetypes
import os
from pathlib import Path

from csg.infrastructure.runtime.user_context import (
    get_user_runtime_settings,
    require_user_openai_api_key,
)

logger = logging.getLogger(__name__)

_PROVIDER_ENV = "CSG_OCR_PROVIDER"
_MODEL_ENV = "CSG_OCR_MODEL"
_DEFAULT_PROVIDER = "openai"
_DEFAULT_OPENAI_MODEL = "gpt-5-nano"
_IMAGE_MIME_TYPES = {
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/gif",
}


def get_ocr_provider() -> str:
    """Return the configured OCR provider name."""
    runtime_provider = get_user_runtime_settings().ocr_provider.strip().lower()
    if runtime_provider:
        return runtime_provider
    return os.environ.get(_PROVIDER_ENV, _DEFAULT_PROVIDER).lower()


async def ocr_image(image_bytes: bytes, language_hint: str = "") -> str:
    """Extract text from image bytes using the configured OCR backend.

    Args:
        image_bytes: Raw image data (PNG, JPEG, TIFF, etc.).
        language_hint: Optional BCP-47 language hint (e.g. "vi", "ja").

    Returns:
        Extracted text as a string, or empty string on failure.
    """
    provider = get_ocr_provider()

    if provider == "gemini":
        return await _ocr_gemini(image_bytes, language_hint)
    elif provider == "openai":
        text = await _ocr_openai_bytes(image_bytes, "image/png", language_hint)
        return text or await _ocr_paddle(image_bytes, language_hint)
    elif provider == "paddle":
        return await _ocr_paddle(image_bytes, language_hint)
    else:
        logger.warning("Unknown OCR provider '%s', falling back to paddle", provider)
        return await _ocr_paddle(image_bytes, language_hint)


async def ocr_file_to_markdown(file_path: Path, language_hint: str = "") -> str:
    """Extract readable document text as clean markdown.

    OpenAI is the default because it can read PDF file inputs directly. If the
    configured cloud provider is unavailable or returns no text, local PaddleOCR
    is used as a best-effort fallback.
    """
    provider = get_ocr_provider()

    if provider == "openai":
        text = await _ocr_openai_file(file_path, language_hint)
        return text or await _ocr_paddle_file(file_path, language_hint)
    if provider == "gemini":
        text = await _ocr_gemini_file(file_path, language_hint)
        return text or await _ocr_paddle_file(file_path, language_hint)
    if provider == "paddle":
        return await _ocr_paddle_file(file_path, language_hint)

    logger.warning("Unknown OCR provider '%s', falling back to OpenAI then paddle", provider)
    text = await _ocr_openai_file(file_path, language_hint)
    return text or await _ocr_paddle_file(file_path, language_hint)


def _ocr_markdown_prompt(language_hint: str) -> str:
    lang_note = f" The source may contain {language_hint} text." if language_hint else ""
    return (
        "Extract all readable text from the provided document and return ONLY clean Markdown."
        f"{lang_note}\n\n"
        "Rules:\n"
        "- Preserve the natural reading order.\n"
        "- Use Markdown headings (#, ##, ###) for visible titles and section headings.\n"
        "- Preserve tables as Markdown tables when the structure is clear.\n"
        "- Preserve lists, numbers, dates, currency values, IDs, and Vietnamese accents exactly.\n"
        "- Do not summarize, translate, explain, or add commentary.\n"
        "- Do not infer hidden or unclear text; write [illegible] for unreadable fragments.\n"
        "- Do not wrap the result in code fences.\n"
        "- If there is no readable text, return an empty string."
    )


# ── PaddleOCR (local, default) ─────────────────────────────────────


async def _ocr_paddle(image_bytes: bytes, _language_hint: str) -> str:
    """Local OCR via PaddleOCR. Requires: pip install kreuzberg[paddle]"""
    try:
        from kreuzberg import extract_from_buffer

        result = await extract_from_buffer(
            image_bytes,
            mime_type="image/png",
            ocr_backend="paddleocr",
        )
        return result.content
    except ImportError:
        logger.error("PaddleOCR not installed. Run: pip install kreuzberg[paddle]")
        return ""
    except Exception as exc:
        logger.error("PaddleOCR failed: %s", exc)
        return ""


async def _ocr_paddle_file(file_path: Path, _language_hint: str) -> str:
    """Local OCR/conversion via Kreuzberg + PaddleOCR for file inputs."""
    try:
        from kreuzberg import extract_from_file

        result = await extract_from_file(file_path, ocr_backend="paddleocr")
        return result.content
    except ImportError:
        logger.error("PaddleOCR not installed. Run: pip install kreuzberg[paddle]")
        return ""
    except Exception as exc:
        logger.error("PaddleOCR file OCR failed for %s: %s", file_path, exc)
        return ""


# ── OpenAI vision/PDF OCR ───────────────────────────────────────────


async def _ocr_openai_file(file_path: Path, language_hint: str) -> str:
    """OCR via OpenAI Responses API. Requires a user-scoped OpenAI API key."""
    mime_type = mimetypes.guess_type(file_path.name)[0] or "application/pdf"
    try:
        return await _ocr_openai_bytes(file_path.read_bytes(), mime_type, language_hint, filename=file_path.name)
    except OSError as exc:
        logger.error("Failed to read OCR input %s: %s", file_path, exc)
        return ""


async def _ocr_openai_bytes(
    file_bytes: bytes,
    mime_type: str,
    language_hint: str,
    *,
    filename: str = "document.pdf",
) -> str:
    """OCR via OpenAI Responses API for PDF or image bytes."""
    try:
        from openai import OpenAI

        try:
            api_key = require_user_openai_api_key()
        except RuntimeError as exc:
            logger.error("%s", exc)
            return ""

        client = OpenAI(api_key=api_key)
        model = os.environ.get(_MODEL_ENV, _DEFAULT_OPENAI_MODEL)
        encoded = base64.b64encode(file_bytes).decode("ascii")
        prompt = _ocr_markdown_prompt(language_hint)

        if mime_type == "application/pdf":
            source = {
                "type": "input_file",
                "filename": filename,
                "file_data": encoded,
            }
        elif mime_type in _IMAGE_MIME_TYPES:
            source = {
                "type": "input_image",
                "image_url": f"data:{mime_type};base64,{encoded}",
                "detail": "high",
            }
        else:
            logger.warning("OpenAI OCR does not support mime type '%s'", mime_type)
            return ""

        response = client.responses.create(
            model=model,
            input=[{
                "role": "user",
                "content": [
                    {"type": "input_text", "text": prompt},
                    source,
                ],
            }],
        )
        return (getattr(response, "output_text", "") or "").strip()
    except ImportError:
        logger.error("openai package not installed. Install an OpenAI-compatible dependency.")
        return ""
    except Exception as exc:
        logger.error("OpenAI OCR failed: %s", exc)
        return ""


# ── Google Gemini Flash ────────────────────────────────────────────


async def _ocr_gemini(image_bytes: bytes, language_hint: str) -> str:
    """OCR via Google Gemini Flash (multimodal LLM). Requires GOOGLE_API_KEY."""
    try:
        from google import genai

        api_key = os.environ.get("GOOGLE_API_KEY", "")
        if not api_key:
            logger.error("GOOGLE_API_KEY not set for Gemini OCR")
            return ""

        client = genai.Client(api_key=api_key)

        prompt = _ocr_markdown_prompt(language_hint)

        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=[prompt, {"mime_type": "image/png", "data": image_bytes}],
        )
        return response.text or ""
    except ImportError:
        logger.error("google-genai not installed. Run: pip install google-genai")
        return ""
    except Exception as exc:
        logger.error("Gemini OCR failed: %s", exc)
        return ""


async def _ocr_gemini_file(file_path: Path, language_hint: str) -> str:
    """Best-effort Gemini OCR for image files only."""
    mime_type = mimetypes.guess_type(file_path.name)[0] or ""
    if mime_type not in _IMAGE_MIME_TYPES:
        logger.warning("Gemini OCR fallback only supports image files, got '%s'", mime_type)
        return ""
    try:
        return await _ocr_gemini(file_path.read_bytes(), language_hint)
    except OSError as exc:
        logger.error("Failed to read OCR input %s: %s", file_path, exc)
        return ""
