﻿"""Outbound adapter for source preparation.

Phase 7 bridge implementation: local-path normalization with deterministic
cleanup behavior for explicitly ephemeral sources.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Mapping

from csg.application.ports.source_provider_port import SourceProviderPort


def is_binary_source_path(path: str) -> bool:
    """Canonical source-path binary check delegated to legacy content filter."""
    from csg.infrastructure.sources.internal.content_filter import is_binary_path

    return is_binary_path(path)


def process_documents_sync(*, doc_paths: list[str], repo_path: str, docs_adapter: Any) -> Any:
    """Canonical sync wrapper around legacy document processing."""
    from csg.infrastructure.sources.internal.document_processor import process_documents

    return process_documents(
        doc_paths=doc_paths,
        repo_path=repo_path,
        docs_adapter=docs_adapter,
    )


class SourceProviderAdapter(SourceProviderPort):
    """SourceProviderPort implementation for local filesystem sources."""

    def prepare(self, source_ref: str, *, kind: str, branch: str | None = None) -> Mapping[str, Any]:
        """Normalize a local source path into prepared-source metadata."""
        normalized_kind = (kind or "local").strip().lower()
        if normalized_kind not in {"local", "path", "repo"}:
            raise ValueError(f"Unsupported source kind: {kind}")

        repo_path = Path(source_ref).resolve()
        if not repo_path.exists():
            raise FileNotFoundError(f"Source path does not exist: {repo_path}")
        if not repo_path.is_dir():
            raise NotADirectoryError(f"Source path is not a directory: {repo_path}")

        return {
            "kind": "local",
            "source_ref": source_ref,
            "repo_path": str(repo_path),
            "branch": branch,
            "ephemeral": False,
            "cleanup_path": None,
        }

    def cleanup(self, prepared_source: Mapping[str, Any]) -> None:
        """Delete prepared source only when explicitly marked ephemeral."""
        cleanup_path = prepared_source.get("cleanup_path")
        if not prepared_source.get("ephemeral") or not cleanup_path:
            return
        shutil.rmtree(str(cleanup_path), ignore_errors=True)

    def is_binary_path(self, path: str) -> bool:
        """Check whether a source path should be treated as binary."""
        return is_binary_source_path(path)

    def process_documents(self, *, doc_paths: list[str], repo_path: str, docs_adapter: Any) -> Any:
        """Process documents through the outbound document pipeline."""
        return process_documents_sync(
            doc_paths=doc_paths,
            repo_path=repo_path,
            docs_adapter=docs_adapter,
        )

