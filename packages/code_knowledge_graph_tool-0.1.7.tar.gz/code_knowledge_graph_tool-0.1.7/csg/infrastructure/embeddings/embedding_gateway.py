"""Canonical outbound gateway for embedding capabilities."""

from __future__ import annotations

from typing import Sequence

from csg.application.ports.embedding_gateway_port import EmbeddingGatewayPort

class EmbeddingGateway(EmbeddingGatewayPort):
    """Minimal embedding gateway contract for canonical outbound wiring."""

    def embed(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
        """Embed input texts into vector representations."""
        raise NotImplementedError("EmbeddingGateway.embed is not implemented yet")
