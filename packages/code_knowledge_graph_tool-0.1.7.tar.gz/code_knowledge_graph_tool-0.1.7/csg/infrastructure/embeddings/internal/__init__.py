"""Embeddings runtime internals owned by outbound adapters."""

