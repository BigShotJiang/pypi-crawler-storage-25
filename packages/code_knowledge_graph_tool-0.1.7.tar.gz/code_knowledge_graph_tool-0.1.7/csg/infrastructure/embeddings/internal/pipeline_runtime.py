﻿"""Embedding pipeline - LangChain embeddings orchestration.

Uses OpenAI embeddings by default with a 768-dimension vector to match the
LadybugDB schema, falling back to local HuggingFace embeddings when OpenAI is
unavailable.
"""

from __future__ import annotations

import json
import importlib.util
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Protocol, Sequence

from csg.infrastructure.config.paths import DATA_DIR
from csg.infrastructure.runtime.user_context import (
    get_user_runtime_settings,
    require_user_openai_api_key,
)

from csg.infrastructure.embeddings.internal.text_generator_runtime import (
    EmbeddableNode,
    EMBEDDABLE_LABELS,
    generate_embedding_text,
)
from csg.infrastructure.graph.knowledge_graph import KnowledgeGraph

if TYPE_CHECKING:
    from langchain_huggingface import HuggingFaceEmbeddings

logger = logging.getLogger(__name__)

DEFAULT_MODEL_ID = "text-embedding-3-small"
LOCAL_FALLBACK_MODEL_ID = "nomic-ai/CodeRankEmbed"
DEFAULT_BATCH_SIZE = 32
DEFAULT_DIMENSIONS = 768
DEFAULT_MAX_SNIPPET_LENGTH = 500

QUERY_PREFIX = "Represent this query for searching relevant code: "


class EmbeddingsModel(Protocol):
    active_model_id: str

    def embed_documents(self, texts: Sequence[str]) -> list[list[float]]:
        """Embed a batch of documents."""

    def embed_query(self, text: str) -> list[float]:
        """Embed a search query."""


def _esc_csv(val) -> str:
    """Escape a value for safe CSV embedding (RFC 4180)."""
    if val is None:
        return ""
    s = str(val)
    if '"' in s or ',' in s or '\n' in s:
        return '"' + s.replace('"', '""') + '"'
    return s


_model_instance: EmbeddingsModel | None = None
_model_config: tuple[str, str, int] | None = None


_detected_device: str | None = None


def detect_device() -> str:
    """Auto-detect the best available device for embeddings (logs once)."""
    global _detected_device
    if _detected_device is not None:
        return _detected_device
    try:
        import torch

        if torch.cuda.is_available():
            logger.info("CUDA detected - using GPU for embeddings")
            _detected_device = "cuda"
            return _detected_device
    except ImportError:
        pass
    _detected_device = "cpu"
    return _detected_device


_MODEL_CACHE_DIR = Path(os.environ.get("CSG_MODEL_CACHE", DATA_DIR / "models"))


def _model_cache_root(model_id: str, cache_dir: Path) -> Path:
    """Return the Hugging Face cache root for *model_id*."""
    model_slug = model_id.replace("/", "--")
    return cache_dir / f"models--{model_slug}"


def _resolve_cache_pointer(path: Path, cache_root: Path) -> Path | None:
    """Resolve a text placeholder pointing at ``../../blobs/<hash>``.

    Some model caches are created on platforms that preserve Hugging Face
    symlinks, then checked out on Windows where those symlinks become plain
    text files containing the relative target path. SentenceTransformer then
    tries to parse those placeholders as JSON and fails. This helper detects
    that shape and returns the blob target so it can be materialized.
    """
    try:
        raw = path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        return None

    if not raw.startswith(".."):
        return None

    target = (path.parent / raw).resolve()
    try:
        target.relative_to(cache_root.resolve())
    except ValueError:
        return None

    if "blobs" not in target.parts or not target.is_file():
        return None
    return target


def _materialize_hf_snapshot_placeholders(cache_root: Path) -> int:
    """Replace snapshot placeholder files with their blob contents."""
    snapshots_dir = cache_root / "snapshots"
    if not snapshots_dir.is_dir():
        return 0

    repaired = 0
    for snapshot_dir in snapshots_dir.iterdir():
        if not snapshot_dir.is_dir():
            continue
        for path in snapshot_dir.rglob("*"):
            if not path.is_file():
                continue
            target = _resolve_cache_pointer(path, cache_root)
            if target is None:
                continue
            path.write_bytes(target.read_bytes())
            repaired += 1

    if repaired:
        logger.info(
            "Materialized %d Hugging Face cache placeholder files under %s",
            repaired,
            cache_root,
        )
    return repaired


def _is_valid_json_file(path: Path) -> bool:
    """Return True if *path* contains parseable JSON."""
    try:
        with path.open(encoding="utf-8") as fh:
            json.load(fh)
        return True
    except (OSError, json.JSONDecodeError):
        return False


def _is_model_cached(model_id: str, cache_dir: Path) -> bool:
    """Check if the model weights are already downloaded to the local cache."""
    cache_root = _model_cache_root(model_id, cache_dir)
    if not cache_root.exists():
        return False

    _materialize_hf_snapshot_placeholders(cache_root)

    ref_path = cache_root / "refs" / "main"
    if not ref_path.is_file():
        return False

    try:
        snapshot_name = ref_path.read_text(encoding="utf-8").strip()
    except OSError:
        return False
    if not snapshot_name:
        return False

    snapshot_dir = cache_root / "snapshots" / snapshot_name
    required_jsons = (
        snapshot_dir / "config.json",
        snapshot_dir / "config_sentence_transformers.json",
        snapshot_dir / "modules.json",
    )
    return snapshot_dir.is_dir() and all(_is_valid_json_file(path) for path in required_jsons)


def _is_openai_model(model_id: str) -> bool:
    return model_id.startswith("text-embedding-") or model_id.startswith("openai:")


def _openai_model_name(model_id: str) -> str:
    return model_id.removeprefix("openai:")


def _has_openai_embedding_config() -> bool:
    """Return whether the user has configured an OpenAI key for this request."""
    try:
        require_user_openai_api_key()
    except RuntimeError:
        return False
    return True


def _has_local_embedding_runtime() -> bool:
    """Return whether local Hugging Face embedding dependencies are installed."""
    return (
        importlib.util.find_spec("sentence_transformers") is not None
        and importlib.util.find_spec("langchain_huggingface") is not None
    )


def can_run_embeddings(model_id: str = DEFAULT_MODEL_ID) -> bool:
    """Return whether embeddings can run for the given model in this environment."""
    provider = get_user_runtime_settings().embedding_provider
    if provider == "local":
        return _has_local_embedding_runtime()
    if _is_openai_model(model_id):
        return _has_openai_embedding_config()
    return _has_local_embedding_runtime()


def _create_local_model(model_id: str = LOCAL_FALLBACK_MODEL_ID, device: str = "auto") -> HuggingFaceEmbeddings:
    """Create a local HuggingFace embedding model."""
    resolved_device = detect_device() if device == "auto" else device

    from langchain_huggingface import HuggingFaceEmbeddings

    _MODEL_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    local_files_only = _is_model_cached(model_id, _MODEL_CACHE_DIR)

    if local_files_only:
        logger.info("Loading embedding model %s from local cache (offline)", model_id)
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
    else:
        logger.info("Downloading embedding model %s on %s", model_id, resolved_device)

    try:
        model = HuggingFaceEmbeddings(
            model_name=model_id,
            cache_folder=str(_MODEL_CACHE_DIR),
            model_kwargs={
                "device": resolved_device,
                "trust_remote_code": True,
                "local_files_only": local_files_only,
            },
            encode_kwargs={"normalize_embeddings": True},
        )
        model.active_model_id = model_id
        return model
    finally:
        if local_files_only:
            os.environ.pop("HF_HUB_OFFLINE", None)
            os.environ.pop("TRANSFORMERS_OFFLINE", None)


class FallbackEmbeddings:
    """Use a primary embedding model and lazily fall back to a local model."""

    def __init__(self, primary: EmbeddingsModel, *, primary_model_id: str, fallback_model_id: str, device: str):
        self.primary = primary
        self.primary_model_id = primary_model_id
        self.fallback_model_id = fallback_model_id
        self.device = device
        self.fallback: EmbeddingsModel | None = None
        self._primary_available = True

    @property
    def active_model_id(self) -> str:
        if self._primary_available:
            return self.primary_model_id
        return self.fallback_model_id

    def _get_fallback(self) -> EmbeddingsModel:
        if self.fallback is None:
            logger.warning(
                "OpenAI embedding unavailable; falling back to local model %s",
                self.fallback_model_id,
            )
            self.fallback = _create_local_model(self.fallback_model_id, self.device)
        return self.fallback

    def embed_documents(self, texts: Sequence[str]) -> list[list[float]]:
        if not self._primary_available:
            return self._get_fallback().embed_documents(list(texts))
        try:
            return self.primary.embed_documents(list(texts))
        except Exception as exc:
            logger.warning("OpenAI document embedding failed: %s", exc)
            self._primary_available = False
            return self._get_fallback().embed_documents(list(texts))

    def embed_query(self, text: str) -> list[float]:
        if not self._primary_available:
            return self._get_fallback().embed_query(text)
        try:
            return self.primary.embed_query(text)
        except Exception as exc:
            logger.warning("OpenAI query embedding failed: %s", exc)
            self._primary_available = False
            return self._get_fallback().embed_query(text)


def get_or_create_model(
    model_id: str = DEFAULT_MODEL_ID,
    device: str = "auto",
) -> EmbeddingsModel:
    """Return a cached embedding model, creating one if needed."""
    global _model_instance, _model_config

    resolved_device = detect_device() if device == "auto" else device
    key = (model_id, resolved_device, DEFAULT_DIMENSIONS)

    if _model_instance is not None and _model_config == key:
        return _model_instance

    if _is_openai_model(model_id):
        provider = get_user_runtime_settings().embedding_provider
        if provider == "local":
            return _create_local_model(LOCAL_FALLBACK_MODEL_ID, device)
        api_key = require_user_openai_api_key()
        try:
            from langchain_openai import OpenAIEmbeddings

            _model_instance = FallbackEmbeddings(
                OpenAIEmbeddings(
                    model=_openai_model_name(model_id),
                    dimensions=DEFAULT_DIMENSIONS,
                    api_key=api_key,
                ),
                primary_model_id=model_id,
                fallback_model_id=LOCAL_FALLBACK_MODEL_ID,
                device=device,
            )
            logger.info("Using OpenAI embedding model %s (%d dimensions)", model_id, DEFAULT_DIMENSIONS)
        except Exception as exc:
            logger.warning(
                "OpenAI embedding model %s could not be initialized: %s; falling back to local model %s",
                model_id,
                exc,
                LOCAL_FALLBACK_MODEL_ID,
            )
            _model_instance = _create_local_model(LOCAL_FALLBACK_MODEL_ID, device)
    else:
        _model_instance = _create_local_model(model_id, device)

    _model_config = key
    return _model_instance


def dispose_model() -> None:
    """Release the cached embedding model."""
    global _model_instance, _model_config, _detected_device
    _model_instance = None
    _model_config = None
    _detected_device = None
    logger.debug("Embedding model disposed")


@dataclass
class EmbeddingConfig:
    model_id: str = DEFAULT_MODEL_ID
    batch_size: int = DEFAULT_BATCH_SIZE
    dimensions: int = DEFAULT_DIMENSIONS
    max_snippet_length: int = DEFAULT_MAX_SNIPPET_LENGTH
    device: str = "auto"


@dataclass
class EmbeddingResult:
    total_embedded: int
    total_upserted: int


def restore_cached_embeddings(adapter, cached: list[dict]) -> int:
    """Re-insert previously cached embeddings into the CodeEmbedding table.

    Returns the number of restored rows.
    """
    if not cached:
        return 0

    import os
    import tempfile

    csv_dir = tempfile.mkdtemp(prefix="csg_embed_cache_")
    csv_path = os.path.join(csv_dir, "CodeEmbedding.csv")

    try:
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            f.write("id,nodeId,name,label,filePath,startLine,endLine,embedding\n")
            for row in cached:
                emb = row.get("embedding", [])
                vec_str = "[" + ",".join(str(v) for v in emb) + "]"

                f.write(
                    f"{_esc_csv(row.get('nodeId', ''))},{_esc_csv(row.get('nodeId', ''))},"
                    f"{_esc_csv(row.get('name', ''))},{_esc_csv(row.get('label', ''))},"
                    f"{_esc_csv(row.get('filePath', ''))},"
                    f"{row.get('startLine') or ''},"
                    f"{row.get('endLine') or ''},"
                    f'"{vec_str}"\n'
                )

        count = adapter.store_embeddings(csv_path)
    finally:
        import shutil
        shutil.rmtree(csv_dir, ignore_errors=True)

    logger.info("Restored %d cached embeddings", count)
    return count


def run_embedding_pipeline(
    graph: KnowledgeGraph,
    repo_name: str,
    adapter,
    config: EmbeddingConfig | None = None,
    on_progress: callable = None,
    skip_node_ids: set[str] | None = None,
) -> EmbeddingResult:
    """Run the full embedding pipeline: extract nodes -> embed -> upsert.

    Args:
        graph: In-memory knowledge graph with nodes to embed.
        repo_name: Repository name for the LadybugDB database.
        adapter: LadybugAdapter instance (duck-typed).
        config: Embedding configuration.
        on_progress: Optional (message, percent) callback.
        skip_node_ids: Node IDs to skip (already have cached embeddings).

    Returns:
        EmbeddingResult with counts.
    """
    cfg = config or EmbeddingConfig()

    if on_progress:
        on_progress("Loading embedding model...", 0)

    embeddings_model = get_or_create_model(cfg.model_id, cfg.device)

    resolved_device = _model_config[1] if _model_config else "cpu"
    batch_size = cfg.batch_size
    if batch_size == DEFAULT_BATCH_SIZE:
        if resolved_device == "cuda":
            batch_size = 128
        else:
            batch_size = 32
        if batch_size != cfg.batch_size:
            logger.info("Auto-tuned batch size to %d for %s", batch_size, resolved_device)

    if on_progress:
        on_progress("Collecting embeddable nodes...", 10)

    embeddable_nodes: list[EmbeddableNode] = []
    skipped = 0
    for node in graph.iter_nodes():
        if node.label not in EMBEDDABLE_LABELS:
            continue
        # Skip binary files - no useful text to embed
        if node.properties.get("binary"):
            continue
        content = node.properties.get("content", "")
        if not content and node.label != "File":
            continue
        if skip_node_ids and node.id in skip_node_ids:
            skipped += 1
            continue

        embeddable_nodes.append(EmbeddableNode(
            id=node.id,
            name=node.properties.get("name", ""),
            label=node.label,
            file_path=node.properties.get("filePath", ""),
            content=content,
            start_line=node.properties.get("startLine"),
            end_line=node.properties.get("endLine"),
        ))

    total = len(embeddable_nodes)
    if skipped:
        logger.info("Incremental: %d cached, %d new nodes to embed", skipped, total)
    if total == 0:
        logger.info("No new embeddable nodes found")
        return EmbeddingResult(total_embedded=0, total_upserted=0)

    logger.info("Embedding %d nodes with %s", total, embeddings_model.active_model_id)

    if on_progress:
        on_progress(f"Embedding {total} nodes...", 20)

    all_points: list[dict] = []

    for batch_start in range(0, total, batch_size):
        batch_end = min(batch_start + batch_size, total)
        batch = embeddable_nodes[batch_start:batch_end]

        texts = [
            generate_embedding_text(n, cfg.max_snippet_length)
            for n in batch
        ]

        vectors = embeddings_model.embed_documents(texts)

        for node, vector in zip(batch, vectors):
            all_points.append({
                "vector": vector,
                "payload": {
                    "nodeId": node.id,
                    "name": node.name,
                    "label": node.label,
                    "filePath": node.file_path,
                    "startLine": node.start_line,
                    "endLine": node.end_line,
                },
            })

        if on_progress:
            pct = 20 + int(70 * batch_end / total)
            on_progress(f"Embedded {batch_end}/{total} nodes...", pct)

    import os
    import tempfile

    if on_progress:
        on_progress("Uploading to LadybugDB...", 90)

    csv_dir = tempfile.mkdtemp(prefix="csg_embed_")
    csv_path = os.path.join(csv_dir, "CodeEmbedding.csv")

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        f.write("id,nodeId,name,label,filePath,startLine,endLine,embedding\n")
        for point in all_points:
            payload = point["payload"]
            vec_str = "[" + ",".join(str(v) for v in point["vector"]) + "]"
            f.write(
                f"{_esc_csv(payload.get('nodeId', ''))},{_esc_csv(payload.get('nodeId', ''))},"
                f"{_esc_csv(payload.get('name', ''))},{_esc_csv(payload.get('label', ''))},"
                f"{_esc_csv(payload.get('filePath', ''))},"
                f"{payload.get('startLine') or ''},"
                f"{payload.get('endLine') or ''},"
                f'"{vec_str}"\n'
            )

    upserted = adapter.store_embeddings(csv_path)

    try:
        adapter.create_vector_index()
    except Exception as exc:
        logger.debug("Vector index creation skipped (may already exist): %s", exc)

    import shutil
    shutil.rmtree(csv_dir, ignore_errors=True)

    if on_progress:
        on_progress("Embedding pipeline complete!", 100)

    logger.info("Embedded %d nodes, upserted %d points", total, upserted)
    return EmbeddingResult(total_embedded=total, total_upserted=upserted)



