"""Infrastructure embeddings adapter."""

from csg.infrastructure.embeddings.embedding_gateway import EmbeddingGateway

__all__ = ["EmbeddingGateway"]
