"""SRS mixin — gathers graph context and generates SRS documents."""

from __future__ import annotations

import json
import logging
from collections import defaultdict

from csg.application.use_cases.agent.generate_srs import generate_srs
from csg.infrastructure.runtime.user_context import MISSING_OPENAI_API_KEY_MESSAGE, require_user_openai_api_key

logger = logging.getLogger(__name__)


class SrsMixin:
    """Generate SRS documents from knowledge-graph context + LLM."""

    def generate_srs(self, extra_context: str = "") -> dict:
        """Gather graph context and generate an SRS document.

        Steps:
            1. Extract directory structure, symbols, communities, processes
               from the knowledge graph.
            2. Combine with optional extra_context from the caller.
            3. Delegate to srs_generation_tool (LLM call + DOCX conversion).

        Returns:
            dict with srs_markdown, srs_md_path, docx_path, success, message.
        """
        try:
            require_user_openai_api_key()
        except RuntimeError:
            return {
                "success": False,
                "message": MISSING_OPENAI_API_KEY_MESSAGE,
            }

        repo_path = self._adapter.repo_source_path
        if not repo_path:
            return {
                "success": False,
                "message": (
                    "No repo source path available. "
                    "The repository must have been indexed with a filesystem path."
                ),
            }

        logger.info("Gathering SRS context from knowledge graph for %s", repo_path)
        graph_context = self._gather_srs_context()

        # Auto-gather explore context via the 6-layer retrieval system
        explore_context = self._gather_explore_context()

        # Only run raw Cypher fallback when explore layers returned little
        _MIN_EXPLORE_CHARS = 500
        if len(explore_context.strip()) < _MIN_EXPLORE_CHARS:
            logger.info(
                "Explore context too short (%d chars < %d), running Cypher fallback",
                len(explore_context.strip()), _MIN_EXPLORE_CHARS,
            )
        else:
            graph_context = ""  # skip redundant Cypher queries

        # Merge: agent-supplied > explore layers > raw graph
        parts = []
        if extra_context.strip():
            parts.append(extra_context.strip())
        if explore_context.strip():
            parts.append(explore_context.strip())
        if graph_context.strip():
            parts.append(graph_context.strip())

        combined = "\n\n".join(parts) if parts else ""

        logger.info(
            "SRS context: graph=%d chars, extra=%d chars",
            len(graph_context), len(extra_context),
        )

        try:
            result_json = generate_srs(
                context=combined,
                repo_path=repo_path,
                agent_gateway=self._agent_gateway,
            )
            return json.loads(result_json)
        except json.JSONDecodeError as exc:
            logger.error("srs_generation_tool returned invalid JSON: %s", exc)
            return {"success": False, "message": "SRS generation returned malformed output."}
        except Exception as exc:
            logger.exception("SRS generation failed")
            return {"success": False, "message": str(exc)}

    # ------------------------------------------------------------------
    # Explore-layer context (6-layer retrieval)
    # ------------------------------------------------------------------

    def _gather_explore_context(self) -> str:
        """Auto-gather context from ALL 6 explore layers for SRS generation.

        Organizes output by SRS section to align with the IEEE 830 + ISO 29148
        hybrid structure used by the system prompt:

        Section 2 context: product perspective, features, user classes, environment
        Section 3 context: feature modules, execution flows, symbols, business rules
        Section 4 context: external interfaces (dependencies, protocols)
        Section 5 context: NFR evidence (config, constraints)
        Section 6 context: data model (schema classes, entities)
        """
        # Accumulators keyed by SRS section
        sec2_overview: list[str] = []     # Overall Description
        sec3_features: list[str] = []     # Functional Requirements (per module)
        sec4_interfaces: list[str] = []   # External Interfaces
        sec5_nfrs: list[str] = []         # Non-Functional evidence
        sec6_data: list[str] = []         # Data Requirements
        sec_contracts: list[str] = []     # Symbol contracts (cross-cutting)
        top_symbols: list[str] = []

        try:
            # ── L0 Topology → Section 2 (Product Features + Architecture) ──
            topo = self.topology()
            communities = topo.get("communities", [])
            if communities:
                lines = ["## SRS Section 2: Product Features (from topology)", ""]
                lines.append("Each community represents a feature module:")
                for c in communities:
                    name = c.get("label") or c.get("name") or "unnamed"
                    count = c.get("symbolCount") or 0
                    cohesion = c.get("cohesion")
                    members = c.get("topMembers", [])
                    coh_str = f", cohesion={cohesion:.2f}" if cohesion is not None else ""
                    members_str = f" — key capabilities: {', '.join(members[:5])}" if members else ""
                    lines.append(f"- **{name}** ({count} components{coh_str}){members_str}")
                sec2_overview.append("\n".join(lines))

            # ── L1 Relevance — targeted searches for SRS sections ──

            # Search for user roles / actors → Section 2.3
            try:
                rel = self.relevance("role user auth permission token login", limit=8)
                hits = []
                for rc in rel.get("communities", []):
                    for hit in rc.get("hits", []):
                        sname = hit.get("name", "")
                        desc = hit.get("description", "")
                        if sname:
                            hits.append(f"- `{sname}`: {desc}" if desc else f"- `{sname}`")
                            if sname not in top_symbols:
                                top_symbols.append(sname)
                if hits:
                    sec2_overview.append("## SRS Section 2.3: User Classes Evidence\n\n" + "\n".join(hits[:15]))
            except Exception as exc:
                logger.debug("L1 relevance (actors) failed: %s", exc)

            # Search for data models → Section 6
            try:
                rel = self.relevance("schema model entity data class type", limit=8)
                hits = []
                for rc in rel.get("communities", []):
                    for hit in rc.get("hits", []):
                        sname = hit.get("name", "")
                        desc = hit.get("description", "")
                        if sname:
                            hits.append(f"- `{sname}`: {desc}" if desc else f"- `{sname}`")
                if hits:
                    sec6_data.append("## SRS Section 6: Data Model Evidence\n\n" + "\n".join(hits[:20]))
            except Exception as exc:
                logger.debug("L1 relevance (data) failed: %s", exc)

            # Search for validation / business rules → Section 3.X.4
            try:
                rel = self.relevance("validator constraint permission guard rule check", limit=8)
                hits = []
                for rc in rel.get("communities", []):
                    for hit in rc.get("hits", []):
                        sname = hit.get("name", "")
                        desc = hit.get("description", "")
                        if sname:
                            hits.append(f"- `{sname}`: {desc}" if desc else f"- `{sname}`")
                if hits:
                    sec3_features.append("## SRS Section 3: Business Rules Evidence\n\n" + "\n".join(hits[:15]))
            except Exception as exc:
                logger.debug("L1 relevance (rules) failed: %s", exc)

            # Search for error handling → Section 8.2 (System Messages)
            try:
                rel = self.relevance("error exception message response status", limit=5)
                hits = []
                for rc in rel.get("communities", []):
                    for hit in rc.get("hits", []):
                        sname = hit.get("name", "")
                        desc = hit.get("description", "")
                        if sname:
                            hits.append(f"- `{sname}`: {desc}" if desc else f"- `{sname}`")
                if hits:
                    sec3_features.append("## SRS Section 8.2: System Messages Evidence\n\n" + "\n".join(hits[:10]))
            except Exception as exc:
                logger.debug("L1 relevance (errors) failed: %s", exc)

            # ── L2 Context — per-community → Section 3 (Feature Modules) ──
            for comm in communities[:8]:
                comm_name = comm.get("label") or comm.get("name") or ""
                if not comm_name:
                    continue
                try:
                    ctx = self.context_layer(f"community:{comm_name}", limit=5)
                    processes = ctx.get("processes", [])
                    symbols = ctx.get("symbols", [])
                    if not processes and not symbols:
                        continue

                    lines = [f"### Feature Module: {comm_name}", ""]
                    if processes:
                        lines.append("**Use Case Flows (derive main scenarios from these):**")
                        for p in processes[:5]:
                            steps = p.get("steps", [])
                            step_names = " → ".join(
                                s.get("name", "?") for s in steps
                            )
                            ptype = p.get("type") or p.get("processType") or ""
                            lines.append(f"- {p.get('name', '?')} ({ptype}): {step_names}")
                        lines.append("")

                    if symbols:
                        lines.append("**Capabilities (derive FRs from these):**")
                        for s in symbols[:10]:
                            name = s.get("name", "")
                            kind = s.get("type", "")
                            desc = s.get("description", "")
                            fan = s.get("fanIn")
                            exported = s.get("isExported")
                            entry = f"- `{name}` ({kind})"
                            if desc:
                                entry += f": {desc[:150]}"
                            if fan:
                                entry += f" [fanIn={fan}]"
                            if exported:
                                entry += " [exported]"
                            lines.append(entry)
                        for s in symbols:
                            if s.get("fanIn") and s.get("name"):
                                if s["name"] not in top_symbols:
                                    top_symbols.append(s["name"])

                    sec3_features.append("\n".join(lines))
                except Exception as exc:
                    logger.debug("L2 context failed for community '%s': %s", comm_name, exc)
                    continue

            # ── L3 Crosscut → Section 5 (Maintainability) ──────────
            try:
                xc = self.crosscut()
                cycles = xc.get("cycles", [])
                shared = xc.get("shared_symbols", [])
                if cycles or shared:
                    lines = ["## SRS Section 5.5: Maintainability Evidence", ""]
                    if cycles:
                        lines.append(f"**Circular Dependencies:** {len(cycles)} cycle(s) detected")
                        for cyc in cycles[:3]:
                            members = cyc.get("members", [])
                            lines.append(f"- {' ↔ '.join(members[:4])}")
                        lines.append("")
                    if shared:
                        lines.append("**Shared Components (high usage across modules):**")
                        for s in shared[:5]:
                            lines.append(f"- `{s.get('name', '?')}` (used by {s.get('fanIn', 0)} other components)")
                    sec5_nfrs.append("\n".join(lines))
            except Exception as exc:
                logger.debug("L3 crosscut failed: %s", exc)

            # ── L4 Contract → Section 3 + 4 (interfaces + requirements) ──
            if top_symbols:
                try:
                    contracts = self.contract(top_symbols[:8])
                    contract_syms = contracts.get("symbols", [])
                    if contract_syms:
                        lines = ["## Symbol Contracts (for FR derivation)", ""]
                        for cs in contract_syms:
                            if cs.get("error"):
                                continue
                            name = cs.get("name", "")
                            sig = cs.get("signature", "")
                            desc = cs.get("description", "")
                            callers = cs.get("callers", [])
                            callees = cs.get("callees", [])
                            lines.append(f"### `{name}`")
                            if desc:
                                lines.append(f"- Description: {desc[:200]}")
                            if sig:
                                lines.append(f"- Signature: `{sig}`")
                            if callers:
                                caller_names = [c.get("name", "?") for c in callers[:5]]
                                lines.append(f"- Called by: {', '.join(caller_names)}")
                            if callees:
                                callee_names = [c.get("name", "?") for c in callees[:5]]
                                lines.append(f"- Calls: {', '.join(callee_names)}")
                            lines.append("")
                        sec_contracts.append("\n".join(lines))
                except Exception as exc:
                    logger.debug("L4 contract failed: %s", exc)

            # ── L5 Implementation → Section 3 (use case scenario details) ──
            impl_symbols = top_symbols[:5]
            if impl_symbols:
                try:
                    impl = self.implementation(impl_symbols)
                    impl_syms = impl.get("symbols", [])
                    if impl_syms:
                        lines = ["## Key Implementation (for use case scenario derivation)", ""]
                        for isym in impl_syms:
                            if isym.get("error") or not isym.get("content"):
                                continue
                            lines.append(f"### `{isym.get('name', '?')}`")
                            lines.append("```")
                            lines.append(isym["content"][:2000])
                            lines.append("```")
                            lines.append("")
                        sec3_features.append("\n".join(lines))
                except Exception as exc:
                    logger.debug("L5 implementation failed: %s", exc)

        except Exception as exc:
            logger.warning("Explore context gathering failed: %s", exc)

        # ── Extra: Entry points (forms, handlers, main functions) ──────
        try:
            rows = self._query(
                "MATCH (s) WHERE s.entryPointScore > 0 "
                "RETURN s.name AS name, s.filePath AS filePath, "
                "s.entryPointScore AS score, s.entryPointReason AS reason "
                "ORDER BY s.entryPointScore DESC LIMIT 20"
            )
            if rows:
                lines = ["## SRS: Entry Points (forms, handlers, main)", ""]
                for r in rows:
                    reason = r.get("reason", "")
                    lines.append(
                        f"- `{r.get('name', '?')}` in {r.get('filePath', '?')} "
                        f"(score={r.get('score', 0):.1f}{', ' + reason if reason else ''})"
                    )
                sec3_features.append("\n".join(lines))
        except Exception as exc:
            logger.debug("Entry point query failed: %s", exc)

        # ── Extra: Schema entities (database tables from DDL/ORM) ──────
        try:
            schema_rows = []
            for table in self._symbol_tables():
                escaped = self._escape_table_name(table)
                try:
                    rows = self._query(
                        f"MATCH (s:{escaped}) WHERE s.schemaEntities IS NOT NULL "
                        f"RETURN s.name AS name, s.filePath AS filePath, "
                        f"s.schemaEntities AS tables"
                    )
                    schema_rows.extend(rows)
                except Exception:
                    continue

            if schema_rows:
                all_tables: set[str] = set()
                lines = ["## SRS Section 6: Database Tables (from DDL/ORM extraction)", ""]
                for r in schema_rows:
                    tables = r.get("tables", [])
                    if isinstance(tables, str):
                        tables = [tables]
                    for t in tables:
                        if t not in all_tables:
                            all_tables.add(t)
                            lines.append(f"- **{t}** (defined in `{r.get('name', '?')}` at {r.get('filePath', '?')})")
                sec6_data.append("\n".join(lines))
        except Exception as exc:
            logger.debug("Schema entity query failed: %s", exc)

        # ── Extra: Infrastructure metadata (docker-compose, .env, etc.) ──
        try:
            rows = self._query(
                "MATCH (f:File) WHERE f.infrastructure IS NOT NULL "
                "RETURN f.name AS name, f.infrastructure AS meta"
            )
            if rows:
                lines = ["## SRS: Infrastructure Metadata (Section 2.1, 2.4, 4.3)", ""]
                for r in rows:
                    try:
                        meta = json.loads(r.get("meta", "{}"))
                    except (json.JSONDecodeError, TypeError):
                        continue
                    infra_type = meta.get("type", "unknown")
                    fname = r.get("name", "?")

                    if infra_type == "docker_compose":
                        services = meta.get("services", [])
                        lines.append(f"**docker-compose** ({fname}): {len(services)} services")
                        for svc in services:
                            deps = ", ".join(svc.get("depends_on", []))
                            dep_str = f" → depends on: {deps}" if deps else ""
                            lines.append(f"- {svc['name']}: image={svc.get('image', svc.get('build', '?'))}{dep_str}")

                    elif infra_type == "dockerfile":
                        images = meta.get("base_images", [])
                        lines.append(f"**Dockerfile** ({fname}): base={', '.join(images)}")
                        if meta.get("ports"):
                            lines.append(f"  Ports: {', '.join(meta['ports'])}")
                        if meta.get("env_vars"):
                            lines.append(f"  Env vars: {', '.join(meta['env_vars'][:10])}")

                    elif infra_type == "env_file":
                        variables = meta.get("variables", [])
                        lines.append(f"**Environment** ({fname}): {len(variables)} variables")
                        for v in variables[:15]:
                            comment = f" — {v['comment']}" if v.get("comment") else ""
                            lines.append(f"- {v['name']}{comment}")

                    elif infra_type == "openapi":
                        endpoints = meta.get("endpoints", [])
                        schemas = meta.get("schemas", [])
                        lines.append(f"**OpenAPI** ({fname}): {meta.get('title', '?')} v{meta.get('version', '?')}")
                        lines.append(f"  {len(endpoints)} endpoints, {len(schemas)} schemas")
                        for ep in endpoints[:10]:
                            lines.append(f"- {ep['method']} {ep['path']}: {ep.get('summary', '')}")

                    elif infra_type == "ci_cd":
                        lines.append(f"**CI/CD** ({fname}): provider={meta.get('provider', '?')}")
                        if meta.get("jobs"):
                            lines.append(f"  Jobs: {', '.join(meta['jobs'][:8])}")

                    elif infra_type == "kubernetes":
                        resources = meta.get("resources", [])
                        lines.append(f"**Kubernetes** ({fname}): {len(resources)} resources")
                        for res in resources[:5]:
                            lines.append(f"- {res.get('kind', '?')}: {res.get('name', '?')}")

                    elif infra_type == "proto":
                        services = meta.get("services", [])
                        messages = meta.get("messages", [])
                        lines.append(f"**Protobuf** ({fname}): {len(services)} services, {len(messages)} messages")

                    elif infra_type == "migration":
                        tables = meta.get("tables", [])
                        lines.append(f"**Migration** ({fname}): {len(tables)} table operations")
                        for t in tables[:10]:
                            lines.append(f"- {t['operation']} {t['table']}")

                    lines.append("")

                if len(lines) > 2:
                    sec2_overview.append("\n".join(lines))
        except Exception as exc:
            logger.debug("Infrastructure metadata query failed: %s", exc)

        # Assemble in SRS section order
        all_sections = (
            sec2_overview
            + sec3_features
            + sec4_interfaces
            + sec5_nfrs
            + sec6_data
            + sec_contracts
        )
        return "\n\n".join(all_sections)

    def _symbol_tables(self) -> list[str]:
        tables = self._search_tables or ()
        return [t for t in tables if t not in ("File", "Section")]

    # ------------------------------------------------------------------
    # Raw Cypher context gathering (fallback)
    # ------------------------------------------------------------------

    def _gather_srs_context(self) -> str:
        """Pull directory structure, symbols, communities, and processes."""
        sections: list[str] = []

        dir_section = self._srs_directory_structure()
        if dir_section:
            sections.append(dir_section)

        comm_section = self._srs_communities()
        if comm_section:
            sections.append(comm_section)

        sym_section = self._srs_key_symbols()
        if sym_section:
            sections.append(sym_section)

        proc_section = self._srs_processes()
        if proc_section:
            sections.append(proc_section)

        return "\n\n".join(sections)

    def _srs_directory_structure(self) -> str:
        """Query Folder→File relationships for the project tree."""
        try:
            rows = self._query(
                "MATCH (f:Folder)-[r:CodeRelation]->(child:File) "
                "WHERE r.type = 'CONTAINS' "
                "RETURN f.filePath AS folder, child.filePath AS file "
                "ORDER BY f.filePath, child.filePath"
            )
        except Exception:
            logger.debug("Failed to query directory structure", exc_info=True)
            return ""

        if not rows:
            return ""

        tree: dict[str, list[str]] = defaultdict(list)
        for row in rows:
            tree[row["folder"]].append(row["file"])

        lines = ["## Project Directory Structure", ""]
        for folder in sorted(tree):
            lines.append(f"### {folder}/")
            for fpath in tree[folder]:
                lines.append(f"  - {fpath}")
        return "\n".join(lines)

    def _srs_communities(self) -> str:
        """Query community nodes for architecture overview."""
        try:
            rows = self._query(
                "MATCH (c:Community) "
                "RETURN c.heuristicLabel AS name, c.symbolCount AS symbolCount, "
                "c.cohesion AS cohesion "
                "ORDER BY c.symbolCount DESC"
            )
        except Exception:
            logger.debug("Failed to query communities", exc_info=True)
            return ""

        if not rows:
            return ""

        lines = ["## Architecture Modules (Communities)", ""]
        for c in rows:
            name = c.get("name") or "unnamed"
            count = c.get("symbolCount") or 0
            cohesion = c.get("cohesion")
            coh_str = f", cohesion={cohesion:.2f}" if cohesion is not None else ""
            lines.append(f"- **{name}** ({count} symbols{coh_str})")
        return "\n".join(lines)

    def _srs_key_symbols(self) -> str:
        """Query key symbol definitions across all symbol tables."""
        all_symbols: list[dict] = []

        for table in self._symbol_tables():
            if len(all_symbols) >= 300:
                break
            escaped = self._escape_table_name(table)
            try:
                rows = self._query(
                    f"MATCH (s:{escaped}) "
                    "RETURN s.name AS name, s.filePath AS filePath, "
                    "s.signature AS signature, s.description AS description, "
                    "s.isExported AS isExported, s.returnType AS returnType, "
                    "s.parameterCount AS parameterCount "
                    "ORDER BY s.filePath, s.name",
                )
                for row in rows:
                    row["kind"] = table
                all_symbols.extend(rows)
            except Exception:
                continue

        if not all_symbols:
            return ""

        # Group by file
        by_file: dict[str, list[dict]] = defaultdict(list)
        for sym in all_symbols:
            fpath = sym.get("filePath") or "unknown"
            by_file[fpath].append(sym)

        lines = ["## Key Source Definitions", ""]
        for fpath in sorted(by_file):
            lines.append(f"### {fpath}")
            for sym in by_file[fpath]:
                kind = sym.get("kind", "")
                name = sym.get("name", "")
                sig = sym.get("signature") or ""
                desc = sym.get("description") or ""
                exported = sym.get("isExported")
                ret = sym.get("returnType") or ""

                header = f"- **{kind}** `{name}`"
                if exported:
                    header += " (exported)"
                if sig:
                    header += f"\n  - Signature: `{sig}`"
                if ret:
                    header += f"\n  - Returns: `{ret}`"
                if desc:
                    # Truncate long descriptions
                    short = desc[:200] + "..." if len(desc) > 200 else desc
                    header += f"\n  - {short}"
                lines.append(header)
            lines.append("")
        return "\n".join(lines)

    def _srs_processes(self) -> str:
        """Query execution flow / process nodes."""
        try:
            rows = self._query(
                "MATCH (p:Process) "
                "RETURN p.name AS name, p.heuristicLabel AS label, "
                "p.processType AS processType, p.stepCount AS stepCount "
                "ORDER BY p.name"
            )
        except Exception:
            logger.debug("Failed to query processes", exc_info=True)
            return ""

        if not rows:
            return ""

        lines = ["## Execution Flows (Processes)", ""]
        for p in rows:
            name = p.get("name") or p.get("label") or "unnamed"
            label = p.get("label") or ""
            ptype = p.get("processType") or ""
            steps = p.get("stepCount") or 0

            entry = f"- **{name}**"
            if label and label != name:
                entry += f" — {label}"
            meta_parts = []
            if ptype:
                meta_parts.append(f"type={ptype}")
            if steps is not None and steps > 0:
                meta_parts.append(f"{steps} steps")
            if meta_parts:
                entry += f" ({', '.join(meta_parts)})"
            lines.append(entry)
        return "\n".join(lines)
