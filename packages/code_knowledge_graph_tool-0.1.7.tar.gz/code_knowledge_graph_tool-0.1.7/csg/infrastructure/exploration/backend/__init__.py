"""Canonical inbound MCP backend implementation."""

from __future__ import annotations

import logging
import os
import threading
from contextlib import contextmanager
from typing import Any

from .context import ContextMixin
from .explore import ExploreMixin
from .impact import ImpactMixin
from .mutations import MutationsMixin
from .search import SearchMixin
from .srs import SrsMixin

logger = logging.getLogger(__name__)


class BackendBase:
    """Core adapter management, scoped-repo switching, and Cypher access."""

    def __init__(
        self,
        adapter: Any,
        *,
        graph_pool=None,
        repository_registry=None,
        search_full_text=None,
        search_full_text_symbols=None,
        merge_rrf=None,
        semantic_search_result_class=None,
        escape_table_name=None,
        search_tables=None,
        is_binary_source_path=None,
        run_pipeline_sync=None,
        agent_gateway=None,
        adapter_factory=None,
    ) -> None:
        self._default_adapter = adapter
        self._adapter_cache: dict[str, Any] = {}
        self._repo_lock = threading.Lock()
        self._local = threading.local()
        self._graph_pool = graph_pool
        self._repository_registry = repository_registry
        self._search_full_text = search_full_text
        self._search_full_text_symbols = search_full_text_symbols
        self._merge_rrf = merge_rrf
        self._semantic_search_result_class = semantic_search_result_class
        self._escape_table_name = escape_table_name
        self._search_tables = search_tables or ()
        self._is_binary_source_path = is_binary_source_path
        self._run_pipeline_sync = run_pipeline_sync
        self._agent_gateway = agent_gateway
        self._adapter_factory = adapter_factory

        try:
            if self._graph_pool is not None:
                self._graph_pool.event_bus.subscribe("repo_changed", self._on_repo_changed)
                self._graph_pool.event_bus.subscribe("repo_deleted", self._on_repo_deleted)
        except Exception:
            logger.debug("Could not subscribe to KuzuPool events", exc_info=True)

    @property
    def _adapter(self) -> Any:
        return getattr(self._local, "adapter", None) or self._default_adapter

    @contextmanager
    def _scoped_repo(self, repo: str | None):
        if not repo:
            yield
            return

        if self._repository_registry is None:
            raise RuntimeError("Exploration backend requires injected repository registry")
        entry = self._repository_registry.get_repo_entry_by_name(repo)
        if not entry:
            raise ValueError(
                f"Repository '{repo}' not found. "
                "Use csg_list_repos to see available repos."
            )

        db_path = os.path.join(entry.storage_path, "lbug")

        with self._repo_lock:
            if repo not in self._adapter_cache:
                if self._adapter_factory is None:
                    raise RuntimeError("Exploration backend requires an injected adapter factory for scoped repos")
                new_adapter = self._adapter_factory(db_path=db_path, repo_source_path=entry.path)
                new_adapter.connect(read_only=True)
                self._adapter_cache[repo] = new_adapter
                logger.info("Opened adapter for repo '%s' at %s", repo, db_path)

            scoped_adapter = self._adapter_cache[repo]

        prev = getattr(self._local, "adapter", None)
        self._local.adapter = scoped_adapter
        try:
            yield
        finally:
            self._local.adapter = prev

    def _on_repo_changed(self, data: dict) -> None:
        changed_path = data.get("db_path", "")
        with self._repo_lock:
            for name, adapter in list(self._adapter_cache.items()):
                if adapter._db_path and os.path.abspath(adapter._db_path) == changed_path:
                    adapter.close()
                    adapter._name_cache.clear()
                    del self._adapter_cache[name]
                    logger.info("Cache invalidated for repo '%s' (data changed)", name)

    def _on_repo_deleted(self, data: dict) -> None:
        deleted_path = data.get("db_path", "")
        with self._repo_lock:
            for name, adapter in list(self._adapter_cache.items()):
                if adapter._db_path and os.path.abspath(adapter._db_path) == deleted_path:
                    adapter.close()
                    del self._adapter_cache[name]
                    logger.info("Cache removed for deleted repo '%s'", name)

    def _query(self, cypher: str, params: dict | None = None) -> list[dict]:
        return self._adapter.execute_query(cypher, params)

    @staticmethod
    def _confidence_envelope(score: float, gap: float = 1.0) -> dict:
        if score > 0.8 and gap > 0.3:
            signal, recommendation = "strong", "drill_down"
        elif score > 0.4:
            signal, recommendation = "moderate", "drill_down"
        else:
            signal, recommendation = "weak", "explore_multiple"
        return {
            "confidence": round(score, 3),
            "confidence_gap": round(gap, 3),
            "signal": signal,
            "recommendation": recommendation,
        }


class Backend(
    ExploreMixin,
    ContextMixin,
    ImpactMixin,
    SearchMixin,
    MutationsMixin,
    SrsMixin,
    BackendBase,
):
    """Inbound MCP backend with tool implementations."""

    pass


__all__ = [
    "Backend",
    "BackendBase",
    "ExploreMixin",
    "ContextMixin",
    "ImpactMixin",
    "MutationsMixin",
    "SearchMixin",
    "SrsMixin",
]
