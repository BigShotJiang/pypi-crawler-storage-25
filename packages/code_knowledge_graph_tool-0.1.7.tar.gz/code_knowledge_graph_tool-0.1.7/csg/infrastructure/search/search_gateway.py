"""Canonical outbound gateway for search capabilities."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from csg.application.ports.search_gateway_port import SearchGatewayPort

class SearchGateway(SearchGatewayPort):
    """Minimal search gateway contract for canonical outbound wiring."""

    def search(self, query: str, *, limit: int = 10) -> Sequence[Mapping[str, Any]]:
        """Run a search query and return ranked results."""
        raise NotImplementedError("SearchGateway.search is not implemented yet")
