﻿"""Canonical outbound wrappers for search functions.

These wrappers keep inbound adapters decoupled from direct legacy search
imports while preserving existing runtime behavior.
"""

from __future__ import annotations

from csg.infrastructure.search.search_gateway import SearchGateway


def search_full_text(*args, **kwargs):
    """Delegate to BM25 full-text search."""
    from csg.infrastructure.search.internal.bm25_runtime import search_fts

    return search_fts(*args, **kwargs)


def search_full_text_symbols(*args, **kwargs):
    """Delegate to BM25 symbol-focused full-text search."""
    from csg.infrastructure.search.internal.bm25_runtime import search_fts_symbols

    return search_fts_symbols(*args, **kwargs)


def merge_rrf(*args, **kwargs):
    """Delegate to reciprocal-rank-fusion merge."""
    from csg.infrastructure.search.internal.hybrid_runtime import merge_with_rrf

    return merge_with_rrf(*args, **kwargs)


def get_semantic_search_result_class():
    """Return the semantic search result class used by hybrid search."""
    from csg.infrastructure.search.internal.hybrid_runtime import SemanticSearchResult

    return SemanticSearchResult


__all__ = [
    "SearchGateway",
    "search_full_text",
    "search_full_text_symbols",
    "merge_rrf",
    "get_semantic_search_result_class",
]

