"""Search runtime internals owned by outbound adapters."""

