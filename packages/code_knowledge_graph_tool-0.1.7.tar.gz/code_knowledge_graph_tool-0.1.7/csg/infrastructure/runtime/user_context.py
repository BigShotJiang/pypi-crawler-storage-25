"""Request-scoped user runtime configuration for provider-backed features."""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar, copy_context
from dataclasses import dataclass
from typing import Callable, Iterator


@dataclass(frozen=True)
class UserRuntimeSettings:
    """Effective per-user runtime settings used by backend behavior."""

    default_branch: str = "main"
    max_file_size_kb: int = 100 * 1024
    embeddings_enabled: bool = True
    embedding_provider: str = "openai"
    ocr_provider: str = "openai"
    llm_provider: str = "openai"


@dataclass(frozen=True)
class UserRuntimeSecrets:
    """Request-scoped provider secrets."""

    openai_api_key: str = ""


MISSING_OPENAI_API_KEY_MESSAGE = (
    "Important: OpenAI features use only the API key saved in your user Settings. "
    "Add your own OpenAI API key in Settings before using embeddings, OCR, chat, or SRS."
)


_SETTINGS: ContextVar[UserRuntimeSettings | None] = ContextVar("csg_user_runtime_settings", default=None)
_SECRETS: ContextVar[UserRuntimeSecrets | None] = ContextVar("csg_user_runtime_secrets", default=None)


def get_user_runtime_settings() -> UserRuntimeSettings:
    """Return the effective request-scoped settings, or defaults when absent."""
    return _SETTINGS.get() or UserRuntimeSettings()


def get_user_runtime_secrets() -> UserRuntimeSecrets:
    """Return the effective request-scoped secrets, or empty defaults when absent."""
    return _SECRETS.get() or UserRuntimeSecrets()


def require_user_openai_api_key() -> str:
    """Return the user's request-scoped OpenAI key or raise a clear reminder."""
    api_key = get_user_runtime_secrets().openai_api_key.strip()
    if not api_key:
        raise RuntimeError(MISSING_OPENAI_API_KEY_MESSAGE)
    return api_key


def bind_current_context(fn: Callable[..., object], /, *args, **kwargs) -> Callable[[], object]:
    """Capture the current context now and return a zero-arg runner for later threads."""
    context = copy_context()
    return lambda: context.run(fn, *args, **kwargs)


@contextmanager
def bind_user_runtime(
    settings: UserRuntimeSettings,
    secrets: UserRuntimeSecrets,
) -> Iterator[None]:
    """Bind request-scoped runtime values for downstream provider calls."""
    settings_token = _SETTINGS.set(settings)
    secrets_token = _SECRETS.set(secrets)
    try:
        yield
    finally:
        _SETTINGS.reset(settings_token)
        _SECRETS.reset(secrets_token)
