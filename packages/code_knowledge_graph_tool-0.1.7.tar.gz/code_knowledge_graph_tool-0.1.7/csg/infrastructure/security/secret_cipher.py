"""Symmetric encryption helper for user provider secrets."""

from __future__ import annotations

import base64
import hashlib
import os

from cryptography.fernet import Fernet, InvalidToken


class SecretCipher:
    """Encrypt and decrypt short provider secrets with a server-scoped key."""

    def __init__(self, secret: str | None = None) -> None:
        raw_secret = (secret or os.environ.get("CSG_SECRET_KEY") or "csg-dev-secret-key").encode("utf-8")
        key = base64.urlsafe_b64encode(hashlib.sha256(raw_secret).digest())
        self._fernet = Fernet(key)

    def encrypt(self, value: str) -> str:
        """Encrypt plaintext into a transport-safe token."""
        return self._fernet.encrypt(value.encode("utf-8")).decode("utf-8")

    def decrypt(self, value: str) -> str:
        """Decrypt a stored token into plaintext."""
        try:
            return self._fernet.decrypt(value.encode("utf-8")).decode("utf-8")
        except InvalidToken as exc:
            raise ValueError("Stored secret is invalid or cannot be decrypted") from exc
