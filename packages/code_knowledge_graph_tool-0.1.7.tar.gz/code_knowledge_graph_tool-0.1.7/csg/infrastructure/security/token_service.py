"""Opaque access/refresh token helpers."""

from __future__ import annotations

import hashlib
import secrets


class TokenService:
    """Generate opaque tokens and stable hashes for persistence."""

    def issue_token(self) -> str:
        return secrets.token_urlsafe(32)

    def hash_token(self, token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()
