"""Canonical outbound gateway for agent capabilities."""

from __future__ import annotations

from typing import Any, AsyncIterator, Mapping

from csg.application.ports.agent_gateway_port import AgentGatewayPort


class AgentGateway(AgentGatewayPort):
    """Agent gateway over outbound internal runner implementation."""

    async def run(self, request: Mapping[str, Any]) -> Mapping[str, Any]:
        """Execute agent workflow for a canonical request payload."""
        from csg.infrastructure.agent.internal.runner import run_agent

        return await run_agent(
            conversation_id=str(request.get("conversation_id", "")),
            user_message=str(request.get("user_message", "")),
            selected_node=request.get("selected_node"),
            repo_id=request.get("repo_id"),
        )

    async def stream(self, payload: Mapping[str, Any]) -> AsyncIterator[Mapping[str, Any]]:
        """Execute agent workflow as a stream."""
        from csg.infrastructure.agent.internal.runner import stream_agent

        async for item in stream_agent(
            conversation_id=str(payload.get("conversation_id", "")),
            user_message=str(payload.get("user_message", "")),
            selected_node=payload.get("selected_node"),
            repo_id=payload.get("repo_id"),
        ):
            yield item

    def generate_srs(self, *, context: str, repo_path: str) -> str:
        """Generate SRS document payload."""
        from csg.infrastructure.agent.internal.srs.generator_runtime import srs_generation_tool

        return srs_generation_tool(context=context, repo_path=repo_path)
