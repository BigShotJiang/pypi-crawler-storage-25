﻿"""Outbound agent adapters."""

from __future__ import annotations

from typing import Any


def run_agent_workflow(*args: Any, **kwargs: Any):
    """Run the agent workflow via canonical outbound wrapper."""
    from csg.infrastructure.agent.internal.runner import run_agent

    return run_agent(*args, **kwargs)


def generate_srs_document(*args: Any, **kwargs: Any):
    """Generate SRS via canonical outbound wrapper."""
    from csg.infrastructure.agent.internal.srs.generator_runtime import srs_generation_tool

    return srs_generation_tool(*args, **kwargs)


__all__ = ["run_agent_workflow", "generate_srs_document"]

