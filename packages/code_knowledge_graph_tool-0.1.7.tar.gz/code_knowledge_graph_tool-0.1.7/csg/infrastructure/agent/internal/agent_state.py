from langchain_core.messages import AnyMessage
from langgraph.graph import add_messages
from pydantic import BaseModel
from typing import Annotated, TypedDict, Optional, Type, List


class InputState(TypedDict):
    """Represents the input state for the agent.

    This class defines the structure of the input state, which includes
    the messages exchanged between the user and the agent. It serves as
    a restricted version of the full State, providing a narrower interface
    to the outside world compared to what is maintained internally.
    """

    messages: Annotated[list[AnyMessage], add_messages]


class AgenticState(InputState):
    """Default state of the retrieval graph / agent.

    Attributes:
        conversation_id:  The unique identifier for the conversation.
        instruction:      Natural-language instruction produced by the planner
                          and consumed by the main agent (internal use only).
        actions:          List of tool/skill names chosen by the planner for
                          this turn. Used to filter which descriptions are
                          passed to the main agent (internal use only).
    """

    conversation_id: str
    instruction: str
    actions: List[str]
    force_srs_mode: bool


def create_state_with_context(additional_context_model: Optional[Type[BaseModel]] = None):
    """Create a custom AgenticState with additional context fields from a Pydantic model.
    
    Args:
        additional_context_model: A Pydantic BaseModel class defining additional
            context fields.
        
    Example:
        from pydantic import BaseModel
        
        class AdditionalContext(BaseModel):
            time_zone: str
            data_info: str
            max_results: int = 10
        
        CustomState = create_state_with_context(AdditionalContext)
        
        # CustomState now has:
        #   messages, conversation_id, instruction, actions,
        #   time_zone, data_info, max_results
    
    Returns:
        A new state class extending AgenticState with additional fields.
    
    Note:
        Additional context fields use a custom reducer that preserves existing
        values when nodes don't explicitly update them. This ensures context
        fields persist across node executions.
    """
    if additional_context_model is None:
        return AgenticState

    def context_field_reducer(left, right):
        """Preserve context across graph nodes that don't explicitly update it.

        LangGraph nodes only return fields they modify. Without this reducer,
        context fields injected at the start (e.g. repo_path, time_zone) would
        be overwritten with None on every node transition.
        """
        return right if right is not None and right != "" else left
    
    base_annotations = AgenticState.__annotations__.copy()
    
    if hasattr(additional_context_model, "model_fields"):
        for field_name, field_info in additional_context_model.model_fields.items():
            field_type = field_info.annotation
            base_annotations[field_name] = Annotated[
                Optional[field_type], context_field_reducer
            ]

    CustomAgenticState = TypedDict("CustomAgenticState", base_annotations)
    
    return CustomAgenticState
