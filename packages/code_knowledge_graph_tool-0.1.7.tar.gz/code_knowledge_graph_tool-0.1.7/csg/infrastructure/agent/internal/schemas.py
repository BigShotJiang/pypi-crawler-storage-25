
from pydantic import BaseModel, Field


class CKGAgentContext(BaseModel):
    """Additional context fields for the CKG agent, auto-injected into state."""
    selected_node_context: str = Field("", description="JSON string of the selected node in the graph UI")
    repo_path: str = Field("", description="Absolute path to the analyzed repository")


class ExploreRequest(BaseModel):
    """Schema for explore_tool (6-layer knowledge graph retrieval)."""
    query: str = Field("", description="Natural language question, or comma-separated symbol names for contract/implementation layers")
    scope: str = Field("", description="Optional scope: 'community:<name>', 'file:<path>', or 'symbol:<name>'. Required for context layer.")
    layer: str = Field("", description="Run a specific layer: topology, relevance, context, crosscut, contract, implementation. Empty = auto mode.")
    repo_path: str = Field("", description="Repository path (auto-injected)")


class NodeDetailRequest(BaseModel):
    """Schema for node_detail_tool."""
    selected_node_context: str = Field("", description="JSON of the selected node (auto-injected from UI)")
    repo_path: str = Field("", description="Repository path (auto-injected)")


class ImpactAnalysisRequest(BaseModel):
    """Schema for impact_analysis_tool."""
    target: str = Field(..., description="Symbol name to analyze blast radius for")
    direction: str = Field("upstream", description="'upstream' (who calls me) or 'downstream' (what I call)")
    repo_path: str = Field("", description="Repository path (auto-injected)")





class ChangeDetectionRequest(BaseModel):
    """Schema for change_detection_tool."""
    scope: str = Field("all", description="'staged', 'unstaged', 'all', or 'compare'")
    base_ref: str = Field("", description="Git ref for compare mode (e.g. 'main')")
    repo_path: str = Field("", description="Repository path (auto-injected)")


class GraphRenameRequest(BaseModel):
    """Schema for graph_rename_tool (always dry-run in web agent)."""
    symbol_name: str = Field(..., description="Current symbol name to rename")
    new_name: str = Field(..., description="New name for the symbol")
    repo_path: str = Field("", description="Repository path (auto-injected)")




class SRSGenerationRequest(BaseModel):
    """Schema for srs_generation_tool (SRS document generator)."""
    context: str = Field("", description="Gathered codebase context to generate SRS from")
    repo_path: str = Field("", description="Repository path (auto-injected)")
