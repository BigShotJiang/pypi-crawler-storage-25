import datetime
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, Callable, Type, Tuple
from typing_extensions import AsyncGenerator

from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langchain_core.language_models import BaseChatModel
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph.state import CompiledStateGraph
from pydantic import BaseModel

from .workflow import build_graph
from .utils.tokens import tiktoken_counter
from .utils.messages import format_message, extract_content_from_response, ChunkMessage
from .utils.logger import logger
from .utils.mcp_tools import fetch_mcp_tools,extract_mcp_tool_names
@dataclass
class ProcessedResult:
    """Container for processed conversation results."""
    final_response: str
    all_tool_calls: List[dict]
    all_messages: List[dict]
    prompt_token: int
    completion_token: int
    execution_time: int


def format_tool_args_to_markdown(tool_args: dict) -> str:
    """Convert tool arguments dictionary to a readable markdown format."""
    if not tool_args or not isinstance(tool_args, dict):
        return str(tool_args)
    
    formatted_lines = []
    for key, value in tool_args.items():
        readable_key = key.replace('_', ' ').title()
        formatted_lines.append(f"• **{readable_key}**: {value}\n")
    
    return ''.join(formatted_lines)


def _has_pending_interrupt(snapshot) -> bool:
    """Check if snapshot has a pending interrupt."""
    if not snapshot:
        return False
    
    if isinstance(snapshot, dict):
        next_nodes = snapshot.get("next")
    else:
        next_nodes = getattr(snapshot, "next", None)
        
    if next_nodes is None:
        return False
    if isinstance(next_nodes, (list, tuple)):
        return len(next_nodes) > 0
    return True


def _extract_tool_call_info(tool_call):
    """Extract tool call information from either a dict or ToolCall object."""
    if callable(tool_call) and not isinstance(tool_call, dict):
        return None
    
    if isinstance(tool_call, dict):
        return {
            "id": tool_call.get("id"),
            "name": tool_call.get("name"),
            "args": tool_call.get("args", {}),
            "type": tool_call.get("type", "function")
        }
    
    try:
        return {
            "id": getattr(tool_call, "id", None),
            "name": getattr(tool_call, "name", None),
            "args": getattr(tool_call, "args", {}),
            "type": getattr(tool_call, "type", "function")
        }
    except (AttributeError, TypeError):
        if hasattr(tool_call, "__dict__"):
            return {
                "id": tool_call.__dict__.get("id"),
                "name": tool_call.__dict__.get("name"),
                "args": tool_call.__dict__.get("args", {}),
                "type": tool_call.__dict__.get("type", "function")
            }
        return None


def _has_checkpointer(graph: CompiledStateGraph) -> bool:
    """Check if the graph has a checkpointer configured."""
    return getattr(graph, 'checkpointer', None) is not None


async def _safe_aget_state(graph: CompiledStateGraph, config: dict):
    """Safely get state, returning None if no checkpointer is set."""
    if not _has_checkpointer(graph):
        return None
    return await graph.aget_state(config)


def _get_chat_history(snapshot) -> List:
    """Extract chat history from snapshot.
    
    Handles StateSnapshot object with .values attribute.
    """
    if not snapshot:
        return []
    
    if hasattr(snapshot, 'values'):
        snapshot_values = snapshot.values
        if callable(snapshot_values):
            snapshot_values = snapshot_values()
        
        if isinstance(snapshot_values, dict):
            messages = snapshot_values.get("messages", [])
            return messages
    
    if isinstance(snapshot, dict):
        messages = snapshot.get("messages", [])
        return messages
    
    return []


def _extract_final_response(all_messages: List[dict]) -> str:
    """Extract the final AI response from processed messages."""
    # First: look for a proper AI text response
    for msg_data in reversed(all_messages):
        content = msg_data["content"]
        message = msg_data["message"]
        message_type = type(message).__name__

        if (message_type == "AIMessage" and
            content and
            content.strip() and
            not content.startswith("content=''") and
            not content.startswith("The assistant is now")):
            return content

    # Second: look for the last informative ToolMessage (degraded response)
    for msg_data in reversed(all_messages):
        message = msg_data["message"]
        message_type = type(message).__name__
        if message_type == "ToolMessage" and hasattr(message, "content"):
            tool_content = message.content
            if (tool_content and
                tool_content.strip() and
                not tool_content.startswith("Error executing tool")):
                return tool_content

    # Third: any non-empty content (existing fallback)
    for msg_data in reversed(all_messages):
        content = msg_data["content"]
        if content and content.strip():
            return content

    return ""


async def _handle_pending_tool_call(
    graph: CompiledStateGraph,
    config: dict,
    user_message: str,
    last_toolcall_message,
    initial_prompt_token: int,
    start_time: datetime.datetime,
    new_user_message_tokens: int
) -> ProcessedResult:
    """Handle execution of a pending tool call using ASYNC methods."""
    confirmation_inputs = {"y", "yes", "ok", "confirm"}
    
    if user_message.strip().lower() in confirmation_inputs:
        result = await graph.ainvoke(None, config)
    else:
        tool_call_id = last_toolcall_message.tool_calls[0]["id"]
        result = await graph.ainvoke(
            {
                "messages": [
                    ToolMessage(
                        tool_call_id=tool_call_id,
                        content=f"User wants to modify the request or STOP the process. Reason: '{user_message}'. Continue assisting, accounting for the user's input",
                    )
                ]
            },
            config,
        )
    
    processed_set = set()
    all_messages = []
    all_tool_calls = []
    
    for msg in result.get("messages", []):
        msg_content = format_message(msg)
        msg_hash = hash(msg_content)
        if msg_hash not in processed_set:
            processed_set.add(msg_hash)
            all_messages.append({
                "content": msg_content,
                "message": msg
            })
            
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                for tool_call in msg.tool_calls:
                    tool_info = _extract_tool_call_info(tool_call)
                    if tool_info:
                        all_tool_calls.append(tool_info)
    
    final_response = _extract_final_response(all_messages)
    completion_token = tiktoken_counter([AIMessage(content=final_response)])
    
    snapshot = await _safe_aget_state(graph, config)
    if isinstance(snapshot, tuple):
        snapshot = snapshot[0]
    
    chat_history = _get_chat_history(snapshot)
    total_prompt_token = tiktoken_counter(chat_history) if chat_history else 0
    
    prompt_token = (total_prompt_token - initial_prompt_token)
    
    if prompt_token == 0 and new_user_message_tokens > 0:
        prompt_token = new_user_message_tokens
    
    execution_time = int((datetime.datetime.now(datetime.timezone.utc) - start_time).total_seconds())
    
    return ProcessedResult(
        final_response=final_response,
        all_tool_calls=all_tool_calls,
        all_messages=all_messages,
        prompt_token=prompt_token,
        completion_token=completion_token,
        execution_time=execution_time
    )


async def _process_new_message(
    graph: CompiledStateGraph,
    initial_state: dict,
    config: dict,
    stream_mode: str = "values"
) -> Tuple[List[dict], List[dict]]:
    """Process a new message through the graph using ASYNC methods."""
    
    processed_set = set()
    all_messages = []
    all_tool_calls = []
    
    events = graph.astream(initial_state, config=config, stream_mode=stream_mode)
    
    async for event in events:
        if stream_mode == "values":
            messages = event.get("messages", [])
        else:
            messages = []
            for node_output in event.values():
                if isinstance(node_output, dict) and "messages" in node_output:
                    messages.extend(node_output["messages"])
        
        for msg in messages:
            msg_content = format_message(msg)
            msg_hash = hash(msg_content)
            
            if msg_hash not in processed_set:
                processed_set.add(msg_hash)
                all_messages.append({
                    "content": msg_content,
                    "message": msg
                })
                
                if hasattr(msg, "tool_calls") and msg.tool_calls:
                    tool_calls_list = msg.tool_calls
                    if callable(tool_calls_list):
                        tool_calls_list = tool_calls_list()
                    
                    if tool_calls_list:
                        for tool_call in tool_calls_list:
                            tool_info = _extract_tool_call_info(tool_call)
                            if tool_info:
                                all_tool_calls.append(tool_info)
    
    return all_messages, all_tool_calls


def _create_confirmation_message(tool_args: dict) -> str:
    """Create a confirmation message for tool execution."""
    args_to_display = {k: v for k, v in tool_args.items() if k not in ["user_id", "conversation_id"]}
    formatted_args = format_tool_args_to_markdown(args_to_display)
    
    return (
        f"**Please confirm your request:**\n\n"
        f"{formatted_args}\n\n"
        f"Press **'y'** to confirm\n"
        f"Press **'n'** to reject"
    )


async def _check_for_confirmation_needed(
    snapshot,
    start_time: datetime.datetime
) -> Optional[dict]:
    """Check if tool confirmation is needed and return confirmation data if so."""
    if not _has_pending_interrupt(snapshot):
        return None
    
    messages = _get_chat_history(snapshot)
    if not messages:
        return None
    
    last_toolcall_message = None
    for msg in reversed(messages):
        if hasattr(msg, "tool_calls") and msg.tool_calls:
            last_toolcall_message = msg
            break
    
    if not last_toolcall_message:
        return None
    
    tool_name = last_toolcall_message.tool_calls[0]["name"]
    logger.info(f"[HITL] Confirmation needed for tool: {tool_name}")
    
    tool_args = last_toolcall_message.tool_calls[0]["args"]
    confirmation_message = _create_confirmation_message(tool_args)
    execution_time = int((datetime.datetime.now(datetime.timezone.utc) - start_time).total_seconds())
    
    return {
        "response": confirmation_message,
        "needs_confirmation": True,
        "tool_call": {
            "name": last_toolcall_message.tool_calls[0]["name"],
            "args": tool_args,
            "id": last_toolcall_message.tool_calls[0]["id"]
        },
        "prompt_token": 0,
        "completion_token": 0,
        "execution_time": execution_time,
        "tool_calls": []
    }


class ReActAgent:
    """A ReAct agent with invoke and stream methods."""
    
    def __init__(self, graph: CompiledStateGraph, mcp_tool_names: Optional[List[str]] = None):
        self.graph = graph
        self.mcp_tool_names = mcp_tool_names or []
    
    async def invoke(
        self,
        conversation_id: str,
        user_message: str,
        **context_values
    ) -> dict:
        """Process user message and return complete AI response at once."""
        return await _invoke_impl(
            self.graph,
            conversation_id,
            user_message,
            context_values
        )
    
    async def stream(
        self,
        conversation_id: str,
        user_message: str,
        **context_values
    ) -> AsyncGenerator[str, None]:
        """Process user message and stream AI response in real-time."""
        async for chunk in _streaming_impl(
            self.graph,
            conversation_id,
            user_message,
            context_values
        ):
            yield chunk


async def _invoke_impl(
    graph: CompiledStateGraph,
    conversation_id: str,
    user_message: str,
    context_values: Dict[str, Any]
) -> dict:
    """Internal implementation of invoke."""
    try:
        start_time = datetime.datetime.now(datetime.timezone.utc)
        
        graph_config = getattr(graph, '_config', {})
        config = {
            "configurable": {
                "thread_id": conversation_id,
                **graph_config,
                **context_values  
            }
        }
        
        snapshot = await _safe_aget_state(graph, config)

        initial_chat_history = _get_chat_history(snapshot)
        initial_prompt_token = tiktoken_counter(initial_chat_history) if initial_chat_history else 0

        new_user_message_tokens = tiktoken_counter([HumanMessage(content=user_message)])


        if _has_pending_interrupt(snapshot):
            messages = _get_chat_history(snapshot)
            if messages:
                last_toolcall_message = None
                for msg in reversed(messages):
                    if hasattr(msg, "tool_calls") and msg.tool_calls:
                        last_toolcall_message = msg
                        break
                
                if last_toolcall_message:
                    tool_name = last_toolcall_message.tool_calls[0]['name']
                    logger.info(f"[HITL] Resuming interrupted tool call: {tool_name}")
                    result = await _handle_pending_tool_call(
                        graph, config, user_message, last_toolcall_message,
                        initial_prompt_token, start_time, new_user_message_tokens
                    )
                    
                    response_content = extract_content_from_response(result.final_response)
                    return {
                        "response": response_content,
                        "prompt_token": result.prompt_token,
                        "completion_token": result.completion_token,
                        "execution_time": result.execution_time,
                        "tool_calls": result.all_tool_calls
                    }
        initial_state = {
            "messages": [HumanMessage(content=user_message)],
            "instruction": "",
            "actions": [],
            "conversation_id": conversation_id,
            "force_srs_mode": False,
        }
        
        if context_values:
            initial_state.update(context_values)
            logger.info(f"[CONTEXT] Updated initial_state with context_values: {list(context_values.keys())}")
            for key, value in context_values.items():
                logger.debug(f"[CONTEXT]   - {key}: {value}")
        
        logger.info(f"[INITIAL_STATE] Keys in initial_state: {list(initial_state.keys())}")
        state_without_messages = {k: v for k, v in initial_state.items() if k != 'messages'}
        logger.debug(f"[INITIAL_STATE] Full initial_state (excluding messages): {state_without_messages}")
        
        all_messages, all_tool_calls = await _process_new_message(
            graph, initial_state, config, stream_mode="values"
        )
        
        final_response = _extract_final_response(all_messages)

        snapshot = await _safe_aget_state(graph, config)

        confirmation_data = await _check_for_confirmation_needed(snapshot, start_time)
        if confirmation_data:
            return confirmation_data

        chat_history = _get_chat_history(snapshot)
        total_prompt_token = tiktoken_counter(chat_history) if chat_history else 0

        prompt_token = total_prompt_token - initial_prompt_token
        completion_token = tiktoken_counter([AIMessage(content=final_response)])
        execution_time = int((datetime.datetime.now(datetime.timezone.utc) - start_time).total_seconds())
        
        response_content = extract_content_from_response(final_response) if final_response else ""
        return {
            "response": response_content,
            "prompt_token": prompt_token,
            "completion_token": completion_token,
            "execution_time": execution_time,
            "tool_calls": all_tool_calls
        }
                
    except Exception as exc:
        return {"response": f"An error occurred: {str(exc)}"}


async def _streaming_impl(
    graph: CompiledStateGraph,
    conversation_id: str,
    user_message: str,
    context_values: Dict[str, Any],
) -> AsyncGenerator[str, None]:
    """Internal implementation of streaming with real-time message streaming."""
    try:
        graph_config = getattr(graph, '_config', {})
        config = {
            "configurable": {
                "thread_id": conversation_id,
                **graph_config,
                **context_values
            }
        }
        
        snapshot = await _safe_aget_state(graph, config)
        if isinstance(snapshot, tuple):
            snapshot = snapshot[0]
        
        if _has_pending_interrupt(snapshot):
            messages = _get_chat_history(snapshot)
            if messages:
                last_message = messages[-1]
                if hasattr(last_message, "tool_calls") and last_message.tool_calls:
                    logger.debug("Processing pending tool call confirmation")
                    
                    confirmation_inputs = {"y", "yes", "ok", "confirm"}
                    
                    if user_message.strip().lower() in confirmation_inputs:
                        logger.debug("User confirmed tool call")
                        message = None
                    else:
                        logger.debug("User provided modification or rejection")
                        tool_call_id = last_message.tool_calls[0]["id"]
                        message = ToolMessage(
                            tool_call_id=tool_call_id,
                            content=f"User wants to modify the request or STOP the process. Reason: '{user_message}'. Continue assisting, accounting for the user's input.",
                        )
                    
                    graph_input = {"messages": message} if message is not None else None
                    
                    async for node_name, (msg, metadata) in graph.astream(
                        graph_input, config, stream_mode="messages", subgraphs=True
                    ):
                        if isinstance(msg, AIMessage) and msg.content:
                            content = extract_content_from_response(msg)
                            if len(content) > 10:
                                for i in range(0, len(content), 10):
                                    part = content[i : i + 10]
                                    payload = ChunkMessage(
                                        response=part, tools=None,
                                        prompt_token=None, completion_token=None, time_process=None
                                    )
                                    yield f"data: {payload.model_dump_json()}\n\n"
                            else:
                                payload = ChunkMessage(
                                    response=content, tools=None,
                                    prompt_token=None, completion_token=None, time_process=None
                                )
                                yield f"data: {payload.model_dump_json()}\n\n"
                    return
        
        initial_state = {
            "messages": [HumanMessage(content=user_message)],
            "instruction": "",
            "actions": [],
            "conversation_id": conversation_id,
            "force_srs_mode": False,
        }
        
        if context_values:
            initial_state.update(context_values)
        
        async for node_name, (msg, metadata) in graph.astream(
            initial_state, config, stream_mode="messages", subgraphs=True
        ):
            if isinstance(msg, AIMessage) and msg.content:
                content = extract_content_from_response(msg)
                if len(content) > 10:
                    for i in range(0, len(content), 10):
                        part = content[i : i + 10]
                        payload = ChunkMessage(
                            response=part, tools=None,
                            prompt_token=None, completion_token=None, time_process=None
                        )
                        yield f"data: {payload.model_dump_json()}\n\n"
                else:
                    payload = ChunkMessage(
                        response=content, tools=None,
                        prompt_token=None, completion_token=None, time_process=None
                    )
                    yield f"data: {payload.model_dump_json()}\n\n"
        
        snapshot = await _safe_aget_state(graph, config)
        if isinstance(snapshot, tuple):
            snapshot = snapshot[0]
        
        if _has_pending_interrupt(snapshot):
            messages = _get_chat_history(snapshot)
            last_message = messages[-1] if messages else None
            
            if last_message and hasattr(last_message, "tool_calls") and last_message.tool_calls:
                tool_args = last_message.tool_calls[0]["args"]
                logger.debug(f"New tool call request: {tool_args}")
                
                args_to_display = {k: v for k, v in tool_args.items() if k not in ["user_id", "conversation_id"]}
                
                formatted_args = format_tool_args_to_markdown(args_to_display)
                
                confirmation_message = (
                    f"**Please confirm your request:**\n\n"
                    f"{formatted_args}\n\n"
                    f"Press **'y'** to confirm\n"
                    f"Press **'n'** to reject"
                )
                
                for char in confirmation_message:
                    payload = ChunkMessage(
                        response=char,
                        tools=None,
                        prompt_token=0,
                        completion_token=0,
                        time_process=0
                    )
                    yield f"data: {payload.model_dump_json()}\n\n"
                return
        
        logger.debug(f"Stream finished for conversation: {conversation_id}")
                
    except Exception as exc:
        logger.error(f"Error in _streaming_impl: {exc}", exc_info=exc)
        error_payload = ChunkMessage(
            response=f"An error occurred: {str(exc)}",
            prompt_token=0,
            completion_token=0,
            tools=None,
            time_process=0
        )
        yield f"data: {error_payload.model_dump_json()}\n\n"


async def create_react_agent(
    llm: BaseChatModel,
    agent_description: str,
    checkpointer: Optional[BaseCheckpointSaver] = None,
    tools: Optional[List[Callable]] = None,
    tool_descriptions: Optional[Dict[str, str]] = None,
    tool_guide: Optional[Dict[str, str]] = None,
    tool_arg_schemas: Optional[Dict[str, Type[BaseModel]]] = None,
    additional_context_model: Optional[Type[BaseModel]] = None,
    max_tool_rounds: int = 10,
    max_tokens: int = 100000,
    interrupt_before: Optional[List[str]] = None,
    interrupt_after: Optional[List[str]] = None,
    use_prompt_cache: bool = False,
    use_planner: bool = True,
    mcp_tools: Optional[List[Dict[str, Any]]] = None,
) -> ReActAgent:
    """
    ASYNC version of create_react_agent with MCP support.
    
    Use this when you have MCP tools. All parameters are the same as
    create_react_agent, but this must be awaited.
    
    Example::
    
        # Initialize with MCP tools
        agent = await create_react_agent_async(
            checkpointer=MemorySaver(),
            llm=ChatAnthropic(model="claude-sonnet-4-20250514"),
            agent_description="You are an RKC assistant.",
            mcp_tools=[
                {"name": "rkc", "url": "https://rkc.com/mcp"}
            ],
            interrupt_before=["delete_user"],  # Use MCP tool names!
        )
        
        # Access MCP tool names
        print(f"Loaded {len(agent.mcp_tool_names)} MCP tools:")
        print(agent.mcp_tool_names)
        
        # Use the agent
        result = await agent.invoke(
            conversation_id="user-123",
            user_message="Get my info"
        )
    """
    mcp_langchain_tools = []
    mcp_tool_names_list = []
    all_tool_descriptions = tool_descriptions.copy() if tool_descriptions else {}
    
    if mcp_tools:
        logger.info(f"[MCP] Fetching tools from {len(mcp_tools)} MCP server(s)...")
        
        mcp_tools_list, mcp_descriptions, _ = await fetch_mcp_tools(mcp_tools)
        
        if mcp_tools_list:
            mcp_langchain_tools = mcp_tools_list
            mcp_tool_names_list = extract_mcp_tool_names(mcp_tools_list)
            
            all_tool_descriptions.update(mcp_descriptions)
            logger.info(
                f"[MCP] ✓ Fetched {len(mcp_langchain_tools)} MCP tools: {mcp_tool_names_list}"
            )
    
    graph = build_graph(
        checkpointer=checkpointer,
        llm=llm,
        agent_description=agent_description,
        tools=tools,
        mcp_langchain_tools=mcp_langchain_tools,
        tool_descriptions=all_tool_descriptions,
        tool_guide=tool_guide,
        tool_arg_schemas=tool_arg_schemas,
        additional_context_model=additional_context_model,
        max_tool_rounds=max_tool_rounds,
        max_tokens=max_tokens,
        interrupt_before=interrupt_before,
        interrupt_after=interrupt_after,
        use_prompt_cache=use_prompt_cache,
        use_planner=use_planner,
    )
    
    return ReActAgent(graph, mcp_tool_names=mcp_tool_names_list)

async def get_mcp_tool_names_from_config(mcp_tools_config: List[Dict[str, Any]]) -> List[str]:
    """
    Pre-fetch MCP tool names from configuration without creating full agent.
    Useful for determining interrupt_before list before agent creation.
    
    Args:
        mcp_tools_config: List of MCP server configurations
    
    Returns:
        List of tool names available from the MCP servers
    
    Example::
    
        # Get tool names first
        mcp_config = [{"name": "rkc", "url": "https://rkc.com/mcp"}]
        tool_names = await get_mcp_tool_names_from_config(mcp_config)
        
        print(f"Available tools: {tool_names}")
        # ['get_user_info', 'delete_user', 'get_charge_info', ...]
        
        # Select sensitive ones
        sensitive = [t for t in tool_names if 'delete' in t or 'cancel' in t]
        
        # Create agent with interrupts
        agent = await create_react_agent_async(
            mcp_tools=mcp_config,
            interrupt_before=sensitive,
            ...
        )
    """
    if not mcp_tools_config:
        return []
    
    _, _, _ = await fetch_mcp_tools(mcp_tools_config)
    tools, _, _ = await fetch_mcp_tools(mcp_tools_config)
    return extract_mcp_tool_names(tools)
