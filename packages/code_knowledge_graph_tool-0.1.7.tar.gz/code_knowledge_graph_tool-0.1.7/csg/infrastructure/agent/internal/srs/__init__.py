﻿"""SRS document generation."""

from csg.infrastructure.agent.internal.srs.generator_runtime import srs_generation_tool

__all__ = ["srs_generation_tool"]

