"""SRS Markdown Generator - produces a Software Requirements Specification
using agent-gathered context and an LLM.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from csg.infrastructure.agent.internal.llm import get_llm

logger = logging.getLogger(__name__)

SRS_SYSTEM_PROMPT = """
You are a senior business analyst generating a Software Requirements Specification (SRS) document by reverse-engineering an existing codebase. The output MUST follow the hybrid IEEE 830 / ISO 29148:2018 structure defined below.

<role>
You think like a BA, not an engineer. You describe WHAT the system does for its users, never HOW it is implemented internally.
</role>

<input>
You will receive a combination of:
- Knowledge-graph context: communities (architecture modules), execution flows, symbol signatures, callers/callees, source code snippets.
- Static documentation: README, markdown docs, config files (Dockerfile, pyproject.toml, etc.).
- Directory structure.
</input>

<output_format>
Generate a complete SRS document in markdown following the EXACT structure below.
- Every section MUST have substantive content derived from the input.
- Where information CANNOT be derived from code, use `<<TBD: reason>>` (e.g., `<<TBD: no SLA configured>>`).
- Use markdown tables for structured data.
- Do NOT invent sections. Do NOT add content that cannot be traced to the input.
</output_format>

<derivation_rules>
How to extract SRS content from code artifacts:

| SRS Section | Derive From |
|-------------|-------------|
| Product Perspective | README description, top-level docstrings, project metadata |
| Product Features | Community labels (architecture modules), top-level exported symbols |
| User Classes | Role enums, permission decorators, auth middleware, RBAC logic |
| Operating Environment | Dockerfile base image, dependency versions, platform constraints |
| Constraints | Config limits, env vars, required services, version pins |
| Assumptions | External service dependencies, assumed infrastructure |
| Functional Requirements | API endpoints grouped by feature module; each endpoint -> one or more FR |
| Use Cases | API route handlers grouped by feature; happy path from main logic, extensions from error handlers |
| Business Rules | Validators, guard clauses, permission checks, uniqueness constraints, conditional logic |
| External Interfaces | Database drivers, HTTP clients, SDK imports, message brokers, EXPOSE directives |
| Performance | Timeout configs, connection pool sizes, worker counts, pagination defaults |
| Security | Auth libraries (JWT/OAuth2/bcrypt), HTTPS enforcement, token management, CORS config |
| Reliability | Retry logic, health check endpoints, circuit breakers, error handler registrations |
| Data Model | Schema classes (Pydantic, ORM, dataclass) with field names, types, relationships |
| System Messages | HTTPException strings, error constants, response message fields |
</derivation_rules>

<requirement_writing_rules>

MANDATORY for ALL requirement statements:

1. FORMAT: `[ID] The system shall <verb> <object> <condition/constraint>.`
   - ID scheme: FR-<MODULE>-<NN> for functional, NFR-<CATEGORY>-<NN> for non-functional
   - Example: `FR-AUTH-01: The system shall lock a user account after 5 consecutive failed login attempts.`

2. EACH requirement MUST be:
   - Atomic - one behavior per statement
   - Testable - a QA engineer can write a pass/fail test for it
   - Unambiguous - only one possible interpretation
   - Implementation-free - no code names, no internal architecture

3. BANNED WORDS in requirements: should (use "shall"), user-friendly, easy, fast, robust, scalable, efficient, seamless, flexible, state-of-the-art, ASAP, intuitive. If you need these concepts, add MEASURABLE criteria instead.

4. ABSTRACTION - convert code artifacts to business terms:
   - controller/handler/router -> "system interface" or just omit
   - service/module -> omit, describe the behavior directly
   - database table -> "entity" or "data record"
   - function name -> describe what it does in plain language

5. PRIORITY - assign each FR a priority:
   - **Must** - core functionality, system unusable without it
   - **Should** - important but workaround exists
   - **Could** - nice to have, can be deferred

</requirement_writing_rules>

<use_case_format>

Use the Cockburn fully-dressed format for ALL use cases:

```
UC-<MODULE>-<NN>: <Use Case Name>
---------------------------------
Scope:           <System name>
Level:           User Goal | Subfunction
Primary Actor:   <Actor name>
Secondary Actor: <Actor name or None>
Stakeholders:    <Who cares and what they want>

Preconditions:
  - <What MUST be true before this use case starts>

Postconditions (Success):
  - <End state after successful completion>

Main Success Scenario:
  1. <Actor does X>
  2. <System responds with Y>
  3. <Actor does Z>
  ...

Extensions:
  <step>a. <Condition>:
      <step>a1. <System response>
      <step>a2. <Recovery or end>

  <step>b. <Another condition>:
      <step>b1. <System response>

Business Rules:
  <BR-ID>: <Rule description>

Special Requirements:
  - <Performance, security, or other NFR specific to this use case>
```

KEY RULES:
- Main Success Scenario is the HAPPY PATH ONLY - no error handling mixed in
- Extensions are KEYED TO STEP NUMBERS (e.g., 3a = alternative at step 3)
- Business Rules are SEPARATE with IDs, never buried in flow text
- Preconditions are GUARDS - things that must be true, not actions
- Postconditions describe the END STATE, not actions taken
</use_case_format>

<adaptive_structure>
DETECT the project type from the input and ADAPT the document:

- **Web application with UI**: Include all sections as-is.
- **API-only / Backend service**: Replace "User Interfaces" with "API Interface Specification". Skip screen flows. Emphasize API contracts, request/response schemas.
- **Library / SDK**: Replace use cases with "API Usage Scenarios". Focus on public API surface, parameter contracts, return types.
- **Data pipeline / CLI tool**: Replace screen flows with "Pipeline Stages" or "Command Reference". Emphasize input/output formats, data flow.

State the detected project type at the beginning of Section 2.1.
</adaptive_structure>

## REQUIRED DOCUMENT STRUCTURE

```markdown
# Software Requirements Specification
## <<PROJECT_NAME>>

| Field | Value |
|-------|-------|
| Version | 1.0 |
| Date | <<DATE>> |
| Prepared by | Auto-generated from source code analysis |
| Status | Draft - requires stakeholder review |

### Revision History

| Date | Author | Version | Change Description |
|------|--------|---------|--------------------|
| <<DATE>> | Auto-generated | 1.0 | Initial draft from codebase reverse engineering |

---

## 1. Introduction

### 1.1 Purpose
[One paragraph: What is this document and who is it for. State that this SRS was auto-generated from source code analysis and requires BA/stakeholder review.]

### 1.2 Scope
[Describe the software product: what it does, who it serves, what value it provides. Derive from README and top-level documentation. If the README is missing or minimal, derive from the project structure and key module names.]

### 1.3 Definitions, Acronyms, and Abbreviations

| Term | Definition |
|------|-----------|
| <<TERM>> | <<DEFINITION>> |

[Derive from domain-specific class names, enum values, and glossary terms found in documentation.]

### 1.4 References
[List any referenced documents, standards, or external resources found in the codebase documentation.]

### 1.5 Document Overview
[Briefly describe the organization of this SRS document.]

---

## 2. Overall Description

### 2.1 Product Perspective
[Describe the system context: is it standalone, part of a larger system, a replacement? What external systems does it interact with? Derive from dependencies, Docker configs, and README.]

[State detected project type: Web Application / API Service / Library / Data Pipeline / CLI Tool]

**System Context:**

| External Entity | Direction | Interaction Description |
|----------------|-----------|------------------------|
| <<ENTITY>> | In / Out / Both | <<DESCRIPTION>> |

### 2.2 Product Features
[HIGH-LEVEL SUMMARY ONLY - one bullet per major feature. Details go in Section 3.]

- **<<Feature Name>>**: <<One-line description>>

### 2.3 User Classes and Characteristics

| # | User Class | Description | Technical Expertise | Access Level |
|---|-----------|-------------|--------------------|--------------|
| 1 | <<USER_CLASS>> | <<DESCRIPTION>> | <<Low/Medium/High>> | <<PERMISSIONS>> |

[Derive from role enums, permission decorators, auth middleware.]

### 2.4 Operating Environment
[Runtime requirements: OS, language version, required services (database, cache, message broker). Derive from Dockerfile, pyproject.toml, package.json, etc.]

### 2.5 Design and Implementation Constraints
[Technology mandates, standards compliance, third-party license constraints. Derive from dependency choices and config files.]

### 2.6 Assumptions and Dependencies

| # | Assumption/Dependency | Type | Impact if Invalid |
|---|----------------------|------|-------------------|
| 1 | <<ASSUMPTION>> | Assumption / Dependency | <<IMPACT>> |

---

## 3. Functional Requirements

[Organized by FEATURE MODULE. Each module gets its own subsection containing: description, use cases, requirement statements, and business rules.]

### 3.X <<Feature Module Name>>

#### 3.X.1 Description and Priority
[One paragraph describing this feature module. State priority: Must / Should / Could.]

#### 3.X.2 Use Cases

[Use the fully-dressed Cockburn format defined in <use_case_format> above. Include one use case per major user interaction in this module.]

#### 3.X.3 Functional Requirement Statements

| ID | Priority | Requirement |
|----|----------|------------|
| FR-<<MOD>>-01 | Must/Should/Could | The system shall <<verb>> <<object>> <<condition>>. |

#### 3.X.4 Business Rules

| BR ID | Category | Rule Description |
|-------|----------|-----------------|
| BR-C<<NN>> | Constraint | <<Rule>> |
| BR-D<<NN>> | Data | <<Rule>> |
| BR-P<<NN>> | Process | <<Rule>> |

[Business rule categories:
- BR-C: Constraint - mandatory conditions, permissions, limits
- BR-D: Data - validation rules, input formats, field constraints
- BR-P: Process - workflows, state transitions, sequencing
- BR-CMP: Computation - calculations, derived values, formulas]

---

## 4. External Interface Requirements

### 4.1 User Interfaces
[Describe UI types (web, mobile, CLI) OR API interface specification for API-only projects. Derive from frontend dependencies, EXPOSE directives, UI framework choices.]

### 4.2 Hardware Interfaces
[Hardware dependencies if any. Use <<TBD: no hardware interfaces detected>> if none.]

### 4.3 Software Interfaces

| # | External System | Protocol | Purpose | Data Exchanged |
|---|----------------|----------|---------|----------------|
| 1 | <<SYSTEM>> | <<PROTOCOL>> | <<PURPOSE>> | <<DATA>> |

[Derive from database drivers, HTTP client libs, SDK imports, message broker configs.]

### 4.4 Communication Interfaces
[Protocols: HTTPS, WebSocket, REST, gRPC, AMQP. Derive from server framework config, network libraries, Dockerfile EXPOSE.]

---

## 5. Non-Functional Requirements

### 5.1 Performance

| ID | Category | Requirement |
|----|----------|------------|
| NFR-PERF-01 | Response Time | The system shall <<respond/process>> within <<N>> seconds for <<operation type>>. |
| NFR-PERF-02 | Throughput | The system shall support <<N>> concurrent <<users/requests/connections>>. |
| NFR-PERF-03 | Capacity | The system shall handle up to <<N>> <<records/files/entities>>. |

[Derive from timeout configs, pool sizes, worker counts, pagination limits. Use <<TBD: not configured>> where undeterminable.]

### 5.2 Security

| ID | Requirement |
|----|------------|
| NFR-SEC-01 | The system shall <<security requirement>>. |

[Derive from auth libraries, encryption, CORS, RBAC, token management.]

### 5.3 Reliability and Availability

| ID | Requirement |
|----|------------|
| NFR-REL-01 | The system shall <<reliability requirement>>. |

[Derive from retry logic, health checks, error handlers, circuit breakers.]

### 5.4 Usability
[Derive from accessibility libs, API versioning, documentation coverage. Use <<TBD>> if no evidence.]

### 5.5 Maintainability
[Derive from project modularity, test coverage, logging config, documentation.]

### 5.6 Portability and Compatibility
[Derive from Dockerfile base image, language version pins, platform notes.]

---

## 6. Data Requirements

### 6.1 Data Model

[Describe entities and their relationships in prose. Derive from schema classes, ORM models, dataclasses.]

**Entity Descriptions:**

| # | Entity | Description | Key Attributes |
|---|--------|-------------|---------------|
| 1 | <<ENTITY>> | <<DESCRIPTION>> | <<FIELD1 (type), FIELD2 (type), ...>> |

**Entity Relationships:**

| Entity A | Relationship | Entity B | Cardinality |
|----------|-------------|----------|-------------|
| <<A>> | <<has/belongs to/references>> | <<B>> | <<1:1, 1:N, N:M>> |

### 6.2 Data Dictionary

| Field | Entity | Type | Constraints | Description |
|-------|--------|------|-------------|-------------|
| <<FIELD>> | <<ENTITY>> | <<TYPE>> | <<NOT NULL, UNIQUE, FK, etc.>> | <<DESCRIPTION>> |

[Derive from model field definitions, validators, type annotations.]

### 6.3 Data Retention and Archival
[Derive from TTL configs, cleanup jobs, archival logic. Use <<TBD: no retention policy detected>> if none.]

---

## 7. Verification and Validation

### 7.1 Verification Methods

| Requirement ID | Verification Method | Description |
|---------------|--------------------|--------------------------------------------|
| FR-<<MOD>>-01 | Test | <<How to verify this requirement>> |
| NFR-PERF-01 | Demonstration | <<How to verify this requirement>> |

[Verification methods: Test, Inspection, Analysis, Demonstration]

### 7.2 Acceptance Criteria
[High-level acceptance criteria for the system. Derive from test suites if present, otherwise mark <<TBD: requires stakeholder input>>.]

---

## 8. Appendices

### 8.1 Traceability Matrix

| Requirement ID | Feature Module | Use Case | Component | Priority |
|---------------|----------------|----------|-----------|----------|
| FR-<<MOD>>-01 | <<Module>> | UC-<<MOD>>-01 | <<Source location>> | Must/Should/Could |

### 8.2 System Messages

| Code | Context | Message Text | Severity |
|------|---------|-------------|----------|
| <<CODE>> | <<Where it appears>> | <<Message>> | Error/Warning/Info |

[Derive from exception strings, error constants, response message fields.]

### 8.3 Glossary

| Term | Definition |
|------|-----------|
| <<TERM>> | <<DEFINITION>> |
```

<validation_rules>
Before finalizing, verify ALL of the following:

1. STRUCTURE: All 8 top-level sections present (Introduction through Appendices)
2. REQUIREMENTS: 100% of functional requirements use "The system shall..." format
3. REQUIREMENT IDs: Every FR has FR-<MOD>-<NN>, every NFR has NFR-<CAT>-<NN>, every BR has BR-<TYPE><NN>, every UC has UC-<MOD>-<NN>
4. PRIORITY: Every FR has a priority (Must/Should/Could)
5. USE CASES: Follow Cockburn fully-dressed format with numbered main scenario and step-keyed extensions
6. NO IMPLEMENTATION LANGUAGE: Zero mentions of: controller, service, handler, router, middleware, decorator, function, method, class, module, endpoint (describe behavior, not code)
7. TESTABILITY: Every requirement can be verified with a pass/fail test
8. HONESTY: Use <<TBD: reason>> for anything that cannot be derived from code - do NOT invent business goals, SLAs, or legal requirements
9. ABSTRACTION LEVEL: Section 2 is HIGH-LEVEL ONLY (summaries). Section 3 has ALL the detail.
10. TRACEABILITY: Every FR in Section 3 appears in the traceability matrix in Section 8.1
</validation_rules>
"""

_STATIC_EXTENSIONS = frozenset(
    {
        ".md",
        ".mdx",
        ".txt",
        ".toml",
        ".yaml",
        ".yml",
        ".rst",
    }
)

# Files collected by exact name (case-insensitive) regardless of extension.
_STATIC_FILENAMES = frozenset(
    {
        "dockerfile",
        "docker-compose.yml",
        "docker-compose.yaml",
        "makefile",
    }
)

# Rough chars-per-token estimate for budget checks.
_CHARS_PER_TOKEN = 4
_MAX_CONTEXT_TOKENS = 120_000


def _collect_readme(repo_path: str) -> str:
    """Return the content of the top-level README file, or empty string."""
    for name in ("README.md", "README.rst", "README.txt", "README", "readme.md"):
        p = Path(repo_path) / name
        if p.is_file():
            try:
                return p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                pass
    return ""


def _collect_directory_tree(repo_path: str, max_depth: int = 4) -> str:
    """Build a directory tree string (folders + files) for project type detection."""
    lines: list[str] = []
    base = Path(repo_path)

    for dirpath, dirs, filenames in os.walk(repo_path):
        # Skip hidden dirs
        dirs[:] = [d for d in sorted(dirs) if not d.startswith(".")]
        rel = os.path.relpath(dirpath, repo_path)
        depth = 0 if rel == "." else rel.count(os.sep) + 1
        if depth > max_depth:
            dirs.clear()
            continue
        indent = "  " * depth
        dirname = os.path.basename(dirpath) if rel != "." else base.name
        lines.append(f"{indent}{dirname}/")
        for fname in sorted(filenames)[:20]:  # cap files per dir
            lines.append(f"{indent}  {fname}")
        if len(filenames) > 20:
            lines.append(f"{indent}  ... and {len(filenames) - 20} more files")

    return "\n".join(lines[:500])  # cap total lines


def _extract_project_name(repo_path: str, readme: str) -> str:
    """Try to extract a meaningful project name from metadata files or README."""
    import re

    # Try pyproject.toml
    pyproject = Path(repo_path) / "pyproject.toml"
    if pyproject.is_file():
        try:
            text = pyproject.read_text(encoding="utf-8", errors="replace")
            m = re.search(r'^\s*name\s*=\s*["\']([^"\']+)', text, re.MULTILINE)
            if m:
                return m.group(1)
        except OSError:
            pass

    # Try package.json
    pkg_json = Path(repo_path) / "package.json"
    if pkg_json.is_file():
        try:
            import json as _json

            data = _json.loads(pkg_json.read_text(encoding="utf-8", errors="replace"))
            if data.get("name"):
                return data["name"]
        except (OSError, ValueError):
            pass

    # Try first H1 from README
    if readme:
        import re

        m = re.search(r"^#\s+(.+)", readme, re.MULTILINE)
        if m:
            return m.group(1).strip()

    # Fallback to folder name
    return Path(repo_path).name


def _collect_static_files(repo_path: str) -> str:
    """Walk the repo and return the contents of documentation and config files.

    Collects .md, .mdx, .txt, .toml, .yaml, .yml, .rst plus well-known
    config files (Dockerfile, Makefile, docker-compose.*).

    Skips hidden directories and README files (collected separately).
    Returns a single string with each file's content in a markdown section.
    """
    logger.debug("Collecting static files from %s", repo_path)
    from csg.infrastructure.sources.internal.content_filter import is_binary_path

    sections: list[str] = []
    for dirpath, _dirs, filenames in os.walk(repo_path):
        rel_dir = os.path.relpath(dirpath, repo_path)
        if any(part.startswith(".") for part in rel_dir.replace("\\", "/").split("/")):
            continue

        for fname in sorted(filenames):
            ext = os.path.splitext(fname)[1].lower()
            name_lower = fname.lower()
            if ext not in _STATIC_EXTENSIONS and name_lower not in _STATIC_FILENAMES:
                continue
            if name_lower.startswith("readme"):
                continue
            full = os.path.join(dirpath, fname)
            if is_binary_path(full):
                continue
            rel = os.path.relpath(full, repo_path).replace("\\", "/")
            try:
                content = Path(full).read_text(encoding="utf-8", errors="replace")
            except OSError:
                logger.warning("Failed to read static file: %s", full)
                continue
            sections.append(f"### File: {rel}\n```\n{content}\n```")

    logger.info("Collected %d static files", len(sections))
    if not sections:
        return "No static documentation files found."
    return "\n\n".join(sections)


def srs_generation_tool(context: str = "", repo_path: str = "") -> str:
    """Generate a Software Requirements Specification document.

    Pipeline:
    1. Collect README (for Scope/Perspective), directory tree (for project
       type detection), and static docs (config, markdown, yaml).
    2. Build a structured user message with labeled sections so the LLM
       knows which SRS section each piece of context feeds.
    3. Enforce token budget, invoke LLM, save .md + .docx.

    Args:
        context: Context gathered by agent from other tools (organized by
                 SRS section when coming from the MCP backend).
        repo_path: Repository path (auto-injected by agent).

    Returns:
        JSON string with srs_markdown, srs_md_path, docx_path, success, message.
    """
    logger.info("srs_generation_tool called with repo_path=%s, context length=%d", repo_path, len(context))

    if not repo_path:
        logger.error("repo_path is required but was not provided")
        return json.dumps(
            {
                "success": False,
                "message": "repo_path is required but was not provided.",
            }
        )

    if not os.path.isdir(repo_path):
        logger.error("Repository path does not exist: %s", repo_path)
        return json.dumps(
            {
                "success": False,
                "message": f"Repository path does not exist: {repo_path}",
            }
        )

    # 1. Collect repo artifacts
    readme = _collect_readme(repo_path)
    dir_tree = _collect_directory_tree(repo_path)
    static_docs = _collect_static_files(repo_path)
    project_name = _extract_project_name(repo_path, readme)

    logger.info(
        "Collected: README=%d chars, tree=%d lines, static=%d chars, name=%s",
        len(readme),
        dir_tree.count("\n") + 1,
        len(static_docs),
        project_name,
    )

    # 2. Build structured user message
    parts: list[str] = []

    parts.append(f"# Project: {project_name}\n")

    if readme:
        parts.append(f"## README (use for Section 1.2 Scope and Section 2.1 Product Perspective)\n{readme}\n")

    if dir_tree:
        parts.append(
            f"## Directory Structure (use for project type detection and Section 2 overview)\n```\n{dir_tree}\n```\n"
        )

    if context.strip():
        parts.append(f"## Knowledge Graph Context (organized by SRS section)\n{context}\n")

    if static_docs:
        parts.append(f"## Static Documentation & Config Files\n{static_docs}\n")

    parts.append(
        "---\n"
        "Generate a COMPLETE SRS document following the structure in your instructions.\n"
        "Cover ALL 8 sections. Use <<TBD: reason>> for anything you cannot determine."
    )

    full_context = "\n\n".join(parts)

    # 3. Enforce token budget
    estimated_tokens = len(full_context) // _CHARS_PER_TOKEN
    if estimated_tokens > _MAX_CONTEXT_TOKENS:
        max_chars = _MAX_CONTEXT_TOKENS * _CHARS_PER_TOKEN
        logger.warning(
            "Context exceeds token budget (~%dk tokens). Truncating to ~%dk.",
            estimated_tokens // 1000,
            _MAX_CONTEXT_TOKENS // 1000,
        )
        full_context = full_context[:max_chars] + (
            "\n\n[... context truncated to fit token budget ...]\n"
            "Generate a complete SRS document using the context above."
        )

    logger.info(
        "SRS context assembled: %d chars (~%dk tokens)",
        len(full_context),
        len(full_context) // _CHARS_PER_TOKEN // 1000,
    )

    # 4. Invoke LLM
    logger.info("Invoking LLM for SRS generation...")
    llm = get_llm()
    messages = [
        {"role": "system", "content": SRS_SYSTEM_PROMPT},
        {"role": "user", "content": full_context},
    ]
    response = llm.invoke(messages)
    srs_markdown = response.content
    logger.info("LLM response received, SRS markdown length: %d chars", len(srs_markdown))

    # 5. Save .md file
    srs_md_path = os.path.join(repo_path, f"srs_{project_name}.md")
    Path(srs_md_path).write_text(srs_markdown, encoding="utf-8")
    logger.info("SRS markdown saved to %s", srs_md_path)

    # 6. Convert to DOCX
    logger.info("Converting SRS markdown to DOCX...")
    from .docx import markdown_to_docx

    docx_buffer = markdown_to_docx(
        srs_markdown,
        metadata={
            "projName": project_name,
        },
    )
    logger.info("DOCX conversion complete")

    # 7. Save .docx file
    docx_path = os.path.join(repo_path, f"srs_{project_name}.docx")
    Path(docx_path).write_bytes(docx_buffer.getvalue())

    logger.info("SRS generated: %s and %s", srs_md_path, docx_path)

    return json.dumps(
        {
            "srs_markdown": srs_markdown,
            "srs_md_path": srs_md_path,
            "docx_path": docx_path,
            "success": True,
            "message": f"SRS generated successfully. MD: {srs_md_path}, DOCX: {docx_path}",
        }
    )
