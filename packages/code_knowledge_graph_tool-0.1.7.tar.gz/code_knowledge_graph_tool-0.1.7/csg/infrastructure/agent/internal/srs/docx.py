"""
========================================
Converts markdown  content into a formatted .docx file.
Used by the /api/export-docx endpoint.
"""

import io
import re
from docx import Document
from docx.shared import  Pt, Cm, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn


NAVY = RGBColor(0x08, 0x14, 0x2A)
BLUE = RGBColor(0x0F, 0x2D, 0x5E)
ACCENT = RGBColor(0x1D, 0x5F, 0xD4)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)


def _set_cell_shading(cell, color_hex: str):
    """Apply background shading to a table cell."""
    shading_elm = cell._element.get_or_add_tcPr()
    shading = shading_elm.makeelement(
        qn("w:shd"),
        {
            qn("w:val"): "clear",
            qn("w:color"): "auto",
            qn("w:fill"): color_hex,
        },
    )
    shading_elm.append(shading)


def _add_inline_runs(para, line: str):
    """Add runs to a paragraph handling bold (**text**) and <<FIELD>> markers."""
    parts = re.split(r"(\*\*[^*]+\*\*|<<[^>]+>>)", line)
    for part in parts:
        if part.startswith("**") and part.endswith("**"):
            run = para.add_run(part[2:-2])
            run.bold = True
            run.font.name = "Calibri"
            run.font.size = Pt(11)
        elif part.startswith("<<") and part.endswith(">>"):
            run = para.add_run(f"\u00ab{part[2:-2]}\u00bb")
            run.font.color.rgb = ACCENT
            run.italic = True
            run.font.name = "Calibri"
            run.font.size = Pt(11)
        else:
            run = para.add_run(part)
            run.font.name = "Calibri"
            run.font.size = Pt(11)


def markdown_to_docx(markdown_text: str, metadata: dict | None = None) -> io.BytesIO:
    """
    Convert markdown SoW text into a .docx file returned as a BytesIO buffer.

    Parameters
    ----------
    markdown_text : str
        The raw markdown from the Claude API response.
    metadata : dict, optional
        Engagement metadata (custShort, projName, sowType) for the filename/header.

    Returns
    -------
    io.BytesIO
        A buffer containing the .docx file bytes.
    """
    doc = Document()

    # ── Page setup ──
    section = doc.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(2.54)
    section.right_margin = Cm(2.54)

    # ── Default font ──
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Calibri"
    font.size = Pt(11)
    font.color.rgb = RGBColor(0x0F, 0x1F, 0x3D)

    # ── Heading styles (levels 1-5 to match SRS template depth) ──
    for level, (size, color, bold) in enumerate(
        [
            (18, NAVY, True),   # H1
            (14, BLUE, True),   # H2
            (12, NAVY, True),   # H3
            (11, BLUE, True),   # H4
            (11, NAVY, False),  # H5
        ],
        start=1,
    ):
        heading_style = doc.styles[f"Heading {level}"]
        heading_style.font.name = "Calibri"
        heading_style.font.size = Pt(size)
        heading_style.font.bold = bold
        heading_style.font.color.rgb = color

    meta = metadata or {}
    proj = meta.get("projName", "Project")

    # ── Header ──
    header_para = doc.sections[0].header.paragraphs[0]
    header_para.text = f"Software Requirements Specification — {proj}"
    header_para.style.font.size = Pt(8)
    header_para.style.font.color.rgb = RGBColor(0x5C, 0x6E, 0x91)

    # ── Pre-process: strip markdown code fences wrapping the whole output ──
    stripped = markdown_text.strip()
    if stripped.startswith("```"):
        first_nl = stripped.index("\n") if "\n" in stripped else len(stripped)
        stripped = stripped[first_nl + 1:]
        if stripped.rstrip().endswith("```"):
            stripped = stripped.rstrip()[:-3].rstrip()
        markdown_text = stripped

    # ── Parse markdown line by line ──
    lines = [line.rstrip("\r") for line in markdown_text.split("\n")]
    i = 0
    in_code_block = False

    while i < len(lines):
        line = lines[i]

        # ── Track fenced code blocks — render as monospaced paragraphs ──
        if line.strip().startswith("```"):
            in_code_block = not in_code_block
            i += 1
            continue
        if in_code_block:
            para = doc.add_paragraph()
            run = para.add_run(line)
            run.font.name = "Consolas"
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
            i += 1
            continue

        # ── Headings (check deepest first to avoid prefix collisions) ──
        if line.startswith("##### "):
            doc.add_heading(line[6:].strip(), level=5)
            i += 1
            continue
        if line.startswith("#### "):
            doc.add_heading(line[5:].strip(), level=4)
            i += 1
            continue
        if line.startswith("### "):
            doc.add_heading(line[4:].strip(), level=3)
            i += 1
            continue
        if line.startswith("## "):
            doc.add_heading(line[3:].strip(), level=2)
            i += 1
            continue
        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), level=1)
            i += 1
            continue

        # ── Tables ──
        if "|" in line and i + 1 < len(lines) and re.match(r"^\s*\|[-| :]+\|\s*$", lines[i + 1].strip()):
            header_cells = [c.strip() for c in line.split("|") if c.strip()]
            i += 2  # skip header + separator
            data_rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].split("|") if c.strip()]
                data_rows.append(cells)
                i += 1

            num_cols = len(header_cells)
            table = doc.add_table(rows=1 + len(data_rows), cols=num_cols)
            table.style = "Table Grid"
            table.alignment = WD_TABLE_ALIGNMENT.CENTER

            # Header row
            for j, text in enumerate(header_cells):
                if j < num_cols:
                    cell = table.rows[0].cells[j]
                    cell.text = ""
                    run = cell.paragraphs[0].add_run(text)
                    run.bold = True
                    run.font.color.rgb = WHITE
                    run.font.size = Pt(10)
                    run.font.name = "Calibri"
                    _set_cell_shading(cell, "08142A")

            # Data rows
            for row_idx, row_data in enumerate(data_rows):
                for col_idx, text in enumerate(row_data):
                    if col_idx < num_cols:
                        cell = table.rows[row_idx + 1].cells[col_idx]
                        clean = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
                        cell.text = clean
                        for paragraph in cell.paragraphs:
                            paragraph.style.font.size = Pt(10)
                            paragraph.style.font.name = "Calibri"
                        if row_idx % 2 == 1:
                            _set_cell_shading(cell, "EEF3FF")
            continue

        # ── Numbered lists (1. , 2. , etc.) ──
        num_match = re.match(r"^(\d+)\.\s+(.*)", line)
        if num_match:
            text = num_match.group(2).strip()
            text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
            para = doc.add_paragraph(text, style="List Number")
            i += 1
            continue

        # ── Bullet lists (top-level and indented) ──
        bullet_match = re.match(r"^(\s*)[-*]\s+(.*)", line)
        if bullet_match:
            text = bullet_match.group(2).strip()
            text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
            indent = len(bullet_match.group(1))
            if indent >= 2:
                para = doc.add_paragraph(text, style="List Bullet 2")
            else:
                para = doc.add_paragraph(text, style="List Bullet")
            i += 1
            continue

        # ── Horizontal rule ──
        if line.strip() == "---":
            para = doc.add_paragraph()
            para.paragraph_format.space_after = Pt(6)
            # Add a bottom border
            pPr = para._p.get_or_add_pPr()
            pBdr = pPr.makeelement(qn("w:pBdr"), {})
            bottom = pBdr.makeelement(
                qn("w:bottom"),
                {
                    qn("w:val"): "single",
                    qn("w:sz"): "4",
                    qn("w:space"): "1",
                    qn("w:color"): "CCCCCC",
                },
            )
            pBdr.append(bottom)
            pPr.append(pBdr)
            i += 1
            continue

        # ── Blank line ──
        if not line.strip():
            i += 1
            continue

        # ── Regular paragraph with inline formatting ──
        para = doc.add_paragraph()
        _add_inline_runs(para, line)
        i += 1

    # ── Write to buffer ──
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer
