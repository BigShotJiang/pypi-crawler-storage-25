from langgraph.graph import StateGraph, END
from langgraph.graph.state import CompiledStateGraph
from langgraph.checkpoint.base import BaseCheckpointSaver
from langchain_core.language_models import BaseChatModel
from langchain_core.tools import tool, BaseTool
from langchain_core.runnables import RunnableConfig
from pydantic import BaseModel
from typing import Callable, List, Dict, Optional, Type, Any

from .agent_state import create_state_with_context, AgenticState
from .graph_nodes import planner_agent, call_model, should_continue
from .utils.context import safe_get
from .utils.logger import logger
from .tools.memory import create_memory_tool, MEMORY_TOOL_NAME
from .tools.skills import DEFAULT_SKILLS
from .planner import MEMORY_TOOL_REGISTRY_ENTRY

def build_tool_skill_registry(
    tool_descriptions: Optional[Dict[str, str]] = None,
    tool_guide: Optional[Dict[str, str]] = None,
) -> Dict[str, Dict]:
    """
    Assemble the full tool/skill registry that is shared between the planner
    (so it can choose actions) and the main agent (so it knows which guidance
    to receive).

    Registry entry shape:
        {
            "name":        str,  # same as the key
            "description": str,  # shown to planner (when to use)
            "guide":       str,  # injected into main agent (how to use)
        }

    Registration order:
        1. Default skills (gestures, out_of_scopes, abusive)
        2. Memory tool (always present)
        3. User-supplied tool_descriptions (for planner)
        4. User-supplied tool_guide (for call_model)
    """
    registry: Dict[str, Dict] = {}

    for skill_name, skill_entry in DEFAULT_SKILLS.items():
        registry[skill_name] = skill_entry.copy()

    registry[MEMORY_TOOL_REGISTRY_ENTRY["name"]] = {
        "name": MEMORY_TOOL_REGISTRY_ENTRY["name"],
        "description": MEMORY_TOOL_REGISTRY_ENTRY["description"],
    }
    if "guide" in MEMORY_TOOL_REGISTRY_ENTRY:
        registry[MEMORY_TOOL_REGISTRY_ENTRY["name"]]["guide"] = MEMORY_TOOL_REGISTRY_ENTRY["guide"]

    if tool_descriptions:
        for tool_name, desc in tool_descriptions.items():
            if tool_name in registry:
                registry[tool_name]["description"] = desc
                if "guide" not in registry[tool_name]:
                    registry[tool_name]["guide"] = desc
            else:
                registry[tool_name] = {
                    "name": tool_name,
                    "description": desc,
                    "guide": desc,
                }

    if tool_guide:
        for tool_name, guide in tool_guide.items():
            if tool_name in registry:
                registry[tool_name]["guide"] = guide
                if "description" not in registry[tool_name] or not registry[tool_name].get("description"):
                    registry[tool_name]["description"] = guide
            else:
                registry[tool_name] = {
                    "name": tool_name,
                    "description": guide,
                    "guide": guide,
                }

    for tool_name, entry in registry.items():
        if "description" not in entry or not entry.get("description"):
            if "guide" in entry and entry.get("guide"):
                entry["description"] = entry["guide"]
        if "guide" not in entry or not entry.get("guide"):
            if "description" in entry and entry.get("description"):
                entry["guide"] = entry["description"]

    logger.info(f"[TOOL_REGISTRY] Built registry with {len(registry)} tools/skills")
    for tool_name, entry in registry.items():
        has_desc = bool(entry.get("description"))
        has_guide = bool(entry.get("guide"))
        desc_source = "custom" if tool_name in (tool_descriptions or {}) else "default"
        guide_source = "custom" if tool_name in (tool_guide or {}) else "default"
        logger.info(
            f"[TOOL_REGISTRY] {tool_name}: "
            f"description={has_desc}({desc_source}), guide={has_guide}({guide_source})"
        )

    return registry


def build_graph(
    llm: BaseChatModel,
    agent_description: str,
    checkpointer: Optional[BaseCheckpointSaver] = None,
    tools: Optional[List[Callable]] = None,
    tool_descriptions: Optional[Dict[str, str]] = None,
    tool_guide: Optional[Dict[str, str]] = None,
    tool_arg_schemas: Optional[Dict[str, Type[BaseModel]]] = None,
    additional_context_model: Optional[Type[BaseModel]] = None,
    max_tool_rounds: int = 10,
    max_tokens: int = 100000,
    interrupt_before: Optional[List[str]] = None,
    interrupt_after: Optional[List[str]] = None,
    use_prompt_cache: bool = False,
    use_planner: bool = True,
    mcp_langchain_tools: Optional[List[Any]] = None,
) -> CompiledStateGraph:
    """
    Enhanced build_graph with MCP support.

    NEW Parameter:
        mcp_langchain_tools (Optional[List[Any]], default=None):
            Pre-converted LangChain tools from MCP servers.
            These are already LangChain tool objects, not Python Callables.

    All other parameters remain the same as the original build_graph.
    
    Usage::
    
        # Get MCP tools (already LangChain tools)
        mcp_tools = await mcp_client.get_tools()
        
        # Build graph with both Python functions and MCP tools
        graph = build_graph(
            tools=[my_python_function],  # Python Callables
            mcp_langchain_tools=mcp_tools,  # LangChain tools from MCP
            interrupt_before=["delete_user"],  # Works for both!
            ...
        )
    """
    StateClass = create_state_with_context(additional_context_model)

    additional_context_fields = []
    if additional_context_model and hasattr(additional_context_model, "model_fields"):
        additional_context_fields = list(additional_context_model.model_fields.keys())

    
    memory_tool_description = MEMORY_TOOL_REGISTRY_ENTRY["description"]
    # Create a default memory tool (no state/LLM yet — enhanced later
    # in create_tool_node_with_state when the graph is actually running).
    memory_lc_tool = tool(
        name_or_callable=MEMORY_TOOL_NAME,
        description=memory_tool_description,
    )(create_memory_tool())

    langchain_tools = [memory_lc_tool]

    if tools:
        logger.info(f"[GRAPH_BUILD] Converting {len(tools)} Python functions to LangChain tools")
        for func in tools:
            if isinstance(func, BaseTool):
                langchain_tools.append(func)
                logger.info(f"[GRAPH_BUILD] ✓ Added pre-built LangChain tool: {func.name}")
                continue

            tool_name = func.__name__
            safe_tool_name = (
                tool_name[:64] if len(tool_name) <= 64 else tool_name[:61] + "..."
            )

            description = ""
            if tool_descriptions and tool_name in tool_descriptions:
                description = tool_descriptions[tool_name]
            elif func.__doc__:
                description = func.__doc__.strip()

            if tool_arg_schemas and tool_name in tool_arg_schemas:
                arg_schema = tool_arg_schemas[tool_name]
                langchain_tool = tool(
                    name_or_callable=safe_tool_name,
                    description=description,
                    args_schema=arg_schema,
                )(func)
            else:
                langchain_tool = tool(
                    name_or_callable=safe_tool_name,
                    description=description,
                )(func)

            langchain_tools.append(langchain_tool)
            logger.info(f"[GRAPH_BUILD] ✓ Converted Python function: {safe_tool_name}")

    if mcp_langchain_tools:
        logger.info(f"[GRAPH_BUILD] Adding {len(mcp_langchain_tools)} MCP LangChain tools")
        for mcp_tool in mcp_langchain_tools:
            langchain_tools.append(mcp_tool)
            tool_name = mcp_tool.name if hasattr(mcp_tool, 'name') else 'unknown'
            logger.info(f"[GRAPH_BUILD] ✓ Added MCP tool: {tool_name}")
            logger.info(f"[GRAPH_BUILD] Check MCP TOOL: {tool_name} + description: {mcp_tool.description if hasattr(mcp_tool, 'description') else 'No description'}")

    logger.info(f"[GRAPH_BUILD] Total tools: {len(langchain_tools)} (1 memory + {len(tools or [])} Python + {len(mcp_langchain_tools or [])} MCP)")

    tool_skill_registry = build_tool_skill_registry(
        tool_descriptions=tool_descriptions,
        tool_guide=tool_guide,
    )

    sensitive_tool_names = []
    safe_tool_names = []
    
    if (interrupt_before or interrupt_after) and langchain_tools:
        tool_name_list = [t.name for t in langchain_tools]
        
        if interrupt_before:
            for item in interrupt_before:
                if item in tool_name_list and item not in sensitive_tool_names:
                    sensitive_tool_names.append(item)
                    logger.info(f"[TOOL_SEPARATION] Marking tool as sensitive (interrupt_before): {item}")
        
        if interrupt_after:
            for item in interrupt_after:
                if item in tool_name_list and item not in sensitive_tool_names:
                    sensitive_tool_names.append(item)
                    logger.info(f"[TOOL_SEPARATION] Marking tool as sensitive (interrupt_after): {item}")
        
        safe_tool_names = [name for name in tool_name_list if name not in sensitive_tool_names]
        
        if sensitive_tool_names:
            logger.info(f"[TOOL_SEPARATION] Sensitive tools: {sensitive_tool_names}")
        if safe_tool_names:
            logger.info(f"[TOOL_SEPARATION] Safe tools: {safe_tool_names}")
    
    sensitive_tools = [t for t in langchain_tools if t.name in sensitive_tool_names] if langchain_tools else []
    safe_tools = [t for t in langchain_tools if t.name in safe_tool_names] if langchain_tools else []
    
    if not sensitive_tool_names and langchain_tools:
        safe_tools = langchain_tools
    
    workflow = StateGraph(state_schema=StateClass)

    if use_planner:
        workflow.add_node("planner", planner_agent)
    workflow.add_node("agent", call_model)

    def create_tool_node_with_state(tools_list):
        """Factory function to create tool nodes with state access."""
        async def tool_node_with_state(state: AgenticState, config: RunnableConfig):
            """Tool node that provides state access to the memory tool."""
            from langgraph.prebuilt import ToolNode
            from langchain_core.messages import ToolMessage
            from langchain_core.runnables import RunnableLambda

            configurable = safe_get(config, "configurable", {})
            current_llm = safe_get(configurable, "llm") or llm

            def get_state():
                return state

            def get_llm():
                return current_llm

            enhanced_tools = []
            for tool_obj in tools_list:
                if hasattr(tool_obj, "name") and tool_obj.name == MEMORY_TOOL_NAME:
                    from .tools.memory import create_memory_tool

                    memory_tool_func = create_memory_tool(
                        state_getter=get_state, llm_getter=get_llm
                    )
                    enhanced_tool = tool(
                        name_or_callable=MEMORY_TOOL_NAME,
                        description=tool_obj.description,
                    )(memory_tool_func)
                    enhanced_tools.append(enhanced_tool)
                else:
                    enhanced_tools.append(tool_obj)

            logger.info(f"[TOOL_NODE] Creating ToolNode with {len(enhanced_tools)} tools: {[t.name for t in enhanced_tools]}")
            tool_node = ToolNode(enhanced_tools)
            def _tool_fallback(error_state):
                """Create error ToolMessages for ALL pending tool_calls, not just the first."""
                error_msg = f"Error executing tool: {error_state.get('error', 'Unknown error')}"
                messages_list = error_state.get("messages", [])
                tool_calls = []
                if messages_list:
                    last_msg = messages_list[-1]
                    if hasattr(last_msg, "tool_calls") and last_msg.tool_calls:
                        tool_calls = last_msg.tool_calls

                if not tool_calls:
                    return {"messages": [ToolMessage(content=error_msg, tool_call_id="unknown")]}

                return {
                    "messages": [
                        ToolMessage(
                            content=error_msg,
                            tool_call_id=tc.get("id", "unknown") if isinstance(tc, dict) else getattr(tc, "id", "unknown"),
                        )
                        for tc in tool_calls
                    ]
                }

            tool_node_with_fallback = tool_node.with_fallbacks(
                [RunnableLambda(_tool_fallback)],
                exception_key="error",
            )
            messages = state.get('messages', [])
            logger.info(f"[TOOL_NODE] Invoking ToolNode with state containing {len(messages)} messages")
            if messages:
                last_msg = messages[-1]
                if hasattr(last_msg, 'tool_calls'):
                    logger.info(f"[TOOL_NODE] Last message has {len(last_msg.tool_calls)} tool_calls: {last_msg.tool_calls}")
                else:
                    logger.info("[TOOL_NODE] Last message has no tool_calls attribute")
            
            result = await tool_node_with_fallback.ainvoke(state)
            logger.info(f"[TOOL_NODE] ToolNode returned {len(result.get('messages', []))} messages")
            if result.get('messages'):
                for msg in result['messages']:
                    logger.info(f"[TOOL_NODE] Returned message type: {type(msg).__name__}, content preview: {str(msg.content)[:200] if hasattr(msg, 'content') else 'N/A'}")
            return result
        
        return tool_node_with_state

    if sensitive_tools:
        workflow.add_node("sensitive_tools", create_tool_node_with_state(sensitive_tools))
        logger.info(f"[GRAPH_BUILD] Added 'sensitive_tools' node with {len(sensitive_tools)} tools")
    
    if safe_tools:
        workflow.add_node("safe_tools", create_tool_node_with_state(safe_tools))
        logger.info(f"[GRAPH_BUILD] Added 'safe_tools' node with {len(safe_tools)} tools")

    if use_planner:
        workflow.set_entry_point("planner")
        workflow.add_edge("planner", "agent")
    else:
        workflow.set_entry_point("agent")

    if langchain_tools:
        if sensitive_tools and safe_tools:
            workflow.add_conditional_edges(
                "agent",
                should_continue,
                {
                    "sensitive_tools": "sensitive_tools",
                    "safe_tools": "safe_tools",
                    "end": END,
                },
            )
            workflow.add_edge("sensitive_tools", "agent")
            workflow.add_edge("safe_tools", "agent")
            logger.info("[GRAPH_BUILD] Configured edges for both sensitive and safe tools")
        elif sensitive_tools:
            workflow.add_conditional_edges(
                "agent",
                should_continue,
                {
                    "sensitive_tools": "sensitive_tools",
                    "end": END,
                },
            )
            workflow.add_edge("sensitive_tools", "agent")
            logger.info("[GRAPH_BUILD] Configured edges for sensitive tools only")
        elif safe_tools:
            workflow.add_conditional_edges(
                "agent",
                should_continue,
                {
                    "safe_tools": "safe_tools",
                    "end": END,
                },
            )
            workflow.add_edge("safe_tools", "agent")
            logger.info("[GRAPH_BUILD] Configured edges for safe tools only")
    else:
        workflow.add_edge("agent", END)
        logger.info("[GRAPH_BUILD] No tools configured, agent goes directly to END")

    interrupt_before_nodes = ["sensitive_tools"] if sensitive_tools and interrupt_before else None
    interrupt_after_nodes = ["sensitive_tools"] if sensitive_tools and interrupt_after else None
    
    graph = workflow.compile(
        checkpointer=checkpointer,
        interrupt_before=interrupt_before_nodes,
        interrupt_after=interrupt_after_nodes,
    )
    
    if interrupt_before_nodes:
        logger.info(f"[GRAPH_BUILD] Graph compiled with interrupt_before={interrupt_before_nodes}")
    if interrupt_after_nodes:
        logger.info(f"[GRAPH_BUILD] Graph compiled with interrupt_after={interrupt_after_nodes}")

    graph._config = {
        "llm": llm,
        "agent_description": agent_description,
        "tools": langchain_tools,
        "tool_skill_registry": tool_skill_registry,
        "planner_llm": llm,
        "additional_context_fields": additional_context_fields,
        "max_tool_rounds": max_tool_rounds,
        "max_tokens": max_tokens,
        "use_prompt_cache": use_prompt_cache,
        "use_planner": use_planner,
        "sensitive_tool_names": sensitive_tool_names,
        "safe_tool_names": safe_tool_names,
    }

    return graph
