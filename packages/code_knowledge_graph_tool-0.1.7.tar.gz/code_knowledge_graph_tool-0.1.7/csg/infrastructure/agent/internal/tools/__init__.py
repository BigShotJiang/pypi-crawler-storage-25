"""Agent tools for the react agent."""
