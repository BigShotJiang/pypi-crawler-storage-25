﻿"""Agent tools wrapping the layered retrieval Backend class.

Each tool receives `repo_path` via context injection from the agent framework.
All tools use the same Backend as the MCP server (KuzuDB).
"""

from __future__ import annotations

import functools
import json
import logging
import os
import threading

logger = logging.getLogger(__name__)

# Shown when the repo has no LadybugDB index yet - typically because
# the ingestion pipeline hasn't been run or the DB was deleted.
_NO_DB_MSG = (
    "LadybugDB is not available for this repository. "
    "Please re-ingest the repository to enable full search capabilities."
)

# Cache Backend instances per db_path to avoid re-creating LadybugAdapter
# on every tool call.  BackendBase subscribes to KuzuPool events, so cached
# instances are automatically invalidated when the underlying data changes.
_backend_cache: dict[str, object] = {}
_backend_cache_lock = threading.Lock()


def _get_backend(repo_path: str):
    """Return a cached Backend for repo_path, or None if unavailable."""
    if not repo_path:
        return None
    from csg.infrastructure.repository.internal.repo_registry_runtime import get_storage_path
    db_path = str(get_storage_path(repo_path) / "lbug")
    if not os.path.exists(db_path):
        return None

    with _backend_cache_lock:
        if db_path in _backend_cache:
            return _backend_cache[db_path]

    from csg.infrastructure.exploration.backend import Backend
    from csg.infrastructure.graph.lbug_adapter import LadybugAdapter

    adapter = LadybugAdapter(db_path=db_path, repo_source_path=repo_path)
    adapter.connect(read_only=True)
    backend = Backend(adapter)

    with _backend_cache_lock:
        _backend_cache[db_path] = backend

    return backend


def _backend_tool(error_prefix: str):
    """Decorator that handles backend lookup, JSON serialisation, and error logging.

    Eliminates the repeated get-backend / try-except / json.dumps boilerplate
    across every tool function.  The decorated function receives `backend` as
    its first positional arg and should return a JSON-serialisable value.
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, repo_path: str = "", **kwargs):
            backend = _get_backend(repo_path)
            if backend is None:
                return _NO_DB_MSG
            try:
                result = fn(backend, *args, **kwargs)
                if isinstance(result, str):
                    return result
                return json.dumps(result, indent=2, default=str)
            except Exception as e:
                logger.error("%s error: %s", error_prefix, e, exc_info=True)
                return f"{error_prefix} error: {e}"
        return wrapper
    return decorator


@_backend_tool("Explore")
def explore_tool(
    backend,
    query: str = "",
    scope: str = "",
    layer: str = "",
) -> dict | str:
    """Search and explore the codebase through a 6-layer knowledge graph.

    Use layer= to jump directly to any layer. Omit layer for auto mode.

    Args:
        query: Natural language question, or comma-separated symbol names for contract/implementation layers.
        scope: Optional scope: 'community:<name>', 'file:<path>', or 'symbol:<name>'. Required for context layer.
        layer: Run a specific layer: topology, relevance, context, crosscut, contract, implementation. Empty = auto.

    Returns:
        Layer-specific data. Check _meta.depth_reached to see which layer responded.
    """
    return backend.explore_auto(query=query, scope=scope, layer=layer)


def node_detail_tool(selected_node_context: str = "", repo_path: str = "") -> str:
    """Get a comprehensive briefing on a specific code node (selected in the UI).

    Args:
        selected_node_context: JSON string of the selected node (auto-injected from UI context).
        repo_path: Repository path (auto-injected).

    Returns:
        360-degree view of the node: callers, callees, processes, and interface contract.
    """
    if not selected_node_context:
        return "No node is currently selected in the graph UI. Please select a node first."

    try:
        node = json.loads(selected_node_context)
    except json.JSONDecodeError:
        return "Could not parse the selected node context."

    node_label = node.get("label", "")
    node_type = node.get("nodeType", "")
    file_path = node.get("filePath", "")
    start_line = node.get("startLine")
    end_line = node.get("endLine")
    community_id = node.get("communityId")

    basic_info = (
        f"## Selected Node\n"
        f"- **Name**: {node_label}\n"
        f"- **Type**: {node_type}\n"
        f"- **File**: {file_path}\n"
    )
    if start_line is not None:
        basic_info += f"- **Lines**: {start_line}-{end_line}\n"
    if community_id:
        basic_info += f"- **Community**: {community_id}\n"

    backend = _get_backend(repo_path)
    if backend is None:
        return basic_info + f"\n{_NO_DB_MSG}"

    try:
        parts = [basic_info]

        ctx = backend.context_360(node_label)
        if "error" not in ctx:
            sig = ctx.get("signature")
            if sig:
                parts.append(f"\n## Signature\n```\n{sig}\n```")

            callers = ctx.get("callers", [])
            callees = ctx.get("callees", [])
            processes = ctx.get("processes", [])

            parts.append("\n## Relationships")
            if callers:
                parts.append(f"**Incoming ({len(callers)}):**")
                for c in callers[:15]:
                    parts.append(
                        f"  - [{c.get('rel')}] {c.get('name')}"
                        f" ({c.get('kind')}) in {c.get('file', '?')}"
                    )

            if callees:
                parts.append(f"**Outgoing ({len(callees)}):**")
                for c in callees[:15]:
                    parts.append(
                        f"  - [{c.get('rel')}] {c.get('name')}"
                        f" ({c.get('kind')}) in {c.get('file', '?')}"
                    )

            if processes:
                parts.append(f"**Processes ({len(processes)}):**")
                for p in processes:
                    parts.append(f"  - {p.get('name', '?')}")

            heritage = ctx.get("heritage")
            if heritage:
                parts.append(
                    f"\n**Heritage**: {json.dumps(heritage, default=str)}"
                )
        else:
            parts.append(f"\nSymbol lookup: {ctx['error']}")

        return "\n".join(parts)
    except Exception as e:
        logger.error("node_detail_tool error: %s", e, exc_info=True)
        return basic_info + f"\nError fetching details: {e}"


@_backend_tool("Impact analysis")
def impact_analysis_tool(
    backend,
    target: str,
    direction: str = "upstream",
) -> dict | str:
    """Analyze the blast radius of changing a code symbol.

    Uses adaptive depth - traverses deeper for low-fanIn symbols and
    stops earlier when the affected set is large enough to assess risk.

    Args:
        target: Symbol name to analyze (function, class, method).
        direction: 'upstream' (who calls me) or 'downstream' (what I call).

    Returns:
        Impact report with affected symbols, risk level, and dependency chains.
    """
    result = backend.impact(
        target=target,
        direction=direction,
    )
    if "error" in result:
        return f"Impact analysis error: {result['error']}"
    return result



@_backend_tool("Change detection")
def change_detection_tool(
    backend,
    scope: str = "all",
    base_ref: str = "",
) -> dict | str:
    """Detect code changes via git diff and find affected symbols in the knowledge graph.

    Args:
        scope: What to detect - 'staged', 'unstaged', 'all', or 'compare' (vs base_ref).
        base_ref: Git ref for compare mode (e.g. 'main', 'HEAD~3').

    Returns:
        Changed files, affected symbols, and total counts.
    """
    result = backend.detect_changes(scope=scope, base_ref=base_ref)
    if "error" in result:
        return f"Change detection error: {result['error']}"
    return result


@_backend_tool("Rename")
def graph_rename_tool(
    backend,
    symbol_name: str,
    new_name: str,
    dry_run: bool = True,
) -> dict | str:
    """Graph-aware rename - finds all structural references via call graph edges.

    Uses graph relationships (CALLS, IMPORTS, EXTENDS) to find references,
    not text search. Set dry_run=false to apply the rename.

    Args:
        symbol_name: Current name of the function, class, or method.
        new_name: Proposed new name.
        dry_run: Preview changes without applying (default True).

    Returns:
        Affected files and references found via graph edges.
    """
    result = backend.rename(
        symbol_name=symbol_name,
        new_name=new_name,
        dry_run=dry_run,
    )
    if "error" in result:
        return f"Rename error: {result['error']}"
    return result


