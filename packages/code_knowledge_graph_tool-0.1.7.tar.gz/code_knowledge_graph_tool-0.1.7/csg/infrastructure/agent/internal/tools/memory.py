"""Memory tool for on-demand conversation summarization."""
import json
from typing import Any, Callable, List, Optional

from langchain_core.messages import AIMessage, HumanMessage
from langmem.short_term.summarization import summarize_messages

from ..utils.logger import logger

MEMORY_TOOL_NAME: str = "call_memory_tool"


def safe_get_messages(state: Any) -> List[Any]:
    """Safely get messages from state, supporting both dict-like and attribute access."""
    try:
        if isinstance(state, dict):
            return state.get("messages", [])
        elif hasattr(state, 'get') and callable(getattr(state, 'get')):
            return state.get("messages", [])
        elif hasattr(state, 'messages'):
            messages = getattr(state, 'messages', [])
            if callable(messages):
                messages = messages()
            return messages if isinstance(messages, list) else []
        elif hasattr(state, '__getitem__'):
            return state["messages"]
        else:
            return []
    except (KeyError, AttributeError, TypeError):
        return []


def create_memory_tool(state_getter: Optional[Callable] = None, llm_getter: Optional[Callable] = None) -> Callable:
    """
    Factory function to create a memory tool with access to state and LLM.
    
    Args:
        state_getter: Function that returns current state when called
        llm_getter: Function that returns LLM for summarization when called
        
    Returns:
        call_memory_tool function
    """
    def call_memory_tool(conversation_id: str) -> str:
        """
        Get a summary of the recent conversation history (last 20 messages).
        
        Use this tool when:
        - User asks about past interactions or "what we discussed"
        - User asks for a summary of previous conversation
        - Current user instruction is unclear and needs conversation context
        - You need to understand the conversation flow to provide better responses
        
        Args:
            conversation_id: The unique identifier for the conversation
            
        Returns:
            JSON string containing the conversation summary
        """
        try:
            logger.info(f"call_memory_tool invoked for conversation_id: {conversation_id}")
            
            state = state_getter() if state_getter else None
            llm = llm_getter() if llm_getter else None
            
            if not state or not llm:
                logger.warning("call_memory_tool: State or LLM not available, returning placeholder")
                return json.dumps({
                    "summary": "Memory tool called but state/LLM not available. This is a placeholder response.",
                    "conversation_id": conversation_id
                })
            
            messages = safe_get_messages(state)
            
            if not messages:
                logger.warning(f"call_memory_tool: No messages found for conversation_id={conversation_id}")
                return json.dumps({
                    "summary": "No conversation history available.",
                    "conversation_id": conversation_id
                })
            
            last_20_messages = messages[-20:] if len(messages) > 20 else messages
            
            summary_text = _generate_conversation_summary(last_20_messages, llm)
            
            if summary_text and len(summary_text) > 20:
                result_dict = {
                    "summary": summary_text,
                    "conversation_id": conversation_id,
                    "messages_analyzed": len(last_20_messages),
                    "status": "success",
                    "has_history": True
                }
            else:
                human_msgs = [m for m in last_20_messages if isinstance(m, HumanMessage)]
                ai_msgs = [m for m in last_20_messages if isinstance(m, AIMessage)]
                
                if human_msgs or ai_msgs:
                    summary_parts = []
                    for msg in human_msgs[-3:]:
                        content = str(msg.content)[:100] if hasattr(msg, 'content') else str(msg)[:100]
                        summary_parts.append(f"User: {content}")
                    for msg in ai_msgs[-3:]:
                        content = str(msg.content)[:100] if hasattr(msg, 'content') else str(msg)[:100]
                        summary_parts.append(f"Assistant: {content}")
                    
                    fallback_summary = "\n".join(summary_parts)
                    result_dict = {
                        "summary": fallback_summary,
                        "conversation_id": conversation_id,
                        "messages_analyzed": len(last_20_messages),
                        "status": "success",
                        "has_history": True,
                        "note": "Summary generated from message content"
                    }
                else:
                    result_dict = {
                        "summary": "No conversation history available.",
                        "conversation_id": conversation_id,
                        "messages_analyzed": 0,
                        "status": "no_history",
                        "has_history": False
                    }
            
            return json.dumps(result_dict, indent=2)
            
        except Exception as e:
            logger.error(f"Error in call_memory_tool: {e}", exc_info=True)
            return json.dumps({
                "error": f"Failed to retrieve conversation summary: {str(e)}",
                "conversation_id": conversation_id
            })
    
    return call_memory_tool


def _generate_conversation_summary(messages: List[Any], llm: Any) -> str:
    """
    Internal function to generate conversation summary from messages.
    
    Args:
        messages: List of conversation messages (last 20)
        llm: Language model for summarization
        
    Returns:
        Conversation summary as string
    """
    try:
        messages_for_summary = [
            msg for msg in messages 
            if isinstance(msg, (HumanMessage, AIMessage))
        ]
        
        if not messages_for_summary:
            return "No conversation history available."

        first_human_idx = None
        for i, msg in enumerate(messages_for_summary):
            if isinstance(msg, HumanMessage):
                first_human_idx = i
                break
        
        if first_human_idx is None:
            return "No user messages found in conversation history."
        
        messages_for_summary = messages_for_summary[first_human_idx:]
        
        if not messages_for_summary:
            return "No conversation history available."
        
        summary_result = summarize_messages(
            messages_for_summary,
            running_summary=None,
            model=llm,
            max_tokens=2048,
            max_tokens_before_summary=1024,
            max_summary_tokens=512,
        )
        
        summary_text = ""
        if summary_result:
            if hasattr(summary_result, 'running_summary'):
                running_summary_obj = summary_result.running_summary
                if running_summary_obj and hasattr(running_summary_obj, 'summary'):
                    summary_text = str(running_summary_obj.summary)
                elif running_summary_obj:
                    summary_text = str(running_summary_obj)
            elif hasattr(summary_result, 'summary'):
                summary_text = str(summary_result.summary)
            elif isinstance(summary_result, dict):
                summary_text = summary_result.get('summary', '') or summary_result.get('running_summary', '')
            elif isinstance(summary_result, str):
                summary_text = summary_result
            else:
                summary_text = str(summary_result)
        
        if not summary_text or summary_text.strip() == "":
            human_messages = [msg for msg in messages_for_summary if isinstance(msg, HumanMessage)]
            ai_messages = [msg for msg in messages_for_summary if isinstance(msg, AIMessage)]
            if human_messages or ai_messages:
                summary_parts = []
                if human_messages:
                    summary_parts.append(f"User asked {len(human_messages)} question(s)")
                if ai_messages:
                    summary_parts.append(f"Assistant provided {len(ai_messages)} response(s)")
                summary_text = ". ".join(summary_parts) + "."
            else:
                summary_text = "No summary generated."
        
        return summary_text
        
    except Exception as e:
        logger.error(f"Error generating conversation summary: {e}")
        return f"Error generating summary: {str(e)}"

