import json
from typing import Any, Mapping

from csg.infrastructure.agent.internal.agent_setup import ckg_agent
from csg.infrastructure.agent.internal.utils.logger import logger
from csg.domain.repository_ids import repository_id_from_storage_path


def _resolve_repo_path(repo_id: str | None) -> str | None:
    """Resolve a repo_id (storage dir name) to its filesystem path."""
    if not repo_id:
        return None
    try:
        from csg.infrastructure.repository.internal.repo_registry_runtime import (
            get_storage_path,
            list_registered_repos,
        )

        for entry in list_registered_repos():
            storage_path = get_storage_path(entry.path)
            if repo_id in {entry.name, storage_path.name, repository_id_from_storage_path(storage_path)}:
                return entry.path
    except Exception:
        pass
    return None


def _serialize_selected_node(selected_node: Any) -> str | None:
    """Serialize selected-node context without depending on presentation models."""
    if not selected_node:
        return None
    if hasattr(selected_node, "model_dump_json"):
        return selected_node.model_dump_json()
    if hasattr(selected_node, "model_dump"):
        return json.dumps(selected_node.model_dump())
    if isinstance(selected_node, Mapping):
        return json.dumps(dict(selected_node))
    return None


async def run_agent(
    conversation_id: str,
    user_message: str,
    selected_node: Any = None,
    repo_id: str | None = None,
):
    """Run the CKG agent with optional node context and repo path."""
    logger.info("Received agent request: user_input=%s", user_message)

    repo_path = _resolve_repo_path(repo_id) or ""
    context_kwargs = {}
    serialized_selected_node = _serialize_selected_node(selected_node)
    if serialized_selected_node:
        context_kwargs["selected_node_context"] = serialized_selected_node
    if repo_path:
        context_kwargs["repo_path"] = repo_path

    agent = await ckg_agent()
    result = await agent.invoke(
        user_message=user_message,
        conversation_id=conversation_id,
        **context_kwargs,
    )

    logger.info("Agent result type: %s", type(result))
    logger.info(
        "Agent result keys: %s",
        list(result.keys()) if isinstance(result, dict) else "Not a dict",
    )

    response = result["response"]
    if response:
        logger.info(
            "Response received: length=%s, preview=%s",
            len(response),
            response[:100],
        )
    else:
        logger.warning("Empty response! Full result: %s", result)

    if not response or not response.strip():
        logger.error("No valid response found in agent result")
        response = "I couldn't generate a response. Please try rephrasing your question."

    tool_calls = [
        tc.get("name")
        for tc in result.get("tool_calls", [])
        if isinstance(tc, dict) and tc.get("name")
    ]

    return {
        "response": response,
        "prompt_token": result.get("prompt_token", 0),
        "completion_token": result.get("completion_token", 0),
        "execution_time": result.get("execution_time", 0),
        "tool_calls": tool_calls,
    }


async def stream_agent(
    conversation_id: str,
    user_message: str,
    selected_node: Any = None,
    repo_id: str | None = None,
):
    """Stream the agent response chunk by chunk (SSE-style strings)."""
    logger.info("Received stream request: user_input=%s...", user_message[:80])

    repo_path = _resolve_repo_path(repo_id) or ""
    context_kwargs = {}
    serialized_selected_node = _serialize_selected_node(selected_node)
    if serialized_selected_node:
        context_kwargs["selected_node_context"] = serialized_selected_node
    if repo_path:
        context_kwargs["repo_path"] = repo_path

    agent = await ckg_agent()
    async for chunk in agent.stream(
        conversation_id=conversation_id,
        user_message=user_message,
        **context_kwargs,
    ):
        yield chunk
