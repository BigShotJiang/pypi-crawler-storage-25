"""
 planner prompt and helpers for the react agent.

The planner is a lightweight LLM call with structured output that runs BEFORE
the main agent. It decides:
  - instruction: what the main agent should do (supports multi-part requests)
  - actions:     which tool(s)/skill(s) to activate (list, can be many)

Everything in this file is hardcoded – no user configuration needed.
"""

from typing import Dict, List
from textwrap import dedent
from pydantic import BaseModel, Field, field_validator
from .utils.logger import logger


class PlannerOutput(BaseModel):
    """Structured output returned by the planner LLM node."""

    instruction: str = Field(
        description=(
            "1–3 sentence instruction for the main agent describing exactly what the user "
            "wants and how to handle it. For multi-part requests, break the instruction into "
            "numbered steps (e.g. '1. ... 2. ...'). Be specific: name which tool/skill to "
            "use per step and what to do with the result."
        )
    )
    actions: List[str] = Field(
        description=(
            "List of tool or skill names to activate for this turn. "
            "Use the exact names from the available tools/skills list. "
            "Can contain multiple names when the user asks for several independent things. "
            "Order does not matter – the main agent decides execution order. "
            "Duplicate tool names are automatically removed."
        )
    )

    @field_validator("actions", mode="before")
    @classmethod
    def deduplicate_actions(cls, v):
        """Remove duplicate tool names from actions list while preserving order."""
        if not isinstance(v, list):
            return v
        return list(dict.fromkeys(v))


PLANNER_SYSTEM_PROMPT = """
## Analyze the user's message and decide:
1. What the main agent should do (instruction)
2. Which tools/skills to activate (actions)

## Based one
    - USER_MESSAGE: Current user request
    - CHAT_HISTORY: Previous user messages (oldest first)
    - PREVIOUS_AI_MESSAGES: Recent AI response excerpts
    - AVAILABLE_TOOLS_AND_SKILLS: All available tools/skills with descriptions

## You must return a JSON defined in "PlannerOutput" schema with :
    
    1. "instruction": Write 1-3 specific plans: Break down the user's request infered from "Selection Rules" and "CONTEXT" into clear numbered steps. For each step, specify these three things:
        - WHAT is the response language (e.g. English, Vietnamese, Japanese) based ONLY on the **USER_MESSAGE**
        - Which tools/skills to use 
        - **IMPORTANT**: How the agents should use these tools/skills? (e.g. "Use tool X to get Y, then pass Y to tool Z for further analysis, finally summarize the insights for the user.")
    
    2. "actions": the name of the tools/skills from AVAILABLE_TOOLS_AND_SKILLS that main agent MUST use based on "instruction"
    
## MULTI-TOOL STRATEGY
    In "instruction", specify the execution strategy when multiple tools are needed:
    - **parallel**: tools are independent, results combined afterward (e.g. "Search X and analyze Y at the same time, then summarize both")
    - **sequential**: one tool's output feeds the next (e.g. "First detect changes, then run impact analysis on the critical symbols found")
    - **iterative**: call a tool, evaluate the result, decide next tool (e.g. "Start with relevance layer, if weak signal drill into context layer")

    **Default strategy selection:**
    - Simple lookups ("What is X?", "Where is X?") → single tool, no strategy needed
    - Information gathering with known targets → **parallel**
    - Analytical / exploratory questions ("How does X work?", "What happens if...", "Explain X", "Overview of X", "What should I watch out for?") → **sequential** or **iterative**
    - When in doubt → **sequential** (safer, lets agent adapt based on intermediate results)

    Keep "actions" minimal — list only the 1-2 starting tools. The main agent can call additional tools based on intermediate results.

## SELECTION RULES
    Match user intent to the right tool(s):

    **Code content / search / locate** ("show me the code", "what does X do",
    "where is X?", "find X", "what is X?", "implementation of X", "how does auth work?",
    "explain this code", "find similar code", "conceptually related to X"):
        → actions: ["explore_tool"]
        → instruction: use layer="relevance", query=<user question>. For source code, follow up with layer="implementation", query="<symbol names>".

    **Architecture / overview** ("project structure", "how is this organized?", "overview"):
        → actions: ["explore_tool"]
        → instruction: use layer="topology". Then drill into key communities with layer="context", scope="community:<name>".

    **Relationships / context** ("who calls X?", "what does X call?", "dependencies of X"):
        → actions: ["explore_tool"]
        → instruction: use layer="contract", query="<symbol name>" for callers/callees/signature.

    **Impact / risk** ("what breaks if I change X?", "blast radius of X"):
        → actions: ["impact_analysis_tool"]

    **File review / overall review** ("review file X", "what's in this file", "explain this file"):
        → actions: ["explore_tool"]
        → instruction: use layer="context", scope="file:<path>".

    **Selected node in UI** (ACTIVE_CONTEXT present + "this", "it", "explain it"):
        → actions: ["node_detail_tool"]

    **Git changes** ("what changed?", "diff", "before I commit"):
        → actions: ["change_detection_tool"]

    **Rename** ("rename X to Y", "what would renaming affect?"):
        → actions: ["graph_rename_tool"]
        → instruction: use symbol_name=<current name>, new_name=<new name>. Always preview only.

    **Cross-cutting concerns / shared code** ("shared utilities", "what's used across modules", "cycles", "duplicates"):
        → actions: ["explore_tool"]
        → instruction: use layer="crosscut". Optional query= to narrow.

    **SRS / documentation generation** ("generate SRS", "create requirements document", "export specifications", "document the system"):
        → actions: ["explore_tool", "srs_generation_tool"]
        → instruction: Follow the srs_generation_tool guide. Gather context in 5 sequential batches using explore_tool (topology → crosscut → context per community → relevance for data/rules/actors/errors → contract/implementation for key symbols). Organize gathered context by SRS sections before passing to srs_generation_tool. Output follows IEEE 830 + ISO 29148 hybrid format.

## ACTIVE_CONTEXT
    If ACTIVE_CONTEXT is present, it describes what the user currently has selected in the UI (e.g. a graph node).
    - When the user says "this", "it", "the node", "this function", "explain it" etc. without naming a specific symbol, they are referring to the item in ACTIVE_CONTEXT.
    - If ACTIVE_CONTEXT shows a selected node, include `node_detail_tool` in your actions.

## IMPORTANT NOTES
    - **DEFAULT: Treat every USER_MESSAGE as a fresh, independent request.**
      Always generate NEW instruction and actions based on USER_MESSAGE.
      IGNORE CHAT_HISTORY and PREVIOUS_AI_MESSAGES unless the user EXPLICITLY
      references them (e.g. "like before", "same as above", "regarding what you said").

    - ONLY use CHAT_HISTORY when USER_MESSAGE contains explicit back-references
      such as pronouns referring to prior messages or phrases like "the same X",
      "as I asked before", "continue with", "and also", etc.

"""


def build_planner_user_content(
    current_user_message: str,
    chat_history: str,
    previous_ai_context: str,
    tool_skill_registry: Dict[str, Dict],
    active_context: str = "",
) -> str:
    """
    Assemble the user-turn text sent to the planner LLM.

    Args:
        current_user_message: The latest human message text.
        chat_history: Newline-separated numbered list of earlier user messages.
        previous_ai_context: Short excerpts from previous AI responses.
        tool_skill_registry: Full registry of tools and skills available.
            Each value must have at minimum a "description" key.
        active_context: Summary of active UI context (e.g. selected node).

    Returns:
        Formatted string ready to be wrapped in a HumanMessage.
    """
    registry_lines: List[str] = []
    tools_sent_to_planner = []
    for idx, (name, entry) in enumerate(tool_skill_registry.items(), start=1):
        desc = entry.get("description") or entry.get("guide", "No description provided.")
        registry_lines.append(f"{idx}. **{name}**: {desc[:250]}")
        tools_sent_to_planner.append(name)
        desc_preview = desc[:100].replace('\n', ' ') if desc else "None"
        logger.info(
            f"[PLANNER] Tool '{name}' description (first 100 chars): {desc_preview}..."
        )

    registry_str = "\n".join(registry_lines) if registry_lines else "None"

    logger.info(
        f"[PLANNER] Sending {len(tools_sent_to_planner)} tool descriptions to planner: {tools_sent_to_planner}"
    )

    context_block = ""
    if active_context:
        context_block = f"ACTIVE_CONTEXT:\n{active_context}\n\n"

    return (
        f"USER_MESSAGE:\n{current_user_message}\n\n"
        f"{context_block}"
        f"CHAT_HISTORY:\n{chat_history}\n\n"
        f"PREVIOUS_AI_MESSAGES:\n{previous_ai_context}\n\n"
        f"AVAILABLE_TOOLS_AND_SKILLS:\n{registry_str}"
    )


MEMORY_TOOL_REGISTRY_ENTRY: Dict = {
    "name": "call_memory_tool",
    "description": (
        "Retrieves a summary of the recent conversation history (last 20 messages). "
        "Use when the user asks about past interactions, references earlier parts of the "
        "conversation, or when the current request is ambiguous without prior context."
    ),
    "guide": dedent("""
        **What to pass:**
            - conversation_id: The unique identifier for the conversation (automatically provided)

        **Output format:**
            - The tool returns a JSON string with a "summary" field containing the conversation summary
            - Use the summary to understand context and provide relevant responses
            - If the summary indicates no history, acknowledge this to the user

    """).strip(),
}


def build_selected_descriptions_block(
    actions: List[str],
    tool_skill_registry: Dict[str, Dict],
) -> str:
    """
    Given the planner's chosen actions list and the full registry, return a
    formatted string of only the selected tool/skill guides.

    Tools and skills use the "guide" field (if available) for the main agent,
    falling back to "description" if "guide" is not provided.
    
    The "guide" field contains detailed instructions on:
    - What to pass to the tool
    - How to rephrase the tool output
    - How this tool can be used along with other tools
    
    The tool/skill NAME is always prepended to ensure the agent knows which
    tool it's reading about, even if the user didn't include the name in
    the guide.
    
    Duplicate actions are automatically deduplicated to avoid passing the same
    tool guide multiple times.
    """
    parts: List[str] = []
    seen_actions: set = set()
    guides_sent_to_call_model = []
    for action_name in actions:
        if action_name in seen_actions:
            continue
        seen_actions.add(action_name)
        
        entry = tool_skill_registry.get(action_name)
        if not entry:
            logger.warning(f"[CALL_MODEL] Action '{action_name}' not found in registry, skipping")
            continue
        guide = entry.get("guide", entry.get("description", ""))
        if guide:
            parts.append(f"**Tool/Skill Name: {action_name}**\n\nTool Guide:{guide}")
            guides_sent_to_call_model.append(action_name)
            guide_source = "custom_guide" if entry.get("guide") else "fallback_to_description"
            guide_preview = guide[:150].replace('\n', ' ') if guide else "None"
            logger.info(
                f"[CALL_MODEL] Injecting guide for '{action_name}' (source: {guide_source}, "
                f"length: {len(guide)} chars, preview: {guide_preview}...)"
            )
    
    if guides_sent_to_call_model:
        logger.info(
            f"[CALL_MODEL] Sending {len(guides_sent_to_call_model)} tool guides to call_model: "
            f"{guides_sent_to_call_model}"
        )
    else:
        logger.info(f"[CALL_MODEL] No guides to send for actions: {actions}")
    
    return "\n\n".join(parts)


__all__ = [
    "PlannerOutput",
    "PLANNER_SYSTEM_PROMPT",
    "MEMORY_TOOL_REGISTRY_ENTRY",
    "build_planner_user_content",
    "build_selected_descriptions_block",
]
