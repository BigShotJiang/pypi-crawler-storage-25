"""Create chat models from ChatConfig; dispatch by provider (openai | bedrock)."""

from langchain_openai import ChatOpenAI

from csg.infrastructure.runtime.user_context import get_user_runtime_settings, require_user_openai_api_key


def get_llm():
    settings = get_user_runtime_settings()
    api_key = require_user_openai_api_key()

    if settings.llm_provider != "openai":
        raise ValueError(f"Unsupported LLM provider: {settings.llm_provider}")

    llm = ChatOpenAI(
        model="gpt-5.4-nano",
        api_key=api_key,
        temperature=0,
        max_retries=5,
    )
    return llm
