import json
from textwrap import dedent

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.runnables import RunnableConfig

from .agent_state import AgenticState
from .planner import (
    PLANNER_SYSTEM_PROMPT,
    PlannerOutput,
    build_planner_user_content,
    build_selected_descriptions_block,
)
from .utils.context import inject_context_into_response, safe_get
from .utils.logger import logger
from .utils.messages import (
    create_system_message_with_cache,
    trim_messages_with_remove,
    truncate_ai_messages,
)
from .utils.tokens import extract_text_from_content


def _normalize_tool_call_signature(tool_call: dict) -> str:
    """Build a stable signature for loop-detection across tool calls."""
    name = tool_call.get("name", "")
    args = tool_call.get("args", {}) or {}
    filtered_args = {k: v for k, v in args.items() if k not in ("conversation_id",)}
    return f"{name}:{sorted(filtered_args.items())}"


def _collect_recent_tool_context(messages: list, max_messages: int = 8, max_chars: int = 12000) -> str:
    """Collect recent ToolMessage payloads to seed SRS generation context."""
    recent_tool_messages = [m for m in reversed(messages) if isinstance(m, ToolMessage)][:max_messages]
    chunks = []
    for msg in reversed(recent_tool_messages):
        content = extract_text_from_content(msg.content) if hasattr(msg, "content") else ""
        if content:
            chunks.append(content)
    joined = "\n\n---\n\n".join(chunks)
    return joined[:max_chars]


def _force_srs_after_explore_stop(state: AgenticState, messages: list, last_message) -> bool:
    """Force a handoff to srs_generation_tool when SRS flow is stuck on explore_tool."""
    actions: list = safe_get(state, "actions", []) or []
    if "explore_tool" not in actions or "srs_generation_tool" not in actions:
        return False

    tool_calls = getattr(last_message, "tool_calls", None) or []
    if not tool_calls:
        return False

    first_call = tool_calls[0]
    if not isinstance(first_call, dict) or first_call.get("name") != "explore_tool":
        return False

    forced_context = _collect_recent_tool_context(messages)
    if not forced_context:
        return False

    repo_path = (
        safe_get(state, "repo_path", "")
        or (first_call.get("args", {}) or {}).get("repo_path", "")
    )
    forced_call = {
        "name": "srs_generation_tool",
        "args": {
            "context": forced_context,
            "repo_path": repo_path,
        },
        "id": first_call.get("id", "forced_srs_generation_tool"),
        "type": "tool_call",
    }
    last_message.tool_calls = [forced_call]
    state["force_srs_mode"] = True
    logger.warning(
        "[SHOULD_CONTINUE] Explore loop stop detected in SRS flow. "
        "Forced transition to srs_generation_tool."
    )
    return True


def preserve_state_fields(state: AgenticState, base_result):
    """
    Merge planner output with existing graph state so required fields are never lost.

    How it works:
      - Takes the planner's result (e.g. {"instruction": "...", "actions": [...]})
        and overlays selected fields from the current graph state.
      - conversation_id: always copied from state into result (so the graph keeps
        the session id across nodes).
      - instruction and actions: defaults to empty if missing from result, but
        NEVER restores old values from state. This prevents stale plans from
        a previous turn leaking into the current turn.

    Why:
      LangGraph state updates are merged per-key. The planner node returns only
      instruction and actions. Without this helper, conversation_id would not be
      in the returned dict and could be cleared. This ensures conversation_id
      is always preserved while instruction/actions stay fresh each turn.
    """
    result = base_result.copy() if isinstance(base_result, dict) else base_result

    for field in ["conversation_id", "force_srs_mode"]:
        field_value = safe_get(state, field)
        if field_value is not None:
            result[field] = field_value
    # Always use the planner's output for instruction/actions, even if empty.
    # Never restore old values — that causes stale plans to persist across turns.
    for field in ["instruction", "actions"]:
        if field not in result:
            result[field] = "" if field == "instruction" else []
    return result


def planner_agent(state: AgenticState, config: RunnableConfig):
    """
    Planner layer – always runs before the main agent.

    Uses structured LLM output (PlannerOutput) to decide:
      - instruction : what the main agent should do (supports multi-part requests)
      - actions     : list of tool/skill names to activate this turn

    The full tool/skill registry (all default skills + user tools + memory tool)
    is passed in from config so the planner can pick ANY combination.
    """
    configurable = safe_get(config, "configurable", {})
    planner_llm = safe_get(configurable, "planner_llm")
    use_prompt_cache = safe_get(configurable, "use_prompt_cache", False)
    tool_skill_registry: dict = safe_get(configurable, "tool_skill_registry", {})

    if not planner_llm:
        logger.warning("planner_agent: No planner LLM configured, skipping planning")
        return preserve_state_fields(state, {"instruction": "", "actions": []})

    all_messages = safe_get(state, "messages", [])
    if not all_messages:
        return preserve_state_fields(state, {"instruction": "", "actions": []})

    all_user_messages = [m for m in all_messages if isinstance(m, HumanMessage)]
    if not all_user_messages:
        return preserve_state_fields(state, {"instruction": "", "actions": []})

    latest_user_msg = all_user_messages[-1]
    current_user_message = (extract_text_from_content(latest_user_msg.content) or "").strip()

    try:
        trimmed_messages = trim_messages_with_remove(all_messages)
    except Exception:
        trimmed_messages = all_messages

    user_messages = [m for m in trimmed_messages if isinstance(m, HumanMessage)]
    ai_messages = [m for m in trimmed_messages if isinstance(m, AIMessage)]

    previous_user_messages = user_messages[:-1] if len(user_messages) > 1 else []
    chat_history = (
        "\n".join(
            f"{i + 1}. {extract_text_from_content(msg.content).strip()}" for i, msg in enumerate(previous_user_messages)
        )
        if previous_user_messages
        else "None"
    )

    ai_context_parts = []
    for i, m in enumerate(ai_messages):
        content_text = extract_text_from_content(m.content)
        words = content_text.split()[:20] if content_text else []
        ai_context_parts.append(f"{i + 1}. {' '.join(words)}")
    previous_ai_context = "\n\n".join(ai_context_parts) if ai_context_parts else "None"

    system_message = create_system_message_with_cache(
        PLANNER_SYSTEM_PROMPT,
        use_prompt_cache=use_prompt_cache,
    )

    # Build active context summary for the planner (e.g. selected node)
    active_context = ""
    selected_node_ctx = safe_get(state, "selected_node_context", "")
    if selected_node_ctx:
        try:
            node_data = json.loads(selected_node_ctx) if isinstance(selected_node_ctx, str) else selected_node_ctx
            node_name = node_data.get("label", "unknown")
            node_type = node_data.get("nodeType", "unknown")
            node_file = node_data.get("filePath", "")
            active_context = f"User has selected a node in the graph UI: **{node_name}** ({node_type}) in `{node_file}`"
        except Exception:
            active_context = "User has a node selected in the graph UI."

    user_content = build_planner_user_content(
        current_user_message=current_user_message,
        chat_history=chat_history,
        previous_ai_context=previous_ai_context,
        tool_skill_registry=tool_skill_registry,
        active_context=active_context,
    )
    user_message = HumanMessage(content=user_content)

    try:
        structured_llm = planner_llm.with_structured_output(schema=PlannerOutput)
        result: PlannerOutput = structured_llm.invoke([system_message, user_message])
        instruction = result.instruction or ""
        actions = result.actions or []
    except Exception as e:
        logger.error(f"planner_agent: Structured output failed: {e}", exc_info=True)
        instruction = ""
        actions = []

    logger.info("=" * 80)
    logger.info("PLANNER OUTPUT:")
    logger.info(
        f"User Message: {current_user_message[:200]}..."
        if len(current_user_message) > 200
        else f"User Message: {current_user_message}"
    )
    logger.info(f"Instruction: {instruction}")
    logger.info(f"Actions: {actions}")
    logger.info("=" * 80)

    return preserve_state_fields(state, {"instruction": instruction, "actions": actions})


def call_model(state: AgenticState, config: RunnableConfig):
    """Main ReAct agent – calls the model with the filtered tool/skill guidance."""

    configurable = safe_get(config, "configurable", {})
    agent_description = safe_get(configurable, "agent_description", "You are a helpful AI assistant.")
    tools = safe_get(configurable, "tools", [])
    llm = safe_get(configurable, "llm")
    additional_context_fields = safe_get(configurable, "additional_context_fields", [])
    use_prompt_cache = safe_get(configurable, "use_prompt_cache", False)
    use_planner = safe_get(configurable, "use_planner", True)
    tool_skill_registry: dict = safe_get(configurable, "tool_skill_registry", {})

    if not llm:
        return {"messages": [AIMessage(content="Error: No language model configured.")]}

    all_messages = safe_get(state, "messages", [])
    instruction = safe_get(state, "instruction", "")
    actions: list = safe_get(state, "actions", []) or []
    force_srs_mode = bool(safe_get(state, "force_srs_mode", False))

    if force_srs_mode and "srs_generation_tool" in actions:
        actions = ["srs_generation_tool"]
        logger.warning(
            "[CALL_MODEL] force_srs_mode is active. Restricting actions to srs_generation_tool."
        )

    logger.info(f"[CALL_MODEL] Starting call_model with instruction: '{instruction}', actions: {actions}")

    if not all_messages:
        return {"messages": [AIMessage(content="Hello! I'm your AI Assistant. How can I help you today?")]}

    if use_planner:
        default_guidance = dedent("""

            ## CRITICAL: RESPONSE FORMAT RULES

                **ABSOLUTELY FORBIDDEN - DO NOT INCLUDE IN YOUR RESPONSE:**
                    - NO thinking tags: <thinking>, <reasoning>, <thought>, etc.
                    - NO reasoning blocks or internal process explanations
                    - NO internal monologue or decision-making process
                    **EXAMPLE OF WRONG RESPONSE:**
                        - Correct: "I'll help you create a ticket..." / Wrong: "<thinking>User wants...</thinking>"

            ## EXECUTION FLOW

                1. **Route by action type:**

                    - If "actions" is `out_of_scopes` / `gestures` / `abusive`
                        → No tools call, generate fresh response based on "instruction"

                    - If "actions" include tool names → proceed to step 2.

                2. **Call initial tools based on instruction:**
                    - Use the strategy hint from instruction (parallel / sequential / iterative)
                    - When no hint: parallel if tools are independent, sequential if one feeds another

                3. **After receiving tool results — EVALUATE before acting:**
                    - **Sufficient to answer?** → Synthesize results and respond to the user.
                    - **Results reveal new targets to investigate?** → Call additional tools on those specific items. You may use ANY available tool, not only the ones in "actions".
                    - **Tool returned an error or "not available"?** → Try an alternative tool. If all alternatives fail, respond with what you have.
                    - **Do NOT retry the same tool with the same arguments if it already failed.**

                4. **RESPONSE RULES:**
                    - Follow the tool guides and instruction to rephrase/combine tool outputs into the most logical answer
                    - ALWAYS cite specific symbol names, file paths, and line numbers from tool output
                    - When combining multiple tool results, explicitly connect them — explain how they relate to each other and to the user's question
                    - ALWAYS RESPOND in the language as guided from the instruction and user message, NEVER switch language unless explicitly guided by the instruction or tool description.
        """).strip()
    else:
        default_guidance = dedent("""
            ## CRITICAL: RESPONSE FORMAT RULES
            
                **ABSOLUTELY FORBIDDEN - DO NOT INCLUDE IN YOUR RESPONSE:**
                    - NO thinking tags: <thinking>, <reasoning>, <thought>, etc.
                    - NO reasoning blocks or internal process explanations
                    - NO internal monologue or decision-making process
                    **EXAMPLE OF WRONG RESPONSE:**
                        - Correct: "I'll help you create a ticket..." / Wrong: "<thinking>User wants...</thinking>"
                    - On tool error/no data: report transparently. On poor output: retry with refined input. On valid: respond using tool data.
                    - ALWAYS RESPONSE in the language as guided from the instruction and user message, NEVER switch language unless explicitly guided by the instruction or tool description.
        """).strip()

    static_parts = [dedent(agent_description), default_guidance]
    static_system_content = "\n\n".join(static_parts)
    cached_system_message = create_system_message_with_cache(
        static_system_content,
        use_prompt_cache=use_prompt_cache,
    )

    try:
        trimmed_messages = trim_messages_with_remove(all_messages)
        tool_messages = [m for m in trimmed_messages if isinstance(m, ToolMessage)]
        if tool_messages:
            logger.info(f"call_model: Found {len(tool_messages)} ToolMessage(s) in context")
        trimmed_messages = truncate_ai_messages(trimmed_messages, max_words=10)
    except Exception:
        trimmed_messages = all_messages

    dynamic_parts = []

    if use_planner:
        if actions and tool_skill_registry:
            logger.info(f"[CALL_MODEL] Building guides block for actions: {actions}")
            selected_block = build_selected_descriptions_block(
                actions=actions,
                tool_skill_registry=tool_skill_registry,
            )
            if selected_block:
                dynamic_parts.append(selected_block)
                logger.info(
                    f"[CALL_MODEL] Injected tool guides block for actions: {actions} "
                    f"(block length: {len(selected_block)} chars)"
                )
            else:
                logger.warning(f"[CALL_MODEL] No guide block generated for actions: {actions}")

            # Compact reference for all other tools so agent can discover them mid-reasoning
            _skip_in_other = {"gestures", "out_of_scopes", "abusive", "call_memory_tool"}
            other_tools = [
                f"- **{name}**: {entry.get('description', '')[:150]}"
                for name, entry in tool_skill_registry.items()
                if name not in actions and name not in _skip_in_other and entry.get("description")
            ]
            if other_tools:
                dynamic_parts.append(
                    "## OTHER AVAILABLE TOOLS (use if primary tools are insufficient):\n" + "\n".join(other_tools)
                )
                logger.info(f"[CALL_MODEL] Injected {len(other_tools)} other tool references")
        else:
            if not actions:
                logger.info("[CALL_MODEL] No actions provided, skipping guide injection")
            if not tool_skill_registry:
                logger.warning("[CALL_MODEL] No tool_skill_registry available")

        if instruction:
            dynamic_parts.append(f"## INSTRUCTION:\n{instruction}")

    context_fields_to_show = additional_context_fields or []
    if context_fields_to_show:
        context_info = []
        for field in context_fields_to_show:
            field_value = safe_get(state, field)
            if field_value is not None:
                context_info.append(f"- {field}: {field_value}")
        if context_info:
            dynamic_parts.append("## AVAILABLE CONTEXT:\n" + "\n".join(context_info))

    messages_to_send = trimmed_messages
    if dynamic_parts:
        dynamic_content = "\n\n".join(dynamic_parts)
        dynamic_system_message = SystemMessage(content=dynamic_content)
        messages_to_send = [dynamic_system_message] + messages_to_send

    has_tool_messages = any(isinstance(msg, ToolMessage) for msg in messages_to_send)

    callable_tools = []
    if tools:
        for t in tools:
            try:
                if not hasattr(t, "name") or not t.name:
                    logger.warning(f"Tool missing name attribute, skipping: {t}")
                    continue
                callable_tools.append(t)
            except Exception as tool_check_error:
                logger.error(f"Error validating tool: {tool_check_error}, skipping")

    try:
        if callable_tools:
            model_with_tools = llm.bind_tools(callable_tools)
        else:
            if has_tool_messages:
                messages_to_send = [msg for msg in messages_to_send if not isinstance(msg, ToolMessage)]
            model_with_tools = llm

        try:
            response = model_with_tools.invoke([cached_system_message] + messages_to_send)
        except Exception as invoke_error:
            error_msg = str(invoke_error)
            if any(
                k in error_msg
                for k in [
                    "ToolUse",
                    "ModelErrorException",
                    "ValidationException",
                    "toolResult",
                ]
            ):
                logger.error(f"Bedrock tool use error: {error_msg}")
                fallback_messages = [msg for msg in messages_to_send if not isinstance(msg, ToolMessage)]
                response = llm.invoke([cached_system_message] + fallback_messages)
                return {"messages": [response]}
            else:
                raise

        response = inject_context_into_response(response, state, additional_context_fields, config)

        # Guardrail for SRS workflow:
        # if the model keeps issuing the same explore_tool call in a loop,
        # force a handoff to srs_generation_tool using already collected context.
        if (
            use_planner
            and "explore_tool" in actions
            and "srs_generation_tool" in actions
            and hasattr(response, "tool_calls")
            and response.tool_calls
            and isinstance(response.tool_calls[0], dict)
        ):
            first_call = response.tool_calls[0]
            if first_call.get("name") == "explore_tool":
                previous_ai_tool_calls = [
                    m.tool_calls[0]
                    for m in reversed(trimmed_messages)
                    if isinstance(m, AIMessage) and getattr(m, "tool_calls", None) and isinstance(m.tool_calls[0], dict)
                ][:2]
                current_sig = _normalize_tool_call_signature(first_call)
                previous_sigs = [_normalize_tool_call_signature(tc) for tc in previous_ai_tool_calls]
                if previous_sigs and all(sig == current_sig for sig in previous_sigs):
                    forced_context = _collect_recent_tool_context(trimmed_messages)
                    if forced_context:
                        repo_path = (
                            safe_get(state, "repo_path", "")
                            or (first_call.get("args", {}) or {}).get("repo_path", "")
                        )
                        logger.warning(
                            "[CALL_MODEL] Detected repeated explore_tool loop. "
                            "Forcing transition to srs_generation_tool."
                        )
                        forced_call = {
                            "name": "srs_generation_tool",
                            "args": {
                                "context": forced_context,
                                "repo_path": repo_path,
                            },
                            "id": first_call.get("id", "forced_srs_generation_tool"),
                            "type": "tool_call",
                        }
                        response = AIMessage(content=response.content, tool_calls=[forced_call])

        next_force_srs_mode = force_srs_mode
        if force_srs_mode:
            tool_calls = getattr(response, "tool_calls", None) or []
            if not tool_calls:
                next_force_srs_mode = False
                logger.info("[CALL_MODEL] force_srs_mode cleared after final non-tool response.")

        result = {"messages": [response], "force_srs_mode": next_force_srs_mode}
        # Only preserve conversation_id across turns.
        # instruction/actions are per-turn and should NOT persist to the next turn.
        for field in ["conversation_id", "force_srs_mode"]:
            field_value = safe_get(state, field)
            if field_value is not None:
                result[field] = field_value
        result["force_srs_mode"] = next_force_srs_mode
        return result

    except Exception as e:
        result = {
            "messages": [AIMessage(content=(f"I apologize, but I encountered an error: {e}. Please try again."))],
            "force_srs_mode": False,
        }
        for field in ["conversation_id", "running_summary"]:
            field_value = safe_get(state, field)
            if field_value is not None:
                result[field] = field_value
        return result


def should_continue(state: AgenticState, config: RunnableConfig):
    """Determine whether to route to sensitive_tools, safe_tools, both, or end.

    Returns:
    - "sensitive_tools": Route to sensitive tools node (requires confirmation)
    - "safe_tools": Route to safe tools node (auto-execute)
    - "both": Route to both (sensitive first, then safe)
    - "end": Done with tools, go to end
    """
    messages = safe_get(state, "messages", [])

    if not messages:
        return "end"

    last_message = messages[-1]

    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
        configurable = safe_get(config, "configurable", {})
        max_tool_rounds = safe_get(configurable, "max_tool_rounds", 10)

        tool_rounds = 0
        for msg in reversed(messages):
            if isinstance(msg, ToolMessage):
                tool_rounds += 1
            elif isinstance(msg, HumanMessage):
                break

        if tool_rounds >= max_tool_rounds:
            if _force_srs_after_explore_stop(state, messages, last_message):
                return "safe_tools"
            logger.info(f"[SHOULD_CONTINUE] Max tool rounds ({max_tool_rounds}) reached, ending")
            return "end"

        # Circuit breaker: detect repeated identical tool failures
        recent_tool_msgs = [m for m in reversed(messages) if isinstance(m, ToolMessage)][:4]

        if len(recent_tool_msgs) >= 4:
            contents = [m.content for m in recent_tool_msgs]
            if len(set(contents)) == 1:
                if _force_srs_after_explore_stop(state, messages, last_message):
                    return "safe_tools"
                logger.info(
                    f"[SHOULD_CONTINUE] Circuit breaker: last {len(recent_tool_msgs)} "
                    f"tool messages are identical, ending loop"
                )
                return "end"

        # Circuit breaker: detect repeated identical tool CALLS (same name + args)
        recent_ai_msgs = [m for m in reversed(messages) if isinstance(m, AIMessage) and getattr(m, "tool_calls", None)][
            :3
        ]

        if len(recent_ai_msgs) >= 3:
            call_signatures = []
            for m in recent_ai_msgs:
                tc = m.tool_calls[0]
                name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", "")
                args = tc.get("args", {}) if isinstance(tc, dict) else getattr(tc, "args", {})
                # Exclude injected fields like conversation_id for comparison
                filtered_args = {k: v for k, v in args.items() if k not in ("conversation_id",)}
                call_signatures.append(f"{name}:{sorted(filtered_args.items())}")
            if len(set(call_signatures)) == 1:
                if _force_srs_after_explore_stop(state, messages, last_message):
                    return "safe_tools"
                logger.info(
                    f"[SHOULD_CONTINUE] Circuit breaker: last {len(recent_ai_msgs)} "
                    f"tool calls are identical ({call_signatures[0]}), ending loop"
                )
                return "end"

        sensitive_tool_names = safe_get(configurable, "sensitive_tool_names", [])
        safe_tool_names = safe_get(configurable, "safe_tool_names", [])

        if not sensitive_tool_names and not safe_tool_names:
            logger.info(
                "[SHOULD_CONTINUE] No tool separation configured, using legacy routing → routing to 'safe_tools'"
            )
            logger.info(
                f"[SHOULD_CONTINUE] Tool calls to execute: {[tc.get('name') if isinstance(tc, dict) else getattr(tc, 'name', 'unknown') for tc in last_message.tool_calls]}"
            )
            return "safe_tools"

        has_sensitive = False
        has_safe = False

        for tc in last_message.tool_calls:
            tool_name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", None)
            if tool_name in sensitive_tool_names:
                has_sensitive = True
                logger.info(f"[SHOULD_CONTINUE] Detected sensitive tool call: {tool_name}")
            elif tool_name in safe_tool_names:
                has_safe = True
                logger.info(f"[SHOULD_CONTINUE] Detected safe tool call: {tool_name}")

        if has_sensitive:
            logger.info(f"[SHOULD_CONTINUE] Routing to 'sensitive_tools' (has_safe={has_safe})")
            return "sensitive_tools"
        elif has_safe:
            logger.info("[SHOULD_CONTINUE] Routing to 'safe_tools'")
            return "safe_tools"
        else:
            logger.warning("[SHOULD_CONTINUE] Tool calls present but no matching tools found, ending")
            return "end"

    return "end"
