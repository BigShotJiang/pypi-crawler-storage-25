from textwrap import dedent
from datetime import datetime
from csg.infrastructure.agent.internal.react_agent import create_react_agent
from csg.infrastructure.agent.internal.schemas import (
    CKGAgentContext,
    ExploreRequest,
    NodeDetailRequest,
    ImpactAnalysisRequest,
    ChangeDetectionRequest,
    GraphRenameRequest,
    SRSGenerationRequest,
)
from langgraph.checkpoint.memory import MemorySaver
from .llm import get_llm
from csg.infrastructure.agent.internal.tools.backend_tools import (
    explore_tool,
    node_detail_tool,
    impact_analysis_tool,
    change_detection_tool,
    graph_rename_tool,
)
from csg.infrastructure.agent.internal.srs import srs_generation_tool

SYSTEM_PROMPT = """
    You are a **Code Knowledge Graph Agent**. You navigate codebases using a layered retrieval
    system inspired by HNSW - descending from coarse project topology to fine-grained source
    code, using 3-5% of the tokens a flat dump would require.
    
    - ONLY handler question in this SCOPES
    
    **Today's Date: {today_date}**

    ## AVAILABLE CONTEXT
        - `selected_node_context`: JSON of the node the user selected in the graph UI (if any).
        - `repo_path`: path to the analyzed repository (used by tools internally).

    ## BEHAVIOR
        - Be concise. Narrate which tool/layer you're using and why.
        - On ambiguous questions, start broad and narrow down.
        - On tool errors or empty results, try an alternative before giving up.

    ## RESPONSE FORMAT
        - **ALWAYS cite** specific symbol names, file paths, and line numbers from tool output.
        - When combining multiple tool results, explicitly connect them - explain how outputs relate to each other and to the user's question.
        - For impact analysis results, always include a risk level (LOW / MEDIUM / HIGH / CRITICAL).
        - Structure long answers with markdown headers, bullet lists, or tables as appropriate.
        - Close with a follow-up suggestion: "Would you like to explore this further?" or a specific next-step recommendation.
"""


_agent_instance = None
_checkpointer = MemorySaver()


async def ckg_agent():
    global _agent_instance
    if _agent_instance is not None:
        return _agent_instance

    llm = get_llm()
    today_date = datetime.now().date().strftime("%Y-%m-%d")
    agent_prompt = dedent(SYSTEM_PROMPT).format(today_date=today_date)

    _agent_instance = await create_react_agent(
        checkpointer=_checkpointer,
        llm=llm,
        additional_context_model=CKGAgentContext,
        tools=[
            explore_tool,
            node_detail_tool,
            impact_analysis_tool,
            change_detection_tool,
            graph_rename_tool,
            srs_generation_tool,
        ],
        tool_descriptions={
            "explore_tool": dedent("""
                **PRIMARY TOOL - 6-layer knowledge graph retrieval.**
                Use layer= to jump directly to any layer. Each layer is independent.
                topology -> community map. relevance -> search. context -> execution flows.
                crosscut -> cycles/shared code. contract -> signatures/callers. implementation -> source code.
                Omit layer for auto mode (chains layers by confidence).
            """).strip(),

            "node_detail_tool": dedent("""
                **Selected node inspector.** Full briefing on the node the user selected in the graph UI.
                Use when user asks about a specific node they clicked and selected_node_context is present.
                Returns metadata, signature, callers, callees, processes, and community membership.
            """).strip(),

            "impact_analysis_tool": dedent("""
                **Blast-radius analyzer.** Shows what breaks or is affected if a symbol changes.
                Use for: "What happens if I change X?", "What depends on X?", risk assessment, pre-commit checks.
                For pre-commit workflows: pair with change_detection_tool - detect changes first, then analyze
                impact on each critical symbol. Returns affected symbols by depth, risk level, and processes.
            """).strip(),

            "change_detection_tool": dedent("""
                **Git change detector.** Maps git diff to affected graph symbols.
                Use for: "What changed?", "What's different from main?", "Check before I commit",
                reviewing staged/unstaged changes, comparing branches.
                For pre-commit: use scope="staged", then run impact_analysis_tool on critical symbols found.
            """).strip(),

            "graph_rename_tool": dedent("""
                **Rename preview.** Graph-aware rename using structural edges (CALLS/IMPORTS/EXTENDS), not text search.
                Always dry-run (preview only - no files modified).
                Use for: "Rename X to Y", "What would renaming affect?", previewing rename scope before refactoring.
            """).strip(),

            "srs_generation_tool": dedent("""
                **SRS Document Generator.** Creates a standards-compliant Software Requirements
                Specification (IEEE 830 + ISO 29148 hybrid). Requires context gathered by the
                agent beforehand using explore_tool (layer by layer). Outputs markdown + DOCX
                with fully-dressed use cases, traceable requirement IDs, and business rules.
                Use for: "Generate SRS", "Create requirements document", "Export specifications",
                "Document the system", "Create SRS for this project".
            """).strip(),
        },
        tool_guide={
            "explore_tool": dedent("""
                **6 independent retrieval layers.** Use layer= to call any layer directly.
                You decide the order - jump to L5 for source code, or start at L0 for overview.

                **How to call each layer:**

                    layer="topology"
                        -> No other params needed.
                        -> Returns: communities[] (name, symbolCount, cohesion, topMembers[]), interactions[].
                        -> Use community names from topMembers for follow-up calls.

                    layer="relevance"
                        -> Requires: query=<natural language question>.
                        -> Returns: relevance.communities[] (name, score, hits[{name, label, filePath}]).
                        -> Check _meta.search.signal: "strong" (trust), "moderate" (verify), "weak" (broaden query).
                        -> Use hit names for contract/implementation calls.

                    layer="context"
                        -> Requires: scope="community:<name>" or scope="file:<path>".
                        -> Optional: query= to narrow within the scope.
                        -> Returns: context.processes[] (name, steps[{name, type, filePath}]), context.symbols[] (name, type, filePath, isExported, fanIn).
                        -> Use symbol names for contract/implementation calls.

                    layer="crosscut"
                        -> Optional: query= and/or scope=.
                        -> Returns: crosscut (cycles[], shared_symbols[], duplicates[]).

                    layer="contract"
                        -> Requires: query="symbolA, symbolB" (comma-separated symbol names).
                        -> Returns: contracts.symbols[] (name, signature, returnType, callers[], callees[], heritage).

                    layer="implementation"
                        -> Requires: query="symbolA, symbolB" (comma-separated symbol names).
                        -> Returns: implementation.symbols[] (name, type, filePath, startLine, endLine, content).

                **Auto mode (no layer=):**
                    Omit layer to let the system chain layers by confidence.
                    No args -> topology. query= -> relevance + auto context/contract.
                    scope="community:<name>" -> context + auto contract.
                    scope="symbol:<name>" -> 360 deg view via context_360.

                **Presenting to user:**
                    - Lead with the top community and its relevance score
                    - Show execution flows as numbered steps (from processes[].steps[])
                    - List key symbols with file paths
                    - Note the confidence signal (strong/moderate/weak)
            """).strip(),

            "node_detail_tool": dedent("""
                **How to call:** No input needed - reads selected_node_context automatically.

                **Presenting to user:**
                    - One-line identity: "**`Symbol`** - <kind> in `file:line`".
                    - Signature in a code block.
                    - Callers/callees as `file:line` bullet lists.
                    - Processes the node participates in and its role.
                    - Community membership and cross-community edges.
            """).strip(),

            "impact_analysis_tool": dedent("""
                **How to call:** target=<symbol name>. Optionally set direction ("upstream" or "downstream").

                **Presenting to user:**
                    - Lead with risk level in bold: **Risk: HIGH**.
                    - Affected symbols organized by depth (1=direct, 2=transitive...) as a table or tree.
                    - Affected processes and what could break.
                    - End with a recommendation: safe / needs testing / high risk.
            """).strip(),

            "change_detection_tool": dedent("""
                **How to call:** scope="staged"|"unstaged"|"all"|"compare". For compare: set base_ref.
                **Follow-up:** Run impact_analysis_tool on critical symbols found.

                **Presenting to user:**
                    - Totals first: "**N files changed, M symbols affected**".
                    - Symbols grouped by file with change type (added/modified/deleted).
                    - Highlight high-connectivity symbols - riskiest changes.
                    - Pre-commit -> recommend which symbols need impact analysis.
            """).strip(),

            "graph_rename_tool": dedent("""
                **How to call:** symbol_name=<current>, new_name=<new>.

                **Presenting to user:**
                    - State rename: "`OldName` -> `NewName`".
                    - Affected files with specific lines, grouped by reference type (calls, imports, extends).
                    - Total reference count.
                    - Remind user: **preview only** - no files modified.
            """).strip(),

            "srs_generation_tool": dedent("""
                **SRS Generator - IEEE 830 + ISO 29148 hybrid (8 sections).**

                The output document must contain ALL of:
                  1. Introduction (purpose, scope, glossary)
                  2. Overall Description (product perspective, features summary, user classes, environment)
                  3. Functional Requirements (per feature module: use cases + FR-IDs + business rules)
                  4. External Interface Requirements (UI, hardware, software, communication)
                  5. Non-Functional Requirements (performance, security, reliability, usability)
                  6. Data Requirements (entity model, data dictionary, retention)
                  7. Verification & Validation (methods per requirement, acceptance criteria)
                  8. Appendices (traceability matrix, system messages, glossary)

                **SRS Quality Rules (non-negotiable):**
                  - Every FR uses "The system shall..." with a unique ID (FR-MOD-NN)
                  - Every FR has a priority: Must / Should / Could
                  - Use cases follow Cockburn fully-dressed format:
                    Main Success Scenario (happy path only, numbered steps),
                    Extensions keyed to step numbers (3a, 5b),
                    Business Rules with BR-IDs, Preconditions, Postconditions
                  - ZERO implementation language: no controller, service, handler, function, module names
                  - Use <<TBD: reason>> for anything not derivable from code - do NOT invent

                **How to gather context (sequential batches):**

                  1. explore_tool(layer="topology") -> community names = feature modules
                     explore_tool(layer="crosscut") -> cycles, shared code
                  2. explore_tool(layer="context", scope="community:<name>") per community
                     -> execution flows (use case scenarios), key symbols (FR sources)
                  3. explore_tool(layer="relevance", query="schema model entity data")
                     -> data model for Section 6
                     explore_tool(layer="relevance", query="role user auth permission")
                     -> actors for Section 2.3 and use cases
                  4. explore_tool(layer="relevance", query="validator constraint rule")
                     -> business rules for Section 3.X.4
                     explore_tool(layer="relevance", query="error exception message")
                     -> system messages for Section 8.2
                  5. explore_tool(layer="contract", query="<key symbols>")
                     -> signatures for FR derivation
                     explore_tool(layer="implementation", query="<entry points>")
                     -> source for use case scenarios

                **Before calling srs_generation_tool:**
                  - Reorganize ALL gathered context from a business perspective
                  - Label each piece by target SRS section
                  - Remove code names - describe behavior only

                **After generation:**
                  - "SRS saved to: {path}/srs_{name}.md"
                  - "DOCX: {path}/srs_{name}.docx"
                  - "Draft - requires BA/stakeholder review"
            """).strip(),
        },
        tool_arg_schemas={
            "explore_tool": ExploreRequest,
            "node_detail_tool": NodeDetailRequest,
            "impact_analysis_tool": ImpactAnalysisRequest,
            "change_detection_tool": ChangeDetectionRequest,
            "graph_rename_tool": GraphRenameRequest,
            "srs_generation_tool": SRSGenerationRequest,
        },
        agent_description=agent_prompt,
        max_tool_rounds=20,
        max_tokens=1500,
        use_prompt_cache=False
    )

    return _agent_instance

