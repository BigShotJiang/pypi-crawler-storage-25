"""Agent runtime internals owned by outbound adapters."""

