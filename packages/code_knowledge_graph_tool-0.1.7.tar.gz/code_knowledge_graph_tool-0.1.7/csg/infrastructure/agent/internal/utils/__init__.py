"""Agent utilities — logging, tokens, messages, MCP tools, context."""
