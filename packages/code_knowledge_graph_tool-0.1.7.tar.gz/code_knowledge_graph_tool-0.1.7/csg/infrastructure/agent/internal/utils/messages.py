from langchain_core.messages import AIMessage, ToolMessage, SystemMessage
from langchain_core.messages import trim_messages 
from typing import Any, List, Optional, Dict
from pydantic import BaseModel
from .logger import logger


def extract_text_from_content(content):
    """Extract text from content whether it's a string or list."""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        text_parts = []
        for item in content:
            if isinstance(item, dict):
                if 'text' in item:
                    text_parts.append(str(item['text']))
                elif 'content' in item:
                    text_parts.append(str(item['content']))
            elif isinstance(item, str):
                text_parts.append(item)
        return '\n'.join(text_parts) if text_parts else ""
    else:
        return str(content) if content else ""


def format_message(message):
    """Format a message for display without modifying it too much."""
    if hasattr(message, "content") and message.content:
        return extract_text_from_content(message.content)
    return str(message)


def extract_content_from_response(response):
    """Extract content from various response types."""
    if isinstance(response, AIMessage):
        return extract_text_from_content(response.content)
    elif isinstance(response, dict) and "content" in response:
        return extract_text_from_content(response["content"])
    elif isinstance(response, str):
        return response
    else:
        return extract_text_from_content(response) if response else str(response)


def create_system_message_with_cache(text: str, use_prompt_cache: bool = False) -> SystemMessage:
    """
    Create a SystemMessage with optional prompt caching support.
    
    Args:
        text: The prompt text content
        use_prompt_cache: If True, creates SystemMessage with cachePoint structure for AWS Bedrock prompt caching.
                        If False, creates a simple SystemMessage.
    
    Returns:
        SystemMessage with or without cachePoint structure
    
    Note:
        Prompt caching (cachePoint) is ONLY supported when using AWS Bedrock models.
        Setting use_prompt_cache=True with non-Bedrock models will have no effect.
    """
    if use_prompt_cache:
        return SystemMessage(
            content=[
                {
                    "type": "text",
                    "text": text,
                },
                {
                    "cachePoint": {
                        "type": "default",
                    },
                },
            ]
        )
    else:
        return SystemMessage(content=text)


def truncate_ai_messages(messages: List[Any], max_words: int = 20) -> List[Any]:
    """
    Truncate AIMessage content to first N words to save context.
    
    SAFETY: Only truncates AIMessages that are safe to modify:
    - AIMessages WITHOUT tool_calls (final answers) - safe to truncate
    - AIMessages WITH tool_calls that have been executed (have corresponding ToolMessages) - safe to truncate
    
    Does NOT truncate AIMessages with tool_calls that haven't been executed yet.
    
    Args:
        messages: List of all messages in conversation
        max_words: Maximum number of words to keep from AI responses (default: 20)
        
    Returns:
        List of messages with truncated AIMessage content (only safe ones)
    """
    if not messages:
        return messages
    
    executed_tool_call_ids = set()
    for msg in messages:
        if isinstance(msg, ToolMessage):
            tool_call_id = getattr(msg, "tool_call_id", None)
            if tool_call_id:
                executed_tool_call_ids.add(tool_call_id)
    
    truncated = []
    for msg in messages:
        if isinstance(msg, AIMessage):
            has_tool_calls = hasattr(msg, 'tool_calls') and msg.tool_calls
            
            if has_tool_calls:
                tool_calls = msg.tool_calls
                if callable(tool_calls):
                    tool_calls = tool_calls()
                
                all_executed = True
                for tool_call in tool_calls:
                    tool_call_id = tool_call.get("id") if isinstance(tool_call, dict) else getattr(tool_call, "id", None)
                    if tool_call_id and tool_call_id not in executed_tool_call_ids:
                        all_executed = False
                        break
                
                if all_executed:
                    content = msg.content
                    if isinstance(content, str) and content.strip():
                        words = content.split()
                        if len(words) > max_words:
                            truncated_content = ' '.join(words[:max_words]) + "..."
                            truncated_msg = AIMessage(content=truncated_content)
                            truncated_msg.tool_calls = msg.tool_calls
                            if hasattr(msg, 'id'):
                                truncated_msg.id = msg.id
                            truncated.append(truncated_msg)
                        else:
                            truncated.append(msg)
                    else:
                        truncated.append(msg)
                else:
                    truncated.append(msg)
            else:
                content = msg.content
                if isinstance(content, str) and content.strip():
                    words = content.split()
                    if len(words) > max_words:
                        truncated_content = ' '.join(words[:max_words]) + "..."
                        truncated_msg = AIMessage(content=truncated_content)
                        if hasattr(msg, 'id'):
                            truncated_msg.id = msg.id
                        truncated.append(truncated_msg)
                    else:
                        truncated.append(msg)
                else:
                    truncated.append(msg)
        else:
            truncated.append(msg)
    
    return truncated


def trim_messages_with_remove(messages: List[Any]) -> List[Any]:
    """Keep only the last few messages to fit context window using LangChain's trim_messages.
    
    Uses LangChain's built-in trim_messages function which properly handles:
    - Maintaining valid chat history (starts with HumanMessage)
    - Preserving SystemMessage if present
    - Keeping AIMessage + ToolMessage pairs intact (prevents Bedrock ValidationException)
    
    Reference: https://reference.langchain.com/v0.3/python/core/messages/langchain_core.messages.utils.trim_messages.html
    """
    if len(messages) <= 3:
        return messages
    
    try:
        trimmed = trim_messages(
            messages,
            max_tokens=6,
            token_counter=len,
            strategy="last",
            start_on="human",
            end_on=("human", "tool"),
            include_system=True,
            allow_partial=False,
        )
        
        return _ensure_tool_call_integrity(trimmed, messages)

    except Exception as e:
        logger.warning(f"Error using langchain trim_messages, falling back to keeping all messages: {e}")
        return messages


def _ensure_tool_call_integrity(trimmed: List[Any], original: List[Any]) -> List[Any]:
    """Ensure every AIMessage with tool_calls has ALL its ToolMessage responses present.

    When the LLM calls multiple tools in parallel (tool_calls list > 1), trimming can
    remove some ToolMessages while keeping the AIMessage, causing an API 400 error
    ("tool_call_id did not have response messages"). This function repairs that by
    re-inserting missing ToolMessages from the original history.
    """
    original_tool_messages: dict = {}
    for msg in original:
        if isinstance(msg, ToolMessage) and hasattr(msg, "tool_call_id"):
            original_tool_messages[msg.tool_call_id] = msg

    trimmed_tool_ids = {
        msg.tool_call_id
        for msg in trimmed
        if isinstance(msg, ToolMessage) and hasattr(msg, "tool_call_id")
    }

    result = []
    for msg in trimmed:
        result.append(msg)
        if isinstance(msg, AIMessage) and getattr(msg, "tool_calls", None):
            for tc in msg.tool_calls:
                tc_id = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", None)
                if tc_id and tc_id not in trimmed_tool_ids and tc_id in original_tool_messages:
                    result.append(original_tool_messages[tc_id])
                    trimmed_tool_ids.add(tc_id)
                    logger.info(f"[TRIM_INTEGRITY] Re-inserted missing ToolMessage for tool_call_id={tc_id}")

    return result


class ChunkMessage(BaseModel):
    response: Optional[str] = ""
    tool_calls: Optional[List[Dict[str, Any]]] = None
    prompt_token: Optional[int] = None
    completion_token: Optional[int] = None
    time_process: Optional[int] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    execution_time: Optional[int] = None
