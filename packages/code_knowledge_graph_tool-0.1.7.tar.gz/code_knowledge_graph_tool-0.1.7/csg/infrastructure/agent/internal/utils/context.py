"""Context injection utilities for ReAct agent.

This module provides helper functions for injecting context fields (like time_zone,
time_range_info, conversation_id) into tool calls after LLM responses.
"""
from typing import Any, List, Optional
from langchain_core.runnables import RunnableConfig
from ..agent_state import AgenticState
from .logger import logger


def safe_get(obj: Any, key: str, default: Any = None) -> Any:
    """Safely get a value from an object, supporting both dict-like and attribute access.
    
    Also handles LangGraph state objects which may have a 'values' attribute.
    """
    try:
        if isinstance(obj, dict):
            return obj.get(key, default)
        elif hasattr(obj, 'get') and callable(getattr(obj, 'get')):
            return obj.get(key, default)
        elif hasattr(obj, key):
            return getattr(obj, key, default)
        elif hasattr(obj, '__getitem__'):
            return obj[key]
        
        if hasattr(obj, 'values'):
            values = getattr(obj, 'values')
            if isinstance(values, dict):
                return values.get(key, default)
            elif hasattr(values, 'get') and callable(getattr(values, 'get')):
                return values.get(key, default)
            elif hasattr(values, key):
                return getattr(values, key, default)
        
        return default
    except (KeyError, AttributeError, TypeError):
        return default


def inject_context_into_response(
    response: Any, 
    state: AgenticState, 
    additional_context_fields: Optional[List[str]] = None, 
    config: Optional[RunnableConfig] = None
) -> Any:
    """Inject context fields directly into the response's tool calls after LLM invocation.
    
    This is called immediately after the LLM returns a response, ensuring context is injected
    before the response is returned from the node.
    
    Args:
        response: The AIMessage response from the LLM
        state: Current agent state containing context values
        additional_context_fields: Optional list of field names to inject
        config: Optional config for getting conversation_id from thread_id
        
    Returns:
        Modified response with injected context in tool calls
    """
    if not hasattr(response, 'tool_calls') or not response.tool_calls:
        return response
    
    conversation_id = safe_get(state, "conversation_id")
    if not conversation_id and config:
        configurable = safe_get(config, "configurable", {})
        conversation_id = safe_get(configurable, "thread_id")
    
    configurable = safe_get(config, "configurable", {}) if config else {}
    context_values = {}
    
    if additional_context_fields:
        for field in additional_context_fields:
            field_value = safe_get(configurable, field)
            if field_value is None:
                field_value = safe_get(state, field)
            if field_value is not None:
                context_values[field] = field_value
    
    for tool_call in response.tool_calls:
        if isinstance(tool_call, dict):
            args = tool_call.get('args', {})
            tool_name = tool_call.get('name', 'unknown')
        else:
            args = getattr(tool_call, 'args', {})
            tool_name = getattr(tool_call, 'name', 'unknown')
        
        if not isinstance(args, dict):
            logger.warning(f"[INJECT_CONTEXT] Tool call '{tool_name}' has non-dict args, skipping")
            continue
        
        if conversation_id:
            args['conversation_id'] = conversation_id
        
        for field, value in context_values.items():
            args[field] = value
        
        if isinstance(tool_call, dict):
            tool_call['args'] = args
        else:
            try:
                if hasattr(tool_call, 'args'):
                    if hasattr(tool_call.args, 'update') and callable(tool_call.args.update):
                        tool_call.args.update(args)
                    else:
                        tool_call.args = args
            except Exception as e:
                logger.warning(f"[INJECT_CONTEXT] Could not update args for tool '{tool_name}': {e}")
    
    return response

