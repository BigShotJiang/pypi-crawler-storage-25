"""Unified agent logger — file + console output."""

import os
import sys
import logging
from datetime import datetime

logs_dir = os.path.join(os.path.dirname(__file__), "..", "logs")
try:
    os.makedirs(logs_dir, exist_ok=True)
except Exception:
    pass

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_filename = f"running_logs_{timestamp}.log"
log_filepath = os.path.abspath(os.path.join(logs_dir, log_filename))

logger = logging.getLogger("csg.agent")
logger.setLevel(logging.INFO)

if not logger.handlers:
    _fmt = logging.Formatter("[%(asctime)s] %(levelname)s [%(name)s]: %(message)s")
    try:
        file_handler = logging.FileHandler(log_filepath, encoding="utf-8")
        file_handler.setFormatter(_fmt)
        logger.addHandler(file_handler)
    except Exception:
        pass  # file logging optional

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(_fmt)
    logger.addHandler(stream_handler)
