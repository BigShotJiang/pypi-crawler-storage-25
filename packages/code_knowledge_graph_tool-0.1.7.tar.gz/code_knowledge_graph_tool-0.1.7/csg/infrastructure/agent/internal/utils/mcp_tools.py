from langchain_mcp_adapters.client import MultiServerMCPClient

from typing import  Dict, Any, List, Tuple
from .logger import logger


async def fetch_mcp_tools(mcp_configs: List[Dict[str, Any]]) -> Tuple[List, Dict[str, str], Dict[str, str]]:
    """
    Fetch tools from MCP servers and prepare them for the React agent.
    
    Args:
        mcp_configs: List of MCP server configurations
            Example: [
                {"name": "rkc", "url": "https://rkc.com/mcp"},
                {"name": "weather", "url": "http://localhost:8000/mcp"}
            ]
    
    Returns:
        Tuple of:
        - List of MCP tools (LangChain compatible)
        - Dict of tool descriptions (for planner)
        - Dict of tool names to server names (for tracking)
    """
    if not mcp_configs:
        return [], {}, {}
    
    server_config = {}
    for config in mcp_configs:
        name = config.get("name", f"mcp_server_{len(server_config)}")
        
        if "url" in config:
            server_config[name] = {
                "transport": "http",
                "url": config["url"]
            }
        elif "command" in config:
            server_config[name] = {
                "transport": "stdio",
                "command": config["command"],
                "args": config.get("args", [])
            }
        else:
            logger.warning(f"[MCP] Invalid config for server '{name}': {config}")
            continue
    
    if not server_config:
        logger.warning("[MCP] No valid server configs provided")
        return [], {}, {}
    
    logger.info(f"[MCP] Connecting to {len(server_config)} MCP server(s): {list(server_config.keys())}")
    
    client = MultiServerMCPClient(server_config)
    mcp_tools = await client.get_tools()
    
    tool_descriptions = {}
    tool_to_server = {}
    
    for tool in mcp_tools:
        tool_name = tool.name
        tool_descriptions[tool_name] = tool.description or f"MCP tool: {tool_name}"
        
        for server_name in server_config.keys():
            if tool_name.startswith(f"{server_name}_"):
                tool_to_server[tool_name] = server_name
                break
        else:
            tool_to_server[tool_name] = "unknown"
        
        logger.info(f"[MCP] ✓ Loaded tool: {tool_name} (from {tool_to_server[tool_name]})")
    
    logger.info(f"[MCP] Successfully loaded {len(mcp_tools)} tools from MCP servers")
    
    return mcp_tools, tool_descriptions, tool_to_server


def extract_mcp_tool_names(mcp_tools: List) -> List[str]:
    """
    Extract tool names from MCP tools list.
    
    Args:
        mcp_tools: List of MCP tools
    
    Returns:
        List of tool names as strings
    """
    return [tool.name for tool in mcp_tools if hasattr(tool, 'name')]

