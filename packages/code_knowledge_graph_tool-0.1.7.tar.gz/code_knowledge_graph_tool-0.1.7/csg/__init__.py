"""CSG — Code Structure with Graph."""

__version__ = "0.1.0"
