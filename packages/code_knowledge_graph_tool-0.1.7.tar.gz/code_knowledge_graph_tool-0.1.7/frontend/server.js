const http = require("http");
const fs = require("fs");
const path = require("path");

const DIST = path.join(__dirname, "dist");
const BACKEND = process.env.BACKEND_URL || "http://backend:8080";
const PORT = 4173;

const MIME = {
  ".html": "text/html",
  ".js": "application/javascript",
  ".css": "text/css",
  ".json": "application/json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
};

function proxy(req, res) {
  const url = new URL(BACKEND + req.url);
  const opts = {
    hostname: url.hostname,
    port: url.port,
    path: url.pathname + url.search,
    method: req.method,
    headers: { ...req.headers, host: url.host },
  };
  const proxyReq = http.request(opts, (proxyRes) => {
    res.writeHead(proxyRes.statusCode, proxyRes.headers);
    proxyRes.pipe(res, { end: true });
  });
  proxyReq.on("error", () => {
    res.writeHead(502);
    res.end("Backend unavailable");
  });
  req.pipe(proxyReq, { end: true });
}

function serveStatic(req, res) {
  let filePath = path.join(DIST, req.url === "/" ? "index.html" : req.url);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    // SPA fallback
    filePath = path.join(DIST, "index.html");
  }
  const ext = path.extname(filePath);
  const contentType = MIME[ext] || "application/octet-stream";
  const stream = fs.createReadStream(filePath);
  res.writeHead(200, { "Content-Type": contentType });
  stream.pipe(res);
  stream.on("error", () => {
    res.writeHead(404);
    res.end("Not found");
  });
}

http
  .createServer((req, res) => {
    if (req.url.startsWith("/api") || req.url.startsWith("/v1")) {
      proxy(req, res);
    } else {
      serveStatic(req, res);
    }
  })
  .listen(PORT, "0.0.0.0", () => {
    console.log(`Frontend listening on :${PORT}, proxying API to ${BACKEND}`);
  });
