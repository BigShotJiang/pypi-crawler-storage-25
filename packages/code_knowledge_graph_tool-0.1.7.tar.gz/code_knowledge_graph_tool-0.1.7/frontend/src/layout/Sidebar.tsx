import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  FolderGit2,
  KeyRound,
  Settings,
  LogOut,
  Network,
  BookOpen,
  Puzzle,
  Terminal,
  ChevronsLeft,
  ChevronsRight,
  X,
} from "lucide-react";
import clsx from "clsx";
import { useAuth } from "../context/AuthContext";

const NAV_ITEMS = [
  { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/graph", icon: Network, label: "Graph Explorer" },
  { to: "/repositories", icon: FolderGit2, label: "Repositories" },
  { to: "/api-keys", icon: KeyRound, label: "API Keys" },
  { to: "/extensions", icon: Puzzle, label: "Extensions" },
  { to: "/cli-guide", icon: Terminal, label: "CLI Guide" },
  { to: "/install", icon: BookOpen, label: "Documentation" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

interface Props {
  collapsed: boolean;
  mobileOpen: boolean;
  onToggleCollapse: () => void;
  onCloseMobile: () => void;
}

export default function Sidebar({ collapsed, mobileOpen, onToggleCollapse, onCloseMobile }: Props) {
  const navigate = useNavigate();
  const { logout } = useAuth();

  const sidebarContent = (
    <>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div
          className={clsx("flex items-center gap-3 px-3 py-2 cursor-pointer group", collapsed && "justify-center px-0")}
          onClick={() => navigate("/")}
        >
          <div className="border border-brand/50 bg-brand/10 rounded px-2 py-1 transition-all group-hover:shadow-[0_0_12px_rgba(0,229,153,0.25)] shrink-0">
            <span className="text-brand font-mono text-xs font-bold tracking-widest">CKG</span>
          </div>
          {!collapsed && (
            <span className="text-white font-semibold text-sm tracking-tight">Code Knowledge Graph</span>
          )}
        </div>
        {/* Mobile close button */}
        <button
          onClick={onCloseMobile}
          className="md:hidden text-muted hover:text-text p-1"
          aria-label="Close menu"
        >
          <X size={18} />
        </button>
      </div>

      {!collapsed && <p className="px-3 text-[10px] font-mono uppercase tracking-widest text-muted/60 mb-1">Menu</p>}

      <nav className="flex flex-col gap-0.5 flex-1">
        {NAV_ITEMS.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            onClick={onCloseMobile}
            className={({ isActive }) =>
              clsx(
                "relative flex items-center gap-3 rounded-xl text-sm transition-all duration-200",
                collapsed ? "justify-center px-2 py-2.5" : "px-3 py-2.5",
                isActive
                  ? "bg-accent/10 text-accent font-medium shadow-[0_0_20px_rgba(0,229,153,0.08)]"
                  : "text-muted hover:text-text hover:bg-white/[0.03]",
              )
            }
            title={collapsed ? label : undefined}
          >
            {({ isActive }) => (
              <>
                {isActive && <span className="absolute left-0 top-2 bottom-2 w-[3px] bg-brand rounded-full" />}
                <Icon size={18} className={isActive ? "text-accent" : ""} />
                {!collapsed && <span>{label}</span>}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="h-px bg-border/50 mx-2 my-1" />

      {/* Collapse toggle — desktop only */}
      <button
        onClick={onToggleCollapse}
        className="hidden md:flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-muted hover:text-text hover:bg-white/[0.03] transition-all duration-200"
        title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {collapsed ? <ChevronsRight size={18} /> : <ChevronsLeft size={18} />}
        {!collapsed && <span>Collapse</span>}
      </button>

      <button
        onClick={async () => {
          await logout();
          navigate("/login", { replace: true });
        }}
        className={clsx(
          "flex items-center gap-3 rounded-xl text-sm text-muted hover:text-red-400 hover:bg-red-400/5 transition-all duration-200",
          collapsed ? "justify-center px-2 py-2.5" : "px-3 py-2.5",
        )}
        title={collapsed ? "Sign Out" : undefined}
      >
        <LogOut size={18} />
        {!collapsed && <span>Sign Out</span>}
      </button>
    </>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={clsx(
          "hidden md:flex flex-col shrink-0 rounded-2xl border border-border bg-surface/80 backdrop-blur-md h-full py-5 px-3 gap-1 transition-[width] duration-300 ease-in-out overflow-hidden",
          collapsed ? "w-[68px]" : "w-[240px]",
        )}
      >
        {sidebarContent}
      </aside>

      {/* Mobile sidebar (drawer) */}
      <aside
        className={clsx(
          "md:hidden fixed inset-y-0 left-0 z-50 flex flex-col w-[280px] bg-surface border-r border-border py-5 px-3 gap-1 transition-transform duration-300 ease-in-out",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        {sidebarContent}
      </aside>
    </>
  );
}
