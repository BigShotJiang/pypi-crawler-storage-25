import { useLocation } from "react-router-dom";
import { LayoutDashboard, Network, FolderGit2, KeyRound, BookOpen, Settings, Menu } from "lucide-react";
import { useDashboardStats } from "../hooks/useDashboardStats";
import Breadcrumb from "../components/ui/Breadcrumb";

const PAGE_META: Record<string, { title: string; subtitle: string; icon: typeof LayoutDashboard; crumbs: { label: string; to?: string }[] }> = {
  "/dashboard": { title: "Dashboard", subtitle: "Overview", icon: LayoutDashboard, crumbs: [{ label: "Dashboard" }] },
  "/graph": { title: "Graph Explorer", subtitle: "Knowledge Graphs", icon: Network, crumbs: [{ label: "Dashboard", to: "/dashboard" }, { label: "Graph Explorer" }] },
  "/repositories": { title: "Repositories", subtitle: "Codebase Manager", icon: FolderGit2, crumbs: [{ label: "Dashboard", to: "/dashboard" }, { label: "Repositories" }] },
  "/api-keys": { title: "API Keys", subtitle: "API Access", icon: KeyRound, crumbs: [{ label: "Dashboard", to: "/dashboard" }, { label: "API Keys" }] },
  "/install": { title: "Documentation", subtitle: "Integration Guide", icon: BookOpen, crumbs: [{ label: "Dashboard", to: "/dashboard" }, { label: "Documentation" }] },
  "/settings": { title: "Settings", subtitle: "Configuration", icon: Settings, crumbs: [{ label: "Dashboard", to: "/dashboard" }, { label: "Settings" }] },
};

interface Props {
  onMenuToggle?: () => void;
}

export default function TopBar({ onMenuToggle }: Props) {
  const location = useLocation();
  const { stats } = useDashboardStats();
  const meta = PAGE_META[location.pathname] ?? { title: "Dashboard", subtitle: "Overview", icon: LayoutDashboard, crumbs: [{ label: "Dashboard" }] };
  const Icon = meta.icon;

  return (
    <div className="sticky top-0 z-20 border-b border-white/[0.06] bg-surface/60 backdrop-blur-xl">
      <div className="flex items-center justify-between px-4 md:px-8 py-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onMenuToggle}
            className="md:hidden text-muted hover:text-text transition-colors p-1"
            aria-label="Open menu"
          >
            <Menu size={20} />
          </button>

          <div className="w-8 h-8 rounded-lg bg-accent/10 border border-accent/20 flex items-center justify-center">
            <Icon size={15} className="text-accent" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-semibold text-text leading-tight">{meta.title}</h1>
              <div className="hidden md:block">
                <Breadcrumb items={meta.crumbs} />
              </div>
            </div>
            <p className="text-[11px] text-muted font-mono hidden sm:block">{meta.subtitle}</p>
          </div>
        </div>
        <div className="hidden lg:flex items-center gap-3">
          {stats && (
            <div className="flex items-center gap-4 text-xs text-muted">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                {stats.total_repos ?? 0} repos
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                {stats.total_nodes?.toLocaleString() ?? 0} nodes
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
