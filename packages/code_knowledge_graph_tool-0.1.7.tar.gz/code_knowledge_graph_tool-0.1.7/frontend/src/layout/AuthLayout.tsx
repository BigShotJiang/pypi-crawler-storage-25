import type { ReactNode } from "react";
import { useNavigate } from "react-router-dom";

export default function AuthLayout({ children }: { children: ReactNode }) {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen flex items-center justify-center px-4" style={{ background: "#050A0F" }}>
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: [
            "radial-gradient(ellipse 80% 50% at 50% 30%, rgba(0,229,153,0.14) 0%, transparent 70%)",
            "radial-gradient(ellipse 60% 40% at 50% 35%, rgba(0,180,120,0.08) 0%, transparent 60%)",
          ].join(", "),
        }}
      />
      <div className="fixed inset-0 bg-grid pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        <div className="flex items-center justify-center gap-3 mb-8 cursor-pointer" onClick={() => navigate("/")}>
          <div className="border border-[#00E599]/50 bg-[#00E599]/10 rounded px-2 py-1">
            <span className="text-[#00E599] font-mono text-xs font-bold tracking-widest">CKG</span>
          </div>
          <span className="text-white font-semibold tracking-tight">Code Knowledge Graph</span>
        </div>

        <div className="bg-[#0e1f30] border border-[#1a3548] rounded-xl p-8 shadow-2xl shadow-[0_0_60px_rgba(0,229,153,0.06)]">
          {children}
        </div>
      </div>
    </div>
  );
}
