import { useState, useEffect } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { Code2 } from "lucide-react";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import { useIngestion } from "../context/IngestionContext";

const COLLAPSE_KEY = "ckg-sidebar-collapsed";

/** Persistent banner visible from any page while ingestion is active */
function IngestionBanner() {
  const { jobs } = useIngestion();
  const navigate = useNavigate();
  const location = useLocation();

  const activeJobs = jobs.filter(j => j.status === "uploading");
  const isOnReposPage = location.pathname === "/repositories";

  const job = activeJobs[0];
  if (!job || isOnReposPage) return null;

  const progress = Math.min(95, job.messages.length * 8 + 5);
  const lastMsg = job.messages[job.messages.length - 1];

  return (
    <button
      type="button"
      onClick={() => navigate("/repositories")}
      className="relative z-10 mx-4 mt-2 flex items-center gap-3 px-4 py-2.5 rounded-xl border border-blue-500/20 bg-blue-500/5 hover:bg-blue-500/10 transition-colors cursor-pointer text-left"
    >
      <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
        <Code2 size={14} className="text-blue-400" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-semibold text-text truncate">
            {job.name}{activeJobs.length > 1 ? ` (+${activeJobs.length - 1})` : ""}
          </span>
          <span className="flex items-center gap-1 text-[10px] font-medium text-blue-400 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
            Indexing
          </span>
        </div>
        <div className="w-full h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
          <div
            className="h-full rounded-full transition-[width] duration-700 ease-out"
            style={{ width: `${progress}%`, background: "linear-gradient(90deg, #00E599, #38bdf8)" }}
          />
        </div>
        {lastMsg && <p className="text-[10px] text-muted mt-0.5 truncate">{lastMsg.text}</p>}
      </div>
    </button>
  );
}

export default function AppLayout() {
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem(COLLAPSE_KEY) === "true"; } catch { return false; }
  });
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    try { localStorage.setItem(COLLAPSE_KEY, String(collapsed)); } catch {}
  }, [collapsed]);

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileOpen(false);
  }, []);

  return (
    <div
      className="flex h-screen overflow-hidden p-2 md:p-3 gap-2 md:gap-3"
      style={{
        background: "linear-gradient(135deg, #0a1628 0%, #0c2434 50%, #0a2e24 100%)",
      }}
    >
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <Sidebar
        collapsed={collapsed}
        mobileOpen={mobileOpen}
        onToggleCollapse={() => setCollapsed((v) => !v)}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <main className="flex-1 overflow-hidden rounded-2xl relative flex flex-col">
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            background: [
              "radial-gradient(ellipse 80% 50% at 60% 20%, rgba(0,229,153,0.08) 0%, transparent 70%)",
              "radial-gradient(ellipse 100% 60% at 50% 50%, rgba(0,80,60,0.04) 0%, transparent 80%)",
            ].join(", "),
          }}
        />
        <div className="fixed inset-0 bg-grid pointer-events-none opacity-40" />
        <TopBar onMenuToggle={() => setMobileOpen((v) => !v)} />
        <IngestionBanner />
        <div className="relative z-0 flex-1 overflow-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
