import type { AnalysisResult } from "../types";
import SearchBar from "./SearchBar";

interface Props {
  result: AnalysisResult | null;
  showWorkspace: boolean;
  onReset: () => void;
  onFocusNode: (nodeId: string) => void;
}

export default function Header({
  result,
  showWorkspace,
  onReset,
  onFocusNode,
}: Props) {
  return (
    <header className="flex items-center gap-[0.75rem] px-[1rem] py-[0.35rem] border-b border-border bg-surface shrink-0">
      <span
        className="text-[1rem] font-bold"
        style={{
          background: "linear-gradient(135deg, #a855f7, #06b6d4)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}
      >
        CSG
      </span>
      <span className="w-px h-[20px] bg-border" />
      <span className="text-muted text-[0.75rem]">
        Code Structure with Graph
      </span>

      {showWorkspace && result && (
        <>
          <SearchBar
            nodes={result.graph.nodes}
            edges={result.graph.edges}
            filterPassIds={new Set(result.graph.nodes.map((n) => n.id))}
            onSelect={onFocusNode}
            onHighlightNodes={() => {}}
            onHighlightEndpoints={() => {}}
            onClearHighlights={() => {}}
          />
          <span className="text-[0.7rem] text-muted whitespace-nowrap">
            {result.summary.total_nodes} nodes&nbsp;&nbsp;
            {result.summary.total_relationships} edges
          </span>
          <button
            onClick={onReset}
            className="bg-transparent border border-border text-text py-[0.25rem] px-[0.6rem] rounded-[6px] cursor-pointer text-[0.7rem] hover:border-accent"
          >
            New Analysis
          </button>
        </>
      )}
    </header>
  );
}
