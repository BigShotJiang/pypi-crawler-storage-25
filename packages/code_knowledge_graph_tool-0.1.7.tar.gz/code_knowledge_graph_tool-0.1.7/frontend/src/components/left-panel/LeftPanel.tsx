import { useState } from "react";
import type { FileTreeItem, GraphNode, GraphEdge } from "../../types";
import FileTree from "./FileTree";
import NodeFilters from "./NodeFilters";
import EdgeFilters from "./EdgeFilters";
import DepthFilter from "./DepthFilter";

interface Props {
  open: boolean;
  onClose: () => void;
  fileTree: FileTreeItem[];
  graphNodes: GraphNode[];
  graphEdges: GraphEdge[];
  hiddenNodeTypes: Set<string>;
  hiddenEdgeTypes: Set<string>;
  depthFilter: number | null;
  showAll: boolean;
  onToggleNodeType: (type: string) => void;
  onToggleEdgeType: (type: string) => void;
  onSetDepthFilter: (depth: number | null) => void;
  onToggleShowAll: () => void;
  onOpenFile: (path: string) => void;
}

type Tab = "explorer" | "filters";

export default function LeftPanel({
  open,
  onClose,
  fileTree,
  graphNodes,
  graphEdges,
  hiddenNodeTypes,
  hiddenEdgeTypes,
  depthFilter,
  showAll,
  onToggleNodeType,
  onToggleEdgeType,
  onSetDepthFilter,
  onToggleShowAll,
  onOpenFile,
}: Props) {
  const [tab, setTab] = useState<Tab>("explorer");

  return (
    <>
      <button
        onClick={onClose}
        aria-label={open ? "Close file panel" : "Open file panel"}
        className="absolute z-[26] flex items-center justify-center cursor-pointer"
        style={{
          top: "12px",
          left: open ? "292px" : "12px",
          width: "34px",
          height: "34px",
          background: open ? "var(--accent)" : "rgba(22,27,34,0.85)",
          border: `1px solid ${open ? "var(--accent)" : "var(--border)"}`,
          borderRadius: "8px",
          color: open ? "#fff" : "var(--text)",
          fontSize: "1rem",
          backdropFilter: "blur(12px)",
          transition: "left 300ms ease-in-out, background 200ms, border-color 200ms",
        }}
      >
        {open ? "\u2715" : "\u2261"}
      </button>

      <div
        className="absolute top-0 left-0 h-full z-[25] flex flex-col overflow-hidden border-r border-border"
        style={{
          width: "280px",
          background: "rgba(22,27,34,0.92)",
          backdropFilter: "blur(16px)",
          boxShadow: open ? "4px 0 32px rgba(0,0,0,0.4)" : "none",
          transform: open ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 300ms ease-in-out, box-shadow 300ms ease-in-out",
        }}
      >
        <div className="flex items-center px-[0.75rem] py-[0.5rem] border-b border-border shrink-0">
          <span className="text-[0.75rem] font-semibold text-text">Explorer</span>
        </div>

        <div className="flex border-b border-border shrink-0">
          {(["explorer", "filters"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-[0.45rem] text-center text-[0.7rem] uppercase cursor-pointer border-b-2 transition-colors bg-transparent border-x-0 border-t-0 ${
                tab === t
                  ? "text-accent border-accent"
                  : "text-muted border-transparent hover:text-text"
              }`}
              style={{ letterSpacing: "0.04em" }}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-[0.5rem]">
          {tab === "explorer" ? (
            <FileTree items={fileTree} onOpenFile={onOpenFile} />
          ) : (
            <>
              <NodeFilters
                nodes={graphNodes}
                hiddenTypes={hiddenNodeTypes}
                showAll={showAll}
                onToggle={onToggleNodeType}
                onToggleShowAll={onToggleShowAll}
              />
              <EdgeFilters
                edges={graphEdges}
                hiddenTypes={hiddenEdgeTypes}
                onToggle={onToggleEdgeType}
              />
              <DepthFilter value={depthFilter} onChange={onSetDepthFilter} />
            </>
          )}
        </div>
      </div>
    </>
  );
}
