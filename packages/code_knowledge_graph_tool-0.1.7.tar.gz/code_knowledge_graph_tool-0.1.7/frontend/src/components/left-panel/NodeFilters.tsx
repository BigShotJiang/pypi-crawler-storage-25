import { useMemo } from "react";
import { NODE_COLORS } from "../../constants";
import type { GraphNode } from "../../types";

interface Props {
  nodes: GraphNode[];
  hiddenTypes: Set<string>;
  showAll: boolean;
  onToggle: (type: string) => void;
  onToggleShowAll: () => void;
}

export default function NodeFilters({ nodes, hiddenTypes, showAll, onToggle, onToggleShowAll }: Props) {
  const counts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const n of nodes) {
      map[n.nodeType] = (map[n.nodeType] ?? 0) + 1;
    }
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [nodes]);

  return (
    <div className="mb-[1rem]">
      <div className="flex items-center justify-between mb-[0.4rem] px-[0.25rem]">
        <div className="text-[0.7rem] font-semibold text-muted uppercase" style={{ letterSpacing: "0.04em" }}>
          Node Types
        </div>
        <button
          onClick={onToggleShowAll}
          className="text-[0.6rem] px-[0.4rem] py-[0.15rem] rounded-[4px] cursor-pointer border transition-colors"
          style={{
            background: showAll ? "var(--accent)" : "transparent",
            borderColor: showAll ? "var(--accent)" : "var(--border)",
            color: showAll ? "#fff" : "var(--muted)",
          }}
        >
          {showAll ? "Hide Noise" : "Show All"}
        </button>
      </div>
      <div className="text-[0.65rem] text-muted opacity-70 mb-[0.5rem] px-[0.25rem]">
        Toggle visibility of node types
      </div>
      {counts.map(([type, count]) => {
        const hidden = hiddenTypes.has(type);
        return (
          <button
            key={type}
            onClick={() => onToggle(type)}
            className={`flex items-center gap-[0.4rem] w-full py-[0.3rem] px-[0.5rem] rounded-[5px] cursor-pointer text-[0.75rem] transition-[background] duration-150 border-none bg-transparent text-left ${
              hidden ? "text-muted opacity-[0.45]" : "text-text"
            } hover:bg-white/5`}
          >
            <span
              className="w-[10px] h-[10px] rounded-full shrink-0 transition-opacity duration-150"
              style={{ background: NODE_COLORS[type] }}
            />
            <span className="flex-1">{type}</span>
            <span className="text-[0.65rem] text-muted">{count}</span>
            <span
              className="w-[14px] h-[14px] rounded-[3px] flex items-center justify-center text-[0.6rem] shrink-0"
              style={{
                border: `1px solid ${hidden ? "var(--border)" : "var(--accent)"}`,
                background: hidden ? "transparent" : "var(--accent)",
                color: hidden ? "transparent" : "#fff",
              }}
            >
              {hidden ? "" : "\u2713"}
            </span>
          </button>
        );
      })}
    </div>
  );
}
