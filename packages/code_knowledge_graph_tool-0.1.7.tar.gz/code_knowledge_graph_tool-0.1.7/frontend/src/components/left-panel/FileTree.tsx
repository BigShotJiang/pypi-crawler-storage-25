import { useCallback, useMemo, useState } from "react";
import { FILE_COLORS } from "../../constants";
import type { FileTreeItem } from "../../types";

interface Props {
  items: FileTreeItem[];
  onOpenFile: (path: string) => void;
}

export default function FileTree({ items, onOpenFile }: Props) {
  const [filter, setFilter] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(() => {
    const initial = new Set<string>();
    items.forEach((item) => {
      if (item.type === "folder") initial.add(item.path);
    });
    return initial;
  });
  const [selectedPath, setSelectedPath] = useState<string | null>(null);

  const toggleFolder = useCallback((path: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  }, []);

  const handleOpenFile = useCallback(
    (path: string) => {
      setSelectedPath(path);
      onOpenFile(path);
    },
    [onOpenFile],
  );

  return (
    <div>
      <div className="mb-[0.5rem]">
        <input
          type="text"
          placeholder="Search files..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="w-full py-[0.3rem] px-[0.5rem] bg-bg border border-border rounded-[5px] text-text text-[0.75rem] outline-none focus:border-accent"
        />
      </div>
      <TreeItems
        items={items}
        depth={0}
        filter={filter.toLowerCase()}
        expanded={expanded}
        selectedPath={selectedPath}
        onToggleFolder={toggleFolder}
        onOpenFile={handleOpenFile}
      />
    </div>
  );
}

function TreeItems({
  items,
  depth,
  filter,
  expanded,
  selectedPath,
  onToggleFolder,
  onOpenFile,
}: {
  items: FileTreeItem[];
  depth: number;
  filter: string;
  expanded: Set<string>;
  selectedPath: string | null;
  onToggleFolder: (path: string) => void;
  onOpenFile: (path: string) => void;
}) {
  const filtered = useMemo(
    () =>
      items.filter((item) => {
        if (!filter) return true;
        if (item.name.toLowerCase().includes(filter)) return true;
        if (item.children) return hasMatch(item.children, filter);
        return false;
      }),
    [items, filter],
  );

  return (
    <>
      {filtered.map((item) => {
        const isExpanded = expanded.has(item.path);
        const isSelected = selectedPath === item.path;
        const indent = depth * 12;

        if (item.type === "folder") {
          return (
            <div key={item.path}>
              <div
                onClick={() => onToggleFolder(item.path)}
                className="flex items-center gap-[0.3rem] py-[0.2rem] px-[0.3rem] rounded cursor-pointer text-[0.75rem] whitespace-nowrap overflow-hidden hover:bg-hover"
                style={{
                  paddingLeft: `${indent}px`,
                  ...(isSelected
                    ? {
                        background: "rgba(251,191,36,0.12)",
                        borderLeft: "2px solid #fbbf24",
                      }
                    : {}),
                }}
              >
                <span className="shrink-0 text-[0.7rem] w-[14px] text-center" style={{ color: "#6366f1" }}>
                  {isExpanded ? "\u25BE" : "\u25B8"}
                </span>
                <span className="shrink-0 text-[0.7rem]">
                  {isExpanded ? "\uD83D\uDCC2" : "\uD83D\uDCC1"}
                </span>
                <span className="overflow-hidden text-ellipsis">{item.name}</span>
              </div>
              {isExpanded && item.children && (
                <div className="ml-[0.75rem] border-l border-border">
                  <TreeItems
                    items={item.children}
                    depth={depth + 1}
                    filter={filter}
                    expanded={expanded}
                    selectedPath={selectedPath}
                    onToggleFolder={onToggleFolder}
                    onOpenFile={onOpenFile}
                  />
                </div>
              )}
            </div>
          );
        }

        const ext = item.name.split(".").pop() ?? "";
        const fileColor = FILE_COLORS[ext] ?? "#64748b";

        return (
          <div
            key={item.path}
            onClick={() => onOpenFile(item.path)}
            className="flex items-center gap-[0.3rem] py-[0.2rem] px-[0.3rem] rounded cursor-pointer text-[0.75rem] whitespace-nowrap overflow-hidden hover:bg-hover"
            style={{
              paddingLeft: `${indent + 14}px`,
              ...(isSelected
                ? {
                    background: "rgba(251,191,36,0.12)",
                    borderLeft: "2px solid #fbbf24",
                  }
                : {}),
            }}
          >
            <span className="shrink-0 text-[0.7rem]" style={{ color: fileColor }}>
              &#x1F4C4;
            </span>
            <span className="overflow-hidden text-ellipsis">{item.name}</span>
          </div>
        );
      })}
    </>
  );
}

function hasMatch(children: FileTreeItem[], filter: string): boolean {
  for (const c of children) {
    if (c.name.toLowerCase().includes(filter)) return true;
    if (c.children && hasMatch(c.children, filter)) return true;
  }
  return false;
}
