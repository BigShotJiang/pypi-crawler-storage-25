interface Props {
  value: number | null;
  onChange: (depth: number | null) => void;
}

const MIN_DEPTH = 1;
const MAX_DEPTH = 20;

export default function DepthFilter({ value, onChange }: Props) {
  const current = value ?? MIN_DEPTH;

  return (
    <div className="mb-[1rem]">
      <div className="text-[0.7rem] font-semibold text-muted uppercase mb-[0.4rem] px-[0.25rem]" style={{ letterSpacing: "0.04em" }}>
        Focus Depth
      </div>
      <div className="text-[0.65rem] text-muted opacity-70 mb-[0.5rem] px-[0.25rem]">
        Show nodes within N hops of selection
      </div>
      <div className="flex items-center gap-[0.5rem] px-[0.25rem]">
        <span className="text-[0.65rem] text-muted w-[1rem] text-right">{MIN_DEPTH}</span>
        <input
          type="range"
          min={MIN_DEPTH}
          max={MAX_DEPTH}
          value={current}
          onChange={(e) => onChange(Number(e.target.value))}
          className="flex-1 accent-[var(--accent)] cursor-pointer"
          style={{ height: "4px" }}
        />
        <span className="text-[0.65rem] text-muted w-[1.2rem]">{MAX_DEPTH}</span>
      </div>
      <div className="text-center mt-[0.3rem]">
        <span
          className="inline-block text-[0.7rem] font-semibold"
          style={{
            padding: "0.15rem 0.5rem",
            borderRadius: "12px",
            background: "var(--accent)",
            color: "#fff",
          }}
        >
          {current} {current === 1 ? "hop" : "hops"}
        </span>
      </div>
    </div>
  );
}
