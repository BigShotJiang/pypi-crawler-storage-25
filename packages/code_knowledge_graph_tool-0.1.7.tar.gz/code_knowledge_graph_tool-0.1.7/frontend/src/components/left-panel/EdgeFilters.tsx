import { useMemo } from "react";
import { EDGE_COLORS } from "../../constants";
import type { GraphEdge } from "../../types";

interface Props {
  edges: GraphEdge[];
  hiddenTypes: Set<string>;
  onToggle: (type: string) => void;
}

export default function EdgeFilters({ edges, hiddenTypes, onToggle }: Props) {
  const counts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const e of edges) {
      map[e.type] = (map[e.type] ?? 0) + 1;
    }
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [edges]);

  return (
    <div className="mb-[1rem]">
      <div className="text-[0.7rem] font-semibold text-muted uppercase mb-[0.4rem] px-[0.25rem]" style={{ letterSpacing: "0.04em" }}>
        Edge Types
      </div>
      <div className="text-[0.65rem] text-muted opacity-70 mb-[0.5rem] px-[0.25rem]">
        Toggle visibility of relationships
      </div>
      {counts.map(([type, count]) => {
        const hidden = hiddenTypes.has(type);
        return (
          <button
            key={type}
            onClick={() => onToggle(type)}
            className={`flex items-center gap-[0.5rem] w-full py-[0.3rem] px-[0.5rem] rounded-[5px] cursor-pointer text-[0.75rem] transition-[background] duration-150 border-none bg-transparent text-left ${
              hidden ? "text-muted opacity-[0.45]" : "text-text"
            } hover:bg-hover`}
          >
            <span
              className="w-[18px] h-[3px] rounded-[2px] shrink-0"
              style={{ background: EDGE_COLORS[type] ?? "#475569" }}
            />
            <span className="flex-1">{type}</span>
            <span className="text-[0.65rem] text-muted">{count}</span>
          </button>
        );
      })}
    </div>
  );
}
