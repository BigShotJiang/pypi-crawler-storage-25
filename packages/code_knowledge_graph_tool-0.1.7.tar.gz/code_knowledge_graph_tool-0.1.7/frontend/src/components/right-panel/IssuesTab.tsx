import { AlertTriangle, CircleDot, FileText, LocateFixed } from "lucide-react";
import type { AnalysisIssue } from "../../types";

interface Props {
  issues?: AnalysisIssue[];
  onSelectNode: (id: string) => void;
  onOpenFile: (path: string) => void;
}

const SEVERITY_STYLES: Record<AnalysisIssue["severity"], { label: string; color: string; bg: string }> = {
  critical: { label: "Critical", color: "#f87171", bg: "rgba(248,113,113,0.1)" },
  warning: { label: "Warning", color: "#facc15", bg: "rgba(250,204,21,0.1)" },
  info: { label: "Info", color: "#38bdf8", bg: "rgba(56,189,248,0.1)" },
};

export default function IssuesTab({ issues = [], onSelectNode, onOpenFile }: Props) {
  if (issues.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center px-6">
        <CircleDot size={28} className="text-accent mb-3" />
        <p className="text-sm text-text font-medium">No issues found</p>
        <p className="text-xs text-muted mt-1">The current graph has no heuristic quality findings.</p>
      </div>
    );
  }

  const groups = groupIssues(issues);

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        <IssueCount label="Critical" value={countSeverity(issues, "critical")} color="#f87171" />
        <IssueCount label="Warnings" value={countSeverity(issues, "warning")} color="#facc15" />
        <IssueCount label="Info" value={countSeverity(issues, "info")} color="#38bdf8" />
      </div>

      {groups.map(([category, categoryIssues]) => (
        <section key={category}>
          <div className="flex items-center justify-between mb-1.5">
            <h3 className="text-[0.72rem] text-muted font-semibold">{category}</h3>
            <span className="text-[0.65rem] text-muted">{categoryIssues.length}</span>
          </div>
          <div className="space-y-2">
            {categoryIssues.map((issue) => (
              <IssueRow
                key={issue.id}
                issue={issue}
                onSelectNode={onSelectNode}
                onOpenFile={onOpenFile}
              />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

function IssueRow({
  issue,
  onSelectNode,
  onOpenFile,
}: {
  issue: AnalysisIssue;
  onSelectNode: (id: string) => void;
  onOpenFile: (path: string) => void;
}) {
  const style = SEVERITY_STYLES[issue.severity];
  const primaryNodeId = issue.nodeIds[0];

  return (
    <article className="bg-bg border border-border rounded-[6px] p-2">
      <div className="flex items-start gap-2">
        <span
          className="mt-0.5 w-5 h-5 rounded flex items-center justify-center shrink-0"
          style={{ color: style.color, background: style.bg }}
          title={style.label}
        >
          <AlertTriangle size={13} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[0.74rem] text-text font-medium leading-snug break-words">{issue.title}</p>
          <p className="text-[0.68rem] text-muted leading-snug mt-1 break-words">{issue.message}</p>
          {issue.filePath && (
            <p className="text-[0.65rem] text-muted font-mono mt-1 truncate" title={issue.filePath}>
              {issue.filePath}
            </p>
          )}
          <div className="flex items-center gap-1.5 mt-2">
            {primaryNodeId && (
              <button
                type="button"
                onClick={() => onSelectNode(primaryNodeId)}
                className="h-6 px-2 rounded border border-border bg-surface text-muted hover:text-text hover:border-accent transition-colors inline-flex items-center gap-1 text-[0.65rem]"
                title="Focus node"
              >
                <LocateFixed size={12} />
                Node
              </button>
            )}
            {issue.filePath && (
              <button
                type="button"
                onClick={() => onOpenFile(issue.filePath!)}
                className="h-6 px-2 rounded border border-border bg-surface text-muted hover:text-text hover:border-accent transition-colors inline-flex items-center gap-1 text-[0.65rem]"
                title="Open file"
              >
                <FileText size={12} />
                File
              </button>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}

function IssueCount({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="bg-bg border border-border rounded-[6px] p-2 text-center">
      <div className="text-[1.1rem] font-bold" style={{ color }}>
        {value}
      </div>
      <div className="text-[0.58rem] text-muted uppercase">{label}</div>
    </div>
  );
}

function groupIssues(issues: AnalysisIssue[]): Array<[string, AnalysisIssue[]]> {
  const groups = new Map<string, AnalysisIssue[]>();
  for (const issue of issues) {
    groups.set(issue.category, [...(groups.get(issue.category) ?? []), issue]);
  }
  return Array.from(groups.entries()).sort((a, b) => a[0].localeCompare(b[0]));
}

function countSeverity(issues: AnalysisIssue[], severity: AnalysisIssue["severity"]) {
  return issues.filter((issue) => issue.severity === severity).length;
}
