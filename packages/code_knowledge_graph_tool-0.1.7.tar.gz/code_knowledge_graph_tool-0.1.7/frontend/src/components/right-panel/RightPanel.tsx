import { useState } from "react";
import type { AnalysisResult, GraphNode, GraphEdge } from "../../types";
import NodeDetail from "./NodeDetail";
import StatsTab from "./StatsTab";
import FlowsTab from "./FlowsTab";
import IssuesTab from "./IssuesTab";

interface Props {
  open: boolean;
  result: AnalysisResult;
  selectedNode: GraphNode | null;
  graphNodes: GraphNode[];
  graphEdges: GraphEdge[];
  focusedProcessId: string | null;
  onSelectNode: (id: string) => void;
  onOpenFile: (path: string) => void;
  onToggleProcessFocus: (id: string) => void;
  onClose: () => void;
}

type Tab = "details" | "stats" | "flows" | "issues";

export default function RightPanel({
  open,
  result,
  selectedNode,
  graphNodes,
  graphEdges,
  focusedProcessId,
  onSelectNode,
  onOpenFile,
  onToggleProcessFocus,
  onClose,
}: Props) {
  const [tab, setTab] = useState<Tab>("details");

  return (
    <aside
      className="absolute top-0 right-0 h-full z-[25] flex flex-col border-l border-border overflow-hidden"
      style={{
        width: 340,
        background: "rgba(22,27,34,0.95)",
        backdropFilter: "blur(16px)",
        boxShadow: open ? "-4px 0 32px rgba(0,0,0,0.4)" : "none",
        visibility: open ? "visible" : "hidden",
        transform: open ? "translateX(0)" : "translateX(100%)",
        transition: open
          ? "transform 300ms ease-in-out, box-shadow 300ms ease-in-out, visibility 0s"
          : "transform 300ms ease-in-out, box-shadow 300ms ease-in-out, visibility 0s 300ms",
      }}
    >
      <div className="flex items-center justify-between px-[0.75rem] py-[0.5rem] border-b border-border shrink-0">
        <span className="text-[0.75rem] font-semibold text-text">Details</span>
        <button
          onClick={onClose}
          aria-label="Close details panel"
          className="w-6 h-6 rounded flex items-center justify-center hover:bg-white/5 transition-colors"
          style={{ color: "var(--muted)" }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12" /></svg>
        </button>
      </div>

      <div className="flex border-b border-border shrink-0">
        {(["details", "stats", "flows", "issues"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-[0.45rem] text-center text-[0.72rem] cursor-pointer border-b-2 transition-all duration-150 bg-transparent border-x-0 border-t-0 ${
              tab === t
                ? "text-accent border-accent"
                : "text-muted border-transparent hover:text-text"
            }`}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-[0.75rem]">
        {tab === "details" && (
          <NodeDetail
            selectedNode={selectedNode}
            graphNodes={graphNodes}
            graphEdges={graphEdges}
            onSelectNode={onSelectNode}
          />
        )}
        {tab === "stats" && <StatsTab result={result} />}
        {tab === "flows" && (
          <FlowsTab
            processes={result.processes}
            focusedProcessId={focusedProcessId}
            onToggleProcessFocus={onToggleProcessFocus}
          />
        )}
        {tab === "issues" && (
          <IssuesTab
            issues={result.issues}
            onSelectNode={onSelectNode}
            onOpenFile={onOpenFile}
          />
        )}
      </div>
    </aside>
  );
}
