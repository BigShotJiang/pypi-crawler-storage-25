import type { Process } from "../../types";

interface Props {
  processes: Process[];
  focusedProcessId: string | null;
  onToggleProcessFocus: (id: string) => void;
}

export default function FlowsTab({
  processes,
  focusedProcessId,
  onToggleProcessFocus,
}: Props) {
  if (!processes.length) {
    return (
      <p className="text-muted text-[0.8rem]">No execution flows detected</p>
    );
  }

  const cross = processes
    .filter((p) => p.process_type === "cross_community")
    .sort((a, b) => b.step_count - a.step_count);
  const intra = processes
    .filter((p) => p.process_type !== "cross_community")
    .sort((a, b) => b.step_count - a.step_count);

  return (
    <div>
      {cross.length > 0 && (
        <div className="mb-[1rem]">
          <div className="text-[0.7rem] font-semibold uppercase mb-[0.4rem]" style={{ color: "#fbbf24" }}>
            Cross-Community ({cross.length})
          </div>
          {cross.map((p) => (
            <FlowItem
              key={p.id}
              process={p}
              isFocused={focusedProcessId === p.id}
              onToggle={onToggleProcessFocus}
            />
          ))}
        </div>
      )}
      {intra.length > 0 && (
        <div>
          <div className="text-[0.7rem] font-semibold uppercase mb-[0.4rem]" style={{ color: "#34d399" }}>
            Intra-Community ({intra.length})
          </div>
          {intra.map((p) => (
            <FlowItem
              key={p.id}
              process={p}
              isFocused={focusedProcessId === p.id}
              onToggle={onToggleProcessFocus}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function FlowItem({
  process,
  isFocused,
  onToggle,
}: {
  process: Process;
  isFocused: boolean;
  onToggle: (id: string) => void;
}) {
  const typeColor =
    process.process_type === "cross_community" ? "#fbbf24" : "#34d399";

  return (
    <div className="flex items-center gap-[0.4rem] py-[0.4rem] px-[0.3rem] border-b border-border text-[0.75rem]">
      <span style={{ color: typeColor, fontSize: "0.85rem" }}>&#x2B95;</span>
      <div className="flex-1 min-w-0">
        <div className="overflow-hidden text-ellipsis whitespace-nowrap">
          {process.heuristic_label || process.label}
        </div>
        <div className="text-[0.65rem] text-muted">
          {process.step_count} steps
        </div>
      </div>
      <button
        onClick={() => onToggle(process.id)}
        className="shrink-0 cursor-pointer"
        style={{
          fontSize: "0.6rem",
          padding: "0.15rem 0.4rem",
          borderRadius: "6px",
          border: `1px solid ${isFocused ? "#06b6d4" : "var(--border)"}`,
          background: isFocused ? "#06b6d422" : "transparent",
          color: isFocused ? "#06b6d4" : "var(--text)",
        }}
      >
        {isFocused ? "Unfocus" : "Focus"}
      </button>
    </div>
  );
}
