import { useMemo } from "react";
import { NODE_COLORS, EDGE_COLORS } from "../../constants";
import type { GraphNode, GraphEdge, NeighborInfo } from "../../types";

interface Props {
  selectedNode: GraphNode | null;
  graphNodes: GraphNode[];
  graphEdges: GraphEdge[];
  onSelectNode: (id: string) => void;
}

export default function NodeDetail({
  selectedNode,
  graphNodes,
  graphEdges,
  onSelectNode,
}: Props) {
  const { incoming, outgoing } = useMemo(() => {
    if (!selectedNode) return { incoming: [], outgoing: [] };

    const nodeIndex = new Map<string, GraphNode>();
    for (const n of graphNodes) nodeIndex.set(n.id, n);

    const inc: NeighborInfo[] = [];
    const out: NeighborInfo[] = [];

    for (const e of graphEdges) {
      if (e.target === selectedNode.id) {
        const src = nodeIndex.get(e.source);
        if (src)
          inc.push({ id: src.id, label: src.label, type: e.type, nodeType: src.nodeType });
      }
      if (e.source === selectedNode.id) {
        const tgt = nodeIndex.get(e.target);
        if (tgt)
          out.push({ id: tgt.id, label: tgt.label, type: e.type, nodeType: tgt.nodeType });
      }
    }

    return { incoming: inc, outgoing: out };
  }, [selectedNode, graphNodes, graphEdges]);

  if (!selectedNode) {
    return (
      <p className="text-muted text-[0.8rem]">
        Click a node in the graph to see details
      </p>
    );
  }

  const color = NODE_COLORS[selectedNode.nodeType] ?? "#94a3b8";

  return (
    <div className="bg-bg border border-border rounded-[6px] p-[0.75rem] mb-[0.75rem]">
      <h3 className="text-[0.85rem] mb-[0.3rem] font-mono">
        {selectedNode.label}
      </h3>
      <div className="text-[0.72rem] text-muted mb-[0.5rem]">
        <span
          className="inline-block py-[0.1rem] px-[0.4rem] rounded-[3px] text-[0.65rem]"
          style={{ background: `${color}22`, color }}
        >
          {selectedNode.nodeType}
        </span>
        {selectedNode.filePath && (
          <span className="opacity-70 ml-[0.3rem]">{selectedNode.filePath}</span>
        )}
      </div>

      <NeighborSection title="Incoming" items={incoming} onSelect={onSelectNode} />
      <NeighborSection title="Outgoing" items={outgoing} onSelect={onSelectNode} />
    </div>
  );
}

function NeighborSection({
  title,
  items,
  onSelect,
}: {
  title: string;
  items: NeighborInfo[];
  onSelect: (id: string) => void;
}) {
  if (!items.length) return null;

  return (
    <div className="mt-[0.5rem]">
      <div className="text-[0.65rem] text-muted uppercase mb-[0.25rem] font-semibold">
        {title} ({items.length})
      </div>
      {items.slice(0, 25).map((n, i) => {
        const c = NODE_COLORS[n.nodeType] ?? "#94a3b8";
        const ec = EDGE_COLORS[n.type] ?? "#475569";
        return (
          <div
            key={`${n.id}-${n.type}-${i}`}
            onClick={() => onSelect(n.id)}
            className="flex items-center gap-[0.3rem] py-[0.2rem] text-[0.72rem] text-accent cursor-pointer hover:underline"
          >
            <span
              className="w-[6px] h-[6px] rounded-full shrink-0"
              style={{ background: c }}
            />
            {n.label}
            <span className="text-[0.6rem] px-[0.2rem]" style={{ color: ec }}>
              [{n.type}]
            </span>
          </div>
        );
      })}
      {items.length > 25 && (
        <div className="text-muted text-[0.65rem] mt-[0.2rem]">
          ...and {items.length - 25} more
        </div>
      )}
    </div>
  );
}
