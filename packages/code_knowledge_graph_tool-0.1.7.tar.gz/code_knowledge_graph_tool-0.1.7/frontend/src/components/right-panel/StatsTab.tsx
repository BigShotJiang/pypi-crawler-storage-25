import { NODE_COLORS, EDGE_COLORS } from "../../constants";
import type { AnalysisResult } from "../../types";

interface Props {
  result: AnalysisResult;
}

export default function StatsTab({ result }: Props) {
  const { summary, nodes_by_label, relationships_by_type, communities } = result;

  const sortedNodes = Object.entries(nodes_by_label).sort((a, b) => b[1] - a[1]);
  const sortedRels = Object.entries(relationships_by_type).sort((a, b) => b[1] - a[1]);

  return (
    <div>
      <div className="bg-bg border border-border rounded-[6px] p-[0.6rem] text-center mb-[0.5rem]">
        <div className="text-[1.6rem] font-bold text-accent">
          {summary.total_lines.toLocaleString()}
        </div>
        <div className="text-[0.6rem] text-muted uppercase">Lines of Code</div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "0.5rem",
          marginBottom: "1rem",
        }}
      >
        <StatCard value={summary.files} label="Files" />
        <StatCard value={summary.total_nodes} label="Nodes" />
        <StatCard value={summary.total_relationships} label="Edges" />
        <StatCard value={summary.communities} label="Communities" />
      </div>

      <h3 className="text-[0.75rem] text-muted mb-[0.35rem] mt-[0.75rem]">
        Nodes by Label
      </h3>
      <table className="w-full border-collapse text-[0.72rem]">
        <tbody>
          {sortedNodes.map(([label, count]) => (
            <tr key={label} className="border-b border-border">
              <td className="text-left py-[0.3rem] px-[0.5rem]">
                <span
                  className="inline-block w-2 h-2 rounded-full mr-[0.4rem] align-middle"
                  style={{ background: NODE_COLORS[label] ?? "#94a3b8" }}
                />
                {label}
              </td>
              <td className="text-left py-[0.3rem] px-[0.5rem]">{count}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3 className="text-[0.75rem] text-muted mb-[0.35rem] mt-[0.75rem]">
        Relationships by Type
      </h3>
      <table className="w-full border-collapse text-[0.72rem]">
        <tbody>
          {sortedRels.map(([type, count]) => (
            <tr key={type} className="border-b border-border">
              <td className="text-left py-[0.3rem] px-[0.5rem]">
                <span
                  className="inline-block w-[14px] h-[3px] rounded-[2px] mr-[0.4rem] align-middle"
                  style={{ background: EDGE_COLORS[type] ?? "#475569" }}
                />
                {type}
              </td>
              <td className="text-left py-[0.3rem] px-[0.5rem]">{count}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {communities.length > 0 && (
        <>
          <h3 className="text-[0.75rem] text-muted mb-[0.35rem] mt-[0.75rem]">
            Communities
          </h3>
          <table className="w-full border-collapse text-[0.72rem]">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-[0.3rem] px-[0.5rem] text-muted font-semibold sticky top-0 bg-surface">
                  Label
                </th>
                <th className="text-left py-[0.3rem] px-[0.5rem] text-muted font-semibold sticky top-0 bg-surface">
                  Size
                </th>
                <th className="text-left py-[0.3rem] px-[0.5rem] text-muted font-semibold sticky top-0 bg-surface">
                  Coh.
                </th>
              </tr>
            </thead>
            <tbody>
              {communities.map((c) => (
                <tr key={c.id} className="border-b border-border">
                  <td className="py-[0.3rem] px-[0.5rem]">
                    {c.heuristic_label || c.label}
                  </td>
                  <td className="py-[0.3rem] px-[0.5rem]">{c.symbol_count}</td>
                  <td className="py-[0.3rem] px-[0.5rem]">{c.cohesion}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
}

function StatCard({ value, label }: { value: number; label: string }) {
  return (
    <div className="bg-bg border border-border rounded-[6px] p-[0.6rem] text-center">
      <div className="text-[1.4rem] font-bold text-accent">{value}</div>
      <div className="text-[0.6rem] text-muted uppercase">{label}</div>
    </div>
  );
}
