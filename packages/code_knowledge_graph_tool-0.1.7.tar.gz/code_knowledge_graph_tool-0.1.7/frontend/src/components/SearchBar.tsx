import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { NODE_COLORS } from "../constants";
import type { GraphEdge, GraphNode } from "../types";

// ── Utilities ────────────────────────────────────────────────────

/** Split camelCase / snake_case / PascalCase / kebab-case into lowercase tokens */
function tokenize(str: string): string[] {
  return str
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")   // camelCase
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2") // XMLParser → XML Parser
    .replace(/[_\-./\\:]/g, " ")               // separators
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
}

/** Score how well `query` matches `target`. Higher = better. 0 = no match. */
function fuzzyScore(queryWords: string[], target: string): number {
  const lower = target.toLowerCase();
  const tokens = tokenize(target);

  // Exact full-string containment per word (current behavior, best score)
  if (queryWords.every((w) => lower.includes(w))) return 100;

  // Token-aware: each query word matches the start of any token
  const tokenStart = queryWords.every((w) =>
    tokens.some((t) => t.startsWith(w)),
  );
  if (tokenStart) return 80;

  // Token-aware: each query word is a substring of any token
  const tokenSub = queryWords.every((w) =>
    tokens.some((t) => t.includes(w)),
  );
  if (tokenSub) return 70;

  // Fuzzy: characters appear in order
  const flat = queryWords.join("");
  let qi = 0;
  for (let ti = 0; ti < lower.length && qi < flat.length; ti++) {
    if (lower[ti] === flat[qi]) qi++;
  }
  if (qi === flat.length) return 50 - Math.min(30, target.length - flat.length);

  return 0;
}

/** Parse optional type qualifier: `type:function foo` or `t:class bar` */
function parseQuery(raw: string): { typeFilter: string | null; text: string } {
  const m = raw.match(/^(?:type|t):(\S+)\s*(.*)/i);
  if (m) return { typeFilter: m[1]!.toLowerCase(), text: m[2]!.trim() };
  return { typeFilter: null, text: raw.trim() };
}

/**
 * Find all nodes that lie on ANY shortest path between two nodes.
 * BFS from both ends, then collect nodes where distFromSource + distFromTarget === shortestLen.
 * O(V+E), safe on large graphs.
 */
function findAllShortestPathNodes(
  adj: Record<string, string[]>,
  from: string,
  to: string,
): Set<string> {
  if (from === to) return new Set([from]);

  // BFS from source
  const distFrom = new Map<string, number>([[from, 0]]);
  let frontier = [from];
  while (frontier.length > 0) {
    const next: string[] = [];
    for (const nid of frontier) {
      for (const nb of adj[nid] ?? []) {
        if (!distFrom.has(nb)) {
          distFrom.set(nb, distFrom.get(nid)! + 1);
          next.push(nb);
        }
      }
    }
    frontier = next;
  }
  if (!distFrom.has(to)) return new Set(); // unreachable

  const shortestLen = distFrom.get(to)!;

  // BFS from target
  const distTo = new Map<string, number>([[to, 0]]);
  frontier = [to];
  while (frontier.length > 0) {
    const next: string[] = [];
    for (const nid of frontier) {
      for (const nb of adj[nid] ?? []) {
        if (!distTo.has(nb)) {
          distTo.set(nb, distTo.get(nid)! + 1);
          next.push(nb);
        }
      }
    }
    frontier = next;
  }

  // A node is on a shortest path if distFrom[n] + distTo[n] === shortestLen
  const result = new Set<string>();
  for (const [nid, df] of distFrom) {
    const dt = distTo.get(nid);
    if (dt !== undefined && df + dt === shortestLen) {
      result.add(nid);
    }
  }
  return result;
}

/** BFS reverse dependents: find all nodes that transitively point TO nodeId */
function findReverseDeps(
  edges: GraphEdge[],
  nodeId: string,
  maxNodes = 50,
): string[] {
  // Build reverse adjacency (target → sources)
  const reverseAdj: Record<string, string[]> = {};
  for (const e of edges) {
    (reverseAdj[e.target] ??= []).push(e.source);
  }
  const visited = new Set<string>([nodeId]);
  let frontier = [nodeId];
  const result: string[] = [];

  while (frontier.length > 0 && result.length < maxNodes) {
    const next: string[] = [];
    for (const nid of frontier) {
      for (const src of reverseAdj[nid] ?? []) {
        if (visited.has(src)) continue;
        visited.add(src);
        result.push(src);
        if (result.length >= maxNodes) break;
        next.push(src);
      }
      if (result.length >= maxNodes) break;
    }
    frontier = next;
  }
  return result;
}

// ── Types ────────────────────────────────────────────────────────

interface ScoredMatch {
  node: GraphNode;
  score: number;
}

type SearchMode = "normal" | "path";

interface Props {
  nodes: GraphNode[];
  edges: GraphEdge[];
  filterPassIds: Set<string>;
  onSelect: (nodeId: string) => void;
  onHighlightNodes: (ids: Set<string>) => void;
  onHighlightEndpoints: (ids: Set<string>) => void;
  onClearHighlights: () => void;
}

// ── Component ────────────────────────────────────────────────────

export default function SearchBar({
  nodes,
  edges,
  filterPassIds,
  onSelect,
  onHighlightNodes,
  onHighlightEndpoints,
  onClearHighlights,
}: Props) {
  const [query, setQuery] = useState("");
  const [show, setShow] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0, width: 0 });
  const [hlIndex, setHlIndex] = useState(-1);

  // Feature 6: faceted filter chip
  const [activeChip, setActiveChip] = useState<string | null>(null);
  // Feature 7: search scope
  const [searchAll, setSearchAll] = useState(true);
  // Feature 5: path finding mode
  const [mode, setMode] = useState<SearchMode>("normal");
  const [pathSource, setPathSource] = useState<GraphNode | null>(null);
  const [pathError, setPathError] = useState<string | null>(null);
  // Feature 4: reverse deps display
  const [reverseDepsFor, setReverseDepsFor] = useState<string | null>(null);

  const wrapRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Build adjacency for path finding
  const adjacency = useMemo(() => {
    const adj: Record<string, string[]> = {};
    for (const e of edges) {
      (adj[e.source] ??= []).push(e.target);
      (adj[e.target] ??= []).push(e.source);
    }
    return adj;
  }, [edges]);

  // Node index for quick lookup
  const nodeIndex = useMemo(() => {
    const idx = new Map<string, GraphNode>();
    for (const n of nodes) idx.set(n.id, n);
    return idx;
  }, [nodes]);

  // ── Search logic ────────────────────────────────────────────────

  const { typeFilter, text: searchText } = useMemo(
    () => parseQuery(query),
    [query],
  );

  const words = useMemo(
    () => (searchText ? searchText.toLowerCase().split(/\s+/) : []),
    [searchText],
  );

  // Compute scored matches
  const scoredMatches = useMemo<ScoredMatch[]>(() => {
    if (words.length === 0) return [];

    // Feature 7: scope
    const pool = searchAll ? nodes : nodes.filter((n) => filterPassIds.has(n.id));

    // Feature 3: type qualifier
    const typed = typeFilter
      ? pool.filter((n) => n.nodeType.toLowerCase().startsWith(typeFilter))
      : pool;

    const results: ScoredMatch[] = [];
    for (const n of typed) {
      const hay = `${n.label ?? ""} ${n.filePath ?? ""} ${n.id ?? ""}`;
      const score = fuzzyScore(words, hay);
      if (score > 0) results.push({ node: n, score });
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, 40);
  }, [words, searchAll, nodes, filterPassIds, typeFilter]);

  // Feature 6: facet counts
  const facets = useMemo(() => {
    const counts = new Map<string, number>();
    for (const m of scoredMatches) {
      counts.set(m.node.nodeType, (counts.get(m.node.nodeType) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1]);
  }, [scoredMatches]);

  // Apply chip filter
  const filteredMatches = useMemo(
    () =>
      activeChip
        ? scoredMatches.filter((m) => m.node.nodeType === activeChip)
        : scoredMatches,
    [scoredMatches, activeChip],
  );

  // Feature 2: group by nodeType
  const grouped = useMemo(() => {
    const groups = new Map<string, ScoredMatch[]>();
    for (const m of filteredMatches) {
      const arr = groups.get(m.node.nodeType) ?? [];
      arr.push(m);
      groups.set(m.node.nodeType, arr);
    }
    return groups;
  }, [filteredMatches]);

  // Flat list for keyboard navigation
  const flatList = useMemo(() => {
    const list: GraphNode[] = [];
    for (const [, items] of grouped) {
      for (const m of items) list.push(m.node);
    }
    return list;
  }, [grouped]);

  // Feature 4: reverse deps results
  const reverseDepsResults = useMemo(() => {
    if (!reverseDepsFor) return [];
    const depIds = findReverseDeps(edges, reverseDepsFor);
    return depIds.map((id) => nodeIndex.get(id)).filter(Boolean) as GraphNode[];
  }, [reverseDepsFor, edges, nodeIndex]);

  const visible = show && (words.length > 0 || reverseDepsFor || mode === "path" || pathError);

  // ── Effects ─────────────────────────────────────────────────────

  useEffect(() => {
    if (visible && inputRef.current) {
      const r = inputRef.current.getBoundingClientRect();
      setPos({ top: r.bottom + 4, left: r.left, width: Math.max(r.width, 480) });
    }
  }, [visible, query, reverseDepsFor]);

  useEffect(() => {
    if (!visible) return;
    const h = (e: MouseEvent) => {
      const target = e.target as Node;
      if (wrapRef.current?.contains(target)) return;
      if (dropdownRef.current?.contains(target)) return;
      setShow(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [visible]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        inputRef.current?.focus();
      }
      if (e.key === "Escape") {
        if (reverseDepsFor) {
          setReverseDepsFor(null);
          onClearHighlights();
        } else if (mode === "path") {
          setMode("normal");
          setPathSource(null);
          onClearHighlights();
        } else {
          setShow(false);
        }
      }
    };
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [reverseDepsFor, mode, onClearHighlights]);

  // Reset chip when results change
  useEffect(() => {
    setActiveChip(null);
  }, [query]);

  // ── Handlers ────────────────────────────────────────────────────

  const pick = useCallback(
    (id: string) => {
      if (mode === "path") {
        if (!pathSource) {
          // First pick = source
          const node = nodeIndex.get(id);
          if (node) {
            setPathSource(node);
            setQuery("");
            setHlIndex(-1);
          }
        } else {
          // Second pick = target → find all shortest-path nodes
          const targetNode = nodeIndex.get(id);
          const pathNodes = findAllShortestPathNodes(adjacency, pathSource.id, id);
          if (pathNodes.size > 0) {
            onHighlightNodes(pathNodes);
            onHighlightEndpoints(new Set([pathSource.id, id]));
            onSelect(id);
            setPathError(null);
            setShow(false);
            setMode("normal");
            setPathSource(null);
          } else {
            // No connection — show error, let user pick a different target
            setPathError(`No path between "${pathSource.label}" and "${targetNode?.label ?? id}"`);
          }
          setQuery("");
        }
        return;
      }

      onSelect(id);
      setQuery("");
      setShow(false);
      setReverseDepsFor(null);
      onClearHighlights();
    },
    [onSelect, mode, pathSource, adjacency, nodeIndex, onHighlightNodes, onHighlightEndpoints, onClearHighlights],
  );

  const showReverseDeps = useCallback(
    (nodeId: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setReverseDepsFor(nodeId);
      // Highlight in graph
      const depIds = findReverseDeps(edges, nodeId);
      onHighlightNodes(new Set([nodeId, ...depIds]));
    },
    [edges, onHighlightNodes],
  );

  const exitReverseDeps = useCallback(() => {
    setReverseDepsFor(null);
    onClearHighlights();
  }, [onClearHighlights]);

  const togglePathMode = useCallback(() => {
    if (mode === "path") {
      setMode("normal");
      setPathSource(null);
      setPathError(null);
      onClearHighlights();
    } else {
      setMode("path");
      setPathSource(null);
      setPathError(null);
      setReverseDepsFor(null);
      setQuery("");
      setShow(true);
      inputRef.current?.focus();
    }
  }, [mode, onClearHighlights]);

  // ── Placeholder ─────────────────────────────────────────────────

  const placeholder = (() => {
    if (mode === "path" && !pathSource) return "Path mode: search source node...";
    if (mode === "path" && pathSource) return `Path from "${pathSource.label}" → search target...`;
    return `Search ${nodes.length} nodes... (Ctrl+K)`;
  })();

  // ── Render ──────────────────────────────────────────────────────

  return (
    <div ref={wrapRef} className="flex-1 max-w-[420px] mx-auto relative flex items-center gap-[0.35rem]">
      {/* Search input */}
      <div className="relative flex-1">
        <span className="absolute left-[0.6rem] top-1/2 -translate-y-1/2 text-muted text-[0.75rem]">
          {mode === "path" ? "\u2194" : "\uD83D\uDD0D"}
        </span>
        <input
          ref={inputRef}
          type="text"
          placeholder={placeholder}
          aria-label="Search graph nodes"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShow(true);
            setHlIndex(-1);
            setReverseDepsFor(null);
            setPathError(null);
          }}
          onKeyDown={(e) => {
            e.stopPropagation();
            e.nativeEvent.stopPropagation();
            const list = reverseDepsFor ? reverseDepsResults : flatList;
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setHlIndex((i) => (i < list.length - 1 ? i + 1 : 0));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setHlIndex((i) => (i > 0 ? i - 1 : list.length - 1));
            } else if (e.key === "Enter" && hlIndex >= 0 && hlIndex < list.length) {
              e.preventDefault();
              pick(list[hlIndex]!.id);
            } else if (e.key === "Escape") {
              if (reverseDepsFor) {
                exitReverseDeps();
              } else {
                setShow(false);
              }
            }
          }}
          onFocus={() => {
            if (query || mode === "path") setShow(true);
          }}
          className="w-full py-[0.35rem] pr-[0.7rem] pl-[1.8rem] bg-bg border border-border rounded-[6px] text-text text-[0.8rem] outline-none focus:border-accent focus:ring-1 focus:ring-accent/20"
        />
      </div>

      {/* Feature 7: scope toggle */}
      <button
        onClick={() => setSearchAll((v) => !v)}
        title={searchAll ? "Searching all nodes" : "Searching visible only"}
        className="cursor-pointer shrink-0 transition-colors duration-150"
        style={{
          padding: "0.25rem 0.45rem",
          borderRadius: 6,
          fontSize: "0.65rem",
          fontWeight: 600,
          border: `1px solid ${searchAll ? "var(--border)" : "var(--accent)"}`,
          background: searchAll ? "var(--elevated)" : "var(--accent)",
          color: searchAll ? "var(--muted)" : "#fff",
        }}
      >
        {searchAll ? "ALL" : "VIS"}
      </button>

      {/* Feature 5: path mode toggle */}
      <button
        onClick={togglePathMode}
        title={mode === "path" ? "Exit path mode (Esc)" : "Find path between two nodes"}
        className="cursor-pointer shrink-0 transition-colors duration-150"
        style={{
          padding: "0.25rem 0.45rem",
          borderRadius: 6,
          fontSize: "0.7rem",
          border: `1px solid ${mode === "path" ? "var(--accent)" : "var(--border)"}`,
          background: mode === "path" ? "var(--accent)" : "var(--elevated)",
          color: mode === "path" ? "#fff" : "var(--muted)",
        }}
      >
        &#x2192;
      </button>

      {/* ── Dropdown portal ────────────────────────────────────── */}
      {visible &&
        createPortal(
          <div
            ref={dropdownRef}
            style={{
              position: "fixed",
              top: pos.top,
              left: pos.left,
              width: pos.width,
              maxHeight: 460,
              overflowY: "auto",
              zIndex: 99999,
              background: "var(--surface, #161b22)",
              border: "1px solid var(--border, #30363d)",
              borderRadius: 8,
              boxShadow: "0 12px 40px rgba(0,0,0,0.6)",
            }}
            onMouseDown={(e) => e.preventDefault()}
          >
            {/* ── Reverse deps view ────────────────────────────── */}
            {reverseDepsFor ? (
              <>
                <div
                  style={{
                    padding: "6px 10px",
                    fontSize: 11,
                    color: "var(--muted)",
                    borderBottom: "1px solid var(--border)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <span>
                    <strong style={{ color: "var(--text)" }}>
                      {nodeIndex.get(reverseDepsFor)?.label ?? reverseDepsFor}
                    </strong>
                    {" \u2190 "}
                    {reverseDepsResults.length} dependent{reverseDepsResults.length !== 1 ? "s" : ""}
                  </span>
                  <button
                    onClick={exitReverseDeps}
                    className="cursor-pointer"
                    style={{
                      background: "none",
                      border: "none",
                      color: "var(--muted)",
                      fontSize: 14,
                      padding: "0 4px",
                    }}
                  >
                    &#x2715;
                  </button>
                </div>
                {reverseDepsResults.length === 0 && (
                  <div style={{ padding: "12px 10px", fontSize: 12, color: "var(--muted)", textAlign: "center" }}>
                    No dependents found
                  </div>
                )}
                {reverseDepsResults.map((n, i) => (
                  <ResultRow
                    key={n.id}
                    node={n}
                    highlighted={i === hlIndex}
                    onPick={pick}
                    onHover={() => setHlIndex(i)}
                    onReverseDeps={showReverseDeps}

                  />
                ))}
              </>
            ) : pathError ? (
              /* No path found error */
              <div style={{ padding: "12px 10px", fontSize: 12, textAlign: "center" }}>
                <div style={{ color: "#f87171", marginBottom: 6 }}>{pathError}</div>
                <div style={{ color: "var(--muted)" }}>
                  Try a different target, or press <strong>Esc</strong> to exit
                </div>
              </div>
            ) : mode === "path" && !pathSource && words.length === 0 ? (
              /* Path mode hint */
              <div style={{ padding: "12px 10px", fontSize: 12, color: "var(--muted)", textAlign: "center" }}>
                Type to search for the <strong>source</strong> node
              </div>
            ) : mode === "path" && pathSource && words.length === 0 ? (
              <div style={{ padding: "12px 10px", fontSize: 12, color: "var(--muted)", textAlign: "center" }}>
                Source: <strong style={{ color: "var(--text)" }}>{pathSource.label}</strong>
                {" \u2014 now search for the "}
                <strong>target</strong> node
              </div>
            ) : (
              /* ── Normal search results ─────────────────────── */
              <>
                {/* Result count + type hint */}
                <div
                  style={{
                    padding: "4px 10px",
                    fontSize: 10,
                    color: "var(--muted)",
                    borderBottom: "1px solid var(--border)",
                    display: "flex",
                    justifyContent: "space-between",
                  }}
                >
                  <span>
                    {filteredMatches.length} result{filteredMatches.length !== 1 ? "s" : ""}
                    {!searchAll && " (visible)"}
                    {mode === "path" && pathSource && ` \u2014 picking target for "${pathSource.label}"`}
                  </span>
                  {!typeFilter && (
                    <span style={{ opacity: 0.6 }}>tip: type:function ...</span>
                  )}
                </div>

                {/* Feature 6: faceted chips */}
                {facets.length > 1 && (
                  <div
                    style={{
                      padding: "4px 8px",
                      display: "flex",
                      gap: 4,
                      flexWrap: "wrap",
                      borderBottom: "1px solid var(--border)",
                    }}
                  >
                    <ChipButton
                      label={`All (${scoredMatches.length})`}
                      active={activeChip === null}
                      onClick={() => setActiveChip(null)}
                    />
                    {facets.map(([type, count]) => (
                      <ChipButton
                        key={type}
                        label={`${type} (${count})`}
                        color={NODE_COLORS[type]}
                        active={activeChip === type}
                        onClick={() =>
                          setActiveChip((prev) => (prev === type ? null : type))
                        }
                      />
                    ))}
                  </div>
                )}

                {/* Feature 2: categorized results */}
                {filteredMatches.length === 0 && (
                  <div style={{ padding: "12px 10px", fontSize: 12, color: "var(--muted)", textAlign: "center" }}>
                    No matches found
                  </div>
                )}

                {Array.from(grouped.entries()).map(([type, items]) => (
                  <div key={type}>
                    <div
                      style={{
                        padding: "4px 10px",
                        fontSize: 10,
                        fontWeight: 600,
                        color: NODE_COLORS[type] ?? "var(--muted)",
                        textTransform: "uppercase",
                        letterSpacing: "0.05em",
                        background: "rgba(255,255,255,0.02)",
                      }}
                    >
                      {type}
                    </div>
                    {items.map((m) => {
                      const idx = flatList.indexOf(m.node);
                      return (
                        <ResultRow
                          key={m.node.id}
                          node={m.node}
                          highlighted={idx === hlIndex}
                          onPick={pick}
                          onHover={() => setHlIndex(idx)}
                          onReverseDeps={showReverseDeps}

                        />
                      );
                    })}
                  </div>
                ))}
              </>
            )}
          </div>,
          document.body,
        )}
    </div>
  );
}

// ── Sub-components ───────────────────────────────────────────────

function ChipButton({
  label,
  color,
  active,
  onClick,
}: {
  label: string;
  color?: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="cursor-pointer transition-all duration-100"
      style={{
        padding: "1px 6px",
        borderRadius: 4,
        fontSize: 10,
        border: `1px solid ${active ? color ?? "var(--accent)" : "var(--border)"}`,
        background: active ? (color ?? "var(--accent)") + "22" : "transparent",
        color: active ? color ?? "var(--accent)" : "var(--muted)",
        fontWeight: active ? 600 : 400,
      }}
    >
      {label}
    </button>
  );
}

function ResultRow({
  node,
  highlighted,
  onPick,
  onHover,
  onReverseDeps,
}: {
  node: GraphNode;
  highlighted: boolean;
  onPick: (id: string) => void;
  onHover: () => void;
  onReverseDeps: (id: string, e: React.MouseEvent) => void;
}) {
  return (
    <div
      onClick={() => onPick(node.id)}
      onMouseEnter={onHover}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "5px 10px",
        fontSize: 13,
        cursor: "pointer",
        color: "var(--text, #e6edf3)",
        background: highlighted ? "rgba(255,255,255,0.08)" : "transparent",
      }}
      ref={(el) => {
        if (highlighted && el) el.scrollIntoView({ block: "nearest" });
      }}
    >
      <span
        style={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          background: NODE_COLORS[node.nodeType] ?? "#94a3b8",
          flexShrink: 0,
        }}
      />
      <span
        style={{
          flex: 1,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        }}
      >
        {node.label}
        {node.filePath && (
          <span style={{ color: "var(--muted)", marginLeft: 6, fontSize: 10 }}>
            {node.filePath}
          </span>
        )}
      </span>

      {/* Feature 4: reverse deps button */}
      <button
        onClick={(e) => onReverseDeps(node.id, e)}
        title="Find dependents (who uses this?)"
        className="cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity"
        style={{
          background: "none",
          border: "1px solid var(--border)",
          borderRadius: 4,
          color: "var(--muted)",
          fontSize: 10,
          padding: "1px 4px",
          flexShrink: 0,
          opacity: highlighted ? 0.7 : 0,
          transition: "opacity 150ms",
        }}
      >
        &#x21E0;
      </button>

      <span
        style={{
          fontSize: 10,
          padding: "1px 5px",
          borderRadius: 3,
          background: "var(--elevated, #21262d)",
          color: "var(--muted)",
          flexShrink: 0,
        }}
      >
        {node.nodeType}
      </span>
    </div>
  );
}
