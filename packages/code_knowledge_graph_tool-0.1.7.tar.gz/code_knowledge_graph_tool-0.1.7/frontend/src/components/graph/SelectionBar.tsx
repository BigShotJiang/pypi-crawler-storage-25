import type { GraphNode } from "../../types";

interface Props {
  selectedNode: GraphNode | null;
  onClear: () => void;
}

export default function SelectionBar({ selectedNode, onClear }: Props) {
  if (!selectedNode) return null;

  return (
    <div
      className="absolute top-[1rem] left-1/2 flex items-center gap-[0.5rem] px-[0.9rem] py-[0.4rem] rounded-[12px] text-[0.8rem] z-10"
      style={{
        transform: "translateX(-50%)",
        background: "rgba(88,166,255,0.12)",
        border: "1px solid rgba(88,166,255,0.25)",
        backdropFilter: "blur(8px)",
        animation: "slideDown 0.2s ease",
      }}
    >
      <span
        className="w-[6px] h-[6px] rounded-full"
        style={{
          background: "#06b6d4",
          animation: "pulse 2s infinite",
        }}
      />
      <span className="font-mono">{selectedNode.label}</span>
      <span className="text-[0.7rem] text-muted">{selectedNode.nodeType}</span>
      <button
        onClick={onClear}
        aria-label="Clear selection"
        className="cursor-pointer text-muted hover:text-text text-[0.7rem] ml-[0.3rem]"
      >
        &times;
      </button>
    </div>
  );
}
