import clsx from "clsx";
import { ZoomIn, ZoomOut, Maximize, Crosshair, RotateCcw, Play, Palette, Group } from "lucide-react";
import { RIGHT_PANEL_WIDTH, PANEL_GAP_OPEN } from "../../constants";

interface Props {
  physicsOn: boolean;
  hasSelection: boolean;
  communityColorMode: boolean;
  groupByCommunity: boolean;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onFit: () => void;
  onFocusSelected: () => void;
  onClearSelection: () => void;
  onTogglePhysics: () => void;
  onToggleCommunityColor?: () => void;
  onToggleGroupByCommunity?: () => void;
  rightPanelOpen?: boolean;
}

function ToolbarButton({
  onClick,
  title,
  active,
  children,
  hidden,
}: {
  onClick?: () => void;
  title: string;
  active?: boolean;
  children: React.ReactNode;
  hidden?: boolean;
}) {
  if (hidden) return null;
  return (
    <button
      onClick={onClick}
      title={title}
      aria-label={title}
      className={clsx(
        "w-[34px] h-[34px] flex items-center justify-center rounded-lg text-sm",
        "border backdrop-blur-md cursor-pointer transition-all duration-200",
        active
          ? "bg-accent border-accent text-white"
          : "bg-surface/85 border-border text-text hover:border-accent hover:text-accent",
      )}
    >
      {children}
    </button>
  );
}

export default function GraphToolbar({
  physicsOn,
  hasSelection,
  communityColorMode,
  groupByCommunity,
  onZoomIn,
  onZoomOut,
  onFit,
  onFocusSelected,
  onClearSelection,
  onTogglePhysics,
  onToggleCommunityColor,
  onToggleGroupByCommunity,
  rightPanelOpen,
}: Props) {
  return (
    <div
      className="absolute bottom-4 flex flex-col gap-1 z-10 transition-[right] duration-300 ease-in-out"
      style={{ right: rightPanelOpen ? `${RIGHT_PANEL_WIDTH + PANEL_GAP_OPEN}px` : `${PANEL_GAP_OPEN}px` }}
    >
      <ToolbarButton onClick={onZoomIn} title="Zoom In">
        <ZoomIn size={16} />
      </ToolbarButton>
      <ToolbarButton onClick={onZoomOut} title="Zoom Out">
        <ZoomOut size={16} />
      </ToolbarButton>
      <ToolbarButton onClick={onFit} title="Fit to Screen">
        <Maximize size={16} />
      </ToolbarButton>

      <div className="h-px my-0.5 bg-border" />

      <ToolbarButton onClick={onFocusSelected} title="Focus on Selected" hidden={!hasSelection}>
        <Crosshair size={16} />
      </ToolbarButton>
      <ToolbarButton onClick={onClearSelection} title="Clear Selection" hidden={!hasSelection}>
        <RotateCcw size={16} />
      </ToolbarButton>

      {hasSelection && <div className="h-px my-0.5 bg-border" />}

      <ToolbarButton onClick={onTogglePhysics} title="Toggle Layout" active={physicsOn}>
        <Play size={16} />
      </ToolbarButton>

      <div className="h-px my-0.5 bg-border" />

      <ToolbarButton onClick={onToggleCommunityColor} title="Color by Community" active={communityColorMode}>
        <Palette size={16} />
      </ToolbarButton>
      <ToolbarButton onClick={onToggleGroupByCommunity} title="Group by Community" active={groupByCommunity}>
        <Group size={16} />
      </ToolbarButton>

    </div>
  );
}
