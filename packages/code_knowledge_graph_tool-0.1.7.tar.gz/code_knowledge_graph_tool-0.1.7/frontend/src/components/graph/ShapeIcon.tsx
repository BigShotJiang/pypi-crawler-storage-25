interface Props {
  shape: string;
  color: string;
  size?: number;
}

export default function ShapeIcon({ shape, color, size = 12 }: Props) {
  const s = size;
  const half = s / 2;

  const common = {
    width: s,
    height: s,
    viewBox: `0 0 ${s} ${s}`,
    xmlns: "http://www.w3.org/2000/svg",
  };

  switch (shape) {
    case "diamond":
      return (
        <svg {...common}>
          <polygon
            points={`${half},0 ${s},${half} ${half},${s} 0,${half}`}
            fill={color}
          />
        </svg>
      );
    case "square":
    case "rectangle":
      return (
        <svg {...common}>
          <rect x={1} y={1} width={s - 2} height={s - 2} rx={1} fill={color} />
        </svg>
      );
    case "triangle":
      return (
        <svg {...common}>
          <polygon
            points={`${half},0 ${s},${s} 0,${s}`}
            fill={color}
          />
        </svg>
      );
    case "triangleDown":
    case "vee":
      return (
        <svg {...common}>
          <polygon
            points={`0,0 ${s},0 ${half},${s}`}
            fill={color}
          />
        </svg>
      );
    case "hexagon":
      return (
        <svg {...common}>
          <polygon
            points={`${half},0 ${s},${s * 0.25} ${s},${s * 0.75} ${half},${s} 0,${s * 0.75} 0,${s * 0.25}`}
            fill={color}
          />
        </svg>
      );
    case "star": {
      const cx = half, cy = half;
      const outerR = half, innerR = half * 0.4;
      const points: string[] = [];
      for (let i = 0; i < 10; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (Math.PI / 5) * i - Math.PI / 2;
        points.push(`${cx + r * Math.cos(angle)},${cy + r * Math.sin(angle)}`);
      }
      return (
        <svg {...common}>
          <polygon points={points.join(" ")} fill={color} />
        </svg>
      );
    }
    default:
      return (
        <svg {...common}>
          <circle cx={half} cy={half} r={half - 1} fill={color} />
        </svg>
      );
  }
}
