import { useMemo, useState } from "react";
import { NODE_COLORS, EDGE_COLORS } from "../../constants";
import type { GraphNode, GraphEdge } from "../../types";
import ShapeIcon from "./ShapeIcon";

const AMBIGUOUS_EDGE_COLOR = "#facc15";

const VIS_SHAPES: Record<string, string> = {
  Class: "diamond",
  Interface: "diamond",
  Function: "dot",
  Method: "dot",
  File: "square",
  Folder: "triangle",
  Community: "hexagon",
  Process: "star",
  Enum: "triangleDown",
  Decorator: "triangle",
  Project: "dot",
  Package: "dot",
  Module: "dot",
  Type: "dot",
};

interface Props {
  nodes: GraphNode[];
  edges: GraphEdge[];
  hiddenNodeTypes: Set<string>;
  hiddenEdgeTypes: Set<string>;
  onToggleNodeType: (type: string) => void;
  onToggleEdgeType: (type: string) => void;
  offsetLeft?: boolean;
}

export default function FloatingLegend({
  nodes,
  edges,
  hiddenNodeTypes,
  hiddenEdgeTypes,
  onToggleNodeType,
  onToggleEdgeType,
}: Props) {
  const [expanded, setExpanded] = useState(true);

  const nodeTypeCounts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const n of nodes) map[n.nodeType] = (map[n.nodeType] ?? 0) + 1;
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [nodes]);

  const edgeTypeCounts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const e of edges) map[e.type] = (map[e.type] ?? 0) + 1;
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [edges]);

  const ambiguousEdgeCount = useMemo(
    () => edges.filter((edge) => edge.reviewLabel === "AMBIGUOUS").length,
    [edges],
  );

  return (
    <div className="relative z-20">
      <button
        onClick={() => setExpanded((v) => !v)}
        aria-label={expanded ? "Collapse legend" : "Expand legend"}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] cursor-pointer border-none bg-surface/85 text-muted backdrop-blur-md transition-colors hover:text-text"
      >
        Legend {expanded ? "\u25BE" : "\u25B8"}
      </button>

      {expanded && (
        <div className="mt-1 p-2.5 rounded-xl border border-border bg-surface/85 backdrop-blur-md overflow-y-auto max-h-[50vh] min-w-[180px] max-w-[240px] shadow-[0_8px_32px_rgba(0,0,0,0.4)]">
          {/* Nodes */}
          <div className="text-[10px] font-semibold text-muted uppercase tracking-wide mb-1.5">Nodes</div>
          {nodeTypeCounts.map(([type, count]) => {
            const hidden = hiddenNodeTypes.has(type);
            const color = NODE_COLORS[type] ?? "#94a3b8";
            const shape = VIS_SHAPES[type] ?? "dot";
            return (
              <div
                key={type}
                onClick={() => onToggleNodeType(type)}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onToggleNodeType(type); } }}
                role="button"
                tabIndex={0}
                className="flex items-center gap-1.5 py-0.5 px-1 rounded cursor-pointer transition-opacity duration-150 hover:bg-white/5"
                style={{ opacity: hidden ? 0.3 : 1 }}
              >
                <ShapeIcon shape={shape} color={color} size={10} />
                <span className="flex-1 text-[11px] text-text">{type}</span>
                <span className="text-[10px] text-muted">{count}</span>
              </div>
            );
          })}

          <div className="h-px bg-border my-2" />

          {/* Edges */}
          <div className="text-[10px] font-semibold text-muted uppercase tracking-wide mb-1.5">Edges</div>
          {ambiguousEdgeCount > 0 && (
            <div className="flex items-center gap-1.5 py-0.5 px-1 rounded">
              <span
                className="shrink-0 w-3.5 h-[3px]"
                style={{
                  backgroundImage: `repeating-linear-gradient(to right, ${AMBIGUOUS_EDGE_COLOR} 0 5px, transparent 5px 8px)`,
                }}
              />
              <span className="flex-1 text-[11px] text-text">AMBIGUOUS</span>
              <span className="text-[10px] text-muted">{ambiguousEdgeCount}</span>
            </div>
          )}
          {edgeTypeCounts.map(([type, count]) => {
            const hidden = hiddenEdgeTypes.has(type);
            const color = EDGE_COLORS[type] ?? "#475569";
            return (
              <div
                key={type}
                onClick={() => onToggleEdgeType(type)}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onToggleEdgeType(type); } }}
                role="button"
                tabIndex={0}
                className="flex items-center gap-1.5 py-0.5 px-1 rounded cursor-pointer transition-opacity duration-150 hover:bg-white/5"
                style={{ opacity: hidden ? 0.3 : 1 }}
              >
                <span className="shrink-0 w-3.5 h-[3px] rounded-sm" style={{ background: color }} />
                <span className="flex-1 text-[11px] text-text">{type}</span>
                <span className="text-[10px] text-muted">{count}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
