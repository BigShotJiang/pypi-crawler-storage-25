import { useCallback, useEffect, useRef, useState } from "react";
import { DataSet } from "vis-data";
import { Network } from "vis-network";
import { NODE_COLORS, NODE_SIZES, EDGE_COLORS, COMMUNITY_COLORS } from "../../constants";
import type { GraphNode, GraphEdge, Community } from "../../types";
import GraphToolbar from "./GraphToolbar";
import SelectionBar from "./SelectionBar";
import AiPanel from "./AiPanel";

const AMBIGUOUS_EDGE_COLOR = "#facc15";
const AMBIGUOUS_REVIEW_LABEL = "AMBIGUOUS";

interface Props {
  nodes: GraphNode[];
  edges: GraphEdge[];
  selectedNodeId: string | null;
  filterPassIds: Set<string>;
  visibleNodeIds: Set<string> | null;
  processStepIds: Set<string> | null;
  hiddenEdgeTypes: Set<string>;
  depthFilter: number | null;
  communityColorMode: boolean;
  groupByCommunity: boolean;
  communities: Community[];
  communityMembers?: Record<string, string[]>;
  focusNodeId: string | null;
  onFocusNodeConsumed: () => void;
  onSelectNode: (id: string) => void;
  onClearSelection: () => void;
  onToggleCommunityColor?: () => void;
  onToggleGroupByCommunity?: () => void;
  highlightedNodeIds?: Set<string>;
  highlightEndpointIds?: Set<string>;
  repoId?: string;
  rightPanelOpen?: boolean;
}

function toVisNode(n: GraphNode, nodeCount = 0) {
  const c = NODE_COLORS[n.nodeType] ?? "#94a3b8";
  const shape = VIS_SHAPES[n.nodeType] ?? "dot";
  const drawThreshold = nodeCount > 5000 ? 12 : nodeCount > 2000 ? 9 : 5;
  return {
    id: n.id,
    label: n.label || "",
    size: NODE_SIZES[n.nodeType] ?? 14,
    shape,
    color: {
      background: c,
      border: c,
      highlight: { background: c, border: "#fff" },
      hover: { background: c, border: "#fff" },
    },
    font: {
      color: "#e6edf3",
      size: 10,
      face: "-apple-system,sans-serif",
      strokeWidth: 2,
      strokeColor: "#0d1117",
    },
    scaling: {
      label: {
        enabled: true,
        drawThreshold,
        maxVisible: 30,
      },
    },
    title: n.nodeType + (n.filePath ? "\n" + n.filePath : ""),
    nodeType: n.nodeType,
    filePath: n.filePath,
  };
}

function toVisEdge(e: GraphEdge, useSmoothEdges = true, isLargeGraph = false) {
  const isAmbiguous = e.reviewLabel === AMBIGUOUS_REVIEW_LABEL;
  const c = isAmbiguous ? AMBIGUOUS_EDGE_COLOR : EDGE_COLORS[e.type] ?? "#475569";
  const title = isAmbiguous ? `${e.type} · ${AMBIGUOUS_REVIEW_LABEL}` : e.type;
  return {
    id: e.id,
    from: e.source,
    to: e.target,
    relType: e.type,
    reviewLabel: e.reviewLabel,
    title,
    color: { color: c, highlight: c, hover: c, opacity: isLargeGraph ? 0.3 : 0.55 },
    arrows: { to: { enabled: true, scaleFactor: isLargeGraph ? 0.3 : 0.5, type: "arrow" as const } },
    dashes: isAmbiguous ? [8, 6] : false,
    smooth: useSmoothEdges ? { enabled: true, type: "continuous" as const, roundness: 0.15 } : false,
    width: isAmbiguous ? (isLargeGraph ? 1 : 1.4) : (isLargeGraph ? 0.5 : 0.8),
  };
}

/** Parse hex color to {r,g,b}. */
function parseHex(hex: string): { r: number; g: number; b: number } {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return { r, g, b };
}

const toHex = (v: number) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0");

/** Blend a hex color toward a dark background for dimming effect. */
function dimColor(hex: string, amount: number): string {
  if (!hex.startsWith("#") || hex.length !== 7) return hex;
  const { r, g, b } = parseHex(hex);
  const bg = { r: 13, g: 17, b: 23 }; // #0d1117
  const mix = (c: number, bgc: number) => Math.round(bgc + (c - bgc) * amount);
  return `#${toHex(mix(r, bg.r))}${toHex(mix(g, bg.g))}${toHex(mix(b, bg.b))}`;
}

/** Brighten a hex color by blending toward white. amount 0-1 (0 = unchanged, 1 = white). */
function brightenColor(hex: string, amount: number): string {
  if (!hex.startsWith("#") || hex.length !== 7) return hex;
  const { r, g, b } = parseHex(hex);
  const mix = (c: number) => Math.round(c + (255 - c) * amount);
  return `#${toHex(mix(r))}${toHex(mix(g))}${toHex(mix(b))}`;
}

/** Return hex color with alpha as rgba string. */
function hexAlpha(hex: string, alpha: number): string {
  if (!hex.startsWith("#") || hex.length !== 7) return hex;
  const { r, g, b } = parseHex(hex);
  return `rgba(${r},${g},${b},${alpha})`;
}

// vis-network uses different shape names than cytoscape
const VIS_SHAPES: Record<string, string> = {
  Class: "diamond",
  Interface: "diamond",
  Function: "dot",
  Method: "dot",
  File: "square",
  Folder: "triangle",
  Community: "hexagon",
  Process: "star",
  Enum: "triangleDown",
  Decorator: "triangle",
};

export default function GraphView({
  nodes,
  edges,
  selectedNodeId,
  filterPassIds,
  visibleNodeIds: _visibleNodeIds,
  processStepIds,
  hiddenEdgeTypes,
  depthFilter: _depthFilter,
  communityColorMode,
  groupByCommunity,
  communities,
  communityMembers,
  focusNodeId,
  onFocusNodeConsumed,
  onSelectNode,
  onClearSelection,
  onToggleCommunityColor,
  onToggleGroupByCommunity,
  highlightedNodeIds,
  highlightEndpointIds,
  repoId,
  rightPanelOpen,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const networkRef = useRef<Network | null>(null);
  const visNodesRef = useRef<DataSet<any> | null>(null);
  const visEdgesRef = useRef<DataSet<any> | null>(null);
  const smoothPanRef = useRef<((nodeId: string) => void) | null>(null);
  const [physicsOn, setPhysicsOn] = useState(true);
  const [, setStatusText] = useState("");
  const prevNodeStateRef = useRef<Map<string, string>>(new Map());
  const filterRafRef = useRef<number | null>(null);
  const lastFilterTimeRef = useRef<number>(0);
  const highlightedIdsRef = useRef<Set<string> | undefined>(highlightedNodeIds);
  highlightedIdsRef.current = highlightedNodeIds;

  // Use index for O(1) lookup instead of O(N) .find()
  const nodeIndexRef = useRef<Map<string, GraphNode>>(new Map());
  const edgesByNodeRef = useRef<Map<string, GraphEdge[]>>(new Map());
  useEffect(() => {
    const m = new Map<string, GraphNode>();
    for (const n of nodes) m.set(n.id, n);
    nodeIndexRef.current = m;

    const em = new Map<string, GraphEdge[]>();
    for (const e of edges) {
      let arr = em.get(e.source);
      if (!arr) { arr = []; em.set(e.source, arr); }
      arr.push(e);
      let arr2 = em.get(e.target);
      if (!arr2) { arr2 = []; em.set(e.target, arr2); }
      arr2.push(e);
    }
    edgesByNodeRef.current = em;
  }, [nodes, edges]);

  const selectedNode = nodeIndexRef.current.get(selectedNodeId ?? "") ?? null;

  const ensureNodeInDataSet = useCallback((nodeId: string): boolean => {
    const visNodes = visNodesRef.current;
    if (!visNodes) return false;
    if (visNodes.get(nodeId)) return true;

    const raw = nodeIndexRef.current.get(nodeId);
    if (!raw) return false;

    visNodes.add(toVisNode(raw, nodes.length));
    return true;
  }, [nodes.length]);

  // Initialize vis-network — only add nodes/edges that pass current filters
  useEffect(() => {
    if (!containerRef.current || nodes.length === 0) return;

    // Only add nodes that pass the filter to the DataSet (biggest perf win)
    const passNodes = nodes.filter((n) => filterPassIds.has(n.id));
    const passNodeIds = new Set(passNodes.map((n) => n.id));
    const passEdges = edges.filter(
      (e) => passNodeIds.has(e.source) && passNodeIds.has(e.target) && !hiddenEdgeTypes.has(e.type),
    );

    // Scale settings based on visible node count
    const visibleCount = passNodes.length;
    const isLargeGraph = visibleCount > 2000;
    const isMediumGraph = visibleCount > 500;

    // Disable smooth edges for large graphs — significant rendering cost
    const useSmoothEdges = !isMediumGraph;

    const visNodes = new DataSet(passNodes.map((n) => toVisNode(n, visibleCount)));
    const visEdges = new DataSet(passEdges.map((e) => toVisEdge(e, useSmoothEdges, isLargeGraph)));
    visNodesRef.current = visNodes;
    visEdgesRef.current = visEdges;
    const stabilizationIters = isLargeGraph ? 0 : isMediumGraph ? 50 : 200;
    const physicsEnabled = !isLargeGraph;

    const network = new Network(
      containerRef.current,
      { nodes: visNodes, edges: visEdges },
      {
        physics: {
          enabled: physicsEnabled,
          solver: "forceAtlas2Based",
          forceAtlas2Based: {
            gravitationalConstant: isLargeGraph ? -26 : -50,
            centralGravity: 0.005,
            springLength: isLargeGraph ? 80 : 120,
            springConstant: 0.018,
            damping: isLargeGraph ? 0.8 : 0.4,
            avoidOverlap: 0.5,
          },
          stabilization: stabilizationIters > 0
            ? { iterations: stabilizationIters, updateInterval: 25 }
            : false,
          maxVelocity: 50,
          minVelocity: 0.3,
        },
        interaction: {
          hover: true,
          hoverConnectedEdges: false,
          tooltipDelay: isMediumGraph ? 300 : 150,
          zoomView: true,
          dragView: true,
          dragNodes: true,
          keyboard: { enabled: true, bindToWindow: false },
          hideEdgesOnDrag: isMediumGraph,
          hideEdgesOnZoom: isMediumGraph,
        },
        layout: { improvedLayout: false },
        nodes: { borderWidth: 1.5, borderWidthSelected: 3 },
        edges: { selectionWidth: 2, hoverWidth: 3 },
      },
    );

    setPhysicsOn(physicsEnabled);

    // Manual smooth pan using requestAnimationFrame + easing
    let panAnimId: number | null = null;
    function smoothPanTo(targetX: number, targetY: number, duration = 700) {
      if (panAnimId) cancelAnimationFrame(panAnimId);
      const start = performance.now();
      const from = network.getViewPosition();
      const dx = targetX - from.x;
      const dy = targetY - from.y;
      // Skip if already close enough
      if (Math.abs(dx) < 3 && Math.abs(dy) < 3) return;

      function easeInOutCubic(t: number) {
        return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      }

      function step(now: number) {
        const elapsed = now - start;
        const t = Math.min(elapsed / duration, 1);
        const e = easeInOutCubic(t);
        network.moveTo({
          position: { x: from.x + dx * e, y: from.y + dy * e },
        });
        if (t < 1) {
          panAnimId = requestAnimationFrame(step);
        } else {
          panAnimId = null;
        }
      }
      panAnimId = requestAnimationFrame(step);
    }

    // Expose smooth pan by node ID
    smoothPanRef.current = (nodeId: string) => {
      const pos = network.getPositions([nodeId])[nodeId];
      if (pos) smoothPanTo(pos.x, pos.y);
    };

    network.on("click", (params: any) => {
      if (params.nodes.length > 0) {
        onSelectNode(params.nodes[0]);
      } else {
        onClearSelection();
      }
    });

    // Show edge label on hover, hide on blur
    network.on("hoverEdge", (params: any) => {
      const eid = params.edge;
      if (visEdges && eid) {
        const edge = visEdges.get(eid) as any;
        if (edge) {
          const label = edge.reviewLabel === AMBIGUOUS_REVIEW_LABEL
            ? `${edge.relType} · ${AMBIGUOUS_REVIEW_LABEL}`
            : edge.relType;
          visEdges.update({ id: eid, label, font: { size: 9, face: "-apple-system,sans-serif", color: edge.color?.color ?? "#94a3b8", strokeWidth: 3, strokeColor: "#0a1628", align: "middle" } } as any);
        }
      }
    });
    network.on("blurEdge", (params: any) => {
      const eid = params.edge;
      if (visEdges && eid) {
        visEdges.update({ id: eid, label: "", font: { size: 0 } } as any);
      }
    });

    network.on("stabilizationProgress", (p: any) => {
      setStatusText(`Layout: ${Math.round((p.iterations / p.total) * 100)}%`);
    });

    network.on("stabilizationIterationsDone", () => {
      setStatusText(`${nodes.length} nodes  ${edges.length} edges`);
    });

    networkRef.current = network;

    return () => {
      network.destroy();
      networkRef.current = null;
      visNodesRef.current = null;
      visEdgesRef.current = null;
      smoothPanRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes, edges]);

  // Smooth pan to selected node, or schedule fit-all on deselect
  const prevSelectedIdRef = useRef<string | null>(null);
  const pendingFitRef = useRef(false);
  useEffect(() => {
    if (selectedNodeId && smoothPanRef.current && ensureNodeInDataSet(selectedNodeId)) {
      smoothPanRef.current(selectedNodeId);
    } else if (!selectedNodeId && prevSelectedIdRef.current) {
      // Deselected — schedule fit after filter effect restores all nodes
      pendingFitRef.current = true;
    }
    prevSelectedIdRef.current = selectedNodeId;
  }, [selectedNodeId, ensureNodeInDataSet]);

  // Focus node from search — smooth zoom-in transition
  useEffect(() => {
    if (focusNodeId && networkRef.current) {
      if (!ensureNodeInDataSet(focusNodeId)) {
        onFocusNodeConsumed();
        return;
      }
      networkRef.current.focus(focusNodeId, {
        scale: 1.5,
        animation: { duration: 800, easingFunction: "easeInOutQuad" },
      });
      networkRef.current.selectNodes([focusNodeId]);
      onSelectNode(focusNodeId);
      onFocusNodeConsumed();
    }
  }, [focusNodeId, onFocusNodeConsumed, onSelectNode, ensureNodeInDataSet]);

  // Apply filters/highlighting — add/remove nodes from DataSet instead of hidden toggle
  useEffect(() => {
    if (filterRafRef.current) cancelAnimationFrame(filterRafRef.current);
    filterRafRef.current = requestAnimationFrame(() => {
      const now = performance.now();
      if (now - lastFilterTimeRef.current < 33) return; // Throttle to ~30fps
      lastFilterTimeRef.current = now;

      const visNodes = visNodesRef.current;
      const visEdges = visEdgesRef.current;
      if (!visNodes || !visEdges || !networkRef.current) return;

      const hasSelection = !!selectedNodeId;
      const hasProcessFocus = !!processStepIds;
      const hasQueryHighlight = !!highlightedNodeIds && highlightedNodeIds.size > 0;
      const nodeIndex = nodeIndexRef.current;

      const commIdToIndex: Record<string, number> = {};
      communities.forEach((c, i) => { commIdToIndex[c.id] = i; });

      // Determine which nodes should be in the DataSet
      const shouldBeVisible = new Set<string>();
      for (const n of nodes) {
        const pass = filterPassIds.has(n.id);
        if (!hasSelection && !hasProcessFocus) {
          if (pass) shouldBeVisible.add(n.id);
        } else if (hasProcessFocus && processStepIds!.has(n.id)) {
          shouldBeVisible.add(n.id);
        } else if (hasSelection && (n.id === selectedNodeId || pass)) {
          shouldBeVisible.add(n.id);
        }
      }

      // Add nodes that should be visible but aren't in DataSet
      const currentNodeIds = new Set(visNodes.getIds() as string[]);
      const toAdd: any[] = [];
      const toRemove: string[] = [];

      for (const id of shouldBeVisible) {
        if (!currentNodeIds.has(id)) {
          const raw = nodeIndex.get(id);
          if (raw) toAdd.push(toVisNode(raw, nodes.length));
        }
      }

      // Remove nodes that shouldn't be visible
      for (const id of currentNodeIds) {
        if (!shouldBeVisible.has(id)) toRemove.push(id);
      }

      if (toRemove.length > 0) visNodes.remove(toRemove);
      if (toAdd.length > 0) visNodes.add(toAdd);

      // ── Style updates for visible nodes (selection highlighting, community colors) ──
      const nodeUpdates: any[] = [];
      const nextNodeState = new Map<string, string>();

      visNodes.forEach((n: any) => {
        const raw = nodeIndex.get(n.id);
        let baseColor = raw ? NODE_COLORS[raw.nodeType] ?? "#94a3b8" : "#94a3b8";
        if (communityColorMode && raw?.communityId && commIdToIndex[raw.communityId] !== undefined) {
          baseColor = COMMUNITY_COLORS[commIdToIndex[raw.communityId]! % COMMUNITY_COLORS.length]!;
        }
        const baseSize = raw ? NODE_SIZES[raw.nodeType] ?? 14 : 14;

        let stateKey: string;
        let update: any;

        const defaultFont = { color: "#e6edf3", size: 10, face: "-apple-system,sans-serif", strokeWidth: 2, strokeColor: "#0d1117", background: "transparent" };
        const defaultScaling = { label: { enabled: true, drawThreshold: nodes.length > 5000 ? 12 : nodes.length > 2000 ? 9 : 5, maxVisible: 30 } };

        if (hasProcessFocus && processStepIds!.has(n.id)) {
          stateKey = "P";
          update = {
            id: n.id, size: Math.round(baseSize * 1.5), borderWidth: 1.5, borderWidthSelected: 3,
            color: { background: "#06b6d4", border: "#06b6d4", highlight: { background: "#06b6d4", border: "#fff" }, hover: { background: "#06b6d4", border: "#fff" } },
            font: { ...defaultFont }, scaling: defaultScaling,
          };
        } else if (hasSelection && n.id === selectedNodeId) {
          stateKey = `S:${baseColor}`;
          update = {
            id: n.id, size: Math.round(baseSize * 1.8), borderWidth: 1.5, borderWidthSelected: 3,
            color: { background: baseColor, border: "#ffffff", highlight: { background: baseColor, border: "#fff" }, hover: { background: baseColor, border: "#fff" } },
            font: { ...defaultFont, color: "#ffffff", strokeWidth: 3 }, scaling: defaultScaling,
          };
        } else if (hasQueryHighlight && highlightedNodeIds!.has(n.id)) {
          const isEndpoint = highlightEndpointIds?.has(n.id);
          const labelBg = hexAlpha(baseColor, 0.65);
          if (isEndpoint) {
            // Endpoint: white border, label badge
            stateKey = `QE:${baseColor}`;
            update = {
              id: n.id, size: baseSize, borderWidth: 3, borderWidthSelected: 3,
              color: { background: baseColor, border: "#ffffff", highlight: { background: baseColor, border: "#fff" }, hover: { background: baseColor, border: "#fff" } },
              font: {
                ...defaultFont, color: "#ffffff", size: 12,
                strokeWidth: 0, strokeColor: "transparent", background: labelBg,
              },
              scaling: { label: { enabled: false, drawThreshold: 0, maxVisible: 12 } },
            };
          } else {
            // Intermediate path node: brighter colored border, label badge
            const brightBorder = brightenColor(baseColor, 0.4);
            stateKey = `QI:${baseColor}`;
            update = {
              id: n.id, size: baseSize, borderWidth: 2.5, borderWidthSelected: 3,
              color: { background: baseColor, border: brightBorder, highlight: { background: baseColor, border: "#fff" }, hover: { background: baseColor, border: "#fff" } },
              font: {
                ...defaultFont, color: "#ffffff", size: 11,
                strokeWidth: 0, strokeColor: "transparent", background: labelBg,
              },
              scaling: { label: { enabled: false, drawThreshold: 0, maxVisible: 11 } },
            };
          }
        } else if (hasQueryHighlight) {
          const dimmed = dimColor(baseColor, 0.25);
          stateKey = `D:${baseColor}`;
          update = {
            id: n.id, size: Math.round(baseSize * 0.85), borderWidth: 1.5, borderWidthSelected: 3,
            color: { background: dimmed, border: dimmed, highlight: { background: baseColor, border: "#fff" }, hover: { background: baseColor, border: "#fff" } },
            font: { ...defaultFont, color: "#e6edf350" }, scaling: defaultScaling,
          };
        } else {
          stateKey = `N:${baseSize}:${baseColor}`;
          update = {
            id: n.id, size: baseSize, borderWidth: 1.5, borderWidthSelected: 3,
            color: { background: baseColor, border: baseColor, highlight: { background: baseColor, border: "#fff" }, hover: { background: baseColor, border: "#fff" } },
            font: { ...defaultFont }, scaling: defaultScaling,
          };
        }

        nextNodeState.set(n.id, stateKey);
        if (prevNodeStateRef.current.get(n.id) !== stateKey) {
          nodeUpdates.push(update);
        }
      });

      prevNodeStateRef.current = nextNodeState;
      if (nodeUpdates.length > 0) visNodes.update(nodeUpdates);

      // ── Sync edges: add/remove based on visible node set ──
      const currentEdgeIds = new Set(visEdges.getIds() as string[]);
      const useSmoothEdges = shouldBeVisible.size <= 500;
      const largeGraph = nodes.length > 2000;
      const edgesToAdd: any[] = [];
      const edgesToRemove: string[] = [];

      // Add edges where both endpoints are visible — O(V_visible * avg_degree) via index
      const seenEdgeIds = new Set<string>();
      const edgesByNode = edgesByNodeRef.current;
      for (const nodeId of shouldBeVisible) {
        const connected = edgesByNode.get(nodeId);
        if (!connected) continue;
        for (const e of connected) {
          if (seenEdgeIds.has(e.id)) continue;
          seenEdgeIds.add(e.id);
          const bothVisible = shouldBeVisible.has(e.source) && shouldBeVisible.has(e.target) && !hiddenEdgeTypes.has(e.type);
          if (bothVisible && !currentEdgeIds.has(e.id)) {
            edgesToAdd.push(toVisEdge(e, useSmoothEdges, largeGraph));
          }
        }
      }

      // Remove edges where an endpoint is no longer visible
      const edgeIdIndex = new Map(edges.map((e) => [e.id, e]));
      for (const eid of currentEdgeIds) {
        const raw = edgeIdIndex.get(eid);
        if (!raw || !shouldBeVisible.has(raw.source) || !shouldBeVisible.has(raw.target) || hiddenEdgeTypes.has(raw.type)) {
          edgesToRemove.push(eid);
        }
      }

      if (edgesToRemove.length > 0) visEdges.remove(edgesToRemove);
      if (edgesToAdd.length > 0) visEdges.add(edgesToAdd);

      // ── Edge style updates (process focus, selection, query highlighting) ──
      {
        const edgeUpdates: any[] = [];
        visEdges.forEach((e: any) => {
          const isAmbiguous = e.reviewLabel === AMBIGUOUS_REVIEW_LABEL;
          const edgeColor = isAmbiguous ? AMBIGUOUS_EDGE_COLOR : EDGE_COLORS[e.relType] ?? "#475569";
          const defaultOpacity = nodes.length > 2000 ? 0.3 : 0.55;
          const defaultWidth = isAmbiguous ? (nodes.length > 2000 ? 1 : 1.4) : (nodes.length > 2000 ? 0.5 : 0.8);
          if (hasProcessFocus && processStepIds!.has(e.from) && processStepIds!.has(e.to)) {
            edgeUpdates.push({ id: e.id, width: 2, color: { color: "#06b6d4", highlight: "#06b6d4", hover: "#06b6d4", opacity: 0.8 } });
          } else if (hasQueryHighlight) {
            const fromHit = highlightedNodeIds!.has(e.from);
            const toHit = highlightedNodeIds!.has(e.to);
            if (fromHit && toHit) {
              // Use brighter version of the edge's own color for highlighted paths
              const brightEdge = brightenColor(edgeColor, 0.45);
              edgeUpdates.push({ id: e.id, width: 2.5, color: { color: brightEdge, highlight: brightEdge, hover: brightEdge, opacity: 0.9 } });
            } else if (fromHit || toHit) {
              edgeUpdates.push({ id: e.id, width: 1, color: { color: edgeColor, highlight: edgeColor, hover: edgeColor, opacity: 0.25 } });
            } else {
              edgeUpdates.push({ id: e.id, width: 0.5, color: { color: edgeColor, highlight: edgeColor, hover: edgeColor, opacity: 0.06 } });
            }
          } else if (hasSelection) {
            edgeUpdates.push({ id: e.id, width: 1.2, color: { color: edgeColor, highlight: edgeColor, hover: edgeColor, opacity: 0.7 } });
          } else {
            edgeUpdates.push({ id: e.id, width: defaultWidth, color: { color: edgeColor, highlight: edgeColor, hover: edgeColor, opacity: defaultOpacity } });
          }
        });
        if (edgeUpdates.length > 0) visEdges.update(edgeUpdates);
      }

      // Fit-to-screen after nodes are restored from a deselection
      if (pendingFitRef.current) {
        pendingFitRef.current = false;
        networkRef.current?.fit({ animation: { duration: 600, easingFunction: "easeInOutQuad" } });
      }
    });

    return () => { if (filterRafRef.current) cancelAnimationFrame(filterRafRef.current); };
  }, [nodes, edges, selectedNodeId, filterPassIds, processStepIds, hiddenEdgeTypes, communityColorMode, communities, highlightedNodeIds, highlightEndpointIds]);

  // Community clustering via vis-network cluster() API
  useEffect(() => {
    const network = networkRef.current;
    if (!network || !communityMembers) return;

    if (groupByCommunity) {
      const commIds = Object.keys(communityMembers);
      commIds.forEach((commId, index) => {
        const memberIds = new Set(communityMembers[commId]);
        if (!memberIds || memberIds.size < 2) return;

        const comm = communities.find((c) => c.id === commId);
        const color = COMMUNITY_COLORS[index % COMMUNITY_COLORS.length]!;

        try {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (network as any).cluster({
            joinCondition: (nodeOptions: any) => memberIds.has(nodeOptions.id),
            clusterNodeProperties: {
              id: `cluster:${commId}`,
              label: `${comm?.heuristic_label || commId}\n(${memberIds.size})`,
              shape: "hexagon",
              size: 30 + Math.sqrt(memberIds.size) * 5,
              color: { background: color, border: color },
              font: { color: "#fff", size: 12, multi: true },
              borderWidth: 2,
            },
            clusterEdgeProperties: {
              color: { color, opacity: 0.3 },
              width: 1,
            },
          });
        } catch {
          // May fail if nodes are already clustered
        }
      });
    } else {
      // Open all clusters
      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const net = network as any;
        const allNodeIds: string[] = net.body?.nodeIndices ?? [];
        for (const id of allNodeIds) {
          if (network.isCluster(id)) {
            network.openCluster(id);
          }
        }
      } catch {
        // Ignore errors when no clusters exist
      }
    }
  }, [groupByCommunity, communityMembers, communities]);

  const handleZoomIn = useCallback(() => {
    const network = networkRef.current;
    if (network) {
      network.moveTo({ scale: network.getScale() * 1.3, animation: { duration: 400, easingFunction: "easeInOutQuad" as const } });
    }
  }, []);

  const handleZoomOut = useCallback(() => {
    const network = networkRef.current;
    if (network) {
      network.moveTo({ scale: network.getScale() / 1.3, animation: { duration: 400, easingFunction: "easeInOutQuad" as const } });
    }
  }, []);

  const handleFit = useCallback(() => {
    networkRef.current?.fit({ animation: { duration: 600, easingFunction: "easeInOutQuad" } });
  }, []);

  const handleFocusSelected = useCallback(() => {
    if (!selectedNodeId || !networkRef.current) return;
    if (!ensureNodeInDataSet(selectedNodeId)) return;
    networkRef.current.focus(selectedNodeId, {
      scale: networkRef.current.getScale(),
      animation: { duration: 600, easingFunction: "easeInOutQuad" },
    });
  }, [selectedNodeId, ensureNodeInDataSet]);

  const handleTogglePhysics = useCallback(() => {
    const network = networkRef.current;
    if (!network) return;

    if (physicsOn) {
      setPhysicsOn(false);
      network.setOptions({ physics: false });
    } else {
      setPhysicsOn(true);
      network.setOptions({
        physics: {
          enabled: true,
          solver: "forceAtlas2Based",
          forceAtlas2Based: {
            gravitationalConstant: -50,
            centralGravity: 0.005,
            springLength: 120,
            springConstant: 0.018,
            damping: 0.4,
            avoidOverlap: 0.5,
          },
          stabilization: false,
          maxVelocity: 50,
        },
      });
    }
  }, [physicsOn]);

  return (
    <div className="absolute inset-0">
      <div ref={containerRef} className="w-full h-full" tabIndex={0} style={{ outline: 'none' }} />

      <SelectionBar selectedNode={selectedNode} onClear={onClearSelection} />

      <GraphToolbar
        physicsOn={physicsOn}
        hasSelection={!!selectedNodeId}
        communityColorMode={communityColorMode}
        groupByCommunity={groupByCommunity}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onFit={handleFit}
        onFocusSelected={handleFocusSelected}
        onClearSelection={onClearSelection}
        onTogglePhysics={handleTogglePhysics}
        onToggleCommunityColor={onToggleCommunityColor}
        onToggleGroupByCommunity={onToggleGroupByCommunity}
        rightPanelOpen={rightPanelOpen}
      />

      <AiPanel rightPanelOpen={rightPanelOpen} selectedNode={selectedNode} repoId={repoId} />
    </div>
  );
}
