import { useState, useRef } from "react";
import clsx from "clsx";
import { executeQuery, queryCkgAgent, type QueryResult } from "../../api";

interface Props {
  repoId?: string;
  onHighlightNodes?: (ids: Set<string>) => void;
  onClearHighlights?: () => void;
  highlightedCount?: number;
}

interface PresetQuery {
  label: string;
  query: string;
}

interface PresetCategory {
  group: string;
  queries: PresetQuery[];
}

const PRESET_CATEGORIES: PresetCategory[] = [
  {
    group: "Hot Spots",
    queries: [
      {
        label: "Most Called Symbols",
        query:
          "MATCH (n:Method) WHERE n.fanIn > 3 RETURN n.id AS id, n.name AS name, n.filePath AS file, n.fanIn AS fanIn ORDER BY n.fanIn DESC LIMIT 25",
      },
      {
        label: "Large Symbols (>50 lines)",
        query:
          "MATCH (n:Method) WHERE n.endLine - n.startLine > 50 RETURN n.id AS id, n.name AS name, n.filePath AS file, (n.endLine - n.startLine) AS lines ORDER BY lines DESC LIMIT 25",
      },
      {
        label: "Files with Most Symbols",
        query:
          "MATCH (f:File)-[r:CodeRelation]->(n) WHERE r.type = 'CONTAINS' WITH f, count(n) AS symbols ORDER BY symbols DESC LIMIT 20 RETURN f.id AS id, f.name AS name, f.filePath AS file, symbols",
      },
    ],
  },
  {
    group: "Architecture",
    queries: [
      {
        label: "Cross-File Calls",
        query:
          "MATCH (a)-[r:CodeRelation]->(b) WHERE r.type = 'CALLS' AND a.filePath <> b.filePath RETURN a.id AS id, a.name AS caller, b.name AS callee, a.filePath AS from, b.filePath AS to LIMIT 30",
      },
      {
        label: "Import Graph",
        query:
          "MATCH (a:File)-[r:CodeRelation]->(b:File) WHERE r.type = 'IMPORTS' RETURN a.id AS id, a.name AS source, b.name AS target, r.confidence AS confidence LIMIT 30",
      },
      {
        label: "Inheritance / Extends",
        query:
          "MATCH (c)-[r:CodeRelation]->(p) WHERE r.type = 'EXTENDS' RETURN c.id AS id, c.name AS child, p.name AS parent, c.filePath AS file",
      },
    ],
  },
  {
    group: "Communities",
    queries: [
      {
        label: "Largest Communities",
        query:
          "MATCH (c:Community) WHERE c.symbolCount > 2 RETURN c.id AS id, c.heuristicLabel AS community, c.symbolCount AS symbols, c.cohesion AS cohesion ORDER BY c.symbolCount DESC LIMIT 15",
      },
      {
        label: "Community Members",
        query:
          "MATCH (s)-[r:CodeRelation]->(c:Community) WHERE r.type = 'MEMBER_OF' RETURN s.id AS id, s.name AS member, c.heuristicLabel AS community ORDER BY c.heuristicLabel LIMIT 30",
      },
    ],
  },
  {
    group: "Execution Flows",
    queries: [
      {
        label: "Process Entry Points",
        query:
          "MATCH (p:Process) RETURN p.id AS id, p.heuristicLabel AS process, p.processType AS type, p.stepCount AS steps ORDER BY p.stepCount DESC",
      },
      {
        label: "Process Steps",
        query:
          "MATCH (s)-[r:CodeRelation]->(p:Process) WHERE r.type = 'STEP_IN_PROCESS' RETURN s.id AS id, s.name AS step, p.heuristicLabel AS process, s.filePath AS file ORDER BY p.heuristicLabel LIMIT 30",
      },
    ],
  },
];

const ALL_PRESETS = PRESET_CATEGORIES.flatMap((c) => c.queries);

function formatCell(val: unknown): string {
  if (val === null || val === undefined) return "\u2014";
  if (typeof val === "boolean") return val ? "true" : "false";
  if (typeof val === "number")
    return Number.isInteger(val) ? String(val) : val.toFixed(4);
  return String(val);
}

/** Extract node IDs from query results by scanning columns named "id". */
function extractNodeIds(result: QueryResult): Set<string> {
  const ids = new Set<string>();
  const idColIndices = result.columns
    .map((col, i) => [col.toLowerCase(), i] as const)
    .filter(([col]) => col === "id")
    .map(([, i]) => i);

  if (idColIndices.length === 0) return ids;

  for (const row of result.rows) {
    for (const idx of idColIndices) {
      const val = (row as unknown[])[idx];
      if (typeof val === "string" && val.length > 0) {
        ids.add(val);
      }
    }
  }
  return ids;
}

export default function QueryFAB({
  repoId,
  onHighlightNodes,
  onClearHighlights,
  highlightedCount = 0,
}: Props) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<QueryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [presetKey, setPresetKey] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const canRun = !!repoId && query.trim().length > 0 && !loading;

  const handlePresetSelect = (value: string) => {
    if (!value) return;
    const preset = ALL_PRESETS.find((p) => p.label === value);
    if (preset) {
      setQuery(preset.query);
      setResult(null);
      setError(null);
      onClearHighlights?.();
      setPresetKey((k) => k + 1);
      textareaRef.current?.focus();
    }
  };

  const handleRun = async () => {
    if (!canRun || !repoId) return;
    setLoading(true);
    setError(null);
    setResult(null);
    onClearHighlights?.();
    try {
      const res = await executeQuery(repoId, query.trim());
      setResult(res);
      const nodeIds = extractNodeIds(res);
      if (nodeIds.size > 0) {
        onHighlightNodes?.(nodeIds);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    e.stopPropagation();
    e.nativeEvent.stopPropagation();
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      handleRun();
    }
  };

  const handleAiGenerate = async () => {
    if (!aiPrompt.trim() || aiLoading || !repoId) return;
    setAiLoading(true);
    try {
      const resp = await queryCkgAgent(
        `Generate ONLY a KuzuDB Cypher query (no explanation, no markdown) for: "${aiPrompt.trim()}"\n\n` +
          `CRITICAL — KuzuDB has ONE relationship table: CodeRelation. ` +
          `NEVER write [:CONTAINS], [:CALLS], etc. — those tables do NOT exist and will error. ` +
          `ALWAYS use [:CodeRelation {type: 'TYPE_HERE'}].\n\n` +
          `Node tables: File, Folder, Function, Class, Interface, Method, CodeElement, Community, Process, Section, \`Struct\`, \`Enum\`, \`Macro\`, \`Typedef\`, \`Union\`, \`Namespace\`, \`Trait\`, \`Impl\`, \`TypeAlias\`, \`Const\`, \`Static\`, \`Property\`, \`Record\`, \`Delegate\`, \`Annotation\`, \`Constructor\`, \`Template\`, \`Module\`.\n` +
          `Tables shown with backticks MUST be backtick-escaped in queries.\n\n` +
          `Semantic groups (use UNION ALL when user asks broadly):\n` +
          `- "functions/callable": Function, Method, \`Constructor\`, \`Static\`\n` +
          `- "types/definitions": Class, Interface, \`Struct\`, \`Enum\`, \`Trait\`, \`Record\`, \`TypeAlias\`, \`Typedef\`\n` +
          `- "structure": File, Folder, \`Module\`, \`Namespace\`\n\n` +
          `All relationship types (CodeRelation.type values) with direction:\n` +
          `- CONTAINS: parent→child (Folder→File, File→Function, File→Class, File→Method, etc.)\n` +
          `- CALLS: caller→callee (Function→Function, Function→Method, Method→Method, Method→Function, Constructor→Function, Constructor→Method)\n` +
          `- IMPORTS: File→File\n` +
          `- EXTENDS: child→parent (Class→Class, \`Struct\`→Class)\n` +
          `- IMPLEMENTS: implementor→interface (Class→Interface, Class→\`Trait\`, \`Struct\`→\`Trait\`, \`Struct\`→Interface)\n` +
          `- INHERITS: child→parent\n` +
          `- HAS_METHOD: owner→method (Class→Method, \`Struct\`→Method, Interface→Method, \`Trait\`→Method, \`Impl\`→Method, \`Record\`→Method, \`Enum\`→Method)\n` +
          `- HAS_PROPERTY: owner→prop (Class→\`Property\`, \`Struct\`→\`Property\`, Interface→\`Property\`, \`Record\`→\`Property\`)\n` +
          `- OVERRIDES: Method overrides parent Method\n` +
          `- ACCESSES: Function/Method→\`Property\`\n` +
          `- USES: symbol→symbol\n` +
          `- DEFINES: File→symbol\n` +
          `- DECORATES: decorator→symbol\n` +
          `- MEMBER_OF: symbol→Community\n` +
          `- STEP_IN_PROCESS: symbol→Process (has 'step' property for ordering)\n` +
          `- DESCRIBES: Section→symbol\n` +
          `- DOCUMENTED_BY: symbol→Section\n` +
          `- COMMUNITY_INTERACTS: Community→Community\n\n` +
          `Node properties:\n` +
          `- Common: name, filePath, startLine, endLine, fanIn, isExported, content, signature, parameterCount, returnType\n` +
          `- File: lineCount, binary\n` +
          `- Community: heuristicLabel, symbolCount, cohesion\n` +
          `- Process: heuristicLabel, processType, stepCount\n` +
          `- Section: level\n\n` +
          `Direction examples:\n` +
          `- File contains Function: (f:File)-[:CodeRelation {type: 'CONTAINS'}]->(fn:Function)\n` +
          `- Function calls Method: (a:Function)-[:CodeRelation {type: 'CALLS'}]->(b:Method)\n` +
          `- Class has Method: (c:Class)-[:CodeRelation {type: 'HAS_METHOD'}]->(m:Method)\n\n` +
          `IMPORTANT: Always include n.id AS id in results so they can highlight nodes on the graph.\n` +
          `Return ONLY the Cypher query, nothing else.`,
        null,
        repoId,
      );
      let cypher = resp.response.trim();
      // Strip markdown code fences if present
      const fenceMatch = cypher.match(/```(?:cypher|sql)?\s*\n?([\s\S]*?)```/);
      if (fenceMatch?.[1]) cypher = fenceMatch[1].trim();
      setQuery(cypher);
      setResult(null);
      setError(null);
      onClearHighlights?.();
      textareaRef.current?.focus();
    } catch (err: unknown) {
      setError(
        `AI generation failed: ${err instanceof Error ? err.message : String(err)}`,
      );
    } finally {
      setAiLoading(false);
    }
  };

  const statusText = loading
    ? "Running..."
    : result
      ? `${result.count} row${result.count !== 1 ? "s" : ""} returned${result.truncated ? " (truncated)" : ""}`
      : repoId
        ? "Ready"
        : "No repository selected";

  return (
    <div className="relative">
      {/* FAB Button */}
      <button
        onClick={() => setOpen((v) => !v)}
        title="Query Graph"
        aria-label="Query Graph"
        className={clsx(
          "flex items-center gap-1.5 h-9 px-3 rounded-[10px] text-xs font-medium",
          "border backdrop-blur-md cursor-pointer transition-all duration-300",
          open
            ? "bg-accent border-accent/50 text-bgBase shadow-[0_0_20px_rgba(0,229,153,0.3)]"
            : "bg-surface/90 border-border text-text",
        )}
      >
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="4 17 10 11 4 5" />
          <line x1="12" y1="19" x2="20" y2="19" />
        </svg>
        Query
        {!open && highlightedCount > 0 && (
          <span className="ml-1 min-w-[18px] h-[18px] flex items-center justify-center rounded-full bg-accent text-bgBase text-[9px] font-bold px-1">
            {highlightedCount}
          </span>
        )}
      </button>

      {/* Expanded Panel */}
      {open && (
        <div className="absolute z-20 flex flex-col bottom-full left-0 mb-2 w-[520px] max-h-[520px] rounded-xl border border-border bg-bgSurface/95 backdrop-blur-2xl shadow-[0_8px_40px_rgba(0,0,0,0.5)]">
          {/* Header */}
          <div className="flex items-center justify-between px-3 py-2 border-b border-border shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded flex items-center justify-center bg-accent/15 border border-accent/25">
                <svg
                  width="10"
                  height="10"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-accent"
                >
                  <polyline points="4 17 10 11 4 5" />
                  <line x1="12" y1="19" x2="20" y2="19" />
                </svg>
              </div>
              <span className="text-xs font-semibold text-text">
                Cypher Query
              </span>
            </div>
            <div className="flex items-center gap-2">
              {highlightedCount > 0 && (
                <button
                  onClick={onClearHighlights}
                  className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-accent/15 text-accent border border-accent/25 hover:bg-accent/25 cursor-pointer transition-colors"
                  title="Clear graph highlights"
                >
                  <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M18 6L6 18M6 6l12 12" />
                  </svg>
                  {highlightedCount} highlighted
                </button>
              )}
              <select
                key={presetKey}
                onChange={(e) => handlePresetSelect(e.target.value)}
                defaultValue=""
                className="text-[10px] px-1.5 py-1 rounded outline-none cursor-pointer bg-elevated border border-border text-text"
              >
                <option value="" disabled>
                  Examples...
                </option>
                {PRESET_CATEGORIES.map((cat) => (
                  <optgroup key={cat.group} label={cat.group}>
                    {cat.queries.map((p) => (
                      <option key={p.label} value={p.label}>
                        {p.label}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
              <button
                onClick={() => setOpen(false)}
                className="w-5 h-5 rounded flex items-center justify-center text-muted hover:bg-white/5 transition-colors"
                aria-label="Close query panel"
              >
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path d="M18 6L6 18M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {/* AI Generation Row */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 border-b border-border shrink-0">
            <input
              type="text"
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              onKeyDown={(e) => {
                e.stopPropagation();
                if (e.key === "Enter") {
                  e.preventDefault();
                  handleAiGenerate();
                }
              }}
              placeholder="Describe what you want to query..."
              className="flex-1 text-[11px] px-2 py-1 rounded-md outline-none font-mono bg-bg border border-border text-text focus:border-accent/50 transition-colors"
            />
            <button
              onClick={handleAiGenerate}
              disabled={!aiPrompt.trim() || aiLoading || !repoId}
              title="Generate Cypher with AI"
              className={clsx(
                "flex items-center gap-1 text-[10px] px-2 py-1 rounded-md font-medium border transition-colors",
                aiLoading || !aiPrompt.trim() || !repoId
                  ? "bg-elevated/50 text-muted/50 border-border cursor-not-allowed"
                  : "bg-accent/15 text-accent border-accent/25 hover:bg-accent/25 cursor-pointer",
              )}
            >
              {aiLoading ? (
                <svg
                  className="animate-spin"
                  width="10"
                  height="10"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <path d="M12 2v4m0 12v4m-7.07-3.93l2.83-2.83m8.49-8.49l2.83-2.83M2 12h4m12 0h4M4.93 4.93l2.83 2.83m8.49 8.49l2.83 2.83" />
                </svg>
              ) : (
                <svg
                  width="10"
                  height="10"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <path d="M12 3l1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3z" />
                </svg>
              )}
              AI
            </button>
          </div>

          {/* Query Input */}
          <div className="px-3 py-2 shrink-0">
            <textarea
              ref={textareaRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="MATCH (n:Function) RETURN n.id AS id, n.name, n.filePath LIMIT 10"
              rows={3}
              className="w-full text-xs p-2 rounded-md outline-none resize-none font-mono bg-bg border border-border text-text focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-colors"
            />
            <div className="flex items-center justify-between mt-1.5">
              <span
                className={clsx(
                  "text-[10px]",
                  error ? "text-red-400" : "text-muted",
                )}
              >
                {statusText}
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] px-1 py-0.5 rounded bg-elevated text-muted border border-border">
                  &#x2318;&#x21B5;
                </span>
                <button
                  onClick={handleRun}
                  disabled={!canRun}
                  className={clsx(
                    "text-[11px] px-3 py-1 rounded-md font-medium border transition-colors",
                    canRun
                      ? "bg-accent/15 text-accent border-accent/25 hover:bg-accent/25 cursor-pointer"
                      : "bg-accent/15 text-accent/50 border-accent/20 cursor-not-allowed",
                  )}
                >
                  {loading ? "Running..." : "Run"}
                </button>
              </div>
            </div>
          </div>

          {/* Results Area */}
          <div className="flex-1 overflow-y-auto px-3 pb-3 max-h-[240px]">
            {error ? (
              <div className="p-2 rounded-md bg-red-500/10 border border-red-500/20">
                <p className="text-[11px] text-red-400 font-mono break-all">
                  {error}
                </p>
              </div>
            ) : result && result.count > 0 ? (
              <div className="overflow-x-auto rounded-md border border-border">
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="bg-elevated/50 border-b border-border">
                      {result.columns.map((col) => (
                        <th
                          key={col}
                          className="px-2 py-1.5 text-left font-semibold text-muted whitespace-nowrap"
                        >
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {result.rows.map((row, i) => (
                      <tr
                        key={i}
                        className="border-b border-border/50 hover:bg-white/[0.02] transition-colors"
                      >
                        {(row as unknown[]).map((cell, j) => (
                          <td
                            key={j}
                            className="px-2 py-1 text-text font-mono max-w-[200px] truncate"
                            title={formatCell(cell)}
                          >
                            {formatCell(cell)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : result && result.count === 0 ? (
              <div className="flex flex-col items-center justify-center py-6 text-center rounded-md bg-bg border border-dashed border-border">
                <p className="text-[11px] text-muted">
                  Query returned no results
                </p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center rounded-md bg-bg border border-dashed border-border">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mb-2 opacity-40 text-muted"
                >
                  <rect x="3" y="3" width="7" height="7" />
                  <rect x="14" y="3" width="7" height="7" />
                  <rect x="3" y="14" width="7" height="7" />
                  <rect x="14" y="14" width="7" height="7" />
                </svg>
                <p className="text-[11px] text-muted">
                  Query results will appear here
                </p>
                <p className="text-[9px] text-muted mt-0.5 opacity-60">
                  Select an example or describe what you need
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
