import { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import clsx from "clsx";
import { queryCkgAgent } from "../../api";
import type { GraphNode } from "../../types";
import { RIGHT_PANEL_WIDTH, AI_PANEL_WIDTH, AI_PANEL_WIDTH_EXPANDED, AI_PANEL_HEIGHT } from "../../constants";

interface Message {
  role: "user" | "assistant";
  text: string;
  promptTokens?: number;
  completionTokens?: number;
  executionTime?: number;
}

const WELCOME: Message = {
  role: "assistant",
  text: "Hi! I'm CKG Assistant. Ask me about your codebase structure, dependencies, or any node in the graph.\n\nYou can also ask me to **generate an SRS document** for your project — just say \"Generate SRS\" and I'll analyze the codebase and create a full Software Requirements Specification (.md + .docx).",
};

interface Props {
  rightPanelOpen?: boolean;
  selectedNode?: GraphNode | null;
  repoId?: string;
}

export default function AiPanel({ rightPanelOpen, selectedNode, repoId }: Props) {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [messages, setMessages] = useState<Message[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Auto-resize textarea to fit content
  useEffect(() => {
    const ta = textareaRef.current;
    if (ta) {
      ta.style.height = "auto";
      ta.style.height = `${ta.scrollHeight}px`;
    }
  }, [input]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || loading) return;

    setMessages((prev) => [...prev, { role: "user", text }]);
    setInput("");
    setLoading(true);

    try {
      const nodeCtx = selectedNode ? {
        id: selectedNode.id,
        label: selectedNode.label,
        nodeType: selectedNode.nodeType,
        filePath: selectedNode.filePath,
        startLine: selectedNode.startLine,
        endLine: selectedNode.endLine,
        communityId: selectedNode.communityId ?? null,
      } : null;

      const result = await queryCkgAgent(text, nodeCtx, repoId);
      setMessages((prev) => [...prev, {
        role: "assistant",
        text: result.response,
        promptTokens: result.prompt_token,
        completionTokens: result.completion_token,
        executionTime: result.execution_time,
      }]);

      if (result.tool_calls?.includes("srs_generation_tool")) {
        const url = repoId ? `/api/srs-docx?repo_id=${repoId}` : "/api/srs-docx";
        const a = document.createElement("a");
        a.href = url;
        a.download = "";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      setMessages((prev) => [...prev, { role: "assistant", text: `Error: ${msg}` }]);
    } finally {
      setLoading(false);
    }
  };

  const rightOffset = rightPanelOpen ? `${RIGHT_PANEL_WIDTH + 60}px` : "60px";

  return (
    <>
      {/* Trigger button */}
      <button
        onClick={() => setOpen((v) => !v)}
        title="AI Assistant"
        aria-label="AI Assistant"
        className={clsx(
          "absolute bottom-4 z-20 w-[42px] h-[42px] flex items-center justify-center rounded-xl",
          "border backdrop-blur-md transition-all duration-300",
          open
            ? "bg-accent border-accent shadow-[0_0_20px_rgba(0,229,153,0.3)]"
            : "bg-surface/90 border-border",
        )}
        style={{ right: rightOffset }}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={open ? "var(--bg-base)" : "var(--accent)"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2a8 8 0 0 1 8 8v1a8 8 0 0 1-16 0v-1a8 8 0 0 1 8-8z" />
          <path d="M9 14h.01M15 14h.01" />
          <path d="M9.5 17.5c1 1 3.5 1 5 0" />
          <path d="M8 2S6 1 4.5 2.5" />
          <path d="M16 2s2-1 3.5.5" />
        </svg>
      </button>

      {/* Panel */}
      {open && (
        <div
          className="absolute bottom-16 z-20 flex flex-col rounded-2xl border border-border bg-bgSurface/95 backdrop-blur-2xl shadow-[0_8px_40px_rgba(0,0,0,0.5)] transition-all duration-300"
          style={{
            right: rightOffset,
            width: expanded ? AI_PANEL_WIDTH_EXPANDED : AI_PANEL_WIDTH,
            height: expanded ? "calc(100% - 72px)" : AI_PANEL_HEIGHT,
          }}
        >
          {/* Header */}
          <div className="flex items-center gap-2 px-4 py-3 border-b border-border shrink-0">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-accent/15 border border-accent/25">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent">
                <path d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-text">CKG Assistant</p>
              <p className="text-[10px] truncate text-muted">
                {selectedNode ? `Focused: ${selectedNode.label} (${selectedNode.nodeType})` : "Graph-aware AI"}
              </p>
            </div>
            <button
              onClick={() => setExpanded((v) => !v)}
              title={expanded ? "Collapse" : "Expand"}
              aria-label={expanded ? "Collapse panel" : "Expand panel"}
              className="w-6 h-6 rounded flex items-center justify-center text-muted hover:bg-white/5 transition-colors"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {expanded
                  ? <><path d="M4 14h6v6" /><path d="M20 10h-6V4" /><path d="M14 10l7-7" /><path d="M3 21l7-7" /></>
                  : <><path d="M15 3h6v6" /><path d="M9 21H3v-6" /><path d="M21 3l-7 7" /><path d="M3 21l7-7" /></>
                }
              </svg>
            </button>
            <button
              onClick={() => setOpen(false)}
              aria-label="Close AI panel"
              className="w-6 h-6 rounded flex items-center justify-center text-muted hover:bg-white/5 transition-colors"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12" /></svg>
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3" style={{ scrollbarWidth: "thin" }}>
            {messages.map((msg, i) => (
              <div key={i} className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}>
                <div
                  className={clsx(
                    "max-w-[85%] px-3 py-2 text-sm leading-relaxed",
                    msg.role === "user"
                      ? "rounded-[12px_12px_4px_12px] bg-accent text-bgBase"
                      : "rounded-[12px_12px_12px_4px] bg-surface text-text border border-border",
                  )}
                >
                  {msg.role === "user" ? msg.text : (
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      components={{
                        h1: ({ children }) => <h1 className="text-base font-bold mt-3 mb-1.5">{children}</h1>,
                        h2: ({ children }) => <h2 className="text-sm font-bold mt-2.5 mb-1">{children}</h2>,
                        h3: ({ children }) => <h3 className="text-sm font-semibold mt-2 mb-1">{children}</h3>,
                        p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                        ul: ({ children }) => <ul className="list-disc pl-4 mb-2 space-y-1">{children}</ul>,
                        ol: ({ children }) => <ol className="list-decimal pl-4 mb-2 space-y-1">{children}</ol>,
                        li: ({ children }) => <li className="text-sm">{children}</li>,
                        code: ({ className, children }) => {
                          const isBlock = className?.includes("language-");
                          if (isBlock) return <code className="block text-xs p-3 my-2 rounded-lg overflow-x-auto bg-black/35 text-gray-200">{children}</code>;
                          return <code className="text-xs px-1.5 py-0.5 rounded bg-black/25 text-accent">{children}</code>;
                        },
                        pre: ({ children }) => <pre className="my-2 rounded-lg overflow-x-auto text-xs bg-black/35">{children}</pre>,
                        a: ({ href, children }) => <a href={href} className="underline text-accent" target="_blank" rel="noopener noreferrer">{children}</a>,
                      }}
                    >
                      {msg.text}
                    </ReactMarkdown>
                  )}
                </div>
                {msg.role === "assistant" && msg.executionTime != null && msg.executionTime > 0 && (
                  <div className="flex items-center gap-2 mt-1 px-1 text-[10px] text-muted">
                    <span className="flex items-center gap-0.5" title="Processing time">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" />
                      </svg>
                      {msg.executionTime}s
                    </span>
                    <span className="flex items-center gap-0.5" title="Prompt tokens">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                      </svg>
                      {msg.promptTokens?.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-0.5" title="Completion tokens">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 20h9" /><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
                      </svg>
                      {msg.completionTokens?.toLocaleString()}
                    </span>
                    <span className="text-muted/60">|</span>
                    <span title="Total tokens">
                      {((msg.promptTokens ?? 0) + (msg.completionTokens ?? 0)).toLocaleString()} tokens
                    </span>
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="rounded-[12px_12px_12px_4px] bg-surface text-muted border border-border px-3 py-2 text-sm flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                  Thinking...
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="px-3 py-3 border-t border-border shrink-0">
            <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex gap-2 items-end">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  e.stopPropagation();
                  e.nativeEvent.stopPropagation();
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder={selectedNode ? `Ask about ${selectedNode.label}...` : "Ask about your codebase..."}
                disabled={loading}
                rows={1}
                className={clsx(
                  "flex-1 text-sm px-3 py-2 rounded-lg outline-none transition-colors resize-none",
                  "bg-bg border border-border text-text",
                  "focus:border-accent/50 focus:ring-1 focus:ring-accent/20",
                  loading && "opacity-60",
                )}
                style={{ maxHeight: 120 }}
              />
              <button
                type="submit"
                disabled={loading || !input.trim()}
                aria-label="Send message"
                className={clsx(
                  "px-3 py-2 rounded-lg text-sm font-medium transition-all border",
                  input.trim() && !loading
                    ? "bg-accent text-bgBase border-accent"
                    : "bg-elevated text-muted border-border",
                  "disabled:opacity-50 disabled:cursor-not-allowed",
                )}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 2L11 13" /><path d="M22 2L15 22L11 13L2 9L22 2Z" />
                </svg>
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
