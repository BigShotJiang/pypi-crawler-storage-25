import { useEffect, useRef } from "react";
import clsx from "clsx";
import { NODE_COLORS, LEFT_PANEL_WIDTH, CODE_PANEL_MIN_WIDTH } from "../constants";
import type { GraphNode } from "../types";

interface Props {
  filePath: string;
  content: string;
  nodeType: string;
  highlightStart: number | null;
  highlightEnd: number | null;
  infoNode: GraphNode | null;
  binary?: boolean;
  leftPanelOpen?: boolean;
  onClose: () => void;
}

export default function CodePanel({
  filePath,
  content,
  nodeType,
  highlightStart,
  highlightEnd,
  infoNode,
  binary = false,
  leftPanelOpen = false,
  onClose,
}: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const color = NODE_COLORS[nodeType] ?? "#94a3b8";

  useEffect(() => {
    if (highlightStart && scrollRef.current) {
      const el = scrollRef.current.querySelector(`#L${highlightStart}`);
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [highlightStart, content]);

  return (
    <div
      className="absolute top-0 z-30 flex flex-col h-full w-[40%] border-r border-border bg-bg overflow-hidden shadow-xl shadow-black/30 transition-[left] duration-300 ease-in-out"
      style={{
        left: leftPanelOpen ? LEFT_PANEL_WIDTH : 0,
        minWidth: CODE_PANEL_MIN_WIDTH,
        maxWidth: 600,
      }}
    >
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-surface shrink-0">
        <span
          className="text-[10px] px-1.5 py-0.5 rounded uppercase"
          style={{ background: `${color}22`, color }}
        >
          {nodeType}
        </span>
        <span className="flex-1 font-mono text-xs text-muted overflow-hidden text-ellipsis whitespace-nowrap">
          {filePath}
        </span>
        <button
          onClick={onClose}
          className="cursor-pointer text-muted hover:text-text text-sm p-1"
          aria-label="Close code panel"
        >
          &times;
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-auto font-mono text-[13px] leading-relaxed">
        {binary ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-muted">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mx-auto mb-3 opacity-40"
              >
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
                <line x1="9" y1="15" x2="15" y2="15" />
              </svg>
              <p className="text-sm">Binary file not displayed.</p>
            </div>
          </div>
        ) : infoNode ? (
          <InfoCard node={infoNode} />
        ) : (
          <table className="border-collapse w-full">
            <tbody>
              {content.split("\n").map((line, i) => {
                const lineNum = i + 1;
                const isHighlighted =
                  highlightStart != null &&
                  lineNum >= highlightStart &&
                  lineNum <= (highlightEnd ?? highlightStart);
                return (
                  <tr
                    key={lineNum}
                    id={`L${lineNum}`}
                    className={isHighlighted ? "bg-accent/10" : undefined}
                  >
                    <td
                      className={clsx(
                        "select-none text-right pr-4 pl-2 whitespace-pre border-r border-border",
                        isHighlighted ? "text-accent opacity-100" : "text-muted opacity-50",
                      )}
                      style={{ width: "1%" }}
                    >
                      {lineNum}
                    </td>
                    <td className="text-text px-2 whitespace-pre">{line}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function InfoCard({ node }: { node: GraphNode }) {
  const color = NODE_COLORS[node.nodeType] ?? "#94a3b8";
  return (
    <div className="m-4 p-4 bg-surface border border-border rounded-lg">
      <h3 className="text-base mb-2">{node.label}</h3>
      <div className="flex gap-2 py-1.5 text-sm border-b border-border">
        <span className="text-muted min-w-[100px]">Type</span>
        <span style={{ color }}>{node.nodeType}</span>
      </div>
      {node.filePath && (
        <div className="flex gap-2 py-1.5 text-sm border-b border-border">
          <span className="text-muted min-w-[100px]">Path</span>
          <span>{node.filePath}</span>
        </div>
      )}
    </div>
  );
}
