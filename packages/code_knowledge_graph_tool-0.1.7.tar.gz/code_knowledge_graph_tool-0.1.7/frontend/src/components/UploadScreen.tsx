import { useCallback, useRef, useState, useEffect } from "react";
import { Upload, CheckCircle2, AlertCircle, Loader2, GitBranch, Cloud } from "lucide-react";

type SourceTab = "local" | "git" | "cloud";

interface Props {
  status: "idle" | "uploading" | "done" | "error";
  messages: Array<{ text: string; isError: boolean }>;
  onAnalyze: (file: File) => void;
  onAnalyzeGit?: (url: string, branch?: string) => void;
  onAnalyzeUrl?: (url: string) => void;
}

export default function UploadScreen({ status, messages, onAnalyze, onAnalyzeGit, onAnalyzeUrl }: Props) {
  const [tab, setTab] = useState<SourceTab>("local");
  const [files, setFiles] = useState<File[]>([]);
  const [dragover, setDragover] = useState(false);
  const [gitUrl, setGitUrl] = useState("");
  const [gitBranch, setGitBranch] = useState("");
  const [cloudUrl, setCloudUrl] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const logEndRef = useRef<HTMLDivElement>(null);

  const addFiles = useCallback((incoming: FileList | File[]) => {
    const zips = Array.from(incoming).filter(f => f.name.endsWith(".zip"));
    if (zips.length > 0) setFiles(prev => [...prev, ...zips]);
  }, []);

  const removeFile = useCallback((idx: number) => {
    setFiles(prev => prev.filter((_, i) => i !== idx));
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragover(false);
      addFiles(e.dataTransfer.files);
    },
    [addFiles],
  );

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const isRunning = status === "uploading";
  const isDone = status === "done";
  const isError = status === "error";
  const hasMessages = messages.length > 0;

  const tabs: { id: SourceTab; label: string; icon: React.ReactNode }[] = [
    { id: "local", label: "Local", icon: <Upload size={14} /> },
    { id: "git", label: "Git", icon: <GitBranch size={14} /> },
    { id: "cloud", label: "Cloud", icon: <Cloud size={14} /> },
  ];

  // Show upload form when idle or no messages yet
  if (!hasMessages && !isRunning) {
    return (
      <div className="flex flex-col items-center">
        {/* Tabs */}
        <div className="flex w-full rounded-lg p-1 mb-5 gap-1" style={{ background: "rgba(255,255,255,0.03)" }}>
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-md text-xs font-medium transition-all duration-200 ${
                tab === t.id
                  ? "bg-accent/15 text-accent border border-accent/25"
                  : "text-muted hover:text-text border border-transparent"
              }`}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>

        {/* Local Upload */}
        {tab === "local" && (
          <>
            <div
              onDragOver={(e) => { e.preventDefault(); setDragover(true); }}
              onDragLeave={() => setDragover(false)}
              onDrop={handleDrop}
              className={`w-full border-2 border-dashed rounded-xl py-10 px-8 text-center cursor-pointer transition-all duration-200 ${
                dragover ? "border-accent bg-accent/5" : "border-border hover:border-accent/50"
              }`}
              onClick={() => inputRef.current?.click()}
            >
              <input
                ref={inputRef}
                type="file"
                accept=".zip"
                multiple
                className="hidden"
                onChange={(e) => { if (e.target.files) { addFiles(e.target.files); e.target.value = ""; } }}
              />
              <Upload size={28} className="mx-auto text-muted mb-3" />
              <p className="text-sm text-text font-medium mb-1">
                {files.length > 0
                  ? `${files.length} file${files.length > 1 ? "s" : ""} selected`
                  : "Drop .zip files here"}
              </p>
              <p className="text-xs text-muted">or click to browse — select multiple</p>
            </div>
            {files.length > 0 && (
              <div className="w-full mt-3 space-y-1.5">
                {files.map((f, i) => (
                  <div key={`${f.name}-${i}`} className="flex items-center justify-between px-3 py-2 rounded-lg border border-white/[0.06]" style={{ background: "rgba(255,255,255,0.02)" }}>
                    <div className="min-w-0">
                      <p className="text-xs text-text font-medium truncate">{f.name}</p>
                      <p className="text-[10px] text-muted font-mono">{(f.size / 1024 / 1024).toFixed(1)} MB</p>
                    </div>
                    <button
                      onClick={() => removeFile(i)}
                      className="text-muted hover:text-red-400 text-xs px-1.5 transition-colors shrink-0"
                      aria-label={`Remove ${f.name}`}
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
            <button
              disabled={files.length === 0}
              onClick={() => { files.forEach(f => onAnalyze(f)); setFiles([]); }}
              className="btn-primary mt-4 px-6 py-2.5 text-sm w-full disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {files.length > 1 ? `Analyze ${files.length} Codebases` : "Analyze Codebase"}
            </button>
          </>
        )}

        {/* Git Repository */}
        {tab === "git" && (
          <div className="w-full space-y-3">
            <div>
              <label className="block text-xs text-muted mb-1.5 font-medium">Repository URL</label>
              <input
                type="text"
                value={gitUrl}
                onChange={(e) => setGitUrl(e.target.value)}
                placeholder="https://github.com/user/repo.git"
                className="w-full px-4 py-2.5 rounded-lg text-sm text-text placeholder:text-muted/50 border border-border bg-transparent focus:border-accent/50 focus:outline-none transition-colors font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1.5 font-medium">Branch <span className="text-muted/50">(optional)</span></label>
              <input
                type="text"
                value={gitBranch}
                onChange={(e) => setGitBranch(e.target.value)}
                placeholder="main"
                className="w-full px-4 py-2.5 rounded-lg text-sm text-text placeholder:text-muted/50 border border-border bg-transparent focus:border-accent/50 focus:outline-none transition-colors font-mono"
              />
            </div>
            <p className="text-[11px] text-muted leading-relaxed">
              Supports GitHub, GitLab, Bitbucket, and any public Git URL. Private repos require accessible credentials on the server.
            </p>
            <button
              disabled={!gitUrl.trim()}
              onClick={() => onAnalyzeGit?.(gitUrl.trim(), gitBranch.trim() || undefined)}
              className="btn-primary mt-1 px-6 py-2.5 text-sm w-full disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Clone & Analyze
            </button>
          </div>
        )}

        {/* Cloud Storage */}
        {tab === "cloud" && (
          <div className="w-full space-y-3">
            <div className="flex gap-2 mb-1">
              {[
                { label: "S3", color: "text-orange-400 border-orange-400/20 bg-orange-400/5" },
                { label: "GCS", color: "text-blue-400 border-blue-400/20 bg-blue-400/5" },
                { label: "Azure", color: "text-cyan-400 border-cyan-400/20 bg-cyan-400/5" },
                { label: "URL", color: "text-accent border-accent/20 bg-accent/5" },
              ].map((p) => (
                <span key={p.label} className={`text-[10px] font-mono px-2 py-1 rounded border ${p.color}`}>
                  {p.label}
                </span>
              ))}
            </div>
            <div>
              <label className="block text-xs text-muted mb-1.5 font-medium">Archive URL</label>
              <input
                type="text"
                value={cloudUrl}
                onChange={(e) => setCloudUrl(e.target.value)}
                placeholder="https://storage.example.com/repo.zip"
                className="w-full px-4 py-2.5 rounded-lg text-sm text-text placeholder:text-muted/50 border border-border bg-transparent focus:border-accent/50 focus:outline-none transition-colors font-mono"
              />
            </div>
            <p className="text-[11px] text-muted leading-relaxed">
              Provide a direct link to a .zip archive. Supports S3 pre-signed URLs, GCS public links, Azure Blob SAS URLs, or any accessible HTTP URL.
            </p>
            <button
              disabled={!cloudUrl.trim()}
              onClick={() => onAnalyzeUrl?.(cloudUrl.trim())}
              className="btn-primary mt-1 px-6 py-2.5 text-sm w-full disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Download & Analyze
            </button>
          </div>
        )}
      </div>
    );
  }

  // Show ingestion progress
  return (
    <div className="flex flex-col gap-3">
      {/* Status header */}
      <div className="flex items-center gap-3 px-1">
        {isRunning && <Loader2 size={18} className="text-accent animate-spin" />}
        {isDone && <CheckCircle2 size={18} className="text-green-400" />}
        {isError && <AlertCircle size={18} className="text-red-400" />}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-text">
            {isRunning ? "Analyzing..." : isDone ? "Analysis Complete" : "Analysis Failed"}
          </p>
          <p className="text-[10px] text-muted">
            {messages.length} step{messages.length !== 1 ? "s" : ""} processed
          </p>
        </div>
        {isRunning && (
          <span className="text-[10px] font-mono text-accent bg-accent/10 border border-accent/20 px-2 py-0.5 rounded-full animate-pulse">
            LIVE
          </span>
        )}
      </div>

      {/* Progress bar */}
      {isRunning && (
        <div className="w-full h-1 rounded-full overflow-hidden" style={{ background: "var(--elevated)" }}>
          <div className="h-full bg-accent rounded-full animate-shimmer" style={{ width: "60%", transition: "width 500ms ease" }} />
        </div>
      )}

      {/* Log output */}
      <div
        className="rounded-lg border overflow-y-auto font-mono text-xs"
        style={{
          background: "rgba(0,0,0,0.3)",
          borderColor: "var(--border)",
          maxHeight: 240,
          minHeight: 120,
          scrollbarWidth: "thin",
        }}
      >
        <div className="px-3 py-2 space-y-0.5">
          {messages.map((msg, i) => (
            <div
              key={i}
              className="flex items-start gap-2 py-0.5"
              style={{ color: msg.isError ? "#f87171" : "#94a3b8" }}
            >
              <span className="shrink-0 select-none" style={{ color: msg.isError ? "#f87171" : "#00E599" }}>
                {msg.isError ? "✗" : "▸"}
              </span>
              <span className="break-all">{msg.text}</span>
            </div>
          ))}
          {isRunning && (
            <div className="flex items-center gap-2 py-0.5 text-accent">
              <span className="animate-pulse">▸</span>
              <span className="animate-pulse">waiting...</span>
            </div>
          )}
          <div ref={logEndRef} />
        </div>
      </div>

      {/* Done / Error actions */}
      {isDone && (
        <p className="text-xs text-green-400 text-center">Redirecting to graph...</p>
      )}
      {isError && (
        <button
          onClick={() => {
            if (tab === "local" && files.length > 0) files.forEach(f => onAnalyze(f));
            else if (tab === "git" && gitUrl.trim()) onAnalyzeGit?.(gitUrl.trim(), gitBranch.trim() || undefined);
            else if (tab === "cloud" && cloudUrl.trim()) onAnalyzeUrl?.(cloudUrl.trim());
          }}
          className="btn-primary px-4 py-2 text-sm w-full"
        >
          Retry
        </button>
      )}
    </div>
  );
}
