import { useEffect, useState } from "react";
import { X, Keyboard } from "lucide-react";

const SHORTCUTS = [
  { keys: "Ctrl + K", desc: "Search nodes" },
  { keys: "[", desc: "Toggle file panel" },
  { keys: "]", desc: "Toggle details panel" },
  { keys: "Escape", desc: "Close active panel / clear selection" },
  { keys: "?", desc: "Show this help" },
];

export default function KeyboardHelp() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "?" && !e.ctrlKey && !e.metaKey) {
        const tag = (e.target as HTMLElement)?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
        e.preventDefault();
        setOpen((v) => !v);
      }
      if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={() => setOpen(false)}>
      <div className="glass-card p-6 w-full max-w-sm shadow-2xl" onClick={(e) => e.stopPropagation()} style={{ background: "rgba(14,31,48,0.95)" }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Keyboard size={16} className="text-accent" />
            <h2 className="text-sm font-semibold text-text">Keyboard Shortcuts</h2>
          </div>
          <button onClick={() => setOpen(false)} aria-label="Close" className="text-muted hover:text-text transition-colors">
            <X size={16} />
          </button>
        </div>
        <div className="space-y-2">
          {SHORTCUTS.map(({ keys, desc }) => (
            <div key={keys} className="flex items-center justify-between py-1.5 border-b border-white/[0.04] last:border-0">
              <span className="text-sm text-muted">{desc}</span>
              <kbd className="px-2 py-0.5 rounded text-xs font-mono bg-elevated border border-border text-text">{keys}</kbd>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
