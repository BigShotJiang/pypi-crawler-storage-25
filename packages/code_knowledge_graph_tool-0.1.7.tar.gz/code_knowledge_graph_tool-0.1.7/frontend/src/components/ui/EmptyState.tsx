import type { LucideIcon } from "lucide-react";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
  compact?: boolean;
}

export default function EmptyState({ icon: Icon, title, description, action, compact }: EmptyStateProps) {
  return (
    <div className={`flex flex-col items-center justify-center text-center ${compact ? "py-8" : "py-16"}`}>
      <div className={`relative flex items-center justify-center mb-4 ${compact ? "" : "w-20 h-20"}`}>
        {!compact && (
          <div className="absolute inset-0 rounded-full border-2 border-dashed border-muted/20 animate-pulse2s" />
        )}
        <div className={`${compact ? "w-10 h-10" : "w-14 h-14"} rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center`}>
          <Icon size={compact ? 18 : 24} className="text-accent" />
        </div>
      </div>
      <p className={`font-semibold text-text ${compact ? "text-sm mb-0.5" : "text-lg mb-1"}`}>{title}</p>
      {description && (
        <p className={`text-muted max-w-sm leading-relaxed ${compact ? "text-xs" : "text-sm mb-6"}`}>
          {description}
        </p>
      )}
      {action && <div className={compact ? "mt-3" : "mt-2"}>{action}</div>}
    </div>
  );
}
