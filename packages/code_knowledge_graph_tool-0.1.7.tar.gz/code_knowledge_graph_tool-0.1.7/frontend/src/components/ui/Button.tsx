import { forwardRef } from "react";
import { Loader2 } from "lucide-react";
import clsx from "clsx";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "icon";
type Size = "sm" | "md" | "lg";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
}

const variantStyles: Record<Variant, string> = {
  primary:
    "bg-accent text-bgBase font-semibold hover:bg-accent-hover hover:shadow-[0_0_20px_rgba(0,229,153,0.25)] active:scale-[0.98]",
  secondary:
    "bg-transparent text-text border border-white/10 hover:bg-white/5 hover:border-white/20",
  ghost:
    "bg-transparent text-muted hover:text-text hover:bg-white/5",
  danger:
    "bg-danger/10 text-danger border border-danger/20 hover:bg-danger/20",
  icon:
    "bg-surface/85 text-text border border-border backdrop-blur-md hover:border-accent hover:text-accent",
};

const sizeStyles: Record<Size, string> = {
  sm: "px-3 py-1.5 text-xs gap-1.5 rounded-md",
  md: "px-5 py-2.5 text-sm gap-2 rounded-md",
  lg: "px-6 py-3 text-sm gap-2 rounded-md",
};

const iconSizeStyles: Record<Size, string> = {
  sm: "w-7 h-7 rounded-md text-xs",
  md: "w-[34px] h-[34px] rounded-lg text-sm",
  lg: "w-10 h-10 rounded-lg text-base",
};

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", size = "md", loading, icon, children, className, disabled, ...props }, ref) => {
    const isIcon = variant === "icon";
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={clsx(
          "inline-flex items-center justify-center transition-all duration-200 cursor-pointer",
          "disabled:opacity-40 disabled:cursor-not-allowed disabled:pointer-events-none",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-1 focus-visible:ring-offset-bg",
          variantStyles[variant],
          isIcon ? iconSizeStyles[size] : sizeStyles[size],
          className,
        )}
        {...props}
      >
        {loading ? <Loader2 size={isIcon ? 16 : 14} className="animate-spin" /> : icon}
        {!isIcon && children}
      </button>
    );
  },
);

Button.displayName = "Button";
export default Button;
