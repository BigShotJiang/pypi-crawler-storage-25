import clsx from "clsx";

interface SkeletonProps {
  variant?: "text" | "card" | "row" | "circle";
  className?: string;
  count?: number;
}

const variantStyles: Record<string, string> = {
  text: "h-4 rounded-md",
  card: "h-24 rounded-2xl",
  row: "h-16 rounded-xl",
  circle: "w-10 h-10 rounded-full",
};

export default function Skeleton({ variant = "text", className, count = 1 }: SkeletonProps) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className={clsx(
            "shimmer-bg border border-white/[0.06]",
            variantStyles[variant],
            className,
          )}
        />
      ))}
    </>
  );
}
