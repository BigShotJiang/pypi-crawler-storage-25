import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

export interface Crumb {
  label: string;
  to?: string;
}

interface Props {
  items: Crumb[];
}

export default function Breadcrumb({ items }: Props) {
  if (items.length === 0) return null;
  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1 text-xs text-muted">
      {items.map((item, i) => {
        const isLast = i === items.length - 1;
        return (
          <span key={i} className="flex items-center gap-1">
            {i > 0 && <ChevronRight size={12} className="text-muted/40" />}
            {isLast || !item.to ? (
              <span className={isLast ? "text-text font-medium" : ""}>{item.label}</span>
            ) : (
              <Link to={item.to} className="hover:text-accent transition-colors">{item.label}</Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}
