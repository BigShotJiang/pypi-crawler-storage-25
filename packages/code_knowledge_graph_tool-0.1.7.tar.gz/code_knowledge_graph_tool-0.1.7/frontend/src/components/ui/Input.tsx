import { forwardRef } from "react";
import clsx from "clsx";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  variant?: "default" | "mono";
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ variant = "default", className, ...props }, ref) => {
    return (
      <input
        ref={ref}
        className={clsx(
          "w-full px-4 py-2.5 rounded-lg text-sm text-text placeholder:text-muted/50",
          "bg-transparent border border-border",
          "focus:border-accent/50 focus:outline-none focus:ring-1 focus:ring-accent/20",
          "transition-colors duration-150",
          "disabled:opacity-50 disabled:cursor-not-allowed",
          variant === "mono" && "font-mono",
          className,
        )}
        {...props}
      />
    );
  },
);

Input.displayName = "Input";
export default Input;

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  variant?: "default" | "mono";
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ variant = "default", className, ...props }, ref) => {
    return (
      <textarea
        ref={ref}
        className={clsx(
          "w-full px-4 py-2.5 rounded-lg text-sm text-text placeholder:text-muted/50",
          "bg-transparent border border-border resize-none",
          "focus:border-accent/50 focus:outline-none focus:ring-1 focus:ring-accent/20",
          "transition-colors duration-150",
          "disabled:opacity-50 disabled:cursor-not-allowed",
          variant === "mono" && "font-mono",
          className,
        )}
        {...props}
      />
    );
  },
);

Textarea.displayName = "Textarea";
