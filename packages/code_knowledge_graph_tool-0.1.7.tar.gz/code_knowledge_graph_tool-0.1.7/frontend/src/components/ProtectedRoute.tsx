import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute() {
  const { initializing, isAuthenticated } = useAuth();
  const location = useLocation();

  if (initializing) {
    return (
      <div className="min-h-screen bg-[#050A0F] flex items-center justify-center px-6">
        <div className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#0b1522]/90 backdrop-blur-md p-6 text-center">
          <div className="w-10 h-10 mx-auto rounded-full border-2 border-[#1a3548] border-t-[#00E599] animate-spin mb-4" />
          <p className="text-white font-medium">Restoring session</p>
          <p className="text-[#6b8fa8] text-sm mt-1">Checking your account state...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <Outlet />;
}
