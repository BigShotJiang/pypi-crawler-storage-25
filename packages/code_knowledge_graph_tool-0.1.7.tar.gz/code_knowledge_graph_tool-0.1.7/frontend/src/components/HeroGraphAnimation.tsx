const NODES = [
  { cx: 120, cy: 80, r: 6, delay: 0 },
  { cx: 280, cy: 50, r: 4, delay: 0.8 },
  { cx: 400, cy: 120, r: 7, delay: 1.6 },
  { cx: 180, cy: 200, r: 5, delay: 0.4 },
  { cx: 350, cy: 220, r: 6, delay: 1.2 },
  { cx: 500, cy: 60, r: 4, delay: 2.0 },
  { cx: 60, cy: 160, r: 5, delay: 0.6 },
  { cx: 450, cy: 180, r: 5, delay: 1.8 },
  { cx: 240, cy: 140, r: 8, delay: 1.0 },
  { cx: 540, cy: 140, r: 4, delay: 1.4 },
];

const EDGES: [number, number][] = [
  [0, 3], [0, 1], [1, 2], [1, 8], [2, 4], [2, 5],
  [3, 6], [3, 8], [4, 7], [4, 8], [5, 9], [7, 9],
];

export default function HeroGraphAnimation() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30 hidden md:block">
      <svg
        viewBox="0 0 600 280"
        fill="none"
        className="w-full h-full"
        preserveAspectRatio="xMidYMid slice"
      >
        {EDGES.map(([from, to], i) => {
          const a = NODES[from]!;
          const b = NODES[to]!;
          return (
          <line
            key={i}
            x1={a.cx}
            y1={a.cy}
            x2={b.cx}
            y2={b.cy}
            stroke="rgba(0,229,153,0.2)"
            strokeWidth="1"
            strokeDasharray="4 4"
          >
            <animate
              attributeName="stroke-dashoffset"
              from="0"
              to="-16"
              dur={`${3 + i * 0.3}s`}
              repeatCount="indefinite"
            />
          </line>
        );})}
        {NODES.map((node, i) => (
          <g key={i}>
            <circle
              cx={node.cx}
              cy={node.cy}
              r={node.r * 2.5}
              fill="rgba(0,229,153,0.06)"
            >
              <animate
                attributeName="r"
                values={`${node.r * 2};${node.r * 3};${node.r * 2}`}
                dur="4s"
                begin={`${node.delay}s`}
                repeatCount="indefinite"
              />
            </circle>
            <circle
              cx={node.cx}
              cy={node.cy}
              r={node.r}
              fill="rgba(0,229,153,0.5)"
            >
              <animate
                attributeName="cy"
                values={`${node.cy};${node.cy - 6};${node.cy}`}
                dur="6s"
                begin={`${node.delay}s`}
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.5;0.9;0.5"
                dur="3s"
                begin={`${node.delay}s`}
                repeatCount="indefinite"
              />
            </circle>
          </g>
        ))}
      </svg>
    </div>
  );
}
