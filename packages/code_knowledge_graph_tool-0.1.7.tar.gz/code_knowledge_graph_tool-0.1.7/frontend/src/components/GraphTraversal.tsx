import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useNavigate } from "react-router-dom";

const NODES = [
  {
    id: "root",
    side: "center" as const,
    tag: "Root",
    title: "CKG Engine",
    body: null,
    accent: true,
  },
  {
    id: "architecture",
    side: "right" as const,
    tag: "Phase 03: Architecture",
    title: "4-Layer Ingestion",
    list: [
      { label: "L0:", text: "File & Folder maps" },
      { label: "L1:", text: "AST Specific Relational" },
      { label: "L2:", text: "I/O Execution flow" },
      { label: "L3:", text: "Semantic code embeddings" },
    ],
  },
  {
    id: "capabilities",
    side: "left" as const,
    tag: "Phase 04: Capabilities",
    title: "Agentic Superpowers",
    list: [
      { label: "•", text: "Pre-commit Blast Radius" },
      { label: "•", text: "Smart Context Retrieval" },
      { label: "•", text: "Structural AST Rename" },
    ],
  },
  {
    id: "deploy",
    side: "center" as const,
    tag: "Final Phase",
    title: "Initialize the Engine",
    body: null,
    cta: true,
  },
];

const SEGMENT = 1 / NODES.length;

export default function GraphTraversal() {
  const navigate = useNavigate();
  const trackRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: trackRef,
    offset: ["start start", "end end"],
  });

  const lineHeight = useTransform(scrollYProgress, [0, 0.95], ["0%", "100%"]);

  return (
    <div ref={trackRef} className="h-[500vh] w-full bg-bgBase relative">
      <div className="sticky top-0 h-screen w-full overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none opacity-[0.08]"
          style={{
            backgroundImage:
              "linear-gradient(to right, #00E599 1px, transparent 1px), linear-gradient(to bottom, #00E599 1px, transparent 1px)",
            backgroundSize: "50px 50px",
            maskImage:
              "radial-gradient(circle at center, black, transparent 80%)",
            WebkitMaskImage:
              "radial-gradient(circle at center, black, transparent 80%)",
          }}
        />

        <div className="absolute left-1/2 top-[10%] bottom-[10%] w-px -translate-x-1/2">
          <div className="absolute inset-0 bg-white/5" />
          <motion.div
            className="absolute top-0 left-0 w-full bg-brand shadow-[0_0_8px_rgba(0,229,153,0.4)]"
            style={{ height: lineHeight }}
          />
          <motion.div
            className="absolute left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-brand shadow-[0_0_12px_rgba(0,229,153,0.6)]"
            style={{ top: lineHeight }}
          />
        </div>

        {NODES.map((node, i) => {
          const enter = i * SEGMENT;
          const peak = enter + SEGMENT * 0.5;
          const exit = Math.min(enter + SEGMENT * 1.5, 1);

          return (
            <NodeCard
              key={node.id}
              node={node}
              index={i}
              total={NODES.length}
              scrollYProgress={scrollYProgress}
              enter={enter}
              peak={peak}
              exit={exit}
              onNavigate={() => navigate("/dashboard")}
            />
          );
        })}
      </div>
    </div>
  );
}

interface NodeCardProps {
  node: (typeof NODES)[number];
  index: number;
  total: number;
  scrollYProgress: ReturnType<typeof useScroll>["scrollYProgress"];
  enter: number;
  peak: number;
  exit: number;
  onNavigate: () => void;
}

function NodeCard({
  node,
  index,
  total,
  scrollYProgress,
  enter,
  peak,
  exit,
  onNavigate,
}: NodeCardProps) {
  const isLast = index === total - 1;
  const opacity = useTransform(
    scrollYProgress,
    isLast
      ? [enter, enter + 0.06, 1]
      : [enter, enter + 0.06, exit - 0.04, exit],
    isLast ? [0, 1, 1] : [0, 1, 1, 0.15]
  );

  const scale = useTransform(
    scrollYProgress,
    [enter, enter + 0.06],
    [0.85, 1]
  );

  const yPercent = useTransform(
    scrollYProgress,
    [enter, peak, exit],
    [55, 50 - index * 2, 50 - index * 2 - 15]
  );

  const xClass =
    node.side === "left"
      ? "right-[52%] pr-12"
      : node.side === "right"
        ? "left-[52%] pl-12"
        : "left-1/2 -translate-x-1/2";

  const isCenter = node.side === "center";
  const isDanger = "danger" in node && (node as Record<string, unknown>).danger;
  const isCta = "cta" in node && node.cta;
  const isAccent = "accent" in node && node.accent;

  return (
    <motion.div
      className={`absolute w-96 z-10 ${xClass}`}
      style={{
        opacity,
        scale,
        top: useTransform(yPercent, (v) => `${v}%`),
      }}
    >
      <div
        className={`absolute top-6 w-4 h-4 rounded-full border-2 border-brand bg-bgBase z-20 ${
          node.side === "left"
            ? "-right-[2.55rem]"
            : node.side === "right"
              ? "-left-[2.55rem]"
              : "left-1/2 -translate-x-1/2 -top-6"
        }`}
      />

      {!isCenter && (
        <div
          className={`absolute top-[1.65rem] h-px bg-brand/40 w-8 ${
            node.side === "left" ? "-right-8" : "-left-8"
          }`}
        />
      )}

      {isAccent ? (
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-bgCard border-2 border-brand rounded-full flex items-center justify-center relative shadow-[0_0_30px_rgba(0,229,153,0.3)]">
            <div className="w-8 h-8 bg-brand/20 rounded-full flex items-center justify-center">
              <svg
                className="w-4 h-4 text-brand"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 10V3L4 14h7v7l9-11h-7z"
                />
              </svg>
            </div>
            <div className="absolute inset-0 rounded-full border border-brand animate-ping opacity-30" />
          </div>
          <h2 className="text-white font-bold mt-4 text-xl tracking-tight">
            {node.title}
          </h2>
          <p className="text-brand font-mono text-[10px] uppercase mt-1 tracking-widest bg-brand/10 px-2 py-0.5 rounded">
            Active
          </p>
        </div>
      ) : isCta ? (
        <div className="bg-brand/10 backdrop-blur-md border border-brand p-6 rounded-xl text-center shadow-[0_0_30px_rgba(0,229,153,0.15)]">
          <div className="text-brand font-mono text-[10px] mb-2 uppercase tracking-widest">
            [ {node.tag} ]
          </div>
          <h3 className="text-xl font-bold text-white mb-4">{node.title}</h3>
          <button
            onClick={onNavigate}
            className="px-6 py-2 bg-brand text-bgBase font-bold rounded hover:bg-white transition-colors"
          >
            Deploy CKG to Workspace
          </button>
        </div>
      ) : (
        <div
          className={`bg-bgCard/90 backdrop-blur-md border ${
            isDanger ? "border-red-500/30" : "border-brand/30"
          } p-6 rounded-xl`}
        >
          <div
            className={`${
              isDanger ? "text-red-400" : "text-brand"
            } font-mono text-[10px] mb-2 uppercase tracking-widest`}
          >
            [ {node.tag} ]
          </div>
          <h3 className="text-lg font-bold text-white mb-2">{node.title}</h3>
          {("body" in node && (node as unknown as { body?: string | null }).body) && (
            <p className="text-sm text-gray-400">{(node as unknown as { body: string }).body}</p>
          )}
          {"list" in node && node.list && (
            <ul className="text-sm text-gray-400 space-y-1">
              {node.list.map((item, j) => (
                <li key={j}>
                  <span className="text-white">{item.label}</span> {item.text}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </motion.div>
  );
}
