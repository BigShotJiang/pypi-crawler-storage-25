import React, { useCallback, useEffect, useRef, useState } from "react";
import type { AnalysisResult, GraphNode } from "../types";
import { useGraphState } from "../hooks/useGraphState";
import { fetchFileContent } from "../api";
import { NON_CODE_TYPES } from "../constants";
import LeftPanel from "./left-panel/LeftPanel";
import CodePanel from "./CodePanel";
import GraphView from "./graph/GraphView";
import FloatingLegend from "./graph/FloatingLegend";
import QueryFAB from "./graph/QueryFAB";
import RightPanel from "./right-panel/RightPanel";
import KeyboardHelp from "./ui/KeyboardHelp";

class GraphErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 32, color: "#f87171", background: "#0d1117", fontFamily: "monospace", fontSize: 13, overflow: "auto", height: "100%" }}>
          <p style={{ fontWeight: "bold", fontSize: 16, marginBottom: 8 }}>Graph Render Error</p>
          <p>{this.state.error.message}</p>
          <pre style={{ marginTop: 12, opacity: 0.6, whiteSpace: "pre-wrap" }}>{this.state.error.stack}</pre>
        </div>
      );
    }
    return this.props.children;
  }
}

interface Props {
  result: AnalysisResult;
  focusNodeId: string | null;
  onFocusNodeConsumed: () => void;
  searchHighlightIds: Set<string>;
  searchEndpointIds: Set<string>;
  onFilterPassIdsChange: (ids: Set<string>) => void;
}

export default function Workspace({
  result,
  focusNodeId,
  onFocusNodeConsumed,
  searchHighlightIds,
  searchEndpointIds,
  onFilterPassIdsChange,
}: Props) {
  const { graph, file_tree } = result;
  const graphState = useGraphState(graph.nodes, graph.edges);

  const [leftOpen, setLeftOpen] = useState(false);
  const [rightOpen, setRightOpen] = useState(false);

  const [codeState, setCodeState] = useState<{
    visible: boolean;
    filePath: string;
    content: string;
    nodeType: string;
    highlightStart: number | null;
    highlightEnd: number | null;
    infoNode: GraphNode | null;
    binary: boolean;
  }>({
    visible: false,
    filePath: "",
    content: "",
    nodeType: "",
    highlightStart: null,
    highlightEnd: null,
    infoNode: null,
    binary: false,
  });

  const openFile = useCallback(async (filePath: string) => {
    setCodeState((prev) => ({
      ...prev,
      visible: true,
      filePath,
      content: "Loading...",
      nodeType: "File",
      highlightStart: null,
      highlightEnd: null,
      infoNode: null,
      binary: false,
    }));
    try {
      const result = await fetchFileContent(filePath);
      setCodeState((prev) => ({ ...prev, content: result.content, binary: result.binary }));
    } catch {
      setCodeState((prev) => ({ ...prev, content: "Failed to load file" }));
    }
  }, []);

  const openNodeInCode = useCallback(async (node: GraphNode) => {
    if (!node.filePath || NON_CODE_TYPES.has(node.nodeType)) {
      setCodeState({
        visible: true,
        filePath: node.label,
        content: "",
        nodeType: node.nodeType,
        highlightStart: null,
        highlightEnd: null,
        infoNode: node,
        binary: false,
      });
      return;
    }
    setCodeState({
      visible: true,
      filePath: node.filePath,
      content: "Loading...",
      nodeType: node.nodeType,
      highlightStart: node.startLine,
      highlightEnd: node.endLine,
      infoNode: null,
      binary: false,
    });
    try {
      const result = await fetchFileContent(node.filePath);
      setCodeState((prev) => ({ ...prev, content: result.content, binary: result.binary }));
    } catch {
      setCodeState((prev) => ({ ...prev, content: "Failed to load file" }));
    }
  }, []);

  // When search targets a filtered-out node, unhide its type so it becomes visible
  useEffect(() => {
    if (focusNodeId) {
      graphState.ensureNodeVisible(focusNodeId);
    }
  }, [focusNodeId, graphState.ensureNodeVisible]);

  // Report filterPassIds up to GraphPage for SearchBar scope toggle
  useEffect(() => {
    onFilterPassIdsChange(graphState.filterPassIds);
  }, [graphState.filterPassIds, onFilterPassIdsChange]);

  // Apply search highlights (path finding / reverse deps) from SearchBar
  useEffect(() => {
    if (searchHighlightIds.size > 0) {
      graphState.setHighlightedNodeIds(searchHighlightIds);
    } else {
      graphState.clearHighlightedNodeIds();
    }
  }, [searchHighlightIds, graphState.setHighlightedNodeIds, graphState.clearHighlightedNodeIds]);

  const prevSelectedRef = useRef<GraphNode | null>(null);

  useEffect(() => {
    if (graphState.selectedNode) {
      openNodeInCode(graphState.selectedNode);
      // Batch panel opens to avoid separate re-renders
      setLeftOpen((prev) => { if (!prev) setRightOpen(true); return true; });
    } else if (prevSelectedRef.current) {
      // Selection was cleared — close panels and code viewer
      setRightOpen(false);
      setLeftOpen(false);
      setCodeState((prev) => ({ ...prev, visible: false }));
    }
    prevSelectedRef.current = graphState.selectedNode;
  }, [graphState.selectedNode, openNodeInCode]);

  const closeCodePanel = useCallback(() => {
    setCodeState((prev) => ({ ...prev, visible: false }));
  }, []);

  // Keyboard shortcuts for panel toggling
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;

      if (e.key === "[") {
        e.preventDefault();
        setLeftOpen((v) => !v);
      } else if (e.key === "]") {
        e.preventDefault();
        setRightOpen((v) => !v);
      } else if (e.key === "Escape") {
        if (codeState.visible) {
          closeCodePanel();
        } else if (graphState.selectedNodeId) {
          graphState.clearSelection();
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [codeState.visible, closeCodePanel, graphState.selectedNodeId, graphState.clearSelection]);

  return (
    <GraphErrorBoundary>
    <div className="relative flex-1 overflow-hidden">
        <GraphView
          nodes={graph.nodes}
          edges={graph.edges}
          selectedNodeId={graphState.selectedNodeId}
          filterPassIds={graphState.filterPassIds}
          visibleNodeIds={graphState.visibleNodeIds}
          processStepIds={graphState.processStepIds}
          hiddenEdgeTypes={graphState.hiddenEdgeTypes}
          depthFilter={graphState.depthFilter}
          communityColorMode={graphState.communityColorMode}
          groupByCommunity={graphState.groupByCommunity}
          communities={result.communities}
          communityMembers={result.community_members}
          focusNodeId={focusNodeId}
          onFocusNodeConsumed={onFocusNodeConsumed}
          onSelectNode={graphState.selectNode}
          onClearSelection={graphState.clearSelection}
          onToggleCommunityColor={graphState.toggleCommunityColorMode}
          onToggleGroupByCommunity={graphState.toggleGroupByCommunity}
          highlightedNodeIds={graphState.highlightedNodeIds}
          highlightEndpointIds={searchEndpointIds}
          repoId={result.repo_id}
          rightPanelOpen={rightOpen}
        />

        <LeftPanel
          open={leftOpen}
          onClose={() => setLeftOpen((v) => !v)}
          fileTree={file_tree}
          graphNodes={graph.nodes}
          graphEdges={graph.edges}
          hiddenNodeTypes={graphState.hiddenNodeTypes}
          hiddenEdgeTypes={graphState.hiddenEdgeTypes}
          depthFilter={graphState.depthFilter}
          showAll={graphState.showAll}
          onToggleNodeType={graphState.toggleNodeType}
          onToggleEdgeType={graphState.toggleEdgeType}
          onSetDepthFilter={graphState.setDepthFilter}
          onToggleShowAll={graphState.toggleShowAll}
          onOpenFile={openFile}
        />

        <div
          className="absolute bottom-4 z-[31] flex flex-col gap-2"
          style={{
            left: leftOpen ? "296px" : "16px",
            transition: "left 300ms ease-in-out",
          }}
        >
          <FloatingLegend
            nodes={graph.nodes}
            edges={graph.edges}
            hiddenNodeTypes={graphState.hiddenNodeTypes}
            hiddenEdgeTypes={graphState.hiddenEdgeTypes}
            onToggleNodeType={graphState.toggleNodeType}
            onToggleEdgeType={graphState.toggleEdgeType}
          />
          <QueryFAB
            repoId={result.repo_id}
            onHighlightNodes={graphState.setHighlightedNodeIds}
            onClearHighlights={graphState.clearHighlightedNodeIds}
            highlightedCount={graphState.highlightedNodeIds.size}
          />
        </div>

        {codeState.visible && (
          <CodePanel
            filePath={codeState.filePath}
            content={codeState.content}
            nodeType={codeState.nodeType}
            highlightStart={codeState.highlightStart}
            highlightEnd={codeState.highlightEnd}
            infoNode={codeState.infoNode}
            binary={codeState.binary}
            leftPanelOpen={leftOpen}
            onClose={closeCodePanel}
          />
        )}

        {/* Details panel toggle — floats on graph */}
        <button
          onClick={() => setRightOpen((v) => !v)}
          aria-label={rightOpen ? "Close details panel" : "Open details panel"}
          className="absolute z-[26] flex items-center justify-center cursor-pointer"
          style={{
            top: 12,
            right: rightOpen ? 352 : 12,
            transition: "right 300ms ease-in-out",
            width: 34,
            height: 34,
            background: rightOpen ? "var(--accent)" : "rgba(22,27,34,0.85)",
            border: `1px solid ${rightOpen ? "var(--accent)" : "var(--border)"}`,
            borderRadius: 8,
            color: rightOpen ? "#fff" : "var(--text)",
            fontSize: "0.75rem",
            backdropFilter: "blur(12px)",
          }}
        >
          {rightOpen ? "\u2715" : "\u2630"}
        </button>

        {/* Details panel — absolute overlay, rightmost */}
        <RightPanel
          open={rightOpen}
          result={result}
          selectedNode={graphState.selectedNode}
          graphNodes={graph.nodes}
          graphEdges={graph.edges}
          focusedProcessId={graphState.focusedProcessId}
          onSelectNode={graphState.selectNode}
          onOpenFile={openFile}
          onToggleProcessFocus={graphState.toggleProcessFocus}
          onClose={() => setRightOpen(false)}
        />
      <KeyboardHelp />
    </div>
    </GraphErrorBoundary>
  );
}
