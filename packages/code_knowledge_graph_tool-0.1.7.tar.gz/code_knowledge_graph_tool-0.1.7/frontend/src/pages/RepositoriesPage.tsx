import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { CheckCircle2, Trash2, Plus, PlayCircle, X, Clock, FolderGit2, Code2 } from "lucide-react";
import { useRepos } from "../hooks/useRepos";
import { useIngestion } from "../context/IngestionContext";
import type { IngestionJob } from "../context/IngestionContext";
import { useToast } from "../components/ui/Toast";
import UploadScreen from "../components/UploadScreen";
import { PageContainer, AnimatedCard } from "../components/PageTransition";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

/* ──────────────────────────────────────────────────────────
 *  Ingestion Background Card — non-interactive progress box
 * ────────────────────────────────────────────────────────── */
function IngestionCard({
  job,
  onCancel,
}: {
  job: IngestionJob;
  onCancel: () => void;
}) {
  const startedRef = useRef(Date.now());
  const [elapsed, setElapsed] = useState("just now");

  const progress =
    job.status === "done" ? 100 : job.status === "error" ? 0 : Math.min(95, job.messages.length * 8 + 5);

  useEffect(() => {
    const id = setInterval(() => {
      const diff = Date.now() - startedRef.current;
      const mins = Math.floor(diff / 60000);
      setElapsed(mins < 1 ? "just now" : `${mins}m ago`);
    }, 30_000);
    return () => clearInterval(id);
  }, []);

  const lastMsg = job.messages[job.messages.length - 1];
  const lastMessage = lastMsg ? lastMsg.text : "Preparing...";

  const shortHash = useRef(Math.random().toString(16).slice(2, 12)).current;

  return (
    <div
      className="glass-card px-6 py-5 select-none"
      style={{ pointerEvents: "none", opacity: job.status === "error" ? 0.6 : 1 }}
    >
      <div style={{ pointerEvents: "auto" }}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
              <Code2 size={18} className="text-blue-400" />
            </div>
            <div className="min-w-0">
              <p className="text-text font-semibold truncate">{job.name}</p>
              <p className="text-muted text-xs font-mono">{shortHash}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {job.status === "uploading" && (
              <span className="flex items-center gap-1.5 text-xs font-medium text-blue-400 bg-blue-500/10 px-3 py-1 rounded-full font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                Indexing
              </span>
            )}
            {job.status === "done" && (
              <span className="flex items-center gap-1.5 text-xs font-medium text-accent bg-accent/10 px-3 py-1 rounded-full font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                Done
              </span>
            )}
            {job.status === "error" && (
              <span className="flex items-center gap-1.5 text-xs font-medium text-red-400 bg-red-500/10 px-3 py-1 rounded-full font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                Failed
              </span>
            )}
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full h-1.5 rounded-full overflow-hidden mb-2" style={{ background: "rgba(255,255,255,0.06)" }}>
          <div
            className="h-full rounded-full transition-[width] duration-700 ease-out"
            style={{
              width: `${progress}%`,
              background:
                job.status === "error"
                  ? "var(--danger)"
                  : "linear-gradient(90deg, #00E599, #38bdf8)",
            }}
          />
        </div>

        {/* Status text */}
        <p className="text-muted text-xs mb-3 truncate">{lastMessage}</p>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted/70 flex items-center gap-1.5">
            <Clock size={11} /> {elapsed}
          </span>
          <button
            onClick={onCancel}
            aria-label="Cancel ingestion"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-muted border border-white/[0.06] rounded-lg hover:text-red-400 hover:border-red-400/30 transition-colors"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function RepositoriesPage() {
  const { repos, loading, refresh, removeRepo } = useRepos();
  const [showUpload, setShowUpload] = useState(false);
  const [removing, setRemoving] = useState<string | null>(null);
  const navigate = useNavigate();
  const { jobs, startAnalysis, startGitAnalysis, startUrlAnalysis, cancelJob } = useIngestion();
  const { toast } = useToast();

  // Track which completed jobs have already triggered navigation
  const navigatedRef = useRef<Set<string>>(new Set());

  const activeJobs = jobs.filter(j => j.status === "uploading");
  const visibleJobs = jobs.filter(j => j.status !== "cancelled" && (j.status !== "done" || !navigatedRef.current.has(j.id)));

  // Close modal when any ingestion starts
  useEffect(() => {
    if (activeJobs.length > 0 && showUpload) {
      setShowUpload(false);
    }
  }, [activeJobs.length, showUpload]);

  // Refresh repo list when page regains focus
  useEffect(() => {
    const onFocus = () => refresh();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [refresh]);

  // Navigate to graph when a job completes
  useEffect(() => {
    const doneJob = jobs.find(j => j.status === "done" && j.result?.repo_id && !navigatedRef.current.has(j.id));
    if (!doneJob) return;

    const repoId = doneJob.result!.repo_id;
    navigatedRef.current.add(doneJob.id);

    const timer = setTimeout(() => {
      cancelJob(doneJob.id);
      refresh();
      navigate(`/graph/${repoId}`, { state: { analysisResult: doneJob.result } });
    }, 1200);
    return () => clearTimeout(timer);
  }, [jobs, navigate, refresh, cancelJob]);

  const handleRemove = async (id: string) => {
    setRemoving(id);
    try {
      await removeRepo(id);
      toast("Repository removed", "success");
    } catch {
      toast("Failed to remove repository", "error");
    } finally {
      setRemoving(null);
    }
  };

  const handleAnalyze = (file: File) => startAnalysis(file);
  const handleAnalyzeGit = (url: string, branch?: string) => startGitAnalysis(url, branch);
  const handleAnalyzeUrl = (url: string) => startUrlAnalysis(url);

  return (
    <PageContainer>
      <AnimatedCard className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-text">Codebase Manager</h2>
          <p className="text-muted text-sm mt-0.5">Import codebases and explore their knowledge graphs</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn-secondary px-4 py-2.5 text-sm">
            <PlayCircle size={15} /> Tutorial
          </button>
          <button
            onClick={() => setShowUpload(true)}
            className="btn-primary px-5 py-2.5 text-sm"
          >
            <Plus size={15} /> New Repository
          </button>
        </div>
      </AnimatedCard>

      {/* Ingestion background cards */}
      {visibleJobs.length > 0 && (
        <div className="space-y-3 mb-3">
          {visibleJobs.map(job => (
            <AnimatedCard key={job.id}>
              <IngestionCard job={job} onCancel={() => cancelJob(job.id)} />
            </AnimatedCard>
          ))}
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <AnimatedCard key={i}>
              <div className="shimmer-bg rounded-2xl h-24 border border-white/[0.06]" />
            </AnimatedCard>
          ))}
        </div>
      ) : repos.length === 0 && visibleJobs.length === 0 ? (
        <AnimatedCard>
          <div className="flex flex-col items-center justify-center py-32 text-center">
            <div className="relative w-24 h-24 flex items-center justify-center mb-6">
              <div className="absolute inset-0 rounded-full border-2 border-dashed border-muted/20 animate-pulse2s" />
              <div className="w-16 h-16 rounded-2xl glass-card flex items-center justify-center">
                <FolderGit2 size={28} className="text-muted" />
              </div>
            </div>
            <p className="text-lg font-bold text-text mb-1">No repositories yet</p>
            <p className="text-muted text-sm mb-8 max-w-sm leading-relaxed">
              Import a codebase from local file, Git, or cloud to analyze its structure and explore the knowledge graph
            </p>
            <button
              onClick={() => setShowUpload(true)}
              className="btn-primary px-6 py-3 text-sm"
            >
              <Plus size={15} /> Upload Repository
            </button>
          </div>
        </AnimatedCard>
      ) : (
        <div className="space-y-3">
          {repos.map((repo) => (
            <AnimatedCard key={repo.id}>
              <div className="glass-card px-6 py-5 hover:border-accent/20 hover:translate-y-[-1px] hover:shadow-lg group">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0">
                      <CheckCircle2 size={18} className="text-accent" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-text font-semibold truncate">{repo.name}</p>
                      <div className="flex items-center gap-3 mt-0.5">
                        <p className="text-muted text-xs font-mono">{repo.last_commit?.slice(0, 12) ?? "—"}</p>
                        <span className="w-1 h-1 rounded-full bg-white/10" />
                        <span className="text-xs text-muted flex items-center gap-1">
                          <Clock size={11} /> {repo.indexed_at ? timeAgo(repo.indexed_at) : "—"}
                        </span>
                      </div>
                      {repo.stats && (
                        <div className="flex items-center gap-3 mt-1.5">
                          <span className="text-[10px] text-muted flex items-center gap-1"><span className="w-1 h-1 rounded-full bg-blue-400" />{repo.stats.nodes?.toLocaleString()} nodes</span>
                          <span className="text-[10px] text-muted flex items-center gap-1"><span className="w-1 h-1 rounded-full bg-purple-400" />{repo.stats.edges?.toLocaleString()} edges</span>
                          <span className="text-[10px] text-muted flex items-center gap-1"><span className="w-1 h-1 rounded-full bg-orange-400" />{repo.stats.communities} communities</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-medium text-accent bg-accent/10 px-3 py-1 rounded-full font-mono">Ready</span>
                    <button
                      onClick={() => navigate(`/graph/${repo.id}`)}
                      className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-accent border border-accent/30 rounded-lg hover:bg-accent/10 transition-colors"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="3" /><circle cx="5" cy="6" r="2" /><circle cx="19" cy="6" r="2" />
                        <circle cx="5" cy="18" r="2" /><circle cx="19" cy="18" r="2" />
                        <line x1="9.5" y1="10.5" x2="6.5" y2="7.5" /><line x1="14.5" y1="10.5" x2="17.5" y2="7.5" />
                        <line x1="9.5" y1="13.5" x2="6.5" y2="16.5" /><line x1="14.5" y1="13.5" x2="17.5" y2="16.5" />
                      </svg>
                      Explore Graph
                    </button>
                    <button
                      onClick={() => handleRemove(repo.id)}
                      disabled={removing === repo.id}
                      aria-label="Delete repository"
                      className="flex items-center gap-1.5 px-3 py-2 text-sm text-muted border border-white/[0.06] rounded-lg hover:text-red-400 hover:border-red-400/30 transition-colors disabled:opacity-40"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            </AnimatedCard>
          ))}
        </div>
      )}

      {showUpload && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="relative glass-card p-8 w-full max-w-lg shadow-2xl" style={{ background: "rgba(14,31,48,0.95)" }}>
            <button
              onClick={() => { setShowUpload(false); refresh(); }}
              aria-label="Close upload dialog"
              className="absolute top-4 right-4 text-muted hover:text-text transition-colors"
            >
              <X size={20} />
            </button>
            <p className="text-accent font-mono text-xs uppercase tracking-widest mb-2">Upload</p>
            <h2 className="text-xl font-bold text-text mb-1">New Repository</h2>
            <p className="text-sm text-muted mb-6">Import a codebase from local file, Git, or cloud storage</p>
            <UploadScreen
              status="idle"
              messages={[]}
              onAnalyze={handleAnalyze}
              onAnalyzeGit={handleAnalyzeGit}
              onAnalyzeUrl={handleAnalyzeUrl}
            />
          </div>
        </div>
      )}
    </PageContainer>
  );
}
