import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AuthLayout from "../layout/AuthLayout";

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const update = (field: string, value: string) => setForm((f) => ({ ...f, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (form.password !== form.confirm) {
      setError("Passwords do not match");
      return;
    }
    if (form.password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }

    setLoading(true);
    try {
      await register(form.username, form.email, form.password);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create account");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthLayout>
      <h1 className="text-2xl font-bold text-white mb-1">Create account</h1>
      <p className="text-[#6b8fa8] text-sm mb-6">Get started with Code Knowledge Graph</p>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 mb-4">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm text-[#6b8fa8] mb-1.5">Username</label>
          <input
            type="text"
            value={form.username}
            onChange={(e) => update("username", e.target.value)}
            className="w-full bg-[#0a1628] border border-[#1a3548] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#3a5568] focus:outline-none focus:border-[#00E599]/50 transition-colors"
            placeholder="Choose a username"
            required
          />
        </div>
        <div>
          <label className="block text-sm text-[#6b8fa8] mb-1.5">Email</label>
          <input
            type="email"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            className="w-full bg-[#0a1628] border border-[#1a3548] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#3a5568] focus:outline-none focus:border-[#00E599]/50 transition-colors"
            placeholder="you@company.com"
            required
          />
        </div>
        <div>
          <label className="block text-sm text-[#6b8fa8] mb-1.5">Password</label>
          <input
            type="password"
            value={form.password}
            onChange={(e) => update("password", e.target.value)}
            className="w-full bg-[#0a1628] border border-[#1a3548] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#3a5568] focus:outline-none focus:border-[#00E599]/50 transition-colors"
            placeholder="Create a password"
            required
          />
        </div>
        <div>
          <label className="block text-sm text-[#6b8fa8] mb-1.5">Confirm Password</label>
          <input
            type="password"
            value={form.confirm}
            onChange={(e) => update("confirm", e.target.value)}
            className="w-full bg-[#0a1628] border border-[#1a3548] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#3a5568] focus:outline-none focus:border-[#00E599]/50 transition-colors"
            placeholder="Confirm your password"
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-[#00E599] text-[#050A0F] font-semibold py-2.5 rounded-lg hover:bg-[#00b377] transition-colors shadow-[0_0_15px_rgba(0,229,153,0.2)] disabled:opacity-50"
        >
          {loading ? "Creating account..." : "Create Account"}
        </button>
      </form>

      <p className="text-center text-[#6b8fa8] text-sm mt-6">
        Already have an account?{" "}
        <Link to="/login" className="text-[#00E599] hover:underline">Sign in</Link>
      </p>
    </AuthLayout>
  );
}
