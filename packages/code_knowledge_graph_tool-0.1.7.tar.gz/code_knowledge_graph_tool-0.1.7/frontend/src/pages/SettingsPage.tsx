import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  AlertTriangle,
  Boxes,
  Check,
  Cpu,
  Eye,
  EyeOff,
  Globe,
  KeyRound,
  Lock,
  Monitor,
  Moon,
  Save,
  Shield,
  Sun,
  Trash2,
  User,
} from "lucide-react";
import { changePassword, deleteAccount, updateProfile } from "../api";
import { useAuth } from "../context/AuthContext";
import { useSettings } from "../hooks/useSettings";
import { useToast } from "../components/ui/Toast";
import { PageContainer, AnimatedCard } from "../components/PageTransition";
import type { UserSettings } from "../types";

const UI_SETTINGS_KEY = "ckg-ui-settings";

interface LocalUiSettings {
  theme: "dark" | "light" | "system";
  notifications: boolean;
  autoAnalyze: boolean;
  compactSidebar: boolean;
}

const DEFAULT_UI_SETTINGS: LocalUiSettings = {
  theme: "dark",
  notifications: true,
  autoAnalyze: false,
  compactSidebar: false,
};

function loadUiSettings(): LocalUiSettings {
  try {
    const raw = localStorage.getItem(UI_SETTINGS_KEY);
    return raw ? { ...DEFAULT_UI_SETTINGS, ...JSON.parse(raw) } : { ...DEFAULT_UI_SETTINGS };
  } catch {
    return { ...DEFAULT_UI_SETTINGS };
  }
}

function saveUiSettings(settings: LocalUiSettings) {
  localStorage.setItem(UI_SETTINGS_KEY, JSON.stringify(settings));
}

function Toggle({
  enabled,
  onToggle,
  label,
}: {
  enabled: boolean;
  onToggle: () => void;
  label: string;
}) {
  return (
    <button
      role="switch"
      aria-checked={enabled}
      aria-label={label}
      onClick={onToggle}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus-visible:ring-2 focus-visible:ring-accent ${
        enabled ? "bg-accent" : "bg-white/10"
      }`}
    >
      <span
        className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform duration-200 ${
          enabled ? "translate-x-6" : "translate-x-1"
        }`}
      />
    </button>
  );
}

function SettingRow({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-3.5 border-b border-white/[0.04] last:border-0 gap-4">
      <div className="min-w-0">
        <p className="text-sm text-text font-medium">{label}</p>
        {description && <p className="text-xs text-muted mt-0.5">{description}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function SectionHeader({
  icon: Icon,
  label,
  sectionLabel,
  iconColor,
  bgColor,
}: {
  icon: React.ElementType;
  label: string;
  sectionLabel: string;
  iconColor: string;
  bgColor: string;
}) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className={`w-10 h-10 rounded-xl ${bgColor} border border-white/[0.06] flex items-center justify-center`}>
        <Icon size={18} className={iconColor} />
      </div>
      <div>
        <p className={`${iconColor} font-mono text-[10px] uppercase tracking-widest`}>{sectionLabel}</p>
        <h2 className="text-base font-semibold text-text">{label}</h2>
      </div>
    </div>
  );
}

const defaultServerSettings: UserSettings = {
  default_branch: "main",
  max_file_size_kb: 100 * 1024,
  embeddings_enabled: true,
  embedding_provider: "openai",
  ocr_provider: "openai",
  llm_provider: "openai",
};

export default function SettingsPage() {
  const navigate = useNavigate();
  const { user, refreshUser, logout } = useAuth();
  const { toast } = useToast();
  const {
    settings,
    secretStatus,
    loading,
    saveSettings,
    saveOpenAiKey,
    clearOpenAiKey,
  } = useSettings();

  const username = user?.username ?? "User";
  const initial = username.charAt(0).toUpperCase();
  const roleLabel = user?.role === "admin" ? "Administrator" : "Member";
  const [uiSettings, setUiSettings] = useState<LocalUiSettings>(loadUiSettings);
  const [serverSettings, setServerSettings] = useState<UserSettings>(defaultServerSettings);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [openAiKey, setOpenAiKey] = useState("");
  const [revealSecret, setRevealSecret] = useState(false);
  const [updatingSecret, setUpdatingSecret] = useState(false);
  const [profileName, setProfileName] = useState(username);
  const [profileSaving, setProfileSaving] = useState(false);
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmDelete, setConfirmDelete] = useState("");
  const [deletingAccount, setDeletingAccount] = useState(false);

  useEffect(() => {
    saveUiSettings(uiSettings);
    setSaved(false);
  }, [uiSettings]);

  useEffect(() => {
    if (settings) {
      setServerSettings(settings);
    }
  }, [settings]);

  useEffect(() => {
    setProfileName(username);
  }, [username]);

  const themeOptions = useMemo(
    () => [
      { value: "dark", icon: Moon, label: "Dark" },
      { value: "light", icon: Sun, label: "Light" },
      { value: "system", icon: Monitor, label: "System" },
    ] as const,
    []
  );

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveSettings(serverSettings);
      saveUiSettings(uiSettings);
      setSaved(true);
      toast("Settings saved", "success");
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      toast(error instanceof Error ? error.message : "Failed to save settings", "error");
    } finally {
      setSaving(false);
    }
  };

  const updateServerSetting = <K extends keyof UserSettings>(key: K, value: UserSettings[K]) => {
    setServerSettings((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  };

  const updateUiSetting = <K extends keyof LocalUiSettings>(key: K, value: LocalUiSettings[K]) => {
    setUiSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleSaveOpenAiKey = async () => {
    if (!openAiKey.trim()) return;
    setUpdatingSecret(true);
    try {
      await saveOpenAiKey(openAiKey.trim());
      setOpenAiKey("");
      setRevealSecret(false);
      toast("OpenAI API key updated", "success");
    } catch (error) {
      toast(error instanceof Error ? error.message : "Failed to save OpenAI API key", "error");
    } finally {
      setUpdatingSecret(false);
    }
  };

  const handleClearOpenAiKey = async () => {
    setUpdatingSecret(true);
    try {
      await clearOpenAiKey();
      setOpenAiKey("");
      setRevealSecret(false);
      toast("OpenAI API key removed", "success");
    } catch (error) {
      toast(error instanceof Error ? error.message : "Failed to remove OpenAI API key", "error");
    } finally {
      setUpdatingSecret(false);
    }
  };

  const handleProfileSave = async () => {
    if (!profileName.trim() || profileName.trim() === username) return;
    setProfileSaving(true);
    try {
      await updateProfile(profileName.trim());
      await refreshUser();
      toast("Username updated", "success");
    } catch (error) {
      toast(error instanceof Error ? error.message : "Failed to update username", "error");
    } finally {
      setProfileSaving(false);
    }
  };

  const handlePasswordSave = async () => {
    if (!currentPassword || !newPassword) return;
    setPasswordSaving(true);
    try {
      await changePassword(currentPassword, newPassword);
      setCurrentPassword("");
      setNewPassword("");
      toast("Password updated. Please sign in again.", "success");
      try {
        await logout();
      } catch {
        // logout still clears local auth state in context finally-path
      }
      navigate("/login", { replace: true });
    } catch (error) {
      toast(error instanceof Error ? error.message : "Failed to update password", "error");
    } finally {
      setPasswordSaving(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (confirmDelete !== username) return;
    setDeletingAccount(true);
    try {
      await deleteAccount();
      toast("Account deleted", "success");
      try {
        await logout();
      } catch {
        // ignore revoked-session errors during logout
      }
      navigate("/login", { replace: true });
    } catch (error) {
      toast(error instanceof Error ? error.message : "Failed to delete account", "error");
    } finally {
      setDeletingAccount(false);
    }
  };

  return (
    <PageContainer>
      <AnimatedCard className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-text">Settings</h2>
          <p className="text-muted text-sm mt-0.5">Local UI preferences stay in browser. Backend settings affect analysis and AI behavior per user.</p>
        </div>
        <button
          onClick={handleSave}
          disabled={loading || saving}
          className={`btn-primary px-5 py-2.5 text-sm transition-all disabled:opacity-50 ${saved ? "bg-green-500 hover:bg-green-600" : ""}`}
        >
          {saved ? <Check size={15} /> : <Save size={15} />}
          {saving ? "Saving..." : saved ? "Saved" : "Save Changes"}
        </button>
      </AnimatedCard>

      <div className="space-y-4 max-w-3xl">
        <AnimatedCard>
          <div className="glass-card p-6">
            <SectionHeader
              icon={User}
              label="Profile"
              sectionLabel="Account"
              iconColor="text-accent"
              bgColor="bg-accent/10"
            />
            <div className="flex items-center gap-4 py-3 border-b border-white/[0.04]">
              <div className="w-14 h-14 rounded-full bg-accent/15 border border-accent/30 flex items-center justify-center text-accent font-bold text-xl">
                {initial}
              </div>
              <div className="flex-1">
                <p className="text-text font-semibold text-lg">{username}</p>
                <p className="text-muted text-xs font-mono flex items-center gap-1">
                  <Shield size={11} /> {roleLabel}
                </p>
              </div>
            </div>

            <SettingRow
              label="Username"
              description="Used as your login identifier. Ownership stays tied to your immutable user ID."
            >
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-48 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs focus:border-accent/40 focus:outline-none"
                />
                <button onClick={handleProfileSave} disabled={profileSaving} className="btn-secondary px-4 py-2 text-xs disabled:opacity-50">
                  {profileSaving ? "Updating..." : "Update"}
                </button>
              </div>
            </SettingRow>

            <SettingRow
              label="Change password"
              description="Updates credentials and revokes every active session for this account."
            >
              <div className="flex items-center gap-2">
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Current"
                  className="w-28 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs focus:border-accent/40 focus:outline-none"
                />
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="New password"
                  className="w-32 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs focus:border-accent/40 focus:outline-none"
                />
                <button onClick={handlePasswordSave} disabled={passwordSaving} className="btn-secondary px-4 py-2 text-xs disabled:opacity-50">
                  {passwordSaving ? "Updating..." : "Apply"}
                </button>
              </div>
            </SettingRow>
          </div>
        </AnimatedCard>

        <AnimatedCard>
          <div className="glass-card p-6">
            <SectionHeader
              icon={Moon}
              label="Appearance"
              sectionLabel="Local UI"
              iconColor="text-violet-400"
              bgColor="bg-violet-400/10"
            />
            <SettingRow label="Theme" description="UI-only for now. Saved in this browser, not used by backend.">
              <div className="flex items-center gap-1 bg-white/[0.03] border border-white/[0.06] rounded-lg p-1">
                {themeOptions.map(({ value, icon: ThemeIcon, label }) => (
                  <button
                    key={value}
                    onClick={() => updateUiSetting("theme", value)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                      uiSettings.theme === value
                        ? "bg-accent/15 text-accent border border-accent/30"
                        : "text-muted hover:text-text"
                    }`}
                  >
                    <ThemeIcon size={12} />
                    {label}
                  </button>
                ))}
              </div>
            </SettingRow>
            <SettingRow label="Compact sidebar" description="Visible in UI only for now. Does not change app layout behavior yet.">
              <Toggle
                enabled={uiSettings.compactSidebar}
                onToggle={() => updateUiSetting("compactSidebar", !uiSettings.compactSidebar)}
                label="Compact sidebar"
              />
            </SettingRow>
            <SettingRow label="Analysis notifications" description="UI placeholder for now. Kept local until notification plumbing exists.">
              <Toggle
                enabled={uiSettings.notifications}
                onToggle={() => updateUiSetting("notifications", !uiSettings.notifications)}
                label="Analysis notifications"
              />
            </SettingRow>
            <SettingRow label="Auto analyze on push" description="UI placeholder for now. Backend watcher still remains global.">
              <Toggle
                enabled={uiSettings.autoAnalyze}
                onToggle={() => updateUiSetting("autoAnalyze", !uiSettings.autoAnalyze)}
                label="Auto analyze on push"
              />
            </SettingRow>
          </div>
        </AnimatedCard>

        <AnimatedCard>
          <div className="glass-card p-6">
            <SectionHeader
              icon={Cpu}
              label="Backend Behavior"
              sectionLabel="Effective"
              iconColor="text-cyan-400"
              bgColor="bg-cyan-400/10"
            />
            {!secretStatus?.openai_api_key_configured && secretStatus?.important_reminder && (
              <div className="mb-5 flex items-start gap-3 rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 text-sm text-text">
                <AlertTriangle size={18} className="mt-0.5 shrink-0 text-warning" />
                <div>
                  <p className="font-semibold text-warning">Important</p>
                  <p className="mt-1 text-muted">{secretStatus.important_reminder}</p>
                </div>
              </div>
            )}
            <SettingRow label="Default branch" description="Used automatically when Git analysis is started without an explicit branch.">
              <input
                type="text"
                value={serverSettings.default_branch}
                onChange={(e) => updateServerSetting("default_branch", e.target.value)}
                className="w-32 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs font-mono focus:border-accent/40 focus:outline-none"
              />
            </SettingRow>
            <SettingRow label="Max file size (KB)" description="Files above this limit are skipped during repository discovery for your jobs.">
              <input
                type="number"
                min={1}
                value={serverSettings.max_file_size_kb}
                onChange={(e) => updateServerSetting("max_file_size_kb", Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-28 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs font-mono focus:border-accent/40 focus:outline-none text-right"
              />
            </SettingRow>
            <SettingRow label="Embeddings enabled" description="Turns semantic embedding phases on or off for your analysis jobs.">
              <Toggle
                enabled={serverSettings.embeddings_enabled}
                onToggle={() => updateServerSetting("embeddings_enabled", !serverSettings.embeddings_enabled)}
                label="Embeddings enabled"
              />
            </SettingRow>
            <SettingRow label="Embedding provider" description="OpenAI uses your per-user API key. Local forces the built-in local fallback model path.">
              <div className="flex items-center gap-1 bg-white/[0.03] border border-white/[0.06] rounded-lg p-1">
                {(["openai", "local"] as const).map((provider) => (
                  <button
                    key={provider}
                    onClick={() => updateServerSetting("embedding_provider", provider)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                      serverSettings.embedding_provider === provider
                        ? "bg-cyan-400/15 text-cyan-400 border border-cyan-400/30"
                        : "text-muted hover:text-text"
                    }`}
                  >
                    {provider === "openai" ? <Globe size={11} /> : <Cpu size={11} />}
                    {provider === "openai" ? "OpenAI" : "Local"}
                  </button>
                ))}
              </div>
            </SettingRow>
            <SettingRow label="OCR provider" description="Controls document OCR fallback when text extraction is weak.">
              <select
                value={serverSettings.ocr_provider}
                onChange={(e) => updateServerSetting("ocr_provider", e.target.value as UserSettings["ocr_provider"])}
                className="w-32 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs focus:border-accent/40 focus:outline-none"
              >
                <option value="openai">OpenAI</option>
                <option value="gemini">Gemini</option>
                <option value="paddle">Paddle</option>
              </select>
            </SettingRow>
            <SettingRow label="LLM provider" description="Used by agent and SRS generation. v1 is fixed to OpenAI.">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs">
                <Lock size={12} className="text-muted" />
                {serverSettings.llm_provider}
              </div>
            </SettingRow>
          </div>
        </AnimatedCard>

        <AnimatedCard>
          <div className="glass-card p-6">
            <SectionHeader
              icon={KeyRound}
              label="Provider Secret"
              sectionLabel="OpenAI"
              iconColor="text-yellow-400"
              bgColor="bg-yellow-400/10"
            />
            <SettingRow
              label="OpenAI API key"
              description={secretStatus?.openai_api_key_configured
                ? `Configured${secretStatus.updated_at ? `, updated ${new Date(secretStatus.updated_at).toLocaleString()}` : ""}. The server uses this key for your embeddings, OCR, and agent calls.`
                : "Not configured yet. OpenAI features stay blocked until you save your own key here. This key is stored encrypted on the server and scoped to your user ID."}
            >
              <div className="flex items-center gap-2">
                <input
                  type={revealSecret ? "text" : "password"}
                  value={openAiKey}
                  onChange={(e) => setOpenAiKey(e.target.value)}
                  placeholder={secretStatus?.openai_api_key_configured ? "Enter new key to rotate" : "sk-..."}
                  className="w-56 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs focus:border-accent/40 focus:outline-none"
                />
                <button
                  onClick={() => setRevealSecret((prev) => !prev)}
                  className="px-3 py-2 rounded-lg border border-white/[0.08] text-muted hover:text-text transition-colors"
                  aria-label={revealSecret ? "Hide secret" : "Reveal secret"}
                >
                  {revealSecret ? <EyeOff size={13} /> : <Eye size={13} />}
                </button>
                <button onClick={handleSaveOpenAiKey} disabled={updatingSecret || !openAiKey.trim()} className="btn-secondary px-4 py-2 text-xs disabled:opacity-50">
                  {updatingSecret ? "Saving..." : secretStatus?.openai_api_key_configured ? "Rotate" : "Save"}
                </button>
                {secretStatus?.openai_api_key_configured && (
                  <button onClick={handleClearOpenAiKey} disabled={updatingSecret} className="px-4 py-2 rounded-lg border border-red-400/30 text-red-400 text-xs hover:bg-red-400/10 transition-colors disabled:opacity-50">
                    Remove
                  </button>
                )}
              </div>
            </SettingRow>
          </div>
        </AnimatedCard>

        <AnimatedCard>
          <div className="glass-card p-6">
            <SectionHeader
              icon={Boxes}
              label="Provider Notes"
              sectionLabel="Reference"
              iconColor="text-blue-400"
              bgColor="bg-blue-400/10"
            />
            <dl className="space-y-0 text-sm">
              {[
                { label: "Embeddings", value: "OpenAI with your saved key, or explicit local provider" },
                { label: "OCR", value: "OpenAI, Gemini, or Paddle" },
                { label: "LLM", value: "OpenAI only in v1" },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-center py-2.5 border-b border-white/[0.04] last:border-0">
                  <dt className="text-muted">{label}</dt>
                  <dd className="text-text font-medium text-xs">{value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </AnimatedCard>

        <AnimatedCard>
          <div className="glass-card p-6 border-red-400/20">
            <SectionHeader
              icon={Trash2}
              label="Danger Zone"
              sectionLabel="Destructive"
              iconColor="text-red-400"
              bgColor="bg-red-400/10"
            />
            <SettingRow label="Reset local UI placeholders" description="Restores browser-only theme/sidebar/notification placeholders.">
              <button
                onClick={() => {
                  setUiSettings({ ...DEFAULT_UI_SETTINGS });
                  saveUiSettings(DEFAULT_UI_SETTINGS);
                  toast("Local UI settings reset", "success");
                }}
                className="px-4 py-1.5 rounded-lg border border-red-400/30 text-red-400 text-xs font-medium hover:bg-red-400/10 transition-colors"
              >
                Reset Local UI
              </button>
            </SettingRow>
            <SettingRow label="Delete account" description={`Soft delete only. Type "${username}" to confirm; login will stop working afterwards.`}>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={confirmDelete}
                  onChange={(e) => setConfirmDelete(e.target.value)}
                  placeholder={username}
                  className="w-36 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08] text-text text-xs focus:border-red-400/40 focus:outline-none"
                />
                <button
                  onClick={handleDeleteAccount}
                  disabled={deletingAccount || confirmDelete !== username}
                  className="px-4 py-2 rounded-lg border border-red-400/30 text-red-400 text-xs hover:bg-red-400/10 transition-colors disabled:opacity-40"
                >
                  {deletingAccount ? "Deleting..." : "Delete Account"}
                </button>
              </div>
            </SettingRow>
          </div>
        </AnimatedCard>
      </div>
    </PageContainer>
  );
}
