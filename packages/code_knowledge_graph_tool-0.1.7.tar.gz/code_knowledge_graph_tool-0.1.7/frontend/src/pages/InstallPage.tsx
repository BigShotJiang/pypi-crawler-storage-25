import { useState } from "react";
import { Copy, Check, Terminal, Puzzle, BookOpen, ArrowRight } from "lucide-react";
import { PageContainer, AnimatedCard } from "../components/PageTransition";

const LANGUAGES = [
  { id: "curl", label: "Curl", dot: "bg-gray-400", code: `# Upload and analyze a repository\ncurl -X POST http://localhost:8080/api/analyze \\\n  -F "file=@my-repo.zip" \\\n  --no-buffer` },
  { id: "python", label: "Python", dot: "bg-yellow-400", code: `import requests\n\n# Upload and analyze a repository\nwith open("my-repo.zip", "rb") as f:\n    resp = requests.post(\n        "http://localhost:8080/api/analyze",\n        files={"file": f},\n        stream=True,\n    )\n\nfor line in resp.iter_lines():\n    if line:\n        print(line.decode())` },
  { id: "nodejs", label: "NodeJS", dot: "bg-green-400", code: `const fs = require("fs");\n\nconst form = new FormData();\nform.append("file", fs.createReadStream("my-repo.zip"));\n\nconst resp = await fetch("http://localhost:8080/api/analyze", {\n  method: "POST",\n  body: form,\n});\n\nconst reader = resp.body.getReader();\nconst decoder = new TextDecoder();\n\nwhile (true) {\n  const { done, value } = await reader.read();\n  if (done) break;\n  console.log(decoder.decode(value));\n}` },
  { id: "go", label: "GO", dot: "bg-cyan-400", code: `package main\n\nimport (\n    "bytes"\n    "fmt"\n    "io"\n    "mime/multipart"\n    "net/http"\n    "os"\n)\n\nfunc main() {\n    file, _ := os.Open("my-repo.zip")\n    defer file.Close()\n\n    body := &bytes.Buffer{}\n    writer := multipart.NewWriter(body)\n    part, _ := writer.CreateFormFile("file", "my-repo.zip")\n    io.Copy(part, file)\n    writer.Close()\n\n    resp, _ := http.Post(\n        "http://localhost:8080/api/analyze",\n        writer.FormDataContentType(),\n        body,\n    )\n    defer resp.Body.Close()\n    io.Copy(os.Stdout, resp.Body)\n}` },
  { id: "java", label: "Java", dot: "bg-orange-400", code: `import java.net.http.*;\nimport java.nio.file.*;\n\nvar client = HttpClient.newHttpClient();\nvar path = Path.of("my-repo.zip");\n\nvar request = HttpRequest.newBuilder()\n    .uri(URI.create("http://localhost:8080/api/analyze"))\n    .POST(HttpRequest.BodyPublishers.ofFile(path))\n    .build();\n\nvar response = client.send(request,\n    HttpResponse.BodyHandlers.ofString());\nSystem.out.println(response.body());` },
  { id: "csharp", label: "C#", dot: "bg-purple-400", code: `using var client = new HttpClient();\nusing var content = new MultipartFormDataContent();\n\nvar fileBytes = File.ReadAllBytes("my-repo.zip");\ncontent.Add(new ByteArrayContent(fileBytes), "file", "my-repo.zip");\n\nvar response = await client.PostAsync(\n    "http://localhost:8080/api/analyze", content);\n\nvar result = await response.Content.ReadAsStringAsync();\nConsole.WriteLine(result);` },
];

const FEATURES = [
  { icon: Terminal, title: "Hassle-free onboarding experience", desc: "Quick and simple setup to get started without delays. Save time with a seamless and efficient onboarding process." },
  { icon: Puzzle, title: "MCP Integration with API", desc: "Easily control and scale your code analysis with our flexible, powerful API for all your needs." },
  { icon: BookOpen, title: "Developer-friendly documentation", desc: "Clear, concise guides and examples to help you integrate CKG with ease and confidence." },
];

export default function InstallPage() {
  const [activeTab, setActiveTab] = useState("curl");
  const [copied, setCopied] = useState(false);

  const activeSnippet = LANGUAGES.find((l) => l.id === activeTab);

  const handleCopy = () => {
    if (activeSnippet) {
      navigator.clipboard.writeText(activeSnippet.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <PageContainer>
      <AnimatedCard>
        <h2 className="text-2xl font-bold text-text mb-2 leading-snug">
          Easy integration with any language
        </h2>
        <p className="text-muted max-w-xl mb-6 text-sm leading-relaxed">
          Analyze codebases programmatically using the CKG API. Check out the
          ready-to-use code snippets for an easier integration.
        </p>
      </AnimatedCard>

      <AnimatedCard className="flex gap-6 mb-8">
        <div className="flex flex-col justify-end shrink-0 pb-4">
          <a href="/api-keys" className="btn-primary rounded-full">
            Get API Access <ArrowRight size={14} />
          </a>
        </div>

        <div className="flex-1 glass-card overflow-hidden">
          <div className="flex items-center border-b border-white/[0.06]">
            {LANGUAGES.map(({ id, label, dot }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`px-4 py-3 text-sm transition-all duration-200 border-b-2 flex items-center gap-1.5 ${
                  activeTab === id
                    ? "text-accent border-accent bg-accent/5 font-medium"
                    : "text-muted border-transparent hover:text-text hover:bg-white/[0.02]"
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
                {label}
              </button>
            ))}
          </div>

          <div className="relative p-5">
            <pre className="bg-black/30 rounded-xl p-5 text-xs text-muted font-mono overflow-x-auto whitespace-pre leading-relaxed min-h-[160px]">
              {activeSnippet?.code}
            </pre>
            <button
              onClick={handleCopy}
              className="absolute top-7 right-7 flex items-center gap-1.5 px-3 py-1.5 text-xs text-muted border border-white/[0.08] rounded-lg hover:text-text hover:border-white/20 transition-colors bg-black/30"
            >
              {copied ? <><Check size={12} className="text-accent" /> Copied</> : <><Copy size={12} /> Copy</>}
            </button>
          </div>
        </div>
      </AnimatedCard>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {FEATURES.map(({ icon: Icon, title, desc }) => (
          <AnimatedCard key={title}>
            <div className="glass-card p-6 h-full group">
              <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center mb-4 group-hover:bg-accent/15 transition-colors">
                <Icon size={20} className="text-accent" />
              </div>
              <p className="text-sm font-semibold text-text mb-2">{title}</p>
              <p className="text-xs text-muted leading-relaxed">{desc}</p>
            </div>
          </AnimatedCard>
        ))}
      </div>

      <AnimatedCard className="flex items-center justify-center">
        <a
          href="/api-keys"
          className="inline-flex items-center gap-2 text-sm text-muted border border-white/[0.08] rounded-full px-6 py-2.5 hover:text-accent hover:border-accent/30 transition-all duration-200"
        >
          Looking for the API Keys? <span className="text-accent font-medium">Here it is</span> <ArrowRight size={14} className="text-accent" />
        </a>
      </AnimatedCard>
    </PageContainer>
  );
}
