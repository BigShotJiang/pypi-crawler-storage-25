import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Network, XCircle, FileText, Puzzle, Search, Check, Target, Brain, Replace, Shield, CheckCircle2, Menu, X } from "lucide-react";
import LanguageIcon from "../components/LanguageIcon";
import ScrollReveal from "../components/ScrollReveal";
import HeroGraphAnimation from "../components/HeroGraphAnimation";
import { useAuth } from "../context/AuthContext";

export default function LandingPage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="relative text-gray-200 min-h-screen" style={{ background: '#050A0F' }}>
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: [
            'radial-gradient(ellipse 90% 60% at 50% 25%, rgba(0,229,153,0.18) 0%, transparent 70%)',
            'radial-gradient(ellipse 70% 50% at 50% 30%, rgba(0,180,120,0.12) 0%, transparent 60%)',
            'radial-gradient(ellipse 130% 70% at 50% 45%, rgba(0,80,60,0.08) 0%, transparent 80%)',
          ].join(', '),
        }}
      />
      <div className="fixed inset-0 bg-grid pointer-events-none" />
      <nav className={`fixed top-0 w-full z-50 border-b border-white/5 backdrop-blur-md transition-all duration-300 ${scrolled ? "bg-bgBase/95 shadow-lg" : "bg-bgBase/80"}`}>
        <div className={`max-w-7xl mx-auto px-6 flex items-center justify-between transition-all duration-300 ${scrolled ? "h-14" : "h-16"}`}>
          <div className="flex items-center gap-8">
            <button onClick={() => navigate("/")} className="flex items-center gap-3 group">
              <div className="border border-brand/50 bg-brand/10 rounded px-2 py-1 transition-all group-hover:border-brand group-hover:shadow-[0_0_12px_rgba(0,229,153,0.25)]">
                <span className="text-brand font-mono text-xs font-bold tracking-widest">CKG</span>
              </div>
              <span className="text-white font-semibold tracking-tight hidden sm:inline">Code Knowledge Graph</span>
            </button>
            <div className="hidden md:flex items-center gap-6 text-sm text-gray-400">
              <a href="#problem" className="hover:text-white transition-colors">Problem</a>
              <a href="#solution" className="hover:text-white transition-colors">Solution</a>
              <a href="#features" className="hover:text-white transition-colors">Features</a>
              <a href="#roadmap" className="hover:text-white transition-colors">Roadmap</a>
              <button onClick={() => navigate("/install")} className="hover:text-white transition-colors">Docs</button>
            </div>
          </div>
          <div className="flex items-center gap-4 text-sm">
            {isAuthenticated ? (
              <button onClick={() => navigate("/dashboard")} className="hidden md:block text-gray-400 hover:text-white transition-colors">Dashboard</button>
            ) : (
              <button onClick={() => navigate("/login")} className="hidden md:block text-gray-400 hover:text-white transition-colors">Log in</button>
            )}
            <button onClick={() => navigate(isAuthenticated ? "/dashboard" : "/login")} className="bg-brand text-bgBase font-semibold px-4 py-2 rounded-md hover:bg-brandDark transition-all shadow-[0_0_15px_rgba(0,229,153,0.2)] hover:shadow-[0_0_25px_rgba(0,229,153,0.35)] hover:scale-[1.02]">
              Get Started
            </button>
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden text-gray-400 hover:text-white transition-colors">
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-white/5 bg-bgBase/95 backdrop-blur-md px-6 py-4 space-y-3 animate-fadeIn">
            {[
              { label: "Problem", href: "#problem" },
              { label: "Solution", href: "#solution" },
              { label: "Features", href: "#features" },
              { label: "Roadmap", href: "#roadmap" },
            ].map(({ label, href }) => (
              <a key={label} href={href} onClick={() => setMobileMenuOpen(false)} className="block text-sm text-gray-400 hover:text-white transition-colors">{label}</a>
            ))}
            <button onClick={() => { navigate("/install"); setMobileMenuOpen(false); }} className="block text-sm text-gray-400 hover:text-white transition-colors">Docs</button>
          </div>
        )}
      </nav>
      <header className="pt-40 pb-24 px-6 text-center max-w-5xl mx-auto relative">
        <HeroGraphAnimation />
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-brand/30 bg-brand/5 backdrop-blur-sm text-brand text-xs font-mono mb-8">
            <Network size={12} />
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand" />
            </span>
            AI-Powered Code Intelligence
          </div>
        </motion.div>

        <motion.h1 className="text-5xl md:text-7xl font-bold text-white tracking-[-0.02em] mb-6 leading-[1.1]" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}>
          Code Knowledge <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand to-emerald-500">Graph</span>
        </motion.h1>

        <motion.p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.25 }}>
          Automatically maps your codebase into an interactive knowledge graph.<br className="hidden md:inline" />
          Developers and AI agents navigate code like a <span className="text-white font-medium">map</span>, not a maze.
        </motion.p>

        <motion.div className="flex flex-col sm:flex-row items-center justify-center gap-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.4 }}>
          <button onClick={() => navigate("/dashboard")} className="group btn-primary w-full sm:w-auto px-8 py-3 text-base shadow-[0_0_20px_rgba(0,229,153,0.2)]">
            Get Started Free
            <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
          </button>
          <button onClick={() => navigate("/install")} className="btn-secondary w-full sm:w-auto px-8 py-3">
            <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            Documentation
          </button>
        </motion.div>
        <motion.div className="mt-20 relative w-full rounded-xl border border-white/10 bg-bgCard shadow-2xl overflow-hidden text-left" initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.5 }}>
          <div className="h-10 border-b border-white/10 bg-bgSurface flex items-center px-4 gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500/80" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <div className="w-3 h-3 rounded-full bg-green-500/80" />
            <span className="ml-4 text-xs font-mono text-gray-500">~/projects/csg-engine — bash</span>
          </div>
          <div className="p-6 font-mono text-sm overflow-x-auto text-gray-300">
            <p><span className="text-brand">$</span> <span className="text-white">csg</span> <span className="text-blue-400">analyze</span> <span className="text-yellow-400/70">./backend</span> <span className="text-blue-400/70">--embeddings</span></p>
            <p className="text-gray-500 mt-1">&gt; Parsing AST via Tree-sitter...</p>
            <p className="text-gray-500">&gt; Building knowledge graph (L0 → L3)...</p>
            <p className="text-brand mt-1">✔ Indexed 1,204 files across 3 languages.</p>
            <p className="mt-4"><span className="text-brand">$</span> <span className="text-white">csg</span> <span className="text-blue-400">mcp</span> <span className="text-blue-400/70">--transport</span> <span className="text-yellow-400/70">http</span> <span className="text-blue-400/70">--port</span> <span className="text-yellow-400/70">8080</span></p>
            <p className="text-brand mt-1">✔ MCP server running on <span className="text-blue-400">localhost:8080</span><span className="animate-pulse2s">▋</span></p>
          </div>
        </motion.div>
      </header>
      <ScrollReveal>
        <section className="py-10 border-y border-white/5 bg-bgSurface/30">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <p className="text-sm font-medium text-gray-500 mb-6 uppercase tracking-wider">Powered by</p>
            <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
              {[
                { name: "Tree-sitter", letter: "T", color: "text-green-400 bg-green-400/10 border-green-400/20" },
                { name: "LadybugDB", letter: "L", color: "text-blue-400 bg-blue-400/10 border-blue-400/20" },
                { name: "Python", letter: "P", color: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20" },
                { name: "LangGraph", letter: "LG", color: "text-cyan-400 bg-cyan-400/10 border-cyan-400/20" },
                { name: "TypeScript", letter: "TS", color: "text-blue-500 bg-blue-500/10 border-blue-500/20" },
              ].map(({ name, letter, color }) => (
                <div key={name} className="flex items-center gap-2.5 opacity-50 grayscale hover:opacity-100 hover:grayscale-0 transition-all duration-300 cursor-default">
                  <div className={`w-8 h-8 rounded-lg border flex items-center justify-center text-xs font-bold ${color}`}>{letter}</div>
                  <span className="text-sm font-medium text-gray-400">{name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>
      <section id="problem" className="py-24 max-w-7xl mx-auto px-6">
        <ScrollReveal>
          <div className="text-center mb-16">
            <p className="text-red-400 font-mono text-xs uppercase tracking-widest mb-4">01 / Problem</p>
            <h2 className="text-3xl md:text-5xl font-bold text-white">The problem is real.</h2>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 gap-8">
          <ScrollReveal direction="left">
            <div className="border border-red-500/20 bg-bgCard rounded-xl p-8 h-full hover:border-red-500/40 hover:shadow-[0_0_20px_rgba(248,81,73,0.08)] transition-all">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                  <span className="text-red-400 font-mono text-xs font-bold">01</span>
                </div>
                <h3 className="text-lg font-bold text-white">Developer Perspective</h3>
              </div>
              <ul className="space-y-4 text-gray-400 text-sm leading-relaxed">
                <li className="flex gap-3"><XCircle size={16} className="text-red-400 mt-0.5 shrink-0" /><div><span className="text-white font-medium">Onboarding takes weeks to months</span> — new hires struggle to understand unfamiliar codebases without a structural overview</div></li>
                <li className="flex gap-3"><XCircle size={16} className="text-red-400 mt-0.5 shrink-0" /><div><span className="text-white font-medium">Hidden dependencies</span> — code connections are buried across files, making changes risky and unpredictable</div></li>
                <li className="flex gap-3"><XCircle size={16} className="text-red-400 mt-0.5 shrink-0" /><div><span className="text-white font-medium">Outdated documentation</span> — docs drift from reality, creating a false sense of understanding</div></li>
              </ul>
              <div className="mt-6 pt-4 border-t border-white/5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 font-mono text-xs">Result → Slow development, high cognitive load</span>
              </div>
            </div>
          </ScrollReveal>
          <ScrollReveal direction="right" delay={0.1}>
            <div className="border border-red-500/20 bg-bgCard rounded-xl p-8 h-full hover:border-red-500/40 hover:shadow-[0_0_20px_rgba(248,81,73,0.08)] transition-all">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                  <span className="text-red-400 font-mono text-xs font-bold">02</span>
                </div>
                <h3 className="text-lg font-bold text-white">AI Agent Perspective</h3>
              </div>
              <ul className="space-y-4 text-gray-400 text-sm leading-relaxed">
                <li className="flex gap-3"><XCircle size={16} className="text-red-400 mt-0.5 shrink-0" /><div><span className="text-white font-medium">No deep codebase context</span> — AI tools (Copilot, ChatGPT, Claude) only see isolated file chunks, never the full architecture</div></li>
                <li className="flex gap-3"><XCircle size={16} className="text-red-400 mt-0.5 shrink-0" /><div><span className="text-white font-medium">Blind search dependency</span> — heavily relies on provider search tools and terminal output to navigate code, burning tokens on guesswork</div></li>
                <li className="flex gap-3"><XCircle size={16} className="text-red-400 mt-0.5 shrink-0" /><div><span className="text-white font-medium">Brute-force debugging</span> — fixing a bug means reading every single file to trace the error without a structural guide</div></li>
                <li className="flex gap-3"><XCircle size={16} className="text-red-400 mt-0.5 shrink-0" /><div><span className="text-white font-medium">No connection map</span> — even when a bug is found, there is no understanding of downstream impact — fix one bug, create ten more</div></li>
              </ul>
              <div className="mt-6 pt-4 border-t border-white/5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 font-mono text-xs">Result → Wasted tokens, broken fixes, no persistent memory</span>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>
      <section className="py-24 border-y border-white/5">
        <div className="max-w-4xl mx-auto px-6">
          <ScrollReveal>
            <div className="text-center mb-12">
              <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">02 / Insight</p>
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Code is not linear.</h2>
              <h2 className="text-3xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-brand to-emerald-500">
                It is a graph of relationships.
              </h2>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={0.15}>
            <div className="grid md:grid-cols-3 gap-4 mb-12">
              {[
                { who: "Developers", action: "read files", Icon: FileText },
                { who: "AI tools", action: "read chunks", Icon: Puzzle },
                { who: "Nobody", action: "understands the full structure", Icon: Search },
              ].map(({ who, action, Icon }) => (
                <div key={who} className="border border-white/10 bg-bgCard rounded-xl p-5 text-center hover:border-white/20 transition-colors">
                  <div className="w-10 h-10 mx-auto rounded-lg bg-white/5 border border-white/10 flex items-center justify-center mb-3">
                    <Icon size={20} className="text-gray-400" />
                  </div>
                  <p className="text-white font-medium text-sm">{who}</p>
                  <p className="text-gray-500 text-xs mt-1">{action}</p>
                </div>
              ))}
            </div>
          </ScrollReveal>

          <ScrollReveal delay={0.25}>
            <div className="border border-brand/20 bg-brand/5 rounded-xl p-8 shadow-[0_0_30px_rgba(0,229,153,0.06)]">
              <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">What users actually want</p>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  "AI that truly understands the codebase",
                  "Integration with coding agents (Claude CLI, Codex)",
                  "Reduced token / credit cost",
                  "Higher output productivity",
                ].map((item) => (
                  <div key={item} className="flex items-start gap-3">
                    <Check size={14} className="text-brand mt-0.5 shrink-0" />
                    <p className="text-gray-300 text-sm">{item}</p>
                  </div>
                ))}
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>
      <section id="solution" className="py-24 max-w-5xl mx-auto px-6">
        <ScrollReveal>
          <div className="text-center mb-12">
            <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">03 / Solution</p>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Code Knowledge Graph</h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Developers and AI navigate code like a <span className="text-brand font-semibold">map</span>, not a <span className="text-red-400">maze</span>.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            { num: "01", title: "Auto-Map", desc: "Automatically maps your code into a knowledge graph", icon: "M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" },
            { num: "02", title: "Relationships", desc: "Shows relationships between modules, functions, and data flow", icon: "M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" },
            { num: "03", title: "AI-Native", desc: "AI understands structure, not just text — deep context, not chunks", icon: "M13 10V3L4 14h7v7l9-11h-7z" },
          ].map(({ num, title, desc, icon }) => (
            <ScrollReveal key={title}>
              <div className="group border border-brand/20 bg-bgCard rounded-xl p-8 text-center hover:border-brand/40 transition-all h-full relative overflow-hidden">
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-brand to-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                <p className="text-brand/40 font-mono text-[10px] uppercase tracking-widest mb-3">{num}</p>
                <div className="w-14 h-14 mx-auto rounded-xl bg-brand/10 border border-brand/20 flex items-center justify-center mb-5 text-brand group-hover:scale-105 transition-transform">
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={icon} /></svg>
                </div>
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-brand transition-colors">{title}</h3>
                <p className="text-gray-400 text-sm">{desc}</p>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </section>
      <section id="engine" className="py-24 border-y border-white/5 overflow-hidden">
        <div className="max-w-5xl mx-auto px-6 relative">
          <div className="absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-brand/30 to-transparent hidden md:block" />
          <ScrollReveal>
            <div className="flex flex-col items-center text-center mb-20 relative">
              <div className="w-16 h-16 bg-bgCard border-2 border-brand rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(0,229,153,0.25)] z-10">
                <div className="w-8 h-8 bg-brand/20 rounded-full flex items-center justify-center animate-pulse2s">
                  <svg className="w-4 h-4 text-brand" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
              </div>
              <h2 className="text-2xl font-bold text-white mt-4 tracking-tight">CKG Engine</h2>
              <p className="text-brand font-mono text-[10px] uppercase mt-1 tracking-widest bg-brand/10 px-3 py-1 rounded">Active</p>
            </div>
          </ScrollReveal>
          <div className="md:grid md:grid-cols-2 gap-8 mb-16 relative">
            <div className="hidden md:block" />
            <ScrollReveal direction="right">
              <div className="bg-bgCard/90 border border-brand/30 rounded-xl p-6 relative">
                <div className="absolute left-0 top-6 -translate-x-full hidden md:flex items-center">
                  <div className="w-8 h-px bg-brand/40" />
                  <div className="w-4 h-4 rounded-full border-2 border-brand bg-bgBase ring-4 ring-brand/10 -ml-px" />
                </div>
                <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">[ Phase 01: The Map ]</p>
                <h3 className="text-lg font-bold text-white mb-2">AI Gains Full Context</h3>
                <p className="text-sm text-gray-400">CKG gives AI complete structural awareness of your codebase. Every dependency is visible, so fixes land precisely without cascading side effects.</p>
              </div>
            </ScrollReveal>
          </div>
          <div className="md:grid md:grid-cols-2 gap-8 mb-16 relative">
            <ScrollReveal direction="left">
              <div className="bg-bgCard/90 border border-brand/30 rounded-xl p-6 relative">
                <div className="absolute right-0 top-6 translate-x-full hidden md:flex items-center flex-row-reverse">
                  <div className="w-8 h-px bg-brand/40" />
                  <div className="w-4 h-4 rounded-full border-2 border-brand bg-bgBase ring-4 ring-brand/10 -mr-px" />
                </div>
                <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">[ Phase 02: Insight ]</p>
                <h3 className="text-lg font-bold text-white mb-2">Code is a Graph</h3>
                <p className="text-sm text-gray-400">CKG maps the entire codebase into an interactive structure, connecting AI Agents to LadybugDB for perfect retrieval.</p>
              </div>
            </ScrollReveal>
            <div className="hidden md:block" />
          </div>
          <div className="md:grid md:grid-cols-2 gap-8 mb-16 relative">
            <div className="hidden md:block" />
            <ScrollReveal direction="right">
              <div className="bg-bgCard/90 border border-brand/30 rounded-xl p-6 relative">
                <div className="absolute left-0 top-6 -translate-x-full hidden md:flex items-center">
                  <div className="w-8 h-px bg-brand/40" />
                  <div className="w-4 h-4 rounded-full border-2 border-brand bg-bgBase ring-4 ring-brand/10 -ml-px" />
                </div>
                <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">[ Phase 03: Architecture ]</p>
                <h3 className="text-lg font-bold text-white mb-3">6-Layer Retrieval</h3>
                <ul className="text-sm text-gray-400 space-y-2">
                  {[
                    { label: "L0:", text: "Topology — project map" },
                    { label: "L1:", text: "Relevance — hybrid search" },
                    { label: "L2:", text: "Context — execution flows" },
                    { label: "L3:", text: "Crosscut — shared patterns" },
                    { label: "L4:", text: "Contract — signatures & types" },
                    { label: "L5:", text: "Implementation — source code" },
                  ].map((item) => (
                    <li key={item.label}><span className="text-white font-medium">{item.label}</span> {item.text}</li>
                  ))}
                </ul>
              </div>
            </ScrollReveal>
          </div>
          <div className="md:grid md:grid-cols-2 gap-8 mb-20 relative">
            <ScrollReveal direction="left">
              <div className="bg-bgCard/90 border border-brand/30 rounded-xl p-6 relative">
                <div className="absolute right-0 top-6 translate-x-full hidden md:flex items-center flex-row-reverse">
                  <div className="w-8 h-px bg-brand/40" />
                  <div className="w-4 h-4 rounded-full border-2 border-brand bg-bgBase ring-4 ring-brand/10 -mr-px" />
                </div>
                <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">[ Phase 04: Capabilities ]</p>
                <h3 className="text-lg font-bold text-white mb-3">Agentic Superpowers</h3>
                <ul className="text-sm text-gray-400 space-y-2">
                  {[
                    "Pre-commit Blast Radius",
                    "Smart Context Retrieval",
                    "Structural AST Rename",
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-2">
                      <span className="text-brand">•</span> {item}
                    </li>
                  ))}
                </ul>
              </div>
            </ScrollReveal>
            <div className="hidden md:block" />
          </div>
          <ScrollReveal>
            <div className="max-w-md mx-auto bg-brand/10 backdrop-blur-md border border-brand rounded-xl p-8 text-center shadow-[0_0_30px_rgba(0,229,153,0.15)] relative z-10 hover:shadow-[0_0_40px_rgba(0,229,153,0.25)] hover:scale-[1.02] transition-all duration-300">
              <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">[ Final Phase ]</p>
              <h3 className="text-xl font-bold text-white mb-4">Initialize the Engine</h3>
              <button
                onClick={() => navigate("/dashboard")}
                className="btn-primary px-6 py-2.5"
              >
                Deploy CKG to Workspace
              </button>
            </div>
          </ScrollReveal>
        </div>
      </section>
      <section className="py-24 border-t border-white/5 max-w-6xl mx-auto px-6">
        <ScrollReveal>
          <div className="text-center mb-4">
            <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">04 / How It Works</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Core Technical Architecture</h2>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 gap-8 mt-12">
          <ScrollReveal direction="left">
            <div className="border border-white/10 bg-bgCard rounded-xl p-8 h-full">
              <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-3">Tree-sitter AST Parser</p>
              <h3 className="text-xl font-bold text-white mb-4">Concrete + Incremental Syntax Trees</h3>
              <p className="text-gray-400 text-sm leading-relaxed mb-4">
                An AST (Abstract Syntax Tree) is a structured representation of source code. Instead of raw text, code is converted into a tree where each node represents a syntactic construct and relationships show how code is organized.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed">
                Tree-sitter builds an incremental, error-tolerant syntax tree that updates in real-time as code changes — enabling fast, accurate parsing across 13+ languages simultaneously.
              </p>
            </div>
          </ScrollReveal>

          <ScrollReveal direction="right" delay={0.1}>
            <div className="border border-white/10 bg-bgCard rounded-xl p-8 h-full">
              <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-3">Execution Pipeline</p>
              <h3 className="text-xl font-bold text-white mb-4">6-Stage Ingestion</h3>
              <div className="space-y-3">
                {[
                  { step: "01", name: "Structure", desc: "Walk file tree, map folder/file relationships" },
                  { step: "02", name: "Parsing", desc: "Extract functions, classes, methods via Tree-sitter" },
                  { step: "03", name: "Resolution", desc: "Resolve imports, calls, heritage across files" },
                  { step: "04", name: "Clustering", desc: "Group related symbols into communities" },
                  { step: "05", name: "Processes", desc: "Trace execution flows from entry points" },
                  { step: "06", name: "Search", desc: "Build hybrid indexes for retrieval" },
                ].map(({ step, name, desc }) => (
                  <div key={step} className="flex gap-3 items-start">
                    <span className="w-6 h-6 rounded-full bg-brand/10 border border-brand/20 flex items-center justify-center text-brand font-mono text-[10px] font-bold shrink-0 mt-0.5">{step}</span>
                    <div>
                      <span className="text-white text-sm font-medium">{name}</span>
                      <span className="text-gray-500 text-sm"> — {desc}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </ScrollReveal>
        </div>
        <ScrollReveal className="mt-8">
          <div className="border border-white/10 bg-bgCard rounded-xl p-8">
            <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-3">Multi-Layer Retrieval System</p>
            <h3 className="text-xl font-bold text-white mb-6">6 Layers of Retrieval</h3>
            <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { layer: "L0", name: "Topology", nodes: "Communities, Folders", edges: "Project-level structural map", color: "text-gray-400" },
                { layer: "L1", name: "Relevance", nodes: "Symbols, Communities", edges: "BM25 + semantic search by community", color: "text-blue-400" },
                { layer: "L2", name: "Context", nodes: "Processes, Symbols", edges: "Execution paths & scoped listing", color: "text-purple-400" },
                { layer: "L3", name: "Crosscut", nodes: "Shared symbols, Cycles", edges: "Cross-cutting concerns & duplicates", color: "text-orange-400" },
                { layer: "L4", name: "Contract", nodes: "Signatures, Types", edges: "Heritage chains & callers/callees", color: "text-cyan-400" },
                { layer: "L5", name: "Implementation", nodes: "Source code", edges: "Actual code content for symbols", color: "text-brand" },
              ].map(({ layer, name, nodes, edges, color }) => {
                const barColor = color === "text-gray-400" ? "bg-gray-400" : color === "text-blue-400" ? "bg-blue-400" : color === "text-purple-400" ? "bg-purple-400" : "bg-brand";
                return (
                <div key={layer} className="bg-bgBase/50 border border-white/5 rounded-lg p-5 relative overflow-hidden">
                  <div className={`absolute left-0 top-0 bottom-0 w-1 ${barColor}`} />
                  <div className="flex items-center gap-2 mb-3 pl-2">
                    <span className={`font-mono text-xs font-bold ${color}`}>{layer}</span>
                    <span className="text-white text-sm font-medium">{name}</span>
                  </div>
                  <p className="text-gray-500 text-xs mb-1 pl-2"><span className="text-gray-400">Nodes:</span> {nodes}</p>
                  <p className="text-gray-500 text-xs pl-2"><span className="text-gray-400">Edges:</span> {edges}</p>
                </div>
              );})}
            </div>
          </div>
        </ScrollReveal>
        <ScrollReveal className="mt-8">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="border border-white/10 bg-bgCard rounded-xl p-6">
              <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">Traversal</p>
              <h4 className="text-white font-bold mb-2">Relationship Traversal</h4>
              <p className="text-gray-400 text-sm">Real flow return — what files are included, what functions need to run, what conditions apply.</p>
            </div>
            <div className="border border-white/10 bg-bgCard rounded-xl p-6">
              <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">Semantic</p>
              <h4 className="text-white font-bold mb-2">Semantic Search</h4>
              <p className="text-gray-400 text-sm">Code embeddings stored for deep contextual retrieval beyond keyword matching.</p>
            </div>
          </div>
        </ScrollReveal>
      </section>
      <section id="features" className="py-24 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <ScrollReveal>
            <div className="text-center mb-16">
              <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">05 / Core Features</p>
              <h2 className="text-3xl md:text-5xl font-bold text-white">Everything you need.</h2>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-5">
            {[
              { title: "Impact Analysis", desc: "Help AI agents understand the blast radius of every change before it ships.", tag: "Analysis", Icon: Target },
              { title: "Smart Context", desc: "Instead of random file matches, get complete execution flows grouped by process.", tag: "Intelligence", Icon: Brain },
              { title: "SRS Generation", desc: "Auto-generate Software Requirements Specification docs, dependency maps, and architecture overviews from the graph.", tag: "Automation", Icon: FileText },
              { title: "Graph-Powered Rename", desc: "Structural references, not text matches. Knows function calls from comments.", tag: "Refactoring", Icon: Replace },
              { title: "Pre-Commit Check", desc: "Know the blast radius of every commit. No more surprise breaking changes.", tag: "Safety", Icon: Shield },
            ].map(({ title, desc, tag, Icon }, i) => (
              <ScrollReveal key={title} delay={i * 0.05}>
                <div className="border border-white/10 bg-bgCard rounded-xl p-6 hover:border-brand/30 hover:shadow-[0_0_20px_rgba(0,229,153,0.08)] transition-all h-full group">
                  <div className="w-10 h-10 rounded-lg bg-brand/10 border border-brand/20 flex items-center justify-center mb-3">
                    <Icon size={18} className="text-brand" />
                  </div>
                  <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">{tag}</p>
                  <h3 className="text-white font-bold mb-2 group-hover:text-brand transition-colors">{title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
          <ScrollReveal className="mt-12">
            <div className="border border-white/10 bg-bgCard rounded-xl p-6 text-center">
              <p className="text-white font-medium text-sm mb-5">13+ Programming Languages Supported</p>
              <div className="flex flex-wrap justify-center gap-3">
                {["TypeScript", "JavaScript", "Python", "Java", "Kotlin", "C", "C#", "C++", "Ruby", "Swift", "Rust", "Go", "PHP"].map((lang) => (
                  <span key={lang} className="inline-flex items-center gap-2 px-3 py-1.5 bg-bgBase/50 border border-white/5 rounded-lg text-gray-400 text-xs hover:border-white/20 hover:text-white transition-colors">
                    <LanguageIcon lang={lang} size={16} />
                    {lang}
                  </span>
                ))}
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>
      <section className="py-24 border-t border-white/5">
        <div className="max-w-6xl mx-auto px-6">
          <ScrollReveal>
            <div className="text-center mb-16">
              <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">06 / Competitive Landscape</p>
              <h2 className="text-3xl md:text-4xl font-bold text-white">How we compare</h2>
            </div>
          </ScrollReveal>

          <ScrollReveal>
            <div className="border border-white/10 bg-bgCard rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-left px-6 py-4 text-gray-500 font-medium text-xs uppercase tracking-wider">Tool</th>
                    <th className="text-left px-6 py-4 text-gray-500 font-medium text-xs uppercase tracking-wider">Focus</th>
                    <th className="text-left px-6 py-4 text-gray-500 font-medium text-xs uppercase tracking-wider">Strength</th>
                    <th className="text-left px-6 py-4 text-gray-500 font-medium text-xs uppercase tracking-wider">Limitation</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { tool: "Graphite", focus: "Code graph viz", strength: "Visual dependency mapping", limit: "Static indexing, no AI integration" },
                    { tool: "Cursor", focus: "AI code editor", strength: "Strong code generation", limit: "No persistent structural understanding" },
                    { tool: "Antigravity", focus: "Codebase analysis", strength: "Large repo exploration", limit: "Shallow relationship mapping" },
                    { tool: "CLI Agents", focus: "General AI assistance", strength: "Flexible reasoning", limit: "No codebase memory, high token cost" },
                    { tool: "CKG", focus: "Knowledge graph", strength: "Deep structural + semantic understanding", limit: "", highlight: true },
                  ].map(({ tool, focus, strength, limit, highlight }) => (
                    <tr key={tool} className={`border-b border-white/5 last:border-0 hover:bg-white/[0.02] transition-colors ${highlight ? "bg-brand/5 border-l-[3px] border-l-brand" : ""}`}>
                      <td className={`px-6 py-4 font-medium ${highlight ? "text-brand" : "text-white"}`}>{tool}</td>
                      <td className="px-6 py-4 text-gray-400">{focus}</td>
                      <td className="px-6 py-4 text-gray-400">{strength}</td>
                      <td className="px-6 py-4">
                        {highlight ? <CheckCircle2 size={16} className="text-brand" /> : <span className="flex items-center gap-1.5 text-gray-500"><XCircle size={14} className="text-red-400/60" /> {limit}</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </ScrollReveal>
        </div>
      </section>
      <section className="py-24 border-t border-white/5">
        <div className="max-w-5xl mx-auto px-6">
          <ScrollReveal>
            <div className="text-center mb-16">
              <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">07 / Differentiation</p>
              <h2 className="text-3xl md:text-4xl font-bold text-white">Why CKG wins</h2>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              { title: "Persistent Memory", desc: "Unlike CLI agents that forget between sessions, CKG maintains a persistent graph database that accumulates understanding over time." },
              { title: "Multi-Layer Depth", desc: "6 layers of retrieval from topology to source code — not just surface-level dependency scanning." },
              { title: "AI-Native Architecture", desc: "Built from the ground up for AI agent integration via MCP. Not a visualization tool with AI bolted on." },
              { title: "Execution Flow Modeling", desc: "Traces real execution paths through call chains, not just static import graphs. Understands runtime behavior." },
            ].map(({ title, desc }, i) => (
              <ScrollReveal key={title} delay={i * 0.08}>
                <div className="border border-brand/20 bg-bgCard rounded-xl p-8 hover:border-brand/40 transition-colors h-full">
                  <h3 className="text-white font-bold text-lg mb-3">{title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
      <section className="py-24 border-t border-white/5">
        <div className="max-w-5xl mx-auto px-6">
          <ScrollReveal>
            <div className="text-center mb-16">
              <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">08 / Go-To-Market</p>
              <h2 className="text-3xl md:text-4xl font-bold text-white">Growth strategy</h2>
            </div>
          </ScrollReveal>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { phase: "Phase 1", title: "Developer Community", items: ["Open-source core engine", "GitHub + dev forums presence", "Free tier for individual developers"] },
              { phase: "Phase 2", title: "Product-Led Growth", items: ["Self-serve Pro subscriptions", "AI agent marketplace integrations", "Plugin ecosystem (VS Code, JetBrains)"] },
              { phase: "Phase 3", title: "Enterprise Expansion", items: ["Team collaboration features", "On-prem enterprise licensing", "MCP server access for AI fleets"] },
            ].map(({ phase, title, items }, i) => (
              <ScrollReveal key={phase} delay={i * 0.1}>
                <div className="border border-white/10 bg-bgCard rounded-xl p-8 h-full">
                  <p className="text-brand font-mono text-[10px] uppercase tracking-widest mb-2">{phase}</p>
                  <h3 className="text-white font-bold text-lg mb-4">{title}</h3>
                  <ul className="space-y-2">
                    {items.map((item) => (
                      <li key={item} className="flex gap-2 text-gray-400 text-sm">
                        <span className="text-brand shrink-0">→</span>{item}
                      </li>
                    ))}
                  </ul>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
      <section id="roadmap" className="py-24 border-t border-white/5">
        <div className="max-w-5xl mx-auto px-6">
          <ScrollReveal>
            <div className="text-center mb-16">
              <p className="text-brand font-mono text-xs uppercase tracking-widest mb-4">09 / Roadmap</p>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Path to full launch</h2>
              <p className="text-gray-400">End of 2027 — full production release</p>
            </div>
          </ScrollReveal>

          <div className="relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/10 -translate-x-1/2 hidden md:block" />

            <div className="space-y-8">
              {[
                { q: "Q1–Q2 2026", title: "Foundation", items: ["Core graph engine ✓", "Tree-sitter multi-language support ✓", "LadybugDB integration ✓", "CLI tool + web UI ✓"], side: "left" },
                { q: "Q3–Q4 2026", title: "Intelligence", items: ["6-layer retrieval system ✓", "AI agent MCP integration ✓", "Semantic embedding layer ✓", "Process flow tracing ✓"], side: "right" },
                { q: "Q1–Q2 2027", title: "Scale", items: ["Team collaboration", "Enterprise on-prem deployment", "Plugin ecosystem", "Advanced analytics dashboard"], side: "left" },
                { q: "Q3–Q4 2027", title: "Full Launch", items: ["Production SaaS platform", "Marketplace integrations", "Enterprise licensing", "Global availability"], side: "right" },
              ].map(({ q, title, items, side }, i) => (
                <ScrollReveal key={q} direction={side === "left" ? "left" : "right"} delay={i * 0.08}>
                  <div className={`md:w-[45%] ${side === "right" ? "md:ml-auto" : ""}`}>
                    <div className="border border-white/10 bg-bgCard rounded-xl p-6 relative">
                      <div className={`hidden md:block absolute top-6 w-3 h-3 rounded-full bg-brand border-2 border-bgBase ${side === "left" ? "-right-[calc(50vw-50%-0.375rem)]" : "-left-[calc(50vw-50%-0.375rem)]"}`} />
                      <p className="text-brand font-mono text-xs mb-1">{q}</p>
                      <h3 className="text-white font-bold text-lg mb-3">{title}</h3>
                      <ul className="space-y-1.5">
                        {items.map((item) => (
                          <li key={item} className="flex gap-2 text-gray-400 text-sm">
                            <span className="text-brand shrink-0">•</span>{item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </div>
      </section>
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-brand/5" />
        <ScrollReveal>
          <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Ready to map your architecture?
            </h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
              Join engineering teams building more maintainable and AI-ready software.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button onClick={() => navigate("/dashboard")} className="px-10 py-4 rounded-md bg-brand text-bgBase font-bold text-lg hover:bg-brandDark transition-all shadow-[0_0_30px_rgba(0,229,153,0.3)] hover:scale-105">
                Get Started Free
              </button>
              <button onClick={() => navigate("/install")} className="px-10 py-4 rounded-md bg-bgSurface border border-white/10 text-white font-medium hover:bg-white/5 transition-colors">
                Explore the Product
              </button>
            </div>
          </div>
        </ScrollReveal>
      </section>
      <footer className="relative bg-bgBase pt-16 pb-8">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-brand/20 to-transparent" />
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="border border-brand/50 bg-brand/10 rounded px-1.5 py-0.5">
                <span className="text-brand font-mono text-[10px] font-bold tracking-widest">CKG</span>
              </div>
              <span className="text-white font-medium text-sm">Code Knowledge Graph</span>
            </div>
            <p className="text-sm text-gray-500">The codebase evolution engine.</p>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Product</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><button onClick={() => navigate("/dashboard")} className="hover:text-brand transition-colors">Engine</button></li>
              <li><button onClick={() => navigate("/api-keys")} className="hover:text-brand transition-colors">API</button></li>
              <li><button onClick={() => navigate("/settings")} className="hover:text-brand transition-colors">Settings</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Resources</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><button onClick={() => navigate("/install")} className="hover:text-brand transition-colors">Documentation</button></li>
              <li><button onClick={() => navigate("/api-keys")} className="hover:text-brand transition-colors">API Reference</button></li>
              <li><button onClick={() => navigate("/repositories")} className="hover:text-brand transition-colors">Repositories</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Connect</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#" className="hover:text-brand transition-colors flex items-center gap-2"><svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>GitHub</a></li>
              <li><a href="#" className="hover:text-brand transition-colors flex items-center gap-2"><svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>Twitter</a></li>
              <li><a href="#" className="hover:text-brand transition-colors flex items-center gap-2"><svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.37a19.791 19.791 0 00-4.885-1.515.074.074 0 00-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 00-5.487 0 12.64 12.64 0 00-.617-1.25.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028 14.09 14.09 0 001.226-1.994.076.076 0 00-.041-.106 13.107 13.107 0 01-1.872-.892.077.077 0 01-.008-.128 10.2 10.2 0 00.372-.292.074.074 0 01.077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 01.078.01c.12.098.246.198.373.292a.077.077 0 01-.006.127 12.299 12.299 0 01-1.873.892.077.077 0 00-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 00.084.028 19.839 19.839 0 006.002-3.03.077.077 0 00.032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 00-.031-.03z"/></svg>Discord</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between text-xs text-gray-600">
          <p>&copy; 2026 CKG Engine. All rights reserved.</p>
          <p className="mt-4 md:mt-0">Built for developers and AI agents.</p>
        </div>
      </footer>
    </div>
  );
}
