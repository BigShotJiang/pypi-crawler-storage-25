import { useState } from "react";
import { Link } from "react-router-dom";
import AuthLayout from "../layout/AuthLayout";

export default function RecoveryPage() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <AuthLayout>
        <div className="text-center py-4">
          <div className="w-14 h-14 mx-auto rounded-full bg-[#00E599]/10 border border-[#00E599]/30 flex items-center justify-center mb-4">
            <svg className="w-7 h-7 text-[#00E599]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Check your email</h2>
          <p className="text-[#6b8fa8] text-sm mb-6">
            If an account exists for <span className="text-white">{email}</span>, we've sent a recovery link.
          </p>
          <Link
            to="/login"
            className="block w-full bg-[#00E599] text-[#050A0F] font-semibold py-2.5 rounded-lg hover:bg-[#00b377] transition-colors text-center"
          >
            Back to Sign In
          </Link>
        </div>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout>
      <h1 className="text-2xl font-bold text-white mb-1">Reset password</h1>
      <p className="text-[#6b8fa8] text-sm mb-6">Enter your email and we'll send a recovery link</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm text-[#6b8fa8] mb-1.5">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#0a1628] border border-[#1a3548] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#3a5568] focus:outline-none focus:border-[#00E599]/50 transition-colors"
            placeholder="you@company.com"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-[#00E599] text-[#050A0F] font-semibold py-2.5 rounded-lg hover:bg-[#00b377] transition-colors shadow-[0_0_15px_rgba(0,229,153,0.2)]"
        >
          Send Recovery Link
        </button>
      </form>

      <p className="text-center text-[#6b8fa8] text-sm mt-6">
        Remember your password?{" "}
        <Link to="/login" className="text-[#00E599] hover:underline">Sign in</Link>
      </p>
    </AuthLayout>
  );
}
