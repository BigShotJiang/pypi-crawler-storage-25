import { useState } from "react";
import { Plus, Eye, EyeOff, Trash2, Copy, Check, KeyRound } from "lucide-react";
import { useApiKeys } from "../hooks/useApiKeys";
import { useToast } from "../components/ui/Toast";
import { PageContainer, AnimatedCard } from "../components/PageTransition";

export default function ApiKeysPage() {
  const { keys, loading, addKey, removeKey } = useApiKeys();
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [desc, setDesc] = useState("");
  const [creating, setCreating] = useState(false);
  const [revealed, setRevealed] = useState<Set<string>>(new Set());
  const [copied, setCopied] = useState<string | null>(null);

  const handleCreate = async () => {
    if (!desc.trim()) return;
    setCreating(true);
    try {
      await addKey(desc.trim());
      setDesc("");
      setShowForm(false);
      toast("Token created successfully", "success");
    } catch {
      toast("Failed to create token", "error");
    } finally {
      setCreating(false);
    }
  };

  const toggleReveal = (id: string) => {
    setRevealed((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const copyKey = (key: string, id: string) => {
    navigator.clipboard.writeText(key);
    setCopied(id);
    toast("Copied to clipboard", "success");
    setTimeout(() => setCopied(null), 2000);
  };

  const handleRemoveKey = async (id: string) => {
    try {
      await removeKey(id);
      toast("Token revoked", "success");
    } catch {
      toast("Failed to revoke token", "error");
    }
  };

  const firstKey = keys[0];
  const curlSnippet = `curl -X POST https://your-ckg-server/api/analyze \\
  -H "Authorization: Bearer ${firstKey?.key ?? "YOUR_API_TOKEN"}" \\
  -H "Content-Type: multipart/form-data" \\
  -F "file=@repo.zip"`;

  return (
    <PageContainer>
      <AnimatedCard className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-text">API Connections</h2>
          <p className="text-muted text-sm mt-0.5">Manage tokens to access the CKG API programmatically</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary px-5 py-2.5 text-sm">
          <Plus size={15} /> Create Token
        </button>
      </AnimatedCard>

      {showForm && (
        <AnimatedCard>
          <div className="glass-card p-6 mb-6" style={{ borderColor: "rgba(0,229,153,0.2)" }}>
            <p className="text-accent font-mono text-xs uppercase tracking-widest mb-3">New Token</p>
            <h3 className="text-base font-semibold text-text mb-4">Create API Token</h3>
            <div className="flex gap-3">
              <input
                type="text"
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                placeholder="Token description (e.g., CI pipeline)"
                aria-label="Token description"
                className="flex-1 px-4 py-2.5 bg-white/[0.03] border border-white/[0.08] rounded-lg text-sm text-text placeholder:text-muted focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/20 transition-colors"
                onKeyDown={(e) => e.key === "Enter" && handleCreate()}
                autoFocus
              />
              <button onClick={handleCreate} disabled={!desc.trim() || creating} className="btn-primary px-5 py-2.5 text-sm disabled:opacity-40">
                {creating ? "Creating..." : "Create"}
              </button>
              <button onClick={() => { setShowForm(false); setDesc(""); }} className="btn-secondary px-5 py-2.5 text-sm">
                Cancel
              </button>
            </div>
          </div>
        </AnimatedCard>
      )}

      <AnimatedCard className="mb-8">
        <p className="text-muted font-mono text-xs uppercase tracking-widest mb-4">Token List</p>
        {loading ? (
          <div className="shimmer-bg rounded-2xl h-40 border border-white/[0.06]" />
        ) : keys.length === 0 ? (
          <div className="glass-card p-12 text-center">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center mb-4">
              <KeyRound size={24} className="text-accent" />
            </div>
            <p className="text-text font-semibold mb-1">No API tokens yet</p>
            <p className="text-muted text-sm">Create a token above to start using the API</p>
          </div>
        ) : (
          <div className="glass-card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  <th className="text-left px-5 py-3.5 text-muted font-mono text-xs uppercase tracking-wider w-10">#</th>
                  <th className="text-left px-5 py-3.5 text-muted font-mono text-xs uppercase tracking-wider">Description</th>
                  <th className="text-left px-5 py-3.5 text-muted font-mono text-xs uppercase tracking-wider">API Key</th>
                  <th className="text-left px-5 py-3.5 text-muted font-mono text-xs uppercase tracking-wider w-28">Created</th>
                  <th className="w-12" />
                </tr>
              </thead>
              <tbody>
                {keys.map((k, i) => (
                  <tr key={k.id} className="border-b border-white/[0.04] last:border-0 hover:bg-white/[0.02] transition-colors">
                    <td className="px-5 py-4 text-muted font-mono text-xs">{i + 1}</td>
                    <td className="px-5 py-4 text-text font-medium">{k.description}</td>
                    <td className="px-5 py-4 font-mono text-xs">
                      <span className="inline-flex items-center gap-2.5 text-muted">
                        {revealed.has(k.id) ? k.key : k.key.slice(0, 6) + "••••••••••••"}
                        <button onClick={() => toggleReveal(k.id)} className="text-muted hover:text-text transition-colors" aria-label={revealed.has(k.id) ? "Hide key" : "Reveal key"}>
                          {revealed.has(k.id) ? <EyeOff size={13} /> : <Eye size={13} />}
                        </button>
                        <button onClick={() => copyKey(k.key, k.id)} className="text-muted hover:text-accent transition-colors" aria-label="Copy key">
                          {copied === k.id ? <Check size={13} className="text-accent" /> : <Copy size={13} />}
                        </button>
                      </span>
                    </td>
                    <td className="px-5 py-4 text-muted text-xs">{new Date(k.created_at).toLocaleDateString()}</td>
                    <td className="px-5 py-4">
                      <button onClick={() => handleRemoveKey(k.id)} className="text-muted hover:text-red-400 transition-colors" aria-label="Delete token">
                        <Trash2 size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AnimatedCard>

      <AnimatedCard>
        <p className="text-muted font-mono text-xs uppercase tracking-widest mb-4">Quick Copy</p>
        <div className="glass-card p-6">
          <p className="text-sm text-muted mb-4">Authenticate your requests using your API token:</p>
          <div className="relative">
            <pre className="bg-black/30 rounded-xl p-5 text-xs font-mono overflow-x-auto whitespace-pre leading-relaxed">
              <span className="text-white">curl</span> <span className="text-blue-400">-X POST</span> <span className="text-brand">https://your-ckg-server/api/analyze</span> \{"\n"}
              {"  "}<span className="text-blue-400">-H</span> <span className="text-yellow-400/70">"Authorization: Bearer {firstKey?.key ?? "YOUR_API_TOKEN"}"</span> \{"\n"}
              {"  "}<span className="text-blue-400">-H</span> <span className="text-yellow-400/70">"Content-Type: multipart/form-data"</span> \{"\n"}
              {"  "}<span className="text-blue-400">-F</span> <span className="text-yellow-400/70">"file=@repo.zip"</span>
            </pre>
            <button
              onClick={() => { navigator.clipboard.writeText(curlSnippet); setCopied("curl"); toast("Copied to clipboard", "success"); setTimeout(() => setCopied(null), 2000); }}
              className="absolute top-3 right-3 flex items-center gap-1.5 px-3 py-1.5 text-xs text-muted border border-white/[0.08] rounded-lg hover:text-text hover:border-white/20 transition-colors bg-black/30"
              aria-label="Copy curl command"
            >
              {copied === "curl" ? <><Check size={11} className="text-accent" /> Copied</> : <><Copy size={11} /> Copy</>}
            </button>
          </div>
        </div>
      </AnimatedCard>
    </PageContainer>
  );
}
