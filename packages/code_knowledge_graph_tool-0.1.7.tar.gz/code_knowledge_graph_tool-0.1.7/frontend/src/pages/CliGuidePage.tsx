import { useState } from "react";
import { Terminal, Copy, Check, ExternalLink, ArrowDown, Flag, ListOrdered, Settings2, Cloud, Code2 } from "lucide-react";
import { PageContainer, AnimatedCard } from "../components/PageTransition";

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button
      onClick={handleCopy}
      className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 text-[11px] text-muted border border-white/[0.08] rounded-md hover:text-text hover:border-white/20 transition-colors bg-black/30"
    >
      {copied ? <><Check size={11} className="text-accent" /> Copied</> : <><Copy size={11} /> Copy</>}
    </button>
  );
}

const COMMANDS = [
  { cmd: "ckg login", desc: "Authenticate with your API key" },
  { cmd: "ckg init", desc: "Initialize CKG in your project directory" },
  { cmd: "ckg ingest", desc: "Full parse + push (first time)" },
  { cmd: "ckg push", desc: "Delta sync (only changed files)" },
  { cmd: "ckg watch", desc: "Auto-sync on file changes" },
  { cmd: "ckg status", desc: "Show sync status" },
  { cmd: "ckg inspect", desc: "Preview what data will be sent (transparency)" },
];

const INGEST_FLAGS = [
  { flag: "--embeddings / --no-embeddings", desc: "Toggle AI embeddings for semantic search" },
  { flag: "--flows / --no-flows", desc: "Toggle data flow analysis" },
  { flag: "--all", desc: "Enable all features" },
  { flag: "--dry-run", desc: "Parse only, don't push" },
];

const PUSH_FLAGS = [
  { flag: "--force", desc: "Force full re-push (ignore delta cache)" },
];

const WATCH_FLAGS = [
  { flag: "--debounce <ms>", desc: "Debounce interval (default: 2000ms)" },
];

export default function CliGuidePage() {
  return (
    <PageContainer>
      {/* Header */}
      <AnimatedCard className="mb-8 pb-6 border-b border-white/[0.06]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-text mb-2 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center">
                <Terminal size={22} className="text-accent" />
              </div>
              CLI Integration Guide
            </h1>
            <p className="text-muted text-lg">Parse your code locally, push only graph metadata.</p>
          </div>
          <a
            href="https://www.npmjs.com/package/@bitsness/ckg-cli"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 rounded-lg font-bold text-sm transition-colors w-max"
          >
            <ExternalLink size={14} />
            NPM Package
          </a>
        </div>
      </AnimatedCard>

      {/* Steps */}
      <div className="space-y-4 mb-8">
        {/* Step 1: Install */}
        <AnimatedCard>
          <div className="glass-card p-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-blue-500/50 rounded-full" />
            <h3 className="text-lg font-bold text-text mb-4 pl-3">1. Install the CLI via npm</h3>
            <div className="relative">
              <pre className="bg-black/40 text-blue-300 p-4 rounded-xl font-mono text-sm overflow-x-auto border border-white/[0.05]">
                <code>npm i -g @bitsness/ckg-cli</code>
              </pre>
              <CopyButton text="npm i -g @bitsness/ckg-cli" />
            </div>
          </div>
        </AnimatedCard>

        {/* Step 2: Authenticate */}
        <AnimatedCard>
          <div className="glass-card p-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-accent/50 rounded-full" />
            <h3 className="text-lg font-bold text-text mb-2 pl-3">2. Authenticate</h3>
            <p className="text-muted text-sm mb-4 pl-3">
              Generate an API Key in the{" "}
              <a href="/api-keys" className="text-accent hover:underline">API Keys</a>{" "}
              page and login:
            </p>
            <div className="relative">
              <pre className="bg-black/40 text-accent p-4 rounded-xl font-mono text-sm overflow-x-auto border border-white/[0.05]">
                <code>ckg login --api-key YOUR_SECRET_KEY</code>
              </pre>
              <CopyButton text="ckg login --api-key YOUR_SECRET_KEY" />
            </div>
          </div>
        </AnimatedCard>

        {/* Step 3: Initialize and Push */}
        <AnimatedCard>
          <div className="glass-card p-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-purple-500/50 rounded-full" />
            <h3 className="text-lg font-bold text-text mb-2 pl-3">3. Initialize and Push</h3>
            <p className="text-muted text-sm mb-4 pl-3 flex items-center gap-2">
              <span className="text-amber-400 text-xs">&#9888;</span>
              In your project directory, run:
            </p>
            <div className="relative">
              <pre className="bg-black/40 text-purple-300 p-4 rounded-xl font-mono text-sm overflow-x-auto border border-white/[0.05]">
                <code>{`ckg init\nckg ingest`}</code>
              </pre>
              <CopyButton text={`ckg init\nckg ingest`} />
            </div>
          </div>
        </AnimatedCard>
      </div>

      {/* Divider */}
      <div className="w-full h-px bg-white/[0.06] my-8" />

      {/* Commands Table */}
      <AnimatedCard className="mb-8">
        <h2 className="text-xl font-bold text-text mb-4 flex items-center gap-2">
          <ListOrdered size={20} className="text-green-400" />
          Commands
        </h2>
        <div className="overflow-x-auto rounded-xl border border-white/[0.08] bg-black/30">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/[0.08]" style={{ background: "rgba(255,255,255,0.03)" }}>
                <th className="px-6 py-3 text-sm font-semibold text-muted">Command</th>
                <th className="px-6 py-3 text-sm font-semibold text-muted">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05]">
              {COMMANDS.map(({ cmd, desc }) => (
                <tr key={cmd} className="hover:bg-white/[0.02] transition-colors">
                  <td className="px-6 py-3 font-mono text-sm text-accent">{cmd}</td>
                  <td className="px-6 py-3 text-sm text-muted">{desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </AnimatedCard>

      {/* Flags */}
      <AnimatedCard className="mb-8">
        <h2 className="text-xl font-bold text-text mb-4 flex items-center gap-2">
          <Flag size={20} className="text-amber-400" />
          Flags
        </h2>
        <div className="space-y-6">
          <div>
            <span className="inline-block font-mono text-sm text-text font-bold px-2.5 py-1 rounded" style={{ background: "rgba(255,255,255,0.05)" }}>
              ckg ingest
            </span>
            <ul className="mt-3 space-y-1.5 ml-2">
              {INGEST_FLAGS.map(({ flag, desc }) => (
                <li key={flag} className="text-sm text-muted">
                  <span className="font-mono text-amber-300">{flag}</span>
                  <span className="mx-2 text-white/20">&mdash;</span>
                  {desc}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <span className="inline-block font-mono text-sm text-text font-bold px-2.5 py-1 rounded" style={{ background: "rgba(255,255,255,0.05)" }}>
              ckg push
            </span>
            <ul className="mt-3 space-y-1.5 ml-2">
              {PUSH_FLAGS.map(({ flag, desc }) => (
                <li key={flag} className="text-sm text-muted">
                  <span className="font-mono text-amber-300">{flag}</span>
                  <span className="mx-2 text-white/20">&mdash;</span>
                  {desc}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <span className="inline-block font-mono text-sm text-text font-bold px-2.5 py-1 rounded" style={{ background: "rgba(255,255,255,0.05)" }}>
              ckg watch
            </span>
            <ul className="mt-3 space-y-1.5 ml-2">
              {WATCH_FLAGS.map(({ flag, desc }) => (
                <li key={flag} className="text-sm text-muted">
                  <span className="font-mono text-amber-300">{flag}</span>
                  <span className="mx-2 text-white/20">&mdash;</span>
                  {desc}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </AnimatedCard>

      {/* How It Works */}
      <AnimatedCard className="mb-8">
        <div className="glass-card p-6">
          <h2 className="text-xl font-bold text-text mb-6 flex items-center gap-2">
            <Settings2 size={20} className="text-cyan-400" />
            How It Works
          </h2>
          <div className="max-w-3xl mx-auto py-4">
            {/* Your Machine */}
            <div className="bg-black/30 border border-white/[0.08] rounded-2xl p-6 relative">
              <div className="absolute -top-3 left-6 px-3 py-1 bg-[var(--bg)] border border-white/[0.08] text-[10px] font-bold tracking-widest uppercase text-blue-300 rounded-full flex items-center gap-2">
                <Code2 size={12} /> Your Machine
              </div>
              <div className="mt-4 flex flex-col items-center text-center space-y-4">
                <div className="px-4 py-2 bg-accent/10 border border-accent/20 text-accent font-mono text-sm rounded-lg inline-flex items-center gap-2">
                  <Terminal size={14} /> ckg ingest
                </div>
                <ArrowDown size={18} className="text-muted/40" />
                <div className="bg-white/[0.03] p-4 rounded-xl text-sm text-muted w-full">
                  Scan files <span className="mx-2 text-accent">&rarr;</span> Parse AST <span className="mx-2 text-accent">&rarr;</span> Extract definitions
                  <div className="text-xs text-muted/60 mt-1">(functions, classes, methods, interfaces)</div>
                </div>
                <ArrowDown size={18} className="text-muted/40" />
                <div className="px-4 py-2 bg-blue-500/10 border border-blue-500/20 text-blue-300 text-sm rounded-lg font-bold flex flex-col items-center w-full">
                  Output: Nodes + Edges
                  <span className="text-xs text-red-300/80 font-normal mt-1 border border-red-500/20 bg-red-500/10 px-2 py-0.5 rounded-md">
                    NO source code included
                  </span>
                </div>
              </div>
            </div>

            {/* Arrow between boxes */}
            <div className="flex flex-col items-center justify-center py-6 relative">
              <div className="w-px h-16 bg-gradient-to-b from-blue-500/30 to-accent/50 relative">
                <ArrowDown size={18} className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-accent animate-bounce" />
              </div>
              <div className="absolute bg-[var(--bg-card)] px-3 py-1 text-xs font-medium border border-white/[0.08] rounded-full text-muted flex items-center gap-2">
                <Cloud size={12} className="text-accent" /> Only metadata
              </div>
            </div>

            {/* CKG Cloud */}
            <div className="bg-accent/5 border border-accent/20 rounded-2xl p-6 relative shadow-[0_0_30px_rgba(0,229,153,0.05)]">
              <div className="absolute -top-3 left-6 px-3 py-1 bg-[var(--bg)] border border-accent/20 text-[10px] font-bold tracking-widest uppercase text-accent rounded-full flex items-center gap-2 shadow-sm shadow-accent/10">
                <Cloud size={12} /> CKG Cloud
              </div>
              <div className="mt-4 grid gap-3 text-sm">
                {[
                  { icon: "bg-green-500/20 text-green-400", title: "Graph Database", desc: "Architecture visualization" },
                  { icon: "bg-cyan-500/20 text-cyan-400", title: "AI Embeddings", desc: "Semantic natural language search" },
                  { icon: "bg-purple-500/20 text-purple-400", title: "Data Flow Analysis", desc: "Execution tracking & Impact maps" },
                ].map((item) => (
                  <div key={item.title} className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-white/[0.05]">
                    <div className={`w-8 h-8 rounded-lg ${item.icon} flex items-center justify-center shrink-0`}>
                      {item.title === "Graph Database" && (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3" /><circle cx="5" cy="6" r="2" /><circle cx="19" cy="6" r="2" /><circle cx="5" cy="18" r="2" /><circle cx="19" cy="18" r="2" /><line x1="9.5" y1="10.5" x2="6.5" y2="7.5" /><line x1="14.5" y1="10.5" x2="17.5" y2="7.5" /><line x1="9.5" y1="13.5" x2="6.5" y2="16.5" /><line x1="14.5" y1="13.5" x2="17.5" y2="16.5" /></svg>
                      )}
                      {item.title === "AI Embeddings" && (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a8 8 0 0 1 8 8c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 8-8z"/></svg>
                      )}
                      {item.title === "Data Flow Analysis" && (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3v12"/><path d="M18 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M15 6a9 9 0 0 0-9 9"/></svg>
                      )}
                    </div>
                    <div>
                      <div className="font-semibold text-text">{item.title}</div>
                      <div className="text-xs text-muted">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </AnimatedCard>

      {/* Divider */}
      <div className="w-full h-px bg-white/[0.06] my-8" />

      {/* Project Configuration */}
      <AnimatedCard className="mb-8">
        <h2 className="text-xl font-bold text-text mb-2 flex items-center gap-2">
          <Code2 size={20} className="text-blue-400" />
          Project Configuration
        </h2>
        <p className="text-muted text-sm mb-4 leading-relaxed">
          After running <code className="text-accent font-mono text-xs">init</code>, a{" "}
          <code className="text-accent font-mono text-xs">.ckg/config.json</code> file is created.
          This links your local project to the remote repository.
          Do <strong className="text-red-400">NOT</strong> commit the{" "}
          <code className="text-accent font-mono text-xs">.ckg/ast-cache</code> folder.
        </p>
        <div className="bg-black/30 border border-white/[0.06] rounded-xl p-4">
          <pre className="text-green-300 font-mono text-sm overflow-x-auto">
            <code>{`{
  "repoId": "6df9-4x2...",
  "repoName": "core-backend",
  "server": "http://localhost:8080"
}`}</code>
          </pre>
        </div>
      </AnimatedCard>

      {/* Enterprise */}
      <AnimatedCard className="mb-8">
        <div className="glass-card p-6" style={{ background: "rgba(0,229,153,0.03)" }}>
          <h2 className="text-xl font-bold text-text mb-3 flex items-center gap-2">
            <Cloud size={20} className="text-accent" />
            Enterprise & Custom Servers
          </h2>
          <p className="text-muted text-sm mb-6 leading-relaxed">
            If your company hosts a private CKG instance, you can override the default server URL.
          </p>
          <div className="space-y-6">
            <div>
              <h4 className="font-semibold text-text text-sm mb-2">Method 1: Environment Variables (Best for CI/CD)</h4>
              <div className="relative">
                <pre className="bg-black/40 text-accent/80 p-4 rounded-xl font-mono text-sm overflow-x-auto border border-white/[0.05]">
                  <code>{`export CKG_SERVER="https://ckg.internal.company.com"
export CKG_API_KEY="your-secret-key"
ckg ingest`}</code>
                </pre>
                <CopyButton text={`export CKG_SERVER="https://ckg.internal.company.com"\nexport CKG_API_KEY="your-secret-key"\nckg ingest`} />
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-text text-sm mb-2">Method 2: Per-Project Flag</h4>
              <div className="relative">
                <pre className="bg-black/40 text-accent/80 p-4 rounded-xl font-mono text-sm overflow-x-auto border border-white/[0.05]">
                  <code>ckg init --server https://ckg.internal.company.com</code>
                </pre>
                <CopyButton text="ckg init --server https://ckg.internal.company.com" />
              </div>
            </div>
          </div>
        </div>
      </AnimatedCard>
    </PageContainer>
  );
}
