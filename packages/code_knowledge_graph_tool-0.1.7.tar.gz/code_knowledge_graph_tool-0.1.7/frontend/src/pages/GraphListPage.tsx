import { useNavigate } from "react-router-dom";
import { Network, ArrowRight, Loader2, Plus } from "lucide-react";
import { useRepos } from "../hooks/useRepos";
import { PageContainer, AnimatedCard } from "../components/PageTransition";

export default function GraphListPage() {
  const { repos, loading } = useRepos();
  const navigate = useNavigate();

  return (
    <PageContainer>
      <AnimatedCard className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-text">Knowledge Graphs</h2>
          <p className="text-muted text-sm mt-0.5">Select a repository to explore its code structure</p>
        </div>
        <button onClick={() => navigate("/repositories")} className="btn-primary px-5 py-2.5 text-sm">
          <Plus size={15} /> Add Repository
        </button>
      </AnimatedCard>

      {loading ? (
        <div className="flex items-center gap-3 text-muted text-sm">
          <Loader2 size={16} className="animate-spin text-accent" />
          Loading repositories...
        </div>
      ) : repos.length === 0 ? (
        <AnimatedCard>
          <div className="flex flex-col items-center justify-center py-32 text-center">
            <div className="relative w-24 h-24 flex items-center justify-center mb-6">
              <div className="absolute inset-0 rounded-full border-2 border-dashed border-muted/20 animate-pulse2s" />
              <div className="w-16 h-16 rounded-2xl glass-card flex items-center justify-center">
                <Network size={28} className="text-muted" />
              </div>
            </div>
            <p className="text-lg font-bold text-text mb-1">No repositories indexed</p>
            <p className="text-muted text-sm mb-8 max-w-sm leading-relaxed">
              Upload a codebase in the Repositories tab to start exploring knowledge graphs
            </p>
            <button onClick={() => navigate("/repositories")} className="btn-primary px-6 py-3 text-sm">
              Go to Repositories
            </button>
          </div>
        </AnimatedCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {repos.map((repo) => (
            <AnimatedCard key={repo.id}>
              <button
                onClick={() => navigate(`/graph/${repo.id}`)}
                className="w-full glass-card p-6 text-left group relative"
              >
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-brand to-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity rounded-t-2xl" />
                <div className="flex items-start justify-between mb-5">
                  <div className="w-11 h-11 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center group-hover:border-accent/40 transition-colors">
                    <Network size={20} className="text-accent" />
                  </div>
                  <ArrowRight size={15} className="text-muted group-hover:text-accent transition-colors mt-1" />
                </div>
                <p className="text-base font-semibold text-text mb-1">{repo.name}</p>
                <p className="text-xs text-muted font-mono mb-4">{repo.last_commit?.slice(0, 12) ?? "—"}</p>
                <div className="flex items-center gap-3 text-xs text-muted">
                  <span className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                    {repo.stats?.nodes?.toLocaleString() ?? 0} nodes
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                    {repo.stats?.edges?.toLocaleString() ?? 0} edges
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-400" />
                    {repo.stats?.communities ?? 0} communities
                  </span>
                </div>
              </button>
            </AnimatedCard>
          ))}
        </div>
      )}
    </PageContainer>
  );
}
