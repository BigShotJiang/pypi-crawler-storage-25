import { useNavigate } from "react-router-dom";
import {
  FolderGit2,
  Boxes,
  GitFork,
  Users,
  Plus,
  Upload,
  Network,
  KeyRound,
  FileCode2,
  Workflow,
  Clock,
  ArrowUpRight,
  Puzzle,
} from "lucide-react";
import { useDashboardStats } from "../hooks/useDashboardStats";
import { PageContainer, AnimatedCard } from "../components/PageTransition";
import type { RepoStats } from "../types";

function StatCard({
  icon: Icon,
  label,
  value,
  accent = "text-accent",
  bgAccent = "bg-accent/10",
  badge,
}: {
  icon: React.ElementType;
  label: string;
  value: number | string;
  accent?: string;
  bgAccent?: string;
  badge?: string;
}) {
  return (
    <div className="glass-card glass-card-glow p-6">
      <div className="flex items-center gap-2 text-xs text-muted font-mono uppercase tracking-wider mb-4">
        <Icon size={14} className={accent} />
        {label}
      </div>
      <div className="flex items-end gap-3">
        <span className="text-4xl font-bold text-text">
          {typeof value === "number" ? value.toLocaleString() : value}
        </span>
        {badge && (
          <span className={`text-xs ${accent} ${bgAccent} px-2 py-0.5 rounded-full mb-1 font-mono`}>
            {badge}
          </span>
        )}
      </div>
    </div>
  );
}

function MiniBar({ values, color }: { values: number[]; color: string }) {
  const max = Math.max(...values, 1);
  return (
    <div className="flex items-end gap-1 h-10 overflow-hidden">
      {values.map((v, i) => (
        <div
          key={i}
          className={`flex-1 rounded-sm ${color} transition-all duration-300`}
          style={{ height: `${(v / max) * 100}%`, minHeight: v > 0 ? "2px" : "0" }}
        />
      ))}
    </div>
  );
}

function RepoRow({ repo, onClick }: { repo: RepoStats; onClick: () => void }) {
  const age = repo.indexed_at
    ? formatRelativeTime(repo.indexed_at)
    : "—";

  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-left hover:bg-white/[0.03] transition-colors group"
    >
      <div className="w-9 h-9 rounded-lg bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0">
        <FolderGit2 size={16} className="text-accent" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-text truncate group-hover:text-accent transition-colors">
          {repo.name}
        </p>
        <p className="text-xs text-muted flex items-center gap-1">
          <Clock size={10} /> {age}
        </p>
      </div>
      <div className="hidden sm:flex items-center gap-4 text-xs text-muted">
        <span title="Files">{repo.files} files</span>
        <span title="Nodes">{repo.nodes} nodes</span>
        <span title="Communities">{repo.communities} comm.</span>
      </div>
      <ArrowUpRight size={14} className="text-muted group-hover:text-accent transition-colors shrink-0" />
    </button>
  );
}

function formatRelativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

export default function DashboardPage() {
  const { stats, loading } = useDashboardStats();
  const navigate = useNavigate();

  const repos = stats?.repos ?? [];

  // Build per-repo bar chart data
  const repoNodeValues = repos.map((r) => r.nodes);
  const repoEdgeValues = repos.map((r) => r.edges);
  const repoCommunityValues = repos.map((r) => r.communities);
  const repoProcessValues = repos.map((r) => r.processes);

  return (
    <PageContainer>
      <AnimatedCard className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-text">Overview</h2>
          <p className="text-muted text-sm mt-0.5">
            Monitor your indexed repositories and code analysis metrics
          </p>
        </div>
        <button
          onClick={() => navigate("/repositories")}
          className="btn-primary px-5 py-2.5 text-sm"
        >
          <Plus size={15} /> New Analysis
        </button>
      </AnimatedCard>

      {/* Primary stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {loading ? (
          [1, 2, 3, 4].map((i) => (
            <AnimatedCard key={i}>
              <div className="shimmer-bg rounded-2xl h-[120px] border border-white/[0.06]" />
            </AnimatedCard>
          ))
        ) : (
          <>
            <AnimatedCard>
              <StatCard
                icon={FolderGit2}
                label="Repositories"
                value={stats?.total_repos ?? 0}
                badge="indexed"
              />
            </AnimatedCard>
            <AnimatedCard>
              <StatCard
                icon={FileCode2}
                label="Files"
                value={stats?.total_files ?? 0}
                accent="text-cyan-400"
                bgAccent="bg-cyan-400/10"
                badge="parsed"
              />
            </AnimatedCard>
            <AnimatedCard>
              <StatCard
                icon={Boxes}
                label="Symbols"
                value={stats?.total_nodes ?? 0}
                accent="text-blue-400"
                bgAccent="bg-blue-400/10"
                badge="nodes"
              />
            </AnimatedCard>
            <AnimatedCard>
              <StatCard
                icon={GitFork}
                label="Relationships"
                value={stats?.total_relationships ?? 0}
                accent="text-purple-400"
                bgAccent="bg-purple-400/10"
                badge="edges"
              />
            </AnimatedCard>
          </>
        )}
      </div>

      {/* Secondary stat cards + quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <AnimatedCard>
          <div className="glass-card p-6 hover:border-orange-400/20">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-muted font-mono uppercase tracking-wider flex items-center gap-2">
                <Users size={14} className="text-orange-400" /> Communities
              </span>
            </div>
            <span className="text-3xl font-bold text-text block mb-3">
              {loading ? "—" : stats?.total_communities ?? 0}
            </span>
            {repos.length > 1 && (
              <MiniBar values={repoCommunityValues} color="bg-orange-400/50" />
            )}
          </div>
        </AnimatedCard>

        <AnimatedCard>
          <div className="glass-card p-6 hover:border-pink-400/20">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-muted font-mono uppercase tracking-wider flex items-center gap-2">
                <Workflow size={14} className="text-pink-400" /> Processes
              </span>
            </div>
            <span className="text-3xl font-bold text-text block mb-3">
              {loading ? "—" : stats?.total_processes ?? 0}
            </span>
            {repos.length > 1 && (
              <MiniBar values={repoProcessValues} color="bg-pink-400/50" />
            )}
          </div>
        </AnimatedCard>

        <AnimatedCard>
          <div
            className="glass-card p-6"
            style={{
              background:
                "linear-gradient(135deg, rgba(0,229,153,0.08) 0%, rgba(255,255,255,0.03) 100%)",
            }}
          >
            <p className="text-sm font-bold text-text mb-3">Quick Actions</p>
            <div className="space-y-2">
              <button
                onClick={() => navigate("/repositories")}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-muted bg-white/[0.03] border border-white/[0.06] rounded-lg hover:border-accent/30 hover:text-accent transition-colors"
              >
                <Upload size={12} /> Upload Repository
              </button>
              <button
                onClick={() => navigate("/graph")}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-muted bg-white/[0.03] border border-white/[0.06] rounded-lg hover:border-accent/30 hover:text-accent transition-colors"
              >
                <Network size={12} /> Graph Explorer
              </button>
              <button
                onClick={() => navigate("/api-keys")}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-muted bg-white/[0.03] border border-white/[0.06] rounded-lg hover:border-accent/30 hover:text-accent transition-colors"
              >
                <KeyRound size={12} /> Generate API Key
              </button>
              <button
                onClick={() => navigate("/extensions")}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-muted bg-white/[0.03] border border-white/[0.06] rounded-lg hover:border-accent/30 hover:text-accent transition-colors"
              >
                <Puzzle size={12} /> IDE Extensions
              </button>
            </div>
          </div>
        </AnimatedCard>
      </div>

      {/* Per-repo breakdown chart */}
      {!loading && repos.length > 0 && (
        <AnimatedCard className="mb-6">
          <div className="glass-card p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-sm font-semibold text-text">
                Repository Breakdown
              </h2>
              <div className="flex items-center gap-4 text-xs text-muted">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-accent" /> Nodes
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-purple-400" /> Edges
                </span>
              </div>
            </div>
            <div className="flex items-end gap-3 h-32">
              {repos.map((repo) => {
                const maxVal = Math.max(
                  ...repoNodeValues,
                  ...repoEdgeValues,
                  1,
                );
                const nH = (repo.nodes / maxVal) * 100;
                const eH = (repo.edges / maxVal) * 100;
                return (
                  <div
                    key={repo.id}
                    className="flex-1 flex flex-col items-center gap-1 h-full group cursor-pointer"
                    onClick={() => navigate(`/graph/${repo.id}`)}
                    title={`${repo.name}: ${repo.nodes} nodes, ${repo.edges} edges`}
                  >
                    <div className="flex items-end gap-0.5 flex-1 w-full">
                      <div
                        className="flex-1 rounded-t bg-accent/40 group-hover:bg-accent/70 transition-colors"
                        style={{ height: `${nH}%`, minHeight: repo.nodes > 0 ? "2px" : "0" }}
                      />
                      <div
                        className="flex-1 rounded-t bg-purple-400/40 group-hover:bg-purple-400/70 transition-colors"
                        style={{ height: `${eH}%`, minHeight: repo.edges > 0 ? "2px" : "0" }}
                      />
                    </div>
                    <p className="text-[10px] text-muted truncate max-w-full group-hover:text-accent transition-colors">
                      {repo.name}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </AnimatedCard>
      )}

      {/* Recent repositories list */}
      <AnimatedCard>
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-text">
              Recent Repositories
            </h2>
            <button
              onClick={() => navigate("/repositories")}
              className="text-xs text-accent hover:underline"
            >
              View all
            </button>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="shimmer-bg rounded-xl h-14 border border-white/[0.04]"
                />
              ))}
            </div>
          ) : repos.length === 0 ? (
            <div className="text-center py-10">
              <FolderGit2
                size={32}
                className="text-muted/40 mx-auto mb-3"
              />
              <p className="text-muted text-sm mb-4">
                No repositories indexed yet
              </p>
              <button
                onClick={() => navigate("/repositories")}
                className="btn-primary px-5 py-2 text-sm"
              >
                <Plus size={14} /> Analyze First Repository
              </button>
            </div>
          ) : (
            <div className="divide-y divide-white/[0.04]">
              {repos
                .slice()
                .sort(
                  (a, b) =>
                    new Date(b.indexed_at).getTime() -
                    new Date(a.indexed_at).getTime(),
                )
                .slice(0, 5)
                .map((repo) => (
                  <RepoRow
                    key={repo.id}
                    repo={repo}
                    onClick={() => navigate(`/graph/${repo.id}`)}
                  />
                ))}
            </div>
          )}
        </div>
      </AnimatedCard>
    </PageContainer>
  );
}
