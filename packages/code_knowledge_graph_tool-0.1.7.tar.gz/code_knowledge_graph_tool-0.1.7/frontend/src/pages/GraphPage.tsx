import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft, Loader2 } from "lucide-react";
import type { AnalysisResult } from "../types";
import { fetchRepoGraph } from "../api";
import Workspace from "../components/Workspace";
import SearchBar from "../components/SearchBar";

export default function GraphPage() {
  const { repoId } = useParams<{ repoId: string }>();
  const navigate = useNavigate();
  const location = useLocation();

  const passedResult =
    (location.state as { analysisResult?: AnalysisResult } | null)?.analysisResult ?? null;

  const [result, setResult] = useState<AnalysisResult | null>(passedResult);
  const [loading, setLoading] = useState(!passedResult);
  const [error, setError] = useState<string | null>(null);
  const [focusNodeId, setFocusNodeId] = useState<string | null>(null);
  const [searchHighlightIds, setSearchHighlightIds] = useState<Set<string>>(new Set());
  const [searchEndpointIds, setSearchEndpointIds] = useState<Set<string>>(new Set());
  const [filterPassIds, setFilterPassIds] = useState<Set<string>>(() => new Set());

  // Fallback: if Workspace hasn't reported yet, treat all nodes as visible
  const effectiveFilterPassIds = useMemo(
    () => (filterPassIds.size > 0 ? filterPassIds : new Set(result?.graph.nodes.map((n) => n.id) ?? [])),
    [filterPassIds, result],
  );

  const clearSearchHighlights = useCallback(() => {
    setSearchHighlightIds(new Set());
    setSearchEndpointIds(new Set());
  }, []);

  useEffect(() => {
    if (passedResult || !repoId) return;
    setLoading(true);
    setError(null);
    fetchRepoGraph(repoId)
      .then((data) => setResult(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [repoId, passedResult]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-4">
        <Loader2 size={28} className="text-accent animate-spin" />
        <p className="text-muted text-sm">Analyzing repository...</p>
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-4">
        <div className="w-14 h-14 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
          <span className="text-red-400 text-xl">!</span>
        </div>
        <p className="text-red-400 text-sm">{error ?? "Failed to load graph"}</p>
        <button onClick={() => navigate("/repositories")} className="text-sm text-accent hover:underline">
          Back to Repositories
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden relative" style={{ background: 'linear-gradient(135deg, #0a1628 0%, #0c2434 50%, #0a2e24 100%)' }}>
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: [
            "radial-gradient(ellipse 80% 50% at 60% 20%, rgba(0,229,153,0.08) 0%, transparent 70%)",
            "radial-gradient(ellipse 100% 60% at 50% 50%, rgba(0,80,60,0.04) 0%, transparent 80%)",
          ].join(", "),
        }}
      />
      <div className="fixed inset-0 bg-grid pointer-events-none opacity-40" />
      <header className="flex items-center gap-3 px-4 py-2 border-b border-border bg-surface shrink-0 relative z-10">
        <button
          onClick={() => navigate("/repositories")}
          className="text-muted hover:text-text transition-colors"
          title="Back to Repositories"
          aria-label="Back to Repositories"
        >
          <ArrowLeft size={16} />
        </button>

        <div className="flex items-center gap-1.5">
          <span
            className="text-sm font-bold"
            style={{ background: "linear-gradient(135deg, #00e676, #00bfa5)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}
          >
            CKG
          </span>
          <span className="w-px h-4 bg-border" />
          <span className="text-muted text-xs font-mono">Code Knowledge Graph</span>
        </div>

        <SearchBar
          nodes={result.graph.nodes}
          edges={result.graph.edges}
          filterPassIds={effectiveFilterPassIds}
          onSelect={setFocusNodeId}
          onHighlightNodes={setSearchHighlightIds}
          onHighlightEndpoints={setSearchEndpointIds}
          onClearHighlights={clearSearchHighlights}
        />

        <div className="flex items-center gap-3 ml-auto text-xs text-muted font-mono">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            {result.summary.total_nodes} nodes
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
            {result.summary.total_relationships} edges
          </span>
        </div>

      </header>

      <div className="flex flex-1 overflow-hidden relative z-10">
        <Workspace
          result={result}
          focusNodeId={focusNodeId}
          onFocusNodeConsumed={() => setFocusNodeId(null)}
          searchHighlightIds={searchHighlightIds}
          searchEndpointIds={searchEndpointIds}
          onFilterPassIdsChange={setFilterPassIds}
        />
      </div>
    </div>
  );
}
