import { useState } from "react";
import { useNavigate, useLocation, Link, Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AuthLayout from "../layout/AuthLayout";

export default function LoginPage() {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname ?? "/dashboard";

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (isAuthenticated) {
    return <Navigate to={from} replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      await login(identifier, password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid username or password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      <h1 className="text-2xl font-bold text-white mb-1">Welcome back</h1>
      <p className="text-[#6b8fa8] text-sm mb-6">Sign in to your account</p>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 mb-4">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm text-[#6b8fa8] mb-1.5">Username or Email</label>
          <input
            type="text"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            className="w-full bg-[#0a1628] border border-[#1a3548] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#3a5568] focus:outline-none focus:border-[#00E599]/50 transition-colors"
            placeholder="Enter username or email"
            required
          />
        </div>
        <div>
          <label className="block text-sm text-[#6b8fa8] mb-1.5">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-[#0a1628] border border-[#1a3548] rounded-lg px-4 py-2.5 text-white text-sm placeholder-[#3a5568] focus:outline-none focus:border-[#00E599]/50 transition-colors"
            placeholder="Enter password"
            required
          />
        </div>

        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 text-[#6b8fa8] cursor-pointer">
            <input type="checkbox" className="rounded border-[#1a3548] accent-[#00E599]" />
            Remember me
          </label>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-[#00E599] text-[#050A0F] font-semibold py-2.5 rounded-lg hover:bg-[#00b377] transition-colors disabled:opacity-50 shadow-[0_0_15px_rgba(0,229,153,0.2)]"
        >
          {loading ? "Signing in..." : "Sign In"}
        </button>
      </form>

      <p className="text-center text-[#6b8fa8] text-sm mt-6">
        Don't have an account?{" "}
        <Link to="/register" className="text-[#00E599] hover:underline">Sign up</Link>
      </p>
    </AuthLayout>
  );
}
