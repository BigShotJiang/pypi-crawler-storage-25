import { ArrowUpRight, Download, ExternalLink, Star, Zap, Shield, RefreshCw } from "lucide-react";
import { PageContainer, AnimatedCard } from "../components/PageTransition";

/* ── IDE extension definitions ──────────────────── */

interface Extension {
  id: string;
  name: string;
  ide: string;
  description: string;
  icon: string;
  status: "available" | "coming_soon";
  marketplaceUrl: string;
  features: string[];
  color: string;
  bgColor: string;
}

const EXTENSIONS: Extension[] = [
  {
    id: "vscode",
    name: "CKG for VS Code",
    ide: "Visual Studio Code",
    description:
      "Full CKG integration inside VS Code. Explore your code knowledge graph, run impact analysis, and get AI-powered context — all without leaving your editor.",
    icon: "vscode",
    status: "coming_soon",
    marketplaceUrl: "https://marketplace.visualstudio.com/",
    features: [
      "Inline graph visualization",
      "Impact analysis on save",
      "Process flow explorer",
      "Semantic search panel",
    ],
    color: "text-blue-400",
    bgColor: "bg-blue-400/10",
  },
  {
    id: "jetbrains",
    name: "CKG for JetBrains",
    ide: "IntelliJ / WebStorm / PyCharm",
    description:
      "Native JetBrains plugin for CKG. Deep integration with project indexing, code inspections powered by the knowledge graph, and one-click SRS generation.",
    icon: "jetbrains",
    status: "coming_soon",
    marketplaceUrl: "https://plugins.jetbrains.com/",
    features: [
      "Project-level graph view",
      "Code inspection integration",
      "Rename refactor with graph",
      "SRS document generation",
    ],
    color: "text-orange-400",
    bgColor: "bg-orange-400/10",
  },
  {
    id: "neovim",
    name: "ckg.nvim",
    ide: "Neovim",
    description:
      "Lightweight Neovim plugin connecting to the CKG MCP server. Telescope integration for graph-powered search, floating window for symbol context, and LSP-like navigation.",
    icon: "neovim",
    status: "coming_soon",
    marketplaceUrl: "https://github.com/",
    features: [
      "Telescope graph search",
      "Floating symbol context",
      "MCP server integration",
      "Treesitter highlighting",
    ],
    color: "text-green-400",
    bgColor: "bg-green-400/10",
  },
  {
    id: "cursor",
    name: "CKG for Cursor",
    ide: "Cursor Editor",
    description:
      "Supercharge Cursor's AI with CKG's persistent code knowledge graph. Give the AI full structural awareness of your entire codebase through MCP.",
    icon: "cursor",
    status: "coming_soon",
    marketplaceUrl: "https://cursor.com/",
    features: [
      "MCP context provider",
      "Persistent code memory",
      "Cross-repo awareness",
      "6-layer retrieval for AI",
    ],
    color: "text-violet-400",
    bgColor: "bg-violet-400/10",
  },
  {
    id: "claude",
    name: "CKG MCP Server",
    ide: "Claude Code / Claude Desktop",
    description:
      "Connect Claude directly to your code knowledge graph via MCP. Enable Claude to understand your entire codebase structure, run impact analysis, and trace execution flows.",
    icon: "claude",
    status: "available",
    marketplaceUrl: "https://claude.ai/",
    features: [
      "8 MCP tools available",
      "6-layer hierarchical retrieval",
      "Impact & blast radius analysis",
      "Pre-commit review prompt",
    ],
    color: "text-amber-400",
    bgColor: "bg-amber-400/10",
  },
];

/* ── IDE icon SVGs ──────────────────────────────── */

function IDEIcon({ icon, size = 28 }: { icon: string; size?: number }) {
  const s = size;
  switch (icon) {
    case "vscode":
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
          <path d="M17.5 0L24 3.5V20.5L17.5 24L0 12.5L5.5 8L17.5 16V0Z" fill="#007ACC" />
          <path d="M0 12.5L5.5 8L17.5 16V24L0 12.5Z" fill="#1E8AD6" opacity="0.8" />
          <path d="M5.5 16L0 12.5L5.5 8L10.5 12L5.5 16Z" fill="#1E8AD6" opacity="0.6" />
        </svg>
      );
    case "jetbrains":
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
          <rect width="24" height="24" rx="4" fill="#000" />
          <rect x="4" y="18" width="8" height="2" fill="#fff" />
          <text x="4" y="14" fill="#fff" fontSize="8" fontFamily="monospace" fontWeight="bold">
            JB
          </text>
        </svg>
      );
    case "neovim":
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
          <path d="M2 3L10 12L2 21V3Z" fill="#57A143" />
          <path d="M22 3L14 12L22 21V3Z" fill="#57A143" />
          <path d="M2 3L14 21H22L10 3H2Z" fill="#4E9A06" />
        </svg>
      );
    case "cursor":
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
          <rect width="24" height="24" rx="6" fill="#1A1A2E" />
          <path d="M7 6L17 12L7 18V6Z" fill="#8B5CF6" />
        </svg>
      );
    case "claude":
      return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
          <rect width="24" height="24" rx="6" fill="#D97706" opacity="0.15" />
          <circle cx="12" cy="12" r="6" fill="#D97706" />
          <circle cx="12" cy="12" r="3" fill="#FDE68A" />
        </svg>
      );
    default:
      return <div className="w-7 h-7 rounded bg-white/10" />;
  }
}

/* ── Extension card ─────────────────────────────── */

function ExtensionCard({ ext }: { ext: Extension }) {
  const isAvailable = ext.status === "available";

  return (
    <div className="glass-card p-6 flex flex-col h-full group hover:border-white/15 transition-all">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div
            className={`w-12 h-12 rounded-xl ${ext.bgColor} border border-white/[0.06] flex items-center justify-center`}
          >
            <IDEIcon icon={ext.icon} size={24} />
          </div>
          <div>
            <h3 className="text-text font-semibold text-sm group-hover:text-accent transition-colors">
              {ext.name}
            </h3>
            <p className="text-muted text-xs">{ext.ide}</p>
          </div>
        </div>
        {isAvailable ? (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-accent/10 text-accent text-[10px] font-mono uppercase tracking-wider border border-accent/20">
            <Zap size={9} /> Available
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/[0.04] text-muted text-[10px] font-mono uppercase tracking-wider border border-white/[0.06]">
            Coming Soon
          </span>
        )}
      </div>

      {/* Description */}
      <p className="text-muted text-sm leading-relaxed mb-5 flex-1">
        {ext.description}
      </p>

      {/* Features */}
      <div className="space-y-2 mb-5">
        {ext.features.map((f) => (
          <div key={f} className="flex items-center gap-2 text-xs text-muted">
            <span className={ext.color}>
              <Star size={10} />
            </span>
            {f}
          </div>
        ))}
      </div>

      {/* Action */}
      {isAvailable ? (
        <a
          href={ext.marketplaceUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-primary px-4 py-2.5 text-xs w-full text-center"
        >
          <Download size={13} /> Install Extension
          <ArrowUpRight size={11} className="ml-auto opacity-60" />
        </a>
      ) : (
        <button
          disabled
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-md bg-white/[0.04] border border-white/[0.08] text-muted text-xs font-medium cursor-not-allowed"
        >
          <RefreshCw size={13} /> Notify Me When Available
        </button>
      )}
    </div>
  );
}

/* ── Main ───────────────────────────────────────── */

export default function ExtensionsPage() {
  return (
    <PageContainer>
      <AnimatedCard className="mb-8">
        <h2 className="text-2xl font-bold text-text">Extensions</h2>
        <p className="text-muted text-sm mt-0.5">
          Bring CKG intelligence directly into your favorite IDE
        </p>
      </AnimatedCard>

      {/* MCP highlight banner */}
      <AnimatedCard className="mb-6">
        <div
          className="glass-card p-6 border-accent/20"
          style={{
            background:
              "linear-gradient(135deg, rgba(0,229,153,0.08) 0%, rgba(0,229,153,0.02) 100%)",
          }}
        >
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
              <Shield size={18} className="text-accent" />
            </div>
            <div>
              <h3 className="text-text font-semibold text-sm mb-1">
                Works with any MCP-compatible client
              </h3>
              <p className="text-muted text-xs leading-relaxed">
                CKG exposes a full MCP server with 8 tools, 5 resources, and 3
                guided prompts. Any IDE or AI assistant that supports the Model
                Context Protocol can connect to CKG instantly — no extension
                required. Run{" "}
                <code className="px-1.5 py-0.5 rounded bg-white/[0.06] text-accent text-[11px] font-mono">
                  csg mcp
                </code>{" "}
                to start the server.
              </p>
            </div>
          </div>
        </div>
      </AnimatedCard>

      {/* Extension cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {EXTENSIONS.map((ext) => (
          <AnimatedCard key={ext.id}>
            <ExtensionCard ext={ext} />
          </AnimatedCard>
        ))}
      </div>

      {/* Integration code snippet */}
      <AnimatedCard>
        <div className="glass-card p-6">
          <h3 className="text-text font-semibold text-sm mb-4 flex items-center gap-2">
            <ExternalLink size={14} className="text-accent" />
            Quick MCP Integration
          </h3>
          <p className="text-muted text-xs mb-4">
            Add this to your Claude Desktop or MCP client configuration:
          </p>
          <pre className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-4 text-xs font-mono text-muted overflow-x-auto">
            <code>
{`{
  "mcpServers": {
    "ckg": {
      "command": "csg",
      "args": ["mcp"],
      "env": {}
    }
  }
}`}
            </code>
          </pre>
          <p className="text-muted text-[11px] mt-3">
            For HTTP transport, run{" "}
            <code className="px-1 py-0.5 rounded bg-white/[0.04] text-accent text-[10px]">
              csg mcp --transport http
            </code>{" "}
            and connect to{" "}
            <code className="px-1 py-0.5 rounded bg-white/[0.04] text-accent text-[10px]">
              http://localhost:8080/mcp
            </code>
          </p>
        </div>
      </AnimatedCard>
    </PageContainer>
  );
}
