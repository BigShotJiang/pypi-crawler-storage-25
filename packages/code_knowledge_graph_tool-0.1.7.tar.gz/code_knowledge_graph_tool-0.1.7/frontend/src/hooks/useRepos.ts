import { useCallback, useEffect, useState } from "react";
import type { RepoListItem } from "../types";
import { fetchRepos, deleteRepo } from "../api";

export function useRepos() {
  const [repos, setRepos] = useState<RepoListItem[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const data = await fetchRepos();
      setRepos(data);
    } catch {
      setRepos([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const removeRepo = useCallback(
    async (id: string) => {
      await deleteRepo(id);
      refresh();
    },
    [refresh]
  );

  return { repos, loading, refresh, removeRepo };
}
