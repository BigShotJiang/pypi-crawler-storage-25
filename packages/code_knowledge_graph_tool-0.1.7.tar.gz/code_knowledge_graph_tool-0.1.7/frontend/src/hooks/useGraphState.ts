import { useCallback, useEffect, useMemo, useState } from "react";
import { DEFAULT_HIDDEN_TYPES } from "../constants";
import type { GraphEdge, GraphNode } from "../types";

const PREFS_KEY = "ckg-graph-prefs";

interface GraphState {
  selectedNodeId: string | null;
  hiddenNodeTypes: Set<string>;
  hiddenEdgeTypes: Set<string>;
  depthFilter: number | null;
  focusedProcessId: string | null;
  showAll: boolean;
  communityColorMode: boolean;
  groupByCommunity: boolean;
}

function loadPrefs(): Partial<GraphState> {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return {};
    const p = JSON.parse(raw);
    return {
      communityColorMode: p.communityColorMode ?? false,
      groupByCommunity: p.groupByCommunity ?? false,
      depthFilter: p.depthFilter ?? 1,
      showAll: p.showAll ?? false,
      hiddenNodeTypes: p.hiddenNodeTypes ? new Set(p.hiddenNodeTypes) : undefined,
      hiddenEdgeTypes: p.hiddenEdgeTypes ? new Set(p.hiddenEdgeTypes) : undefined,
    };
  } catch { return {}; }
}

export function useGraphState(nodes: GraphNode[], edges: GraphEdge[]) {
  const saved = loadPrefs();
  const autoCluster = saved.groupByCommunity ?? (nodes.length > 1500);
  const [highlightedNodeIds, setHighlightedNodeIds] = useState<Set<string>>(new Set());
  const [state, setState] = useState<GraphState>({
    selectedNodeId: null,
    hiddenNodeTypes: saved.hiddenNodeTypes ?? new Set(DEFAULT_HIDDEN_TYPES),
    hiddenEdgeTypes: saved.hiddenEdgeTypes ?? new Set(),
    depthFilter: saved.depthFilter ?? 1,
    focusedProcessId: null,
    showAll: saved.showAll ?? false,
    communityColorMode: saved.communityColorMode ?? false,
    groupByCommunity: autoCluster,
  });

  // Persist preferences (not selection/focus — those are ephemeral)
  useEffect(() => {
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify({
        communityColorMode: state.communityColorMode,
        groupByCommunity: state.groupByCommunity,
        depthFilter: state.depthFilter,
        showAll: state.showAll,
        hiddenNodeTypes: [...state.hiddenNodeTypes],
        hiddenEdgeTypes: [...state.hiddenEdgeTypes],
      }));
    } catch {}
  }, [state.communityColorMode, state.groupByCommunity, state.depthFilter, state.showAll, state.hiddenNodeTypes, state.hiddenEdgeTypes]);

  const selectNode = useCallback((nodeId: string) => {
    setState((prev) => ({
      ...prev,
      selectedNodeId: nodeId,
      focusedProcessId: null,
    }));
  }, []);

  const clearSelection = useCallback(() => {
    setState((prev) => ({ ...prev, selectedNodeId: null }));
  }, []);

  const toggleNodeType = useCallback((type: string) => {
    setState((prev) => {
      const next = new Set(prev.hiddenNodeTypes);
      if (next.has(type)) next.delete(type);
      else next.add(type);
      return { ...prev, hiddenNodeTypes: next };
    });
  }, []);

  const toggleEdgeType = useCallback((type: string) => {
    setState((prev) => {
      const next = new Set(prev.hiddenEdgeTypes);
      if (next.has(type)) next.delete(type);
      else next.add(type);
      return { ...prev, hiddenEdgeTypes: next };
    });
  }, []);

  const setDepthFilter = useCallback((depth: number | null) => {
    setState((prev) => ({ ...prev, depthFilter: depth }));
  }, []);

  const toggleProcessFocus = useCallback((processId: string) => {
    setState((prev) => ({
      ...prev,
      focusedProcessId:
        prev.focusedProcessId === processId ? null : processId,
      selectedNodeId:
        prev.focusedProcessId === processId ? prev.selectedNodeId : null,
    }));
  }, []);

  const toggleShowAll = useCallback(() => {
    setState((prev) => {
      const next = !prev.showAll;
      return {
        ...prev,
        showAll: next,
        hiddenNodeTypes: next ? new Set() : new Set(DEFAULT_HIDDEN_TYPES),
      };
    });
  }, []);

  const toggleCommunityColorMode = useCallback(() => {
    setState((prev) => ({ ...prev, communityColorMode: !prev.communityColorMode }));
  }, []);

  const toggleGroupByCommunity = useCallback(() => {
    setState((prev) => ({ ...prev, groupByCommunity: !prev.groupByCommunity }));
  }, []);

  const clearHighlightedNodeIds = useCallback(() => {
    setHighlightedNodeIds(new Set());
  }, []);

  // Ensure a node is visible by unhiding its type if currently filtered out
  const ensureNodeVisible = useCallback((nodeId: string) => {
    const node = nodes.find((n) => n.id === nodeId);
    if (!node) return;
    setState((prev) => {
      if (!prev.hiddenNodeTypes.has(node.nodeType)) return prev;
      const next = new Set(prev.hiddenNodeTypes);
      next.delete(node.nodeType);
      return { ...prev, hiddenNodeTypes: next };
    });
  }, [nodes]);

  // Memoize adjacency list (only rebuilt when edges change, not on every filter)
  const adjacencyList = useMemo(() => {
    const adj: Record<string, string[]> = {};
    for (const e of edges) {
      (adj[e.source] ??= []).push(e.target);
      (adj[e.target] ??= []).push(e.source);
    }
    return adj;
  }, [edges]);

  // BFS visibility computation
  const visibleNodeIds = useMemo(() => {
    const { selectedNodeId, depthFilter } = state;
    if (!selectedNodeId) return null;
    // null means show all nodes (no hop limit)
    if (depthFilter === null) return null;

    const maxHops = depthFilter;
    const visited = new Set<string>([selectedNodeId]);
    let frontier = [selectedNodeId];

    for (let d = 0; d < maxHops; d++) {
      const next: string[] = [];
      for (const nid of frontier) {
        for (const nb of adjacencyList[nid] ?? []) {
          if (!visited.has(nb)) {
            visited.add(nb);
            next.push(nb);
          }
        }
      }
      frontier = next;
      if (!frontier.length) break;
    }

    return visited;
  }, [state.selectedNodeId, state.depthFilter, adjacencyList]);

  // Process focus step IDs
  const processStepIds = useMemo(() => {
    const { focusedProcessId } = state;
    if (!focusedProcessId) return null;

    const steps = new Set<string>([focusedProcessId]);
    for (const e of edges) {
      if (e.type === "STEP_IN_PROCESS") {
        if (e.target === focusedProcessId) steps.add(e.source);
        if (e.source === focusedProcessId) steps.add(e.target);
      }
    }
    return steps;
  }, [state.focusedProcessId, edges]);

  // Filtered node pass set
  const filterPassIds = useMemo(() => {
    const pass = new Set<string>();
    for (const n of nodes) {
      const passDepth = visibleNodeIds === null || visibleNodeIds.has(n.id);
      const passType = !state.hiddenNodeTypes.has(n.nodeType);
      if (passDepth && passType) pass.add(n.id);
    }
    return pass;
  }, [nodes, visibleNodeIds, state.hiddenNodeTypes]);

  const selectedNode = useMemo(
    () => nodes.find((n) => n.id === state.selectedNodeId) ?? null,
    [nodes, state.selectedNodeId],
  );

  return {
    ...state,
    selectedNode,
    visibleNodeIds,
    processStepIds,
    filterPassIds,
    highlightedNodeIds,
    setHighlightedNodeIds,
    clearHighlightedNodeIds,
    selectNode,
    clearSelection,
    toggleNodeType,
    toggleEdgeType,
    setDepthFilter,
    toggleProcessFocus,
    toggleShowAll,
    ensureNodeVisible,
    toggleCommunityColorMode,
    toggleGroupByCommunity,
  };
}
