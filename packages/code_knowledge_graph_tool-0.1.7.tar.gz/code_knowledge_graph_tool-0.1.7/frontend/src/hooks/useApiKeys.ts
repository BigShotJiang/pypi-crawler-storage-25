import { useCallback, useEffect, useState } from "react";
import type { ApiKeyItem } from "../types";
import { fetchApiKeys, createApiKey, deleteApiKey } from "../api";

export function useApiKeys() {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const data = await fetchApiKeys();
      setKeys(data);
    } catch {
      setKeys([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const addKey = useCallback(
    async (description: string) => {
      const key = await createApiKey(description);
      setKeys((prev) => [...prev, key]);
      return key;
    },
    []
  );

  const removeKey = useCallback(
    async (id: string) => {
      await deleteApiKey(id);
      refresh();
    },
    [refresh]
  );

  return { keys, loading, addKey, removeKey };
}
