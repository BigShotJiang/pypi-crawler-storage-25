import { useCallback, useEffect, useState } from "react";
import type { UserSecretStatus, UserSettings } from "../types";
import {
  deleteOpenAiApiKey,
  fetchUserSecretStatus,
  fetchUserSettings,
  setOpenAiApiKey,
  updateUserSettings,
} from "../api";

export function useSettings() {
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [secretStatus, setSecretStatus] = useState<UserSecretStatus | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [settingsData, secretData] = await Promise.all([
        fetchUserSettings(),
        fetchUserSecretStatus(),
      ]);
      setSettings(settingsData);
      setSecretStatus(secretData);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const saveSettings = useCallback(async (nextSettings: UserSettings) => {
    const saved = await updateUserSettings(nextSettings);
    setSettings(saved);
    return saved;
  }, []);

  const saveOpenAiKey = useCallback(async (apiKey: string) => {
    const saved = await setOpenAiApiKey(apiKey);
    setSecretStatus(saved);
    return saved;
  }, []);

  const clearOpenAiKey = useCallback(async () => {
    await deleteOpenAiApiKey();
    setSecretStatus({
      openai_api_key_configured: false,
      updated_at: null,
      important_reminder:
        "Important: OpenAI features use only the API key saved in your user Settings. Add your own OpenAI API key in Settings before using embeddings, OCR, chat, or SRS.",
    });
  }, []);

  return {
    settings,
    secretStatus,
    loading,
    refresh,
    saveSettings,
    saveOpenAiKey,
    clearOpenAiKey,
  };
}
