import { useCallback, useState } from "react";
import { analyzeRepo, analyzeGitRepo, analyzeUrlRepo } from "../api";
import type { AnalysisResult, StatusMessage } from "../types";

interface AnalysisState {
  status: "idle" | "uploading" | "done" | "error";
  messages: Array<{ text: string; isError: boolean }>;
  result: AnalysisResult | null;
}

export function useAnalysis() {
  const [state, setState] = useState<AnalysisState>({
    status: "idle",
    messages: [],
    result: null,
  });

  const addMessage = useCallback((text: string, isError = false) => {
    setState((prev) => ({
      ...prev,
      messages: [...prev.messages, { text, isError }],
    }));
  }, []);

  const callbacks = useCallback(
    () => ({
      onStatus: (msg: StatusMessage) => addMessage(msg.message),
      onResult: (result: AnalysisResult) => {
        addMessage(`Results received (${result.summary.total_nodes} nodes)`);
        setState((prev) => ({ ...prev, result }));
      },
      onError: (message: string) => {
        addMessage(`Error: ${message}`, true);
        setState((prev) => ({ ...prev, status: "error" }));
      },
      onDone: () => {
        addMessage("Rendering graph...");
        setState((prev) => ({ ...prev, status: "done" }));
      },
    }),
    [addMessage],
  );

  const startAnalysis = useCallback(
    async (file: File) => {
      setState({ status: "uploading", messages: [], result: null });
      addMessage(`Uploading ${file.name}...`);
      try {
        const cb = callbacks();
        await analyzeRepo(file, cb.onStatus, cb.onResult, cb.onError, cb.onDone);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unknown error";
        addMessage(`Error: ${message}`, true);
        setState((prev) => ({ ...prev, status: "error" }));
      }
    },
    [addMessage, callbacks],
  );

  const startGitAnalysis = useCallback(
    async (url: string, branch?: string) => {
      setState({ status: "uploading", messages: [], result: null });
      addMessage(`Cloning ${url}${branch ? ` (${branch})` : ""}...`);
      try {
        const cb = callbacks();
        await analyzeGitRepo(url, branch ?? "", cb.onStatus, cb.onResult, cb.onError, cb.onDone);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unknown error";
        addMessage(`Error: ${message}`, true);
        setState((prev) => ({ ...prev, status: "error" }));
      }
    },
    [addMessage, callbacks],
  );

  const startUrlAnalysis = useCallback(
    async (url: string) => {
      setState({ status: "uploading", messages: [], result: null });
      addMessage(`Downloading from ${url}...`);
      try {
        const cb = callbacks();
        await analyzeUrlRepo(url, cb.onStatus, cb.onResult, cb.onError, cb.onDone);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unknown error";
        addMessage(`Error: ${message}`, true);
        setState((prev) => ({ ...prev, status: "error" }));
      }
    },
    [addMessage, callbacks],
  );

  const reset = useCallback(() => {
    setState({ status: "idle", messages: [], result: null });
  }, []);

  return { ...state, startAnalysis, startGitAnalysis, startUrlAnalysis, reset };
}
