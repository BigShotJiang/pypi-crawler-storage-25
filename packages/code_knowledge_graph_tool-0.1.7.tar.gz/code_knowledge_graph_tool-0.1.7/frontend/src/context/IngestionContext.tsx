import { createContext, useContext, useState, useCallback, useRef } from "react";
import { analyzeRepo, analyzeGitRepo, analyzeUrlRepo, cancelJob as apiCancelJob } from "../api";
import type { AnalysisResult } from "../types";

export interface IngestionJob {
  id: string;
  name: string;
  status: "uploading" | "done" | "error" | "cancelled";
  messages: Array<{ text: string; isError: boolean }>;
  result: AnalysisResult | null;
}

interface IngestionContextValue {
  jobs: IngestionJob[];
  startAnalysis: (file: File) => void;
  startGitAnalysis: (url: string, branch?: string) => void;
  startUrlAnalysis: (url: string) => void;
  cancelJob: (id: string) => void;
}

const IngestionContext = createContext<IngestionContextValue | null>(null);

let _nextId = 0;

export function IngestionProvider({ children }: { children: React.ReactNode }) {
  const [jobs, setJobs] = useState<IngestionJob[]>([]);
  const controllersRef = useRef<Map<string, AbortController>>(new Map());
  const backendJobIdsRef = useRef<Map<string, string>>(new Map());

  const updateJob = useCallback((id: string, updates: Partial<IngestionJob>) => {
    setJobs(prev => prev.map(j => (j.id === id ? { ...j, ...updates } : j)));
  }, []);

  const addMessage = useCallback((id: string, text: string, isError = false) => {
    setJobs(prev =>
      prev.map(j =>
        j.id === id ? { ...j, messages: [...j.messages, { text, isError }] } : j,
      ),
    );
  }, []);

  const cleanupController = useCallback((id: string) => {
    controllersRef.current.delete(id);
    backendJobIdsRef.current.delete(id);
  }, []);

  const makeJobIdHandler = useCallback((id: string) => {
    return (backendJobId: string) => {
      backendJobIdsRef.current.set(id, backendJobId);
    };
  }, []);

  const makeCancelledHandler = useCallback((id: string) => {
    return () => {
      addMessage(id, "Analysis cancelled and rolled back");
      updateJob(id, { status: "cancelled" });
      cleanupController(id);
    };
  }, [addMessage, updateJob, cleanupController]);

  const startAnalysis = useCallback(
    (file: File) => {
      const id = String(++_nextId);
      const name = file.name.replace(/\.zip$/i, "");
      const controller = new AbortController();
      controllersRef.current.set(id, controller);

      setJobs(prev => [...prev, { id, name, status: "uploading", messages: [], result: null }]);

      analyzeRepo(
        file,
        (msg) => addMessage(id, msg.message),
        (result) => {
          addMessage(id, `Results received (${result.summary.total_nodes} nodes)`);
          updateJob(id, { result });
        },
        (message) => {
          addMessage(id, `Error: ${message}`, true);
          updateJob(id, { status: "error" });
          cleanupController(id);
        },
        () => {
          addMessage(id, "Rendering graph...");
          updateJob(id, { status: "done" });
          cleanupController(id);
        },
        controller.signal,
        makeJobIdHandler(id),
        makeCancelledHandler(id),
      ).catch(() => {
        /* abort throws — safe to ignore */
      });
    },
    [addMessage, updateJob, cleanupController, makeJobIdHandler, makeCancelledHandler],
  );

  const startGitAnalysis = useCallback(
    (url: string, branch?: string) => {
      const id = String(++_nextId);
      const name = url.split("/").pop()?.replace(/\.git$/, "") ?? url;
      const controller = new AbortController();
      controllersRef.current.set(id, controller);

      setJobs(prev => [...prev, { id, name, status: "uploading", messages: [], result: null }]);

      analyzeGitRepo(
        url,
        branch ?? "",
        (msg) => addMessage(id, msg.message),
        (result) => {
          addMessage(id, `Results received (${result.summary.total_nodes} nodes)`);
          updateJob(id, { result });
        },
        (message) => {
          addMessage(id, `Error: ${message}`, true);
          updateJob(id, { status: "error" });
          cleanupController(id);
        },
        () => {
          addMessage(id, "Rendering graph...");
          updateJob(id, { status: "done" });
          cleanupController(id);
        },
        controller.signal,
        makeJobIdHandler(id),
        makeCancelledHandler(id),
      ).catch(() => {
        /* abort throws — safe to ignore */
      });
    },
    [addMessage, updateJob, cleanupController, makeJobIdHandler, makeCancelledHandler],
  );

  const startUrlAnalysis = useCallback(
    (url: string) => {
      const id = String(++_nextId);
      const name = url.split("/").pop()?.replace(/\.zip$/i, "") ?? url;
      const controller = new AbortController();
      controllersRef.current.set(id, controller);

      setJobs(prev => [...prev, { id, name, status: "uploading", messages: [], result: null }]);

      analyzeUrlRepo(
        url,
        (msg) => addMessage(id, msg.message),
        (result) => {
          addMessage(id, `Results received (${result.summary.total_nodes} nodes)`);
          updateJob(id, { result });
        },
        (message) => {
          addMessage(id, `Error: ${message}`, true);
          updateJob(id, { status: "error" });
          cleanupController(id);
        },
        () => {
          addMessage(id, "Rendering graph...");
          updateJob(id, { status: "done" });
          cleanupController(id);
        },
        controller.signal,
        makeJobIdHandler(id),
        makeCancelledHandler(id),
      ).catch(() => {
        /* abort throws — safe to ignore */
      });
    },
    [addMessage, updateJob, cleanupController, makeJobIdHandler, makeCancelledHandler],
  );

  const cancelJob = useCallback((id: string) => {
    // 1. Signal backend to cancel pipeline + rollback
    const backendJobId = backendJobIdsRef.current.get(id);
    if (backendJobId) {
      apiCancelJob(backendJobId).catch(() => {});
      backendJobIdsRef.current.delete(id);
    }

    // 2. Abort the SSE stream
    const controller = controllersRef.current.get(id);
    if (controller) {
      controller.abort();
      controllersRef.current.delete(id);
    }

    // 3. Remove from UI
    setJobs(prev => prev.filter(j => j.id !== id));
  }, []);

  return (
    <IngestionContext.Provider
      value={{ jobs, startAnalysis, startGitAnalysis, startUrlAnalysis, cancelJob }}
    >
      {children}
    </IngestionContext.Provider>
  );
}

export function useIngestion(): IngestionContextValue {
  const ctx = useContext(IngestionContext);
  if (!ctx) throw new Error("useIngestion must be used within IngestionProvider");
  return ctx;
}
