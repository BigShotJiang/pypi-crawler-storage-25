import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { fetchCurrentUser, loginUser, logoutUser, registerUser } from "../api";
import type { AuthUser } from "../types";

interface AuthState {
  initializing: boolean;
  isAuthenticated: boolean;
  user: AuthUser | null;
  login: (identifier: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    let active = true;
    const loadUser = async () => {
      try {
        const currentUser = await fetchCurrentUser();
        if (active) setUser(currentUser);
      } catch {
        if (active) setUser(null);
      } finally {
        if (active) setInitializing(false);
      }
    };
    void loadUser();
    return () => {
      active = false;
    };
  }, []);

  const login = async (identifier: string, password: string) => {
    const currentUser = await loginUser(identifier, password);
    setUser(currentUser);
  };

  const register = async (username: string, email: string, password: string) => {
    const currentUser = await registerUser(username, email, password);
    setUser(currentUser);
  };

  const logout = async () => {
    try {
      await logoutUser();
    } finally {
      setUser(null);
    }
  };

  const refreshUser = async () => {
    try {
      const currentUser = await fetchCurrentUser();
      setUser(currentUser);
    } catch {
      setUser(null);
    }
  };

  return (
    <AuthContext.Provider value={{ initializing, isAuthenticated: user !== null, user, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
