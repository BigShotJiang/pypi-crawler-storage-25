// ── Layout dimensions ────────────────────────────────────────────
export const SIDEBAR_WIDTH = 240;
export const LEFT_PANEL_WIDTH = 280;
export const RIGHT_PANEL_WIDTH = 340;
export const CODE_PANEL_MIN_WIDTH = 300;
export const TOOLBAR_BTN_SIZE = 34;
export const AI_PANEL_WIDTH = 380;
export const AI_PANEL_WIDTH_EXPANDED = 600;
export const AI_PANEL_HEIGHT = 480;
export const PANEL_GAP = 12;
export const PANEL_GAP_OPEN = 16;

// ── Graph colors ─────────────────────────────────────────────────
export const NODE_COLORS: Record<string, string> = {
  Project: "#c084fc",
  Package: "#818cf8",
  Module: "#67e8f9",
  Folder: "#6366f1",
  File: "#38bdf8",
  Class: "#fbbf24",
  Function: "#34d399",
  Method: "#2dd4bf",
  Interface: "#f472b6",
  Enum: "#fb923c",
  Type: "#a78bfa",
  Variable: "#94a3b8",
  Import: "#64748b",
  Decorator: "#facc15",
  Community: "#818cf8",
  Process: "#fb7185",
  CodeElement: "#94a3b8",
};

export const NODE_SIZES: Record<string, number> = {
  Project: 40,
  Package: 35,
  Module: 28,
  Folder: 22,
  File: 16,
  Class: 28,
  Function: 16,
  Method: 14,
  Interface: 24,
  Enum: 18,
  Type: 16,
  Variable: 10,
  Import: 8,
  Decorator: 14,
  Community: 32,
  Process: 28,
  CodeElement: 12,
};

export const EDGE_COLORS: Record<string, string> = {
  CONTAINS: "#4ade80",
  DEFINES: "#22d3ee",
  IMPORTS: "#60a5fa",
  CALLS: "#a78bfa",
  EXTENDS: "#f97316",
  IMPLEMENTS: "#ec4899",
  HAS_METHOD: "#14b8a6",
  HAS_PROPERTY: "#14b8a6",
  MEMBER_OF: "#818cf8",
  STEP_IN_PROCESS: "#fb7185",
  OVERRIDES: "#eab308",
  INHERITS: "#f97316",
  USES: "#94a3b8",
  ACCESSES: "#94a3b8",
  DECORATES: "#facc15",
};

export const NODE_SHAPES: Record<string, string> = {
  Class: "diamond",
  Interface: "diamond",
  Function: "ellipse",
  Method: "ellipse",
  File: "rectangle",
  Folder: "triangle",
  Community: "hexagon",
  Process: "star",
  Enum: "vee",
  Decorator: "triangle",
};

export const FILE_COLORS: Record<string, string> = {
  py: "#34d399",
  js: "#fbbf24",
  ts: "#38bdf8",
  jsx: "#fbbf24",
  tsx: "#38bdf8",
  java: "#fb923c",
  go: "#67e8f9",
  rs: "#fb923c",
  rb: "#f43f5e",
  php: "#818cf8",
  c: "#94a3b8",
  cpp: "#94a3b8",
  h: "#94a3b8",
  cs: "#a78bfa",
  kt: "#c084fc",
  swift: "#f97316",
  json: "#fbbf24",
  yaml: "#f472b6",
  yml: "#f472b6",
  md: "#94a3b8",
  toml: "#94a3b8",
  html: "#f97316",
  css: "#38bdf8",
  scss: "#f472b6",
};

export const COMMUNITY_COLORS: string[] = [
  "#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4",
  "#3b82f6", "#8b5cf6", "#d946ef", "#ec4899", "#f43f5e",
  "#14b8a6", "#84cc16",
];

export const DEFAULT_HIDDEN_TYPES = new Set([
  "Project", "Package", "Module", "Class", "Function", "Method",
  "Interface", "Enum", "Type", "Variable", "Import", "Decorator",
  "Community", "Process", "CodeElement",
]);

export const NON_CODE_TYPES = new Set([
  "Community",
  "Process",
  "Folder",
  "Project",
  "Package",
  "Module",
]);
