import type {
  AnalysisResult,
  StatusMessage,
  RepoListItem,
  DashboardStats,
  ApiKeyItem,
  AuthUser,
  UserSecretStatus,
  UserSettings,
} from "./types";

export interface SSECallbacks {
  onStatus: (msg: StatusMessage) => void;
  onResult: (result: AnalysisResult) => void;
  onError: (message: string) => void;
  onDone: () => void;
  onJobId?: (jobId: string) => void;
  onCancelled?: () => void;
}

async function readErrorMessage(resp: Response): Promise<string> {
  const fallback = resp.statusText || "Request failed";
  try {
    const contentType = resp.headers.get("content-type") ?? "";
    if (contentType.includes("application/json")) {
      const payload = await resp.json();
      if (typeof payload?.detail === "string") return payload.detail;
      if (typeof payload?.message === "string") return payload.message;
    }
    const text = await resp.text();
    return text || fallback;
  } catch {
    return fallback;
  }
}

async function refreshAuthSession(): Promise<boolean> {
  const resp = await fetch("/api/auth/refresh", {
    method: "POST",
    credentials: "include",
  });
  return resp.ok;
}

async function fetchWithSession(input: RequestInfo | URL, init: RequestInit = {}, retry = true): Promise<Response> {
  const resp = await fetch(input, {
    ...init,
    credentials: "include",
  });
  if (resp.status === 401 && retry) {
    const refreshed = await refreshAuthSession();
    if (refreshed) {
      return fetchWithSession(input, init, false);
    }
  }
  return resp;
}

export async function registerUser(
  username: string,
  email: string,
  password: string,
): Promise<AuthUser> {
  const resp = await fetch("/api/auth/register", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password }),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  const data = await resp.json();
  return data.user as AuthUser;
}

export async function loginUser(
  identifier: string,
  password: string,
): Promise<AuthUser> {
  const resp = await fetch("/api/auth/login", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identifier, password }),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  const data = await resp.json();
  return data.user as AuthUser;
}

export async function logoutUser(): Promise<void> {
  const resp = await fetch("/api/auth/logout", {
    method: "POST",
    credentials: "include",
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
}

export async function fetchCurrentUser(): Promise<AuthUser> {
  const resp = await fetchWithSession("/api/auth/me");
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  const data = await resp.json();
  return data.user as AuthUser;
}

export async function fetchUserSettings(): Promise<UserSettings> {
  const resp = await fetchWithSession("/api/settings/me");
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}

export async function updateUserSettings(settings: UserSettings): Promise<UserSettings> {
  const resp = await fetchWithSession("/api/settings/me", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(settings),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}

export async function fetchUserSecretStatus(): Promise<UserSecretStatus> {
  const resp = await fetchWithSession("/api/settings/me/secrets/status");
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}

export async function setOpenAiApiKey(apiKey: string): Promise<UserSecretStatus> {
  const resp = await fetchWithSession("/api/settings/me/secrets/openai", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ api_key: apiKey }),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}

export async function deleteOpenAiApiKey(): Promise<void> {
  const resp = await fetchWithSession("/api/settings/me/secrets/openai", { method: "DELETE" });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
}

export async function updateProfile(username: string): Promise<AuthUser> {
  const resp = await fetchWithSession("/api/account/me/profile", {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username }),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  const data = await resp.json();
  return data.user as AuthUser;
}

export async function changePassword(currentPassword: string, newPassword: string): Promise<void> {
  const resp = await fetchWithSession("/api/account/me/password", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      current_password: currentPassword,
      new_password: newPassword,
    }),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
}

export async function deleteAccount(): Promise<void> {
  const resp = await fetchWithSession("/api/account/me", { method: "DELETE" });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
}

export async function analyzeRepo(
  file: File,
  onStatus: (msg: StatusMessage) => void,
  onResult: (result: AnalysisResult) => void,
  onError: (message: string) => void,
  onDone: () => void,
  signal?: AbortSignal,
  onJobId?: (jobId: string) => void,
  onCancelled?: () => void,
): Promise<void> {
  const formData = new FormData();
  formData.append("file", file);

  const resp = await fetchWithSession("/api/analyze", {
    method: "POST",
    body: formData,
    signal,
  });

  if (!resp.ok) {
    onError(`Upload failed: ${await readErrorMessage(resp)}`);
    return;
  }

  await _readSSEStream(resp, { onStatus, onResult, onError, onDone, onJobId, onCancelled });
}

export async function analyzeGitRepo(
  url: string,
  branch: string,
  onStatus: (msg: StatusMessage) => void,
  onResult: (result: AnalysisResult) => void,
  onError: (message: string) => void,
  onDone: () => void,
  signal?: AbortSignal,
  onJobId?: (jobId: string) => void,
  onCancelled?: () => void,
): Promise<void> {
  const resp = await fetchWithSession("/api/analyze-git", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url, branch }),
    signal,
  });

  if (!resp.ok) {
    const detail = await readErrorMessage(resp);
    onError(`Request failed: ${detail}`);
    return;
  }

  await _readSSEStream(resp, { onStatus, onResult, onError, onDone, onJobId, onCancelled });
}

export async function analyzeUrlRepo(
  url: string,
  onStatus: (msg: StatusMessage) => void,
  onResult: (result: AnalysisResult) => void,
  onError: (message: string) => void,
  onDone: () => void,
  signal?: AbortSignal,
  onJobId?: (jobId: string) => void,
  onCancelled?: () => void,
): Promise<void> {
  const resp = await fetchWithSession("/api/analyze-url", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
    signal,
  });

  if (!resp.ok) {
    const detail = await readErrorMessage(resp);
    onError(`Request failed: ${detail}`);
    return;
  }

  await _readSSEStream(resp, { onStatus, onResult, onError, onDone, onJobId, onCancelled });
}

export async function cancelJob(jobId: string): Promise<void> {
  const resp = await fetchWithSession(`/api/jobs/${jobId}/cancel`, { method: "POST" });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
}

async function _readSSEStream(resp: Response, cb: SSECallbacks): Promise<void> {
  const reader = resp.body?.getReader();
  if (!reader) {
    cb.onError("No response body");
    return;
  }

  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split("\n\n");
    buffer = parts.pop() ?? "";

    for (const part of parts) {
      const lines = part.trim().split("\n");
      let event = "";
      let data = "";

      for (const line of lines) {
        if (line.startsWith("event: ")) event = line.slice(7);
        else if (line.startsWith("data: ")) data = line.slice(6);
      }

      if (!event) continue;

      if (event === "job_id") {
        cb.onJobId?.((JSON.parse(data) as { job_id: string }).job_id);
      } else if (event === "status") {
        cb.onStatus(JSON.parse(data) as StatusMessage);
      } else if (event === "result") {
        cb.onResult(JSON.parse(data) as AnalysisResult);
      } else if (event === "error") {
        cb.onError((JSON.parse(data) as { message: string }).message);
      } else if (event === "cancelled") {
        cb.onCancelled?.();
      } else if (event === "done") {
        cb.onDone();
      }
    }
  }
}

export async function fetchFileContent(
  path: string,
  repoId?: string,
): Promise<{ content: string; binary: boolean }> {
  const query = new URLSearchParams({ path });
  if (repoId) query.set("repo_id", repoId);
  const resp = await fetchWithSession(`/api/file?${query.toString()}`);
  if (!resp.ok) throw new Error(await readErrorMessage(resp));

  const ct = resp.headers.get("content-type") ?? "";
  if (ct.includes("application/json")) {
    const json = await resp.json();
    if (json.binary) return { content: "", binary: true };
  }
  return { content: await resp.text(), binary: false };
}


export async function fetchRepos(): Promise<RepoListItem[]> {
  const resp = await fetchWithSession("/api/repos");
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}

export async function deleteRepo(id: string): Promise<void> {
  const resp = await fetchWithSession(`/api/repos/${id}`, { method: "DELETE" });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
}

export async function fetchRepoGraph(id: string): Promise<AnalysisResult> {
  const resp = await fetchWithSession(`/api/repos/${id}/graph`);
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}


export async function fetchStats(): Promise<DashboardStats> {
  const resp = await fetchWithSession("/api/stats");
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}


export async function fetchApiKeys(): Promise<ApiKeyItem[]> {
  const resp = await fetchWithSession("/api/keys");
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}

export async function createApiKey(description: string): Promise<ApiKeyItem> {
  const resp = await fetchWithSession("/api/keys", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ description }),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  return resp.json();
}

export async function deleteApiKey(id: string): Promise<void> {
  const resp = await fetchWithSession(`/api/keys/${id}`, { method: "DELETE" });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
}


interface SelectedNodeContext {
  id: string;
  label: string;
  nodeType: string;
  filePath: string;
  startLine: number | null;
  endLine: number | null;
  communityId?: string | null;
}

export interface AgentResponse {
  response: string;
  prompt_token: number;
  completion_token: number;
  execution_time: number;
  tool_calls?: string[];
}

export async function queryCkgAgent(
  userMessage: string,
  selectedNode?: SelectedNodeContext | null,
  repoId?: string,
): Promise<AgentResponse> {
  const resp = await fetchWithSession("/v1/ckg-agent", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_message: userMessage,
      selected_node: selectedNode ?? null,
      repo_id: repoId ?? null,
    }),
  });
  if (!resp.ok) throw new Error(await readErrorMessage(resp));
  const data = await resp.json();
  return {
    response: data.response,
    prompt_token: data.prompt_token ?? 0,
    completion_token: data.completion_token ?? 0,
    execution_time: data.execution_time ?? 0,
    tool_calls: data.tool_calls ?? [],
  };
}


export interface QueryResult {
  columns: string[];
  rows: unknown[][];
  count: number;
  truncated: boolean;
}

export async function executeQuery(
  repoId: string,
  cypher: string,
): Promise<QueryResult> {
  const resp = await fetchWithSession(`/api/repos/${repoId}/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cypher }),
  });
  if (!resp.ok) {
    throw new Error(await readErrorMessage(resp));
  }
  return resp.json();
}
