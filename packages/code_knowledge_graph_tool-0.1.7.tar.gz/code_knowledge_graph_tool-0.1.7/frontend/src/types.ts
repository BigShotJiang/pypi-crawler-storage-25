export interface GraphNode {
  id: string;
  label: string;
  x: number;
  y: number;
  size: number;
  color: string;
  nodeType: string;
  filePath: string;
  startLine: number | null;
  endLine: number | null;
  communityId?: string | null;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  color: string;
  type: string;
  size: number;
  reviewLabel?: string | null;
}

export interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface AnalysisIssue {
  id: string;
  category: string;
  severity: "info" | "warning" | "critical";
  title: string;
  message: string;
  filePath?: string | null;
  nodeIds: string[];
  metadata: Record<string, unknown>;
}

export interface Community {
  id: string;
  label: string;
  heuristic_label: string;
  cohesion: number;
  symbol_count: number;
}

export interface Process {
  id: string;
  label: string;
  heuristic_label: string;
  process_type: string;
  step_count: number;
}

export interface Summary {
  files: number;
  total_lines: number;
  total_nodes: number;
  total_relationships: number;
  communities: number;
  processes: number;
}

export interface FileTreeItem {
  name: string;
  path: string;
  type: "file" | "folder";
  children?: FileTreeItem[];
}

export interface AnalysisResult {
  summary: Summary;
  nodes_by_label: Record<string, number>;
  relationships_by_type: Record<string, number>;
  communities: Community[];
  processes: Process[];
  symbols: Array<{
    id: string;
    label: string;
    name: string;
    filePath: string;
    kind: string;
  }>;
  graph: GraphData;
  file_tree: FileTreeItem[];
  community_members?: Record<string, string[]>;
  issues?: AnalysisIssue[];
  repo_id?: string;
}

export interface RepoListItem {
  id: string;
  name: string;
  path: string;
  indexed_at: string;
  last_commit: string;
  stats: {
    files: number;
    nodes: number;
    edges: number;
    communities: number;
    processes: number;
  };
}

export interface RepoStats {
  id: string;
  name: string;
  indexed_at: string;
  files: number;
  nodes: number;
  edges: number;
  communities: number;
  processes: number;
  embeddings: number;
}

export interface DashboardStats {
  total_repos: number;
  total_nodes: number;
  total_relationships: number;
  total_communities: number;
  total_processes: number;
  total_files: number;
  total_embeddings: number;
  repos: RepoStats[];
}

export interface ApiKeyItem {
  id: string;
  key: string;
  description: string;
  created_at: string;
}

export interface AuthUser {
  id: string;
  username: string;
  email: string;
  role: string;
  status: string;
  created_at?: string | null;
  updated_at?: string | null;
  last_login_at?: string | null;
}

export interface UserSettings {
  default_branch: string;
  max_file_size_kb: number;
  embeddings_enabled: boolean;
  embedding_provider: "openai" | "local";
  ocr_provider: "openai" | "gemini" | "paddle";
  llm_provider: "openai";
}

export interface UserSecretStatus {
  openai_api_key_configured: boolean;
  updated_at?: string | null;
  important_reminder?: string | null;
}

export interface StatusMessage {
  phase: string;
  message: string;
}

export interface NeighborInfo {
  id: string;
  label: string;
  type: string;
  nodeType: string;
}
