import { Routes, Route, Navigate } from "react-router-dom";
import AppLayout from "./layout/AppLayout";
import ProtectedRoute from "./components/ProtectedRoute";
import { IngestionProvider } from "./context/IngestionContext";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import DashboardPage from "./pages/DashboardPage";
import RepositoriesPage from "./pages/RepositoriesPage";
import GraphListPage from "./pages/GraphListPage";
import GraphPage from "./pages/GraphPage";
import ApiKeysPage from "./pages/ApiKeysPage";
import InstallPage from "./pages/InstallPage";
import SettingsPage from "./pages/SettingsPage";
import ExtensionsPage from "./pages/ExtensionsPage";
import CliGuidePage from "./pages/CliGuidePage";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      <Route element={<ProtectedRoute />}>
        <Route path="/graph/:repoId" element={<GraphPage />} />
      </Route>

      <Route
        element={
          <IngestionProvider>
            <ProtectedRoute />
          </IngestionProvider>
        }
      >
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/graph" element={<GraphListPage />} />
          <Route path="/repositories" element={<RepositoriesPage />} />
          <Route path="/api-keys" element={<ApiKeysPage />} />
          <Route path="/install" element={<InstallPage />} />
          <Route path="/extensions" element={<ExtensionsPage />} />
          <Route path="/cli-guide" element={<CliGuidePage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
