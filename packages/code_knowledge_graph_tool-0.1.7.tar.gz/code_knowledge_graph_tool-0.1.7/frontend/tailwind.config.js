/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "var(--bg)",
        surface: "var(--surface)",
        border: "var(--border)",
        text: "var(--text)",
        muted: "var(--muted)",
        accent: "var(--accent)",
        "accent-hover": "var(--accent-hover)",
        elevated: "var(--elevated)",
        hover: "var(--hover)",
        brand: "var(--accent)",
        brandDark: "var(--accent-hover)",
        bgBase: "var(--bg-base)",
        bgSurface: "var(--bg-surface)",
        bgCard: "var(--bg-card)",
        success: "var(--accent)",
        warning: "var(--warning)",
        danger: "var(--danger)",
        info: "var(--info)",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "BlinkMacSystemFont", "sans-serif"],
        mono: ["JetBrains Mono", "Menlo", "monospace"],
      },
      animation: {
        slideDown: "slideDown 0.2s ease",
        pulse2s: "pulse 2s infinite",
        shimmer: "shimmer 1.5s infinite",
        fadeIn: "fadeIn 0.3s ease-out",
        float: "float 6s ease-in-out infinite",
        nodePulse: "nodePulse 2s ease-in-out infinite alternate",
      },
      keyframes: {
        shimmer: {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(100%)" },
        },
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        float: {
          "0%, 100%": { transform: "translateY(-8px)" },
          "50%": { transform: "translateY(8px)" },
        },
        nodePulse: {
          "0%": { transform: "scale(1)", opacity: "0.7" },
          "100%": { transform: "scale(1.15)", opacity: "1" },
        },
      },
    },
  },
  plugins: [],
};
