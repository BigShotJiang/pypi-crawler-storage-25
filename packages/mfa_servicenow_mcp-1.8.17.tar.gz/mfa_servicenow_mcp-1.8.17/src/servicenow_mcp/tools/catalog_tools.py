"""
Service Catalog tools for the ServiceNow MCP server.

This module provides tools for querying and viewing the service catalog in ServiceNow.
"""

import logging
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from servicenow_mcp.auth.auth_manager import AuthManager
from servicenow_mcp.utils.config import ServerConfig
from servicenow_mcp.utils.registry import register_tool

from .sn_api import invalidate_query_cache, sn_count, sn_query_page

logger = logging.getLogger(__name__)


class ListCatalogItemsParams(BaseModel):
    """Parameters for listing service catalog items."""

    limit: int = Field(default=10, description="Maximum number of catalog items to return")
    offset: int = Field(default=0, description="Offset for pagination")
    category: Optional[str] = Field(default=None, description="Filter by category")
    query: Optional[str] = Field(default=None, description="Search query for catalog items")
    active: bool = Field(default=True, description="Whether to only return active catalog items")
    count_only: bool = Field(
        default=False,
        description="Return count only without fetching records. Uses lightweight Aggregate API.",
    )


class GetCatalogItemParams(BaseModel):
    """Parameters for getting a specific service catalog item."""

    item_id: str = Field(..., description="Catalog item ID or sys_id")


class ListCatalogCategoriesParams(BaseModel):
    """Parameters for listing service catalog categories."""

    limit: int = Field(default=10, description="Maximum number of categories to return")
    offset: int = Field(default=0, description="Offset for pagination")
    query: Optional[str] = Field(default=None, description="Search query for categories")
    active: bool = Field(default=True, description="Whether to only return active categories")


class CatalogResponse(BaseModel):
    """Response from catalog operations."""

    success: bool = Field(..., description="Whether the operation was successful")
    message: str = Field(..., description="Message describing the result")
    data: Optional[Dict[str, Any]] = Field(default=None, description="Response data")


class CreateCatalogCategoryParams(BaseModel):
    """Parameters for creating a new service catalog category."""

    title: str = Field(..., description="Title of the category")
    description: Optional[str] = Field(default=None, description="Description of the category")
    parent: Optional[str] = Field(default=None, description="Parent category sys_id")
    icon: Optional[str] = Field(default=None, description="Icon for the category")
    active: bool = Field(default=True, description="Whether the category is active")
    order: Optional[int] = Field(default=None, description="Order of the category")


class UpdateCatalogCategoryParams(BaseModel):
    """Parameters for updating a service catalog category."""

    category_id: str = Field(..., description="Category ID or sys_id")
    title: Optional[str] = Field(default=None, description="Title of the category")
    description: Optional[str] = Field(default=None, description="Description of the category")
    parent: Optional[str] = Field(default=None, description="Parent category sys_id")
    icon: Optional[str] = Field(default=None, description="Icon for the category")
    active: Optional[bool] = Field(default=None, description="Whether the category is active")
    order: Optional[int] = Field(default=None, description="Order of the category")


class MoveCatalogItemsParams(BaseModel):
    """Parameters for moving catalog items between categories."""

    item_ids: List[str] = Field(..., description="List of catalog item IDs to move")
    target_category_id: str = Field(..., description="Target category ID to move items to")


@register_tool(
    name="list_catalog_items",
    params=ListCatalogItemsParams,
    description="Search catalog items with optional category/active filters. Returns name, price, and category summary.",
    serialization="json",
    return_type=str,
)
def list_catalog_items(
    config: ServerConfig,
    auth_manager: AuthManager,
    params: ListCatalogItemsParams,
) -> Dict[str, Any]:
    """
    List service catalog items from ServiceNow.

    Args:
        config: Server configuration
        auth_manager: Authentication manager
        params: Parameters for listing catalog items

    Returns:
        Dictionary containing catalog items and metadata
    """
    logger.info("Listing service catalog items")

    # Add filters
    filters = []
    if params.active:
        filters.append("active=true")
    if params.category:
        filters.append(f"category={params.category}")
    if params.query:
        filters.append(f"short_descriptionLIKE{params.query}^ORnameLIKE{params.query}")

    query_string = "^".join(filters) if filters else ""

    if params.count_only:
        count = sn_count(config, auth_manager, "sc_cat_item", query_string)
        return {"success": True, "count": count}

    try:
        records, total_count = sn_query_page(
            config,
            auth_manager,
            table="sc_cat_item",
            query=query_string,
            fields="sys_id,name,short_description,category,price,picture,active,order",
            limit=min(params.limit, 100),
            offset=params.offset,
            display_value=True,
            fail_silently=False,
        )

        # Format the response
        formatted_items = []
        for item in records:
            formatted_items.append(
                {
                    "sys_id": item.get("sys_id", ""),
                    "name": item.get("name", ""),
                    "short_description": item.get("short_description", ""),
                    "category": item.get("category", ""),
                    "price": item.get("price", ""),
                    "picture": item.get("picture", ""),
                    "active": item.get("active", ""),
                    "order": item.get("order", ""),
                }
            )

        return {
            "success": True,
            "message": f"Retrieved {len(formatted_items)} catalog items",
            "items": formatted_items,
            "total": len(formatted_items),
            "limit": params.limit,
            "offset": params.offset,
        }

    except Exception as e:
        logger.error(f"Error listing catalog items: {str(e)}")
        return {
            "success": False,
            "message": f"Error listing catalog items: {str(e)}",
            "items": [],
            "total": 0,
            "limit": params.limit,
            "offset": params.offset,
        }


@register_tool(
    name="get_catalog_item",
    params=GetCatalogItemParams,
    description="Fetch a single catalog item by sys_id. Returns full details including variables.",
    serialization="json_dict",
    return_type=str,
)
def get_catalog_item(
    config: ServerConfig,
    auth_manager: AuthManager,
    params: GetCatalogItemParams,
) -> CatalogResponse:
    """
    Get a specific service catalog item from ServiceNow.

    Args:
        config: Server configuration
        auth_manager: Authentication manager
        params: Parameters for getting a catalog item

    Returns:
        Response containing the catalog item details
    """
    logger.info(f"Getting service catalog item: {params.item_id}")

    try:
        records, _ = sn_query_page(
            config,
            auth_manager,
            table="sc_cat_item",
            query=f"sys_id={params.item_id}",
            fields="sys_id,name,short_description,description,category,price,picture,active,order,delivery_time,availability",
            limit=1,
            offset=0,
            display_value=True,
            fail_silently=False,
        )

        if not records:
            return CatalogResponse(
                success=False,
                message=f"Catalog item not found: {params.item_id}",
                data=None,
            )

        item = records[0]

        # Format the response
        formatted_item = {
            "sys_id": item.get("sys_id", ""),
            "name": item.get("name", ""),
            "short_description": item.get("short_description", ""),
            "description": item.get("description", ""),
            "category": item.get("category", ""),
            "price": item.get("price", ""),
            "picture": item.get("picture", ""),
            "active": item.get("active", ""),
            "order": item.get("order", ""),
            "delivery_time": item.get("delivery_time", ""),
            "availability": item.get("availability", ""),
            "variables": get_catalog_item_variables(config, auth_manager, params.item_id),
        }

        return CatalogResponse(
            success=True,
            message=f"Retrieved catalog item: {item.get('name', '')}",
            data=formatted_item,
        )

    except Exception as e:
        logger.error(f"Error getting catalog item: {str(e)}")
        return CatalogResponse(
            success=False,
            message=f"Error getting catalog item: {str(e)}",
            data=None,
        )


def get_catalog_item_variables(
    config: ServerConfig,
    auth_manager: AuthManager,
    item_id: str,
) -> List[Dict[str, Any]]:
    """
    Get variables for a specific service catalog item.

    Args:
        config: Server configuration
        auth_manager: Authentication manager
        item_id: Catalog item ID or sys_id

    Returns:
        List of variables for the catalog item
    """
    logger.info(f"Getting variables for catalog item: {item_id}")

    try:
        records, _ = sn_query_page(
            config,
            auth_manager,
            table="item_option_new",
            query=f"cat_item={item_id}^ORDERBYorder",
            fields="sys_id,name,question_text,type,mandatory,default_value,help_text,order",
            limit=100,
            offset=0,
            display_value=True,
        )

        # Format the response
        formatted_variables = []
        for variable in records:
            formatted_variables.append(
                {
                    "sys_id": variable.get("sys_id", ""),
                    "name": variable.get("name", ""),
                    "label": variable.get("question_text", ""),
                    "type": variable.get("type", ""),
                    "mandatory": variable.get("mandatory", ""),
                    "default_value": variable.get("default_value", ""),
                    "help_text": variable.get("help_text", ""),
                    "order": variable.get("order", ""),
                }
            )

        return formatted_variables

    except Exception as e:
        logger.error(f"Error getting catalog item variables: {str(e)}")
        return []


@register_tool(
    name="list_catalog_categories",
    params=ListCatalogCategoriesParams,
    description="List catalog categories with parent/child relationships. Filter by active status or search query.",
    serialization="json",
    return_type=str,
)
def list_catalog_categories(
    config: ServerConfig,
    auth_manager: AuthManager,
    params: ListCatalogCategoriesParams,
) -> Dict[str, Any]:
    """
    List service catalog categories from ServiceNow.

    Args:
        config: Server configuration
        auth_manager: Authentication manager
        params: Parameters for listing catalog categories

    Returns:
        Dictionary containing catalog categories and metadata
    """
    logger.info("Listing service catalog categories")

    # Add filters
    filters = []
    if params.active:
        filters.append("active=true")
    if params.query:
        filters.append(f"titleLIKE{params.query}^ORdescriptionLIKE{params.query}")

    query_string = "^".join(filters) if filters else ""

    try:
        records, total_count = sn_query_page(
            config,
            auth_manager,
            table="sc_category",
            query=query_string,
            fields="sys_id,title,description,parent,icon,active,order",
            limit=min(params.limit, 100),
            offset=params.offset,
            display_value=True,
            fail_silently=False,
        )

        # Format the response
        formatted_categories = []
        for category in records:
            formatted_categories.append(
                {
                    "sys_id": category.get("sys_id", ""),
                    "title": category.get("title", ""),
                    "description": category.get("description", ""),
                    "parent": category.get("parent", ""),
                    "icon": category.get("icon", ""),
                    "active": category.get("active", ""),
                    "order": category.get("order", ""),
                }
            )

        return {
            "success": True,
            "message": f"Retrieved {len(formatted_categories)} catalog categories",
            "categories": formatted_categories,
            "total": len(formatted_categories),
            "limit": params.limit,
            "offset": params.offset,
        }

    except Exception as e:
        logger.error(f"Error listing catalog categories: {str(e)}")
        return {
            "success": False,
            "message": f"Error listing catalog categories: {str(e)}",
            "categories": [],
            "total": 0,
            "limit": params.limit,
            "offset": params.offset,
        }


@register_tool(
    name="create_catalog_category",
    params=CreateCatalogCategoryParams,
    description="Create a catalog category. Requires title. Optionally set parent, icon, order, and active status.",
    serialization="json_dict",
    return_type=str,
)
def create_catalog_category(
    config: ServerConfig,
    auth_manager: AuthManager,
    params: CreateCatalogCategoryParams,
) -> CatalogResponse:
    """
    Create a new service catalog category in ServiceNow.

    Args:
        config: Server configuration
        auth_manager: Authentication manager
        params: Parameters for creating a catalog category

    Returns:
        Response containing the result of the operation
    """
    logger.info("Creating new service catalog category")

    # Build the API URL
    url = f"{config.instance_url}/api/now/table/sc_category"

    # Prepare request body
    body = {
        "title": params.title,
    }

    if params.description is not None:
        body["description"] = params.description
    if params.parent is not None:
        body["parent"] = params.parent
    if params.icon is not None:
        body["icon"] = params.icon
    if params.active is not None:
        body["active"] = str(params.active).lower()
    if params.order is not None:
        body["order"] = str(params.order)

    # Make the API request
    headers = auth_manager.get_headers()
    headers["Accept"] = "application/json"
    headers["Content-Type"] = "application/json"

    try:
        response = auth_manager.make_request("POST", url, headers=headers, json=body)
        response.raise_for_status()

        # Process the response
        result = response.json()
        category = result.get("result", {})

        # Format the response
        formatted_category = {
            "sys_id": category.get("sys_id", ""),
            "title": category.get("title", ""),
            "description": category.get("description", ""),
            "parent": category.get("parent", ""),
            "icon": category.get("icon", ""),
            "active": category.get("active", ""),
            "order": category.get("order", ""),
        }

        invalidate_query_cache(table="sc_category")

        return CatalogResponse(
            success=True,
            message=f"Created catalog category: {params.title}",
            data=formatted_category,
        )

    except Exception as e:
        logger.error(f"Error creating catalog category: {str(e)}")
        return CatalogResponse(
            success=False,
            message=f"Error creating catalog category: {str(e)}",
            data=None,
        )


@register_tool(
    name="update_catalog_category",
    params=UpdateCatalogCategoryParams,
    description="Partial update of a catalog category by sys_id. Supports title, parent, icon, order, and active fields.",
    serialization="json_dict",
    return_type=str,
)
def update_catalog_category(
    config: ServerConfig,
    auth_manager: AuthManager,
    params: UpdateCatalogCategoryParams,
) -> CatalogResponse:
    """
    Update an existing service catalog category in ServiceNow.

    Args:
        config: Server configuration
        auth_manager: Authentication manager
        params: Parameters for updating a catalog category

    Returns:
        Response containing the result of the operation
    """
    logger.info(f"Updating service catalog category: {params.category_id}")

    # Build the API URL
    url = f"{config.instance_url}/api/now/table/sc_category/{params.category_id}"

    # Prepare request body with only the provided parameters
    body = {}
    if params.title is not None:
        body["title"] = params.title
    if params.description is not None:
        body["description"] = params.description
    if params.parent is not None:
        body["parent"] = params.parent
    if params.icon is not None:
        body["icon"] = params.icon
    if params.active is not None:
        body["active"] = str(params.active).lower()
    if params.order is not None:
        body["order"] = str(params.order)

    # Make the API request
    headers = auth_manager.get_headers()
    headers["Accept"] = "application/json"
    headers["Content-Type"] = "application/json"

    try:
        response = auth_manager.make_request("PATCH", url, headers=headers, json=body)
        response.raise_for_status()

        # Process the response
        result = response.json()
        category = result.get("result", {})

        # Format the response
        formatted_category = {
            "sys_id": category.get("sys_id", ""),
            "title": category.get("title", ""),
            "description": category.get("description", ""),
            "parent": category.get("parent", ""),
            "icon": category.get("icon", ""),
            "active": category.get("active", ""),
            "order": category.get("order", ""),
        }

        invalidate_query_cache(table="sc_category")

        return CatalogResponse(
            success=True,
            message=f"Updated catalog category: {params.category_id}",
            data=formatted_category,
        )

    except Exception as e:
        logger.error(f"Error updating catalog category: {str(e)}")
        return CatalogResponse(
            success=False,
            message=f"Error updating catalog category: {str(e)}",
            data=None,
        )


@register_tool(
    name="move_catalog_items",
    params=MoveCatalogItemsParams,
    description="Reassign one or more catalog items to a target category. Requires item_ids and target_category_id.",
    serialization="json_dict",
    return_type=str,
)
def move_catalog_items(
    config: ServerConfig,
    auth_manager: AuthManager,
    params: MoveCatalogItemsParams,
) -> CatalogResponse:
    """
    Move catalog items to a different category.

    Args:
        config: Server configuration
        auth_manager: Authentication manager
        params: Parameters for moving catalog items

    Returns:
        Response containing the result of the operation
    """
    logger.info(
        f"Moving {len(params.item_ids)} catalog items to category: {params.target_category_id}"
    )

    # Build the API URL
    url = f"{config.instance_url}/api/now/table/sc_cat_item"

    # Make the API request for each item
    headers = auth_manager.get_headers()
    headers["Accept"] = "application/json"
    headers["Content-Type"] = "application/json"

    success_count = 0
    failed_items = []

    try:
        for item_id in params.item_ids:
            item_url = f"{url}/{item_id}"
            body = {"category": params.target_category_id}

            try:
                response = auth_manager.make_request("PATCH", item_url, headers=headers, json=body)
                response.raise_for_status()
                success_count += 1
            except Exception as e:
                logger.error(f"Error moving catalog item {item_id}: {str(e)}")
                failed_items.append({"item_id": item_id, "error": str(e)})

        # Invalidate cache after all items processed
        invalidate_query_cache(table="sc_cat_item")

        # Prepare the response
        if success_count == len(params.item_ids):
            return CatalogResponse(
                success=True,
                message=f"Successfully moved {success_count} catalog items to category {params.target_category_id}",
                data={"moved_items_count": success_count},
            )
        elif success_count > 0:
            return CatalogResponse(
                success=True,
                message=f"Partially moved catalog items. {success_count} succeeded, {len(failed_items)} failed.",
                data={
                    "moved_items_count": success_count,
                    "failed_items": failed_items,
                },
            )
        else:
            return CatalogResponse(
                success=False,
                message="Failed to move any catalog items",
                data={"failed_items": failed_items},
            )

    except Exception as e:
        logger.error(f"Error moving catalog items: {str(e)}")
        return CatalogResponse(
            success=False,
            message=f"Error moving catalog items: {str(e)}",
            data=None,
        )
