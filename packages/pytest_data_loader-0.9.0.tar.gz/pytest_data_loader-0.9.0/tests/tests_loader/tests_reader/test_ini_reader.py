from configparser import ConfigParser, SectionProxy
from typing import IO, Any

import pytest

from pytest_data_loader import load, parametrize, parametrize_dir
from tests.paths import PATH_INI_FILE, PATH_INI_FILE_DIR

pytestmark = pytest.mark.readers

parser = ConfigParser()


def ini_file_reader(f: IO[str]) -> ConfigParser:
    parser.read_file(f)
    return parser


@load("data", PATH_INI_FILE, reader=ini_file_reader)
def test_load_ini_file_with_reader(data: ConfigParser) -> None:
    """Test @load loader with INI file reader"""
    assert isinstance(data, ConfigParser)
    assert len(data.sections()) > 1


@load(
    "data",
    PATH_INI_FILE,
    reader=ini_file_reader,
    onload=lambda parser: {s: dict(parser.items(s)) for s in parser.sections()},
)
def test_load_ini_file_with_reader_and_onload(data: dict[str, Any]) -> None:
    """Test @load loader with INI file reader and onload"""
    assert isinstance(data, dict)


@parametrize("data", PATH_INI_FILE, reader=ini_file_reader)
def test_parametrize_ini_file_with_reader(data: tuple[str, Any]) -> None:
    """Test @parametrize loader with INI file reader"""
    assert isinstance(data, tuple)
    section_name, section_data = data
    assert isinstance(section_name, str)
    assert isinstance(section_data, SectionProxy)


@parametrize_dir("data", PATH_INI_FILE_DIR, reader=lambda _: ini_file_reader)
def test_parametrize_dir_with_init_reader(data: ConfigParser) -> None:
    """Test @parametrize_dir loader with INI file reader"""
    assert isinstance(data, ConfigParser)
    assert len(data.sections()) > 1
