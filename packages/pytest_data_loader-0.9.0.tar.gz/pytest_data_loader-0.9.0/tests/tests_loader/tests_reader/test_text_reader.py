from io import BufferedReader, TextIOWrapper
from pathlib import Path

import pytest
from pytest import FixtureRequest

from pytest_data_loader import load, parametrize
from tests.paths import PATH_TEXT_FILE

from ..helper import get_parametrized_test_idx

pytestmark = pytest.mark.readers


# NOTE: These tests don't make much sense in reality since open() already handles the same things.
#       These tests just make sure that the file_reader option works as low level


@load(
    ("file_path", "data"),
    PATH_TEXT_FILE,
    reader=BufferedReader,
    read_options={"mode": "rb"},
    onload=lambda r: TextIOWrapper(r, encoding="utf-8").read(),
)
def test_load_text_file_with_reader(file_path: Path, data: str) -> None:
    """Test @load loader with text file reader"""
    assert isinstance(data, str)
    assert data == file_path.read_text()


@parametrize(
    ("file_path", "data"),
    PATH_TEXT_FILE,
    reader=BufferedReader,
    read_options={"mode": "rb"},
    onload=lambda r: TextIOWrapper(r, encoding="utf-8").read(),
)
def test_parametrize_text_file_with_reader(request: FixtureRequest, file_path: Path, data: str) -> None:
    """Test @parametrize loader with text file reader"""
    assert isinstance(data, str)
    idx = get_parametrized_test_idx(request, "data")
    assert data == file_path.read_text().splitlines()[idx]
