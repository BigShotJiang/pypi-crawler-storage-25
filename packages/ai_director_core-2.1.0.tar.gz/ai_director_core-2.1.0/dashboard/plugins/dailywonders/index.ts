import { pluginRegistry } from '../../src/hooks';
import type { BrandPlugin, AdditionalPlatform } from '../../src/hooks';

/**
 * DailyWonders brand plugin — reference implementation demonstrating:
 * - Auto-publish scheduling (onVideoScheduled)
 * - SEO optimization after upload (onVideoPublished)
 * - Additional platform support (Pinterest)
 * - Custom settings panel
 */
const dailyWondersPlugin: BrandPlugin = {
  id: 'dailywonders',
  name: 'DailyWonders',

  hooks: {
    onVideoScheduled(data) {
      console.log('[DailyWonders] Video scheduled — setting up auto-publish:', data);
      // In production: queue auto-publish job via API
    },

    async onVideoPublished(data) {
      console.log('[DailyWonders] Video published — running SEO optimization:', data);
      // In production: call SEO API, generate meta tags, submit sitemap
    },

    onChannelConfigUpdated(data) {
      console.log('[DailyWonders] Channel config updated:', data);
    },
  },

  getAdditionalPlatforms(): AdditionalPlatform[] {
    return [
      {
        id: 'pinterest',
        name: 'Pinterest',
        icon: '📌',
        fields: [
          { key: 'pinTitle', label: 'Pin Title', type: 'text' },
          { key: 'pinDescription', label: 'Pin Description', type: 'textarea' },
          { key: 'boardName', label: 'Board Name', type: 'text' },
          { key: 'pinLink', label: 'Destination URL', type: 'text' },
        ],
      },
    ];
  },

  renderSettingsPanel() {
    // Use JSX via createElement since this is a .ts file
    // Brands would typically use .tsx for richer UI
    const { createElement: h } = require('react');
    return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 12 } },
      h('div', { style: { fontFamily: "'DM Mono', monospace", fontSize: 10, color: '#ffffff44', letterSpacing: 2 } }, 'DAILYWONDERS SETTINGS'),
      h('div', { style: { fontSize: 13, color: '#e8e6e0', lineHeight: 1.6 } },
        'DailyWonders plugin is active. Features: auto-publish scheduling, SEO optimization, Pinterest pin creation.'
      ),
      h('div', { style: { display: 'flex', gap: 8, marginTop: 8 } },
        h('span', { style: { background: 'rgba(16, 185, 129, 0.13)', color: '#10b981', padding: '4px 10px', borderRadius: 20, fontFamily: "'DM Mono', monospace", fontSize: 10 } }, '✓ Auto-publish'),
        h('span', { style: { background: 'rgba(16, 185, 129, 0.13)', color: '#10b981', padding: '4px 10px', borderRadius: 20, fontFamily: "'DM Mono', monospace", fontSize: 10 } }, '✓ SEO'),
        h('span', { style: { background: 'rgba(16, 185, 129, 0.13)', color: '#10b981', padding: '4px 10px', borderRadius: 20, fontFamily: "'DM Mono', monospace", fontSize: 10 } }, '✓ Pinterest'),
      ),
    );
  },
};

export function registerDailyWonders() {
  pluginRegistry.register(dailyWondersPlugin);
}

export default dailyWondersPlugin;
