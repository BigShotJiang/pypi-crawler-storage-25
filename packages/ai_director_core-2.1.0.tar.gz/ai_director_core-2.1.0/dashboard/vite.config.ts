import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';

function readVersion(): string {
  const pyproject = fs.readFileSync(
    path.resolve(__dirname, '../pyproject.toml'),
    'utf-8',
  );
  const match = pyproject.match(/^version\s*=\s*"(\d+\.\d+\.\d+)"/m);
  return match ? match[1] : '0.0.0';
}

export default defineConfig({
  plugins: [react()],
  define: {
    __APP_VERSION__: JSON.stringify(readVersion()),
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    outDir: path.resolve(__dirname, '../ai_director/dashboard/static'),
    emptyOutDir: true,
  },
});
