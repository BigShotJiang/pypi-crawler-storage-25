import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import styles from './AppLayout.module.css';

interface AppLayoutProps {
  onLogout: () => void;
  userEmail?: string;
}

export function AppLayout({ onLogout, userEmail }: AppLayoutProps) {
  return (
    <div className={styles.layout}>
      <div className="grain-overlay" />
      <Sidebar onLogout={onLogout} userEmail={userEmail} />
      <main className={styles.content}>
        <Outlet />
      </main>
    </div>
  );
}
