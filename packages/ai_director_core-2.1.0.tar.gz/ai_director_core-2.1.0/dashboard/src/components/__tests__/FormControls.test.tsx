import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, it, expect } from 'vitest';
import { Input, Select, Textarea } from '../FormControls';

describe('Input', () => {
  it('renders with label', () => {
    render(<Input label="Email" />);
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
  });

  it('displays error message', () => {
    render(<Input label="Name" error="Required" />);
    expect(screen.getByText('Required')).toBeInTheDocument();
  });

  it('handles value changes', async () => {
    let value = '';
    render(<Input label="Test" value={value} onChange={(e) => { value = e.target.value; }} />);
    await userEvent.type(screen.getByLabelText('Test'), 'hello');
    expect(value).toBe('o'); // controlled input needs re-render
  });
});

describe('Select', () => {
  it('renders with options', () => {
    render(
      <Select
        label="Color"
        options={[
          { value: 'red', label: 'Red' },
          { value: 'blue', label: 'Blue' },
        ]}
      />,
    );
    expect(screen.getByLabelText('Color')).toBeInTheDocument();
    expect(screen.getByText('Red')).toBeInTheDocument();
    expect(screen.getByText('Blue')).toBeInTheDocument();
  });
});

describe('Textarea', () => {
  it('renders with label', () => {
    render(<Textarea label="Description" />);
    expect(screen.getByLabelText('Description')).toBeInTheDocument();
  });

  it('displays error message', () => {
    render(<Textarea label="Bio" error="Too long" />);
    expect(screen.getByText('Too long')).toBeInTheDocument();
  });
});
