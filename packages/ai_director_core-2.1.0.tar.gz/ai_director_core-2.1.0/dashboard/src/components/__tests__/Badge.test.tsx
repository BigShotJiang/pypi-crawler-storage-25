import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { Badge } from '../Badge';

describe('Badge', () => {
  it('renders with text', () => {
    render(<Badge>Active</Badge>);
    expect(screen.getByText('Active')).toBeInTheDocument();
  });

  it('applies default variant', () => {
    const { container } = render(<Badge>Default</Badge>);
    expect((container.firstChild as HTMLElement).className).toContain('default');
  });

  it('applies accent variant', () => {
    const { container } = render(<Badge variant="accent">Accent</Badge>);
    expect((container.firstChild as HTMLElement).className).toContain('accent');
  });

  it('applies success variant', () => {
    const { container } = render(<Badge variant="success">Success</Badge>);
    expect((container.firstChild as HTMLElement).className).toContain('success');
  });

  it('applies error variant', () => {
    const { container } = render(<Badge variant="error">Error</Badge>);
    expect((container.firstChild as HTMLElement).className).toContain('error');
  });
});
