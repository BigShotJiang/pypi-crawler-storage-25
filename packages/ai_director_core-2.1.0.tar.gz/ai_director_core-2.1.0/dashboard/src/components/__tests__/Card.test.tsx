import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { Card } from '../Card';

describe('Card', () => {
  it('renders children', () => {
    render(<Card>Card content</Card>);
    expect(screen.getByText('Card content')).toBeInTheDocument();
  });

  it('applies default variant', () => {
    const { container } = render(<Card>Default</Card>);
    expect((container.firstChild as HTMLElement).className).toContain('default');
  });

  it('applies accent variant', () => {
    const { container } = render(<Card variant="accent">Accent</Card>);
    expect((container.firstChild as HTMLElement).className).toContain('accent');
  });

  it('applies success variant', () => {
    const { container } = render(<Card variant="success">Success</Card>);
    expect((container.firstChild as HTMLElement).className).toContain('success');
  });

  it('adds button role when onClick is provided', async () => {
    render(<Card onClick={() => {}}>Clickable</Card>);
    expect(screen.getByRole('button')).toBeInTheDocument();
  });
});
