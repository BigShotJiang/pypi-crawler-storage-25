import { NavLink } from 'react-router-dom';
import styles from './Sidebar.module.css';

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: '◈' },
  { to: '/channels', label: 'Channels', icon: '◎' },
  { to: '/calendar', label: 'Calendar', icon: '▦' },
  { to: '/schedule', label: 'Schedule', icon: '▸' },
  { to: '/settings', label: 'Settings', icon: '⚙' },
];

interface SidebarProps {
  onLogout: () => void;
  userEmail?: string;
}

export function Sidebar({ onLogout, userEmail }: SidebarProps) {
  return (
    <aside className={styles.sidebar}>
      <div className={styles.brand}>
        <span className={styles.logo}>◈</span>
        <span className={styles.logoText}>DIRECTOR</span>
        <span className={styles.version}>v{__APP_VERSION__}</span>
      </div>

      <nav className={styles.nav}>
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.navItemActive : ''}`
            }
          >
            <span className={styles.navIcon}>{item.icon}</span>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className={styles.footer}>
        {userEmail && <div className={styles.userEmail}>{userEmail}</div>}
        <button className={styles.logoutBtn} onClick={onLogout}>
          Sign out
        </button>
      </div>
    </aside>
  );
}
