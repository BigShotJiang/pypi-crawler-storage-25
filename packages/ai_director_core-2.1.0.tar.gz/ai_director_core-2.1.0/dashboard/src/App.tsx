import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from '@/components';
import { AuthProvider, useAuth, LoginPage, ProtectedRoute } from '@/features/auth';
import { PluginRegistryProvider } from '@/hooks';
import { DashboardHome } from '@/features/dashboard';
import { ChannelListPage, ChannelDetailPage, ChannelForm } from '@/features/channels';
import { CalendarPage } from '@/features/calendar';
import { SchedulePage } from '@/features/schedule';
import { SettingsPage } from '@/features/settings';

function AuthenticatedApp() {
  const { user, logout } = useAuth();

  return (
    <Routes>
      <Route
        element={
          <ProtectedRoute>
            <AppLayout onLogout={logout} userEmail={user?.email ?? undefined} />
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardHome />} />
        <Route path="channels" element={<ChannelListPage />} />
        <Route path="channels/new" element={<ChannelForm />} />
        <Route path="channels/:id" element={<ChannelDetailPage />} />
        <Route path="channels/:id/edit" element={<ChannelForm />} />
        <Route path="calendar" element={<CalendarPage />} />
        <Route path="schedule" element={<SchedulePage />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>
      <Route path="login" element={<LoginPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <PluginRegistryProvider>
          <AuthenticatedApp />
        </PluginRegistryProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
