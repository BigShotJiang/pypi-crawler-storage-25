import { describe, it, expect } from 'vitest';
import { PluginRegistry } from '../plugin-registry';
import type { BrandPlugin } from '../types';

function createMockPlugin(overrides: Partial<BrandPlugin> = {}): BrandPlugin {
  return {
    id: 'test-plugin',
    name: 'Test Plugin',
    ...overrides,
  };
}

describe('PluginRegistry', () => {
  it('registers a plugin', () => {
    const registry = new PluginRegistry();
    const plugin = createMockPlugin();
    registry.register(plugin);
    expect(registry.getAll()).toHaveLength(1);
    expect(registry.get('test-plugin')).toBe(plugin);
  });

  it('throws when registering duplicate plugin id', () => {
    const registry = new PluginRegistry();
    registry.register(createMockPlugin());
    expect(() => registry.register(createMockPlugin())).toThrow(
      'Plugin "test-plugin" is already registered',
    );
  });

  it('unregisters a plugin', () => {
    const registry = new PluginRegistry();
    registry.register(createMockPlugin());
    registry.unregister('test-plugin');
    expect(registry.getAll()).toHaveLength(0);
  });

  it('dispatches hooks to all plugins', () => {
    const registry = new PluginRegistry();
    let called = false;
    registry.register(
      createMockPlugin({
        hooks: {
          onVideoScheduled: () => {
            called = true;
          },
        },
      }),
    );
    registry.dispatch('onVideoScheduled', { videoId: '123' });
    expect(called).toBe(true);
  });

  it('catches and logs hook errors without throwing', () => {
    const registry = new PluginRegistry();
    registry.register(
      createMockPlugin({
        hooks: {
          onVideoScheduled: () => {
            throw new Error('boom');
          },
        },
      }),
    );
    // Should not throw
    expect(() =>
      registry.dispatch('onVideoScheduled', {}),
    ).not.toThrow();
  });

  it('collects additional platforms from plugins', () => {
    const registry = new PluginRegistry();
    registry.register(
      createMockPlugin({
        getAdditionalPlatforms: () => [
          { id: 'pinterest', name: 'Pinterest' },
        ],
      }),
    );
    const platforms = registry.getAdditionalPlatforms();
    expect(platforms).toHaveLength(1);
    expect(platforms[0]!.id).toBe('pinterest');
  });

  it('collects settings panels from plugins', () => {
    const registry = new PluginRegistry();
    registry.register(
      createMockPlugin({
        renderSettingsPanel: () => 'settings-node' as any,
      }),
    );
    const panels = registry.renderAllSettingsPanels();
    expect(panels).toHaveLength(1);
    expect(panels[0]!.pluginId).toBe('test-plugin');
    expect(panels[0]!.node).toBe('settings-node');
  });
});
