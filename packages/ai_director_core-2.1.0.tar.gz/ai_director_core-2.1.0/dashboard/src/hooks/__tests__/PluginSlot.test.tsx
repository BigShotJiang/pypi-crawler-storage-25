import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { PluginSlot } from '../PluginSlot';

function ThrowingComponent(): React.ReactElement {
  throw new Error('Plugin crash!');
}

function NormalComponent() {
  return <div>Plugin works</div>;
}

describe('PluginSlot', () => {
  it('renders children normally', () => {
    render(
      <PluginSlot pluginId="test">
        <NormalComponent />
      </PluginSlot>,
    );
    expect(screen.getByText('Plugin works')).toBeInTheDocument();
  });

  it('shows error fallback when child throws', () => {
    // Suppress console.error from error boundary
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});
    render(
      <PluginSlot pluginId="broken-plugin">
        <ThrowingComponent />
      </PluginSlot>,
    );
    expect(screen.getByText(/broken-plugin.*encountered an error/)).toBeInTheDocument();
    spy.mockRestore();
  });
});
