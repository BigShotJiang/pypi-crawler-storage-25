import { Component, type ReactNode, type ErrorInfo } from 'react';

interface PluginSlotProps {
  pluginId: string;
  children: ReactNode;
}

interface PluginSlotState {
  hasError: boolean;
  error?: Error;
}

/**
 * Error boundary for plugin UI extension points.
 * If a plugin's rendered component throws, this catches it
 * and shows a fallback instead of crashing the entire page.
 */
export class PluginSlot extends Component<PluginSlotProps, PluginSlotState> {
  constructor(props: PluginSlotProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): PluginSlotState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(`[plugin:${this.props.pluginId}] render error:`, error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          background: 'rgba(239, 68, 68, 0.08)',
          border: '1px solid rgba(239, 68, 68, 0.2)',
          borderRadius: 8,
          padding: 12,
          fontFamily: "'DM Mono', monospace",
          fontSize: 11,
          color: '#ef4444',
        }}>
          Plugin "{this.props.pluginId}" encountered an error.
        </div>
      );
    }
    return this.props.children;
  }
}
