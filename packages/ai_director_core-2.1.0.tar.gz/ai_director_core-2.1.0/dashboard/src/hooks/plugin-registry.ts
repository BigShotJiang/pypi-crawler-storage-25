import { createContext, useContext, useMemo, createElement, type ReactNode } from 'react';
import type { BrandPlugin, HookName, AdditionalPlatform } from './types';

class PluginRegistry {
  private plugins: Map<string, BrandPlugin> = new Map();

  register(plugin: BrandPlugin): void {
    if (this.plugins.has(plugin.id)) {
      throw new Error(`Plugin "${plugin.id}" is already registered.`);
    }
    this.plugins.set(plugin.id, plugin);
  }

  unregister(pluginId: string): void {
    this.plugins.delete(pluginId);
  }

  getAll(): BrandPlugin[] {
    return Array.from(this.plugins.values());
  }

  get(id: string): BrandPlugin | undefined {
    return this.plugins.get(id);
  }

  /**
   * Dispatch a lifecycle hook to all registered plugins.
   * Errors in individual plugins are caught and logged — never crash the app.
   */
  dispatch(hook: HookName, data: Record<string, unknown>): void {
    for (const plugin of this.plugins.values()) {
      const handler = plugin.hooks?.[hook];
      if (handler) {
        try {
          const result = handler(data);
          // Handle async hooks — catch promise rejections
          if (result instanceof Promise) {
            result.catch((err) => {
              console.error(`[plugin:${plugin.id}] async hook "${hook}" error:`, err);
            });
          }
        } catch (err) {
          console.error(`[plugin:${plugin.id}] hook "${hook}" error:`, err);
        }
      }
    }
  }

  /**
   * Collect additional platforms from all plugins.
   */
  getAdditionalPlatforms(): AdditionalPlatform[] {
    const platforms: AdditionalPlatform[] = [];
    for (const plugin of this.plugins.values()) {
      if (plugin.getAdditionalPlatforms) {
        try {
          platforms.push(...plugin.getAdditionalPlatforms());
        } catch (err) {
          console.error(`[plugin:${plugin.id}] getAdditionalPlatforms error:`, err);
        }
      }
    }
    return platforms;
  }

  /**
   * Collect schedule extras renders from all plugins.
   */
  renderAllScheduleExtras(schedule: Record<string, unknown>): ReactNode[] {
    const nodes: ReactNode[] = [];
    for (const plugin of this.plugins.values()) {
      if (plugin.renderScheduleExtras) {
        try {
          nodes.push(plugin.renderScheduleExtras(schedule));
        } catch (err) {
          console.error(`[plugin:${plugin.id}] renderScheduleExtras error:`, err);
        }
      }
    }
    return nodes;
  }

  /**
   * Collect settings panel renders from all plugins.
   */
  renderAllSettingsPanels(): { pluginId: string; pluginName: string; node: ReactNode }[] {
    const panels: { pluginId: string; pluginName: string; node: ReactNode }[] = [];
    for (const plugin of this.plugins.values()) {
      if (plugin.renderSettingsPanel) {
        try {
          panels.push({
            pluginId: plugin.id,
            pluginName: plugin.name,
            node: plugin.renderSettingsPanel(),
          });
        } catch (err) {
          console.error(`[plugin:${plugin.id}] renderSettingsPanel error:`, err);
        }
      }
    }
    return panels;
  }
}

// Singleton registry
const globalRegistry = new PluginRegistry();

const PluginRegistryContext = createContext<PluginRegistry>(globalRegistry);

export function usePluginRegistry(): PluginRegistry {
  return useContext(PluginRegistryContext);
}

export function PluginRegistryProvider({ children }: { children: ReactNode }) {
  const registry = useMemo(() => globalRegistry, []);
  return createElement(PluginRegistryContext.Provider, { value: registry }, children);
}

export { globalRegistry as pluginRegistry };
export { PluginRegistry };
