import type { ReactNode } from 'react';

export interface AdditionalPlatform {
  id: string;
  name: string;
  icon?: string;
  fields?: { key: string; label: string; type: 'text' | 'textarea' | 'select'; options?: string[] }[];
}

export interface BrandPlugin {
  id: string;
  name: string;
  hooks?: {
    onVideoScheduled?: (data: Record<string, unknown>) => void | Promise<void>;
    onVideoPublished?: (data: Record<string, unknown>) => void | Promise<void>;
    onChannelConfigUpdated?: (data: Record<string, unknown>) => void | Promise<void>;
  };
  renderScheduleExtras?: (schedule: Record<string, unknown>) => ReactNode;
  renderSettingsPanel?: () => ReactNode;
  getAdditionalPlatforms?: () => AdditionalPlatform[];
}

export type HookName = 'onVideoScheduled' | 'onVideoPublished' | 'onChannelConfigUpdated';
