import { usePluginRegistry } from '@/hooks';
import { PluginSlot } from '@/hooks/PluginSlot';
import { Card } from '@/components';
import styles from './SettingsPage.module.css';

export function SettingsPage() {
  const registry = usePluginRegistry();
  const pluginPanels = registry.renderAllSettingsPanels();

  return (
    <div className="page-enter">
      <h1 className={styles.title}>Settings</h1>

      <Card>
        <h3 className={styles.sectionLabel}>GENERAL</h3>
        <p className={styles.info}>
          Dashboard settings and plugin management. Configure your Firebase project
          credentials in the <code>.env.local</code> file.
        </p>
      </Card>

      {pluginPanels.length > 0 && (
        <div className={styles.plugins}>
          <h2 className={styles.pluginHeader}>Plugin Settings</h2>
          {pluginPanels.map(({ pluginId, pluginName, node }) => (
            <Card key={pluginId}>
              <h3 className={styles.sectionLabel}>{pluginName.toUpperCase()}</h3>
              <PluginSlot pluginId={pluginId}>{node}</PluginSlot>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <h3 className={styles.sectionLabel}>REGISTERED PLUGINS</h3>
        {registry.getAll().length === 0 ? (
          <p className={styles.info}>No plugins registered.</p>
        ) : (
          <div className={styles.pluginList}>
            {registry.getAll().map((p) => (
              <div key={p.id} className={styles.pluginItem}>
                <span className={styles.pluginName}>{p.name}</span>
                <span className={styles.pluginId}>{p.id}</span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
