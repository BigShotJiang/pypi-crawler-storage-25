import { useState } from 'react';
import { addDoc, updateDoc, doc, collection, db } from '@/lib/firestore';
import { Button, Card, Input } from '@/components';
import { PLATFORM_FIELDS, type ScheduleEntry, type PlatformSchedule } from './types';
import { usePluginRegistry } from '@/hooks/plugin-registry';
import styles from './ScheduleForm.module.css';

interface ScheduleFormProps {
  entry: (ScheduleEntry & { id: string }) | null;
  onSaved: () => void;
  onCancel: () => void;
}

export function ScheduleForm({ entry, onSaved, onCancel }: ScheduleFormProps) {
  const isEdit = !!entry;
  const registry = usePluginRegistry();

  // Merge built-in + plugin platforms
  const additionalPlatforms = registry.getAdditionalPlatforms();
  const allPlatformFields = { ...PLATFORM_FIELDS };
  for (const p of additionalPlatforms) {
    if (!allPlatformFields[p.id]) {
      allPlatformFields[p.id] = { label: p.name, fields: p.fields ?? [] };
    }
  }

  const [form, setForm] = useState({
    videoId: entry?.videoId ?? '',
    videoTitle: entry?.videoTitle ?? '',
    channelId: entry?.channelId ?? '',
    channelName: entry?.channelName ?? '',
    publishDate: entry?.publishDate ?? '',
    publishTime: entry?.publishTime ?? '',
    platforms: entry?.platforms ?? [] as PlatformSchedule[],
  });
  const [saving, setSaving] = useState(false);

  function togglePlatform(platformId: string) {
    setForm((prev) => {
      const exists = prev.platforms.find((p) => p.platform === platformId);
      if (exists) {
        return { ...prev, platforms: prev.platforms.filter((p) => p.platform !== platformId) };
      }
      return { ...prev, platforms: [...prev.platforms, { platform: platformId, settings: {} }] };
    });
  }

  function updatePlatformSetting(platformId: string, key: string, value: string) {
    setForm((prev) => ({
      ...prev,
      platforms: prev.platforms.map((p) =>
        p.platform === platformId ? { ...p, settings: { ...p.settings, [key]: value } } : p,
      ),
    }));
  }

  async function handleSave() {
    setSaving(true);
    const data = { ...form, createdAt: new Date().toISOString() };

    if (isEdit && entry) {
      await updateDoc(doc(db, 'schedules', entry.id), data);
    } else {
      await addDoc(collection(db, 'schedules'), data);
    }

    // Dispatch plugin hook
    for (const p of form.platforms) {
      registry.dispatch('onVideoScheduled', { ...data, platform: p.platform });
    }

    setSaving(false);
    onSaved();
  }

  return (
    <Card variant="accent">
      <h3 className={styles.formTitle}>{isEdit ? 'Edit Schedule' : 'Schedule Video'}</h3>
      <div className={styles.grid}>
        <Input label="Video Title" value={form.videoTitle} onChange={(e) => setForm((f) => ({ ...f, videoTitle: e.target.value }))} />
        <Input label="Channel Name" value={form.channelName} onChange={(e) => setForm((f) => ({ ...f, channelName: e.target.value }))} />
        <Input label="Publish Date" type="date" value={form.publishDate} onChange={(e) => setForm((f) => ({ ...f, publishDate: e.target.value }))} />
        <Input label="Publish Time" type="time" value={form.publishTime} onChange={(e) => setForm((f) => ({ ...f, publishTime: e.target.value }))} />
      </div>

      <div className={styles.platformSection}>
        <div className={styles.platformLabel}>PLATFORMS</div>
        <div className={styles.platformToggles}>
          {Object.entries(allPlatformFields).map(([id, cfg]) => (
            <label key={id} className={styles.platformToggle}>
              <input type="checkbox" checked={form.platforms.some((p) => p.platform === id)} onChange={() => togglePlatform(id)} />
              <span>{cfg.label}</span>
            </label>
          ))}
        </div>

        {form.platforms.map((ps) => {
          const cfg = allPlatformFields[ps.platform];
          if (!cfg) return null;
          return (
            <div key={ps.platform} className={styles.platformSettings}>
              <div className={styles.platformSettingsLabel}>{cfg.label} Settings</div>
              {cfg.fields.map((field) => (
                <div key={field.key} className={styles.settingField}>
                  {field.type === 'select' ? (
                    <div className={styles.settingGroup}>
                      <label className={styles.settingLabel}>{field.label}</label>
                      <select
                        value={ps.settings[field.key] ?? ''}
                        onChange={(e) => updatePlatformSetting(ps.platform, field.key, e.target.value)}
                        className={styles.settingSelect}
                      >
                        <option value="">Select...</option>
                        {field.options?.map((o) => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                  ) : field.type === 'textarea' ? (
                    <div className={styles.settingGroup}>
                      <label className={styles.settingLabel}>{field.label}</label>
                      <textarea
                        value={ps.settings[field.key] ?? ''}
                        onChange={(e) => updatePlatformSetting(ps.platform, field.key, e.target.value)}
                        className={styles.settingTextarea}
                        rows={2}
                      />
                    </div>
                  ) : (
                    <Input
                      label={field.label}
                      value={ps.settings[field.key] ?? ''}
                      onChange={(e) => updatePlatformSetting(ps.platform, field.key, e.target.value)}
                    />
                  )}
                </div>
              ))}
            </div>
          );
        })}
      </div>

      <div className={styles.actions}>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? 'Saving...' : isEdit ? 'Update Schedule' : 'Create Schedule'}
        </Button>
        <Button variant="secondary" onClick={onCancel}>Cancel</Button>
      </div>
    </Card>
  );
}
