import { useEffect, useState } from 'react';
import { collection, getDocs, deleteDoc, doc, db } from '@/lib/firestore';
import { Button, Card, Badge } from '@/components';
import { ScheduleForm } from './ScheduleForm';
import type { ScheduleEntry } from './types';
import styles from './SchedulePage.module.css';

export function SchedulePage() {
  const [schedules, setSchedules] = useState<(ScheduleEntry & { id: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editEntry, setEditEntry] = useState<(ScheduleEntry & { id: string }) | null>(null);

  useEffect(() => {
    loadSchedules();
  }, []);

  async function loadSchedules() {
    try {
      const snap = await getDocs(collection(db, 'schedules'));
      const data = snap.docs
        .map((d) => ({ id: d.id, ...d.data() }) as ScheduleEntry & { id: string })
        .sort((a, b) => a.publishDate.localeCompare(b.publishDate));
      setSchedules(data);
    } catch {
      setSchedules([]);
    }
    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Delete this schedule entry?')) return;
    await deleteDoc(doc(db, 'schedules', id));
    setSchedules((prev) => prev.filter((s) => s.id !== id));
  }

  function handleSaved() {
    setShowForm(false);
    setEditEntry(null);
    loadSchedules();
  }

  if (loading) return <div className={styles.loading}>Loading schedules...</div>;

  return (
    <div className="page-enter">
      <div className={styles.header}>
        <h1 className={styles.title}>Publishing Schedule</h1>
        <Button variant="ghost" onClick={() => { setEditEntry(null); setShowForm(true); }}>
          + Schedule Video
        </Button>
      </div>

      {showForm && (
        <div className={styles.formWrapper}>
          <ScheduleForm entry={editEntry} onSaved={handleSaved} onCancel={() => { setShowForm(false); setEditEntry(null); }} />
        </div>
      )}

      {schedules.length === 0 ? (
        <div className={styles.empty}>No videos scheduled yet.</div>
      ) : (
        <div className={styles.list}>
          {schedules.map((entry) => (
            <Card key={entry.id}>
              <div className={styles.entryHeader}>
                <div>
                  <h3 className={styles.entryTitle}>{entry.videoTitle}</h3>
                  <div className={styles.entryMeta}>
                    <span className={styles.entryDate}>
                      {new Date(entry.publishDate).toLocaleDateString()} at {entry.publishTime}
                    </span>
                    <span className={styles.entryChannel}>{entry.channelName}</span>
                  </div>
                </div>
                <div className={styles.entryActions}>
                  <Button variant="ghost" onClick={() => { setEditEntry(entry); setShowForm(true); }}>Edit</Button>
                  <Button variant="ghost" onClick={() => handleDelete(entry.id)}>Delete</Button>
                </div>
              </div>
              <div className={styles.platforms}>
                {entry.platforms.map((p) => (
                  <Badge key={p.platform} variant="accent">{p.platform}</Badge>
                ))}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
