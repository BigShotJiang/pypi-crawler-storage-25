export interface ScheduleEntry {
  id?: string;
  videoId: string;
  videoTitle: string;
  channelId: string;
  channelName: string;
  publishDate: string; // ISO date string
  publishTime: string; // HH:mm format
  platforms: PlatformSchedule[];
  createdAt?: string;
}

export interface PlatformSchedule {
  platform: 'youtube' | 'tiktok' | 'instagram' | string;
  settings: Record<string, string>;
}

export interface WeeklyTemplate {
  id?: string;
  channelId: string;
  slots: TemplateSlot[];
}

export interface TemplateSlot {
  dayOfWeek: number; // 0=Sunday, 1=Monday, etc.
  time: string; // HH:mm
  platform: string;
}

export const PLATFORM_FIELDS: Record<string, { label: string; fields: { key: string; label: string; type: 'text' | 'textarea' | 'select'; options?: string[] }[] }> = {
  youtube: {
    label: 'YouTube',
    fields: [
      { key: 'title', label: 'Title', type: 'text' },
      { key: 'description', label: 'Description', type: 'textarea' },
      { key: 'tags', label: 'Tags (comma-separated)', type: 'text' },
      { key: 'category', label: 'Category', type: 'text' },
      { key: 'visibility', label: 'Visibility', type: 'select', options: ['public', 'unlisted', 'private'] },
      { key: 'thumbnail', label: 'Thumbnail URL', type: 'text' },
    ],
  },
  tiktok: {
    label: 'TikTok',
    fields: [
      { key: 'caption', label: 'Caption', type: 'textarea' },
      { key: 'hashtags', label: 'Hashtags', type: 'text' },
      { key: 'coverImage', label: 'Cover Image URL', type: 'text' },
    ],
  },
  instagram: {
    label: 'Instagram',
    fields: [
      { key: 'caption', label: 'Caption', type: 'textarea' },
      { key: 'hashtags', label: 'Hashtags', type: 'text' },
      { key: 'coverImage', label: 'Cover Image URL', type: 'text' },
      { key: 'postType', label: 'Post Type', type: 'select', options: ['reels', 'feed'] },
    ],
  },
};
