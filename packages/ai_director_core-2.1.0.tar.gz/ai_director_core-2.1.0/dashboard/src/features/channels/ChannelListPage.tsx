import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, getDocs, deleteDoc, doc, db } from '@/lib/firestore';
import { Button, Card, Badge } from '@/components';
import type { ChannelConfig } from './types';
import styles from './ChannelListPage.module.css';

export function ChannelListPage() {
  const [channels, setChannels] = useState<(ChannelConfig & { id: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadChannels();
  }, []);

  async function loadChannels() {
    try {
      const snap = await getDocs(collection(db, 'channels'));
      const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }) as ChannelConfig & { id: string });
      setChannels(data);
    } catch {
      // Firestore may not be configured yet
      setChannels([]);
    }
    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Delete this channel? This action cannot be undone.')) return;
    await deleteDoc(doc(db, 'channels', id));
    setChannels((prev) => prev.filter((c) => c.id !== id));
  }

  if (loading) {
    return <div className={styles.loading}>Loading channels...</div>;
  }

  return (
    <div className="page-enter">
      <div className={styles.header}>
        <h1 className={styles.title}>Channels</h1>
        <Button variant="ghost" onClick={() => navigate('/channels/new')}>
          + New Channel
        </Button>
      </div>

      {channels.length === 0 ? (
        <div className={styles.empty}>
          <div className={styles.emptyIcon}>◎</div>
          <p>No channels configured yet.</p>
          <Button onClick={() => navigate('/channels/new')}>Create first channel →</Button>
        </div>
      ) : (
        <div className={styles.grid}>
          {channels.map((ch) => (
            <Card key={ch.id} onClick={() => navigate(`/channels/${ch.id}`)}>
              <div className={styles.cardHeader}>
                <h3 className={styles.cardName}>{ch.name}</h3>
                <Badge variant={ch.active ? 'success' : 'default'}>
                  {ch.active ? 'Active' : 'Paused'}
                </Badge>
              </div>
              <div className={styles.cardNiche}>{ch.niche}</div>
              <div className={styles.cardMeta}>
                <span>{ch.focusMarket}</span>
                <span>·</span>
                <span>{ch.contentLanguage}</span>
              </div>
              <div className={styles.cardActions}>
                <Button variant="ghost" onClick={(e) => { e.stopPropagation(); navigate(`/channels/${ch.id}/edit`); }}>
                  Edit
                </Button>
                <Button variant="ghost" onClick={(e) => { e.stopPropagation(); handleDelete(ch.id); }}>
                  Delete
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
