import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, addDoc, updateDoc, collection, db } from '@/lib/firestore';
import { Button, Card, Input, Textarea, Select } from '@/components';
import { EMPTY_CHANNEL, type ChannelConfig } from './types';
import styles from './ChannelForm.module.css';

export function ChannelForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isNew = !id || id === 'new';
  const [form, setForm] = useState<ChannelConfig>({ ...EMPTY_CHANNEL });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isNew && id) {
      (async () => {
        const snap = await getDoc(doc(db, 'channels', id));
        if (snap.exists()) {
          setForm(snap.data() as ChannelConfig);
        }
      })();
    }
  }, [id, isNew]);

  function update(path: string, value: unknown) {
    setForm((prev) => {
      const copy = structuredClone(prev);
      const keys = path.split('.');
      let target: Record<string, unknown> = copy as unknown as Record<string, unknown>;
      for (let i = 0; i < keys.length - 1; i++) {
        target = target[keys[i]!] as Record<string, unknown>;
      }
      target[keys[keys.length - 1]!] = value;
      return copy;
    });
  }

  function validate(): boolean {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs['name'] = 'Required';
    if (!form.niche.trim()) errs['niche'] = 'Required';
    if (!form.description.trim()) errs['description'] = 'Required';
    if (!form.focusMarket.trim()) errs['focusMarket'] = 'Required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSave() {
    if (!validate()) return;
    setSaving(true);
    const now = new Date().toISOString();

    if (isNew) {
      const data = { ...form, createdAt: now, updatedAt: now };
      const ref = await addDoc(collection(db, 'channels'), data);
      navigate(`/channels/${ref.id}`);
    } else {
      await updateDoc(doc(db, 'channels', id!), { ...form, updatedAt: now });
      navigate(`/channels/${id}`);
    }
    setSaving(false);
  }

  return (
    <div className="page-enter">
      <div className={styles.header}>
        <Button variant="ghost" onClick={() => navigate(isNew ? '/channels' : `/channels/${id}`)}>
          ← Cancel
        </Button>
        <h1 className={styles.title}>{isNew ? 'New Channel' : 'Edit Channel'}</h1>
      </div>

      <div className={styles.sections}>
        {/* Basic Info */}
        <Card>
          <h3 className={styles.sectionLabel}>BASIC INFO</h3>
          <div className={styles.grid}>
            <Input label="Channel Name" value={form.name} onChange={(e) => update('name', e.target.value)} error={errors['name']} />
            <Input label="Niche" value={form.niche} onChange={(e) => update('niche', e.target.value)} error={errors['niche']} />
            <div className={styles.fullWidth}>
              <Textarea label="Description" value={form.description} onChange={(e) => update('description', e.target.value)} error={errors['description']} />
            </div>
            <Input label="Focus Market" value={form.focusMarket} onChange={(e) => update('focusMarket', e.target.value)} error={errors['focusMarket']} placeholder="e.g., US, Vietnam, Global" />
            <Select
              label="Content Language"
              value={form.contentLanguage}
              onChange={(e) => update('contentLanguage', e.target.value)}
              options={[
                { value: 'en', label: 'English' },
                { value: 'vi', label: 'Vietnamese' },
                { value: 'es', label: 'Spanish' },
                { value: 'pt', label: 'Portuguese' },
                { value: 'zh', label: 'Chinese' },
                { value: 'ja', label: 'Japanese' },
              ]}
            />
          </div>
        </Card>

        {/* Target Audience */}
        <Card>
          <h3 className={styles.sectionLabel}>TARGET AUDIENCE</h3>
          <div className={styles.grid}>
            <Input label="Age Range" value={form.targetAudience.ageRange} onChange={(e) => update('targetAudience.ageRange', e.target.value)} placeholder="e.g., 18-35" />
            <Input label="Interests (comma-separated)" value={form.targetAudience.interests.join(', ')} onChange={(e) => update('targetAudience.interests', e.target.value.split(',').map((s) => s.trim()).filter(Boolean))} />
            <div className={styles.fullWidth}>
              <Textarea label="Demographics" value={form.targetAudience.demographics} onChange={(e) => update('targetAudience.demographics', e.target.value)} placeholder="Describe your target audience..." />
            </div>
          </div>
        </Card>

        {/* Brand Identity */}
        <Card>
          <h3 className={styles.sectionLabel}>BRAND IDENTITY</h3>
          <div className={styles.grid}>
            <Input label="Logo URL" value={form.brandIdentity.logo} onChange={(e) => update('brandIdentity.logo', e.target.value)} />
            <Input label="Color Palette (comma-separated)" value={form.brandIdentity.colorPalette.join(', ')} onChange={(e) => update('brandIdentity.colorPalette', e.target.value.split(',').map((s) => s.trim()).filter(Boolean))} placeholder="#f59e0b, #0a0a0f" />
            <div className={styles.fullWidth}>
              <Textarea label="Tone of Voice" value={form.brandIdentity.toneOfVoice} onChange={(e) => update('brandIdentity.toneOfVoice', e.target.value)} placeholder="Describe the brand voice..." />
            </div>
          </div>
        </Card>

        {/* Content Strategy */}
        <Card>
          <h3 className={styles.sectionLabel}>CONTENT STRATEGY</h3>
          <div className={styles.grid}>
            <Input label="Posting Frequency" value={form.contentStrategy.postingFrequency} onChange={(e) => update('contentStrategy.postingFrequency', e.target.value)} placeholder="e.g., Daily, 3x/week" />
            <Input label="Content Pillars (comma-separated)" value={form.contentStrategy.contentPillars.join(', ')} onChange={(e) => update('contentStrategy.contentPillars', e.target.value.split(',').map((s) => s.trim()).filter(Boolean))} />
          </div>
        </Card>

        {/* Platforms */}
        <Card>
          <h3 className={styles.sectionLabel}>PLATFORMS</h3>
          {(['youtube', 'tiktok', 'instagram'] as const).map((platform) => (
            <div key={platform} className={styles.platformRow}>
              <label className={styles.platformToggle}>
                <input
                  type="checkbox"
                  checked={form.platforms[platform].enabled}
                  onChange={(e) => update(`platforms.${platform}.enabled`, e.target.checked)}
                />
                <span className={styles.platformName}>{platform.charAt(0).toUpperCase() + platform.slice(1)}</span>
              </label>
              {form.platforms[platform].enabled && (
                <div className={styles.platformFields}>
                  <Input label="Handle" value={form.platforms[platform].handle} onChange={(e) => update(`platforms.${platform}.handle`, e.target.value)} placeholder="@username" />
                  <Input label="Notes" value={form.platforms[platform].notes} onChange={(e) => update(`platforms.${platform}.notes`, e.target.value)} />
                </div>
              )}
            </div>
          ))}
        </Card>
      </div>

      <div className={styles.actions}>
        <Button onClick={handleSave} disabled={saving} fullWidth>
          {saving ? 'Saving...' : isNew ? 'Create Channel →' : 'Save Changes →'}
        </Button>
      </div>
    </div>
  );
}
