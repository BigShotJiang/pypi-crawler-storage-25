import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, db } from '@/lib/firestore';
import { Button, Badge, Card } from '@/components';
import type { ChannelConfig } from './types';
import styles from './ChannelDetailPage.module.css';

export function ChannelDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [channel, setChannel] = useState<(ChannelConfig & { id: string }) | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const snap = await getDoc(doc(db, 'channels', id));
      if (snap.exists()) {
        setChannel({ id: snap.id, ...snap.data() } as ChannelConfig & { id: string });
      }
      setLoading(false);
    })();
  }, [id]);

  if (loading) {
    return <div className={styles.loading}>Loading...</div>;
  }

  if (!channel) {
    return (
      <div className={styles.notFound}>
        <p>Channel not found.</p>
        <Button variant="ghost" onClick={() => navigate('/channels')}>← Back to channels</Button>
      </div>
    );
  }

  return (
    <div className="page-enter">
      <div className={styles.header}>
        <Button variant="ghost" onClick={() => navigate('/channels')}>← Channels</Button>
        <Button variant="ghost" onClick={() => navigate(`/channels/${id}/edit`)}>Edit</Button>
      </div>

      <h1 className={styles.title}>{channel.name}</h1>
      <div className={styles.meta}>
        <Badge variant={channel.active ? 'success' : 'default'}>
          {channel.active ? 'Active' : 'Paused'}
        </Badge>
        <Badge variant="accent">{channel.niche}</Badge>
      </div>

      <div className={styles.sections}>
        {/* Basic Info */}
        <Card>
          <h3 className={styles.sectionLabel}>BASIC INFO</h3>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Description</span>
            <span className={styles.fieldValue}>{channel.description || '—'}</span>
          </div>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Focus Market</span>
            <span className={styles.fieldValue}>{channel.focusMarket || '—'}</span>
          </div>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Language</span>
            <span className={styles.fieldValue}>{channel.contentLanguage || '—'}</span>
          </div>
        </Card>

        {/* Target Audience */}
        <Card>
          <h3 className={styles.sectionLabel}>TARGET AUDIENCE</h3>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Age Range</span>
            <span className={styles.fieldValue}>{channel.targetAudience?.ageRange || '—'}</span>
          </div>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Interests</span>
            <span className={styles.fieldValue}>{channel.targetAudience?.interests?.join(', ') || '—'}</span>
          </div>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Demographics</span>
            <span className={styles.fieldValue}>{channel.targetAudience?.demographics || '—'}</span>
          </div>
        </Card>

        {/* Brand Identity */}
        <Card>
          <h3 className={styles.sectionLabel}>BRAND IDENTITY</h3>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Tone of Voice</span>
            <span className={styles.fieldValue}>{channel.brandIdentity?.toneOfVoice || '—'}</span>
          </div>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Color Palette</span>
            <span className={styles.fieldValue}>{channel.brandIdentity?.colorPalette?.join(', ') || '—'}</span>
          </div>
        </Card>

        {/* Content Strategy */}
        <Card>
          <h3 className={styles.sectionLabel}>CONTENT STRATEGY</h3>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Posting Frequency</span>
            <span className={styles.fieldValue}>{channel.contentStrategy?.postingFrequency || '—'}</span>
          </div>
          <div className={styles.field}>
            <span className={styles.fieldLabel}>Content Pillars</span>
            <span className={styles.fieldValue}>{channel.contentStrategy?.contentPillars?.join(', ') || '—'}</span>
          </div>
        </Card>

        {/* Platforms */}
        <Card>
          <h3 className={styles.sectionLabel}>PLATFORMS</h3>
          {(['youtube', 'tiktok', 'instagram'] as const).map((p) => (
            <div key={p} className={styles.platform}>
              <Badge variant={channel.platforms?.[p]?.enabled ? 'success' : 'default'}>
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </Badge>
              {channel.platforms?.[p]?.handle && (
                <span className={styles.handle}>@{channel.platforms[p].handle}</span>
              )}
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}
