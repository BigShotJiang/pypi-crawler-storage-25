export interface ChannelConfig {
  id?: string;
  name: string;
  niche: string;
  description: string;
  targetAudience: {
    ageRange: string;
    interests: string[];
    demographics: string;
  };
  focusMarket: string;
  contentLanguage: string;
  brandIdentity: {
    logo: string;
    colorPalette: string[];
    toneOfVoice: string;
  };
  contentStrategy: {
    postingFrequency: string;
    contentPillars: string[];
  };
  platforms: {
    youtube: PlatformConfig;
    tiktok: PlatformConfig;
    instagram: PlatformConfig;
  };
  active: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface PlatformConfig {
  enabled: boolean;
  handle: string;
  notes: string;
}

export const EMPTY_CHANNEL: ChannelConfig = {
  name: '',
  niche: '',
  description: '',
  targetAudience: { ageRange: '', interests: [], demographics: '' },
  focusMarket: '',
  contentLanguage: 'en',
  brandIdentity: { logo: '', colorPalette: [], toneOfVoice: '' },
  contentStrategy: { postingFrequency: '', contentPillars: [] },
  platforms: {
    youtube: { enabled: false, handle: '', notes: '' },
    tiktok: { enabled: false, handle: '', notes: '' },
    instagram: { enabled: false, handle: '', notes: '' },
  },
  active: true,
};
