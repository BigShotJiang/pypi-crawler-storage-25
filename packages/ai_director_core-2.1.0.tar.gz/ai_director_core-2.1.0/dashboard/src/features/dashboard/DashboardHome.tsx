import { useEffect, useState } from 'react';
import { collection, getDocs, db } from '@/lib/firestore';
import { Card, Badge } from '@/components';
import styles from './DashboardHome.module.css';

export function DashboardHome() {
  const [stats, setStats] = useState({ channels: 0, videos: 0, schedules: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [cSnap, vSnap, sSnap] = await Promise.all([
          getDocs(collection(db, 'channels')),
          getDocs(collection(db, 'videos')),
          getDocs(collection(db, 'schedules')),
        ]);
        setStats({
          channels: cSnap.size,
          videos: vSnap.size,
          schedules: sSnap.size,
        });
      } catch {
        // Firestore may not be configured
      }
      setLoading(false);
    })();
  }, []);

  return (
    <div className="page-enter">
      <div className={styles.greeting}>
        <span className={styles.greetingTime}>AI DIRECTOR</span>
        <h1 className={styles.greetingName}>Dashboard</h1>
      </div>

      <div className={styles.statsGrid}>
        <Card>
          <div className={styles.statLabel}>CHANNELS</div>
          <div className={styles.statValue}>{loading ? '—' : stats.channels}</div>
        </Card>
        <Card>
          <div className={styles.statLabel}>VIDEOS</div>
          <div className={styles.statValue}>{loading ? '—' : stats.videos}</div>
        </Card>
        <Card>
          <div className={styles.statLabel}>SCHEDULED</div>
          <div className={styles.statValue}>{loading ? '—' : stats.schedules}</div>
        </Card>
      </div>

      <Card>
        <div className={styles.quickStart}>
          <Badge variant="accent">Getting Started</Badge>
          <p className={styles.quickStartText}>
            Configure your Firebase credentials in <code>.env.local</code>, then create your first channel
            from the Channels page. Videos can be scheduled from the Calendar or Schedule pages.
          </p>
        </div>
      </Card>
    </div>
  );
}
