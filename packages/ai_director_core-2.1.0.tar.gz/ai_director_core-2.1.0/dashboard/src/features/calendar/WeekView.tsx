import {
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  format,
  isSameDay,
  isToday,
} from 'date-fns';
import { Badge } from '@/components';
import { VIDEO_STATUS_CONFIG, type Video } from './types';
import styles from './WeekView.module.css';

interface WeekViewProps {
  date: Date;
  videos: (Video & { id: string })[];
  onSelectVideo: (video: Video & { id: string }) => void;
}

export function WeekView({ date, videos, onSelectVideo }: WeekViewProps) {
  const start = startOfWeek(date, { weekStartsOn: 1 });
  const end = endOfWeek(date, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start, end });

  function videosForDay(day: Date) {
    return videos.filter((v) => isSameDay(new Date(v.scheduledDate), day));
  }

  return (
    <div className={styles.grid}>
      {days.map((day) => (
        <div key={day.toISOString()} className={`${styles.day} ${isToday(day) ? styles.today : ''}`}>
          <div className={styles.dayHeader}>
            <span className={styles.dayName}>{format(day, 'EEE')}</span>
            <span className={styles.dayNum}>{format(day, 'd')}</span>
          </div>
          <div className={styles.dayContent}>
            {videosForDay(day).map((v) => {
              const statusCfg = VIDEO_STATUS_CONFIG[v.status];
              return (
                <button
                  key={v.id}
                  className={styles.videoCard}
                  onClick={() => onSelectVideo(v)}
                >
                  <div className={styles.videoTitle}>{v.title}</div>
                  <div className={styles.videoMeta}>
                    <Badge variant={statusCfg.variant}>{statusCfg.label}</Badge>
                    {v.platforms.length > 0 && (
                      <span className={styles.platforms}>
                        {v.platforms.join(', ')}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
