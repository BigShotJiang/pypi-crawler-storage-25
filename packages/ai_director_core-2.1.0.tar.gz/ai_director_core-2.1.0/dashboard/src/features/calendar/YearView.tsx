import {
  startOfYear,
  endOfYear,
  eachMonthOfInterval,
  eachDayOfInterval,
  startOfMonth,
  endOfMonth,
  format,
  isSameDay,
} from 'date-fns';
import type { Video } from './types';
import styles from './YearView.module.css';

interface YearViewProps {
  date: Date;
  videos: (Video & { id: string })[];
}

export function YearView({ date, videos }: YearViewProps) {
  const yearStart = startOfYear(date);
  const yearEnd = endOfYear(date);
  const months = eachMonthOfInterval({ start: yearStart, end: yearEnd });

  function videoCountForDay(day: Date) {
    return videos.filter((v) => isSameDay(new Date(v.scheduledDate), day)).length;
  }

  return (
    <div>
      <div className={styles.yearLabel}>{format(date, 'yyyy')}</div>
      <div className={styles.grid}>
        {months.map((month) => {
          const days = eachDayOfInterval({ start: startOfMonth(month), end: endOfMonth(month) });
          return (
            <div key={month.toISOString()} className={styles.month}>
              <div className={styles.monthName}>{format(month, 'MMM')}</div>
              <div className={styles.days}>
                {days.map((day) => {
                  const count = videoCountForDay(day);
                  return (
                    <div
                      key={day.toISOString()}
                      className={`${styles.day} ${count > 0 ? styles.hasVideo : ''} ${count > 2 ? styles.hot : ''}`}
                      title={`${format(day, 'MMM d')}: ${count} video${count !== 1 ? 's' : ''}`}
                    />
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
