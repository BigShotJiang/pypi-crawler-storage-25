import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  format,
  isSameMonth,
  isSameDay,
  isToday,
} from 'date-fns';
import { Badge } from '@/components';
import { VIDEO_STATUS_CONFIG, type Video } from './types';
import styles from './MonthView.module.css';

interface MonthViewProps {
  date: Date;
  videos: (Video & { id: string })[];
  onSelectVideo: (video: Video & { id: string }) => void;
}

export function MonthView({ date, videos, onSelectVideo }: MonthViewProps) {
  const monthStart = startOfMonth(date);
  const monthEnd = endOfMonth(date);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: calStart, end: calEnd });

  function videosForDay(day: Date) {
    return videos.filter((v) => isSameDay(new Date(v.scheduledDate), day));
  }

  return (
    <div>
      <div className={styles.monthLabel}>{format(date, 'MMMM yyyy')}</div>
      <div className={styles.headerRow}>
        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
          <div key={d} className={styles.headerCell}>{d}</div>
        ))}
      </div>
      <div className={styles.grid}>
        {days.map((day) => {
          const inMonth = isSameMonth(day, date);
          const dayVideos = videosForDay(day);
          return (
            <div
              key={day.toISOString()}
              className={`${styles.cell} ${!inMonth ? styles.outside : ''} ${isToday(day) ? styles.today : ''}`}
            >
              <span className={styles.dayNum}>{format(day, 'd')}</span>
              {dayVideos.slice(0, 3).map((v) => (
                <button key={v.id} className={styles.dot} onClick={() => onSelectVideo(v)} title={v.title}>
                  <Badge variant={VIDEO_STATUS_CONFIG[v.status].variant}>
                    {v.title.length > 12 ? v.title.slice(0, 12) + '…' : v.title}
                  </Badge>
                </button>
              ))}
              {dayVideos.length > 3 && (
                <span className={styles.more}>+{dayVideos.length - 3}</span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
