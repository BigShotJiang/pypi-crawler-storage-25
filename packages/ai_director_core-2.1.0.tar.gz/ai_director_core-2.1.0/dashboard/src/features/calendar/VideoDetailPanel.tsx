import { Badge } from '@/components';
import { VIDEO_STATUS_CONFIG, type Video } from './types';
import styles from './VideoDetailPanel.module.css';

interface VideoDetailPanelProps {
  video: Video & { id: string };
  onClose: () => void;
}

export function VideoDetailPanel({ video, onClose }: VideoDetailPanelProps) {
  const statusCfg = VIDEO_STATUS_CONFIG[video.status];

  return (
    <div className={styles.backdrop} onClick={onClose}>
      <div className={styles.panel} onClick={(e) => e.stopPropagation()}>
        <div className={styles.header}>
          <h2 className={styles.title}>{video.title}</h2>
          <button className={styles.closeBtn} onClick={onClose}>✕</button>
        </div>

        <div className={styles.meta}>
          <Badge variant={statusCfg.variant}>{statusCfg.label}</Badge>
          <span className={styles.date}>{new Date(video.scheduledDate).toLocaleDateString()}</span>
        </div>

        <div className={styles.section}>
          <div className={styles.sectionLabel}>CHANNEL</div>
          <div className={styles.sectionValue}>{video.channelName}</div>
        </div>

        <div className={styles.section}>
          <div className={styles.sectionLabel}>PLATFORMS</div>
          <div className={styles.platforms}>
            {video.platforms.map((p) => (
              <Badge key={p} variant="accent">{p}</Badge>
            ))}
          </div>
        </div>

        <div className={styles.section}>
          <div className={styles.sectionLabel}>SCRIPT</div>
          <div className={styles.script}>{video.script || 'No script available.'}</div>
        </div>
      </div>
    </div>
  );
}
