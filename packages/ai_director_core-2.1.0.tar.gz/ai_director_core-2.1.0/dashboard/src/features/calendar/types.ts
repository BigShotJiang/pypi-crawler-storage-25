export type VideoStatus = 'draft' | 'scripted' | 'in-production' | 'ready' | 'published';

export interface Video {
  id?: string;
  title: string;
  channelId: string;
  channelName: string;
  script: string;
  status: VideoStatus;
  scheduledDate: string; // ISO date string
  platforms: string[];
  createdAt?: string;
  updatedAt?: string;
}

export const VIDEO_STATUS_CONFIG: Record<VideoStatus, { label: string; variant: 'default' | 'accent' | 'purple' | 'pink' | 'success' }> = {
  draft: { label: 'Draft', variant: 'default' },
  scripted: { label: 'Scripted', variant: 'accent' },
  'in-production': { label: 'In Production', variant: 'purple' },
  ready: { label: 'Ready', variant: 'pink' },
  published: { label: 'Published', variant: 'success' },
};

export type CalendarView = 'week' | 'month' | 'year';
