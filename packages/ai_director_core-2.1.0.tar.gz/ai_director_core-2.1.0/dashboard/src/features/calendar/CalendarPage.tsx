import { useState, useEffect } from 'react';
import { collection, getDocs, query, db } from '@/lib/firestore';
import { Button, Select } from '@/components';
import { WeekView } from './WeekView';
import { MonthView } from './MonthView';
import { YearView } from './YearView';
import { VideoDetailPanel } from './VideoDetailPanel';
import type { Video, CalendarView } from './types';
import type { ChannelConfig } from '../channels/types';
import styles from './CalendarPage.module.css';

export function CalendarPage() {
  const [view, setView] = useState<CalendarView>('week');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [videos, setVideos] = useState<(Video & { id: string })[]>([]);
  const [channels, setChannels] = useState<(ChannelConfig & { id: string })[]>([]);
  const [channelFilter, setChannelFilter] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<(Video & { id: string }) | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [videoSnap, channelSnap] = await Promise.all([
        getDocs(query(collection(db, 'videos'))),
        getDocs(collection(db, 'channels')),
      ]);
      setVideos(videoSnap.docs.map((d) => ({ id: d.id, ...d.data() }) as Video & { id: string }));
      setChannels(channelSnap.docs.map((d) => ({ id: d.id, ...d.data() }) as ChannelConfig & { id: string }));
    } catch {
      setVideos([]);
      setChannels([]);
    }
    setLoading(false);
  }

  const filteredVideos = channelFilter
    ? videos.filter((v) => v.channelId === channelFilter)
    : videos;

  function navigate(direction: -1 | 1) {
    const d = new Date(currentDate);
    if (view === 'week') d.setDate(d.getDate() + direction * 7);
    else if (view === 'month') d.setMonth(d.getMonth() + direction);
    else d.setFullYear(d.getFullYear() + direction);
    setCurrentDate(d);
  }

  if (loading) {
    return <div className={styles.loading}>Loading calendar...</div>;
  }

  return (
    <div className="page-enter">
      <div className={styles.header}>
        <h1 className={styles.title}>Calendar</h1>
        <div className={styles.controls}>
          <Select
            value={channelFilter}
            onChange={(e) => setChannelFilter(e.target.value)}
            options={[
              { value: '', label: 'All Channels' },
              ...channels.map((c) => ({ value: c.id, label: c.name })),
            ]}
          />
          <div className={styles.viewSwitch}>
            {(['week', 'month', 'year'] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`${styles.viewBtn} ${view === v ? styles.viewBtnActive : ''}`}
              >
                {v.charAt(0).toUpperCase() + v.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className={styles.nav}>
        <Button variant="ghost" onClick={() => navigate(-1)}>←</Button>
        <Button variant="ghost" onClick={() => setCurrentDate(new Date())}>Today</Button>
        <Button variant="ghost" onClick={() => navigate(1)}>→</Button>
      </div>

      <div className={styles.calendar}>
        {view === 'week' && (
          <WeekView date={currentDate} videos={filteredVideos} onSelectVideo={setSelectedVideo} />
        )}
        {view === 'month' && (
          <MonthView date={currentDate} videos={filteredVideos} onSelectVideo={setSelectedVideo} />
        )}
        {view === 'year' && (
          <YearView date={currentDate} videos={filteredVideos} />
        )}
      </div>

      {selectedVideo && (
        <VideoDetailPanel video={selectedVideo} onClose={() => setSelectedVideo(null)} />
      )}
    </div>
  );
}
