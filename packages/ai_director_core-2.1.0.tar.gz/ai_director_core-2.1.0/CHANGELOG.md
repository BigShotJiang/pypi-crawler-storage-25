# Changelog

## [2.1.0] — 2026-05-13

### Added
- **Dashboard Portal**: Full web dashboard (React 18 + TypeScript) served from inside the pip package via `ad dashboard`
  - Firebase Auth login with email/password
  - Channel configuration UI (niche, audience, brand identity, platforms)
  - Production calendar with week/month/year views and script preview
  - Video publishing schedule with multi-platform support (YouTube, TikTok, Instagram)
  - Brand extension hook system (plugin architecture) for custom brand features
  - DailyWonders reference plugin with Pinterest platform extension
  - Settings page with plugin management
  - Version display in sidebar (`◈ DIRECTOR v2.1.0`)
- **AI Model Configuration**: Configurable AI model backend per brand
  - Default LLM: `gemini-3.1`, default image model: `gemini-2.5-flash-image`
  - Optional `ai_models` field on `ChannelConfig` (`AIModelsConfig` Pydantic model)
  - Environment variable overrides: `AI_DIRECTOR_LLM_MODEL`, `AI_DIRECTOR_IMAGE_MODEL`
  - `resolve_models(config)` function with env > config > defaults precedence
- **CLI Commands**:
  - `ad dashboard [--port 3456] [--host 127.0.0.1]` — launch the web dashboard
  - `ad app-info --config <path>` — generate `.ai-director.json` manifest with brand metadata
  - `ad app-info --show --config <path>` — print manifest to stdout

### Changed
- Tech stack now includes Gemini 3.1 (LLM) and gemini-2.5-flash-image (image generation) as default models
- Dashboard frontend builds to `ai_director/dashboard/static/` and ships inside the Python wheel

## [2.0.0] — 2026-05-13

### Breaking Changes ⚠️
- `channel_config.json` schema expanded with `brand_identity` and `budget` sections
- See [MIGRATION.md](MIGRATION.md) for upgrade guide

### Added
- **Brand Identity Config**: `brand_identity` object in channel config for brand-specific voice, audience plan, hook strategies, content plan, USPs, and competitor differentiation
- **Budget Management**: `budget` object with monthly/per-video limits, cost allocation, alert/hard-stop thresholds
- **Budget Tracker**: Runtime cost tracking module (`BudgetTracker`) with GCS persistence and local fallback
- **Budget Enforcement**: Pre-flight budget checks before each agent step — proceed/fallback/stop decisions
- **Asset Fallback**: Automatic fallback from AI generation (Flux) to Pexels when budget is near limit
- **GCS Path Enforcement**: Validates all storage paths belong to the owning channel — prevents cross-contamination
- **Scoped Logging**: All pipeline logs prefixed with `channel_name` for audit trail
- **CLI Commands**:
  - `ai-director budget status --config <path>` — view remaining budget, costs by category
  - `ai-director migrate --config <path>` — auto-generate missing brand_identity/budget with defaults
  - `ai-director init --name <name> --niche <niche>` — generate boilerplate channel config
- **Pipeline Workflow**:
  - Budget pre-check job before pipeline starts
  - Budget summary job after pipeline completes
  - Telegram notification on budget alerts
  - `budget_blocked` topic status when pipeline stopped by budget
  - `channel_name` passed explicitly to all workflow steps

### Changed
- `ChannelConfig` Pydantic model is now frozen (immutable) — enforces brand isolation at runtime
- All 5 agents (Script Writer, Shot List Director, Asset Resolver, Motion Director, QA Validator) now:
  - Read and respect `brand_identity` for creative decisions
  - Adapt output based on `aspect_ratio` (9:16, 16:9, 1:1)
- `reusable-pipeline.yml` now requires `channel_name` input for isolation enforcement
- Config validation (`ai-director validate`) checks brand_identity and budget fields

### No Breaking Changes for Existing Channels
- `brand_identity` defaults to `None` (agents use existing narrative config)
- `budget` defaults to `None` (unlimited spending)
- Existing `channel_config.json` files work without modification
