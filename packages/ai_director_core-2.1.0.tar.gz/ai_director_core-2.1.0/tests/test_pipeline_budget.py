"""Tests for budget-aware pipeline behavior: proceed, fallback, stop."""

import json
from pathlib import Path

import pytest

from ai_director.budget.tracker import BudgetTracker, LocalStorageBackend
from ai_director.models.budget import BudgetConfig
from ai_director.models.config import ChannelConfig
from ai_director.pipeline import run_full_pipeline, _remove_ai_sources


def _config(budget: dict | None = None) -> ChannelConfig:
    data = {
        "channel_name": "TestBrand",
        "channel_niche": "testing",
        "target_platform": "youtube_shorts",
        "target_audience": "testers",
        "narrative": {
            "tone": "neutral",
            "pacing_wps": 3.0,
            "max_words_per_60s": 50,
            "hook_formula": "question",
            "structure": ["hook", "body"],
        },
        "visual": {
            "color_palette": ["#000"],
            "shot_ratio": {"wide": 1.0},
            "forbidden_visuals": [],
        },
        "motion": {
            "default_style": "slow",
            "allowed_motions": ["pan"],
            "forbidden_motions": [],
            "min_scene_duration_s": 5,
            "max_scene_duration_s": 10,
        },
        "asset_sources_priority": ["pexels_search", "ai_generate_flux"],
        "confidence_thresholds": {"auto_proceed": 0.85},
    }
    if budget:
        data["budget"] = budget
    return ChannelConfig(**data)


class TestPipelineBudgetProceed:
    def test_runs_all_agents_within_budget(self, tmp_path):
        config = _config(budget={
            "monthly_limit_usd": 1000.0,
            "per_video_limit_usd": 100.0,
            "cost_allocation": {"api_calls": 0.7, "asset_gen": 0.3},
        })
        result = run_full_pipeline(config, "Test Topic", "t001", str(tmp_path / "out"))
        assert result["status"] == "ready"
        assert "budget_summary" in result

    def test_no_budget_unlimited(self, tmp_path):
        config = _config()
        result = run_full_pipeline(config, "Test", "t002", str(tmp_path / "out"))
        assert result["status"] == "ready"


class TestPipelineBudgetFallback:
    def test_removes_ai_sources_on_fallback(self):
        config = _config()
        filtered = _remove_ai_sources(config)
        assert "ai_generate_flux" not in filtered.asset_sources_priority
        assert "pexels_search" in filtered.asset_sources_priority

    def test_fallback_defaults_to_pexels(self):
        config = _config()
        config = config.model_copy(update={"asset_sources_priority": ["ai_generate_flux"]})
        filtered = _remove_ai_sources(config)
        assert filtered.asset_sources_priority == ["pexels_search"]


class TestPipelineBudgetStop:
    def test_stops_when_budget_exhausted(self, tmp_path):
        # Set extremely low budget that will trigger hard stop
        config = _config(budget={
            "monthly_limit_usd": 0.01,
            "per_video_limit_usd": 0.001,
            "cost_allocation": {"api_calls": 0.7, "asset_gen": 0.3},
            "alert_threshold_pct": 0.0,
            "hard_stop_threshold_pct": 0.0,  # Stop immediately
        })
        result = run_full_pipeline(config, "Test", "t003", str(tmp_path / "out"))
        assert result["status"] == "budget_blocked"
        assert "stopped_at" in result
