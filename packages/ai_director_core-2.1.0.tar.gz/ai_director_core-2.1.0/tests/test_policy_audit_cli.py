"""Tests for the audit CLI command and pipeline policy integration."""

import json
from pathlib import Path

import pytest

from ai_director.models.config import ChannelConfig
from ai_director.pipeline import _AGENT_PIPELINE


def _config_dict() -> dict:
    return {
        "channel_name": "TestBrand",
        "channel_niche": "testing",
        "target_platform": "youtube_shorts",
        "target_audience": "testers",
        "narrative": {
            "tone": "neutral",
            "pacing_wps": 3.0,
            "max_words_per_60s": 50,
            "hook_formula": "question",
            "structure": ["hook", "body"],
        },
        "visual": {
            "color_palette": ["#000"],
            "shot_ratio": {"wide": 1.0},
            "forbidden_visuals": [],
        },
        "motion": {
            "default_style": "slow",
            "allowed_motions": ["pan"],
            "forbidden_motions": [],
            "min_scene_duration_s": 5,
            "max_scene_duration_s": 10,
        },
        "asset_sources_priority": ["pexels_search"],
        "confidence_thresholds": {"auto_proceed": 0.85},
    }


class TestPipelinePolicyOrder:
    """PolicyAuditor must be in the pipeline between MotionDirector and QAValidator."""

    def test_policy_auditor_in_pipeline(self):
        agent_names = [name for name, _ in _AGENT_PIPELINE]
        assert "policy_audit" in agent_names

    def test_policy_auditor_after_motion(self):
        agent_names = [name for name, _ in _AGENT_PIPELINE]
        motion_idx = agent_names.index("motion")
        policy_idx = agent_names.index("policy_audit")
        assert policy_idx > motion_idx

    def test_policy_auditor_before_qa(self):
        agent_names = [name for name, _ in _AGENT_PIPELINE]
        policy_idx = agent_names.index("policy_audit")
        qa_idx = agent_names.index("qa")
        assert policy_idx < qa_idx

    def test_pipeline_order_complete(self):
        expected_order = ["script", "shots", "assets", "motion", "policy_audit", "qa"]
        actual_order = [name for name, _ in _AGENT_PIPELINE]
        assert actual_order == expected_order


class TestAuditCLI:
    """Tests for the `ad audit` command."""

    def test_audit_clean_content(self, tmp_path):
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps(_config_dict()))

        input_data = {
            "topic": "Ancient Roman architecture",
            "script": "The Colosseum was built in 80 AD.",
            "shots": [{"description": "Wide shot of ruins"}],
        }
        input_path = tmp_path / "input.json"
        input_path.write_text(json.dumps(input_data))

        from ai_director.runner import _cmd_audit
        import argparse

        args = argparse.Namespace(
            config=str(config_path),
            input=str(input_path),
            check_freshness=False,
            as_json=True,
        )
        # Should not raise or sys.exit(1)
        import io
        import sys

        captured = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured
        try:
            _cmd_audit(args)
        finally:
            sys.stdout = old_stdout

        output = json.loads(captured.getvalue())
        assert output["status"] == "audit_passed"

    def test_audit_violation_exits_1(self, tmp_path):
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps(_config_dict()))

        input_data = {
            "topic": "Test",
            "script": "This contains graphic violence and gore",
        }
        input_path = tmp_path / "input.json"
        input_path.write_text(json.dumps(input_data))

        from ai_director.runner import _cmd_audit
        import argparse

        args = argparse.Namespace(
            config=str(config_path),
            input=str(input_path),
            check_freshness=False,
            as_json=True,
        )

        with pytest.raises(SystemExit) as exc_info:
            _cmd_audit(args)
        assert exc_info.value.code == 1

    def test_audit_check_freshness(self, tmp_path):
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps(_config_dict()))

        input_data = {
            "topic": "Clean content",
            "script": "A beautiful sunrise over the mountains.",
        }
        input_path = tmp_path / "input.json"
        input_path.write_text(json.dumps(input_data))

        from ai_director.runner import _cmd_audit
        import argparse

        args = argparse.Namespace(
            config=str(config_path),
            input=str(input_path),
            check_freshness=True,
            as_json=False,
        )
        # Should include freshness info, not raise
        import io
        import sys

        captured = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured
        try:
            _cmd_audit(args)
        finally:
            sys.stdout = old_stdout

        output = captured.getvalue()
        assert "Policy Audit: audit_passed" in output
        assert "Policy rules are fresh" in output or "Policy rules may be stale" in output
