"""Tests for the platform policy registry."""

import pytest
from datetime import date

from ai_director.policies import (
    PolicyRule,
    PlatformPolicy,
    get_policy,
    list_platforms,
    check_text_against_rules,
)


class TestPolicyRegistry:
    """Test policy loading and structure."""

    def test_all_platforms_registered(self):
        platforms = list_platforms()
        assert "youtube_shorts" in platforms
        assert "tiktok" in platforms
        assert "instagram_reels" in platforms

    def test_get_policy_youtube(self):
        policy = get_policy("youtube_shorts")
        assert policy.platform == "youtube_shorts"
        assert policy.name == "YouTube Community Guidelines"
        assert isinstance(policy.last_updated, date)
        assert len(policy.rules) > 0

    def test_get_policy_tiktok(self):
        policy = get_policy("tiktok")
        assert policy.platform == "tiktok"
        assert policy.name == "TikTok Community Guidelines"
        assert len(policy.rules) > 0

    def test_get_policy_instagram(self):
        policy = get_policy("instagram_reels")
        assert policy.platform == "instagram_reels"
        assert "Meta" in policy.name
        assert len(policy.rules) > 0

    def test_get_policy_unknown_raises(self):
        with pytest.raises(KeyError, match="No policy registered"):
            get_policy("nonexistent_platform")

    def test_policy_has_categories(self):
        for platform in list_platforms():
            policy = get_policy(platform)
            assert len(policy.categories) > 0

    def test_all_rules_have_required_fields(self):
        for platform in list_platforms():
            policy = get_policy(platform)
            for rule in policy.rules:
                assert rule.rule_id, f"Missing rule_id in {platform}"
                assert rule.category, f"Missing category in {platform}"
                assert rule.severity == "block", f"Severity must be 'block' for {rule.rule_id}"

    def test_rule_ids_unique_per_platform(self):
        for platform in list_platforms():
            policy = get_policy(platform)
            ids = [r.rule_id for r in policy.rules]
            assert len(ids) == len(set(ids)), f"Duplicate rule IDs in {platform}"

    def test_freshness_date_not_ancient(self):
        """Policy data should be from 2025 or later."""
        for platform in list_platforms():
            policy = get_policy(platform)
            assert policy.last_updated.year >= 2025, (
                f"{platform} policy last_updated is too old: {policy.last_updated}"
            )

    def test_guidelines_url_set(self):
        for platform in list_platforms():
            policy = get_policy(platform)
            assert policy.guidelines_url.startswith("https://")

    def test_get_rules_by_category(self):
        policy = get_policy("youtube_shorts")
        hate_rules = policy.get_rules_by_category("hate_speech")
        assert len(hate_rules) > 0
        for rule in hate_rules:
            assert rule.category == "hate_speech"


class TestCheckTextAgainstRules:
    """Test Tier 1 keyword/pattern matching."""

    def test_clean_text_passes(self):
        policy = get_policy("youtube_shorts")
        violations = check_text_against_rules(
            "A beautiful sunrise over ancient Roman streets",
            policy.rules,
        )
        assert len(violations) == 0

    def test_keyword_match(self):
        policy = get_policy("youtube_shorts")
        violations = check_text_against_rules(
            "This video shows graphic violence and gore",
            policy.rules,
        )
        assert len(violations) > 0
        assert any(v["match_type"] == "keyword" for v in violations)

    def test_pattern_match(self):
        policy = get_policy("tiktok")
        violations = check_text_against_rules(
            "Learn how to kill people in this tutorial",
            policy.rules,
        )
        assert len(violations) > 0

    def test_case_insensitive_keywords(self):
        policy = get_policy("instagram_reels")
        violations = check_text_against_rules(
            "PORNOGRAPHY content is forbidden",
            policy.rules,
        )
        assert len(violations) > 0

    def test_multiple_violations(self):
        policy = get_policy("youtube_shorts")
        violations = check_text_against_rules(
            "gore pornography buy drugs online",
            policy.rules,
        )
        # Should catch multiple rules
        categories = {v["category"] for v in violations}
        assert len(categories) >= 2

    def test_violation_contains_rule_id(self):
        policy = get_policy("youtube_shorts")
        violations = check_text_against_rules("gore content", policy.rules)
        assert violations
        assert "rule_id" in violations[0]
        assert "category" in violations[0]
        assert "severity" in violations[0]
