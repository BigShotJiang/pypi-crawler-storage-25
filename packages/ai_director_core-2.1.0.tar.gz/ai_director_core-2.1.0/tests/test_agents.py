"""Integration tests: agents produce correct output for different brand configs."""

import pytest

from ai_director.agents.script_writer import ScriptWriter
from ai_director.agents.shot_list_director import ShotListDirector
from ai_director.agents.asset_resolver import AssetResolver
from ai_director.agents.motion_director import MotionDirector
from ai_director.agents.qa_validator import QAValidator
from ai_director.models.config import ChannelConfig


def _losteras_config() -> ChannelConfig:
    """LostEras: historical, 9:16, with brand identity."""
    return ChannelConfig(
        channel_name="LostEras",
        channel_niche="historical storytelling shorts",
        target_platform="youtube_shorts",
        target_audience="History enthusiasts 25-45",
        aspect_ratio="9:16",
        narrative={
            "tone": "Epic, contemplative",
            "pacing_wps": 3.5,
            "max_words_per_60s": 55,
            "hook_formula": "Counter-intuitive fact",
            "structure": ["hook_0_8s", "context_8_25s", "climax_25_50s", "payoff_50_60s"],
        },
        visual={
            "color_palette": ["dark amber #C9A84C", "deep crimson #8B1A1A"],
            "shot_ratio": {"wide_establishing": 0.6, "medium": 0.25, "close_detail": 0.15},
            "forbidden_visuals": ["modern buildings", "cars"],
            "historical_accuracy_window_years": 50,
        },
        motion={
            "default_style": "slow_cinematic",
            "allowed_motions": ["slow_pan_left", "slow_zoom_in"],
            "forbidden_motions": ["shake", "fast_cuts_under_2s"],
            "min_scene_duration_s": 6,
            "max_scene_duration_s": 12,
        },
        asset_sources_priority=["library_cache", "pexels_search", "ai_generate_flux"],
        confidence_thresholds={"auto_proceed": 0.85},
        brand_identity={
            "brand_voice": "Epic, third-person omniscient narrator",
            "audience_plan": {
                "primary_segments": [
                    {"name": "History buffs", "demographics": "25-45 M/F US/UK", "psychographics": "Curious about ancient civilizations"},
                ],
                "content_goals": ["educate", "awe"],
                "engagement_strategy": "End with provocative question",
            },
            "hook_strategy": {
                "primary_hooks": ["Counter-intuitive fact opener", "Death/betrayal moment"],
                "forbidden_hooks": ["Like and subscribe", "You won't believe"],
            },
            "unique_selling_points": ["Only channel covering Roman daily life"],
            "competitor_differentiation": "Focuses on daily life not wars",
        },
    )


def _quietmind_config() -> ChannelConfig:
    """QuietMind: meditation, 16:9, with brand identity."""
    return ChannelConfig(
        channel_name="QuietMind",
        channel_niche="mindfulness and meditation",
        target_platform="instagram_reels",
        target_audience="Stressed professionals 28-40",
        aspect_ratio="16:9",
        narrative={
            "tone": "Calm, second-person, direct instructions",
            "pacing_wps": 2.5,
            "max_words_per_60s": 40,
            "hook_formula": "Relatable stress scenario",
            "structure": ["problem_0_10s", "technique_10_45s", "outcome_45_60s"],
        },
        visual={
            "color_palette": ["soft sage #87A878", "warm white #F8F4EE"],
            "shot_ratio": {"wide_establishing": 0.3, "medium": 0.4, "close_detail": 0.3},
            "forbidden_visuals": ["crowds", "screens", "city traffic"],
        },
        motion={
            "default_style": "ultra_slow_breathe",
            "allowed_motions": ["ultra_slow_zoom_in", "slow_pan_right"],
            "forbidden_motions": ["shake", "fast_cuts_under_4s"],
            "min_scene_duration_s": 8,
            "max_scene_duration_s": 15,
        },
        asset_sources_priority=["pexels_search"],
        confidence_thresholds={"auto_proceed": 0.9},
        brand_identity={
            "brand_voice": "Calm, nurturing, direct",
            "audience_plan": {
                "primary_segments": [
                    {"name": "Stressed professionals", "demographics": "28-40 US", "psychographics": "Seeking calm"},
                ],
                "content_goals": ["relax", "teach technique"],
                "engagement_strategy": "Invite to try the technique",
            },
            "hook_strategy": {
                "primary_hooks": ["Relatable stress scenario"],
                "forbidden_hooks": ["Clickbait", "Shocking"],
            },
        },
    )


class TestScriptWriter:
    def test_portrait_uses_brand_voice(self):
        config = _losteras_config()
        agent = ScriptWriter(config)
        result = agent.run({"topic": "Roman Sewers", "topic_id": "t001"})
        ctx = result["prompt_context"]
        assert ctx["brand_voice"] == "Epic, third-person omniscient narrator"
        assert "Counter-intuitive fact opener" in ctx["primary_hooks"]
        assert "Like and subscribe" in ctx["forbidden_hooks"]
        assert result["metadata"]["aspect_ratio"] == "9:16"

    def test_landscape_uses_different_brand(self):
        config = _quietmind_config()
        agent = ScriptWriter(config)
        result = agent.run({"topic": "Box Breathing", "topic_id": "t002"})
        ctx = result["prompt_context"]
        assert ctx["brand_voice"] == "Calm, nurturing, direct"
        assert result["metadata"]["aspect_ratio"] == "16:9"

    def test_no_brand_identity_still_works(self):
        config = _losteras_config().model_copy(update={"brand_identity": None})
        agent = ScriptWriter(config)
        result = agent.run({"topic": "Test", "topic_id": "t003"})
        assert "brand_voice" not in result["prompt_context"]
        assert result["prompt_context"]["tone"] == "Epic, contemplative"


class TestShotListDirector:
    def test_portrait_composition(self):
        agent = ShotListDirector(_losteras_config())
        result = agent.run({})
        assert result["aspect_ratio"] == "9:16"
        assert "vertical" in result["composition_rules"]["framing"]

    def test_landscape_composition(self):
        agent = ShotListDirector(_quietmind_config())
        result = agent.run({})
        assert result["aspect_ratio"] == "16:9"
        assert "landscape" in result["composition_rules"]["framing"]


class TestAssetResolver:
    def test_portrait_search_params(self):
        agent = AssetResolver(_losteras_config())
        result = agent.run({})
        assert result["search_params"]["orientation"] == "portrait"
        assert result["search_params"]["min_height"] == 1920

    def test_landscape_search_params(self):
        agent = AssetResolver(_quietmind_config())
        result = agent.run({})
        assert result["search_params"]["orientation"] == "landscape"
        assert result["search_params"]["min_width"] == 1920

    def test_includes_brand_usps(self):
        agent = AssetResolver(_losteras_config())
        result = agent.run({})
        assert "Only channel covering Roman daily life" in result["unique_selling_points"]


class TestMotionDirector:
    def test_portrait_pan_amplitude(self):
        agent = MotionDirector(_losteras_config())
        result = agent.run({})
        assert result["aspect_adjustments"]["pan_amplitude_factor"] == 0.6
        assert result["default_style"] == "slow_cinematic"

    def test_landscape_pan_amplitude(self):
        agent = MotionDirector(_quietmind_config())
        result = agent.run({})
        assert result["aspect_adjustments"]["pan_amplitude_factor"] == 1.0
        assert result["default_style"] == "ultra_slow_breathe"


class TestQAValidator:
    def test_includes_brand_identity_checks(self):
        agent = QAValidator(_losteras_config())
        result = agent.run({})
        check_ids = [c["id"] for c in result["validation_checks"]]
        assert "aspect_ratio" in check_ids
        assert "forbidden_hooks" in check_ids
        assert "brand_voice" in check_ids
        assert "forbidden_visuals" in check_ids

    def test_portrait_aspect_check(self):
        agent = QAValidator(_losteras_config())
        result = agent.run({})
        ar_check = next(c for c in result["validation_checks"] if c["id"] == "aspect_ratio")
        assert ar_check["expected"] == "9:16"

    def test_landscape_aspect_check(self):
        agent = QAValidator(_quietmind_config())
        result = agent.run({})
        ar_check = next(c for c in result["validation_checks"] if c["id"] == "aspect_ratio")
        assert ar_check["expected"] == "16:9"

    def test_no_brand_identity_fewer_checks(self):
        config = _losteras_config().model_copy(update={"brand_identity": None})
        agent = QAValidator(config)
        result = agent.run({})
        check_ids = [c["id"] for c in result["validation_checks"]]
        assert "forbidden_hooks" not in check_ids
        assert "brand_voice" not in check_ids
