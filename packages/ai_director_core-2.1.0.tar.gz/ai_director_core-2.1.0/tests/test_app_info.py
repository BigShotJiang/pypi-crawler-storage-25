import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from ai_director.models.config import ChannelConfig


def _minimal_config(**overrides) -> dict:
    base = {
        "channel_name": "TestChannel",
        "channel_niche": "testing",
        "target_platform": "youtube_shorts",
        "target_audience": "testers",
        "narrative": {
            "tone": "neutral",
            "pacing_wps": 3.0,
            "max_words_per_60s": 50,
            "hook_formula": "ask a question",
            "structure": ["hook", "body", "outro"],
        },
        "visual": {
            "color_palette": ["#000000"],
            "shot_ratio": {"wide_establishing": 0.6, "medium": 0.4},
            "forbidden_visuals": [],
        },
        "motion": {
            "default_style": "slow_cinematic",
            "allowed_motions": ["slow_pan_left"],
            "forbidden_motions": [],
            "min_scene_duration_s": 5,
            "max_scene_duration_s": 10,
        },
        "asset_sources_priority": ["pexels_search"],
        "confidence_thresholds": {"auto_proceed": 0.85},
    }
    return {**base, **overrides}


def _write_config(tmp: Path, **overrides) -> Path:
    cfg_path = tmp / "channel_config.json"
    cfg_path.write_text(json.dumps(_minimal_config(**overrides)))
    return cfg_path


class TestAppInfoCLI:
    def test_app_info_writes_manifest(self, tmp_path, monkeypatch):
        cfg_path = _write_config(tmp_path)
        manifest_path = tmp_path / ".ai-director.json"
        monkeypatch.delenv("AI_DIRECTOR_LLM_MODEL", raising=False)
        monkeypatch.delenv("AI_DIRECTOR_IMAGE_MODEL", raising=False)

        import argparse
        from ai_director.runner import _cmd_app_info

        args = argparse.Namespace(
            config=str(cfg_path),
            show=False,
            output=str(manifest_path),
        )
        _cmd_app_info(args)

        assert manifest_path.exists()
        data = json.loads(manifest_path.read_text())
        assert data["name"] == "TestChannel"
        assert data["niche"] == "testing"
        assert data["platform"] == "youtube_shorts"
        assert data["ai_models"]["llm_model"] == "gemini-3.1"
        assert data["ai_models"]["image_model"] == "gemini-2.5-flash-image"
        assert "core_version" in data
        assert "generated_at" in data

    def test_app_info_show_mode(self, tmp_path, capsys, monkeypatch):
        cfg_path = _write_config(tmp_path)
        monkeypatch.delenv("AI_DIRECTOR_LLM_MODEL", raising=False)
        monkeypatch.delenv("AI_DIRECTOR_IMAGE_MODEL", raising=False)

        import argparse
        from ai_director.runner import _cmd_app_info

        args = argparse.Namespace(
            config=str(cfg_path),
            show=True,
            output=".ai-director.json",
        )
        _cmd_app_info(args)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["name"] == "TestChannel"
        assert data["ai_models"]["llm_model"] == "gemini-3.1"

    def test_app_info_with_custom_models(self, tmp_path, monkeypatch):
        cfg_path = _write_config(
            tmp_path,
            ai_models={"llm_model": "custom-llm", "image_model": "custom-img"},
        )
        manifest_path = tmp_path / ".ai-director.json"
        monkeypatch.delenv("AI_DIRECTOR_LLM_MODEL", raising=False)
        monkeypatch.delenv("AI_DIRECTOR_IMAGE_MODEL", raising=False)

        import argparse
        from ai_director.runner import _cmd_app_info

        args = argparse.Namespace(
            config=str(cfg_path),
            show=False,
            output=str(manifest_path),
        )
        _cmd_app_info(args)

        data = json.loads(manifest_path.read_text())
        assert data["ai_models"]["llm_model"] == "custom-llm"
        assert data["ai_models"]["image_model"] == "custom-img"
