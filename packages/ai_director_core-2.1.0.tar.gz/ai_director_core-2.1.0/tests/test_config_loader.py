import json
import tempfile
from pathlib import Path

import pytest

from ai_director.config_loader import load_channel_config, validate_config
from ai_director.models.config import ChannelConfig


def _minimal_config(**overrides) -> dict:
    """A minimal valid channel config dict."""
    base = {
        "channel_name": "TestChannel",
        "channel_niche": "testing",
        "target_platform": "youtube_shorts",
        "target_audience": "testers",
        "narrative": {
            "tone": "neutral",
            "pacing_wps": 3.0,
            "max_words_per_60s": 50,
            "hook_formula": "ask a question",
            "structure": ["hook", "body", "outro"],
        },
        "visual": {
            "color_palette": ["#000000"],
            "shot_ratio": {"wide_establishing": 0.6, "medium": 0.4},
            "forbidden_visuals": [],
        },
        "motion": {
            "default_style": "slow_cinematic",
            "allowed_motions": ["slow_pan_left"],
            "forbidden_motions": [],
            "min_scene_duration_s": 5,
            "max_scene_duration_s": 10,
        },
        "asset_sources_priority": ["pexels_search"],
        "confidence_thresholds": {"auto_proceed": 0.85},
    }
    return {**base, **overrides}


def _write_config(data: dict, tmp_path: Path) -> Path:
    p = tmp_path / "channel_config.json"
    p.write_text(json.dumps(data))
    return p


class TestLoadChannelConfig:
    def test_loads_valid_config(self, tmp_path):
        path = _write_config(_minimal_config(), tmp_path)
        config = load_channel_config(path)
        assert config.channel_name == "TestChannel"
        assert isinstance(config, ChannelConfig)

    def test_returns_frozen_instance(self, tmp_path):
        path = _write_config(_minimal_config(), tmp_path)
        config = load_channel_config(path)
        with pytest.raises(Exception):
            config.channel_name = "changed"

    def test_no_global_state(self, tmp_path):
        """Two loads produce independent instances."""
        data1 = _minimal_config(channel_name="Channel_A")
        data2 = _minimal_config(channel_name="Channel_B")
        p1 = tmp_path / "a.json"
        p2 = tmp_path / "b.json"
        p1.write_text(json.dumps(data1))
        p2.write_text(json.dumps(data2))

        config_a = load_channel_config(p1)
        config_b = load_channel_config(p2)

        assert config_a.channel_name == "Channel_A"
        assert config_b.channel_name == "Channel_B"
        assert config_a is not config_b

    def test_with_brand_identity(self, tmp_path):
        data = _minimal_config(
            brand_identity={
                "brand_voice": "Calm and educational",
                "audience_plan": {
                    "primary_segments": [
                        {
                            "name": "Students",
                            "demographics": "18-25",
                            "psychographics": "Curious",
                        }
                    ],
                    "content_goals": ["educate"],
                    "engagement_strategy": "Quiz at end",
                },
                "hook_strategy": {
                    "primary_hooks": ["Did you know..."],
                },
            }
        )
        path = _write_config(data, tmp_path)
        config = load_channel_config(path)
        assert config.brand_identity is not None
        assert config.brand_identity.brand_voice == "Calm and educational"

    def test_without_brand_identity_backward_compat(self, tmp_path):
        path = _write_config(_minimal_config(), tmp_path)
        config = load_channel_config(path)
        assert config.brand_identity is None
        assert config.budget is None

    def test_with_budget(self, tmp_path):
        data = _minimal_config(
            budget={
                "monthly_limit_usd": 200.0,
                "per_video_limit_usd": 10.0,
                "cost_allocation": {"api_calls": 0.7, "asset_gen": 0.3},
            }
        )
        path = _write_config(data, tmp_path)
        config = load_channel_config(path)
        assert config.budget is not None
        assert config.budget.monthly_limit_usd == 200.0


class TestValidateConfig:
    def test_valid_config_no_errors(self, tmp_path):
        path = _write_config(_minimal_config(), tmp_path)
        config = load_channel_config(path)
        errors = validate_config(config)
        assert errors == []

    def test_min_exceeds_max_duration(self, tmp_path):
        data = _minimal_config()
        data["motion"]["min_scene_duration_s"] = 10
        data["motion"]["max_scene_duration_s"] = 10
        path = _write_config(data, tmp_path)
        config = load_channel_config(path)
        errors = validate_config(config)
        assert any("min_scene_duration_s" in e for e in errors)

    def test_per_video_exceeds_monthly(self, tmp_path):
        data = _minimal_config(
            budget={
                "monthly_limit_usd": 5.0,
                "per_video_limit_usd": 10.0,
                "cost_allocation": {"api_calls": 1.0},
            }
        )
        path = _write_config(data, tmp_path)
        config = load_channel_config(path)
        errors = validate_config(config)
        assert any("per_video_limit_usd" in e for e in errors)
