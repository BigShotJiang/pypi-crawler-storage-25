import pytest
from pydantic import ValidationError

from ai_director.models.brand_identity import (
    AudienceSegment,
    AudiencePlan,
    BrandIdentity,
    ContentPlan,
    HookStrategy,
)


def _segment(**overrides) -> dict:
    base = {
        "name": "History buffs 25-45",
        "demographics": "Male 25-45, US/UK",
        "psychographics": "Curious about ancient civilizations",
    }
    return {**base, **overrides}


def _audience_plan(**overrides) -> dict:
    base = {
        "primary_segments": [_segment()],
        "content_goals": ["educate", "entertain"],
        "engagement_strategy": "Ask provocative questions in the last 5s",
    }
    return {**base, **overrides}


def _hook_strategy(**overrides) -> dict:
    base = {
        "primary_hooks": ["Counter-intuitive fact opener"],
        "forbidden_hooks": [],
        "hook_test_criteria": "Must grab attention within 2 seconds",
    }
    return {**base, **overrides}


def _brand_identity(**overrides) -> dict:
    base = {
        "brand_voice": "Epic, contemplative, third-person omniscient",
        "audience_plan": _audience_plan(),
        "hook_strategy": _hook_strategy(),
    }
    return {**base, **overrides}


# ── AudienceSegment ──────────────────────────────────────────


class TestAudienceSegment:
    def test_valid(self):
        seg = AudienceSegment(**_segment())
        assert seg.name == "History buffs 25-45"

    def test_missing_name(self):
        with pytest.raises(ValidationError):
            AudienceSegment(**_segment(name=None))

    def test_empty_name(self):
        with pytest.raises(ValidationError):
            AudienceSegment(**_segment(name=""))

    def test_frozen(self):
        seg = AudienceSegment(**_segment())
        with pytest.raises(ValidationError):
            seg.name = "changed"


# ── AudiencePlan ─────────────────────────────────────────────


class TestAudiencePlan:
    def test_valid(self):
        plan = AudiencePlan(**_audience_plan())
        assert len(plan.primary_segments) == 1

    def test_empty_segments_rejected(self):
        with pytest.raises(ValidationError):
            AudiencePlan(**_audience_plan(primary_segments=[]))

    def test_empty_goals_rejected(self):
        with pytest.raises(ValidationError):
            AudiencePlan(**_audience_plan(content_goals=[]))


# ── HookStrategy ─────────────────────────────────────────────


class TestHookStrategy:
    def test_valid(self):
        hs = HookStrategy(**_hook_strategy())
        assert hs.primary_hooks == ["Counter-intuitive fact opener"]

    def test_empty_primary_hooks_rejected(self):
        with pytest.raises(ValidationError):
            HookStrategy(**_hook_strategy(primary_hooks=[]))

    def test_forbidden_hooks_defaults_empty(self):
        hs = HookStrategy(primary_hooks=["Hook A"])
        assert hs.forbidden_hooks == []


# ── ContentPlan ──────────────────────────────────────────────


class TestContentPlan:
    def test_defaults(self):
        cp = ContentPlan()
        assert cp.posting_frequency == "daily"
        assert cp.evergreen_ratio == 0.7

    def test_evergreen_ratio_bounds(self):
        with pytest.raises(ValidationError):
            ContentPlan(evergreen_ratio=1.5)
        with pytest.raises(ValidationError):
            ContentPlan(evergreen_ratio=-0.1)


# ── BrandIdentity ────────────────────────────────────────────


class TestBrandIdentity:
    def test_valid_full(self):
        bi = BrandIdentity(**_brand_identity())
        assert bi.brand_voice.startswith("Epic")

    def test_missing_brand_voice(self):
        data = _brand_identity()
        del data["brand_voice"]
        with pytest.raises(ValidationError):
            BrandIdentity(**data)

    def test_empty_brand_voice(self):
        with pytest.raises(ValidationError):
            BrandIdentity(**_brand_identity(brand_voice=""))

    def test_missing_audience_plan(self):
        data = _brand_identity()
        del data["audience_plan"]
        with pytest.raises(ValidationError):
            BrandIdentity(**data)

    def test_missing_hook_strategy(self):
        data = _brand_identity()
        del data["hook_strategy"]
        with pytest.raises(ValidationError):
            BrandIdentity(**data)

    def test_content_plan_optional_defaults(self):
        bi = BrandIdentity(**_brand_identity())
        assert bi.content_plan.posting_frequency == "daily"

    def test_frozen(self):
        bi = BrandIdentity(**_brand_identity())
        with pytest.raises(ValidationError):
            bi.brand_voice = "changed"

    def test_with_usps_and_differentiation(self):
        bi = BrandIdentity(
            **_brand_identity(
                unique_selling_points=["Only channel covering Roman sewers"],
                competitor_differentiation="Focuses on daily life, not wars",
            )
        )
        assert len(bi.unique_selling_points) == 1
        assert "daily life" in bi.competitor_differentiation
