from __future__ import annotations

import re
from pathlib import Path

import pytest

from ai_director.version import get_version, bump_version


_PYPROJECT = Path(__file__).resolve().parent.parent / "pyproject.toml"


class TestGetVersion:
    def test_returns_semver(self):
        ver = get_version()
        assert re.match(r"^\d+\.\d+\.\d+$", ver)


class TestBumpVersion:
    def _read_version(self) -> str:
        text = _PYPROJECT.read_text()
        m = re.search(r'^version\s*=\s*"(\d+\.\d+\.\d+)"', text, re.MULTILINE)
        assert m
        return m.group(1)

    def _write_version(self, ver: str) -> None:
        text = _PYPROJECT.read_text()
        new_text = re.sub(
            r'^(version\s*=\s*")(\d+\.\d+\.\d+)(")',
            rf"\g<1>{ver}\3",
            text,
            count=1,
            flags=re.MULTILINE,
        )
        _PYPROJECT.write_text(new_text)

    def test_bump_patch(self):
        original = self._read_version()
        try:
            self._write_version("1.0.0")
            old, new = bump_version("patch")
            assert old == "1.0.0"
            assert new == "1.0.1"
            assert self._read_version() == "1.0.1"
        finally:
            self._write_version(original)

    def test_bump_minor(self):
        original = self._read_version()
        try:
            self._write_version("1.2.3")
            old, new = bump_version("minor")
            assert old == "1.2.3"
            assert new == "1.3.0"
        finally:
            self._write_version(original)

    def test_bump_major(self):
        original = self._read_version()
        try:
            self._write_version("1.2.3")
            old, new = bump_version("major")
            assert old == "1.2.3"
            assert new == "2.0.0"
        finally:
            self._write_version(original)

    def test_invalid_level(self):
        with pytest.raises(ValueError, match="Invalid level"):
            bump_version("invalid")
