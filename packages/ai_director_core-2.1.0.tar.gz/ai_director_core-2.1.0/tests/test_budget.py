import pytest
from pydantic import ValidationError

from ai_director.models.budget import BudgetConfig


def _budget(**overrides) -> dict:
    base = {
        "monthly_limit_usd": 100.0,
        "per_video_limit_usd": 5.0,
        "cost_allocation": {"api_calls": 0.6, "asset_gen": 0.3, "storage": 0.1},
    }
    return {**base, **overrides}


class TestBudgetConfig:
    def test_valid(self):
        bc = BudgetConfig(**_budget())
        assert bc.monthly_limit_usd == 100.0
        assert bc.alert_threshold_pct == 0.8
        assert bc.hard_stop_threshold_pct == 1.0
        assert bc.notification_channels == ["telegram"]

    def test_zero_monthly_rejected(self):
        with pytest.raises(ValidationError):
            BudgetConfig(**_budget(monthly_limit_usd=0))

    def test_negative_per_video_rejected(self):
        with pytest.raises(ValidationError):
            BudgetConfig(**_budget(per_video_limit_usd=-1))

    def test_cost_allocation_must_sum_to_one(self):
        with pytest.raises(ValidationError, match="sum to 1.0"):
            BudgetConfig(**_budget(cost_allocation={"api_calls": 0.5, "storage": 0.2}))

    def test_cost_allocation_negative_rejected(self):
        with pytest.raises(ValidationError, match="must be >= 0"):
            BudgetConfig(**_budget(cost_allocation={"api_calls": -0.1, "storage": 1.1}))

    def test_alert_greater_than_hard_stop_rejected(self):
        with pytest.raises(ValidationError, match="alert_threshold_pct"):
            BudgetConfig(**_budget(alert_threshold_pct=0.95, hard_stop_threshold_pct=0.8))

    def test_alert_threshold_bounds(self):
        with pytest.raises(ValidationError):
            BudgetConfig(**_budget(alert_threshold_pct=-0.1))
        with pytest.raises(ValidationError):
            BudgetConfig(**_budget(alert_threshold_pct=1.5))

    def test_frozen(self):
        bc = BudgetConfig(**_budget())
        with pytest.raises(ValidationError):
            bc.monthly_limit_usd = 200.0

    def test_custom_notification_channels(self):
        bc = BudgetConfig(**_budget(notification_channels=["slack", "email"]))
        assert bc.notification_channels == ["slack", "email"]

    def test_cost_allocation_tolerance(self):
        # Should accept values within 0.01 tolerance
        bc = BudgetConfig(**_budget(cost_allocation={"api_calls": 0.601, "asset_gen": 0.3, "storage": 0.1}))
        assert bc is not None
