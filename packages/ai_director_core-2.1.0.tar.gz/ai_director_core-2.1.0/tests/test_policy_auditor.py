"""Tests for the PolicyAuditor agent."""

import pytest
from datetime import date, timedelta

from ai_director.agents.policy_auditor import PolicyAuditor, check_freshness
from ai_director.models.config import ChannelConfig
from ai_director.policies import PlatformPolicy, PolicyRule


def _make_config(platform: str = "youtube_shorts") -> ChannelConfig:
    """Minimal config for testing PolicyAuditor."""
    return ChannelConfig(
        channel_name="TestChannel",
        channel_niche="test content",
        target_platform=platform,
        target_audience="General",
        aspect_ratio="9:16",
        narrative={
            "tone": "Neutral",
            "pacing_wps": 3.0,
            "max_words_per_60s": 50,
            "hook_formula": "Question",
            "structure": ["hook", "body", "outro"],
        },
        visual={
            "color_palette": ["#FFFFFF"],
            "shot_ratio": {"wide_establishing": 1.0},
            "forbidden_visuals": [],
        },
        motion={
            "default_style": "slow_cinematic",
            "allowed_motions": ["pan_left"],
            "forbidden_motions": [],
            "min_scene_duration_s": 3,
            "max_scene_duration_s": 10,
        },
        asset_sources_priority=["pexels_search"],
        confidence_thresholds={"auto_proceed": 0.85},
    )


class TestPolicyAuditorPassCase:
    """Clean content should pass audit."""

    def test_clean_script_passes(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Ancient Roman architecture",
            "script": "The Colosseum was built in 80 AD as a grand amphitheater.",
            "shots": [{"description": "Wide shot of Colosseum ruins"}],
        })
        assert result["status"] == "audit_passed"
        assert len(result["violations"]) == 0
        assert "is_policy_fresh" in result

    def test_clean_content_all_platforms(self):
        for platform in ["youtube_shorts", "tiktok", "instagram_reels"]:
            auditor = PolicyAuditor(_make_config(platform))
            result = auditor.run({
                "topic": "Beautiful sunset timelapse",
                "script": "Watch the sun set over the ocean in this peaceful moment.",
            })
            assert result["status"] == "audit_passed", f"Failed for {platform}"


class TestPolicyAuditorViolation:
    """Policy violations should trigger hard stop."""

    def test_violent_content_fails(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Test",
            "script": "This scene shows graphic violence and gore everywhere.",
        })
        assert result["status"] == "policy_violation"
        assert len(result["violations"]) > 0

    def test_hate_speech_fails(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Test",
            "script": "All people should die, white supremacy forever",
        })
        assert result["status"] == "policy_violation"

    def test_explicit_content_fails(self):
        auditor = PolicyAuditor(_make_config("tiktok"))
        result = auditor.run({
            "topic": "Test",
            "script": "Watch this pornography video with explicit sex",
        })
        assert result["status"] == "policy_violation"

    def test_child_safety_fails(self):
        auditor = PolicyAuditor(_make_config("instagram_reels"))
        result = auditor.run({
            "topic": "Test",
            "script": "Content about child exploitation and minor abuse",
        })
        assert result["status"] == "policy_violation"

    def test_scam_content_fails(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Test",
            "script": "Free money hack! Get rich quick guaranteed returns!",
        })
        assert result["status"] == "policy_violation"

    def test_misinformation_fails(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Test",
            "script": "Vaccines cause autism, proven by science",
        })
        assert result["status"] == "policy_violation"


class TestPolicyAuditorMultiSource:
    """Audit checks script, shots, and assets."""

    def test_violation_in_shots(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "History of Rome",
            "script": "The Roman Empire was vast and powerful.",
            "shots": [
                {"description": "Map of the empire"},
                {"description": "Scene with graphic violence and gore"},
            ],
        })
        assert result["status"] == "policy_violation"
        assert any(v["source"].startswith("shots[") for v in result["violations"])

    def test_violation_in_assets(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "History",
            "script": "A peaceful narration.",
            "assets": [
                {"description": "Sunset photo", "query": "sunset landscape"},
                {"description": "Violence", "query": "pornography content"},
            ],
        })
        assert result["status"] == "policy_violation"
        assert any(v["source"].startswith("assets[") for v in result["violations"])

    def test_clean_multi_source_passes(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Beautiful architecture",
            "script": "Rome's architecture influenced the entire Western world.",
            "shots": [
                {"description": "Wide shot of Pantheon"},
                {"description": "Close-up of marble columns"},
            ],
            "assets": [
                {"description": "Ancient temple", "query": "roman temple"},
            ],
        })
        assert result["status"] == "audit_passed"


class TestPolicyAuditorZeroTolerance:
    """Zero tolerance — any single violation blocks the entire video."""

    def test_one_bad_shot_blocks_all(self):
        """Even 1 violation among 100 clean items = block."""
        auditor = PolicyAuditor(_make_config())
        clean_shots = [{"description": f"Beautiful scene {i}"} for i in range(100)]
        clean_shots[50] = {"description": "Scene with graphic violence and gore"}

        result = auditor.run({
            "topic": "Nature documentary",
            "script": "A wonderful story about nature.",
            "shots": clean_shots,
        })
        assert result["status"] == "policy_violation"


class TestPolicyAuditorChecksPerformed:
    """Audit result includes details of checks performed."""

    def test_checks_performed_recorded(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Test",
            "script": "Clean content about history.",
        })
        assert len(result["checks_performed"]) > 0
        assert result["checks_performed"][0]["tier"] == 1

    def test_tier2_runs_when_tier1_passes(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Peaceful meditation",
            "script": "Breathe in, breathe out. Find your calm center.",
        })
        assert result["status"] == "audit_passed"
        tier2_checks = [c for c in result["checks_performed"] if c.get("tier") == 2]
        assert len(tier2_checks) > 0

    def test_tier2_skipped_on_tier1_violation(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Test",
            "script": "Graphic violence and gore in every scene",
        })
        assert result["status"] == "policy_violation"
        tier2_checks = [c for c in result["checks_performed"] if c.get("tier") == 2]
        assert len(tier2_checks) == 0


class TestCheckFreshness:
    """Test policy freshness checking."""

    def test_recent_policy_is_fresh(self):
        policy = PlatformPolicy(
            platform="test",
            name="Test",
            last_updated=date.today(),
            guidelines_url="https://example.com",
        )
        assert check_freshness(policy) is True

    def test_old_policy_is_stale(self):
        policy = PlatformPolicy(
            platform="test",
            name="Test",
            last_updated=date.today() - timedelta(days=180),
            guidelines_url="https://example.com",
        )
        assert check_freshness(policy) is False

    def test_edge_of_freshness(self):
        policy = PlatformPolicy(
            platform="test",
            name="Test",
            last_updated=date.today() - timedelta(days=89),
            guidelines_url="https://example.com",
        )
        assert check_freshness(policy) is True


class TestPolicyAuditorPassthrough:
    """Auditor should pass through input data for downstream agents."""

    def test_input_data_preserved(self):
        auditor = PolicyAuditor(_make_config())
        result = auditor.run({
            "topic": "Ancient Rome",
            "script": "The Roman Forum was the heart of public life.",
            "shots": [{"description": "Forum ruins"}],
            "custom_field": "preserved",
        })
        assert result["custom_field"] == "preserved"
        assert result["topic"] == "Ancient Rome"
