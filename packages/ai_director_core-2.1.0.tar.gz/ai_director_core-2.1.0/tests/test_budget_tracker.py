import json
from pathlib import Path

import pytest

from ai_director.budget.tracker import (
    BudgetDecision,
    BudgetTracker,
    LocalStorageBackend,
)
from ai_director.models.budget import BudgetConfig


def _budget_config(**overrides) -> BudgetConfig:
    base = {
        "monthly_limit_usd": 100.0,
        "per_video_limit_usd": 10.0,
        "cost_allocation": {"api_calls": 0.6, "asset_gen": 0.3, "storage": 0.1},
        "alert_threshold_pct": 0.8,
        "hard_stop_threshold_pct": 1.0,
    }
    return BudgetConfig(**{**base, **overrides})


def _tracker(tmp_path: Path, config: BudgetConfig | None = None, **kw) -> BudgetTracker:
    if config is None:
        config = _budget_config()
    storage = LocalStorageBackend(tmp_path / ".budget")
    return BudgetTracker(
        channel_name="test-channel",
        budget_config=config,
        storage=storage,
        period="2026-05",
        **kw,
    )


class TestBudgetTrackerCheckBudget:
    def test_proceed_within_budget(self, tmp_path):
        t = _tracker(tmp_path)
        assert t.check_budget("api_calls", 1.0) == BudgetDecision.PROCEED

    def test_fallback_per_video_exceeded(self, tmp_path):
        t = _tracker(tmp_path)
        t.record_cost("api_calls", 9.0)
        assert t.check_budget("api_calls", 2.0) == BudgetDecision.FALLBACK

    def test_stop_hard_limit(self, tmp_path):
        config = _budget_config(per_video_limit_usd=200.0)
        t = _tracker(tmp_path, config=config)
        t.record_cost("api_calls", 95.0)
        assert t.check_budget("api_calls", 6.0) == BudgetDecision.STOP

    def test_alert_threshold_still_proceeds(self, tmp_path):
        """Alert threshold triggers warning but still returns PROCEED."""
        config = _budget_config(alert_threshold_pct=0.5, per_video_limit_usd=200.0)
        t = _tracker(tmp_path, config=config)
        t.record_cost("api_calls", 45.0)
        # 45 + 6 = 51 > 50 (alert at 50%), but < 100 (hard stop)
        assert t.check_budget("api_calls", 6.0) == BudgetDecision.PROCEED

    def test_category_limit_fallback(self, tmp_path):
        t = _tracker(tmp_path)
        # api_calls limit = 100 * 0.6 = 60
        t.record_cost("api_calls", 58.0)
        assert t.check_budget("api_calls", 3.0) == BudgetDecision.FALLBACK

    def test_unlimited_always_proceeds(self, tmp_path):
        storage = LocalStorageBackend(tmp_path / ".budget")
        t = BudgetTracker(
            channel_name="test",
            budget_config=None,
            storage=storage,
            period="2026-05",
        )
        assert t.is_unlimited
        assert t.check_budget("api_calls", 999999.0) == BudgetDecision.PROCEED


class TestBudgetTrackerRecordCost:
    def test_accumulates_costs(self, tmp_path):
        t = _tracker(tmp_path)
        t.record_cost("api_calls", 1.0)
        t.record_cost("api_calls", 2.0)
        t.record_cost("asset_gen", 0.5)
        summary = t.get_remaining()
        assert summary.total_spent_usd == pytest.approx(3.5)
        assert summary.spent_by_category["api_calls"] == pytest.approx(3.0)


class TestBudgetTrackerPersist:
    def test_persist_and_reload(self, tmp_path):
        t = _tracker(tmp_path)
        t.record_cost("api_calls", 5.0)
        t.record_cost("asset_gen", 2.0)
        t.persist(video_completed=True)

        # New tracker should load persisted data
        t2 = _tracker(tmp_path)
        summary = t2.get_remaining()
        assert summary.total_spent_usd == pytest.approx(7.0)
        assert summary.videos_produced == 1
        assert summary.remaining_usd == pytest.approx(93.0)

    def test_persist_clears_run_costs(self, tmp_path):
        t = _tracker(tmp_path)
        t.record_cost("api_calls", 5.0)
        t.persist()
        # Run costs should be zero now
        summary = t.get_remaining()
        # total_spent is in persisted data, not run costs
        assert summary.total_spent_usd == pytest.approx(5.0)

    def test_multiple_runs_accumulate(self, tmp_path):
        # Run 1
        t1 = _tracker(tmp_path)
        t1.record_cost("api_calls", 10.0)
        t1.persist(video_completed=True)

        # Run 2
        t2 = _tracker(tmp_path)
        t2.record_cost("api_calls", 15.0)
        t2.persist(video_completed=True)

        # Run 3 check
        t3 = _tracker(tmp_path)
        summary = t3.get_remaining()
        assert summary.total_spent_usd == pytest.approx(25.0)
        assert summary.videos_produced == 2
        assert summary.remaining_usd == pytest.approx(75.0)


class TestBudgetSummary:
    def test_unlimited_summary(self, tmp_path):
        storage = LocalStorageBackend(tmp_path / ".budget")
        t = BudgetTracker("ch", None, storage, "2026-05")
        s = t.get_remaining()
        assert s.monthly_limit_usd == float("inf")
        assert s.remaining_usd == float("inf")


class TestLocalStorageBackend:
    def test_load_nonexistent(self, tmp_path):
        backend = LocalStorageBackend(tmp_path)
        assert backend.load("ch", "2026-05") is None

    def test_save_and_load(self, tmp_path):
        backend = LocalStorageBackend(tmp_path)
        data = {"total": 42}
        backend.save("ch", "2026-05", data)
        loaded = backend.load("ch", "2026-05")
        assert loaded == data

    def test_creates_directories(self, tmp_path):
        backend = LocalStorageBackend(tmp_path / "nested" / "deep")
        backend.save("ch", "2026-05", {"x": 1})
        assert backend.load("ch", "2026-05") == {"x": 1}
