import pytest

from ai_director.lib.gcs import (
    GCSPathError,
    ScopedLogger,
    budget_data_path,
    build_gcs_path,
    validate_gcs_path,
)


class TestValidateGCSPath:
    def test_valid_path(self):
        p = validate_gcs_path("LostEras", "gs://ai-director-assets/losteras/assets/img.png")
        assert p == "gs://ai-director-assets/losteras/assets/img.png"

    def test_wrong_channel_rejected(self):
        with pytest.raises(GCSPathError, match="does not belong"):
            validate_gcs_path("LostEras", "gs://ai-director-assets/quietmind/assets/img.png")

    def test_path_traversal_rejected(self):
        with pytest.raises(GCSPathError, match="Path traversal"):
            validate_gcs_path("LostEras", "gs://ai-director-assets/losteras/../quietmind/x")

    def test_wrong_bucket_rejected(self):
        with pytest.raises(GCSPathError):
            validate_gcs_path("LostEras", "gs://other-bucket/losteras/x")


class TestBuildGCSPath:
    def test_builds_correct_path(self):
        p = build_gcs_path("LostEras", "library", "img.png")
        assert p == "gs://ai-director-assets/losteras/library/img.png"

    def test_channel_name_normalized(self):
        p = build_gcs_path("Lost Eras", "x")
        assert p == "gs://ai-director-assets/lost_eras/x"


class TestBudgetDataPath:
    def test_correct_structure(self):
        p = budget_data_path("LostEras", "2026-05")
        assert p == "gs://ai-director-assets/losteras/budget/monthly/2026-05.json"


class TestScopedLogger:
    def test_prefixes_messages(self):
        sl = ScopedLogger("test", "LostEras")
        msg, _ = sl.process("hello", {})
        assert msg == "[LostEras] hello"
