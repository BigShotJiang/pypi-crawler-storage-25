import os
import pytest
from ai_director.models.config import (
    AIModelsConfig,
    ChannelConfig,
    resolve_models,
    DEFAULT_LLM_MODEL,
    DEFAULT_IMAGE_MODEL,
)


def _minimal_config(**overrides) -> dict:
    base = {
        "channel_name": "TestChannel",
        "channel_niche": "testing",
        "target_platform": "youtube_shorts",
        "target_audience": "testers",
        "narrative": {
            "tone": "neutral",
            "pacing_wps": 3.0,
            "max_words_per_60s": 50,
            "hook_formula": "ask a question",
            "structure": ["hook", "body", "outro"],
        },
        "visual": {
            "color_palette": ["#000000"],
            "shot_ratio": {"wide_establishing": 0.6, "medium": 0.4},
            "forbidden_visuals": [],
        },
        "motion": {
            "default_style": "slow_cinematic",
            "allowed_motions": ["slow_pan_left"],
            "forbidden_motions": [],
            "min_scene_duration_s": 5,
            "max_scene_duration_s": 10,
        },
        "asset_sources_priority": ["pexels_search"],
        "confidence_thresholds": {"auto_proceed": 0.85},
    }
    return {**base, **overrides}


class TestAIModelsConfig:
    def test_defaults(self):
        m = AIModelsConfig()
        assert m.llm_model == DEFAULT_LLM_MODEL
        assert m.image_model == DEFAULT_IMAGE_MODEL

    def test_custom_models(self):
        m = AIModelsConfig(llm_model="claude-sonnet-4-20250514", image_model="dall-e-3")
        assert m.llm_model == "claude-sonnet-4-20250514"
        assert m.image_model == "dall-e-3"

    def test_frozen(self):
        m = AIModelsConfig()
        with pytest.raises(Exception):
            m.llm_model = "other"


class TestChannelConfigAIModels:
    def test_ai_models_none_by_default(self):
        cfg = ChannelConfig(**_minimal_config())
        assert cfg.ai_models is None

    def test_ai_models_set(self):
        cfg = ChannelConfig(**_minimal_config(ai_models={"llm_model": "custom-llm", "image_model": "custom-img"}))
        assert cfg.ai_models is not None
        assert cfg.ai_models.llm_model == "custom-llm"
        assert cfg.ai_models.image_model == "custom-img"


class TestResolveModels:
    def test_defaults_when_no_config_no_env(self, monkeypatch):
        monkeypatch.delenv("AI_DIRECTOR_LLM_MODEL", raising=False)
        monkeypatch.delenv("AI_DIRECTOR_IMAGE_MODEL", raising=False)
        cfg = ChannelConfig(**_minimal_config())
        llm, img = resolve_models(cfg)
        assert llm == DEFAULT_LLM_MODEL
        assert img == DEFAULT_IMAGE_MODEL

    def test_config_overrides_defaults(self, monkeypatch):
        monkeypatch.delenv("AI_DIRECTOR_LLM_MODEL", raising=False)
        monkeypatch.delenv("AI_DIRECTOR_IMAGE_MODEL", raising=False)
        cfg = ChannelConfig(**_minimal_config(ai_models={"llm_model": "my-llm", "image_model": "my-img"}))
        llm, img = resolve_models(cfg)
        assert llm == "my-llm"
        assert img == "my-img"

    def test_env_overrides_config(self, monkeypatch):
        monkeypatch.setenv("AI_DIRECTOR_LLM_MODEL", "env-llm")
        monkeypatch.setenv("AI_DIRECTOR_IMAGE_MODEL", "env-img")
        cfg = ChannelConfig(**_minimal_config(ai_models={"llm_model": "config-llm", "image_model": "config-img"}))
        llm, img = resolve_models(cfg)
        assert llm == "env-llm"
        assert img == "env-img"

    def test_partial_env_override(self, monkeypatch):
        monkeypatch.setenv("AI_DIRECTOR_LLM_MODEL", "env-llm")
        monkeypatch.delenv("AI_DIRECTOR_IMAGE_MODEL", raising=False)
        cfg = ChannelConfig(**_minimal_config(ai_models={"llm_model": "config-llm", "image_model": "config-img"}))
        llm, img = resolve_models(cfg)
        assert llm == "env-llm"
        assert img == "config-img"
