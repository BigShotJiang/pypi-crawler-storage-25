from __future__ import annotations

import json
from argparse import Namespace
from pathlib import Path

import pytest

from ai_director.scaffold import (
    _VALID_ASPECT_RATIOS,
    _collect_from_args,
    _generate_channel_config,
    _generate_requirements,
    _generate_topics_queue,
    _generate_workflow,
    run_scaffold,
)


@pytest.fixture
def sample_info() -> dict:
    return {
        "name": "TestBrand",
        "niche": "history",
        "platform": "youtube_shorts",
        "language": "en",
        "aspect_ratio": "9:16",
        "duration": 60,
        "voice": "Epic and cinematic",
        "audience": "History buffs 25-45",
        "budget_monthly": 100.0,
        "budget_per_video": 5.0,
    }


class TestGenerateChannelConfig:
    def test_config_has_all_sections(self, sample_info):
        config = _generate_channel_config(sample_info)
        assert config["channel_name"] == "TestBrand"
        assert config["channel_niche"] == "history"
        assert config["aspect_ratio"] == "9:16"
        assert "brand_identity" in config
        assert "budget" in config
        assert "narrative" in config
        assert "visual" in config
        assert "motion" in config

    def test_brand_identity_uses_input(self, sample_info):
        config = _generate_channel_config(sample_info)
        assert config["brand_identity"]["brand_voice"] == "Epic and cinematic"

    def test_budget_uses_input(self, sample_info):
        config = _generate_channel_config(sample_info)
        assert config["budget"]["monthly_limit_usd"] == 100.0
        assert config["budget"]["per_video_limit_usd"] == 5.0

    def test_config_validates_via_loader(self, sample_info, tmp_path):
        """Generated config should pass validation."""
        from ai_director.config_loader import load_channel_config

        config = _generate_channel_config(sample_info)
        p = tmp_path / "channel_config.json"
        p.write_text(json.dumps(config))
        loaded = load_channel_config(str(p))
        assert loaded.channel_name == "TestBrand"


class TestGenerateWorkflow:
    def test_contains_channel_name(self):
        wf = _generate_workflow("LostEras")
        assert 'channel_name: "LostEras"' in wf

    def test_contains_reusable_workflow_ref(self):
        wf = _generate_workflow("LostEras")
        assert "reusable-pipeline.yml" in wf


class TestGenerateRequirements:
    def test_pins_version(self):
        req = _generate_requirements()
        assert req.startswith("ai-director-core==")
        assert "\n" in req


class TestGenerateTopicsQueue:
    def test_has_sample_topic(self):
        q = _generate_topics_queue()
        assert len(q["topics"]) == 1
        assert q["topics"][0]["status"] == "pending"


class TestNonInteractiveMode:
    def test_collects_from_args(self):
        args = Namespace(
            name="MyBrand", niche="tech", voice="casual", audience="developers",
            platform="youtube_shorts", language="en", aspect_ratio="16:9",
            duration=90, budget_monthly=200.0, budget_per_video=10.0,
        )
        info = _collect_from_args(args)
        assert info["name"] == "MyBrand"
        assert info["aspect_ratio"] == "16:9"
        assert info["duration"] == 90

    def test_missing_required_field_exits(self):
        args = Namespace(name=None, niche="tech", voice="casual", audience="devs",
                         platform=None, language=None, aspect_ratio=None,
                         duration=None, budget_monthly=None, budget_per_video=None)
        with pytest.raises(SystemExit):
            _collect_from_args(args)


class TestRunScaffold:
    def test_generates_all_files(self, tmp_path):
        args = Namespace(
            non_interactive=True,
            output_dir=str(tmp_path),
            name="ScaffoldTest",
            niche="cooking",
            voice="Warm and friendly",
            audience="Home cooks 30-50",
            platform="youtube_shorts",
            language="en",
            aspect_ratio="9:16",
            duration=60,
            budget_monthly=100.0,
            budget_per_video=5.0,
        )
        run_scaffold(args)

        assert (tmp_path / "data" / "channel_config.json").exists()
        assert (tmp_path / ".github" / "workflows" / "pipeline.yml").exists()
        assert (tmp_path / "requirements.txt").exists()
        assert (tmp_path / "data" / "topics_queue.json").exists()

        # Verify config content
        config = json.loads((tmp_path / "data" / "channel_config.json").read_text())
        assert config["channel_name"] == "ScaffoldTest"
        assert config["brand_identity"]["brand_voice"] == "Warm and friendly"

    def test_invalid_aspect_ratio_exits(self, tmp_path):
        args = Namespace(
            non_interactive=True,
            output_dir=str(tmp_path),
            name="Bad",
            niche="x",
            voice="x",
            audience="x",
            platform="youtube_shorts",
            language="en",
            aspect_ratio="4:3",
            duration=60,
            budget_monthly=100.0,
            budget_per_video=5.0,
        )
        with pytest.raises(SystemExit):
            run_scaffold(args)

    def test_default_values(self, tmp_path):
        args = Namespace(
            non_interactive=True,
            output_dir=str(tmp_path),
            name="Defaults",
            niche="test",
            voice="neutral",
            audience="everyone",
            platform=None,
            language=None,
            aspect_ratio=None,
            duration=None,
            budget_monthly=None,
            budget_per_video=None,
        )
        run_scaffold(args)

        config = json.loads((tmp_path / "data" / "channel_config.json").read_text())
        assert config["aspect_ratio"] == "9:16"
        assert config["target_platform"] == "youtube_shorts"
        assert config["budget"]["monthly_limit_usd"] == 100.0
