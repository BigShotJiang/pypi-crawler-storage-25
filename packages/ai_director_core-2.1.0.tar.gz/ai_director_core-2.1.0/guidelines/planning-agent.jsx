import { useState, useEffect, useRef } from "react";

const STORAGE_KEYS = {
  projects: "agent:projects",
  logs: "agent:logs",
};

const DEFAULT_PROJECTS = [
  { id: "1", name: "AI Marketing Tool (Shopify)", priority: 1, category: "product", active: true, notes: "MVP hoàn chỉnh, cần tìm user đầu tiên" },
  { id: "2", name: "LostEras YouTube Channel", priority: 2, category: "content", active: true, notes: "Upload daily Shorts, 2-3 tuần, view còn thấp" },
  { id: "3", name: "Viral5 YouTube Channel", priority: 3, category: "content", active: true, notes: "Top 5 content, Gen Z audience" },
  { id: "4", name: "Học Tài Chính 180 ngày", priority: 4, category: "learning", active: true, notes: "Track trong Git repository" },
  { id: "5", name: "Học Tiếng Anh B2", priority: 5, category: "learning", active: true, notes: "Listening & speaking daily" },
  { id: "6", name: "Shopee Affiliate", priority: 6, category: "income", active: true, notes: "Passive track" },
];

const CATEGORY_COLORS = {
  product: "#f59e0b",
  content: "#6366f1",
  learning: "#10b981",
  income: "#ec4899",
};

const CATEGORY_LABELS = {
  product: "Product",
  content: "Content",
  learning: "Learning",
  income: "Income",
};

export default function PlanningAgent() {
  const [screen, setScreen] = useState("dashboard"); // dashboard | checkin | history | projects
  const [projects, setProjects] = useState([]);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [checkin, setCheckin] = useState({ energy: 3, time: 90, notes: "" });
  const [recommendation, setRecommendation] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [newProject, setNewProject] = useState(null);
  const [todayLogged, setTodayLogged] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [pRes, lRes] = await Promise.all([
        window.storage.get(STORAGE_KEYS.projects),
        window.storage.get(STORAGE_KEYS.logs),
      ]);
      const loadedProjects = pRes ? JSON.parse(pRes.value) : DEFAULT_PROJECTS;
      const loadedLogs = lRes ? JSON.parse(lRes.value) : [];
      setProjects(loadedProjects);
      setLogs(loadedLogs);

      const today = new Date().toDateString();
      const alreadyLogged = loadedLogs.some(l => new Date(l.date).toDateString() === today);
      setTodayLogged(alreadyLogged);
      if (alreadyLogged) {
        const todayLog = loadedLogs.find(l => new Date(l.date).toDateString() === today);
        setRecommendation(todayLog.recommendation);
      }
    } catch (e) {
      setProjects(DEFAULT_PROJECTS);
    }
    setLoading(false);
  }

  async function saveProjects(updated) {
    setProjects(updated);
    await window.storage.set(STORAGE_KEYS.projects, JSON.stringify(updated));
  }

  async function saveLogs(updated) {
    setLogs(updated);
    await window.storage.set(STORAGE_KEYS.logs, JSON.stringify(updated));
  }

  async function runCheckin() {
    setAiLoading(true);
    setScreen("checkin-result");

    const activeProjects = projects.filter(p => p.active);
    const recentLogs = logs.slice(-7);

    const systemPrompt = `Bạn là planning agent cá nhân của Robert - một backend/AI developer người Việt Nam, 12 năm kinh nghiệm, đang nuôi 2 con một mình, làm việc sau 10 giờ đêm với năng lượng có hạn.

Robert đang chạy song song nhiều dự án và cần bạn giúp quyết định TỐI NAY nên làm gì — cụ thể, thực tế, không nói chung chung.

Nguyên tắc:
- Ưu tiên AI Marketing Tool vì đây là sản phẩm gần với doanh thu nhất
- Respect thời gian và năng lượng thực tế của Robert
- Đừng motivate, đừng coach — chỉ cần recommend rõ ràng
- Output: 1 main task + lý do ngắn gọn + 1 optional task nếu còn sức

Trả lời bằng tiếng Việt, ngắn gọn, thực tế.`;

    const userMessage = `Check-in tối nay:
- Năng lượng: ${checkin.energy}/5
- Thời gian có: ${checkin.time} phút
- Ghi chú: ${checkin.notes || "không có"}

Projects đang active:
${activeProjects.map((p, i) => `${i + 1}. [${p.category}] ${p.name} (priority: ${p.priority}) — ${p.notes}`).join("\n")}

${recentLogs.length > 0 ? `7 ngày gần nhất:\n${recentLogs.map(l => `- ${new Date(l.date).toLocaleDateString("vi-VN")}: ${l.mainTask}`).join("\n")}` : "Chưa có lịch sử."}

Recommend tối nay làm gì?`;

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: systemPrompt,
          messages: [{ role: "user", content: userMessage }],
        }),
      });

      const data = await response.json();
      const text = data.content?.find(b => b.type === "text")?.text || "Không thể tạo recommendation.";

      const rec = {
        text,
        energy: checkin.energy,
        time: checkin.time,
        notes: checkin.notes,
        mainTask: extractMainTask(text),
      };

      setRecommendation(rec);

      // Save to log
      const today = new Date().toDateString();
      const existingIdx = logs.findIndex(l => new Date(l.date).toDateString() === today);
      const newLog = { date: new Date().toISOString(), ...rec };
      const updatedLogs = existingIdx >= 0
        ? logs.map((l, i) => i === existingIdx ? newLog : l)
        : [...logs, newLog];
      await saveLogs(updatedLogs);
      setTodayLogged(true);
    } catch (e) {
      setRecommendation({ text: "Lỗi kết nối API. Kiểm tra lại.", mainTask: "-" });
    }
    setAiLoading(false);
  }

  function extractMainTask(text) {
    const lines = text.split("\n").filter(l => l.trim());
    return lines[0]?.replace(/^[#*\-•]+\s*/, "").substring(0, 60) || "Xem chi tiết";
  }

  function getHour() {
    return new Date().getHours();
  }

  function getGreeting() {
    const h = getHour();
    if (h >= 22 || h < 2) return "Đêm muộn rồi";
    if (h >= 20) return "Tối nay";
    return "Chào";
  }

  if (loading) {
    return (
      <div style={styles.loadingScreen}>
        <div style={styles.loadingDot} />
      </div>
    );
  }

  return (
    <div style={styles.app}>
      <div style={styles.grain} />

      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <span style={styles.logo}>◈</span>
          <span style={styles.logoText}>AGENT</span>
        </div>
        <nav style={styles.nav}>
          {["dashboard", "history", "projects"].map(s => (
            <button key={s} onClick={() => setScreen(s)} style={{
              ...styles.navBtn,
              ...(screen === s || (screen === "checkin-result" && s === "dashboard") ? styles.navBtnActive : {})
            }}>
              {s === "dashboard" ? "Hôm nay" : s === "history" ? "Lịch sử" : "Dự án"}
            </button>
          ))}
        </nav>
      </header>

      <main style={styles.main}>
        {/* DASHBOARD */}
        {(screen === "dashboard") && (
          <div style={styles.page}>
            <div style={styles.greeting}>
              <span style={styles.greetingTime}>{getGreeting()}</span>
              <h1 style={styles.greetingName}>Robert</h1>
            </div>

            {todayLogged && recommendation ? (
              <div style={styles.todayCard}>
                <div style={styles.todayBadge}>✓ Đã check-in hôm nay</div>
                <div style={styles.recBox}>
                  <div style={styles.recLabel}>Recommendation</div>
                  <div style={styles.recText}>{recommendation.text}</div>
                </div>
                <button onClick={() => { setTodayLogged(false); setCheckin({ energy: 3, time: 90, notes: "" }); setScreen("checkin"); }} style={styles.rerunBtn}>
                  Cập nhật check-in
                </button>
              </div>
            ) : (
              <div style={styles.checkinPrompt}>
                <div style={styles.promptIcon}>◎</div>
                <p style={styles.promptText}>Chưa có plan cho tối nay.</p>
                <button onClick={() => setScreen("checkin")} style={styles.primaryBtn}>
                  Bắt đầu check-in →
                </button>
              </div>
            )}

            {/* Projects overview */}
            <div style={styles.section}>
              <div style={styles.sectionLabel}>Dự án đang chạy</div>
              <div style={styles.projectGrid}>
                {projects.filter(p => p.active).sort((a, b) => a.priority - b.priority).map(p => (
                  <div key={p.id} style={styles.projectChip}>
                    <span style={{ ...styles.chipDot, background: CATEGORY_COLORS[p.category] }} />
                    <span style={styles.chipName}>{p.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* CHECK-IN FORM */}
        {screen === "checkin" && (
          <div style={styles.page}>
            <button onClick={() => setScreen("dashboard")} style={styles.backBtn}>← Quay lại</button>
            <h2 style={styles.pageTitle}>Check-in tối nay</h2>

            <div style={styles.formCard}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Năng lượng hiện tại</label>
                <div style={styles.energyRow}>
                  {[1, 2, 3, 4, 5].map(n => (
                    <button key={n} onClick={() => setCheckin(c => ({ ...c, energy: n }))} style={{
                      ...styles.energyBtn,
                      ...(checkin.energy === n ? styles.energyBtnActive : {})
                    }}>
                      {n === 1 ? "😮‍💨" : n === 2 ? "😐" : n === 3 ? "🙂" : n === 4 ? "⚡" : "🔥"}
                    </button>
                  ))}
                </div>
                <div style={styles.energyLabel}>
                  {["", "Kiệt sức", "Mệt", "Ổn", "Tốt", "Rất tốt"][checkin.energy]}
                </div>
              </div>

              <div style={styles.formGroup}>
                <label style={styles.label}>Thời gian có thể làm (phút)</label>
                <div style={styles.timeRow}>
                  {[30, 60, 90, 120].map(t => (
                    <button key={t} onClick={() => setCheckin(c => ({ ...c, time: t }))} style={{
                      ...styles.timeBtn,
                      ...(checkin.time === t ? styles.timeBtnActive : {})
                    }}>
                      {t}p
                    </button>
                  ))}
                </div>
              </div>

              <div style={styles.formGroup}>
                <label style={styles.label}>Ghi chú thêm (tuỳ chọn)</label>
                <textarea
                  value={checkin.notes}
                  onChange={e => setCheckin(c => ({ ...c, notes: e.target.value }))}
                  placeholder="Hôm nay có gì đặc biệt không? Deadline, ưu tiên đột xuất..."
                  style={styles.textarea}
                  rows={3}
                />
              </div>

              <button onClick={runCheckin} style={styles.primaryBtn}>
                Phân tích & Recommend →
              </button>
            </div>
          </div>
        )}

        {/* CHECK-IN RESULT */}
        {screen === "checkin-result" && (
          <div style={styles.page}>
            <h2 style={styles.pageTitle}>Plan tối nay</h2>
            {aiLoading ? (
              <div style={styles.aiLoading}>
                <div style={styles.aiDots}>
                  <span style={{ ...styles.dot, animationDelay: "0s" }} />
                  <span style={{ ...styles.dot, animationDelay: "0.2s" }} />
                  <span style={{ ...styles.dot, animationDelay: "0.4s" }} />
                </div>
                <div style={styles.aiLoadingText}>Đang phân tích...</div>
              </div>
            ) : recommendation ? (
              <div>
                <div style={styles.metaRow}>
                  <span style={styles.metaChip}>⚡ {["", "Kiệt sức", "Mệt", "Ổn", "Tốt", "Rất tốt"][recommendation.energy]}</span>
                  <span style={styles.metaChip}>⏱ {recommendation.time} phút</span>
                </div>
                <div style={styles.recCard}>
                  <div style={styles.recCardLabel}>Recommendation</div>
                  <div style={styles.recCardText}>{recommendation.text}</div>
                </div>
                <button onClick={() => setScreen("dashboard")} style={styles.secondaryBtn}>
                  Về Dashboard
                </button>
              </div>
            ) : null}
          </div>
        )}

        {/* HISTORY */}
        {screen === "history" && (
          <div style={styles.page}>
            <h2 style={styles.pageTitle}>Lịch sử</h2>
            {logs.length === 0 ? (
              <div style={styles.emptyState}>Chưa có check-in nào.</div>
            ) : (
              <div style={styles.logList}>
                {[...logs].reverse().map((log, i) => (
                  <div key={i} style={styles.logItem}>
                    <div style={styles.logDate}>
                      {new Date(log.date).toLocaleDateString("vi-VN", { weekday: "short", day: "numeric", month: "numeric" })}
                    </div>
                    <div style={styles.logMeta}>
                      <span style={styles.metaChip}>⚡ {["", "Kiệt sức", "Mệt", "Ổn", "Tốt", "Rất tốt"][log.energy]}</span>
                      <span style={styles.metaChip}>⏱ {log.time}p</span>
                    </div>
                    <div style={styles.logRec}>{log.text}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* PROJECTS */}
        {screen === "projects" && (
          <div style={styles.page}>
            <div style={styles.pageTitleRow}>
              <h2 style={styles.pageTitle}>Dự án</h2>
              <button onClick={() => setNewProject({ name: "", category: "product", priority: projects.length + 1, notes: "", active: true })} style={styles.addBtn}>
                + Thêm
              </button>
            </div>

            {newProject && (
              <div style={styles.newProjectCard}>
                <input
                  placeholder="Tên dự án"
                  value={newProject.name}
                  onChange={e => setNewProject(p => ({ ...p, name: e.target.value }))}
                  style={styles.input}
                />
                <select value={newProject.category} onChange={e => setNewProject(p => ({ ...p, category: e.target.value }))} style={styles.select}>
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
                <input
                  placeholder="Ghi chú ngắn"
                  value={newProject.notes}
                  onChange={e => setNewProject(p => ({ ...p, notes: e.target.value }))}
                  style={styles.input}
                />
                <div style={styles.newProjectBtns}>
                  <button onClick={async () => {
                    if (!newProject.name.trim()) return;
                    const updated = [...projects, { ...newProject, id: Date.now().toString() }];
                    await saveProjects(updated);
                    setNewProject(null);
                  }} style={styles.primaryBtn}>Lưu</button>
                  <button onClick={() => setNewProject(null)} style={styles.secondaryBtn}>Huỷ</button>
                </div>
              </div>
            )}

            <div style={styles.fullProjectList}>
              {[...projects].sort((a, b) => a.priority - b.priority).map(p => (
                <div key={p.id} style={{ ...styles.fullProjectItem, opacity: p.active ? 1 : 0.4 }}>
                  <div style={styles.fullProjectLeft}>
                    <span style={{ ...styles.catDot, background: CATEGORY_COLORS[p.category] }} />
                    <div>
                      <div style={styles.fullProjectName}>{p.name}</div>
                      <div style={styles.fullProjectNote}>{p.notes}</div>
                    </div>
                  </div>
                  <button onClick={async () => {
                    const updated = projects.map(proj => proj.id === p.id ? { ...proj, active: !proj.active } : proj);
                    await saveProjects(updated);
                  }} style={{ ...styles.toggleBtn, background: p.active ? "#10b98122" : "#ffffff11", color: p.active ? "#10b981" : "#666" }}>
                    {p.active ? "Active" : "Paused"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300&family=DM+Sans:wght@300;400;500&display=swap');
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }
        @keyframes dotBounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
      `}</style>
    </div>
  );
}

const styles = {
  app: {
    minHeight: "100vh",
    background: "#0a0a0f",
    color: "#e8e6e0",
    fontFamily: "'DM Sans', sans-serif",
    position: "relative",
    overflow: "hidden",
  },
  grain: {
    position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
    backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E\")",
    opacity: 0.4,
  },
  loadingScreen: {
    minHeight: "100vh", background: "#0a0a0f",
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  loadingDot: {
    width: 8, height: 8, borderRadius: "50%", background: "#f59e0b",
    animation: "pulse 1.2s ease infinite",
  },
  header: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "20px 24px 16px",
    borderBottom: "1px solid #ffffff0a",
    position: "relative", zIndex: 1,
  },
  headerLeft: { display: "flex", alignItems: "center", gap: 8 },
  logo: { color: "#f59e0b", fontSize: 18 },
  logoText: {
    fontFamily: "'DM Mono', monospace", fontSize: 11, letterSpacing: 4,
    color: "#ffffff55", fontWeight: 400,
  },
  nav: { display: "flex", gap: 4 },
  navBtn: {
    background: "none", border: "none", cursor: "pointer",
    fontFamily: "'DM Mono', monospace", fontSize: 11, letterSpacing: 1,
    color: "#ffffff33", padding: "6px 12px", borderRadius: 6,
    transition: "all 0.15s",
  },
  navBtnActive: { color: "#e8e6e0", background: "#ffffff0a" },
  main: { position: "relative", zIndex: 1 },
  page: { padding: "32px 24px 60px", maxWidth: 600, margin: "0 auto", animation: "fadeIn 0.25s ease" },
  greeting: { marginBottom: 32 },
  greetingTime: { fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#ffffff33", letterSpacing: 2 },
  greetingName: { fontSize: 36, fontWeight: 300, margin: "4px 0 0", letterSpacing: -1, color: "#e8e6e0" },
  checkinPrompt: {
    background: "#ffffff06", border: "1px solid #ffffff0a", borderRadius: 16,
    padding: "48px 32px", textAlign: "center", marginBottom: 32,
  },
  promptIcon: { fontSize: 32, marginBottom: 16, color: "#f59e0b55" },
  promptText: { color: "#ffffff44", margin: "0 0 24px", fontFamily: "'DM Mono', monospace", fontSize: 13 },
  primaryBtn: {
    background: "#f59e0b", color: "#0a0a0f", border: "none", cursor: "pointer",
    padding: "12px 24px", borderRadius: 8, fontFamily: "'DM Mono', monospace",
    fontSize: 13, fontWeight: 500, letterSpacing: 0.5, transition: "opacity 0.15s",
    width: "100%",
  },
  secondaryBtn: {
    background: "#ffffff0a", color: "#ffffff66", border: "none", cursor: "pointer",
    padding: "12px 24px", borderRadius: 8, fontFamily: "'DM Mono', monospace",
    fontSize: 13, marginTop: 12, width: "100%", transition: "background 0.15s",
  },
  rerunBtn: {
    background: "none", color: "#ffffff33", border: "1px solid #ffffff0a",
    cursor: "pointer", padding: "8px 16px", borderRadius: 6,
    fontFamily: "'DM Mono', monospace", fontSize: 11, marginTop: 16, letterSpacing: 0.5,
  },
  todayCard: {
    background: "#ffffff06", border: "1px solid #10b98122", borderRadius: 16,
    padding: "24px", marginBottom: 32,
  },
  todayBadge: {
    fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#10b981",
    letterSpacing: 2, marginBottom: 16,
  },
  recBox: {},
  recLabel: { fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#ffffff33", letterSpacing: 2, marginBottom: 8 },
  recText: { color: "#e8e6e0", lineHeight: 1.7, fontSize: 14, whiteSpace: "pre-wrap" },
  section: { marginTop: 8 },
  sectionLabel: { fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#ffffff22", letterSpacing: 2, marginBottom: 12 },
  projectGrid: { display: "flex", flexWrap: "wrap", gap: 8 },
  projectChip: {
    display: "flex", alignItems: "center", gap: 6,
    background: "#ffffff06", border: "1px solid #ffffff08",
    borderRadius: 20, padding: "5px 12px",
  },
  chipDot: { width: 6, height: 6, borderRadius: "50%", flexShrink: 0 },
  chipName: { fontSize: 12, color: "#ffffff88" },
  backBtn: {
    background: "none", border: "none", cursor: "pointer",
    fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#ffffff33",
    padding: 0, marginBottom: 24, letterSpacing: 0.5,
  },
  pageTitle: { fontSize: 24, fontWeight: 300, margin: "0 0 24px", letterSpacing: -0.5 },
  pageTitleRow: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 },
  formCard: { background: "#ffffff06", border: "1px solid #ffffff08", borderRadius: 16, padding: 24 },
  formGroup: { marginBottom: 28 },
  label: { fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#ffffff44", letterSpacing: 2, display: "block", marginBottom: 12 },
  energyRow: { display: "flex", gap: 8 },
  energyBtn: {
    flex: 1, padding: "10px 4px", background: "#ffffff06", border: "1px solid #ffffff08",
    borderRadius: 8, cursor: "pointer", fontSize: 20, transition: "all 0.15s",
  },
  energyBtnActive: { background: "#f59e0b22", border: "1px solid #f59e0b66" },
  energyLabel: { fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#f59e0b", marginTop: 8, textAlign: "center" },
  timeRow: { display: "flex", gap: 8 },
  timeBtn: {
    flex: 1, padding: "10px", background: "#ffffff06", border: "1px solid #ffffff08",
    borderRadius: 8, cursor: "pointer", fontFamily: "'DM Mono', monospace",
    fontSize: 13, color: "#ffffff66", transition: "all 0.15s",
  },
  timeBtnActive: { background: "#f59e0b22", border: "1px solid #f59e0b66", color: "#f59e0b" },
  textarea: {
    width: "100%", background: "#ffffff06", border: "1px solid #ffffff08",
    borderRadius: 8, padding: "10px 12px", color: "#e8e6e0",
    fontFamily: "'DM Sans', sans-serif", fontSize: 13, resize: "vertical",
    boxSizing: "border-box", lineHeight: 1.6,
  },
  aiLoading: { display: "flex", flexDirection: "column", alignItems: "center", padding: "60px 0", gap: 16 },
  aiDots: { display: "flex", gap: 8 },
  dot: {
    width: 8, height: 8, borderRadius: "50%", background: "#f59e0b",
    display: "inline-block", animation: "dotBounce 0.8s ease infinite",
  },
  aiLoadingText: { fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#ffffff33", letterSpacing: 2 },
  metaRow: { display: "flex", gap: 8, marginBottom: 16 },
  metaChip: {
    fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#ffffff55",
    background: "#ffffff08", padding: "4px 10px", borderRadius: 20,
  },
  recCard: {
    background: "#ffffff06", border: "1px solid #f59e0b22", borderRadius: 16,
    padding: 24, marginBottom: 4,
  },
  recCardLabel: { fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#f59e0b88", letterSpacing: 2, marginBottom: 12 },
  recCardText: { color: "#e8e6e0", lineHeight: 1.8, fontSize: 14, whiteSpace: "pre-wrap" },
  emptyState: { fontFamily: "'DM Mono', monospace", fontSize: 12, color: "#ffffff22", textAlign: "center", padding: "60px 0" },
  logList: { display: "flex", flexDirection: "column", gap: 16 },
  logItem: { background: "#ffffff06", border: "1px solid #ffffff08", borderRadius: 12, padding: 20 },
  logDate: { fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#f59e0b88", marginBottom: 8, letterSpacing: 1 },
  logMeta: { display: "flex", gap: 6, marginBottom: 12 },
  logRec: { color: "#ffffff77", fontSize: 13, lineHeight: 1.7, whiteSpace: "pre-wrap" },
  addBtn: {
    background: "#ffffff08", border: "1px solid #ffffff10", borderRadius: 6,
    color: "#ffffff55", cursor: "pointer", fontFamily: "'DM Mono', monospace",
    fontSize: 11, padding: "6px 12px",
  },
  newProjectCard: { background: "#ffffff06", border: "1px dashed #ffffff15", borderRadius: 12, padding: 20, marginBottom: 16, display: "flex", flexDirection: "column", gap: 10 },
  input: {
    background: "#ffffff06", border: "1px solid #ffffff10", borderRadius: 8,
    padding: "10px 12px", color: "#e8e6e0", fontFamily: "'DM Sans', sans-serif",
    fontSize: 13, width: "100%", boxSizing: "border-box",
  },
  select: {
    background: "#0a0a0f", border: "1px solid #ffffff10", borderRadius: 8,
    padding: "10px 12px", color: "#ffffff77", fontFamily: "'DM Mono', monospace",
    fontSize: 12, width: "100%",
  },
  newProjectBtns: { display: "flex", gap: 8, marginTop: 4 },
  fullProjectList: { display: "flex", flexDirection: "column", gap: 10 },
  fullProjectItem: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    background: "#ffffff06", border: "1px solid #ffffff08", borderRadius: 12, padding: "14px 16px",
    transition: "opacity 0.2s",
  },
  fullProjectLeft: { display: "flex", alignItems: "flex-start", gap: 12 },
  catDot: { width: 8, height: 8, borderRadius: "50%", flexShrink: 0, marginTop: 5 },
  fullProjectName: { fontSize: 14, color: "#e8e6e0", marginBottom: 2 },
  fullProjectNote: { fontSize: 11, color: "#ffffff33", fontFamily: "'DM Mono', monospace" },
  toggleBtn: {
    border: "none", cursor: "pointer", borderRadius: 20,
    padding: "4px 12px", fontFamily: "'DM Mono', monospace", fontSize: 10,
    letterSpacing: 0.5, flexShrink: 0,
  },
};
