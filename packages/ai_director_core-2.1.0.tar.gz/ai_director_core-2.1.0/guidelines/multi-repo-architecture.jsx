import { useState } from "react";

const sections = [
  { id: "architecture", label: "Architecture Overview" },
  { id: "core-lib", label: "Core Library Structure" },
  { id: "channel-config", label: "Channel Config Schema" },
  { id: "reusable-workflow", label: "Reusable Workflow" },
  { id: "channel-repo", label: "Channel Repo (Minimal)" },
  { id: "new-channel", label: "Tạo kênh mới" },
  { id: "versioning", label: "Versioning Strategy" },
];

const content = {
  "architecture": {
    description: "Hai tầng rõ ràng: Core Library (framework) và Channel Repos (configuration). Mọi intelligence nằm ở Core. Channel repo chỉ là data.",
    code: `# ══════════════════════════════════════════════════════════════
#  TẦNG 1: CORE LIBRARY — ai-director-core (1 repo duy nhất)
# ══════════════════════════════════════════════════════════════
#
#  ai-director-core/
#  ├── ai_director/              # Python package — installable via pip
#  │   ├── agents/               # 5 agents, hoàn toàn config-driven
#  │   ├── lib/                  # Claude, Pexels, Flux clients
#  │   ├── motion_map.py         # Rule-based motion decisions
#  │   ├── validator.py          # Schema + constitution validation
#  │   └── runner.py             # CLI: ai-director run --config ...
#  ├── .github/workflows/
#  │   └── reusable-pipeline.yml # Reusable workflow — channels gọi vào đây
#  ├── pyproject.toml            # Package metadata + versioning
#  └── CHANGELOG.md              # Ghi rõ mỗi version thay đổi gì
#
# ══════════════════════════════════════════════════════════════
#  TẦNG 2: CHANNEL REPOS — mỗi kênh là 1 repo riêng
# ══════════════════════════════════════════════════════════════
#
#  losters-channel/              dustcraft-channel/
#  ├── .github/workflows/        ├── .github/workflows/
#  │   └── pipeline.yml          │   └── pipeline.yml
#  │       uses: core@v1.2       │       uses: core@v1.2
#  ├── data/                     ├── data/
#  │   ├── channel_config.json   │   ├── channel_config.json
#  │   └── topics_queue.json     │   └── topics_queue.json
#  └── requirements.txt          └── requirements.txt
#      ai-director-core==1.2.0       ai-director-core==1.2.0
#
# ══════════════════════════════════════════════════════════════
#  DATA FLOW
# ══════════════════════════════════════════════════════════════
#
#  channel_config.json  ──►  Core Agents  ──►  video_package.json
#  topics_queue.json    ──►  (ai-director-core)
#
#  Core agents không biết họ đang phục vụ kênh nào.
#  Họ chỉ đọc channel_config.json và execute.
#  Đây là separation of concerns hoàn hảo.
#
# ══════════════════════════════════════════════════════════════
#  KHI CẦN THÊM KÊNH MỚI
# ══════════════════════════════════════════════════════════════
#
#  1. Tạo repo mới (GitHub "Use this template" từ channel-template)
#  2. Viết channel_config.json cho niche mới (~30 phút)
#  3. Thêm topics vào topics_queue.json
#  4. Push → Pipeline tự chạy lúc 11pm
#
#  Không cần viết code. Không cần sửa core. Zero configuration drift.`
  },

  "core-lib": {
    description: "Cấu trúc Python package của ai-director-core. Package này được publish lên GitHub Packages hoặc PyPI private, và mọi channel repo install nó như một dependency bình thường.",
    code: `# ai-director-core/pyproject.toml
# Đây là cách package được define và version

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "ai-director-core"
version = "1.2.0"   # ← Bump version này mỗi khi release
description = "AI Director core engine for automated video production"
requires-python = ">=3.11"
dependencies = [
    "anthropic>=0.40.0",
    "requests>=2.31.0",
    "tenacity>=8.2.0",     # Auto-retry cho API calls
    "pillow>=10.0.0",       # Image processing
    "pydantic>=2.0.0",      # Schema validation cho channel_config
]

[project.scripts]
ai-director = "ai_director.runner:main"   # CLI entry point

# ──────────────────────────────────────────────────────────────
# ai_director/runner.py
# CLI interface — đây là gì GitHub Actions gọi trong mỗi job

import argparse, json, sys
from pathlib import Path
from .config_loader import load_channel_config, validate_config
from .agents import ScriptWriter, ShotListDirector, AssetResolver, MotionDirector, QAValidator

def main():
    parser = argparse.ArgumentParser(prog="ai-director")
    subparsers = parser.add_subparsers(dest="command")

    # Command: run toàn bộ pipeline
    run_parser = subparsers.add_parser("run")
    run_parser.add_argument("--config", required=True, help="Path to channel_config.json")
    run_parser.add_argument("--topic", required=True, help="Topic title to process")
    run_parser.add_argument("--topic-id", required=True)
    run_parser.add_argument("--output-dir", default="outputs/")

    # Command: validate config trước khi chạy
    validate_parser = subparsers.add_parser("validate")
    validate_parser.add_argument("--config", required=True)

    # Command: chạy từng agent riêng lẻ (dùng khi debug)
    agent_parser = subparsers.add_parser("agent")
    agent_parser.add_argument("--name", choices=["script", "shots", "assets", "motion", "qa"])
    agent_parser.add_argument("--config", required=True)
    agent_parser.add_argument("--input", required=True)
    agent_parser.add_argument("--output", required=True)

    args = parser.parse_args()
    config = load_channel_config(args.config)

    if args.command == "validate":
        errors = validate_config(config)
        if errors:
            print("❌ Config validation failed:")
            for e in errors: print(f"  - {e}")
            sys.exit(1)
        print("✅ Config valid")

    elif args.command == "run":
        # Chạy toàn bộ pipeline, trả về path đến final package
        from .pipeline import run_full_pipeline
        result = run_full_pipeline(config, args.topic, args.topic_id, args.output_dir)
        sys.exit(0 if result["status"] == "ready" else 1)

    elif args.command == "agent":
        # Chạy từng agent riêng — hữu ích khi test/debug
        from .agent_runner import run_single_agent
        run_single_agent(args.name, config, args.input, args.output)

# ──────────────────────────────────────────────────────────────
# ai_director/config_loader.py
# Load và validate channel_config.json
# Dùng Pydantic để đảm bảo schema đúng trước khi chạy pipeline

from pydantic import BaseModel, Field, validator
from typing import Literal

class NarrativeConfig(BaseModel):
    tone: str
    pacing_wps: float = Field(ge=2.0, le=5.0)
    max_words_per_60s: int = Field(ge=30, le=80)
    hook_formula: str
    structure: list[str]

class VisualConfig(BaseModel):
    color_palette: list[str]
    shot_ratio: dict[str, float]
    forbidden_visuals: list[str]
    historical_accuracy_window_years: int = 0  # 0 = không áp dụng

class MotionConfig(BaseModel):
    default_style: str
    allowed_motions: list[str]
    forbidden_motions: list[str]
    min_scene_duration_s: int = Field(ge=3, le=20)
    max_scene_duration_s: int = Field(ge=5, le=30)

class ChannelConfig(BaseModel):
    """
    Schema hoàn chỉnh của channel_config.json.
    Pydantic tự validate khi load — fail early nếu config thiếu field quan trọng.
    """
    channel_name: str
    channel_niche: str
    target_platform: Literal["youtube_shorts", "tiktok", "instagram_reels"]
    target_audience: str
    language: str = "en"
    
    narrative: NarrativeConfig
    visual: VisualConfig
    motion: MotionConfig
    
    asset_sources_priority: list[Literal["library_cache", "pexels_search", "ai_generate_flux", "pixabay"]]
    confidence_thresholds: dict[str, float]
    
    # Platform-specific overrides
    video_duration_s: int = 60
    aspect_ratio: Literal["9:16", "16:9", "1:1"] = "9:16"

def load_channel_config(path: str) -> ChannelConfig:
    with open(path) as f:
        data = json.load(f)
    return ChannelConfig(**data)   # Pydantic validate ngay tại đây`
  },

  "channel-config": {
    description: "Đây là file duy nhất mỗi kênh cần customize. Toàn bộ personality và style của một kênh được encode trong đây. Khi bạn muốn tạo kênh mới, bạn chỉ cần viết file này.",
    code: `// data/channel_config.json — ví dụ cho LostEras
// Đây là "DNA" của kênh, không phải code

{
  "channel_name": "LostEras",
  "channel_niche": "historical storytelling shorts — counter-intuitive facts about ancient civilizations",
  "target_platform": "youtube_shorts",
  "target_audience": "History enthusiasts 25–45, US/UK market, interested in Roman/Greek/Medieval content",
  "language": "en",
  "video_duration_s": 60,
  "aspect_ratio": "9:16",

  "narrative": {
    "tone": "Epic, contemplative, third-person omniscient narrator — like a documentary but faster",
    "pacing_wps": 3.5,
    "max_words_per_60s": 55,
    "hook_formula": "Open with counter-intuitive fact OR a death/betrayal moment — never chronological",
    "structure": ["hook_0_8s", "context_8_25s", "climax_25_50s", "payoff_50_60s"]
  },

  "visual": {
    "color_palette": ["dark amber #C9A84C", "deep crimson #8B1A1A", "aged parchment #F5E6C8"],
    "shot_ratio": {
      "wide_establishing": 0.60,
      "medium": 0.25,
      "close_detail": 0.15
    },
    "forbidden_visuals": ["modern buildings", "cars", "smartphones", "bright neon colors"],
    "historical_accuracy_window_years": 50,
    "reference_aesthetic": "similar to History Channel documentaries, BBC historical dramas"
  },

  "motion": {
    "default_style": "slow_cinematic",
    "allowed_motions": ["slow_pan_left", "slow_pan_right", "slow_zoom_in", "slow_zoom_out"],
    "forbidden_motions": ["shake", "random_zoom", "fast_cuts_under_2s"],
    "min_scene_duration_s": 6,
    "max_scene_duration_s": 12
  },

  "typography": {
    "font": "IM Fell English",
    "color": "#C9A84C",
    "text_appear_delay_s": 0.5,
    "position": "bottom_third",
    "max_chars_per_line": 42
  },

  "asset_sources_priority": ["library_cache", "pexels_search", "ai_generate_flux"],
  
  "confidence_thresholds": {
    "auto_proceed": 0.85,
    "flag_review": 0.60,
    "stop_human": 0.59
  }
}

// ──────────────────────────────────────────────────────────────
// So sánh: channel_config.json cho một kênh hoàn toàn khác
// Ví dụ: "QuietMind" — meditation & mindfulness shorts
// Cùng core engine, hoàn toàn khác personality
// ──────────────────────────────────────────────────────────────

{
  "channel_name": "QuietMind",
  "channel_niche": "mindfulness and meditation techniques for busy professionals",
  "target_platform": "instagram_reels",
  "target_audience": "Stressed professionals 28–40, US market, looking for 60s mental reset",
  "language": "en",

  "narrative": {
    "tone": "Calm, second-person, direct instructions — no drama, no history",
    "pacing_wps": 2.5,
    "max_words_per_60s": 40,
    "hook_formula": "Start with a relatable stress scenario, then offer immediate relief",
    "structure": ["problem_0_10s", "technique_10_45s", "outcome_45_60s"]
  },

  "visual": {
    "color_palette": ["soft sage #87A878", "warm white #F8F4EE", "muted blue #7BA7BC"],
    "shot_ratio": {
      "wide_establishing": 0.30,
      "medium": 0.40,
      "close_detail": 0.30
    },
    "forbidden_visuals": ["crowds", "screens", "city traffic", "harsh lighting"],
    "historical_accuracy_window_years": 0
  },

  "motion": {
    "default_style": "ultra_slow_breathe",
    "allowed_motions": ["ultra_slow_zoom_in", "slow_pan_right", "parallax_depth"],
    "forbidden_motions": ["shake", "fast_cuts_under_4s", "zoom_out_aggressive"],
    "min_scene_duration_s": 8,
    "max_scene_duration_s": 15
  }

  // ... same structure, completely different content strategy
}

// Key insight: Core engine đọc channel_config và tự adapt.
// Không có hardcode nào cho LostEras hay QuietMind trong core code.`
  },

  "reusable-workflow": {
    description: "Đây là workflow được define ở ai-director-core và được gọi bởi tất cả channel repos. Khi bạn update workflow này, tất cả channels nhận update ngay sau khi họ bump version.",
    code: `# ai-director-core/.github/workflows/reusable-pipeline.yml
# Workflow này KHÔNG chạy trực tiếp — nó chỉ được gọi bởi channel repos
# Đây là "framework workflow" — channels cung cấp data, core cung cấp logic

name: "AI Director Core Pipeline"

on:
  workflow_call:   # ← Keyword quan trọng: đây là reusable workflow
    inputs:
      topic:
        required: true
        type: string
      topic_id:
        required: true
        type: string
      config_path:
        required: false
        type: string
        default: "data/channel_config.json"   # Convention mặc định
      queue_path:
        required: false
        type: string
        default: "data/topics_queue.json"
      core_version:
        required: false
        type: string
        default: "latest"
    secrets:
      ANTHROPIC_API_KEY:
        required: true
      PEXELS_API_KEY:
        required: true
      REPLICATE_API_KEY:
        required: false   # Optional — chỉ cần nếu channel dùng AI generation
      GCP_SA_KEY:
        required: true
      TELEGRAM_BOT_TOKEN:
        required: false
      TELEGRAM_CHAT_ID:
        required: false
    outputs:
      package_path:
        description: "GCP path đến video package đã render xong"
        value: ${{ jobs.qa-validator.outputs.package_path }}
      status:
        description: "ready | qa_failed | blocked"
        value: ${{ jobs.qa-validator.outputs.status }}

jobs:
  script-writer:
    name: "✍️ Script Writer"
    runs-on: ubuntu-latest
    outputs:
      artifact_name: ${{ steps.write.outputs.artifact_name }}
    steps:
      - uses: actions/checkout@v4   # Checkout channel repo (có channel_config.json)
      
      - name: Install ai-director-core
        run: |
          # Install exact version được pin trong channel's requirements.txt
          pip install -r requirements.txt
          # Hoặc install trực tiếp nếu không có requirements.txt
          # pip install "ai-director-core==${{ inputs.core_version }}"
      
      - name: Run Script Writer agent
        id: write
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: |
          # Gọi CLI của core package — channel không cần biết implementation
          ai-director agent \
            --name script \
            --config ${{ inputs.config_path }} \
            --input '{"topic": "${{ inputs.topic }}", "topic_id": "${{ inputs.topic_id }}"}' \
            --output outputs/script.json
          echo "artifact_name=script-${{ inputs.topic_id }}" >> $GITHUB_OUTPUT
      
      - uses: actions/upload-artifact@v4
        with:
          name: script-${{ inputs.topic_id }}
          path: outputs/script.json

  # ... (shot-list-director, asset-resolver, motion-director jobs)
  # Structure giống hệt như trước, nhưng thay vì gọi python3 agents/...
  # Tất cả đều gọi: ai-director agent --name [agent_name] --config ...

  qa-validator:
    name: "✅ QA Validator"
    needs: [motion-director]
    runs-on: ubuntu-latest
    outputs:
      package_path: ${{ steps.qa.outputs.package_path }}
      status: ${{ steps.qa.outputs.status }}
    steps:
      - uses: actions/checkout@v4
      - run: pip install -r requirements.txt
      - uses: actions/download-artifact@v4
        with:
          name: package-${{ inputs.topic_id }}
          path: inputs/
      
      - name: Run QA and push to GCP
        id: qa
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
          GCP_SA_KEY: ${{ secrets.GCP_SA_KEY }}
          TELEGRAM_BOT_TOKEN: ${{ secrets.TELEGRAM_BOT_TOKEN }}
          TELEGRAM_CHAT_ID: ${{ secrets.TELEGRAM_CHAT_ID }}
        run: |
          ai-director agent \
            --name qa \
            --config ${{ inputs.config_path }} \
            --input inputs/video_package.json \
            --output outputs/final_package.json
          
          # Push to GCP — channel name được lấy từ config tự động
          CHANNEL=$(python3 -c "import json; print(json.load(open('${{ inputs.config_path }}'))['channel_name'].lower())")
          GCS_PATH="gs://ai-director-outputs/$CHANNEL/${{ inputs.topic_id }}/package.json"
          gsutil cp outputs/final_package.json $GCS_PATH
          echo "package_path=$GCS_PATH" >> $GITHUB_OUTPUT`
  },

  "channel-repo": {
    description: "Đây là toàn bộ nội dung của một channel repo. Không có agent code, không có lib, không có logic. Chỉ có config và một workflow file mỏng gọi vào core.",
    code: `# TOÀN BỘ NỘI DUNG của losters-channel repo:
# ├── .github/workflows/pipeline.yml   ← 40 dòng
# ├── data/channel_config.json         ← ~60 dòng JSON
# ├── data/topics_queue.json           ← danh sách topics
# └── requirements.txt                 ← 1 dòng
#
# Đó là tất cả. Không có gì khác.

# ──────────────────────────────────────────────────────────────
# .github/workflows/pipeline.yml — workflow của channel repo
# File này không chứa bất kỳ logic nào — chỉ là "caller"

name: "LostEras Content Pipeline"

on:
  schedule:
    - cron: '0 16 * * *'    # 11pm Vietnam, daily
  workflow_dispatch:
    inputs:
      topic_override:
        description: 'Override topic'
        required: false

jobs:
  # Job 1: Lấy topic từ queue — logic đơn giản, đặt ở đây vì cần repo access
  pick-topic:
    name: "📋 Pick Topic"
    runs-on: ubuntu-latest
    outputs:
      topic: ${{ steps.pick.outputs.topic }}
      topic_id: ${{ steps.pick.outputs.topic_id }}
      has_topic: ${{ steps.pick.outputs.has_topic }}
    steps:
      - uses: actions/checkout@v4
      - run: pip install ai-director-core  # Core có utility để đọc queue
      - name: Pick next topic
        id: pick
        run: |
          ai-director queue pick \
            --queue data/topics_queue.json \
            --override "${{ github.event.inputs.topic_override }}" \
            >> $GITHUB_OUTPUT

  # Job 2: Gọi toàn bộ core pipeline
  run-pipeline:
    needs: pick-topic
    if: needs.pick-topic.outputs.has_topic == 'true'
    # ↓ Đây là magic line — gọi reusable workflow từ core repo
    uses: your-org/ai-director-core/.github/workflows/reusable-pipeline.yml@v1.2.0
    with:
      topic: ${{ needs.pick-topic.outputs.topic }}
      topic_id: ${{ needs.pick-topic.outputs.topic_id }}
      config_path: "data/channel_config.json"
    secrets:
      ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
      PEXELS_API_KEY: ${{ secrets.PEXELS_API_KEY }}
      GCP_SA_KEY: ${{ secrets.GCP_SA_KEY }}
      TELEGRAM_BOT_TOKEN: ${{ secrets.TELEGRAM_BOT_TOKEN }}
      TELEGRAM_CHAT_ID: ${{ secrets.TELEGRAM_CHAT_ID }}

  # Job 3: Update queue status sau khi pipeline xong
  update-queue:
    needs: [pick-topic, run-pipeline]
    if: always() && needs.pick-topic.outputs.has_topic == 'true'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install ai-director-core
      - name: Mark topic status
        run: |
          STATUS="${{ needs.run-pipeline.outputs.status }}"
          ai-director queue update \
            --queue data/topics_queue.json \
            --topic-id "${{ needs.pick-topic.outputs.topic_id }}" \
            --status "$STATUS"
          git config user.email "bot@ai-director"
          git config user.name "AI Director Bot"
          git add data/topics_queue.json
          git commit -m "[$STATUS] ${{ needs.pick-topic.outputs.topic }}" || true
          git push

# ──────────────────────────────────────────────────────────────
# requirements.txt — chỉ có 1 dòng
ai-director-core==1.2.0

# Khi muốn upgrade: đổi thành ai-director-core==1.3.0
# Chạy lại pipeline → tự động dùng logic mới từ core
# Không cần sửa thêm bất kỳ thứ gì`
  },

  "new-channel": {
    description: "Quy trình tạo một kênh mới từ scratch. Mục tiêu: dưới 30 phút từ idea đến pipeline chạy được.",
    code: `# ══════════════════════════════════════════════════════════════
# CHECKLIST: Tạo kênh mới trong < 30 phút
# ══════════════════════════════════════════════════════════════

# BƯỚC 1 (~2 phút): Tạo repo từ template
# ─────────────────────────────────────────
# Trên GitHub: Vào channel-template repo → "Use this template"
# Đặt tên: [channel-name]-channel (vd: quietmind-channel)
# Private repo

# BƯỚC 2 (~5 phút): Add secrets vào repo mới
# ──────────────────────────────────────────
# GitHub repo → Settings → Secrets and variables → Actions
# Add: ANTHROPIC_API_KEY, PEXELS_API_KEY, GCP_SA_KEY, TELEGRAM_*
# (Secrets này dùng chung — copy từ channel đã có)

# BƯỚC 3 (~20 phút): Viết channel_config.json
# ────────────────────────────────────────────
# Đây là bước duy nhất cần creativity.
# Prompt để dùng với Claude:
#
# "I'm creating a YouTube Shorts channel about [niche].
#  Target audience: [description].
#  Reference channels/aesthetics: [examples].
#  Generate a channel_config.json following this schema: [paste ChannelConfig schema]
#  Make sure narrative tone, visual palette, and hook formula
#  are authentic to this specific niche."

# BƯỚC 4 (~3 phút): Add initial topics
# ──────────────────────────────────────
# Edit data/topics_queue.json, thêm 10–15 topics để bắt đầu

# BƯỚC 5: Push và verify
# ──────────────────────
git add .
git commit -m "🎬 Initial channel config for [ChannelName]"
git push

# Trigger manual pipeline để test:
# GitHub → Actions → "LostEras Content Pipeline" → Run workflow

# ══════════════════════════════════════════════════════════════
# CHANNEL TEMPLATE REPO STRUCTURE
# (cái bạn tạo một lần, dùng mãi mãi)
# ══════════════════════════════════════════════════════════════

# channel-template/
# ├── .github/
# │   └── workflows/
# │       └── pipeline.yml          # Đã viết sẵn, không cần sửa
# ├── data/
# │   ├── channel_config.json       # Template với placeholder values
# │   └── topics_queue.json         # Template rỗng
# ├── requirements.txt              # Đã có ai-director-core version mặc định
# └── README.md                     # Hướng dẫn: "Chỉ cần sửa channel_config.json"

# Khi tạo kênh mới từ template, người dùng chỉ cần biết:
# 1. Điền vào channel_config.json
# 2. Thêm topics vào queue
# 3. Push`
  },

  "versioning": {
    description: "Strategy để upgrade core library mà không làm hỏng các channel đang chạy. Đây là phần quan trọng nhất về mặt operational safety.",
    code: `# VERSIONING STRATEGY — Semantic Versioning với upgrade opt-in
#
# PATCH (1.2.0 → 1.2.1): Bug fix, không thay đổi behavior
#   Ví dụ: Fix retry logic trong Claude client
#   Channel repos: Có thể tự động upgrade via Dependabot
#
# MINOR (1.2.0 → 1.3.0): Tính năng mới, backward compatible
#   Ví dụ: Thêm support cho Pixabay ngoài Pexels
#          Improve prompt quality cho Shot List Director
#          Thêm motion type mới "cinematic_dolly"
#   Channel repos: Opt-in bằng cách bump version trong requirements.txt
#
# MAJOR (1.x.x → 2.0.0): Breaking changes — schema thay đổi
#   Ví dụ: channel_config.json có field mới BẮT BUỘC
#          Agent 2 output schema thay đổi
#   Channel repos: Phải migrate channel_config.json trước khi upgrade
#                  Core sẽ có migration guide trong CHANGELOG.md

# ──────────────────────────────────────────────────────────────
# CHANGELOG.md — ví dụ về cách document changes

## [1.3.0] — 2026-06-01
### Added
- Agent 2 now generates 15% more specific visual descriptions
  for medieval period shots (improved Flux prompts)
- Support for Pixabay as additional asset source
  Add "pixabay" to channel_config.asset_sources_priority to use

### Changed  
- Motion Director: "ominous" tone now defaults to zoom_out instead of pan_right
  (better emotional alignment based on LostEras test data)

### No Breaking Changes
- All existing channel_config.json files work without modification

## [2.0.0] — 2026-07-15
### Breaking Changes ⚠️
- channel_config.json now requires "brand_voice" field under narrative
- See MIGRATION.md for how to update your config

# ──────────────────────────────────────────────────────────────
# Practical workflow khi upgrade

# 1. Core team (bạn) release v1.3.0:
git tag v1.3.0
git push origin v1.3.0
# GitHub Actions tự build và publish package

# 2. Để upgrade một channel:
# Edit requirements.txt trong channel repo:
# TRƯỚC: ai-director-core==1.2.0
# SAU:   ai-director-core==1.3.0
git commit -m "⬆️ Upgrade ai-director-core to 1.3.0"
git push
# Lần chạy tiếp theo tự dùng version mới

# 3. Để tất cả channels nhận update cùng lúc:
# Dùng Dependabot hoặc viết script nhỏ:
for repo in losters-channel quietmind-channel dustcraft-channel; do
  gh repo clone your-org/$repo /tmp/$repo
  cd /tmp/$repo
  sed -i 's/ai-director-core==.*/ai-director-core==1.3.0/' requirements.txt
  git commit -am "⬆️ Upgrade to ai-director-core 1.3.0"
  git push
  cd ..
done

# ──────────────────────────────────────────────────────────────
# GCP ASSET LIBRARY — dùng chung hay tách biệt?
#
# Khuyến nghị: MỘT bucket, tách folder theo channel
#
# gs://ai-director-assets/
# ├── losters/library/          # Assets của LostEras
# ├── losters/assets.db         # SQLite database của LostEras
# ├── quietmind/library/        # Assets của QuietMind  
# └── quietmind/assets.db       # SQLite database của QuietMind
#
# Lý do: Chi phí GCP một bucket < nhiều bucket.
# Nhưng assets KHÔNG share giữa channels vì period/style khác nhau.
# assets.db của mỗi channel độc lập — không có cross-contamination.`
  }
};

export default function MultiRepoArchitecture() {
  const [activeSection, setActiveSection] = useState("architecture");
  const [copied, setCopied] = useState(false);

  const sec = sections.find(s => s.id === activeSection);
  const data = content[activeSection];

  const handleCopy = () => {
    navigator.clipboard.writeText(data.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{
      background: "#0D1117",
      minHeight: "100vh",
      fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
      color: "#C9D1D9",
      display: "flex",
      flexDirection: "column"
    }}>
      {/* Header */}
      <div style={{
        background: "#161B22",
        borderBottom: "1px solid #30363D",
        padding: "20px 28px",
      }}>
        <div style={{ fontSize: 11, color: "#8B949E", letterSpacing: "0.12em", marginBottom: 6 }}>
          AI DIRECTOR — MULTI-CHANNEL PLATFORM ARCHITECTURE
        </div>
        <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: "#F0F6FC" }}>
          ai-director-core + channel repos
        </h1>
        <div style={{ display: "flex", gap: 20, marginTop: 10, flexWrap: "wrap" }}>
          {[
            { label: "1 core repo", color: "#388BFD" },
            { label: "N channel repos", color: "#3FB950" },
            { label: "0 code duplication", color: "#F78166" },
            { label: "Upgrade = 1 dòng thay đổi", color: "#D2A8FF" }
          ].map((tag, i) => (
            <span key={i} style={{
              fontSize: 11,
              color: tag.color,
              background: tag.color + "18",
              border: `1px solid ${tag.color}44`,
              borderRadius: 20,
              padding: "3px 10px"
            }}>{tag.label}</span>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", flex: 1 }}>
        {/* Sidebar */}
        <div style={{
          width: 220,
          background: "#161B22",
          borderRight: "1px solid #30363D",
          padding: "16px 0",
          flexShrink: 0
        }}>
          {sections.map(s => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              style={{
                display: "block",
                width: "100%",
                textAlign: "left",
                padding: "10px 18px",
                background: activeSection === s.id ? "#21262D" : "transparent",
                border: "none",
                borderLeft: `2px solid ${activeSection === s.id ? "#388BFD" : "transparent"}`,
                color: activeSection === s.id ? "#F0F6FC" : "#8B949E",
                cursor: "pointer",
                fontSize: 12.5,
                fontFamily: "inherit",
                lineHeight: 1.4,
                transition: "all 0.1s"
              }}
            >
              {s.label}
            </button>
          ))}

          {/* Visual repo hierarchy */}
          <div style={{
            margin: "20px 12px 0",
            background: "#0D1117",
            border: "1px solid #30363D",
            borderRadius: 6,
            padding: "12px",
            fontSize: 11,
            lineHeight: 1.8,
            color: "#8B949E"
          }}>
            <div style={{ color: "#388BFD", marginBottom: 4 }}>📦 ai-director-core</div>
            <div style={{ paddingLeft: 8 }}>└─ reusable-pipeline.yml</div>
            <div style={{ paddingLeft: 8 }}>└─ ai_director/</div>
            <div style={{ height: 8 }} />
            <div style={{ color: "#3FB950", marginBottom: 4 }}>📁 losters-channel</div>
            <div style={{ paddingLeft: 8, color: "#F78166" }}>└─ channel_config.json</div>
            <div style={{ paddingLeft: 8 }}>└─ topics_queue.json</div>
            <div style={{ height: 8 }} />
            <div style={{ color: "#3FB950", marginBottom: 4 }}>📁 quietmind-channel</div>
            <div style={{ paddingLeft: 8, color: "#F78166" }}>└─ channel_config.json</div>
            <div style={{ paddingLeft: 8 }}>└─ topics_queue.json</div>
            <div style={{ height: 4 }} />
            <div style={{ color: "#6E7681" }}>📁 [next-channel]...</div>
          </div>
        </div>

        {/* Main content */}
        <div style={{ flex: 1, padding: "24px 28px", overflowY: "auto" }}>
          <div style={{
            background: "#1C2128",
            border: "1px solid #30363D",
            borderLeft: "3px solid #388BFD",
            borderRadius: 6,
            padding: "12px 16px",
            marginBottom: 20,
            fontSize: 13,
            color: "#A5D6FF",
            lineHeight: 1.7
          }}>
            {data.description}
          </div>

          <div style={{
            background: "#161B22",
            border: "1px solid #30363D",
            borderRadius: 8,
            overflow: "hidden"
          }}>
            <div style={{
              background: "#21262D",
              padding: "10px 16px",
              borderBottom: "1px solid #30363D",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center"
            }}>
              <span style={{ fontSize: 12, color: "#8B949E" }}>{sec?.label}</span>
              <button
                onClick={handleCopy}
                style={{
                  background: "#21262D",
                  border: "1px solid #30363D",
                  borderRadius: 6,
                  color: "#8B949E",
                  padding: "4px 12px",
                  cursor: "pointer",
                  fontSize: 11,
                  fontFamily: "inherit",
                }}
              >
                {copied ? "✅ Copied" : "📋 Copy"}
              </button>
            </div>

            <pre style={{
              margin: 0,
              padding: "20px 20px",
              fontSize: 12,
              lineHeight: 1.85,
              color: "#C9D1D9",
              overflowX: "auto",
              overflowY: "auto",
              maxHeight: "65vh",
              whiteSpace: "pre-wrap",
              wordBreak: "break-word"
            }}>
              {data.code.split("\n").map((line, i) => {
                const isComment = line.trim().startsWith("#") || line.trim().startsWith("//");
                const isKey = /^(name|on|jobs|runs-on|needs|if|env|steps|with|uses|run|outputs|id|secrets|inputs):/i.test(line.trim());
                const isString = line.includes('"') && !isComment;
                return (
                  <span key={i} style={{
                    color: isComment ? "#6E7681" : isKey ? "#79C0FF" : "#C9D1D9",
                    display: "block",
                    minHeight: "1.2em"
                  }}>
                    {line || ""}
                  </span>
                );
              })}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
