## ADDED Requirements

### Requirement: README contains architecture overview
README.md SHALL include an architecture overview section explaining the two-tier structure: Core Library (ai-director-core) and Channel Repos (configuration-only).

#### Scenario: Developer reads architecture section
- **WHEN** developer opens README.md
- **THEN** they SHALL find a clear description of the core/channel separation, data flow, and multi-repo strategy

### Requirement: README contains tech stack
README.md SHALL list the primary tech stack: Python 3.11+, Pydantic v2, Anthropic Claude, Hatchling, GitHub Actions, GCS.

#### Scenario: Developer checks tech stack
- **WHEN** developer reads the Tech Stack section
- **THEN** they SHALL find all major dependencies and their purposes listed

### Requirement: README contains installation instructions
README.md SHALL include installation instructions for both development (editable install) and production (pip install from package registry).

#### Scenario: Developer installs for development
- **WHEN** developer follows the installation section
- **THEN** they SHALL be able to run `pip install -e .` and use the `ai-director` CLI

### Requirement: README contains CLI reference
README.md SHALL document all available CLI commands: `run`, `validate`, `agent`, `budget status`, `migrate`, `init`, and `scaffold`.

#### Scenario: Developer looks up CLI command
- **WHEN** developer reads CLI Reference section
- **THEN** they SHALL find usage, arguments, and examples for every command

### Requirement: README contains project structure
README.md SHALL include the project directory structure showing the organization of agents, models, budget, lib, and tests.

#### Scenario: Developer checks project layout
- **WHEN** developer reads the Project Structure section
- **THEN** they SHALL see a tree view of the `ai_director/` package and key files

### Requirement: README contains quickstart guide
README.md SHALL include a quickstart section showing how to scaffold a new brand and run the pipeline end-to-end.

#### Scenario: New user follows quickstart
- **WHEN** user follows the Quickstart section steps
- **THEN** they SHALL be able to scaffold a brand, create a topic, and run the pipeline

---

## MODIFIED Requirements

### Requirement: README documentation
The README SHALL include documentation for all CLI commands, including `ad dashboard` and `ad app-info`. The tech stack table SHALL list Gemini 3.1 (LLM), gemini-2.5-flash-image (image generation), and React 18 + TypeScript (dashboard). The project structure SHALL reflect the `dashboard/` directory.

#### Scenario: Tech stack table completeness
- **WHEN** a user reads the README tech stack table
- **THEN** the table SHALL include entries for: Gemini 3.1 (LLM — configurable), gemini-2.5-flash-image (image generation), React 18 + TypeScript (dashboard), and Vite (dashboard build)

#### Scenario: CLI reference completeness
- **WHEN** a user reads the CLI reference section
- **THEN** the section SHALL document `ad dashboard`, `ad app-info` commands with usage examples

#### Scenario: CHANGELOG reflects new features
- **WHEN** a user reads CHANGELOG.md
- **THEN** the `[2.1.0]` section SHALL list: dashboard portal, version display, AI model config, `ad app-info` CLI, and `ad dashboard` CLI
