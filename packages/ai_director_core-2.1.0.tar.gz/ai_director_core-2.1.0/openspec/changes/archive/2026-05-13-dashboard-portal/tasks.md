## 1. Project Scaffold & Configuration

- [x] 1.1 Initialize `dashboard/` directory with Vite + React + TypeScript (package.json, tsconfig, vite config)
- [x] 1.2 Configure `vite.config.ts` to build output to `ai_director/dashboard/static/`
- [x] 1.3 Set up `vitest.config.ts` with React Testing Library and jsdom environment
- [x] 1.4 Install all dependencies (react, react-router-dom, firebase, date-fns, vitest, testing-library, typescript)
- [x] 1.5 Create `ai_director/dashboard/__init__.py` and `ai_director/dashboard/server.py` (Python HTTP server for SPA)
- [x] 1.6 Add `ad dashboard` CLI command to `runner.py` and update `pyproject.toml` to include static files

## 2. Design System & UI Foundation

- [x] 2.1 Create `src/styles/tokens.css` with all CSS custom properties (colors, fonts, spacing) from design tokens
- [x] 2.2 Create `src/styles/global.css` with reset, font imports (DM Sans, DM Mono), base styles, grain overlay, animation keyframes
- [x] 2.3 Build `Button` component with primary, secondary, ghost variants
- [x] 2.4 Build `Card` component with dark surface styling
- [x] 2.5 Build `Input`, `Select`, `Textarea` form components
- [x] 2.6 Build `Badge` component for status labels
- [x] 2.7 Build `Modal` component with backdrop and close handling
- [x] 2.8 Build `Sidebar` layout component with navigation links
- [x] 2.9 Build `AppLayout` shell component (sidebar + header + content area)
- [x] 2.10 Write tests for all shared UI components

## 3. Firebase & Authentication

- [x] 3.1 Create `src/lib/firebase.ts` with Firebase app initialization and auth export
- [x] 3.2 Create `src/features/auth/AuthProvider.tsx` with Firebase Auth state context
- [x] 3.3 Create `src/features/auth/LoginPage.tsx` with email/password form matching design system
- [x] 3.4 Create `src/features/auth/ProtectedRoute.tsx` route guard component
- [x] 3.5 Configure Firebase environment variables (`.env.example` and `.env.local`)
- [ ] 3.6 Write tests for AuthProvider (auth state changes, session persistence)
- [x] 3.7 Write tests for LoginPage (valid/invalid credentials, error display)
- [ ] 3.8 Write tests for ProtectedRoute (redirect unauthenticated, allow authenticated)

## 4. Routing & App Shell

- [x] 4.1 Create `src/App.tsx` with React Router setup and route definitions
- [x] 4.2 Define routes: `/login`, `/`, `/channels`, `/channels/:id`, `/calendar`, `/schedule`, `/settings`
- [x] 4.3 Wrap routes with AuthProvider and ProtectedRoute
- [x] 4.4 Implement sidebar active state based on current route
- [ ] 4.5 Write tests for route protection and navigation

## 5. Channel Configuration

- [x] 5.1 Create `src/lib/firestore.ts` with Firestore helpers for channel CRUD operations
- [x] 5.2 Create channel TypeScript types/interfaces (`src/features/channels/types.ts`)
- [x] 5.3 Build `ChannelListPage.tsx` — display all channels with name, niche, status chips
- [x] 5.4 Build `ChannelDetailPage.tsx` — full config view grouped by category (basic, audience, brand, strategy, platforms)
- [x] 5.5 Build `ChannelForm.tsx` — create/edit form with all config fields and validation
- [x] 5.6 Implement channel delete with confirmation modal
- [ ] 5.7 Write tests for channel CRUD operations (create, read, update, delete)
- [ ] 5.8 Write tests for form validation (required fields, error display)

## 6. Production Calendar

- [x] 6.1 Create video TypeScript types/interfaces (`src/features/calendar/types.ts`)
- [x] 6.2 Build `CalendarPage.tsx` with view switcher (week/month/year)
- [x] 6.3 Build `WeekView.tsx` — 7-column layout with video cards per day
- [x] 6.4 Build `MonthView.tsx` — monthly grid with video indicators
- [x] 6.5 Build `YearView.tsx` — 12-month overview with heat-map density indicators
- [x] 6.6 Build `VideoDetailPanel.tsx` — slide-out panel with title, script, status, platforms
- [x] 6.7 Implement date navigation (prev/next for week, month, year)
- [x] 6.8 Implement channel filter dropdown for calendar
- [x] 6.9 Add production status badges (draft, scripted, in-production, ready, published)
- [ ] 6.10 Write tests for week view rendering and navigation
- [ ] 6.11 Write tests for month view rendering and navigation
- [ ] 6.12 Write tests for year view rendering
- [ ] 6.13 Write tests for video detail panel open/close
- [ ] 6.14 Write tests for channel filter functionality

## 7. Publishing Schedule

- [x] 7.1 Create schedule TypeScript types/interfaces (`src/features/schedule/types.ts`)
- [x] 7.2 Build `SchedulePage.tsx` — list of upcoming scheduled publishes
- [x] 7.3 Build `ScheduleForm.tsx` — create/edit form with date picker, platform selection, per-platform settings
- [x] 7.4 Implement YouTube-specific settings (title, description, tags, category, visibility, thumbnail)
- [x] 7.5 Implement TikTok-specific settings (caption, hashtags, cover image)
- [x] 7.6 Implement Instagram-specific settings (caption, hashtags, cover image, post type)
- [x] 7.7 Build recurring weekly template configuration
- [x] 7.8 Integrate schedule entries with calendar view (platform badges on video cards)
- [x] 7.9 Implement schedule delete with single-platform and full removal support
- [ ] 7.10 Write tests for schedule CRUD operations
- [ ] 7.11 Write tests for platform-specific settings forms
- [ ] 7.12 Write tests for recurring schedule template

## 8. Brand Plugin/Hook System

- [x] 8.1 Create `src/hooks/types.ts` — BrandPlugin interface, hook type definitions, Platform type
- [x] 8.2 Create `src/hooks/plugin-registry.ts` — BrandPluginRegistry with register, unregister, and event dispatch
- [x] 8.3 Implement lifecycle hook dispatching: `onVideoScheduled`, `onVideoPublished`, `onChannelConfigUpdated`
- [x] 8.4 Create `PluginSlot.tsx` component for UI extension points with error boundaries
- [x] 8.5 Integrate plugin slots into schedule detail view and settings page
- [x] 8.6 Implement plugin isolation — error catching in hooks and render error boundaries
- [x] 8.7 Write tests for plugin registration (success, duplicate rejection)
- [x] 8.8 Write tests for lifecycle hook dispatching
- [x] 8.9 Write tests for plugin isolation (hook error handling, render error boundary)

## 9. DailyWonders Example Plugin

- [x] 9.1 Create `dashboard/plugins/dailywonders/index.ts` — plugin registration with all hooks
- [x] 9.2 Implement auto-publish schedule hook (`onVideoScheduled`)
- [x] 9.3 Implement SEO optimization hook (`onVideoPublished`)
- [x] 9.4 Implement social sharing settings (Pinterest pins)
- [x] 9.5 Build DailyWonders settings panel component
- [ ] 9.6 Write tests for DailyWonders plugin registration and hook execution

## 10. Integration & CI

- [ ] 10.1 Create `.github/workflows/dashboard-ci.yml` — build, lint, test on PR
- [ ] 10.2 Add `firebase.json` and `.firebaserc` for Firebase Hosting deployment config
- [ ] 10.3 End-to-end smoke test: auth → channel create → calendar view → schedule
- [ ] 10.4 Update root `README.md` with dashboard setup and development instructions
