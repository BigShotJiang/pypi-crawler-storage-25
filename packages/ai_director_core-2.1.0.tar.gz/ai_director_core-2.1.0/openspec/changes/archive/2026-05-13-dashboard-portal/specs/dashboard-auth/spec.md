## ADDED Requirements

### Requirement: Firebase email/password authentication
The system SHALL authenticate users via Firebase Authentication using email/password provider. Only authenticated users SHALL access the dashboard.

#### Scenario: Successful login with valid credentials
- **WHEN** a user enters valid email and password on the login screen
- **THEN** the system authenticates via Firebase Auth and redirects to the dashboard home

#### Scenario: Failed login with invalid credentials
- **WHEN** a user enters invalid email or password
- **THEN** the system displays an error message and remains on the login screen

#### Scenario: Session persistence across page reloads
- **WHEN** an authenticated user reloads the browser
- **THEN** the system restores the session from Firebase Auth state and does not require re-login

#### Scenario: Logout
- **WHEN** an authenticated user clicks the logout button
- **THEN** the system signs out via Firebase Auth and redirects to the login screen

### Requirement: Protected route access
The system SHALL prevent unauthenticated users from accessing any dashboard route other than the login page.

#### Scenario: Unauthenticated access to protected route
- **WHEN** an unauthenticated user navigates to a dashboard route
- **THEN** the system redirects to the login page

#### Scenario: Authenticated access to protected route
- **WHEN** an authenticated user navigates to a dashboard route
- **THEN** the system renders the requested page

### Requirement: Default admin account
The system SHALL support a default admin account with email `andrew.hcmuns@gmail.com` configured in the Firebase project.

#### Scenario: Default admin can log in after Firebase project setup
- **WHEN** the Firebase project is initialized with the default admin account
- **THEN** the admin can log in with email `andrew.hcmuns@gmail.com` and the configured password
