## ADDED Requirements

### Requirement: Design system tokens
The system SHALL define CSS custom properties (design tokens) matching the planning-agent.jsx aesthetic: dark background (`#0a0a0f`), light text (`#e8e6e0`), amber accent (`#f59e0b`), success green (`#10b981`), surface cards (`#ffffff06`), subtle borders (`#ffffff0a`).

#### Scenario: All components use design tokens
- **WHEN** a UI component renders
- **THEN** the component uses CSS custom properties from the design token system rather than hardcoded color values

### Requirement: Typography system
The system SHALL use DM Sans as the primary body font and DM Mono as the monospace/label font, loaded from Google Fonts.

#### Scenario: Body text renders in DM Sans
- **WHEN** any body text is rendered
- **THEN** the text uses the DM Sans font family with appropriate weight (300 for headings, 400 for body)

#### Scenario: Labels and metadata render in DM Mono
- **WHEN** labels, badges, or metadata text is rendered
- **THEN** the text uses DM Mono font family with letter-spacing for readability

### Requirement: Shared UI components
The system SHALL provide a set of shared UI components: Button (primary, secondary, ghost variants), Card, Input, Select, Textarea, Badge, Modal, and Sidebar — all styled according to the design system.

#### Scenario: Primary button renders with amber accent
- **WHEN** a primary Button component renders
- **THEN** it displays with amber (`#f59e0b`) background, dark text, DM Mono font, and rounded corners

#### Scenario: Card component renders with dark surface
- **WHEN** a Card component renders
- **THEN** it displays with `#ffffff06` background, `#ffffff0a` border, 16px border-radius

### Requirement: Application layout shell
The system SHALL provide a consistent layout shell with a fixed sidebar navigation, header with user info, and main content area.

#### Scenario: Sidebar navigation displays all sections
- **WHEN** the layout shell renders for an authenticated user
- **THEN** the sidebar displays navigation links for: Dashboard, Channels, Calendar, Schedule, and Settings

#### Scenario: Active navigation state
- **WHEN** a user is on the Calendar page
- **THEN** the Calendar navigation item displays in the active state with accent highlighting

### Requirement: Grain texture overlay
The system SHALL apply a subtle noise/grain texture overlay matching the planning-agent.jsx aesthetic.

#### Scenario: Grain renders as non-interactive overlay
- **WHEN** the application renders
- **THEN** a fixed-position grain texture overlay is displayed with low opacity and pointer-events disabled

### Requirement: Animation system
The system SHALL use subtle fade-in animations for page transitions and component mounting, matching the planning-agent.jsx animation style.

#### Scenario: Page transition animation
- **WHEN** a user navigates between pages
- **THEN** the new page content fades in with a slight upward translate (8px over 250ms)
