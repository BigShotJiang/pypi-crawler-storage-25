## ADDED Requirements

### Requirement: Week view calendar
The system SHALL display a week view calendar showing all scheduled videos for the selected week, with each day as a column and video cards positioned by date.

#### Scenario: Display current week videos
- **WHEN** a user navigates to the calendar page
- **THEN** the system displays the current week with video cards showing title, channel, and production status for each scheduled video

#### Scenario: Navigate to previous/next week
- **WHEN** a user clicks the previous or next week navigation button
- **THEN** the system updates the calendar to show videos for the selected week

### Requirement: Month view calendar
The system SHALL display a month view calendar showing all scheduled videos in a monthly grid layout.

#### Scenario: Display current month videos
- **WHEN** a user switches to month view
- **THEN** the system displays a monthly grid with video indicators on their scheduled dates

#### Scenario: Navigate to previous/next month
- **WHEN** a user clicks the previous or next month navigation button
- **THEN** the system updates the calendar to show videos for the selected month

### Requirement: Year view calendar
The system SHALL display a year view calendar providing a high-level overview of video production activity across all months.

#### Scenario: Display year overview
- **WHEN** a user switches to year view
- **THEN** the system displays all 12 months with heat-map style indicators showing video density per day

### Requirement: Video script preview
The system SHALL allow users to view the full script and production details of a video from the calendar.

#### Scenario: Open video details from calendar
- **WHEN** a user clicks on a video card in the calendar
- **THEN** the system opens a detail panel showing the video title, script content, channel, production status, scheduled date, and assigned platforms

#### Scenario: Close video detail panel
- **WHEN** a user closes the video detail panel
- **THEN** the system returns to the calendar view with the previous state preserved

### Requirement: Calendar filtering by channel
The system SHALL allow users to filter the calendar by one or more channels.

#### Scenario: Filter by single channel
- **WHEN** a user selects a single channel from the filter dropdown
- **THEN** the calendar displays only videos belonging to the selected channel

#### Scenario: Clear channel filter
- **WHEN** a user clears the channel filter
- **THEN** the calendar displays videos from all channels

### Requirement: Video production status display
The system SHALL display production status badges on video cards in the calendar. Statuses include: draft, scripted, in-production, ready, published.

#### Scenario: Display status badge on video card
- **WHEN** the calendar renders a video card
- **THEN** the card displays a color-coded status badge indicating the current production stage
