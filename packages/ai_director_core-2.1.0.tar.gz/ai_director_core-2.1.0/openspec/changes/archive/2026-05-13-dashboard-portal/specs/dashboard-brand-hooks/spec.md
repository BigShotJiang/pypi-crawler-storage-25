## ADDED Requirements

### Requirement: Plugin registration API
The system SHALL provide a `BrandPluginRegistry` that allows brand plugins to register themselves with the dashboard at application startup.

#### Scenario: Register a brand plugin
- **WHEN** a brand plugin calls `registerPlugin()` with a valid plugin configuration
- **THEN** the system adds the plugin to the registry and activates its hooks

#### Scenario: Reject duplicate plugin registration
- **WHEN** a plugin attempts to register with an ID that already exists
- **THEN** the system throws an error and does not register the duplicate

### Requirement: Plugin lifecycle hooks
The system SHALL support the following lifecycle hooks that plugins can subscribe to: `onVideoScheduled`, `onVideoPublished`, `onChannelConfigUpdated`.

#### Scenario: Plugin receives onVideoScheduled event
- **WHEN** a video is scheduled via the publishing schedule
- **THEN** the system invokes `onVideoScheduled` on all registered plugins that implement this hook

#### Scenario: Plugin receives onVideoPublished event
- **WHEN** a video's status changes to published
- **THEN** the system invokes `onVideoPublished` on all registered plugins that implement this hook

#### Scenario: Plugin receives onChannelConfigUpdated event
- **WHEN** a channel configuration is created or modified
- **THEN** the system invokes `onChannelConfigUpdated` on all registered plugins that implement this hook

### Requirement: Plugin UI extension points
The system SHALL provide designated UI slots where plugins can render additional UI components: schedule extras panel, settings panel.

#### Scenario: Plugin renders schedule extras
- **WHEN** a plugin implements `renderScheduleExtras`
- **THEN** the system renders the plugin's component in the schedule detail view

#### Scenario: Plugin renders settings panel
- **WHEN** a plugin implements `renderSettingsPanel`
- **THEN** the system renders the plugin's settings in the channel settings page under a plugin-specific section

### Requirement: Plugin platform extension
The system SHALL allow plugins to register additional publishing platforms beyond the built-in YouTube, TikTok, and Instagram.

#### Scenario: Plugin adds custom platform
- **WHEN** a plugin implements `getAdditionalPlatforms` returning a Pinterest platform definition
- **THEN** the system includes Pinterest as an available platform in the publishing schedule

### Requirement: Plugin isolation
The system SHALL isolate plugin execution so that a failure in one plugin does not crash the dashboard or affect other plugins.

#### Scenario: Plugin hook throws error
- **WHEN** a plugin's hook handler throws an unhandled error
- **THEN** the system catches the error, logs it, and continues invoking hooks on other plugins

#### Scenario: Plugin render error
- **WHEN** a plugin's UI component throws a render error
- **THEN** the system displays a fallback error boundary for that plugin slot without affecting the rest of the page

### Requirement: Example DailyWonders plugin
The system SHALL include a reference plugin implementation for the DailyWonders brand demonstrating: auto-publish scheduling, SEO optimization after upload, social sharing (Pinterest pins), and custom settings panel.

#### Scenario: DailyWonders plugin registers successfully
- **WHEN** the dashboard starts with the DailyWonders plugin enabled
- **THEN** the plugin registers with hooks for `onVideoScheduled`, `onVideoPublished`, and provides a settings panel

#### Scenario: DailyWonders SEO hook runs on publish
- **WHEN** a video is published for a DailyWonders channel
- **THEN** the DailyWonders plugin executes its SEO optimization logic via the `onVideoPublished` hook
