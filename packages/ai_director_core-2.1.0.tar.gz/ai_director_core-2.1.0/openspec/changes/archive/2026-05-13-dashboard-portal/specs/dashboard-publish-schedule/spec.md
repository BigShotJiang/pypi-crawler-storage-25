## ADDED Requirements

### Requirement: Create publishing schedule
The system SHALL allow authenticated users to create a publishing schedule for a video, specifying the publish date/time and target platforms.

#### Scenario: Schedule video for single platform
- **WHEN** a user selects a video, sets a publish date/time, and selects YouTube as the target platform
- **THEN** the system creates a publishing schedule entry with the specified date and platform

#### Scenario: Schedule video for multiple platforms
- **WHEN** a user selects a video and selects YouTube, TikTok, and Instagram as target platforms
- **THEN** the system creates schedule entries for each platform with the specified date/time

### Requirement: Supported publishing platforms
The system SHALL support scheduling video uploads for YouTube, TikTok, and Instagram platforms. Each platform SHALL have its own configuration section.

#### Scenario: Platform-specific settings for YouTube
- **WHEN** a user configures YouTube publishing settings
- **THEN** the system provides fields for title, description, tags, category, visibility (public/unlisted/private), and thumbnail

#### Scenario: Platform-specific settings for TikTok
- **WHEN** a user configures TikTok publishing settings
- **THEN** the system provides fields for caption, hashtags, and cover image

#### Scenario: Platform-specific settings for Instagram
- **WHEN** a user configures Instagram publishing settings
- **THEN** the system provides fields for caption, hashtags, cover image, and post type (Reels/Feed)

### Requirement: Edit publishing schedule
The system SHALL allow users to modify existing publishing schedules, including changing dates, times, and platforms.

#### Scenario: Reschedule video to different date
- **WHEN** a user changes the publish date of a scheduled video
- **THEN** the system updates the schedule and the calendar reflects the new date

#### Scenario: Add platform to existing schedule
- **WHEN** a user adds a new platform to an already-scheduled video
- **THEN** the system creates a new platform entry in the schedule

### Requirement: Delete publishing schedule
The system SHALL allow users to remove a publishing schedule entry.

#### Scenario: Remove schedule for single platform
- **WHEN** a user removes the YouTube schedule for a video
- **THEN** the system deletes that platform's schedule entry while preserving other platform schedules

#### Scenario: Remove entire video schedule
- **WHEN** a user deletes all platform schedules for a video
- **THEN** the system removes the video from the publishing calendar

### Requirement: Publishing schedule calendar integration
The system SHALL display publishing schedules in the production calendar with platform icons indicating which platforms each video is scheduled for.

#### Scenario: Calendar shows platform badges
- **WHEN** the calendar renders a scheduled video
- **THEN** the video card displays platform icons (YouTube, TikTok, Instagram) for each scheduled platform

### Requirement: Weekly recurring schedule template
The system SHALL allow users to create a recurring weekly schedule template defining which days and times videos should be published.

#### Scenario: Set recurring schedule
- **WHEN** a user configures a weekly template with Monday at 6 PM and Thursday at 12 PM for YouTube
- **THEN** the system suggests these time slots when scheduling new videos for the channel
