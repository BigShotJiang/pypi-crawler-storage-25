## Why

AI Director core currently operates as a CLI-only tool — channels are configured via JSON files and pipelines run through GitHub Actions. There is no centralized interface for managing channels, reviewing video scripts, scheduling uploads, or monitoring production calendars. As the number of brands grows (LostEras, Viral5, DailyWonders, etc.), operators need a visual dashboard to manage channel configurations, review AI-generated content, and coordinate publishing across platforms — without touching config files or running CLI commands manually.

## What Changes

- Add a **web-based dashboard portal** (React + TypeScript) as a new `dashboard/` directory in the repository
- Implement **Firebase Authentication** with email/password login (default admin: `andrew.hcmuns@gmail.com`)
- Build **channel configuration UI** for managing all channel parameters: niche, description, target audience, focus market, brand identity, content strategy, and platform settings
- Create a **production calendar** with week/month/year views showing scheduled videos, their scripts, and production status
- Add **publishing schedule management** to plan video uploads across platforms (YouTube, TikTok, Instagram) with per-platform settings
- Introduce a **brand extension hook system** allowing child brands to register custom plugins (e.g., auto-publish, SEO optimization, social sharing, pin creation) without modifying core dashboard code
- All code, comments, and technical documentation in **English**; full **test coverage** with unit and integration tests

## Capabilities

### New Capabilities
- `dashboard-auth`: Firebase Authentication integration — login/logout, session management, route protection, default admin account setup
- `dashboard-channel-config`: Channel configuration management UI — create/edit/view channel settings (niche, description, audience, market, brand identity, content strategy, platform configs)
- `dashboard-calendar`: Production calendar — week/month/year views for video schedules, script preview, production status tracking
- `dashboard-publish-schedule`: Publishing schedule management — plan upload dates per platform, manage platform credentials, configure per-platform upload settings
- `dashboard-brand-hooks`: Brand extension hook system — plugin registration API, lifecycle hooks, isolated brand plugin execution, example DailyWonders plugin demonstrating auto-publish, SEO, and social sharing extensions
- `dashboard-ui-foundation`: UI foundation layer — design system matching planning-agent.jsx aesthetic (dark theme, DM Sans/DM Mono fonts, amber/green accent palette), shared components, layout shell

### Modified Capabilities

_None — this is a new subsystem that does not change existing core engine specs._

## Impact

- **New directory**: `dashboard/` at repository root containing the React/TypeScript web application
- **Dependencies**: React 18+, TypeScript, Firebase SDK, date-fns or dayjs for calendar, Vite for build tooling
- **API surface**: Dashboard reads channel `config.json` and `video_package.json` files from GCS (or local dev); no changes to core Python engine API
- **CI/CD**: New GitHub Actions workflow for dashboard build, test, and deploy
- **Infrastructure**: Firebase project setup required (Auth + optionally Firestore for dashboard state)
- **Testing**: Vitest + React Testing Library for unit/component tests; all features require test coverage
- **Existing code**: Zero impact on `ai_director/` Python package — dashboard is a separate frontend application that consumes core engine outputs
