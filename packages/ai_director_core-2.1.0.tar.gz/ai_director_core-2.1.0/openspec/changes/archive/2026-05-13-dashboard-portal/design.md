## Context

AI Director core is a Python CLI-based video production engine using a multi-repo architecture: core engine lives in `ai-director-core`, each channel (LostEras, Viral5, etc.) is a separate data repo. Currently, all channel management happens through JSON config files and CLI commands. There is no web interface.

The dashboard portal introduces a React/TypeScript web application **bundled inside the `ai_director` Python package**. Frontend source lives at `dashboard/` (repo root) for development; built static assets are output to `ai_director/dashboard/static/` and included in the Python wheel. A lightweight Python server (`ai_director/dashboard/server.py`) serves the SPA. Brands run `ad dashboard` to launch it — when they `pip install --upgrade ai-director-core`, they get the latest dashboard automatically.

The design aesthetic is defined by the existing `planning-agent.jsx` reference: dark theme (`#0a0a0f` background), DM Sans / DM Mono fonts, amber (`#f59e0b`) accent, minimal grain texture, clean card-based layouts.

## Goals / Non-Goals

**Goals:**
- Provide a web-based dashboard for managing channel configurations, video calendars, and publishing schedules
- Authenticate users via Firebase Auth (email/password, default admin: `andrew.hcmuns@gmail.com`)
- Enable brand-level extensibility through a hook/plugin system so brands like DailyWonders can add features without modifying core code
- Match the planning-agent.jsx dark aesthetic consistently across all screens
- Maintain full test coverage for all features
- Keep all code, comments, and documentation in English

**Non-Goals:**
- Video editing or rendering within the dashboard
- Replacing the CLI pipeline — the dashboard is a management layer, not a pipeline runner
- Real-time collaboration (single-operator usage is sufficient for v1)
- Mobile-native app — responsive web is acceptable
- Direct YouTube/TikTok API upload automation in core (this is a brand plugin concern)

## Decisions

### 1. React + TypeScript + Vite as frontend stack

**Choice**: React 18+ with TypeScript, built with Vite.

**Rationale**: The existing planning-agent.jsx already uses React. TypeScript adds type safety essential for the hook system. Vite provides fast dev/build cycles.

**Alternatives considered**:
- Next.js: Unnecessary SSR complexity for a dashboard — this is a SPA consumed by authenticated operators
- Vue/Svelte: Team familiarity is with React (planning-agent.jsx precedent)

### 2. Firebase Auth for authentication

**Choice**: Firebase Authentication with email/password provider.

**Rationale**: User requirement. Firebase provides managed auth with minimal backend, session persistence, and easy route protection. Default admin `andrew.hcmuns@gmail.com` is configured during project setup.

**Alternatives considered**:
- Custom JWT auth: More control but requires backend infrastructure we don't need
- Auth0: More enterprise features but heavier dependency for a single-admin dashboard

### 3. Firestore as dashboard state store

**Choice**: Firebase Firestore for storing channel configs, calendar entries, and publishing schedules.

**Rationale**: Natural pairing with Firebase Auth, real-time listeners for UI updates, offline support, and no separate backend server needed. Channel configs in Firestore mirror (and can sync to) the JSON config files used by core engine.

**Alternatives considered**:
- Local JSON files via API: Would require a backend server
- SQLite: No multi-device access without a server

### 4. Plugin/hook architecture for brand extensions

**Choice**: Event-based hook system with a `BrandPluginRegistry`.

**Design**:
```
dashboard/src/hooks/plugin-registry.ts   — Central registry
dashboard/src/hooks/types.ts             — Hook type definitions
dashboard/plugins/dailywonders/           — Example brand plugin

Plugin interface:
  interface BrandPlugin {
    id: string;
    name: string;
    hooks: {
      onVideoScheduled?: (video, schedule) => void | Promise<void>;
      onVideoPublished?: (video, platform) => void | Promise<void>;
      onChannelConfigUpdated?: (config) => void | Promise<void>;
      renderScheduleExtras?: (schedule) => ReactNode;
      renderSettingsPanel?: () => ReactNode;
      getAdditionalPlatforms?: () => Platform[];
    }
  }
```

Plugins register via `registerPlugin()` at app startup. Core dashboard emits lifecycle events; plugins respond. Plugins render into designated extension points (slots) in the UI.

**Rationale**: Keeps core dashboard clean — DailyWonders can add SEO, auto-publish, social sharing as a plugin without touching core components. Plugins are isolated: one brand's plugin cannot break another.

**Alternatives considered**:
- Micro-frontends: Over-engineered for the current scale
- Backend webhooks: Adds latency, requires server — plugins should be client-side for now

### 5. Calendar implementation

**Choice**: Custom calendar component built on a date library (date-fns).

**Rationale**: Requires tight integration with video data model and the dark theme. Off-the-shelf calendar components (react-big-calendar, FullCalendar) bring heavy styling that conflicts with the design system.

**Views**: Week (default), Month, Year — each showing video cards with status badges.

### 6. Package-integrated architecture

**Choice**: Dashboard is bundled inside the `ai_director` Python package, served via `ad dashboard` CLI command.

**Design**:
```
dashboard/                       — React source (repo root, dev only)
├── src/
│   ├── components/              — Shared UI components
│   ├── features/
│   │   ├── auth/                — Login, AuthProvider, route guards
│   │   ├── channels/            — Channel config CRUD
│   │   ├── calendar/            — Calendar views (week/month/year)
│   │   └── schedule/            — Publishing schedule management
│   ├── hooks/                   — Plugin registry, shared React hooks
│   ├── lib/                     — Firebase config, utilities
│   ├── styles/                  — Design tokens, global styles
│   └── App.tsx
├── plugins/
│   └── dailywonders/            — Example brand plugin
├── package.json
├── vite.config.ts               — Builds to ai_director/dashboard/static/
└── vitest.config.ts

ai_director/dashboard/           — Python module (included in wheel)
├── __init__.py                  — Public API: launch_dashboard()
├── server.py                    — HTTP server serving static SPA + API
└── static/                      — Built React assets (generated by vite build)
```

**Build flow**: `cd dashboard && npm run build` → outputs to `ai_director/dashboard/static/`. The `pyproject.toml` includes these files in the wheel via hatch config.

**CLI**: `ad dashboard [--port 3456] [--host 0.0.0.0]` starts the server.

**Rationale**: Brands install `ai-director-core` as a pip dependency. When they upgrade, they get the latest dashboard. No separate deployment or npm install needed for end users.

**Alternatives considered**:
- Separate npm package: Requires brands to manage two package ecosystems
- Docker container: Over-complex for a dev/admin tool

### 7. Design system tokens

Extracted from `planning-agent.jsx`:

| Token | Value | Usage |
|-------|-------|-------|
| `--bg-primary` | `#0a0a0f` | App background |
| `--text-primary` | `#e8e6e0` | Main text |
| `--text-muted` | `#ffffff44` | Secondary text |
| `--accent` | `#f59e0b` | Primary accent (amber) |
| `--success` | `#10b981` | Active/success states |
| `--purple` | `#6366f1` | Content category |
| `--pink` | `#ec4899` | Income category |
| `--surface` | `#ffffff06` | Card backgrounds |
| `--border` | `#ffffff0a` | Subtle borders |
| `--font-sans` | `'DM Sans', sans-serif` | Body text |
| `--font-mono` | `'DM Mono', monospace` | Labels, metadata |

## Risks / Trade-offs

- **[Firestore costs at scale]** → Mitigation: Dashboard usage is low-volume (single admin, <100 channels). Firestore free tier is sufficient. Monitor usage.
- **[Plugin security]** → Mitigation: Plugins are first-party code bundled at build time, not runtime-loaded untrusted code. Plugin authors are trusted developers.
- **[Config drift between Firestore and JSON files]** → Mitigation: Implement a sync mechanism (export from Firestore → channel repo JSON). V1 treats Firestore as source of truth; CLI reads exported configs.
- **[Single point of failure on Firebase]** → Mitigation: Firebase has 99.95% SLA. For v1, acceptable. If needed later, abstract auth behind an interface.
- **[Calendar performance with many videos]** → Mitigation: Paginate by visible date range, lazy-load script content. Firestore queries are indexed by date.

## Open Questions

- Should the dashboard support multiple admin users in v1, or is single-admin sufficient?
- What is the deployment target — Firebase Hosting, Vercel, or self-hosted?
- Should channel config sync to Git repos be automated (via GitHub API) or manual export?
