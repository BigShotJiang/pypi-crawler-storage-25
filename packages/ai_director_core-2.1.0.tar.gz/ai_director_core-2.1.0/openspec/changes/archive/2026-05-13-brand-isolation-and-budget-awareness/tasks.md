## 1. Schema & Models — Brand Identity

- [x] 1.1 Tạo Pydantic models: `AudienceSegment`, `AudiencePlan`, `HookStrategy`, `ContentPlan`, `BrandIdentity` trong `ai_director/models/brand_identity.py`
- [x] 1.2 Thêm field `brand_identity: BrandIdentity` vào `ChannelConfig` model (optional với default để backward compatible)
- [x] 1.3 Viết unit tests cho `BrandIdentity` model validation — valid config, missing fields, invalid values

## 2. Schema & Models — Budget

- [x] 2.1 Tạo Pydantic models: `BudgetConfig` với `monthly_limit_usd`, `per_video_limit_usd`, `cost_allocation`, `alert_threshold_pct`, `hard_stop_threshold_pct` trong `ai_director/models/budget.py`
- [x] 2.2 Thêm field `budget: BudgetConfig | None` vào `ChannelConfig` model (optional, default = None = unlimited)
- [x] 2.3 Viết unit tests cho `BudgetConfig` validation — valid ranges, cost_allocation sums to 1.0, thresholds

## 3. Config Loader — Brand Isolation

- [x] 3.1 Update `load_channel_config()` để load và validate `brand_identity` và `budget` fields
- [x] 3.2 Enforce immutability — `ChannelConfig` instance phải frozen (Pydantic `model_config = ConfigDict(frozen=True)`)
- [x] 3.3 Thêm validation: config self-contained check — không reference external channel names/paths
- [x] 3.4 Viết tests cho config isolation — verify no global state, verify single config per load

## 4. Budget Tracker Module

- [x] 4.1 Tạo `ai_director/budget/tracker.py` với class `BudgetTracker` — `check_budget()`, `record_cost()`, `get_remaining()`
- [x] 4.2 Implement GCS persistence: read/write budget data từ `gs://ai-director-assets/{channel_name}/budget/`
- [x] 4.3 Implement local fallback: nếu GCS unavailable, persist to local file + retry sync
- [x] 4.4 Implement threshold logic: alert tại `alert_threshold_pct`, hard stop tại `hard_stop_threshold_pct`
- [x] 4.5 Implement per-video budget check: estimate cost trước mỗi agent step, fallback nếu vượt
- [x] 4.6 Viết unit tests cho BudgetTracker — track costs, threshold alerts, hard stops, per-video limits

## 5. Agent Updates — Brand Identity Awareness

- [x] 5.1 Update Script Writer agent: đọc `brand_identity.brand_voice`, `hook_strategy`, `audience_plan` khi generate script
- [x] 5.2 Update Shot List Director: respect `aspect_ratio` cho shot compositions (16:9 vs 9:16 vs 1:1)
- [x] 5.3 Update Asset Resolver: search/generate assets theo `aspect_ratio` và `brand_identity` visual preferences
- [x] 5.4 Update Motion Director: adapt motion parameters theo `aspect_ratio` và brand-specific motion config
- [x] 5.5 Update QA Validator: validate output against brand identity requirements (hooks, forbidden content, aspect ratio)
- [x] 5.6 Viết integration tests: agents produce correct output cho different brand configs (LostEras 9:16 vs QuietMind 16:9)

## 6. Agent Updates — Budget Integration

- [x] 6.1 Inject `BudgetTracker` vào pipeline runner — pass to agents qua dependency injection
- [x] 6.2 Wrap API calls (Claude, Pexels, Flux) với `budget_tracker.record_cost()` after each call
- [x] 6.3 Add pre-flight budget check trước mỗi agent: `budget_tracker.check_budget()` → skip/fallback/stop
- [x] 6.4 Implement fallback logic trong Asset Resolver: nếu budget gần limit, dùng Pexels thay vì Flux AI generation
- [x] 6.5 Viết tests cho budget-aware agent behavior — proceed, fallback, và stop scenarios

## 7. Pipeline & Workflow Updates

- [x] 7.1 Update `reusable-pipeline.yml`: thêm budget check step trước mỗi job
- [x] 7.2 Thêm budget summary step cuối pipeline: report costs incurred, remaining budget
- [x] 7.3 Add notification step: gửi Telegram alert khi budget threshold reached
- [x] 7.4 Update pipeline để pass `channel_name` explicitly vào mọi step (isolation enforcement)
- [x] 7.5 Add `budget_blocked` status cho topic queue khi pipeline bị stop do budget

## 8. CLI Updates

- [x] 8.1 Thêm command `ai-director budget status --config <path>` — hiển thị remaining budget, costs by category
- [x] 8.2 Update `ai-director validate` — validate `brand_identity` và `budget` fields
- [x] 8.3 Thêm command `ai-director migrate --config <path>` — auto-generate missing brand_identity/budget fields với defaults
- [x] 8.4 Update `ai-director init` — generate boilerplate channel_config.json với brand_identity và budget sections

## 9. GCS & Storage

- [x] 9.1 Implement GCS path enforcement: validate all read/write paths match `{channel_name}/` prefix
- [x] 9.2 Tạo budget data storage structure: `{channel_name}/budget/monthly/{YYYY-MM}.json`
- [x] 9.3 Add pipeline logs với `channel_name` scope identifier cho audit trail

## 10. Documentation & Migration

- [x] 10.1 Viết MIGRATION.md: hướng dẫn existing channels thêm brand_identity và budget fields
- [x] 10.2 Update channel_config.json templates trong channel-template repo với brand_identity và budget sections
- [x] 10.3 Update CHANGELOG.md cho version mới
