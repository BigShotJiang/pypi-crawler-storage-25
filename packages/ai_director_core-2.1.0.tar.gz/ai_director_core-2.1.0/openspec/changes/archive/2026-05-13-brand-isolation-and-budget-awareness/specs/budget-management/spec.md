## ADDED Requirements

### Requirement: Budget configuration per brand
The system SHALL support a `budget` object in `channel_config.json` that defines spending limits for each brand. Budget is independently configured by each brand.

#### Scenario: Brand defines monthly and per-video budget
- **WHEN** a channel repo includes `budget.monthly_limit_usd` and `budget.per_video_limit_usd`
- **THEN** the config loader SHALL validate these values and the budget tracker SHALL enforce them during pipeline execution

#### Scenario: Brand defines cost allocation
- **WHEN** `budget.cost_allocation` specifies percentage splits (e.g., `{"api_calls": 0.6, "asset_gen": 0.3, "storage": 0.1}`)
- **THEN** the budget tracker SHALL track costs per category and enforce category-level limits

### Requirement: Runtime budget tracking
The system SHALL track actual costs incurred during each pipeline run and accumulate them per channel per billing period (monthly).

#### Scenario: Cost recorded after API call
- **WHEN** an agent makes an API call (Claude, Pexels, Flux)
- **THEN** the budget tracker SHALL record the estimated cost of that call against the channel's budget

#### Scenario: Cost data persisted to GCS
- **WHEN** a pipeline run completes (success or failure)
- **THEN** the budget tracker SHALL persist the accumulated cost data to `gs://ai-director-assets/{channel_name}/budget/` for historical tracking

### Requirement: Budget enforcement with thresholds
The system SHALL enforce budget limits using configurable alert and hard-stop thresholds.

#### Scenario: Alert threshold reached
- **WHEN** accumulated costs reach `budget.alert_threshold_pct` (default 80%) of the monthly limit
- **THEN** the system SHALL send a notification via configured channels (e.g., Telegram) but SHALL continue execution

#### Scenario: Hard stop threshold reached
- **WHEN** accumulated costs reach `budget.hard_stop_threshold_pct` (default 100%) of the monthly limit
- **THEN** the pipeline SHALL stop execution, mark the topic as `budget_blocked`, and notify via configured channels

#### Scenario: Per-video budget exceeded mid-pipeline
- **WHEN** estimated cost of the next agent step would exceed `budget.per_video_limit_usd`
- **THEN** the pipeline SHALL skip optional expensive operations (e.g., AI generation) and fall back to cheaper alternatives (e.g., Pexels search), or stop if no alternatives exist

### Requirement: Budget reporting via CLI
The system SHALL provide CLI commands to query budget status for any channel.

#### Scenario: Check remaining budget
- **WHEN** user runs `ai-director budget status --config <path>`
- **THEN** the system SHALL display remaining monthly budget, costs by category, and number of videos produced this period
