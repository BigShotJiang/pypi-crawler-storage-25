## ADDED Requirements

### Requirement: Config-level brand isolation
The system SHALL ensure each brand's configuration is loaded in complete isolation. No brand config SHALL influence or be accessible to another brand's pipeline run.

#### Scenario: Single config per pipeline run
- **WHEN** the pipeline starts for a specific channel
- **THEN** the config loader SHALL load exactly one `ChannelConfig` from the channel's `channel_config.json` and SHALL NOT access any other channel's config

#### Scenario: No global or shared config state
- **WHEN** multiple channels are configured in the system
- **THEN** there SHALL be no singleton, global variable, or shared state that could leak config between channels

### Requirement: Runtime data isolation
The system SHALL ensure runtime data (assets, outputs, budget tracking) is scoped exclusively to the owning brand.

#### Scenario: GCS path enforcement
- **WHEN** any agent reads or writes assets on GCS
- **THEN** the system SHALL enforce that all paths are prefixed with `gs://ai-director-assets/{channel_name}/` and SHALL reject any path that references a different channel

#### Scenario: Budget data isolation
- **WHEN** the budget tracker reads or writes cost data
- **THEN** it SHALL only access data under the current channel's namespace and SHALL NOT aggregate or compare with other channels

### Requirement: Brand-specific settings priority
The system SHALL prioritize brand-specific configuration over any system defaults. Brand settings MUST NOT conflict with other brands.

#### Scenario: Brand overrides default motion style
- **WHEN** a brand's config specifies `motion.default_style: "ultra_slow_breathe"` while another brand uses `"slow_cinematic"`
- **THEN** each brand's pipeline SHALL use its own motion style independently without any interference

#### Scenario: Different aspect ratios across brands
- **WHEN** brand A uses `aspect_ratio: "9:16"` and brand B uses `aspect_ratio: "16:9"`
- **THEN** each pipeline run SHALL produce output in its respective format with no shared rendering state

### Requirement: Isolation validation
The system SHALL provide validation to verify brand isolation is maintained.

#### Scenario: Config validation catches cross-references
- **WHEN** `ai-director validate --config <path>` is run
- **THEN** the validator SHALL check that the config is self-contained and does not reference external channel names, paths, or configs

#### Scenario: Pipeline logs include isolation context
- **WHEN** a pipeline run executes
- **THEN** all log entries SHALL include `channel_name` as a scoped identifier to enable auditing of isolation compliance
