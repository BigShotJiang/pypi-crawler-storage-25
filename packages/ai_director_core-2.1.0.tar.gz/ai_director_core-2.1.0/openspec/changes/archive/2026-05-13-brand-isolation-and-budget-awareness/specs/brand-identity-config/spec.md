## ADDED Requirements

### Requirement: Brand identity configuration
The system SHALL support a `brand_identity` object in `channel_config.json` that allows each brand to define its unique audience plan, hook strategies, content plan, brand voice, and competitive differentiation.

#### Scenario: Brand defines audience plan
- **WHEN** a channel repo includes `brand_identity.audience_plan` with primary segments, content goals, and engagement strategy
- **THEN** the config loader SHALL validate and load the audience plan, making it available to all agents

#### Scenario: Brand defines custom hook strategy
- **WHEN** a channel repo specifies `brand_identity.hook_strategy` with primary hooks, forbidden hooks, and test criteria
- **THEN** the Script Writer agent SHALL use only the primary hooks and SHALL NOT use any forbidden hooks

#### Scenario: Brand defines unique selling points
- **WHEN** `brand_identity.unique_selling_points` and `brand_identity.competitor_differentiation` are provided
- **THEN** agents SHALL incorporate these differentiators into content generation to maintain brand uniqueness

### Requirement: Agents use brand identity for creative decisions
The system SHALL ensure all agents read and respect brand-specific configuration when making creative decisions. Brand-specific settings SHALL take priority over any default behavior.

#### Scenario: Script Writer uses brand voice
- **WHEN** the Script Writer agent generates a script
- **THEN** it SHALL use `brand_identity.brand_voice` as the primary tone directive, combined with `narrative.tone`

#### Scenario: Content plan influences topic selection
- **WHEN** the pipeline picks a topic from the queue
- **THEN** it SHALL consider `brand_identity.content_plan` to prioritize topics aligned with the brand's content strategy

### Requirement: Aspect ratio driven by brand config
The system SHALL adapt the entire pipeline output based on the `aspect_ratio` field in each brand's config. Each brand independently decides its video format.

#### Scenario: Brand uses 16:9 landscape format
- **WHEN** a brand's config specifies `aspect_ratio: "16:9"`
- **THEN** Shot List Director SHALL generate shot compositions for landscape, Asset Resolver SHALL search/generate landscape assets, and Motion Director SHALL use landscape-appropriate motion parameters

#### Scenario: Brand uses 9:16 portrait format
- **WHEN** a brand's config specifies `aspect_ratio: "9:16"`
- **THEN** the pipeline SHALL produce portrait-oriented output with vertical compositions and vertical-optimized text placement
