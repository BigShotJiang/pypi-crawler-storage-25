## Context

AI Director hiện có kiến trúc hai tầng: core library (ai-director-core) chứa toàn bộ logic, và channel repos chỉ chứa `channel_config.json` + `topics_queue.json`. Hiện tại schema `ChannelConfig` đã có các fields cơ bản (narrative, visual, motion), nhưng thiếu:

1. **Brand identity layer** — không có chỗ để brand định nghĩa audience plan, hook strategy, content calendar riêng
2. **Budget awareness** — core engine không biết brand nào có budget bao nhiêu, không track chi phí, không enforce limits
3. **Isolation guarantees** — tuy assets đã tách folder trên GCS, nhưng không có cơ chế runtime đảm bảo config/data không cross-contaminate

Kiến trúc hiện tại dùng Pydantic để validate config, CLI `ai-director` làm entry point, và GitHub Actions reusable workflow để orchestrate pipeline.

## Goals / Non-Goals

**Goals:**
- Mỗi brand có thể định nghĩa audience plan, hook strategies, content plan, brand voice chi tiết trong `channel_config.json`
- Core engine đọc và ưu tiên brand-specific config khi quyết định creative direction
- Budget configuration per-brand: spending limits cho API calls, asset generation, storage
- Runtime budget tracking và enforcement (warn → block khi vượt)
- Format video (aspect_ratio) hoàn toàn do brand quyết định, core adapt theo
- Zero cross-contamination giữa brands ở mọi layer (config, runtime, storage)

**Non-Goals:**
- Billing system / payment integration — budget tracking là internal cost control, không phải billing
- Real-time dashboard cho budget — chỉ cần CLI reports và alerts (Telegram)
- Shared asset library giữa brands — mỗi brand có assets riêng
- Multi-tenant deployment — mỗi brand vẫn là repo riêng, không phải SaaS

## Decisions

### 1. Brand Identity as nested config object (không phải separate file)

**Decision**: Thêm `brand_identity` object vào `channel_config.json` thay vì tạo file riêng.

**Rationale**: Giữ nguyên nguyên tắc "1 config file = DNA of channel". Tách ra file riêng tạo complexity không cần thiết — phải sync 2 files, validate cross-references.

**Alternatives considered**:
- Separate `brand_identity.json` file — bị reject vì tăng coupling, channel repo phải maintain thêm file
- Environment variables — không phù hợp cho structured data (audience segments, hook formulas)

**Structure**:
```python
class AudiencePlan(BaseModel):
    primary_segments: list[AudienceSegment]
    content_goals: list[str]
    engagement_strategy: str

class HookStrategy(BaseModel):
    primary_hooks: list[str]          # Hook formulas ưu tiên
    forbidden_hooks: list[str]        # Hooks không được dùng
    hook_test_criteria: str           # Tiêu chí đánh giá hook quality

class BrandIdentity(BaseModel):
    brand_voice: str                  # Personality & tone chi tiết
    audience_plan: AudiencePlan
    hook_strategy: HookStrategy
    content_plan: ContentPlan
    unique_selling_points: list[str]
    competitor_differentiation: str   # Điều gì khác biệt so với competitors
```

### 2. Budget as config + runtime tracker (hybrid approach)

**Decision**: Budget limits định nghĩa trong `channel_config.json`, runtime tracking qua `BudgetTracker` module trong core, persist data trên GCS per-channel.

**Rationale**: Config-driven limits giữ nguyên pattern hiện tại (channel chỉ cần edit JSON). Runtime tracker trong core đảm bảo enforcement nhất quán.

**Alternatives considered**:
- External budget service (Redis/DB) — over-engineering cho use case này
- Budget chỉ trong CI env vars — không structured, khó validate

**Structure**:
```python
class BudgetConfig(BaseModel):
    monthly_limit_usd: float
    per_video_limit_usd: float
    cost_allocation: dict[str, float]  # {"api_calls": 0.6, "asset_gen": 0.3, "storage": 0.1}
    alert_threshold_pct: float = 0.8   # Alert khi đạt 80%
    hard_stop_threshold_pct: float = 1.0
    notification_channels: list[str] = ["telegram"]

class BudgetTracker:
    """Track và enforce budget constraints per pipeline run."""
    def check_budget(self, channel: str, cost_type: str, estimated_cost: float) -> BudgetDecision
    def record_cost(self, channel: str, cost_type: str, actual_cost: float) -> None
    def get_remaining(self, channel: str) -> BudgetSummary
```

### 3. Brand isolation via namespace-scoped config loading

**Decision**: `ConfigLoader` enforce rằng mỗi pipeline run chỉ nhìn thấy config của chính brand đó. Không có global state, không có shared config.

**Rationale**: Đã có tách folder trên GCS. Cần thêm runtime isolation: config loader nhận 1 config path, load 1 `ChannelConfig`, truyền xuống tất cả agents. Không có singleton/global config.

**Implementation**:
- `load_channel_config(path)` trả về immutable `ChannelConfig` — agents nhận qua dependency injection
- `BudgetTracker` scoped by `channel_name` — mỗi instance chỉ track 1 channel
- GCS paths enforce: `gs://ai-director-assets/{channel_name}/` — không thể access folder channel khác
- Pipeline workflow truyền `channel_name` vào mọi step, không derive từ global state

### 4. Aspect ratio adaptation at agent level

**Decision**: Mỗi agent đọc `aspect_ratio` từ config và adapt output tương ứng. Không có hardcoded assumption về format.

**Rationale**: Đã có field `aspect_ratio` trong schema hiện tại, nhưng agents chưa dùng nó consistently. Cần enforce rằng Shot List Director, Asset Resolver, và Motion Director đều respect field này.

## Risks / Trade-offs

- **[Schema migration]** → Existing channels phải thêm `brand_identity` và `budget` fields. Mitigation: Core cung cấp migration script + sensible defaults cho optional fields. Giai đoạn đầu `budget` có thể optional (default = unlimited).
- **[Budget tracking accuracy]** → Estimated costs cho API calls có thể không chính xác 100%. Mitigation: Dùng conservative estimates, thêm buffer 10% vào tracking.
- **[GCS cost data persistence]** → Nếu GCS unavailable, budget tracking mất data. Mitigation: Local fallback file + retry logic.
- **[Config complexity tăng]** → `channel_config.json` sẽ dài hơn đáng kể. Mitigation: Cung cấp templates với comments, CLI `ai-director init` generate boilerplate.

## Migration Plan

1. Release core version mới với `brand_identity` và `budget` fields **optional** (có defaults)
2. Existing channels chạy bình thường không cần thay đổi
3. Cung cấp `ai-director migrate --config <path>` để auto-generate missing fields
4. Sau 1 release cycle, mark fields là required trong minor version tiếp theo
5. Rollback: Channels giữ nguyên version cũ trong `requirements.txt`

## Open Questions

- Nên lưu budget tracking data ở GCS (simple, stateless) hay SQLite trên GCS (structured queries)?
- Có cần monthly budget reset tự động hay manual reset qua CLI?
- Hook strategy nên validate ở config time hay runtime (khi agent generate hooks)?
