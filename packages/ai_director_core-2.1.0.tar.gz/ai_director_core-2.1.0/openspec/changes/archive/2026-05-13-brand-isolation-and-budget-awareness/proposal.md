## Why

Hiện tại kiến trúc AI Director multi-repo đã tách rõ Core (logic) và Channel repos (config). Tuy nhiên mỗi brand (channel repo) chưa có cơ chế để định nghĩa **audience plan, hook strategy, và budget riêng** một cách có cấu trúc. Core engine cũng chưa có khả năng **phân biệt và ưu tiên** các cấu hình đặc trưng của từng brand, hay **giới hạn chi phí** theo budget mà mỗi brand quyết định. Điều này cần giải quyết trước khi scale lên nhiều channels để tránh conflict và vượt ngân sách.

## What Changes

- Mở rộng `channel_config.json` schema để hỗ trợ **brand-specific audience plan**, **custom hook strategies**, và **content plan** riêng cho từng brand
- Thêm **budget configuration** vào `channel_config.json` — mỗi brand tự quyết định gói budget (API calls, asset generation, storage)
- Core engine đọc và **ưu tiên brand-specific config** khi chạy pipeline — đảm bảo không conflict giữa các brands
- Thêm **budget enforcement** trong pipeline — track chi phí, cảnh báo khi gần limit, block khi vượt budget
- Hỗ trợ cả **16:9 và 9:16** (và 1:1) tuỳ theo cấu hình từng brand, core engine phải adapt rendering pipeline theo `aspect_ratio` của brand đó
- **BREAKING**: `channel_config.json` schema sẽ có thêm các fields bắt buộc mới (`brand_identity`, `budget`)

## Capabilities

### New Capabilities
- `brand-identity-config`: Schema mở rộng cho brand-specific configuration — audience plan, hook strategies, content calendar, brand voice, và visual identity riêng cho từng channel repo
- `budget-management`: Hệ thống quản lý budget cho từng brand — định nghĩa spending limits, track API/asset costs, enforce budget constraints trong pipeline execution
- `brand-isolation`: Cơ chế đảm bảo cấu hình và data của từng brand hoàn toàn độc lập — không cross-contamination giữa brands, ưu tiên brand-specific settings

### Modified Capabilities

_(Không có specs hiện tại để modify)_

## Impact

- **Schema**: `ChannelConfig` Pydantic model cần thêm `BrandIdentity`, `BudgetConfig` models mới
- **Core agents**: Tất cả 5 agents cần đọc và respect brand-specific config (tone, hooks, audience) và budget limits
- **Pipeline**: `reusable-pipeline.yml` cần thêm budget tracking steps và budget gate checks giữa các jobs
- **CLI**: `ai-director validate` cần validate thêm brand identity và budget fields
- **Channel repos**: Tất cả existing channels cần migration guide để thêm fields mới vào `channel_config.json`
- **GCP**: Budget tracking data cần storage riêng per-channel trong GCS bucket
- **Dependencies**: Có thể cần thêm cost tracking library hoặc custom module
