## 1. Scaffold Module

- [x] 1.1 Tạo `ai_director/scaffold.py` với interactive prompt functions: `_ask()`, `_ask_choice()`, `_ask_float()`
- [x] 1.2 Implement `_generate_channel_config()` — tạo dict channel_config.json từ user input
- [x] 1.3 Implement `_generate_workflow()` — tạo string `.github/workflows/pipeline.yml` gọi reusable pipeline
- [x] 1.4 Implement `_generate_requirements()` — đọc version từ pyproject.toml, tạo `requirements.txt`
- [x] 1.5 Implement `_generate_topics_queue()` — tạo empty topics queue `data/topics_queue.json`
- [x] 1.6 Implement `run_scaffold()` — orchestrate: collect input → generate files → write to output-dir

## 2. CLI Integration

- [x] 2.1 Thêm `scaffold` subcommand vào `runner.py` với args: `--output-dir`, `--non-interactive`, `--name`, `--niche`, `--voice`, `--audience`, `--aspect-ratio`, `--duration`, `--budget-monthly`, `--budget-per-video`
- [x] 2.2 Wire `_cmd_scaffold()` trong runner.py gọi `scaffold.run_scaffold()`

## 3. Tests

- [x] 3.1 Test scaffold generates all 4 files với correct structure
- [x] 3.2 Test non-interactive mode với CLI args
- [x] 3.3 Test default values applied correctly
- [x] 3.4 Test invalid aspect ratio rejected
- [x] 3.5 Test generated config validates qua `load_channel_config()`

## 4. README

- [x] 4.1 Viết README.md: Architecture overview + data flow diagram
- [x] 4.2 Viết README.md: Tech stack section
- [x] 4.3 Viết README.md: Installation + development setup
- [x] 4.4 Viết README.md: CLI reference cho tất cả commands (run, validate, agent, budget, migrate, init, scaffold)
- [x] 4.5 Viết README.md: Project structure tree
- [x] 4.6 Viết README.md: Quickstart guide (scaffold → add topic → run pipeline)
