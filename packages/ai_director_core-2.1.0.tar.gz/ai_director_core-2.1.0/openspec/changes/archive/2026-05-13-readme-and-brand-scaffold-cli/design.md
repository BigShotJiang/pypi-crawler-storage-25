## Context

ai-director-core v2.0.0 đã có đầy đủ agents, models, budget tracking, và pipeline orchestration. Tuy nhiên:
1. README.md chỉ có 1 dòng — người mới không biết cách cài đặt hay sử dụng
2. Onboarding brand mới hoàn toàn thủ công: phải tự tạo 4+ files đúng format, dễ sai cấu trúc

Hệ thống đã có `ai-director init` tạo config template, nhưng chỉ tạo 1 file `channel_config.json`. Chưa có scaffold tạo toàn bộ channel repo structure (workflow, requirements, topics queue).

## Goals / Non-Goals

**Goals:**
- README.md mô tả đầy đủ: architecture, tech stack, install, CLI commands, project structure
- `ai-director scaffold` interactive wizard tạo toàn bộ channel repo files trong 1 lần chạy
- Scaffold output có thể dùng trực tiếp — push lên GitHub là pipeline chạy được

**Non-Goals:**
- Không tự động tạo GitHub repo (chỉ tạo local files)
- Không thay thế `ai-director init` (init vẫn giữ cho quick single-file use case)
- Không support custom workflow templates (dùng template cố định)

## Decisions

### 1. Scaffold dùng stdlib `input()` thay vì thêm dependency

**Chọn**: Dùng Python stdlib (`input()` + simple prompts)
**Lý do**: Không muốn thêm dependency (`questionary`, `inquirer`) chỉ cho 1 command. Hệ thống chạy chủ yếu trong CI, interactive prompts phức tạp không cần thiết.
**Alternative**: `questionary` library — đẹp hơn nhưng thêm dependency cho minimal value.

### 2. Scaffold tạo files vào output directory, không khởi tạo git repo

**Chọn**: Tạo files vào `--output-dir` (default: current directory)
**Lý do**: User có thể đã init git repo trước, hoặc muốn scaffold vào existing directory. Chỉ tạo files, không chạy `git init`.

### 3. Scaffold module riêng `ai_director/scaffold.py`

**Chọn**: Module riêng thay vì thêm vào `runner.py`
**Lý do**: `runner.py` đã 280+ lines. Scaffold logic phức tạp (template generation, interactive prompts, file writing) nên tách riêng.

### 4. README structure theo conventional format

**Chọn**: Overview → Architecture → Tech Stack → Install → CLI Reference → Project Structure → Contributing
**Lý do**: Standard format mà developer quen thuộc, dễ scan.

## Risks / Trade-offs

- **[Risk] Scaffold output lạc hậu so với core** → Mitigation: Scaffold đọc `pyproject.toml` version dynamically để pin đúng version trong generated `requirements.txt`
- **[Risk] Workflow template hardcoded** → Mitigation: Acceptable cho v1. Nếu cần custom workflows sau này thì extend scaffold với template engine
- **[Trade-off] stdlib input() không có validation UX đẹp** → Acceptable. Scaffold chạy 1 lần per brand, không cần polish
