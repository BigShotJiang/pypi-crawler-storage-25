## ADDED Requirements

### Requirement: README contains architecture overview
README.md SHALL include an architecture overview section explaining the two-tier structure: Core Library (ai-director-core) and Channel Repos (configuration-only).

#### Scenario: Developer reads architecture section
- **WHEN** developer opens README.md
- **THEN** they SHALL find a clear description of the core/channel separation, data flow, and multi-repo strategy

### Requirement: README contains tech stack
README.md SHALL list the primary tech stack: Python 3.11+, Pydantic v2, Anthropic Claude, Hatchling, GitHub Actions, GCS.

#### Scenario: Developer checks tech stack
- **WHEN** developer reads the Tech Stack section
- **THEN** they SHALL find all major dependencies and their purposes listed

### Requirement: README contains installation instructions
README.md SHALL include installation instructions for both development (editable install) and production (pip install from package registry).

#### Scenario: Developer installs for development
- **WHEN** developer follows the installation section
- **THEN** they SHALL be able to run `pip install -e .` and use the `ai-director` CLI

### Requirement: README contains CLI reference
README.md SHALL document all available CLI commands: `run`, `validate`, `agent`, `budget status`, `migrate`, `init`, and `scaffold`.

#### Scenario: Developer looks up CLI command
- **WHEN** developer reads CLI Reference section
- **THEN** they SHALL find usage, arguments, and examples for every command

### Requirement: README contains project structure
README.md SHALL include the project directory structure showing the organization of agents, models, budget, lib, and tests.

#### Scenario: Developer checks project layout
- **WHEN** developer reads the Project Structure section
- **THEN** they SHALL see a tree view of the `ai_director/` package and key files

### Requirement: README contains quickstart guide
README.md SHALL include a quickstart section showing how to scaffold a new brand and run the pipeline end-to-end.

#### Scenario: New user follows quickstart
- **WHEN** user follows the Quickstart section steps
- **THEN** they SHALL be able to scaffold a brand, create a topic, and run the pipeline
