## ADDED Requirements

### Requirement: Scaffold interactive wizard
The system SHALL provide an `ai-director scaffold` CLI command that interactively collects brand information and generates a complete channel repo structure.

The wizard SHALL prompt for:
1. Channel name (required)
2. Channel niche (required)
3. Target platform (default: youtube_shorts)
4. Language (default: en)
5. Aspect ratio (choices: 9:16, 16:9, 1:1 — default: 9:16)
6. Video duration in seconds (default: 60)
7. Brand voice / narrative tone (required)
8. Target audience description (required)
9. Monthly budget limit USD (default: 100)
10. Per-video budget limit USD (default: 5)

#### Scenario: Successful scaffold with all defaults
- **WHEN** user runs `ai-director scaffold` and provides only channel name, niche, brand voice, and audience
- **THEN** system generates files with sensible defaults for all other fields

#### Scenario: Successful scaffold with custom values
- **WHEN** user provides custom aspect ratio "16:9", budget "$200/month", and duration "90"
- **THEN** generated `channel_config.json` SHALL reflect those custom values

#### Scenario: User provides invalid aspect ratio
- **WHEN** user enters an aspect ratio not in [9:16, 16:9, 1:1]
- **THEN** system SHALL re-prompt with valid choices

### Requirement: Scaffold generates complete channel repo structure
The scaffold command SHALL generate the following files in the output directory:

1. `data/channel_config.json` — full config with brand_identity and budget sections
2. `.github/workflows/pipeline.yml` — GitHub Actions workflow calling the reusable pipeline
3. `requirements.txt` — pinning `ai-director-core` to current version
4. `data/topics_queue.json` — empty topics queue with correct schema

#### Scenario: All files created in output directory
- **WHEN** scaffold completes successfully with `--output-dir ./my-brand`
- **THEN** all 4 files SHALL exist under `./my-brand/` with correct directory structure

#### Scenario: Generated workflow calls reusable pipeline
- **WHEN** scaffold generates `.github/workflows/pipeline.yml`
- **THEN** workflow SHALL use `workflow_call` to reference `ai-director-core` reusable pipeline with `channel_name` input

#### Scenario: Requirements file pins current core version
- **WHEN** scaffold generates `requirements.txt`
- **THEN** it SHALL contain `ai-director-core==<current_version>` read from pyproject.toml

### Requirement: Scaffold output directory control
The scaffold command SHALL accept `--output-dir <path>` argument (default: current directory). Directories SHALL be created automatically if they don't exist.

#### Scenario: Default output directory
- **WHEN** user runs `ai-director scaffold` without `--output-dir`
- **THEN** files SHALL be created in the current working directory

#### Scenario: Custom output directory
- **WHEN** user runs `ai-director scaffold --output-dir /tmp/new-brand`
- **THEN** files SHALL be created under `/tmp/new-brand/`

#### Scenario: Non-existent output directory
- **WHEN** `--output-dir` points to a directory that doesn't exist
- **THEN** system SHALL create it (including parent directories)

### Requirement: Scaffold non-interactive mode
The scaffold command SHALL support `--non-interactive` flag with all values provided as CLI arguments for CI/scripting use.

#### Scenario: Non-interactive scaffold
- **WHEN** user runs `ai-director scaffold --non-interactive --name "MyBrand" --niche "tech" --voice "casual" --audience "developers" --aspect-ratio "16:9"`
- **THEN** system SHALL generate all files without prompting for input
