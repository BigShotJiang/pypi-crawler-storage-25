## Why

README.md hiện tại chỉ có 1 dòng tiêu đề, thiếu hoàn toàn hướng dẫn sử dụng, tech stack, architecture overview, và CLI reference. Đồng thời, quy trình onboarding brand mới vẫn hoàn toàn thủ công — người dùng phải tự tạo repo, viết config, tạo workflow, và đảm bảo đúng cấu trúc. Cần một CLI interactive scaffold để tự động hóa toàn bộ quá trình này.

## What Changes

- **Update README.md**: Viết lại hoàn chỉnh với architecture overview, tech stack, installation, CLI reference, project structure, và quickstart guide
- **Thêm `ai-director scaffold` CLI command**: Interactive wizard hỏi thông tin brand (tên, niche, aspect ratio, budget, audience, tone...) rồi tự động tạo toàn bộ file structure cho channel repo mới:
  - `data/channel_config.json` — config đầy đủ từ input
  - `.github/workflows/pipeline.yml` — workflow gọi vào reusable pipeline
  - `requirements.txt` — pin core version
  - `data/topics_queue.json` — file queue rỗng sẵn format

## Capabilities

### New Capabilities
- `brand-scaffold-cli`: Interactive CLI wizard (`ai-director scaffold`) tạo toàn bộ channel repo structure từ user input — bao gồm config, workflow, dependencies, và topics queue
- `readme-docs`: README.md hoàn chỉnh với tech stack, architecture, installation, CLI reference, project structure

### Modified Capabilities
_(none — no existing spec requirements are changing)_

## Impact

- `ai_director/runner.py`: Thêm `scaffold` subcommand
- `ai_director/scaffold.py`: Module mới chứa logic interactive wizard và file generation
- `README.md`: Viết lại hoàn toàn
- `pyproject.toml`: Có thể thêm dependency nếu cần (e.g. `questionary` cho interactive prompts, hoặc dùng stdlib)
- No breaking changes — purely additive
