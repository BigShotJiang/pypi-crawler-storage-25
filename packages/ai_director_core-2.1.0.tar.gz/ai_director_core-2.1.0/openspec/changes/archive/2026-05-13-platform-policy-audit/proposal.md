## Why

Video tạo bởi AI Director phải tuân thủ 100% chính sách nội dung của nền tảng đích (YouTube, TikTok, Instagram Reels). Hiện tại QA Validator chỉ kiểm tra brand constraints (hooks, tone, aspect ratio) — **không hề kiểm tra platform policy**. Một video vi phạm policy có thể bị gỡ, dẫn đến mất channel, ban account, hoặc demonetize. Không có ngoại lệ nào được chấp nhận.

## What Changes

- **Thêm Platform Policy Registry**: Module chứa policy rules cho từng nền tảng (YouTube Community Guidelines, TikTok Community Guidelines, IG Reels policies). Mỗi platform có danh sách forbidden content categories, content restrictions, và metadata requirements.
- **Thêm Policy Audit Agent**: Agent mới (`PolicyAuditor`) kiểm tra toàn bộ output pipeline (script, shot list, assets, motion) dựa trên policy rules. Audit ở 2 cấp: text-based rule matching + AI-powered semantic check.
- **Pipeline integration**: Policy audit chạy **trước** QA Validator và là **hard gate** — nếu fail thì pipeline STOP, video KHÔNG được xuất. Không có override/bypass.
- **CLI command**: `ad audit --config <path> --input <video_package>` để audit thủ công bất kỳ video package nào.

## Capabilities

### New Capabilities
- `policy-registry`: Platform policy rules registry — chứa và quản lý policy rules cho YouTube, TikTok, Instagram Reels. Có thể cập nhật policy khi nền tảng thay đổi quy định.
- `policy-auditor`: Policy Audit Agent — kiểm tra toàn bộ pipeline output chống lại policy rules. Hard gate, zero tolerance.
- `audit-cli`: CLI command `ad audit` để kiểm tra video package thủ công.

### Modified Capabilities
_(none — QA Validator vẫn giữ nguyên, policy audit là layer riêng phía trước)_

## Impact

- `ai_director/policies/` — module mới chứa policy registry
- `ai_director/agents/policy_auditor.py` — agent mới
- `ai_director/pipeline.py` — thêm policy audit step trước QA
- `ai_director/runner.py` — thêm `audit` subcommand
- `ai_director/models/config.py` — có thể thêm `target_platform` vào danh sách supported platforms
- `.github/workflows/reusable-pipeline.yml` — thêm policy-audit job
