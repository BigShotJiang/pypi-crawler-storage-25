## 1. Policy Registry

- [x] 1.1 Tạo `ai_director/policies/__init__.py` — base types: `PolicyRule`, `PlatformPolicy`, `get_policy(platform)`
- [x] 1.2 Tạo `ai_director/policies/youtube.py` — YouTube Community Guidelines rules (8 categories)
- [x] 1.3 Tạo `ai_director/policies/tiktok.py` — TikTok Community Guidelines rules (8 categories)
- [x] 1.4 Tạo `ai_director/policies/instagram.py` — Instagram Reels policy rules
- [x] 1.5 Tests cho policy registry: load, structure validation, freshness date

## 2. Policy Auditor Agent

- [x] 2.1 Tạo `ai_director/agents/policy_auditor.py` — PolicyAuditor agent với `run()` method
- [x] 2.2 Implement Tier 1: rule-based keyword/pattern matching trên script, shots, assets
- [x] 2.3 Implement Tier 2: AI semantic check stub (placeholder cho Claude integration)
- [x] 2.4 Implement audit result model: `AuditResult(status, violations, checks_performed)`
- [x] 2.5 Tests cho PolicyAuditor: pass case, fail case, multi-layer audit, zero tolerance

## 3. Pipeline Integration

- [x] 3.1 Update `pipeline.py` — thêm PolicyAuditor vào pipeline sau MotionDirector, trước QAValidator
- [x] 3.2 Policy fail = hard stop: `status: "policy_violation"`, không produce video
- [x] 3.3 Tests cho pipeline với policy audit: pass-through, hard stop on violation

## 4. CLI Integration

- [x] 4.1 Thêm `audit` subcommand vào `runner.py`
- [x] 4.2 Implement `--check-freshness` flag
- [x] 4.3 Tests cho audit CLI command

## 5. Workflow Update

- [x] 5.1 Thêm `policy-audit` job vào `reusable-pipeline.yml` giữa motion-director và qa-validator
- [x] 5.2 Update README.md — document `ad audit` command và policy audit feature
