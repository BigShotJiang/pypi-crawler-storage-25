## ADDED Requirements

### Requirement: Manual audit CLI command
The system SHALL provide `ad audit` CLI command that audits a video package JSON file against the platform policy for a given channel config.

#### Scenario: Audit a video package
- **WHEN** user runs `ad audit --config data/channel_config.json --input video_package.json`
- **THEN** the system SHALL load the channel config, determine the target platform, run full policy audit, and print results

#### Scenario: Audit pass output
- **WHEN** audit passes
- **THEN** the system SHALL print "✅ Policy audit passed" with a summary of checks performed

#### Scenario: Audit fail output
- **WHEN** audit finds violations
- **THEN** the system SHALL print each violation with: rule_id, category, severity, matched content, and exit with non-zero status

#### Scenario: Check policy freshness
- **WHEN** user runs `ad audit --check-freshness`
- **THEN** the system SHALL display the `last_updated` date of each platform's policy rules and warn if any are older than 90 days
