## ADDED Requirements

### Requirement: Platform policy rules registry
The system SHALL maintain a registry of content policy rules for each supported platform (YouTube, TikTok, Instagram Reels). Each platform's policy SHALL include forbidden content categories, forbidden keywords/patterns, content restrictions, and metadata requirements.

#### Scenario: YouTube policy loaded
- **WHEN** a channel config specifies `target_platform: "youtube_shorts"`
- **THEN** the system SHALL load YouTube Community Guidelines rules including categories: violent_graphic, hate_speech, harassment, dangerous_acts, misinformation, sexually_explicit, spam_deceptive, child_safety

#### Scenario: TikTok policy loaded
- **WHEN** a channel config specifies `target_platform: "tiktok"`
- **THEN** the system SHALL load TikTok Community Guidelines rules including categories: violence, hate, harassment, nudity, minor_safety, misinformation, dangerous_activities, regulated_goods

#### Scenario: Instagram Reels policy loaded
- **WHEN** a channel config specifies `target_platform: "instagram_reels"`
- **THEN** the system SHALL load Instagram Community Guidelines rules

#### Scenario: Policy freshness tracking
- **WHEN** any policy module is loaded
- **THEN** the system SHALL expose a `last_updated` date to allow freshness checks

### Requirement: Policy rules structure
Each policy rule SHALL contain: rule_id, category, severity (always "block"), description, forbidden_keywords (list of patterns), and forbidden_themes (list of semantic categories).

#### Scenario: Rule structure validation
- **WHEN** a policy rule is defined
- **THEN** it SHALL have all required fields and severity SHALL always be "block" (no warnings allowed for policy violations)
