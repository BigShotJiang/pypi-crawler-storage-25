## ADDED Requirements

### Requirement: Policy audit agent
The system SHALL provide a `PolicyAuditor` agent that validates all pipeline output against platform policy rules. This agent SHALL be a hard gate — any violation SHALL cause the pipeline to STOP with no override possible.

#### Scenario: Script text audit
- **WHEN** the PolicyAuditor receives a video package with a script
- **THEN** it SHALL scan all script text (narration, on-screen text, hook) against forbidden keywords and themes for the target platform

#### Scenario: Shot description audit
- **WHEN** the PolicyAuditor receives shot list descriptions
- **THEN** it SHALL check each shot description against forbidden visual categories (violence, nudity, dangerous acts, etc.)

#### Scenario: Asset source audit
- **WHEN** the PolicyAuditor receives resolved assets
- **THEN** it SHALL verify asset search queries and descriptions do not reference forbidden content

#### Scenario: Audit pass — pipeline continues
- **WHEN** all audit checks pass for a video package
- **THEN** the PolicyAuditor SHALL return status "audit_passed" and the pipeline SHALL continue to QA Validator

#### Scenario: Audit fail — pipeline stops
- **WHEN** any audit check fails
- **THEN** the PolicyAuditor SHALL return status "policy_violation" with detailed violation report, and the pipeline SHALL STOP immediately. No video SHALL be produced.

### Requirement: Two-tier audit system
The PolicyAuditor SHALL support two audit tiers: Tier 1 (rule-based pattern matching) and Tier 2 (AI semantic analysis). Tier 1 SHALL always run. Tier 2 SHALL run only when Tier 1 passes and AI is available.

#### Scenario: Tier 1 catches keyword violation
- **WHEN** a script contains an exact forbidden keyword match
- **THEN** Tier 1 SHALL flag it immediately without invoking Tier 2

#### Scenario: Tier 2 catches semantic violation
- **WHEN** Tier 1 passes but content implies prohibited themes (e.g., sarcasm about violence, coded hate speech)
- **THEN** Tier 2 AI analysis SHALL detect and flag the semantic violation

### Requirement: Zero tolerance — no bypass
The PolicyAuditor SHALL NOT provide any mechanism to skip, override, or bypass policy checks. There SHALL be no `--force`, `--skip-audit`, or equivalent flag anywhere in the system.

#### Scenario: No skip flag exists
- **WHEN** a developer inspects the CLI and pipeline code
- **THEN** there SHALL be no argument, environment variable, or configuration option that allows skipping policy audit

### Requirement: Policy audit in pipeline position
The PolicyAuditor SHALL run after MotionDirector (agent 4) and before QAValidator (agent 5). The pipeline order SHALL be: ScriptWriter → ShotListDirector → AssetResolver → MotionDirector → **PolicyAuditor** → QAValidator.

#### Scenario: Pipeline execution order
- **WHEN** the full pipeline runs
- **THEN** PolicyAuditor SHALL execute after all content generation agents and before QA validation
