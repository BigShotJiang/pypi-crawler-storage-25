## Context

ai-director-core v2.0.0 pipeline: ScriptWriter → ShotListDirector → AssetResolver → MotionDirector → QAValidator. QA chỉ check brand constraints. Không có platform policy enforcement.

Platforms có quy định nghiêm ngặt:
- **YouTube**: Community Guidelines (violent/graphic, hate speech, harassment, dangerous acts, misinformation, sexually explicit, spam, deceptive, child safety)
- **TikTok**: Community Guidelines (violence, hate, harassment, nudity, minor safety, misinformation, dangerous activities, regulated goods)
- **Instagram Reels**: Community Guidelines (violence, hate, harassment, nudity, misinformation, fraud, regulated goods)

`ChannelConfig.target_platform` đã tồn tại (`youtube_shorts | tiktok | instagram_reels`), tự động xác định platform cho policy.

## Goals / Non-Goals

**Goals:**
- Hard gate policy audit: fail = video STOP, không có bypass
- Policy rules dạng data (JSON/dict), dễ update khi platform đổi chính sách
- Audit cả 4 output layers: script text, shot descriptions, asset sources, motion parameters
- 2 cấp audit: rule-based (keyword/pattern) + AI semantic (khi Claude available)
- CLI audit command cho manual check

**Non-Goals:**
- Không fetch policy updates tự động từ platform APIs (manual update)
- Không audit video frames/images trực tiếp (chỉ audit metadata + text)
- Không thay thế QA Validator (policy audit là layer riêng)

## Decisions

### 1. Policy rules as Python dicts, không phải external files

**Chọn**: Policy rules hardcoded trong Python module `ai_director/policies/{platform}.py`
**Lý do**: Policies thay đổi ít (vài lần/năm). Python dict cho phép type safety, IDE completion, và test coverage. Không cần dynamic loading overhead.
**Alternative**: YAML/JSON files — flexible hơn nhưng mất type safety và khó test.

### 2. Policy audit là agent riêng, không merge vào QA Validator

**Chọn**: `PolicyAuditor` agent riêng, chạy **trước** QAValidator trong pipeline
**Lý do**: Separation of concerns — QA checks brand compliance, PolicyAuditor checks platform compliance. Khác nhau về severity: QA fail = flag review, policy fail = HARD STOP.
**Alternative**: Merge vào QA — đơn giản hơn nhưng vi phạm single responsibility, khó control severity.

### 3. Two-tier audit: rule-based first, then AI semantic

**Chọn**:
- Tier 1 (always): Keyword/pattern matching — fast, deterministic, zero cost
- Tier 2 (when AI available): Claude semantic analysis — catch nuanced violations
**Lý do**: Rule-based catches obvious violations (keywords, forbidden categories). AI catches subtle ones (sarcasm, implied violence, misleading context). Tier 1 alone đủ cho MVP.

### 4. Zero tolerance — no override mechanism

**Chọn**: Không có `--force`, `--skip-audit`, hay bất kỳ bypass nào
**Lý do**: User yêu cầu rõ ràng — "không có bất cứ trường hợp ngoại lệ nào". Hard gate trong pipeline, hard gate trong CLI. Code không expose skip path.

## Risks / Trade-offs

- **[Risk] False positives block valid videos** → Mitigation: Policy rules phải cụ thể, không quá broad. Test kỹ với real video packages. Nếu false positive xảy ra → fix rules, không phải bypass.
- **[Risk] Policy outdated khi platform update** → Mitigation: Mỗi policy module có `_LAST_UPDATED` date. CLI `ad audit --check-freshness` cảnh báo nếu policy > 90 ngày chưa update.
- **[Trade-off] AI semantic tier tốn thêm API cost** → Acceptable. Budget tracker đã track. Tier 2 chỉ chạy khi tier 1 pass (giảm cost).
