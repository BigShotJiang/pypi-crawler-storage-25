## ADDED Requirements

### Requirement: Configurable AI model backend
The system SHALL support configurable AI model selection for LLM and image generation tasks. The default LLM model SHALL be `gemini-3.1` and the default image model SHALL be `gemini-2.5-flash-image`.

#### Scenario: Default model configuration
- **WHEN** a brand has no `ai_models` field in its channel config and no environment variables set
- **THEN** the system SHALL use `gemini-3.1` as the LLM model and `gemini-2.5-flash-image` as the image model

#### Scenario: Config-level model override
- **WHEN** a brand sets `ai_models.llm_model` to `claude-sonnet-4-20250514` in channel config
- **THEN** the system SHALL use `claude-sonnet-4-20250514` for all LLM operations for that brand

#### Scenario: Environment variable override takes precedence
- **WHEN** `AI_DIRECTOR_LLM_MODEL` env var is set to `gemini-3.1-pro`
- **THEN** the system SHALL use `gemini-3.1-pro` regardless of the config file value

#### Scenario: Image model configuration
- **WHEN** a brand sets `ai_models.image_model` to a custom model name
- **THEN** the system SHALL use that model for all image generation tasks

### Requirement: AIModelsConfig Pydantic model
The system SHALL provide an `AIModelsConfig` frozen Pydantic model with `llm_model` and `image_model` string fields, integrated as an optional field on `ChannelConfig`.

#### Scenario: Backward compatibility
- **WHEN** an existing channel config has no `ai_models` field
- **THEN** the config SHALL load successfully with `ai_models` defaulting to `None`

#### Scenario: Model resolution function
The system SHALL provide a `resolve_models(config)` function that returns the effective LLM and image model by checking env vars first, then config, then defaults.

- **WHEN** `resolve_models` is called with a config that has `ai_models` set and env vars are also set
- **THEN** env var values SHALL take precedence over config values
