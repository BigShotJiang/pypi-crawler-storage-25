## MODIFIED Requirements

### Requirement: README documentation
The README SHALL include documentation for all CLI commands, including `ad dashboard` and `ad app-info`. The tech stack table SHALL list Gemini 3.1 (LLM), gemini-2.5-flash-image (image generation), and React 18 + TypeScript (dashboard). The project structure SHALL reflect the `dashboard/` directory.

#### Scenario: Tech stack table completeness
- **WHEN** a user reads the README tech stack table
- **THEN** the table SHALL include entries for: Gemini 3.1 (LLM — configurable), gemini-2.5-flash-image (image generation), React 18 + TypeScript (dashboard), and Vite (dashboard build)

#### Scenario: CLI reference completeness
- **WHEN** a user reads the CLI reference section
- **THEN** the section SHALL document `ad dashboard`, `ad app-info` commands with usage examples

#### Scenario: CHANGELOG reflects new features
- **WHEN** a user reads CHANGELOG.md
- **THEN** the `[2.1.0]` section SHALL list: dashboard portal, version display, AI model config, `ad app-info` CLI, and `ad dashboard` CLI
