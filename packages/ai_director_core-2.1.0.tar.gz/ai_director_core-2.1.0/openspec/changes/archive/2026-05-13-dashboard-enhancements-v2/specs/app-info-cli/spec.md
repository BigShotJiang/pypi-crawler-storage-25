## ADDED Requirements

### Requirement: App info CLI command
The system SHALL provide an `ad app-info` CLI command that generates or displays a `.ai-director.json` manifest file containing the brand's app metadata.

#### Scenario: Generate manifest from config
- **WHEN** `ad app-info --config data/channel_config.json` is executed
- **THEN** the system SHALL write a `.ai-director.json` file in the current directory containing: `name`, `core_version`, `niche`, `platform`, `ai_models` (resolved), and `generated_at` timestamp

#### Scenario: Show info to stdout
- **WHEN** `ad app-info --show --config data/channel_config.json` is executed
- **THEN** the system SHALL print the manifest JSON to stdout without writing a file

#### Scenario: Custom output path
- **WHEN** `ad app-info --config data/channel_config.json --output path/to/manifest.json` is executed
- **THEN** the system SHALL write the manifest to the specified path

### Requirement: Manifest schema
The `.ai-director.json` manifest SHALL contain at minimum: `name` (channel name), `core_version` (ai-director-core version), `niche`, `platform`, `ai_models` object with `llm_model` and `image_model`, and `generated_at` ISO timestamp.

#### Scenario: Manifest content
- **WHEN** a manifest is generated for a channel named "DailyWonders" with niche "science" on platform "youtube_shorts"
- **THEN** the JSON SHALL contain `{"name": "DailyWonders", "core_version": "2.1.0", "niche": "science", "platform": "youtube_shorts", "ai_models": {"llm_model": "gemini-3.1", "image_model": "gemini-2.5-flash-image"}, "generated_at": "..."}`
