## Context

The dashboard portal is implemented as a React SPA built into `ai_director/dashboard/static/` and served via Python's `http.server`. The Sidebar shows `◈ DIRECTOR` but no version. AI model selection is hardcoded to Anthropic Claude in `pipeline.py` and agents. Brands have no CLI to push their app configuration upstream. CHANGELOG and README don't cover the new dashboard or model features.

## Goals / Non-Goals

**Goals:**
- Show the package version in the dashboard sidebar, read from the Python package at build time or from a generated file
- Add a Pydantic model `AIModelsConfig` for configurable LLM + image models, defaulting to Gemini 3.1 / gemini-2.5-flash-image
- Add `ad app-info` CLI to write a `.ai-director.json` manifest into the brand repo
- Update CHANGELOG.md and README.md with all new features, tech stack, and CLI docs

**Non-Goals:**
- Runtime model switching in the dashboard UI (future work)
- Removing Anthropic Claude support (it remains as a valid model option)
- Firebase or deployment automation changes

## Decisions

### 1. Version display — inject at build time via Vite `define`

**Decision**: During `npm run build`, read the version from `pyproject.toml` via a small Vite plugin and inject it as `__APP_VERSION__` global constant. The Sidebar reads this constant.

**Alternative**: Fetch version from a `/api/version` endpoint on the Python server. Rejected — adds network round-trip for a static value and complicates the zero-dependency HTTP server.

### 2. AI model config — new `AIModelsConfig` Pydantic model

**Decision**: Add an optional `ai_models` field to `ChannelConfig` with:
```python
class AIModelsConfig(BaseModel):
    llm_model: str = "gemini-3.1"
    image_model: str = "gemini-2.5-flash-image"
```
Environment variables `AI_DIRECTOR_LLM_MODEL` and `AI_DIRECTOR_IMAGE_MODEL` override config values. This lets each brand set models via env without touching config JSON.

**Alternative**: Only env vars, no config field. Rejected — brands should be able to pin models in their config for reproducibility.

### 3. `ad app-info` CLI — write `.ai-director.json` manifest

**Decision**: New `app-info` subcommand with two modes:
- `ad app-info --config data/channel_config.json` — reads config and writes `.ai-director.json` with name, version, niche, models, platform
- `ad app-info --show` — prints current info to stdout

The manifest is a simple JSON file brands can commit to their repo, useful for dashboards and tooling to discover which core version + models a brand uses.

### 4. Documentation updates — inline in CHANGELOG and README

**Decision**: Add a new `[2.1.0]` CHANGELOG section. Update README's tech stack table and CLI reference with `ad dashboard`, `ad app-info`, and Gemini model entries.

## Risks / Trade-offs

- **[Vite version injection]** If `pyproject.toml` format changes, the regex parser breaks → Mitigation: same regex already used in `version.py`, share the pattern
- **[Model config backward compat]** Adding `ai_models` field to frozen config → Mitigation: `Optional` with `None` default, same pattern as `brand_identity` and `budget`
- **[.ai-director.json conflicts]** Brands may have different expectations for this file → Mitigation: document the schema, keep it minimal and additive
