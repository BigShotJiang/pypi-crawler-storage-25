## Why

The dashboard portal (v1) ships with core UI but lacks version visibility, AI model configuration, and a CLI for brands to push app metadata to their git repos. These additions complete the dashboard's operational readiness: version display gives instant deployment awareness, model config makes the AI backbone configurable per brand, and the new CLI bridges the dashboard settings to the brand's repo. CHANGELOG and README also need updating to reflect all new features.

## What Changes

- Display the package version next to the sidebar logo (`◈ DIRECTOR v2.x.x`)
- New `ad app-info` CLI command that writes/updates app metadata (name, version, description, AI models) to the brand repo's git config or a dedicated `.ai-director.json` manifest
- Add AI model configuration: `gemini-3.1` as the primary LLM and `gemini-2.5-flash-image` for image generation, selectable via environment variables per brand
- Update `CHANGELOG.md` with all new dashboard & model features
- Update `README.md` with new tech stack entries (Gemini models, React dashboard) and CLI usage for `ad dashboard` and `ad app-info`

## Capabilities

### New Capabilities
- `ai-model-config`: AI model backend configuration — Gemini 3.1 for LLM, gemini-2.5-flash-image for image generation. Per-brand env-driven model selection
- `app-info-cli`: CLI command `ad app-info` to push/sync app metadata to the brand repo's settings file

### Modified Capabilities
- `readme-docs`: Update README with dashboard CLI, app-info CLI, tech stack (Gemini models, React/TypeScript dashboard)

## Impact

- `ai_director/models/config.py` — new optional `ai_models` field on `ChannelConfig`
- `ai_director/runner.py` — new `app-info` subcommand
- `dashboard/src/components/Sidebar.tsx` — version display
- `CHANGELOG.md`, `README.md` — documentation updates
- New env vars: `AI_DIRECTOR_LLM_MODEL`, `AI_DIRECTOR_IMAGE_MODEL`
