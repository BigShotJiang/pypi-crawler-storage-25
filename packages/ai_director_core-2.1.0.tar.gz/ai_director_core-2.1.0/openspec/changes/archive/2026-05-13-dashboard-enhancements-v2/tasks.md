## 1. Version Display in Dashboard Sidebar

- [x] 1.1 Add Vite plugin to read version from `pyproject.toml` and inject as `__APP_VERSION__` define
- [x] 1.2 Add TypeScript type declaration for `__APP_VERSION__` in `vite-env.d.ts`
- [x] 1.3 Update `Sidebar.tsx` to display version next to logo text
- [x] 1.4 Add CSS for version label in `Sidebar.module.css`
- [ ] 1.5 Write test for version display in Sidebar

## 2. AI Model Configuration

- [x] 2.1 Create `AIModelsConfig` Pydantic model in `ai_director/models/config.py`
- [x] 2.2 Add optional `ai_models` field to `ChannelConfig`
- [x] 2.3 Create `resolve_models()` function in `ai_director/models/config.py` (env > config > defaults)
- [x] 2.4 Write tests for `AIModelsConfig` and `resolve_models`

## 3. App Info CLI

- [x] 3.1 Add `app-info` subparser to `runner.py` with `--config`, `--show`, `--output` args
- [x] 3.2 Implement `_cmd_app_info` function that builds manifest JSON
- [x] 3.3 Write tests for `ad app-info` manifest generation

## 4. Documentation Updates

- [x] 4.1 Add `[2.1.0]` section to `CHANGELOG.md` with dashboard, model config, app-info, version display
- [x] 4.2 Update README tech stack table with Gemini models, React dashboard, Vite
- [x] 4.3 Add `ad dashboard` CLI docs to README
- [x] 4.4 Add `ad app-info` CLI docs to README
- [x] 4.5 Update README project structure to include `dashboard/` directory

## 5. Build & Verify

- [x] 5.1 Bump version to 2.1.0
- [x] 5.2 Rebuild dashboard frontend (`npm run build`)
- [x] 5.3 Run all Python tests
- [x] 5.4 Run all Vitest tests
