## ADDED Requirements

### Requirement: CI runs tests on push and PR
The system SHALL have a GitHub Actions workflow that runs `pytest` on every push to `main` and on every pull request targeting `main`.

#### Scenario: Tests run on push
- **WHEN** code is pushed to `main` branch
- **THEN** CI SHALL install dependencies and run `pytest` with verbose output

#### Scenario: Tests run on PR
- **WHEN** a pull request is opened targeting `main`
- **THEN** CI SHALL run the test suite and report pass/fail status

#### Scenario: CI fails on test failure
- **WHEN** any test fails during CI
- **THEN** the workflow SHALL exit with non-zero status, blocking merge if branch protection is enabled

### Requirement: CI uses correct Python version
The CI workflow SHALL use Python 3.11 matching the project's `requires-python` constraint.

#### Scenario: Python version matches project
- **WHEN** CI runs
- **THEN** it SHALL use Python 3.11 and install the project in editable mode
