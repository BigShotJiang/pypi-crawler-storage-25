## ADDED Requirements

### Requirement: Short CLI alias
The system SHALL provide `ad` as a short alias for the `ai-director` CLI command. Both commands SHALL invoke the same entry point.

#### Scenario: User runs ad command
- **WHEN** user runs `ad validate --config data/channel_config.json`
- **THEN** it SHALL behave identically to `ai-director validate --config data/channel_config.json`

#### Scenario: Both aliases coexist
- **WHEN** package is installed
- **THEN** both `ai-director` and `ad` SHALL be available as CLI commands
