## ADDED Requirements

### Requirement: Show current version
The system SHALL provide `ad version` command that displays the current package version.

#### Scenario: Display version
- **WHEN** user runs `ad version`
- **THEN** system SHALL print the current version from pyproject.toml (e.g., "2.0.0")

### Requirement: Bump version
The system SHALL provide `ad version bump <level>` command where level is `patch`, `minor`, or `major`.

#### Scenario: Bump patch version
- **WHEN** user runs `ad version bump patch` and current version is "2.0.0"
- **THEN** system SHALL update pyproject.toml to "2.0.1" and print the new version

#### Scenario: Bump minor version
- **WHEN** user runs `ad version bump minor` and current version is "2.0.0"
- **THEN** system SHALL update pyproject.toml to "2.1.0"

#### Scenario: Bump major version
- **WHEN** user runs `ad version bump major` and current version is "2.0.0"
- **THEN** system SHALL update pyproject.toml to "3.0.0"

### Requirement: Git tag on version bump
The system SHALL create a git tag `v{new_version}` after bumping version.

#### Scenario: Tag created after bump
- **WHEN** user runs `ad version bump patch` successfully
- **THEN** system SHALL create git tag `v2.0.1` and commit the pyproject.toml change
