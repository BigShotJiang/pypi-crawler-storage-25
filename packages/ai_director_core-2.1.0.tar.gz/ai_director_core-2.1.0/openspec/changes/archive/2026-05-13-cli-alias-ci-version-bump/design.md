## Context

ai-director-core v2.0.0 đã có đầy đủ agents, models, pipeline. CLI entry point hiện tại là `ai-director` (dài). Chưa có CI, chưa có version management.

## Goals / Non-Goals

**Goals:**
- `ad` alias hoạt động song song với `ai-director` — cùng entry point
- `ad version` show current version, `ad version bump <level>` update pyproject.toml + git tag
- CI chạy pytest trên Python 3.11 cho mỗi push/PR

**Non-Goals:**
- Không tự động publish package lên PyPI (chỉ bump version)
- Không setup CD/deployment pipeline
- Không thay đổi existing CLI commands

## Decisions

### 1. Alias `ad` qua pyproject.toml entry point

**Chọn**: Thêm `ad = "ai_director.runner:main"` song song với `ai-director`
**Lý do**: Zero code change — cả hai entry points gọi cùng `main()`. User cài package = có cả hai.

### 2. Version bump dùng regex replace trong pyproject.toml

**Chọn**: Read pyproject.toml → regex match `version = "X.Y.Z"` → bump → write back
**Lý do**: Không cần thêm dependency (`bump2version`, `hatch version`). Logic đơn giản, 1 file duy nhất.

### 3. CI workflow dùng single Python version

**Chọn**: Python 3.11 only, không matrix
**Lý do**: Project requires-python >=3.11, test trên 1 version đủ cho scope hiện tại.

## Risks / Trade-offs

- **[Risk] `ad` trùng với system command** → Mitigation: Kiểm tra `which ad` trên macOS/Linux — không có command `ad` mặc định
- **[Trade-off] Version bump chỉ sửa pyproject.toml** → Acceptable. Nếu cần bump nhiều file sau thì extend
