## Why

CLI hiện tại dùng `ai-director` — dài, khó gõ khi dùng thường xuyên. Chưa có CI workflow để chạy tests tự động trước khi merge. Chưa có cách bump version có hệ thống. GitHub repo cũng chưa có description/topics.

## What Changes

- **Thêm CLI alias `ad`**: Short alias 2 ký tự cho `ai-director`, cả hai đều hoạt động song song
- **Thêm `ad version` command**: `ad version` hiển thị version, `ad version bump <patch|minor|major>` bump version trong pyproject.toml + tạo git tag
- **Thêm CI workflow** (`.github/workflows/ci.yml`): Chạy `pytest` tự động trên push/PR, fail = block
- **Thêm GitHub repo About**: Script/workflow set description + topics cho repo

## Capabilities

### New Capabilities
- `cli-alias`: Short CLI alias `ad` song song với `ai-director`
- `version-management`: CLI command `ad version` và `ad version bump` để quản lý version
- `ci-workflow`: GitHub Actions CI chạy tests tự động trên mỗi push và PR

### Modified Capabilities
_(none)_

## Impact

- `pyproject.toml`: Thêm `ad` entry point, thêm `pytest` dev dependency
- `ai_director/runner.py`: Thêm `version` subcommand
- `.github/workflows/ci.yml`: File mới — CI pipeline
- README.md: Cập nhật CLI alias trong docs
