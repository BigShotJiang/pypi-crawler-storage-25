## 1. CLI Alias

- [x] 1.1 Thêm `ad` entry point vào `pyproject.toml` song song với `ai-director`
- [x] 1.2 Update README.md — ghi chú alias `ad` trong CLI reference

## 2. Version Management

- [x] 2.1 Thêm `version` subcommand vào `runner.py` — show current version
- [x] 2.2 Implement `ad version bump <patch|minor|major>` — update pyproject.toml + git commit + git tag
- [x] 2.3 Tests cho version show và version bump logic

## 3. CI Workflow

- [x] 3.1 Tạo `.github/workflows/ci.yml` — pytest on push/PR to main
- [x] 3.2 Verify CI config syntax

## 4. GitHub Repo About

- [x] 4.1 Update repo description và topics via GitHub API hoặc hướng dẫn manual setting

## 5. Final

- [ ] 5.1 Run full test suite
- [ ] 5.2 Commit và push
