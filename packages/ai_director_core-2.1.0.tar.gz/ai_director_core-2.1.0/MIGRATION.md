# Migration Guide: v1.x → v2.0.0

## Breaking Changes

Version 2.0.0 introduces two new config sections in `channel_config.json`:
- `brand_identity` — brand-specific voice, audience, hooks, and content plan
- `budget` — spending limits and cost tracking

## Automatic Migration

Run the migration tool to auto-generate missing fields with sensible defaults:

```bash
ai-director migrate --config data/channel_config.json
```

This will:
1. Add `brand_identity` with defaults derived from your existing `target_audience` and `hook_formula`
2. Add `budget` with defaults: $100/month, $5/video
3. Preserve all existing fields untouched

**Review the generated values** and customize them for your brand.

## Manual Migration

### Step 1: Add `brand_identity`

Add this section to your `channel_config.json`:

```json
{
  "brand_identity": {
    "brand_voice": "Describe your channel's personality and tone in detail",
    "audience_plan": {
      "primary_segments": [
        {
          "name": "Segment name (e.g., 'History buffs 25-45')",
          "demographics": "Age, gender, location",
          "psychographics": "Interests, values, pain points"
        }
      ],
      "content_goals": ["educate", "entertain"],
      "engagement_strategy": "How you drive engagement (comments, shares)"
    },
    "hook_strategy": {
      "primary_hooks": ["Your hook formulas"],
      "forbidden_hooks": ["Hooks you never use"],
      "hook_test_criteria": "How to evaluate hook effectiveness"
    },
    "content_plan": {
      "themes": ["Theme 1", "Theme 2"],
      "posting_frequency": "daily"
    },
    "unique_selling_points": ["What makes your channel unique"],
    "competitor_differentiation": "How your channel differs from competitors"
  }
}
```

### Step 2: Add `budget`

```json
{
  "budget": {
    "monthly_limit_usd": 100.0,
    "per_video_limit_usd": 5.0,
    "cost_allocation": {
      "api_calls": 0.6,
      "asset_gen": 0.3,
      "storage": 0.1
    },
    "alert_threshold_pct": 0.8,
    "hard_stop_threshold_pct": 1.0,
    "notification_channels": ["telegram"]
  }
}
```

**Notes:**
- `cost_allocation` values must sum to 1.0
- `alert_threshold_pct` must be ≤ `hard_stop_threshold_pct`
- Set `monthly_limit_usd` based on your expected usage

### Step 3: Validate

```bash
ai-director validate --config data/channel_config.json
```

### Step 4: Update core version

In your channel repo's `requirements.txt`:

```
ai-director-core==2.0.0
```

## Backward Compatibility

During the transition period, both `brand_identity` and `budget` are **optional**.
- If `brand_identity` is missing, agents use existing `narrative.tone` and `hook_formula`
- If `budget` is missing, the pipeline runs with no spending limits

These fields will become required in a future minor version.

## Rollback

If you need to rollback, simply keep the old version in `requirements.txt`:

```
ai-director-core==1.2.0
```

The old version will ignore the new fields if they're already in your config.
