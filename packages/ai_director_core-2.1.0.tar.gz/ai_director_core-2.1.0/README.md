# ai-director-core

> AI Director core engine for automated video production. Config-driven, multi-brand architecture — each channel is pure data, all intelligence lives here.

[![CI](https://github.com/minhhoit/ai-director-core/actions/workflows/ci.yml/badge.svg)](https://github.com/minhhoit/ai-director-core/actions/workflows/ci.yml)

Core engine for automated video production. Config-driven, multi-brand architecture — each channel is pure data, all intelligence lives here.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  TIER 1: CORE LIBRARY — ai-director-core (this repo)       │
│                                                             │
│  ai_director/                                               │
│  ├── agents/        6 config-driven agents                  │
│  ├── models/        Pydantic v2 schemas (frozen)            │
│  ├── policies/      Platform community guidelines rules     │
│  ├── budget/        Runtime cost tracking & enforcement     │
│  ├── lib/           GCS, clients, utilities                 │
│  ├── pipeline.py    Orchestration with budget + policy gates │
│  ├── scaffold.py    Interactive brand scaffolding wizard    │
│  └── runner.py      CLI entry point                         │
│                                                             │
│  .github/workflows/                                         │
│  └── reusable-pipeline.yml   ← channel repos call this     │
└─────────────────────────────────────────────────────────────┘
          ▲                          ▲
          │ uses: core@v2            │ uses: core@v2
┌─────────┴──────────┐   ┌──────────┴──────────┐
│  losteras-channel/  │   │  quietmind-channel/  │
│  ├── data/          │   │  ├── data/            │
│  │   ├── config.json│   │  │   ├── config.json  │
│  │   └── topics.json│   │  │   └── topics.json  │
│  ├── pipeline.yml   │   │  ├── pipeline.yml     │
│  └── requirements   │   │  └── requirements     │
└─────────────────────┘   └───────────────────────┘
```

**Data flow**: `channel_config.json` → Core Agents → `video_package.json`

Core agents don't know which channel they serve. They read the config and execute. Zero configuration drift across brands.

## Tech Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Language | Python 3.11+ | Core runtime |
| Models | Pydantic v2 | Schema validation, frozen configs |
| LLM | Gemini 3.1 (configurable) | Script writing, creative decisions |
| Image Gen | gemini-2.5-flash-image (configurable) | AI image generation |
| Legacy LLM | Anthropic Claude | Alternative LLM backend |
| Dashboard | React 18 + TypeScript | Web dashboard SPA |
| Dashboard Build | Vite 6 | Frontend bundler (builds to pip package) |
| Build | Hatchling | Package building & distribution |
| CI/CD | GitHub Actions | Reusable workflow per channel |
| Storage | Google Cloud Storage | Assets, budget data, per-channel isolation |
| Assets | Pexels API | Stock video/image search |
| Auth | Firebase Auth | Dashboard authentication |
| Database | Firestore | Dashboard state persistence |
| Notifications | Telegram Bot | Budget alerts |

## Installation

### Development

```bash
git clone https://github.com/<org>/ai-director-core.git
cd ai-director-core
pip install -e .
```

### Production (channel repos)

```bash
pip install ai-director-core==2.1.0
```

## CLI Reference

> **Short alias**: All commands below work with both `ai-director` and `ad`. For example: `ad scaffold`, `ad validate`, `ad version`.

### `ad scaffold`

Interactive wizard to create a complete channel repo structure.

```bash
# Interactive mode
ad scaffold --output-dir ./my-new-brand

# Non-interactive mode (CI/scripting)
ad scaffold --non-interactive \
  --name "MyBrand" \
  --niche "history" \
  --voice "Epic and cinematic" \
  --audience "History buffs 25-45" \
  --aspect-ratio "9:16" \
  --output-dir ./mybrand-channel
```

Generated files:
- `data/channel_config.json` — full config with brand_identity & budget
- `.github/workflows/pipeline.yml` — workflow calling reusable pipeline
- `requirements.txt` — pinned core version
- `data/topics_queue.json` — topic queue with sample entry

### `ad run`

Run the full 6-agent pipeline for a topic.

```bash
ad run --config data/channel_config.json --topic "Ancient Rome" --topic-id topic-001
```

### `ad audit`

Run policy audit on pipeline data against the target platform's community guidelines. This is a zero-tolerance gate — any violation blocks video production.

```bash
# Audit pipeline data
ad audit --config data/channel_config.json --input outputs/package.json

# With freshness check (warns if policy rules are stale)
ad audit --config data/channel_config.json --input outputs/package.json --check-freshness

# JSON output (for CI integration)
ad audit --config data/channel_config.json --input outputs/package.json --json
```

Supported platforms: `youtube_shorts`, `tiktok`, `instagram_reels`

### `ad validate`

Validate a channel config file (schema, brand_identity, budget).

```bash
ad validate --config data/channel_config.json
```

### `ad agent`

Run a single agent in isolation.

```bash
ad agent --name script --config data/channel_config.json --input topic.json --output script.json
```

Agents: `script`, `shots`, `assets`, `motion`, `qa`

### `ad budget status`

Show remaining budget, costs by category.

```bash
ad budget status --config data/channel_config.json
ad budget status --config data/channel_config.json --json
```

### `ad init`

Generate a single boilerplate `channel_config.json`.

```bash
ad init --name "MyChannel" --niche "meditation"
```

### `ad migrate`

Auto-add missing `brand_identity` and `budget` fields to existing configs.

```bash
ad migrate --config data/channel_config.json
```

### `ad version`

Show current version or bump version.

```bash
# Show version
ad version

# Bump version (updates pyproject.toml + creates git tag)
ad version bump patch   # 2.0.0 → 2.0.1
ad version bump minor   # 2.0.0 → 2.1.0
ad version bump major   # 2.0.0 → 3.0.0

# Bump without git tag
ad version bump patch --no-tag
```

### `ad dashboard`

Launch the web dashboard (React SPA served from the installed package).

```bash
# Default: http://127.0.0.1:3456
ad dashboard

# Custom port and host
ad dashboard --port 8080 --host 0.0.0.0
```

Requires Firebase credentials in `dashboard/.env.local` for auth and Firestore features.

### `ad app-info`

Generate a `.ai-director.json` manifest with brand metadata (name, version, models, platform).

```bash
# Write manifest to .ai-director.json
ad app-info --config data/channel_config.json

# Print to stdout (no file written)
ad app-info --show --config data/channel_config.json

# Custom output path
ad app-info --config data/channel_config.json --output path/to/manifest.json
```

AI models are resolved with precedence: env vars (`AI_DIRECTOR_LLM_MODEL`, `AI_DIRECTOR_IMAGE_MODEL`) > config > defaults (`gemini-3.1`, `gemini-2.5-flash-image`).

## Project Structure

```
ai-director-core/
├── ai_director/
│   ├── agents/
│   │   ├── base.py              # BaseAgent ABC (config, channel_name, aspect_ratio)
│   │   ├── script_writer.py     # Brand voice, hooks, audience-aware scripts
│   │   ├── shot_list_director.py # Aspect-ratio composition rules
│   │   ├── asset_resolver.py    # Orientation-specific asset search
│   │   ├── motion_director.py   # Per-aspect-ratio motion adjustments
│   │   ├── policy_auditor.py    # Zero-tolerance platform policy gate
│   │   └── qa_validator.py      # Brand compliance checks
│   ├── policies/
│   │   ├── __init__.py          # PolicyRule, PlatformPolicy, registry
│   │   ├── youtube.py           # YouTube Community Guidelines
│   │   ├── tiktok.py            # TikTok Community Guidelines
│   │   └── instagram.py         # Meta Community Standards
│   ├── budget/
│   │   └── tracker.py           # BudgetTracker, GCS/local persistence
│   ├── dashboard/
│   │   ├── __init__.py          # Dashboard serve entry point
│   │   ├── server.py            # SPA HTTP server
│   │   └── static/              # Built React dashboard (auto-generated)
│   ├── lib/
│   │   └── gcs.py               # GCS path enforcement, scoped logging
│   ├── models/
│   │   ├── brand_identity.py    # AudiencePlan, HookStrategy, ContentPlan
│   │   ├── budget.py            # BudgetConfig with validation
│   │   └── config.py            # ChannelConfig, AIModelsConfig, resolve_models
│   ├── config_loader.py         # Load, validate, cross-channel isolation
│   ├── pipeline.py              # 6-agent orchestration with budget + policy gates
│   ├── scaffold.py              # Interactive brand scaffolding wizard
│   ├── version.py               # Version management (show/bump)
│   └── runner.py                # CLI entry point (ai-director / ad)
├── dashboard/                   # React 18 + TypeScript dashboard source
│   ├── src/                     # Components, features, hooks, styles
│   ├── plugins/                 # Brand plugin examples (DailyWonders)
│   ├── package.json
│   └── vite.config.ts           # Builds → ai_director/dashboard/static/
├── tests/
├── .github/workflows/
│   ├── ci.yml                   # CI: run tests on push/PR
│   └── reusable-pipeline.yml    # Reusable GitHub Actions workflow
├── pyproject.toml
├── CHANGELOG.md
└── MIGRATION.md
```

## Quickstart

### 1. Scaffold a new brand

```bash
ad scaffold --output-dir ./mybrand-channel
```

Follow the prompts to enter your brand's name, niche, voice, audience, and budget.

### 2. Customize your config

Edit `mybrand-channel/data/channel_config.json` — tune the `brand_identity`, `budget`, `narrative`, and `visual` sections for your brand.

### 3. Add topics

Edit `mybrand-channel/data/topics_queue.json`:

```json
{
  "topics": [
    {"id": "topic-001", "title": "The Fall of Rome", "status": "pending"},
    {"id": "topic-002", "title": "Viking Age", "status": "pending"}
  ]
}
```

### 4. Validate

```bash
cd mybrand-channel
ad validate --config data/channel_config.json
```

### 5. Run the pipeline

```bash
ad run --config data/channel_config.json --topic "The Fall of Rome" --topic-id topic-001
```

### 6. Deploy

1. Replace `<org>` in `.github/workflows/pipeline.yml` with your GitHub org
2. Set GitHub secrets: `ANTHROPIC_API_KEY`, `PEXELS_API_KEY`, `GCP_SA_KEY`
3. Push to GitHub — pipeline runs on schedule (23:00 UTC+7 daily)

## License

See [LICENSE](LICENSE).