from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, model_validator


class BudgetConfig(BaseModel):
    """Budget constraints for a single brand/channel."""

    model_config = ConfigDict(frozen=True)

    monthly_limit_usd: float = Field(
        ..., gt=0, description="Maximum monthly spend in USD"
    )
    per_video_limit_usd: float = Field(
        ..., gt=0, description="Maximum spend per video in USD"
    )
    cost_allocation: dict[str, float] = Field(
        ...,
        description=(
            "Percentage allocation per cost category. "
            "Keys: 'api_calls', 'asset_gen', 'storage', etc. Values must sum to 1.0"
        ),
    )
    alert_threshold_pct: float = Field(
        default=0.8,
        ge=0.0,
        le=1.0,
        description="Fraction of monthly limit that triggers an alert (default 80%)",
    )
    hard_stop_threshold_pct: float = Field(
        default=1.0,
        ge=0.0,
        le=2.0,
        description="Fraction of monthly limit that triggers a hard stop (default 100%)",
    )
    notification_channels: list[str] = Field(
        default_factory=lambda: ["telegram"],
        description="Where to send budget notifications",
    )

    @model_validator(mode="after")
    def _validate_thresholds_and_allocation(self) -> "BudgetConfig":
        # alert must be <= hard_stop
        if self.alert_threshold_pct > self.hard_stop_threshold_pct:
            raise ValueError(
                f"alert_threshold_pct ({self.alert_threshold_pct}) "
                f"must be <= hard_stop_threshold_pct ({self.hard_stop_threshold_pct})"
            )
        # cost_allocation values must sum to 1.0 (with tolerance)
        total = sum(self.cost_allocation.values())
        if abs(total - 1.0) > 0.01:
            raise ValueError(
                f"cost_allocation values must sum to 1.0, got {total:.4f}"
            )
        # all allocation values must be non-negative
        for key, val in self.cost_allocation.items():
            if val < 0:
                raise ValueError(
                    f"cost_allocation['{key}'] must be >= 0, got {val}"
                )
        return self
