from __future__ import annotations

import json
import os
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .brand_identity import BrandIdentity
from .budget import BudgetConfig


# ── AI Model defaults ─────────────────────────────────
DEFAULT_LLM_MODEL = "gemini-3.1"
DEFAULT_IMAGE_MODEL = "gemini-2.5-flash-image"


class AIModelsConfig(BaseModel):
    """Configurable AI model backend per brand."""

    model_config = ConfigDict(frozen=True)

    llm_model: str = Field(default=DEFAULT_LLM_MODEL, description="LLM model for script writing and creative decisions")
    image_model: str = Field(default=DEFAULT_IMAGE_MODEL, description="Image generation model")


class NarrativeConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    tone: str
    pacing_wps: float = Field(ge=2.0, le=5.0)
    max_words_per_60s: int = Field(ge=30, le=80)
    hook_formula: str
    structure: list[str]


class VisualConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    color_palette: list[str]
    shot_ratio: dict[str, float]
    forbidden_visuals: list[str]
    historical_accuracy_window_years: int = 0
    reference_aesthetic: str = ""


class MotionConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    default_style: str
    allowed_motions: list[str]
    forbidden_motions: list[str]
    min_scene_duration_s: int = Field(ge=3, le=20)
    max_scene_duration_s: int = Field(ge=5, le=30)


class TypographyConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    font: str = "IM Fell English"
    color: str = "#C9A84C"
    text_appear_delay_s: float = 0.5
    position: str = "bottom_third"
    max_chars_per_line: int = 42


class ChannelConfig(BaseModel):
    """
    Complete channel configuration — the 'DNA' of a brand.

    This model is frozen (immutable) after creation to guarantee
    brand isolation: once loaded, config cannot be mutated at runtime.
    """

    model_config = ConfigDict(frozen=True)

    # --- Identity ---
    channel_name: str
    channel_niche: str
    target_platform: Literal["youtube_shorts", "tiktok", "instagram_reels"]
    target_audience: str
    language: str = "en"

    # --- Creative ---
    narrative: NarrativeConfig
    visual: VisualConfig
    motion: MotionConfig
    typography: TypographyConfig = Field(default_factory=TypographyConfig)

    # --- Platform ---
    video_duration_s: int = 60
    aspect_ratio: Literal["9:16", "16:9", "1:1"] = "9:16"

    # --- Asset resolution ---
    asset_sources_priority: list[
        Literal["library_cache", "pexels_search", "ai_generate_flux", "pixabay"]
    ]

    confidence_thresholds: dict[str, float]

    # --- Brand Identity (NEW) ---
    brand_identity: BrandIdentity | None = Field(
        default=None,
        description="Brand-specific identity: voice, audience, hooks, content plan. Optional for backward compat.",
    )

    # --- Budget (NEW) ---
    budget: BudgetConfig | None = Field(
        default=None,
        description="Budget constraints for this brand. None means unlimited.",
    )

    # --- AI Models ---
    ai_models: AIModelsConfig | None = Field(
        default=None,
        description="AI model backend config. None uses defaults (gemini-3.1 / gemini-2.5-flash-image).",
    )


def resolve_models(config: ChannelConfig) -> tuple[str, str]:
    """Return (llm_model, image_model) with env > config > defaults precedence."""
    llm = os.environ.get("AI_DIRECTOR_LLM_MODEL")
    img = os.environ.get("AI_DIRECTOR_IMAGE_MODEL")

    if llm is None:
        llm = config.ai_models.llm_model if config.ai_models else DEFAULT_LLM_MODEL
    if img is None:
        img = config.ai_models.image_model if config.ai_models else DEFAULT_IMAGE_MODEL

    return llm, img
