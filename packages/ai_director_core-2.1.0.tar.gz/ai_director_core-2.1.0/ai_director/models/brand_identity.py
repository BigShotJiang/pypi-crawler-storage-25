from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class AudienceSegment(BaseModel):
    """A single audience segment with demographics and psychographics."""

    model_config = ConfigDict(frozen=True)

    name: str = Field(..., min_length=1, description="Segment identifier, e.g. 'History buffs 25-45'")
    demographics: str = Field(..., min_length=1, description="Age, location, gender, etc.")
    psychographics: str = Field(..., min_length=1, description="Interests, values, pain points")
    platform_behavior: str = Field(
        default="",
        description="How this segment consumes content on the target platform",
    )


class AudiencePlan(BaseModel):
    """Defines who the brand's content is for and how to reach them."""

    model_config = ConfigDict(frozen=True)

    primary_segments: list[AudienceSegment] = Field(
        ..., min_length=1, description="At least one audience segment required"
    )
    content_goals: list[str] = Field(
        ..., min_length=1, description="What the content should achieve for this audience"
    )
    engagement_strategy: str = Field(
        ..., min_length=1, description="How to drive engagement (comments, shares, follows)"
    )


class HookStrategy(BaseModel):
    """Rules for opening hooks — what to use and what to avoid."""

    model_config = ConfigDict(frozen=True)

    primary_hooks: list[str] = Field(
        ..., min_length=1, description="Hook formulas the brand uses"
    )
    forbidden_hooks: list[str] = Field(
        default_factory=list, description="Hooks that must never be used"
    )
    hook_test_criteria: str = Field(
        default="",
        description="Criteria for evaluating hook effectiveness",
    )


class ContentPlan(BaseModel):
    """Content strategy and scheduling preferences."""

    model_config = ConfigDict(frozen=True)

    themes: list[str] = Field(
        default_factory=list, description="Recurring themes or content pillars"
    )
    posting_frequency: str = Field(
        default="daily", description="How often content is published"
    )
    seasonal_topics: dict[str, list[str]] = Field(
        default_factory=dict,
        description="Month/season-specific topic priorities, e.g. {'december': ['year-in-review']}",
    )
    evergreen_ratio: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Fraction of content that is evergreen vs. trending",
    )


class BrandIdentity(BaseModel):
    """Complete brand identity for a channel — voice, audience, hooks, and content plan."""

    model_config = ConfigDict(frozen=True)

    brand_voice: str = Field(
        ...,
        min_length=1,
        description="Detailed personality and tone description",
    )
    audience_plan: AudiencePlan
    hook_strategy: HookStrategy
    content_plan: ContentPlan = Field(default_factory=ContentPlan)
    unique_selling_points: list[str] = Field(
        default_factory=list,
        description="What makes this brand different",
    )
    competitor_differentiation: str = Field(
        default="",
        description="How this brand stands apart from competitors",
    )
