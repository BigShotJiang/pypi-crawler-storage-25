"""YouTube Community Guidelines policy rules.

Source: https://support.google.com/youtube/answer/9288567
Last reviewed: 2025-07-15

YouTube organises its Community Guidelines into these categories:
  - Violent or dangerous content
  - Sensitive content
  - Spam & deceptive practices
  - Regulated goods
  - Misinformation
"""

from __future__ import annotations

from datetime import date

from . import PolicyRule, PlatformPolicy, register_policy

_LAST_UPDATED = date(2025, 7, 15)

_RULES: tuple[PolicyRule, ...] = (
    # ── Violent or dangerous content ─────────────────────────
    PolicyRule(
        rule_id="yt-violent-01",
        category="violent_graphic",
        description="Violent or graphic content that glorifies violence or gore",
        forbidden_keywords=(
            "gore", "dismemberment", "beheading", "mutilation",
            "bloodbath", "mass shooting", "graphic violence",
        ),
        forbidden_patterns=(
            r"\b(kill|murder|slaughter)\s+(them|people|everyone)\b",
            r"\bhow\s+to\s+(kill|murder|poison)\b",
        ),
        forbidden_themes=(
            "gratuitous violence", "glorification of gore",
            "instructions for violent acts",
        ),
        source_url="https://support.google.com/youtube/answer/2802008",
    ),
    PolicyRule(
        rule_id="yt-violent-02",
        category="violent_criminal_orgs",
        description="Content promoting violent criminal organizations",
        forbidden_keywords=(
            "join the cartel", "recruit for militia",
            "terrorist recruitment", "pledge allegiance to isis",
        ),
        forbidden_patterns=(
            r"\b(join|support|recruit|pledge)\b.{0,30}\b(terrorist|cartel|militia|gang)\b",
        ),
        forbidden_themes=(
            "promoting terrorist organizations",
            "recruiting for criminal organizations",
            "glorifying violent extremism",
        ),
        source_url="https://support.google.com/youtube/answer/9229472",
    ),
    PolicyRule(
        rule_id="yt-dangerous-01",
        category="dangerous_acts",
        description="Harmful or dangerous content that could cause physical injury",
        forbidden_keywords=(
            "tide pod challenge", "choking game",
            "blackout challenge", "fire challenge",
        ),
        forbidden_patterns=(
            r"\bhow\s+to\s+make\s+(a\s+)?(bomb|explosive|weapon)\b",
            r"\bdangerous\s+challenge\b",
        ),
        forbidden_themes=(
            "dangerous challenges", "instructions for harmful acts",
            "stunts that could cause serious injury",
        ),
        source_url="https://support.google.com/youtube/answer/2801964",
    ),
    # ── Hate speech ──────────────────────────────────────────
    PolicyRule(
        rule_id="yt-hate-01",
        category="hate_speech",
        description="Hate speech targeting protected attributes",
        forbidden_keywords=(
            "racial slur", "ethnic cleansing",
            "white supremacy", "kill all",
        ),
        forbidden_patterns=(
            r"\b(all|every)\s+\w+\s+(should|must|need\s+to)\s+(die|be\s+killed|be\s+eliminated)\b",
            r"\b(inferior|subhuman)\s+(race|people|group)\b",
        ),
        forbidden_themes=(
            "promoting hatred based on race",
            "promoting hatred based on religion",
            "promoting hatred based on gender",
            "promoting hatred based on sexual orientation",
            "promoting hatred based on disability",
            "dehumanisation of protected groups",
        ),
        source_url="https://support.google.com/youtube/answer/2801939",
    ),
    # ── Harassment ───────────────────────────────────────────
    PolicyRule(
        rule_id="yt-harassment-01",
        category="harassment",
        description="Harassment and cyberbullying content",
        forbidden_keywords=(
            "doxxing", "swatting",
            "revenge porn", "cyberstalking",
        ),
        forbidden_patterns=(
            r"\b(dox|doxx|swat)\s+(this|that|the)\s+(person|guy|girl|user)\b",
            r"\bshare\s+(their|his|her)\s+(address|phone|location)\b",
        ),
        forbidden_themes=(
            "sustained harassment campaign",
            "revealing private information",
            "sexual harassment",
            "coordinated bullying",
        ),
        source_url="https://support.google.com/youtube/answer/2802268",
    ),
    # ── Sensitive content ────────────────────────────────────
    PolicyRule(
        rule_id="yt-sexual-01",
        category="sexually_explicit",
        description="Nudity and sexual content",
        forbidden_keywords=(
            "pornography", "explicit sex",
            "sexual intercourse", "nude video",
        ),
        forbidden_patterns=(
            r"\b(porn|xxx|nsfw)\b",
            r"\bsexual(ly)?\s+(explicit|graphic)\b",
        ),
        forbidden_themes=(
            "pornographic content", "explicit sexual acts",
            "sexual gratification content",
        ),
        source_url="https://support.google.com/youtube/answer/2802002",
    ),
    PolicyRule(
        rule_id="yt-child-safety-01",
        category="child_safety",
        description="Child safety violations",
        forbidden_keywords=(
            "child exploitation", "minor abuse",
            "child pornography", "csam",
        ),
        forbidden_patterns=(
            r"\b(child|minor|underage)\s+(exploitation|abuse|trafficking)\b",
        ),
        forbidden_themes=(
            "child sexual exploitation",
            "child endangerment",
            "content sexualising minors",
        ),
        source_url="https://support.google.com/youtube/answer/2801999",
    ),
    PolicyRule(
        rule_id="yt-selfharm-01",
        category="suicide_selfharm",
        description="Suicide, self-harm, and eating disorders",
        forbidden_keywords=(
            "how to commit suicide", "suicide methods",
            "pro-anorexia", "pro-ana", "thinspo",
        ),
        forbidden_patterns=(
            r"\bhow\s+to\s+(commit\s+suicide|self[\s-]?harm|cut\s+yourself)\b",
            r"\b(pro[\s-]?ana|thinspo|bonespo)\b",
        ),
        forbidden_themes=(
            "promoting suicide", "instructions for self-harm",
            "glorifying eating disorders",
        ),
        source_url="https://support.google.com/youtube/answer/2802245",
    ),
    # ── Spam & deceptive practices ───────────────────────────
    PolicyRule(
        rule_id="yt-spam-01",
        category="spam_deceptive",
        description="Spam, scams, and deceptive practices",
        forbidden_keywords=(
            "free money hack", "get rich quick guaranteed",
            "click here to claim prize",
        ),
        forbidden_patterns=(
            r"\b(guaranteed|100%)\s+(money|profit|returns)\b",
            r"\bsend\s+(money|bitcoin|crypto)\s+to\b",
        ),
        forbidden_themes=(
            "financial scams", "phishing",
            "deceptive clickbait promising money",
        ),
        source_url="https://support.google.com/youtube/answer/2801973",
    ),
    # ── Regulated goods ──────────────────────────────────────
    PolicyRule(
        rule_id="yt-regulated-01",
        category="regulated_goods",
        description="Sale of illegal or regulated goods and services",
        forbidden_keywords=(
            "buy drugs online", "purchase firearms illegally",
            "black market weapons",
        ),
        forbidden_patterns=(
            r"\b(buy|sell|purchase)\s+(illegal\s+)?(drugs|firearms|weapons)\s+(online|here|now)\b",
        ),
        forbidden_themes=(
            "illegal drug sales", "illegal firearm sales",
            "promoting regulated substance trade",
        ),
        source_url="https://support.google.com/youtube/answer/9229611",
    ),
    # ── Misinformation ───────────────────────────────────────
    PolicyRule(
        rule_id="yt-misinfo-01",
        category="misinformation",
        description="Harmful misinformation (medical, elections, public safety)",
        forbidden_keywords=(
            "vaccines cause autism", "election was stolen proof",
            "drinking bleach cures",
        ),
        forbidden_patterns=(
            r"\b(cure|treat)\s+(cancer|covid|aids)\s+with\s+(bleach|turpentine|ivermectin)\b",
            r"\belection\s+(was|is)\s+(stolen|rigged|fake)\b",
        ),
        forbidden_themes=(
            "medical misinformation",
            "election misinformation",
            "conspiracy theories causing public harm",
        ),
        source_url="https://support.google.com/youtube/answer/10834785",
    ),
)

YOUTUBE_POLICY = PlatformPolicy(
    platform="youtube_shorts",
    name="YouTube Community Guidelines",
    last_updated=_LAST_UPDATED,
    guidelines_url="https://support.google.com/youtube/answer/9288567",
    rules=_RULES,
)

register_policy(YOUTUBE_POLICY)
