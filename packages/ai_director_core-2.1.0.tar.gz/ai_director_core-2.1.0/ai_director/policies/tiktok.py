"""TikTok Community Guidelines policy rules.

Source: https://www.tiktok.com/community-guidelines/en/overview
Released: August 14, 2025 — Effective: September 13, 2025

TikTok organises its Community Guidelines into:
  Safety and Civility:
    - Violent and Criminal Behavior
    - Hate Speech and Hateful Behavior
    - Violent and Hateful Organizations and Individuals
    - Youth Sexual and Physical Abuse
    - Adult Sexual Abuse
    - Human Trafficking and Smuggling
    - Harassment and Bullying
  Mental and Behavioral Health:
    - Suicide and Self-Harm
    - Disordered Eating, Risky Weight Management, and Body Image
    - Dangerous Activity and Challenges
  Sensitive and Mature Themes:
    - Body Exposure and Sexualized Behaviors
    - Shocking and Graphic Content
    - Animal Abuse
  Integrity and Authenticity:
    - Misinformation
    - Civic and Election Integrity
    - Edited Media and AI-Generated Content (AIGC)
    - Unoriginal Content and Intellectual Property Rights
    - Deceptive Behaviors and Fake Engagement
  Regulated Goods:
    - Regulated Goods, Services, and Commercial Activities
    - Commercial Disclosure and Paid Marketing
    - Frauds and Scams
  Privacy and Security:
    - Personal Information
    - Platform Security
"""

from __future__ import annotations

from datetime import date

from . import PolicyRule, PlatformPolicy, register_policy

_LAST_UPDATED = date(2025, 8, 14)

_RULES: tuple[PolicyRule, ...] = (
    # ── Safety and Civility ──────────────────────────────────
    PolicyRule(
        rule_id="tt-violent-01",
        category="violent_criminal",
        description="Violent and criminal behavior — threats, glorification of violence, promotion of crime",
        forbidden_keywords=(
            "gore", "dismemberment", "beheading", "mutilation",
            "graphic violence", "mass shooting",
        ),
        forbidden_patterns=(
            r"\b(kill|murder|slaughter)\s+(them|people|everyone)\b",
            r"\bhow\s+to\s+(kill|murder|poison|assault)\b",
            r"\b(commit|plan)\s+(a\s+)?(crime|robbery|arson)\b",
        ),
        forbidden_themes=(
            "threats of violence", "glorification of violence",
            "instructions for committing crimes",
            "promotion of harmful acts",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/safety-civility",
    ),
    PolicyRule(
        rule_id="tt-hate-01",
        category="hate_speech",
        description="Hate speech and hateful behavior targeting protected attributes",
        forbidden_keywords=(
            "racial slur", "ethnic cleansing",
            "white supremacy", "kill all",
        ),
        forbidden_patterns=(
            r"\b(all|every)\s+\w+\s+(should|must|need\s+to)\s+(die|be\s+killed|be\s+eliminated)\b",
            r"\b(inferior|subhuman)\s+(race|people|group)\b",
        ),
        forbidden_themes=(
            "attacks based on race", "attacks based on religion",
            "attacks based on gender", "attacks based on sexual orientation",
            "hateful ideologies", "dehumanisation of protected groups",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/safety-civility",
    ),
    PolicyRule(
        rule_id="tt-extremist-01",
        category="violent_extremist_orgs",
        description="Violent and hateful organizations and individuals",
        forbidden_keywords=(
            "join the cartel", "terrorist recruitment",
            "pledge allegiance to isis",
        ),
        forbidden_patterns=(
            r"\b(join|support|recruit|pledge)\b.{0,30}\b(terrorist|cartel|militia|extremist)\b",
        ),
        forbidden_themes=(
            "promoting violent extremism",
            "recruiting for criminal organizations",
            "glorifying mass violence perpetrators",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/safety-civility",
    ),
    PolicyRule(
        rule_id="tt-youth-abuse-01",
        category="child_safety",
        description="Youth sexual and physical abuse — CSAM, grooming, sextortion",
        forbidden_keywords=(
            "child exploitation", "minor abuse",
            "child pornography", "csam", "grooming minors",
        ),
        forbidden_patterns=(
            r"\b(child|minor|underage)\s+(exploitation|abuse|trafficking)\b",
            r"\b(groom|sextort)\w*\s+(child|minor|teen|kid)\b",
        ),
        forbidden_themes=(
            "child sexual abuse material",
            "grooming", "sextortion of minors",
            "content sexualising minors",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/safety-civility",
    ),
    PolicyRule(
        rule_id="tt-adult-abuse-01",
        category="adult_sexual_abuse",
        description="Adult sexual abuse — non-consensual acts, image-based sexual abuse",
        forbidden_keywords=(
            "revenge porn", "non-consensual intimate",
        ),
        forbidden_patterns=(
            r"\b(non[\s-]?consensual|without\s+consent)\s+(sex|intimate|image)\b",
        ),
        forbidden_themes=(
            "non-consensual sexual acts",
            "image-based sexual abuse",
            "sextortion",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/safety-civility",
    ),
    PolicyRule(
        rule_id="tt-trafficking-01",
        category="human_trafficking",
        description="Human trafficking and smuggling",
        forbidden_keywords=(
            "human trafficking", "people smuggling",
            "sell humans", "slave trade",
        ),
        forbidden_patterns=(
            r"\b(traffic|smuggle)\s+(people|humans|persons|migrants)\b",
        ),
        forbidden_themes=(
            "promoting human trafficking",
            "facilitating smuggling of persons",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/safety-civility",
    ),
    PolicyRule(
        rule_id="tt-harassment-01",
        category="harassment",
        description="Harassment and bullying — degrading remarks, doxxing, sexual harassment",
        forbidden_keywords=(
            "doxxing", "swatting", "cyberstalking",
        ),
        forbidden_patterns=(
            r"\b(dox|doxx|swat)\s+(this|that|the)\s+(person|guy|girl|user)\b",
            r"\bshare\s+(their|his|her)\s+(address|phone|location)\b",
        ),
        forbidden_themes=(
            "sustained harassment", "doxxing",
            "sexual harassment", "coordinated bullying",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/safety-civility",
    ),
    # ── Mental and Behavioral Health ─────────────────────────
    PolicyRule(
        rule_id="tt-selfharm-01",
        category="suicide_selfharm",
        description="Suicide and self-harm promotion",
        forbidden_keywords=(
            "how to commit suicide", "suicide methods",
            "self-harm instructions",
        ),
        forbidden_patterns=(
            r"\bhow\s+to\s+(commit\s+suicide|self[\s-]?harm|cut\s+yourself)\b",
        ),
        forbidden_themes=(
            "promoting suicide", "instructions for self-harm",
            "glorifying self-harm",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/mental-behavioral-health",
    ),
    PolicyRule(
        rule_id="tt-eating-01",
        category="disordered_eating",
        description="Disordered eating and risky weight management",
        forbidden_keywords=(
            "pro-anorexia", "pro-ana", "thinspo", "bonespo",
        ),
        forbidden_patterns=(
            r"\b(pro[\s-]?ana|thinspo|bonespo)\b",
        ),
        forbidden_themes=(
            "promoting eating disorders",
            "risky weight loss methods",
            "harmful body comparisons",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/mental-behavioral-health",
    ),
    PolicyRule(
        rule_id="tt-dangerous-01",
        category="dangerous_challenges",
        description="Dangerous activities and challenges that could cause physical harm",
        forbidden_keywords=(
            "tide pod challenge", "choking game",
            "blackout challenge", "fire challenge",
        ),
        forbidden_patterns=(
            r"\bdangerous\s+challenge\b",
            r"\bhow\s+to\s+make\s+(a\s+)?(bomb|explosive|weapon)\b",
        ),
        forbidden_themes=(
            "dangerous stunts", "harmful dares",
            "challenges leading to physical harm",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/mental-behavioral-health",
    ),
    # ── Sensitive and Mature Themes ──────────────────────────
    PolicyRule(
        rule_id="tt-sexual-01",
        category="sexually_explicit",
        description="Body exposure and sexualized behaviors — nudity, sexual activity, sexual services",
        forbidden_keywords=(
            "pornography", "explicit sex",
            "sexual intercourse", "nude video",
        ),
        forbidden_patterns=(
            r"\b(porn|xxx|nsfw)\b",
            r"\bsexual(ly)?\s+(explicit|graphic)\b",
        ),
        forbidden_themes=(
            "nudity", "sexual activity",
            "sexual services", "pornographic content",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/sensitive-mature-themes",
    ),
    PolicyRule(
        rule_id="tt-graphic-01",
        category="shocking_graphic",
        description="Shocking and graphic content — extreme gore, violence, disturbing content",
        forbidden_keywords=(
            "extreme gore", "graphic death",
        ),
        forbidden_patterns=(
            r"\b(extremely|highly)\s+(graphic|gory|violent)\b",
        ),
        forbidden_themes=(
            "extremely gory content",
            "content causing psychological harm",
            "disturbing violent content",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/sensitive-mature-themes",
    ),
    PolicyRule(
        rule_id="tt-animal-01",
        category="animal_abuse",
        description="Animal abuse, cruelty, neglect, or exploitation",
        forbidden_keywords=(
            "animal cruelty", "animal torture",
            "animal fighting", "dog fighting",
        ),
        forbidden_patterns=(
            r"\b(torture|abuse|fight)\s+(animal|dog|cat|pet)s?\b",
        ),
        forbidden_themes=(
            "animal abuse", "animal cruelty",
            "animal exploitation", "animal fighting",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/sensitive-mature-themes",
    ),
    # ── Integrity and Authenticity ───────────────────────────
    PolicyRule(
        rule_id="tt-misinfo-01",
        category="misinformation",
        description="Misinformation causing significant harm to individuals or society",
        forbidden_keywords=(
            "vaccines cause autism", "election was stolen proof",
            "drinking bleach cures",
        ),
        forbidden_patterns=(
            r"\b(cure|treat)\s+(cancer|covid|aids)\s+with\s+(bleach|turpentine|ivermectin)\b",
            r"\belection\s+(was|is)\s+(stolen|rigged|fake)\b",
        ),
        forbidden_themes=(
            "medical misinformation", "election misinformation",
            "harmful conspiracy theories", "public safety misinformation",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/integrity-authenticity",
    ),
    PolicyRule(
        rule_id="tt-election-01",
        category="civic_election_integrity",
        description="Civic and election integrity — misleading voting info, election interference",
        forbidden_keywords=(
            "election was stolen proof",
        ),
        forbidden_patterns=(
            r"\bvote\s+(at|on)\s+(wrong|fake|invalid)\b",
            r"\b(prevent|stop)\s+(people|them)\s+from\s+voting\b",
        ),
        forbidden_themes=(
            "false voting information",
            "election interference",
            "discouraging lawful voting",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/integrity-authenticity",
    ),
    PolicyRule(
        rule_id="tt-aigc-01",
        category="deceptive_aigc",
        description="Unlabeled AI-generated content depicting realistic people or scenes",
        forbidden_themes=(
            "unlabeled AI-generated realistic content",
            "deepfakes without disclosure",
            "misleading synthetic media",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/integrity-authenticity",
    ),
    # ── Regulated Goods ──────────────────────────────────────
    PolicyRule(
        rule_id="tt-regulated-01",
        category="regulated_goods",
        description="Regulated goods, services, and commercial activities",
        forbidden_keywords=(
            "buy drugs online", "purchase firearms illegally",
            "black market weapons",
        ),
        forbidden_patterns=(
            r"\b(buy|sell|purchase)\s+(illegal\s+)?(drugs|firearms|weapons)\s+(online|here|now)\b",
        ),
        forbidden_themes=(
            "illegal drug sales", "illegal weapon trade",
            "prohibited goods trading",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/regulated-goods",
    ),
    PolicyRule(
        rule_id="tt-fraud-01",
        category="fraud_scams",
        description="Frauds and scams",
        forbidden_keywords=(
            "free money hack", "get rich quick guaranteed",
            "click here to claim prize",
        ),
        forbidden_patterns=(
            r"\b(guaranteed|100%)\s+(money|profit|returns)\b",
            r"\bsend\s+(money|bitcoin|crypto)\s+to\b",
        ),
        forbidden_themes=(
            "financial scams", "fraudulent schemes",
            "deceptive money-making claims",
        ),
        source_url="https://www.tiktok.com/community-guidelines/en/regulated-goods",
    ),
)

TIKTOK_POLICY = PlatformPolicy(
    platform="tiktok",
    name="TikTok Community Guidelines",
    last_updated=_LAST_UPDATED,
    guidelines_url="https://www.tiktok.com/community-guidelines/en/overview",
    rules=_RULES,
)

register_policy(TIKTOK_POLICY)
