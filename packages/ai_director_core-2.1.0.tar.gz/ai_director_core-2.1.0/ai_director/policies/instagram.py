"""Instagram Reels / Meta Community Standards policy rules.

Source: https://transparency.meta.com/policies/community-standards/
Last reviewed: 2025-07-15

Meta Community Standards (applying to Facebook, Instagram, Messenger, Threads):
  - Coordinating Harm and Promoting Crime
  - Dangerous Organizations and Individuals
  - Fraud, Scams, and Deceptive Practices
  - Restricted Goods and Services
  - Violence and Incitement
  - Adult Sexual Exploitation
  - Bullying and Harassment
  - Child Sexual Exploitation, Abuse, and Nudity
  - Misinformation
  - Suicide and Self-Injury
  - Hate Speech
"""

from __future__ import annotations

from datetime import date

from . import PolicyRule, PlatformPolicy, register_policy

_LAST_UPDATED = date(2025, 7, 15)

_RULES: tuple[PolicyRule, ...] = (
    # ── Violence and Incitement ──────────────────────────────
    PolicyRule(
        rule_id="ig-violent-01",
        category="violence_incitement",
        description="Violence and incitement — threats, glorification of violence",
        forbidden_keywords=(
            "gore", "dismemberment", "beheading", "mutilation",
            "graphic violence", "mass shooting",
        ),
        forbidden_patterns=(
            r"\b(kill|murder|slaughter)\s+(them|people|everyone)\b",
            r"\bhow\s+to\s+(kill|murder|poison)\b",
        ),
        forbidden_themes=(
            "credible threats of violence",
            "glorification of violence",
            "incitement to violence",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/violence-incitement/",
    ),
    # ── Coordinating Harm and Promoting Crime ────────────────
    PolicyRule(
        rule_id="ig-harm-01",
        category="coordinating_harm",
        description="Coordinating harm and promoting crime",
        forbidden_patterns=(
            r"\b(commit|plan)\s+(a\s+)?(crime|robbery|arson)\b",
            r"\bhow\s+to\s+make\s+(a\s+)?(bomb|explosive|weapon)\b",
        ),
        forbidden_themes=(
            "coordinating real-world harm",
            "promoting criminal activity",
            "facilitating dangerous acts",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/coordinating-harm-publicizing-crime/",
    ),
    # ── Dangerous Organizations and Individuals ──────────────
    PolicyRule(
        rule_id="ig-dangerous-org-01",
        category="dangerous_orgs",
        description="Dangerous organizations and individuals — terrorist groups, criminal organizations",
        forbidden_keywords=(
            "join the cartel", "terrorist recruitment",
            "pledge allegiance to isis",
        ),
        forbidden_patterns=(
            r"\b(join|support|recruit|pledge)\b.{0,30}\b(terrorist|cartel|militia|extremist)\b",
        ),
        forbidden_themes=(
            "promoting terrorist organizations",
            "glorifying violent extremism",
            "recruiting for criminal organizations",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/dangerous-individuals-organizations/",
    ),
    # ── Hate Speech ──────────────────────────────────────────
    PolicyRule(
        rule_id="ig-hate-01",
        category="hate_speech",
        description="Hate speech targeting protected characteristics",
        forbidden_keywords=(
            "racial slur", "ethnic cleansing",
            "white supremacy", "kill all",
        ),
        forbidden_patterns=(
            r"\b(all|every)\s+\w+\s+(should|must|need\s+to)\s+(die|be\s+killed|be\s+eliminated)\b",
            r"\b(inferior|subhuman)\s+(race|people|group)\b",
        ),
        forbidden_themes=(
            "attacks based on race",
            "attacks based on religion",
            "attacks based on gender or sexual orientation",
            "dehumanisation of protected groups",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/hate-speech/",
    ),
    # ── Bullying and Harassment ──────────────────────────────
    PolicyRule(
        rule_id="ig-harassment-01",
        category="harassment",
        description="Bullying and harassment",
        forbidden_keywords=(
            "doxxing", "swatting", "cyberstalking",
        ),
        forbidden_patterns=(
            r"\b(dox|doxx|swat)\s+(this|that|the)\s+(person|guy|girl|user)\b",
            r"\bshare\s+(their|his|her)\s+(address|phone|location)\b",
        ),
        forbidden_themes=(
            "targeted harassment", "doxxing",
            "sexual harassment", "degrading attacks on appearance",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/bullying-harassment/",
    ),
    # ── Adult Sexual Exploitation ────────────────────────────
    PolicyRule(
        rule_id="ig-sexual-01",
        category="sexually_explicit",
        description="Adult sexual exploitation and explicit content",
        forbidden_keywords=(
            "pornography", "explicit sex",
            "sexual intercourse", "nude video",
            "revenge porn",
        ),
        forbidden_patterns=(
            r"\b(porn|xxx|nsfw)\b",
            r"\bsexual(ly)?\s+(explicit|graphic)\b",
        ),
        forbidden_themes=(
            "pornographic content", "non-consensual intimate images",
            "sexual exploitation", "sexual services",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/sexual-exploitation-adults/",
    ),
    # ── Child Sexual Exploitation ────────────────────────────
    PolicyRule(
        rule_id="ig-child-safety-01",
        category="child_safety",
        description="Child sexual exploitation, abuse, and nudity",
        forbidden_keywords=(
            "child exploitation", "minor abuse",
            "child pornography", "csam", "grooming minors",
        ),
        forbidden_patterns=(
            r"\b(child|minor|underage)\s+(exploitation|abuse|trafficking)\b",
            r"\b(groom|sextort)\w*\s+(child|minor|teen|kid)\b",
        ),
        forbidden_themes=(
            "child sexual abuse material",
            "grooming", "sextortion of minors",
            "content sexualising minors",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/child-sexual-exploitation-abuse-and-nudity/",
    ),
    # ── Suicide and Self-Injury ──────────────────────────────
    PolicyRule(
        rule_id="ig-selfharm-01",
        category="suicide_selfharm",
        description="Suicide and self-injury promotion",
        forbidden_keywords=(
            "how to commit suicide", "suicide methods",
            "pro-anorexia", "pro-ana", "thinspo",
        ),
        forbidden_patterns=(
            r"\bhow\s+to\s+(commit\s+suicide|self[\s-]?harm|cut\s+yourself)\b",
            r"\b(pro[\s-]?ana|thinspo|bonespo)\b",
        ),
        forbidden_themes=(
            "promoting suicide", "instructions for self-harm",
            "glorifying self-injury",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/suicide-self-injury/",
    ),
    # ── Fraud, Scams, and Deceptive Practices ────────────────
    PolicyRule(
        rule_id="ig-fraud-01",
        category="fraud_scams",
        description="Fraud, scams, and deceptive practices",
        forbidden_keywords=(
            "free money hack", "get rich quick guaranteed",
            "click here to claim prize",
        ),
        forbidden_patterns=(
            r"\b(guaranteed|100%)\s+(money|profit|returns)\b",
            r"\bsend\s+(money|bitcoin|crypto)\s+to\b",
        ),
        forbidden_themes=(
            "financial scams", "fraudulent schemes",
            "phishing", "deceptive practices",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/fraud-scams/",
    ),
    # ── Restricted Goods and Services ────────────────────────
    PolicyRule(
        rule_id="ig-regulated-01",
        category="regulated_goods",
        description="Restricted goods and services",
        forbidden_keywords=(
            "buy drugs online", "purchase firearms illegally",
            "black market weapons",
        ),
        forbidden_patterns=(
            r"\b(buy|sell|purchase)\s+(illegal\s+)?(drugs|firearms|weapons)\s+(online|here|now)\b",
        ),
        forbidden_themes=(
            "illegal drug sales", "illegal weapon trade",
            "prohibited goods trading",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/regulated-goods/",
    ),
    # ── Misinformation ───────────────────────────────────────
    PolicyRule(
        rule_id="ig-misinfo-01",
        category="misinformation",
        description="Misinformation that could cause harm",
        forbidden_keywords=(
            "vaccines cause autism", "election was stolen proof",
            "drinking bleach cures",
        ),
        forbidden_patterns=(
            r"\b(cure|treat)\s+(cancer|covid|aids)\s+with\s+(bleach|turpentine|ivermectin)\b",
            r"\belection\s+(was|is)\s+(stolen|rigged|fake)\b",
        ),
        forbidden_themes=(
            "medical misinformation",
            "election misinformation",
            "harmful conspiracy theories",
        ),
        source_url="https://transparency.meta.com/policies/community-standards/misinformation/",
    ),
)

INSTAGRAM_POLICY = PlatformPolicy(
    platform="instagram_reels",
    name="Instagram / Meta Community Standards",
    last_updated=_LAST_UPDATED,
    guidelines_url="https://transparency.meta.com/policies/community-standards/",
    rules=_RULES,
)

register_policy(INSTAGRAM_POLICY)
