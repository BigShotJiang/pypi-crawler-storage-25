"""Platform policy registry for content compliance auditing.

Each platform module defines policy rules based on the platform's
official Community Guidelines. Rules are used by PolicyAuditor to
enforce zero-tolerance content compliance.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from typing import Literal


@dataclass(frozen=True)
class PolicyRule:
    """A single policy rule for content compliance.

    Attributes:
        rule_id: Unique identifier (e.g., "yt-violent-01")
        category: Policy category (e.g., "violent_graphic")
        severity: Always "block" — no warnings for policy violations
        description: Human-readable description of the rule
        forbidden_keywords: Exact keywords/phrases that trigger violation
        forbidden_patterns: Regex patterns that trigger violation
        forbidden_themes: Semantic categories for AI tier-2 check
        source_url: URL to the official policy documentation
    """

    rule_id: str
    category: str
    severity: Literal["block"] = "block"
    description: str = ""
    forbidden_keywords: tuple[str, ...] = ()
    forbidden_patterns: tuple[str, ...] = ()
    forbidden_themes: tuple[str, ...] = ()
    source_url: str = ""


@dataclass(frozen=True)
class PlatformPolicy:
    """Complete policy set for a platform.

    Attributes:
        platform: Platform identifier matching ChannelConfig.target_platform
        name: Human-readable name
        last_updated: Date when rules were last synced with platform docs
        guidelines_url: URL to the platform's community guidelines
        rules: Tuple of PolicyRule objects
    """

    platform: str
    name: str
    last_updated: date
    guidelines_url: str
    rules: tuple[PolicyRule, ...] = ()

    def get_rules_by_category(self, category: str) -> tuple[PolicyRule, ...]:
        return tuple(r for r in self.rules if r.category == category)

    @property
    def categories(self) -> tuple[str, ...]:
        return tuple(sorted({r.category for r in self.rules}))


def _compile_pattern(pattern: str) -> re.Pattern[str]:
    """Compile a regex pattern for keyword matching (case-insensitive)."""
    return re.compile(pattern, re.IGNORECASE)


def check_text_against_rules(
    text: str,
    rules: tuple[PolicyRule, ...],
) -> list[dict[str, str]]:
    """Check text against policy rules (Tier 1: keyword/pattern matching).

    Returns list of violations found.
    """
    violations: list[dict[str, str]] = []
    text_lower = text.lower()

    for rule in rules:
        # Check forbidden keywords
        for kw in rule.forbidden_keywords:
            if kw.lower() in text_lower:
                violations.append({
                    "rule_id": rule.rule_id,
                    "category": rule.category,
                    "severity": rule.severity,
                    "description": rule.description,
                    "matched": kw,
                    "match_type": "keyword",
                })
                break  # One match per rule is enough

        # Check forbidden patterns (regex)
        for pat_str in rule.forbidden_patterns:
            pat = _compile_pattern(pat_str)
            match = pat.search(text)
            if match:
                violations.append({
                    "rule_id": rule.rule_id,
                    "category": rule.category,
                    "severity": rule.severity,
                    "description": rule.description,
                    "matched": match.group(),
                    "match_type": "pattern",
                })
                break

    return violations


# ── Platform registry ────────────────────────────────────────

_REGISTRY: dict[str, PlatformPolicy] = {}


def register_policy(policy: PlatformPolicy) -> None:
    """Register a platform policy in the global registry."""
    _REGISTRY[policy.platform] = policy


def get_policy(platform: str) -> PlatformPolicy:
    """Get the policy for a platform. Raises KeyError if not found."""
    if platform not in _REGISTRY:
        raise KeyError(
            f"No policy registered for platform '{platform}'. "
            f"Available: {', '.join(_REGISTRY.keys())}"
        )
    return _REGISTRY[platform]


def list_platforms() -> list[str]:
    """List all platforms with registered policies."""
    return sorted(_REGISTRY.keys())


# Auto-register all platform policies on import
from . import youtube, tiktok, instagram  # noqa: E402, F401
