from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any

from .agents.asset_resolver import AssetResolver
from .agents.motion_director import MotionDirector
from .agents.policy_auditor import PolicyAuditor
from .agents.qa_validator import QAValidator
from .agents.script_writer import ScriptWriter
from .agents.shot_list_director import ShotListDirector
from .budget.tracker import BudgetDecision, BudgetTracker, GCSStorageBackend
from .config_loader import load_channel_config
from .models.config import ChannelConfig

logger = logging.getLogger(__name__)

# Estimated costs per agent step (USD) — conservative estimates
_COST_ESTIMATES: dict[str, tuple[str, float]] = {
    "script": ("api_calls", 0.03),
    "shots": ("api_calls", 0.02),
    "assets": ("asset_gen", 0.15),
    "motion": ("api_calls", 0.01),
    "policy_audit": ("api_calls", 0.01),
    "qa": ("api_calls", 0.02),
}

# Agent execution order
_AGENT_PIPELINE = [
    ("script", ScriptWriter),
    ("shots", ShotListDirector),
    ("assets", AssetResolver),
    ("motion", MotionDirector),
    ("policy_audit", PolicyAuditor),
    ("qa", QAValidator),
]


def run_full_pipeline(
    config: ChannelConfig,
    topic: str,
    topic_id: str,
    output_dir: str,
) -> dict[str, Any]:
    """Run the full video production pipeline with budget awareness.

    Returns a result dict with status: "ready" | "qa_failed" | "budget_blocked"
    """
    channel = config.channel_name.lower().replace(" ", "_")
    logger.info("[%s] Starting pipeline for topic '%s' (id=%s)", channel, topic, topic_id)

    # Initialize budget tracker
    budget = BudgetTracker(
        channel_name=channel,
        budget_config=config.budget,
        storage=GCSStorageBackend(),
    )

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    input_data: dict[str, Any] = {"topic": topic, "topic_id": topic_id}
    results: dict[str, Any] = {}

    for agent_name, agent_cls in _AGENT_PIPELINE:
        cost_type, estimated = _COST_ESTIMATES[agent_name]

        # Pre-flight budget check
        decision = budget.check_budget(cost_type, estimated)

        if decision == BudgetDecision.STOP:
            logger.error("[%s] Budget hard stop before %s", channel, agent_name)
            budget.persist(video_completed=False)
            return {
                "status": "budget_blocked",
                "stopped_at": agent_name,
                "budget_summary": _summary_dict(budget),
            }

        if decision == BudgetDecision.FALLBACK and agent_name == "assets":
            # Fallback: remove AI generation from asset sources
            logger.warning("[%s] Budget fallback: disabling AI asset generation", channel)
            config = _remove_ai_sources(config)

        # Run agent
        agent = agent_cls(config)
        result = agent.run(input_data)
        results[agent_name] = result

        # Record actual cost
        budget.record_cost(cost_type, estimated)

        # Hard stop on policy violation — video will NOT be produced
        if agent_name == "policy_audit" and result.get("status") == "policy_violation":
            logger.error(
                "[%s] POLICY VIOLATION — %d violation(s) found, stopping pipeline",
                channel,
                len(result.get("violations", [])),
            )
            budget.persist(video_completed=False)
            return {
                "status": "policy_violation",
                "stopped_at": "policy_audit",
                "violations": result.get("violations", []),
                "policy_name": result.get("policy_name"),
                "results": results,
                "budget_summary": _summary_dict(budget),
            }

        # Pass output to next agent
        input_data = result

        # Save intermediate output
        output_path = out / f"{agent_name}.json"
        output_path.write_text(json.dumps(result, indent=2, default=str))

    # Persist budget data
    budget.persist(video_completed=True)

    # Build final package
    status = results.get("qa", {}).get("status", "ready")
    package = {
        "status": status or "ready",
        "topic": topic,
        "topic_id": topic_id,
        "channel_name": config.channel_name,
        "aspect_ratio": config.aspect_ratio,
        "results": results,
        "budget_summary": _summary_dict(budget),
    }

    package_path = out / "video_package.json"
    package_path.write_text(json.dumps(package, indent=2, default=str))

    logger.info("[%s] Pipeline complete: status=%s", channel, package["status"])
    return package


def run_single_agent(
    agent_name: str,
    config: ChannelConfig,
    input_path: str,
    output_path: str,
) -> None:
    """Run a single agent for debugging/testing."""
    agent_map = dict(_AGENT_PIPELINE)
    if agent_name not in agent_map:
        raise ValueError(f"Unknown agent: {agent_name}")

    with open(input_path) as f:
        input_data = json.load(f)

    agent = agent_map[agent_name](config)
    result = agent.run(input_data)

    with open(output_path, "w") as f:
        json.dump(result, f, indent=2, default=str)


def _remove_ai_sources(config: ChannelConfig) -> ChannelConfig:
    """Remove expensive AI generation sources from config (budget fallback)."""
    filtered = [s for s in config.asset_sources_priority if s != "ai_generate_flux"]
    if not filtered:
        filtered = ["pexels_search"]
    return config.model_copy(update={"asset_sources_priority": filtered})


def _summary_dict(budget: BudgetTracker) -> dict[str, Any]:
    s = budget.get_remaining()
    return {
        "period": s.period,
        "monthly_limit_usd": s.monthly_limit_usd,
        "total_spent_usd": s.total_spent_usd,
        "remaining_usd": s.remaining_usd,
        "videos_produced": s.videos_produced,
    }
