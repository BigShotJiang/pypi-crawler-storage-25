from __future__ import annotations

import re
from pathlib import Path

_PYPROJECT = Path(__file__).resolve().parent.parent / "pyproject.toml"
_VERSION_RE = re.compile(r'^version\s*=\s*"(\d+\.\d+\.\d+)"', re.MULTILINE)


def get_version() -> str:
    """Read current version from pyproject.toml."""
    text = _PYPROJECT.read_text()
    m = _VERSION_RE.search(text)
    if not m:
        raise RuntimeError("Could not find version in pyproject.toml")
    return m.group(1)


def bump_version(level: str) -> tuple[str, str]:
    """Bump version in pyproject.toml. Returns (old_version, new_version)."""
    text = _PYPROJECT.read_text()
    m = _VERSION_RE.search(text)
    if not m:
        raise RuntimeError("Could not find version in pyproject.toml")

    old = m.group(1)
    major, minor, patch = (int(x) for x in old.split("."))

    if level == "patch":
        patch += 1
    elif level == "minor":
        minor += 1
        patch = 0
    elif level == "major":
        major += 1
        minor = 0
        patch = 0
    else:
        raise ValueError(f"Invalid level: {level}")

    new = f"{major}.{minor}.{patch}"
    new_text = text[:m.start(1)] + new + text[m.end(1):]
    _PYPROJECT.write_text(new_text)
    return old, new
