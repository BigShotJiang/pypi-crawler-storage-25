"""AI Director Dashboard — web-based management portal.

Launch with: ``ad dashboard`` or ``ai-director dashboard``
"""

from __future__ import annotations

from .server import serve

__all__ = ["serve"]
