"""Lightweight HTTP server that serves the built dashboard SPA."""

from __future__ import annotations

import http.server
import os
import sys
from functools import partial
from pathlib import Path

STATIC_DIR = Path(__file__).parent / "static"


class _SPAHandler(http.server.SimpleHTTPRequestHandler):
    """Serve static files; fall back to index.html for SPA routing."""

    def do_GET(self) -> None:
        # Resolve the requested path against the static directory
        rel = self.path.lstrip("/").split("?")[0]
        target = Path(self.directory) / rel  # type: ignore[attr-defined]

        if target.is_file():
            super().do_GET()
        else:
            # SPA fallback — serve index.html for client-side routes
            self.path = "/index.html"
            super().do_GET()

    def log_message(self, fmt: str, *args: object) -> None:
        # Quieter logging
        sys.stderr.write(f"[dashboard] {fmt % args}\n")


def serve(host: str = "127.0.0.1", port: int = 3456) -> None:
    """Start the dashboard HTTP server."""
    if not (STATIC_DIR / "index.html").exists():
        print(
            "❌ Dashboard static files not found.\n"
            "   Run 'cd dashboard && npm run build' to build the frontend first."
        )
        sys.exit(1)

    handler = partial(_SPAHandler, directory=str(STATIC_DIR))
    server = http.server.HTTPServer((host, port), handler)

    print(f"◈ AI Director Dashboard")
    print(f"  Local: http://{host}:{port}/")
    print(f"  Press Ctrl+C to stop.\n")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n◈ Dashboard stopped.")
        server.server_close()
