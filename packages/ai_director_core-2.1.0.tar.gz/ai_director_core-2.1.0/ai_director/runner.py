from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .config_loader import load_channel_config, validate_config
from .budget.tracker import BudgetTracker, GCSStorageBackend
from .scaffold import run_scaffold


def main() -> None:
    parser = argparse.ArgumentParser(prog="ai-director")
    subparsers = parser.add_subparsers(dest="command")

    # ── run ────────────────────────────────────────────────
    run_parser = subparsers.add_parser("run", help="Run the full pipeline")
    run_parser.add_argument("--config", required=True, help="Path to channel_config.json")
    run_parser.add_argument("--topic", required=True, help="Topic title to process")
    run_parser.add_argument("--topic-id", required=True)
    run_parser.add_argument("--output-dir", default="outputs/")

    # ── validate ───────────────────────────────────────────
    validate_parser = subparsers.add_parser("validate", help="Validate channel config")
    validate_parser.add_argument("--config", required=True)

    # ── agent ──────────────────────────────────────────────
    agent_parser = subparsers.add_parser("agent", help="Run a single agent")
    agent_parser.add_argument("--name", choices=["script", "shots", "assets", "motion", "qa"], required=True)
    agent_parser.add_argument("--config", required=True)
    agent_parser.add_argument("--input", required=True)
    agent_parser.add_argument("--output", required=True)

    # ── budget ─────────────────────────────────────────────
    budget_parser = subparsers.add_parser("budget", help="Budget management")
    budget_sub = budget_parser.add_subparsers(dest="budget_command")
    budget_status = budget_sub.add_parser("status", help="Show budget status")
    budget_status.add_argument("--config", required=True)
    budget_status.add_argument("--json", action="store_true", dest="as_json")

    # ── migrate ────────────────────────────────────────────
    migrate_parser = subparsers.add_parser("migrate", help="Migrate config to latest schema")
    migrate_parser.add_argument("--config", required=True)
    migrate_parser.add_argument("--output", help="Output path (default: overwrite)")

    # ── init ───────────────────────────────────────────────
    init_parser = subparsers.add_parser("init", help="Generate boilerplate channel config")
    init_parser.add_argument("--name", required=True, help="Channel name")
    init_parser.add_argument("--niche", required=True, help="Channel niche")
    init_parser.add_argument("--output", default="data/channel_config.json")

    # ── scaffold ───────────────────────────────────────────
    scaffold_parser = subparsers.add_parser("scaffold", help="Interactive wizard to scaffold a new brand repo")
    scaffold_parser.add_argument("--output-dir", default=".", help="Output directory (default: current dir)")
    scaffold_parser.add_argument("--non-interactive", action="store_true", help="Non-interactive mode (all args required)")
    scaffold_parser.add_argument("--name", help="Channel name")
    scaffold_parser.add_argument("--niche", help="Channel niche")
    scaffold_parser.add_argument("--voice", help="Brand voice / narrative tone")
    scaffold_parser.add_argument("--audience", help="Target audience description")
    scaffold_parser.add_argument("--platform", help="Target platform")
    scaffold_parser.add_argument("--language", help="Language code")
    scaffold_parser.add_argument("--aspect-ratio", help="Aspect ratio (9:16, 16:9, 1:1)")
    scaffold_parser.add_argument("--duration", type=int, help="Video duration in seconds")
    scaffold_parser.add_argument("--budget-monthly", type=float, help="Monthly budget limit (USD)")
    scaffold_parser.add_argument("--budget-per-video", type=float, help="Per-video budget limit (USD)")

    # ── version ─────────────────────────────────────────────
    version_parser = subparsers.add_parser("version", help="Show or bump version")
    version_sub = version_parser.add_subparsers(dest="version_command")
    bump_parser = version_sub.add_parser("bump", help="Bump version (patch/minor/major)")
    bump_parser.add_argument("level", choices=["patch", "minor", "major"], help="Version bump level")
    bump_parser.add_argument("--no-tag", action="store_true", help="Skip git tag creation")

    # ── audit ──────────────────────────────────────────────
    audit_parser = subparsers.add_parser("audit", help="Run policy audit on content")
    audit_parser.add_argument("--config", required=True, help="Path to channel_config.json")
    audit_parser.add_argument("--input", required=True, help="Path to pipeline data JSON (script, shots, assets)")
    audit_parser.add_argument("--check-freshness", action="store_true", help="Warn if policy rules are stale")
    audit_parser.add_argument("--json", action="store_true", dest="as_json", help="Output as JSON")

    # ── dashboard ───────────────────────────────────────────
    dashboard_parser = subparsers.add_parser("dashboard", help="Launch the web dashboard")
    dashboard_parser.add_argument("--port", type=int, default=3456, help="Server port (default: 3456)")
    dashboard_parser.add_argument("--host", default="127.0.0.1", help="Server host (default: 127.0.0.1)")

    # ── app-info ────────────────────────────────────────────
    app_info_parser = subparsers.add_parser("app-info", help="Generate or show .ai-director.json manifest")
    app_info_parser.add_argument("--config", required=True, help="Path to channel_config.json")
    app_info_parser.add_argument("--show", action="store_true", help="Print manifest to stdout instead of writing file")
    app_info_parser.add_argument("--output", default=".ai-director.json", help="Output path (default: .ai-director.json)")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "validate":
        _cmd_validate(args)
    elif args.command == "run":
        _cmd_run(args)
    elif args.command == "agent":
        _cmd_agent(args)
    elif args.command == "budget":
        _cmd_budget(args)
    elif args.command == "migrate":
        _cmd_migrate(args)
    elif args.command == "init":
        _cmd_init(args)
    elif args.command == "scaffold":
        run_scaffold(args)
    elif args.command == "version":
        _cmd_version(args)
    elif args.command == "audit":
        _cmd_audit(args)
    elif args.command == "dashboard":
        _cmd_dashboard(args)
    elif args.command == "app-info":
        _cmd_app_info(args)


def _cmd_dashboard(args: argparse.Namespace) -> None:
    from .dashboard import serve
    serve(host=args.host, port=args.port)


def _cmd_app_info(args: argparse.Namespace) -> None:
    from datetime import datetime, timezone
    from .version import get_version
    from .models.config import resolve_models

    config = load_channel_config(args.config)
    llm_model, image_model = resolve_models(config)

    manifest = {
        "name": config.channel_name,
        "core_version": get_version(),
        "niche": config.channel_niche,
        "platform": config.target_platform,
        "ai_models": {
            "llm_model": llm_model,
            "image_model": image_model,
        },
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }

    output = json.dumps(manifest, indent=2)
    if args.show:
        print(output)
    else:
        out_path = Path(args.output)
        out_path.write_text(output + "\n")
        print(f"✅ Wrote {out_path}")


def _cmd_version(args: argparse.Namespace) -> None:
    from .version import get_version, bump_version

    if getattr(args, "version_command", None) == "bump":
        old, new = bump_version(args.level)
        print(f"📦 {old} → {new}")
        if not getattr(args, "no_tag", False):
            import subprocess
            try:
                pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
                subprocess.run(["git", "add", str(pyproject)], check=True, capture_output=True)
                subprocess.run(["git", "commit", "-m", f"chore: bump version to {new}"], check=True, capture_output=True)
                subprocess.run(["git", "tag", f"v{new}"], check=True, capture_output=True)
                print(f"🏷️  Tagged v{new}")
            except FileNotFoundError:
                print("⚠️  git not found — skipped tag")
            except subprocess.CalledProcessError as e:
                print(f"⚠️  git error: {e}")
    else:
        print(get_version())


def _cmd_validate(args: argparse.Namespace) -> None:
    try:
        config = load_channel_config(args.config)
    except Exception as e:
        print(f"❌ Config load failed: {e}")
        sys.exit(1)

    errors = validate_config(config)

    # Check brand_identity
    if config.brand_identity:
        print(f"✅ brand_identity: loaded ({config.brand_identity.brand_voice[:50]}...)")
    else:
        print("⚠️  brand_identity: not configured (optional)")

    # Check budget
    if config.budget:
        print(f"✅ budget: ${config.budget.monthly_limit_usd}/month, ${config.budget.per_video_limit_usd}/video")
    else:
        print("⚠️  budget: not configured (unlimited)")

    if errors:
        print("\n❌ Validation errors:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)

    print(f"\n✅ Config valid for channel '{config.channel_name}'")


def _cmd_run(args: argparse.Namespace) -> None:
    config = load_channel_config(args.config)
    from .pipeline import run_full_pipeline

    result = run_full_pipeline(config, args.topic, args.topic_id, args.output_dir)
    status = result.get("status", "unknown")
    print(f"Pipeline result: {status}")
    sys.exit(0 if status == "ready" else 1)


def _cmd_agent(args: argparse.Namespace) -> None:
    config = load_channel_config(args.config)
    from .pipeline import run_single_agent

    run_single_agent(args.name, config, args.input, args.output)


def _cmd_budget(args: argparse.Namespace) -> None:
    if args.budget_command != "status":
        print("Usage: ai-director budget status --config <path>")
        sys.exit(1)

    config = load_channel_config(args.config)
    channel = config.channel_name.lower().replace(" ", "_")
    tracker = BudgetTracker(
        channel_name=channel,
        budget_config=config.budget,
        storage=GCSStorageBackend(),
    )
    summary = tracker.get_remaining()

    if args.as_json:
        data = {
            "channel_name": summary.channel_name,
            "period": summary.period,
            "monthly_limit_usd": summary.monthly_limit_usd,
            "total_spent_usd": summary.total_spent_usd,
            "remaining_usd": summary.remaining_usd,
            "spent_by_category": summary.spent_by_category,
            "videos_produced": summary.videos_produced,
            "can_proceed": summary.remaining_usd > 0,
        }
        print(json.dumps(data, indent=2, default=str))
    else:
        print(f"📊 Budget Status: {config.channel_name}")
        print(f"   Period: {summary.period}")
        if summary.monthly_limit_usd == float("inf"):
            print("   Budget: unlimited")
        else:
            print(f"   Monthly limit: ${summary.monthly_limit_usd:.2f}")
            print(f"   Total spent:   ${summary.total_spent_usd:.2f}")
            print(f"   Remaining:     ${summary.remaining_usd:.2f}")
        print(f"   Videos produced: {summary.videos_produced}")
        if summary.spent_by_category:
            print("   By category:")
            for cat, val in summary.spent_by_category.items():
                print(f"     {cat}: ${val:.2f}")


def _cmd_migrate(args: argparse.Namespace) -> None:
    path = Path(args.config)
    with open(path) as f:
        data = json.load(f)

    changed = False

    # Add brand_identity with defaults if missing
    if "brand_identity" not in data:
        data["brand_identity"] = {
            "brand_voice": f"Default voice for {data.get('channel_name', 'channel')}",
            "audience_plan": {
                "primary_segments": [
                    {
                        "name": data.get("target_audience", "General audience"),
                        "demographics": "Not specified",
                        "psychographics": "Not specified",
                    }
                ],
                "content_goals": ["entertain", "educate"],
                "engagement_strategy": "Encourage comments and shares",
            },
            "hook_strategy": {
                "primary_hooks": [data.get("narrative", {}).get("hook_formula", "Question opener")],
            },
        }
        changed = True
        print("✅ Added brand_identity with defaults")

    # Add budget with defaults if missing
    if "budget" not in data:
        data["budget"] = {
            "monthly_limit_usd": 100.0,
            "per_video_limit_usd": 5.0,
            "cost_allocation": {"api_calls": 0.6, "asset_gen": 0.3, "storage": 0.1},
        }
        changed = True
        print("✅ Added budget with defaults ($100/month, $5/video)")

    if changed:
        output = args.output or args.config
        with open(output, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"📝 Written to {output}")
    else:
        print("✅ Config already has brand_identity and budget — no migration needed")


def _cmd_init(args: argparse.Namespace) -> None:
    template = {
        "channel_name": args.name,
        "channel_niche": args.niche,
        "target_platform": "youtube_shorts",
        "target_audience": "Describe your target audience here",
        "language": "en",
        "video_duration_s": 60,
        "aspect_ratio": "9:16",
        "narrative": {
            "tone": "Describe your narrative tone",
            "pacing_wps": 3.5,
            "max_words_per_60s": 55,
            "hook_formula": "Describe your hook style",
            "structure": ["hook_0_8s", "context_8_25s", "climax_25_50s", "payoff_50_60s"],
        },
        "visual": {
            "color_palette": ["#000000"],
            "shot_ratio": {"wide_establishing": 0.6, "medium": 0.25, "close_detail": 0.15},
            "forbidden_visuals": [],
        },
        "motion": {
            "default_style": "slow_cinematic",
            "allowed_motions": ["slow_pan_left", "slow_pan_right", "slow_zoom_in"],
            "forbidden_motions": ["shake"],
            "min_scene_duration_s": 5,
            "max_scene_duration_s": 12,
        },
        "asset_sources_priority": ["pexels_search"],
        "confidence_thresholds": {"auto_proceed": 0.85, "flag_review": 0.60},
        "brand_identity": {
            "brand_voice": f"Describe {args.name}'s personality and tone",
            "audience_plan": {
                "primary_segments": [
                    {
                        "name": "Primary segment",
                        "demographics": "Age, gender, location",
                        "psychographics": "Interests, values, pain points",
                    }
                ],
                "content_goals": ["educate", "entertain"],
                "engagement_strategy": "How to drive comments, shares, follows",
            },
            "hook_strategy": {
                "primary_hooks": ["Describe your hook formulas"],
                "forbidden_hooks": [],
                "hook_test_criteria": "How to evaluate hook effectiveness",
            },
            "content_plan": {
                "themes": ["Theme 1", "Theme 2"],
                "posting_frequency": "daily",
            },
            "unique_selling_points": ["What makes this channel unique"],
            "competitor_differentiation": "How this channel differs from competitors",
        },
        "budget": {
            "monthly_limit_usd": 100.0,
            "per_video_limit_usd": 5.0,
            "cost_allocation": {"api_calls": 0.6, "asset_gen": 0.3, "storage": 0.1},
            "alert_threshold_pct": 0.8,
            "hard_stop_threshold_pct": 1.0,
            "notification_channels": ["telegram"],
        },
    }

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w") as f:
        json.dump(template, f, indent=2, ensure_ascii=False)
    print(f"✅ Created channel config template at {output}")
    print(f"📝 Edit the file to customize for '{args.name}'")


if __name__ == "__main__":
    main()


def _cmd_audit(args: argparse.Namespace) -> None:
    config = load_channel_config(args.config)

    with open(args.input) as f:
        input_data = json.load(f)

    from .agents.policy_auditor import PolicyAuditor, check_freshness
    from .policies import get_policy

    auditor = PolicyAuditor(config)
    result = auditor.run(input_data)

    if args.as_json:
        print(json.dumps(result, indent=2, default=str))
    else:
        status = result["status"]
        symbol = "✅" if status == "audit_passed" else "🚫"
        print(f"{symbol} Policy Audit: {status}")
        print(f"   Platform: {result['platform']} ({result['policy_name']})")
        print(f"   Policy updated: {result['policy_last_updated']}")
        print(f"   Checks performed: {len(result['checks_performed'])}")

        if result["violations"]:
            print(f"\n🚫 {len(result['violations'])} violation(s) found:")
            for v in result["violations"]:
                print(f"   [{v.get('rule_id', '?')}] {v.get('category', '?')}: "
                      f"{v.get('description', '')} (matched: {v.get('matched', '?')} in {v.get('source', '?')})")

        if getattr(args, "check_freshness", False):
            policy = get_policy(config.target_platform)
            if not check_freshness(policy):
                print(f"\n⚠️  Policy rules may be stale (last updated: {policy.last_updated})")
                print(f"   Guidelines: {policy.guidelines_url}")
            else:
                print(f"\n✅ Policy rules are fresh (updated: {policy.last_updated})")

    if result["status"] == "policy_violation":
        sys.exit(1)
