from __future__ import annotations

import logging
import re

logger = logging.getLogger(__name__)

_GCS_BUCKET = "ai-director-assets"


class GCSPathError(ValueError):
    """Raised when a GCS path violates brand isolation."""
    pass


def validate_gcs_path(channel_name: str, path: str) -> str:
    """Validate that a GCS path belongs to the given channel.

    Enforces that all paths are under gs://ai-director-assets/{channel_name}/.
    Returns the validated path.
    Raises GCSPathError if the path references a different channel.
    """
    channel = channel_name.lower().replace(" ", "_")
    expected_prefix = f"gs://{_GCS_BUCKET}/{channel}/"

    if not path.startswith(expected_prefix):
        raise GCSPathError(
            f"GCS path '{path}' does not belong to channel '{channel_name}'. "
            f"Expected prefix: '{expected_prefix}'"
        )

    # Additional check: no path traversal
    if ".." in path:
        raise GCSPathError(f"Path traversal detected in '{path}'")

    return path


def build_gcs_path(channel_name: str, *parts: str) -> str:
    """Build a valid GCS path for a channel.

    Example: build_gcs_path("LostEras", "budget", "monthly", "2026-05.json")
    → "gs://ai-director-assets/losteras/budget/monthly/2026-05.json"
    """
    channel = channel_name.lower().replace(" ", "_")
    subpath = "/".join(parts)
    path = f"gs://{_GCS_BUCKET}/{channel}/{subpath}"
    return validate_gcs_path(channel_name, path)


def budget_data_path(channel_name: str, period: str) -> str:
    """Build the GCS path for budget data storage.

    Structure: {channel_name}/budget/monthly/{YYYY-MM}.json
    """
    return build_gcs_path(channel_name, "budget", "monthly", f"{period}.json")


class ScopedLogger(logging.LoggerAdapter):
    """Logger adapter that prefixes all messages with channel_name."""

    def __init__(self, logger_name: str, channel_name: str):
        base_logger = logging.getLogger(logger_name)
        super().__init__(base_logger, {"channel_name": channel_name})

    def process(self, msg: str, kwargs: dict) -> tuple[str, dict]:
        return f"[{self.extra['channel_name']}] {msg}", kwargs
