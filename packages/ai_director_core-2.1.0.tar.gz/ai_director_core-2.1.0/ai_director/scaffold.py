from __future__ import annotations

import json
import sys
import textwrap
from importlib.metadata import version as pkg_version
from pathlib import Path

_VALID_ASPECT_RATIOS = ("9:16", "16:9", "1:1")
_VALID_PLATFORMS = ("youtube_shorts", "youtube", "tiktok", "instagram_reels")


# ── Prompt helpers ─────────────────────────────────────────────


def _ask(prompt: str, *, default: str | None = None, required: bool = True) -> str:
    """Prompt user for text input."""
    suffix = f" [{default}]" if default else ""
    while True:
        answer = input(f"{prompt}{suffix}: ").strip()
        if not answer and default is not None:
            return default
        if answer or not required:
            return answer
        print("  ⚠️  This field is required.")


def _ask_choice(prompt: str, choices: tuple[str, ...], *, default: str) -> str:
    """Prompt user to pick from a list of choices."""
    choices_str = " / ".join(choices)
    while True:
        answer = input(f"{prompt} ({choices_str}) [{default}]: ").strip()
        if not answer:
            return default
        if answer in choices:
            return answer
        print(f"  ⚠️  Invalid choice. Pick one of: {choices_str}")


def _ask_float(prompt: str, *, default: float) -> float:
    """Prompt user for a float value."""
    while True:
        answer = input(f"{prompt} [{default}]: ").strip()
        if not answer:
            return default
        try:
            return float(answer)
        except ValueError:
            print("  ⚠️  Please enter a valid number.")


def _ask_int(prompt: str, *, default: int) -> int:
    """Prompt user for an integer value."""
    while True:
        answer = input(f"{prompt} [{default}]: ").strip()
        if not answer:
            return default
        try:
            return int(answer)
        except ValueError:
            print("  ⚠️  Please enter a valid integer.")


# ── Input collection ───────────────────────────────────────────


def _collect_interactive() -> dict:
    """Collect brand info interactively from the user."""
    print("\n🎬 AI Director — New Brand Scaffold\n")
    print("Answer the following questions to generate your channel repo.\n")

    name = _ask("Channel name", required=True)
    niche = _ask("Channel niche (e.g., history, meditation, tech)", required=True)
    platform = _ask_choice("Target platform", _VALID_PLATFORMS, default="youtube_shorts")
    language = _ask("Language code", default="en")
    aspect_ratio = _ask_choice("Aspect ratio", _VALID_ASPECT_RATIOS, default="9:16")
    duration = _ask_int("Video duration (seconds)", default=60)
    voice = _ask("Brand voice / narrative tone", required=True)
    audience = _ask("Target audience description", required=True)
    budget_monthly = _ask_float("Monthly budget limit (USD)", default=100.0)
    budget_per_video = _ask_float("Per-video budget limit (USD)", default=5.0)

    return {
        "name": name,
        "niche": niche,
        "platform": platform,
        "language": language,
        "aspect_ratio": aspect_ratio,
        "duration": duration,
        "voice": voice,
        "audience": audience,
        "budget_monthly": budget_monthly,
        "budget_per_video": budget_per_video,
    }


def _collect_from_args(args) -> dict:
    """Collect brand info from CLI arguments (non-interactive mode)."""
    missing = []
    for field in ("name", "niche", "voice", "audience"):
        if not getattr(args, field, None):
            missing.append(f"--{field}")
    if missing:
        print(f"❌ Non-interactive mode requires: {', '.join(missing)}")
        sys.exit(1)

    return {
        "name": args.name,
        "niche": args.niche,
        "platform": getattr(args, "platform", None) or "youtube_shorts",
        "language": getattr(args, "language", None) or "en",
        "aspect_ratio": getattr(args, "aspect_ratio", None) or "9:16",
        "duration": int(getattr(args, "duration", None) or 60),
        "voice": args.voice,
        "audience": args.audience,
        "budget_monthly": float(getattr(args, "budget_monthly", None) or 100.0),
        "budget_per_video": float(getattr(args, "budget_per_video", None) or 5.0),
    }


# ── File generators ────────────────────────────────────────────


def _generate_channel_config(info: dict) -> dict:
    """Generate a full channel_config.json dict from collected info."""
    return {
        "channel_name": info["name"],
        "channel_niche": info["niche"],
        "target_platform": info["platform"],
        "target_audience": info["audience"],
        "language": info["language"],
        "video_duration_s": info["duration"],
        "aspect_ratio": info["aspect_ratio"],
        "narrative": {
            "tone": info["voice"],
            "pacing_wps": 3.5,
            "max_words_per_60s": 55,
            "hook_formula": "Question opener",
            "structure": ["hook_0_8s", "context_8_25s", "climax_25_50s", "payoff_50_60s"],
        },
        "visual": {
            "color_palette": ["#000000"],
            "shot_ratio": {"wide_establishing": 0.6, "medium": 0.25, "close_detail": 0.15},
            "forbidden_visuals": [],
        },
        "motion": {
            "default_style": "slow_cinematic",
            "allowed_motions": ["slow_pan_left", "slow_pan_right", "slow_zoom_in"],
            "forbidden_motions": ["shake"],
            "min_scene_duration_s": 5,
            "max_scene_duration_s": 12,
        },
        "asset_sources_priority": ["pexels_search"],
        "confidence_thresholds": {"auto_proceed": 0.85, "flag_review": 0.60},
        "brand_identity": {
            "brand_voice": info["voice"],
            "audience_plan": {
                "primary_segments": [
                    {
                        "name": info["audience"],
                        "demographics": "Not specified — customize this",
                        "psychographics": "Not specified — customize this",
                    }
                ],
                "content_goals": ["educate", "entertain"],
                "engagement_strategy": "Encourage comments and shares",
            },
            "hook_strategy": {
                "primary_hooks": ["Question opener", "Bold statement"],
                "forbidden_hooks": [],
                "hook_test_criteria": "Does the hook create curiosity in the first 3 seconds?",
            },
            "content_plan": {
                "themes": [info["niche"]],
                "posting_frequency": "daily",
            },
            "unique_selling_points": [f"Unique perspective on {info['niche']}"],
            "competitor_differentiation": "Customize — describe what makes this channel different",
        },
        "budget": {
            "monthly_limit_usd": info["budget_monthly"],
            "per_video_limit_usd": info["budget_per_video"],
            "cost_allocation": {"api_calls": 0.6, "asset_gen": 0.3, "storage": 0.1},
            "alert_threshold_pct": 0.8,
            "hard_stop_threshold_pct": 1.0,
            "notification_channels": ["telegram"],
        },
    }


def _generate_workflow(channel_name: str) -> str:
    """Generate a GitHub Actions workflow YAML for the channel repo."""
    return textwrap.dedent(f"""\
        name: "{channel_name} Pipeline"

        on:
          schedule:
            - cron: "0 16 * * *"  # 23:00 UTC+7
          workflow_dispatch:
            inputs:
              topic:
                description: "Topic to process"
                required: false

        jobs:
          pick-topic:
            runs-on: ubuntu-latest
            outputs:
              topic: ${{{{ steps.pick.outputs.topic }}}}
              topic_id: ${{{{ steps.pick.outputs.topic_id }}}}
            steps:
              - uses: actions/checkout@v4
              - id: pick
                run: |
                  if [ -n "${{{{ github.event.inputs.topic }}}}" ]; then
                    echo "topic=${{{{ github.event.inputs.topic }}}}" >> "$GITHUB_OUTPUT"
                    echo "topic_id=manual-$(date +%s)" >> "$GITHUB_OUTPUT"
                  else
                    TOPIC=$(python3 -c "import json; q=json.load(open('data/topics_queue.json')); t=next(x for x in q['topics'] if x['status']=='pending'); print(t['title'])")
                    TOPIC_ID=$(python3 -c "import json; q=json.load(open('data/topics_queue.json')); t=next(x for x in q['topics'] if x['status']=='pending'); print(t['id'])")
                    echo "topic=$TOPIC" >> "$GITHUB_OUTPUT"
                    echo "topic_id=$TOPIC_ID" >> "$GITHUB_OUTPUT"
                  fi

          run-pipeline:
            needs: pick-topic
            uses: <org>/ai-director-core/.github/workflows/reusable-pipeline.yml@main
            with:
              topic: ${{{{ needs.pick-topic.outputs.topic }}}}
              topic_id: ${{{{ needs.pick-topic.outputs.topic_id }}}}
              channel_name: "{channel_name}"
            secrets:
              ANTHROPIC_API_KEY: ${{{{ secrets.ANTHROPIC_API_KEY }}}}
              PEXELS_API_KEY: ${{{{ secrets.PEXELS_API_KEY }}}}
              GCP_SA_KEY: ${{{{ secrets.GCP_SA_KEY }}}}
              TELEGRAM_BOT_TOKEN: ${{{{ secrets.TELEGRAM_BOT_TOKEN }}}}
              TELEGRAM_CHAT_ID: ${{{{ secrets.TELEGRAM_CHAT_ID }}}}
    """)


def _get_core_version() -> str:
    """Get current ai-director-core version from package metadata or pyproject.toml."""
    try:
        return pkg_version("ai-director-core")
    except Exception:
        # Fallback: read pyproject.toml in dev mode
        pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
        if pyproject.exists():
            for line in pyproject.read_text().splitlines():
                if line.strip().startswith("version"):
                    return line.split("=")[1].strip().strip('"').strip("'")
        return "2.0.0"


def _generate_requirements() -> str:
    """Generate requirements.txt pinning core version."""
    ver = _get_core_version()
    return f"ai-director-core=={ver}\n"


def _generate_topics_queue() -> dict:
    """Generate an empty topics_queue.json."""
    return {
        "topics": [
            {
                "id": "topic-001",
                "title": "Your first topic — replace this",
                "status": "pending",
            }
        ]
    }


# ── Main orchestrator ──────────────────────────────────────────


def run_scaffold(args) -> None:
    """Run the scaffold wizard: collect input → generate files → write."""
    non_interactive = getattr(args, "non_interactive", False)

    if non_interactive:
        info = _collect_from_args(args)
    else:
        info = _collect_interactive()

    output_dir = Path(getattr(args, "output_dir", None) or ".")

    # Validate aspect ratio
    if info["aspect_ratio"] not in _VALID_ASPECT_RATIOS:
        print(f"❌ Invalid aspect ratio: {info['aspect_ratio']}. Must be one of: {', '.join(_VALID_ASPECT_RATIOS)}")
        sys.exit(1)

    # Generate all files
    config = _generate_channel_config(info)
    workflow = _generate_workflow(info["name"])
    requirements = _generate_requirements()
    topics = _generate_topics_queue()

    # Write files
    files = {
        "data/channel_config.json": json.dumps(config, indent=2, ensure_ascii=False),
        ".github/workflows/pipeline.yml": workflow,
        "requirements.txt": requirements,
        "data/topics_queue.json": json.dumps(topics, indent=2, ensure_ascii=False),
    }

    for rel_path, content in files.items():
        full_path = output_dir / rel_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content)

    print(f"\n✅ Scaffold complete! Files created in: {output_dir.resolve()}\n")
    print("   Created files:")
    for rel_path in files:
        print(f"   📄 {rel_path}")
    print(f"\n📝 Next steps:")
    print(f"   1. Edit data/channel_config.json to customize your brand")
    print(f"   2. Replace <org> in .github/workflows/pipeline.yml with your GitHub org")
    print(f"   3. Add topics to data/topics_queue.json")
    print(f"   4. Set up GitHub secrets: ANTHROPIC_API_KEY, PEXELS_API_KEY, GCP_SA_KEY")
    print(f"   5. Push to GitHub and the pipeline will run on schedule")
