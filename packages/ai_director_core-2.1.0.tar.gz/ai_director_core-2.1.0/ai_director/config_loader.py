from __future__ import annotations

import json
import logging
import re
from pathlib import Path

from .models.config import ChannelConfig

logger = logging.getLogger(__name__)

# Pattern to detect cross-channel references in config values
_CROSS_CHANNEL_PATTERN = re.compile(
    r"gs://ai-director-assets/[a-z0-9_-]+/|/channels?/[a-z0-9_-]+/",
    re.IGNORECASE,
)


def load_channel_config(path: str | Path) -> ChannelConfig:
    """Load and validate a channel config from a JSON file.

    Returns a frozen (immutable) ChannelConfig instance.
    Each call creates a new independent instance — no global state.
    """
    path = Path(path)
    with open(path) as f:
        data = json.load(f)

    config = ChannelConfig(**data)

    _validate_self_contained(config)

    logger.info("Loaded config for channel '%s' from %s", config.channel_name, path)
    return config


def validate_config(config: ChannelConfig) -> list[str]:
    """Run additional validation checks beyond Pydantic schema.

    Returns a list of error messages (empty if valid).
    """
    errors: list[str] = []

    # Check self-contained
    cross_refs = _find_cross_references(config)
    if cross_refs:
        errors.append(
            f"Config references external channel paths: {', '.join(cross_refs)}"
        )

    # Check motion duration consistency
    if config.motion.min_scene_duration_s >= config.motion.max_scene_duration_s:
        errors.append(
            f"min_scene_duration_s ({config.motion.min_scene_duration_s}) "
            f"must be < max_scene_duration_s ({config.motion.max_scene_duration_s})"
        )

    # Check budget if present
    if config.budget:
        if config.budget.per_video_limit_usd > config.budget.monthly_limit_usd:
            errors.append(
                "per_video_limit_usd should not exceed monthly_limit_usd"
            )

    return errors


def _validate_self_contained(config: ChannelConfig) -> None:
    """Ensure config doesn't reference other channels' resources."""
    cross_refs = _find_cross_references(config)
    if cross_refs:
        logger.warning(
            "Config for '%s' contains potential cross-channel references: %s",
            config.channel_name,
            cross_refs,
        )


def _find_cross_references(config: ChannelConfig) -> list[str]:
    """Scan all string values in the config for cross-channel path references."""
    refs: list[str] = []
    config_json = config.model_dump_json()
    channel_name = config.channel_name.lower().replace(" ", "_")

    for match in _CROSS_CHANNEL_PATTERN.finditer(config_json):
        matched_path = match.group(0)
        # Ignore references to the channel's own path
        if channel_name not in matched_path.lower():
            refs.append(matched_path)

    return refs
