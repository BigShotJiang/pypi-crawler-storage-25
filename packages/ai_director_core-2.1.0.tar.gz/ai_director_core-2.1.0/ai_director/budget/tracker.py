from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Protocol

from ..models.budget import BudgetConfig

logger = logging.getLogger(__name__)


class BudgetDecision(str, Enum):
    PROCEED = "proceed"
    FALLBACK = "fallback"
    STOP = "stop"


@dataclass(frozen=True)
class BudgetSummary:
    channel_name: str
    period: str  # e.g. "2026-05"
    monthly_limit_usd: float
    total_spent_usd: float
    remaining_usd: float
    spent_by_category: dict[str, float]
    videos_produced: int


class StorageBackend(Protocol):
    """Abstraction for budget data persistence."""

    def load(self, channel_name: str, period: str) -> dict | None: ...
    def save(self, channel_name: str, period: str, data: dict) -> None: ...


class LocalStorageBackend:
    """Persist budget data to local JSON files. Used as fallback when GCS unavailable."""

    def __init__(self, base_dir: str | Path = ".budget_data"):
        self._base = Path(base_dir)

    def _path(self, channel_name: str, period: str) -> Path:
        return self._base / channel_name / "budget" / "monthly" / f"{period}.json"

    def load(self, channel_name: str, period: str) -> dict | None:
        p = self._path(channel_name, period)
        if p.exists():
            return json.loads(p.read_text())
        return None

    def save(self, channel_name: str, period: str, data: dict) -> None:
        p = self._path(channel_name, period)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data, indent=2))


class GCSStorageBackend:
    """Persist budget data to Google Cloud Storage.

    Falls back to LocalStorageBackend if GCS is unavailable.
    """

    def __init__(self, bucket_name: str = "ai-director-assets", local_fallback_dir: str = ".budget_data"):
        self._bucket_name = bucket_name
        self._local = LocalStorageBackend(local_fallback_dir)
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from google.cloud import storage
                self._client = storage.Client()
            except Exception:
                logger.warning("GCS client unavailable, using local fallback")
                return None
        return self._client

    def _blob_path(self, channel_name: str, period: str) -> str:
        return f"{channel_name}/budget/monthly/{period}.json"

    def load(self, channel_name: str, period: str) -> dict | None:
        client = self._get_client()
        if client is None:
            return self._local.load(channel_name, period)
        try:
            bucket = client.bucket(self._bucket_name)
            blob = bucket.blob(self._blob_path(channel_name, period))
            if blob.exists():
                return json.loads(blob.download_as_text())
            return None
        except Exception:
            logger.warning("GCS load failed, falling back to local")
            return self._local.load(channel_name, period)

    def save(self, channel_name: str, period: str, data: dict) -> None:
        # Always save locally as backup
        self._local.save(channel_name, period, data)
        client = self._get_client()
        if client is None:
            return
        try:
            bucket = client.bucket(self._bucket_name)
            blob = bucket.blob(self._blob_path(channel_name, period))
            blob.upload_from_string(json.dumps(data, indent=2), content_type="application/json")
        except Exception:
            logger.warning("GCS save failed, data saved locally only")


class BudgetTracker:
    """Track and enforce budget constraints for a single channel pipeline run."""

    def __init__(
        self,
        channel_name: str,
        budget_config: BudgetConfig | None,
        storage: StorageBackend | None = None,
        period: str | None = None,
    ):
        self._channel = channel_name
        self._config = budget_config
        self._storage = storage or LocalStorageBackend()
        self._period = period or datetime.now(timezone.utc).strftime("%Y-%m")

        # Load existing data for this period
        self._data = self._load_or_init()
        # Track costs accumulated in this run (not yet persisted)
        self._run_costs: dict[str, float] = {}

    def _load_or_init(self) -> dict:
        existing = self._storage.load(self._channel, self._period)
        if existing:
            return existing
        return {
            "channel_name": self._channel,
            "period": self._period,
            "total_spent_usd": 0.0,
            "spent_by_category": {},
            "videos_produced": 0,
            "entries": [],
        }

    @property
    def is_unlimited(self) -> bool:
        return self._config is None

    def check_budget(self, cost_type: str, estimated_cost: float) -> BudgetDecision:
        """Check if a cost is within budget. Returns decision: proceed/fallback/stop."""
        if self.is_unlimited:
            return BudgetDecision.PROCEED

        config = self._config
        total = self._data["total_spent_usd"] + sum(self._run_costs.values())
        projected = total + estimated_cost

        # Check hard stop first (most severe)
        hard_limit = config.monthly_limit_usd * config.hard_stop_threshold_pct
        if projected >= hard_limit:
            logger.error(
                "[%s] Monthly budget hard stop: $%.2f >= $%.2f",
                self._channel, projected, hard_limit,
            )
            return BudgetDecision.STOP

        # Check alert threshold
        alert_limit = config.monthly_limit_usd * config.alert_threshold_pct
        if projected >= alert_limit:
            logger.warning(
                "[%s] Monthly budget alert: $%.2f >= $%.2f (%.0f%%)",
                self._channel, projected, alert_limit, config.alert_threshold_pct * 100,
            )
            # Still proceed, but alert has been raised

        # Check per-video limit
        run_total = sum(self._run_costs.values()) + estimated_cost
        if run_total > config.per_video_limit_usd:
            logger.warning(
                "[%s] Per-video budget would be exceeded: $%.2f > $%.2f",
                self._channel, run_total, config.per_video_limit_usd,
            )
            return BudgetDecision.FALLBACK

        # Check category-level limit
        if cost_type in config.cost_allocation:
            cat_limit = config.monthly_limit_usd * config.cost_allocation[cost_type]
            cat_spent = self._data.get("spent_by_category", {}).get(cost_type, 0.0)
            cat_run = self._run_costs.get(cost_type, 0.0)
            if cat_spent + cat_run + estimated_cost > cat_limit:
                logger.warning(
                    "[%s] Category '%s' budget near limit: $%.2f > $%.2f",
                    self._channel, cost_type, cat_spent + cat_run + estimated_cost, cat_limit,
                )
                return BudgetDecision.FALLBACK

        return BudgetDecision.PROCEED

    def record_cost(self, cost_type: str, actual_cost: float) -> None:
        """Record a cost that has been incurred."""
        self._run_costs[cost_type] = self._run_costs.get(cost_type, 0.0) + actual_cost
        logger.info(
            "[%s] Cost recorded: %s=$%.4f (run total=$%.4f)",
            self._channel, cost_type, actual_cost, sum(self._run_costs.values()),
        )

    def get_remaining(self) -> BudgetSummary:
        """Get current budget summary."""
        if self.is_unlimited:
            return BudgetSummary(
                channel_name=self._channel,
                period=self._period,
                monthly_limit_usd=float("inf"),
                total_spent_usd=self._data["total_spent_usd"],
                remaining_usd=float("inf"),
                spent_by_category=self._data.get("spent_by_category", {}),
                videos_produced=self._data.get("videos_produced", 0),
            )
        total = self._data["total_spent_usd"] + sum(self._run_costs.values())
        return BudgetSummary(
            channel_name=self._channel,
            period=self._period,
            monthly_limit_usd=self._config.monthly_limit_usd,
            total_spent_usd=total,
            remaining_usd=max(0, self._config.monthly_limit_usd - total),
            spent_by_category=self._merge_categories(),
            videos_produced=self._data.get("videos_produced", 0),
        )

    def persist(self, video_completed: bool = False) -> None:
        """Persist accumulated costs from this run to storage."""
        # Merge run costs into data
        for cat, cost in self._run_costs.items():
            self._data["total_spent_usd"] += cost
            cats = self._data.setdefault("spent_by_category", {})
            cats[cat] = cats.get(cat, 0.0) + cost

        if video_completed:
            self._data["videos_produced"] = self._data.get("videos_produced", 0) + 1

        # Record this run as an entry
        self._data.setdefault("entries", []).append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "costs": dict(self._run_costs),
            "video_completed": video_completed,
        })

        self._storage.save(self._channel, self._period, self._data)
        self._run_costs.clear()
        logger.info("[%s] Budget data persisted for period %s", self._channel, self._period)

    def _merge_categories(self) -> dict[str, float]:
        merged = dict(self._data.get("spent_by_category", {}))
        for cat, cost in self._run_costs.items():
            merged[cat] = merged.get(cat, 0.0) + cost
        return merged
