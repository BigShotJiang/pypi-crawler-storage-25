from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from ..models.config import ChannelConfig

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """Base class for all AI Director agents.

    Agents receive the full ChannelConfig and use it to make
    brand-aware creative decisions. Config is immutable — agents
    cannot modify it.
    """

    def __init__(self, config: ChannelConfig):
        self._config = config

    @property
    def config(self) -> ChannelConfig:
        return self._config

    @property
    def channel_name(self) -> str:
        return self._config.channel_name

    @property
    def aspect_ratio(self) -> str:
        return self._config.aspect_ratio

    @property
    def is_landscape(self) -> bool:
        return self._config.aspect_ratio == "16:9"

    @property
    def is_portrait(self) -> bool:
        return self._config.aspect_ratio == "9:16"

    @abstractmethod
    def run(self, input_data: dict[str, Any]) -> dict[str, Any]:
        """Execute the agent's task. Returns output data."""
        ...

    def _log(self, msg: str, *args: Any) -> None:
        logger.info("[%s/%s] " + msg, self.channel_name, self.__class__.__name__, *args)
