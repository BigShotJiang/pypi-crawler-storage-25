"""PolicyAuditor agent — zero-tolerance platform compliance gate.

Runs between MotionDirector and QAValidator in the pipeline.
Two-tier audit:
  Tier 1: Rule-based keyword/pattern matching (always runs)
  Tier 2: AI semantic check (stub — runs if Tier 1 passes)
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from .base import BaseAgent
from ..policies import get_policy, check_text_against_rules, PlatformPolicy


# How many days before a policy is considered stale
_FRESHNESS_THRESHOLD_DAYS = 90


class PolicyAuditor(BaseAgent):
    """Agent: Audit video package against platform community guidelines.

    This agent is a HARD GATE — if any policy violation is found,
    the pipeline STOPS. No bypass. No --force. No --skip-audit.
    """

    def run(self, input_data: dict[str, Any]) -> dict[str, Any]:
        self._log("Running policy audit for %s", self.config.target_platform)

        policy = get_policy(self.config.target_platform)

        # Build text corpus from pipeline data
        texts = _extract_auditable_text(input_data)

        # Tier 1: Rule-based keyword/pattern matching
        all_violations: list[dict[str, str]] = []
        checks_performed: list[dict[str, Any]] = []

        for source_label, text in texts:
            violations = check_text_against_rules(text, policy.rules)
            checks_performed.append({
                "tier": 1,
                "source": source_label,
                "text_length": len(text),
                "rules_checked": len(policy.rules),
                "violations_found": len(violations),
            })
            for v in violations:
                v["source"] = source_label
            all_violations.extend(violations)

        # Tier 2: AI semantic check (only if Tier 1 passes)
        tier2_result = None
        if not all_violations:
            tier2_result = _tier2_semantic_check(texts, policy)
            checks_performed.append({
                "tier": 2,
                "type": "semantic_stub",
                "result": tier2_result["status"],
            })
            if tier2_result["status"] == "violation":
                all_violations.extend(tier2_result.get("violations", []))

        # Determine final status
        if all_violations:
            status = "policy_violation"
        else:
            status = "audit_passed"

        result: dict[str, Any] = {
            "status": status,
            "platform": self.config.target_platform,
            "policy_name": policy.name,
            "policy_last_updated": policy.last_updated.isoformat(),
            "violations": all_violations,
            "checks_performed": checks_performed,
            "is_policy_fresh": check_freshness(policy),
        }

        if status == "policy_violation":
            self._log(
                "POLICY VIOLATION: %d violation(s) found — video will NOT be produced",
                len(all_violations),
            )
        else:
            self._log("Policy audit passed — %d checks performed", len(checks_performed))

        # Pass through input data so downstream agents have access
        result.update({
            k: v for k, v in input_data.items()
            if k not in result
        })

        return result


def check_freshness(policy: PlatformPolicy) -> bool:
    """Check if a policy's rules are still considered fresh."""
    threshold = date.today() - timedelta(days=_FRESHNESS_THRESHOLD_DAYS)
    return policy.last_updated >= threshold


def _extract_auditable_text(data: dict[str, Any]) -> list[tuple[str, str]]:
    """Extract text content from pipeline data for auditing.

    Returns list of (source_label, text) tuples.
    """
    texts: list[tuple[str, str]] = []

    # Script text
    if "script" in data:
        script = data["script"]
        if isinstance(script, str):
            texts.append(("script", script))
        elif isinstance(script, dict):
            for key in ("text", "content", "narration", "dialogue"):
                if key in script:
                    texts.append((f"script.{key}", str(script[key])))

    # Shot descriptions
    if "shots" in data:
        shots = data["shots"]
        if isinstance(shots, list):
            for i, shot in enumerate(shots):
                if isinstance(shot, dict):
                    desc = shot.get("description", shot.get("visual", ""))
                    if desc:
                        texts.append((f"shots[{i}]", str(desc)))
                elif isinstance(shot, str):
                    texts.append((f"shots[{i}]", shot))

    # Asset metadata
    if "assets" in data:
        assets = data["assets"]
        if isinstance(assets, list):
            for i, asset in enumerate(assets):
                if isinstance(asset, dict):
                    for key in ("description", "alt_text", "query", "prompt"):
                        if key in asset:
                            texts.append((f"assets[{i}].{key}", str(asset[key])))

    # Topic
    if "topic" in data:
        texts.append(("topic", str(data["topic"])))

    return texts


def _tier2_semantic_check(
    texts: list[tuple[str, str]],
    policy: PlatformPolicy,
) -> dict[str, Any]:
    """Tier 2: AI-powered semantic policy check (stub).

    This is a placeholder for future Claude/LLM integration.
    Currently always returns "passed" status.
    """
    # TODO: Integrate with Claude API for semantic content analysis
    # The LLM would evaluate whether the combined content violates
    # the spirit of the policy rules (forbidden_themes) even if
    # no exact keyword matches were found.
    return {
        "status": "passed",
        "violations": [],
        "note": "AI semantic check not yet implemented — stub returns passed",
    }
