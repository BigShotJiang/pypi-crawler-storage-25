from __future__ import annotations

from typing import Any

from .base import BaseAgent


class ScriptWriter(BaseAgent):
    """Agent 1: Generate video script based on topic and channel config.

    Uses brand_identity.brand_voice, hook_strategy, and audience_plan
    to craft scripts that match the brand's personality.
    """

    def run(self, input_data: dict[str, Any]) -> dict[str, Any]:
        topic = input_data["topic"]
        topic_id = input_data["topic_id"]
        self._log("Generating script for topic '%s'", topic)

        # Build brand-aware prompt context
        prompt_context = self._build_prompt_context(topic)

        # Placeholder for Claude API call — will be implemented with actual client
        script = {
            "topic_id": topic_id,
            "topic": topic,
            "prompt_context": prompt_context,
            "script": None,  # To be filled by Claude
            "metadata": {
                "channel_name": self.channel_name,
                "aspect_ratio": self.aspect_ratio,
                "language": self.config.language,
            },
        }

        return script

    def _build_prompt_context(self, topic: str) -> dict[str, Any]:
        """Build the full context for script generation, incorporating brand identity."""
        ctx: dict[str, Any] = {
            "tone": self.config.narrative.tone,
            "pacing_wps": self.config.narrative.pacing_wps,
            "max_words_per_60s": self.config.narrative.max_words_per_60s,
            "hook_formula": self.config.narrative.hook_formula,
            "structure": self.config.narrative.structure,
            "target_audience": self.config.target_audience,
            "channel_niche": self.config.channel_niche,
            "video_duration_s": self.config.video_duration_s,
        }

        # Overlay brand identity if available
        bi = self.config.brand_identity
        if bi:
            ctx["brand_voice"] = bi.brand_voice
            ctx["primary_hooks"] = bi.hook_strategy.primary_hooks
            ctx["forbidden_hooks"] = bi.hook_strategy.forbidden_hooks
            ctx["hook_test_criteria"] = bi.hook_strategy.hook_test_criteria
            ctx["audience_segments"] = [
                {
                    "name": seg.name,
                    "demographics": seg.demographics,
                    "psychographics": seg.psychographics,
                }
                for seg in bi.audience_plan.primary_segments
            ]
            ctx["content_goals"] = bi.audience_plan.content_goals
            ctx["engagement_strategy"] = bi.audience_plan.engagement_strategy
            ctx["unique_selling_points"] = bi.unique_selling_points
            ctx["competitor_differentiation"] = bi.competitor_differentiation

        return ctx
