from __future__ import annotations

from typing import Any

from .base import BaseAgent


# Search query modifiers by aspect ratio
_ASPECT_SEARCH_PARAMS = {
    "9:16": {"orientation": "portrait", "min_height": 1920, "min_width": 1080},
    "16:9": {"orientation": "landscape", "min_height": 1080, "min_width": 1920},
    "1:1": {"orientation": "squarish", "min_height": 1080, "min_width": 1080},
}


class AssetResolver(BaseAgent):
    """Agent 3: Resolve visual assets for each shot.

    Searches and generates assets matching the brand's aspect_ratio
    and visual preferences. Uses asset_sources_priority to determine
    where to look first.
    """

    def run(self, input_data: dict[str, Any]) -> dict[str, Any]:
        self._log("Resolving assets for aspect_ratio=%s", self.aspect_ratio)

        search_params = _ASPECT_SEARCH_PARAMS.get(
            self.aspect_ratio, _ASPECT_SEARCH_PARAMS["9:16"]
        )

        resolve_context = {
            "channel_name": self.channel_name,
            "aspect_ratio": self.aspect_ratio,
            "search_params": search_params,
            "asset_sources_priority": list(self.config.asset_sources_priority),
            "color_palette": list(self.config.visual.color_palette),
            "forbidden_visuals": list(self.config.visual.forbidden_visuals),
            "confidence_thresholds": dict(self.config.confidence_thresholds),
            "resolved_assets": None,  # To be filled by asset resolution logic
        }

        # Include brand identity visual preferences if available
        bi = self.config.brand_identity
        if bi:
            resolve_context["unique_selling_points"] = bi.unique_selling_points

        return resolve_context
