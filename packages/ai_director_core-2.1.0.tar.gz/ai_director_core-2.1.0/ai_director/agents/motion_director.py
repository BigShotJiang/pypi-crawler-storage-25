from __future__ import annotations

from typing import Any

from .base import BaseAgent


# Motion parameter adjustments by aspect ratio
_MOTION_ADJUSTMENTS = {
    "9:16": {
        "pan_amplitude_factor": 0.6,  # Less horizontal pan for vertical
        "zoom_center_bias": "upper_third",  # Focus zoom on upper part
    },
    "16:9": {
        "pan_amplitude_factor": 1.0,  # Full horizontal pan
        "zoom_center_bias": "center",
    },
    "1:1": {
        "pan_amplitude_factor": 0.5,
        "zoom_center_bias": "center",
    },
}


class MotionDirector(BaseAgent):
    """Agent 4: Assign motion/animation to each shot.

    Adapts motion parameters based on aspect_ratio — vertical videos
    use different pan amplitudes and zoom centers than landscape.
    """

    def run(self, input_data: dict[str, Any]) -> dict[str, Any]:
        self._log(
            "Assigning motion: style=%s, aspect_ratio=%s",
            self.config.motion.default_style,
            self.aspect_ratio,
        )

        adjustments = _MOTION_ADJUSTMENTS.get(
            self.aspect_ratio, _MOTION_ADJUSTMENTS["9:16"]
        )

        motion_plan = {
            "channel_name": self.channel_name,
            "aspect_ratio": self.aspect_ratio,
            "default_style": self.config.motion.default_style,
            "allowed_motions": list(self.config.motion.allowed_motions),
            "forbidden_motions": list(self.config.motion.forbidden_motions),
            "min_scene_duration_s": self.config.motion.min_scene_duration_s,
            "max_scene_duration_s": self.config.motion.max_scene_duration_s,
            "aspect_adjustments": adjustments,
            "motion_assignments": None,  # To be filled by Claude
        }

        return motion_plan
