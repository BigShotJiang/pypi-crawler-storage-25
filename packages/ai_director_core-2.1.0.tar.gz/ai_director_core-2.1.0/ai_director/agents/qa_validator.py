from __future__ import annotations

from typing import Any

from .base import BaseAgent


class QAValidator(BaseAgent):
    """Agent 5: Validate the final video package against brand requirements.

    Checks that the output respects brand identity constraints:
    hooks, forbidden content, aspect ratio, visual palette, etc.
    """

    def run(self, input_data: dict[str, Any]) -> dict[str, Any]:
        self._log("Running QA validation")

        checks = self._build_validation_checks()

        result = {
            "channel_name": self.channel_name,
            "validation_checks": checks,
            "status": None,  # "ready" | "qa_failed" | "blocked"
            "issues": [],
        }

        return result

    def _build_validation_checks(self) -> list[dict[str, Any]]:
        """Build the list of validation checks based on config."""
        checks: list[dict[str, Any]] = []

        # Aspect ratio check
        checks.append({
            "id": "aspect_ratio",
            "description": f"Output must be {self.aspect_ratio}",
            "expected": self.aspect_ratio,
        })

        # Forbidden visuals check
        if self.config.visual.forbidden_visuals:
            checks.append({
                "id": "forbidden_visuals",
                "description": "Output must not contain forbidden visuals",
                "forbidden": list(self.config.visual.forbidden_visuals),
            })

        # Forbidden motions check
        if self.config.motion.forbidden_motions:
            checks.append({
                "id": "forbidden_motions",
                "description": "Output must not use forbidden motions",
                "forbidden": list(self.config.motion.forbidden_motions),
            })

        # Duration check
        checks.append({
            "id": "scene_duration",
            "description": "Each scene must be within duration bounds",
            "min_s": self.config.motion.min_scene_duration_s,
            "max_s": self.config.motion.max_scene_duration_s,
        })

        # Brand identity checks
        bi = self.config.brand_identity
        if bi:
            # Forbidden hooks
            if bi.hook_strategy.forbidden_hooks:
                checks.append({
                    "id": "forbidden_hooks",
                    "description": "Script must not use forbidden hook patterns",
                    "forbidden": list(bi.hook_strategy.forbidden_hooks),
                })

            # Brand voice consistency
            checks.append({
                "id": "brand_voice",
                "description": f"Script tone must match: {bi.brand_voice[:100]}",
                "expected_voice": bi.brand_voice,
            })

        return checks
