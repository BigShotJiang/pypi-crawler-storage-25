from __future__ import annotations

from typing import Any

from .base import BaseAgent


# Aspect-ratio-specific composition guidelines
_COMPOSITION_RULES = {
    "9:16": {
        "framing": "vertical composition, subject centered or rule-of-thirds vertically",
        "text_safe_area": "top 15% and bottom 25% reserved for text overlays",
        "motion_bias": "vertical pans preferred over horizontal",
    },
    "16:9": {
        "framing": "landscape composition, wide establishing shots, horizontal rule-of-thirds",
        "text_safe_area": "bottom 20% for lower thirds",
        "motion_bias": "horizontal pans and tracking shots preferred",
    },
    "1:1": {
        "framing": "square composition, centered subject, symmetric framing",
        "text_safe_area": "bottom 20% for text",
        "motion_bias": "slow zoom preferred, minimal panning",
    },
}


class ShotListDirector(BaseAgent):
    """Agent 2: Generate shot list based on script and channel visual config.

    Respects aspect_ratio for shot compositions — landscape vs portrait
    produce fundamentally different shot lists.
    """

    def run(self, input_data: dict[str, Any]) -> dict[str, Any]:
        self._log("Generating shot list for aspect_ratio=%s", self.aspect_ratio)

        composition = _COMPOSITION_RULES.get(self.aspect_ratio, _COMPOSITION_RULES["9:16"])

        shot_list = {
            "channel_name": self.channel_name,
            "aspect_ratio": self.aspect_ratio,
            "composition_rules": composition,
            "shot_ratio": dict(self.config.visual.shot_ratio),
            "color_palette": list(self.config.visual.color_palette),
            "forbidden_visuals": list(self.config.visual.forbidden_visuals),
            "historical_accuracy_window_years": self.config.visual.historical_accuracy_window_years,
            "reference_aesthetic": self.config.visual.reference_aesthetic,
            "shots": None,  # To be filled by Claude
        }

        return shot_list
