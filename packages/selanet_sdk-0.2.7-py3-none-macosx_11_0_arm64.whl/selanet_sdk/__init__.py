"""
Selanet Python SDK

High-level client for interacting with the Selanet agent system.

Example:
    >>> import asyncio
    >>> from selanet_sdk import SelaClient
    >>>
    >>> async def main():
    ...     client = await SelaClient.with_api_key("sk_live_xxx")
    ...     result = await client.browse("https://example.com")
    ...     await client.shutdown()
    >>>
    >>> asyncio.run(main())
"""

from .sela import (
    # Top-level functions
    version,
    valid_event_types,
    init_runtime,

    # Main client
    SelaClient,

    # Configuration types
    SelaClientConfig,
    RuntimeConfig,
    DiscoveryOptions,
    ConnectionOptions,
    ScreenshotOptions,
    BrowseOptions,
    XParams,
    XiaohongshuParams,
    RednoteParams,
    YouTubeParams,
    LinkedInParams,
    ParallelBrowseItem,
    ParallelBrowseResult,

    # Discovery types
    DiscoveredAgent,
    AgentStatusResponse,

    # Response types
    PageMetadata,
    AvailableAction,
    SemanticContent,
    SemanticPage,
    ActionResult,
    SemanticResponse,
    SessionInfo,
    BrowserResponse,

    # Reputation types
    ReputationRecord,
    TaskOutcome,

    # Event types
    ClientEvent,

    # Error types
    SelaError,
)

__version__ = version()
__all__ = [
    # Functions
    "version",
    "valid_event_types",
    "init_runtime",

    # Client
    "SelaClient",

    # Config
    "SelaClientConfig",
    "RuntimeConfig",
    "DiscoveryOptions",
    "ConnectionOptions",
    "ScreenshotOptions",
    "BrowseOptions",
    "XParams",
    "XiaohongshuParams",
    "RednoteParams",
    "YouTubeParams",
    "LinkedInParams",
    "ParallelBrowseItem",
    "ParallelBrowseResult",

    # Discovery
    "DiscoveredAgent",
    "AgentStatusResponse",

    # Response
    "PageMetadata",
    "AvailableAction",
    "SemanticContent",
    "SemanticPage",
    "ActionResult",
    "SemanticResponse",
    "SessionInfo",
    "BrowserResponse",

    # Reputation
    "ReputationRecord",
    "TaskOutcome",

    # Events
    "ClientEvent",

    # Errors
    "SelaError",
]
