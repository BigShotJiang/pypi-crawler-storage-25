# Copyright © 2026, Alexander Suvorov
"""Terminal-based smart password manager with deterministic password generation.
Generate, manage, and retrieve passwords without storing them - all from your command line."""

__version__ = '2.2.2'
__author__ = 'Alexander Suvorov'
