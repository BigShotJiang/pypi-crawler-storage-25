from __future__ import annotations

from typing import Any, Literal, Mapping
from urllib.parse import quote

from ..exceptions import DriftstoneError
from ..models.repository import (
    DriftstoneBranch,
    DriftstoneCopy,
    DriftstoneCopyStatus,
    DriftstoneDeleteResult,
    DriftstoneDownload,
    DriftstoneDownloadFile,
    DriftstoneRepository,
    DriftstoneUpload,
    DriftstoneUploadComplete,
    DriftstoneUploadFile,
)
from ._base import ResourceBase


class DriftstoneRepositories(ResourceBase):
    @staticmethod
    def _require_non_empty_string(value: str, name: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise DriftstoneError(f"{name} must be a non-empty string")
        return value.strip()

    @staticmethod
    def _optional_non_empty_string(value: str | None, name: str) -> str | None:
        if value is None:
            return None
        return DriftstoneRepositories._require_non_empty_string(value, name)

    @staticmethod
    def _encode_repo(repo: str) -> str:
        normalized = DriftstoneRepositories._require_non_empty_string(repo, "repo").strip("/")
        if not normalized:
            raise DriftstoneError("repo must be a non-empty string")
        return quote(normalized, safe="")

    @staticmethod
    def _encode_route_segment(value: str, name: str) -> str:
        normalized = DriftstoneRepositories._require_non_empty_string(value, name)
        if "/" in normalized or "\\" in normalized:
            raise DriftstoneError(f"{name} cannot contain / or \\")
        return quote(normalized, safe="")

    def create(
        self,
        name: str,
    ) -> DriftstoneRepository:
        normalized_name = self._require_non_empty_string(name, "name")
        response = self._client._request("POST", "/repos", {"name": normalized_name})
        return DriftstoneRepository._from_api(response["data"])

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[DriftstoneRepository]:
        response = self._client._request(
            "GET",
            "/repos",
            self._pagination_payload(page=page, page_size=page_size),
        )
        data = response.get("data")
        if not isinstance(data, list):
            raise DriftstoneError("Expected repository list response data to be a list")
        return [DriftstoneRepository._from_api(item) for item in data]

    def get(self, repo: str) -> DriftstoneRepository:
        response = self._client._request("GET", f"/repos/{self._encode_repo(repo)}")
        return DriftstoneRepository._from_api(response["data"])

    retrieve = get

    def delete(self, repo: str) -> DriftstoneDeleteResult:
        response = self._client._request("DELETE", f"/repos/{self._encode_repo(repo)}")
        return DriftstoneDeleteResult._from_api(response["data"])

    def list_branches(
        self,
        repo: str,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[DriftstoneBranch]:
        response = self._client._request(
            "GET",
            f"/repos/{self._encode_repo(repo)}/branches",
            self._pagination_payload(page=page, page_size=page_size),
        )
        data = response.get("data")
        if not isinstance(data, list):
            raise DriftstoneError("Expected branch list response data to be a list")
        return [DriftstoneBranch._from_api(item) for item in data]

    def get_branch(self, repo: str, branch: str) -> DriftstoneBranch:
        response = self._client._request(
            "GET",
            f"/repos/{self._encode_repo(repo)}/branches/{self._encode_route_segment(branch, 'branch')}",
        )
        return DriftstoneBranch._from_api(response["data"])

    def create_branch(
        self,
        repo: str,
        name: str,
        *,
        storage_dir: str,
        message: str | None = None,
        transforms: dict[str, Any] | None = None,
        archive: bool = True,
    ) -> DriftstoneBranch:
        normalized_name = self._require_non_empty_string(name, "name")
        if "/" in normalized_name or "\\" in normalized_name:
            raise DriftstoneError("name cannot contain / or \\")
        normalized_storage_dir = self._require_non_empty_string(storage_dir, "storage_dir")
        if "/" in normalized_storage_dir or "\\" in normalized_storage_dir:
            raise DriftstoneError("storage_dir cannot contain / or \\")
        normalized_message = self._optional_non_empty_string(message, "message")

        if transforms is not None and not isinstance(transforms, dict):
            raise DriftstoneError("transforms must be a dictionary")

        payload: dict[str, Any] = {
            "name": normalized_name,
            "storageDir": normalized_storage_dir,
        }
        if normalized_message is not None:
            payload["message"] = normalized_message
        if transforms is not None:
            payload["transforms"] = transforms
        payload["archive"] = bool(archive)

        response = self._client._request(
            "POST",
            f"/repos/{self._encode_repo(repo)}/branches",
            payload,
        )
        return DriftstoneBranch._from_api(response["data"])

    def delete_branch(self, repo: str, branch: str) -> DriftstoneDeleteResult:
        response = self._client._request(
            "DELETE",
            f"/repos/{self._encode_repo(repo)}/branches/{self._encode_route_segment(branch, 'branch')}",
        )
        return DriftstoneDeleteResult._from_api(response["data"])

    def create_upload(
        self,
        repo: str,
        *,
        files: list[DriftstoneUploadFile | Mapping[str, str]],
        storage_dir: str,
        branch: str = "main",
    ) -> DriftstoneUpload:
        normalized_storage_dir = self._require_non_empty_string(storage_dir, "storage_dir")
        normalized_branch = self._require_branch_name(branch, "branch")
        payload_files = self._normalize_upload_files(files)
        response = self._client._request(
            "POST",
            f"/repos/{self._encode_repo(repo)}/uploads",
            {
                "branch": normalized_branch,
                "storageDir": normalized_storage_dir,
                "files": payload_files,
            },
        )
        return DriftstoneUpload._from_api(response["data"])

    def create_download(
        self,
        repo: str,
        *,
        type: Literal["main", "branch"],
        files: list[DriftstoneDownloadFile | Mapping[str, str]],
    ) -> DriftstoneDownload:
        if type not in ("main", "branch"):
            raise DriftstoneError("type must be either 'main' or 'branch'")

        payload_files = self._normalize_download_files(files)
        response = self._client._request(
            "POST",
            f"/repos/{self._encode_repo(repo)}/downloads",
            {
                "type": type,
                "files": payload_files,
            },
        )
        return DriftstoneDownload._from_api(response["data"])

    def create_directory_download(
        self,
        repo: str,
        *,
        type: Literal["main", "branch"],
        directory: str,
    ) -> DriftstoneDownload:
        if type not in ("main", "branch"):
            raise DriftstoneError("type must be either 'main' or 'branch'")

        normalized_directory = self._require_directory_path(directory, "directory")
        response = self._client._request(
            "POST",
            f"/repos/{self._encode_repo(repo)}/downloads/directory",
            {
                "type": type,
                "directory": normalized_directory,
            },
        )
        return DriftstoneDownload._from_api(response["data"])

    def copy_directory(
        self,
        repo: str,
        *,
        source_dir: str,
        dest_dir: str,
        source_branch: str = "main",
        dest_branch: str = "main",
        transforms: dict[str, Any] | None = None,
        archive: bool = True,
    ) -> DriftstoneCopy:
        normalized_source_dir = self._require_storage_dir(source_dir, "source_dir")
        normalized_dest_dir = self._require_storage_dir(dest_dir, "dest_dir")
        normalized_source_branch = self._require_branch_name(source_branch, "source_branch")
        normalized_dest_branch = self._require_branch_name(dest_branch, "dest_branch")
        if (
            normalized_source_dir == normalized_dest_dir
            and normalized_source_branch == normalized_dest_branch
        ):
            raise DriftstoneError("source and destination must be different")
        if transforms is not None and not isinstance(transforms, dict):
            raise DriftstoneError("transforms must be a dictionary")

        response = self._client._request(
            "POST",
            f"/repos/{self._encode_repo(repo)}/copies",
            {
                "sourceDir": normalized_source_dir,
                "destDir": normalized_dest_dir,
                "sourceBranch": normalized_source_branch,
                "destBranch": normalized_dest_branch,
                "transforms": transforms or {},
                "archive": bool(archive),
            },
        )
        return DriftstoneCopy._from_api(response["data"])

    def get_copy_status(self, repo: str, run_id: str) -> DriftstoneCopyStatus:
        response = self._client._request(
            "GET",
            f"/repos/{self._encode_repo(repo)}/copies/{self._encode_route_segment(run_id, 'run_id')}",
        )
        return DriftstoneCopyStatus._from_api(response["data"])

    def complete_upload(self, repo: str, upload_id: str) -> DriftstoneUploadComplete:
        response = self._client._request(
            "POST",
            f"/repos/{self._encode_repo(repo)}/uploads/{self._encode_route_segment(upload_id, 'upload_id')}/complete",
        )
        return DriftstoneUploadComplete._from_api(response["data"])

    @staticmethod
    def _pagination_payload(*, page: int, page_size: int) -> dict[str, int]:
        if not isinstance(page, int) or page < 1:
            raise DriftstoneError("page must be a positive integer")
        if not isinstance(page_size, int) or page_size < 1:
            raise DriftstoneError("page_size must be a positive integer")
        return {
            "page": page,
            "pageSize": page_size,
        }

    @staticmethod
    def _require_storage_dir(value: str, name: str) -> str:
        normalized = DriftstoneRepositories._require_non_empty_string(value, name)
        if "/" in normalized or "\\" in normalized:
            raise DriftstoneError(f"{name} cannot contain / or \\")
        return normalized

    @staticmethod
    def _require_branch_name(value: str, name: str) -> str:
        normalized = DriftstoneRepositories._require_non_empty_string(value, name)
        if "/" in normalized or "\\" in normalized:
            raise DriftstoneError(f"{name} cannot contain / or \\")
        return normalized

    @staticmethod
    def _require_directory_path(value: str, name: str) -> str:
        normalized = DriftstoneRepositories._require_non_empty_string(value, name).strip("/")
        if not normalized:
            raise DriftstoneError(f"{name} must be a non-empty string")
        if "\\" in normalized:
            raise DriftstoneError(f"{name} cannot contain \\")
        if any(part in ("", ".", "..") for part in normalized.split("/")):
            raise DriftstoneError(f"{name} contains an invalid path segment")
        return normalized

    @staticmethod
    def _normalize_upload_files(
        files: list[DriftstoneUploadFile | Mapping[str, str]],
    ) -> list[dict[str, str]]:
        if not isinstance(files, list) or not files:
            raise DriftstoneError("files must be a non-empty list")

        normalized_files: list[dict[str, str]] = []
        for item in files:
            if isinstance(item, DriftstoneUploadFile):
                normalized = item._to_api()
            elif isinstance(item, Mapping):
                normalized = {
                    "name": item.get("name", ""),
                    "hash": item.get("hash", ""),
                }
            else:
                raise DriftstoneError("files must contain DriftstoneUploadFile objects or mappings")

            normalized["name"] = DriftstoneRepositories._require_non_empty_string(
                normalized["name"],
                "file name",
            )
            normalized["hash"] = DriftstoneRepositories._require_non_empty_string(
                normalized["hash"],
                "file hash",
            )
            normalized_files.append(normalized)

        return normalized_files

    @staticmethod
    def _normalize_download_files(
        files: list[DriftstoneDownloadFile | Mapping[str, str]],
    ) -> list[dict[str, str]]:
        if not isinstance(files, list) or not files:
            raise DriftstoneError("files must be a non-empty list")

        normalized_files: list[dict[str, str]] = []
        for item in files:
            if isinstance(item, DriftstoneDownloadFile):
                normalized = item._to_api()
            elif isinstance(item, Mapping):
                normalized = {
                    "path": item.get("path", ""),
                }
            else:
                raise DriftstoneError("files must contain DriftstoneDownloadFile objects or mappings")

            normalized["path"] = DriftstoneRepositories._require_non_empty_string(
                normalized["path"],
                "file path",
            )
            normalized_files.append(normalized)

        return normalized_files
