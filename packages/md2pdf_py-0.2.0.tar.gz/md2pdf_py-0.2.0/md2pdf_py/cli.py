"""CLI entry point for md2pdf."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from md2pdf_py import __version__
from md2pdf_py.converter import WeasyPrintUnavailableError, convert, convert_text


def _build_parser() -> argparse.ArgumentParser:
    """Create and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog="md2pdf",
        description="Convert Markdown files to beautifully styled PDFs.",
    )
    parser.add_argument("input", help='Path to the Markdown file (use "-" for stdin)')
    parser.add_argument(
        "-o",
        "--output",
        help="Output PDF path (default: <input>.pdf)",
    )
    parser.add_argument(
        "--template",
        default="default",
        help="Built-in template: default, report, invoice, book (default: default)",
    )
    parser.add_argument("--css", help="Path to a custom CSS file (overrides --template)")
    parser.add_argument("--title", help="Document title")
    parser.add_argument("--toc", action="store_true", help="Include table of contents")
    parser.add_argument(
        "--page-size",
        choices=["A4", "Letter"],
        default="A4",
        help="Page size (default: A4)",
    )
    parser.add_argument(
        "--no-page-numbers",
        action="store_true",
        help="Disable page numbers in footer",
    )
    parser.add_argument(
        "--create-dirs",
        action="store_true",
        help="Create output parent directories if they do not exist",
    )
    parser.add_argument(
        "--no-cover",
        action="store_true",
        help="Disable frontmatter cover page",
    )
    parser.add_argument(
        "--emit-html",
        metavar="PATH",
        help="Save intermediate HTML to PATH (in addition to PDF)",
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def main(argv: list[str] | None = None) -> int:
    """CLI entry point.

    Args:
        argv: Optional argument list (defaults to sys.argv[1:]).

    Returns:
        Exit code: 0 on success, 1 on error.
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    input_path = Path(args.input) if args.input != "-" else None
    if input_path is not None and not input_path.exists():
        print(f"Error: Input file not found: {input_path}", file=sys.stderr)
        return 1

    # Resolve output path: -o can be a file or directory
    if args.output:
        output_path = Path(args.output)
        if output_path.is_dir() or (
            str(args.output).endswith("/") or str(args.output).endswith("\\")
        ):
            stem = "output" if input_path is None else input_path.stem
            output_path = output_path / f"{stem}.pdf"
    elif input_path is not None:
        output_path = input_path.with_suffix(".pdf")
    else:
        output_path = Path("output.pdf")
    output_parent = output_path.parent if str(output_path.parent) else Path(".")
    if not output_parent.exists():
        if args.create_dirs:
            output_parent.mkdir(parents=True, exist_ok=True)
        else:
            print(
                f"Error: Output directory does not exist: {output_parent}. "
                f"Use --create-dirs to create it.",
                file=sys.stderr,
            )
            return 1
    css_path = Path(args.css) if args.css else None
    emit_html = Path(args.emit_html) if args.emit_html else None

    # Validate --emit-html parent directory using the same rules as the PDF
    # output path: if missing, either create it with --create-dirs or bail out.
    if emit_html is not None:
        emit_parent = emit_html.parent if str(emit_html.parent) else Path(".")
        if not emit_parent.exists():
            if args.create_dirs:
                emit_parent.mkdir(parents=True, exist_ok=True)
            else:
                print(
                    f"Error: --emit-html directory does not exist: {emit_parent}. "
                    f"Use --create-dirs to create it.",
                    file=sys.stderr,
                )
                return 1

    try:
        if input_path is None:
            # Stdin mode
            md_text = sys.stdin.read()
            if not md_text.strip():
                print("Error: Empty input from stdin", file=sys.stderr)
                return 1
            convert_text(
                md_text,
                output_path,
                css_path=css_path,
                title=args.title,
                include_toc=args.toc,
                page_size=args.page_size,
                page_numbers=not args.no_page_numbers,
                emit_html=emit_html,
                no_cover=args.no_cover,
                template=args.template,
            )
        else:
            convert(
                input_path,
                output_path,
                css_path=css_path,
                title=args.title,
                include_toc=args.toc,
                page_size=args.page_size,
                page_numbers=not args.no_page_numbers,
                emit_html=emit_html,
                no_cover=args.no_cover,
                template=args.template,
            )
    except WeasyPrintUnavailableError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except (FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"✓ PDF created: {output_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
