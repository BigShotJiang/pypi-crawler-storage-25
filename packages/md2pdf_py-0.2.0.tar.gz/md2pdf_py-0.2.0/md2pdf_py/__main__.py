"""Allow running md2pdf_py as a module: python -m md2pdf_py."""

from md2pdf_py.cli import main

if __name__ == "__main__":
    main()
