"""md2pdf-py: Markdown to PDF converter using WeasyPrint."""

__version__ = "0.2.0"
