"""Markdown to PDF converter engine powered by WeasyPrint."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import markdown

logger = logging.getLogger(__name__)


_WEASYPRINT_INSTALL_HINT = (
    "Error: PDF generation requires WeasyPrint system libraries.\n"
    "Install them with:\n"
    "  Ubuntu/Debian: sudo apt-get install -y libpango-1.0-0 libpangocairo-1.0-0 "
    "libgdk-pixbuf-2.0-0 libffi-dev shared-mime-info\n"
    "  macOS:         brew install pango\n"
    "Docs: https://doc.courtbouillon.org/weasyprint/stable/first_steps.html"
)


class WeasyPrintUnavailableError(RuntimeError):
    """Raised when WeasyPrint (or its system libs) cannot be loaded."""


def _import_weasyprint() -> Any:
    """Try importing WeasyPrint; raise a helpful error if system libs missing."""
    try:
        from weasyprint import HTML
    except (ImportError, OSError) as exc:  # pragma: no cover - env-dependent
        raise WeasyPrintUnavailableError(_WEASYPRINT_INSTALL_HINT) from exc
    return HTML


_FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Parse YAML-like frontmatter from markdown text.

    Returns:
        A tuple of (metadata dict, remaining markdown text).
    """
    match = _FRONTMATTER_RE.match(text)
    if not match:
        return {}, text
    meta: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip().lower()] = value.strip()
    return meta, text[match.end() :]


def _build_cover_html(meta: dict[str, str]) -> str:
    """Build a cover page HTML block from frontmatter metadata."""
    parts: list[str] = ['<div class="cover-page">']
    if "title" in meta:
        parts.append(f'<h1 class="cover-title">{meta["title"]}</h1>')
    if "author" in meta:
        parts.append(f'<p class="cover-author">{meta["author"]}</p>')
    if "date" in meta:
        parts.append(f'<p class="cover-date">{meta["date"]}</p>')
    parts.append("</div>")
    return "\n".join(parts)


_DEFAULT_CSS = Path(__file__).parent / "default.css"
_TEMPLATES_DIR = Path(__file__).parent / "templates"

MARKDOWN_EXTENSIONS: list[str] = [
    "tables",
    "fenced_code",
    "toc",
    "sane_lists",
    "nl2br",
    "codehilite",
]


def md_to_html(
    md_text: str,
    *,
    title: str | None = None,
    include_toc: bool = False,
    no_cover: bool = False,
) -> str:
    """Convert Markdown text to a full HTML document string.

    Args:
        md_text: Raw Markdown content.
        title: Optional document title for the HTML <title> tag.
        include_toc: If True, prepend a generated table of contents.
        no_cover: If True, skip frontmatter cover page generation.

    Returns:
        Complete HTML document as a string.
    """
    # Parse frontmatter
    meta, md_text = _parse_frontmatter(md_text)

    md = markdown.Markdown(extensions=MARKDOWN_EXTENSIONS)
    body = md.convert(md_text)

    toc_html = ""
    if include_toc and hasattr(md, "toc"):
        toc_html = f'<div class="toc">{md.toc}</div>\n'

    # Cover page from frontmatter
    cover_html = ""
    if meta and not no_cover:
        cover_html = _build_cover_html(meta) + "\n"

    doc_title = title or meta.get("title", "Document")
    return (
        "<!DOCTYPE html>\n<html>\n<head>\n"
        f'<meta charset="utf-8">\n<title>{doc_title}</title>\n'
        "</head>\n<body>\n"
        f"{cover_html}{toc_html}{body}\n"
        "</body>\n</html>"
    )


def convert(
    input_path: Path,
    output_path: Path,
    *,
    css_path: Path | None = None,
    title: str | None = None,
    include_toc: bool = False,
    page_size: str = "A4",
    page_numbers: bool = True,
    emit_html: Path | None = None,
    no_cover: bool = False,
    template: str = "default",
) -> Path:
    """Convert a Markdown file to PDF.

    Args:
        input_path: Path to the source .md file.
        output_path: Destination PDF path.
        css_path: Optional custom CSS file; defaults to built-in stylesheet.
        title: Optional title for the PDF document.
        include_toc: Prepend a table of contents.
        page_size: Page size — "A4" or "Letter".
        page_numbers: Show page numbers in the footer.

    Returns:
        The output_path after successful write.

    Raises:
        FileNotFoundError: If input_path or css_path does not exist.
        ValueError: If input_path is not a .md file.
    """
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")
    suffix = input_path.suffix.lower()
    if suffix not in (".md", ".markdown"):
        logger.warning(
            "Input file %s does not have a Markdown extension (.md/.markdown); continuing anyway.",
            input_path,
        )

    md_text = input_path.read_text(encoding="utf-8")
    if not md_text.strip():
        raise ValueError(f"Input markdown file is empty: {input_path}")

    return convert_text(
        md_text,
        output_path,
        css_path=css_path,
        title=title,
        include_toc=include_toc,
        page_size=page_size,
        page_numbers=page_numbers,
        emit_html=emit_html,
        no_cover=no_cover,
        template=template,
    )


def convert_text(
    md_text: str,
    output_path: Path,
    *,
    css_path: Path | None = None,
    title: str | None = None,
    include_toc: bool = False,
    page_size: str = "A4",
    page_numbers: bool = True,
    emit_html: Path | None = None,
    no_cover: bool = False,
    template: str = "default",
) -> Path:
    """Convert Markdown text to PDF.

    Args:
        md_text: Raw Markdown content.
        output_path: Destination PDF path.
        css_path: Optional custom CSS file; defaults to built-in stylesheet.
        title: Optional title for the PDF document.
        include_toc: Prepend a table of contents.
        page_size: Page size — "A4" or "Letter".
        page_numbers: Show page numbers in the footer.
        emit_html: If set, save the intermediate HTML to this path.

    Returns:
        The output_path after successful write.
    """
    html_str = md_to_html(md_text, title=title, include_toc=include_toc, no_cover=no_cover)

    # Build CSS: page size + page numbers override + user/default styles
    css_parts: list[str] = []
    css_parts.append(f"@page {{ size: {page_size}; margin: 2cm; ")
    if page_numbers:
        css_parts.append(
            '@bottom-center { content: counter(page) " / " counter(pages); '
            "font-size: 9pt; color: #888; }"
        )
    css_parts.append("}")

    # Resolve CSS: custom > template > default
    if css_path:
        if not css_path.exists():
            raise FileNotFoundError(f"CSS file not found: {css_path}")
        style_file = css_path
    else:
        template_file = _TEMPLATES_DIR / f"{template}.css"
        if template_file.exists():
            style_file = template_file
        else:
            if template != "default":
                logger.warning("Unknown template '%s', falling back to 'default'", template)
            style_file = _DEFAULT_CSS
    css_parts.append(style_file.read_text(encoding="utf-8"))

    full_css = "\n".join(css_parts)
    combined_html = html_str.replace(
        "</head>",
        f"<style>{full_css}</style>\n</head>",
    )

    # Write HTML BEFORE importing WeasyPrint so that `--emit-html` still works
    # when pango/cairo system libs are unavailable. HTML generation has no
    # runtime dependency on WeasyPrint.
    if emit_html:
        emit_html.write_text(combined_html, encoding="utf-8")
        logger.info("HTML written: %s", emit_html)

    # PDF generation requires WeasyPrint (+ pango).
    html_cls = _import_weasyprint()

    logger.info("Generating PDF → %s", output_path)
    html_cls(string=combined_html).write_pdf(str(output_path))
    logger.info("PDF written: %s (%d bytes)", output_path, output_path.stat().st_size)
    return output_path
