# md2pdf-py

[![CI](https://github.com/hakanbaysal/md2pdf-py/actions/workflows/ci.yml/badge.svg)](https://github.com/hakanbaysal/md2pdf-py/actions/workflows/ci.yml)
[![Coverage](https://img.shields.io/badge/coverage-70%25+-brightgreen)](https://github.com/hakanbaysal/md2pdf-py)

Markdown dosyalarını şık, üretime hazır PDF’lere dönüştüren CLI aracı.

> **🆕 v0.2.0 Yenilikler**
> - 🎨 Template sistemi: `--template report|invoice|book|default`
> - 📋 YAML frontmatter desteği (title/author/date → kapak sayfası)
> - 📥 Stdin desteği: `cat file.md | md2pdf -`
> - 📂 `-o` dizin kabul eder, dosya adını otomatik üretir
> - 📝 `--emit-html` ile ara HTML çıktısı
> - 🐳 Docker desteği (multi-arch GHCR image)
> - 🛠️ Ruff + mypy + pre-commit + coverage CI

## Özellikler

- 📄 **WeasyPrint** tabanlı - sunucu dostu, headless browser gerektirmez
- 🎨 Hazır stil: A4, sayfa numarası, Türkçe karakter desteği (DejaVu Sans)
- 📊 Tablo, kod bloğu (syntax highlight), TOC, blockquote desteği
- 🔧 Özelleştirilebilir CSS
- ✅ Python 3.10+

## Sistem Bağımlılıkları

WeasyPrint native kütüphaneler (pango, cairo, gdk-pixbuf) gerektirir. Python paketini
kurmadan önce bunları yükleyin:

**Ubuntu / Debian**

```bash
sudo apt-get update
sudo apt-get install -y \
    libpango-1.0-0 libpangocairo-1.0-0 libgdk-pixbuf-2.0-0 \
    libffi-dev shared-mime-info
```

**macOS (Homebrew)**

```bash
brew install pango
```

Detaylı kurulum notları: <https://doc.courtbouillon.org/weasyprint/stable/first_steps.html>

Sistem kütüphaneleri eksikse `md2pdf` çalıştırıldığında yükleme talimatlarıyla
birlikte anlamlı bir hata mesajı verir (exit kodu: `2`).

## Kurulum

```bash
pip install -e .
```

Ya da doğrudan bir etiketten:

```bash
pip install git+https://github.com/hakanbaysal/md2pdf-py.git@v0.1.0
```

## Kullanım

```bash
# Basit kullanım
md2pdf README.md

# Çıktı dosyası belirterek
md2pdf document.md -o output.pdf

# Çıktı dizini (dosya adı otomatik)
md2pdf document.md -o build/pdfs/

# Stdin'den okuma
cat document.md | md2pdf -
md2pdf - < document.md

# Template ile
md2pdf document.md --template report
md2pdf document.md --template invoice
md2pdf document.md --template book

# HTML çıktısı da al
md2pdf document.md --emit-html debug.html

# Çıktı dizini yoksa oluştur
md2pdf document.md -o build/pdfs/document.pdf --create-dirs

# Özel CSS ile
md2pdf document.md --css mystyle.css

# Başlık ve TOC ile
md2pdf document.md --title "Proje Dökümanı" --toc

# Letter boyutunda, sayfa numarasız
md2pdf document.md --page-size Letter --no-page-numbers

# Detaylı log
md2pdf document.md -v
```

## CLI Seçenekleri

| Seçenek              | Açıklama                                                |
|----------------------|---------------------------------------------------------|
| `input`              | Markdown dosya yolu (`.md` veya `.markdown`, stdin için `-`) |
| `-o, --output`       | PDF çıktı yolu veya dizin (varsayılan: `input.pdf`)       |
| `--template`         | Hazır şablon: `default`, `report`, `invoice`, `book`    |
| `--css`              | Özel CSS dosyası (template'ı override eder)              |
| `--emit-html`        | Ara HTML çıktısını belirtilen yola kaydet               |
| `--title`            | Döküman başlığı                                         |
| `--toc`              | İçindekiler tablosu ekle                                |
| `--no-cover`         | Frontmatter kapak sayfasını devre dışı bırak            |
| `--page-size`        | Sayfa boyutu: `A4` veya `Letter`                        |
| `--no-page-numbers`  | Sayfa numaralarını gizle                                |
| `--create-dirs`      | Çıktı için eksik ana dizinleri otomatik oluştur         |
| `-v, --verbose`      | Detaylı loglama                                         |
| `--version`          | Versiyon bilgisi                                        |

## Exit Kodları

| Kod | Anlam                                                               |
|-----|---------------------------------------------------------------------|
| `0` | Başarılı                                                            |
| `1` | Kullanıcı/girdi hatası (ör. eksik dosya, boş markdown, çıktı dizini)|
| `2` | Ortam/yapılandırma hatası (WeasyPrint sistem kütüphaneleri eksik)   |

## Geliştirme

```bash
pip install -e ".[dev]"
pre-commit install
pytest -v
ruff check .
mypy md2pdf_py/
```

Sistem kütüphaneleri eksikse pango-gated entegrasyon testleri `SKIPPED` olarak
geçilir; bu testler CI'da (GitHub Actions) çalıştırılır.

## Docker

```bash
# Pull
docker pull ghcr.io/hakanbaysal/md2pdf-py:latest

# Kullanım
docker run --rm -v $PWD:/data ghcr.io/hakanbaysal/md2pdf-py input.md -o output.pdf

# Template ile
docker run --rm -v $PWD:/data ghcr.io/hakanbaysal/md2pdf-py input.md --template report
```

## YAML Frontmatter

Markdown dosyanızın başına YAML frontmatter ekleyerek otomatik kapak sayfası oluşturabilirsiniz:

```markdown
---
title: Proje Raporu
author: Hakan Baysal
date: 2026-04-17
---

# İçerik başlığı...
```

Kapak sayfasını kapatmak için: `--no-cover`

## Değişiklik Günlüğü

Tüm değişiklikler için [CHANGELOG.md](CHANGELOG.md) dosyasına bakın.

## Lisans

MIT - Hakan Baysal
