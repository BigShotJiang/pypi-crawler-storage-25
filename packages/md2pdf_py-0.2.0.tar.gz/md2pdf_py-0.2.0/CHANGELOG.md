# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-04-17

### Added

- CHANGELOG.md following Keep a Changelog format
- Ruff and mypy configuration with dedicated CI lint job
- Coverage reporting with 70% minimum threshold
- `-o` flag now accepts a directory and auto-generates `<input_stem>.pdf`
- Stdin support: `md2pdf -` reads markdown from stdin
- `--emit-html PATH` flag to save intermediate HTML output
- YAML frontmatter parsing for title, author, and date with cover page
- `--no-cover` flag to disable frontmatter cover page
- Template system with built-in styles: default, report, invoice, book
- `--template NAME` flag to select built-in templates
- PyPI publish workflow with OIDC support
- Pre-commit hooks for linting and formatting
- Docker support with multi-stage build and GHCR publish workflow
- Multi-arch Docker images (amd64, arm64)

### Changed

- Upgraded dev dependencies to include ruff and mypy
- CI pipeline now runs lint, typecheck, and coverage jobs in parallel
- `--emit-html` now validates its parent directory and honors `--create-dirs`,
  matching the behavior of the PDF output path
- Unknown `--template NAME` values now log a warning before falling back to
  the default stylesheet instead of silently ignoring the request

### Fixed

- `--emit-html` no longer loses its output when PDF generation fails because
  WeasyPrint / pango system libraries are unavailable. The intermediate HTML
  is now written before the WeasyPrint import is attempted.

## [0.1.0] - 2025-04-17

### Added

- Initial release
- Markdown to PDF conversion using WeasyPrint
- CLI with `-o`, `--css`, `--title`, `--toc`, `--page-size`, `--no-page-numbers`, `--create-dirs` flags
- Default A4 stylesheet with Turkish character support (DejaVu Sans)
- Table, code block (syntax highlight), TOC, blockquote support
- CI pipeline with Python 3.10/3.11/3.12 matrix

[Unreleased]: https://github.com/hakanbaysal/md2pdf-py/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/hakanbaysal/md2pdf-py/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/hakanbaysal/md2pdf-py/releases/tag/v0.1.0
