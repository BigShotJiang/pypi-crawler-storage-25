"""Tests for md2pdf_py.cli module."""

from __future__ import annotations

import importlib
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

FIXTURES = Path(__file__).parent / "fixtures"
SAMPLE_MD = str(FIXTURES / "sample.md")

try:
    from weasyprint import HTML as _HTML  # noqa: F401

    WEASYPRINT_AVAILABLE = True
except (ImportError, OSError):
    WEASYPRINT_AVAILABLE = False


class TestCliVersion:
    """Version flag test — no WeasyPrint needed if we patch."""

    def test_version(self, capsys) -> None:  # type: ignore[no-untyped-def]
        if not WEASYPRINT_AVAILABLE:
            mock_wp = MagicMock()
            with patch.dict("sys.modules", {"weasyprint": mock_wp}):
                import md2pdf_py.converter

                importlib.reload(md2pdf_py.converter)
                import md2pdf_py.cli

                importlib.reload(md2pdf_py.cli)
                with pytest.raises(SystemExit, match="0"):
                    md2pdf_py.cli.main(["--version"])
        else:
            from md2pdf_py.cli import main

            with pytest.raises(SystemExit, match="0"):
                main(["--version"])
        captured = capsys.readouterr()
        assert "md2pdf" in captured.out


class TestCliMissingInput:
    """Test missing input file handling."""

    def test_missing_input(self) -> None:
        if not WEASYPRINT_AVAILABLE:
            mock_wp = MagicMock()
            with patch.dict("sys.modules", {"weasyprint": mock_wp}):
                import md2pdf_py.converter

                importlib.reload(md2pdf_py.converter)
                import md2pdf_py.cli

                importlib.reload(md2pdf_py.cli)
                code = md2pdf_py.cli.main(["/nonexistent.md"])
        else:
            from md2pdf_py.cli import main

            code = main(["/nonexistent.md"])
        assert code == 1


@pytest.mark.skipif(not WEASYPRINT_AVAILABLE, reason="WeasyPrint system libs not available")
class TestCliIntegration:
    """Full CLI integration tests requiring WeasyPrint."""

    def test_basic_run(self, tmp_path: Path) -> None:
        from md2pdf_py.cli import main

        out = str(tmp_path / "out.pdf")
        code = main([SAMPLE_MD, "-o", out])
        assert code == 0
        assert Path(out).stat().st_size > 0

    def test_verbose(self, tmp_path: Path) -> None:
        from md2pdf_py.cli import main

        out = str(tmp_path / "v.pdf")
        code = main([SAMPLE_MD, "-o", out, "--verbose"])
        assert code == 0

    def test_create_dirs(self, tmp_path: Path) -> None:
        from md2pdf_py.cli import main

        out = str(tmp_path / "nested" / "sub" / "v.pdf")
        code = main([SAMPLE_MD, "-o", out, "--create-dirs"])
        assert code == 0
        assert Path(out).exists()


class TestCliOutputValidation:
    """Output path validation tests (no WeasyPrint required)."""

    def test_missing_output_dir_without_flag(self, tmp_path: Path, capsys) -> None:  # type: ignore[no-untyped-def]
        from md2pdf_py.cli import main

        md = tmp_path / "in.md"
        md.write_text("# hi")
        missing = tmp_path / "does_not_exist" / "out.pdf"
        code = main([str(md), "-o", str(missing)])
        assert code == 1
        err = capsys.readouterr().err
        assert "Output directory does not exist" in err

    def test_output_dir_auto_filename(self, tmp_path: Path) -> None:
        """When -o points to a directory, auto-generate <stem>.pdf."""
        from md2pdf_py.cli import main

        md = tmp_path / "doc.md"
        md.write_text("# Test")
        outdir = tmp_path / "outdir"
        outdir.mkdir()
        # We expect it to resolve to outdir/doc.pdf but fail at convert
        # (no weasyprint), so just check the path resolution logic.
        # Use a mock to intercept the convert call.
        from unittest.mock import patch as _patch

        with _patch("md2pdf_py.cli.convert") as mock_conv:
            mock_conv.return_value = outdir / "doc.pdf"
            code = main([str(md), "-o", str(outdir)])
            assert code == 0
            call_args = mock_conv.call_args
            assert call_args[0][1] == outdir / "doc.pdf"

    def test_stdin_mode(self, tmp_path: Path) -> None:
        """Test reading from stdin with '-'."""
        import io
        from unittest.mock import patch as _patch

        out = tmp_path / "stdin_out.pdf"
        with (
            _patch("md2pdf_py.cli.convert_text") as mock_conv,
            _patch("sys.stdin", io.StringIO("# Hello from stdin")),
        ):
            mock_conv.return_value = out
            from md2pdf_py.cli import main

            code = main(["-", "-o", str(out)])
            assert code == 0
            mock_conv.assert_called_once()
            assert mock_conv.call_args[0][0] == "# Hello from stdin"

    def test_emit_html_flag(self, tmp_path: Path) -> None:
        """Test --emit-html saves HTML alongside PDF."""
        from unittest.mock import patch as _patch

        md = tmp_path / "test.md"
        md.write_text("# Hello")
        html_out = tmp_path / "out.html"
        pdf_out = tmp_path / "out.pdf"

        with _patch("md2pdf_py.cli.convert") as mock_conv:
            mock_conv.return_value = pdf_out
            from md2pdf_py.cli import main

            code = main([str(md), "-o", str(pdf_out), "--emit-html", str(html_out)])
            assert code == 0
            call_kwargs = mock_conv.call_args[1]
            assert call_kwargs["emit_html"] == html_out

    def test_emit_html_missing_parent_without_create_dirs(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """--emit-html must fail fast if parent dir is missing and --create-dirs is not set."""
        md = tmp_path / "in.md"
        md.write_text("# hi")
        pdf_out = tmp_path / "out.pdf"
        html_out = tmp_path / "missing" / "out.html"

        from md2pdf_py.cli import main

        code = main([str(md), "-o", str(pdf_out), "--emit-html", str(html_out)])
        assert code == 1
        err = capsys.readouterr().err
        assert "--emit-html directory does not exist" in err

    def test_emit_html_missing_parent_with_create_dirs(self, tmp_path: Path) -> None:
        """--emit-html parent dir should be auto-created when --create-dirs is set."""
        from unittest.mock import patch as _patch

        md = tmp_path / "in.md"
        md.write_text("# hi")
        pdf_out = tmp_path / "out.pdf"
        html_out = tmp_path / "made" / "out.html"

        with _patch("md2pdf_py.cli.convert") as mock_conv:
            mock_conv.return_value = pdf_out
            from md2pdf_py.cli import main

            code = main(
                [
                    str(md),
                    "-o",
                    str(pdf_out),
                    "--emit-html",
                    str(html_out),
                    "--create-dirs",
                ]
            )
            assert code == 0
            assert html_out.parent.is_dir()
            assert mock_conv.call_args[1]["emit_html"] == html_out
