"""Tests for md2pdf_py.converter module."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

import pytest

from md2pdf_py.converter import _parse_frontmatter, md_to_html

FIXTURES = Path(__file__).parent / "fixtures"
SAMPLE_MD = FIXTURES / "sample.md"

try:
    from weasyprint import HTML as _HTML  # noqa: F401

    WEASYPRINT_AVAILABLE = True
except (ImportError, OSError):
    WEASYPRINT_AVAILABLE = False


@contextmanager
def monkey_patch_weasyprint(side_effect: Callable[[], None]) -> Iterator[None]:
    """Patch converter._import_weasyprint to raise whatever side_effect raises."""
    with patch("md2pdf_py.converter._import_weasyprint", side_effect=side_effect):
        yield


class TestMdToHtml:
    """Unit tests for the md_to_html helper (no WeasyPrint needed at runtime)."""

    def test_basic_conversion(self) -> None:
        html = md_to_html("# Hello\n\nWorld")
        assert "<h1" in html
        assert "World" in html

    def test_title_tag(self) -> None:
        html = md_to_html("text", title="My Title")
        assert "<title>My Title</title>" in html

    def test_toc_generation(self) -> None:
        html = md_to_html("# A\n## B\n### C", include_toc=True)
        assert 'class="toc"' in html

    def test_table_rendering(self) -> None:
        md = "| A | B |\n|---|---|\n| 1 | 2 |"
        html = md_to_html(md)
        assert "<table>" in html

    def test_default_title(self) -> None:
        html = md_to_html("hello")
        assert "<title>Document</title>" in html

    def test_html_structure(self) -> None:
        html = md_to_html("test")
        assert "<!DOCTYPE html>" in html
        assert "<body>" in html


class TestFrontmatter:
    """Tests for YAML frontmatter parsing."""

    def test_parse_frontmatter(self) -> None:
        text = "---\ntitle: Hello\nauthor: Me\ndate: 2026-01-01\n---\n# Content"
        meta, body = _parse_frontmatter(text)
        assert meta["title"] == "Hello"
        assert meta["author"] == "Me"
        assert meta["date"] == "2026-01-01"
        assert body.strip() == "# Content"

    def test_no_frontmatter(self) -> None:
        text = "# Just markdown"
        meta, body = _parse_frontmatter(text)
        assert meta == {}
        assert body == text

    def test_frontmatter_cover_in_html(self) -> None:
        text = "---\ntitle: My Doc\nauthor: Author\n---\n# Body"
        html = md_to_html(text)
        assert 'class="cover-page"' in html
        assert "My Doc" in html

    def test_frontmatter_no_cover_flag(self) -> None:
        text = "---\ntitle: My Doc\n---\n# Body"
        html = md_to_html(text, no_cover=True)
        assert 'class="cover-page"' not in html

    def test_frontmatter_title_used_as_doc_title(self) -> None:
        text = "---\ntitle: Custom Title\n---\n# Body"
        html = md_to_html(text)
        assert "<title>Custom Title</title>" in html


class TestTemplateSystem:
    """Tests for the template system."""

    def test_templates_directory_exists(self) -> None:
        from md2pdf_py.converter import _TEMPLATES_DIR

        assert _TEMPLATES_DIR.is_dir()

    def test_all_templates_exist(self) -> None:
        from md2pdf_py.converter import _TEMPLATES_DIR

        for name in ("default", "report", "invoice", "book"):
            assert (_TEMPLATES_DIR / f"{name}.css").exists(), f"Missing template: {name}"

    def test_template_flag_passed(self, tmp_path: Path) -> None:
        from unittest.mock import patch as _patch

        md = tmp_path / "test.md"
        md.write_text("# Hello")
        pdf_out = tmp_path / "out.pdf"

        with _patch("md2pdf_py.cli.convert") as mock_conv:
            mock_conv.return_value = pdf_out
            from md2pdf_py.cli import main

            code = main([str(md), "-o", str(pdf_out), "--template", "report"])
            assert code == 0
            assert mock_conv.call_args[1]["template"] == "report"


@pytest.mark.skipif(not WEASYPRINT_AVAILABLE, reason="WeasyPrint system libs not available")
class TestConvert:
    """Integration tests for the convert function (requires WeasyPrint + pango)."""

    def test_pdf_generation(self, tmp_path: Path) -> None:
        from md2pdf_py.converter import convert

        out = tmp_path / "out.pdf"
        result = convert(SAMPLE_MD, out)
        assert result == out
        assert out.exists()
        assert out.stat().st_size > 0

    def test_pdf_with_toc(self, tmp_path: Path) -> None:
        from md2pdf_py.converter import convert

        out = tmp_path / "toc.pdf"
        convert(SAMPLE_MD, out, include_toc=True)
        assert out.stat().st_size > 0

    def test_pdf_letter_size(self, tmp_path: Path) -> None:
        from md2pdf_py.converter import convert

        out = tmp_path / "letter.pdf"
        convert(SAMPLE_MD, out, page_size="Letter")
        assert out.stat().st_size > 0

    def test_custom_css(self, tmp_path: Path) -> None:
        from md2pdf_py.converter import convert

        css = tmp_path / "custom.css"
        css.write_text("body { color: red; }")
        out = tmp_path / "custom.pdf"
        convert(SAMPLE_MD, out, css_path=css)
        assert out.stat().st_size > 0


class TestConvertValidation:
    """Validation tests that mock WeasyPrint's HTML.write_pdf."""

    def test_missing_input(self, tmp_path: Path) -> None:
        from md2pdf_py.converter import convert

        with pytest.raises(FileNotFoundError):
            convert(Path("/nonexistent.md"), tmp_path / "x.pdf")

    def test_invalid_extension(self, tmp_path: Path, caplog) -> None:  # type: ignore[no-untyped-def]
        """Non-markdown extensions are allowed but emit a warning."""
        import logging

        from md2pdf_py.converter import convert

        bad = tmp_path / "file.jpg"
        bad.write_text("# still parsed as markdown")
        # convert will warn then attempt PDF generation; in envs without
        # weasyprint libs it raises WeasyPrintUnavailableError afterwards.
        # Accept either successful warning path or weasyprint-unavailable.
        from md2pdf_py.converter import WeasyPrintUnavailableError

        with caplog.at_level(logging.WARNING, logger="md2pdf_py.converter"):
            try:
                convert(bad, tmp_path / "x.pdf")
            except WeasyPrintUnavailableError:
                pass
            except OSError:
                # weasyprint imported but system libs missing at runtime
                pass
        assert any("does not have a Markdown extension" in r.message for r in caplog.records)

    def test_missing_css(self, tmp_path: Path) -> None:
        from md2pdf_py.converter import convert

        with pytest.raises(FileNotFoundError, match="CSS file not found"):
            convert(SAMPLE_MD, tmp_path / "x.pdf", css_path=Path("/no.css"))

    def test_empty_input_rejected(self, tmp_path: Path) -> None:
        from md2pdf_py.converter import convert

        empty = tmp_path / "empty.md"
        empty.write_text("   \n\t\n")
        with pytest.raises(ValueError, match="empty"):
            convert(empty, tmp_path / "x.pdf")

    def test_emit_html_written_even_without_weasyprint(self, tmp_path: Path) -> None:
        """HTML must be written before the WeasyPrint import is attempted.

        Regression: previously `_import_weasyprint()` was invoked before
        `emit_html.write_text(...)`, so if pango/cairo system libs were
        missing the caller got a `WeasyPrintUnavailableError` and the
        intermediate HTML was silently dropped.
        """
        from md2pdf_py.converter import (
            WeasyPrintUnavailableError,
            convert_text,
        )

        html_out = tmp_path / "emit.html"
        pdf_out = tmp_path / "emit.pdf"

        def _boom() -> None:
            raise WeasyPrintUnavailableError("pango missing (simulated)")

        with (
            monkey_patch_weasyprint(_boom),
            pytest.raises(WeasyPrintUnavailableError),
        ):
            convert_text(
                "# Hello\n\nBody text.\n",
                pdf_out,
                emit_html=html_out,
            )

        # HTML must still have been written despite PDF failure.
        assert html_out.exists(), "emit-html output was lost when WeasyPrint unavailable"
        content = html_out.read_text(encoding="utf-8")
        assert ">Hello</h1>" in content
        assert "<style>" in content  # inlined CSS

    def test_invalid_template_falls_back_with_warning(self, tmp_path: Path, caplog) -> None:  # type: ignore[no-untyped-def]
        """Unknown --template names must warn and fall back to default."""
        import contextlib
        import logging

        from md2pdf_py.converter import (
            WeasyPrintUnavailableError,
            convert_text,
        )

        def _boom() -> None:
            raise WeasyPrintUnavailableError("pango missing (simulated)")

        with (
            caplog.at_level(logging.WARNING, logger="md2pdf_py.converter"),
            monkey_patch_weasyprint(_boom),
            contextlib.suppress(WeasyPrintUnavailableError),
        ):
            convert_text(
                "# Hi\n",
                tmp_path / "x.pdf",
                template="yanlisisim",
            )
        assert any("Unknown template 'yanlisisim'" in r.message for r in caplog.records), (
            "Expected a warning about unknown template fallback"
        )
