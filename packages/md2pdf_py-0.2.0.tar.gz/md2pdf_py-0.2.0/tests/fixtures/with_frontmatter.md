---
title: Test Document
author: Hakan Baysal
date: 2026-04-17
---

# Introduction

This document has YAML frontmatter for testing.

## Section 1

Some content here.
