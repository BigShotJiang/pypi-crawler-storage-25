# Örnek Markdown Dosyası

Bu dosya **md2pdf-py** test fixture'ıdır.

## Türkçe Karakter Testi

Şşığ çöğümlü İstanbul'da güneşli bir gün.

## Tablo Örneği

| İsim       | Yaş | Şehir     |
|-----------|-----|-----------|
| Hakan     | 30  | İstanbul  |
| Ayşe      | 25  | Ankara    |
| Müge      | 28  | İzmir     |

## Kod Bloğu

```python
def merhaba(isim: str) -> str:
    """Selamla."""
    return f"Merhaba, {isim}!"
```

## Alıntı

> Basitlik, en büyük zarafettir. — Leonardo da Vinci

## Liste

- Madde 1
- Madde 2
  - Alt madde
- Madde 3

1. Birinci
2. İkinci
3. Üçüncü

---

*Dosya sonu.*
