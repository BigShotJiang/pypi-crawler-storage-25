from setuptools import setup, find_packages

setup(
    name="ntc-sniff",
    version="1.0.7",
    packages=find_packages(),
    install_requires=["scapy"],
    entry_points={"console_scripts":["ntc-sniff=ntc_sniff.main:main"]}
)