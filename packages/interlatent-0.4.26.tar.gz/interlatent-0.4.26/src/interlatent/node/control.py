"""Built-in control-loop wrappers used by the Node daemon.

The daemon calls one of these on every assignment. The functions are
deliberately written to be drop-in replacements for one another and
to never import their heavy deps at module load — the daemon should
be importable on a barebones Pi.

Custom integrations: write your own `control_loop(client, session,
should_stop, **_)` and pass `--loop my_module:control_loop` to the
daemon. `import_callable` resolves it.

Episode recording: the LeRobot wrapper does NOT stage anything on the
Pi anymore. Each Infer call already ships the full observation to the
GPU container; when the OpenSession metadata carries ``record=true``
the server persists per-step rows + raw JPEG bytes, builds the LeRobot
dataset on shutdown, and uploads it through the same inbox protocol
the SDK upload path uses. The Pi loop is therefore pure inference:
``robot.get_observation() -> client.step() -> robot.send_action()``.
"""
from __future__ import annotations

import importlib
import io
import logging
import time
from typing import Any, Callable, Optional

import numpy as np

_LOG = logging.getLogger("interlatent.node.control")


def import_callable(spec: str) -> Callable[..., Any]:
    """Resolve a `module.path:attr` spec to the attribute itself.

    Used for `--loop` overrides on the CLI.
    """
    if ":" not in spec:
        raise ValueError(
            f"--loop expects 'module:function', got {spec!r}"
        )
    module_path, _, attr = spec.partition(":")
    mod = importlib.import_module(module_path)
    fn = getattr(mod, attr, None)
    if fn is None:
        raise AttributeError(
            f"module {module_path!r} has no attribute {attr!r}"
        )
    if not callable(fn):
        raise TypeError(f"{spec!r} is not callable")
    return fn


# ---------------------------------------------------------------------------
# Built-in LeRobot wrapper
# ---------------------------------------------------------------------------


def lerobot_control_loop(
    *,
    client,
    session: dict,
    should_stop: Callable[[], bool],
    robot_kind: str,
    robot_port: Optional[str] = None,
    robot_extra: Optional[dict[str, str]] = None,
    robot_cameras: Optional[dict[str, str]] = None,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    **_: Any,
) -> None:
    """Generic LeRobot observe/act loop.

    Reads frames + joint state from a LeRobot Robot, npz-encodes them
    for DRTC, and dispatches the returned action chunk.

    **Recording flow:** after a successful step() we capture the
    observation + executed action + JPEG-encoded camera frames and hand
    them to ``client.record_tick(...)``. That call is non-blocking —
    a background thread inside :class:`DRTCClient` drains the queue and
    ships each tick to the server via the ``RecordTick`` RPC, where the
    server-side recorder builds + uploads the LeRobot dataset on
    ``CloseSession``. Inference latency is unaffected.

    Pacing is governed by the DRTC client's internal RTC cooldown plus
    the explicit period below: without it the loop busy-spins while
    waiting for an action chunk (e.g. during a DRTC cold start),
    starving the camera capture thread until lerobot's frame-freshness
    check fails with a TimeoutError.
    """
    robot = _make_lerobot_robot(
        robot_kind, port=robot_port, extra=robot_extra or {}, cameras=robot_cameras or {}
    )

    session_id = session.get("id", "")
    fps = int(session.get("fps", 30) or 30)

    robot.connect()
    # Ordered action-feature names — used to turn the flat policy action
    # vector into the {name: value} dict send_action expects.
    action_keys = list(getattr(robot, "action_features", None) or [])
    _LOG.info(
        "LeRobot %r connected; action_keys=%s; entering control loop "
        "(streaming RecordTick → server) episode=%s",
        robot_kind, action_keys, session_id,
    )
    try:
        period = 1.0 / fps if fps > 0 else 1.0 / 30.0
        step_counter = 0
        while not should_stop():
            loop_start = time.perf_counter()

            obs = robot.get_observation()
            # Encode lazily: client.step() only builds the payload on
            # ticks where DRTC actually sends an observation, so the
            # ~1.8MB npz encode is skipped on the majority of ticks.
            # The policy expects observation.state + observation.images.*;
            # raw lerobot robot keys (<motor>.pos, <cam>) are remapped.
            action = client.step(
                lambda o=obs: _encode_npz(_to_policy_schema(o)),
                codec="npz",
            )
            if action is not None:
                action_arr = np.asarray(action, dtype=np.float32).reshape(-1)
                robot.send_action(_coerce_action_for_robot(action_arr, action_keys))

                # Per-tick capture — non-blocking; queues to a background
                # thread in the DRTC client that ships via RecordTick.
                _capture_tick(client, obs, action_arr, step_counter)
                step_counter += 1

            elapsed = time.perf_counter() - loop_start
            if elapsed < period:
                time.sleep(period - elapsed)
    finally:
        try:
            robot.disconnect()
        except Exception:
            _LOG.warning("Robot disconnect failed", exc_info=True)
        _LOG.info(
            "Control loop exiting for session %s; client.close() will "
            "flush recorder queue and trigger server-side upload.",
            session_id,
        )


def _capture_tick(client: Any, obs: Any, action: "np.ndarray", step: int) -> None:
    """JPEG-encode camera frames and queue a RecordTick on the DRTC client.

    lerobot returns ``{"<motor>.pos": float, "<cam>": np.ndarray (HxWx3 RGB)}``.
    We split numeric scalars (joint state) from numpy arrays (camera frames),
    JPEG-encode each frame, and hand the lot to :meth:`DRTCClient.record_tick`.

    JPEG encoding runs on the control thread but it's cheap (~1–2 ms for a
    640×480 frame on a Pi 5, OpenCV releases the GIL during ``imencode``).
    If this turns out to be a real budget hit on slower hardware we can
    move it into the DRTC client's recorder thread — but for now keeping
    it here lets the in-flight buffer hold compressed bytes, not raw RGB,
    cutting memory ~10× per queued frame.
    """
    try:
        import time as _time

        try:
            import cv2  # type: ignore
        except ImportError:
            cv2 = None  # type: ignore

        jpegs: dict[str, bytes] = {}
        state: list[float] = []
        for k, v in obs.items():
            if isinstance(v, np.ndarray) and v.ndim >= 2:
                if cv2 is None:
                    continue
                img = v
                if img.ndim == 3 and img.shape[2] == 3:
                    img = img[..., ::-1]  # RGB -> BGR for OpenCV
                ok, buf = cv2.imencode(
                    ".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 85],
                )
                if ok:
                    jpegs[k] = bytes(buf)
            else:
                try:
                    state.append(float(v))
                except (TypeError, ValueError):
                    continue

        client.record_tick(
            step=step,
            observation_state=state if state else None,
            action=action.tolist(),
            jpegs=jpegs,
            control_timestamp_ns=_time.monotonic_ns(),
        )
    except Exception:
        # Capture must never break inference.
        _LOG.exception("record_tick failed at step %d", step)


def _build_camera_configs(cameras: dict[str, str]) -> dict[str, Any]:
    """Build lerobot OpenCV camera configs from a ``{name: device}`` map.

    Each ``name`` becomes the lerobot camera key, so the robot emits
    ``observation.images.<name>``. Pick names that match the policy's
    expected image keys and no ``rename_map`` is needed.

    ``device`` is a /dev path ("/dev/video0") or a bare index ("0").
    Resolution/fps default to 640x480@30 — the SO101 camera default.
    """
    if not cameras:
        return {}
    from lerobot.cameras.opencv import OpenCVCameraConfig

    out: dict[str, Any] = {}
    for name, device in cameras.items():
        idx_or_path: Any = int(device) if str(device).isdigit() else device
        out[name] = OpenCVCameraConfig(
            index_or_path=idx_or_path, width=640, height=480, fps=30
        )
    return out


def _make_lerobot_robot(
    kind: str,
    *,
    port: Optional[str],
    extra: dict[str, str],
    cameras: Optional[dict[str, str]] = None,
):
    """Instantiate a LeRobot Robot by name.

    For v1 we support the two follower configs we've verified — extending
    to more is a 3-line addition per type.
    """
    # Importing here keeps the daemon importable without lerobot installed.
    try:
        from lerobot.robots import make_robot_from_config
    except ImportError as e:
        raise RuntimeError(
            "lerobot is not installed. Install with `pip install "
            "interlatent[lerobot]` (or pass --loop module:fn for a "
            "custom adapter)."
        ) from e

    cam_configs = _build_camera_configs(cameras or {})

    kind_norm = kind.lower().strip()
    if kind_norm in ("so101", "so101_follower"):
        # lerobot consolidated its per-robot modules: SO101FollowerConfig
        # now lives in the shared `so_follower` module (covers SO100 +
        # SO101). Older lerobot shipped a dedicated `so101_follower`
        # module — support both layouts.
        try:
            from lerobot.robots.so_follower import SO101FollowerConfig
        except ImportError:
            from lerobot.robots.so101_follower import SO101FollowerConfig
        kwargs = _filter_kwargs(SO101FollowerConfig, extra)
        if cam_configs:
            kwargs["cameras"] = cam_configs
        cfg = SO101FollowerConfig(port=port or "", **kwargs)
        return make_robot_from_config(cfg)

    if kind_norm in ("koch", "koch_follower"):
        from lerobot.robots.koch_follower import KochFollowerConfig
        kwargs = _filter_kwargs(KochFollowerConfig, extra)
        if cam_configs:
            kwargs["cameras"] = cam_configs
        cfg = KochFollowerConfig(port=port or "", **kwargs)
        return make_robot_from_config(cfg)

    raise ValueError(
        f"Unsupported --robot {kind!r}. Built-in support: so101_follower, "
        f"koch_follower. For other LeRobot robots, write a thin adapter and "
        f"pass --loop module:fn."
    )


def _filter_kwargs(cfg_cls, extra: dict[str, str]) -> dict[str, Any]:
    """Pick only the keys `cfg_cls` actually declares.

    Lets the user pass --robot-arg key=value without us hardcoding which
    keys are valid for which config class.
    """
    try:
        import dataclasses
        if dataclasses.is_dataclass(cfg_cls):
            valid = {f.name for f in dataclasses.fields(cfg_cls)}
            return {k: v for k, v in extra.items() if k in valid}
    except Exception:
        pass
    return dict(extra)


# ---------------------------------------------------------------------------
# Codecs
# ---------------------------------------------------------------------------


def _to_policy_schema(obs: dict) -> dict:
    """Map a raw lerobot robot observation to the policy input schema.

    lerobot robots return joints as bare ``<motor>.pos`` scalars and
    cameras as bare ``<name>`` image arrays. lerobot policies instead
    expect a single ``observation.state`` vector plus
    ``observation.images.<name>`` image keys.

    Joint scalars are concatenated in robot-observation order — which
    is the motor order the policy's ``observation.state`` was trained
    on, so no explicit joint-name map is needed. Images are detected by
    uint8 dtype + 2-D-or-more shape and re-keyed under
    ``observation.images.``.
    """
    state_vals: list[float] = []
    out: dict[str, Any] = {}
    for key, value in obs.items():
        if key == "task":
            out["task"] = value
            continue
        arr = np.asarray(value)
        if arr.dtype == np.uint8 and arr.ndim >= 2:
            name = key.rsplit(".", 1)[-1]
            out[f"observation.images.{name}"] = arr
        else:
            state_vals.extend(float(x) for x in arr.flatten())
    if state_vals:
        out["observation.state"] = np.asarray(state_vals, dtype=np.float32)
    return out


def _jpeg_encode(arr: np.ndarray, quality: int = 85) -> np.ndarray:
    """Encode an HWC/HW uint8 image as JPEG bytes (a 1-D uint8 array).

    Camera frames dominate the DRTC observation payload: raw, two cams
    at full res are ~1.8MB per observation, which is hundreds of ms of
    upload on a robot's uplink and the main source of inference latency.
    JPEG shrinks that ~15-30x. The server auto-detects the JPEG magic
    bytes (FF D8 FF) and decodes — no codec negotiation needed.
    """
    from PIL import Image

    img = arr
    if img.ndim == 3 and img.shape[-1] == 1:
        img = img[:, :, 0]
    buf = io.BytesIO()
    Image.fromarray(img).save(buf, format="JPEG", quality=quality)
    return np.frombuffer(buf.getvalue(), dtype=np.uint8)


def _encode_npz(obs: dict) -> bytes:
    """Encode a LeRobot observation dict into npz bytes.

    LeRobot observations are dicts of numpy arrays (joints, cameras).
    Camera frames (uint8, 2-D+) are JPEG-compressed before packing;
    everything else (the state vector) goes in raw. The DRTC server's
    npz codec produces a dict for the lerobot backend to consume via
    `_to_batch`, decoding any JPEG blobs on the way in.
    """
    flat: dict[str, np.ndarray] = {}
    for k, v in obs.items():
        if isinstance(v, np.ndarray) and v.dtype == np.uint8 and v.ndim >= 2:
            # Camera frame — JPEG-compress it.
            try:
                flat[k] = _jpeg_encode(v)
                continue
            except Exception:
                _LOG.debug("JPEG encode failed for %r; sending raw", k, exc_info=True)
                flat[k] = v
                continue
        if isinstance(v, np.ndarray):
            flat[k] = v
        else:
            try:
                flat[k] = np.asarray(v)
            except Exception:
                # Skip un-encodable keys rather than crashing the whole loop.
                _LOG.debug("Skipping unencodable obs key %r (type=%s)", k, type(v).__name__)
    buf = io.BytesIO()
    np.savez(buf, **flat)
    return buf.getvalue()


def _coerce_action_for_robot(action: np.ndarray, action_keys: list) -> Any:
    """Convert the DRTC action vector into the shape the robot wants.

    lerobot follower robots (so_follower, koch_follower, ...) expect a
    dict mapping action-feature names to floats, e.g.
    ``{"shoulder_pan.pos": 0.1, ...}``. We zip the flat policy action
    vector with the robot's ordered ``action_features`` keys.

    If the lengths don't match (or no keys were supplied) we fall back
    to the bare array — some robots accept that.
    """
    arr = np.asarray(action, dtype=np.float32).reshape(-1)
    if action_keys and len(action_keys) == len(arr):
        return {k: float(v) for k, v in zip(action_keys, arr)}
    return arr
