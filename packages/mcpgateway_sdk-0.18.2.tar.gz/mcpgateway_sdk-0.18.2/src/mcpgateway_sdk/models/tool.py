"""Tool models."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ToolLookup(BaseModel):
    """A tool resolved by exact name lookup."""

    model_config = ConfigDict(extra="ignore")

    tool_id: UUID
    tool_name: str
    description: str = ""
    server_id: UUID
    server_name: str = ""
    input_schema: dict[str, Any] = {}


class ToolSearchResult(BaseModel):
    """A tool returned from semantic search."""

    model_config = ConfigDict(extra="ignore")

    tool_id: UUID
    tool_name: str
    description: str = ""
    server_id: UUID
    server_name: str = ""
    score: float = 0.0
    input_schema: dict[str, Any] = {}


class ToolExecuteResult(BaseModel):
    """Result of executing a tool via the gateway."""

    model_config = ConfigDict(extra="ignore")

    result: Any = None
    server_id: UUID
    tool_name: str
    duration_ms: int = 0
    error: str | None = None
