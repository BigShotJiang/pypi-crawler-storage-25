"""Sandbox models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class SandboxCreate(BaseModel):
    """Request body for creating a new sandbox."""

    image: str = "mcpgateway/sandbox-runtime:latest"
    idle_timeout_seconds: int = 1800
    memory_mb: int | None = None
    cpu_cores: float | None = None
    disk_mb: int | None = None
    env_vars: dict[str, str] = {}
    network_enabled: bool | None = None
    session_key: str | None = None


class Sandbox(BaseModel):
    """A running or stopped sandbox instance."""

    model_config = ConfigDict(extra="ignore")

    id: UUID
    user_id: UUID | None = None
    user_name: str | None = None
    status: str = "unknown"
    image: str = ""
    container_id: str | None = None
    workspace_path: str = "/workspace"
    created_at: datetime | None = None
    last_activity_at: datetime | None = None
    stopped_at: datetime | None = None
    memory_mb: int = 512
    cpu_cores: float = 1.0
    disk_mb: int = 1024
    idle_timeout_seconds: int = 1800
    network_enabled: bool = False
    exec_count: int = 0
    session_key: str | None = None


class ExecResult(BaseModel):
    """Result of executing a command in a sandbox."""

    model_config = ConfigDict(extra="ignore")

    exit_code: int = 0
    stdout: str = ""
    stderr: str = ""
    duration_ms: int = 0


class SandboxFile(BaseModel):
    """A file or directory in a sandbox workspace."""

    model_config = ConfigDict(extra="ignore")

    name: str
    path: str = ""  # May not be present in API response
    size: int = 0
    is_directory: bool = False
    modified_at: datetime | None = None
