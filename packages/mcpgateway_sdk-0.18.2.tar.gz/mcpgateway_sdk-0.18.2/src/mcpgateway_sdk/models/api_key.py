"""API key models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ApiKeyCreate(BaseModel):
    """Request body for creating an API key."""

    name: str
    description: str | None = None
    environment: str = "live"
    scopes: list[str] | None = None
    rate_limit_rpm: int = 60
    expires_in_days: int | None = None
    expires_at: datetime | None = None


class ApiKey(BaseModel):
    """An API key returned from the gateway."""

    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
    description: str | None = None
    key_prefix: str = ""
    environment: str = "live"
    scopes: list[str] | None = None
    rate_limit_rpm: int = 60
    is_active: bool = True
    created_at: datetime | None = None
    updated_at: datetime | None = None
    expires_at: datetime | None = None
    last_used_at: datetime | None = None
    last_used_ip: str | None = None
    key: str | None = None  # Only present on creation response
