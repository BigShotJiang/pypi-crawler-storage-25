"""Skill models."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Skill(BaseModel):
    """An agent skill managed by the gateway."""

    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
    description: str | None = None
    source_type: str = ""
    source_url: str | None = None
    mcp_server_id: UUID | None = None
    mcp_server_name: str | None = None
    skill_metadata: dict[str, Any] = {}
    package_size_bytes: int = 0
    portal_visible: bool = False
    portal_category: str | None = None
    portal_tags: list[str] = []
    skill_md_content: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class SkillCatalogEntry(BaseModel):
    """An entry in the skill catalog (available for installation)."""

    model_config = ConfigDict(extra="ignore")

    name: str
    description: str = ""
    source: str = ""
    source_url: str = ""
    author: str | None = None
    version: str | None = None
    tags: list[str] = []
    license: str | None = None
    files: list[str] = []
    metadata: dict[str, Any] = {}


class AttachResult(BaseModel):
    """Result of attaching a skill to a server."""

    model_config = ConfigDict(extra="ignore")

    attachment_id: str
    tools_registered: list[str] = []
    server_id: UUID
    skill_id: UUID
