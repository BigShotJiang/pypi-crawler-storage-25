"""Common models shared across resources."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class PaginatedResponse(BaseModel):
    """Paginated list response from the API."""

    model_config = ConfigDict(extra="ignore")

    items: list[dict[str, Any]]
    total: int
    offset: int = 0
    limit: int = 100
