"""Shared test fixtures for MCPGateway SDK tests."""
