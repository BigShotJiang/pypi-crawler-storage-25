# 🚀 by-framework-python

<div align="center">

[![版本](https://img.shields.io/badge/version-0.1.0-blue.svg)](pyproject.toml)
[![Python](https://img.shields.io/badge/python-3.12+-yellow.svg)](pyproject.toml)
[![Redis](https://img.shields.io/badge/redis-7.0+-red.svg)](pyproject.toml)
[![许可证](https://img.shields.io/badge/license-Apache_2.0-green.svg)](LICENSE)

</div>

<div align="center">

[**English**](README.md) | [**中文**](README_zh.md)

</div>

---

**by-framework** 是一个基于 Redis Streams 构建的分布式 Agent 调度框架，提供 Worker 编排、会话级运行时状态与插件化能力注册，适合构建 AI Agent 系统。

---

## 目录

- [✨ 核心特性](#-核心特性)
- [🏗️ 核心架构](#️-核心架构)
- [📦 安装](#-安装)
- [🚀 快速上手](#-快速上手)
- [💡 深入理解](#-深入理解)
- [🔌 插件系统](#-插件系统)
- [📡 发送任务](#-发送任务)
- [🧪 示例](#-示例)
- [🛠️ 配置参考](#️-配置参考)
- [📚 API 参考](#-api-参考)
- [🧩 进阶能力](#-进阶能力)
- [🚀 部署指南](#-部署指南)

---

## ✨ 核心特性

- ⚡ **原生异步**：基于 Python `asyncio` 构建，完美契合 I/O 密集型 Agent 任务。
- 🧩 **高度插件化**：通过插件和 AgentConfig 注册工具、提示词、技能与生命周期钩子。
- 📊 **状态管控**：完善的 `AgentContext` 支持，轻松实现流式输出、状态流转和附件处理。
- 🔄 **解耦架构**：采用控制流与数据流分离设计，便于 Worker 横向扩展。
- 🎯 **Agent Type 路由**：Worker 通过 `get_agent_types()` 声明支持的 agent type，并参与路由与在线校验。

---

## 🏗️ 核心架构

系统采用事件驱动设计，高度解耦：

```
┌─────────────┐       ┌──────────────┐       ┌──────────────┐
│   Client    │──────▶│  Redis Input │──────▶│   Gateway    │
│ (Gateway)   │       │     MQ       │       │   Worker     │
└─────────────┘       └──────────────┘       └──────┬───────┘
        ▲                                              │
        │                                              │
        │                                              ▼
┌─────────────┐       ┌──────────────┐       ┌──────────────┐
│   Consumer  │◀─────│  Redis Data  │◀─────│   Business   │
│  / Backend  │       │   Streams    │       │   Logic      │
└─────────────┘       └──────────────┘       └──────────────┘
```

### 核心组件说明

- **接入层**: `GatewayClient` 向 Redis Input MQ 投递控制指令。
- **调度层**: 利用 Redis Stream 实现 Worker 集群的竞争消费与路由。
- **执行层**: `GatewayWorker` 主动拉取任务，并在独立的隔离工作空间中执行业务逻辑。
- **输出层**: 数据异步写入会话级 data stream，供下游消费者读取。

### Worker 路由语义

当前 Worker 路由有三层语义，建议分开理解：

- **membership**: Worker 声明自己支持哪些 `agent_types`。这是静态关系，只在启动和优雅退出时更新。
- **online / heartbeat**: Worker 当前是否还能接单。只有当前在线的 Worker 才被视为可发送目标。
- **worker_id lock**: 防止同一个 `worker_id` 被重复启动。这是实例互斥，不参与 agent type 路由判断。

生产主路径使用 agent type stream：

- Client 把消息写入 `byai_gateway:ctrl:agent_type:{agent_type}`
- 同一 agent type 下的多个 Worker 通过 Redis consumer group 竞争消费
- 发送前只检查"这个 agent type 是否至少存在一个 online Worker"
- 不会在发送前预先挑选某个具体 Worker

调试或定向控制路径使用 worker stream：

- 当显式提供 `target_worker_id` 时，消息会写入 `byai_gateway:ctrl:worker:{worker_id}`
- 这条路径只用于 debug、定向下发或 worker 级控制命令
- 发送前会显式检查该 worker 是否 online

### 数据流向

```
User Request
    ↓
Gateway (写入 control stream)
    ↓
Worker (消费 control stream，处理任务)
    ↓
Redis Stream (写入 session data stream)
    ↓
Backend 或其他消费者 (读取 session data stream)
    ↓
Frontend (渲染实时 AI 响应)
```

---

## 📦 安装

### 前置要求

- Python 3.12+
- Redis 7.0+ (用于消息队列)

### 使用 pip 安装

```bash
# 基础安装
pip install by-framework

# 开发模式安装
pip install -e ".[dev]"
```

### 使用 uv 安装 (推荐)

```bash
# 克隆项目后安装所有依赖
cd by-framework-python
uv sync
```

### Workspace 开发

当前仓库使用 `uv workspace` 管理本地包开发。

常用命令：

```bash
# 在仓库根目录同步 workspace 依赖
uv sync

# 运行包测试
uv run pytest tests
```

## 🚀 快速上手

### 1. 创建一个简单的 Agent Worker

创建 `my_agent.py`：

```python
import asyncio
from by_framework import GatewayWorker, AgentContext, run_worker

class MyAssistant(GatewayWorker):
    def get_agent_types(self):
        # 声明此 Worker 能够处理的 Agent 类型
        return ["weather_agent", "chat_agent"]

    async def process_command(self, command, context: AgentContext):
        # 发送流式文本片段
        await context.emit_chunk("正在处理您的请求...\n")

        # 模拟耗时操作
        await asyncio.sleep(0.5)

        # 更新任务状态
        await context.emit_state("thinking")

        # 从 command 的 content 中读取请求内容
        user_input = (
            command.content if isinstance(command.content, str) else str(command.content)
        )

        # 发送思考过程
        await context.emit_chunk(f"我收到了: {user_input}\n")
        await asyncio.sleep(0.3)

        # 发送最终结果
        await context.emit_chunk("这是我的回复！")

        return {
            "status": "success",
            "message": "任务完成",
            "data": {"answer": "今天天气晴朗"}
        }

if __name__ == "__main__":
    run_worker(
        worker_class=MyAssistant,
        worker_id="worker-01",
        redis_host="localhost",
        redis_port=6379,
    )
```

### 2. 启动 Redis

```bash
docker run -d -p 6379:6379 redis:7-alpine
```

### 3. 启动 Worker

```bash
cd by-framework-python
uv run python my_agent.py
```

### 4. 发送测试任务

创建 `send_task.py`：

```python
import asyncio

from by_framework import ByaiGatewayClient, WorkerRegistry, close_redis, init_redis


async def send_task():
    # 初始化共享 Redis 客户端和 registry
    redis = init_redis(host="localhost", port=6379)
    registry = WorkerRegistry(redis_client=redis)

    # ByaiGatewayClient 接收的是 redis_client / registry
    client = ByaiGatewayClient(redis_client=redis, registry=registry)

    response = await client.send_message(
        target_agent_type="weather_agent",
        session_id="session-001",
        content="今天北京天气怎么样？",
    )

    if response.success:
        print(f"任务已发送，消息 ID: {response.message_id}")
    else:
        print(f"发送失败: {response.error}")

    await close_redis()


asyncio.run(send_task())
```

运行：

```bash
uv run python send_task.py
```

---

## 💡 深入理解

### GatewayWorker 基类

`GatewayWorker` 是所有自定义 Worker 的基类，你需要实现以下方法：

| 方法 | 是否必须 | 描述 |
|------|---------|------|
| `get_agent_types()` | 是 | 返回此 Worker 能处理的 Agent 类型列表 |
| `process_command(command, context)` | 是 | 处理具体的业务逻辑 |

### AgentContext 上下文

`AgentContext` 提供了与运行环境交互的能力：

```python
from by_framework import AgentContext, ArtifactEvent


async def process_command(self, command, context: AgentContext):
    # 1. 发送流式输出
    await context.emit_chunk("正在处理...")

    # 2. 发送产物/结构化数据
    await context.emit_artifact(ArtifactEvent(url="https://example.com/result.json"))

    # 3. 获取消息 ID 和会话 ID
    msg_id = context.message_id
    session_id = context.session_id

    # 4. 调用其他 Agent (支持挂起当前任务等待返回)
    result = await context.call_agent(
        target_agent_type="translator_agent",
        content="Hello",
        wait_for_reply=True
    )
```

### 命令与消息协议

#### AskAgentCommand (任务指令)

```python
from by_framework.core.protocol.commands import AskAgentCommand
from by_framework.core.protocol.message_header import MessageHeader

command = AskAgentCommand(
    header=MessageHeader(
        message_id="msg_123",
        session_id="sess_456",
        target_agent_type="weather_agent"
    ),
    content="查询北京天气",
    extra_payload={
        "location": "北京"
    }
)
```

#### 常用 EventType 值

| 事件类型 | 描述 |
|---------|------|
| `answerDelta` | 回答内容增量 |
| `reasoningLogDelta` | 推理或中间日志输出 |
| `appStreamResponse` | 标记流结束 |
| `taskCreate` | 任务创建相关事件 |
| `taskStop` | 任务终止相关事件 |

---

## 🔌 插件系统

插件是 By-Framework 扩展能力的基石。你可以通过插件注册工具、提示词模板等。

### 插件目录结构

```
my_plugins/
├── weather_plugin.py
├── calculator_plugin.py
└── custom_hooks.py
```

### 编写插件

创建 `my_cool_plugin.py`：

```python
from by_framework import AgentConfig, AgentContext, Plugin, PluginBuildContext, PluginManifest
from typing import Any

class WeatherPlugin(Plugin):
    def __init__(self):
        super().__init__(PluginManifest(
            plugin_id="weather_plugin",
            version="1.0.0",
        ))

    async def register_agent_configs(self, build_context: PluginBuildContext) -> list[AgentConfig]:
        # 插件通过返回 AgentConfig 列表来注册能力
        config = AgentConfig(
            agent_id="weather_assistant",
            tools={
                "get_current_weather": self._get_weather,
                "get_forecast": self._get_forecast
            },
            prompts={
                "system_prompt": "你是一个天气助手..."
            }
        )
        return [config]

    async def _get_weather(self, city: str) -> dict[str, Any]:
        """获取当前天气"""
        # 实际项目中这里会调用真实的天气 API
        return {
            "city": city,
            "temperature": 25,
            "condition": "晴",
            "humidity": 60
        }

    async def _get_forecast(self, city: str, days: int = 3) -> list[dict]:
        """获取天气预报"""
        return [
            {"day": 1, "high": 28, "low": 18, "condition": "晴"},
            {"day": 2, "high": 26, "low": 16, "condition": "多云"},
            {"day": 3, "high": 24, "low": 14, "condition": "阴"}
        ][:days]

    # 插件生命周期钩子
    async def on_task_start(self, context: AgentContext):
        """任务开始时调用"""
        print(f"任务 {context.message_id} 开始")

    async def on_task_complete(self, context: AgentContext, result: Any):
        """任务成功完成时调用"""
        print(f"任务 {context.message_id} 完成")

    async def on_task_error(self, context: AgentContext, error: Exception):
        """任务出错时调用"""
        print(f"任务 {context.message_id} 出错: {error}")
```

### 使用插件

方式一：通过 plugin_list 参数传入

```python
from by_framework import run_worker
from my_cool_plugin import WeatherPlugin

run_worker(
    worker_class=MyAssistant,
    worker_id="worker-01",
    plugin_list=[WeatherPlugin()]
)
```

方式二：通过 plugin_configurator 回调配置

```python
from by_framework import run_worker
from my_cool_plugin import WeatherPlugin

def configure_plugins(registry):
    registry.register_bundle(WeatherPlugin())

run_worker(
    worker_class=MyAssistant,
    worker_id="worker-01",
    plugin_configurator=configure_plugins
)
```

方式三：从插件目录加载模块

```python
run_worker(
    worker_class=MyAssistant,
    plugin_dir="./my_plugins"  # 启动时扫描目录中的 .py 文件
)
```

---

## 📡 发送任务

### 使用 ByaiGatewayClient

`ByaiGatewayClient` 是对 `GatewayClient` 的封装，默认通过共享的 Byai codec 进行消息序列化，支持更高级的消息协议。

```python
import asyncio

from by_framework import ByaiGatewayClient, WorkerRegistry, close_redis, init_redis


async def main():
    redis = init_redis(host="localhost", port=6379)
    registry = WorkerRegistry(redis_client=redis)
    client = ByaiGatewayClient(redis_client=redis, registry=registry)

    response = await client.send_message(
        target_agent_type="weather_agent",
        session_id="session_123",
        user_code="user_123",
        content="查询北京今天的天气",
    )

    if response.success:
        print(f"任务已发送，消息 ID: {response.message_id}")
    else:
        print(f"发送失败: {response.error}")

    await close_redis()


asyncio.run(main())
```

### 发送路径说明

`GatewayClient.send_message(...)` 有两种模式：

- 默认 agent type 模式：根据 `target_agent_type` 写入 agent type stream，并在 `require_online_worker=True` 时验证是否存在在线 worker。
- direct worker 模式：传入 `target_worker_id` 后直接写入 worker stream，适合 debug 或定向控制。

这意味着：

- `response.target_worker_id` 在 agent type 模式下可能为空，因为实际由哪个 worker 消费，是在对应 agent type 的消费者真正读到消息时才确定的。
- 如果要取消一个已经开始执行的任务，execution registry 中会在 worker 真正开始处理时补齐 `worker_id`。

---

## 🧪 示例

### 示例 1: 基础流式输出

```python
class StreamingAgent(GatewayWorker):
    def get_agent_types(self):
        return ["streaming_demo"]

    async def process_command(self, command, context: AgentContext):
        text = "这是一段流式输出的示例文本。"

        for char in text:
            await context.emit_chunk(char)
            await asyncio.sleep(0.05)

        return {"status": "done"}
```

### 示例 2: 注册插件能力

工具、提示词和技能通过插件机制注册，并通过 `AgentConfig` 暴露。

```python
from by_framework import AgentConfig, GatewayWorker, Plugin, PluginBuildContext, PluginManifest


class CalculatorPlugin(Plugin):
    def __init__(self):
        super().__init__(PluginManifest(plugin_id="calculator"))

    async def register_agent_configs(
        self, build_context: PluginBuildContext
    ) -> list[AgentConfig]:
        return [
            AgentConfig(
                agent_id="tool_demo",
                tools={"calculate": self.calculate},
            )
        ]

    async def calculate(self, a: float, b: float, op: str) -> float:
        if op == "+":
            return a + b
        if op == "-":
            return a - b
        if op == "*":
            return a * b
        if op == "/":
            return a / b if b != 0 else 0
        return 0


class ToolAgent(GatewayWorker):
    def get_agent_types(self):
        return ["tool_demo"]

    async def process_command(self, command, context: AgentContext):
        config = context.get_agent_config("tool_demo")
        await context.emit_chunk(
            f"已注册工具: {list(config.tools.keys()) if config else []}"
        )
        return {"status": "success"}
```

## 🧩 进阶能力

### 人机交互型流程

Worker 可以通过 `context.ask_user(...)` 挂起执行并等待用户输入。用户回复回来后，会以 `ResumeCommand` 的形式重新进入同一个 Worker。

```python
from by_framework import AgentContext, AskUserEvent, GatewayWorker, ResumeCommand


class ApprovalAgent(GatewayWorker):
    def get_agent_types(self):
        return ["approval_agent"]

    async def process_command(self, command, context: AgentContext):
        if isinstance(command, ResumeCommand):
            await context.emit_chunk(f"用户回复: {command.content}")
            return {"status": "completed"}

        return await context.ask_user(
            AskUserEvent(prompt="请确认部署窗口。")
        )
```

### Scatter-Gather 分发

`dispatch_group(...)` 可以一次分发多个子任务，`collect_group_results(...)` 可以在这些子任务回调完成后收集结果。

```python
tasks = [
    {"target_agent_type": "researcher", "content": "收集参考资料"},
    {"target_agent_type": "writer", "content": "起草摘要"},
]

group = await context.dispatch_group(tasks, wait_for_reply=True)
results = await context.collect_group_results(group["task_group_id"])
```

### Byai 强类型 Worker 层

如果你的业务内容使用 BaiYing message 对象，可以直接继承 `ByaiWorker`，并配合 `ByaiAgentContext` 使用，框架会自动做内容编解码。

### 服务发现工具

仓库中还包含一套基于 Redis 的服务发现与 HTTP 调用工具：

- `ServiceRegistry`：服务注册与心跳
- `DiscoveryClient`：带缓存的服务发现与负载均衡
- `DiscoveryHttpClient`：结合服务发现的 HTTP 重试与节点切换

这些实现位于 [src/by_framework/core/discovery.py](/Users/xiaozhongcheng/data/company/beyonai/by-framework-python/src/by_framework/core/discovery.py) 和 [src/by_framework/util/discovery_http_client.py](/Users/xiaozhongcheng/data/company/beyonai/by-framework-python/src/by_framework/util/discovery_http_client.py)。

---

## 🛠️ 配置参考

### run_worker 函数参数

`run_worker` 函数支持丰富的配置项：

| 参数 | 类型 | 描述 | 默认值 |
| :--- | :--- | :--- | :--- |
| `worker_class` | `Type[GatewayWorker]` | **必填**。业务 Worker 类。 | - |
| `worker_id` | `str` | Worker 实例的唯一标识名。 | `"worker-1"` |
| `redis_host` | `str` | Redis 服务器地址。 | `"localhost"` |
| `redis_port` | `int` | Redis 端口。 | `6379` |
| `redis_db` | `int` | Redis 数据库号。 | `0` |
| `redis_password` | `str` | Redis 密码 (可选)。 | `None` |
| `redis_username` | `str` | Redis 用户名 (可选)。 | `None` |
| `workspace_dir` | `str` | 任务执行的本地工作目录。 | `"/tmp/gateway-workspace"` |
| `consumer_group` | `str` | Redis 消费者组名称。 | `"agent_engines"` |
| `max_concurrency` | `int` | 单个 Worker 的最大并发处理数。 | `50` |
| `fetch_count` | `int` | 每次从 Redis 批量获取的消息数量。 | `10` |
| `redis_max_connections` | `int` | Redis 最大连接数。 | `max_concurrency + 10` |
| `plugin_list` | `List[Plugin]` | 显式传入的插件列表。 | `None` |
| `plugin_configurator` | `Callable` | 插件配置回调函数。 | `None` |
| `plugin_hook_timeout_seconds` | `float` | 插件 hook 默认超时时间。 | `None` |
| `plugin_log_hook_stats_on_shutdown` | `bool` | 退出时是否输出插件 hook 统计。 | `True` |
| `plugin_dir` | `str` | 启动时扫描一次的 `.py` 插件目录。 | `None` |

### 环境变量

| 环境变量 | 描述 | 默认值 |
|---------|------|-------|
| `BYAI_WORKER_CONCURRENCY` | 最大并发数 | `50` |
| `BYAI_WORKER_FETCH_COUNT` | 批量获取消息数 | `10` |
| `BYAI_REDIS_MAX_CONNECTIONS` | Redis 最大连接数 | `max_concurrency + 10` |

---

## 📚 API 参考

### GatewayWorker

```python
class GatewayWorker:
    def get_agent_types(self) -> List[str]:
        """返回此 Worker 能处理的 Agent 类型列表"""
        pass

    async def process_command(self, command, context: AgentContext) -> Any:
        """处理命令并返回结果"""
        pass
```

### AgentContext

```python
class AgentContext:
    session_id: str
    trace_id: str
    current_agent_id: str
    message_id: str
    parent_message_id: str

    async def emit_chunk(self, event: Union[StreamChunkEvent, str], event_type: Optional[str] = None):
        """发送文本片段或流式事件"""

    async def emit_state(self, event: Union[StateChangeEvent, str], event_type: Optional[str] = None):
        """发送状态更新"""

    async def emit_artifact(self, event: Union[ArtifactEvent, str], event_type: Optional[str] = None):
        """发送产物/附件"""

    async def ask_user(self, event: Union[AskUserEvent, str]) -> dict:
        """向用户发送等待输入请求"""

    async def call_agent(self, target_agent_type: str, content: object, **kwargs) -> dict:
        """调用其他 Agent"""

    async def dispatch_group(self, tasks: list[dict], **kwargs) -> dict:
        """分发任务组"""

    async def get_active_workers(self) -> Dict[str, Any]:
        """获取集群中所有活跃的 worker"""
```

### GatewayClient / ByaiGatewayClient

```python
class GatewayClient:
    async def send_message(
        self,
        target_agent_type: str,
        session_id: str,
        content: Any,
        user_code: str = "",
        action_type: str = "ASK_AGENT",
        metadata: Optional[dict] = None,
        target_worker_id: Optional[str] = None,
        require_online_worker: bool = True,
    ) -> SendMessageResponse:
        """发送消息，返回响应对象"""

    async def cancel_task(self, message_id: str, session_id: str, reason: str = "") -> CancelTaskResponse:
        """取消指定的任务"""
```

## 🚀 部署指南

### 单机部署

1. **准备环境**

```bash
# 安装依赖
cd by-framework-python
uv sync
```

2. **启动 Redis**

```bash
docker run -d --name gateway-redis \
  -p 6379:6379 \
  --restart unless-stopped \
  redis:7-alpine
```

3. **启动 Worker**

```bash
uv run python -m by_framework \
  --worker-class my_agent.MyAgent \
  --worker-id worker-01 \
  --redis-host localhost
```

### 多 Worker 部署

如需横向扩展，可以启动多个不同 `worker_id` 的 Worker 进程，并让它们共享同一个 Redis 实例与相同的 `target_agent_type` stream。

### 生产环境建议

1. **使用连接池**

```python
run_worker(
    worker_class=MyAgent,
    redis_max_connections=50
)
```

2. **配置监控**

```python
import logging

from by_framework.common.logger import setup_logging

setup_logging(level=logging.INFO, use_json=True)
```

### 常见问题

**Q: 如何保证任务不丢失？**

A: Redis Streams 提供持久化机制。Worker 使用 `XACK` 确认消息处理完成，未确认的消息会被重新投递。

**Q: 如何实现 Worker 负载均衡？**

A: 多个 Worker 连接同一个 Redis Stream，Redis 会自动在消费者组内进行负载分配。

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

### 开发流程

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'feat: add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 开启 Pull Request

---

## 📄 许可证

本项目采用 Apache 2.0 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

---

由 **byai 团队** 维护。

有问题或建议？欢迎联系我们！
