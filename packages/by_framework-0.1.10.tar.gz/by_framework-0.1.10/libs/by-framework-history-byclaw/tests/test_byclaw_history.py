# pylint: disable=C0114,C0115,C0116,W0613
import httpx
import pytest

from by_framework_history_byclaw import ByClawHistoryBackend


@pytest.mark.asyncio
async def test_byclaw_history_backend_formats_messages(monkeypatch) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/byaiService/open/api/inner/getMessages"
        assert request.content == b'{"sessionId":"sess-1","topK":2}'
        return httpx.Response(
            200,
            json={
                "code": 0,
                "msg": "success",
                "data": [
                    {"usage": 1, "messageContent": "hello", "metadata": {"n": 1}},
                    {"usage": 2, "messageContent": "world", "metadata": {"n": 2}},
                ],
            },
        )

    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(
        transport=transport, base_url="https://history.example.com"
    )

    class FakeAsyncClient:

        def __init__(self, *args, **kwargs):
            self._client = client

        async def __aenter__(self):
            return self._client

        async def __aexit__(self, exc_type, exc, tb):
            await self._client.aclose()
            return False

    monkeypatch.setattr(
        "by_framework_history_byclaw.byclaw_history.httpx.AsyncClient", FakeAsyncClient
    )

    backend = ByClawHistoryBackend(base_url="https://history.example.com")
    history = await backend.get_history("sess-1", limit=2)

    assert history == [
        {"role": "user", "content": "hello", "metadata": {"n": 1}},
        {"role": "assistant", "content": "world", "metadata": {"n": 2}},
    ]
