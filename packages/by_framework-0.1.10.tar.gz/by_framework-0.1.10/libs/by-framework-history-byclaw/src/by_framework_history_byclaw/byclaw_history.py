# pylint: disable=C0114,C0301,R0914,W0718
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import httpx
from by_framework.common.logger import logger
from by_framework.core.runtime.history.base import BaseHistoryBackend


class ByClawHistoryBackend(BaseHistoryBackend):
    """History record storage backend based on ByAI interface."""

    def __init__(self, base_url: Optional[str] = None):
        self.base_url = base_url or os.environ.get("BYAI_BASE_URL", "")

    async def save_message(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Save message to this backend (ByClaw backend is read-only, not supported yet)."""
        logger.warning(
            "ByClawHistoryBackend: save_message is not supported for ByAI backend, session_id=%s",
            session_id,
        )

    async def list_sessions(self) -> List[Dict[str, Any]]:
        """Get all session list (not supported by ByClaw backend)."""
        logger.warning(
            "ByClawHistoryBackend: list_sessions is not supported for ByAI backend"
        )
        return []

    async def get_history(
        self, session_id: str, limit: int = 10
    ) -> list[dict[str, Any]]:
        url = f"{self.base_url.rstrip('/')}/byaiService/open/api/inner/getMessages"
        payload = {"sessionId": session_id, "topK": limit}

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(url, json=payload, timeout=10.0)
                resp.raise_for_status()
                data = resp.json()

                if not isinstance(data, dict):
                    logger.error(
                        "ByClawHistoryBackend: Invalid response format for session %s, expected dict, got %s",
                        session_id,
                        type(data),
                    )
                    return []

                result_code = data.get("code")
                if result_code != 0:
                    logger.error(
                        "ByClawHistoryBackend: Failed to get messages for session %s, code: %s, message: %s",
                        session_id,
                        result_code,
                        data.get("msg", "Unknown error"),
                    )
                    return []

                messages_data = data.get("data")
                if not isinstance(messages_data, list):
                    logger.warning(
                        "ByClawHistoryBackend: 'data' field for session %s is not a list, got %s",
                        session_id,
                        type(messages_data),
                    )
                    return []

                formatted_messages: list[dict[str, Any]] = []
                for item in messages_data:
                    if not isinstance(item, dict):
                        continue

                    usage = item.get("usage")
                    role = (
                        "user"
                        if usage == 1
                        else "assistant"
                        if usage == 2
                        else "unknown"
                    )
                    content = item.get("messageContent") or ""

                    formatted_messages.append(
                        {
                            "role": role,
                            "content": content,
                            "metadata": item.get("metadata"),
                        }
                    )

                return formatted_messages
        except Exception as err:
            logger.error(
                "ByClawHistoryBackend: Unexpected error while getting messages for session %s: %s",
                session_id,
                str(err),
                exc_info=True,
            )
            return []
