"""Tests for adapter and worker modules."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from by_framework.core.protocol.commands import AskAgentCommand, ResumeCommand
from by_framework.core.protocol.message_header import MessageHeader

from by_framework_langgraph.adapter import LangGraphAdapter


def _make_mock_context(session_id: str = "test-session"):
    """Create a mock AgentContext."""
    ctx = MagicMock()
    ctx.session_id = session_id
    ctx.redis = AsyncMock()
    ctx.emit_chunk = AsyncMock()
    ctx.ask_user = AsyncMock()
    ctx.call_agent = AsyncMock()
    return ctx


def _make_header(**kwargs):
    """Create a MessageHeader with default values overridden by kwargs."""
    defaults = {
        "message_id": "msg-001",
        "session_id": "sess-001",
        "trace_id": "trace-001",
    }
    defaults.update(kwargs)
    return MessageHeader(**defaults)


class TestLangGraphAdapterInit:
    """Tests for LangGraphAdapter initialization."""

    def test_default_thread_id_uses_session_id(self):
        """Verify adapter falls back to session_id when no thread_id given."""
        ctx = _make_mock_context(session_id="my-session")
        graph = MagicMock()
        adapter = LangGraphAdapter(graph, ctx)
        assert adapter._thread_id == "my-session"  # pylint: disable=protected-access

    def test_custom_thread_id(self):
        """Verify adapter uses explicit thread_id when provided."""
        ctx = _make_mock_context()
        graph = MagicMock()
        adapter = LangGraphAdapter(graph, ctx, thread_id="custom-thread")
        assert adapter._thread_id == "custom-thread"  # pylint: disable=protected-access


class TestIsGraphSuspended:
    """Tests for _is_graph_suspended."""

    def test_suspended_when_next_is_nonempty(self):
        """Verify graph is detected as suspended when snapshot.next is non-empty."""
        ctx = _make_mock_context()
        graph = MagicMock()
        snapshot = MagicMock()
        snapshot.next = ("tools",)
        graph.get_state.return_value = snapshot

        adapter = LangGraphAdapter(graph, ctx)
        assert adapter._is_graph_suspended() is True  # pylint: disable=protected-access

    def test_not_suspended_when_next_is_empty(self):
        """Verify graph is not suspended when snapshot.next is empty."""
        ctx = _make_mock_context()
        graph = MagicMock()
        snapshot = MagicMock()
        snapshot.next = ()
        graph.get_state.return_value = snapshot

        adapter = LangGraphAdapter(graph, ctx)
        assert adapter._is_graph_suspended() is False  # pylint: disable=protected-access

    def test_not_suspended_on_error(self):
        """Verify graph is not suspended when get_state raises an exception."""
        ctx = _make_mock_context()
        graph = MagicMock()
        graph.get_state.side_effect = RuntimeError("no checkpoint")

        adapter = LangGraphAdapter(graph, ctx)
        assert adapter._is_graph_suspended() is False  # pylint: disable=protected-access


class TestAdapterRun:
    """Tests for adapter.run() dispatching."""

    @pytest.mark.asyncio
    async def test_resume_command_calls_handle_resume(self):
        """Verify ResumeCommand resumes the graph and returns the final answer."""
        ctx = _make_mock_context()
        graph = MagicMock()
        graph.ainvoke = AsyncMock(
            return_value={"messages": [MagicMock(content="done")]}
        )
        # Not suspended
        snapshot = MagicMock()
        snapshot.next = ()
        graph.get_state.return_value = snapshot

        adapter = LangGraphAdapter(graph, ctx, stream=False)

        cmd = ResumeCommand(
            header=_make_header(),
            content="user reply",
            status="COMPLETED",
        )
        result = await adapter.run(cmd)

        # Should have called ainvoke (not with initial state)
        graph.ainvoke.assert_called_once()
        assert result == "done"

    @pytest.mark.asyncio
    async def test_initial_command_calls_handle_initial(self):
        """Verify AskAgentCommand invokes the graph with initial input."""
        ctx = _make_mock_context()
        graph = MagicMock()
        graph.ainvoke = AsyncMock(
            return_value={"messages": [MagicMock(content="hello")]}
        )
        snapshot = MagicMock()
        snapshot.next = ()
        graph.get_state.return_value = snapshot

        adapter = LangGraphAdapter(graph, ctx, stream=False)

        cmd = AskAgentCommand(
            header=_make_header(),
            content="write a poem",
        )
        result = await adapter.run(cmd)

        graph.ainvoke.assert_called_once()
        assert result == "hello"

    @pytest.mark.asyncio
    async def test_returns_queued_when_suspended(self):
        """Verify a suspended graph returns QUEUED status dict."""
        ctx = _make_mock_context()
        graph = MagicMock()
        graph.ainvoke = AsyncMock(
            return_value={"messages": [MagicMock(content="partial")]}
        )
        snapshot = MagicMock()
        snapshot.next = ("tools",)
        graph.get_state.return_value = snapshot

        adapter = LangGraphAdapter(graph, ctx, stream=False)

        cmd = AskAgentCommand(
            header=_make_header(),
            content="write a poem",
        )
        result = await adapter.run(cmd)

        assert isinstance(result, dict)
        assert result["status"] == "QUEUED"
