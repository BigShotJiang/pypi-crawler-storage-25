# 基于 ContextVar 的内部消息树设计方案

## 1. 背景与动机
在多智能体或复杂的单智能体执行逻辑中，线性的日志输出（Linear Logs）无法清晰地展示任务的因果关系和逻辑层级。为了在 UI 上实现自动化的“推理日志嵌套”和“子步骤折叠”，我们需要在 `AgentContext` 中建立一套自动化的层级消息管理机制。

**现有问题**：
- 手动传递 `message_id` 和 `parent_message_id` 极其繁琐。
- 开发者容易忘记透传 ID，导致消息树断裂或嵌套错误。
- 难以支持深层嵌套（如“解析任务 -> 处理文件 -> 读取元数据”）。

## 2. 技术方案：异步感知的 ID 追踪

### A. Context-Aware 执行上下文
利用 Python 的 `contextvars` 模块（Python 3.7+ 标准库），我们在异步执行的“协程链”中维护一个局部的 `ContextVar`。该变量存储当前正在活跃的消息标识符对 `(current_id, parent_id)`。

### B. 自动化 ID 继承
`AgentContext` 将不再仅依赖于初始化时传入的静态 ID，而是动态从 `ContextVar` 中获取：
- **`message_id`**: 永远指向当前上下文中最内层的执行节点 ID。
- **`parent_message_id`**: 永远指向当前节点的父级 ID。

### C. 核心 API: `sub_step`
提供一个异步上下文管理器 `sub_step(title: str)`。

**逻辑流程**：
1. **生成子 ID**：通过 `generate_message_id()` 获取一个新的 ID（如 `sub_01`）。
2. **发射标题**：自动调用 `emit_state` 发送步骤名称，指定其 ID 为 `sub_01`，父级为当前 `message_id`。
3. **切换上下文**：将 `ContextVar` 更新为 `(sub_01, 原 message_id)`。
4. **用户执行**：在大括号内，后续所有的 `emit_chunk` 等调用默认使用 `sub_01`。
5. **自动恢复**：`with` 块结束时，`ContextVar` 自动回溯到父级状态。

## 3. 使用示例

### 场景：文档解析与分析
```python
async def process_command(self, command, context: AgentContext):
    await context.emit_chunk("收到请求，准备处理文档。")

    # 自动开启一个名为“解析文档”的子节点
    async with context.sub_step("解析文档"):
        await context.emit_chunk("正在读取文件...")  # 自动归类在“解析文档”下
        await context.emit_chunk("内容长度：5000 字符")

        # 支持深度嵌套
        async with context.sub_step("抽取摘要"):
            await context.emit_chunk("正致力于 LLM 总结...") # 自动归类在“抽取摘要”下

    await context.emit_chunk("解析任务全部完成。") # 自动跳回主节点
```

## 4. 实现细节 (AgentContext 修改)

```python
from contextvars import ContextVar
from contextlib import asynccontextmanager

# 定义模块级上下文变量
_current_trace_context = ContextVar("current_trace_context", default=(None, None))

class AgentContext:
    def __init__(self, message_id, parent_message_id, ...):
        # 初始化时将基础 ID 注入当前上下文
        self._token = _current_trace_context.set((message_id, parent_message_id))

    @property
    def message_id(self):
        return _current_trace_context.get()[0] or self._initial_message_id

    @property
    def parent_message_id(self):
        return _current_trace_context.get()[1] or self._initial_parent_message_id

    @asynccontextmanager
    async def sub_step(self, title: str):
        sub_id = self.generate_message_id()
        parent_id = self.message_id

        # 1. 产生标题节点
        await self.emit_state(title, message_id=sub_id, parent_message_id=parent_id)

        # 2. 下钻 ID 栈
        token = _current_trace_context.set((sub_id, parent_id))
        try:
            yield sub_id, parent_id
        finally:
            # 3. 恢复 ID 栈
            _current_trace_context.reset(token)
```

## 5. 预期效果
- **开发者无感**：无需在函数间透传各种 ID 字符串。
- **UI 自动嵌套**：前端 SSE 接收到的 `orderId` 和 `parentOrderId` 链路完整，自动呈现嵌套树状图。
- **线程安全**：基于 `contextvars`，完美支持异步并发任务间的 ID 隔离。
