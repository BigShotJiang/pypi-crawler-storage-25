# Knowledge Client Integration Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Integrate the external knowledge management service into the SDK through a typed async client that wraps the documented HTTP APIs.

**Architecture:** Add a small `KnowledgeClient` on top of `httpx.AsyncClient` and keep all remote knowledge-service semantics in that client layer. Use typed dataclasses for request results, centralize envelope parsing and error handling, and export the client from the package root so SDK users can consume the remote service directly.

**Tech Stack:** Python 3.12+, `httpx`, dataclasses, pytest, pytest-asyncio.

---

### Task 1: Create failing client tests

**Files:**
- Create: `tests/client/test_knowledge_client.py`

**Step 1: Write the failing tests**

Cover:
- `create_knowledge_base` posts to `/api/v1/knowledge-bases`
- `write_text` uploads multipart form data to `/api/v1/write`
- `fetch_lines` posts to `/api/v1/fetch`
- `list_dir` posts to `/api/v1/list_dir`
- `search` posts to `/api/v1/knowledge-items/search`
- envelope errors raise a typed exception

**Step 2: Run test to verify it fails**

Run: `.venv/bin/pytest tests/client/test_knowledge_client.py -v`
Expected: FAIL because the client does not exist yet.

### Task 2: Implement minimal remote client

**Files:**
- Create: `src/by_framework/knowledge/client.py`
- Create: `src/by_framework/knowledge/models.py`
- Create: `src/by_framework/knowledge/exceptions.py`
- Modify: `src/by_framework/knowledge/__init__.py`
- Modify: `src/by_framework/__init__.py`

**Step 1: Define typed models**

Add dataclasses for:
- knowledge base record
- write result
- directory entry
- search item and search metadata

**Step 2: Implement `KnowledgeClient`**

Implement:
- constructor with `base_url`, optional auth headers, timeout, injected `httpx.AsyncClient`
- async methods for the five documented APIs
- shared envelope parsing and typed exception raising
- async close support

**Step 3: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/client/test_knowledge_client.py -v`
Expected: PASS

### Task 3: Clean up wrong-direction code and test discovery

**Files:**
- Modify: `pyproject.toml`

**Step 1: Remove local-provider-only test discovery**

Ensure pytest no longer references `tests/knowledge`.

**Step 2: Run targeted verification**

Run: `.venv/bin/pytest tests/client/test_knowledge_client.py tests/client/test_client.py -v`
Expected: PASS
