# Agent Type 在线检测与严格发送方案

> **给后续实现用：** 按这份方案分阶段落地，先解决“worker 已经下线但仍然还能发送”的核心问题，再逐步补齐观测和细节优化。

## 1. 背景与核心问题

当前实现里，worker 的在线判断依赖：

- 心跳间隔：`10s`
- 容忍时间：`30s`

发送前会先探测某个 `agent_type` 是否存在 live worker，如果存在就允许发送。

这个方案的最大问题是：

**worker 如果刚发完一次 heartbeat 就崩了，在接下来最多 30 秒内，系统仍然会认为它在线。**

于是就会出现用户最担心的场景：

1. worker 实际已经挂了
2. 前端或上游 agent 发消息时，探测仍然通过
3. 消息被写入 `agent_type` 的控制队列
4. 但实际没有任何在线 worker 能消费

从 AI Agent 对话框架的语义来看，这不是理想行为。

这个框架更符合下面这条原则：

**只要目标 worker 不在线，就应该视为不可用，发送侧立刻报错。**

这条规则应该同时适用于：

- 前端 -> agent
- agent -> 子 agent

也就是说，这里不应该把队列当成“离线缓冲区”，而应该把它当成“在线 agent 的传输通道”。

---

## 2. 设计目标

这次改造的目标非常明确：

1. **worker 下线后，要尽可能快地从“可发送”状态切换到“不可发送”状态。**
2. **正常停机时，要立即摘除在线状态，而不是等超时。**
3. **agent_type 的可用性判断只认“当前在线 worker”，不认历史注册记录。**
4. **前端调用和 agent-to-agent 调用都采用严格发送语义。**
5. **在网络轻微抖动下，不要因为阈值设置太激进而频繁误判。**

---

## 3. 推荐方案总览

### 3.1 保留 membership，但不再用它代表在线

继续保留这两类 Redis 集合：

- `worker_declared_agent_types(worker_id)`
- `agent_type_members(agent_type)`

它们的职责只是：

- 记录某个 worker 理论上支持哪些 `agent_type`
- 记录某个 `agent_type` 理论上有哪些成员 worker

**membership 只表示归属，不表示在线。**

### 3.2 在线判断改成 lease 模型

新增每个 worker 的在线租约 key，例如：

- `worker_online_lease(worker_id)`

worker 每次 heartbeat 时刷新这个 key 的 TTL，例如：

- `SET key "1" EX 15`

这表示：

- 这个 worker 的“在线证明”只在未来 15 秒内有效
- 如果 worker 挂掉且不再 heartbeat，这个在线证明会自动过期

相比“最后心跳时间 + 30 秒阈值判断”，lease 模型更直接，也更贴近“在线才能对话”的业务语义。

### 3.3 发送前只认在线 lease

发送到 `agent_type` 时：

1. 读取 `agent_type_members(agent_type)`
2. 遍历成员 worker
3. 只保留那些 `worker_online_lease(worker_id)` 仍然存在的 worker
4. 如果结果为空，则直接报错，不发送

也就是说：

- 有在线 worker：允许发送
- 没有在线 worker：立即失败

### 3.4 正常退出时主动摘除

worker 正常 shutdown 时，不应该等 TTL 自然过期，而是应该立即：

1. 停止 heartbeat loop
2. 删除自己的 `worker_online_lease`
3. 从活跃索引中摘除自己
4. 清理 membership
5. 释放 worker lock

这样可以把正常停机的误判窗口降到接近 0。

---

## 4. 为什么单纯缩短阈值不够

如果只是把现在的：

- heartbeat = `10s`
- threshold = `30s`

改成：

- heartbeat = `10s`
- threshold = `10s`

会出现新的问题：

- Redis 一次瞬时阻塞
- event loop 卡顿
- 轻微网络抖动

都可能让健康 worker 因为 heartbeat 稍微晚一点点就被误判为离线。

所以真正该做的，不是“把阈值设得和心跳一样”，而是：

- 用更短的 lease 缩小误判窗口
- 但 lease TTL 仍然要大于 heartbeat 间隔，留出合理缓冲

---

## 5. 推荐默认参数

对于当前 AI Agent 场景，推荐改成：

- `heartbeat_interval_seconds = 5`
- `heartbeat_lease_ttl_seconds = 15`

这套配置的含义是：

- worker 每 5 秒刷新一次在线租约
- 如果 worker 崩了，最多 15 秒后就会被判定离线
- 即使丢 1 到 2 次 heartbeat，也不会立刻误杀

这比原先 `10s / 30s` 更适合“目标 agent 必须在线才能对话”的场景。

如果后面发现 Redis 压力偏大，也可以退一步配置成：

- `heartbeat_interval_seconds = 6`
- `heartbeat_lease_ttl_seconds = 18`

但原则保持不变：

**lease TTL 应该约等于 heartbeat interval 的 3 倍。**

---

## 6. 新的发送语义

### 6.1 前端到 agent

发送前先检查目标 `agent_type` 是否存在在线 worker：

- 有：发送
- 没有：立即报错

推荐错误码：

- `AGENT_TYPE_UNAVAILABLE`

推荐错误文案：

- `No online worker found for agent_type 'xxx'`

### 6.2 agent 到 agent

`call_agent()` 也采用同样语义：

- 子 agent 有在线 worker：继续调用
- 子 agent 没有在线 worker：立即失败并返回错误

不再允许“子 agent 不在线但先把消息塞进队列”。

### 6.3 direct worker 调试发送

如果显式指定 `target_worker_id`：

- 直接检查该 worker 的在线 lease 是否存在
- 存在则发送到 `worker_ctrl_stream(worker_id)`
- 不存在则立即失败

也就是说，定向调试路径同样是严格在线语义。

---

## 7. Redis 结构调整建议

### 7.1 保留现有结构

继续保留：

- `ACTIVE_WORKERS` zset
- `worker_declared_agent_types(worker_id)` set
- `agent_type_members(agent_type)` set

用途调整为：

- `ACTIVE_WORKERS`
  - 用于观测、排查、查看最后心跳时间
- `membership` 两类 set
  - 用于归属关系维护

### 7.2 新增在线 lease key

新增：

- `worker_online_lease(worker_id)`

用途：

- 发送前的严格在线判断

最终语义变成：

- “在线” 由 lease 决定
- “归属” 由 membership 决定
- “最近一次心跳时间” 由 zset 决定

---

## 8. 代码改造点

### 8.1 `src/by_framework/common/constants.py`

新增：

- `RedisKeys.worker_online_lease(worker_id)`
- worker 侧默认常量：
  - `WORKER_DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 5`
  - `WORKER_DEFAULT_LEASE_TTL_SECONDS = 15`

不要复用 service discovery 的 `SD_*` 常量。

### 8.2 `src/by_framework/common/config.py`

将 worker 配置调整为：

- `heartbeat_interval_seconds`
- `heartbeat_lease_ttl_seconds`

不再依赖单一的 `health_threshold_ms`。

### 8.3 `src/by_framework/core/registry.py`

重点改造：

1. `heartbeat_worker(worker_id)`
   除了继续写 `ACTIVE_WORKERS`，还要刷新 `worker_online_lease(worker_id)`。

2. `check_worker_online(redis, worker_id)`
   改为直接检查 lease 是否存在，而不是用 zset 时间窗口判断。

3. `check_agent_type_online(redis, agent_type)`
   改为：
   - 获取 `agent_type_members(agent_type)`
   - 逐个检查 lease
   - 只返回在线 worker

4. `mark_worker_inactive(worker_id)`
   改为：
   - 删除 lease
   - 从 `ACTIVE_WORKERS` 中移除

### 8.4 `src/by_framework/worker/heartbeat.py`

重点改造：

- heartbeat loop 只负责刷新 lease 和最后心跳时间
- 启动时做一次 membership 注册 + 一次 heartbeat
- 默认间隔改成 5 秒
- heartbeat 时要显式传入 lease TTL

### 8.5 `src/by_framework/worker/worker.py`

`GatewayWorker.heartbeat_interval` 改成读取新的：

- `WorkerConfig.heartbeat_interval_seconds`

并把 lease TTL 传给 `WorkerHeartbeat`。

### 8.6 `src/by_framework/client/client.py`

当前默认已经是“探测后再发送”，这里继续收紧语义：

- `target_worker_id` 路径：
  - 只认 worker lease
- `agent_type` 路径：
  - 只要没有在线 worker，就直接失败

这里可以继续保留 `probe_agent_type=False` 作为低层逃生开关，但不建议上层业务使用。

### 8.7 `src/by_framework/worker/context.py`

`call_agent()` 保持严格语义：

- 子 agent 没有在线 worker 时，直接返回失败

---

## 9. 分阶段落地顺序

### 第一阶段：先解决最核心问题

目标：

- worker 下线后，不再被长时间误判为在线

改动：

1. 新增 `worker_online_lease(worker_id)`
2. heartbeat 改为刷新 lease
3. 在线判断改为检查 lease
4. `mark_worker_inactive()` 删除 lease
5. 发送前探测只认 lease

这是必须优先完成的部分。

### 第二阶段：补充观测和稳态优化

改动：

1. 日志中输出 lease TTL、最近心跳时间
2. 补充监控：
   - online worker 数量
   - agent_type 无在线 worker 的拒绝次数
3. 根据运行情况微调：
   - heartbeat interval
   - lease TTL

### 第三阶段：进一步收敛接口命名

后续可以把：

- `probe_agent_type`

进一步调整为更明确的表达，例如：

- `require_online_worker`

但这不是这次必须做的核心改造。

---

## 10. 测试方案

### 10.1 Registry 测试

需要覆盖：

1. `heartbeat_worker()` 会刷新 lease
2. `check_worker_online()` 只认 lease
3. `check_agent_type_online()` 只返回在线 worker
4. `mark_worker_inactive()` 会删除 lease 并摘掉 zset 记录

目标文件：

- `tests/core/test_registry.py`

### 10.2 Heartbeat 测试

需要覆盖：

1. start 时注册 membership + 刷新 lease
2. loop 中持续刷新 lease
3. 停止后不再继续 heartbeat

目标文件：

- `tests/worker/test_heartbeat.py`

### 10.3 Client 测试

需要覆盖：

1. `agent_type` 没有在线 worker 时发送失败
2. `agent_type` 有在线 worker 时发送成功
3. `target_worker_id` 不在线时发送失败
4. `target_worker_id` 在线时发送成功

目标文件：

- `tests/client/test_client.py`

---

## 11. 方案边界

这套方案可以大幅缩小“worker 已下线但仍能发送”的窗口，但无法在分布式系统里做到绝对 0 窗口。

仍然存在一个极短的竞态：

1. 发送前检查 lease 时，worker 还在线
2. 检查完成后，worker 立刻崩掉
3. 消息仍然可能已经写入 stream

这是无法完全消除的。

但相比当前“最长 30 秒误判窗口”的方案，lease 模型能把风险窗口压缩到大约 `15 秒`，并且正常停机时几乎可以做到立即失效。

对于当前 AI Agent 在线对话场景，这已经是明显更合理的语义。

---

## 12. 成功标准

当满足下面这些条件时，可以认为这次改造达成目标：

1. worker 正常停机后，后续发送立即报错。
2. worker 异常崩溃后，最多约 15 秒内不再被认为在线。
3. `agent_type` 可用性判断只认在线 worker，不认历史 membership。
4. 前端调用和 agent-to-agent 调用都遵循严格在线语义。
5. 相关单测覆盖 lease 刷新、离线摘除、发送拒绝和发送成功场景。
