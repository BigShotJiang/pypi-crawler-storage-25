# ByaiAgentContext Typed Facade Refactor Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Introduce a `ByaiAgentContext` that preserves `AgentContext` runtime behavior while providing stronger Byai-specific typing for worker business code.

**Architecture:** Keep `AgentContext` as the shared runtime implementation and use `ByaiAgentContext` as a thin typed facade on top of it. `GatewayWorker` will gain a context-class hook so `ByaiWorker` can construct `ByaiAgentContext` without duplicating lifecycle or transport behavior.

**Tech Stack:** Python, dataclasses, Protocol-based codec abstraction, pytest, pytest-asyncio

---

### Task 1: Add failing tests for context-class selection and typed facade behavior

**Files:**
- Modify: `tests/worker/test_byai_worker.py`
- Modify: `tests/worker/test_context.py`
- Create or modify: `src/by_framework/worker/byai_context.py`

**Step 1: Write the failing tests**

Add tests that verify:

```python
assert isinstance(context, ByaiAgentContext)
```

when a `ByaiWorker` handles a message, and that `ByaiAgentContext.call_agent(...)` accepts `BaiYingMessage` inputs while preserving the same runtime dispatch behavior as `AgentContext`.

**Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/worker/test_byai_worker.py tests/worker/test_context.py -v`
Expected: FAIL because `ByaiAgentContext` is not wired through `ByaiWorker` yet.

**Step 3: Write minimal implementation**

Create a thin `ByaiAgentContext` subclass that:
- Inherits from `AgentContext`
- Reuses the same `content_codec` runtime path
- Narrows high-value method signatures such as `call_agent(...)`
- Does not reimplement message transport logic

**Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/worker/test_byai_worker.py tests/worker/test_context.py -v`
Expected: PASS

### Task 2: Wire context-class selection through workers

**Files:**
- Modify: `src/by_framework/worker/worker.py`
- Modify: `src/by_framework/worker/byai_worker.py`
- Modify: `src/by_framework/worker/__init__.py`
- Modify: `src/by_framework/__init__.py`

**Step 1: Add worker hook**

Add a default hook to `GatewayWorker`:

```python
def get_context_class(self) -> type[AgentContext]:
    return AgentContext
```

and use it when constructing the runtime context inside `_handle_message(...)`.

**Step 2: Override in ByaiWorker**

Return `ByaiAgentContext` from `ByaiWorker.get_context_class()`.

**Step 3: Preserve existing behavior**

Do not change how the worker:
- initializes runtime state
- sets current command
- dispatches callbacks
- persists resume data

Only the concrete context class should change for Byai workers.

**Step 4: Verify**

Run: `uv run pytest tests/worker/test_gateway_worker.py tests/worker/test_byai_worker.py tests/worker/test_runner.py -v`
Expected: PASS

### Task 3: Tighten public typing without changing semantics

**Files:**
- Create: `src/by_framework/worker/byai_context.py`
- Modify: `src/by_framework/core/protocol/__init__.py`
- Modify: `src/by_framework/__init__.py`

**Step 1: Define typed aliases**

Add a Byai content alias such as:

```python
ByaiContent = str | BaiYingMessage | list[BaiYingMessage]
```

and optionally a typed task dataclass for group dispatch if the API benefits from it.

**Step 2: Narrow typed facade signatures**

Implement typed wrappers for:
- `call_agent(...)`
- optional `dispatch_group(...)`

These wrappers should delegate directly to `super()` and keep runtime behavior unchanged.

**Step 3: Export the new typed context**

Expose `ByaiAgentContext` through worker package exports and top-level package exports.

**Step 4: Verify**

Run: `uv run pytest tests/worker/test_context.py tests/worker/test_byai_worker.py -v`
Expected: PASS

### Task 4: Run focused regression tests

**Files:**
- Test: `tests/worker/test_context.py`
- Test: `tests/worker/test_byai_worker.py`
- Test: `tests/worker/test_gateway_worker.py`
- Test: `tests/worker/test_runner.py`
- Test: `tests/client/test_client.py`
- Test: `tests/core/protocol/test_byai_codec.py`

**Step 1: Run focused suite**

Run:

```bash
uv run pytest \
  tests/worker/test_context.py \
  tests/worker/test_byai_worker.py \
  tests/worker/test_gateway_worker.py \
  tests/worker/test_runner.py \
  tests/client/test_client.py \
  tests/core/protocol/test_byai_codec.py -q
```

Expected: PASS

**Step 2: Optional docs update**

If helpful, add a short README example showing:
- `class MyWorker(ByaiWorker)`
- `async def process_command(self, command, context: ByaiAgentContext): ...`

**Step 3: Record any remaining follow-up**

If resume semantics still need stronger typing, note them separately rather than overloading this refactor.
