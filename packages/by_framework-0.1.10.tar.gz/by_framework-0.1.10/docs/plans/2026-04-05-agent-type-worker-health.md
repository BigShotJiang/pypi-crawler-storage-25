# Agent Type Worker Health Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace the current single-threshold live-worker probe with a health-state model and send policy that handles real worker crashes and transient network jitter without unnecessary message rejection.

**Architecture:** Keep the current Redis-backed worker membership and heartbeat model, but change health evaluation from binary `alive/dead` to three states: `HEALTHY`, `SUSPECT`, and `DEAD`. Sender-side admission control becomes policy-driven: external sends default to healthy-first with degraded fallback, while internal async flows can optionally enqueue even when no healthy worker exists.

**Tech Stack:** Python, Redis Streams, Redis ZSET/SET, asyncio, pytest

---

## Problem Statement

Current behavior:

1. Worker membership is static:
   - `worker_declared_agent_types(worker_id)`
   - `agent_type_members(agent_type)`

2. Worker liveness is dynamic:
   - `ACTIVE_WORKERS` ZSET stores `worker_id -> last_heartbeat_ms`

3. Sender-side probe is binary:
   - `now - last_heartbeat <= health_threshold_ms` => alive
   - otherwise dead

Current defaults:

- `heartbeat_interval = 10s`
- `health_threshold = 30s`

This creates two real problems:

1. **Real crash detection is delayed**
   - If a worker crashes right after a heartbeat, the sender may still consider it alive for up to ~30 seconds.
   - New messages can still be accepted for an `agent_type` that no longer has a functioning consumer.

2. **Single-threshold design cannot distinguish jitter from failure**
   - If heartbeat interval and tolerance are too close, transient delays cause false negatives.
   - If tolerance is widened too much, real failures are detected too slowly.

Root cause:

- A single threshold is trying to solve two different goals:
  - tolerate heartbeat jitter
  - detect real worker failure quickly

That is why the current design is inherently unstable under real-world network and scheduler variability.

---

## Target Design

### 1. Health state becomes tri-state

For each worker, derive health from the elapsed time since its last heartbeat:

- `HEALTHY`
- `SUSPECT`
- `DEAD`

Recommended default thresholds when `heartbeat_interval = 10s`:

- `healthy`: `age <= 25s`
- `suspect`: `25s < age <= 45s`
- `dead`: `age > 45s`

This means:

- one late heartbeat does not immediately mark the worker unavailable
- a truly crashed worker still transitions to dead in bounded time

### 2. Agent type health is aggregated from worker health

For a given `agent_type`, partition members into:

- `healthy_workers`
- `suspect_workers`
- `dead_workers`
- `declared_workers`

Sender-side routing should use these partitions rather than a single `has_agent_type(...) -> bool`.

### 3. Sending becomes policy-driven

Introduce explicit send policies instead of hardwiring one binary probe behavior.

Recommended policies:

- `STRICT_HEALTHY`
  - allow send only if there is at least one healthy worker

- `ALLOW_SUSPECT`
  - allow send if there is at least one healthy or suspect worker
  - preferred default for user-facing client requests

- `QUEUE_ANYWAY`
  - allow send as long as the `agent_type` is declared by at least one worker, even if all are currently dead
  - preferred for internal async flows that can tolerate delayed execution

### 4. Graceful stop remains immediate

Normal shutdown should still:

1. stop heartbeat
2. mark worker inactive immediately
3. unregister membership
4. release worker lock

Crash recovery should still rely on heartbeat timeout progression, not graceful cleanup.

---

## Concrete Changes

### Configuration Changes

Modify `src/by_framework/common/config.py` and related config readers.

Replace the single mental model:

- `heartbeat_interval`
- `health_threshold_ms`

With:

- `heartbeat_interval_seconds: int = 10`
- `healthy_after_miss_seconds: int = 25`
- `dead_after_miss_seconds: int = 45`
- `heartbeat_jitter_ratio: float = 0.1`
- `default_send_policy: str = "ALLOW_SUSPECT"`

Recommended validation rules:

- `heartbeat_interval_seconds >= 1`
- `healthy_after_miss_seconds > heartbeat_interval_seconds`
- `dead_after_miss_seconds > healthy_after_miss_seconds`
- `dead_after_miss_seconds >= 3 * heartbeat_interval_seconds`
- `0 <= heartbeat_jitter_ratio <= 0.25`

### Registry API Changes

Modify `src/by_framework/core/registry.py`.

Add a worker health enum or string literal set:

```python
WorkerHealth = Literal["HEALTHY", "SUSPECT", "DEAD", "UNKNOWN"]
```

Add worker-level health inspection:

```python
async def get_worker_health(
    self,
    worker_id: str,
    healthy_after_ms: int,
    dead_after_ms: int,
) -> str:
    ...
```

Add agent-type-level health inspection:

```python
async def get_agent_type_health(
    self,
    agent_type: str,
    healthy_after_ms: int,
    dead_after_ms: int,
) -> dict[str, Any]:
    ...
```

Expected result shape:

```python
{
    "agent_type": "langgraph_agent",
    "declared_workers": ["w1", "w2"],
    "healthy_workers": ["w1"],
    "suspect_workers": ["w2"],
    "dead_workers": [],
    "status": "HEALTHY",
}
```

Aggregation rules:

- if `healthy_workers` non-empty => `status = "HEALTHY"`
- elif `suspect_workers` non-empty => `status = "DEGRADED"`
- elif `declared_workers` non-empty => `status = "UNAVAILABLE"`
- else => `status = "UNREGISTERED"`

Keep convenience wrappers, but make them call the new model:

- `has_agent_type(...)` should become a thin compatibility wrapper
- it should not remain the primary business primitive

### Sender Routing Changes

Modify:

- `src/by_framework/client/client.py`
- `src/by_framework/worker/context.py`

Introduce explicit send policy parameters:

For `GatewayClient.send_message(...)`:

```python
send_policy: str = "ALLOW_SUSPECT"
```

For `AgentContext.call_agent(...)`:

```python
send_policy: str = "QUEUE_ANYWAY"
```

Suggested decision logic:

#### `STRICT_HEALTHY`

- require `healthy_workers`
- if none => reject send with `AGENT_TYPE_NO_HEALTHY_WORKER`

#### `ALLOW_SUSPECT`

- allow if `healthy_workers` or `suspect_workers`
- if only suspect workers exist, log warning and return a response flag such as:

```python
degraded_delivery=True
```

#### `QUEUE_ANYWAY`

- allow if `declared_workers` exists at all
- if no declared workers => reject
- if only dead workers exist => enqueue and log degraded condition

This is important because Redis Stream is a durable queue. “No currently healthy worker” is not always a reason to reject the message.

### Error Code Changes

Extend `src/by_framework/core/protocol/responses.py`.

Instead of only one unavailable error, distinguish:

- `AGENT_TYPE_UNREGISTERED`
- `AGENT_TYPE_NO_HEALTHY_WORKER`
- `AGENT_TYPE_ONLY_DEAD_WORKERS`
- `WORKER_NOT_ALIVE`

This improves operational diagnosis and reduces ambiguity.

### Heartbeat Loop Improvements

Modify `src/by_framework/worker/heartbeat.py`.

Add jitter:

```python
sleep_seconds = interval * random.uniform(1 - jitter, 1 + jitter)
```

Recommended:

- `interval = 10s`
- `jitter = 0.1`
- effective sleep ~ `9s` to `11s`

This avoids synchronized heartbeat spikes from many workers starting together.

Also refresh heartbeat opportunistically:

- after successful message processing in `WorkerRunner`
- after worker startup hooks complete

This reduces false suspicion for very busy workers whose event loop is active but whose heartbeat sleep aligns poorly with load spikes.

### Optional Cleanup Job

Optional but recommended:

Add a periodic maintenance task or admin command that prunes stale membership for workers that:

- have no heartbeat for a long retention period, e.g. `24h`
- and no lock
- and no active executions

This is not required for correctness, but keeps registry state clean.

---

## Default Policy Recommendation

### For external client requests

Use:

- `send_policy = "ALLOW_SUSPECT"`

Reason:

- user-facing traffic should not fail on minor jitter
- but it should still fail when an `agent_type` is genuinely absent
- degraded-but-probably-okay delivery is acceptable

### For internal agent-to-agent calls

Use:

- `send_policy = "QUEUE_ANYWAY"`

Reason:

- internal workflows are often asynchronous
- temporary worker gaps should not necessarily lose work
- durable queue semantics are usually preferable to hard reject

### For admin/debug strict flows

Use:

- `send_policy = "STRICT_HEALTHY"`

Reason:

- tooling and diagnostics often need sharper correctness guarantees

---

## Failure Scenario Analysis

### Scenario A: worker truly crashes

Assumptions:

- heartbeat interval = 10s
- healthy threshold = 25s
- dead threshold = 45s

Timeline:

1. worker sends heartbeat at `t=0`
2. worker crashes at `t=1`
3. sender checks at `t=8`: worker still `HEALTHY`
4. sender checks at `t=28`: worker becomes `SUSPECT`
5. sender checks at `t=46`: worker becomes `DEAD`

Outcome:

- crash is not hidden forever
- a brief grace period exists
- jitter and true failure are separated

### Scenario B: network jitter delays heartbeat

Assumptions:

- heartbeat interval = 10s
- one heartbeat arrives late at `t=27`

Outcome under current binary 10/10 design:

- worker flips dead incorrectly

Outcome under proposed tri-state design:

- worker may enter `SUSPECT`
- sender with `ALLOW_SUSPECT` continues to send
- false rejection is avoided

### Scenario C: agent type has only one worker and it dies

Behavior with `STRICT_HEALTHY`:

- new requests eventually fail after dead threshold

Behavior with `QUEUE_ANYWAY`:

- requests continue to enter the queue
- they remain pending until a new worker appears

This must be a policy choice, not a hardcoded side effect.

---

## API Design Recommendations

### GatewayClient

Recommended signature:

```python
async def send_message(
    self,
    target_agent_type: str,
    session_id: str,
    content: Any,
    *,
    send_policy: str = "ALLOW_SUSPECT",
    target_worker_id: str | None = None,
    check_target_worker_alive: bool = True,
    ...
) -> SendMessageResponse:
    ...
```

Rules:

- if `target_worker_id` is provided:
  - route directly to worker stream
  - ignore agent-type health policy
  - optionally check worker liveness

- if `target_worker_id` is absent:
  - route by `agent_type`
  - use send policy against aggregated health result

### AgentContext

Recommended signature:

```python
async def call_agent(
    self,
    target_agent_type: str,
    content: Any,
    *,
    send_policy: str = "QUEUE_ANYWAY",
    ...
) -> dict:
    ...
```

This keeps external and internal default behavior intentionally different.

---

## Migration Plan

### Phase 1: Add new health model without breaking old behavior

**Files:**
- Modify: `src/by_framework/common/config.py`
- Modify: `src/by_framework/core/registry.py`
- Test: `tests/core/test_registry.py`

**Step 1: Write the failing tests**

Add tests for:

- worker health transitions to `HEALTHY`, `SUSPECT`, `DEAD`
- agent type health aggregates correctly
- healthy beats suspect beats dead in status derivation

**Step 2: Run tests to verify they fail**

Run:

```bash
./.venv/bin/pytest tests/core/test_registry.py -q
```

Expected: missing new API failures

**Step 3: Implement minimal health APIs**

Add:

- `get_worker_health(...)`
- `get_agent_type_health(...)`

Keep old `has_agent_type(...)` working for now.

**Step 4: Run tests to verify they pass**

Run:

```bash
./.venv/bin/pytest tests/core/test_registry.py -q
```

**Step 5: Commit**

```bash
git add src/by_framework/common/config.py src/by_framework/core/registry.py tests/core/test_registry.py
git commit -m "feat: add tri-state worker health model"
```

---

### Phase 2: Add sender-side send policies

**Files:**
- Modify: `src/by_framework/client/client.py`
- Modify: `src/by_framework/worker/context.py`
- Modify: `src/by_framework/core/protocol/responses.py`
- Test: `tests/client/test_client.py`
- Test: `tests/worker/test_context.py`

**Step 1: Write failing tests**

Add tests for:

- `STRICT_HEALTHY` rejects suspect-only pools
- `ALLOW_SUSPECT` allows suspect-only pools
- `QUEUE_ANYWAY` enqueues when only dead-but-declared workers exist
- direct worker routing ignores agent-type send policy

**Step 2: Run tests to verify they fail**

Run:

```bash
./.venv/bin/pytest tests/client/test_client.py tests/worker/test_context.py -q
```

**Step 3: Implement policy routing**

Make sender routing depend on `get_agent_type_health(...)` instead of `has_agent_type(...)`.

**Step 4: Run tests to verify they pass**

Run:

```bash
./.venv/bin/pytest tests/client/test_client.py tests/worker/test_context.py -q
```

**Step 5: Commit**

```bash
git add src/by_framework/client/client.py src/by_framework/worker/context.py src/by_framework/core/protocol/responses.py tests/client/test_client.py tests/worker/test_context.py
git commit -m "feat: add policy-driven agent type admission control"
```

---

### Phase 3: Improve heartbeat robustness

**Files:**
- Modify: `src/by_framework/worker/heartbeat.py`
- Modify: `src/by_framework/worker/runner.py`
- Test: `tests/worker/test_heartbeat.py`
- Test: `tests/worker/test_runner.py`

**Step 1: Write failing tests**

Add tests for:

- heartbeat uses jittered sleep window
- startup heartbeat still happens immediately
- runner refreshes heartbeat after processing

**Step 2: Run tests to verify they fail**

Run:

```bash
./.venv/bin/pytest tests/worker/test_heartbeat.py tests/worker/test_runner.py -q
```

**Step 3: Implement jitter and opportunistic refresh**

Keep behavior simple and observable in tests.

**Step 4: Run tests to verify they pass**

Run:

```bash
./.venv/bin/pytest tests/worker/test_heartbeat.py tests/worker/test_runner.py -q
```

**Step 5: Commit**

```bash
git add src/by_framework/worker/heartbeat.py src/by_framework/worker/runner.py tests/worker/test_heartbeat.py tests/worker/test_runner.py
git commit -m "feat: harden worker heartbeat against jitter"
```

---

### Phase 4: Update docs and defaults

**Files:**
- Modify: `README.md`
- Modify: config docs and examples

**Step 1: Document health states**

Explain:

- heartbeat interval
- healthy threshold
- dead threshold
- send policies

**Step 2: Document recommended defaults**

Use:

- `heartbeat_interval = 10s`
- `healthy_after = 25s`
- `dead_after = 45s`
- default client send policy = `ALLOW_SUSPECT`
- default internal call policy = `QUEUE_ANYWAY`

**Step 3: Run targeted regression**

Run:

```bash
./.venv/bin/pytest tests/client/test_client.py tests/core/test_registry.py tests/worker tests/integration/test_callback_flow.py -q
```

**Step 4: Commit**

```bash
git add README.md
git commit -m "docs: document worker health states and send policies"
```

---

## Test Matrix

### Registry Tests

- worker transitions from healthy to suspect to dead over time
- agent type with mixed worker states aggregates correctly
- dead workers remain declared but are not counted as healthy

### Client Tests

- no workers declared => `AGENT_TYPE_UNREGISTERED`
- only dead workers + strict policy => reject
- only suspect workers + allow-suspect policy => accept
- direct worker route checks worker liveness independently

### Worker Tests

- heartbeat jitter stays within configured bounds
- graceful shutdown immediately removes active status
- crash still decays naturally to dead over timeout

### Integration Tests

- internal `call_agent(..., send_policy="QUEUE_ANYWAY")` can enqueue during temporary outage
- external client defaults behave predictably during suspect-only windows

---

## Recommended Defaults for Production

- `heartbeat_interval_seconds = 10`
- `healthy_after_miss_seconds = 25`
- `dead_after_miss_seconds = 45`
- `heartbeat_jitter_ratio = 0.1`
- `client default send_policy = "ALLOW_SUSPECT"`
- `AgentContext.call_agent default send_policy = "QUEUE_ANYWAY"`

These defaults are intentionally asymmetric:

- external user requests prefer availability without being too permissive
- internal orchestration prefers eventual execution through the queue

---

## Success Criteria

The solution is complete when:

1. A late heartbeat does not immediately make an otherwise healthy worker unsendable.
2. A truly crashed worker eventually becomes unsendable within a bounded time window.
3. Sender behavior is explicit and policy-driven, not hardcoded around one binary threshold.
4. Direct worker routing remains independent from agent-type routing.
5. Queue-backed internal workflows can choose durability over immediate rejection.
6. Tests demonstrate the difference between healthy, suspect, and dead states.
