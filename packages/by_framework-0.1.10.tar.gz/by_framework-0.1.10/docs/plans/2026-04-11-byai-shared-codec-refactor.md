# Byai Shared Codec Refactor Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Extract Byai message serialization into a shared codec, add worker-side decoding through a `ByaiWorker`, and keep existing business `process_command()` implementations unchanged.

**Architecture:** Keep the wire protocol unchanged as `str | list[dict]` in command dataclasses, then add a shared Byai codec that converts between protocol payloads and `BaiYingMessage` domain objects. `ByaiGatewayClient` will serialize through the shared codec before enqueueing commands, while `ByaiWorker` will decode command content before invoking the existing `process_command()` method implemented by business workers.

**Tech Stack:** Python, dataclasses, pytest, pytest-asyncio, Redis-stream-backed command transport

---

### Task 1: Add failing tests for shared Byai codec behavior

**Files:**
- Create: `tests/core/protocol/test_byai_codec.py`
- Modify: `src/by_framework/core/protocol/__init__.py`
- Modify: `src/by_framework/__init__.py`

**Step 1: Write the failing test**

```python
def test_serialize_single_baiying_message_to_wire_format():
    message = BaiYingMessage(
        role=BaiYingMessageRole.USER,
        content=MessageContent(
            text="hello",
            files=[MessageFile(fileId=1, fileUrl="u", fileType="txt", fileName="a")],
            resources=[Resource(resourceId="r1", resourceName="doc", resourceType="file")],
        ),
    )

    payload = serialize_byai_content(message)

    assert payload == [
        {
            "role": "user",
            "content": {
                "text": "hello",
                "files": [
                    {"fileId": 1, "fileUrl": "u", "fileType": "txt", "fileName": "a"},
                ],
                "resources": [
                    {
                        "resourceId": "r1",
                        "resourceName": "doc",
                        "resourceType": "file",
                        "id": "",
                        "path": "",
                        "resourceDesc": "",
                        "resourceMetaData": {},
                    },
                ],
            },
        }
    ]
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/core/protocol/test_byai_codec.py -v`
Expected: FAIL because shared codec functions do not exist yet.

**Step 3: Write minimal implementation**

Create a shared codec module with:

```python
def serialize_byai_content(content): ...

def deserialize_byai_content(content): ...
```

The implementation must:
- Preserve raw `str`
- Serialize `BaiYingMessage` and `list[BaiYingMessage]` to protocol-safe `list[dict]`
- Deserialize protocol-safe `list[dict]` back to `BaiYingMessage` or `list[BaiYingMessage]`
- Leave non-Byai list payloads untouched for protocol compatibility

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/core/protocol/test_byai_codec.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add tests/core/protocol/test_byai_codec.py src/by_framework/core/protocol/message.py src/by_framework/core/protocol/__init__.py src/by_framework/__init__.py
git commit -m "feat: add shared byai message codec"
```

### Task 2: Migrate Byai client to use the shared codec

**Files:**
- Modify: `src/by_framework/client/byai_client.py`
- Delete or slim: `src/by_framework/client/interceptors.py`
- Modify: `tests/client/test_client.py`

**Step 1: Write the failing test**

```python
@pytest.mark.asyncio
async def test_byai_client_send_message_serializes_baiying_message():
    client = ByaiGatewayClient(redis_client=mock_redis, registry=mock_registry)

    await client.send_message(
        target_agent_type="test",
        session_id="s1",
        content=BaiYingMessage(role=BaiYingMessageRole.USER, content="hello"),
    )

    data = json.loads(mock_redis.xadd.call_args.args[1]["data"])
    command = command_from_dict(data)
    assert command.content == [{"role": "user", "content": "hello"}]
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/client/test_client.py -k byai_client_send_message_serializes_baiying_message -v`
Expected: FAIL until `ByaiGatewayClient` serializes through the shared codec.

**Step 3: Write minimal implementation**

Update `ByaiGatewayClient` so it serializes content through the shared codec before delegating to `GatewayClient.send_message(...)`. If `interceptors.py` is no longer needed, remove it or leave only a deprecated compatibility shim that calls the codec.

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/client/test_client.py -k byai_client_send_message_serializes_baiying_message -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/by_framework/client/byai_client.py src/by_framework/client/interceptors.py tests/client/test_client.py
git commit -m "refactor: move byai client serialization to shared codec"
```

### Task 3: Add `ByaiWorker` that decodes content before business `process_command()`

**Files:**
- Create: `src/by_framework/worker/byai_worker.py`
- Modify: `src/by_framework/worker/__init__.py`
- Modify: `src/by_framework/__init__.py`
- Create: `tests/worker/test_byai_worker.py`

**Step 1: Write the failing test**

```python
@pytest.mark.asyncio
async def test_byai_worker_process_command_receives_decoded_message():
    class DemoWorker(ByaiWorker):
        def get_agent_types(self):
            return ["demo"]

        async def process_command(self, command, context):
            assert isinstance(command.content, BaiYingMessage)
            assert command.content.role == BaiYingMessageRole.USER
            assert command.content.content == "hello"
            return {"ok": True}
```

**Step 2: Run test to verify it fails**

Run: `uv run pytest tests/worker/test_byai_worker.py -v`
Expected: FAIL because `ByaiWorker` does not exist yet.

**Step 3: Write minimal implementation**

Implement `ByaiWorker` so that:
- It preserves the public `process_command(self, command, context)` entrypoint for subclasses
- It intercepts command handling inside `_handle_message`
- It creates a decoded command copy for `AskAgentCommand` and `ResumeCommand`
- It leaves all non-Byai payloads untouched

**Step 4: Run test to verify it passes**

Run: `uv run pytest tests/worker/test_byai_worker.py -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/by_framework/worker/byai_worker.py src/by_framework/worker/__init__.py src/by_framework/__init__.py tests/worker/test_byai_worker.py
git commit -m "feat: add byai worker content decoding"
```

### Task 4: Verify compatibility with targeted regression tests

**Files:**
- Test: `tests/client/test_client.py`
- Test: `tests/worker/test_gateway_worker.py`
- Test: `tests/core/protocol/test_protocol.py`
- Test: `tests/worker/test_byai_worker.py`

**Step 1: Run focused regression suite**

Run: `uv run pytest tests/core/protocol/test_byai_codec.py tests/client/test_client.py tests/worker/test_byai_worker.py tests/worker/test_gateway_worker.py tests/core/protocol/test_protocol.py -v`

Expected: PASS

**Step 2: Run formatting if needed**

Run: `make format`
Expected: No diff after formatting, or only intentional formatting changes.

**Step 3: Run lint or the smallest useful subset if formatting touched imports**

Run: `make lint`
Expected: PASS, or capture any unrelated pre-existing issues before closing.

**Step 4: Commit**

```bash
git add docs/plans/2026-04-11-byai-shared-codec-refactor.md
git commit -m "docs: add byai codec refactor plan"
```
