# Worker Registry Refactor Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Clarify worker registration, heartbeat, and direct-worker debug routing so capability-group consumption remains the production path while alive checks become the single source of truth for sendability.

**Architecture:** Split static capability membership from dynamic liveness and keep worker ID locking as a separate startup concern. Production sends go to capability streams after an alive-capability gate; direct-to-worker sends remain available for debugging and control flows, but they use worker liveness checks instead of capability routing assumptions.

**Tech Stack:** Python, Redis Streams, Redis consumer groups, pytest, async worker runtime

---

## Design Summary

### Current Problems

1. `register_worker(...)` mixes two concerns:
   - one-time capability membership registration
   - periodic heartbeat refresh

2. `unregister_worker(...)` exists but is not part of the normal shutdown lifecycle, so the real correctness model already depends on heartbeat expiry rather than explicit deregistration.

3. `get_target_worker(...)` selects from the static capability set and can drift from `has_capability(..., check_active=True)`, which already models the real admission rule.

4. The code currently blends two different delivery modes:
   - production capability-group delivery
   - direct worker delivery for debugging or worker-specific control

### Target Model

Keep three separate concepts:

1. **Capability membership**
   - Static relation: which worker can consume which capability.
   - Written on startup, optionally removed on graceful shutdown.

2. **Worker liveness**
   - Dynamic relation: which worker is currently alive enough to receive work.
   - Maintained by heartbeat only.
   - Used by all admission checks and worker selection helpers.

3. **Worker ID lock**
   - Startup exclusivity for a concrete `worker_id`.
   - Independent from capability membership and heartbeat.

### Delivery Semantics

1. **Primary path**
   - User sends to `ctrl_stream(capability)`.
   - Consumer group load-balances across worker instances.
   - Before sending, the client verifies that the capability has at least one alive worker.

2. **Debug path**
   - Caller explicitly targets `worker_id`.
   - Client verifies that the worker is alive.
   - Message is sent to worker-specific stream or control stream.

3. **Control path**
   - Cancel or resume can still route via worker-specific channel when the execution record identifies a specific worker.

---

## API Refactor

### Task 1: Split registry responsibilities into explicit methods

**Files:**
- Modify: `src/by_framework/core/registry.py`
- Test: `tests/core/test_registry.py`

**Step 1: Add explicit static membership API**

Add methods with these responsibilities:

```python
async def register_worker_membership(self, worker_id: str, capabilities: list[str]) -> None:
    ...

async def unregister_worker_membership(self, worker_id: str) -> None:
    ...
```

`register_worker_membership(...)` should:
- ensure `worker_capabilities(worker_id)` contains the declared capabilities
- ensure each `capability_workers(capability)` contains `worker_id`
- not update `ACTIVE_WORKERS`

`unregister_worker_membership(...)` should:
- remove `worker_id` from every declared capability set
- delete `worker_capabilities(worker_id)`
- not change lock state

**Step 2: Add explicit heartbeat API**

Add methods with these responsibilities:

```python
async def heartbeat_worker(self, worker_id: str) -> None:
    ...

async def mark_worker_inactive(self, worker_id: str) -> None:
    ...
```

`heartbeat_worker(...)` should:
- update only `ACTIVE_WORKERS`
- never touch capability membership sets

`mark_worker_inactive(...)` should:
- `zrem` from `ACTIVE_WORKERS`
- be safe to call multiple times

**Step 3: Preserve compatibility temporarily**

Keep `register_worker(...)` and `unregister_worker(...)` as compatibility wrappers during migration:

```python
async def register_worker(self, worker_id: str, capabilities: list[str]) -> None:
    await self.register_worker_membership(worker_id, capabilities)
    await self.heartbeat_worker(worker_id)

async def unregister_worker(self, worker_id: str) -> None:
    await self.mark_worker_inactive(worker_id)
    await self.unregister_worker_membership(worker_id)
```

Document them as transitional APIs to be removed after downstream callers are migrated.

**Step 4: Add tests for each responsibility**

Write focused tests for:
- membership registration does not mark worker alive
- heartbeat does not modify capability sets
- compatibility wrapper still preserves old behavior
- unregister compatibility removes both liveness and membership

**Step 5: Run tests**

Run:

```bash
pytest tests/core/test_registry.py -v
```

**Step 6: Commit**

```bash
git add src/by_framework/core/registry.py tests/core/test_registry.py
git commit -m "refactor: split worker membership and heartbeat"
```

---

### Task 2: Make alive-based selection the only selection rule

**Files:**
- Modify: `src/by_framework/core/registry.py`
- Modify: `src/by_framework/client/client.py`
- Test: `tests/core/test_registry.py`

**Step 1: Add alive worker lookup helpers**

Add:

```python
async def get_alive_workers(
    self,
    capability: str,
    health_threshold_ms: int = RedisKeys.SD_DEFAULT_HEALTH_THRESHOLD_MS,
) -> list[str]:
    ...

async def get_random_alive_worker(
    self,
    capability: str,
    health_threshold_ms: int = RedisKeys.SD_DEFAULT_HEALTH_THRESHOLD_MS,
) -> str | None:
    ...
```

Implementation rule:
- read candidate workers from `capability_workers(capability)`
- intersect with alive workers from `ACTIVE_WORKERS`
- return normalized string IDs only

**Step 2: Re-scope `get_target_worker(...)`**

Choose one of these two options and document it clearly in code:

Recommended:

```python
async def get_target_worker(self, agent_id: str) -> Optional[str]:
    return await self.get_random_alive_worker(agent_id)
```

This preserves compatibility while aligning behavior with your admission model.

**Step 3: Align client send flow**

In `GatewayClient`, ensure:
- capability send checks and capability worker selection both use the same alive-filtered source
- direct worker send uses `is_worker_alive(worker_id)`

If there is a `target_worker_id` parameter path already, treat it as a separate explicit mode rather than falling back through capability selection.

**Step 4: Add tests**

Add tests covering:
- `get_random_alive_worker(...)` skips inactive workers remaining in membership sets
- capability send fails when no alive worker exists
- direct-to-worker send fails when worker is not alive

**Step 5: Run tests**

Run:

```bash
pytest tests/core/test_registry.py tests/common test_client_related -v
```

Replace `test_client_related` with the actual client test path once identified.

**Step 6: Commit**

```bash
git add src/by_framework/core/registry.py src/by_framework/client/client.py tests
git commit -m "refactor: route capability sends through alive workers"
```

---

### Task 3: Separate production send path from debug direct-worker send path

**Files:**
- Modify: `src/by_framework/client/client.py`
- Modify: `src/by_framework/common/constants.py` if new stream helpers are needed
- Test: client send-flow tests

**Step 1: Define explicit send modes in code**

Refactor client send logic so the call path is internally explicit:

```python
if target_worker_id:
    # direct worker mode
else:
    # capability mode
```

Capability mode rules:
- verify capability has alive workers
- publish to `RedisKeys.ctrl_stream(target_agent_type)`
- do not require pre-selecting a worker for correctness

Direct worker mode rules:
- verify `is_worker_alive(target_worker_id)`
- publish to worker-specific stream if available
- persist the chosen `worker_id` in execution metadata for later control operations

**Step 2: Make execution tracking mode-aware**

When saving execution metadata:
- capability mode may keep `worker_id=""` until the message is actually claimed, or store only capability-level routing metadata
- direct worker mode stores the explicit worker immediately

If downstream cancellation requires a worker ID, update tracking at the point where the worker actually starts processing the message.

**Step 3: Add tests**

Add tests for:
- capability mode sends without forcing a concrete worker choice
- debug mode sends only to the targeted worker
- invalid debug worker ID fails fast with a clear error

**Step 4: Run tests**

Run the relevant client and integration tests for send flow.

**Step 5: Commit**

```bash
git add src/by_framework/client/client.py src/by_framework/common/constants.py tests
git commit -m "refactor: separate capability and direct-worker send modes"
```

---

### Task 4: Move worker lifecycle onto the new membership + heartbeat model

**Files:**
- Modify: `src/by_framework/worker/heartbeat.py`
- Modify: `src/by_framework/worker/worker.py`
- Modify: `src/by_framework/worker/runner.py`
- Test: `tests/worker/test_heartbeat.py`
- Test: worker runner lifecycle tests

**Step 1: Update heartbeat startup**

Change startup semantics:

```python
await self.registry.register_worker_membership(self.worker_id, self.capabilities)
await self.registry.heartbeat_worker(self.worker_id)
```

Heartbeat loop should call only:

```python
await self.registry.heartbeat_worker(self.worker_id)
```

This removes repeated `sadd` work on every heartbeat tick.

**Step 2: Update graceful stop**

In shutdown sequence:
- stop heartbeat task
- mark worker inactive immediately
- optionally unregister membership on graceful shutdown

Recommended graceful shutdown order:

```python
await self.worker.stop_heartbeat()
await self.worker.registry.mark_worker_inactive(self.worker.worker_id)
await self.worker.registry.unregister_worker_membership(self.worker.worker_id)
await self.worker.registry.release_worker_id(...)
```

This gives fast disappearance from admission checks and also cleans static indexes when shutdown is orderly.

**Step 3: Keep crash behavior safe**

Do not rely on graceful unregister for correctness.
If a process crashes:
- membership may remain temporarily
- liveness expires naturally
- alive-filtered send logic still behaves correctly

**Step 4: Update tests**

Revise heartbeat tests to assert:
- startup registers membership once
- loop only sends heartbeat updates
- stop marks worker inactive
- optional membership cleanup happens only on graceful shutdown path

**Step 5: Run tests**

Run:

```bash
pytest tests/worker/test_heartbeat.py tests/worker/test_runner.py -v
```

**Step 6: Commit**

```bash
git add src/by_framework/worker/heartbeat.py src/by_framework/worker/worker.py src/by_framework/worker/runner.py tests/worker
git commit -m "refactor: align worker lifecycle with explicit heartbeat semantics"
```

---

### Task 5: Tighten direct-worker semantics for debugging and control flows

**Files:**
- Modify: `src/by_framework/client/client.py`
- Modify: `src/by_framework/worker/runner.py` if execution metadata updates are needed
- Test: client and integration tests

**Step 1: Add a first-class direct worker send helper**

Add a clear helper or internal method such as:

```python
async def _send_to_worker(...)
async def _send_to_capability(...)
```

Make the code self-documenting rather than mixing both paths in one block.

**Step 2: Define how control commands find workers**

Recommended control strategy:
- if an execution record already has `worker_id`, use worker-specific control stream
- if not, fall back to capability-level control only when safe
- for debug-initiated direct sends, worker ID should always be known immediately

**Step 3: Add integration tests**

Add coverage for:
- direct send followed by cancel goes to the same worker
- capability send records worker ID when processing begins
- cancel still works after worker selection is deferred to consumer-group claim time

**Step 4: Run tests**

Run the relevant integration tests, especially callback and control handling suites.

**Step 5: Commit**

```bash
git add src/by_framework/client/client.py src/by_framework/worker/runner.py tests
git commit -m "refactor: formalize direct worker debug routing"
```

---

### Task 6: Remove ambiguity from names and docs

**Files:**
- Modify: `README.md`
- Modify: code docstrings in `src/by_framework/core/registry.py`
- Modify: any developer docs referencing old registration semantics

**Step 1: Update terminology**

Use these terms consistently:
- `membership`: static worker-capability relation
- `heartbeat` or `liveness`: dynamic alive state
- `lock`: worker identity exclusivity
- `capability send`: production group consumption
- `direct worker send`: debug/control targeting

**Step 2: Document the mental model**

Add a short architecture note:
- membership answers “who can consume”
- heartbeat answers “who can consume now”
- consumer group answers “which instance actually consumes”
- direct worker mode is only for debugging and worker-specific control

**Step 3: Note the compatibility wrappers**

If transitional methods remain, mark them as compatibility APIs and say when they can be removed.

**Step 4: Run docs lint or formatting if applicable**

**Step 5: Commit**

```bash
git add README.md src/by_framework/core/registry.py
git commit -m "docs: clarify worker membership heartbeat and routing semantics"
```

---

## Redis Data Model After Refactor

### Keep Existing Keys

- `byai_gateway:registry:worker:capabilities:{worker_id}`
- `byai_gateway:registry:capability:workers:{capability}`
- `byai_gateway:registry:active_workers`
- `byai_gateway:registry:worker:lock:{worker_id}`

### New Semantics

1. `worker:capabilities:{worker_id}`
   - static membership, updated at startup and graceful shutdown only

2. `capability:workers:{capability}`
   - static reverse index, updated at startup and graceful shutdown only

3. `active_workers`
   - dynamic liveness only, updated by heartbeat and explicit inactive mark

4. `worker:lock:{worker_id}`
   - startup exclusivity only

This keeps migration cheap because the Redis schema does not need to change immediately; only the write semantics change.

---

## Compatibility Strategy

### Phase 1: Non-breaking internal split

- Add new methods
- Keep old wrappers
- Update internal callers to use new methods
- Preserve current external behavior

### Phase 2: Behavioral alignment

- Make all worker selection alive-aware
- Make capability send independent of concrete worker choice

### Phase 3: API cleanup

- Deprecate old wrapper methods in docstrings and changelog
- Remove them only after all internal and external callers are migrated

---

## Test Matrix

### Registry unit tests

- membership registration writes only membership sets
- heartbeat writes only active zset
- inactive workers remain in membership but are excluded from alive queries
- direct worker liveness checks behave correctly
- lock lifecycle remains unchanged

### Worker lifecycle tests

- startup claims lock, registers membership, emits heartbeat
- repeated heartbeat does not rewrite membership
- graceful shutdown marks inactive and unregisters membership
- crash scenario still results in capability becoming unsendable after heartbeat timeout

### Client send-flow tests

- capability send succeeds only when at least one alive worker exists
- capability send does not require preselected worker
- direct worker send requires alive targeted worker
- error messages distinguish capability-unavailable from worker-unavailable

### Integration tests

- multiple worker instances under same capability consume through consumer group
- debug direct-worker routing reaches only the specified worker
- cancel/resume path still works when execution worker is learned at consume time

---

## Risks and Mitigations

1. **Risk:** Some existing code assumes `register_worker(...)` implies liveness.
   **Mitigation:** Keep compatibility wrappers first, migrate call sites incrementally.

2. **Risk:** Capability sends that previously stored `target_worker_id` early may now defer worker selection until consume time.
   **Mitigation:** Update execution tracking when processing starts and make cancellation logic resilient to delayed worker assignment.

3. **Risk:** Graceful unregister may remove membership for rolling restart windows.
   **Mitigation:** Correctness still depends on alive checks, not unregister success.

4. **Risk:** Debug direct-worker path could diverge from production semantics.
   **Mitigation:** Treat it as an explicit opt-in path with dedicated helper methods and tests.

---

## Recommended Execution Order

1. Split membership and heartbeat APIs in `WorkerRegistry`
2. Make all selection logic alive-aware
3. Separate capability send and direct-worker send in client code
4. Update worker heartbeat and shutdown lifecycle
5. Fix execution tracking for delayed worker assignment
6. Update docs and remove ambiguity

---

## Success Criteria

The refactor is complete when all of the following are true:

1. A capability is considered sendable only when it has at least one alive worker.
2. Heartbeat no longer rewrites static capability membership on every tick.
3. Production capability sends no longer depend on selecting a concrete worker in advance.
4. Direct worker sends remain available for debugging and validate worker liveness explicitly.
5. Worker ID lock remains independent and unchanged in purpose.
6. Graceful shutdown performs immediate inactive marking and optional membership cleanup, but crash safety still relies on heartbeat expiry.
