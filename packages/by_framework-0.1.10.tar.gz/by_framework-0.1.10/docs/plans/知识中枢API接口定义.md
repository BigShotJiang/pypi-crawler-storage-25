# 知识库 API 接口文档

## 1. 基础约定

### Base URL

```text
/api/v1
```

### 通用成功响应

```json
{
  "code": 200,
  "message": "success",
  "error": null,      # 错误信息, object
  "data": {}
}
```

## 2. 接口总览

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `POST` | `/api/v1/knowledge-bases` | 创建知识库 |
| `POST` | `/api/v1/knowledge-bases/delete` | 删除知识库（逻辑删除） |
| `POST` | `/api/v1/write-file` | 写入原文件到知识库 |
| `POST` | `/api/v1/write-index` | 写入索引及 markdown 副本到知识库 |
| `POST` | `/api/v1/knowledge-items/import` | 一次性导入原文件、markdown 副本与索引 |
| `POST` | `/api/v1/knowledge-items/delete` | 删除知识库文档（逻辑删除） |
| `POST` | `/api/v1/knowledge-items/search` | 执行 chunk 级混合检索 |
| `POST` | `/api/v1/list_dir` | 列出知识库目录 |
| `POST` | `/api/v1/glob` | 正则表达式方式查找文件、目录 |
| `POST` | `/api/v1/read-file` | 读取原文件或 markdown 文件 |
| `POST` | `/api/v1/file-to-markdown` | 文件解析为markdown文件 |
| `POST` | `/api/v1/build-markdown-index` | 为markdown文件构建索引 |

## 3. 创建知识库

### `POST /api/v1/knowledge-bases`

用于创建知识库。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_code` | string | 是 | - | 知识库编码 |
| `kb_name` | string | 是 | - | 知识库名称 |
| `kb_description` | string \| null | 否 | `null` | 知识库描述 |
| `status` | `ACTIVE` \| `INACTIVE` | 否 | `ACTIVE` | 知识库状态 |
| `metadata` | object \| null | 否 | `null` | 扩展元数据 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/knowledge-bases \
  -H "Content-Type: application/json" \
  -d '{
    "kb_code": "hr-policy",
    "kb_name": "人力制度知识库",
    "kb_description": "公司人事制度与流程",
    "status": "ACTIVE",
    "metadata": {
      "owner_dept": "HR"
    }
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "kb_code": "hr-policy",
    "kb_name": "人力制度知识库",
    "kb_description": "公司人事制度与流程",
    "status": "ACTIVE",
    "metadata": {
      "owner_dept": "HR"
    }
  }
}
```

### `data` 字段说明


| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `kb_name` | string | 知识库名称 |
| `kb_description` | string \| null | 知识库描述 |
| `status` | string | 知识库状态 |
| `metadata` | object \| null | 扩展元数据 |

## 4. 删除知识库

### `POST /api/v1/knowledge-bases/delete`

逻辑删除知识库。当前阶段仅修改数据库中的逻辑删除字段，不删除 MinIO 中的任何对象。

推荐语义：

- 将 `knowledge_base.is_deleted` 置为 `true`
- 同步将该知识库下的 `knowledge_fs_entry.is_deleted` 置为 `true`
- 同步将该知识库下的 `knowledge_item.is_deleted` 置为 `true`
- 不物理删除 `knowledge_fs_entry`、`knowledge_item`、`knowledge_item_version`、`knowledge_item_chunk`
- 删除后，知识库不应再出现在目录浏览、检索、读文件、写文件、写索引、组合导入等接口的可见结果中

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_code` | string | 是 | - | 知识库编码 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/knowledge-bases/delete \
  -H "Content-Type: application/json" \
  -d '{
    "kb_code": "hr-policy"
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "kb_code": "hr-policy",
    "is_deleted": true
  }
}
```

### `data` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `is_deleted` | boolean | 删除后的知识库逻辑删除标记，固定为 `true` |


## 5. 写入文件到知识库

### `POST /api/v1/write-file`

将原始文件写入知识库，上传文件格式不限制，支持目录层级，不存在目录时自动创建目录。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_code` | string | 是 | - | 知识库编码 |
| `file_code` | string | 是 | - | 文件编码 |
| `file_path` | string | 是 | - | 文件完整路径 |
| `file_description` | string \| null | 否 | `null` | 文件描述 |
| `file_content` | string | 是 | - | 原文件内容，使用 base64 编码后的字符串 |
| `version` | string | 是 | - | 文档版本号 |
| `source_code` | string | 是 | - | 文件来源系统 |
| `status` | `ACTIVE` \| `INACTIVE` | 否 | `ACTIVE` | 文件状态 |
| `metadata` | object \| null | 否 | `null` | 扩展元数据 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/write-file \
  -H "Content-Type: application/json" \
  -d '{
    "kb_code": "hr-policy",
    "file_code": "file-001",
    "file_path": "/考勤制度/异常考勤处理办法.pdf",
    "file_description": null,
    "file_content": "base64",
    "version": "V1",
    "source_code": "oa",
    "status": "ACTIVE",
    "metadata": {
      "owner_dept": "HR"
    }
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "kb_code": "hr-policy",
    "file_code": "file-001",
    "type_code": "pdf",
    "file_path": "/考勤制度/异常考勤处理办法.pdf",
    "file_description": null,
    "version": "V1",
    "status": "ACTIVE",
    "metadata": {
      "owner_dept": "HR"
    }
  }
}
```

### `data` 字段说明


| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `file_code` | string | 文件编码 |
| `type_code` | string | 文件类型编码，取扩展名的小写 |
| `file_path` | string \| null | 文件路径 |
| `file_description` | string \| null | 文件描述 |
| `version` | string \| null | 文件版本 |
| `status` | string | 文件状态 |
| `metadata` | object \| null | 扩展元数据 |


## 6. 写入索引到知识库

### `POST /api/v1/write-index`

将构建好的索引信息和对应的 markdown 副本写入知识库，支持任意文件类型的索引导入。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_code` | string | 是 | - | 知识库编码 |
| `file_code` | string | 是 | - | 文件编码 |
| `version` | string | 是 | - | 文件版本 |
| `markdown_content` | string | 是 | - | 解析后的 markdown 文件内容，原文字符串 |
| `chunks` | list[object] | 是 | - | 文件构建信息 |

### `chunks` 元素字段

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `chunk_no` | integer | 是 | chunk 顺序号，请求内必须唯一 |
| `start_line` | integer | 是 | chunk 起始行号 |
| `end_line` | integer | 是 | chunk 结束行号 |
| `chunk_text` | string | 是 | chunk 文本 |
| `embedding` | number[] | 是 | chunk 向量 |
| `char_start` | integer \| null | 否 | 起始字符偏移 |
| `char_end` | integer \| null | 否 | 结束字符偏移 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/write-index \
  -H "Content-Type: application/json" \
  -d '{
    "kb_code": "hr-policy",
    "file_code": "file-001",
    "version": "V1",
    "markdown_content": "# 异常考勤处理办法\n\n第一条 ...",
    "chunks": [
      {
        "chunk_no": 1,
        "start_line": 1,
        "end_line": 100,
        "chunk_text": "xxxxx",
        "embedding": [0.1, 0.2, 0.3, ...],
        "char_start": 1,
        "char_end": 732
      }
    ]
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "kb_code": "hr-policy",
    "file_code": "file-001",
    "version": "V1",
    "chunks": {
      "count": 1
    }
  }
}
```

### `data` 字段说明


| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `file_code` | string | 文件编码 |
| `version` | string \| null | 文件版本 |
| `chunks` | object | chunk构建信息 |

### `chunks` 元素字段

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `count` | integer| 导入的chunk数量 |

## 7. 导入文件与索引

### `POST /api/v1/knowledge-items/import`

一次性完成原文件写入、markdown 副本写入与 chunk 索引写入。该接口的请求语义等价于顺序执行：

1. `POST /api/v1/write-file`
2. `POST /api/v1/write-index`

但服务端应以单个原子事务完成导入；任一步失败时，数据库和对象存储都不应留下半成状态。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_code` | string | 是 | - | 知识库编码 |
| `file_code` | string | 是 | - | 文件编码 |
| `file_path` | string | 是 | - | 文件完整路径 |
| `file_description` | string \| null | 否 | `null` | 文件描述 |
| `file_content` | string | 是 | - | 原文件内容，使用 base64 编码后的字符串 |
| `version` | string | 是 | - | 文件版本 |
| `source_code` | string | 是 | - | 文件来源系统 |
| `status` | `ACTIVE` \| `INACTIVE` | 否 | `ACTIVE` | 文件状态 |
| `metadata` | object \| null | 否 | `null` | 扩展元数据 |
| `markdown_content` | string | 是 | - | 解析后的 markdown 文件内容，原文字符串 |
| `chunks` | list[object] | 是 | - | 文件构建信息 |

### `chunks` 元素字段

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `chunk_no` | integer | 是 | chunk 顺序号，请求内必须唯一 |
| `start_line` | integer | 是 | chunk 起始行号 |
| `end_line` | integer | 是 | chunk 结束行号 |
| `chunk_text` | string | 是 | chunk 文本 |
| `embedding` | number[] | 是 | chunk 向量 |
| `char_start` | integer \| null | 否 | 起始字符偏移 |
| `char_end` | integer \| null | 否 | 结束字符偏移 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/knowledge-items/import \
  -H "Content-Type: application/json" \
  -d '{
    "kb_code": "hr-policy",
    "file_code": "file-001",
    "file_path": "/考勤制度/异常考勤处理办法.pdf",
    "file_description": "异常考勤制度原文",
    "file_content": "base64",
    "version": "V1",
    "source_code": "oa",
    "status": "ACTIVE",
    "metadata": {
      "owner_dept": "HR"
    },
    "markdown_content": "# 异常考勤处理办法\n\n第一条 ...",
    "chunks": [
      {
        "chunk_no": 1,
        "start_line": 1,
        "end_line": 100,
        "chunk_text": "xxxxx",
        "embedding": [0.1, 0.2, 0.3],
        "char_start": 1,
        "char_end": 732
      }
    ]
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "kb_code": "hr-policy",
    "file_code": "file-001",
    "type_code": "pdf",
    "file_path": "/考勤制度/异常考勤处理办法.pdf",
    "file_description": "异常考勤制度原文",
    "version": "V1",
    "status": "ACTIVE",
    "metadata": {
      "owner_dept": "HR"
    },
    "chunks": {
      "count": 1
    }
  }
}
```

### `data` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `file_code` | string | 文件编码 |
| `type_code` | string | 文件类型编码，取扩展名的小写 |
| `file_path` | string | 文件路径 |
| `file_description` | string \| null | 文件描述 |
| `version` | string | 文件版本 |
| `status` | string | 文件状态 |
| `metadata` | object \| null | 扩展元数据 |
| `chunks` | object | chunk 写入结果摘要 |

### `chunks` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `count` | integer | 成功写入的 chunk 数量 |

## 8. 删除知识库文档

### `POST /api/v1/knowledge-items/delete`

逻辑删除知识库中的单个文档。当前阶段仅修改数据库中的逻辑删除字段，不删除 MinIO 中的原文件或 markdown 副本对象。

推荐语义：

- 通过 `kb_code + file_code` 定位文档
- 将 `knowledge_item.is_deleted` 置为 `true`
- 将对应的 `knowledge_fs_entry.is_deleted` 置为 `true`
- 不删除 `knowledge_item_version`、`knowledge_item_chunk`、embedding 表和 MinIO 对象
- 删除后，该文档不应再出现在目录浏览、检索、读文件、写索引等接口的可见结果中

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_code` | string | 是 | - | 知识库编码 |
| `file_code` | string | 是 | - | 文件编码 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/knowledge-items/delete \
  -H "Content-Type: application/json" \
  -d '{
    "kb_code": "hr-policy",
    "file_code": "file-001"
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "kb_code": "hr-policy",
    "file_code": "file-001",
    "is_deleted": true
  }
}
```

### `data` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `file_code` | string | 文件编码 |
| `is_deleted` | boolean | 删除后的文档逻辑删除标记，固定为 `true` |


## 9. 检索文档 chunk

### `POST /api/v1/knowledge-items/search`

用于执行 chunk 级混合检索。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `query` | string | 是 | - | 检索问题 |
| `kb_codes` | string[] | 是 | - | 知识库编码列表，至少 1 个 |
| `top_k` | integer | 否 | `10` | 最终返回条数 |
| `vector_top_k` | integer | 否 | `40` | 向量召回候选数，必须大于等于 `top_k` |
| `text_top_k` | integer | 否 | `30` | 文本召回候选数，必须大于等于 `top_k` |
| `source_codes` | string[] \| null | 否 | `null` | 来源过滤 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/knowledge-items/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "员工请假制度怎么规定",
    "kb_codes": ["hr-policy"],
    "top_k": 5,
    "vector_top_k": 20,
    "text_top_k": 20,
    "source_codes": ["oa"]
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "items": [
      {
        "kb_code": "hr-policy",
        "file_code": "employee-handbook",
        "version": "v1",
        "chunk_no": 1,
        "chunk_text": "员工请假应至少提前一天提交申请。",
        "score": 0.93,
        "text_score": 0.72,
        "vector_score": 0.95,
        "source_code": "oa",
        "file_path": "/employee-handbook.md"
      }
    ],
    "meta": {
      "query": "员工请假制度怎么规定",
      "top_k": 5,
      "vector_top_k": 20,
      "text_top_k": 20,
      "returned_count": 1
    }
  }
}
```

### `data.items[]` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `file_code` | string | 文档编码 |
| `version` | string | 命中文档版本 |
| `chunk_no` | integer | chunk 序号 |
| `chunk_text` | string | chunk 内容 |
| `score` | number | 综合得分 |
| `text_score` | number \| null | 文本召回得分 |
| `vector_score` | number \| null | 向量召回得分 |
| `source_code` | string | 来源编码 |
| `type_code` | string | 类型编码 |
| `file_path` | string | 文档路径 |

### `data.meta` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `query` | string | 原始查询 |
| `top_k` | integer | 返回条数配置 |
| `vector_top_k` | integer | 向量召回候选数 |
| `text_top_k` | integer | 文本召回候选数 |
| `returned_count` | integer | 实际返回条数 |

## 10. 列出知识库目录

### `POST /api/v1/list_dir`

用于列出知识库中的虚拟目录内容。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_codes` | string[] | 是 | - | 知识库编码列表 |
| `path` | string | 否 | `/` | 待列出的目录路径 |
| `source_codes` | string[] | 否 | null | 过滤文件来源系统，默认不过过滤 |
| `type_code` | string[] | 否 | null | 过滤文件类型，默认不过滤 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/list_dir \
  -H "Content-Type: application/json" \
  -d '{
    "kb_codes": ["hr-policy"],
    "path": "/policies",
    "source_codes": null,
    "type_code": null
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": [
    {
      "kb_code": "hr-policy",
      "name": "/policies/employee-handbook.md",
      "type": "file",
      "size": 2048
    },
    {
      "kb_code": "hr-policy",
      "name": "/policies/archive",
      "type": "directory",
      "size": 0
    }
  ]
}
```

### `data[]` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `name` | string | 文件或目录的完整路径 |
| `type` | `file` \| `directory` | 节点类型 |
| `size` | integer | 文件大小(KB)，目录通常为 `0` |


## 8. 正则表达式方式查找文件、目录

### `POST /api/v1/glob`

基于正则表达式查找文件、目录，基于层级查找，如：
*.md: 在一级目录下查找markdown文件
人力*/*.pdf: 在一级目录下查找”人力*“， 再在对应的二级目录查找pdf文件
人力资源: 等价于list_dir

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_codes` | string[] | 是 | - | 知识库编码列表 |
| `path` | string | 是 | - |  待查询的路径，支持正则表达式 |
| `source_codes` | string[] | 否 | null | 过滤文件来源系统，默认不过过滤 |
| `type_code` | string[] | 否 | null | 过滤文件类型，默认不过滤 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/glob \
  -H "Content-Type: application/json" \
  -d '{
    "kb_codes": ["hr-policy"],
    "path": "/policies/*.md",
    "source_codes": null,
    "type_code": null
  }'
```

### 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": [
    {
      "kb_code": "hr-policy",
      "name": "/policies/employee-handbook.md",
      "type": "file",
      "size": 2048
    },
  ]
}
```

### `data[]` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `name` | string | 文件或目录的完整路径 |
| `type` | `file` \| `directory` | 节点类型 |
| `size` | integer | 文件大小(KB)，目录通常为 `0` |


## 9. 按行读取文档

### `POST /api/v1/read-file`

用于根据路径读取原文件或 markdown 副本内容。
传入多个知识库编码时，返回首个匹配的知识库文件。

读取规则：

- `content_type=original`：忽略 `start_line` 和 `end_line`，直接返回原文件的可访问 `url`
- `content_type=markdown`：当同时传入 `start_line` 和 `end_line` 时，返回对应范围的文本内容
- `content_type=markdown`：当 `start_line` 和 `end_line` 都不传时，返回完整 markdown 文件内容

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `kb_codes` | string[] | 是 | - | 知识库编码列表，至少 1 个 |
| `path` | string | 是 | - | 文档路径 |
| `content_type` | `original` \| `markdown` | 否 | `markdown` | 读取原文件还是 markdown 副本 |
| `start_line` | integer | 否 | - | 起始行号；`content_type=markdown` 时可选，与 `end_line` 成对出现 |
| `end_line` | integer | 否 | - | 结束行号；`content_type=markdown` 时可选，与 `start_line` 成对出现 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/read-file \
  -H "Content-Type: application/json" \
  -d '{
    "kb_codes": ["hr-policy"],
    "path": "/policies/employee-handbook.md",
    "content_type": "markdown",
    "start_line": 1,
    "end_line": 20
  }'
```

### 读取 markdown 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "items": [
      {
        "kb_code": "hr-policy",
        "path": "/policies/employee-handbook.md",
        "content_type": "markdown",
        "start_line": 1,
        "end_line": 20,
        "data": "# 员工手册\n\n员工请假应至少提前一天提交申请。",
        "reached_eof": false
      }
    ]
  }
}
```

### 读取完整 markdown 成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "items": [
      {
        "kb_code": "hr-policy",
        "path": "/policies/employee-handbook.md",
        "content_type": "markdown",
        "data": "# 员工手册\n\n员工请假应至少提前一天提交申请。",
        "reached_eof": true
      }
    ]
  }
}
```

### 读取原文件成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "items": [
      {
        "kb_code": "hr-policy",
        "path": "/policies/employee-handbook.pdf",
        "content_type": "original",
        "url": "https://example.com/kb/hr-policy/policies/employee-handbook.pdf"
      }
    ]
  }
}
```

### `data.items[]` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `kb_code` | string | 知识库编码 |
| `path` | string | 文档路径 |
| `content_type` | `original` \| `markdown` | 本次读取的内容类型 |
| `start_line` | integer | 实际返回起始行；分段读取 markdown 时返回 |
| `end_line` | integer | 实际返回结束行；分段读取 markdown 时返回 |
| `data` | string | 行内容拼接结果；仅 `markdown` 返回 |
| `reached_eof` | boolean | 是否已经到达文件末尾；仅 `markdown` 返回，完整读取时通常为 `true` |
| `url` | string | 原文件访问地址；仅 `original` 返回 |


## 10. 文件解析为markdown文件

### `POST /api/v1/file-to-markdown`

将文件解释为markdown文件，目前demo构建仅支持pdf、word、powerpoint、excel。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `content` | string | 是 | - | 文件base64 |
| `type` | string | 是 | - | 文件类型 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/file-to-markdown \
  -H "Content-Type: application/json" \
  -d '{
    "content": "base64",
    "path": "pdf"
  }'
```

### 预期成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "md_content": "xxxxxx"
  }
}
```

### `data` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `md_content` | string | 解析后的markdown内容 |


## 11. 为markdown文件构建索引

### `POST /api/v1/build-markdown-index`

为markdown文件切分为chunk，以及embedding计算。

### 请求体

`Content-Type: application/json`

| 字段 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| `content` | string | 是 | - | markdown文件base64 |

### 调用示例

```bash
curl -X POST http://localhost:8000/api/v1/build-markdown-index \
  -H "Content-Type: application/json" \
  -d '{
    "content": "xxxxx"
  }'
```

### 预期成功响应示例

```json
{
  "code": 200,
  "message": "success",
  "error": null,
  "data": {
    "chunks": {
      "chunk_no": 1,
      "start_line": 1,
      "end_line": 100,
      "chunk_text": "xxxxx",
      "embedding": [0.1, 0.2, 0.3, ...],
      "char_start": 1,
      "char_end": 732
    }
  }
}
```

### `data.chunks[]` 字段说明

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `chunk_no` | integer | chunk 顺序号，请求内必须唯一 |
| `start_line` | integer | chunk 起始行号 |
| `end_line` | integer | chunk 结束行号 |
| `chunk_text` | string | chunk 文本 |
| `embedding` | number[] | chunk 向量 |
| `char_start` | integer \| null | 起始字符偏移 |
| `char_end` | integer \| null | 结束字符偏移 |


## 12. 删除能力影响评估

### 12.1 需要补充的接口

本次新增的删除接口：

- `POST /api/v1/knowledge-bases/delete`
- `POST /api/v1/knowledge-items/delete`

建议都采用逻辑删除，当前阶段只修改数据库逻辑删除字段，不处理 MinIO 中的原文件、markdown 副本与临时对象。

### 12.2 哪些表需要修改

结论：当前阶段需要新增逻辑删除字段，`status` 不承担删除语义。

建议新增的表字段：

- `knowledge_base.is_deleted boolean not null default false`
- `knowledge_fs_entry.is_deleted boolean not null default false`
- `knowledge_item.is_deleted boolean not null default false`

当前阶段不建议修改结构的表：

- `knowledge_item_version`
  - 不需要新增删除标记
  - 保留历史版本和对象路径即可
- `knowledge_item_chunk`
  - 不需要新增删除标记
  - 可继续作为历史数据保留
- embedding 表
  - 当前阶段不需要物理删除或新增删除标记
- MinIO 对象
  - 当前阶段不改动

因此，表结构层面的建议是：

- 新增 `is_deleted`
- 当前阶段不新增 `deleted_at`
- 当前阶段不新增额外删除状态表

### 12.3 删除知识库时涉及的表

最小逻辑删除动作：

- 更新 `knowledge_base.is_deleted = true`
- 同步更新该知识库下 `knowledge_fs_entry.is_deleted = true`
- 同步更新该知识库下 `knowledge_item.is_deleted = true`

当前阶段不建议联动修改：

- `knowledge_item_version`
- `knowledge_item_chunk`

原因：

- `knowledge_fs_entry` 和 `knowledge_item` 仍会直接被目录浏览、读文件、写索引等链路消费
- 仅删除知识库主表不足以让所有查询天然隐藏下游节点
- 逻辑删除知识库时同步删除其下文档，可以减少查询侧的遗漏风险

### 12.4 删除知识库文档时涉及的表

推荐最小逻辑删除动作：

- 更新 `knowledge_item.is_deleted = true`
- 更新对应 `knowledge_fs_entry.is_deleted = true`

不建议当前阶段修改：

- `knowledge_item_version`
- `knowledge_item_chunk`
- embedding 表
- MinIO 对象

为什么建议同时改两张表：

- 只改 `knowledge_item.is_deleted`
  - `search` 可通过投影刷新隐藏
  - 但 `list_dir` / `glob` 目前主要依赖 `knowledge_fs_entry`
- 只改 `knowledge_fs_entry.is_deleted`
  - 目录浏览会隐藏
  - 但检索投影如果不刷新，搜索仍可能命中旧 chunk

所以文档逻辑删除的推荐实现是：

- `knowledge_item.is_deleted = true`
- `knowledge_fs_entry.is_deleted = true`
- 同步刷新该文档对应的 retrieval projection

### 12.5 哪些现有接口会受影响

明确受影响的现有接口有：

- `POST /api/v1/knowledge-items/search`
- `POST /api/v1/list_dir`
- `POST /api/v1/glob`
- `POST /api/v1/read-file`
- `POST /api/v1/write-file`
- `POST /api/v1/write-index`
- `POST /api/v1/knowledge-items/import`

影响说明：

- `search`
  - 已经按 `knowledge_base_status = 'ACTIVE'`、`knowledge_item_status = 'ACTIVE'` 过滤
  - 还需要补 `knowledge_base.is_deleted = false`、`knowledge_item.is_deleted = false`
  - 删除文档后需要确保 retrieval projection 被刷新，否则旧投影数据仍可能残留
- `list_dir`
  - 当前查询主要过滤 `knowledge_fs_entry.status = 'ACTIVE'`
  - 删除后需要补 `knowledge_base.is_deleted = false`、`knowledge_fs_entry.is_deleted = false`
- `glob`
  - 与 `list_dir` 一样，需要补 `knowledge_base.is_deleted = false`、`knowledge_fs_entry.is_deleted = false`
- `read-file`
  - 当前读取当前版本时已过滤 `knowledge_fs_entry.status`、`knowledge_item.status`
  - 还需要补 `knowledge_base.is_deleted = false`、`knowledge_fs_entry.is_deleted = false`、`knowledge_item.is_deleted = false`
- `write-file`
  - 当前会校验知识库必须为 `ACTIVE`
  - 还需要额外校验知识库 `is_deleted = false`
- `write-index`
  - 通过 `knowledge_item` 和版本定位文档
  - 删除文档后需要依赖 `knowledge_item.is_deleted = false` 拦截后续写索引
- `knowledge-items/import`
  - 与 `write-file` 一样，需要依赖知识库 `ACTIVE` 状态且 `is_deleted = false`

### 12.6 当前实现的主要改动点

建议后续实施时优先改这些位置：

- `knowledge_base_repository`
  - 新增按 `kb_code` 逻辑删除知识库的方法
  - 为按 `kb_code` 查询补 `is_deleted` 语义处理
- `knowledge_item_repository`
  - 新增按 `kb_code + file_code` 逻辑删除文档的方法
  - 为按 `item_code` / `fs_entry_id` 查询补 `is_deleted` 语义处理
- `knowledge_fs_entry_repository`
  - 新增按 `fs_entry_id` 或 `knowledge_base_id + full_path` 逻辑删除目录/文件节点的方法
  - 为 `list_root_entries`、`list_root_nodes`、`list_children`、`list_child_nodes`、`list_entries_by_path_pattern`、`get_current_file_version_by_entry_id` 补 `knowledge_base.is_deleted = false`、`knowledge_fs_entry.is_deleted = false` 过滤
- `retrieval_projection_repository`
  - 删除文档后刷新单文档投影
- `knowledge_base_service`
  - 新增删除知识库接口对应的 service 方法
- `knowledge_item_ingestion_service`
  - 新增删除文档接口对应的 service 方法
- API 层
  - 增加两个删除接口的 request / response / route / 错误映射
