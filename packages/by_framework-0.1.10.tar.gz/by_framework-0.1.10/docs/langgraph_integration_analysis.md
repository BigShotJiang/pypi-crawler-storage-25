# by-framework × LangGraph 集成架构分析

## 1. 当前架构核心机制剖析

### 1.1 三大协作原语

by-framework 的协作系统建立在 **Redis Streams 双通道** 之上：

| 原语 | 作用 | 实现机制 | 状态转移 |
|------|------|---------|----------|
| `call_agent` | 调用远程 Agent | 向目标 Agent 的 `queue:ctrl:{agent_type}` 发送 `AskAgentCommand` | → `QUEUED` (挂起) |
| `ask_user` | 请求用户输入 | 通过数据流发送 `AskUserEvent` (表单) | → `WAITING_USER` (挂起) |
| `resume` | 恢复挂起任务 | 框架自动向源 Agent 发送 `ResumeCommand` | → `RESUMED` (唤醒) |

### 1.2 数据流图

```
                          ┌─────────────────────────────┐
                          │    Orchestrator Worker       │
                          │                             │
  User ──AskAgentCommand──►  process_command()          │
                          │    │                        │
                          │    ├── ctx.call_agent("poet")│
                          │    │   └─ xadd → queue:ctrl:poet-agent
                          │    │       (设置 _is_suspended=true)
                          │    │       (注入 source_agent_type)
                          │    │                        │
                          │    └── return {status:QUEUED}│
                          └─────────────────────────────┘
                                        │
                                        ▼
                          ┌─────────────────────────────┐
                          │    Poet Worker               │
                          │    process_command()         │
                          │    └── return full_poem      │
                          └──────────┬──────────────────┘
                                     │ (框架检测 has_source_agent)
                                     ▼
                          _enqueue_agent_return()
                            └─ ResumeCommand → queue:ctrl:orchestrator
                                        │
                                        ▼
                          ┌─────────────────────────────┐
                          │    Orchestrator Worker       │
                          │    process_command(ResumeCmd)│
                          │    └── resume_data 包含诗篇   │
                          └─────────────────────────────┘
```

### 1.3 关键实现细节

#### `call_agent` 的挂起/唤醒契约

```python
# context.py L434-543
async def call_agent(self, target_agent_type, content, wait_for_reply=True, ...):
    # 1. 注入 source_agent_type（用于回调路由）
    source_agent_type = self.current_agent_id if wait_for_reply else ""

    # 2. 设置挂起标志（防止框架发送 APP_STREAM_RESPONSE）
    if wait_for_reply:
        self._is_suspended = True

    # 3. 发送 AskAgentCommand 到目标 Redis Stream
    await self.redis.xadd(RedisKeys.ctrl_stream(target), command.to_redis_payload())
```

#### 框架级自动回调 (`worker.py` L423-428)

```python
# 当子 Agent 完成时，框架自动发送 ResumeCommand 回源 Agent
if has_source_agent:
    await self._enqueue_agent_return(
        raw_command,
        status=AgentState.COMPLETED.value,
        reply_data=process_result,  # ← 这里是子 Agent 的返回值
    )
```

#### `ask_user` 的挂起信号

```python
# context.py L397-418
async def ask_user(self, event, ...):
    await self.emitter.ask_user(...)  # 向前端推送表单
    self._is_suspended = True         # 防止框架自动结束流
    return {"status": AgentState.WAITING_USER.value}
```

> [!IMPORTANT]
> **核心约定**：`call_agent` 和 `ask_user` 都通过设置 `_is_suspended = True` 通知框架 "本次 `process_command` 执行完不是真正结束"，框架据此决定不发送 `APP_STREAM_RESPONSE`，等待后续的 `ResumeCommand` 重新触发 `process_command`。

---

## 2. LangGraph 的 interrupt/resume 模型

LangGraph 的状态管理基于 **Checkpoint + interrupt/Command(resume)** 模型：

```python
# 在工具内部挂起
result = interrupt("Waiting for external input")

# 恢复时传递数据
from langgraph.types import Command
final = await graph.ainvoke(Command(resume=data), config=config)
```

### 核心特征

| 特征 | 说明 |
|------|------|
| **状态持久化** | Checkpoint 自动保存整个图的执行状态 |
| **函数级挂起** | `interrupt()` 在工具函数内部挂起，恢复时从断点继续 |
| **多次中断** | 图可以多次 interrupt → resume，形成多轮对话 |
| **确定性恢复** | resume 时 Checkpoint 精确恢复到中断点的上下文 |

---

## 3. 核心矛盾：两套"挂起/恢复"语义的阻抗不匹配

```
┌──────────────────────────────┐     ┌──────────────────────────────┐
│     by-framework 层          │     │      LangGraph 层            │
│                              │     │                              │
│  process_command() 执行结束   │     │  interrupt() 挂起图执行       │
│  → 返回值决定状态             │     │  → Checkpoint 保存全量状态    │
│  → _is_suspended 通知框架    │     │  → 工具函数暂停在 interrupt   │
│                              │     │                              │
│  新的 process_command() 调用  │     │  Command(resume=data) 恢复   │
│  (ResumeCommand)             │     │  → 从 Checkpoint 恢复上下文   │
│  → 全新的函数调用上下文       │     │  → interrupt() 返回 data      │
└──────────────────────────────┘     └──────────────────────────────┘

矛盾点：
├─ by-framework: process_command 是"一次性函数调用"，挂起=函数返回
├─ LangGraph:    interrupt 是"协程级挂起"，状态由 Checkpoint 托管
└─ 桥接需求:     在 process_command 的两次调用之间，保持 LangGraph 图的状态连续性
```

---

## 4. 现有 Orchestrator 示例的解法评价

当前 [orchestrator.py](file:///Users/xiaozhongcheng/data/company/beyonai/by-framework-samples/python/workers/multi-workers/orchestrator.py) 使用了一种 **"工具内 dispatch + interrupt"** 模式：

### 4.1 工作流程

```mermaid
sequenceDiagram
    participant User
    participant Framework as by-framework
    participant Orch as Orchestrator
    participant LG as LangGraph
    participant Poet as Poet Worker

    User->>Framework: AskAgentCommand("写诗")
    Framework->>Orch: process_command(AskAgentCmd)
    Orch->>LG: graph.ainvoke({messages: [HumanMessage]})
    LG->>LG: agent_node → LLM 决定调用 invoke_poet
    LG->>LG: ToolNode 执行 invoke_poet 工具
    Note over LG: 工具内部:
    LG->>Framework: context.call_agent("poet-agent", topic)
    LG->>LG: interrupt("Waiting for poet")
    LG-->>Orch: graph.ainvoke 返回(图挂起)
    Orch-->>Framework: return "Tasks dispatched..."

    Poet->>Framework: 完成创作，return full_poem
    Framework->>Orch: process_command(ResumeCmd, reply_data=poem)

    Orch->>LG: graph.ainvoke(Command(resume=poem))
    Note over LG: interrupt() 返回 poem
    LG->>LG: 工具返回 → agent_node → LLM 汇总
    LG-->>Orch: final answer
    Orch->>Framework: emit_chunk(final_answer)
```

### 4.2 评价

| 维度 | 评价 |
|------|------|
| **正确性** | ✅ 基本可行，利用 MemorySaver Checkpoint 桥接了两次 `process_command` 调用 |
| **幂等性** | ✅ 使用 Redis key 防止 Checkpoint 恢复时重复派发 (`dispatched_task:...`) |
| **灵活性** | ✅ 支持多工具、多轮 interrupt（LLM 可以连续调用多个远程工具） |
| **耦合度** | ⚠️ 工具工厂 `_make_remote_tool` 内部直接依赖 `context.call_agent` 和 `interrupt`，紧耦合 |
| **ask_user** | ❌ 未覆盖 ask_user 场景 |
| **Checkpoint 持久化** | ⚠️ MemorySaver 是内存级的，Worker 重启丢失（生产需 Redis/PostgresCheckpointer） |
| **消息格式** | ⚠️ `_format_messages` 手动转换消息格式，维护成本高 |

---

## 5. 三种改进方案

### 方案 A：最小侵入 — 抽象 LangGraph 适配工具工厂

**思路**：在 by-framework 中提供一个标准化的 "远程工具工厂"，封装 `call_agent + interrupt` 的样板代码。

```python
# 新增: by_framework/integrations/langgraph/remote_tool.py

from langgraph.types import interrupt
from langchain_core.tools import tool

def make_remote_agent_tool(
    context: AgentContext,
    tool_name: str,
    target_agent_type: str,
    description: str,
    idempotency_ttl: int = 86400,
):
    """工厂：生成一个桥接 by-framework call_agent 与 LangGraph interrupt 的工具。"""

    @tool(tool_name, description=description)
    async def remote_tool(topic: str, tool_call_id: Annotated[str, InjectedToolCallId]):
        # 幂等防抖
        redis_key = f"dispatched:{context.session_id}:{tool_call_id}"
        if not await context.redis.exists(redis_key):
            await context.call_agent(
                target_agent_type=target_agent_type,
                content=topic,
            )
            await context.redis.set(redis_key, "1", ex=idempotency_ttl)

        # LangGraph 中断
        result = interrupt(f"Waiting for {target_agent_type}")
        return result

    return remote_tool
```

同理，提供 `ask_user` 的工具适配：

```python
# 新增: by_framework/integrations/langgraph/ask_user_tool.py

def make_ask_user_tool(context: AgentContext, tool_name: str = "ask_user"):
    """工厂：生成桥接 by-framework ask_user 与 LangGraph interrupt 的工具。"""

    @tool(tool_name, description="向用户提问并等待回复")
    async def ask_user_tool(
        prompt: str,
        tool_call_id: Annotated[str, InjectedToolCallId],
    ):
        redis_key = f"asked_user:{context.session_id}:{tool_call_id}"
        if not await context.redis.exists(redis_key):
            await context.ask_user(prompt)
            await context.redis.set(redis_key, "1", ex=86400)

        result = interrupt(f"Waiting for user: {prompt}")
        return result

    return ask_user_tool
```

**优势**：
- 零框架改动，纯辅助层
- 样板代码最小化
- 保持用户对 LangGraph 图结构的完全控制

**劣势**：
- 用户仍需手动管理 Checkpoint、`process_command` 的 AskAgent/Resume 分叉
- `ask_user` 的 Resume 触发点与 `call_agent` 的不同（前者由前端触发，后者由框架自动触发），需额外文档说明

---

### 方案 B：Human-in-the-Loop 统一模型

**思路**：将 `call_agent` 和 `ask_user` 统一建模为 LangGraph 的 **Human-in-the-Loop** 模式，利用 LangGraph 原生的 `interrupt` 机制统一处理所有"等待外部输入"的场景。

```python
# 新增: by_framework/integrations/langgraph/base_worker.py

class LangGraphWorker(ByaiWorker):
    """通用 LangGraph Worker 基类，自动处理 interrupt ↔ by-framework 的桥接。"""

    @abstractmethod
    def build_graph(self, context: AgentContext) -> CompiledStateGraph:
        """子类构建 LangGraph 图。"""
        ...

    def _get_checkpointer(self):
        if not hasattr(self, "_checkpointer"):
            self._checkpointer = MemorySaver()
        return self._checkpointer

    async def process_command(self, command, context):
        config = {"configurable": {"thread_id": context.session_id}}
        graph = self.build_graph(context)

        if isinstance(command, ResumeCommand):
            # 统一恢复：无论是 call_agent 回调还是 ask_user 回复
            resume_data = command.reply_data or command.content or ""
            final = await graph.ainvoke(
                Command(resume=str(resume_data)),
                config=config,
            )
        else:
            user_input = extract_text(command.content)
            final = await graph.ainvoke(
                {"messages": [HumanMessage(content=user_input)]},
                config=config,
            )

        # 统一判断：图是否挂起
        last_msg = final["messages"][-1]
        if hasattr(last_msg, "tool_calls") and last_msg.tool_calls:
            return {"status": "QUEUED"}  # 图挂起，等待外部

        # 图完成，输出最终结果
        answer = last_msg.content if hasattr(last_msg, "content") else str(last_msg)
        await context.emit_chunk(answer, content_type="text")
        return answer
```

**核心语义映射**：

```
┌────────────────────┬──────────────────────────────────┐
│ by-framework 原语   │ 在 LangGraph Worker 中的表现       │
├────────────────────┼──────────────────────────────────┤
│ call_agent()       │ 工具内: call_agent + interrupt()  │
│                    │ → 图挂起 → process_command 返回    │
│                    │ → 框架不发 APP_STREAM_RESPONSE     │
├────────────────────┼──────────────────────────────────┤
│ ask_user()         │ 工具内: ask_user + interrupt()     │
│                    │ → 同上逻辑                        │
├────────────────────┼──────────────────────────────────┤
│ ResumeCommand      │ Command(resume=data)              │
│ (from call_agent)  │ → interrupt() 返回 reply_data     │
│                    │ → 工具函数继续执行                  │
├────────────────────┼──────────────────────────────────┤
│ ResumeCommand      │ Command(resume=user_input)        │
│ (from ask_user)    │ → 同上                           │
└────────────────────┴──────────────────────────────────┘
```

**优势**：
- 提供开箱即用的基类，团队不需要理解底层桥接细节
- `call_agent` 和 `ask_user` 的 resume 在 LangGraph 层是统一的
- 可以扩展 `dispatch_group`（scatter-gather）

**劣势**：
- 新增框架层代码，需要维护
- 对 LangGraph 版本有依赖
- 图的"是否挂起"判断逻辑（检查 `tool_calls`）可能不够健壮

---

### 方案 C：框架级深度集成 — LangGraph Adapter 模块

**思路**：在 by-framework 核心提供 `LangGraphAdapter`，在 `_handle_message` 层面拦截 LangGraph 的 interrupt 状态，自动化挂起/恢复的全流程管理。

```python
# 新增: by_framework/integrations/langgraph/adapter.py

class LangGraphAdapter:
    """
    运行时适配器：在 by-framework 命令生命周期和 LangGraph 图执行之间
    做精确的状态桥接。
    """

    def __init__(self, graph: CompiledStateGraph, context: AgentContext):
        self.graph = graph
        self.context = context
        self._config = {"configurable": {"thread_id": context.session_id}}

    async def run(self, command: GatewayCommand) -> Any:
        """统一入口：根据命令类型决定 invoke 还是 resume。"""
        if isinstance(command, ResumeCommand):
            return await self._handle_resume(command)
        return await self._handle_initial(command)

    async def _handle_initial(self, command):
        content = extract_text(command.content)
        result = await self.graph.ainvoke(
            {"messages": [HumanMessage(content=content)]},
            config=self._config,
        )
        return await self._process_result(result)

    async def _handle_resume(self, command: ResumeCommand):
        data = command.reply_data or command.content or ""
        result = await self.graph.ainvoke(
            Command(resume=str(data)),
            config=self._config,
        )
        return await self._process_result(result)

    async def _process_result(self, result) -> Any:
        """分析图执行结果，决定是挂起还是完成。"""
        # 检查 LangGraph 是否有 pending interrupts
        snapshot = self.graph.get_state(self._config)
        if snapshot.next:  # 图还有后续节点要执行（被 interrupt 阻塞了）
            return {"status": AgentState.QUEUED.value}

        last_msg = result["messages"][-1]
        answer = last_msg.content if hasattr(last_msg, "content") else str(last_msg)
        await self.context.emit_chunk(answer, content_type="text")
        return answer
```

> [!TIP]
> 使用 `graph.get_state(config).next` 而非检查 `tool_calls` 来判断图是否挂起，这是更可靠的 LangGraph 原生方式。`snapshot.next` 不为空说明图被 interrupt 阻塞，有后续节点待执行。

**优势**：
- 最精确的挂起判断（通过 `get_state().next`）
- 可以在 Adapter 层做统一的日志、metrics、错误处理
- 支持 streaming（可以在 Adapter 中用 `astream_events` 替代 `ainvoke`）

**劣势**：
- 侵入性最大
- 需要仔细处理 Checkpoint 的生命周期管理

---

## 6. ask_user 场景的特殊分析

`ask_user` 与 `call_agent` 在 by-framework 层看似对称，但在 LangGraph 集成中有微妙差异：

### 6.1 ask_user 的特殊之处

```
call_agent 路径:
  process_command → call_agent → _is_suspended → 返回
  Framework 自动检测 source_agent → 子Agent完成 → 自动发 ResumeCommand

ask_user 路径:
  process_command → ask_user → _is_suspended → 返回
  前端收到 AskUserEvent → 用户填写表单 → 前端/Client 发 ResumeCommand
```

> [!WARNING]
> **关键差异**：`ask_user` 的 `ResumeCommand` 由外部(前端/Client)触发，其 `content` 字段携带用户输入；而 `call_agent` 的 `ResumeCommand` 由框架自动触发，`reply_data` 携带子 Agent 返回值。LangGraph 的 `Command(resume=...)` 需要区分这两种数据来源。

### 6.2 在 LangGraph 中统一处理 ask_user

```python
def make_ask_user_tool(context: AgentContext):
    @tool("ask_user", description="需要向用户确认时调用此工具")
    async def ask_user_tool(
        prompt: str,
        tool_call_id: Annotated[str, InjectedToolCallId],
    ):
        # 仅首次执行时发送 ask_user 事件
        redis_key = f"asked:{context.session_id}:{tool_call_id}"
        if not await context.redis.exists(redis_key):
            await context.ask_user(prompt)
            await context.redis.set(redis_key, "1", ex=86400)

        # 挂起等待用户输入
        user_reply = interrupt(f"ask_user:{prompt}")
        return f"用户回复：{user_reply}"

    return ask_user_tool
```

在 `process_command` 的 Resume 分支中：

```python
if isinstance(command, ResumeCommand):
    # 从 ResumeCommand 提取用户输入或子Agent返回
    if command.reply_data:
        resume_value = str(command.reply_data)
    elif command.content:
        resume_value = str(command.content)
    else:
        resume_value = ""

    final = await graph.ainvoke(Command(resume=resume_value), config=config)
```

这样，**无论是 `call_agent` 回调还是 `ask_user` 回复**，在 LangGraph 层都是统一的 `Command(resume=value)` → `interrupt()` 返回 `value` 的语义。

---

## 7. 推荐方案与实施路径

### 推荐：方案 A + B 组合

```
阶段 1: 提供工具工厂（方案 A）
├─ make_remote_agent_tool()
├─ make_ask_user_tool()
├─ 零框架改动，纯库代码
└─ 即刻可用

阶段 2: 提供 LangGraphWorker 基类（方案 B）
├─ 封装 process_command 的 AskAgent/Resume 分叉
├─ 内置 Checkpoint 管理
├─ 使用 get_state().next 判断挂起（方案 C 的核心优化）
└─ 用户只需实现 build_graph()
```

### 建议的模块结构

```
src/by_framework/integrations/
└── langgraph/
    ├── __init__.py
    ├── remote_tool.py        # make_remote_agent_tool()
    ├── ask_user_tool.py      # make_ask_user_tool()
    ├── worker.py             # LangGraphWorker 基类
    └── utils.py              # 消息格式转换、Checkpoint 管理等
```

### 关键设计原则

1. **LangGraph Checkpoint 是状态桥梁** — 两次 `process_command` 调用之间，图的全量状态由 Checkpoint 托管，这是整个集成的基石
2. **幂等性 = Redis 防抖** — Checkpoint 恢复会重新执行工具函数，必须用 Redis key 防止重复 `call_agent`/`ask_user`
3. **统一 Resume 语义** — `call_agent` 和 `ask_user` 的返回在 LangGraph 层都映射为 `Command(resume=data)`
4. **`_is_suspended` 是契约** — 工具内调用 `call_agent` 或 `ask_user` 后，框架自动知道不应结束流
5. **Checkpointer 选型** — 开发环境用 `MemorySaver`，生产需用 `langgraph-checkpoint-postgres` 或类似持久化方案

---

## 8. 对比总结表

| 维度 | 纯 by-framework | + LangGraph (当前示例) | + LangGraph (推荐方案) |
|------|-----------------|----------------------|----------------------|
| call_agent | `ctx.call_agent()` + 手动处理 Resume | 工具内 `call_agent + interrupt` | `make_remote_agent_tool()` 一行搞定 |
| ask_user | `ctx.ask_user()` + 手动处理 Resume | ❌ 未实现 | `make_ask_user_tool()` |
| 多工具编排 | 手写状态机 | LLM 自动规划 ✅ | 同左 ✅ |
| 状态管理 | 自行管理（Redis/文件） | MemorySaver Checkpoint | 可插拔 Checkpoint |
| 幂等性 | N/A | Redis 防抖 ✅ | 内置防抖 ✅ |
| 代码量 | 中等 | 高（样板代码多） | 低 ✅ |
| scatter-gather | `dispatch_group()` | 需手动实现 | 可扩展 `dispatch_group_tool()` |
