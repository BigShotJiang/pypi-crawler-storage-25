"""Tests for WorkerRegistry functionality."""

import pytest

from by_framework import RedisKeys, WorkerRegistry


class MockPipeline:
    """Mock Redis pipeline for testing."""

    def __init__(self, redis):
        self.redis = redis
        self.commands = []

    def hset(self, name, key, value):
        self.commands.append(("hset", name, key, value))
        return self

    def expire(self, name, ttl):
        self.commands.append(("expire", name, ttl))
        return self

    async def execute(self):
        for cmd in self.commands:
            if cmd[0] == "hset":
                await self.redis.hset(cmd[1], {cmd[2]: cmd[3]})
            elif cmd[0] == "expire":
                await self.redis.expire(cmd[1], cmd[2])
        return []


class MockRedis:
    """Mock Redis client for testing."""

    def __init__(self):
        self.data = {}
        self.kv = {}
        self.expires = {}

    async def zadd(self, name, mapping):
        if name not in self.data:
            self.data[name] = {}
        for k, v in mapping.items():
            self.data[name][k] = v

    async def zrem(self, name, *values):
        bucket = self.data.get(name)
        if not isinstance(bucket, dict):
            return 0
        removed = 0
        for value in values:
            if value in bucket:
                del bucket[value]
                removed += 1
        return removed

    async def zrangebyscore(self, name, min_score, max_score, withscores=False):
        if name not in self.data:
            return []
        result = []
        # Handle '+inf' as no upper bound
        max_val = float("inf") if max_score == "+inf" else max_score
        for k, v in self.data[name].items():
            if min_score <= v <= max_val:
                result.append((k, v) if withscores else k)
        return result

    async def sadd(self, name, value):
        if name not in self.data:
            self.data[name] = set()
        self.data[name].add(value)

    async def srem(self, name, value):
        bucket = self.data.get(name)
        if not isinstance(bucket, set):
            return 0
        if value in bucket:
            bucket.remove(value)
            return 1
        return 0

    async def smembers(self, name):
        if name not in self.data:
            return set()
        return self.data[name]

    async def set(self, name, value, nx=False, ex=None):
        if nx and name in self.kv:
            return False
        self.kv[name] = value
        if ex is not None:
            self.expires[name] = ex
        return True

    async def get(self, name):
        return self.kv.get(name)

    async def delete(self, name):
        self.kv.pop(name, None)
        self.data.pop(name, None)

    async def expire(self, name, ttl):
        self.expires[name] = ttl
        return 1

    async def hset(self, name, mapping=None, key=None, value=None):
        if name not in self.data:
            self.data[name] = {}
        if mapping:
            self.data[name].update(mapping)
        else:
            self.data[name][key] = value

    async def hget(self, name, key):
        return self.data.get(name, {}).get(key)

    async def hgetall(self, name):
        return self.data.get(name, {})

    def pipeline(self):
        return MockPipeline(self)


@pytest.mark.asyncio
async def test_register_worker_compatibility_wrapper():
    """Test legacy register_worker wrapper writes membership and liveness."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)
    with pytest.warns(DeprecationWarning, match="register_worker"):
        await registry.register_worker("worker-1", ["super_assistant"])
    assert "worker-1" in redis_mock.data[RedisKeys.ACTIVE_WORKERS]
    assert redis_mock.data[RedisKeys.worker_declared_agent_types("worker-1")] == {
        "super_assistant"
    }


@pytest.mark.asyncio
async def test_unregister_worker_compatibility_wrapper_warns():
    """Test that the legacy unregister_worker wrapper emits a deprecation warning."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)
    await registry.register_worker_membership("worker-1", ["super_assistant"])
    await registry.heartbeat_worker("worker-1")

    with pytest.warns(DeprecationWarning, match="unregister_worker"):
        await registry.unregister_worker("worker-1")

    assert redis_mock.data[RedisKeys.ACTIVE_WORKERS] == {}
    assert RedisKeys.worker_declared_agent_types("worker-1") not in redis_mock.data


@pytest.mark.asyncio
async def test_register_worker_membership_only_updates_membership_sets():
    """Test static membership registration does not mark worker online."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    await registry.register_worker_membership(
        "worker-1", ["super_assistant", "code_agent"]
    )

    assert RedisKeys.ACTIVE_WORKERS not in redis_mock.data
    assert redis_mock.data[RedisKeys.worker_declared_agent_types("worker-1")] == {
        "super_assistant",
        "code_agent",
    }
    assert redis_mock.data[RedisKeys.agent_type_members("super_assistant")] == {
        "worker-1"
    }
    assert redis_mock.data[RedisKeys.agent_type_members("code_agent")] == {"worker-1"}


@pytest.mark.asyncio
async def test_heartbeat_worker_only_updates_active_workers():
    """Test that heartbeat marks liveness without mutating agent-type membership."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    await registry.heartbeat_worker("worker-1")

    assert "worker-1" in redis_mock.data[RedisKeys.ACTIVE_WORKERS]
    assert redis_mock.kv[RedisKeys.worker_online_lease("worker-1")] == "1"
    assert redis_mock.expires[RedisKeys.worker_online_lease("worker-1")] == (
        RedisKeys.WORKER_DEFAULT_LEASE_TTL_SECONDS
    )
    assert RedisKeys.worker_declared_agent_types("worker-1") not in redis_mock.data


@pytest.mark.asyncio
async def test_unregister_worker_membership_only_removes_membership_sets():
    """Test that membership unregister does not mutate worker liveness."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    await registry.register_worker_membership("worker-1", ["super_assistant"])
    await registry.heartbeat_worker("worker-1")
    online_snapshot = dict(redis_mock.data[RedisKeys.ACTIVE_WORKERS])
    await registry.unregister_worker_membership("worker-1")

    assert redis_mock.data[RedisKeys.ACTIVE_WORKERS] == online_snapshot
    assert RedisKeys.worker_declared_agent_types("worker-1") not in redis_mock.data
    assert redis_mock.data[RedisKeys.agent_type_members("super_assistant")] == set()


@pytest.mark.asyncio
async def test_mark_worker_inactive_only_removes_online_state():
    """Test that mark_worker_inactive only removes the online record."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    await registry.register_worker_membership("worker-1", ["super_assistant"])
    await registry.heartbeat_worker("worker-1")
    await registry.mark_worker_inactive("worker-1")

    assert redis_mock.data[RedisKeys.ACTIVE_WORKERS] == {}
    assert RedisKeys.worker_online_lease("worker-1") not in redis_mock.kv
    assert redis_mock.data[RedisKeys.worker_declared_agent_types("worker-1")] == {
        "super_assistant"
    }


@pytest.mark.asyncio
async def test_get_target_worker():
    """Test that WorkerRegistry can find workers by agent type."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)
    await registry.register_worker_membership("worker-1", ["super_assistant"])
    await registry.heartbeat_worker("worker-1")
    await registry.register_worker_membership("worker-2", ["my-agent"])
    await registry.heartbeat_worker("worker-2")

    # Test finding worker by agent type
    worker = await registry.get_target_worker("super_assistant")
    assert worker == "worker-1"

    worker = await registry.get_target_worker("my-agent")
    assert worker == "worker-2"

    # Test not found case
    worker = await registry.get_target_worker("unknown-agent")
    assert worker is None


@pytest.mark.asyncio
async def test_get_target_worker_filters_out_inactive_workers():
    """Test that target worker selection only returns online workers."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    await registry.register_worker_membership("dead-worker", ["super_assistant"])
    await registry.register_worker_membership("online-worker", ["super_assistant"])
    await registry.heartbeat_worker("online-worker")

    workers = await registry.get_online_workers("super_assistant")

    assert workers == ["online-worker"]
    assert await registry.get_target_worker("super_assistant") == "online-worker"


@pytest.mark.asyncio
async def test_check_worker_online_only_uses_lease_presence():
    """Test that stale zset entries without lease are not considered online."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    await redis_mock.zadd(RedisKeys.ACTIVE_WORKERS, {"worker-1": 123456789})

    assert await registry.is_worker_online("worker-1") is False


@pytest.mark.asyncio
async def test_claim_worker_id_duplicate_should_fail():
    """Test that claiming a duplicate worker_id raises ValueError."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    token1 = await registry.claim_worker_id("worker-1")
    assert token1

    with pytest.raises(ValueError):
        await registry.claim_worker_id("worker-1")


@pytest.mark.asyncio
async def test_registry_tracks_execution_lifecycle():
    """Test WorkerRegistry tracks execution lifecycle."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    execution = {
        "execution_id": "exec-1",
        "message_id": "msg-1",
        "session_id": "sess-1",
        "worker_id": "worker-1",
        "target_agent_type": "langgraph_agent",
        "status": "RUNNING",
        "cancel_requested": False,
    }

    await registry.save_execution(execution)

    # Verify that it was saved to session registry
    reg_key = RedisKeys.session_registry("sess-1")
    assert "exec:exec-1" in redis_mock.data[reg_key]
    assert "msg_map:msg-1" in redis_mock.data[reg_key]
    assert redis_mock.expires[reg_key] == RedisKeys.DEFAULT_SESSION_TTL

    found = await registry.get_execution_by_message_id("msg-1", session_id="sess-1")
    assert found["execution_id"] == "exec-1"

    await registry.mark_execution_cancelling("exec-1", "sess-1", "user aborted")
    updated = await registry.get_execution("exec-1", "sess-1")
    assert updated["status"] == "CANCELLING"
    assert updated["cancel_requested"] is True
    assert updated["cancel_reason"] == "user aborted"

    await registry.mark_execution_finished("exec-1", "sess-1", "CANCELLED")
    finished = await registry.get_execution("exec-1", "sess-1")
    assert finished["status"] == "CANCELLED"


@pytest.mark.asyncio
async def test_has_online_agent_type():
    """Test has_online_agent_type returns correct status and worker list."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)
    await registry.register_worker_membership(
        "worker-1", ["super_assistant", "code_agent"]
    )
    await registry.heartbeat_worker("worker-1")
    await registry.register_worker_membership("worker-2", ["super_assistant"])
    await registry.heartbeat_worker("worker-2")

    # Test with workers registered and online
    exists, workers = await registry.has_online_agent_type("super_assistant")
    assert exists is True
    assert set(workers) == {"worker-1", "worker-2"}

    # Test with single worker
    exists, workers = await registry.has_online_agent_type("code_agent")
    assert exists is True
    assert set(workers) == {"worker-1"}

    # Test with no workers
    exists, workers = await registry.has_online_agent_type("unknown_agent")
    assert exists is False
    assert workers == []


@pytest.mark.asyncio
async def test_has_online_agent_type_filters_offline_workers():
    """Test has_online_agent_type filters offline workers with check_active=True."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)

    # Manually register agent types WITHOUT active heartbeat
    await redis_mock.sadd(RedisKeys.agent_type_members("inactive_agent"), "dead_worker")
    await redis_mock.sadd(
        RedisKeys.worker_declared_agent_types("dead_worker"), "inactive_agent"
    )

    # With check_active=True (default), dead worker should not be found
    exists, workers = await registry.has_online_agent_type(
        "inactive_agent", check_active=True
    )
    assert exists is False
    assert workers == []

    # With check_active=False, dead worker should be found
    exists, workers = await registry.has_online_agent_type(
        "inactive_agent", check_active=False
    )
    assert exists is True
    assert workers == ["dead_worker"]


@pytest.mark.asyncio
async def test_is_worker_online():
    """Test that is_worker_online correctly checks worker lease state."""
    redis_mock = MockRedis()
    registry = WorkerRegistry(redis_mock)
    await registry.register_worker_membership("online_worker", ["test_agent"])
    await registry.heartbeat_worker("online_worker")

    # Worker with an active lease should be online
    is_online = await registry.is_worker_online("online_worker")
    assert is_online is True

    # Unknown worker should not be online
    is_online = await registry.is_worker_online("unknown_worker")
    assert is_online is False
