# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Standardized Open Source governance files (CONTRIBUTING, CODE_OF_CONDUCT, SECURITY).
- GitHub Issue and Pull Request templates.
- Dependabot configuration for dependency monitoring.

## [1.0.0] - 2026-04-30
### Added
- Initial release of by-framework-python.
- Distributed worker coordination using Redis Streams.
- Plugin-based agent capability registration.
- AgentContext for state, chunk, and artifact management.
- Standardized message protocol (AskAgentCommand, etc.).
- Workspace-based task execution.
