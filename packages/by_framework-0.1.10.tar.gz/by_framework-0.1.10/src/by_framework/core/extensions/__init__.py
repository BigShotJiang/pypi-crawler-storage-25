"""
Plugin system module - Provides pluggable Worker extension mechanism.

This module implements a standardized plugin registration and management
system, allowing business logic (such as tools, prompts, skills, callbacks)
to be decoupled from Worker infrastructure, and dynamically injected and
managed through the form of plugins.
"""

from .agent_config import AgentConfig, CallbackType
from .plugin import Plugin, PluginBuildContext, PluginManifest, PromptTemplate
from .registry import PluginRegistry

__all__ = [
    "AgentConfig",
    "CallbackType",
    "PluginManifest",
    "Plugin",
    "PluginBuildContext",
    "PromptTemplate",
    "PluginRegistry",
]
