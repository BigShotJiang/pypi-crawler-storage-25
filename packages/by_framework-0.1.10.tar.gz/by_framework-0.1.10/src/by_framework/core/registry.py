"""
Worker registry module.

Provides worker registration, discovery, and execution tracking
through Redis-backed storage.
"""

import json
import logging
import random
import time
import uuid
import warnings
from typing import Any, List, Optional

from by_framework.common.constants import (EXEC_FIELD_PREFIX, MSG_MAP_PREFIX, RedisKeys)
from by_framework.common.exceptions import ExecutionDataError
from by_framework.common.redis_client import Redis, get_redis

logger = logging.getLogger("by_framework.registry")


# --- Standalone agent type probing functions (usable without WorkerRegistry) ---


async def check_worker_online(
    redis: Redis,
    worker_id: str,
) -> bool:
    """Check if the specified worker is active.

    Args:
        redis: Redis client instance.
        worker_id: Worker ID.
    Returns:
        Whether the worker is active.
    """
    lease_value = await redis.get(RedisKeys.worker_online_lease(worker_id))
    return lease_value is not None


async def check_agent_type_online(
    redis: Redis,
    agent_type: str,
    check_active: bool = True,
) -> tuple[bool, List[str]]:
    """Check if there are registered and active workers for the agent type.

    Args:
        redis: Redis client instance.
        agent_type: Agent type identifier.
        check_active: Whether to check worker active status (default True).
    Returns:
        (Whether there are active workers, list of active worker IDs)
    """
    workers = await redis.smembers(RedisKeys.agent_type_members(agent_type))
    if not workers:
        return (False, [])

    worker_ids = [w.decode() if isinstance(w, bytes) else w for w in workers]

    if check_active:
        online_worker_ids = []
        for worker_id in worker_ids:
            if await check_worker_online(redis, worker_id):
                online_worker_ids.append(worker_id)
        worker_ids = online_worker_ids

    return (len(worker_ids) > 0, worker_ids)


class WorkerRegistry:
    """Worker registry responsible for worker registration, discovery, and execution.

    Stores worker information and execution state through Redis sorted sets
    and Hash structures.
    """

    def __init__(self, redis_client: Optional[Redis] = None):
        self.redis = redis_client or get_redis()
        self._lock_tokens: dict[str, str] = {}

    async def register_worker_membership(
        self, worker_id: str, agent_types: List[str]
    ) -> None:
        for agent_type in agent_types:
            await self.redis.sadd(
                RedisKeys.worker_declared_agent_types(worker_id), agent_type
            )
            await self.redis.sadd(RedisKeys.agent_type_members(agent_type), worker_id)

    async def heartbeat_worker(
        self,
        worker_id: str,
        lease_ttl_seconds: int = RedisKeys.WORKER_DEFAULT_LEASE_TTL_SECONDS,
    ) -> None:
        now = int(time.time() * 1000)
        await self.redis.zadd(RedisKeys.ACTIVE_WORKERS, {worker_id: now})
        await self.redis.set(
            RedisKeys.worker_online_lease(worker_id),
            "1",
            ex=lease_ttl_seconds,
        )

    async def register_worker(self, worker_id: str, agent_types: List[str]):
        """Compatibility wrapper for callers that couple registration and heartbeat."""
        warnings.warn(
            "WorkerRegistry.register_worker() is deprecated; use "
            "register_worker_membership() plus heartbeat_worker() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        await self.register_worker_membership(worker_id, agent_types)
        await self.heartbeat_worker(worker_id)

    async def unregister_worker_membership(self, worker_id: str) -> None:
        """Remove static worker-agent-type membership without mutating liveness."""
        agent_types_raw = await self.redis.smembers(
            RedisKeys.worker_declared_agent_types(worker_id)
        )
        await self.redis.delete(RedisKeys.worker_declared_agent_types(worker_id))
        for agent_type_raw in agent_types_raw:
            agent_type = (
                agent_type_raw.decode()
                if isinstance(agent_type_raw, bytes)
                else agent_type_raw
            )
            await self.redis.srem(RedisKeys.agent_type_members(agent_type), worker_id)

    async def mark_worker_inactive(self, worker_id: str) -> None:
        await self.redis.delete(RedisKeys.worker_online_lease(worker_id))
        await self.redis.zrem(RedisKeys.ACTIVE_WORKERS, worker_id)

    async def unregister_worker(self, worker_id: str):
        """Compatibility wrapper for callers that couple deregistration and liveness."""
        warnings.warn(
            "WorkerRegistry.unregister_worker() is deprecated; use "
            "mark_worker_inactive() plus unregister_worker_membership() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        await self.mark_worker_inactive(worker_id)
        await self.unregister_worker_membership(worker_id)

    async def get_online_workers(
        self,
        agent_type: str,
    ) -> List[str]:
        _, worker_ids = await check_agent_type_online(
            self.redis,
            agent_type,
            check_active=True,
        )
        return worker_ids

    async def get_random_online_worker(
        self,
        agent_type: str,
    ) -> Optional[str]:
        workers = await self.get_online_workers(agent_type)
        if not workers:
            return None
        return random.choice(workers)

    async def get_target_worker(self, agent_id: str) -> Optional[str]:
        return await self.get_random_online_worker(agent_id)

    async def is_worker_online(
        self,
        worker_id: str,
    ) -> bool:
        """Check if the specified worker is active.

        Args:
            worker_id: Worker ID.

        Returns:
            Whether the worker is active.
        """
        return await check_worker_online(self.redis, worker_id)

    async def has_online_agent_type(
        self,
        agent_type: str,
        check_active: bool = True,
    ) -> tuple[bool, List[str]]:
        """Check if there are registered and active workers for the agent type.

        Args:
            agent_type: Agent type identifier.
            check_active: Whether to check worker active status (default True).
        Returns:
            (Whether there are active workers, list of active worker IDs)
        """
        return await check_agent_type_online(self.redis, agent_type, check_active)

    async def get_all_workers(self) -> dict[str, Any]:
        """Get all registered Worker information.

        Returns:
            Dictionary containing all worker IDs with their capabilities
            and last active time.
        """
        redis_inst = self.redis
        worker_ids = await redis_inst.zrange(
            RedisKeys.ACTIVE_WORKERS, 0, -1, withscores=True
        )

        result = {}
        for worker_id_raw, score in worker_ids:
            worker_id = (
                worker_id_raw.decode()
                if isinstance(worker_id_raw, bytes)
                else worker_id_raw
            )
            agent_types_raw = await redis_inst.smembers(
                RedisKeys.worker_declared_agent_types(worker_id)
            )
            agent_types = [
                c.decode() if isinstance(c, bytes) else c for c in agent_types_raw
            ]
            result[worker_id] = {
                "agent_types": agent_types,
                "last_seen": int(score) if score else 0,
            }
        return result

    async def claim_worker_id(self, worker_id: str, ttl_seconds: int = 60) -> str:
        """Attempt to acquire an exclusive lock for Worker ID.

        Args:
            worker_id: Worker ID to acquire lock for
            ttl_seconds: Lock TTL in seconds

        Returns:
            Lock token

        Raises:
            ValueError: If worker_id is already in use
        """
        token = uuid.uuid4().hex
        ok = await self.redis.set(
            RedisKeys.worker_lock(worker_id),
            token,
            nx=True,
            ex=ttl_seconds,
        )
        if not ok:
            raise ValueError(f"worker_id already in use: {worker_id}")
        self._lock_tokens[worker_id] = token
        return token

    async def refresh_worker_id_lock(
        self, worker_id: str, ttl_seconds: int = 60
    ) -> bool:
        """Refresh the TTL of the Worker ID lock.

        Args:
            worker_id: Worker ID
            ttl_seconds: New TTL in seconds

        Returns:
            True if refresh succeeded, otherwise False
        """
        token = self._lock_tokens.get(worker_id)
        if not token:
            return False

        current = await self.redis.get(RedisKeys.worker_lock(worker_id))
        if isinstance(current, bytes):
            current = current.decode("utf-8")
        if current != token:
            return False

        result = await self.redis.expire(RedisKeys.worker_lock(worker_id), ttl_seconds)
        return bool(result)

    async def release_worker_id(
        self, worker_id: str, token: Optional[str] = None
    ) -> bool:
        """Release the exclusive lock for Worker ID.

        Args:
            worker_id: Worker ID
            token: Optional lock token

        Returns:
            True if release succeeded, otherwise False
        """
        expected = token or self._lock_tokens.get(worker_id)
        if not expected:
            return False

        key = RedisKeys.worker_lock(worker_id)
        current = await self.redis.get(key)
        if isinstance(current, bytes):
            current = current.decode("utf-8")
        if current != expected:
            return False

        await self.redis.delete(key)
        self._lock_tokens.pop(worker_id, None)
        return True

    async def initialize_execution(self, execution: dict[str, Any]):
        """Initialize Execution on sender side (status QUEUED) with first timeline
        record.

        Args:
            execution: Execution info dict containing execution_id, message_id,
                session_id, etc.
        """
        now = int(time.time() * 1000)
        execution["created_at"] = now
        execution["updated_at"] = now
        execution.setdefault("started_at", 0)
        execution.setdefault("finished_at", 0)
        if "timeline" not in execution:
            execution["timeline"] = [
                {"status": execution.get("status", "QUEUED"), "timestamp": now}
            ]

        execution_id = execution["execution_id"]
        message_id = execution["message_id"]
        session_id = execution["session_id"]

        reg_key = RedisKeys.session_registry(session_id)
        encoded_data = json.dumps(execution, ensure_ascii=False)

        # Use Pipeline to ensure atomicity and set TTL
        pipe = self.redis.pipeline()
        pipe.hset(reg_key, f"{EXEC_FIELD_PREFIX}{execution_id}", encoded_data)
        pipe.hset(reg_key, f"{MSG_MAP_PREFIX}{message_id}", execution_id)
        pipe.expire(reg_key, RedisKeys.DEFAULT_SESSION_TTL)
        await pipe.execute()

    async def update_execution_status(
        self, execution_id: str, session_id: str, status: str, **kwargs
    ):
        """Update existing execution record's status and append to timeline."""
        current = await self.get_execution(execution_id, session_id)
        if current is None:
            return

        now = int(time.time() * 1000)
        current["status"] = status
        current["updated_at"] = now
        if status == "RUNNING" and current.get("started_at", 0) == 0:
            current["started_at"] = now

        for key, value in kwargs.items():
            current[key] = value

        timeline = current.get("timeline", [])
        timeline.append({"status": status, "timestamp": now})
        current["timeline"] = timeline

        reg_key = RedisKeys.session_registry(session_id)
        pipe = self.redis.pipeline()
        pipe.hset(
            reg_key,
            f"{EXEC_FIELD_PREFIX}{execution_id}",
            json.dumps(current, ensure_ascii=False),
        )
        pipe.expire(reg_key, RedisKeys.DEFAULT_SESSION_TTL)
        await pipe.execute()

    async def update_execution_status_by_message(
        self, message_id: str, session_id: str, status: str
    ):
        """Update specific execution status by message_id and append to timeline"""
        execution = await self.get_execution_by_message_id(message_id, session_id)
        if not execution:
            return
        await self.update_execution_status(
            execution["execution_id"], session_id, status
        )

    async def save_execution(self, execution: dict[str, Any]):
        """(Compatibility) Save execution data to Redis.

        Recommend using initialize_execution first.

        Args:
            execution: Execution info dict containing execution_id,
                message_id, session_id, etc.
        """
        now = int(time.time() * 1000)
        if "created_at" not in execution or execution["created_at"] == 0:
            execution["created_at"] = now
        if "updated_at" not in execution or execution["updated_at"] == 0:
            execution["updated_at"] = now

        if "timeline" not in execution:
            execution["timeline"] = [
                {"status": execution.get("status", "RUNNING"), "timestamp": now}
            ]

        execution_id = execution["execution_id"]
        message_id = execution["message_id"]
        session_id = execution["session_id"]

        reg_key = RedisKeys.session_registry(session_id)
        encoded_data = json.dumps(execution, ensure_ascii=False)

        # Use Pipeline to ensure atomicity and set TTL
        pipe = self.redis.pipeline()
        pipe.hset(reg_key, f"{EXEC_FIELD_PREFIX}{execution_id}", encoded_data)
        pipe.hset(reg_key, f"{MSG_MAP_PREFIX}{message_id}", execution_id)
        pipe.expire(reg_key, RedisKeys.DEFAULT_SESSION_TTL)
        await pipe.execute()

    async def get_execution(
        self, execution_id: str, session_id: str = ""
    ) -> Optional[dict[str, Any]]:
        """
        Get execution details.

        Note: In the new architecture, callers should provide session_id to
        optimize query performance. If session_id is not provided, global
        search is needed (which is not recommended).
        """
        if not session_id:
            logger.warning(
                "get_execution called without session_id, this is inefficient in the "
                "new registry architecture."
            )
            # Compatibility logic: if session_id is truly unavailable, may need to
            # scan all or return error
            return None

        reg_key = RedisKeys.session_registry(session_id)
        data = await self.redis.hget(reg_key, f"{EXEC_FIELD_PREFIX}{execution_id}")
        if not data:
            return None

        if isinstance(data, bytes):
            data = data.decode("utf-8")

        try:
            return json.loads(data)
        except json.JSONDecodeError as err:
            raise ExecutionDataError(execution_id, cause=err) from err

    async def get_execution_by_message_id(
        self, message_id: str, session_id: str = ""
    ) -> Optional[dict[str, Any]]:
        """
        Get execution details by message_id.
        """
        if not session_id:
            # In some flows (like cancellation), only message_id may be available.
            # To support this, we maintain session_id passing on the GatewayClient side.
            return None

        reg_key = RedisKeys.session_registry(session_id)
        execution_id = await self.redis.hget(reg_key, f"{MSG_MAP_PREFIX}{message_id}")
        if isinstance(execution_id, bytes):
            execution_id = execution_id.decode("utf-8")

        if not execution_id:
            return None
        return await self.get_execution(execution_id, session_id)

    async def mark_execution_cancelling(
        self, execution_id: str, session_id: str, reason: str
    ):
        """Mark execution status as CANCELLING.

        Args:
            execution_id: Execution ID
            session_id: Session ID
            reason: Cancellation reason
        """
        current = await self.get_execution(execution_id, session_id)
        if current is None:
            return

        current["status"] = "CANCELLING"
        current["cancel_requested"] = True
        current["cancel_reason"] = reason
        now = int(time.time() * 1000)
        current["updated_at"] = now

        timeline = current.get("timeline", [])
        timeline.append({"status": "CANCELLING", "timestamp": now})
        current["timeline"] = timeline

        reg_key = RedisKeys.session_registry(session_id)
        pipe = self.redis.pipeline()
        pipe.hset(
            reg_key,
            f"{EXEC_FIELD_PREFIX}{execution_id}",
            json.dumps(current, ensure_ascii=False),
        )
        pipe.expire(reg_key, RedisKeys.DEFAULT_SESSION_TTL)
        await pipe.execute()

    async def mark_cancel_requested(
        self, execution_id: str, session_id: str, reason: str = ""
    ):
        """Only mark the cancel_requested flag, do not change execution status.

        Used in cascade cancellation scenarios to mark completed (COMPLETED)
        parent nodes, so that cancelled child agents know they don't need to
        callback and wake up the parent.

        Args:
            execution_id: Execution ID
            session_id: Session ID
            reason: Cancellation reason
        """
        current = await self.get_execution(execution_id, session_id)
        if current is None:
            return

        current["cancel_requested"] = True
        if reason:
            current["cancel_reason"] = reason
        current["updated_at"] = int(time.time() * 1000)

        reg_key = RedisKeys.session_registry(session_id)
        pipe = self.redis.pipeline()
        pipe.hset(
            reg_key,
            f"{EXEC_FIELD_PREFIX}{execution_id}",
            json.dumps(current, ensure_ascii=False),
        )
        pipe.expire(reg_key, RedisKeys.DEFAULT_SESSION_TTL)
        await pipe.execute()

    async def mark_execution_finished(
        self, execution_id: str, session_id: str, status: str
    ):
        """Mark execution as finished status.

        Args:
            execution_id: Execution ID
            session_id: Session ID
            status: Final status
        """
        current = await self.get_execution(execution_id, session_id)
        if current is None:
            return

        current["status"] = status
        now = int(time.time() * 1000)
        current["finished_at"] = now
        current["updated_at"] = now

        timeline = current.get("timeline", [])
        timeline.append({"status": status, "timestamp": now})
        current["timeline"] = timeline

        reg_key = RedisKeys.session_registry(session_id)
        pipe = self.redis.pipeline()
        pipe.hset(
            reg_key,
            f"{EXEC_FIELD_PREFIX}{execution_id}",
            json.dumps(current, ensure_ascii=False),
        )
        pipe.expire(reg_key, RedisKeys.DEFAULT_SESSION_TTL)
        await pipe.execute()

    async def get_all_session_executions(self, session_id: str) -> list[dict[str, Any]]:
        """Get all execution records under the specified Session.

        Used in cascade cancellation scenarios, fetches the entire Session's
        registry data through HGETALL at once, filters out all entries with
        exec: prefix and deserializes them.

        Args:
            session_id: Session ID

        Returns:
            List of all execution records under this session
        """
        reg_key = RedisKeys.session_registry(session_id)
        all_data = await self.redis.hgetall(reg_key)
        executions = []
        for field, value in all_data.items():
            field_str = field.decode() if isinstance(field, bytes) else field
            if not field_str.startswith(EXEC_FIELD_PREFIX):
                continue
            value_str = value.decode("utf-8") if isinstance(value, bytes) else value
            try:
                executions.append(json.loads(value_str))
            except json.JSONDecodeError:
                continue
        return executions

    def _encode_execution(self, execution: dict[str, Any]) -> dict[str, str]:  # pylint: disable=unused-argument
        # Deprecated, since we switched to JSON storage
        return {}

    def _decode_execution(self, execution: dict[str, Any]) -> dict[str, Any]:  # pylint: disable=unused-argument
        # Deprecated, since we switched to JSON storage
        return {}
