# Copyright (C) 2019 Renato Lima - Akretion <renato.lima@akretion.com.br>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

{
    "name": "Currency Rate Update BR",
    "summary": "Update exchange rates using OCA modules for Brazil",
    "version": "18.0.1.0.2",
    "author": "Akretion, " "Odoo Community Association (OCA)",
    "maintainers": ["renatonlima"],
    "website": "https://github.com/OCA/l10n-brazil",
    "license": "AGPL-3",
    "category": "Financial Management/Configuration",
    "depends": ["currency_rate_update"],
    "development_status": "Beta",
    "installable": True,
}
