from __future__ import annotations

import subprocess
from datetime import UTC, datetime
from pathlib import Path

import pytest

from cooldown_guard.project import load_ledger, load_pyproject
from cooldown_guard.service import CooldownGuardService
from cooldown_guard.time_utils import format_utc


class FakeIndex:
    def __init__(self, upload_time: datetime) -> None:
        self.upload_time = upload_time

    def get_upload_time(self, package: str, version: str) -> datetime:
        assert package == "urllib3"
        assert version == "2.7.0"
        return self.upload_time


def write_project(root: Path) -> None:
    (root / "pyproject.toml").write_text(
        """
[project]
name = "demo"
version = "0.1.0"

[tool.uv]
exclude-newer = "7 days"
""".strip()
    )


def test_approve_writes_constraint_override_and_ledger(tmp_path: Path) -> None:
    write_project(tmp_path)
    upload_time = datetime(2026, 5, 7, 16, 13, 17, tzinfo=UTC)
    calls: list[Path] = []
    service = CooldownGuardService(
        package_index=FakeIndex(upload_time),
        now=lambda: datetime(2026, 5, 13, 12, 0, 0, tzinfo=UTC),
        uv_lock_runner=lambda root: calls.append(root),
    )

    entry = service.approve(
        project_root=tmp_path,
        spec="urllib3==2.7.0",
        approved_by="alice",
        reason="security fix",
        advisory="CVE-2026-12345",
        introduced_via=["requests"],
    )

    assert calls == [tmp_path.resolve()]
    doc = load_pyproject(tmp_path / "pyproject.toml")
    assert doc["tool"]["uv"]["exclude-newer-package"]["urllib3"] == "2026-05-07T16:13:18Z"
    assert "urllib3==2.7.0" in doc["tool"]["uv"]["constraint-dependencies"]
    assert entry.relax_to == "urllib3>=2.7.0"

    ledger = load_ledger(tmp_path / ".cooldown-guard.toml")
    assert ledger.exceptions[0].approved_by == "alice"
    assert format_utc(ledger.exceptions[0].cooldown_ends_at) == "2026-05-14T16:13:17Z"


def test_validate_reports_missing_constraint(tmp_path: Path) -> None:
    write_project(tmp_path)
    (tmp_path / "pyproject.toml").write_text(
        """
[project]
name = "demo"
version = "0.1.0"

[tool.uv]
exclude-newer = "7 days"
exclude-newer-package = { urllib3 = "2026-05-07T16:13:18Z" }
""".strip()
    )
    (tmp_path / ".cooldown-guard.toml").write_text(
        """
version = 1

[[exceptions]]
package = "urllib3"
version = "2.7.0"
constraint = "urllib3==2.7.0"
relax_to = "urllib3>=2.7.0"
approved_by = "alice"
approved_at = "2026-05-13T12:00:00Z"
reason = "security fix"
introduced_via = ["requests"]
upload_time = "2026-05-07T16:13:17Z"
package_cutoff = "2026-05-07T16:13:18Z"
cooldown_ends_at = "2026-05-14T16:13:17Z"
state = "active"
""".strip()
    )

    errors = CooldownGuardService().validate(tmp_path)
    assert errors == ["urllib3: missing constraint urllib3==2.7.0"]


def test_cleanup_check_reports_ready_without_mutating_files(tmp_path: Path) -> None:
    write_project(tmp_path)
    (tmp_path / "pyproject.toml").write_text(
        """
[project]
name = "demo"
version = "0.1.0"

[tool.uv]
exclude-newer = "7 days"
exclude-newer-package = { urllib3 = "2026-05-07T16:13:18Z" }
constraint-dependencies = ["urllib3==2.7.0"]
""".strip()
    )
    (tmp_path / ".cooldown-guard.toml").write_text(
        """
version = 1

[[exceptions]]
package = "urllib3"
version = "2.7.0"
constraint = "urllib3==2.7.0"
relax_to = "urllib3>=2.7.0"
approved_by = "alice"
approved_at = "2026-05-13T12:00:00Z"
reason = "security fix"
introduced_via = ["requests"]
upload_time = "2026-05-07T16:13:17Z"
package_cutoff = "2026-05-07T16:13:18Z"
cooldown_ends_at = "2026-05-14T16:13:17Z"
state = "active"
""".strip()
    )
    original = (tmp_path / "pyproject.toml").read_text()
    service = CooldownGuardService(
        now=lambda: datetime(2026, 5, 15, 12, 0, 0, tzinfo=UTC),
        uv_lock_runner=lambda root: None,
    )

    results = service.cleanup(tmp_path, apply=False)

    assert [(result.package, result.state) for result in results] == [("urllib3", "ready")]
    assert (tmp_path / "pyproject.toml").read_text() == original


def test_cleanup_apply_relaxes_constraint_and_marks_ledger(tmp_path: Path) -> None:
    write_project(tmp_path)
    (tmp_path / "pyproject.toml").write_text(
        """
[project]
name = "demo"
version = "0.1.0"

[tool.uv]
exclude-newer = "7 days"
exclude-newer-package = { urllib3 = "2026-05-07T16:13:18Z" }
constraint-dependencies = ["urllib3==2.7.0"]
""".strip()
    )
    (tmp_path / ".cooldown-guard.toml").write_text(
        """
version = 1

[[exceptions]]
package = "urllib3"
version = "2.7.0"
constraint = "urllib3==2.7.0"
relax_to = "urllib3>=2.7.0"
approved_by = "alice"
approved_at = "2026-05-13T12:00:00Z"
reason = "security fix"
introduced_via = ["requests"]
upload_time = "2026-05-07T16:13:17Z"
package_cutoff = "2026-05-07T16:13:18Z"
cooldown_ends_at = "2026-05-14T16:13:17Z"
state = "active"
""".strip()
    )
    service = CooldownGuardService(
        now=lambda: datetime(2026, 5, 15, 12, 0, 0, tzinfo=UTC),
        uv_lock_runner=lambda root: None,
    )

    results = service.cleanup(tmp_path, apply=True)

    assert [(result.package, result.state) for result in results] == [("urllib3", "cleaned")]
    doc = load_pyproject(tmp_path / "pyproject.toml")
    assert "exclude-newer-package" not in doc["tool"]["uv"]
    assert doc["tool"]["uv"]["constraint-dependencies"] == ["urllib3>=2.7.0"]
    ledger = load_ledger(tmp_path / ".cooldown-guard.toml")
    assert ledger.exceptions[0].state == "cleaned"


def test_cleanup_reports_blocked_if_uv_lock_fails(tmp_path: Path) -> None:
    write_project(tmp_path)
    (tmp_path / "pyproject.toml").write_text(
        """
[project]
name = "demo"
version = "0.1.0"

[tool.uv]
exclude-newer = "7 days"
exclude-newer-package = { urllib3 = "2026-05-07T16:13:18Z" }
constraint-dependencies = ["urllib3==2.7.0"]
""".strip()
    )
    (tmp_path / ".cooldown-guard.toml").write_text(
        """
version = 1

[[exceptions]]
package = "urllib3"
version = "2.7.0"
constraint = "urllib3==2.7.0"
relax_to = "urllib3>=2.7.0"
approved_by = "alice"
approved_at = "2026-05-13T12:00:00Z"
reason = "security fix"
introduced_via = ["requests"]
upload_time = "2026-05-07T16:13:17Z"
package_cutoff = "2026-05-07T16:13:18Z"
cooldown_ends_at = "2026-05-14T16:13:17Z"
state = "active"
""".strip()
    )

    def fail(_: Path) -> None:
        raise subprocess.CalledProcessError(1, ["uv", "lock"], stderr="resolution failed")

    service = CooldownGuardService(
        now=lambda: datetime(2026, 5, 15, 12, 0, 0, tzinfo=UTC),
        uv_lock_runner=fail,
    )

    results = service.cleanup(tmp_path, apply=False)

    assert [(result.package, result.state, result.detail) for result in results] == [
        ("urllib3", "blocked", "resolution failed")
    ]
