"""artifact smoke tests for pypi publishing."""

from __future__ import annotations

import subprocess
import sys


def test_import_package() -> None:
    import cooldown_guard

    assert cooldown_guard.__version__


def test_import_core_api() -> None:
    from cooldown_guard.project import load_ledger, load_pyproject
    from cooldown_guard.service import CooldownGuardService

    assert CooldownGuardService is not None
    assert callable(load_pyproject)
    assert callable(load_ledger)


def test_cli_help() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "cooldown_guard.cli", "--help"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert "approve" in result.stdout
    assert "cleanup" in result.stdout
