from __future__ import annotations

from datetime import UTC, datetime
from typing import Literal

from pydantic import BaseModel, Field


class CooldownException(BaseModel):
    package: str
    version: str
    constraint: str
    relax_to: str
    approved_by: str
    approved_at: datetime
    reason: str
    advisory: str | None = None
    severity: str | None = None
    introduced_via: list[str] = Field(default_factory=list)
    upload_time: datetime
    package_cutoff: datetime
    cooldown_ends_at: datetime | None = None
    state: Literal["active", "cleaned"] = "active"
    cleaned_at: datetime | None = None
    cleanup_resolution: str | None = None

    def as_toml_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "package": self.package,
            "version": self.version,
            "constraint": self.constraint,
            "relax_to": self.relax_to,
            "approved_by": self.approved_by,
            "approved_at": _format_datetime(self.approved_at),
            "reason": self.reason,
            "introduced_via": self.introduced_via,
            "upload_time": _format_datetime(self.upload_time),
            "package_cutoff": _format_datetime(self.package_cutoff),
            "state": self.state,
        }
        if self.advisory is not None:
            payload["advisory"] = self.advisory
        if self.severity is not None:
            payload["severity"] = self.severity
        if self.cooldown_ends_at is not None:
            payload["cooldown_ends_at"] = _format_datetime(self.cooldown_ends_at)
        if self.cleaned_at is not None:
            payload["cleaned_at"] = _format_datetime(self.cleaned_at)
        if self.cleanup_resolution is not None:
            payload["cleanup_resolution"] = self.cleanup_resolution
        return payload


class Ledger(BaseModel):
    version: int = 1
    exceptions: list[CooldownException] = Field(default_factory=list)

    def active_exceptions(self) -> list[CooldownException]:
        return [entry for entry in self.exceptions if entry.state == "active"]

    def get_active(self, package: str) -> CooldownException | None:
        for entry in self.exceptions:
            if entry.package == package and entry.state == "active":
                return entry
        return None

    def upsert(self, entry: CooldownException) -> None:
        for index, current in enumerate(self.exceptions):
            if current.package == entry.package and current.state == entry.state:
                self.exceptions[index] = entry
                return
        self.exceptions.append(entry)


def _format_datetime(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")
