from __future__ import annotations

from contextlib import AbstractContextManager
from dataclasses import dataclass
from pathlib import Path
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name
from tomlkit import array, document, inline_table, parse, table
from tomlkit.container import Container
from tomlkit.exceptions import ParseError
from tomlkit.items import Array, InlineTable, Table
from tomlkit.toml_document import TOMLDocument

from cooldown_guard.models import CooldownException, Ledger
from cooldown_guard.time_utils import parse_rfc3339

LEDGER_FILENAME = ".cooldown-guard.toml"


class ProjectConfigError(RuntimeError):
    pass


@dataclass(slots=True)
class ProjectPaths:
    root: Path
    pyproject: Path
    ledger: Path
    lockfile: Path


def project_paths(root: Path) -> ProjectPaths:
    resolved = root.resolve()
    return ProjectPaths(
        root=resolved,
        pyproject=resolved / "pyproject.toml",
        ledger=resolved / LEDGER_FILENAME,
        lockfile=resolved / "uv.lock",
    )


def load_pyproject(path: Path) -> TOMLDocument:
    try:
        return parse(path.read_text())
    except FileNotFoundError as exc:
        raise ProjectConfigError(f"missing pyproject.toml at {path}") from exc
    except ParseError as exc:
        raise ProjectConfigError(f"failed to parse {path}: {exc}") from exc


def save_pyproject(path: Path, doc: TOMLDocument) -> None:
    path.write_text(doc.as_string())


def load_ledger(path: Path) -> Ledger:
    if not path.exists():
        return Ledger()

    payload = parse(path.read_text())
    exceptions = [
        _load_exception(dict(item))
        for item in payload.get("exceptions", [])
    ]
    version = int(payload.get("version", 1))
    return Ledger(version=version, exceptions=exceptions)


def save_ledger(path: Path, ledger: Ledger) -> None:
    doc = document()
    doc["version"] = ledger.version
    entries = []
    for entry in ledger.exceptions:
        entries.append(entry.as_toml_dict())
    doc["exceptions"] = entries
    path.write_text(doc.as_string())


def get_global_exclude_newer(doc: TOMLDocument) -> str:
    uv_table = _ensure_uv_table(doc)
    exclude_newer = uv_table.get("exclude-newer")
    if not isinstance(exclude_newer, str):
        raise ProjectConfigError("target project is missing [tool.uv].exclude-newer")
    return exclude_newer


def ensure_package_cutoff(doc: TOMLDocument, package: str, cutoff: str) -> None:
    uv_table = _ensure_uv_table(doc)
    mapping = uv_table.get("exclude-newer-package")
    if mapping is None:
        mapping = inline_table()
        uv_table["exclude-newer-package"] = mapping
    if not isinstance(mapping, (InlineTable, Table)):
        raise ProjectConfigError("[tool.uv].exclude-newer-package must be a table")
    mapping[package] = cutoff


def remove_package_cutoff(doc: TOMLDocument, package: str) -> None:
    uv_table = _ensure_uv_table(doc)
    mapping = uv_table.get("exclude-newer-package")
    if not isinstance(mapping, (InlineTable, Table)):
        return
    if package in mapping:
        del mapping[package]
    if not mapping:
        del uv_table["exclude-newer-package"]


def get_package_cutoff(doc: TOMLDocument, package: str) -> str | None:
    uv_table = _ensure_uv_table(doc)
    mapping = uv_table.get("exclude-newer-package")
    if not isinstance(mapping, (InlineTable, Table)):
        return None
    value = mapping.get(package)
    return value if isinstance(value, str) else None


def replace_constraint(doc: TOMLDocument, package: str, new_constraint: str) -> None:
    uv_table = _ensure_uv_table(doc)
    constraints = _ensure_constraint_array(uv_table)
    filtered = [value for value in constraints if _requirement_name(value) != package]
    filtered.append(new_constraint)
    uv_table["constraint-dependencies"] = array().multiline(True)
    for value in filtered:
        uv_table["constraint-dependencies"].append(value)


def remove_constraint(doc: TOMLDocument, package: str) -> None:
    uv_table = _ensure_uv_table(doc)
    constraints = uv_table.get("constraint-dependencies")
    if not isinstance(constraints, Array):
        return
    filtered = [value for value in constraints if _requirement_name(value) != package]
    if filtered:
        new_array = array().multiline(True)
        for value in filtered:
            new_array.append(value)
        uv_table["constraint-dependencies"] = new_array
    else:
        del uv_table["constraint-dependencies"]


def has_constraint(doc: TOMLDocument, package: str, expected: str) -> bool:
    uv_table = _ensure_uv_table(doc)
    constraints = uv_table.get("constraint-dependencies")
    if not isinstance(constraints, Array):
        return False
    normalized_package = canonicalize_name(package)
    for value in constraints:
        if not isinstance(value, str):
            continue
        if canonicalize_name(_requirement_name(value)) == normalized_package and value == expected:
            return True
    return False


def project_transaction(paths: ProjectPaths) -> "ProjectTransaction":
    return ProjectTransaction(paths)


class ProjectTransaction(AbstractContextManager["ProjectTransaction"]):
    def __init__(self, paths: ProjectPaths) -> None:
        self._paths = paths
        self._snapshots: dict[Path, bytes | None] = {}
        self._committed = False

    def __enter__(self) -> "ProjectTransaction":
        for path in [self._paths.pyproject, self._paths.ledger, self._paths.lockfile]:
            self._snapshots[path] = path.read_bytes() if path.exists() else None
        return self

    def commit(self) -> None:
        self._committed = True

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._committed and exc is None:
            return None
        for path, snapshot in self._snapshots.items():
            if snapshot is None:
                if path.exists():
                    path.unlink()
                continue
            path.write_bytes(snapshot)
        return None


def _ensure_uv_table(doc: TOMLDocument) -> Container:
    tool_table = doc.get("tool")
    if tool_table is None:
        tool_table = table()
        doc["tool"] = tool_table
    uv_table = tool_table.get("uv")
    if uv_table is None:
        uv_table = table()
        tool_table["uv"] = uv_table
    return uv_table


def _ensure_constraint_array(uv_table: Container) -> list[str]:
    constraints = uv_table.get("constraint-dependencies")
    if constraints is None:
        return []
    if not isinstance(constraints, Array):
        raise ProjectConfigError("[tool.uv].constraint-dependencies must be an array")
    return [value for value in constraints if isinstance(value, str)]


def _requirement_name(raw: str) -> str:
    return Requirement(raw).name


def _load_exception(payload: dict[str, object]) -> CooldownException:
    raw = dict(payload)
    for key in ["approved_at", "upload_time", "package_cutoff", "cooldown_ends_at", "cleaned_at"]:
        if key in raw and raw[key] is not None:
            raw[key] = parse_rfc3339(str(raw[key]))
    return CooldownException.model_validate(raw)
