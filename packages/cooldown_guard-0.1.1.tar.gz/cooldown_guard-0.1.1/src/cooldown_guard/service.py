from __future__ import annotations

import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Callable

from packaging.requirements import InvalidRequirement, Requirement
from packaging.utils import canonicalize_name
from tomlkit import parse

from cooldown_guard.models import CooldownException, Ledger
from cooldown_guard.project import (
    ProjectConfigError,
    ensure_package_cutoff,
    get_global_exclude_newer,
    get_package_cutoff,
    has_constraint,
    load_ledger,
    load_pyproject,
    project_paths,
    project_transaction,
    remove_package_cutoff,
    replace_constraint,
    save_ledger,
    save_pyproject,
)
from cooldown_guard.pypi import PyPiClient
from cooldown_guard.time_utils import compute_cooldown_end, format_utc, parse_rfc3339, utc_now


class CooldownGuardError(RuntimeError):
    pass


@dataclass(slots=True)
class CleanupResult:
    package: str
    state: str
    detail: str


class CooldownGuardService:
    def __init__(
        self,
        package_index: PyPiClient | None = None,
        now: Callable[[], datetime] = utc_now,
        uv_lock_runner: Callable[[Path], None] | None = None,
    ) -> None:
        self._package_index = package_index or PyPiClient()
        self._now = now
        self._uv_lock_runner = uv_lock_runner or run_uv_lock

    def approve(
        self,
        project_root: Path,
        spec: str,
        approved_by: str,
        reason: str,
        advisory: str | None = None,
        severity: str | None = None,
        introduced_via: list[str] | None = None,
        relax_to: str | None = None,
    ) -> CooldownException:
        package, version = _parse_exact_spec(spec)
        paths = project_paths(project_root)
        doc = load_pyproject(paths.pyproject)
        exclude_newer = get_global_exclude_newer(doc)
        ledger = load_ledger(paths.ledger)

        if ledger.get_active(package):
            raise CooldownGuardError(f"an active exception already exists for {package}")

        upload_time = self._package_index.get_upload_time(package, version)
        package_cutoff = upload_time + timedelta(seconds=1)
        approved_at = self._now()
        constraint = f"{package}=={version}"
        relax_target = relax_to or f"{package}>={version}"
        cooldown_ends_at = compute_cooldown_end(upload_time, exclude_newer)
        entry = CooldownException(
            package=package,
            version=version,
            constraint=constraint,
            relax_to=relax_target,
            approved_by=approved_by,
            approved_at=approved_at,
            reason=reason,
            advisory=advisory,
            severity=severity,
            introduced_via=introduced_via or [],
            upload_time=upload_time,
            package_cutoff=package_cutoff,
            cooldown_ends_at=cooldown_ends_at,
        )

        ensure_package_cutoff(doc, package, format_utc(package_cutoff))
        replace_constraint(doc, package, constraint)
        ledger.upsert(entry)

        with project_transaction(paths) as transaction:
            save_pyproject(paths.pyproject, doc)
            save_ledger(paths.ledger, ledger)
            self._uv_lock_runner(paths.root)
            transaction.commit()

        return entry

    def validate(self, project_root: Path) -> list[str]:
        paths = project_paths(project_root)
        doc = load_pyproject(paths.pyproject)
        ledger = load_ledger(paths.ledger)
        errors: list[str] = []

        for entry in ledger.active_exceptions():
            cutoff = get_package_cutoff(doc, entry.package)
            if cutoff != format_utc(entry.package_cutoff):
                errors.append(
                    f"{entry.package}: ledger cutoff {format_utc(entry.package_cutoff)} does not match pyproject"
                )
            if not has_constraint(doc, entry.package, entry.constraint):
                errors.append(f"{entry.package}: missing constraint {entry.constraint}")

        return errors

    def status(self, project_root: Path) -> list[CooldownException]:
        paths = project_paths(project_root)
        ledger = load_ledger(paths.ledger)
        return ledger.exceptions

    def cleanup(self, project_root: Path, apply: bool = False, package: str | None = None) -> list[CleanupResult]:
        paths = project_paths(project_root)
        current_time = self._now()
        ledger = load_ledger(paths.ledger)
        targets = [
            entry for entry in ledger.active_exceptions()
            if package is None or canonicalize_name(entry.package) == canonicalize_name(package)
        ]
        results: list[CleanupResult] = []

        for entry in targets:
            if entry.cooldown_ends_at is None:
                results.append(
                    CleanupResult(
                        package=entry.package,
                        state="skipped",
                        detail="cooldown end is not time-based; manual cleanup required",
                    )
                )
                continue

            if current_time < entry.cooldown_ends_at:
                results.append(
                    CleanupResult(
                        package=entry.package,
                        state="waiting",
                        detail=f"eligible after {format_utc(entry.cooldown_ends_at)}",
                    )
                )
                continue

            result = self._cleanup_entry(paths.root, entry, apply=apply, cleaned_at=current_time)
            results.append(result)

        return results

    def _cleanup_entry(self, project_root: Path, entry: CooldownException, apply: bool, cleaned_at: datetime) -> CleanupResult:
        paths = project_paths(project_root)
        doc = load_pyproject(paths.pyproject)
        ledger = load_ledger(paths.ledger)
        active_entry = ledger.get_active(entry.package)
        if active_entry is None:
            return CleanupResult(package=entry.package, state="skipped", detail="entry is no longer active")

        remove_package_cutoff(doc, entry.package)
        replace_constraint(doc, entry.package, entry.relax_to)

        with project_transaction(paths) as transaction:
            save_pyproject(paths.pyproject, doc)
            active_entry.state = "cleaned"
            active_entry.cleaned_at = cleaned_at
            active_entry.cleanup_resolution = entry.relax_to
            save_ledger(paths.ledger, ledger)
            try:
                self._uv_lock_runner(paths.root)
            except subprocess.CalledProcessError as exc:
                detail = _stderr_detail(exc)
                return CleanupResult(package=entry.package, state="blocked", detail=detail)

            if apply:
                transaction.commit()
                return CleanupResult(package=entry.package, state="cleaned", detail=f"relaxed to {entry.relax_to}")

        return CleanupResult(package=entry.package, state="ready", detail=f"can relax to {entry.relax_to}")


def run_uv_lock(project_root: Path) -> None:
    subprocess.run(
        ["uv", "lock"],
        cwd=project_root,
        check=True,
        capture_output=True,
        text=True,
    )


def _parse_exact_spec(spec: str) -> tuple[str, str]:
    try:
        requirement = Requirement(spec)
    except InvalidRequirement as exc:
        raise CooldownGuardError(f"invalid requirement: {spec}") from exc

    specifiers = list(requirement.specifier)
    if len(specifiers) != 1 or specifiers[0].operator != "==":
        raise CooldownGuardError("approve expects an exact requirement like urllib3==2.7.0")
    if requirement.marker or requirement.extras or requirement.url:
        raise CooldownGuardError("approve only supports plain package==version requirements")

    return requirement.name, specifiers[0].version


def _stderr_detail(exc: subprocess.CalledProcessError) -> str:
    stderr = (exc.stderr or "").strip()
    stdout = (exc.stdout or "").strip()
    return stderr or stdout or str(exc)
