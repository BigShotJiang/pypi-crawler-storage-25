from __future__ import annotations

from pathlib import Path

import typer

from cooldown_guard.service import CooldownGuardError, CooldownGuardService
from cooldown_guard.time_utils import format_utc

app = typer.Typer(add_completion=False, no_args_is_help=True)


@app.command()
def approve(
    spec: str = typer.Argument(..., help="exact requirement like urllib3==2.7.0"),
    project: Path = typer.Option(Path("."), "--project", resolve_path=True, file_okay=False, dir_okay=True),
    approved_by: str = typer.Option(..., "--approved-by"),
    reason: str = typer.Option(..., "--reason"),
    advisory: str | None = typer.Option(None, "--advisory"),
    severity: str | None = typer.Option(None, "--severity"),
    introduced_via: list[str] = typer.Option(None, "--introduced-via"),
    relax_to: str | None = typer.Option(None, "--relax-to"),
) -> None:
    service = CooldownGuardService()
    try:
        entry = service.approve(
            project_root=project,
            spec=spec,
            approved_by=approved_by,
            reason=reason,
            advisory=advisory,
            severity=severity,
            introduced_via=introduced_via,
            relax_to=relax_to,
        )
    except CooldownGuardError as exc:
        raise typer.Exit(code=_echo_error(str(exc))) from exc

    typer.echo(f"approved {entry.package}=={entry.version}")
    typer.echo(f"cutoff override: {format_utc(entry.package_cutoff)}")
    if entry.cooldown_ends_at is not None:
        typer.echo(f"cleanup eligible after: {format_utc(entry.cooldown_ends_at)}")


@app.command()
def validate(
    project: Path = typer.Option(Path("."), "--project", resolve_path=True, file_okay=False, dir_okay=True),
) -> None:
    service = CooldownGuardService()
    try:
        errors = service.validate(project_root=project)
    except CooldownGuardError as exc:
        raise typer.Exit(code=_echo_error(str(exc))) from exc

    if errors:
        for error in errors:
            typer.echo(f"invalid: {error}")
        raise typer.Exit(code=1)

    typer.echo("ledger and pyproject are in sync")


@app.command()
def status(
    project: Path = typer.Option(Path("."), "--project", resolve_path=True, file_okay=False, dir_okay=True),
) -> None:
    service = CooldownGuardService()
    entries = service.status(project_root=project)
    if not entries:
        typer.echo("no cooldown exceptions")
        return

    for entry in entries:
        line = f"{entry.package} {entry.state} {entry.constraint}"
        if entry.state == "active" and entry.cooldown_ends_at is not None:
            line += f" eligible-after={format_utc(entry.cooldown_ends_at)}"
        if entry.state == "cleaned" and entry.cleaned_at is not None:
            line += f" cleaned-at={format_utc(entry.cleaned_at)}"
        typer.echo(line)


@app.command()
def cleanup(
    project: Path = typer.Option(Path("."), "--project", resolve_path=True, file_okay=False, dir_okay=True),
    apply: bool = typer.Option(False, "--apply", help="apply changes instead of just checking"),
    package: str | None = typer.Option(None, "--package", help="limit cleanup to one package"),
) -> None:
    service = CooldownGuardService()
    results = service.cleanup(project_root=project, apply=apply, package=package)
    if not results:
        typer.echo("no matching active exceptions")
        return

    exit_code = 0
    for result in results:
        typer.echo(f"{result.package}: {result.state} - {result.detail}")
        if result.state == "blocked":
            exit_code = 1

    if exit_code:
        raise typer.Exit(code=exit_code)


def _echo_error(message: str) -> int:
    typer.echo(f"error: {message}")
    return 1


if __name__ == "__main__":
    app()
