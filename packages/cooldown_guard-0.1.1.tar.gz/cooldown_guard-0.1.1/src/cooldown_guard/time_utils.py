from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta


_FRIENDLY_DURATION = re.compile(r"^\s*(\d+)\s*(second|seconds|minute|minutes|hour|hours|day|days|week|weeks)\s*$")
_ISO_DURATION = re.compile(
    r"^P(?:(?P<days>\d+)D)?(?:T(?:(?P<hours>\d+)H)?(?:(?P<minutes>\d+)M)?(?:(?P<seconds>\d+)S)?)?$"
)


def utc_now() -> datetime:
    return datetime.now(UTC)


def parse_rfc3339(value: str) -> datetime:
    normalized = value.strip().replace("Z", "+00:00")
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def parse_uv_duration(value: str) -> timedelta | None:
    friendly = _FRIENDLY_DURATION.match(value)
    if friendly:
        amount = int(friendly.group(1))
        unit = friendly.group(2)
        if unit.startswith("second"):
            return timedelta(seconds=amount)
        if unit.startswith("minute"):
            return timedelta(minutes=amount)
        if unit.startswith("hour"):
            return timedelta(hours=amount)
        if unit.startswith("day"):
            return timedelta(days=amount)
        if unit.startswith("week"):
            return timedelta(weeks=amount)

    iso = _ISO_DURATION.match(value.strip())
    if iso:
        parts = {name: int(raw or 0) for name, raw in iso.groupdict().items()}
        return timedelta(
            days=parts["days"],
            hours=parts["hours"],
            minutes=parts["minutes"],
            seconds=parts["seconds"],
        )

    return None


def compute_cooldown_end(upload_time: datetime, exclude_newer: str) -> datetime | None:
    duration = parse_uv_duration(exclude_newer)
    if duration is not None:
        return upload_time + duration
    return None


def format_utc(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")
