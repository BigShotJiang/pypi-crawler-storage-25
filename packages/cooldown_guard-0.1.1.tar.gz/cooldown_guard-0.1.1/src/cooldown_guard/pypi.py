from __future__ import annotations

from datetime import UTC, datetime

import httpx

from cooldown_guard.time_utils import parse_rfc3339


class PackageIndexError(RuntimeError):
    pass


class PyPiClient:
    def __init__(self, base_url: str = "https://pypi.org/pypi", timeout: float = 10.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    def get_upload_time(self, package: str, version: str) -> datetime:
        url = f"{self._base_url}/{package}/json"
        response = httpx.get(url, timeout=self._timeout)
        response.raise_for_status()
        payload = response.json()
        releases = payload.get("releases", {})
        artifacts = releases.get(version, [])
        if not artifacts:
            raise PackageIndexError(f"no release artifacts found for {package}=={version}")

        upload_times: list[datetime] = []
        for artifact in artifacts:
            raw_time = artifact.get("upload_time_iso_8601")
            if not raw_time:
                continue
            upload_times.append(parse_rfc3339(raw_time))

        if not upload_times:
            raise PackageIndexError(f"release metadata for {package}=={version} had no upload times")

        return max(upload_times).astimezone(UTC)
