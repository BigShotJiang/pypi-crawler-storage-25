
"""
Visual smoke test for the pygame renderer.

Runs for a few seconds with a synthetic two-vehicle scenario — no Excel file
needed.  Verifies that the window opens, vehicles are drawn, the HUD displays,
and the window closes cleanly.

Usage:
    python tests/smoke_renderer.py
    python tests/smoke_renderer.py --playback   # CSV playback path
    python tests/smoke_renderer.py --fast       # run at 4x speed
"""
import argparse
import sys
from pathlib import Path

# Allow running from the project root without installing the package
sys.path.insert(0, str(Path(__file__).parent.parent))

from cacc_sim.controllers import CACCController
from cacc_sim.driving_models import CACCModel, IDMModel, LeadVehicleModel
from cacc_sim.filters import PassthroughFilter
from cacc_sim.loader import SimConfig
from cacc_sim.plant import VehiclePlant, VehicleResponseModel
from cacc_sim.playback import CSVPlayback
from cacc_sim.profile import LeadVehicleProfile
from cacc_sim.renderer import PygameRenderer
from cacc_sim.simulation import SimulationLoop
from cacc_sim.vehicle import Vehicle

import pandas as pd


# ---------------------------------------------------------------------------
# Build a synthetic 4-vehicle scenario: lead + ACC + human truck + CACC
# ---------------------------------------------------------------------------

def _build_vehicles() -> list[Vehicle]:
    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s':     [0.0, 10.0, 20.0, 30.0],
        'value':      [20.0, 30.0, 30.0, 20.0],
        'transition': ['ramp', 'ramp', 'ramp', 'ramp'],
    }))

    lead = Vehicle(
        id=1,
        model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=150.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=None,
        vehicle_type=None,
    )
    acc = Vehicle(
        id=2,
        model=IDMModel(desired_speed=30.0, time_headway=1.5),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=115.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=1,
        vehicle_type=None,
    )
    truck = Vehicle(
        id=3,
        model=IDMModel(desired_speed=25.0, time_headway=2.0,
                       a_max=1.2, a_min=-5.0),
        response=VehicleResponseModel(mode='kinematic',
                                      a_max=1.2, a_min=-5.0),
        plant=VehiclePlant(x0=65.0, v0=20.0, length=15.0),
        filter_=PassthroughFilter(),
        leader_id=2,
        vehicle_type='heavy_truck',
    )
    cacc_car = Vehicle(
        id=4,
        model=CACCModel(
            desired_speed=30.0,
            controller=CACCController(
                k1=0.2, k2=0.7, k_ff=1.0,
                target_headway_s=0.6, s0=2.0,
            ),
        ),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=35.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=3,
        vehicle_type=None,
    )
    return [lead, acc, truck, cacc_car]


def run_live(speed: float = 1.0) -> None:
    """Live simulation smoke test."""
    vehicles = _build_vehicles()
    config = SimConfig(
        duration_s=80.0,
        response_model='kinematic',
        simulation_speed=speed,
        render_interval_s=0.05,
    )
    renderer = PygameRenderer(title='CAV Sandbox — Live Smoke Test')
    loop = SimulationLoop(vehicles, config)
    print(f'Running live sim at {speed}× speed.  Close window or press Q to stop.')
    df = loop.run_live(renderer)
    renderer.close()
    print(f'Done. {len(df)} log rows recorded.')


def run_playback(speed: float = 1.0) -> None:
    """CSV playback smoke test — runs sim headless first, then replays."""
    vehicles = _build_vehicles()
    config = SimConfig(
        duration_s=80.0,
        response_model='kinematic',
        simulation_speed=0,      # batch: no pacing during data generation
        render_interval_s=0.05,
    )
    print('Generating simulation data (headless)...')
    loop = SimulationLoop(vehicles, config)
    df = loop.run()
    print(f'  {len(df)} rows generated.')

    renderer = PygameRenderer(title='CAV Sandbox — Playback Smoke Test', playback_mode=True)
    pb = CSVPlayback(df, renderer, render_interval_s=0.05, initial_speed=speed)
    print(f'Playing back at {speed}× speed.  Close window or press Q to stop.')
    pb.run()
    renderer.close()
    print('Playback complete.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Pygame renderer smoke test')
    parser.add_argument('--playback', action='store_true',
                        help='Test CSV playback path instead of live sim')
    parser.add_argument('--fast', action='store_true',
                        help='Run at 4× speed')
    args = parser.parse_args()

    speed = 4.0 if args.fast else 1.0

    if args.playback:
        run_playback(speed)
    else:
        run_live(speed)
