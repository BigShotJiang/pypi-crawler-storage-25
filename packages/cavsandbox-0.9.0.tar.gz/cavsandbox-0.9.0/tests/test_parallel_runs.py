"""Test parallel scenario execution as described in the User's Guide."""
from __future__ import annotations

import shutil
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import openpyxl
import pytest

REPO_ROOT = Path(__file__).parent.parent
QUICKSTART = REPO_ROOT / "examples" / "quickstart.xlsx"
RESULTS_DIR = REPO_ROOT / "results"
RESULTS_INDEX = RESULTS_DIR / "index.csv"


def _make_workbook(k_ff: float, dest: Path) -> None:
    """Clone quickstart.xlsx with simulation_speed=0 and the given k_ff."""
    wb = openpyxl.load_workbook(QUICKSTART)
    ws = wb["simulation"]
    for row in ws.iter_rows():
        cell = row[0]
        if cell.value == "cacc_k_ff":
            row[1].value = k_ff
        elif cell.value == "simulation_speed":
            row[1].value = 0          # headless
        elif cell.value == "duration_s":
            row[1].value = 15         # short run so the test is fast
    wb.save(dest)


def run_scenario(path: str) -> tuple[str, int, str]:
    """Run one scenario in a subprocess; return (path, returncode, stderr)."""
    result = subprocess.run(
        [sys.executable, "-m", "cacc_sim.main", path, "--seed", "42"],
        capture_output=True,
        text=True,
        cwd=str(REPO_ROOT),
    )
    return path, result.returncode, result.stderr.strip()


def test_parallel_scenarios(tmp_path: Path) -> None:
    k_ff_values = [0.80, 0.85, 0.90, 0.95]
    scenario_files = []
    for k in k_ff_values:
        p = tmp_path / f"temp_kff_{k:.2f}.xlsx"
        _make_workbook(k, p)
        scenario_files.append(str(p))

    # Snapshot result folders before the run.
    before = set(RESULTS_DIR.iterdir()) if RESULTS_DIR.exists() else set()

    t0 = time.perf_counter()
    with ProcessPoolExecutor(max_workers=4) as executor:
        outcomes = list(executor.map(run_scenario, scenario_files))
    elapsed = time.perf_counter() - t0

    # All processes must exit cleanly.
    for path, rc, stderr in outcomes:
        assert rc == 0, f"Scenario {path} failed (rc={rc}):\n{stderr}"

    # Each run must have created a new timestamped results folder.
    after = set(RESULTS_DIR.iterdir()) if RESULTS_DIR.exists() else set()
    new_folders = [p for p in (after - before) if p.is_dir()]
    assert len(new_folders) == 4, (
        f"Expected 4 new result folders, found {len(new_folders)}: {new_folders}"
    )

    # Each folder must contain data.csv, metadata.yaml, input.xlsx.
    for folder in new_folders:
        assert (folder / "data.csv").exists(), f"Missing data.csv in {folder}"
        assert (folder / "metadata.yaml").exists(), f"Missing metadata.yaml in {folder}"
        assert (folder / "input.xlsx").exists(), f"Missing input.xlsx in {folder}"

    # The results index must have gained exactly 4 lines (one per run).
    if RESULTS_INDEX.exists():
        index_lines = RESULTS_INDEX.read_text().splitlines()
        new_entries = [
            ln for ln in index_lines
            if any(folder.name in ln for folder in new_folders)
        ]
        assert len(new_entries) == 4, (
            f"Expected 4 index entries, found {len(new_entries)}"
        )

    print(
        f"\nAll 4 scenarios completed successfully in {elapsed:.1f}s "
        f"with no file contention.\nNew result folders:"
    )
    for folder in sorted(new_folders):
        print(f"  {folder.name}")
