# CLAUDE.md

## Project

CAVSandbox: Python simulation of longitudinal car-following with ACC, CACC, and human driver models. Target audience: college/graduate students and professors.

## Design Document

Read `CACC_Design_Notes.md` for full architecture, class interfaces, and design rationale. Follow Section 14 (Development Sequence) for build order.

## Stack

-   Python 3.11+
-   pandas, numpy, openpyxl (Excel input)
-   pygame (real-time graphics)
-   pyyaml (run metadata output)
-   matplotlib (post-run plots)
-   No external frameworks — pure Python classes with ABCs
-   uv for package management — always use `uv pip install`, never `pip install`

## Architecture

-   `cacc_sim/` — core package (models, filters, sensors, vehicle, loop)
-   `plugins/` — user-extensible driving models and filters
-   `tests/` — pytest tests (unit and integration)
-   `Filter_tests/` — Step 17 sensor validation suite; see `Filter_tests/Filter Test Context.docx` for the validation specification
-   `Archive/` — historical code; do not use as reference, design notes are authoritative
-   Strategy Pattern throughout: DrivingModel, Filter, BaseSensor are ABCs

### Modules built so far (Section 14 steps 1–17)

| Module | Contents |
|---|---|
| `cacc_sim/core.py` | `VehicleState`, `DrivingModelOutput`, `FilterInput`, `FilterOutput`, `DrivingModel` ABC (+ `from_excel_row()`), `Filter` ABC, `DelayBuffer` |
| `cacc_sim/plant.py` | `VehiclePlant` (kinematic integrator), `VehicleResponseModel` (`'kinematic'`/`'lag'` modes) |
| `cacc_sim/controllers.py` | `CACCController` (P+FF, string-stability check in `__init__`, `string_stable` property) |
| `cacc_sim/driving_models.py` | `IDMModel`, `IDMHumanModel`, `CACCModel`, `LeadVehicleModel` — all implement `from_excel_row()` |
| `cacc_sim/filters.py` | `PassthroughFilter` |
| `cacc_sim/rng.py` | `vehicle_rng(master_seed, vehicle_id, process)` — derives independent `random.Random` per vehicle/process from master seed via XOR offsets |
| `cacc_sim/sensors.py` | `ARNoise`, `GapKalmanFilter`, `LowPassFilter`; `BaseSensor`/`PassthroughSensor`/`RadarSensor`; `BaseEgoSensor`/`PassthroughEgoSensor`/`NoisyEgoSensor`; `BaseBSMTracker`/`PassthroughBSMTracker`/`DSRCBSMTracker` (10 Hz BSM, packet drop, phase stagger, age tracking); `BaseFusionEstimator`/`PassthroughFusionEstimator`/`FusionKalmanFilter` (3-state multi-rate KF: radar every step + BSM on fresh packet); `BaseFusionEstimator.seed(gap, rate)` no-op default; `FusionKalmanFilter.seed()` sets initial state from exact plant values before first step (P[2,2]=0 lets Q build accel uncertainty gradually); `comms_model='dsrc'` activates both together |
| `cacc_sim/profile.py` | `LeadVehicleProfile` |
| `cacc_sim/loader.py` | `SimConfig`, `load_vehicles()`, `load_plugins()`, `validate_vehicle_df()`, `MODEL_REGISTRY`, `FILTER_REGISTRY`; `_build_model()` dispatches via `cls.from_excel_row()` |
| `cacc_sim/road.py` | `Lane`, `Road` (single-lane scaffold; `get_leader()` indirection for future multi-lane) |
| `cacc_sim/vehicle.py` | `Vehicle` (sensor pipeline wiring in `step()`: passthrough bypass when `sensor_model='passthrough'`; full radar+ego+BSM+fusion path otherwise); stores `_last_a_meas` each step so BSM tracker on following vehicles receives ego-measured (not true) leader accel; logs `lead_a_radar` and `bsm_age_s`; `platoon_leader` reference wired by `load_vehicles()` — populates `state.leader_speed` and `state.leader_acceleration` for plugin models |
| `cacc_sim/simulation.py` | `SimulationLoop`; `_CollisionError` — stops sim early on gap < 0, prints warning, returns partial DataFrame; `run_live()` shows frozen collision overlay; maintains per-vehicle `collections.deque` speed buffer (`_CHART_WINDOW_S = 30 s`) passed to `RenderFrame` each render tick; decimates CSV log to `log_rate_hz` (default 10 Hz) — collision rows always logged; `_seed_filters()` called from `__init__()` seeds each follower's `FusionKalmanFilter` from exact plant gap and rate before the first step |
| `cacc_sim/renderer.py` | `PygameRenderer`, `RenderFrame`, `VehicleRenderState`; collision overlay via `draw(..., collision_message=)`; PNG sprite rendering with `BLEND_RGB_MULT` tinting; falls back to rectangles if sprites missing; live speed chart (rolling 30 s window, `collections.deque` buffer); `handle_events()` returns `(paused, running, seek_time)`; road visuals: 4 px warm-white `(255,255,180)` centre dashes (20 px dash / 40 px gap, scrolling), solid white `(255,255,255)` 2 px edge lines at top and bottom of road strip (static), scrolling red/white roadside posts at 50 m world intervals (4 × 16 px, alternating `(220,30,30)`/`(255,255,255)` keyed to `floor(world_x/50m)%2` via camera `offset` — no flicker); `_draw_road(offset, px_per_m)` receives camera params from `draw()` |
| `cacc_sim/assets/` | `car.png`, `truck.png` — white-on-transparent sprites tinted to model color at render time |
| `cacc_sim/playback.py` | `CSVPlayback`; full-trace speed chart with vertical playback cursor; click-to-seek (left-click chart snaps playback position and pauses) |
| `cacc_sim/palette.py` | `MODEL_COLORS` (pygame: grey lead, cyan CACC), `MODEL_COLORS_PLOT` (matplotlib: black lead, dark teal `#008080` CACC), `MODEL_LINESTYLES`, `to_rgb255()` |
| `cacc_sim/output.py` | `save_run()` — creates `results/<scenario>_<timestamp>/` subfolder containing `data.csv`, `metadata.yaml`, `input.xlsx`, and plots; appends one line to `results/index.csv` (run_folder, scenario, timestamp, seed, duration_s, n_vehicles, cacc_k_ff); `metadata.yaml` includes `log_rate_hz` and `n_steps` (logged steps per vehicle, not sim steps) |
| `cacc_sim/plot.py` | `plot_run()` — five-panel composite PNG + five individual panel PNGs (speed, gap, accel, lag, spacetime); CLI entry point; uses `MODEL_COLORS_PLOT`; lag panel shows vehicle 2 actual (solid) vs. commanded (dashed) only; space-time panel plots position (y) vs. time (x) with caption explaining axes |
| `cacc_sim/main.py` | CLI entry point (`argparse`, `prog='cavsandbox'`); positional `input` arg accepts `.xlsx` (simulation) or `.csv` (CSV playback via `CSVPlayback.from_csv()`); `--seed` overrides `master_seed`; unrecognised extension → `parser.error()`; `.xlsx` dispatch: headless when `simulation_speed=0`, live renderer otherwise |
| `cacc_sim/__init__.py` | Re-exports all public names — stable import surface for plugins; `plot_run` is intentionally excluded (CLI tool, not public API — import directly from `cacc_sim.plot` if needed) |
| `plugins/wiedemann99.py` | `Wiedemann99Model` — shipped plugin; worked example for plugin authors |

## Commands

-   `pytest` — run all tests (including Filter_tests/tests/)
-   `pytest Filter_tests/tests/` — run Step 17 integration tests only
-   `python -m cacc_sim.main <input.xlsx>` — run simulation (live or headless per `simulation_speed`)
-   `python -m cacc_sim.main <results.csv>` — replay a saved CSV through the live renderer
-   `python -m cacc_sim.main examples/quickstart.xlsx` — run the default four-vehicle CACC quick-start scenario
-   `python -m cacc_sim.plot <results.csv> [--show]` — regenerate plots from an existing CSV
-   `python tests/smoke_renderer.py` — visual smoke test (live sim, 4-vehicle scenario)
-   `python tests/smoke_renderer.py --playback` — CSV playback smoke test
-   `python tests/smoke_renderer.py --fast` — run at 4× speed
-   `python Filter_tests/make_workbooks.py` — generate validation Excel workbooks in Filter_tests/validation/
-   `python Filter_tests/validate_step17.py` — run full Step 17 validation and produce diagnostic PNGs

## Conventions

-   Timestep is always 0.01 s (100 Hz sim, decoupled 10 Hz render)
-   All distances in metres, speeds in m/s, accelerations in m/s²
-   Passthrough stubs for sensors/comms initially — same ABC interface as real implementations
-   Excel input: vehicles, simulation, profile sheets; optional vehicle_types sheet for mixed fleets
-   State logging: list of dicts → pandas DataFrame → CSV
-   Use `math.sqrt` (not `np.sqrt`) for scalar operations in hot loops — numpy has per-call overhead that dominates at single-value scale (per §13.2)
-   All `step()` / `compute()` methods return plain Python `float`, not `np.float64` — wrap `np.clip` results in `float()`
-   Stochastic plugin models use `random.Random(seed)` (stdlib), not `numpy.random` — keeps numpy out of non-hot-path code and allows per-instance seeding

## Key Design Rules

### General
-   Vehicle class never contains if/elif for model selection — Strategy Pattern only
-   `leader_id` is explicit in Excel, not derived from row order
-   Lead vehicle must use `model='LEAD_PROFILE'`
-   `extras` fields on dataclasses use `field(default_factory=dict)` — never a bare `{}` default
-   `@classmethod @abstractmethod` order: `@classmethod` is the outer decorator (wraps `@abstractmethod`) — reversing is deprecated in Python 3.11+
-   Do not use the `Archive/` folder as reference — it is outdated

### Vehicle response
-   `VehicleResponseModel` has a `mode` parameter: `'kinematic'` (instant, no lag) or `'lag'` (1st-order, default); configured via `response_model` key in the Excel simulation sheet
-   Vehicle response parameters (`tau_throttle_s`, `tau_brake_s`, `a_max_mps2`, `a_min_mps2`, `j_max_mps3`) use a four-level resolution hierarchy: (1) per-vehicle column, (2) `vehicle_types` sheet lookup via `vehicle_type` column, (3) simulation sheet globals, (4) hardcoded defaults in `VehicleResponseModel.__init__()`. The `vehicle_types` sheet is optional — omit it for homogeneous fleets. See Section 10.2.1.
-   Passive drag model is quadratic: `a_drag = -(crr * 9.81 + k_aero * v²)`; parameters are `crr` (rolling resistance) and `k_aero` (= 0.5 * Cd * A * rho / m); linear drag was rejected as it overstates drag 2–3× at highway speeds

### CACC
-   `CACCController` lives in `controllers.py`, not `driving_models.py`. Plugin authors import it with `from cacc_sim import CACCController` or `from cacc_sim.controllers import CACCController`.
-   CACC gains (`cacc_k1`, `cacc_k2`, `cacc_k_ff`, `cacc_target_headway_s`, `cacc_s0_m`) are `SimConfig` fields — system-level, not per-vehicle. Defaults are `k1=0.45, k2=0.25, k_ff=0.90`; these give a string-stability margin at the default 0.6 s headway (`k_ff + k2*T_h = 1.05 > 1`). The PATH field-test value `k_ff=0.45` is deliberately not the default — it is marginally unstable at this headway.
-   `CACCController.__init__()` warns via `warnings.warn()` when `k_ff + k2 * T_h < 1` (string-unstable). The warning fires for both built-in and plugin instantiation. Integral term is deliberately absent — see controllers.py docstring.
-   `lead_a_v2v: float = 0.0` in `VehicleState` is the BSM feedforward field. `0.0` means unavailable — `k_ff * 0.0 = 0` degrades gracefully to pure feedback. Currently wired via `PassthroughBSMTracker` (perfect V2V); a realistic `DSRCChannel` (10 Hz BSM, packet drop, age tracking) is a future step.
-   `lead_a_radar: float = 0.0` is Kalman-estimated lead acceleration for future EIDM/CAH; always `0.0` in the current `PassthroughFusionEstimator`.

### Road and leader resolution
-   `Road.get_leader()` is the single indirection point for leader lookup — `SimulationLoop` never resolves leaders directly. This is the extension seam for multi-lane and lane-change logic.
-   `SimulationLoop` accepts an optional `road` parameter; if omitted, a single-lane road of `config.road_length_m` is created automatically.

### Plugin system
-   Adding a new model means implementing `from_excel_row(cls, row, sim_config)` on the class and dropping the file in `plugins/`. Do **not** edit `_build_model()` — it dispatches via `cls.from_excel_row()` for everything except `LEAD_PROFILE`.
-   `load_plugins()` is auto-called from `load_vehicles()` and is idempotent — double-calling is safe. Caches loaded modules in `sys.modules` under the key `_cacc_plugin_<stem>`.
-   Name collision (plugin class name matches existing registry entry): warning is issued, existing entry preserved — built-in models cannot be overridden by a plugin.
-   `DrivingModel.from_excel_row()` base raises `NotImplementedError` with a message that names the class and tells the plugin author what to implement. `LeadVehicleModel` raises intentionally — it requires a profile object that cannot come from the row alone.
