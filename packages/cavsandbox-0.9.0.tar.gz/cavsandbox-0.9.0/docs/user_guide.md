## Table of Contents

- [Introduction](#introduction)
- [Part 1 — Configuring a Scenario](#part-1--configuring-a-scenario)
  - [1. The Excel Input File](#1-the-excel-input-file)
  - [2. The Vehicles Sheet](#2-the-vehicles-sheet)
  - [3. The Simulation Sheet](#3-the-simulation-sheet)
  - [4. The Profile Sheet](#4-the-profile-sheet)
  - [5. The Vehicle Types Sheet](#5-the-vehicle-types-sheet)
- [Part 2 — Driving Models](#part-2--driving-models)
  - [6. Choosing a Driving Model](#6-choosing-a-driving-model)
  - [7. IDMModel (ACC)](#7-idmmodel-acc)
  - [8. IDMHumanModel](#8-idmhumanmodel)
  - [9. CACCModel](#9-caccmodel)
  - [10. Wiedemann99Model (Plugin)](#10-wiedemann99model-plugin)
  - [11. LeadVehicleModel](#11-leadvehiclemodel)
- [Part 3 — Sensor and Communications Configuration](#part-3--sensor-and-communications-configuration)
  - [12. Sensor Pipeline Overview](#12-sensor-pipeline-overview)
  - [13. Sensor Model Options](#13-sensor-model-options)
  - [14. Ego Sensor](#14-ego-sensor)
  - [15. V2V Communications Model](#15-v2v-communications-model)
  - [16. Fusion Kalman Filter](#16-fusion-kalman-filter)
  - [Sensor Configuration Summary](#sensor-configuration-summary)
- [Part 4 — Running the Simulation](#part-4--running-the-simulation)
  - [17. Command-Line Interface](#17-command-line-interface)
  - [18. The Live Renderer](#18-the-live-renderer)
  - [19. CSV Playback](#19-csv-playback)
  - [20. Headless Batch Mode](#20-headless-batch-mode)
- [Part 5 — Results and Output](#part-5--results-and-output)
  - [21. Output Folder Structure](#21-output-folder-structure)
  - [22. The State Log (data.csv)](#22-the-state-log-datacsv)
  - [23. The Plots](#23-the-plots)
  - [24. metadata.yaml](#24-metadatayaml)
- [Part 6 — Advanced Topics](#part-6--advanced-topics)
  - [25. String Stability](#25-string-stability)
  - [26. Mixed Fleets](#26-mixed-fleets)
  - [27. Reproducibility and Seeds](#27-reproducibility-and-seeds)
  - [28. Performance](#28-performance)
- [Appendix A — Excel Input Parameter Reference](#appendix-a--excel-input-parameter-reference)
  - [Table A1 — Vehicles Sheet Columns](#table-a1--vehicles-sheet-columns)
    - [§A1.1 Response Parameter Resolution](#a11-response-parameter-resolution)
  - [Table A2 — Simulation Sheet Keys](#table-a2--simulation-sheet-keys)
    - [Timing](#timing)
    - [Rendering](#rendering)
    - [Sensor / Comms](#sensor--comms)
    - [CACC Gains](#cacc-gains)
    - [Response Model](#response-model)
    - [Logging](#logging)
  - [Table A3 — Profile Sheet Columns](#table-a3--profile-sheet-columns)
  - [Table A4 — Vehicle Types Sheet Columns](#table-a4--vehicle-types-sheet-columns)
- [Appendix B — Error Messages Reference](#appendix-b--error-messages-reference)
  - [Vehicles Sheet — Fatal Errors](#vehicles-sheet--fatal-errors)
    - [Missing required columns](#missing-required-columns)
    - [Row data errors](#row-data-errors)
    - [Leader topology errors](#leader-topology-errors)
    - [Position overlap errors](#position-overlap-errors)
  - [Vehicle Types Sheet — Fatal Errors](#vehicle-types-sheet--fatal-errors)
  - [Profile Sheet — Fatal Errors](#profile-sheet--fatal-errors)
  - [Non-Fatal Warnings](#non-fatal-warnings)
- [Appendix C — data.csv Column Reference](#appendix-c--datacsv-column-reference)
- [Further Reading](#further-reading)
  - [Foundational Car-Following Models](#foundational-car-following-models)
  - [CACC and V2V Communications](#cacc-and-v2v-communications)
  - [String Stability](#string-stability)

---

# CAVSandbox User Guide

## Introduction

CAVSandbox is a Python simulation of longitudinal car-following — the physics of vehicles traveling in a single lane, following one another under different control strategies. It models human drivers using the Intelligent Driver Model with psychophysical reaction delay, vehicles equipped with Adaptive Cruise Control (ACC), and vehicles equipped with Cooperative Adaptive Cruise Control (CACC), which use Vehicle-to-Vehicle (V2V) communication to anticipate the leader's actions rather than merely reacting to them. The simulation includes a realistic sensor pipeline, i.e., radar noise and delay, IMU bias drift, and V2V communications with packet drop, so that the gap between idealized control theory and physically realistic behavior can be studied directly. All scenario configuration is done in Excel; no code changes are required to run, modify, or extend a scenario. The plugin system allows new driving models and sensor filters to be added by dropping a single Python file into the `plugins/` folder.

This guide is the complete reference for configuring and running CAVSandbox scenarios and interpreting their results. It is rather long because it is comprehensive. There is no reason to read it through from end to end. Read the sections that you need and come back to it as a reference document.

This guide assumes you have completed the Quick-Start Guide and can successfully run `examples/quickstart.xlsx`. It does not cover installation (see the Quick-Start Guide), plugin development (see the Plugin Author Guide), or architectural internals (see the CACC Design Notes).

The guide is organized in the order you work: configure your fleet and scenario (Parts 1–3), run the simulation (Part 4), interpret the results (Part 5), and explore advanced topics (Part 6). Reference appendices at the back collect all parameter tables, error messages, and CSV column definitions in one place for quick lookup without having to read through the narrative sections.

The diagram below shows the data flow through a single follower vehicle's sensor pipeline, from the lead vehicle's physical state through to the driving model's commanded acceleration.

![CAVSandbox sensor pipeline](assets/cavsandbox_pipeline.svg)

The teal components are controlled by sensor_model, the purple components by comms_model, and the blue components are the control pipeline that is always active. Parts 2 and 3 cover each component in detail.

***

## Part 1 — Configuring a Scenario

### 1. The Excel Input File

Every CAVSandbox scenario is defined by a single Excel workbook. The workbook is the complete specification of the simulation — who is in the platoon, how they behave, what the lead vehicle does, and how the simulation engine is configured. When a run completes, a verbatim copy of the input workbook is saved alongside the results, making every run fully self-documenting.

The workbook contains three required sheets and one optional sheet:

| **Sheet**       | **Required** | **Purpose**                                                             |
|-----------------|--------------|-------------------------------------------------------------------------|
| `vehicles`      | Yes          | One row per vehicle — model, initial conditions, per-vehicle parameters |
| `simulation`    | Yes          | Global parameters — timing, sensor model, CACC gains, output settings   |
| `profile`       | Yes          | Lead vehicle drive cycle — time-triggered speed targets                 |
| `vehicle_types` | No           | Named parameter presets for mixed fleets (cars, trucks, etc.)           |

CAVSandbox reads the workbook when you pass it on the command line:

```bash
python -m cacc_sim.main my_scenario.xlsx
```

The path is relative to your current working directory. If you run this command from the project root, `examples/quickstart.xlsx` works as written. If you run it from a different directory, adjust the path accordingly.

**Validation.** Before the simulation starts, CAVSandbox runs a comprehensive validation pass over the workbook contents. It checks required columns, data types, value ranges, model name registry membership, and leader topology in sixteen categories. The validator collects all problems within each category before raising an error, so you see every issue of a given type at once rather than fixing them one at a time. A typical validation error looks like:

```
Unknown model name(s): ['CACmodel'] 
```

If you see a validation error, fix all reported issues of that category before re-running — there may be further categories of errors that only become visible once the first category is resolved.

**What CAVSandbox does not validate.** The validator checks that inputs are well-formed, not that they represent a physically sensible scenario. It will not warn you that a desired headway of 0.1 s is unrealistically short, or that an initial position overlap between two vehicles might cause an immediate collision. Physical plausibility is your responsibility as the scenario designer.

***

### 2. The Vehicles Sheet

The vehicles sheet defines the platoon. Each row is one vehicle. Rows are processed in the order they appear, but platoon topology is determined by the `leader_id` column, not row order — you can arrange rows in any order as long as the leader references are consistent.

#### 2.1 Required Columns

These columns must be present and non-null for every row:

| **Column**           | **Type**         | **Validation**                                                                                                                                                                                                                                                                                                                                                                                |
|----------------------|------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `vehicle_id`         | integer          | Unique, no blanks                                                                                                                                                                                                                                                                                                                                                                             |
| `model`              | string           | Must match a name in the model registry (see Part 2)                                                                                                                                                                                                                                                                                                                                          |
| `initial_position_m` | float            | ≥ 0; bumper position in meters from the start of the road                                                                                                                                                                                                                                                                                                                                     |
| `initial_speed_mps`  | float            | ≥ 0; speed in meters per second                                                                                                                                                                                                                                                                                                                                                               |
| `vehicle_length_m`   | float            | \> 0; used for gap calculation and sprite scaling                                                                                                                                                                                                                                                                                                                                             |
| `leader_id`          | integer or blank | Exactly one row must be blank (the lead vehicle); all others must reference a valid `vehicle_id`                                                                                                                                                                                                                                                                                              |
| `filter`             | string           | The driving model input filter, applied to sensor outputs immediately before they reach the driving model's compute() call. This is an extension point for plugin authors. For all built-in models and standard scenarios, use PassthroughFilter. Sensor pipeline filtering (radar Kalman filter, low-pass filter) is controlled by sensor_model in the simulation sheet, not by this column. |

**Initial position** is the position of the vehicle's front bumper. Gap between two vehicles is computed as leader rear bumper minus follower front bumper: `gap = leader.x - follower.x - leader.length`. For a four-vehicle platoon at 20 m equilibrium gap with 5 m vehicle length, the correct initial positions are:

| **vehicle_id** | **initial_position_m** |
|----------------|------------------------|
| 1 (lead)       | 100                    |
| 2              | 75                     |
| 3              | 50                     |
| 4              | 25                     |

**Leader topology** rules: exactly one vehicle must have a blank `leader_id` — this is the lead vehicle and must use the `LEAD_PROFILE` model. All other vehicles must reference a `vehicle_id` that exists in the sheet. Circular chains (A leads B leads A) are detected and rejected.

#### 2.2 Conditionally Required Columns

These columns are required only when a specific model is assigned:

| **Column**          | **Required when**                                                      | **Validation**                              |
|---------------------|------------------------------------------------------------------------|---------------------------------------------|
| `desired_speed_mps` | model is `IDMHumanModel`, `IDMModel`, CACCModel, or `Wiedemann99Model` | \> 0; meters per second                     |
| `time_headway_s`    | model is `IDMHumanModel` or `IDMModel`                                 | \> 0; typically 0.8–2.5 s for human drivers |
| `reaction_time_s`   | model is `IDMHumanModel`                                               | \> 0; typically 0.5–1.5 s                   |

For CACC vehicles, `desired_speed_mps` should be set slightly above the lead vehicle's cruise speed, typically 10% higher. The CACC target headway is not a per-vehicle parameter. It is the system-level cacc_target_headway_s setting in the simulation sheet tat sets the headway to an identical value for all CACC vehicles. This design is intentional: string stability is a platoon property that depends on all vehicles using the same headway.

#### 2.3 Optional Response Parameter Columns

These five columns override the vehicle response model parameters for individual vehicles. If blank, the value falls through to the vehicle type, then the simulation sheet global, then the hardcoded default, as described in Section 2.4.

| **Column**       | **Default** | **Notes**                                                |
|------------------|-------------|----------------------------------------------------------|
| `vehicle_type`   | —           | String matching a `type_id` in the `vehicle_types` sheet |
| `tau_throttle_s` | 0.5         | Throttle time constant (s)                               |
| `tau_brake_s`    | 0.3         | Brake time constant (s)                                  |
| `a_max_mps2`     | 2.5         | Maximum acceleration (m/s²)                              |
| `a_min_mps2`     | −8.0        | Maximum deceleration (m/s²); must be negative            |
| `j_max_mps3`     | 5.0         | Jerk limit (m/s³)                                        |

#### 2.4 The Four-Level Parameter Resolution Hierarchy

The five response parameters are resolved in this priority order for each vehicle:

1.  **Per-vehicle column** — a non-blank value in the vehicles sheet wins immediately
2.  **Vehicle type lookup** — if `vehicle_type` is set and the `vehicle_types` sheet exists, the matching row is used
3.  **Simulation sheet globals** — the global default values from the simulation sheet
4.  **Hardcoded defaults** — the built-in defaults listed in the table above

This means a simple homogeneous fleet needs no `vehicle_types` sheet and no per-vehicle override columns — the simulation sheet globals cover everything. A mixed fleet defines named types in `vehicle_types` and sets `vehicle_type` per row. An individual vehicle that is anomalous within its type can override a single parameter without defining a new type.

#### 2.5 Optional Wiedemann99 Columns

If any vehicle uses `Wiedemann99Model`, these columns may be added. Blank means use the defaults found in the VISSIM simulation model:

| **Column** | **VISSIM default** | **Physical meaning**                |
|------------|--------------------|-------------------------------------|
| `w_CC0`    | 1.5 m              | Standstill distance                 |
| `w_CC1`    | 0.9 s              | Desired time headway                |
| `w_CC2`    | 4.0 m              | Following variation                 |
| `w_CC3`    | −8.0               | Threshold entering following regime |
| `w_CC4`    | −0.35              | Negative speed-difference threshold |
| `w_CC5`    | 0.35               | Positive speed-difference threshold |
| `w_CC6`    | 6.0                | Influence of gap on oscillation     |
| `w_CC7`    | 0.25 m/s²          | Oscillation acceleration            |
| `w_CC8`    | 2.0 m/s²           | Standstill acceleration             |
| `w_CC9`    | 1.5 m/s²           | Desired acceleration at 80 km/h     |

#### 2.6 What Not to Put in the Vehicles Sheet

CACC controller gains (`cacc_k1`, `cacc_k2`, `cacc_k_ff`) are system-level parameters, therefore they are found in the simulation sheet, not the vehicles sheet. Putting them per-vehicle would prevent reasoning about string stability as a platoon property, since stability depends on all vehicles using the same gains.

***

### 3. The Simulation Sheet

The simulation sheet is a two-column key-value table: the left column contains parameter names, the right column contains their values. Order does not matter. Parameters not present in the sheet fall through to their hardcoded defaults.

Parameters are organized here by logical group.

#### 3.1 Timing Parameters

| **Key**      | **Default** | **Notes**                                                |
|--------------|-------------|----------------------------------------------------------|
| `duration_s` | —           | Total simulation time in seconds. Required — no default. |

#### 3.2 Rendering Parameters

| Key                 | Default | Notes                                                                                                                                                                                                                                                                                                                                                       |
|---------------------|---------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `simulation_speed`  | 1.0     | `0` = headless batch (no window); `1.0` = real time; `2.0` = 2× speed. Values between 0 and 1 slow the simulation below real time. Note: simulation_speed controls the speed of the live renderer during a simulation run only. It has no effect when replaying a saved CSV. Playback speed in that mode is controlled interactively with the + and - keys. |
| `render_interval_s` | 0.1     | How often the Pygame window updates in seconds. 0.1 s (10 Hz) is smooth enough for visual inspection. Reducing this below 0.05 s provides no perceptible benefit.                                                                                                                                                                                           |

#### 3.3 Sensor and Communications Configuration

| **Key**          | **Default**   | **Options**                    | **Notes**                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|------------------|---------------|--------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `sensor_model`   | `passthrough` | `passthrough`, `kalman`, `lpf` | Controls both the radar sensor pipeline and the ego vehicle sensor (IMU and wheel encoder noise). passthrough bypasses all sensor noise — plant values are used directly. kalman activates radar delay and AR(1) noise with Kalman filtering, plus IMU bias drift and speed noise on the ego vehicle. lpf uses a low-pass filter in place of the Kalman filter for radar and also implements IMU bias drift and speed noise on the ego vehicle. See Part 3 for details. |
| `comms_model`    | `passthrough` | `passthrough`, `v2v`           | Controls V2V communications. v2v also activates the fusion Kalman filter. See Part 3.                                                                                                                                                                                                                                                                                                                                                                                   |
| `response_model` | `lag`         | `lag`, `kinematic`             | `lag` applies first-order actuator dynamics. `kinematic` applies commanded acceleration instantly — useful for isolating control behavior from actuator effects.                                                                                                                                                                                                                                                                                                        |

#### 3.4 CACC Gains

These are system-level parameters that apply to all CACC vehicles in the platoon. See Section 9 for a full explanation of what each gain does and how they interact.

| **Key**                 | **Default** | **Notes**                                          |
|-------------------------|-------------|----------------------------------------------------|
| `cacc_k1`               | 0.45        | Gain on gap error (m/s² per m)                     |
| `cacc_k2`               | 0.25        | Gain on relative velocity (m/s² per m/s)           |
| `cacc_k_ff`             | 0.90        | Feedforward gain on BSM-reported lead acceleration |
| `cacc_target_headway_s` | 0.6         | Target time headway for CACC (s)                   |
| `cacc_s0_m`             | 2.0         | Standstill gap for CACC (m)                        |

The string stability condition with these gains is `k_ff + k2 × T_h ≥ 1`. With the defaults: `0.90 + 0.25 × 0.6 = 1.05` — string stable with a margin of 0.05 above the boundary. CAVSandbox logs a warning at startup if the configured gains violate this condition.

#### 3.5 Global Response Model Parameters

These are the Level 3 defaults in the four-level hierarchy. They apply to all vehicles that do not have a vehicle type or per-vehicle override:

| **Key**          | **Default** | **Notes**                   |
|------------------|-------------|-----------------------------|
| `tau_throttle_s` | 0.5         | Throttle time constant      |
| `tau_brake_s`    | 0.3         | Brake time constant         |
| `a_max_mps2`     | 2.5         | Maximum acceleration (m/s²) |
| `a_min_mps2`     | −8.0        | Maximum deceleration (m/s²) |
| `j_max_mps3`     | 5.0         | Jerk limit (m/s³)           |

#### 3.6 Logging and Output Parameters

| **Key**       | **Default** | **Notes**                                                                                                                                                                                                              |
|---------------|-------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `log_rate_hz` | 10          | CSV logging rate. The simulation always runs at 100 Hz; only every N-th step is logged. Default of 10 Hz reduces a 100 s run from 1 M rows to 100 k rows. Collision rows are always logged regardless of this setting. |
| `master_seed` | 0           | Random seed for all stochastic processes — radar noise, IMU noise, BSM packet drop. Set to a fixed integer for reproducible runs. Override on the command line with `--seed N`.                                        |

***

### 4. The Profile Sheet

The profile sheet defines the lead vehicle's drive cycle — a sequence of time-triggered speed commands that the `LeadVehicleModel` follows. It is the primary forcing function for the entire platoon.

#### 4.1 Sheet Structure

| **Column**   | **Type** | **Notes**                                                                                                         |
|--------------|----------|-------------------------------------------------------------------------------------------------------------------|
| `time_s`     | float    | Simulation time at which this event takes effect. Rows are sorted by time at load time regardless of sheet order. |
| `value`      | float    | Target speed (m/s).                                                                                               |
| `transition` | string   | `step` — change immediately. `ramp` — interpolate linearly to the next waypoint. Default is `ramp` if blank.      |
| `note`       | string   | Optional human-readable label. Not used by the simulation.                                                        |

Before the first event the first value is held. After the last event the last value is held. This means a profile with a single row produces a constant speed for the entire run.

#### 4.2 Transition Types

**Step transitions** change the target speed instantaneously at the specified time. The lead vehicle's proportional speed controller then commands the acceleration needed to reach the new target, subject to actuator limits. The result is a rapid but physically limited speed change — not a true instantaneous velocity jump, because the vehicle response model applies actuator lag.

**Ramp transitions** interpolate linearly between the current row's value and the next row's value over the time interval between them. This produces a constant rate of change of the speed target during the transition. Ramp is the transition type of the current row, governing how it transitions to the next — the last row's transition setting has no effect since there is no following row.

A common point of confusion: to produce a ramp deceleration from 30 m/s to 25 m/s starting at t=10s and completing at t=40s, two rows are needed:

| **time_s** | **value** | **transition** | **note**           |
|------------|-----------|----------------|--------------------|
| 10         | 30.0      | ramp           | begin deceleration |
| 40         | 25.0      | ramp           | end deceleration   |

The first row says "at t=10s, begin ramping from 30.0 m/s toward the next waypoint." The second row says "arrive at 25.0 m/s at t=40s." After t=40s the lead vehicle holds 25.0 m/s.

#### 4.3 Building Common Profile Shapes

**Constant speed** — a single row:

| **time_s** | **value** | **transition** |
|------------|-----------|----------------|
| 0          | 30.0      | step           |

**Step change** — two rows:

| **time_s** | **value** | **transition** |
|------------|-----------|----------------|
| 0          | 30.0      | step           |
| 10         | 25.0      | step           |

**Ramp deceleration and recovery** — four rows:

| **time_s** | **value** | **transition** |
|------------|-----------|----------------|
| 0          | 30.0      | step           |
| 10         | 30.0      | ramp           |
| 40         | 24.0      | ramp           |
| 70         | 30.0      | ramp           |

**Sinusoidal approximation** — the profile sheet does not have a native sinusoidal mode, but a piecewise-linear approximation using ramp transitions can closely replicate a sine wave. With N waypoints per period and amplitude A around offset v₀:

```
t_i = warmup_s + i × (T / N)
v_i = v₀ + A × sin(2π × i / N)
```

With N=8 waypoints per period the maximum speed error is `A × (1 − cos(π/8)) ≈ 0.15 m/s` for A=2 m/s — acceptable for string stability studies. A 60-second warmup followed by 5 cycles at 0.1 Hz requires 42 profile rows. The Filter_tests validation workbooks use this approach and can serve as a reference.

#### 4.4 Profile Design Considerations

The lead vehicle follows its profile using a proportional speed controller with gain `kp=0.5`. This means the vehicle tracks the target speed smoothly but does not instantaneously jump to it even for step transitions. At highway speeds the tracking error is negligible for typical scenarios. At very low speeds or for very sharp step changes, the lead vehicle may not fully reach the target before the next event fires — design profiles with sufficient time between events for the vehicle to settle.

***

### 5. The Vehicle Types Sheet

The vehicle types sheet is optional. Omit it entirely for homogeneous fleets — the simulation sheet globals cover all vehicles. Include it when modeling a mixed fleet where different vehicle classes have meaningfully different response characteristics.

#### 5.1 Sheet Structure

| **Column**       | **Type** | **Validation**                                                            |
|------------------|----------|---------------------------------------------------------------------------|
| `type_id`        | string   | Unique, no blanks. Referenced by `vehicle_type` column in vehicles sheet. |
| `tau_throttle_s` | float    | \> 0                                                                      |
| `tau_brake_s`    | float    | \> 0                                                                      |
| `a_max_mps2`     | float    | \> 0                                                                      |
| `a_min_mps2`     | float    | \< 0                                                                      |
| `j_max_mps3`     | float    | \> 0                                                                      |

All parameter columns must be non-blank and numeric — partial rows are not permitted. Unlike the vehicles sheet where blank triggers fallthrough, the vehicle_types sheet requires complete rows because a type definition with missing values would be ambiguous.

#### 5.2 Example

A mixed fleet of passenger cars and heavy trucks:

| **type_id** | **tau_throttle_s** | **tau_brake_s** | **a_max_mps2** | **a_min_mps2** | **j_max_mps3** |
|-------------|--------------------|-----------------|----------------|----------------|----------------|
| car         | 0.5                | 0.3             | 2.5            | −8.0           | 5.0            |
| heavy_truck | 0.9                | 0.5             | 1.2            | −5.0           | 3.0            |

In the vehicles sheet, set `vehicle_type` to `car` or `heavy_truck` per row. Vehicles with a blank `vehicle_type` fall through to simulation sheet globals.

#### 5.3 When Vehicle Types Are Worth the Effort

Vehicle types add meaningful fidelity when the difference in response characteristics between vehicle classes is large enough to affect platoon behavior. The difference between `tau_throttle=0.5` (car) and `tau_throttle=0.9` (truck) is significant at 0.6 s CACC headway — the truck's slower actuator response means it reaches its commanded acceleration later, which the following vehicle has no direct way to know. For a homogeneous fleet of identical vehicles, vehicle types add no information and should be omitted.


---

## Part 2 — Driving Models

### 6. Choosing a Driving Model

CAVSandbox includes five driving models. Four are built in; one comes as a plugin. The `model` column in the vehicles sheet determines which model each vehicle uses.

| **Model**          | **Type**              | **Represents**                                       |
|--------------------|-----------------------|------------------------------------------------------|
| `IDMModel`         | ACC                   | Sensor-based automated following, no reaction delay  |
| `IDMHumanModel`    | Human driver          | Attentive human with reaction delay                  |
| `CACCModel`        | CACC                  | Cooperative automated following with V2V feedforward |
| `Wiedemann99Model` | Human driver (plugin) | Psychophysical regime-switching human driver         |
| `LeadVehicleModel` | Lead vehicle          | Prescribed speed profile — not a car-following model |

Every vehicle in the platoon must be assigned one of these models. The lead vehicle must use `LeadVehicleModel`. All other vehicles use one of the four car-following models — they can be mixed freely in a single scenario, which is how mixed-traffic studies are configured.

The choice of model depends on what you are studying. If your research question is about CACC performance, use `CACCModel` for automated followers and `IDMHumanModel` for any human drivers in the scenario. If you are studying the effect of reaction time on platoon stability, use `IDMHumanModel` with varying `reaction_time_s` values. If you need behavior that matches VISSIM's default model or want regime-switching following dynamics, use `Wiedemann99Model`. For quick baseline comparisons where human driver realism is not the focus, `IDMModel` is simpler and more predictable than `IDMHumanModel`.

***

### 7. IDMModel (ACC)

`IDMModel` represents a vehicle equipped with Adaptive Cruise Control.

#### 7.1 What It Models

An ACC system measures the gap to the preceding vehicle using radar and controls throttle and brake to maintain a desired time headway. The driver sets a desired speed and headway; the system handles the longitudinal control. `IDMModel` captures this behavior using the IDM formula with sensor-quality inputs rather than human-perception inputs.

The IDM computes a desired acceleration based on four inputs: the vehicle's own speed, the gap to the vehicle ahead, the relative velocity between the two vehicles, and a desired speed the driver is trying to maintain. The output is a smooth acceleration that handles everything from free-flow cruising to emergency braking within a single formula, no separate regimes are required.

The `IDMHumanModel`, it is purely reactive — it only knows what its own radar measures and has no information about what the leader is planning to do. This is the fundamental limitation that CACC addresses.

#### 7.2 Per-Vehicle Parameters

These parameters are configured in the vehicles sheet. Values may also be set at the vehicle type level or simulation sheet level using the four-level hierarchy described in Section 2.4; the per-vehicle column always takes priority.

| **Parameter**       | **Default** | **Required** | **Notes**                                                                                                                                                                   |
|---------------------|-------------|--------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `desired_speed_mps` | —           | Yes          | Target free-flow speed (m/s). No default, must be set explicitly.                                                                                                           |
| `time_headway_s`    | —           | Yes          | Desired time gap to preceding vehicle (s). No default, must be set explicitly. Typical ACC range: 1.0–2.5s. Shorter headways increase efficiency but reduce safety margins. |

#### 7.3 Preset, Fixed Parameters

The IDM formula also uses parameters for comfortable acceleration (`a_max`), comfortable deceleration (`b`), minimum gap at standstill (`s0`), and acceleration exponent (`delta`). These are not exposed as per-vehicle columns because they are less influential than `desired_speed_mps`, `time_headway_s`, and `reaction_time_s` for the scenarios CAVSandbox is designed for, and because exposing them would clutter the vehicles sheet for most users. They take their built-in defaults, which are calibrated to typical passenger car behavior. Plugin authors who need to vary them can do so by subclassing `IDMHumanModel`.

#### 7.4 When to Use It

Use `IDMModel` to represent ACC-equipped vehicles in mixed-traffic scenarios, or as a cleaner human driver baseline when reaction time is not relevant to your research question. It is also useful for understanding the performance ceiling of pure radar-based following — the improvement CACC provides over `IDMModel` is precisely the benefit of V2V feedforward.

### 8. IDMHumanModel

`IDMHumanModel` represents an attentive human driver using the Intelligent Driver Model with an added perception reaction time delay.

#### 8.1 What It Models

`IDMHumanModel` adds a reaction time delay on top of the base IDM. The delay applies to the perceived quantities (gap, lead vehicle speed, and lead vehicle acceleration), but not to the driver's own speed, which is known from the speedometer without delay. This distinction is physically correct: a driver perceives the gap to the vehicle ahead with some lag but knows their own speed immediately.

On the first simulation step the delay buffer is pre-seeded with the initial perceived values so there is no artificial startup transient.

#### 8.2 Per-Vehicle Parameters

These parameters are configured in the vehicles sheet. Values may also be set at the vehicle type level or simulation sheet level using the four-level hierarchy described in Section 2.4; the per-vehicle column always takes priority.

| **Parameter**       | **Default** | **Required** | **Notes**                                                                                                                         |
|---------------------|-------------|--------------|-----------------------------------------------------------------------------------------------------------------------------------|
| `desired_speed_mps` | —           | Yes          | The speed the driver tries to maintain in free flow (m/s). Typical highway value: 30–33 m/s.                                      |
| `time_headway_s`    | —           | Yes          | The driver's preferred time gap to the vehicle ahead. Typical range: 0.8–2.5 s. Shorter values produce more aggressive following. |
| `reaction_time_s`   | —           | Yes          | Perception reaction delay (s). Typical range: 0.5–1.5 s. Longer values increase string instability risk.                          |

#### 8.3 When to Use It

Use `IDMHumanModel` whenever you need a physically plausible human driver — in mixed-traffic scenarios alongside ACC or CACC vehicles, as a baseline comparison against automated models, or when studying how reaction time affects platoon stability.

***

### 9. CACCModel

`CACCModel` represents a vehicle equipped with Cooperative Adaptive Cruise Control. It extends ACC with a feedforward term on the lead vehicle's acceleration received via V2V communication. This feedforward term is what distinguishes CACC from ACC and enables string-stable following at shorter headways.

#### 9.1 What It Models

The CACC controller combines two components: a feedback term that responds to gap error and relative velocity (the same structure as ACC), and a feedforward term that anticipates the leader's acceleration from the BSM. The commanded acceleration is:

```
a_cmd = k1 × e_gap + k2 × e_vel + k_ff × a_lead_v2v

where:
  e_gap = gap - desired_gap(v_ego)     gap error (m)
  e_vel = v_leader - v_ego             relative velocity (m/s)
  a_lead_v2v = leader acceleration from BSM (m/s²)
  desired_gap(v) = s0 + T_h × v        constant time headway policy
```

The feedback terms (`k1 × e_gap + k2 × e_vel`) behave like an ACC controller — they correct for errors that have already developed. The feedforward term (`k_ff × a_lead_v2v`) anticipates changes before they create an error, allowing the follower to begin responding at the same time as the leader rather than after a reaction delay.

#### 9.2 System-Level Gains

Desired_speed_mps can be set at the vehicle, vehicle type, or simulation level. It is required.

CACC gains, however, are configured in the simulation sheet, not the vehicles sheet, because string stability is a platoon property that requires all vehicles to use the same gains. There are default values if these aren’t provided, however they generally should be set explicitly in the simulation sheet, since these parameters may be part of what is being studied. The default values for k1, k2, and k_ff were chosen to be string-stable at the default 0.6 s target heaway. The relevant simulation sheet parameters are:

| **Parameter**           | **Default** | **Notes**                            |
|-------------------------|-------------|--------------------------------------|
| `cacc_k1`               | 0.45        | Gain on gap error                    |
| `cacc_k2`               | 0.25        | Gain on relative velocity            |
| `cacc_k_ff`             | 0.90        | Feedforward gain on BSM acceleration |
| `cacc_target_headway_s` | 0.6         | Target time headway (s)              |
| `cacc_s0_m`             | 2.0         | Standstill gap (m)                   |

#### 9.3 String Stability

String stability requires that a speed disturbance at the lead vehicle does not amplify as it propagates back through the platoon. For the CACC controller above, the simplified string stability condition is:

```
k_ff + k2 × T_h ≥ 1
```

With the default gains: `0.90 + 0.25 × 0.6 = 1.05` — string stable with a margin of 0.05 above the boundary. CAVSandbox prints a warning at startup if the configured gains violate this condition. The warning does not stop the simulation — running with string-unstable gains is sometimes the intended experiment.

The condition assumes perfect V2V communication. With realistic V2V comms (`comms_model='V2V'`), packet drops cause the feedforward term to go to zero intermittently, effectively reducing the average `k_ff` below its configured value. This means gains that are theoretically stable may be marginally stable in practice under realistic comms. See Section 25 for a detailed treatment of empirical string stability testing.

#### 9.4 Graceful Degradation

When the BSM is unavailable, either because `comms_model='passthrough'` is set, or because a packet has been dropped and the BSM age exceeds `bsm_max_age_s`, the feedforward term drops to zero:

```
a_ff = k_ff × 0.0 = 0.0
```

The controller falls back to pure feedback behavior, equivalent to ACC at the CACC headway. No mode switch or special handling is required — the degradation is seamless and automatic. The shorter CACC headway (0.6 s versus typical ACC headways of 1.4 s) means pure-feedback performance at this headway is more demanding than ACC operation, which is one reason maintaining reliable V2V communication matters.

#### 9.5 When to Use It

Use `CACCModel` for any vehicle that should use cooperative adaptive cruise control. For meaningful CACC behavior, at least the lead vehicle and one follower must be in the platoon — a single CACC vehicle with no V2V partner is just ACC at a short headway. For string stability studies, a minimum of three to four vehicles is recommended so that amplitude growth or decay across platoon positions can be observed.

***

### 10. Wiedemann99Model (Plugin)

`Wiedemann99Model` implements the Wiedemann 1974 psychophysical car-following model in its VISSIM-parameterized form (Wiedemann 99). It ships as a plugin rather than a built-in model, both as a worked example for plugin authors and because it is primarily useful for scenarios where human driver realism is the central concern.

#### 10.1 What It Models

The defining characteristic of the Wiedemann model is that drivers do not react continuously. Instead, they respond only when their perception of the traffic situation crosses a psychophysical threshold. Between threshold crossings the driver coasts — making no pedal input — which produces the oscillatory following behavior observed in naturalistic driving data.

The model defines four regimes:

| **Regime**   | **Condition**                                     | **Driver behavior**                              |
|--------------|---------------------------------------------------|--------------------------------------------------|
| Free driving | Gap exceeds perception threshold                  | Accelerates toward desired speed; ignores leader |
| Closing in   | Approaching leader, gap above desired but closing | Begins braking to avoid overshoot                |
| Following    | Near equilibrium gap, small speed difference      | Small oscillations around desired gap            |
| Braking      | Gap below desired (emergency)                     | Hard deceleration                                |

This regime-switching structure is what produces the stop-and-go oscillations and inattentive coasting phases observed in real traffic — phenomena that the continuous IDM does not produce.

#### 10.2 Per-Vehicle Parameters

The CC0–CC9 parameters control the threshold boundaries between regimes. The default values are the same as those used in the VISSIM simulation model, which are calibrated to typical highway following behavior.

| **Parameter**       | **Default** | **Required** | **Notes**                                                         |
|---------------------|-------------|--------------|-------------------------------------------------------------------|
| `desired_speed_mps` | —           | Yes          | Target free-flow speed (m/s). No default, must be set explicitly. |
| `w_CC0`             | 1.5m        | No           | Standstill distance                                               |
| `w_CC1`             | 0.9s        | No           | Desired time headway                                              |
| `w_CC2`             | 4.0m        | No           | Following variation                                               |
| `w_CC3`             | -8.0        | No           | Threshold entering following regime                               |
| `w_CC4`             | -0.35       | No           | Negative speed-difference threshold                               |
| `w_CC5`             | 0.35        | No           | Positive speed-difference threshold                               |
| `w_CC6`             | 6.0         | No           | Influence of gap on oscillation                                   |
| `w_CC7`             | 0.25m/s2    | No           | Oscillation acceleration                                          |
| `w_CC8`             | 2.0m/s2     | No           | Standstill acceleration                                           |
| `w_CC9`             | 1.5m/s2     | No           | Desired acceleration at 80 km/h                                   |

#### 10.3 IDMHumanModel vs. Wiedemann99Model

Both models represent human drivers but emphasize different aspects of human behavior.

`IDMHumanModel` is a continuous model with a clean mathematical structure. Its parameters connect directly to measurable quantities — desired headway, comfortable deceleration, reaction time. It is easier to calibrate from first principles, has well-understood stability properties, and produces predictable behavior that is straightforward to compare against ACC and CACC. For most teaching scenarios and mixed-traffic studies, it is the right choice.

`Wiedemann99Model` is more realistic in its representation of the moment-to-moment mechanics of human following — the inattentive coasting, the threshold-triggered corrections, the oscillatory following pattern. It is the right choice when the research question specifically requires regime-switching behavior, when the goal is to replicate naturalistic driving data, or when results need to be comparable to VISSIM simulations that use Wiedemann99 as their default model.

The calibration caveat is worth noting: the CC0–CC9 parameters do not have the same direct physical interpretation as IDM parameters. The VISSIM defaults work well for typical highway following but may not represent specific driver populations or road conditions without recalibration against observed data.

#### 10.4 When to Use It

Use `Wiedemann99Model` when regime-switching following behavior is important to your research question, when VISSIM comparability is needed, or when studying dense traffic and stop-and-go conditions where the inattentive coasting phase affects platoon dynamics. For most CACC studies with human vehicles in the platoon, `IDMHumanModel` is simpler and more appropriate.

***

### 11. LeadVehicleModel

`LeadVehicleModel` is not a car-following model. It drives the lead vehicle according to a prescribed speed profile defined in the profile sheet, regardless of what any other vehicle is doing. It is the forcing function for the entire platoon.

#### 11.1 What It Models

The lead vehicle reads speed targets from the profile sheet and tracks them using a proportional speed controller. When the current speed differs from the target, the controller commands an acceleration proportional to the error:

```
a_cmd = kp × (v_target - v_ego)     where kp = 0.5
```

The commanded acceleration is then subject to the vehicle response model (actuator lag, jerk limits, acceleration limits) exactly like any other model. This means even a `step` transition in the profile sheet produces a physically realistic acceleration response rather than an instantaneous velocity jump.

#### 11.2 Configuration

`LeadVehicleModel` requires no per-vehicle columns beyond the standard required columns. All behavior is determined by the profile sheet. See Section 4 for a complete reference on configuring the profile.

Exactly one vehicle must use `LeadVehicleModel` — the vehicle with a blank `leader_id`. Using it on any other vehicle, or not using it on the lead vehicle, will cause a validation error.

#### 11.3 The Lead Vehicle's Role

The lead vehicle's speed trajectory is the primary experimental variable in most CAVSandbox scenarios. The follower models are the dependent variables — their behavior is what you are studying. Designing the lead vehicle profile thoughtfully is therefore the most important scenario design decision. Section 4.3 provides guidance on building common profile shapes. For string stability studies specifically, the sinusoidal approximation profile described in Section 4.3 and Section 25 is the recommended approach.


---

## Part 3 — Sensor and Communications Configuration

### 12. Sensor Pipeline Overview

When a simulation runs with realistic sensors, each follower vehicle's state estimate passes through three components before reaching the driving model. Understanding these components helps interpret what the diagnostic plots show and why realistic sensor runs differ from passthrough runs.

The three components are:

**Ego sensor.** The vehicle measures its own speed and acceleration. Speed comes from wheel encoders with small additive noise. Acceleration comes from an IMU with white noise plus a slowly drifting bias. The ego sensor output is used in two ways: it is passed into `VehicleState` as the vehicle's self-reported acceleration, and it is broadcast in the BSM so that following vehicles receive a realistic (noisy) acceleration signal rather than the true plant value.

**Radar sensor.** The vehicle measures the gap to the vehicle ahead and the rate of change of that gap. The radar introduces a fixed processing delay, temporally correlated measurement noise on both gap and gap-rate, and a filter (Kalman or low-pass) that produces smoothed estimates from the noisy measurements.

**Fusion estimator.** When V2V comms are active, the fusion Kalman filter combines the radar measurements (arriving at 100 Hz) with BSM-reported leader acceleration (arriving at approximately 10 Hz) into a joint three-state estimate of gap, gap-rate, and leader acceleration. When comms are in passthrough mode, this layer simply passes the radar output through unchanged.

The `sensor_model` key in the simulation sheet controls Layers 1 and 2 together. The `comms_model` key controls Layer 3. These two keys are the only sensor configuration needed for standard scenarios.

**Passthrough bypass.** When `sensor_model='passthrough'`, all three layers are bypassed entirely: the driving model receives exact plant values with no noise, no delay, and no filtering. No sensor objects are instantiated. The passthrough baseline is useful for testing and debugging, but it is also a meaningful option that establishes what behavior would look like under ideal sensing, providing a reference against which realistic sensor runs can be compared.

***

### 13. Sensor Model Options

The `sensor_model` key accepts three values: `passthrough`, `kalman`, and `lpf`.

#### 13.1 Passthrough

```
sensor_model = passthrough
```

All sensor noise, delay, and filtering is disabled. The driving model receives exact plant values: true gap, true gap-rate, true ego speed, and true ego acceleration. This is the default and the recommended starting point for any new scenario — validate the control behavior under ideal conditions before adding sensor realism.

Use passthrough when:

-   Setting up and debugging a new scenario
-   Studying control gains in isolation from sensor effects
-   Establishing a baseline for comparison with realistic sensor runs
-   Running quickly without the computational overhead of the sensor pipeline

#### 13.2 Kalman Filter Mode

```
sensor_model = kalman
```

Activates the full realistic sensor pipeline for both the radar and ego sensor.

**Radar pipeline:**

-   70 ms fixed processing delay — the radar measurement reflects the true gap from 70 ms ago
-   Temporally correlated noise applied to both gap (σ = 0.30 m, ρ = 0.80) and gap-rate (σ = 0.10 m/s, ρ = 0.80) — each measurement error is 80% carried over from the previous step, producing slowly wandering errors that can bias the gap estimate for hundreds of milliseconds
-   `GapKalmanFilter` — a two-state Kalman filter estimating gap and gap-rate jointly from the noisy delayed measurements. The filter is optimal given the noise model and produces a smoother gap-rate estimate than finite differencing would

**Ego sensor pipeline:**

-   Wheel encoder speed noise: white Gaussian noise with σ = 0.05 m/s
-   IMU acceleration: white noise (σ = 0.08 m/s²) plus a slowly drifting bias (drift rate 0.02 m/s² per second) — the bias is the dominant error source for real MEMS accelerometers and is the reason CACC string stability is more conservative in practice than theory predicts

The output columns in `data.csv` for kalman mode include both the raw noisy measurements (`gap_meas`, `gap_rate_meas`) and the Kalman filter estimates (`gap_filtered`, `gap_rate_filtered`), allowing the filter's performance to be evaluated directly from the logged data.

#### 13.3 Low-Pass Filter Mode

```
sensor_model = lpf
```

Identical to kalman mode except the gap filter:

-   Same 70 ms delay and same correlated noise on gap and gap-rate
-   `LowPassFilter` — a first-order IIR filter at 2.0 Hz cutoff applied independently to gap and gap-rate, replacing the Kalman filter
-   Ego sensor pipeline: identical to kalman mode

The low-pass filter is simpler than the Kalman filter and easier to understand but less optimal — it applies the same smoothing regardless of the noise level, whereas the Kalman filter weights measurements by their estimated reliability. For teaching purposes, comparing kalman and lpf runs illustrates the tradeoff between filter complexity and performance.

***

### 14. Ego Sensor

The ego sensor models the vehicle's perception of its own state. This matters specifically for CACC because the BSM broadcasts the ego-measured acceleration — not the true plant acceleration — to following vehicles. IMU noise therefore propagates through the V2V channel into the feedforward term of every downstream vehicle.

#### 14.1 Speed Measurement

Speed is measured by wheel encoders, modeled as white Gaussian noise with σ = 0.05 m/s. This is small relative to highway speeds and has negligible effect on control performance. The measured speed is clamped to zero from below — a rare noise excursion cannot produce a negative speed reading.

#### 14.2 Acceleration Measurement

Acceleration is measured by an IMU (inertial measurement unit), modeled with two components:

**White noise** (σ = 0.08 m/s²) — fast, independent sample-to-sample variation from vibration and electronic noise.

**Bias drift** — a slowly wandering DC offset that accumulates as a random walk. The drift rate is 0.02 m/s² per second, meaning the bias can shift by this amount each second of simulation time. Unlike white noise, bias drift persists — a bias of 0.1 m/s² at t=10 s may still be approximately 0.1 m/s² at t=11 s. This is the dominant error source for real MEMS accelerometers and is the reason CACC string stability is more conservative in practice than theory predicts.

#### 14.3 IMU Noise Propagation

The consequence for CACC is direct. When vehicle 2 broadcasts its acceleration via BSM, it broadcasts its IMU measurement — white noise plus bias drift. Vehicle 3 receives this as `lead_a_v2v` and applies `k_ff × lead_a_v2v` as a feedforward command. A bias of 0.1 m/s² in vehicle 2's IMU therefore produces a persistent 0.09 m/s² (= 0.90 × 0.1) feedforward offset in vehicle 3's commanded acceleration. Vehicle 3's own IMU then adds its own noise to the BSM it broadcasts to vehicle 4, compounding the effect down the platoon.

This propagation is physically correct and is one reason the string stability condition is derived assuming clean feedforward signals — real systems require a larger stability margin to absorb IMU noise. Running a comparison between `sensor_model='passthrough'` and `sensor_model='kalman'` with `comms_model='v2v'` directly demonstrates this effect.

***

### 15. V2V Communications Model

The `comms_model` key controls the V2V communications pipeline. Two options are available: `passthrough` and `v2v.`

#### 15.1 Passthrough Communications

```
comms_model = passthrough
```

Perfect V2V — the leader's acceleration is delivered to every following vehicle instantly, with no delay, no packet loss, and no noise. The value delivered is the leader's true plant acceleration, not the ego-measured value.

Use passthrough comms when:

-   Studying CACC control behavior in isolation from comms imperfections
-   Establishing a baseline for comparison with realistic comms runs
-   Running with `sensor_model='passthrough'` for a fully ideal baseline

#### 15.2 V2V Communications

```
comms_model = v2v
```

Realistic V2V communications. Activating V2V also activates the fusion Kalman filter (Layer 3 of the sensor pipeline). The two are always coupled because the fusion filter has no purpose without BSM data.

**BSM content.** The BSM carries the leader's ego-measured acceleration — the IMU output including noise and bias drift, not the true plant acceleration. This is the physically correct model: real BSMs are populated from the vehicle's own sensors.

**Transmission rate.** BSMs are broadcast at 10 Hz (every 100 ms). Each vehicle's broadcast is staggered by a random offset at initialization, derived deterministically from the master seed, so all vehicles do not broadcast simultaneously — a more realistic model of V2V channel access.

**Packet drop.** Each broadcast attempt is independently dropped with probability `bsm_packet_drop_rate` (default 0.02). At 10 Hz with 2% drop rate, consecutive drops are rare (probability 0.04%) but occur occasionally. The packet drop RNG is seeded independently per vehicle so each vehicle has its own drop history.

**Staleness.** The BSM age (`bsm_age_s`) tracks how many seconds have passed since the last received packet. When `bsm_age_s ≥ bsm_max_age_s` (default 0.30 s), the BSM is declared stale and `lead_a_v2v` returns 0.0 — the CACC feedforward term drops to zero and the controller degrades gracefully to pure feedback. A threshold of 0.30 s tolerates up to two consecutive dropped packets before declaring stale.

**Relevant simulation sheet parameters:**

| **Key**                | **Default** | **Notes**                                 |
|------------------------|-------------|-------------------------------------------|
| `bsm_rate_hz`          | 10.0        | BSM broadcast rate (Hz)                   |
| `bsm_packet_drop_rate` | 0.02        | Per-packet drop probability (0–1)         |
| `bsm_max_age_s`        | 0.30        | Age threshold for declaring BSM stale (s) |

The `bsm_age_s` column in `data.csv` records the BSM age for each vehicle at each logged timestep. Plotting this column produces the sawtooth pattern seen in the diagnostic plots — regular drops to near-zero when packets arrive, with occasional tall spikes where packets were dropped.

***

### 16. Fusion Kalman Filter

The fusion Kalman filter is activated automatically when `comms_model='v2v'`. It fuses radar measurements (arriving every simulation step at 100 Hz) with BSM-reported leader acceleration (arriving approximately every 10 steps at 10 Hz) into a single joint estimate.

#### 16.1 What It Estimates

The filter maintains a three-state estimate:

```
x = [gap, gap_rate, a_lead]
```

Gap and gap-rate are estimated from the radar pipeline — the same quantities as the two-state `GapKalmanFilter` used in `sensor_model='kalman'` mode. The third state, `a_lead`, is the filter's running estimate of the leader's acceleration, updated from BSM packets when they arrive and propagated forward using the filter's dynamics model between packets.

#### 16.2 Multi-Rate Update Protocol

Each simulation step (every 0.01 s):

1.  **Predict** — project the state estimate forward using the physics of the system: gap changes at gap-rate, gap-rate changes with leader and ego acceleration, leader acceleration is approximately constant between steps
2.  **Radar update** — apply the radar measurement to correct gap and gap-rate
3.  **BSM update (conditional)** — if a fresh BSM packet arrived this step (`bsm_age_s < dt`), apply it to update the `a_lead` state

Between BSM packets (9 steps out of every 10), the filter extrapolates `a_lead` from the dynamics model rather than holding the last received value or dropping to zero. This produces a smoother leader acceleration estimate than a simple hold-last strategy, at the cost of the filter's own model uncertainty accumulating between updates.

#### 16.3 Outputs

The fusion filter returns three values each step:

-   `gap_fused` — the fused gap estimate, used by the CACC controller for gap error
-   `rate_fused` — the fused gap-rate estimate, used for velocity error
-   `lead_a_radar` — the filter's estimate of leader acceleration, logged in `data.csv` but not currently used by the built-in CACC controller

`lead_a_radar` is available as a `VehicleState` field for plugin models that want a continuously-updated, Kalman-smoothed leader acceleration estimate — for example, future implementations of Enhanced IDM (EIDM) or Comfortable and Adaptive Headway (CAH) models that use leader acceleration as a continuous input rather than a discrete BSM signal.

The CACC controller uses `lead_a_v2v` (the raw BSM value) for its feedforward term, not `lead_a_radar`. This distinction is intentional: `lead_a_v2v` has lower latency and is the signal CACC was designed to use, while `lead_a_radar` is a smoothed estimate better suited to continuous-input models.

***

### Sensor Configuration Summary

The four practically useful configurations and what each is good for:

| `sensor_model` | `comms_model` | **Use for**                                                                         |
|----------------|---------------|-------------------------------------------------------------------------------------|
| `passthrough`  | `passthrough` | Full ideal baseline — validates control behavior with no sensor effects             |
| `kalman`       | `passthrough` | Isolates radar and ego sensor effects from comms effects                            |
| `passthrough`  | `v2v`         | Not recommended — passthrough radar with realistic comms is internally inconsistent |
| `kalman`       | v2v           | Full realistic pipeline — use for research results and comms degradation studies    |

The progression from full passthrough to full realistic is itself a meaningful sensitivity study — each step adds one source of imperfection and its effect on CACC performance can be isolated. This progression mirrors the development sequence used to validate the simulation itself.


---

## Part 4 — Running the Simulation

### 17. Command-Line Interface

CAVSandbox is invoked from the command line using Python's module runner. The entry point is `cacc_sim.main`, and the program name registered by the package installer is `cavsandbox`.

#### 17.1 Basic Usage

```bash
python -m cacc_sim.main <input>
```

The `input` argument is either an Excel workbook (`.xlsx`) or a results CSV file (`.csv`). The file extension determines what happens:

-   `.xlsx` — runs a simulation using the workbook as the scenario definition
-   `.csv` — launches the live renderer in playback mode, replaying a previously saved run

Any other extension produces an error:

```
cavsandbox: error: unrecognised file type '.txt'. Expected .xlsx for simulation or .csv for playback.
```

#### 17.2 Arguments and Flags

| **Argument**     | **Type**   | **Notes**                                                                                                                                                    |
|------------------|------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `input`          | positional | Path to `.xlsx` scenario file or `.csv` results file. Relative to current working directory.                                                                 |
| `--seed N`       | optional   | Override the `master_seed` value from the simulation sheet. Useful for running the same scenario with different random seeds without editing the Excel file. |
| `--help` or `-h` | optional   | Print usage summary and exit.                                                                                                                                |

#### 17.3 Running from the Project Root

All example commands in this guide assume you run from the project root directory: the folder containing `cacc_sim/`, `plugins/`, and `examples/`. If you run from a different directory, adjust file paths accordingly:

```bash
# From project root — works as written
python -m cacc_sim.main examples/quickstart.xlsx

# From a different directory — adjust the path
python -m cacc_sim.main /path/to/cavsandbox/examples/quickstart.xlsx
```

#### 17.4 Live vs. Headless Mode

Whether the simulation opens a Pygame window is controlled by `simulation_speed` in the simulation sheet, not by a command-line flag:

-   `simulation_speed = 0` — headless batch mode. No window opens. The simulation runs as fast as the CPU allows and exits when complete. Use this for parameter studies and automated runs.
-   `simulation_speed = 1.0` — live mode at real time. The simulation advances one simulation second per wall-clock second.
-   `simulation_speed = 2.0` — live mode at 2× real time.
-   Values between 0 and 1 slow the simulation below real time — useful for close inspection of fast events.

Note: simulation_speed controls the speed of the live renderer during a simulation run only. It has no effect when replaying a saved CSV. Playback speed in that mode is controlled interactively with the + and - keys.

#### 17.5 Seed Override Example

Running the same scenario five times with different seeds for an ensemble study:

```bash
python -m cacc_sim.main examples/quickstart.xlsx --seed 1
python -m cacc_sim.main examples/quickstart.xlsx --seed 2
python -m cacc_sim.main examples/quickstart.xlsx --seed 3
python -m cacc_sim.main examples/quickstart.xlsx --seed 4
python -m cacc_sim.main examples/quickstart.xlsx --seed 5
```

Each run produces a separate time-stamped results folder. The seed used is recorded in `metadata.yaml` so every run is fully reproducible.

***

### 18. The Live Renderer

When `simulation_speed` is non-zero, a Pygame window opens showing the simulation in real time. The window has three visual areas.

#### 18.1 The Road Strip

The road strip occupies the upper portion of the window. Vehicles move from left to right. The lead vehicle is anchored near the right edge of the strip; followers appear to its left at their current gap. This camera convention keeps the entire platoon visible at all times regardless of how far the vehicles have traveled.

Vehicle sprites are color-coded by model type:

| **Model**          | **Color** |
|--------------------|-----------|
| `LeadVehicleModel` | Grey      |
| `CACCModel`        | Cyan      |
| `IDMModel`         | Green     |
| `IDMHumanModel`    | Amber     |

Plugin models render in grey, the same color as the lead vehicle. If you are running a mixed scenario with both a lead vehicle and a plugin model such as `Wiedemann99Model`, the two will be visually indistinguishable in the renderer. Plugin authors who want a distinct color can add an entry to `palette.py`.

Two road visual elements convey vehicle speed:

-   **Scrolling center-line dashes**: White dashes on the road surface scroll leftward at the lead vehicle's speed. The faster the lead vehicle travels, the faster they scroll.
-   **Scrolling roadside posts**: Red and white vertical posts just outside both road edges scroll leftward at the lead vehicle's speed.

#### 18.2 The Speed Chart

The lower portion of the window shows a rolling 30-second speed history for all vehicles, updated each render tick. Each vehicle is plotted in its model color. The chart is useful for observing speed disturbances propagating through the platoon and checking whether followers are tracking the lead vehicle's speed changes.

#### 18.3 The HUD

A heads-up display in the top-left corner of the window shows:

-   Current simulation time (seconds)
-   Current playback speed multiplier
-   Lead vehicle speed (m/s)
-   Paused indicator when the simulation is paused

#### 18.4 Keyboard Controls

| **Key**         | **Action**                           |
|-----------------|--------------------------------------|
| `Space`         | Pause / resume                       |
| `Q` or `Escape` | Quit — results are saved before exit |

The simulation saves results automatically when it completes normally. If you quit early with `Q`, results up to that point are saved.

#### 18.5 Collision Behavior

If a gap between any two vehicles reaches zero, the simulation stops immediately, saves partial results, and displays a frozen collision overlay showing which vehicles were involved and at what time. The overlay remains visible until you press `Q` to exit.

***

### 19. CSV Playback

Any saved run can be replayed through the live renderer without re-running the simulation:

```bash
python -m cacc_sim.main results/quickstart_<timestamp>/data.csv
```

Playback mode reads the logged state from the CSV and begins the renderer at normal (1.0) speed. This is useful for reviewing a completed run, sharing results with colleagues who don't have the original Excel file, and stepping through events frame by frame.

#### 19.1 Playback Controls

Playback mode adds additional controls not available during live simulation:

| **Key**         | **Action**                           |
|-----------------|--------------------------------------|
| `Space`         | Pause / resume                       |
| `→`             | Step forward one frame while paused  |
| `←`             | Step backward one frame while paused |
| `+`             | Increase playback speed              |
| `-`             | Decrease playback speed              |
| `R`             | Rewind to start                      |
| `Q` or `Escape` | Quit                                 |

#### 19.2 Click-to-Seek

Left-clicking anywhere on the speed chart in playback mode seeks to that point in time and pauses. The vertical cursor snaps to the clicked position. This makes it easy to navigate directly to a braking event or gap closure without stepping through frame by frame.

#### 19.3 Full-Trace Speed Chart

The speed chart in playback mode shows the complete speed history for all vehicles — the full run, not just the rolling 30-second window used during live simulation. A vertical cursor line marks the current playback position and moves as the run progresses.

***

### 20. Headless Batch Mode

Setting `simulation_speed = 0` in the simulation sheet runs the simulation without opening a Pygame window. The simulation runs as fast as possible and exits when complete, writing results to the `results/` folder exactly as in live mode.

```bash
# Run headless — no window, maximum speed
python -m cacc_sim.main my_scenario.xlsx
# (with simulation_speed = 0 set in the simulation sheet)
```

#### 20.1 When to Use Headless Mode

Headless mode is the right choice whenever you don't need to observe the simulation in real time:

-   **Parameter studies** — running the same scenario with different gain values, headway settings, or sensor configurations
-   **Ensemble runs** — multiple seeds for the same scenario
-   **Automated pipelines** — running CAVSandbox from a script and processing results programmatically
-   **Long runs** — scenarios longer than a few minutes where watching in real time is not practical

#### 20.2 Running a Parameter Study

A simple parameter study varying `cacc_k_ff` across five values can be run from a Python script that modifies the Excel file programmatically. The following example illustrates the pattern:

```python
import subprocess
import openpyxl

k_ff_values = [0.80, 0.85, 0.90, 0.95, 1.00]

for k_ff in k_ff_values:
    # Load and modify the Excel file
    wb = openpyxl.load_workbook('examples/quickstart.xlsx')
    ws = wb['simulation']
    for row in ws.iter_rows():
        if row[0].value == 'cacc_k_ff':
            row[1].value = k_ff
    wb.save(f'temp_kff_{k_ff}.xlsx')

    # Run headless
    subprocess.run([
        'python', '-m', 'cacc_sim.main',
        f'temp_kff_{k_ff}.xlsx',
        '--seed', '42'
    ])
```

Each run creates a separate timestamped results folder. The `results/index.csv` file records one line per run, making it straightforward to find and compare results across the study. Clean up the temporary Excel files after the study completes.

#### 20.3 Regenerating Plots

Post-run plots can be regenerated from any saved CSV without re-running the simulation:

```bash
python -m cacc_sim.plot results/<scenario>_<timestamp>/data.csv
```

Add `--show` to display the plots interactively rather than just saving them to disk:

```bash
python -m cacc_sim.plot results/<scenario>_<timestamp>/data.csv --show
```

This is useful when you want to adjust plot appearance — for example to change axis ranges or add annotations — without having to repeat a full simulation run.


---

## Part 5 — Results and Output

### 21. Output Folder Structure

Every CAVSandbox run writes its results to a dedicated subfolder inside the `results/` directory at the project root. The subfolder is named after the scenario and the timestamp of the run:

```
results/
├── index.csv
├── quickstart_20260428_143022/
│   ├── data.csv
│   ├── metadata.yaml
│   ├── input.xlsx
│   ├── data.png
│   ├── data_speed.png
│   ├── data_gap.png
│   ├── data_accel.png
│   ├── data_lag.png
│   └── data_spacetime.png
└── quickstart_20260428_150011/
    └── ...
```

The scenario name comes from the Excel filename without the extension. The timestamp format is `YYYYMMDD_HHMMSS`. Two runs of the same scenario produce two separate subfolders — results are never overwritten.

Results are written at the end of a completed run and also when the user quits early with `Q` or when a collision stops the simulation — partial results are always saved rather than discarded.

#### 21.1 The Index File

`results/index.csv` is a single flat file that grows by one line after every run. It provides a quick overview of all runs without opening individual folders:

```
run_folder,scenario,timestamp,seed,duration_s,n_vehicles,cacc_k_ff
quickstart_20260428_143022,quickstart,2026-04-28 14:30:22,42,50,4,0.90
quickstart_20260428_150011,quickstart,2026-04-28 15:00:11,99,50,4,0.90
```

The index is useful for parameter studies where many runs accumulate quickly. A simple pandas one-liner loads the full study summary:

```python
import pandas as pd
index = pd.read_csv('results/index.csv')
```

***

### 22. The State Log (data.csv)

`data.csv` is the primary analysis file. It contains one row per vehicle per logged timestep. The simulation always runs at 100 Hz but only logs at `log_rate_hz` (default 10 Hz), so a 50-second run with four vehicles produces approximately 2,000 rows. Collision rows are always logged regardless of the log rate.

#### 22.1 Core State Columns

These columns are present in every run regardless of sensor or comms configuration:

| **Column**         | **Units** | **Description**                                                                 |
|--------------------|-----------|---------------------------------------------------------------------------------|
| `t`                | s         | Simulation time                                                                 |
| `id`               | —         | Vehicle ID matching the vehicles sheet                                          |
| `x`                | m         | Front bumper position from road start                                           |
| `v`                | m/s       | True plant speed                                                                |
| `a`                | m/s²      | True plant acceleration (actual, after actuator lag)                            |
| `a_cmd`            | m/s²      | Commanded acceleration from the driving model                                   |
| `gap`              | m         | True gap to the preceding vehicle (leader rear bumper to follower front bumper) |
| `leader_id`        | —         | Vehicle ID of the preceding vehicle; blank for the lead vehicle                 |
| `model`            | —         | Driving model class name                                                        |
| `vehicle_type`     | —         | Vehicle type string if set; blank for homogeneous fleets                        |
| `vehicle_length_m` | m         | Vehicle length                                                                  |

**The distinction between** `a` **and** `a_cmd` is important. `a_cmd` is what the driving model requested — the ideal acceleration to achieve the desired gap and speed. `a` is what the vehicle plant actually achieved after the response model applied actuator lag and jerk limits. The `data_lag.png` plot shows this difference for the first follower and is the primary diagnostic for understanding how actuator dynamics affect control performance.

#### 22.2 Sensor Pipeline Columns

These columns are populated when `sensor_model` is not `passthrough`. In passthrough mode they equal the true plant values.

| **Column**          | **Units** | **Description**                                       |
|---------------------|-----------|-------------------------------------------------------|
| `gap_meas`          | m         | Raw noisy radar gap measurement before filtering      |
| `gap_filtered`      | m         | Kalman or LPF filtered gap estimate                   |
| `gap_rate_meas`     | m/s       | Raw noisy radar gap-rate measurement before filtering |
| `gap_rate_filtered` | m/s       | Kalman or LPF filtered gap-rate estimate              |
| `lead_v_meas`       | m/s       | Measured speed of the preceding vehicle               |

Plotting `gap_meas` and `gap_filtered` together against the true `gap` is the primary diagnostic for Kalman filter performance — the filter should track the true gap without excessive lag while visibly smoothing the noisy raw measurement.

#### 22.3 V2V and Fusion Columns

These columns are populated when `comms_model` is not `passthrough`.

| **Column**     | **Units** | **Description**                                                                                                                                                                           |
|----------------|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `lead_a_v2v`   | m/s²      | Leader acceleration received via BSM — the ego-measured value including IMU noise, not the true plant acceleration. Zero when BSM is stale or comms are passthrough.                      |
| `lead_a_radar` | m/s²      | Fusion KF estimate of leader acceleration from the three-state filter. Available for research use; not currently used by the built-in CACC controller.                                    |
| `bsm_age_s`    | s         | Age of the most recently received BSM packet in seconds. Produces a sawtooth pattern — drops to near-zero when a packet arrives, climbs between packets, spikes when packets are dropped. |

#### 22.4 Log Rate vs. Simulation Rate

The simulation runs at 100 Hz (0.01 s timestep) but logs at `log_rate_hz` (default 10 Hz). This means each logged row represents one step out of every ten — intermediate states are not recorded. For most analysis purposes 10 Hz is sufficient. If you need finer time resolution — for example to study actuator transients or filter initialization behavior — increase `log_rate_hz` to 100 in the simulation sheet, accepting the larger file size.

***

### 23. The Plots

CAVSandbox generates six plot files automatically at the end of every run: one five-panel composite (`data.png`) and five individual panels saved separately. All plots use a shared color palette — vehicle colors match between the plots and the live renderer.

Plots can be regenerated from any saved CSV at any time:

```bash
python -m cacc_sim.plot results/<scenario>_<timestamp>/data.csv --show
```

#### 23.1 Speed vs. Time (`data_speed.png`)

Shows the speed of all vehicles over the full run duration. This is the first panel to examine after any run.

**What to look for:**

-   **String stability** — do follower speed oscillations grow or shrink from front to back? Growing amplitudes indicate string instability. In a stable platoon, V4's speed excursions should be smaller than V2's.
-   **Tracking quality** — do followers converge to the lead vehicle's speed after a disturbance, and how quickly?
-   **Startup transient** — the first few seconds often show an initial oscillation as the platoon settles from its initial conditions. This is expected and should decay within 5–10 seconds for a well-configured scenario.

#### 23.2 Gap vs. Time (`data_gap.png`)

Shows the gap to the preceding vehicle for each follower over the full run. With realistic sensors active, this panel also shows `gap_meas` (noisy measurement) and `gap_filtered` (KF or LPF estimate) for the first follower.

**What to look for:**

-   **Headway policy** — does the gap settle near the desired gap `s0 + T_h × v`? At 30 m/s with `T_h = 0.6` and `s0 = 2.0` the desired gap is 20 m.
-   **Filter performance** — the filtered estimate should track the true gap without significant lag. If it consistently leads or lags the true gap, the filter needs retuning.
-   **Collision margin** — does the gap stay well above zero during aggressive braking events?

#### 23.3 Acceleration vs. Time (`data_accel.png`)

Shows true plant acceleration for all vehicles over the full run.

**What to look for:**

-   **Comfort** — are accelerations smooth or do they contain high-frequency oscillations? The jerk limit `j_max` should prevent abrupt changes; if you see sharp spikes, check that actuator lag is active (`response_model = lag`).
-   **Amplitude growth** — as with speed, for a stable string, acceleration amplitudes should not grow from front to back.
-   **Actuator saturation** — acceleration clipped at `a_max` or `a_min` indicates the response model is hitting its limits.

#### 23.4 Actual vs. Commanded Acceleration (`data_lag.png`)

Shows the commanded acceleration (`a_cmd`, dashed) and true plant acceleration (`a`, solid) for the first follower only. This panel isolates the contribution of the vehicle response model.

**What to look for:**

-   **Lag magnitude** — the solid line should follow the dashed line with a delay of approximately `tau_throttle_s` or `tau_brake_s` depending on direction. At the defaults (0.5 s throttle, 0.3 s brake) the lag is visible but modest.
-   **Jerk limiting** — sharp commanded acceleration steps should appear as ramps in the actual acceleration, showing the jerk limiter at work.
-   **Asymmetry** — braking lag (`tau_brake_s = 0.3`) is shorter than throttle lag (`tau_throttle_s = 0.5`), which is physically realistic and should be visible in the plot.

#### 23.5 Space-Time Diagram (`data_spacetime.png`)

Shows position (y-axis) vs. time (x-axis) for all vehicles. This is a standard traffic engineering visualization — each vehicle traces a line whose slope equals its speed.

**Note on axis convention:** CAVSandbox uses time on the x-axis and position on the y-axis. Many traffic engineering texts use a transposed convention (position on x, time on y). The axis labels make clear which convention is in use.

**What to look for:**

-   **Parallel lines** — equal slopes mean all vehicles are traveling at the same speed. Parallel lines with consistent vertical spacing mean string-stable following at constant headway.
-   **Converging lines** — followers closing the gap to the vehicle ahead.
-   **Diverging lines** — gap growing, potentially indicating string instability or a vehicle reaching its desired speed limit.
-   **Collision** — two lines crossing indicates a gap of zero. If collision detection fired, the run will have ended at that point.

***

### 24. metadata.yaml

Every run produces a `metadata.yaml` file recording the complete parameter state at the time of the run. It is the authoritative record of what was simulated.

#### 24.1 Fields

| **Field**          | **Notes**                                                                                                                                                            |
|--------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `run_name`         | Folder name — `<scenario>_<timestamp>`                                                                                                                               |
| `timestamp`        | ISO format timestamp of the run                                                                                                                                      |
| `version`          | CAVSandbox package version from `cacc_sim.__version__`                                                                                                               |
| `excel_input`      | Original Excel filename                                                                                                                                              |
| `duration_s`       | Configured run duration                                                                                                                                              |
| `n_vehicles`       | Number of vehicles in the platoon                                                                                                                                    |
| `n_steps`          | Number of logged rows per vehicle in `data.csv`                                                                                                                      |
| `response_model`   | `kinematic` or `lag`                                                                                                                                                 |
| `string_stability` | Dict of `{vehicle_id: true/false}` for CACC vehicles — computed from the configured gains and headway at run time                                                    |
| `response_params`  | Dict of `{vehicle_id: {mode, tau_throttle_s, tau_brake_s, a_max_mps2, a_min_mps2, j_max_mps3}}` — the fully resolved parameter values after the four-level hierarchy |

#### 24.2 Why response_params Is Valuable

`response_params` records the resolved values after the four-level hierarchy has been applied — not just what was in the simulation sheet, but what each vehicle actually used. In a mixed fleet where some vehicles have per-vehicle overrides, a type definition, and simulation sheet globals all in play, the Excel file alone does not tell you what any specific vehicle used. `response_params` closes that gap.

#### 24.3 Using metadata.yaml for Reproducibility

The combination of `metadata.yaml` and `input.xlsx` in the same results folder provides complete reproducibility. To exactly reproduce a run:

```bash
python -m cacc_sim.main results/<scenario>_<timestamp>/input.xlsx --seed <seed from metadata.yaml>
```

The seed override is only needed if you want to reproduce stochastic behavior exactly. For passthrough sensor runs the seed has no effect and can be omitted.

#### 24.4 Reading metadata.yaml Programmatically

```python
import yaml

with open('results/quickstart_20260428_143022/metadata.yaml') as f:
    meta = yaml.safe_load(f)

print(meta['string_stability'])   # {2: True, 3: True, 4: True}
print(meta['version'])             # '0.7.1'
```


---

## Part 6 — Advanced Topics

### 25. String Stability

String stability is the property that a speed disturbance at the lead vehicle does not amplify as it propagates rearward through the platoon. A string-stable platoon attenuates disturbances — V4's speed excursion is smaller than V3's, which is smaller than V2's. A string-unstable platoon amplifies them — disturbances grow as they travel back, eventually producing dangerous gap closures or collisions even from small initial perturbations.

String stability is the central design constraint for CACC and the primary reason CACC requires V2V feedforward rather than pure radar-based feedback.

#### 25.1 The Theoretical Condition

For the CACC controller implemented in CAVSandbox, the simplified string stability condition is:

```
k_ff + k2 × T_h ≥ 1
```

With the default gains:

```
0.90 + 0.25 × 0.6 = 1.05  ✓  string-stable, margin = 0.05
```

CAVSandbox evaluates this condition at startup and records the result per vehicle in `metadata.yaml` under `string_stability`. A warning is issued if the condition is not satisfied — the simulation continues, since running with string-unstable gains is a legitimate experiment.

The condition has a clear physical interpretation: `k_ff × a_lead` is the feedforward anticipation term, and `k2 × T_h` is the velocity-feedback contribution at the operating headway. Their sum must exceed 1.0 for the closed-loop gain at the disturbance frequency to be less than unity — the formal requirement for attenuation rather than amplification.

**Important caveats.** The condition above is a simplified result derived assuming:

-   Perfect V2V communication (no packet drop, no noise)
-   Identical gains and headway for all vehicles
-   Linear analysis around an equilibrium operating point

In practice with realistic comms (`comms_model='v2v'`), packet drops reduce the effective feedforward contribution below `k_ff`, requiring a larger theoretical margin. IMU noise in the BSM signal adds a persistent feedforward error. Both effects mean real-world CACC requires a more conservative gain choice than the theoretical boundary suggests.

#### 25.2 Empirical String Stability Testing

The theoretical condition is a necessary but not always sufficient indicator of practical string stability. Empirical testing with a sinusoidal lead vehicle profile is, along with testing with sudden, hard stops, are the recommended approaches for validating behavior under realistic conditions.

**The sinusoidal test.** A sinusoidal speed perturbation at the lead vehicle at a fixed frequency produces a steady oscillation throughout the platoon. String stability is confirmed if acceleration amplitudes decrease monotonically from V1 through V4. String instability is confirmed if any follower's amplitude exceeds the lead vehicle's amplitude.

**Profile configuration.** The profile sheet does not currently support a native sinusoidal command. Use the piecewise-linear approximation described in Section 4.3 with the following recommended parameters:

| **Parameter**         | **Recommended value** | **Notes**                                                                     |
|-----------------------|-----------------------|-------------------------------------------------------------------------------|
| Amplitude             | 2.0 m/s               | Large enough to be clearly visible, small enough to stay in the linear regime |
| Frequency             | 0.1 Hz                | Period of 10 s; 5 cycles = 50 s measurement window                            |
| Offset                | 30.0 m/s              | Highway cruise speed                                                          |
| Warmup                | 60 s                  | Allows all transients to settle before oscillation begins                     |
| Cycles                | 5                     | Minimum for reliable amplitude measurement                                    |
| N waypoints per cycle | 8                     | Maximum speed approximation error ≈ 0.15 m/s                                  |

Total run duration: 60 s warmup + 50 s oscillation = 110 s. Total profile rows: 42.

**Amplitude measurement.** Compute acceleration amplitude as `(max(a) − min(a)) / 2` over the last three complete cycles of the measurement window. Using the last three cycles rather than all five reduces sensitivity to any remaining startup transient. A platoon is empirically string-stable if all follower amplitudes are below the lead vehicle's amplitude.

**Frequency dependence.** String stability is frequency-dependent — a platoon may be stable at 0.1 Hz but marginally unstable at 0.3 Hz, or vice versa. The 0.1 Hz test is the standard operating point for CACC validation because it falls within the bandwidth of typical speed disturbances on highways. For a more complete characterization, run the sinusoidal test at multiple frequencies (0.05, 0.1, 0.2, 0.3 Hz) and plot amplitude ratio versus frequency.

#### 25.3 Effect of Gains and Headway

The three CACC gains and the target headway interact to determine both the string stability margin and the controller's transient response. Understanding the tradeoffs guides gain selection.

**Increasing** `k_ff` moves the system further above the stability boundary. It is the most direct lever for improving string stability. The practical upper limit is approximately 0.95–1.0 — values above 1.0 can cause overshoot where the follower anticipates too aggressively and briefly closes past the desired gap.

**Increasing** `k2` also improves the stability margin (since the condition is `k_ff + k2 × T_h ≥ 1`) but at the cost of making the controller more sensitive to gap-rate noise. With realistic sensors, a high `k2` amplifies the noisy KF gap-rate estimate into the commanded acceleration. The default `k2 = 0.25` reflects this tradeoff.

**Increasing** `T_h` improves the stability margin for a given gain set but reduces traffic efficiency — longer headways mean lower road capacity. The 0.6 s default is at the aggressive end of what published CACC field tests have demonstrated safely.

**Increasing** `k1` does not appear in the string stability condition and has no direct effect on the margin. It affects how quickly the controller corrects gap errors — too low and the platoon is sluggish, too high and it oscillates at the scale of individual control steps.

#### 25.4 Sensitivity to Sensor Configuration

Running paired scenarios, one with `sensor_model='passthrough'` and one with `sensor_model='kalman'`, both with `comms_model='v2v'` — directly quantifies how sensor noise affects the practical string stability margin. This comparison is the primary recommended use of the sensor configuration options for research purposes.

***

### 26. Mixed Fleets

A mixed fleet scenario includes vehicles of more than one type — for example, passenger cars with short actuator time constants mixed with heavy trucks with slower response. Mixed fleets reveal how heterogeneity in vehicle dynamics affects platoon behavior and string stability.

#### 26.1 Setting Up a Mixed Fleet

Mixed fleets use the `vehicle_types` sheet, described in full in Section 5. The key design decisions are:

**Which parameters differ meaningfully between types.** For a car-truck mix the most physically significant differences are `tau_throttle_s` (trucks are slower to accelerate), `tau_brake_s` (trucks have longer braking distances), and `a_max_mps2` and `a_min_mps2` (trucks have lower acceleration and deceleration limits). The jerk limit `j_max_mps3` also differs but has less effect on string stability than the time constants.

**Where trucks are placed in the platoon.** A truck immediately behind the lead vehicle experiences the same disturbance as a car would but responds more slowly. The gap error grows larger before the response arrives. Placing trucks at the rear of the platoon is generally safer for string stability since their slower response does not propagate forward to cars that could react more aggressively.

#### 26.2 CACC Gains for Mixed Fleets

The string stability condition `k_ff + k2 × T_h ≥ 1` assumes all vehicles respond identically. In a mixed fleet the slower actuator response of trucks effectively reduces their closed-loop bandwidth, that is, the same commanded acceleration takes longer to materialize. This means the gain selection needs to be more conservative to maintain string stability across all vehicle types, not just the fastest-responding ones.. This means the stability margin is more conservative for a truck than for a car at the same gain settings.

A safe approach is to derive gains that are string-stable for the worst-case vehicle type (the slowest-responding truck) and apply those gains uniformly. More sophisticated approaches use vehicle-class-specific gains, but CAVSandbox currently supports only system-level gains. Per-vehicle gain variation would require a custom plugin.

#### 26.3 Interpreting Mixed Fleet Results

In mixed fleet runs, the speed and acceleration plots will show clearly different response characteristics per vehicle. A useful analysis is to plot `a` vs. `a_cmd` for a truck and a car side by side — the lag panel (`data_lag.png`) shows this for vehicle 2 only, so a parameter study comparing a scenario where vehicle 2 is a car versus a truck directly illustrates the actuator response difference.

***

### 27. Reproducibility and Seeds

CAVSandbox is designed for fully reproducible stochastic runs. Every source of randomness in the simulation is derived from a single `master_seed` integer through a deterministic derivation that is independent per vehicle and per process.

#### 27.1 How Seeds Work

The master seed is set in the simulation sheet or overridden with `--seed N` on the command line. From it, CAVSandbox derives independent `random.Random` instances for each combination of vehicle and stochastic process:

```python
vehicle_rng(master_seed, vehicle_id, process_name)
```

The process names currently in use are `'radar_noise'`, `'ego_noise'`, and `'bsm_comms'`. Each combination produces a completely independent random stream — vehicle 2's radar noise is independent of vehicle 3's radar noise, and both are independent of the BSM packet drop decisions. This means adding a vehicle to a platoon does not change the noise sequence of existing vehicles.

#### 27.2 What the Seed Controls

| **Process**                           | **Controlled by seed**        |
|---------------------------------------|-------------------------------|
| Radar AR(1) noise on gap and gap-rate | Yes                           |
| Ego sensor speed noise                | Yes                           |
| IMU white noise and bias drift        | Yes                           |
| BSM packet drop decisions             | Yes                           |
| BSM phase offset at initialization    | Yes                           |
| Lead vehicle profile timing           | No — profile is deterministic |
| Initial vehicle positions and speeds  | No — set explicitly in Excel  |

#### 27.3 Reproducing a Run

Every run records its seed in `metadata.yaml`. To reproduce a run exactly:

```bash
python -m cacc_sim.main results/<scenario>_<timestamp>/input.xlsx \
    --seed <seed from metadata.yaml>
```

The `input.xlsx` in the results folder is a verbatim copy of the original — it includes all parameter values as they were when the run was executed. Combined with the seed, this fully specifies the run.

#### 27.4 Running Ensembles

For statistical analysis, run the same scenario multiple times with different seeds and aggregate the results across runs. The `results/index.csv` file makes it straightforward to collect all runs of a given scenario:

```python
import pandas as pd

index = pd.read_csv('results/index.csv')
scenario_runs = index[index['scenario'] == 'quickstart']

results = []
for _, row in scenario_runs.iterrows():
    df = pd.read_csv(f"results/{row['run_folder']}/data.csv")
    df['seed'] = row['seed']
    results.append(df)

all_runs = pd.concat(results, ignore_index=True)
```

For passthrough sensor runs the seed has no effect — all stochastic processes are bypassed — and ensemble analysis is not meaningful. Ensembles are only useful when `sensor_model='kalman'` or `comms_model='v2v'` is active.

#### 27.5 Seed 0 as the Default

The default `master_seed = 0` in the simulation sheet is intentional. Zero is a deterministic, reproducible baseline that all users share — running `examples/quickstart.xlsx` without changing the seed always produces the same result on any machine. This makes the quickstart scenario fully reproducible across different users and platforms.

***

### 28. Performance

CAVSandbox is designed for research and teaching scenarios rather than high-throughput production simulation. Understanding its performance characteristics helps set appropriate expectations and guides decisions about when to use headless mode.

#### 28.1 Expected Simulation Speed

Performance depends primarily on fleet size and whether the live renderer is active. Here are some benchmarks measured on a modes PC: Intel Core i7-12700 (12th Gen), Python 3.11.14, Windows 11 Pro. The headless runs used with a 50 s, 4- or 10-vehicle CACC scenario with simulation_speed = 0.

| **Configuration**                          | **Approximate speed**           |
|--------------------------------------------|---------------------------------|
| 4 vehicles, headless, passthrough sensors  | 18× real time                   |
| 4 vehicles, headless, kalman sensors       | 15× real time                   |
| 4 vehicles, live renderer at 1.0×          | 1× real time (renderer-limited) |
| 10 vehicles, headless, passthrough sensors | 15× real time                   |
| 10 vehicles, headless, kalman sensors      | 12× real time                   |

#### 28.2 Reducing Simulation Time

For parameter studies where many runs are needed:

-   Set `simulation_speed = 0` for headless mode — the largest single speedup
-   Keep `log_rate_hz` at 10 (the default) — logging at 100 Hz is 10× slower with no analysis benefit for most purposes
-   Use `sensor_model='passthrough'` for gain sensitivity studies where sensor effects are not the variable of interest — eliminates KF computation entirely
-   Run on a machine with a fast single-core CPU — the simulation is single-threaded and does not benefit from multiple cores within a single run

#### 28.4 Parallelizing Parameter Studies

Each CAVSandbox run is an independent process. A parameter study with N scenarios can be parallelized across CPU cores using Python's `concurrent.futures`:

```python
from concurrent.futures import ProcessPoolExecutor
import subprocess

scenarios = ['temp_kff_0.80.xlsx', 'temp_kff_0.85.xlsx',
             'temp_kff_0.90.xlsx', 'temp_kff_0.95.xlsx']

def run_scenario(path):
    subprocess.run(['python', '-m', 'cacc_sim.main', path, '--seed', '42'])

with ProcessPoolExecutor(max_workers=4) as executor:
    executor.map(run_scenario, scenarios)
```

Each process writes to its own timestamped results folder so there is no file contention. This approach scales linearly with the number of cores available.


---

# Appendix A — Excel Input Parameter Reference

This appendix lists every parameter that CAVSandbox reads from each sheet of the Excel workbook.

***

## Table A1 — Vehicles Sheet Columns

The **vehicles** sheet must have one row per simulated vehicle. Columns are read as a DataFrame; column order does not matter.

| **Column**             | **Type**     | **Status**  | **Default**    | **Description**                                                                                                                                                                                                                                                                                                                                |
|------------------------|--------------|-------------|----------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `vehicle_id`           | int          | Required    | —              | Unique integer identifier for this vehicle. Must not be duplicated.                                                                                                                                                                                                                                                                            |
| `model`                | str          | Required    | —              | Driving model name. Must match a registered model: `IDMModel`, `IDMHumanModel`, `CACCModel`, `LEAD_PROFILE`, or a loaded plugin class name.                                                                                                                                                                                                    |
| `initial_position_m`   | float        | Required    | —              | Starting longitudinal position (m). Must be ≥ 0. Convention: front-bumper position.                                                                                                                                                                                                                                                            |
| `initial_speed_mps`    | float        | Required    | —              | Starting speed (m/s). Must be ≥ 0.                                                                                                                                                                                                                                                                                                             |
| `vehicle_length_m`     | float        | Required    | —              | Bumper-to-bumper vehicle length (m). Must be \> 0.                                                                                                                                                                                                                                                                                             |
| `leader_id`            | int or blank | Required    | —              | `vehicle_id` of the immediately preceding vehicle. Leave blank for the lead vehicle. Exactly one row must be blank.                                                                                                                                                                                                                            |
| `filter`               | str          | Required    | —              | This is the driving model input filter applied to sensor outputs immediately before compute() is called. This is a plugin extension point, not the radar sensor filter. For all built-in models and standard scenarios use PassthroughFilter. The radar pipeline filter (Kalman or LPF) is controlled by sensor_model in the simulation sheet. |
| `desired_speed_mps`    | float        | Conditional | —              | Free-flow target speed v₀ (m/s). Required for: `IDMModel`, `IDMHumanModel`, `CACCModel`, `Wiedemann99Model`.                                                                                                                                                                                                                                   |
| `time_headway_s`       | float        | Conditional | —              | Desired time headway T (s). Required for: `IDMModel`, `IDMHumanModel`.                                                                                                                                                                                                                                                                         |
| `reaction_time_s`      | float        | Conditional | —              | Perception-reaction delay (s). Required for: `IDMHumanModel`.                                                                                                                                                                                                                                                                                  |
| `vehicle_type`         | str          | Optional    | blank          | Type identifier referencing a row in the `vehicle_types` sheet. Used for level-2 response parameter lookup. Omit for homogeneous fleets.                                                                                                                                                                                                       |
| `tau_throttle_s`       | float        | Optional    | see §A1.1      | Per-vehicle throttle actuator time constant (s). Must be \> 0 if provided. Level-1 override in the four-level resolution hierarchy.                                                                                                                                                                                                            |
| `tau_brake_s`          | float        | Optional    | see §A1.1      | Per-vehicle brake actuator time constant (s). Must be \> 0 if provided. Level-1 override.                                                                                                                                                                                                                                                      |
| `a_max_mps2`           | float        | Optional    | see §A1.1      | Per-vehicle maximum acceleration (m/s²). Must be \> 0 if provided. Level-1 override.                                                                                                                                                                                                                                                           |
| `a_min_mps2`           | float        | Optional    | see §A1.1      | Per-vehicle minimum acceleration (m/s²). Must be \< 0 if provided. Level-1 override.                                                                                                                                                                                                                                                           |
| `j_max_mps3`           | float        | Optional    | see §A1.1      | Per-vehicle maximum jerk (m/s³). Must be \> 0 if provided. Level-1 override.                                                                                                                                                                                                                                                                   |
| `ego_speed_sigma`      | float        | Optional    | module default | Standard deviation of ego speed sensor noise (m/s). Active only when `sensor_model ≠ passthrough`. Blank or ≤ 0 uses the module-level default.                                                                                                                                                                                                 |
| `ego_accel_bias_drift` | float        | Optional    | module default | Acceleration bias drift rate for the ego sensor. Active only when `sensor_model ≠ passthrough`. Blank or ≤ 0 uses the module-level default.                                                                                                                                                                                                    |

### §A1.1 Response Parameter Resolution

The five response parameters (`tau_throttle_s`, `tau_brake_s`, `a_max_mps2`, `a_min_mps2`, `j_max_mps3`) are resolved through a four-level hierarchy. The first non-blank value wins:

| **Level** | **Source**                                                  |
|-----------|-------------------------------------------------------------|
| 1         | Per-vehicle column in the vehicles sheet                    |
| 2         | `vehicle_types` sheet row for this vehicle's `vehicle_type` |
| 3         | Simulation sheet global key of the same name                |
| 4         | Hardcoded default                                           |

***

The hardcoded defaults are:

***

-   `tau_throttle_s=0.5`,

***

-   `tau_brake_s=0.3`,

***

-   `a_max_mps2=2.5`,

***

-   `a_min_mps2=−8.0`,

***

-   `j_max_mps3=5.0`

***

***

## Table A2 — Simulation Sheet Keys

The **simulation** sheet is a two-column key–value list (no header row). Keys are read by name; unrecognised keys are silently ignored. Missing keys fall back to the defaults shown. The simulation timestep is always **0.01 s** (100 Hz) and cannot be set via the Excel file.

### Timing

| **Key**         | **Type** | **Default** | **Description**                                  |
|-----------------|----------|-------------|--------------------------------------------------|
| `duration_s`    | float    | `100.0`     | Total simulation run duration (s).               |
| `road_length_m` | float    | `1000.0`    | Road length for the single-lane road object (m). |

### Rendering

| Key                 | Type  | Default | Description                                                                                            |
|---------------------|-------|---------|--------------------------------------------------------------------------------------------------------|
| `simulation_speed`  | float | `1.0`   | Real-time multiplier for the live renderer. `0` runs headless (no window). `2.0` runs at 2× real time. |
| `render_interval_s` | float | `0.1`   | Seconds between renderer frames (default 10 Hz render). Has no effect in headless mode.                |

### Sensor / Comms

| **Key**                | **Type** | **Default**     | **Description**                                                                                                                                  |
|------------------------|----------|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------|
| `sensor_model`         | str      | `'passthrough'` | Sensor pipeline mode. `'passthrough'` bypasses all sensing; `'kalman'` uses a gap Kalman filter; `'lpf'` uses a low-pass filter.                 |
| `comms_model`          | str      | `'passthrough'` | V2V communications mode. `'passthrough'` gives perfect leader acceleration; `'v2v'` simulates DSRC BSM at 10 Hz with packet drop.                |
| `bsm_rate_hz`          | float    | `10.0`          | BSM broadcast rate (Hz). Active only when `comms_model = 'v2v'`.                                                                                 |
| `bsm_packet_drop_rate` | float    | `0.02`          | Per-packet drop probability (0–1). Active only when `comms_model = 'v2v'`.                                                                       |
| `bsm_max_age_s`        | float    | `0.30`          | Maximum BSM age before the packet is treated as stale (s). Active only when `comms_model = 'v2v'`.                                               |
| `sigma_q_rate`         | float    | `0.3`           | Kalman filter process noise standard deviation on the gap-rate state (m/s²·√s). Active when `sensor_model = 'kalman'` and `comms_model = 'v2v'`. |

### CACC Gains

| **Key**                 | **Type** | **Default** | **Description**                                                                                                                  |
|-------------------------|----------|-------------|----------------------------------------------------------------------------------------------------------------------------------|
| `cacc_k1`               | float    | `0.45`      | Gap-error proportional gain (m/s² per m).                                                                                        |
| `cacc_k2`               | float    | `0.25`      | Speed-error proportional gain (m/s² per m/s).                                                                                    |
| `cacc_k_ff`             | float    | `0.90`      | Feedforward gain on lead vehicle acceleration. Values below `1 − k2·T_h` produce string-unstable platoons (a warning is issued). |
| `cacc_target_headway_s` | float    | `0.6`       | Desired time headway for CACC spacing policy (s).                                                                                |
| `cacc_s0_m`             | float    | `2.0`       | Standstill gap for CACC spacing policy (m).                                                                                      |

### Response Model

| **Key**          | **Type** | **Default** | **Description**                                                                                                                   |
|------------------|----------|-------------|-----------------------------------------------------------------------------------------------------------------------------------|
| `response_model` | str      | `'lag'`     | Vehicle actuator response mode. `'kinematic'` applies commanded acceleration instantly; `'lag'` applies first-order actuator lag. |
| `tau_throttle_s` | float    | `0.5`       | Level-3 global default for throttle actuator time constant (s). Overridden per vehicle or vehicle type.                           |
| `tau_brake_s`    | float    | `0.3`       | Level-3 global default for brake actuator time constant (s). Overridden per vehicle or vehicle type.                              |
| `a_max_mps2`     | float    | `2.5`       | Level-3 global default for maximum acceleration (m/s²).                                                                           |
| `a_min_mps2`     | float    | `-8.0`      | Level-3 global default for minimum acceleration (m/s²).                                                                           |
| `j_max_mps3`     | float    | `5.0`       | Level-3 global default for maximum jerk (m/s³).                                                                                   |

### Logging

| **Key**       | **Type** | **Default** | **Description**                                                                                                                                           |
|---------------|----------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
| `master_seed` | int      | `0`         | Master random seed for all stochastic components. `0` uses a fixed deterministic default. Override at the command line with `--seed`.                     |
| `log_rate_hz` | float    | `10.0`      | CSV output decimation rate (Hz). The simulation runs at 100 Hz; `10.0` logs every 10th step. Collision rows are always logged regardless of this setting. |

***

## Table A3 — Profile Sheet Columns

The **profile** sheet defines the lead vehicle's speed drive cycle. Rows are sorted by `time_s` at load time regardless of sheet order. The first event value is held before `time_s[0]`; the last event value is held after `time_s[-1]`.

| **Column**   | **Type** | **Status** | **Description**                                                                                                                                                         |
|--------------|----------|------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `time_s`     | float    | Required   | Simulation time at which this event takes effect (s).                                                                                                                   |
| `value`      | float    | Required   | Target speed at this event (m/s).                                                                                                                                       |
| `transition` | str      | Optional   | Interpolation mode to the *next* event: `'ramp'` (linear interpolation, default) or `'step'` (hold `value` until the next event time). Blank cells default to `'ramp'`. |
| `note`       | str      | Optional   | Human-readable label. Never read by simulation code.                                                                                                                    |

***

## Table A4 — Vehicle Types Sheet Columns

The **vehicle_types** sheet is optional. When present, it defines named vehicle archetypes for level-2 response parameter lookup. The sheet is indexed by `type_id`; every numeric column must be non-blank for every row.

| **Column**       | **Type** | **Status** | **Description**                                                                                                                   |
|------------------|----------|------------|-----------------------------------------------------------------------------------------------------------------------------------|
| `type_id`        | str      | Required   | Unique type identifier. Vehicles reference this via the `vehicle_type` column in the vehicles sheet. Used as the DataFrame index. |
| `tau_throttle_s` | float    | Required   | Throttle actuator time constant for this vehicle type (s). Must be \> 0.                                                          |
| `tau_brake_s`    | float    | Required   | Brake actuator time constant for this vehicle type (s). Must be \> 0.                                                             |
| `a_max_mps2`     | float    | Required   | Maximum acceleration for this vehicle type (m/s²). Must be \> 0.                                                                  |
| `a_min_mps2`     | float    | Required   | Minimum acceleration for this vehicle type (m/s²). Must be \< 0.                                                                  |
| `j_max_mps3`     | float    | Required   | Maximum jerk for this vehicle type (m/s³). Must be \> 0.                                                                          |


---

# Appendix B — Error Messages Reference

This appendix lists every `ValueError` and warning raised by `cacc_sim/loader.py` during workbook validation. Errors are fatal — the simulation will not start. Warnings are non-fatal; the simulation continues but the message should be investigated.

Errors are grouped by which sheet they relate to. Where the message is dynamically constructed, the template is shown with the variable parts in `{braces}`.

***

## Vehicles Sheet — Fatal Errors

### Missing required columns

| **Error message**                  | **Cause**                                                                            | **Fix**                                                                                                                                                 |
|------------------------------------|--------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| `Missing required columns: {cols}` | One or more of the seven required column headers are absent from the vehicles sheet. | Add the missing columns. Required headers: `vehicle_id`, `model`, `initial_position_m`, `initial_speed_mps`, `vehicle_length_m`, `leader_id`, `filter`. |

### Row data errors

| **Error message**                                                       | **Cause**                                                                                                                                                              | **Fix**                                                                                                                 |
|-------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| `Duplicate vehicle_id values: {ids}`                                    | Two or more rows share the same `vehicle_id`.                                                                                                                          | Assign a unique integer to every row.                                                                                   |
| `Unknown model name(s): {names}`                                        | A value in the `model` column does not match any registered model or plugin.                                                                                           | Use a valid name: `IDMModel`, `IDMHumanModel`, `CACCModel`, `LEAD_PROFILE`, or the exact class name of a loaded plugin. |
| `Unknown filter name(s): {names}`                                       | A value in the `filter` column does not match any registered filter or plugin.                                                                                         | Use `passthrough` or the exact class name of a loaded plugin filter.                                                    |
| `Vehicle {id}: model '{name}' requires column '{col}' to be non-blank.` | A model-specific required column is missing or blank for that vehicle.                                                                                                 | Provide a value for the named column. See Table A1 for which columns each model requires.                               |
| `Vehicle {id}: initial_position_m must be ≥ 0.`                         | `initial_position_m` is negative.                                                                                                                                      | Use a non-negative position.                                                                                            |
| `Vehicle {id}: initial_speed_mps must be ≥ 0.`                          | `initial_speed_mps` is negative.                                                                                                                                       | Use a non-negative speed.                                                                                               |
| `Vehicle {id}: vehicle_length_m must be > 0.`                           | `vehicle_length_m` is zero or negative.                                                                                                                                | Use a positive length.                                                                                                  |
| `Vehicle {id}: {param} must be {rule}, got {val}.`                      | A per-vehicle response override column has an out-of-range value. `a_max_mps2`, `j_max_mps3`, `tau_throttle_s`, `tau_brake_s` must be \> 0; `a_min_mps2` must be \< 0. | Correct the value or leave the cell blank to inherit from the vehicle type, simulation sheet, or hardcoded default.     |

### Leader topology errors

These are checked after the row-data errors above; they require clean data to run.

| **Error message**                                                                                          | **Cause**                                                                          | **Fix**                                                                                                        |
|------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| `No lead vehicle found: exactly one row must have a blank leader_id.`                                      | Every row has a `leader_id` value — no lead vehicle is defined.                    | Leave exactly one row's `leader_id` cell blank.                                                                |
| `{n} rows have blank leader_id — exactly one is required (vehicle_ids: {ids}).`                            | More than one row has a blank `leader_id`.                                         | Keep exactly one blank `leader_id`; fill in the others.                                                        |
| `Vehicle {id}: leader_id {lid} does not reference a valid vehicle_id.`                                     | A `leader_id` value points to a vehicle that does not exist in the sheet.          | Correct the `leader_id` to match an existing `vehicle_id`.                                                     |
| `Vehicle {id} has blank leader_id (lead vehicle) but model='{name}' — lead vehicle must use LEAD_PROFILE.` | The vehicle with no leader uses a following model instead of `LEAD_PROFILE`.       | Set the lead vehicle's `model` to `LEAD_PROFILE`.                                                              |
| `Circular leader_id chain detected involving vehicle(s): {ids}`                                            | The `leader_id` references form a cycle (e.g., vehicle 2 → vehicle 3 → vehicle 2). | Break the cycle. The leader chain must be a single linear sequence from the lead vehicle to the last follower. |

### Position overlap errors

| **Error message** | **Cause** | **Fix** |
|---|---|---|
| `[vehicles sheet] Vehicle {id} initial position overlaps with the vehicle ahead: vehicle {id} front bumper is at {f} m but vehicle {ahead_id} rear bumper is at {r} m. Increase initial_position_m for vehicle {ahead_id} or decrease it for vehicle {id} so that gap = {r} - {f} = {gap} m is positive.` | Two vehicles' initial positions place them physically on top of each other. | Adjust `initial_position_m` values so each vehicle's front bumper is behind the preceding vehicle's rear bumper. The message reports the exact positions and the required correction. |

***

## Vehicle Types Sheet — Fatal Errors

These errors are only raised when a `vehicle_types` sheet is present in the workbook.

| **Error message**                                                                       | **Cause**                                                                                        | **Fix**                                                                                                      |
|-----------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|
| `vehicle_types sheet missing column '{col}'.`                                           | A required numeric column is absent.                                                             | Add the column. Required columns: `tau_throttle_s`, `tau_brake_s`, `a_max_mps2`, `a_min_mps2`, `j_max_mps3`. |
| `vehicle_types: '{col}' is blank for type_id(s): {ids}.`                                | A required numeric column has blank cells for one or more types.                                 | Fill in values for all listed `type_id` rows.                                                                |
| `vehicle_types: a_max_mps2 must be > 0 for type_id(s): {ids}.`                          | `a_max_mps2` is zero or negative for one or more types.                                          | Provide a positive value.                                                                                    |
| `vehicle_types: a_min_mps2 must be < 0 for type_id(s): {ids}.`                          | `a_min_mps2` is zero or positive for one or more types.                                          | Provide a negative value.                                                                                    |
| `Vehicle {id}: vehicle_type '{vt}' not found in vehicle_types sheet.`                   | A vehicle's `vehicle_type` value does not match any `type_id` in the vehicle_types sheet.        | Add the type to the vehicle_types sheet, or correct the `vehicle_type` cell in the vehicles sheet.           |
| `vehicle_type column is non-blank for some vehicles but vehicle_types sheet is absent.` | The vehicles sheet contains `vehicle_type` values but the workbook has no `vehicle_types` sheet. | Add a `vehicle_types` sheet, or clear the `vehicle_type` column in the vehicles sheet.                       |

***

## Profile Sheet — Fatal Errors

| **Error message**                              | **Cause**                                                                  | **Fix**                                                                         |
|------------------------------------------------|----------------------------------------------------------------------------|---------------------------------------------------------------------------------|
| `LEAD_PROFILE model requires a profile sheet.` | The workbook contains a `LEAD_PROFILE` vehicle but has no `profile` sheet. | Add a `profile` sheet with at least one row. See Table A3 for required columns. |

***

## Non-Fatal Warnings

These do not stop the simulation but indicate likely input problems.

| **Warning**                                                                                                                              | **Cause**                                                                      | **What to do**                                                                                                      |
|------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| `Dropping {n} fully empty row(s) from vehicles sheet.`                                                                                   | The vehicles sheet contains one or more rows where every cell is blank.        | Remove the empty rows from the sheet.        |
| `Plugin class '{name}' in {file} collides with an existing registry entry. Existing entry kept; rename the plugin class to register it.` | A plugin driving model class has the same name as an already-registered model. | Rename the plugin class to a unique name.    |
| `Plugin filter '{name}' in {file} collides with an existing registry entry. Existing entry kept.`                                        | A plugin filter class has the same name as an already-registered filter.       | Rename the plugin filter class to a unique name.                                                                    |


---

# Appendix C — data.csv Column Reference

Every CAVSandbox run writes a `data.csv` file to its results folder. This appendix describes every column in that file.

**Row structure.** The file contains one row per vehicle per logged timestep. The simulation runs at 100 Hz (0.01 s timestep); rows are decimated to `log_rate_hz` (default 10 Hz) so that each logged step represents 0.1 s of simulated time. Collision rows are always included regardless of `log_rate_hz`.

**Passthrough columns.** Several columns carry sensor or comms pipeline data. When `sensor_model = 'passthrough'` or `comms_model = 'passthrough'`, those columns are still present but contain ground-truth plant values rather than realistic sensor readings. The table below marks each such column with:

-   **(S)** — distinct from ground truth only when `sensor_model ≠ 'passthrough'`
-   **(C)** — distinct from ground truth only when `comms_model = 'v2v'`
-   **(S+C)** — meaningful only when both `sensor_model ≠ 'passthrough'` and `comms_model = 'v2v'`

***

| **Column**          | **Type**    | **Units** | **Description**                                                                                                                                                                                                                |
|---------------------|-------------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `t`                 | float       | s         | Simulation time of this logged step.                                                                                                                                                                                           |
| `id`                | int         | —         | Vehicle identifier. Matches `vehicle_id` in the vehicles sheet.                                                                                                                                                                |
| `x`                 | float       | m         | Front-bumper longitudinal position. Initialised from `initial_position_m`; integrated forward each step.                                                                                                                       |
| `v`                 | float       | m/s       | Actual vehicle speed after the response model is applied.                                                                                                                                                                      |
| `a`                 | float       | m/s²      | Actual acceleration applied to the plant this step (post-response-model).                                                                                                                                                      |
| `a_cmd`             | float       | m/s²      | Commanded acceleration output from the driving model before the response model. Equals `a` when `response_model = 'kinematic'`.                                                                                                |
| `gap`               | float       | m         | True bumper-to-bumper gap to the immediately preceding vehicle (`= leader.x − self.x − leader.length`). `9999.0` for the lead vehicle. Negative when a collision has occurred; collision rows are always logged.               |
| `gap_meas`          | float       | m         | **(S)** Radar gap measurement before filtering. Equals `gap` in passthrough mode.                                                                                                                                              |
| `gap_filtered`      | float       | m         | **(S)** Filtered or fused gap estimate used by the driving model as `state.gap`. Equals `gap` in passthrough mode.                                                                                                             |
| `gap_rate_meas`     | float       | m/s       | **(S)** Radar gap-closing rate measurement before filtering (positive = gap growing). Equals the true rate in passthrough mode.                                                                                                |
| `gap_rate_filtered` | float       | m/s       | **(S)** Filtered or fused gap-rate estimate used by the driving model. Equals the true rate in passthrough mode.                                                                                                               |
| `lead_v_meas`       | float       | m/s       | **(S)** Estimated speed of the immediately preceding vehicle. True leader speed in passthrough mode; derived as `ego_speed + fused_gap_rate` otherwise.                                                                        |
| `lead_a_v2v`        | float       | m/s²      | **(C)** Lead acceleration feedforward used for CACC. True leader plant acceleration in passthrough mode; ego-measured leader acceleration delivered via BSM otherwise. `0.0` when the BSM packet is stale or has been dropped. |
| `lead_a_radar`      | float       | m/s²      | **(S+C)** Kalman filter estimate of lead acceleration from the radar–BSM fusion layer. Always `0.0` in passthrough sensor mode or passthrough comms mode.                                                                      |
| `bsm_age_s`         | float       | s         | **(C)** Time elapsed since the last BSM packet was received from the immediately preceding vehicle. Always `0.0` in passthrough comms mode.                                                                                    |
| `leader_id`         | int or None | —         | `vehicle_id` of the immediately preceding vehicle. `None` for the lead vehicle.                                                                                                                                                |
| `model`             | str         | —         | Python class name of the driving model (e.g., `'CACCModel'`, `'IDMModel'`, `'LeadVehicleModel'`).                                                                                                                              |
| `vehicle_type`      | str or None | —         | Vehicle type identifier from the vehicles sheet. `None` if the `vehicle_type` column was not set for this vehicle.                                                                                                             |
| `length`            | float       | m         | Bumper-to-bumper vehicle length. Constant for the lifetime of the run.                                                                                                                                                         |


---

## Further Reading

The following references provide theoretical foundations and empirical context for the models and methods implemented in CAVSandbox. Where papers are freely available online, direct links are provided.

---

### Foundational Car-Following Models

Treiber, M., Hennecke, A., & Helbing, D. (2000). Congested traffic states in empirical observations and microscopic simulations. *Physical Review E, 62*(2), 1805–1824. — The original IDM paper. Derives the model from first principles and validates it against empirical traffic data.
[https://arxiv.org/abs/cond-mat/0002177](https://arxiv.org/abs/cond-mat/0002177)

Treiber, M., & Kesting, A. (2013). *Traffic Flow Dynamics: Data, Models and Simulation*. Springer. — The most comprehensive single reference for car-following theory, covering IDM, reaction time extensions, calibration methodology, and string stability in depth. A companion website with interactive simulations is available at [http://www.traffic-simulation.de](http://www.traffic-simulation.de).
[https://link.springer.com/book/10.1007/978-3-642-32460-4](https://link.springer.com/book/10.1007/978-3-642-32460-4)

Wiedemann, R. (1974). *Simulation des Straßenverkehrsflusses*. Schriftenreihe des Instituts für Verkehrswesen, Universität Karlsruhe. — The original psychophysical car-following model underlying `Wiedemann99Model`. The original is a German-language technical report not freely available online. For the VISSIM parameterization of the model (CC0–CC9 parameters), see the PTV VISSIM User Manual at [https://www.ptvgroup.com/en/products/ptv-vissim/](https://www.ptvgroup.com/en/products/ptv-vissim/). An accessible English-language treatment is available in:

Fellendorf, M., & Vortisch, P. (2010). Microscopic traffic flow simulator VISSIM. In J. Barceló (Ed.), *Fundamental of Traffic Simulation* (pp. 63–93). Springer.
[https://doi.org/10.1007/978-1-4419-6142-6_2](https://doi.org/10.1007/978-1-4419-6142-6_2)

---

### CACC and V2V Communications

Milanés, V., & Shladover, S. E. (2014). Modeling cooperative and autonomous adaptive cruise control dynamic responses using experimental data. *Transportation Research Part C, 48*, 285–300. — The PATH field test results that inform the default CACC gains in CAVSandbox. Reports empirically calibrated values of k1, k2, and k_ff from instrumented vehicle experiments on California highways.
[https://doi.org/10.1016/j.trc.2014.09.001](https://doi.org/10.1016/j.trc.2014.09.001)

---

### String Stability

Swaroop, D., & Hedrick, J. K. (1996). String stability of interconnected systems. *IEEE Transactions on Automatic Control, 41*(3), 349–357. — The canonical theoretical treatment of string stability for vehicle platoons. Derives the frequency-domain conditions for disturbance attenuation in a vehicle string and establishes the framework used in CAVSandbox's stability check.
[https://doi.org/10.1109/9.486636](https://doi.org/10.1109/9.486636)
