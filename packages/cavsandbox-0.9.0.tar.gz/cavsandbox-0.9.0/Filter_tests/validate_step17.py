#!/usr/bin/env python3
"""
Step 17 end-to-end validation: sensor pipeline diagnostic plots.

Runs a 4-vehicle CACC scenario through all five drive profile stages
with sensor_model='kalman' and comms_model='v2v'.  Produces one
multi-panel diagnostic PNG per stage in Filter_tests/validation/.

Panel layout (all stages):
  1  Speed vs. time — all 4 vehicles
  2  True gap / radar raw / KF estimate — V2 (first follower)
  3  True gap rate / KF estimated gap rate — V2
  4  True leader accel / lead_a_radar / lead_a_v2v — V2
  5  BSM age timeline — V2, V3, V4

Additional panel for Stage 4 (sinusoidal):
  6  String stability amplitude (last 3 oscillation cycles)

Additional panel for Stage 5 (emergency braking):
  6  Gap vs. time — all followers, with minimum gap annotation

Usage (from project root):
    python Filter_tests/validate_step17.py
"""
from __future__ import annotations

import sys
from pathlib import Path

# Make cacc_sim and make_workbooks importable
_here = Path(__file__).resolve().parent
_root = _here.parent
for _p in [str(_root), str(_here)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from cacc_sim.loader import load_vehicles, SimConfig
from cacc_sim.simulation import SimulationLoop
from make_workbooks import (
    VALIDATION_DIR,
    STAGE_PARAMS,
    make_validation_workbook,
)

# Per-vehicle colors — distinct hues for each platoon position
_VC: dict[int, str] = {1: 'black', 2: '#008080', 3: '#4682B4', 4: '#8B4513'}
_FOLLOWER_IDS = (2, 3, 4)

# Sinusoidal stage parameters (must match stage4_profile() in make_workbooks.py)
_SINE_T_WARMUP = 60.0
_SINE_PERIOD   = 10.0
_SINE_N_CYCLES = 5
_SINE_AMPLITUDE_WINDOW_START = _SINE_T_WARMUP + (_SINE_N_CYCLES - 3) * _SINE_PERIOD


def _pivot(df: pd.DataFrame) -> dict[int, pd.DataFrame]:
    """Split combined DataFrame into per-vehicle DataFrames."""
    return {int(vid): df[df['id'] == vid].reset_index(drop=True)
            for vid in sorted(df['id'].unique())}


def _joined_v2(df: pd.DataFrame, vd: dict[int, pd.DataFrame]) -> pd.DataFrame:
    """
    Merge V2 columns with V1's true speed and acceleration for cross-vehicle
    comparisons.
    """
    v2_cols = ['t', 'v', 'gap', 'gap_meas', 'gap_filtered',
               'lead_v_meas', 'lead_a_v2v', 'lead_a_radar', 'bsm_age_s']
    v2 = vd[2][v2_cols].copy()
    v1 = vd[1][['t', 'v', 'a']].rename(columns={'v': 'v1', 'a': 'a1'})
    return v2.merge(v1, on='t')


# ---------------------------------------------------------------------------
# Extra panel: string stability amplitude (Stage 4)
# ---------------------------------------------------------------------------

def _plot_string_stability(ax: plt.Axes, vd: dict[int, pd.DataFrame]) -> None:
    """
    String stability amplitude panel.

    Measures peak acceleration amplitude over the last 3 complete oscillation
    cycles for each vehicle.  Amplitude = (max - min) / 2 of logged 'a'.
    """
    t0 = _SINE_AMPLITUDE_WINDOW_START
    t1 = _SINE_T_WARMUP + _SINE_N_CYCLES * _SINE_PERIOD

    amps: dict[int, float] = {}
    for vid, vdf in sorted(vd.items()):
        window = vdf[(vdf['t'] >= t0) & (vdf['t'] <= t1)]['a']
        if len(window) >= 2:
            amps[vid] = (float(window.max()) - float(window.min())) / 2.0
        else:
            amps[vid] = 0.0

    positions = sorted(amps.keys())
    amplitudes = [amps[p] for p in positions]

    ax.plot(positions, amplitudes, 'o-', color='#333333', lw=1.5, ms=8)
    for vid, amp in amps.items():
        ax.annotate(f'{amp:.3f}', (vid, amp),
                    textcoords='offset points', xytext=(6, 4), fontsize=8)

    lead_amp = amps.get(1, 0.0)
    if lead_amp > 0:
        ax.axhline(lead_amp, color='red', ls='--', lw=1.0,
                   label=f'Lead amplitude  ({lead_amp:.3f} m/s²)')

    ax.set_xticks(positions)
    ax.set_xticklabels([f'V{p}' for p in positions])
    ax.set_xlabel('Platoon position (1 = lead)')
    ax.set_ylabel('Accel amplitude (m/s²)')

    follower_amps = [amps[p] for p in positions if p > 1]
    if lead_amp > 0 and follower_amps:
        max_ratio = max(a / lead_amp for a in follower_amps)
        is_stable = max_ratio <= 1.01
        status = ('String stable (OK)'
                  if is_stable
                  else f'String unstable  (max ratio = {max_ratio:.2f}x)')
    else:
        status = '(insufficient data)'

    ax.set_title(f'String stability amplitude  —  {status}')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)


# ---------------------------------------------------------------------------
# Extra panel: gap vs. time for all followers (Stage 5)
# ---------------------------------------------------------------------------

def _plot_gap_timeline(ax: plt.Axes, vd: dict[int, pd.DataFrame]) -> None:
    """Gap vs. time for each follower, annotated with the minimum gap."""
    for vid in _FOLLOWER_IDS:
        if vid not in vd:
            continue
        vdf = vd[vid]
        ax.plot(vdf['t'], vdf['gap'], color=_VC[vid], lw=1.2, label=f'V{vid}')
        min_gap = float(vdf['gap'].min())
        t_min   = float(vdf.loc[vdf['gap'].idxmin(), 't'])
        ax.annotate(
            f'{min_gap:.1f} m',
            (t_min, min_gap),
            textcoords='offset points', xytext=(6, -12),
            fontsize=7, color=_VC[vid],
            arrowprops=dict(arrowstyle='->', color=_VC[vid], lw=0.8),
        )

    ax.axhline(0, color='red', ls='--', lw=0.8, label='Collision threshold')
    ax.set_ylabel('Gap (m)')
    ax.set_title('Gap vs. time — followers (emergency braking)')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)


# ---------------------------------------------------------------------------
# Main plot function
# ---------------------------------------------------------------------------

def plot_stage(
    df: pd.DataFrame,
    stage_name: str,
    stage_num: int,
    extra: str | None,
) -> None:
    """Generate and save the diagnostic figure for one stage."""
    n_panels = 5 + (1 if extra is not None else 0)
    fig, axes = plt.subplots(
        n_panels, 1,
        figsize=(11, 2.9 * n_panels),
        constrained_layout=True,
    )
    ax1, ax2, ax3, ax4, ax5 = axes[:5]
    ax_extra = axes[5] if n_panels == 6 else None

    fig.suptitle(f'Stage {stage_num}: {stage_name}', fontsize=13, fontweight='bold')

    vd = _pivot(df)
    jd = _joined_v2(df, vd)
    t  = jd['t'].to_numpy()

    # ── Panel 1: speed vs. time ───────────────────────────────────────────
    for vid in sorted(vd.keys()):
        vdf = vd[vid]
        ax1.plot(vdf['t'], vdf['v'], color=_VC.get(vid, 'grey'),
                 lw=1.2, label=f'V{vid}')
    ax1.set_ylabel('Speed (m/s)')
    ax1.set_title('Speed vs. time — all vehicles')
    ax1.legend(loc='upper right', fontsize=8)
    ax1.grid(True, alpha=0.3)

    # ── Panel 2: gap tracking ─────────────────────────────────────────────
    ax2.plot(t, jd['gap'],          color='black',   lw=1.2,       label='True gap')
    ax2.plot(t, jd['gap_meas'],     color='#999999', lw=0.8, ls=':', label='Radar raw')
    ax2.plot(t, jd['gap_filtered'], color=_VC[2],    lw=1.2, ls='--', label='KF estimate')
    ax2.set_ylabel('Gap (m)')
    ax2.set_title('Gap tracking — V2 (first follower)')
    ax2.legend(loc='upper right', fontsize=8)
    ax2.grid(True, alpha=0.3)

    # ── Panel 3: gap-rate tracking ────────────────────────────────────────
    # True gap rate = V1.v − V2.v
    # KF estimated gap rate ≈ lead_v_meas − V2.v  (= v_meas_ego + rate_fused − v_ego)
    true_rate = jd['v1'] - jd['v']
    kf_rate   = jd['lead_v_meas'] - jd['v']
    ax3.plot(t, true_rate, color='black', lw=1.2,       label='True gap rate')
    ax3.plot(t, kf_rate,   color=_VC[2],  lw=1.2, ls='--', label='KF estimate')
    ax3.set_ylabel('Gap rate (m/s)')
    ax3.set_title('Gap-rate tracking — V2')
    ax3.legend(loc='upper right', fontsize=8)
    ax3.grid(True, alpha=0.3)

    # ── Panel 4: leader acceleration ──────────────────────────────────────
    ax4.plot(t, jd['a1'],           color='black',   lw=1.2,       label='True (V1.a)')
    ax4.plot(t, jd['lead_a_radar'], color=_VC[2],    lw=1.2, ls='--', label='KF estimate')
    ax4.plot(t, jd['lead_a_v2v'],   color='#CC4400', lw=0.8, ls=':',  label='BSM (raw)')
    ax4.set_ylabel('Accel (m/s²)')
    ax4.set_title('Leader acceleration tracking — V2')
    ax4.legend(loc='upper right', fontsize=8)
    ax4.grid(True, alpha=0.3)

    # ── Panel 5: BSM age timeline ─────────────────────────────────────────
    for vid in _FOLLOWER_IDS:
        if vid in vd:
            vdf = vd[vid]
            ax5.plot(vdf['t'], vdf['bsm_age_s'],
                     color=_VC[vid], lw=0.9, alpha=0.85, label=f'V{vid}')
    bsm_max = SimConfig().bsm_max_age_s
    ax5.axhline(bsm_max, color='red', ls='--', lw=0.9,
                label=f'Stale threshold ({bsm_max:.2f} s)')
    ax5.set_ylim(0, bsm_max * 1.15)
    ax5.set_ylabel('BSM age (s)')
    ax5.set_title('BSM packet age — V2, V3, V4  (sawtooth = packets arriving)')
    ax5.legend(loc='upper right', fontsize=8)
    ax5.grid(True, alpha=0.3)

    # ── Extra panel ───────────────────────────────────────────────────────
    if extra == 'sinusoidal' and ax_extra is not None:
        _plot_string_stability(ax_extra, vd)
    elif extra == 'emergency' and ax_extra is not None:
        _plot_gap_timeline(ax_extra, vd)

    # Shared x-axis label only on the bottom panel
    for ax in axes[:-1]:
        ax.set_xlabel('')
    axes[-1].set_xlabel('Time (s)')

    out = VALIDATION_DIR / f'stage{stage_num}_diagnostic.png'
    fig.savefig(str(out), dpi=150)
    plt.close(fig)
    print(f'  -> {out.name}')


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    VALIDATION_DIR.mkdir(parents=True, exist_ok=True)

    for num, (name, profile_fn, extra) in enumerate(STAGE_PARAMS, start=1):
        profile_rows, duration_s = profile_fn()
        wb_path = VALIDATION_DIR / f'stage{num}.xlsx'

        print(f'Stage {num}: {name}  ({duration_s:.0f} s)')
        make_validation_workbook(profile_rows, wb_path, duration_s)
        vehicles, config = load_vehicles(str(wb_path))
        df = SimulationLoop(vehicles, config).run()

        if (df[df['id'] > 1]['gap'] < 0).any():
            print(f'  WARNING: collision detected — partial results only')

        plot_stage(df, name, num, extra)

    print(f'\nDone - all PNGs written to {VALIDATION_DIR}')


if __name__ == '__main__':
    main()
