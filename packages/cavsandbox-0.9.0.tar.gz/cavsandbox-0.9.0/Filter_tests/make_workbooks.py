#!/usr/bin/env python3
"""
Generate Excel input workbooks for Step 17 sensor validation.

Creates five workbooks in Filter_tests/validation/:
  stage1.xlsx — constant speed
  stage2.xlsx — step change
  stage3.xlsx — ramp
  stage4.xlsx — sinusoidal (N=8 piecewise-linear approximation)
  stage5.xlsx — emergency braking

Usage (from project root):
    python Filter_tests/make_workbooks.py

Or import and call make_validation_workbook() / generate_all() directly.
"""
from __future__ import annotations

import math
from pathlib import Path

import openpyxl

VALIDATION_DIR = Path(__file__).resolve().parent / 'validation'

# 4-vehicle CACC platoon: V1 = lead, V2-V4 = CACC followers
# Equilibrium gap at 30 m/s = cacc_s0_m + cacc_target_headway_s * v = 2 + 0.6*30 = 20 m
# Initial spacing = 20 m gap + 5 m vehicle length = 25 m centre-to-centre
_VEHICLE_ROWS = [
    #  vid  model           x0     v0    len  leader  desired_speed_mps
    (1, 'LEAD_PROFILE', 100.0, 30.0, 5.0, None, None),
    (2, 'CACCModel',     75.0, 30.0, 5.0,    1, 33.0),
    (3, 'CACCModel',     50.0, 30.0, 5.0,    2, 33.0),
    (4, 'CACCModel',     25.0, 30.0, 5.0,    3, 33.0),
]

_SIM_BASE = dict(
    response_model='lag',
    sensor_model='kalman',
    comms_model='v2v',
    cacc_target_headway_s=0.6,
    cacc_k1=0.45,
    cacc_k2=0.25,
    cacc_k_ff=0.90,
    cacc_s0_m=2.0,
    master_seed=42,
    log_rate_hz=10.0,
)


def make_validation_workbook(
    profile_rows: list,
    path: Path | str,
    duration_s: float,
    **sim_overrides,
) -> None:
    """
    Write a complete 4-vehicle CACC workbook with the given drive profile.

    Parameters
    ----------
    profile_rows : list of [time_s, value, transition]
        Rows for the profile sheet.
    path : Path
        Destination .xlsx path.
    duration_s : float
        Simulation duration (written to simulation sheet).
    **sim_overrides
        Any SimConfig key=value pairs to override the shared defaults.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    wb = openpyxl.Workbook()

    # vehicles sheet
    ws_v = wb.active
    ws_v.title = 'vehicles'
    ws_v.append([
        'vehicle_id', 'model', 'initial_position_m', 'initial_speed_mps',
        'vehicle_length_m', 'leader_id', 'filter', 'desired_speed_mps',
    ])
    for vid, model, x0, v0, length, leader_id, desired in _VEHICLE_ROWS:
        ws_v.append([vid, model, x0, v0, length, leader_id, 'passthrough', desired])

    # simulation sheet
    ws_s = wb.create_sheet('simulation')
    sim_params = {**_SIM_BASE, 'duration_s': duration_s}
    sim_params.update(sim_overrides)
    for key, val in sim_params.items():
        ws_s.append([key, val])

    # profile sheet
    ws_p = wb.create_sheet('profile')
    ws_p.append(['time_s', 'value', 'transition'])
    for row in profile_rows:
        ws_p.append(list(row))

    wb.save(str(path))


# ---------------------------------------------------------------------------
# Per-stage profile generators — each returns (profile_rows, duration_s)
# ---------------------------------------------------------------------------

def stage1_profile() -> tuple[list, float]:
    """Stage 1: constant speed 30 m/s for 30 s."""
    rows = [(0.0, 30.0, 'ramp'), (30.0, 30.0, 'ramp')]
    return rows, 30.0


def stage2_profile() -> tuple[list, float]:
    """Stage 2: step change from 30 → 25 m/s at t=10 s, then hold 40 s."""
    rows = [
        ( 0.0, 30.0, 'step'),   # hold at 30 until t=10
        (10.0, 25.0, 'ramp'),   # instantaneous drop to 25 at t=10
        (50.0, 25.0, 'ramp'),
    ]
    return rows, 50.0


def stage3_profile() -> tuple[list, float]:
    """Stage 3: ramp from 30 → 24 m/s over t=10–30 s, then hold."""
    rows = [
        ( 0.0, 30.0, 'step'),   # hold at 30 during warmup
        (10.0, 30.0, 'ramp'),   # ramp begins
        (30.0, 24.0, 'ramp'),   # ramp ends  (rate = −0.3 m/s²)
        (50.0, 24.0, 'ramp'),
    ]
    return rows, 50.0


def stage4_profile() -> tuple[list, float]:
    """Stage 4: sinusoidal perturbation — 60 s warmup then 5 cycles at 0.1 Hz, ±2 m/s.

    Uses N=8 equally-spaced waypoints per cycle as a piecewise-linear
    approximation of the sine wave.  Total duration = 110 s.
    """
    v0, A, f = 30.0, 2.0, 0.1
    T = 1.0 / f                      # 10 s period
    N = 8                             # waypoints per cycle
    t_step = T / N                    # 1.25 s per step
    n_cycles = 5
    t_warmup = 60.0
    duration = t_warmup + n_cycles * T   # 110 s

    rows: list = [
        (0.0,      v0, 'step'),    # hold at cruise speed during warmup
        (t_warmup, v0, 'ramp'),    # oscillation start point
    ]
    for i in range(1, n_cycles * N + 1):
        t_i = round(t_warmup + i * t_step, 6)
        v_i = round(v0 + A * math.sin(2.0 * math.pi * i / N), 8)
        rows.append((t_i, v_i, 'ramp'))

    return rows, duration


def stage5_profile() -> tuple[list, float]:
    """Stage 5: emergency braking — 10 s cruise then hard decel to 5 m/s."""
    rows = [
        ( 0.0, 30.0, 'step'),   # hold at 30 during warmup
        (10.0,  5.0, 'ramp'),   # target drops to 5 m/s  (proportional ctrl saturates at −4 m/s²)
        (30.0,  5.0, 'ramp'),
    ]
    return rows, 30.0


# ---------------------------------------------------------------------------
# Stage registry — used by validate_step17.py
# ---------------------------------------------------------------------------

STAGE_PARAMS: list[tuple[str, callable, str | None]] = [
    ('Constant Speed',    stage1_profile, None),
    ('Step Change',       stage2_profile, None),
    ('Ramp',              stage3_profile, None),
    ('Sinusoidal',        stage4_profile, 'sinusoidal'),
    ('Emergency Braking', stage5_profile, 'emergency'),
]


def generate_all(base_dir: Path | str | None = None) -> None:
    """Generate all 5 stage workbooks."""
    out_dir = Path(base_dir) if base_dir is not None else VALIDATION_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, (name, profile_fn, _) in enumerate(STAGE_PARAMS, start=1):
        rows, duration = profile_fn()
        out = out_dir / f'stage{i}.xlsx'
        make_validation_workbook(rows, out, duration)
        print(f'  stage{i}.xlsx  ({name}, {duration:.0f} s)  ->  {out}')


if __name__ == '__main__':
    print('Generating validation workbooks...')
    generate_all()
    print('Done.')
