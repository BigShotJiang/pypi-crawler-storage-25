# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["EmailValueParam"]


class EmailValueParam(TypedDict, total=False):
    """Email address value"""

    data: Required[str]
    """A valid email address."""

    type: Required[Literal["value/email"]]
