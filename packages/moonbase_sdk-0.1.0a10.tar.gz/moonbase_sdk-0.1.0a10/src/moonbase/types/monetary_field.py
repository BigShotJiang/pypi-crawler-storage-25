# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel
from .field_default_value import FieldDefaultValue

__all__ = ["MonetaryField"]


class MonetaryField(BaseModel):
    """A field that stores monetary amounts with currency information."""

    id: str
    """Unique identifier for the object."""

    cardinality: Literal["one", "many"]
    """
    Specifies whether the field can hold a single value (`one`) or multiple values
    (`many`).
    """

    created_at: datetime
    """Time at which the object was created, as an ISO 8601 timestamp in UTC."""

    default_unit: str
    """
    The default currency for the field, as a 3-letter ISO 4217 code (e.g., `USD`,
    `EUR`, `GBP`).
    """

    default_values: List[FieldDefaultValue]

    kind: Literal["system", "inverse", "custom"]
    """
    `system` fields are managed by Moonbase, `inverse` fields are the reverse side
    of a two-way relation, and `custom` fields are user-created.
    """

    name: str
    """The human-readable name of the field (e.g., "Deal Value")."""

    readonly: bool
    """
    If `true`, the value of this field is system-managed and cannot be updated via
    the API.
    """

    ref: str
    """
    A unique, stable, machine-readable identifier for the field within its
    collection (e.g., `deal_value`).
    """

    required: bool
    """If `true`, this field must have a value."""

    type: Literal["field/number/monetary"]
    """The data type of the field. Always `field/number/monetary` for this field."""

    unique: bool
    """
    If `true`, values for this field must be unique across all items in the
    collection.
    """

    updated_at: datetime
    """Time at which the object was last updated, as an ISO 8601 timestamp in UTC."""

    description: Optional[str] = None
    """An optional, longer-form description of the field's purpose."""
