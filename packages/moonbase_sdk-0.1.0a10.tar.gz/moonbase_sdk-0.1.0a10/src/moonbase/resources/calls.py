# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import call_list_params, call_create_params, call_upsert_params, call_retrieve_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursorPage, AsyncCursorPage
from ..types.call import Call
from .._base_client import AsyncPaginator, make_request_options
from ..types.shared_params.tag_pointer_param import TagPointerParam

__all__ = ["CallsResource", "AsyncCallsResource"]


class CallsResource(SyncAPIResource):
    """View activities and capture calls"""

    @cached_property
    def with_raw_response(self) -> CallsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/moonbaseai/moonbase-sdk-python#accessing-raw-response-data-eg-headers
        """
        return CallsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CallsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/moonbaseai/moonbase-sdk-python#with_streaming_response
        """
        return CallsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        direction: Literal["incoming", "outgoing"],
        participants: Iterable[call_create_params.Participant],
        provider: Literal["openphone", "user", "zoom_phone"],
        provider_id: str,
        provider_status: str,
        start_at: Union[str, datetime],
        answered_at: Union[str, datetime] | Omit = omit,
        end_at: Union[str, datetime] | Omit = omit,
        provider_metadata: Dict[str, object] | Omit = omit,
        recordings: Iterable[call_create_params.Recording] | Omit = omit,
        tags: Iterable[TagPointerParam] | Omit = omit,
        transcript: call_create_params.Transcript | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Call:
        """
        Logs a phone call.

        Args:
          direction: The direction of the call, either `incoming` or `outgoing`.

          participants: An array of participants involved in the call.

          provider: The name of the phone provider that handled the call (e.g., `openphone`).

          provider_id: The unique identifier for the call from the provider's system.

          provider_status: The status of the call.

          start_at: The time the call started, as an ISO 8601 timestamp in UTC.

          answered_at: The time the call was answered, as an ISO 8601 timestamp in UTC.

          end_at: The time the call ended, as an ISO 8601 timestamp in UTC.

          provider_metadata: A hash of additional metadata from the provider.

          recordings: Any recordings associated with the call.

          tags: Optional list of tag pointers to assign to the call.

          transcript: A transcript of the call.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/calls",
            body=maybe_transform(
                {
                    "direction": direction,
                    "participants": participants,
                    "provider": provider,
                    "provider_id": provider_id,
                    "provider_status": provider_status,
                    "start_at": start_at,
                    "answered_at": answered_at,
                    "end_at": end_at,
                    "provider_metadata": provider_metadata,
                    "recordings": recordings,
                    "tags": tags,
                    "transcript": transcript,
                },
                call_create_params.CallCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Call,
        )

    def retrieve(
        self,
        id: str,
        *,
        include: List[Literal["transcript", "note", "summary"]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Call:
        """
        Retrieves the details of an existing call.

        Args:
          include: Specifies which related objects to include in the response. Valid options are
              `transcript`, `note`, and `summary`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/calls/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"include": include}, call_retrieve_params.CallRetrieveParams),
            ),
            cast_to=Call,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPage[Call]:
        """
        Returns a list of calls.

        Args:
          after: When specified, returns results starting immediately after the item identified
              by this cursor. Use the cursor value from the previous response's metadata to
              fetch the next page of results.

          before: When specified, returns results starting immediately before the item identified
              by this cursor. Use the cursor value from the response's metadata to fetch the
              previous page of results.

          limit: Maximum number of items to return per page. Must be between 1 and 100. Defaults
              to 20 if not specified.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/calls",
            page=SyncCursorPage[Call],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "limit": limit,
                    },
                    call_list_params.CallListParams,
                ),
            ),
            model=Call,
        )

    def upsert(
        self,
        *,
        direction: Literal["incoming", "outgoing"],
        participants: Iterable[call_upsert_params.Participant],
        provider: Literal["openphone", "user", "zoom_phone"],
        provider_id: str,
        provider_status: str,
        start_at: Union[str, datetime],
        answered_at: Union[str, datetime] | Omit = omit,
        end_at: Union[str, datetime] | Omit = omit,
        provider_metadata: Dict[str, object] | Omit = omit,
        recordings: Iterable[call_upsert_params.Recording] | Omit = omit,
        tags: Iterable[TagPointerParam] | Omit = omit,
        transcript: call_upsert_params.Transcript | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Call:
        """
        Find and update an existing phone call, or create a new one.

        Args:
          direction: The direction of the call, either `incoming` or `outgoing`.

          participants: An array of participants involved in the call.

          provider: The name of the phone provider that handled the call (e.g., `openphone`).

          provider_id: The unique identifier for the call from the provider's system.

          provider_status: The status of the call.

          start_at: The time the call started, as an ISO 8601 timestamp in UTC.

          answered_at: The time the call was answered, as an ISO 8601 timestamp in UTC.

          end_at: The time the call ended, as an ISO 8601 timestamp in UTC.

          provider_metadata: A hash of additional metadata from the provider.

          recordings: Any recordings associated with the call.

          tags: Optional list of tag pointers to assign to the call. If omitted, existing tags
              are unchanged. Pass an empty array to clear tags.

          transcript: A transcript of the call.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/calls/upsert",
            body=maybe_transform(
                {
                    "direction": direction,
                    "participants": participants,
                    "provider": provider,
                    "provider_id": provider_id,
                    "provider_status": provider_status,
                    "start_at": start_at,
                    "answered_at": answered_at,
                    "end_at": end_at,
                    "provider_metadata": provider_metadata,
                    "recordings": recordings,
                    "tags": tags,
                    "transcript": transcript,
                },
                call_upsert_params.CallUpsertParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Call,
        )


class AsyncCallsResource(AsyncAPIResource):
    """View activities and capture calls"""

    @cached_property
    def with_raw_response(self) -> AsyncCallsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/moonbaseai/moonbase-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncCallsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCallsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/moonbaseai/moonbase-sdk-python#with_streaming_response
        """
        return AsyncCallsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        direction: Literal["incoming", "outgoing"],
        participants: Iterable[call_create_params.Participant],
        provider: Literal["openphone", "user", "zoom_phone"],
        provider_id: str,
        provider_status: str,
        start_at: Union[str, datetime],
        answered_at: Union[str, datetime] | Omit = omit,
        end_at: Union[str, datetime] | Omit = omit,
        provider_metadata: Dict[str, object] | Omit = omit,
        recordings: Iterable[call_create_params.Recording] | Omit = omit,
        tags: Iterable[TagPointerParam] | Omit = omit,
        transcript: call_create_params.Transcript | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Call:
        """
        Logs a phone call.

        Args:
          direction: The direction of the call, either `incoming` or `outgoing`.

          participants: An array of participants involved in the call.

          provider: The name of the phone provider that handled the call (e.g., `openphone`).

          provider_id: The unique identifier for the call from the provider's system.

          provider_status: The status of the call.

          start_at: The time the call started, as an ISO 8601 timestamp in UTC.

          answered_at: The time the call was answered, as an ISO 8601 timestamp in UTC.

          end_at: The time the call ended, as an ISO 8601 timestamp in UTC.

          provider_metadata: A hash of additional metadata from the provider.

          recordings: Any recordings associated with the call.

          tags: Optional list of tag pointers to assign to the call.

          transcript: A transcript of the call.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/calls",
            body=await async_maybe_transform(
                {
                    "direction": direction,
                    "participants": participants,
                    "provider": provider,
                    "provider_id": provider_id,
                    "provider_status": provider_status,
                    "start_at": start_at,
                    "answered_at": answered_at,
                    "end_at": end_at,
                    "provider_metadata": provider_metadata,
                    "recordings": recordings,
                    "tags": tags,
                    "transcript": transcript,
                },
                call_create_params.CallCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Call,
        )

    async def retrieve(
        self,
        id: str,
        *,
        include: List[Literal["transcript", "note", "summary"]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Call:
        """
        Retrieves the details of an existing call.

        Args:
          include: Specifies which related objects to include in the response. Valid options are
              `transcript`, `note`, and `summary`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/calls/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"include": include}, call_retrieve_params.CallRetrieveParams),
            ),
            cast_to=Call,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Call, AsyncCursorPage[Call]]:
        """
        Returns a list of calls.

        Args:
          after: When specified, returns results starting immediately after the item identified
              by this cursor. Use the cursor value from the previous response's metadata to
              fetch the next page of results.

          before: When specified, returns results starting immediately before the item identified
              by this cursor. Use the cursor value from the response's metadata to fetch the
              previous page of results.

          limit: Maximum number of items to return per page. Must be between 1 and 100. Defaults
              to 20 if not specified.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/calls",
            page=AsyncCursorPage[Call],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "limit": limit,
                    },
                    call_list_params.CallListParams,
                ),
            ),
            model=Call,
        )

    async def upsert(
        self,
        *,
        direction: Literal["incoming", "outgoing"],
        participants: Iterable[call_upsert_params.Participant],
        provider: Literal["openphone", "user", "zoom_phone"],
        provider_id: str,
        provider_status: str,
        start_at: Union[str, datetime],
        answered_at: Union[str, datetime] | Omit = omit,
        end_at: Union[str, datetime] | Omit = omit,
        provider_metadata: Dict[str, object] | Omit = omit,
        recordings: Iterable[call_upsert_params.Recording] | Omit = omit,
        tags: Iterable[TagPointerParam] | Omit = omit,
        transcript: call_upsert_params.Transcript | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Call:
        """
        Find and update an existing phone call, or create a new one.

        Args:
          direction: The direction of the call, either `incoming` or `outgoing`.

          participants: An array of participants involved in the call.

          provider: The name of the phone provider that handled the call (e.g., `openphone`).

          provider_id: The unique identifier for the call from the provider's system.

          provider_status: The status of the call.

          start_at: The time the call started, as an ISO 8601 timestamp in UTC.

          answered_at: The time the call was answered, as an ISO 8601 timestamp in UTC.

          end_at: The time the call ended, as an ISO 8601 timestamp in UTC.

          provider_metadata: A hash of additional metadata from the provider.

          recordings: Any recordings associated with the call.

          tags: Optional list of tag pointers to assign to the call. If omitted, existing tags
              are unchanged. Pass an empty array to clear tags.

          transcript: A transcript of the call.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/calls/upsert",
            body=await async_maybe_transform(
                {
                    "direction": direction,
                    "participants": participants,
                    "provider": provider,
                    "provider_id": provider_id,
                    "provider_status": provider_status,
                    "start_at": start_at,
                    "answered_at": answered_at,
                    "end_at": end_at,
                    "provider_metadata": provider_metadata,
                    "recordings": recordings,
                    "tags": tags,
                    "transcript": transcript,
                },
                call_upsert_params.CallUpsertParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Call,
        )


class CallsResourceWithRawResponse:
    def __init__(self, calls: CallsResource) -> None:
        self._calls = calls

        self.create = to_raw_response_wrapper(
            calls.create,
        )
        self.retrieve = to_raw_response_wrapper(
            calls.retrieve,
        )
        self.list = to_raw_response_wrapper(
            calls.list,
        )
        self.upsert = to_raw_response_wrapper(
            calls.upsert,
        )


class AsyncCallsResourceWithRawResponse:
    def __init__(self, calls: AsyncCallsResource) -> None:
        self._calls = calls

        self.create = async_to_raw_response_wrapper(
            calls.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            calls.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            calls.list,
        )
        self.upsert = async_to_raw_response_wrapper(
            calls.upsert,
        )


class CallsResourceWithStreamingResponse:
    def __init__(self, calls: CallsResource) -> None:
        self._calls = calls

        self.create = to_streamed_response_wrapper(
            calls.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            calls.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            calls.list,
        )
        self.upsert = to_streamed_response_wrapper(
            calls.upsert,
        )


class AsyncCallsResourceWithStreamingResponse:
    def __init__(self, calls: AsyncCallsResource) -> None:
        self._calls = calls

        self.create = async_to_streamed_response_wrapper(
            calls.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            calls.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            calls.list,
        )
        self.upsert = async_to_streamed_response_wrapper(
            calls.upsert,
        )
