"""
Modified Base32 encoding that doesn't use padding and keeps sorting order.

Based on base64 standard library module, modified to use Douglas Crockford's
alphabet (but not other features).
"""

from typing import Final

P32_ALPHABET: Final = "0123456789abcdefghjkmnpqrstvwxyz"

_encode_tables = {}
_decode_tables = {}


def p32encode(s: bytes | bytearray, *, alphabet: str = P32_ALPHABET) -> str:
    """
    Encodes bytes-like objects using Base32 encoding with Crockford's alphabet.
    """

    if not isinstance(s, bytes | bytearray):
        raise TypeError(f"a bytes or bytearray is required, not '{type(s)}'")

    if alphabet not in _encode_tables:
        if len(alphabet) != 32:
            raise ValueError("alphabet must be 32 characters")

        _encode_tables[alphabet] = [a + b for a in alphabet for b in alphabet]

    encode_table = _encode_tables[alphabet]
    leftover = len(s) % 5
    # Pad the last quantum with zero bits if necessary
    if leftover:
        s = s + b"\0" * (5 - leftover)  # Don't use += !

    encoded = ""
    for i in range(0, len(s), 5):
        c = int.from_bytes(s[i : i + 5], byteorder="big")
        encoded += (
            encode_table[c >> 30]  # bits 1 - 10
            + encode_table[(c >> 20) & 0x3FF]  # bits 11 - 20
            + encode_table[(c >> 10) & 0x3FF]  # bits 21 - 30
            + encode_table[c & 0x3FF]  # bits 31 - 40
        )

    # Adjust for any leftover partial quanta
    if leftover == 1:
        encoded = encoded[:-6]
    elif leftover == 2:
        encoded = encoded[:-4]
    elif leftover == 3:
        encoded = encoded[:-3]
    elif leftover == 4:
        encoded = encoded[:-1]

    return encoded


def p32decode(s: str, *, alphabet: str = P32_ALPHABET) -> bytes:
    """
    Decodes bytes from Base32 encoding with Crockford's alphabet.
    """

    if alphabet not in _decode_tables:
        if len(alphabet) != 32:
            raise ValueError("alphabet must be 32 characters")

        _decode_tables[alphabet] = {v: k for k, v in enumerate(alphabet)}

    decode_table = _decode_tables[alphabet]

    # Calculate "padding" we should use
    leftover = len(s) % 8
    padchars = 8 - leftover if leftover else 0
    if padchars not in {0, 1, 3, 4, 6}:
        raise ValueError("Incorrect padding")

    # Now decode the full quanta
    decoded = bytearray()
    acc = 0
    for i in range(0, len(s), 8):
        quanta = s[i : i + 8]
        acc = 0
        try:
            for c in quanta:
                acc = (acc << 5) + decode_table[c]
        except KeyError:
            raise ValueError(f'Non-base32 digit found: "{c!r}"') from None  # pyright: ignore[reportPossiblyUnboundVariable]
        decoded += acc.to_bytes(5)  # big endian

    if padchars and decoded:
        acc <<= 5 * padchars
        last = acc.to_bytes(5)  # big endian
        leftover = (43 - 5 * padchars) // 8  # 1: 4, 3: 3, 4: 2, 6: 1
        decoded[-5:] = last[:leftover]

    return bytes(decoded)
