from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from subprocess import DEVNULL
from typing import Any, Dict, Optional

from fastapi import Body, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from starlette.types import ASGIApp, Receive, Scope, Send

from expops.core.cache_probe.cache_layout import compute_cache_version_hash
from expops.web.server import (
    WORKSPACE_ROOT,
    PROJECTS_DIR,
    PKG_UI_DIR,
    _app_version,
    _is_project_dir,
    get_run_status as _get_run_status_handler,
    list_runs as _list_runs_handler,
    list_projects as _list_projects_handler,
    get_graph as _get_graph_handler,
    list_charts as _list_charts_handler,
    fetch_chart as _fetch_chart_handler,
    _get_chart_config_impl,
    _get_probe_metrics_impl,
    _resolve_firebase_api_key,
)

DEFAULT_PORT = 8765


class _RejectWebsocketMiddleware:
    """StaticFiles only supports HTTP; close stray websocket handshakes before routing.

    Without this, uvicorn routes websocket scopes to the catch-all ``/`` StaticFiles mount,
    which asserts ``scope[\"type\"] == \"http\"`` and logs noisy tracebacks.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 4404})
            return
        await self.app(scope, receive, send)


run_app = FastAPI(title="ExpOps Run Server", version=_app_version())
run_app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Outermost: reject websocket before API/static routing (LIFO order).
run_app.add_middleware(_RejectWebsocketMiddleware)

# Registry of active subprocesses: project_id -> Popen
_active_runs: Dict[str, subprocess.Popen] = {}


@run_app.post("/api/run/{project_id}")
def trigger_run(project_id: str, local: bool = False) -> Dict[str, Any]:
    """Trigger expops run <project_id> as a background subprocess.

    Returns immediately with {status: "started"}. Raises 404 if the project
    does not exist in the local workspace, or 409 if already running.
    """
    project_dir = PROJECTS_DIR / project_id
    if not _is_project_dir(project_dir):
        raise HTTPException(
            status_code=404,
            detail=f"Project '{project_id}' not found in workspace {PROJECTS_DIR}",
        )

    existing = _active_runs.get(project_id)
    if existing is not None and existing.poll() is None:
        raise HTTPException(
            status_code=409,
            detail=f"A run is already active for project '{project_id}'",
        )

    cmd = [sys.executable, "-m", "expops", "run", project_id]
    if local:
        cmd.append("--local")

    proc = subprocess.Popen(
        cmd,
        stdout=DEVNULL,
        stderr=DEVNULL,
        cwd=str(WORKSPACE_ROOT),
    )
    _active_runs[project_id] = proc
    return {"status": "started", "project_id": project_id}


@run_app.get("/api/run/{project_id}/active")
def get_active_status(project_id: str) -> Dict[str, Any]:
    """Check whether a run subprocess is currently active for a project."""
    proc = _active_runs.get(project_id)
    if proc is None:
        return {"running": False, "pid": None}
    if proc.poll() is None:
        return {"running": True, "pid": proc.pid}
    # Process finished — clean up
    del _active_runs[project_id]
    return {"running": False, "pid": None}


@run_app.get("/api/workspace/info")
def get_workspace_info() -> Dict[str, Any]:
    """Return workspace root path and git remote info (if available).

    Walks up from WORKSPACE_ROOT to find a .git directory, then queries the
    remote URL, current branch, and HEAD commit SHA via git CLI.
    """
    # Walk up to find a git root
    git_root: Optional[Path] = None
    candidate = WORKSPACE_ROOT.resolve()
    for _ in range(20):  # cap traversal depth
        if (candidate / ".git").exists():
            git_root = candidate
            break
        parent = candidate.parent
        if parent == candidate:
            break
        candidate = parent

    git_info: Optional[Dict[str, Any]] = None
    if git_root is not None:
        def _git(*args: str) -> Optional[str]:
            result = subprocess.run(
                ["git", "-C", str(git_root), *args],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                return result.stdout.strip() or None
            return None

        remote_url = _git("remote", "get-url", "origin")
        branch = _git("rev-parse", "--abbrev-ref", "HEAD")
        commit_sha = _git("rev-parse", "HEAD")

        if remote_url is not None:
            git_info = {
                "remote_url": remote_url,
                "branch": branch,
                "commit_sha": commit_sha,
            }

    return {"workspace_root": str(WORKSPACE_ROOT), "git": git_info}


@run_app.get("/api/projects/{project_id}/version-hash")
def get_project_version_hash(project_id: str) -> Dict[str, Any]:
    """Return the cache version hash for a project (sha256 of config + scripts).

    The hash is computed by compute_cache_version_hash() and is identical to
    what expops uses internally for cache namespacing.
    """
    project_dir = PROJECTS_DIR / project_id
    if not _is_project_dir(project_dir):
        raise HTTPException(
            status_code=404,
            detail=f"Project '{project_id}' not found in workspace {PROJECTS_DIR}",
        )
    version_hash = compute_cache_version_hash(project_dir)
    return {"project_id": project_id, "version_hash": version_hash}


# --- Backend config endpoint ---

@run_app.get("/api/projects/{project_id}/backend-config")
def get_backend_config(project_id: str) -> Dict[str, Any]:
    """Return the KV backend configuration for a project.

    Used by the webapp to decide whether to use Firestore or local SQLite
    listeners for real-time updates. Resolution matches _kv_for_project / create_kv_store.
    """
    from expops.web.server import resolve_effective_kv_backend_for_listener

    effective, backend_cfg = resolve_effective_kv_backend_for_listener(project_id)
    result: Dict[str, Any] = {"type": effective}
    if effective == "gcp":
        result["gcp_project"] = backend_cfg.get("gcp_project") or None
        result["firebase_api_key"] = _resolve_firebase_api_key(backend_cfg, project_id)
    return result


# --- Monitoring endpoints delegated to server.py handlers ---

@run_app.get("/api/projects")
def list_projects() -> Dict[str, Any]:
    return _list_projects_handler()


@run_app.get("/api/projects/{project_id}/runs")
def list_runs(project_id: str) -> Dict[str, Any]:
    return _list_runs_handler(project_id)


@run_app.get("/api/projects/{project_id}/graph")
def get_graph(project_id: str) -> Dict[str, Any]:
    return _get_graph_handler(project_id)


@run_app.get("/api/projects/{project_id}/runs/{run_id}/status")
def get_run_status(project_id: str, run_id: str) -> Dict[str, Any]:
    return _get_run_status_handler(project_id, run_id)


@run_app.get("/api/projects/{project_id}/runs/{run_id}/charts")
def list_charts(project_id: str, run_id: str) -> Dict[str, Any]:
    return _list_charts_handler(project_id, run_id)


@run_app.get("/api/projects/{project_id}/runs/{run_id}/charts/fetch")
def fetch_chart(project_id: str, run_id: str, uri: str = "", cache_path: str = ""):
    return _fetch_chart_handler(project_id, run_id, uri=uri, cache_path=cache_path)


def _parse_yaml_cfg(yaml_text: str) -> Optional[Dict[str, Any]]:
    """Parse YAML text into a config dict, returning None if empty or invalid."""
    text = (yaml_text or "").strip()
    if not text:
        return None
    import yaml
    cfg = yaml.safe_load(text)
    return cfg if isinstance(cfg, dict) else None


@run_app.post("/api/projects/{project_id}/chart-config")
def get_chart_config(
    project_id: str,
    yaml_text: str = Body(default="", media_type="text/plain"),
) -> Dict[str, Any]:
    """Chart config — accepts project YAML in body; falls back to filesystem."""
    return _get_chart_config_impl(project_id, cfg=_parse_yaml_cfg(yaml_text))


@run_app.post("/api/projects/{project_id}/runs/{run_id}/metrics/{probe_path:path}")
def get_probe_metrics(
    project_id: str,
    run_id: str,
    probe_path: str,
    yaml_text: str = Body(default="", media_type="text/plain"),
) -> Dict[str, Any]:
    """Probe metrics — accepts project YAML in body for XPath resolution; falls back to filesystem."""
    return _get_probe_metrics_impl(project_id, run_id, probe_path, cfg=_parse_yaml_cfg(yaml_text))


# Static file mounts — must come AFTER all API routes so they don't shadow them.
# /projects serves user project JS files; / serves mlops-charts.js and UI assets.
def _mount_static_files() -> None:
    try:
        from fastapi.staticfiles import StaticFiles

        if PROJECTS_DIR.exists():
            run_app.mount("/projects", StaticFiles(directory=str(PROJECTS_DIR)), name="projects-static")

        if PKG_UI_DIR.exists():
            run_app.mount("/", StaticFiles(directory=str(PKG_UI_DIR), html=True), name="static")
    except Exception:
        pass


_mount_static_files()


def create_run_app() -> FastAPI:
    return run_app


if __name__ == "__main__":
    import uvicorn

    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", str(DEFAULT_PORT)))
    uvicorn.run("expops.web.run_server:run_app", host=host, port=port, reload=False)
