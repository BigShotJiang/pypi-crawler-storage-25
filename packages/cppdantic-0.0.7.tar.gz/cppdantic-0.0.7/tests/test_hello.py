def test_hello():
    import cppdantic

    assert cppdantic.hello() == "hello from cppdantic"
