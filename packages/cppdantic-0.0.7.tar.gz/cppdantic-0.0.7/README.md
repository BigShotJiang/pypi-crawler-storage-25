# cppdantic

Small demo that **builds against the `easybind` package from PyPI**. **cppdantic** and **easybind** are **independent** projects (separate repos, separate PyPI names). This repo may include **`external/easybind`** as an **optional git submodule** only so you can browse both trees in one checkout — it is **not** wired into `pyproject.toml` as a path dependency.

**PyPI:** [`cppdantic`](https://pypi.org/project/cppdantic/) (when published). Versioning and tags: **`RELEASING.md`**.

**Bumping `easybind~=…`:** **`easybind-pin-pyproject`** (from **easybind**). Default = latest **`v*`** tag on **GitHub** (repo URL from that package’s PyPI metadata). Use **`--from-pypi`** for PyPI’s published latest instead — see **`RELEASING.md`**.

## Build / test

You need **`easybind`** installed from **PyPI** (matching the pin in **`pyproject.toml`**), plus CMake ≥ 3.25, Ninja, and a C++20 compiler on `PATH`:

```bash
python -m pip install -U pip
python -m pip install "easybind~=0.2.14"   # align with pyproject.toml
python -m pip install -e '.[test]'
python -m pytest tests -q
```

`CMake` loads **`easybind/cmake/easybind_pip.cmake`** from the **installed** **`easybind`** package. PyPI must ship the **`cmake/`** tree for the version you pin.

**Optional submodule:** if you use **`git submodule update --init external/easybind`**, you can also **`pip install -e /path/to/easybind`** from that checkout — it is the same **easybind** project, not a special cppdantic path override.

### uv

From the **cppdantic repo root**:

```bash
uv pip install "easybind~=0.2.14"
uv pip install -e ".[test]"
```

(`pyproject.toml` sets **`[tool.uv] no-build-isolation-package = ["cppdantic"]`** so editable builds use your venv; the **`[test]`** extra pulls in **`setuptools-scm`** and **`scikit-build-core`** for that mode.)

If **`uv pip install`** fails with **`Metadata mismatch in METADATA`** (setuptools-scm version differs between build phases), clear stale artifacts and install **easybind first**, then **cppdantic**:

```bash
rm -rf build dist *.egg-info src/cppdantic/*.egg-info
uv pip install -e external/easybind/
uv pip install -e ".[test]"
```

Ensure **`src/cppdantic/_version.py`** is not tracked by git (it is gitignored). If it was ever committed, run **`git rm --cached src/cppdantic/_version.py`**.

## Tagging

Create an annotated **`v*`** tag on **`main`** after your pins commit (see **`RELEASING.md`**).
