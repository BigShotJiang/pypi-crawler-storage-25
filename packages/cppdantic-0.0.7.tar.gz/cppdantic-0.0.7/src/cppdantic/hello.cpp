#include <easybind/bind.hpp>

EASYBIND_NS_MODULE_SHARED_OBJECT(cppdantic, cppdantic, m, true, {
  m.doc() = "cppdantic hello-world (built against PyPI easybind)";
  m.def("hello", []() { return std::string("hello from cppdantic"); });
});
