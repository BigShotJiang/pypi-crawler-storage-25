# Releasing cppdantic to PyPI

**Pins vs installs:** **`easybind-pin-pyproject`** (default) sets pins from the **latest `v*`** tag on **GitHub**. **cppdantic** still **builds and ships wheels that `pip install easybind`** — that means **PyPI**. Wait until the pinned **`easybind==A.B.C`** exists on PyPI before you rely on isolated installs or CI (see **`easybind-wait-pypi`** in cppdantic’s publish workflow).

## End-to-end workflow (easybind → PyPI → bump cppdantic → tag)

Do this in order.

### 1) Release **easybind** (separate repo; submodule path shown for this monorepo)

```bash
cd /path/to/easybind   # e.g. ~/Devel/cppdantic/external/easybind

git fetch origin && git checkout main && git pull origin main
# commit anything not on main, then:

export EB_TAG=v0.2.4    # choose the new version
git tag -a "$EB_TAG" -m "easybind ${EB_TAG#v}"
git push origin main
git push origin "$EB_TAG"
```

- Wait until GitHub **Publish to PyPI** on **easybind** finishes.
- Check PyPI: **https://pypi.org/project/easybind/** shows **`easybind==`** that version (or `pip install 'easybind==…'` in a clean venv).

### 2) Bump **cppdantic** `pyproject.toml` pins (manual; not CI)

```bash
cd /path/to/cppdantic
python -m pip install -U "easybind"   # refresh devtools / metadata helpers

easybind-pin-pyproject --dry-run
easybind-pin-pyproject                  # sets all easybind~= lines to latest GitHub v* tag (or: --version A.B.C)

git add pyproject.toml
git commit -m "Bump easybind pins"
git push origin main
```

### 3) Tag **cppdantic**

Bump the next **`vMAJOR.MINOR.PATCH`** from the latest **`v*`** tag (usually **patch**). Example:

```bash
cd /path/to/cppdantic
git fetch --tags
export TAG=v0.1.1   # choose the next version
git tag -a "$TAG" -m "cppdantic ${TAG#v}"
git push origin main
git push origin "$TAG"
```

**GitHub vs PyPI:** the cppdantic tag can exist while the publish workflow fails; **`PYPI_API_TOKEN`** must be set on the **cppdantic** repo. Do not tag **cppdantic** for a pin you cannot **`pip install`** yet — CI uses **`easybind-wait-pypi`** so the workflow waits for PyPI.

**CI wait:** the **Publish to PyPI** workflow installs **easybind** from PyPI and runs **`easybind-wait-pypi`** (same behavior as easybind’s wait script): it polls until **`easybind==X.Y.Z`** from your pins exists (default timeout 30 minutes, 30 s interval). Keep the **`pip install "easybind~=…"`** line in **`.github/workflows/publish.yml`** in sync with **`pyproject.toml`** when you bump pins. **No git submodule** is required for cppdantic CI.

---

## Order: easybind first, then bump pins

**cppdantic** builds against whatever **`easybind`** you install; CI and wheels must see a matching release on PyPI.

1. **easybind** (separate repo): merge your changes, tag **`vA.B.C`**, **`git push origin vA.B.C`**, and wait until the **Publish to PyPI** workflow finishes and **`easybind==A.B.C`** is installable from PyPI.
2. **cppdantic**: bump **every** `easybind~=…` in **`pyproject.toml`** (same `A.B.C` in all three places: **`[build-system] requires`**, **`dependencies`**, **`[tool.cibuildwheel.linux] test-requires`**). Automate with **easybind**’s helper (after `pip install easybind` in your venv):

   ```bash
   cd /path/to/cppdantic
   easybind-pin-pyproject --dry-run   # preview (default: latest v* tag on GitHub)
   easybind-pin-pyproject             # pins follow GitHub tags (PyPI metadata supplies github.com/…)
   ```

   **`--from-pypi`:** use this if you want pins to match PyPI’s **published** latest (`info.version`) instead of the highest **`v*`** tag on GitHub (e.g. conservative bumps, or no GitHub URL in metadata — then set **`--from-github YOUR_ORG/easybind`** or fix PyPI project URLs).

   Set **`GITHUB_TOKEN`** if the repo is private or you hit rate limits. Pin manually when needed: **`--version 0.2.6`**. **`--installed`** only helps after **`pip install`** has that version in the venv.

   Before tagging **cppdantic**, ensure the pinned **`easybind==A.B.C`** is on **PyPI** if you expect **`pip install`** / CI to succeed.

   Or import **`easybind.devtools`** — see **easybind**’s README.

   **This is not run by CI or by `pip install`.** It only changes files when **you** run it and **commit** the diff. Builds always use whatever **`easybind~=…`** is already in **`pyproject.toml`** on that commit.

3. **Commit that bump on `main` before you create the cppdantic tag.** The tag must point at a commit that already contains the updated **`pyproject.toml`**.

If you tag cppdantic before the matching easybind wheel exists, isolated builds and cibuildwheel tests can fail.

## Version

Setuptools-scm reads **cppdantic**’s version from **`TAG`** only. **`easybind~=…`** must already be committed and resolvable on PyPI.

Versions come from **Git tags** via **setuptools-scm** (same idea as easybind):

- Tag **`vMAJOR.MINOR.PATCH`** (e.g. `v0.1.0`) on the commit you want to release.
- On that exact tag, the sdist/wheel version is **`MAJOR.MINOR.PATCH`** (`no-guess-dev` + `no-local-version`).
- Untagged trees get a dev version (fine for local installs; for PyPI, tag cleanly).

The wheel metadata version comes from setuptools-scm (no checked-in **`_version.py`** — avoids editable-install metadata mismatches; use **`importlib.metadata.version("cppdantic")`** at runtime).

## CI publish

Pushing a tag **`v*`** runs **`.github/workflows/publish.yml`**: sdist, **cibuildwheel** (manylinux\_2\_28 x86\_64), **twine check**, upload to PyPI.

Set the **`PYPI_API_TOKEN`** repository secret (scoped to this project).

## Manual dry run

```bash
python -m pip install build twine
git fetch --tags
python -m build
twine check dist/*
# twine upload dist/*
```

## Notes

- **Runtime:** the extension expects **`easybind`** installed at the version pinned in **`pyproject.toml`** (e.g. `easybind~=0.2.14`) so **`libeasybind.so`** and headers resolve next to **`site-packages/easybind`** (RPATH **`$ORIGIN/../easybind`**).
- **Wheels** are Linux x86\_64 manylinux for now; extend the workflow if you need macOS/Windows.
