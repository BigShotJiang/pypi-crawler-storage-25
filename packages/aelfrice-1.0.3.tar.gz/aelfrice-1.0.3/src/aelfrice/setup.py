"""Claude Code wiring: idempotent install/uninstall of UserPromptSubmit hooks.

This module mutates a Claude Code `settings.json` file (project- or
user-scoped) to add or remove an entry under
`hooks.UserPromptSubmit`, the hook event Claude Code fires every
time a user submits a prompt. Hook stdout is injected as additional
context for the model — that is the channel through which retrieval
is delivered.

The functions here only manipulate JSON; the actual hook script /
command (which calls aelfrice retrieval and prints context) is
supplied by the caller as a `command` string. That keeps this module
purely about "wiring", with no opinion about *what* the hook does.

Schema reference (a single UserPromptSubmit entry, taken from the
Claude Code settings.json contract):

    {
      "hooks": {
        "UserPromptSubmit": [
          {
            "hooks": [
              {
                "type": "command",
                "command": "aelf retrieve --hook",
                "timeout": 5,
                "statusMessage": "Searching aelfrice..."
              }
            ]
          }
        ]
      }
    }

Idempotency contract: two install calls with the same `command`
string produce a settings.json with exactly one matching entry.
Uninstall is keyed off the same `command` string and is a no-op if
no match exists.

Atomicity contract: the on-disk settings.json either reflects the
prior state or the post-mutation state — never a partial write. We
write to a sibling tempfile and `os.replace` it into place.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Final, Literal, cast, overload

SettingsScope = Literal["user", "project"]

USER_SETTINGS_PATH: Final[Path] = Path.home() / ".claude" / "settings.json"
PROJECT_SETTINGS_RELPATH: Final[Path] = Path(".claude") / "settings.json"
_HOOK_SCRIPT_NAME: Final[str] = "aelf-hook"
# Legacy / pre-pipx shim locations we will silently clean up if they
# point at a deleted target. Keep this list narrow: only paths the
# package itself ever wrote, never user-managed binaries.
_DANGLING_SHIM_CANDIDATES: Final[tuple[Path, ...]] = (
    Path("/usr/local/bin/aelf"),
    Path("/usr/local/bin/aelf-hook"),
)

_HOOKS_KEY: Final[str] = "hooks"
_EVENT_KEY: Final[str] = "UserPromptSubmit"
_INNER_HOOKS_KEY: Final[str] = "hooks"
_TYPE_KEY: Final[str] = "type"
_COMMAND_KEY: Final[str] = "command"
_TIMEOUT_KEY: Final[str] = "timeout"
_STATUS_MESSAGE_KEY: Final[str] = "statusMessage"
_HOOK_TYPE_COMMAND: Final[str] = "command"
_STATUSLINE_KEY: Final[str] = "statusLine"
STATUSLINE_COMMAND: Final[str] = "aelf statusline"
STATUSLINE_SUFFIX: Final[str] = " ; aelf statusline 2>/dev/null"
# Shell metacharacters that signal a "complex" existing statusline command
# we do NOT want to mutate. If any of these are already in the user's
# command we leave it alone and ask them to compose manually.
_COMPLEX_SHELL_TOKENS: Final[tuple[str, ...]] = (
    "|", "<<", "&&", "||", "`", "\\",
)


@dataclass(frozen=True)
class InstallResult:
    """Outcome of `install_user_prompt_submit_hook`.

    `installed` is True when the entry was newly written, False when
    an entry with the same command was already present (idempotent
    no-op). `path` is the settings.json path that was inspected.
    """
    path: Path
    installed: bool
    already_present: bool


@dataclass(frozen=True)
class UninstallResult:
    """Outcome of `uninstall_user_prompt_submit_hook`.

    `removed` counts how many entries with the matching command
    were stripped (typically 0 or 1). `path` is the settings.json
    path that was inspected.
    """
    path: Path
    removed: int


def default_settings_path(
    scope: SettingsScope, project_root: Path | None = None
) -> Path:
    """Resolve the conventional Claude Code settings.json path.

    `scope="user"` returns `~/.claude/settings.json`.
    `scope="project"` returns `<project_root>/.claude/settings.json`.
    `project_root` defaults to the current working directory.
    """
    if scope == "user":
        return USER_SETTINGS_PATH
    root = project_root if project_root is not None else Path.cwd()
    return root / PROJECT_SETTINGS_RELPATH


def _venv_bin_dir() -> Path:
    """Return the directory holding entry-point scripts for the active interpreter.

    Uses `sys.prefix`, which is the venv root for an active virtualenv
    (and the system root otherwise). `sys._base_executable` points at
    the *base* interpreter even inside a venv, so it is unsuitable.
    """
    return Path(sys.prefix) / "bin"


def _executable_in_dir(directory: Path, name: str) -> Path | None:
    """Return `directory/name` if it exists and is executable, else None."""
    candidate = directory / name
    if candidate.is_file() and os.access(candidate, os.X_OK):
        return candidate
    return None


def resolve_hook_command(scope: SettingsScope) -> str:
    """Pick the absolute `aelf-hook` path appropriate for `scope`.

    Project scope: prefer the entry point next to `sys.executable` so
    project-scope settings always pin to that project's venv. This is
    the routing primitive — `~/projects/aelfrice` and
    `~/projects/aelfrice-lab` each get their own venv's `aelf-hook`.

    User scope: prefer `shutil.which("aelf-hook")` so the hook resolves
    to whatever the user has on $PATH (typically a pipx-installed
    `~/.local/bin/aelf-hook`). Fallback chain ensures we never write a
    bare `aelf-hook` that depends on a venv being active later.

    Last-resort fallback is the bare name; tested but emitted only when
    no executable is found anywhere on the system, in which case the
    user has bigger problems and `aelf doctor` will flag it.
    """
    venv_bin = _venv_bin_dir()
    venv_hook = _executable_in_dir(venv_bin, _HOOK_SCRIPT_NAME)
    path_hook_str = shutil.which(_HOOK_SCRIPT_NAME)
    path_hook = Path(path_hook_str) if path_hook_str else None
    if scope == "project":
        chosen = venv_hook or path_hook
    else:
        chosen = path_hook or venv_hook
    if chosen is None:
        return _HOOK_SCRIPT_NAME
    return str(chosen)


def detect_default_scope(cwd: Path | None = None) -> SettingsScope:
    """Pick `project` if the active interpreter is the venv at `cwd`, else `user`.

    The strict test: `sys.prefix` (the active venv root) must equal
    `<cwd>/.venv`. We deliberately do not `.resolve()` `sys.executable`
    because on uv-managed venvs the `python` shim resolves through to
    the *base* interpreter, which would defeat the comparison. Comparing
    venv roots is the correct primitive.
    """
    project_root = cwd if cwd is not None else Path.cwd()
    venv_dir = project_root / ".venv"
    if not venv_dir.exists():
        return "user"
    try:
        venv_resolved = venv_dir.resolve()
        prefix_resolved = Path(sys.prefix).resolve()
    except OSError:
        return "user"
    if prefix_resolved != venv_resolved:
        return "user"
    return "project"


@dataclass(frozen=True)
class DanglingShimCleanup:
    """Outcome of `clean_dangling_shims`.

    `removed` lists the absolute paths that were unlinked (each was a
    symlink whose target no longer existed). Empty when nothing to do.
    `skipped` lists paths we declined to touch (real files, symlinks
    whose target still exists, or non-symlinks owned by another tool).
    """
    removed: tuple[Path, ...]
    skipped: tuple[Path, ...]


def clean_dangling_shims(
    candidates: tuple[Path, ...] | None = None,
) -> DanglingShimCleanup:
    """Silently remove dangling symlinks the package itself ever wrote.

    Only acts on paths in `_DANGLING_SHIM_CANDIDATES` (or the override
    list for tests). A path is removed iff it is a symlink AND its
    target does not exist. Real files and live symlinks are skipped —
    we never destroy a working install.
    """
    targets = candidates if candidates is not None else _DANGLING_SHIM_CANDIDATES
    removed: list[Path] = []
    skipped: list[Path] = []
    for path in targets:
        try:
            is_symlink = path.is_symlink()
        except OSError:
            skipped.append(path)
            continue
        if not is_symlink:
            if path.exists():
                skipped.append(path)
            continue
        try:
            target_exists = path.resolve(strict=True).exists()
        except (OSError, RuntimeError):
            target_exists = False
        if target_exists:
            skipped.append(path)
            continue
        try:
            path.unlink()
        except OSError:
            skipped.append(path)
            continue
        removed.append(path)
    return DanglingShimCleanup(
        removed=tuple(removed), skipped=tuple(skipped)
    )


def install_user_prompt_submit_hook(
    settings_path: Path,
    *,
    command: str,
    timeout: int | None = None,
    status_message: str | None = None,
) -> InstallResult:
    """Add a UserPromptSubmit hook entry running `command`.

    Creates `settings_path` (and parent dirs) if missing. Preserves
    every other key in the file. Idempotent: a second call with the
    same `command` is a no-op and returns `already_present=True`.
    """
    if not command:
        raise ValueError("command must be a non-empty string")
    data = _load_settings(settings_path)
    user_prompt_submit = _get_user_prompt_submit_list(data, create=True)
    if _find_entry_index(user_prompt_submit, command) is not None:
        return InstallResult(
            path=settings_path, installed=False, already_present=True
        )
    user_prompt_submit.append(
        _build_entry(
            command=command, timeout=timeout, status_message=status_message
        )
    )
    _atomic_write(settings_path, data)
    return InstallResult(
        path=settings_path, installed=True, already_present=False
    )


def uninstall_user_prompt_submit_hook(
    settings_path: Path,
    *,
    command: str | None = None,
    command_basename: str | None = None,
) -> UninstallResult:
    """Remove UserPromptSubmit entries matching `command` or `command_basename`.

    Pass exactly one of:
      * `command` -- exact-string match of the stored hook command.
      * `command_basename` -- match every hook whose stored command,
        treated as a path, has this basename. Lets a bare-name install
        and an absolute-path install be cleaned up by the same call.

    Returns `removed=0` if the file does not exist, has no matching
    entry, or has no `hooks.UserPromptSubmit` block at all.
    """
    if command is None and command_basename is None:
        raise ValueError("provide command or command_basename")
    if command is not None and command_basename is not None:
        raise ValueError("command and command_basename are mutually exclusive")
    if command is not None and not command:
        raise ValueError("command must be a non-empty string")
    if command_basename is not None and not command_basename:
        raise ValueError("command_basename must be a non-empty string")
    if not settings_path.exists():
        return UninstallResult(path=settings_path, removed=0)
    data = _load_settings(settings_path)
    user_prompt_submit = _get_user_prompt_submit_list(data, create=False)
    if user_prompt_submit is None:
        return UninstallResult(path=settings_path, removed=0)
    before = len(user_prompt_submit)
    if command is not None:
        kept = [
            entry for entry in user_prompt_submit
            if not _entry_matches(entry, command)
        ]
    else:
        assert command_basename is not None
        kept = [
            entry for entry in user_prompt_submit
            if not _entry_matches_basename(entry, command_basename)
        ]
    removed = before - len(kept)
    if removed == 0:
        return UninstallResult(path=settings_path, removed=0)
    user_prompt_submit[:] = kept
    _atomic_write(settings_path, data)
    return UninstallResult(path=settings_path, removed=removed)


# --- Statusline auto-wiring ---------------------------------------------


@dataclass(frozen=True)
class StatuslineInstallResult:
    """Outcome of `install_statusline`.

    `mode` describes what we did:
      'installed'   - settings had no statusLine; we wrote a fresh one.
      'composed'    - settings had a simple existing statusLine; we
                      appended our snippet to its command.
      'already'     - settings already had our statusline (idempotent).
      'skipped'     - existing statusLine was complex (shell
                      metacharacters); we left it alone. The caller
                      should print the documented manual-compose hint.
    """
    path: Path
    mode: Literal["installed", "composed", "already", "skipped"]
    existing_command: str | None = None


@dataclass(frozen=True)
class StatuslineUninstallResult:
    """Outcome of `uninstall_statusline`.

    `mode` describes what we did:
      'removed'   - statusLine was just `aelf statusline`; field deleted.
      'unwrapped' - statusLine was a composed `<orig> ; aelf statusline ...`;
                    we restored the original command.
      'absent'    - no statusLine matched ours; no-op.
    """
    path: Path
    mode: Literal["removed", "unwrapped", "absent"]


def _looks_complex(command: str) -> bool:
    """True iff `command` contains shell tokens we refuse to wrap."""
    return any(tok in command for tok in _COMPLEX_SHELL_TOKENS)


def _has_our_statusline(command: str) -> bool:
    """True iff `command` already invokes our statusline snippet."""
    return STATUSLINE_COMMAND in command


def install_statusline(
    settings_path: Path, *, statusline_command: str = STATUSLINE_COMMAND
) -> StatuslineInstallResult:
    """Add or compose `aelf statusline` into Claude Code's statusLine.

    Deterministic rules:
      * No `statusLine` set -> write fresh `{type, command}`.
      * Already `aelf statusline` -> idempotent no-op.
      * Existing simple command -> append ' ; aelf statusline 2>/dev/null'.
      * Existing complex command -> skip with a 'skipped' result.
    """
    data = _load_settings(settings_path)
    existing = data.get(_STATUSLINE_KEY)
    if existing is None:
        data[_STATUSLINE_KEY] = {
            _TYPE_KEY: _HOOK_TYPE_COMMAND,
            _COMMAND_KEY: statusline_command,
        }
        _atomic_write(settings_path, data)
        return StatuslineInstallResult(
            path=settings_path, mode="installed", existing_command=None
        )
    if not isinstance(existing, dict):
        # Malformed -- leave alone, signal as skipped so caller can warn.
        return StatuslineInstallResult(
            path=settings_path, mode="skipped",
            existing_command=str(existing),
        )
    existing_dict = cast(dict[str, object], existing)
    cmd_obj = existing_dict.get(_COMMAND_KEY)
    if not isinstance(cmd_obj, str):
        return StatuslineInstallResult(
            path=settings_path, mode="skipped", existing_command=None
        )
    if _has_our_statusline(cmd_obj):
        return StatuslineInstallResult(
            path=settings_path, mode="already", existing_command=cmd_obj
        )
    if _looks_complex(cmd_obj):
        return StatuslineInstallResult(
            path=settings_path, mode="skipped", existing_command=cmd_obj
        )
    existing_dict[_COMMAND_KEY] = cmd_obj + STATUSLINE_SUFFIX
    _atomic_write(settings_path, data)
    return StatuslineInstallResult(
        path=settings_path, mode="composed", existing_command=cmd_obj
    )


def uninstall_statusline(
    settings_path: Path, *, statusline_command: str = STATUSLINE_COMMAND
) -> StatuslineUninstallResult:
    """Reverse `install_statusline` surgically.

    Recognises both the standalone form (drop the field) and the
    composed form (strip our suffix, restore the original command).
    Leaves anything else alone.
    """
    if not settings_path.exists():
        return StatuslineUninstallResult(path=settings_path, mode="absent")
    data = _load_settings(settings_path)
    existing = data.get(_STATUSLINE_KEY)
    if not isinstance(existing, dict):
        return StatuslineUninstallResult(path=settings_path, mode="absent")
    existing_dict = cast(dict[str, object], existing)
    cmd_obj = existing_dict.get(_COMMAND_KEY)
    if not isinstance(cmd_obj, str):
        return StatuslineUninstallResult(path=settings_path, mode="absent")
    if cmd_obj == statusline_command:
        del data[_STATUSLINE_KEY]
        _atomic_write(settings_path, data)
        return StatuslineUninstallResult(path=settings_path, mode="removed")
    if cmd_obj.endswith(STATUSLINE_SUFFIX):
        existing_dict[_COMMAND_KEY] = cmd_obj[: -len(STATUSLINE_SUFFIX)]
        _atomic_write(settings_path, data)
        return StatuslineUninstallResult(path=settings_path, mode="unwrapped")
    return StatuslineUninstallResult(path=settings_path, mode="absent")


# --- internal helpers ---------------------------------------------------


def _load_settings(path: Path) -> dict[str, object]:
    if not path.exists():
        return {}
    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        return {}
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError(
            f"settings file must contain a JSON object at top level: {path}"
        )
    return cast(dict[str, object], parsed)


@overload
def _get_user_prompt_submit_list(
    data: dict[str, object], *, create: Literal[True]
) -> list[dict[str, object]]: ...


@overload
def _get_user_prompt_submit_list(
    data: dict[str, object], *, create: Literal[False]
) -> list[dict[str, object]] | None: ...


def _get_user_prompt_submit_list(
    data: dict[str, object], *, create: bool
) -> list[dict[str, object]] | None:
    hooks_obj = data.get(_HOOKS_KEY)
    if hooks_obj is None:
        if not create:
            return None
        hooks_obj = {}
        data[_HOOKS_KEY] = hooks_obj
    if not isinstance(hooks_obj, dict):
        raise ValueError(f"'{_HOOKS_KEY}' must be an object")
    hooks_dict = cast(dict[str, object], hooks_obj)
    event_list = hooks_dict.get(_EVENT_KEY)
    if event_list is None:
        if not create:
            return None
        event_list = []
        hooks_dict[_EVENT_KEY] = event_list
    if not isinstance(event_list, list):
        raise ValueError(f"'{_HOOKS_KEY}.{_EVENT_KEY}' must be a list")
    return cast(list[dict[str, object]], event_list)


def _build_entry(
    *, command: str, timeout: int | None, status_message: str | None
) -> dict[str, object]:
    inner: dict[str, object] = {
        _TYPE_KEY: _HOOK_TYPE_COMMAND,
        _COMMAND_KEY: command,
    }
    if timeout is not None:
        inner[_TIMEOUT_KEY] = timeout
    if status_message is not None:
        inner[_STATUS_MESSAGE_KEY] = status_message
    return {_INNER_HOOKS_KEY: [inner]}


def _find_entry_index(
    entries: list[dict[str, object]], command: str
) -> int | None:
    for i, entry in enumerate(entries):
        if _entry_matches(entry, command):
            return i
    return None


def _entry_matches(entry: dict[str, object], command: str) -> bool:
    inner = entry.get(_INNER_HOOKS_KEY)
    if not isinstance(inner, list):
        return False
    for hook in cast(list[object], inner):
        if not isinstance(hook, dict):
            continue
        hook_dict = cast(dict[str, object], hook)
        if (
            hook_dict.get(_TYPE_KEY) == _HOOK_TYPE_COMMAND
            and hook_dict.get(_COMMAND_KEY) == command
        ):
            return True
    return False


def _entry_matches_basename(
    entry: dict[str, object], basename: str
) -> bool:
    """True iff any inner command's first whitespace-stripped path token has `basename`."""
    inner = entry.get(_INNER_HOOKS_KEY)
    if not isinstance(inner, list):
        return False
    for hook in cast(list[object], inner):
        if not isinstance(hook, dict):
            continue
        hook_dict = cast(dict[str, object], hook)
        if hook_dict.get(_TYPE_KEY) != _HOOK_TYPE_COMMAND:
            continue
        cmd = hook_dict.get(_COMMAND_KEY)
        if not isinstance(cmd, str):
            continue
        # First whitespace token is the program; basename match against it.
        first = cmd.strip().split(maxsplit=1)[0] if cmd.strip() else ""
        if first and Path(first).name == basename:
            return True
    return False


def _atomic_write(path: Path, data: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    fd, tmp_name = tempfile.mkstemp(
        prefix=path.name + ".", suffix=".tmp", dir=str(path.parent)
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(serialized)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise
