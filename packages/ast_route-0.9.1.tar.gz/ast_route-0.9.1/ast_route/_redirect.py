##
##
##
from __future__ import annotations

import csv
import time
from pathlib import Path

import trio

from .provider import Provider as _Provider

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import TypedDict

class SemiCSV(csv.Dialect):
    "delimit by semicolon"
    delimiter=";"
    doublequote=False
    escapechar="\\"
    lineterminator="\n"
    quotechar='"'
    quoting=csv.QUOTE_MINIMAL
    strict=True

class RedirectProvider(_Provider):
    """
    A router that simply redirects.
    """

    ts: float = 0
    num2name = dict[str, str]
    name2num = dict[str, set[str]]
    db_path: str | None = None
    transport: str

    def __init__(self, table=None, expand=(), **kw):
        super().__init__(**kw)
        self.table = Path(table)
        self.expand = [ str(x) for x in expand ]

        self.in2out = {}

    def status(self):
        "Status"
        res = super().status()
        res["nums"] = len(self.in2out)
        return res

    async def setup(self, kam):
        "Application setup"

        await super().setup(kam)
        await self.run_update()

    #       if kam.app is not None:
    #           kam.app.add_url_rule("/pjsip/add", methods=["POST"], view_func=self.add_peer)

    def route_known(self, snr, dnr) -> TypedDict:
        "Test if the destination is one of our users"
        snr  # noqa:B018
        if (dest := self.in2out.get(dnr, None)) is None:
            return None
        res = {"b_nr": dest[0]}
        res["dest"] = dest[1] or None
        return res

    def _update(self):
        """Thread for list updating"""
        in2out = {}
        with self.table.open("r") as pf:
            # d_number ext secret
            for res in csv.DictReader(pf, dialect=SemiCSV):
                try:
                    num = res["from"]
                    dest = res["to"]
                    prov = res.get("provider",None)
                except KeyError:
                    self.logger.warning("Not recognized: %r", res)
                    continue

                if prov is not None:
                    prov = self.cfg.cfg["provider"][prov]

                dp=(dest,prov)
                nums = []

                # update number mappings
                for n in num.split(","):
                    if n[0] == "*":
                        for nn in self.expand:
                            nums.append(nn + n[1:])
                    else:
                        nums.append(n)

                for num in nums:
                    in2out[num] = dp

            self.in2out = in2out

    async def run_update(self):
        """Run one database update"""
        self.ts = self.table.stat().st_mtime
        await trio.to_thread.run_sync(self._update)

    async def run_updates(self):
        """Background job that waits for the table to be updated"""
        while True:
            await trio.sleep(10)
            try:
                ts = self.table.stat().st_mtime
            except FileNotFoundError:
                continue
            if ts == self.ts:
                continue
            # wait until the file doesn't change any more
            while (ts2 := self.table.stat().st_mtime) > (tm := time.time() - 5):  # noqa:ASYNC110
                await trio.sleep(ts2 - tm)
            await self.run_update()

    async def run(self, kam):  # noqa:ARG002
        "Application runtime"
        if self.table is not None:
            await self.run_updates()
