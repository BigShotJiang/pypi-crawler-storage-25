##
##
##
from __future__ import annotations

import hashlib
import hmac
import json
import math
from pathlib import Path
from pprint import pprint

import httpx
import trio
from asyncopenapi3 import OpenAPI
from quart import request

from .provider import Provider as _Provider


class ZoomProvider(_Provider):
    """
    A provider for routing to Zoom that asks Zoom which numbers are
    assigned.

    Args:
        auth_url: URL to authorize at
        known: additional recognized numbers, statically assigned
        update: Update frequency
    """

    api: OpenAPI | None = None
    sess: httpx.AsyncClient | None = None

    def __init__(self, auth_url=None, cred=None, update=0, known=(), **kw):
        super().__init__(**kw)

        self.numByNr = {}
        self.numById = {}
        self.numUnseen = set()
        self._update = update
        self._known = set(known)

        self._auth_url = auth_url
        self._cred = cred
        self.update_ok = None

    def status(self):
        "Status"
        res = super().status()
        res["nums"] = len(self.numByNr)
        res["users"] = len(self.numById)
        res["static"] = len(self._known)
        res["ok"] &= bool(self.update_ok)
        return res


    def updateNumber(self, nr):
        "apply update for this entry"
        try:
            onr = self.numById.pop(nr.id)
        except KeyError:
            pass
        else:
            del self.numByNr[onr.number.removeprefix("+")]

        if not nr.carrier: ## or nr.carrier.name != "BYOC":
            return

        self.numByNr[nr.number.removeprefix("+")] = nr
        self.numById[nr.id] = nr
        self.numUnseen.discard(nr.id)

    async def updateNumbers(self):
        "fetch and apply the current number list from Zoom"
        self.numUnseen = set(self.numById.keys())
        self.logger.info("Start: update numbers")
        n = x = 0
        try:
            res = await self.api.call_listAccountPhoneNumbers(
                parameters=dict(type="byoc", page_size=100, next_page_token=None)
            )
            while True:
                for r in res.phone_numbers:
                    if r.assignee is None:
                        x += 1
                        continue
                    n += 1
                    self.updateNumber(r)

                npt = res.next_page_token
                if not npt:
                    break
                res = await self.api.call_listAccountPhoneNumbers(
                    parameters=dict(type="byoc", next_page_token=npt, page_size=100)
                )
        except Exception:  # pylint:disable=broad-exception-caught
            self.logger.exception("Update numbers")
            self.update_ok = False
            return

        for nid in self.numUnseen:
            onr = self.numById.pop(nid)
            del self.numByNr[onr.number.removeprefix("+")]
        self.logger.info("Done: update numbers (%d assigned, %d free)", n, x)
        self.update_ok = True

    async def refresh_numbers(self, task_status=trio.TASK_STATUS_IGNORED):
        "Background task for number refresh"
        while True:
            await self.updateNumbers()
            if task_status is not None:
                task_status.started()
                task_status = None
            if self._update < 0:
                return
            await trio.sleep(self._update)

    async def refresh_token(self, task_status=trio.TASK_STATUS_IGNORED):
        "Background task for access token refresh"
        cred = self._cred
        data = {
            "grant_type": "account_credentials",
            "account_id": cred["account"],
            "client_secret": cred["secret"],
        }
        while True:
            self.logger.info("Start: update auth")
            response = await self.sess.post(
                self._auth_url,
                auth=httpx.BasicAuth(username=cred["client"], password=cred["secret"]),
                data=data,
            )
            if response.status_code != 200:
                raise RuntimeError("Unable to get access token", response.text)
                # continue
            response_data = response.json()
            access_token = response_data["access_token"]
            self.api.authenticate("Bearer", "Bearer " + access_token)

            self.logger.info("Start: auth done")
            if task_status is not None:
                task_status.started()
                task_status = None
            await trio.sleep(response_data["expires_in"] * 2 / 3)

    async def _evt(self, *a, **k):
        "Handler for incoming events from Zoom"
        a, k  # noqa:B018 pylint:disable=W0104
        msg = await request.json
        pprint(msg)
        try:
            msg = msg["payload"]["plainToken"]
            signature = (
                hmac.new(
                    bytes(self._cred.token, "utf-8"),
                    msg=bytes(msg, "utf-8"),
                    digestmod=hashlib.sha256,
                )
                .hexdigest()
                .lower()
            )
            return dict(
                plainToken=msg,
                encryptedToken=signature,
            )
        except KeyError:
            return {}

    def route_known(self, snr, dnr):
        "Route test that filters known numbers."
        snr  # noqa:B018 pylint:disable=W0104
        if dnr in self._known:
            return {}
        if dnr in self.numByNr:
            return {}
        return None

    async def setup(self, kam):
        "Application setup"

        await super().setup(kam)

        if kam.app is not None:
            kam.app.add_url_rule("/zoom/evt", methods=["POST"], view_func=self._evt)

    async def run(self, kam, *, task_status=trio.TASK_STATUS_IGNORED):  # noqa:ARG002
        "Application runtime"

        with (Path(__file__).parent / "_data" / "zoom" / "phone.json").open("r") as _f:
            _s = json.load(_f)
        async with (
            OpenAPI(_s) as self.api,
            trio.open_nursery() as n,
        ):
            self.sess = httpx.AsyncClient(limits=httpx.Limits(max_connections=3))
            await n.start(self.refresh_token)
            if self._update:
                await n.start(self.refresh_numbers)
            self.logger.debug("Zoom subsystem is up.")

            task_status.started()
            await trio.sleep(math.inf)
