##
##
##
from __future__ import annotations

import csv
import math
import sqlite3
import time
from pathlib import Path

import trio

from .provider import Provider as _Provider

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import TypedDict


class SemiCSV(csv.Dialect):
    "delimit by semicolon"
    delimiter=";"
    doublequote=False
    escapechar="\\"
    lineterminator="\n"
    quotechar='"'
    quoting=csv.QUOTE_MINIMAL
    strict=True

class PJSipProvider(_Provider):
    """
    A router for users that get saved into the Asterisk database.
    """

    ts: float = 0
    num2name = dict[str, str]
    name2num = dict[str, set[str]]
    db_path: str | None = None
    transport: str

    def __init__(self, peers=None, expand=(), transport="pbx-udp", **kw):
        super().__init__(**kw)
        self.peers = Path(peers)
        self.expand = [ str(x) for x in expand ]
        self.transport = transport

        self.name2num = {}
        self.num2name = {}

    def status(self):
        "Status"
        res = super().status()
        res["peers"] = len(self.name2num)
        res["nums"] = len(self.num2name)
        return res

    async def setup(self, kam):
        "Application setup"

        await super().setup(kam)
        self.db_path = kam.cfg["database"]["path"]
        await self.run_update()

    #       if kam.app is not None:
    #           kam.app.add_url_rule("/pjsip/add", methods=["POST"], view_func=self.add_peer)

    def format_a_in(self, snr:str) -> str|None:
        if snr in self.name2num:
            snr = self.name2num[snr][0]
        return super().format_a_in(snr)

    def route_known(self, snr, dnr) -> TypedDict:
        "Test if the destination is one of our users"
        snr  # noqa:B018
        if (name := self.num2name.get(dnr, None)) is not None:
            return {"end": name, "b_nr": name}
        return None

    def _update(self):
        """Thread for database processing"""
        con = sqlite3.connect(self.db_path)
        with con:
            cur = con.cursor()
            known = set()
            cur.execute("select id from ps_endpoints")
            while True:
                res = cur.fetchone()
                if res is None:
                    break
                known.add(res[0])

            with self.peers.open("r") as pf:
                # d_number ext secret
                for res in csv.DictReader(pf, dialect=SemiCSV):
                    try:
                        num = res["number"]
                        name = res["d_number"]
                        secret = res["secret"]
                    except KeyError:
                        self.logger.warning("Not recognized: %r", res)
                        continue
                    if not num or num[0]=="#":
                        # empty / comment
                        continue

                    nums = []

                    # update name/number mappings
                    for n in num.split(","):
                        if n[0] == "*":
                            for nn in self.expand:
                                nums.append(nn + n[1:])
                        else:
                            nums.append(n)

                    on, self.name2num[name] = self.name2num.get(name), nums
                    for n in nums:
                        self.num2name[n] = name
                    for n in (on or ()):
                        if n not in nums and self.num2name.get(n) == name:
                            del self.num2name[n]

                    pwf="password_digest"
                    pwn="password"
                    supported="SHA-256, MD5"
                    if ":" in secret:
                        scheme="digest"
                    elif len(secret)==32:
                        scheme="digest"
                        secret="MD5:"+secret
                        supported = "MD5"
                    else:
                        scheme="digest"  # userpass?
                        pwf,pwn = pwn,pwf


                    if name in known:
                        cur.execute(
                                "update ps_auths set auth_type = ?," #noqa:S608
                            f" {pwf} = ?, {pwn} = NULL, supported_algorithms_uas = ?"
                            " where id = ?", (scheme, secret, supported, name)
                        )
                        known.remove(name)
                    else:
                        cur.execute(
                            "insert into ps_auths(id,auth_type,realm,username,"
                            f"   {pwf},{pwn},supported_algorithms_uas)"
                            "values(?,?,'STARFACE',?,?,NULL,?)",
                            (name, scheme,name, secret, supported),
                        )
                        cur.execute("insert into ps_aors(id,max_contacts) values(?,1)", (name,))
                        cur.execute(
                            "insert into ps_endpoints("
                            "id,context,    dtmf_mode, disallow,allow,          direct_media,callerid,auth,outbound_auth,aors,transport,rewrite_contact) values("  # noqa:E501
                            "?, 'in_pjsip', 'rfc4733', 'all',   'gsm,alaw,ulaw','no',        ?,       ?,   ?,            ?,   ?,        'yes')",  # noqa:E501
                            (name, name, name, name, name, self.transport),
                        )

            for name in known:
                cur.execute("delete from ps_endpoints where id = ?", (name,))
                cur.execute("delete from ps_aors where id = ?", (name,))
                cur.execute("delete from ps_auths where id = ?", (name,))
                for num in self.name2num.pop(name, ()):
                    if self.num2name.get(num) == name:
                        del self.num2name[num]

    async def run_update(self):
        """Run one database update"""
        self.ts = self.peers.stat().st_mtime
        await trio.to_thread.run_sync(self._update)

    async def run_updates(self):
        """Background job that waits for the peers file to be updated"""
        while True:
            await trio.sleep(10)
            try:
                ts = self.peers.stat().st_mtime
            except FileNotFoundError:
                continue
            if ts == self.ts:
                continue
            # wait until the file doesn't change any more
            while (ts2 := self.peers.stat().st_mtime) > (tm := time.time() - 5):  #noqa:ASYNC110
                await trio.sleep(ts2 - tm)
            await self.run_update()

    async def run(self, kam):  # noqa:ARG002
        "Application runtime"

        async with (trio.open_nursery() as n,):
            if self.peers is not None:
                n.start_soon(self.run_updates)

            await trio.sleep(math.inf)
