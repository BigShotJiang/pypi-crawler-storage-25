"""
Class to hold provider data
"""

from __future__ import annotations

import logging

from .rule import RewriteRule

from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from ._util import ResultD

class RuleD(TypedDict):
    "Stores a single match+result"

    match: str | list[str]
    result: str | bool | None


RuleT = RuleD | bool | None | list[RuleD | bool | None]


class Provider:
    """
    Settings for providers.
    """

    def __init__(
        self,
        name,
        country,
        city,
        prefix,
        channel="PJSIP",
        endpoint=None,
        default=None,  # number to use when incoming is anon
        route=(),
        pre_route=(),
        fallback=None,
        emergency=("110", "112"),
        a_in: RuleT = None,
        b_in: RuleT = None,
        a_out: RuleT = None,
        b_out: RuleT = None,
        p_out: RuleT = False,
        anon=("anonymous", ""),
        **kw,
    ):
        self._name = name
        self.country = str(country) if isinstance(country, int) else country
        self.city = str(city) if isinstance(city, int) else city
        self.prefix = str(prefix) if isinstance(prefix, int) else prefix
        self.default = str(default) if isinstance(default, int) else default
        self.channel = channel
        self.pre_routes = pre_route
        self.fallback = fallback
        self.emergency = emergency
        self.routes = route
        self.a_in = self._rfix(a_in, True, True)
        self.b_in = self._rfix(b_in, False, True)
        self.a_out = self._rfix(a_out, True, False)
        self.p_out = self._rfix(p_out, True, False)
        self.b_out = self._rfix(b_out, False, False)
        self.endpoint = endpoint
        self.anon = frozenset(anon)

        self.logger = logging.getLogger(f"ast_route.prov.{self.name}")

        for k in kw:
            self.logger.warning("Config: Provider %s: unknown %r", self._name, k)

    def _rfix1(self, rule: dict | bool | None, is_in: bool) -> RewriteRule:
        if isinstance(rule, dict):
            rule = RewriteRule(self, is_in, **rule)
        else:
            rule = RewriteRule(self, is_in, result=rule)
        return rule

    def _rfix(self, rule: RuleT, is_a: bool, is_in: bool) -> tuple[RewriteRule]:
        res = []
        if not is_a:
            if (
                not isinstance(rule, (tuple, list))
                or not isinstance(rule[0], dict)
                or rule[0]["match"] != "*"
            ):
                res.append(self._rfix1({"match": self.emergency, "result": "*"}, is_in))

        if not isinstance(rule, (tuple, list)):
            res.append(self._rfix1(rule, is_in))
        else:
            for r in rule:
                res.append(self._rfix1(r, is_in))
        return tuple(res)

    def status(self) -> dict[str,str|int|float]:
        "Status thing"
        return {"ok":True}

    @property
    def name(self) -> str:
        "This provider's name"
        return self._name

    def route(self, snr: str, dnr: str) -> ResultD|None:
        """
        Dedicated routing on the source provider.

        Returns (destnr, destprov) tuple, or `None`.
        """
        for f in self.routes:
            r = f.match(snr, dnr)
            if r is not None:
                r.setdefault("chan", "PJSIP")
                end = self.endpoint or (f.dest.name if f.dest else None)
                if end:
                    r.setdefault("end", end)
                return r
        return None

    def format_a_in(self, nr) -> str:
        "Canonicalize incoming calling number"
        if nr.lower() in self.anon:
            return "anonymous" if self.default is None else self.default
        return self._apply(nr, self.a_in)

    def format_b_in(self, nr) -> str:
        "Canonicalize incoming called number"
        return self._apply(nr, self.b_in)

    def format_a_out(self, nr, rule) -> str:
        "Canonicalize outgoing calling number"
        if nr.lower() in self.anon:
            return "anonymous"
        return self._apply(nr, rule)

    def format_b_out(self, nr, rule) -> str:
        "Canonicalize outgoing called number"
        return self._apply(nr, rule)

    def _apply(self, nr, fmt) -> tuple[str, Provider, str|None]:
        """
        Rewrite an incoming number to CountryCityLocalExt form.
        """
        for rule in fmt:
            if (res := rule.match(nr)) is not None:
                return res
        return nr

    def __repr__(self):
        return f"Ext({self._name})"

    # async part

    async def setup(self, kam):
        "Async setup."
        self.cfg = kam

    async def run(self, kam):
        "Background task. No-op, can be overridden by providers"
