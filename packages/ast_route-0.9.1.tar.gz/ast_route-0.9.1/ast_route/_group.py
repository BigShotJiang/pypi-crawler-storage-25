##
##
##
from __future__ import annotations

import csv
import time
from pathlib import Path

import trio

from .provider import Provider as _Provider

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import TypedDict

class SemiCSV(csv.Dialect):
    "delimit by semicolon"
    delimiter=";"
    doublequote=False
    escapechar="\\"
    lineterminator="\n"
    quotechar='"'
    quoting=csv.QUOTE_MINIMAL
    strict=True

class GroupProvider(_Provider):
    """
    A router that redirects to multiple destinations.
    """

    ts: float = 0
    num2name = dict[str, str]
    name2num = dict[str, set[str]]
    db_path: str | None = None
    transport: str

    def __init__(self, table=None, expand=(), **kw):
        super().__init__(**kw)
        self.table = Path(table)
        self.expand = [ str(x) for x in expand ]

        self.in2out = {}

    def status(self):
        "Status"
        res = super().status()
        res["nums"] = len(self.in2out)
        return res

    async def setup(self, kam):
        "Application setup"

        await super().setup(kam)
        await self.run_update()

    #       if kam.app is not None:
    #           kam.app.add_url_rule("/pjsip/add", methods=["POST"], view_func=self.add_peer)

    def route_known(self, snr, dnr) -> TypedDict:
        "Test if the destination is one of our users"
        snr  # noqa:B018
        if (dest := self.in2out.get(dnr, None)) is None:
            return None
        res = {"chan": "Local"}
        res["dest"] = dest
        return res

    def _update(self):
        """Thread for list updating"""
        in2out = {}
        with self.table.open("r") as pf:
            # d_number ext secret
            for res in csv.reader(pf, dialect=SemiCSV):
                try:
                    src,*dst = res
                except Exception:
                    self.logger.warning("Not recognized: %r", res)
                    continue

                in2out[src] = dst

            self.in2out = in2out

    async def run_update(self):
        """Run one database update"""
        self.ts = self.table.stat().st_mtime
        await trio.to_thread.run_sync(self._update)

    async def run_updates(self):
        """Background job that waits for the table to be updated"""
        while True:
            await trio.sleep(10)
            try:
                ts = self.table.stat().st_mtime
            except FileNotFoundError:
                continue
            if ts == self.ts:
                continue
            # wait until the file doesn't change any more
            while (ts2 := self.table.stat().st_mtime) > (tm := time.time() - 5): #noqa:ASYNC110
                await trio.sleep(ts2 - tm)
            await self.run_update()

    async def run(self, kam):  # noqa:ARG002
        "Application runtime"
        if self.table is not None:
            await self.run_updates()
