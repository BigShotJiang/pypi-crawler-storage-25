from __future__ import annotations

import os

import trio

__all__ = ["systemd_ready"]

from cysystemd.daemon import Notification, notify


async def systemd_ready(*, task_status=trio.TASK_STATUS_IGNORED):
    """
    This coroutine provides keepalive messages to systemd.
    """

    with trio.CancelScope() as sc:
        task_status.started(sc)

        pid = int(os.environ.get("WATCHDOG_PID", os.getpid()))
        delay = int(os.environ.get("WATCHDOG_USEC", 10_000_000)) / 1_500_000  # 2/3rd of usec ⇒ sec
        notify(Notification.READY)

        while os.getpid() == pid:
            await trio.sleep(delay)
            notify(Notification.WATCHDOG)
