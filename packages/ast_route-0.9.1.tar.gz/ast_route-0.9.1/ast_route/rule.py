from __future__ import annotations

import logging
import re

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Literal, Pattern

    from ._util import ResultD
    from .config import Cfg
    from .provider import Provider

logger = logging.getLogger(__name__)

_nr = re.compile(r"\$(\d)")


class Reject(Exception):
    "Reject this route."

    def __init__(self, reason):
        self.reason = reason


class RoutingRule:
    """
    Number Routing.
    """

    # pattern the source number must conform to for the rule to apply
    source: Pattern | None = None

    # pattern the destination number must conform to for the rule to apply
    pattern: Pattern | Literal["*"] = None  # noqa:F722  # ruff error

    # provider to route the result to
    dest: Provider | None = None

    # channel to send the call to, default PJSIP
    channel: str | None = None

    # endpoint to send the call to
    endpoint: str | None = None

    # rewrite pattern to build the destination number
    result: str | None = None

    # method to call instead of "match"
    # destination provider specific!
    use: str | None = None

    prio: int = 0

    def __init__(
        self,
        cfg: Cfg,
        match: str | list[str],
        source: str | None = None,
        dest: str | None = None,
        channel: str | None = None,
        endpoint: str | None = None,
        result: str | None = None,
        reject: str | None = None,
        use: str | None = None,
        prio: int = 0,
    ):
        """
        One routing entry.

        @match: the pattern to match. May be a regexp, a list of explicit
        numbers, or the literal '*' (which matches all global emergency numbers)

        @source: pattern restricting the A numbers this routing entry
        applies to.

        @dest: name of the provider to route a matching number to.

        @channel: name of the destination to send the call to. Typically empty.

        @endpoint: name of the destination to send the call to. Typically empty.

        @reject: if set: don't route this. Incompatible with @dest.

        @result: pattern to rewrite the destination number to. Matches that
        are a list cannot be rewritten.

        @use: Run the match through an additional filter.
        """
        from ._main import ConfigError  # pylint:disable=C0415

        if source is not None:
            try:
                self.source = re.compile(f"^{source}$")
            except Exception as exc:
                raise ValueError(f"Pattern: ^{source}$") from exc
        if isinstance(match, (tuple, list)):
            self.pattern = set(match)
            if result is not None:
                raise ConfigError(
                    f"{source}/{match}: Cannot change the result of a non-pattern match"
                )
        elif match == "*":
            self.pattern = set(cfg.emergency)
            if result is not None:
                raise ConfigError(
                    f"{source}/{match}: Cannot change the result of an emergency number match"
                )
        else:
            try:
                self.pattern = re.compile(f"^{match}$")
            except Exception as exc:
                raise ValueError(f"Pattern: ^{match}$") from exc
        if result is not None:
            result = str(result) if isinstance(result, int) else result
            if not isinstance(self.pattern, re.Pattern):
                raise ConfigError(
                    f"{source}/{match}: Rewriting the result only works with patterns"
                )
            self.result = result
        if dest is not None:
            if reject is not None:
                raise ConfigError(f"{source}/{match}: 'reject' is incompatible with 'dest'")
            try:
                self.dest = cfg.provider[dest]
            except KeyError:
                raise ConfigError(f"{source}/{match}: Provider {dest !r} not found.") from None
            if use is not None:
                self.use = getattr(self.dest, f"route_{use}")
        else:
            if use is not None:
                raise ConfigError(f"{source}/{match}: 'use' requires 'dest'")
        self.prio = prio
        self.reject = reject
        self.channel = channel
        self.endpoint = endpoint

    def __str__(self):
        pre = f"{self.source}🡲" if self.source else ""
        return f"{pre}{self.pattern} 🡲 {self.dest}/{self.result}"

    def __repr__(self):
        pre = f"{self.source}:" if self.source else ""
        return f"{pre}{self.pattern} > {self.dest}/{self.result}"

    def match(self, snr: str, dnr: str) -> ResultD | None:
        """
        If @nr matches does not match this rule, return None.

        If ``.reject`` is set, raise an exception with that string.

        Return (new_nr,dest,channel) if ``.result`` is set.

        Otherwise return (None,dest,channel).
        """
        if self.source is not None and self.source.match(snr) is None:
            return None  # no source match

        if isinstance(self.pattern, set):
            if dnr in self.pattern:
                return (self.result or dnr), self.dest, self.channel
            return None

        if (m := self.pattern.match(dnr)) is None:
            return None

        if self.reject is not None:
            return Reject(self.reject)

        # 'use: known' => call route_known()
        if self.use is not None:
            res = self.use(snr, dnr)
            if res is None:
                return res

        else:
            res = {}

            if self.result is not None:
                def repl(p):
                    return m.group(int(p[1]))

                dest = _nr.sub(repl, self.result)
                if dest is not None:
                    res["b_nr"] = dest

        if self.dest is not None:
            res.setdefault("dest", self.dest)

        if self.channel is not None:
            res.setdefault("chan", self.channel)
        if self.endpoint is not None:
            res.setdefault("end", self.endpoint)
        return res


class RewriteRule:
    """
    Number Rewriting.
    """

    # pattern the destination number must conform to for the rule to apply
    pattern: Pattern | Literal["*"] = None  # noqa:F722  # ruff error

    # rewrite pattern to build the destination number
    result: str | None = None

    def __init__(
        self,
        prov: Provider,
        is_in: bool,
        match: str | list[str] = ".*",
        result: str | bool | None = None,
    ):
        """
        One rewriting entry.

        @match: the pattern to match. May be a regexp, a list of explicit
        numbers, or the literal '*' (which matches all global emergency numbers)

        @result: pattern to rewrite the destination number to. Matches that
        are a list cannot be rewritten.

        @is_in says that the rule applies to incoming numbers.
        Otherwise, outgoing. This is relevant when @pattern is not a string.
        """
        if isinstance(match, (tuple, list)):
            self.pattern = set(match)
        else:
            try:
                self.pattern = re.compile(f"^{match}$")
            except Exception as exc:
                raise ValueError(f"Pattern: ^{match}$") from exc

        if isinstance(result, int) and not isinstance(result, bool):
            result = str(result)
        self.result = result
        self.is_in = is_in
        self.prov = prov


    def match(self, nr: str) -> str:
        """
        Check for a match.

        Returns: the rewritten number, or `None` if not applicable.
        """
        if isinstance(self.pattern, set):
            if nr not in self.pattern:
                return None
            if isinstance(self.result, str):
                if self.result == "*":
                    return nr
                return self.result

        else:
            if (m := self.pattern.match(nr)) is None:
                return None

            if isinstance(self.result, str):
                if self.result == "*":
                    return nr

                def repl(p):
                    return m.group(int(p[1]))

                return _nr.sub(repl, self.result)

        if self.is_in:
            plus = False
            if nr[0] == "+":
                plus = True
                nr = nr[1:]

            if plus or self.result is False:
                return nr
            if self.result is None:
                if nr.startswith("00"):
                    return nr[2:]
                if nr.startswith("0"):
                    return self.prov.country + nr[1:]
                return self.prov.country + self.prov.city + nr

            if self.result is True:
                if not plus:
                    logger.warning("no plus on %s", nr)
                return nr

            # Ugh
            logger.warning("in: %r %s ??", self.result, nr)

        else:  # out
            if self.result is False:
                return nr
            if self.result is None:
                return "00" + nr
            if self.result is True:
                return "+" + nr

            # Ugh 2
            logger.warning("out: %r %s ??", self.result, nr)

        return "X_" + nr
