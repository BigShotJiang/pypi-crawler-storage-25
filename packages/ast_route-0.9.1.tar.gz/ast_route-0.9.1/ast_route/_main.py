"""
This is a Python-centric implementation of Kamailio's routing.
Much effort is spent on using Kamailio's shared memory as sparingly as
possible.

This code is strictly about 1:1 routing to known providers.

It tries very hard to handle number rewrites in a way that's mostly transparent.

"""

from __future__ import annotations

import io
import logging
import sys
from pathlib import Path
from traceback import print_exc

import trio

from ._util import QuartTrio
from .rule import Reject
from .systemd import systemd_ready


class Restart(Exception):
    "Raised when the configuration is reloaded."



class ConfigError(Exception):
    "Configuration has semantic errors."



class Router:
    """
    Main app
    """

    app = None
    sess = None
    url = None
    mode:str
    cfg:dict

    def __init__(self, cfg:dict, mode:str="daemon"):
        self.cfg = cfg
        self.log = logging.getLogger(__name__)
        self.mode = mode

        app = cfg.app_server

        host = app.get("host", "localhost")
        port = app.get("port", "50080")
        self.url = f"http://{host}:{port}"

    def make_app_server(self):
        """
        Creates the QuartTrio application server that provides the routing API.
        """
        self.app = QuartTrio("ast_route")
        self.app.add_url_rule("/route/<srcspec>", methods=["GET"], view_func=self._get_rtx)
        self.app.add_url_rule(
            "/debug/route/<srcspec>", methods=["GET"], view_func=self._get_rtx_debug
        )
        self.app.add_url_rule("/", methods=["GET"], view_func=self._hello)
        self.app.add_url_rule("/status", methods=["GET"], view_func=self.status)

    async def _hello(self):
        return "Hello"

    async def _get_rtx_debug(self, srcspec: str):
        return await self._get_rtx(srcspec, debug=True)

    async def _get_rtx(self, srcspec: str, debug: bool = False):
        try:
            srcprov, srcnr, destnr = srcspec.split(":")
            out = io.StringIO()
            out2 = out if debug else io.StringIO()
            try:
                try:
                    src = self.cfg.provider[srcprov]
                except KeyError:
                    raise Reject(f"Provider {srcprov!r} unknown") from None
                res = self.cfg.route(src, srcnr, destnr, out=out2)
                print(":".join(f"{k}={v}" for k,v in res.items()), file=out)

            except Reject as rej:
                print(f"hangup={rej.reason}", file=out)

            except Exception as exc:
                print_exc(file=out2)
                print(f"hangup=DESTINATION_OUT_OF_ORDER,exc={exc !r}", file=out)

            return out.getvalue()

        except Exception:
            self.log.exception("SRC %r", srcspec)
            raise

    async def run_app_server(self, task_status=trio.TASK_STATUS_IGNORED):
        "Run the app server as a task"
        await self.app.run_task(task_status=task_status, **self.cfg.app_server)

    def status(self):
        "Status"
        res = {}
        res["prov"] = { a:b.status() for a,b in self.cfg.provider.items() }

        ok = all(p["ok"] for p in res["prov"].values())
        res["ok"] = ok

        return res

    async def main(self, *, task_status=None):
        "background processes"

        # Database setup

        try:
            db_cfg = self.cfg["database"]
        except KeyError:
            pass
        else:
            db_data = Path(__file__).parent / "db.22.sql"
            # TODO check Asterisk version

            with db_data.open("r") as dbf:
                await trio.run_process(["sqlite3", db_cfg["path"]], stdin=dbf)
        await getattr(self,f"run_{self.mode}")(task_status=task_status)

    async def run_zoom(self, *, task_status=trio.TASK_STATUS_IGNORED):
        "get and dump zoom data"
        prov = self.cfg.provider["zoom"]
        await prov.setup(self)
        async with trio.open_nursery() as n:
            await n.start(prov.run, self)
            task_status.started()

            ext = {}
            for num,v in prov.numByNr.items():
                v=dict(v) #noqa:PLW2901
                p=dict(v["assignee"])
                inr=p["extension_number"]
                val = ext.setdefault(inr,{})
                z = val.setdefault("zoom",{})
                nums = z.setdefault("nrs",[])
                nums.append(num)
                z["name"] = p["name"]
                z["type"] = p["type"]

            from yaml import safe_dump
            safe_dump(ext, sys.stdout)
            n.cancel_scope.cancel()

    async def run_daemon(self, task_status=trio.TASK_STATUS_IGNORED):
        "Background server"
        self.make_app_server()
        while True:
            try:
                await self._main(task_status)
            except* Restart:
                try:
                    self.cfg = self.cfg.reload()
                except ConfigError as exc:
                    self.log.error(f"Config not changed: {exc :r}")  # noqa:TRY400

            task_status = None

    async def _main(self, task_status):
        async def _run(prov, *, task_status=None):
            await prov.setup(self)
            if task_status is not None:
                task_status.started()
            await prov.run(self)

        async with trio.open_nursery() as n:
            for prov in self.cfg.provider.values():
                await n.start(_run, prov)
            await n.start(self.run_app_server)

            if task_status is not None:
                task_status.started()

            self.log.debug("Startup done.")
            await n.start(systemd_ready)
            while True:
                await trio.sleep(5)
                if not self.cfg.is_changed():
                    continue

                self.log.error("App changed, reloading")
                raise Restart
