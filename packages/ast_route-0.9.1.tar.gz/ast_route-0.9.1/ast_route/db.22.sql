CREATE TABLE if not exists "alembic_version_config" (
  "version_num" varchar(32) NOT NULL,
  PRIMARY KEY ("version_num")
);

delete from "alembic_version_config";
INSERT INTO "alembic_version_config" VALUES
('abdc9ede147d');

--
-- Table structure for table "extensions"
--

CREATE TABLE if not exists "extensions" (
  "id" bigint(20) NOT NULL,
  "context" varchar(40) NOT NULL,
  "exten" varchar(40) NOT NULL,
  "priority" int(11) NOT NULL,
  "app" varchar(40) NOT NULL,
  "appdata" varchar(256) NOT NULL,
  PRIMARY KEY ("id")
);
create unique index if not exists extensions_context on extensions ("context","exten","priority");
create unique index if not exists extensions_id on extensions ("id");

--
-- Table structure for table "iaxfriends"
--

CREATE TABLE if not exists "iaxfriends" (
  "id" int(11) NOT NULL,
  "name" varchar(40) NOT NULL,
  "type" varchar(20) DEFAULT NULL,
  "username" varchar(40) DEFAULT NULL,
  "mailbox" varchar(40) DEFAULT NULL,
  "secret" varchar(40) DEFAULT NULL,
  "dbsecret" varchar(40) DEFAULT NULL,
  "context" varchar(40) DEFAULT NULL,
  "regcontext" varchar(40) DEFAULT NULL,
  "host" varchar(40) DEFAULT NULL,
  "ipaddr" varchar(40) DEFAULT NULL,
  "port" int(11) DEFAULT NULL,
  "defaultip" varchar(20) DEFAULT NULL,
  "sourceaddress" varchar(20) DEFAULT NULL,
  "mask" varchar(20) DEFAULT NULL,
  "regexten" varchar(40) DEFAULT NULL,
  "regseconds" int(11) DEFAULT NULL,
  "accountcode" varchar(80) DEFAULT NULL,
  "mohinterpret" varchar(20) DEFAULT NULL,
  "mohsuggest" varchar(20) DEFAULT NULL,
  "inkeys" varchar(40) DEFAULT NULL,
  "outkeys" varchar(40) DEFAULT NULL,
  "language" varchar(10) DEFAULT NULL,
  "callerid" varchar(100) DEFAULT NULL,
  "cid_number" varchar(40) DEFAULT NULL,
  "sendani" varchar(20) DEFAULT NULL,
  "fullname" varchar(40) DEFAULT NULL,
  "trunk" varchar(20) DEFAULT NULL,
  "auth" varchar(20) DEFAULT NULL,
  "maxauthreq" int(11) DEFAULT NULL,
  "requirecalltoken" varchar(20) DEFAULT NULL,
  "encryption" varchar(20) DEFAULT NULL,
  "transfer" varchar(20) DEFAULT NULL,
  "jitterbuffer" varchar(20) DEFAULT NULL,
  "forcejitterbuffer" varchar(20) DEFAULT NULL,
  "disallow" varchar(200) DEFAULT NULL,
  "allow" varchar(200) DEFAULT NULL,
  "codecpriority" varchar(40) DEFAULT NULL,
  "qualify" varchar(10) DEFAULT NULL,
  "qualifysmoothing" varchar(20) DEFAULT NULL,
  "qualifyfreqok" varchar(10) DEFAULT NULL,
  "qualifyfreqnotok" varchar(10) DEFAULT NULL,
  "timezone" varchar(20) DEFAULT NULL,
  "adsi" varchar(20) DEFAULT NULL,
  "amaflags" varchar(20) DEFAULT NULL,
  "setvar" varchar(200) DEFAULT NULL,
  PRIMARY KEY ("id")
);
create unique index if not exists iaxfriends_name on iaxfriends ("name");
create index if not exists iaxfriends_iaxfriends_name on iaxfriends ("name");
create index if not exists iaxfriends_iaxfriends_name_host on iaxfriends ("name","host");
create index if not exists iaxfriends_iaxfriends_name_ipaddr_port on iaxfriends ("name","ipaddr","port");
create index if not exists iaxfriends_iaxfriends_ipaddr_port on iaxfriends ("ipaddr","port");
create index if not exists iaxfriends_iaxfriends_host_port on iaxfriends ("host","port");

--
-- Table structure for table "meetme"
--

CREATE TABLE if not exists "meetme" (
  "bookid" int(11) NOT NULL,
  "confno" varchar(80) NOT NULL,
  "starttime" datetime DEFAULT NULL,
  "endtime" datetime DEFAULT NULL,
  "pin" varchar(20) DEFAULT NULL,
  "adminpin" varchar(20) DEFAULT NULL,
  "opts" varchar(20) DEFAULT NULL,
  "adminopts" varchar(20) DEFAULT NULL,
  "recordingfilename" varchar(80) DEFAULT NULL,
  "recordingformat" varchar(10) DEFAULT NULL,
  "maxusers" int(11) DEFAULT NULL,
  "members" int(11) NOT NULL,
  PRIMARY KEY ("bookid")
);
create index if not exists meetme_meetme_confno_start_end on meetme ("confno","starttime","endtime");

--
-- Table structure for table "musiconhold"
--

CREATE TABLE if not exists "musiconhold" (
  "name" varchar(80) NOT NULL,
  "mode" varchar(20) DEFAULT NULL,
  "directory" varchar(255) DEFAULT NULL,
  "application" varchar(255) DEFAULT NULL,
  "digit" varchar(1) DEFAULT NULL,
  "sort" varchar(10) DEFAULT NULL,
  "format" varchar(10) DEFAULT NULL,
  "stamp" datetime DEFAULT NULL,
  "loop_last" varchar(20) DEFAULT NULL,
  PRIMARY KEY ("name")
);

--
-- Table structure for table "musiconhold_entry"
--

CREATE TABLE if not exists "musiconhold_entry" (
  "name" varchar(80) NOT NULL,
  "position" int(11) NOT NULL,
  "entry" varchar(1024) NOT NULL,
  PRIMARY KEY ("name","position"),
  CONSTRAINT "fk_musiconhold_entry_name_musiconhold" FOREIGN KEY ("name") REFERENCES "musiconhold" ("name")
);

--
-- Table structure for table "ps_aors"
--

CREATE TABLE if not exists "ps_aors" (
  "id" varchar(255) NOT NULL,
  "contact" varchar(255) DEFAULT NULL,
  "default_expiration" int(11) DEFAULT NULL,
  "mailboxes" varchar(80) DEFAULT NULL,
  "max_contacts" int(11) DEFAULT NULL,
  "minimum_expiration" int(11) DEFAULT NULL,
  "remove_existing" varchar(20) DEFAULT NULL,
  "qualify_frequency" int(11) DEFAULT NULL,
  "authenticate_qualify" varchar(20) DEFAULT NULL,
  "maximum_expiration" int(11) DEFAULT NULL,
  "outbound_proxy" varchar(255) DEFAULT NULL,
  "support_path" varchar(20) DEFAULT NULL,
  "qualify_timeout" float DEFAULT NULL,
  "voicemail_extension" varchar(40) DEFAULT NULL,
  "remove_unavailable" varchar(20) DEFAULT NULL,
  "qualify_2xx_only" varchar(20) DEFAULT NULL
);
create unique index if not exists ps_aors_id on ps_aors ("id");
create index if not exists ps_aors_ps_aors_id on ps_aors ("id");
create index if not exists ps_aors_ps_aors_qualifyfreq_contact on ps_aors ("qualify_frequency","contact");

--
-- Table structure for table "ps_asterisk_publications"
--

CREATE TABLE if not exists "ps_asterisk_publications" (
  "id" varchar(40) NOT NULL,
  "devicestate_publish" varchar(40) DEFAULT NULL,
  "mailboxstate_publish" varchar(40) DEFAULT NULL,
  "device_state" varchar(20) DEFAULT NULL,
  "device_state_filter" varchar(256) DEFAULT NULL,
  "mailbox_state" varchar(20) DEFAULT NULL,
  "mailbox_state_filter" varchar(256) DEFAULT NULL
);
create unique index if not exists ps_asterisk_publications_id on ps_asterisk_publications ("id");
create index if not exists ps_asterisk_publications_ps_asterisk_publications_id on ps_asterisk_publications ("id");

--
-- Table structure for table "ps_auths"
--

CREATE TABLE if not exists "ps_auths" (
  "id" varchar(255) NOT NULL,
  "auth_type" varchar(20) DEFAULT NULL,
  "nonce_lifetime" int(11) DEFAULT NULL,
  "md5_cred" varchar(40) DEFAULT NULL,
  "password" varchar(80) DEFAULT NULL,
  "realm" varchar(255) DEFAULT NULL,
  "username" varchar(40) DEFAULT NULL,
  "refresh_token" varchar(255) DEFAULT NULL,
  "oauth_clientid" varchar(255) DEFAULT NULL,
  "oauth_secret" varchar(255) DEFAULT NULL,
  "password_digest" varchar(1024) DEFAULT NULL,
  "supported_algorithms_uas" varchar(1024) DEFAULT NULL,
  "supported_algorithms_uac" varchar(1024) DEFAULT NULL
);
create unique index if not exists ps_auths_id on ps_auths ("id");
create index if not exists ps_auths_ps_auths_id on ps_auths ("id");

--
-- Table structure for table "ps_contacts"
--

CREATE TABLE if not exists "ps_contacts" (
  "id" varchar(255) DEFAULT NULL,
  "uri" varchar(511) DEFAULT NULL,
  "expiration_time" bigint(20) DEFAULT NULL,
  "qualify_frequency" int(11) DEFAULT NULL,
  "outbound_proxy" varchar(255) DEFAULT NULL,
  "path" text DEFAULT NULL,
  "user_agent" varchar(255) DEFAULT NULL,
  "qualify_timeout" float DEFAULT NULL,
  "reg_server" varchar(255) DEFAULT NULL,
  "authenticate_qualify" varchar(20) DEFAULT NULL,
  "via_addr" varchar(40) DEFAULT NULL,
  "via_port" int(11) DEFAULT NULL,
  "call_id" varchar(255) DEFAULT NULL,
  "endpoint" varchar(255) DEFAULT NULL,
  "prune_on_boot" varchar(20) DEFAULT NULL,
  "qualify_2xx_only" varchar(20) DEFAULT NULL
);
create unique index if not exists ps_contacts_id on ps_contacts ("id");
create unique index if not exists ps_contacts_ps_contacts_uq on ps_contacts ("id","reg_server");
create index if not exists ps_contacts_ps_contacts_id on ps_contacts ("id");
create index if not exists ps_contacts_ps_contacts_qualifyfreq_exp on ps_contacts ("qualify_frequency","expiration_time");

--
-- Table structure for table "ps_domain_aliases"
--

CREATE TABLE if not exists "ps_domain_aliases" (
  "id" varchar(255) NOT NULL,
  "domain" varchar(255) DEFAULT NULL
);
create unique index if not exists ps_domain_aliases_id on ps_domain_aliases ("id");
create index if not exists ps_domain_aliases_ps_domain_aliases_id on ps_domain_aliases ("id");

--
-- Table structure for table "ps_endpoint_id_ips"
--

CREATE TABLE if not exists "ps_endpoint_id_ips" (
  "id" varchar(255) NOT NULL,
  "endpoint" varchar(255) DEFAULT NULL,
  "match" varchar(80) DEFAULT NULL,
  "srv_lookups" varchar(20) DEFAULT NULL,
  "match_header" varchar(255) DEFAULT NULL,
  "match_request_uri" varchar(255) DEFAULT NULL
);
create unique index if not exists ps_endpoint_id_ips_id on ps_endpoint_id_ips ("id");
create index if not exists ps_endpoint_id_ips_ps_endpoint_id_ips_id on ps_endpoint_id_ips ("id");

--
-- Table structure for table "ps_endpoints"
--

CREATE TABLE if not exists "ps_endpoints" (
  "id" varchar(255) NOT NULL,
  "transport" varchar(40) DEFAULT NULL,
  "aors" varchar(2048) DEFAULT NULL,
  "auth" varchar(255) DEFAULT NULL,
  "context" varchar(40) DEFAULT NULL,
  "disallow" varchar(200) DEFAULT NULL,
  "allow" varchar(200) DEFAULT NULL,
  "direct_media" varchar(20) DEFAULT NULL,
  "connected_line_method" varchar(20) DEFAULT NULL,
  "direct_media_method" varchar(20) DEFAULT NULL,
  "direct_media_glare_mitigation" varchar(20) DEFAULT NULL,
  "disable_direct_media_on_nat" varchar(20) DEFAULT NULL,
  "dtmf_mode" varchar(20) DEFAULT NULL,
  "external_media_address" varchar(40) DEFAULT NULL,
  "force_rport" varchar(20) DEFAULT NULL,
  "ice_support" varchar(20) DEFAULT NULL,
  "identify_by" varchar(80) DEFAULT NULL,
  "mailboxes" varchar(40) DEFAULT NULL,
  "moh_suggest" varchar(40) DEFAULT NULL,
  "outbound_auth" varchar(255) DEFAULT NULL,
  "outbound_proxy" varchar(255) DEFAULT NULL,
  "rewrite_contact" varchar(20) DEFAULT NULL,
  "rtp_ipv6" varchar(20) DEFAULT NULL,
  "rtp_symmetric" varchar(20) DEFAULT NULL,
  "send_diversion" varchar(20) DEFAULT NULL,
  "send_pai" varchar(20) DEFAULT NULL,
  "send_rpid" varchar(20) DEFAULT NULL,
  "timers_min_se" int(11) DEFAULT NULL,
  "timers" varchar(20) DEFAULT NULL,
  "timers_sess_expires" int(11) DEFAULT NULL,
  "callerid" varchar(40) DEFAULT NULL,
  "callerid_privacy" varchar(20) DEFAULT NULL,
  "callerid_tag" varchar(40) DEFAULT NULL,
  "100rel" varchar(20) DEFAULT NULL,
  "aggregate_mwi" varchar(20) DEFAULT NULL,
  "trust_id_inbound" varchar(20) DEFAULT NULL,
  "trust_id_outbound" varchar(20) DEFAULT NULL,
  "use_ptime" varchar(20) DEFAULT NULL,
  "use_avpf" varchar(20) DEFAULT NULL,
  "media_encryption" varchar(20) DEFAULT NULL,
  "inband_progress" varchar(20) DEFAULT NULL,
  "call_group" varchar(40) DEFAULT NULL,
  "pickup_group" varchar(40) DEFAULT NULL,
  "named_call_group" varchar(40) DEFAULT NULL,
  "named_pickup_group" varchar(40) DEFAULT NULL,
  "device_state_busy_at" int(11) DEFAULT NULL,
  "fax_detect" varchar(20) DEFAULT NULL,
  "t38_udptl" varchar(20) DEFAULT NULL,
  "t38_udptl_ec" varchar(20) DEFAULT NULL,
  "t38_udptl_maxdatagram" int(11) DEFAULT NULL,
  "t38_udptl_nat" varchar(20) DEFAULT NULL,
  "t38_udptl_ipv6" varchar(20) DEFAULT NULL,
  "tone_zone" varchar(40) DEFAULT NULL,
  "language" varchar(40) DEFAULT NULL,
  "one_touch_recording" varchar(20) DEFAULT NULL,
  "record_on_feature" varchar(40) DEFAULT NULL,
  "record_off_feature" varchar(40) DEFAULT NULL,
  "rtp_engine" varchar(40) DEFAULT NULL,
  "allow_transfer" varchar(20) DEFAULT NULL,
  "allow_subscribe" varchar(20) DEFAULT NULL,
  "sdp_owner" varchar(40) DEFAULT NULL,
  "sdp_session" varchar(40) DEFAULT NULL,
  "tos_audio" varchar(10) DEFAULT NULL,
  "tos_video" varchar(10) DEFAULT NULL,
  "sub_min_expiry" int(11) DEFAULT NULL,
  "from_domain" varchar(40) DEFAULT NULL,
  "from_user" varchar(40) DEFAULT NULL,
  "mwi_from_user" varchar(40) DEFAULT NULL,
  "dtls_verify" varchar(40) DEFAULT NULL,
  "dtls_rekey" varchar(40) DEFAULT NULL,
  "dtls_cert_file" varchar(200) DEFAULT NULL,
  "dtls_private_key" varchar(200) DEFAULT NULL,
  "dtls_cipher" varchar(200) DEFAULT NULL,
  "dtls_ca_file" varchar(200) DEFAULT NULL,
  "dtls_ca_path" varchar(200) DEFAULT NULL,
  "dtls_setup" varchar(20) DEFAULT NULL,
  "srtp_tag_32" varchar(20) DEFAULT NULL,
  "media_address" varchar(40) DEFAULT NULL,
  "redirect_method" varchar(20) DEFAULT NULL,
  "set_var" text DEFAULT NULL,
  "cos_audio" int(11) DEFAULT NULL,
  "cos_video" int(11) DEFAULT NULL,
  "message_context" varchar(40) DEFAULT NULL,
  "force_avp" varchar(20) DEFAULT NULL,
  "media_use_received_transport" varchar(20) DEFAULT NULL,
  "accountcode" varchar(80) DEFAULT NULL,
  "user_eq_phone" varchar(20) DEFAULT NULL,
  "moh_passthrough" varchar(20) DEFAULT NULL,
  "media_encryption_optimistic" varchar(20) DEFAULT NULL,
  "rpid_immediate" varchar(20) DEFAULT NULL,
  "g726_non_standard" varchar(20) DEFAULT NULL,
  "rtp_keepalive" int(11) DEFAULT NULL,
  "rtp_timeout" int(11) DEFAULT NULL,
  "rtp_timeout_hold" int(11) DEFAULT NULL,
  "bind_rtp_to_media_address" varchar(20) DEFAULT NULL,
  "voicemail_extension" varchar(40) DEFAULT NULL,
  "mwi_subscribe_replaces_unsolicited" varchar(20) DEFAULT NULL,
  "deny" varchar(95) DEFAULT NULL,
  "permit" varchar(95) DEFAULT NULL,
  "acl" varchar(40) DEFAULT NULL,
  "contact_deny" varchar(95) DEFAULT NULL,
  "contact_permit" varchar(95) DEFAULT NULL,
  "contact_acl" varchar(40) DEFAULT NULL,
  "subscribe_context" varchar(40) DEFAULT NULL,
  "fax_detect_timeout" int(11) DEFAULT NULL,
  "contact_user" varchar(80) DEFAULT NULL,
  "preferred_codec_only" varchar(20) DEFAULT NULL,
  "asymmetric_rtp_codec" varchar(20) DEFAULT NULL,
  "rtcp_mux" varchar(20) DEFAULT NULL,
  "allow_overlap" varchar(20) DEFAULT NULL,
  "refer_blind_progress" varchar(20) DEFAULT NULL,
  "notify_early_inuse_ringing" varchar(20) DEFAULT NULL,
  "max_audio_streams" int(11) DEFAULT NULL,
  "max_video_streams" int(11) DEFAULT NULL,
  "webrtc" varchar(20) DEFAULT NULL,
  "dtls_fingerprint" varchar(20) DEFAULT NULL,
  "incoming_mwi_mailbox" varchar(40) DEFAULT NULL,
  "bundle" varchar(20) DEFAULT NULL,
  "dtls_auto_generate_cert" varchar(20) DEFAULT NULL,
  "follow_early_media_fork" varchar(20) DEFAULT NULL,
  "accept_multiple_sdp_answers" varchar(20) DEFAULT NULL,
  "suppress_q850_reason_headers" varchar(20) DEFAULT NULL,
  "trust_connected_line" varchar(20) DEFAULT NULL,
  "send_connected_line" varchar(20) DEFAULT NULL,
  "ignore_183_without_sdp" varchar(20) DEFAULT NULL,
  "codec_prefs_incoming_offer" varchar(128) DEFAULT NULL,
  "codec_prefs_outgoing_offer" varchar(128) DEFAULT NULL,
  "codec_prefs_incoming_answer" varchar(128) DEFAULT NULL,
  "codec_prefs_outgoing_answer" varchar(128) DEFAULT NULL,
  "stir_shaken" varchar(20) DEFAULT NULL,
  "send_history_info" varchar(20) DEFAULT NULL,
  "allow_unauthenticated_options" varchar(20) DEFAULT NULL,
  "t38_bind_udptl_to_media_address" varchar(20) DEFAULT NULL,
  "geoloc_incoming_call_profile" varchar(80) DEFAULT NULL,
  "geoloc_outgoing_call_profile" varchar(80) DEFAULT NULL,
  "incoming_call_offer_pref" varchar(20) DEFAULT NULL,
  "outgoing_call_offer_pref" varchar(20) DEFAULT NULL,
  "stir_shaken_profile" varchar(80) DEFAULT NULL,
  "security_negotiation" varchar(20) DEFAULT NULL,
  "security_mechanisms" varchar(512) DEFAULT NULL,
  "send_aoc" varchar(20) DEFAULT NULL,
  "overlap_context" varchar(80) DEFAULT NULL,
  "tenantid" varchar(80) DEFAULT NULL,
  "suppress_moh_on_sendonly" varchar(20) DEFAULT NULL
);
create unique index if not exists ps_endpoints_id on ps_endpoints ("id");
create index if not exists ps_endpoints_ps_endpoints_id on ps_endpoints ("id");

--
-- Table structure for table "ps_globals"
--

CREATE TABLE if not exists "ps_globals" (
  "id" varchar(40) NOT NULL,
  "max_forwards" int(11) DEFAULT NULL,
  "user_agent" varchar(255) DEFAULT NULL,
  "default_outbound_endpoint" varchar(40) DEFAULT NULL,
  "debug" varchar(40) DEFAULT NULL,
  "endpoint_identifier_order" varchar(40) DEFAULT NULL,
  "max_initial_qualify_time" int(11) DEFAULT NULL,
  "default_from_user" varchar(80) DEFAULT NULL,
  "keep_alive_interval" int(11) DEFAULT NULL,
  "regcontext" varchar(80) DEFAULT NULL,
  "contact_expiration_check_interval" int(11) DEFAULT NULL,
  "default_voicemail_extension" varchar(40) DEFAULT NULL,
  "disable_multi_domain" varchar(20) DEFAULT NULL,
  "unidentified_request_count" int(11) DEFAULT NULL,
  "unidentified_request_period" int(11) DEFAULT NULL,
  "unidentified_request_prune_interval" int(11) DEFAULT NULL,
  "default_realm" varchar(40) DEFAULT NULL,
  "mwi_tps_queue_high" int(11) DEFAULT NULL,
  "mwi_tps_queue_low" int(11) DEFAULT NULL,
  "mwi_disable_initial_unsolicited" varchar(20) DEFAULT NULL,
  "ignore_uri_user_options" varchar(20) DEFAULT NULL,
  "use_callerid_contact" varchar(20) DEFAULT NULL,
  "send_contact_status_on_update_registration" varchar(20) DEFAULT NULL,
  "taskprocessor_overload_trigger" varchar(20) DEFAULT NULL,
  "norefersub" varchar(20) DEFAULT NULL,
  "allow_sending_180_after_183" varchar(20) DEFAULT NULL,
  "all_codecs_on_empty_reinvite" varchar(20) DEFAULT NULL,
  "default_auth_algorithms_uas" varchar(1024) DEFAULT NULL,
  "default_auth_algorithms_uac" varchar(1024) DEFAULT NULL
);
create unique index if not exists ps_globals_id on ps_globals ("id");
create index if not exists ps_globals_ps_globals_id on ps_globals ("id");

--
-- Table structure for table "ps_inbound_publications"
--

CREATE TABLE if not exists "ps_inbound_publications" (
  "id" varchar(255) NOT NULL,
  "endpoint" varchar(255) DEFAULT NULL,
  "event_asterisk-devicestate" varchar(40) DEFAULT NULL,
  "event_asterisk-mwi" varchar(40) DEFAULT NULL
);
create unique index if not exists ps_inbound_publications_id on ps_inbound_publications ("id");
create index if not exists ps_inbound_publications_ps_inbound_publications_id on ps_inbound_publications ("id");

--
-- Table structure for table "ps_outbound_publishes"
--

CREATE TABLE if not exists "ps_outbound_publishes" (
  "id" varchar(255) NOT NULL,
  "expiration" int(11) DEFAULT NULL,
  "outbound_auth" varchar(255) DEFAULT NULL,
  "outbound_proxy" varchar(256) DEFAULT NULL,
  "server_uri" varchar(256) DEFAULT NULL,
  "from_uri" varchar(256) DEFAULT NULL,
  "to_uri" varchar(256) DEFAULT NULL,
  "event" varchar(40) DEFAULT NULL,
  "max_auth_attempts" int(11) DEFAULT NULL,
  "transport" varchar(40) DEFAULT NULL,
  "multi_user" varchar(20) DEFAULT NULL,
  "@body" varchar(40) DEFAULT NULL,
  "@context" varchar(256) DEFAULT NULL,
  "@exten" varchar(256) DEFAULT NULL
);
create unique index if not exists ps_outbound_publishes_id on ps_outbound_publishes ("id");
create index if not exists ps_outbound_publishes_ps_outbound_publishes_id on ps_outbound_publishes ("id");

--
-- Table structure for table "ps_registrations"
--

CREATE TABLE if not exists "ps_registrations" (
  "id" varchar(255) NOT NULL,
  "auth_rejection_permanent" varchar(20) DEFAULT NULL,
  "client_uri" varchar(255) DEFAULT NULL,
  "contact_user" varchar(40) DEFAULT NULL,
  "expiration" int(11) DEFAULT NULL,
  "max_retries" int(11) DEFAULT NULL,
  "outbound_auth" varchar(255) DEFAULT NULL,
  "outbound_proxy" varchar(255) DEFAULT NULL,
  "retry_interval" int(11) DEFAULT NULL,
  "forbidden_retry_interval" int(11) DEFAULT NULL,
  "server_uri" varchar(255) DEFAULT NULL,
  "transport" varchar(40) DEFAULT NULL,
  "support_path" varchar(20) DEFAULT NULL,
  "fatal_retry_interval" int(11) DEFAULT NULL,
  "line" varchar(20) DEFAULT NULL,
  "endpoint" varchar(255) DEFAULT NULL,
  "support_outbound" varchar(20) DEFAULT NULL,
  "contact_header_params" varchar(255) DEFAULT NULL,
  "max_random_initial_delay" int(11) DEFAULT NULL,
  "security_negotiation" varchar(20) DEFAULT NULL,
  "security_mechanisms" varchar(512) DEFAULT NULL,
  "user_agent" varchar(255) DEFAULT NULL
);
create unique index if not exists ps_registrations_id on ps_registrations ("id");
create index if not exists ps_registrations_ps_registrations_id on ps_registrations ("id");

--
-- Table structure for table "ps_resource_list"
--

CREATE TABLE if not exists "ps_resource_list" (
  "id" varchar(40) NOT NULL,
  "list_item" varchar(2048) DEFAULT NULL,
  "event" varchar(40) DEFAULT NULL,
  "full_state" varchar(20) DEFAULT NULL,
  "notification_batch_interval" int(11) DEFAULT NULL,
  "resource_display_name" varchar(20) DEFAULT NULL
);
create unique index if not exists ps_resource_list_id on ps_resource_list ("id");
create index if not exists ps_resource_list_ps_resource_list_id on ps_resource_list ("id");

--
-- Table structure for table "ps_subscription_persistence"
--

CREATE TABLE if not exists "ps_subscription_persistence" (
  "id" varchar(40) NOT NULL,
  "packet" varchar(2048) DEFAULT NULL,
  "src_name" varchar(128) DEFAULT NULL,
  "src_port" int(11) DEFAULT NULL,
  "transport_key" varchar(64) DEFAULT NULL,
  "local_name" varchar(128) DEFAULT NULL,
  "local_port" int(11) DEFAULT NULL,
  "cseq" int(11) DEFAULT NULL,
  "tag" varchar(128) DEFAULT NULL,
  "endpoint" varchar(40) DEFAULT NULL,
  "expires" int(11) DEFAULT NULL,
  "contact_uri" varchar(256) DEFAULT NULL,
  "prune_on_boot" varchar(20) DEFAULT NULL,
  "generator_data" text DEFAULT NULL
);
create unique index if not exists ps_subscription_persistence_id on ps_subscription_persistence ("id");
create index if not exists ps_subscription_persistence_ps_subscription_persistence_id on ps_subscription_persistence ("id");

--
-- Table structure for table "ps_systems"
--

CREATE TABLE if not exists "ps_systems" (
  "id" varchar(40) NOT NULL,
  "timer_t1" int(11) DEFAULT NULL,
  "timer_b" int(11) DEFAULT NULL,
  "compact_headers" varchar(20) DEFAULT NULL,
  "threadpool_initial_size" int(11) DEFAULT NULL,
  "threadpool_auto_increment" int(11) DEFAULT NULL,
  "threadpool_idle_timeout" int(11) DEFAULT NULL,
  "threadpool_max_size" int(11) DEFAULT NULL,
  "disable_tcp_switch" varchar(20) DEFAULT NULL,
  "follow_early_media_fork" varchar(20) DEFAULT NULL,
  "accept_multiple_sdp_answers" varchar(20) DEFAULT NULL,
  "disable_rport" varchar(20) DEFAULT NULL
);
create unique index if not exists ps_systems_id on ps_systems ("id");
create index if not exists ps_systems_ps_systems_id on ps_systems ("id");

--
-- Table structure for table "ps_transports"
--

CREATE TABLE if not exists "ps_transports" (
  "id" varchar(40) NOT NULL,
  "async_operations" int(11) DEFAULT NULL,
  "bind" varchar(40) DEFAULT NULL,
  "ca_list_file" varchar(200) DEFAULT NULL,
  "cert_file" varchar(200) DEFAULT NULL,
  "cipher" varchar(200) DEFAULT NULL,
  "domain" varchar(40) DEFAULT NULL,
  "external_media_address" varchar(40) DEFAULT NULL,
  "external_signaling_address" varchar(40) DEFAULT NULL,
  "external_signaling_port" int(11) DEFAULT NULL,
  "method" varchar(20) DEFAULT NULL,
  "local_net" varchar(40) DEFAULT NULL,
  "password" varchar(40) DEFAULT NULL,
  "priv_key_file" varchar(200) DEFAULT NULL,
  "protocol" varchar(20) DEFAULT NULL,
  "require_client_cert" varchar(20) DEFAULT NULL,
  "verify_client" varchar(20) DEFAULT NULL,
  "verify_server" varchar(20) DEFAULT NULL,
  "tos" varchar(10) DEFAULT NULL,
  "cos" int(11) DEFAULT NULL,
  "allow_reload" varchar(20) DEFAULT NULL,
  "symmetric_transport" varchar(20) DEFAULT NULL,
  "allow_wildcard_certs" varchar(20) DEFAULT NULL,
  "tcp_keepalive_enable" tinyint(1) DEFAULT NULL,
  "tcp_keepalive_idle_time" int(11) DEFAULT NULL,
  "tcp_keepalive_interval_time" int(11) DEFAULT NULL,
  "tcp_keepalive_probe_count" int(11) DEFAULT NULL
);
create unique index if not exists ps_transports_id on ps_transports ("id");
create index if not exists ps_transports_ps_transports_id on ps_transports ("id");

--
-- Table structure for table "queue_members"
--

CREATE TABLE if not exists "queue_members" (
  "queue_name" varchar(80) NOT NULL,
  "interface" varchar(80) NOT NULL,
  "membername" varchar(80) DEFAULT NULL,
  "state_interface" varchar(80) DEFAULT NULL,
  "penalty" int(11) DEFAULT NULL,
  "paused" int(11) DEFAULT NULL,
  "uniqueid" int(11) NOT NULL,
  "wrapuptime" int(11) DEFAULT NULL,
  "ringinuse" varchar(20) DEFAULT NULL,
  "reason_paused" varchar(80) DEFAULT NULL,
  PRIMARY KEY ("queue_name","interface")
);
create unique index if not exists queue_members_uniqueid on queue_members ("uniqueid");

--
-- Table structure for table "queue_rules"
--

CREATE TABLE if not exists "queue_rules" (
  "rule_name" varchar(80) NOT NULL,
  "time" varchar(32) NOT NULL,
  "min_penalty" varchar(32) NOT NULL,
  "max_penalty" varchar(32) NOT NULL
);

--
-- Table structure for table "queues"
--

CREATE TABLE if not exists "queues" (
  "name" varchar(128) NOT NULL,
  "musiconhold" varchar(128) DEFAULT NULL,
  "announce" varchar(128) DEFAULT NULL,
  "context" varchar(128) DEFAULT NULL,
  "timeout" int(11) DEFAULT NULL,
  "ringinuse" varchar(20) DEFAULT NULL,
  "setinterfacevar" varchar(20) DEFAULT NULL,
  "setqueuevar" varchar(20) DEFAULT NULL,
  "setqueueentryvar" varchar(20) DEFAULT NULL,
  "monitor_format" varchar(8) DEFAULT NULL,
  "membermacro" varchar(512) DEFAULT NULL,
  "membergosub" varchar(512) DEFAULT NULL,
  "queue_youarenext" varchar(128) DEFAULT NULL,
  "queue_thereare" varchar(128) DEFAULT NULL,
  "queue_callswaiting" varchar(128) DEFAULT NULL,
  "queue_quantity1" varchar(128) DEFAULT NULL,
  "queue_quantity2" varchar(128) DEFAULT NULL,
  "queue_holdtime" varchar(128) DEFAULT NULL,
  "queue_minutes" varchar(128) DEFAULT NULL,
  "queue_minute" varchar(128) DEFAULT NULL,
  "queue_seconds" varchar(128) DEFAULT NULL,
  "queue_thankyou" varchar(128) DEFAULT NULL,
  "queue_callerannounce" varchar(128) DEFAULT NULL,
  "queue_reporthold" varchar(128) DEFAULT NULL,
  "announce_frequency" int(11) DEFAULT NULL,
  "announce_to_first_user" varchar(20) DEFAULT NULL,
  "min_announce_frequency" int(11) DEFAULT NULL,
  "announce_round_seconds" int(11) DEFAULT NULL,
  "announce_holdtime" varchar(128) DEFAULT NULL,
  "announce_position" varchar(128) DEFAULT NULL,
  "announce_position_limit" int(11) DEFAULT NULL,
  "periodic_announce" varchar(50) DEFAULT NULL,
  "periodic_announce_frequency" int(11) DEFAULT NULL,
  "relative_periodic_announce" varchar(20) DEFAULT NULL,
  "random_periodic_announce" varchar(20) DEFAULT NULL,
  "retry" int(11) DEFAULT NULL,
  "wrapuptime" int(11) DEFAULT NULL,
  "penaltymemberslimit" int(11) DEFAULT NULL,
  "autofill" varchar(20) DEFAULT NULL,
  "monitor_type" varchar(128) DEFAULT NULL,
  "autopause" varchar(20) DEFAULT NULL,
  "autopausedelay" int(11) DEFAULT NULL,
  "autopausebusy" varchar(20) DEFAULT NULL,
  "autopauseunavail" varchar(20) DEFAULT NULL,
  "maxlen" int(11) DEFAULT NULL,
  "servicelevel" int(11) DEFAULT NULL,
  "strategy" varchar(20) DEFAULT NULL,
  "joinempty" varchar(128) DEFAULT NULL,
  "leavewhenempty" varchar(128) DEFAULT NULL,
  "reportholdtime" varchar(20) DEFAULT NULL,
  "memberdelay" int(11) DEFAULT NULL,
  "weight" int(11) DEFAULT NULL,
  "timeoutrestart" varchar(20) DEFAULT NULL,
  "defaultrule" varchar(128) DEFAULT NULL,
  "timeoutpriority" varchar(128) DEFAULT NULL,
  "log_restricted_caller_id" varchar(20) DEFAULT NULL,
  PRIMARY KEY ("name")
);

--
-- Table structure for table "sippeers"
--

CREATE TABLE if not exists "sippeers" (
  "id" int(11) NOT NULL,
  "name" varchar(40) NOT NULL,
  "ipaddr" varchar(45) DEFAULT NULL,
  "port" int(11) DEFAULT NULL,
  "regseconds" int(11) DEFAULT NULL,
  "defaultuser" varchar(40) DEFAULT NULL,
  "fullcontact" varchar(80) DEFAULT NULL,
  "regserver" varchar(20) DEFAULT NULL,
  "useragent" varchar(255) DEFAULT NULL,
  "lastms" int(11) DEFAULT NULL,
  "host" varchar(40) DEFAULT NULL,
  "type" varchar(20) DEFAULT NULL,
  "context" varchar(40) DEFAULT NULL,
  "permit" varchar(95) DEFAULT NULL,
  "deny" varchar(95) DEFAULT NULL,
  "secret" varchar(40) DEFAULT NULL,
  "md5secret" varchar(40) DEFAULT NULL,
  "remotesecret" varchar(40) DEFAULT NULL,
  "transport" varchar(20) DEFAULT NULL,
  "dtmfmode" varchar(20) DEFAULT NULL,
  "directmedia" varchar(20) DEFAULT NULL,
  "nat" varchar(29) DEFAULT NULL,
  "callgroup" varchar(40) DEFAULT NULL,
  "pickupgroup" varchar(40) DEFAULT NULL,
  "language" varchar(40) DEFAULT NULL,
  "disallow" varchar(200) DEFAULT NULL,
  "allow" varchar(200) DEFAULT NULL,
  "insecure" varchar(40) DEFAULT NULL,
  "trustrpid" varchar(20) DEFAULT NULL,
  "progressinband" varchar(20) DEFAULT NULL,
  "promiscredir" varchar(20) DEFAULT NULL,
  "useclientcode" varchar(20) DEFAULT NULL,
  "accountcode" varchar(80) DEFAULT NULL,
  "setvar" varchar(200) DEFAULT NULL,
  "callerid" varchar(40) DEFAULT NULL,
  "amaflags" varchar(40) DEFAULT NULL,
  "callcounter" varchar(20) DEFAULT NULL,
  "busylevel" int(11) DEFAULT NULL,
  "allowoverlap" varchar(20) DEFAULT NULL,
  "allowsubscribe" varchar(20) DEFAULT NULL,
  "videosupport" varchar(20) DEFAULT NULL,
  "maxcallbitrate" int(11) DEFAULT NULL,
  "rfc2833compensate" varchar(20) DEFAULT NULL,
  "mailbox" varchar(40) DEFAULT NULL,
  "session-timers" varchar(20) DEFAULT NULL,
  "session-expires" int(11) DEFAULT NULL,
  "session-minse" int(11) DEFAULT NULL,
  "session-refresher" varchar(20) DEFAULT NULL,
  "t38pt_usertpsource" varchar(40) DEFAULT NULL,
  "regexten" varchar(40) DEFAULT NULL,
  "fromdomain" varchar(40) DEFAULT NULL,
  "fromuser" varchar(40) DEFAULT NULL,
  "qualify" varchar(40) DEFAULT NULL,
  "defaultip" varchar(45) DEFAULT NULL,
  "rtptimeout" int(11) DEFAULT NULL,
  "rtpholdtimeout" int(11) DEFAULT NULL,
  "sendrpid" varchar(20) DEFAULT NULL,
  "outboundproxy" varchar(40) DEFAULT NULL,
  "callbackextension" varchar(40) DEFAULT NULL,
  "timert1" int(11) DEFAULT NULL,
  "timerb" int(11) DEFAULT NULL,
  "qualifyfreq" int(11) DEFAULT NULL,
  "constantssrc" varchar(20) DEFAULT NULL,
  "contactpermit" varchar(95) DEFAULT NULL,
  "contactdeny" varchar(95) DEFAULT NULL,
  "usereqphone" varchar(20) DEFAULT NULL,
  "textsupport" varchar(20) DEFAULT NULL,
  "faxdetect" varchar(20) DEFAULT NULL,
  "buggymwi" varchar(20) DEFAULT NULL,
  "auth" varchar(40) DEFAULT NULL,
  "fullname" varchar(40) DEFAULT NULL,
  "trunkname" varchar(40) DEFAULT NULL,
  "cid_number" varchar(40) DEFAULT NULL,
  "callingpres" varchar(20) DEFAULT NULL,
  "mohinterpret" varchar(40) DEFAULT NULL,
  "mohsuggest" varchar(40) DEFAULT NULL,
  "parkinglot" varchar(40) DEFAULT NULL,
  "hasvoicemail" varchar(20) DEFAULT NULL,
  "subscribemwi" varchar(20) DEFAULT NULL,
  "vmexten" varchar(40) DEFAULT NULL,
  "autoframing" varchar(20) DEFAULT NULL,
  "rtpkeepalive" int(11) DEFAULT NULL,
  "call-limit" int(11) DEFAULT NULL,
  "g726nonstandard" varchar(20) DEFAULT NULL,
  "ignoresdpversion" varchar(20) DEFAULT NULL,
  "allowtransfer" varchar(20) DEFAULT NULL,
  "dynamic" varchar(20) DEFAULT NULL,
  "path" varchar(256) DEFAULT NULL,
  "supportpath" varchar(20) DEFAULT NULL,
  PRIMARY KEY ("id")
);
create unique index if not exists sippeers_name on sippeers ("name");
create index if not exists sippeers_sippeers_name on sippeers ("name");
create index if not exists sippeers_sippeers_name_host on sippeers ("name","host");
create index if not exists sippeers_sippeers_ipaddr_port on sippeers ("ipaddr","port");
create index if not exists sippeers_sippeers_host_port on sippeers ("host","port");

--
-- Table structure for table "stir_tn"
--

CREATE TABLE if not exists "stir_tn" (
  "id" varchar(80) NOT NULL,
  "private_key_file" varchar(1024) DEFAULT NULL,
  "public_cert_url" varchar(1024) DEFAULT NULL,
  "attest_level" varchar(1) DEFAULT NULL,
  "send_mky" varchar(20) DEFAULT NULL,
  PRIMARY KEY ("id")
);

--
-- Table structure for table "voicemail"
--

CREATE TABLE if not exists "voicemail" (
  "uniqueid" int(11) NOT NULL,
  "context" varchar(80) NOT NULL,
  "mailbox" varchar(80) NOT NULL,
  "password" varchar(80) NOT NULL,
  "fullname" varchar(80) DEFAULT NULL,
  "alias" varchar(80) DEFAULT NULL,
  "email" varchar(80) DEFAULT NULL,
  "pager" varchar(80) DEFAULT NULL,
  "attach" varchar(20) DEFAULT NULL,
  "attachfmt" varchar(10) DEFAULT NULL,
  "serveremail" varchar(80) DEFAULT NULL,
  "language" varchar(20) DEFAULT NULL,
  "tz" varchar(30) DEFAULT NULL,
  "deletevoicemail" varchar(20) DEFAULT NULL,
  "saycid" varchar(20) DEFAULT NULL,
  "sendvoicemail" varchar(20) DEFAULT NULL,
  "review" varchar(20) DEFAULT NULL,
  "tempgreetwarn" varchar(20) DEFAULT NULL,
  "operator" varchar(20) DEFAULT NULL,
  "envelope" varchar(20) DEFAULT NULL,
  "sayduration" int(11) DEFAULT NULL,
  "forcename" varchar(20) DEFAULT NULL,
  "forcegreetings" varchar(20) DEFAULT NULL,
  "callback" varchar(80) DEFAULT NULL,
  "dialout" varchar(80) DEFAULT NULL,
  "exitcontext" varchar(80) DEFAULT NULL,
  "maxmsg" int(11) DEFAULT NULL,
  "volgain" decimal(5,2) DEFAULT NULL,
  "imapuser" varchar(80) DEFAULT NULL,
  "imappassword" varchar(80) DEFAULT NULL,
  "imapserver" varchar(80) DEFAULT NULL,
  "imapport" varchar(8) DEFAULT NULL,
  "imapflags" varchar(80) DEFAULT NULL,
  "stamp" datetime DEFAULT NULL,
  PRIMARY KEY ("uniqueid")
);
create index if not exists voicemail_voicemail_mailbox on voicemail ("mailbox");
create index if not exists voicemail_voicemail_context on voicemail ("context");
create index if not exists voicemail_voicemail_mailbox_context on voicemail ("mailbox","context");
create index if not exists voicemail_voicemail_imapuser on voicemail ("imapuser");

--
-- Dump completed on 2025-10-15 17:10:11

