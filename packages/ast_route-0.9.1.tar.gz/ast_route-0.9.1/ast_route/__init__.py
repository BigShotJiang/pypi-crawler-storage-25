# everybody needs these
from __future__ import annotations

import logging
import logging.config
import sys

from . import log as log  # noqa:PLC0414  # ruff bug *sigh*
from ._main import ConfigError as ConfigError  #noqa:PLC0414
from ._main import Router as Router  #noqa:PLC0414

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {"format": "%(levelname)s %(module)s %(message)s"},
    },
    "handlers": {
        "syslog": {
            "class": "logging.handlers.SysLogHandler",
            "address": "/dev/log",
            "formatter": "verbose",
        },
        "stderr": {
            "class": "logging.StreamHandler",
            "stream": sys.stderr,
            "formatter": "verbose",
            "level": logging.DEBUG,
        },
    },
    "root": {
        "handlers": ["syslog"],  # 'stderr',
        "level": logging.DEBUG,
        "propagate": True,
    },
}

logging.config.dictConfig(LOGGING)
