from __future__ import annotations

import sys

from ast_route._main import ConfigError, Router
from ast_route.config import Cfg

import asyncclick as click
import trio


@click.command
@click.option("-c", "--config", type=click.Path(dir_okay=False), help="config file")
@click.option("-s", "--secret", type=click.Path(dir_okay=False), help="file with secrets")
@click.option("-m", "--mode", type=str, help="daemon, zoom, …", default="daemon")
async def main(config, secret, mode):
    """
    Run the routing server and whatnot.
    """

    args = {}
    if config:
        args["cfg"] = config
    if secret:
        args["secret"] = secret
    try:
        cfg = Cfg(**args)
    except ConfigError as exc:
        print(f"Config: {exc}", file=sys.stderr)
        sys.exit(1)

    rt = Router(cfg, mode)
    await rt.main()


if __name__ == "__main__":
    trio.run(main.main)
