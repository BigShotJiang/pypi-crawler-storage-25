from __future__ import annotations

import trio
from hypercorn.config import Config as HyperConfig
from hypercorn.trio import serve
from quart_trio.app import QuartTrio as _QuartTrio

from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable, Coroutine


class ResultD(TypedDict):
    "result for curl"

    a_nr: str  # caller ID in SIP From
    b_nr: str  # destination in SIP To
    p_nr: str  # caller ID in P-Preferred-Identity
    chan: str  # PJSIP, Local, …  default PJSIP
    end: str  # SIP endpoint, context, …


class ErrorD(TypedDict):
    "broken result for curl"
    hangup: str



class QuartTrio(_QuartTrio):
    "QuartTrio specialization that uses Hypercorn to run a server."

    def run_task(
        self,
        host: str = "127.0.0.1",
        port: int = 5000,
        debug: bool | None = None,
        ca_certs: str | None = None,
        certfile: str | None = None,
        keyfile: str | None = None,
        shutdown_trigger: Callable[..., Awaitable[None]] | None = None,
        task_status: trio.TaskStatus = trio.TASK_STATUS_IGNORED,
    ) -> Coroutine[None, None, None]:
        """Return a task that when awaited runs this application.

        This is best used for development only, see Hypercorn for
        production servers.

        Arguments:
            host: Hostname to listen on. By default this is loopback
                only, use 0.0.0.0 to have the server listen externally.
            port: Port number to listen on.
            debug: If set enable (or disable) debug mode and debug output.
            ca_certs: Path to the SSL CA certificate file.
            certfile: Path to the SSL certificate file.
            keyfile: Path to the SSL key file.

        """
        config = HyperConfig()
        config.access_log_format = "%(h)s %(r)s %(s)s %(b)s %(D)s"
        config.accesslog = "-"
        config.bind = [f"{host}:{port}"]
        config.ca_certs = ca_certs
        config.certfile = certfile
        if debug is not None:
            config.debug = debug
        config.errorlog = config.accesslog
        config.keyfile = keyfile

        return serve(self, config, shutdown_trigger=shutdown_trigger, task_status=task_status)

def srepr(x, bare=False):
    "short repr of possibly-complex objects"
    if isinstance(x, set):
        if not x:
            return "∅"
        else:
            return "⊕".join(srepr(v) for v in x)
    if isinstance(x, tuple):
        if bare:
            return ",".join(srepr(v) for v in x)
        return "(" + ",".join(srepr(v) for v in x) + ")"
    if isinstance(x, list):
        if bare:
            return ",".join(srepr(v) for v in x)
        return "[" + ",".join(srepr(v) for v in x) + "]"
    if isinstance(x, dict):
        if bare:
            return ",".join(_drepr(k, v) for k, v in x.items())
        return "{" + ",".join(_drepr(k, v) for k, v in x.items()) + "}"
    return str(x)

def _drepr(k, v):
    k = str(k)
    if v is None:
        return "?" + k
    if v is False:
        return "!" + k
    if v is True:
        return k
    return f"{k}={srepr(v)}"
