"""
PJSIP dynamic data integration
"""

from __future__ import annotations

from ._redirect import RedirectProvider as Provider  # noqa:F401 pylint:disable=W0611
