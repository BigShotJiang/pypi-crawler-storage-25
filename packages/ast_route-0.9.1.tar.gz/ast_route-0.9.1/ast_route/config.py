"""
Config file analysis

The configuration is a YAML file::

    # Emergency numbers are always passed on 1:1, i.e. they are NOT
    # prefixed with an area code, interpreted as direct-dial-in, or
    # similar mangling.
    emergency:
    - "110"
    - "112"
    - "19222"

    # local data
    self:
      domain: example.net
      country: "49"
      city: "69"
      prefix: "90009"
      default: "49911900090"

    # The built-in web server. It also does phone# routing.
    app_server:
      # host: localhost
      port: 50080

    # The global pre-route table should only be used for emergency numbers.
    # Match them all by using "*" as the pattern.
    pre-route:
    - match: "*"
      result: "$1"  # use provider's format_out if empty
      dest: "pbx"

    route:
    - match: "496990009([0-2]*)"
      result: "90009$2"
      use: known
      dest: zoom

    - match: "496990009([0-2]*)"
      result: "90009$2"
      dest: pbx

    - match: "0{0,2}[1-9]{5,}"
      dest: landline

    provider:
      landline:
        # No emergency calls may arrive from here
        emergency: []
        pre-route: []
        #
        a_in: null
        b_in: null
        a_out: null
        b_out: null

        # the route is applied to untranslated B numbers of calls from this provider
        route:
        - match: "49(.*)"
          result: "49$1"  # use format_in if empty
          dest: zoom
          # if dest is given the number must be formatted for it
          # otherwise the result must be bare; route lookup will call format_out

        # Otherwise uses
        # - the setting of b_in to adapt the number, if no match
        # - the route: list to find the destination, if no dest
        # - b_out to format it, if no explicit result

      zoom:
        type: zoom

        # other options for a second provider
        # The filter applies to incoming destination numbers

        a_in: false
        b_in: true
        a_out: null
        b_out: false

      pbx:
        a_in:
        - match: "([0-9]{,3})"
          pattern: "90009$1"
        - null

        route:
        - match: "000(.*)"
          # force-forward-to-zoom by using three leading zeroes
          # this is an annoying hack, but if the PBX doesn't
          # understand anything else, well …
          result: "$1"
          dest: "zoom"  # use route table if empty

Internally phone numbers always are in 49911… format.
"""

from __future__ import annotations

import logging
from importlib import import_module
from pathlib import Path

import trio
import yaml

from ._util import ErrorD, ResultD, srepr
from .provider import Provider
from .rule import Reject, RoutingRule

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import io


logger = logging.getLogger("cfg")

k_global = ("emergency", "self", "app_server")

class SecretLoader(yaml.SafeLoader):  # pylint:disable=too-many-ancestors
    "A loader that understands !secret YAML elements"

    def __init__(self, secret, stream):
        self.secret = secret
        super().__init__(stream)


def load_secret(loader, node):
    "An accessor for loading secrets"
    v = loader.secret
    for k in node.value.split("."):
        v = v[k]
    return v


SecretLoader.add_constructor("!secret", load_secret)


class Cfg:
    "Global configuration"

    def __init__(
        self,
        cfg="/etc/asterisk/routing.yaml",
        secret="/etc/asterisk/secrets.yaml",  # noqa:S107
        test_load=False,
    ):
        self.f_cfg = Path(cfg)
        self.f_secret = Path(secret)
        self.t_chg = max(self.f_cfg.stat().st_mtime, self.f_secret.stat().st_mtime) + 0.1

        with open(secret) as f:
            sec = yaml.SafeLoader(f).get_single_data()

        with open(cfg) as f:
            self.cfg = SecretLoader(sec, f).get_single_data()

        if test_load:
            return

        for k in k_global:
            setattr(self, k, self.cfg[k])
        self.pre_routes = []
        self.routes = []

        for m in self.cfg.get("pre-route", ()):
            self.pre_routes.append(m)

        for m in self.cfg.get("route", ()):
            self.routes.append(m)

        self.provider = self.cfg.setdefault("provider", {})

        for k, pd in self.provider.items():
            for kk, v in self.cfg["self"].items():
                pd.setdefault(kk, v)

            try:
                pn = pd.pop("type")
            except KeyError:
                PT = Provider
            else:
                if "." not in pn:
                    pn = f"ast_route.{pn}"
                PT = import_module(pn).Provider

            # 'pre-route' is not a valid Python identifier
            for kk in list(pd.keys()):
                if "-" in kk:
                    pd[kk.replace("-", "_")] = pd.pop(kk)
            self.provider[k] = PT(name=k, **pd)

        self.pre_routes = [RoutingRule(self, **x) for x in self.pre_routes]
        self.routes = [RoutingRule(self, **x) for x in self.routes]
        for pd in self.provider.values():
            pd.pre_routes = [RoutingRule(self, **x) for x in pd.pre_routes]
            pd.routes = [RoutingRule(self, **x) for x in pd.routes]
            if pd.fallback is not None:
                pd.fallback = self.provider[pd.fallback]

    def reload(self) -> Cfg:
        "Returns a new instance of itself"
        return type(self)(self.f_cfg, self.f_secret)

    def is_changed(self) -> bool:
        "check for config file updates"
        return self.t_chg < max(self.f_cfg.stat().st_mtime, self.f_secret.stat().st_mtime)

    def __getitem__(self, k):
        return self.cfg[k]

    def route(
        self, src: Provider, snr: str, dnr: str, out: io.StringIO
    ) -> ResultD|ErrorD:
        """Translate A+B number+provider from source to destination.

        Routing algorithm (B number):
        * Apply the pre-route table.
          If the source doesn't have a pre-route, use the global table.
        * Apply the source's route table if it exists.
          A match without a destination uses the global table.
        * If no match:
          * Canonicalize the number per the source's rules.
          * Apply the global route table if the source table didn't match.
        * If source and destination are the same and the source has a
          fallback, use that instead.
        * Rewrite the number for the destination.
        * Apply source and destination rewrite rules to the A number.

        As an important exception to the above, emergency destinations are
        never rewritten.

        The return value is a `ResultD`.
        """
        nsnr = src.format_a_in(snr)
        print(f"A In: {snr} → {nsnr}", file=out)
        ndnr = None
        data = {}

        for m in src.pre_routes or ():
            res = m.match(snr, dnr)
            if res is not None:
                print(f"B Pre {m}: {srepr(res)}", file=out)
                data.update(res)

        # If no pre-route rule applied, try source-specific rules.
        if "dest" not in data:
            res = src.route(snr, dnr)
            if res is not None:
                data.update(res)

        if "b_nr" not in data:
            data["b_nr"] = src.format_b_in(dnr)
            print(f"B In: {dnr} → {data['b_nr']}", file=out)

        fdnr = None
        ndnr = data.pop("b_nr")

        if "dest" not in data:
            for m in self.routes:
                res = m.match(nsnr, ndnr)
                if res is not None:
                    print(f"B Match {m}: {srepr(res)}", file=out)
                    data.update(res)
                    ndnr = data.get("b_nr",ndnr)
                    if data.get("dest") is not None:
                        break

            else:
                # no match at all.
                print(f"B NoMatch: {src.name}:{ndnr}", file=out)
                logger.debug("ROUTE %s %r → ?", dnr, src.name)
                raise Reject("notfound")

        dst = data.pop("dest")
        if dst is None:
            raise Reject("notfound")

        if src is dst and dst.fallback:
            print(f"Fallback: {dst} → {dst.fallback}", file=out)
            dst = dst.fallback

        if "b_nr" not in data:
            # Use the provider's output rule if no pattern matched
            fdnr = dst.format_b_out(ndnr, dst.b_out)
            if fdnr != ndnr:
                print(f"B Dst: {ndnr} → {fdnr}", file=out)
            data["b_nr"] = fdnr

        fsnr = dst.format_a_out(nsnr, dst.a_out)
        fpnr = dst.format_a_out(nsnr, dst.p_out)
        if fsnr != nsnr:
            print(f"A Dst: {nsnr} → {fsnr}", file=out)

        data.setdefault("a_nr", fsnr)
        data.setdefault("p_nr", fpnr)
        data.setdefault("b_nr", fdnr)
        data.setdefault("chan", dst.channel)
        data.setdefault("end", dst.endpoint or dst.name)

        logger.debug("ROUTE %r %r %r ⇒ %s", snr, src.name, dnr, srepr(data))
        return data

    async def run(self, *, task_status=trio.TASK_STATUS_IGNORED):
        async def _run(prov, *, task_status=None):
            await prov.setup(self)
            if task_status is not None:
                task_status.started()
            await prov.run(self)

        async with trio.open_nursery() as n:
            for prov in self.provider.values():
                await n.start(_run, prov)
            task_status.started()
            await trio.sleep_forever()
