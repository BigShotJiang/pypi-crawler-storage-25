"""
PJSIP dynamic call distro integration
"""

from __future__ import annotations

from ._group import GroupProvider as Provider  # noqa:F401 pylint:disable=W0611
