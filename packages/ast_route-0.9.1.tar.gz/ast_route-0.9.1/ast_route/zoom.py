"""
Zoom integration
"""

from __future__ import annotations

from ._zoom import ZoomProvider as Provider  # noqa:F401 pylint:disable=W0611
