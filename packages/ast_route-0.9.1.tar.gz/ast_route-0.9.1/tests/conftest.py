"""
Fixtures
"""

from __future__ import annotations

import pytest


@pytest.fixture
def anyio_backend():  # pylint:disable=missing-function-docstring
    return "trio"
