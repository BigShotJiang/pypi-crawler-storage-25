from __future__ import annotations

import io
import pytest

from ast_route import Router
from ast_route.config import Cfg

import trio
from httpx import AsyncClient as Client

# config says:
#          pa    pb    pc
# a_in    null  false true
# b_in    false true  null
# a_out   true  null  false
# b_out   true  false null

_tests = [
    (
        "anonymous:12345:pa",
        dict(a_nr="0098765", b_nr="1212345", p_nr="98765", end="pb"),
    ),
    (
        "anonymous:4991112345678:pa",
        dict(a_nr="98765", b_nr="+49123456", p_nr="98765", end="pc"),
    ),
    (
        "733445:+245678:pb",
        dict(a_nr="+733445", b_nr="+245678", p_nr="733445", end="pa"),
    ),
    (
        "727272:+235678:pb",
        dict(a_nr="+727272", b_nr="+345678", p_nr="727272", end="pa"),
    ),
    (
        "545454:55555:pa",
        dict(a_nr="49911545454", b_nr="0067555589", p_nr="49911545454", end="pc"),
    ),
    (
        "032198765:65554:pa",
        dict(a_nr="4932198765", b_nr="0065554", p_nr="4932198765", end="pc"),
    ),
    (
        "+4932198765:65554:pa",
        dict(a_nr="4932198765", b_nr="0065554", p_nr="4932198765", end="pc"),
    ),
    (
        "+545454:00123987:pc",
        dict(a_nr="00545454", b_nr="12123987", p_nr="545454", end="pb"),
    ),
]


def test_bad():
    "broken config"
    from ast_route._main import ConfigError  # pylint:disable=import-outside-toplevel

    with pytest.raises(ConfigError):
        Cfg("tests/test_cfg_bad.yaml", "/dev/null")


@pytest.mark.anyio
async def test_basic():
    "basic config"
    c = Cfg("tests/test_cfg.yaml", "/dev/null")
    async with trio.open_nursery() as n:
        await n.start(c.run)
        await trio.sleep(1)

        for sd in _tests:
            s, d = sd
            sa, sb, sp = s.split(":")
            sp = c.provider[sp]

            out = io.StringIO()
            r = c.route(sp, sa, sb, out=out)
            assert r.pop("chan") == "PJSIP"

            assert d == r, (sd, out.getvalue())
        n.cancel_scope.cancel()


@pytest.mark.anyio
async def test_router():
    "routing test"
    m = Router(Cfg("tests/test_cfg.yaml", "/dev/null"))

    async with trio.open_nursery() as n:
        await n.start(m.main)

        cl = Client()

        for sd in _tests:
            s, d = sd
            sa, sb, sp = s.split(":")

            res = await cl.get(f"http://localhost:{m.cfg.app_server['port']}/route/{sp}:{sa}:{sb}")
            r = {}
            for x in res.text.strip().split(":"):
                k,v = x.split("=",1)
                r[k]=v
            assert r.pop("chan") == "PJSIP"
            assert d == r, sd

        res = await cl.get(f"http://localhost:{m.cfg.app_server['port']}/status")

        n.cancel_scope.cancel()
