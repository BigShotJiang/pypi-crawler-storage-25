from _typeshed import Incomplete
from functools import cached_property
from gllm_core.retry import RetryConfig
from gllm_inference.constants import GRPC_ENABLE_RETRIES_KEY as GRPC_ENABLE_RETRIES_KEY, INVOKER_PROPAGATED_MAX_RETRIES as INVOKER_PROPAGATED_MAX_RETRIES
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.lm_invoker.mixin import StreamingBufferMixin as StreamingBufferMixin
from gllm_inference.lm_invoker.operations.file_operations import XAIFileOperations as XAIFileOperations
from gllm_inference.lm_invoker.schema.xai import InputType as InputType, Key as Key
from gllm_inference.output_transformer.output_transformer import BaseOutputTransformer as BaseOutputTransformer
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, ContextWindow as ContextWindow, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMTool as LMTool, Message as Message, MessageRole as MessageRole, ModelId as ModelId, ModelProvider as ModelProvider, NativeTool as NativeTool, NativeToolType as NativeToolType, OutputTransformerType as OutputTransformerType, ResponseEvent as ResponseEvent, ResponseSchema as ResponseSchema, StreamBuffer as StreamBuffer, StreamBufferType as StreamBufferType, Thinking as Thinking, ThinkingConfig as ThinkingConfig, ThinkingEvent as ThinkingEvent, TokenUsage as TokenUsage, ToolCall as ToolCall, ToolResult as ToolResult, URLAttachment as URLAttachment, UploadedAttachment as UploadedAttachment
from typing import Any

IMAGE_GENERATION_MODEL_SUBSTRING: str
DEFAULT_IMAGE_RESPONSE_FORMAT: str

class XAILMInvoker(StreamingBufferMixin, BaseLMInvoker):
    '''A language model invoker to interact with xAI language models.

    Examples:
        ```python
        lm_invoker = XAILMInvoker(model_name="grok-4-fast-non-reasoning")
        result = await lm_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Image
        5. Structured output
        6. Tool calling
        7. Native tools
           a. Web search
           b. Image generation
        8. Thinking
        9. Output analytics
        10. Retry and timeout
        11. Extra capabilities
           a. Input transformer
           b. Output transformer
           c. File management

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        client_params (dict[str, Any]): The xAI client initialization parameters.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): The list of tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig | None): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        image_generation (bool): Whether to enable image generation.
        input_transformer (InputTransformerType): The type of input transformer to use.
        output_transformer (OutputTransformerType): The type of output transformer to use.
    '''
    image_generation: Incomplete
    client_params: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, thinking: bool | ThinkingConfig = False, input_transformer: InputTransformerType = ..., output_transformer: OutputTransformerType = ...) -> None:
        """Initializes a new instance of the XAILMInvoker class.

        Args:
            model_name (str): The name of the xAI model.
            api_key (str | None, optional): The API key for authenticating with xAI. Defaults to None, in which
                case the `XAI_API_KEY` environment variable will be used.
            model_kwargs (dict[str, Any] | None, optional): Additional model parameters. Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            tools (list[LMTool] | None, optional): Tools provided to the language model to enable tool calling.
                Defaults to None.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout is used.
            thinking (bool | ThinkingConfig, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to False.
            input_transformer (InputTransformerType, optional): The type of input transformer to use.
                Defaults to InputTransformerType.IDENTITY, which returns the input without transformation.
            output_transformer (OutputTransformerType, optional): The type of output transformer to use.
                Defaults to OutputTransformerType.IDENTITY, which returns the output without transformation.
        """
    @cached_property
    def file(self) -> XAIFileOperations:
        """The file operations for the language model.

        Returns:
            XAIFileOperations: The file operations for the language model.
        """
