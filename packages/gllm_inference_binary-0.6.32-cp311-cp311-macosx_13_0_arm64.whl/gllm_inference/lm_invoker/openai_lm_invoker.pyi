from _typeshed import Incomplete
from functools import cached_property
from gllm_core.retry import RetryConfig
from gllm_inference.constants import DOCUMENT_MIME_TYPES as DOCUMENT_MIME_TYPES, INVOKER_PROPAGATED_MAX_RETRIES as INVOKER_PROPAGATED_MAX_RETRIES, OPENAI_DEFAULT_URL as OPENAI_DEFAULT_URL
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.lm_invoker.operations.batch_operations import OpenAIBatchOperations as OpenAIBatchOperations
from gllm_inference.lm_invoker.operations.data_store_operations import OpenAIDataStoreOperations as OpenAIDataStoreOperations
from gllm_inference.lm_invoker.operations.file_operations import OpenAIFileOperations as OpenAIFileOperations
from gllm_inference.lm_invoker.schema.openai import InputType as InputType, Key as Key, OutputType as OutputType
from gllm_inference.output_transformer.output_transformer import BaseOutputTransformer as BaseOutputTransformer
from gllm_inference.schema import Activity as Activity, ActivityEvent as ActivityEvent, ActivityType as ActivityType, Attachment as Attachment, AttachmentStore as AttachmentStore, AttachmentType as AttachmentType, CodeEvent as CodeEvent, CodeExecResult as CodeExecResult, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMTool as LMTool, MCPCall as MCPCall, Message as Message, MessageRole as MessageRole, ModelId as ModelId, ModelProvider as ModelProvider, NativeTool as NativeTool, NativeToolType as NativeToolType, OAuthCredentials as OAuthCredentials, OutputTransformerType as OutputTransformerType, ResponseEvent as ResponseEvent, ResponseSchema as ResponseSchema, Thinking as Thinking, ThinkingConfig as ThinkingConfig, ThinkingEvent as ThinkingEvent, TokenUsage as TokenUsage, ToolCall as ToolCall, ToolResult as ToolResult, URLAttachment as URLAttachment, UploadedAttachment as UploadedAttachment
from typing import Any, Awaitable, Callable

STREAM_DATA_START_TYPE_MAP: Incomplete
STREAM_DATA_CONTENT_TYPE_MAP: Incomplete
STREAM_DATA_END_TYPE_MAP: Incomplete
MCP_TOOL_KEY_MAP: Incomplete
OutputHooks = Callable[[Any, LMOutput], None]
StreamingHooks = Callable[[Any, BaseOutputTransformer], Awaitable[None]]

class OpenAILMInvoker(BaseLMInvoker):
    '''A language model invoker to interact with OpenAI language models.

    This class provides support for OpenAI\'s Responses API schema, which is recommended by OpenAI as the preferred API
    to use whenever possible. Use this class unless you have a specific reason to use the Chat Completions API instead.
    The Chat Completions API schema is supported through the `OpenAIChatCompletionsLMInvoker` class.

    Examples:
        ```python
        lm_invoker = OpenAILMInvoker(model_name="gpt-5-nano")
        result = await lm_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Document
           c. Image
        5. Structured output
        6. Tool calling
        7. Native tools
           a. Code interpreter
           b. Data store
           c. Image generation
           d. MCP connector
           e. MCP server
           f. Web search
        8. Thinking
        9. Output analytics
        10. Retry and timeout
        11. Extra capabilities
           a. Input transformer
           b. Output transformer
           c. Batch invocation
           d. File management
           e. Data store management
           f. [BETA] Custom output hooks & streaming hooks

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    OpenAI compatible endpoints:
        This class can interact with endpoints compatible with OpenAI\'s Responses API schema
        (e.g. SGLang: https://github.com/sgl-project/sglang). To do this, simply set `base_url` to the endpoint URL.
        Supported features may vary between endpoints. Unsupported features will result in an error.

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        client_kwargs (dict[str, Any]): The keyword arguments for the OpenAI client.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): The list of tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        image_generation (bool): Whether to enable image generation.
        data_stores (list[AttachmentStore]): The data stores to retrieve internal knowledge from.
        input_transformer (InputTransformerType): The type of input transformer to use.
        output_transformer (OutputTransformerType): The type of output transformer to use.
    '''
    client_kwargs: Incomplete
    def __init__(self, model_name: str, api_key: str | None = None, base_url: str = ..., model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, thinking: bool | ThinkingConfig = False, image_generation: bool = False, data_stores: list[AttachmentStore] | None = None, input_transformer: InputTransformerType = ..., output_transformer: OutputTransformerType = ..., output_hooks: list[OutputHooks] | None = None, streaming_hooks: list[StreamingHooks] | None = None) -> None:
        '''Initializes a new instance of the OpenAILMInvoker class.

        Args:
            model_name (str): The name of the OpenAI model.
            api_key (str | None, optional): The API key for authenticating with OpenAI. Defaults to None, in which
                case the `OPENAI_API_KEY` environment variable will be used. If the endpoint does not require an
                API key, a dummy value can be passed (e.g. "<empty>").
            base_url (str, optional): The base URL of a custom endpoint that is compatible with OpenAI\'s
                Responses API schema. Defaults to OpenAI\'s default URL.
            model_kwargs (dict[str, Any] | None, optional): Additional model parameters. Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None, in which case an empty list is used.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            thinking (bool | ThinkingConfig, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to False.
            image_generation (bool, optional): Whether to enable image generation. Defaults to False.
            data_stores (list[AttachmentStore] | None, optional): The data stores to retrieve internal knowledge from.
                Defaults to None, in which case no data stores will be used.
            input_transformer (InputTransformerType, optional): The type of input transformer to use.
                Defaults to InputTransformerType.IDENTITY, which returns the input without transformation.
            output_transformer (OutputTransformerType, optional): The type of output transformer to use.
                Defaults to OutputTransformerType.IDENTITY, which returns the output without transformation.

            output_hooks (list[OutputHooks] | None, optional): [BETA] Custom standard output processing hooks.
                Defaults to None, in which case no output hooks will be used.
            streaming_hooks (list[StreamingHooks] | None, optional): [BETA] Custom streaming output processing hooks.
                Defaults to None, in which case no streaming hooks will be used.
        '''
    @cached_property
    def batch(self) -> OpenAIBatchOperations:
        """The batch operations for the language model.

        Returns:
            OpenAIBatchOperations: The batch operations for the language model.
        """
    @cached_property
    def file(self) -> OpenAIFileOperations:
        """The file operations for the language model.

        Returns:
            OpenAIFileOperations: The file operations for the language model.
        """
    @cached_property
    def data_store(self) -> OpenAIDataStoreOperations:
        """The data store operations for the language model.

        Returns:
            OpenAIDataStoreOperations: The data store operations for the language model.
        """
    data_stores: Incomplete
    native_tools: Incomplete
    def set_data_stores(self, data_stores: list[AttachmentStore]) -> None:
        """Sets the data stores for the OpenAI language model.

        This method sets the data stores for the OpenAI language model. Any existing data stores will be replaced.

        Args:
            data_stores (list[AttachmentStore]): The list of data stores to be used.
        """
