"""
Copilot tools — delegate coding/review tasks to GitHub Copilot CLI.

Tools
-----
  github_copilot  Submit a task (background or wait mode).
  github_copilot_status    Query task status / list all tasks.
  github_copilot_models    List available models with context limits and billing.

All three share a singleton CopilotDelegateService which owns one gh copilot
CLI process (via github-copilot-sdk JSON-RPC) for the lifetime of the Runtime.
"""

from __future__ import annotations

import asyncio
import re
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.agent.tools._delegate_notify import (
    NotifyTarget,
    deliver_background_completion,
)
from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import ChannelType
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore

# Conservative Copilot agent name pattern. Allows a leading letter/digit
# followed by letters, digits, underscore, dot, hyphen. Max 64 chars. Excludes
# whitespace and other chars that could produce a malformed @mention or inject
# extra content ahead of the task header.
_AGENT_NAME_RE: re.Pattern[str] = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]{0,63}$")


def _normalize_agent(raw: str | None) -> str | None:
    """Strip whitespace and a single leading '@' from an agent name.

    Returns ``None`` for empty input. Does not validate; pair with
    ``_AGENT_NAME_RE`` to reject invalid forms with a clear error.
    """
    if raw is None:
        return None
    value = raw.strip()
    if value.startswith("@"):
        value = value[1:].strip()
    return value or None


# ── Shared risk assessment for delegate tools (Copilot / Claude Code) ────────

_DELEGATE_FACTORS = (
    "4: Small scoped change, few files, wait mode",
    "5: Moderate change, clear scope",
    "6: Broad change, background mode, or touches config",
    "7: Large scope, modifies CI/CD, or no file restriction",
)


def _assess_delegate_risk(name: str, args: dict[str, Any]) -> RiskAssessment:
    """Shared assess_risk logic for Copilot and Claude Code delegate tools."""
    task_type = (args.get("task_type", "code") or "code").strip()
    mode = (args.get("mode", "background") or "background").strip()
    files = args.get("files") or []

    # Deterministic task types
    _TASK_SCORES: dict[str, tuple[int, str]] = {
        "review": (3, f"{name} review (code analysis)"),
        "research": (3, f"{name} research (read-focused analysis)"),
        "test": (4, f"{name} test (writes test files, may run tests)"),
    }
    entry = _TASK_SCORES.get(task_type)
    if entry:
        base, reason = entry
        # Background +1 only for low-risk tasks (review/research)
        if mode == "background" and base < 4:
            base += 1
        return RiskScore(min(base, 9), reason=reason)

    # code / unknown — LLM
    return RiskPrompt(
        context=(
            f"{name} {task_type} task — autonomous code changes.\n"
            f"Mode: {mode}, files: {files or 'any'}"
        ),
        range=(4, 7),
        factors=_DELEGATE_FACTORS,
    )


if TYPE_CHECKING:
    from workpilot.channels.manager import ChannelManager
    from workpilot.config.schema import CopilotToolConfig


# ── Task state ────────────────────────────────────────────────────────────────


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class CopilotTask:
    task_id: str
    task: str
    task_type: str
    status: TaskStatus = TaskStatus.PENDING
    result: str = ""
    error: str = ""
    notify_channel: ChannelType = ChannelType.CLI
    notify_channel_id: str = ""
    notify_thread_id: str | None = None
    # Originating session — propagated to the OutboundMessage on completion
    # so AgentLoop._capture_for_persist can persist the result into the
    # user's session JSONL. Lets a browser refresh preserve the delegate
    # completion (the push queue only delivers once).
    notify_session_id: str = ""
    asyncio_task: asyncio.Task | None = field(default=None, repr=False)
    # Per-task preference for the SDK permission handler. ``None`` defers to
    # ``CopilotHooksConfig.auto_approve`` from config. ``True`` requests
    # approval of grey-area requests and ``False`` requests denial — but
    # ``tools.copilot.hooks.auto_approve`` is a hard ceiling: when config is
    # ``False`` a per-task ``True`` still resolves to deny (LLM-authored args
    # cannot loosen an operator's strict policy). Per-task can only TIGHTEN.
    # Either way, the Copilot CLI applies the user's own ``~/.copilot/``
    # allow/deny rules first — this only controls what happens when the CLI
    # has to ask.
    auto_approve: bool | None = None


# ── Service ───────────────────────────────────────────────────────────────────


class CopilotDelegateService:
    """Singleton service managing the Copilot SDK client and task registry."""

    _TASK_TYPE_PROMPTS: dict[str, str] = {
        "code": (
            "Implement the following task. Write clean, minimal code. "
            "Only change what is necessary. Run tests when applicable."
        ),
        "review": (
            "Review the following code or task. Identify bugs, security issues, "
            "performance problems, and style violations. Be concise and actionable."
        ),
        "test": (
            "Write tests for the following task. Use the existing test framework "
            "and conventions in the codebase."
        ),
        "refactor": (
            "Refactor the following code. Keep behaviour identical. "
            "Improve readability, reduce duplication, and simplify where possible."
        ),
    }

    def __init__(
        self,
        workspace: Path,
        bus: MessageBus,
        config: CopilotToolConfig,
        github_token: str | None = None,
        channel_manager: ChannelManager | None = None,
    ) -> None:
        self._workspace = workspace
        self._bus = bus
        self._config = config
        self._github_token = github_token
        self._channel_manager = channel_manager
        self._tasks: dict[str, CopilotTask] = {}
        self._client: Any | None = None
        self._client_lock = asyncio.Lock()
        self._started = False
        self._semaphore = asyncio.Semaphore(config.max_concurrent)

    # ── Client lifecycle ──────────────────────────────────────────────────────

    async def _get_client(self) -> Any:
        """Return (or lazily start) the shared CopilotClient."""
        async with self._client_lock:
            if self._started:
                return self._client
            try:
                from copilot import CopilotClient  # type: ignore[import]
                from copilot.client import SubprocessConfig  # type: ignore[import,attr-defined]
            except ImportError:
                raise RuntimeError(
                    "github-copilot-sdk not installed or too old. "
                    "Install/upgrade: pip install -U 'github-copilot-sdk>=0.2'"
                )

            # Name the local clearly so logs/debugging don't confuse it with
            # the tool-level ``self._config`` (CopilotToolConfig).
            subprocess_config = SubprocessConfig(
                cwd=str(self._workspace),
                cli_path=self._config.cli_path or None,
                github_token=self._github_token or None,
            )
            self._client = CopilotClient(subprocess_config)
            await self._client.start()
            self._started = True

            auth = await self._client.get_auth_status()
            if auth.isAuthenticated:
                logger.info(
                    f"CopilotDelegateService: authenticated as {auth.login} via {auth.authType}"
                )
            else:
                logger.warning(
                    "CopilotDelegateService: not authenticated — "
                    "tasks will fail. Run: gh auth login"
                )
        return self._client

    async def stop(self) -> None:
        # Cancel in-flight background tasks
        for ct in self._tasks.values():
            if ct.asyncio_task and not ct.asyncio_task.done():
                ct.asyncio_task.cancel()
                ct.status = TaskStatus.FAILED
                ct.error = "Cancelled: runtime shutting down"
        # Wait briefly for tasks to finish cancellation
        pending = [
            ct.asyncio_task
            for ct in self._tasks.values()
            if ct.asyncio_task and not ct.asyncio_task.done()
        ]
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

        if self._client and self._started:
            try:
                await self._client.stop()
                logger.info("CopilotDelegateService: CLI client stopped")
            except Exception as exc:
                logger.warning(f"CopilotDelegateService stop error: {exc}")
            finally:
                self._client = None
                self._started = False

    # ── Prompt builder ────────────────────────────────────────────────────────

    # Shared preamble: the result of this task is relayed verbatim to the
    # user via the WorkPilot outbound-persistence mechanism (toast +
    # session entry). Remind the delegate to produce a self-contained
    # final answer in its reply text rather than deferring to files on
    # disk or out-of-band channels.
    _OUTPUT_INSTRUCTION: str = (
        "Produce the final answer directly in your reply text — the full "
        "result, not a summary. WorkPilot relays your reply verbatim to "
        "the user's session (toast + history), so any content you leave "
        "only in files/comments/PRs may be invisible in the delivery. "
        "Use markdown; include the evidence the user needs to act on."
    )

    def _build_prompt(self, task: CopilotTask, files: list[str], agent: str | None = None) -> str:
        instruction = self._TASK_TYPE_PROMPTS.get(task.task_type, self._TASK_TYPE_PROMPTS["code"])
        parts: list[str] = []
        if agent:
            # Route to a custom Copilot agent defined via AGENTS.md / .github/agents
            # (Copilot CLI auto-loads these from cwd; the @-mention is how it
            # routes a request to a specific named agent).
            parts.append(f"@{agent}")
        parts.append(
            f"[{task.task_type.upper()} TASK]\n{instruction}\n\n"
            f"## Output\n{self._OUTPUT_INSTRUCTION}\n\nTask:\n{task.task}"
        )
        if files:
            file_list = "\n".join(f"  - {f}" for f in files)
            parts.append(f"\nFocus on these files/paths:\n{file_list}")
        return "\n".join(parts)

    # ── Model resolution ──────────────────────────────────────────────────────

    def _resolve_model(self, task_type: str, model_override: str | None) -> str:
        """
        Priority: explicit per-call model > model_policy[task_type] > default_model.
        """
        if model_override:
            return model_override
        policy = self._config.model_policy
        return getattr(policy, task_type, self._config.default_model)

    # ── Task submission ───────────────────────────────────────────────────────

    async def submit(
        self,
        task_desc: str,
        task_type: str,
        files: list[str],
        model_override: str | None,
        mode: str,
        notify_channel: ChannelType,
        notify_channel_id: str,
        notify_thread_id: str | None,
        resume_task_id: str | None = None,
        agent: str | None = None,
        auto_approve: bool | None = None,
        notify_session_id: str = "",
    ) -> str:
        model = self._resolve_model(task_type, model_override)

        # ── Resume path ───────────────────────────────────────────────────────
        if resume_task_id:
            # Do NOT require the prior task to be in the in-memory registry —
            # Copilot session history lives on disk and survives WorkPilot restarts.
            # Let the SDK raise if the session genuinely doesn't exist.
            task_id = uuid.uuid4().hex[:12]
            ct = CopilotTask(
                task_id=task_id,
                task=task_desc,
                task_type=task_type,
                notify_channel=notify_channel,
                notify_channel_id=notify_channel_id,
                notify_thread_id=notify_thread_id,
                notify_session_id=notify_session_id,
                auto_approve=auto_approve,
            )
            self._tasks[task_id] = ct
            prompt = self._build_prompt(ct, files, agent=agent)
            resume_session_id = f"wp-{resume_task_id}"

            if mode == "wait":
                return await self._wait_with_timeout_fallback(
                    ct, prompt, model, resume_session_id=resume_session_id
                )

            ct.asyncio_task = asyncio.create_task(
                self._run_task(ct, prompt, model, notify=True, resume_session_id=resume_session_id),
                name=f"copilot-{task_id}",
            )
            return (
                f"Task resumed (id={task_id})\n"
                f"Continuing Copilot session wp-{resume_task_id}.\n"
                f"{self._describe_notify(ct)}\n"
                f'Check status: github_copilot_status(task_id="{task_id}")'
            )

        # ── New task path ─────────────────────────────────────────────────────
        task_id = uuid.uuid4().hex[:12]
        ct = CopilotTask(
            task_id=task_id,
            task=task_desc,
            task_type=task_type,
            notify_channel=notify_channel,
            notify_channel_id=notify_channel_id,
            notify_thread_id=notify_thread_id,
            notify_session_id=notify_session_id,
            auto_approve=auto_approve,
        )
        self._tasks[task_id] = ct
        prompt = self._build_prompt(ct, files, agent=agent)

        if mode == "wait":
            return await self._wait_with_timeout_fallback(ct, prompt, model)

        ct.asyncio_task = asyncio.create_task(
            self._run_task(ct, prompt, model, notify=True),
            name=f"copilot-{task_id}",
        )
        return (
            f"Task submitted (id={task_id})\n"
            f"Type: {task_type} | Model: {model}\n"
            f"{self._describe_notify(ct)}\n"
            f'Check status: github_copilot_status(task_id="{task_id}")'
        )

    async def _wait_with_timeout_fallback(
        self,
        ct: CopilotTask,
        prompt: str,
        model: str,
        *,
        resume_session_id: str | None = None,
    ) -> str:
        """``mode=wait`` with ``config.wait_timeout`` fallback to background.

        Runs the task as a shielded asyncio.Task. If it finishes before the
        timeout, the full result is returned synchronously via tool_result
        (no outbound publish — avoids double-delivery). If the timeout
        fires, the task keeps running; a secondary awaiter publishes the
        completion via ``_notify`` so ``AgentLoop._capture_for_persist``
        can persist it into the originating session. The LLM receives an
        immediate "detached to background" reply and doesn't block.
        """
        bg_task = asyncio.create_task(
            self._run_task(ct, prompt, model, notify=False, resume_session_id=resume_session_id),
            name=f"copilot-{ct.task_id}",
        )
        ct.asyncio_task = bg_task
        wait_timeout = self._config.wait_timeout
        try:
            await asyncio.wait_for(asyncio.shield(bg_task), timeout=wait_timeout)
        except TimeoutError:
            # Task still running under the shield. Detach a secondary
            # awaiter that calls _notify on completion so the user still
            # gets the result via session persistence.
            asyncio.create_task(
                self._notify_on_done(bg_task, ct),
                name=f"copilot-{ct.task_id}-notify-on-done",
            )
            return (
                f"Task timed out after {wait_timeout}s — detached to background "
                f"(id={ct.task_id}).\n"
                f"The Copilot session is still running; its result will appear "
                f"in this session on completion, and you can poll status with "
                f'github_copilot_status(task_id="{ct.task_id}").'
            )
        except asyncio.CancelledError:
            # Agent turn cancelled (e.g. user interrupt, shutdown) while
            # we were waiting. ``asyncio.shield`` protects ``bg_task``
            # from the cancellation so it keeps running, but without
            # an attached completion notifier the eventual result would
            # never reach ``_capture_for_persist`` / session JSONL —
            # silently lost. Attach the notifier BEFORE re-raising so
            # the cancellation semantics are preserved while the
            # detached task still publishes its outcome on completion.
            if not bg_task.done():
                asyncio.create_task(
                    self._notify_on_done(bg_task, ct),
                    name=f"copilot-{ct.task_id}-notify-on-cancel",
                )
            raise
        # Task completed inside the wait window
        return ct.result if ct.status == TaskStatus.DONE else f"Task failed: {ct.error}"

    async def _notify_on_done(self, task: asyncio.Task, ct: CopilotTask) -> None:
        """Await a wait-mode task past its soft timeout, then publish the
        completion so the outbound-capture handler can persist it.

        Exceptions from the task are already recorded on ``ct`` by
        ``_run_task``; we just need to fire the notify. Any exception
        inside ``_notify`` itself is swallowed there.
        """
        try:
            await task
        except Exception:
            # _run_task already set ct.status=FAILED / ct.error before
            # propagating, so we can still notify the failure state.
            pass
        await self._notify(ct)

    @staticmethod
    def _describe_notify(ct: CopilotTask) -> str:
        """One-line user-facing description of how this task reports completion."""
        return f"You will be notified on '{ct.notify_channel}' when it completes."

    # ── Task execution ────────────────────────────────────────────────────────

    async def _run_task(
        self,
        ct: CopilotTask,
        prompt: str,
        model: str,
        *,
        notify: bool,
        resume_session_id: str | None = None,
    ) -> None:
        """Execute one Copilot session (new or resumed), with optional retry."""
        async with self._semaphore:
            attempt = 0
            max_attempts = (
                max(self._config.retry.max_attempts, 1) if self._config.retry.enabled else 1
            )
            session_id = f"wp-{ct.task_id}"

            while attempt < max_attempts:
                attempt += 1
                ct.status = TaskStatus.RUNNING
                logger.info(
                    f"CopilotDelegate [{ct.task_id}]: starting ({ct.task_type}) "
                    f"attempt {attempt}/{max_attempts}"
                )
                try:
                    await self._execute_session(ct, prompt, model, session_id, resume_session_id)
                    break  # success
                except Exception as exc:
                    ct.status = TaskStatus.FAILED
                    ct.error = str(exc)
                    logger.error(f"CopilotDelegate [{ct.task_id}]: failed — {exc}")
                    if attempt < max_attempts:
                        # Next attempt resumes from the failed session checkpoint
                        resume_session_id = session_id
                        logger.info(f"CopilotDelegate [{ct.task_id}]: retrying via resume_session")

        if notify:
            await self._notify(ct)

    async def _execute_session(
        self,
        ct: CopilotTask,
        prompt: str,
        model: str,
        session_id: str,
        resume_session_id: str | None,
    ) -> None:
        client = await self._get_client()

        # SDK 0.2.x: create_session / resume_session take **kwargs (not a dict).
        session_kwargs: dict[str, Any] = {
            "model": model,
            "on_permission_request": self._make_permission_handler(ct),
            "hooks": {
                "on_pre_tool_use": self._on_pre_tool_use,
                "on_post_tool_use": self._on_post_tool_use,
            },
        }

        if resume_session_id:
            session = await client.resume_session(resume_session_id, **session_kwargs)
        else:
            session_kwargs["session_id"] = session_id
            session = await client.create_session(**session_kwargs)

        # SDK send_and_wait default is 60s when timeout=None — pass task_timeout
        # explicitly so long tasks don't time out. 0 in config means "no limit";
        # map to 3600s (1h) since the SDK has no true infinity mode.
        timeout = self._config.task_timeout if self._config.task_timeout > 0 else 3600
        try:
            # 0.2.x: send_and_wait takes prompt as positional string, not {"prompt": ...}
            reply = await session.send_and_wait(prompt, timeout=timeout)
            ct.result = reply.data.content if reply else "(no response)"
            ct.status = TaskStatus.DONE
            logger.info(f"CopilotDelegate [{ct.task_id}]: done ({len(ct.result)} chars)")
        finally:
            await session.destroy()

    # ── Notification ──────────────────────────────────────────────────────────

    async def _notify(self, ct: CopilotTask) -> None:
        from workpilot.security.leak import redact_credentials

        max_chars = self._config.notification_max_chars
        if ct.status == TaskStatus.DONE:
            # ``max_chars == 0`` means "no truncation" — session JSONL
            # persistence renders the full markdown on refresh, so there's
            # no channel reason to clip by default.
            body = (
                ct.result
                if not max_chars or len(ct.result) <= max_chars
                else ct.result[:max_chars] + "\n\n...(truncated)"
            )
            body = redact_credentials(body)
            content = (
                f"**Copilot task complete** (id=`{ct.task_id}`, type=`{ct.task_type}`)\n\n{body}"
            )
        else:
            content = (
                f"**Copilot task failed** (id=`{ct.task_id}`, type=`{ct.task_type}`)\n"
                f"Error: {ct.error}"
            )

        await deliver_background_completion(
            self._bus,
            target=NotifyTarget(
                channel=ct.notify_channel,
                channel_id=ct.notify_channel_id,
                thread_id=ct.notify_thread_id,
                session_id=ct.notify_session_id,
            ),
            content=content,
            task_id=ct.task_id,
            origin_tool="github_copilot",
            channel_manager=self._channel_manager,
            log_prefix="CopilotDelegate",
        )

    # ── SDK hooks ─────────────────────────────────────────────────────────────

    def _make_permission_handler(self, ct: CopilotTask) -> Any:
        """Build an SDK ``on_permission_request`` callback.

        The Copilot CLI calls this only for tools its own allow/deny rules
        (from ``~/.copilot/``, ``--allow-tool``, etc.) couldn't resolve — so
        the user's native config naturally takes priority. This callback only
        decides the grey area.

        Resolution rule — config is a **hard ceiling**, per-task can only
        tighten (never loosen):

        * ``config.hooks.auto_approve=False`` (strict) → always deny,
          regardless of ``ct.auto_approve``. Per-task args come from the LLM
          and must not be able to bypass an operator's strict setting.
        * ``config.hooks.auto_approve=True`` → per-task ``False`` tightens
          to deny; ``True`` or ``None`` stays approve.
        """
        # The pyproject pin is ``github-copilot-sdk>=0.2``, where
        # PermissionHandler and PermissionRequestResult live in
        # ``copilot.session``. Import them directly.
        from copilot.session import (  # type: ignore[import,attr-defined]
            PermissionHandler,
            PermissionRequestResult,
        )

        # Config ceiling: if operator set strict mode, task arg cannot loosen.
        if not self._config.hooks.auto_approve:
            effective = False
        else:
            # Config permits approve; task arg may still tighten to False.
            effective = True if ct.auto_approve is None else ct.auto_approve

        # Approve: reuse the SDK's own helper — 1:1 with the legacy behavior
        # (returns PermissionRequestResult(kind="approved")).
        if effective:
            return PermissionHandler.approve_all

        # Deny: construct the result inside the callback so we don't touch the
        # SDK at handler-creation time with dummy args.
        def handler(request: Any, invocation: dict[str, Any]) -> Any:
            return PermissionRequestResult(kind="denied-by-rules")

        return handler

    async def _on_pre_tool_use(self, input: dict, invocation: dict) -> dict:
        tool_name = input.get("toolName", "unknown")
        logger.debug(f"CopilotDelegate: pre_tool_use tool={tool_name}")
        if tool_name in self._config.hooks.block_copilot_tools:
            logger.info(f"CopilotDelegate: blocking tool={tool_name} (block_copilot_tools)")
            return {"permissionDecision": "deny"}
        return {"permissionDecision": "allow"}

    async def _on_post_tool_use(self, input: dict, invocation: dict) -> dict:
        logger.debug(f"CopilotDelegate: post_tool_use tool={input.get('toolName', 'unknown')}")
        return {}

    # ── Status queries ────────────────────────────────────────────────────────

    def get_task(self, task_id: str) -> CopilotTask | None:
        return self._tasks.get(task_id)

    def list_tasks(self) -> list[CopilotTask]:
        return list(self._tasks.values())

    async def get_models(self) -> Any:
        client = await self._get_client()
        return await client.list_models()


# ── Tool: github_copilot ────────────────────────────────────────────────────


class CopilotDelegateTool(Tool):
    """Delegate a coding, review, test, or refactor task to GitHub Copilot CLI."""

    risk_range = (3, 7)

    def __init__(self, service: CopilotDelegateService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "github_copilot"

    @property
    def description(self) -> str:
        return (
            "Delegate a coding task to GitHub Copilot. "
            "Copilot reads, edits, and tests autonomously. "
            "Returns a task_id; notifies on completion."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return _assess_delegate_risk("Copilot", args)

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": (
                        "Task description. Include file names, expected behaviour, "
                        "and acceptance criteria."
                    ),
                },
                "task_type": {
                    "type": "string",
                    "enum": ["code", "review", "test", "refactor"],
                    "description": (
                        "code = fix/implement; review = audit for bugs/security; "
                        "test = write tests; refactor = restructure without behaviour change."
                    ),
                },
                "files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File or directory paths for Copilot to focus on.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["background", "wait"],
                    "description": (
                        "background (default) = async with notification; "
                        "wait = block until done (short tasks only)."
                    ),
                },
                "model": {
                    "type": "string",
                    "description": "Copilot model. Use github_copilot_models to list options.",
                },
                "resume_task_id": {
                    "type": "string",
                    "description": "Resume a prior task by ID. Continues from existing session.",
                },
                "agent": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 64,
                    "pattern": r"^@?[A-Za-z0-9][A-Za-z0-9_.\-]{0,63}$",
                    "description": (
                        "Name of a Copilot custom agent to route the task to "
                        "(defined via AGENTS.md / .github/agents/ in the workspace; "
                        "auto-loaded by the Copilot CLI). Omit to use the default "
                        "agent. Allowed chars: letters, digits, `_`, `.`, `-` "
                        "(leading `@` is accepted and stripped)."
                    ),
                },
                "auto_approve": {
                    # Tri-state: bool requests per-task behaviour; null/omitted
                    # defers to ``tools.copilot.hooks.auto_approve``. Config is
                    # a hard ceiling — stricter config cannot be loosened by a
                    # per-task value. Advertise null in the schema so
                    # validators don't reject it.
                    "anyOf": [{"type": "boolean"}, {"type": "null"}],
                    "description": (
                        "Per-task preference for handling grey-area Copilot CLI "
                        "tool requests (those not already resolved by `~/.copilot/` "
                        "allow/deny rules). `true` requests auto-approve; `false` "
                        "requests deny. `tools.copilot.hooks.auto_approve` is the "
                        "effective ceiling — when config is `false` a per-task "
                        "`true` still resolves to deny. Omit or set to null to use "
                        "config."
                    ),
                },
            },
            "required": ["task"],
        }

    async def execute(self, **kwargs: Any) -> str:
        # Read channel context from kwargs (injected by ToolRegistry.execute)
        channel = kwargs.get("_channel", "")
        channel_id = kwargs.get("_channel_id", "")
        thread_id = kwargs.get("_thread_id")
        session_id = kwargs.get("_session_id", "")

        task: str = kwargs.get("task", "")
        task_type: str = kwargs.get("task_type", "code")
        files: list[str] = kwargs.get("files", [])
        mode: str = kwargs.get("mode", "background")
        model: str | None = kwargs.get("model") or None
        resume_task_id: str | None = kwargs.get("resume_task_id") or None
        # ToolRegistry doesn't enforce JSON-schema types at runtime; reject
        # non-string ``agent`` explicitly (matches ClaudeCodeTool.execute)
        # so the caller gets a clear error instead of an AttributeError from
        # ``.strip()`` inside ``_normalize_agent``.
        raw_agent = kwargs.get("agent")
        if raw_agent is not None and not isinstance(raw_agent, str):
            return "Error: agent must be a string or null."
        agent: str | None = _normalize_agent(raw_agent)
        # ToolRegistry doesn't enforce JSON-schema types at runtime; reject
        # non-bool ``auto_approve`` explicitly so the caller gets a clear error
        # instead of a silent fallback to config default.
        auto_approve: bool | None = None
        if "auto_approve" in kwargs:
            raw_auto_approve = kwargs["auto_approve"]
            if raw_auto_approve is None:
                auto_approve = None
            elif isinstance(raw_auto_approve, bool):
                auto_approve = raw_auto_approve
            else:
                return (
                    "Error: auto_approve must be a boolean (true/false) or null; "
                    "omit or pass null to defer to config."
                )

        if not task.strip():
            return "Error: task description cannot be empty."
        if task_type not in ("code", "review", "test", "refactor"):
            return f"Error: invalid task_type '{task_type}'. Use: code, review, test, refactor."
        if mode not in ("background", "wait"):
            return f"Error: invalid mode '{mode}'. Use: background or wait."
        if agent is not None and not _AGENT_NAME_RE.match(agent):
            return (
                f"Error: invalid agent name '{agent}'. "
                "Allowed chars: letters, digits, `_`, `.`, `-` (max 64)."
            )

        return await self._service.submit(
            task_desc=task,
            task_type=task_type,
            files=files,
            model_override=model,
            mode=mode,
            notify_channel=ChannelType.of(channel),
            notify_channel_id=channel_id,
            notify_thread_id=thread_id,
            resume_task_id=resume_task_id,
            agent=agent,
            auto_approve=auto_approve,
            notify_session_id=session_id,
        )


# ── Tool: github_copilot_status ──────────────────────────────────────────────────────


class CopilotStatusTool(Tool):
    """Query the status and result of a background Copilot task."""

    risk_range = (0, 0)

    def __init__(self, service: CopilotDelegateService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "github_copilot_status"

    @property
    def description(self) -> str:
        return "Check Copilot task status or list all tasks."

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=20, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only Copilot status query")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task ID from github_copilot. Omit to list all tasks.",
                },
            },
        }

    async def execute(self, **kwargs: Any) -> str:
        task_id: str | None = kwargs.get("task_id")

        if not task_id:
            tasks = self._service.list_tasks()
            if not tasks:
                return "No Copilot tasks found."
            lines = [f"{'ID':<14} {'TYPE':<10} {'STATUS'}"]
            lines.append("-" * 36)
            for t in tasks:
                lines.append(f"{t.task_id:<14} {t.task_type:<10} {t.status.value}")
            return "\n".join(lines)

        ct = self._service.get_task(task_id)
        if ct is None:
            return f"Error: no task with id '{task_id}'."

        lines = [
            f"Task ID:   {ct.task_id}",
            f"Type:      {ct.task_type}",
            f"Status:    {ct.status.value}",
        ]
        if ct.status == TaskStatus.RUNNING:
            lines.append("Result:    (in progress...)")
        elif ct.status == TaskStatus.DONE:
            preview = ct.result[:500] + ("..." if len(ct.result) > 500 else "")
            lines.append(f"Result:\n{preview}")
        elif ct.status == TaskStatus.FAILED:
            lines.append(f"Error:     {ct.error}")

        return "\n".join(lines)


# ── Tool: github_copilot_models ──────────────────────────────────────────────────────


class CopilotModelsTool(Tool):
    """List models available to the Copilot CLI, with context limits and billing."""

    risk_range = (0, 0)

    def __init__(self, service: CopilotDelegateService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "github_copilot_models"

    @property
    def description(self) -> str:
        return "List available Copilot models with context limits and billing info."

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only Copilot model listing")

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, **kwargs: Any) -> str:
        try:
            models = await self._service.get_models()
        except Exception as exc:
            return f"Error fetching models: {exc}"

        if not models:
            return "No models returned."

        header = f"{'MODEL':<30} {'CTX':>7}  {'PROMPT':>7}  BILLING"
        sep = "-" * 58
        rows = [header, sep]
        for m in models:
            lim = m.capabilities.limits
            ctx = (
                f"{lim.max_context_window_tokens // 1000}K"
                if lim.max_context_window_tokens
                else "-"
            )
            prompt = f"{lim.max_prompt_tokens // 1000}K" if lim.max_prompt_tokens else "-"
            billing = f"x{m.billing.multiplier}" if m.billing else "-"
            rows.append(f"{m.id:<30} {ctx:>7}  {prompt:>7}  {billing}")
        return "\n".join(rows)
