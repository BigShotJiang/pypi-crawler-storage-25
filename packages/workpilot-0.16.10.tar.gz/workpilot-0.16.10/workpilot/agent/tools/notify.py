"""
Cross-channel notification tool — send messages to any active channel
via the async message bus.

The tool publishes an OutboundMessage to the MessageBus, which routes it
to the appropriate channel handler. Use '*' to broadcast to all channels.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.bus.events import OutboundMessage
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import ChannelType
from workpilot.security.risk import RiskAssessment, RiskScore
from workpilot.session.manager import SessionManager


class NotifyTool(Tool):
    """Send notifications to active channels through the message bus."""

    risk_range = (0, 0)

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Notification to user")

    def __init__(
        self,
        bus: MessageBus,
        active_channels_fn: Callable[[], list[ChannelType]] | None = None,
    ) -> None:
        self._bus = bus
        self._active_channels_fn = active_channels_fn or (lambda: [ChannelType.CLI])

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "notify"

    @property
    def description(self) -> str:
        return "Push a notification to the user via their active channel."

    @property
    def parameters(self) -> dict[str, Any]:
        channels = self._active_channels_fn()
        return {
            "type": "object",
            "properties": {
                "channel": {
                    "type": "string",
                    "enum": [*channels, "*"],
                    "description": (
                        "Target channel, or '*' for all active channels. "
                        "cloud: Teams bot & Web Chat via Cloud Gateway."
                    ),
                },
                "content": {
                    "type": "string",
                    "description": "Message content.",
                },
                "attachments": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Optional list of attachment sha256 refs from the local "
                        "attachment store. The Cloud channel resolves and inlines "
                        "supported images — attachments that exceed the WSS frame "
                        "budget are dropped with a short text note appended to the "
                        "message so the user sees what was skipped. Non-cloud "
                        "channels currently ignore this field."
                    ),
                },
            },
            "required": ["channel", "content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        channel: str = kwargs["channel"]  # from LLM tool call — may be "*" or a channel name
        content: str = kwargs["content"]
        # Accept sha strings as the public surface; CloudChannel.send resolves
        # them against the attachment store and inlines bytes_b64 on the frame.
        raw_attachments = kwargs.get("attachments") or None
        attachments: list[Any] | None = (
            [s for s in raw_attachments if isinstance(s, str) and s]
            if isinstance(raw_attachments, list)
            else None
        ) or None
        # Registry injects _channel/_channel_id/_session_id from the current conversation
        current_channel = ChannelType.of(kwargs.get("_channel", ""))
        current_channel_id: str = kwargs.get("_channel_id", "")
        current_session_id: str = kwargs.get("_session_id", "")

        if not content.strip() and not attachments:
            return "Error: message content or attachments required."

        # Validate ``channel`` explicitly. The JSON-schema ``enum`` restricts
        # it to ``"*"`` + the currently active channel names, but tool
        # registry does NOT enforce schema types/enums at runtime — so an
        # LLM typo (e.g. ``"wen"``) would otherwise slip through
        # ``ChannelType.of()``'s silent CLI fallback and get routed to the
        # wrong channel (or persist into the current session via the
        # self-target branch in ``_meta``). Surface the typo as a clear
        # error instead.
        active_channels = self._active_channels_fn()
        valid_channel_names = {str(ch) for ch in active_channels}
        if channel != "*" and channel not in valid_channel_names:
            valid_list = ", ".join(sorted(valid_channel_names) + ["*"]) or "'*'"
            return f"Error: unknown or inactive channel {channel!r}. Valid options: {valid_list}."

        def _meta(target_ch: str) -> dict[str, Any]:
            """Metadata stamp recognised by ``AgentLoop._capture_for_persist``.

            ``target_session_id`` resolution, in order:

            1. ``SessionManager.channel_default_session(target_ch)`` —
               the channel's canonical default session (web → local_web,
               cli → local_cli). Derivable from the channel name alone.
            2. **Self-target on cloud**: cloud has no channel-default
               (cloud_teams and cloud_web depend on which surface the
               user is on — not derivable from ``"cloud"`` alone). When
               the user is ON cloud and notifies themselves (target ==
               current channel), use their current session so the entry
               lands in ``cloud_teams.jsonl`` / ``cloud_web.jsonl``.
            3. Otherwise ``None`` → the capture handler drops the entry.
               Covers cross-channel sends (web user → notify cloud) and
               the cloud leg of a broadcast (no duplicate into the
               originating session).

            We deliberately do NOT stamp ``session_id`` in the metadata:
            the handler's ``target_session_id or session_id`` fallback
            would otherwise pull every per-target outbound back into the
            originating session on broadcast.
            """
            target_sid = SessionManager.channel_default_session(target_ch)
            if (
                target_sid is None
                and current_session_id
                and ChannelType.of(target_ch) == current_channel
            ):
                # Cloud self-notify (user on Teams/WebChat notifying themselves).
                target_sid = current_session_id
            return {
                "source": "notify",
                "_ts": datetime.now(UTC).isoformat(),
                "_origin": "notify",
                "target_session_id": target_sid,
            }

        # Broadcast to all active channels
        if channel == "*":
            targets = self._active_channels_fn()
            if not targets:
                return "Error: no active channels."
            results: list[str] = []
            for ch in targets:
                try:
                    # Use real channel_id if notifying the current conversation's channel
                    cid = current_channel_id if ch == current_channel and current_channel_id else ch
                    await self._bus.publish_outbound(
                        OutboundMessage(
                            channel=ChannelType.of(ch),
                            channel_id=cid,
                            content=content,
                            attachments=attachments,
                            metadata=_meta(str(ch)),
                        )
                    )
                    results.append(ch)
                except Exception as exc:
                    logger.error(f"Failed to notify '{ch}': {exc}")
            return f"Notified {len(results)} channels: {', '.join(results)}"

        # Single channel
        cid = current_channel_id if channel == current_channel and current_channel_id else channel
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ChannelType.of(channel),
                    channel_id=cid,
                    content=content,
                    attachments=attachments,
                    metadata=_meta(channel),
                )
            )
            return f"Notified {channel}"
        except Exception as exc:
            logger.error(f"Failed to notify '{channel}': {exc}")
            return f"Error sending to {channel}: {exc}"
