"""
Message bus event types — decoupled communication between channels and agent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from workpilot.config.schema import ChannelType

# ── Notification framing (shared contract) ───────────────────────────────────

# Sources produced by the outbound-persistence pipeline — notify tool,
# delegate completions, scheduler deliveries. Channels / handlers that
# need to differentiate "notification outbound" from "plain response"
# check ``metadata.source`` against this set.
NOTIFICATION_SOURCES: frozenset[str] = frozenset({"notify", "delegate", "scheduler"})


def frame_notification(content: str, meta: dict[str, Any]) -> str:
    """Apply the canonical ``[Notification delivered to user at
    HH:MM:SS via <origin>] <content>`` framing prefix.

    Single source of truth for the framing format:

    * ``AgentLoop._capture_for_persist`` stamps it on the session JSONL
      entry so future LLM turns read the notification as a past event
      rather than a new instruction.
    * ``WebChannel.send`` stamps it on the WebSocket push frame so the
      browser's ``parseNotificationPush`` regex matches and
      ``onNotification`` fires (toast + inline card rendering).

    Any change to the format (slice width, origin fallback, spacing)
    must match the frontend regex ``NOTIFICATION_PREFIX_RE`` in
    ``web/src/lib/parseMessages.ts``; ``useWebSocket.ts`` reuses the
    exported ``stripNotificationPrefix`` helper from that module (single
    source of truth) rather than maintaining its own copy.

    ``HH:MM:SS`` is derived from ``meta["_ts"]`` when present, else
    ``datetime.now(UTC).isoformat()`` at call time. ``<origin>`` is
    ``meta["_origin"] or meta["source"]`` ("notify" | "delegate" |
    "scheduler" — or the specific ``cron:<job>`` / tool name producers
    stamp).

    Note: channels whose frontend is a different product surface (e.g.
    CloudChannel → Teams / WebChat Bot Framework, which render the
    content directly to end users) should NOT call this helper — the
    prefix is a contract with WorkPilot's own web frontend, not a
    universal user-facing string.
    """
    ts = meta.get("_ts") or datetime.now(UTC).isoformat()
    # HH:MM:SS = 8 chars after the "T" separator. Must match the
    # frontend regex — see module docstring.
    ts_short = ts.split("T")[-1][:8] if "T" in ts else ts
    origin = meta.get("_origin") or meta.get("source") or "notify"
    return f"[Notification delivered to user at {ts_short} via {origin}] {content}"


# ── Message types ────────────────────────────────────────────────────────────


@dataclass
class InboundMessage:
    """Message received from a channel, headed to the agent."""

    channel: ChannelType | str
    channel_id: str
    sender_id: str
    content: str
    content_format: str = "text"
    sender_name: str = ""
    thread_id: str | None = None
    session_id: str | None = None
    session_key: str | None = None
    attachments: list[Any] | None = None
    timestamp: str | None = None  # ISO format
    metadata: dict[str, Any] = field(default_factory=dict)
    # metadata may contain: source, tenant_id, injection, interrupt


@dataclass
class OutboundMessage:
    """Message from the agent, headed to a channel."""

    channel: ChannelType
    channel_id: str
    content: str
    thread_id: str | None = None
    reply_to: str | None = None
    attachments: list[Any] | None = None
    format: str = "markdown"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class StreamingChunk:
    """Incremental content fragment during streaming responses."""

    channel: ChannelType
    channel_id: str
    content: str
    chunk_type: str = "token"  # "token" | "tool_progress" | "status"
    done: bool = False


# ── Typed events for cross-subsystem coordination ───────────────────────────


class EventType(str, Enum):
    """Typed events emitted via EventBus for cross-subsystem coordination."""

    # Message lifecycle
    MESSAGE_RECEIVED = "message.received"
    MESSAGE_SENT = "message.sent"
    # Tool execution
    TOOL_EXECUTED = "tool.executed"
    TOOL_FAILED = "tool.failed"
    TOOL_APPROVED = "tool.approved"
    TOOL_DENIED = "tool.denied"
    # Approval workflow
    APPROVAL_REQUESTED = "approval.requested"
    APPROVAL_RESOLVED = "approval.resolved"
    # Security
    SECURITY_ALERT = "security.alert"
    SECURITY_ESTOP = "security.estop"
    SECURITY_LEAK = "security.leak"
    # Cost
    COST_WARNING = "cost.warning"
    # Health
    HEALTH_DEGRADED = "health.degraded"
    HEALTH_RECOVERED = "health.recovered"
    # Agent
    AGENT_ITERATION = "agent.iteration"
    AGENT_INTERRUPTED = "agent.interrupted"
    # Memory
    MEMORY_CONSOLIDATED = "memory.consolidated"
    # Session
    SESSION_CREATED = "session.created"
    # Channel lifecycle
    CHANNEL_CONNECTED = "channel.connected"
    # Typing indicators
    TYPING_STARTED = "typing.started"
    TYPING_STOPPED = "typing.stopped"
