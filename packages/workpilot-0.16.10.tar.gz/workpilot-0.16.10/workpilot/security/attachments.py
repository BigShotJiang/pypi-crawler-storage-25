"""
Attachment store — content-addressed file storage.

Two attachment kinds are supported:

- ``image`` — binary image bytes referenced from prompts as
  ``workpilot-attachment://<sha>``; inlined to a ``data:`` URL at the
  provider API boundary (see ``providers/client.py::_resolve_attachment_urls``).
  Sent to the model as ``input_image`` parts, which require a vision-capable
  model.
- ``text`` — UTF-8 decodable text/code/markdown files. The bytes are read
  and inlined as ``input_text`` parts directly, so no vision model is
  required. Size-capped more aggressively than images so they don't blow
  the context window.

The on-disk layout is the same for both — ``~/.workpilot/data/attachments/<sha>.<ext>``.
"""

from __future__ import annotations

import base64
import hashlib
import os
import re
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Literal

from loguru import logger

from workpilot.utils.helpers import ensure_dir, get_data_dir

# ── MIME / extension allowlists ───────────────────────────────────────────────

ALLOWED_IMAGE_TYPES: frozenset[str] = frozenset(
    {"image/png", "image/jpeg", "image/gif", "image/webp"}
)

# Known text-ish MIMEs. Browsers serve many code files as ``text/plain`` or
# ``application/octet-stream``, so a filename-extension fallback catches the
# rest (see ``_TEXT_EXTENSIONS``).
_ALLOWED_TEXT_MIMES: frozenset[str] = frozenset(
    {
        "application/graphql",
        "application/javascript",
        "application/json",
        "application/sql",
        "application/toml",
        "application/typescript",
        "application/x-javascript",
        "application/x-toml",
        "application/x-yaml",
        "application/xml",
        "application/yaml",
    }
)

# Extensions we're willing to accept as text even when the browser sends a
# generic MIME (``text/plain``, ``application/octet-stream``, or nothing).
# Curated for common web / backend / cloud / scripting / config formats —
# esoteric languages are deliberately out to keep the surface small.
_TEXT_EXTENSIONS: frozenset[str] = frozenset(
    {
        # plain / docs
        "txt",
        "md",
        "markdown",
        "rst",
        "log",
        # tabular
        "csv",
        "tsv",
        # code
        "py",
        "pyw",
        "js",
        "jsx",
        "mjs",
        "cjs",
        "ts",
        "tsx",
        "rs",
        "go",
        "java",
        "kt",
        "scala",
        "swift",
        "dart",
        "c",
        "cpp",
        "cxx",
        "cc",
        "h",
        "hpp",
        "hxx",
        "cs",
        "fs",
        "vb",
        "rb",
        "php",
        "pl",
        "lua",
        "r",
        # scripts
        "sh",
        "bash",
        "zsh",
        "ps1",
        "bat",
        "cmd",
        # config / data
        "json",
        "yaml",
        "yml",
        "toml",
        "xml",
        "ini",
        "cfg",
        "conf",
        "properties",
        "env",
        # markup
        "html",
        "htm",
        "css",
        "scss",
        "sass",
        "less",
        # domain
        "sql",
        "graphql",
        "proto",
        "tf",
        "hcl",
        # framework
        "vue",
        "svelte",
        "astro",
    }
)

# Per-kind size caps — image bytes ride the wire intact, but text goes into
# the prompt verbatim so we cap more tightly to protect the context window.
MAX_IMAGE_BYTES: int = 20_000_000  # 20 MB
MAX_TEXT_BYTES: int = 500_000  # 500 KB

AttachmentKind = Literal["image", "text"]

_IMAGE_EXT_BY_MIME: dict[str, str] = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
}
_MIME_BY_IMAGE_EXT: dict[str, str] = {v: k for k, v in _IMAGE_EXT_BY_MIME.items()}
_TEXT_EXT: str = ".txt"

ATTACHMENT_URL_SCHEME = "workpilot-attachment://"


# Fence-language map (for text attachments) lives here so agent + provider
# share the same extension → language table. Keep in sync with
# ``_TEXT_EXTENSIONS`` above.
_FENCE_LANG_BY_EXT: dict[str, str] = {
    "py": "python",
    "pyw": "python",
    "js": "javascript",
    "mjs": "javascript",
    "cjs": "javascript",
    "jsx": "jsx",
    "ts": "typescript",
    "tsx": "tsx",
    "rs": "rust",
    "go": "go",
    "java": "java",
    "kt": "kotlin",
    "scala": "scala",
    "swift": "swift",
    "dart": "dart",
    "c": "c",
    "cpp": "cpp",
    "cxx": "cpp",
    "cc": "cpp",
    "h": "c",
    "hpp": "cpp",
    "hxx": "cpp",
    "cs": "csharp",
    "fs": "fsharp",
    "vb": "vbnet",
    "rb": "ruby",
    "php": "php",
    "pl": "perl",
    "lua": "lua",
    "r": "r",
    "sh": "bash",
    "bash": "bash",
    "zsh": "bash",
    "ps1": "powershell",
    "bat": "batch",
    "cmd": "batch",
    "json": "json",
    "yaml": "yaml",
    "yml": "yaml",
    "toml": "toml",
    "xml": "xml",
    "ini": "ini",
    "cfg": "ini",
    "conf": "ini",
    "properties": "properties",
    "env": "bash",
    "html": "html",
    "htm": "html",
    "css": "css",
    "scss": "scss",
    "sass": "sass",
    "less": "less",
    "sql": "sql",
    "graphql": "graphql",
    "proto": "protobuf",
    "tf": "hcl",
    "hcl": "hcl",
    "vue": "vue",
    "svelte": "svelte",
    "astro": "astro",
    "md": "markdown",
    "markdown": "markdown",
    "csv": "csv",
    "tsv": "tsv",
}


def fence_lang(name: str | None) -> str:
    """Return a fence-language hint for a text attachment (``"python"`` for
    ``foo.py``, ``""`` for unknown extensions)."""
    ext = _extension_of(name)
    return _FENCE_LANG_BY_EXT.get(ext, "") if ext else ""


# Filename sanitizer for embedding in ``<attached_file name="...">`` tags.
# Strips characters that would break the surrounding structure or look like
# prompt-injection scaffolding to the model.
_UNSAFE_NAME_CHARS_RE = re.compile(r'[<>"\x00-\x1f]')


def sanitize_name_for_tag(name: str | None) -> str:
    """Produce a safe display name for an attachment tag. Never empty."""
    if not name:
        return "attachment"
    cleaned = _UNSAFE_NAME_CHARS_RE.sub("_", name).strip()
    return cleaned or "attachment"


def safe_fence(body: str, lang: str = "") -> str:
    """Wrap *body* in a fenced code block whose fence length exceeds the
    longest run of backticks in the body — so markdown attachments with
    their own ``` fences don't close the outer block prematurely."""
    longest = 0
    run = 0
    for ch in body:
        if ch == "`":
            run += 1
            if run > longest:
                longest = run
        else:
            run = 0
    fence = "`" * max(3, longest + 1)
    return f"{fence}{lang}\n{body}\n{fence}"


def render_text_attachment(name: str | None, body: str) -> str:
    """Shared rendering for text attachments — used by both the agent loop
    (build time) and the provider resolver (JSONL replay) so the in-context
    format stays consistent."""
    safe_name = sanitize_name_for_tag(name)
    return (
        f'<attached_file name="{safe_name}">\n'
        f"{safe_fence(body, fence_lang(name))}\n"
        f"</attached_file>"
    )


# ── Classifier ────────────────────────────────────────────────────────────────


def _normalize_mime(content_type: str | None) -> str:
    if not content_type:
        return ""
    return content_type.lower().split(";", 1)[0].strip()


def _extension_of(name: str | None) -> str:
    if not name or "." not in name:
        return ""
    return name.rsplit(".", 1)[-1].lower()


def kind_of(content_type: str | None, name: str | None) -> AttachmentKind | None:
    """Classify an upload. Returns ``None`` if neither image nor text.

    Resolution order:
    1. Image MIME allowlist
    2. Known text MIME allowlist
    3. ``text/*`` generic
    4. Text extension fallback (covers ``application/octet-stream`` +
       ``text/plain`` files that are really code)
    """
    mime = _normalize_mime(content_type)
    if mime in ALLOWED_IMAGE_TYPES:
        return "image"
    if mime in _ALLOWED_TEXT_MIMES or mime.startswith("text/"):
        return "text"
    if _extension_of(name) in _TEXT_EXTENSIONS:
        return "text"
    return None


def cap_for(kind: AttachmentKind) -> int:
    return MAX_IMAGE_BYTES if kind == "image" else MAX_TEXT_BYTES


# ── Store ─────────────────────────────────────────────────────────────────────


class AttachmentError(ValueError):
    """Raised on attachment validation failures."""


@dataclass(frozen=True)
class AttachmentRef:
    sha256: str
    path: str
    content_type: str
    size: int
    kind: AttachmentKind
    name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "sha256": self.sha256,
            "path": self.path,
            "content_type": self.content_type,
            "size": self.size,
            "kind": self.kind,
        }
        if self.name:
            d["name"] = self.name
        return d


def attachments_dir() -> Path:
    return ensure_dir(get_data_dir() / "data" / "attachments")


def _pick_extension(content_type: str, kind: AttachmentKind) -> str:
    """Pick a deterministic extension by ``(content_type, kind)``.

    Derived from content_type only — NOT from the uploaded filename — so the
    same bytes always land at the same path regardless of what the user
    named the file. The original filename is preserved in ``AttachmentRef.name``
    and in the persisted sidecar; it's what drives fence-language detection
    on replay.
    """
    if kind == "image":
        return _IMAGE_EXT_BY_MIME.get(content_type, ".bin")
    return _TEXT_EXT


def _path_for(sha256: str, content_type: str, kind: AttachmentKind) -> Path:
    return attachments_dir() / f"{sha256}{_pick_extension(content_type, kind)}"


def _normalize_content_type(content_type: str) -> str:
    """Strip RFC 7231 parameters (``; charset=...``) and lower-case the
    media type so ``image/png; charset=binary`` and ``IMAGE/PNG`` both
    map to the same stable token used for classification and extension
    selection."""
    if not isinstance(content_type, str):
        return ""
    return content_type.split(";", 1)[0].strip().lower()


def save_attachment(data: bytes, content_type: str, name: str | None = None) -> AttachmentRef:
    """Validate, hash, and persist bytes. Returns a reusable ref.

    Idempotent — if the content-addressed file already exists, the existing
    file is kept and its ref returned.
    """
    content_type = _normalize_content_type(content_type)
    kind = kind_of(content_type, name)
    # Normalise text kinds to "text/plain" so the value returned here
    # matches what ``load_ref()`` reconstructs from disk (we only persist
    # ``<sha>.txt`` regardless of the source MIME — markdown / yaml / py
    # all become text/plain after a round-trip). Preserving the original
    # MIME only in the upload response would be misleading.
    if kind == "text":
        content_type = "text/plain"
    if kind is None:
        raise AttachmentError(
            f"Unsupported attachment: content_type={content_type!r} name={name!r}"
        )
    size = len(data)
    if size == 0:
        raise AttachmentError("Empty attachment")
    cap = cap_for(kind)
    if size > cap:
        raise AttachmentError(f"Attachment too large for kind={kind}: {size} bytes (max {cap})")
    # Reject text that isn't valid UTF-8 — we'd only be able to surface it as
    # text to the LLM, and mojibake makes for bad prompts.
    if kind == "text":
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AttachmentError(f"Text attachment is not valid UTF-8: {exc}") from exc

    sha256 = hashlib.sha256(data).hexdigest()
    path = _path_for(sha256, content_type, kind)
    if not path.exists():
        # Unique tmp suffix per call — two concurrent uploads of the same
        # bytes would otherwise collide on a shared ``<sha>.png.tmp`` and
        # either clobber each other's write or error on replace.
        tmp = path.with_suffix(path.suffix + f".{os.getpid()}.{os.urandom(4).hex()}.tmp")
        try:
            tmp.write_bytes(data)
            tmp.replace(path)
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass

    return AttachmentRef(
        sha256=sha256,
        path=str(path),
        content_type=content_type,
        size=size,
        kind=kind,
        name=name,
    )


_SHA256_HEX_RE = re.compile(r"^[0-9a-f]{64}$")


def _is_valid_sha256(sha256: str) -> bool:
    """Lower-case 64-char hex digest check — guards path traversal from
    untrusted callers (e.g. ``..`` or directory separators would never
    match)."""
    return isinstance(sha256, str) and bool(_SHA256_HEX_RE.fullmatch(sha256))


def load_ref(sha256: str) -> AttachmentRef | None:
    """Look up an on-disk attachment by sha256.

    The on-disk filename is deterministic — one of:
    - ``<sha>.png`` / ``.jpg`` / ``.gif`` / ``.webp`` for images
    - ``<sha>.txt`` for text

    so we stat a handful of known candidates instead of globbing. Input is
    lowercased before validation so callers that forward user-supplied
    digests (API handlers, wire frames) don't need to repeat the
    normalization. Values that don't match 64-char hex return ``None``
    so untrusted input can't produce a path traversal.
    """
    if isinstance(sha256, str):
        sha256 = sha256.lower()
    if not _is_valid_sha256(sha256):
        return None
    dir_ = attachments_dir()
    if not dir_.is_dir():
        return None
    # Images first (fixed MIME → ext map), then the single text filename.
    for ext, mime in _MIME_BY_IMAGE_EXT.items():
        p = dir_ / f"{sha256}{ext}"
        if p.is_file():
            return AttachmentRef(
                sha256=sha256,
                path=str(p),
                content_type=mime,
                size=p.stat().st_size,
                kind="image",
            )
    p_text = dir_ / f"{sha256}{_TEXT_EXT}"
    if p_text.is_file():
        return AttachmentRef(
            sha256=sha256,
            path=str(p_text),
            content_type="text/plain",
            size=p_text.stat().st_size,
            kind="text",
        )
    return None


def load_as_data_url(sha256: str) -> str | None:
    """Read an image attachment and encode as a ``data:`` URL.

    Returns ``None`` for missing or non-image attachments (with a warning
    log so upstream callers that rely on it for rendering can diagnose
    ``<image missing>`` turns in the transcript).
    """
    ref = load_ref(sha256)
    if ref is None:
        logger.warning("Image attachment missing from local store: {}", sha256)
        return None
    if ref.kind != "image":
        return None
    data = Path(ref.path).read_bytes()
    b64 = base64.b64encode(data).decode("ascii")
    return f"data:{ref.content_type};base64,{b64}"


def load_as_text(sha256: str) -> str | None:
    """Read a text attachment and decode as UTF-8.

    Returns ``None`` for missing or non-text attachments, or on decode error
    (shouldn't happen for well-formed uploads — ``save_attachment`` rejects
    non-UTF-8 text).
    """
    ref = load_ref(sha256)
    if ref is None or ref.kind != "text":
        return None
    try:
        return Path(ref.path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        logger.warning("Failed to load text attachment {}: {}", sha256, exc)
        return None


def load_for_outbound(sha256: str) -> dict[str, Any] | None:
    """Load an attachment for outbound relay (agent → channel).

    Returns a dict matching the ``OutboundAttachment`` wire shape (see
    ``design/cloud-gateway/attachments.md`` §4.5) — ``sha256``,
    ``content_type``, ``size``, ``kind``, ``name``, ``bytes_b64`` —
    or ``None`` when the sha is not in the local store.

    Bytes are read + base64-encoded inline; the channel renderer (Teams
    adaptive-card Image, Web Chat <img>) decodes them without a separate
    round-trip to the client.
    """
    ref = load_ref(sha256)
    if ref is None:
        return None
    try:
        data = Path(ref.path).read_bytes()
    except OSError as exc:
        logger.warning("Failed to read outbound attachment {}: {}", sha256, exc)
        return None
    return {
        "sha256": ref.sha256,
        "content_type": ref.content_type,
        "size": ref.size,
        "kind": ref.kind,
        "name": ref.name,
        "bytes_b64": base64.b64encode(data).decode("ascii"),
    }


def gc_unreferenced(active_sha256s: set[str], older_than: timedelta = timedelta(days=7)) -> int:
    """Delete attachment files not present in *active_sha256s* and older than the cutoff."""
    dir_ = attachments_dir()
    if not dir_.is_dir():
        return 0
    cutoff = datetime.now(UTC) - older_than
    removed = 0
    for p in dir_.iterdir():
        if not p.is_file():
            continue
        sha = p.stem
        if sha in active_sha256s:
            continue
        try:
            mtime = datetime.fromtimestamp(p.stat().st_mtime, tz=UTC)
        except OSError:
            continue
        if mtime > cutoff:
            continue
        try:
            p.unlink()
            removed += 1
        except OSError as exc:
            logger.warning("Failed to GC attachment {}: {}", p, exc)
    return removed
