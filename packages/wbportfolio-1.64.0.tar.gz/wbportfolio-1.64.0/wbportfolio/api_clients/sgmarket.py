"""
Societe Generale MAKS Order Entry API Client for Portfolio Rebalancing.

Provides an OIDC-authenticated interface to the SG Luxembourg MAKS Order Entry API,
supporting order submission (rebalancing) and status/execution/allocation reporting.

Authentication flow:
  1. The user authenticates interactively on the SG Markets IdP.
  2. The IdP callback returns a Bearer access token — this token is passed to the constructor.
  3. When the token expires the client raises — the user must re-authenticate via the IdP.

Key Features:
- Externally-supplied access token with expiry-aware validation (no silent refresh).
- Virtual portfolio fallback for testing/debug.
- Robust error handling with HTTP status validation.
- Timeout-configured requests for reliability.

Usage:
    client = SGMarketAPIClient(initial_access_token="<token from IdP callback>")
    result = client.submit_rebalancing(orders)
    status = client.get_order_status(request_id=result["requestId"])
"""

from datetime import datetime, timedelta
from json import JSONDecodeError
from typing import Any

import requests
from django.conf import settings
from django.utils import timezone
from requests import HTTPError


class SGMarketAPIClient:
    """Client for Societe Generale MAKS Order Entry API."""

    BASE_URL = "https://maks-api.lu.world.socgen"

    VIRTUAL_PORTFOLIO = "TEST_PORTFOLIO_001"

    def __init__(
        self,
        initial_access_token: str,
        token_expiry: datetime | None = None,
    ) -> None:
        """
        :param initial_access_token: Bearer token obtained from the SG Markets IdP callback.
        :param token_expiry: Datetime when the token expires. Defaults to 1 hour from now.
        """
        self.access_token = initial_access_token
        self.token_expiry = token_expiry or timezone.now() + timedelta(hours=1)

    def _is_token_expired(self) -> bool:
        """Check if the current token is expired or within 5 minutes of expiry."""
        return timezone.now() > self.token_expiry - timedelta(minutes=5)

    def _renew_token(self) -> None:
        """Raise when the token has expired — re-authentication must happen via the SG IdP."""
        raise ValueError("Access token has expired. Please re-authenticate via the SG Markets IdP.")

    def _get_headers(self) -> dict[str, str]:
        """Return request headers, validating token expiry first."""
        if self._is_token_expired():
            self._renew_token()
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }

    def _get_json(self, response: requests.Response) -> dict[str, Any]:
        """Safely parse JSON response, returning empty dict on failure."""
        try:
            return response.json()
        except JSONDecodeError:
            return {}

    def _raise_for_status(self, response: requests.Response) -> None:
        """Raise HTTPError on non-2xx responses, surfacing the API error message."""
        try:
            response.raise_for_status()
        except HTTPError as e:
            message = self._get_json(response).get("message", str(e))
            raise HTTPError(message, response=response) from e

    def _build_status_params(
        self,
        external_reference: str | None,
        order_id: str | None,
        request_id: str | None,
    ) -> dict[str, str]:
        """Build query params dict for status/execution/allocation endpoints."""
        if external_reference:
            return {"externalReference": external_reference}
        if order_id:
            return {"id": order_id}
        if request_id:
            return {"requestId": request_id}
        raise ValueError("One of external_reference, order_id, or request_id must be provided.")

    def submit_rebalancing(
        self,
        orders: list[dict[str, Any]],
        test: bool = False,
    ) -> dict[str, Any]:
        """
        Submit a batch of rebalancing orders to SG MAKS.

        Each order dict must include (per MAKS spec):
            - externalReference: client reference (str)
            - orderInitiator: order giver login (str)
            - portfolio: portfolio reference (str)
            - side: "BUY" or "SELL"
            - quantity: total quantity across accounts (int/float)
            - accounts: list of {"account": str, "quantityInUnit": int}
            - instrument: {"assetType": str, "currency": str, "ticker"|"isin": str, ...}
        Optional: orderType, goodTillDate, limit, stop, strategy, tradingInstructions.

        Args:
            orders: List of order dicts per the MAKS order creation contract.
            test: Replace portfolio references with virtual sandbox value if True.

        Returns:
            Dict with "requestId" (str) and "orders" list, each containing
            orderId, externalReference, status, and optional message.

        Raises:
            HTTPError: On API failure.
            ValueError: If the access token has expired.
        """
        if test or settings.DEBUG:
            for order in orders:
                order["portfolio"] = self.VIRTUAL_PORTFOLIO

        url = f"{self.BASE_URL}/order-entry/api/v1/orders"
        response = requests.post(url, json={"orders": orders}, headers=self._get_headers(), timeout=60)
        self._raise_for_status(response)
        return self._get_json(response)

    def get_order_status(
        self,
        *,
        external_reference: str | None = None,
        order_id: str | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Fetch order status by externalReference, SG orderId, or requestId.

        Returns:
            Dict with "requestId" and "orders" list, each containing
            orderId, externalReference, status (WORKING/EXECUTED/NACK/NOT_FOUND),
            and optional message on error.

        Raises:
            ValueError: If no query parameter is provided, or token has expired.
            HTTPError: On API failure.
        """
        params = self._build_status_params(external_reference, order_id, request_id)
        url = f"{self.BASE_URL}/order-entry/api/v1/orders/statuses"
        response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
        self._raise_for_status(response)
        return self._get_json(response)

    def get_order_executions(
        self,
        *,
        external_reference: str | None = None,
        order_id: str | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Fetch execution details for orders.

        Returns:
            Dict with "requestId" and "orders" list, each containing status,
            executedQty, averagePrice, workingQuantity, and "executions" array
            with executionId, executionTime, quantity, indicativePrice, currency,
            exchangePlace, brokerID, brokerName, canceled.

        Raises:
            ValueError: If no query parameter is provided, or token has expired.
            HTTPError: On API failure.
        """
        params = self._build_status_params(external_reference, order_id, request_id)
        url = f"{self.BASE_URL}/order-entry/api/v1/orders/executions"
        response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
        self._raise_for_status(response)
        return self._get_json(response)

    def get_order_allocations(
        self,
        *,
        external_reference: str | None = None,
        order_id: str | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Fetch allocation details for orders (post-execution settlement data).

        Returns:
            Dict with "requestId" and "orders" list, each containing allocatedQty,
            averagePrice, and "allocations" array with full settlement details
            (price, grossAmount, netAmount, charges, tradeDate, settlementDate, SSI, etc.).

        Raises:
            ValueError: If no query parameter is provided, or token has expired.
            HTTPError: On API failure.
        """
        params = self._build_status_params(external_reference, order_id, request_id)
        url = f"{self.BASE_URL}/order-entry/api/v1/orders/allocations"
        response = requests.get(url, headers=self._get_headers(), params=params, timeout=30)
        self._raise_for_status(response)
        return self._get_json(response)

    def validate_response(self, response: dict[str, Any]) -> dict[str, Any]:
        """
        Validate that no orders in the response are in a terminal error state.

        Returns:
            Response dict if all orders are non-error, else empty dict.
        """
        orders = response.get("orders", [])
        if orders and all(o.get("status") not in ("NACK", "NOT_FOUND", "ERROR") for o in orders):
            return response
        return {}
