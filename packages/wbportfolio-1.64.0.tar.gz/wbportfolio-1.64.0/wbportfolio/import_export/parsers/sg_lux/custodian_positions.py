from datetime import date
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd
from pandas.tseries.offsets import BDay
from schwifty import IBAN
from wbfdm.import_export.handlers.instrument import InstrumentLookup
from wbfdm.models import Instrument

from wbportfolio.models.portfolio import Portfolio

if TYPE_CHECKING:
    from wbcore.contrib.io.models import ImportSource

# Bank specific Information for Societe Generale Luxembourg
BANK_COUNTRY_CODE = "LU"
BANK_CODE = "060"


def get_fx_rate(ptf: Portfolio, instrument: Instrument | None, vdate: date) -> float | None:
    if not instrument:
        return None
    return float(instrument.currency.convert(vdate, ptf.currency, exact_lookup=True))


def get_price(instrument: Instrument | None, vdate: date) -> float | None:
    if not instrument:
        return None
    return float(instrument.get_price(vdate))


def parse(import_source: "ImportSource") -> dict:
    """Parse the custodian positions file into a dictionary"""
    lookup = InstrumentLookup(Instrument)
    # Get df from csv and rename columns and group by account number, isin, and date to sum the shares per date, account, and isin
    df = pd.read_csv(import_source.file.open(), encoding="latin1").rename(  # type: ignore
        columns={
            "Account number": "account_number",
            "ISIN code": "isin",
            "Quantity": "initial_shares",
            "Position date": "date",
            "Security name": "name",
        }
    )

    df = pd.DataFrame(
        df[["account_number", "isin", "initial_shares", "date", "name"]]
        .groupby(["account_number", "isin", "date", "name"])
        .sum()
    )
    df = df.reset_index()

    df["account_number"] = df["account_number"].astype(str)
    ptf_map = {
        account_number: Portfolio.all_objects.get(
            bank_accounts__iban=str(IBAN.generate(BANK_COUNTRY_CODE, bank_code=BANK_CODE, account_code=account_number))
        )
        for account_number in df["account_number"].unique()
    }

    # parse datetime string to date string and set to 1 day earlier
    df["date"] = pd.to_datetime(df["date"], format="%m/%d/%Y %I:%M:%S %p") - BDay(1)

    df["underlying_quote"] = df.apply(
        lambda row: lookup.lookup(
            only_security=False, isin=str(row["isin"]), name=str(row["name"]), instrument_type="equity"
        ),
        axis=1,
    )
    df["portfolio"] = df["account_number"].map(ptf_map)

    df["initial_currency_fx_rate"] = df.apply(
        lambda row: get_fx_rate(row["portfolio"], row["underlying_quote"], row["date"]), axis=1
    )
    df["initial_price"] = df.apply(lambda row: get_price(row["underlying_quote"], row["date"]), axis=1)
    df["is_estimated"] = False
    df["total_value"] = df["initial_shares"] * df["initial_currency_fx_rate"] * df["initial_price"]

    df["weighting"] = df.groupby(["account_number", "date"])["total_value"].transform(
        lambda s: s / s.sum() if s.sum() else 0
    )
    # Serialize to be savable in a json dtype
    df["date"] = df["date"].dt.strftime("%Y-%m-%d")
    df["portfolio"] = df["portfolio"].apply(lambda x: x.id)
    df["underlying_quote"] = df.apply(
        lambda x: x["underlying_quote"].id if x["underlying_quote"] else {"isin": x["isin"]}, axis=1
    )
    # remove name column
    df = df.drop(columns=["name", "account_number", "total_value", "isin"])
    df = df.replace([np.inf, -np.inf, np.nan], None)
    return {"data": df.to_dict("records")}
