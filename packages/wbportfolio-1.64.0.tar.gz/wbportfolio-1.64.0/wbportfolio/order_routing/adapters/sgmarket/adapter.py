from django.conf import settings
from requests import HTTPError

from wbportfolio.api_clients.sgmarket import SGMarketAPIClient
from wbportfolio.order_routing.adapters.base import BaseCustodianAdapter
from wbportfolio.order_routing.adapters.sgmarket.model import SGMarketExecutionOrder, SGMarketOrder
from wbportfolio.order_routing.exception import RoutingError
from wbportfolio.order_routing.model import ExecutionStatus, Order

STATUS_MAP = {
    "WORKING": ExecutionStatus.PENDING,
    "EXECUTED": ExecutionStatus.COMPLETED,
    "NACK": ExecutionStatus.REJECTED,
    "NOT_FOUND": ExecutionStatus.UNKNOWN,
    "ERROR": ExecutionStatus.FAILED,
}


class CustodianAdapter(BaseCustodianAdapter):
    client: SGMarketAPIClient
    order_model = SGMarketOrder

    def __init__(self, *args, raise_exception: bool = False, **kwargs):
        super().__init__(*args, **kwargs)
        self.rebalancing_id = self.execution_kwarg.get("requestId")
        self.raise_exception = raise_exception

    def _handle_response(self, res: dict) -> None:
        for order in res.get("orders", []):
            if message := order.get("message"):
                self.logger.warning("SG Market order %s: %s", order.get("externalReference"), message)
                if self.raise_exception:
                    raise RoutingError(message)

    def authenticate(self) -> bool:
        """Initialise the API client with the bearer token from settings."""
        self.client = SGMarketAPIClient(
            initial_access_token=settings.SGMARKET_API_TOKEN,
        )
        return True

    def is_valid(self) -> bool:
        """Verify the token is still valid and the API is reachable."""
        try:
            res = self.client.get_order_status(external_reference=self.isin)
            return "orders" in res
        except (HTTPError, KeyError, ValueError) as e:
            self.logger.warning("Couldn't validate SG Market adapter: %s", e)
            return False

    def submit_rebalancing(self, items: list[dict], as_draft: bool = True) -> tuple[list[dict], str, dict]:
        """
        Submit a batch of orders to SG MAKS.

        Enriches each serialised order with portfolio, orderInitiator, and accounts
        from the adapter context before forwarding to the API client.
        Draft mode is not supported by MAKS — if requested, a warning is logged and
        the orders are submitted live.
        """
        if as_draft:
            self.logger.warning("SG Market adapter does not support draft mode — submitting live")

        account = self.execution_kwarg.get("account")

        for item in items:
            # inject the reference_id and account into the order dictionary
            item["portfolio"] = self.reference_id
            if account:
                item["accounts"] = [
                    {"account": account, "quantityInUnit": item["quantity"]}
                ]  # we assume a unique account

        res = self.client.submit_rebalancing(items)
        self._handle_response(res)

        request_id = res.get("requestId", "")
        return items, f"Submitted rebalancing request {request_id}", {"requestId": request_id}

    def cancel_current_rebalancing(self) -> bool:
        """MAKS does not expose a cancellation endpoint."""
        self.logger.warning("SG Market adapter does not support order cancellation")
        return False

    def get_rebalance_status(self) -> tuple[ExecutionStatus, str, str]:
        """
        Aggregate status across all orders in the last submitted request.

        WORKING in any order → PENDING; all EXECUTED → COMPLETED; any NACK/ERROR → REJECTED.
        """
        try:
            if self.rebalancing_id:
                res = self.client.get_order_status(request_id=self.rebalancing_id)
            else:
                res = self.client.get_order_status(external_reference=self.isin)

            self._handle_response(res)
            orders = res.get("orders", [])
            if not orders:
                return ExecutionStatus.UNKNOWN, "", ""

            statuses = {o.get("status", "") for o in orders}
            if "WORKING" in statuses:
                raw_status = "WORKING"
            elif statuses & {"NACK", "ERROR"}:
                raw_status = "NACK"
            elif statuses == {"EXECUTED"}:
                raw_status = "EXECUTED"
            else:
                raw_status = ""

            message = "; ".join(o["message"] for o in orders if o.get("message"))
            return STATUS_MAP.get(raw_status, ExecutionStatus.UNKNOWN), raw_status, message

        except (HTTPError, KeyError, ValueError) as e:
            self.logger.warning("Error fetching SG Market rebalance status: %s", e)
            return ExecutionStatus.UNKNOWN, "", str(e)

    def get_current_rebalancing(self) -> list[dict]:
        """Return the execution details for the current rebalancing request."""
        if self.rebalancing_id:
            res = self.client.get_order_executions(request_id=self.rebalancing_id)
        else:
            res = self.client.get_order_executions(external_reference=self.isin)
        self._handle_response(res)
        return res.get("orders", [])

    def deserialize_rebalancing_request_items(self, item) -> Order:
        return SGMarketExecutionOrder.model_validate(item).to_order(self.rebalance_date)
