from datetime import date
from typing import Any

from pydantic import BaseModel

from wbportfolio.order_routing.model import Order

from ...model import ExecutionInstruction
from ..base import AdapterOrder

EXECUTION_INSTRUCTION_TO_ORDER_TYPE = {
    ExecutionInstruction.MARKET: "MARKET",
    ExecutionInstruction.MARKET_ON_CLOSE: "MARKET_ON_CLOSE)",
    ExecutionInstruction.LIMIT: "LIMIT",
    ExecutionInstruction.STOP: "STOP",
    ExecutionInstruction.STOP_LIMIT: "STOP_LIMIT",
}


class SGMarketInstrument(BaseModel):
    assetType: str  # noqa: N815
    ticker: str | None = None
    isin: str | None = None
    currency: str = "EUR"
    exchangePlace: str | None = None  # noqa: N815


class SGMarketOrder(AdapterOrder):
    """Represents a single order in the MAKS submission format."""

    externalReference: str  # noqa: N815
    orderInitiator: str  # noqa: N815
    side: str
    quantity: float
    strategy: str
    orderType: str = "MARKET"  # noqa: N815
    goodTillDate: str | None = None  # noqa: N815
    tradingInstructions: str | None = None  # noqa: N815
    instrument: SGMarketInstrument
    portfolio: str | None = None
    accounts: list[dict[str, Any]] | None = None
    limit: float | None = None
    stop: float | None = None

    @classmethod
    def from_order(cls, order: Order, **kwargs) -> "SGMarketOrder":
        ticker = order.ticker if order.ticker else None
        isin = order.isin if not order.ticker else None

        if order.shares is not None:
            side = "SELL" if order.shares < 0 else "BUY"
            quantity = abs(order.shares)
        else:
            side = "BUY"
            quantity = abs(order.target_weight or 0)

        if order.execution_instruction not in EXECUTION_INSTRUCTION_TO_ORDER_TYPE:
            raise ValueError(f"Invalid execution instruction for sgmarket: {order.execution_instruction}")
        limit = order.execution_instruction_parameters.get("limit") if order.execution_instruction_parameters else None
        stop = order.execution_instruction_parameters.get("stop") if order.execution_instruction_parameters else None
        if limit is None and order.execution_instruction in [
            ExecutionInstruction.LIMIT,
            ExecutionInstruction.STOP_LIMIT,
        ]:
            raise ValueError("Limit value is needed when execution type is of type LIMIT")
        if stop is None and order.execution_instruction in [
            ExecutionInstruction.STOP,
            ExecutionInstruction.STOP_LIMIT,
        ]:
            raise ValueError("stop value is needed when execution type is of type STOP")

        return cls.model_validate(
            {
                "externalReference": str(order.id),
                "orderInitiator": order.user_email,
                "side": side,
                "quantity": quantity,
                "orderType": EXECUTION_INSTRUCTION_TO_ORDER_TYPE[order.execution_instruction],
                "goodTillDate": order.trade_date.strftime("%Y-%m-%d"),
                "tradingInstructions": order.comment,
                "accounts": [],
                "instrument": {
                    "assetType": order.asset_class.value,
                    "ticker": ticker,
                    "isin": isin,
                    "currency": order.currency,
                    "exchangePlace": order.exchange_mic,
                },
                "limit": limit,
                "stop": stop,
                "strategy": "CTD",  # Call the Desk, default strategy. For other, see MAKS documentation
            }
        )

    def to_order(self, rebalance_date: date) -> Order:
        signed_quantity = self.quantity if self.side == "BUY" else -self.quantity
        return Order(
            id=self.externalReference,
            asset_class=Order.AssetType.EQUITY,
            ticker=self.instrument[0].ticker,
            isin=self.instrument[0].isin,
            trade_date=rebalance_date,
            target_weight=signed_quantity,
            shares=signed_quantity,
        )


class SGMarketExecutionOrder(BaseModel):
    """Represents an order item in the MAKS executions/status response."""

    orderId: str | None = None  # noqa: N815
    externalReference: str  # noqa: N815
    status: str
    executedQty: float | None = None  # noqa: N815
    averagePrice: float | None = None  # noqa: N815
    workingQuantity: float | None = None  # noqa: N815
    executions: list[dict[str, Any]] = []

    def to_order(self, rebalance_date: date) -> Order:
        return Order(
            id=self.externalReference,
            asset_class=Order.AssetType.EQUITY,
            trade_date=rebalance_date,
            target_weight=0,
            shares=self.executedQty,
            execution_price=self.averagePrice,
        )
