"""Game name resolution — tiered strategy for app ID → game name."""

from __future__ import annotations

import json
import re
import time
from pathlib import Path

import httpx

from steam_clip_tui.constants import (
    default_steam_librarycache_path,
    default_steam_libraryfolders_path,
)


class GameNameResolver:
    """Resolves Steam app IDs to game names using tiered caching."""

    def __init__(
        self,
        libraryfolders_path: Path | None = None,
        cache_path: Path | None = None,
    ):
        """Initialize the resolver with optional path overrides."""
        self._libraryfolders_path = libraryfolders_path or default_steam_libraryfolders_path()
        self._cache_path = cache_path
        self._memory_cache: dict[int, str] = {}
        self._disk_cache: dict[int, dict] = {}
        self._http: httpx.AsyncClient | None = None
        self._install_map: dict[int, Path] | None = None
        self._cache_dirty = False

    async def resolve(self, app_id: int) -> str:
        """Resolve an app ID to a game name using cache and API fallback."""
        # 1. memory cache
        if app_id in self._memory_cache:
            return self._memory_cache[app_id]

        # 2. disk cache
        name = self._read_disk_cache(app_id)
        if name:
            self._memory_cache[app_id] = name
            return name

        # 3. local appmanifest
        name = self._resolve_from_appmanifest(app_id)
        if name:
            self._memory_cache[app_id] = name
            self._write_disk_cache(app_id, name)
            return name

        # 4. Steam Web API
        name = await self._resolve_from_api(app_id)
        if name:
            self._memory_cache[app_id] = name
            self._write_disk_cache(app_id, name)
            return name

        # 5. fallback
        fallback = f"App {app_id}"
        self._memory_cache[app_id] = fallback
        return fallback

    def _build_install_map(self) -> dict[int, Path]:
        """Parse libraryfolders.vdf to map appid → install directory."""
        if self._install_map is not None:
            return self._install_map

        result: dict[int, Path] = {}
        vdf_path = self._libraryfolders_path
        if not vdf_path.exists():
            self._install_map = result
            return result

        try:
            text = vdf_path.read_text()
            data = _parse_vdf(text)
            if "libraryfolders" in data:
                for _key, folder_data in data["libraryfolders"].items():
                    if not isinstance(folder_data, dict):
                        continue
                    lib_path = Path(folder_data.get("path", ""))
                    apps = folder_data.get("apps", {})
                    if isinstance(apps, dict):
                        for app_id_str in apps:
                            result[int(app_id_str)] = lib_path
        except Exception:
            pass

        self._install_map = result
        return result

    def _resolve_from_appmanifest(self, app_id: int) -> str | None:
        install_map = self._build_install_map()
        lib_path = install_map.get(app_id)
        if lib_path is None:
            return None

        manifest = lib_path / "steamapps" / f"appmanifest_{app_id}.acf"
        if not manifest.exists():
            return None

        try:
            text = manifest.read_text()
            data = _parse_vdf(text)
            app_state = data.get("AppState", {})
            name = app_state.get("name")
            if name:
                return name
        except Exception:
            pass
        return None

    async def _resolve_from_api(self, app_id: int) -> str | None:
        if self._http is None:
            self._http = httpx.AsyncClient(timeout=httpx.Timeout(10.0))
        try:
            resp = await self._http.get(
                "https://store.steampowered.com/api/appdetails",
                params={"appids": app_id},
            )
            resp.raise_for_status()
            data = resp.json()
            app_data = data.get(str(app_id), {})
            if app_data.get("success"):
                return app_data["data"].get("name")
        except Exception:
            pass
        return None

    def _read_disk_cache(self, app_id: int) -> str | None:
        if not self._disk_cache:
            self._load_disk_cache()
        entry = self._disk_cache.get(str(app_id))
        if entry:
            name = entry.get("name")
            if name:
                return name
        return None

    def _write_disk_cache(self, app_id: int, name: str):
        self._disk_cache[str(app_id)] = {"name": name, "ts": int(time.time())}
        self._cache_dirty = True

    def _load_disk_cache(self):
        if not self._cache_path:
            return
        try:
            if self._cache_path.exists():
                self._disk_cache = json.loads(self._cache_path.read_text())
        except (json.JSONDecodeError, OSError):
            self._disk_cache = {}

    def _save_disk_cache(self):
        if not self._cache_path:
            return
        try:
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            self._cache_path.write_text(json.dumps(self._disk_cache, indent=2))
        except OSError:
            pass

    async def close(self):
        """Flush pending cache writes and close the HTTP client session."""
        if self._cache_dirty:
            self._save_disk_cache()
            self._cache_dirty = False
        if self._http:
            await self._http.aclose()
            self._http = None

    _ICON_RE = re.compile(r"^[0-9a-f]{40}\.jpg$")

    def resolve_icon(self, app_id: int) -> Path | None:
        """Resolve a game icon from local Steam librarycache."""
        cache_dir = default_steam_librarycache_path(app_id)
        if not cache_dir.is_dir():
            return None
        for entry in cache_dir.iterdir():
            if entry.suffix == ".jpg" and self._ICON_RE.match(entry.name):
                return entry
        return None

    def resolve_icons(self, app_ids: list[int]) -> list[Path | None]:
        """Resolve icons for multiple app IDs."""
        return [self.resolve_icon(aid) for aid in app_ids]


def _parse_vdf(text: str) -> dict:
    """Parse Valve Data Format text into a nested dictionary."""
    result: dict = {}
    tokens = _tokenize_vdf(text)
    pos = 0

    def _read_value():
        nonlocal pos
        if pos >= len(tokens):
            return None
        tok = tokens[pos]
        pos += 1
        if tok == "{":
            obj = {}
            while pos < len(tokens) and tokens[pos] != "}":
                key = tokens[pos]
                pos += 1
                obj[key] = _read_value()
            pos += 1  # skip '}'
            return obj
        return tok

    while pos < len(tokens):
        if tokens[pos] == "}":
            break
        key = tokens[pos]
        pos += 1
        result[key] = _read_value()

    return result


def _tokenize_vdf(text: str) -> list[str]:
    """Tokenize VDF text into a list of string tokens."""
    tokens = []
    i = 0
    while i < len(text):
        c = text[i]
        if c in ("{", "}"):
            tokens.append(c)
            i += 1
        elif c == '"':
            i += 1
            start = i
            while i < len(text) and text[i] != '"':
                if text[i] == "\\":
                    i += 1
                i += 1
            tokens.append(text[start:i])
            i += 1
        else:
            i += 1
    return tokens
