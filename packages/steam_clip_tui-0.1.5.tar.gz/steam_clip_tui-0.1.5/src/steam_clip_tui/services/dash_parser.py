"""Parse MPEG-DASH session.mpd XML manifest for clip metadata."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING
from xml.etree import ElementTree

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class DashInfo:
    """Parsed MPEG-DASH manifest metadata."""

    duration_seconds: float
    width: int
    height: int
    video_codec: str
    audio_codec: str
    timescale: int
    segment_duration_us: int


def _parse_iso8601_duration(dur: str) -> float:
    """Parse ISO 8601 duration like 'PT38.868S' or 'PT1H2M3.5S'."""
    match = re.match(r"PT(?:(\d+)H)?(?:(\d+)M)?([\d.]+)S", dur)
    if not match:
        return 0.0
    h, m, s = match.groups()
    return int(h or 0) * 3600 + int(m or 0) * 60 + float(s)


class DashManifestParser:
    """Parser for MPEG-DASH session.mpd XML manifests."""

    def parse(self, mpd_path: Path) -> DashInfo | None:
        """Parse an MPD file and return extracted metadata, or None if invalid."""
        if not mpd_path.exists():
            return None
        try:
            tree = ElementTree.parse(str(mpd_path))
            root = tree.getroot()
        except ElementTree.ParseError:
            return None

        ns = {"mpd": "urn:mpeg:dash:schema:mpd:2011"}

        duration_str = root.get("mediaPresentationDuration", "PT0S")
        duration = _parse_iso8601_duration(duration_str)

        max_seg = root.get("maxSegmentDuration", "PT3.0S")
        seg_duration_us = int(_parse_iso8601_duration(max_seg) * 1_000_000)

        width = 0
        height = 0
        video_codec = ""
        audio_codec = ""
        timescale = 1000000

        for adapt in root.findall(".//mpd:AdaptationSet", ns):
            content_type = adapt.get("contentType", "")
            for rep in adapt.findall("mpd:Representation", ns):
                mime = rep.get("mimeType", "")
                if content_type == "video" and "video" in mime:
                    width = int(rep.get("width", 0))
                    height = int(rep.get("height", 0))
                    video_codec = rep.get("codecs", "")
                    seg_template = adapt.find("mpd:SegmentTemplate", ns)
                    if seg_template is not None:
                        timescale = int(seg_template.get("timescale", "1000000"))
                elif content_type == "audio" and "audio" in mime:
                    audio_codec = rep.get("codecs", "")

        return DashInfo(
            duration_seconds=duration,
            width=width,
            height=height,
            video_codec=video_codec,
            audio_codec=audio_codec,
            timescale=timescale,
            segment_duration_us=seg_duration_us,
        )
