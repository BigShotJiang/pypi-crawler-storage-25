"""Steam clip scanner — walks userdata and builds Clip/Game tree."""

from __future__ import annotations

import json
import re
from datetime import datetime
from typing import TYPE_CHECKING

from steam_clip_tui.constants import (
    CLIP_DIR_PATTERN,
    SESSION_MPD_FILENAME,
    THUMBNAIL_FILENAME,
    TIMELINES_DIR_NAME,
    VIDEO_DIR_NAME,
    default_steam_userdata_path,
)
from steam_clip_tui.models.clip import Clip
from steam_clip_tui.models.game import Game
from steam_clip_tui.services.dash_parser import DashManifestParser

if TYPE_CHECKING:
    from pathlib import Path

_DIR_RE = re.compile(r"clip_(\d+)_(\d{8})_(\d{6})")


def _parse_clip_dirname(dirname: str) -> tuple[int, datetime] | None:
    m = _DIR_RE.match(dirname)
    if not m:
        return None
    app_id = int(m.group(1))
    try:
        dt = datetime.strptime(f"{m.group(2)}{m.group(3)}", "%Y%m%d%H%M%S")
    except ValueError:
        dt = datetime.min
    return app_id, dt


class SteamClipScanner:
    """Scans Steam userdata directories to discover game clips."""

    def __init__(self, userdata_path: Path | None = None):
        """Initialize the scanner with an optional userdata path override."""
        self._userdata = userdata_path or default_steam_userdata_path()
        self._dash_parser = DashManifestParser()

    async def scan(self) -> list[Game]:
        """Scan the userdata directory and return a list of games with clips."""
        if not self._userdata.exists():
            return []

        clips_by_app: dict[int, list[Clip]] = {}

        try:
            steamid_dirs = list(self._userdata.iterdir())
        except OSError:
            return []

        for steamid_dir in steamid_dirs:
            clips_dir = steamid_dir / "gamerecordings" / "clips"
            if not clips_dir.exists():
                continue

            for clip_dir in sorted(clips_dir.iterdir()):
                if not clip_dir.is_dir() or not clip_dir.name.startswith(CLIP_DIR_PATTERN):
                    continue

                clip = self._scan_clip(clip_dir)
                if clip is None:
                    continue

                clips_by_app.setdefault(clip.app_id, []).append(clip)

        games = [
            Game(app_id=app_id, name=f"App {app_id}", clips=clips)
            for app_id, clips in sorted(clips_by_app.items())
        ]
        games.sort(key=lambda g: g.latest_clip_date or datetime.min, reverse=True)
        for game in games:
            game.clips.sort(key=lambda c: c.date, reverse=True)
        return games

    def _scan_clip(self, clip_dir: Path) -> Clip | None:
        parsed = _parse_clip_dirname(clip_dir.name)
        if parsed is None:
            return None
        app_id, date = parsed

        timeline_name = ""
        daterecorded = 0
        start_offset_ms = 0.0
        timeline_dir = clip_dir / TIMELINES_DIR_NAME
        if timeline_dir.exists():
            timeline_files = sorted(timeline_dir.glob("*.json"))
            if timeline_files:
                try:
                    data = json.loads(timeline_files[-1].read_text())
                    timeline_name = timeline_files[-1].stem
                    daterecorded = int(data.get("daterecorded", 0))
                    start_offset_ms = float(data.get("starttime", 0))
                except (json.JSONDecodeError, ValueError):
                    pass

        thumb_path = clip_dir / THUMBNAIL_FILENAME
        if not thumb_path.exists():
            thumb_path = None

        video_dir: Path | None = None
        fg_name = ""
        has_video = False
        file_size = 0
        duration = 0.0
        width = 0
        height = 0
        video_codec = ""
        audio_codec = ""

        video_parent = clip_dir / VIDEO_DIR_NAME
        if video_parent.exists():
            for fg_dir in sorted(video_parent.iterdir()):
                if fg_dir.is_dir():
                    video_dir = fg_dir
                    fg_name = fg_dir.name
                    break
            if video_dir is not None:
                mpd = video_dir / SESSION_MPD_FILENAME
                dash_info = self._dash_parser.parse(mpd)
                if dash_info is not None:
                    duration = dash_info.duration_seconds
                    width = dash_info.width
                    height = dash_info.height
                    video_codec = dash_info.video_codec
                    audio_codec = dash_info.audio_codec
                    all_segments = sorted(video_dir.glob("*-stream*.m4s"))
                    chunks = [f for f in all_segments if "stream0-" in f.name]
                    inits = [f for f in all_segments if f.name.startswith("init-stream")]
                    has_video = len(chunks) > 0 and len(inits) > 0
                    if has_video:
                        file_size = sum(f.stat().st_size for f in all_segments)

        return Clip(
            app_id=app_id,
            clip_dir=clip_dir,
            date=date,
            timeline_name=timeline_name,
            daterecorded=daterecorded,
            start_offset_ms=start_offset_ms,
            duration_seconds=duration,
            width=width,
            height=height,
            video_codec=video_codec,
            audio_codec=audio_codec,
            thumbnail_path=thumb_path,
            video_dir=video_dir,
            fg_name=fg_name,
            has_video=has_video,
            file_size_bytes=file_size,
        )
