"""Clip exporter — converts DASH segments to MP4 via ffmpeg subprocess."""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from steam_clip_tui.models.clip import Clip
    from steam_clip_tui.models.export_settings import ExportSettings

_TIME_PATTERN = re.compile(r"time=(\d+):(\d+):(\d+)\.(\d+)")


@dataclass
class ExportProgress:
    """Progress information for an ongoing export operation."""

    percent: float
    time_seconds: float
    status: str  # "running", "complete", "error"


class ClipExporter:
    """Exports Steam game clips to MP4 using ffmpeg."""

    async def export(
        self,
        clip: Clip,
        settings: ExportSettings,
        progress_callback=None,
    ) -> Path:
        """Export a clip to the specified output path with progress reporting."""
        if not clip.has_video or clip.video_dir is None:
            raise ValueError("Clip has no video data")

        output_path = self._make_output_path(clip, settings)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        args = self._build_ffmpeg_args(clip, settings, output_path)
        process = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        duration = clip.duration_seconds
        stderr_lines: list[str] = []

        async def read_progress():
            while True:
                line = await process.stderr.readline()
                if not line:
                    break
                decoded = line.decode("utf-8", errors="replace")
                stderr_lines.append(decoded)
                m = _TIME_PATTERN.search(decoded)
                if m and duration > 0:
                    h, mi, s, _ = m.groups()
                    elapsed = int(h) * 3600 + int(mi) * 60 + float(s)
                    pct = min(elapsed / duration * 100, 100)
                    if progress_callback:
                        await progress_callback(
                            ExportProgress(
                                percent=pct,
                                time_seconds=elapsed,
                                status="running",
                            )
                        )

        read_task = asyncio.ensure_future(read_progress())
        await process.wait()
        await read_task

        if process.returncode != 0:
            stderr_text = "".join(stderr_lines)
            raise RuntimeError(f"ffmpeg exited with code {process.returncode}: {stderr_text[:500]}")

        if progress_callback:
            await progress_callback(
                ExportProgress(percent=100, time_seconds=duration, status="complete")
            )

        return output_path

    def _build_ffmpeg_args(self, clip: Clip, settings: ExportSettings, output: Path) -> list[str]:
        args = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "info"]

        if settings.hwaccel:
            args.extend(["-hwaccel", settings.hwaccel])

        video_files = sorted(clip.video_dir.glob("init-stream0.m4s"))
        video_files += sorted(clip.video_dir.glob("chunk-stream0-*.m4s"))
        if not video_files:
            raise ValueError("No video segments found")
        args.extend(["-i", "concat:" + "|".join(str(f) for f in video_files)])

        audio_files = sorted(clip.video_dir.glob("init-stream1.m4s"))
        audio_files += sorted(clip.video_dir.glob("chunk-stream1-*.m4s"))
        if not audio_files:
            raise ValueError("No audio segments found")
        args.extend(["-i", "concat:" + "|".join(str(f) for f in audio_files)])

        args.extend(["-c:v", settings.video_codec])
        if settings.video_codec != "copy":
            args.extend(["-b:v", settings.video_bitrate])

        args.extend(["-c:a", settings.audio_codec])

        scale = settings.resolution_scale
        if scale is not None:
            args.extend(["-vf", f"scale={scale}:force_original_aspect_ratio=decrease"])

        args.extend(["-f", settings.container])
        args.append(str(output))

        return args

    def _make_output_path(self, clip: Clip, settings: ExportSettings) -> Path:
        game_name = f"app_{clip.app_id}"
        filename = _apply_template(
            settings.filename_template,
            game=game_name,
            date=clip.date.strftime("%Y-%m-%d"),
            time=clip.date.strftime("%H%M%S"),
            appid=str(clip.app_id),
            ext=settings.container,
        )
        return settings.output_dir / filename


def _apply_template(template: str, **kwargs) -> str:
    """Apply template variables to a filename template string."""
    result = template
    for key, val in kwargs.items():
        result = result.replace("{" + key + "}", str(val))
    return result
