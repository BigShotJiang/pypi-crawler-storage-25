"""Services for scanning, exporting, and resolving game names."""
