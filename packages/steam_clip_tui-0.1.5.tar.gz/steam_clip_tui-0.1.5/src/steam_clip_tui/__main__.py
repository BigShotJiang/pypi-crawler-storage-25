"""Entry point for steam-clip-tui."""

from steam_clip_tui.app import main

if __name__ == "__main__":
    main()
