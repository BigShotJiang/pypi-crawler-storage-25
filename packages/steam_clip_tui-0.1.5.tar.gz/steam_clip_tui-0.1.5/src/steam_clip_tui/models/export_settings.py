"""Export settings model for configuring video output."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar


@dataclass
class ExportSettings:
    """Configuration for video export including codec, resolution, and output paths."""

    output_dir: Path = field(default_factory=lambda: Path.home() / "Movies" / "SteamClips")
    container: str = "mp4"
    video_codec: str = "copy"
    audio_codec: str = "copy"
    resolution: str = "source"
    filename_template: str = "{game}/{date}_{time}.{ext}"
    video_bitrate: str = "12M"
    hwaccel: str = ""

    CODEC_CHOICES: ClassVar[list[tuple[str, str]]] = [
        ("copy", "Copy (no re-encode)"),
        ("libx264", "H.264 (CPU)"),
        ("libx265", "H.265 (CPU)"),
        ("h264_videotoolbox", "H.264 (VideoToolbox)"),
        ("hevc_videotoolbox", "H.265 (VideoToolbox)"),
    ]

    RESOLUTION_CHOICES: ClassVar[list[tuple[str, str]]] = [
        ("source", "Source"),
        ("1080p", "1080p"),
        ("720p", "720p"),
        ("480p", "480p"),
    ]

    @property
    def resolution_scale(self) -> str | None:
        """Return the scale filter value for the configured resolution."""
        match self.resolution:
            case "1080p":
                return "1920:1080"
            case "720p":
                return "1280:720"
            case "480p":
                return "854:480"
            case _:
                return None
