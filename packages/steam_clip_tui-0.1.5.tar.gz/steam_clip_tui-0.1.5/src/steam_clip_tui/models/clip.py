"""Clip data model representing a single Steam game recording clip."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime
    from pathlib import Path


@dataclass
class Clip:
    """Data model for a single Steam game recording clip."""

    app_id: int
    clip_dir: Path
    date: datetime
    timeline_name: str = ""
    daterecorded: int = 0
    start_offset_ms: float = 0.0
    duration_seconds: float = 0.0
    width: int = 0
    height: int = 0
    video_codec: str = ""
    audio_codec: str = ""
    thumbnail_path: Path | None = None
    video_dir: Path | None = None
    fg_name: str = ""
    has_video: bool = False
    file_size_bytes: int = 0
    selected: bool = False

    @property
    def display_date(self) -> str:
        """Return the clip date formatted for display."""
        return self.date.strftime("%Y-%m-%d %H:%M")

    @property
    def display_duration(self) -> str:
        """Return the clip duration formatted as M:SS."""
        mins, secs = divmod(int(self.duration_seconds), 60)
        return f"{mins}:{secs:02d}"

    @property
    def resolution_str(self) -> str:
        """Return the resolution as a WxH string."""
        if self.width and self.height:
            return f"{self.width}x{self.height}"
        return "unknown"

    @property
    def file_size_mb(self) -> float:
        """Return the actual file size in MB from DASH segments on disk."""
        if not self.has_video or self.file_size_bytes <= 0:
            return 0.0
        return self.file_size_bytes / (1024 * 1024)
