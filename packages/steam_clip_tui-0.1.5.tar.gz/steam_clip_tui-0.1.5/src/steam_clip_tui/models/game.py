"""Game data model grouping clips by Steam app ID."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from steam_clip_tui.models.clip import Clip


@dataclass
class Game:
    """Data model grouping clips by Steam app ID."""

    app_id: int
    name: str
    clips: list[Clip] = field(default_factory=list)
    icon_path: Path | None = None

    @property
    def clip_count(self) -> int:
        """Return the number of clips for this game."""
        return len(self.clips)

    @property
    def latest_clip_date(self):
        """Return the date of the most recent clip, or None if no clips."""
        if not self.clips:
            return None
        return max(c.date for c in self.clips)
