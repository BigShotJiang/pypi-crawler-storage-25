"""Configuration management with TOML loading and XDG paths."""

from __future__ import annotations

import shutil
import tomllib
from pathlib import Path

import platformdirs

CONFIG_FILENAME = "config.toml"
DEFAULT_CONFIG = Path(__file__).resolve().parent.parent.parent / "config.default.toml"


def _default_config_path() -> Path:
    return platformdirs.user_config_path("steam-clip-tui") / CONFIG_FILENAME


def _cache_path() -> Path:
    return platformdirs.user_cache_path("steam-clip-tui")


class Config:
    """Configuration manager with TOML loading and XDG-compliant paths."""

    def __init__(self, config_path: Path | None = None):
        """Initialize config from the given path or default location."""
        self._path = config_path or _default_config_path()
        self._data: dict = {}
        self._load()

    def _load(self):
        if not self._path.exists():
            self._path.parent.mkdir(parents=True, exist_ok=True)
            if DEFAULT_CONFIG.exists():
                shutil.copy(DEFAULT_CONFIG, self._path)
            else:
                self._path.write_text("# steam-clip-tui configuration\n")
        with open(self._path, "rb") as f:
            self._data = tomllib.load(f)

    def save(self):
        """Save the current configuration to disk."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        text = _to_toml(self._data)
        self._path.write_text(text)

    @property
    def steam_userdata_path(self) -> Path | None:
        """Return the configured Steam userdata directory path."""
        raw = self._data.get("paths", {}).get("steam_userdata")
        if raw:
            return Path(raw).expanduser().resolve()
        return None

    @property
    def steam_libraryfolders_path(self) -> Path | None:
        """Return the configured Steam libraryfolders.vdf path."""
        raw = self._data.get("paths", {}).get("steam_libraryfolders")
        if raw:
            return Path(raw).expanduser().resolve()
        return None

    @property
    def show_game_icons(self) -> bool:
        """Whether to show game icons in the UI."""
        return self._data.get("ui", {}).get("show_game_icons", True)

    @property
    def show_clip_preview(self) -> bool:
        """Whether to show clip thumbnail preview."""
        return self._data.get("ui", {}).get("show_clip_preview", True)

    @property
    def date_format(self) -> str:
        """Return the configured date format string."""
        return self._data.get("ui", {}).get("date_format", "%Y-%m-%d %H:%M")

    @property
    def output_dir(self) -> Path:
        """Return the configured export output directory."""
        raw = self._data.get("export", {}).get("output_dir", "~/Movies/SteamClips")
        return Path(raw).expanduser().resolve()

    @property
    def video_codec(self) -> str:
        """Return the configured video codec."""
        return self._data.get("export", {}).get("video_codec", "copy")

    @property
    def audio_codec(self) -> str:
        """Return the configured audio codec."""
        return self._data.get("export", {}).get("audio_codec", "copy")

    @property
    def resolution(self) -> str:
        """Return the configured export resolution."""
        return self._data.get("export", {}).get("resolution", "source")

    @property
    def filename_template(self) -> str:
        """Return the configured filename template for exports."""
        return self._data.get("export", {}).get("filename_template", "{game}/{date}_{time}.{ext}")

    @property
    def video_bitrate(self) -> str:
        """Return the configured video bitrate."""
        return self._data.get("export", {}).get("video_bitrate", "12M")

    @property
    def hwaccel(self) -> str:
        """Return the configured hardware acceleration method."""
        return self._data.get("export", {}).get("hwaccel", "")

    @property
    def name_cache_ttl_days(self) -> int:
        """Return the TTL in days for cached game names."""
        return self._data.get("cache", {}).get("name_cache_ttl_days", 30)

    def cachedir(self) -> Path:
        """Return the cache directory, creating it if needed."""
        p = _cache_path()
        p.mkdir(parents=True, exist_ok=True)
        return p

    def appnames_cache_path(self) -> Path:
        """Return the path to the app names cache file."""
        return self.cachedir() / "appnames.json"

    def get_cached_app_name(self, app_id: int) -> str | None:
        """Return a cached app name by ID, or None if not cached."""
        names = self._data.get("cache", {}).get("app_names", {})
        return names.get(str(app_id))


def _to_toml(data: dict, indent: str = "") -> str:  # noqa: ARG001
    """Serialize config data to TOML format."""
    lines = []
    for section, values in data.items():
        if isinstance(values, dict):
            lines.append(f"[{section}]")
            for k, v in values.items():
                lines.append(_format_kv(k, v))
        else:
            lines.append(_format_kv(section, values))
    return "\n".join(lines) + "\n"


def _format_kv(key: str, value) -> str:
    if isinstance(value, bool):
        return f"{key} = {str(value).lower()}"
    if isinstance(value, (int, float)):
        return f"{key} = {value}"
    return f'{key} = "{value}"'
