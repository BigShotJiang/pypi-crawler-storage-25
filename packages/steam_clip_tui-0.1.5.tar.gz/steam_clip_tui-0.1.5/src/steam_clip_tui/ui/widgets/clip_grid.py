"""Clip list widget."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import TYPE_CHECKING

from textual.message import Message
from textual.widgets import Label, ListItem, ListView

if TYPE_CHECKING:
    from steam_clip_tui.models.clip import Clip


class ClipSelected(Message):
    """Message posted when a clip is selected in the grid."""

    def __init__(self, clip: Clip):
        """Initialize with the selected clip."""
        super().__init__()
        self.clip = clip


class ClipGrid(ListView):
    """List view displaying clips for a selected game."""

    def __init__(self, **kwargs):
        """Initialize the clip grid with empty state."""
        super().__init__(**kwargs)
        self._clips: list[Clip] = []
        self._filtered: list[Clip] = []
        self._filter_active = False
        self._current_clip_dirs: frozenset[str] = frozenset()

    async def set_clips(self, clips: list[Clip]) -> None:
        """Populate the grid with clips for a game."""
        if not clips:
            return
        new_dirs = frozenset(c.clip_dir.name for c in clips)
        if new_dirs == self._current_clip_dirs:
            return
        self._current_clip_dirs = new_dirs
        self._clips = clips
        self._filtered = list(clips)
        self._filter_active = False
        await self._show_clips(self._filtered)

    async def filter_by_date(self, query: str) -> None:
        """Filter clips by date query.

        Supports substring match against display_date and date range
        with ``..`` (e.g. "2024-01..2024-06"). An empty query restores
        the full list.
        """
        query = query.strip()
        if not query:
            self._filtered = list(self._clips)
            self._filter_active = False
        elif ".." in query:
            self._filtered = self._filter_by_range(query)
            self._filter_active = True
        else:
            q = query.lower()
            self._filtered = [c for c in self._clips if q in c.display_date.lower()]
            self._filter_active = True
        await self._show_clips(self._filtered)

    @property
    def is_filtered(self) -> bool:
        """Return True if a filter is currently active."""
        return self._filter_active

    @property
    def active_clips(self) -> list[Clip]:
        """Return the currently visible clips (filtered or full list)."""
        return self._filtered if self._filter_active else self._clips

    @property
    def filtered_count(self) -> int:
        """Return the number of clips in the current filtered view."""
        return len(self._filtered)

    @property
    def total_count(self) -> int:
        """Return the total number of clips for the current game."""
        return len(self._clips)

    def _filter_by_range(self, query: str) -> list[Clip]:
        """Filter clips by a date range query like '2024-01..2024-06'."""
        parts = query.split("..", 1)
        start = self._parse_date(parts[0].strip(), is_end=False) if parts[0].strip() else None
        end = self._parse_date(parts[1].strip(), is_end=True) if parts[1].strip() else None
        results: list[Clip] = []
        for c in self._clips:
            if start is not None and c.date < start:
                continue
            if end is not None and c.date > end:
                continue
            results.append(c)
        return results

    @staticmethod
    def _parse_date(s: str, is_end: bool = False) -> datetime | None:
        """Parse a date string in YYYY, YYYY-MM, or YYYY-MM-DD format.

        When *is_end* is True, partial dates are extended to cover the full
        period (e.g. "2024" → Dec 31, 2024). Otherwise they stay at the start
        of the period.
        """
        formats = ["%Y-%m-%d", "%Y-%m", "%Y"]
        for fmt in formats:
            try:
                dt = datetime.strptime(s, fmt)
                if is_end and fmt == "%Y":
                    dt = dt.replace(month=12, day=31)
                elif is_end and fmt == "%Y-%m":
                    month = dt.month
                    year = dt.year
                    if month == 12:
                        dt = dt.replace(year=year + 1, month=1, day=1) - timedelta(days=1)
                    else:
                        dt = dt.replace(month=month + 1, day=1) - timedelta(days=1)
                return dt
            except ValueError:
                continue
        return None

    @staticmethod
    def _render_clip(clip: Clip) -> str:
        if clip.has_video:
            return (
                f"  {clip.display_date}    "
                f"{clip.display_duration}    "
                f"{clip.resolution_str}    "
                f"{clip.video_codec}"
            )
        return f"  {clip.display_date}    (no video)"

    async def _show_clips(self, clips: list[Clip]) -> None:
        """Render the given clip list into ListItems."""
        await self.clear()
        items = [
            ListItem(
                Label(self._render_clip(c)),
                id=f"clip-{c.clip_dir.name}",
            )
            for c in clips
        ]
        if items:
            await self.extend(items)
            self.index = 0

    def _on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        event.stop()
        if event.item is None:
            return
        idx = self.index
        clips = self.active_clips
        if 0 <= idx < len(clips):
            self.post_message(ClipSelected(clips[idx]))

    def _on_list_view_selected(self, event: ListView.Selected) -> None:
        event.stop()
        self.toggle_selection()

    def toggle_selection(self) -> None:
        """Toggle selection state of the current clip."""
        idx = self.index
        clips = self.active_clips
        if 0 <= idx < len(clips):
            clips[idx].selected = not clips[idx].selected
