"""Widget modules for game list, clip grid, and preview pane."""
