"""Preview pane for selected clip."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Container, Vertical
from textual.widgets import Button, Static

if TYPE_CHECKING:
    from steam_clip_tui.config import Config
    from steam_clip_tui.models.clip import Clip


class PreviewPane(Vertical):
    """Right-side pane showing clip preview and metadata."""

    def __init__(self, **kwargs):
        """Initialize the preview pane with empty state."""
        super().__init__(**kwargs)
        self._clip: Clip | None = None
        self._img_widget = None

    def compose(self):
        """Compose the preview pane layout."""
        yield Static("Clip Preview", id="preview-title")
        yield Static("", id="preview-thumb")
        with Container(id="preview-meta"):
            yield Static("Select a clip", id="meta-content")
        yield Button("Export [e]", id="export-button", disabled=True)

    def show_clip(self, clip: Clip, config: Config) -> None:
        """Display clip preview with thumbnail and metadata."""
        self._clip = clip
        thumb = self.query_one("#preview-thumb", Static)
        meta = self.query_one("#meta-content", Static)
        export_btn = self.query_one("#export-button", Button)

        # Remove any previously mounted image
        if self._img_widget is not None:
            self._img_widget.remove()
            self._img_widget = None

        if config.show_clip_preview and clip.thumbnail_path:
            try:
                from textual_image.widget import Image

                self._img_widget = Image(str(clip.thumbnail_path))
                self.mount(self._img_widget, before=thumb)
                thumb.display = False
            except Exception:
                thumb.display = True
                thumb.update(f"\n  [Thumbnail: {clip.thumbnail_path.name}]")
        else:
            thumb.display = True
            tname = clip.thumbnail_path.name if clip.thumbnail_path else "N/A"
            thumb.update(f"\n  [Thumbnail: {tname}]")

        lines = [
            f"Date: {clip.display_date}",
            f"Duration: {clip.display_duration}",
            f"Resolution: {clip.resolution_str}",
        ]
        if clip.video_codec:
            lines.append(f"Video: {clip.video_codec}")
        if clip.audio_codec:
            lines.append(f"Audio: {clip.audio_codec}")
        if clip.has_video:
            lines.append(f"Size: {clip.file_size_mb:.0f} MB")
        else:
            lines.append("[Video not available]")

        meta.update("\n".join(lines))

        if clip.has_video:
            export_btn.disabled = False
            export_btn.label = "Export [e]"
        else:
            export_btn.disabled = True
            export_btn.label = "No video"
