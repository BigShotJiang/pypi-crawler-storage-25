"""Game list sidebar widget."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Horizontal
from textual.message import Message
from textual.widgets import Label, ListItem, ListView

if TYPE_CHECKING:
    from steam_clip_tui.models.game import Game


class GameSelected(Message):
    """Message posted when a game is selected in the list."""

    def __init__(self, game: Game):
        """Initialize with the selected game."""
        super().__init__()
        self.game = game


class GameList(ListView):
    """Sidebar list view displaying available games."""

    def __init__(self, icon_width: int = 0, **kwargs):
        """Initialize the game list with empty state."""
        super().__init__(**kwargs)
        self._icon_width = icon_width
        self._games: list[Game] = []
        self._filtered: list[Game] = []
        self._filter_active = False

    async def set_games(self, games: list[Game]) -> None:
        """Populate the list with all games."""
        self._games = games
        self._filtered = list(games)
        self._filter_active = False
        await self._show_games(self._filtered)

    async def filter_by_name(self, query: str) -> None:
        """Filter displayed games by name (case-insensitive substring match).

        An empty query restores the full list.
        """
        query = query.strip().lower()
        if not query:
            self._filtered = list(self._games)
            self._filter_active = False
        else:
            self._filtered = [g for g in self._games if query in g.name.lower()]
            self._filter_active = True
        await self._show_games(self._filtered)

    @property
    def is_filtered(self) -> bool:
        """Return True if a filter is currently active."""
        return self._filter_active

    @property
    def active_games(self) -> list[Game]:
        """Return the currently visible games (filtered or full list)."""
        return self._filtered if self._filter_active else self._games

    async def _show_games(self, games: list[Game]) -> None:
        """Render the given game list into ListItems."""
        await self.clear()
        items = []
        for g in games:
            label = Label(self._render_game_name(g))
            if g.icon_path is not None:
                try:
                    from textual_image.widget import Image

                    icon = Image(str(g.icon_path))
                    icon.styles.width = self._icon_width
                    content = Horizontal(icon, label, classes="game-item")
                except (ImportError, OSError):
                    content = label
            else:
                content = label
            items.append(ListItem(content, id=f"game-{g.app_id}"))
        if items:
            await self.extend(items)
            self.index = 0

    @staticmethod
    def _render_game_name(game: Game) -> str:
        return f"  {game.name}  ({game.clip_count})"

    def _on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        event.stop()
        if event.item is None:
            return
        idx = self.index
        games = self.active_games
        if 0 <= idx < len(games):
            self.post_message(GameSelected(games[idx]))
