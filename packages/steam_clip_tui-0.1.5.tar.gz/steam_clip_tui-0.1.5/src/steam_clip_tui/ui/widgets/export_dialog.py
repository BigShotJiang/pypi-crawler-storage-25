"""Export settings modal dialog."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, Select

from steam_clip_tui.models.export_settings import ExportSettings
from steam_clip_tui.services.exporter import _apply_template

if TYPE_CHECKING:
    from steam_clip_tui.config import Config
    from steam_clip_tui.models.clip import Clip


class ExportDialog(ModalScreen[ExportSettings | None]):
    """Modal dialog for configuring and initiating clip export."""

    def __init__(self, config: Config, clip: Clip):
        """Initialize the dialog with config and clip to export."""
        super().__init__()
        self._config = config
        self._clip = clip
        self._settings = ExportSettings(
            output_dir=config.output_dir,
            video_codec=config.video_codec,
            audio_codec=config.audio_codec,
            resolution=config.resolution,
            filename_template=config.filename_template,
            video_bitrate=config.video_bitrate,
            hwaccel=config.hwaccel,
        )

    def compose(self):
        """Compose the export dialog layout."""
        with Container():
            yield Label("Export Clip")

            yield Label("Output directory:")
            self._output_input = Input(
                str(self._settings.output_dir),
                id="export-output-dir",
            )
            yield self._output_input

            yield Label("Video codec:")
            self._codec_select = Select(
                [(label, codec) for codec, label in ExportSettings.CODEC_CHOICES],
                value=self._settings.video_codec,
                id="export-codec",
            )
            yield self._codec_select

            yield Label("Resolution:")
            self._res_select = Select(
                [(label, res) for res, label in ExportSettings.RESOLUTION_CHOICES],
                value=self._settings.resolution,
                id="export-resolution",
            )
            yield self._res_select

            yield Label("Filename preview:")
            self._filename_label = Label(self._preview_filename())
            yield self._filename_label

            with Horizontal(id="dialog-buttons"):
                yield Button("Cancel [esc]", id="export-cancel", variant="default")
                yield Button("Export", id="export-confirm", variant="primary")

    def on_mount(self) -> None:
        """Update the filename preview on mount."""
        self._update_filename()

    def _preview_filename(self) -> str:
        game_name = (
            self._config.get_cached_app_name(self._clip.app_id) or f"app_{self._clip.app_id}"
        )
        return _apply_template(
            self._settings.filename_template,
            game=game_name.replace(" ", "_"),
            date=self._clip.date.strftime("%Y-%m-%d"),
            time=self._clip.date.strftime("%H%M%S"),
            ext="mp4",
        )

    def _update_filename(self) -> None:
        self._filename_label.update(self._preview_filename())

    def on_select_changed(self) -> None:
        """Update settings when codec or resolution selection changes."""
        self._settings.video_codec = self._codec_select.value or "copy"
        self._settings.resolution = self._res_select.value or "source"
        self._update_filename()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Update output directory when input changes."""
        if event.input is self._output_input:
            self._settings.output_dir = Path(event.value).expanduser()
            self._update_filename()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle confirm or cancel button press."""
        if event.button.id == "export-confirm":
            self.dismiss(self._settings)
        elif event.button.id == "export-cancel":
            self.dismiss(None)

    def on_key(self, event) -> None:
        """Dismiss the dialog on escape key press."""
        if event.key == "escape":
            self.dismiss(None)
