"""UI components for the Steam Clip TUI application."""
