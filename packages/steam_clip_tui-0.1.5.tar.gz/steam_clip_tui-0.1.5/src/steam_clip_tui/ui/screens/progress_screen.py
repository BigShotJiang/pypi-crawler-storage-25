"""Export progress screen."""

from __future__ import annotations

import asyncio

from textual.containers import Container
from textual.screen import ModalScreen
from textual.widgets import Button, ProgressBar, Static


class ProgressScreen(ModalScreen[bool]):
    """Modal screen showing export progress with a cancel button."""

    def __init__(self):
        """Initialize the progress screen with an event for completion."""
        super().__init__()
        self._done = asyncio.Event()

    def compose(self):
        """Compose the progress screen layout with bar and cancel button."""
        with Container():
            yield Static("Exporting clip...", id="progress-title")
            self._bar = ProgressBar(total=100, show_eta=False)
            yield self._bar
            self._status = Static("0%", id="progress-pct")
            yield self._status
            self._time = Static("", id="progress-time")
            yield self._time
            self._cancel_btn = Button("Cancel", id="progress-cancel")
            yield self._cancel_btn

    async def update_progress(self, progress) -> None:
        """Update the progress bar and status display."""
        self._bar.update(progress=progress.percent)
        self._status.update(f"{progress.percent:.0f}%")
        mins, secs = divmod(int(progress.time_seconds), 60)
        self._time.update(f"Elapsed: {mins}:{secs:02d}")

        if progress.status == "complete":
            self._done.set()

    def signal_error(self) -> None:
        """Signal that an error occurred so dismiss_on_complete returns."""
        self._done.set()

    async def dismiss_on_complete(self) -> None:
        """Wait for export completion and dismiss the screen."""
        await asyncio.wait_for(self._done.wait(), timeout=600)
        self.dismiss(True)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle cancel button press."""
        if event.button.id == "progress-cancel":
            self.dismiss(False)

    def on_key(self, event) -> None:
        """Dismiss on escape key press."""
        if event.key == "escape":
            self.dismiss(False)
