"""Help screen showing keyboard shortcuts."""

from textual.containers import Container
from textual.screen import ModalScreen
from textual.widgets import Static

HELP_TEXT = """
[b]Steam Clip TUI — Keyboard Shortcuts[/b]

[dim]Navigation[/dim]
  [bold red]h[/] / [bold red]l[/]    Switch focus left / right
  [bold red]j[/] / [bold red]k[/]    Move cursor down / up
  [bold red]g[/]          Focus game list

[dim]Actions[/dim]
  [bold red]e[/]          Export selected clip
  [bold red]/[/]          Search games / Filter clips by date
  [bold red]Enter[/]      Confirm search (keep filter)
  [bold red]Esc[/]        Clear search and restore full list
  [bold red]?[/]          Show this help

[dim]Global[/dim]
  [bold red]q[/]          Quit
"""


class HelpScreen(ModalScreen[None]):
    """Modal screen displaying keyboard shortcuts."""

    def compose(self):
        """Compose the help screen layout."""
        with Container():
            yield Static(HELP_TEXT)
            yield Static("\nPress any key to close", id="help-close")

    def on_key(self, event) -> None:  # noqa: ARG002
        """Dismiss the screen on any key press."""
        self.dismiss(None)

    def on_click(self) -> None:
        """Dismiss the screen on click."""
        self.dismiss(None)
