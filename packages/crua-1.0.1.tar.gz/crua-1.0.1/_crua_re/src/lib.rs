use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use regex::Regex;
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};

static NEXT_ID: AtomicU64 = AtomicU64::new(0);

fn registry() -> &'static Mutex<HashMap<u64, Regex>> {
    static REG: OnceLock<Mutex<HashMap<u64, Regex>>> = OnceLock::new();
    REG.get_or_init(|| Mutex::new(HashMap::new()))
}

#[pyfunction]
fn compile_pattern(pattern: &str) -> PyResult<u64> {
    let regex = Regex::new(pattern)
        .map_err(|e| PyValueError::new_err(format!("Invalid regex: {e}")))?;
    let id = NEXT_ID.fetch_add(1, Ordering::Relaxed);
    registry().lock().unwrap().insert(id, regex);
    Ok(id)
}

#[pyfunction]
fn is_match(id: u64, text: &str) -> bool {
    let lock = registry().lock().unwrap();
    lock.get(&id).map_or(false, |re| re.is_match(text))
}

#[pyfunction]
fn captures(id: u64, text: &str) -> Option<Vec<Option<String>>> {
    let lock = registry().lock().unwrap();
    let re = lock.get(&id)?;
    let caps = re.captures(text)?;
    Some(
        caps.iter()
            .skip(1)
            .map(|m| m.map(|m| m.as_str().to_owned()))
            .collect(),
    )
}

#[pyfunction]
fn findall(id: u64, text: &str) -> Vec<String> {
    let lock = registry().lock().unwrap();
    let Some(re) = lock.get(&id) else {
        return vec![];
    };
    re.find_iter(text).map(|m| m.as_str().to_owned()).collect()
}

#[pyfunction]
fn sub(id: u64, text: &str, replacement: &str) -> String {
    let lock = registry().lock().unwrap();
    let Some(re) = lock.get(&id) else {
        return text.to_owned();
    };
    re.replace_all(text, replacement).into_owned()
}

#[pymodule]
fn crua_re(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(compile_pattern, m)?)?;
    m.add_function(wrap_pyfunction!(is_match, m)?)?;
    m.add_function(wrap_pyfunction!(captures, m)?)?;
    m.add_function(wrap_pyfunction!(findall, m)?)?;
    m.add_function(wrap_pyfunction!(sub, m)?)?;
    Ok(())
}
