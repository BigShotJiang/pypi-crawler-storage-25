#!/usr/bin/env python3
"""
Patch generated client modules where OpenAPI schema implies a list body but
Congress.gov returns an envelope dict.

Middleware reads ``response.content`` via ``ApiEnvelope``; broken generated
parsers iterate envelope keys and crash. This script runs after every
``generate-client`` promotion.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# (relative path under _client/api, comment describing the envelope body)
CONGRESS_ENVELOPE_PATCHES: tuple[tuple[str, str], ...] = (
    ("congress/get_congress.py", '{"congresses": [...]}'),
    ("congress/get_congress_congress.py", '{"congress": {...}}'),
    ("congress/get_congress_current.py", '{"congress": {...}}'),
)

BROKEN_200_BLOCK = """    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for componentsschemas_congresses_item_data in _response_200:
            componentsschemas_congresses_item = Congress.from_dict(componentsschemas_congresses_item_data)

            response_200.append(componentsschemas_congresses_item)

        return response_200"""


def _fixed_200_block(envelope_comment: str) -> str:
    return f"""    if response.status_code == 200:
        # Congress.gov returns an envelope (e.g. {envelope_comment}); congressgov.services
        # parses response.content via ApiEnvelope. Generated list iteration fails.
        return None"""


def patch_congress_envelope_parsers(client_root: Path) -> list[Path]:
    """Replace broken list-iteration _parse_response blocks in congress endpoints."""
    api_root = client_root / "api"
    patched: list[Path] = []
    for rel_path, envelope_comment in CONGRESS_ENVELOPE_PATCHES:
        module_path = api_root / rel_path
        if not module_path.is_file():
            continue
        text = module_path.read_text(encoding="utf-8")
        if BROKEN_200_BLOCK not in text:
            continue
        new_text = text.replace(BROKEN_200_BLOCK, _fixed_200_block(envelope_comment), 1)
        if new_text != text:
            module_path.write_text(new_text, encoding="utf-8")
            patched.append(module_path)
    return patched


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--client-root",
        type=Path,
        default=Path("src/congressgov/_client"),
        help="Root of the generated congressgov._client package",
    )
    args = parser.parse_args(argv)
    client_root = args.client_root.resolve()
    if not client_root.is_dir():
        print(f"Client root not found: {client_root}", file=sys.stderr)
        return 1
    patched = patch_congress_envelope_parsers(client_root)
    for path in patched:
        print(f"Patched {path.relative_to(client_root.parent.parent)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
