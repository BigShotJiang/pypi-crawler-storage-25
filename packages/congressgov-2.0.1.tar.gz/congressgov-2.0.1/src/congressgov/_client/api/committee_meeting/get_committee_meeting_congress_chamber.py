from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.committee_meetings import CommitteeMeetings
from ...models.get_committee_meeting_congress_chamber_chamber import GetCommitteeMeetingCongressChamberChamber
from ...models.get_committee_meeting_congress_chamber_format import GetCommitteeMeetingCongressChamberFormat
from ...types import UNSET, Response, Unset


def _get_kwargs(
    congress: int,
    chamber: GetCommitteeMeetingCongressChamberChamber,
    *,
    format_: Union[Unset, GetCommitteeMeetingCongressChamberFormat] = GetCommitteeMeetingCongressChamberFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
    from_date_time: Union[Unset, str] = UNSET,
    to_date_time: Union[Unset, str] = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_format_: Union[Unset, str] = UNSET
    if format_ is None:
        format_ = GetCommitteeMeetingCongressChamberFormat.JSON
    elif isinstance(format_, str):
        format_ = GetCommitteeMeetingCongressChamberFormat(format_.lower())
    if not isinstance(format_, Unset):
        json_format_ = format_.value

    params["format"] = json_format_

    params["offset"] = offset

    params["limit"] = limit

    params["fromDateTime"] = from_date_time

    params["toDateTime"] = to_date_time

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/committee-meeting/{congress}/{chamber}".format(
            congress=congress,
            chamber=chamber,
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, list["CommitteeMeetings"]]]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for componentsschemas_committee_meeting_item_data in _response_200:
            componentsschemas_committee_meeting_item = CommitteeMeetings.from_dict(
                componentsschemas_committee_meeting_item_data
            )

            response_200.append(componentsschemas_committee_meeting_item)

        return response_200
    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, list["CommitteeMeetings"]]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    congress: int,
    chamber: GetCommitteeMeetingCongressChamberChamber,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetCommitteeMeetingCongressChamberFormat] = GetCommitteeMeetingCongressChamberFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
    from_date_time: Union[Unset, str] = UNSET,
    to_date_time: Union[Unset, str] = UNSET,
) -> Response[Union[Any, list["CommitteeMeetings"]]]:
    """Returns a list of committee meetings filtered by the specified congress and chamber.

     Returns a list of committee meetings filtered by the specified congress and chamber.

    Args:
        congress (int):
        chamber (GetCommitteeMeetingCongressChamberChamber):
        format_ (Union[Unset, GetCommitteeMeetingCongressChamberFormat]):  Default:
            GetCommitteeMeetingCongressChamberFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):
        from_date_time (Union[Unset, str]):
        to_date_time (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, list['CommitteeMeetings']]]
    """

    kwargs = _get_kwargs(
        congress=congress,
        chamber=chamber,
        format_=format_,
        offset=offset,
        limit=limit,
        from_date_time=from_date_time,
        to_date_time=to_date_time,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    congress: int,
    chamber: GetCommitteeMeetingCongressChamberChamber,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetCommitteeMeetingCongressChamberFormat] = GetCommitteeMeetingCongressChamberFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
    from_date_time: Union[Unset, str] = UNSET,
    to_date_time: Union[Unset, str] = UNSET,
) -> Optional[Union[Any, list["CommitteeMeetings"]]]:
    """Returns a list of committee meetings filtered by the specified congress and chamber.

     Returns a list of committee meetings filtered by the specified congress and chamber.

    Args:
        congress (int):
        chamber (GetCommitteeMeetingCongressChamberChamber):
        format_ (Union[Unset, GetCommitteeMeetingCongressChamberFormat]):  Default:
            GetCommitteeMeetingCongressChamberFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):
        from_date_time (Union[Unset, str]):
        to_date_time (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, list['CommitteeMeetings']]
    """

    return sync_detailed(
        congress=congress,
        chamber=chamber,
        client=client,
        format_=format_,
        offset=offset,
        limit=limit,
        from_date_time=from_date_time,
        to_date_time=to_date_time,
    ).parsed


async def asyncio_detailed(
    congress: int,
    chamber: GetCommitteeMeetingCongressChamberChamber,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetCommitteeMeetingCongressChamberFormat] = GetCommitteeMeetingCongressChamberFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
    from_date_time: Union[Unset, str] = UNSET,
    to_date_time: Union[Unset, str] = UNSET,
) -> Response[Union[Any, list["CommitteeMeetings"]]]:
    """Returns a list of committee meetings filtered by the specified congress and chamber.

     Returns a list of committee meetings filtered by the specified congress and chamber.

    Args:
        congress (int):
        chamber (GetCommitteeMeetingCongressChamberChamber):
        format_ (Union[Unset, GetCommitteeMeetingCongressChamberFormat]):  Default:
            GetCommitteeMeetingCongressChamberFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):
        from_date_time (Union[Unset, str]):
        to_date_time (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, list['CommitteeMeetings']]]
    """

    kwargs = _get_kwargs(
        congress=congress,
        chamber=chamber,
        format_=format_,
        offset=offset,
        limit=limit,
        from_date_time=from_date_time,
        to_date_time=to_date_time,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    congress: int,
    chamber: GetCommitteeMeetingCongressChamberChamber,
    *,
    client: Union[AuthenticatedClient, Client],
    format_: Union[Unset, GetCommitteeMeetingCongressChamberFormat] = GetCommitteeMeetingCongressChamberFormat.XML,
    offset: Union[Unset, int] = UNSET,
    limit: Union[Unset, int] = UNSET,
    from_date_time: Union[Unset, str] = UNSET,
    to_date_time: Union[Unset, str] = UNSET,
) -> Optional[Union[Any, list["CommitteeMeetings"]]]:
    """Returns a list of committee meetings filtered by the specified congress and chamber.

     Returns a list of committee meetings filtered by the specified congress and chamber.

    Args:
        congress (int):
        chamber (GetCommitteeMeetingCongressChamberChamber):
        format_ (Union[Unset, GetCommitteeMeetingCongressChamberFormat]):  Default:
            GetCommitteeMeetingCongressChamberFormat.XML.
        offset (Union[Unset, int]):
        limit (Union[Unset, int]):
        from_date_time (Union[Unset, str]):
        to_date_time (Union[Unset, str]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, list['CommitteeMeetings']]
    """

    return (
        await asyncio_detailed(
            congress=congress,
            chamber=chamber,
            client=client,
            format_=format_,
            offset=offset,
            limit=limit,
            from_date_time=from_date_time,
            to_date_time=to_date_time,
        )
    ).parsed
