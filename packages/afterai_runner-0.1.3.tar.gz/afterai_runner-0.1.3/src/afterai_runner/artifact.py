"""
Artifact contract: one file = one signal. Validates required keys and RFC3339 window.
"""
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator

# D1–D5, W1–W5
VALID_SIGNAL_KEYS = frozenset(
    f"{p}{i}" for p in ("D", "W") for i in range(1, 6)
)
CADENCE_VALUES = ("daily", "weekly")


def _parse_rfc3339(s: str) -> None:
    """Validate RFC3339-like string (raise if invalid)."""
    if not s or not isinstance(s, str):
        raise ValueError("RFC3339 value must be a non-empty string")
    s = s.strip()
    # Accept Z or +00:00
    from datetime import datetime
    normalized = s.replace("Z", "+00:00")
    try:
        datetime.fromisoformat(normalized)
    except Exception as e:
        raise ValueError(f"Invalid RFC3339 datetime: {s}") from e


class WindowModel(BaseModel):
    """Window with start/end RFC3339."""
    start: str = Field(..., description="Window start (RFC3339)")
    end: str = Field(..., description="Window end (RFC3339)")

    @field_validator("start", "end")
    @classmethod
    def check_rfc3339(cls, v: str) -> str:
        _parse_rfc3339(v)
        return v


class ArtifactIn(BaseModel):
    """
    Artifact JSON (one file = one signal).
    Required: signal_key, cadence, window, metrics.
    Optional passthrough: severity, confidence, tags, source, evidence_refs, baseline_ref, created_at.
    """
    signal_key: str = Field(..., description="D1–D5 or W1–W5")
    cadence: str = Field(..., description="daily | weekly")
    window: WindowModel = Field(..., description="start/end RFC3339")
    metrics: Dict[str, Any] = Field(..., description="Pre-aggregated metrics object")

    severity: Optional[str] = None
    confidence: Optional[float] = None
    tags: Optional[List[str]] = None
    source: Optional[Any] = None
    evidence_refs: Optional[List[str]] = None
    baseline_ref: Optional[str] = None
    created_at: Optional[str] = None

    @field_validator("signal_key")
    @classmethod
    def valid_signal_key(cls, v: str) -> str:
        key = (v or "").strip()
        if key not in VALID_SIGNAL_KEYS:
            raise ValueError(
                f"signal_key must be one of D1–D5, W1–W5; got {v!r}"
            )
        return key

    @field_validator("cadence")
    @classmethod
    def valid_cadence(cls, v: str) -> str:
        c = (v or "").strip().lower()
        if c not in CADENCE_VALUES:
            raise ValueError(
                f"cadence must be 'daily' or 'weekly'; got {v!r}"
            )
        return c


def load_artifact(path: str | Path) -> ArtifactIn:
    """
    Load and validate artifact JSON from a local file path.
    Raises FileNotFoundError if path missing, ValueError for invalid content.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Artifact file not found: {p}")
    if not p.is_file():
        raise ValueError(f"Artifact path is not a file: {p}")

    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as e:
        raise ValueError(f"Cannot read artifact file {p}: {e}") from e

    try:
        data = __import__("json").loads(raw)
    except Exception as e:
        raise ValueError(f"Artifact JSON parse error in {p}: {e}") from e

    if not isinstance(data, dict):
        raise ValueError(f"Artifact root must be a JSON object; got {type(data).__name__}")

    for key in ("signal_key", "cadence", "window", "metrics"):
        if key not in data:
            raise ValueError(f"Artifact missing required key: {key}")

    if not isinstance(data.get("window"), dict):
        raise ValueError("Artifact 'window' must be an object with start and end")
    if "start" not in data["window"] or "end" not in data["window"]:
        raise ValueError("Artifact window must have 'start' and 'end' (RFC3339)")

    return ArtifactIn(**data)
