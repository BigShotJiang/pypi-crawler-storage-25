"""
CLI: afterai-runner run | ace-from-ais
"""
import argparse
import json
import sys
from pathlib import Path

import requests

from .config import get_api_key, get_base_url
from .manifest import load_manifest
from .artifact import load_artifact
from .payload import build_payload
from .emit import emit_signal
from .ace_rules import run_ace_from_ais_rule


def _cmd_run(args: argparse.Namespace) -> int:
    manifest_path = args.manifest
    dry_run = args.dry_run
    try:
        manifest = load_manifest(manifest_path)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    if not manifest.artifacts:
        print("No artifacts in manifest.", file=sys.stderr)
        return 0
    if not dry_run:
        try:
            api_key = get_api_key()
            base_url = get_base_url()
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
    else:
        api_key = ""
        base_url = ""
    errors = 0
    for i, entry in enumerate(manifest.artifacts):
        path = entry.path_resolved
        try:
            artifact = load_artifact(path)
        except FileNotFoundError as e:
            print(f"Error [{i+1}] {path}: {e}", file=sys.stderr)
            errors += 1
            continue
        except ValueError as e:
            print(f"Error [{i+1}] {path}: {e}", file=sys.stderr)
            errors += 1
            continue
        payload = build_payload(artifact, entry)
        if dry_run:
            print(json.dumps(payload, indent=2))
            continue
        try:
            result = emit_signal(payload, api_key, base_url)
            print(f"Emitted {entry.system} {artifact.signal_key} -> signal_id={result.get('signal_id', '?')}")
        except requests.exceptions.HTTPError as e:
            print(f"Error [{i+1}] {path}: HTTP {e.response.status_code} - {e.response.text[:200]}", file=sys.stderr)
            errors += 1
        except Exception as e:
            print(f"Error [{i+1}] {path}: {e}", file=sys.stderr)
            errors += 1
    return 1 if errors else 0


def _cmd_ace_from_ais(args: argparse.Namespace) -> int:
    try:
        api_key = get_api_key()
        base_url = get_base_url()
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    severities = [s.strip() for s in (args.severity or "high,critical").split(",") if s.strip()]
    results = run_ace_from_ais_rule(
        base_url=base_url,
        api_key=api_key,
        min_signals=args.min_signals,
        severities=severities,
        hours=args.hours,
        limit=args.limit,
        system_filter=args.system,
        dry_run=args.dry_run,
    )
    for r in results:
        print(json.dumps(r, indent=2))
    if not results:
        print("No systems met the rule threshold.", file=sys.stderr)
    return 0


def _cmd_eval(args: argparse.Namespace) -> int:
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
    )
    from .eval.agent_config import load_agent_config
    from .eval.loop import make_connector, run_once, run_loop

    try:
        api_key = get_api_key()
        base_url = get_base_url()
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    try:
        agent_cfg = load_agent_config(args.agent_config)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    print(f"Agent type : {agent_cfg.type}")
    print(f"AfterAI URL: {base_url}")

    connector = make_connector(agent_cfg)
    if args.once:
        processed = run_once(base_url, api_key, connector)
        print(f"Processed {processed} job(s).")
    else:
        run_loop(base_url, api_key, connector, poll_interval=args.poll_interval)
    return 0


def _cmd_eval_init(args: argparse.Namespace) -> int:
    dest = Path(args.agent_config)
    if dest.exists():
        print(f"{dest} already exists. Not overwriting.", file=sys.stderr)
        return 1
    content = """\
agent:
  # Foundry v2 (recommended — uses Azure identity, no API key needed)
  type: foundry
  foundry_version: v2
  project_endpoint: https://YOUR_RESOURCE.services.ai.azure.com/api/projects/YOUR_PROJECT
  agent_name: your-agent-name
  # Set AZURE_FOUNDRY_TOKEN env var, or ensure `az login` is done and az CLI is available

  # --- Foundry v1 (classic, being deprecated) ---
  # type: foundry
  # foundry_version: v1
  # project_endpoint: https://YOUR_PROJECT.services.ai.azure.com
  # agent_id: asst_YOUR_AGENT_ID
  # api_key: ${AZURE_API_KEY}

  # --- Generic HTTP ---
  # type: http
  # url: https://your-agent.example.com/chat
  # headers:
  #   Authorization: Bearer ${YOUR_API_KEY}
  # body_template: '{"message": "{prompt}"}'
  # response_path: response.text

# AfterAI connection uses AFTERAI_API_KEY and AFTERAI_BASE_URL env vars.
# Do NOT commit this file — add it to .gitignore.
"""
    dest.write_text(content)
    print(f"Created {dest}")
    print("Edit it with your agent details, then run: afterai-runner eval")
    print(f"Add {dest} to .gitignore — keep your credentials local.")
    return 0


def _cmd_dataset_generate(args: argparse.Namespace) -> int:
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
    )
    from .eval.agent_config import load_agent_config
    from .dataset import fetch_agent_definition, summarize_agent, generate_dataset

    try:
        agent_cfg = load_agent_config(args.agent_config)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if agent_cfg.type != "foundry":
        print("Error: dataset-generate requires a Foundry agent config (type: foundry)", file=sys.stderr)
        return 1

    print("Fetching agent definition from Foundry...")
    try:
        agent_def = fetch_agent_definition(agent_cfg)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    summarize_agent(agent_def, agent_cfg.foundry_version)
    print()

    if not args.yes:
        confirm = input("Generate eval dataset with this agent? [y/N] ").strip().lower()
        if confirm != "y":
            print("Aborted.")
            return 0

    try:
        api_key = get_api_key()
        base_url = get_base_url()
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    print("Generating dataset (this may take a few seconds)...")
    try:
        result = generate_dataset(base_url, api_key, agent_def, agent_cfg.foundry_version)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    print(f"\nDataset created!")
    print(f"  ID:      {result['dataset_id']}")
    print(f"  Name:    {result.get('name', '(unnamed)')}")
    print(f"  Threads: {result.get('thread_count', '?')}")
    print(f"  Review it at: https://app.useafter.ai/app/evaluation")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="afterai-runner",
        description="AfterAI Runner — emit AIS from manifest; optional ACE-from-AIS rule",
    )
    subparsers = parser.add_subparsers(dest="command", required=True, help="Command")

    run_parser = subparsers.add_parser("run", help="Run ingestion from a manifest")
    run_parser.add_argument("--manifest", "-m", required=True, help="Path to manifest (JSON or YAML)")
    run_parser.add_argument("--dry-run", action="store_true", help="Print payloads, do not send")
    run_parser.set_defaults(_run=_cmd_run)

    ace_parser = subparsers.add_parser(
        "ace-from-ais", help="Out-of-band rule: read AIS, emit inferred ACE if threshold met"
    )
    ace_parser.add_argument("--min-signals", type=int, default=2, help="Min AIS count per system to trigger (default: 2)")
    ace_parser.add_argument("--severity", default="high,critical", help="Comma-separated severities (default: high,critical)")
    ace_parser.add_argument("--hours", type=int, default=24, help="Look-back window in hours (default: 24)")
    ace_parser.add_argument("--limit", type=int, default=100, help="Max signals to fetch (default: 100)")
    ace_parser.add_argument("--system", default=None, help="Filter by system (optional)")
    ace_parser.add_argument("--dry-run", action="store_true", help="Do not POST ACE; print would-be payloads")
    ace_parser.set_defaults(_run=_cmd_ace_from_ais)

    eval_parser = subparsers.add_parser("eval", help="Run eval jobs against your local agent")
    eval_parser.add_argument("--agent-config", default="afterai-agent.yaml", help="Path to agent config YAML (default: afterai-agent.yaml)")
    eval_parser.add_argument("--poll-interval", type=int, default=10, help="Seconds between polls (default: 10)")
    eval_parser.add_argument("--once", action="store_true", help="Process pending jobs once and exit")
    eval_parser.set_defaults(_run=_cmd_eval)

    eval_init_parser = subparsers.add_parser("eval-init", help="Create a starter afterai-agent.yaml")
    eval_init_parser.add_argument("--agent-config", default="afterai-agent.yaml", help="Output path (default: afterai-agent.yaml)")
    eval_init_parser.set_defaults(_run=_cmd_eval_init)

    dg_parser = subparsers.add_parser(
        "dataset-generate",
        help="Fetch your Foundry agent definition and generate an AfterAI eval dataset",
    )
    dg_parser.add_argument("--agent-config", default="afterai-agent.yaml", help="Path to agent config YAML (default: afterai-agent.yaml)")
    dg_parser.add_argument("--yes", "-y", action="store_true", help="Skip confirmation prompt")
    dg_parser.set_defaults(_run=_cmd_dataset_generate)

    args = parser.parse_args()
    exit_code = args._run(args)
    sys.exit(exit_code)
