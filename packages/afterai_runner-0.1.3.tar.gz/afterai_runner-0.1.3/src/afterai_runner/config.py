"""
Runner configuration from environment.
"""
import os
from typing import Optional


def get_api_key() -> str:
    """Required API key. Raises if missing."""
    key = os.environ.get("AFTERAI_API_KEY", "").strip()
    if not key:
        raise ValueError(
            "AFTERAI_API_KEY is required. Set it in the environment or .env."
        )
    return key


def get_base_url() -> str:
    """API base URL. Default: https://api.useafter.ai"""
    url = os.environ.get("AFTERAI_BASE_URL", "https://api.useafter.ai").strip()
    return url.rstrip("/") if url else "https://api.useafter.ai"
