"""
AfterAI Runner v0 — manifest-driven ingestion of pre-aggregated D1–W5 metrics
and emission of AIS payloads to the AfterAI API.
"""
from .__version__ import __version__

__all__ = ["__version__"]
