"""
Manifest contract: JSON or YAML manifest with version and artifacts.
path must be a local filesystem path (no S3, GCS, HTTPS).
"""
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Field, field_validator


# Remote path prefixes we reject (v0 local filesystem only)
_REMOTE_PREFIXES = ("http://", "https://", "s3://", "gs://", "ftp://")


class ManifestArtifact(BaseModel):
    """Single artifact entry: system + local path."""
    system: str = Field(..., min_length=1, description="System identifier")
    path: str = Field(..., min_length=1, description="Local path to artifact JSON")

    @field_validator("path")
    @classmethod
    def path_must_be_local(cls, v: str) -> str:
        v_lower = v.strip().lower()
        for prefix in _REMOTE_PREFIXES:
            if v_lower.startswith(prefix):
                raise ValueError(
                    f"path must be a local filesystem path; remote URIs (e.g. {prefix}) are not supported in v0"
                )
        if not v.strip():
            raise ValueError("path must be non-empty")
        return v.strip()

    @property
    def path_resolved(self) -> Path:
        return Path(self.path).resolve()


class Manifest(BaseModel):
    """Manifest root: optional version + list of artifacts. Runner does not dedupe entries."""
    version: Optional[str] = Field(None, description="Manifest version e.g. 2026-02 (optional)")
    artifacts: List[ManifestArtifact] = Field(
        default_factory=list,
        description="List of artifact entries (system + path)",
    )


def load_manifest(path: str | Path) -> Manifest:
    """
    Load manifest from a JSON or YAML file.
    Raises helpful errors for missing file, invalid format, or validation failures.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Manifest file not found: {p}")
    if not p.is_file():
        raise ValueError(f"Manifest path is not a file: {p}")

    raw = p.read_text(encoding="utf-8")
    suffix = p.suffix.lower()
    try:
        if suffix in (".json",):
            data: Dict[str, Any] = __import__("json").loads(raw)
        elif suffix in (".yaml", ".yml"):
            data = yaml.safe_load(raw)
            if data is None:
                data = {}
        else:
            # Try JSON first, then YAML
            try:
                data = __import__("json").loads(raw)
            except Exception:
                data = yaml.safe_load(raw) or {}
    except Exception as e:
        raise ValueError(f"Manifest parse error in {p}: {e}") from e

    if not isinstance(data, dict):
        raise ValueError(f"Manifest root must be a JSON object; got {type(data).__name__}")

    if "artifacts" in data and not isinstance(data["artifacts"], list):
        raise ValueError("Manifest 'artifacts' must be an array")

    return Manifest(**data)
