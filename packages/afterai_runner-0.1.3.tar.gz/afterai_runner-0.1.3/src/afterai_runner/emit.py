"""
Emit AIS payload to AfterAI API via POST /signals. Minimal HTTP client (API accepts full payload; SDK emit_ais uses different shape).
"""
from typing import Any, Dict

import requests

DEFAULT_TIMEOUT = 30


def emit_signal(
    payload: Dict[str, Any],
    api_key: str,
    base_url: str,
    timeout: int = DEFAULT_TIMEOUT,
) -> Dict[str, Any]:
    """
    POST payload to {base_url}/signals. Uses X-API-Key header.
    Returns response JSON; raises on HTTP error.
    """
    url = f"{base_url.rstrip('/')}/signals"
    headers = {
        "X-API-Key": api_key,
        "Content-Type": "application/json",
    }
    resp = requests.post(url, json=payload, headers=headers, timeout=timeout)
    resp.raise_for_status()
    return resp.json()
