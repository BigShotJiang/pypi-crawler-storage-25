"""Azure AI Foundry Agents connector — pure requests, no SDK dependency."""

import logging
import time
from typing import Optional

import requests

from .base import BaseConnector
from ..agent_config import AgentConfig
from ..auth import get_bearer_token

logger = logging.getLogger(__name__)

_POLL_INTERVAL = 2
_MAX_POLLS = 90

_V2_API_VERSION = "2025-11-15-preview"


class FoundryConnector(BaseConnector):
    def __init__(self, config: AgentConfig) -> None:
        self._version = config.foundry_version
        self._endpoint = config.project_endpoint.rstrip("/")

        if self._version == "v2":
            self._agent_name = config.agent_name
            self._bearer_token: Optional[str] = None
        else:
            # v1 state
            self._agent_id = config.agent_id
            self._v1_headers = {
                "api-key": config.api_key,
                "Content-Type": "application/json",
            }
            self._api_version = "2024-05-01-preview"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _v1_url(self, path: str) -> str:
        return f"{self._endpoint}/openai{path}?api-version={self._api_version}"

    def _v2_headers(self) -> dict:
        if self._bearer_token is None:
            self._bearer_token = get_bearer_token()
        return {
            "Authorization": f"Bearer {self._bearer_token}",
            "Content-Type": "application/json",
        }

    def _v2_url(self, path: str) -> str:
        return f"{self._endpoint}{path}?api-version={_V2_API_VERSION}"

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def invoke(self, prompt: str) -> str:
        if self._version == "v2":
            return self._invoke_v2(prompt)
        return self._invoke_v1(prompt)

    # ------------------------------------------------------------------
    # v2 invoke — conversations + responses API
    # ------------------------------------------------------------------

    def _invoke_v2(self, prompt: str) -> str:
        headers = self._v2_headers()

        # Step 1: create conversation
        conv_resp = requests.post(
            self._v2_url("/conversations"),
            headers=headers,
            json={"items": [{"type": "message", "role": "user", "content": prompt}]},
            timeout=30,
        )
        conv_resp.raise_for_status()
        conversation_id = conv_resp.json()["id"]
        logger.debug("v2 conversation created: %s", conversation_id)

        # Step 2: submit response request
        resp = requests.post(
            self._v2_url("/openai/responses"),
            headers=headers,
            json={
                "input": prompt,
                "conversation": conversation_id,
                "agent": {"name": self._agent_name, "version": "latest"},
                "store": True,
            },
            timeout=120,
        )
        resp.raise_for_status()
        response_data = resp.json()

        # Parse assistant message from output items
        for item in response_data.get("output", []):
            if item.get("type") == "message" and item.get("role") == "assistant":
                texts = [
                    block["text"]
                    for block in item.get("content", [])
                    if block.get("type") in ("text", "output_text")
                ]
                return "\n".join(texts)

        raise RuntimeError(
            f"No assistant message found in v2 response for conversation {conversation_id}"
        )

    # ------------------------------------------------------------------
    # v1 invoke — threads + runs (Assistants API)
    # ------------------------------------------------------------------

    def _invoke_v1(self, prompt: str) -> str:
        # Create thread
        resp = requests.post(
            self._v1_url("/threads"), headers=self._v1_headers, json={}, timeout=30
        )
        resp.raise_for_status()
        thread_id = resp.json()["id"]

        # Add user message
        requests.post(
            self._v1_url(f"/threads/{thread_id}/messages"),
            headers=self._v1_headers,
            json={"role": "user", "content": prompt},
            timeout=30,
        ).raise_for_status()

        # Create run
        run_resp = requests.post(
            self._v1_url(f"/threads/{thread_id}/runs"),
            headers=self._v1_headers,
            json={"assistant_id": self._agent_id},
            timeout=30,
        )
        run_resp.raise_for_status()
        run_id = run_resp.json()["id"]

        # Poll for completion
        for _ in range(_MAX_POLLS):
            time.sleep(_POLL_INTERVAL)
            status_resp = requests.get(
                self._v1_url(f"/threads/{thread_id}/runs/{run_id}"),
                headers=self._v1_headers,
                timeout=30,
            )
            status_resp.raise_for_status()
            run_data = status_resp.json()
            status = run_data.get("status")
            if status == "completed":
                break
            elif status in ("failed", "cancelled", "expired"):
                error = run_data.get("last_error", {}).get("message", status)
                raise RuntimeError(f"Run ended with status '{status}': {error}")
        else:
            raise TimeoutError(f"Run did not complete within {_MAX_POLLS * _POLL_INTERVAL}s")

        # Get last assistant message
        messages_resp = requests.get(
            self._v1_url(f"/threads/{thread_id}/messages"),
            headers=self._v1_headers,
            timeout=30,
        )
        messages_resp.raise_for_status()
        for msg in messages_resp.json().get("data", []):
            if msg.get("role") == "assistant":
                texts = [
                    block["text"]["value"]
                    for block in msg.get("content", [])
                    if block.get("type") == "text"
                ]
                return "\n".join(texts)
        raise RuntimeError(f"No assistant message found in thread {thread_id}")
