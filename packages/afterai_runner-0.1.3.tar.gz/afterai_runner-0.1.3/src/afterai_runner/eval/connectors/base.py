from abc import ABC, abstractmethod

class BaseConnector(ABC):
    @abstractmethod
    def invoke(self, prompt: str) -> str:
        ...
    def close(self) -> None:
        pass
