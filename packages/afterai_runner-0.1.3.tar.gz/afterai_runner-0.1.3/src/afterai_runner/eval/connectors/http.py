"""Generic HTTP connector."""

import json
import logging
from typing import Any

import requests

from .base import BaseConnector
from ..agent_config import AgentConfig

logger = logging.getLogger(__name__)


def _get_nested(data: Any, path: str) -> str:
    parts = path.split(".")
    current = data
    for part in parts:
        if not isinstance(current, dict):
            raise KeyError(f"Cannot traverse '{part}' in {type(current).__name__}")
        current = current.get(part)
        if current is None:
            raise KeyError(f"Path '{path}' not found in response")
    return str(current)


class HTTPConnector(BaseConnector):
    def __init__(self, config: AgentConfig) -> None:
        self._url = config.url
        self._headers = {"Content-Type": "application/json", **config.headers}
        self._body_template = config.body_template
        self._response_path = config.response_path

    def invoke(self, prompt: str) -> str:
        body_str = self._body_template.replace("{prompt}", prompt.replace('"', '\\"'))
        try:
            body = json.loads(body_str)
        except json.JSONDecodeError as exc:
            raise ValueError(f"body_template is not valid JSON after substitution: {exc}") from exc
        resp = requests.post(self._url, headers=self._headers, json=body, timeout=60)
        resp.raise_for_status()
        return _get_nested(resp.json(), self._response_path)
