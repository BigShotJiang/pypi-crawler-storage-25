"""Shared Azure bearer token helper for Foundry v2 auth."""

import os
import subprocess


def get_bearer_token() -> str:
    """Return an Azure bearer token for https://ai.azure.com/.

    Resolution order:
    1. ``AZURE_FOUNDRY_TOKEN`` environment variable (fastest, good for CI)
    2. ``az account get-access-token`` subprocess (relies on az login)

    Raises ``ValueError`` with actionable instructions if both fail.
    """
    token = os.getenv("AZURE_FOUNDRY_TOKEN")
    if token:
        return token

    try:
        result = subprocess.run(
            [
                "az",
                "account",
                "get-access-token",
                "--resource",
                "https://ai.azure.com/",
                "--query",
                "accessToken",
                "-o",
                "tsv",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        token = result.stdout.strip()
        if token:
            return token
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    raise ValueError(
        "Could not obtain an Azure bearer token for Foundry v2. "
        "Either set the AZURE_FOUNDRY_TOKEN environment variable, "
        "or run 'az login' so the az CLI can provide a token automatically."
    )
