"""Poll loop: fetch pending eval jobs, invoke agent, submit responses."""

import logging
import time
from typing import List, Dict, Any

import requests

from .agent_config import AgentConfig
from .connectors.base import BaseConnector
from .connectors.foundry import FoundryConnector
from .connectors.http import HTTPConnector

logger = logging.getLogger(__name__)


def make_connector(config: AgentConfig) -> BaseConnector:
    if config.type == "foundry":
        return FoundryConnector(config)
    elif config.type == "http":
        return HTTPConnector(config)
    raise ValueError(f"Unknown agent type: {config.type}")


def _headers(api_key: str) -> Dict[str, str]:
    return {"X-Api-Key": api_key, "Content-Type": "application/json"}


def _fetch_pending(base_url: str, api_key: str) -> List[Dict[str, Any]]:
    resp = requests.get(f"{base_url}/eval-jobs/pending", headers=_headers(api_key), timeout=15)
    resp.raise_for_status()
    return resp.json().get("jobs", [])


def _claim(base_url: str, api_key: str, job_id: str) -> None:
    requests.patch(
        f"{base_url}/eval-jobs/{job_id}",
        headers=_headers(api_key),
        json={"status": "running"},
        timeout=15,
    ).raise_for_status()


def _fetch_dataset(base_url: str, api_key: str, dataset_id: str, version_id: str) -> List[Dict[str, Any]]:
    resp = requests.get(
        f"{base_url}/datasets/{dataset_id}/versions/{version_id}",
        headers=_headers(api_key), timeout=15,
    )
    resp.raise_for_status()
    return resp.json().get("threads", [])


def _submit(base_url: str, api_key: str, job_id: str, responses: List[Dict[str, str]]) -> None:
    requests.post(
        f"{base_url}/eval-jobs/{job_id}/responses",
        headers=_headers(api_key),
        json={"responses": responses},
        timeout=120,
    ).raise_for_status()


def _fail(base_url: str, api_key: str, job_id: str, error: str) -> None:
    requests.patch(
        f"{base_url}/eval-jobs/{job_id}",
        headers=_headers(api_key),
        json={"status": "failed", "error": error},
        timeout=15,
    )


def run_once(base_url: str, api_key: str, connector: BaseConnector) -> int:
    jobs = _fetch_pending(base_url, api_key)
    if not jobs:
        return 0
    processed = 0
    for job in jobs:
        job_id = job["job_id"]
        dataset_id = job.get("dataset_id", "")
        version_id = job.get("version_id", "")
        logger.info("Job %s — dataset %s/%s", job_id, dataset_id, version_id)
        try:
            _claim(base_url, api_key, job_id)
            threads = _fetch_dataset(base_url, api_key, dataset_id, version_id)
            if not threads:
                raise ValueError("Dataset has no threads")
            if "prompt" not in threads[0]:
                raise ValueError("Dataset uses legacy format — regenerate with the new prompt-only format")
            responses = []
            for thread in threads:
                tid = thread["thread_id"]
                prompt = thread["prompt"]
                logger.info("  -> thread %s", tid)
                try:
                    response = connector.invoke(prompt)
                    responses.append({"thread_id": tid, "prompt": prompt, "response": response})
                    logger.info("  ok thread %s", tid)
                except Exception as exc:
                    logger.warning("  fail thread %s: %s", tid, exc)
                    responses.append({"thread_id": tid, "prompt": prompt, "response": f"[Agent failed: {exc}]"})
            logger.info("Submitting %d responses...", len(responses))
            _submit(base_url, api_key, job_id, responses)
            logger.info("Job %s done.", job_id)
            processed += 1
        except Exception as exc:
            logger.error("Job %s failed: %s", job_id, exc)
            _fail(base_url, api_key, job_id, str(exc))
    return processed


def run_loop(base_url: str, api_key: str, connector: BaseConnector, poll_interval: int = 10) -> None:
    logger.info("afterai-runner eval started. Polling every %ds. Ctrl+C to stop.", poll_interval)
    try:
        while True:
            processed = run_once(base_url, api_key, connector)
            if processed == 0:
                logger.debug("No pending jobs. Waiting %ds...", poll_interval)
            time.sleep(poll_interval)
    except KeyboardInterrupt:
        logger.info("Stopped.")
    finally:
        connector.close()
