"""Load agent config from a local YAML file."""

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

import yaml


def _resolve_env(value: str) -> str:
    """Replace ${VAR} references with environment variable values."""
    def replacer(m):
        var = m.group(1)
        val = os.getenv(var)
        if val is None:
            raise ValueError(f"Environment variable '{var}' not set (referenced in agent config)")
        return val
    return re.sub(r"\$\{(\w+)\}", replacer, str(value))


@dataclass
class AgentConfig:
    type: str  # "foundry" or "http"
    # Foundry
    project_endpoint: Optional[str] = None
    agent_id: Optional[str] = None
    api_key: Optional[str] = None
    foundry_version: str = "v2"
    agent_name: Optional[str] = None
    # HTTP
    url: Optional[str] = None
    headers: Dict[str, str] = field(default_factory=dict)
    body_template: str = '{{"message": "{prompt}"}}'
    response_path: str = "response"


def load_agent_config(path: str = "afterai-agent.yaml") -> AgentConfig:
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(
            f"Agent config not found: {path}\n"
            "Run 'afterai-runner eval-init' to create a template."
        )
    with open(config_path) as f:
        raw = yaml.safe_load(f) or {}

    agent = raw.get("agent", raw)  # support both {agent: {...}} and flat {...}
    agent_type = agent.get("type", "").lower()
    if agent_type not in ("foundry", "http"):
        raise ValueError(f"agent.type must be 'foundry' or 'http', got: '{agent_type}'")

    cfg = AgentConfig(type=agent_type)

    if agent_type == "foundry":
        cfg.project_endpoint = _resolve_env(agent.get("project_endpoint", "")).rstrip("/")
        if not cfg.project_endpoint:
            raise ValueError("agent.project_endpoint is required for Foundry agents")

        # Resolve optional fields without raising on missing env vars yet
        raw_agent_id = agent.get("agent_id", "")
        raw_agent_name = agent.get("agent_name", "")
        raw_api_key = agent.get("api_key", "")
        raw_foundry_version = agent.get("foundry_version", "")

        cfg.agent_id = _resolve_env(raw_agent_id) if raw_agent_id else None
        cfg.agent_name = _resolve_env(raw_agent_name) if raw_agent_name else None
        cfg.api_key = _resolve_env(raw_api_key) if raw_api_key else None

        # Determine foundry_version
        if raw_foundry_version:
            version = raw_foundry_version.lower()
            if version not in ("v1", "v2"):
                raise ValueError(f"agent.foundry_version must be 'v1' or 'v2', got: '{version}'")
            cfg.foundry_version = version
        elif cfg.agent_id and cfg.agent_name:
            raise ValueError(
                "Both agent_id and agent_name are set but foundry_version is not specified. "
                "Set foundry_version: v1 (uses agent_id) or foundry_version: v2 (uses agent_name)."
            )
        elif cfg.agent_id:
            # agent_id only → v1 legacy
            cfg.foundry_version = "v1"
        else:
            # agent_name or nothing → v2 default
            cfg.foundry_version = "v2"

        # Version-specific validation
        if cfg.foundry_version == "v1":
            if not cfg.agent_id:
                raise ValueError("agent.agent_id is required for Foundry v1 agents")
            if not cfg.api_key:
                raise ValueError("agent.api_key is required for Foundry v1 agents")
        else:  # v2
            if not cfg.agent_name:
                raise ValueError(
                    "agent.agent_name is required for Foundry v2 agents. "
                    "Set it to the name of your agent in Azure AI Foundry."
                )
            # api_key not required for v2 (Bearer token auth via AZURE_FOUNDRY_TOKEN or az CLI)

    elif agent_type == "http":
        cfg.url = _resolve_env(agent.get("url", ""))
        if not cfg.url:
            raise ValueError("agent.url is required for HTTP agents")
        cfg.headers = {k: _resolve_env(v) for k, v in agent.get("headers", {}).items()}
        if "body_template" in agent:
            cfg.body_template = agent["body_template"]
        if "response_path" in agent:
            cfg.response_path = agent["response_path"]

    return cfg
