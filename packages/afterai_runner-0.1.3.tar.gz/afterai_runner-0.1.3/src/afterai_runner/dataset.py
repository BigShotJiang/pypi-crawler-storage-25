"""Fetch agent definition from Foundry and generate an AfterAI eval dataset."""

import requests

from .eval.agent_config import AgentConfig
from .eval.auth import get_bearer_token


def fetch_agent_definition(cfg: AgentConfig) -> dict:
    """Fetch the agent definition from Azure AI Foundry.

    For v2, calls the Foundry agents REST API with Bearer token auth.
    For v1, calls the OpenAI Assistants API with api-key auth.

    Returns the full JSON response as a dict.
    Raises ``RuntimeError`` on non-200 responses.
    """
    if cfg.foundry_version == "v2":
        token = get_bearer_token()
        url = (
            f"{cfg.project_endpoint}/agents/{cfg.agent_name}"
            f"?api-version=2025-11-15-preview"
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
    else:
        url = (
            f"{cfg.project_endpoint}/openai/assistants/{cfg.agent_id}"
            f"?api-version=2024-05-01-preview"
        )
        headers = {
            "api-key": cfg.api_key,
            "Content-Type": "application/json",
        }

    resp = requests.get(url, headers=headers, timeout=30)
    if not resp.ok:
        raise RuntimeError(
            f"Failed to fetch agent definition (HTTP {resp.status_code}): {resp.text[:400]}"
        )
    return resp.json()


def summarize_agent(agent_def: dict, foundry_version: str) -> None:
    """Print a human-readable summary of the agent definition to stdout."""
    if foundry_version == "v2":
        defn = agent_def.get("definition", agent_def)
    else:
        defn = agent_def

    name = agent_def.get("name") or agent_def.get("id", "(unknown)")
    model = defn.get("model", "(unknown)")
    tools_raw = defn.get("tools", [])
    tool_names = [t.get("type", str(t)) for t in tools_raw] if tools_raw else []
    tools_str = ", ".join(tool_names) if tool_names else "(none)"
    instructions = defn.get("instructions") or ""
    if len(instructions) > 300:
        instructions = instructions[:300] + "..."

    print(f"Agent name:     {name}")
    print(f"Model:          {model}")
    print(f"Tools:          {tools_str}")
    print(f"Instructions:   {instructions}")


def generate_dataset(base_url: str, api_key: str, agent_def: dict, foundry_version: str) -> dict:
    """POST to AfterAI to generate an eval dataset from an agent definition.

    Returns the parsed JSON response dict.
    Raises ``RuntimeError`` on non-200 responses.
    """
    description = agent_def.get("name") or agent_def.get("id", "Foundry agent")
    url = f"{base_url}/datasets/generate"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    body = {
        "description": description,
        "agent_definition": agent_def,
    }
    resp = requests.post(url, headers=headers, json=body, timeout=60)
    if not resp.ok:
        raise RuntimeError(
            f"Dataset generation failed (HTTP {resp.status_code}): {resp.text[:400]}"
        )
    return resp.json()
