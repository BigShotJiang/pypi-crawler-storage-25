"""
Build AIS payload from artifact + manifest entry. Runner adds system, external_id, type, created_at, defaults.
"""
from datetime import datetime, timezone
from typing import Any, Dict

from .artifact import ArtifactIn
from .manifest import ManifestArtifact


def _iso_week_from_rfc3339(end: str) -> str:
    """Return YYYY-Www from window.end (RFC3339)."""
    normalized = end.strip().replace("Z", "+00:00")
    dt = datetime.fromisoformat(normalized)
    y, w, _ = dt.isocalendar()
    return f"{y}-W{w:02d}"


def _date_from_rfc3339(s: str) -> str:
    """Return YYYY-MM-DD from RFC3339 string."""
    normalized = s.strip().replace("Z", "+00:00")
    dt = datetime.fromisoformat(normalized)
    return dt.strftime("%Y-%m-%d")


def build_external_id(system: str, signal_key: str, cadence: str, window_end: str) -> str:
    """
    Daily: {system}:{signal_key}:{YYYY-MM-DD}
    Weekly: {system}:{signal_key}:{YYYY-Www} (ISO week from window.end)
    """
    if cadence == "daily":
        return f"{system}:{signal_key}:{_date_from_rfc3339(window_end)}"
    return f"{system}:{signal_key}:{_iso_week_from_rfc3339(window_end)}"


def build_payload(artifact: ArtifactIn, manifest_entry: ManifestArtifact) -> Dict[str, Any]:
    """
    Merge artifact with runner-added fields. Uses system from manifest.
    Runner adds: system, external_id, type="ais", created_at (if missing).
    Defaults: severity="low", confidence=0.8 (if missing).
    """
    system = manifest_entry.system
    window_end = artifact.window.end

    external_id = build_external_id(
        system, artifact.signal_key, artifact.cadence, window_end
    )

    created_at = artifact.created_at
    if not created_at or not created_at.strip():
        created_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    severity = artifact.severity if artifact.severity is not None else "low"
    confidence = artifact.confidence if artifact.confidence is not None else 0.8

    payload: Dict[str, Any] = {
        "system": system,
        "type": "ais",
        "signal_key": artifact.signal_key,
        "cadence": artifact.cadence,
        "window": {"start": artifact.window.start, "end": artifact.window.end},
        "metrics": artifact.metrics,
        "external_id": external_id,
        "created_at": created_at,
        "severity": severity,
        "confidence": confidence,
    }

    if artifact.tags is not None:
        payload["tags"] = artifact.tags
    if artifact.source is not None:
        payload["source"] = artifact.source
    if artifact.evidence_refs is not None:
        payload["evidence_refs"] = artifact.evidence_refs
    if artifact.baseline_ref is not None:
        payload["baseline_ref"] = artifact.baseline_ref

    return payload
