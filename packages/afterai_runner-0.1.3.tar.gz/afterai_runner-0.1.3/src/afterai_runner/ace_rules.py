"""
Minimal out-of-band ACE-from-AIS rule: read AIS via GET /signals/debug,
apply a simple threshold (e.g. N high-severity signals per system in last W hours),
emit inferred ACE via POST /ingest using SDK-style payload.
"""
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

import requests

from .config import get_api_key, get_base_url


def _parse_rfc3339_to_utc(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        normalized = s.strip().replace("Z", "+00:00")
        dt = datetime.fromisoformat(normalized)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def fetch_signals_debug(
    base_url: str,
    api_key: str,
    limit: int = 100,
    system: Optional[str] = None,
    timeout: int = 30,
) -> List[Dict[str, Any]]:
    """GET /signals/debug; returns list of items with id, system, severity, created_at, etc."""
    url = f"{base_url.rstrip('/')}/signals/debug"
    params: Dict[str, Any] = {"limit": limit}
    if system:
        params["system"] = system
    resp = requests.get(
        url,
        headers={"X-API-Key": api_key},
        params=params,
        timeout=timeout,
    )
    resp.raise_for_status()
    data = resp.json()
    return data.get("items") or []


def filter_by_severity_and_hours(
    items: List[Dict[str, Any]],
    severities: List[str],
    hours: int,
    now: Optional[datetime] = None,
) -> List[Dict[str, Any]]:
    """Keep items whose severity is in severities and created_at is within the last hours."""
    if now is None:
        now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=hours)
    out = []
    for item in items:
        if item.get("severity") not in severities:
            continue
        created = _parse_rfc3339_to_utc(item.get("created_at"))
        if created is None or created < cutoff:
            continue
        out.append(item)
    return out


def group_by_system(items: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """Group debug items by system; each value is list of items (with id)."""
    by_system: Dict[str, List[Dict[str, Any]]] = {}
    for item in items:
        sys_id = (item.get("system") or "").strip()
        if not sys_id:
            continue
        by_system.setdefault(sys_id, []).append(item)
    return by_system


def build_inferred_ace_payload(
    system_id: str,
    ais_refs: List[str],
    occurred_at: str,
    environment: str = "production",
) -> Dict[str, Any]:
    """Build minimal ACE payload for inferred ACE (drift_detector source, pending, extensions.ais_refs)."""
    return {
        "schema_version": "1.0.0",
        "occurred_at": occurred_at,
        "system": {
            "system_id": system_id,
            "name": system_id,
            "type": "other",
        },
        "source": {
            "origin": "drift_detector",
            "actor": {"actor_type": "system", "actor_id": "afterai-drift"},
        },
        "change": {
            "change_type": "eval",
            "intent": "observed",
            "baseline": {},
            "candidate": {},
        },
        "risk": {
            "severity": "high",
            "blast_radius": "single_app",
            "customer_impact": "minor",
        },
        "fingerprints": {
            "change_fingerprint": "ais-escalation",
        },
        "environment": environment,
        "status": "pending",
        "extensions": {"ais_refs": ais_refs},
    }


def post_ace(
    base_url: str,
    api_key: str,
    payload: Dict[str, Any],
    idempotency_key: Optional[str] = None,
    timeout: int = 30,
) -> Dict[str, Any]:
    """POST ACE to /ingest. Returns response JSON."""
    url = f"{base_url.rstrip('/')}/ingest"
    headers = {"X-API-Key": api_key, "Content-Type": "application/json"}
    if idempotency_key:
        headers["Idempotency-Key"] = idempotency_key
    resp = requests.post(url, json=payload, headers=headers, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def run_ace_from_ais_rule(
    base_url: str,
    api_key: str,
    min_signals: int = 2,
    severities: Optional[List[str]] = None,
    hours: int = 24,
    limit: int = 100,
    system_filter: Optional[str] = None,
    dry_run: bool = False,
) -> List[Dict[str, Any]]:
    """
    Fetch AIS, filter by severity and time, group by system; for each system with
    >= min_signals matching items, build and POST an inferred ACE (unless dry_run).
    Returns list of ACE responses (or would-be payloads if dry_run).
    """
    if severities is None:
        severities = ["high", "critical"]
    items = fetch_signals_debug(base_url, api_key, limit=limit, system=system_filter)
    filtered = filter_by_severity_and_hours(items, severities, hours)
    by_system = group_by_system(filtered)
    now_iso = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    results = []
    for sys_id, sys_items in by_system.items():
        if len(sys_items) < min_signals:
            continue
        signal_ids = [it["id"] for it in sys_items if it.get("id")]
        if not signal_ids:
            continue
        payload = build_inferred_ace_payload(
            system_id=sys_id,
            ais_refs=signal_ids,
            occurred_at=now_iso,
        )
        if dry_run:
            results.append({"system": sys_id, "dry_run": True, "payload": payload})
            continue
        idempotency_key = f"ace-from-ais:{sys_id}:{now_iso[:13]}"
        try:
            ack = post_ace(base_url, api_key, payload, idempotency_key=idempotency_key)
            results.append({"system": sys_id, "ace_id": ack.get("ace_id"), "ack": ack})
        except requests.exceptions.HTTPError as e:
            results.append({"system": sys_id, "error": str(e), "response": getattr(e.response, "text", "")})
    return results
