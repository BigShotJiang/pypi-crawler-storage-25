"""Tests for payload building and external_id formatting."""
from afterai_runner.artifact import ArtifactIn, WindowModel
from afterai_runner.manifest import ManifestArtifact
from afterai_runner.payload import build_external_id, build_payload


def _artifact(
    signal_key: str = "D1",
    cadence: str = "daily",
    window_start: str = "2026-02-03T00:00:00Z",
    window_end: str = "2026-02-03T23:59:59Z",
    metrics: dict | None = None,
    severity: str | None = None,
    confidence: float | None = None,
    created_at: str | None = None,
) -> ArtifactIn:
    return ArtifactIn(
        signal_key=signal_key,
        cadence=cadence,
        window=WindowModel(start=window_start, end=window_end),
        metrics=metrics or {"x": 1},
        severity=severity,
        confidence=confidence,
        created_at=created_at,
    )


def test_external_id_daily() -> None:
    eid = build_external_id("my-system-01", "D1", "daily", "2026-02-03T23:59:59Z")
    assert eid == "my-system-01:D1:2026-02-03"


def test_external_id_weekly() -> None:
    # 2026-02-08 is in week 6 (Sunday)
    eid = build_external_id("my-system-01", "W1", "weekly", "2026-02-08T23:59:59Z")
    assert eid == "my-system-01:W1:2026-W06"


def test_build_payload_has_system_and_type() -> None:
    artifact = _artifact()
    entry = ManifestArtifact(system="my-system-01", path="/tmp/D1.json")
    payload = build_payload(artifact, entry)
    assert payload["system"] == "my-system-01"
    assert payload["type"] == "ais"
    assert payload["signal_key"] == "D1"
    assert payload["cadence"] == "daily"
    assert "external_id" in payload
    assert payload["external_id"] == "my-system-01:D1:2026-02-03"


def test_build_payload_defaults_severity_confidence() -> None:
    artifact = _artifact(severity=None, confidence=None)
    entry = ManifestArtifact(system="s", path="/tmp/d.json")
    payload = build_payload(artifact, entry)
    assert payload["severity"] == "low"
    assert payload["confidence"] == 0.8


def test_build_payload_passthrough_severity_confidence() -> None:
    artifact = _artifact(severity="high", confidence=0.95)
    entry = ManifestArtifact(system="s", path="/tmp/d.json")
    payload = build_payload(artifact, entry)
    assert payload["severity"] == "high"
    assert payload["confidence"] == 0.95


def test_build_payload_created_at_filled_if_missing() -> None:
    artifact = _artifact(created_at=None)
    entry = ManifestArtifact(system="s", path="/tmp/d.json")
    payload = build_payload(artifact, entry)
    assert "created_at" in payload
    assert payload["created_at"]


def test_build_payload_created_at_preserved_if_present() -> None:
    artifact = _artifact(created_at="2026-02-03T17:54:01Z")
    entry = ManifestArtifact(system="s", path="/tmp/d.json")
    payload = build_payload(artifact, entry)
    assert payload["created_at"] == "2026-02-03T17:54:01Z"


def test_build_payload_optional_passthrough() -> None:
    artifact = ArtifactIn(
        signal_key="W1",
        cadence="weekly",
        window=WindowModel(start="2026-02-03T00:00:00Z", end="2026-02-08T23:59:59Z"),
        metrics={"recall": 0.9},
        tags=["eval", "weekly"],
        source={"runner": "v0"},
        evidence_refs=["run-123"],
        baseline_ref="snap-456",
    )
    entry = ManifestArtifact(system="sys", path="/w1.json")
    payload = build_payload(artifact, entry)
    assert payload["tags"] == ["eval", "weekly"]
    assert payload["source"] == {"runner": "v0"}
    assert payload["evidence_refs"] == ["run-123"]
    assert payload["baseline_ref"] == "snap-456"
    assert payload["external_id"] == "sys:W1:2026-W06"
