"""Tests for emit (HTTP POST)."""
from unittest.mock import patch, MagicMock

import pytest
import requests

from afterai_runner.emit import emit_signal


def test_emit_signal_success() -> None:
    payload = {
        "system": "my-system-01",
        "type": "ais",
        "signal_key": "D1",
        "cadence": "daily",
        "window": {"start": "2026-02-03T00:00:00Z", "end": "2026-02-03T23:59:59Z"},
        "metrics": {"x": 1},
        "external_id": "my-system-01:D1:2026-02-03",
        "created_at": "2026-02-03T17:00:00Z",
        "severity": "low",
        "confidence": 0.8,
    }
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "accepted": True,
        "signal_id": "sig-123",
        "created_at": "2026-02-03T17:00:01Z",
        "tenant_id": "tenant-1",
    }
    mock_response.raise_for_status = MagicMock()

    with patch("afterai_runner.emit.requests.post", return_value=mock_response) as post:
        result = emit_signal(payload, "ak_test", "https://api.useafter.ai")
        assert result["signal_id"] == "sig-123"
        assert result["accepted"] is True
        post.assert_called_once()
        call_kw = post.call_args[1]
        assert call_kw["headers"]["X-API-Key"] == "ak_test"
        assert call_kw["json"] == payload
        assert "signals" in post.call_args[0][0]


def test_emit_signal_http_error() -> None:
    payload = {"system": "s", "type": "ais", "signal_key": "D1", "cadence": "daily", "window": {"start": "2026-02-03T00:00:00Z", "end": "2026-02-03T23:59:59Z"}, "metrics": {}, "external_id": "s:D1:2026-02-03", "created_at": "2026-02-03T00:00:00Z", "severity": "low", "confidence": 0.8}
    mock_response = MagicMock()
    mock_response.status_code = 401
    mock_response.text = "Unauthorized"
    mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError(response=mock_response)

    with patch("afterai_runner.emit.requests.post", return_value=mock_response):
        with pytest.raises(requests.exceptions.HTTPError):
            emit_signal(payload, "bad-key", "https://api.useafter.ai")
