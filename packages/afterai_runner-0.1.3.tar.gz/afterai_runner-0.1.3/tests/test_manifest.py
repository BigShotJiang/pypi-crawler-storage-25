"""Tests for manifest loading and validation."""
import json
import tempfile
from pathlib import Path

import pytest
import yaml

from afterai_runner.manifest import (
    Manifest,
    ManifestArtifact,
    load_manifest,
    _REMOTE_PREFIXES,
)


def test_manifest_artifact_local_path() -> None:
    a = ManifestArtifact(system="sys1", path="/tmp/D1.json")
    assert a.system == "sys1"
    assert a.path == "/tmp/D1.json"


def test_manifest_artifact_rejects_remote_paths() -> None:
    for prefix in _REMOTE_PREFIXES:
        with pytest.raises(ValueError, match="local filesystem"):
            ManifestArtifact(system="s", path=f"{prefix}bucket/key.json")


def test_manifest_artifact_empty_path_rejected() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        ManifestArtifact(system="s", path="   ")


def test_manifest_minimal() -> None:
    m = Manifest(version="2026-02", artifacts=[])
    assert m.version == "2026-02"
    assert m.artifacts == []


def test_manifest_with_artifacts() -> None:
    m = Manifest(
        version="2026-02",
        artifacts=[
            ManifestArtifact(system="my-system-01", path="/path/to/D1.json"),
            ManifestArtifact(system="my-system-01", path="/path/to/W1.json"),
        ],
    )
    assert len(m.artifacts) == 2
    assert m.artifacts[0].system == "my-system-01"
    assert m.artifacts[0].path == "/path/to/D1.json"


def test_load_manifest_json() -> None:
    data = {
        "version": "2026-02",
        "artifacts": [
            {"system": "my-system-01", "path": "/path/to/D1-2026-02-03.json"},
            {"system": "my-system-01", "path": "/path/to/W1-2026-W05.json"},
        ],
    }
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        f.write(json.dumps(data).encode("utf-8"))
        path = f.name
    try:
        m = load_manifest(path)
        assert m.version == "2026-02"
        assert len(m.artifacts) == 2
        assert m.artifacts[0].path == "/path/to/D1-2026-02-03.json"
    finally:
        Path(path).unlink(missing_ok=True)


def test_load_manifest_yaml() -> None:
    data = {
        "version": "2026-02",
        "artifacts": [
            {"system": "my-system-01", "path": "/path/to/D1.json"},
        ],
    }
    with tempfile.NamedTemporaryFile(suffix=".yaml", delete=False) as f:
        f.write(yaml.dump(data).encode("utf-8"))
        path = f.name
    try:
        m = load_manifest(path)
        assert m.version == "2026-02"
        assert len(m.artifacts) == 1
    finally:
        Path(path).unlink(missing_ok=True)


def test_load_manifest_missing_file() -> None:
    with pytest.raises(FileNotFoundError, match="not found"):
        load_manifest("/nonexistent/manifest.json")


def test_load_manifest_invalid_json() -> None:
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        f.write(b"not json {")
        path = f.name
    try:
        with pytest.raises(ValueError, match="parse error"):
            load_manifest(path)
    finally:
        Path(path).unlink(missing_ok=True)


def test_load_manifest_artifacts_not_array() -> None:
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        f.write(json.dumps({"version": "2026-02", "artifacts": "not-a-list"}).encode("utf-8"))
        path = f.name
    try:
        with pytest.raises(ValueError, match="must be an array"):
            load_manifest(path)
    finally:
        Path(path).unlink(missing_ok=True)


def test_load_manifest_without_version() -> None:
    """Manifest without version parses successfully (version is optional per spec)."""
    data = {
        "artifacts": [
            {"system": "my-system-01", "path": "/path/to/D1.json"},
        ],
    }
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        f.write(json.dumps(data).encode("utf-8"))
        path = f.name
    try:
        m = load_manifest(path)
        assert m.version is None
        assert len(m.artifacts) == 1
        assert m.artifacts[0].system == "my-system-01"
        assert m.artifacts[0].path == "/path/to/D1.json"
    finally:
        Path(path).unlink(missing_ok=True)
