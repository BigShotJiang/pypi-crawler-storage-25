"""Tests for artifact loading and validation."""
import json
import tempfile
from pathlib import Path

import pytest

from afterai_runner.artifact import (
    ArtifactIn,
    WindowModel,
    load_artifact,
    VALID_SIGNAL_KEYS,
)


def test_window_rfc3339() -> None:
    w = WindowModel(start="2026-02-03T00:00:00Z", end="2026-02-03T23:59:59Z")
    assert w.start == "2026-02-03T00:00:00Z"
    assert w.end == "2026-02-03T23:59:59Z"


def test_window_invalid_rfc3339() -> None:
    with pytest.raises(ValueError, match="Invalid RFC3339"):
        WindowModel(start="not-a-date", end="2026-02-03T23:59:59Z")


def test_artifact_valid_signal_keys() -> None:
    for key in VALID_SIGNAL_KEYS:
        a = ArtifactIn(
            signal_key=key,
            cadence="daily" if key.startswith("D") else "weekly",
            window=WindowModel(start="2026-02-03T00:00:00Z", end="2026-02-03T23:59:59Z"),
            metrics={"x": 1},
        )
        assert a.signal_key == key


def test_artifact_invalid_signal_key() -> None:
    with pytest.raises(ValueError, match="D1–D5, W1–W5"):
        ArtifactIn(
            signal_key="X1",
            cadence="daily",
            window=WindowModel(start="2026-02-03T00:00:00Z", end="2026-02-03T23:59:59Z"),
            metrics={},
        )


def test_artifact_invalid_cadence() -> None:
    with pytest.raises(ValueError, match="daily.*weekly"):
        ArtifactIn(
            signal_key="D1",
            cadence="monthly",
            window=WindowModel(start="2026-02-03T00:00:00Z", end="2026-02-03T23:59:59Z"),
            metrics={},
        )


def test_artifact_minimal() -> None:
    a = ArtifactIn(
        signal_key="D1",
        cadence="daily",
        window=WindowModel(start="2026-02-03T00:00:00Z", end="2026-02-03T23:59:59Z"),
        metrics={"score_mean": 0.87},
    )
    assert a.signal_key == "D1"
    assert a.cadence == "daily"
    assert a.metrics == {"score_mean": 0.87}
    assert a.severity is None
    assert a.confidence is None


def test_load_artifact_success() -> None:
    data = {
        "signal_key": "D1",
        "cadence": "daily",
        "window": {"start": "2026-02-03T00:00:00Z", "end": "2026-02-03T23:59:59Z"},
        "metrics": {"score_mean": 0.87, "fail_rate": 0.03},
    }
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        f.write(json.dumps(data).encode("utf-8"))
        path = f.name
    try:
        a = load_artifact(path)
        assert a.signal_key == "D1"
        assert a.cadence == "daily"
        assert a.metrics["score_mean"] == 0.87
    finally:
        Path(path).unlink(missing_ok=True)


def test_load_artifact_missing_file() -> None:
    with pytest.raises(FileNotFoundError, match="not found"):
        load_artifact("/nonexistent/artifact.json")


def test_load_artifact_missing_required_key() -> None:
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        f.write(json.dumps({"signal_key": "D1", "cadence": "daily"}).encode("utf-8"))
        path = f.name
    try:
        with pytest.raises(ValueError, match="missing required key"):
            load_artifact(path)
    finally:
        Path(path).unlink(missing_ok=True)


def test_load_artifact_window_not_object() -> None:
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        f.write(
            json.dumps(
                {
                    "signal_key": "D1",
                    "cadence": "daily",
                    "window": "invalid",
                    "metrics": {},
                }
            ).encode("utf-8")
        )
        path = f.name
    try:
        with pytest.raises(ValueError, match="window"):
            load_artifact(path)
    finally:
        Path(path).unlink(missing_ok=True)
