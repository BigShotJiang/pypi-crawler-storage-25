"""
Umarise Core API client.

All hashing is done locally. Only the hash is sent to the API.
Umarise is content-blind: we never receive your file.
"""

from __future__ import annotations

import httpx
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from umarise.hasher import hash_file


CORE_API_BASE = "https://core.umarise.com"


class UmariseError(Exception):
    """Base exception for Umarise API errors."""

    def __init__(self, message: str, code: Optional[str] = None, status: Optional[int] = None):
        super().__init__(message)
        self.code = code
        self.status = status


@dataclass
class AnchorResult:
    """Result of anchoring a hash."""
    origin_id: str
    hash: str
    already_existed: bool = False


@dataclass
class ResolveResult:
    """Result of resolving an origin."""
    origin_id: str
    hash: str
    hash_algo: str
    captured_at: str
    proof_status: Optional[str] = None
    bitcoin_block_height: Optional[int] = None
    anchored_at: Optional[str] = None


@dataclass
class ProofResult:
    """Result of fetching a proof."""
    status: str  # 'pending' | 'anchored' | 'not_found'
    proof_bytes: Optional[bytes] = None
    bitcoin_block_height: Optional[int] = None
    anchored_at: Optional[str] = None


class UmariseClient:
    """Client for the Umarise Core API.

    Args:
        api_key: Your Umarise API key (um_... for sandbox, um_live_... for production).
                 Get one at https://umarise.com/developers
        base_url: API base URL (default: https://core.umarise.com)
        timeout: Request timeout in seconds (default: 30)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = CORE_API_BASE,
        timeout: float = 30,
    ):
        if not api_key:
            raise UmariseError(
                "No API key provided.\n"
                "Get your key at https://umarise.com/developers"
            )
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    def _headers(self) -> dict:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
        }

    def anchor(self, file_path: str | Path) -> AnchorResult:
        """Anchor a file to Bitcoin.

        1. Computes SHA-256 hash locally (file never leaves your machine)
        2. Checks if hash already exists (deduplication)
        3. If new: submits hash to Umarise registry

        Args:
            file_path: Path to the file to anchor.

        Returns:
            AnchorResult with origin_id and hash.
        """
        path = Path(file_path)
        if not path.exists():
            raise UmariseError(f"File not found: {file_path}")

        file_hash = hash_file(path)

        # Check for existing anchor (deduplication)
        existing = self.resolve(hash=file_hash)
        if existing:
            return AnchorResult(
                origin_id=existing.origin_id,
                hash=file_hash,
                already_existed=True,
            )

        # Submit new hash
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                f"{self._base_url}/v1-core-origins",
                headers=self._headers(),
                json={"hash": file_hash},
            )

        if resp.status_code == 409:
            # Race condition: hash was anchored between resolve and submit
            existing = self.resolve(hash=file_hash)
            if existing:
                return AnchorResult(
                    origin_id=existing.origin_id,
                    hash=file_hash,
                    already_existed=True,
                )

        if resp.status_code not in (200, 201):
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            raise UmariseError(
                data.get("error", {}).get("message", f"API error: {resp.status_code}"),
                code=data.get("error", {}).get("code"),
                status=resp.status_code,
            )

        data = resp.json()
        return AnchorResult(
            origin_id=data["origin_id"],
            hash=file_hash,
        )

    def anchor_hash(self, hash: str) -> AnchorResult:
        """Anchor a pre-computed hash (for programmatic use).

        Args:
            hash: SHA-256 hash with 'sha256:' prefix.

        Returns:
            AnchorResult with origin_id and hash.
        """
        existing = self.resolve(hash=hash)
        if existing:
            return AnchorResult(
                origin_id=existing.origin_id,
                hash=hash,
                already_existed=True,
            )

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                f"{self._base_url}/v1-core-origins",
                headers=self._headers(),
                json={"hash": hash},
            )

        if resp.status_code not in (200, 201):
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            raise UmariseError(
                data.get("error", {}).get("message", f"API error: {resp.status_code}"),
                code=data.get("error", {}).get("code"),
                status=resp.status_code,
            )

        data = resp.json()
        return AnchorResult(origin_id=data["origin_id"], hash=hash)

    def resolve(
        self,
        *,
        origin_id: Optional[str] = None,
        hash: Optional[str] = None,
        token: Optional[str] = None,
    ) -> Optional[ResolveResult]:
        """Resolve origin metadata. No API key required.

        Args:
            origin_id: Look up by origin UUID.
            hash: Look up by SHA-256 hash.
            token: Look up by short token.

        Returns:
            ResolveResult or None if not found.
        """
        params = {}
        if origin_id:
            params["origin_id"] = origin_id
        elif hash:
            params["hash"] = hash
        elif token:
            params["token"] = token
        else:
            raise UmariseError("Provide origin_id, hash, or token")

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.get(f"{self._base_url}/v1-core-resolve", params=params)

        if resp.status_code == 404:
            return None
        if resp.status_code != 200:
            return None

        data = resp.json()
        return ResolveResult(
            origin_id=data["origin_id"],
            hash=data["hash"],
            hash_algo=data.get("hash_algo", "sha256"),
            captured_at=data["captured_at"],
            proof_status=data.get("proof_status"),
            bitcoin_block_height=data.get("bitcoin_block_height"),
            anchored_at=data.get("anchored_at"),
        )

    def proof(self, origin_id: str) -> ProofResult:
        """Fetch proof status and binary .ots proof.

        Args:
            origin_id: The origin UUID.

        Returns:
            ProofResult with status and optional proof bytes.
        """
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.get(
                f"{self._base_url}/v1-core-proof",
                params={"origin_id": origin_id},
                headers={"Accept": "application/octet-stream, application/json"},
            )

        if resp.status_code == 200:
            block_height = resp.headers.get("x-bitcoin-block-height")
            anchored_at = resp.headers.get("x-anchored-at")
            return ProofResult(
                status="anchored",
                proof_bytes=resp.content,
                bitcoin_block_height=int(block_height) if block_height else None,
                anchored_at=anchored_at,
            )

        if resp.status_code == 202:
            return ProofResult(status="pending")

        return ProofResult(status="not_found")

    def verify(self, hash: str) -> dict:
        """Verify a hash against the Umarise registry.

        No API key required. Public endpoint.

        Args:
            hash: SHA-256 hash (with or without 'sha256:' prefix).

        Returns:
            Dict with 'found' (bool) and optional 'origin' metadata.
        """
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                f"{self._base_url}/v1-core-verify",
                json={"hash": hash},
                headers={"Content-Type": "application/json"},
            )

        if resp.status_code == 200:
            return {"found": True, "origin": resp.json()}
        return {"found": False}
