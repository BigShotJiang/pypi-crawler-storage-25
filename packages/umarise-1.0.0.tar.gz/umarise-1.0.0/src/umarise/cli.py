"""
Umarise CLI — anchor files to Bitcoin, verify proofs offline.

Usage:
    umarise anchor <file>     Hash and anchor a file
    umarise proof <file>      Full lifecycle: anchor + resolve + download proof
    umarise verify <file>     Verify a file against its .proof bundle
"""

import json
import os
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import click

from umarise import __version__
from umarise.client import UmariseClient, UmariseError
from umarise.hasher import hash_file


def _get_api_key(api_key: str | None) -> str:
    key = api_key or os.environ.get("UMARISE_API_KEY")
    if not key:
        click.echo(
            "✗ No API key found.\n"
            "  Set UMARISE_API_KEY environment variable or pass --api-key <key>.\n"
            "  Get your key at https://umarise.com/developers",
            err=True,
        )
        sys.exit(1)
    return key


@click.group()
@click.version_option(__version__, prog_name="umarise")
def main():
    """Anchor files to Bitcoin. Verify proofs offline."""
    pass


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--api-key", default=None, help="API key (overrides UMARISE_API_KEY)")
def anchor(file: str, api_key: str | None):
    """Hash a file and anchor it to the Umarise registry."""
    key = _get_api_key(api_key)
    client = UmariseClient(api_key=key)
    path = Path(file).resolve()

    try:
        result = client.anchor(path)
    except UmariseError as e:
        click.echo(f"\n✗ {e}", err=True)
        sys.exit(1)

    if result.already_existed:
        click.echo(f"✓ hash: {result.hash} (already anchored)")
        click.echo(f"✓ origin_id: {result.origin_id}")
    else:
        click.echo(f"✓ hash computed: {result.hash}")
        click.echo(f"✓ anchored: origin_id {result.origin_id}")

    # Build certificate
    certificate = {
        "version": "1.0",
        "origin_id": result.origin_id,
        "hash": result.hash,
        "hash_algo": "sha256",
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "proof_status": "pending",
        "issuer": "https://core.umarise.com",
        "spec": "https://anchoring-spec.org/v1.0/",
    }

    # Try to fetch proof
    proof_result = client.proof(result.origin_id)
    if proof_result.status == "anchored" and proof_result.proof_bytes:
        certificate["proof_status"] = "anchored"
        certificate["bitcoin_block_height"] = proof_result.bitcoin_block_height
        certificate["anchored_at"] = proof_result.anchored_at
        click.echo(f"✓ proof.ots included (Bitcoin block {proof_result.bitcoin_block_height})")
    else:
        click.echo("ℹ proof.ots pending — Bitcoin confirmation takes ~2 hours")
        click.echo(f"  Run 'umarise verify {file}' later to check status")

    # Write .proof ZIP
    proof_path = Path(f"{path}.proof")
    with zipfile.ZipFile(proof_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("certificate.json", json.dumps(certificate, indent=2))
        if proof_result.status == "anchored" and proof_result.proof_bytes:
            zf.writestr("proof.ots", proof_result.proof_bytes)

    # Write certificate.json receipt
    cert_path = Path(f"{path}.certificate.json")
    cert_path.write_text(json.dumps(certificate, indent=2))

    has_ots = certificate["proof_status"] == "anchored"
    if has_ots:
        click.echo(f"✓ proof saved: {file}.proof")
    else:
        click.echo(f"✓ certificate saved: {file}.proof")
    click.echo(f"✓ receipt: {file}.certificate.json")


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--api-key", default=None, help="API key (overrides UMARISE_API_KEY)")
def proof(file: str, api_key: str | None):
    """Full proof lifecycle: anchor, resolve, download, verify — one command."""
    key = _get_api_key(api_key)
    client = UmariseClient(api_key=key)
    path = Path(file).resolve()

    # Anchor (with deduplication)
    try:
        anchor_result = client.anchor(path)
    except UmariseError as e:
        click.echo(f"\n✗ {e}", err=True)
        sys.exit(1)

    if anchor_result.already_existed:
        click.echo(f"✓ hash: {anchor_result.hash} (already anchored)")
        click.echo(f"✓ origin_id: {anchor_result.origin_id}")
    else:
        click.echo(f"✓ hash computed: {anchor_result.hash}")
        click.echo(f"✓ anchored: origin_id {anchor_result.origin_id}")

    # Fetch proof
    proof_result = client.proof(anchor_result.origin_id)

    if proof_result.status != "anchored" or not proof_result.proof_bytes:
        click.echo("⏳ proof pending — run again later")
        return

    click.echo(f"✓ anchored in Bitcoin block {proof_result.bitcoin_block_height}")

    # Format date
    if proof_result.anchored_at:
        try:
            dt = datetime.fromisoformat(proof_result.anchored_at.replace("Z", "+00:00"))
            click.echo(f"✓ no later than: {dt.strftime('%Y-%m-%d')}")
        except ValueError:
            click.echo(f"✓ anchored at: {proof_result.anchored_at}")

    # Build certificate
    certificate = {
        "version": "1.0",
        "origin_id": anchor_result.origin_id,
        "hash": anchor_result.hash,
        "hash_algo": "sha256",
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "anchored_at": proof_result.anchored_at,
        "bitcoin_block_height": proof_result.bitcoin_block_height,
        "proof_status": "anchored",
        "issuer": "https://core.umarise.com",
        "spec": "https://anchoring-spec.org/v1.0/",
    }

    # Write .proof ZIP with artifact
    proof_path = Path(f"{path}.proof")
    with zipfile.ZipFile(proof_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("certificate.json", json.dumps(certificate, indent=2))
        zf.writestr("proof.ots", proof_result.proof_bytes)
        # Include original artifact
        zf.write(path, f"artifact{path.suffix}")
        # VERIFY.txt
        zf.writestr("VERIFY.txt", _verify_instructions(anchor_result.hash, path.name))

    click.echo(f"✓ saved: {file}.proof")

    # Extract proof directory
    extract_dir = path.parent / f"{path.name}-proof"
    extract_dir.mkdir(exist_ok=True)
    with zipfile.ZipFile(proof_path, "r") as zf:
        zf.extractall(extract_dir)
    click.echo(f"✓ extracted: {path.name}-proof/")

    # Verify locally
    file_hash = hash_file(path)
    if file_hash == anchor_result.hash:
        click.echo("✓ proof valid — independent of Umarise")
    else:
        click.echo("✗ hash mismatch — file may have been modified", err=True)
        sys.exit(1)


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.argument("proof_file", required=False, default=None)
def verify(file: str, proof_file: str | None):
    """Verify a file against its .proof bundle."""
    path = Path(file).resolve()
    proof_path = Path(proof_file) if proof_file else Path(f"{path}.proof")

    if not proof_path.exists():
        click.echo(
            f"\n✗ Proof not found: {proof_path}\n"
            "If you already anchored this file, the proof may still be pending (~2 hours for Bitcoin confirmation).\n"
            'Run "umarise proof <file>" again later to download the .proof bundle.',
            err=True,
        )
        sys.exit(1)

    # Extract certificate from ZIP
    try:
        with zipfile.ZipFile(proof_path, "r") as zf:
            cert_data = json.loads(zf.read("certificate.json"))
            has_ots = "proof.ots" in zf.namelist()
    except (zipfile.BadZipFile, KeyError):
        click.echo("✗ Invalid .proof bundle", err=True)
        sys.exit(1)

    # Hash check
    file_hash = hash_file(path)
    if file_hash != cert_data.get("hash"):
        click.echo("✗ hash does NOT match — file may have been modified", err=True)
        sys.exit(1)

    click.echo("✓ hash matches")

    # Offline proof check
    if has_ots and cert_data.get("proof_status") == "anchored":
        block = cert_data.get("bitcoin_block_height")
        if block:
            click.echo(f"✓ anchored in Bitcoin block {block}")
        anchored_at = cert_data.get("anchored_at")
        if anchored_at:
            try:
                dt = datetime.fromisoformat(anchored_at.replace("Z", "+00:00"))
                click.echo(f"✓ no later than: {dt.strftime('%Y-%m-%d')}")
            except ValueError:
                pass
        click.echo("✓ proof valid — independent of Umarise")
    else:
        click.echo("⏳ proof status: pending (awaiting Bitcoin confirmation)")
        click.echo("  Bitcoin confirmation takes ~2 hours. Run verify again later.")

        # Try online check
        try:
            client = UmariseClient(api_key="anon")
            origin_id = cert_data.get("origin_id")
            if origin_id:
                proof_result = client.proof(origin_id)
                if proof_result.status == "anchored":
                    click.echo(f"✓ anchored in Bitcoin block {proof_result.bitcoin_block_height}")
                    if proof_result.anchored_at:
                        dt = datetime.fromisoformat(proof_result.anchored_at.replace("Z", "+00:00"))
                        click.echo(f"✓ no later than: {dt.strftime('%Y-%m-%d')}")
                    click.echo("✓ proof valid — independent of Umarise")
        except Exception:
            pass


def _verify_instructions(hash: str, filename: str) -> str:
    return f"""VERIFICATION INSTRUCTIONS
========================

File: {filename}
Hash: {hash}

To verify this proof independently:

1. Compute the SHA-256 hash of the original file:
   shasum -a 256 "{filename}"

2. Compare with the hash in certificate.json

3. Verify the OpenTimestamps proof:
   ots verify proof.ots

4. Or visit: https://verify-anchoring.org

This proof is valid independent of Umarise.
The Anchoring Specification: https://anchoring-spec.org
"""


if __name__ == "__main__":
    main()
