"""
Umarise — Anchor files to Bitcoin. Verify proofs offline.

Content-blind proof-of-existence infrastructure.
Umarise never receives your file, only its SHA-256 hash.

Usage:
    from umarise import UmariseClient

    client = UmariseClient(api_key="um_...")
    result = client.anchor("path/to/file.pdf")
    print(result.origin_id)

CLI:
    umarise anchor file.pdf
    umarise proof file.pdf
    umarise verify file.pdf

Documentation: https://umarise.com/developers
Specification: https://anchoring-spec.org
"""

__version__ = "1.0.0"

from umarise.client import UmariseClient
from umarise.hasher import hash_file, hash_bytes

__all__ = ["UmariseClient", "hash_file", "hash_bytes"]
