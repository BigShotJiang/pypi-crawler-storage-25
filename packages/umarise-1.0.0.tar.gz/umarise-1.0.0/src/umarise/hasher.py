"""
Local SHA-256 hashing — content never leaves your machine.
"""

import hashlib
from pathlib import Path


def hash_bytes(data: bytes) -> str:
    """Compute SHA-256 hash of raw bytes.

    Returns:
        Hash string with 'sha256:' prefix, e.g. 'sha256:a1b2c3...'
    """
    digest = hashlib.sha256(data).hexdigest()
    return f"sha256:{digest}"


def hash_file(path: str | Path) -> str:
    """Compute SHA-256 hash of a file.

    The file is read in 64KB chunks to support large files
    without loading them entirely into memory.

    Returns:
        Hash string with 'sha256:' prefix.
    """
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return f"sha256:{h.hexdigest()}"
