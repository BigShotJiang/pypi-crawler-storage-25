import requests
import os
from typing import Optional

class LifelineClient:
    def __init__(self, api_key: Optional[str] = None, base_url: str = "https://asad999-lifelineopenapi.hf.space"):
        """
        Initialize the SDK.
        The base_url defaults to your live Hugging Face API.
        An api_key is required for analyzing images, but not for generating keys.
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def generate_api_key(self, email: str, admin_secret: str) -> dict:
        """
        Generates a new API key for a user.
        Requires the master admin_secret set in your Hugging Face space.
        """
        endpoint = f"{self.base_url}/v1/keys/generate"
        
        # FastAPI translates 'admin_secret' to 'admin-secret' in headers
        headers = {
            "admin-secret": admin_secret,
            "Content-Type": "application/json"
        }
        
        payload = {"email": email}
        
        response = requests.post(endpoint, headers=headers, json=payload)
        
        # Raise an error if unauthorized or limit reached
        response.raise_for_status() 
        
        return response.json()

    def analyze(self, image_path: str) -> dict:
        """
        Uploads an ECG image to the backend and returns the prediction.
        """
        if not self.api_key:
            raise ValueError("An API key is required to use the analyze function. Initialize LifelineClient with api_key='your_key'.")
            
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Could not find image at {image_path}")

        endpoint = f"{self.base_url}/v1/analyze"
        
        # Inject the API key into the headers
        headers = {"x-api-key": self.api_key}

        # Open the file in binary mode and send it as multipart/form-data
        with open(image_path, "rb") as f:
            files = {"file": (os.path.basename(image_path), f, "image/jpeg")}
            response = requests.post(endpoint, headers=headers, files=files)

        response.raise_for_status() 
        
        return response.json()