# Lifeline SDK

The official Python client for the Lifeline ECG Analysis API.

## Installation
```bash
pip install lifelinecg-sdk