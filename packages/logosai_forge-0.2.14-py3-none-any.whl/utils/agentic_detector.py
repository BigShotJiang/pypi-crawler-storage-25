"""
Agentic AI Detection Module for FORGE
LogosAI Agentic AI 기능 필요성을 감지하는 모듈

Author: FORGE AI Team
Date: 2025-08-28
Version: 1.0.0
"""

from typing import List, Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


class AgenticDetector:
    """
    LogosAI Agentic AI 기능 필요성 감지
    
    이 클래스는 사용자 쿼리와 패턴 분석을 통해
    EnhancedLogosAIAgent의 Agentic AI 기능이 필요한지 판단합니다.
    """
    
    # Agentic이 필요한 키워드 정의
    REASONING_KEYWORDS = [
        "추론", "reasoning", "think", "생각", "사고",
        "분석", "analyze", "understand", "이해", "파악",
        "판단", "decide", "determine", "결정"
    ]
    
    PLANNING_KEYWORDS = [
        "계획", "plan", "strategy", "전략",
        "단계", "steps", "workflow", "과정",
        "순서", "sequence", "절차", "procedure"
    ]
    
    TOOL_KEYWORDS = [
        "도구", "tool", "use", "사용", "활용",
        "utilize", "integrate", "통합", "연동",
        "api", "서비스", "service", "기능"
    ]
    
    LEARNING_KEYWORDS = [
        "학습", "learn", "improve", "개선", "향상",
        "기억", "remember", "memory", "저장",
        "adapt", "적응", "진화", "발전"
    ]
    
    COLLABORATION_KEYWORDS = [
        "협업", "collaborate", "together", "함께",
        "multi-agent", "멀티", "여러", "multiple"
    ]
    
    # 복잡한 패턴 타입
    COMPLEX_PATTERN_TYPES = [
        'multi_step', 'decision_tree', 'workflow',
        'state_machine', 'pipeline', 'orchestration'
    ]
    
    @classmethod
    def detect_agentic_requirements(
        cls,
        query: str,
        patterns: List[Dict],
        force_agentic: bool = False
    ) -> Dict[str, Any]:
        """
        Agentic AI 기능 필요성 감지
        
        Args:
            query: 사용자 쿼리
            patterns: 감지된 패턴 리스트
            force_agentic: 강제로 Agentic 활성화
        
        Returns:
            {
                "needs_agentic": bool,              # Agentic 필요 여부
                "reasoning_type": str,               # 추론 타입
                "confidence": float,                 # 신뢰도 (0.0-1.0)
                "detected_features": List[str],      # 감지된 기능들
                "recommended_config": Dict[str, Any] # 권장 설정
            }
        """
        if force_agentic:
            logger.info("Agentic features forced enabled")
            return cls._create_agentic_result(
                needs_agentic=True,
                reasoning_type="chain_of_thought",
                confidence=1.0,
                detected_features=["forced"],
                patterns=patterns
            )
        
        query_lower = query.lower()
        detected_features = []
        confidence_score = 0.0
        
        # 1. 키워드 기반 감지
        keyword_results = cls._detect_keywords(query_lower)
        detected_features.extend(keyword_results["features"])
        confidence_score += keyword_results["confidence"]
        
        # 2. 패턴 복잡도 기반 감지
        pattern_results = cls._analyze_patterns(patterns)
        detected_features.extend(pattern_results["features"])
        confidence_score += pattern_results["confidence"]
        
        # 3. 쿼리 복잡도 분석
        query_complexity = cls._analyze_query_complexity(query)
        if query_complexity["is_complex"]:
            detected_features.append("complex_query")
            confidence_score += query_complexity["confidence"]
        
        # 4. 추론 타입 결정
        reasoning_type = cls._determine_reasoning_type(
            query_lower,
            patterns,
            detected_features
        )
        
        # 5. 최종 결정
        # 신뢰도를 0.0-1.0 범위로 정규화
        normalized_confidence = min(confidence_score, 1.0)
        
        # Agentic이 필요한 조건:
        # - 신뢰도가 0.3 이상 또는
        # - 2개 이상의 기능이 감지됨 또는
        # - 복잡한 패턴이 있음
        needs_agentic = (
            normalized_confidence >= 0.3 or
            len(detected_features) >= 2 or
            "complex_pattern" in detected_features
        )
        
        return cls._create_agentic_result(
            needs_agentic=needs_agentic,
            reasoning_type=reasoning_type,
            confidence=normalized_confidence,
            detected_features=detected_features,
            patterns=patterns
        )
    
    @classmethod
    def _detect_keywords(cls, query: str) -> Dict[str, Any]:
        """키워드 기반 기능 감지"""
        features = []
        confidence = 0.0
        
        if any(kw in query for kw in cls.REASONING_KEYWORDS):
            features.append("reasoning")
            confidence += 0.3
        
        if any(kw in query for kw in cls.PLANNING_KEYWORDS):
            features.append("planning")
            confidence += 0.2
        
        if any(kw in query for kw in cls.TOOL_KEYWORDS):
            features.append("tools")
            confidence += 0.2
        
        if any(kw in query for kw in cls.LEARNING_KEYWORDS):
            features.append("learning")
            confidence += 0.15
        
        if any(kw in query for kw in cls.COLLABORATION_KEYWORDS):
            features.append("collaboration")
            confidence += 0.15
        
        return {
            "features": features,
            "confidence": confidence
        }
    
    @classmethod
    def _analyze_patterns(cls, patterns: List[Dict]) -> Dict[str, Any]:
        """패턴 분석을 통한 복잡도 평가"""
        features = []
        confidence = 0.0
        
        # 패턴 개수에 따른 복잡도
        if len(patterns) >= 5:
            features.append("very_complex_pattern")
            confidence += 0.4
        elif len(patterns) >= 3:
            features.append("complex_pattern")
            confidence += 0.2
        elif len(patterns) >= 2:
            confidence += 0.1
        
        # 특정 패턴 타입 확인
        for pattern in patterns:
            pattern_type = pattern.get('type', '').lower()
            if pattern_type in cls.COMPLEX_PATTERN_TYPES:
                if "complex_pattern" not in features:
                    features.append("complex_pattern")
                confidence += 0.1
                break
        
        return {
            "features": features,
            "confidence": confidence
        }
    
    @classmethod
    def _analyze_query_complexity(cls, query: str) -> Dict[str, Any]:
        """쿼리 자체의 복잡도 분석"""
        # 간단한 휴리스틱 기반 분석
        word_count = len(query.split())
        has_multiple_sentences = '.' in query or '?' in query or '!' in query
        has_conditions = any(word in query.lower() for word in ['if', '만약', 'when', '경우'])
        
        is_complex = (
            word_count > 15 or
            has_multiple_sentences or
            has_conditions
        )
        
        confidence = 0.0
        if is_complex:
            if word_count > 20:
                confidence = 0.3
            elif word_count > 15:
                confidence = 0.2
            else:
                confidence = 0.1
        
        return {
            "is_complex": is_complex,
            "confidence": confidence,
            "word_count": word_count
        }
    
    @classmethod
    def _determine_reasoning_type(
        cls,
        query: str,
        patterns: List[Dict],
        detected_features: List[str]
    ) -> str:
        """적절한 추론 타입 결정"""
        
        # 키워드 기반 추론 타입 선택
        if "단계" in query or "step" in query or "순서" in query:
            return "chain_of_thought"
        
        if "행동" in query or "action" in query or "수행" in query:
            return "react"
        
        if "옵션" in query or "alternative" in query or "선택" in query:
            return "tree_of_thoughts"
        
        if "일관성" in query or "consistent" in query:
            return "self_consistency"
        
        if "분해" in query or "decompose" in query or "나누" in query:
            return "least_to_most"
        
        # 패턴 기반 추론 타입 선택
        if len(patterns) >= 4:
            return "tree_of_thoughts"  # 복잡한 경우 여러 경로 탐색
        
        if "planning" in detected_features:
            return "chain_of_thought"  # 계획이 필요한 경우
        
        if "tools" in detected_features:
            return "react"  # 도구 사용이 필요한 경우
        
        # 기본값
        return "chain_of_thought"
    
    @classmethod
    def _create_agentic_result(
        cls,
        needs_agentic: bool,
        reasoning_type: str,
        confidence: float,
        detected_features: List[str],
        patterns: List[Dict]
    ) -> Dict[str, Any]:
        """Agentic 감지 결과 생성"""
        
        # 권장 설정 생성
        recommended_config = cls._generate_recommended_config(
            needs_agentic,
            reasoning_type,
            detected_features,
            patterns
        )
        
        result = {
            "needs_agentic": needs_agentic,
            "reasoning_type": reasoning_type,
            "confidence": confidence,
            "detected_features": list(set(detected_features)),  # 중복 제거
            "recommended_config": recommended_config
        }
        
        logger.info(
            f"Agentic detection result: needs={needs_agentic}, "
            f"confidence={confidence:.2f}, features={detected_features}"
        )
        
        return result
    
    @classmethod
    def _generate_recommended_config(
        cls,
        needs_agentic: bool,
        reasoning_type: str,
        detected_features: List[str],
        patterns: List[Dict]
    ) -> Dict[str, Any]:
        """권장 Agentic 설정 생성"""
        
        if not needs_agentic:
            return {}
        
        config = {
            "enable_agentic": True,
            "agentic_config": {
                "reasoning_type": reasoning_type,
                "tools_enabled": "tools" in detected_features,
                "memory_capacity": 50,
                "learning_rate": 0.1 if "learning" in detected_features else 0.0,
                "max_reasoning_steps": 5
            }
        }
        
        # 복잡도에 따른 설정 조정
        if "very_complex_pattern" in detected_features:
            config["agentic_config"]["max_reasoning_steps"] = 10
            config["agentic_config"]["memory_capacity"] = 100
        elif "complex_pattern" in detected_features:
            config["agentic_config"]["max_reasoning_steps"] = 7
            config["agentic_config"]["memory_capacity"] = 75
        
        # 협업이 필요한 경우
        if "collaboration" in detected_features:
            config["agentic_config"]["enable_collaboration"] = True
        
        return config


# 유틸리티 함수
def should_use_agentic(query: str, patterns: List[Dict] = None) -> bool:
    """
    간단한 Agentic 사용 여부 판단 함수
    
    Args:
        query: 사용자 쿼리
        patterns: 패턴 리스트 (선택적)
    
    Returns:
        bool: Agentic 사용 여부
    """
    patterns = patterns or []
    result = AgenticDetector.detect_agentic_requirements(query, patterns)
    return result["needs_agentic"]


def get_agentic_config(query: str, patterns: List[Dict] = None) -> Dict[str, Any]:
    """
    Agentic 설정 가져오기
    
    Args:
        query: 사용자 쿼리
        patterns: 패턴 리스트 (선택적)
    
    Returns:
        Dict: Agentic 설정
    """
    patterns = patterns or []
    result = AgenticDetector.detect_agentic_requirements(query, patterns)
    return result["recommended_config"]