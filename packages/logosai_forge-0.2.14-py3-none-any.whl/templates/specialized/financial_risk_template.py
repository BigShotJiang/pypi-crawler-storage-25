"""
Financial Risk Analysis Agent Template
=======================================
포트폴리오 관리 및 재무 위험 분석 전문 에이전트
"""

import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from loguru import logger
import pandas as pd
import numpy as np

from logosai import (
    LogosAIAgent,
    AgentConfig,
    AgentType,
    AgentResponse,
    AgentResponseType
)

class {agent_class_name}(LogosAIAgent):
    """
    {agent_description}
    
    재무 위험 분석 및 포트폴리오 관리 전문 에이전트
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        """Initialize the financial risk agent."""
        if config is None:
            config = AgentConfig(
                name="{agent_name}",
                agent_type=AgentType.CUSTOM,
                description="{agent_description}",
                config={{
                    "model": "gemini-2.5-flash-lite",
                    "temperature": 0.3,  # 낮은 temperature로 정확성 향상
                    "max_tokens": 3000,
                    {custom_config}
                }}
            )
        
        super().__init__(config)
        
        # Initialize instance variables
        self.llm_client: Optional[Any] = None
        self.portfolio_data = None
        self.market_data = None
        
        {custom_init}
        
        logger.info(f"{{self.name}} initialized for financial risk analysis")
    
    async def initialize(self) -> bool:
        """Async initialization for resources."""
        try:
            # Initialize LLM client
            from logosai.llm import LLMClient
            self.llm_client = LLMClient(
                model=self.config.config.get("model", "gemini-2.5-flash-lite"),
                temperature=self.config.config.get("temperature", 0.3),
                max_tokens=self.config.config.get("max_tokens", 3000)
            )
            
            # Initialize market data connection
            {custom_async_init}
            
            logger.info(f"{{self.name}} initialization completed")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize {{self.name}}: {{str(e)}}")
            return False
    
    async def _analyze_portfolio(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """포트폴리오 분석 로직"""
        {core_business_logic}
    
    async def _calculate_risk_metrics(self, portfolio: Dict[str, Any]) -> Dict[str, Any]:
        """위험 지표 계산"""
        try:
            # Calculate Value at Risk (VaR)
            portfolio_value = sum(asset.get('value', 0) for asset in portfolio.values())
            
            # Simple VaR calculation (실제로는 더 복잡한 계산 필요)
            var_95 = portfolio_value * 0.05  # 5% VaR
            
            # Calculate Sharpe Ratio (simplified)
            returns = [asset.get('return', 0) for asset in portfolio.values()]
            if returns:
                avg_return = np.mean(returns)
                std_return = np.std(returns)
                sharpe_ratio = avg_return / std_return if std_return > 0 else 0
            else:
                sharpe_ratio = 0
            
            return {{
                "var_95": var_95,
                "sharpe_ratio": sharpe_ratio,
                "portfolio_value": portfolio_value,
                "risk_level": self._assess_risk_level(var_95, portfolio_value)
            }}
            
        except Exception as e:
            logger.error(f"Risk calculation error: {{str(e)}}")
            return {{"error": str(e)}}
    
    def _assess_risk_level(self, var: float, total: float) -> str:
        """위험 수준 평가"""
        risk_ratio = var / total if total > 0 else 0
        if risk_ratio < 0.03:
            return "low"
        elif risk_ratio < 0.07:
            return "moderate"
        elif risk_ratio < 0.15:
            return "high"
        else:
            return "very_high"
    
    async def _generate_rebalancing_recommendation(
        self, 
        portfolio: Dict[str, Any],
        target_allocation: Dict[str, float]
    ) -> Dict[str, Any]:
        """리밸런싱 추천 생성"""
        recommendations = []
        
        # Calculate current allocation
        total_value = sum(asset.get('value', 0) for asset in portfolio.values())
        
        for asset_name, asset_data in portfolio.items():
            current_weight = asset_data.get('value', 0) / total_value if total_value > 0 else 0
            target_weight = target_allocation.get(asset_name, 0)
            
            difference = target_weight - current_weight
            
            if abs(difference) > 0.02:  # 2% threshold
                action = "buy" if difference > 0 else "sell"
                amount = abs(difference * total_value)
                
                recommendations.append({{
                    "asset": asset_name,
                    "action": action,
                    "amount": amount,
                    "current_weight": current_weight,
                    "target_weight": target_weight
                }})
        
        return {{
            "recommendations": recommendations,
            "estimated_trades": len(recommendations),
            "rebalancing_urgency": "high" if len(recommendations) > 3 else "moderate"
        }}
    
    async def process(self, query: str, context: Dict[str, Any] = None) -> AgentResponse:
        """Main processing method for portfolio analysis."""
        try:
            if not query:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={{"error": "Query is required", "message": "쿼리가 필요합니다."}}
                )
            
            logger.info(f"Processing portfolio query: {{query}}")
            
            # Extract portfolio data from context or query
            portfolio_data = context.get('portfolio') if context else {{}}
            
            # Perform risk analysis
            risk_metrics = await self._calculate_risk_metrics(portfolio_data)
            
            # Generate rebalancing recommendations
            target_allocation = context.get('target_allocation', {{}}) if context else {{}}
            rebalancing = await self._generate_rebalancing_recommendation(
                portfolio_data, 
                target_allocation
            )
            
            # Compile results
            result = {{
                "risk_metrics": risk_metrics,
                "rebalancing": rebalancing,
                "timestamp": datetime.now().isoformat(),
                "query": query
            }}
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={{
                    "answer": f"포트폴리오 분석 완료. 위험 수준: {{risk_metrics.get('risk_level', 'unknown')}}",
                    "data": result,
                    "metadata": {{
                        "agent": self.name,
                        "processing_time": datetime.now().isoformat()
                    }}
                }}
            )
            
        except Exception as e:
            logger.error(f"Error processing portfolio request: {{str(e)}}")
            
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{
                    "error": str(e),
                    "message": f"포트폴리오 분석 중 오류가 발생했습니다: {{str(e)}}"
                }}
            )
    
    async def shutdown(self):
        """Clean up resources."""
        try:
            if self.llm_client:
                # Cleanup LLM client if needed
                pass
            
            {custom_cleanup}
            
            logger.info(f"{{self.name}} shutdown completed")
            
        except Exception as e:
            logger.error(f"Error during shutdown: {{str(e)}}")

# Example usage
async def main():
    """Test the financial risk agent."""
    {sample_code}

if __name__ == "__main__":
    asyncio.run(main())