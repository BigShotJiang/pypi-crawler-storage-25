"""
Data Masking Template - Enterprise Security
"""

TEMPLATE_INFO = {
    "id": "enterprise.data_masking",
    "name": "Data Masking",
    "category": "enterprise",
    "version": "1.0.0",
    "llm_customizable": ["masking_strategies", "pii_detection", "compliance_rules"]
}

def get_data_masking():
    """데이터 마스킹 및 익명화 함수 템플릿"""
    return '''
async def _mask_sensitive_data(
    self,
    data: Union[pd.DataFrame, Dict, List],
    masking_rules: Dict[str, str],
    masking_options: Optional[Dict[str, Any]] = None
) -> Tuple[Any, Dict[str, Any]]:
    """
    Mask sensitive data for privacy protection.
    
    Args:
        data: Data to mask
        masking_rules: Rules defining what and how to mask
        masking_options: Additional masking configuration
    
    Returns:
        Tuple[masked data, metadata]
    """
    metadata = {
        "operation": "data_masking",
        "processed_at": datetime.now().isoformat()
    }
    
    try:
        import hashlib
        import random
        import string
        
        # Default options
        default_options = {
            "method": "hash",  # hash, replace, tokenize, scramble
            "preserve_format": True,
            "salt": os.urandom(16).hex(),
            "compliance": "gdpr",  # gdpr, pci-dss, hipaa
            "reversible": False,
            "mask_char": "*"
        }
        
        if masking_options:
            default_options.update(masking_options)
        
        result = {}
        
        # Convert data to DataFrame for uniform processing
        if isinstance(data, dict):
            df = pd.DataFrame([data] if not isinstance(list(data.values())[0], list) else data)
        elif isinstance(data, list):
            df = pd.DataFrame(data)
        else:
            df = data.copy()
        
        # [LLM_CUSTOMIZE: pii_detection]
        # Detect PII automatically
        pii_patterns = {
            "email": r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            "phone": r'\b\d{3}[-.]?\d{3,4}[-.]?\d{4}\b',
            "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
            "credit_card": r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
            "korean_rrn": r'\b\d{6}[-]?\d{7}\b'  # Korean Resident Registration Number
        }
        
        detected_pii = {}
        for column in df.columns:
            if column in masking_rules:
                continue
            
            # Check for PII patterns
            column_str = str(df[column].iloc[0]) if len(df) > 0 else ""
            for pii_type, pattern in pii_patterns.items():
                if re.search(pattern, column_str):
                    detected_pii[column] = pii_type
                    logger.info(f"Auto-detected {pii_type} in column: {column}")
        {pii_detection}
        
        # [LLM_CUSTOMIZE: masking_strategies]
        # Apply masking based on rules and detected PII
        masked_columns = {}
        
        for column, mask_type in {**masking_rules, **detected_pii}.items():
            if column not in df.columns:
                continue
            
            if mask_type == "hash" or default_options["method"] == "hash":
                # One-way hash masking
                salt = default_options["salt"].encode('utf-8')
                df[column] = df[column].apply(
                    lambda x: hashlib.sha256(salt + str(x).encode('utf-8')).hexdigest()[:16]
                    if pd.notna(x) else None
                )
                
            elif mask_type == "replace" or mask_type == "email":
                # Replace with masked characters
                df[column] = df[column].apply(
                    lambda x: re.sub(r'[^@.]', default_options["mask_char"], str(x))
                    if pd.notna(x) else None
                )
                
            elif mask_type == "tokenize":
                # Tokenization with mapping table
                token_map = {}
                
                def tokenize(value):
                    if pd.isna(value):
                        return None
                    if value not in token_map:
                        token_map[value] = f"TOKEN_{len(token_map):06d}"
                    return token_map[value]
                
                df[column] = df[column].apply(tokenize)
                result["token_mapping"] = token_map
                
            elif mask_type == "scramble" or mask_type == "phone":
                # Scramble preserving format
                def scramble(value):
                    if pd.isna(value):
                        return None
                    value_str = str(value)
                    if default_options["preserve_format"]:
                        # Preserve non-alphanumeric characters
                        scrambled = []
                        for char in value_str:
                            if char.isdigit():
                                scrambled.append(str(random.randint(0, 9)))
                            elif char.isalpha():
                                scrambled.append(random.choice(string.ascii_letters))
                            else:
                                scrambled.append(char)
                        return ''.join(scrambled)
                    else:
                        return ''.join(random.sample(value_str, len(value_str)))
                
                df[column] = df[column].apply(scramble)
                
            elif mask_type == "partial":
                # Partial masking (e.g., show last 4 digits)
                df[column] = df[column].apply(
                    lambda x: default_options["mask_char"] * (len(str(x)) - 4) + str(x)[-4:]
                    if pd.notna(x) and len(str(x)) > 4 else None
                )
            
            masked_columns[column] = mask_type
        
        {masking_strategies}
        
        # [LLM_CUSTOMIZE: compliance_rules]
        # Apply compliance-specific rules
        if default_options["compliance"] == "gdpr":
            # GDPR compliance checks
            result["gdpr_compliant"] = True
            result["data_minimization"] = True
            result["right_to_erasure"] = default_options["reversible"]
            
        elif default_options["compliance"] == "pci-dss":
            # PCI-DSS compliance for payment data
            if "credit_card" in detected_pii.values():
                # Ensure strong masking for credit cards
                for col, pii_type in detected_pii.items():
                    if pii_type == "credit_card":
                        df[col] = df[col].apply(
                            lambda x: "*" * 12 + str(x)[-4:] if pd.notna(x) and len(str(x)) >= 16 else None
                        )
            result["pci_compliant"] = True
            
        elif default_options["compliance"] == "hipaa":
            # HIPAA compliance for health data
            result["hipaa_compliant"] = True
            result["phi_protected"] = True
        {compliance_rules}
        
        # Convert back to original format
        if isinstance(data, dict):
            if len(df) == 1:
                result["masked_data"] = df.iloc[0].to_dict()
            else:
                result["masked_data"] = df.to_dict('records')
        elif isinstance(data, list):
            result["masked_data"] = df.to_dict('records')
        else:
            result["masked_data"] = df
        
        # Update metadata
        metadata.update({
            "columns_masked": masked_columns,
            "detected_pii": detected_pii,
            "compliance": default_options["compliance"],
            "reversible": default_options["reversible"],
            "total_fields": len(df.columns),
            "masked_fields": len(masked_columns)
        })
        
        logger.info(f"Data masking completed: {len(masked_columns)} fields masked")
        return result, metadata
        
    except ImportError as e:
        metadata["error"] = f"Required library not installed: {e}"
        logger.error(f"Import error in data masking: {e}")
        
        # Basic fallback masking
        result["masked_data"] = data
        if isinstance(data, pd.DataFrame):
            for col in masking_rules.keys():
                if col in data.columns:
                    data[col] = "***MASKED***"
        
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Data masking failed: {e}")
        raise
'''