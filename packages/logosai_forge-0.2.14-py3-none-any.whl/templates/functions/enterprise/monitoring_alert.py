"""
Monitoring and Alert Template - Enterprise Operations
"""

TEMPLATE_INFO = {
    "id": "enterprise.monitoring_alert",
    "name": "Monitoring and Alert",
    "category": "enterprise",
    "version": "1.0.0",
    "llm_customizable": ["threshold_analysis", "alert_prioritization", "escalation_rules"]
}

def get_monitoring_alert():
    """시스템 모니터링 및 알림 함수 템플릿"""
    return '''
async def _monitor_and_alert(
    self,
    metrics: Dict[str, Any],
    thresholds: Dict[str, Dict[str, Any]],
    alert_channels: List[str],
    monitoring_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Monitor system metrics and generate alerts based on thresholds.
    
    Args:
        metrics: Current system metrics to monitor
        thresholds: Alert thresholds for each metric
        alert_channels: Channels to send alerts (email, sms, slack, webhook)
        monitoring_options: Additional monitoring configuration
    
    Returns:
        Tuple[monitoring results, metadata]
    """
    metadata = {
        "operation": "system_monitoring",
        "monitored_at": datetime.now().isoformat()
    }
    
    try:
        import asyncio
        import statistics
        from collections import deque
        
        # Default options
        default_options = {
            "aggregation_window": 300,  # seconds
            "alert_cooldown": 600,  # seconds between same alerts
            "severity_levels": ["INFO", "WARNING", "ERROR", "CRITICAL"],
            "enable_predictions": True,
            "trend_analysis": True,
            "auto_scaling": False,
            "notification_format": "detailed",  # detailed, summary, minimal
            "dashboard_update": True,
            "store_history": True
        }
        
        if monitoring_options:
            default_options.update(monitoring_options)
        
        result = {
            "metrics_analyzed": 0,
            "alerts_generated": [],
            "trends": {},
            "recommendations": []
        }
        
        # [LLM_CUSTOMIZE: threshold_analysis]
        # Analyze metrics against thresholds
        violations = []
        
        for metric_name, metric_value in metrics.items():
            result["metrics_analyzed"] += 1
            
            # Get threshold configuration
            threshold = thresholds.get(metric_name, {})
            if not threshold:
                continue
            
            # Handle different metric types
            if isinstance(metric_value, (int, float)):
                # Numeric metric
                if "min" in threshold and metric_value < threshold["min"]:
                    violations.append({
                        "metric": metric_name,
                        "value": metric_value,
                        "threshold": threshold["min"],
                        "type": "below_minimum",
                        "severity": threshold.get("severity", "WARNING")
                    })
                
                if "max" in threshold and metric_value > threshold["max"]:
                    violations.append({
                        "metric": metric_name,
                        "value": metric_value,
                        "threshold": threshold["max"],
                        "type": "above_maximum",
                        "severity": threshold.get("severity", "WARNING")
                    })
                
                # Rate of change analysis
                if default_options["trend_analysis"] and hasattr(self, "_metric_history"):
                    history = self._metric_history.get(metric_name, deque(maxlen=10))
                    history.append(metric_value)
                    
                    if len(history) >= 3:
                        # Calculate trend
                        recent_avg = statistics.mean(list(history)[-3:])
                        older_avg = statistics.mean(list(history)[:-3])
                        
                        if older_avg > 0:
                            change_rate = ((recent_avg - older_avg) / older_avg) * 100
                            
                            if abs(change_rate) > threshold.get("rate_threshold", 50):
                                violations.append({
                                    "metric": metric_name,
                                    "change_rate": change_rate,
                                    "type": "rapid_change",
                                    "severity": "WARNING"
                                })
                            
                            result["trends"][metric_name] = {
                                "direction": "increasing" if change_rate > 0 else "decreasing",
                                "rate": change_rate
                            }
            
            elif isinstance(metric_value, dict):
                # Complex metric (e.g., response time percentiles)
                for sub_metric, sub_value in metric_value.items():
                    sub_threshold = threshold.get(sub_metric)
                    if sub_threshold and isinstance(sub_value, (int, float)):
                        if sub_value > sub_threshold:
                            violations.append({
                                "metric": f"{metric_name}.{sub_metric}",
                                "value": sub_value,
                                "threshold": sub_threshold,
                                "type": "threshold_exceeded",
                                "severity": threshold.get("severity", "WARNING")
                            })
        
        # Special metrics for Samsung/Banking
        if "semiconductor_yield" in metrics:
            if metrics["semiconductor_yield"] < 0.95:  # 95% yield threshold
                violations.append({
                    "metric": "semiconductor_yield",
                    "value": metrics["semiconductor_yield"],
                    "threshold": 0.95,
                    "type": "quality_alert",
                    "severity": "CRITICAL"
                })
        
        if "transaction_latency" in metrics:
            if metrics["transaction_latency"] > 100:  # 100ms for banking
                violations.append({
                    "metric": "transaction_latency",
                    "value": metrics["transaction_latency"],
                    "threshold": 100,
                    "type": "performance_alert",
                    "severity": "ERROR"
                })
        {threshold_analysis}
        
        # [LLM_CUSTOMIZE: alert_prioritization]
        # Prioritize and group alerts
        alerts = []
        
        # Group violations by severity
        severity_groups = {}
        for violation in violations:
            severity = violation["severity"]
            if severity not in severity_groups:
                severity_groups[severity] = []
            severity_groups[severity].append(violation)
        
        # Create alerts based on severity
        for severity in ["CRITICAL", "ERROR", "WARNING", "INFO"]:
            if severity not in severity_groups:
                continue
            
            group = severity_groups[severity]
            
            # Check cooldown
            if hasattr(self, "_alert_history"):
                recent_alerts = self._alert_history.get(severity, [])
                last_alert_time = max(recent_alerts) if recent_alerts else 0
                
                if time.time() - last_alert_time < default_options["alert_cooldown"]:
                    logger.info(f"Alert cooldown active for {severity}")
                    continue
            
            alert = {
                "id": hashlib.sha256(
                    f"{datetime.now().isoformat()}{severity}{str(group)}".encode()
                ).hexdigest()[:8],
                "timestamp": datetime.now().isoformat(),
                "severity": severity,
                "violations": group,
                "affected_metrics": list(set(v["metric"] for v in group)),
                "priority": {
                    "CRITICAL": 1,
                    "ERROR": 2,
                    "WARNING": 3,
                    "INFO": 4
                }[severity]
            }
            
            # Add context based on severity
            if severity == "CRITICAL":
                alert["action_required"] = "immediate"
                alert["escalate_to"] = "on_call_engineer"
                alert["auto_remediation"] = self._get_remediation_actions(group)
            
            elif severity == "ERROR":
                alert["action_required"] = "urgent"
                alert["escalate_to"] = "team_lead"
            
            alerts.append(alert)
        {alert_prioritization}
        
        # [LLM_CUSTOMIZE: escalation_rules]
        # Send alerts through configured channels
        for alert in alerts:
            for channel in alert_channels:
                try:
                    if channel == "email":
                        await self._send_email_alert(alert, default_options)
                    
                    elif channel == "slack":
                        await self._send_slack_alert(alert, default_options)
                    
                    elif channel == "webhook":
                        await self._send_webhook_alert(alert, default_options)
                    
                    elif channel == "sms":
                        if alert["severity"] in ["CRITICAL", "ERROR"]:
                            await self._send_sms_alert(alert, default_options)
                    
                    elif channel == "teams":
                        await self._send_teams_alert(alert, default_options)
                    
                    elif channel == "pagerduty":
                        if alert["severity"] == "CRITICAL":
                            await self._send_pagerduty_alert(alert, default_options)
                    
                    logger.info(f"Alert sent to {channel}: {alert['id']}")
                    
                except Exception as e:
                    logger.error(f"Failed to send alert to {channel}: {e}")
        
        # Auto-remediation for critical issues
        if default_options.get("auto_scaling") and any(a["severity"] == "CRITICAL" for a in alerts):
            critical_alerts = [a for a in alerts if a["severity"] == "CRITICAL"]
            
            for alert in critical_alerts:
                for violation in alert["violations"]:
                    if violation["metric"] == "cpu_usage" and violation["value"] > 80:
                        # Auto-scale up
                        result["auto_remediation"] = {
                            "action": "scale_up",
                            "reason": "High CPU usage",
                            "executed": True
                        }
                    
                    elif violation["metric"] == "memory_usage" and violation["value"] > 90:
                        # Clear cache
                        result["auto_remediation"] = {
                            "action": "clear_cache",
                            "reason": "High memory usage",
                            "executed": True
                        }
        {escalation_rules}
        
        # Generate recommendations
        if default_options["enable_predictions"]:
            for metric_name, trend in result["trends"].items():
                if trend["direction"] == "increasing" and trend["rate"] > 20:
                    result["recommendations"].append({
                        "metric": metric_name,
                        "recommendation": f"Consider scaling resources for {metric_name}",
                        "predicted_issue": "Resource exhaustion within 1 hour",
                        "confidence": 0.85
                    })
        
        # Update dashboard if enabled
        if default_options["dashboard_update"]:
            result["dashboard_updated"] = True
            result["dashboard_url"] = "https://monitoring.example.com/dashboard"
        
        # Store history
        if default_options["store_history"]:
            if not hasattr(self, "_metric_history"):
                self._metric_history = {}
            
            for metric_name, metric_value in metrics.items():
                if metric_name not in self._metric_history:
                    self._metric_history[metric_name] = deque(maxlen=100)
                
                if isinstance(metric_value, (int, float)):
                    self._metric_history[metric_name].append(metric_value)
        
        # Update result
        result["alerts_generated"] = alerts
        result["alert_count"] = len(alerts)
        result["highest_severity"] = min(
            (a["severity"] for a in alerts),
            key=lambda x: ["CRITICAL", "ERROR", "WARNING", "INFO"].index(x)
        ) if alerts else "NONE"
        
        # Update metadata
        metadata.update({
            "metrics_count": len(metrics),
            "thresholds_count": len(thresholds),
            "violations_found": len(violations),
            "alerts_sent": len(alerts),
            "channels_used": alert_channels
        })
        
        logger.info(f"Monitoring completed: {len(violations)} violations, {len(alerts)} alerts")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Monitoring failed: {e}")
        raise
    
    async def _send_email_alert(self, alert: Dict, options: Dict):
        """Send email alert"""
        # Implementation placeholder
        logger.info(f"Email alert would be sent: {alert['id']}")
    
    async def _send_slack_alert(self, alert: Dict, options: Dict):
        """Send Slack alert"""
        # Implementation placeholder
        logger.info(f"Slack alert would be sent: {alert['id']}")
    
    async def _send_webhook_alert(self, alert: Dict, options: Dict):
        """Send webhook alert"""
        try:
            import aiohttp
            webhook_url = options.get("webhook_url", "https://webhook.example.com")
            
            async with aiohttp.ClientSession() as session:
                async with session.post(webhook_url, json=alert) as response:
                    return response.status == 200
        except:
            return False
    
    async def _send_sms_alert(self, alert: Dict, options: Dict):
        """Send SMS alert for critical issues"""
        logger.info(f"SMS alert would be sent: {alert['id']}")
    
    async def _send_teams_alert(self, alert: Dict, options: Dict):
        """Send Microsoft Teams alert"""
        logger.info(f"Teams alert would be sent: {alert['id']}")
    
    async def _send_pagerduty_alert(self, alert: Dict, options: Dict):
        """Send PagerDuty alert for critical issues"""
        logger.info(f"PagerDuty incident would be created: {alert['id']}")
    
    def _get_remediation_actions(self, violations: List[Dict]):
        """Get auto-remediation actions for violations"""
        actions = []
        for violation in violations:
            if violation["metric"] == "disk_usage" and violation["value"] > 90:
                actions.append("clean_temp_files")
            elif violation["metric"] == "connection_pool" and violation["value"] > 95:
                actions.append("reset_connection_pool")
        return actions
'''