"""
Audit Logger Template - Enterprise Compliance
"""

TEMPLATE_INFO = {
    "id": "enterprise.audit_logger",
    "name": "Audit Logger",
    "category": "enterprise",
    "version": "1.0.0",
    "llm_customizable": ["event_classification", "compliance_formatting", "alert_rules"]
}

def get_audit_logger():
    """감사 로그 기록 함수 템플릿"""
    return '''
async def _log_audit_event(
    self,
    event_type: str,  # login, access, modification, deletion, error
    event_data: Dict[str, Any],
    user_info: Optional[Dict[str, Any]] = None,
    audit_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Log audit events for compliance and security monitoring.
    
    Args:
        event_type: Type of event being logged
        event_data: Details of the event
        user_info: Information about the user
        audit_options: Additional logging configuration
    
    Returns:
        Tuple[logging results, metadata]
    """
    metadata = {
        "operation": "audit_logging",
        "logged_at": datetime.now().isoformat()
    }
    
    try:
        import json
        import asyncio
        import hashlib
        from pathlib import Path
        
        # Default options
        default_options = {
            "log_level": "INFO",  # DEBUG, INFO, WARNING, ERROR, CRITICAL
            "storage": "file",  # file, database, siem, elasticsearch
            "format": "json",  # json, csv, syslog
            "encryption": False,
            "compression": False,
            "retention_days": 90,
            "compliance_standard": "iso27001",  # iso27001, sox, k-isms
            "alert_threshold": None,
            "log_path": "audit_logs"
        }
        
        if audit_options:
            default_options.update(audit_options)
        
        result = {}
        
        # [LLM_CUSTOMIZE: event_classification]
        # Classify event severity and risk
        event_severity = {
            "login": "INFO",
            "logout": "INFO",
            "access": "INFO",
            "view": "INFO",
            "create": "WARNING",
            "modification": "WARNING",
            "deletion": "CRITICAL",
            "error": "ERROR",
            "security": "CRITICAL",
            "privilege": "CRITICAL",
            "compliance": "WARNING"
        }
        
        severity = event_severity.get(event_type, "INFO")
        
        # Risk scoring
        risk_score = 0
        if event_type in ["deletion", "security", "privilege"]:
            risk_score = 9
        elif event_type in ["modification", "compliance"]:
            risk_score = 6
        elif event_type == "error":
            risk_score = 7
        else:
            risk_score = 3
        
        # Check for suspicious patterns
        if user_info:
            # Multiple failed attempts
            if event_data.get("failed_attempts", 0) > 3:
                risk_score = min(10, risk_score + 3)
                severity = "CRITICAL"
            
            # Unusual access time
            current_hour = datetime.now().hour
            if current_hour < 6 or current_hour > 22:
                risk_score = min(10, risk_score + 1)
            
            # Unusual location
            if user_info.get("location") and user_info.get("usual_location"):
                if user_info["location"] != user_info["usual_location"]:
                    risk_score = min(10, risk_score + 2)
        {event_classification}
        
        # Create audit log entry
        audit_entry = {
            "event_id": hashlib.sha256(
                f"{datetime.now().isoformat()}{event_type}{json.dumps(event_data)}".encode()
            ).hexdigest()[:16],
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "severity": severity,
            "risk_score": risk_score,
            "event_data": event_data,
            "user_info": user_info or {},
            "session_info": {
                "ip_address": user_info.get("ip_address") if user_info else None,
                "user_agent": user_info.get("user_agent") if user_info else None,
                "session_id": user_info.get("session_id") if user_info else None
            },
            "system_info": {
                "hostname": os.uname().nodename if hasattr(os, 'uname') else "unknown",
                "service": "forge_ai",
                "version": "1.0.0"
            }
        }
        
        # [LLM_CUSTOMIZE: compliance_formatting]
        # Format according to compliance standard
        if default_options["compliance_standard"] == "iso27001":
            audit_entry["iso27001"] = {
                "control_objective": "A.12.4.1",  # Event logging
                "evidence_type": "automated_log",
                "retention_period": default_options["retention_days"]
            }
            
        elif default_options["compliance_standard"] == "sox":
            audit_entry["sox"] = {
                "section": "404",  # Management assessment
                "control_type": "preventive",
                "financial_impact": event_type in ["modification", "deletion"]
            }
            
        elif default_options["compliance_standard"] == "k-isms":
            # Korean ISMS-P compliance
            audit_entry["kisms"] = {
                "category": "접근통제",  # Access control
                "requirement": "2.6.3",  # Logging and monitoring
                "evidence_collected": True
            }
        {compliance_formatting}
        
        # Store audit log
        if default_options["storage"] == "file":
            # File-based storage
            log_dir = Path(default_options["log_path"])
            log_dir.mkdir(parents=True, exist_ok=True)
            
            # Organize by date
            log_date = datetime.now().strftime("%Y%m%d")
            log_file = log_dir / f"audit_{log_date}.{default_options['format']}"
            
            # Encrypt if required
            log_content = json.dumps(audit_entry, ensure_ascii=False)
            if default_options["encryption"]:
                # Simple encryption (in production, use proper encryption)
                from cryptography.fernet import Fernet
                key = Fernet.generate_key()
                cipher = Fernet(key)
                log_content = cipher.encrypt(log_content.encode()).decode()
                result["encryption_key"] = key.decode()
            
            # Write to file
            async with aiofiles.open(log_file, 'a', encoding='utf-8') as f:
                if default_options["format"] == "json":
                    await f.write(log_content + "\n")
                elif default_options["format"] == "csv":
                    # Convert to CSV format
                    csv_line = f"{audit_entry['timestamp']},{audit_entry['event_type']},{severity},{risk_score}\n"
                    await f.write(csv_line)
            
            result["log_file"] = str(log_file)
            
        elif default_options["storage"] == "database":
            # Database storage (placeholder)
            result["database_insert"] = True
            result["table"] = "audit_logs"
            
        elif default_options["storage"] == "siem":
            # SIEM integration (placeholder)
            result["siem_forwarded"] = True
            result["siem_endpoint"] = "https://siem.example.com/api/logs"
        
        # [LLM_CUSTOMIZE: alert_rules]
        # Check alert conditions
        alerts = []
        
        if risk_score >= 8:
            alerts.append({
                "level": "HIGH",
                "message": f"High risk event detected: {event_type}",
                "action": "immediate_review"
            })
        
        if severity == "CRITICAL":
            alerts.append({
                "level": "CRITICAL",
                "message": f"Critical event: {event_type}",
                "action": "notify_security_team"
            })
        
        if event_type == "security" and event_data.get("breach_attempted"):
            alerts.append({
                "level": "CRITICAL",
                "message": "Security breach attempt detected",
                "action": "incident_response"
            })
        
        # Failed login threshold
        if event_type == "login" and event_data.get("status") == "failed":
            if event_data.get("consecutive_failures", 0) >= 5:
                alerts.append({
                    "level": "HIGH",
                    "message": "Multiple login failures detected",
                    "action": "account_lockout"
                })
        {alert_rules}
        
        if alerts:
            result["alerts"] = alerts
            # Trigger alert notifications
            for alert in alerts:
                logger.warning(f"AUDIT ALERT: {alert['message']}")
        
        # Update result
        result.update({
            "event_id": audit_entry["event_id"],
            "logged": True,
            "severity": severity,
            "risk_score": risk_score
        })
        
        # Update metadata
        metadata.update({
            "storage_method": default_options["storage"],
            "compliance_standard": default_options["compliance_standard"],
            "alerts_generated": len(alerts),
            "encryption_enabled": default_options["encryption"]
        })
        
        logger.info(f"Audit event logged: {event_type} (Risk: {risk_score}/10)")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Audit logging failed: {e}")
        
        # Fallback to basic logging
        try:
            basic_log = f"{datetime.now().isoformat()} - {event_type} - {json.dumps(event_data)}\n"
            with open("audit_fallback.log", "a") as f:
                f.write(basic_log)
            result["fallback_logged"] = True
        except:
            pass
        
        raise
'''