"""
Backup and Restore Template - Enterprise Disaster Recovery
"""

TEMPLATE_INFO = {
    "id": "enterprise.backup_restore",
    "name": "Backup and Restore",
    "category": "enterprise",
    "version": "1.0.0",
    "llm_customizable": ["backup_strategy", "validation_checks", "recovery_procedures"]
}

def get_backup_restore():
    """백업 및 복구 함수 템플릿"""
    return '''
async def _handle_backup_restore(
    self,
    operation: str,  # backup, restore, verify
    source_path: str,
    backup_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Handle backup and restore operations for disaster recovery.
    
    Args:
        operation: Operation type (backup, restore, verify)
        source_path: Path to backup source or restore target
        backup_options: Additional backup/restore configuration
    
    Returns:
        Tuple[operation results, metadata]
    """
    metadata = {
        "operation": f"disaster_recovery_{operation}",
        "executed_at": datetime.now().isoformat()
    }
    
    try:
        import shutil
        import tarfile
        import hashlib
        import asyncio
        from pathlib import Path
        
        # Default options
        default_options = {
            "destination": "backups",
            "compression": "gzip",  # none, gzip, bz2, xz
            "encryption": True,
            "incremental": False,
            "retention_days": 30,
            "storage_type": "local",  # local, s3, azure, gcs
            "verify_integrity": True,
            "backup_type": "full",  # full, incremental, differential
            "parallel_threads": 4,
            "exclude_patterns": [".git", "__pycache__", "*.pyc", ".env"]
        }
        
        if backup_options:
            default_options.update(backup_options)
        
        result = {}
        source = Path(source_path)
        
        # [LLM_CUSTOMIZE: backup_strategy]
        if operation == "backup":
            # Create backup
            dest_dir = Path(default_options["destination"])
            dest_dir.mkdir(parents=True, exist_ok=True)
            
            # Generate backup name
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{source.name}_backup_{timestamp}"
            
            # Determine backup type
            if default_options["backup_type"] == "incremental":
                # Find last full backup
                last_backup = self._find_last_backup(dest_dir, source.name, "full")
                if not last_backup:
                    logger.info("No full backup found, creating full backup instead")
                    default_options["backup_type"] = "full"
                else:
                    # Compare modification times
                    backup_name = f"{source.name}_incremental_{timestamp}"
            
            elif default_options["backup_type"] == "differential":
                # Find last full backup
                last_backup = self._find_last_backup(dest_dir, source.name, "full")
                if not last_backup:
                    logger.info("No full backup found, creating full backup instead")
                    default_options["backup_type"] = "full"
                else:
                    backup_name = f"{source.name}_differential_{timestamp}"
            
            # Create backup archive
            if default_options["compression"] != "none":
                backup_file = dest_dir / f"{backup_name}.tar.{default_options['compression'][:2]}"
                mode = f"w:{default_options['compression']}"
            else:
                backup_file = dest_dir / f"{backup_name}.tar"
                mode = "w"
            
            # Calculate total size
            total_size = sum(f.stat().st_size for f in source.rglob('*') if f.is_file())
            
            # Create archive with progress tracking
            files_backed_up = 0
            bytes_processed = 0
            
            with tarfile.open(backup_file, mode) as tar:
                for item in source.rglob('*'):
                    # Check exclusions
                    if any(pattern in str(item) for pattern in default_options["exclude_patterns"]):
                        continue
                    
                    if default_options["backup_type"] == "incremental" and last_backup:
                        # Only backup files modified after last backup
                        if item.stat().st_mtime <= last_backup.stat().st_mtime:
                            continue
                    
                    tar.add(item, arcname=item.relative_to(source.parent))
                    files_backed_up += 1
                    
                    if item.is_file():
                        bytes_processed += item.stat().st_size
            
            # Generate checksum
            checksum = None
            if default_options["verify_integrity"]:
                hasher = hashlib.sha256()
                with open(backup_file, 'rb') as f:
                    for chunk in iter(lambda: f.read(65536), b''):
                        hasher.update(chunk)
                checksum = hasher.hexdigest()
                
                # Save checksum
                checksum_file = backup_file.with_suffix(backup_file.suffix + '.sha256')
                checksum_file.write_text(f"{checksum}  {backup_file.name}\n")
            
            # Encryption
            if default_options["encryption"]:
                # Simple encryption (in production, use proper encryption)
                encrypted_file = backup_file.with_suffix(backup_file.suffix + '.enc')
                
                from cryptography.fernet import Fernet
                key = Fernet.generate_key()
                cipher = Fernet(key)
                
                with open(backup_file, 'rb') as f_in:
                    with open(encrypted_file, 'wb') as f_out:
                        # Encrypt in chunks
                        while True:
                            chunk = f_in.read(65536)
                            if not chunk:
                                break
                            f_out.write(cipher.encrypt(chunk))
                
                # Remove unencrypted file
                backup_file.unlink()
                backup_file = encrypted_file
                result["encryption_key"] = key.decode()
            
            # Upload to cloud storage if configured
            if default_options["storage_type"] != "local":
                result["cloud_upload"] = await self._upload_to_cloud(
                    backup_file,
                    default_options["storage_type"],
                    default_options.get("cloud_config", {})
                )
            
            result.update({
                "backup_file": str(backup_file),
                "backup_size": backup_file.stat().st_size,
                "files_backed_up": files_backed_up,
                "backup_type": default_options["backup_type"],
                "checksum": checksum,
                "compressed": default_options["compression"] != "none",
                "encrypted": default_options["encryption"]
            })
            
            logger.info(f"Backup created: {backup_file} ({files_backed_up} files)")
        {backup_strategy}
        
        # [LLM_CUSTOMIZE: recovery_procedures]
        elif operation == "restore":
            # Restore from backup
            backup_file = Path(backup_options.get("backup_file", source_path))
            
            if not backup_file.exists():
                raise FileNotFoundError(f"Backup file not found: {backup_file}")
            
            # Verify integrity if checksum exists
            if default_options["verify_integrity"]:
                checksum_file = backup_file.with_suffix(backup_file.suffix + '.sha256')
                if checksum_file.exists():
                    expected_checksum = checksum_file.read_text().split()[0]
                    
                    hasher = hashlib.sha256()
                    with open(backup_file, 'rb') as f:
                        for chunk in iter(lambda: f.read(65536), b''):
                            hasher.update(chunk)
                    
                    if hasher.hexdigest() != expected_checksum:
                        raise ValueError("Backup integrity check failed!")
                    
                    logger.info("Backup integrity verified")
            
            # Decrypt if encrypted
            if backup_file.suffix == '.enc':
                if not backup_options.get("encryption_key"):
                    raise ValueError("Encryption key required for encrypted backup")
                
                from cryptography.fernet import Fernet
                cipher = Fernet(backup_options["encryption_key"].encode())
                
                decrypted_file = backup_file.with_suffix('')
                with open(backup_file, 'rb') as f_in:
                    with open(decrypted_file, 'wb') as f_out:
                        while True:
                            chunk = f_in.read(65536)
                            if not chunk:
                                break
                            f_out.write(cipher.decrypt(chunk))
                
                backup_file = decrypted_file
            
            # Create restore target
            restore_path = Path(backup_options.get("restore_path", source_path))
            restore_path.mkdir(parents=True, exist_ok=True)
            
            # Extract archive
            mode = 'r'
            if backup_file.suffix == '.gz':
                mode = 'r:gz'
            elif backup_file.suffix == '.bz2':
                mode = 'r:bz2'
            elif backup_file.suffix == '.xz':
                mode = 'r:xz'
            
            files_restored = 0
            with tarfile.open(backup_file, mode) as tar:
                members = tar.getmembers()
                for member in members:
                    tar.extract(member, restore_path)
                    files_restored += 1
            
            result.update({
                "restore_path": str(restore_path),
                "files_restored": files_restored,
                "restore_complete": True
            })
            
            logger.info(f"Restore completed: {files_restored} files to {restore_path}")
        {recovery_procedures}
        
        # [LLM_CUSTOMIZE: validation_checks]
        elif operation == "verify":
            # Verify backup integrity and completeness
            backup_file = Path(source_path)
            
            verification_results = {
                "file_exists": backup_file.exists(),
                "readable": False,
                "integrity": False,
                "contents": []
            }
            
            if backup_file.exists():
                # Check readability
                try:
                    mode = 'r'
                    if backup_file.suffix == '.gz':
                        mode = 'r:gz'
                    elif backup_file.suffix == '.bz2':
                        mode = 'r:bz2'
                    
                    with tarfile.open(backup_file, mode) as tar:
                        verification_results["readable"] = True
                        verification_results["contents"] = [m.name for m in tar.getmembers()[:10]]
                        verification_results["total_files"] = len(tar.getmembers())
                except:
                    verification_results["readable"] = False
                
                # Check integrity
                checksum_file = backup_file.with_suffix(backup_file.suffix + '.sha256')
                if checksum_file.exists():
                    expected_checksum = checksum_file.read_text().split()[0]
                    
                    hasher = hashlib.sha256()
                    with open(backup_file, 'rb') as f:
                        for chunk in iter(lambda: f.read(65536), b''):
                            hasher.update(chunk)
                    
                    verification_results["integrity"] = hasher.hexdigest() == expected_checksum
                    verification_results["checksum"] = hasher.hexdigest()
            
            result["verification"] = verification_results
            result["valid"] = all([
                verification_results["file_exists"],
                verification_results["readable"],
                verification_results.get("integrity", True)
            ])
        {validation_checks}
        
        # Cleanup old backups
        if operation == "backup" and default_options["retention_days"]:
            dest_dir = Path(default_options["destination"])
            cutoff_date = datetime.now() - timedelta(days=default_options["retention_days"])
            
            cleaned = 0
            for old_backup in dest_dir.glob(f"{source.name}_*.tar*"):
                if old_backup.stat().st_mtime < cutoff_date.timestamp():
                    old_backup.unlink()
                    cleaned += 1
            
            if cleaned:
                result["old_backups_cleaned"] = cleaned
                logger.info(f"Cleaned {cleaned} old backups")
        
        # Update metadata
        metadata.update({
            "backup_type": default_options.get("backup_type"),
            "compression": default_options.get("compression"),
            "encryption": default_options.get("encryption"),
            "storage_type": default_options.get("storage_type")
        })
        
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Backup/restore operation failed: {e}")
        raise

    def _find_last_backup(self, backup_dir: Path, source_name: str, backup_type: str):
        """Find the most recent backup of specified type"""
        pattern = f"{source_name}_{backup_type}_*.tar*"
        backups = list(backup_dir.glob(pattern))
        if backups:
            return max(backups, key=lambda p: p.stat().st_mtime)
        return None
    
    async def _upload_to_cloud(self, file_path: Path, storage_type: str, config: Dict):
        """Upload backup to cloud storage"""
        if storage_type == "s3":
            try:
                import boto3
                s3 = boto3.client('s3', **config.get("credentials", {}))
                bucket = config.get("bucket", "backups")
                key = f"backups/{file_path.name}"
                s3.upload_file(str(file_path), bucket, key)
                return {"uploaded": True, "location": f"s3://{bucket}/{key}"}
            except Exception as e:
                logger.error(f"S3 upload failed: {e}")
                return {"uploaded": False, "error": str(e)}
        
        # Add other cloud providers as needed
        return {"uploaded": False, "error": "Storage type not implemented"}
'''