"""vision_react/observe — Screenshot + LLM observation (ReAct: Observe step)."""

TEMPLATE_INFO = {
    "id": "vision_react.observe",
    "name": "Vision Observe",
    "category": "vision_react",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "external_dependencies": ["Vision AI (Gemini)", "screencapture (macOS)"],
    "llm_customizable": [],
}


def get_screenshot_and_ask():
    return '''
async def _screenshot_and_ask(self, app: str, question: str) -> str:
    """Screenshot + LLM question → natural language answer.

    Most basic Vision function: capture screen, ask LLM a question about it.
    Used by all other vision_react functions.
    """
    screenshot = await self._capture_window(app)
    if not screenshot:
        return "Cannot capture screen"
    img_b64 = await self._encode_image(screenshot)
    if not img_b64:
        return "Cannot encode image"

    result = await self._vision_query(img_b64, question)
    return result.get("raw", result.get("answer", str(result)))
'''


def get_screenshot_and_decide():
    return '''
async def _screenshot_and_decide(self, app: str, goal: str, choices: list) -> dict:
    """Screenshot + LLM structured decision from choices.

    Returns: {"choice": "selected", "reason": "why", "confidence": 0.9}
    """
    screenshot = await self._capture_window(app)
    if not screenshot:
        return {"choice": "", "reason": "capture failed", "confidence": 0}
    img_b64 = await self._encode_image(screenshot)

    choices_str = ", ".join(f'"{c}"' for c in choices)
    prompt = (
        f"Look at this screenshot and make a decision.\\n"
        f"Goal: {goal}\\n"
        f"Choices: [{choices_str}]\\n"
        f"Return JSON: {{\\"choice\\": \\"selected\\", \\"reason\\": \\"why\\", \\"confidence\\": 0.9}}"
    )
    result = await self._vision_query(img_b64, prompt)
    if "choice" not in result:
        result["choice"] = choices[0] if choices else ""
        result["confidence"] = 0.3
    return result
'''
