"""vision_react/act — Execute actions based on Vision AI judgment (ReAct: Act step)."""

TEMPLATE_INFO = {
    "id": "vision_react.act",
    "name": "Vision Act",
    "category": "vision_react",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "external_dependencies": ["Peekaboo CLI", "Vision AI"],
    "llm_customizable": [],
}


def get_click_element_by_vision():
    return '''
async def _click_element_by_vision(self, app: str, element_desc: str) -> bool:
    """Find element via Vision AI, then click at its coordinates."""
    import asyncio
    coords = await self._find_element_position(app, element_desc)
    if coords is None:
        return False
    x, y = coords
    return await self._click_at(x, y, app=app)
'''


def get_navigate_to_item():
    return '''
async def _navigate_to_item(self, app: str, target: str, max_scroll: int = 5) -> bool:
    """Navigate to a specific item in a list (scroll + Vision check, repeat).

    Scrolls down and checks after each scroll if target is visible.
    """
    import asyncio
    for i in range(max_scroll):
        # Check if target is visible
        visible = await self._is_element_visible(app, target)
        if visible:
            return True
        # Scroll down
        await self._press_key("down", app)
        await asyncio.sleep(0.5)
    return False
'''


def get_wait_for_screen_change():
    return '''
async def _wait_for_screen_change(self, app: str, timeout: int = 10) -> str:
    """Wait until screen type changes (e.g., after click/enter).

    Captures screen type at start, then polls every 1s until it changes.
    Returns the new screen type.
    """
    import asyncio
    initial_type = await self._identify_screen_type(app)
    elapsed = 0
    while elapsed < timeout:
        await asyncio.sleep(1)
        elapsed += 1
        current_type = await self._identify_screen_type(app)
        if current_type != initial_type:
            return current_type
    return initial_type  # No change within timeout
'''
