"""vision_react/locate — Find UI element positions on screen."""

TEMPLATE_INFO = {
    "id": "vision_react.locate",
    "name": "Vision Locate",
    "category": "vision_react",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "external_dependencies": ["Vision AI (Gemini)"],
    "llm_customizable": [],
}


def get_find_element_position():
    return '''
async def _find_element_position(self, app: str, target_desc: str) -> tuple:
    """Find screen coordinates of a UI element using Vision AI.

    Returns: (x, y) tuple or None if not found.
    Handles Retina display scaling (divide by 2).
    """
    screenshot = await self._capture_window(app)
    if not screenshot:
        return None
    img_b64 = await self._encode_image(screenshot)

    prompt = (
        f"Find \\"{target_desc}\\" in this screenshot.\\n"
        f"Return JSON: {{\\"found\\": true, \\"x\\": pixel_x, \\"y\\": pixel_y, \\"text\\": \\"matched text\\"}}\\n"
        f"If not found: {{\\"found\\": false}}"
    )
    result = await self._vision_query(img_b64, prompt)

    if result.get("found"):
        x = result.get("x", 0)
        y = result.get("y", 0)
        # Retina scaling (image coords → screen coords)
        scale = 2
        return (x // scale, y // scale)
    return None
'''


def get_is_element_visible():
    return '''
async def _is_element_visible(self, app: str, element_desc: str) -> bool:
    """Check if a specific element is visible on screen."""
    answer = await self._screenshot_and_ask(
        app, f"Is \\"{element_desc}\\" visible on this screen? Answer only: yes or no"
    )
    return "yes" in answer.lower()
'''
