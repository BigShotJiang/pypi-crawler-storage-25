"""vision_react/react — ReAct loop + error recovery (core orchestration)."""

TEMPLATE_INFO = {
    "id": "vision_react.react",
    "name": "ReAct Loop",
    "category": "vision_react",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "external_dependencies": ["Vision AI", "Peekaboo CLI", "desktop functions"],
    "llm_customizable": ["max_steps"],
}


def get_react_loop():
    return '''
async def _react_loop(self, app: str, goal: str, max_steps: int = 10) -> dict:
    """Observe → Think → Act loop until goal is achieved.

    Each step:
      1. Observe: screenshot + identify_screen_type
      2. Think: LLM decides next action based on goal + current state + history
      3. Act: execute the decided action

    Returns: {"success": bool, "steps": int, "result": str, "reason": str}
    """
    import asyncio
    from loguru import logger

    history = []

    # Ensure app is active
    await self._activate_app(app)
    await asyncio.sleep(1)

    for step in range(max_steps):
        # ── Observe ──
        screen_type = await self._identify_screen_type(app)

        # ── Think ──
        decision = await self._decide_next_action(app, goal, history)
        action = decision.get("action", "")
        params = decision.get("params", {})
        reason = decision.get("reason", "")

        logger.info(f"  [ReAct {step+1}/{max_steps}] screen={screen_type}, action={action}, params={params}")

        # Check completion
        if action == "goal_achieved":
            return {"success": True, "steps": len(history) + 1,
                    "result": decision.get("result", "Goal achieved")}

        if action == "give_up":
            return {"success": False, "steps": len(history) + 1,
                    "reason": reason or "Agent decided to give up"}

        # ── Act ──
        await self._execute_react_action(app, action, params)

        # Record history
        history.append({
            "step": step + 1,
            "screen": screen_type,
            "action": action,
            "params": params,
            "reason": reason,
        })

        await asyncio.sleep(0.5)

    return {"success": False, "steps": max_steps, "reason": "max steps exceeded"}


async def _execute_react_action(self, app: str, action: str, params: dict):
    """Execute a single ReAct action."""
    import asyncio

    if action == "click_at":
        await self._click_at(params.get("x", 0), params.get("y", 0), app=app)
    elif action == "press_key":
        await self._press_key(params.get("key", "enter"), app)
    elif action == "paste_text":
        await self._paste_text(params.get("text", ""), app)
    elif action == "hotkey":
        await self._hotkey(params.get("keys", ""), app)
    elif action == "scroll_down":
        for _ in range(params.get("count", 3)):
            await self._press_key("down", app)
            await asyncio.sleep(0.2)
    elif action == "scroll_up":
        for _ in range(params.get("count", 3)):
            await self._press_key("up", app)
            await asyncio.sleep(0.2)
    elif action == "activate_app":
        await self._activate_app(params.get("name", app))
    elif action == "click_element":
        await self._click_element_by_vision(app, params.get("description", ""))
    elif action == "wait":
        await asyncio.sleep(params.get("seconds", 2))
    # Unknown action: do nothing (logged by caller)
'''


def get_recover_from_error():
    return '''
async def _recover_from_error(self, app: str, error_type: str = "unknown") -> bool:
    """Recover from error state (Escape spam, close popup, restart app).

    Strategies by error_type:
        popup: press Escape
        wrong_screen: Escape → identify → navigate back
        app_frozen: close + reopen
        unknown: Escape × 3 → check state
    """
    import asyncio

    if error_type == "app_frozen":
        await self._close_app(app)
        await asyncio.sleep(2)
        await self._activate_app(app)
        await asyncio.sleep(2)
        return True

    # Default: press Escape up to 3 times
    for i in range(3):
        await self._press_key("escape", app)
        await asyncio.sleep(0.5)
        screen = await self._identify_screen_type(app)
        if screen in ("friend_list", "chat_list", "inbox"):
            return True  # Back to safe state

    return False
'''
