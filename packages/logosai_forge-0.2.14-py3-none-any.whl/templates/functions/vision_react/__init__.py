# vision_react — ReAct pattern Vision AI functions (Observe→Think→Act loop)
