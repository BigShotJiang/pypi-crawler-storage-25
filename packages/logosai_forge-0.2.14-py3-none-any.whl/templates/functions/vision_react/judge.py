"""vision_react/judge — LLM screen judgment (ReAct: Think step)."""

TEMPLATE_INFO = {
    "id": "vision_react.judge",
    "name": "Vision Judge",
    "category": "vision_react",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "external_dependencies": ["Vision AI (Gemini)"],
    "llm_customizable": ["screen_types", "action_vocabulary"],
}


def get_identify_screen_type():
    return '''
async def _identify_screen_type(self, app: str) -> str:
    """Identify current screen type using Vision AI.

    Returns one of:
        chat_room, profile_card, search_results, friend_list,
        chat_list, login_required, compose_window, inbox,
        no_window, unknown
    """
    screenshot = await self._capture_window(app)
    if not screenshot:
        return "no_window"
    img_b64 = await self._encode_image(screenshot)

    # [LLM_CUSTOMIZE: screen_types]
    screen_types = "chat_room, profile_card, search_results, friend_list, chat_list, login_required, compose_window, inbox, unknown"
    {screen_types}

    prompt = (
        f"Identify the screen type of this {app} screenshot.\\n"
        f"Options: {screen_types}\\n"
        f"Return JSON: {{\\"screen_type\\": \\"..\\", \\"detail\\": \\"brief description\\"}}"
    )
    result = await self._vision_query(img_b64, prompt)
    return result.get("screen_type", "unknown")
'''


def get_is_correct_target():
    return '''
async def _is_correct_target(self, app: str, target_name: str) -> bool:
    """Check if the selected/highlighted item is the desired target."""
    answer = await self._screenshot_and_ask(
        app,
        f"Is \\"{target_name}\\" currently selected or highlighted on this screen? "
        f"Look for blue highlight, cursor position, or focus indicator. Answer: yes or no"
    )
    return "yes" in answer.lower()
'''


def get_decide_next_action():
    return '''
async def _decide_next_action(self, app: str, goal: str, history: list = None) -> dict:
    """LLM decides next action based on current screen + goal + history.

    Returns: {"action": "action_name", "params": {...}, "reason": "why"}

    Available actions:
        click_at(x, y), press_key(key), paste_text(text), hotkey(keys),
        activate_app(name), scroll_down, scroll_up,
        goal_achieved, give_up
    """
    screenshot = await self._capture_window(app)
    if not screenshot:
        return {"action": "give_up", "reason": "cannot capture screen"}
    img_b64 = await self._encode_image(screenshot)

    history_str = ""
    if history:
        history_str = "\\nPrevious steps:\\n" + "\\n".join(
            f"  Step {h['step']}: screen={h.get('screen','?')}, action={h.get('action','?')}"
            for h in history[-5:]  # Last 5 steps
        )

    # [LLM_CUSTOMIZE: action_vocabulary]
    {action_vocabulary}

    prompt = (
        f"You are controlling {app} to achieve a goal.\\n"
        f"Goal: {goal}\\n"
        f"{history_str}\\n"
        f"Look at the current screen and decide the next action.\\n\\n"
        f"Available actions: click_at(x,y), press_key(key), paste_text(text), "
        f"hotkey(keys), scroll_down, scroll_up, goal_achieved, give_up\\n\\n"
        f"Return JSON: {{\\"action\\": \\"action_name\\", \\"params\\": {{}}, \\"reason\\": \\"why\\"}}"
    )
    result = await self._vision_query(img_b64, prompt)
    if "action" not in result:
        result["action"] = "give_up"
        result["reason"] = "LLM did not return valid action"
    return result
'''
