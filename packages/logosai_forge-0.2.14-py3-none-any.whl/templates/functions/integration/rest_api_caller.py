"""
REST API Caller Template
"""

TEMPLATE_INFO = {
    "id": "integration.rest_api_caller",
    "name": "REST API Caller",
    "category": "integration",
    "version": "1.0.0",
    "llm_customizable": ["auth_setup", "request_preparation", "response_processing"]
}

def get_rest_api_caller():
    """REST API 호출 함수 템플릿"""
    return '''
async def _call_rest_api(
    self,
    url: str,
    method: str = "GET",
    headers: Optional[Dict[str, str]] = None,
    params: Optional[Dict[str, Any]] = None,
    data: Optional[Union[Dict, str]] = None,
    auth: Optional[Dict[str, str]] = None,
    timeout: int = 30
) -> Tuple[Any, Dict[str, Any]]:
    """
    Call REST API endpoints.
    
    Args:
        url: API endpoint URL
        method: HTTP method (GET, POST, PUT, DELETE, PATCH)
        headers: Request headers
        params: Query parameters
        data: Request body data (JSON or form data)
        auth: Authentication info (type, token/credentials)
        timeout: Request timeout in seconds
    
    Returns:
        Tuple[response data, metadata]
    """
    metadata = {
        "url": url,
        "method": method,
        "requested_at": datetime.now().isoformat()
    }
    
    try:
        import aiohttp
        
        # Prepare headers
        if headers is None:
            headers = {}
        
        # [LLM_CUSTOMIZE: auth_setup]
        # Setup authentication
        if auth:
            auth_type = auth.get("type", "bearer")
            if auth_type == "bearer":
                headers["Authorization"] = f"Bearer {auth.get('token')}"
            elif auth_type == "basic":
                import base64
                credentials = base64.b64encode(
                    f"{auth.get('username')}:{auth.get('password')}".encode()
                ).decode()
                headers["Authorization"] = f"Basic {credentials}"
            elif auth_type == "api_key":
                key_location = auth.get("location", "header")
                if key_location == "header":
                    headers[auth.get("key_name", "X-API-Key")] = auth.get("key")
                elif key_location == "query":
                    if params is None:
                        params = {}
                    params[auth.get("key_name", "api_key")] = auth.get("key")
            else:
                {auth_setup}
        
        # [LLM_CUSTOMIZE: request_preparation]
        # Prepare request data
        json_data = None
        form_data = None
        
        if data:
            if isinstance(data, dict):
                if headers.get("Content-Type") == "application/x-www-form-urlencoded":
                    form_data = data
                else:
                    json_data = data
                    headers["Content-Type"] = "application/json"
            elif isinstance(data, str):
                # Assume it's already formatted
                pass
            else:
                {request_preparation}
        
        # Make the request
        async with aiohttp.ClientSession() as session:
            async with session.request(
                method=method.upper(),
                url=url,
                headers=headers,
                params=params,
                json=json_data,
                data=form_data if form_data else data if isinstance(data, str) else None,
                timeout=aiohttp.ClientTimeout(total=timeout)
            ) as response:
                
                # Capture response metadata
                metadata.update({
                    "status_code": response.status,
                    "response_headers": dict(response.headers),
                    "response_time_ms": None  # Would need additional timing logic
                })
                
                # [LLM_CUSTOMIZE: response_processing]
                # Process response based on content type
                content_type = response.headers.get("Content-Type", "")
                
                if "application/json" in content_type:
                    result = await response.json()
                    metadata["response_type"] = "json"
                elif "text/" in content_type:
                    result = await response.text()
                    metadata["response_type"] = "text"
                elif "application/xml" in content_type:
                    result = await response.text()
                    metadata["response_type"] = "xml"
                    # Optionally parse XML
                    try:
                        import xml.etree.ElementTree as ET
                        result = ET.fromstring(result)
                    except:
                        pass
                else:
                    # Binary content
                    result = await response.read()
                    metadata["response_type"] = "binary"
                    metadata["content_length"] = len(result)
                    {response_processing}
                
                # Check for errors
                if response.status >= 400:
                    error_msg = f"API request failed with status {response.status}"
                    if isinstance(result, dict) and "error" in result:
                        error_msg += f": {result['error']}"
                    raise Exception(error_msg)
                
                metadata["success"] = True
                logger.info(f"API call successful: {method} {url} -> {response.status}")
                
                return result, metadata
                
    except asyncio.TimeoutError:
        metadata["error"] = f"Request timeout after {timeout} seconds"
        logger.error(f"API request timeout: {url}")
        raise
        
    except Exception as e:
        metadata["error"] = str(e)
        metadata["success"] = False
        logger.error(f"API request failed: {e}")
        raise
'''