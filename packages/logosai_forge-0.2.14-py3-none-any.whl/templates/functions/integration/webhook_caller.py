"""
Webhook Caller Template
"""

TEMPLATE_INFO = {
    "id": "integration.webhook_caller",
    "name": "Webhook Caller",
    "category": "integration",
    "version": "1.0.0",
    "llm_customizable": ["request_preparation", "response_processing", "retry_logic"]
}

def get_webhook_caller():
    """웹훅 호출 함수 템플릿"""
    return '''
async def _call_webhook(
    self,
    url: str,
    payload: Dict[str, Any],
    method: str = "POST",
    headers: Optional[Dict[str, str]] = None,
    auth: Optional[Dict[str, str]] = None,
    timeout: int = 30,
    retry_count: int = 3
) -> Dict[str, Any]:
    """
    Call external webhook with retry logic and error handling.
    
    Args:
        url: Webhook URL
        payload: Data to send
        method: HTTP method (GET, POST, PUT, DELETE)
        headers: Additional headers
        auth: Authentication configuration
        timeout: Request timeout in seconds
        retry_count: Number of retry attempts
    
    Returns:
        Dict with response data and metadata
    """
    result = {
        "success": False,
        "status_code": None,
        "response_data": None,
        "response_headers": {},
        "request_id": None,
        "attempts": 0,
        "latency_ms": None,
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        import aiohttp
        import asyncio
        import json
        import time
        import hashlib
        import base64
        from urllib.parse import urlparse
        
        # Validate URL
        parsed_url = urlparse(url)
        if not parsed_url.scheme or not parsed_url.netloc:
            raise ValueError(f"Invalid URL: {url}")
        
        # [LLM_CUSTOMIZE: request_preparation]
        # Add request preparation logic
        {request_preparation}
        
        # Default headers
        default_headers = {
            "Content-Type": "application/json",
            "User-Agent": "LogosAI-Agent/1.0",
            "X-Request-ID": hashlib.md5(f"{url}{time.time()}".encode()).hexdigest()
        }
        
        if headers:
            default_headers.update(headers)
        
        result["request_id"] = default_headers.get("X-Request-ID")
        
        # Prepare authentication
        auth_header = None
        if auth:
            if auth.get("type") == "bearer":
                auth_header = f"Bearer {auth.get('token')}"
            elif auth.get("type") == "basic":
                credentials = base64.b64encode(
                    f"{auth.get('username')}:{auth.get('password')}".encode()
                ).decode()
                auth_header = f"Basic {credentials}"
            elif auth.get("type") == "api_key":
                if auth.get("location") == "header":
                    default_headers[auth.get("key_name", "X-API-Key")] = auth.get("key")
                elif auth.get("location") == "query":
                    # Add to URL
                    separator = "&" if "?" in url else "?"
                    url = f"{url}{separator}{auth.get('key_name', 'api_key')}={auth.get('key')}"
        
        if auth_header:
            default_headers["Authorization"] = auth_header
        
        # Prepare payload
        if method.upper() in ["GET", "DELETE"]:
            # For GET/DELETE, add payload as query parameters
            if payload:
                import urllib.parse
                query_string = urllib.parse.urlencode(payload)
                separator = "&" if "?" in url else "?"
                url = f"{url}{separator}{query_string}"
                request_data = None
        else:
            request_data = json.dumps(payload) if isinstance(payload, dict) else payload
        
        # [LLM_CUSTOMIZE: retry_logic]
        # Add retry logic customization
        {retry_logic}
        
        # Retry logic with exponential backoff
        for attempt in range(retry_count):
            result["attempts"] = attempt + 1
            
            try:
                start_time = time.time()
                
                async with aiohttp.ClientSession() as session:
                    async with session.request(
                        method=method.upper(),
                        url=url,
                        headers=default_headers,
                        data=request_data,
                        timeout=aiohttp.ClientTimeout(total=timeout)
                    ) as response:
                        result["status_code"] = response.status
                        result["response_headers"] = dict(response.headers)
                        result["latency_ms"] = int((time.time() - start_time) * 1000)
                        
                        # Read response
                        response_text = await response.text()
                        
                        # Try to parse as JSON
                        try:
                            result["response_data"] = json.loads(response_text)
                        except json.JSONDecodeError:
                            result["response_data"] = response_text
                        
                        # Check if successful
                        if 200 <= response.status < 300:
                            result["success"] = True
                            logger.info(f"Webhook called successfully: {url} (attempt {attempt + 1})")
                            break
                        elif response.status == 429:  # Rate limited
                            # Check for Retry-After header
                            retry_after = response.headers.get("Retry-After", str(2 ** attempt))
                            await asyncio.sleep(float(retry_after))
                            logger.warning(f"Rate limited, retrying after {retry_after}s")
                        elif 500 <= response.status < 600:  # Server error, retry
                            if attempt < retry_count - 1:
                                wait_time = 2 ** attempt  # Exponential backoff
                                await asyncio.sleep(wait_time)
                                logger.warning(f"Server error {response.status}, retrying in {wait_time}s")
                            else:
                                logger.error(f"Server error {response.status} after {retry_count} attempts")
                        else:
                            # Client error, don't retry
                            logger.error(f"Client error {response.status}: {response_text}")
                            break
                        
            except asyncio.TimeoutError:
                logger.warning(f"Request timeout (attempt {attempt + 1})")
                if attempt < retry_count - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    result["error"] = "Request timeout after all retries"
                    
            except aiohttp.ClientError as e:
                logger.warning(f"Connection error (attempt {attempt + 1}): {e}")
                if attempt < retry_count - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    result["error"] = str(e)
        
        # [LLM_CUSTOMIZE: response_processing]
        # Add response processing logic
        {response_processing}
        
        # Add insights based on response
        if result["success"]:
            result["insights"] = []
            
            if result["latency_ms"] > 1000:
                result["insights"].append(f"High latency detected: {result['latency_ms']}ms")
            
            if result["attempts"] > 1:
                result["insights"].append(f"Success after {result['attempts']} attempts")
            
            # Check response size
            if result["response_data"]:
                response_size = len(str(result["response_data"]))
                if response_size > 10000:
                    result["insights"].append(f"Large response: {response_size} characters")
        
        return result
        
    except ImportError:
        # Fallback to requests library
        try:
            import requests
            import time
            
            start_time = time.time()
            
            for attempt in range(retry_count):
                result["attempts"] = attempt + 1
                
                try:
                    if method.upper() == "GET":
                        response = requests.get(url, params=payload, headers=headers, timeout=timeout)
                    elif method.upper() == "POST":
                        response = requests.post(url, json=payload, headers=headers, timeout=timeout)
                    elif method.upper() == "PUT":
                        response = requests.put(url, json=payload, headers=headers, timeout=timeout)
                    elif method.upper() == "DELETE":
                        response = requests.delete(url, params=payload, headers=headers, timeout=timeout)
                    else:
                        raise ValueError(f"Unsupported method: {method}")
                    
                    result["status_code"] = response.status_code
                    result["response_headers"] = dict(response.headers)
                    result["latency_ms"] = int((time.time() - start_time) * 1000)
                    
                    try:
                        result["response_data"] = response.json()
                    except:
                        result["response_data"] = response.text
                    
                    if 200 <= response.status_code < 300:
                        result["success"] = True
                        break
                    elif response.status_code == 429 and attempt < retry_count - 1:
                        time.sleep(2 ** attempt)
                    elif 500 <= response.status_code < 600 and attempt < retry_count - 1:
                        time.sleep(2 ** attempt)
                    else:
                        break
                        
                except requests.Timeout:
                    if attempt < retry_count - 1:
                        time.sleep(2 ** attempt)
                    else:
                        result["error"] = "Request timeout"
                        
                except requests.RequestException as e:
                    if attempt < retry_count - 1:
                        time.sleep(2 ** attempt)
                    else:
                        result["error"] = str(e)
            
            logger.info(f"Webhook called using requests library: {result['success']}")
            return result
            
        except ImportError:
            result["error"] = "No HTTP library available (aiohttp or requests)"
            logger.error("Neither aiohttp nor requests library available")
            return result
            
    except ValueError as e:
        logger.warning(f"Webhook validation error: {e}")
        result["error"] = str(e)
        return result
        
    except Exception as e:
        logger.error(f"Webhook call failed: {e}")
        result["error"] = str(e)
        return result
'''