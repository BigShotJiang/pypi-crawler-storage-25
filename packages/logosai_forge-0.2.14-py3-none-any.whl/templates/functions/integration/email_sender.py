"""
Email Sender Template
"""

TEMPLATE_INFO = {
    "id": "integration.email_sender",
    "name": "Email Sender",
    "category": "integration",
    "version": "1.0.0",
    "llm_customizable": ["email_formatting", "validation_rules", "error_handling"]
}

def get_email_sender():
    """이메일 전송 함수 템플릿"""
    return '''
async def _send_email(
    self,
    recipient: Union[str, List[str]],
    subject: str,
    body: str,
    attachments: Optional[List[str]] = None,
    html_body: Optional[str] = None,
    cc: Optional[List[str]] = None,
    bcc: Optional[List[str]] = None,
    config: Optional[Dict] = None
) -> Dict[str, Any]:
    """
    Send email notifications with attachments support.
    
    Args:
        recipient: Email recipient(s)
        subject: Email subject
        body: Plain text body
        attachments: List of file paths to attach
        html_body: HTML version of email body
        cc: Carbon copy recipients
        bcc: Blind carbon copy recipients
        config: SMTP configuration
    
    Returns:
        Dict with sending status and metadata
    """
    result = {
        "sent": False,
        "recipients": [],
        "message_id": None,
        "timestamp": datetime.now().isoformat(),
        "metadata": {}
    }
    
    try:
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        from email.mime.base import MIMEBase
        from email import encoders
        import os
        
        # [LLM_CUSTOMIZE: validation_rules]
        # Add email validation rules
        {validation_rules}
        
        # Normalize recipients
        if isinstance(recipient, str):
            recipients = [recipient]
        else:
            recipients = recipient
        
        # Validate email addresses
        import re
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        valid_recipients = []
        for email in recipients:
            if re.match(email_pattern, email):
                valid_recipients.append(email)
            else:
                logger.warning(f"Invalid email address: {email}")
        
        if not valid_recipients:
            raise ValueError("No valid email addresses provided")
        
        # Default SMTP configuration
        smtp_config = {
            "host": os.getenv("SMTP_HOST", "smtp.gmail.com"),
            "port": int(os.getenv("SMTP_PORT", "587")),
            "use_tls": True,
            "username": os.getenv("SMTP_USERNAME"),
            "password": os.getenv("SMTP_PASSWORD"),
            "from_address": os.getenv("SMTP_FROM", "noreply@example.com")
        }
        
        if config:
            smtp_config.update(config)
        
        # [LLM_CUSTOMIZE: email_formatting]
        # Add email formatting logic
        {email_formatting}
        
        # Create message
        msg = MIMEMultipart('alternative')
        msg['From'] = smtp_config["from_address"]
        msg['To'] = ', '.join(valid_recipients)
        msg['Subject'] = subject
        
        # Add CC and BCC if provided
        if cc:
            valid_cc = [email for email in cc if re.match(email_pattern, email)]
            if valid_cc:
                msg['Cc'] = ', '.join(valid_cc)
                valid_recipients.extend(valid_cc)
        
        if bcc:
            valid_bcc = [email for email in bcc if re.match(email_pattern, email)]
            valid_recipients.extend(valid_bcc)
        
        # Add body
        part1 = MIMEText(body, 'plain')
        msg.attach(part1)
        
        if html_body:
            part2 = MIMEText(html_body, 'html')
            msg.attach(part2)
        
        # Add attachments
        if attachments:
            for file_path in attachments:
                if os.path.isfile(file_path):
                    try:
                        part = MIMEBase('application', 'octet-stream')
                        with open(file_path, 'rb') as file:
                            part.set_payload(file.read())
                        encoders.encode_base64(part)
                        part.add_header(
                            'Content-Disposition',
                            f'attachment; filename= {os.path.basename(file_path)}'
                        )
                        msg.attach(part)
                        logger.info(f"Attached file: {file_path}")
                    except Exception as e:
                        logger.warning(f"Failed to attach file {file_path}: {e}")
                else:
                    logger.warning(f"Attachment file not found: {file_path}")
        
        # Send email
        try:
            # Connect to SMTP server
            if smtp_config["use_tls"]:
                server = smtplib.SMTP(smtp_config["host"], smtp_config["port"])
                server.starttls()
            else:
                server = smtplib.SMTP_SSL(smtp_config["host"], smtp_config["port"])
            
            # Login if credentials provided
            if smtp_config["username"] and smtp_config["password"]:
                server.login(smtp_config["username"], smtp_config["password"])
            
            # Send email
            text = msg.as_string()
            server.sendmail(smtp_config["from_address"], valid_recipients, text)
            server.quit()
            
            result["sent"] = True
            result["recipients"] = valid_recipients
            result["message_id"] = msg.get('Message-ID', 'generated_' + datetime.now().strftime('%Y%m%d%H%M%S'))
            
            logger.info(f"Email sent successfully to {len(valid_recipients)} recipients")
            
        except smtplib.SMTPAuthenticationError:
            logger.error("SMTP authentication failed")
            result["error"] = "Authentication failed - check credentials"
            
            # Fallback: Save email to file
            fallback_path = f"unsent_email_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
            with open(fallback_path, 'w') as f:
                f.write(f"To: {', '.join(valid_recipients)}\\n")
                f.write(f"Subject: {subject}\\n\\n")
                f.write(body)
            result["fallback_file"] = fallback_path
            logger.info(f"Email saved to file: {fallback_path}")
            
        except smtplib.SMTPException as e:
            logger.error(f"SMTP error: {e}")
            result["error"] = str(e)
        
        # [LLM_CUSTOMIZE: error_handling]
        # Add error handling logic
        {error_handling}
        
        # Add metadata
        result["metadata"] = {
            "subject_length": len(subject),
            "body_length": len(body),
            "has_html": html_body is not None,
            "attachment_count": len(attachments) if attachments else 0,
            "smtp_host": smtp_config["host"]
        }
        
        return result
        
    except ValueError as e:
        logger.warning(f"Email validation error: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
        
    except ImportError as e:
        logger.warning(f"Email module import error: {e}")
        
        # Fallback: Create email template file
        fallback_path = f"email_template_{datetime.now().strftime('%Y%m%d%H%M%S')}.html"
        
        email_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>{subject}</title>
        </head>
        <body>
            <h2>{subject}</h2>
            <p><strong>To:</strong> {', '.join(recipients if 'recipients' in locals() else [recipient] if isinstance(recipient, str) else recipient)}</p>
            <p><strong>Date:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <hr>
            <div>{html_body if html_body else f'<pre>{body}</pre>'}</div>
        </body>
        </html>
        """
        
        with open(fallback_path, 'w') as f:
            f.write(email_content)
        
        result["fallback_file"] = fallback_path
        result["error"] = "Email module not available, created template file"
        logger.info(f"Email template saved to: {fallback_path}")
        
        return result
        
    except Exception as e:
        logger.error(f"Email sending failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''