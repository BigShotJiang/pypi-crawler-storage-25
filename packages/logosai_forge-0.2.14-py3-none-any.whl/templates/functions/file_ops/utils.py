"""file_ops/utils — Path safety + file size formatting."""

TEMPLATE_INFO = {
    "id": "file_ops.utils",
    "name": "File Utilities",
    "category": "file_ops",
    "version": "1.0.0",
    "platform": "cross_platform",
    "llm_customizable": ["allowed_roots"],
}


def get_is_safe_path():
    return '''
async def _is_safe_path(self, path: str, allowed_roots: list = None) -> bool:
    """Check if path is within allowed directories."""
    import os
    abs_path = os.path.abspath(os.path.expanduser(path))
    # [LLM_CUSTOMIZE: allowed_roots]
    roots = allowed_roots or [os.path.expanduser("~"), "/tmp"]
    {allowed_roots}
    return any(abs_path.startswith(os.path.abspath(r)) for r in roots)
'''


def get_format_file_size():
    return '''
def _format_file_size(self, size: int) -> str:
    """Format bytes to human-readable size."""
    if size < 1024:
        return f"{size}B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f}KB"
    elif size < 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024):.1f}MB"
    return f"{size / (1024 * 1024 * 1024):.1f}GB"
'''
