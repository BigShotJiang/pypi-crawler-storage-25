"""file_ops/file_analysis — LLM-based file content analysis."""

TEMPLATE_INFO = {
    "id": "file_ops.file_analysis",
    "name": "File Content Analysis",
    "category": "file_ops",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["asyncio"],
    "llm_customizable": ["analysis_prompt"],
}


def get_analyze_file_content():
    return '''
async def _analyze_file_content(self, path: str, content: str) -> dict:
    """Analyze file content with LLM — summarize + key points."""
    import os, asyncio
    filename = os.path.basename(path)

    # [LLM_CUSTOMIZE: analysis_prompt]
    system_prompt = "You are a file analyst. Summarize the file content concisely. Highlight key information, structure, and important data. Respond in the same language as the content."
    {analysis_prompt}

    if not hasattr(self, "_llm") or not self._llm:
        return {"answer": f"File: {path}\\n\\n{content[:3000]}", "content": content}

    try:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"File: {filename}\\n\\nContent:\\n{content[:5000]}\\n\\nProvide a summary and key points."},
        ]
        answer = await asyncio.wait_for(self._llm.invoke_messages(messages), timeout=15)
        answer = answer if isinstance(answer, str) else str(answer)
        return {"answer": f"File: {path}\\n\\n{answer}", "content": content}
    except Exception:
        return {"answer": f"File: {path}\\n\\n{content[:3000]}", "content": content}
'''
