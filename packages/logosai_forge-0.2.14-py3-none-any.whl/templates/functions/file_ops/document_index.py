"""file_ops/document_index — Build + search document index with LLM summarization."""

TEMPLATE_INFO = {
    "id": "file_ops.document_index",
    "name": "Document Index",
    "category": "file_ops",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["os", "json", "asyncio"],
    "llm_customizable": ["scan_directories", "doc_extensions", "summarize_prompt"],
}


def get_build_document_index():
    return '''
async def _build_document_index(self, scan_dirs: list = None, project_root: str = "~") -> dict:
    """Scan document folders and build LLM-summarized index."""
    import os, json, asyncio, re

    project_root = os.path.expanduser(project_root)

    # [LLM_CUSTOMIZE: scan_directories]
    dirs_to_scan = scan_dirs or ["docs", "Documents"]
    {scan_directories}
    doc_extensions = {".md", ".txt", ".rst", ".pdf", ".docx"}
    max_file_size = 500 * 1024  # 500KB

    index = {}
    for scan_dir in dirs_to_scan:
        full_dir = os.path.join(project_root, scan_dir)
        if not os.path.isdir(full_dir):
            continue
        for root, dirs, filenames in os.walk(full_dir):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d != "node_modules"]
            for fname in filenames:
                ext = os.path.splitext(fname)[1].lower()
                if ext not in doc_extensions:
                    continue
                fpath = os.path.join(root, fname)
                try:
                    if os.path.getsize(fpath) > max_file_size:
                        continue
                except OSError:
                    continue
                rel_path = os.path.relpath(fpath, project_root)
                try:
                    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read(5000)
                except Exception:
                    continue

                # LLM summarize if available
                summary = content[:200]
                keywords = []
                if hasattr(self, "_llm") and self._llm:
                    try:
                        resp = await asyncio.wait_for(
                            self._llm.invoke(
                                f"Summarize in 1-2 sentences and extract 5 keywords.\\n\\nFile: {rel_path}\\nContent:\\n{content[:4000]}\\n\\n"
                                "Return JSON: {\\"summary\\": \\"...\\", \\"keywords\\": [\\"kw1\\", \\"kw2\\"]}"
                            ), timeout=15)
                        text = resp.content if hasattr(resp, "content") else str(resp)
                        match = re.search(r"\\{.*\\}", text, re.DOTALL)
                        if match:
                            parsed = json.loads(match.group())
                            summary = parsed.get("summary", summary)
                            keywords = parsed.get("keywords", [])
                    except Exception:
                        pass

                index[rel_path] = {"summary": summary, "keywords": keywords, "size": os.path.getsize(fpath), "extension": ext}

    return {"answer": f"Indexed {len(index)} documents", "index": index, "count": len(index)}
'''


def get_search_document_index():
    return '''
async def _search_document_index(self, query: str, index: dict = None) -> dict:
    """Search document index using LLM relevance matching."""
    import json, asyncio, re

    if not index:
        return {"answer": "No index available", "documents": []}

    index_text = "\\n".join(
        f"- {path}: {info.get('summary', '')} (keywords: {', '.join(info.get('keywords', []))})"
        for path, info in index.items()
    )

    if not hasattr(self, "_llm") or not self._llm:
        return {"answer": "LLM not available for search", "documents": []}

    try:
        resp = await asyncio.wait_for(
            self._llm.invoke(
                f"User question: {query}\\n\\nAvailable documents:\\n{index_text}\\n\\n"
                "Which documents are most relevant? Select up to 3.\\n"
                "Return JSON: {\\"documents\\": [\\"path1\\", \\"path2\\"]}"
            ), timeout=10)
        text = resp.content if hasattr(resp, "content") else str(resp)
        match = re.search(r"\\{.*\\}", text, re.DOTALL)
        if match:
            parsed = json.loads(match.group())
            paths = parsed.get("documents", [])
            results = [{"path": p, **index[p]} for p in paths if p in index]
            answer = f"Found {len(results)} relevant document(s):\\n" + "\\n".join(f"- {r['path']}: {r.get('summary', '')[:80]}" for r in results)
            return {"answer": answer, "documents": results}
    except Exception:
        pass

    return {"answer": "Search failed", "documents": []}
'''
