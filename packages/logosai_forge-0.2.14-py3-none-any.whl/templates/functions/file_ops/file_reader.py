"""file_ops/file_reader — Read PDF, Excel, PPTX, DOCX, text files."""

TEMPLATE_INFO = {
    "id": "file_ops.file_reader",
    "name": "File Reader",
    "category": "file_ops",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["os", "pathlib"],
    "llm_customizable": ["max_pages", "max_rows", "max_slides"],
}


def get_read_text_file():
    return '''
async def _read_text_file(self, path: str, max_chars: int = 50000) -> dict:
    """Read text/code file content."""
    import os
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        return {"answer": f"File not found: {path}", "error": True}
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read(max_chars)
        size = os.path.getsize(path)
        return {"answer": f"File: {path} ({size} bytes)\\n\\n{content[:5000]}", "content": content}
    except Exception as e:
        return {"answer": f"Error reading {path}: {e}", "error": True}
'''


def get_read_pdf():
    return '''
async def _read_pdf(self, path: str, max_pages: int = 20) -> dict:
    """Extract text from PDF file."""
    import os
    path = os.path.expanduser(path)
    try:
        import PyPDF2
        with open(path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            pages = len(reader.pages)
            text = ""
            for i, page in enumerate(reader.pages[:max_pages]):
                text += page.extract_text() or ""
                if len(text) > 30000:
                    break
        return {"answer": f"PDF: {path} ({pages} pages)\\n\\n{text[:5000]}", "content": text, "pages": pages}
    except ImportError:
        return {"answer": "PyPDF2 not installed", "error": True}
    except Exception as e:
        return {"answer": f"Error reading PDF: {e}", "error": True}
'''


def get_read_excel():
    return '''
async def _read_excel(self, path: str, max_sheets: int = 5, max_rows: int = 50) -> dict:
    """Extract data from Excel file."""
    import os
    path = os.path.expanduser(path)
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        text_parts = []
        for sheet_name in wb.sheetnames[:max_sheets]:
            ws = wb[sheet_name]
            text_parts.append(f"\\n📊 Sheet: {sheet_name}")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= max_rows:
                    text_parts.append(f"  ... ({ws.max_row - max_rows} more rows)")
                    break
                cells = [str(c) if c is not None else "" for c in row]
                text_parts.append(" | ".join(cells))
        wb.close()
        text = "\\n".join(text_parts)
        return {"answer": f"Excel: {path}\\n{text[:5000]}", "content": text}
    except ImportError:
        return {"answer": "openpyxl not installed", "error": True}
    except Exception as e:
        return {"answer": f"Error reading Excel: {e}", "error": True}
'''


def get_read_pptx():
    return '''
async def _read_pptx(self, path: str, max_slides: int = 30) -> dict:
    """Extract text from PowerPoint file."""
    import os
    path = os.path.expanduser(path)
    try:
        from pptx import Presentation
        prs = Presentation(path)
        text_parts = []
        for i, slide in enumerate(prs.slides):
            if i >= max_slides:
                text_parts.append(f"\\n... ({len(prs.slides) - max_slides} more slides)")
                break
            slide_text = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        t = para.text.strip()
                        if t:
                            slide_text.append(t)
                if shape.has_table:
                    for row in shape.table.rows:
                        cells = [cell.text.strip() for cell in row.cells]
                        slide_text.append(" | ".join(cells))
            if slide_text:
                text_parts.append(f"\\n📄 Slide {i+1}:")
                text_parts.extend(f"  {t}" for t in slide_text)
        text = "\\n".join(text_parts)
        return {"answer": f"PowerPoint: {path} ({len(prs.slides)} slides)\\n{text[:5000]}", "content": text, "slides": len(prs.slides)}
    except ImportError:
        return {"answer": "python-pptx not installed", "error": True}
    except Exception as e:
        return {"answer": f"Error reading PPTX: {e}", "error": True}
'''


def get_read_docx():
    return '''
async def _read_docx(self, path: str, max_paragraphs: int = 200) -> dict:
    """Extract text from Word document."""
    import os
    path = os.path.expanduser(path)
    try:
        from docx import Document
        doc = Document(path)
        text_parts = []
        for para in doc.paragraphs[:max_paragraphs]:
            t = para.text.strip()
            if t:
                text_parts.append(t)
        for i, table in enumerate(doc.tables[:10]):
            text_parts.append(f"\\n📋 Table {i+1}:")
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                text_parts.append("  " + " | ".join(cells))
        text = "\\n".join(text_parts)
        return {"answer": f"Word: {path}\\n{text[:5000]}", "content": text}
    except ImportError:
        return {"answer": "python-docx not installed", "error": True}
    except Exception as e:
        return {"answer": f"Error reading DOCX: {e}", "error": True}
'''
