"""file_ops/file_search — File name/content search + Spotlight + parallel orchestrator."""

TEMPLATE_INFO = {
    "id": "file_ops.file_search",
    "name": "File Search",
    "category": "file_ops",
    "version": "2.0.0",
    "platform": "cross_platform",
    "required_imports": ["subprocess", "asyncio", "os", "pathlib"],
    "llm_customizable": ["exclude_patterns", "default_directories"],
}

DEFAULT_DIRS = ["~/Development", "~/Documents", "~/Desktop"]
DOC_EXTENSIONS = {".pdf", ".docx", ".pptx", ".xlsx", ".doc", ".xls", ".ppt", ".md", ".txt", ".csv"}


def get_find_files_by_name():
    return '''
async def _find_files_by_name(self, pattern: str, directories: list = None,
                               maxdepth: int = 6, include_dir_contents: bool = True) -> dict:
    """Find files + directories by name pattern.

    1. find로 파일명 매칭
    2. find로 디렉토리명 매칭 → 안의 문서 파일 수집
    3. 결과 합산 + 중복 제거

    Args:
        directories: 검색 경로 (기본: ~/Development, ~/Documents, ~/Desktop)
        include_dir_contents: 디렉토리명 매칭 시 내부 문서도 수집
    """
    import os, subprocess, asyncio
    from pathlib import Path
    from datetime import datetime

    dirs = [os.path.expanduser(d) for d in (directories or ["~/Development", "~/Documents", "~/Desktop"])]
    exclude = [".*", "node_modules", "__pycache__", "Library", ".venv", "venv", ".git"]
    all_files = []

    for directory in dirs:
        if not os.path.isdir(directory):
            continue

        # 1. 파일명 검색
        cmd = ["find", directory, "-maxdepth", str(maxdepth), "-type", "f", "-iname", f"*{pattern}*"]
        for ex in exclude:
            cmd.extend(["-not", "-path", f"*/{ex}/*"])
        try:
            result = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True, timeout=10)
            for f in result.stdout.strip().split("\\n"):
                f = f.strip()
                if f and f not in all_files:
                    all_files.append(f)
        except Exception:
            pass

        # 2. 디렉토리명 검색 → 내부 문서 수집
        if include_dir_contents:
            cmd_dir = ["find", directory, "-maxdepth", str(maxdepth), "-type", "d", "-iname", f"*{pattern}*"]
            for ex in exclude:
                cmd_dir.extend(["-not", "-path", f"*/{ex}/*"])
            try:
                result_dir = await asyncio.to_thread(subprocess.run, cmd_dir, capture_output=True, text=True, timeout=10)
                for d in result_dir.stdout.strip().split("\\n"):
                    d = d.strip()
                    if d and os.path.isdir(d):
                        # 디렉토리 안의 문서 파일 수집
                        for root, _, files in os.walk(d):
                            for fname in files:
                                ext = os.path.splitext(fname)[1].lower()
                                if ext in {".pdf", ".docx", ".pptx", ".xlsx", ".md", ".txt", ".csv", ".py", ".json"}:
                                    fpath = os.path.join(root, fname)
                                    if fpath not in all_files:
                                        all_files.append(fpath)
                            break  # 1 depth만
            except Exception:
                pass

    # 결과 정보
    file_info = []
    for f in all_files[:20]:
        try:
            stat = os.stat(f)
            modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
            file_info.append({"path": f, "size": stat.st_size, "modified": modified})
        except Exception:
            file_info.append({"path": f})

    answer = f"Found {len(all_files)} file(s) matching \\'{pattern}\\':\\n"
    answer += "\\n".join(f"- {fi['path']}" for fi in file_info[:10])
    return {"files": [fi["path"] for fi in file_info], "answer": answer, "file_info": file_info}
'''


def get_find_files_by_content():
    return '''
async def _find_files_by_content(self, pattern: str, directories: list = None, max_results: int = 15) -> dict:
    """파일 내용 검색 — 병렬 4채널 (asyncio.gather).

    동시 실행:
      1. Spotlight (mdfind 메타데이터 쿼리) — PDF/DOCX/PPTX 내용 포함
      2. grep (텍스트/코드 파일)
      3. pdfgrep (PDF 전용, Spotlight 누락 보완)
      4. 디렉토리명 매칭 파일 수집
    """
    import os, subprocess, asyncio, time
    from pathlib import Path

    dirs = [os.path.expanduser(d) for d in (directories or ["~/Development", "~/Documents", "~/Desktop"])]
    _exclude = {"/Library/", "/node_modules/", "/.git/", "/__pycache__/", "/.Trash/", "/.venv/", "/venv/"}
    start_time = time.time()

    def _ok(path):
        return path.strip() and not any(x in path for x in _exclude)

    all_files = []
    matches = []

    async def _spotlight():
        results = []
        for directory in dirs:
            try:
                # 메타데이터 쿼리 (내용 + 이름)
                for query in [
                    f'kMDItemTextContent == "*{pattern}*"cd',
                    f'kMDItemFSName == "*{pattern}*"cd',
                ]:
                    cmd = ["mdfind", "-onlyin", directory, query]
                    spot = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True, timeout=10)
                    for f in spot.stdout.strip().split("\\n"):
                        if _ok(f) and f not in results:
                            results.append(f)
            except Exception:
                pass
        return results[:15]

    async def _grep():
        results = []
        for directory in dirs:
            try:
                cmd = ["grep", "-ril", "-i",
                       "--include=*.txt", "--include=*.md", "--include=*.py",
                       "--include=*.json", "--include=*.csv", "--include=*.yaml",
                       "--include=*.js", "--include=*.ts", "--include=*.html",
                       "-m", "3", pattern, directory]
                grep = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True, timeout=15)
                for f in grep.stdout.strip().split("\\n"):
                    if _ok(f) and f not in results:
                        results.append(f)
            except Exception:
                pass
        return results[:10]

    async def _pdfgrep():
        results = []
        for directory in dirs:
            try:
                find_cmd = ["find", directory, "-maxdepth", "3", "-iname", "*.pdf", "-type", "f",
                            "-not", "-path", "*/Library/*", "-not", "-path", "*/.git/*"]
                find_result = await asyncio.to_thread(subprocess.run, find_cmd, capture_output=True, text=True, timeout=8)
                for pf in [f.strip() for f in find_result.stdout.strip().split("\\n") if f.strip()][:10]:
                    try:
                        pg = subprocess.run(["pdfgrep", "-i", "-c", pattern, pf], capture_output=True, text=True, timeout=3)
                        count = int(pg.stdout.strip()) if pg.stdout.strip().isdigit() else 0
                        if count > 0:
                            results.append(pf)
                    except Exception:
                        pass
            except Exception:
                pass
        return results[:5]

    async def _dir_search():
        results = []
        for directory in dirs:
            try:
                cmd = ["find", directory, "-maxdepth", "4", "-type", "d", "-iname", f"*{pattern}*",
                       "-not", "-path", "*/node_modules/*", "-not", "-path", "*/.git/*"]
                find_dir = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True, timeout=8)
                for d in find_dir.stdout.strip().split("\\n"):
                    d = d.strip()
                    if d and os.path.isdir(d):
                        for fname in os.listdir(d):
                            ext = os.path.splitext(fname)[1].lower()
                            if ext in {".pdf", ".docx", ".pptx", ".xlsx", ".md", ".txt"}:
                                results.append(os.path.join(d, fname))
            except Exception:
                pass
        return results[:10]

    # 병렬 실행
    spot_r, grep_r, pdf_r, dir_r = await asyncio.gather(
        _spotlight(), _grep(), _pdfgrep(), _dir_search(),
        return_exceptions=True,
    )

    channels = []
    for name, results in [("spotlight", spot_r), ("grep", grep_r), ("pdfgrep", pdf_r), ("directory", dir_r)]:
        if isinstance(results, list):
            channels.append(name)
            for f in results:
                if f not in all_files:
                    all_files.append(f)
                    matches.append(f"{f} ({name})")

    elapsed = int((time.time() - start_time) * 1000)
    answer = f"Found \\'{pattern}\\' in {len(all_files)} file(s) ({elapsed}ms, channels: {channels}):\\n"
    answer += "\\n".join(f"- {m}" for m in matches[:max_results])
    if not all_files:
        answer = f"No files containing \\'{pattern}\\' found"

    return {"files": all_files[:max_results], "answer": answer, "search_time_ms": elapsed, "channels_used": channels}
'''


def get_list_directory():
    return '''
async def _list_directory(self, directory: str = "~", max_items: int = 50) -> dict:
    """List directory contents with file sizes."""
    import os

    directory = os.path.expanduser(directory)
    if not os.path.isdir(directory):
        return {"answer": f"Not a directory: {directory}", "items": []}

    try:
        entries = sorted(e for e in os.listdir(directory) if not e.startswith("."))
        items = []
        for entry in entries[:max_items]:
            full_path = os.path.join(directory, entry)
            if os.path.isdir(full_path):
                items.append({"name": entry, "type": "dir", "display": f"📁 {entry}/"})
            else:
                size = os.path.getsize(full_path)
                items.append({"name": entry, "type": "file", "size": size, "display": f"📄 {entry} ({self._format_file_size(size)})"})

        answer = f"Directory: {directory}\\n\\n" + "\\n".join(i["display"] for i in items)
        return {"answer": answer, "items": items}
    except PermissionError:
        return {"answer": f"Permission denied: {directory}", "items": []}
'''


def get_spotlight_search():
    return '''
async def _spotlight_search(self, pattern: str, directory: str = "~",
                             search_type: str = "all") -> list:
    """macOS Spotlight (mdfind) 메타데이터 기반 검색.

    search_type:
        "content": kMDItemTextContent (PDF/DOCX/PPTX 내용)
        "name":    kMDItemFSName (파일명)
        "all":     단순 텍스트 검색 (기본 mdfind)

    장점: 인덱스 기반 ~0.1초, PDF/DOCX 내용까지 검색, 대소문자 무시
    """
    import subprocess, asyncio, os

    directory = os.path.expanduser(directory)
    _exclude = {"/Library/", "/node_modules/", "/.git/", "/.Trash/"}

    queries = []
    if search_type == "content":
        queries = [f'kMDItemTextContent == "*{pattern}*"cd']
    elif search_type == "name":
        queries = [f'kMDItemFSName == "*{pattern}*"cd', f'kMDItemDisplayName == "*{pattern}*"cd']
    else:
        queries = [pattern]  # 기본 mdfind 텍스트 검색

    results = []
    for q in queries:
        try:
            cmd = ["mdfind", "-onlyin", directory, q]
            spot = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True, timeout=10)
            for f in spot.stdout.strip().split("\\n"):
                f = f.strip()
                if f and not any(x in f for x in _exclude) and f not in results:
                    results.append(f)
        except Exception:
            pass

    return results[:20]
'''


def get_parallel_file_search():
    return '''
async def _parallel_file_search(self, pattern: str, directories: list = None,
                                  search_name: bool = True, search_content: bool = True,
                                  search_dirs: bool = True, max_results: int = 20) -> dict:
    """파일명 + 내용 + 디렉토리 병렬 검색 오케스트레이터.

    모든 검색을 asyncio.gather로 동시 실행:
      - Spotlight 이름 검색
      - Spotlight 내용 검색
      - find 파일명 검색
      - find 디렉토리명 검색
      - grep 텍스트 내용 검색

    결과 통합 + 중복 제거
    """
    import asyncio, time

    dirs = directories or ["~/Development", "~/Documents", "~/Desktop"]
    start = time.time()
    tasks = []

    if search_name:
        tasks.append(("spotlight_name", self._spotlight_search(pattern, search_type="name")))
        tasks.append(("find_name", self._find_files_by_name(pattern, directories=dirs, include_dir_contents=False)))

    if search_content:
        tasks.append(("spotlight_content", self._spotlight_search(pattern, search_type="content")))

    if search_dirs:
        tasks.append(("find_dirs", self._find_files_by_name(pattern, directories=dirs, include_dir_contents=True)))

    # 병렬 실행
    names = [t[0] for t in tasks]
    results = await asyncio.gather(*[t[1] for t in tasks], return_exceptions=True)

    all_files = []
    channels_used = []
    for name, result in zip(names, results):
        if isinstance(result, Exception):
            continue
        channels_used.append(name)
        if isinstance(result, list):
            for f in result:
                if f not in all_files:
                    all_files.append(f)
        elif isinstance(result, dict):
            for f in result.get("files", []):
                if f not in all_files:
                    all_files.append(f)

    elapsed = int((time.time() - start) * 1000)
    answer = f"Found {len(all_files)} file(s) for \\'{pattern}\\' ({elapsed}ms):\\n"
    answer += "\\n".join(f"- {f}" for f in all_files[:max_results])

    return {
        "files": all_files[:max_results],
        "total": len(all_files),
        "search_time_ms": elapsed,
        "channels_used": channels_used,
        "answer": answer if all_files else f"No files found for \\'{pattern}\\'"
    }
'''
