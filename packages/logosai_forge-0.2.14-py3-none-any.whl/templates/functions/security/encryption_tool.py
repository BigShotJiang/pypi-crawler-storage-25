"""
Encryption Tool Template
"""

TEMPLATE_INFO = {
    "id": "security.encryption_tool",
    "name": "Encryption Tool",
    "category": "security",
    "version": "1.0.0",
    "llm_customizable": ["encryption_algorithm", "key_management", "data_preparation"]
}

def get_encryption_tool():
    """암호화/복호화 함수 템플릿"""
    return '''
async def _handle_encryption(
    self,
    data: Union[str, bytes, Dict],
    operation: str = "encrypt",  # encrypt, decrypt, generate_key
    key: Optional[Union[str, bytes]] = None,
    encryption_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Handle encryption and decryption operations.
    
    Args:
        data: Data to encrypt/decrypt
        operation: Operation type (encrypt, decrypt, generate_key)
        key: Encryption key
        encryption_options: Encryption configuration
    
    Returns:
        Tuple[encryption results, metadata]
    """
    metadata = {
        "operation": f"data_{operation}",
        "processed_at": datetime.now().isoformat()
    }
    
    try:
        from cryptography.fernet import Fernet
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.backends import default_backend
        import base64
        import os
        
        # Default options
        default_options = {
            "algorithm": "fernet",  # fernet, aes, rsa
            "key_length": 32,
            "encoding": "utf-8",
            "output_format": "base64",  # base64, hex, bytes
            "use_password": False,  # Derive key from password
            "iterations": 100000  # For key derivation
        }
        
        if encryption_options:
            default_options.update(encryption_options)
        
        result = {}
        
        # [LLM_CUSTOMIZE: key_management]
        # Handle key generation or derivation
        if operation == "generate_key":
            if default_options["algorithm"] == "fernet":
                key = Fernet.generate_key()
                result["key"] = key.decode('utf-8')
                result["key_format"] = "base64"
                
            elif default_options["algorithm"] == "aes":
                key = os.urandom(default_options["key_length"])
                result["key"] = base64.b64encode(key).decode('utf-8')
                result["key_format"] = "base64"
                
            elif default_options["algorithm"] == "rsa":
                try:
                    from cryptography.hazmat.primitives.asymmetric import rsa
                    from cryptography.hazmat.primitives import serialization
                    
                    # Generate RSA key pair
                    private_key = rsa.generate_private_key(
                        public_exponent=65537,
                        key_size=2048,
                        backend=default_backend()
                    )
                    
                    # Export private key
                    private_pem = private_key.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.PKCS8,
                        encryption_algorithm=serialization.NoEncryption()
                    )
                    
                    # Export public key
                    public_key = private_key.public_key()
                    public_pem = public_key.public_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PublicFormat.SubjectPublicKeyInfo
                    )
                    
                    result["private_key"] = private_pem.decode('utf-8')
                    result["public_key"] = public_pem.decode('utf-8')
                    result["key_format"] = "pem"
                    
                except ImportError:
                    logger.error("RSA support requires additional cryptography features")
                    raise
            
            result["algorithm"] = default_options["algorithm"]
            result["success"] = True
            metadata["key_generated"] = True
            
            logger.info(f"Key generated for {default_options['algorithm']}")
            return result, metadata
        
        # Derive key from password if requested
        if default_options["use_password"] and key:
            password = key.encode('utf-8') if isinstance(key, str) else key
            salt = os.urandom(16)
            kdf = PBKDF2(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=default_options["iterations"],
                backend=default_backend()
            )
            key = base64.urlsafe_b64encode(kdf.derive(password))
            result["salt"] = base64.b64encode(salt).decode('utf-8')
        {key_management}
        
        # [LLM_CUSTOMIZE: data_preparation]
        # Prepare data for encryption/decryption
        if isinstance(data, dict):
            import json
            data = json.dumps(data).encode('utf-8')
        elif isinstance(data, str):
            data = data.encode(default_options["encoding"])
        elif not isinstance(data, bytes):
            data = str(data).encode(default_options["encoding"])
        {data_preparation}
        
        # [LLM_CUSTOMIZE: encryption_algorithm]
        if operation == "encrypt":
            if not key:
                # Generate a key if not provided
                if default_options["algorithm"] == "fernet":
                    key = Fernet.generate_key()
                    result["generated_key"] = key.decode('utf-8')
                else:
                    key = os.urandom(default_options["key_length"])
                    result["generated_key"] = base64.b64encode(key).decode('utf-8')
            
            if default_options["algorithm"] == "fernet":
                # Ensure key is in correct format
                if isinstance(key, str):
                    key = key.encode('utf-8')
                
                cipher = Fernet(key)
                encrypted = cipher.encrypt(data)
                
                if default_options["output_format"] == "base64":
                    result["encrypted_data"] = encrypted.decode('utf-8')
                elif default_options["output_format"] == "hex":
                    result["encrypted_data"] = encrypted.hex()
                else:
                    result["encrypted_data"] = encrypted
                
            elif default_options["algorithm"] == "aes":
                # AES encryption
                if isinstance(key, str):
                    key = base64.b64decode(key)
                
                # Generate IV
                iv = os.urandom(16)
                cipher = Cipher(
                    algorithms.AES(key),
                    modes.CBC(iv),
                    backend=default_backend()
                )
                encryptor = cipher.encryptor()
                
                # Pad data to multiple of 16 bytes
                from cryptography.hazmat.primitives import padding
                padder = padding.PKCS7(128).padder()
                padded_data = padder.update(data) + padder.finalize()
                
                encrypted = encryptor.update(padded_data) + encryptor.finalize()
                
                # Combine IV and encrypted data
                combined = iv + encrypted
                
                if default_options["output_format"] == "base64":
                    result["encrypted_data"] = base64.b64encode(combined).decode('utf-8')
                elif default_options["output_format"] == "hex":
                    result["encrypted_data"] = combined.hex()
                else:
                    result["encrypted_data"] = combined
                
                result["iv"] = base64.b64encode(iv).decode('utf-8')
            
            result["success"] = True
            result["data_size"] = len(data)
            result["encrypted_size"] = len(result.get("encrypted_data", ""))
            
        elif operation == "decrypt":
            if not key:
                raise ValueError("Key required for decryption")
            
            if default_options["algorithm"] == "fernet":
                if isinstance(key, str):
                    key = key.encode('utf-8')
                
                cipher = Fernet(key)
                
                # Prepare encrypted data
                if isinstance(data, str):
                    encrypted = data.encode('utf-8')
                else:
                    encrypted = data
                
                decrypted = cipher.decrypt(encrypted)
                
                # Try to decode as string
                try:
                    result["decrypted_data"] = decrypted.decode(default_options["encoding"])
                    
                    # Try to parse as JSON
                    try:
                        import json
                        result["decrypted_json"] = json.loads(result["decrypted_data"])
                    except:
                        pass
                except:
                    result["decrypted_data"] = decrypted
                    result["data_format"] = "bytes"
                
            elif default_options["algorithm"] == "aes":
                if isinstance(key, str):
                    key = base64.b64decode(key)
                
                # Decode encrypted data
                if isinstance(data, str):
                    if default_options["output_format"] == "base64":
                        combined = base64.b64decode(data)
                    else:
                        combined = bytes.fromhex(data)
                else:
                    combined = data
                
                # Extract IV and encrypted data
                iv = combined[:16]
                encrypted = combined[16:]
                
                cipher = Cipher(
                    algorithms.AES(key),
                    modes.CBC(iv),
                    backend=default_backend()
                )
                decryptor = cipher.decryptor()
                
                padded_data = decryptor.update(encrypted) + decryptor.finalize()
                
                # Remove padding
                from cryptography.hazmat.primitives import padding
                unpadder = padding.PKCS7(128).unpadder()
                decrypted = unpadder.update(padded_data) + unpadder.finalize()
                
                # Try to decode
                try:
                    result["decrypted_data"] = decrypted.decode(default_options["encoding"])
                except:
                    result["decrypted_data"] = decrypted
                    result["data_format"] = "bytes"
            
            result["success"] = True
        
        {encryption_algorithm}
        
        # Update metadata
        metadata.update({
            "algorithm": default_options["algorithm"],
            "operation_success": result.get("success", False)
        })
        
        logger.info(f"Encryption operation '{operation}' completed")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Encryption operation failed: {e}")
        raise
'''