"""
Password Hasher Template
"""

TEMPLATE_INFO = {
    "id": "security.password_hasher",
    "name": "Password Hasher",
    "category": "security",
    "version": "1.0.0",
    "llm_customizable": ["hashing_algorithm", "salt_generation", "validation_rules"]
}

def get_password_hasher():
    """비밀번호 해싱 함수 템플릿"""
    return '''
async def _handle_password_security(
    self,
    password: str,
    operation: str = "hash",  # hash, verify, generate
    hashed_password: Optional[str] = None,
    security_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Handle password security operations.
    
    Args:
        password: Plain text password or password to verify
        operation: Operation type (hash, verify, generate)
        hashed_password: Hashed password for verification
        security_options: Security configuration
    
    Returns:
        Tuple[security results, metadata]
    """
    metadata = {
        "operation": f"password_{operation}",
        "processed_at": datetime.now().isoformat()
    }
    
    try:
        import hashlib
        import secrets
        import string
        
        # Default options
        default_options = {
            "algorithm": "pbkdf2",  # pbkdf2, bcrypt, argon2
            "iterations": 100000,  # For PBKDF2
            "salt_length": 32,
            "hash_length": 32,
            "password_length": 16,  # For generation
            "include_symbols": True,
            "check_strength": True
        }
        
        if security_options:
            default_options.update(security_options)
        
        result = {}
        
        # [LLM_CUSTOMIZE: validation_rules]
        # Check password strength
        if default_options["check_strength"] and operation in ["hash", "verify"]:
            strength = {
                "length": len(password),
                "has_uppercase": any(c.isupper() for c in password),
                "has_lowercase": any(c.islower() for c in password),
                "has_digits": any(c.isdigit() for c in password),
                "has_symbols": any(c in string.punctuation for c in password)
            }
            
            strength["score"] = sum([
                strength["length"] >= 8,
                strength["has_uppercase"],
                strength["has_lowercase"],
                strength["has_digits"],
                strength["has_symbols"]
            ])
            
            strength["rating"] = (
                "very_strong" if strength["score"] == 5 else
                "strong" if strength["score"] == 4 else
                "medium" if strength["score"] == 3 else
                "weak" if strength["score"] == 2 else
                "very_weak"
            )
            
            result["strength_analysis"] = strength
            
            # Warn if password is weak
            if strength["score"] < 3:
                logger.warning(f"Weak password detected: score {strength['score']}/5")
        {validation_rules}
        
        if operation == "hash":
            # [LLM_CUSTOMIZE: salt_generation]
            # Generate salt
            salt = secrets.token_bytes(default_options["salt_length"])
            {salt_generation}
            
            # [LLM_CUSTOMIZE: hashing_algorithm]
            # Hash password
            if default_options["algorithm"] == "pbkdf2":
                hashed = hashlib.pbkdf2_hmac(
                    'sha256',
                    password.encode('utf-8'),
                    salt,
                    default_options["iterations"],
                    dklen=default_options["hash_length"]
                )
                
                # Combine salt and hash for storage
                combined = salt + hashed
                result["hashed_password"] = combined.hex()
                result["algorithm"] = "pbkdf2_sha256"
                result["iterations"] = default_options["iterations"]
                
            elif default_options["algorithm"] == "bcrypt":
                try:
                    import bcrypt
                    
                    # Generate salt and hash
                    salt = bcrypt.gensalt()
                    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
                    result["hashed_password"] = hashed.decode('utf-8')
                    result["algorithm"] = "bcrypt"
                    
                except ImportError:
                    # Fallback to PBKDF2
                    logger.warning("bcrypt not available, using PBKDF2")
                    default_options["algorithm"] = "pbkdf2"
                    # Recursive call with updated algorithm
                    return await self._handle_password_security(
                        password, operation, hashed_password, default_options
                    )
            
            elif default_options["algorithm"] == "argon2":
                try:
                    from argon2 import PasswordHasher
                    
                    ph = PasswordHasher()
                    result["hashed_password"] = ph.hash(password)
                    result["algorithm"] = "argon2"
                    
                except ImportError:
                    # Fallback to PBKDF2
                    logger.warning("argon2 not available, using PBKDF2")
                    default_options["algorithm"] = "pbkdf2"
                    return await self._handle_password_security(
                        password, operation, hashed_password, default_options
                    )
            {hashing_algorithm}
            
            result["success"] = True
            metadata["hash_length"] = len(result["hashed_password"])
            
        elif operation == "verify":
            if not hashed_password:
                raise ValueError("Hashed password required for verification")
            
            # Verify based on algorithm
            try:
                if "argon2" in hashed_password:
                    # Argon2 format
                    from argon2 import PasswordHasher
                    ph = PasswordHasher()
                    try:
                        ph.verify(hashed_password, password)
                        result["verified"] = True
                    except:
                        result["verified"] = False
                        
                elif hashed_password.startswith("$2"):
                    # Bcrypt format
                    import bcrypt
                    result["verified"] = bcrypt.checkpw(
                        password.encode('utf-8'),
                        hashed_password.encode('utf-8')
                    )
                    
                else:
                    # Assume PBKDF2
                    stored = bytes.fromhex(hashed_password)
                    salt = stored[:default_options["salt_length"]]
                    stored_hash = stored[default_options["salt_length"]:]
                    
                    new_hash = hashlib.pbkdf2_hmac(
                        'sha256',
                        password.encode('utf-8'),
                        salt,
                        default_options["iterations"],
                        dklen=default_options["hash_length"]
                    )
                    
                    result["verified"] = secrets.compare_digest(stored_hash, new_hash)
                
            except Exception as e:
                logger.error(f"Password verification failed: {e}")
                result["verified"] = False
                result["error"] = str(e)
            
            result["success"] = True
            
        elif operation == "generate":
            # Generate secure password
            length = default_options["password_length"]
            
            # Character sets
            lowercase = string.ascii_lowercase
            uppercase = string.ascii_uppercase
            digits = string.digits
            symbols = string.punctuation if default_options["include_symbols"] else ""
            
            # Ensure at least one of each required type
            password_chars = [
                secrets.choice(lowercase),
                secrets.choice(uppercase),
                secrets.choice(digits)
            ]
            
            if default_options["include_symbols"]:
                password_chars.append(secrets.choice(symbols))
            
            # Fill rest with random characters
            all_chars = lowercase + uppercase + digits + symbols
            for _ in range(length - len(password_chars)):
                password_chars.append(secrets.choice(all_chars))
            
            # Shuffle to avoid predictable patterns
            secrets.SystemRandom().shuffle(password_chars)
            generated_password = ''.join(password_chars)
            
            result["generated_password"] = generated_password
            result["length"] = length
            result["entropy_bits"] = length * 6.5  # Approximate
            result["success"] = True
            
            # Also hash it if requested
            if security_options and security_options.get("auto_hash"):
                hash_result, _ = await self._handle_password_security(
                    generated_password, "hash", None, security_options
                )
                result["hashed"] = hash_result.get("hashed_password")
        
        else:
            raise ValueError(f"Unknown operation: {operation}")
        
        # Update metadata
        metadata.update({
            "algorithm_used": default_options.get("algorithm"),
            "operation_success": result.get("success", False)
        })
        
        logger.info(f"Password {operation} completed successfully")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Password security operation failed: {e}")
        raise
'''