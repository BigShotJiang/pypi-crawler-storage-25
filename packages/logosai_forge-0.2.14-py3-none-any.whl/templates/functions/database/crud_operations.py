"""
CRUD Operations Template
"""

TEMPLATE_INFO = {
    "id": "database.crud_operations",
    "name": "CRUD Operations",
    "category": "database",
    "version": "1.0.0",
    "llm_customizable": ["query_building", "validation_logic", "error_handling"]
}

def get_crud_operations():
    """CRUD 작업 함수 템플릿"""
    return '''
async def _perform_crud_operation(
    self,
    operation: str,  # create, read, update, delete
    table_name: str,
    data: Optional[Dict[str, Any]] = None,
    conditions: Optional[Dict[str, Any]] = None,
    crud_options: Optional[Dict[str, Any]] = None
) -> Tuple[Any, Dict[str, Any]]:
    """
    Perform CRUD operations on database.
    
    Args:
        operation: CRUD operation type
        table_name: Target table name
        data: Data for create/update operations
        conditions: Conditions for read/update/delete
        crud_options: Additional options
    
    Returns:
        Tuple[operation results, metadata]
    """
    metadata = {
        "operation": f"crud_{operation}",
        "table": table_name,
        "executed_at": datetime.now().isoformat()
    }
    
    try:
        import sqlite3
        import json
        
        # Default options
        default_options = {
            "db_path": "database.db",
            "db_type": "sqlite",  # sqlite, postgresql, mysql
            "return_format": "dict",  # dict, list, dataframe
            "limit": 100,
            "offset": 0,
            "order_by": None,
            "validate": True
        }
        
        if crud_options:
            default_options.update(crud_options)
        
        result = {}
        
        # Connect to database
        if default_options["db_type"] == "sqlite":
            conn = sqlite3.connect(default_options["db_path"])
            conn.row_factory = sqlite3.Row  # Enable column access by name
            cursor = conn.cursor()
            
        # [LLM_CUSTOMIZE: validation_logic]
        # Validate input data
        if default_options["validate"]:
            if operation in ["create", "update"] and not data:
                raise ValueError(f"Data required for {operation} operation")
            
            if operation in ["update", "delete"] and not conditions:
                logger.warning(f"No conditions for {operation} - affects all records")
            
            # Validate table name (prevent SQL injection)
            if not table_name.replace("_", "").isalnum():
                raise ValueError(f"Invalid table name: {table_name}")
        {validation_logic}
        
        # [LLM_CUSTOMIZE: query_building]
        if operation == "create":
            # Build INSERT query
            columns = list(data.keys())
            placeholders = ["?" for _ in columns]
            values = [data[col] for col in columns]
            
            # Handle JSON/dict columns
            for i, val in enumerate(values):
                if isinstance(val, (dict, list)):
                    values[i] = json.dumps(val)
            
            query = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({', '.join(placeholders)})"
            
            cursor.execute(query, values)
            conn.commit()
            
            result["inserted_id"] = cursor.lastrowid
            result["affected_rows"] = cursor.rowcount
            result["success"] = True
            
            logger.info(f"Created record in {table_name}: ID {result['inserted_id']}")
            
        elif operation == "read":
            # Build SELECT query
            query = f"SELECT * FROM {table_name}"
            params = []
            
            # Add WHERE conditions
            if conditions:
                where_clauses = []
                for key, value in conditions.items():
                    if value is None:
                        where_clauses.append(f"{key} IS NULL")
                    elif isinstance(value, list):
                        placeholders = ", ".join(["?" for _ in value])
                        where_clauses.append(f"{key} IN ({placeholders})")
                        params.extend(value)
                    elif isinstance(value, dict):
                        # Handle operators
                        op = value.get("operator", "=")
                        val = value.get("value")
                        where_clauses.append(f"{key} {op} ?")
                        params.append(val)
                    else:
                        where_clauses.append(f"{key} = ?")
                        params.append(value)
                
                query += f" WHERE {' AND '.join(where_clauses)}"
            
            # Add ORDER BY
            if default_options["order_by"]:
                query += f" ORDER BY {default_options['order_by']}"
            
            # Add LIMIT and OFFSET
            query += f" LIMIT {default_options['limit']} OFFSET {default_options['offset']}"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Format results
            if default_options["return_format"] == "dict":
                result["data"] = [dict(row) for row in rows]
            elif default_options["return_format"] == "dataframe":
                import pandas as pd
                result["data"] = pd.DataFrame([dict(row) for row in rows])
            else:
                result["data"] = rows
            
            result["count"] = len(rows)
            result["success"] = True
            
            logger.info(f"Read {len(rows)} records from {table_name}")
            
        elif operation == "update":
            # Build UPDATE query
            set_clauses = []
            values = []
            
            for key, value in data.items():
                set_clauses.append(f"{key} = ?")
                if isinstance(value, (dict, list)):
                    values.append(json.dumps(value))
                else:
                    values.append(value)
            
            query = f"UPDATE {table_name} SET {', '.join(set_clauses)}"
            
            # Add WHERE conditions
            if conditions:
                where_clauses = []
                for key, value in conditions.items():
                    where_clauses.append(f"{key} = ?")
                    values.append(value)
                
                query += f" WHERE {' AND '.join(where_clauses)}"
            
            cursor.execute(query, values)
            conn.commit()
            
            result["affected_rows"] = cursor.rowcount
            result["success"] = True
            
            logger.info(f"Updated {result['affected_rows']} records in {table_name}")
            
        elif operation == "delete":
            # Build DELETE query
            query = f"DELETE FROM {table_name}"
            params = []
            
            # Add WHERE conditions
            if conditions:
                where_clauses = []
                for key, value in conditions.items():
                    where_clauses.append(f"{key} = ?")
                    params.append(value)
                
                query += f" WHERE {' AND '.join(where_clauses)}"
            
            cursor.execute(query, params)
            conn.commit()
            
            result["affected_rows"] = cursor.rowcount
            result["success"] = True
            
            logger.info(f"Deleted {result['affected_rows']} records from {table_name}")
            
        {query_building}
        
        # Close connection
        cursor.close()
        conn.close()
        
        # [LLM_CUSTOMIZE: error_handling]
        # Update metadata
        metadata.update({
            "rows_affected": result.get("affected_rows", 0),
            "operation_success": result.get("success", False)
        })
        {error_handling}
        
        return result, metadata
        
    except sqlite3.IntegrityError as e:
        metadata["error"] = f"Integrity constraint violation: {e}"
        logger.error(f"Database integrity error: {e}")
        raise
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"CRUD operation failed: {e}")
        raise
'''