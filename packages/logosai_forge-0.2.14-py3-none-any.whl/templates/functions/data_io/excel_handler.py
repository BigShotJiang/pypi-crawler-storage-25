"""
Excel Handler Template
"""

TEMPLATE_INFO = {
    "id": "data_io.excel_handler",
    "name": "Excel Handler",
    "category": "data_io",
    "version": "1.0.0",
    "llm_customizable": ["data_validation", "sheet_processing", "formatting_rules"]
}

def get_excel_handler():
    """Excel 파일 처리 함수 템플릿"""
    return '''
async def _handle_excel_data(
    self,
    file_path: str,
    sheet_name: Optional[Union[str, int, List]] = None,
    options: Optional[Dict[str, Any]] = None
) -> Tuple[Union[pd.DataFrame, Dict[str, pd.DataFrame]], Dict[str, Any]]:
    """
    Read and process Excel files.
    
    Args:
        file_path: Path to Excel file
        sheet_name: Sheet name(s) to read (None = all sheets)
        options: Reading options
    
    Returns:
        Tuple[DataFrame(s), metadata]
    """
    metadata = {
        "source": file_path,
        "loaded_at": datetime.now().isoformat(),
        "source_type": "excel"
    }
    
    try:
        # Check file exists
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Excel file not found: {file_path}")
        
        # Get file info
        file_size = os.path.getsize(file_path)
        metadata["file_size_bytes"] = file_size
        
        # [LLM_CUSTOMIZE: data_validation]
        # Add custom validation rules
        {data_validation}
        
        # Default options
        default_options = {
            "engine": "openpyxl",
            "header": 0,
            "index_col": None
        }
        
        if options:
            default_options.update(options)
        
        # Read Excel file
        if sheet_name is None:
            # Read all sheets
            dfs = pd.read_excel(file_path, sheet_name=None, **default_options)
            metadata["sheets"] = list(dfs.keys())
            metadata["sheet_count"] = len(dfs)
            
            # [LLM_CUSTOMIZE: sheet_processing]
            # Process each sheet
            {sheet_processing}
            
            # Add metadata for each sheet
            for sheet, df in dfs.items():
                metadata[f"sheet_{sheet}"] = {
                    "rows": len(df),
                    "columns": len(df.columns),
                    "columns_list": df.columns.tolist()
                }
            
            result = dfs
            
        else:
            # Read specific sheet(s)
            df = pd.read_excel(file_path, sheet_name=sheet_name, **default_options)
            
            # [LLM_CUSTOMIZE: formatting_rules]
            # Apply formatting rules
            {formatting_rules}
            
            metadata.update({
                "rows": len(df),
                "columns": len(df.columns),
                "columns_list": df.columns.tolist(),
                "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()}
            })
            
            result = df
        
        logger.info(f"Successfully loaded Excel: {file_path}")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Failed to read Excel: {e}")
        raise
'''