"""
Database Connector Template
"""

TEMPLATE_INFO = {
    "id": "data_io.database_connector",
    "name": "Database Connector",
    "category": "data_io",
    "version": "1.0.0",
    "llm_customizable": ["connection_string", "query_logic", "result_processing"]
}

def get_database_connector():
    """데이터베이스 연결 및 쿼리 함수 템플릿"""
    return '''
async def _connect_database(
    self,
    db_type: str,
    connection_params: Dict[str, Any],
    query: Optional[str] = None,
    params: Optional[Union[List, Dict]] = None
) -> Tuple[Any, Dict[str, Any]]:
    """
    Connect to database and execute queries.
    
    Args:
        db_type: Database type (postgresql, mysql, sqlite, mongodb)
        connection_params: Connection parameters (host, port, user, password, database)
        query: SQL query or MongoDB operation
        params: Query parameters for safe execution
    
    Returns:
        Tuple[query results, metadata]
    """
    metadata = {
        "db_type": db_type,
        "executed_at": datetime.now().isoformat()
    }
    
    connection = None
    
    try:
        # [LLM_CUSTOMIZE: connection_string]
        # Build connection string based on db_type
        if db_type == "postgresql":
            import psycopg2
            connection = psycopg2.connect(
                host=connection_params.get("host", "localhost"),
                port=connection_params.get("port", 5432),
                user=connection_params.get("user"),
                password=connection_params.get("password"),
                database=connection_params.get("database")
            )
        elif db_type == "mysql":
            import mysql.connector
            connection = mysql.connector.connect(**connection_params)
        elif db_type == "sqlite":
            import sqlite3
            connection = sqlite3.connect(connection_params.get("database", ":memory:"))
        elif db_type == "mongodb":
            from pymongo import MongoClient
            client = MongoClient(connection_params.get("connection_string"))
            connection = client[connection_params.get("database")]
        else:
            {connection_string}
        
        metadata["connection_established"] = True
        
        # Execute query if provided
        if query:
            # [LLM_CUSTOMIZE: query_logic]
            # Execute query based on database type
            if db_type in ["postgresql", "mysql", "sqlite"]:
                cursor = connection.cursor()
                
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                
                # Determine query type
                query_lower = query.lower().strip()
                if query_lower.startswith("select"):
                    results = cursor.fetchall()
                    columns = [desc[0] for desc in cursor.description]
                    
                    # Convert to DataFrame for easier handling
                    df = pd.DataFrame(results, columns=columns)
                    metadata["rows_returned"] = len(df)
                    metadata["columns"] = columns
                    result = df
                    
                elif any(query_lower.startswith(cmd) for cmd in ["insert", "update", "delete"]):
                    connection.commit()
                    result = {"affected_rows": cursor.rowcount}
                    metadata["affected_rows"] = cursor.rowcount
                    
                else:
                    connection.commit()
                    result = {"success": True}
                    
                cursor.close()
                
            elif db_type == "mongodb":
                collection = connection[query]
                if params:
                    operation = params.get("operation", "find")
                    filter_doc = params.get("filter", {})
                    
                    if operation == "find":
                        results = list(collection.find(filter_doc))
                        result = results
                        metadata["documents_returned"] = len(results)
                    elif operation == "insert":
                        result = collection.insert_many(params.get("documents", []))
                        metadata["inserted_ids"] = str(result.inserted_ids)
                    else:
                        {query_logic}
            else:
                {query_logic}
            
            # [LLM_CUSTOMIZE: result_processing]
            # Process results
            {result_processing}
            
            metadata["query_executed"] = True
            
        else:
            result = {"connection": "established", "ready": True}
        
        logger.info(f"Database operation successful: {db_type}")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Database operation failed: {e}")
        raise
        
    finally:
        # Close connection
        if connection:
            try:
                if db_type in ["postgresql", "mysql", "sqlite"]:
                    connection.close()
                metadata["connection_closed"] = True
            except:
                pass
'''