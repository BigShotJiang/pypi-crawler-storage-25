"""
JSON Parser Template
"""

TEMPLATE_INFO = {
    "id": "data_io.json_parser",
    "name": "JSON Parser",
    "category": "data_io",
    "version": "1.0.0",
    "llm_customizable": ["schema_validation", "data_processing", "transformation"]
}

def get_json_parser():
    """JSON 파싱 함수 템플릿"""
    return '''
async def _parse_json_data(
    self,
    source: Union[str, Dict, bytes],
    schema: Optional[Dict] = None
) -> Tuple[Any, Dict[str, Any]]:
    """
    Parse JSON from various sources.
    
    Args:
        source: File path, dict, or JSON string/bytes
        schema: Optional JSON schema for validation
    
    Returns:
        Tuple[parsed data, metadata]
    
    Raises:
        ValueError: If JSON is invalid
        FileNotFoundError: If file doesn't exist
    """
    metadata = {
        "source_type": "json",
        "parsed_at": datetime.now().isoformat()
    }
    
    try:
        # Determine source type and parse
        if isinstance(source, dict):
            # Already a dictionary
            data = source
            metadata["source"] = "dict"
            
        elif isinstance(source, bytes):
            # Bytes to parse
            try:
                data = json.loads(source.decode('utf-8'))
                metadata["source"] = "bytes"
            except UnicodeDecodeError:
                data = json.loads(source.decode('latin-1'))
                metadata["source"] = "bytes"
                metadata["encoding"] = "latin-1"
                
        elif isinstance(source, str):
            # Could be file path or JSON string
            if os.path.exists(source):
                # File path
                with open(source, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                metadata["source"] = source
                metadata["file_size_bytes"] = os.path.getsize(source)
            else:
                # Try as JSON string
                try:
                    data = json.loads(source)
                    metadata["source"] = "string"
                except json.JSONDecodeError:
                    # Maybe it's a file path that doesn't exist
                    if '/' in source or '\\\\' in source:
                        raise FileNotFoundError(f"File not found: {source}")
                    else:
                        raise ValueError(f"Invalid JSON string: {source[:100]}...")
        else:
            raise ValueError(f"Unsupported source type: {type(source)}")
        
        # [LLM_CUSTOMIZE: schema_validation]
        # Validate against schema if provided
        if schema:
            {schema_validation}
        
        # [LLM_CUSTOMIZE: data_processing]
        # Process or transform the data
        {data_processing}
        
        # Update metadata
        metadata.update({
            "data_type": type(data).__name__,
            "size": len(json.dumps(data)) if data else 0
        })
        
        # Add specific metadata based on data type
        if isinstance(data, list):
            metadata["length"] = len(data)
            if data and isinstance(data[0], dict):
                metadata["keys"] = list(data[0].keys())
        elif isinstance(data, dict):
            metadata["keys"] = list(data.keys())
            metadata["depth"] = _calculate_json_depth(data)
        
        logger.info(f"Successfully parsed JSON ({metadata['data_type']})")
        return data, metadata
        
    except FileNotFoundError as e:
        metadata["error"] = str(e)
        logger.error(f"File not found: {e}")
        raise
        
    except json.JSONDecodeError as e:
        metadata["error"] = f"Invalid JSON: {e}"
        logger.error(f"JSON parsing failed: {e}")
        raise ValueError(f"Invalid JSON: {e}")
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"JSON parsing failed: {e}")
        raise

def _calculate_json_depth(obj, current_depth=0):
    """Calculate maximum depth of JSON structure"""
    if not isinstance(obj, (dict, list)):
        return current_depth
    
    if isinstance(obj, dict):
        return max([_calculate_json_depth(v, current_depth + 1) for v in obj.values()] or [current_depth])
    else:
        return max([_calculate_json_depth(item, current_depth + 1) for item in obj] or [current_depth])
'''

def get_write_json_template():
    """JSON 쓰기 함수 템플릿"""
    return '''
async def _write_json_data(
    self,
    data: Any,
    file_path: str,
    options: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Write data to JSON file.
    
    Args:
        data: Data to write
        file_path: Output file path
        options: Writing options (indent, ensure_ascii, etc.)
    
    Returns:
        Dict with write metadata
    """
    metadata = {
        "target": file_path,
        "written_at": datetime.now().isoformat(),
        "operation": "write_json"
    }
    
    try:
        # Default options
        default_options = {
            "indent": 2,
            "ensure_ascii": False,
            "sort_keys": False
        }
        
        if options:
            default_options.update(options)
        
        # Create directory if needed
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # [LLM_CUSTOMIZE: transformation]
        # Transform data before writing if needed
        {transformation}
        
        # Write JSON
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, **default_options)
        
        # Update metadata
        metadata.update({
            "file_size_bytes": os.path.getsize(file_path),
            "data_type": type(data).__name__,
            "success": True
        })
        
        logger.info(f"Successfully wrote JSON: {file_path}")
        return metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        metadata["success"] = False
        logger.error(f"Failed to write JSON: {e}")
        raise
'''