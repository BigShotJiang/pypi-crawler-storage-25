"""
CSV Reader Template
"""

TEMPLATE_INFO = {
    "id": "data_io.csv_reader",
    "name": "CSV Reader",
    "category": "data_io",
    "version": "1.0.0",
    "llm_customizable": ["validation_logic", "preprocessing", "postprocessing"]
}

def get_csv_reader():
    """CSV 읽기 함수 템플릿"""
    return '''
async def _read_csv_data(
    self,
    file_path: str,
    options: Optional[Dict[str, Any]] = None
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Read CSV file and return DataFrame with metadata.
    
    Args:
        file_path: Path to CSV file
        options: Reading options (encoding, delimiter, columns, dtype, etc.)
    
    Returns:
        Tuple[DataFrame, metadata dict]
    
    Raises:
        FileNotFoundError: If file doesn't exist
        pd.errors.EmptyDataError: If file is empty
        ValueError: If validation fails
    """
    metadata = {
        "source": file_path,
        "loaded_at": datetime.now().isoformat(),
        "source_type": "csv"
    }
    
    try:
        # Validate file exists
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Check file size
        file_size = os.path.getsize(file_path)
        metadata["file_size_bytes"] = file_size
        
        if file_size == 0:
            raise pd.errors.EmptyDataError("File is empty")
        
        # [LLM_CUSTOMIZE: validation_logic]
        # Add specific validation requirements
        {validation_logic}
        
        # Default options
        default_options = {
            "encoding": "utf-8",
            "delimiter": ",",
            "header": 0,
            "na_values": ["", "N/A", "null", "None", "NULL", "NA"]
        }
        
        if options:
            default_options.update(options)
        
        # [LLM_CUSTOMIZE: preprocessing]
        # Add any preprocessing steps
        {preprocessing}
        
        # Read CSV with error handling
        try:
            df = pd.read_csv(file_path, **default_options)
        except UnicodeDecodeError:
            # Try different encodings
            for encoding in ["latin-1", "iso-8859-1", "cp1252"]:
                try:
                    default_options["encoding"] = encoding
                    df = pd.read_csv(file_path, **default_options)
                    metadata["encoding_used"] = encoding
                    break
                except UnicodeDecodeError:
                    continue
            else:
                raise ValueError("Unable to decode file with any standard encoding")
        
        # [LLM_CUSTOMIZE: postprocessing]
        # Add any data processing after loading
        {postprocessing}
        
        # Update metadata
        metadata.update({
            "row_count": len(df),
            "column_count": len(df.columns),
            "columns": df.columns.tolist(),
            "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
            "memory_usage_mb": df.memory_usage(deep=True).sum() / 1024 / 1024,
            "null_counts": df.isnull().sum().to_dict(),
            "duplicates": df.duplicated().sum()
        })
        
        logger.info(f"Successfully loaded CSV: {file_path} ({len(df)} rows, {len(df.columns)} columns)")
        return df, metadata
        
    except FileNotFoundError as e:
        metadata["error"] = str(e)
        logger.error(f"File not found: {file_path}")
        raise
        
    except pd.errors.EmptyDataError as e:
        metadata["error"] = "File is empty"
        logger.error(f"Empty CSV file: {file_path}")
        raise
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Failed to read CSV: {e}")
        raise
'''

def get_write_csv_template():
    """CSV 쓰기 함수 템플릿"""
    return '''
async def _write_csv_data(
    self,
    df: pd.DataFrame,
    file_path: str,
    options: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Write DataFrame to CSV file.
    
    Args:
        df: DataFrame to write
        file_path: Output file path
        options: Writing options
    
    Returns:
        Dict with write metadata
    """
    metadata = {
        "target": file_path,
        "written_at": datetime.now().isoformat(),
        "operation": "write_csv"
    }
    
    try:
        # Default options
        default_options = {
            "index": False,
            "encoding": "utf-8"
        }
        
        if options:
            default_options.update(options)
        
        # Create directory if needed
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Write CSV
        df.to_csv(file_path, **default_options)
        
        # Update metadata
        metadata.update({
            "rows_written": len(df),
            "columns_written": len(df.columns),
            "file_size_bytes": os.path.getsize(file_path),
            "success": True
        })
        
        logger.info(f"Successfully wrote CSV: {file_path} ({len(df)} rows)")
        return metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        metadata["success"] = False
        logger.error(f"Failed to write CSV: {e}")
        raise
'''