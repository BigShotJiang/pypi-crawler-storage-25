"""
PDF Extractor Template
"""

TEMPLATE_INFO = {
    "id": "data_io.pdf_extractor",
    "name": "PDF Extractor",
    "category": "data_io",
    "version": "1.0.0",
    "llm_customizable": ["extraction_strategy", "text_processing", "table_handling"]
}

def get_pdf_extractor():
    """PDF 텍스트 추출 함수 템플릿"""
    return '''
async def _extract_pdf_content(
    self,
    file_path: str,
    extract_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Extract text and metadata from PDF files.
    
    Args:
        file_path: Path to PDF file
        extract_options: Options for extraction (pages, tables, images)
    
    Returns:
        Tuple[extracted content, metadata]
    """
    metadata = {
        "source": file_path,
        "extracted_at": datetime.now().isoformat(),
        "source_type": "pdf"
    }
    
    try:
        import PyPDF2
        import pdfplumber
        
        # Check file exists
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PDF file not found: {file_path}")
        
        # Get file info
        file_size = os.path.getsize(file_path)
        metadata["file_size_bytes"] = file_size
        
        # Default options
        default_options = {
            "extract_text": True,
            "extract_tables": True,
            "extract_images": False,
            "pages": None  # None = all pages
        }
        
        if extract_options:
            default_options.update(extract_options)
        
        result = {
            "text": "",
            "tables": [],
            "metadata": {},
            "pages": []
        }
        
        # [LLM_CUSTOMIZE: extraction_strategy]
        # Choose extraction strategy based on PDF type
        {extraction_strategy}
        
        # Extract with pdfplumber (better for tables)
        with pdfplumber.open(file_path) as pdf:
            metadata["total_pages"] = len(pdf.pages)
            metadata["pdf_metadata"] = pdf.metadata
            
            # Determine pages to extract
            if default_options["pages"]:
                if isinstance(default_options["pages"], int):
                    pages_to_extract = [default_options["pages"]]
                elif isinstance(default_options["pages"], list):
                    pages_to_extract = default_options["pages"]
                else:
                    pages_to_extract = range(len(pdf.pages))
            else:
                pages_to_extract = range(len(pdf.pages))
            
            for page_num in pages_to_extract:
                if page_num >= len(pdf.pages):
                    continue
                    
                page = pdf.pages[page_num]
                page_data = {
                    "page_number": page_num + 1,
                    "text": "",
                    "tables": []
                }
                
                # Extract text
                if default_options["extract_text"]:
                    page_text = page.extract_text()
                    if page_text:
                        page_data["text"] = page_text
                        result["text"] += page_text + "\\n\\n"
                
                # [LLM_CUSTOMIZE: table_handling]
                # Extract tables
                if default_options["extract_tables"]:
                    tables = page.extract_tables()
                    if tables:
                        for table in tables:
                            # Convert to DataFrame for easier handling
                            df = pd.DataFrame(table[1:], columns=table[0] if table else None)
                            page_data["tables"].append({
                                "data": df.to_dict('records'),
                                "rows": len(df),
                                "columns": list(df.columns)
                            })
                            result["tables"].append(df)
                        {table_handling}
                
                result["pages"].append(page_data)
        
        # [LLM_CUSTOMIZE: text_processing]
        # Process extracted text
        if result["text"]:
            # Clean up text
            result["text"] = result["text"].strip()
            # Remove excessive whitespace
            result["text"] = ' '.join(result["text"].split())
            {text_processing}
        
        # Update metadata
        metadata.update({
            "pages_extracted": len(result["pages"]),
            "text_length": len(result["text"]),
            "tables_found": len(result["tables"]),
            "extraction_options": default_options
        })
        
        logger.info(f"Successfully extracted PDF: {file_path} ({metadata['pages_extracted']} pages)")
        return result, metadata
        
    except ImportError as e:
        metadata["error"] = "Required libraries not installed (PyPDF2, pdfplumber)"
        logger.error(f"Missing PDF libraries: {e}")
        raise
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Failed to extract PDF: {e}")
        raise
'''