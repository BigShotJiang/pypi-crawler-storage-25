"""
KPI Dashboard Template - Real-time business metrics monitoring
"""
import asyncio
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Any, List, Tuple, Optional, Union
import json
import logging

logger = logging.getLogger(__name__)

async def kpi_dashboard(
    data_sources: List[Dict[str, Any]],
    kpi_definitions: Dict[str, Dict],
    refresh_interval: int = 60,
    dashboard_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    실시간 KPI 대시보드 생성 및 모니터링
    
    Args:
        data_sources: 데이터 소스 연결 정보 리스트
        kpi_definitions: KPI 정의 및 계산 방법
        refresh_interval: 새로고침 간격 (초)
        dashboard_options: 대시보드 옵션
    
    Returns:
        Tuple[Dict[str, Any], Dict[str, Any]]: (KPI 결과, 메타데이터)
    """
    try:
        options = dashboard_options or {}
        
        # KPI 계산
        kpi_results = {}
        
        # 샘플 KPI 계산
        for kpi_name, kpi_def in kpi_definitions.items():
            # 실제로는 데이터 소스에서 데이터를 가져와 계산
            if kpi_name == "revenue":
                kpi_results[kpi_name] = {
                    "value": 1250000,
                    "change": 12.5,
                    "status": "good",
                    "trend": "up"
                }
            elif kpi_name == "conversion_rate":
                kpi_results[kpi_name] = {
                    "value": 3.2,
                    "change": 0.5,
                    "status": "warning",
                    "trend": "stable"
                }
            elif kpi_name == "customer_satisfaction":
                kpi_results[kpi_name] = {
                    "value": 4.5,
                    "change": 0.2,
                    "status": "excellent",
                    "trend": "up"
                }
            else:
                kpi_results[kpi_name] = {
                    "value": 0,
                    "change": 0,
                    "status": "calculating",
                    "trend": "stable"
                }
        
        # 임계값 체크
        alerts = []
        for kpi_name, kpi_value in kpi_results.items():
            if kpi_name in kpi_definitions:
                thresholds = kpi_definitions[kpi_name].get("thresholds", {})
                value = kpi_value["value"]
                
                if "critical" in thresholds and value < thresholds["critical"]:
                    alerts.append({
                        "kpi": kpi_name,
                        "level": "critical",
                        "message": f"{kpi_name} is below critical threshold",
                        "value": value,
                        "threshold": thresholds["critical"]
                    })
                elif "warning" in thresholds and value < thresholds["warning"]:
                    alerts.append({
                        "kpi": kpi_name,
                        "level": "warning",
                        "message": f"{kpi_name} is below warning threshold",
                        "value": value,
                        "threshold": thresholds["warning"]
                    })
        
        # 대시보드 구성
        dashboard = {
            "kpis": kpi_results,
            "alerts": alerts,
            "last_updated": datetime.now().isoformat(),
            "refresh_interval": refresh_interval,
            "summary": {
                "total_kpis": len(kpi_results),
                "critical_alerts": len([a for a in alerts if a["level"] == "critical"]),
                "warning_alerts": len([a for a in alerts if a["level"] == "warning"]),
                "healthy_kpis": len([k for k, v in kpi_results.items() if v["status"] == "good" or v["status"] == "excellent"])
            }
        }
        
        # 메타데이터
        metadata = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "data_sources_count": len(data_sources),
            "kpi_count": len(kpi_results),
            "alert_count": len(alerts),
            "processing_time_ms": 125,
            "next_refresh": (datetime.now() + timedelta(seconds=refresh_interval)).isoformat()
        }
        
        logger.info(f"KPI dashboard generated with {len(kpi_results)} metrics and {len(alerts)} alerts")
        
        return dashboard, metadata
        
    except Exception as e:
        logger.error(f"Error generating KPI dashboard: {str(e)}")
        return {
            "error": str(e),
            "kpis": {}
        }, {
            "success": False,
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

# 샘플 데이터 생성 함수
def get_sample_data() -> Dict[str, Any]:
    """KPI 대시보드 샘플 데이터 생성"""
    return {
        "data_sources": [
            {
                "type": "database",
                "name": "analytics_db",
                "connection": "postgresql://localhost/analytics"
            },
            {
                "type": "api",
                "name": "google_analytics",
                "endpoint": "https://analytics.googleapis.com/v4"
            }
        ],
        "kpi_definitions": {
            "revenue": {
                "name": "Monthly Revenue",
                "calculation": "SUM(orders.total)",
                "unit": "USD",
                "thresholds": {
                    "warning": 1000000,
                    "critical": 800000
                }
            },
            "conversion_rate": {
                "name": "Conversion Rate",
                "calculation": "COUNT(conversions) / COUNT(visitors) * 100",
                "unit": "%",
                "thresholds": {
                    "warning": 2.5,
                    "critical": 2.0
                }
            },
            "customer_satisfaction": {
                "name": "Customer Satisfaction Score",
                "calculation": "AVG(feedback.rating)",
                "unit": "score",
                "thresholds": {
                    "warning": 4.0,
                    "critical": 3.5
                }
            },
            "response_time": {
                "name": "Average Response Time",
                "calculation": "AVG(api_logs.response_time)",
                "unit": "ms",
                "thresholds": {
                    "warning": 500,
                    "critical": 1000
                }
            }
        },
        "refresh_interval": 60,
        "dashboard_options": {
            "theme": "dark",
            "auto_refresh": True,
            "show_trends": True
        }
    }