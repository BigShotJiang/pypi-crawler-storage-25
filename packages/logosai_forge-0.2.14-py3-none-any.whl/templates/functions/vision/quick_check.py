"""vision/quick_check — Lightweight app status check (AppleScript/JS, ~0.1s)."""

TEMPLATE_INFO = {
    "id": "vision.quick_check",
    "name": "Quick App Check",
    "category": "vision",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio"],
    "llm_customizable": ["app_checks"],
}


def get_lightweight_app_check():
    return '''
async def _lightweight_app_check(self, app_name: str) -> dict:
    """Fast app status check without Vision AI (~0.1s). Uses AppleScript/JS."""
    import subprocess, asyncio

    # [LLM_CUSTOMIZE: app_checks]
    {app_checks}

    # Check if app is running
    try:
        script = f'tell application "System Events" to return (name of processes) contains "{app_name}"'
        result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=3)
        is_running = "true" in result.stdout.lower()

        if not is_running:
            return {"running": False, "state": "not_running", "action": "open_app"}

        # Check if app has windows
        script2 = f'tell application "System Events" to return count of windows of process "{app_name}"'
        result2 = subprocess.run(["osascript", "-e", script2], capture_output=True, text=True, timeout=3)
        window_count = int(result2.stdout.strip()) if result2.stdout.strip().isdigit() else 0

        return {
            "running": True,
            "windows": window_count,
            "state": "ready" if window_count > 0 else "no_window",
            "action": "activate" if window_count > 0 else "open_window",
        }
    except Exception as e:
        return {"running": False, "state": "error", "error": str(e)}
'''
