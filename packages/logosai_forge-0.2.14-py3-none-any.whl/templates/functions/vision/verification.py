"""vision/verification — Verify preconditions before actions."""

TEMPLATE_INFO = {
    "id": "vision.verification",
    "name": "Action Verification",
    "category": "vision",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "llm_customizable": ["verify_prompt"],
}


def get_verify_preconditions():
    return '''
async def _verify_preconditions(self, app_name: str, action: str, conditions: list = None) -> dict:
    """Verify that preconditions are met before performing an action."""
    import asyncio

    image_path = await self._capture_window(app_name)
    if not image_path:
        return {"ready": False, "error": "capture failed"}

    image_b64 = await self._encode_image(image_path)

    cond_text = "\\n".join(f"- {c}" for c in (conditions or [f"{action} is possible"]))

    # [LLM_CUSTOMIZE: verify_prompt]
    prompt = f"""Check if these conditions are met in {app_name}:
{cond_text}

Action to perform: {action}

Return JSON:
{{
    "ready": true/false,
    "conditions_met": ["condition1", ...],
    "conditions_not_met": ["condition2", ...],
    "suggestion": "what to do if not ready"
}}"""
    {verify_prompt}

    return await self._vision_query(image_b64, prompt)
'''
