"""vision/vision_llm — Vision LLM query (image + prompt → structured result)."""

TEMPLATE_INFO = {
    "id": "vision.vision_llm",
    "name": "Vision LLM Query",
    "category": "vision",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio", "json"],
    "external_dependencies": ["google.genai (Gemini Vision API)"],
    "llm_customizable": ["vision_model"],
}


def get_vision_query():
    return '''
async def _vision_query(self, image_base64: str, prompt: str, model: str = "gemini-2.5-flash-lite") -> dict:
    """Send image + prompt to Vision LLM → return JSON result."""
    import asyncio, json, re

    try:
        import google.generativeai as genai
        import os
        genai.configure(api_key=os.environ.get("GOOGLE_API_KEY", ""))

        llm = genai.GenerativeModel(model)
        import base64
        image_data = base64.b64decode(image_base64)

        response = await asyncio.to_thread(
            llm.generate_content,
            [prompt, {"mime_type": "image/png", "data": image_data}]
        )
        text = response.text if hasattr(response, "text") else str(response)

        # Try to parse JSON from response
        match = re.search(r"\\{.*\\}", text, re.DOTALL)
        if match:
            return json.loads(match.group())
        return {"raw": text}
    except Exception as e:
        return {"error": str(e)}
'''
