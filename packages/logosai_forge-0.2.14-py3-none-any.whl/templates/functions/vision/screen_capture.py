"""vision/screen_capture — Window screenshot + image encoding."""

TEMPLATE_INFO = {
    "id": "vision.screen_capture",
    "name": "Screen Capture",
    "category": "vision",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio", "os", "base64"],
    "external_dependencies": ["screencapture (macOS built-in)", "Peekaboo CLI (optional)"],
    "llm_customizable": ["capture_strategy"],
}


def get_capture_window():
    return '''
async def _capture_window(self, app_name: str = None) -> str:
    """Capture app window screenshot → returns base64 encoded image path."""
    import subprocess, asyncio, os, tempfile

    output_path = os.path.join(tempfile.gettempdir(), f"screen_{app_name or 'full'}.png")

    # [LLM_CUSTOMIZE: capture_strategy]
    # Strategy: Peekaboo → screencapture → full screen fallback
    {capture_strategy}

    # Try screencapture (macOS built-in)
    try:
        if app_name:
            # Get window ID for specific app
            script = f'tell application "System Events" to return id of window 1 of process "{app_name}"'
            result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=5)
            if result.returncode == 0 and result.stdout.strip():
                wid = result.stdout.strip()
                subprocess.run(["screencapture", "-l", wid, output_path], capture_output=True, timeout=5)
                if os.path.exists(output_path):
                    return output_path

        # Fallback: full screen
        subprocess.run(["screencapture", "-x", output_path], capture_output=True, timeout=5)
        return output_path if os.path.exists(output_path) else ""
    except Exception:
        return ""
'''


def get_get_window_id():
    return '''
async def _get_window_id(self, app_name: str) -> str:
    """Get macOS window ID for a specific app (CoreGraphics)."""
    import subprocess
    try:
        script = f"""
        tell application "System Events"
            tell process "{app_name}"
                return id of window 1
            end tell
        end tell
        """
        result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=5)
        return result.stdout.strip() if result.returncode == 0 else ""
    except Exception:
        return ""
'''


def get_encode_image():
    return '''
async def _encode_image(self, image_path: str, max_width: int = 1024) -> str:
    """Encode image to base64 string (with optional resize)."""
    import base64, os
    if not os.path.exists(image_path):
        return ""
    try:
        # Try resize with PIL if available
        try:
            from PIL import Image
            img = Image.open(image_path)
            if img.width > max_width:
                ratio = max_width / img.width
                img = img.resize((max_width, int(img.height * ratio)))
                img.save(image_path)
        except ImportError:
            pass

        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    except Exception:
        return ""
'''
