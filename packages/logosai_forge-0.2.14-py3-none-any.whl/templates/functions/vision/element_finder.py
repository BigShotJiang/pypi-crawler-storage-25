"""vision/element_finder — Find UI elements on screen using Vision AI."""

TEMPLATE_INFO = {
    "id": "vision.element_finder",
    "name": "Element Finder",
    "category": "vision",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "llm_customizable": ["find_prompt"],
}


def get_find_element_on_screen():
    return '''
async def _find_element_on_screen(self, app_name: str, target: str) -> dict:
    """Find a specific UI element on screen using Vision AI."""
    import asyncio

    image_path = await self._capture_window(app_name)
    if not image_path:
        return {"found": False, "error": "capture failed"}

    image_b64 = await self._encode_image(image_path)
    if not image_b64:
        return {"found": False, "error": "encode failed"}

    # [LLM_CUSTOMIZE: find_prompt]
    prompt = f"""Find "{target}" on this screenshot of {app_name}.
Return JSON:
{{
    "found": true/false,
    "x": pixel_x_coordinate,
    "y": pixel_y_coordinate,
    "text": "matched text",
    "action": "click" | "arrow_down_N" | "scroll_down",
    "confidence": 0.0-1.0
}}
If not found, return {{"found": false, "suggestion": "what to try next"}}"""
    {find_prompt}

    result = await self._vision_query(image_b64, prompt)
    return result
'''
