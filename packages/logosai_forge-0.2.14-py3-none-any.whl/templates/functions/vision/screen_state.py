"""vision/screen_state — Analyze app screen state (login needed? ready? next action?)."""

TEMPLATE_INFO = {
    "id": "vision.screen_state",
    "name": "Screen State Analysis",
    "category": "vision",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["asyncio"],
    "llm_customizable": ["state_prompt"],
}


def get_analyze_screen_state():
    return '''
async def _analyze_screen_state(self, app_name: str, expected_state: str = "main screen") -> dict:
    """Analyze current app screen state using Vision AI."""
    import asyncio

    # Capture current screen
    image_path = await self._capture_window(app_name)
    if not image_path:
        return {"state": "unknown", "error": "capture failed"}

    image_b64 = await self._encode_image(image_path)
    if not image_b64:
        return {"state": "unknown", "error": "encode failed"}

    # [LLM_CUSTOMIZE: state_prompt]
    prompt = f"""Analyze this screenshot of {app_name}.
Return JSON:
{{
    "state": "ready" | "login_required" | "loading" | "error" | "popup",
    "description": "what you see",
    "needs_login": true/false,
    "next_action": "suggested action"
}}
Expected state: {expected_state}"""
    {state_prompt}

    result = await self._vision_query(image_b64, prompt)
    return result
'''
