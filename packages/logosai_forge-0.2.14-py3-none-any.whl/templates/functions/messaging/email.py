"""messaging/email — Gmail browser automation (10 functions)."""

TEMPLATE_INFO = {
    "id": "messaging.email",
    "name": "Gmail Email",
    "category": "messaging",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio", "json"],
    "external_dependencies": ["Google Chrome", "Peekaboo CLI"],
    "llm_customizable": ["email_compose_prompt"],
}


def get_compose_email():
    return '''
async def _compose_email(self, to: str, subject: str, body: str) -> bool:
    """Open Gmail compose window via Chrome URL."""
    import subprocess, urllib.parse
    params = urllib.parse.urlencode({"to": to, "su": subject, "body": body})
    url = f"https://mail.google.com/mail/?view=cm&{params}"
    subprocess.Popen(["open", "-a", "Google Chrome", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True
'''


def get_send_email():
    return '''
async def _send_email(self, app: str = "Google Chrome") -> bool:
    """Send email in Gmail compose window (Cmd+Enter)."""
    import asyncio
    await self._hotkey("command+return", app)
    await asyncio.sleep(2)
    return True
'''


def get_attach_file_to_email():
    return '''
async def _attach_file_to_email(self, file_path: str) -> bool:
    """Attach file to Gmail compose (Finder copy → Chrome paste)."""
    import subprocess, asyncio, os
    if not os.path.exists(file_path):
        return False
    # Copy file in Finder
    script = f'tell application "Finder" to set the clipboard to (POSIX file "{file_path}" as alias)'
    subprocess.run(["osascript", "-e", script], capture_output=True, timeout=5)
    await asyncio.sleep(0.5)
    # Paste in Chrome
    await self._activate_app("Google Chrome")
    await asyncio.sleep(0.5)
    await self._hotkey("command+v", "Google Chrome")
    await asyncio.sleep(2)
    return True
'''


def get_search_emails():
    return '''
async def _search_emails(self, query: str) -> dict:
    """Search Gmail via URL + parse results with Vision."""
    import subprocess, urllib.parse, asyncio
    encoded = urllib.parse.quote(query)
    url = f"https://mail.google.com/mail/#search/{encoded}"
    subprocess.Popen(["open", "-a", "Google Chrome", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    await asyncio.sleep(3)
    # Read results via Chrome JS
    js = "document.querySelectorAll('tr.zA').length"
    count = await self._chrome_execute_js(js)
    return {"query": query, "result_count": count, "answer": f"Gmail search: {query} ({count} results)"}
'''


def get_read_inbox():
    return '''
async def _read_inbox(self, max_emails: int = 10) -> dict:
    """Read Gmail inbox via Chrome JavaScript DOM extraction."""
    import asyncio, json
    js = f"""
    (function() {{
        var rows = document.querySelectorAll('tr.zA');
        var emails = [];
        for (var i = 0; i < Math.min(rows.length, {max_emails}); i++) {{
            var row = rows[i];
            var sender = row.querySelector('.yW span') ? row.querySelector('.yW span').getAttribute('email') || row.querySelector('.yW span').textContent : '';
            var subject = row.querySelector('.bog') ? row.querySelector('.bog').textContent : '';
            var snippet = row.querySelector('.y2') ? row.querySelector('.y2').textContent : '';
            var date = row.querySelector('.xW') ? row.querySelector('.xW').textContent : '';
            emails.push({{sender: sender, subject: subject, snippet: snippet, date: date}});
        }}
        return JSON.stringify(emails);
    }})()
    """
    result = await self._chrome_execute_js(js)
    try:
        emails = json.loads(result) if result and not result.startswith("ERROR") else []
    except Exception:
        emails = []
    answer = f"Inbox: {len(emails)} emails\\n" + "\\n".join(f"- {e.get('sender','?')}: {e.get('subject','')}" for e in emails[:5])
    return {"emails": emails, "answer": answer}
'''


def get_read_email_detail():
    return '''
async def _read_email_detail(self) -> dict:
    """Read currently open email body via Chrome JS."""
    import asyncio
    js = """
    (function() {
        var body = document.querySelector('.a3s.aiL');
        return body ? body.innerText.substring(0, 3000) : 'No email body found';
    })()
    """
    body = await self._chrome_execute_js(js)
    return {"body": body, "answer": body[:2000]}
'''


def get_reply_to_email():
    return """
async def _reply_to_email(self, reply_text: str) -> bool:
    \"\"\"Reply to currently open email (click Reply → paste → send).\"\"\"
    import asyncio
    js = 'document.querySelector(\\'[data-tooltip="Reply"]\\').click()'
    await self._chrome_execute_js(js)
    await asyncio.sleep(1)
    await self._paste_text(reply_text, "Google Chrome")
    await asyncio.sleep(0.5)
    await self._hotkey("command+return", "Google Chrome")
    return True
"""


def get_delete_email():
    return """
async def _delete_email(self) -> bool:
    \"\"\"Delete currently open email (click Delete button).\"\"\"
    import asyncio
    js = 'document.querySelector(\\'[data-tooltip="Delete"]\\').click()'
    result = await self._chrome_execute_js(js)
    return "ERROR" not in (result or "")
"""


def get_draft_email_content():
    return '''
async def _draft_email_content(self, context: str, tone: str = "professional") -> str:
    """LLM drafts email body based on context and tone."""
    import asyncio

    # [LLM_CUSTOMIZE: email_compose_prompt]
    {email_compose_prompt}

    if not hasattr(self, "_llm") or not self._llm:
        return context

    try:
        resp = await asyncio.wait_for(
            self._llm.invoke(
                f"Write an email body.\\nContext: {context}\\nTone: {tone}\\n\\n"
                "Write ONLY the email body (no subject line, no greeting if not needed)."
            ), timeout=15)
        return resp.content if hasattr(resp, "content") else str(resp)
    except Exception:
        return context
'''


def get_find_file_for_attachment():
    return '''
async def _find_file_for_attachment(self, filename: str) -> str:
    """Find file for email attachment (4-stage: Spotlight → common paths → find → fallback)."""
    import os, subprocess, asyncio

    # Stage 1: Spotlight
    try:
        result = subprocess.run(["mdfind", "-name", filename], capture_output=True, text=True, timeout=5)
        files = [f.strip() for f in result.stdout.strip().split("\\n") if f.strip() and os.path.isfile(f.strip())]
        if files:
            return files[0]
    except Exception:
        pass

    # Stage 2: Common paths
    home = os.path.expanduser("~")
    for d in ["Downloads", "Documents", "Desktop"]:
        path = os.path.join(home, d, filename)
        if os.path.exists(path):
            return path

    # Stage 3: find command
    try:
        result = subprocess.run(
            ["find", home, "-maxdepth", "4", "-iname", f"*{filename}*", "-type", "f"],
            capture_output=True, text=True, timeout=10)
        files = [f.strip() for f in result.stdout.strip().split("\\n") if f.strip()]
        if files:
            return files[0]
    except Exception:
        pass

    return ""
'''
