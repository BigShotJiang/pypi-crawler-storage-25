"""messaging/kakaotalk — KakaoTalk messaging automation (5 functions)."""

TEMPLATE_INFO = {
    "id": "messaging.kakaotalk",
    "name": "KakaoTalk Messaging",
    "category": "messaging",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio", "json"],
    "external_dependencies": ["Peekaboo CLI", "Vision AI (Gemini)"],
    "llm_customizable": ["search_strategy", "retry_logic"],
}


def get_parse_message_query():
    return '''
async def _parse_message_query(self, query: str) -> dict:
    """LLM extracts recipient + message from natural language query."""
    import asyncio, json, re

    if not hasattr(self, "_llm") or not self._llm:
        return {"recipient": "", "message": query, "error": "LLM not available"}

    try:
        resp = await asyncio.wait_for(
            self._llm.invoke(
                f"Extract the recipient and message from this request.\\n\\n"
                f"Request: {query}\\n\\n"
                'Return JSON: {{"recipient": "name", "message": "message text"}}\\n'
                "If no clear recipient, return empty string."
            ), timeout=10)
        text = resp.content if hasattr(resp, "content") else str(resp)
        match = re.search(r"\\{.*\\}", text, re.DOTALL)
        if match:
            return json.loads(match.group())
    except Exception:
        pass
    return {"recipient": "", "message": query}
'''


def get_search_friend():
    return '''
async def _search_friend(self, recipient: str, app: str = "KakaoTalk") -> bool:
    """Search for a friend in KakaoTalk Friends tab (Vision + keyboard)."""
    import asyncio

    # [LLM_CUSTOMIZE: search_strategy]
    {search_strategy}

    # 1. Activate KakaoTalk
    await self._activate_app(app)
    await asyncio.sleep(1)

    # 2. Click Friends tab (tab index 1)
    await self._click_tab_by_index(app, tab_index=1)
    await asyncio.sleep(0.5)

    # 3. Try Vision scan (no search — scroll through friends)
    result = await self._find_element_on_screen(app, recipient)
    if result.get("found"):
        if result.get("action", "").startswith("arrow_down"):
            n = int(result["action"].split("_")[-1]) if "_" in result["action"] else 1
            for _ in range(n):
                await self._press_key("down", app)
                await asyncio.sleep(0.2)
        return True

    # 4. Click Search button + type name
    await self._click_ui_button(app, "Search")
    await asyncio.sleep(0.5)
    await self._paste_text(recipient, app)
    await asyncio.sleep(1)

    # 5. Vision scan search results
    result = await self._find_element_on_screen(app, recipient)
    if result.get("found"):
        return True

    # [LLM_CUSTOMIZE: retry_logic]
    {retry_logic}

    return False
'''


def get_open_chat():
    return '''
async def _open_chat(self, app: str = "KakaoTalk") -> bool:
    """Open chat room after selecting a friend (press Enter)."""
    import asyncio
    await self._press_key("enter", app)
    await asyncio.sleep(1)
    # Verify chat opened via Vision
    state = await self._analyze_screen_state(app, "chat room")
    return state.get("state") == "ready"
'''


def get_send_chat_message():
    return '''
async def _send_chat_message(self, message: str, app: str = "KakaoTalk") -> bool:
    """Send message in current KakaoTalk chat room (paste + Enter)."""
    import asyncio
    await self._paste_text(message, app)
    await asyncio.sleep(0.5)
    await self._press_key("enter", app)
    await asyncio.sleep(1)
    return True
'''


def get_verify_message_sent():
    return '''
async def _verify_message_sent(self, message: str, app: str = "KakaoTalk") -> bool:
    """Verify message was sent via Vision AI (check chat bubble)."""
    import asyncio
    result = await self._find_element_on_screen(app, message[:20])
    return result.get("found", False)
'''
