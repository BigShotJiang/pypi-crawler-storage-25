# messaging — KakaoTalk, Email automation function templates (macOS)
