"""file_write/spreadsheet_writer — Create Excel workbooks + CSV files."""

TEMPLATE_INFO = {
    "id": "file_write.spreadsheet_writer",
    "name": "Spreadsheet Writer",
    "category": "file_write",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["os", "tempfile"],
    "llm_customizable": ["sheet_formatting", "chart_options"],
}


def get_create_xlsx():
    return '''
async def _create_xlsx(self, title: str, sheets: dict, output_path: str = None) -> dict:
    """Create Excel workbook with multiple sheets.

    Args:
        title: Workbook title (used for filename)
        sheets: {"Sheet1": {"headers": [str], "data": [[values]], "chart": {"type": "bar", "x_col": 0, "y_col": 1}}}

    Returns: {"file_path": str, "sheet_count": int, "answer": str}
    """
    import os, tempfile
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.chart import BarChart, LineChart, PieChart, Reference

        wb = Workbook()
        wb.remove(wb.active)

        for sheet_name, sheet_data in sheets.items():
            ws = wb.create_sheet(title=sheet_name)
            headers = sheet_data.get("headers", [])
            data = sheet_data.get("data", [])

            # Headers
            header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)
            for col, h in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col, value=h)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center")

            # Data rows
            for row_idx, row_data in enumerate(data, 2):
                for col_idx, value in enumerate(row_data, 1):
                    ws.cell(row=row_idx, column=col_idx, value=value)

            # Auto-width
            for col in ws.columns:
                max_len = max((len(str(cell.value or "")) for cell in col), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 30)

            # Chart
            chart_cfg = sheet_data.get("chart")
            if chart_cfg and data:
                chart_type = chart_cfg.get("type", "bar")
                chart_cls = {"bar": BarChart, "line": LineChart, "pie": PieChart}.get(chart_type, BarChart)
                chart = chart_cls()
                chart.title = sheet_name
                y_col = chart_cfg.get("y_col", 1) + 1
                data_ref = Reference(ws, min_col=y_col, min_row=1, max_row=len(data)+1)
                cats_ref = Reference(ws, min_col=1, min_row=2, max_row=len(data)+1)
                chart.add_data(data_ref, titles_from_data=True)
                chart.set_categories(cats_ref)
                ws.add_chart(chart, "E2")

        path = output_path or os.path.join(tempfile.gettempdir(), f"{title[:30].replace(' ','_')}.xlsx")
        wb.save(path)
        return {"file_path": path, "file_name": os.path.basename(path),
                "sheet_count": len(sheets), "answer": f"Excel 생성 완료: {path}"}
    except ImportError:
        return {"error": "openpyxl not installed", "answer": "openpyxl 설치 필요"}
    except Exception as e:
        return {"error": str(e), "answer": f"Excel 생성 실패: {e}"}
'''


def get_write_csv():
    return '''
async def _write_csv(self, data: list, headers: list = None, output_path: str = None, delimiter: str = ",") -> dict:
    """Write data to CSV file.

    Args:
        data: List of dicts or list of lists
        headers: Column headers (auto-detected from dict keys if not provided)
        output_path: Save path

    Returns: {"file_path": str, "rows": int, "answer": str}
    """
    import os, csv, tempfile

    if not data:
        return {"error": "No data", "answer": "데이터가 없습니다"}

    path = output_path or os.path.join(tempfile.gettempdir(), "output.csv")
    try:
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            if isinstance(data[0], dict):
                cols = headers or list(data[0].keys())
                writer = csv.DictWriter(f, fieldnames=cols, delimiter=delimiter)
                writer.writeheader()
                writer.writerows(data)
            else:
                writer = csv.writer(f, delimiter=delimiter)
                if headers:
                    writer.writerow(headers)
                writer.writerows(data)

        return {"file_path": path, "file_name": os.path.basename(path),
                "rows": len(data), "answer": f"CSV 저장 완료: {path} ({len(data)} rows)"}
    except Exception as e:
        return {"error": str(e), "answer": f"CSV 저장 실패: {e}"}
'''
