"""file_write/text_writer — Write text, JSON, append to files."""

TEMPLATE_INFO = {
    "id": "file_write.text_writer",
    "name": "Text Writer",
    "category": "file_write",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["os", "json"],
    "llm_customizable": [],
}


def get_write_text():
    return '''
async def _write_text(self, content: str, output_path: str = None, filename: str = "output.txt") -> dict:
    """Write text content to file."""
    import os, tempfile
    path = output_path or os.path.join(tempfile.gettempdir(), filename)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return {"file_path": path, "file_name": os.path.basename(path),
                "size": len(content), "answer": f"파일 저장 완료: {path}"}
    except Exception as e:
        return {"error": str(e), "answer": f"파일 저장 실패: {e}"}
'''


def get_write_json():
    return '''
async def _write_json(self, data: dict, output_path: str = None, filename: str = "output.json") -> dict:
    """Write dict/list as formatted JSON file."""
    import os, json, tempfile
    path = output_path or os.path.join(tempfile.gettempdir(), filename)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
        return {"file_path": path, "file_name": os.path.basename(path),
                "answer": f"JSON 저장 완료: {path}"}
    except Exception as e:
        return {"error": str(e), "answer": f"JSON 저장 실패: {e}"}
'''


def get_append_to_file():
    return '''
async def _append_to_file(self, content: str, file_path: str) -> dict:
    """Append content to existing file (create if not exists)."""
    import os
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "a", encoding="utf-8") as f:
            f.write(content)
        return {"file_path": file_path, "answer": f"파일에 추가 완료: {file_path}"}
    except Exception as e:
        return {"error": str(e), "answer": f"파일 추가 실패: {e}"}
'''
