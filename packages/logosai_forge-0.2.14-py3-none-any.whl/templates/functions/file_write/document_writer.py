"""file_write/document_writer — Create PPT, Word, PDF documents."""

TEMPLATE_INFO = {
    "id": "file_write.document_writer",
    "name": "Document Writer",
    "category": "file_write",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["os", "tempfile"],
    "llm_customizable": ["slide_layout", "doc_style", "pdf_style"],
}


def get_create_pptx():
    return '''
async def _create_pptx(self, title: str, slides: list, subtitle: str = "", output_path: str = None) -> dict:
    """Create PowerPoint presentation with slides.

    Args:
        title: Presentation title
        slides: [{"title": str, "bullets": [str], "notes": str}]
        output_path: Optional save path (default: tempdir)

    Returns: {"file_path": str, "slide_count": int, "answer": str}
    """
    import os, tempfile
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt
        from pptx.enum.text import PP_ALIGN

        prs = Presentation()

        # Title slide
        title_slide = prs.slides.add_slide(prs.slide_layouts[0])
        title_slide.shapes.title.text = title
        if subtitle and title_slide.placeholders[1]:
            title_slide.placeholders[1].text = subtitle

        # Content slides
        for slide_data in slides:
            slide = prs.slides.add_slide(prs.slide_layouts[1])
            slide.shapes.title.text = slide_data.get("title", "")
            body = slide.placeholders[1]
            tf = body.text_frame
            tf.clear()
            for i, bullet in enumerate(slide_data.get("bullets", [])):
                p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
                p.text = bullet
                p.font.size = Pt(18)

        path = output_path or os.path.join(tempfile.gettempdir(), f"{title[:30].replace(' ','_')}.pptx")
        prs.save(path)
        return {"file_path": path, "file_name": os.path.basename(path),
                "slide_count": len(prs.slides), "answer": f"PPT 생성 완료: {path}"}
    except ImportError:
        return {"error": "python-pptx not installed", "answer": "python-pptx 설치 필요"}
    except Exception as e:
        return {"error": str(e), "answer": f"PPT 생성 실패: {e}"}
'''


def get_create_docx():
    return '''
async def _create_docx(self, title: str, sections: list, output_path: str = None) -> dict:
    """Create Word document with sections.

    Args:
        title: Document title
        sections: [{"type": "heading|paragraph|table|bullet", "content": Any, "level": int}]

    Returns: {"file_path": str, "answer": str}
    """
    import os, tempfile
    try:
        from docx import Document
        from docx.shared import Pt

        doc = Document()
        doc.add_heading(title, level=0)

        for sec in sections:
            stype = sec.get("type", "paragraph")
            content = sec.get("content", "")
            if stype == "heading":
                doc.add_heading(content, level=sec.get("level", 1))
            elif stype == "paragraph":
                doc.add_paragraph(content)
            elif stype == "bullet":
                if isinstance(content, list):
                    for item in content:
                        doc.add_paragraph(item, style="List Bullet")
                else:
                    doc.add_paragraph(content, style="List Bullet")
            elif stype == "table":
                if isinstance(content, list) and content:
                    headers = list(content[0].keys()) if isinstance(content[0], dict) else []
                    if headers:
                        table = doc.add_table(rows=1, cols=len(headers))
                        table.style = "Table Grid"
                        for i, h in enumerate(headers):
                            table.rows[0].cells[i].text = str(h)
                        for row_data in content:
                            row = table.add_row()
                            for i, h in enumerate(headers):
                                row.cells[i].text = str(row_data.get(h, ""))

        path = output_path or os.path.join(tempfile.gettempdir(), f"{title[:30].replace(' ','_')}.docx")
        doc.save(path)
        return {"file_path": path, "file_name": os.path.basename(path), "answer": f"Word 생성 완료: {path}"}
    except ImportError:
        return {"error": "python-docx not installed", "answer": "python-docx 설치 필요"}
    except Exception as e:
        return {"error": str(e), "answer": f"Word 생성 실패: {e}"}
'''


def get_create_pdf():
    return '''
async def _create_pdf(self, title: str, content: list, output_path: str = None) -> dict:
    """Create PDF document.

    Args:
        title: Document title
        content: [{"type": "text|heading|table", "data": str|list}]

    Returns: {"file_path": str, "answer": str}
    """
    import os, tempfile
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors

        path = output_path or os.path.join(tempfile.gettempdir(), f"{title[:30].replace(' ','_')}.pdf")
        doc = SimpleDocTemplate(path, pagesize=A4)
        styles = getSampleStyleSheet()
        elements = []

        elements.append(Paragraph(title, styles["Title"]))
        elements.append(Spacer(1, 1*cm))

        for item in content:
            itype = item.get("type", "text")
            data = item.get("data", "")
            if itype == "heading":
                elements.append(Paragraph(data, styles["Heading2"]))
            elif itype == "text":
                elements.append(Paragraph(data, styles["Normal"]))
                elements.append(Spacer(1, 0.3*cm))
            elif itype == "table" and isinstance(data, list):
                t = Table(data)
                t.setStyle(TableStyle([
                    ("BACKGROUND", (0,0), (-1,0), colors.grey),
                    ("TEXTCOLOR", (0,0), (-1,0), colors.whitesmoke),
                    ("GRID", (0,0), (-1,-1), 1, colors.black),
                ]))
                elements.append(t)
                elements.append(Spacer(1, 0.5*cm))

        doc.build(elements)
        return {"file_path": path, "file_name": os.path.basename(path), "answer": f"PDF 생성 완료: {path}"}
    except ImportError:
        return {"error": "reportlab not installed", "answer": "reportlab 설치 필요"}
    except Exception as e:
        return {"error": str(e), "answer": f"PDF 생성 실패: {e}"}
'''
