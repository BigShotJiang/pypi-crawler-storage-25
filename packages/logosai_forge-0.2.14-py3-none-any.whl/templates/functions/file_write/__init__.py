# file_write — File creation function templates (PPT, Excel, Word, PDF, CSV, JSON)
