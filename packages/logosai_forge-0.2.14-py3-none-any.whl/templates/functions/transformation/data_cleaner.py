"""
Data Cleaning Template
"""

TEMPLATE_INFO = {
    "id": "transformation.data_cleaner",
    "name": "Data Cleaner",
    "category": "transformation",
    "version": "1.0.0",
    "llm_customizable": ["cleaning_rules", "validation_logic", "custom_transformations"]
}

def get_data_cleaner():
    """데이터 정제 함수 템플릿"""
    return '''
async def _clean_data(
    self,
    data: Union[pd.DataFrame, List[Dict], Dict],
    cleaning_config: Optional[Dict] = None
) -> Dict[str, Any]:
    """
    Clean and preprocess data with various cleaning strategies.
    
    Args:
        data: Input data to clean
        cleaning_config: Configuration for cleaning operations
    
    Returns:
        Dict with cleaned data and cleaning report
    """
    result = {
        "cleaned_data": None,
        "original_shape": None,
        "cleaned_shape": None,
        "operations_performed": [],
        "issues_found": [],
        "statistics": {},
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        # Convert to DataFrame if needed
        if isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, dict):
            df = pd.DataFrame([data] if not any(isinstance(v, list) for v in data.values()) else data)
        else:
            df = data.copy()
        
        result["original_shape"] = df.shape
        original_df = df.copy()
        
        # Default cleaning configuration
        config = {
            "remove_duplicates": True,
            "handle_missing": "drop",  # drop, fill_mean, fill_median, fill_mode, forward_fill
            "remove_outliers": False,
            "standardize_text": True,
            "fix_dtypes": True,
            "custom_rules": []
        }
        
        if cleaning_config:
            config.update(cleaning_config)
        
        # [LLM_CUSTOMIZE: cleaning_rules]
        # Add custom cleaning rules
        {cleaning_rules}
        
        # 1. Remove duplicates
        if config["remove_duplicates"]:
            before_rows = len(df)
            df = df.drop_duplicates()
            after_rows = len(df)
            if before_rows > after_rows:
                result["operations_performed"].append(f"Removed {before_rows - after_rows} duplicate rows")
                result["issues_found"].append({"type": "duplicates", "count": before_rows - after_rows})
        
        # 2. Handle missing values
        missing_cols = df.columns[df.isnull().any()].tolist()
        if missing_cols:
            result["issues_found"].append({
                "type": "missing_values",
                "columns": missing_cols,
                "counts": df[missing_cols].isnull().sum().to_dict()
            })
            
            if config["handle_missing"] == "drop":
                df = df.dropna()
                result["operations_performed"].append("Dropped rows with missing values")
            
            elif config["handle_missing"] == "fill_mean":
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())
                result["operations_performed"].append("Filled missing numeric values with mean")
            
            elif config["handle_missing"] == "fill_median":
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].median())
                result["operations_performed"].append("Filled missing numeric values with median")
            
            elif config["handle_missing"] == "fill_mode":
                for col in missing_cols:
                    if not df[col].empty:
                        mode_value = df[col].mode()
                        if not mode_value.empty:
                            df[col] = df[col].fillna(mode_value[0])
                result["operations_performed"].append("Filled missing values with mode")
            
            elif config["handle_missing"] == "forward_fill":
                df = df.fillna(method='ffill')
                result["operations_performed"].append("Forward filled missing values")
        
        # 3. Fix data types
        if config["fix_dtypes"]:
            for col in df.columns:
                # Try to convert to numeric
                if df[col].dtype == 'object':
                    try:
                        # Check if it looks like numeric
                        test_val = pd.to_numeric(df[col], errors='coerce')
                        if test_val.notna().sum() > len(df) * 0.5:  # More than 50% are numeric
                            df[col] = test_val
                            result["operations_performed"].append(f"Converted {col} to numeric")
                    except:
                        pass
                    
                    # Try to convert to datetime
                    try:
                        if any(keyword in col.lower() for keyword in ['date', 'time', 'created', 'updated']):
                            df[col] = pd.to_datetime(df[col], errors='coerce')
                            result["operations_performed"].append(f"Converted {col} to datetime")
                    except:
                        pass
        
        # 4. Standardize text columns
        if config["standardize_text"]:
            text_cols = df.select_dtypes(include=['object']).columns
            for col in text_cols:
                # Strip whitespace
                df[col] = df[col].astype(str).str.strip()
                
                # Standardize case for certain columns
                if any(keyword in col.lower() for keyword in ['email', 'url', 'id']):
                    df[col] = df[col].str.lower()
                elif any(keyword in col.lower() for keyword in ['name', 'title', 'city', 'country']):
                    df[col] = df[col].str.title()
                
                result["operations_performed"].append(f"Standardized text in {col}")
        
        # 5. Remove outliers (for numeric columns)
        if config["remove_outliers"]:
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)]
                if len(outliers) > 0:
                    df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]
                    result["operations_performed"].append(f"Removed {len(outliers)} outliers from {col}")
                    result["issues_found"].append({
                        "type": "outliers",
                        "column": col,
                        "count": len(outliers),
                        "bounds": {"lower": lower_bound, "upper": upper_bound}
                    })
        
        # [LLM_CUSTOMIZE: validation_logic]
        # Add data validation logic
        {validation_logic}
        
        # 6. Apply custom rules
        if config.get("custom_rules"):
            for rule in config["custom_rules"]:
                try:
                    # Rule format: {"column": "col_name", "operation": "func", "params": {}}
                    col = rule.get("column")
                    operation = rule.get("operation")
                    params = rule.get("params", {})
                    
                    if col in df.columns:
                        if operation == "replace":
                            df[col] = df[col].replace(**params)
                        elif operation == "map":
                            df[col] = df[col].map(params)
                        elif operation == "apply":
                            df[col] = df[col].apply(params)
                        
                        result["operations_performed"].append(f"Applied custom rule to {col}")
                except Exception as e:
                    logger.warning(f"Failed to apply custom rule: {e}")
        
        # [LLM_CUSTOMIZE: custom_transformations]
        # Add custom transformations
        {custom_transformations}
        
        # Calculate statistics
        result["cleaned_shape"] = df.shape
        result["statistics"] = {
            "rows_removed": result["original_shape"][0] - result["cleaned_shape"][0],
            "removal_percentage": ((result["original_shape"][0] - result["cleaned_shape"][0]) / result["original_shape"][0] * 100) if result["original_shape"][0] > 0 else 0,
            "columns": len(df.columns),
            "dtypes": df.dtypes.astype(str).to_dict(),
            "missing_values": df.isnull().sum().to_dict(),
            "memory_usage": df.memory_usage(deep=True).sum() / 1024 / 1024  # MB
        }
        
        # Add quality score
        quality_score = 100
        
        # Deduct for missing values
        total_cells = df.shape[0] * df.shape[1]
        missing_cells = df.isnull().sum().sum()
        if total_cells > 0:
            quality_score -= (missing_cells / total_cells) * 20
        
        # Deduct for duplicates found
        if any(issue["type"] == "duplicates" for issue in result["issues_found"]):
            quality_score -= 10
        
        # Deduct for outliers found
        if any(issue["type"] == "outliers" for issue in result["issues_found"]):
            quality_score -= 5
        
        result["statistics"]["quality_score"] = max(0, quality_score)
        
        result["cleaned_data"] = df
        result["success"] = True
        
        logger.info(f"Data cleaning completed: {len(result['operations_performed'])} operations performed")
        return result
        
    except Exception as e:
        logger.error(f"Data cleaning failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''