"""
Data Aggregation Template
"""

TEMPLATE_INFO = {
    "id": "transformation.data_aggregator",
    "name": "Data Aggregator",
    "category": "transformation",
    "version": "1.0.0",
    "llm_customizable": ["aggregation_logic", "custom_metrics", "grouping_rules"]
}

def get_data_aggregator():
    """데이터 집계 함수 템플릿"""
    return '''
async def _aggregate_data(
    self,
    data: Union[pd.DataFrame, List[Dict]],
    group_by: Optional[Union[str, List[str]]] = None,
    aggregations: Optional[Dict[str, Union[str, List[str]]]] = None,
    time_column: Optional[str] = None,
    time_period: Optional[str] = None
) -> Dict[str, Any]:
    """
    Aggregate data with various grouping and aggregation strategies.
    
    Args:
        data: Input data to aggregate
        group_by: Column(s) to group by
        aggregations: Dict of column: aggregation_function(s)
        time_column: Column for time-based aggregation
        time_period: Period for time aggregation (D, W, M, Q, Y)
    
    Returns:
        Dict with aggregated data and statistics
    """
    result = {
        "aggregated_data": None,
        "original_rows": 0,
        "aggregated_rows": 0,
        "aggregations_applied": {},
        "group_statistics": {},
        "time_series": None,
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        # Convert to DataFrame if needed
        if isinstance(data, list):
            df = pd.DataFrame(data)
        else:
            df = data.copy()
        
        result["original_rows"] = len(df)
        
        # [LLM_CUSTOMIZE: aggregation_logic]
        # Add custom aggregation logic
        {aggregation_logic}
        
        # Default aggregations if not specified
        if aggregations is None:
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            aggregations = {}
            for col in numeric_cols:
                # Smart aggregation based on column name
                if any(keyword in col.lower() for keyword in ['count', 'quantity', 'number']):
                    aggregations[col] = 'sum'
                elif any(keyword in col.lower() for keyword in ['price', 'cost', 'amount', 'value']):
                    aggregations[col] = ['sum', 'mean', 'min', 'max']
                elif any(keyword in col.lower() for keyword in ['rate', 'ratio', 'percentage']):
                    aggregations[col] = 'mean'
                else:
                    aggregations[col] = ['sum', 'mean']
        
        # Time-based aggregation
        if time_column and time_column in df.columns:
            try:
                df[time_column] = pd.to_datetime(df[time_column])
                
                # Set time column as index for resampling
                df_time = df.set_index(time_column)
                
                # Determine period if not specified
                if time_period is None:
                    date_range = df[time_column].max() - df[time_column].min()
                    if date_range.days <= 7:
                        time_period = 'H'  # Hourly
                    elif date_range.days <= 31:
                        time_period = 'D'  # Daily
                    elif date_range.days <= 365:
                        time_period = 'W'  # Weekly
                    else:
                        time_period = 'M'  # Monthly
                
                # Resample and aggregate
                time_agg = df_time.resample(time_period).agg(aggregations)
                result["time_series"] = time_agg
                result["aggregations_applied"]["time_based"] = {
                    "period": time_period,
                    "start": str(df[time_column].min()),
                    "end": str(df[time_column].max()),
                    "periods": len(time_agg)
                }
                
                logger.info(f"Time-based aggregation completed: {time_period}")
                
            except Exception as e:
                logger.warning(f"Time-based aggregation failed: {e}")
        
        # Group-based aggregation
        if group_by:
            if isinstance(group_by, str):
                group_by = [group_by]
            
            # Filter valid columns
            valid_groups = [col for col in group_by if col in df.columns]
            
            if valid_groups:
                # [LLM_CUSTOMIZE: grouping_rules]
                # Add custom grouping rules
                {grouping_rules}
                
                # Perform aggregation
                agg_df = df.groupby(valid_groups).agg(aggregations)
                
                # Flatten multi-level columns if needed
                if isinstance(agg_df.columns, pd.MultiIndex):
                    agg_df.columns = ['_'.join(col).strip() for col in agg_df.columns.values]
                
                agg_df = agg_df.reset_index()
                
                result["aggregated_data"] = agg_df
                result["aggregated_rows"] = len(agg_df)
                result["aggregations_applied"]["group_based"] = {
                    "groups": valid_groups,
                    "functions": aggregations
                }
                
                # Calculate group statistics
                for group in valid_groups:
                    unique_values = df[group].nunique()
                    result["group_statistics"][group] = {
                        "unique_values": unique_values,
                        "most_common": df[group].value_counts().head(5).to_dict() if unique_values <= 100 else None,
                        "coverage": (df[group].notna().sum() / len(df)) * 100
                    }
        
        else:
            # No grouping, aggregate entire dataset
            agg_result = {}
            for col, funcs in aggregations.items():
                if col in df.columns:
                    if isinstance(funcs, list):
                        for func in funcs:
                            agg_result[f"{col}_{func}"] = df[col].agg(func)
                    else:
                        agg_result[f"{col}_{funcs}"] = df[col].agg(funcs)
            
            result["aggregated_data"] = pd.DataFrame([agg_result])
            result["aggregated_rows"] = 1
            result["aggregations_applied"]["global"] = aggregations
        
        # [LLM_CUSTOMIZE: custom_metrics]
        # Add custom metrics calculation
        {custom_metrics}
        
        # Add summary statistics
        if result["aggregated_data"] is not None:
            numeric_cols = result["aggregated_data"].select_dtypes(include=[np.number]).columns
            
            if len(numeric_cols) > 0:
                result["summary_statistics"] = {
                    "numeric_columns": len(numeric_cols),
                    "compression_ratio": result["original_rows"] / result["aggregated_rows"] if result["aggregated_rows"] > 0 else 0,
                    "column_stats": {}
                }
                
                for col in numeric_cols[:10]:  # Limit to first 10 columns
                    result["summary_statistics"]["column_stats"][col] = {
                        "min": float(result["aggregated_data"][col].min()),
                        "max": float(result["aggregated_data"][col].max()),
                        "mean": float(result["aggregated_data"][col].mean()),
                        "std": float(result["aggregated_data"][col].std()) if len(result["aggregated_data"]) > 1 else 0
                    }
        
        # Add insights
        insights = []
        
        if result["aggregated_rows"] > 0:
            compression = result["original_rows"] / result["aggregated_rows"]
            if compression > 10:
                insights.append(f"High data compression achieved: {compression:.1f}x reduction")
            
            if group_by and result["group_statistics"]:
                for group, stats in result["group_statistics"].items():
                    if stats["unique_values"] < 10:
                        insights.append(f"Low cardinality in {group}: {stats['unique_values']} unique values")
        
        if result["time_series"] is not None:
            # Time series insights
            if len(result["time_series"]) > 0:
                numeric_cols = result["time_series"].select_dtypes(include=[np.number]).columns
                for col in numeric_cols[:3]:  # First 3 columns
                    trend = result["time_series"][col].pct_change().mean()
                    if abs(trend) > 0.1:
                        direction = "increasing" if trend > 0 else "decreasing"
                        insights.append(f"{col} shows {direction} trend: {trend*100:.1f}% average change")
        
        result["insights"] = insights
        result["success"] = True
        
        logger.info(f"Data aggregation completed: {result['aggregated_rows']} groups from {result['original_rows']} rows")
        return result
        
    except Exception as e:
        logger.error(f"Data aggregation failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''