"""
Text Summarization Template
"""

TEMPLATE_INFO = {
    "id": "ml_ai.text_summarization",
    "name": "Text Summarization",
    "category": "ml_ai",
    "version": "1.0.0",
    "llm_customizable": ["summarization_strategy", "length_control", "key_points_extraction"]
}

def get_text_summarization():
    """텍스트 요약 함수 템플릿"""
    return '''
async def _summarize_text(
    self,
    text: Union[str, List[str], pd.DataFrame],
    text_column: Optional[str] = None,
    summary_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Summarize text content.
    
    Args:
        text: Text to summarize
        text_column: Column name if DataFrame
        summary_options: Summarization configuration
    
    Returns:
        Tuple[summary results, metadata]
    """
    metadata = {
        "operation": "text_summarization",
        "processed_at": datetime.now().isoformat()
    }
    
    try:
        # Default options
        default_options = {
            "max_length": 150,
            "min_length": 30,
            "method": "extractive",  # extractive, abstractive
            "num_sentences": 3,
            "language": "auto"
        }
        
        if summary_options:
            default_options.update(summary_options)
        
        # Prepare text
        if isinstance(text, pd.DataFrame):
            if text_column:
                texts = text[text_column].tolist()
            else:
                texts = text.iloc[:, 0].tolist()
        elif isinstance(text, list):
            texts = text
        else:
            texts = [text]
        
        result = {
            "summaries": [],
            "key_points": [],
            "statistics": {}
        }
        
        # [LLM_CUSTOMIZE: summarization_strategy]
        # Choose summarization strategy
        for idx, content in enumerate(texts):
            if not content or not isinstance(content, str):
                result["summaries"].append("")
                continue
            
            # Clean text
            content = ' '.join(content.split())
            original_length = len(content.split())
            
            if default_options["method"] == "extractive":
                try:
                    # Use sumy for extractive summarization
                    from sumy.parsers.plaintext import PlaintextParser
                    from sumy.nlp.tokenizers import Tokenizer
                    from sumy.summarizers.lsa import LsaSummarizer
                    from sumy.nlp.stemmers import Stemmer
                    from sumy.utils import get_stop_words
                    
                    # Detect language
                    language = "english"  # Default
                    if any(ord(char) > 127 for char in content[:100]):
                        # Contains non-ASCII, might be Korean
                        language = "korean"
                    
                    parser = PlaintextParser.from_string(content, Tokenizer(language))
                    stemmer = Stemmer(language)
                    summarizer = LsaSummarizer(stemmer)
                    
                    summary_sentences = summarizer(
                        parser.document, 
                        default_options["num_sentences"]
                    )
                    
                    summary = ' '.join([str(sentence) for sentence in summary_sentences])
                    
                except ImportError:
                    # Fallback to simple extractive method
                    sentences = content.split('. ')
                    if len(sentences) > default_options["num_sentences"]:
                        # Take first and last sentences and one from middle
                        summary = '. '.join([
                            sentences[0],
                            sentences[len(sentences)//2],
                            sentences[-1]
                        ])
                    else:
                        summary = content[:default_options["max_length"]]
                        
            else:  # abstractive
                try:
                    from transformers import pipeline
                    
                    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
                    summary_result = summarizer(
                        content,
                        max_length=default_options["max_length"],
                        min_length=default_options["min_length"],
                        do_sample=False
                    )
                    summary = summary_result[0]["summary_text"]
                    
                except ImportError:
                    # Fallback to simple method
                    words = content.split()
                    if len(words) > default_options["max_length"]:
                        summary = ' '.join(words[:default_options["max_length"]]) + "..."
                    else:
                        summary = content
            
            {summarization_strategy}
            
            result["summaries"].append(summary)
            
            # [LLM_CUSTOMIZE: key_points_extraction]
            # Extract key points
            # Simple keyword extraction
            from collections import Counter
            import re
            
            # Remove common words
            stop_words = {"the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", 
                         "of", "with", "by", "is", "was", "are", "were", "been", "be",
                         "이", "그", "저", "것", "등", "및", "을", "를", "에", "의"}
            
            words = re.findall(r'\w+', content.lower())
            filtered_words = [w for w in words if w not in stop_words and len(w) > 3]
            word_freq = Counter(filtered_words)
            key_words = [word for word, _ in word_freq.most_common(5)]
            
            result["key_points"].append({
                "index": idx,
                "keywords": key_words,
                "original_length": original_length,
                "summary_length": len(summary.split())
            })
            
            {key_points_extraction}
        
        # [LLM_CUSTOMIZE: length_control]
        # Calculate statistics
        result["statistics"] = {
            "total_documents": len(texts),
            "average_compression_ratio": sum(
                len(s.split()) / len(t.split()) 
                for s, t in zip(result["summaries"], texts) 
                if t and s
            ) / len(texts) if texts else 0,
            "total_summaries": len([s for s in result["summaries"] if s])
        }
        {length_control}
        
        # Update metadata
        metadata.update({
            "documents_processed": len(texts),
            "summarization_method": default_options["method"],
            "target_length": default_options["max_length"]
        })
        
        logger.info(f"Text summarization completed: {len(texts)} documents")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Text summarization failed: {e}")
        raise
'''