"""
Text Classification Template
"""

TEMPLATE_INFO = {
    "id": "ml_ai.text_classification",
    "name": "Text Classification",
    "category": "ml_ai",
    "version": "1.0.0",
    "llm_customizable": ["preprocessing", "model_selection", "postprocessing"]
}

def get_text_classification():
    """텍스트 분류 함수 템플릿"""
    return '''
async def _classify_text(
    self,
    texts: List[str],
    model_type: str = "sentiment",
    custom_categories: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Classify text into categories.
    
    Args:
        texts: List of texts to classify
        model_type: Type of classification (sentiment, topic, intent, custom)
        custom_categories: Custom category labels for custom classification
    
    Returns:
        Dict with classification results including predictions and confidence
    """
    result = {
        "model_type": model_type,
        "predictions": [],
        "confidence_scores": [],
        "model_info": {},
        "summary": {},
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        # Validate input
        if not texts:
            raise ValueError("No texts provided for classification")
        
        # [LLM_CUSTOMIZE: preprocessing]
        # Add text preprocessing (cleaning, normalization, etc.)
        {preprocessing}
        
        # Clean texts
        cleaned_texts = []
        for text in texts:
            # Basic cleaning
            if text is None:
                cleaned_text = ""
            else:
                cleaned_text = str(text).strip()
            cleaned_texts.append(cleaned_text)
        
        # Classification based on model type
        if model_type == "sentiment":
            # Sentiment analysis
            try:
                from transformers import pipeline
                classifier = pipeline(
                    "sentiment-analysis",
                    model="distilbert-base-uncased-finetuned-sst-2-english",
                    device=-1  # CPU
                )
                
                # Process in batches for efficiency
                batch_size = 32
                all_predictions = []
                
                for i in range(0, len(cleaned_texts), batch_size):
                    batch = cleaned_texts[i:i+batch_size]
                    # Truncate long texts
                    batch = [text[:512] if len(text) > 512 else text for text in batch]
                    predictions = classifier(batch)
                    all_predictions.extend(predictions)
                
                for pred in all_predictions:
                    # Map labels to standard format
                    label = pred['label']
                    if label == 'POSITIVE':
                        result["predictions"].append('positive')
                    elif label == 'NEGATIVE':
                        result["predictions"].append('negative')
                    else:
                        result["predictions"].append(label.lower())
                    
                    result["confidence_scores"].append(pred['score'])
                
                result["model_info"] = {
                    "type": "sentiment",
                    "model": "distilbert-base-uncased-finetuned-sst-2-english",
                    "categories": ["positive", "negative"]
                }
                
            except ImportError:
                # Fallback to simple rule-based sentiment
                logger.warning("Transformers not available, using rule-based sentiment")
                
                positive_words = ["good", "great", "excellent", "amazing", "wonderful", "fantastic", "love", "best"]
                negative_words = ["bad", "terrible", "awful", "horrible", "worst", "hate", "disappointed", "poor"]
                
                for text in cleaned_texts:
                    text_lower = text.lower()
                    pos_count = sum(1 for word in positive_words if word in text_lower)
                    neg_count = sum(1 for word in negative_words if word in text_lower)
                    
                    if pos_count > neg_count:
                        result["predictions"].append("positive")
                        confidence = min(0.5 + (pos_count * 0.1), 0.95)
                    elif neg_count > pos_count:
                        result["predictions"].append("negative")
                        confidence = min(0.5 + (neg_count * 0.1), 0.95)
                    else:
                        result["predictions"].append("neutral")
                        confidence = 0.5
                    
                    result["confidence_scores"].append(confidence)
                
                result["model_info"] = {
                    "type": "sentiment",
                    "model": "rule-based",
                    "categories": ["positive", "negative", "neutral"]
                }
        
        elif model_type == "intent":
            # Intent classification
            # [LLM_CUSTOMIZE: model_selection]
            # Add intent classification logic
            {model_selection}
            
            # Fallback intent detection
            intents = {
                "question": ["what", "why", "how", "when", "where", "who", "?"],
                "request": ["please", "could", "would", "can", "help", "need"],
                "statement": ["is", "are", "was", "were", ".", "!"],
                "greeting": ["hello", "hi", "hey", "good morning", "good afternoon"],
                "goodbye": ["bye", "goodbye", "see you", "later", "farewell"]
            }
            
            for text in cleaned_texts:
                text_lower = text.lower()
                scores = {}
                
                for intent, keywords in intents.items():
                    score = sum(1 for kw in keywords if kw in text_lower)
                    scores[intent] = score
                
                if max(scores.values()) == 0:
                    result["predictions"].append("statement")
                    result["confidence_scores"].append(0.5)
                else:
                    best_intent = max(scores, key=scores.get)
                    result["predictions"].append(best_intent)
                    confidence = min(0.5 + (scores[best_intent] * 0.15), 0.95)
                    result["confidence_scores"].append(confidence)
            
            result["model_info"] = {
                "type": "intent",
                "model": "keyword-based",
                "categories": list(intents.keys())
            }
        
        elif model_type == "custom" and custom_categories:
            # Custom classification based on provided categories
            # Simple keyword-based approach
            for text in cleaned_texts:
                text_lower = text.lower()
                scores = {}
                
                for category in custom_categories:
                    # Check if category keywords appear in text
                    category_lower = category.lower()
                    score = 1 if category_lower in text_lower else 0
                    scores[category] = score
                
                if max(scores.values()) == 0:
                    # No match, assign first category with low confidence
                    result["predictions"].append(custom_categories[0])
                    result["confidence_scores"].append(0.3)
                else:
                    best_category = max(scores, key=scores.get)
                    result["predictions"].append(best_category)
                    result["confidence_scores"].append(0.7)
            
            result["model_info"] = {
                "type": "custom",
                "model": "keyword-matching",
                "categories": custom_categories
            }
        
        else:
            raise ValueError(f"Unsupported model type: {model_type}")
        
        # [LLM_CUSTOMIZE: postprocessing]
        # Add postprocessing logic
        {postprocessing}
        
        # Calculate summary statistics
        from collections import Counter
        label_counts = Counter(result["predictions"])
        
        result["summary"] = {
            "total_texts": len(texts),
            "unique_labels": len(label_counts),
            "label_distribution": dict(label_counts),
            "average_confidence": np.mean(result["confidence_scores"]) if result["confidence_scores"] else 0,
            "min_confidence": min(result["confidence_scores"]) if result["confidence_scores"] else 0,
            "max_confidence": max(result["confidence_scores"]) if result["confidence_scores"] else 0
        }
        
        # Add percentage distribution
        total = len(result["predictions"])
        result["summary"]["label_percentages"] = {
            label: (count / total * 100) for label, count in label_counts.items()
        }
        
        logger.info(f"Text classification completed: {len(texts)} texts classified as {model_type}")
        return result
        
    except ValueError as e:
        logger.warning(f"Text classification validation error: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
        
    except Exception as e:
        logger.error(f"Text classification failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''