"""
Sentiment Analysis Template
"""

TEMPLATE_INFO = {
    "id": "ml_ai.sentiment_analysis",
    "name": "Sentiment Analysis",
    "category": "ml_ai",
    "version": "1.0.0",
    "llm_customizable": ["model_selection", "preprocessing", "result_interpretation"]
}

def get_sentiment_analysis():
    """감정 분석 함수 템플릿"""
    return '''
async def _analyze_sentiment(
    self,
    texts: Union[str, List[str], pd.DataFrame],
    text_column: Optional[str] = None,
    analysis_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Perform sentiment analysis on text data.
    
    Args:
        texts: Text data to analyze
        text_column: Column name if DataFrame
        analysis_options: Analysis configuration
    
    Returns:
        Tuple[sentiment results, metadata]
    """
    metadata = {
        "analysis_type": "sentiment",
        "analyzed_at": datetime.now().isoformat()
    }
    
    try:
        # Default options
        default_options = {
            "language": "auto",  # auto, en, ko, etc.
            "model_type": "transformers",  # transformers, textblob, vader
            "include_scores": True,
            "include_emotions": False,
            "batch_size": 32
        }
        
        if analysis_options:
            default_options.update(analysis_options)
        
        # Prepare text list
        if isinstance(texts, str):
            text_list = [texts]
        elif isinstance(texts, pd.DataFrame):
            if text_column:
                text_list = texts[text_column].tolist()
            else:
                # Find first string column
                str_cols = texts.select_dtypes(include=['object']).columns
                if len(str_cols) > 0:
                    text_list = texts[str_cols[0]].tolist()
                else:
                    raise ValueError("No text column found in DataFrame")
        else:
            text_list = texts
        
        # [LLM_CUSTOMIZE: preprocessing]
        # Preprocess texts
        processed_texts = []
        for text in text_list:
            if text and isinstance(text, str):
                # Basic cleaning
                text = text.strip()
                # Remove excessive whitespace
                text = ' '.join(text.split())
                processed_texts.append(text)
            else:
                processed_texts.append("")
        {preprocessing}
        
        result = {
            "sentiments": [],
            "summary": {},
            "distribution": {},
            "details": []
        }
        
        # [LLM_CUSTOMIZE: model_selection]
        # Select and apply sentiment analysis model
        if default_options["model_type"] == "transformers":
            try:
                from transformers import pipeline
                
                # Initialize sentiment pipeline
                if default_options["language"] == "ko":
                    sentiment_pipeline = pipeline(
                        "sentiment-analysis",
                        model="nlptown/bert-base-multilingual-uncased-sentiment"
                    )
                else:
                    sentiment_pipeline = pipeline("sentiment-analysis")
                
                # Process in batches
                batch_size = default_options["batch_size"]
                for i in range(0, len(processed_texts), batch_size):
                    batch = processed_texts[i:i+batch_size]
                    if batch:
                        batch_results = sentiment_pipeline(batch)
                        
                        for text, res in zip(batch, batch_results):
                            sentiment_data = {
                                "text": text[:100] + "..." if len(text) > 100 else text,
                                "sentiment": res["label"],
                                "confidence": res["score"]
                            }
                            
                            # Map to standard sentiment labels
                            if "positive" in res["label"].lower() or "5" in res["label"]:
                                sentiment = "positive"
                            elif "negative" in res["label"].lower() or "1" in res["label"]:
                                sentiment = "negative"
                            else:
                                sentiment = "neutral"
                            
                            sentiment_data["normalized_sentiment"] = sentiment
                            result["sentiments"].append(sentiment)
                            result["details"].append(sentiment_data)
                
            except ImportError:
                # Fallback to TextBlob
                default_options["model_type"] = "textblob"
        
        if default_options["model_type"] == "textblob":
            try:
                from textblob import TextBlob
                
                for text in processed_texts:
                    if text:
                        blob = TextBlob(text)
                        polarity = blob.sentiment.polarity
                        subjectivity = blob.sentiment.subjectivity
                        
                        # Determine sentiment
                        if polarity > 0.1:
                            sentiment = "positive"
                        elif polarity < -0.1:
                            sentiment = "negative"
                        else:
                            sentiment = "neutral"
                        
                        sentiment_data = {
                            "text": text[:100] + "..." if len(text) > 100 else text,
                            "sentiment": sentiment,
                            "polarity": polarity,
                            "subjectivity": subjectivity,
                            "confidence": abs(polarity)
                        }
                        
                        result["sentiments"].append(sentiment)
                        result["details"].append(sentiment_data)
                    else:
                        result["sentiments"].append("neutral")
                        result["details"].append({"text": "", "sentiment": "neutral"})
                        
            except ImportError:
                # Simple rule-based fallback
                positive_words = ["good", "great", "excellent", "happy", "love", "좋다", "훌륭하다", "행복하다"]
                negative_words = ["bad", "terrible", "hate", "sad", "awful", "나쁘다", "싫다", "슬프다"]
                
                for text in processed_texts:
                    text_lower = text.lower()
                    pos_count = sum(1 for word in positive_words if word in text_lower)
                    neg_count = sum(1 for word in negative_words if word in text_lower)
                    
                    if pos_count > neg_count:
                        sentiment = "positive"
                    elif neg_count > pos_count:
                        sentiment = "negative"
                    else:
                        sentiment = "neutral"
                    
                    result["sentiments"].append(sentiment)
                    result["details"].append({
                        "text": text[:100] + "..." if len(text) > 100 else text,
                        "sentiment": sentiment,
                        "method": "rule_based"
                    })
        
        {model_selection}
        
        # [LLM_CUSTOMIZE: result_interpretation]
        # Calculate summary statistics
        sentiment_counts = pd.Series(result["sentiments"]).value_counts()
        total = len(result["sentiments"])
        
        result["distribution"] = {
            "positive": int(sentiment_counts.get("positive", 0)),
            "negative": int(sentiment_counts.get("negative", 0)),
            "neutral": int(sentiment_counts.get("neutral", 0))
        }
        
        result["summary"] = {
            "total_texts": total,
            "overall_sentiment": sentiment_counts.idxmax() if not sentiment_counts.empty else "neutral",
            "positive_ratio": sentiment_counts.get("positive", 0) / total if total > 0 else 0,
            "negative_ratio": sentiment_counts.get("negative", 0) / total if total > 0 else 0,
            "neutral_ratio": sentiment_counts.get("neutral", 0) / total if total > 0 else 0
        }
        
        # Add emotion detection if requested
        if default_options["include_emotions"]:
            # Simple emotion keywords
            emotions = {
                "joy": ["happy", "joy", "excited", "기쁘다", "즐겁다"],
                "anger": ["angry", "mad", "furious", "화나다", "분노"],
                "sadness": ["sad", "depressed", "unhappy", "슬프다", "우울하다"],
                "fear": ["afraid", "scared", "worried", "무섭다", "걱정"],
                "surprise": ["surprised", "amazed", "shocked", "놀라다", "충격"]
            }
            
            for detail in result["details"]:
                text_lower = detail.get("text", "").lower()
                detected_emotions = []
                for emotion, keywords in emotions.items():
                    if any(keyword in text_lower for keyword in keywords):
                        detected_emotions.append(emotion)
                detail["emotions"] = detected_emotions if detected_emotions else ["neutral"]
        
        {result_interpretation}
        
        # Update metadata
        metadata.update({
            "texts_analyzed": total,
            "model_used": default_options["model_type"],
            "language": default_options["language"],
            "sentiment_distribution": result["distribution"]
        })
        
        logger.info(f"Sentiment analysis completed: {total} texts analyzed")
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Sentiment analysis failed: {e}")
        raise
'''