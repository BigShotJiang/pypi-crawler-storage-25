"""desktop/ui_control — Accessibility API button clicks."""

TEMPLATE_INFO = {
    "id": "desktop.ui_control",
    "name": "UI Control",
    "category": "desktop",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio"],
    "llm_customizable": [],
}


def get_click_ui_button():
    return '''
async def _click_ui_button(self, app_name: str, button_description: str) -> bool:
    """Click a button in app using macOS Accessibility API (description matching)."""
    import subprocess, asyncio
    script = f"""
    tell application "System Events"
        tell process "{app_name}"
            set frontmost to true
            delay 0.3
            try
                set allButtons to every button of window 1
                repeat with btn in allButtons
                    if description of btn contains "{button_description}" then
                        click btn
                        return "clicked"
                    end if
                end repeat
                return "not_found"
            on error errMsg
                return "error:" & errMsg
            end try
        end tell
    end tell
    """
    try:
        result = await asyncio.to_thread(
            subprocess.run, ["osascript", "-e", script],
            capture_output=True, text=True, timeout=10)
        return "clicked" in result.stdout
    except Exception:
        return False
'''


def get_click_tab_by_index():
    return '''
async def _click_tab_by_index(self, app_name: str, tab_index: int = 1, group_index: int = 1) -> bool:
    """Click Nth button in app sidebar (used for tabs like Friends/Chats in KakaoTalk)."""
    import subprocess, asyncio
    script = f"""
    tell application "System Events"
        tell process "{app_name}"
            set frontmost to true
            delay 0.3
            try
                click button {tab_index} of group {group_index} of window 1
                return "clicked"
            on error errMsg
                return "error:" & errMsg
            end try
        end tell
    end tell
    """
    try:
        result = await asyncio.to_thread(
            subprocess.run, ["osascript", "-e", script],
            capture_output=True, text=True, timeout=10)
        return "clicked" in result.stdout
    except Exception:
        return False
'''
