"""desktop/app_control — App activation, opening, closing, switching."""

TEMPLATE_INFO = {
    "id": "desktop.app_control",
    "name": "App Control",
    "category": "desktop",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio"],
    "llm_customizable": ["app_aliases"],
}


def get_activate_app():
    return '''
async def _activate_app(self, app_name: str) -> bool:
    """Activate (bring to front) a macOS application via AppleScript."""
    import subprocess
    try:
        subprocess.run(
            ["osascript", "-e", f'tell application "{app_name}" to activate'],
            capture_output=True, text=True, timeout=5
        )
        return True
    except Exception:
        return False
'''


def get_close_app():
    return '''
async def _close_app(self, app_name: str = None) -> bool:
    """Close frontmost window (Cmd+W) without quitting the app."""
    import subprocess
    script = 'tell application "System Events" to keystroke "w" using command down'
    try:
        subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=5)
        return True
    except Exception:
        return False
'''


def get_switch_app():
    return '''
async def _switch_app(self, app_name: str) -> bool:
    """Switch to a specific app (restore previous app after task)."""
    import subprocess
    if not app_name:
        return False
    try:
        subprocess.run(
            ["osascript", "-e", f'tell application "{app_name}" to activate'],
            capture_output=True, text=True, timeout=5
        )
        return True
    except Exception:
        return False
'''


def get_open_app():
    return '''
async def _open_app(self, app_name: str) -> bool:
    """Open a macOS app by name (supports Korean aliases)."""
    import subprocess

    # [LLM_CUSTOMIZE: app_aliases]
    aliases = {
        "크롬": "Google Chrome", "카카오톡": "KakaoTalk", "엑셀": "Microsoft Excel",
        "워드": "Microsoft Word", "파워포인트": "Microsoft PowerPoint",
        "메일": "Mail", "파인더": "Finder", "터미널": "Terminal",
    }
    {app_aliases}

    resolved = aliases.get(app_name, app_name)
    try:
        subprocess.Popen(["open", "-a", resolved], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False
'''
