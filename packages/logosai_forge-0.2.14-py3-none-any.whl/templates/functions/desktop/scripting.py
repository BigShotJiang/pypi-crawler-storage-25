"""desktop/scripting — AppleScript execution + Chrome JS injection."""

TEMPLATE_INFO = {
    "id": "desktop.scripting",
    "name": "Scripting",
    "category": "desktop",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio"],
    "llm_customizable": [],
}


def get_run_applescript():
    return '''
async def _run_applescript(self, script: str) -> str:
    """Execute AppleScript and return result string."""
    import subprocess, asyncio
    try:
        result = await asyncio.to_thread(
            subprocess.run, ["osascript", "-e", script],
            capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            return result.stdout.strip()
        return f"ERROR:{result.stderr.strip()}"
    except subprocess.TimeoutExpired:
        return "ERROR:timeout"
    except Exception as e:
        return f"ERROR:{e}"
'''


def get_chrome_execute_js():
    return '''
async def _chrome_execute_js(self, javascript: str, tab_pattern: str = "mail.google.com") -> str:
    """Execute JavaScript in a specific Chrome tab (matched by URL pattern)."""
    import subprocess, asyncio

    escaped_js = javascript.replace("\\\\", "\\\\\\\\").replace('"', '\\\\"').replace("\\n", "\\\\n")
    script = f"""
    tell application "Google Chrome"
        set found to false
        repeat with w in windows
            repeat with t in tabs of w
                if URL of t contains "{tab_pattern}" then
                    set found to true
                    tell t to set result to execute javascript "{escaped_js}"
                    return result
                end if
            end repeat
        end repeat
        if not found then return "TAB_NOT_FOUND"
    end tell
    """
    try:
        result = await asyncio.to_thread(
            subprocess.run, ["osascript", "-e", script],
            capture_output=True, text=True, timeout=10)
        return result.stdout.strip() if result.returncode == 0 else f"ERROR:{result.stderr.strip()}"
    except Exception as e:
        return f"ERROR:{e}"
'''
