# desktop — macOS desktop automation function templates
