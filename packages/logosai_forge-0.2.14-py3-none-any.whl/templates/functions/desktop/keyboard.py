"""desktop/keyboard — Key press, paste, hotkey, click via Peekaboo CLI."""

TEMPLATE_INFO = {
    "id": "desktop.keyboard",
    "name": "Keyboard & Mouse",
    "category": "desktop",
    "version": "1.0.0",
    "platform": "macos",
    "runtime": "acp_server",
    "required_imports": ["subprocess", "asyncio"],
    "external_dependencies": ["Peekaboo CLI (/usr/local/bin/peekaboo)"],
    "llm_customizable": [],
}


def get_press_key():
    return '''
async def _press_key(self, key: str, app: str = None) -> bool:
    """Press a key (enter, escape, down, up, tab, etc.) via Peekaboo CLI."""
    import subprocess, asyncio
    cmd = f"peekaboo press {key}"
    if app:
        cmd += f' --app "{app}"'
    try:
        result = await asyncio.to_thread(
            subprocess.run, cmd, shell=True, capture_output=True, text=True, timeout=5)
        return result.returncode == 0
    except Exception:
        return False
'''


def get_paste_text():
    return '''
async def _paste_text(self, text: str, app: str = None) -> bool:
    """Paste text via clipboard (supports Korean/non-ASCII). Uses Peekaboo CLI."""
    import subprocess, asyncio
    cmd = f'peekaboo paste "{text}"'
    if app:
        cmd += f' --app "{app}"'
    try:
        result = await asyncio.to_thread(
            subprocess.run, cmd, shell=True, capture_output=True, text=True, timeout=10)
        return result.returncode == 0
    except Exception:
        return False
'''


def get_hotkey():
    return '''
async def _hotkey(self, keys: str, app: str = None) -> bool:
    """Press key combination (e.g., 'command+c', 'command+shift+s') via Peekaboo CLI."""
    import subprocess, asyncio
    cmd = f"peekaboo hotkey {keys}"
    if app:
        cmd += f' --app "{app}"'
    try:
        result = await asyncio.to_thread(
            subprocess.run, cmd, shell=True, capture_output=True, text=True, timeout=5)
        return result.returncode == 0
    except Exception:
        return False
'''


def get_click_at():
    return '''
async def _click_at(self, x: int, y: int, double: bool = False, app: str = None) -> bool:
    """Click at screen coordinates via Peekaboo CLI."""
    import subprocess, asyncio
    cmd = f"peekaboo click --coords {x},{y}"
    if double:
        cmd += " --double"
    if app:
        cmd += f' --app "{app}"'
    try:
        result = await asyncio.to_thread(
            subprocess.run, cmd, shell=True, capture_output=True, text=True, timeout=5)
        return result.returncode == 0
    except Exception:
        return False
'''
