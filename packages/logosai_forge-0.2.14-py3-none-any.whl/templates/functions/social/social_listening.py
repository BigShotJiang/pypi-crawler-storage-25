"""
Social Media Listening Function Templates
"""

def get_social_monitor():
    """Template for social media monitoring"""
    return '''
async def _monitor_social_media(self, platforms: List[str], keywords: List[str], options: Optional[Dict] = None) -> Dict[str, Any]:
    """
    Monitor social media platforms for keywords and mentions
    
    Args:
        platforms: List of platforms to monitor (e.g., ['twitter', 'instagram', 'facebook'])
        keywords: List of keywords to track
        options: Optional configuration (date_range, limit, etc.)
    
    Returns:
        Dict containing posts, mentions, and metadata
    """
    
    result = {
        "posts": [],
        "mentions": [],
        "metadata": {
            "platforms_monitored": platforms,
            "keywords_tracked": keywords,
            "timestamp": datetime.now().isoformat(),
            "total_found": 0
        }
    }
    
    try:
        logger.info(f"Starting social media monitoring for platforms: {platforms}")
        logger.info(f"Tracking keywords: {keywords}")
        
        # Configure monitoring options
        date_range = options.get("date_range", "24h") if options else "24h"
        limit = options.get("limit", 100) if options else 100
        
        # Monitor each platform
        for platform in platforms:
            platform_lower = platform.lower()
            logger.info(f"Monitoring {platform}...")
            
            if platform_lower == "twitter":
                # Twitter monitoring logic
                twitter_posts = await self._monitor_twitter(keywords, date_range, limit)
                result["posts"].extend(twitter_posts)
                
            elif platform_lower == "instagram":
                # Instagram monitoring logic
                instagram_posts = await self._monitor_instagram(keywords, date_range, limit)
                result["posts"].extend(instagram_posts)
                
            elif platform_lower == "facebook":
                # Facebook monitoring logic
                facebook_posts = await self._monitor_facebook(keywords, date_range, limit)
                result["posts"].extend(facebook_posts)
                
            elif platform_lower == "reddit":
                # Reddit monitoring logic
                reddit_posts = await self._monitor_reddit(keywords, date_range, limit)
                result["posts"].extend(reddit_posts)
            
            else:
                logger.warning(f"Platform {platform} not supported yet")
        
        # Extract mentions from posts
        result["mentions"] = self._extract_mentions(result["posts"], keywords)
        
        # Update metadata
        result["metadata"]["total_found"] = len(result["posts"])
        result["metadata"]["mentions_count"] = len(result["mentions"])
        result["metadata"]["engagement_metrics"] = self._calculate_engagement(result["posts"])
        
        logger.info(f"Monitoring completed. Found {result['metadata']['total_found']} posts")
        return result
        
    except Exception as e:
        logger.error(f"Social media monitoring failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result

async def _monitor_twitter(self, keywords: List[str], date_range: str, limit: int) -> List[Dict]:
    """Monitor Twitter for keywords"""
    # Placeholder for Twitter API integration
    return [
        {
            "platform": "twitter",
            "id": f"tweet_{i}",
            "text": f"Sample tweet containing {keywords[0]}",
            "author": f"user_{i}",
            "timestamp": datetime.now().isoformat(),
            "engagement": {"likes": 10 * i, "retweets": 5 * i, "replies": 2 * i},
            "url": f"https://twitter.com/user_{i}/status/{i}"
        }
        for i in range(min(5, limit))
    ]

async def _monitor_instagram(self, keywords: List[str], date_range: str, limit: int) -> List[Dict]:
    """Monitor Instagram for keywords"""
    # Placeholder for Instagram API integration
    return []

async def _monitor_facebook(self, keywords: List[str], date_range: str, limit: int) -> List[Dict]:
    """Monitor Facebook for keywords"""
    # Placeholder for Facebook Graph API integration
    return []

async def _monitor_reddit(self, keywords: List[str], date_range: str, limit: int) -> List[Dict]:
    """Monitor Reddit for keywords"""
    # Placeholder for Reddit API integration
    return []

def _extract_mentions(self, posts: List[Dict], keywords: List[str]) -> List[Dict]:
    """Extract mentions from posts"""
    mentions = []
    for post in posts:
        text = post.get("text", "").lower()
        for keyword in keywords:
            if keyword.lower() in text:
                mentions.append({
                    "keyword": keyword,
                    "post_id": post.get("id"),
                    "platform": post.get("platform"),
                    "author": post.get("author"),
                    "timestamp": post.get("timestamp")
                })
    return mentions

def _calculate_engagement(self, posts: List[Dict]) -> Dict:
    """Calculate engagement metrics"""
    total_likes = sum(post.get("engagement", {}).get("likes", 0) for post in posts)
    total_shares = sum(post.get("engagement", {}).get("retweets", 0) + 
                      post.get("engagement", {}).get("shares", 0) for post in posts)
    total_comments = sum(post.get("engagement", {}).get("replies", 0) + 
                        post.get("engagement", {}).get("comments", 0) for post in posts)
    
    return {
        "total_likes": total_likes,
        "total_shares": total_shares,
        "total_comments": total_comments,
        "engagement_rate": (total_likes + total_shares + total_comments) / max(len(posts), 1)
    }
'''


def get_sentiment_analyzer():
    """Template for sentiment analysis"""
    return '''
async def _analyze_sentiment(self, texts: List[str], context: Optional[str] = None) -> Dict[str, Any]:
    """
    Analyze sentiment of social media posts
    
    Args:
        texts: List of texts to analyze
        context: Optional context for better analysis
    
    Returns:
        Dict containing sentiment_scores, overall_sentiment, emotions
    """
    
    result = {
        "sentiment_scores": [],
        "overall_sentiment": "neutral",
        "emotions": {},
        "summary": {}
    }
    
    try:
        logger.info(f"Analyzing sentiment for {len(texts)} texts")
        
        positive_count = 0
        negative_count = 0
        neutral_count = 0
        
        for text in texts:
            # Simple sentiment analysis (replace with actual NLP model)
            sentiment = self._calculate_sentiment(text)
            
            result["sentiment_scores"].append({
                "text": text[:100] + "..." if len(text) > 100 else text,
                "sentiment": sentiment["label"],
                "score": sentiment["score"],
                "emotions": sentiment.get("emotions", {})
            })
            
            # Count sentiments
            if sentiment["label"] == "positive":
                positive_count += 1
            elif sentiment["label"] == "negative":
                negative_count += 1
            else:
                neutral_count += 1
        
        # Calculate overall sentiment
        total = len(texts)
        if total > 0:
            if positive_count > negative_count and positive_count > neutral_count:
                result["overall_sentiment"] = "positive"
            elif negative_count > positive_count and negative_count > neutral_count:
                result["overall_sentiment"] = "negative"
            else:
                result["overall_sentiment"] = "neutral"
        
        # Summary statistics
        result["summary"] = {
            "total_analyzed": total,
            "positive": positive_count,
            "negative": negative_count,
            "neutral": neutral_count,
            "positive_percentage": (positive_count / total * 100) if total > 0 else 0,
            "negative_percentage": (negative_count / total * 100) if total > 0 else 0,
            "neutral_percentage": (neutral_count / total * 100) if total > 0 else 0
        }
        
        # Aggregate emotions
        result["emotions"] = self._aggregate_emotions(result["sentiment_scores"])
        
        logger.info(f"Sentiment analysis completed. Overall: {result['overall_sentiment']}")
        return result
        
    except Exception as e:
        logger.error(f"Sentiment analysis failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result

def _calculate_sentiment(self, text: str) -> Dict:
    """Calculate sentiment for a single text"""
    # Placeholder for actual sentiment calculation
    # In production, use TextBlob, VADER, or transformers
    
    positive_words = ["good", "great", "excellent", "love", "amazing", "best", "happy", "wonderful"]
    negative_words = ["bad", "terrible", "hate", "worst", "awful", "horrible", "sad", "angry"]
    
    text_lower = text.lower()
    positive_score = sum(1 for word in positive_words if word in text_lower)
    negative_score = sum(1 for word in negative_words if word in text_lower)
    
    if positive_score > negative_score:
        return {
            "label": "positive",
            "score": min(positive_score / 10, 1.0),
            "emotions": {"joy": 0.7, "trust": 0.3}
        }
    elif negative_score > positive_score:
        return {
            "label": "negative",
            "score": min(negative_score / 10, 1.0),
            "emotions": {"anger": 0.5, "sadness": 0.5}
        }
    else:
        return {
            "label": "neutral",
            "score": 0.5,
            "emotions": {"neutral": 1.0}
        }

def _aggregate_emotions(self, sentiment_scores: List[Dict]) -> Dict:
    """Aggregate emotions from all texts"""
    emotion_counts = {}
    for score in sentiment_scores:
        for emotion, value in score.get("emotions", {}).items():
            if emotion not in emotion_counts:
                emotion_counts[emotion] = 0
            emotion_counts[emotion] += value
    
    # Normalize
    total = sum(emotion_counts.values())
    if total > 0:
        return {emotion: count/total for emotion, count in emotion_counts.items()}
    return emotion_counts
'''


def get_crisis_detector():
    """Template for crisis detection"""
    return '''
async def _detect_crisis(self, posts: List[Dict], thresholds: Dict) -> Dict[str, Any]:
    """
    Detect potential crisis situations from social media
    
    Args:
        posts: List of social media posts
        thresholds: Detection thresholds (sentiment, volume, velocity)
    
    Returns:
        Dict containing crisis_level, alerts, recommendations
    """
    
    result = {
        "crisis_level": "normal",
        "alerts": [],
        "recommendations": [],
        "metrics": {}
    }
    
    try:
        logger.info(f"Analyzing {len(posts)} posts for crisis detection")
        
        # Default thresholds
        negative_threshold = thresholds.get("negative_sentiment", 0.6)
        volume_threshold = thresholds.get("volume_spike", 5.0)  # 5x normal volume
        velocity_threshold = thresholds.get("velocity", 10)  # posts per minute
        
        # Analyze sentiment distribution
        sentiment_analysis = await self._analyze_sentiment(
            [post.get("text", "") for post in posts]
        )
        
        negative_ratio = sentiment_analysis["summary"]["negative_percentage"] / 100
        
        # Calculate posting velocity (posts per minute)
        if posts:
            time_span = self._calculate_time_span(posts)
            velocity = len(posts) / max(time_span, 1)
        else:
            velocity = 0
        
        # Crisis detection logic
        crisis_indicators = []
        
        if negative_ratio > negative_threshold:
            crisis_indicators.append("high_negative_sentiment")
            result["alerts"].append({
                "type": "sentiment",
                "severity": "high",
                "message": f"Negative sentiment at {negative_ratio:.1%} (threshold: {negative_threshold:.1%})"
            })
        
        if velocity > velocity_threshold:
            crisis_indicators.append("high_velocity")
            result["alerts"].append({
                "type": "velocity",
                "severity": "medium",
                "message": f"High posting velocity: {velocity:.1f} posts/min"
            })
        
        # Determine crisis level
        if len(crisis_indicators) >= 2:
            result["crisis_level"] = "critical"
        elif len(crisis_indicators) == 1:
            result["crisis_level"] = "warning"
        else:
            result["crisis_level"] = "normal"
        
        # Generate recommendations
        if result["crisis_level"] == "critical":
            result["recommendations"] = [
                "Immediately activate crisis response team",
                "Prepare official statement",
                "Monitor all channels continuously",
                "Engage with key stakeholders",
                "Consider pausing scheduled posts"
            ]
        elif result["crisis_level"] == "warning":
            result["recommendations"] = [
                "Increase monitoring frequency",
                "Prepare response templates",
                "Alert communications team",
                "Review crisis protocol"
            ]
        
        # Store metrics
        result["metrics"] = {
            "negative_sentiment_ratio": negative_ratio,
            "posting_velocity": velocity,
            "total_posts": len(posts),
            "crisis_indicators": crisis_indicators
        }
        
        logger.info(f"Crisis detection completed. Level: {result['crisis_level']}")
        return result
        
    except Exception as e:
        logger.error(f"Crisis detection failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result

def _calculate_time_span(self, posts: List[Dict]) -> float:
    """Calculate time span of posts in minutes"""
    if not posts:
        return 0
    
    timestamps = []
    for post in posts:
        if "timestamp" in post:
            try:
                ts = datetime.fromisoformat(post["timestamp"].replace("Z", "+00:00"))
                timestamps.append(ts)
            except:
                continue
    
    if len(timestamps) < 2:
        return 1
    
    timestamps.sort()
    time_diff = timestamps[-1] - timestamps[0]
    return max(time_diff.total_seconds() / 60, 1)  # Return minutes
'''