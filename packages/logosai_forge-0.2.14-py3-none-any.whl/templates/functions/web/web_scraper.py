"""
Web Scraper Template
"""

TEMPLATE_INFO = {
    "id": "web.web_scraper",
    "name": "Web Scraper",
    "category": "web",
    "version": "1.0.0",
    "llm_customizable": ["extraction_rules", "pagination_handling", "data_cleaning"]
}

def get_web_scraper():
    """웹 스크래핑 함수 템플릿"""
    return '''
async def _scrape_website(
    self,
    url: Union[str, List[str]],
    scraping_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Scrape content from websites.
    
    Args:
        url: URL(s) to scrape
        scraping_options: Scraping configuration
    
    Returns:
        Tuple[scraped data, metadata]
    """
    metadata = {
        "operation": "web_scraping",
        "scraped_at": datetime.now().isoformat()
    }
    
    try:
        import aiohttp
        from bs4 import BeautifulSoup
        import asyncio
        
        # Default options
        default_options = {
            "parser": "html.parser",
            "timeout": 30,
            "headers": {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            },
            "extract_text": True,
            "extract_links": True,
            "extract_images": False,
            "extract_tables": False,
            "css_selectors": {},  # Custom CSS selectors
            "follow_pagination": False,
            "max_pages": 5
        }
        
        if scraping_options:
            default_options.update(scraping_options)
        
        # Prepare URL list
        urls = [url] if isinstance(url, str) else url
        
        result = {
            "pages": [],
            "aggregated_data": {},
            "statistics": {}
        }
        
        async def scrape_single_url(session, target_url):
            try:
                async with session.get(
                    target_url,
                    headers=default_options["headers"],
                    timeout=aiohttp.ClientTimeout(total=default_options["timeout"])
                ) as response:
                    
                    if response.status != 200:
                        return {
                            "url": target_url,
                            "error": f"HTTP {response.status}",
                            "success": False
                        }
                    
                    html = await response.text()
                    soup = BeautifulSoup(html, default_options["parser"])
                    
                    page_data = {
                        "url": target_url,
                        "title": soup.title.string if soup.title else "",
                        "success": True
                    }
                    
                    # [LLM_CUSTOMIZE: extraction_rules]
                    # Extract text content
                    if default_options["extract_text"]:
                        # Remove script and style elements
                        for script in soup(["script", "style"]):
                            script.decompose()
                        
                        # Get text
                        text = soup.get_text()
                        lines = (line.strip() for line in text.splitlines())
                        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                        text = ' '.join(chunk for chunk in chunks if chunk)
                        
                        page_data["text"] = text[:5000]  # Limit text length
                        page_data["text_length"] = len(text)
                    
                    # Extract links
                    if default_options["extract_links"]:
                        links = []
                        for link in soup.find_all('a', href=True):
                            href = link['href']
                            # Make absolute URL
                            if href.startswith('/'):
                                from urllib.parse import urljoin
                                href = urljoin(target_url, href)
                            links.append({
                                "url": href,
                                "text": link.get_text(strip=True)[:100]
                            })
                        page_data["links"] = links[:50]  # Limit number of links
                        page_data["total_links"] = len(links)
                    
                    # Extract images
                    if default_options["extract_images"]:
                        images = []
                        for img in soup.find_all('img', src=True):
                            src = img['src']
                            if src.startswith('/'):
                                from urllib.parse import urljoin
                                src = urljoin(target_url, src)
                            images.append({
                                "src": src,
                                "alt": img.get('alt', '')[:100]
                            })
                        page_data["images"] = images[:30]
                        page_data["total_images"] = len(images)
                    
                    # Extract tables
                    if default_options["extract_tables"]:
                        tables = []
                        for table in soup.find_all('table'):
                            # Convert table to list of lists
                            rows = []
                            for tr in table.find_all('tr'):
                                cells = []
                                for td in tr.find_all(['td', 'th']):
                                    cells.append(td.get_text(strip=True))
                                rows.append(cells)
                            
                            if rows:
                                # Convert to DataFrame-like structure
                                if len(rows) > 1:
                                    df = pd.DataFrame(rows[1:], columns=rows[0] if rows[0] else None)
                                    tables.append(df.to_dict('records'))
                                else:
                                    tables.append(rows)
                        
                        page_data["tables"] = tables[:10]
                        page_data["total_tables"] = len(tables)
                    
                    # Custom CSS selectors
                    if default_options["css_selectors"]:
                        custom_data = {}
                        for key, selector in default_options["css_selectors"].items():
                            elements = soup.select(selector)
                            custom_data[key] = [elem.get_text(strip=True) for elem in elements[:10]]
                        page_data["custom_extracted"] = custom_data
                    
                    {extraction_rules}
                    
                    return page_data
                    
            except asyncio.TimeoutError:
                return {
                    "url": target_url,
                    "error": "Timeout",
                    "success": False
                }
            except Exception as e:
                return {
                    "url": target_url,
                    "error": str(e),
                    "success": False
                }
        
        # Create session and scrape URLs
        async with aiohttp.ClientSession() as session:
            # [LLM_CUSTOMIZE: pagination_handling]
            # Handle pagination if requested
            all_urls = urls.copy()
            
            if default_options["follow_pagination"]:
                for base_url in urls[:1]:  # Only follow pagination for first URL
                    # Simple pagination pattern (page=1, page=2, etc.)
                    for page in range(2, min(default_options["max_pages"] + 1, 10)):
                        if '?' in base_url:
                            paginated_url = f"{base_url}&page={page}"
                        else:
                            paginated_url = f"{base_url}?page={page}"
                        all_urls.append(paginated_url)
            {pagination_handling}
            
            # Scrape all URLs concurrently
            tasks = [scrape_single_url(session, u) for u in all_urls]
            scraped_pages = await asyncio.gather(*tasks)
            
            result["pages"] = scraped_pages
        
        # [LLM_CUSTOMIZE: data_cleaning]
        # Aggregate and clean data
        successful_pages = [p for p in scraped_pages if p.get("success")]
        
        if successful_pages:
            # Aggregate text
            all_text = ' '.join(p.get("text", "") for p in successful_pages)
            
            # Aggregate links (deduplicate)
            all_links = {}
            for page in successful_pages:
                for link in page.get("links", []):
                    all_links[link["url"]] = link["text"]
            
            result["aggregated_data"] = {
                "total_text_length": len(all_text),
                "unique_links": len(all_links),
                "all_titles": [p.get("title", "") for p in successful_pages]
            }
            
            # If tables were extracted, combine them
            if default_options["extract_tables"]:
                all_tables = []
                for page in successful_pages:
                    all_tables.extend(page.get("tables", []))
                result["aggregated_data"]["combined_tables"] = all_tables
        
        {data_cleaning}
        
        # Calculate statistics
        result["statistics"] = {
            "total_urls": len(all_urls),
            "successful": len(successful_pages),
            "failed": len(scraped_pages) - len(successful_pages),
            "success_rate": len(successful_pages) / len(scraped_pages) if scraped_pages else 0
        }
        
        # Update metadata
        metadata.update({
            "urls_scraped": len(all_urls),
            "scraping_options": default_options,
            "success_count": len(successful_pages)
        })
        
        logger.info(f"Web scraping completed: {len(successful_pages)}/{len(all_urls)} pages")
        return result, metadata
        
    except ImportError as e:
        metadata["error"] = f"Required libraries not installed: {e}"
        logger.error(f"Missing libraries for web scraping: {e}")
        raise
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Web scraping failed: {e}")
        raise
'''