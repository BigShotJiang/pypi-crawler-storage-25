"""web/http_client — HTTP GET/POST/PUT/DELETE + API call + file download."""

TEMPLATE_INFO = {
    "id": "web.http_client",
    "name": "HTTP Client",
    "category": "web",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["asyncio", "aiohttp", "json"],
    "llm_customizable": ["auth_handler", "error_handler"],
}


def get_http_get():
    return '''
async def _http_get(self, url: str, headers: dict = None, params: dict = None, timeout: int = 30) -> dict:
    """HTTP GET request."""
    import aiohttp, asyncio
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers or {}, params=params, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                text = await resp.text()
                return {"status": resp.status, "content": text[:5000], "headers": dict(resp.headers),
                        "answer": text[:2000] if resp.status == 200 else f"HTTP {resp.status}: {text[:200]}"}
    except Exception as e:
        return {"error": str(e), "answer": f"GET 실패: {e}"}
'''


def get_http_post():
    return '''
async def _http_post(self, url: str, data: dict = None, json_data: dict = None, headers: dict = None, timeout: int = 30) -> dict:
    """HTTP POST request (form data or JSON)."""
    import aiohttp, asyncio
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers or {}, data=data, json=json_data, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                text = await resp.text()
                return {"status": resp.status, "content": text[:5000],
                        "answer": f"POST {resp.status}: {text[:500]}"}
    except Exception as e:
        return {"error": str(e), "answer": f"POST 실패: {e}"}
'''


def get_http_put():
    return '''
async def _http_put(self, url: str, data: dict = None, json_data: dict = None, headers: dict = None) -> dict:
    """HTTP PUT request."""
    import aiohttp, asyncio
    try:
        async with aiohttp.ClientSession() as session:
            async with session.put(url, headers=headers or {}, data=data, json=json_data, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                text = await resp.text()
                return {"status": resp.status, "content": text[:2000], "answer": f"PUT {resp.status}"}
    except Exception as e:
        return {"error": str(e), "answer": f"PUT 실패: {e}"}
'''


def get_http_delete():
    return '''
async def _http_delete(self, url: str, headers: dict = None) -> dict:
    """HTTP DELETE request."""
    import aiohttp, asyncio
    try:
        async with aiohttp.ClientSession() as session:
            async with session.delete(url, headers=headers or {}, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                return {"status": resp.status, "answer": f"DELETE {resp.status}"}
    except Exception as e:
        return {"error": str(e), "answer": f"DELETE 실패: {e}"}
'''


def get_api_call():
    return '''
async def _api_call(self, url: str, method: str = "GET", headers: dict = None, data: dict = None,
                     auth: dict = None, timeout: int = 30) -> dict:
    """Generic REST API call with auth support.

    auth: {"type": "bearer|basic", "token": str} or {"type": "basic", "username": str, "password": str}
    """
    import aiohttp, asyncio, base64
    h = dict(headers or {})

    # Auth
    if auth:
        if auth.get("type") == "bearer":
            h["Authorization"] = f"Bearer {auth['token']}"
        elif auth.get("type") == "basic":
            creds = base64.b64encode(f"{auth['username']}:{auth['password']}".encode()).decode()
            h["Authorization"] = f"Basic {creds}"

    try:
        async with aiohttp.ClientSession() as session:
            req_method = getattr(session, method.lower())
            kwargs = {"headers": h, "timeout": aiohttp.ClientTimeout(total=timeout)}
            if method.upper() in ("POST", "PUT", "PATCH"):
                kwargs["json"] = data
            elif data:
                kwargs["params"] = data
            async with req_method(url, **kwargs) as resp:
                text = await resp.text()
                return {"status": resp.status, "success": 200 <= resp.status < 300,
                        "content": text[:5000], "answer": text[:2000] if resp.status < 300 else f"API {resp.status}: {text[:200]}"}
    except Exception as e:
        return {"success": False, "error": str(e), "answer": f"API 호출 실패: {e}"}
'''


def get_download_file():
    return '''
async def _download_file(self, url: str, save_path: str = None, timeout: int = 60) -> dict:
    """Download file from URL."""
    import aiohttp, asyncio, os, tempfile
    if not save_path:
        filename = url.split("/")[-1].split("?")[0] or "download"
        save_path = os.path.join(tempfile.gettempdir(), filename)
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                if resp.status == 200:
                    with open(save_path, "wb") as f:
                        while True:
                            chunk = await resp.content.read(8192)
                            if not chunk:
                                break
                            f.write(chunk)
                    size = os.path.getsize(save_path)
                    return {"file_path": save_path, "file_name": os.path.basename(save_path),
                            "size": size, "answer": f"다운로드 완료: {save_path} ({size} bytes)"}
                return {"error": f"HTTP {resp.status}", "answer": f"다운로드 실패: HTTP {resp.status}"}
    except Exception as e:
        return {"error": str(e), "answer": f"다운로드 실패: {e}"}
'''


def get_parse_json_response():
    return '''
async def _parse_json_response(self, text: str) -> dict:
    """Parse JSON from API response text (handles partial/nested JSON)."""
    import json, re
    try:
        return {"data": json.loads(text), "success": True}
    except json.JSONDecodeError:
        match = re.search(r"\\{.*\\}", text, re.DOTALL)
        if match:
            try:
                return {"data": json.loads(match.group()), "success": True}
            except Exception:
                pass
        match = re.search(r"\\[.*\\]", text, re.DOTALL)
        if match:
            try:
                return {"data": json.loads(match.group()), "success": True}
            except Exception:
                pass
    return {"data": None, "success": False, "raw": text[:1000], "answer": "JSON 파싱 실패"}
'''
