"""parsing/filepath — File path extraction."""

TEMPLATE_INFO = {
    "id": "parsing.filepath.extract_file_path",
    "name": "Extract File Path",
    "category": "parsing",
    "version": "1.0.0",
    "required_imports": ["re", "os"],
    "llm_customizable": [],
}


def get_extract_file_path():
    return '''
def _extract_file_path(self, text: str) -> list:
    """텍스트에서 파일 경로 추출.

    예: "/Users/maior/docs/report.pdf 첨부해줘" → ["/Users/maior/docs/report.pdf"]
        "~/Documents/budget.xlsx" → ["~/Documents/budget.xlsx"]
    """
    import re, os
    patterns = [
        r"/[\\w./\\-]+\\.\\w{2,5}",           # /absolute/path/file.ext
        r"~/[\\w./\\-]+\\.\\w{2,5}",          # ~/relative/path/file.ext
        r"[A-Za-z]:\\\\[\\w\\\\./\\-]+\\.\\w{2,5}",  # Windows C:\\path\\file.ext
    ]
    results = []
    for pat in patterns:
        for match in re.findall(pat, text):
            expanded = os.path.expanduser(match)
            results.append(expanded)
    return list(set(results))
'''
