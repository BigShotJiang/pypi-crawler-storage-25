"""parsing/phone — Phone number extraction."""

TEMPLATE_INFO = {
    "id": "parsing.phone.extract_phone",
    "name": "Extract Phone",
    "category": "parsing",
    "version": "1.0.0",
    "required_imports": ["re"],
    "llm_customizable": [],
}


def get_extract_phone():
    return '''
def _extract_phone(self, text: str) -> list:
    """전화번호 추출 (한국 형식 + 국제 형식).

    예: "010-1234-5678로 전화해줘" → ["010-1234-5678"]
    """
    import re
    patterns = [
        r"\\+?\\d{1,3}[-.\\s]?\\d{2,4}[-.\\s]?\\d{3,4}[-.\\s]?\\d{3,4}",
        r"0\\d{1,2}[-.\\s]?\\d{3,4}[-.\\s]?\\d{4}",
    ]
    results = []
    for pat in patterns:
        results.extend(re.findall(pat, text))
    return list(set(results))
'''
