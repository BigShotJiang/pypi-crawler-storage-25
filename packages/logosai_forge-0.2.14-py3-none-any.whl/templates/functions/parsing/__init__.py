# parsing — Text parsing function templates (email, phone, name, date, url, filepath, sanitizer)
