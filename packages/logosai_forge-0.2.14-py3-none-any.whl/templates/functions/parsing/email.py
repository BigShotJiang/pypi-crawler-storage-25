"""parsing/email — Email address extraction."""

TEMPLATE_INFO = {
    "id": "parsing.email.extract_email",
    "name": "Extract Email",
    "category": "parsing",
    "version": "1.0.0",
    "required_imports": ["re"],
    "llm_customizable": [],
}


def get_extract_email():
    return '''
def _extract_email(self, text: str) -> list:
    """텍스트에서 이메일 주소 추출. 한글이 붙어있어도 정확 추출.

    예: "maiordba@gmail.com에게 보내줘" → ["maiordba@gmail.com"]
    """
    import re
    pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}"
    return re.findall(pattern, text)
'''
