"""parsing/url — URL extraction."""

TEMPLATE_INFO = {
    "id": "parsing.url.extract_url",
    "name": "Extract URL",
    "category": "parsing",
    "version": "1.0.0",
    "required_imports": ["re"],
    "llm_customizable": [],
}


def get_extract_url():
    return """
def _extract_url(self, text: str) -> list:
    \"\"\"텍스트에서 URL 추출.\"\"\"
    import re
    pattern = r'https?://\\S+'
    urls = re.findall(pattern, text)
    # www로 시작하는 것도 포함
    www = re.findall(r'www\\.\\S+', text)
    return list(set(urls + www))
"""
