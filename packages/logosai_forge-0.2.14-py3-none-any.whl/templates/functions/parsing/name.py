"""parsing/name — Person name extraction."""

TEMPLATE_INFO = {
    "id": "parsing.name.extract_name",
    "name": "Extract Name",
    "category": "parsing",
    "version": "1.0.0",
    "required_imports": ["re"],
    "llm_customizable": ["name_patterns"],
}


def get_extract_name():
    return '''
async def _extract_name(self, text: str) -> list:
    """텍스트에서 사람 이름 추출 (한국어/영어).

    한국어: 2-4자 한글 이름 (김철수, 이성정)
    영어: Capitalized words (John Smith)

    LLM 사용 시 더 정확.
    """
    import re
    names = []

    # 한국어 이름 (성+이름 2-4자)
    kr_pattern = r"[가-힣]{2,4}(?=에게|한테|님|씨|\\s)"
    names.extend(re.findall(kr_pattern, text))

    # 영어 이름
    en_pattern = r"[A-Z][a-z]+(?:\\s[A-Z][a-z]+)+"
    names.extend(re.findall(en_pattern, text))

    # LLM 보강 (있으면)
    if not names and hasattr(self, "_llm") and self._llm:
        try:
            import asyncio
            resp = await asyncio.wait_for(
                self._llm.invoke(f"이 텍스트에서 사람 이름만 추출하세요. 이름만 반환: {text[:200]}"),
                timeout=5)
            answer = resp.content if hasattr(resp, "content") else str(resp)
            if answer.strip():
                names.append(answer.strip())
        except Exception:
            pass

    return list(set(names))
'''
