"""parsing/sanitizer — Input sanitization (XSS, SQL injection prevention)."""

TEMPLATE_INFO = {
    "id": "parsing.sanitizer.sanitize_input",
    "name": "Sanitize Input",
    "category": "parsing",
    "version": "1.0.0",
    "required_imports": ["re", "html"],
    "llm_customizable": [],
}


def get_sanitize_input():
    return '''
def _sanitize_input(self, text: str) -> str:
    """입력 정제 — XSS, SQL injection, command injection 방지.

    모든 에이전트의 사용자 입력 처리 전 호출.
    """
    import re, html

    if not text or not isinstance(text, str):
        return ""

    # HTML 이스케이프 (XSS 방지)
    sanitized = html.escape(text)

    # SQL injection 패턴 제거
    sql_patterns = [
        r"(?i)(\\b(SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|EXEC|UNION)\\b)",
        r"(--|;|/\\*|\\*/)",
        r"(?i)(\\bOR\\b\\s+\\d+\\s*=\\s*\\d+)",
    ]
    for pat in sql_patterns:
        sanitized = re.sub(pat, "", sanitized)

    # Command injection 패턴 제거
    cmd_patterns = [r"[`$]\\(", r"\\|\\s*\\w+", r"&&", r"\\|\\|"]
    for pat in cmd_patterns:
        sanitized = re.sub(pat, "", sanitized)

    return sanitized.strip()
'''
