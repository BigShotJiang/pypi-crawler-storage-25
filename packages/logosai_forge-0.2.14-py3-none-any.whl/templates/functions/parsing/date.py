"""parsing/date — Date/time extraction from natural language."""

TEMPLATE_INFO = {
    "id": "parsing.date.extract_date",
    "name": "Extract Date",
    "category": "parsing",
    "version": "1.0.0",
    "required_imports": ["datetime", "re"],
    "llm_customizable": ["date_rules"],
}


def get_extract_date():
    return '''
async def _extract_date(self, text: str) -> str:
    """자연어 날짜 표현 → ISO 형식 변환.

    예: "내일 오후 3시" → "2026-04-04 15:00"
        "다음 주 월요일" → "2026-04-07"
    """
    from datetime import datetime, timedelta

    today = datetime.now()

    # 규칙 기반 (빠른 처리)
    if "오늘" in text:
        return today.strftime("%Y-%m-%d")
    if "내일" in text:
        return (today + timedelta(days=1)).strftime("%Y-%m-%d")
    if "모레" in text:
        return (today + timedelta(days=2)).strftime("%Y-%m-%d")
    if "어제" in text:
        return (today - timedelta(days=1)).strftime("%Y-%m-%d")

    # 시간 추출
    import re
    time_match = re.search(r"(\\d{1,2})시", text)
    time_str = ""
    if time_match:
        hour = int(time_match.group(1))
        if "오후" in text and hour < 12:
            hour += 12
        time_str = f" {hour:02d}:00"

    # LLM 기반 (복잡한 표현)
    if hasattr(self, "_llm") and self._llm:
        try:
            import asyncio
            prompt = f"오늘은 {today.strftime('%Y-%m-%d')}입니다. \\"{text}\\"에서 날짜를 추출하세요. ISO 형식(YYYY-MM-DD HH:mm)으로만 반환."
            resp = await asyncio.wait_for(self._llm.invoke(prompt), timeout=5)
            answer = resp.content if hasattr(resp, "content") else str(resp)
            return answer.strip()
        except Exception:
            pass

    return today.strftime("%Y-%m-%d") + time_str if time_str else ""
'''
