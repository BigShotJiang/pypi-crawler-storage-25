"""
Statistical Analysis Template
"""

TEMPLATE_INFO = {
    "id": "analysis.statistical",
    "name": "Statistical Analysis",
    "category": "analysis",
    "version": "1.0.0",
    "llm_customizable": ["advanced_statistics", "domain_analysis", "custom_metrics"]
}

def get_statistical_analysis():
    """통계 분석 함수 템플릿"""
    return '''
async def _analyze_statistics(
    self,
    data: pd.DataFrame,
    columns: Optional[List[str]] = None,
    options: Optional[Dict] = None
) -> Dict[str, Any]:
    """
    Perform statistical analysis on data.
    
    Args:
        data: DataFrame to analyze
        columns: Specific columns to analyze (None = all numeric)
        options: Analysis options (percentiles, correlation, etc.)
    
    Returns:
        Dict with statistical results including summary, details, and metrics
    """
    result = {
        "analysis_type": "statistical",
        "summary": {},
        "details": {},
        "metrics": {},
        "recommendations": [],
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        # Validate input
        if data.empty:
            raise ValueError("Input DataFrame is empty")
        
        # Select columns to analyze
        if columns:
            # Validate specified columns exist
            missing_cols = set(columns) - set(data.columns)
            if missing_cols:
                raise ValueError(f"Columns not found: {missing_cols}")
            numeric_data = data[columns].select_dtypes(include=[np.number])
        else:
            numeric_data = data.select_dtypes(include=[np.number])
        
        if numeric_data.empty:
            raise ValueError("No numeric columns to analyze")
        
        # Basic statistics
        result["summary"] = {
            "mean": numeric_data.mean().to_dict(),
            "median": numeric_data.median().to_dict(),
            "mode": numeric_data.mode().iloc[0].to_dict() if not numeric_data.mode().empty else {},
            "std": numeric_data.std().to_dict(),
            "var": numeric_data.var().to_dict(),
            "min": numeric_data.min().to_dict(),
            "max": numeric_data.max().to_dict(),
            "range": (numeric_data.max() - numeric_data.min()).to_dict(),
            "count": numeric_data.count().to_dict(),
            "null_count": numeric_data.isnull().sum().to_dict()
        }
        
        # Percentiles
        percentiles = options.get("percentiles", [0.25, 0.5, 0.75]) if options else [0.25, 0.5, 0.75]
        result["details"]["percentiles"] = {}
        for p in percentiles:
            result["details"]["percentiles"][f"p{int(p*100)}"] = numeric_data.quantile(p).to_dict()
        
        # Skewness and Kurtosis
        result["details"]["distribution"] = {
            "skewness": numeric_data.skew().to_dict(),
            "kurtosis": numeric_data.kurtosis().to_dict()
        }
        
        # Correlation matrix (if multiple columns)
        if len(numeric_data.columns) > 1:
            correlation_matrix = numeric_data.corr()
            result["details"]["correlation"] = correlation_matrix.to_dict()
            
            # Find strong correlations
            strong_correlations = []
            for i in range(len(correlation_matrix.columns)):
                for j in range(i+1, len(correlation_matrix.columns)):
                    corr_value = correlation_matrix.iloc[i, j]
                    if abs(corr_value) > 0.7:  # Strong correlation threshold
                        strong_correlations.append({
                            "column1": correlation_matrix.columns[i],
                            "column2": correlation_matrix.columns[j],
                            "correlation": corr_value
                        })
            
            if strong_correlations:
                result["details"]["strong_correlations"] = strong_correlations
        
        # [LLM_CUSTOMIZE: advanced_statistics]
        # Add advanced statistical tests or analyses
        {advanced_statistics}
        
        # [LLM_CUSTOMIZE: domain_analysis]
        # Add domain-specific analysis
        {domain_analysis}
        
        # [LLM_CUSTOMIZE: custom_metrics]
        # Calculate custom metrics based on requirements
        {custom_metrics}
        
        # Outlier detection using IQR method
        outliers = {}
        for col in numeric_data.columns:
            Q1 = numeric_data[col].quantile(0.25)
            Q3 = numeric_data[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            outlier_count = ((numeric_data[col] < lower_bound) | (numeric_data[col] > upper_bound)).sum()
            if outlier_count > 0:
                outliers[col] = {
                    "count": int(outlier_count),
                    "percentage": outlier_count / len(numeric_data) * 100,
                    "bounds": {"lower": lower_bound, "upper": upper_bound}
                }
        
        if outliers:
            result["details"]["outliers"] = outliers
        
        # Generate metrics
        result["metrics"] = {
            "columns_analyzed": len(numeric_data.columns),
            "rows_analyzed": len(numeric_data),
            "total_null_values": int(numeric_data.isnull().sum().sum()),
            "null_percentage": numeric_data.isnull().sum().sum() / (len(numeric_data) * len(numeric_data.columns)) * 100,
            "has_outliers": len(outliers) > 0,
            "outlier_columns": list(outliers.keys()) if outliers else []
        }
        
        # Generate recommendations
        recommendations = []
        
        # Check for high null percentage
        for col in numeric_data.columns:
            null_pct = numeric_data[col].isnull().sum() / len(numeric_data) * 100
            if null_pct > 20:
                recommendations.append(f"Column '{col}' has {null_pct:.1f}% null values - consider imputation or removal")
        
        # Check for high skewness
        for col, skew_val in result["details"]["distribution"]["skewness"].items():
            if abs(skew_val) > 1:
                recommendations.append(f"Column '{col}' is highly skewed ({skew_val:.2f}) - consider transformation")
        
        # Check for outliers
        for col, outlier_info in outliers.items():
            if outlier_info["percentage"] > 5:
                recommendations.append(f"Column '{col}' has {outlier_info['percentage']:.1f}% outliers - investigate or handle")
        
        result["recommendations"] = recommendations
        
        logger.info(f"Statistical analysis completed for {len(numeric_data.columns)} columns")
        return result
        
    except ValueError as e:
        logger.warning(f"Statistical analysis validation error: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
        
    except Exception as e:
        logger.error(f"Statistical analysis failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''