"""
Time Series Analysis Template
"""

TEMPLATE_INFO = {
    "id": "analysis.time_series",
    "name": "Time Series Analysis",
    "category": "analysis",
    "version": "1.0.0",
    "llm_customizable": ["preprocessing", "analysis_methods", "forecasting"]
}

def get_time_series():
    """시계열 분석 함수 템플릿"""
    return '''
async def _analyze_time_series(
    self,
    data: Union[pd.DataFrame, pd.Series, List],
    datetime_column: Optional[str] = None,
    value_column: Optional[str] = None,
    analysis_options: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Perform time series analysis and forecasting.
    
    Args:
        data: Time series data
        datetime_column: Name of datetime column
        value_column: Name of value column to analyze
        analysis_options: Analysis configuration
    
    Returns:
        Tuple[analysis results, metadata]
    """
    metadata = {
        "analysis_type": "time_series",
        "analyzed_at": datetime.now().isoformat()
    }
    
    try:
        import numpy as np
        from scipy import stats
        from statsmodels.tsa.seasonal import seasonal_decompose
        from statsmodels.tsa.stattools import adfuller
        
        # Convert to DataFrame if necessary
        if isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, pd.Series):
            df = data.to_frame()
        else:
            df = data.copy()
        
        # Default options
        default_options = {
            "decompose": True,
            "stationarity_test": True,
            "autocorrelation": True,
            "trend_analysis": True,
            "seasonality_period": None,
            "forecast_periods": 0
        }
        
        if analysis_options:
            default_options.update(analysis_options)
        
        # [LLM_CUSTOMIZE: preprocessing]
        # Preprocess time series data
        if datetime_column:
            df[datetime_column] = pd.to_datetime(df[datetime_column])
            df = df.set_index(datetime_column)
            df = df.sort_index()
        
        if value_column:
            ts = df[value_column]
        else:
            # Assume first numeric column
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                ts = df[numeric_cols[0]]
                value_column = numeric_cols[0]
            else:
                raise ValueError("No numeric column found for analysis")
        
        # Handle missing values
        ts = ts.fillna(method='ffill').fillna(method='bfill')
        {preprocessing}
        
        result = {
            "summary": {},
            "statistics": {},
            "patterns": {},
            "forecast": None
        }
        
        # Basic statistics
        result["statistics"] = {
            "mean": float(ts.mean()),
            "median": float(ts.median()),
            "std": float(ts.std()),
            "min": float(ts.min()),
            "max": float(ts.max()),
            "count": len(ts),
            "missing_values": int(ts.isna().sum())
        }
        
        # [LLM_CUSTOMIZE: analysis_methods]
        # Trend analysis
        if default_options["trend_analysis"]:
            # Calculate moving averages
            result["patterns"]["ma_7"] = ts.rolling(window=7).mean().tolist()[-10:]
            result["patterns"]["ma_30"] = ts.rolling(window=30).mean().tolist()[-10:]
            
            # Trend direction
            recent_mean = ts.tail(10).mean()
            older_mean = ts.tail(20).head(10).mean()
            result["patterns"]["trend_direction"] = "upward" if recent_mean > older_mean else "downward"
            result["patterns"]["trend_strength"] = abs(recent_mean - older_mean) / older_mean if older_mean != 0 else 0
        
        # Stationarity test (Augmented Dickey-Fuller)
        if default_options["stationarity_test"] and len(ts) > 20:
            adf_result = adfuller(ts.dropna())
            result["patterns"]["stationarity"] = {
                "adf_statistic": float(adf_result[0]),
                "p_value": float(adf_result[1]),
                "is_stationary": adf_result[1] < 0.05,
                "critical_values": {k: float(v) for k, v in adf_result[4].items()}
            }
        
        # Seasonal decomposition
        if default_options["decompose"] and len(ts) > 50:
            try:
                # Determine period if not provided
                if default_options["seasonality_period"]:
                    period = default_options["seasonality_period"]
                else:
                    # Simple heuristic: weekly pattern = 7, monthly = 30, yearly = 365
                    if len(ts) > 365:
                        period = 365
                    elif len(ts) > 30:
                        period = 30
                    else:
                        period = 7
                
                decomposition = seasonal_decompose(ts, model='additive', period=period)
                result["patterns"]["decomposition"] = {
                    "trend": decomposition.trend.dropna().tolist()[-10:],
                    "seasonal": decomposition.seasonal.dropna().tolist()[-10:],
                    "residual": decomposition.resid.dropna().tolist()[-10:],
                    "period": period
                }
            except:
                logger.warning("Could not perform seasonal decomposition")
        
        # Autocorrelation
        if default_options["autocorrelation"] and len(ts) > 10:
            from statsmodels.stats.stattools import acf
            acf_values = acf(ts.dropna(), nlags=min(10, len(ts)//4))
            result["patterns"]["autocorrelation"] = {
                "values": acf_values.tolist(),
                "significant_lag": int(np.argmax(np.abs(acf_values[1:])) + 1)
            }
        
        {analysis_methods}
        
        # [LLM_CUSTOMIZE: forecasting]
        # Simple forecasting
        if default_options["forecast_periods"] > 0:
            try:
                from statsmodels.tsa.arima.model import ARIMA
                
                # Fit ARIMA model (simple version)
                model = ARIMA(ts, order=(1, 1, 1))
                model_fit = model.fit()
                
                # Make forecast
                forecast = model_fit.forecast(steps=default_options["forecast_periods"])
                
                result["forecast"] = {
                    "values": forecast.tolist(),
                    "periods": default_options["forecast_periods"],
                    "method": "ARIMA(1,1,1)"
                }
            except:
                # Fallback to simple linear extrapolation
                x = np.arange(len(ts))
                y = ts.values
                z = np.polyfit(x, y, 1)
                p = np.poly1d(z)
                
                future_x = np.arange(len(ts), len(ts) + default_options["forecast_periods"])
                forecast_values = p(future_x)
                
                result["forecast"] = {
                    "values": forecast_values.tolist(),
                    "periods": default_options["forecast_periods"],
                    "method": "linear_extrapolation"
                }
            {forecasting}
        
        # Update metadata
        metadata.update({
            "data_points": len(ts),
            "time_range": {
                "start": str(ts.index[0]) if hasattr(ts.index, '__getitem__') else None,
                "end": str(ts.index[-1]) if hasattr(ts.index, '__getitem__') else None
            },
            "value_column": value_column,
            "analysis_performed": list(result.keys())
        })
        
        logger.info(f"Time series analysis completed: {len(ts)} data points")
        return result, metadata
        
    except ImportError as e:
        metadata["error"] = f"Required libraries not installed: {e}"
        logger.error(f"Missing libraries for time series analysis: {e}")
        raise
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Time series analysis failed: {e}")
        raise
'''