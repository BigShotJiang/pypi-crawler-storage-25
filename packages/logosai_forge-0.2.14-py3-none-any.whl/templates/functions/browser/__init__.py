# browser — Web browsing automation function templates
