"""browser/interaction — Form filling, clicking, waiting."""

TEMPLATE_INFO = {
    "id": "browser.interaction",
    "name": "Browser Interaction",
    "category": "browser",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["asyncio"],
    "llm_customizable": [],
}


def get_fill_form_field():
    return '''
async def _fill_form_field(self, selector: str, value: str, tab_pattern: str = "") -> dict:
    """Fill a form field in Chrome via JavaScript."""
    import asyncio
    escaped_val = value.replace("\\\\", "\\\\\\\\").replace("'", "\\\\'")
    js = f"var el = document.querySelector('{selector}'); if(el) {{ el.value = '{escaped_val}'; el.dispatchEvent(new Event('input')); 'filled' }} else {{ 'not_found' }}"
    result = await self._chrome_execute_js(js, tab_pattern)
    return {"success": result == "filled", "answer": f"Field {selector}: {result}"}
'''


def get_click_element():
    return '''
async def _click_browser_element(self, selector: str, tab_pattern: str = "") -> dict:
    """Click an element in Chrome via JavaScript."""
    js = f"var el = document.querySelector('{selector}'); if(el) {{ el.click(); 'clicked' }} else {{ 'not_found' }}"
    result = await self._chrome_execute_js(js, tab_pattern)
    return {"success": result == "clicked", "answer": f"Click {selector}: {result}"}
'''


def get_submit_form():
    return '''
async def _submit_form(self, form_selector: str = "form", tab_pattern: str = "") -> dict:
    """Submit a form in Chrome."""
    js = f"var f = document.querySelector('{form_selector}'); if(f) {{ f.submit(); 'submitted' }} else {{ 'not_found' }}"
    result = await self._chrome_execute_js(js, tab_pattern)
    return {"success": result == "submitted", "answer": f"Form submit: {result}"}
'''


def get_wait_for_element():
    return '''
async def _wait_for_element(self, selector: str, timeout: int = 10, tab_pattern: str = "") -> dict:
    """Wait until an element appears on page."""
    import asyncio
    for _ in range(timeout):
        js = f"document.querySelector('{selector}') ? 'found' : 'waiting'"
        result = await self._chrome_execute_js(js, tab_pattern)
        if result == "found":
            return {"found": True, "answer": f"Element {selector} found"}
        await asyncio.sleep(1)
    return {"found": False, "answer": f"Element {selector} not found after {timeout}s"}
'''


def get_fill_login_form():
    return '''
async def _fill_login_form(self, username: str, password: str,
                            user_selector: str = "input[type=email], input[name=username], #username",
                            pass_selector: str = "input[type=password]",
                            submit_selector: str = "button[type=submit], input[type=submit]",
                            tab_pattern: str = "") -> dict:
    """Fill login form with username and password, then submit."""
    import asyncio
    # Fill username
    r1 = await self._fill_form_field(user_selector, username, tab_pattern)
    await asyncio.sleep(0.5)
    # Fill password
    r2 = await self._fill_form_field(pass_selector, password, tab_pattern)
    await asyncio.sleep(0.5)
    # Submit
    r3 = await self._click_browser_element(submit_selector, tab_pattern)
    return {"success": r1.get("success") and r2.get("success"),
            "answer": f"Login form: user={r1.get('success')}, pass={r2.get('success')}, submit={r3.get('success')}"}
'''
