"""browser/navigation — URL navigation, page text extraction, screenshots."""

TEMPLATE_INFO = {
    "id": "browser.navigation",
    "name": "Browser Navigation",
    "category": "browser",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["asyncio", "subprocess"],
    "llm_customizable": ["wait_strategy"],
}


def get_open_url():
    return '''
async def _open_url(self, url: str, wait_time: int = 3) -> dict:
    """Open URL in Chrome and extract page text via JS."""
    import subprocess, asyncio
    subprocess.Popen(["open", "-a", "Google Chrome", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    await asyncio.sleep(wait_time)
    js = "document.title + '\\\\n\\\\n' + document.body.innerText.substring(0, 5000)"
    text = await self._chrome_execute_js(js, url.split("/")[2] if "/" in url else url)
    return {"url": url, "text": text, "answer": text[:2000] if text else f"Opened: {url}"}
'''


def get_extract_page_text():
    return '''
async def _extract_page_text(self, tab_pattern: str = "") -> dict:
    """Extract text content from current Chrome tab."""
    js = "document.body.innerText.substring(0, 10000)"
    text = await self._chrome_execute_js(js, tab_pattern)
    title_js = "document.title"
    title = await self._chrome_execute_js(title_js, tab_pattern)
    return {"text": text, "title": title, "length": len(text or ""), "answer": f"{title}\\n\\n{(text or '')[:3000]}"}
'''


def get_take_web_screenshot():
    return '''
async def _take_web_screenshot(self, url: str = None, output_path: str = None) -> dict:
    """Take screenshot of current Chrome window (or open URL first)."""
    import asyncio, os, tempfile, subprocess
    if url:
        subprocess.Popen(["open", "-a", "Google Chrome", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        await asyncio.sleep(3)
    path = output_path or os.path.join(tempfile.gettempdir(), "web_screenshot.png")
    try:
        subprocess.run(["screencapture", "-x", path], capture_output=True, timeout=5)
        return {"image_path": path, "file_name": os.path.basename(path), "answer": f"스크린샷 저장: {path}"}
    except Exception as e:
        return {"error": str(e), "answer": f"스크린샷 실패: {e}"}
'''


def get_extract_links():
    return '''
async def _extract_links(self, tab_pattern: str = "") -> dict:
    """Extract all links from current page."""
    import json as _json
    js = """
    (function() {
        var links = [];
        document.querySelectorAll('a[href]').forEach(function(a) {
            if (a.href && !a.href.startsWith('javascript:')) {
                links.push({url: a.href, text: (a.textContent || '').trim().substring(0, 100)});
            }
        });
        return JSON.stringify(links.slice(0, 50));
    })()
    """
    result = await self._chrome_execute_js(js, tab_pattern)
    try:
        links = _json.loads(result) if result and not result.startswith("ERROR") else []
    except Exception:
        links = []
    return {"links": links, "count": len(links), "answer": f"Found {len(links)} links"}
'''


def get_extract_table():
    return '''
async def _extract_table(self, table_index: int = 0, tab_pattern: str = "") -> dict:
    """Extract HTML table data from current page."""
    import json as _json
    js = f"""
    (function() {{
        var tables = document.querySelectorAll('table');
        if (tables.length <= {table_index}) return JSON.stringify([]);
        var table = tables[{table_index}];
        var data = [];
        table.querySelectorAll('tr').forEach(function(tr) {{
            var row = [];
            tr.querySelectorAll('th, td').forEach(function(cell) {{
                row.push(cell.textContent.trim());
            }});
            data.push(row);
        }});
        return JSON.stringify(data.slice(0, 100));
    }})()
    """
    result = await self._chrome_execute_js(js, tab_pattern)
    try:
        data = _json.loads(result) if result and not result.startswith("ERROR") else []
    except Exception:
        data = []
    return {"data": data, "rows": len(data), "answer": f"Table: {len(data)} rows"}
'''
