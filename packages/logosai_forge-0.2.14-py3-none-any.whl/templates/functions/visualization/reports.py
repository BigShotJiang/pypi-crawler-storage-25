"""visualization/reports — Dashboard, data table, HTML report, image export."""

TEMPLATE_INFO = {
    "id": "visualization.reports",
    "name": "Report Generator",
    "category": "visualization",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["os", "json"],
    "llm_customizable": ["report_style", "dashboard_layout"],
}


def get_render_table():
    return '''
async def _render_table(self, data: list, headers: list = None, title: str = "Data Table") -> dict:
    """Render data as HTML table with styling."""
    if not data:
        return {"html": "<p>No data</p>", "answer": "데이터 없음"}
    cols = headers or (list(data[0].keys()) if isinstance(data[0], dict) else [f"Col{i}" for i in range(len(data[0]))])
    rows_html = ""
    for row in data[:100]:
        cells = "".join(f"<td style=\\"padding:6px;border:1px solid #ddd\\">{row.get(c,'') if isinstance(row,dict) else row[i] if i<len(row) else ''}</td>" for i, c in enumerate(cols))
        rows_html += f"<tr>{cells}</tr>"
    header_html = "".join(f"<th style=\\"padding:8px;background:#4472C4;color:white;border:1px solid #ddd\\">{c}</th>" for c in cols)
    html = f"<h3>{title}</h3><table style=\\"border-collapse:collapse;width:100%\\"><thead><tr>{header_html}</tr></thead><tbody>{rows_html}</tbody></table>"
    return {"html": html, "rows": len(data), "answer": f"Table: {title} ({len(data)} rows)"}
'''


def get_create_dashboard():
    return '''
async def _create_dashboard(self, title: str, charts: list, columns: int = 2) -> dict:
    """Create dashboard layout combining multiple charts.

    Args:
        charts: [{"html": str, "title": str}]
        columns: Grid columns (1, 2, or 3)
    """
    grid_items = ""
    for chart in charts:
        grid_items += f"<div style=\\"border:1px solid #eee;padding:10px;border-radius:8px;background:white\\">"
        grid_items += f"<h4 style=\\"margin:0 0 10px\\">{chart.get('title','')}</h4>"
        grid_items += chart.get("html", "")
        grid_items += "</div>"

    html = f"""<div style="font-family:sans-serif;padding:20px;background:#f5f5f5">
    <h2 style="text-align:center">{title}</h2>
    <div style="display:grid;grid-template-columns:repeat({columns},1fr);gap:15px;margin-top:20px">
    {grid_items}
    </div></div>"""
    return {"html": html, "chart_count": len(charts), "answer": f"Dashboard: {title} ({len(charts)} charts)"}
'''


def get_create_html_report():
    return '''
async def _create_html_report(self, title: str, sections: list, output_path: str = None) -> dict:
    """Create full HTML report with text, charts, and tables.

    Args:
        sections: [{"type": "text|chart|table|heading", "content": str, "title": str}]
    """
    import os, tempfile
    body = ""
    for sec in sections:
        stype = sec.get("type", "text")
        content = sec.get("content", "")
        sec_title = sec.get("title", "")
        if stype == "heading":
            body += f"<h2 style=\\"color:#333;border-bottom:2px solid #4472C4;padding-bottom:5px\\">{content}</h2>"
        elif stype == "text":
            body += f"<p style=\\"line-height:1.6\\">{content}</p>"
        elif stype == "chart":
            body += f"<div style=\\"margin:20px 0\\">{content}</div>"
        elif stype == "table":
            body += f"<div style=\\"margin:20px 0\\">{content}</div>"

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>{title}</title>
    <style>body{{font-family:sans-serif;max-width:1000px;margin:0 auto;padding:20px;color:#333}}</style>
    </head><body><h1 style="text-align:center;color:#2c3e50">{title}</h1>{body}</body></html>"""

    path = output_path or os.path.join(tempfile.gettempdir(), f"{title[:30].replace(' ','_')}_report.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return {"file_path": path, "file_name": os.path.basename(path), "html": html,
            "answer": f"HTML 보고서 생성: {path}"}
'''


def get_export_chart_to_image():
    return '''
async def _export_chart_to_image(self, html_content: str, output_path: str = None, width: int = 1280, height: int = 720) -> dict:
    """Export chart HTML to image (screenshot-based fallback)."""
    import os, tempfile, subprocess
    # Save HTML to temp file
    html_path = os.path.join(tempfile.gettempdir(), "chart_export.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(f"<html><body style=\\"margin:0;padding:20px\\">{html_content}</body></html>")

    img_path = output_path or os.path.join(tempfile.gettempdir(), "chart_export.png")
    # Open in Chrome + screenshot
    try:
        subprocess.Popen(["open", "-a", "Google Chrome", html_path], stdout=subprocess.DEVNULL)
        import asyncio
        await asyncio.sleep(2)
        subprocess.run(["screencapture", "-x", img_path], capture_output=True, timeout=5)
        return {"image_path": img_path, "file_name": os.path.basename(img_path),
                "answer": f"차트 이미지 저장: {img_path}"}
    except Exception as e:
        return {"error": str(e), "answer": f"이미지 변환 실패: {e}"}
'''
