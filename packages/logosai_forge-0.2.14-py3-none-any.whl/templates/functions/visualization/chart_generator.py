"""
Chart Generation Template
"""

TEMPLATE_INFO = {
    "id": "visualization.chart_generator",
    "name": "Chart Generator",
    "category": "visualization",
    "version": "1.0.0",
    "llm_customizable": ["chart_configuration", "data_preparation", "style_customization"]
}

def get_chart_generator():
    """차트 생성 함수 템플릿"""
    return '''
async def _generate_chart(
    self,
    data: Union[pd.DataFrame, Dict, List],
    chart_type: str = "line",
    title: Optional[str] = None,
    x_column: Optional[str] = None,
    y_columns: Optional[List[str]] = None,
    save_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Generate various types of charts from data.
    
    Args:
        data: Input data (DataFrame, dict, or list)
        chart_type: Type of chart (line, bar, scatter, pie, heatmap, etc.)
        title: Chart title
        x_column: Column name for x-axis
        y_columns: Column names for y-axis
        save_path: Path to save the chart
    
    Returns:
        Dict with chart HTML, image path, and metadata
    """
    result = {
        "chart_type": chart_type,
        "title": title or f"{chart_type.capitalize()} Chart",
        "html": None,
        "image_path": None,
        "data_summary": {},
        "metadata": {},
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        # Convert data to DataFrame if needed
        if isinstance(data, dict):
            df = pd.DataFrame(data)
        elif isinstance(data, list):
            df = pd.DataFrame(data)
        else:
            df = data
        
        # Validate data
        if df.empty:
            raise ValueError("No data provided for chart generation")
        
        # [LLM_CUSTOMIZE: data_preparation]
        # Add data preprocessing logic
        {data_preparation}
        
        # Auto-detect columns if not specified
        if x_column is None and len(df.columns) > 0:
            # Use first column as x-axis by default
            x_column = df.columns[0]
        
        if y_columns is None:
            # Use numeric columns as y-axis
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            if x_column in numeric_cols:
                numeric_cols.remove(x_column)
            y_columns = numeric_cols[:5]  # Limit to 5 series
        
        # Generate chart based on type
        try:
            import plotly.graph_objects as go
            import plotly.express as px
            
            # [LLM_CUSTOMIZE: chart_configuration]
            # Add chart-specific configuration
            {chart_configuration}
            
            if chart_type == "line":
                if len(y_columns) == 1:
                    fig = px.line(df, x=x_column, y=y_columns[0], title=result["title"])
                else:
                    fig = go.Figure()
                    for col in y_columns:
                        fig.add_trace(go.Scatter(x=df[x_column], y=df[col], mode='lines', name=col))
                    fig.update_layout(title=result["title"], xaxis_title=x_column)
            
            elif chart_type == "bar":
                if len(y_columns) == 1:
                    fig = px.bar(df, x=x_column, y=y_columns[0], title=result["title"])
                else:
                    fig = go.Figure()
                    for col in y_columns:
                        fig.add_trace(go.Bar(x=df[x_column], y=df[col], name=col))
                    fig.update_layout(title=result["title"], xaxis_title=x_column, barmode='group')
            
            elif chart_type == "scatter":
                if len(y_columns) >= 1:
                    fig = px.scatter(df, x=x_column, y=y_columns[0], title=result["title"])
                    if len(y_columns) > 1 and len(df) < 1000:
                        # Add size based on second column if available
                        fig = px.scatter(df, x=x_column, y=y_columns[0], 
                                       size=y_columns[1] if len(y_columns) > 1 else None,
                                       title=result["title"])
            
            elif chart_type == "pie":
                if y_columns:
                    # Sum values for pie chart
                    pie_data = df[y_columns[0]].value_counts() if df[y_columns[0]].dtype == 'object' else df.groupby(x_column)[y_columns[0]].sum()
                    fig = px.pie(values=pie_data.values, names=pie_data.index, title=result["title"])
            
            elif chart_type == "heatmap":
                # Create correlation matrix for numeric columns
                numeric_df = df[y_columns] if y_columns else df.select_dtypes(include=[np.number])
                corr_matrix = numeric_df.corr()
                
                fig = px.imshow(corr_matrix, 
                              labels=dict(color="Correlation"),
                              x=corr_matrix.columns,
                              y=corr_matrix.columns,
                              title=result["title"] or "Correlation Heatmap",
                              color_continuous_scale="RdBu",
                              aspect="auto")
            
            elif chart_type == "histogram":
                if y_columns:
                    fig = px.histogram(df, x=y_columns[0], title=result["title"], nbins=30)
            
            elif chart_type == "box":
                if y_columns:
                    fig = px.box(df, y=y_columns, title=result["title"])
            
            else:
                # Default to scatter plot
                logger.warning(f"Unknown chart type '{chart_type}', defaulting to scatter")
                fig = px.scatter(df, x=x_column, y=y_columns[0] if y_columns else df.columns[1], 
                               title=result["title"])
            
            # [LLM_CUSTOMIZE: style_customization]
            # Add style customization
            {style_customization}
            
            # Update layout for better appearance
            fig.update_layout(
                autosize=True,
                margin=dict(l=50, r=50, t=50, b=50),
                hovermode='closest',
                showlegend=True
            )
            
            # Generate HTML
            result["html"] = fig.to_html(include_plotlyjs='cdn', div_id="chart")
            
            # Save if path provided
            if save_path:
                if save_path.endswith('.html'):
                    fig.write_html(save_path)
                    result["image_path"] = save_path
                else:
                    # Save as static image (requires kaleido)
                    try:
                        if save_path.endswith('.png'):
                            fig.write_image(save_path)
                        elif save_path.endswith('.svg'):
                            fig.write_image(save_path)
                        elif save_path.endswith('.pdf'):
                            fig.write_image(save_path)
                        else:
                            # Default to PNG
                            save_path = save_path + '.png'
                            fig.write_image(save_path)
                        result["image_path"] = save_path
                    except ImportError:
                        logger.warning("kaleido not installed, saving as HTML instead")
                        html_path = save_path.replace('.png', '.html').replace('.svg', '.html')
                        fig.write_html(html_path)
                        result["image_path"] = html_path
            
        except ImportError:
            logger.warning("Plotly not available, falling back to matplotlib")
            
            import matplotlib.pyplot as plt
            
            fig, ax = plt.subplots(figsize=(10, 6))
            
            if chart_type in ["line", "scatter"]:
                for col in y_columns:
                    ax.plot(df[x_column], df[col], label=col, 
                           marker='o' if chart_type == "scatter" else None)
                ax.set_xlabel(x_column)
                ax.legend()
            
            elif chart_type == "bar":
                if len(y_columns) == 1:
                    ax.bar(df[x_column], df[y_columns[0]])
                else:
                    x = np.arange(len(df[x_column]))
                    width = 0.8 / len(y_columns)
                    for i, col in enumerate(y_columns):
                        ax.bar(x + i * width, df[col], width, label=col)
                    ax.set_xticks(x + width * (len(y_columns) - 1) / 2)
                    ax.set_xticklabels(df[x_column])
                    ax.legend()
            
            elif chart_type == "pie" and y_columns:
                pie_data = df[y_columns[0]].value_counts() if df[y_columns[0]].dtype == 'object' else df.groupby(x_column)[y_columns[0]].sum()
                ax.pie(pie_data.values, labels=pie_data.index, autopct='%1.1f%%')
            
            elif chart_type == "histogram" and y_columns:
                ax.hist(df[y_columns[0]], bins=30)
                ax.set_xlabel(y_columns[0])
                ax.set_ylabel("Frequency")
            
            ax.set_title(result["title"])
            plt.tight_layout()
            
            # Save matplotlib figure
            if save_path:
                plt.savefig(save_path)
                result["image_path"] = save_path
            
            # Convert to HTML (basic)
            from io import BytesIO
            import base64
            
            buffer = BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()
            result["html"] = f'<img src="data:image/png;base64,{image_base64}" />'
            
            plt.close()
        
        # Add data summary
        result["data_summary"] = {
            "rows": len(df),
            "columns": len(df.columns),
            "x_column": x_column,
            "y_columns": y_columns,
            "data_types": df.dtypes.astype(str).to_dict()
        }
        
        # Add metadata
        result["metadata"] = {
            "library": "plotly" if "plotly" in str(type(fig)) else "matplotlib",
            "interactive": "plotly" in str(type(fig)),
            "chart_dimensions": {"width": 800, "height": 600}
        }
        
        logger.info(f"Chart generated successfully: {chart_type}")
        return result
        
    except ValueError as e:
        logger.warning(f"Chart generation validation error: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
        
    except Exception as e:
        logger.error(f"Chart generation failed: {e}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''