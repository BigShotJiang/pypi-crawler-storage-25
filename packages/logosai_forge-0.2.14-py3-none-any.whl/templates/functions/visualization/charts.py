"""visualization/charts — Various chart types (line, bar, pie, scatter, heatmap, histogram, box)."""

TEMPLATE_INFO = {
    "id": "visualization.charts",
    "name": "Chart Creator",
    "category": "visualization",
    "version": "1.0.0",
    "platform": "cross_platform",
    "required_imports": ["json"],
    "llm_customizable": ["chart_style", "color_scheme"],
}


def get_create_line_chart():
    return '''
async def _create_line_chart(self, data: list, x_key: str, y_keys: list, title: str = "Line Chart") -> dict:
    """Create interactive line chart (Plotly HTML)."""
    import json
    traces = []
    for y_key in y_keys:
        traces.append({"x": [d[x_key] for d in data], "y": [d[y_key] for d in data],
                        "type": "scatter", "mode": "lines+markers", "name": y_key})
    layout = {"title": title, "xaxis": {"title": x_key}, "yaxis": {"title": ", ".join(y_keys)}}
    html = f"<div id=\\"chart\\"></div><script src=\\"https://cdn.plot.ly/plotly-latest.min.js\\"></script><script>Plotly.newPlot(\\'chart\\',{json.dumps(traces)},{json.dumps(layout)})</script>"
    return {"html": html, "chart_type": "line", "answer": f"Line chart: {title}"}
'''


def get_create_bar_chart():
    return '''
async def _create_bar_chart(self, data: list, x_key: str, y_keys: list, title: str = "Bar Chart", grouped: bool = False) -> dict:
    """Create bar chart (grouped or stacked)."""
    import json
    barmode = "group" if grouped else "stack"
    traces = []
    for y_key in y_keys:
        traces.append({"x": [d[x_key] for d in data], "y": [d[y_key] for d in data], "type": "bar", "name": y_key})
    layout = {"title": title, "barmode": barmode}
    html = f"<div id=\\"chart\\"></div><script src=\\"https://cdn.plot.ly/plotly-latest.min.js\\"></script><script>Plotly.newPlot(\\'chart\\',{json.dumps(traces)},{json.dumps(layout)})</script>"
    return {"html": html, "chart_type": "bar", "answer": f"Bar chart: {title}"}
'''


def get_create_pie_chart():
    return '''
async def _create_pie_chart(self, labels: list, values: list, title: str = "Pie Chart") -> dict:
    """Create pie chart."""
    import json
    trace = [{"labels": labels, "values": values, "type": "pie"}]
    layout = {"title": title}
    html = f"<div id=\\"chart\\"></div><script src=\\"https://cdn.plot.ly/plotly-latest.min.js\\"></script><script>Plotly.newPlot(\\'chart\\',{json.dumps(trace)},{json.dumps(layout)})</script>"
    return {"html": html, "chart_type": "pie", "answer": f"Pie chart: {title}"}
'''


def get_create_scatter_chart():
    return '''
async def _create_scatter_chart(self, data: list, x_key: str, y_key: str, size_key: str = None, title: str = "Scatter Plot") -> dict:
    """Create scatter plot with optional bubble sizes."""
    import json
    trace = {"x": [d[x_key] for d in data], "y": [d[y_key] for d in data],
             "type": "scatter", "mode": "markers", "name": f"{x_key} vs {y_key}"}
    if size_key:
        trace["marker"] = {"size": [d.get(size_key, 10) for d in data]}
    layout = {"title": title, "xaxis": {"title": x_key}, "yaxis": {"title": y_key}}
    html = f"<div id=\\"chart\\"></div><script src=\\"https://cdn.plot.ly/plotly-latest.min.js\\"></script><script>Plotly.newPlot(\\'chart\\',[{json.dumps(trace)}],{json.dumps(layout)})</script>"
    return {"html": html, "chart_type": "scatter", "answer": f"Scatter plot: {title}"}
'''


def get_create_heatmap():
    return '''
async def _create_heatmap(self, z_data: list, x_labels: list = None, y_labels: list = None, title: str = "Heatmap") -> dict:
    """Create heatmap from 2D data matrix."""
    import json
    trace = {"z": z_data, "type": "heatmap", "colorscale": "Viridis"}
    if x_labels: trace["x"] = x_labels
    if y_labels: trace["y"] = y_labels
    layout = {"title": title}
    html = f"<div id=\\"chart\\"></div><script src=\\"https://cdn.plot.ly/plotly-latest.min.js\\"></script><script>Plotly.newPlot(\\'chart\\',[{json.dumps(trace)}],{json.dumps(layout)})</script>"
    return {"html": html, "chart_type": "heatmap", "answer": f"Heatmap: {title}"}
'''


def get_create_histogram():
    return '''
async def _create_histogram(self, values: list, bins: int = 20, title: str = "Histogram") -> dict:
    """Create histogram."""
    import json
    trace = [{"x": values, "type": "histogram", "nbinsx": bins}]
    layout = {"title": title}
    html = f"<div id=\\"chart\\"></div><script src=\\"https://cdn.plot.ly/plotly-latest.min.js\\"></script><script>Plotly.newPlot(\\'chart\\',{json.dumps(trace)},{json.dumps(layout)})</script>"
    return {"html": html, "chart_type": "histogram", "answer": f"Histogram: {title}"}
'''
