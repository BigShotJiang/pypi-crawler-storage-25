"""
LLM Response Cache System

Caches LLM responses to reduce API calls and improve performance.
"""

import json
import hashlib
import time
from pathlib import Path
from typing import Optional, Dict, Any
import threading
from collections import OrderedDict
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class LLMCache:
    """Simple LRU cache for LLM responses"""
    
    def __init__(self, max_size: int = 1000, ttl_hours: int = 24, cache_dir: Optional[Path] = None):
        """
        Initialize the cache.
        
        Args:
            max_size: Maximum number of cached items
            ttl_hours: Time to live in hours
            cache_dir: Optional directory for persistent cache
        """
        self.max_size = max_size
        self.ttl_seconds = ttl_hours * 3600
        self.cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self.lock = threading.Lock()
        self.cache_dir = cache_dir
        
        # Load persistent cache if directory provided
        if self.cache_dir:
            self.cache_dir = Path(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            self._load_persistent_cache()
            
    def _generate_key(self, prompt: str, model: str, temperature: float) -> str:
        """Generate cache key from parameters"""
        content = f"{prompt}|{model}|{temperature}"
        return hashlib.sha256(content.encode()).hexdigest()
        
    def get(self, prompt: str, model: str, temperature: float) -> Optional[str]:
        """
        Get cached response if available and not expired.
        
        Args:
            prompt: The prompt text
            model: Model name
            temperature: Temperature setting
            
        Returns:
            Cached response or None
        """
        # Temporarily disable cache for testing to avoid mock responses
        return None
        
        key = self._generate_key(prompt, model, temperature)
        
        with self.lock:
            if key in self.cache:
                entry = self.cache[key]
                
                # Check if expired
                if time.time() - entry['timestamp'] > self.ttl_seconds:
                    del self.cache[key]
                    return None
                    
                # Move to end (LRU)
                self.cache.move_to_end(key)
                
                logger.debug(f"Cache hit for key: {key[:8]}...")
                return entry['response']
                
        return None
        
    def set(self, prompt: str, model: str, temperature: float, response: str):
        """
        Cache a response.
        
        Args:
            prompt: The prompt text
            model: Model name
            temperature: Temperature setting
            response: The response to cache
        """
        key = self._generate_key(prompt, model, temperature)
        
        with self.lock:
            # Remove oldest if at capacity
            if len(self.cache) >= self.max_size:
                self.cache.popitem(last=False)
                
            # Add new entry
            self.cache[key] = {
                'prompt': prompt[:100],  # Store first 100 chars for debugging
                'model': model,
                'temperature': temperature,
                'response': response,
                'timestamp': time.time()
            }
            
            # Move to end
            self.cache.move_to_end(key)
            
            # Save to persistent cache if enabled
            if self.cache_dir:
                self._save_entry(key, self.cache[key])
                
            logger.debug(f"Cached response for key: {key[:8]}...")
            
    def clear(self):
        """Clear all cached entries"""
        with self.lock:
            self.cache.clear()
            
        if self.cache_dir:
            # Clear persistent cache
            for file in self.cache_dir.glob("*.json"):
                file.unlink()
                
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        with self.lock:
            total_entries = len(self.cache)
            
            if total_entries > 0:
                timestamps = [entry['timestamp'] for entry in self.cache.values()]
                oldest = datetime.fromtimestamp(min(timestamps))
                newest = datetime.fromtimestamp(max(timestamps))
                
                # Count by model
                model_counts = {}
                for entry in self.cache.values():
                    model = entry['model']
                    model_counts[model] = model_counts.get(model, 0) + 1
                    
                return {
                    'total_entries': total_entries,
                    'max_size': self.max_size,
                    'oldest_entry': oldest.isoformat(),
                    'newest_entry': newest.isoformat(),
                    'models': model_counts,
                    'hit_rate': 0.0  # Would need to track hits/misses
                }
            else:
                return {
                    'total_entries': 0,
                    'max_size': self.max_size,
                    'models': {},
                    'hit_rate': 0.0
                }
                
    def _save_entry(self, key: str, entry: Dict[str, Any]):
        """Save entry to persistent cache"""
        try:
            file_path = self.cache_dir / f"{key}.json"
            with open(file_path, 'w') as f:
                json.dump(entry, f)
        except Exception as e:
            logger.error(f"Failed to save cache entry: {e}")
            
    def _load_persistent_cache(self):
        """Load entries from persistent cache"""
        try:
            for file_path in self.cache_dir.glob("*.json"):
                with open(file_path, 'r') as f:
                    entry = json.load(f)
                    
                # Check if expired
                if time.time() - entry['timestamp'] <= self.ttl_seconds:
                    key = file_path.stem
                    self.cache[key] = entry
                else:
                    # Remove expired file
                    file_path.unlink()
                    
            logger.info(f"Loaded {len(self.cache)} entries from persistent cache")
            
        except Exception as e:
            logger.error(f"Failed to load persistent cache: {e}")


# Global cache instance
llm_cache = LLMCache(
    max_size=1000,
    ttl_hours=24,
    cache_dir=Path.home() / ".forge" / "llm_cache"
)