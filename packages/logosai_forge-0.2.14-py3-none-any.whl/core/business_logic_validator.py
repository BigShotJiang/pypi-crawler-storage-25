"""
Business Logic Validator
========================
생성된 비즈니스 로직이 요구사항을 충족하는지 검증하는 모듈
"""

import ast
import re
from typing import Dict, Any, List, Tuple, Optional
from dataclasses import dataclass
from loguru import logger


@dataclass
class BusinessLogicValidationResult:
    """비즈니스 로직 검증 결과"""
    is_valid: bool
    coverage_score: float  # 0.0 - 1.0
    missing_requirements: List[str]
    implemented_requirements: List[str]
    suggestions: List[str]
    details: Dict[str, Any]


class BusinessLogicValidator:
    """비즈니스 로직 검증기"""
    
    def __init__(self):
        """초기화"""
        # 요구사항 키워드 매핑
        self.requirement_patterns = {
            # 계산 관련
            "addition": [r"add", r"\+", r"sum", r"plus"],
            "subtraction": [r"subtract", r"-", r"minus"],
            "multiplication": [r"multiply", r"\*", r"times"],
            "division": [r"divide", r"/"],
            
            # 데이터 처리
            "filtering": [r"filter", r"where", r"select"],
            "sorting": [r"sort", r"order"],
            "aggregation": [r"aggregate", r"group", r"sum", r"count", r"average"],
            
            # 모니터링
            "threshold_check": [r"threshold", r"limit", r">=", r"<=", r">", r"<"],
            "alert": [r"alert", r"notify", r"warning", r"send"],
            "monitoring": [r"monitor", r"check", r"watch", r"observe"],
            
            # 조건부 로직
            "conditional": [r"if ", r"elif ", r"else:", r"when", r"condition"],
            "loop": [r"for ", r"while ", r"iterate"],
            
            # 에러 처리
            "error_handling": [r"try:", r"except", r"error", r"exception"],
            "validation": [r"valid", r"check", r"verify"],
            
            # 데이터 저장/로드
            "persistence": [r"save", r"store", r"persist", r"database", r"file"],
            "loading": [r"load", r"fetch", r"retrieve", r"get"],
        }
        
    def validate(
        self, 
        agent_code: str, 
        user_query: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> BusinessLogicValidationResult:
        """
        비즈니스 로직 검증
        
        Args:
            agent_code: 생성된 에이전트 코드
            user_query: 사용자 쿼리 (요구사항)
            metadata: 추가 메타데이터
            
        Returns:
            BusinessLogicValidationResult
        """
        logger.info(f"Validating business logic for query: {user_query[:100]}...")
        
        # 1. 사용자 쿼리에서 요구사항 추출
        requirements = self._extract_requirements(user_query)
        logger.info(f"Extracted {len(requirements)} requirements from query")
        
        # 2. 생성된 코드에서 구현된 기능 분석
        implemented = self._analyze_implemented_features(agent_code)
        logger.info(f"Found {len(implemented)} implemented features in code")
        
        # 3. 요구사항 매칭
        matched, missing = self._match_requirements(requirements, implemented, agent_code)
        
        # 4. 커버리지 계산
        coverage_score = len(matched) / len(requirements) if requirements else 1.0
        
        # 5. 제안사항 생성
        suggestions = self._generate_suggestions(missing, agent_code)
        
        # 6. 상세 정보 수집
        details = {
            "total_requirements": len(requirements),
            "matched_requirements": len(matched),
            "missing_requirements": len(missing),
            "code_analysis": {
                "has_error_handling": "try:" in agent_code,
                "has_logging": "logger." in agent_code or "log" in agent_code.lower(),
                "has_async": "async def" in agent_code,
                "has_docstrings": '"""' in agent_code or "'''" in agent_code,
                "function_count": agent_code.count("async def") + agent_code.count("def "),
                "complexity": self._estimate_complexity(agent_code)
            }
        }
        
        is_valid = coverage_score >= 0.7  # 70% 이상 구현되면 valid
        
        result = BusinessLogicValidationResult(
            is_valid=is_valid,
            coverage_score=coverage_score,
            missing_requirements=missing,
            implemented_requirements=matched,
            suggestions=suggestions,
            details=details
        )
        
        if is_valid:
            logger.info(f"✅ Business logic validation passed (coverage: {coverage_score:.1%})")
        else:
            logger.warning(f"⚠️  Business logic validation failed (coverage: {coverage_score:.1%})")
            logger.warning(f"Missing requirements: {missing}")
        
        return result
    
    def _extract_requirements(self, user_query: str) -> List[str]:
        """사용자 쿼리에서 요구사항 추출"""
        requirements = []
        query_lower = user_query.lower()
        
        for req_type, patterns in self.requirement_patterns.items():
            for pattern in patterns:
                if re.search(pattern, query_lower):
                    requirements.append(req_type)
                    break  # 중복 방지
        
        # 기본 요구사항 (항상 필요)
        if not requirements:
            requirements.append("basic_processing")
        
        return list(set(requirements))  # 중복 제거
    
    def _analyze_implemented_features(self, code: str) -> List[str]:
        """코드에서 구현된 기능 분석"""
        implemented = []
        code_lower = code.lower()
        
        # AST로 코드 구조 분석
        try:
            tree = ast.parse(code)
            
            # 함수/메서드 이름 분석
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_name = node.name.lower()
                    
                    # 함수 이름에서 기능 유추
                    for req_type, patterns in self.requirement_patterns.items():
                        if any(re.search(p, func_name) for p in patterns):
                            implemented.append(req_type)
        except:
            pass
        
        # 코드 내용으로 기능 확인
        for req_type, patterns in self.requirement_patterns.items():
            for pattern in patterns:
                if re.search(pattern, code_lower):
                    implemented.append(req_type)
                    break
        
        return list(set(implemented))  # 중복 제거
    
    def _match_requirements(
        self, 
        requirements: List[str], 
        implemented: List[str],
        code: str
    ) -> Tuple[List[str], List[str]]:
        """요구사항과 구현된 기능 매칭"""
        matched = []
        missing = []
        
        for req in requirements:
            if req in implemented:
                matched.append(req)
            else:
                # 유사 기능으로 대체 가능한지 확인
                if self._check_alternative_implementation(req, implemented, code):
                    matched.append(req)
                else:
                    missing.append(req)
        
        return matched, missing
    
    def _check_alternative_implementation(
        self,
        requirement: str,
        implemented: List[str],
        code: str
    ) -> bool:
        """대체 구현으로 요구사항이 충족되는지 확인"""
        
        # 유사 기능 매핑
        alternatives = {
            "addition": ["calculation", "arithmetic"],
            "subtraction": ["calculation", "arithmetic"],
            "multiplication": ["calculation", "arithmetic"],
            "division": ["calculation", "arithmetic"],
            "filtering": ["data_processing", "selection"],
            "sorting": ["data_processing", "ordering"],
            "aggregation": ["data_processing", "computation"],
        }
        
        if requirement in alternatives:
            for alt in alternatives[requirement]:
                if alt in implemented:
                    return True
        
        return False
    
    def _generate_suggestions(self, missing: List[str], code: str) -> List[str]:
        """누락된 요구사항에 대한 제안 생성"""
        suggestions = []
        
        for req in missing:
            if req == "error_handling":
                suggestions.append("Add try-except blocks for error handling")
            elif req == "validation":
                suggestions.append("Add input validation logic")
            elif req == "logging":
                suggestions.append("Add logging statements for debugging")
            elif req == "alert":
                suggestions.append("Implement alert/notification functionality")
            elif req == "persistence":
                suggestions.append("Add data persistence (save/load) methods")
            elif req in ["addition", "subtraction", "multiplication", "division"]:
                suggestions.append(f"Implement {req} operation")
            else:
                suggestions.append(f"Implement missing requirement: {req}")
        
        return suggestions
    
    def _estimate_complexity(self, code: str) -> str:
        """코드 복잡도 추정"""
        # 간단한 복잡도 지표
        lines = len(code.split('\n'))
        functions = code.count("def ")
        conditionals = code.count("if ") + code.count("elif ") + code.count("else:")
        loops = code.count("for ") + code.count("while ")
        
        complexity_score = (functions * 2) + conditionals + loops
        
        if complexity_score < 10:
            return "simple"
        elif complexity_score < 30:
            return "moderate"
        elif complexity_score < 60:
            return "complex"
        else:
            return "very_complex"
    
    def generate_test_cases(
        self,
        agent_code: str,
        user_query: str,
        validation_result: BusinessLogicValidationResult
    ) -> List[Dict[str, Any]]:
        """
        검증 결과를 기반으로 자동 테스트 케이스 생성
        
        Args:
            agent_code: 생성된 에이전트 코드
            user_query: 사용자 쿼리
            validation_result: 검증 결과
            
        Returns:
            테스트 케이스 리스트
        """
        test_cases = []
        
        # 구현된 요구사항별 테스트 케이스 생성
        for req in validation_result.implemented_requirements:
            test_case = self._generate_test_case_for_requirement(req, user_query)
            if test_case:
                test_cases.append(test_case)
        
        # 기본 테스트 케이스 (항상 포함)
        test_cases.insert(0, {
            "name": "basic_initialization",
            "description": "Test agent initialization",
            "test_type": "initialization",
            "expected_behavior": "Agent should initialize without errors"
        })
        
        test_cases.append({
            "name": "basic_process",
            "description": "Test basic processing",
            "test_type": "process",
            "input": {"query": user_query},
            "expected_behavior": "Agent should process query and return result"
        })
        
        return test_cases
    
    def _generate_test_case_for_requirement(
        self,
        requirement: str,
        user_query: str
    ) -> Optional[Dict[str, Any]]:
        """특정 요구사항에 대한 테스트 케이스 생성"""
        
        test_templates = {
            "addition": {
                "name": "test_addition",
                "description": "Test addition operation",
                "test_type": "calculation",
                "input": {"a": 5, "b": 3},
                "expected_output": 8
            },
            "subtraction": {
                "name": "test_subtraction",
                "description": "Test subtraction operation",
                "test_type": "calculation",
                "input": {"a": 10, "b": 4},
                "expected_output": 6
            },
            "monitoring": {
                "name": "test_monitoring",
                "description": "Test monitoring functionality",
                "test_type": "monitoring",
                "input": {"value": 15, "threshold": 10},
                "expected_behavior": "Should trigger alert when value exceeds threshold"
            },
            "error_handling": {
                "name": "test_error_handling",
                "description": "Test error handling",
                "test_type": "error",
                "input": {"invalid": "data"},
                "expected_behavior": "Should handle error gracefully"
            }
        }
        
        return test_templates.get(requirement)


# Example usage
if __name__ == "__main__":
    validator = BusinessLogicValidator()
    
    # Test code
    sample_code = '''
    async def process(self, query: str):
        try:
            result = self._calculate(query)
            if result > 10:
                logger.warning("Value exceeded threshold")
            return result
        except Exception as e:
            logger.error(f"Error: {e}")
            return None
    '''
    
    sample_query = "Create a calculator that adds numbers and sends alerts when result is over 10"
    
    result = validator.validate(sample_code, sample_query)
    print(f"Valid: {result.is_valid}")
    print(f"Coverage: {result.coverage_score:.1%}")
    print(f"Missing: {result.missing_requirements}")
    print(f"Suggestions: {result.suggestions}")

