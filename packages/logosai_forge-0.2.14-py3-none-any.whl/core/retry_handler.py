"""
Retry Handler for FORGE AI System
에러 복구 및 재시도 메커니즘
"""

import asyncio
import time
import logging
from typing import Any, Callable, Dict, List, Optional, TypeVar
from dataclasses import dataclass
from enum import Enum
import google.generativeai as genai
import openai
import os

logger = logging.getLogger(__name__)

T = TypeVar('T')


class RetryStrategy(Enum):
    """재시도 전략"""
    EXPONENTIAL_BACKOFF = "exponential_backoff"  # 지수 백오프
    LINEAR_BACKOFF = "linear_backoff"  # 선형 백오프
    IMMEDIATE = "immediate"  # 즉시 재시도


class ModelProvider(Enum):
    """LLM 모델 제공자"""
    GEMINI_LITE = "gemini-2.5-flash-lite"
    GEMINI_PRO = "gemini-1.5-pro"
    GEMINI_FLASH = "gemini-2.0-flash-exp"
    GPT_35_TURBO = "gpt-3.5-turbo"
    GPT_4 = "gpt-4"
    GPT_4_TURBO = "gpt-4-turbo-preview"
    CLAUDE_3 = "claude-3-opus"  # Future support
    TEMPLATE_FALLBACK = "template"  # 최종 폴백


@dataclass
class RetryConfig:
    """재시도 설정"""
    max_retries: int = 3
    initial_delay: float = 1.0
    max_delay: float = 30.0
    backoff_factor: float = 2.0
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL_BACKOFF
    timeout: float = 30.0
    fallback_models: List[ModelProvider] = None
    

@dataclass
class RetryResult:
    """재시도 결과"""
    success: bool
    result: Any
    attempts: int
    final_model: str
    errors: List[Dict[str, Any]]
    total_time: float


class RetryHandler:
    """재시도 핸들러"""
    
    def __init__(self, config: RetryConfig = None):
        self.config = config or RetryConfig()
        self._initialize_models()
        
    def _initialize_models(self):
        """모델 초기화"""
        # API 키 설정
        self.gemini_key = os.getenv('GEMINI_API_KEY') or os.getenv('GOOGLE_API_KEY')
        self.openai_key = os.getenv('OPENAI_API_KEY')
        
        # 기본 폴백 모델 순서
        if not self.config.fallback_models:
            self.config.fallback_models = [
                ModelProvider.GEMINI_LITE,
                ModelProvider.GEMINI_PRO,
                ModelProvider.GPT_35_TURBO,
                ModelProvider.GPT_4,
                ModelProvider.TEMPLATE_FALLBACK
            ]
    
    async def execute_with_retry(
        self,
        func: Callable,
        *args,
        **kwargs
    ) -> RetryResult:
        """재시도 로직으로 함수 실행"""
        
        start_time = time.time()
        errors = []
        attempts = 0
        
        for attempt in range(self.config.max_retries):
            attempts = attempt + 1
            
            try:
                # 타임아웃 적용
                result = await asyncio.wait_for(
                    func(*args, **kwargs),
                    timeout=self.config.timeout
                )
                
                # 성공
                return RetryResult(
                    success=True,
                    result=result,
                    attempts=attempts,
                    final_model=kwargs.get('model', 'unknown'),
                    errors=errors,
                    total_time=time.time() - start_time
                )
                
            except asyncio.TimeoutError as e:
                error_info = {
                    'attempt': attempts,
                    'error_type': 'timeout',
                    'error': str(e),
                    'model': kwargs.get('model', 'unknown')
                }
                errors.append(error_info)
                logger.warning(f"Attempt {attempts} timed out: {e}")
                
            except Exception as e:
                error_info = {
                    'attempt': attempts,
                    'error_type': type(e).__name__,
                    'error': str(e),
                    'model': kwargs.get('model', 'unknown')
                }
                errors.append(error_info)
                logger.warning(f"Attempt {attempts} failed: {e}")
            
            # 마지막 시도가 아니면 대기
            if attempt < self.config.max_retries - 1:
                delay = self._calculate_delay(attempt)
                logger.info(f"Waiting {delay:.1f}s before retry...")
                await asyncio.sleep(delay)
        
        # 모든 재시도 실패
        return RetryResult(
            success=False,
            result=None,
            attempts=attempts,
            final_model='none',
            errors=errors,
            total_time=time.time() - start_time
        )
    
    def _calculate_delay(self, attempt: int) -> float:
        """재시도 지연 시간 계산"""
        if self.config.strategy == RetryStrategy.IMMEDIATE:
            return 0
        
        elif self.config.strategy == RetryStrategy.LINEAR_BACKOFF:
            delay = self.config.initial_delay * (attempt + 1)
            
        elif self.config.strategy == RetryStrategy.EXPONENTIAL_BACKOFF:
            delay = self.config.initial_delay * (self.config.backoff_factor ** attempt)
        
        else:
            delay = self.config.initial_delay
        
        # 최대 지연 시간 제한
        return min(delay, self.config.max_delay)
    
    async def execute_with_model_fallback(
        self,
        query: str,
        task_type: str = "generate_code"
    ) -> RetryResult:
        """모델 폴백을 사용한 실행"""
        
        start_time = time.time()
        errors = []
        attempts = 0
        
        for model_provider in self.config.fallback_models:
            attempts += 1
            
            try:
                logger.info(f"Trying model: {model_provider.value}")
                
                if model_provider == ModelProvider.TEMPLATE_FALLBACK:
                    # 템플릿 기반 폴백
                    result = await self._template_fallback(query, task_type)
                else:
                    # LLM 모델 사용
                    result = await self._execute_llm(
                        model_provider,
                        query,
                        task_type
                    )
                
                if result and self._validate_result(result, task_type):
                    return RetryResult(
                        success=True,
                        result=result,
                        attempts=attempts,
                        final_model=model_provider.value,
                        errors=errors,
                        total_time=time.time() - start_time
                    )
                else:
                    raise ValueError("Invalid result from model")
                    
            except Exception as e:
                error_info = {
                    'attempt': attempts,
                    'model': model_provider.value,
                    'error_type': type(e).__name__,
                    'error': str(e)
                }
                errors.append(error_info)
                logger.warning(f"Model {model_provider.value} failed: {e}")
                
                # 다음 모델 시도 전 짧은 대기
                if attempts < len(self.config.fallback_models):
                    await asyncio.sleep(1)
        
        # 모든 모델 실패
        logger.error(f"All models failed after {attempts} attempts")
        return RetryResult(
            success=False,
            result=None,
            attempts=attempts,
            final_model='none',
            errors=errors,
            total_time=time.time() - start_time
        )
    
    async def _execute_llm(
        self,
        model_provider: ModelProvider,
        query: str,
        task_type: str
    ) -> str:
        """LLM 실행"""
        
        # Gemini 모델들
        if model_provider.value.startswith("gemini"):
            if not self.gemini_key:
                raise ValueError("Gemini API key not configured")
            
            genai.configure(api_key=self.gemini_key)
            model = genai.GenerativeModel(model_provider.value)
            
            prompt = self._build_prompt(query, task_type)
            response = model.generate_content(prompt)
            return response.text
        
        # OpenAI 모델들
        elif model_provider.value.startswith("gpt"):
            if not self.openai_key:
                raise ValueError("OpenAI API key not configured")
            
            openai.api_key = self.openai_key
            
            prompt = self._build_prompt(query, task_type)
            response = openai.ChatCompletion.create(
                model=model_provider.value,
                messages=[
                    {"role": "system", "content": "You are an expert Python developer."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=4000,
                temperature=0.7
            )
            return response.choices[0].message.content
        
        # Claude 모델들 (Future)
        elif model_provider.value.startswith("claude"):
            raise NotImplementedError("Claude support coming soon")
        
        else:
            raise ValueError(f"Unknown model provider: {model_provider.value}")
    
    def _build_prompt(self, query: str, task_type: str) -> str:
        """프롬프트 생성"""
        if task_type == "generate_code":
            return f"""Generate complete Python code for a LogosAI agent based on this query:

Query: {query}

Requirements:
1. Create a complete, working implementation
2. Use appropriate Python libraries
3. Include proper error handling
4. Return structured results

Generate ONLY the Python code for the _process_core_logic method.
The code should process the 'extracted_info' parameter and return a dictionary with results.

Generate the code now:"""
        
        elif task_type == "analyze_query":
            return f"""Analyze this query and extract key information:

Query: {query}

Extract:
1. Main intent (what the user wants to do)
2. Domain (finance, healthcare, etc.)
3. Required features
4. Complexity level

Provide a structured analysis:"""
        
        else:
            return query
    
    def _validate_result(self, result: str, task_type: str) -> bool:
        """결과 유효성 검증"""
        if not result or len(result) < 100:
            return False
        
        if task_type == "generate_code":
            # 코드 생성 결과 검증
            required_elements = ['def', 'return', 'try', 'except']
            return any(elem in result for elem in required_elements)
        
        return True
    
    async def _template_fallback(self, query: str, task_type: str) -> str:
        """템플릿 기반 폴백"""
        logger.info("Using template fallback")
        
        if task_type == "generate_code":
            return """
# Template-based fallback
data = extracted_info if isinstance(extracted_info, dict) else {'input': str(extracted_info)}

try:
    # Basic processing logic
    result = {
        'status': 'success',
        'data': data,
        'message': 'Processed with template fallback',
        'timestamp': datetime.now().isoformat()
    }
    return result
except Exception as e:
    logger.error(f'Error in template logic: {e}')
    return {'status': 'error', 'error': str(e)}
"""
        
        return "Template fallback response"


class SmartRetryManager:
    """스마트 재시도 매니저 - 학습 기능 포함"""
    
    def __init__(self):
        self.retry_handler = RetryHandler()
        self.success_history = {}  # 모델별 성공 기록
        self.failure_patterns = []  # 실패 패턴 기록
        
    async def execute_with_smart_retry(
        self,
        query: str,
        task_type: str = "generate_code"
    ) -> RetryResult:
        """스마트 재시도 실행"""
        
        # 1. 과거 성공 패턴 확인
        best_model = self._find_best_model_for_query(query)
        
        # 2. 모델 순서 재정렬
        if best_model:
            models = self._reorder_models(best_model)
            self.retry_handler.config.fallback_models = models
        
        # 3. 실행
        result = await self.retry_handler.execute_with_model_fallback(
            query, task_type
        )
        
        # 4. 결과 학습
        self._learn_from_result(query, result)
        
        return result
    
    def _find_best_model_for_query(self, query: str) -> Optional[ModelProvider]:
        """쿼리에 가장 적합한 모델 찾기"""
        # 간단한 키워드 기반 매칭
        query_lower = query.lower()
        
        if "complex" in query_lower or "advanced" in query_lower:
            return ModelProvider.GPT_4
        elif "simple" in query_lower or "basic" in query_lower:
            return ModelProvider.GEMINI_LITE
        elif "real-time" in query_lower or "streaming" in query_lower:
            return ModelProvider.GEMINI_PRO
        
        # 과거 성공 기록 확인
        for pattern, model in self.success_history.items():
            if pattern in query_lower:
                return model
        
        return None
    
    def _reorder_models(self, best_model: ModelProvider) -> List[ModelProvider]:
        """모델 순서 재정렬"""
        models = [
            ModelProvider.GEMINI_LITE,
            ModelProvider.GEMINI_PRO,
            ModelProvider.GPT_35_TURBO,
            ModelProvider.GPT_4,
            ModelProvider.TEMPLATE_FALLBACK
        ]
        
        # best_model을 맨 앞으로
        if best_model in models:
            models.remove(best_model)
            models.insert(0, best_model)
        
        return models
    
    def _learn_from_result(self, query: str, result: RetryResult):
        """결과로부터 학습"""
        if result.success:
            # 성공 패턴 저장
            key_words = self._extract_keywords(query)
            for word in key_words:
                self.success_history[word] = ModelProvider(result.final_model)
        else:
            # 실패 패턴 저장
            self.failure_patterns.append({
                'query': query[:100],
                'errors': result.errors,
                'timestamp': time.time()
            })
    
    def _extract_keywords(self, query: str) -> List[str]:
        """키워드 추출"""
        # 간단한 키워드 추출
        important_words = []
        for word in query.lower().split():
            if len(word) > 5:  # 5자 이상 단어만
                important_words.append(word)
        return important_words[:3]  # 상위 3개만


# 사용 예제
if __name__ == "__main__":
    async def test_retry():
        # 기본 재시도 핸들러
        handler = RetryHandler(
            RetryConfig(
                max_retries=3,
                strategy=RetryStrategy.EXPONENTIAL_BACKOFF,
                timeout=10.0
            )
        )
        
        # 모델 폴백 테스트
        result = await handler.execute_with_model_fallback(
            "Create a simple calculator agent",
            "generate_code"
        )
        
        print(f"Success: {result.success}")
        print(f"Attempts: {result.attempts}")
        print(f"Final Model: {result.final_model}")
        print(f"Total Time: {result.total_time:.2f}s")
        
        if result.errors:
            print("\nErrors encountered:")
            for error in result.errors:
                print(f"  - {error['model']}: {error['error_type']}")
        
        # 스마트 재시도 매니저
        smart_manager = SmartRetryManager()
        result2 = await smart_manager.execute_with_smart_retry(
            "Create a complex trading bot with real-time data analysis",
            "generate_code"
        )
        
        print(f"\nSmart Retry Result:")
        print(f"Success: {result2.success}")
        print(f"Final Model: {result2.final_model}")
    
    # 실행
    asyncio.run(test_retry())