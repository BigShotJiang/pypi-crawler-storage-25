#!/usr/bin/env python3
"""
FORGE AI 에러 처리 시스템
명확하고 유용한 에러 메시지 제공
"""

from typing import List, Dict, Optional


class AgentGenerationError(Exception):
    """
    에이전트 생성 실패 시 상세한 정보 제공
    """
    
    def __init__(
        self,
        message: str,
        code: str = None,
        line_number: int = None,
        suggestion: str = None,
        fix_history: List[Dict] = None,
        domain: str = None
    ):
        """
        Args:
            message: 에러 메시지
            code: 문제가 된 코드
            line_number: 에러 발생 라인
            suggestion: 해결 방안
            fix_history: 자가 수정 시도 이력
            domain: 도메인 정보
        """
        self.message = message
        self.code = code
        self.line_number = line_number
        self.suggestion = suggestion
        self.fix_history = fix_history or []
        self.domain = domain
        
        super().__init__(self.format_error())
    
    def format_error(self) -> str:
        """에러를 보기 좋게 포맷팅"""
        error_msg = f"\n{'='*60}\n"
        error_msg += f"❌ 에이전트 생성 실패\n"
        error_msg += f"{'='*60}\n\n"
        
        error_msg += f"📍 에러: {self.message}\n"
        
        if self.domain:
            error_msg += f"🎯 도메인: {self.domain}\n"
        
        if self.line_number:
            error_msg += f"📍 라인: {self.line_number}\n"
        
        if self.code:
            error_msg += f"\n📄 문제 코드:\n"
            error_msg += f"{'─'*40}\n"
            # 코드가 길면 처음 20줄만 표시
            code_lines = self.code.split('\n')
            if len(code_lines) > 20:
                display_code = '\n'.join(code_lines[:20])
                error_msg += display_code
                error_msg += f"\n... ({len(code_lines) - 20} more lines)\n"
            else:
                error_msg += self.code
            error_msg += f"\n{'─'*40}\n"
        
        if self.fix_history:
            error_msg += f"\n🔧 자가 수정 시도 이력:\n"
            for i, attempt in enumerate(self.fix_history, 1):
                error_msg += f"  {i}. {attempt.get('error', 'Unknown')} → {attempt.get('fix_applied', 'Unknown')}\n"
                if attempt.get('success'):
                    error_msg += f"     ✅ 성공\n"
                else:
                    error_msg += f"     ❌ 실패\n"
        
        if self.suggestion:
            error_msg += f"\n💡 해결 방안: {self.suggestion}\n"
        
        error_msg += f"{'='*60}\n"
        return error_msg


class DomainNotFoundError(Exception):
    """도메인 모듈을 찾을 수 없을 때"""
    
    def __init__(self, domain: str, available_domains: List[str] = None):
        self.domain = domain
        self.available_domains = available_domains or []
        
        message = f"도메인 '{domain}'을 찾을 수 없습니다."
        if self.available_domains:
            message += f"\n사용 가능한 도메인: {', '.join(self.available_domains[:10])}"
        
        super().__init__(message)


class BusinessLogicError(Exception):
    """비즈니스 로직 생성/파싱 실패"""
    
    def __init__(self, message: str, llm_response: str = None):
        self.message = message
        self.llm_response = llm_response
        
        error_msg = f"비즈니스 로직 에러: {message}"
        if llm_response:
            error_msg += f"\nLLM 응답 (처음 500자):\n{llm_response[:500]}"
        
        super().__init__(error_msg)


class SelfHealingError(Exception):
    """자가 수정 실패"""
    
    def __init__(self, message: str, attempts: int = 0, last_error: str = None):
        self.message = message
        self.attempts = attempts
        self.last_error = last_error
        
        error_msg = f"자가 수정 실패: {message}"
        if attempts:
            error_msg += f"\n시도 횟수: {attempts}"
        if last_error:
            error_msg += f"\n마지막 에러: {last_error}"
        
        super().__init__(error_msg)