#!/usr/bin/env python3
"""
ApiIntegrationAgent - Standalone Agent
==============================
REST API와 연동하는 에이전트

이 에이전트는 외부 의존성 없이 독립적으로 실행됩니다.
"""

import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ApiIntegrationAgent:
    """REST API와 연동하는 에이전트"""
    
    def __init__(self):
        """Initialize the agent"""
        self.name = "ApiIntegrationAgent"
        self.description = "REST API와 연동하는 에이전트"
        self.agent_type = "api_integration"
        logger.info(f"{self.name} initialized")
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Process user query"""
        try:
            logger.info(f"Processing query: {query}")
            
            # Validate input
            if not query:
                return {
                    "status": "error",
                    "error": "Empty query"
                }
            
            # Initialize context
            if context is None:
                context = {}
            
            # API 통합 로직
            # API 요청 시뮬레이션
            api_url = context.get('api_url', 'https://api.example.com/data')
            method = context.get('method', 'GET')
            
            # 실제 API 호출 대신 시뮬레이션
            simulated_response = {
                "api_url": api_url,
                "method": method,
                "status_code": 200,
                "response": {
                    "data": [
                        {"id": 1, "name": "Item 1", "value": 100},
                        {"id": 2, "name": "Item 2", "value": 200}
                    ],
                    "total": 2,
                    "timestamp": datetime.now().isoformat()
                }
            }
            
            return {
                "status": "success",
                "api_response": simulated_response,
                "message": "API 요청이 성공적으로 처리되었습니다"
            }
            
        except Exception as e:
            logger.error(f"Processing error: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent information"""
        return {
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "capabilities": self._get_capabilities()
        }
    
    def _get_capabilities(self) -> List[str]:
        """Get agent capabilities"""
        capabilities_map = {
            "calculator": ["basic_arithmetic", "expression_evaluation"],
            "data_analysis": ["data_processing", "statistical_analysis"],
            "api_integration": ["http_requests", "json_parsing"],
            "web_scraping": ["html_parsing", "data_extraction"],
            "general_purpose": ["text_processing", "general_tasks"]
        }
        return capabilities_map.get(self.agent_type, ["general_processing"])


# 메인 실행 함수
async def main():
    """테스트 실행"""
    agent = ApiIntegrationAgent()
    
    print(f"\n============================================================")
    print(f"{agent.name} 테스트")
    print('='*60)
    print(f"설명: {agent.description}")
    print(f"타입: {agent.agent_type}")
    print(f"기능: {', '.join(agent._get_capabilities())}")
    print('='*60)
    
    # 테스트 쿼리
    test_queries = ["API 데이터를 가져와줘", "서버 상태를 확인해줘", "데이터를 동기화해줘"]
    
    for query in test_queries:
        print(f"\n쿼리: {query}")
        result = await agent.process(query)
        print(f"결과: {json.dumps(result, ensure_ascii=False, indent=2)}")
    
    print(f"\n============================================================")
    print("테스트 완료!")


if __name__ == "__main__":
    asyncio.run(main())
