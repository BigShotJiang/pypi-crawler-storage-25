"""
Helper 함수 후처리 모듈
생성된 코드에서 정의되지 않은 함수를 감지하고 자동으로 추가
"""

import re
import ast
from typing import List, Dict, Set, Tuple
from loguru import logger
try:
    from forge.core.helper_library import HelperLibrary
except ImportError:
    try:
        from .helper_library import HelperLibrary
    except ImportError:
        import sys
        import os
        core_path = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, os.path.dirname(core_path))
        from core.helper_library import HelperLibrary

class HelperPostProcessor:
    """Helper 함수 후처리기"""
    
    def __init__(self):
        self.helper_library = HelperLibrary()
        
    def process_business_logic(self, code: str, query: str) -> str:
        """
        비즈니스 로직을 처리하여 누락된 helper 함수를 추가
        
        Args:
            code: 생성된 비즈니스 로직 코드
            query: 원본 사용자 쿼리
            
        Returns:
            helper 함수가 추가된 완전한 코드
        """
        try:
            # 1. 정의되지 않은 함수 찾기
            undefined_functions = self._find_undefined_functions(code)
            
            if not undefined_functions:
                logger.info("✅ 모든 함수가 정의되어 있음")
                return code
            
            logger.warning(f"⚠️ 정의되지 않은 함수 발견: {undefined_functions}")
            
            # 2. Helper 라이브러리에서 함수 찾기
            helper_functions = self._get_helper_functions(undefined_functions, query)
            
            # 3. 코드에 helper 함수 추가
            enhanced_code = self._inject_helper_functions(code, helper_functions)
            
            logger.info(f"✅ {len(helper_functions)} 개의 helper 함수 자동 추가")
            
            return enhanced_code
            
        except Exception as e:
            logger.error(f"❌ Helper 후처리 실패: {e}")
            return code
    
    def _find_undefined_functions(self, code: str) -> Set[str]:
        """코드에서 정의되지 않은 함수 찾기"""
        undefined = set()
        
        # 정의된 함수 찾기
        defined_functions = set()
        def_pattern = r'def\s+(\w+)\s*\('
        for match in re.finditer(def_pattern, code):
            defined_functions.add(match.group(1))
        
        # 호출된 함수 찾기
        called_functions = set()
        
        # 🔧 FIXED: 더 정확한 함수 호출 패턴 (메서드 체인과 logger 호출 제외)
        call_patterns = [
            r'(?<!\.)(?<!\w)(\w+)\s*\(',  # function() but not .function() and not part of word
            r'=\s*(?<!\.)(?<!\w)(\w+)\s*\(',     # = function( but not = .function(
            r'return\s+(?<!\.)(?<!\w)(\w+)\s*\(', # return function( but not return .function(
        ]
        
        for pattern in call_patterns:
            for match in re.finditer(pattern, code):
                func_name = match.group(1)
                # 내장 함수나 메서드 제외
                if not self._is_builtin_or_method(func_name):
                    called_functions.add(func_name)
        
        # 정의되지 않은 함수
        undefined = called_functions - defined_functions
        
        # 일반적인 함수명 필터링
        common_functions = {
            'print', 'len', 'str', 'int', 'float', 'bool', 'list', 'dict', 'set',
            'tuple', 'range', 'enumerate', 'zip', 'map', 'filter', 'sum', 'min',
            'max', 'abs', 'round', 'sorted', 'reversed', 'isinstance', 'hasattr',
            'getattr', 'setattr', 'open', 'type', 'format', 'logger', 'pd', 'np',
            # 🔧 FIXED: Logger와 관련된 모든 함수들 추가
            'info', 'error', 'warning', 'debug', 'critical', 'exception', 'log',
            'nfo', 'rror', 'arning', 'ebug',  # 잘린 버전들도 추가 (방어적)
            'get', 'update', 'append', 'extend', 'join', 'split', 'replace',
            'json', 'loads', 'dumps', 'DataFrame', 'Series', 'array', 'mean', 'std',
            # Agent response helper functions
            '_success_response', '_error_response', '_partial_response', '_stream_response',
            # Common constants  
            'INTEGRATION', 'CONFIG', 'SETTINGS', 'API_KEY', 'BASE_URL'
        }
        
        undefined = undefined - common_functions
        
        return undefined
    
    def _is_builtin_or_method(self, func_name: str) -> bool:
        """내장 함수나 메서드인지 확인"""
        builtins = {
            'print', 'len', 'str', 'int', 'float', 'bool', 'list', 'dict', 'set',
            'tuple', 'range', 'enumerate', 'zip', 'map', 'filter', 'sum', 'min',
            'max', 'abs', 'round', 'sorted', 'reversed', 'isinstance', 'hasattr',
            'if', 'else', 'elif', 'for', 'while', 'try', 'except', 'finally',
            'with', 'as', 'import', 'from', 'return', 'yield', 'pass', 'break',
            'continue', 'raise', 'assert', 'del', 'global', 'nonlocal', 'lambda'
        }
        
        return func_name in builtins
    
    def _get_helper_functions(self, undefined_functions: Set[str], query: str) -> Dict[str, str]:
        """Helper 라이브러리에서 필요한 함수 가져오기"""
        helper_functions = {}
        
        # 쿼리 기반 helper 함수 가져오기
        library_code = self.helper_library.get_helper_functions_for_query(query)
        
        # 각 undefined 함수에 대해 매칭 시도
        for func_name in undefined_functions:
            # 라이브러리 코드에서 함수 찾기
            pattern = rf'def\s+{func_name}\s*\([^)]*\):.*?(?=\n(?:def\s+\w+|$))'
            match = re.search(pattern, library_code, re.DOTALL)
            
            if match:
                helper_functions[func_name] = match.group(0)
                logger.info(f"✅ 라이브러리에서 '{func_name}' 함수 발견")
            else:
                # 유사한 이름의 함수 찾기
                similar = self._find_similar_function(func_name, library_code)
                if similar:
                    helper_functions[func_name] = similar
                    logger.info(f"✅ 유사 함수 발견: '{func_name}'")
                else:
                    # 기본 구현 생성
                    helper_functions[func_name] = self._generate_default_function(func_name)
                    logger.warning(f"⚠️ '{func_name}' 기본 구현 생성")
        
        return helper_functions
    
    def _find_similar_function(self, func_name: str, library_code: str) -> str:
        """유사한 이름의 함수 찾기"""
        # 함수 이름 변형 시도
        variations = [
            func_name.replace('_', ''),  # 언더스코어 제거
            'calculate_' + func_name,     # calculate_ 접두사
            'check_' + func_name,         # check_ 접두사
            'validate_' + func_name,      # validate_ 접두사
            'get_' + func_name,           # get_ 접두사
        ]
        
        for variation in variations:
            pattern = rf'def\s+{variation}\s*\([^)]*\):.*?(?=\n(?:def\s+\w+|$))'
            match = re.search(pattern, library_code, re.DOTALL)
            if match:
                # 원래 함수명으로 변경
                return match.group(0).replace(f'def {variation}', f'def {func_name}', 1)
        
        return None
    
    def _generate_default_function(self, func_name: str) -> str:
        """기본 함수 구현 생성"""
        # 함수명에서 힌트 추출
        func_name_lower = func_name.lower()
        
        if 'calculate' in func_name_lower or 'score' in func_name_lower:
            return f'''def {func_name}(*args, **kwargs):
    """자동 생성된 계산 함수"""
    # 기본 계산 로직
    if args:
        if len(args) == 1:
            return float(args[0]) if args[0] else 0.0
        elif len(args) == 2:
            try:
                val1 = float(args[0]) if args[0] else 0.0
                val2 = float(args[1]) if args[1] else 0.0
                return (val1 + val2) / 2
            except:
                return 0.0
    return 0.0'''
        
        elif 'validate' in func_name_lower or 'check' in func_name_lower:
            return f'''def {func_name}(data):
    """자동 생성된 검증 함수"""
    # 기본 검증 로직
    if data is None:
        return False
    if isinstance(data, (list, dict)):
        return len(data) > 0
    return bool(data)'''
        
        elif 'extract' in func_name_lower or 'get' in func_name_lower:
            return f'''def {func_name}(data, key=None):
    """자동 생성된 추출 함수"""
    # 기본 추출 로직
    if isinstance(data, dict) and key:
        return data.get(key, [])
    elif isinstance(data, (list, tuple)):
        return list(data)
    elif isinstance(data, str):
        return data.split()
    return []'''
        
        else:
            # 범용 기본 함수
            return f'''def {func_name}(*args, **kwargs):
    """자동 생성된 함수"""
    # 기본 구현
    if args:
        return args[0] if len(args) == 1 else args
    return kwargs if kwargs else None'''
    
    def _inject_helper_functions(self, code: str, helper_functions: Dict[str, str]) -> str:
        """코드에 helper 함수 주입"""
        if not helper_functions:
            return code
        
        # Helper 함수들을 하나의 블록으로 결합
        helper_block = "# ===== 자동 추가된 Helper 함수 =====\n\n"
        for func_name, func_code in helper_functions.items():
            helper_block += func_code + "\n\n"
        helper_block += "# ===== Helper 함수 끝 =====\n\n"
        
        # 코드 시작 부분에 helper 함수 추가
        # import 문 다음에 추가하도록 시도
        lines = code.split('\n')
        insert_index = 0
        
        # import 문들을 찾아서 그 다음 위치 찾기
        for i, line in enumerate(lines):
            if line.strip().startswith('import ') or line.strip().startswith('from '):
                insert_index = i + 1
            elif insert_index > 0 and line.strip() and not line.strip().startswith('#'):
                # import 이후 첫 번째 실제 코드
                break
        
        # Helper 함수 삽입
        if insert_index > 0:
            # import 문 다음에 삽입
            lines.insert(insert_index, helper_block)
        else:
            # 코드 맨 앞에 삽입
            return helper_block + code
        
        return '\n'.join(lines)
    
    def validate_and_fix(self, code: str, query: str) -> Tuple[bool, str]:
        """
        코드를 검증하고 필요시 수정
        
        Returns:
            (is_valid, fixed_code)
        """
        try:
            # 1. 문법 검증
            compile(code, '<string>', 'exec')
            
            # 2. 정의되지 않은 함수 검사
            undefined = self._find_undefined_functions(code)
            
            if undefined:
                logger.warning(f"⚠️ 정의되지 않은 함수 발견, 자동 수정 시도: {undefined}")
                fixed_code = self.process_business_logic(code, query)
                
                # 다시 검증
                try:
                    compile(fixed_code, '<string>', 'exec')
                    return True, fixed_code
                except SyntaxError as e:
                    logger.error(f"❌ 수정 후에도 문법 오류: {e}")
                    return False, code
            
            return True, code
            
        except SyntaxError as e:
            logger.error(f"❌ 문법 오류: {e}")
            # 🔍 DEBUG: 오류 발생 코드의 처음 10라인 로깅
            lines = code.split('\n')
            logger.error(f"🔍 오류 발생 코드 (처음 10라인):")
            for i, line in enumerate(lines[:10], 1):
                marker = ">>> " if i == e.lineno else "    "
                logger.error(f"{marker}Line {i}: {repr(line)}")
            return False, code