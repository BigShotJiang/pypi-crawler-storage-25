#!/usr/bin/env python3
"""
🧠 LLM 기반 코드 자동 수정 모듈
Google Gemini을 사용한 고급 Python 코드 에러 분석 및 수정
베스트 프랙티스 적응형 토큰 시스템 및 강화된 코드 파싱 적용
+ Enhanced Self-Healing Module 통합
"""

import asyncio
import logging
from typing import Dict, Any, Tuple, Optional
import os
import json
from datetime import datetime

# 강화된 토큰 관리 및 코드 파싱 시스템 import
from .smart_token_manager import SmartTokenManager, CodeComplexity, TokenStrategy
from .enhanced_code_parser import EnhancedCodeParser, ParsedResponse

# Enhanced Self-Healing Module import
try:
    from .business_logic_v2.self_healing import SelfHealingModule, HealingResult
    SELF_HEALING_AVAILABLE = True
    logger = logging.getLogger(__name__)
    logger.info("✅ Enhanced Self-Healing Module available")
except ImportError as e:
    SELF_HEALING_AVAILABLE = False
    logger = logging.getLogger(__name__)
    logger.warning(f"⚠️ Enhanced Self-Healing Module not available: {e}")

# LogosAI LLMClient import with fallback to direct Google Genai
try:
    from logosai.utils.llm_client import LLMClient
    LLMCLIENT_AVAILABLE = True
    logger.info("✅ LogosAI LLMClient available")
except ImportError as e:
    logger.warning(f"LogosAI LLMClient not available: {e}, trying direct Google Genai")
    try:
        from google import genai
        LLMCLIENT_AVAILABLE = False
        logger.info("✅ Direct Google Genai available")
    except ImportError:
        logger.error("Neither LogosAI LLMClient nor Google Genai available")
        LLMCLIENT_AVAILABLE = None


class CodeFixer:
    """🚀 베스트 프랙티스 LLM 기반 코드 수정 클래스
    
    주요 기능:
    - 적응형 토큰 관리 (자동 최적화)
    - 강화된 코드 파싱 (```python 마커 완벽 처리)
    - 실시간 토큰 측정 및 비용 최적화
    - 코드 완전성 검증 및 청킹 지원
    """
    
    def __init__(self, api_key: str = None):
        """
        초기화
        Args:
            api_key: Google API 키 (없으면 환경변수에서 가져옴)
        """
        self.api_key = api_key or os.getenv('GOOGLE_API_KEY')
        
        # 🚀 베스트 프랙티스 시스템 초기화
        self.token_manager = SmartTokenManager()
        self.code_parser = EnhancedCodeParser()
        
        # ✨ Enhanced Self-Healing Module 초기화
        if SELF_HEALING_AVAILABLE:
            self.self_healing = SelfHealingModule()
            logger.info("✅ Enhanced Self-Healing Module initialized in CodeFixer")
        else:
            self.self_healing = None
            logger.warning("⚠️ Self-Healing unavailable, using traditional rule-based fixes only")
        
        # 세션 메트릭 추적
        self.session_metrics = {
            'total_requests': 0,
            'successful_fixes': 0,
            'total_tokens_used': 0,
            'avg_response_time': 0,
            'complexity_distribution': {},
            'parsing_methods_used': {},
            'cost_breakdown': {},
            'self_healing_used': 0,  # 새로운 메트릭
            'self_healing_success': 0,
        }
        
        if not self.api_key:
            logger.warning("⚠️  Google API 키가 없습니다. 로컬 규칙 기반 수정만 사용합니다.")
            self.client = None
        else:
            # 🎯 기본 클라이언트는 중간 토큰으로 초기화 (나중에 동적 조정)
            try:
                if LLMCLIENT_AVAILABLE:
                    self.client = LLMClient(
                        provider="google",
                        model="gemini-2.5-flash-lite",
                        api_key=self.api_key,
                        temperature=0.5,
                        max_tokens=30000  # ⚡ 기본값 2000 → 4000으로 개선
                    )
                    logger.info("✅ 베스트 프랙티스 Google Gemini LLMClient 초기화 완료")
                elif LLMCLIENT_AVAILABLE is False:
                    self.client = genai.Client(api_key=self.api_key)
                    logger.info("✅ 직접 Google Genai 클라이언트 초기화 완료")
                else:
                    logger.error("❌ Google API 클라이언트를 초기화할 수 없습니다")
                    self.client = None
            except Exception as e:
                logger.error(f"❌ 클라이언트 초기화 실패: {e}")
                self.client = None
    
    def get_system_prompt(self) -> str:
        """시스템 프롬프트 - 코드만 출력하도록 강제"""
        return """You are a Python code fixer. You receive broken code and its error message.

CRITICAL RULES:
1. Output ONLY the fixed Python code inside a ```python code block.
2. Do NOT output any explanation, analysis, reasoning, or markdown text.
3. Fix ONLY the error — do not add features, comments, or refactor.
4. Preserve the original code structure, variable names, and style.
5. Return the COMPLETE fixed code, not just the changed lines.

Response format (STRICTLY follow this):
```python
<complete fixed code here>
```

Nothing else. No text before or after the code block."""

    def get_user_prompt(self, code: str, error: str, context: str = "") -> str:
        """간결한 사용자 프롬프트 — 코드 블록 출력을 강제"""
        return f"""Fix this Python code error. Return ONLY the complete fixed code in a ```python block.

Error:
{error}

Code:
```python
{code}
```

Remember: Output ONLY ```python ... ``` with the fixed code. No explanation."""

    def get_enhanced_system_prompt(self, strategy: TokenStrategy) -> str:
        """🚀 전략 맞춤형 Chain-of-Thought 시스템 프롬프트"""
        
        base_prompt = """당신은 세계 최고 수준의 Python 코드 에러 수정 전문가입니다.

## 🧠 **Chain-of-Thought 추론 프로세스 (내부 실행)**

### **1️⃣ 에러 진단 (Diagnostic Analysis)**
```
🔍 에러 해부:
- 에러 타입 분류: [SyntaxError/NameError/TypeError/etc]
- 발생 지점 핀포인트: [라인번호:컬럼번호]  
- 근본 원인 식별: [문법/의미/구조/컨텍스트]
- 에러 전파 경로: [호출 스택 추적]
```

### **2️⃣ 컨텍스트 분석 (Context Understanding)**
```
🧩 코드 구조 파악:
- 스코프 범위: [전역/함수/클래스/블록]
- 변수 생명주기: [정의위치→사용위치→소멸]
- 의존성 매핑: [import→function call→method access]
- 데이터 흐름: [input→processing→output]
```

### **3️⃣ 해결책 도출 (Solution Design)**
```
⚡ 최적 해결책:
- 후보 솔루션: [A안/B안/C안 비교분석]
- 최소 침습성: [변경 범위 최소화]
- 부작용 예측: [다른 코드에 미치는 영향]
- 검증 가능성: [수정 후 동작 예측]
```

### **4️⃣ 정밀 수정 (Precise Implementation)**  
```
🎯 코드 수정:
- 타겟 라인 식별: [정확한 수정 위치]
- 문법 완전성: [괄호/인덴트/구문 검증]
- 스타일 일관성: [기존 코딩 스타일 유지]
- 완성도 확인: [누락 부분 재검토]
```

### **5️⃣ 품질 검증 (Quality Assurance)**
```
✅ 최종 검증:
- 문법 검사: python -m py_compile [mental simulation]
- 논리 검증: 수정된 코드의 실행 흐름 시뮬레이션
- 완전성 검증: 모든 필수 요소 포함 여부
- 일관성 검증: 기존 코드베이스와의 조화
```

## 📋 **엄격한 출력 규칙**
1. **위 5단계를 내부적으로 완전히 수행한 후 결과만 출력**
2. **수정된 전체 코드만 ```python``` 블록으로 제공**
3. **주석, 설명, 메타데이터는 일체 포함하지 않음**
4. **원본 들여쓰기와 코딩 스타일 100% 보존**
5. **함수명, 변수명, 클래스명 임의 변경 금지**

## ⚠️ **중요 제약사항**
- 에러 해결에만 집중 (기능 추가/최적화 금지)
- 최소한의 변경으로 최대 효과 추구
- 원개발자의 의도 완전 보존
- Python 모범 사례 준수"""

        # 전략별 특화 지시사항
        if strategy.cost_tier == "premium":
            base_prompt += """

## 🏆 **프리미엄 모드 추가 지침**
- 대용량 코드의 구조적 무결성 최우선
- 복잡한 의존성 관계 신중히 고려
- 모듈간 인터페이스 호환성 보장
- 성능 영향 최소화하는 수정 방식 선택"""
        
        elif strategy.use_chunking:
            base_prompt += """

## 📦 **청킹 모드 추가 지침**  
- 현재 청크는 전체 코드의 일부임을 인지
- 청크 경계에서의 컨텍스트 유지
- 다른 청크와의 상호작용 고려
- 청크 단위 수정이 전체에 미치는 영향 예측"""
        
        elif strategy.cost_tier == "basic":
            base_prompt += """

## 🎯 **기본 모드 추가 지침**
- 단순하고 직접적인 수정 방식 선호
- 복잡한 리팩토링보다는 직관적 해결책
- 명확하고 이해하기 쉬운 수정 적용"""
        
        return base_prompt

    async def _fix_with_chunking(
        self, 
        code: str, 
        error: str, 
        context: str,
        strategy: TokenStrategy,
        metrics: Dict[str, Any]
    ) -> Tuple[bool, str, str]:
        """대용량 코드를 청크 단위로 나누어서 수정"""
        logger.info(f"📦 청킹 모드로 대용량 코드 수정 시작: {len(code)} chars")
        
        # 코드를 청크로 분할
        chunks = self.token_manager.split_code_into_chunks(code, strategy.chunk_size or 800)
        
        if len(chunks) <= 1:
            # 청킹이 필요하지 않은 경우 일반 처리
            logger.warning("청킹 요청되었지만 단일 청크로 처리")
            strategy.use_chunking = False
            return await self.fix_with_llm(code, error, context)
        
        fixed_chunks = []
        total_changes = 0
        
        for i, chunk in enumerate(chunks):
            logger.info(f"📦 청크 {i+1}/{len(chunks)} 수정 중...")
            
            # 각 청크를 개별적으로 수정
            chunk_context = f"전체 코드의 일부 (청크 {i+1}/{len(chunks)})\n{context}"
            success, fixed_chunk, explanation = await self.fix_with_llm(
                chunk, error, chunk_context
            )
            
            if success and fixed_chunk != chunk:
                fixed_chunks.append(fixed_chunk)
                total_changes += 1
                logger.info(f"✅ 청크 {i+1} 수정 완료")
            else:
                fixed_chunks.append(chunk)  # 수정되지 않은 경우 원본 유지
                logger.info(f"⚪ 청크 {i+1} 변경사항 없음")
        
        # 청크들을 다시 합치기
        final_code = '\n'.join(fixed_chunks)
        
        if total_changes > 0:
            explanation = f"대용량 코드를 {len(chunks)}개 청크로 분할하여 수정함 ({total_changes}개 청크에서 변경사항 적용)"
            return True, final_code, explanation
        else:
            return False, code, "청킹 처리했지만 수정할 내용이 없음"

    def _update_session_metrics(
        self,
        success: bool,
        complexity: str,
        tokens_used: int,
        processing_time: float,
        parsing_method: str,
        cost_tier: str
    ):
        """세션 메트릭 업데이트"""
        self.session_metrics['total_requests'] += 1
        
        if success:
            self.session_metrics['successful_fixes'] += 1
        
        self.session_metrics['total_tokens_used'] += tokens_used
        
        # 평균 응답 시간 계산
        total_requests = self.session_metrics['total_requests']
        current_avg = self.session_metrics['avg_response_time']
        self.session_metrics['avg_response_time'] = (
            (current_avg * (total_requests - 1) + processing_time) / total_requests
        )
        
        # 복잡도 분포 업데이트
        if complexity not in self.session_metrics['complexity_distribution']:
            self.session_metrics['complexity_distribution'][complexity] = 0
        self.session_metrics['complexity_distribution'][complexity] += 1
        
        # 파싱 방법 분포 업데이트
        if parsing_method not in self.session_metrics['parsing_methods_used']:
            self.session_metrics['parsing_methods_used'][parsing_method] = 0
        self.session_metrics['parsing_methods_used'][parsing_method] += 1
        
        # 비용 분석 업데이트
        cost_info = self.token_manager.get_cost_estimation(tokens_used, cost_tier)
        if cost_tier not in self.session_metrics['cost_breakdown']:
            self.session_metrics['cost_breakdown'][cost_tier] = {
                'requests': 0, 
                'tokens': 0, 
                'estimated_cost': 0.0
            }
        
        self.session_metrics['cost_breakdown'][cost_tier]['requests'] += 1
        self.session_metrics['cost_breakdown'][cost_tier]['tokens'] += tokens_used
        self.session_metrics['cost_breakdown'][cost_tier]['estimated_cost'] += cost_info['estimated_cost_usd']

    def _generate_enhanced_explanation(
        self,
        original_code: str,
        fixed_code: str,
        error: str,
        parsed_result: ParsedResponse,
        metrics: Dict[str, Any]
    ) -> str:
        """강화된 수정 설명 생성"""
        base_explanation = parsed_result.explanation or self.generate_explanation(original_code, fixed_code, error)
        
        # 상세 정보 추가
        details = [
            f"🎯 복잡도: {metrics['complexity']}",
            f"🔍 파싱: {parsed_result.parsing_method}",
            f"✨ 신뢰도: {parsed_result.confidence:.1%}",
            f"📊 토큰: {metrics['final_max_tokens']}"
        ]
        
        enhanced_explanation = f"{base_explanation}\n\n📈 처리 상세: {' | '.join(details)}"
        
        # 주의사항 추가
        if parsed_result.issues:
            enhanced_explanation += f"\n⚠️ 주의사항: {', '.join(parsed_result.issues)}"
        
        if not parsed_result.is_complete:
            enhanced_explanation += "\n🔧 권장: 수정 결과를 검토해주세요"
        
        return enhanced_explanation

    def get_session_metrics(self) -> Dict[str, Any]:
        """현재 세션의 메트릭 반환"""
        success_rate = (
            self.session_metrics['successful_fixes'] / 
            max(1, self.session_metrics['total_requests'])
        ) * 100
        
        total_cost = sum(
            tier_data['estimated_cost'] 
            for tier_data in self.session_metrics['cost_breakdown'].values()
        )
        
        return {
            **self.session_metrics,
            'success_rate_percent': round(success_rate, 1),
            'total_estimated_cost_usd': round(total_cost, 4),
            'token_manager_metrics': self.token_manager.export_metrics(),
            'optimization_suggestions': self.token_manager.get_optimization_suggestions()
        }

    async def fix_with_llm(self, code: str, error: str, context: str = "") -> Tuple[bool, str, str]:
        """
        🚀 베스트 프랙티스 LLM 기반 코드 수정
        - 적응형 토큰 할당
        - 강화된 코드 파싱
        - 실시간 메트릭 추적
        
        Returns:
            (success, fixed_code, explanation)
        """
        if not self.client:
            return False, "", "Google API 키가 설정되지 않았습니다."
        
        start_time = datetime.now()
        
        try:
            # 🎯 단순화된 설정 - API가 알아서 처리
            logger.info(f"🧠 Google Gemini 코드 수정 요청")
            
            # 🎯 클라이언트 설정 (단순화)
            if LLMCLIENT_AVAILABLE:
                # 고정된 안전한 설정 사용
                self.client.max_tokens = 30000  # Gemini API 안전 범위
                self.client.temperature = 0.5
                
                if not hasattr(self.client, '_initialized') or not self.client._initialized:
                    await self.client.initialize()
                
                messages = [
                    {"role": "system", "content": self.get_system_prompt()},
                    {"role": "user", "content": self.get_user_prompt(code, error, context)}
                ]
                
                # 🚀 향상된 Google Gemini 호출
                response = await self.client.invoke_messages(messages)
                raw_response = response.content if hasattr(response, 'content') else str(response)
                
                # 🔍 API 응답 상세 로깅
                logger.info(f"🔍 LLMClient 응답 분석:")
                logger.info(f"  - 응답 길이: {len(raw_response)} 글자")
                logger.info(f"  - 응답 타입: {type(response)}")
                if hasattr(response, 'usage'):
                    logger.info(f"  - 토큰 사용량: {response.usage}")
                logger.info(f"  - 응답 끝부분: ...{raw_response[-100:]}")
            else:
                # Direct Google Genai 호출
                prompt = self.get_system_prompt() + "\n\n" + self.get_user_prompt(code, error, context)
                response = await self.client.models.generate_content(
                    model="gemini-2.5-flash-lite",
                    contents=[{"parts": [{"text": prompt}]}],
                    generation_config={"max_output_tokens": 30000}  # 단순화
                )
                raw_response = response.text if hasattr(response, 'text') else str(response)
                
                # 🔍 직접 API 응답 상세 로깅  
                logger.info(f"🔍 Direct Genai 응답 분석:")
                logger.info(f"  - 응답 길이: {len(raw_response)} 글자")
                logger.info(f"  - 응답 타입: {type(response)}")
                if hasattr(response, 'usage_metadata'):
                    logger.info(f"  - 토큰 사용량: {response.usage_metadata}")
                if hasattr(response, 'candidates') and response.candidates:
                    candidate = response.candidates[0]
                    if hasattr(candidate, 'finish_reason'):
                        logger.info(f"  - 완료 이유: {candidate.finish_reason}")
                logger.info(f"  - 응답 끝부분: ...{raw_response[-100:]}")
            
            # 🎯 공통 파싱 과정
            logger.info(f"🔍 파싱 전 원본 응답 검사:")
            logger.info(f"  - 코드 블록 개수: {raw_response.count('```')}")
            logger.info(f"  - Python 블록 여부: {'```python' in raw_response}")
            logger.info(f"  - 응답이 완전한가: {raw_response.endswith('```') if '```' in raw_response else 'N/A'}")
            
            parsed_result = self.code_parser.parse_ai_response(
                raw_response, code, error
            )
            
            # 파싱 결과 상세 로깅
            logger.info(f"🔍 파싱 결과 분석:")
            logger.info(f"  - 파싱 성공: {bool(parsed_result.code)}")
            logger.info(f"  - 신뢰도: {parsed_result.confidence}")
            logger.info(f"  - 완전성: {parsed_result.is_complete}")
            logger.info(f"  - 파싱 방법: {parsed_result.parsing_method}")
            logger.info(f"  - 이슈들: {parsed_result.issues}")
            if parsed_result.code:
                logger.info(f"  - 파싱된 코드 길이: {len(parsed_result.code)} 글자")
                logger.info(f"  - 파싱된 코드 끝부분: ...{parsed_result.code[-50:]}")
            
            # 🎯 결과 검증
            if not parsed_result.code or parsed_result.confidence < 0.3:
                logger.warning(f"⚠️ 파싱 신뢰도 낮음: {parsed_result.confidence:.2f}")
                return False, "", f"파싱 실패: {', '.join(parsed_result.issues)}"
            
            if parsed_result.code == code:
                return False, "", "LLM이 유효한 수정을 제공하지 못했습니다."
            
            # 🎯 성공 반환
            processing_time = (datetime.now() - start_time).total_seconds()
            logger.info(f"✅ 처리 완료 - 시간: {processing_time:.2f}초")
            
            explanation = parsed_result.explanation or f"코드 수정 완료 (방법: {parsed_result.parsing_method})"
            logger.info(f"✅ 코드 수정 완료: {parsed_result.parsing_method}, 신뢰도: {parsed_result.confidence:.2f}")
            return True, parsed_result.code, explanation
            
        except Exception as e:
            processing_time = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ LLM 수정 실패 (시간: {processing_time:.2f}초): {e}")
            return False, "", f"LLM 수정 중 오류 발생: {str(e)}"

    def fix_with_rules(self, code: str, error: str) -> Tuple[bool, str, str]:
        """
        규칙 기반 코드 수정 (LLM 없이)
        """
        logger.info(f"🔧 규칙 기반 수정 시도: {error[:50]}...")
        
        fixed_code = code
        changes = []
        
        # SyntaxError 수정
        if "SyntaxError" in error:
            if "unexpected EOF" in error.lower() or "정의되지 않은" in error:
                # 괄호 매칭 수정
                open_parens = code.count('(')
                close_parens = code.count(')')
                if open_parens > close_parens:
                    fixed_code = code + ')' * (open_parens - close_parens)
                    changes.append(f"누락된 닫는 괄호 {open_parens - close_parens}개 추가")
                
                # 따옴표 매칭 수정
                if code.count('"') % 2 != 0:
                    if not code.endswith('"'):
                        fixed_code = fixed_code + '"'
                        changes.append("누락된 닫는 따옴표 추가")
                
                if code.count("'") % 2 != 0:
                    if not code.endswith("'"):
                        fixed_code = fixed_code + "'"
                        changes.append("누락된 닫는 작은따옴표 추가")
                        
            elif "invalid syntax" in error.lower():
                # 콜론 추가 (if, for, while, def, class)
                lines = code.split('\n')
                for i, line in enumerate(lines):
                    stripped = line.strip()
                    if any(stripped.startswith(kw) for kw in ['if ', 'for ', 'while ', 'def ', 'class ', 'elif ', 'else', 'try', 'except', 'finally']):
                        if not stripped.endswith(':'):
                            lines[i] = line + ':'
                            changes.append(f"라인 {i+1}에 콜론 추가")
                
                fixed_code = '\n'.join(lines)
        
        # IndentationError 수정
        elif "IndentationError" in error:
            lines = code.split('\n')
            fixed_lines = []
            for line in lines:
                if line.strip():  # 빈 줄이 아닌 경우
                    if not line.startswith('    ') and not line.startswith('\t'):
                        # 들여쓰기가 필요한 라인인지 확인
                        if any(prev_line.strip().endswith(':') for prev_line in fixed_lines[-1:] if prev_line.strip()):
                            fixed_lines.append('    ' + line.lstrip())
                            changes.append("들여쓰기 추가")
                        else:
                            fixed_lines.append(line)
                    else:
                        fixed_lines.append(line)
                else:
                    fixed_lines.append(line)
            fixed_code = '\n'.join(fixed_lines)
        
        # Import 오류 수정
        elif "ImportError" in error or "ModuleNotFoundError" in error:
            if "numpy" in error:
                fixed_code = "import numpy as np\n" + code
                changes.append("numpy import 추가")
            elif "pandas" in error:
                fixed_code = "import pandas as pd\n" + code
                changes.append("pandas import 추가")
            elif "requests" in error:
                fixed_code = "import requests\n" + code
                changes.append("requests import 추가")
        
        if changes:
            explanation = ", ".join(changes) + "."
            logger.info(f"✅ 규칙 기반 수정 완료: {explanation}")
            return True, fixed_code, explanation
        
        logger.warning("⚠️  규칙 기반 수정 실패")
        return False, code, "자동 수정할 수 없는 에러입니다."

    def generate_explanation(self, original: str, fixed: str, error: str) -> str:
        """수정 설명 생성"""
        if len(fixed) > len(original):
            return f"코드에 누락된 부분을 추가했습니다. (에러: {error.split(':')[0] if ':' in error else error})"
        elif len(fixed) < len(original):
            return f"잘못된 부분을 제거했습니다. (에러: {error.split(':')[0] if ':' in error else error})"
        else:
            return f"코드 구조를 수정했습니다. (에러: {error.split(':')[0] if ':' in error else error})"

    def _is_simple_syntax_error(self, error: str) -> bool:
        """Check if error is a simple syntax error fixable by line-targeted rules.
        Structural errors (expected except/finally) require LLM understanding."""
        if any(p in error.lower() for p in ["expected 'except'", "expected 'finally'"]):
            return False
        return any(p in error for p in ['SyntaxError', 'IndentationError'])

    def _extract_error_line(self, error: str) -> Optional[int]:
        """Extract line number from error message."""
        import re
        match = re.search(r'line\s+(\d+)', error, re.IGNORECASE)
        return int(match.group(1)) if match else None

    def fix_with_targeted_rules(self, code: str, error: str) -> Tuple[bool, str, str]:
        """
        Line-targeted rule-based fix for simple SyntaxError/IndentationError.
        Much faster than LLM and doesn't over-correct unrelated code.
        """
        line_no = self._extract_error_line(error)
        if not line_no:
            return False, code, "라인 번호를 추출할 수 없습니다."

        lines = code.split('\n')
        if line_no < 1 or line_no > len(lines):
            return False, code, "라인 번호가 범위를 벗어났습니다."

        target_idx = line_no - 1
        target_line = lines[target_idx]
        changes = []

        if 'SyntaxError' in error:
            # Fix leading zeros in decimal integers (e.g., 0123 → 123)
            import re as _re
            if 'leading zeros' in error.lower():
                fixed_line = _re.sub(r'\b0+(\d+)\b', lambda m: m.group(1), target_line)
                if fixed_line != target_line:
                    lines[target_idx] = fixed_line
                    changes.append(f"라인 {line_no}의 leading zeros 제거")

            # Fix unclosed brackets on the target line
            if not changes:
                # For curly braces, skip f-string content: f"...{expr}..."
                # Count only real bracket imbalance outside strings
                line_for_brackets = target_line
                # Strip f-string interpolation braces from counting
                import re as _re2
                fstring_stripped = _re2.sub(r'f["\'].*?["\']', '', line_for_brackets)

                open_p = target_line.count('(') - target_line.count(')')
                open_b = target_line.count('[') - target_line.count(']')
                # Use f-string-stripped version for curly braces
                open_c = fstring_stripped.count('{') - fstring_stripped.count('}')

                suffix = ''
                if open_p > 0:
                    suffix += ')' * open_p
                    changes.append(f"라인 {line_no}에 닫는 괄호 {open_p}개 추가")
                if open_b > 0:
                    suffix += ']' * open_b
                    changes.append(f"라인 {line_no}에 닫는 대괄호 {open_b}개 추가")
                if open_c > 0:
                    suffix += '}' * open_c
                    changes.append(f"라인 {line_no}에 닫는 중괄호 {open_c}개 추가")

                if suffix:
                    lines[target_idx] = target_line.rstrip() + suffix

            # Fix unclosed string quotes (only if no bracket fix was applied)
            if not changes:
                stripped = target_line.rstrip()
                if stripped.count('"') % 2 != 0:
                    lines[target_idx] = stripped + '"'
                    changes.append(f"라인 {line_no}에 닫는 따옴표 추가")
                elif stripped.count("'") % 2 != 0:
                    lines[target_idx] = stripped + "'"
                    changes.append(f"라인 {line_no}에 닫는 작은따옴표 추가")

            # Fix missing colon
            if not changes and 'invalid syntax' in error.lower():
                stripped = target_line.strip()
                keywords = ['if ', 'for ', 'while ', 'def ', 'class ', 'elif ', 'else', 'try', 'except', 'finally', 'with ']
                if any(stripped.startswith(kw) for kw in keywords) and not stripped.endswith(':'):
                    lines[target_idx] = target_line.rstrip() + ':'
                    changes.append(f"라인 {line_no}에 콜론 추가")

            # "expected 'except' or 'finally'" — structural error, too complex for line-targeted fix.
            # Inserting except blindly creates infinite loops. Delegate to LLM.
            # (intentionally no handling here)

        elif 'IndentationError' in error:
            # Check if previous line ends with colon → this line needs indent
            if target_idx > 0:
                prev_stripped = lines[target_idx - 1].strip()
                if prev_stripped.endswith(':'):
                    current_stripped = target_line.lstrip()
                    prev_indent = len(lines[target_idx - 1]) - len(lines[target_idx - 1].lstrip())
                    lines[target_idx] = ' ' * (prev_indent + 4) + current_stripped
                    changes.append(f"라인 {line_no}의 들여쓰기 수정")

        if changes:
            fixed_code = '\n'.join(lines)
            explanation = ', '.join(changes)
            logger.info(f"✅ 라인 타겟 규칙 수정 완료: {explanation}")
            return True, fixed_code, explanation

        return False, code, "타겟 규칙으로 수정할 수 없습니다."

    async def fix_code(self, code: str, error: str, context: str = "") -> Tuple[bool, str, str]:
        """
        🚀 베스트 프랙티스 메인 코드 수정 함수
        - ⚡ 단순 에러 → 빠른 라인 타겟 규칙 수정 (즉시, 과교정 없음)
        - Enhanced Self-Healing (빠른 AST 기반 수정)
        - Google Gemini (복잡한 에러 분석)
        - 규칙 기반 폴백
        """
        # 입력 검증
        if not code or not error:
            return False, code, "코드나 에러 메시지가 없습니다."

        logger.info(f"🚀 코드 수정 시작: {len(code)} chars, {len(error)} chars error")

        # 0단계: 단순 에러 → 빠른 라인 타겟 규칙 (SyntaxError/IndentationError)
        # LLM보다 수천 배 빠르고 해당 라인만 수정하므로 과교정 없음
        if self._is_simple_syntax_error(error):
            logger.info("⚡ 단순 SyntaxError/IndentationError 감지 → 빠른 라인 타겟 수정 시도")
            success, fixed_code, explanation = self.fix_with_targeted_rules(code, error)
            if success:
                return True, fixed_code, f"⚡ 빠른 수정: {explanation}"
            logger.info("⚡ 라인 타겟 수정 실패 → Self-Healing/LLM으로 계속")

        # 1단계: Enhanced Self-Healing (빠르고 로컬)
        # Self-Healing은 구문(syntax/indentation) 수정에만 효과적.
        # 의미론적 에러(NameError, TypeError 등)는 건너뛰고 LLM으로 보낸다.
        semantic_errors = ('NameError', 'TypeError', 'AttributeError', 'ValueError',
                           'KeyError', 'IndexError', 'ZeroDivisionError', 'FileNotFoundError',
                           'ImportError', 'ModuleNotFoundError')
        is_semantic_error = any(e in error for e in semantic_errors)

        if self.self_healing and not is_semantic_error:
            logger.info("✨ Enhanced Self-Healing 시도...")
            self.session_metrics['self_healing_used'] += 1

            try:
                # 에러 정보 파싱
                error_info = self._parse_error_info(error)

                # Self-Healing 실행
                result: HealingResult = self.self_healing.heal(code, error_info)

                if result.success and result.confidence > 0.7:
                    logger.info(f"✅ Self-Healing 성공 (신뢰도: {result.confidence:.2f})")
                    self.session_metrics['self_healing_success'] += 1

                    explanation = f"🔧 Self-Healing: {', '.join(result.fixes_applied)}"
                    if result.suggestions:
                        explanation += f" | 제안: {', '.join(result.suggestions[:2])}"

                    return True, result.healed_code, explanation
                elif result.success:
                    logger.info(f"⚠️ Self-Healing 부분 성공 (신뢰도: {result.confidence:.2f}) - LLM으로 재검증")
                    # 낮은 신뢰도면 LLM으로 재검증
                else:
                    logger.info(f"⚠️ Self-Healing 실패: {result.error_details}")
            except Exception as e:
                logger.warning(f"Self-Healing 예외: {e}")
        elif is_semantic_error:
            logger.info(f"⏩ 의미론적 에러 감지 → Self-Healing 건너뛰고 LLM으로")
        
        # 2단계: Google Gemini (LLM 기반)
        if self.client:
            logger.info("🧠 Google Gemini 시도...")
            success, fixed_code, explanation = await self.fix_with_llm(code, error, context)
            if success:
                logger.info("✅ Google Gemini 수정 성공")
                return True, fixed_code, f"🧠 Gemini: {explanation}"
        
        # 3단계: 규칙 기반 폴백
        logger.info("🔧 규칙 기반 수정으로 폴백")
        success, fixed_code, explanation = self.fix_with_rules(code, error)
        if success:
            return True, fixed_code, f"🔧 규칙: {explanation}"
        
        # 4단계: 최종 실패
        logger.warning("❌ 모든 수정 방법 실패")
        return False, code, "자동 수정에 실패했습니다. 수동으로 확인해주세요."
    
    def _parse_error_info(self, error: str) -> Optional[Dict]:
        """에러 메시지에서 정보 추출"""
        error_info = {}
        
        try:
            # 라인 번호 추출
            if 'line' in error.lower():
                import re
                line_match = re.search(r'line\s+(\d+)', error, re.IGNORECASE)
                if line_match:
                    error_info['line_number'] = int(line_match.group(1))
            
            # 에러 타입 추출
            error_types = ['SyntaxError', 'IndentationError', 'NameError', 'TypeError', 
                          'ValueError', 'AttributeError', 'ImportError']
            for err_type in error_types:
                if err_type in error:
                    error_info['error_type'] = err_type
                    break
            
            return error_info if error_info else None
        except Exception:
            return None
    
    def export_metrics_to_file(self, filepath: str = "code_fixer_metrics.json"):
        """메트릭을 JSON 파일로 내보내기"""
        metrics = self.get_session_metrics()
        metrics['export_timestamp'] = datetime.now().isoformat()
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(metrics, f, indent=2, ensure_ascii=False)
            logger.info(f"📊 메트릭 내보내기 완료: {filepath}")
        except Exception as e:
            logger.error(f"❌ 메트릭 내보내기 실패: {e}")
    
    def print_session_summary(self):
        """세션 요약 출력"""
        metrics = self.get_session_metrics()
        
        print("\n" + "="*60)
        print("🚀 CodeFixer 베스트 프랙티스 세션 요약")
        print("="*60)
        
        print(f"📊 총 요청: {metrics['total_requests']}")
        print(f"✅ 성공율: {metrics['success_rate_percent']}%")
        print(f"🎯 총 토큰: {metrics['total_tokens_used']:,}")
        print(f"⏱️ 평균 응답: {metrics['avg_response_time']:.2f}s")
        print(f"💰 예상 비용: ${metrics['total_estimated_cost_usd']}")
        
        # Self-Healing 통계
        if metrics.get('self_healing_used', 0) > 0:
            sh_success_rate = (metrics['self_healing_success'] / metrics['self_healing_used']) * 100
            print(f"\n✨ Self-Healing 사용: {metrics['self_healing_used']}회")
            print(f"   성공율: {sh_success_rate:.1f}%")
        
        if metrics['complexity_distribution']:
            print(f"\n🔍 복잡도 분포:")
            for complexity, count in metrics['complexity_distribution'].items():
                print(f"  - {complexity}: {count}회")
        
        if metrics['parsing_methods_used']:
            print(f"\n🔧 파싱 방법:")
            for method, count in metrics['parsing_methods_used'].items():
                print(f"  - {method}: {count}회")
        
        print(f"\n💡 최적화 제안:")
        for suggestion in metrics['optimization_suggestions']:
            print(f"  • {suggestion}")
        
        print("="*60)
