"""
Smart Forge System - 통합 Agent 생성 시스템
=============================================
모든 Generation System을 하나로 통합
"""

import asyncio
from typing import Dict, Any, Optional, Literal
from dataclasses import dataclass
from datetime import datetime
from loguru import logger

# 기존 시스템들 import
from forge.core.forge_v2_system import ForgeV2System
from forge.core.business_logic_v2.business_logic_generator_v2 import BusinessLogicGeneratorV2
from forge.core.business_logic_v2.self_healing import SelfHealingModule
from forge.core.business_logic_validator import BusinessLogicValidator
from forge.core.template_system.template_manager import TemplateManager

try:
    from forge.core.next_gen.smart_assembler import SmartAssembler
    SMART_ASSEMBLER_AVAILABLE = True
except ImportError:
    SMART_ASSEMBLER_AVAILABLE = False
    logger.warning("SmartAssembler not available")


@dataclass
class GenerationResult:
    """Generation 결과"""
    success: bool
    agent_code: str
    agent_name: str
    metadata: Dict[str, Any]
    generation_time: float
    mode_used: str
    self_healing_applied: bool
    validation_passed: bool
    error: Optional[str] = None


class SmartForgeSystem:
    """
    통합 Agent 생성 시스템
    
    3가지 Mode:
    - Quick: Template 기반 (1-2초)
    - Standard: V2 Generator (5-10초) [Default]
    - Advanced: Next Gen + LLM (10-20초)
    """
    
    def __init__(self):
        logger.info("🔨 Initializing SmartForgeSystem...")
        
        # Core systems
        self.v2_system = ForgeV2System()
        self.template_manager = TemplateManager()
        self.self_healing = SelfHealingModule()
        self.validator = BusinessLogicValidator()
        
        # Next Gen (optional)
        self.smart_assembler = None
        if SMART_ASSEMBLER_AVAILABLE:
            self.smart_assembler = SmartAssembler()
            logger.info("✅ SmartAssembler loaded")
        
        # Statistics
        self.stats = {
            'total_generations': 0,
            'quick_mode': 0,
            'standard_mode': 0,
            'advanced_mode': 0,
            'self_healing_used': 0,
            'avg_generation_time': 0.0
        }
        
        logger.info("✅ SmartForgeSystem initialized")
    
    async def generate_agent(
        self,
        query: str,
        mode: Literal['quick', 'standard', 'advanced'] = 'standard',
        user_email: str = "default@forge.ai",
        enable_self_healing: bool = True,
        enable_validation: bool = True
    ) -> GenerationResult:
        """
        통합 Agent 생성
        
        Args:
            query: 사용자 요청
            mode: 생성 모드 (quick/standard/advanced)
            user_email: 사용자 이메일
            enable_self_healing: Self-healing 활성화
            enable_validation: Validation 활성화
        
        Returns:
            GenerationResult
        """
        start_time = datetime.now()
        self.stats['total_generations'] += 1
        
        logger.info(f"🚀 Generating agent - Mode: {mode}, Query: {query[:100]}...")
        
        try:
            # Mode에 따라 생성
            if mode == 'quick':
                result = await self._quick_generation(query, user_email)
            elif mode == 'standard':
                result = await self._standard_generation(query, user_email)
            else:  # advanced
                result = await self._advanced_generation(query, user_email)
            
            # Self-Healing 적용
            if enable_self_healing and result.success:
                result = await self._apply_self_healing(result)
            
            # Validation 적용
            if enable_validation and result.success:
                result = await self._apply_validation(result)
            
            # 통계 업데이트
            generation_time = (datetime.now() - start_time).total_seconds()
            result.generation_time = generation_time
            self._update_stats(mode, generation_time)
            
            logger.info(f"✅ Generation complete - {generation_time:.2f}s")
            return result
            
        except Exception as e:
            logger.error(f"❌ Generation failed: {e}")
            return GenerationResult(
                success=False,
                agent_code="",
                agent_name="",
                metadata={},
                generation_time=(datetime.now() - start_time).total_seconds(),
                mode_used=mode,
                self_healing_applied=False,
                validation_passed=False,
                error=str(e)
            )
    
    async def _quick_generation(self, query: str, user_email: str) -> GenerationResult:
        """
        Quick Mode: Template 기반 생성 (1-2초)
        """
        logger.info("⚡ Quick Mode - Template-based generation")
        self.stats['quick_mode'] += 1
        
        try:
            # Template 매칭
            template = self.template_manager.find_best_match(query)
            
            if not template:
                logger.warning("No template found, falling back to standard mode")
                return await self._standard_generation(query, user_email)
            
            # Template 기반 코드 생성
            agent_code = self.template_manager.generate_from_template(
                template.id,
                query
            )
            
            # Agent 이름 추출
            agent_name = self._extract_agent_name(agent_code) or "QuickAgent"
            
            return GenerationResult(
                success=True,
                agent_code=agent_code,
                agent_name=agent_name,
                metadata={
                    'template_used': template.id,
                    'template_name': template.name,
                    'mode': 'quick'
                },
                generation_time=0.0,  # Will be set later
                mode_used='quick',
                self_healing_applied=False,
                validation_passed=False
            )
            
        except Exception as e:
            logger.error(f"Quick generation failed: {e}")
            raise
    
    async def _standard_generation(self, query: str, user_email: str) -> GenerationResult:
        """
        Standard Mode: V2 Generator (5-10초)
        """
        logger.info("🔧 Standard Mode - V2 Generator")
        self.stats['standard_mode'] += 1
        
        try:
            # V2 System으로 생성
            result = await self.v2_system.create_agent({
                'query': query,
                'user_email': user_email,
                'output_type': 'logosai'
            })
            
            if not result.get('success'):
                raise Exception(result.get('error', 'Unknown error'))
            
            agent_code = result.get('agent_code', '')
            agent_name = result.get('agent_name', 'StandardAgent')
            
            return GenerationResult(
                success=True,
                agent_code=agent_code,
                agent_name=agent_name,
                metadata={
                    'generator': 'V2',
                    'mode': 'standard',
                    **result.get('metadata', {})
                },
                generation_time=0.0,
                mode_used='standard',
                self_healing_applied=False,
                validation_passed=False
            )
            
        except Exception as e:
            logger.error(f"Standard generation failed: {e}")
            raise
    
    async def _advanced_generation(self, query: str, user_email: str) -> GenerationResult:
        """
        Advanced Mode: Next Gen + LLM (10-20초)
        """
        logger.info("🚀 Advanced Mode - Next Gen + LLM")
        self.stats['advanced_mode'] += 1
        
        if not self.smart_assembler:
            logger.warning("SmartAssembler not available, falling back to standard mode")
            return await self._standard_generation(query, user_email)
        
        try:
            # SmartAssembler로 생성
            result = await self.smart_assembler.generate_agent(
                query=query,
                user_email=user_email,
                output_type='logosai'
            )
            
            return GenerationResult(
                success=True,
                agent_code=result.code,
                agent_name=result.agent_name,
                metadata={
                    'generator': 'SmartAssembler',
                    'mode': 'advanced',
                    'complexity': result.metadata.get('complexity'),
                    'patterns_used': result.metadata.get('patterns', [])
                },
                generation_time=0.0,
                mode_used='advanced',
                self_healing_applied=False,
                validation_passed=False
            )
            
        except Exception as e:
            logger.error(f"Advanced generation failed: {e}")
            # Fallback to standard
            return await self._standard_generation(query, user_email)
    
    async def _apply_self_healing(self, result: GenerationResult) -> GenerationResult:
        """Self-Healing 적용"""
        logger.info("🔧 Applying Self-Healing...")
        
        try:
            # 코드 검증
            healing_result = self.self_healing.heal(result.agent_code, None)
            
            if healing_result.success:
                logger.info(f"✅ Self-Healing applied: {len(healing_result.fixes_applied)} fixes")
                result.agent_code = healing_result.healed_code
                result.self_healing_applied = True
                result.metadata['self_healing'] = {
                    'fixes_applied': healing_result.fixes_applied,
                    'confidence': healing_result.confidence
                }
                self.stats['self_healing_used'] += 1
            else:
                logger.warning(f"⚠️ Self-Healing failed: {healing_result.error_details}")
                result.metadata['self_healing'] = {
                    'failed': True,
                    'error': healing_result.error_details
                }
            
            return result
            
        except Exception as e:
            logger.error(f"Self-Healing error: {e}")
            return result
    
    async def _apply_validation(self, result: GenerationResult) -> GenerationResult:
        """Validation 적용"""
        logger.info("✅ Applying Validation...")
        
        try:
            # Business Logic Validation
            validation_result = self.validator.validate(
                query="Generated agent",  # Original query would be better
                code=result.agent_code
            )
            
            result.validation_passed = validation_result.get('success', False)
            result.metadata['validation'] = {
                'coverage': validation_result.get('coverage', 0),
                'issues': validation_result.get('issues', [])
            }
            
            if result.validation_passed:
                logger.info(f"✅ Validation passed - Coverage: {validation_result.get('coverage', 0):.1f}%")
            else:
                logger.warning(f"⚠️ Validation issues found: {len(validation_result.get('issues', []))}")
            
            return result
            
        except Exception as e:
            logger.error(f"Validation error: {e}")
            result.validation_passed = False
            return result
    
    def _extract_agent_name(self, code: str) -> Optional[str]:
        """코드에서 Agent 이름 추출"""
        try:
            import re
            match = re.search(r'class\s+(\w+)\s*\(', code)
            return match.group(1) if match else None
        except:
            return None
    
    def _update_stats(self, mode: str, generation_time: float):
        """통계 업데이트"""
        total = self.stats['total_generations']
        current_avg = self.stats['avg_generation_time']
        
        # 평균 생성 시간 업데이트
        self.stats['avg_generation_time'] = (
            (current_avg * (total - 1) + generation_time) / total
        )
    
    def get_stats(self) -> Dict[str, Any]:
        """통계 반환"""
        return {
            **self.stats,
            'success_rate': self._calculate_success_rate(),
            'mode_distribution': {
                'quick': f"{self.stats['quick_mode'] / max(1, self.stats['total_generations']) * 100:.1f}%",
                'standard': f"{self.stats['standard_mode'] / max(1, self.stats['total_generations']) * 100:.1f}%",
                'advanced': f"{self.stats['advanced_mode'] / max(1, self.stats['total_generations']) * 100:.1f}%"
            }
        }
    
    def _calculate_success_rate(self) -> float:
        """성공률 계산"""
        # TODO: 실패 추적 추가
        return 100.0


# Singleton instance
_smart_forge_instance = None

def get_smart_forge() -> SmartForgeSystem:
    """SmartForgeSystem 싱글톤 인스턴스 반환"""
    global _smart_forge_instance
    if _smart_forge_instance is None:
        _smart_forge_instance = SmartForgeSystem()
    return _smart_forge_instance


if __name__ == "__main__":
    # 테스트
    async def test():
        forge = SmartForgeSystem()
        
        # Quick mode test
        result = await forge.generate_agent(
            "Create a simple calculator agent",
            mode='quick'
        )
        print(f"Quick: {result.success}, Time: {result.generation_time:.2f}s")
        
        # Standard mode test
        result = await forge.generate_agent(
            "Create an inventory monitoring agent",
            mode='standard'
        )
        print(f"Standard: {result.success}, Time: {result.generation_time:.2f}s")
        
        # Stats
        print(f"\nStats: {forge.get_stats()}")
    
    asyncio.run(test())

