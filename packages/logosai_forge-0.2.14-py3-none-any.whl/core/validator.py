"""
Validator for FORGE AI

Validates generated code using LLM-driven analysis.
All validation decisions are made by LLM, not hardcoded rules.
"""

from typing import Dict, Any, List, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum
import ast
import logging
import json

from .llm_orchestrator import LLMOrchestrator, TaskType
from .prompts import prompt_registry

logger = logging.getLogger(__name__)


class ValidationSeverity(Enum):
    """Severity levels for validation issues"""
    ERROR = "error"       # Must fix
    WARNING = "warning"   # Should fix
    INFO = "info"        # Nice to have
    CRITICAL = "critical" # Security/major issue


@dataclass
class ValidationIssue:
    """Represents a validation issue"""
    severity: ValidationSeverity
    category: str
    message: str
    line_number: Optional[int] = None
    suggestion: Optional[str] = None
    code_snippet: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'severity': self.severity.value,
            'category': self.category,
            'message': self.message,
            'line_number': self.line_number,
            'suggestion': self.suggestion,
            'code_snippet': self.code_snippet
        }


@dataclass 
class ValidationResult:
    """Result of code validation"""
    is_valid: bool
    issues: List[ValidationIssue] = field(default_factory=list)
    score: float = 1.0  # 0-1 quality score
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_issues_by_severity(self, severity: ValidationSeverity) -> List[ValidationIssue]:
        """Get issues filtered by severity"""
        return [issue for issue in self.issues if issue.severity == severity]
        
    def has_critical_issues(self) -> bool:
        """Check if there are critical issues"""
        return any(issue.severity == ValidationSeverity.CRITICAL for issue in self.issues)
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            'is_valid': self.is_valid,
            'issues': [issue.to_dict() for issue in self.issues],
            'score': self.score,
            'metadata': self.metadata
        }


class Validator:
    """Validates generated code using LLM analysis"""
    
    def __init__(self, llm_orchestrator: Optional[LLMOrchestrator] = None):
        """
        Initialize validator.
        
        Args:
            llm_orchestrator: LLM orchestrator for validation
        """
        self.llm = llm_orchestrator
        
    async def validate(self, code: str, 
                      context: Optional[Dict[str, Any]] = None) -> ValidationResult:
        """
        Validate generated code using LLM-driven analysis.
        
        Args:
            code: Python code to validate
            context: Optional context about the code
            
        Returns:
            Validation result with issues and score
        """
        logger.info("Starting code validation")
        
        # Run validation tasks in parallel
        validation_tasks = [
            self._validate_syntax(code),
            self._validate_structure(code, context),
            self._validate_security(code, context),
            self._validate_best_practices(code, context),
            self._validate_logosai_compliance(code, context),
            self._validate_functionality(code, context)
        ]
        
        results = await asyncio.gather(*validation_tasks, return_exceptions=True)
        
        # Aggregate results
        all_issues = []
        
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Validation task failed: {result}")
            elif isinstance(result, list):
                all_issues.extend(result)
                
        # Calculate overall validity and score
        is_valid, score = await self._calculate_validity(all_issues, code)
        
        result = ValidationResult(
            is_valid=is_valid,
            issues=all_issues,
            score=score,
            metadata={
                'code_length': len(code),
                'line_count': len(code.splitlines()),
                'context': context
            }
        )
        
        logger.info(f"Validation complete: valid={is_valid}, score={score:.2f}, issues={len(all_issues)}")
        
        return result
        
    async def _validate_syntax(self, code: str) -> List[ValidationIssue]:
        """Validate Python syntax"""
        issues = []
        
        # First try AST parsing
        try:
            ast.parse(code)
        except SyntaxError as e:
            issues.append(ValidationIssue(
                severity=ValidationSeverity.ERROR,
                category="syntax",
                message=str(e),
                line_number=e.lineno,
                suggestion="Fix the syntax error"
            ))
            
            # Ask LLM for better suggestion
            fix_prompt = f"""Analyze this syntax error and suggest a fix:

Error: {e}
Line {e.lineno}: {e.text}

Provide a specific fix:"""
            
            try:
                suggestion = await self.llm.generate(
                    fix_prompt,
                    task_type=TaskType.VALIDATION,
                    temperature=0.3
                )
                issues[-1].suggestion = suggestion.strip()
            except:
                pass
                
        return issues
        
    async def _validate_structure(self, code: str, 
                                 context: Optional[Dict[str, Any]]) -> List[ValidationIssue]:
        """Let LLM validate code structure"""
        
        structure_prompt = f"""Analyze the structure of this Python code:

```python
{code[:2000]}{'...' if len(code) > 2000 else ''}
```

Check for:
1. Class structure and inheritance
2. Required methods implementation
3. Method signatures
4. Import statements
5. Overall organization

Report issues in this format:
Issue: [description]
Severity: [error/warning/info]
Line: [approximate line]
Fix: [suggestion]

Structural issues:"""
        
        response = await self.llm.generate(
            structure_prompt,
            task_type=TaskType.VALIDATION,
            temperature=0.3
        )
        
        # Parse LLM response into issues
        issues = self._parse_llm_issues(response, "structure")
        
        return issues
        
    async def _validate_security(self, code: str,
                                context: Optional[Dict[str, Any]]) -> List[ValidationIssue]:
        """Let LLM validate security aspects"""
        
        # Use prompt from registry
        prompt = prompt_registry.render_prompt(
            "validation_security_check",
            code_snippet=code[:3000] + '...' if len(code) > 3000 else code,
            context=json.dumps(context or {})
        )
        
        response = await self.llm.generate(
            prompt,
            task_type=TaskType.VALIDATION,
            temperature=0.3
        )
        
        # Parse response
        issues = self._parse_llm_issues(response, "security")
        
        # Mark security issues as critical
        for issue in issues:
            if issue.severity in [ValidationSeverity.ERROR, ValidationSeverity.WARNING]:
                issue.severity = ValidationSeverity.CRITICAL
                
        return issues
        
    async def _validate_best_practices(self, code: str,
                                      context: Optional[Dict[str, Any]]) -> List[ValidationIssue]:
        """Let LLM validate against Python best practices"""
        
        practices_prompt = f"""Review this code for Python best practices:

```python
{code[:2000]}{'...' if len(code) > 2000 else ''}
```

Check for:
1. PEP 8 style compliance
2. Type hints usage
3. Docstring quality
4. Error handling patterns
5. Code organization
6. Variable naming
7. Function/class design

Report violations with severity (error/warning/info):"""
        
        response = await self.llm.generate(
            practices_prompt,
            task_type=TaskType.VALIDATION,
            temperature=0.3
        )
        
        issues = self._parse_llm_issues(response, "best_practices")
        
        return issues
        
    async def _validate_logosai_compliance(self, code: str,
                                          context: Optional[Dict[str, Any]]) -> List[ValidationIssue]:
        """Let LLM validate LogosAI framework compliance"""
        
        compliance_prompt = f"""Check if this code properly implements a LogosAI agent:

```python
{code[:2500]}{'...' if len(code) > 2500 else ''}
```

LogosAI requirements:
1. Must inherit from LogosAIAgent
2. Must implement: setup(), process(), validate_input(), format_output()
3. Should use async/await properly
4. Should handle errors with LogosAIException
5. Should use self.logger for logging
6. Should call super().__init__() with name, description, version

Report any compliance issues:"""
        
        response = await self.llm.generate(
            compliance_prompt,
            task_type=TaskType.VALIDATION,
            temperature=0.2
        )
        
        issues = self._parse_llm_issues(response, "logosai_compliance")
        
        return issues
        
    async def _validate_functionality(self, code: str,
                                     context: Optional[Dict[str, Any]]) -> List[ValidationIssue]:
        """Let LLM validate if code fulfills requirements"""
        
        if not context or 'requirements' not in context:
            return []
            
        functional_prompt = f"""Does this code fulfill the requirements?

Requirements:
{json.dumps(context.get('requirements', {}), indent=2)}

Code capabilities analysis:
1. Does it implement all required features?
2. Does it handle the specified use cases?
3. Are there any missing functionalities?
4. Does the logic make sense?

Report any gaps or issues:"""
        
        response = await self.llm.generate(
            functional_prompt,
            task_type=TaskType.VALIDATION,
            temperature=0.4
        )
        
        issues = self._parse_llm_issues(response, "functionality")
        
        return issues
        
    def _parse_llm_issues(self, response: str, category: str) -> List[ValidationIssue]:
        """Parse LLM response into ValidationIssue objects"""
        issues = []
        
        # Split response into individual issues
        lines = response.strip().split('\n')
        current_issue = {}
        
        for line in lines:
            line = line.strip()
            
            if not line:
                # Empty line might indicate end of issue
                if current_issue:
                    issues.append(self._create_issue(current_issue, category))
                    current_issue = {}
                continue
                
            # Parse different formats LLM might use
            if line.startswith('Issue:') or line.startswith('- '):
                if current_issue:
                    issues.append(self._create_issue(current_issue, category))
                current_issue = {'message': line.replace('Issue:', '').replace('- ', '').strip()}
                
            elif line.startswith('Severity:'):
                severity_str = line.replace('Severity:', '').strip().lower()
                current_issue['severity'] = severity_str
                
            elif line.startswith('Line:'):
                try:
                    line_num = int(line.replace('Line:', '').strip().split()[0])
                    current_issue['line'] = line_num
                except:
                    pass
                    
            elif line.startswith('Fix:') or line.startswith('Suggestion:'):
                current_issue['suggestion'] = line.replace('Fix:', '').replace('Suggestion:', '').strip()
                
            elif current_issue and 'message' in current_issue:
                # Continuation of previous message
                current_issue['message'] += ' ' + line
                
        # Don't forget last issue
        if current_issue:
            issues.append(self._create_issue(current_issue, category))
            
        return issues
        
    def _create_issue(self, issue_dict: Dict[str, Any], category: str) -> ValidationIssue:
        """Create ValidationIssue from parsed data"""
        
        # Map severity strings
        severity_map = {
            'error': ValidationSeverity.ERROR,
            'warning': ValidationSeverity.WARNING,
            'info': ValidationSeverity.INFO,
            'critical': ValidationSeverity.CRITICAL,
            'high': ValidationSeverity.ERROR,
            'medium': ValidationSeverity.WARNING,
            'low': ValidationSeverity.INFO
        }
        
        severity_str = issue_dict.get('severity', 'warning').lower()
        severity = severity_map.get(severity_str, ValidationSeverity.WARNING)
        
        return ValidationIssue(
            severity=severity,
            category=category,
            message=issue_dict.get('message', 'Unknown issue'),
            line_number=issue_dict.get('line'),
            suggestion=issue_dict.get('suggestion')
        )
        
    async def _calculate_validity(self, issues: List[ValidationIssue], 
                                 code: str) -> Tuple[bool, float]:
        """Let LLM calculate overall validity and score"""
        
        # Prepare issue summary
        issue_summary = {
            'critical': len([i for i in issues if i.severity == ValidationSeverity.CRITICAL]),
            'error': len([i for i in issues if i.severity == ValidationSeverity.ERROR]),
            'warning': len([i for i in issues if i.severity == ValidationSeverity.WARNING]),
            'info': len([i for i in issues if i.severity == ValidationSeverity.INFO])
        }
        
        calc_prompt = f"""Based on these validation results, determine:
1. Is the code valid for deployment? (yes/no)
2. Quality score from 0.0 to 1.0

Issue Summary:
- Critical issues: {issue_summary['critical']}
- Errors: {issue_summary['error']}
- Warnings: {issue_summary['warning']}
- Info: {issue_summary['info']}

Code metrics:
- Length: {len(code)} characters
- Lines: {len(code.splitlines())}

Consider:
- Critical issues should make it invalid
- Multiple errors might make it invalid
- Warnings reduce score but might still be valid
- Info items are suggestions only

Response format:
Valid: [yes/no]
Score: [0.0-1.0]
Reasoning: [brief explanation]"""
        
        response = await self.llm.generate(
            calc_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.2
        )
        
        # Parse response
        is_valid = 'yes' in response.lower().split('\n')[0]
        
        # Extract score
        score = 0.5  # Default
        for line in response.split('\n'):
            if 'score:' in line.lower():
                try:
                    score = float(line.split(':')[1].strip())
                    score = max(0.0, min(1.0, score))  # Clamp to 0-1
                except:
                    pass
                break
                
        # Override if critical issues
        if issue_summary['critical'] > 0:
            is_valid = False
            score = min(score, 0.3)
            
        return is_valid, score
        
    async def suggest_fixes(self, code: str, 
                           issues: List[ValidationIssue]) -> Dict[str, str]:
        """Let LLM suggest fixes for validation issues"""
        
        if not issues:
            return {}
            
        # Group issues by severity
        critical_issues = [i for i in issues if i.severity == ValidationSeverity.CRITICAL]
        error_issues = [i for i in issues if i.severity == ValidationSeverity.ERROR]
        
        # Focus on critical and error issues
        important_issues = critical_issues + error_issues
        
        if not important_issues:
            return {}
            
        fix_prompt = f"""Suggest specific code fixes for these issues:

Issues:
{chr(10).join([f"- {i.category}: {i.message}" for i in important_issues[:5]])}

Provide specific code changes or additions:"""
        
        response = await self.llm.generate(
            fix_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.5
        )
        
        # Parse into fix dictionary
        fixes = {}
        current_key = "general"
        current_fix = []
        
        for line in response.split('\n'):
            if line.strip().endswith(':'):
                if current_fix:
                    fixes[current_key] = '\n'.join(current_fix)
                current_key = line.strip().rstrip(':').lower().replace(' ', '_')
                current_fix = []
            else:
                current_fix.append(line)
                
        if current_fix:
            fixes[current_key] = '\n'.join(current_fix)
            
        return fixes


# Add asyncio import at the top
import asyncio