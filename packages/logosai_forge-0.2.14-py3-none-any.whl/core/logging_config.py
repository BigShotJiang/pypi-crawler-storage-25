"""
Unified Logging Configuration for FORGE System

This module provides consistent logging setup across all FORGE components,
addressing the inconsistency between standard logging and loguru.
"""

import sys
import logging
from pathlib import Path
from datetime import datetime
from loguru import logger

# Remove default loguru handler
logger.remove()

# Define log format
LOG_FORMAT = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"

# Configure loguru
logger.add(
    sys.stderr,
    format=LOG_FORMAT,
    level="INFO",
    colorize=True
)

# Add file logging
log_dir = Path(__file__).parent.parent / "logs"
log_dir.mkdir(exist_ok=True)

logger.add(
    log_dir / f"forge_{datetime.now().strftime('%Y%m%d')}.log",
    format=LOG_FORMAT,
    level="DEBUG",
    rotation="100 MB",
    retention="30 days",
    compression="zip"
)

# Intercept standard logging
class InterceptHandler(logging.Handler):
    """Intercept standard logging messages and redirect to loguru"""
    
    def emit(self, record: logging.LogRecord) -> None:
        # Get corresponding Loguru level if it exists
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        # Find caller from where originated the logged message
        frame, depth = sys._getframe(6), 6
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(
            level, record.getMessage()
        )

# Install the interceptor for standard logging
logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)

# Function to get logger for a module
def get_logger(name: str):
    """Get a logger instance for the given module name"""
    return logger.bind(name=name)

# Export the configured logger
__all__ = ['logger', 'get_logger']