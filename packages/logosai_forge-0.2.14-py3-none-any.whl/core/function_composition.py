"""
FunctionCompositionTracker + PatternBasedGenerator

A4: 함수 조합 학습 — 어떤 함수들이 잘 어울리는지 추적
A5: 패턴 기반 생성 — 성공 함수 패턴을 새 도메인에 적용
"""

import sqlite3
import re
from typing import Dict, Any, List, Optional
from pathlib import Path
from loguru import logger


class FunctionCompositionTracker:
    """Track which functions work well together."""

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            db_path = str(Path(__file__).parent.parent / "prototype" / "backend" / "forge_evolution.db")
            cls._instance = cls(db_path)
        return cls._instance

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._init_db()

    def _init_db(self):
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS function_pairs (
                    func_a TEXT NOT NULL,
                    func_b TEXT NOT NULL,
                    cooccurrence INTEGER DEFAULT 0,
                    joint_success INTEGER DEFAULT 0,
                    PRIMARY KEY (func_a, func_b)
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[Composition] DB init: {e}")

    def record_composition(self, agent_id: str, functions_used: List[str], success: bool = True):
        """Record function combination from an agent execution."""
        try:
            conn = sqlite3.connect(self._db_path)
            for i, fa in enumerate(functions_used):
                for fb in functions_used[i+1:]:
                    a, b = sorted([fa, fb])
                    conn.execute("""
                        INSERT INTO function_pairs (func_a, func_b, cooccurrence, joint_success)
                        VALUES (?, ?, 1, ?)
                        ON CONFLICT(func_a, func_b) DO UPDATE SET
                            cooccurrence = cooccurrence + 1,
                            joint_success = joint_success + ?
                    """, (a, b, 1 if success else 0, 1 if success else 0))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[Composition] Record failed: {e}")

    def suggest_companions(self, func_name: str, top_k: int = 5) -> List[Dict]:
        """Suggest functions that pair well with this one."""
        try:
            conn = sqlite3.connect(self._db_path)
            rows = conn.execute("""
                SELECT
                    CASE WHEN func_a = ? THEN func_b ELSE func_a END as companion,
                    cooccurrence,
                    ROUND(CAST(joint_success AS REAL) / MAX(cooccurrence, 1), 3) as success_rate
                FROM function_pairs
                WHERE func_a = ? OR func_b = ?
                ORDER BY cooccurrence DESC, success_rate DESC
                LIMIT ?
            """, (func_name, func_name, func_name, top_k)).fetchall()
            conn.close()
            return [{"companion": r[0], "cooccurrence": r[1], "success_rate": r[2]} for r in rows]
        except Exception:
            return []

    def get_top_pairs(self, min_cooccurrence: int = 2, limit: int = 10) -> List[Dict]:
        """Get most frequently co-occurring function pairs."""
        try:
            conn = sqlite3.connect(self._db_path)
            rows = conn.execute("""
                SELECT func_a, func_b, cooccurrence,
                       ROUND(CAST(joint_success AS REAL) / MAX(cooccurrence, 1), 3) as success_rate
                FROM function_pairs WHERE cooccurrence >= ?
                ORDER BY cooccurrence DESC LIMIT ?
            """, (min_cooccurrence, limit)).fetchall()
            conn.close()
            return [{"func_a": r[0], "func_b": r[1], "cooccurrence": r[2], "success_rate": r[3]} for r in rows]
        except Exception:
            return []

    def get_anti_patterns(self, max_success_rate: float = 0.5, min_cooccurrence: int = 3) -> List[Dict]:
        """Get function pairs with high failure rate."""
        try:
            conn = sqlite3.connect(self._db_path)
            rows = conn.execute("""
                SELECT func_a, func_b, cooccurrence,
                       ROUND(CAST(joint_success AS REAL) / MAX(cooccurrence, 1), 3) as success_rate
                FROM function_pairs
                WHERE cooccurrence >= ? AND CAST(joint_success AS REAL) / MAX(cooccurrence, 1) <= ?
                ORDER BY success_rate ASC
            """, (min_cooccurrence, max_success_rate)).fetchall()
            conn.close()
            return [{"func_a": r[0], "func_b": r[1], "cooccurrence": r[2], "success_rate": r[3]} for r in rows]
        except Exception:
            return []


class PatternBasedGenerator:
    """Generate functions by learning from successful patterns."""

    def find_similar_function(self, target_name: str, target_desc: str,
                               known_functions: List[Dict]) -> Optional[Dict]:
        """Find the best matching successful function for pattern-based generation."""
        best = None
        best_score = 0
        target_words = set(target_name.lower().replace("_", " ").split())

        for func in known_functions:
            func_words = set(func["name"].lower().replace("_", " ").split())
            name_overlap = len(target_words & func_words) / max(len(target_words | func_words), 1)

            # No name overlap → skip (prevents false matches from quality alone)
            if name_overlap == 0:
                continue

            quality = func.get("success_rate", 0.5)
            score = name_overlap * 0.5 + quality * 0.5

            if score > best_score and score > 0.3:
                best_score = score
                best = func

        return best

    def generate_prompt_with_example(self, spec: Dict, example_func: Dict) -> str:
        """Build LLM prompt using successful function as reference."""
        return f"""Reference function (proven {example_func.get('success_rate', 0)*100:.0f}% success rate, {example_func.get('call_count', 0)} uses):
```python
{example_func.get('code', '')}
```

Generate a SIMILAR function for a different domain:
Name: {spec.get('name', '')}
Description: {spec.get('description', '')}

Keep the SAME structure (input validation → core logic → result formatting).
Change domain-specific terms and formulas.
Return ONLY the function code."""
