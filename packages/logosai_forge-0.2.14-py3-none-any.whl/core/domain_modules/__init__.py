#!/usr/bin/env python3
"""
FORGE AI 도메인 전문 모듈 레지스트리
30+ 도메인별 전문 AST 생성 모듈
"""

from typing import Dict, Any
from loguru import logger


# 도메인 모듈들을 동적으로 로드
DOMAIN_REGISTRY = {}


def register_domain_modules():
    """도메인 모듈 동적 등록"""
    try:
        # 데이터 & 분석 도메인
        from .voice_analysis import VoiceAnalysisASTModule
        from .data_analysis import DataAnalysisASTModule
        from .inventory_management import InventoryManagementASTModule
        
        # 등록
        DOMAIN_REGISTRY['voice_analysis'] = VoiceAnalysisASTModule()
        DOMAIN_REGISTRY['data_analysis'] = DataAnalysisASTModule()
        DOMAIN_REGISTRY['inventory_management'] = InventoryManagementASTModule()
        DOMAIN_REGISTRY['inventory'] = InventoryManagementASTModule()  # 별칭
        
        # 기본 도메인
        from .general import GeneralASTModule
        DOMAIN_REGISTRY['general'] = GeneralASTModule()
        DOMAIN_REGISTRY['default'] = GeneralASTModule()  # 별칭
        
        logger.info(f"✅ {len(DOMAIN_REGISTRY)} 도메인 모듈 등록 완료")
        
    except ImportError as e:
        logger.warning(f"⚠️ 일부 도메인 모듈 로드 실패: {e}")
        # 최소한 기본 모듈은 등록
        if 'general' not in DOMAIN_REGISTRY:
            DOMAIN_REGISTRY['general'] = None


def get_domain_module(domain: str):
    """도메인 모듈 가져오기"""
    if not DOMAIN_REGISTRY:
        register_domain_modules()
    
    # 도메인 정규화
    domain = domain.lower().replace(' ', '_').replace('-', '_')
    
    # 매핑
    domain_mapping = {
        'voice': 'voice_analysis',
        'audio': 'voice_analysis',
        'speech': 'voice_analysis',
        'stt': 'voice_analysis',
        'data': 'data_analysis',
        'analysis': 'data_analysis',
        'inventory': 'inventory_management',
        'stock': 'inventory_management',
        '재고': 'inventory_management',
        '음성': 'voice_analysis',
        '데이터': 'data_analysis'
    }
    
    # 매핑된 도메인 찾기
    mapped_domain = domain_mapping.get(domain, domain)
    
    # 모듈 반환
    module = DOMAIN_REGISTRY.get(mapped_domain)
    if not module:
        logger.warning(f"⚠️ 도메인 '{domain}' 모듈을 찾을 수 없음, 기본 모듈 사용")
        module = DOMAIN_REGISTRY.get('general')
    
    return module


def list_available_domains():
    """사용 가능한 도메인 목록"""
    if not DOMAIN_REGISTRY:
        register_domain_modules()
    
    return list(DOMAIN_REGISTRY.keys())


# 초기화 시 모듈 등록
register_domain_modules()