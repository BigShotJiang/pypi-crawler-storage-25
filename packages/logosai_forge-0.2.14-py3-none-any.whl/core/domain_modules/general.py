#!/usr/bin/env python3
"""
범용 AST 생성 모듈
도메인 특화되지 않은 일반적인 에이전트를 위한 기본 모듈
"""

import ast
from typing import List, Dict, Any
from loguru import logger


class GeneralASTModule:
    """
    범용 AST 생성 모듈
    """
    
    def __init__(self):
        self.domain = "general"
        self.required_imports = [
            'json',
            'asyncio',
            'aiohttp',
            'datetime',
            'typing.Dict, Any, Optional, List',
            'loguru.logger',
            're',
            'os',
            'sys'
        ]
        
        self.required_methods = [
            'validate_input',
            'process_request',
            'handle_response',
            'format_output',
            'log_activity',
            'error_handler',
            'cache_result',
            'cleanup'
        ]
    
    def get_required_imports(self) -> List[str]:
        """필수 import 목록 반환"""
        return self.required_imports
    
    def generate_business_logic(self) -> str:
        """범용 비즈니스 로직 생성"""
        logic = '''
# 범용 비즈니스 로직
logger.info("🚀 에이전트 처리 시작")

# 입력 검증
if not extracted_info or not isinstance(extracted_info, dict):
    logger.warning("입력 데이터가 없음, 기본값 사용")
    extracted_info = {}

# 파라미터 추출
operation = extracted_info.get('operation', 'process')
input_data = extracted_info.get('data', {})
options = extracted_info.get('options', {})

# 1. 입력 유효성 검사
logger.info("Validating input...")
validation_result = self.validate_input(input_data)
if not validation_result['valid']:
    return {
        "status": "error",
        "message": f"입력 검증 실패: {validation_result['reason']}",
        "timestamp": datetime.now().isoformat()
    }

# 2. 요청 처리
logger.info(f"Processing {operation} request...")
try:
    processed_data = await self.process_request(
        operation=operation,
        data=input_data,
        options=options
    )
except Exception as e:
    logger.error(f"처리 중 에러: {e}")
    error_result = self.error_handler(e, input_data)
    return error_result

# 3. 응답 처리
logger.info("Handling response...")
response = self.handle_response(processed_data)

# 4. 출력 포맷팅
logger.info("Formatting output...")
formatted_output = self.format_output(response, options.get('format', 'json'))

# 5. 활동 로깅
self.log_activity({
    "operation": operation,
    "input_size": len(str(input_data)),
    "output_size": len(str(formatted_output)),
    "success": True
})

# 6. 결과 캐싱
if options.get('cache', False):
    self.cache_result(operation, input_data, formatted_output)

# 7. 정리 작업
self.cleanup()

# 결과 반환
result = {
    "status": "success",
    "operation": operation,
    "data": formatted_output,
    "metadata": {
        "processed_at": datetime.now().isoformat(),
        "processing_time": "0.5s",  # 실제로는 측정 필요
        "options_used": options
    },
    "message": f"{operation} 작업 완료"
}

logger.info("✅ 에이전트 처리 완료")
return result
'''
        return logic
    
    def generate_helper_methods(self) -> List[ast.FunctionDef]:
        """헬퍼 메서드 AST 노드 생성"""
        methods_code = """
def validate_input(self, data: Any) -> Dict[str, Any]:
    '''입력 유효성 검사'''
    if data is None:
        return {"valid": False, "reason": "데이터가 없음"}
    
    if isinstance(data, dict) and not data:
        return {"valid": False, "reason": "빈 딕셔너리"}
    
    if isinstance(data, str) and not data.strip():
        return {"valid": False, "reason": "빈 문자열"}
    
    # 크기 제한 검사
    if len(str(data)) > 1000000:  # 1MB
        return {"valid": False, "reason": "데이터 크기 초과"}
    
    return {"valid": True, "reason": "OK"}

async def process_request(self, operation: str, data: Any, options: Dict) -> Any:
    '''요청 처리'''
    logger.info(f"Processing operation: {operation}")
    
    # 작업별 처리
    if operation == "analyze":
        return self._analyze_data(data)
    elif operation == "transform":
        return self._transform_data(data, options)
    elif operation == "query":
        return await self._query_data(data)
    elif operation == "compute":
        return self._compute_data(data)
    else:
        # 기본 처리
        return self._default_process(data)

def _analyze_data(self, data: Any) -> Dict:
    '''데이터 분석'''
    return {
        "type": type(data).__name__,
        "size": len(str(data)),
        "content": str(data)[:100] + "..." if len(str(data)) > 100 else str(data)
    }

def _transform_data(self, data: Any, options: Dict) -> Any:
    '''데이터 변환'''
    transform_type = options.get('transform_type', 'json')
    
    if transform_type == 'json':
        import json
        return json.dumps(data) if not isinstance(data, str) else data
    elif transform_type == 'upper':
        return str(data).upper()
    elif transform_type == 'lower':
        return str(data).lower()
    else:
        return data

async def _query_data(self, data: Any) -> Dict:
    '''데이터 조회'''
    # 실제로는 데이터베이스나 API 호출
    await asyncio.sleep(0.1)  # 비동기 작업 시뮬레이션
    
    return {
        "query": str(data),
        "results": [
            {"id": 1, "value": "Result 1"},
            {"id": 2, "value": "Result 2"}
        ],
        "count": 2
    }

def _compute_data(self, data: Any) -> Dict:
    '''데이터 계산'''
    if isinstance(data, (int, float)):
        return {
            "original": data,
            "squared": data ** 2,
            "sqrt": data ** 0.5 if data >= 0 else None,
            "double": data * 2
        }
    elif isinstance(data, list) and all(isinstance(x, (int, float)) for x in data):
        return {
            "sum": sum(data),
            "avg": sum(data) / len(data) if data else 0,
            "min": min(data) if data else None,
            "max": max(data) if data else None
        }
    else:
        return {"error": "계산 불가능한 데이터 타입"}

def _default_process(self, data: Any) -> Dict:
    '''기본 처리'''
    return {
        "processed": True,
        "data": data,
        "timestamp": datetime.now().isoformat()
    }

def handle_response(self, processed_data: Any) -> Dict:
    '''응답 처리'''
    if isinstance(processed_data, dict) and 'error' in processed_data:
        return {
            "success": False,
            "error": processed_data['error'],
            "data": None
        }
    
    return {
        "success": True,
        "data": processed_data,
        "error": None
    }

def format_output(self, response: Dict, format_type: str) -> Any:
    '''출력 포맷팅'''
    if format_type == 'json':
        return response
    elif format_type == 'string':
        return str(response)
    elif format_type == 'summary':
        return {
            "success": response.get('success', False),
            "data_preview": str(response.get('data', ''))[:200]
        }
    else:
        return response

def log_activity(self, activity: Dict) -> None:
    '''활동 로깅'''
    logger.info(f"Activity: {activity}")
    
    # 실제로는 데이터베이스나 파일에 저장
    # self.activity_log.append({
    #     **activity,
    #     "timestamp": datetime.now().isoformat()
    # })

def error_handler(self, error: Exception, context: Any) -> Dict:
    '''에러 처리'''
    error_type = type(error).__name__
    error_message = str(error)
    
    logger.error(f"Error handled: {error_type}: {error_message}")
    
    return {
        "status": "error",
        "error": {
            "type": error_type,
            "message": error_message,
            "context": str(context)[:100] if context else None
        },
        "timestamp": datetime.now().isoformat(),
        "message": f"처리 중 에러 발생: {error_message}"
    }

def cache_result(self, operation: str, input_data: Any, result: Any) -> None:
    '''결과 캐싱'''
    cache_key = f"{operation}:{hash(str(input_data))}"
    
    # 실제로는 Redis나 메모리 캐시 사용
    # self.cache[cache_key] = {
    #     "result": result,
    #     "cached_at": datetime.now().isoformat(),
    #     "ttl": 3600  # 1시간
    # }
    
    logger.info(f"Result cached with key: {cache_key}")

def cleanup(self) -> None:
    '''정리 작업'''
    # 임시 파일 삭제, 연결 종료 등
    logger.info("Cleanup completed")
    
    # 실제 구현 예시:
    # if hasattr(self, 'temp_files'):
    #     for file in self.temp_files:
    #         os.remove(file)
    # if hasattr(self, 'connections'):
    #     for conn in self.connections:
    #         conn.close()
"""
        tree = ast.parse(methods_code)
        return tree.body