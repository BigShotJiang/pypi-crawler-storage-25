#!/usr/bin/env python3
"""
데이터 분석 전문 AST 생성 모듈
통계, 시각화, 예측, 인사이트 추출 등
"""

import ast
from typing import List, Dict, Any
from loguru import logger


class DataAnalysisASTModule:
    """
    데이터 분석 전문 AST 생성 모듈
    """
    
    def __init__(self):
        self.domain = "data_analysis"
        self.required_imports = [
            'pandas as pd',
            'numpy as np',
            'matplotlib.pyplot as plt',
            'seaborn as sns',
            'scipy.stats',
            'sklearn',
            'json',
            'datetime',
            'asyncio',
            'loguru.logger'
        ]
        
        self.required_methods = [
            'load_data',
            'clean_data',
            'analyze_statistics',
            'detect_patterns',
            'create_visualizations',
            'predict_trends',
            'extract_insights',
            'generate_report',
            'export_results'
        ]
    
    def get_required_imports(self) -> List[str]:
        """필수 import 목록 반환"""
        return self.required_imports
    
    def generate_business_logic(self) -> str:
        """데이터 분석 비즈니스 로직 생성"""
        logic = '''
# 데이터 분석 비즈니스 로직
logger.info("📊 데이터 분석 시작")

# 입력 검증
if not extracted_info or not isinstance(extracted_info, dict):
    logger.warning("입력 데이터가 없음, 기본값 사용")
    extracted_info = {}

# 파라미터 추출
data_source = extracted_info.get('data_source') or extracted_info.get('file_path')
analysis_type = extracted_info.get('analysis_type', 'comprehensive')
target_columns = extracted_info.get('columns', [])

# 1. 데이터 로드
logger.info(f"Loading data from: {data_source}")
df = self.load_data(data_source)

# 2. 데이터 정제
logger.info("Cleaning and preprocessing data...")
clean_df = self.clean_data(df)

# 3. 통계 분석
logger.info("Performing statistical analysis...")
statistics = self.analyze_statistics(clean_df, target_columns)

# 4. 패턴 감지
logger.info("Detecting patterns and anomalies...")
patterns = self.detect_patterns(clean_df)

# 5. 시각화 생성
logger.info("Creating visualizations...")
visualizations = self.create_visualizations(clean_df, analysis_type)

# 6. 트렌드 예측
logger.info("Predicting trends...")
predictions = self.predict_trends(clean_df)

# 7. 인사이트 추출
logger.info("Extracting insights...")
insights = self.extract_insights({
    "statistics": statistics,
    "patterns": patterns,
    "predictions": predictions
})

# 8. 보고서 생성
logger.info("Generating comprehensive report...")
report = self.generate_report({
    "data_summary": statistics,
    "patterns": patterns,
    "visualizations": visualizations,
    "predictions": predictions,
    "insights": insights
})

# 9. 결과 내보내기
export_result = self.export_results(report)

# 결과 반환
result = {
    "status": "success",
    "data_source": data_source,
    "analysis_type": analysis_type,
    "statistics": statistics,
    "patterns": patterns,
    "visualizations": visualizations,
    "predictions": predictions,
    "insights": insights,
    "report": report,
    "export": export_result,
    "timestamp": datetime.now().isoformat(),
    "message": "데이터 분석 완료"
}

logger.info("✅ 데이터 분석 성공")
return result
'''
        return logic
    
    def generate_helper_methods(self) -> List[ast.FunctionDef]:
        """헬퍼 메서드 AST 노드 생성"""
        methods_code = """
def load_data(self, source: str) -> pd.DataFrame:
    '''데이터 로드'''
    try:
        if source.endswith('.csv'):
            return pd.read_csv(source)
        elif source.endswith('.json'):
            return pd.read_json(source)
        elif source.endswith('.xlsx'):
            return pd.read_excel(source)
        else:
            # 데모 데이터
            data = {
                'date': pd.date_range('2024-01-01', periods=100),
                'sales': np.random.randint(100, 1000, 100),
                'profit': np.random.randint(10, 100, 100),
                'customers': np.random.randint(50, 500, 100)
            }
            return pd.DataFrame(data)
    except Exception as e:
        logger.error(f"데이터 로드 실패: {e}")
        # 기본 데이터 반환
        return pd.DataFrame()

def clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
    '''데이터 정제'''
    # 결측치 처리
    df = df.dropna()
    
    # 중복 제거
    df = df.drop_duplicates()
    
    # 이상치 처리 (IQR 방법)
    for col in df.select_dtypes(include=[np.number]).columns:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]
    
    return df

def analyze_statistics(self, df: pd.DataFrame, columns: List[str] = None) -> Dict:
    '''통계 분석'''
    if columns:
        df_subset = df[columns]
    else:
        df_subset = df.select_dtypes(include=[np.number])
    
    stats = {
        'descriptive': df_subset.describe().to_dict(),
        'correlation': df_subset.corr().to_dict(),
        'skewness': df_subset.skew().to_dict(),
        'kurtosis': df_subset.kurtosis().to_dict()
    }
    
    return stats

def detect_patterns(self, df: pd.DataFrame) -> Dict:
    '''패턴 감지'''
    patterns = {
        'trends': [],
        'seasonality': [],
        'anomalies': []
    }
    
    # 트렌드 감지
    for col in df.select_dtypes(include=[np.number]).columns:
        values = df[col].values
        trend = np.polyfit(range(len(values)), values, 1)[0]
        patterns['trends'].append({
            'column': col,
            'trend': 'increasing' if trend > 0 else 'decreasing',
            'strength': abs(trend)
        })
    
    # 이상치 감지 (Z-score)
    from scipy import stats
    for col in df.select_dtypes(include=[np.number]).columns:
        z_scores = np.abs(stats.zscore(df[col]))
        anomalies = df[z_scores > 3]
        if not anomalies.empty:
            patterns['anomalies'].append({
                'column': col,
                'count': len(anomalies),
                'indices': anomalies.index.tolist()
            })
    
    return patterns

def create_visualizations(self, df: pd.DataFrame, analysis_type: str) -> List[Dict]:
    '''시각화 생성'''
    visualizations = []
    
    # 히스토그램
    for col in df.select_dtypes(include=[np.number]).columns:
        visualizations.append({
            'type': 'histogram',
            'column': col,
            'data': df[col].value_counts().to_dict()
        })
    
    # 상관관계 히트맵 데이터
    numeric_df = df.select_dtypes(include=[np.number])
    if not numeric_df.empty:
        visualizations.append({
            'type': 'heatmap',
            'data': numeric_df.corr().to_dict()
        })
    
    # 시계열 데이터
    if 'date' in df.columns:
        for col in numeric_df.columns:
            visualizations.append({
                'type': 'timeseries',
                'x': 'date',
                'y': col,
                'data': df[['date', col]].to_dict('records')
            })
    
    return visualizations

def predict_trends(self, df: pd.DataFrame) -> Dict:
    '''트렌드 예측'''
    predictions = {}
    
    # 간단한 선형 회귀 예측
    from sklearn.linear_model import LinearRegression
    
    for col in df.select_dtypes(include=[np.number]).columns:
        values = df[col].values
        X = np.arange(len(values)).reshape(-1, 1)
        y = values
        
        model = LinearRegression()
        model.fit(X, y)
        
        # 미래 10개 포인트 예측
        future_X = np.arange(len(values), len(values) + 10).reshape(-1, 1)
        future_predictions = model.predict(future_X)
        
        predictions[col] = {
            'current_trend': model.coef_[0],
            'future_values': future_predictions.tolist(),
            'confidence': model.score(X, y)
        }
    
    return predictions

def extract_insights(self, analysis_results: Dict) -> List[str]:
    '''인사이트 추출'''
    insights = []
    
    # 통계 인사이트
    if 'statistics' in analysis_results:
        stats = analysis_results['statistics']
        if 'correlation' in stats:
            corr = stats['correlation']
            # 강한 상관관계 찾기
            for col1 in corr:
                for col2 in corr[col1]:
                    if col1 != col2 and abs(corr[col1][col2]) > 0.7:
                        insights.append(
                            f"강한 상관관계: {col1} ↔ {col2} (r={corr[col1][col2]:.2f})"
                        )
    
    # 패턴 인사이트
    if 'patterns' in analysis_results:
        patterns = analysis_results['patterns']
        for trend in patterns.get('trends', []):
            if trend['strength'] > 0.5:
                insights.append(
                    f"{trend['column']}에서 강한 {trend['trend']} 트렌드 감지"
                )
    
    # 예측 인사이트
    if 'predictions' in analysis_results:
        for col, pred in analysis_results['predictions'].items():
            if pred['confidence'] > 0.8:
                insights.append(
                    f"{col} 예측 신뢰도 높음 (R²={pred['confidence']:.2f})"
                )
    
    return insights

def generate_report(self, analysis_data: Dict) -> Dict:
    '''분석 보고서 생성'''
    report = {
        'title': '데이터 분석 보고서',
        'generated_at': datetime.now().isoformat(),
        'summary': {
            'total_insights': len(analysis_data.get('insights', [])),
            'patterns_found': len(analysis_data.get('patterns', {}).get('trends', [])),
            'anomalies_detected': len(analysis_data.get('patterns', {}).get('anomalies', [])),
            'predictions_made': len(analysis_data.get('predictions', {}))
        },
        'sections': {
            'statistics': analysis_data.get('statistics', {}),
            'patterns': analysis_data.get('patterns', {}),
            'predictions': analysis_data.get('predictions', {}),
            'insights': analysis_data.get('insights', []),
            'visualizations': analysis_data.get('visualizations', [])
        }
    }
    return report

def export_results(self, report: Dict) -> Dict:
    '''결과 내보내기'''
    return {
        'format': 'json',
        'exported': True,
        'path': '/tmp/data_analysis_report.json',
        'size': len(str(report))
    }
"""
        tree = ast.parse(methods_code)
        return tree.body