#!/usr/bin/env python3
"""
Universal Code Parser - 모든 LLM 응답을 정확히 파싱하는 통합 시스템
"""

import re
import json
import ast
from typing import Any, Dict, Optional, Union
from enum import Enum
from loguru import logger

class ResponseType(Enum):
    JSON = "json"
    MARKDOWN = "markdown"
    CODE_BLOCK = "code_block"
    PLAIN_TEXT = "plain_text"
    MIXED = "mixed"

class UniversalCodeParser:
    """모든 LLM 응답을 정확히 파싱하는 범용 파서"""
    
    def __init__(self):
        self.patterns = {
            # JSON 패턴들
            'json_with_code': r'\{\s*["\']code["\']\s*:\s*["\']([^"\']*)["\'].*?\}',
            'json_object': r'\{[\s\S]*?\}',
            'json_in_text': r'```json\s*([\s\S]*?)\s*```',
            
            # 코드 블록 패턴들
            'python_block': r'```python\s*([\s\S]*?)\s*```',
            'code_block': r'```\s*([\s\S]*?)\s*```',
            'triple_quotes': r'"""([\s\S]*?)"""',
            
            # 실행 가능한 코드 패턴
            'import_start': r'(import\s+\w+|from\s+\w+)',
            'class_start': r'class\s+\w+',
            'function_start': r'def\s+\w+|async\s+def\s+\w+',
        }
        
        self.cleanup_patterns = [
            # 문제가 되는 패턴들 제거
            (r'exec\("""', ''),  # exec 구문 제거
            (r'exec\("', ''),    # exec 구문 제거  
            (r'exec\(\'', ''),   # exec 구문 제거
            (r'\{"code":\s*"[^"]*"\}', ''),  # JSON 객체 제거
            (r'^\s*\{["\']code["\']:', ''),  # JSON 시작 제거
            (r'^\s*```.*$', ''),  # 코드 블록 마커 제거
            (r'.*"""$', '"""'),   # 불완전한 종료 수정
        ]
    
    def parse(self, response: str) -> str:
        """LLM 응답에서 깨끗한 코드 추출"""
        
        if not response or not response.strip():
            logger.error("Empty response received")
            return self._get_emergency_code()
        
        logger.info(f"🔍 Parsing response of {len(response)} characters")
        
        # 1. 응답 타입 감지
        response_type = self._detect_response_type(response)
        logger.info(f"📊 Detected response type: {response_type.value}")
        
        # 2. 타입별 최적화된 파싱
        if response_type == ResponseType.JSON:
            code = self._parse_json_response(response)
        elif response_type == ResponseType.MARKDOWN:
            code = self._parse_markdown_response(response)
        elif response_type == ResponseType.CODE_BLOCK:
            code = self._parse_code_block_response(response)
        else:
            code = self._parse_text_response(response)
        
        # 3. 코드 정제 및 검증
        cleaned_code = self._clean_and_validate(code)
        
        # 4. 최종 검증
        if self._is_valid_python_code(cleaned_code):
            logger.info("✅ Successfully parsed and validated code")
            return cleaned_code
        else:
            logger.warning("⚠️ Parsed code failed validation, applying emergency fixes")
            return self._apply_emergency_fixes(cleaned_code)
    
    def _detect_response_type(self, response: str) -> ResponseType:
        """응답 타입 자동 감지"""
        
        response_lower = response.lower().strip()
        
        # JSON 응답 감지
        if (response.strip().startswith('{') and response.strip().endswith('}')) or \
           '"code":' in response or "'code':" in response:
            return ResponseType.JSON
        
        # 마크다운 코드 블록 감지
        if '```python' in response or '```\n' in response:
            return ResponseType.MARKDOWN
        
        # 일반 코드 블록 감지
        if any(pattern in response for pattern in ['import ', 'class ', 'def ', 'async def']):
            return ResponseType.CODE_BLOCK
        
        # 혼합 타입 감지
        if '{' in response and 'import ' in response:
            return ResponseType.MIXED
        
        return ResponseType.PLAIN_TEXT
    
    def _parse_json_response(self, response: str) -> str:
        """JSON 응답에서 코드 추출"""
        
        logger.info("🔧 Parsing JSON response")
        
        try:
            # 직접 JSON 파싱 시도
            data = json.loads(response.strip())
            if isinstance(data, dict) and 'code' in data:
                logger.info("✅ Found code in JSON object")
                return str(data['code'])
        except json.JSONDecodeError:
            pass
        
        # JSON 패턴 매칭으로 코드 추출
        for pattern_name, pattern in [
            ('json_with_code', self.patterns['json_with_code']),
            ('json_in_text', self.patterns['json_in_text']),
            ('json_object', self.patterns['json_object'])
        ]:
            match = re.search(pattern, response, re.DOTALL)
            if match:
                logger.info(f"✅ Extracted code using {pattern_name}")
                
                if pattern_name == 'json_with_code':
                    return match.group(1)
                elif pattern_name == 'json_in_text':
                    # JSON 블록 내용 파싱
                    try:
                        json_data = json.loads(match.group(1))
                        if 'code' in json_data:
                            return str(json_data['code'])
                    except:
                        pass
                elif pattern_name == 'json_object':
                    # JSON 객체 전체 파싱
                    try:
                        json_data = json.loads(match.group(0))
                        if isinstance(json_data, dict) and 'code' in json_data:
                            return str(json_data['code'])
                    except:
                        pass
        
        logger.warning("❌ Failed to extract code from JSON, falling back to text parsing")
        return self._parse_text_response(response)
    
    def _parse_markdown_response(self, response: str) -> str:
        """마크다운 응답에서 코드 추출"""
        
        logger.info("🔧 Parsing Markdown response")
        
        # Python 코드 블록 우선 추출
        python_match = re.search(self.patterns['python_block'], response, re.DOTALL)
        if python_match:
            logger.info("✅ Found Python code block")
            return python_match.group(1).strip()
        
        # 일반 코드 블록 추출
        code_match = re.search(self.patterns['code_block'], response, re.DOTALL)
        if code_match:
            logger.info("✅ Found generic code block")
            return code_match.group(1).strip()
        
        logger.warning("❌ No code blocks found in Markdown, parsing as text")
        return self._parse_text_response(response)
    
    def _parse_code_block_response(self, response: str) -> str:
        """코드 블록 응답 파싱"""
        
        logger.info("🔧 Parsing code block response")
        
        # import로 시작하는 코드 찾기
        lines = response.split('\n')
        code_lines = []
        capturing = False
        
        for line in lines:
            stripped = line.strip()
            
            # 코드 시작 감지
            if not capturing and (
                stripped.startswith('import ') or 
                stripped.startswith('from ') or
                stripped.startswith('class ') or
                stripped.startswith('def ') or
                stripped.startswith('async def ')
            ):
                capturing = True
            
            if capturing:
                code_lines.append(line)
        
        if code_lines:
            logger.info("✅ Extracted code starting from imports/class/function")
            return '\n'.join(code_lines)
        
        # 전체 응답을 코드로 간주
        logger.info("⚠️ Using entire response as code")
        return response
    
    def _parse_text_response(self, response: str) -> str:
        """일반 텍스트 응답 파싱"""
        
        logger.info("🔧 Parsing text response")
        
        # 코드로 보이는 라인들만 추출
        lines = response.split('\n')
        code_lines = []
        
        for line in lines:
            stripped = line.strip()
            
            # 명백히 코드가 아닌 라인 제외
            if any(excluded in stripped.lower() for excluded in [
                'here is', 'here\'s', 'this code', 'the code', 'generated code',
                'solution:', 'answer:', 'result:', 'output:', 'explanation:'
            ]):
                continue
            
            # 코드 같은 라인만 포함
            if (stripped and 
                not stripped.startswith('#') and  # 주석 제외
                ('=' in stripped or 
                 stripped.startswith(('import ', 'from ', 'class ', 'def ', 'async ', 'if ', 'for ', 'while ', 'try:', 'return', 'await')) or
                 any(keyword in stripped for keyword in ['self.', '()', 'await ', 'async ', '__init__']))):
                code_lines.append(line)
        
        if code_lines:
            logger.info("✅ Extracted code-like lines from text")
            return '\n'.join(code_lines)
        
        # 전체 응답 반환 (최후의 수단)
        logger.warning("⚠️ Using entire response as fallback")
        return response
    
    def _clean_and_validate(self, code: str) -> str:
        """코드 정제 및 기본 검증"""
        
        if not code:
            return self._get_emergency_code()
        
        logger.info("🧹 Cleaning and validating code")
        
        # 문제 패턴 제거
        cleaned = code
        for pattern, replacement in self.cleanup_patterns:
            cleaned = re.sub(pattern, replacement, cleaned, flags=re.MULTILINE)
        
        # 빈 줄 정리
        lines = [line.rstrip() for line in cleaned.split('\n')]
        cleaned = '\n'.join(lines)
        
        # 들여쓰기 정리
        cleaned = self._fix_basic_indentation(cleaned)
        
        return cleaned
    
    def _fix_basic_indentation(self, code: str) -> str:
        """기본 들여쓰기 수정"""
        
        lines = code.split('\n')
        fixed_lines = []
        current_indent = 0
        
        for line in lines:
            stripped = line.strip()
            
            if not stripped:
                fixed_lines.append('')
                continue
            
            # 들여쓰기 레벨 결정
            if stripped.startswith(('class ', 'def ', 'async def ')):
                if stripped.startswith('class '):
                    current_indent = 0
                else:
                    current_indent = 4 if any('class ' in prev_line for prev_line in fixed_lines[-10:]) else 0
                fixed_lines.append(' ' * current_indent + stripped)
                if stripped.endswith(':'):
                    current_indent += 4
            elif stripped.startswith(('if ', 'for ', 'while ', 'try:', 'with ', 'except')):
                fixed_lines.append(' ' * current_indent + stripped)
                if stripped.endswith(':'):
                    current_indent += 4
            elif stripped in ['else:', 'elif', 'except:', 'finally:']:
                fixed_lines.append(' ' * max(0, current_indent - 4) + stripped)
                current_indent = max(4, current_indent)
            else:
                fixed_lines.append(' ' * current_indent + stripped)
        
        return '\n'.join(fixed_lines)
    
    def _is_valid_python_code(self, code: str) -> bool:
        """Python 코드 유효성 검사"""
        
        try:
            ast.parse(code)
            return True
        except SyntaxError as e:
            logger.warning(f"Syntax error in parsed code: {e}")
            return False
        except Exception as e:
            logger.warning(f"Unexpected error in code validation: {e}")
            return False
    
    def _apply_emergency_fixes(self, code: str, original_code: str = None) -> str:
        """비상 수정 적용 - 가능하면 원본 LLM 코드 사용"""
        
        logger.info("🚨 Applying emergency fixes")
        
        # Store original code if available
        if original_code and len(original_code) > 1000:
            self._cached_original_code = original_code
            logger.info(f"📦 Cached original LLM code: {len(original_code)} chars")
        
        # 기본 템플릿 변수 강제 치환
        emergency_fixes = {
            '{agent_class_name}': 'GeneratedAgent',
            '{agent_name}': 'Generated Agent',
            '{agent_description}': 'Auto-generated agent',
            '{custom_config}': 'dict(timeout=60)',  # Use dict() instead of JSON
            '{core_business_logic}': 'pass  # Business logic placeholder'
        }
        
        fixed_code = code
        for var, replacement in emergency_fixes.items():
            if var in fixed_code:
                fixed_code = fixed_code.replace(var, replacement)
                logger.info(f"🔧 Emergency fix: {var} → {replacement}")
        
        # 마지막 검증
        if self._is_valid_python_code(fixed_code):
            return fixed_code
        else:
            logger.error("🚨 Emergency fixes failed")
            
            # Try to use cached original code if available
            if hasattr(self, '_cached_original_code') and self._cached_original_code:
                logger.info("📦 Attempting to use cached original LLM code")
                # Wrap original code in basic agent structure if needed
                if 'class' in self._cached_original_code and 'LogosAIAgent' in self._cached_original_code:
                    return self._cached_original_code
                else:
                    # Wrap in agent structure
                    return self._wrap_in_agent_structure(self._cached_original_code)
            
            # Last resort - use fallback template
            logger.error("🚨 Using minimal fallback template")
            return self._get_emergency_code()
    
    def _wrap_in_agent_structure(self, core_logic: str) -> str:
        """Core logic을 에이전트 구조로 감싸기"""
        
        logger.info("📦 Wrapping core logic in agent structure")
        
        # Clean up the core logic
        cleaned_logic = core_logic.strip()
        if not cleaned_logic:
            cleaned_logic = "pass  # No logic provided"
        
        # Properly indent the logic
        indented_logic = '\n'.join('        ' + line for line in cleaned_logic.split('\n'))
        
        return f'''from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType
import json
import datetime
import pandas as pd
import numpy as np

class GeneratedAgent(LogosAIAgent):
    """LLM-generated agent with original business logic"""
    
    def __init__(self, config=None):
        if config is None:
            config = AgentConfig(
                name="Generated Agent",
                agent_type=AgentType.CUSTOM,
                config={{"timeout": 60, "max_retries": 3}}
            )
        super().__init__(config)
        
        # Initialize variables
        self.data = {{}}
        self.results = []
    
    async def process(self, request):
        """Process user request with LLM-generated logic"""
        try:
            # Original LLM logic
{indented_logic}
            
            # Return result
            return AgentResponse(
                type=AgentResponseType.JSON,
                content={{"status": "success", "data": self.results}}
            )
        except Exception as e:
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}}
            )
'''
    
    def _get_emergency_code(self) -> str:
        """최후의 수단 - 기본 에이전트 코드"""
        
        return '''from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType

class GeneratedAgent(LogosAIAgent):
    """Emergency fallback agent"""
    
    def __init__(self, config=None):
        if config is None:
            config = AgentConfig(
                name="Generated Agent",
                agent_type=AgentType.CUSTOM,
                config={"timeout": 60}
            )
        super().__init__(config)
    
    async def process(self, request):
        """Process user request"""
        return AgentResponse(
            type=AgentResponseType.JSON,
            content={"status": "processed", "data": request}
        )

# Test code
async def main():
    agent = GeneratedAgent()
    result = await agent.process({"test": "data"})
    print(f"Result: {result}")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
'''

# 테스트 함수
def test_universal_parser():
    """파서 테스트"""
    
    parser = UniversalCodeParser()
    
    # 테스트 케이스들
    test_cases = [
        # JSON 응답
        '{"code": "class TestAgent:\\n    pass"}',
        
        # 마크다운 응답
        '''```python
class TestAgent:
    def __init__(self):
        pass
```''',
        
        # 문제가 있는 응답
        '''exec("""
class {agent_class_name}:
    pass
{"code": "return True"}
```''',
        
        # 혼합 응답
        '''Here is the generated code:

```python
from logosai import LogosAIAgent

class MyAgent(LogosAIAgent):
    def process(self, request):
        return {"result": "success"}
```

This agent processes requests.'''
    ]
    
    print("🧪 Testing Universal Code Parser")
    print("=" * 50)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📝 Test Case {i}:")
        print(f"Input: {test_case[:100]}...")
        
        try:
            result = parser.parse(test_case)
            print(f"✅ Parsed successfully:")
            print(f"Output: {result[:200]}...")
            
            # 구문 검사
            ast.parse(result)
            print("✅ Syntax valid!")
            
        except Exception as e:
            print(f"❌ Error: {e}")
    
    print("\n🎉 Parser testing complete!")

if __name__ == "__main__":
    test_universal_parser()