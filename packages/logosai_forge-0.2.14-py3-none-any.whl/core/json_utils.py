"""
JSON Utilities for FORGE AI
Safe and robust JSON parsing utilities
"""

import json
import re
from typing import Any, Dict, Optional
from loguru import logger


def extract_json_from_text(text: str) -> Optional[Dict[str, Any]]:
    """
    Extract JSON object from text that may contain markdown or other formatting
    
    Args:
        text: Raw text that may contain JSON
        
    Returns:
        Parsed JSON dict or None if extraction fails
    """
    if not text:
        return None
        
    # Clean the text
    text = text.strip()
    
    # Remove markdown code blocks
    patterns_to_remove = [
        r'```json\s*',
        r'```\s*',
        r'\s*```'
    ]
    
    for pattern in patterns_to_remove:
        text = re.sub(pattern, '', text)
    
    # Try to find JSON object
    json_patterns = [
        r'\{[\s\S]*\}',  # Match outermost braces
        r'\{[^{}]*\}',   # Match simple object without nested braces
    ]
    
    for pattern in json_patterns:
        matches = re.findall(pattern, text)
        if matches:
            # Try each match, starting with the longest
            matches.sort(key=len, reverse=True)
            for match in matches:
                try:
                    return json.loads(match)
                except json.JSONDecodeError:
                    continue
    
    # Last resort: try the whole text
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def safe_json_loads(text: str, default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Safely load JSON with fallback
    
    Args:
        text: JSON text to parse
        default: Default value if parsing fails
        
    Returns:
        Parsed JSON or default value
    """
    result = extract_json_from_text(text)
    if result is not None:
        return result
        
    if default is not None:
        return default
        
    return {}


def ensure_json_fields(data: Dict[str, Any], required_fields: list, defaults: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Ensure all required fields exist in JSON data
    
    Args:
        data: JSON data
        required_fields: List of required field names
        defaults: Optional default values for missing fields
        
    Returns:
        Data with all required fields
    """
    defaults = defaults or {}
    
    for field in required_fields:
        if field not in data:
            default_value = defaults.get(field, "")
            logger.debug(f"Adding missing field '{field}' with default: {default_value}")
            data[field] = default_value
            
    return data


def create_json_prompt_template(example: Dict[str, Any], description: str = "") -> str:
    """
    Create a clear JSON prompt template
    
    Args:
        example: Example JSON structure
        description: Optional description
        
    Returns:
        Formatted prompt template
    """
    json_str = json.dumps(example, indent=2, ensure_ascii=False)
    
    template = f"""
{description}

Return ONLY valid JSON in this exact format:
{json_str}

Important:
- Do NOT include markdown formatting
- Do NOT add explanatory text
- Return ONLY the JSON object
"""
    
    return template.strip()