"""
FunctionRegistry — Function version management.

Tracks: version history, quality scores, code diffs, rollback capability.
Each function improvement creates a new version (1.0 → 1.1 → 1.2).
"""

import sqlite3
import difflib
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path
from loguru import logger


class FunctionRegistry:
    """Function version management (SQLite)."""

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            db_path = str(Path(__file__).parent.parent / "prototype" / "backend" / "forge_evolution.db")
            cls._instance = cls(db_path)
        return cls._instance

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._init_db()

    def _init_db(self):
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS function_versions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    func_name TEXT NOT NULL,
                    version TEXT NOT NULL,
                    code TEXT NOT NULL,
                    quality_score REAL DEFAULT 0,
                    parent_version TEXT DEFAULT '',
                    change_reason TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    UNIQUE(func_name, version)
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_fv_name ON function_versions(func_name)")
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[FuncRegistry] DB init: {e}")

    def register_version(self, func_name: str, code: str, quality_score: float = 0,
                          change_reason: str = "") -> str:
        """Register new version (auto-increment: 1.0 → 1.1 → 1.2)."""
        try:
            conn = sqlite3.connect(self._db_path)
            row = conn.execute(
                "SELECT version FROM function_versions WHERE func_name=? ORDER BY id DESC LIMIT 1",
                (func_name,)
            ).fetchone()

            if row:
                parts = row[0].split(".")
                parent = row[0]
                new_version = f"{parts[0]}.{int(parts[1]) + 1}"
            else:
                parent = ""
                new_version = "1.0"

            conn.execute(
                """INSERT INTO function_versions
                   (func_name, version, code, quality_score, parent_version, change_reason, created_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (func_name, new_version, code, quality_score, parent, change_reason,
                 datetime.now().isoformat())
            )
            conn.commit()
            conn.close()
            logger.info(f"[FuncRegistry] {func_name} v{new_version} registered (quality={quality_score})")
            return new_version
        except Exception as e:
            logger.debug(f"[FuncRegistry] Register failed: {e}")
            return "0.0"

    def get_latest(self, func_name: str) -> Optional[Dict]:
        """Get latest version of a function."""
        try:
            conn = sqlite3.connect(self._db_path)
            row = conn.execute(
                "SELECT version, code, quality_score, change_reason, created_at FROM function_versions WHERE func_name=? ORDER BY id DESC LIMIT 1",
                (func_name,)
            ).fetchone()
            conn.close()
            if not row:
                return None
            return {"func_name": func_name, "version": row[0], "code": row[1],
                    "quality_score": row[2], "change_reason": row[3], "created_at": row[4]}
        except Exception:
            return None

    def get_version(self, func_name: str, version: str) -> Optional[Dict]:
        """Get specific version."""
        try:
            conn = sqlite3.connect(self._db_path)
            row = conn.execute(
                "SELECT version, code, quality_score, parent_version, change_reason, created_at FROM function_versions WHERE func_name=? AND version=?",
                (func_name, version)
            ).fetchone()
            conn.close()
            if not row:
                return None
            return {"func_name": func_name, "version": row[0], "code": row[1],
                    "quality_score": row[2], "parent_version": row[3], "change_reason": row[4]}
        except Exception:
            return None

    def get_version_history(self, func_name: str) -> List[Dict]:
        """Get full version history."""
        try:
            conn = sqlite3.connect(self._db_path)
            rows = conn.execute(
                "SELECT version, quality_score, parent_version, change_reason, created_at FROM function_versions WHERE func_name=? ORDER BY id",
                (func_name,)
            ).fetchall()
            conn.close()
            return [{"version": r[0], "quality_score": r[1], "parent": r[2],
                     "change_reason": r[3], "created_at": r[4]} for r in rows]
        except Exception:
            return []

    def compare_versions(self, func_name: str, v1: str, v2: str) -> Dict:
        """Compare two versions (diff + quality delta)."""
        a = self.get_version(func_name, v1)
        b = self.get_version(func_name, v2)
        if not a or not b:
            return {"error": "version not found"}
        diff = "".join(difflib.unified_diff(
            a["code"].splitlines(keepends=True), b["code"].splitlines(keepends=True),
            fromfile=f"v{v1}", tofile=f"v{v2}"
        ))
        return {"v1": v1, "v2": v2, "diff": diff,
                "quality_delta": round(b["quality_score"] - a["quality_score"], 3)}

    def rollback(self, func_name: str, to_version: str) -> Optional[str]:
        """Rollback to a previous version (creates new version with old code)."""
        target = self.get_version(func_name, to_version)
        if not target:
            return None
        return self.register_version(func_name, target["code"], target["quality_score"],
                                      f"Rollback to v{to_version}")
