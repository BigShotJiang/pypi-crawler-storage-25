"""
core.slice_library — Canonical import path for SliceLibrary.

Re-exports from core.business_logic_v2.slice_library so V6 pipeline
imports use a clean path without 'v2' in the name.
"""
from core.business_logic_v2.slice_library import *  # noqa: F401,F403
from core.business_logic_v2.slice_library import (
    SliceLibrary,
    get_slice_library,
    initialize_library,
)
