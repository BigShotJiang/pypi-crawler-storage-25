"""Redirect to canonical location."""
from core.business_logic_v2.slice_library.core_slices import *  # noqa: F401,F403
from core.business_logic_v2.slice_library.core_slices import create_core_slices, get_core_slice_ids
