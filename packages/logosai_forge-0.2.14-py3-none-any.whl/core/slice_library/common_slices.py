"""Redirect to canonical location."""
from core.business_logic_v2.slice_library.common_slices import *  # noqa: F401,F403
from core.business_logic_v2.slice_library.common_slices import create_common_slices
