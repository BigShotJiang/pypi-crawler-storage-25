"""Redirect to canonical location."""
from core.business_logic_v2.slice_library.domain_slices import *  # noqa: F401,F403
from core.business_logic_v2.slice_library.domain_slices import create_all_domain_slices
