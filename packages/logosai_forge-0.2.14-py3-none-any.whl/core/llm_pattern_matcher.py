#!/usr/bin/env python3
"""
LLM 기반 패턴 매칭 시스템
하드코딩된 키워드 대신 LLM을 사용해서 지능적으로 패턴 매칭
"""

import asyncio
import json
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from loguru import logger


class LLMPatternMatcher:
    """LLM을 사용한 지능적 패턴 매칭"""
    
    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        
    async def should_use_pattern_system(self, query: str, agent_type: str = "general") -> Tuple[bool, Dict[str, Any]]:
        """
        LLM을 사용해서 패턴 시스템 사용 여부를 지능적으로 판단
        
        Returns:
            Tuple[bool, Dict]: (사용_여부, 분석_결과)
        """
        
        # LLM 클라이언트가 없으면 fallback
        if not self.llm_client:
            logger.warning("🤖 LLM client not available, using fallback logic")
            return self._fallback_pattern_matching(query, agent_type)
        
        # LLM 프롬프트 생성
        prompt = self._create_pattern_analysis_prompt(query, agent_type)
        
        try:
            # LLM에게 질의
            logger.info("🧠 LLM 기반 패턴 분석 시작...")
            response = await self._query_llm(prompt)
            
            # 응답 파싱
            analysis = self._parse_llm_response(response)
            
            should_use = analysis.get('should_use_pattern_system', False)
            confidence = analysis.get('confidence', 0.0)
            
            logger.info(f"🤖 LLM 패턴 분석 결과: {should_use} (신뢰도: {confidence:.2f})")
            logger.info(f"🎯 감지된 도메인: {analysis.get('detected_domain', 'unknown')}")
            logger.info(f"🔍 복잡도: {analysis.get('complexity', 'unknown')}")
            
            return should_use, analysis
            
        except Exception as e:
            logger.error(f"❌ LLM 패턴 분석 실패: {e}")
            return self._fallback_pattern_matching(query, agent_type)
    
    def _create_pattern_analysis_prompt(self, query: str, agent_type: str) -> str:
        """패턴 분석용 LLM 프롬프트 생성"""
        
        return f"""분석 요청: 사용자 쿼리가 패턴 기반 비즈니스 로직을 필요로 하는지 판단해주세요.

사용자 쿼리: "{query}"
에이전트 타입: {agent_type}

다음 기준으로 분석해주세요:

1. **도메인 특화 여부**: 특정 도메인(금융, 데이터분석, ML/AI, 자동화, 마케팅 등)의 전문 로직이 필요한가?

2. **복잡도**: 
   - Simple: 기본적인 처리만 필요
   - Moderate: 중간 복잡도의 비즈니스 로직
   - Complex: 도메인 전문 지식과 복잡한 워크플로우 필요

3. **패턴 매칭 대상 도메인들**:
   - 데이터 분석/시각화 (CSV, Excel, 차트, 대시보드, 통계)
   - 머신러닝/AI (ML, 알고리즘, 모델, 훈련, 예측, AutoML)
   - 금융 (포트폴리오, 리스크, 투자, 거래, 분석)
   - 비즈니스 인텔리전스 (KPI, 모니터링, 보고서, 인사이트)
   - 자동화 (워크플로우, 스케줄링, 작업 관리)
   - 마케팅 (캠페인, 고객 분석, 세그멘테이션)
   - 개발/DevOps (CI/CD, 배포, 모니터링)
   - 커뮤니케이션 (이메일, 메시징, 알림)

4. **단순 작업**: 계산기, 텍스트 변환, 기본 검색 등은 패턴 시스템이 불필요

JSON 형식으로 응답해주세요:
{{
    "should_use_pattern_system": true/false,
    "confidence": 0.0-1.0,
    "detected_domain": "도메인명 또는 general",
    "complexity": "simple/moderate/complex",
    "reasoning": "판단 근거",
    "key_indicators": ["핵심 키워드들"],
    "business_logic_type": "예상되는 비즈니스 로직 유형"
}}

분석:"""

    async def _query_llm(self, prompt: str) -> str:
        """LLM에게 질의"""
        
        try:
            # 🔧 FIXED: FORGELLMManager 전용 호출 방식
            if hasattr(self.llm_client, 'generate_text'):
                # FORGELLMManager 방식
                response = await self.llm_client.generate_text(prompt, model_id="gemini.flash_lite")
            elif hasattr(self.llm_client, '_fallback_generate_text'):
                # Fallback 방식
                response = self.llm_client._fallback_generate_text(prompt, "gemini.flash_lite")
            elif hasattr(self.llm_client, 'generate_async'):
                response = await self.llm_client.generate_async(prompt)
            elif hasattr(self.llm_client, 'generate'):
                response = self.llm_client.generate(prompt)
            elif hasattr(self.llm_client, 'chat'):
                response = await self.llm_client.chat(prompt)
            else:
                # 🔧 FORGELLMManager가 callable이 아니므로 메서드 호출
                response = str(self.llm_client)
                raise ValueError(f"Unsupported LLM client: {type(self.llm_client)}")
            
            return response if isinstance(response, str) else str(response)
            
        except Exception as e:
            logger.error(f"❌ LLM 호출 실패: {e}")
            raise
    
    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """LLM 응답 파싱"""
        
        try:
            # JSON 부분만 추출
            response = response.strip()
            
            # 코드 블록 제거
            if '```json' in response:
                start = response.find('```json') + 7
                end = response.find('```', start)
                response = response[start:end]
            elif '```' in response:
                start = response.find('```') + 3
                end = response.find('```', start)
                response = response[start:end]
            
            # JSON으로 파싱
            if response.startswith('{'):
                return json.loads(response)
            else:
                # JSON이 아닌 경우 찾아서 추출
                import re
                json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
                matches = re.findall(json_pattern, response, re.DOTALL)
                if matches:
                    return json.loads(matches[0])
                else:
                    raise ValueError("No valid JSON found in response")
                    
        except Exception as e:
            logger.error(f"❌ LLM 응답 파싱 실패: {e}")
            logger.error(f"원본 응답: {response[:500]}...")
            
            # 응답에서 키워드 기반으로 추론
            return self._extract_fallback_analysis(response)
    
    def _extract_fallback_analysis(self, response: str) -> Dict[str, Any]:
        """LLM 응답 파싱 실패시 키워드 기반 추론"""
        
        response_lower = response.lower()
        
        # 패턴 시스템 사용 여부 키워드
        positive_keywords = [
            'true', 'yes', 'complex', 'domain-specific', 'business logic',
            'pattern', 'specialized', 'advanced'
        ]
        negative_keywords = [
            'false', 'no', 'simple', 'basic', 'general', 'unnecessary'
        ]
        
        positive_count = sum(1 for kw in positive_keywords if kw in response_lower)
        negative_count = sum(1 for kw in negative_keywords if kw in response_lower)
        
        should_use = positive_count > negative_count
        confidence = abs(positive_count - negative_count) / max(positive_count + negative_count, 1)
        
        return {
            'should_use_pattern_system': should_use,
            'confidence': confidence,
            'detected_domain': 'unknown',
            'complexity': 'moderate' if should_use else 'simple',
            'reasoning': 'Extracted from LLM response keywords',
            'key_indicators': [],
            'business_logic_type': 'unknown'
        }
    
    def _fallback_pattern_matching(self, query: str, agent_type: str) -> Tuple[bool, Dict[str, Any]]:
        """LLM 사용 불가시 fallback 로직 (기존 키워드 기반보다 개선됨)"""
        
        logger.warning("🔄 Using improved fallback pattern matching")
        
        query_lower = query.lower()
        
        # 🔧 FIXED: 도메인별 키워드 패턴 (AutoML 키워드 강화)
        domain_patterns = {
            'data_analysis': {
                'keywords': ['csv', 'excel', '데이터', '분석', 'analysis', '차트', '대시보드', 'dashboard', 
                           '시각화', 'visualization', '통계', 'statistics', '상관관계', 'correlation'],
                'weight': 1.0
            },
            'machine_learning': {
                'keywords': [
                    # 기본 ML 키워드
                    'ml', 'ML', 'machine learning', '머신러닝', 'ai', '인공지능', 
                    '모델', 'model', 'modeling', '알고리즘', 'algorithm', 
                    '훈련', 'training', '예측', 'prediction', 
                    # AutoML 전용 키워드
                    'automl', 'AutoML', 'auto ml', 'auto-ml',
                    '하이퍼파라미터', 'hyperparameter', 'hyper parameter',
                    '튜닝', 'tuning', 'optimization', '최적화',
                    '성능', 'performance', '평가', 'evaluation', 'validation',
                    '배포', 'deployment', 'deploy', '원클릭', 'one-click',
                    # ML 라이브러리
                    'sklearn', 'scikit-learn', 'tensorflow', 'pytorch',
                    # ML 기법
                    'classification', '분류', 'regression', '회귀', 
                    'clustering', '클러스터링', 'ensemble', '앙상블',
                    'cross-validation', 'grid search', 'random search'
                ],
                'weight': 1.2  # ML은 복잡도가 높으므로 가중치 증가
            },
            'financial': {
                'keywords': ['금융', 'financial', '포트폴리오', 'portfolio', '투자', 'investment',
                           '리스크', 'risk', '거래', 'trading', '주식', 'stock', '암호화폐', 'crypto'],
                'weight': 1.1
            },
            'business_intelligence': {
                'keywords': ['bi', 'business intelligence', 'kpi', '모니터링', 'monitoring',
                           '보고서', 'report', '인사이트', 'insight', '메트릭', 'metrics'],
                'weight': 1.0
            },
            'automation': {
                'keywords': ['자동화', 'automation', '워크플로우', 'workflow', '스케줄링', 'scheduling',
                           '작업', 'task', '프로세스', 'process', '배치', 'batch'],
                'weight': 0.9
            }
        }
        
        # 도메인 점수 계산
        domain_scores = {}
        total_matches = 0
        
        for domain, pattern in domain_patterns.items():
            matches = sum(1 for kw in pattern['keywords'] if kw in query_lower)
            score = matches * pattern['weight']
            domain_scores[domain] = score
            total_matches += matches
        
        # 최고 점수 도메인
        best_domain = max(domain_scores.items(), key=lambda x: x[1]) if domain_scores else ('general', 0)
        
        # 패턴 시스템 사용 결정
        should_use = total_matches >= 2  # 최소 2개 키워드 매칭
        confidence = min(total_matches / 5.0, 1.0)  # 5개 이상이면 100% 확신
        
        complexity = 'complex' if total_matches >= 4 else 'moderate' if total_matches >= 2 else 'simple'
        
        analysis = {
            'should_use_pattern_system': should_use,
            'confidence': confidence,
            'detected_domain': best_domain[0] if best_domain[1] > 0 else 'general',
            'complexity': complexity,
            'reasoning': f'Keyword-based fallback: {total_matches} matches',
            'key_indicators': [kw for domain_pattern in domain_patterns.values() for kw in domain_pattern['keywords'] if kw in query_lower],
            'business_logic_type': 'domain-specific' if should_use else 'general'
        }
        
        logger.info(f"🔄 Fallback 결과: {should_use} (키워드 {total_matches}개, 신뢰도 {confidence:.2f})")
        
        return should_use, analysis


# 싱글톤 인스턴스
_llm_pattern_matcher = None

def get_llm_pattern_matcher(llm_client=None) -> LLMPatternMatcher:
    """LLM 패턴 매칭 싱글톤 인스턴스 반환"""
    global _llm_pattern_matcher
    
    if _llm_pattern_matcher is None:
        _llm_pattern_matcher = LLMPatternMatcher(llm_client)
        logger.info("🧠 LLM 패턴 매칭 시스템 초기화 완료")
    
    return _llm_pattern_matcher
