"""
Smart Template Generator for FORGE AI
Generates agent code using template system with streaming support and automatic error fixing
"""

import asyncio
import re
import ast
import json
from typing import Optional, Any, Callable, Dict, List, Tuple
from datetime import datetime
from pathlib import Path
from enum import Enum
from loguru import logger

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts
from .sandbox_executor import SandboxExecutor, ExecutionResult


class StreamEventType(Enum):
    """Detailed streaming event types for real-time updates"""
    # Analysis stage
    ANALYSIS_START = "analysis_start"
    ANALYSIS_DOMAIN = "analysis_domain"
    ANALYSIS_FEATURES = "analysis_features"
    ANALYSIS_COMPLETE = "analysis_complete"
    
    # Generation stage
    GENERATION_START = "generation_start"
    TEMPLATE_SELECTED = "template_selected"
    GENERATING_INIT = "generating_init"
    INIT_GENERATED = "init_generated"
    GENERATING_LOGIC = "generating_logic"
    LOGIC_GENERATED = "logic_generated"
    GENERATING_SAMPLE = "generating_sample"
    SAMPLE_GENERATED = "sample_generated"
    GENERATING_TEST = "generating_test"
    TEST_GENERATED = "test_generated"
    CODE_ASSEMBLED = "code_assembled"
    
    # Test stage
    TEST_START = "test_start"
    TEST_RUNNING = "test_running"
    TEST_OUTPUT = "test_output"
    TEST_ERROR = "test_error"
    TEST_SUCCESS = "test_success"
    
    # Fix stage
    FIX_START = "fix_start"
    FIX_ANALYZING = "fix_analyzing"
    FIX_APPLYING = "fix_applying"
    FIX_COMPLETE = "fix_complete"
    
    # Completion
    GENERATION_COMPLETE = "generation_complete"
    GENERATION_FAILED = "generation_failed"


class SmartTemplateGenerator:
    """
    Intelligent template-based code generator with streaming support
    """
    
    def __init__(self, llm_orchestrator: LLMOrchestrator, sandbox_executor: SandboxExecutor):
        """Initialize with LLM and sandbox executor"""
        self.llm = llm_orchestrator
        self.sandbox = sandbox_executor
        self.template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template_clean.py.template"
        
        # Load clean template
        try:
            with open(self.template_path, 'r') as f:
                self.template = f.read()
        except Exception as e:
            logger.error(f"Could not load template: {e}")
            self.template = ""
        
        # Track generation state
        self.current_code = ""
        self.fix_attempts = 0
        self.max_fix_attempts = 3
    
    async def generate_progressively(self, analysis: QueryAnalysis, context: Context,
                                    stream_callback: Optional[Callable] = None) -> Any:
        """Generate agent code with detailed streaming updates"""
        
        start_time = datetime.now()
        
        try:
            # Start generation
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_START,
                "🚀 에이전트 생성을 시작합니다...",
                {"progress": 0, "total_stages": 7}
            )
            
            # 1. Extract agent metadata
            agent_metadata = await self._generate_agent_metadata(analysis, stream_callback)
            
            # 2. Generate initialization code
            init_code = await self._generate_init_code(analysis, stream_callback)
            
            # 3. Generate business logic
            logic_code = await self._generate_business_logic(analysis, stream_callback)
            
            # 4. Generate sample data
            sample_data_code = await self._generate_sample_data(analysis, stream_callback)
            
            # 5. Generate test code
            test_code = await self._generate_test_code(analysis, sample_data_code, stream_callback)
            
            # 6. Assemble complete code
            complete_code = await self._assemble_code(
                agent_metadata,
                init_code,
                logic_code,
                sample_data_code,
                test_code,
                stream_callback
            )
            
            # 7. Test and fix until working
            final_code = await self._test_and_fix_code(complete_code, analysis, stream_callback)
            
            # Complete
            total_time = (datetime.now() - start_time).total_seconds()
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_COMPLETE,
                f"✅ 에이전트 생성 완료! (총 {total_time:.1f}초)",
                {
                    "progress": 100,
                    "total_time": total_time,
                    "code_length": len(final_code)
                }
            )
            
            # Create artifacts
            artifacts = self._create_artifacts(analysis, start_time, final_code)
            
            # Return result
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "smart_template_generation"
            
            return GeneratedCode(code=final_code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Generation failed: {e}")
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_FAILED,
                f"❌ 생성 실패: {str(e)}",
                {"error": str(e)}
            )
            raise
    
    async def _generate_agent_metadata(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> Dict[str, str]:
        """Generate agent metadata including class name"""
        
        await self._stream_event(
            callback,
            StreamEventType.ANALYSIS_DOMAIN,
            f"📋 도메인 분석: {analysis.domain or 'general'}",
            {"progress": 5, "domain": analysis.domain}
        )
        
        # Generate English class name
        class_name = self._generate_english_class_name(analysis)
        
        await self._stream_event(
            callback,
            StreamEventType.ANALYSIS_FEATURES,
            f"🎯 필요 기능: {', '.join(analysis.required_capabilities[:3])}...",
            {"progress": 10, "features": analysis.required_capabilities}
        )
        
        return {
            'agent_class_name': class_name,
            'agent_name': class_name.replace('Agent', ' Agent'),
            'agent_type': 'CUSTOM',
            'agent_description': analysis.query[:200],
            'custom_config': self._generate_config_dict(analysis)
        }
    
    async def _generate_init_code(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Generate initialization code"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_INIT,
            "🔧 초기화 코드를 생성하고 있습니다...",
            {"progress": 15}
        )
        
        prompt = f"""Generate ONLY Python initialization code for this agent:
{analysis.query}

Requirements:
1. ONLY variable initialization (self.xxx = ...)
2. NO imports, NO comments in Korean
3. Keep it concise and relevant

Example format:
self.data_cache = {{}}
self.threshold = 0.95
self.api_client = None

Generate initialization code:"""

        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=1000,
            temperature=0.3
        )
        
        code = self._extract_code(result)
        
        await self._stream_event(
            callback,
            StreamEventType.INIT_GENERATED,
            "✅ 초기화 코드 생성 완료",
            {"progress": 20, "code_preview": code[:100] + "..."}
        )
        
        return code
    
    async def _generate_business_logic(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Generate core business logic"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_LOGIC,
            "💡 핵심 비즈니스 로직을 구현하고 있습니다...",
            {"progress": 25}
        )
        
        # Generate feature by feature
        all_logic = []
        features = analysis.required_capabilities
        
        for i, feature in enumerate(features[:5]):  # Limit to 5 main features
            progress = 30 + (i * 10)
            
            await self._stream_event(
                callback,
                StreamEventType.GENERATING_LOGIC,
                f"💡 {feature} 기능 구현 중...",
                {"progress": progress, "current_feature": feature}
            )
            
            prompt = f"""Generate Python code for this specific feature: {feature}

Context: {analysis.query}

Requirements:
1. ONLY the implementation code
2. Use clear variable names
3. Return results as dictionary
4. Handle errors gracefully
5. NO Korean comments

Generate the code:"""

            result = await self.llm.generate(
                prompt=prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=2000,
                temperature=0.4
            )
            
            feature_code = self._extract_code(result)
            all_logic.append(f"# {feature}\n{feature_code}")
        
        final_logic = "\n\n".join(all_logic)
        
        await self._stream_event(
            callback,
            StreamEventType.LOGIC_GENERATED,
            "✅ 비즈니스 로직 구현 완료",
            {"progress": 70}
        )
        
        return final_logic
    
    async def _generate_sample_data(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Generate domain-specific sample data"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_SAMPLE,
            "📊 테스트용 샘플 데이터를 생성하고 있습니다...",
            {"progress": 75}
        )
        
        domain = (analysis.domain or "general").lower()
        
        # Domain-specific sample data templates
        if "financial" in domain or "finance" in domain:
            sample_template = """
# Financial sample data
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

dates = pd.date_range(end=datetime.now(), periods=100, freq='D')
prices = 100 + np.cumsum(np.random.randn(100) * 2)
volumes = np.random.randint(1000, 10000, 100)

portfolio_data = pd.DataFrame({
    'date': dates,
    'price': prices,
    'volume': volumes,
    'returns': np.random.randn(100) * 0.02
})
"""
        elif "customer" in domain:
            sample_template = """
# Customer sample data
import pandas as pd
import numpy as np

customer_data = pd.DataFrame({
    'customer_id': range(1, 101),
    'age': np.random.randint(18, 70, 100),
    'purchase_count': np.random.poisson(5, 100),
    'total_spent': np.random.exponential(100, 100),
    'segment': np.random.choice(['VIP', 'Regular', 'New'], 100)
})
"""
        else:
            # Generic data
            sample_template = """
# Generic sample data
sample_data = {
    'items': [f'item_{i}' for i in range(100)],
    'values': [np.random.random() * 100 for _ in range(100)],
    'categories': ['A', 'B', 'C'] * 33 + ['A']
}
"""
        
        await self._stream_event(
            callback,
            StreamEventType.SAMPLE_GENERATED,
            "✅ 샘플 데이터 생성 완료",
            {"progress": 80}
        )
        
        return sample_template.strip()
    
    async def _generate_test_code(self, analysis: QueryAnalysis, sample_data: str, callback: Optional[Callable]) -> str:
        """Generate test code with sample data"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_TEST,
            "🧪 테스트 코드를 작성하고 있습니다...",
            {"progress": 85}
        )
        
        # Extract main capabilities for testing
        test_queries = []
        for cap in analysis.required_capabilities[:3]:
            test_queries.append(f"Test {cap}")
        
        test_template = f"""
# Test queries
test_queries = {test_queries}

for i, query in enumerate(test_queries):
    logger.info(f"\\nTest {{i+1}}: {{query}}")
    
    request = {{"query": query}}
    response = await agent.process(request)
    
    logger.info(f"Response type: {{response.type}}")
    logger.info(f"Response: {{json.dumps(response.content, indent=2, ensure_ascii=False)}}")
"""
        
        await self._stream_event(
            callback,
            StreamEventType.TEST_GENERATED,
            "✅ 테스트 코드 작성 완료",
            {"progress": 90}
        )
        
        return test_template.strip()
    
    async def _assemble_code(self, metadata: Dict, init_code: str, logic_code: str, 
                           sample_data: str, test_code: str, callback: Optional[Callable]) -> str:
        """Assemble all parts into complete code"""
        
        await self._stream_event(
            callback,
            StreamEventType.CODE_ASSEMBLED,
            "🔨 전체 코드를 조립하고 있습니다...",
            {"progress": 92}
        )
        
        # Apply template
        final_code = self.template.format(
            agent_class_name=metadata['agent_class_name'],
            agent_name=metadata['agent_name'],
            agent_type=metadata['agent_type'],
            agent_description=metadata['agent_description'],
            custom_config=metadata['custom_config'],
            custom_init=self._indent_code(init_code, 8),
            custom_async_init=self._indent_code("# No additional async initialization required", 12),
            core_business_logic=self._indent_code(logic_code, 12),
            custom_cleanup=self._indent_code("# No additional cleanup required", 12),
            sample_data=self._indent_code(sample_data, 4),
            test_queries=test_code
        )
        
        return final_code
    
    async def _test_and_fix_code(self, code: str, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Test code and fix errors automatically"""
        
        self.fix_attempts = 0
        current_code = code
        
        while self.fix_attempts < self.max_fix_attempts:
            await self._stream_event(
                callback,
                StreamEventType.TEST_START,
                f"🧪 코드 실행 테스트 중... (시도 {self.fix_attempts + 1}/{self.max_fix_attempts})",
                {"progress": 93 + self.fix_attempts * 2}
            )
            
            # Test execution
            test_result = await self.sandbox.execute(
                code=current_code,
                input_data={},
                timeout=30
            )
            
            if test_result.success:
                await self._stream_event(
                    callback,
                    StreamEventType.TEST_SUCCESS,
                    "✅ 실행 테스트 성공!",
                    {
                        "progress": 98,
                        "output_preview": test_result.output[:300] if test_result.output else "",
                        "execution_time": test_result.execution_time_ms
                    }
                )
                return current_code
            
            # Error occurred
            await self._stream_event(
                callback,
                StreamEventType.TEST_ERROR,
                f"❌ 에러 발생: {self._classify_error(test_result.stderr)}",
                {
                    "progress": 94 + self.fix_attempts * 2,
                    "error_type": self._classify_error(test_result.stderr),
                    "error_detail": test_result.stderr[:500],
                    "attempt": self.fix_attempts + 1
                }
            )
            
            # Fix error
            current_code = await self._fix_error(current_code, test_result, analysis, callback)
            self.fix_attempts += 1
        
        # If we get here, we couldn't fix all errors
        logger.warning(f"Could not fix all errors after {self.max_fix_attempts} attempts")
        return current_code
    
    async def _fix_error(self, code: str, test_result: ExecutionResult, 
                        analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Fix specific error in code"""
        
        error_type = self._classify_error(test_result.stderr)
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_START,
            f"🔧 {error_type} 수정을 시작합니다...",
            {"error_type": error_type}
        )
        
        # Error-specific fixes
        if error_type == "ImportError":
            fixed_code = await self._fix_import_error(code, test_result.stderr, callback)
        elif error_type == "NameError":
            fixed_code = await self._fix_name_error(code, test_result.stderr, callback)
        elif error_type == "SyntaxError":
            fixed_code = await self._fix_syntax_error(code, test_result.stderr, callback)
        elif error_type == "TypeError":
            fixed_code = await self._fix_type_error(code, test_result.stderr, callback)
        else:
            # General LLM fix
            fixed_code = await self._llm_fix_error(code, test_result.stderr, callback)
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_COMPLETE,
            "✅ 에러 수정 완료",
            {"progress": 95 + self.fix_attempts}
        )
        
        return fixed_code
    
    async def _fix_import_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix import errors by adding missing imports"""
        
        # Extract missing module
        import_match = re.search(r"No module named '(\w+)'", error)
        if import_match:
            module = import_match.group(1)
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_APPLYING,
                f"📦 누락된 모듈 추가: {module}",
                {"fix_type": "add_import", "module": module}
            )
            
            # Add import at the beginning
            import_line = f"import {module}\n"
            if f"import {module}" not in code:
                # Find the right place to add import
                lines = code.split('\n')
                import_index = 0
                for i, line in enumerate(lines):
                    if line.startswith('from logosai'):
                        import_index = i + 1
                        break
                
                lines.insert(import_index, import_line)
                return '\n'.join(lines)
        
        return code
    
    async def _fix_name_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix undefined variable errors"""
        
        # Extract undefined name
        name_match = re.search(r"name '(\w+)' is not defined", error)
        if name_match:
            var_name = name_match.group(1)
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_APPLYING,
                f"🔤 미정의 변수 초기화: {var_name}",
                {"fix_type": "define_variable", "variable": var_name}
            )
            
            # Common fixes
            if var_name == 'np':
                return code.replace('import numpy', 'import numpy as np')
            elif var_name == 'pd':
                return code.replace('import pandas', 'import pandas as pd')
            
            # Add initialization
            init_line = f"        {var_name} = None  # Auto-fixed\n"
            init_marker = "def __init__(self"
            if init_marker in code:
                lines = code.split('\n')
                for i, line in enumerate(lines):
                    if init_marker in line:
                        # Find the end of __init__
                        j = i + 1
                        while j < len(lines) and lines[j].startswith('        '):
                            j += 1
                        lines.insert(j - 1, init_line)
                        return '\n'.join(lines)
        
        return code
    
    async def _fix_syntax_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix syntax errors using LLM"""
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "📝 문법 오류 분석 중...",
            {"fix_type": "syntax"}
        )
        
        # Extract line number
        line_match = re.search(r"line (\d+)", error)
        if line_match:
            line_num = int(line_match.group(1))
            
            # Get context around error
            lines = code.split('\n')
            start = max(0, line_num - 5)
            end = min(len(lines), line_num + 5)
            
            context = '\n'.join(f"{i+1}: {lines[i]}" for i in range(start, end))
            
            prompt = f"""Fix this Python syntax error:

Error: {error}

Code context:
{context}

Return ONLY the fixed line {line_num}:"""

            result = await self.llm.generate(
                prompt=prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=200,
                temperature=0.1
            )
            
            fixed_line = result.strip()
            if line_num <= len(lines):
                lines[line_num - 1] = fixed_line
                return '\n'.join(lines)
        
        return code
    
    def _fix_template_variables(self, code: str) -> str:
        """Fix unsubstituted template variables with default values"""
        
        # 기본값으로 치환
        default_replacements = {
            'agent_class_name': 'GeneratedAgent',
            'agent_name': 'Generated Agent',
            'agent_description': 'Auto-generated agent',
            'agent_type': 'CUSTOM',
            'custom_config': '{"timeout": 60, "retry_attempts": 3}',
            'custom_init': '# Custom initialization',
            'custom_async_init': '# Async initialization',
            'core_business_logic': '# Business logic placeholder',
            'initialization': '# Initialization code',
            'sample_data': '# Sample data placeholder',
            'test_queries': '# Test queries placeholder'
        }
        
        # 치환되지 않은 템플릿 변수 찾기
        template_vars = re.findall(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}', code)
        
        fixed_code = code
        for var in template_vars:
            placeholder = f'{{{var}}}'
            replacement = default_replacements.get(var, f'# TODO: Replace {placeholder}')
            
            if placeholder in fixed_code:
                logger.info(f"  Replacing {placeholder} with: {replacement[:50]}...")
                
                # 다중 줄 코드 블록의 들여쓰기 처리
                if '\n' in replacement and var in ['custom_init', 'core_business_logic', 'initialization']:
                    lines = fixed_code.split('\n')
                    for i, line in enumerate(lines):
                        if placeholder in line:
                            # 해당 라인의 들여쓰기 감지
                            indent_match = re.match(r'^(\s*)', line)
                            base_indent = indent_match.group(1) if indent_match else ''
                            
                            # 치환값에 들여쓰기 적용
                            replacement_lines = replacement.split('\n')
                            indented_lines = []
                            for j, repl_line in enumerate(replacement_lines):
                                if j == 0:
                                    indented_lines.append(repl_line)
                                else:
                                    indented_lines.append(base_indent + repl_line if repl_line.strip() else repl_line)
                            
                            replacement = '\n'.join(indented_lines)
                            break
                
                fixed_code = fixed_code.replace(placeholder, replacement)
        
        return fixed_code
    
    async def _fix_type_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix type errors"""
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "🔢 타입 오류 분석 중...",
            {"fix_type": "type_error"}
        )
        
        return await self._llm_fix_error(code, error, callback)
    
    async def _llm_fix_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Use LLM to fix any error"""
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "🤖 AI가 에러를 분석하고 있습니다...",
            {"fix_type": "llm_analysis"}
        )
        
        prompt = f"""Fix this Python error:

Error:
{error}

Code (show only the relevant part that needs fixing):
{code[-2000:]}  # Last 2000 chars

Return the complete fixed code:"""

        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=3000,
            temperature=0.3
        )
        
        # Extract code
        fixed_code = self._extract_code(result)
        
        # If we got a partial fix, try to merge it
        if len(fixed_code) < len(code) / 2:
            # Probably just a snippet, try to apply it
            return code  # For now, return original
        
        return fixed_code
    
    def _generate_english_class_name(self, analysis: QueryAnalysis) -> str:
        """Generate valid English class name"""
        
        domain = (analysis.domain or "").lower()
        intent = (analysis.intent or "").lower()
        
        # Domain-based naming
        if "financial" in domain or "finance" in domain or "risk" in intent:
            base_name = "FinancialRisk"
        elif "customer" in domain or "customer" in intent:
            base_name = "CustomerAnalysis"
        elif "api" in domain or "api" in intent:
            base_name = "ApiData"
        elif "data" in domain or "analysis" in intent:
            base_name = "DataAnalysis"
        elif "web" in domain or "scraping" in intent:
            base_name = "WebScraper"
        elif "monitoring" in intent:
            base_name = "SystemMonitor"
        else:
            # Use first capability
            if analysis.required_capabilities:
                first_cap = analysis.required_capabilities[0]
                words = first_cap.replace('_', ' ').split()
                base_name = ''.join(word.capitalize() for word in words)
            else:
                base_name = "Custom"
        
        return f"{base_name}Agent"
    
    def _generate_config_dict(self, analysis: QueryAnalysis) -> str:
        """Generate configuration dictionary"""
        
        # Determine appropriate model based on complexity
        if analysis.complexity.value == "expert":
            model = "gpt-4-turbo-preview"
            tokens = 8000
        elif analysis.complexity.value == "intermediate":
            model = "gpt-3.5-turbo"
            tokens = 4000
        else:
            model = "gpt-3.5-turbo"
            tokens = 2000
        
        return f"""{{
    "model": "{model}",
    "temperature": 0.7,
    "max_tokens": {tokens},
    "timeout": 30,
    "retry_attempts": 3,
    "cache_enabled": true
}}"""
    
    def _extract_code(self, response: str) -> str:
        """Extract clean code from LLM response"""
        
        # Try to extract from code blocks
        python_match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        if python_match:
            return python_match.group(1).strip()
        
        code_match = re.search(r'```\n(.*?)```', response, re.DOTALL)
        if code_match:
            return code_match.group(1).strip()
        
        # Return as is if no code blocks
        return response.strip()
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by specified spaces"""
        if not code:
            return ""
        
        indent = ' ' * spaces
        lines = code.split('\n')
        return '\n'.join(indent + line if line.strip() else line for line in lines)
    
    def _classify_error(self, error: str) -> str:
        """Classify error type from error message"""
        
        if "ImportError" in error or "No module named" in error:
            return "ImportError"
        elif "NameError" in error or "is not defined" in error:
            return "NameError"
        elif "SyntaxError" in error:
            return "SyntaxError"
        elif "TypeError" in error:
            return "TypeError"
        elif "AttributeError" in error:
            return "AttributeError"
        elif "ValueError" in error:
            return "ValueError"
        else:
            return "UnknownError"
    
    async def _stream_event(self, callback: Optional[Callable], event_type: StreamEventType,
                           message: str, data: Dict[str, Any] = None):
        """Send streaming event if callback is provided"""
        
        if callback:
            await callback(
                event_type.value,
                message,
                data or {}
            )
    
    def _create_artifacts(self, analysis: QueryAnalysis, start_time: datetime, final_code: str):
        """Create generation artifacts"""
        
        artifacts = GenerationArtifacts(
            generation_id=f"smart_gen_{datetime.now().timestamp()}",
            timestamp=start_time,
            original_query=analysis.query
        )
        
        artifacts.query_analysis = {
            "intent": analysis.intent,
            "domain": analysis.domain,
            "complexity": analysis.complexity.value,
            "capabilities": analysis.required_capabilities
        }
        
        artifacts.generated_code_raw = final_code
        artifacts.optimized_code = final_code
        artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return artifacts