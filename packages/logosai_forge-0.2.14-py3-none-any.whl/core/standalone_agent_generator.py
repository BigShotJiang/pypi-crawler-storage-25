"""
Standalone Agent Generator - 완전 독립형 에이전트 생성기
=======================================================
외부 의존성 없이 작동하는 에이전트 코드 생성
"""

import json
import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path


class StandaloneAgentGenerator:
    """독립형 에이전트 생성기 - LogosAI 의존성 제거"""
    
    def __init__(self):
        """초기화"""
        self.agent_types = {
            "data_analysis": "데이터 분석",
            "api_integration": "API 통합", 
            "web_scraping": "웹 스크래핑",
            "calculator": "계산기",
            "general_purpose": "범용"
        }
        print("🚀 StandaloneAgentGenerator 초기화 완료")
    
    async def generate_agent(self, user_request: str) -> Dict[str, Any]:
        """사용자 요청에서 에이전트 생성"""
        
        # 1. 요청 분석
        analysis = self._analyze_request(user_request)
        
        # 2. 에이전트 코드 생성
        agent_code = self._generate_agent_code(analysis)
        
        # 3. 메타데이터 생성
        metadata = self._generate_metadata(analysis)
        
        # 4. 실행 가능한 standalone 파일 생성
        standalone_code = self._generate_standalone_code(analysis)
        
        return {
            "code": agent_code,
            "standalone_code": standalone_code,
            "metadata": metadata,
            "analysis": analysis
        }
    
    def _analyze_request(self, request: str) -> Dict[str, Any]:
        """요청 분석"""
        request_lower = request.lower()
        
        # 에이전트 타입 감지
        if any(word in request_lower for word in ['데이터', '분석', 'csv', 'excel']):
            agent_type = "data_analysis"
        elif any(word in request_lower for word in ['api', 'rest', 'endpoint']):
            agent_type = "api_integration"
        elif any(word in request_lower for word in ['웹', '크롤링', 'scraping']):
            agent_type = "web_scraping"
        elif any(word in request_lower for word in ['계산', 'calculator']):
            agent_type = "calculator"
        else:
            agent_type = "general_purpose"
        
        # 에이전트 이름 생성
        agent_name = f"{agent_type.title().replace('_', '')}Agent"
        
        return {
            "agent_type": agent_type,
            "agent_name": agent_name,
            "description": request,
            "request": request
        }
    
    def _generate_standalone_code(self, analysis: Dict[str, Any]) -> str:
        """완전 독립형 실행 가능한 코드 생성"""
        
        agent_type = analysis["agent_type"]
        agent_name = analysis["agent_name"]
        description = analysis["description"]
        
        # 에이전트 타입별 핵심 로직
        core_logic = self._get_standalone_core_logic(agent_type)
        
        # 독립형 코드 생성
        code = f'''#!/usr/bin/env python3
"""
{agent_name} - Standalone Agent
{'='*30}
{description}

이 에이전트는 외부 의존성 없이 독립적으로 실행됩니다.
"""

import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class {agent_name}:
    """{description}"""
    
    def __init__(self):
        """Initialize the agent"""
        self.name = "{agent_name}"
        self.description = "{description}"
        self.agent_type = "{agent_type}"
        logger.info(f"{{self.name}} initialized")
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Process user query"""
        try:
            logger.info(f"Processing query: {{query}}")
            
            # Validate input
            if not query:
                return {{
                    "status": "error",
                    "error": "Empty query"
                }}
            
            # Initialize context
            if context is None:
                context = {{}}
            
{core_logic}
            
        except Exception as e:
            logger.error(f"Processing error: {{e}}")
            return {{
                "status": "error",
                "error": str(e)
            }}
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent information"""
        return {{
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "capabilities": self._get_capabilities()
        }}
    
    def _get_capabilities(self) -> List[str]:
        """Get agent capabilities"""
        capabilities_map = {{
            "calculator": ["basic_arithmetic", "expression_evaluation"],
            "data_analysis": ["data_processing", "statistical_analysis"],
            "api_integration": ["http_requests", "json_parsing"],
            "web_scraping": ["html_parsing", "data_extraction"],
            "general_purpose": ["text_processing", "general_tasks"]
        }}
        return capabilities_map.get(self.agent_type, ["general_processing"])


# 메인 실행 함수
async def main():
    """테스트 실행"""
    agent = {agent_name}()
    
    print(f"\\n{'='*60}")
    print(f"{{agent.name}} 테스트")
    print('='*60)
    print(f"설명: {{agent.description}}")
    print(f"타입: {{agent.agent_type}}")
    print(f"기능: {{', '.join(agent._get_capabilities())}}")
    print('='*60)
    
    # 테스트 쿼리
    test_queries = {self._get_test_queries(agent_type)}
    
    for query in test_queries:
        print(f"\\n쿼리: {{query}}")
        result = await agent.process(query)
        print(f"결과: {{json.dumps(result, ensure_ascii=False, indent=2)}}")
    
    print(f"\\n{'='*60}")
    print("테스트 완료!")


if __name__ == "__main__":
    asyncio.run(main())
'''
        
        return code
    
    def _get_standalone_core_logic(self, agent_type: str) -> str:
        """독립형 핵심 로직 생성"""
        
        if agent_type == "calculator":
            return '''            # 계산기 로직
            import re
            
            # 숫자 추출
            numbers = re.findall(r'-?\d+\.?\d*', query)
            if len(numbers) >= 2:
                num1, num2 = float(numbers[0]), float(numbers[1])
                
                # 연산 감지
                if '+' in query or '더하기' in query:
                    result = num1 + num2
                    operation = "더하기"
                elif '-' in query or '빼기' in query:
                    result = num1 - num2
                    operation = "빼기"
                elif '*' in query or '곱하기' in query:
                    result = num1 * num2
                    operation = "곱하기"
                elif '/' in query or '나누기' in query:
                    if num2 != 0:
                        result = num1 / num2
                        operation = "나누기"
                    else:
                        return {
                            "status": "error",
                            "error": "0으로 나눌 수 없습니다"
                        }
                else:
                    result = num1 + num2
                    operation = "더하기 (기본)"
                
                return {
                    "status": "success",
                    "result": result,
                    "operation": operation,
                    "expression": f"{num1} {operation} {num2} = {result}"
                }
            else:
                return {
                    "status": "error",
                    "error": "쿼리에서 충분한 숫자를 찾을 수 없습니다"
                }'''
        
        elif agent_type == "data_analysis":
            return '''            # 데이터 분석 로직
            # 간단한 데이터 분석 시뮬레이션
            data = context.get('data', None)
            
            if data:
                # 실제 데이터가 제공된 경우
                analysis_results = {
                    "data_received": True,
                    "data_type": type(data).__name__,
                    "analysis": "데이터 분석을 수행했습니다"
                }
            else:
                # 샘플 분석 결과
                analysis_results = {
                    "sample_analysis": {
                        "total_records": 1000,
                        "average_value": 52.3,
                        "max_value": 98.7,
                        "min_value": 12.1,
                        "categories": ["A", "B", "C"],
                        "trend": "increasing"
                    },
                    "message": "샘플 데이터 분석 결과입니다"
                }
            
            return {
                "status": "success",
                "analysis": analysis_results,
                "query": query
            }'''
        
        elif agent_type == "api_integration":
            return '''            # API 통합 로직
            # API 요청 시뮬레이션
            api_url = context.get('api_url', 'https://api.example.com/data')
            method = context.get('method', 'GET')
            
            # 실제 API 호출 대신 시뮬레이션
            simulated_response = {
                "api_url": api_url,
                "method": method,
                "status_code": 200,
                "response": {
                    "data": [
                        {"id": 1, "name": "Item 1", "value": 100},
                        {"id": 2, "name": "Item 2", "value": 200}
                    ],
                    "total": 2,
                    "timestamp": datetime.now().isoformat()
                }
            }
            
            return {
                "status": "success",
                "api_response": simulated_response,
                "message": "API 요청이 성공적으로 처리되었습니다"
            }'''
        
        else:  # general_purpose
            return '''            # 범용 처리 로직
            response_data = {
                "query": query,
                "processed_at": datetime.now().isoformat(),
                "context_keys": list(context.keys()) if context else [],
                "message": f"'{query}' 요청을 처리했습니다"
            }
            
            # 쿼리 내용에 따른 추가 처리
            if "help" in query.lower() or "도움" in query.lower():
                response_data["help"] = "다양한 작업을 도와드릴 수 있습니다. 구체적으로 무엇이 필요하신지 알려주세요."
            
            return {
                "status": "success",
                "data": response_data
            }'''
    
    def _get_test_queries(self, agent_type: str) -> str:
        """테스트 쿼리 생성"""
        queries_map = {
            "calculator": '["10 더하기 5는?", "100에서 25 빼면?", "7 곱하기 8"]',
            "data_analysis": '["데이터를 분석해줘", "트렌드를 보여줘", "통계 요약을 해줘"]',
            "api_integration": '["API 데이터를 가져와줘", "서버 상태를 확인해줘", "데이터를 동기화해줘"]',
            "web_scraping": '["웹사이트 데이터를 수집해줘", "페이지 내용을 가져와줘", "링크를 추출해줘"]',
            "general_purpose": '["도움이 필요해", "이것을 처리해줘", "정보를 찾아줘"]'
        }
        
        return queries_map.get(agent_type, '["테스트 쿼리"]')
    
    def _generate_agent_code(self, analysis: Dict[str, Any]) -> str:
        """LogosAI 호환 에이전트 코드 생성 (나중에 사용)"""
        # 기존 코드와 동일하게 유지
        return f"# LogosAI compatible agent code for {analysis['agent_name']}"
    
    def _generate_metadata(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """메타데이터 생성"""
        agent_id = str(uuid.uuid4())[:8]
        
        return {
            "agent_id": agent_id,
            "agent_name": analysis["agent_name"],
            "agent_type": analysis["agent_type"],
            "description": analysis["description"],
            "created_at": datetime.now().isoformat(),
            "version": "1.0.0",
            "standalone": True
        }


# 테스트 코드
if __name__ == "__main__":
    async def test():
        generator = StandaloneAgentGenerator()
        
        # 테스트 요청들
        test_requests = [
            "간단한 계산기 에이전트를 만들어줘",
            "CSV 파일을 분석하는 에이전트",
            "REST API와 연동하는 에이전트"
        ]
        
        for request in test_requests:
            print(f"\n{'='*60}")
            print(f"요청: {request}")
            print('='*60)
            
            result = await generator.generate_agent(request)
            
            print(f"에이전트 이름: {result['metadata']['agent_name']}")
            print(f"에이전트 타입: {result['metadata']['agent_type']}")
            print(f"독립형 코드 길이: {len(result['standalone_code'])} 문자")
            
            # 독립형 코드 파일로 저장
            filename = f"{result['metadata']['agent_name'].lower()}_{result['metadata']['agent_id']}.py"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(result['standalone_code'])
            
            print(f"✅ 독립형 파일 생성됨: {filename}")
    
    import asyncio
    asyncio.run(test())