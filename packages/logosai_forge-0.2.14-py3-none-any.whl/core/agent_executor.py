"""
Agent Executor for FORGE AI

Executes generated agents in a sandboxed environment.
All execution decisions are made by LLM.
"""

import os
import sys
import asyncio
import tempfile
import subprocess
import resource
import json
import traceback
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass
from datetime import datetime
from loguru import logger

from .llm_orchestrator import LLMOrchestrator, TaskType
from .prompts import prompt_registry

@dataclass
class ExecutionResult:
    """Result of agent execution"""
    success: bool
    output: Any
    error: Optional[str] = None
    execution_time: float = 0.0
    resource_usage: Dict[str, Any] = None
    sandbox_logs: str = ""
    metadata: Dict[str, Any] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'output': self.output,
            'error': self.error,
            'execution_time': self.execution_time,
            'resource_usage': self.resource_usage or {},
            'sandbox_logs': self.sandbox_logs,
            'metadata': self.metadata or {}
        }


class AgentExecutor:
    """Executes agents in sandboxed environment with LLM-driven decisions"""
    
    def __init__(self, 
                 llm_orchestrator: Optional[LLMOrchestrator] = None,
                 config: Optional[Dict[str, Any]] = None):
        """
        Initialize executor.
        
        Args:
            llm_orchestrator: LLM for execution decisions
            config: Execution configuration
        """
        self.llm = llm_orchestrator
        self.config = config or {}
        
        # Default limits (can be overridden by LLM)
        self.default_limits = {
            'max_memory': 512 * 1024 * 1024,  # 512MB
            'max_cpu_time': 30,  # 30 seconds
            'max_file_size': 10 * 1024 * 1024,  # 10MB
            'max_processes': 10
        }
        
    async def execute(self, 
                     agent_code: str,
                     input_data: Dict[str, Any],
                     test_mode: bool = True) -> ExecutionResult:
        """
        Execute agent code in sandbox.
        
        Args:
            agent_code: Python code to execute
            input_data: Input data for the agent
            test_mode: Whether this is a test execution
            
        Returns:
            Execution result
        """
        logger.info("Starting agent execution")
        
        # 1. Let LLM analyze execution requirements
        execution_plan = await self._analyze_execution_requirements(
            agent_code, input_data, test_mode
        )
        
        # 2. Prepare sandbox environment
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # 3. Set up files
                agent_path, runner_path = await self._setup_execution_files(
                    temp_dir, agent_code, input_data, execution_plan
                )
                
                # 4. Execute in sandbox
                result = await self._execute_in_sandbox(
                    runner_path, execution_plan, temp_dir
                )
                
                # 5. Process results
                final_result = await self._process_execution_result(
                    result, temp_dir, execution_plan
                )
                
                return final_result
                
            except Exception as e:
                logger.error(f"Execution failed: {e}")
                return ExecutionResult(
                    success=False,
                    output=None,
                    error=str(e),
                    metadata={'traceback': traceback.format_exc()}
                )
                
    async def _analyze_execution_requirements(self, 
                                            agent_code: str,
                                            input_data: Dict[str, Any],
                                            test_mode: bool) -> Dict[str, Any]:
        """Let LLM analyze and determine execution requirements"""
        
        analysis_prompt = f"""Analyze this agent code and determine execution requirements:

Code summary (first 1000 chars):
{agent_code[:1000]}...

Input data:
{json.dumps(input_data, indent=2)[:500]}

Test mode: {test_mode}

Determine:
1. Resource requirements (memory, CPU time)
2. Security restrictions needed
3. Required Python packages
4. Potential risks
5. Execution strategy

Provide requirements as JSON:"""
        
        response = await self.llm.generate(
            analysis_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Parse response
        try:
            requirements = json.loads(response)
        except:
            # Let LLM fix JSON
            fix_prompt = f"""Convert this to valid JSON:
{response}

Valid JSON:"""
            
            fixed = await self.llm.generate(
                fix_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.1
            )
            
            try:
                requirements = json.loads(fixed)
            except:
                # Use defaults
                requirements = {
                    'memory_limit': self.default_limits['max_memory'],
                    'cpu_limit': self.default_limits['max_cpu_time'],
                    'security_level': 'high',
                    'packages': [],
                    'risks': []
                }
                
        return requirements
        
    async def _setup_execution_files(self, 
                                   temp_dir: str,
                                   agent_code: str,
                                   input_data: Dict[str, Any],
                                   execution_plan: Dict[str, Any]) -> Tuple[Path, Path]:
        """Set up files for execution based on LLM plan"""
        
        # Save agent code
        agent_path = Path(temp_dir) / "agent.py"
        with open(agent_path, 'w') as f:
            f.write(agent_code)
            
        # Save input data
        input_path = Path(temp_dir) / "input.json"
        with open(input_path, 'w') as f:
            json.dump(input_data, f)
            
        # Let LLM generate runner script
        runner_code = await self._generate_runner_script(
            agent_code, execution_plan
        )
        
        runner_path = Path(temp_dir) / "runner.py"
        with open(runner_path, 'w') as f:
            f.write(runner_code)
            
        return agent_path, runner_path
        
    async def _generate_runner_script(self, 
                                    agent_code: str,
                                    execution_plan: Dict[str, Any]) -> str:
        """Let LLM generate appropriate runner script"""
        
        runner_prompt = f"""Generate a Python runner script for this agent:

Agent class structure (first 500 chars):
{agent_code[:500]}...

Execution requirements:
{json.dumps(execution_plan, indent=2)}

The runner should:
1. Import the agent from agent.py
2. Load input from input.json
3. Initialize the agent
4. Run setup()
5. Run process() with input data
6. Save output to output.json
7. Handle errors gracefully
8. Apply resource limits
9. Log execution details

Generate complete runner script:"""
        
        runner_code = await self.llm.generate(
            runner_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.3
        )
        
        # Validate runner has necessary components
        if 'import' not in runner_code or 'agent' not in runner_code.lower():
            # Use fallback runner
            runner_code = self._get_fallback_runner(execution_plan)
            
        return runner_code
        
    def _get_fallback_runner(self, execution_plan: Dict[str, Any]) -> str:
        """Fallback runner script"""
        memory_limit = execution_plan.get('memory_limit', self.default_limits['max_memory'])
        cpu_limit = execution_plan.get('cpu_limit', self.default_limits['max_cpu_time'])
        
        return f"""
import sys
import json
import asyncio
import resource
import time
import traceback

# Set resource limits
resource.setrlimit(resource.RLIMIT_AS, ({memory_limit}, {memory_limit}))
resource.setrlimit(resource.RLIMIT_CPU, ({cpu_limit}, {cpu_limit}))

# Import agent
sys.path.insert(0, '.')
from agent import *

async def run():
    start_time = time.time()
    
    try:
        # Load input
        with open('input.json', 'r') as f:
            input_data = json.load(f)
            
        # Find agent class
        agent_classes = [obj for name, obj in globals().items() 
                        if isinstance(obj, type) and 
                        name != 'LogosAIAgent' and
                        issubclass(obj, LogosAIAgent)]
        
        if not agent_classes:
            raise Exception("No agent class found")
            
        # Initialize agent
        agent = agent_classes[0]()
        
        # Setup
        await agent.setup()
        
        # Process
        result = await agent.process(input_data)
        
        # Save output
        output = {{
            'success': True,
            'result': result,
            'execution_time': time.time() - start_time
        }}
        
    except Exception as e:
        output = {{
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc(),
            'execution_time': time.time() - start_time
        }}
        
    with open('output.json', 'w') as f:
        json.dump(output, f)

# Run
if __name__ == '__main__':
    asyncio.run(run())
"""
        
    async def _execute_in_sandbox(self, 
                                 runner_path: Path,
                                 execution_plan: Dict[str, Any],
                                 work_dir: str) -> Dict[str, Any]:
        """Execute runner in sandboxed subprocess"""
        
        # Let LLM determine sandbox parameters
        sandbox_prompt = f"""Determine sandbox execution parameters:

Execution plan:
{json.dumps(execution_plan, indent=2)}

Decide:
1. Should we use virtual environment? (yes/no)
2. Which Python executable to use?
3. Environment variables needed?
4. Additional security measures?

Format as JSON:"""
        
        sandbox_params = await self.llm.generate(
            sandbox_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.2
        )
        
        # Parse parameters
        try:
            params = json.loads(sandbox_params)
        except:
            params = {
                'use_venv': False,
                'python_executable': sys.executable,
                'env_vars': {},
                'security': []
            }
            
        # Prepare environment
        env = os.environ.copy()
        env.update(params.get('env_vars', {}))
        
        # Disable potentially dangerous modules
        env['PYTHONPATH'] = work_dir
        
        # Execute
        try:
            process = await asyncio.create_subprocess_exec(
                params.get('python_executable', sys.executable),
                str(runner_path),
                cwd=work_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env
            )
            
            # Wait with timeout
            timeout = execution_plan.get('cpu_limit', self.default_limits['max_cpu_time'])
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
                
                return {
                    'returncode': process.returncode,
                    'stdout': stdout.decode('utf-8'),
                    'stderr': stderr.decode('utf-8')
                }
                
            except asyncio.TimeoutError:
                process.kill()
                return {
                    'returncode': -1,
                    'stdout': '',
                    'stderr': f'Execution timeout ({timeout}s)'
                }
                
        except Exception as e:
            return {
                'returncode': -1,
                'stdout': '',
                'stderr': str(e)
            }
            
    async def _process_execution_result(self,
                                       raw_result: Dict[str, Any],
                                       work_dir: str,
                                       execution_plan: Dict[str, Any]) -> ExecutionResult:
        """Process and interpret execution results"""
        
        # Try to load output.json
        output_path = Path(work_dir) / "output.json"
        
        if output_path.exists():
            try:
                with open(output_path, 'r') as f:
                    output_data = json.load(f)
                    
                return ExecutionResult(
                    success=output_data.get('success', False),
                    output=output_data.get('result'),
                    error=output_data.get('error'),
                    execution_time=output_data.get('execution_time', 0),
                    sandbox_logs=f"stdout:\n{raw_result['stdout']}\n\nstderr:\n{raw_result['stderr']}",
                    metadata={
                        'returncode': raw_result['returncode'],
                        'execution_plan': execution_plan
                    }
                )
            except Exception as e:
                logger.error(f"Failed to load output.json: {e}")
                
        # Fallback: Let LLM interpret raw output
        interpret_prompt = f"""Interpret this execution result:

Return code: {raw_result['returncode']}
Stdout:
{raw_result['stdout'][:1000]}

Stderr:
{raw_result['stderr'][:1000]}

Was the execution successful? What was the output?
Format as JSON with keys: success, output, error"""
        
        interpretation = await self.llm.generate(
            interpret_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        try:
            result_data = json.loads(interpretation)
            
            return ExecutionResult(
                success=result_data.get('success', False),
                output=result_data.get('output'),
                error=result_data.get('error', raw_result['stderr']),
                sandbox_logs=f"stdout:\n{raw_result['stdout']}\n\nstderr:\n{raw_result['stderr']}",
                metadata={
                    'returncode': raw_result['returncode'],
                    'interpretation': 'LLM interpreted'
                }
            )
        except:
            # Ultimate fallback
            return ExecutionResult(
                success=raw_result['returncode'] == 0,
                output=raw_result['stdout'],
                error=raw_result['stderr'] if raw_result['returncode'] != 0 else None,
                sandbox_logs=f"stdout:\n{raw_result['stdout']}\n\nstderr:\n{raw_result['stderr']}"
            )
            
    async def validate_execution_safety(self, 
                                      agent_code: str) -> Tuple[bool, List[str]]:
        """Let LLM validate if code is safe to execute"""
        
        safety_prompt = f"""Analyze this code for execution safety:

```python
{agent_code[:2000]}{'...' if len(agent_code) > 2000 else ''}
```

Check for:
1. System calls that could be dangerous
2. File system operations outside sandbox
3. Network operations
4. Resource exhaustion risks
5. Code injection vulnerabilities

Is it safe to execute in sandbox? List any concerns:"""
        
        response = await self.llm.generate(
            safety_prompt,
            task_type=TaskType.VALIDATION,
            temperature=0.2
        )
        
        # Parse response
        is_safe = 'safe' in response.lower() and 'not safe' not in response.lower()
        
        # Extract concerns
        concerns = []
        for line in response.split('\n'):
            if any(word in line.lower() for word in ['risk', 'danger', 'concern', 'vulnerable']):
                concerns.append(line.strip())
                
        return is_safe, concerns