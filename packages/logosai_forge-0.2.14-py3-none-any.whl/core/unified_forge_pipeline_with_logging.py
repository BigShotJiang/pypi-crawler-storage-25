"""
Forge AI Pipeline with Integrated Logging
로깅 및 스트리밍이 통합된 파이프라인
"""

import asyncio
from typing import Optional, Dict, Any
from dataclasses import asdict
import json
import traceback

from .unified_query_analyzer import UnifiedQueryAnalyzer, QueryAnalysisResult
from .unified_pattern_matcher import UnifiedPatternMatcher, PatternMatchResult
from .unified_business_logic_generator import UnifiedBusinessLogicGenerator, BusinessLogicResult
from .unified_template_generator import UnifiedTemplateGenerator, TemplateGenerationResult
from .unified_logging_system import get_logger, LogLevel

class UnifiedForgePipelineWithLogging:
    """로깅이 통합된 Forge AI 파이프라인"""
    
    def __init__(self):
        # 모듈 초기화
        self.query_analyzer = UnifiedQueryAnalyzer()
        self.pattern_matcher = UnifiedPatternMatcher()
        self.business_logic_generator = UnifiedBusinessLogicGenerator()
        self.template_generator = UnifiedTemplateGenerator()
        
        # 로거 초기화
        self.logger = get_logger("forge_pipeline")
        self.module_loggers = {
            "query_analyzer": get_logger("query_analyzer"),
            "pattern_matcher": get_logger("pattern_matcher"),
            "business_logic": get_logger("business_logic"),
            "template_generator": get_logger("template_generator")
        }
        
    async def generate_agent(self, 
                           query: str, 
                           user_email: Optional[str] = None,
                           stream_callback: Optional[callable] = None) -> Dict[str, Any]:
        """
        에이전트 생성 파이프라인 실행
        
        Args:
            query: 사용자 쿼리
            user_email: 사용자 이메일
            stream_callback: 실시간 스트리밍을 위한 콜백 함수
        """
        
        # 스트리밍 콜백 등록
        if stream_callback:
            for logger in self.module_loggers.values():
                logger.subscribe(stream_callback)
            self.logger.subscribe(stream_callback)
        
        try:
            # 파이프라인 시작
            self.logger.start_phase("pipeline_execution")
            self.logger.log(
                LogLevel.INFO,
                module="pipeline",
                phase="initialization",
                message=f"Starting agent generation for query: {query[:100]}...",
                metadata={"user_email": user_email}
            )
            
            # Step 1: 쿼리 분석
            self.logger.progress("pipeline_execution", 1, 5, "Analyzing query...")
            query_result = await self._analyze_query(query, user_email)
            
            # Step 2: 패턴 매칭
            self.logger.progress("pipeline_execution", 2, 5, "Matching patterns...")
            pattern_result = await self._match_patterns(query_result)
            
            # Step 3: 비즈니스 로직 생성
            self.logger.progress("pipeline_execution", 3, 5, "Generating business logic...")
            business_logic_result = await self._generate_business_logic(query_result, pattern_result)
            
            # Step 4: 템플릿 생성
            self.logger.progress("pipeline_execution", 4, 5, "Generating agent code...")
            template_result = await self._generate_template(
                query_result, 
                pattern_result, 
                business_logic_result
            )
            
            # Step 5: 최종 검증
            self.logger.progress("pipeline_execution", 5, 5, "Validating generated code...")
            validation_result = await self._validate_code(template_result.agent_code)
            
            # 파이프라인 완료
            self.logger.end_phase("pipeline_execution", success=True)
            
            # 메트릭 수집
            metrics = self._collect_metrics()
            
            result = {
                "success": validation_result["is_valid"],
                "agent_code": template_result.agent_code,
                "agent_metadata": {
                    "class_name": business_logic_result.agent_class_name,
                    "name": business_logic_result.agent_name,
                    "description": business_logic_result.agent_description,
                    "intent": query_result.intent,
                    "domain": query_result.domain,
                    "patterns": pattern_result.patterns,
                    "template_used": pattern_result.template_type
                },
                "validation": validation_result,
                "metrics": metrics
            }
            
            self.logger.log(
                LogLevel.INFO,
                module="pipeline",
                phase="completion",
                message="Agent generation completed successfully",
                metadata=result["agent_metadata"],
                progress=100
            )
            
            return result
            
        except Exception as e:
            # 에러 처리
            self.logger.log(
                LogLevel.ERROR,
                module="pipeline",
                phase="error",
                message=f"Pipeline failed: {str(e)}",
                metadata={"error_type": type(e).__name__, "traceback": traceback.format_exc()}
            )
            
            self.logger.end_phase("pipeline_execution", success=False)
            
            return {
                "success": False,
                "error": str(e),
                "traceback": traceback.format_exc(),
                "metrics": self._collect_metrics()
            }
        finally:
            # 스트리밍 콜백 해제
            if stream_callback:
                for logger in self.module_loggers.values():
                    logger.unsubscribe(stream_callback)
                self.logger.unsubscribe(stream_callback)
    
    async def _analyze_query(self, query: str, user_email: Optional[str]) -> QueryAnalysisResult:
        """쿼리 분석 with 로깅"""
        logger = self.module_loggers["query_analyzer"]
        logger.start_phase("query_analysis")
        
        try:
            logger.log(
                LogLevel.INFO,
                module="query_analyzer",
                phase="analysis",
                message="Starting query analysis",
                metadata={"query_length": len(query)}
            )
            
            result = await self.query_analyzer.analyze(query, user_email)
            
            logger.log(
                LogLevel.INFO,
                module="query_analyzer",
                phase="analysis",
                message="Query analysis completed",
                metadata={
                    "intent": result.intent,
                    "domain": result.domain,
                    "metadata_keys": list(result.agent_metadata.keys())
                }
            )
            
            logger.end_phase("query_analysis", success=True)
            return result
            
        except Exception as e:
            logger.log(
                LogLevel.ERROR,
                module="query_analyzer",
                phase="analysis",
                message=f"Query analysis failed: {str(e)}"
            )
            logger.end_phase("query_analysis", success=False)
            raise
    
    async def _match_patterns(self, query_result: QueryAnalysisResult) -> PatternMatchResult:
        """패턴 매칭 with 로깅"""
        logger = self.module_loggers["pattern_matcher"]
        logger.start_phase("pattern_matching")
        
        try:
            logger.log(
                LogLevel.INFO,
                module="pattern_matcher",
                phase="matching",
                message="Starting pattern matching",
                metadata={"intent": query_result.intent}
            )
            
            result = await self.pattern_matcher.match_for_pipeline(query_result)
            
            logger.log(
                LogLevel.INFO,
                module="pattern_matcher",
                phase="matching",
                message="Pattern matching completed",
                metadata={
                    "patterns_found": result.patterns,
                    "template_type": result.template_type,
                    "confidence": result.confidence
                }
            )
            
            logger.end_phase("pattern_matching", success=True)
            return result
            
        except Exception as e:
            logger.log(
                LogLevel.ERROR,
                module="pattern_matcher",
                phase="matching",
                message=f"Pattern matching failed: {str(e)}"
            )
            logger.end_phase("pattern_matching", success=False)
            raise
    
    async def _generate_business_logic(self, 
                                      query_result: QueryAnalysisResult,
                                      pattern_result: PatternMatchResult) -> BusinessLogicResult:
        """비즈니스 로직 생성 with 로깅"""
        logger = self.module_loggers["business_logic"]
        logger.start_phase("business_logic_generation")
        
        try:
            logger.log(
                LogLevel.INFO,
                module="business_logic",
                phase="generation",
                message="Starting business logic generation",
                metadata={
                    "patterns": pattern_result.patterns,
                    "template_type": pattern_result.template_type
                }
            )
            
            # 진행 상황 업데이트 (예: LLM 호출 시)
            logger.progress("business_logic_generation", 1, 3, "Calling LLM for logic generation...")
            
            result = await self.business_logic_generator.generate(
                query_result, 
                pattern_result
            )
            
            logger.progress("business_logic_generation", 2, 3, "Processing LLM response...")
            
            # 완전성 확인
            result.ensure_completeness()
            
            logger.progress("business_logic_generation", 3, 3, "Business logic completed")
            
            logger.log(
                LogLevel.INFO,
                module="business_logic",
                phase="generation",
                message="Business logic generation completed",
                metadata={
                    "class_name": result.agent_class_name,
                    "agent_name": result.agent_name,
                    "logic_length": len(result.core_business_logic)
                }
            )
            
            logger.end_phase("business_logic_generation", success=True)
            return result
            
        except Exception as e:
            logger.log(
                LogLevel.ERROR,
                module="business_logic",
                phase="generation",
                message=f"Business logic generation failed: {str(e)}"
            )
            logger.end_phase("business_logic_generation", success=False)
            raise
    
    async def _generate_template(self,
                                query_result: QueryAnalysisResult,
                                pattern_result: PatternMatchResult,
                                business_logic_result: BusinessLogicResult) -> TemplateGenerationResult:
        """템플릿 생성 with 로깅"""
        logger = self.module_loggers["template_generator"]
        logger.start_phase("template_generation")
        
        try:
            logger.log(
                LogLevel.INFO,
                module="template_generator",
                phase="generation",
                message="Starting template generation",
                metadata={
                    "template_type": pattern_result.template_type,
                    "class_name": business_logic_result.agent_class_name
                }
            )
            
            result = await self.template_generator.generate_for_pipeline(
                query_result,
                pattern_result,
                business_logic_result
            )
            
            # 변수 치환 검증
            unresolved = result.get_unresolved_variables()
            if unresolved:
                logger.log(
                    LogLevel.WARNING,
                    module="template_generator",
                    phase="generation",
                    message=f"Unresolved template variables found",
                    metadata={"unresolved": unresolved}
                )
            
            logger.log(
                LogLevel.INFO,
                module="template_generator",
                phase="generation",
                message="Template generation completed",
                metadata={
                    "code_length": len(result.agent_code),
                    "variables_substituted": len(result.template_variables)
                }
            )
            
            logger.end_phase("template_generation", success=True)
            return result
            
        except Exception as e:
            logger.log(
                LogLevel.ERROR,
                module="template_generator",
                phase="generation",
                message=f"Template generation failed: {str(e)}"
            )
            logger.end_phase("template_generation", success=False)
            raise
    
    async def _validate_code(self, code: str) -> Dict[str, Any]:
        """코드 검증 with 로깅"""
        self.logger.start_phase("code_validation")
        
        try:
            self.logger.log(
                LogLevel.INFO,
                module="pipeline",
                phase="validation",
                message="Starting code validation",
                metadata={"code_length": len(code)}
            )
            
            # 기본 Python 문법 검증
            compile(code, '<string>', 'exec')
            
            # 추가 검증 로직
            validation_checks = {
                "has_class": "class " in code,
                "has_process_method": "async def process" in code,
                "has_imports": "import" in code,
                "syntax_valid": True
            }
            
            is_valid = all(validation_checks.values())
            
            self.logger.log(
                LogLevel.INFO if is_valid else LogLevel.WARNING,
                module="pipeline",
                phase="validation",
                message=f"Code validation {'passed' if is_valid else 'failed'}",
                metadata=validation_checks
            )
            
            self.logger.end_phase("code_validation", success=is_valid)
            
            return {
                "is_valid": is_valid,
                "checks": validation_checks
            }
            
        except SyntaxError as e:
            self.logger.log(
                LogLevel.ERROR,
                module="pipeline",
                phase="validation",
                message=f"Code syntax error: {str(e)}",
                metadata={"line": e.lineno, "offset": e.offset}
            )
            self.logger.end_phase("code_validation", success=False)
            
            return {
                "is_valid": False,
                "error": str(e),
                "type": "syntax_error"
            }
        except Exception as e:
            self.logger.log(
                LogLevel.ERROR,
                module="pipeline",
                phase="validation",
                message=f"Code validation error: {str(e)}"
            )
            self.logger.end_phase("code_validation", success=False)
            
            return {
                "is_valid": False,
                "error": str(e),
                "type": "validation_error"
            }
    
    def _collect_metrics(self) -> Dict[str, Any]:
        """전체 메트릭 수집"""
        all_metrics = {
            "pipeline": self.logger.get_metrics()
        }
        
        for name, logger in self.module_loggers.items():
            all_metrics[name] = logger.get_metrics()
        
        # 전체 통계
        total_errors = sum(m.get("errors", 0) for m in all_metrics.values())
        total_warnings = sum(m.get("warnings", 0) for m in all_metrics.values())
        
        all_metrics["summary"] = {
            "total_errors": total_errors,
            "total_warnings": total_warnings,
            "success": total_errors == 0
        }
        
        return all_metrics