"""
Agentic Engine - 하이브리드 Agentic AI 핵심 엔진
LLM 기반 의사결정 + 효율적 실행의 조합
"""

import asyncio
import json
from typing import Dict, Any, Optional, List, Tuple, Union
from datetime import datetime
from enum import Enum
from dataclasses import dataclass, asdict
import pandas as pd
import numpy as np

from loguru import logger


class DecisionType(Enum):
    """의사결정 유형"""
    STRATEGIC = "strategic"      # 전략적 계획 수립
    ANALYTICAL = "analytical"    # 분석 방법 선택
    CONTEXTUAL = "contextual"    # 컨텍스트 해석
    CREATIVE = "creative"        # 창의적 인사이트
    ADAPTIVE = "adaptive"        # 적응적 대응


class ExecutionMode(Enum):
    """실행 모드"""
    FAST = "fast"           # 빠른 규칙 기반 실행
    SMART = "smart"         # LLM 기반 스마트 실행
    HYBRID = "hybrid"       # 하이브리드 실행


@dataclass
class AgenticPlan:
    """Agentic AI 실행 계획"""
    strategy: str
    steps: List[Dict[str, Any]]
    llm_decisions: List[str]
    fast_operations: List[str]
    expected_duration: float
    confidence: float
    reasoning: str


@dataclass 
class AgenticContext:
    """Agentic AI 컨텍스트"""
    user_intent: str
    data_profile: Dict[str, Any]
    business_domain: str
    urgency_level: str
    quality_requirement: str
    previous_results: Optional[List[Dict]] = None


class AgenticEngine:
    """
    하이브리드 Agentic AI 엔진
    
    핵심 원칙:
    1. LLM Zone: 창의적 사고, 전략적 계획, 컨텍스트 이해
    2. Fast Zone: 계산, 데이터 처리, 규칙 기반 작업
    3. Smart Integration: 두 영역의 최적 조합
    """
    
    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        self.execution_history: List[Dict] = []
        self.context_memory: Dict[str, Any] = {}
        
    async def initialize_llm(self, model: str = "gpt-4o-mini", **kwargs):
        """LLM 클라이언트 초기화"""
        try:
            # LLM 클라이언트 동적 임포트 및 초기화
            from ..llm_client import LLMClient
            
            self.llm_client = LLMClient(
                model=model,
                temperature=kwargs.get('temperature', 0.3),
                max_tokens=kwargs.get('max_tokens', 2000),
                **kwargs
            )
            
            # 연결 테스트
            test_response = await self.llm_client.invoke("Hello, are you ready for agentic AI?")
            logger.info(f"🤖 LLM 초기화 완료: {model}")
            return True
            
        except Exception as e:
            logger.warning(f"⚠️ LLM 초기화 실패: {e}")
            logger.info("🔄 Mock LLM 모드로 전환")
            self.llm_client = MockLLMClient()
            return False
    
    # ==================== LLM Zone: 창의적 사고 영역 ====================
    
    async def strategic_planning(self, context: AgenticContext) -> AgenticPlan:
        """🧠 전략적 계획 수립 (LLM 기반)"""
        if not self.llm_client:
            raise ValueError("LLM 클라이언트가 초기화되지 않았습니다")
        
        prompt = f"""당신은 데이터 분석 전략가입니다. 다음 상황을 분석하고 최적의 전략을 수립해주세요:

사용자 의도: {context.user_intent}
데이터 프로필: {json.dumps(context.data_profile, ensure_ascii=False, indent=2)}
비즈니스 도메인: {context.business_domain}
긴급도: {context.urgency_level}
품질 요구사항: {context.quality_requirement}

다음 형식으로 전략을 제안해주세요:
{{
    "strategy": "전략 요약 (1-2문장)",
    "steps": [
        {{"action": "구체적 행동", "type": "fast|smart", "priority": 1-5, "estimated_time": 초}},
        ...
    ],
    "llm_decisions": ["LLM이 담당할 의사결정 목록"],
    "fast_operations": ["빠른 계산으로 처리할 작업 목록"],
    "reasoning": "이 전략을 선택한 이유"
}}"""

        try:
            response = await self.llm_client.invoke(prompt)
            plan_data = self._parse_json_response(response)
            
            plan = AgenticPlan(
                strategy=plan_data.get("strategy", "기본 분석 전략"),
                steps=plan_data.get("steps", []),
                llm_decisions=plan_data.get("llm_decisions", []),
                fast_operations=plan_data.get("fast_operations", []),
                expected_duration=sum(step.get("estimated_time", 1) for step in plan_data.get("steps", [])),
                confidence=0.85,
                reasoning=plan_data.get("reasoning", "LLM 기반 전략 수립")
            )
            
            logger.info(f"🎯 전략 수립 완료: {plan.strategy}")
            return plan
            
        except Exception as e:
            logger.error(f"전략 수립 실패: {e}")
            return self._fallback_plan(context)
    
    async def contextual_understanding(self, data: Any, user_query: str) -> Dict[str, Any]:
        """🔍 컨텍스트 이해 및 해석 (LLM 기반)"""
        if not self.llm_client:
            return {"understanding": "기본 컨텍스트", "insights": []}
        
        # 데이터 샘플 생성
        data_sample = self._create_data_sample(data)
        
        prompt = f"""다음 데이터와 사용자 요청을 분석하여 비즈니스 컨텍스트를 이해해주세요:

데이터 샘플:
{data_sample}

사용자 요청: "{user_query}"

다음을 JSON 형식으로 분석해주세요:
{{
    "business_domain": "추정되는 비즈니스 도메인",
    "data_nature": "데이터의 성격과 특징",
    "user_goals": ["사용자의 목표 목록"],
    "key_concerns": ["주요 관심사항"],
    "success_metrics": ["성공 지표"],
    "context_insights": ["컨텍스트 인사이트"]
}}"""

        try:
            response = await self.llm_client.invoke(prompt)
            understanding = self._parse_json_response(response)
            
            logger.info(f"🔍 컨텍스트 이해 완료: {understanding.get('business_domain', 'Unknown')}")
            return understanding
            
        except Exception as e:
            logger.error(f"컨텍스트 이해 실패: {e}")
            return {
                "business_domain": "일반",
                "data_nature": "구조화된 데이터",
                "user_goals": ["데이터 분석"],
                "context_insights": ["기본 분석 수행"]
            }
    
    async def creative_insight_generation(self, analysis_results: Dict[str, Any], 
                                        context: AgenticContext) -> Dict[str, Any]:
        """💡 창의적 인사이트 생성 (LLM 기반)"""
        if not self.llm_client:
            return {"insights": ["기본 분석이 완료되었습니다."], "recommendations": []}
        
        prompt = f"""당신은 비즈니스 인사이트 전문가입니다. 다음 분석 결과를 바탕으로 창의적이고 실용적인 인사이트를 생성해주세요:

분석 결과:
{json.dumps(analysis_results, ensure_ascii=False, indent=2)}

비즈니스 컨텍스트:
- 도메인: {context.business_domain}
- 사용자 의도: {context.user_intent}

다음 형식으로 인사이트를 제공해주세요:
{{
    "key_findings": ["핵심 발견사항"],
    "business_insights": ["비즈니스 인사이트"],
    "hidden_patterns": ["숨겨진 패턴이나 특이사항"],
    "opportunities": ["비즈니스 기회"],
    "risks": ["잠재적 위험요소"],
    "action_recommendations": ["구체적 액션 아이템"],
    "next_steps": ["다음 단계 제안"]
}}"""

        try:
            response = await self.llm_client.invoke(prompt)
            insights = self._parse_json_response(response)
            
            logger.info(f"💡 인사이트 생성 완료: {len(insights.get('business_insights', []))}개 인사이트")
            return insights
            
        except Exception as e:
            logger.error(f"인사이트 생성 실패: {e}")
            return {
                "key_findings": ["분석이 완료되었습니다"],
                "business_insights": ["데이터에서 패턴을 발견했습니다"],
                "action_recommendations": ["추가 분석을 고려해보세요"]
            }
    
    # ==================== Fast Zone: 효율적 실행 영역 ====================
    
    def fast_data_profiling(self, data: Union[pd.DataFrame, Dict, List]) -> Dict[str, Any]:
        """⚡ 빠른 데이터 프로파일링"""
        try:
            if isinstance(data, pd.DataFrame):
                df = data
            elif isinstance(data, dict):
                df = pd.DataFrame(data)
            elif isinstance(data, list):
                df = pd.DataFrame(data)
            else:
                return {"error": "지원하지 않는 데이터 형식"}
            
            profile = {
                "shape": {"rows": len(df), "columns": len(df.columns)},
                "columns": list(df.columns),
                "dtypes": df.dtypes.astype(str).to_dict(),
                "missing_values": df.isnull().sum().to_dict(),
                "memory_usage": f"{df.memory_usage(deep=True).sum() / 1024:.1f} KB",
                "numeric_columns": df.select_dtypes(include=[np.number]).columns.tolist(),
                "categorical_columns": df.select_dtypes(include=['object']).columns.tolist(),
                "datetime_columns": df.select_dtypes(include=['datetime']).columns.tolist()
            }
            
            # 데이터 품질 점수 계산
            missing_ratio = df.isnull().sum().sum() / (len(df) * len(df.columns))
            duplicate_ratio = df.duplicated().sum() / len(df)
            profile["quality_score"] = max(0, 100 - (missing_ratio * 50) - (duplicate_ratio * 30))
            
            return profile
            
        except Exception as e:
            logger.error(f"데이터 프로파일링 실패: {e}")
            return {"error": str(e)}
    
    def fast_statistical_analysis(self, df: pd.DataFrame) -> Dict[str, Any]:
        """⚡ 빠른 통계 분석"""
        try:
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            
            if len(numeric_cols) == 0:
                return {"message": "분석할 숫자형 컬럼이 없습니다"}
            
            stats = {}
            for col in numeric_cols:
                col_data = df[col].dropna()
                if len(col_data) > 0:
                    stats[col] = {
                        "count": int(len(col_data)),
                        "mean": float(col_data.mean()),
                        "median": float(col_data.median()),
                        "std": float(col_data.std()),
                        "min": float(col_data.min()),
                        "max": float(col_data.max()),
                        "q25": float(col_data.quantile(0.25)),
                        "q75": float(col_data.quantile(0.75)),
                        "range": float(col_data.max() - col_data.min()),
                        "cv": float(col_data.std() / col_data.mean()) if col_data.mean() != 0 else 0
                    }
            
            return {"statistics": stats, "summary": f"{len(stats)}개 숫자형 컬럼 분석 완료"}
            
        except Exception as e:
            logger.error(f"통계 분석 실패: {e}")
            return {"error": str(e)}
    
    def fast_pattern_detection(self, df: pd.DataFrame) -> Dict[str, Any]:
        """⚡ 빠른 패턴 탐지"""
        try:
            patterns = {
                "data_patterns": [],
                "anomalies": [],
                "trends": []
            }
            
            # 기본 패턴 탐지
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            
            for col in numeric_cols:
                col_data = df[col].dropna()
                if len(col_data) < 2:
                    continue
                
                # 변동성 분석
                cv = col_data.std() / col_data.mean() if col_data.mean() != 0 else 0
                if cv > 1.0:
                    patterns["data_patterns"].append(f"{col}: 높은 변동성 ({cv:.2f})")
                elif cv < 0.1:
                    patterns["data_patterns"].append(f"{col}: 안정적 패턴 ({cv:.2f})")
                
                # 이상치 탐지 (IQR 방법)
                Q1 = col_data.quantile(0.25)
                Q3 = col_data.quantile(0.75)
                IQR = Q3 - Q1
                outliers = col_data[(col_data < Q1 - 1.5*IQR) | (col_data > Q3 + 1.5*IQR)]
                
                if len(outliers) > 0:
                    patterns["anomalies"].append({
                        "column": col,
                        "outlier_count": len(outliers),
                        "outlier_ratio": len(outliers) / len(col_data)
                    })
            
            return patterns
            
        except Exception as e:
            logger.error(f"패턴 탐지 실패: {e}")
            return {"error": str(e)}
    
    # ==================== Hybrid Integration ====================
    
    async def execute_agentic_workflow(self, data: Any, user_query: str, 
                                     context_hints: Optional[Dict] = None) -> Dict[str, Any]:
        """🤖⚡ 하이브리드 Agentic 워크플로우 실행"""
        start_time = datetime.now()
        
        try:
            # Phase 1: 빠른 데이터 프로파일링 (Fast Zone)
            logger.info("⚡ Phase 1: 빠른 데이터 분석...")
            data_profile = self.fast_data_profiling(data)
            
            # Phase 2: LLM 기반 컨텍스트 이해 (LLM Zone)
            logger.info("🧠 Phase 2: 컨텍스트 이해...")
            context_understanding = await self.contextual_understanding(data, user_query)
            
            # Phase 3: 전략적 계획 수립 (LLM Zone)
            logger.info("🎯 Phase 3: 전략 수립...")
            agentic_context = AgenticContext(
                user_intent=user_query,
                data_profile=data_profile,
                business_domain=context_understanding.get("business_domain", "일반"),
                urgency_level=context_hints.get("urgency", "normal") if context_hints else "normal",
                quality_requirement=context_hints.get("quality", "standard") if context_hints else "standard"
            )
            
            execution_plan = await self.strategic_planning(agentic_context)
            
            # Phase 4: 하이브리드 실행
            logger.info("🔄 Phase 4: 하이브리드 실행...")
            analysis_results = await self._execute_hybrid_analysis(data, execution_plan)
            
            # Phase 5: 창의적 인사이트 생성 (LLM Zone)
            logger.info("💡 Phase 5: 인사이트 생성...")
            insights = await self.creative_insight_generation(analysis_results, agentic_context)
            
            # 실행 시간 계산
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # 결과 조합
            final_result = {
                "execution_info": {
                    "strategy": execution_plan.strategy,
                    "execution_time": execution_time,
                    "plan_confidence": execution_plan.confidence,
                    "phases_completed": 5
                },
                "data_analysis": analysis_results,
                "business_insights": insights,
                "context": {
                    "business_domain": context_understanding.get("business_domain"),
                    "user_goals": context_understanding.get("user_goals", []),
                    "data_nature": context_understanding.get("data_nature")
                },
                "metadata": {
                    "timestamp": datetime.now().isoformat(),
                    "agentic_engine_version": "1.0.0",
                    "llm_decisions": len(execution_plan.llm_decisions),
                    "fast_operations": len(execution_plan.fast_operations)
                }
            }
            
            logger.success(f"✅ Agentic 워크플로우 완료 ({execution_time:.2f}초)")
            return final_result
            
        except Exception as e:
            logger.error(f"Agentic 워크플로우 실패: {e}")
            return {
                "error": str(e),
                "fallback_analysis": self._emergency_fallback_analysis(data),
                "execution_time": (datetime.now() - start_time).total_seconds()
            }
    
    async def _execute_hybrid_analysis(self, data: Any, plan: AgenticPlan) -> Dict[str, Any]:
        """하이브리드 분석 실행"""
        results = {}
        
        if isinstance(data, (dict, list)):
            df = pd.DataFrame(data)
        else:
            df = data
        
        # Fast Zone 작업들
        if "statistical_analysis" in plan.fast_operations:
            results["statistics"] = self.fast_statistical_analysis(df)
        
        if "pattern_detection" in plan.fast_operations:
            results["patterns"] = self.fast_pattern_detection(df)
        
        # 기본 분석 항상 수행
        results["basic_analysis"] = {
            "row_count": len(df),
            "column_count": len(df.columns),
            "data_quality": "good" if len(df) > 0 else "empty"
        }
        
        return results
    
    # ==================== 유틸리티 메서드 ====================
    
    def _parse_json_response(self, response: str) -> Dict[str, Any]:
        """JSON 응답 파싱"""
        try:
            # JSON 블록 추출
            if "```json" in response:
                json_start = response.find("```json") + 7
                json_end = response.find("```", json_start)
                json_str = response[json_start:json_end].strip()
            elif "{" in response and "}" in response:
                json_start = response.find("{")
                json_end = response.rfind("}") + 1
                json_str = response[json_start:json_end]
            else:
                return {"error": "JSON 형식을 찾을 수 없음"}
            
            return json.loads(json_str)
        except Exception as e:
            logger.warning(f"JSON 파싱 실패: {e}")
            return {"error": f"JSON 파싱 오류: {str(e)}"}
    
    def _create_data_sample(self, data: Any) -> str:
        """데이터 샘플 생성"""
        try:
            if isinstance(data, pd.DataFrame):
                sample = data.head(3).to_dict('records')
                return json.dumps(sample, ensure_ascii=False, indent=2)
            elif isinstance(data, (dict, list)):
                sample = data[:3] if isinstance(data, list) else data
                return json.dumps(sample, ensure_ascii=False, indent=2)
            else:
                return str(data)[:200]
        except:
            return "데이터 샘플을 생성할 수 없습니다"
    
    def _fallback_plan(self, context: AgenticContext) -> AgenticPlan:
        """폴백 계획"""
        return AgenticPlan(
            strategy="기본 데이터 분석 전략",
            steps=[
                {"action": "데이터 프로파일링", "type": "fast", "priority": 1, "estimated_time": 1},
                {"action": "기본 통계 분석", "type": "fast", "priority": 2, "estimated_time": 2},
                {"action": "패턴 탐지", "type": "fast", "priority": 3, "estimated_time": 1}
            ],
            llm_decisions=["컨텍스트 이해"],
            fast_operations=["통계 분석", "패턴 탐지"],
            expected_duration=4.0,
            confidence=0.7,
            reasoning="LLM 오류로 인한 폴백 전략"
        )
    
    def _emergency_fallback_analysis(self, data: Any) -> Dict[str, Any]:
        """긴급 폴백 분석"""
        try:
            profile = self.fast_data_profiling(data)
            return {
                "basic_profile": profile,
                "message": "긴급 모드: 기본 분석만 수행됨"
            }
        except:
            return {"message": "데이터 분석 불가"}


class MockLLMClient:
    """Mock LLM 클라이언트 (테스트용)"""
    
    async def invoke(self, prompt: str) -> str:
        """Mock 응답 생성"""
        if "전략" in prompt or "strategy" in prompt:
            return '''```json
{
    "strategy": "데이터 패턴 분석 및 비즈니스 인사이트 도출 전략",
    "steps": [
        {"action": "데이터 품질 검증", "type": "fast", "priority": 1, "estimated_time": 1},
        {"action": "통계적 패턴 분석", "type": "fast", "priority": 2, "estimated_time": 2},
        {"action": "비즈니스 컨텍스트 해석", "type": "smart", "priority": 3, "estimated_time": 3}
    ],
    "llm_decisions": ["비즈니스 컨텍스트 해석", "전략적 권장사항 도출"],
    "fast_operations": ["통계 계산", "데이터 정제", "패턴 탐지"],
    "reasoning": "데이터 특성과 사용자 의도를 고려한 효율적 분석 전략"
}```'''
        
        elif "컨텍스트" in prompt or "context" in prompt:
            return '''```json
{
    "business_domain": "데이터 분석",
    "data_nature": "구조화된 표 형태 데이터",
    "user_goals": ["데이터 패턴 이해", "비즈니스 인사이트 발견"],
    "key_concerns": ["데이터 품질", "분석 정확성"],
    "success_metrics": ["인사이트 품질", "실행 속도"],
    "context_insights": ["사용자는 실용적인 분석 결과를 원함"]
}```'''
        
        elif "인사이트" in prompt or "insight" in prompt:
            return '''```json
{
    "key_findings": ["데이터가 정상적으로 구조화되어 있음", "기본 통계 패턴이 발견됨"],
    "business_insights": ["데이터 품질이 분석에 적합함", "추가 세부 분석 가능"],
    "hidden_patterns": ["특별한 이상 패턴은 발견되지 않음"],
    "opportunities": ["심화 분석을 통한 추가 인사이트 발굴 가능"],
    "risks": ["데이터 양이 제한적일 수 있음"],
    "action_recommendations": ["더 많은 데이터 수집 고려", "세분화된 분석 수행"],
    "next_steps": ["특정 비즈니스 질문에 맞춤형 분석 수행"]
}```'''
        
        else:
            return "Mock LLM 응답: 요청을 이해했습니다."