"""
Environment Validator for FORGE System

Validates environment variables and API keys at startup to prevent runtime errors.
"""

import os
from typing import Dict, List, Tuple, Optional
from pathlib import Path
from core.logging_config import logger


class EnvironmentValidator:
    """Validates required environment variables and configurations"""
    
    REQUIRED_VARS = {
        'GOOGLE_API_KEY': 'Google Gemini API key for LLM operations',
        'OPENAI_API_KEY': 'OpenAI API key (optional but recommended)',
    }
    
    OPTIONAL_VARS = {
        'ANTHROPIC_API_KEY': 'Anthropic Claude API key',
        'HUGGINGFACE_API_KEY': 'Hugging Face API key',
        'LOGOSAI_LOG_LEVEL': 'Logging level (DEBUG, INFO, WARNING, ERROR)',
        'FORGE_TEMPLATE_DIR': 'Custom template directory path',
        'FORGE_CACHE_DIR': 'Cache directory for LLM responses',
    }
    
    @classmethod
    def validate(cls) -> Tuple[bool, List[str]]:
        """
        Validate environment variables
        
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        warnings = []
        
        # Check required variables
        for var, description in cls.REQUIRED_VARS.items():
            value = os.getenv(var)
            if not value:
                errors.append(f"Missing required environment variable: {var} ({description})")
            elif var.endswith('_KEY') and len(value) < 10:
                errors.append(f"Invalid {var}: API key seems too short")
        
        # Check optional variables
        for var, description in cls.OPTIONAL_VARS.items():
            value = os.getenv(var)
            if not value:
                logger.debug(f"Optional variable {var} not set ({description})")
        
        # Validate Google API key format
        google_key = os.getenv('GOOGLE_API_KEY')
        if google_key and not cls._validate_google_api_key(google_key):
            errors.append("GOOGLE_API_KEY format appears invalid")
        
        # Log results
        if errors:
            for error in errors:
                logger.error(error)
        else:
            logger.info("✅ Environment validation passed")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def _validate_google_api_key(key: str) -> bool:
        """Basic validation of Google API key format"""
        # Google API keys typically start with 'AIza' and are 39 characters
        return len(key) >= 30 and key.isalnum()
    
    @classmethod
    def get_config(cls) -> Dict[str, Optional[str]]:
        """Get all configuration values"""
        config = {}
        
        # Get all environment variables
        all_vars = {**cls.REQUIRED_VARS, **cls.OPTIONAL_VARS}
        
        for var in all_vars:
            config[var] = os.getenv(var)
        
        return config
    
    @classmethod
    def setup_defaults(cls):
        """Set up default values for optional variables"""
        defaults = {
            'LOGOSAI_LOG_LEVEL': 'INFO',
            'FORGE_TEMPLATE_DIR': str(Path(__file__).parent.parent / 'templates'),
            'FORGE_CACHE_DIR': str(Path.home() / '.forge' / 'cache'),
        }
        
        for var, default_value in defaults.items():
            if not os.getenv(var):
                os.environ[var] = default_value
                logger.debug(f"Set default for {var}: {default_value}")