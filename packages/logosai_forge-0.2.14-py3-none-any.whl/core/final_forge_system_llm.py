"""
FinalForgeSystem with LLM-based 5-step Pattern Generation
This implements the complete LLM-based agent generation system
"""

import asyncio
import json
import uuid
import re
import os
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass
from loguru import logger


@dataclass
class ForgeRequest:
    """FORGE 요청 데이터 클래스"""
    query: str
    user_email: str = "user@example.com"
    session_id: str = ""
    project_id: str = ""
    output_type: str = "logosai"  # logosai, fastapi, langchain, standalone
    enable_testing: bool = True
    save_to_file: bool = True
    metadata: Dict[str, Any] = None


@dataclass
class ForgeResult:
    """FORGE 결과 데이터 클래스"""
    success: bool
    agent_code: str = ""
    agent_id: str = ""
    file_path: str = ""
    test_results: Dict[str, Any] = None
    metadata: Dict[str, Any] = None
    error: str = ""


class FinalForgeSystemLLM:
    """LLM-based FORGE AI System with 5-step Pattern"""
    
    def __init__(self):
        """초기화"""
        self.output_dir = Path("forge/agents/generated")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # LLM 클라이언트 초기화
        self.llm_client = self._initialize_llm_client()
        
        logger.info("🚀 FinalForgeSystem LLM 초기화 완료")
    
    def _initialize_llm_client(self):
        """LLM 클라이언트 초기화"""
        try:
            from .direct_gemini_client import DirectGeminiClient
            
            api_key = os.getenv('GOOGLE_API_KEY')
            if not api_key:
                logger.warning("⚠️ GOOGLE_API_KEY not found")
                return None
            
            return DirectGeminiClient(api_key=api_key)
        except Exception as e:
            logger.error(f"Failed to initialize LLM client: {e}")
            return None
    
    async def create_agent(self, request: ForgeRequest) -> ForgeResult:
        """Main entry point for LLM-based agent creation with 5-step pattern"""
        
        logger.info(f"🚀 Starting LLM-based FinalForgeSystem agent creation")
        logger.info(f"📝 Query: {request.query[:100]}...")
        
        start_time = datetime.now()
        
        try:
            # Step 1: Analyze requirements with LLM
            logger.info("Step 1: Analyzing requirements...")
            requirements = await self.step1_analyze_requirements(request.query)
            logger.info(f"✅ Requirements analyzed: {requirements.get('primary_intent', 'unknown')}")
            
            # Step 2: Match business patterns
            logger.info("Step 2: Matching business patterns...")
            patterns = await self.step2_match_patterns(requirements)
            logger.info(f"✅ Primary pattern: {patterns.get('primary_pattern', 'unknown')}")
            
            # Step 3: Generate business logic with LLM
            logger.info("Step 3: Generating business logic...")
            business_logic = await self.step3_generate_business_logic(requirements, patterns)
            logger.info(f"✅ Business logic generated: {len(business_logic)} chars")
            
            # Step 4: Structure complete agent code
            logger.info("Step 4: Structuring complete agent...")
            structured_code = await self.step4_structure_code(business_logic, requirements, patterns)
            logger.info(f"✅ Structured code: {len(structured_code)} chars")
            
            # Step 5: Optimize and validate
            logger.info("Step 5: Optimizing and validating...")
            final_code = await self.step5_optimize_and_validate(structured_code, requirements)
            logger.info(f"✅ Final code: {len(final_code)} chars")
            
            # Generate metadata
            metadata = {
                "agent_id": str(uuid.uuid4())[:8],
                "agent_name": self._generate_agent_name(requirements),
                "agent_type": requirements.get('agent_type', 'custom'),
                "primary_intent": requirements.get('primary_intent', ''),
                "domain": requirements.get('domain', 'general'),
                "pattern": patterns.get('primary_pattern', ''),
                "complexity": self._calculate_complexity(requirements, patterns),
                "features": requirements.get('actions', []),
                "capabilities": requirements.get('required_capabilities', []),
                "generation_time": (datetime.now() - start_time).total_seconds(),
                "code_length": len(final_code),
                "timestamp": datetime.now().isoformat()
            }
            
            # Test if enabled
            test_results = None
            if request.enable_testing:
                test_results = await self._test_agent(final_code, requirements)
                metadata["test_status"] = test_results.get("status", "unknown")
            
            # Save to file if requested
            file_path = None
            if request.save_to_file:
                file_path = self._save_agent(final_code, metadata)
                logger.info(f"✅ Agent saved to: {file_path}")
            
            return ForgeResult(
                success=True,
                agent_code=final_code,
                agent_id=metadata["agent_id"],
                file_path=file_path,
                test_results=test_results,
                metadata=metadata
            )
            
        except Exception as e:
            logger.error(f"Agent generation failed: {e}")
            return ForgeResult(
                success=False,
                error=str(e)
            )
    
    async def step1_analyze_requirements(self, query: str) -> Dict[str, Any]:
        """Step 1: 요구사항을 분석하여 구조화된 명세 생성"""
        
        prompt = f"""
        You are an expert software architect. Analyze this request and extract technical requirements.
        
        User Request: {query}
        
        Analyze and provide:
        1. Primary Intent: What is the main goal?
        2. Domain: (e-commerce, finance, automation, monitoring, etc.)
        3. Key Entities: What are the main data/objects involved?
        4. Actions Required: What operations need to be performed?
        5. Business Rules: What conditions and constraints exist?
        6. Input Sources: Where does data come from?
        7. Output Requirements: What should be produced?
        8. Performance Needs: Any specific performance requirements?
        
        Example for "재고가 10개 이하면 경고, 5개 이하면 긴급 주문":
        {{
            "primary_intent": "inventory monitoring and automated ordering",
            "domain": "inventory_management",
            "key_entities": ["inventory", "products", "orders", "alerts"],
            "actions": ["monitor_stock", "send_alert", "create_order"],
            "business_rules": [
                {{"condition": "stock <= 10", "action": "send_warning"}},
                {{"condition": "stock <= 5", "action": "create_urgent_order"}}
            ],
            "input_sources": ["database", "inventory_system"],
            "output_requirements": ["alerts", "order_records"],
            "performance_needs": "real-time monitoring",
            "agent_type": "monitoring",
            "required_capabilities": ["data_monitoring", "alert_generation", "order_creation"]
        }}
        
        Analyze the request and return ONLY a JSON object with these fields.
        """
        
        try:
            if not self.llm_client:
                # Fallback if no LLM client
                return self._fallback_analysis(query)
            
            response = await self.llm_client.generate(
                prompt,
                max_tokens=2000,
                temperature=0.3
            )
            
            # Extract JSON from response
            json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            else:
                return self._fallback_analysis(query)
                
        except Exception as e:
            logger.error(f"Error in step1_analyze_requirements: {e}")
            return self._fallback_analysis(query)
    
    async def step2_match_patterns(self, analysis: Dict) -> Dict[str, Any]:
        """Step 2: 비즈니스 패턴 매칭 및 아키텍처 결정"""
        
        prompt = f"""
        Based on this analysis, identify the best matching business patterns and architecture.
        
        Analysis: {json.dumps(analysis, indent=2)}
        
        Common Patterns:
        1. MONITORING_PATTERN: Track metrics, check thresholds, trigger actions
        2. WORKFLOW_PATTERN: Sequential steps with conditions
        3. ETL_PATTERN: Extract, Transform, Load data
        4. CRUD_PATTERN: Create, Read, Update, Delete operations
        5. EVENT_DRIVEN_PATTERN: React to events with handlers
        6. SCHEDULER_PATTERN: Time-based execution
        7. API_GATEWAY_PATTERN: Route and process API calls
        8. AGGREGATOR_PATTERN: Collect and combine data from multiple sources
        
        Determine:
        1. Primary Pattern: Main architectural pattern
        2. Secondary Patterns: Supporting patterns
        3. Data Flow: How data moves through the system
        4. Integration Points: External systems to connect
        5. State Management: What state needs to be maintained
        
        Example Response:
        {{
            "primary_pattern": "MONITORING_PATTERN",
            "secondary_patterns": ["EVENT_DRIVEN_PATTERN", "SCHEDULER_PATTERN"],
            "data_flow": "database -> monitor -> evaluator -> action_handler",
            "integration_points": ["inventory_db", "notification_service", "order_system"],
            "state_management": {{
                "persistent": ["thresholds", "product_configs"],
                "transient": ["current_levels", "alert_status"]
            }},
            "pattern_components": {{
                "monitor": "continuously check inventory levels",
                "evaluator": "compare against thresholds",
                "action_handler": "send alerts or create orders"
            }}
        }}
        
        Return ONLY a JSON object with the pattern matching results.
        """
        
        try:
            if not self.llm_client:
                return self._fallback_patterns()
            
            response = await self.llm_client.generate(
                prompt,
                max_tokens=2000,
                temperature=0.4
            )
            
            # Extract JSON from response
            json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            else:
                return self._fallback_patterns()
                
        except Exception as e:
            logger.error(f"Error in step2_match_patterns: {e}")
            return self._fallback_patterns()
    
    async def step3_generate_business_logic(self, analysis: Dict, patterns: Dict) -> str:
        """Step 3: 핵심 비즈니스 로직 생성"""
        
        prompt = f"""
        Generate the core business logic based on the pattern and requirements.
        
        Requirements: {json.dumps(analysis, indent=2)}
        Pattern: {json.dumps(patterns, indent=2)}
        
        Generate Python code for the core business logic following these guidelines:
        1. Create complete async methods for each action identified
        2. Use clear variable names and add detailed docstrings
        3. Include comprehensive error handling
        4. Return structured Dict[str, Any] responses
        5. Add logging for important operations
        
        For each action in {analysis.get('actions', ['process'])}, create a corresponding method.
        
        Example structure:
        async def monitor_inventory(self, product_id: str) -> Dict[str, Any]:
            '''Monitor inventory and trigger actions based on thresholds'''
            try:
                # Implementation
                return {{"status": "success", "data": result}}
            except Exception as e:
                logger.error(f"Error: {{e}}")
                return {{"status": "error", "error": str(e)}}
        
        Generate ALL business logic methods needed.
        Return ONLY Python code, no markdown or explanations.
        """
        
        try:
            if not self.llm_client:
                return self._generate_fallback_business_logic(analysis, patterns)
            
            response = await self.llm_client.generate(
                prompt,
                max_tokens=10000,
                temperature=0.5
            )
            
            # Clean the response
            code = self._clean_code_response(response)
            
            # Validate we have actual methods
            if not self._validate_business_logic(code):
                return self._generate_fallback_business_logic(analysis, patterns)
            
            return code
            
        except Exception as e:
            logger.error(f"Error in step3_generate_business_logic: {e}")
            return self._generate_fallback_business_logic(analysis, patterns)
    
    async def step4_structure_code(self, business_logic: str, analysis: Dict, patterns: Dict) -> str:
        """Step 4: 완전한 에이전트 클래스 구조화"""
        
        agent_name = self._generate_agent_name(analysis)
        description = analysis.get('primary_intent', 'Process custom requests')
        
        prompt = f"""
        Create a complete LogosAI agent class incorporating the business logic.
        
        Agent Name: {agent_name}
        Description: {description}
        
        Business Logic to incorporate:
        {business_logic}
        
        Requirements: {json.dumps(analysis, indent=2)}
        
        Generate a COMPLETE LogosAI agent with:
        1. All necessary imports
        2. Proper class definition inheriting from LogosAIAgent
        3. __init__ method with AgentConfig
        4. async initialize method
        5. async process method that uses the business logic
        6. All business logic methods integrated
        7. Error handling and logging
        8. async cleanup method
        
        The agent should be production-ready and fully functional.
        Return ONLY the complete Python code, no markdown or explanations.
        Start with imports and end with the complete class.
        """
        
        try:
            if not self.llm_client:
                return self._generate_fallback_agent(business_logic, analysis, patterns)
            
            response = await self.llm_client.generate(
                prompt,
                max_tokens=15000,
                temperature=0.6
            )
            
            # Clean the response
            code = self._clean_code_response(response)
            
            # Validate structure
            if not self._validate_agent_structure(code):
                return self._generate_fallback_agent(business_logic, analysis, patterns)
            
            return code
            
        except Exception as e:
            logger.error(f"Error in step4_structure_code: {e}")
            return self._generate_fallback_agent(business_logic, analysis, patterns)
    
    async def step5_optimize_and_validate(self, code: str, requirements: Dict) -> str:
        """Step 5: 코드 최적화 및 검증"""
        
        # First: Syntax validation
        syntax_errors = self._check_syntax(code)
        
        if syntax_errors:
            logger.warning(f"Syntax errors detected: {syntax_errors}")
            
            if self.llm_client:
                # Fix with LLM
                code = await self._fix_with_llm(code, syntax_errors, requirements)
            else:
                # Basic fixes
                code = self._apply_basic_fixes(code)
        
        # Check completeness
        if len(code) < 8000:
            logger.warning(f"Code seems incomplete ({len(code)} chars)")
            
            if self.llm_client:
                code = await self._expand_code(code, requirements)
        
        # Final validation
        final_errors = self._check_syntax(code)
        if final_errors:
            logger.warning("Still has syntax errors after fixes, applying emergency fixes")
            code = self._apply_emergency_fixes(code)
        
        logger.info(f"✅ Final code validation complete: {len(code)} chars")
        return code
    
    async def _fix_with_llm(self, code: str, errors: List[str], requirements: Dict) -> str:
        """Fix code errors using LLM"""
        
        error_desc = '\n'.join(errors[:5])  # Limit to first 5 errors
        
        prompt = f"""
        Fix these Python syntax errors and complete the code:
        
        Errors:
        {error_desc}
        
        Current Code:
        {code[:5000]}...
        
        Requirements: {json.dumps(requirements, indent=2)}
        
        Fix ALL errors and ensure:
        1. Complete all truncated methods
        2. Fix all syntax issues
        3. Add missing imports
        4. Ensure LogosAI framework compliance
        
        Return the COMPLETE, FIXED Python code only.
        """
        
        try:
            response = await self.llm_client.generate(
                prompt,
                max_tokens=15000,
                temperature=0.3
            )
            
            return self._clean_code_response(response)
            
        except Exception as e:
            logger.error(f"LLM fix failed: {e}")
            return self._apply_basic_fixes(code)
    
    async def _expand_code(self, code: str, requirements: Dict) -> str:
        """Expand incomplete code using LLM"""
        
        prompt = f"""
        This LogosAI agent code is incomplete. Expand it with:
        
        1. Complete implementations for all methods
        2. Comprehensive error handling
        3. Detailed logging
        4. All business rules from requirements
        5. Helper methods as needed
        
        Current code ({len(code)} chars):
        {code}
        
        Requirements: {json.dumps(requirements, indent=2)}
        
        Generate the COMPLETE, EXPANDED agent code.
        Ensure it's at least 10,000 characters with full functionality.
        Return ONLY Python code.
        """
        
        try:
            response = await self.llm_client.generate(
                prompt,
                max_tokens=15000,
                temperature=0.5
            )
            
            expanded = self._clean_code_response(response)
            
            if len(expanded) > len(code):
                logger.info(f"Code expanded from {len(code)} to {len(expanded)} chars")
                return expanded
            else:
                return code
                
        except Exception as e:
            logger.error(f"Code expansion failed: {e}")
            return code
    
    # ============== Helper Methods ==============
    
    def _clean_code_response(self, response: str) -> str:
        """Clean LLM response to extract pure Python code"""
        
        code = response.strip()
        
        # Remove markdown code blocks
        if '```python' in code:
            code = re.sub(r'```python\n?', '', code)
            code = re.sub(r'```\n?', '', code)
        elif '```' in code:
            code = re.sub(r'```\n?', '', code)
        
        # Remove any JSON wrapping
        if code.startswith('{') and '"code"' in code[:100]:
            try:
                data = json.loads(code)
                if 'code' in data:
                    code = data['code']
            except:
                pass
        
        return code.strip()
    
    def _check_syntax(self, code: str) -> List[str]:
        """Check Python syntax and return errors"""
        
        errors = []
        try:
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            errors.append(f"Line {e.lineno}: {e.msg}")
        
        return errors
    
    def _validate_business_logic(self, code: str) -> bool:
        """Validate that business logic contains actual methods"""
        
        return any(keyword in code for keyword in ['async def', 'def']) and len(code) > 100
    
    def _validate_agent_structure(self, code: str) -> bool:
        """Validate agent has proper structure"""
        
        required = ['class', 'LogosAIAgent', 'async def process', '__init__']
        return all(req in code for req in required)
    
    def _apply_basic_fixes(self, code: str) -> str:
        """Apply basic syntax fixes"""
        
        # Remove backticks
        code = re.sub(r'```[a-zA-Z]*\n?', '', code)
        code = re.sub(r'```\n?', '', code)
        
        # Fix unclosed strings
        lines = code.split('\n')
        fixed_lines = []
        
        for line in lines:
            # Count quotes
            if line.count('"') % 2 != 0:
                line += '"'
            if line.count("'") % 2 != 0:
                line += "'"
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _apply_emergency_fixes(self, code: str) -> str:
        """Apply emergency fixes for persistent errors"""
        
        # Remove problematic lines
        lines = code.split('\n')
        clean_lines = []
        
        for line in lines:
            # Skip obviously broken lines
            if line.strip().endswith('\\'):
                continue
            if '...' in line and 'docstring' not in line.lower():
                continue
            clean_lines.append(line)
        
        return '\n'.join(clean_lines)
    
    def _generate_agent_name(self, analysis: Dict) -> str:
        """Generate agent name from analysis"""
        
        intent = analysis.get('primary_intent', 'custom').replace('_', ' ')
        words = intent.split()[:2]
        name = ''.join(w.title() for w in words) + 'Agent'
        
        return name
    
    def _calculate_complexity(self, analysis: Dict, patterns: Dict) -> str:
        """Calculate agent complexity"""
        
        actions = len(analysis.get('actions', []))
        rules = len(analysis.get('business_rules', []))
        patterns_count = 1 + len(patterns.get('secondary_patterns', []))
        
        score = actions + rules + patterns_count
        
        if score <= 3:
            return "simple"
        elif score <= 7:
            return "moderate"
        else:
            return "complex"
    
    def _save_agent(self, code: str, metadata: Dict[str, Any]) -> str:
        """Save agent to file"""
        
        filename = f"{metadata['agent_name'].lower()}_{metadata['agent_id']}.py"
        file_path = self.output_dir / filename
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)
        
        return str(file_path)
    
    async def _test_agent(self, code: str, analysis: Dict) -> Dict[str, Any]:
        """Test generated agent"""
        
        try:
            # Basic syntax check
            compile(code, '<string>', 'exec')
            
            # Create test input based on analysis
            test_input = {
                "query": f"Test {analysis.get('primary_intent', 'operation')}",
                "data": {"test": True}
            }
            
            return {
                "status": "success",
                "test_input": test_input,
                "test_result": {"message": "Agent compiled successfully"}
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    # ============== Fallback Methods ==============
    
    def _fallback_analysis(self, query: str) -> Dict[str, Any]:
        """Fallback analysis when LLM is not available"""
        
        # Simple keyword-based analysis
        query_lower = query.lower()
        
        if '재고' in query or 'inventory' in query_lower:
            return {
                "primary_intent": "inventory_monitoring",
                "domain": "inventory_management",
                "key_entities": ["inventory", "products"],
                "actions": ["monitor", "alert", "order"],
                "business_rules": [
                    {"condition": "threshold", "action": "alert"}
                ],
                "agent_type": "monitoring",
                "required_capabilities": ["monitoring", "alerting"]
            }
        elif '계산' in query or 'calculat' in query_lower:
            return {
                "primary_intent": "calculation",
                "domain": "computation",
                "key_entities": ["numbers", "operations"],
                "actions": ["calculate", "validate"],
                "business_rules": [],
                "agent_type": "calculator",
                "required_capabilities": ["computation"]
            }
        else:
            return {
                "primary_intent": "custom_processing",
                "domain": "general",
                "key_entities": ["data"],
                "actions": ["process"],
                "business_rules": [],
                "agent_type": "custom",
                "required_capabilities": ["data_processing"]
            }
    
    def _fallback_patterns(self) -> Dict[str, Any]:
        """Fallback patterns when LLM is not available"""
        
        return {
            "primary_pattern": "WORKFLOW_PATTERN",
            "secondary_patterns": [],
            "data_flow": "input -> process -> output",
            "integration_points": [],
            "state_management": {"persistent": [], "transient": []}
        }
    
    def _generate_fallback_business_logic(self, analysis: Dict, patterns: Dict) -> str:
        """Generate fallback business logic"""
        
        actions = analysis.get('actions', ['process'])
        logic_methods = []
        
        for action in actions:
            method_name = action.replace(' ', '_').lower()
            logic_methods.append(f'''
    async def {method_name}(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute {action} operation"""
        try:
            # Process input
            result = {{
                "action": "{action}",
                "status": "success",
                "data": input_data,
                "timestamp": datetime.now().isoformat()
            }}
            
            # Apply business rules
            for rule in self.business_rules:
                # Check conditions and apply actions
                pass
            
            return result
            
        except Exception as e:
            logger.error(f"Error in {method_name}: {{e}}")
            return {{
                "status": "error",
                "action": "{action}",
                "error": str(e)
            }}
''')
        
        return '\n'.join(logic_methods)
    
    def _generate_fallback_agent(self, business_logic: str, analysis: Dict, patterns: Dict) -> str:
        """Generate complete fallback agent"""
        
        agent_name = self._generate_agent_name(analysis)
        description = analysis.get('primary_intent', 'Custom processing')
        
        return f'''from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType
from typing import Dict, Any, Optional, List
import asyncio
import json
from datetime import datetime
from loguru import logger


class {agent_name}(LogosAIAgent):
    """{description}"""
    
    def __init__(self, config: Optional[AgentConfig] = None):
        """Initialize the agent"""
        if config is None:
            config = AgentConfig(
                name="{agent_name}",
                agent_type=AgentType.CUSTOM,
                description="{description}",
                config={{
                    "model": "gemini-2.5-flash-lite",
                    "temperature": 0.7,
                    "max_tokens": 15000
                }}
            )
        super().__init__(config)
        
        # Initialize components
        self.business_rules = {json.dumps(analysis.get('business_rules', []))}
        self.pattern = "{patterns.get('primary_pattern', 'WORKFLOW_PATTERN')}"
        
    async def initialize(self) -> bool:
        """Async initialization"""
        try:
            logger.info(f"Initializing {{self.name}}")
            # Initialize resources
            return True
        except Exception as e:
            logger.error(f"Initialization failed: {{e}}")
            return False
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Main processing method"""
        try:
            # Parse input
            input_data = {{
                "query": query,
                "context": context or {{}}
            }}
            
            # Apply business logic
            result = await self.execute_business_logic(input_data)
            
            # Return response
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result,
                message="Processing completed successfully"
            )
            
        except Exception as e:
            logger.error(f"Processing error: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}},
                message=f"Error: {{str(e)}}"
            )
    
    async def execute_business_logic(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute core business logic"""
        results = []
        
        # Execute each action
        for action in {analysis.get('actions', ['process'])}:
            method_name = action.replace(' ', '_').lower()
            if hasattr(self, method_name):
                method = getattr(self, method_name)
                result = await method(input_data)
                results.append(result)
        
        return {{
            "results": results,
            "summary": f"Executed {{len(results)}} actions"
        }}
    
{business_logic}
    
    async def cleanup(self):
        """Cleanup resources"""
        try:
            logger.info(f"Cleaning up {{self.name}}")
            # Cleanup logic
        except Exception as e:
            logger.error(f"Cleanup error: {{e}}")
'''


# Example usage
async def main():
    """Test the LLM-based FinalForgeSystem"""
    
    system = FinalForgeSystemLLM()
    
    # Test request
    request = ForgeRequest(
        query="재고가 10개 이하면 경고 알림을 보내고, 5개 이하면 긴급 주문을 자동으로 생성하는 시스템",
        enable_testing=True,
        save_to_file=True
    )
    
    result = await system.create_agent(request)
    
    if result.success:
        print(f"\n✅ Agent created successfully!")
        print(f"Agent ID: {result.agent_id}")
        print(f"Code length: {len(result.agent_code)} chars")
        print(f"File: {result.file_path}")
        print(f"Metadata: {json.dumps(result.metadata, indent=2)}")
    else:
        print(f"\n❌ Agent creation failed: {result.error}")


if __name__ == "__main__":
    asyncio.run(main())