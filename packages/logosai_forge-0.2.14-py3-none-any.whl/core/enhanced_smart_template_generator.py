"""
Enhanced Smart Template Generator for FORGE AI
Generates agent code using template system with streaming support, automatic error fixing, and proper token limits
"""

import asyncio
import re
import ast
import json
from typing import Optional, Any, Callable, Dict, List, Tuple
from datetime import datetime
from pathlib import Path
from enum import Enum
from loguru import logger

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts
from .sandbox_executor import SandboxExecutor, ExecutionResult
from .template_based_generator import TemplateBasedGenerator


class StreamEventType(Enum):
    """Detailed streaming event types for real-time updates"""
    # Analysis stage
    ANALYSIS_START = "analysis_start"
    ANALYSIS_DOMAIN = "analysis_domain"
    ANALYSIS_FEATURES = "analysis_features"
    ANALYSIS_COMPLETE = "analysis_complete"
    
    # Generation stage
    GENERATION_START = "generation_start"
    TEMPLATE_SELECTED = "template_selected"
    GENERATING_INIT = "generating_init"
    INIT_GENERATED = "init_generated"
    GENERATING_LOGIC = "generating_logic"
    LOGIC_GENERATED = "logic_generated"
    GENERATING_SAMPLE = "generating_sample"
    SAMPLE_GENERATED = "sample_generated"
    GENERATING_TEST = "generating_test"
    TEST_GENERATED = "test_generated"
    CODE_ASSEMBLED = "code_assembled"
    
    # Test stage
    TEST_START = "test_start"
    TEST_RUNNING = "test_running"
    TEST_OUTPUT = "test_output"
    TEST_ERROR = "test_error"
    TEST_SUCCESS = "test_success"
    
    # Fix stage
    FIX_START = "fix_start"
    FIX_ANALYZING = "fix_analyzing"
    FIX_APPLYING = "fix_applying"
    FIX_COMPLETE = "fix_complete"
    
    # Completion
    GENERATION_COMPLETE = "generation_complete"
    GENERATION_FAILED = "generation_failed"


class EnhancedSmartTemplateGenerator:
    """
    Enhanced template-based code generator with proper token limits and streaming support
    """
    
    def __init__(self, llm_orchestrator: LLMOrchestrator, sandbox_executor: SandboxExecutor):
        """Initialize with LLM and sandbox executor"""
        self.llm = llm_orchestrator
        self.sandbox = sandbox_executor
        self.template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template_v2.py.template"
        
        # Load clean template
        try:
            with open(self.template_path, 'r') as f:
                self.template = f.read()
        except Exception as e:
            logger.error(f"Could not load template: {e}")
            self.template = ""
        
        # Initialize template-based generator
        self.template_generator = TemplateBasedGenerator(
            templates_dir=Path(__file__).parent.parent / "templates"
        )
        
        # Track generation state
        self.current_code = ""
        self.fix_attempts = 0
        self.max_fix_attempts = 3
        
        # Enhanced token limits to prevent truncation
        self.token_limits = {
            'init': 3000,           # Increased from 1000
            'logic_per_feature': 8000,  # Increased from 2000
            'sample_data': 4000,    # New limit for sample data
            'test_code': 4000,      # New limit for test code
            'fix_syntax': 1000,     # Increased from 200
            'fix_general': 10000    # Increased from 3000
        }
        
        # Template mode flag
        self.use_template_mode = True  # Enable new template-based generation
    
    async def generate_progressively(self, analysis: QueryAnalysis, context: Context,
                                    stream_callback: Optional[Callable] = None) -> Any:
        """Generate agent code with detailed streaming updates"""
        
        start_time = datetime.now()
        
        try:
            # Check if template mode is enabled
            if self.use_template_mode:
                return await self._generate_with_templates(analysis, context, stream_callback)
            
            # Original generation flow (fallback)
            # Start generation
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_START,
                "🚀 에이전트 생성을 시작합니다...",
                {"progress": 0, "total_stages": 7}
            )
            
            # 1. Extract agent metadata
            agent_metadata = await self._generate_agent_metadata(analysis, stream_callback)
            
            # 2. Generate initialization code
            init_code = await self._generate_init_code(analysis, stream_callback)
            
            # 3. Generate business logic (with higher token limits)
            logic_code = await self._generate_business_logic(analysis, stream_callback)
            
            # 4. Generate sample data
            sample_data_code = await self._generate_sample_data(analysis, stream_callback)
            
            # 5. Generate test code
            test_code = await self._generate_test_code(analysis, sample_data_code, stream_callback)
            
            # 6. Assemble complete code
            complete_code = await self._assemble_code(
                agent_metadata,
                init_code,
                logic_code,
                sample_data_code,
                test_code,
                stream_callback
            )
            
            # 7. Test and fix until working
            final_code = await self._test_and_fix_code(complete_code, analysis, stream_callback)
            
            # Complete
            total_time = (datetime.now() - start_time).total_seconds()
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_COMPLETE,
                f"✅ 에이전트 생성 완료! (총 {total_time:.1f}초)",
                {
                    "progress": 100,
                    "total_time": total_time,
                    "code_length": len(final_code)
                }
            )
            
            # Create artifacts
            artifacts = self._create_artifacts(analysis, start_time, final_code)
            
            # 🚨 CRITICAL: Apply UniversalCodeParser to ensure no JSON contamination
            logger.info("🔥 FINAL STEP: Applying UniversalCodeParser to ensure clean code")
            
            try:
                from .universal_code_parser import UniversalCodeParser
                parser = UniversalCodeParser()
                
                # Check if final_code looks like JSON
                # 수정: 10000자 임계값을 30000자로 증가 (템플릿 프롬프트 문제 회피)
                if ('"code":' in final_code or 
                    final_code.strip().startswith('{"') or 
                    (len(final_code) > 30000 and '```' in final_code)):
                    
                    logger.warning(f"🚨 DETECTED JSON CONTAMINATION in final_code ({len(final_code)} chars) - applying parser")
                    
                    # Parse with UniversalCodeParser
                    cleaned_code = parser.parse(final_code)
                    
                    if cleaned_code and len(cleaned_code.strip()) > 50:
                        logger.info(f"✅ Successfully cleaned final_code: {len(cleaned_code)} chars")
                        final_code = cleaned_code
                    else:
                        logger.error("❌ Parser failed, using emergency template")
                        final_code = self._get_emergency_minimal_agent()
                
                # Double-check result
                if '"code":' in final_code or '{"' in final_code[:100]:
                    logger.error("🚨 STILL CONTAMINATED! Using emergency template")
                    final_code = self._get_emergency_minimal_agent()
                else:
                    logger.info("✅ Final code is clean")
                    
            except Exception as e:
                logger.error(f"Final cleanup failed: {e}")
                # Use emergency template as last resort
                final_code = self._get_emergency_minimal_agent()
            
            # Return result
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "enhanced_smart_template_generation"
            
            return GeneratedCode(code=final_code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Generation failed: {e}")
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_FAILED,
                f"❌ 생성 실패: {str(e)}",
                {"error": str(e)}
            )
            raise
    
    async def _generate_agent_metadata(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> Dict[str, str]:
        """Generate agent metadata including class name"""
        
        await self._stream_event(
            callback,
            StreamEventType.ANALYSIS_DOMAIN,
            f"📋 도메인 분석: {analysis.domain or 'general'}",
            {"progress": 5, "domain": analysis.domain}
        )
        
        # Generate English class name
        class_name = self._generate_english_class_name(analysis)
        
        await self._stream_event(
            callback,
            StreamEventType.ANALYSIS_FEATURES,
            f"🎯 필요 기능: {', '.join(analysis.required_capabilities[:3])}...",
            {"progress": 10, "features": analysis.required_capabilities}
        )
        
        # Clean up description to avoid syntax errors
        description = analysis.query[:200].replace('\n', ' ').replace('"', "'").strip()
        
        return {
            'agent_class_name': class_name,
            'agent_name': class_name.replace('Agent', ' Agent'),
            'agent_type': 'CUSTOM',
            'agent_description': description,
            'custom_config': self._generate_config_dict(analysis)
        }
    
    async def _generate_init_code(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Generate initialization code with proper token limit"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_INIT,
            "🔧 초기화 코드를 생성하고 있습니다...",
            {"progress": 15}
        )
        
        prompt = f"""Generate ONLY Python initialization code for this agent:
{analysis.query}

SECURITY CONSTRAINTS - MUST FOLLOW:
- DO NOT import: os, sys, subprocess, socket, urllib, requests, pathlib
- DO NOT use file operations: open(), file(), Path()
- The template already imports: json, datetime, pandas, numpy, re, logosai
- You can only use safe imports: math, random, collections, itertools

Requirements:
1. ONLY variable initialization (self.xxx = ...)
2. NO imports, NO comments in Korean
3. Keep it concise and relevant
4. Initialize all necessary variables for the requested features
5. Follow ALL security constraints above
6. Use f-strings for formatting: f"{{variable}}" not {{{{{{variable}}}}}}
7. For dictionaries, use single braces: {{{{'key': 'value'}}}} not {{{{{{''key'': ''value''}}}}}}
8. DO NOT reference 'analysis' variable - it doesn't exist in init context
9. Use self for all instance variables

Example format:
self.data_cache = {{}}
self.threshold = 0.95
self.api_client = None
self.portfolio_data = {{}}
self.risk_metrics = {{}}

Generate initialization code for ALL required features:"""

        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=self.token_limits['init'],
            temperature=0.3
        )
        
        code = self._extract_code(result)
        
        await self._stream_event(
            callback,
            StreamEventType.INIT_GENERATED,
            "✅ 초기화 코드 생성 완료",
            {"progress": 20, "code_preview": code[:100] + "..."}
        )
        
        return code
    
    async def _generate_business_logic(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Generate core business logic with higher token limits"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_LOGIC,
            "💡 핵심 비즈니스 로직을 구현하고 있습니다...",
            {"progress": 25}
        )
        
        # For complex agents, generate all logic in one comprehensive prompt
        if len(analysis.required_capabilities) > 3:
            # Single comprehensive generation for complex agents
            prompt = f"""You are implementing the core business logic for an AI agent.

USER REQUEST: {analysis.query}

REQUIRED CAPABILITIES:
{chr(10).join([f"- {cap}" for cap in analysis.required_capabilities])}

🚨 CRITICAL: OUTPUT ONLY PURE PYTHON CODE - NO JSON, NO MARKDOWN, NO EXPLANATIONS

Your response must start immediately with Python code. Do NOT wrap in JSON or markdown.

Example of correct response format:
def helper_method(self, data):
    # process data
    return result

def main_logic(self, extracted_info):
    # implement core functionality
    return {{"status": "success", "data": result}}

REQUIREMENTS:
- Write helper methods for complex operations
- Use extracted_info parameter for input data  
- Return dictionary with status and results
- Handle errors with try/except
- Use pandas (pd), numpy (np), datetime if needed
- All code must be executable Python

Start your Python code now (no JSON, no markdown):"""

            result = await self.llm.generate(
                prompt=prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=self.token_limits['logic_per_feature'] * 2,  # Double for comprehensive
                temperature=0.4
            )
            
            # 🔍 DEBUG: 실제 LLM 응답 분석
            logger.info("=" * 80)
            logger.info("🔍 RAW LLM RESPONSE ANALYSIS:")
            logger.info(f"📏 Response length: {len(str(result))} chars")
            logger.info(f"🎯 First 500 chars: {str(result)[:500]}...")
            logger.info(f"🎯 Last 500 chars: ...{str(result)[-500:]}")
            logger.info(f"🚨 Contains JSON patterns:")
            code_pattern = '{"code":'
            exec_pattern = 'exec('
            json_pattern = '```json'
            python_pattern = '```python'
            
            logger.info(f"   - '{code_pattern}': {'Yes' if code_pattern in str(result) else 'No'}")
            logger.info(f"   - '{exec_pattern}': {'Yes' if exec_pattern in str(result) else 'No'}")
            logger.info(f"   - '{json_pattern}': {'Yes' if json_pattern in str(result) else 'No'}")
            logger.info(f"   - '{python_pattern}': {'Yes' if python_pattern in str(result) else 'No'}")
            logger.info("=" * 80)
            
            final_logic = self._extract_code(result)
            
            # 🔍 DEBUG: Save generated logic to file for analysis
            debug_file = f"debug_generated_logic_{datetime.now().strftime('%H%M%S')}.py"
            try:
                with open(debug_file, 'w', encoding='utf-8') as f:
                    f.write("# Generated Business Logic\n")
                    f.write("# " + "="*50 + "\n")
                    f.write(f"# Generated at: {datetime.now()}\n")
                    f.write("# " + "="*50 + "\n\n")
                    f.write(final_logic)
                logger.info(f"💾 Saved generated logic to: {debug_file}")
            except Exception as e:
                logger.error(f"Failed to save debug file: {e}")
            
        else:
            # Generate feature by feature for simpler agents
            all_logic = []
            features = analysis.required_capabilities
            
            for i, feature in enumerate(features[:5]):  # Limit to 5 main features
                progress = 30 + (i * 10)
                
                await self._stream_event(
                    callback,
                    StreamEventType.GENERATING_LOGIC,
                    f"💡 {feature} 기능 구현 중...",
                    {"progress": progress, "current_feature": feature}
                )
                
                prompt = f"""Implement this specific feature: {feature}

USER REQUEST: {analysis.query}

🚨 RESPOND WITH PURE PYTHON CODE ONLY - NO JSON, NO MARKDOWN, NO EXPLANATIONS

✅ Write Python code that implements this feature
❌ Do NOT use {{"code": "..."}} format
❌ Do NOT use ```json or explanatory text

REQUIREMENTS:
- Implement {feature} functionality
- Use extracted_info parameter for input data
- Return dictionary with results
- Handle errors with try/except
- Use pandas (pd), numpy (np) if needed

Write the Python code now:"""

                result = await self.llm.generate(
                    prompt=prompt,
                    task_type=TaskType.CODE_GENERATION,
                    max_tokens=self.token_limits['logic_per_feature'],
                    temperature=0.4
                )
                
                # 🔍 DEBUG: Feature별 LLM 응답 분석
                logger.info(f"🔍 FEATURE '{feature}' LLM RESPONSE:")
                logger.info(f"📏 Length: {len(str(result))} chars")
                logger.info(f"🎯 Preview: {str(result)[:200]}...")
                
                feature_code = self._extract_code(result)
                all_logic.append(f"# {feature}\n{feature_code}")
            
            final_logic = "\n\n".join(all_logic)
        
        await self._stream_event(
            callback,
            StreamEventType.LOGIC_GENERATED,
            "✅ 비즈니스 로직 구현 완료",
            {"progress": 70}
        )
        
        return final_logic
    
    async def _generate_sample_data(self, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Generate domain-specific sample data with proper token limit"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_SAMPLE,
            "📊 테스트용 샘플 데이터를 생성하고 있습니다...",
            {"progress": 75}
        )
        
        domain = (analysis.domain or "general").lower()
        
        prompt = f"""Generate ONLY Python code for sample data to test a {domain} agent.

The agent needs: {', '.join(analysis.required_capabilities[:3])}

SECURITY CONSTRAINTS:
- ONLY use these safe imports: pandas, numpy, datetime, json, random
- DO NOT import: os, sys, subprocess, socket, urllib, requests, pathlib
- DO NOT use file operations or network calls
- Generate data programmatically, don't read from files

Requirements:
1. Generate ONLY executable Python code - no explanations
2. ONLY use allowed imports listed above
3. Create realistic sample data variables
4. Use pandas DataFrames where appropriate
5. DO NOT use 'self.' - this is module-level code
6. Include various test scenarios
7. DO NOT use any backticks (```) in your response
8. Return ONLY pure Python code

Example format:
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Sample market data
dates = pd.date_range(end=datetime.now(), periods=100)
prices = 100 + np.cumsum(np.random.randn(100) * 2)

Generate ONLY the Python code for sample data:"""

        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=self.token_limits['sample_data'],
            temperature=0.5
        )
        
        sample_code = self._extract_code(result)
        
        await self._stream_event(
            callback,
            StreamEventType.SAMPLE_GENERATED,
            "✅ 샘플 데이터 생성 완료",
            {"progress": 80}
        )
        
        return sample_code
    
    async def _generate_test_code(self, analysis: QueryAnalysis, sample_data: str, callback: Optional[Callable]) -> str:
        """Generate test code with sample data"""
        
        await self._stream_event(
            callback,
            StreamEventType.GENERATING_TEST,
            "🧪 테스트 코드를 작성하고 있습니다...",
            {"progress": 85}
        )
        
        # Extract main capabilities for testing
        test_queries = []
        for cap in analysis.required_capabilities[:3]:
            test_queries.append(f"Test {cap}")
        
        # Generate properly formatted test queries for template
        test_queries_str = str(test_queries)
        
        await self._stream_event(
            callback,
            StreamEventType.TEST_GENERATED,
            "✅ 테스트 코드 작성 완료",
            {"progress": 90}
        )
        
        return test_queries_str
    
    async def _assemble_code(self, metadata: Dict, init_code: str, logic_code: str, 
                           sample_data: str, test_code: str, callback: Optional[Callable]) -> str:
        """Assemble all parts into complete code"""
        
        await self._stream_event(
            callback,
            StreamEventType.CODE_ASSEMBLED,
            "🔨 전체 코드를 조립하고 있습니다...",
            {"progress": 92}
        )
        
        # Apply template using string.Template for safer substitution
        from string import Template
        
        # Convert template to use $ instead of {}
        safe_template = Template(self.template.replace('{agent_class_name}', '$agent_class_name')
                                              .replace('{agent_name}', '$agent_name')
                                              .replace('{agent_type}', '$agent_type')
                                              .replace('{agent_description}', '$agent_description')
                                              .replace('{custom_config}', '$custom_config')
                                              .replace('{custom_init}', '$custom_init')
                                              .replace('{custom_async_init}', '$custom_async_init')
                                              .replace('{core_business_logic}', '$core_business_logic')
                                              .replace('{custom_cleanup}', '$custom_cleanup')
                                              .replace('{sample_data}', '$sample_data')
                                              .replace('{test_queries}', '$test_queries'))
        
        # 🔍 DEBUG: Template assembly debugging
        logger.info("🔧 Template assembly debugging:")
        logger.info(f"  - agent_class_name: {metadata.get('agent_class_name', 'MISSING')}")
        logger.info(f"  - logic_code length: {len(logic_code)} chars")
        logger.info(f"  - init_code length: {len(init_code)} chars")
        logger.info(f"  - sample_data length: {len(sample_data)} chars")
        logger.info(f"  - test_code length: {len(test_code)} chars")
        
        # Validate each code snippet before assembly
        validation_errors = []
        
        # Check init_code for 'analysis' reference
        if 'analysis.' in init_code and 'self.analysis' not in init_code:
            logger.warning("⚠️ init_code contains 'analysis' reference - fixing...")
            init_code = init_code.replace('analysis.', 'self.')
        
        # Check for undefined variables in init_code
        if init_code and init_code.strip():
            try:
                compile(init_code, '<init_code>', 'exec')
                logger.info("✅ init_code syntax valid")
            except SyntaxError as e:
                logger.warning(f"⚠️ init_code has syntax error: {e}")
                init_code = "# Init code had syntax errors, using default\npass"
        
        # Check logic_code
        if logic_code and logic_code.strip():
            # Basic syntax check (can't fully validate without context)
            if 'analysis.' in logic_code and 'self.analysis' not in logic_code:
                logger.warning("⚠️ logic_code contains 'analysis' reference - fixing...")
                logic_code = logic_code.replace('analysis.', 'self.')
        
        # 옵션 1과 2 적용: 설명 텍스트 안전하게 처리
        safe_description = metadata.get('agent_description', '')
        
        # 옵션 2: 줄바꿈 이스케이프 처리
        if '\n' in safe_description:
            # 여러 줄 텍스트를 파이썬 문자열로 안전하게 변환
            safe_description = safe_description.replace('\\', '\\\\')
            safe_description = safe_description.replace('"', '\\"')
            # 삼중 따옴표로 감싸기 위한 표시 추가
            safe_description = '"""' + safe_description + '"""'
        else:
            # 한 줄 텍스트는 일반 문자열로 처리
            safe_description = safe_description.replace('\\', '\\\\')
            safe_description = safe_description.replace('"', '\\"')
        
        try:
            final_code = safe_template.substitute(
                agent_class_name=metadata['agent_class_name'],
                agent_name=metadata['agent_name'],
                agent_type=metadata['agent_type'],
            agent_description=safe_description,
            custom_config=metadata['custom_config'],
            custom_init=self._indent_code(init_code, 8),
            custom_async_init=self._indent_code("# No additional async initialization required", 12),
            core_business_logic=self._indent_code(logic_code, 12),
            custom_cleanup=self._indent_code("# No additional cleanup required", 12),
            sample_data=self._indent_code(sample_data, 4),
            test_queries=test_code
        )
            logger.info(f"✅ Template assembly successful: {len(final_code)} chars")
            
        except Exception as e:
            logger.error(f"🚨 Template assembly FAILED: {e}")
            logger.error(f"🚨 Template assembly error type: {type(e).__name__}")
            logger.error(f"🚨 Available metadata keys: {list(metadata.keys())}")
            
            # 🚨 EMERGENCY FALLBACK: Create guaranteed working agent
            agent_name = metadata.get('agent_class_name', 'GeneratedAgent')
            logger.error(f"🚨 CREATING EMERGENCY ASSEMBLY FOR: {agent_name}")
            
            # Clean and validate business logic code
            clean_logic = self._clean_business_logic_for_emergency(logic_code)
            
            final_code = f'''from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType
from typing import Dict, Any, Optional
from datetime import datetime
import json
import pandas as pd
import numpy as np

class {agent_name}(LogosAIAgent):
    """Generated agent with emergency assembly"""
    
    def __init__(self, config: Optional[AgentConfig] = None):
        super().__init__(config)
        
    async def process(self, query: str, context: Dict[str, Any] = None) -> AgentResponse:
        """Process user query with generated business logic"""
        try:
            # Execute business logic
{clean_logic}
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={{
                    "message": "Processing completed successfully", 
                    "query": query,
                    "timestamp": datetime.now().isoformat()
                }}
            )
        except Exception as e:
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{
                    "error": str(e),
                    "message": "Processing failed but agent is functional",
                    "query": query
                }}
            )
'''
            logger.info(f"🔧 EMERGENCY ASSEMBLY COMPLETE: {len(final_code)} chars")
            logger.info(f"🔧 Business logic size: {len(clean_logic)} chars")
        
        await self._stream_event(
            callback,
            StreamEventType.CODE_ASSEMBLED,
            "✅ 코드 조립 완료",
            {"progress": 95, "code_length": len(final_code)}
        )
        
        # 🔍 DEBUG: Save final assembled code
        debug_final_file = f"debug_final_assembled_{datetime.now().strftime('%H%M%S')}.py"
        try:
            with open(debug_final_file, 'w', encoding='utf-8') as f:
                f.write("# Final Assembled Agent Code\n")
                f.write("# " + "="*50 + "\n")
                f.write(f"# Generated at: {datetime.now()}\n")
                f.write(f"# Template Type: {metadata.get('template_type', 'Unknown')}\n")
                f.write("# " + "="*50 + "\n\n")
                f.write(final_code)
            logger.info(f"💾 Saved final assembled code to: {debug_final_file}")
        except Exception as e:
            logger.error(f"Failed to save final debug file: {e}")
        
        # 🔧 CRITICAL FIX: Apply all automatic fixes
        final_code = self._apply_all_automatic_fixes(final_code)
        
        return final_code
    
    def _clean_business_logic_for_emergency(self, logic_code: str) -> str:
        """Clean business logic code for emergency assembly"""
        if not logic_code or len(logic_code.strip()) < 10:
            return "            # No business logic provided\n            result = {'status': 'no_logic'}\n            logger.info(f'Query processed: {query}')"
        
        # Add proper indentation (12 spaces for method body)
        lines = logic_code.strip().split('\n')
        indented_lines = []
        
        for line in lines:
            if line.strip():
                # Ensure proper indentation
                if not line.startswith('            '):
                    indented_lines.append('            ' + line.lstrip())
                else:
                    indented_lines.append(line)
            else:
                indented_lines.append('')
        
        # 🔥 CRITICAL: Fix f-string syntax errors
        result = '\n'.join(indented_lines)
        clean_code = self._fix_fstring_syntax(result)
        return clean_code
    
    def _fix_fstring_syntax(self, code: str) -> str:
        """Fix f-string syntax errors (remove # comments inside f-strings)"""
        import re
        
        # Pattern to find f-strings with # comments inside {}
        fstring_pattern = r'f"([^"]*\{[^}]*#[^}]*\}[^"]*)"'
        
        def fix_fstring_match(match):
            fstring_content = match.group(1)
            # Remove everything after # inside {}
            fixed_content = re.sub(r'(\{[^#}]*)(#[^}]*)', r'\1', fstring_content)
            return f'f"{fixed_content}"'
        
        # Apply fix
        fixed_code = re.sub(fstring_pattern, fix_fstring_match, code)
        
        # Additional pattern for logger.debug(f"...{# TODO...}")
        logger_pattern = r'(logger\.[a-z]+\(f"[^"]*\{)(#[^}]*\{[^}]*\})'
        fixed_code = re.sub(logger_pattern, r'\1extracted_info}', fixed_code)
        
        # Pattern for any f-string with {# TODO: Replace {var}}
        todo_pattern = r'\{# TODO: Replace \{([^}]+)\}\}'
        fixed_code = re.sub(todo_pattern, r'{\1}', fixed_code)
        
        # 🔧 추가: 괄호 매칭 문제 수정 (임시 비활성화)
        # fixed_code = self._fix_bracket_matching(fixed_code)
        
        if fixed_code != code:
            logger.info("🔧 Fixed f-string syntax errors")
        
        return fixed_code
    
    def _fix_bracket_matching(self, code: str) -> str:
        """괄호 매칭 문제 수정"""
        lines = code.split('\n')
        fixed_lines = []
        
        for i, line in enumerate(lines):
            # 중괄호가 홀수 개인 라인 감지
            open_braces = line.count('{')
            close_braces = line.count('}')
            
            # 만약 닫는 중괄호가 여는 중괄호보다 많으면
            if close_braces > open_braces:
                # 여분의 중괄호 제거
                excess = close_braces - open_braces
                # 라인 끝에서부터 여분의 } 제거
                for _ in range(excess):
                    line = line[::-1].replace('}', '', 1)[::-1]
                logger.info(f"🔧 라인 {i+1}: 여분의 중괄호 {excess}개 제거")
            
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _apply_all_automatic_fixes(self, code: str) -> str:
        """Apply all automatic fixes to ensure code works"""
        logger.info("🔧 Applying comprehensive automatic fixes...")
        
        # 1. Fix process method signature
        code = self._fix_process_method_signature(code)
        
        # 2. Fix f-string syntax errors
        code = self._fix_fstring_syntax(code)
        
        # 3. Fix common template issues
        code = self._fix_template_issues(code)
        
        # 4. Ensure proper imports
        code = self._ensure_proper_imports(code)
        
        logger.info(f"✅ All automatic fixes applied. Final code: {len(code)} chars")
        return code
    
    def _fix_template_issues(self, code: str) -> str:
        """Fix common template-related issues"""
        # Remove any remaining template variables
        import re
        
        # Fix unresolved template variables like {agent_class_name}
        code = re.sub(r'\{agent_class_name\}', 'GeneratedAgent', code)
        code = re.sub(r'\{agent_name\}', 'Generated Agent', code)
        code = re.sub(r'\{agent_description\}', 'Auto-generated agent', code)
        
        # Fix empty docstrings that cause indentation issues
        code = re.sub(r'"""\s*"""', '"""Auto-generated agent"""', code)
        
        # Fix TODO comments in f-strings more aggressively
        code = re.sub(r'f"([^"]*)\{# TODO[^}]*\{([^}]+)\}[^}]*\}([^"]*)"', r'f"\1{\2}\3"', code)
        
        return code
    
    def _ensure_proper_imports(self, code: str) -> str:
        """Ensure all necessary imports are present"""
        required_imports = [
            "from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType",
            "from typing import Dict, Any, Optional",
            "from datetime import datetime",
            "import json"
        ]
        
        # Check if imports are missing and add them
        for import_line in required_imports:
            if import_line not in code:
                code = import_line + "\n" + code
        
        return code
    
    def _fix_process_method_signature(self, code: str) -> str:
        """Fix process method signature to match wrapper.py expectations"""
        import re
        
        logger.info("🔧 Fixing process method signature for wrapper compatibility")
        
        # Pattern 1: async def process(self, request: Dict[str, Any])
        pattern1 = r'async def process\(self,\s*request[^)]*\)\s*->\s*AgentResponse:'
        replacement1 = 'async def process(self, query: str, context: Dict[str, Any] = None) -> AgentResponse:'
        
        if re.search(pattern1, code):
            logger.info("📝 Found pattern: process(self, request: Dict[str, Any])")
            code = re.sub(pattern1, replacement1, code)
            
            # Also fix the request usage inside the method
            # Change: query = request.get("query", "")
            code = re.sub(r'query\s*=\s*request\.get\(["\']query["\'],\s*["\']["\']\)', 'pass  # query already provided as parameter', code)
            
            # Change: if not query:
            # (This should already be correct)
            
            logger.info("✅ Fixed process method signature and request usage")
        
        # Pattern 2: async def process(self, request)
        pattern2 = r'async def process\(self,\s*request\)\s*->\s*AgentResponse:'
        if re.search(pattern2, code):
            logger.info("📝 Found pattern: process(self, request)")
            code = re.sub(pattern2, replacement1, code)
            logger.info("✅ Fixed basic process method signature")
        
        # Pattern 3: process(self, request) without type hints
        pattern3 = r'async def process\(self,\s*request\):'
        replacement3 = 'async def process(self, query: str, context: Dict[str, Any] = None):'
        if re.search(pattern3, code):
            logger.info("📝 Found pattern: process(self, request) without types")
            code = re.sub(pattern3, replacement3, code)
            logger.info("✅ Fixed process method signature without types")
        
        return code
    
    async def _test_and_fix_code(self, code: str, analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Test code and fix errors automatically"""
        
        self.fix_attempts = 0
        current_code = code
        
        while self.fix_attempts < self.max_fix_attempts:
            await self._stream_event(
                callback,
                StreamEventType.TEST_START,
                f"🧪 코드 실행 테스트 중... (시도 {self.fix_attempts + 1}/{self.max_fix_attempts})",
                {"progress": 93 + self.fix_attempts * 2}
            )
            
            # Test execution
            test_result = await self.sandbox.execute(
                code=current_code,
                input_data={},
                timeout=30
            )
            
            if test_result.success:
                await self._stream_event(
                    callback,
                    StreamEventType.TEST_SUCCESS,
                    "✅ 실행 테스트 성공!",
                    {
                        "progress": 98,
                        "output_preview": test_result.output[:300] if test_result.output else "",
                        "execution_time": test_result.execution_time_ms
                    }
                )
                return current_code
            
            # Error occurred
            await self._stream_event(
                callback,
                StreamEventType.TEST_ERROR,
                f"❌ 에러 발생: {self._classify_error(test_result.stderr)}",
                {
                    "progress": 94 + self.fix_attempts * 2,
                    "error_type": self._classify_error(test_result.stderr),
                    "error_detail": test_result.stderr[:500],
                    "attempt": self.fix_attempts + 1
                }
            )
            
            # Fix error
            current_code = await self._fix_error(current_code, test_result, analysis, callback)
            self.fix_attempts += 1
        
        # If we get here, we couldn't fix all errors
        logger.warning(f"Could not fix all errors after {self.max_fix_attempts} attempts")
        return current_code
    
    async def _fix_error(self, code: str, test_result: ExecutionResult, 
                        analysis: QueryAnalysis, callback: Optional[Callable]) -> str:
        """Fix specific error in code"""
        
        error_type = self._classify_error(test_result.stderr)
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_START,
            f"🔧 {error_type} 수정을 시작합니다...",
            {"error_type": error_type}
        )
        
        # Error-specific fixes
        if error_type == "SecurityError":
            fixed_code = await self._fix_security_error(code, test_result.stderr, callback)
        elif error_type == "ImportError":
            fixed_code = await self._fix_import_error(code, test_result.stderr, callback)
        elif error_type == "NameError":
            fixed_code = await self._fix_name_error(code, test_result.stderr, callback)
        elif error_type == "SyntaxError":
            fixed_code = await self._fix_syntax_error(code, test_result.stderr, callback)
        elif error_type == "TypeError":
            fixed_code = await self._fix_type_error(code, test_result.stderr, callback)
        else:
            # General LLM fix
            fixed_code = await self._llm_fix_error(code, test_result.stderr, callback)
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_COMPLETE,
            "✅ 에러 수정 완료",
            {"progress": 95 + self.fix_attempts}
        )
        
        return fixed_code
    
    async def _fix_security_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix security violation errors by removing blocked imports and operations"""
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "🔒 보안 위반 사항을 분석하고 있습니다...",
            {"fix_type": "security"}
        )
        
        # Parse security violations from error message
        violations = []
        for line in error.split('\n'):
            if 'Blocked import:' in line or 'Blocked operation:' in line:
                violations.append(line.strip())
        
        # Remove blocked imports
        lines = code.split('\n')
        fixed_lines = []
        
        for line in lines:
            skip_line = False
            
            # Check for blocked imports
            if line.strip().startswith('import ') or line.strip().startswith('from '):
                for violation in violations:
                    if 'Blocked import:' in violation:
                        blocked_module = violation.split('Blocked import:')[1].strip()
                        if blocked_module in line:
                            skip_line = True
                            await self._stream_event(
                                callback,
                                StreamEventType.FIX_APPLYING,
                                f"🚫 제거: {line.strip()}",
                                {"action": "remove_import", "module": blocked_module}
                            )
                            break
            
            # Check for blocked operations
            if not skip_line:
                for violation in violations:
                    if 'Blocked operation:' in violation:
                        blocked_op = violation.split('Blocked operation:')[1].strip()
                        if blocked_op in line:
                            # Comment out instead of removing completely
                            line = f"# SECURITY: {line.strip()} # Blocked operation"
                            await self._stream_event(
                                callback,
                                StreamEventType.FIX_APPLYING,
                                f"🔒 비활성화: {blocked_op}",
                                {"action": "disable_operation", "operation": blocked_op}
                            )
            
            if not skip_line:
                fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    async def _fix_import_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix import errors by adding missing imports"""
        
        # Extract missing module
        import_match = re.search(r"No module named '(\w+)'", error)
        if import_match:
            module = import_match.group(1)
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_APPLYING,
                f"📦 누락된 모듈 추가: {module}",
                {"fix_type": "add_import", "module": module}
            )
            
            # Add import at the beginning
            import_line = f"import {module}\n"
            if f"import {module}" not in code:
                # Find the right place to add import
                lines = code.split('\n')
                import_index = 0
                for i, line in enumerate(lines):
                    if line.startswith('from logosai'):
                        import_index = i + 1
                        break
                
                lines.insert(import_index, import_line)
                return '\n'.join(lines)
        
        return code
    
    async def _fix_name_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix undefined variable errors"""
        
        # Extract undefined name
        name_match = re.search(r"name '(\w+)' is not defined", error)
        if name_match:
            var_name = name_match.group(1)
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_APPLYING,
                f"🔤 미정의 변수 초기화: {var_name}",
                {"fix_type": "define_variable", "variable": var_name}
            )
            
            # Common fixes
            if var_name == 'np':
                return code.replace('import numpy', 'import numpy as np')
            elif var_name == 'pd':
                return code.replace('import pandas', 'import pandas as pd')
            
            # Add initialization
            init_line = f"        {var_name} = None  # Auto-fixed\n"
            init_marker = "def __init__(self"
            if init_marker in code:
                lines = code.split('\n')
                for i, line in enumerate(lines):
                    if init_marker in line:
                        # Find the end of __init__
                        j = i + 1
                        while j < len(lines) and lines[j].startswith('        '):
                            j += 1
                        lines.insert(j - 1, init_line)
                        return '\n'.join(lines)
        
        return code
    
    async def _fix_syntax_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """최우선 에러 수정 - JSON 혼입 문제 완전 해결"""
        
        # 🚨 임시 완화: 비상 템플릿 조건을 극도로 완화하여 실제 에이전트 생성 허용
        
        # 1. 코드 길이 제한 대폭 완화 (15000 → 50000)
        if len(code) > 50000:
            logger.error(f"🚨 CRITICAL: Code extremely long ({len(code)} chars) - using emergency template")
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_ANALYZING,
                "🚨 극도로 긴 코드 감지 - 비상 템플릿 사용",
                {"fix_type": "emergency_long_code", "code_length": len(code)}
            )
            
            return self._get_emergency_minimal_agent()
        
        # 2. JSON 혼입 감지를 극도로 엄격하게 (실제 심각한 경우만)
        # 코드 시작 부분에서만 체크 (처음 100자)
        # 단, docstring이나 주석으로 시작하는 경우는 제외
        code_start = code[:100] if len(code) > 100 else code
        
        # docstring이나 주석으로 시작하는 경우는 정상적인 코드
        is_normal_start = (
            code_start.strip().startswith('"""') or 
            code_start.strip().startswith("'''") or
            code_start.strip().startswith('#') or
            code_start.strip().startswith('from ') or
            code_start.strip().startswith('import ')
        )
        
        critical_contamination_patterns = [
            '{"code": "from logosai',    # 정말 JSON으로 감싸진 코드
            'exec("""from logosai',      # exec으로 감싸진 코드
            '```json\n{"code":',         # 마크다운 JSON 블록
        ]
        
        # 정상적인 시작이 아닌 경우에만 패턴 체크
        is_critically_contaminated = False
        if not is_normal_start:
            is_critically_contaminated = any(pattern in code_start for pattern in critical_contamination_patterns)
        # unterminated string literal은 일반적인 문법 오류로 처리 가능
        # JSON contamination과 함께 발생한 경우에만 심각한 오류로 간주
        has_severe_string_error = False
        if 'unterminated string literal' in str(error):
            # JSON contamination과 함께 발생한 경우에만 심각한 오류
            has_severe_string_error = is_critically_contaminated
        
        if (is_critically_contaminated and has_severe_string_error):
            
            logger.error(f"🚨 CRITICAL: Critical JSON contamination detected - using emergency template")
            logger.error(f"🚨 Contamination details: {critical_contamination_patterns}")
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_ANALYZING,
                "🚨 심각한 JSON 혼입 감지 - 비상 템플릿 사용",
                {"fix_type": "emergency_critical_contamination", "patterns": critical_contamination_patterns}
            )
            
            return self._get_emergency_minimal_agent()
        
        # 🎯 새로운 접근: 비상 템플릿 대신 적극적 수정 시도
        logger.info("🔧 비상 템플릿 조건 통과 - 적극적 에러 수정 시도")
        
        # 기존 에러 수정 로직
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "📝 스마트 에러 분석 중...",
            {"fix_type": "smart_analysis"}
        )
        
        # 우선순위 1: 템플릿 변수 문제 즉시 해결
        if any(var in str(error) for var in ['agent_class_name', 'custom_config', 'core_business_logic', '{', '}']):
            logger.info("🔧 Template variable error detected, applying immediate fixes")
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_ANALYZING,
                "🔧 템플릿 변수 에러 즉시 수정 중...",
                {"fix_type": "template_emergency"}
            )
            
            # 즉시 템플릿 변수 치환
            template_fixes = {
                '{agent_class_name}': 'GeneratedAgent',
                '{agent_name}': 'Generated Agent', 
                '{agent_description}': 'Auto-generated agent',
                '{agent_type}': 'CUSTOM',
                '{custom_config}': 'dict(timeout=60, retry_attempts=3)',
                '{custom_init}': '# Custom initialization',
                '{core_business_logic}': 'pass  # Business logic placeholder',
                '{sample_data}': 'dict(sample="data")',
                '{test_queries}': '["test query"]'
            }
            
            fixed_code = code
            for var, replacement in template_fixes.items():
                if var in fixed_code:
                    fixed_code = fixed_code.replace(var, replacement)
                    logger.info(f"🔧 Emergency fix: {var} → {replacement[:30]}...")
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_ANALYZING,
                "✅ 템플릿 변수 에러 수정 완료!",
                {"fix_type": "template_success"}
            )
            
            return fixed_code
        
        # 우선순위 2: 들여쓰기 에러 즉시 해결 (더 강력한 감지)
        if ("IndentationError" in str(error) or 
            "expected an indented block" in str(error) or
            "unindent does not match" in str(error) or
            ('"""' in code and "function definition" in str(error))):
            
            logger.error("🚨 CRITICAL: Indentation error detected - using emergency template")
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_ANALYZING,
                "🚨 들여쓰기 에러 감지 - 비상 템플릿 사용",
                {"fix_type": "emergency_indentation", "error": str(error)[:100]}
            )
            
            # 들여쓰기 에러는 너무 복잡하므로 즉시 비상 템플릿 사용
            return self._get_emergency_minimal_agent()
        
        # 우선순위 3: JSON 응답 혼입 문제 해결 (더 강력한 감지)
        if ('"code":' in code or 'exec("""' in code or '"code"' in code or 
            'unterminated string literal' in str(error) or 
            len(code) > 10000):  # 비정상적으로 긴 코드도 JSON 혼입 의심
            
            logger.info("🔧 JSON contamination detected, applying aggressive cleaning")
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_ANALYZING,
                "🧹 JSON 혼입 코드 강력 정리 중...",
                {"fix_type": "aggressive_cleanup"}
            )
            
            # 강력한 JSON 제거 로직
            cleaned_code = self._aggressive_json_cleanup(code)
            
            await self._stream_event(
                callback,
                StreamEventType.FIX_ANALYZING,
                "✅ 강력 정리 완료!",
                {"fix_type": "aggressive_success"}
            )
            
            return cleaned_code
        
        # Enhanced LLM fallback with better prompts
        return await self._enhanced_llm_fix(code, error, callback)
    
    async def _enhanced_llm_fix(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Enhanced LLM-based error fixing with improved prompts"""
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "🤖 고급 AI 에러 수정 중...",
            {"fix_type": "enhanced_llm"}
        )
        
        # Extract line number and context
        line_match = re.search(r"line (\d+)", error)
        if line_match:
            line_num = int(line_match.group(1))
            lines = code.split('\n')
            
            # Get more context for better understanding
            start = max(0, line_num - 8)
            end = min(len(lines), line_num + 8)
            
            # Create numbered context
            context_lines = []
            for i in range(start, end):
                if i < len(lines):
                    marker = " >>> ERROR" if i + 1 == line_num else "    "
                    context_lines.append(f"{i+1:3d}{marker} {lines[i]}")
            
            context = '\n'.join(context_lines)
            
            # Enhanced error-specific prompt
            enhanced_prompt = f"""You are a Python expert. Fix this syntax error with precision.

ERROR: {error}

CODE CONTEXT (error on line {line_num} marked with >>> ERROR):
{context}

CRITICAL REQUIREMENTS:
1. Analyze the error type carefully
2. If it's template variables like {{agent_class_name}}, replace with actual values
3. If it's unterminated strings, add proper closing quotes
4. If it's indentation, fix the spacing
5. Return ONLY the corrected lines {start+1}-{end}
6. Maintain exact indentation and structure
7. Don't add explanations

COMMON FIXES:
- {{agent_class_name}} → GeneratedAgent
- {{agent_name}} → "Generated Agent"
- {{custom_config}} → {{"timeout": 60}}
- Unterminated strings → add closing quotes
- Missing colons → add : at line end
- Wrong indentation → fix spaces/tabs

Fixed code (lines {start+1}-{end} only):"""

            try:
                result = await self.llm.generate(
                        prompt=enhanced_prompt,
                    task_type=TaskType.CODE_GENERATION,
                        max_tokens=1000,
                    temperature=0.1
                )
            
                # Extract and apply fixes
                fixed_context = self._extract_code_from_llm(result)
                fixed_lines = fixed_context.split('\n')
                
                # Apply the fixes to original code
                for i, fixed_line in enumerate(fixed_lines):
                    if start + i < len(lines):
                        lines[start + i] = fixed_line
                
                return '\n'.join(lines)
        
            except Exception as e:
                logger.error(f"Enhanced LLM fix failed: {e}")
        
        # Last resort: try to fix common issues automatically
        return self._apply_emergency_fixes(code, error)
    
    def _extract_code_from_llm(self, response: str) -> str:
        """Extract code from LLM response"""
        # Remove code block markers if present
        if '```' in response:
            match = re.search(r'```(?:python)?\n(.*?)\n```', response, re.DOTALL)
            if match:
                return match.group(1)
        
        # Clean up response
        lines = response.strip().split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Remove line numbers and markers
            cleaned = re.sub(r'^\s*\d+\s*[>]*\s*(?:ERROR)?\s*', '', line)
            cleaned_lines.append(cleaned)
        
        return '\n'.join(cleaned_lines)
    
    def _apply_emergency_fixes(self, code: str, error: str) -> str:
        """Apply emergency fixes for common issues"""
        
        # Fix template variables with context-aware replacements
        template_fixes = {
            '{agent_class_name}': 'GeneratedAgent',
            '{agent_name}': 'Generated Agent',
            '{agent_description}': 'Auto-generated agent',
            '{agent_type}': 'CUSTOM',
            '{custom_config}': '"timeout": 60, "retry_attempts": 3',  # No braces for config
            '{custom_init}': '# Custom initialization',
            '{custom_async_init}': '# Async initialization',
            '{core_business_logic}': 'pass  # Business logic placeholder'
        }
        
        fixed_code = code
        for template_var, replacement in template_fixes.items():
            if template_var in fixed_code:
                fixed_code = fixed_code.replace(template_var, replacement)
                logger.info(f"Emergency fix: {template_var} → {replacement}")
        
        # Fix common string issues
        if "unterminated" in error.lower():
            lines = fixed_code.split('\n')
            for i, line in enumerate(lines):
                if '"""' in line and line.count('"""') % 2 == 1:
                    # Add closing triple quotes
                    if i + 1 < len(lines):
                        lines.insert(i + 1, '    """')
                        logger.info(f"Emergency fix: Added closing quotes after line {i + 1}")
                        break
            fixed_code = '\n'.join(lines)
        
        return fixed_code
    
    def _fix_indentation_immediate(self, code: str, error: str) -> str:
        """들여쓰기 에러 즉시 수정 - 강화된 버전"""
        
        logger.info(f"🔧 Fixing indentation error: {error[:100]}...")
        
        # 라인 번호 추출
        import re
        line_match = re.search(r"line (\d+)", str(error))
        if not line_match:
            return self._comprehensive_indentation_fix(code)
            
        line_num = int(line_match.group(1))
        lines = code.split('\n')
        
        if line_num > len(lines):
            return self._comprehensive_indentation_fix(code)
        
        # 강화된 들여쓰기 수정
        fixed = False
        
        # 1. 문제 라인 주변 검사 (더 넓은 범위)
        for i in range(max(0, line_num - 3), min(len(lines), line_num + 8)):
            if i >= len(lines):
                continue
                
            line = lines[i]
            stripped = line.strip()
            
            # Case 1: 빈 docstring 수정
            if stripped == '"""' and i > 0:
                prev_line = lines[i-1].strip()
                if (prev_line.endswith(':') and 
                    any(keyword in prev_line for keyword in ['def ', 'class ', 'if ', 'for ', 'while ', 'try', 'except', 'else', 'elif'])):
                    
                    # 적절한 들여쓰기로 pass 추가
                    indent_level = len(lines[i-1]) - len(lines[i-1].lstrip()) + 4
                    lines[i] = ' ' * indent_level + 'pass'
                    logger.info(f"🔧 Fixed empty docstring at line {i+1}: replaced with 'pass'")
                    fixed = True
                    break
            
            # Case 2: 함수/클래스 정의 후 빈 라인
            elif stripped == '' and i > 0:
                prev_line = lines[i-1].strip()
                if (prev_line.endswith(':') and 
                    any(keyword in prev_line for keyword in ['def ', 'class ', 'async def ', 'if ', 'for ', 'while ', 'try:', 'except', 'with '])):
                    
                    # 적절한 들여쓰기로 pass 추가
                    indent_level = len(lines[i-1]) - len(lines[i-1].lstrip()) + 4
                    lines[i] = ' ' * indent_level + 'pass'
                    logger.info(f"🔧 Added 'pass' at line {i+1} with {indent_level} spaces")
                    fixed = True
                    break
            
            # Case 3: 함수 정의 후 잘못된 들여쓰기
            elif i > 0 and lines[i-1].strip().endswith(':') and any(keyword in lines[i-1] for keyword in ['def ', 'class ', 'if ', 'for ']):
                if stripped and not line.startswith(' '):
                    # 들여쓰기가 없는 경우
                    indent_level = len(lines[i-1]) - len(lines[i-1].lstrip()) + 4
                    lines[i] = ' ' * indent_level + stripped
                    logger.info(f"🔧 Fixed indentation at line {i+1}")
                    fixed = True
                    break
        
        # 2. 수정되지 않았으면 포괄적 수정 적용
        if not fixed:
            return self._comprehensive_indentation_fix(code)
        
        result = '\n'.join(lines)
        
        # 3. 수정 후 검증
        try:
            import ast
            ast.parse(result)
            logger.info("✅ Indentation fix successful - syntax valid")
            return result
        except SyntaxError as e:
            logger.warning(f"Indentation fix failed validation: {e}")
            return self._comprehensive_indentation_fix(code)
    
    def _comprehensive_indentation_fix(self, code: str) -> str:
        """포괄적 들여쓰기 수정 - 전체 코드 재구성"""
        
        logger.info("🔨 Applying comprehensive indentation fix")
        
        lines = code.split('\n')
        fixed_lines = []
        indent_stack = [0]  # 들여쓰기 레벨 스택
        
        for i, line in enumerate(lines):
            stripped = line.strip()
            
            if not stripped:
                fixed_lines.append('')
                continue
            
            current_indent = indent_stack[-1]
            
            # 블록 시작 키워드 감지
            if any(stripped.startswith(keyword) for keyword in ['class ', 'def ', 'async def ']):
                if stripped.startswith('class '):
                    current_indent = 0
                else:
                    # 함수는 클래스 내부면 4, 아니면 0
                    current_indent = 4 if any('class ' in prev_line for prev_line in fixed_lines[-10:] if prev_line.strip()) else 0
                
                fixed_lines.append(' ' * current_indent + stripped)
                
                if stripped.endswith(':'):
                    indent_stack.append(current_indent + 4)
                    # 다음 라인이 비어있거나 docstring만 있으면 pass 추가
                    if (i + 1 < len(lines) and 
                        (not lines[i + 1].strip() or lines[i + 1].strip() == '"""')):
                        fixed_lines.append(' ' * (current_indent + 4) + 'pass')
            
            # 제어 구조 키워드
            elif any(stripped.startswith(keyword) for keyword in ['if ', 'for ', 'while ', 'try:', 'with ', 'except', 'else:', 'elif']):
                fixed_lines.append(' ' * current_indent + stripped)
                if stripped.endswith(':'):
                    indent_stack.append(current_indent + 4)
            
            # 블록 끝 감지 (return, pass, break, continue)
            elif any(stripped.startswith(keyword) for keyword in ['return ', 'pass', 'break', 'continue', 'raise ']):
                fixed_lines.append(' ' * current_indent + stripped)
                # 스택에서 들여쓰기 레벨 제거
                if len(indent_stack) > 1:
                    indent_stack.pop()
            
            # 일반 문장
            else:
                fixed_lines.append(' ' * current_indent + stripped)
        
        result = '\n'.join(fixed_lines)
        
        # 최종 검증
        try:
            import ast
            ast.parse(result)
            logger.info("✅ Comprehensive indentation fix successful")
            return result
        except SyntaxError as e:
            logger.error(f"Comprehensive fix failed: {e}")
            # 최후의 수단: 비상 템플릿
            return self._get_emergency_minimal_agent()
    
    def _aggressive_json_cleanup(self, code: str) -> str:
        """JSON 혼입 코드 강력 정리"""
        
        logger.info("🧹 Applying aggressive JSON cleanup")
        
        # 1. JSON 객체 패턴 제거
        import re
        
        # {"code": "..."} 패턴 완전 제거
        code = re.sub(r'\{"code":\s*"[^"]*"[^}]*\}', '', code, flags=re.DOTALL)
        
        # exec(""" 패턴 제거
        code = re.sub(r'exec\(""".*?"""\)', '', code, flags=re.DOTALL)
        code = re.sub(r'exec\(".*?"\)', '', code, flags=re.DOTALL)
        
        # 비정상적으로 긴 문자열 리터럴 제거
        lines = code.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # 200자 이상의 라인은 의심스러움
            if len(line) > 200 and ('"' in line or "'" in line):
                logger.info(f"🗑️ Removing suspicious long line: {line[:50]}...")
                continue
            
            # JSON 같은 패턴 제거 (더 정확한 패턴 매칭)
            if ('"code":' in line and '{' in line) or ('"timeout":' in line and ',' in line):
                logger.info(f"🗑️ Removing JSON pattern line: {line[:50]}...")
                continue
            
            cleaned_lines.append(line)
        
        cleaned_code = '\n'.join(cleaned_lines)
        
        # 2. 기본 에이전트 구조가 있는지 확인
        if not self._has_basic_agent_structure(cleaned_code):
            logger.warning("No basic agent structure found, using emergency template")
            return self._get_emergency_agent_code()
        
        return cleaned_code
    
    def _has_basic_agent_structure(self, code: str) -> bool:
        """기본 에이전트 구조 확인"""
        
        required_elements = [
            'LogosAIAgent',
            'class ',
            'def __init__',
            'def process' 
        ]
        
        return all(element in code for element in required_elements)
    
    def _get_emergency_agent_code(self) -> str:
        """비상 에이전트 코드"""
        
        return '''from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType

class EmergencyAgent(LogosAIAgent):
    """Emergency agent due to code generation failure"""
    
    def __init__(self, config=None):
        if config is None:
            config = AgentConfig(
                name="Emergency Agent",
                agent_type=AgentType.CUSTOM,
                config={"timeout": 60, "retry_attempts": 3}
            )
        super().__init__(config)
        self.initialized = True
    
    async def initialize(self):
        """Initialize the agent"""
        await super().initialize()
        logger.info("Emergency agent initialized")
    
    async def process(self, query: str, context=None):
        """Emergency processing logic"""
        if not query:
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={"error": "No query provided"}
            )
        
        # Basic processing
        result = {
            "status": "emergency_processed",
            "input": query,
            "message": "Processed by emergency agent due to generation failure",
            "timestamp": str(datetime.now())
        }
        
        return AgentResponse(
            type=AgentResponseType.JSON,
            content=result
        )

# Test function
async def main():
    agent = EmergencyAgent()
    await agent.initialize()
    test_request = {"test": "data", "emergency": True}
    result = await agent.process(test_request)
    print(f"Emergency agent result: {result}")

if __name__ == "__main__":
    import asyncio
    from datetime import datetime
    from loguru import logger
    asyncio.run(main())
'''
    
    def _get_emergency_minimal_agent(self) -> str:
        """최소한의 작동하는 에이전트 - JSON 혼입 문제 해결"""
        
        return '''from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType

class MinimalWorkingAgent(LogosAIAgent):
    """최소한의 작동하는 에이전트 - 긴급 상황용"""
    
    def __init__(self, config=None):
        if config is None:
            config = AgentConfig(
                name="Minimal Working Agent",
                agent_type=AgentType.CUSTOM,
                config={"timeout": 30, "retry_attempts": 2}
            )
        super().__init__(config)
        self.processed_count = 0
    
    async def initialize(self):
        """에이전트 초기화"""
        await super().initialize()
        logger.info("Minimal working agent initialized successfully")
    
    async def process(self, query: str, context=None):
        """기본 처리 로직"""
        self.processed_count += 1
        
        if not query:
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={"error": "No query provided", "agent": "minimal"}
            )
        
        # 간단한 처리
        result = {
            "status": "processed_successfully",
            "input_received": query,
            "processed_by": "MinimalWorkingAgent", 
            "processing_count": self.processed_count,
            "timestamp": str(datetime.now()),
            "success": True
        }
        
        return AgentResponse(
            type=AgentResponseType.JSON,
            content=result
        )

# 테스트 실행
async def main():
    agent = MinimalWorkingAgent()
    await agent.initialize()
    
    # 테스트 요청들
    test_requests = [
        {"action": "test", "data": "sample"},
        {"query": "process this", "type": "test"},
        None  # 에러 케이스 테스트
    ]
    
    for i, req in enumerate(test_requests):
        try:
            result = await agent.process(req)
            print(f"Test {i+1} result: {result}")
        except Exception as e:
            print(f"Test {i+1} error: {e}")

if __name__ == "__main__":
    import asyncio
    from datetime import datetime
    from loguru import logger
    
    print("🔥 Minimal Working Agent - Emergency Template")
    asyncio.run(main())
'''
    
    def _fix_template_variables(self, code: str) -> str:
        """Fix unsubstituted template variables with default values"""
        
        # 기본값으로 치환
        default_replacements = {
            'agent_class_name': 'GeneratedAgent',
            'agent_name': 'Generated Agent',
            'agent_description': 'Auto-generated agent',
            'agent_type': 'CUSTOM',
            'custom_config': '{"timeout": 60, "retry_attempts": 3}',
            'custom_init': '# Custom initialization',
            'custom_async_init': '# Async initialization',
            'core_business_logic': '# Business logic placeholder',
            'initialization': '# Initialization code',
            'sample_data': '# Sample data placeholder',
            'test_queries': '# Test queries placeholder'
        }
        
        # 치환되지 않은 템플릿 변수 찾기
        template_vars = re.findall(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}', code)
        
        fixed_code = code
        for var in template_vars:
            placeholder = f'{{{var}}}'
            replacement = default_replacements.get(var, f'# TODO: Replace {placeholder}')
            
            if placeholder in fixed_code:
                logger.info(f"  Replacing {placeholder} with: {replacement[:50]}...")
                
                # 다중 줄 코드 블록의 들여쓰기 처리
                if '\n' in replacement and var in ['custom_init', 'core_business_logic', 'initialization']:
                    lines = fixed_code.split('\n')
                    for i, line in enumerate(lines):
                        if placeholder in line:
                            # 해당 라인의 들여쓰기 감지
                            indent_match = re.match(r'^(\s*)', line)
                            base_indent = indent_match.group(1) if indent_match else ''
                            
                            # 치환값에 들여쓰기 적용
                            replacement_lines = replacement.split('\n')
                            indented_lines = []
                            for j, repl_line in enumerate(replacement_lines):
                                if j == 0:
                                    indented_lines.append(repl_line)
                                else:
                                    indented_lines.append(base_indent + repl_line if repl_line.strip() else repl_line)
                            
                            replacement = '\n'.join(indented_lines)
                            break
                
                fixed_code = fixed_code.replace(placeholder, replacement)
        
        return fixed_code
    
    async def _fix_type_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Fix type errors"""
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "🔢 타입 오류 분석 중...",
            {"fix_type": "type_error"}
        )
        
        return await self._llm_fix_error(code, error, callback)
    
    async def _llm_fix_error(self, code: str, error: str, callback: Optional[Callable]) -> str:
        """Use LLM to fix any error with higher token limit"""
        
        await self._stream_event(
            callback,
            StreamEventType.FIX_ANALYZING,
            "🤖 AI가 에러를 분석하고 있습니다...",
            {"fix_type": "llm_analysis"}
        )
        
        prompt = f"""Fix this Python error in the agent code:

Error:
{error}

IMPORTANT: The code MUST be complete and not truncated. Return the ENTIRE fixed code.

Code to fix:
{code}

Requirements:
1. Fix the error completely
2. Return the COMPLETE fixed code
3. Do not truncate or shorten the code
4. Maintain all existing functionality

Return the complete fixed code:"""

        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=self.token_limits['fix_general'],
            temperature=0.3
        )
        
        # Extract code
        fixed_code = self._extract_code(result)
        
        # Verify the code is not truncated
        if len(fixed_code) < len(code) * 0.8:
            logger.warning("Fixed code seems truncated, keeping original")
            return code
        
        return fixed_code
    
    def _generate_english_class_name(self, analysis: QueryAnalysis) -> str:
        """Generate valid English class name"""
        
        domain = (analysis.domain or "").lower()
        intent = (analysis.intent or "").lower()
        
        # Domain-based naming
        if "financial" in domain or "finance" in domain or "risk" in intent:
            base_name = "FinancialRisk"
        elif "customer" in domain or "customer" in intent:
            base_name = "CustomerAnalysis"
        elif "api" in domain or "api" in intent:
            base_name = "ApiData"
        elif "data" in domain or "analysis" in intent:
            base_name = "DataAnalysis"
        elif "web" in domain or "scraping" in intent:
            base_name = "WebScraper"
        elif "monitoring" in intent:
            base_name = "SystemMonitor"
        else:
            # Use first capability
            if analysis.required_capabilities:
                first_cap = analysis.required_capabilities[0]
                words = first_cap.replace('_', ' ').split()
                base_name = ''.join(word.capitalize() for word in words)
            else:
                base_name = "Custom"
        
        return f"{base_name}Agent"
    
    def _generate_config_dict(self, analysis: QueryAnalysis) -> str:
        """Generate configuration dictionary with proper token limits"""
        
        # Determine appropriate model based on complexity
        if analysis.complexity.value == "expert":
            model = "gpt-4-turbo-preview"
            tokens = 16000  # Increased from 8000
        elif analysis.complexity.value == "intermediate":
            model = "gpt-3.5-turbo"
            tokens = 8000   # Increased from 4000
        else:
            model = "gpt-3.5-turbo"
            tokens = 4000   # Increased from 2000
        
        return f"""{{
    "model": "{model}",
    "temperature": 0.7,
    "max_tokens": {tokens},
    "timeout": 30,
    "retry_attempts": 3,
    "cache_enabled": True
}}"""
    
    def _extract_code(self, response: str) -> str:
        """Extract clean code from LLM response with comprehensive debugging"""
        
        # 🔍 DEBUG: 코드 추출 과정 분석
        logger.info("🔍 CODE EXTRACTION ANALYSIS:")
        logger.info(f"📝 Input response length: {len(response)} chars")
        code_check = '{"code":'
        logger.info(f"📝 Contains '{code_check}': {'Yes' if code_check in response else 'No'}")
        logger.info(f"📝 Contains 'exec(': {'Yes' if 'exec(' in response else 'No'}")
        logger.info(f"📝 Contains '```python': {'Yes' if '```python' in response else 'No'}")
        
        original_response = response
        
        # 🚨 Priority 1: Check for JSON contamination and clean it
        if code_check in response or 'exec("""' in response:
            logger.warning("🚨 JSON contamination detected in _extract_code, applying UniversalCodeParser")
            try:
                # Import and use UniversalCodeParser
                import sys
                sys.path.append(str(Path(__file__).parent))
                from universal_code_parser import UniversalCodeParser
                
                parser = UniversalCodeParser()
                cleaned_response = parser.parse(response)
                
                if cleaned_response and len(cleaned_response.strip()) > 50:
                    logger.info("✅ UniversalCodeParser successfully cleaned JSON contamination")
                    response = cleaned_response
                else:
                    logger.error("❌ UniversalCodeParser failed, proceeding with original")
            except Exception as e:
                logger.error(f"❌ UniversalCodeParser error: {e}")
        
        # Try to extract from code blocks
        python_match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        if python_match:
            code = python_match.group(1).strip()
            logger.info("✅ Extracted from ```python block")
        else:
            code_match = re.search(r'```\n(.*?)```', response, re.DOTALL)
            if code_match:
                code = code_match.group(1).strip()
                logger.info("✅ Extracted from ``` block")
            else:
                # Return as is if no code blocks
                code = response.strip()
                logger.info("📝 No code blocks found, using raw response")
        
        # Remove any remaining backticks from the extracted code
        # This handles cases where LLM includes backticks inside the code
        code = re.sub(r'```python\s*\n?', '', code)
        code = re.sub(r'```py\s*\n?', '', code)
        code = re.sub(r'```\s*\n?', '', code)
        code = re.sub(r'\n?```', '', code)
        
        # Remove lines that only contain backticks
        lines = code.split('\n')
        cleaned_lines = []
        for line in lines:
            if line.strip() in ['```', '```python', '```py']:
                continue
            # Also remove backticks from within lines (if not in strings)
            if '```' in line and not ('"' in line.split('```')[0] or "'" in line.split('```')[0]):
                line = line.replace('```', '')
            cleaned_lines.append(line)
        
        final_code = '\n'.join(cleaned_lines).strip()
        
        # 🔍 DEBUG: 추출 결과 분석
        logger.info(f"📤 EXTRACTION RESULT:")
        logger.info(f"📤 Final code length: {len(final_code)} chars")
        logger.info(f"📤 Still contains JSON?: {'Yes' if code_check in final_code else 'No'}")
        logger.info(f"📤 Code preview: {final_code[:200]}...")
        
        # 🔍 DEBUG: Save extracted code for analysis
        debug_extracted_file = f"debug_extracted_code_{datetime.now().strftime('%H%M%S')}.py"
        try:
            with open(debug_extracted_file, 'w', encoding='utf-8') as f:
                f.write("# Extracted Code from LLM Response\n")
                f.write("# " + "="*50 + "\n")
                f.write(f"# Extracted at: {datetime.now()}\n")
                f.write("# " + "="*50 + "\n\n")
                f.write(final_code)
            logger.info(f"💾 Saved extracted code to: {debug_extracted_file}")
        except Exception as e:
            logger.error(f"Failed to save extracted debug file: {e}")
        
        return final_code
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by specified spaces"""
        if not code:
            return ""
        
        # Remove any code that's not properly formatted
        # This helps handle LLM responses that might include explanatory text
        cleaned_code = self._extract_code(code)
        
        indent = ' ' * spaces
        lines = cleaned_code.split('\n')
        return '\n'.join(indent + line if line.strip() else line for line in lines)
    
    def _classify_error(self, error: str) -> str:
        """Classify error type from error message"""
        
        if "Security violations detected" in error:
            return "SecurityError"
        elif "ImportError" in error or "No module named" in error:
            return "ImportError"
        elif "NameError" in error or "is not defined" in error:
            return "NameError"
        elif "SyntaxError" in error:
            return "SyntaxError"
        elif "TypeError" in error:
            return "TypeError"
        elif "AttributeError" in error:
            return "AttributeError"
        elif "ValueError" in error:
            return "ValueError"
        else:
            return "UnknownError"
    
    async def _stream_event(self, callback: Optional[Callable], event_type: StreamEventType,
                           message: str, data: Dict[str, Any] = None):
        """Send streaming event if callback is provided"""
        
        if callback:
            await callback(
                event_type.value,
                message,
                data or {}
            )
    
    def _create_artifacts(self, analysis: QueryAnalysis, start_time: datetime, final_code: str):
        """Create generation artifacts"""
        
        artifacts = GenerationArtifacts(
            generation_id=f"enhanced_gen_{datetime.now().timestamp()}",
            timestamp=start_time,
            original_query=analysis.query
        )
        
        artifacts.query_analysis = {
            "intent": analysis.intent,
            "domain": analysis.domain,
            "complexity": analysis.complexity.value,
            "capabilities": analysis.required_capabilities
        }
        
        artifacts.generated_code_raw = final_code
        artifacts.optimized_code = final_code
        artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return artifacts
    
    async def _generate_with_templates(self, analysis: QueryAnalysis, context: Context,
                                     stream_callback: Optional[Callable] = None) -> Any:
        """Generate agent code using template-based system"""
        
        start_time = datetime.now()
        
        try:
            # Start generation
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_START,
                "🚀 템플릿 기반 에이전트 생성을 시작합니다...",
                {"progress": 0, "total_stages": 5}
            )
            
            # 1. Select template
            await self._stream_event(
                stream_callback,
                StreamEventType.TEMPLATE_SELECTED,
                "📋 최적 템플릿 선택 중...",
                {"progress": 10}
            )
            
            # Create metadata for template selection
            metadata = {
                "category": self._map_domain_to_category(analysis.domain),
                "capabilities": analysis.required_capabilities
            }
            
            template_id, confidence = await self.template_generator.select_template(
                analysis.query, metadata
            )
            
            await self._stream_event(
                stream_callback,
                StreamEventType.TEMPLATE_SELECTED,
                f"✅ 템플릿 선택: {template_id} (신뢰도: {confidence:.0%})",
                {"progress": 20, "template": template_id, "confidence": confidence}
            )
            
            # 2. Generate business logic only
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATING_LOGIC,
                "💡 비즈니스 로직 생성 중...",
                {"progress": 40}
            )
            
            # Create LLM client wrapper for template generator
            class LLMClientWrapper:
                def __init__(self, llm_orchestrator):
                    self.llm = llm_orchestrator
                    
                async def invoke(self, prompt: str) -> str:
                    logger.debug(f"🤖 LLM invoke called with prompt length: {len(prompt)}")
                    
                    # Already using JSON format in template_based_generator prompts
                    response = await self.llm.generate(
                        TaskType.MAIN_LOGIC,
                        prompt,
                        max_tokens=3000
                    )
                    # Log response type and content
                    logger.debug(f"📥 LLM response type: {type(response)}")
                    
                    if hasattr(response, 'content'):
                        result = response.content
                        logger.debug(f"📝 Using response.content: {len(result)} chars")
                    else:
                        result = str(response)
                        logger.debug(f"📝 Using str(response): {len(result)} chars")
                    
                    return result
            
            llm_client = LLMClientWrapper(self.llm)
            
            # Generate using template system
            generated_code, generation_metadata = await self.template_generator.generate_agent_code(
                analysis.query,
                llm_client,
                metadata
            )
            
            await self._stream_event(
                stream_callback,
                StreamEventType.LOGIC_GENERATED,
                "✅ 비즈니스 로직 생성 완료",
                {"progress": 60}
            )
            
            # 3. Test the generated code
            await self._stream_event(
                stream_callback,
                StreamEventType.TEST_START,
                "🧪 생성된 코드 테스트 중...",
                {"progress": 70}
            )
            
            # Test and fix
            final_code = await self._test_and_fix_code(generated_code, analysis, stream_callback)
            
            # Complete
            total_time = (datetime.now() - start_time).total_seconds()
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_COMPLETE,
                f"✅ 템플릿 기반 에이전트 생성 완료! (총 {total_time:.1f}초)",
                {
                    "progress": 100,
                    "total_time": total_time,
                    "code_length": len(final_code),
                    "template_used": template_id,
                    "confidence": confidence
                }
            )
            
            # Create artifacts
            artifacts = self._create_artifacts(analysis, start_time, final_code)
            artifacts.template_metadata = generation_metadata
            
            # Return result
            class GeneratedCode:
                def __init__(self, code, artifacts, template_info):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = template_info["template_used"]
                    self.template_confidence = template_info["template_confidence"]
            
            return GeneratedCode(
                code=final_code,
                artifacts=artifacts,
                template_info=generation_metadata
            )
            
        except Exception as e:
            logger.error(f"Template-based generation failed: {e}")
            await self._stream_event(
                stream_callback,
                StreamEventType.GENERATION_FAILED,
                f"❌ 템플릿 기반 생성 실패: {str(e)}",
                {"error": str(e)}
            )
            # Fallback to original generation
            logger.info("Falling back to original generation method...")
            self.use_template_mode = False
            return await self.generate_progressively(analysis, context, stream_callback)
    
    def _map_domain_to_category(self, domain: str) -> str:
        """Map analysis domain to template category"""
        domain_mapping = {
            "data_analysis": "data_analysis",
            "web_scraping": "web_automation",
            "automation": "business_automation",
            "ai_ml": "ai_ml",
            "security": "security",
            "communication": "communication",
            "monitoring": "security",
            "document_processing": "business_automation"
        }
        
        if domain:
            domain_lower = domain.lower()
            for key, value in domain_mapping.items():
                if key in domain_lower:
                    return value
        
        return "general"