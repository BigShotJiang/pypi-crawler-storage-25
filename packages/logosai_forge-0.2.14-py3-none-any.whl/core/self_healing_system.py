"""
Self-Healing System for FORGE AI

자동으로 코드 에러를 감지하고 수정하는 시스템입니다.
LLM을 활용하여 구문 오류, 들여쓰기 오류 등을 자동으로 수정합니다.
"""

import re
import asyncio
import logging
from typing import Dict, Any, Optional, List, Tuple
from pathlib import Path
import tempfile
import ast
import json

logger = logging.getLogger(__name__)


class SelfHealingSystem:
    """자가 치유 시스템 - 코드 에러 자동 수정"""
    
    def __init__(self, llm_client=None):
        """
        자가 치유 시스템 초기화
        
        Args:
            llm_client: LLM 클라이언트 (없으면 기본값 사용)
        """
        self.llm_client = llm_client
        self.max_retry = 3
        self.success_history = []  # 성공한 수정 패턴 저장
        self.error_patterns = self._load_error_patterns()
        
        # LLM이 없으면 규칙 기반 수정만 사용
        self.use_llm = llm_client is not None
        
        logger.info("🏥 Self-Healing System initialized")
    
    def _load_error_patterns(self) -> Dict[str, Any]:
        """일반적인 에러 패턴과 해결 방법 로드"""
        return {
            'IndentationError': {
                'patterns': [
                    r'unindent does not match any outer indentation level',
                    r'expected an indented block',
                    r'unexpected indent'
                ],
                'solutions': [
                    'fix_indentation',
                    'normalize_indentation',
                    'remove_mixed_tabs_spaces'
                ]
            },
            'SyntaxError': {
                'patterns': [
                    r'invalid syntax',
                    r'EOL while scanning string literal',
                    r'unexpected EOF while parsing'
                ],
                'solutions': [
                    'fix_syntax',
                    'fix_string_literals',
                    'fix_brackets'
                ]
            },
            'ImportError': {
                'patterns': [
                    r'No module named',
                    r'cannot import name'
                ],
                'solutions': [
                    'fix_imports',
                    'add_missing_imports'
                ]
            }
        }
    
    async def heal_code(self, code: str, error_info: Dict[str, Any]) -> Tuple[bool, str]:
        """
        코드를 자동으로 수정
        
        Args:
            code: 에러가 있는 코드
            error_info: 에러 정보 (type, message, line_no 등)
            
        Returns:
            (성공 여부, 수정된 코드 또는 에러 메시지)
        """
        logger.info(f"🏥 Attempting to heal code with error: {error_info.get('message', 'Unknown')}")
        
        # 시도 횟수 제한
        for attempt in range(self.max_retry):
            logger.info(f"🔧 Healing attempt {attempt + 1}/{self.max_retry}")
            
            # 1단계: 규칙 기반 수정 시도
            success, fixed_code = self._rule_based_fix(code, error_info)
            if success:
                if self._validate_code(fixed_code):
                    logger.info("✅ Rule-based healing successful!")
                    self._record_success('rule_based', error_info)
                    return True, fixed_code
            
            # 2단계: LLM 기반 수정 시도 (LLM이 있는 경우)
            if self.use_llm:
                success, fixed_code = await self._llm_based_fix(code, error_info)
                if success:
                    if self._validate_code(fixed_code):
                        logger.info("✅ LLM-based healing successful!")
                        self._record_success('llm_based', error_info)
                        return True, fixed_code
            
            # 3단계: 패턴 기반 수정 시도
            success, fixed_code = self._pattern_based_fix(code, error_info)
            if success:
                if self._validate_code(fixed_code):
                    logger.info("✅ Pattern-based healing successful!")
                    self._record_success('pattern_based', error_info)
                    return True, fixed_code
            
            # 수정된 코드로 다시 에러 정보 업데이트
            code = fixed_code if fixed_code else code
            new_error = self._get_error_info(code)
            if new_error:
                error_info = new_error
            else:
                # 에러가 없으면 성공
                return True, code
        
        logger.warning(f"❌ Failed to heal code after {self.max_retry} attempts")
        return False, f"Failed to heal: {error_info.get('message', 'Unknown error')}"
    
    def _rule_based_fix(self, code: str, error_info: Dict[str, Any]) -> Tuple[bool, str]:
        """규칙 기반 수정"""
        error_type = error_info.get('type', '')
        error_line = error_info.get('line_no', 0)
        
        if 'IndentationError' in error_type or 'unindent' in str(error_info.get('message', '')):
            # 들여쓰기 수정
            fixed_code = self._fix_indentation(code, error_line)
            return True, fixed_code
        
        if 'SyntaxError' in error_type:
            # 구문 오류 수정
            fixed_code = self._fix_syntax(code, error_line)
            return True, fixed_code
        
        return False, code
    
    def _fix_indentation(self, code: str, error_line: int) -> str:
        """들여쓰기 오류 수정"""
        lines = code.split('\n')
        
        if error_line > 0 and error_line <= len(lines):
            # 에러 라인 주변의 들여쓰기 분석
            prev_indent = 0
            if error_line > 1:
                prev_line = lines[error_line - 2]
                prev_indent = len(prev_line) - len(prev_line.lstrip())
            
            # 현재 라인의 들여쓰기 수정
            current_line = lines[error_line - 1]
            stripped = current_line.lstrip()
            
            # 이전 라인이 콜론으로 끝나면 들여쓰기 증가
            if error_line > 1 and lines[error_line - 2].rstrip().endswith(':'):
                new_indent = prev_indent + 4
            else:
                # 그렇지 않으면 이전 라인과 같은 들여쓰기
                new_indent = prev_indent
            
            lines[error_line - 1] = ' ' * new_indent + stripped
            
            logger.info(f"🔧 Fixed indentation at line {error_line}: {new_indent} spaces")
        
        return '\n'.join(lines)
    
    def _fix_syntax(self, code: str, error_line: int) -> str:
        """구문 오류 수정"""
        lines = code.split('\n')
        
        if error_line > 0 and error_line <= len(lines):
            current_line = lines[error_line - 1]
            
            # 일반적인 구문 오류 패턴 수정
            # 1. 닫히지 않은 문자열
            if current_line.count('"') % 2 != 0:
                current_line += '"'
            elif current_line.count("'") % 2 != 0:
                current_line += "'"
            
            # 2. 닫히지 않은 괄호
            open_parens = current_line.count('(')
            close_parens = current_line.count(')')
            if open_parens > close_parens:
                current_line += ')' * (open_parens - close_parens)
            
            # 3. 닫히지 않은 중괄호 (딕셔너리)
            open_braces = current_line.count('{')
            close_braces = current_line.count('}')
            if open_braces > close_braces:
                # 딕셔너리가 시작되었지만 닫히지 않은 경우
                # 다음 줄들을 확인하여 적절한 위치에 } 추가
                indent = len(current_line) - len(current_line.lstrip())
                # 마지막에 닫는 중괄호 추가
                for i in range(error_line, min(error_line + 10, len(lines))):
                    if i < len(lines):
                        next_line = lines[i]
                        # 빈 줄이거나 들여쓰기가 같거나 작으면 그 전에 닫기
                        if not next_line.strip() or (next_line.strip() and len(next_line) - len(next_line.lstrip()) <= indent):
                            lines.insert(i, ' ' * indent + '}')
                            logger.info(f"🔧 Added closing brace after line {i}")
                            break
                else:
                    # 적절한 위치를 못 찾으면 바로 다음 줄에 추가
                    if error_line < len(lines):
                        lines.insert(error_line, ' ' * indent + '}')
                    else:
                        lines.append(' ' * indent + '}')
                    logger.info(f"🔧 Added closing brace after line {error_line}")
            
            # 4. 콜론 누락 (if, for, def, class 등)
            if re.match(r'\s*(if|for|while|def|class|try|except|finally|with)\s+.*[^:]$', current_line):
                current_line += ':'
            
            lines[error_line - 1] = current_line
            logger.info(f"🔧 Fixed syntax at line {error_line}")
        
        return '\n'.join(lines)
    
    async def _llm_based_fix(self, code: str, error_info: Dict[str, Any]) -> Tuple[bool, str]:
        """LLM 기반 수정"""
        if not self.llm_client:
            return False, code
        
        try:
            # 에러 컨텍스트 추출
            error_context = self._extract_error_context(code, error_info)
            
            # LLM에게 수정 요청
            prompt = f"""
다음 Python 코드에 에러가 있습니다. 에러를 수정해주세요.

에러 정보:
- 타입: {error_info.get('type', 'Unknown')}
- 메시지: {error_info.get('message', 'Unknown')}
- 위치: Line {error_info.get('line_no', 'Unknown')}

에러가 발생한 코드 부분:
```python
{error_context}
```

전체 코드:
```python
{code}
```

수정된 전체 코드를 제공해주세요. 특히 들여쓰기를 정확하게 맞춰주세요.
코드만 출력하고 설명은 하지 마세요.
"""
            
            # LLM 호출
            response = await self.llm_client.generate(prompt)
            
            # 응답에서 코드 추출
            fixed_code = self._extract_code_from_response(response)
            
            if fixed_code and fixed_code != code:
                logger.info("🤖 LLM generated fix")
                return True, fixed_code
            
        except Exception as e:
            logger.error(f"LLM-based fix failed: {e}")
        
        return False, code
    
    def _pattern_based_fix(self, code: str, error_info: Dict[str, Any]) -> Tuple[bool, str]:
        """패턴 기반 수정 - 과거 성공 패턴 활용"""
        # 과거에 성공한 패턴이 있으면 적용
        for success_pattern in self.success_history:
            if self._matches_pattern(error_info, success_pattern):
                logger.info(f"📋 Applying successful pattern: {success_pattern['method']}")
                # 같은 방법 적용
                if success_pattern['method'] == 'fix_indentation':
                    return True, self._fix_indentation(code, error_info.get('line_no', 0))
                elif success_pattern['method'] == 'fix_syntax':
                    return True, self._fix_syntax(code, error_info.get('line_no', 0))
        
        return False, code
    
    def _validate_code(self, code: str) -> bool:
        """코드 유효성 검증"""
        try:
            compile(code, '<string>', 'exec')
            return True
        except SyntaxError:
            return False
        except Exception:
            return False
    
    def _get_error_info(self, code: str) -> Optional[Dict[str, Any]]:
        """코드에서 에러 정보 추출"""
        try:
            compile(code, '<string>', 'exec')
            return None  # 에러 없음
        except SyntaxError as e:
            return {
                'type': 'SyntaxError',
                'message': str(e),
                'line_no': e.lineno,
                'offset': e.offset
            }
        except IndentationError as e:
            return {
                'type': 'IndentationError',
                'message': str(e),
                'line_no': e.lineno if hasattr(e, 'lineno') else 0
            }
        except Exception as e:
            return {
                'type': type(e).__name__,
                'message': str(e),
                'line_no': 0
            }
    
    def _extract_error_context(self, code: str, error_info: Dict[str, Any], context_lines: int = 5) -> str:
        """에러 주변 코드 추출"""
        lines = code.split('\n')
        error_line = error_info.get('line_no', 0)
        
        if error_line > 0:
            start = max(0, error_line - context_lines - 1)
            end = min(len(lines), error_line + context_lines)
            context_lines = lines[start:end]
            
            # 에러 라인 표시
            result = []
            for i, line in enumerate(context_lines, start=start+1):
                if i == error_line:
                    result.append(f">>> {line}  # << ERROR HERE")
                else:
                    result.append(f"    {line}")
            
            return '\n'.join(result)
        
        return code[:500]  # 처음 500자만 반환
    
    def _extract_code_from_response(self, response: str) -> Optional[str]:
        """LLM 응답에서 코드 추출"""
        # 코드 블록 찾기
        code_block_pattern = r'```python\n(.*?)\n```'
        matches = re.findall(code_block_pattern, response, re.DOTALL)
        
        if matches:
            return matches[0]
        
        # 코드 블록이 없으면 전체 응답이 코드일 수 있음
        # 단, 설명 텍스트가 포함되지 않았는지 확인
        if not any(keyword in response.lower() for keyword in ['here is', 'the code', 'fixed', 'modified']):
            return response.strip()
        
        return None
    
    def _matches_pattern(self, error_info: Dict[str, Any], pattern: Dict[str, Any]) -> bool:
        """에러가 패턴과 일치하는지 확인"""
        return (error_info.get('type') == pattern.get('error_type') and
                error_info.get('message', '')[:50] == pattern.get('error_message', '')[:50])
    
    def _record_success(self, method: str, error_info: Dict[str, Any]):
        """성공한 수정 패턴 기록"""
        self.success_history.append({
            'method': method,
            'error_type': error_info.get('type'),
            'error_message': error_info.get('message', '')[:100]
        })
        
        # 최대 100개까지만 저장
        if len(self.success_history) > 100:
            self.success_history = self.success_history[-100:]
        
        logger.info(f"📝 Recorded successful healing pattern: {method}")
    
    async def analyze_and_fix(self, code: str) -> Tuple[bool, str, List[Dict[str, Any]]]:
        """
        코드 분석 및 자동 수정
        
        Returns:
            (성공 여부, 수정된 코드, 수정 이력)
        """
        fix_history = []
        current_code = code
        
        # 최대 5개의 에러까지 순차적으로 수정
        for _ in range(5):
            error_info = self._get_error_info(current_code)
            
            if not error_info:
                # 에러가 없으면 성공
                return True, current_code, fix_history
            
            # 에러 수정 시도
            success, fixed_code = await self.heal_code(current_code, error_info)
            
            fix_history.append({
                'error': error_info,
                'success': success,
                'method': 'auto_heal'
            })
            
            if not success:
                # 수정 실패
                logger.error(f"Failed to fix error: {error_info}")
                return False, current_code, fix_history
            
            current_code = fixed_code
        
        # 5개 이상의 에러가 있으면 실패로 간주
        return False, current_code, fix_history


# 싱글톤 인스턴스
_healing_system = None


def get_healing_system(llm_client=None) -> SelfHealingSystem:
    """싱글톤 자가 치유 시스템 반환"""
    global _healing_system
    if _healing_system is None:
        _healing_system = SelfHealingSystem(llm_client)
    return _healing_system