"""
FORGE API Server
프로덕션 API 서버
"""

from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import uvicorn
import asyncio
import os
from loguru import logger

from .pipeline import ProductionPipeline
from .monitor import PipelineMonitor
from .cache import PipelineCache
from .error_handler import ErrorHandler


class GenerateRequest(BaseModel):
    """생성 요청 모델"""
    query: str
    context: Optional[Dict[str, Any]] = None
    cache_enabled: bool = True
    async_mode: bool = False


class GenerateResponse(BaseModel):
    """생성 응답 모델"""
    success: bool
    query: str
    code: Optional[str] = None
    template: Optional[str] = None
    patterns: Optional[int] = None
    execution_time_ms: Optional[float] = None
    cached: bool = False
    error: Optional[str] = None


class HealthResponse(BaseModel):
    """헬스체크 응답"""
    status: str
    version: str
    uptime_seconds: float
    statistics: Dict[str, Any]


class ForgeAPIServer:
    """FORGE API 서버"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.app = FastAPI(
            title="FORGE AI API",
            description="Framework for Orchestrating Reactive Generated Entities",
            version="1.0.0"
        )
        
        # API 키 확인: 인자 > GEMINI_API_KEY > GOOGLE_API_KEY
        if not api_key:
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        
        # 프로덕션 파이프라인
        self.pipeline = ProductionPipeline(api_key=api_key)
        
        # 모니터링
        self.monitor = PipelineMonitor()
        self.monitor.start_monitoring()
        
        # 캐시
        self.cache = PipelineCache(max_size_mb=100)
        
        # 에러 핸들러
        self.error_handler = ErrorHandler()
        
        # 시작 시간
        self.start_time = None
        
        # API 라우트 설정
        self._setup_routes()
    
    def _setup_routes(self):
        """API 라우트 설정"""
        
        @self.app.on_event("startup")
        async def startup_event():
            """서버 시작 이벤트"""
            import time
            self.start_time = time.time()
            logger.info("FORGE API Server started")
            
            # 캐시 워밍업
            common_queries = [
                ("VIP 고객 할인", None),
                ("재고 알림", None),
                ("데이터 집계", None)
            ]
            # 실제로는 파이프라인 실행 결과를 캐시해야 함
            # self.cache.warm_up(common_queries)
        
        @self.app.on_event("shutdown")
        async def shutdown_event():
            """서버 종료 이벤트"""
            self.monitor.stop_monitoring()
            logger.info("FORGE API Server stopped")
        
        @self.app.get("/health", response_model=HealthResponse)
        async def health_check():
            """헬스체크"""
            import time
            uptime = time.time() - self.start_time if self.start_time else 0
            
            return HealthResponse(
                status="healthy",
                version="1.0.0",
                uptime_seconds=uptime,
                statistics=self.monitor.get_statistics()
            )
        
        @self.app.post("/generate", response_model=GenerateResponse)
        async def generate_logic(request: GenerateRequest, background_tasks: BackgroundTasks):
            """비즈니스 로직 생성"""
            timer_id = self.monitor.start_timer("api.generate")
            self.monitor.increment_counter("pipeline.requests")
            
            try:
                # 캐시 확인
                cache_key = None
                if request.cache_enabled:
                    cache_key = self.cache.generate_key(request.query, request.context)
                    cached_result = self.cache.get(cache_key)
                    
                    if cached_result:
                        self.monitor.increment_counter("cache.hits")
                        self.monitor.end_timer(timer_id)
                        return GenerateResponse(
                            success=True,
                            query=request.query,
                            code=cached_result.get("code"),
                            template=cached_result.get("template"),
                            patterns=cached_result.get("patterns"),
                            execution_time_ms=0,
                            cached=True
                        )
                    else:
                        self.monitor.increment_counter("cache.misses")
                
                # 비동기 모드
                if request.async_mode:
                    # 백그라운드 태스크로 처리
                    background_tasks.add_task(
                        self._process_async,
                        request.query,
                        request.context,
                        cache_key
                    )
                    
                    return GenerateResponse(
                        success=True,
                        query=request.query,
                        error="Processing in background"
                    )
                
                # 동기 처리
                result = await self._process_query(request.query, request.context)
                
                # 캐시 저장
                if request.cache_enabled and cache_key and result.success:
                    cache_data = {
                        "code": result.combined_result.code if result.combined_result else None,
                        "template": result.combined_result.template_type if result.combined_result else None,
                        "patterns": len(result.matched_patterns)
                    }
                    self.cache.put(cache_key, cache_data)
                
                self.monitor.increment_counter("pipeline.success")
                elapsed_ms = self.monitor.end_timer(timer_id)
                
                return GenerateResponse(
                    success=result.success,
                    query=request.query,
                    code=result.combined_result.code if result.combined_result else None,
                    template=result.combined_result.template_type if result.combined_result else None,
                    patterns=len(result.matched_patterns),
                    execution_time_ms=elapsed_ms,
                    cached=False,
                    error=result.error
                )
                
            except Exception as e:
                self.monitor.increment_counter("pipeline.error")
                self.monitor.end_timer(timer_id)
                
                # 에러 처리
                self.error_handler.handle_error(
                    e, "api_server", request.query, request.context
                )
                
                logger.error(f"Generation failed: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/statistics")
        async def get_statistics():
            """통계 조회"""
            return {
                "monitor": self.monitor.get_statistics(),
                "cache": self.cache.get_statistics(),
                "errors": self.error_handler.get_error_statistics()
            }
        
        @self.app.post("/cache/clear")
        async def clear_cache():
            """캐시 클리어"""
            self.cache.clear()
            return {"message": "Cache cleared"}
        
        @self.app.get("/metrics")
        async def get_metrics():
            """메트릭 익스포트 (Prometheus 형식)"""
            metrics = self.monitor.export_metrics()
            
            # Prometheus text format
            lines = []
            for metric in metrics:
                labels = ",".join([f'{k}="{v}"' for k, v in metric["labels"].items()])
                if labels:
                    labels = "{" + labels + "}"
                lines.append(f"{metric['name']}{labels} {metric['value']} {int(metric['timestamp']*1000)}")
            
            return "\n".join(lines)
    
    async def _process_query(self, query: str, context: Optional[Dict] = None):
        """쿼리 처리"""
        # 동기 함수를 비동기로 실행
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            self.pipeline.process,
            query,
            context
        )
    
    async def _process_async(self, query: str, context: Optional[Dict], cache_key: Optional[str]):
        """비동기 처리"""
        try:
            result = await self._process_query(query, context)
            
            # 캐시 저장
            if cache_key and result.success:
                cache_data = {
                    "code": result.combined_result.code if result.combined_result else None,
                    "template": result.combined_result.template_type if result.combined_result else None,
                    "patterns": len(result.matched_patterns)
                }
                self.cache.put(cache_key, cache_data)
            
            logger.info(f"Async processing completed for: {query}")
        except Exception as e:
            logger.error(f"Async processing failed: {e}")
    
    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """서버 실행"""
        logger.info(f"Starting FORGE API Server on {host}:{port}")
        uvicorn.run(self.app, host=host, port=port)