"""
Pipeline Monitor Module
파이프라인 모니터링 시스템
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
import time
import psutil
import threading
from collections import deque
from datetime import datetime
from loguru import logger


class MetricType(Enum):
    """메트릭 타입"""
    COUNTER = "counter"      # 누적 카운터
    GAUGE = "gauge"          # 현재 값
    HISTOGRAM = "histogram"  # 분포
    TIMER = "timer"          # 시간 측정


@dataclass
class Metric:
    """메트릭 데이터"""
    name: str
    type: MetricType
    value: float
    timestamp: float
    labels: Dict[str, str] = field(default_factory=dict)


class PipelineMonitor:
    """파이프라인 모니터"""
    
    def __init__(self, buffer_size: int = 1000):
        """
        Args:
            buffer_size: 메트릭 버퍼 크기
        """
        self.metrics_buffer = deque(maxlen=buffer_size)
        self.metrics = {}
        self.timers = {}
        
        # 시스템 메트릭
        self.system_metrics = {
            "cpu_percent": 0,
            "memory_mb": 0,
            "thread_count": 0
        }
        
        # 파이프라인 메트릭
        self.pipeline_metrics = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "average_latency_ms": 0,
            "p95_latency_ms": 0,
            "p99_latency_ms": 0
        }
        
        # 컴포넌트별 메트릭
        self.component_metrics = {
            "pattern_matching": {"count": 0, "latency_ms": []},
            "logic_generation": {"count": 0, "latency_ms": []},
            "template_combination": {"count": 0, "latency_ms": []},
            "cache": {"hits": 0, "misses": 0}
        }
        
        # 모니터링 스레드
        self.monitoring_thread = None
        self.monitoring_active = False
        
        # 알림 임계값
        self.alert_thresholds = {
            "cpu_percent": 80,
            "memory_mb": 1000,
            "error_rate": 0.1,
            "p99_latency_ms": 1000
        }
        
        # 알림 핸들러
        self.alert_handlers = []
    
    def start_monitoring(self):
        """모니터링 시작"""
        if not self.monitoring_active:
            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(
                target=self._monitoring_loop,
                daemon=True
            )
            self.monitoring_thread.start()
            logger.info("Pipeline monitoring started")
    
    def stop_monitoring(self):
        """모니터링 중지"""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        logger.info("Pipeline monitoring stopped")
    
    def _monitoring_loop(self):
        """모니터링 루프"""
        while self.monitoring_active:
            # 시스템 메트릭 수집
            self._collect_system_metrics()
            
            # 알림 확인
            self._check_alerts()
            
            # 5초 대기
            time.sleep(5)
    
    def _collect_system_metrics(self):
        """시스템 메트릭 수집"""
        try:
            self.system_metrics["cpu_percent"] = psutil.cpu_percent(interval=1)
            self.system_metrics["memory_mb"] = psutil.Process().memory_info().rss / 1024 / 1024
            self.system_metrics["thread_count"] = threading.active_count()
            
            # 메트릭 기록
            self.record_metric("system.cpu", self.system_metrics["cpu_percent"], MetricType.GAUGE)
            self.record_metric("system.memory", self.system_metrics["memory_mb"], MetricType.GAUGE)
            self.record_metric("system.threads", self.system_metrics["thread_count"], MetricType.GAUGE)
        except Exception as e:
            logger.error(f"Failed to collect system metrics: {e}")
    
    def record_metric(self, name: str, value: float, metric_type: MetricType = MetricType.GAUGE, labels: Dict[str, str] = None):
        """메트릭 기록"""
        metric = Metric(
            name=name,
            type=metric_type,
            value=value,
            timestamp=time.time(),
            labels=labels or {}
        )
        
        self.metrics_buffer.append(metric)
        
        # 집계
        if name not in self.metrics:
            self.metrics[name] = []
        self.metrics[name].append(value)
        
        # 최대 1000개만 유지
        if len(self.metrics[name]) > 1000:
            self.metrics[name] = self.metrics[name][-1000:]
    
    def start_timer(self, name: str) -> str:
        """타이머 시작"""
        timer_id = f"{name}_{time.time()}"
        self.timers[timer_id] = time.time()
        return timer_id
    
    def end_timer(self, timer_id: str, labels: Dict[str, str] = None):
        """타이머 종료"""
        if timer_id in self.timers:
            start_time = self.timers.pop(timer_id)
            elapsed_ms = (time.time() - start_time) * 1000
            
            # 타이머 이름 추출
            name = timer_id.rsplit('_', 1)[0]
            
            # 메트릭 기록
            self.record_metric(f"{name}.latency", elapsed_ms, MetricType.TIMER, labels)
            
            # 컴포넌트 메트릭 업데이트
            if name in self.component_metrics:
                self.component_metrics[name]["count"] += 1
                self.component_metrics[name]["latency_ms"].append(elapsed_ms)
                
                # 최대 1000개만 유지
                if len(self.component_metrics[name]["latency_ms"]) > 1000:
                    self.component_metrics[name]["latency_ms"] = \
                        self.component_metrics[name]["latency_ms"][-1000:]
            
            return elapsed_ms
        return 0
    
    def increment_counter(self, name: str, value: int = 1, labels: Dict[str, str] = None):
        """카운터 증가"""
        self.record_metric(name, value, MetricType.COUNTER, labels)
        
        # 파이프라인 메트릭 업데이트
        if name == "pipeline.requests":
            self.pipeline_metrics["total_requests"] += value
        elif name == "pipeline.success":
            self.pipeline_metrics["successful_requests"] += value
        elif name == "pipeline.error":
            self.pipeline_metrics["failed_requests"] += value
        elif name == "cache.hits":
            self.component_metrics["cache"]["hits"] += value
        elif name == "cache.misses":
            self.component_metrics["cache"]["misses"] += value
    
    def get_statistics(self) -> Dict[str, Any]:
        """통계 조회"""
        # 에러율 계산
        error_rate = 0
        if self.pipeline_metrics["total_requests"] > 0:
            error_rate = self.pipeline_metrics["failed_requests"] / self.pipeline_metrics["total_requests"]
        
        # 지연시간 통계
        all_latencies = []
        for component in self.component_metrics.values():
            if "latency_ms" in component:
                all_latencies.extend(component["latency_ms"])
        
        p95_latency = 0
        p99_latency = 0
        avg_latency = 0
        
        if all_latencies:
            sorted_latencies = sorted(all_latencies)
            p95_index = int(len(sorted_latencies) * 0.95)
            p99_index = int(len(sorted_latencies) * 0.99)
            
            p95_latency = sorted_latencies[p95_index] if p95_index < len(sorted_latencies) else 0
            p99_latency = sorted_latencies[p99_index] if p99_index < len(sorted_latencies) else 0
            avg_latency = sum(all_latencies) / len(all_latencies)
        
        return {
            "pipeline": {
                "total_requests": self.pipeline_metrics["total_requests"],
                "successful_requests": self.pipeline_metrics["successful_requests"],
                "failed_requests": self.pipeline_metrics["failed_requests"],
                "error_rate": f"{error_rate:.2%}",
                "average_latency_ms": f"{avg_latency:.2f}",
                "p95_latency_ms": f"{p95_latency:.2f}",
                "p99_latency_ms": f"{p99_latency:.2f}"
            },
            "system": self.system_metrics,
            "components": {
                name: {
                    "count": data["count"],
                    "avg_latency_ms": f"{sum(data['latency_ms'])/len(data['latency_ms']):.2f}" 
                        if data.get("latency_ms") else "0"
                }
                for name, data in self.component_metrics.items()
                if "count" in data
            },
            "cache": {
                "hits": self.component_metrics["cache"]["hits"],
                "misses": self.component_metrics["cache"]["misses"],
                "hit_rate": f"{self.component_metrics['cache']['hits']/(self.component_metrics['cache']['hits']+self.component_metrics['cache']['misses']):.2%}"
                    if (self.component_metrics['cache']['hits']+self.component_metrics['cache']['misses']) > 0 else "0%"
            }
        }
    
    def _check_alerts(self):
        """알림 확인"""
        alerts = []
        
        # CPU 임계값 확인
        if self.system_metrics["cpu_percent"] > self.alert_thresholds["cpu_percent"]:
            alerts.append(f"High CPU usage: {self.system_metrics['cpu_percent']}%")
        
        # 메모리 임계값 확인
        if self.system_metrics["memory_mb"] > self.alert_thresholds["memory_mb"]:
            alerts.append(f"High memory usage: {self.system_metrics['memory_mb']:.0f}MB")
        
        # 에러율 확인
        if self.pipeline_metrics["total_requests"] > 100:
            error_rate = self.pipeline_metrics["failed_requests"] / self.pipeline_metrics["total_requests"]
            if error_rate > self.alert_thresholds["error_rate"]:
                alerts.append(f"High error rate: {error_rate:.2%}")
        
        # 알림 발송
        for alert in alerts:
            self._send_alert(alert)
    
    def _send_alert(self, message: str):
        """알림 발송"""
        logger.warning(f"ALERT: {message}")
        
        # 알림 핸들러 실행
        for handler in self.alert_handlers:
            try:
                handler(message)
            except Exception as e:
                logger.error(f"Alert handler failed: {e}")
    
    def add_alert_handler(self, handler):
        """알림 핸들러 추가"""
        self.alert_handlers.append(handler)
    
    def export_metrics(self) -> List[Dict[str, Any]]:
        """메트릭 익스포트 (Prometheus 형식)"""
        export_data = []
        
        for metric in self.metrics_buffer:
            export_data.append({
                "name": metric.name,
                "type": metric.type.value,
                "value": metric.value,
                "timestamp": metric.timestamp,
                "labels": metric.labels
            })
        
        return export_data