"""
Error Handler Module
에러 처리 및 복구 메커니즘
"""

from typing import Any, Optional, Dict, Callable
from dataclasses import dataclass
from enum import Enum
import traceback
import time
from loguru import logger


class ErrorSeverity(Enum):
    """에러 심각도"""
    LOW = "low"        # 무시 가능
    MEDIUM = "medium"  # 재시도 필요
    HIGH = "high"      # 즉시 처리
    CRITICAL = "critical"  # 시스템 중단


@dataclass
class ErrorContext:
    """에러 컨텍스트"""
    error_type: str
    message: str
    severity: ErrorSeverity
    stack_trace: str
    timestamp: float
    retry_count: int
    component: str
    query: Optional[str]
    metadata: Dict[str, Any]


class ErrorHandler:
    """에러 처리기"""
    
    def __init__(self):
        self.error_history = []
        self.retry_strategies = {
            ErrorSeverity.LOW: self._retry_with_backoff,
            ErrorSeverity.MEDIUM: self._retry_with_exponential_backoff,
            ErrorSeverity.HIGH: self._retry_with_circuit_breaker,
            ErrorSeverity.CRITICAL: self._handle_critical
        }
        
        # Circuit breaker 설정
        self.circuit_breaker = {
            "failures": 0,
            "last_failure": 0,
            "state": "closed",  # closed, open, half-open
            "threshold": 5,
            "timeout": 60  # seconds
        }
        
        # 에러 복구 전략
        self.recovery_strategies = {
            "PatternMatchingError": self._recover_pattern_matching,
            "LogicGenerationError": self._recover_logic_generation,
            "TemplateError": self._recover_template,
            "ValidationError": self._recover_validation
        }
    
    def handle_error(self, 
                    error: Exception,
                    component: str,
                    query: Optional[str] = None,
                    context: Optional[Dict] = None) -> Optional[Any]:
        """에러 처리"""
        
        # 에러 컨텍스트 생성
        error_context = self._create_error_context(
            error, component, query, context
        )
        
        # 에러 로깅
        self._log_error(error_context)
        
        # 에러 기록
        self.error_history.append(error_context)
        
        # 복구 시도
        if error_context.severity in [ErrorSeverity.LOW, ErrorSeverity.MEDIUM]:
            recovery_strategy = self.recovery_strategies.get(
                error.__class__.__name__
            )
            if recovery_strategy:
                return recovery_strategy(error_context)
        
        # 재시도 전략 적용
        retry_strategy = self.retry_strategies[error_context.severity]
        return retry_strategy(error_context)
    
    def _create_error_context(self,
                            error: Exception,
                            component: str,
                            query: Optional[str],
                            context: Optional[Dict]) -> ErrorContext:
        """에러 컨텍스트 생성"""
        
        # 심각도 판단
        severity = self._determine_severity(error, component)
        
        return ErrorContext(
            error_type=error.__class__.__name__,
            message=str(error),
            severity=severity,
            stack_trace=traceback.format_exc(),
            timestamp=time.time(),
            retry_count=0,
            component=component,
            query=query,
            metadata=context or {}
        )
    
    def _determine_severity(self, error: Exception, component: str) -> ErrorSeverity:
        """에러 심각도 판단"""
        
        # Critical errors
        if isinstance(error, (SystemError, MemoryError)):
            return ErrorSeverity.CRITICAL
        
        # High severity
        if component in ["api_server", "production_pipeline"]:
            return ErrorSeverity.HIGH
        
        # Medium severity
        if isinstance(error, (ValueError, KeyError, AttributeError)):
            return ErrorSeverity.MEDIUM
        
        # Low severity
        return ErrorSeverity.LOW
    
    def _log_error(self, context: ErrorContext):
        """에러 로깅"""
        if context.severity == ErrorSeverity.CRITICAL:
            logger.critical(f"[{context.component}] {context.message}")
        elif context.severity == ErrorSeverity.HIGH:
            logger.error(f"[{context.component}] {context.message}")
        elif context.severity == ErrorSeverity.MEDIUM:
            logger.warning(f"[{context.component}] {context.message}")
        else:
            logger.info(f"[{context.component}] {context.message}")
    
    def _retry_with_backoff(self, context: ErrorContext, max_retries: int = 3):
        """백오프 재시도"""
        for i in range(max_retries):
            time.sleep(2 ** i)  # Exponential backoff
            logger.info(f"Retry attempt {i+1}/{max_retries}")
            # 재시도 로직은 호출하는 쪽에서 구현
        return None
    
    def _retry_with_exponential_backoff(self, context: ErrorContext):
        """지수 백오프 재시도"""
        return self._retry_with_backoff(context, max_retries=5)
    
    def _retry_with_circuit_breaker(self, context: ErrorContext):
        """서킷 브레이커와 함께 재시도"""
        
        # 서킷 브레이커 상태 확인
        if self.circuit_breaker["state"] == "open":
            # 타임아웃 확인
            if time.time() - self.circuit_breaker["last_failure"] > self.circuit_breaker["timeout"]:
                self.circuit_breaker["state"] = "half-open"
                logger.info("Circuit breaker: half-open")
            else:
                logger.warning("Circuit breaker is open, skipping retry")
                return None
        
        # 실패 카운트 증가
        self.circuit_breaker["failures"] += 1
        self.circuit_breaker["last_failure"] = time.time()
        
        # 임계값 확인
        if self.circuit_breaker["failures"] >= self.circuit_breaker["threshold"]:
            self.circuit_breaker["state"] = "open"
            logger.error("Circuit breaker opened due to too many failures")
            return None
        
        return self._retry_with_backoff(context)
    
    def _handle_critical(self, context: ErrorContext):
        """크리티컬 에러 처리"""
        logger.critical("Critical error detected, initiating emergency procedures")
        
        # 알림 발송 (실제 환경에서는 이메일, 슬랙 등)
        self._send_alert(context)
        
        # 시스템 상태 덤프
        self._dump_system_state(context)
        
        # Graceful shutdown 시작
        return None
    
    def _send_alert(self, context: ErrorContext):
        """알림 발송"""
        logger.info(f"Alert sent for {context.error_type}: {context.message}")
    
    def _dump_system_state(self, context: ErrorContext):
        """시스템 상태 덤프"""
        logger.info(f"System state dumped at {context.timestamp}")
    
    def _recover_pattern_matching(self, context: ErrorContext):
        """패턴 매칭 에러 복구"""
        logger.info("Attempting pattern matching recovery")
        # 기본 패턴 매칭으로 폴백
        return []
    
    def _recover_logic_generation(self, context: ErrorContext):
        """로직 생성 에러 복구"""
        logger.info("Attempting logic generation recovery")
        # 기본 템플릿 사용
        return None
    
    def _recover_template(self, context: ErrorContext):
        """템플릿 에러 복구"""
        logger.info("Attempting template recovery")
        # 기본 템플릿으로 폴백
        return "orchestrated"
    
    def _recover_validation(self, context: ErrorContext):
        """검증 에러 복구"""
        logger.info("Attempting validation recovery")
        # 검증 스킵
        return True
    
    def reset_circuit_breaker(self):
        """서킷 브레이커 리셋"""
        self.circuit_breaker["failures"] = 0
        self.circuit_breaker["state"] = "closed"
        logger.info("Circuit breaker reset")
    
    def get_error_statistics(self) -> Dict[str, Any]:
        """에러 통계 조회"""
        if not self.error_history:
            return {"total": 0}
        
        stats = {
            "total": len(self.error_history),
            "by_severity": {},
            "by_component": {},
            "by_type": {},
            "recent_errors": []
        }
        
        for error in self.error_history:
            # 심각도별
            severity = error.severity.value
            stats["by_severity"][severity] = stats["by_severity"].get(severity, 0) + 1
            
            # 컴포넌트별
            component = error.component
            stats["by_component"][component] = stats["by_component"].get(component, 0) + 1
            
            # 타입별
            error_type = error.error_type
            stats["by_type"][error_type] = stats["by_type"].get(error_type, 0) + 1
        
        # 최근 에러
        stats["recent_errors"] = [
            {
                "type": e.error_type,
                "message": e.message,
                "severity": e.severity.value,
                "timestamp": e.timestamp
            }
            for e in self.error_history[-5:]
        ]
        
        return stats