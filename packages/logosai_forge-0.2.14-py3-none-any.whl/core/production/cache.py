"""
Pipeline Cache Module
파이프라인 캐싱 시스템
"""

from typing import Any, Optional, Dict, List, Tuple
from dataclasses import dataclass
import hashlib
import json
import time
from collections import OrderedDict
from loguru import logger


@dataclass
class CacheEntry:
    """캐시 엔트리"""
    key: str
    value: Any
    timestamp: float
    hit_count: int
    size_bytes: int
    ttl: int  # Time to live in seconds


class PipelineCache:
    """파이프라인 캐시"""
    
    def __init__(self, max_size_mb: int = 100, default_ttl: int = 3600):
        """
        Args:
            max_size_mb: 최대 캐시 크기 (MB)
            default_ttl: 기본 TTL (초)
        """
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.default_ttl = default_ttl
        self.cache = OrderedDict()
        self.current_size = 0
        
        # 통계
        self.stats = {
            "hits": 0,
            "misses": 0,
            "evictions": 0,
            "total_requests": 0
        }
        
        # 캐시 레벨
        self.cache_levels = {
            "pattern_matching": OrderedDict(),  # L1 캐시
            "logic_generation": OrderedDict(),   # L2 캐시
            "template_combination": OrderedDict()  # L3 캐시
        }
    
    def get(self, key: str, level: str = "default") -> Optional[Any]:
        """캐시 조회"""
        self.stats["total_requests"] += 1
        
        # 레벨별 캐시 확인
        if level != "default" and level in self.cache_levels:
            cache_dict = self.cache_levels[level]
        else:
            cache_dict = self.cache
        
        if key in cache_dict:
            entry = cache_dict[key]
            
            # TTL 확인
            if time.time() - entry.timestamp > entry.ttl:
                self._evict(key, cache_dict)
                self.stats["misses"] += 1
                return None
            
            # Hit count 증가 및 LRU 업데이트
            entry.hit_count += 1
            cache_dict.move_to_end(key)
            
            self.stats["hits"] += 1
            logger.debug(f"Cache hit for key: {key[:20]}...")
            return entry.value
        
        self.stats["misses"] += 1
        return None
    
    def put(self, key: str, value: Any, ttl: Optional[int] = None, level: str = "default"):
        """캐시 저장"""
        # 캐시 레벨 선택
        if level != "default" and level in self.cache_levels:
            cache_dict = self.cache_levels[level]
        else:
            cache_dict = self.cache
        
        # 크기 계산
        size_bytes = self._estimate_size(value)
        
        # 크기 제한 확인
        while self.current_size + size_bytes > self.max_size_bytes:
            self._evict_lru(cache_dict)
        
        # 캐시 엔트리 생성
        entry = CacheEntry(
            key=key,
            value=value,
            timestamp=time.time(),
            hit_count=0,
            size_bytes=size_bytes,
            ttl=ttl or self.default_ttl
        )
        
        # 저장
        cache_dict[key] = entry
        self.current_size += size_bytes
        
        logger.debug(f"Cached key: {key[:20]}... (size: {size_bytes} bytes)")
    
    def invalidate(self, key: str, level: str = "all"):
        """캐시 무효화"""
        if level == "all":
            # 모든 레벨에서 제거
            for cache_dict in [self.cache] + list(self.cache_levels.values()):
                if key in cache_dict:
                    self._evict(key, cache_dict)
        else:
            # 특정 레벨에서만 제거
            cache_dict = self.cache_levels.get(level, self.cache)
            if key in cache_dict:
                self._evict(key, cache_dict)
    
    def clear(self, level: Optional[str] = None):
        """캐시 전체 클리어"""
        if level:
            if level in self.cache_levels:
                self.cache_levels[level].clear()
        else:
            self.cache.clear()
            for cache_dict in self.cache_levels.values():
                cache_dict.clear()
            self.current_size = 0
        
        logger.info(f"Cache cleared{f' for level: {level}' if level else ''}")
    
    def _evict(self, key: str, cache_dict: OrderedDict):
        """캐시 엔트리 제거"""
        if key in cache_dict:
            entry = cache_dict[key]
            self.current_size -= entry.size_bytes
            del cache_dict[key]
            self.stats["evictions"] += 1
    
    def _evict_lru(self, cache_dict: OrderedDict):
        """LRU 정책으로 제거"""
        if cache_dict:
            key, entry = cache_dict.popitem(last=False)
            self.current_size -= entry.size_bytes
            self.stats["evictions"] += 1
            logger.debug(f"Evicted LRU entry: {key[:20]}...")
    
    def _estimate_size(self, obj: Any) -> int:
        """객체 크기 추정"""
        try:
            # JSON으로 직렬화하여 크기 계산
            json_str = json.dumps(obj, default=str)
            return len(json_str.encode('utf-8'))
        except:
            # 직렬화 실패시 기본값
            return 1024
    
    def generate_key(self, query: str, context: Optional[Dict] = None) -> str:
        """캐시 키 생성"""
        # 쿼리와 컨텍스트를 조합하여 유니크 키 생성
        key_data = {
            "query": query,
            "context": context or {}
        }
        
        key_str = json.dumps(key_data, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def get_statistics(self) -> Dict[str, Any]:
        """캐시 통계 조회"""
        hit_rate = 0
        if self.stats["total_requests"] > 0:
            hit_rate = self.stats["hits"] / self.stats["total_requests"]
        
        return {
            "total_requests": self.stats["total_requests"],
            "hits": self.stats["hits"],
            "misses": self.stats["misses"],
            "hit_rate": f"{hit_rate:.2%}",
            "evictions": self.stats["evictions"],
            "current_size_mb": self.current_size / (1024 * 1024),
            "max_size_mb": self.max_size_bytes / (1024 * 1024),
            "entries": {
                "default": len(self.cache),
                "pattern_matching": len(self.cache_levels["pattern_matching"]),
                "logic_generation": len(self.cache_levels["logic_generation"]),
                "template_combination": len(self.cache_levels["template_combination"])
            }
        }
    
    def warm_up(self, common_queries: List[Tuple[str, Any]]):
        """캐시 워밍업"""
        logger.info(f"Warming up cache with {len(common_queries)} entries")
        
        for query, result in common_queries:
            key = self.generate_key(query)
            self.put(key, result, ttl=7200)  # 2시간 TTL
        
        logger.info("Cache warmup complete")