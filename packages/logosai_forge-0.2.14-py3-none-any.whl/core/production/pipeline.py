"""
Production Pipeline
프로덕션 환경을 위한 완전한 파이프라인
"""

import os
import time
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from loguru import logger
import json

# Steps 1-4
from ..pipeline.advanced_pipeline import AdvancedPipeline, AdvancedPipelineResult

# Production components
from .error_handler import ErrorHandler
from .cache import PipelineCache
from .monitor import PipelineMonitor


@dataclass
class ProductionConfig:
    """프로덕션 설정"""
    api_key: Optional[str] = None
    cache_enabled: bool = True
    cache_ttl: int = 3600
    monitoring_enabled: bool = True
    error_recovery: bool = True
    max_retries: int = 3
    timeout_seconds: int = 30
    log_level: str = "INFO"


class ProductionPipeline:
    """프로덕션 파이프라인 (Steps 1→2→3→4→5)"""
    
    def __init__(self, config: Optional[ProductionConfig] = None, api_key: Optional[str] = None):
        """
        Args:
            config: 프로덕션 설정
            api_key: Gemini/Google API key
        """
        # API 키 확인: 인자 > GEMINI_API_KEY > GOOGLE_API_KEY
        if not api_key:
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        
        self.config = config or ProductionConfig(api_key=api_key)
        
        logger.info("Initializing Production Pipeline (Steps 1→2→3→4→5)")
        
        # 기본 파이프라인 (Steps 1-4)
        self.pipeline = AdvancedPipeline(api_key=self.config.api_key)
        
        # 에러 핸들러
        self.error_handler = ErrorHandler()
        
        # 캐시
        self.cache = PipelineCache(default_ttl=self.config.cache_ttl) if self.config.cache_enabled else None
        
        # 모니터
        self.monitor = PipelineMonitor() if self.config.monitoring_enabled else None
        
        # 통계
        self.statistics = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "total_time_ms": 0
        }
        
        logger.info("[Step 5] Production components initialized")
        
        # 모니터링 시작
        if self.monitor:
            self.monitor.start_monitoring()
            logger.info("[Step 5] Monitoring started")
    
    def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AdvancedPipelineResult:
        """
        프로덕션 파이프라인 실행
        
        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트
            
        Returns:
            파이프라인 실행 결과
        """
        start_time = time.time()
        self.statistics["total_requests"] += 1
        
        # 모니터링
        timer_id = None
        if self.monitor:
            timer_id = self.monitor.start_timer("production.pipeline")
            self.monitor.increment_counter("pipeline.requests")
        
        try:
            logger.info(f"[Production] Processing query: {query}")
            
            # 캐시 확인
            if self.cache and self.config.cache_enabled:
                cache_key = self.cache.generate_key(query, context)
                cached_result = self.cache.get(cache_key, level="pattern_matching")
                
                if cached_result:
                    self.statistics["cache_hits"] += 1
                    if self.monitor:
                        self.monitor.increment_counter("cache.hits")
                    
                    logger.info("[Production] Cache hit, returning cached result")
                    
                    # 캐시된 결과 반환
                    return AdvancedPipelineResult(
                        query=query,
                        matched_patterns=cached_result.get("patterns", []),
                        combined_result=cached_result.get("result"),
                        execution_time_ms=(time.time() - start_time) * 1000,
                        success=True,
                        error=None
                    )
                else:
                    self.statistics["cache_misses"] += 1
                    if self.monitor:
                        self.monitor.increment_counter("cache.misses")
            
            # 파이프라인 실행
            result = self._execute_with_retry(query, context)
            
            # 성공 시 캐시 저장
            if result.success and self.cache and self.config.cache_enabled:
                cache_data = {
                    "patterns": result.matched_patterns,
                    "result": result.combined_result
                }
                self.cache.put(cache_key, cache_data, level="pattern_matching")
                logger.debug("[Production] Result cached")
            
            # 통계 업데이트
            if result.success:
                self.statistics["successful_requests"] += 1
                if self.monitor:
                    self.monitor.increment_counter("pipeline.success")
            else:
                self.statistics["failed_requests"] += 1
                if self.monitor:
                    self.monitor.increment_counter("pipeline.error")
            
            # 실행 시간 기록
            execution_time = (time.time() - start_time) * 1000
            self.statistics["total_time_ms"] += execution_time
            
            if self.monitor and timer_id:
                self.monitor.end_timer(timer_id)
            
            logger.info(f"[Production] Complete in {execution_time:.0f}ms")
            
            return result
            
        except Exception as e:
            # 에러 처리
            if self.config.error_recovery:
                recovery_result = self.error_handler.handle_error(
                    e, "production_pipeline", query, context
                )
                
                if recovery_result:
                    logger.info("[Production] Error recovered")
                    return recovery_result
            
            # 복구 실패
            self.statistics["failed_requests"] += 1
            if self.monitor:
                self.monitor.increment_counter("pipeline.error")
                if timer_id:
                    self.monitor.end_timer(timer_id)
            
            logger.error(f"[Production] Pipeline failed: {e}")
            
            return AdvancedPipelineResult(
                query=query,
                matched_patterns=[],
                combined_result=None,
                execution_time_ms=(time.time() - start_time) * 1000,
                success=False,
                error=str(e)
            )
    
    def _execute_with_retry(self, query: str, context: Optional[Dict] = None) -> AdvancedPipelineResult:
        """재시도 로직과 함께 실행"""
        
        last_error = None
        
        for attempt in range(self.config.max_retries):
            try:
                # 타임아웃 적용
                import signal
                
                def timeout_handler(signum, frame):
                    raise TimeoutError(f"Pipeline timeout after {self.config.timeout_seconds}s")
                
                # 타임아웃 설정 (Unix 계열만)
                if hasattr(signal, 'SIGALRM'):
                    signal.signal(signal.SIGALRM, timeout_handler)
                    signal.alarm(self.config.timeout_seconds)
                
                try:
                    # 실제 파이프라인 실행
                    result = self.pipeline.process(query, context)
                    
                    # 타임아웃 해제
                    if hasattr(signal, 'SIGALRM'):
                        signal.alarm(0)
                    
                    return result
                    
                except TimeoutError as e:
                    last_error = e
                    logger.warning(f"[Production] Attempt {attempt+1} timed out")
                    
            except Exception as e:
                last_error = e
                logger.warning(f"[Production] Attempt {attempt+1} failed: {e}")
                
                # 지수 백오프
                if attempt < self.config.max_retries - 1:
                    wait_time = 2 ** attempt
                    logger.info(f"[Production] Waiting {wait_time}s before retry")
                    time.sleep(wait_time)
        
        # 모든 재시도 실패
        raise last_error or Exception("All retry attempts failed")
    
    def batch_process(self, queries: List[str], parallel: bool = False) -> List[AdvancedPipelineResult]:
        """배치 처리"""
        logger.info(f"[Production] Batch processing {len(queries)} queries")
        
        results = []
        
        if parallel:
            # 병렬 처리
            import concurrent.futures
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                futures = [executor.submit(self.process, query) for query in queries]
                results = [f.result() for f in concurrent.futures.as_completed(futures)]
        else:
            # 순차 처리
            for query in queries:
                results.append(self.process(query))
        
        # 성공률 계산
        success_count = sum(1 for r in results if r.success)
        logger.info(f"[Production] Batch complete: {success_count}/{len(queries)} successful")
        
        return results
    
    def get_statistics(self) -> Dict[str, Any]:
        """통계 조회"""
        stats = self.statistics.copy()
        
        # 성공률 계산
        if stats["total_requests"] > 0:
            stats["success_rate"] = stats["successful_requests"] / stats["total_requests"]
            stats["average_time_ms"] = stats["total_time_ms"] / stats["total_requests"]
        else:
            stats["success_rate"] = 0
            stats["average_time_ms"] = 0
        
        # 캐시 통계
        if self.cache:
            stats["cache"] = self.cache.get_statistics()
        
        # 모니터 통계
        if self.monitor:
            stats["monitor"] = self.monitor.get_statistics()
        
        # 에러 통계
        stats["errors"] = self.error_handler.get_error_statistics()
        
        return stats
    
    def health_check(self) -> Dict[str, Any]:
        """헬스 체크"""
        health = {
            "status": "healthy",
            "components": {}
        }
        
        # 파이프라인 체크
        try:
            test_result = self.pipeline.analyze_query("test")
            health["components"]["pipeline"] = "healthy"
        except:
            health["components"]["pipeline"] = "unhealthy"
            health["status"] = "degraded"
        
        # 캐시 체크
        if self.cache:
            cache_stats = self.cache.get_statistics()
            health["components"]["cache"] = {
                "status": "healthy",
                "hit_rate": cache_stats["hit_rate"]
            }
        
        # 모니터 체크
        if self.monitor:
            monitor_stats = self.monitor.get_statistics()
            health["components"]["monitor"] = {
                "status": "healthy",
                "cpu": monitor_stats["system"]["cpu_percent"],
                "memory_mb": monitor_stats["system"]["memory_mb"]
            }
        
        return health
    
    def export_config(self, output_file: str):
        """설정 익스포트"""
        config_data = {
            "api_key": "***" if self.config.api_key else None,
            "cache_enabled": self.config.cache_enabled,
            "cache_ttl": self.config.cache_ttl,
            "monitoring_enabled": self.config.monitoring_enabled,
            "error_recovery": self.config.error_recovery,
            "max_retries": self.config.max_retries,
            "timeout_seconds": self.config.timeout_seconds,
            "log_level": self.config.log_level
        }
        
        with open(output_file, 'w') as f:
            json.dump(config_data, f, indent=2)
        
        logger.info(f"[Production] Config exported to {output_file}")
    
    def shutdown(self):
        """종료 처리"""
        logger.info("[Production] Shutting down pipeline")
        
        # 모니터링 종료
        if self.monitor:
            self.monitor.stop_monitoring()
        
        # 캐시 클리어
        if self.cache:
            self.cache.clear()
        
        # 통계 출력
        stats = self.get_statistics()
        logger.info(f"[Production] Final statistics: {json.dumps(stats, indent=2)}")
        
        logger.info("[Production] Shutdown complete")