"""
Agent Registry for FORGE AI

Manages all generated agents using LLM-driven organization and search.
All categorization and recommendation decisions are made by LLM.
"""

import json
import sqlite3
import asyncio
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import hashlib
from loguru import logger

from .llm_orchestrator import LLMOrchestrator, TaskType
from .prompts import prompt_registry

@dataclass
class RegisteredAgent:
    """Represents a registered agent"""
    id: str
    name: str
    description: str
    code: str
    template_used: str
    capabilities: List[str]
    tags: List[str]
    category: str
    version: str = "1.0.0"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    created_by: str = "FORGE"
    status: str = "active"  # active, deprecated, testing
    performance_score: float = 0.0
    usage_count: int = 0
    parent_agent_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'template_used': self.template_used,
            'capabilities': self.capabilities,
            'tags': self.tags,
            'category': self.category,
            'version': self.version,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'created_by': self.created_by,
            'status': self.status,
            'performance_score': self.performance_score,
            'usage_count': self.usage_count,
            'parent_agent_id': self.parent_agent_id,
            'metadata': self.metadata
        }


@dataclass
class SearchResult:
    """Agent search result"""
    agent: RegisteredAgent
    relevance_score: float
    match_reason: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'agent': self.agent.to_dict(),
            'relevance_score': self.relevance_score,
            'match_reason': self.match_reason
        }


class AgentRegistry:
    """Registry for managing all generated agents"""
    
    def __init__(self,
                 llm_orchestrator: Optional[LLMOrchestrator] = None,
                 db_path: Optional[str] = None):
        """
        Initialize agent registry.
        
        Args:
            llm_orchestrator: LLM for intelligent operations
            db_path: Path to SQLite database
        """
        self.llm = llm_orchestrator
        self.db_path = db_path or "forge_agents.db"
        
        # In-memory cache
        self.agents: Dict[str, RegisteredAgent] = {}
        self.categories: Dict[str, List[str]] = {}
        self.tag_index: Dict[str, List[str]] = {}
        
        # Initialize database
        self._init_database()
        self._load_agents()
        
    def _init_database(self):
        """Initialize SQLite database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agents (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                code TEXT NOT NULL,
                template_used TEXT,
                capabilities TEXT,
                tags TEXT,
                category TEXT,
                version TEXT,
                created_at TEXT,
                updated_at TEXT,
                created_by TEXT,
                status TEXT,
                performance_score REAL,
                usage_count INTEGER,
                parent_agent_id TEXT,
                metadata TEXT
            )
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_category ON agents(category)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_status ON agents(status)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_created_at ON agents(created_at)
        """)
        
        conn.commit()
        conn.close()
        
    def _load_agents(self):
        """Load agents from database into memory"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM agents WHERE status != 'deleted'")
        rows = cursor.fetchall()
        
        for row in rows:
            agent = self._row_to_agent(row)
            self.agents[agent.id] = agent
            
            # Update indices
            if agent.category not in self.categories:
                self.categories[agent.category] = []
            self.categories[agent.category].append(agent.id)
            
            for tag in agent.tags:
                if tag not in self.tag_index:
                    self.tag_index[tag] = []
                self.tag_index[tag].append(agent.id)
                
        conn.close()
        
        logger.info(f"Loaded {len(self.agents)} agents from registry")
        
    def _row_to_agent(self, row) -> RegisteredAgent:
        """Convert database row to RegisteredAgent"""
        return RegisteredAgent(
            id=row[0],
            name=row[1],
            description=row[2],
            code=row[3],
            template_used=row[4],
            capabilities=json.loads(row[5]) if row[5] else [],
            tags=json.loads(row[6]) if row[6] else [],
            category=row[7] or "uncategorized",
            version=row[8] or "1.0.0",
            created_at=datetime.fromisoformat(row[9]) if row[9] else datetime.now(),
            updated_at=datetime.fromisoformat(row[10]) if row[10] else datetime.now(),
            created_by=row[11] or "FORGE",
            status=row[12] or "active",
            performance_score=row[13] or 0.0,
            usage_count=row[14] or 0,
            parent_agent_id=row[15],
            metadata=json.loads(row[16]) if row[16] else {}
        )
        
    async def register_agent(self,
                           name: str,
                           code: str,
                           template_used: str,
                           description: Optional[str] = None,
                           parent_agent_id: Optional[str] = None,
                           metadata: Optional[Dict[str, Any]] = None) -> RegisteredAgent:
        """
        Register a new agent in the registry.
        
        Args:
            name: Agent name
            code: Agent code
            template_used: Template that was used
            description: Agent description
            parent_agent_id: Parent agent if this is an evolution
            metadata: Additional metadata
            
        Returns:
            Registered agent
        """
        # Generate unique ID
        agent_id = self._generate_agent_id(name, code)
        
        # Let LLM analyze the agent
        analysis = await self._analyze_agent(name, code, description)
        
        # Create agent record
        agent = RegisteredAgent(
            id=agent_id,
            name=name,
            description=description or analysis.get('description', ''),
            code=code,
            template_used=template_used,
            capabilities=analysis.get('capabilities', []),
            tags=analysis.get('tags', []),
            category=analysis.get('category', 'general'),
            parent_agent_id=parent_agent_id,
            metadata=metadata or {}
        )
        
        # Save to database
        self._save_agent(agent)
        
        # Update in-memory indices
        self.agents[agent.id] = agent
        
        if agent.category not in self.categories:
            self.categories[agent.category] = []
        self.categories[agent.category].append(agent.id)
        
        for tag in agent.tags:
            if tag not in self.tag_index:
                self.tag_index[tag] = []
            self.tag_index[tag].append(agent.id)
            
        logger.info(f"Registered agent: {agent.id} ({agent.name})")
        
        return agent
        
    def _generate_agent_id(self, name: str, code: str) -> str:
        """Generate unique agent ID"""
        # Use hash of name + code for uniqueness
        content = f"{name}:{code[:1000]}"
        hash_digest = hashlib.sha256(content.encode()).hexdigest()[:12]
        
        # Create readable ID
        clean_name = ''.join(c for c in name.lower() if c.isalnum() or c == '_')[:20]
        
        return f"{clean_name}_{hash_digest}"
        
    async def _analyze_agent(self, name: str, code: str, 
                           description: Optional[str]) -> Dict[str, Any]:
        """Let LLM analyze agent for categorization and tagging"""
        
        analysis_prompt = f"""Analyze this agent for registration:

Name: {name}
Description: {description or 'Not provided'}
Code Preview:
```python
{code[:1500]}{'...' if len(code) > 1500 else ''}
```

Determine:
1. Concise description (if not provided)
2. Main capabilities (list 3-5)
3. Relevant tags (5-10 keywords)
4. Best category from: data_processing, api_integration, ml_ai, automation, 
   monitoring, security, communication, database, file_operations, web_scraping,
   analytics, testing, deployment, general

Format as JSON:
{{
  "description": "concise description",
  "capabilities": ["capability1", "capability2", ...],
  "tags": ["tag1", "tag2", ...],
  "category": "category_name"
}}"""
        
        response = await self.llm.generate(
            analysis_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Parse response
        try:
            analysis = json.loads(response)
        except:
            # Let LLM fix JSON
            fix_prompt = f"""Fix this JSON:
{response}

Valid JSON with description, capabilities, tags, category:"""
            
            fixed = await self.llm.generate(
                fix_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.1
            )
            
            try:
                analysis = json.loads(fixed)
            except:
                # Fallback
                analysis = {
                    'description': description or f'Agent for {name}',
                    'capabilities': ['general processing'],
                    'tags': [name.lower()],
                    'category': 'general'
                }
                
        return analysis
        
    def _save_agent(self, agent: RegisteredAgent):
        """Save agent to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO agents VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            agent.id,
            agent.name,
            agent.description,
            agent.code,
            agent.template_used,
            json.dumps(agent.capabilities),
            json.dumps(agent.tags),
            agent.category,
            agent.version,
            agent.created_at.isoformat(),
            agent.updated_at.isoformat(),
            agent.created_by,
            agent.status,
            agent.performance_score,
            agent.usage_count,
            agent.parent_agent_id,
            json.dumps(agent.metadata)
        ))
        
        conn.commit()
        conn.close()
        
    async def search_agents(self, 
                          query: str,
                          category: Optional[str] = None,
                          tags: Optional[List[str]] = None,
                          limit: int = 10) -> List[SearchResult]:
        """
        Search for agents using LLM-powered semantic search.
        
        Args:
            query: Search query
            category: Filter by category
            tags: Filter by tags
            limit: Maximum results
            
        Returns:
            List of search results
        """
        # Get candidate agents
        candidates = []
        
        if category:
            # Filter by category
            agent_ids = self.categories.get(category, [])
            candidates = [self.agents[aid] for aid in agent_ids if aid in self.agents]
        elif tags:
            # Filter by tags
            agent_ids = set()
            for tag in tags:
                agent_ids.update(self.tag_index.get(tag, []))
            candidates = [self.agents[aid] for aid in agent_ids if aid in self.agents]
        else:
            # All active agents
            candidates = [a for a in self.agents.values() if a.status == 'active']
            
        if not candidates:
            return []
            
        # Let LLM rank candidates
        results = await self._rank_agents(query, candidates, limit)
        
        return results
        
    async def _rank_agents(self, 
                         query: str,
                         candidates: List[RegisteredAgent],
                         limit: int) -> List[SearchResult]:
        """Let LLM rank agents by relevance"""
        
        # Prepare candidate summaries
        candidate_info = []
        for agent in candidates[:20]:  # Limit for LLM context
            candidate_info.append({
                'id': agent.id,
                'name': agent.name,
                'description': agent.description,
                'capabilities': agent.capabilities,
                'tags': agent.tags,
                'category': agent.category
            })
            
        rank_prompt = f"""Rank these agents by relevance to the query:

Query: {query}

Candidates:
{json.dumps(candidate_info, indent=2)}

Rank the top {min(limit, len(candidates))} most relevant agents.
For each, provide:
1. agent_id
2. relevance_score (0-100)
3. match_reason (why it matches)

Format as JSON array sorted by relevance:"""
        
        response = await self.llm.generate(
            rank_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Parse rankings
        try:
            rankings = json.loads(response)
            if not isinstance(rankings, list):
                rankings = []
        except:
            rankings = []
            
        # Create search results
        results = []
        seen_ids = set()
        
        for ranking in rankings:
            if isinstance(ranking, dict) and 'agent_id' in ranking:
                agent_id = ranking['agent_id']
                
                if agent_id in self.agents and agent_id not in seen_ids:
                    seen_ids.add(agent_id)
                    
                    results.append(SearchResult(
                        agent=self.agents[agent_id],
                        relevance_score=float(ranking.get('relevance_score', 50)),
                        match_reason=ranking.get('match_reason', 'Matched query')
                    ))
                    
        # Sort by relevance score
        results.sort(key=lambda x: x.relevance_score, reverse=True)
        
        return results[:limit]
        
    async def recommend_agent(self,
                            requirements: Dict[str, Any],
                            context: Optional[Dict[str, Any]] = None) -> Optional[RegisteredAgent]:
        """
        Let LLM recommend the best agent for given requirements.
        
        Args:
            requirements: Task requirements
            context: Additional context
            
        Returns:
            Recommended agent or None
        """
        # Search for relevant agents
        search_query = requirements.get('description', '') or json.dumps(requirements)
        search_results = await self.search_agents(search_query, limit=5)
        
        if not search_results:
            return None
            
        # Let LLM choose the best one
        recommend_prompt = f"""Choose the best agent for these requirements:

Requirements:
{json.dumps(requirements, indent=2)}

Context:
{json.dumps(context or {}, indent=2)}

Available Agents:
{json.dumps([r.to_dict() for r in search_results], indent=2)}

Which agent best fits the requirements? Consider:
1. Capability match
2. Performance history
3. Specialization fit

Respond with the agent_id of the best match, or 'none' if no good match:"""
        
        response = await self.llm.generate(
            recommend_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.2
        )
        
        # Extract agent ID
        agent_id = response.strip().lower()
        
        if agent_id == 'none':
            return None
            
        # Find the agent
        for result in search_results:
            if result.agent.id.lower() in agent_id or agent_id in result.agent.id.lower():
                return result.agent
                
        # Return top result if no specific match
        return search_results[0].agent if search_results else None
        
    async def update_agent_status(self,
                                agent_id: str,
                                status: str,
                                reason: Optional[str] = None):
        """Update agent status (active, deprecated, testing)"""
        
        if agent_id not in self.agents:
            return
            
        agent = self.agents[agent_id]
        agent.status = status
        agent.updated_at = datetime.now()
        
        if reason:
            agent.metadata['status_change_reason'] = reason
            agent.metadata['status_change_date'] = datetime.now().isoformat()
            
        self._save_agent(agent)
        
        logger.info(f"Updated agent {agent_id} status to {status}")
        
    def update_performance_score(self, agent_id: str, score: float):
        """Update agent performance score"""
        
        if agent_id not in self.agents:
            return
            
        agent = self.agents[agent_id]
        agent.performance_score = score
        agent.updated_at = datetime.now()
        
        self._save_agent(agent)
        
    def increment_usage_count(self, agent_id: str):
        """Increment agent usage count"""
        
        if agent_id not in self.agents:
            return
            
        agent = self.agents[agent_id]
        agent.usage_count += 1
        agent.updated_at = datetime.now()
        
        self._save_agent(agent)
        
    def get_agent(self, agent_id: str) -> Optional[RegisteredAgent]:
        """Get agent by ID"""
        return self.agents.get(agent_id)
        
    def get_agent_code(self, agent_id: str) -> Optional[str]:
        """Get agent code by ID"""
        agent = self.agents.get(agent_id)
        return agent.code if agent else None
        
    def list_categories(self) -> List[Tuple[str, int]]:
        """List all categories with agent counts"""
        return [(cat, len(agents)) for cat, agents in self.categories.items()]
        
    def list_popular_tags(self, limit: int = 20) -> List[Tuple[str, int]]:
        """List popular tags with usage counts"""
        tag_counts = [(tag, len(agents)) for tag, agents in self.tag_index.items()]
        tag_counts.sort(key=lambda x: x[1], reverse=True)
        return tag_counts[:limit]
        
    async def suggest_similar_agents(self,
                                   agent_id: str,
                                   limit: int = 5) -> List[RegisteredAgent]:
        """Let LLM suggest similar agents"""
        
        if agent_id not in self.agents:
            return []
            
        agent = self.agents[agent_id]
        
        # Get agents in same category
        category_agents = [
            self.agents[aid] 
            for aid in self.categories.get(agent.category, [])
            if aid != agent_id and aid in self.agents
        ]
        
        if not category_agents:
            return []
            
        # Let LLM find similar ones
        similar_prompt = f"""Find agents similar to this one:

Target Agent:
{json.dumps({
    'name': agent.name,
    'description': agent.description,
    'capabilities': agent.capabilities,
    'tags': agent.tags
}, indent=2)}

Candidates:
{json.dumps([{
    'id': a.id,
    'name': a.name,
    'description': a.description,
    'capabilities': a.capabilities
} for a in category_agents[:15]], indent=2)}

Select up to {limit} most similar agents. Consider:
1. Capability overlap
2. Use case similarity
3. Complementary features

List agent IDs of similar agents:"""
        
        response = await self.llm.generate(
            similar_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.4
        )
        
        # Extract agent IDs
        similar_agents = []
        
        for line in response.split('\n'):
            line = line.strip()
            
            for candidate in category_agents:
                if candidate.id in line:
                    similar_agents.append(candidate)
                    break
                    
        return similar_agents[:limit]
        
    def get_statistics(self) -> Dict[str, Any]:
        """Get registry statistics"""
        
        total_agents = len(self.agents)
        active_agents = sum(1 for a in self.agents.values() if a.status == 'active')
        
        # Category distribution
        category_dist = {
            cat: len(agents) 
            for cat, agents in self.categories.items()
        }
        
        # Performance distribution
        performance_scores = [
            a.performance_score 
            for a in self.agents.values() 
            if a.performance_score > 0
        ]
        
        avg_performance = sum(performance_scores) / len(performance_scores) if performance_scores else 0
        
        # Usage statistics
        total_usage = sum(a.usage_count for a in self.agents.values())
        
        return {
            'total_agents': total_agents,
            'active_agents': active_agents,
            'categories': category_dist,
            'average_performance': avg_performance,
            'total_usage': total_usage,
            'popular_tags': self.list_popular_tags(10),
            'most_used_agents': sorted(
                [(a.name, a.usage_count) for a in self.agents.values()],
                key=lambda x: x[1],
                reverse=True
            )[:10]
        }