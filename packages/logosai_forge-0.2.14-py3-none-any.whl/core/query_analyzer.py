"""
Query Analyzer for FORGE AI

Analyzes user queries to understand intent, extract requirements,
and identify necessary agent capabilities.
"""

from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import logging
import json
import re

from .llm_orchestrator import LLMOrchestrator, TaskType

logger = logging.getLogger(__name__)


class Complexity(Enum):
    """Query complexity levels"""
    SIMPLE = "simple"      # Single task, clear requirements
    MEDIUM = "medium"      # Multiple steps, some ambiguity
    COMPLEX = "complex"    # Complex workflow, many requirements
    EXPERT = "expert"      # Requires domain expertise


class WorkflowType(Enum):
    """Types of agent workflows"""
    SINGLE_TASK = "single_task"
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    CONDITIONAL = "conditional"
    HYBRID = "hybrid"


@dataclass
class QueryAnalysis:
    """Result of query analysis"""
    query: str
    intent: str
    entities: Dict[str, List[str]] = field(default_factory=dict)
    required_capabilities: List[str] = field(default_factory=list)
    constraints: Dict[str, Any] = field(default_factory=dict)
    complexity: Complexity = Complexity.SIMPLE
    workflow_type: WorkflowType = WorkflowType.SINGLE_TASK
    domain: Optional[str] = None
    test_data: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    suggestions: List[str] = field(default_factory=list)
    requires_execution: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'query': self.query,
            'intent': self.intent,
            'entities': self.entities,
            'required_capabilities': self.required_capabilities,
            'constraints': self.constraints,
            'complexity': self.complexity.value,
            'workflow_type': self.workflow_type.value,
            'domain': self.domain,
            'test_data': self.test_data,
            'confidence': self.confidence,
            'suggestions': self.suggestions,
            'requires_execution': self.requires_execution
        }


class QueryAnalyzer:
    """Analyzes user queries for agent generation"""
    
    # Common capability patterns
    CAPABILITY_PATTERNS = {
        'database': ['database', 'db', 'sql', 'query', 'table', 'postgres', 'mysql', 'mongodb'],
        'api': ['api', 'endpoint', 'rest', 'http', 'request', 'webhook'],
        'file': ['file', 'csv', 'excel', 'json', 'xml', 'read', 'write', 'parse'],
        'scheduling': ['schedule', 'cron', 'daily', 'hourly', 'periodic', 'every'],
        'notification': ['email', 'alert', 'notify', 'send', 'message', 'slack', 'sms'],
        'data_processing': ['process', 'transform', 'analyze', 'calculate', 'aggregate'],
        'monitoring': ['monitor', 'track', 'watch', 'observe', 'detect'],
        'ml': ['predict', 'classify', 'model', 'train', 'machine learning', 'ai'],
        'web_scraping': ['scrape', 'extract', 'crawl', 'website', 'html'],
        'streaming': ['stream', 'real-time', 'live', 'continuous'],
        'integration': ['integrate', 'connect', 'sync', 'bridge'],
        'visualization': ['chart', 'graph', 'plot', 'dashboard', 'visualize']
    }
    
    # Domain indicators
    DOMAIN_PATTERNS = {
        'finance': ['trading', 'finance', 'payment', 'transaction', 'bank', 'stock', 'crypto', '주식', '금융', '거래', '투자'],
        'ecommerce': ['product', 'order', 'customer', 'cart', 'shop', 'inventory', '제품', '주문', '고객', '구매', '판매', '매출'],
        'healthcare': ['patient', 'medical', 'health', 'diagnosis', 'treatment', '환자', '의료', '건강', '진단', '치료'],
        'manufacturing': ['production', 'factory', 'assembly', 'quality', 'supply chain', '생산', '공장', '제조', '품질'],
        'marketing': ['campaign', 'lead', 'conversion', 'seo', 'advertising', '캠페인', '마케팅', '광고', '홍보'],
        'hr': ['employee', 'recruitment', 'payroll', 'attendance', 'performance', '직원', '채용', '급여', '인사'],
        'iot': ['sensor', 'device', 'telemetry', 'mqtt', 'industrial', '센서', '기기', '장치'],
        'data_processing': ['csv', 'excel', 'data', 'analysis', 'report', '데이터', '분석', '보고서', 'dataframe', 'pandas'],
        'document_processing': ['pdf', 'document', 'text', 'extract', 'contract', '문서', '계약서', '추출', 'ocr']
    }
    
    def __init__(self, llm_orchestrator: LLMOrchestrator):
        """
        Initialize the query analyzer.
        
        Args:
            llm_orchestrator: LLM orchestrator for analysis
        """
        self.llm = llm_orchestrator
        
    async def analyze(self, query: str) -> QueryAnalysis:
        """
        Analyze a user query comprehensively.
        
        Args:
            query: User's natural language query
            
        Returns:
            Comprehensive query analysis
        """
        analysis = QueryAnalysis(query=query, intent="")
        
        # Run all analysis tasks in parallel
        tasks = [
            self._extract_intent(query),
            self._extract_entities(query),
            self._identify_capabilities(query),
            self._assess_complexity(query),
            self._identify_domain(query),
            self._extract_constraints(query)
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Analysis task {i} failed: {result}")
            else:
                if i == 0:  # Intent
                    analysis.intent = result
                elif i == 1:  # Entities
                    analysis.entities = result
                elif i == 2:  # Capabilities
                    analysis.required_capabilities = result
                elif i == 3:  # Complexity
                    analysis.complexity, analysis.workflow_type = result
                elif i == 4:  # Domain
                    analysis.domain = result
                elif i == 5:  # Constraints
                    analysis.constraints = result
                    
        # Generate test data based on analysis
        analysis.test_data = await self._generate_test_data(analysis)
        
        # Calculate confidence score
        analysis.confidence = self._calculate_confidence(analysis)
        
        # Generate suggestions
        analysis.suggestions = await self._generate_suggestions(analysis)
        
        # Check if execution is requested
        analysis.requires_execution = self._check_execution_request(query)
        
        logger.info(f"Query analysis complete: {analysis.intent} (confidence: {analysis.confidence:.2f})")
        
        return analysis
        
    async def _extract_intent(self, query: str) -> str:
        """Extract the main intent from the query"""
        
        prompt = f"""Analyze this query and identify the primary intent in a concise phrase (3-5 words).

Query: {query}

Examples of intents:
- "automate data processing"
- "monitor system health"
- "integrate external api"
- "schedule periodic tasks"
- "analyze customer behavior"

Primary intent:"""
        
        try:
            intent = await self.llm.generate(
                prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=50
            )
            return intent.strip().lower()
        except Exception as e:
            logger.error(f"Failed to extract intent: {e}")
            return "create agent"
            
    async def _extract_entities(self, query: str) -> Dict[str, List[str]]:
        """Extract named entities and key terms"""
        
        prompt = f"""Extract key entities from this query and categorize them.

Query: {query}

Categories to consider:
- data_sources: databases, files, APIs, streams
- actions: process, analyze, monitor, alert
- targets: where to send results
- conditions: when/if statements
- timeframes: scheduling, frequencies

Format as JSON with categories as keys and lists of entities as values:"""
        
        try:
            response = await self.llm.generate(
                prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=300
            )
            
            # Try to parse JSON
            try:
                entities = json.loads(response)
                return entities
            except:
                # Fallback to simple extraction
                return self._extract_entities_fallback(query)
                
        except Exception as e:
            logger.error(f"Failed to extract entities: {e}")
            return self._extract_entities_fallback(query)
            
    def _extract_entities_fallback(self, query: str) -> Dict[str, List[str]]:
        """Fallback entity extraction using patterns"""
        entities = {
            'data_sources': [],
            'actions': [],
            'targets': [],
            'conditions': [],
            'timeframes': []
        }
        
        # Simple pattern matching
        query_lower = query.lower()
        
        # Data sources
        for pattern in ['database', 'api', 'file', 'csv', 'json']:
            if pattern in query_lower:
                entities['data_sources'].append(pattern)
                
        # Actions
        for pattern in ['process', 'analyze', 'monitor', 'send', 'alert', 'transform']:
            if pattern in query_lower:
                entities['actions'].append(pattern)
                
        # Timeframes
        for pattern in ['daily', 'hourly', 'every', 'schedule', 'periodic']:
            if pattern in query_lower:
                entities['timeframes'].append(pattern)
                
        return entities
        
    async def _identify_capabilities(self, query: str) -> List[str]:
        """Identify required agent capabilities"""
        
        # First, use pattern matching
        capabilities = set()
        query_lower = query.lower()
        
        for capability, patterns in self.CAPABILITY_PATTERNS.items():
            if any(pattern in query_lower for pattern in patterns):
                capabilities.add(capability)
                
        # Then, use LLM for deeper analysis
        prompt = f"""Based on this query, what capabilities does the agent need?

Query: {query}

Available capabilities:
- database: Database connections and queries
- api: API integration and HTTP requests
- file: File reading/writing
- scheduling: Scheduled/periodic execution
- notification: Sending alerts/emails
- data_processing: Data transformation and analysis
- monitoring: System/data monitoring
- ml: Machine learning capabilities
- web_scraping: Web data extraction
- streaming: Real-time data processing
- integration: System integration
- visualization: Data visualization

List the required capabilities (one per line):"""
        
        try:
            response = await self.llm.generate(
                prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=200
            )
            
            # Parse response
            for line in response.strip().split('\n'):
                line = line.strip().lower()
                for capability in self.CAPABILITY_PATTERNS.keys():
                    if capability in line:
                        capabilities.add(capability)
                        
        except Exception as e:
            logger.error(f"Failed to identify capabilities via LLM: {e}")
            
        return sorted(list(capabilities))
        
    async def _assess_complexity(self, query: str) -> tuple:
        """Assess query complexity and workflow type"""
        
        prompt = f"""Analyze the complexity and workflow type of this query.

Query: {query}

Complexity levels:
- simple: Single clear task, straightforward implementation
- medium: Multiple steps, some coordination needed
- complex: Many interconnected tasks, complex logic
- expert: Requires domain expertise, sophisticated algorithms

Workflow types:
- single_task: One main operation
- sequential: Steps that must run in order
- parallel: Tasks that can run simultaneously
- conditional: Different paths based on conditions
- hybrid: Mix of sequential and parallel

Provide your assessment as:
Complexity: [level]
Workflow: [type]
Reasoning: [brief explanation]"""
        
        try:
            response = await self.llm.generate(
                prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=200
            )
            
            # Parse response
            complexity = Complexity.SIMPLE
            workflow = WorkflowType.SINGLE_TASK
            
            response_lower = response.lower()
            
            # Extract complexity
            for level in Complexity:
                if level.value in response_lower:
                    complexity = level
                    break
                    
            # Extract workflow
            for wf_type in WorkflowType:
                if wf_type.value in response_lower:
                    workflow = wf_type
                    break
                    
            return complexity, workflow
            
        except Exception as e:
            logger.error(f"Failed to assess complexity: {e}")
            # Fallback assessment based on query length and keywords
            if len(query) > 200 or any(word in query.lower() for word in ['multiple', 'complex', 'sophisticated']):
                return Complexity.COMPLEX, WorkflowType.HYBRID
            elif any(word in query.lower() for word in ['then', 'after', 'sequence']):
                return Complexity.MEDIUM, WorkflowType.SEQUENTIAL
            else:
                return Complexity.SIMPLE, WorkflowType.SINGLE_TASK
                
    async def _identify_domain(self, query: str) -> Optional[str]:
        """Identify the business domain"""
        
        # Pattern matching first
        query_lower = query.lower()
        
        # Count matches for each domain
        domain_scores = {}
        for domain, patterns in self.DOMAIN_PATTERNS.items():
            score = sum(1 for pattern in patterns if pattern in query_lower)
            if score > 0:
                domain_scores[domain] = score
        
        # Return domain with highest score
        if domain_scores:
            best_domain = max(domain_scores.items(), key=lambda x: x[1])
            return best_domain[0]
                
        # LLM analysis for unclear cases
        prompt = f"""Identify the business domain for this query:

Query: {query}

Common domains: finance, ecommerce, healthcare, manufacturing, marketing, hr, iot, data_processing, document_processing, general

Domain:"""
        
        try:
            domain = await self.llm.generate(
                prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=20
            )
            
            domain = domain.strip().lower()
            if domain in self.DOMAIN_PATTERNS.keys() or domain == 'general':
                return domain
                
        except Exception as e:
            logger.error(f"Failed to identify domain: {e}")
            
        # Default to general if no specific domain found
        return 'general'
        
    async def _extract_constraints(self, query: str) -> Dict[str, Any]:
        """Extract constraints and requirements"""
        
        prompt = f"""Extract specific constraints and requirements from this query.

Query: {query}

Look for:
- Performance requirements (speed, latency, throughput)
- Resource constraints (memory, CPU)
- Security requirements
- Compliance needs
- Error handling preferences
- Output format requirements

Format as JSON with constraint types as keys:"""
        
        try:
            response = await self.llm.generate(
                prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=300
            )
            
            try:
                constraints = json.loads(response)
                return constraints
            except:
                return {}
                
        except Exception as e:
            logger.error(f"Failed to extract constraints: {e}")
            return {}
            
    async def _generate_test_data(self, analysis: QueryAnalysis) -> Dict[str, Any]:
        """Generate sample test data based on analysis"""
        
        test_data = {
            'sample_input': {},
            'expected_output_format': {},
            'test_scenarios': []
        }
        
        # Generate based on capabilities
        if 'database' in analysis.required_capabilities:
            test_data['sample_input']['db_query'] = "SELECT * FROM users WHERE active = true"
            
        if 'api' in analysis.required_capabilities:
            test_data['sample_input']['api_endpoint'] = "https://api.example.com/data"
            test_data['sample_input']['api_method'] = "GET"
            
        if 'file' in analysis.required_capabilities:
            test_data['sample_input']['file_path'] = "/data/input.csv"
            
        # Add domain-specific test data
        if analysis.domain == 'ecommerce':
            test_data['sample_input']['order_id'] = "ORD-12345"
            test_data['sample_input']['customer_id'] = "CUST-67890"
            
        return test_data
        
    def _calculate_confidence(self, analysis: QueryAnalysis) -> float:
        """Calculate confidence score for the analysis"""
        
        confidence = 0.5  # Base confidence
        
        # Adjust based on clarity indicators
        if analysis.intent and len(analysis.intent) > 3:
            confidence += 0.1
            
        if len(analysis.required_capabilities) > 0:
            confidence += 0.1
            
        if analysis.domain:
            confidence += 0.1
            
        if analysis.entities and any(analysis.entities.values()):
            confidence += 0.1
            
        if analysis.complexity != Complexity.EXPERT:
            confidence += 0.1
            
        return min(confidence, 1.0)
        
    async def _generate_suggestions(self, analysis: QueryAnalysis) -> List[str]:
        """Generate suggestions for improving the agent"""
        
        suggestions = []
        
        # Capability-based suggestions
        if 'database' in analysis.required_capabilities and 'data_processing' not in analysis.required_capabilities:
            suggestions.append("Consider adding data validation before database operations")
            
        if 'api' in analysis.required_capabilities:
            suggestions.append("Implement retry logic for API calls")
            
        if analysis.workflow_type == WorkflowType.PARALLEL:
            suggestions.append("Use connection pooling for better performance")
            
        if not analysis.constraints.get('error_handling'):
            suggestions.append("Define clear error handling strategy")
            
        # Complexity-based suggestions
        if analysis.complexity in [Complexity.COMPLEX, Complexity.EXPERT]:
            suggestions.append("Consider breaking down into smaller, modular agents")
            suggestions.append("Add comprehensive logging for debugging")
            
        return suggestions
    
    def _check_execution_request(self, query: str) -> bool:
        """Check if the query requests immediate execution"""
        
        execution_keywords = [
            'execute', 'run', 'start', 'launch', 'activate',
            'and execute', 'and run', 'then execute', 'then run',
            '실행', '돌려', '시작'  # Korean keywords
        ]
        
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in execution_keywords)