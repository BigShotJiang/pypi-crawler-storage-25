"""
Enhanced Query Analyzer for FORGE AI System
향상된 쿼리 분석 시스템 - 더 정확한 에이전트 타입 감지와 기능 추출
"""

import re
import json
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class AgentIntent(Enum):
    """에이전트 의도 분류"""
    DATA_PROCESSING = "data_processing"
    API_INTEGRATION = "api_integration"
    AUTOMATION = "automation"
    ANALYSIS = "analysis"
    MONITORING = "monitoring"
    CHATBOT = "chatbot"
    PREDICTION = "prediction"
    OPTIMIZATION = "optimization"
    VISUALIZATION = "visualization"
    SECURITY = "security"


class AgentDomain(Enum):
    """에이전트 도메인 분류"""
    FINANCE = "finance"
    HEALTHCARE = "healthcare"
    ECOMMERCE = "ecommerce"
    EDUCATION = "education"
    ENTERTAINMENT = "entertainment"
    REAL_ESTATE = "real_estate"
    MANUFACTURING = "manufacturing"
    LOGISTICS = "logistics"
    MARKETING = "marketing"
    GENERAL = "general"


@dataclass
class QueryAnalysisResult:
    """쿼리 분석 결과"""
    intent: AgentIntent
    domain: AgentDomain
    features: List[str]
    complexity_score: float
    confidence_score: float
    suggested_template: str
    extracted_entities: Dict[str, List[str]]
    required_libraries: List[str]
    estimated_code_size: int


class EnhancedQueryAnalyzer:
    """향상된 쿼리 분석기"""
    
    def __init__(self):
        self._initialize_patterns()
        self._initialize_keywords()
        
    def _initialize_patterns(self):
        """패턴 초기화"""
        # 의도 패턴
        self.intent_patterns = {
            AgentIntent.DATA_PROCESSING: [
                r"데이터.*처리", r"파싱", r"변환", r"추출", r"정제",
                r"process.*data", r"parse", r"transform", r"extract", r"clean"
            ],
            AgentIntent.API_INTEGRATION: [
                r"API.*호출", r"연동", r"통합", r"REST", r"webhook",
                r"API.*call", r"integrate", r"endpoint", r"서비스.*연결"
            ],
            AgentIntent.AUTOMATION: [
                r"자동화", r"스케줄", r"반복", r"배치", r"워크플로우",
                r"automat", r"schedule", r"batch", r"workflow", r"trigger"
            ],
            AgentIntent.ANALYSIS: [
                r"분석", r"통계", r"리포트", r"인사이트", r"패턴.*찾",
                r"analyz", r"statistic", r"report", r"insight", r"pattern"
            ],
            AgentIntent.MONITORING: [
                r"모니터링", r"감시", r"추적", r"알림", r"상태.*체크",
                r"monitor", r"watch", r"track", r"alert", r"status"
            ],
            AgentIntent.CHATBOT: [
                r"챗봇", r"대화", r"응답", r"질문.*답", r"고객.*서비스",
                r"chatbot", r"conversation", r"response", r"Q&A", r"customer.*service"
            ],
            AgentIntent.PREDICTION: [
                r"예측", r"예상", r"추정", r"전망", r"모델링",
                r"predict", r"forecast", r"estimate", r"projection", r"model"
            ],
            AgentIntent.OPTIMIZATION: [
                r"최적화", r"개선", r"효율", r"성능.*향상", r"튜닝",
                r"optimiz", r"improve", r"efficien", r"performance", r"tuning"
            ],
            AgentIntent.VISUALIZATION: [
                r"시각화", r"차트", r"그래프", r"대시보드", r"플롯",
                r"visualiz", r"chart", r"graph", r"dashboard", r"plot"
            ],
            AgentIntent.SECURITY: [
                r"보안", r"인증", r"암호화", r"접근.*제어", r"감사",
                r"security", r"authenticat", r"encrypt", r"access.*control", r"audit"
            ]
        }
        
        # 도메인 패턴
        self.domain_patterns = {
            AgentDomain.FINANCE: [
                r"주식", r"투자", r"트레이딩", r"금융", r"은행", r"결제", r"매매",
                r"stock", r"invest", r"trading", r"finance", r"bank", r"payment"
            ],
            AgentDomain.HEALTHCARE: [
                r"의료", r"건강", r"병원", r"환자", r"진단", r"처방",
                r"medical", r"health", r"hospital", r"patient", r"diagnos", r"prescription"
            ],
            AgentDomain.ECOMMERCE: [
                r"쇼핑", r"상품", r"주문", r"배송", r"장바구니", r"결제",
                r"shopping", r"product", r"order", r"delivery", r"cart", r"checkout"
            ],
            AgentDomain.EDUCATION: [
                r"교육", r"학습", r"강의", r"학생", r"교사", r"시험",
                r"education", r"learning", r"course", r"student", r"teacher", r"exam"
            ],
            AgentDomain.REAL_ESTATE: [
                r"부동산", r"매물", r"임대", r"매매", r"아파트", r"주택",
                r"real.*estate", r"property", r"rent", r"housing", r"apartment"
            ],
            AgentDomain.MANUFACTURING: [
                r"제조", r"생산", r"공장", r"품질", r"공정", r"재고",
                r"manufactur", r"production", r"factory", r"quality", r"process", r"inventory"
            ],
            AgentDomain.MARKETING: [
                r"마케팅", r"광고", r"캠페인", r"고객", r"타겟", r"프로모션",
                r"marketing", r"advertis", r"campaign", r"customer", r"target", r"promotion"
            ]
        }
        
    def _initialize_keywords(self):
        """키워드 초기화"""
        # 기능 키워드
        self.feature_keywords = {
            "database": ["데이터베이스", "DB", "SQL", "쿼리", "테이블", "database", "query"],
            "web_scraping": ["크롤링", "스크래핑", "웹.*수집", "crawl", "scrap", "web.*collect"],
            "machine_learning": ["머신러닝", "딥러닝", "학습", "훈련", "모델", "AI", "ML", "deep.*learning"],
            "real_time": ["실시간", "리얼타임", "스트리밍", "real.*time", "stream", "live"],
            "batch_processing": ["배치", "대량", "일괄", "batch", "bulk", "mass"],
            "notification": ["알림", "노티", "푸시", "이메일", "notification", "alert", "push", "email"],
            "file_processing": ["파일", "문서", "PDF", "엑셀", "CSV", "file", "document", "excel"],
            "image_processing": ["이미지", "사진", "영상", "비디오", "CV", "image", "photo", "video", "computer.*vision"],
            "nlp": ["자연어", "텍스트", "NLP", "감정.*분석", "natural.*language", "text", "sentiment"],
            "api": ["API", "REST", "GraphQL", "웹훅", "endpoint", "webhook"],
        }
        
        # 라이브러리 매핑
        self.library_mapping = {
            "database": ["sqlite3", "psycopg2", "pymongo", "sqlalchemy"],
            "web_scraping": ["requests", "beautifulsoup4", "selenium", "scrapy"],
            "machine_learning": ["scikit-learn", "tensorflow", "torch", "transformers"],
            "data_analysis": ["pandas", "numpy", "scipy", "statsmodels"],
            "visualization": ["matplotlib", "seaborn", "plotly", "bokeh"],
            "nlp": ["nltk", "spacy", "transformers", "konlpy"],
            "image_processing": ["opencv-python", "PIL", "scikit-image"],
            "api": ["fastapi", "flask", "aiohttp", "requests"],
        }
        
    def analyze_query(self, query: str) -> QueryAnalysisResult:
        """쿼리 분석 메인 함수"""
        query_lower = query.lower()
        
        # 1. 의도 감지
        intent, intent_confidence = self._detect_intent(query_lower)
        
        # 2. 도메인 추출
        domain, domain_confidence = self._extract_domain(query_lower)
        
        # 3. 기능 추출
        features = self._extract_features(query_lower)
        
        # 4. 엔티티 추출
        entities = self._extract_entities(query)
        
        # 5. 복잡도 평가
        complexity = self._assess_complexity(query, features, entities)
        
        # 6. 필요 라이브러리 추정
        libraries = self._estimate_libraries(features, intent, domain)
        
        # 7. 템플릿 제안
        template = self._suggest_template(intent, domain, complexity)
        
        # 8. 예상 코드 크기
        code_size = self._estimate_code_size(complexity, features)
        
        # 전체 신뢰도 계산
        confidence = (intent_confidence + domain_confidence) / 2
        
        return QueryAnalysisResult(
            intent=intent,
            domain=domain,
            features=features,
            complexity_score=complexity,
            confidence_score=confidence,
            suggested_template=template,
            extracted_entities=entities,
            required_libraries=libraries,
            estimated_code_size=code_size
        )
    
    def _detect_intent(self, query: str) -> Tuple[AgentIntent, float]:
        """의도 감지"""
        scores = {}
        
        for intent, patterns in self.intent_patterns.items():
            score = 0
            for pattern in patterns:
                if re.search(pattern, query, re.IGNORECASE):
                    score += 1
            scores[intent] = score
        
        if not scores or max(scores.values()) == 0:
            return AgentIntent.ANALYSIS, 0.3
        
        best_intent = max(scores, key=scores.get)
        confidence = min(scores[best_intent] / 3, 1.0)  # Normalize confidence
        
        return best_intent, confidence
    
    def _extract_domain(self, query: str) -> Tuple[AgentDomain, float]:
        """도메인 추출"""
        scores = {}
        
        for domain, patterns in self.domain_patterns.items():
            score = 0
            for pattern in patterns:
                if re.search(pattern, query, re.IGNORECASE):
                    score += 1
            scores[domain] = score
        
        if not scores or max(scores.values()) == 0:
            return AgentDomain.GENERAL, 0.5
        
        best_domain = max(scores, key=scores.get)
        confidence = min(scores[best_domain] / 2, 1.0)
        
        return best_domain, confidence
    
    def _extract_features(self, query: str) -> List[str]:
        """기능 추출"""
        features = []
        
        for feature, keywords in self.feature_keywords.items():
            for keyword in keywords:
                if re.search(keyword, query, re.IGNORECASE):
                    features.append(feature)
                    break
        
        return list(set(features))  # Remove duplicates
    
    def _extract_entities(self, query: str) -> Dict[str, List[str]]:
        """엔티티 추출"""
        entities = {
            "numbers": re.findall(r'\d+', query),
            "urls": re.findall(r'https?://[^\s]+', query),
            "emails": re.findall(r'[\w\.-]+@[\w\.-]+', query),
            "file_paths": re.findall(r'[./][\w/.-]+', query),
            "quoted_strings": re.findall(r'"([^"]*)"', query) + re.findall(r"'([^']*)'", query),
        }
        
        # Remove empty lists
        return {k: v for k, v in entities.items() if v}
    
    def _assess_complexity(self, query: str, features: List[str], entities: Dict) -> float:
        """복잡도 평가 (0.0 ~ 1.0)"""
        complexity = 0.0
        
        # 쿼리 길이 기반
        query_length = len(query)
        if query_length > 200:
            complexity += 0.2
        elif query_length > 100:
            complexity += 0.1
        
        # 기능 수 기반
        feature_count = len(features)
        complexity += min(feature_count * 0.15, 0.4)
        
        # 엔티티 수 기반
        entity_count = sum(len(v) for v in entities.values())
        complexity += min(entity_count * 0.05, 0.2)
        
        # 특정 복잡한 기능 체크
        complex_features = ["machine_learning", "real_time", "image_processing", "nlp"]
        for feature in features:
            if feature in complex_features:
                complexity += 0.1
        
        return min(complexity, 1.0)
    
    def _estimate_libraries(self, features: List[str], intent: AgentIntent, domain: AgentDomain) -> List[str]:
        """필요 라이브러리 추정"""
        libraries = set()
        
        # 기능별 라이브러리
        for feature in features:
            if feature in self.library_mapping:
                libraries.update(self.library_mapping[feature][:2])  # Top 2 libraries
        
        # 의도별 추가 라이브러리
        intent_libs = {
            AgentIntent.DATA_PROCESSING: ["pandas", "numpy"],
            AgentIntent.API_INTEGRATION: ["requests", "aiohttp"],
            AgentIntent.VISUALIZATION: ["matplotlib", "plotly"],
            AgentIntent.PREDICTION: ["scikit-learn", "tensorflow"],
        }
        
        if intent in intent_libs:
            libraries.update(intent_libs[intent][:1])
        
        return list(libraries)[:5]  # Limit to 5 libraries
    
    def _suggest_template(self, intent: AgentIntent, domain: AgentDomain, complexity: float) -> str:
        """템플릿 제안"""
        # 복잡도에 따른 템플릿 레벨
        if complexity > 0.7:
            level = "advanced"
        elif complexity > 0.4:
            level = "intermediate"
        else:
            level = "basic"
        
        # 템플릿 경로 생성
        template_path = f"{domain.value}/{intent.value}_{level}.py"
        
        return template_path
    
    def _estimate_code_size(self, complexity: float, features: List[str]) -> int:
        """예상 코드 크기 (문자 수)"""
        base_size = 3000  # 기본 템플릿 크기
        
        # 복잡도에 따른 추가
        complexity_addition = int(complexity * 15000)
        
        # 기능에 따른 추가
        feature_addition = len(features) * 1000
        
        estimated_size = base_size + complexity_addition + feature_addition
        
        return min(estimated_size, 30000)  # Max 30K characters


# 사용 예제
if __name__ == "__main__":
    analyzer = EnhancedQueryAnalyzer()
    
    # 테스트 쿼리
    test_queries = [
        "주식 시장 데이터를 실시간으로 수집하고, 기술적 분석 지표를 계산하며, 매매 신호를 생성하는 트레이딩 봇 에이전트",
        "고객 문의를 자동으로 분류하고, 감정 분석을 수행하며, 적절한 답변을 생성하는 고객 서비스 챗봇 에이전트",
        "이미지에서 객체를 탐지하고, 얼굴 인식을 수행하는 컴퓨터 비전 에이전트"
    ]
    
    for query in test_queries:
        result = analyzer.analyze_query(query)
        print(f"\nQuery: {query[:50]}...")
        print(f"Intent: {result.intent.value}")
        print(f"Domain: {result.domain.value}")
        print(f"Features: {result.features}")
        print(f"Complexity: {result.complexity_score:.2f}")
        print(f"Confidence: {result.confidence_score:.2f}")
        print(f"Template: {result.suggested_template}")
        print(f"Libraries: {result.required_libraries}")
        print(f"Est. Size: {result.estimated_code_size:,} chars")
        print("-" * 50)