"""
FunctionExtractor + FunctionRegistrar — Self-Growing Function Library.

After FORGE generates an agent, this module:
1. Extracts reusable functions (AST + reusability scoring)
2. Converts to template format
3. Auto-registers in registry.json
4. Prevents duplicates

Result: FORGE가 에이전트를 만들수록 함수 라이브러리가 자동으로 풍부해진다.
"""

import ast
import re
import json
from typing import Dict, Any, List
from pathlib import Path
from loguru import logger


class FunctionExtractor:
    """Extract reusable functions from generated agent code."""

    SKIP_METHODS = {"process", "shutdown", "__init__", "_process_core_logic",
                    "_execute", "execute_workflow", "_setup_agentic_modules",
                    "_execute_react_action"}

    def extract_reusable_functions(self, agent_code: str) -> List[Dict]:
        """AST-based extraction + reusability scoring."""
        try:
            tree = ast.parse(agent_code)
        except SyntaxError:
            return []

        lines = agent_code.split("\n")
        candidates = []

        for node in ast.walk(tree):
            if not isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)):
                continue
            name = node.name
            if name in self.SKIP_METHODS or not name.startswith("_"):
                continue

            start = node.lineno - 1
            end = node.end_lineno if hasattr(node, "end_lineno") else start + 1
            func_code = "\n".join(lines[start:end])

            score = self._evaluate_reusability(name, func_code)
            if score >= 0.6:
                candidates.append({
                    "function_name": name,
                    "code": func_code,
                    "reusability_score": round(score, 2),
                    "category": self._guess_category(name, func_code),
                    "keywords": self._extract_keywords(name, func_code),
                    "lines": end - start,
                })

        return candidates

    def _evaluate_reusability(self, name: str, code: str) -> float:
        score = 0.5
        if any(w in name for w in ["extract", "validate", "parse", "calculate",
                                    "format", "convert", "search", "filter", "sanitize"]):
            score += 0.2
        self_calls = len(re.findall(r"self\._\w+", code))
        if self_calls <= 1:
            score += 0.15
        elif self_calls >= 5:
            score -= 0.2
        lines = len(code.split("\n"))
        if 5 <= lines <= 50:
            score += 0.1
        if "import " in code:
            score += 0.05
        return min(score, 1.0)

    def _guess_category(self, name: str, code: str) -> str:
        if any(w in name for w in ["email", "phone", "url", "date", "name", "parse", "extract"]):
            return "parsing"
        if any(w in name for w in ["calculate", "compute", "score"]):
            return "calculation"
        if any(w in name for w in ["validate", "check", "verify"]):
            return "validation"
        if any(w in name for w in ["format", "convert", "transform"]):
            return "transformation"
        if any(w in name for w in ["search", "find", "filter"]):
            return "search"
        return "utility"

    def _extract_keywords(self, name: str, code: str) -> List[str]:
        words = re.findall(r"[a-z]+", name)
        imports = re.findall(r"import (\w+)", code)
        return list(set(words + imports))


class FunctionRegistrar:
    """Auto-register reusable functions to registry.json."""

    def __init__(self, registry_path: str = None):
        if registry_path is None:
            registry_path = str(Path(__file__).parent.parent / "templates" / "functions" / "registry.json")
        self.registry_path = registry_path

    def register(self, func_info: Dict, func_code: str) -> Dict:
        """Register function to registry.json (with duplicate check)."""
        try:
            with open(self.registry_path) as f:
                data = json.load(f)
        except Exception:
            return {"action": "error", "reason": "cannot read registry"}

        key = f"{func_info['category']}_{func_info['function_name'].lstrip('_')}"

        if key in data["templates"]:
            return {"action": "skip", "reason": "already exists"}

        data["templates"][key] = {
            "id": f"{func_info['category']}.auto.{func_info['function_name'].lstrip('_')}",
            "category": func_info["category"],
            "file": f"{func_info['category']}/auto_generated.py",
            "function": func_info["function_name"].lstrip("_"),
            "keywords": func_info.get("keywords", []),
            "required_imports": [],
            "parameters": {},
            "returns": "Dict",
            "description": f"Auto-registered: {func_info['function_name']}",
            "source": "auto_extraction",
            "reusability_score": func_info.get("reusability_score", 0),
        }

        try:
            with open(self.registry_path, 'w') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            logger.info(f"[AutoReg] Registered {key} (score={func_info.get('reusability_score', 0)})")
            return {"action": "registered", "key": key}
        except Exception as e:
            return {"action": "error", "reason": str(e)}

    def auto_register_from_agent(self, agent_code: str) -> List[Dict]:
        """Extract + register all reusable functions from agent code."""
        extractor = FunctionExtractor()
        candidates = extractor.extract_reusable_functions(agent_code)

        results = []
        for c in candidates:
            result = self.register(c, c["code"])
            results.append({"function": c["function_name"], **result})
            if result["action"] == "registered":
                # Also register version in FunctionRegistry
                try:
                    from core.function_registry import FunctionRegistry
                    registry = FunctionRegistry.get_instance()
                    registry.register_version(c["function_name"], c["code"],
                                               quality_score=c["reusability_score"],
                                               change_reason="auto-extracted from agent")
                except Exception:
                    pass

        return results
