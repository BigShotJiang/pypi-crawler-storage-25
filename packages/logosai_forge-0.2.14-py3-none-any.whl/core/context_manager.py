"""
Context Manager for FORGE AI

Manages conversational context and interactive information gathering.
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import asyncio
import logging
import json

from .llm_orchestrator import LLMOrchestrator, TaskType

logger = logging.getLogger(__name__)


@dataclass
class Context:
    """Represents a conversation context"""
    session_id: str
    user_query: str
    intent: Optional[str] = None
    gathered_info: Dict[str, Any] = field(default_factory=dict)
    missing_info: List[str] = field(default_factory=list)
    clarifications: List[Dict[str, str]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def update(self, key: str, value: Any):
        """Update context information"""
        self.gathered_info[key] = value
        self.updated_at = datetime.now()
        
        # Remove from missing info if present
        if key in self.missing_info:
            self.missing_info.remove(key)
            
    def add_clarification(self, question: str, answer: str):
        """Add a clarification Q&A"""
        self.clarifications.append({
            'question': question,
            'answer': answer,
            'timestamp': datetime.now().isoformat()
        })
        self.updated_at = datetime.now()
        
    def is_complete(self) -> bool:
        """Check if all required information is gathered"""
        return len(self.missing_info) == 0
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'session_id': self.session_id,
            'user_query': self.user_query,
            'intent': self.intent,
            'gathered_info': self.gathered_info,
            'missing_info': self.missing_info,
            'clarifications': self.clarifications,
            'metadata': self.metadata,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }


class ContextManager:
    """Manages conversational context for agent generation"""
    
    def __init__(self, llm_orchestrator: LLMOrchestrator):
        """
        Initialize the context manager.
        
        Args:
            llm_orchestrator: LLM orchestrator for generating questions
        """
        self.llm = llm_orchestrator
        self.sessions: Dict[str, Context] = {}
        self.templates: Dict[str, List[str]] = self._load_question_templates()
        
    def _load_question_templates(self) -> Dict[str, List[str]]:
        """Load question templates for different types of missing info"""
        return {
            'database_config': [
                "What type of database will the agent connect to? (PostgreSQL, MySQL, MongoDB, etc.)",
                "What are the database connection details? (host, port, database name)",
                "Do you need connection pooling? If yes, what pool size?"
            ],
            'api_endpoint': [
                "What is the API endpoint URL?",
                "What authentication method does the API use? (API key, OAuth, Basic Auth)",
                "What data format does the API expect? (JSON, XML, Form data)"
            ],
            'data_format': [
                "What format is the input data in? (JSON, CSV, XML, etc.)",
                "Can you provide a sample of the data structure?",
                "Are there any required fields in the data?"
            ],
            'processing_logic': [
                "What specific processing should be performed on the data?",
                "Are there any business rules or conditions to apply?",
                "What should happen in case of errors?"
            ],
            'output_format': [
                "What format should the output be in?",
                "Where should the results be sent? (file, API, database, email)",
                "Should the output include metadata or just the processed data?"
            ],
            'performance_requirements': [
                "How much data will be processed? (volume/frequency)",
                "What are the performance requirements? (latency, throughput)",
                "Should processing be synchronous or asynchronous?"
            ],
            'error_handling': [
                "How should errors be handled? (retry, skip, fail)",
                "Should errors be logged? Where?",
                "Are there any alerts that should be triggered on errors?"
            ]
        }
        
    async def initialize_context(self, session_id: str, query: str) -> Context:
        """
        Initialize a new context for a session.
        
        Args:
            session_id: Unique session identifier
            query: User's initial query
            
        Returns:
            Initialized context
        """
        context = Context(
            session_id=session_id,
            user_query=query
        )
        
        # Extract initial intent
        intent_prompt = f"""Analyze this user query and identify the main intent in 2-3 words:

Query: {query}

Intent (2-3 words):"""
        
        try:
            intent = await self.llm.generate(
                intent_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=20
            )
            context.intent = intent.strip()
        except Exception as e:
            logger.error(f"Failed to extract intent: {e}")
            context.intent = "agent_creation"
            
        self.sessions[session_id] = context
        logger.info(f"Initialized context for session {session_id}: {context.intent}")
        
        return context
        
    async def identify_missing_info(self, session_id: str, 
                                  required_capabilities: List[str]) -> List[str]:
        """
        Identify missing information based on required capabilities.
        
        Args:
            session_id: Session ID
            required_capabilities: List of required agent capabilities
            
        Returns:
            List of missing information types
        """
        context = self.sessions.get(session_id)
        if not context:
            raise ValueError(f"No context found for session {session_id}")
            
        # Analyze what information is needed
        analysis_prompt = f"""Based on the user query and required capabilities, identify what information is missing.

User Query: {context.user_query}
Required Capabilities: {', '.join(required_capabilities)}
Already Gathered: {json.dumps(context.gathered_info, indent=2)}

List the missing information categories (one per line) from these options:
- database_config (if database connection needed)
- api_endpoint (if API integration needed)
- data_format (if data processing needed)
- processing_logic (if specific logic not clear)
- output_format (if output format not specified)
- performance_requirements (if performance critical)
- error_handling (if error handling not specified)

Missing information (one per line):"""
        
        try:
            response = await self.llm.generate(
                analysis_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=200
            )
            
            # Parse response
            missing = []
            for line in response.strip().split('\n'):
                line = line.strip().strip('- ').lower()
                if line and any(cat in line for cat in self.templates.keys()):
                    # Extract the category
                    for cat in self.templates.keys():
                        if cat in line:
                            missing.append(cat)
                            break
                            
            context.missing_info = missing
            logger.info(f"Identified missing info for {session_id}: {missing}")
            
        except Exception as e:
            logger.error(f"Failed to identify missing info: {e}")
            # Default missing info based on capabilities
            context.missing_info = self._default_missing_info(required_capabilities)
            
        return context.missing_info
        
    def _default_missing_info(self, capabilities: List[str]) -> List[str]:
        """Get default missing info based on capabilities"""
        missing = []
        
        capability_mapping = {
            'database': ['database_config'],
            'api': ['api_endpoint'],
            'data': ['data_format', 'processing_logic'],
            'file': ['data_format', 'output_format'],
            'stream': ['data_format', 'performance_requirements'],
            'alert': ['output_format', 'error_handling']
        }
        
        for cap in capabilities:
            for keyword, info_types in capability_mapping.items():
                if keyword in cap.lower():
                    missing.extend(info_types)
                    
        return list(set(missing))  # Remove duplicates
        
    async def generate_clarifying_questions(self, session_id: str) -> List[Dict[str, str]]:
        """
        Generate clarifying questions for missing information.
        
        Args:
            session_id: Session ID
            
        Returns:
            List of questions with metadata
        """
        context = self.sessions.get(session_id)
        if not context:
            raise ValueError(f"No context found for session {session_id}")
            
        questions = []
        
        for info_type in context.missing_info:
            # Get template questions
            template_questions = self.templates.get(info_type, [])
            
            # Generate contextual question
            contextual_prompt = f"""Based on the user's query, generate a natural clarifying question for {info_type}.

User Query: {context.user_query}
Information Needed: {info_type}
Example Questions: {', '.join(template_questions[:2])}

Generate a single, natural question that fits the context:"""
            
            try:
                question = await self.llm.generate(
                    contextual_prompt,
                    task_type=TaskType.CONVERSATION,
                    temperature=0.7,
                    max_tokens=100
                )
                
                questions.append({
                    'id': f"{session_id}_{info_type}",
                    'type': info_type,
                    'question': question.strip(),
                    'required': True,
                    'examples': template_questions[:2]
                })
                
            except Exception as e:
                logger.error(f"Failed to generate question for {info_type}: {e}")
                # Use template question as fallback
                if template_questions:
                    questions.append({
                        'id': f"{session_id}_{info_type}",
                        'type': info_type,
                        'question': template_questions[0],
                        'required': True,
                        'examples': template_questions[1:3]
                    })
                    
        return questions
        
    async def process_answer(self, session_id: str, question_id: str, 
                           answer: str) -> Context:
        """
        Process user's answer to a clarifying question.
        
        Args:
            session_id: Session ID
            question_id: Question identifier
            answer: User's answer
            
        Returns:
            Updated context
        """
        context = self.sessions.get(session_id)
        if not context:
            raise ValueError(f"No context found for session {session_id}")
            
        # Extract info type from question_id
        info_type = question_id.split('_')[-1]
        
        # Process and structure the answer
        structure_prompt = f"""Extract and structure the key information from this answer.

Question Type: {info_type}
User Answer: {answer}

Extract the relevant information and format it as JSON:"""
        
        try:
            structured = await self.llm.generate(
                structure_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3,
                max_tokens=200
            )
            
            # Try to parse as JSON
            try:
                info_dict = json.loads(structured)
            except:
                # Fallback to simple key-value
                info_dict = {info_type: answer}
                
            # Update context
            context.update(info_type, info_dict)
            
        except Exception as e:
            logger.error(f"Failed to process answer: {e}")
            # Simple update as fallback
            context.update(info_type, answer)
            
        # Add to clarifications
        context.add_clarification(
            question=f"Question about {info_type}",
            answer=answer
        )
        
        return context
        
    def get_context(self, session_id: str) -> Optional[Context]:
        """Get context for a session"""
        return self.sessions.get(session_id)
        
    def update_context(self, session_id: str, key: str, value: Any) -> Context:
        """Update context with new information"""
        context = self.sessions.get(session_id)
        if not context:
            raise ValueError(f"No context found for session {session_id}")
            
        context.update(key, value)
        return context
        
    async def summarize_context(self, session_id: str) -> str:
        """
        Generate a summary of the gathered context.
        
        Args:
            session_id: Session ID
            
        Returns:
            Context summary
        """
        context = self.sessions.get(session_id)
        if not context:
            raise ValueError(f"No context found for session {session_id}")
            
        summary_prompt = f"""Summarize the gathered information for agent creation:

Original Query: {context.user_query}
Intent: {context.intent}
Gathered Information: {json.dumps(context.gathered_info, indent=2)}
Clarifications: {json.dumps(context.clarifications, indent=2)}

Provide a concise summary of what agent needs to be created:"""
        
        try:
            summary = await self.llm.generate(
                summary_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.5,
                max_tokens=300
            )
            return summary
            
        except Exception as e:
            logger.error(f"Failed to generate summary: {e}")
            return f"Agent for: {context.user_query}"
            
    def clear_session(self, session_id: str):
        """Clear context for a session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            logger.info(f"Cleared context for session {session_id}")
            
    def get_all_sessions(self) -> Dict[str, Context]:
        """Get all active sessions"""
        return self.sessions.copy()