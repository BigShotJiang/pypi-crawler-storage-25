#!/usr/bin/env python3
"""
FORGE AI Error Collector and Analyzer
에러를 수집하고 패턴을 분석하여 근본 원인을 찾습니다.
"""

import json
import traceback
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from collections import Counter, defaultdict
from pathlib import Path
from loguru import logger

class ForgeError(Exception):
    """Base error class with context"""
    def __init__(self, message: str, context: Dict[str, Any] = None, suggestion: str = None):
        super().__init__(message)
        self.message = message
        self.context = context or {}
        self.suggestion = suggestion
        self.timestamp = datetime.now()
        
    def is_retryable(self) -> bool:
        """이 에러가 재시도 가능한지 판단"""
        return False
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "context": self.context,
            "suggestion": self.suggestion,
            "timestamp": self.timestamp.isoformat(),
            "retryable": self.is_retryable()
        }

class TemplateError(ForgeError):
    """템플릿 관련 에러"""
    def is_retryable(self) -> bool:
        return False  # 템플릿 에러는 수정 필요

class LLMError(ForgeError):
    """LLM 응답 관련 에러"""
    def is_retryable(self) -> bool:
        return True  # LLM은 재시도 가능

class ValidationError(ForgeError):
    """코드 검증 에러"""
    def is_retryable(self) -> bool:
        return False  # 검증 실패는 수정 필요

class ParseError(ForgeError):
    """파싱 관련 에러"""
    pass

class ErrorCollector:
    """에러 수집 및 분석 시스템"""
    
    def __init__(self, storage_path: str = "forge/errors"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.current_session = []
        self.error_patterns = defaultdict(list)
        self.error_counts = Counter()
        
    def collect(self, error: Exception, context: Dict[str, Any] = None) -> str:
        """에러 수집 및 저장"""
        error_id = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        
        error_data = {
            "id": error_id,
            "timestamp": datetime.now().isoformat(),
            "error_type": type(error).__name__,
            "error_message": str(error),
            "context": context or {},
            "traceback": traceback.format_exc(),
            "stack_trace": traceback.format_tb(error.__traceback__) if hasattr(error, '__traceback__') else []
        }
        
        # 현재 세션에 추가
        self.current_session.append(error_data)
        
        # 패턴 분석을 위해 저장
        self.error_patterns[error_data["error_type"]].append(error_data)
        self.error_counts[error_data["error_type"]] += 1
        
        # 파일로 저장
        self._save_error(error_id, error_data)
        
        logger.error(f"Error collected: {error_id} - {type(error).__name__}: {str(error)[:100]}")
        
        return error_id
    
    def _save_error(self, error_id: str, error_data: Dict[str, Any]):
        """에러를 파일로 저장"""
        file_path = self.storage_path / f"{error_id}.json"
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(error_data, f, ensure_ascii=False, indent=2)
    
    def analyze_patterns(self) -> Dict[str, Any]:
        """에러 패턴 분석"""
        analysis = {
            "total_errors": len(self.current_session),
            "error_types": dict(self.error_counts),
            "top_errors": self.error_counts.most_common(5),
            "patterns": {},
            "recommendations": []
        }
        
        # 에러 타입별 패턴 분석
        for error_type, errors in self.error_patterns.items():
            if len(errors) >= 2:  # 2개 이상일 때만 패턴 분석
                pattern = self._analyze_error_pattern(errors)
                analysis["patterns"][error_type] = pattern
        
        # 권장사항 생성
        analysis["recommendations"] = self._generate_recommendations(analysis)
        
        return analysis
    
    def _analyze_error_pattern(self, errors: List[Dict[str, Any]]) -> Dict[str, Any]:
        """특정 에러 타입의 패턴 분석"""
        messages = [e["error_message"] for e in errors]
        contexts = [e.get("context", {}) for e in errors]
        
        # 공통 메시지 패턴 찾기
        common_words = self._find_common_patterns(messages)
        
        # 공통 컨텍스트 찾기
        common_context = self._find_common_context(contexts)
        
        return {
            "count": len(errors),
            "common_patterns": common_words,
            "common_context": common_context,
            "first_occurrence": errors[0]["timestamp"],
            "last_occurrence": errors[-1]["timestamp"]
        }
    
    def _find_common_patterns(self, messages: List[str]) -> List[str]:
        """메시지에서 공통 패턴 찾기"""
        if not messages:
            return []
            
        # 간단한 구현: 모든 메시지에 나타나는 단어 찾기
        word_sets = [set(msg.split()) for msg in messages]
        if word_sets:
            common = set.intersection(*word_sets)
            return list(common)[:10]  # 상위 10개만
        return []
    
    def _find_common_context(self, contexts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """공통 컨텍스트 요소 찾기"""
        if not contexts:
            return {}
            
        # 모든 컨텍스트에 나타나는 키 찾기
        if contexts:
            common_keys = set.intersection(*[set(c.keys()) for c in contexts if c])
            result = {}
            for key in common_keys:
                values = [c.get(key) for c in contexts if key in c]
                # 모든 값이 같으면 공통 값으로 저장
                if len(set(str(v) for v in values)) == 1:
                    result[key] = values[0]
            return result
        return {}
    
    def _generate_recommendations(self, analysis: Dict[str, Any]) -> List[str]:
        """분석 결과를 바탕으로 권장사항 생성"""
        recommendations = []
        
        # Top 에러에 대한 권장사항
        for error_type, count in analysis["top_errors"]:
            if error_type == "SyntaxError":
                recommendations.append(f"✅ SyntaxError ({count}회): 템플릿 이스케이프 문제 확인 필요")
            elif error_type == "ValueError":
                recommendations.append(f"✅ ValueError ({count}회): 입력 검증 강화 필요")
            elif error_type == "KeyError":
                recommendations.append(f"✅ KeyError ({count}회): 딕셔너리 키 존재 확인 로직 추가")
            elif error_type == "AttributeError":
                recommendations.append(f"✅ AttributeError ({count}회): 객체 속성 검증 필요")
            else:
                recommendations.append(f"✅ {error_type} ({count}회): 에러 핸들링 개선 필요")
        
        # 패턴 기반 권장사항
        for error_type, pattern in analysis["patterns"].items():
            if pattern["count"] >= 3:
                recommendations.append(f"⚠️ {error_type}이 {pattern['count']}회 반복: 근본 원인 수정 필요")
        
        return recommendations
    
    def get_error_report(self) -> str:
        """에러 보고서 생성"""
        analysis = self.analyze_patterns()
        
        report = []
        report.append("=" * 60)
        report.append("📊 FORGE AI Error Analysis Report")
        report.append("=" * 60)
        report.append(f"\n총 에러 수: {analysis['total_errors']}")
        
        if analysis['top_errors']:
            report.append("\n🔝 Top 5 에러:")
            for error_type, count in analysis['top_errors']:
                report.append(f"  - {error_type}: {count}회")
        
        if analysis['patterns']:
            report.append("\n🔍 에러 패턴:")
            for error_type, pattern in analysis['patterns'].items():
                report.append(f"\n  {error_type}:")
                report.append(f"    - 발생 횟수: {pattern['count']}")
                if pattern['common_patterns']:
                    report.append(f"    - 공통 패턴: {', '.join(pattern['common_patterns'][:5])}")
        
        if analysis['recommendations']:
            report.append("\n💡 권장사항:")
            for rec in analysis['recommendations']:
                report.append(f"  {rec}")
        
        report.append("\n" + "=" * 60)
        
        return "\n".join(report)
    
    def clear_session(self):
        """현재 세션 초기화"""
        self.current_session = []
        self.error_patterns.clear()
        self.error_counts.clear()
        logger.info("Error collector session cleared")

# Global error collector instance
error_collector = ErrorCollector()

def collect_error(error: Exception, context: Dict[str, Any] = None) -> str:
    """전역 에러 수집 함수"""
    return error_collector.collect(error, context)

def get_error_report() -> str:
    """전역 에러 보고서 함수"""
    return error_collector.get_error_report()