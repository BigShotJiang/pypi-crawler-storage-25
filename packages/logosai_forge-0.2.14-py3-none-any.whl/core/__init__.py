"""
FORGE AI Core Components
Framework for Orchestrating Reactive Generated Entities
"""

from .query_analyzer import QueryAnalyzer, QueryAnalysis, Complexity, WorkflowType
from .context_manager import ContextManager, Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .code_generator import CodeGenerator, GeneratedCode
from .validator import Validator, ValidationResult, ValidationIssue, ValidationSeverity
from .agent_executor import AgentExecutor, ExecutionResult
from .performance_monitor import PerformanceMonitor, PerformanceReport, PerformanceMetric
from .evolution_engine import EvolutionEngine, Evolution, EvolutionResult, EvolutionStrategy
from .agent_registry import AgentRegistry, RegisteredAgent, SearchResult
from .template_manager import DualTemplateManager, TemplateMetadata

__all__ = [
    # Query Analysis
    'QueryAnalyzer',
    'QueryAnalysis', 
    'Complexity',
    'WorkflowType',
    
    # Context Management
    'ContextManager',
    'Context',
    
    # LLM Orchestration
    'LLMOrchestrator',
    'TaskType',
    
    # Code Generation
    'CodeGenerator',
    'GeneratedCode',
    
    # Validation
    'Validator',
    'ValidationResult',
    'ValidationIssue',
    'ValidationSeverity',
    
    # Agent Execution
    'AgentExecutor',
    'ExecutionResult',
    
    # Performance Monitoring
    'PerformanceMonitor',
    'PerformanceReport',
    'PerformanceMetric',
    
    # Evolution Engine
    'EvolutionEngine',
    'Evolution',
    'EvolutionResult',
    'EvolutionStrategy',
    
    # Agent Registry
    'AgentRegistry',
    'RegisteredAgent',
    'SearchResult',
    
    # Template Management
    'DualTemplateManager',
    'TemplateMetadata'
]

__version__ = '0.1.0'