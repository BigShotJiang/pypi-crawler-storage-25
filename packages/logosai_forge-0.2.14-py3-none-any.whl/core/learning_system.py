"""
Learning System for FORGE AI
Learns from generation successes and failures to improve over time
"""

import json
import sqlite3
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
import hashlib
from collections import defaultdict
import numpy as np

class PatternType(Enum):
    """Types of patterns to learn"""
    SUCCESS = "success"
    FAILURE = "failure"
    OPTIMIZATION = "optimization"
    
class PatternCategory(Enum):
    """Categories of patterns"""
    CODE_STRUCTURE = "code_structure"
    ERROR_HANDLING = "error_handling"
    PERFORMANCE = "performance"
    SECURITY = "security"
    DATA_HANDLING = "data_handling"
    PROMPT_EFFECTIVENESS = "prompt_effectiveness"

@dataclass
class LearningPattern:
    """Represents a learned pattern"""
    pattern_type: PatternType
    category: PatternCategory
    pattern_signature: str
    description: str
    context: Dict[str, Any]
    solution: Optional[str] = None
    impact_score: float = 0.0
    confidence: float = 0.0
    
@dataclass
class PromptPerformance:
    """Tracks prompt performance metrics"""
    prompt_key: str
    prompt_template: str
    model_used: str
    success_count: int = 0
    failure_count: int = 0
    avg_quality_score: float = 0.0
    avg_generation_time: float = 0.0
    improvements: List[str] = None


class LearningSystem:
    """System for learning from agent generation experiences"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self._init_learning_tables()
        
        # In-memory pattern cache
        self.pattern_cache = defaultdict(list)
        self.prompt_performance_cache = {}
        
    def _init_learning_tables(self):
        """Initialize learning-specific tables if not exists"""
        cursor = self.conn.cursor()
        
        # Pattern recognition table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_patterns (
                id TEXT PRIMARY KEY,
                pattern_type TEXT NOT NULL,
                category TEXT NOT NULL,
                pattern_signature TEXT NOT NULL,
                description TEXT,
                context TEXT,
                solution TEXT,
                occurrences INTEGER DEFAULT 1,
                impact_score REAL DEFAULT 0.0,
                confidence REAL DEFAULT 0.0,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                metadata TEXT
            )
        ''')
        
        # Prompt optimization table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS prompt_performance (
                id TEXT PRIMARY KEY,
                prompt_key TEXT NOT NULL,
                prompt_template TEXT NOT NULL,
                model_used TEXT NOT NULL,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                avg_quality_score REAL DEFAULT 0.0,
                avg_generation_time REAL DEFAULT 0.0,
                improvements TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')
        
        self.conn.commit()
    
    def record_generation_outcome(self, 
                                 generation_log: Dict[str, Any],
                                 execution_result: Optional[Dict[str, Any]] = None):
        """Record outcome of a generation attempt"""
        
        # Extract patterns based on outcome
        if generation_log.get('status') == 'completed' and execution_result:
            if execution_result.get('success'):
                patterns = self._extract_success_patterns(generation_log, execution_result)
            else:
                patterns = self._extract_failure_patterns(generation_log, execution_result)
        else:
            patterns = self._extract_failure_patterns(generation_log, None)
        
        # Store patterns
        for pattern in patterns:
            self._store_pattern(pattern)
        
        # Update prompt performance
        self._update_prompt_performance(generation_log)
        
        # Trigger learning analysis
        self._analyze_patterns()
    
    def _extract_success_patterns(self, 
                                 generation_log: Dict[str, Any],
                                 execution_result: Dict[str, Any]) -> List[LearningPattern]:
        """Extract patterns from successful generation"""
        patterns = []
        
        # Pattern 1: Successful code structure
        code = generation_log.get('generated_code', '')
        if code:
            structure_sig = self._analyze_code_structure(code)
            patterns.append(LearningPattern(
                pattern_type=PatternType.SUCCESS,
                category=PatternCategory.CODE_STRUCTURE,
                pattern_signature=structure_sig,
                description="Successful code structure pattern",
                context={
                    'query_type': generation_log.get('query_type'),
                    'domain': generation_log.get('domain'),
                    'template_used': generation_log.get('template_used'),
                    'execution_time': execution_result.get('execution_time_ms')
                },
                impact_score=0.8,
                confidence=0.9
            ))
        
        # Pattern 2: Effective error handling
        if 'try' in code and 'except' in code:
            patterns.append(LearningPattern(
                pattern_type=PatternType.SUCCESS,
                category=PatternCategory.ERROR_HANDLING,
                pattern_signature=self._hash_pattern("error_handling_present"),
                description="Proper error handling implemented",
                context={'has_error_handling': True},
                impact_score=0.6,
                confidence=0.8
            ))
        
        # Pattern 3: Performance patterns
        exec_time = execution_result.get('execution_time_ms', 0)
        if exec_time < 100:  # Fast execution
            patterns.append(LearningPattern(
                pattern_type=PatternType.SUCCESS,
                category=PatternCategory.PERFORMANCE,
                pattern_signature=self._hash_pattern(f"fast_execution_{generation_log.get('template_used')}"),
                description="Fast execution pattern",
                context={
                    'execution_time_ms': exec_time,
                    'template': generation_log.get('template_used')
                },
                impact_score=0.7,
                confidence=0.85
            ))
        
        return patterns
    
    def _extract_failure_patterns(self,
                                 generation_log: Dict[str, Any],
                                 execution_result: Optional[Dict[str, Any]]) -> List[LearningPattern]:
        """Extract patterns from failed generation"""
        patterns = []
        
        # Pattern 1: Code generation failures
        if generation_log.get('error_type') == 'code_extraction_failed':
            patterns.append(LearningPattern(
                pattern_type=PatternType.FAILURE,
                category=PatternCategory.CODE_STRUCTURE,
                pattern_signature=self._hash_pattern("code_extraction_failure"),
                description="Failed to extract code from LLM response",
                context={
                    'llm_model': generation_log.get('llm_model'),
                    'prompt_length': len(generation_log.get('prompt', ''))
                },
                solution="Improve code extraction patterns or adjust prompt",
                impact_score=0.9,
                confidence=0.95
            ))
        
        # Pattern 2: Execution failures
        if execution_result and not execution_result.get('success'):
            error = execution_result.get('error', {})
            error_type = error.get('type', 'unknown')
            
            patterns.append(LearningPattern(
                pattern_type=PatternType.FAILURE,
                category=PatternCategory.ERROR_HANDLING,
                pattern_signature=self._hash_pattern(f"execution_error_{error_type}"),
                description=f"Execution failed with {error_type}",
                context={
                    'error_type': error_type,
                    'error_message': error.get('message'),
                    'code_snippet': self._extract_error_context(
                        generation_log.get('generated_code', ''),
                        error.get('line_number')
                    )
                },
                solution=self._suggest_error_solution(error_type),
                impact_score=0.8,
                confidence=0.9
            ))
        
        # Pattern 3: Security violations
        if execution_result and execution_result.get('security_violations'):
            patterns.append(LearningPattern(
                pattern_type=PatternType.FAILURE,
                category=PatternCategory.SECURITY,
                pattern_signature=self._hash_pattern("security_violation"),
                description="Security violations detected",
                context={
                    'violations': execution_result.get('security_violations'),
                    'security_level': generation_log.get('security_level')
                },
                solution="Review and restrict dangerous operations",
                impact_score=1.0,  # High impact
                confidence=1.0
            ))
        
        return patterns
    
    def _analyze_code_structure(self, code: str) -> str:
        """Analyze code structure and generate signature"""
        import ast
        
        structure = {
            'imports': 0,
            'classes': 0,
            'functions': 0,
            'async_functions': 0,
            'try_blocks': 0,
            'decorators': 0,
            'line_count': len(code.split('\n'))
        }
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import) or isinstance(node, ast.ImportFrom):
                    structure['imports'] += 1
                elif isinstance(node, ast.ClassDef):
                    structure['classes'] += 1
                elif isinstance(node, ast.FunctionDef):
                    structure['functions'] += 1
                elif isinstance(node, ast.AsyncFunctionDef):
                    structure['async_functions'] += 1
                elif isinstance(node, ast.Try):
                    structure['try_blocks'] += 1
                elif isinstance(node, ast.Name) and node.id.startswith('@'):
                    structure['decorators'] += 1
        except:
            pass
        
        # Generate signature from structure
        sig_str = json.dumps(structure, sort_keys=True)
        return self._hash_pattern(sig_str)
    
    def _update_prompt_performance(self, generation_log: Dict[str, Any]):
        """Update prompt performance metrics"""
        prompt_key = generation_log.get('prompt_key', 'default')
        prompt_template = generation_log.get('prompt_template', '')
        model_used = generation_log.get('llm_model', 'unknown')
        
        # Load existing performance data
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT * FROM prompt_performance 
            WHERE prompt_key = ? AND model_used = ?
        ''', (prompt_key, model_used))
        
        row = cursor.fetchone()
        
        if row:
            # Update existing
            success_count = row[4]
            failure_count = row[5]
            
            if generation_log.get('status') == 'completed':
                success_count += 1
            else:
                failure_count += 1
            
            # Calculate new averages
            total_count = success_count + failure_count
            success_rate = success_count / total_count if total_count > 0 else 0
            
            cursor.execute('''
                UPDATE prompt_performance 
                SET success_count = ?, failure_count = ?, 
                    avg_quality_score = ?, updated_at = ?
                WHERE prompt_key = ? AND model_used = ?
            ''', (success_count, failure_count, success_rate, 
                  datetime.now().isoformat(), prompt_key, model_used))
        else:
            # Insert new
            cursor.execute('''
                INSERT INTO prompt_performance 
                (id, prompt_key, prompt_template, model_used, 
                 success_count, failure_count, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                self._generate_id(),
                prompt_key,
                prompt_template,
                model_used,
                1 if generation_log.get('status') == 'completed' else 0,
                0 if generation_log.get('status') == 'completed' else 1,
                datetime.now().isoformat(),
                datetime.now().isoformat()
            ))
        
        self.conn.commit()
    
    def get_recommendations(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Get recommendations based on learned patterns"""
        recommendations = {
            'template': None,
            'avoid_patterns': [],
            'suggested_improvements': [],
            'confidence': 0.0
        }
        
        # Find successful patterns matching context
        query_type = context.get('query_type')
        domain = context.get('domain')
        
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT * FROM learning_patterns 
            WHERE pattern_type = ? AND impact_score > 0.7
            ORDER BY impact_score DESC, occurrences DESC
            LIMIT 10
        ''', (PatternType.SUCCESS.value,))
        
        success_patterns = cursor.fetchall()
        
        # Find failures to avoid
        cursor.execute('''
            SELECT * FROM learning_patterns 
            WHERE pattern_type = ? AND impact_score > 0.8
            ORDER BY impact_score DESC
            LIMIT 5
        ''', (PatternType.FAILURE.value,))
        
        failure_patterns = cursor.fetchall()
        
        # Generate recommendations
        if success_patterns:
            # Extract context from most successful pattern
            best_pattern_context = json.loads(success_patterns[0][5])
            recommendations['template'] = best_pattern_context.get('template_used')
            recommendations['confidence'] = float(success_patterns[0][9])
        
        for failure in failure_patterns:
            context_data = json.loads(failure[5])
            solution = failure[6]
            recommendations['avoid_patterns'].append({
                'description': failure[4],
                'solution': solution
            })
        
        # Get prompt recommendations
        prompt_recs = self._get_prompt_recommendations(context.get('llm_model', 'gpt-4'))
        recommendations['suggested_improvements'].extend(prompt_recs)
        
        return recommendations
    
    def _get_prompt_recommendations(self, model: str) -> List[str]:
        """Get prompt improvement recommendations"""
        recommendations = []
        
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT prompt_key, avg_quality_score 
            FROM prompt_performance 
            WHERE model_used = ?
            ORDER BY avg_quality_score DESC
            LIMIT 3
        ''', (model,))
        
        top_prompts = cursor.fetchall()
        
        if top_prompts:
            best_prompt = top_prompts[0][0]
            recommendations.append(f"Consider using prompt template: {best_prompt}")
        
        return recommendations
    
    def optimize_prompt(self, current_prompt: str, performance_data: Dict[str, Any]) -> str:
        """Optimize prompt based on learned patterns"""
        # This is a simplified version - in production, could use more sophisticated NLP
        
        optimizations = []
        
        # Check common failure patterns
        if performance_data.get('extraction_failures', 0) > 2:
            optimizations.append("Add explicit markers like ```python and ``` around code")
        
        if performance_data.get('incomplete_code', 0) > 1:
            optimizations.append("Request complete, runnable code with all imports")
        
        if performance_data.get('missing_error_handling', 0) > 1:
            optimizations.append("Explicitly request error handling and edge cases")
        
        # Apply optimizations
        optimized_prompt = current_prompt
        for opt in optimizations:
            optimized_prompt += f"\n\nIMPORTANT: {opt}"
        
        return optimized_prompt
    
    def _store_pattern(self, pattern: LearningPattern):
        """Store or update pattern in database"""
        cursor = self.conn.cursor()
        
        # Check if pattern exists
        cursor.execute('''
            SELECT id, occurrences FROM learning_patterns 
            WHERE pattern_signature = ?
        ''', (pattern.pattern_signature,))
        
        existing = cursor.fetchone()
        
        if existing:
            # Update occurrence count
            cursor.execute('''
                UPDATE learning_patterns 
                SET occurrences = occurrences + 1, 
                    last_seen = ?,
                    confidence = MIN(confidence * 1.05, 1.0)
                WHERE id = ?
            ''', (datetime.now().isoformat(), existing[0]))
        else:
            # Insert new pattern
            cursor.execute('''
                INSERT INTO learning_patterns 
                (id, pattern_type, category, pattern_signature, description,
                 context, solution, impact_score, confidence, first_seen, last_seen)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                self._generate_id(),
                pattern.pattern_type.value,
                pattern.category.value,
                pattern.pattern_signature,
                pattern.description,
                json.dumps(pattern.context),
                pattern.solution,
                pattern.impact_score,
                pattern.confidence,
                datetime.now().isoformat(),
                datetime.now().isoformat()
            ))
        
        self.conn.commit()
    
    def _analyze_patterns(self):
        """Analyze patterns for insights"""
        # This method would run periodically to find meta-patterns
        # For now, just update pattern cache
        
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT category, COUNT(*) as count, AVG(impact_score) as avg_impact
            FROM learning_patterns
            WHERE pattern_type = ?
            GROUP BY category
            ORDER BY count DESC
        ''', (PatternType.FAILURE.value,))
        
        failure_stats = cursor.fetchall()
        
        # Log insights
        for category, count, avg_impact in failure_stats:
            if count > 5 and avg_impact > 0.7:
                print(f"High-impact failure pattern in {category}: {count} occurrences")
    
    def _hash_pattern(self, pattern_str: str) -> str:
        """Generate hash for pattern signature"""
        return hashlib.sha256(pattern_str.encode()).hexdigest()[:16]
    
    def _generate_id(self) -> str:
        """Generate unique ID"""
        return hashlib.md5(f"{datetime.now().isoformat()}".encode()).hexdigest()[:12]
    
    def _extract_error_context(self, code: str, line_number: Optional[int]) -> str:
        """Extract code context around error"""
        if not line_number or not code:
            return ""
        
        lines = code.split('\n')
        start = max(0, line_number - 3)
        end = min(len(lines), line_number + 3)
        
        return '\n'.join(lines[start:end])
    
    def _suggest_error_solution(self, error_type: str) -> str:
        """Suggest solution for common error types"""
        solutions = {
            'NameError': "Ensure all variables are defined before use",
            'TypeError': "Check data types and function arguments",
            'KeyError': "Verify dictionary keys exist before access",
            'AttributeError': "Confirm object has the attribute/method",
            'ImportError': "Check import statements and package availability",
            'SyntaxError': "Review code syntax, especially indentation"
        }
        
        return solutions.get(error_type, "Review error details and fix accordingly")


# Example usage
if __name__ == "__main__":
    # Create learning system
    learning = LearningSystem("forge_agents.db")
    
    # Record successful generation
    success_log = {
        'id': 'gen_001',
        'status': 'completed',
        'query_type': 'data_analysis',
        'domain': 'finance',
        'template_used': 'data_analysis_agent',
        'generated_code': '''
import pandas as pd

class DataAnalyzer:
    def __init__(self):
        self.data = None
    
    def analyze(self, data):
        try:
            df = pd.DataFrame(data)
            return {
                'mean': df.mean(),
                'std': df.std()
            }
        except Exception as e:
            return {'error': str(e)}
''',
        'llm_model': 'gpt-4',
        'prompt_key': 'analysis_v1'
    }
    
    execution_result = {
        'success': True,
        'execution_time_ms': 45,
        'memory_used_mb': 12
    }
    
    learning.record_generation_outcome(success_log, execution_result)
    
    # Get recommendations
    context = {
        'query_type': 'data_analysis',
        'domain': 'finance',
        'llm_model': 'gpt-4'
    }
    
    recommendations = learning.get_recommendations(context)
    print("Recommendations:", json.dumps(recommendations, indent=2))