"""
AgentRegistrar — Registers FORGE-generated agents into ACP runtime.

1. Write .py file to ACP agents/ directory
2. Update ACP configs/agents.json
3. Call ACP hot_register JSON-RPC (runtime registration without restart)
4. Version backup for rollback capability
"""

import json
import sqlite3
import uuid
import shutil
import aiohttp
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, asdict
from loguru import logger


@dataclass
class RegistrationResult:
    success: bool
    agent_id: str
    file_path: str = ""
    message: str = ""
    rollback_path: str = ""
    deployment_id: str = ""  # Track this deployment for post-deploy monitoring


class AgentRegistrar:
    """Registers generated agents into ACP server."""

    def __init__(
        self,
        agents_dir: str = None,
        config_path: str = None,
        acp_url: str = "http://localhost:8888",
    ):
        # Default paths relative to Logos root
        logos_root = Path(__file__).parent.parent.parent  # Logos/
        self.agents_dir = Path(agents_dir) if agents_dir else logos_root / "acp_server" / "agents"
        self.config_path = Path(config_path) if config_path else logos_root / "acp_server" / "configs" / "agents.json"
        self.versions_dir = self.agents_dir.parent / "agent_versions"
        self.acp_url = acp_url

        # Ensure directories exist
        self.agents_dir.mkdir(parents=True, exist_ok=True)
        self.versions_dir.mkdir(parents=True, exist_ok=True)

        # Deployment tracking DB
        self._db_path = str(Path(__file__).parent.parent / "prototype" / "backend" / "forge_evolution.db")
        self._init_deployments_table()

    async def register(
        self,
        agent_code: str,
        agent_name: str,
        agent_id: str,
        description: str = "",
        capabilities: List[Dict] = None,
    ) -> RegistrationResult:
        """Register a generated agent into ACP.

        Steps:
        1. Backup existing agent (if updating)
        2. Write .py file
        3. Update agents.json
        4. Call ACP hot_register JSON-RPC
        """
        try:
            file_name = f"{agent_id}.py"
            file_path = self.agents_dir / file_name
            rollback_path = ""

            # Step 1: Backup if exists
            if file_path.exists():
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup = self.versions_dir / f"{agent_id}_{ts}.py"
                shutil.copy2(file_path, backup)
                rollback_path = str(backup)
                logger.info(f"[Registrar] Backed up {agent_id} → {backup.name}")

            # Step 2: Write .py file
            file_path.write_text(agent_code, encoding="utf-8")
            logger.info(f"[Registrar] Wrote {file_path} ({len(agent_code)} chars)")

            # Step 3: Update agents.json
            self._update_config(agent_id, agent_name, description, capabilities or [])

            # Step 4: Call ACP hot_register
            hot_result = await self._hot_register(agent_id, str(file_path), {
                "agent_id": agent_id,
                "name": agent_name,
                "description": description,
                "capabilities": capabilities or [],
            })

            if hot_result:
                logger.info(f"[Registrar] ✅ {agent_id} registered in ACP runtime")
            else:
                logger.warning(f"[Registrar] ⚠️ {agent_id} written but hot_register failed (ACP may need restart)")

            # Record deployment for post-deploy monitoring
            deployment_id = self._record_deployment(
                agent_id=agent_id, deployment_type=description[:30] if description else "register",
                rollback_path=rollback_path,
            )

            return RegistrationResult(
                success=True,
                agent_id=agent_id,
                file_path=str(file_path),
                message=f"Agent {agent_name} registered" + (" (hot)" if hot_result else " (file only)"),
                rollback_path=rollback_path,
                deployment_id=deployment_id,
            )

        except Exception as e:
            logger.error(f"[Registrar] Failed to register {agent_id}: {e}")
            return RegistrationResult(
                success=False,
                agent_id=agent_id,
                message=str(e),
            )

    async def rollback(self, agent_id: str, version_path: str = None) -> bool:
        """Rollback agent to previous version."""
        try:
            if version_path:
                backup = Path(version_path)
            else:
                # Find latest backup
                backups = sorted(self.versions_dir.glob(f"{agent_id}_*.py"), reverse=True)
                if not backups:
                    logger.warning(f"[Registrar] No backup found for {agent_id}")
                    return False
                backup = backups[0]

            target = self.agents_dir / f"{agent_id}.py"
            shutil.copy2(backup, target)
            logger.info(f"[Registrar] Rolled back {agent_id} from {backup.name}")

            # Re-register in ACP
            await self._hot_register(agent_id, str(target), {"agent_id": agent_id})
            return True

        except Exception as e:
            logger.error(f"[Registrar] Rollback failed for {agent_id}: {e}")
            return False

    def _update_config(self, agent_id: str, name: str, description: str, capabilities: List[Dict]):
        """Update agents.json — preserves existing metadata, tags, parameters."""
        config = {}
        if self.config_path.exists():
            try:
                config = json.loads(self.config_path.read_text(encoding="utf-8"))
            except Exception:
                config = {}

        if "agents" not in config:
            config["agents"] = []

        # Find existing entry
        existing = next((a for a in config["agents"] if a.get("agent_id") == agent_id), None)

        if existing:
            # Preserve existing metadata, tags, parameters — only update changed fields
            if name and name != agent_id:
                existing["name"] = name
            if description and not description.startswith(("Improved:", "Enhanced:", "Auto-fixed:")):
                existing["description"] = description
            if capabilities:
                existing["capabilities"] = capabilities
            existing["last_updated"] = datetime.now().isoformat()
            # metadata, tags, parameters are NEVER deleted
        else:
            # New agent — add with default metadata
            class_name = "".join(w.capitalize() for w in agent_id.replace("-", "_").split("_"))
            config["agents"].append({
                "agent_id": agent_id,
                "name": name or agent_id,
                "description": description,
                "capabilities": capabilities,
                "metadata": {
                    "class_name": class_name,
                    "module_name": agent_id,
                    "agent_type": "CUSTOM",
                },
                "tags": [],
                "parameters": {"model": "gemini-2.5-flash-lite", "temperature": 0.3},
                "source": "forge_v6_generated",
                "generated_at": datetime.now().isoformat(),
            })

        # Backup config before writing
        if self.config_path.exists():
            backup = self.config_path.with_suffix(".json.bak")
            shutil.copy2(self.config_path, backup)

        self.config_path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
        logger.info(f"[Registrar] Updated agents.json ({len(config['agents'])} agents)")

    def _init_deployments_table(self):
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS deployments (
                    deployment_id TEXT PRIMARY KEY,
                    agent_id TEXT NOT NULL,
                    deployment_type TEXT,
                    related_failure_ids TEXT DEFAULT '[]',
                    confidence REAL DEFAULT 0,
                    scope TEXT DEFAULT '',
                    deployed_at TEXT NOT NULL,
                    status TEXT DEFAULT 'active',
                    rollback_path TEXT DEFAULT ''
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS deployment_outcomes (
                    id TEXT PRIMARY KEY,
                    deployment_id TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    failures_before INTEGER DEFAULT 0,
                    failures_after INTEGER DEFAULT 0,
                    new_failures INTEGER DEFAULT 0,
                    resolved_failures INTEGER DEFAULT 0,
                    assessment TEXT DEFAULT 'pending',
                    assessed_at TEXT
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[Registrar] Deployments table init: {e}")

    def _record_deployment(self, agent_id: str, deployment_type: str = "auto_fix",
                           confidence: float = 0, scope: str = "",
                           failure_ids: list = None, rollback_path: str = "") -> str:
        deployment_id = f"deploy_{uuid.uuid4().hex[:10]}"
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute(
                """INSERT INTO deployments (deployment_id, agent_id, deployment_type,
                   related_failure_ids, confidence, scope, deployed_at, rollback_path)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (deployment_id, agent_id, deployment_type,
                 json.dumps(failure_ids or []), confidence, scope,
                 datetime.now().isoformat(), rollback_path)
            )
            conn.commit()
            conn.close()
            logger.info(f"[Registrar] Deployment recorded: {deployment_id} for {agent_id}")
        except Exception as e:
            logger.debug(f"[Registrar] Deployment record failed: {e}")
        return deployment_id

    async def _hot_register(self, agent_id: str, module_path: str, config: Dict) -> bool:
        """Call ACP hot_register JSON-RPC."""
        try:
            async with aiohttp.ClientSession() as session:
                payload = {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "hot_register",
                    "params": {
                        "agent_id": agent_id,
                        "module_path": module_path,
                        "config": config,
                    }
                }
                async with session.post(
                    f"{self.acp_url}/jsonrpc",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        result = await resp.json()
                        return result.get("result", {}).get("registered", False)
                    else:
                        logger.warning(f"[Registrar] hot_register returned {resp.status}")
                        return False
        except Exception as e:
            logger.warning(f"[Registrar] hot_register failed (ACP may be down): {e}")
            return False
