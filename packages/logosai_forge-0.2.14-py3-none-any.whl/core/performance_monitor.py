"""
Performance Monitor for FORGE AI

Monitors and analyzes agent performance using LLM-driven insights.
All performance decisions and analysis are made by LLM, not hardcoded.
"""

import asyncio
import time
import json
import statistics
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict, deque
import logging

from .llm_orchestrator import LLMOrchestrator, TaskType
from .agent_executor import ExecutionResult
from .prompts import prompt_registry

logger = logging.getLogger(__name__)


@dataclass
class PerformanceMetric:
    """Single performance metric"""
    name: str
    value: Any
    timestamp: datetime
    context: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'value': self.value,
            'timestamp': self.timestamp.isoformat(),
            'context': self.context
        }


@dataclass
class PerformanceReport:
    """Performance analysis report"""
    agent_id: str
    period: str
    metrics: Dict[str, Any]
    analysis: str
    recommendations: List[str]
    trends: Dict[str, str]
    anomalies: List[str]
    score: float  # 0-100 performance score
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'agent_id': self.agent_id,
            'period': self.period,
            'metrics': self.metrics,
            'analysis': self.analysis,
            'recommendations': self.recommendations,
            'trends': self.trends,
            'anomalies': self.anomalies,
            'score': self.score
        }


class PerformanceMonitor:
    """Monitors agent performance using LLM analysis"""
    
    def __init__(self, 
                 llm_orchestrator: Optional[LLMOrchestrator] = None,
                 config: Optional[Dict[str, Any]] = None):
        """
        Initialize performance monitor.
        
        Args:
            llm_orchestrator: LLM for performance analysis
            config: Configuration options
        """
        self.llm = llm_orchestrator
        self.config = config or {}
        
        # Performance data storage
        self.metrics: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.execution_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        self.analysis_cache: Dict[str, Tuple[datetime, Any]] = {}
        
        # Real-time monitoring
        self.monitoring_tasks: Dict[str, asyncio.Task] = {}
        self.alert_handlers = []
        
    async def record_execution(self, 
                             agent_id: str,
                             execution_result: ExecutionResult,
                             input_data: Dict[str, Any],
                             context: Optional[Dict[str, Any]] = None):
        """
        Record agent execution results.
        
        Args:
            agent_id: Agent identifier
            execution_result: Execution result
            input_data: Input that was processed
            context: Additional context
        """
        timestamp = datetime.now()
        
        # Store execution data
        execution_data = {
            'timestamp': timestamp,
            'result': execution_result.to_dict(),
            'input': input_data,
            'context': context or {}
        }
        
        self.execution_history[agent_id].append(execution_data)
        
        # Let LLM determine what metrics to extract
        metrics = await self._extract_metrics(agent_id, execution_result, input_data)
        
        # Record each metric
        for metric in metrics:
            self.metrics[f"{agent_id}.{metric.name}"].append(metric)
            
        # Check for anomalies or alerts
        await self._check_alerts(agent_id, execution_result, metrics)
        
    async def _extract_metrics(self,
                             agent_id: str,
                             execution_result: ExecutionResult,
                             input_data: Dict[str, Any]) -> List[PerformanceMetric]:
        """Let LLM extract relevant metrics from execution"""
        
        extract_prompt = f"""Analyze this agent execution and extract performance metrics:

Agent: {agent_id}
Success: {execution_result.success}
Execution Time: {execution_result.execution_time}s
Error: {execution_result.error}
Output Size: {len(str(execution_result.output))} chars
Input Complexity: {len(json.dumps(input_data))} chars

What metrics should we track? Consider:
1. Response time metrics
2. Success/failure patterns
3. Resource usage indicators
4. Output quality signals
5. Input complexity factors

List metrics as JSON array with name, value, and reason:"""
        
        response = await self.llm.generate(
            extract_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Parse metrics
        metrics = []
        timestamp = datetime.now()
        
        try:
            metric_list = json.loads(response)
            if not isinstance(metric_list, list):
                metric_list = []
        except:
            # Fallback: Let LLM fix JSON
            fix_prompt = f"""Convert this to valid JSON array:
{response}

Valid JSON:"""
            
            fixed = await self.llm.generate(
                fix_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.1
            )
            
            try:
                metric_list = json.loads(fixed)
            except:
                metric_list = []
                
        # Create metric objects
        for item in metric_list:
            if isinstance(item, dict) and 'name' in item and 'value' in item:
                metrics.append(PerformanceMetric(
                    name=item['name'],
                    value=item['value'],
                    timestamp=timestamp,
                    context={'reason': item.get('reason', '')}
                ))
                
        # Always include basic metrics
        metrics.extend([
            PerformanceMetric('execution_time', execution_result.execution_time, timestamp),
            PerformanceMetric('success', 1 if execution_result.success else 0, timestamp),
            PerformanceMetric('has_error', 1 if execution_result.error else 0, timestamp)
        ])
        
        return metrics
        
    async def analyze_performance(self,
                                agent_id: str,
                                period: Optional[timedelta] = None) -> PerformanceReport:
        """
        Analyze agent performance over a period.
        
        Args:
            agent_id: Agent to analyze
            period: Time period (default: last 24 hours)
            
        Returns:
            Performance analysis report
        """
        if not period:
            period = timedelta(hours=24)
            
        # Check cache
        cache_key = f"{agent_id}:{period.total_seconds()}"
        if cache_key in self.analysis_cache:
            cached_time, cached_report = self.analysis_cache[cache_key]
            if datetime.now() - cached_time < timedelta(minutes=5):
                return cached_report
                
        # Gather metrics for period
        cutoff_time = datetime.now() - period
        period_metrics = await self._gather_period_metrics(agent_id, cutoff_time)
        
        if not period_metrics:
            return PerformanceReport(
                agent_id=agent_id,
                period=str(period),
                metrics={},
                analysis="No data available for analysis",
                recommendations=[],
                trends={},
                anomalies=[],
                score=0.0
            )
            
        # Let LLM analyze performance
        report = await self._llm_analyze_performance(agent_id, period_metrics, period)
        
        # Cache result
        self.analysis_cache[cache_key] = (datetime.now(), report)
        
        return report
        
    async def _gather_period_metrics(self,
                                   agent_id: str,
                                   cutoff_time: datetime) -> Dict[str, List[Any]]:
        """Gather metrics for a specific period"""
        
        period_metrics = {}
        
        # Collect all metrics for this agent
        for metric_key, metric_deque in self.metrics.items():
            if metric_key.startswith(f"{agent_id}."):
                metric_name = metric_key.split('.', 1)[1]
                
                # Filter by time
                period_values = [
                    m for m in metric_deque 
                    if m.timestamp >= cutoff_time
                ]
                
                if period_values:
                    period_metrics[metric_name] = period_values
                    
        return period_metrics
        
    async def _llm_analyze_performance(self,
                                      agent_id: str,
                                      metrics: Dict[str, List[PerformanceMetric]],
                                      period: timedelta) -> PerformanceReport:
        """Let LLM analyze performance metrics"""
        
        # Prepare metric summary
        metric_summary = {}
        for name, values in metrics.items():
            numeric_values = [v.value for v in values if isinstance(v.value, (int, float))]
            
            if numeric_values:
                metric_summary[name] = {
                    'count': len(values),
                    'mean': statistics.mean(numeric_values),
                    'min': min(numeric_values),
                    'max': max(numeric_values),
                    'recent': values[-1].value if values else None
                }
            else:
                metric_summary[name] = {
                    'count': len(values),
                    'values': [v.value for v in values[-5:]]  # Last 5 values
                }
                
        # Get execution history summary
        executions = self.execution_history.get(agent_id, deque())
        recent_executions = [e for e in executions if e['timestamp'] >= datetime.now() - period]
        
        execution_summary = {
            'total': len(recent_executions),
            'successful': sum(1 for e in recent_executions if e['result']['success']),
            'failed': sum(1 for e in recent_executions if not e['result']['success']),
            'errors': [e['result']['error'] for e in recent_executions if e['result']['error']][:5]
        }
        
        # LLM analysis prompt
        analysis_prompt = f"""Analyze the performance of agent '{agent_id}' over {period}:

Metric Summary:
{json.dumps(metric_summary, indent=2)}

Execution Summary:
{json.dumps(execution_summary, indent=2)}

Provide comprehensive analysis:
1. Overall performance assessment
2. Identify trends (improving/declining/stable)
3. Detect any anomalies or concerns
4. Calculate performance score (0-100)
5. Provide actionable recommendations

Format response as JSON with keys:
- analysis: Overall assessment text
- trends: Dict of metric->trend
- anomalies: List of anomaly descriptions
- score: Performance score 0-100
- recommendations: List of actionable improvements"""
        
        response = await self.llm.generate(
            analysis_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.4
        )
        
        # Parse response
        try:
            analysis_data = json.loads(response)
        except:
            # Let LLM fix
            fix_prompt = f"""Fix this JSON response:
{response}

Valid JSON:"""
            
            fixed = await self.llm.generate(
                fix_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.1
            )
            
            try:
                analysis_data = json.loads(fixed)
            except:
                # Fallback
                analysis_data = {
                    'analysis': 'Unable to complete analysis',
                    'trends': {},
                    'anomalies': [],
                    'score': 50.0,
                    'recommendations': ['Review agent implementation']
                }
                
        return PerformanceReport(
            agent_id=agent_id,
            period=str(period),
            metrics=metric_summary,
            analysis=analysis_data.get('analysis', ''),
            recommendations=analysis_data.get('recommendations', []),
            trends=analysis_data.get('trends', {}),
            anomalies=analysis_data.get('anomalies', []),
            score=float(analysis_data.get('score', 50.0))
        )
        
    async def _check_alerts(self,
                          agent_id: str,
                          execution_result: ExecutionResult,
                          metrics: List[PerformanceMetric]):
        """Let LLM check if any alerts should be triggered"""
        
        # Prepare context
        recent_history = list(self.execution_history[agent_id])[-10:]
        recent_failures = sum(1 for e in recent_history if not e['result']['success'])
        
        alert_prompt = f"""Should we trigger any performance alerts?

Agent: {agent_id}
Latest execution: {'Success' if execution_result.success else 'Failed'}
Error: {execution_result.error or 'None'}
Execution time: {execution_result.execution_time}s
Recent failure rate: {recent_failures}/{len(recent_history)}

Recent metrics:
{json.dumps([m.to_dict() for m in metrics], indent=2)}

Consider alerting for:
1. High failure rates
2. Performance degradation
3. Unusual errors
4. Resource issues
5. Anomalous behavior

Should alert? (yes/no and reason):"""
        
        response = await self.llm.generate(
            alert_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Check if alert needed
        if 'yes' in response.lower():
            # Extract alert details
            alert_data = {
                'agent_id': agent_id,
                'timestamp': datetime.now(),
                'reason': response.split('\n', 1)[-1] if '\n' in response else response,
                'execution_result': execution_result.to_dict(),
                'metrics': [m.to_dict() for m in metrics]
            }
            
            # Trigger alert handlers
            for handler in self.alert_handlers:
                try:
                    await handler(alert_data)
                except Exception as e:
                    logger.error(f"Alert handler failed: {e}")
                    
    def add_alert_handler(self, handler):
        """Add alert handler callback"""
        self.alert_handlers.append(handler)
        
    async def start_monitoring(self, agent_id: str, interval: int = 300):
        """
        Start continuous monitoring of an agent.
        
        Args:
            agent_id: Agent to monitor
            interval: Analysis interval in seconds
        """
        if agent_id in self.monitoring_tasks:
            return
            
        async def monitor_loop():
            while True:
                try:
                    # Analyze performance
                    report = await self.analyze_performance(
                        agent_id,
                        period=timedelta(seconds=interval * 2)
                    )
                    
                    # Check if intervention needed
                    if report.score < 70 or report.anomalies:
                        alert_data = {
                            'agent_id': agent_id,
                            'timestamp': datetime.now(),
                            'reason': f"Low performance score: {report.score}",
                            'report': report.to_dict()
                        }
                        
                        for handler in self.alert_handlers:
                            await handler(alert_data)
                            
                except Exception as e:
                    logger.error(f"Monitoring error for {agent_id}: {e}")
                    
                await asyncio.sleep(interval)
                
        task = asyncio.create_task(monitor_loop())
        self.monitoring_tasks[agent_id] = task
        
    async def stop_monitoring(self, agent_id: str):
        """Stop monitoring an agent"""
        if agent_id in self.monitoring_tasks:
            self.monitoring_tasks[agent_id].cancel()
            del self.monitoring_tasks[agent_id]
            
    async def compare_agents(self, agent_ids: List[str], 
                           period: Optional[timedelta] = None) -> Dict[str, Any]:
        """
        Compare performance across multiple agents.
        
        Args:
            agent_ids: List of agents to compare
            period: Comparison period
            
        Returns:
            Comparison analysis
        """
        if not period:
            period = timedelta(hours=24)
            
        # Gather reports for all agents
        reports = {}
        for agent_id in agent_ids:
            reports[agent_id] = await self.analyze_performance(agent_id, period)
            
        # Let LLM compare
        comparison_prompt = f"""Compare the performance of these agents:

{json.dumps({aid: r.to_dict() for aid, r in reports.items()}, indent=2)}

Provide comparison analysis:
1. Rank agents by overall performance
2. Identify best practices from top performers
3. Common issues across agents
4. Recommendations for improvement
5. Which agent patterns should be replicated?

Format as structured comparison report:"""
        
        response = await self.llm.generate(
            comparison_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.4
        )
        
        return {
            'comparison_date': datetime.now().isoformat(),
            'period': str(period),
            'agents': list(agent_ids),
            'individual_reports': {aid: r.to_dict() for aid, r in reports.items()},
            'comparison_analysis': response
        }
        
    async def suggest_optimizations(self, agent_id: str) -> List[Dict[str, Any]]:
        """Let LLM suggest specific optimizations for an agent"""
        
        # Get recent performance data
        report = await self.analyze_performance(agent_id)
        
        # Get recent execution samples
        recent_executions = list(self.execution_history[agent_id])[-5:]
        
        optimization_prompt = f"""Suggest specific optimizations for agent '{agent_id}':

Performance Report:
{json.dumps(report.to_dict(), indent=2)}

Recent Execution Samples:
{json.dumps(recent_executions, indent=2, default=str)}

Provide specific, actionable optimizations:
1. Code-level improvements
2. Algorithm optimizations
3. Resource usage improvements
4. Error handling enhancements
5. Architecture changes

Format each suggestion with:
- title: Brief title
- description: Detailed explanation
- impact: Expected improvement
- effort: Implementation effort (low/medium/high)
- code_sample: Example code if applicable"""
        
        response = await self.llm.generate(
            optimization_prompt,
            task_type=TaskType.OPTIMIZATION,
            temperature=0.6
        )
        
        # Parse suggestions
        suggestions = []
        current_suggestion = {}
        
        for line in response.split('\n'):
            line = line.strip()
            
            if line.startswith('- title:'):
                if current_suggestion:
                    suggestions.append(current_suggestion)
                current_suggestion = {'title': line.replace('- title:', '').strip()}
            elif line.startswith('- ') and current_suggestion:
                key = line.split(':', 1)[0].replace('- ', '').strip()
                value = line.split(':', 1)[1].strip() if ':' in line else ''
                current_suggestion[key] = value
            elif current_suggestion and 'code_sample' in line:
                # Start collecting code
                current_suggestion['code_sample'] = []
            elif current_suggestion and 'code_sample' in current_suggestion:
                if isinstance(current_suggestion['code_sample'], list):
                    current_suggestion['code_sample'].append(line)
                    
        if current_suggestion:
            suggestions.append(current_suggestion)
            
        # Clean up code samples
        for suggestion in suggestions:
            if 'code_sample' in suggestion and isinstance(suggestion['code_sample'], list):
                suggestion['code_sample'] = '\n'.join(suggestion['code_sample'])
                
        return suggestions
        
    def get_metrics_summary(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get current metrics summary"""
        
        if agent_id:
            # Single agent summary
            agent_metrics = {
                k.split('.', 1)[1]: list(v)
                for k, v in self.metrics.items()
                if k.startswith(f"{agent_id}.")
            }
            
            return {
                'agent_id': agent_id,
                'metrics': {
                    name: {
                        'count': len(values),
                        'latest': values[-1].to_dict() if values else None
                    }
                    for name, values in agent_metrics.items()
                },
                'total_executions': len(self.execution_history.get(agent_id, []))
            }
        else:
            # All agents summary
            all_agents = set(k.split('.')[0] for k in self.metrics.keys())
            
            return {
                'total_agents': len(all_agents),
                'agents': list(all_agents),
                'total_metrics': len(self.metrics),
                'total_executions': sum(len(h) for h in self.execution_history.values())
            }