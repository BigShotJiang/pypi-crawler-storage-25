"""
Unified Business Logic Generator for FORGE AI
통합된 비즈니스 로직 생성기 - 메타데이터 보장 및 템플릿 변수 치환 문제 해결

Author: FORGE AI Team
Date: 2025-01-21
Version: 1.0.0
"""

from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import logging
import json
import re
import asyncio

# Import Agentic detector
try:
    # Try relative import first
    from ..utils.agentic_detector import AgenticDetector
    AGENTIC_DETECTOR_AVAILABLE = True
except ImportError:
    try:
        # Try absolute import
        from utils.agentic_detector import AgenticDetector
        AGENTIC_DETECTOR_AVAILABLE = True
    except ImportError:
        AGENTIC_DETECTOR_AVAILABLE = False
        logging.warning("AgenticDetector not available. Agentic features disabled.")

logger = logging.getLogger(__name__)


@dataclass
class BusinessLogicResult:
    """비즈니스 로직 생성 결과"""
    # 핵심 비즈니스 로직
    core_business_logic: str
    
    # 필수 메타데이터 (템플릿 변수 치환용)
    agent_class_name: str
    agent_name: str
    agent_description: str
    agent_type: str = "CUSTOM"
    
    # 추가 설정
    custom_config: Dict[str, Any] = field(default_factory=dict)
    custom_init: str = ""
    imports: List[str] = field(default_factory=list)
    
    # 처리 단계
    processing_steps: List[str] = field(default_factory=list)
    
    # 검증 및 품질
    is_valid: bool = False
    validation_errors: List[str] = field(default_factory=list)
    confidence: float = 0.0
    
    # 생성 메타데이터
    generation_method: str = "unified"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    # Agentic AI 관련 필드 (선택적)
    use_enhanced_agent: bool = False
    base_class: str = "LogosAIAgent"  # 또는 "EnhancedLogosAIAgent"
    agentic_config: Dict[str, Any] = field(default_factory=dict)
    agentic_features: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """템플릿 치환을 위한 딕셔너리 변환"""
        return {
            'core_business_logic': self.core_business_logic,
            'agent_class_name': self.agent_class_name,
            'agent_name': self.agent_name,
            'agent_description': self.agent_description,
            'agent_type': self.agent_type,
            'custom_config': json.dumps(self.custom_config) if self.custom_config else '{}',
            'custom_init': self.custom_init,
            'initialization': self.custom_init,  # Alternative key
            'imports': self.imports,
            'processing_steps': self.processing_steps,
            'is_valid': self.is_valid,
            'confidence': self.confidence,
            # Agentic AI 관련
            'use_enhanced_agent': self.use_enhanced_agent,
            'base_class': self.base_class,
            'agentic_config': json.dumps(self.agentic_config) if self.agentic_config else '{}',
            'agentic_features': self.agentic_features
        }
    
    def ensure_completeness(self):
        """모든 필수 필드가 채워져 있는지 확인하고 기본값 설정"""
        if not self.agent_class_name or self.agent_class_name == '{agent_class_name}':
            self.agent_class_name = 'GeneratedAgent'
            logger.warning("Missing agent_class_name, using default: GeneratedAgent")
        
        if not self.agent_name or self.agent_name == '{agent_name}':
            self.agent_name = 'Generated Agent'
            logger.warning("Missing agent_name, using default: Generated Agent")
        
        if not self.agent_description or self.agent_description == '{agent_description}':
            self.agent_description = 'Auto-generated agent for processing requests'
            logger.warning("Missing agent_description, using default")
        
        if not self.custom_config:
            self.custom_config = {'timeout': 60, 'retry_attempts': 3}
            logger.warning("Missing custom_config, using default")
        
        if not self.custom_init:
            self.custom_init = '# Custom initialization code\n        pass'
            logger.warning("Missing custom_init, using default")
        
        if not self.core_business_logic or 'pass' in self.core_business_logic:
            self.core_business_logic = self._generate_default_logic()
            logger.warning("Missing or invalid core_business_logic, using default")
    
    def _generate_default_logic(self) -> str:
        """기본 비즈니스 로직 생성"""
        return '''
async def _process_core_logic(self, extracted_info: Dict) -> Dict[str, Any]:
    """Core business logic processing"""
    try:
        # Default processing logic
        result = {
            "status": "processed",
            "input": extracted_info,
            "timestamp": datetime.now().isoformat(),
            "message": "Successfully processed request"
        }
        
        # Add any custom processing here
        if "data" in extracted_info:
            result["processed_data"] = self._process_data(extracted_info["data"])
        
        return result
    except Exception as e:
        logger.error(f"Processing error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

def _process_data(self, data: Any) -> Any:
    """Helper method for data processing"""
    # Implement data-specific processing
    return data
'''


class UnifiedBusinessLogicGenerator:
    """
    통합된 비즈니스 로직 생성기
    모든 비즈니스 로직 생성을 단일 인터페이스로 통합
    """
    
    # 도메인별 비즈니스 로직 템플릿
    DOMAIN_TEMPLATES = {
        'data_processing': {
            'imports': [
                'import pandas as pd',
                'import numpy as np',
                'from typing import Dict, Any, List'
            ],
            'logic_template': '''
async def _process_core_logic(self, extracted_info: Dict) -> Dict[str, Any]:
    """Process data analysis request"""
    try:
        data = extracted_info.get('data', [])
        operation = extracted_info.get('operation', 'analyze')
        
        # Convert to DataFrame for analysis
        if isinstance(data, list):
            df = pd.DataFrame(data)
        else:
            df = pd.DataFrame([data])
        
        results = {}
        
        # Perform requested operation
        if operation == 'analyze':
            results['statistics'] = df.describe().to_dict()
            results['shape'] = df.shape
            results['dtypes'] = df.dtypes.to_dict()
        elif operation == 'aggregate':
            results['sum'] = df.sum().to_dict()
            results['mean'] = df.mean().to_dict()
        else:
            results['data'] = df.to_dict()
        
        return {
            "status": "success",
            "results": results,
            "rows_processed": len(df)
        }
    except Exception as e:
        logger.error(f"Data processing error: {e}")
        return {"status": "error", "error": str(e)}
'''
        },
        'api_integration': {
            'imports': [
                'import aiohttp',
                'import json',
                'from typing import Dict, Any'
            ],
            'logic_template': '''
async def _process_core_logic(self, extracted_info: Dict) -> Dict[str, Any]:
    """Process API integration request"""
    try:
        url = extracted_info.get('url', '')
        method = extracted_info.get('method', 'GET').upper()
        headers = extracted_info.get('headers', {})
        data = extracted_info.get('data')
        
        async with aiohttp.ClientSession() as session:
            async with session.request(
                method=method,
                url=url,
                headers=headers,
                json=data if method in ['POST', 'PUT'] else None
            ) as response:
                response_data = await response.json()
                
                return {
                    "status": "success",
                    "status_code": response.status,
                    "data": response_data,
                    "headers": dict(response.headers)
                }
    except Exception as e:
        logger.error(f"API integration error: {e}")
        return {"status": "error", "error": str(e)}
'''
        },
        'ml_ai': {
            'imports': [
                'import numpy as np',
                'from typing import Dict, Any, List'
            ],
            'logic_template': '''
async def _process_core_logic(self, extracted_info: Dict) -> Dict[str, Any]:
    """Process ML/AI request"""
    try:
        input_data = extracted_info.get('input', '')
        model_type = extracted_info.get('model', 'classification')
        
        # Placeholder for ML processing
        # In real implementation, load and use actual model
        
        if model_type == 'sentiment':
            # Simple sentiment analysis logic
            positive_words = ['good', 'great', 'excellent', 'amazing', 'wonderful']
            negative_words = ['bad', 'terrible', 'awful', 'horrible', 'poor']
            
            text = str(input_data).lower()
            pos_count = sum(1 for word in positive_words if word in text)
            neg_count = sum(1 for word in negative_words if word in text)
            
            if pos_count > neg_count:
                sentiment = 'positive'
                confidence = pos_count / (pos_count + neg_count + 1)
            elif neg_count > pos_count:
                sentiment = 'negative'
                confidence = neg_count / (pos_count + neg_count + 1)
            else:
                sentiment = 'neutral'
                confidence = 0.5
            
            return {
                "status": "success",
                "sentiment": sentiment,
                "confidence": confidence
            }
        
        return {
            "status": "success",
            "prediction": "placeholder_prediction",
            "confidence": 0.75
        }
    except Exception as e:
        logger.error(f"ML processing error: {e}")
        return {"status": "error", "error": str(e)}
'''
        }
    }
    
    def __init__(self):
        """Initialize the unified business logic generator"""
        self.generation_count = 0
        logger.info("UnifiedBusinessLogicGenerator initialized")
    
    async def generate(
        self, 
        query: str,
        analysis_result: Optional[Dict[str, Any]] = None,
        pattern_match: Optional[Dict[str, Any]] = None,
        template_id: Optional[str] = None
    ) -> BusinessLogicResult:
        """
        통합된 비즈니스 로직 생성 메서드
        
        Args:
            query: User query
            analysis_result: Query analysis result
            pattern_match: Pattern matching result
            template_id: Template ID to use
            
        Returns:
            Complete business logic result with all metadata
        """
        logger.info(f"Generating business logic for: {query[:100]}...")
        
        # Initialize result
        result = BusinessLogicResult(
            core_business_logic="",
            agent_class_name="",
            agent_name="",
            agent_description=""
        )
        
        # Extract metadata from analysis
        if analysis_result:
            self._extract_metadata_from_analysis(result, analysis_result)
        
        # Detect Agentic AI requirements (NEW)
        if AGENTIC_DETECTOR_AVAILABLE:
            patterns = []
            if pattern_match and isinstance(pattern_match, dict):
                patterns = pattern_match.get('patterns', [])
            elif isinstance(pattern_match, list):
                patterns = pattern_match
            
            agentic_info = AgenticDetector.detect_agentic_requirements(query, patterns)
            
            if agentic_info["needs_agentic"]:
                logger.info(f"Agentic AI features detected with confidence: {agentic_info['confidence']:.2f}")
                result.use_enhanced_agent = True
                result.base_class = "EnhancedLogosAIAgent"
                result.agentic_config = agentic_info["recommended_config"]
                result.agentic_features = agentic_info["detected_features"]
                
                # Update imports for EnhancedLogosAIAgent
                result.imports = [
                    "from logosai.agent_enhanced import EnhancedLogosAIAgent",
                    "from logosai import AgentConfig, AgentType, AgentResponse, AgentResponseType",
                    "from typing import Dict, Any, Optional",
                    "from loguru import logger"
                ]
            else:
                # Use standard LogosAIAgent
                result.use_enhanced_agent = False
                result.base_class = "LogosAIAgent"
                result.imports = [
                    "from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType",
                    "from typing import Dict, Any, Optional",
                    "from loguru import logger"
                ]
        else:
            # Fallback to standard agent if detector not available
            result.use_enhanced_agent = False
            result.base_class = "LogosAIAgent"
        
        # Determine domain and generate logic
        domain = self._determine_domain(query, analysis_result, pattern_match)
        
        # Generate business logic based on domain
        if domain in self.DOMAIN_TEMPLATES:
            template = self.DOMAIN_TEMPLATES[domain]
            result.core_business_logic = template['logic_template']
            result.imports = template['imports']
            result.generation_method = f"domain_template_{domain}"
        else:
            # Use default logic generation
            result.core_business_logic = self._generate_generic_logic(query)
            result.generation_method = "generic"
        
        # Apply pattern-based enhancements
        if pattern_match:
            self._enhance_with_pattern(result, pattern_match)
        
        # Ensure all required metadata is present
        result.ensure_completeness()
        
        # Validate the generated logic
        result.is_valid = self._validate_logic(result)
        
        # Calculate confidence
        result.confidence = self._calculate_confidence(result)
        
        self.generation_count += 1
        logger.info(f"Business logic generated successfully. Method: {result.generation_method}")
        
        return result
    
    def _extract_metadata_from_analysis(
        self, result: BusinessLogicResult, analysis: Dict[str, Any]
    ):
        """Extract metadata from query analysis"""
        # Get agent metadata if available
        agent_meta = analysis.get('agent_metadata', {})
        
        result.agent_class_name = agent_meta.get('agent_class_name', 'GeneratedAgent')
        result.agent_name = agent_meta.get('agent_name', 'Generated Agent')
        result.agent_description = agent_meta.get('agent_description', 'Auto-generated agent')
        result.agent_type = agent_meta.get('agent_type', 'CUSTOM')
        
        # Extract processing steps
        if 'required_capabilities' in analysis:
            result.processing_steps = analysis['required_capabilities']
        
        # Extract custom config
        if 'constraints' in analysis:
            result.custom_config.update(analysis['constraints'])
    
    def _determine_domain(
        self, query: str, analysis: Optional[Dict], pattern: Optional[Dict]
    ) -> str:
        """Determine the domain for logic generation"""
        # Check analysis result
        if analysis and 'domain' in analysis:
            domain = analysis['domain']
            if domain in ['data_processing', 'analytics']:
                return 'data_processing'
            elif domain in ['api', 'integration']:
                return 'api_integration'
            elif domain in ['ml', 'ai', 'machine_learning']:
                return 'ml_ai'
        
        # Check pattern match
        if pattern and 'pattern_type' in pattern:
            pattern_type = pattern['pattern_type']
            pattern_type_str = str(pattern_type.value if hasattr(pattern_type, 'value') else pattern_type)
            if 'DATA' in pattern_type_str.upper() or 'ANALYT' in pattern_type_str.upper():
                return 'data_processing'
            elif 'API' in pattern_type_str.upper() or 'INTEGRATION' in pattern_type_str.upper():
                return 'api_integration'
            elif 'ML' in pattern_type_str.upper() or 'AI' in pattern_type_str.upper():
                return 'ml_ai'
        
        # Fallback to keyword detection
        query_lower = query.lower()
        if any(kw in query_lower for kw in ['data', 'analyze', 'csv', 'dataframe']):
            return 'data_processing'
        elif any(kw in query_lower for kw in ['api', 'endpoint', 'request', 'http']):
            return 'api_integration'
        elif any(kw in query_lower for kw in ['predict', 'classify', 'sentiment', 'ml', '감정', '예측', '분석', 'ai']):
            return 'ml_ai'
        
        return 'generic'
    
    def _generate_generic_logic(self, query: str) -> str:
        """Generate generic business logic"""
        return '''
async def _process_core_logic(self, extracted_info: Dict) -> Dict[str, Any]:
    """Process request with generic logic"""
    try:
        # Extract input data
        input_data = extracted_info.get('input', extracted_info)
        
        # Process the input
        processed_result = await self._process_input(input_data)
        
        # Format the output
        output = {
            "status": "success",
            "result": processed_result,
            "timestamp": datetime.now().isoformat(),
            "query": extracted_info.get('original_query', '')
        }
        
        return output
    except Exception as e:
        logger.error(f"Processing error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

async def _process_input(self, input_data: Any) -> Any:
    """Process input data"""
    # Implement specific processing logic here
    if isinstance(input_data, dict):
        return {k: str(v) for k, v in input_data.items()}
    elif isinstance(input_data, list):
        return [str(item) for item in input_data]
    else:
        return str(input_data)
'''
    
    def _enhance_with_pattern(self, result: BusinessLogicResult, pattern: Dict):
        """Enhance business logic with pattern information"""
        if 'business_logic_hints' in pattern:
            hints = pattern['business_logic_hints']
            
            # Add processing steps
            if 'processing_steps' in hints:
                result.processing_steps.extend(hints['processing_steps'])
            
            # Update custom config
            if 'config' in hints:
                result.custom_config.update(hints['config'])
    
    def _validate_logic(self, result: BusinessLogicResult) -> bool:
        """Validate the generated business logic"""
        errors = []
        
        # Check for required components
        if not result.core_business_logic:
            errors.append("Missing core business logic")
        
        if not result.agent_class_name or result.agent_class_name == '{agent_class_name}':
            errors.append("Invalid agent class name")
        
        # Check for syntax placeholders
        if '{' in result.core_business_logic and '}' in result.core_business_logic:
            remaining_vars = re.findall(r'\{[^}]+\}', result.core_business_logic)
            if remaining_vars:
                errors.append(f"Unresolved template variables: {remaining_vars}")
        
        # Check for basic Python syntax
        if 'def ' not in result.core_business_logic:
            errors.append("Missing function definition")
        
        result.validation_errors = errors
        return len(errors) == 0
    
    def _calculate_confidence(self, result: BusinessLogicResult) -> float:
        """Calculate confidence score for the generated logic"""
        confidence = 0.5  # Base confidence
        
        # Increase confidence based on completeness
        if result.is_valid:
            confidence += 0.2
        
        if result.generation_method != 'generic':
            confidence += 0.15
        
        if len(result.imports) > 0:
            confidence += 0.1
        
        if len(result.processing_steps) > 0:
            confidence += 0.05
        
        # Decrease confidence for errors
        confidence -= len(result.validation_errors) * 0.1
        
        return max(0.0, min(1.0, confidence))
    
    def generate_emergency_logic(self, query: str, error: Optional[str] = None) -> BusinessLogicResult:
        """
        Generate emergency fallback business logic
        Used when normal generation fails
        """
        logger.warning(f"Generating emergency logic for: {query[:50]}... Error: {error}")
        
        result = BusinessLogicResult(
            core_business_logic=self._generate_generic_logic(query),
            agent_class_name="EmergencyAgent",
            agent_name="Emergency Agent",
            agent_description=f"Emergency agent for: {query[:100]}",
            agent_type="EMERGENCY",
            custom_config={"emergency_mode": True, "error": error},
            generation_method="emergency",
            confidence=0.3
        )
        
        result.ensure_completeness()
        result.is_valid = True  # Emergency logic is always "valid"
        
        return result


# Singleton instance
business_logic_generator = UnifiedBusinessLogicGenerator()


async def generate_business_logic(
    query: str,
    analysis_result: Optional[Dict[str, Any]] = None,
    pattern_match: Optional[Dict[str, Any]] = None
) -> BusinessLogicResult:
    """
    Convenience function for generating business logic
    
    Args:
        query: User query
        analysis_result: Query analysis result
        pattern_match: Pattern matching result
        
    Returns:
        Complete business logic result
    """
    return await business_logic_generator.generate(
        query, analysis_result, pattern_match
    )