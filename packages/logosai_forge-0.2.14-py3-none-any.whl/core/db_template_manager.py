"""
Database-based Template Manager for FORGE AI

Manages templates from database with backward compatibility for LogosAI.
All template selection decisions are made by LLM.
"""

import os
import json
import shutil
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import logging
import sys

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent / "prototype" / "backend"))

from app.services.db_template_repository import DBTemplateRepository
from .llm_orchestrator import LLMOrchestrator, TaskType
from .prompts import prompt_registry

# Import LogosAI template system
try:
    from logosai.templates import TemplateEngine
except ImportError:
    # Fallback for testing
    class TemplateEngine:
        def list_templates(self, category=None):
            return []
        def get_metadata(self, template):
            return None
        def render(self, template, context):
            return f"# Rendered from {template}"

logger = logging.getLogger(__name__)


class DBTemplateManager:
    """Database-based template manager for FORGE AI"""
    
    def __init__(self,
                 db_path: Optional[str] = None,
                 llm_orchestrator: Optional[LLMOrchestrator] = None):
        """
        Initialize database template manager.
        
        Args:
            db_path: Path to SQLite database
            llm_orchestrator: LLM for template decisions
        """
        self.llm = llm_orchestrator
        
        # Template repository
        self.template_repo = DBTemplateRepository(db_path)
        
        # LogosAI engine for backward compatibility
        self.logosai_engine = TemplateEngine()
        
        # Statistics
        self.template_usage: Dict[str, int] = {}
        self.template_performance: Dict[str, List[float]] = {}
        
    async def list_all_templates(self, 
                               category: Optional[str] = None,
                               include_metadata: bool = True,
                               user_email: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List all available templates from database.
        
        Args:
            category: Filter by category
            include_metadata: Include full metadata
            user_email: User email for access control
            
        Returns:
            List of template information
        """
        # Get templates from database
        templates = self.template_repo.list_templates(
            limit=100,
            category=category,
            user_email=user_email,
            include_private=bool(user_email)
        )
        
        # Format template information
        formatted_templates = []
        for template in templates:
            template_info = {
                'name': template['name'],
                'source': template['source'],
                'id': template['id'],
                'category': template['category'],
                'readonly': template['user_email'] != user_email if user_email else True
            }
            
            if include_metadata:
                template_info.update({
                    'description': template['description'],
                    'tags': template['tags'],
                    'parameters': template['parameters'],
                    'usage_count': template['usage_count'],
                    'performance_score': template['performance_score'],
                    'version': template['version']
                })
                
            formatted_templates.append(template_info)
            
        return formatted_templates
        
    async def select_template(self,
                            requirements: Dict[str, Any],
                            context: Optional[Dict[str, Any]] = None,
                            user_email: Optional[str] = None) -> Tuple[str, str]:
        """
        Let LLM select the best template for given requirements.
        
        Args:
            requirements: Template requirements
            context: Additional context
            user_email: User email for access control
            
        Returns:
            Tuple of (template_id, source)
        """
        # Get all available templates
        all_templates = await self.list_all_templates(
            include_metadata=True,
            user_email=user_email
        )
        
        if not all_templates:
            raise ValueError("No templates available")
            
        # Let LLM choose
        select_prompt = f"""Select the best template for these requirements:

Requirements:
{json.dumps(requirements, indent=2)}

Context:
{json.dumps(context or {}, indent=2)}

Available Templates:
{json.dumps(all_templates[:20], indent=2)}  # Limit for context

Consider:
1. Requirement match
2. Template specialization
3. Performance history (usage_count and performance_score)
4. Evolution status (check version and tags)

Select the best template and explain why:
Format: template_id|source|reason"""
        
        response = await self.llm.generate(
            select_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Parse response
        parts = response.strip().split('|')
        
        if len(parts) >= 2:
            template_id = parts[0].strip()
            source = parts[1].strip().lower()
            
            # Find exact match
            for template in all_templates:
                if template['id'] == template_id:
                    logger.info(f"Selected template: {template_id} from {source}")
                    return template_id, source
                    
        # Fallback to first template
        logger.warning("Failed to parse template selection, using fallback")
        return all_templates[0]['id'], all_templates[0]['source']
        
    async def get_template(self, 
                         template_id: str,
                         user_email: Optional[str] = None) -> str:
        """
        Get template content from database.
        
        Args:
            template_id: Template ID
            user_email: User email for access control
            
        Returns:
            Template content
        """
        template = self.template_repo.get_template(template_id, user_email)
        
        if not template:
            # Try by name for backward compatibility
            template = self.template_repo.get_template_by_name(template_id, user_email)
            
        if not template:
            raise ValueError(f"Template not found: {template_id}")
            
        return template['content']
            
    async def render_template(self,
                            template_id: str,
                            context: Dict[str, Any],
                            user_email: Optional[str] = None) -> str:
        """
        Render template with context.
        
        Args:
            template_id: Template ID
            context: Template context/variables
            user_email: User email for access control
            
        Returns:
            Rendered template
        """
        # Track usage
        self.template_usage[template_id] = self.template_usage.get(template_id, 0) + 1
        
        # Get template
        template = self.template_repo.get_template(template_id, user_email)
        if not template:
            template = self.template_repo.get_template_by_name(template_id, user_email)
            
        if not template:
            raise ValueError(f"Template not found: {template_id}")
        
        # Render template
        from jinja2 import Template
        jinja_template = Template(template['content'])
        rendered = jinja_template.render(**context)
        
        # Record usage
        self.template_repo.record_usage(
            template_id=template['id'],
            user_email=user_email or 'anonymous',
            success=True,
            metadata={'context_keys': list(context.keys())}
        )
        
        return rendered
            
    async def evolve_template(self,
                            source_template_id: str,
                            evolution_strategy: str,
                            performance_data: Optional[Dict[str, Any]] = None,
                            user_email: str = "system") -> str:
        """
        Evolve a template and save as new template.
        
        Args:
            source_template_id: Source template ID
            evolution_strategy: Evolution strategy description
            performance_data: Performance data to guide evolution
            user_email: User email (owner of new template)
            
        Returns:
            New evolved template ID
        """
        # Get source template
        source_template = self.template_repo.get_template(source_template_id, user_email)
        if not source_template:
            raise ValueError(f"Source template not found: {source_template_id}")
            
        # Let LLM evolve the template
        evolved_content = await self._evolve_template_content(
            source_template,
            evolution_strategy,
            performance_data
        )
        
        # Generate new template name
        evolved_name = await self._generate_evolved_name(
            source_template['name'],
            evolution_strategy
        )
        
        # Determine category for evolved template
        category = await self._determine_evolved_category(
            source_template,
            evolution_strategy
        )
        
        # Create evolved template data
        evolved_template_data = {
            'name': evolved_name,
            'source': 'forge',
            'category': category,
            'description': f"Evolved from {source_template['name']}: {evolution_strategy}",
            'content': evolved_content,
            'parameters': source_template['parameters'].copy(),
            'tags': source_template['tags'] + ['evolved', category],
            'version': self._increment_version(source_template.get('version', '1.0.0')),
            'parent_template_id': source_template_id,
            'evolution_history': source_template.get('evolution_history', []) + [{
                'date': datetime.now().isoformat(),
                'strategy': evolution_strategy,
                'source': source_template_id,
                'performance_data': performance_data
            }],
            'is_public': False,  # Evolved templates are private by default
            'is_active': True
        }
        
        # Save evolved template
        saved_template = self.template_repo.save_template(
            evolved_template_data,
            user_email=user_email
        )
        
        logger.info(f"Created evolved template: {evolved_name} (ID: {saved_template['id']})")
        
        return saved_template['id']
        
    async def _evolve_template_content(self,
                                     source_template: Dict[str, Any],
                                     strategy: str,
                                     performance_data: Optional[Dict[str, Any]]) -> str:
        """Let LLM evolve template content"""
        
        evolution_prompt = f"""Evolve this template based on the strategy:

Current Template:
```jinja2
{source_template['content']}
```

Template Info:
- Description: {source_template['description']}
- Category: {source_template['category']}
- Parameters: {json.dumps(source_template['parameters'])}
- Current Performance Score: {source_template.get('performance_score', 0)}

Evolution Strategy: {strategy}

Performance Data:
{json.dumps(performance_data or {}, indent=2)}

Apply the evolution strategy to improve the template.
Consider:
1. Performance optimizations
2. Better code structure
3. Enhanced error handling
4. More flexible parameters
5. Improved documentation

Evolved template:"""
        
        evolved_content = await self.llm.generate(
            evolution_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.6,
            max_tokens=4000
        )
        
        return evolved_content
        
    async def _generate_evolved_name(self,
                                   source_name: str,
                                   strategy: str) -> str:
        """Let LLM generate name for evolved template"""
        
        name_prompt = f"""Generate a name for this evolved template:

Source template: {source_name}
Evolution strategy: {strategy}

The name should be:
1. Descriptive but concise
2. Include indication of evolution
3. Valid Python identifier format
4. Max 40 characters

Template name:"""
        
        response = await self.llm.generate(
            name_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.5
        )
        
        # Clean the name
        name = response.strip()
        name = ''.join(c for c in name if c.isalnum() or c in '_-')
        name = name[:40]
        
        # Ensure uniqueness
        existing = self.template_repo.get_template_by_name(name)
        if existing:
            name = f"{name}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
        return name
        
    async def _determine_evolved_category(self,
                                        source_template: Dict[str, Any],
                                        strategy: str) -> str:
        """Let LLM determine category for evolved template"""
        
        category_prompt = f"""Determine the category for this evolved template:

Source category: {source_template['category']}
Evolution strategy: {strategy}

Available categories:
- optimized: Performance-optimized templates
- specialized: Domain-specific templates
- evolved: General evolved templates
- custom: Heavily customized templates
- experimental: Experimental/testing templates

Best category:"""
        
        response = await self.llm.generate(
            category_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        category = response.strip().lower()
        
        # Validate category
        valid_categories = ['optimized', 'specialized', 'evolved', 'custom', 'experimental']
        if category not in valid_categories:
            category = 'evolved'
            
        return category
    
    def _increment_version(self, version: str) -> str:
        """Increment semantic version"""
        try:
            parts = version.split('.')
            if len(parts) == 3:
                major, minor, patch = map(int, parts)
                return f"{major}.{minor}.{patch + 1}"
        except:
            pass
        return "1.0.1"
        
    def record_performance(self,
                         template_id: str,
                         performance_score: float,
                         user_email: str = "anonymous"):
        """Record template performance"""
        
        key = template_id
        
        if key not in self.template_performance:
            self.template_performance[key] = []
            
        self.template_performance[key].append(performance_score)
        
        # Update in database
        self.template_repo.record_usage(
            template_id=template_id,
            user_email=user_email,
            success=performance_score > 0.5,
            metadata={'performance_score': performance_score}
        )
            
    async def recommend_templates(self,
                                requirements: Dict[str, Any],
                                user_email: Optional[str] = None,
                                limit: int = 5) -> List[Dict[str, Any]]:
        """Let LLM recommend templates based on requirements"""
        
        all_templates = await self.list_all_templates(
            include_metadata=True,
            user_email=user_email
        )
        
        recommend_prompt = f"""Recommend templates for these requirements:

Requirements:
{json.dumps(requirements, indent=2)}

Available Templates (showing first 20):
{json.dumps(all_templates[:20], indent=2)}

Recommend up to {limit} templates with reasoning.
Consider:
1. Requirement match
2. Performance scores
3. Usage statistics
4. Evolution status

Format each recommendation as:
- template: template_id
- name: template_name
- score: 0-100
- reason: why recommended"""
        
        response = await self.llm.generate(
            recommend_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.4
        )
        
        # Parse recommendations
        recommendations = []
        current_rec = {}
        
        for line in response.split('\n'):
            line = line.strip()
            
            if line.startswith('- template:'):
                if current_rec:
                    recommendations.append(current_rec)
                current_rec = {'template': line.split(':', 1)[1].strip()}
            elif line.startswith('- ') and current_rec:
                key = line.split(':', 1)[0].replace('- ', '').strip()
                value = line.split(':', 1)[1].strip() if ':' in line else ''
                current_rec[key] = value
                
        if current_rec:
            recommendations.append(current_rec)
            
        # Convert scores to float
        for rec in recommendations:
            if 'score' in rec:
                try:
                    rec['score'] = float(rec['score'])
                except:
                    rec['score'] = 50.0
                    
        # Sort by score
        recommendations.sort(key=lambda x: x.get('score', 0), reverse=True)
        
        return recommendations[:limit]
        
    def get_statistics(self) -> Dict[str, Any]:
        """Get template usage and performance statistics"""
        
        # Get all templates for counting
        all_templates = self.template_repo.list_templates(limit=1000)
        
        # Count by source
        by_source = {}
        by_category = {}
        
        for template in all_templates:
            source = template['source']
            category = template['category']
            
            by_source[source] = by_source.get(source, 0) + 1
            by_category[category] = by_category.get(category, 0) + 1
        
        # Calculate average performance
        avg_performances = {}
        for key, scores in self.template_performance.items():
            if scores:
                avg_performances[key] = sum(scores) / len(scores)
                
        # Most used templates
        most_used = sorted(
            self.template_usage.items(),
            key=lambda x: x[1],
            reverse=True
        )[:10]
        
        return {
            'total_templates': {
                'by_source': by_source,
                'by_category': by_category,
                'total': len(all_templates)
            },
            'usage_stats': {
                'total_uses': sum(self.template_usage.values()),
                'most_used': most_used
            },
            'performance_stats': {
                'tracked_templates': len(self.template_performance),
                'average_scores': avg_performances
            },
            'evolution_stats': {
                'evolved_templates': sum(
                    1 for t in all_templates
                    if t.get('parent_template_id')
                ),
                'categories': by_category
            }
        }
    
    def search_templates(self, 
                        query: str,
                        user_email: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search templates by query"""
        return self.template_repo.search_templates(query, user_email)
    
    def add_favorite(self, template_id: str, user_email: str) -> bool:
        """Add template to user favorites"""
        return self.template_repo.add_favorite(template_id, user_email)
    
    def remove_favorite(self, template_id: str, user_email: str) -> bool:
        """Remove template from user favorites"""
        return self.template_repo.remove_favorite(template_id, user_email)
    
    def get_user_favorites(self, user_email: str) -> List[Dict[str, Any]]:
        """Get user's favorite templates"""
        return self.template_repo.get_user_favorites(user_email)