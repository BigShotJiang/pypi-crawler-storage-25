"""
Evolution Engine for FORGE AI

Evolves agents over time using LLM-driven strategies.
All evolution decisions are made by LLM, not hardcoded rules.
"""

import asyncio
import json
import uuid
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import logging

from .llm_orchestrator import LLMOrchestrator, TaskType
from .code_generator import CodeGenerator, GeneratedCode
from .validator import Validator
from .performance_monitor import PerformanceMonitor, PerformanceReport
from .agent_executor import AgentExecutor
from .prompts import prompt_registry

logger = logging.getLogger(__name__)


class EvolutionStrategy(Enum):
    """Evolution strategies (determined by LLM)"""
    OPTIMIZE = "optimize"           # Performance optimization
    FEATURE_ADD = "feature_add"     # Add new capabilities
    REFACTOR = "refactor"          # Code structure improvement
    SPECIALIZE = "specialize"      # Narrow focus for efficiency
    GENERALIZE = "generalize"      # Broaden capabilities
    MERGE = "merge"                # Combine with another agent
    SPLIT = "split"                # Split into specialized agents


@dataclass
class Evolution:
    """Represents an agent evolution"""
    id: str
    parent_agent_id: str
    strategy: EvolutionStrategy
    changes_description: str
    old_code: str
    new_code: str
    performance_baseline: Dict[str, Any]
    created_at: datetime = field(default_factory=datetime.now)
    tested: bool = False
    test_results: Optional[Dict[str, Any]] = None
    promoted: bool = False
    promotion_date: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'parent_agent_id': self.parent_agent_id,
            'strategy': self.strategy.value,
            'changes_description': self.changes_description,
            'created_at': self.created_at.isoformat(),
            'tested': self.tested,
            'test_results': self.test_results,
            'promoted': self.promoted,
            'promotion_date': self.promotion_date.isoformat() if self.promotion_date else None
        }


@dataclass
class EvolutionResult:
    """Result of evolution process"""
    evolution: Evolution
    success: bool
    new_agent_id: Optional[str] = None
    performance_improvement: Optional[float] = None
    validation_passed: bool = False
    error: Optional[str] = None
    recommendations: List[str] = field(default_factory=list)


class EvolutionEngine:
    """Manages agent evolution using LLM-driven strategies"""
    
    def __init__(self,
                 llm_orchestrator: Optional[LLMOrchestrator] = None,
                 code_generator: Optional[CodeGenerator] = None,
                 validator: Optional[Validator] = None,
                 performance_monitor: Optional[PerformanceMonitor] = None,
                 agent_executor: Optional[AgentExecutor] = None,
                 config: Optional[Dict[str, Any]] = None):
        """
        Initialize evolution engine.
        
        Args:
            llm_orchestrator: LLM for evolution decisions
            code_generator: Code generation component
            validator: Code validation component
            performance_monitor: Performance monitoring component
            agent_executor: Agent execution component
            config: Configuration options
        """
        self.llm = llm_orchestrator
        self.code_generator = code_generator
        self.validator = validator
        self.performance_monitor = performance_monitor
        self.agent_executor = agent_executor
        self.config = config or {}
        
        # Evolution tracking
        self.evolutions: Dict[str, Evolution] = {}
        self.evolution_history: Dict[str, List[Evolution]] = {}
        self.active_experiments: Dict[str, Dict[str, Any]] = {}
        
    async def evolve_agent(self,
                          agent_id: str,
                          agent_code: str,
                          performance_data: Optional[PerformanceReport] = None,
                          user_feedback: Optional[str] = None) -> EvolutionResult:
        """
        Evolve an agent based on performance and feedback.
        
        Args:
            agent_id: Agent to evolve
            agent_code: Current agent code
            performance_data: Performance analysis
            user_feedback: Optional user feedback
            
        Returns:
            Evolution result
        """
        logger.info(f"Starting evolution for agent: {agent_id}")
        
        # Get performance data if not provided
        if not performance_data and self.performance_monitor:
            performance_data = await self.performance_monitor.analyze_performance(agent_id)
            
        # 1. Let LLM analyze and choose evolution strategy
        strategy, analysis = await self._analyze_evolution_needs(
            agent_id, agent_code, performance_data, user_feedback
        )
        
        # 2. Generate evolved code based on strategy
        evolved_code, changes = await self._generate_evolved_code(
            agent_code, strategy, analysis, performance_data
        )
        
        # 3. Validate evolved code
        validation_result = None
        if self.validator:
            validation_result = await self.validator.validate(evolved_code)
            
            if not validation_result.is_valid:
                # Let LLM fix validation issues
                evolved_code = await self._fix_validation_issues(
                    evolved_code, validation_result
                )
                
        # 4. Create evolution record
        evolution = Evolution(
            id=str(uuid.uuid4()),
            parent_agent_id=agent_id,
            strategy=strategy,
            changes_description=changes,
            old_code=agent_code,
            new_code=evolved_code,
            performance_baseline=performance_data.to_dict() if performance_data else {}
        )
        
        self.evolutions[evolution.id] = evolution
        
        # Track history
        if agent_id not in self.evolution_history:
            self.evolution_history[agent_id] = []
        self.evolution_history[agent_id].append(evolution)
        
        # 5. Test evolved version
        test_result = await self._test_evolution(evolution, evolved_code)
        
        evolution.tested = True
        evolution.test_results = test_result
        
        # 6. Evaluate success
        success, improvement = await self._evaluate_evolution(
            evolution, test_result, performance_data
        )
        
        return EvolutionResult(
            evolution=evolution,
            success=success,
            new_agent_id=f"{agent_id}_evolved_{evolution.id[:8]}",
            performance_improvement=improvement,
            validation_passed=validation_result.is_valid if validation_result else True,
            recommendations=await self._get_next_steps(evolution, success)
        )
        
    async def _analyze_evolution_needs(self,
                                      agent_id: str,
                                      agent_code: str,
                                      performance_data: Optional[PerformanceReport],
                                      user_feedback: Optional[str]) -> Tuple[EvolutionStrategy, str]:
        """Let LLM analyze and determine evolution strategy"""
        
        analysis_prompt = f"""Analyze this agent and determine the best evolution strategy:

Agent ID: {agent_id}
Code Length: {len(agent_code)} characters
Code Summary (first 1000 chars):
{agent_code[:1000]}...

Performance Data:
{json.dumps(performance_data.to_dict() if performance_data else {}, indent=2)}

User Feedback: {user_feedback or 'None'}

Available strategies:
1. OPTIMIZE - Improve performance/efficiency
2. FEATURE_ADD - Add new capabilities
3. REFACTOR - Improve code structure
4. SPECIALIZE - Focus on specific use cases
5. GENERALIZE - Broaden capabilities
6. MERGE - Combine with another agent
7. SPLIT - Split into specialized agents

Analyze the agent and determine:
1. What evolution strategy to use
2. Why this strategy is best
3. Specific improvements to make

Format response as JSON:
{{
  "strategy": "STRATEGY_NAME",
  "reasoning": "why this strategy",
  "improvements": ["specific improvement 1", "specific improvement 2", ...]
}}"""
        
        response = await self.llm.generate(
            analysis_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.5
        )
        
        # Parse response
        try:
            analysis = json.loads(response)
            strategy_name = analysis.get('strategy', 'OPTIMIZE')
            
            # Map to enum
            strategy = EvolutionStrategy.OPTIMIZE
            for s in EvolutionStrategy:
                if s.value.upper() == strategy_name.upper() or s.name == strategy_name.upper():
                    strategy = s
                    break
                    
            return strategy, json.dumps(analysis, indent=2)
            
        except:
            # Let LLM fix JSON
            fix_prompt = f"""Fix this JSON response:
{response}

Valid JSON with keys: strategy, reasoning, improvements:"""
            
            fixed = await self.llm.generate(
                fix_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.1
            )
            
            try:
                analysis = json.loads(fixed)
                strategy_name = analysis.get('strategy', 'OPTIMIZE')
                
                strategy = EvolutionStrategy.OPTIMIZE
                for s in EvolutionStrategy:
                    if s.value.upper() == strategy_name.upper():
                        strategy = s
                        break
                        
                return strategy, json.dumps(analysis, indent=2)
            except:
                # Fallback
                return EvolutionStrategy.OPTIMIZE, "Unable to parse strategy analysis"
                
    async def _generate_evolved_code(self,
                                   agent_code: str,
                                   strategy: EvolutionStrategy,
                                   analysis: str,
                                   performance_data: Optional[PerformanceReport]) -> Tuple[str, str]:
        """Let LLM generate evolved code based on strategy"""
        
        evolution_prompt = f"""Evolve this agent code using {strategy.value} strategy:

Current Code:
```python
{agent_code}
```

Strategy Analysis:
{analysis}

Performance Issues to Address:
{json.dumps(performance_data.anomalies if performance_data else [], indent=2)}

Apply the {strategy.value} strategy to improve the agent.
Generate the complete evolved code.

Important:
1. Maintain LogosAI agent structure
2. Preserve working functionality
3. Apply improvements based on analysis
4. Add comments explaining changes

Evolved code:"""
        
        evolved_code = await self.llm.generate(
            evolution_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.6,
            max_tokens=4000
        )
        
        # Generate change summary
        summary_prompt = f"""Summarize the key changes made in this evolution:

Strategy: {strategy.value}
Original code length: {len(agent_code)}
New code length: {len(evolved_code)}

List 3-5 key changes made:"""
        
        changes_summary = await self.llm.generate(
            summary_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        return evolved_code, changes_summary
        
    async def _fix_validation_issues(self,
                                   code: str,
                                   validation_result) -> str:
        """Let LLM fix validation issues"""
        
        # Get critical issues
        critical_issues = [
            i for i in validation_result.issues
            if i.severity.value in ['critical', 'error']
        ]
        
        if not critical_issues:
            return code
            
        fix_prompt = f"""Fix these validation issues in the code:

Issues:
{json.dumps([i.to_dict() for i in critical_issues[:5]], indent=2)}

Code to fix:
```python
{code}
```

Generate corrected code that addresses these issues:"""
        
        fixed_code = await self.llm.generate(
            fix_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.4,
            max_tokens=4000
        )
        
        return fixed_code
        
    async def _test_evolution(self,
                            evolution: Evolution,
                            evolved_code: str) -> Dict[str, Any]:
        """Test evolved agent"""
        
        if not self.agent_executor:
            return {'tested': False, 'reason': 'No executor available'}
            
        # Let LLM generate test scenarios
        test_prompt = f"""Generate test scenarios for this evolved agent:

Evolution Strategy: {evolution.strategy.value}
Changes: {evolution.changes_description}

Generate 3 test cases as JSON array with:
- description: what to test
- input: test input data
- expected_behavior: what should happen"""
        
        response = await self.llm.generate(
            test_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.5
        )
        
        # Parse test cases
        try:
            test_cases = json.loads(response)
            if not isinstance(test_cases, list):
                test_cases = []
        except:
            test_cases = [
                {
                    'description': 'Basic functionality test',
                    'input': {'test': 'data'},
                    'expected_behavior': 'Process successfully'
                }
            ]
            
        # Run tests
        test_results = []
        
        for test_case in test_cases[:3]:  # Limit to 3 tests
            try:
                result = await self.agent_executor.execute(
                    evolved_code,
                    test_case.get('input', {}),
                    test_mode=True
                )
                
                test_results.append({
                    'test': test_case['description'],
                    'success': result.success,
                    'execution_time': result.execution_time,
                    'error': result.error
                })
            except Exception as e:
                test_results.append({
                    'test': test_case['description'],
                    'success': False,
                    'error': str(e)
                })
                
        return {
            'test_cases': test_cases,
            'results': test_results,
            'overall_success': all(r['success'] for r in test_results),
            'success_rate': sum(1 for r in test_results if r['success']) / len(test_results) if test_results else 0
        }
        
    async def _evaluate_evolution(self,
                                evolution: Evolution,
                                test_result: Dict[str, Any],
                                baseline_performance: Optional[PerformanceReport]) -> Tuple[bool, float]:
        """Let LLM evaluate if evolution was successful"""
        
        eval_prompt = f"""Evaluate if this evolution was successful:

Evolution Strategy: {evolution.strategy.value}
Changes Made: {evolution.changes_description}

Test Results:
{json.dumps(test_result, indent=2)}

Baseline Performance Score: {baseline_performance.score if baseline_performance else 'N/A'}

Determine:
1. Was the evolution successful? (yes/no)
2. Estimated performance improvement (-100 to +100)
3. Reasoning

Format as JSON:"""
        
        response = await self.llm.generate(
            eval_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Parse evaluation
        try:
            evaluation = json.loads(response)
            success = evaluation.get('successful', 'yes').lower() == 'yes'
            improvement = float(evaluation.get('improvement', 0))
            
            return success, improvement
        except:
            # Fallback based on test results
            success = test_result.get('overall_success', False)
            improvement = 10.0 if success else -10.0
            
            return success, improvement
            
    async def _get_next_steps(self,
                            evolution: Evolution,
                            success: bool) -> List[str]:
        """Let LLM suggest next steps"""
        
        next_steps_prompt = f"""Suggest next steps for this evolution:

Evolution ID: {evolution.id}
Strategy: {evolution.strategy.value}
Success: {success}
Test Results: {json.dumps(evolution.test_results, indent=2)}

Provide 3-5 actionable next steps:"""
        
        response = await self.llm.generate(
            next_steps_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.5
        )
        
        # Parse suggestions
        suggestions = []
        for line in response.strip().split('\n'):
            line = line.strip()
            if line and not line.startswith('#'):
                cleaned = line.lstrip('0123456789.-• ').strip()
                if cleaned:
                    suggestions.append(cleaned)
                    
        return suggestions[:5]
        
    async def start_ab_test(self,
                          evolution: Evolution,
                          traffic_percentage: float = 50.0) -> str:
        """Start A/B test between original and evolved agent"""
        
        experiment_id = f"exp_{evolution.id[:8]}"
        
        self.active_experiments[experiment_id] = {
            'evolution': evolution,
            'started_at': datetime.now(),
            'traffic_percentage': traffic_percentage,
            'original_requests': 0,
            'evolved_requests': 0,
            'original_success': 0,
            'evolved_success': 0,
            'original_times': [],
            'evolved_times': []
        }
        
        logger.info(f"Started A/B test {experiment_id} with {traffic_percentage}% traffic to evolved version")
        
        return experiment_id
        
    async def evaluate_ab_test(self, experiment_id: str) -> Dict[str, Any]:
        """Let LLM evaluate A/B test results"""
        
        if experiment_id not in self.active_experiments:
            return {'error': 'Experiment not found'}
            
        experiment = self.active_experiments[experiment_id]
        
        # Calculate metrics
        original_success_rate = (
            experiment['original_success'] / experiment['original_requests']
            if experiment['original_requests'] > 0 else 0
        )
        
        evolved_success_rate = (
            experiment['evolved_success'] / experiment['evolved_requests']
            if experiment['evolved_requests'] > 0 else 0
        )
        
        original_avg_time = (
            sum(experiment['original_times']) / len(experiment['original_times'])
            if experiment['original_times'] else 0
        )
        
        evolved_avg_time = (
            sum(experiment['evolved_times']) / len(experiment['evolved_times'])
            if experiment['evolved_times'] else 0
        )
        
        # Let LLM evaluate
        eval_prompt = f"""Evaluate this A/B test and recommend whether to promote the evolved version:

Test Duration: {(datetime.now() - experiment['started_at']).total_seconds() / 3600:.1f} hours

Original Version:
- Requests: {experiment['original_requests']}
- Success Rate: {original_success_rate:.2%}
- Avg Time: {original_avg_time:.3f}s

Evolved Version:
- Requests: {experiment['evolved_requests']}
- Success Rate: {evolved_success_rate:.2%}
- Avg Time: {evolved_avg_time:.3f}s

Evolution Changes: {experiment['evolution'].changes_description}

Should we promote the evolved version? Consider statistical significance and business impact.

Provide recommendation as JSON:
{{
  "promote": true/false,
  "confidence": 0-100,
  "reasoning": "explanation",
  "risks": ["risk1", "risk2"],
  "benefits": ["benefit1", "benefit2"]
}}"""
        
        response = await self.llm.generate(
            eval_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.4
        )
        
        # Parse recommendation
        try:
            recommendation = json.loads(response)
        except:
            recommendation = {
                'promote': evolved_success_rate > original_success_rate,
                'confidence': 50,
                'reasoning': 'Unable to parse LLM recommendation',
                'risks': [],
                'benefits': []
            }
            
        return {
            'experiment_id': experiment_id,
            'metrics': {
                'original': {
                    'requests': experiment['original_requests'],
                    'success_rate': original_success_rate,
                    'avg_time': original_avg_time
                },
                'evolved': {
                    'requests': experiment['evolved_requests'],
                    'success_rate': evolved_success_rate,
                    'avg_time': evolved_avg_time
                }
            },
            'recommendation': recommendation,
            'test_duration_hours': (datetime.now() - experiment['started_at']).total_seconds() / 3600
        }
        
    async def promote_evolution(self, evolution_id: str) -> bool:
        """Promote an evolved agent to production"""
        
        if evolution_id not in self.evolutions:
            return False
            
        evolution = self.evolutions[evolution_id]
        evolution.promoted = True
        evolution.promotion_date = datetime.now()
        
        logger.info(f"Promoted evolution {evolution_id} for agent {evolution.parent_agent_id}")
        
        return True
        
    async def get_evolution_suggestions(self, 
                                      agent_id: str,
                                      agent_code: str,
                                      context: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Let LLM suggest potential evolutions"""
        
        suggest_prompt = f"""Suggest potential evolutions for this agent:

Agent: {agent_id}
Context: {json.dumps(context or {}, indent=2)}
Code Preview:
```python
{agent_code[:1000]}...
```

Consider:
1. Current limitations
2. Potential optimizations
3. New features that could be added
4. Architectural improvements
5. Specialization opportunities

Suggest 3-5 evolution ideas with strategy and benefits:"""
        
        response = await self.llm.generate(
            suggest_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.7
        )
        
        # Parse suggestions
        suggestions = []
        current_suggestion = {}
        
        for line in response.split('\n'):
            line = line.strip()
            
            if line and (line[0].isdigit() or line.startswith('-')):
                if current_suggestion:
                    suggestions.append(current_suggestion)
                    
                current_suggestion = {
                    'title': line.lstrip('0123456789.-• ').strip(),
                    'strategy': EvolutionStrategy.OPTIMIZE.value,
                    'benefits': []
                }
            elif 'strategy:' in line.lower():
                strategy_text = line.split(':', 1)[1].strip()
                # Map to valid strategy
                for s in EvolutionStrategy:
                    if s.value in strategy_text.lower() or s.name.lower() in strategy_text.lower():
                        current_suggestion['strategy'] = s.value
                        break
            elif 'benefit' in line.lower() or current_suggestion.get('benefits'):
                benefit = line.strip('- •')
                if benefit:
                    current_suggestion.setdefault('benefits', []).append(benefit)
                    
        if current_suggestion:
            suggestions.append(current_suggestion)
            
        return suggestions[:5]
        
    def get_evolution_history(self, agent_id: str) -> List[Dict[str, Any]]:
        """Get evolution history for an agent"""
        
        history = self.evolution_history.get(agent_id, [])
        
        return [
            {
                'evolution': e.to_dict(),
                'success': e.test_results.get('overall_success', False) if e.test_results else None,
                'promoted': e.promoted
            }
            for e in history
        ]