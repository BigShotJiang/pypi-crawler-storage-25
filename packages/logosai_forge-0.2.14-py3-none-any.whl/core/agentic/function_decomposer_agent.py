"""
FunctionDecomposerAgent — Chain-of-Thought function decomposition.

Replaces static capability_function_map with LLM-based reasoning.
Analyzes query to decompose into FunctionSpecs using CoT:
1. Identify the core task
2. Break into sub-tasks
3. Map each sub-task to a function with inputs/outputs
4. Determine dependencies between functions

Uses AgenticMemory to recall past decomposition patterns.
"""

import asyncio
import json
import re
from typing import Dict, Any, List, Optional
from loguru import logger

from core.agentic.base import ForgeAgent

try:
    from core.direct_gemini_client import DirectGeminiClient
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False


class FunctionDecomposerAgent(ForgeAgent):
    """Decomposes queries into FunctionSpecs via Chain-of-Thought reasoning."""

    def __init__(self):
        super().__init__("FunctionDecomposer", "Chain-of-Thought function decomposition", role="decomposition")
        self._llm = None

    def _get_llm(self):
        if self._llm is None and LLM_AVAILABLE:
            self._llm = DirectGeminiClient(model_name="gemini-2.5-flash-lite")
        return self._llm

    async def decompose(
        self,
        query: str,
        domain: str = "general",
        complexity: str = "L1",
        business_rules: Optional[str] = None,
        test_cases: Optional[List[Dict]] = None,
    ) -> List[Dict[str, Any]]:
        """Decompose query into function specifications.

        Returns list of dicts with: name, description, inputs, outputs, dependencies, business_rules
        """
        response = await self.process(query, {
            "domain": domain,
            "complexity": complexity,
            "business_rules": business_rules,
            "test_cases": test_cases,
        })
        return response.content.get("functions", [])

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        domain = context.get("domain", "general")
        complexity = context.get("complexity", "L1")
        business_rules = context.get("business_rules")
        test_cases = context.get("test_cases")

        # Step 1: Check memory for similar past decompositions
        self.add_reasoning_step("observe", f"Query: {query[:60]}, domain={domain}, complexity={complexity}")
        similar = ForgeAgent.recall_similar([domain, query.split()[0] if query else ""])
        if similar:
            self.add_reasoning_step("observe", f"Found {len(similar)} similar past decompositions")

        # Step 2: Chain-of-Thought decomposition via LLM
        llm = self._get_llm()
        if llm:
            functions = await self._cot_decompose(llm, query, domain, complexity, business_rules, test_cases)
            if functions:
                self.add_reasoning_step("act", f"CoT produced {len(functions)} functions")
                ForgeAgent.remember(f"decomposition:{query[:40]}", {"functions": [f["name"] for f in functions]}, {"domain": domain})
                return {"functions": functions, "method": "chain_of_thought"}

        # Step 3: Heuristic fallback
        self.add_reasoning_step("reflect", "LLM decomposition failed, using heuristic")
        functions = self._heuristic_decompose(query, domain, complexity, business_rules, test_cases)
        return {"functions": functions, "method": "heuristic"}

    async def _cot_decompose(self, llm, query, domain, complexity, business_rules, test_cases) -> Optional[List[Dict]]:
        """Chain-of-Thought decomposition using LLM."""

        # Build test case context
        tc_context = ""
        if test_cases:
            tc0 = test_cases[0]
            inp = tc0.get("input", {})
            exp = tc0.get("expected", {})
            tc_context = f"""
Test case example:
  Input: {json.dumps(inp)[:200]}
  Expected output: {json.dumps(exp)[:200]}
"""

        rules_context = f"\nBusiness rules: {business_rules}" if business_rules else ""

        prompt = f"""Decompose this task into Python async functions. Think step-by-step.

Query: {query}
Domain: {domain}
Complexity: {complexity}{rules_context}{tc_context}

Think through this step by step:
1. What is the core task?
2. What sub-tasks are needed?
3. What are the inputs/outputs of each sub-task?
4. What are the dependencies?

Return a JSON array of functions:
```json
[
  {{
    "name": "_function_name",
    "description": "What this function does",
    "inputs": {{"param1": "type", "param2": "type"}},
    "outputs": ["output_key1", "output_key2"],
    "dependencies": [],
    "business_rules": "specific rules for this function"
  }}
]
```

Rules:
- Function names start with underscore, snake_case
- L1: 1 function, L2: 2-4 functions, L3: 5-8 functions
- Each function receives data: Dict and returns Dict
- Dependencies list function names that must run before this one"""

        try:
            response = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=2000, temperature=0.1),
                timeout=15
            )
            if not response:
                return None

            # Parse JSON from response
            functions = self._parse_functions(response)
            if functions:
                self.add_reasoning_step("think", f"CoT decomposition: {[f['name'] for f in functions]}")
                return functions

        except Exception as e:
            self.add_reasoning_step("reflect", f"CoT failed: {str(e)[:60]}")

        return None

    def _parse_functions(self, text: str) -> Optional[List[Dict]]:
        """Parse function list from LLM response."""
        try:
            # Extract JSON array
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0]
            elif "```" in text:
                text = text.split("```")[1].split("```")[0]

            text = text.strip()
            # Fix common issues
            text = re.sub(r'//.*$', '', text, flags=re.MULTILINE)
            text = text.replace("True", "true").replace("False", "false").replace("None", "null")

            functions = json.loads(text)
            if isinstance(functions, list) and len(functions) > 0:
                # Validate structure
                valid = []
                for f in functions:
                    if isinstance(f, dict) and "name" in f:
                        name = f["name"]
                        if not name.startswith("_"):
                            name = f"_{name}"
                        name = re.sub(r'[^a-z0-9_]', '', name.lower())
                        valid.append({
                            "name": name,
                            "description": f.get("description", ""),
                            "inputs": f.get("inputs", {"data": "Dict[str, Any]"}),
                            "outputs": f.get("outputs", ["result"]),
                            "dependencies": f.get("dependencies", []),
                            "business_rules": f.get("business_rules", ""),
                        })
                return valid if valid else None

        except Exception:
            pass
        return None

    def _heuristic_decompose(self, query, domain, complexity, business_rules, test_cases) -> List[Dict]:
        """Heuristic fallback when LLM fails."""
        q = query.lower()

        # Derive function name
        match = re.search(r'(?:calculate|compute|analyze|predict|evaluate|generate|create|process)\w*\s+(\w[\w\s]{0,20})', q)
        if match:
            raw = match.group(1).strip().replace(" ", "_")
            verb = re.match(r'(calculate|compute|analyze|predict|evaluate|generate|create|process)', q)
            name = f"_{verb.group(1) if verb else 'process'}_{raw}"
        else:
            name = "_process_data"
        name = re.sub(r'[^a-z0-9_]', '', name)

        # Derive inputs from test cases
        inputs = {"data": "Dict[str, Any]"}
        outputs = ["result"]
        if test_cases:
            tc0 = test_cases[0]
            inp = tc0.get("input", {})
            if isinstance(inp, dict):
                inputs = {k: type(v).__name__ for k, v in inp.items()}
            exp = tc0.get("expected", {})
            if isinstance(exp, dict):
                outputs = list(exp.keys())

        return [{
            "name": name,
            "description": query[:200],
            "inputs": inputs,
            "outputs": outputs,
            "dependencies": [],
            "business_rules": business_rules or query,
        }]
