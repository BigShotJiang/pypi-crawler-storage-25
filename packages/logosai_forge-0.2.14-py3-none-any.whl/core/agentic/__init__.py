"""
FORGE V6 Agentic Architecture
==============================
Agentic AI agents that collaborate to generate agents.
"Agents Building Agents"

Agents:
- ForgeAgent: Base class for all FORGE pipeline agents
- QueryAnalyzerAgent: Multi-agent debate for query analysis
- StrategyAgent: ReAct-based generation strategy selection
- WorkflowDesignerAgent: Debate-based workflow pattern selection
- ErrorHealerAgent: Parallel expert agents for error diagnosis
"""

from core.agentic.base import ForgeAgent

__all__ = ["ForgeAgent"]
