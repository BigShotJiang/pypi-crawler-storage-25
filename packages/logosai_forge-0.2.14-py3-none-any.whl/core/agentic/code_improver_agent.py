"""
CodeImproverAgent — Fixes AND enhances existing agent code.

Two modes:
  improve(): Targeted bug repair from failure feedback
  enhance(): Add missing logic/functions to existing agent code

improve() flow:
  1. Diagnose failure → 2. Minimal fix → 3. Validate → 4. Retry

enhance() flow (uses V6 agents):
  1. Analyze existing code (what functions exist?)
  2. FunctionDecomposerAgent: what's missing based on enhancement request?
  3. CodeGeneratorAgent: generate missing functions
  4. Merge new functions into existing code (preserve everything)
  5. ErrorHealerAgent: fix any syntax issues from merge
  6. TestValidatorAgent: validate enhanced code
"""

import asyncio
import ast
import difflib
import json
import re
from typing import Dict, Any, List, Optional
from loguru import logger

from core.agentic.base import ForgeAgent

try:
    from core.direct_gemini_client import DirectGeminiClient
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False


class CodeImproverAgent(ForgeAgent):
    """Improves and enhances existing agent code."""

    def __init__(self):
        super().__init__("CodeImprover", "Fixes and enhances existing agent code", role="improvement")
        self._llm = None
        # Lazy-loaded V6 agents for enhance/improve mode
        self._decomposer = None
        self._generator = None
        self._healer = None
        self._strategy = None

    def _get_llm(self):
        if self._llm is None and LLM_AVAILABLE:
            self._llm = DirectGeminiClient(model_name="gemini-2.5-flash-lite")
        return self._llm

    async def improve(
        self,
        agent_code: str,
        failure_log: Dict[str, Any],
        max_attempts: int = 2,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Improve agent code based on failure feedback.

        Args:
            agent_code: Current agent source code
            failure_log: Failure context dict
            max_attempts: Maximum fix attempts
            dry_run: If True, return plan only (no code modification)

        Returns: {
            "success": bool,
            "improved_code": str,
            "diff": str,
            "changes": List[str],
            "confidence": float,
            "attempts": int,
        }
        """
        response = await self.process(
            f"Improve code for {failure_log.get('error_type', 'unknown')} error",
            {"agent_code": agent_code, "failure_log": failure_log,
             "max_attempts": max_attempts, "dry_run": dry_run}
        )
        return response.content

    # Size thresholds from config (overridable via YAML or env vars)
    @property
    def SIZE_SMALL(self):
        try:
            from config import get_value
            return get_value("improve", "size_small", 5000)
        except Exception:
            return 5000

    @property
    def SIZE_LARGE(self):
        try:
            from config import get_value
            return get_value("improve", "size_large", 15000)
        except Exception:
            return 15000

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        agent_code = context.get("agent_code", "")
        failure_log = context.get("failure_log", {})
        max_attempts = context.get("max_attempts", 2)
        dry_run = context.get("dry_run", False)
        code_size = len(agent_code)

        self.add_reasoning_step("observe",
            f"Error: {failure_log.get('error_type', '?')} — {failure_log.get('error_message', '?')[:60]} "
            f"(code: {code_size // 1024}KB, dry_run={dry_run})")

        llm = self._get_llm()
        if not llm:
            return {"success": False, "improved_code": agent_code, "diff": "",
                    "changes": [], "confidence": 0, "attempts": 0, "error": "LLM unavailable",
                    "scope": "none", "functions_changed": [], "functions_preserved": []}

        # Dry-run mode: diagnose + plan only, no code modification
        if dry_run:
            return await self._dry_run_plan(llm, agent_code, failure_log)

        # Strategy based on code size
        allow_fallback = code_size < self.SIZE_SMALL

        # Try function-level improve first (like create/enhance pipeline)
        func_result = await self._function_level_improve(llm, agent_code, failure_log)
        if func_result and func_result.get("success"):
            self.add_reasoning_step("act", f"Function-level fix succeeded (conf={func_result['confidence']:.2f})")
            return func_result

        if not allow_fallback:
            self.add_reasoning_step("reflect",
                f"Function-level failed, code too large ({code_size // 1024}KB) for whole-code fallback")
            return {
                "success": False, "improved_code": agent_code, "diff": "",
                "changes": [], "confidence": 0, "attempts": 1,
                "scope": "function_level", "functions_changed": [], "functions_preserved": [],
                "error": f"Code too large ({code_size}B) for whole-code fix. Function-level fix failed.",
            }

        self.add_reasoning_step("reflect", "Function-level failed, falling back to whole-code (small code)")

        # Fallback: LLM whole-code fix (only for small agents <5KB)
        best_code = agent_code
        best_confidence = 0

        for attempt in range(max_attempts):
            self.add_reasoning_step("think", f"Fallback attempt {attempt + 1}/{max_attempts}")

            diagnosis = await self._diagnose(llm, agent_code if attempt == 0 else best_code, failure_log)
            if not diagnosis:
                continue

            fixed_code = await self._generate_fix(llm, best_code, failure_log, diagnosis)
            if not fixed_code:
                continue

            try:
                ast.parse(fixed_code)
            except SyntaxError:
                continue

            struct_check = self._validate_improvement(agent_code, fixed_code)
            if not struct_check["valid"]:
                self.add_reasoning_step("reflect", f"Fallback structure broken: {struct_check['errors']}")
                continue

            validation = await self._validate_fix(fixed_code, failure_log)

            if validation["passed"]:
                diff = self._generate_diff(agent_code, fixed_code)
                changes = self._extract_changes(agent_code, fixed_code)
                ForgeAgent.remember(
                    f"fix_pattern:{failure_log.get('error_type', '')}:{failure_log.get('error_message', '')[:30]}",
                    {"diagnosis": diagnosis, "changes": changes}, {"success": True}
                )
                before_q = self._evaluate_code_quality(agent_code)
                after_q = self._evaluate_code_quality(fixed_code)
                return {
                    "success": True, "improved_code": fixed_code, "diff": diff,
                    "changes": changes, "confidence": validation["confidence"], "attempts": attempt + 1,
                    "scope": "full_rewrite",
                    "functions_changed": self._extract_existing_functions(fixed_code),
                    "functions_preserved": [],
                    "quality_metrics": {
                        "before": before_q, "after": after_q,
                        "improvement_delta": round(after_q["overall"] - before_q["overall"], 3),
                    },
                }
            else:
                best_code = fixed_code
                best_confidence = max(best_confidence, validation.get("confidence", 0))
                failure_log = {**failure_log, "previous_fix_feedback": validation.get("feedback", "")}

        diff = self._generate_diff(agent_code, best_code)
        changes = self._extract_changes(agent_code, best_code)
        return {
            "success": False, "improved_code": best_code, "diff": diff,
            "changes": changes, "confidence": best_confidence, "attempts": max_attempts,
            "scope": "full_rewrite", "functions_changed": [], "functions_preserved": [],
        }

    async def _function_level_improve(self, llm, agent_code: str, failure_log: Dict) -> Optional[Dict]:
        """Function-level improve: diagnose → regenerate broken function → replace → heal → validate.

        Same approach as create/enhance pipeline: work at function granularity.
        Returns None if this approach can't handle the case.
        """
        try:
            # Step 1: Extract functions using AST (handles docstrings, blank lines, try/except)
            func_names = self._extract_existing_functions(agent_code)
            if not func_names:
                return None

            existing_funcs = {}
            for fn in func_names:
                code_block = self._extract_function_code(agent_code, fn)
                if code_block:
                    existing_funcs[fn] = code_block

            if not existing_funcs:
                return None

            func_names = list(existing_funcs.keys())
            self.add_reasoning_step("observe", f"Functions found (AST): {func_names}")

            # Step 1.5 (Cross-Agent Learning): Search patterns from other agents
            cross_hints = ""
            try:
                error_type = failure_log.get("error_type", "")
                error_msg = failure_log.get("error_message", "")[:30]
                similar_patterns = ForgeAgent.recall_similar(
                    ["cross_fix", error_type, error_msg], top_k=3,
                )
                if similar_patterns:
                    cross_hints = "\nPrevious similar fixes from other agents:\n"
                    for item in similar_patterns:
                        val = item.get("value", {})
                        cross_hints += f"- {val.get('diagnosis', '')[:100]}\n"
                        changes = val.get("changes", [])
                        if changes:
                            cross_hints += f"  Fix: {str(changes[:2])[:80]}\n"
                    self.add_reasoning_step("observe", f"Cross-agent patterns found: {len(similar_patterns)}")
            except Exception:
                pass

            # Step 2: Diagnose which function is broken
            signatures = self._extract_function_signatures(agent_code)
            sigs_text = "\n".join(signatures) if signatures else str(func_names)

            # Context-managed code inclusion (replaces hardcoded truncation)
            from core.llm_context_manager import fit_to_context
            code_context = ""
            if len(agent_code) < self.SIZE_SMALL:
                ctx = fit_to_context([{"content": agent_code, "priority": 2, "label": "full_code"}], max_tokens=2000)
                code_context = f"\nFull code:\n```python\n{ctx['text']}\n```"
            else:
                custom = [f for f in func_names if f not in ("_process_core_logic", "_execute")]
                sections = [{"content": existing_funcs.get(fn, ""), "priority": 2, "label": fn}
                            for fn in custom[:3] if existing_funcs.get(fn)]
                ctx = fit_to_context(sections, max_tokens=1500)
                for sec in ctx["sections"]:
                    code_context += f"\n{sec['label']}:\n```python\n{sec['content']}\n```\n"

            # Dynamic timeout based on code size
            diag_timeout = 10 + (len(agent_code) // 5000) * 5  # +5s per 5KB

            diag_prompt = f"""Which function has the bug? Return JSON only.

Function signatures:
{sigs_text}

Error: {failure_log.get('error_message', '')}
Expected: {str(failure_log.get('expected_output', ''))[:200]}
Actual: {str(failure_log.get('actual_output', ''))[:200]}
{code_context}
{cross_hints}
Return: {{"broken_function": "function_name", "diagnosis": "brief explanation"}}"""

            diag_resp = await asyncio.wait_for(
                llm.generate(diag_prompt, max_tokens=300, temperature=0.1), timeout=diag_timeout)
            if not diag_resp:
                return None

            import json as _json
            try:
                diag = _json.loads(diag_resp.strip().strip('```json').strip('```'))
            except Exception:
                diag = {"broken_function": func_names[0], "diagnosis": diag_resp.strip()}

            broken_func = diag.get("broken_function", "")
            diagnosis = diag.get("diagnosis", "")

            if broken_func not in existing_funcs:
                # LLM returned unknown function — try first custom function
                custom_funcs = [f for f in func_names if f not in ("_process_core_logic", "_execute")]
                broken_func = custom_funcs[0] if custom_funcs else func_names[0]

            self.add_reasoning_step("think", f"Broken function: {broken_func} — {diagnosis[:60]}")

            # Step 3: Repair broken function (improve-specific, not CodeGeneratorAgent)
            logger.info(f"[CodeImprover] Step 3: repairing {broken_func}")
            broken_code = existing_funcs.get(broken_func, "")
            new_func_code = await self._repair_function(
                broken_code=broken_code,
                diagnosis=diagnosis,
                failure_log=failure_log,
            )
            if not new_func_code:
                self.add_reasoning_step("reflect", f"_repair_function returned None for {broken_func}")
                return None

            self.add_reasoning_step("act", f"Repaired {broken_func}")

            # Step 4: Replace broken function in original code
            old_func_code = existing_funcs[broken_func]
            improved_code = agent_code.replace(old_func_code, new_func_code)

            # Step 5: Heal syntax errors
            try:
                ast.parse(improved_code)
            except SyntaxError as e:
                self.add_reasoning_step("think", f"Healing syntax: {e}")
                if self._healer is None:
                    from core.agentic.error_healer_agent import ErrorHealerAgent
                    self._healer = ErrorHealerAgent()
                heal_result = await self._healer.heal(improved_code, str(e), broken_func)
                if heal_result.get("healed"):
                    improved_code = heal_result["code"]
                else:
                    return None  # Can't heal, fallback to whole-code

            # Step 6: Structure validation (essential methods preserved)
            struct_check = self._validate_improvement(agent_code, improved_code)
            if not struct_check["valid"]:
                self.add_reasoning_step("reflect", f"Structure broken: {struct_check['errors']}")
                return None

            # Step 7: Functional validation (test case)
            # Try quick direct validation first (for simple agents with plain process())
            validation = {"passed": False, "confidence": 0}
            test_input = failure_log.get("test_input", {})
            expected = failure_log.get("expected_output", {})
            if test_input and expected:
                try:
                    ns = {"json": __import__("json"), "asyncio": __import__("asyncio"),
                          "Dict": dict, "Any": object, "List": list, "Optional": type(None)}
                    exec(improved_code, ns)
                    agent_cls = None
                    for _n, _o in ns.items():
                        if isinstance(_o, type) and hasattr(_o, 'process') and _n not in ('LogosAIAgent',):
                            agent_cls = _o
                            break
                    if agent_cls:
                        _agent = agent_cls()
                        _resp = await asyncio.wait_for(
                            _agent.process(json.dumps(test_input)), timeout=5)
                        _content = getattr(_resp, 'content', _resp)
                        _flat = str(_content).lower()
                        if str(expected).lower() in _flat:
                            validation = {"passed": True, "confidence": 1.0}
                except Exception:
                    pass

            # Fallback to full _validate_fix if quick check didn't pass
            if not validation["passed"]:
                validation = await self._validate_fix(improved_code, failure_log)

            if validation["passed"]:
                diff = self._generate_diff(agent_code, improved_code)
                changes = self._extract_changes(agent_code, improved_code)
                ForgeAgent.remember(
                    f"func_fix:{failure_log.get('error_type', '')}:{broken_func}",
                    {"broken_function": broken_func, "diagnosis": diagnosis, "changes": changes},
                    {"success": True, "method": "function_level"},
                )
                # Cross-agent learning: save universal pattern
                pattern_tag = self._extract_pattern_tag(diagnosis, failure_log.get("error_message", ""))
                ForgeAgent.remember(
                    f"cross_fix:{failure_log.get('error_type', '')}:{pattern_tag}",
                    {"diagnosis": diagnosis, "changes": changes,
                     "error_pattern": failure_log.get("error_message", "")[:100],
                     "source_function": broken_func, "success_count": 1},
                    {"success": True, "method": "cross_agent_learning"},
                )
                # Register new function version
                try:
                    from core.function_registry import FunctionRegistry
                    registry = FunctionRegistry.get_instance()
                    new_func_code = self._extract_function_code(improved_code, broken_func)
                    if new_func_code:
                        registry.register_version(broken_func, new_func_code,
                            quality_score=validation["confidence"],
                            change_reason=f"fix: {diagnosis[:80]}")
                except Exception:
                    pass

                # Report scope + quality metrics
                all_funcs = self._extract_existing_functions(improved_code)
                preserved = [f for f in all_funcs if f != broken_func]
                before_q = self._evaluate_code_quality(agent_code)
                after_q = self._evaluate_code_quality(improved_code)
                return {
                    "success": True, "improved_code": improved_code, "diff": diff,
                    "changes": changes, "confidence": validation["confidence"], "attempts": 1,
                    "scope": "function_level",
                    "functions_changed": [broken_func],
                    "functions_preserved": preserved,
                    "quality_metrics": {
                        "before": before_q, "after": after_q,
                        "improvement_delta": round(after_q["overall"] - before_q["overall"], 3),
                    },
                }
            else:
                self.add_reasoning_step("reflect", f"Function-level validation failed: {validation.get('feedback', '')[:60]}")
                return None

        except Exception as e:
            import traceback
            logger.warning(f"[CodeImprover] Function-level improve error: {e}\n{traceback.format_exc()[:500]}")
            self.add_reasoning_step("reflect", f"Function-level improve error: {e}")
            return None

    async def _repair_function(self, broken_code: str, diagnosis: str, failure_log: Dict) -> Optional[str]:
        """Repair a broken function by asking LLM to fix it in-place.

        Unlike CodeGeneratorAgent (which creates from scratch with data: Dict signature),
        this preserves the original function signature, structure, and calling convention.
        Returns the fixed function code with original indentation, or None.
        """
        llm = self._get_llm()
        if not llm:
            return None

        test_input = failure_log.get("test_input", {})
        expected = failure_log.get("expected_output", {})
        actual = failure_log.get("actual_output", {})

        # Build repair prompt — error_message often contains the correct logic mapping
        error_msg = failure_log.get('error_message', '')
        prompt = (
            f"Fix this Python function. Return ONLY the fixed function code.\n\n"
            f"{broken_code}\n\n"
            f"BUG: {diagnosis}\n\n"
            f"The correct behavior is described here:\n{error_msg}\n\n"
        )
        if test_input and expected:
            prompt += (
                f"VERIFY your fix: Input={json.dumps(test_input)[:200]} must return {str(expected)[:200]}\n"
                f"(currently returns {str(actual)[:200]})\n\n"
            )
        prompt += (
            "IMPORTANT:\n"
            "- Keep the EXACT same function signature\n"
            "- Apply the correct behavior described above\n"
            "- Make sure the values/rates match the description, not just the order\n"
            "- Return ONLY the function code"
        )

        try:
            resp = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=1000, temperature=0.1), timeout=15)
            if not resp:
                return None

            fixed = resp.strip()
            # Extract code from markdown if present
            if '```' in fixed:
                for part in fixed.split('```'):
                    if 'def ' in part:
                        fixed = part.replace('python', '', 1).strip()
                        break

            # Match indentation to original
            orig_lines = broken_code.split("\n")
            orig_indent = ""
            for line in orig_lines:
                if line.strip().startswith("def ") or line.strip().startswith("async def "):
                    orig_indent = line[:len(line) - len(line.lstrip())]
                    break

            fixed_lines = fixed.split("\n")
            fixed_indent = ""
            for line in fixed_lines:
                if line.strip().startswith("def ") or line.strip().startswith("async def "):
                    fixed_indent = line[:len(line) - len(line.lstrip())]
                    break

            # Re-indent if needed
            if orig_indent != fixed_indent:
                reindented = []
                for line in fixed_lines:
                    if not line.strip():
                        reindented.append("")
                    elif line.startswith(fixed_indent):
                        reindented.append(orig_indent + line[len(fixed_indent):])
                    else:
                        reindented.append(orig_indent + line.lstrip())
                fixed = "\n".join(reindented)

            # Syntax check — try multiple wrapping strategies
            syntax_ok = False
            for wrapper in [f"class _T:\n{fixed}", fixed, f"class _T:\n    pass\n{fixed}"]:
                try:
                    ast.parse(wrapper)
                    syntax_ok = True
                    break
                except SyntaxError:
                    continue
            if not syntax_ok:
                logger.debug(f"[CodeImprover] _repair_function: syntax error in fixed code:\n{fixed[:200]}")
                return None

            return fixed
        except Exception as e:
            logger.debug(f"[CodeImprover] _repair_function failed: {e}")
            return None

    async def _diagnose(self, llm, code: str, failure: Dict) -> Optional[str]:
        """LLM diagnoses the specific bug (fallback mode — uses function signatures for large code)."""
        # Smart code truncation: signatures for large, more code for small
        if len(code) > self.SIZE_SMALL:
            sigs = self._extract_function_signatures(code)
            code_section = "Function signatures:\n" + "\n".join(sigs)
        else:
            from core.llm_context_manager import fit_to_context
            ctx = fit_to_context([{"content": code, "priority": 2, "label": "code"}], max_tokens=2000)
            code_section = f"Code:\n```python\n{ctx['text']}\n```"

        timeout = 10 + (len(code) // 5000) * 5

        prompt = f"""Analyze this Python code failure. Identify the SPECIFIC bug.

Error type: {failure.get('error_type', 'unknown')}
Error message: {failure.get('error_message', 'N/A')}
Test input: {str(failure.get('test_input', {}))[:300]}
Expected output: {str(failure.get('expected_output', {}))[:300]}
Actual output: {str(failure.get('actual_output', {}))[:300]}

{code_section}

Explain:
1. Which function/method contains the bug?
2. What specific line or condition is wrong?
3. Why does it produce the actual output instead of expected?
4. How should it be fixed (specific change)?"""

        try:
            response = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=500, temperature=0.1), timeout=timeout)
            return response.strip() if response else None
        except Exception as e:
            logger.warning(f"[CodeImprover] _diagnose failed: {e}")
            return None

    async def _generate_fix(self, llm, code: str, failure: Dict, diagnosis: str) -> Optional[str]:
        """LLM generates minimal code fix."""
        prev_feedback = failure.get("previous_fix_feedback", "")
        feedback_section = f"\nPrevious fix attempt failed: {prev_feedback}" if prev_feedback else ""

        # Build test verification section
        test_input = failure.get('test_input', {})
        expected = failure.get('expected_output', {})
        actual = failure.get('actual_output', {})
        verify = ""
        if test_input and expected:
            verify = f"\nVERIFY your fix with this test:\n  Input: {json.dumps(test_input)[:200]}\n  Must return: {str(expected)[:200]}\n  Currently returns: {str(actual)[:200]}\n"

        prompt = f"""Fix the bug in this Python code. Return ONLY the complete fixed code, no markdown.

DIAGNOSIS: {diagnosis}

Error: {failure.get('error_message', '')}
{verify}{feedback_section}

{code}

Rules:
- Fix ONLY the specific bug described in DIAGNOSIS
- Keep all existing function names, class structure, imports
- Return the COMPLETE file content"""

        timeout = 20 + (len(code) // 5000) * 5  # Dynamic timeout
        try:
            response = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=4000, temperature=0.1), timeout=timeout)
            if not response:
                return None

            fixed = response.strip()
            if '```python' in fixed:
                fixed = fixed.split('```python')[1].split('```')[0].strip()
            elif '```' in fixed:
                fixed = fixed.split('```')[1].split('```')[0].strip()

            return fixed if fixed else None
        except Exception as e:
            logger.warning(f"[CodeImprover] _generate_fix failed: {e}")
            return None

    async def _validate_fix(self, code: str, failure: Dict) -> Dict:
        """Run the fix against the failure's test case."""
        test_input = failure.get("test_input", {})
        expected = failure.get("expected_output", {})

        if not test_input or not expected:
            return {"passed": True, "confidence": 0.6, "feedback": "No test case to validate"}

        try:
            # Execute code
            ns = {"Dict": dict, "Any": object, "List": list, "Optional": type(None),
                  "math": __import__("math"), "json": __import__("json")}

            # Patch AgentConfig if needed
            try:
                import inspect
                from logosai.config import AgentConfig
                from logosai.agent_types import AgentType
                _orig = AgentConfig.__init__
                _vp = set(inspect.signature(_orig).parameters.keys()) - {'self'}
                def _fi(self_c, name='X', agent_type=None, description='X', **kw):
                    if agent_type is None: agent_type = AgentType.CUSTOM
                    _orig(self_c, name=name, agent_type=agent_type, description=description,
                          **{k: v for k, v in kw.items() if k in _vp})
                    for k, v in kw.items():
                        if k not in _vp: setattr(self_c, k, v)
                AgentConfig.__init__ = _fi
            except Exception as e:
                logger.debug(f"[CodeImprover] AgentConfig patch skipped: {e}")

            exec(code, ns)

            # Find agent class
            agent_cls = None
            for n, o in ns.items():
                if isinstance(o, type) and hasattr(o, 'process') and n not in ('LogosAIAgent',):
                    agent_cls = o
                    break

            if not agent_cls:
                return {"passed": False, "confidence": 0.3, "feedback": "No agent class found"}

            agent = agent_cls()

            # Try multiple execution paths — collect all candidates, pick best match
            candidates = []
            SKIP_METHODS = {'_execute', '_process_core_logic', '_should_enable_agentic',
                            '_setup_agentic_modules', '_generate_dialogue_response',
                            '_on_dialogue_invite', '_on_dialogue_message'}

            # Path 1: _process_core_logic / execute_workflow (V6 generated agents)
            for method_name in ["_process_core_logic", "execute_workflow"]:
                m = getattr(agent, method_name, None)
                if m and asyncio.iscoroutinefunction(m):
                    try:
                        out = await asyncio.wait_for(m(test_input), timeout=5)
                        if out and isinstance(out, dict):
                            candidates.append(out)
                    except Exception:
                        continue

            # Path 2: process(query, context=test_input) — LogosAI standard interface
            try:
                import json as _json
                query_str = _json.dumps(test_input)  # JSON string, not Python repr
                resp = await asyncio.wait_for(
                    agent.process(query_str, context=test_input), timeout=5)
                if resp is not None:
                    content = getattr(resp, 'content', resp)
                    if isinstance(content, dict):
                        candidates.append(content)
                    elif content is not None:
                        # Non-dict response (string, number) — wrap for comparison
                        candidates.append({"answer": str(content)})
            except Exception:
                pass

            # Path 3: Try custom async methods (max 5 to avoid timeout on large agents)
            tried = 0
            MAX_CUSTOM_TRIES = 5
            for attr_name in dir(agent):
                if tried >= MAX_CUSTOM_TRIES:
                    break
                if not attr_name.startswith('_') or attr_name.startswith('__'):
                    continue
                if attr_name in SKIP_METHODS:
                    continue
                m = getattr(agent, attr_name, None)
                if m and asyncio.iscoroutinefunction(m):
                    tried += 1
                    try:
                        out = await asyncio.wait_for(m(**test_input), timeout=3)
                        if out and isinstance(out, dict):
                            candidates.append(out)
                    except TypeError:
                        try:
                            out = await asyncio.wait_for(m(test_input), timeout=3)
                            if out and isinstance(out, dict):
                                candidates.append(out)
                        except Exception:
                            continue
                    except Exception:
                        continue

            if not candidates:
                return {"passed": False, "confidence": 0.2, "feedback": "No output from any agent method"}

            # Pick candidate with best match against expected
            output = candidates[0]
            best_match = -1
            for cand in candidates:
                match_count = 0
                if isinstance(expected, dict) and isinstance(cand, dict):
                    for k, v in expected.items():
                        av = cand.get(k)
                        if av is not None:
                            if isinstance(v, (int, float)) and isinstance(av, (int, float)):
                                if abs(av - v) <= max(1, abs(v) * 0.1):
                                    match_count += 1
                            elif isinstance(v, str) and str(av).lower() == v.lower():
                                match_count += 1
                            elif av == v:
                                match_count += 1
                if match_count > best_match:
                    best_match = match_count
                    output = cand

            # Compare output with expected
            matched_keys = 0
            total_keys = len(expected) if isinstance(expected, dict) else 1

            if isinstance(expected, dict) and isinstance(output, dict):
                for k, v in expected.items():
                    av = output.get(k)
                    if av is None:
                        for ov in output.values():
                            if isinstance(ov, dict) and k in ov:
                                av = ov[k]
                                break
                    if av is not None:
                        if isinstance(v, (int, float)) and isinstance(av, (int, float)):
                            if abs(av - v) <= max(1, abs(v) * 0.1):
                                matched_keys += 1
                        elif isinstance(v, str) and str(av).lower() == v.lower():
                            matched_keys += 1
            elif isinstance(expected, str):
                # String expected — search all output values for contains match
                flat = str(output).lower() if not isinstance(output, dict) else " ".join(str(v).lower() for v in output.values())
                if expected.lower() in flat:
                    matched_keys = 1
            elif isinstance(expected, (int, float)):
                # Numeric expected — search output for matching number
                flat = str(output)
                import re as _re
                nums = [float(m) for m in _re.findall(r'[-+]?\d+\.?\d*', flat)]
                for n in nums:
                    if expected == 0 or abs(n - expected) / max(abs(expected), 1e-10) <= 0.05:
                        matched_keys = 1
                        break

            confidence = matched_keys / max(1, total_keys)
            passed = matched_keys == total_keys

            feedback = ""
            if not passed:
                feedback = f"Matched {matched_keys}/{total_keys} keys. Output: {str(output)[:100]}"

            return {"passed": passed, "confidence": confidence, "feedback": feedback}

        except Exception as e:
            return {"passed": False, "confidence": 0.1, "feedback": f"Execution error: {str(e)[:60]}"}

    def _evaluate_code_quality(self, code: str) -> Dict:
        """Fast code quality evaluation (AST-based, no LLM call)."""
        metrics = {"functional": 0.0, "code_quality": 0.0, "overall": 0.0}
        try:
            tree = ast.parse(code)
            metrics["functional"] = 1.0  # Syntax valid

            # Count quality indicators
            funcs = [n for n in ast.walk(tree) if isinstance(n, (ast.AsyncFunctionDef, ast.FunctionDef))]
            classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
            try_blocks = [n for n in ast.walk(tree) if isinstance(n, ast.Try)]
            returns = [n for n in ast.walk(tree) if isinstance(n, ast.Return)]
            docstrings = sum(1 for n in funcs if ast.get_docstring(n))

            lines = len(code.split("\n"))
            has_process = any(f.name == "process" for f in funcs if isinstance(f, ast.AsyncFunctionDef))
            has_error_handling = len(try_blocks) > 0
            has_returns = len(returns) > 0
            has_class = len(classes) > 0

            # Score components
            structure = 0.25 * has_class + 0.25 * has_process + 0.25 * has_error_handling + 0.25 * has_returns
            coverage = min(1.0, docstrings / max(len(funcs), 1))
            complexity = min(1.0, len(funcs) / max(lines / 20, 1))

            metrics["code_quality"] = round(structure * 0.5 + coverage * 0.25 + complexity * 0.25, 3)
            metrics["overall"] = round(metrics["functional"] * 0.6 + metrics["code_quality"] * 0.4, 3)
            metrics["functions"] = len(funcs)
            metrics["lines"] = lines
            metrics["error_handling"] = has_error_handling
        except SyntaxError:
            metrics["functional"] = 0.0
            metrics["code_quality"] = 0.0
            metrics["overall"] = 0.0
        return metrics

    async def _dry_run_plan(self, llm, agent_code: str, failure_log: Dict) -> Dict:
        """Dry-run mode: diagnose + plan without modifying code."""
        # Extract functions for context
        func_names = self._extract_existing_functions(agent_code)
        signatures = self._extract_function_signatures(agent_code)

        # Diagnose
        diagnosis = await self._diagnose(llm, agent_code, failure_log)

        # Identify broken function
        broken_func = ""
        if func_names:
            import json as _json
            diag_prompt = f"""Which function has the bug? Return JSON only.
Functions: {func_names}
Error: {failure_log.get('error_message', '')}
Return: {{"broken_function": "function_name"}}"""
            try:
                resp = await asyncio.wait_for(llm.generate(diag_prompt, max_tokens=200, temperature=0.1), timeout=10)
                diag = _json.loads(resp.strip().strip('```json').strip('```'))
                broken_func = diag.get("broken_function", "")
            except Exception:
                broken_func = func_names[0] if func_names else ""

        # Build plan
        changes = []
        if broken_func:
            changes.append({"function": broken_func, "action": "regenerate", "reason": diagnosis or failure_log.get("error_message", "")})
        else:
            changes.append({"function": "unknown", "action": "full_rewrite", "reason": diagnosis or "Could not identify specific function"})

        # Estimate confidence
        est_confidence = 0.85 if broken_func in (func_names or []) else 0.5

        return {
            "success": True,
            "dry_run": True,
            "improved_code": agent_code,  # Unchanged
            "diff": "",
            "changes": changes,
            "confidence": 0,
            "estimated_confidence": est_confidence,
            "diagnosis": diagnosis or "",
            "broken_function": broken_func,
            "functions": func_names,
            "signatures": signatures,
            "scope": "function_level" if broken_func else "full_rewrite",
            "functions_changed": [],
            "functions_preserved": func_names,
            "attempts": 0,
        }

    def _validate_improvement(self, original_code: str, improved_code: str) -> Dict:
        """Validate that improvement preserves essential agent structure.

        Returns:
            {"valid": bool, "errors": [str]}
        """
        errors = []

        # 1. LogosAIAgent inheritance (only check if original had it)
        if "LogosAIAgent" in original_code and "LogosAIAgent" not in improved_code:
            errors.append("LogosAIAgent inheritance missing")

        # 2. process() method exists (check both sync and async)
        has_process = ("async def process(self" in improved_code or "def process(self" in improved_code)
        if not has_process:
            errors.append("process() method missing")

        # 3. AgentResponse return (only check if original had it)
        if "AgentResponse(" in original_code and "AgentResponse(" not in improved_code:
            errors.append("AgentResponse return missing")

        # 4. Check existing public methods are preserved (non-underscore or process)
        orig_public = set(re.findall(r'async def (process|shutdown)\(', original_code))
        impr_public = set(re.findall(r'async def (process|shutdown)\(', improved_code))
        missing_public = orig_public - impr_public
        if missing_public:
            errors.append(f"Public methods lost: {missing_public}")

        # 5. Syntax valid
        try:
            ast.parse(improved_code)
        except SyntaxError as e:
            errors.append(f"Syntax error: {e}")

        return {"valid": len(errors) == 0, "errors": errors}

    def _extract_pattern_tag(self, diagnosis: str, error_message: str) -> str:
        """Extract a generic pattern tag for cross-agent learning."""
        msg = (diagnosis + " " + error_message).lower()
        if any(w in msg for w in [">=", "<=", "boundary", "threshold", "inclusive"]):
            return "boundary_comparison"
        if any(w in msg for w in ["> ", "< ", "comparison", "condition"]):
            return "boundary_comparison"
        if any(w in msg for w in ["timeout", "hang", "slow", "took too long"]):
            return "timeout_handling"
        if any(w in msg for w in ["try", "except", "error handling", "exception"]):
            return "error_handling"
        if any(w in msg for w in ["answer", "return format", "response format"]):
            return "return_format"
        if any(w in msg for w in ["missing", "not found"]):
            return "missing_logic"
        return "general_fix"

    def _generate_diff(self, original: str, improved: str) -> str:
        """Generate unified diff."""
        orig_lines = original.splitlines(keepends=True)
        impr_lines = improved.splitlines(keepends=True)
        diff = difflib.unified_diff(orig_lines, impr_lines, fromfile="original", tofile="improved")
        return "".join(diff)

    def _extract_changes(self, original: str, improved: str) -> List[str]:
        """Extract human-readable list of changes."""
        changes = []
        orig_lines = set(original.splitlines())
        impr_lines = set(improved.splitlines())

        added = impr_lines - orig_lines
        removed = orig_lines - impr_lines

        if added:
            for line in list(added)[:5]:
                stripped = line.strip()
                if stripped and not stripped.startswith('#'):
                    changes.append(f"+ {stripped[:60]}")
        if removed:
            for line in list(removed)[:5]:
                stripped = line.strip()
                if stripped and not stripped.startswith('#'):
                    changes.append(f"- {stripped[:60]}")

        return changes if changes else ["Minor formatting/logic changes"]

    # ================================================================
    # ENHANCE MODE — Add missing logic/functions using V6 agents
    # ================================================================

    def _ensure_v6_agents(self):
        """Lazy-load V6 agents for enhance mode."""
        if self._decomposer is None:
            from core.agentic.function_decomposer_agent import FunctionDecomposerAgent
            from core.agentic.code_generator_agent import CodeGeneratorAgent
            from core.agentic.error_healer_agent import ErrorHealerAgent
            self._decomposer = FunctionDecomposerAgent()
            self._generator = CodeGeneratorAgent()
            self._healer = ErrorHealerAgent()

    async def enhance(
        self,
        agent_code: str,
        enhancement_request: str,
        test_cases: List[Dict] = None,
    ) -> Dict[str, Any]:
        """Add missing logic/functions to existing agent code.

        Args:
            agent_code: Current agent source code
            enhancement_request: What to add (e.g., "add multiply and divide methods")
            test_cases: Optional test cases for validation

        Returns: {
            "success": bool,
            "enhanced_code": str,
            "diff": str,
            "added_functions": List[str],
            "changes": List[str],
            "confidence": float,
        }
        """
        self.add_reasoning_step("observe", f"Enhancement: {enhancement_request[:60]}")
        self._ensure_v6_agents()
        llm = self._get_llm()

        try:
            # Step 1: Analyze existing code — what functions already exist?
            existing_funcs = self._extract_existing_functions(agent_code)
            self.add_reasoning_step("observe", f"Existing functions: {existing_funcs}")

            # Step 2: Decompose enhancement request — what new functions are needed?
            self.add_reasoning_step("think", "Decomposing enhancement request with FunctionDecomposerAgent")
            new_specs = await self._decomposer.decompose(
                query=enhancement_request,
                domain="enhancement",
                complexity="L1",
                business_rules=f"Existing functions: {existing_funcs}. Add ONLY what's missing. Do NOT recreate existing functions.",
            )

            # Filter out specs for functions that already exist
            specs_to_add = []
            for spec in new_specs:
                name = spec.get("name", "")
                if name not in existing_funcs and not any(name in ef for ef in existing_funcs):
                    specs_to_add.append(spec)
                else:
                    self.add_reasoning_step("observe", f"Skipping {name} — already exists")

            if not specs_to_add:
                self.add_reasoning_step("reflect", "No new functions needed — all already exist")
                return {
                    "success": True,
                    "enhanced_code": agent_code,
                    "diff": "",
                    "added_functions": [],
                    "changes": ["No changes needed — all functions already exist"],
                    "confidence": 1.0,
                }

            self.add_reasoning_step("think", f"Need to add {len(specs_to_add)} functions: {[s['name'] for s in specs_to_add]}")

            # Step 3: Generate code for missing functions
            self.add_reasoning_step("act", "Generating new functions with CodeGeneratorAgent")
            new_functions = await self._generator.generate_functions(
                specs=specs_to_add,
                strategy="llm",
                domain="enhancement",
            )

            if not new_functions:
                self.add_reasoning_step("reflect", "CodeGeneratorAgent returned no functions")
                return {"success": False, "enhanced_code": agent_code, "diff": "",
                        "added_functions": [], "changes": [], "confidence": 0}

            self.add_reasoning_step("act", f"Generated {len(new_functions)} functions")

            # Step 4: Merge new functions into existing code
            self.add_reasoning_step("think", "Merging new functions into existing code")
            enhanced_code = await self._merge_functions(llm, agent_code, new_functions, enhancement_request)

            if not enhanced_code:
                self.add_reasoning_step("reflect", "Merge failed")
                return {"success": False, "enhanced_code": agent_code, "diff": "",
                        "added_functions": list(new_functions.keys()), "changes": [], "confidence": 0}

            # Step 5: Heal syntax errors if any
            try:
                ast.parse(enhanced_code)
            except SyntaxError as e:
                self.add_reasoning_step("think", f"Healing syntax: {e}")
                heal_result = await self._healer.heal(enhanced_code, str(e))
                if heal_result.get("healed"):
                    enhanced_code = heal_result["code"]

            # Step 6: Validate
            try:
                ast.parse(enhanced_code)
                syntax_ok = True
            except SyntaxError:
                syntax_ok = False

            # Verify new functions are present in enhanced code
            added = []
            for name in new_functions:
                if f"def {name}(" in enhanced_code or f"def {name} (" in enhanced_code:
                    added.append(name)

            confidence = 0.9 if syntax_ok and len(added) == len(new_functions) else 0.5
            diff = self._generate_diff(agent_code, enhanced_code)
            changes = self._extract_changes(agent_code, enhanced_code)

            self.add_reasoning_step("reflect",
                f"Enhanced: +{len(added)} functions, syntax={'OK' if syntax_ok else 'ERROR'}, conf={confidence:.2f}")

            return {
                "success": syntax_ok and len(added) > 0,
                "enhanced_code": enhanced_code,
                "diff": diff,
                "added_functions": added,
                "changes": changes,
                "confidence": confidence,
            }

        except Exception as e:
            self.add_reasoning_step("reflect", f"Enhancement failed: {e}")
            return {
                "success": False,
                "enhanced_code": agent_code,
                "diff": "",
                "added_functions": [],
                "changes": [],
                "confidence": 0,
                "error": str(e),
            }

    def _extract_existing_functions(self, code: str) -> List[str]:
        """Extract method names (async + sync) from agent code using AST."""
        try:
            tree = ast.parse(code)
            funcs = []
            for node in ast.walk(tree):
                if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) and node.name.startswith("_"):
                    funcs.append(node.name)
            return funcs if funcs else re.findall(r'(?:async )?def (_\w+)\(', code)
        except SyntaxError:
            return re.findall(r'(?:async )?def (_\w+)\(', code)

    def _extract_function_code(self, code: str, func_name: str) -> Optional[str]:
        """Extract full source code of a specific function using AST line numbers."""
        try:
            tree = ast.parse(code)
            lines = code.split("\n")
            for node in ast.walk(tree):
                if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) and node.name == func_name:
                    start = node.lineno - 1  # 0-indexed
                    end = node.end_lineno if hasattr(node, 'end_lineno') and node.end_lineno else start + 1
                    return "\n".join(lines[start:end])
            return None
        except SyntaxError:
            return None

    def _extract_function_signatures(self, code: str) -> List[str]:
        """Extract function signatures for diagnosis prompt (lightweight)."""
        try:
            tree = ast.parse(code)
            sigs = []
            for node in ast.walk(tree):
                if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) and node.name.startswith("_"):
                    args = [a.arg for a in node.args.args]
                    prefix = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
                    sigs.append(f"{prefix} {node.name}({', '.join(args)})")
            return sigs
        except SyntaxError:
            return re.findall(r'(?:async )?def (_\w+\([^)]*\))', code)

    async def _merge_functions(self, llm, existing_code: str, new_functions: Dict[str, str], request: str) -> Optional[str]:
        """Merge new functions into existing agent code using LLM."""
        # Build the new functions block
        funcs_block = "\n\n".join(new_functions.values())

        prompt = f"""Merge these NEW functions into the existing Python agent code.

EXISTING CODE:
```python
{existing_code}
```

NEW FUNCTIONS TO ADD:
```python
{funcs_block}
```

Enhancement request: {request}

Rules:
- KEEP ALL existing code intact — do not remove or modify existing functions
- ADD the new functions as class methods (indent with 4 spaces)
- Place new functions BEFORE _process_core_logic or process() method
- Update _process_core_logic to call the new functions where appropriate
- Return the COMPLETE merged file

Return ONLY the merged code in a ```python block."""

        try:
            response = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=6000, temperature=0.1), timeout=30)
            if not response:
                return None

            code = response.strip()
            if '```python' in code:
                code = code.split('```python')[1].split('```')[0].strip()
            elif '```' in code:
                code = code.split('```')[1].split('```')[0].strip()

            return code if code else None
        except Exception:
            return None
