"""
WorkflowDebateAgent — 5 strategy agents debate the optimal workflow pattern.

Each agent advocates for its pattern and scores its suitability.
The orchestrator runs a debate: each agent proposes → all agents vote → consensus.

Agents:
- SequentialAgent: step-by-step execution
- ParallelAgent: concurrent independent steps
- PipelineAgent: data-flow chain (output → input)
- ConditionalAgent: branching based on conditions
- LoopAgent: iterative refinement until convergence
"""

import asyncio
from typing import Dict, Any, List
from loguru import logger

from core.agentic.base import ForgeAgent


class WorkflowStrategyProposer(ForgeAgent):
    """Base for workflow pattern proposers."""

    def __init__(self, name: str, pattern: str, description: str):
        super().__init__(name, description, role="workflow_debate")
        self.pattern = pattern

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        functions = context.get("functions", [])
        deps = context.get("dependencies", {})
        complexity = context.get("complexity", "L1")
        num_funcs = len(functions)

        score = self._score(functions, deps, complexity, num_funcs)
        rationale = self._rationale(functions, deps, complexity, num_funcs)

        self.add_reasoning_step("think", f"Pattern={self.pattern}, score={score:.2f}: {rationale[:80]}", score)
        return {
            "pattern": self.pattern,
            "score": score,
            "rationale": rationale,
            "agent": self.config.name,
        }

    def _score(self, functions, deps, complexity, n) -> float:
        raise NotImplementedError

    def _rationale(self, functions, deps, complexity, n) -> str:
        raise NotImplementedError


class SequentialProposer(WorkflowStrategyProposer):
    def __init__(self):
        super().__init__("SequentialAdvocate", "sequential", "Advocates for sequential step-by-step execution")

    def _score(self, functions, deps, complexity, n):
        score = 0.5
        # Sequential is safe default for any number of functions
        if n <= 3:
            score += 0.2  # Simple tasks → sequential is fine
        # If all functions have dependencies → sequential is natural
        dep_count = sum(len(d) for d in deps.values())
        if dep_count > 0:
            score += 0.15
        if complexity == "L1":
            score += 0.1
        return min(1.0, score)

    def _rationale(self, functions, deps, complexity, n):
        return f"Sequential: predictable, safe for {n} functions. Dependencies: {sum(len(d) for d in deps.values())}. Best for simple flows."


class ParallelProposer(WorkflowStrategyProposer):
    def __init__(self):
        super().__init__("ParallelAdvocate", "parallel", "Advocates for parallel concurrent execution")

    def _score(self, functions, deps, complexity, n):
        score = 0.3
        if n <= 1:
            return 0.1  # Can't parallelize 1 function
        # Count independent functions (no deps on each other)
        independent = 0
        for f in functions:
            if not deps.get(f, []):
                independent += 1
        if independent >= 2:
            score += 0.3
        if independent >= n * 0.7:
            score += 0.2  # Most functions are independent
        if complexity == "L3":
            score += 0.1  # Complex tasks benefit from parallelism
        return min(1.0, score)

    def _rationale(self, functions, deps, complexity, n):
        independent = sum(1 for f in functions if not deps.get(f, []))
        return f"Parallel: {independent}/{n} functions are independent. Faster execution via asyncio.gather()."


class PipelineProposer(WorkflowStrategyProposer):
    def __init__(self):
        super().__init__("PipelineAdvocate", "pipeline", "Advocates for data-flow pipeline pattern")

    def _score(self, functions, deps, complexity, n):
        score = 0.4
        if n <= 1:
            return 0.2
        # Pipeline works when each step feeds into the next
        chain_deps = 0
        for i, f in enumerate(functions[1:], 1):
            if functions[i-1] in deps.get(f, []):
                chain_deps += 1
        chain_ratio = chain_deps / max(1, n - 1)
        score += chain_ratio * 0.4
        if complexity in ("L2", "L3"):
            score += 0.1
        return min(1.0, score)

    def _rationale(self, functions, deps, complexity, n):
        return f"Pipeline: data flows step-by-step. Clean data threading. Good for {n}-step transformations."


class ConditionalProposer(WorkflowStrategyProposer):
    def __init__(self):
        super().__init__("ConditionalAdvocate", "conditional", "Advocates for conditional branching")

    def _score(self, functions, deps, complexity, n):
        score = 0.2
        # Conditional is useful when functions have different paths
        if n >= 3:
            score += 0.15
        if complexity == "L3":
            score += 0.15
        # Check if function names suggest conditions
        condition_words = ["check", "validate", "verify", "filter", "approve", "deny", "assess"]
        cond_funcs = sum(1 for f in functions if any(w in f.lower() for w in condition_words))
        if cond_funcs > 0:
            score += 0.3
        return min(1.0, score)

    def _rationale(self, functions, deps, complexity, n):
        return f"Conditional: branching based on intermediate results. Adaptive behavior for {n} functions."


class LoopProposer(WorkflowStrategyProposer):
    def __init__(self):
        super().__init__("LoopAdvocate", "loop", "Advocates for iterative refinement pattern")

    def _score(self, functions, deps, complexity, n):
        score = 0.15
        # Loop is useful for optimization/refinement tasks
        loop_words = ["optimize", "refine", "improve", "converge", "iterate", "train"]
        loop_funcs = sum(1 for f in functions if any(w in f.lower() for w in loop_words))
        if loop_funcs > 0:
            score += 0.4
        if complexity == "L3":
            score += 0.1
        return min(1.0, score)

    def _rationale(self, functions, deps, complexity, n):
        return f"Loop: iterative refinement until convergence. Best for optimization across {n} functions."


class WorkflowDebateAgent(ForgeAgent):
    """Orchestrates 5 workflow proposers in a debate.

    Usage:
        agent = WorkflowDebateAgent()
        result = await agent.debate(functions, dependencies, complexity)
        # result: {pattern, rationale, votes, confidence}
    """

    def __init__(self):
        super().__init__("WorkflowDebateOrchestrator", "5-agent debate for workflow pattern", role="orchestrator")
        self.proposers = [
            SequentialProposer(),
            ParallelProposer(),
            PipelineProposer(),
            ConditionalProposer(),
            LoopProposer(),
        ]

    async def debate(
        self,
        functions: List[str],
        dependencies: Dict[str, List[str]] = None,
        complexity: str = "L1",
    ) -> Dict[str, Any]:
        """Run debate and return winning pattern."""
        response = await self.process(
            f"Debate workflow for {len(functions)} functions",
            {"functions": functions, "dependencies": dependencies or {}, "complexity": complexity}
        )
        return response.content

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        functions = context.get("functions", [])
        deps = context.get("dependencies", {})
        complexity = context.get("complexity", "L1")

        self.add_reasoning_step("think", f"Starting debate for {len(functions)} functions, complexity={complexity}")

        # Phase 1: All proposers score in parallel
        tasks = [p.process(query, context) for p in self.proposers]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        proposals = []
        for r in results:
            if not isinstance(r, Exception):
                proposals.append(r.content)

        if not proposals:
            self.add_reasoning_step("reflect", "All proposers failed, defaulting to sequential")
            return {"pattern": "sequential", "rationale": "Default", "votes": {}, "confidence": 0.5}

        # Phase 2: Rank by score
        proposals.sort(key=lambda x: -x.get("score", 0))

        # Phase 3: Voting — each proposer "votes" by its score being above threshold
        votes = {}
        for p in proposals:
            votes[p["pattern"]] = p["score"]

        winner = proposals[0]
        runner_up = proposals[1] if len(proposals) > 1 else None

        # Confidence = margin between winner and runner-up
        margin = (winner["score"] - (runner_up["score"] if runner_up else 0))
        confidence = min(0.99, winner["score"] * 0.7 + margin * 0.3)

        runner_up_info = f"{runner_up['pattern']} ({runner_up['score']:.2f})" if runner_up else "none"
        self.add_reasoning_step("debate",
            f"Winner: {winner['pattern']} (score={winner['score']:.2f}), runner-up: {runner_up_info}")

        self.add_reasoning_step("reflect",
            f"Consensus: {winner['pattern']} with confidence {confidence:.2f}. "
            f"Rationale: {winner['rationale'][:80]}")

        # Store debate result in memory
        ForgeAgent.remember(
            f"workflow_debate:{','.join(functions[:3])}",
            {"pattern": winner["pattern"], "confidence": confidence},
            {"complexity": complexity, "num_functions": len(functions)}
        )

        return {
            "pattern": winner["pattern"],
            "rationale": winner["rationale"],
            "votes": votes,
            "confidence": confidence,
            "all_proposals": [{"pattern": p["pattern"], "score": p["score"], "rationale": p["rationale"]} for p in proposals],
        }
