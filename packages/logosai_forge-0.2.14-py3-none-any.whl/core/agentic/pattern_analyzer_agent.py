"""
PatternAnalyzerAgent — Analyzes accumulated failures to extract recurring patterns.

When 5+ similar failures accumulate for an agent, this agent:
1. Clusters failures by error signature
2. Extracts common patterns via LLM
3. Generates remediation hints for CodeImproverAgent
4. Triggers auto-fix with pattern context
"""

import json
from collections import Counter
from typing import Dict, Any, List, Optional
from loguru import logger

from core.agentic.base import ForgeAgent


class PatternAnalyzerAgent(ForgeAgent):
    """Analyzes failure patterns and generates remediation strategies."""

    def __init__(self):
        super().__init__(
            name="PatternAnalyzerAgent",
            description="Analyzes accumulated failures to extract recurring patterns",
            role="pattern_analysis",
        )
        self._llm = None

    def _get_llm(self):
        if self._llm is None:
            from core.llm_client import DirectGeminiClient
            self._llm = DirectGeminiClient()
        return self._llm

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Main entry: analyze failures for an agent."""
        failures = context.get("failures", [])
        agent_id = context.get("agent_id", "unknown")
        return await self.analyze(agent_id, failures)

    async def analyze(self, agent_id: str, failures: List[Dict]) -> Dict[str, Any]:
        """Analyze failures and extract patterns.

        Args:
            agent_id: The agent whose failures to analyze
            failures: List of failure dicts from FailureCollectorAgent

        Returns:
            {
                "patterns": [{pattern_id, type, frequency, confidence, description, remediation}],
                "auto_improvable": int,
                "needs_approval": int,
                "test_cases": [{input, expected}],  # Failures converted to test cases
            }
        """
        if not failures:
            return {"patterns": [], "auto_improvable": 0, "needs_approval": 0, "test_cases": []}

        self.add_reasoning_step("observe", f"Analyzing {len(failures)} failures for {agent_id}")

        # Step 1: Cluster by error signature
        clusters = self._cluster_failures(failures)
        self.add_reasoning_step("think", f"Found {len(clusters)} failure clusters")

        # Step 2: Extract patterns per cluster
        patterns = []
        for cluster_key, cluster_failures in clusters.items():
            pattern = await self._extract_pattern(cluster_key, cluster_failures)
            if pattern:
                patterns.append(pattern)

        # Step 3: Convert failures to test cases
        test_cases = self._failures_to_test_cases(failures)

        # Step 4: Classify improvement potential
        auto_improvable = sum(1 for p in patterns if p["confidence"] >= 0.90)
        needs_approval = sum(1 for p in patterns if 0.50 <= p["confidence"] < 0.90)

        self.add_reasoning_step("act",
            f"Extracted {len(patterns)} patterns: {auto_improvable} auto-improvable, {needs_approval} need approval")

        logger.info(f"[PatternAnalyzer] {agent_id}: {len(patterns)} patterns, "
                    f"{auto_improvable} auto, {needs_approval} approval, {len(test_cases)} test cases")

        return {
            "agent_id": agent_id,
            "patterns": patterns,
            "auto_improvable": auto_improvable,
            "needs_approval": needs_approval,
            "test_cases": test_cases,
            "total_failures_analyzed": len(failures),
        }

    def _cluster_failures(self, failures: List[Dict]) -> Dict[str, List[Dict]]:
        """Cluster failures by error_type + tag combination."""
        clusters: Dict[str, List[Dict]] = {}

        for f in failures:
            error_type = f.get("error_type", "unknown")
            tags = f.get("pattern_tags", [])
            # Create cluster key from type + primary tag
            primary_tag = tags[1] if len(tags) > 1 else "general"
            key = f"{error_type}:{primary_tag}"

            clusters.setdefault(key, []).append(f)

        return clusters

    async def _extract_pattern(self, cluster_key: str, failures: List[Dict]) -> Optional[Dict]:
        """Extract a pattern from a cluster of similar failures."""
        if len(failures) < 2:
            return None

        error_type, tag = cluster_key.split(":", 1) if ":" in cluster_key else (cluster_key, "general")

        # Collect error messages for analysis
        messages = [f.get("error_message", "")[:200] for f in failures[:10]]
        sample_input = None
        sample_expected = None
        for f in failures:
            if f.get("test_input"):
                sample_input = f["test_input"]
                sample_expected = f.get("expected_output")
                break

        # Try LLM analysis for richer patterns
        description = ""
        remediation = ""
        confidence = min(0.5 + len(failures) * 0.05, 0.95)  # Base confidence from frequency

        try:
            llm = self._get_llm()
            prompt = f"""Analyze these {len(failures)} similar failures and identify the common pattern.

Error type: {error_type}
Tag: {tag}
Sample error messages:
{chr(10).join(f'- {m}' for m in messages[:5])}

{f'Sample input: {json.dumps(sample_input)}' if sample_input else ''}
{f'Expected output: {json.dumps(sample_expected)}' if sample_expected else ''}

Respond in exactly 2 lines:
Line 1: Pattern description (what goes wrong)
Line 2: Remediation hint (how to fix it)"""

            response = await llm.generate(prompt)
            lines = response.strip().split("\n")
            if len(lines) >= 2:
                description = lines[0].strip()
                remediation = lines[1].strip()
                confidence = min(confidence + 0.1, 0.95)
        except Exception as e:
            logger.debug(f"[PatternAnalyzer] LLM analysis skipped: {e}")
            description = f"Recurring {error_type} with {tag} pattern ({len(failures)} occurrences)"
            remediation = f"Review {tag} logic in affected functions"

        return {
            "pattern_id": f"P_{error_type}_{tag}_{len(failures)}",
            "type": error_type,
            "tag": tag,
            "frequency": len(failures),
            "confidence": confidence,
            "description": description,
            "remediation": remediation,
            "sample_messages": messages[:3],
            "affected_failures": [f.get("failure_id") for f in failures[:10]],
        }

    def _failures_to_test_cases(self, failures: List[Dict]) -> List[Dict]:
        """Convert accumulated failures into test cases for validation."""
        test_cases = []
        seen = set()

        for f in failures:
            test_input = f.get("test_input")
            expected = f.get("expected_output")
            if test_input and expected:
                key = json.dumps(test_input, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    test_cases.append({
                        "input": test_input,
                        "expected": expected,
                    })

        return test_cases
