"""
ForgeV6System — Full Agentic AI Pipeline for Agent Generation.

"Agents Building Agents" — every stage is an agent.
No V5 dependency. Self-contained pipeline.

Pipeline:
1. QueryAnalyzerAgent     → query analysis (3 sub-agents debate)
2. FunctionDecomposerAgent → function decomposition (Chain-of-Thought)
3. StrategyAgent           → generation strategy (ReAct)
4. CodeGeneratorAgent      → function code generation (slice/LLM)
5. WorkflowDebateAgent     → workflow pattern (5 proposers debate)
6. CodeAssemblerAgent      → final agent assembly
7. ErrorHealerAgent        → error diagnosis & healing (3 experts)
"""

import ast
import time
import re
from typing import Dict, Any, Optional
from dataclasses import dataclass
from loguru import logger

from core.agentic.base import ForgeAgent
from core.agentic.query_analyzer_agent import QueryAnalyzerAgent
from core.agentic.function_decomposer_agent import FunctionDecomposerAgent
from core.agentic.strategy_agent import StrategyAgent
from core.agentic.code_generator_agent import CodeGeneratorAgent
from core.agentic.workflow_debate_agent import WorkflowDebateAgent
from core.agentic.code_assembler_agent import CodeAssemblerAgent
from core.agentic.error_healer_agent import ErrorHealerAgent
from core.agentic.test_validator_agent import TestValidatorAgent


@dataclass
class ForgeV6Result:
    """Result from V6 agentic pipeline."""
    success: bool
    agent_code: str = ""
    metadata: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class ForgeV6System:
    """Full agentic pipeline — 7 agents, no V5 dependency.

    Usage:
        system = ForgeV6System()
        result = await system.create_agent(query, test_cases=[...])
    """

    def __init__(self):
        self.query_agent = QueryAnalyzerAgent()
        self.decomposer_agent = FunctionDecomposerAgent()
        self.strategy_agent = StrategyAgent()
        self.generator_agent = CodeGeneratorAgent()
        self.workflow_agent = WorkflowDebateAgent()
        self.assembler_agent = CodeAssemblerAgent()
        self.healer_agent = ErrorHealerAgent()
        self.validator_agent = TestValidatorAgent()

        # Lazy-loaded (only when improve_agent() is called)
        self._improver_agent = None

        # Load pipeline config (YAML, overridable)
        try:
            from config import get_config
            self._config = get_config()
        except Exception:
            self._config = {}
        self._max_retries = self._config.get("pipeline", {}).get("max_retries", 2)

        # Self-Evolution integration (Paper2)
        self.evolution = None
        try:
            from core.self_evolution.config import EvolutionConfig
            from core.self_evolution.orchestrator import EvolutionOrchestrator
            config = EvolutionConfig.from_env()
            if config.enabled:
                self.evolution = EvolutionOrchestrator(config)
                logger.info("ForgeV6System: Self-Evolution system enabled")
        except Exception as e:
            logger.debug(f"ForgeV6System: Self-Evolution not available: {e}")

        logger.info(f"ForgeV6System initialized — 8 agentic agents ready (evolution={'ON' if self.evolution else 'OFF'})")

    async def improve_agent(self, agent_code: str, failure_log: Dict[str, Any], dry_run: bool = False) -> ForgeV6Result:
        """Improve existing agent code based on failure feedback."""
        if self._improver_agent is None:
            from core.agentic.code_improver_agent import CodeImproverAgent
            self._improver_agent = CodeImproverAgent()

        result = await self._improver_agent.improve(agent_code, failure_log, dry_run=dry_run)

        return ForgeV6Result(
            success=result.get("success", False),
            agent_code=result.get("improved_code", agent_code),
            metadata={
                "improvement": {
                    "success": result.get("success"),
                    "confidence": result.get("confidence", 0),
                    "attempts": result.get("attempts", 0),
                    "changes": result.get("changes", []),
                    "diff": result.get("diff", ""),
                    "scope": result.get("scope", ""),
                    "functions_changed": result.get("functions_changed", []),
                    "functions_preserved": result.get("functions_preserved", []),
                    "dry_run": result.get("dry_run", False),
                    "diagnosis": result.get("diagnosis", ""),
                    "estimated_confidence": result.get("estimated_confidence"),
                    "quality_metrics": result.get("quality_metrics"),
                }
            },
        )

    async def enhance_agent(self, agent_code: str, enhancement_request: str,
                            test_cases: list = None) -> ForgeV6Result:
        """Enhance existing agent code by adding missing logic/functions."""
        if self._improver_agent is None:
            from core.agentic.code_improver_agent import CodeImproverAgent
            self._improver_agent = CodeImproverAgent()

        result = await self._improver_agent.enhance(agent_code, enhancement_request, test_cases)

        return ForgeV6Result(
            success=result.get("success", False),
            agent_code=result.get("enhanced_code", agent_code),
            metadata={
                "enhancement": {
                    "success": result.get("success"),
                    "confidence": result.get("confidence", 0),
                    "added_functions": result.get("added_functions", []),
                    "changes": result.get("changes", []),
                    "diff": result.get("diff", ""),
                }
            },
        )

    async def create_agent(
        self,
        query: str,
        agent_name: str = None,
        test_cases: list = None,
        business_rules: list = None,
        progress_callback=None,
        checkpoint_callback=None,
    ) -> ForgeV6Result:
        """Create agent through full agentic pipeline.

        Args:
            progress_callback: async fn(stage, progress, detail) — real-time stage updates
            checkpoint_callback: async fn(stage, question, data, options) — mid-pipeline confirmation
        """
        start = time.time()
        ForgeAgent.clear_traces()

        metadata = {"version": "v6-agentic", "query": query[:200]}

        async def _progress(stage, progress, detail=None):
            if progress_callback:
                try:
                    await progress_callback(stage, progress, detail)
                except Exception:
                    pass

        async def _checkpoint(stage, question, data=None, options=None):
            if checkpoint_callback:
                try:
                    return await checkpoint_callback(stage, question, data or {}, options or ["confirm"])
                except Exception:
                    pass
            return {"action": "confirm"}

        try:
            # ── Stage 1: Query Analysis (Debate) ──
            logger.info("[V6] Stage 1: Multi-agent query analysis")
            await _progress("query_analysis", 10, "Analyzing query...")
            analysis = await self.query_agent.analyze(query)
            domain = analysis.get("domain", "general")
            level = analysis.get("level", "L1")
            capabilities = analysis.get("capabilities", [])
            await _progress("query_analysis", 15, {"domain": domain, "level": level, "capabilities": capabilities})

            # Checkpoint: low confidence analysis
            if analysis.get("confidence", 1) < 0.6:
                resp = await _checkpoint("query_analysis",
                    f"Low confidence ({analysis.get('confidence', 0):.2f}). domain={domain}, level={level}. Proceed?",
                    analysis, ["confirm", "modify"])
                if resp.get("action") == "modify":
                    domain = resp.get("domain", domain)
                    level = resp.get("level", level)
            logger.info(f"[V6] → domain={domain}, level={level}, caps={capabilities[:3]}")

            metadata["analysis"] = {
                "domain": domain, "level": level,
                "capabilities": capabilities,
                "confidence": analysis.get("confidence", 0),
            }

            # ── Stage 2: Function Decomposition (Chain-of-Thought) ──
            logger.info("[V6] Stage 2: Function decomposition")
            await _progress("function_decomposition", 20, "Decomposing into functions...")
            specs = await self.decomposer_agent.decompose(
                query=query,
                domain=domain,
                complexity=level,
                business_rules=business_rules[0] if business_rules else None,
                test_cases=test_cases,
            )
            logger.info(f"[V6] → {len(specs)} functions: {[s['name'] for s in specs]}")

            metadata["decomposition"] = {
                "functions": [s["name"] for s in specs],
                "count": len(specs),
            }

            # ── Stage 3: Strategy Selection (ReAct) ──
            logger.info("[V6] Stage 3: Strategy selection")
            await _progress("strategy_selection", 30, "Selecting generation strategy...")
            func_name = specs[0]["name"] if specs else "_process"
            try:
                strategy_result = await self.strategy_agent.select_strategy(
                    spec_name=func_name,
                    spec_description=query[:200],
                    spec_category=capabilities[0] if capabilities else "custom",
                    domain=domain,
                    has_test_cases=bool(test_cases),
                    complexity=level,
                )
                strategy_result = dict(strategy_result) if strategy_result else {}
                strategy = strategy_result.get("strategy", "llm")
            except Exception as e:
                logger.warning(f"[V6] Strategy selection failed: {e}, using default llm")
                strategy_result = {"strategy": "llm", "confidence": 0.5, "reasoning": "fallback"}
                strategy = "llm"
            logger.info(f"[V6] → strategy={strategy} (conf={strategy_result.get('confidence', 0.5):.2f})")

            metadata["strategy"] = {
                "selected": strategy,
                "confidence": strategy_result.get('confidence', 0.5),
                "reasoning": strategy_result.get("reasoning", ""),
            }

            # ── Stage 4: Code Generation ──
            logger.info(f"[V6] Stage 4: Generating {len(specs)} functions")
            await _progress("code_generation", 45, {"functions_to_generate": len(specs), "strategy": strategy})
            functions = await self.generator_agent.generate_functions(
                specs=specs,
                strategy=strategy,
                domain=domain,
                test_cases=test_cases,
            )
            logger.info(f"[V6] → {len(functions)} functions generated")

            metadata["generation"] = {
                "functions_requested": len(specs),
                "functions_generated": len(functions),
                "function_names": list(functions.keys()),
            }

            # ── Stage 5: Workflow Debate ──
            workflow_pattern = "sequential"
            workflow_votes = {}
            if len(functions) >= 2:
                logger.info(f"[V6] Stage 5: Workflow debate for {len(functions)} functions")
                func_names = list(functions.keys())
                func_deps = {s["name"]: s.get("dependencies", []) for s in specs}
                wf_result = await self.workflow_agent.debate(func_names, func_deps, level)
                workflow_pattern = wf_result["pattern"]
                workflow_votes = wf_result.get("votes", {})
                logger.info(f"[V6] → workflow={workflow_pattern} (conf={wf_result['confidence']:.2f})")
            else:
                logger.info("[V6] Stage 5: Single function, skipping debate")

            metadata["workflow"] = {
                "pattern": workflow_pattern,
                "votes": workflow_votes,
            }

            # ── Stage 6: Code Assembly ──
            logger.info("[V6] Stage 6: Assembling agent code")
            await _progress("code_assembly", 65, {"functions": len(functions), "pattern": workflow_pattern})
            if not agent_name:
                agent_name = self._derive_agent_name(query)

            code = await self.assembler_agent.assemble(
                agent_name=agent_name,
                description=query[:200],
                functions=functions,
                workflow_pattern=workflow_pattern,
                function_specs=specs,
            )
            logger.info(f"[V6] → {len(code.split(chr(10)))} lines assembled")

            # ── Stage 6.5: Domain Expert Review ──
            domain_review_result = None
            try:
                from config import get_value
                dr_enabled = get_value("domain_review", "enabled", True)
                dr_threshold = get_value("domain_review", "confidence_threshold", 0.7)
            except Exception:
                dr_enabled = True
                dr_threshold = 0.7

            if dr_enabled and domain:
                logger.info(f"[V6] Stage 6.5: Domain expert review (domain={domain})")
                await _progress("domain_review", 70, {"domain": domain})
                try:
                    from core.agentic.dynamic_agent_factory import DynamicAgentFactory
                    factory = DynamicAgentFactory.get_instance()
                    expert = factory.create_expert(domain, query[:200])
                    domain_review_result = await expert._execute(code, {
                        "stage": "post_assembly",
                        "functions": list(functions.keys()),
                        "agent_name": agent_name,
                    })
                    dr_conf = domain_review_result.get("confidence", 1.0)
                    dr_review = domain_review_result.get("review", "")
                    logger.info(f"[V6] → Domain review: conf={dr_conf:.2f}, review={dr_review[:80]}")

                    metadata["domain_review"] = {
                        "domain": domain,
                        "confidence": dr_conf,
                        "review": dr_review[:300],
                    }

                    # Low confidence → inject expert feedback into specs for potential retry
                    if dr_conf < dr_threshold and dr_review:
                        logger.info(f"[V6] → Domain confidence {dr_conf:.2f} < {dr_threshold} — feedback stored for retry")
                        metadata["domain_review"]["action"] = "feedback_injected"
                        for spec in specs:
                            spec["domain_feedback"] = dr_review[:200]
                except Exception as e:
                    logger.debug(f"[V6] Domain review skipped: {e}")

            # ── Stage 7: Error Healing (if needed) ──
            try:
                ast.parse(code)
                logger.info("[V6] Stage 7: Syntax OK, no healing needed")
            except SyntaxError as e:
                logger.info(f"[V6] Stage 7: Healing syntax error: {e}")
                heal_result = await self.healer_agent.heal(code, str(e), query)
                if heal_result.get("healed"):
                    code = heal_result["code"]
                    logger.info(f"[V6] → Healed by {heal_result['expert']}")
                    metadata["healing"] = {
                        "applied": True,
                        "expert": heal_result["expert"],
                        "fixes": heal_result["fixes"],
                    }

            # ── Stage 8: Validation + Adaptive Retry (C1) ──
            validation_passed = False
            max_retries = self._max_retries
            RETRY_STRATEGIES = [
                {"name": "feedback", "temperature": 0.4},
                {"name": "change_strategy", "temperature": 0.5},
                {"name": "simplify", "temperature": 0.7},
            ]

            if test_cases:
                for attempt in range(max_retries + 1):
                    await _progress("validation", 80 + attempt * 5,
                                    {"attempt": attempt + 1, "max": max_retries + 1})
                    logger.info(f"[V6] Stage 8: Validation (attempt {attempt + 1}/{max_retries + 1})")
                    val_result = await self.validator_agent.validate(code, test_cases, query)

                    if val_result.get("passed"):
                        validation_passed = True
                        logger.info(f"[V6] → Validation PASSED ({val_result['tests_passed']}/{val_result['tests_total']})")
                        break
                    else:
                        feedback = val_result.get("feedback", "")
                        logger.info(f"[V6] → Validation FAILED: {feedback[:80]}")

                        if attempt < max_retries and feedback:
                            # Adaptive retry: different strategy each attempt (C1)
                            retry_cfg = RETRY_STRATEGIES[attempt] if attempt < len(RETRY_STRATEGIES) else RETRY_STRATEGIES[-1]
                            retry_strategy = strategy
                            retry_temp = retry_cfg.get("temperature", 0.2)

                            if retry_cfg["name"] == "change_strategy":
                                retry_strategy = "slice" if strategy == "llm" else "llm"
                            elif retry_cfg["name"] == "simplify" and len(specs) > 1:
                                specs = specs[:1]  # Simplify to single function

                            # Combine validation feedback + domain expert feedback
                            combined_feedback = f"ATTEMPT {attempt+1} FAILED. Feedback: {feedback[:200]}"
                            for spec in specs:
                                domain_fb = spec.pop("domain_feedback", "")
                                if domain_fb:
                                    combined_feedback += f"\nDomain expert ({domain}): {domain_fb[:150]}"
                                spec["business_rules"] = (spec.get("business_rules", "") +
                                    f"\n\n{combined_feedback}")

                            logger.info(f"[V6] → Adaptive retry: {retry_cfg['name']}, temp={retry_temp}, strategy={retry_strategy}")
                            await _progress("retry", 85 + attempt * 3,
                                            {"strategy": retry_cfg["name"], "temperature": retry_temp})

                            functions = await self.generator_agent.generate_functions(
                                specs=specs, strategy=retry_strategy, domain=domain,
                                test_cases=test_cases)

                            code = await self.assembler_agent.assemble(
                                agent_name=agent_name,
                                description=query[:200],
                                functions=functions,
                                workflow_pattern=workflow_pattern,
                                function_specs=specs,
                            )

                            try:
                                ast.parse(code)
                            except SyntaxError as e:
                                heal_r = await self.healer_agent.heal(code, str(e), query)
                                if heal_r.get("healed"):
                                    code = heal_r["code"]

                metadata["validation"] = {
                    "passed": validation_passed,
                    "tests_passed": val_result.get("tests_passed", 0),
                    "tests_total": val_result.get("tests_total", 0),
                    "attempts": attempt + 1,
                    "feedback": val_result.get("feedback", "")[:200] if not validation_passed else "",
                }
            else:
                logger.info("[V6] Stage 8: No test cases, skipping validation")

            # Record function composition for learning (A4)
            try:
                from core.function_composition import FunctionCompositionTracker
                comp_tracker = FunctionCompositionTracker.get_instance()
                func_names_used = list(functions.keys()) if functions else []
                if func_names_used:
                    comp_tracker.record_composition(
                        agent_id=agent_name,
                        functions_used=func_names_used,
                        success=validation_passed if test_cases else True,
                    )
            except Exception:
                pass

            # ── Stage 9: Self-Evolution (quality eval + library admission) ──
            if self.evolution:
                try:
                    logger.info("[V6] Stage 9: Self-Evolution post-generation")
                    evo_result = await self.evolution.post_generation(
                        code=code, query=query, metadata=metadata,
                    )
                    # Apply healed code if evolution healing improved it
                    if evo_result.healed_code:
                        code = evo_result.healed_code
                        logger.info("[V6] → Evolution healing applied")

                    metadata["evolution"] = {
                        "evaluation": {
                            "overall": getattr(evo_result.evaluation, "overall", None),
                            "functional": getattr(evo_result.evaluation, "functional", None),
                            "code_quality": getattr(evo_result.evaluation, "code_quality", None),
                        } if evo_result.evaluation else None,
                        "healing": {
                            "success": getattr(evo_result.healing, "success", False),
                            "stage_used": getattr(evo_result.healing, "stage_used", None),
                        } if evo_result.healing else None,
                        "admission": {
                            "decision": getattr(evo_result.admission, "decision", None),
                            "message": getattr(evo_result.admission, "message", None),
                        } if evo_result.admission else None,
                    }
                    logger.info(f"[V6] → Evolution: eval={getattr(evo_result.evaluation, 'overall', 'N/A')}, "
                                f"admission={getattr(evo_result.admission, 'decision', 'N/A')}")
                except Exception as e:
                    logger.warning(f"[V6] Self-Evolution post-generation failed (non-fatal): {e}")
                    metadata["evolution"] = {"error": str(e)}

            # ── Stage 10: Auto Function Registration (Self-Growing Library) ──
            try:
                from core.function_extractor import FunctionRegistrar
                auto_reg = FunctionRegistrar()
                reg_results = auto_reg.auto_register_from_agent(code)
                auto_registered = [r for r in reg_results if r.get("action") == "registered"]
                if auto_registered:
                    logger.info(f"[V6] Auto-registered {len(auto_registered)} functions to library")
                    metadata["auto_registered_functions"] = [r["function"] for r in auto_registered]
            except Exception as e:
                logger.debug(f"[V6] Auto-registration skipped: {e}")

            # ── Finalize ──
            elapsed = time.time() - start
            traces = ForgeAgent.get_traces()

            metadata["reasoning"] = {
                "traces": len(traces),
                "steps": sum(len(t.get("reasoning_steps", [])) for t in traces),
                "time_ms": elapsed * 1000,
            }

            # Enhanced metadata for ACP auto-registration + routing
            func_count = len(specs) if specs else 0
            metadata["sample_queries"] = self._generate_sample_queries(query, capabilities)
            metadata["estimated_latency"] = "fast" if level == "L1" else ("medium" if level == "L2" else "slow")
            metadata["quality_score"] = metadata.get("evolution", {}).get("evaluation", {}).get("overall") or (
                0.9 if metadata.get("validation", {}).get("passed") else 0.7
            )
            metadata["agent_name"] = agent_name
            metadata["function_count"] = func_count

            # Verify final syntax
            try:
                ast.parse(code)
                success = True
            except SyntaxError as e:
                success = False
                metadata["final_error"] = str(e)

            logger.info(f"[V6] Done: {'SUCCESS' if success else 'FAILED'} ({elapsed:.1f}s, {len(code.split(chr(10)))} lines)")

            return ForgeV6Result(
                success=success,
                agent_code=code,
                metadata=metadata,
            )

        except Exception as e:
            logger.error(f"[V6] Pipeline error: {e}")
            return ForgeV6Result(
                success=False,
                error=str(e),
                metadata=metadata,
            )

    def _generate_sample_queries(self, query: str, capabilities: list) -> list:
        """Generate sample queries for ACP TaskClassifier routing."""
        samples = [query[:100]]
        # Generate variations from capabilities
        for cap in capabilities[:3]:
            cap_str = str(cap).replace("_", " ")
            samples.append(f"{cap_str} 해줘")
        # Short form
        words = query.split()[:4]
        if len(words) >= 2:
            samples.append(" ".join(words))
        return list(dict.fromkeys(samples))[:5]  # Deduplicate, max 5

    def _derive_agent_name(self, query: str) -> str:
        """Derive agent name from query."""
        q = query.lower()
        match = re.search(r'(?:calculate|compute|evaluate|analyze|predict|process|generate|create|build)\w*\s+([\w\s]{3,30}?)(?:\s+based|\s+from|\s+with|,|\.|$)', q)
        if match:
            raw = match.group(1).strip()
            return re.sub(r'\s+', '_', raw).title().replace('_', '') + "Agent"
        words = [w.capitalize() for w in q.split()[:4] if len(w) > 2]
        return "".join(words[:3]) + "Agent" if words else "GeneratedAgent"
