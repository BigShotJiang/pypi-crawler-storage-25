"""
CodeGeneratorAgent — Generates Python function code for each FunctionSpec.

Takes decomposed function specs + strategy decision → produces actual code.
Uses slice library and LLM internally with agentic reasoning:
- Observe: Check slice library, review strategy, recall past generations
- Think: Determine best approach for this specific function
- Act: Generate code (slice reuse or LLM)
- Reflect: Validate syntax, store outcome for learning
"""

import asyncio
import ast
import json
import re
from typing import Dict, Any, List, Optional
from loguru import logger

from core.agentic.base import ForgeAgent

try:
    from core.direct_gemini_client import DirectGeminiClient
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False


class CodeGeneratorAgent(ForgeAgent):
    """Generates function code for each FunctionSpec using slice/LLM."""

    def __init__(self):
        super().__init__("CodeGenerator", "Generates Python function code", role="generation")
        self._llm = None
        self._slice_library = None
        self._filled_loaded = False

    def _get_llm(self):
        if self._llm is None and LLM_AVAILABLE:
            self._llm = DirectGeminiClient(model_name="gemini-2.5-flash-lite")
        return self._llm

    def _ensure_slices(self):
        if self._slice_library is not None:
            return
        try:
            from core.slice_library.library import SliceLibrary
            from core.slice_library.core_slices import create_core_slices
            from core.slice_library.common_slices import create_common_slices
            from core.slice_library.domain_slices import create_all_domain_slices

            self._slice_library = SliceLibrary()
            self._slice_library.register_many(create_core_slices())
            self._slice_library.register_many(create_common_slices())
            self._slice_library.register_many(create_all_domain_slices())

            # Load filled slices
            if not self._filled_loaded:
                import json
                from pathlib import Path
                fp = Path(__file__).parent.parent / "business_logic_v2" / "slice_library" / "filled_slices.json"
                if fp.exists():
                    with open(fp) as f:
                        for entry in json.load(f).get("slices", []):
                            name = entry.get("name", "")
                            code = entry.get("code_template", "")
                            if name in self._slice_library._slices and code:
                                self._slice_library._slices[name].code_template = code
                self._filled_loaded = True
        except Exception as e:
            logger.warning(f"Slice library unavailable: {e}")

    async def generate_functions(
        self,
        specs: List[Dict[str, Any]],
        strategy: str = "llm",
        domain: str = "general",
        test_cases: Optional[List[Dict]] = None,
    ) -> Dict[str, str]:
        """Generate code for multiple function specs.

        Args:
            specs: List of {name, description, inputs, outputs, business_rules, dependencies}
            strategy: "slice" | "llm" from StrategyAgent
            domain: domain from QueryAnalyzerAgent
            test_cases: Optional test cases for validation context

        Returns:
            Dict[function_name, function_code]
        """
        response = await self.process(
            f"Generate {len(specs)} functions",
            {"specs": specs, "strategy": strategy, "domain": domain, "test_cases": test_cases}
        )
        return response.content.get("functions", {})

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        specs = context.get("specs", [])
        strategy = context.get("strategy", "llm")
        domain = context.get("domain", "general")
        test_cases = context.get("test_cases") or []

        # Inject test_cases into first spec's business_rules (so LLM sees expected outputs)
        if test_cases and specs:
            tc_lines = []
            for tc in test_cases[:3]:
                tc_lines.append(f"  Input: {json.dumps(tc.get('input', {}))[:150]} → Expected: {tc.get('expected', '')}")
            tc_text = "\n".join(tc_lines)
            specs[0]["business_rules"] = (specs[0].get("business_rules", "") +
                f"\n\nYour function MUST produce these results:\n{tc_text}")

        self.add_reasoning_step("observe", f"Generating {len(specs)} functions, strategy={strategy}, domain={domain}")

        self._ensure_slices()
        llm = self._get_llm()
        functions = {}

        for i, spec in enumerate(specs):
            name = spec.get("name", f"_func_{i}")
            desc = spec.get("description", "")
            inputs = spec.get("inputs", {})
            outputs = spec.get("outputs", [])
            rules = spec.get("business_rules", "")

            self.add_reasoning_step("think", f"[{i+1}/{len(specs)}] {name}: {desc[:50]}")

            code = None

            # Try slice first if strategy says so
            if strategy == "slice" and self._slice_library:
                code = self._try_slice(name, desc, domain)

            # Try pattern-based generation (A5: learn from similar successful functions)
            if not code and strategy != "slice":
                try:
                    from core.function_composition import PatternBasedGenerator
                    from core.function_telemetry import FunctionTelemetry
                    tel = FunctionTelemetry.get_instance()
                    top_funcs = tel.get_top_reused(limit=20)
                    # Enrich with code from registry
                    from core.function_registry import FunctionRegistry
                    reg = FunctionRegistry.get_instance()
                    known = []
                    for tf in top_funcs:
                        latest = reg.get_latest(tf["func_name"])
                        if latest:
                            known.append({"name": tf["func_name"], "code": latest["code"],
                                          "success_rate": tf["success_rate"], "call_count": tf["call_count"]})
                    if known:
                        pg = PatternBasedGenerator()
                        similar = pg.find_similar_function(name, desc, known)
                        if similar and llm:
                            prompt = pg.generate_prompt_with_example(
                                {"name": name, "description": desc}, similar)
                            example_code = await self._generate_with_llm_prompt(llm, prompt, name)
                            if example_code:
                                code = example_code
                                self.add_reasoning_step("act", f"Generated {name} by example from {similar['name']}")
                except Exception:
                    pass

            # LLM generation (fallback)
            if not code and llm:
                code = await self._generate_with_llm(llm, name, desc, inputs, outputs, rules)

            if code:
                # Force-rename function to match spec name
                code = self._force_rename(code, name)

                # Syntax validate
                if self._validate_syntax(code, name):
                    functions[name] = code
                    self.add_reasoning_step("act", f"✅ {name}: {len(code.split(chr(10)))} lines")
                else:
                    # Retry once
                    code2 = await self._generate_with_llm(llm, name, desc, inputs, outputs, rules)
                    if code2:
                        code2 = self._force_rename(code2, name)
                    if code2 and self._validate_syntax(code2, name):
                        functions[name] = code2
                        self.add_reasoning_step("act", f"✅ {name}: {len(code2.split(chr(10)))} lines (retry)")
                    else:
                        functions[name] = self._generate_stub(name, desc, inputs, outputs)
                        self.add_reasoning_step("reflect", f"⚠️ {name}: using stub (generation failed)")
            else:
                functions[name] = self._generate_stub(name, desc, inputs, outputs)
                self.add_reasoning_step("reflect", f"⚠️ {name}: using stub (no LLM)")

        self.add_reasoning_step("reflect", f"Generated {len(functions)} functions, {sum(1 for c in functions.values() if 'pass' not in c[:50])} with real logic")

        return {"functions": functions, "count": len(functions)}

    def _try_slice(self, name: str, desc: str, domain: str) -> Optional[str]:
        """Try to find matching slice code."""
        keywords = name.lstrip("_").split("_") + desc.lower().split()[:5]
        keywords = [k for k in keywords if len(k) > 2]

        results = self._slice_library.search_by_keywords(keywords, language="auto", threshold=0.4)
        for candidate, score in results[:3]:
            if candidate.code_template and "async def" in candidate.code_template:
                # Rename function
                code = re.sub(r'async def \w+\(', f'async def {name}(', candidate.code_template, count=1)
                return code
        return None

    async def _generate_with_llm_prompt(self, llm, prompt: str, name: str) -> Optional[str]:
        """Generate function from a custom prompt (used by pattern-based generation)."""
        try:
            response = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=2000, temperature=0.2), timeout=20)
            if not response:
                return None
            code = response.strip()
            if '```python' in code:
                code = code.split('```python')[1].split('```')[0].strip()
            elif '```' in code:
                code = code.split('```')[1].split('```')[0].strip()
            return code if code and 'def ' in code else None
        except Exception:
            return None

    async def _generate_with_llm(self, llm, name, desc, inputs, outputs, rules) -> Optional[str]:
        """Generate function code with LLM."""
        input_params = ", ".join(f"{k}: {v}" for k, v in inputs.items()) if isinstance(inputs, dict) else "data: Dict[str, Any]"
        output_keys = ", ".join(f'"{o}"' for o in outputs) if isinstance(outputs, list) else '"result"'

        prompt = f"""Write ONLY a Python async function. Start with "async def" on the first line.

async def {name}(self, data: Dict[str, Any]) -> Dict[str, Any]:
    \"\"\"
    {desc}
    \"\"\"

Input keys from data: {input_params}
Expected output keys: {output_keys}
Business rules: {rules or desc}

Rules:
- Use data.get('key', default) for inputs
- Return dict with output keys
- Real calculations, not placeholders
- 15-50 lines
- Handle edge cases

ACP Agent Convention (MUST follow):
- If creating files (PPT/Excel/Word/PDF): use tempfile.gettempdir() for output, return {{"file_path": path, "file_name": name, "answer": "Created: " + path}}
- If searching files: return {{"files": ["/absolute/path/..."], "answer": "Found N files"}}
- Always include "answer" key as a string in returned dict

Available Python libraries (already installed — use via inline import):
- python-pptx (PowerPoint), openpyxl (Excel), python-docx (Word), PyPDF2 (PDF)
- aiohttp (async HTTP), subprocess (system tools)

Available system tools (macOS, via subprocess.run):
- mdfind: Spotlight search (fastest file search)
- pdfgrep: PDF content search
- textutil: DOCX/RTF to text conversion
- grep -ril: text file content search"""

        try:
            response = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=2000, temperature=0.2),
                timeout=20
            )
            if not response:
                return None

            code = response.strip()
            if '```python' in code:
                code = code.split('```python')[1].split('```')[0].strip()
            elif '```' in code:
                code = code.split('```')[1].split('```')[0].strip()

            # Ensure starts with async def
            if not code.startswith('async def'):
                import textwrap
                body = textwrap.dedent(code)
                code = f"async def {name}(self, data: Dict[str, Any]) -> Dict[str, Any]:\n" + \
                       "\n".join(f"    {line}" if line.strip() else "" for line in body.split("\n"))

            return code
        except Exception as e:
            logger.warning(f"LLM generation failed for {name}: {e}")
            return None

    def _validate_syntax(self, code: str, func_name: str) -> bool:
        """Check if function code has valid syntax."""
        test = f"from typing import Dict, Any, List, Optional\nimport math\nclass _T:\n"
        indented = "\n".join(f"    {line}" if line.strip() else "" for line in code.split("\n"))
        try:
            ast.parse(test + indented)
            return True
        except SyntaxError:
            return False

    def _force_rename(self, code: str, target_name: str) -> str:
        """Force-rename the first function def in code to target_name."""
        # Try async def first, then plain def
        if re.search(r'async def \w+\(', code):
            return re.sub(r'async def \w+\(', f'async def {target_name}(', code, count=1)
        if re.search(r'def \w+\(', code):
            return re.sub(r'def \w+\(', f'async def {target_name}(', code, count=1)
        return code

    def _generate_stub(self, name, desc, inputs, outputs) -> str:
        """Generate a minimal stub function."""
        output_dict = ", ".join(f'"{o}": None' for o in (outputs if isinstance(outputs, list) else ["result"]))
        return f"""async def {name}(self, data: Dict[str, Any]) -> Dict[str, Any]:
    \"\"\"{desc[:100]}\"\"\"
    return {{{output_dict}, "status": "stub"}}"""
