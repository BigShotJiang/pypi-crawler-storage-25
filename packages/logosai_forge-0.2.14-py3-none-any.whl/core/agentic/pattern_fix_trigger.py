"""
PatternFixTrigger — Orchestrates pattern-based auto-improvement.

Flow:
1. FailureCollector detects 5+ similar failures
2. PatternAnalyzer extracts patterns + remediation hints
3. This trigger: CodeImproverAgent.improve(pattern_hints) + TestValidator(failures→tests)
4. Confidence gate: ≥0.95 auto-deploy, <0.95 approval queue
"""

from typing import Dict, Any, List, Optional
from loguru import logger

from core.agentic.failure_collector_agent import FailureCollectorAgent
from core.agentic.pattern_analyzer_agent import PatternAnalyzerAgent


class PatternFixTrigger:
    """Orchestrates the pattern → improve → validate → deploy cycle."""

    CONFIDENCE_AUTO_DEPLOY = 0.95
    CONFIDENCE_MIN_ATTEMPT = 0.50

    def __init__(self, failure_collector: FailureCollectorAgent = None):
        self.collector = failure_collector or FailureCollectorAgent()
        self.analyzer = PatternAnalyzerAgent()
        self._improver = None
        self._validator = None

    def _get_improver(self):
        if self._improver is None:
            from core.agentic.code_improver_agent import CodeImproverAgent
            self._improver = CodeImproverAgent()
        return self._improver

    def _get_validator(self):
        if self._validator is None:
            from core.agentic.test_validator_agent import TestValidatorAgent
            self._validator = TestValidatorAgent()
        return self._validator

    async def check_and_fix(
        self,
        agent_id: str,
        agent_code: str,
        min_failures: int = 5,
    ) -> Dict[str, Any]:
        """Check if agent has enough failures to trigger pattern-based fix.

        Args:
            agent_id: Agent to check
            agent_code: Current agent code
            min_failures: Minimum failures before triggering (default 5)

        Returns:
            {
                "triggered": bool,
                "patterns_found": int,
                "fix_attempted": bool,
                "fix_success": bool,
                "confidence": float,
                "improved_code": str,
                "action": "auto_deploy" | "needs_approval" | "no_action" | "insufficient_data",
                "test_results": dict,
            }
        """
        # Step 1: Get unresolved failures
        failures = self.collector.get_unresolved(agent_id)

        if len(failures) < min_failures:
            return {
                "triggered": False,
                "action": "insufficient_data",
                "failures_count": len(failures),
                "min_required": min_failures,
            }

        logger.info(f"[PatternFix] {agent_id}: {len(failures)} unresolved failures, analyzing...")

        # Step 2: Analyze patterns
        analysis = await self.analyzer.analyze(agent_id, failures)
        patterns = analysis.get("patterns", [])

        if not patterns:
            return {
                "triggered": True,
                "patterns_found": 0,
                "fix_attempted": False,
                "action": "no_action",
            }

        # Step 3: Build pattern hints for CodeImproverAgent
        pattern_hints = self._build_pattern_hints(patterns)

        # Step 4: Pick representative failure for improve()
        representative = self._pick_representative_failure(failures)

        # Step 5: Build test cases from all failures
        test_cases = analysis.get("test_cases", [])

        # Step 6: Attempt fix with pattern hints
        logger.info(f"[PatternFix] Attempting fix with {len(patterns)} patterns, {len(test_cases)} test cases")
        improver = self._get_improver()

        # Enrich failure_log with pattern hints
        failure_log = {
            "error_type": representative.get("error_type", "logic_error"),
            "error_message": representative.get("error_message", ""),
            "test_input": representative.get("test_input"),
            "expected_output": representative.get("expected_output"),
            "actual_output": representative.get("actual_output"),
            "pattern_hints": pattern_hints,
        }

        fix_result = await improver.improve(agent_code, failure_log)

        if not fix_result.get("success"):
            logger.info(f"[PatternFix] Fix attempt failed for {agent_id}")
            return {
                "triggered": True,
                "patterns_found": len(patterns),
                "fix_attempted": True,
                "fix_success": False,
                "action": "no_action",
                "patterns": patterns,
            }

        improved_code = fix_result.get("improved_code", "")
        confidence = fix_result.get("confidence", 0)

        # Step 7: Validate against ALL accumulated failure test cases
        validation = None
        if test_cases:
            validator = self._get_validator()
            validation = await validator.validate(improved_code, test_cases, "")
            # Adjust confidence based on validation
            if validation.get("passed"):
                tests_ratio = validation.get("tests_passed", 0) / max(validation.get("tests_total", 1), 1)
                confidence = max(confidence, tests_ratio)
            else:
                confidence *= 0.5  # Halve confidence if validation fails

        # Step 8: Determine action
        if confidence >= self.CONFIDENCE_AUTO_DEPLOY:
            action = "auto_deploy"
        elif confidence >= self.CONFIDENCE_MIN_ATTEMPT:
            action = "needs_approval"
        else:
            action = "no_action"

        logger.info(f"[PatternFix] {agent_id}: fix_success=True, conf={confidence:.2f}, action={action}")

        return {
            "triggered": True,
            "patterns_found": len(patterns),
            "patterns": patterns,
            "fix_attempted": True,
            "fix_success": True,
            "confidence": confidence,
            "improved_code": improved_code,
            "diff": fix_result.get("diff", ""),
            "changes": fix_result.get("changes", []),
            "action": action,
            "test_results": {
                "passed": validation.get("passed") if validation else None,
                "tests_passed": validation.get("tests_passed", 0) if validation else 0,
                "tests_total": validation.get("tests_total", 0) if validation else 0,
            },
            "test_cases_used": len(test_cases),
        }

    def _build_pattern_hints(self, patterns: List[Dict]) -> str:
        """Build a concise pattern hint string for LLM."""
        hints = []
        for p in patterns[:5]:  # Max 5 patterns
            hints.append(
                f"- Pattern: {p.get('description', p.get('type', 'unknown'))} "
                f"(frequency: {p.get('frequency', 0)}, "
                f"remediation: {p.get('remediation', 'N/A')})"
            )
        return "\n".join(hints)

    def _pick_representative_failure(self, failures: List[Dict]) -> Dict:
        """Pick the most informative failure as representative."""
        # Prefer failures with test_input and expected_output
        for f in failures:
            if f.get("test_input") and f.get("expected_output"):
                return f
        # Fallback to most recent
        return failures[0] if failures else {}
