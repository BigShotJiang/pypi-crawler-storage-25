"""
QueryAnalyzerAgent — Multi-agent debate for query analysis.

3 sub-agents analyze the query from different perspectives,
then debate and vote to produce a unified QueryAnalysis.

Sub-agents:
- IntentAnalyzerAgent: What does the user want? (intent, action verbs)
- CapabilityMatcherAgent: What capabilities are needed? (domain, functions)
- ComplexityEstimatorAgent: How complex is this? (L1/L2/L3, function count)
"""

import asyncio
import json
import re
from typing import Dict, Any, List, Optional
from loguru import logger

from core.agentic.base import ForgeAgent

# Use the existing LLM client for reasoning
try:
    from core.direct_gemini_client import DirectGeminiClient
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False


class IntentAnalyzerAgent(ForgeAgent):
    """Analyzes user intent: what action is requested?"""

    def __init__(self):
        super().__init__("IntentAnalyzer", "Analyzes user query intent", role="query_analysis")

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        self.add_reasoning_step("think", f"Analyzing intent of: {query[:80]}")

        llm = context.get("llm")
        if llm:
            prompt = f"""Analyze this query's intent. Return JSON only:
{{
  "primary_intent": "create_agent|modify_code|analyze_data|calculate|integrate_api|process_workflow",
  "action_verbs": ["calculate", "generate", ...],
  "target_objects": ["BMI", "discount", ...],
  "is_multi_step": true/false,
  "confidence": 0.0-1.0
}}

Query: {query}"""
            try:
                response = await asyncio.wait_for(llm.generate(prompt, max_tokens=500, temperature=0.1), timeout=10)
                result = self._parse_json(response)
                if result:
                    self.add_reasoning_step("act", f"Intent: {result.get('primary_intent')}", result.get("confidence", 0.8))
                    return result
            except Exception as e:
                self.add_reasoning_step("reflect", f"LLM failed: {e}, using heuristic")

        # Heuristic fallback
        return self._heuristic_intent(query)

    def _heuristic_intent(self, query: str) -> Dict[str, Any]:
        q = query.lower()
        verbs = []
        for v in ["calculate", "compute", "generate", "create", "analyze", "predict", "evaluate", "process", "build", "design"]:
            if v in q:
                verbs.append(v)

        intent = "create_agent"
        if any(v in q for v in ["calculate", "compute"]):
            intent = "calculate"
        elif any(v in q for v in ["analyze", "evaluate"]):
            intent = "analyze_data"
        elif "api" in q or "integrate" in q:
            intent = "integrate_api"
        elif any(v in q for v in ["workflow", "pipeline", "step"]):
            intent = "process_workflow"

        multi = bool(re.search(r'\d+[\s-]?step|and\s+\w+\s+and|including|pipeline', q))

        return {
            "primary_intent": intent,
            "action_verbs": verbs or ["process"],
            "target_objects": re.findall(r'\b[A-Z][a-z]+(?:\s+[a-z]+){0,2}', query)[:5],
            "is_multi_step": multi,
            "confidence": 0.7,
        }

    def _parse_json(self, text: str) -> Optional[Dict]:
        try:
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0]
            elif "```" in text:
                text = text.split("```")[1].split("```")[0]
            # Fix common JSON issues
            text = text.strip()
            text = re.sub(r'//.*$', '', text, flags=re.MULTILINE)  # Remove comments
            text = text.replace("True", "true").replace("False", "false").replace("None", "null")
            return json.loads(text)
        except Exception:
            return None


class CapabilityMatcherAgent(ForgeAgent):
    """Matches query to required capabilities and domain."""

    def __init__(self):
        super().__init__("CapabilityMatcher", "Matches capabilities and domain", role="query_analysis")

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        self.add_reasoning_step("think", f"Matching capabilities for: {query[:80]}")

        llm = context.get("llm")
        if llm:
            prompt = f"""What capabilities and domain does this query need? Return JSON only:
{{
  "domain": "finance|customer|ecommerce|hr|healthcare|manufacturing|energy|logistics|education|legal|insurance|marketing|operations|sales|ml_ai|general",
  "capabilities": ["churn_prediction", "scoring_model", ...],
  "required_functions": ["_calculate_X", "_validate_Y", ...],
  "input_types": ["float", "dict", "list", ...],
  "output_types": ["dict", "float", ...],
  "confidence": 0.0-1.0
}}

Query: {query}"""
            try:
                response = await asyncio.wait_for(llm.generate(prompt, max_tokens=500, temperature=0.1), timeout=10)
                result = self._parse_json(response)
                if result:
                    self.add_reasoning_step("act", f"Domain: {result.get('domain')}, caps: {result.get('capabilities', [])[:3]}", result.get("confidence", 0.8))
                    return result
            except Exception as e:
                self.add_reasoning_step("reflect", f"LLM failed: {e}, using heuristic")

        return self._heuristic_capabilities(query)

    def _heuristic_capabilities(self, query: str) -> Dict[str, Any]:
        q = query.lower()
        domain = "general"
        caps = []

        domain_map = {
            "finance": ["credit", "loan", "interest", "payment", "invoice", "tax", "revenue", "profit"],
            "customer": ["churn", "retention", "lifetime", "ltv", "segment", "loyalty"],
            "ecommerce": ["order", "cart", "discount", "inventory", "shipping", "product"],
            "hr": ["salary", "employee", "payroll", "performance", "attendance", "leave"],
            "healthcare": ["patient", "bmi", "dosage", "diagnosis", "medical"],
            "manufacturing": ["oee", "defect", "quality", "production", "assembly"],
            "energy": ["carbon", "electricity", "kwh", "solar", "consumption"],
            "marketing": ["campaign", "roi", "conversion", "acquisition", "lead"],
        }

        for d, keywords in domain_map.items():
            if any(k in q for k in keywords):
                domain = d
                break

        if "calculate" in q or "compute" in q:
            caps.append("scoring_model")
        if "predict" in q:
            caps.append("churn_prediction")
        if "analyze" in q:
            caps.append("factor_analysis")

        return {
            "domain": domain,
            "capabilities": caps or ["data_aggregation"],
            "required_functions": [],
            "input_types": ["dict"],
            "output_types": ["dict"],
            "confidence": 0.6,
        }

    def _parse_json(self, text: str) -> Optional[Dict]:
        try:
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0]
            elif "```" in text:
                text = text.split("```")[1].split("```")[0]
            text = text.strip()
            text = re.sub(r'//.*$', '', text, flags=re.MULTILINE)
            text = text.replace("True", "true").replace("False", "false").replace("None", "null")
            return json.loads(text)
        except Exception:
            return None


class ComplexityEstimatorAgent(ForgeAgent):
    """Estimates query complexity (L1/L2/L3)."""

    def __init__(self):
        super().__init__("ComplexityEstimator", "Estimates task complexity", role="query_analysis")

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        self.add_reasoning_step("think", f"Estimating complexity: {query[:80]}")

        llm = context.get("llm")
        if llm:
            prompt = f"""Estimate the complexity of implementing this query. Return JSON only:
{{
  "level": "L1|L2|L3",
  "functions_needed": 1-10,
  "complexity_score": 0.0-1.0,
  "reasoning": "brief explanation",
  "has_workflow": true/false,
  "confidence": 0.0-1.0
}}

L1 = single function (1-2 functions), L2 = multi-step (2-4 functions), L3 = complex pipeline (5+ functions)

Query: {query}"""
            try:
                response = await asyncio.wait_for(llm.generate(prompt, max_tokens=500, temperature=0.1), timeout=10)
                result = self._parse_json(response)
                if result:
                    self.add_reasoning_step("act", f"Level: {result.get('level')}, funcs: {result.get('functions_needed')}", result.get("confidence", 0.8))
                    return result
            except Exception as e:
                self.add_reasoning_step("reflect", f"LLM failed: {e}, using heuristic")

        return self._heuristic_complexity(query)

    def _heuristic_complexity(self, query: str) -> Dict[str, Any]:
        q = query.lower()
        step_match = re.findall(r'(\d+)[\s-]?step|stage|phase', q)
        steps = int(step_match[0]) if step_match else 0
        and_count = q.count(" and ")
        has_workflow = bool(re.search(r'workflow|pipeline|step|stage|then|after', q))

        if steps >= 5 or and_count >= 3:
            level, funcs, score = "L3", max(5, steps), 0.85
        elif steps >= 2 or and_count >= 1 or has_workflow:
            level, funcs, score = "L2", max(2, steps or 3), 0.55
        else:
            level, funcs, score = "L1", 1, 0.25

        return {
            "level": level,
            "functions_needed": funcs,
            "complexity_score": score,
            "reasoning": f"Steps: {steps}, conjunctions: {and_count}, workflow: {has_workflow}",
            "has_workflow": has_workflow,
            "confidence": 0.65,
        }

    def _parse_json(self, text: str) -> Optional[Dict]:
        try:
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0]
            elif "```" in text:
                text = text.split("```")[1].split("```")[0]
            text = text.strip()
            text = re.sub(r'//.*$', '', text, flags=re.MULTILINE)
            text = text.replace("True", "true").replace("False", "false").replace("None", "null")
            return json.loads(text)
        except Exception:
            return None


class QueryAnalyzerAgent(ForgeAgent):
    """Orchestrates 3 sub-agents via debate to produce unified QueryAnalysis.

    Usage:
        agent = QueryAnalyzerAgent()
        result = await agent.analyze(query)
        # result has: intent, domain, capabilities, complexity, confidence
    """

    def __init__(self):
        super().__init__("QueryAnalyzerOrchestrator", "Multi-agent query analysis via debate", role="orchestrator")
        self.intent_agent = IntentAnalyzerAgent()
        self.capability_agent = CapabilityMatcherAgent()
        self.complexity_agent = ComplexityEstimatorAgent()
        self._llm = None

    def _get_llm(self):
        if self._llm is None and LLM_AVAILABLE:
            self._llm = DirectGeminiClient(model_name="gemini-2.5-flash-lite")
        return self._llm

    async def analyze(self, query: str) -> Dict[str, Any]:
        """Public API — compatible with existing QueryAnalysis structure."""
        response = await self.process(query)
        return response.content

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        self.add_reasoning_step("think", "Starting multi-agent query analysis")

        llm = self._get_llm()
        agent_context = {"llm": llm}

        # Run all 3 sub-agents in parallel
        self.add_reasoning_step("act", "Dispatching to 3 analysis agents in parallel")
        intent_task = self.intent_agent.process(query, agent_context)
        capability_task = self.capability_agent.process(query, agent_context)
        complexity_task = self.complexity_agent.process(query, agent_context)

        results = await asyncio.gather(intent_task, capability_task, complexity_task, return_exceptions=True)

        intent_result = results[0].content if not isinstance(results[0], Exception) else {}
        capability_result = results[1].content if not isinstance(results[1], Exception) else {}
        complexity_result = results[2].content if not isinstance(results[2], Exception) else {}

        # Debate: synthesize results (weighted by confidence)
        self.add_reasoning_step("debate", "Synthesizing sub-agent results")

        # Calculate weighted consensus
        confidences = [
            intent_result.get("confidence", 0.5),
            capability_result.get("confidence", 0.5),
            complexity_result.get("confidence", 0.5),
        ]
        avg_confidence = sum(confidences) / len(confidences)

        # Build unified analysis (backward-compatible with V5 QueryAnalysis)
        unified = {
            "intent": intent_result.get("primary_intent", "create_agent"),
            "action_verbs": intent_result.get("action_verbs", []),
            "target_objects": intent_result.get("target_objects", []),
            "is_multi_step": intent_result.get("is_multi_step", False),

            "domain": capability_result.get("domain", "general"),
            "capabilities": capability_result.get("capabilities", []),
            "required_functions": capability_result.get("required_functions", []),

            "level": complexity_result.get("level", "L1"),
            "functions_needed": complexity_result.get("functions_needed", 1),
            "complexity_score": complexity_result.get("complexity_score", 0.5),
            "has_workflow": complexity_result.get("has_workflow", False),

            # Meta
            "confidence": avg_confidence,
            "analysis_method": "multi_agent_debate",
            "agent_results": {
                "intent": intent_result,
                "capability": capability_result,
                "complexity": complexity_result,
            },

            # V5 compatibility fields
            "original_query": query,
            "keywords": intent_result.get("action_verbs", []) + intent_result.get("target_objects", []),
            "required_capabilities": capability_result.get("capabilities", []),
        }

        self.add_reasoning_step("reflect",
            f"Consensus: intent={unified['intent']}, domain={unified['domain']}, "
            f"level={unified['level']}, confidence={avg_confidence:.2f}")

        # Store in shared memory for downstream agents
        ForgeAgent.remember(f"query_analysis:{query[:50]}", unified)

        return unified
