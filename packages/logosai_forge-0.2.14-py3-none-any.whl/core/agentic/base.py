"""
ForgeAgent — Base class for all FORGE V6 pipeline agents.

Extends LogosAIAgent with FORGE-specific capabilities:
- Persistent shared memory (SQLite + in-memory cache)
- Reasoning trace capture for paper experiments
- Cross-agent learning via universal pattern storage
"""

import json
import sqlite3
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
from loguru import logger

from logosai.agent import LogosAIAgent
from logosai.config import AgentConfig
from logosai.agent_types import AgentType, AgentResponse, AgentResponseType


class _PersistentMemory:
    """SQLite-backed shared memory with in-memory cache."""

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            db_path = str(Path(__file__).parent.parent.parent / "prototype" / "backend" / "forge_evolution.db")
            cls._instance = cls(db_path)
        return cls._instance

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._cache: Dict[str, Dict] = {}
        self._init_db()
        self._load_cache()

    def _init_db(self):
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_memory (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    metadata TEXT DEFAULT '{}',
                    stored_at TEXT NOT NULL
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[Memory] DB init: {e}")

    def _load_cache(self):
        try:
            conn = sqlite3.connect(self._db_path)
            rows = conn.execute("SELECT key, value, metadata, stored_at FROM agent_memory").fetchall()
            conn.close()
            for key, value, metadata, stored_at in rows:
                self._cache[key] = {
                    "value": json.loads(value),
                    "metadata": json.loads(metadata) if metadata else {},
                    "stored_at": stored_at,
                }
            if self._cache:
                logger.info(f"[Memory] Loaded {len(self._cache)} entries from SQLite")
        except Exception as e:
            logger.debug(f"[Memory] Cache load: {e}")

    def remember(self, key: str, value: Any, metadata: Dict = None):
        entry = {
            "value": value,
            "metadata": metadata or {},
            "stored_at": datetime.now().isoformat(),
        }
        self._cache[key] = entry
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute(
                "INSERT OR REPLACE INTO agent_memory (key, value, metadata, stored_at) VALUES (?,?,?,?)",
                (key, json.dumps(value, ensure_ascii=False, default=str),
                 json.dumps(metadata or {}, ensure_ascii=False, default=str), entry["stored_at"])
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[Memory] Write failed: {e}")

    def recall(self, key: str) -> Optional[Any]:
        entry = self._cache.get(key)
        return entry["value"] if entry else None

    def recall_similar(self, keywords: List[str], top_k: int = 5) -> List[Dict]:
        results = []
        for key, entry in self._cache.items():
            score = sum(1 for kw in keywords if kw.lower() in key.lower())
            if score > 0:
                results.append({"key": key, "score": score, **entry})
        return sorted(results, key=lambda x: -x["score"])[:top_k]


class ToolSchema:
    """Tool call schema — defines input types, output type, timeout, fallback."""
    def __init__(self, input_params: dict = None, output_type: str = "Any",
                 timeout: int = 30, fallback: str = None):
        self.input_params = input_params or {}
        self.output_type = output_type
        self.timeout = timeout
        self.fallback = fallback

    def validate(self, **params) -> list:
        """Validate parameters against schema. Returns error list (empty = OK)."""
        errors = []
        type_map = {"str": str, "int": int, "float": (int, float), "dict": dict, "list": list, "bool": bool}
        for name, expected_type in self.input_params.items():
            if name not in params:
                if not expected_type.startswith("Optional"):
                    errors.append(f"Missing required parameter: {name}")
            else:
                py_type = type_map.get(expected_type.replace("Optional[", "").rstrip("]"))
                if py_type and not isinstance(params[name], py_type):
                    errors.append(f"{name}: expected {expected_type}, got {type(params[name]).__name__}")
        return errors


class ToolRegistry:
    """Central registry for tools with schema validation and dependency injection."""
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
            cls._instance._register_defaults()
        return cls._instance

    def __init__(self):
        self._tools = {}
        self._factories = {}
        self._schemas = {}

    def _register_defaults(self):
        """Register default tools from config."""
        try:
            from config import get_value
            model = get_value("llm", "model", "gemini-2.5-flash-lite")
        except Exception:
            model = "gemini-2.5-flash-lite"

        self.register_tool("llm", lambda: self._create_llm(model),
            ToolSchema({"prompt": "str", "max_tokens": "Optional[int]", "temperature": "Optional[float]"}, "str", timeout=20))
        self.register_tool("slice_library", lambda: self._create_slice_library(),
            ToolSchema({"keywords": "list"}, "list", timeout=5))

    def _create_llm(self, model: str):
        try:
            from core.direct_gemini_client import DirectGeminiClient
            return DirectGeminiClient(model_name=model)
        except Exception:
            return None

    def _create_slice_library(self):
        try:
            from core.slice_library.library import SliceLibrary
            return SliceLibrary()
        except Exception:
            return None

    def register_tool(self, name: str, factory, schema: 'ToolSchema' = None):
        """Register tool with optional schema."""
        self._factories[name] = factory
        if schema:
            self._schemas[name] = schema

    def register_factory(self, name: str, factory):
        """Legacy: register without schema."""
        self._factories[name] = factory

    def get(self, name: str):
        if name not in self._tools:
            factory = self._factories.get(name)
            if factory:
                self._tools[name] = factory()
        return self._tools.get(name)

    def call(self, name: str, **params):
        """Schema-validated tool call: validate → execute → return."""
        schema = self._schemas.get(name)
        if schema:
            errors = schema.validate(**params)
            if errors:
                return {"success": False, "errors": errors}

        tool = self.get(name)
        if tool is None:
            return {"success": False, "errors": [f"Tool '{name}' not found"]}

        if callable(tool):
            result = tool(**params)
        elif hasattr(tool, "execute"):
            result = tool.execute(**params)
        else:
            return {"success": False, "errors": ["Tool is not callable"]}

        return {"success": True, "result": result}

    def get_schema(self, name: str):
        """Get schema definition for a tool."""
        schema = self._schemas.get(name)
        if not schema:
            return None
        return {"input": schema.input_params, "output": schema.output_type,
                "timeout": schema.timeout, "fallback": schema.fallback}

    def list_tools(self):
        return list(set(list(self._tools.keys()) + list(self._factories.keys())))


class TaskTracker:
    """Track sub-task progress within pipeline stages."""
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._tasks = {}
        self._counter = 0

    def create_task(self, name: str, total_steps: int) -> str:
        self._counter += 1
        task_id = f"task_{self._counter}"
        self._tasks[task_id] = {
            "name": name, "total_steps": total_steps, "current_step": 0,
            "detail": "", "started_at": datetime.now().isoformat(), "status": "in_progress",
        }
        return task_id

    def update_task(self, task_id: str, step: int, detail: str = ""):
        if task_id in self._tasks:
            self._tasks[task_id]["current_step"] = step
            self._tasks[task_id]["detail"] = detail
            if step >= self._tasks[task_id]["total_steps"]:
                self._tasks[task_id]["status"] = "completed"

    def get_progress(self, task_id: str) -> Optional[Dict]:
        t = self._tasks.get(task_id)
        if not t:
            return None
        return {
            "name": t["name"],
            "progress": f"{t['current_step']}/{t['total_steps']}",
            "percent": round(t["current_step"] / max(t["total_steps"], 1) * 100),
            "detail": t["detail"], "status": t["status"],
        }

    def get_active_tasks(self) -> List[Dict]:
        return [{"task_id": k, **self.get_progress(k)}
                for k, v in self._tasks.items() if v["status"] == "in_progress"]


class HookExecutor:
    """Execute YAML-defined stage hooks (before/after)."""
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            try:
                from config import get_config
                hooks = get_config().get("hooks", {})
            except Exception:
                hooks = {}
            cls._instance = cls(hooks)
        return cls._instance

    def __init__(self, hooks_config: Dict = None):
        self._hooks = hooks_config or {}
        self._log: List[Dict] = []

    def run_hooks(self, stage: str, timing: str, context: Dict = None) -> int:
        key = f"{timing}_{stage}"
        hooks = self._hooks.get(key, [])
        ran = 0
        for hook in hooks:
            action = hook.get("action", "")
            condition = hook.get("condition", "")
            if condition:
                try:
                    if not eval(condition, {"context": context or {}}):
                        continue
                except Exception:
                    continue
            self._log.append({"stage": stage, "timing": timing, "action": action})
            ran += 1
        return ran

    def get_log(self) -> List[Dict]:
        return list(self._log)


class ForgeAgent(LogosAIAgent):
    """Base class for FORGE pipeline agents.

    All FORGE agents share:
    - Persistent memory store (SQLite + cache, survives restarts)
    - Reasoning trace capture
    """

    _reasoning_traces: List[Dict[str, Any]] = []

    def __init__(self, name: str, description: str, role: str = "pipeline"):
        config = AgentConfig(
            name=name,
            agent_type=AgentType.CUSTOM,
            description=description,
            config={
                "role": role,
                "forge_version": "v6-agentic",
            }
        )
        super().__init__(config)
        self.role = role
        self._trace_enabled = True

    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Main entry point — subclasses override _execute()."""
        start = datetime.now()
        trace = {
            "agent": self.config.name,
            "role": self.role,
            "input": query[:200],
            "start": start.isoformat(),
            "reasoning_steps": [],
        }
        # Append trace BEFORE _execute so add_reasoning_step() can find it
        if self._trace_enabled:
            ForgeAgent._reasoning_traces.append(trace)

        try:
            result = await self._execute(query, context or {})
            # Ensure plain dict (Cython compatibility)
            if isinstance(result, dict) and type(result) is not dict:
                result = dict(result)
            trace["success"] = True
            trace["output_keys"] = list(result.keys()) if isinstance(result, dict) else str(type(result))
        except Exception as e:
            logger.error(f"[{self.config.name}] Error: {e}")
            trace["success"] = False
            trace["error"] = str(e)
            result = {"error": str(e)}

        trace["duration_ms"] = (datetime.now() - start).total_seconds() * 1000

        # Persist trace to SQLite
        self._persist_trace(trace)

        return AgentResponse(
            type=AgentResponseType.SUCCESS if trace["success"] else AgentResponseType.ERROR,
            content=result,
        )

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Override in subclasses with actual logic."""
        raise NotImplementedError(f"{self.config.name} must implement _execute()")

    def add_reasoning_step(self, step_type: str, content: str, confidence: float = 1.0):
        """Record a reasoning step for trace capture."""
        step = {
            "type": step_type,  # "think", "observe", "act", "reflect", "debate"
            "content": content[:500],
            "confidence": confidence,
            "timestamp": datetime.now().isoformat(),
        }
        if ForgeAgent._reasoning_traces:
            traces = ForgeAgent._reasoning_traces
            if traces[-1].get("agent") == self.config.name:
                traces[-1].setdefault("reasoning_steps", []).append(step)

    # ── Persistent reasoning traces ──

    def _persist_trace(self, trace: Dict):
        """Save reasoning trace to SQLite."""
        try:
            db_path = str(Path(__file__).parent.parent.parent / "prototype" / "backend" / "forge_evolution.db")
            conn = sqlite3.connect(db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS reasoning_traces (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_name TEXT NOT NULL,
                    role TEXT DEFAULT '',
                    input_query TEXT DEFAULT '',
                    success INTEGER DEFAULT 1,
                    duration_ms REAL DEFAULT 0,
                    steps TEXT DEFAULT '[]',
                    output_keys TEXT DEFAULT '',
                    error TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                )
            """)
            conn.execute(
                """INSERT INTO reasoning_traces
                   (agent_name, role, input_query, success, duration_ms, steps, output_keys, error, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (trace.get("agent", ""), trace.get("role", ""),
                 trace.get("input", "")[:500],
                 1 if trace.get("success") else 0,
                 trace.get("duration_ms", 0),
                 json.dumps(trace.get("reasoning_steps", []), ensure_ascii=False, default=str),
                 str(trace.get("output_keys", "")),
                 trace.get("error", ""),
                 trace.get("start", datetime.now().isoformat()))
            )
            conn.commit()
            conn.close()
        except Exception:
            pass  # Non-blocking: trace persistence failure shouldn't break pipeline

    @classmethod
    def query_traces(cls, agent_name: str = None, success_only: bool = None, limit: int = 20) -> List[Dict]:
        """Query persisted reasoning traces from SQLite."""
        try:
            db_path = str(Path(__file__).parent.parent.parent / "prototype" / "backend" / "forge_evolution.db")
            conn = sqlite3.connect(db_path)
            query = "SELECT agent_name, role, input_query, success, duration_ms, steps, error, created_at FROM reasoning_traces"
            params = []
            conditions = []
            if agent_name:
                conditions.append("agent_name = ?")
                params.append(agent_name)
            if success_only is not None:
                conditions.append("success = ?")
                params.append(1 if success_only else 0)
            if conditions:
                query += " WHERE " + " AND ".join(conditions)
            query += " ORDER BY id DESC LIMIT ?"
            params.append(limit)
            rows = conn.execute(query, params).fetchall()
            conn.close()
            return [{"agent": r[0], "role": r[1], "input": r[2], "success": bool(r[3]),
                     "duration_ms": r[4], "steps": json.loads(r[5]) if r[5] else [],
                     "error": r[6], "created_at": r[7]} for r in rows]
        except Exception:
            return []

    # ── Persistent shared memory (SQLite + cache) ──

    @classmethod
    def _get_memory(cls) -> _PersistentMemory:
        return _PersistentMemory.get_instance()

    @classmethod
    def remember(cls, key: str, value: Any, metadata: Optional[Dict] = None):
        """Store in persistent shared memory (survives server restarts)."""
        cls._get_memory().remember(key, value, metadata)

    @classmethod
    def recall(cls, key: str) -> Optional[Any]:
        """Retrieve from shared memory."""
        return cls._get_memory().recall(key)

    @classmethod
    def recall_similar(cls, keywords: List[str], top_k: int = 5) -> List[Dict]:
        """Find memory entries matching keywords."""
        return cls._get_memory().recall_similar(keywords, top_k)

    @classmethod
    def get_traces(cls) -> List[Dict]:
        """Get all reasoning traces (for paper experiments)."""
        return list(cls._reasoning_traces)

    @classmethod
    def clear_traces(cls):
        """Clear traces (call between benchmark runs)."""
        cls._reasoning_traces.clear()
