"""
FailureCollectorAgent — Collects, classifies, and stores runtime failures.

Receives failure reports from ACP when agents fail at runtime.
Stores structured failure logs in SQLite for pattern analysis.
Provides similarity search to find recurring failure patterns.
"""

import json
import sqlite3
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path
from loguru import logger

from core.agentic.base import ForgeAgent


class FailureCollectorAgent(ForgeAgent):
    """Collects and classifies agent runtime failures for pattern learning."""

    # Error type taxonomy
    ERROR_TYPES = {"logic_error", "runtime_error", "syntax_error", "timeout", "type_error", "import_error", "assertion_error"}

    def __init__(self, db_path: str = None):
        super().__init__(
            name="FailureCollectorAgent",
            description="Collects and classifies agent runtime failures",
            role="failure_collection",
        )
        # Default DB path
        if db_path is None:
            db_path = str(Path(__file__).parent.parent.parent / "prototype" / "backend" / "forge_evolution.db")
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Initialize failure_logs table."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS failure_logs (
                    id TEXT PRIMARY KEY,
                    agent_id TEXT NOT NULL,
                    error_type TEXT NOT NULL,
                    error_message TEXT,
                    test_input TEXT,
                    expected_output TEXT,
                    actual_output TEXT,
                    traceback TEXT,
                    pattern_tags TEXT DEFAULT '[]',
                    similarity_cluster INTEGER DEFAULT -1,
                    resolved INTEGER DEFAULT 0,
                    resolution_method TEXT,
                    resolution_details TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_failure_agent_id ON failure_logs(agent_id)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_failure_resolved ON failure_logs(resolved)
            """)
            conn.commit()
        finally:
            conn.close()
        logger.info(f"[FailureCollector] DB initialized: {self.db_path}")

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process a failure collection request."""
        action = context.get("action", "collect")
        if action == "collect":
            return await self.collect(context.get("failure_data", {}))
        elif action == "find_similar":
            return {"similar": self.find_similar(context.get("failure_data", {}), context.get("top_k", 10))}
        elif action == "get_unresolved":
            return {"unresolved": self.get_unresolved(context.get("agent_id", ""))}
        elif action == "get_stats":
            return self.get_stats(context.get("agent_id"))
        return {"error": f"Unknown action: {action}"}

    async def collect(self, failure_data: Dict[str, Any]) -> Dict[str, Any]:
        """Collect and store a failure report.

        Args:
            failure_data: {
                "agent_id": str,
                "error_type": str,
                "error_message": str,
                "test_input": dict (optional),
                "expected_output": dict (optional),
                "actual_output": dict (optional),
                "traceback": str (optional),
            }

        Returns:
            {"failure_id": str, "classified_type": str, "similar_count": int}
        """
        agent_id = failure_data.get("agent_id", "unknown")
        error_type = failure_data.get("error_type", "runtime_error")
        error_message = failure_data.get("error_message", "")

        # Classify error type
        classified_type = self._classify_error(error_type, error_message)

        # Auto-tag patterns
        pattern_tags = self._auto_tag(classified_type, error_message)

        failure_id = f"fail_{uuid.uuid4().hex[:12]}"

        self.add_reasoning_step("observe", f"Failure received: agent={agent_id}, type={classified_type}")

        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                """INSERT INTO failure_logs
                   (id, agent_id, error_type, error_message, test_input, expected_output,
                    actual_output, traceback, pattern_tags, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    failure_id,
                    agent_id,
                    classified_type,
                    error_message[:2000],
                    json.dumps(failure_data.get("test_input"), ensure_ascii=False) if failure_data.get("test_input") else None,
                    json.dumps(failure_data.get("expected_output"), ensure_ascii=False) if failure_data.get("expected_output") else None,
                    json.dumps(failure_data.get("actual_output"), ensure_ascii=False) if failure_data.get("actual_output") else None,
                    failure_data.get("traceback", "")[:5000],
                    json.dumps(pattern_tags),
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()
        finally:
            conn.close()

        # Count similar failures
        similar = self.find_similar(failure_data, top_k=5)
        similar_count = len(similar)

        self.add_reasoning_step("act", f"Stored failure {failure_id}, {similar_count} similar found, tags={pattern_tags}")

        logger.info(f"[FailureCollector] Collected {failure_id} for {agent_id} ({classified_type}), {similar_count} similar")

        return {
            "failure_id": failure_id,
            "agent_id": agent_id,
            "classified_type": classified_type,
            "pattern_tags": pattern_tags,
            "similar_count": similar_count,
            "trigger_analysis": similar_count >= 5,  # Trigger PatternAnalyzer when 5+ similar
        }

    def find_similar(self, failure_data: Dict[str, Any], top_k: int = 10, cross_agent: bool = False) -> List[Dict]:
        """Find similar failures. cross_agent=True searches ALL agents (not just same agent_id)."""
        agent_id = failure_data.get("agent_id", "")
        error_type = failure_data.get("error_type", "")

        conn = sqlite3.connect(self.db_path)
        try:
            if cross_agent:
                cursor = conn.execute(
                    """SELECT id, agent_id, error_type, error_message, pattern_tags, resolved, created_at
                       FROM failure_logs
                       WHERE error_type = ? AND resolved = 0
                       ORDER BY created_at DESC LIMIT ?""",
                    (error_type, top_k),
                )
            else:
                cursor = conn.execute(
                    """SELECT id, agent_id, error_type, error_message, pattern_tags, resolved, created_at
                       FROM failure_logs
                       WHERE agent_id = ? AND error_type = ? AND resolved = 0
                       ORDER BY created_at DESC LIMIT ?""",
                    (agent_id, error_type, top_k),
                )
            rows = cursor.fetchall()
        finally:
            conn.close()

        return [
            {
                "failure_id": r[0],
                "agent_id": r[1],
                "error_type": r[2],
                "error_message": r[3],
                "pattern_tags": json.loads(r[4]) if r[4] else [],
                "resolved": bool(r[5]),
                "created_at": r[6],
            }
            for r in rows
        ]

    def get_unresolved(self, agent_id: str, limit: int = 50) -> List[Dict]:
        """Get unresolved failures for an agent."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                """SELECT id, error_type, error_message, test_input, expected_output,
                          actual_output, pattern_tags, created_at
                   FROM failure_logs
                   WHERE agent_id = ? AND resolved = 0
                   ORDER BY created_at DESC LIMIT ?""",
                (agent_id, limit),
            )
            rows = cursor.fetchall()
        finally:
            conn.close()

        return [
            {
                "failure_id": r[0],
                "error_type": r[1],
                "error_message": r[2],
                "test_input": json.loads(r[3]) if r[3] else None,
                "expected_output": json.loads(r[4]) if r[4] else None,
                "actual_output": json.loads(r[5]) if r[5] else None,
                "pattern_tags": json.loads(r[6]) if r[6] else [],
                "created_at": r[7],
            }
            for r in rows
        ]

    def mark_resolved(self, agent_id: str, method: str, failure_ids: List[str] = None, details: str = ""):
        """Mark failures as resolved."""
        conn = sqlite3.connect(self.db_path)
        try:
            if failure_ids:
                placeholders = ",".join("?" * len(failure_ids))
                conn.execute(
                    f"""UPDATE failure_logs SET resolved = 1, resolution_method = ?, resolution_details = ?
                        WHERE id IN ({placeholders})""",
                    [method, details] + failure_ids,
                )
            else:
                conn.execute(
                    """UPDATE failure_logs SET resolved = 1, resolution_method = ?, resolution_details = ?
                       WHERE agent_id = ? AND resolved = 0""",
                    (method, details, agent_id),
                )
            conn.commit()
            logger.info(f"[FailureCollector] Marked resolved: agent={agent_id}, method={method}")
        finally:
            conn.close()

    def assess_deployment(self, deployment_id: str, agent_id: str) -> Dict[str, Any]:
        """Assess a deployment's impact: SUCCESS / REGRESSION / NEUTRAL.

        Compares failure counts before and after the deployment.
        """
        db_path = str(Path(self.db_path).parent / "forge_evolution.db")
        conn = sqlite3.connect(db_path)
        try:
            dep = conn.execute(
                "SELECT deployed_at FROM deployments WHERE deployment_id=?",
                (deployment_id,)
            ).fetchone()
            if not dep:
                return {"assessment": "unknown", "error": "deployment not found"}

            deployed_at = dep[0]

            # Failures resolved by this deployment (or around deployment time)
            resolved = conn.execute(
                "SELECT COUNT(*) FROM failure_logs WHERE agent_id=? AND resolved=1 AND created_at < ?",
                (agent_id, deployed_at)
            ).fetchone()[0]

            # New failures after deployment
            new_failures = conn.execute(
                "SELECT COUNT(*) FROM failure_logs WHERE agent_id=? AND created_at > ? AND resolved=0",
                (agent_id, deployed_at)
            ).fetchone()[0]

            if resolved > 0 and new_failures == 0:
                assessment = "success"
            elif new_failures > resolved:
                assessment = "regression"
            elif resolved == 0 and new_failures == 0:
                assessment = "neutral"
            else:
                assessment = "partial"

            # Record outcome
            outcome_id = f"outcome_{uuid.uuid4().hex[:8]}"
            conn.execute(
                """INSERT OR REPLACE INTO deployment_outcomes
                   (id, deployment_id, agent_id, resolved_failures, new_failures, assessment, assessed_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (outcome_id, deployment_id, agent_id, resolved, new_failures,
                 assessment, datetime.now().isoformat())
            )
            conn.commit()

            return {
                "deployment_id": deployment_id,
                "agent_id": agent_id,
                "resolved": resolved,
                "new_failures": new_failures,
                "assessment": assessment,
            }
        except Exception as e:
            logger.warning(f"[FailureCollector] assess_deployment failed: {e}")
            return {"assessment": "error", "error": str(e)}
        finally:
            conn.close()

    def get_stats(self, agent_id: str = None) -> Dict[str, Any]:
        """Get failure statistics."""
        conn = sqlite3.connect(self.db_path)
        try:
            if agent_id:
                total = conn.execute("SELECT COUNT(*) FROM failure_logs WHERE agent_id = ?", (agent_id,)).fetchone()[0]
                unresolved = conn.execute("SELECT COUNT(*) FROM failure_logs WHERE agent_id = ? AND resolved = 0", (agent_id,)).fetchone()[0]
                by_type = {}
                for row in conn.execute("SELECT error_type, COUNT(*) FROM failure_logs WHERE agent_id = ? GROUP BY error_type", (agent_id,)):
                    by_type[row[0]] = row[1]
            else:
                total = conn.execute("SELECT COUNT(*) FROM failure_logs").fetchone()[0]
                unresolved = conn.execute("SELECT COUNT(*) FROM failure_logs WHERE resolved = 0").fetchone()[0]
                by_type = {}
                for row in conn.execute("SELECT error_type, COUNT(*) FROM failure_logs GROUP BY error_type"):
                    by_type[row[0]] = row[1]

            top_agents = []
            for row in conn.execute(
                "SELECT agent_id, COUNT(*) as cnt FROM failure_logs WHERE resolved = 0 GROUP BY agent_id ORDER BY cnt DESC LIMIT 10"
            ):
                top_agents.append({"agent_id": row[0], "unresolved_count": row[1]})
        finally:
            conn.close()

        return {
            "total_failures": total,
            "unresolved": unresolved,
            "resolved": total - unresolved,
            "by_type": by_type,
            "top_failing_agents": top_agents,
        }

    def _classify_error(self, error_type: str, error_message: str) -> str:
        """Classify error into taxonomy."""
        if error_type in self.ERROR_TYPES:
            return error_type

        msg = error_message.lower()
        if "syntax" in msg or "invalid syntax" in msg:
            return "syntax_error"
        if "import" in msg or "modulenotfound" in msg:
            return "import_error"
        if "timeout" in msg or "timed out" in msg:
            return "timeout"
        if "typeerror" in msg or "type" in msg and "expected" in msg:
            return "type_error"
        if "assert" in msg:
            return "assertion_error"
        if "expected" in msg and ("got" in msg or "actual" in msg):
            return "logic_error"
        return "runtime_error"

    def _auto_tag(self, error_type: str, error_message: str) -> List[str]:
        """Auto-tag failure with pattern keywords."""
        tags = [error_type]
        msg = error_message.lower()

        tag_patterns = {
            "wrong_comparison": [">=", "<=", ">", "<", "comparison", "inequality"],
            "missing_return": ["no return", "none returned", "nonetype"],
            "division_by_zero": ["division by zero", "zerodivisionerror"],
            "key_error": ["keyerror", "key not found", "missing key"],
            "index_error": ["indexerror", "index out of range", "list index"],
            "attribute_error": ["attributeerror", "has no attribute"],
            "value_mismatch": ["expected", "but got", "actual"],
            "async_error": ["coroutine", "await", "async"],
        }

        for tag, keywords in tag_patterns.items():
            if any(kw in msg for kw in keywords):
                tags.append(tag)

        return tags
