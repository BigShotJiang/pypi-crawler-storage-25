"""
DynamicAgentFactory — Create domain-expert agents on-the-fly.

Instead of fixed 8 agents, create specialized agents for specific domains
(finance, healthcare, legal) to provide domain-specific code review.
"""

from typing import Dict, Any, Optional
from loguru import logger

from core.agentic.base import ForgeAgent


class DomainExpertAgent(ForgeAgent):
    """Dynamically created domain expert for code review/validation."""

    def __init__(self, domain: str, task_description: str):
        super().__init__(
            name=f"{domain.title()}Expert",
            description=f"Domain expert for {domain}: {task_description}",
            role="domain_expert",
        )
        self.domain = domain
        self.task_description = task_description
        self._llm = None

    def _get_llm(self):
        if self._llm is None:
            try:
                from core.direct_gemini_client import DirectGeminiClient
                self._llm = DirectGeminiClient()
            except Exception:
                pass
        return self._llm

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Review code/output from domain perspective."""
        llm = self._get_llm()
        if not llm:
            return {"review": "LLM unavailable", "confidence": 0.5}

        import asyncio
        prompt = (
            f"You are a {self.domain} domain expert.\n"
            f"Task: {self.task_description}\n\n"
            f"Review this:\n{query[:3000]}\n\n"
            f"Provide:\n1. Domain-specific issues (if any)\n"
            f"2. Suggestions for improvement\n"
            f"3. Confidence (0-1) that this is correct for {self.domain}"
        )

        try:
            response = await asyncio.wait_for(
                llm.generate(prompt, max_tokens=1000, temperature=0.2), timeout=15)
            return {"review": response.strip() if response else "", "confidence": 0.8, "domain": self.domain}
        except Exception as e:
            return {"review": str(e), "confidence": 0.3, "domain": self.domain}


class DynamicAgentFactory:
    """Factory for creating specialized agents on demand."""

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def create_expert(self, domain: str, task_description: str) -> DomainExpertAgent:
        """Create a domain expert agent."""
        logger.info(f"[DynamicFactory] Creating {domain} expert: {task_description[:50]}")
        return DomainExpertAgent(domain, task_description)

    def create_reviewer(self, criteria: str) -> DomainExpertAgent:
        """Create a code reviewer agent with specific criteria."""
        return DomainExpertAgent("code_review", f"Review code against: {criteria}")
