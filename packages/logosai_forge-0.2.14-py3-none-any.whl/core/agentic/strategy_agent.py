"""
StrategyAgent — ReAct-based generation strategy selection.

Uses Observe→Think→Act→Reflect cycle to choose the optimal
code generation strategy for each FunctionSpec:
- slice: Reuse from 174-slice library (fastest, proven code)
- template: Apply template with LLM customization
- llm: Generate from scratch with LLM (most flexible)

Learns from past outcomes via shared ForgeAgent memory.
"""

import asyncio
from typing import Dict, Any, List, Optional, Tuple
from loguru import logger

from core.agentic.base import ForgeAgent


class StrategyAgent(ForgeAgent):
    """ReAct agent that selects optimal generation strategy per function."""

    def __init__(self):
        super().__init__("StrategyAgent", "ReAct-based generation strategy selector", role="strategy")
        self._slice_library = None
        self._success_history: Dict[str, Dict[str, int]] = {}  # domain → {slice: N, llm: N, template: N}

    def _ensure_slice_library(self):
        """Lazy-load slice library."""
        if self._slice_library is not None:
            return
        try:
            from core.slice_library.library import SliceLibrary
            from core.slice_library.core_slices import create_core_slices
            from core.slice_library.common_slices import create_common_slices
            from core.slice_library.domain_slices import create_all_domain_slices

            self._slice_library = SliceLibrary()
            self._slice_library.register_many(create_core_slices())
            self._slice_library.register_many(create_common_slices())
            self._slice_library.register_many(create_all_domain_slices())

            # Load filled slices
            try:
                import json
                from pathlib import Path
                filled_path = Path(__file__).parent.parent / "business_logic_v2" / "slice_library" / "filled_slices.json"
                if filled_path.exists():
                    with open(filled_path) as f:
                        data = json.load(f)
                    for entry in data.get("slices", []):
                        name = entry.get("name", "")
                        code = entry.get("code_template", "")
                        if name in self._slice_library._slices and code:
                            self._slice_library._slices[name].code_template = code
            except Exception:
                pass

            logger.info(f"StrategyAgent: loaded {len(self._slice_library._slices)} slices")
        except Exception as e:
            logger.warning(f"StrategyAgent: slice library unavailable: {e}")

    async def select_strategy(
        self,
        spec_name: str,
        spec_description: str,
        spec_category: str,
        domain: str = "general",
        has_test_cases: bool = False,
        complexity: str = "L1",
    ) -> Dict[str, Any]:
        """Select optimal strategy using ReAct cycle.

        Returns:
            {
                "strategy": "slice" | "llm" | "template",
                "confidence": float,
                "reasoning": str,
                "slice_match": Optional[str],  # matched slice name
                "slice_score": Optional[float],
            }
        """
        context = {
            "spec_name": spec_name,
            "spec_description": spec_description,
            "spec_category": spec_category,
            "domain": domain,
            "has_test_cases": has_test_cases,
            "complexity": complexity,
        }
        response = await self.process(spec_name, context)
        return response.content

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        spec_name = context.get("spec_name", query)
        domain = context.get("domain", "general")
        has_test_cases = context.get("has_test_cases", False)
        complexity = context.get("complexity", "L1")

        # ── OBSERVE ──
        self.add_reasoning_step("observe", f"Spec: {spec_name}, domain={domain}, complexity={complexity}")

        self._ensure_slice_library()

        # Check slice availability
        slice_match = None
        slice_score = 0.0
        if self._slice_library:
            keywords = self._build_search_keywords(spec_name, context.get("spec_description", ""), context.get("spec_category", ""))
            results = self._slice_library.search_by_keywords(keywords, language="auto", threshold=0.3)
            if results:
                candidate, score = results[0]
                has_code = bool(candidate.code_template and "async def" in candidate.code_template)
                if has_code and score >= 0.4:
                    slice_match = candidate.name
                    slice_score = score

        self.add_reasoning_step("observe", f"Slice search: {'match=' + slice_match + f' (score={slice_score:.2f})' if slice_match else 'no match'}")

        # Check past success history
        past = ForgeAgent.recall(f"strategy_success:{domain}")
        if past:
            self.add_reasoning_step("observe", f"Past success rates for {domain}: {past}")

        # ── THINK ──
        strategy = "llm"
        confidence = 0.5
        reasoning = ""

        if slice_match and slice_score >= 0.7:
            # High-confidence slice match
            strategy = "slice"
            confidence = min(0.95, slice_score)
            reasoning = f"High-confidence slice match: {slice_match} (score={slice_score:.2f})"
        elif slice_match and slice_score >= 0.4:
            if has_test_cases:
                # Has test cases → LLM can implement exact formula
                strategy = "llm"
                confidence = 0.7
                reasoning = f"Slice found ({slice_match}, score={slice_score:.2f}) but test_cases provided → LLM for exact match"
            else:
                # Moderate match, no tests → use slice
                strategy = "slice"
                confidence = min(0.85, slice_score + 0.1)
                reasoning = f"Moderate slice match: {slice_match} (score={slice_score:.2f}), no test cases"
        else:
            # No slice → LLM
            strategy = "llm"
            confidence = 0.6
            reasoning = "No suitable slice found, using LLM generation"

        # Adjust based on complexity
        if complexity == "L3" and strategy == "llm":
            confidence *= 0.9  # L3 LLM generation is riskier
            reasoning += " (L3 complexity penalty applied)"

        self.add_reasoning_step("think", f"Decision: {strategy} (conf={confidence:.2f}) — {reasoning}")

        # ── ACT ──
        result = {
            "strategy": strategy,
            "confidence": confidence,
            "reasoning": reasoning,
            "slice_match": slice_match,
            "slice_score": slice_score,
        }

        self.add_reasoning_step("act", f"Selected: {strategy}")

        # ── REFLECT ──
        # Will be called later with actual outcome via report_outcome()
        self.add_reasoning_step("reflect", "Strategy selected, awaiting generation outcome for learning")

        return result

    def report_outcome(self, domain: str, strategy: str, success: bool, quality_score: float = 0.0):
        """Report the outcome of a strategy selection for learning."""
        key = f"strategy_success:{domain}"
        past = ForgeAgent.recall(key) or {"slice": {"attempts": 0, "successes": 0}, "llm": {"attempts": 0, "successes": 0}, "template": {"attempts": 0, "successes": 0}}
        if strategy in past:
            past[strategy]["attempts"] += 1
            if success:
                past[strategy]["successes"] += 1
        ForgeAgent.remember(key, past, {"last_quality": quality_score})

    def _build_search_keywords(self, name: str, description: str, category: str) -> List[str]:
        """Build search keywords from spec info."""
        import re
        keywords = []
        # From function name
        parts = name.lstrip("_").split("_")
        keywords.extend(parts)
        # From description
        if description:
            keywords.extend(re.findall(r"[a-z]+", description.lower()))
        # From category
        if category:
            keywords.extend(category.lower().split("_"))

        stop = {"the", "a", "an", "and", "or", "for", "of", "in", "to", "with", "based", "on", "from", "by",
                "get", "process", "self", "data", "result", "dict", "str", "int", "float"}
        return [k for k in keywords if k not in stop and len(k) > 2]
