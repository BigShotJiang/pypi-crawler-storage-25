"""
ErrorHealerAgent — Parallel expert agents for error diagnosis and fixing.

3 sub-agents analyze errors from different perspectives:
- SyntaxExpertAgent: AST parsing, indentation, brackets, quotes
- LogicExpertAgent: Data flow, return values, type mismatches
- SemanticExpertAgent: Intent mismatch, missing logic, wrong algorithm

Each expert proposes a fix. Best fix (by confidence) is applied.
Past error patterns stored in ForgeAgent memory for learning.
"""

import ast
import asyncio
import re
from typing import Dict, Any, List, Optional, Tuple
from loguru import logger

from core.agentic.base import ForgeAgent

try:
    from core.direct_gemini_client import DirectGeminiClient
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False


class SyntaxExpertAgent(ForgeAgent):
    """Fixes syntax errors using AST analysis + rule-based repairs."""

    def __init__(self):
        super().__init__("SyntaxExpert", "Fixes Python syntax errors", role="error_healing")

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        code = context.get("code", "")
        error = context.get("error", "")
        self.add_reasoning_step("observe", f"SyntaxError: {error[:80]}")

        fixed_code = code
        fixes = []

        # Fix empty blocks (try/if/for/while without body)
        fixed_code, f1 = self._fix_empty_blocks(fixed_code)
        if f1:
            fixes.append("empty_blocks")

        # Fix unterminated strings
        fixed_code, f2 = self._fix_unterminated_strings(fixed_code)
        if f2:
            fixes.append("unterminated_strings")

        # Fix indentation
        fixed_code, f3 = self._fix_indentation(fixed_code, error)
        if f3:
            fixes.append("indentation")

        # Validate fix
        try:
            ast.parse(fixed_code)
            self.add_reasoning_step("act", f"Fixed: {fixes}", 0.95)
            return {"fixed_code": fixed_code, "fixes": fixes, "success": True, "confidence": 0.95}
        except SyntaxError as e:
            self.add_reasoning_step("reflect", f"Fix incomplete: {e}", 0.3)
            return {"fixed_code": fixed_code, "fixes": fixes, "success": False, "confidence": 0.3, "remaining_error": str(e)}

    def _fix_empty_blocks(self, code: str) -> Tuple[str, bool]:
        lines = code.split('\n')
        result = []
        fixed = False
        starters = ('try:', 'else:', 'finally:', 'except:', 'except ')
        for i, line in enumerate(lines):
            result.append(line)
            stripped = line.lstrip()
            if any(stripped.startswith(s) for s in starters) and stripped.rstrip().endswith(':'):
                indent = len(line) - len(stripped)
                has_body = False
                for j in range(i + 1, min(i + 3, len(lines))):
                    ns = lines[j].lstrip()
                    if not ns:
                        continue
                    if len(lines[j]) - len(ns) > indent:
                        has_body = True
                    break
                if not has_body:
                    result.append(' ' * (indent + 4) + 'pass')
                    fixed = True
        return '\n'.join(result), fixed

    def _fix_unterminated_strings(self, code: str) -> Tuple[str, bool]:
        lines = code.split('\n')
        result = []
        fixed = False
        for line in lines:
            stripped = line.lstrip()
            for q in ['"', "'"]:
                if q * 3 in stripped:
                    continue
                count = stripped.count(q) - stripped.count(f'\\{q}')
                if count % 2 != 0:
                    line = line.rstrip() + q
                    fixed = True
                    break
            result.append(line)
        return '\n'.join(result), fixed

    def _fix_indentation(self, code: str, error: str) -> Tuple[str, bool]:
        if 'indent' not in error.lower():
            return code, False
        # Try to fix by normalizing to 4-space indentation
        lines = code.split('\n')
        result = []
        fixed = False
        for line in lines:
            if '\t' in line:
                line = line.replace('\t', '    ')
                fixed = True
            result.append(line)
        return '\n'.join(result), fixed


class LogicExpertAgent(ForgeAgent):
    """Analyzes logic errors: missing returns, wrong data flow."""

    def __init__(self):
        super().__init__("LogicExpert", "Fixes logic errors in generated code", role="error_healing")

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        code = context.get("code", "")
        error = context.get("error", "")
        self.add_reasoning_step("observe", f"Logic analysis: {error[:80]}")

        fixes = []
        fixed_code = code

        # Check for missing return in async methods
        fixed_code, f1 = self._fix_missing_returns(fixed_code)
        if f1:
            fixes.append("missing_return")

        # Check for type errors in common patterns
        fixed_code, f2 = self._fix_common_type_errors(fixed_code)
        if f2:
            fixes.append("type_fix")

        success = bool(fixes)
        conf = 0.7 if success else 0.2
        self.add_reasoning_step("act", f"Logic fixes: {fixes}", conf)
        return {"fixed_code": fixed_code, "fixes": fixes, "success": success, "confidence": conf}

    def _fix_missing_returns(self, code: str) -> Tuple[str, bool]:
        lines = code.split('\n')
        fixed = False
        # Find async def methods that don't return
        in_method = False
        method_indent = 0
        has_return = False
        method_end = -1

        for i, line in enumerate(lines):
            stripped = line.lstrip()
            indent = len(line) - len(stripped)
            if stripped.startswith('async def ') and 'process' not in stripped:
                in_method = True
                method_indent = indent
                has_return = False
                method_end = i
            elif in_method and indent <= method_indent and stripped and not stripped.startswith('#'):
                if not has_return and method_end > 0:
                    # Insert return {} before this line
                    lines.insert(i, ' ' * (method_indent + 4) + 'return {}')
                    fixed = True
                in_method = False
            elif in_method and 'return ' in stripped:
                has_return = True
                method_end = i

        return '\n'.join(lines), fixed

    def _fix_common_type_errors(self, code: str) -> Tuple[str, bool]:
        fixed = False
        # Fix .get() on non-dict
        if "AttributeError" in code or "'str' object has no attribute 'get'" in code:
            code = code.replace('.get(', '.get(' if isinstance(code, dict) else '')
            fixed = True
        return code, fixed


class SemanticExpertAgent(ForgeAgent):
    """Analyzes semantic errors using LLM: intent mismatch, wrong algorithm."""

    def __init__(self):
        super().__init__("SemanticExpert", "Fixes semantic errors via LLM analysis", role="error_healing")
        self._llm = None

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        code = context.get("code", "")
        error = context.get("error", "")
        original_query = context.get("original_query", "")
        self.add_reasoning_step("observe", f"Semantic analysis for: {error[:60]}")

        if not LLM_AVAILABLE:
            return {"fixed_code": code, "fixes": [], "success": False, "confidence": 0.1}

        if self._llm is None:
            self._llm = DirectGeminiClient(model_name="gemini-2.5-flash-lite")

        prompt = f"""Fix this Python code error. Return ONLY the fixed code in a ```python block.

Error: {error[:200]}
Original intent: {original_query[:200]}

Code:
```python
{code[:3000]}
```

Fix the error while preserving the original intent. Return complete fixed code."""

        try:
            response = await asyncio.wait_for(
                self._llm.generate(prompt, max_tokens=4000, temperature=0.1),
                timeout=15
            )
            if response and '```python' in response:
                fixed = response.split('```python')[1].split('```')[0].strip()
                try:
                    ast.parse(fixed)
                    self.add_reasoning_step("act", "LLM semantic fix applied", 0.8)
                    return {"fixed_code": fixed, "fixes": ["semantic_llm"], "success": True, "confidence": 0.8}
                except SyntaxError:
                    pass
        except Exception as e:
            self.add_reasoning_step("reflect", f"LLM fix failed: {e}", 0.1)

        return {"fixed_code": code, "fixes": [], "success": False, "confidence": 0.1}


class ErrorHealerAgent(ForgeAgent):
    """Orchestrates 3 error experts in parallel for consensus healing."""

    def __init__(self):
        super().__init__("ErrorHealer", "Multi-expert error healing orchestrator", role="orchestrator")
        self.syntax_expert = SyntaxExpertAgent()
        self.logic_expert = LogicExpertAgent()
        self.semantic_expert = SemanticExpertAgent()

    async def heal(self, code: str, error: str, original_query: str = "") -> Dict[str, Any]:
        """Heal code using parallel expert analysis.

        Returns:
            {"code": str, "healed": bool, "fixes": List[str], "confidence": float, "expert": str}
        """
        response = await self.process(error, {
            "code": code,
            "error": error,
            "original_query": original_query,
        })
        return response.content

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        code = context.get("code", "")
        error = context.get("error", "")
        original_query = context.get("original_query", "")

        self.add_reasoning_step("think", f"Dispatching to 3 expert agents for: {error[:60]}")

        # Check memory for similar past errors
        similar = ForgeAgent.recall_similar([error.split(':')[0], error.split('(')[0].strip()[:30]])
        if similar:
            self.add_reasoning_step("observe", f"Found {len(similar)} similar past errors in memory")

        # Run all 3 experts in parallel
        expert_context = {"code": code, "error": error, "original_query": original_query}

        results = await asyncio.gather(
            self.syntax_expert.process(error, expert_context),
            self.logic_expert.process(error, expert_context),
            self.semantic_expert.process(error, expert_context),
            return_exceptions=True,
        )

        # Collect expert opinions
        opinions = []
        for i, (r, name) in enumerate(zip(results, ["syntax", "logic", "semantic"])):
            if isinstance(r, Exception):
                continue
            content = r.content
            if content.get("success"):
                opinions.append({
                    "expert": name,
                    "confidence": content.get("confidence", 0),
                    "fixes": content.get("fixes", []),
                    "fixed_code": content.get("fixed_code", code),
                })

        if not opinions:
            self.add_reasoning_step("reflect", "No expert could fix the error", 0.1)
            return {"code": code, "healed": False, "fixes": [], "confidence": 0.0, "expert": "none"}

        # Select best fix (highest confidence)
        best = max(opinions, key=lambda x: x["confidence"])
        self.add_reasoning_step("debate", f"Best fix from {best['expert']} (conf={best['confidence']:.2f}): {best['fixes']}")

        # Verify the fix compiles
        try:
            ast.parse(best["fixed_code"])
            healed = True
        except SyntaxError:
            healed = False
            best["confidence"] *= 0.5

        # Store in memory for future reference
        ForgeAgent.remember(
            f"error_fix:{error[:40]}",
            {"expert": best["expert"], "fixes": best["fixes"], "success": healed},
            {"error_type": error.split(":")[0].strip()}
        )

        self.add_reasoning_step("reflect", f"Healed={healed}, expert={best['expert']}, fixes={best['fixes']}")

        return {
            "code": best["fixed_code"],
            "healed": healed,
            "fixes": best["fixes"],
            "confidence": best["confidence"],
            "expert": best["expert"],
        }
