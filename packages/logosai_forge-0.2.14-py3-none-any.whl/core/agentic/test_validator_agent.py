"""
TestValidatorAgent — Executes generated agent code with test cases.

Takes assembled code + test_cases → instantiates agent → runs tests → reports results.
If tests fail, generates diagnostic feedback for CodeGeneratorAgent to use on retry.
"""

import ast
import asyncio
import json
import re
import sys
import inspect
from typing import Dict, Any, List, Optional
from loguru import logger

from core.agentic.base import ForgeAgent


class TestValidatorAgent(ForgeAgent):
    """Validates generated agent code by executing test cases."""

    def __init__(self):
        super().__init__("TestValidator", "Validates generated agents with test cases", role="validation")

    async def validate(
        self,
        code: str,
        test_cases: List[Dict],
        original_query: str = "",
    ) -> Dict[str, Any]:
        """Validate generated code against test cases.

        Returns:
            {
                "passed": bool,
                "tests_passed": int,
                "tests_total": int,
                "results": List[{input, expected, actual, match}],
                "errors": List[str],
                "feedback": str,  # diagnostic for retry
            }
        """
        response = await self.process(
            f"Validate with {len(test_cases)} test cases",
            {"code": code, "test_cases": test_cases, "original_query": original_query}
        )
        return response.content

    async def _execute(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        code = context.get("code", "")
        test_cases = context.get("test_cases", [])
        original_query = context.get("original_query", "")

        self.add_reasoning_step("observe", f"Validating code ({len(code.split(chr(10)))} lines) with {len(test_cases)} tests")

        result = {
            "passed": False,
            "tests_passed": 0,
            "tests_total": len(test_cases),
            "results": [],
            "errors": [],
            "feedback": "",
        }

        # Step 1: Syntax check
        try:
            ast.parse(code)
        except SyntaxError as e:
            result["errors"].append(f"SyntaxError: {e}")
            result["feedback"] = f"Code has syntax error at line {e.lineno}: {e.msg}. Fix the syntax."
            self.add_reasoning_step("reflect", f"Syntax error: {e}")
            return result

        # Step 2: Execute code
        try:
            # Prepare execution environment
            from logosai.config import AgentConfig
            from logosai.agent_types import AgentType, AgentResponse, AgentResponseType
            from logosai.agent import LogosAIAgent

            # Patch AgentConfig
            _orig_init = AgentConfig.__init__
            _valid = set(inspect.signature(_orig_init).parameters.keys()) - {'self'}
            def _flex(self_c, name='X', agent_type=None, description='X', **kw):
                if agent_type is None:
                    agent_type = AgentType.CUSTOM
                _orig_init(self_c, name=name, agent_type=agent_type, description=description,
                           **{k: v for k, v in kw.items() if k in _valid})
                for k, v in kw.items():
                    if k not in _valid:
                        setattr(self_c, k, v)
            AgentConfig.__init__ = _flex

            exec_ns = {}
            exec(code, exec_ns)

            # Find agent class
            agent_cls = None
            for n, obj in exec_ns.items():
                if isinstance(obj, type) and hasattr(obj, 'process') and n not in ('LogosAIAgent',):
                    agent_cls = obj
                    break

            if not agent_cls:
                result["errors"].append("No agent class found in generated code")
                result["feedback"] = "Generated code must define a class that extends LogosAIAgent with a process() method."
                return result

            agent = agent_cls()
            self.add_reasoning_step("act", f"Instantiated {agent_cls.__name__}")

        except Exception as e:
            result["errors"].append(f"InstantiationError: {e}")
            result["feedback"] = f"Agent instantiation failed: {e}. Check __init__ method and AgentConfig parameters."
            self.add_reasoning_step("reflect", f"Instantiation failed: {e}")
            return result

        # Step 3: Run test cases
        for i, tc in enumerate(test_cases):
            inp = tc.get("input", {})
            expected = tc.get("expected", {})
            tolerance = tc.get("tolerance", 0.05)

            tc_result = {"input": inp, "expected": expected, "actual": None, "match": False, "error": None}

            try:
                # Try _process_core_logic first (direct business logic)
                output = None
                for method_name in ["_process_core_logic", "execute_workflow"]:
                    method = getattr(agent, method_name, None)
                    if method and asyncio.iscoroutinefunction(method):
                        try:
                            raw = await asyncio.wait_for(method(inp), timeout=5)
                            if raw and isinstance(raw, dict) and raw.get("status") != "partial_implementation":
                                output = raw
                                break
                        except Exception:
                            continue

                # Fallback: try process()
                if output is None:
                    old_limit = sys.getrecursionlimit()
                    sys.setrecursionlimit(200)
                    try:
                        raw = await asyncio.wait_for(
                            agent.process(json.dumps(inp), inp), timeout=5
                        )
                        content = raw.content if hasattr(raw, 'content') else raw
                        if isinstance(content, dict):
                            output = content  # Keep full dict for key-based comparison
                        elif content is not None:
                            output = content
                    except (RecursionError, asyncio.TimeoutError):
                        pass
                    finally:
                        sys.setrecursionlimit(old_limit)

                if output is None:
                    tc_result["error"] = "No output produced"
                    result["results"].append(tc_result)
                    continue

                tc_result["actual"] = self._safe_serialize(output)

                # Compare output with expected
                match = self._compare(output, expected, tolerance)
                tc_result["match"] = match
                if match:
                    result["tests_passed"] += 1

            except Exception as e:
                tc_result["error"] = str(e)[:100]

            result["results"].append(tc_result)

        # Step 4: Generate feedback
        result["passed"] = result["tests_passed"] == result["tests_total"] and result["tests_total"] > 0

        if not result["passed"]:
            feedback_parts = []
            for i, tc_r in enumerate(result["results"]):
                if not tc_r["match"]:
                    if tc_r.get("error"):
                        feedback_parts.append(f"TC{i+1}: Error: {tc_r['error']}")
                    elif tc_r["actual"] is not None:
                        feedback_parts.append(
                            f"TC{i+1}: Expected {json.dumps(tc_r['expected'])[:100]} "
                            f"but got {json.dumps(tc_r['actual'], default=str)[:100]}"
                        )
                    else:
                        feedback_parts.append(f"TC{i+1}: No output produced")
            result["feedback"] = "; ".join(feedback_parts)

        status = "PASS" if result["passed"] else f"FAIL ({result['tests_passed']}/{result['tests_total']})"
        self.add_reasoning_step("reflect", f"Validation: {status}")

        return result

    def _compare(self, actual: Any, expected: Any, tolerance: float) -> bool:
        """Compare actual vs expected with tolerance."""
        if isinstance(expected, dict):
            if not isinstance(actual, dict):
                return False
            for k, v in expected.items():
                act_v = actual.get(k)
                if act_v is None:
                    for val in actual.values():
                        if isinstance(val, dict) and k in val:
                            act_v = val[k]
                            break
                if act_v is None:
                    return False
                if not self._compare(act_v, v, tolerance):
                    return False
            return True
        elif isinstance(expected, (int, float)):
            if not isinstance(actual, (int, float)):
                # Try to extract number from string or dict
                actual = self._extract_number(actual, expected)
                if actual is None:
                    return False
            if expected == 0:
                return abs(actual) <= max(tolerance, 0.01)
            return abs(actual - expected) / max(abs(expected), 1e-10) <= max(tolerance, 0.05)
        elif isinstance(expected, str):
            # Flatten actual to searchable string
            flat = self._flatten_to_string(actual)
            exp_lower = expected.lower().strip()
            # Exact match first, then contains
            return exp_lower in flat
        elif isinstance(expected, bool):
            return str(actual).lower() in ('true', '1') if expected else str(actual).lower() in ('false', '0')
        return actual == expected

    def _extract_number(self, actual: Any, expected_hint: float = 0) -> float | None:
        """Try to extract a numeric value from various output formats."""
        if isinstance(actual, (int, float)):
            return float(actual)
        if isinstance(actual, dict):
            # Search dict values for a number close to expected
            for v in actual.values():
                if isinstance(v, (int, float)):
                    if expected_hint == 0 or abs(v - expected_hint) / max(abs(expected_hint), 1e-10) <= 0.1:
                        return float(v)
                elif isinstance(v, str):
                    n = self._parse_number_from_string(v)
                    if n is not None:
                        return n
                elif isinstance(v, dict):
                    r = self._extract_number(v, expected_hint)
                    if r is not None:
                        return r
        if isinstance(actual, str):
            return self._parse_number_from_string(actual)
        return None

    def _parse_number_from_string(self, s: str) -> float | None:
        """Extract first number from a string."""
        import re
        match = re.search(r'[-+]?\d+\.?\d*', s)
        if match:
            try:
                return float(match.group())
            except ValueError:
                pass
        return None

    def _flatten_to_string(self, actual: Any) -> str:
        """Convert any output to a lowercase searchable string."""
        if isinstance(actual, str):
            return actual.lower()
        if isinstance(actual, dict):
            parts = []
            for v in actual.values():
                parts.append(self._flatten_to_string(v))
            return " ".join(parts)
        if isinstance(actual, (list, tuple)):
            return " ".join(self._flatten_to_string(v) for v in actual)
        return str(actual).lower()

    def _safe_serialize(self, obj):
        try:
            json.dumps(obj)
            return obj
        except (TypeError, ValueError):
            if isinstance(obj, dict):
                return {k: str(v)[:100] for k, v in list(obj.items())[:10]}
            return str(obj)[:200]
