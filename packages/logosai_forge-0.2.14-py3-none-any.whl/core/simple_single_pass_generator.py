"""
Simple Single-Pass Code Generator for FORGE AI
Generates complete agent code in one LLM call to avoid template issues
"""

import asyncio
from typing import Optional, Any, Callable, Dict
from datetime import datetime
from pathlib import Path
import re
from loguru import logger

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts


class SimpleSinglePassGenerator:
    """
    Generates complete agent code in a single LLM call
    to avoid template variable issues and Korean text problems
    """
    
    def __init__(self, llm_orchestrator: LLMOrchestrator):
        """Initialize generator"""
        self.llm = llm_orchestrator
    
    async def generate_progressively(self, analysis: QueryAnalysis, context: Context,
                                    stream_callback: Optional[Callable] = None) -> Any:
        """Generate agent code with progress updates"""
        
        start_time = datetime.now()
        
        try:
            # Show initial progress
            await self._stream_update(stream_callback, "analyzing", 
                                    "🔍 Analyzing requirements...", 
                                    {"progress": 10})
            
            # Prepare the comprehensive prompt
            prompt = self._create_comprehensive_prompt(analysis)
            
            # Show generation progress
            await self._stream_update(stream_callback, "generating",
                                    "🚀 Generating complete agent code...",
                                    {"progress": 30})
            
            # Generate complete code in one call
            result = await self.llm.generate(
                prompt=prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=8000,
                temperature=0.3,
                model_override="gemini-2.5-flash-lite"
            )
            
            # Show processing progress
            await self._stream_update(stream_callback, "processing",
                                    "🔧 Processing and validating code...",
                                    {"progress": 70})
            
            # Extract and clean the code
            final_code = self._extract_and_validate_code(result)
            
            # Show completion
            await self._stream_update(stream_callback, "complete",
                                    "✅ Agent generation complete!",
                                    {"progress": 100,
                                     "total_time": (datetime.now() - start_time).total_seconds()})
            
            # Create artifacts
            artifacts = GenerationArtifacts(
                generation_id=f"simple_gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            
            artifacts.query_analysis = {
                "intent": analysis.intent,
                "domain": analysis.domain,
                "complexity": analysis.complexity.value,
                "capabilities": analysis.required_capabilities
            }
            
            artifacts.generated_code_raw = final_code
            artifacts.optimized_code = final_code
            artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            
            # Return result
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "simple_single_pass"
            
            return GeneratedCode(code=final_code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Generation failed: {e}")
            await self._stream_update(stream_callback, "error",
                                    f"❌ Generation failed: {str(e)}",
                                    {"error": str(e)})
            raise
    
    def _create_comprehensive_prompt(self, analysis: QueryAnalysis) -> str:
        """Create a comprehensive prompt for complete code generation"""
        
        # Generate a simple English agent name
        agent_name = self._generate_english_agent_name(analysis)
        
        prompt = f"""Generate a complete LogosAI agent in Python based on this request:
"{analysis.query}"

IMPORTANT REQUIREMENTS:
1. Generate ONLY executable Python code - no explanations, no Korean text except in strings
2. Use English for all variable names, class names, and function names
3. Class name should be: {agent_name}
4. Follow the LogosAI agent structure exactly
5. Include all necessary imports
6. Implement complete functionality as requested
7. Add sample data generation and test queries

STRUCTURE TO FOLLOW:
```python
import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from loguru import logger

from logosai import (
    LogosAIAgent,
    AgentConfig,
    AgentType,
    AgentResponse,
    AgentResponseType
)
from logosai.utils.llm_client import LLMClient

class {agent_name}(LogosAIAgent):
    def __init__(self, config: Optional[AgentConfig] = None):
        # Initialize with proper config
        
    async def initialize(self) -> bool:
        # Async initialization
        
    async def _extract_query_info(self, query: str) -> Dict[str, Any]:
        # Extract info from query using LLM
        
    async def _process_core_logic(self, extracted_info: Dict[str, Any]) -> Dict[str, Any]:
        # Implement the core business logic here
        # This should fulfill the user's request
        
    async def process(self, request: Dict[str, Any]) -> AgentResponse:
        # Main processing method
        
    async def shutdown(self):
        # Cleanup resources

async def main():
    # Test the agent with sample data and queries

if __name__ == "__main__":
    asyncio.run(main())
```

Generate the COMPLETE working code for the agent. Make sure:
- The agent implements all requested features: {', '.join(analysis.required_capabilities)}
- All methods are properly implemented
- Sample data is realistic and relevant
- Test queries demonstrate the agent's capabilities
- The code is syntactically correct and can be executed

Generate ONLY the Python code, nothing else."""
        
        return prompt
    
    def _generate_english_agent_name(self, analysis: QueryAnalysis) -> str:
        """Generate a valid English agent class name"""
        
        # Map Korean domain/intent to English
        domain = analysis.domain or ""
        
        if "financial" in domain or "finance" in domain:
            base_name = "FinancialRisk"
        elif "customer" in domain:
            base_name = "CustomerAnalysis"
        elif "data" in domain:
            base_name = "DataAnalysis"
        else:
            # Generic fallback based on capabilities
            if analysis.required_capabilities:
                first_cap = analysis.required_capabilities[0]
                base_name = ''.join(word.capitalize() for word in first_cap.split('_'))
            else:
                base_name = "Custom"
        
        return f"{base_name}Agent"
    
    def _extract_and_validate_code(self, response: str) -> str:
        """Extract Python code and validate it"""
        
        # Extract code from markdown blocks
        python_match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        if python_match:
            code = python_match.group(1)
        else:
            # Try to find any code block
            code_match = re.search(r'```\n(.*?)```', response, re.DOTALL)
            if code_match:
                code = code_match.group(1)
            else:
                # Assume the entire response is code
                code = response
        
        # Basic validation and cleanup
        code = code.strip()
        
        # Ensure the code doesn't contain Korean characters outside of strings
        lines = []
        in_string = False
        string_char = None
        
        for line in code.split('\n'):
            # Simple string detection (not perfect but good enough)
            clean_line = ""
            i = 0
            while i < len(line):
                char = line[i]
                
                # Handle string markers
                if char in ['"', "'"] and (i == 0 or line[i-1] != '\\'):
                    if not in_string:
                        in_string = True
                        string_char = char
                    elif char == string_char:
                        in_string = False
                        string_char = None
                
                # Skip Korean characters outside strings
                if not in_string and ord(char) >= 0xAC00 and ord(char) <= 0xD7A3:
                    i += 1
                    continue
                
                clean_line += char
                i += 1
            
            lines.append(clean_line)
        
        return '\n'.join(lines)
    
    async def _stream_update(self, callback: Optional[Callable], status: str, 
                           message: str, data: Dict[str, Any] = None):
        """Send streaming update if callback is provided"""
        if callback:
            await callback(status, message, data or {})