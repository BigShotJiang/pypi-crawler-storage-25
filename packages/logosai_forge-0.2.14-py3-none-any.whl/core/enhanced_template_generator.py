"""
Enhanced Template-Based Generator with Query Analysis Integration
QueryAnalyzer와 IntelligentDataGenerator를 통합한 개선된 템플릿 생성기
"""

import json
import re
import ast
import asyncio
from typing import Dict, Any, Tuple, List, Optional, Callable
from pathlib import Path
from datetime import datetime

from loguru import logger

from .template_based_generator import TemplateBasedGenerator
from .query_analyzer import QueryAnalysis, Complexity
from .intelligent_data_generator import IntelligentDataGenerator


class EnhancedTemplateGenerator(TemplateBasedGenerator):
    """
    개선된 템플릿 기반 생성기
    - QueryAnalysis 결과 활용
    - IntelligentDataGenerator 통합
    - LLM 기반 의미적 매칭
    - 템플릿 성능 추적
    """
    
    def __init__(self, templates_dir: Path = None):
        super().__init__(templates_dir)
        self.data_generator = IntelligentDataGenerator()
        self.template_performance = {}
        self._init_enhanced_registry()
        
    def _init_enhanced_registry(self):
        """향상된 템플릿 레지스트리 초기화"""
        # 기존 템플릿에 추가 메타데이터 추가
        enhanced_metadata = {
            "csv_excel_analyzer": {
                "domain": "data_processing",
                "purpose": "analyze and process csv excel data files",
                "capabilities": ["file_processing", "data_analysis", "statistics", "visualization"],
                "complexity": Complexity.MEDIUM,
                "sample_data_type": "tabular",
                "required_imports": ["pandas", "numpy", "matplotlib"]
            },
            "contract_analyzer": {
                "domain": "document_processing", 
                "purpose": "analyze legal contracts and extract key information",
                "capabilities": ["text_processing", "entity_extraction", "contract_analysis"],
                "complexity": Complexity.COMPLEX,
                "sample_data_type": "text",
                "required_imports": ["re", "datetime", "json"]
            },
            "price_monitoring": {
                "domain": "ecommerce",
                "purpose": "monitor product prices and detect changes",
                "capabilities": ["web_scraping", "monitoring", "notification", "data_tracking"],
                "complexity": Complexity.MEDIUM,
                "sample_data_type": "product_data",
                "required_imports": ["requests", "beautifulsoup4", "pandas"]
            },
            "automl_pipeline": {
                "domain": "machine_learning",
                "purpose": "automated machine learning pipeline for predictions",
                "capabilities": ["ml", "data_processing", "model_training", "prediction"],
                "complexity": Complexity.COMPLEX,
                "sample_data_type": "ml_dataset",
                "required_imports": ["sklearn", "pandas", "numpy", "joblib"]
            },
            "comprehensive": {
                "domain": "general",
                "purpose": "general purpose agent for various tasks",
                "capabilities": ["data_processing", "api", "file"],
                "complexity": Complexity.SIMPLE,
                "sample_data_type": "general",
                "required_imports": ["pandas", "requests"]
            }
        }
        
        # 기존 레지스트리에 향상된 메타데이터 병합
        for template_id, metadata in enhanced_metadata.items():
            if template_id in self.template_registry["templates"]:
                self.template_registry["templates"][template_id].update(metadata)
                
    async def select_template(self, user_request: str, analysis: QueryAnalysis = None) -> Tuple[str, float]:
        """
        QueryAnalysis를 활용한 개선된 템플릿 선택
        
        Args:
            user_request: 사용자 요청
            analysis: QueryAnalyzer의 분석 결과
            
        Returns:
            Tuple[template_id, confidence_score]
        """
        logger.info("🎯 Enhanced template selection with QueryAnalysis")
        
        scores = {}
        
        for template_id, template_info in self.template_registry["templates"].items():
            score = 0.0
            
            # 1. Intent 매칭 (35%)
            if analysis and analysis.intent:
                intent_similarity = await self._calculate_intent_similarity(
                    analysis.intent,
                    template_info.get("purpose", "")
                )
                score += intent_similarity * 0.35
                logger.debug(f"  {template_id} - Intent score: {intent_similarity:.2f}")
            else:
                # Intent가 없으면 키워드 매칭 사용
                keyword_score = self._calculate_keyword_score(
                    user_request.lower(),
                    template_info
                )
                score += keyword_score * 0.35
            
            # 2. 도메인 매칭 (25%)
            if analysis and analysis.domain:
                domain_match = self._calculate_domain_match(
                    analysis.domain,
                    template_info.get("domain", "general")
                )
                score += domain_match * 0.25
                logger.debug(f"  {template_id} - Domain score: {domain_match:.2f}")
            else:
                # 도메인이 없으면 0.1 기본점수
                score += 0.1 * 0.25
            
            # 3. 필요 기능 매칭 (25%)
            if analysis and analysis.required_capabilities:
                capability_match = self._calculate_capability_match(
                    analysis.required_capabilities,
                    template_info.get("capabilities", [])
                )
                score += capability_match * 0.25
                logger.debug(f"  {template_id} - Capability score: {capability_match:.2f}")
            else:
                # capabilities가 없으면 0.2 기본점수
                score += 0.2 * 0.25
            
            # 4. 복잡도 매칭 (5%)
            if analysis and hasattr(analysis, 'complexity'):
                complexity_match = self._calculate_complexity_match(
                    analysis.complexity,
                    template_info.get("complexity", Complexity.SIMPLE)
                )
                score += complexity_match * 0.05
            
            # 5. 기존 키워드 매칭 (10%)
            keyword_score = self._calculate_keyword_score(
                user_request.lower(),
                template_info
            )
            score += keyword_score * 0.10
            
            # 템플릿 성능 기록 반영
            performance_boost = self.get_template_success_rate(template_id) * 0.1
            score = min(score + performance_boost, 1.0)
            
            scores[template_id] = score
            logger.info(f"  {template_id}: {score:.3f}")
        
        # 최고 점수 템플릿 선택
        if not scores:
            return "comprehensive", 0.5
        
        best_template = max(scores.items(), key=lambda x: x[1])
        
        # 점수가 너무 낮으면 기본 템플릿
        if best_template[1] < 0.3:
            logger.warning(f"Low confidence ({best_template[1]:.2f}), using default template")
            return "comprehensive", 0.5
        
        logger.info(f"✅ Selected template: {best_template[0]} (confidence: {best_template[1]:.2f})")
        return best_template
        
    async def _calculate_intent_similarity(self, user_intent: str, template_purpose: str) -> float:
        """의도와 목적의 의미적 유사도 계산"""
        # 간단한 구현 - 실제로는 LLM 사용 가능
        user_words = set(user_intent.lower().split())
        template_words = set(template_purpose.lower().split())
        
        if not user_words or not template_words:
            return 0.0
        
        # Jaccard similarity
        intersection = user_words.intersection(template_words)
        union = user_words.union(template_words)
        
        similarity = len(intersection) / len(union) if union else 0.0
        
        # 특정 키워드 부스트
        boost_keywords = {
            "analyze": ["analysis", "analyze", "process", "분석"],
            "monitor": ["monitoring", "track", "watch", "모니터링"],
            "predict": ["prediction", "forecast", "ml", "예측"],
            "extract": ["extraction", "parse", "process", "추출"],
            "contract": ["계약", "법률", "문서", "조항", "legal", "document"]
        }
        
        for key, synonyms in boost_keywords.items():
            if key in user_intent and any(syn in template_purpose for syn in synonyms):
                similarity = min(similarity + 0.3, 1.0)
        
        return similarity
        
    def _calculate_domain_match(self, user_domain: str, template_domain: str) -> float:
        """도메인 매칭 점수 계산"""
        if user_domain == template_domain:
            return 1.0
        
        # 관련 도메인 매핑
        related_domains = {
            "finance": ["ecommerce", "data_processing"],
            "ecommerce": ["finance", "data_processing"],
            "data_processing": ["finance", "ecommerce", "general"],
            "document_processing": ["general"],
            "machine_learning": ["data_processing"],
            "general": ["data_processing", "document_processing"]
        }
        
        if template_domain in related_domains.get(user_domain, []):
            return 0.6
        
        if template_domain == "general" or user_domain == "general":
            return 0.4
            
        return 0.0
        
    def _calculate_capability_match(self, required: List[str], available: List[str]) -> float:
        """필요 기능과 제공 기능의 매칭 점수"""
        if not required or not available:
            return 0.5
        
        required_set = set(required)
        available_set = set(available)
        
        # 매칭되는 기능 수
        matched = len(required_set.intersection(available_set))
        
        # 필요한 기능 중 몇 퍼센트가 매칭되는지
        coverage = matched / len(required_set) if required_set else 0.0
        
        # 추가 기능 페널티 (너무 많은 불필요한 기능)
        extra_features = len(available_set - required_set)
        penalty = min(extra_features * 0.05, 0.2)
        
        return max(coverage - penalty, 0.0)
        
    def _calculate_complexity_match(self, user_complexity: Complexity, template_complexity: Complexity) -> float:
        """복잡도 매칭"""
        complexity_values = {
            Complexity.SIMPLE: 1,
            Complexity.MEDIUM: 2,
            Complexity.COMPLEX: 3,
            Complexity.EXPERT: 4
        }
        
        user_val = complexity_values.get(user_complexity, 2)
        template_val = complexity_values.get(template_complexity, 2)
        
        diff = abs(user_val - template_val)
        
        if diff == 0:
            return 1.0
        elif diff == 1:
            return 0.7
        elif diff == 2:
            return 0.3
        else:
            return 0.0
            
    def _calculate_keyword_score(self, user_request: str, template_info: Dict) -> float:
        """기존 키워드 매칭 (보조)"""
        score = 0.0
        for keyword in template_info.get("keywords", []):
            if keyword.lower() in user_request:
                score += 0.2
        return min(score, 1.0)
        
    async def generate_business_logic(self, template_id: str, user_request: str, 
                                    analysis: QueryAnalysis, llm_client: Any) -> Dict[str, str]:
        """
        QueryAnalysis를 활용한 비즈니스 로직 생성 + 패턴 통합 시스템
        """
        logger.info(f"🚀 Enhanced business logic generation with Pattern Integration")
        logger.info(f"  Template: {template_id}")
        logger.info(f"  Domain: {analysis.domain}")
        logger.info(f"  Intent: {analysis.intent}")
        
        # 🔗 패턴 통합 시스템 시도
        if self._should_use_pattern_integration(template_id, user_request):
            logger.info("🆕 Using Pattern Template Integration System")
            try:
                from .pattern_template_integrator import get_pattern_integrator
                integrator = get_pattern_integrator()
                
                pattern_result = await integrator.enhanced_generate_business_logic(
                    template_id, user_request, llm_client
                )
                logger.info(f"✅ Pattern integration succeeded with method: {pattern_result.get('generation_method', 'unknown')}")
                return pattern_result
            except Exception as e:
                logger.error(f"❌ Pattern integration failed, falling back: {e}")
                # Fall through to original system
        
        # 기본 비즈니스 로직 생성
        business_logic = await super().generate_business_logic(
            template_id, user_request, llm_client
        )
        
        # IntelligentDataGenerator를 활용한 샘플 데이터 개선
        if analysis and analysis.domain:
            logger.info("📊 Generating domain-specific sample data")
            
            # 생성된 코드에서 데이터 요구사항 추출
            generated_code = business_logic.get("process_logic", "") + \
                           business_logic.get("init_logic", "")
            
            if generated_code:
                requirements = self.data_generator.analyze_code_requirements(generated_code)
                test_suite = self.data_generator.generate_test_data(
                    requirements,
                    domain=analysis.domain
                )
                
                # 샘플 코드에 실제 데이터 주입
                enhanced_sample = self._enhance_sample_with_real_data(
                    business_logic.get("sample_code", ""),
                    test_suite.normal,
                    analysis
                )
                
                business_logic["sample_code"] = enhanced_sample
                business_logic["test_data"] = test_suite.normal
                
                logger.info(f"✅ Enhanced sample data for domain: {analysis.domain}")
        
        # 분석 결과를 메타데이터에 추가
        business_logic["_analysis"] = {
            "intent": analysis.intent,
            "domain": analysis.domain,
            "capabilities": analysis.required_capabilities,
            "complexity": analysis.complexity.value if analysis.complexity else "simple"
        }
        
        return business_logic
    
    def _should_use_pattern_integration(self, template_id: str, user_request: str) -> bool:
        """패턴 통합 시스템 사용 여부 결정"""
        
        import os
        
        # 환경 변수로 제어 가능
        if os.getenv('FORGE_ENABLE_PATTERNS', 'true').lower() == 'false':
            return False
        
        # 특정 템플릿들에 대해 패턴 시스템 우선 사용
        pattern_friendly_templates = [
            'data_analysis', 'comprehensive', 'advanced', 
            'business_intelligence', 'analytics'
        ]
        
        if template_id in pattern_friendly_templates:
            return True
        
        # 키워드 기반 결정 (더 적극적으로) - 🔧 AutoML 키워드 추가
        pattern_keywords = [
            'csv', 'excel', '데이터', '분석', 'analysis', '차트', 
            '대시보드', 'dashboard', '고객', 'customer', '위험', 'risk',
            '시각화', 'visualization', '예측', 'prediction', '품질', 'quality',
            # 🔧 NEW: AutoML/ML 관련 키워드
            'ml', 'ML', '머신러닝', 'machine learning', 'automl', 'AutoML',
            '알고리즘', 'algorithm', '모델', 'model', 'modeling',
            '하이퍼파라미터', 'hyperparameter', '튜닝', 'tuning', 'optimization',
            '성능', 'performance', '평가', 'evaluation', 'validation',
            '배포', 'deployment', '학습', 'training', 'sklearn'
        ]
        
        user_lower = user_request.lower()
        matched = sum(1 for kw in pattern_keywords if kw in user_lower)
        
        should_use = matched >= 1  # 1개 이상 키워드 매칭시 패턴 시스템 사용
        
        if should_use:
            logger.info(f"🎯 Pattern system triggered by {matched} keywords")
        
        return should_use
        
    def _enhance_sample_with_real_data(self, sample_code: str, test_data: Dict[str, Any], 
                                      analysis: QueryAnalysis) -> str:
        """샘플 코드에 실제 테스트 데이터 주입"""
        enhanced_code = sample_code
        
        # 도메인별 데이터 패턴 적용
        if analysis.domain == "ecommerce":
            data_snippet = """    # E-commerce 실제 데이터 예시
    test_data = {
        'products': [
            {'id': 'PROD-12345', 'name': '노트북', 'price': 1500000, 'category': 'Electronics'},
            {'id': 'PROD-12346', 'name': '마우스', 'price': 35000, 'category': 'Electronics'},
            {'id': 'PROD-12347', 'name': '키보드', 'price': 89000, 'category': 'Electronics'}
        ],
        'query': '전자제품 가격 분석'
    }"""
        elif analysis.domain == "finance":
            data_snippet = """    # 금융 데이터 예시
    test_data = {
        'transactions': [
            {'date': '2024-01-15', 'amount': 150000, 'type': 'deposit', 'account': 'ACC100001'},
            {'date': '2024-01-16', 'amount': 50000, 'type': 'withdrawal', 'account': 'ACC100001'},
            {'date': '2024-01-17', 'amount': 200000, 'type': 'transfer', 'account': 'ACC100002'}
        ],
        'analysis_type': 'transaction_summary'
    }"""
        elif analysis.domain == "data_processing":
            data_snippet = """    # 데이터 처리 예시
    import pandas as pd
    
    # CSV 데이터 시뮬레이션
    data = pd.DataFrame({
        'Date': pd.date_range('2024-01-01', periods=30),
        'Sales': np.random.randint(100, 1000, 30),
        'Region': np.random.choice(['Seoul', 'Busan', 'Daegu'], 30),
        'Product': np.random.choice(['A', 'B', 'C'], 30)
    })
    
    test_data = {
        'data': data.to_dict('records'),
        'analysis_type': 'sales_by_region'
    }"""
        else:
            # 기본 데이터
            data_snippet = f"""    # 테스트 데이터
    test_data = {json.dumps(test_data, indent=8, ensure_ascii=False)}"""
        
        # 기존 샘플 데이터 부분을 실제 데이터로 교체
        if "test_data = {" in enhanced_code or "sample_data = {" in enhanced_code:
            enhanced_code = re.sub(
                r'(test_data|sample_data)\s*=\s*{[^}]*}',
                data_snippet.strip(),
                enhanced_code,
                flags=re.DOTALL
            )
        else:
            # 샘플 데이터가 없으면 추가
            enhanced_code = data_snippet + "\n\n" + enhanced_code
        
        return enhanced_code
        
    def record_template_usage(self, template_id: str, query: str, success: bool):
        """템플릿 사용 결과 기록"""
        if template_id not in self.template_performance:
            self.template_performance[template_id] = {
                'successes': 0,
                'failures': 0,
                'queries': []
            }
        
        if success:
            self.template_performance[template_id]['successes'] += 1
        else:
            self.template_performance[template_id]['failures'] += 1
        
        self.template_performance[template_id]['queries'].append({
            'query': query,
            'success': success,
            'timestamp': datetime.now().isoformat()
        })
        
    def get_template_success_rate(self, template_id: str) -> float:
        """템플릿 성공률 계산"""
        if template_id not in self.template_performance:
            return 0.5  # 기본값
        
        perf = self.template_performance[template_id]
        total = perf['successes'] + perf['failures']
        
        if total == 0:
            return 0.5
        
        return perf['successes'] / total
        
    def validate_generated_code(self, code: str, analysis: QueryAnalysis) -> Dict[str, Any]:
        """생성된 코드 검증"""
        issues = []
        
        # 1. 필수 기능 구현 확인
        for capability in analysis.required_capabilities:
            capability_patterns = {
                'file_processing': ['pd.read_csv', 'pd.read_excel', 'open('],
                'data_analysis': ['analyze', 'calculate', 'process'],
                'api': ['requests.', 'http', 'endpoint'],
                'monitoring': ['monitor', 'track', 'check'],
                'ml': ['predict', 'train', 'model']
            }
            
            patterns = capability_patterns.get(capability, [capability])
            if not any(pattern in code for pattern in patterns):
                issues.append(f"Missing capability implementation: {capability}")
        
        # 2. 문법 검증
        try:
            ast.parse(code)
        except SyntaxError as e:
            issues.append(f"Syntax error: {e}")
        
        # 3. 필수 import 확인
        template_info = self.template_registry["templates"].get(
            analysis.domain, {}
        )
        required_imports = template_info.get("required_imports", [])
        
        for imp in required_imports:
            if f"import {imp}" not in code and f"from {imp}" not in code:
                issues.append(f"Missing required import: {imp}")
        
        return {
            'is_valid': len(issues) == 0,
            'issues': issues,
            'confidence': 1.0 - (len(issues) * 0.2)
        }