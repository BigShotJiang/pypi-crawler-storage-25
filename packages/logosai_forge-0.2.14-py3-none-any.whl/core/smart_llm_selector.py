"""
Smart LLM Selector - 작업별 최적 모델 선택기
상황에 따라 가장 효율적인 LLM 모델을 자동으로 선택
"""

import asyncio
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
from enum import Enum
import time
from pathlib import Path
import yaml

from .llm_manager import FORGELLMManager


class Urgency(Enum):
    """작업 긴급도"""
    IMMEDIATE = "immediate"  # < 500ms
    FAST = "fast"           # < 1s
    QUALITY = "quality"     # < 3s


class Complexity(Enum):
    """작업 복잡도"""
    SIMPLE = "simple"      # 단순 검증, 완성
    MEDIUM = "medium"      # 분석, 리뷰, 간단한 생성
    COMPLEX = "complex"    # 복잡한 생성, 설계


@dataclass
class TaskContext:
    """작업 컨텍스트"""
    task_type: str
    urgency: Urgency = Urgency.FAST
    complexity: Complexity = Complexity.MEDIUM
    estimated_tokens: int = 1000
    user_tier: str = "standard"  # standard, premium, enterprise
    current_cost_today: float = 0.0


class SmartLLMSelector:
    """상황별 최적 LLM 모델 선택기"""
    
    def __init__(self, llm_manager: Optional[FORGELLMManager] = None):
        self.llm_manager = llm_manager or FORGELLMManager()
        self.usage_history: List[Dict] = []
        self.daily_costs = {
            "gemini.flash_lite": 0.0,
            "gemini.flash": 0.0,
            "gemini.pro": 0.0
        }
        
    def select_optimal_model(self, context: TaskContext) -> Tuple[str, Dict[str, Any]]:
        """
        작업 컨텍스트에 따라 최적 모델 선택
        
        Returns:
            (model_key, reasoning)
        """
        reasoning = {
            "task_type": context.task_type,
            "urgency": context.urgency.value,
            "complexity": context.complexity.value,
            "estimated_tokens": context.estimated_tokens
        }
        
        # 1. 긴급도 기반 선택
        if context.urgency == Urgency.IMMEDIATE:
            model = "gemini.flash_lite"
            reasoning["decision"] = "Immediate response required"
            
        # 2. 복잡도 기반 선택
        elif context.complexity == Complexity.COMPLEX:
            model = "gemini.pro"
            reasoning["decision"] = "Complex task requires high quality"
            
        # 3. 토큰 기반 선택
        elif context.estimated_tokens > 8000:
            model = "gemini.pro"  # Pro는 32k 토큰 지원
            reasoning["decision"] = "Large token requirement"
            
        # 4. 작업 타입별 기본 매핑 사용
        else:
            model_key = self.llm_manager.config['task_model_mapping'].get(
                context.task_type, 
                "gemini.flash"
            )
            model = model_key
            reasoning["decision"] = f"Default mapping for {context.task_type}"
        
        # 5. 비용 체크 및 다운그레이드
        if self._should_downgrade_for_cost(model, context):
            original = model
            model = self._get_cost_effective_alternative(model)
            reasoning["cost_optimization"] = f"Downgraded from {original} to {model}"
        
        reasoning["selected_model"] = model
        return model, reasoning
    
    def _should_downgrade_for_cost(self, model: str, context: TaskContext) -> bool:
        """비용 제한 확인"""
        if context.user_tier == "enterprise":
            return False  # 엔터프라이즈는 제한 없음
            
        daily_limit = {
            "gemini.flash_lite": 10000,
            "gemini.flash": 5000,
            "gemini.pro": 1000
        }
        
        # 현재 사용량 체크
        model_usage = len([h for h in self.usage_history if h['model'] == model])
        
        return model_usage >= daily_limit.get(model, 1000)
    
    def _get_cost_effective_alternative(self, model: str) -> str:
        """비용 효율적인 대안 모델"""
        downgrades = {
            "gemini.pro": "gemini.flash",
            "gemini.flash": "gemini.flash_lite",
            "gemini.flash_lite": "gemini.flash_lite"  # 최소 모델
        }
        return downgrades.get(model, "gemini.flash")
    
    async def execute_with_optimal_model(
        self, 
        task_type: str,
        prompt: str,
        urgency: Urgency = Urgency.FAST,
        complexity: Complexity = Complexity.MEDIUM
    ) -> Dict[str, Any]:
        """최적 모델로 작업 실행"""
        
        # 토큰 추정 (간단한 휴리스틱)
        estimated_tokens = len(prompt.split()) * 1.5
        
        context = TaskContext(
            task_type=task_type,
            urgency=urgency,
            complexity=complexity,
            estimated_tokens=int(estimated_tokens)
        )
        
        # 모델 선택
        model_key, reasoning = self.select_optimal_model(context)
        
        # 실행 시간 측정
        start_time = time.time()
        
        # LLM 실행
        llm = await self.llm_manager.get_llm_for_task(task_type)
        result = await llm.generate(prompt)
        
        execution_time = time.time() - start_time
        
        # 사용 기록
        self.usage_history.append({
            "timestamp": time.time(),
            "task_type": task_type,
            "model": model_key,
            "tokens": estimated_tokens,
            "execution_time": execution_time,
            "reasoning": reasoning
        })
        
        return {
            "result": result,
            "model_used": model_key,
            "execution_time": execution_time,
            "reasoning": reasoning
        }
    
    def get_pipeline_optimization(self) -> Dict[str, List[str]]:
        """파이프라인 최적화 제안"""
        return {
            "parallel_safe": [
                # 병렬 실행 가능한 작업들
                ["syntax_validation", "quick_health_check", "status_inquiry"],
                ["query_understanding", "requirement_analysis"],
                ["documentation_generation", "test_case_generation"]
            ],
            "sequential_required": [
                # 순차 실행 필요한 작업들
                "agent_rule_generation",
                "agent_code_generation",
                "agent_validation"
            ],
            "cost_optimization": {
                "batch_simple_tasks": "Use flash_lite for multiple simple tasks",
                "cache_expensive_results": "Cache pro model results for 2 hours",
                "downgrade_non_critical": "Use flash for non-critical paths"
            }
        }
    
    def estimate_pipeline_cost(self, tasks: List[Tuple[str, int]]) -> Dict[str, Any]:
        """파이프라인 비용 추정"""
        total_cost = 0.0
        model_usage = {"flash_lite": 0, "flash": 0, "pro": 0}
        
        for task_type, token_count in tasks:
            model_key = self.llm_manager.config['task_model_mapping'].get(
                task_type, 
                "gemini.flash"
            )
            
            # 모델별 비용 계산
            cost_per_1k = {
                "gemini.flash_lite": 0.0005,
                "gemini.flash": 0.001,
                "gemini.pro": 0.015
            }
            
            model_name = model_key.split('.')[1]
            cost = (token_count / 1000) * cost_per_1k.get(model_key, 0.001)
            total_cost += cost
            model_usage[model_name] = model_usage.get(model_name, 0) + 1
        
        return {
            "total_estimated_cost": f"${total_cost:.4f}",
            "model_usage": model_usage,
            "optimization_tips": self._get_cost_optimization_tips(model_usage)
        }
    
    def _get_cost_optimization_tips(self, model_usage: Dict) -> List[str]:
        """비용 최적화 팁"""
        tips = []
        
        if model_usage.get("pro", 0) > 3:
            tips.append("Consider caching Pro model results for repeated queries")
            
        if model_usage.get("flash", 0) > 10:
            tips.append("Batch Flash model calls for better efficiency")
            
        if model_usage.get("flash_lite", 0) < 5:
            tips.append("Use Flash Lite more for simple validations")
            
        return tips


# 파이프라인별 최적화된 실행 클래스
class OptimizedPipeline:
    """최적화된 에이전트 생성 파이프라인"""
    
    def __init__(self, selector: SmartLLMSelector):
        self.selector = selector
        
    async def run_agent_creation_pipeline(self, query: str) -> Dict[str, Any]:
        """최적화된 에이전트 생성 파이프라인 실행"""
        
        results = {}
        total_start = time.time()
        
        # 1단계: 병렬 처리 가능한 초기 분석
        parallel_tasks = await asyncio.gather(
            self.selector.execute_with_optimal_model(
                "syntax_validation", 
                f"Validate syntax: {query}",
                Urgency.IMMEDIATE,
                Complexity.SIMPLE
            ),
            self.selector.execute_with_optimal_model(
                "query_understanding",
                f"Analyze query: {query}",
                Urgency.FAST,
                Complexity.MEDIUM
            ),
            return_exceptions=True
        )
        
        results["validation"] = parallel_tasks[0]
        results["analysis"] = parallel_tasks[1]
        
        # 2단계: 핵심 생성 작업 (순차적)
        if results["analysis"].get("result"):
            # 룰 생성 (고품질)
            results["rules"] = await self.selector.execute_with_optimal_model(
                "agent_rule_generation",
                f"Generate rules based on: {results['analysis']['result']}",
                Urgency.QUALITY,
                Complexity.COMPLEX
            )
            
            # 코드 생성 (고품질)
            results["code"] = await self.selector.execute_with_optimal_model(
                "agent_code_generation",
                f"Generate code with rules: {results['rules']['result']}",
                Urgency.QUALITY,
                Complexity.COMPLEX
            )
        
        # 3단계: 병렬 검증 및 문서화
        final_tasks = await asyncio.gather(
            self.selector.execute_with_optimal_model(
                "agent_validation",
                f"Validate agent: {results.get('code', {}).get('result', '')}",
                Urgency.FAST,
                Complexity.MEDIUM
            ),
            self.selector.execute_with_optimal_model(
                "documentation_generation",
                f"Generate docs for: {query}",
                Urgency.FAST,
                Complexity.MEDIUM
            ),
            return_exceptions=True
        )
        
        results["validation_final"] = final_tasks[0]
        results["documentation"] = final_tasks[1]
        
        # 전체 실행 시간
        total_time = time.time() - total_start
        
        # 비용 분석
        tasks_for_cost = [
            ("syntax_validation", 100),
            ("query_understanding", 500),
            ("agent_rule_generation", 2000),
            ("agent_code_generation", 3000),
            ("agent_validation", 1000),
            ("documentation_generation", 1500)
        ]
        
        cost_analysis = self.selector.estimate_pipeline_cost(tasks_for_cost)
        
        return {
            "results": results,
            "total_execution_time": f"{total_time:.2f}s",
            "cost_analysis": cost_analysis,
            "models_used": {
                step: result.get("model_used", "unknown") 
                for step, result in results.items()
            }
        }