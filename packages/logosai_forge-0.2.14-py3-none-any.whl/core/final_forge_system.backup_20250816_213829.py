"""
FORGE AI - 최종 통합 시스템
===========================
효율적이고 에러 없는 에이전트 자동 생성 시스템

핵심 개선사항:
1. 단일 생성기로 통합
2. 템플릿 없이 직접 코드 생성
3. 독립형 실행 가능 코드
4. 완벽한 에러 처리
5. 실시간 검증
"""

import asyncio
import json
import uuid
import re
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Error Collector 임포트
try:
    from .error_collector import error_collector, ForgeError, TemplateError, ValidationError
except ImportError:
    # Fallback if error_collector is not available
    error_collector = None
    ForgeError = Exception
    TemplateError = Exception
    ValidationError = Exception

# Template Matcher Service 임포트
try:
    from .template_matcher import TemplateMatcherService
except ImportError:
    logger.warning("TemplateMatcherService not available - using default template")
    TemplateMatcherService = None


@dataclass
class ForgeRequest:
    """FORGE 요청 구조"""
    query: str
    user_email: str = "default@forge.ai"
    session_id: Optional[str] = None
    output_type: str = "standalone"  # standalone, logosai
    enable_testing: bool = True
    save_to_file: bool = True


@dataclass
class ForgeResult:
    """FORGE 결과 구조"""
    success: bool
    agent_code: str
    metadata: Dict[str, Any]
    test_results: Optional[Dict[str, Any]] = None
    file_path: Optional[str] = None
    error: Optional[str] = None


class FinalForgeSystem:
    """최종 FORGE AI 시스템"""
    
    def __init__(self):
        """초기화"""
        self.output_dir = Path("forge/agents/generated")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Template Matcher Service 초기화
        if TemplateMatcherService:
            try:
                self.template_matcher = TemplateMatcherService()
                logger.info("✅ TemplateMatcherService 초기화 완료")
            except Exception as e:
                logger.warning(f"TemplateMatcherService 초기화 실패: {e}")
                self.template_matcher = None
        else:
            self.template_matcher = None
        
        # 에이전트 타입 매핑
        self.agent_types = {
            "calculator": ("계산기", ["계산", "더하기", "빼기", "곱하기", "나누기", "calculator"]),
            "data_analysis": ("데이터 분석", ["데이터", "분석", "csv", "excel", "통계", "차트"]),
            "api_integration": ("API 통합", ["api", "rest", "endpoint", "서비스", "요청"]),
            "web_scraping": ("웹 스크래핑", ["웹", "크롤링", "스크래핑", "수집", "파싱"]),
            "automation": ("자동화", ["자동", "스케줄", "반복", "작업", "프로세스"]),
            "document_processing": ("문서 처리", ["문서", "텍스트", "파일", "pdf", "워드"]),
            "chatbot": ("챗봇", ["챗봇", "대화", "응답", "질문", "답변"]),
            "monitoring": ("모니터링", ["모니터링", "감시", "알림", "상태", "체크"]),
            "news_aggregator": ("뉴스 수집", ["뉴스", "news", "기사", "언론", "RSS"]),
            "sentiment_analyzer": ("감정 분석", ["감정", "sentiment", "긍정", "부정", "분석"]),
            "time_series": ("시계열 예측", ["시계열", "예측", "forecast", "트렌드"])
        }
        
        logger.info("🚀 FinalForgeSystem 초기화 완료")
    
    async def create_agent(self, request) -> ForgeResult:
        """에이전트 생성 메인 함수"""
        try:
            # Handle both string and ForgeRequest types
            if isinstance(request, str):
                # Create ForgeRequest from string
                from dataclasses import dataclass
                @dataclass
                class ForgeRequest:
                    query: str
                    user_email: str = "default@forge.ai"
                    session_id: Optional[str] = None
                    output_type: str = "logosai"  # Change default to logosai
                    enable_testing: bool = True
                    save_to_file: bool = True
                request = ForgeRequest(query=request)
                
            logger.info(f"📋 에이전트 생성 시작: {request.query}")
            
            # 1. 요청 분석
            analysis = self._analyze_request(request.query)
            logger.info(f"✅ 요청 분석 완료: {analysis['agent_type']}")
            
            # 2. 코드 생성
            if request.output_type == "standalone":
                agent_code = self._generate_standalone_code(analysis)
            else:
                agent_code = self._generate_logosai_code(analysis)
            logger.info(f"✅ 코드 생성 완료: {len(agent_code)} 문자")
            
            # 3. 메타데이터 생성
            metadata = self._generate_metadata(analysis, request)
            
            # 4. 코드 검증
            validation_result = self._validate_code(agent_code)
            if not validation_result["valid"]:
                # 디버깅을 위해 에러 코드 저장
                self._last_generated_code = agent_code
                raise ValueError(f"코드 검증 실패: {validation_result['errors']}")
            logger.info("✅ 코드 검증 통과")
            
            # 5. 파일 저장 (옵션)
            file_path = None
            if request.save_to_file:
                file_path = self._save_agent(agent_code, metadata)
                logger.info(f"✅ 파일 저장 완료: {file_path}")
            
            # 6. 테스트 실행 (옵션)
            test_results = None
            if request.enable_testing:
                test_results = await self._test_agent(agent_code, analysis)
                logger.info(f"✅ 테스트 완료: {test_results['status']}")
            
            return ForgeResult(
                success=True,
                agent_code=agent_code,
                metadata=metadata,
                test_results=test_results,
                file_path=file_path
            )
            
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"❌ 에이전트 생성 실패: {e}")
            logger.error(f"📍 에러 상세:\n{error_trace}")
            
            # 에러 수집
            if error_collector:
                error_context = {
                    "request": {
                        "query": request.query,
                        "output_type": request.output_type
                    },
                    "analysis": analysis if 'analysis' in locals() else None,
                    "stage": "create_agent"
                }
                error_id = error_collector.collect(e, error_context)
                logger.info(f"📝 Error collected: {error_id}")
            
            # 에러 타입별 구체적 메시지
            error_message = str(e)
            if "API" in error_message or "api" in error_message:
                error_detail = f"AI API 호출 실패: {error_message}"
            elif "timeout" in error_message.lower():
                error_detail = f"처리 시간 초과: {error_message}"
            elif "validation" in error_message.lower():
                error_detail = f"코드 검증 실패: {error_message}"
            elif "syntax" in error_message.lower():
                error_detail = f"문법 오류: {error_message}"
            else:
                error_detail = f"생성 중 오류: {error_message}"
            
            return ForgeResult(
                success=False,
                agent_code="",
                metadata={
                    "error_type": type(e).__name__,
                    "error_detail": error_detail,
                    "error_trace": error_trace[:500]  # 처음 500자만
                },
                error=str(e)
            )
    
    def _analyze_request(self, query: str) -> Dict[str, Any]:
        """요청 분석 - 더 정교한 분석"""
        query_lower = query.lower()
        
        # 에이전트 타입 감지
        agent_type = "general"
        confidence = 0.0
        
        for type_key, (type_name, keywords) in self.agent_types.items():
            matches = sum(1 for keyword in keywords if keyword in query_lower)
            match_ratio = matches / len(keywords)
            
            if match_ratio > confidence:
                confidence = match_ratio
                agent_type = type_key
        
        # 에이전트 이름 생성
        if agent_type == "general":
            agent_name = "CustomAgent"
        else:
            agent_name = f"{agent_type.title().replace('_', '')}Agent"
        
        # 주요 기능 추출
        features = []
        if "실시간" in query_lower:
            features.append("realtime")
        if "데이터베이스" in query_lower or "db" in query_lower:
            features.append("database")
        if "시각화" in query_lower or "차트" in query_lower:
            features.append("visualization")
        if "머신러닝" in query_lower or "ml" in query_lower:
            features.append("machine_learning")
        
        return {
            "agent_type": agent_type,
            "agent_name": agent_name,
            "description": query,
            "original_query": query,  # 원본 쿼리 저장 (템플릿 매칭용)
            "confidence": confidence,
            "features": features,
            "complexity": self._assess_complexity(query, features)
        }
    
    def _assess_complexity(self, query: str, features: List[str]) -> str:
        """복잡도 평가"""
        complexity_score = len(features)
        
        if len(query) > 100:
            complexity_score += 1
        if any(word in query.lower() for word in ["복잡한", "고급", "전문", "통합"]):
            complexity_score += 2
        
        if complexity_score >= 4:
            return "high"
        elif complexity_score >= 2:
            return "medium"
        else:
            return "low"
    
    def _generate_standalone_code(self, analysis: Dict[str, Any]) -> str:
        """독립형 실행 가능한 코드 생성"""
        
        agent_name = analysis["agent_name"]
        description = analysis["description"]
        agent_type = analysis["agent_type"]
        features = analysis["features"]
        
        # 옵션 1과 2 적용: 설명 텍스트 안전하게 처리
        # 옵션 2: 줄바꿈 이스케이프 처리
        escaped_description = description.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
        
        # 옵션 1: 여러 줄 텍스트를 위한 삼중 따옴표 사용 여부 결정
        if '\n' in description and len(description) > 200:
            # 긴 여러 줄 텍스트는 docstring으로 처리
            description_str = '"""' + description.replace('"""', '\\"\\"\\"') + '"""'
        else:
            # 짧은 텍스트는 일반 문자열로 처리
            description_str = '"' + escaped_description + '"'
        
        # 기능별 import 추가
        imports = self._get_imports(agent_type, features)
        
        # 핵심 로직 생성
        core_logic = self._get_advanced_core_logic(agent_type, features)
        
        # 헬퍼 메서드들
        helper_methods = self._get_helper_methods(agent_type, features)
        
        code = f'''#!/usr/bin/env python3
"""
{agent_name} - Advanced Standalone Agent
{'='*40}
{description}

생성일: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
타입: {agent_type}
복잡도: {analysis["complexity"]}
기능: {", ".join(features) if features else "기본"}
"""

{imports}


class {agent_name}:
    """에이전트 클래스"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """에이전트 초기화"""
        self.name = "{agent_name}"
        self.description = {description_str}
        self.agent_type = "{agent_type}"
        self.config = config or {{}}
        self.logger = logging.getLogger(self.name)
        
        # 초기화
        self._initialize()
        self.logger.info(f"{{self.name}} 초기화 완료")
    
    def _initialize(self):
        """리소스 초기화"""
        # 에이전트별 초기화 로직
        pass
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """쿼리 처리 - 메인 함수"""
        try:
            self.logger.info(f"쿼리 처리 시작: {{query[:50]}}...")
            
            # 입력 검증
            if not query:
                return self._error_response("빈 쿼리입니다")
            
            # 컨텍스트 초기화
            if context is None:
                context = {{}}
            
            # 쿼리 전처리
            processed_query = self._preprocess_query(query)
            
{core_logic}
            
        except Exception as e:
            self.logger.error(f"처리 중 오류 발생: {{e}}", exc_info=True)
            return self._error_response(str(e))
    
{helper_methods}
    
    def _preprocess_query(self, query: str) -> str:
        """쿼리 전처리"""
        # 기본 정규화
        query = query.strip()
        # 추가 전처리 로직
        return query
    
    def _error_response(self, error_msg: str) -> Dict[str, Any]:
        """에러 응답 생성"""
        return {{
            "status": "error",
            "error": error_msg,
            "timestamp": datetime.now().isoformat()
        }}
    
    def _success_response(self, data: Any, message: str = "성공") -> Dict[str, Any]:
        """성공 응답 생성"""
        return {{
            "status": "success",
            "data": data,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }}
    
    def get_info(self) -> Dict[str, Any]:
        """에이전트 정보"""
        return {{
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "version": "1.0.0",
            "capabilities": self._get_capabilities(),
            "config": self.config
        }}
    
    def _get_capabilities(self) -> List[str]:
        """에이전트 기능 목록"""
        base_capabilities = {{
            "calculator": ["arithmetic", "expression_evaluation", "unit_conversion"],
            "data_analysis": ["statistics", "visualization", "trend_analysis", "reporting"],
            "api_integration": ["rest_api", "authentication", "data_sync", "webhooks"],
            "web_scraping": ["html_parsing", "dynamic_content", "data_extraction", "automation"],
            "automation": ["scheduling", "workflow", "monitoring", "alerts"],
            "document_processing": ["text_extraction", "format_conversion", "nlp", "search"],
            "chatbot": ["conversation", "context_management", "nlp", "response_generation"],
            "monitoring": ["health_check", "metrics", "alerts", "reporting"]
        }}
        
        return base_capabilities.get(self.agent_type, ["general_processing"])


# 테스트 함수
async def test_agent():
    """에이전트 테스트"""
    agent = {agent_name}()
    
    print(f"\\n{'='*60}")
    print(f"{{agent.name}} 테스트")
    print('='*60)
    info = agent.get_info()
    print(f"설명: {{info['description']}}")
    print(f"타입: {{info['agent_type']}}")
    print(f"기능: {{', '.join(info['capabilities'])}}")
    print('='*60)
    
    # 테스트 쿼리
    test_queries = {self._get_test_queries(agent_type)}
    
    for query in test_queries:
        print(f"\\n쿼리: {{query}}")
        result = await agent.process(query)
        print(f"결과: {{json.dumps(result, ensure_ascii=False, indent=2)}}")
    
    print(f"\\n{'='*60}")
    print("✅ 테스트 완료!")


if __name__ == "__main__":
    # 로깅 설정
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # 테스트 실행
    asyncio.run(test_agent())
'''
        
        return code
    
    def _get_imports(self, agent_type: str, features: List[str]) -> str:
        """필요한 import 문 생성"""
        base_imports = """import asyncio
import json
import logging
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
import re"""
        
        additional_imports = []
        
        # 에이전트 타입별 imports
        if agent_type == "data_analysis":
            additional_imports.extend([
                "import pandas as pd",
                "import numpy as np"
            ])
            if "visualization" in features:
                additional_imports.append("import matplotlib.pyplot as plt")
        
        elif agent_type == "api_integration":
            additional_imports.extend([
                "import aiohttp",
                "import asyncio"
            ])
        
        elif agent_type == "web_scraping":
            additional_imports.extend([
                "from bs4 import BeautifulSoup",
                "import aiohttp"
            ])
        
        if "database" in features:
            additional_imports.append("import sqlite3")
        
        if "machine_learning" in features:
            additional_imports.append("from sklearn import preprocessing, model_selection")
        
        return base_imports + "\n" + "\n".join(additional_imports) if additional_imports else base_imports
    
    def _get_advanced_core_logic(self, agent_type: str, features: List[str]) -> str:
        """고급 핵심 로직 생성"""
        
        logic_map = {
            "calculator": self._get_calculator_logic(),
            "data_analysis": self._get_data_analysis_logic(features),
            "api_integration": self._get_api_logic(features),
            "web_scraping": self._get_scraping_logic(features),
            "automation": self._get_automation_logic(features),
            "document_processing": self._get_document_logic(features),
            "chatbot": self._get_chatbot_logic(features),
            "monitoring": self._get_monitoring_logic(features)
        }
        
        return logic_map.get(agent_type, self._get_general_logic())
    
    def _get_calculator_logic(self) -> str:
        """계산기 로직"""
        return '''            # 계산기 핵심 로직
            try:
                # 수식 파싱
                expression = self._parse_expression(processed_query)
                
                # 계산 수행
                result = self._calculate(expression)
                
                # 단위 변환 (있는 경우)
                if "단위" in context:
                    result = self._convert_units(result, context["단위"])
                
                return self._success_response({
                    "result": result,
                    "expression": expression,
                    "formatted": self._format_result(result)
                })
                
            except Exception as e:
                return self._error_response(f"계산 오류: {str(e)}")'''
    
    def _get_data_analysis_logic(self, features: List[str]) -> str:
        """데이터 분석 로직"""
        visualization = "visualization" in features
        
        return f'''            # 데이터 분석 핵심 로직
            try:
                # 데이터 로드
                data = await self._load_data(context.get("data_source"))
                
                # 데이터 전처리
                cleaned_data = self._preprocess_data(data)
                
                # 분석 수행
                analysis_results = await self._perform_analysis(cleaned_data, processed_query)
                
                # 통계 생성
                statistics = self._generate_statistics(cleaned_data)
                
                {"# 시각화" if visualization else ""}
                {"visualizations = self._create_visualizations(cleaned_data, analysis_results)" if visualization else ""}
                
                return self._success_response({{
                    "analysis": analysis_results,
                    "statistics": statistics,
                    {"'visualizations': visualizations," if visualization else ""}
                    "summary": self._generate_summary(analysis_results)
                }})
                
            except Exception as e:
                return self._error_response(f"분석 오류: {{str(e)}}")'''
    
    def _get_api_logic(self, features: List[str]) -> str:
        """API 통합 로직"""
        return '''            # API 통합 핵심 로직
            try:
                # API 설정
                api_config = self._prepare_api_config(context)
                
                # 인증 처리
                auth_headers = await self._handle_authentication(api_config)
                
                # API 호출
                response = await self._make_api_request(
                    api_config["url"],
                    api_config.get("method", "GET"),
                    headers=auth_headers,
                    data=api_config.get("data")
                )
                
                # 응답 처리
                processed_response = self._process_api_response(response)
                
                # 데이터 변환
                transformed_data = self._transform_data(processed_response)
                
                return self._success_response({
                    "data": transformed_data,
                    "status_code": response.get("status_code"),
                    "headers": response.get("headers")
                })
                
            except Exception as e:
                return self._error_response(f"API 오류: {str(e)}")'''
    
    def _get_general_logic(self) -> str:
        """범용 로직"""
        return '''            # 범용 처리 로직
            try:
                # 작업 분류
                task_type = self._classify_task(processed_query)
                
                # 작업별 처리
                if task_type == "information":
                    result = await self._process_information_request(processed_query, context)
                elif task_type == "action":
                    result = await self._process_action_request(processed_query, context)
                else:
                    result = await self._process_general_request(processed_query, context)
                
                return self._success_response(result)
                
            except Exception as e:
                return self._error_response(f"처리 오류: {str(e)}")'''
    
    def _get_helper_methods(self, agent_type: str, features: List[str]) -> str:
        """헬퍼 메서드 생성"""
        
        if agent_type == "calculator":
            return '''    def _parse_expression(self, query: str) -> str:
        """수식 파싱"""
        # 한글 연산자를 기호로 변환
        query = query.replace("더하기", "+").replace("빼기", "-")
        query = query.replace("곱하기", "*").replace("나누기", "/")
        
        # 숫자와 연산자 추출
        pattern = r'[\d\.\+\-\*\/\(\)\s]+'
        matches = re.findall(pattern, query)
        
        return "".join(matches).strip()
    
    def _calculate(self, expression: str) -> float:
        """안전한 계산 수행"""
        # eval 대신 안전한 파서 사용
        try:
            # 간단한 검증
            if not re.match(r'^[\d\.\+\-\*\/\(\)\s]+$', expression):
                raise ValueError("유효하지 않은 수식")
            
            # 계산 (실제로는 더 안전한 방법 사용 권장)
            result = eval(expression)
            return float(result)
        except:
            raise ValueError("계산할 수 없는 수식입니다")
    
    def _format_result(self, result: float) -> str:
        """결과 포맷팅"""
        if result.is_integer():
            return str(int(result))
        else:
            return f"{result:.2f}"'''
        
        elif agent_type == "data_analysis":
            return '''    async def _load_data(self, data_source: Any) -> Any:
        """데이터 로드"""
        if data_source is None:
            # 샘플 데이터 생성
            import pandas as pd
            return pd.DataFrame({
                'date': pd.date_range('2024-01-01', periods=100),
                'value': np.random.randn(100).cumsum() + 100,
                'category': np.random.choice(['A', 'B', 'C'], 100)
            })
        elif isinstance(data_source, str) and data_source.endswith('.csv'):
            return pd.read_csv(data_source)
        else:
            return data_source
    
    def _preprocess_data(self, data: Any) -> Any:
        """데이터 전처리"""
        if hasattr(data, 'dropna'):
            data = data.dropna()
        return data
    
    async def _perform_analysis(self, data: Any, query: str) -> Dict[str, Any]:
        """분석 수행"""
        results = {}
        
        if hasattr(data, 'describe'):
            results['summary'] = data.describe().to_dict()
        
        if hasattr(data, 'corr'):
            results['correlation'] = data.select_dtypes(include=[np.number]).corr().to_dict()
        
        return results
    
    def _generate_statistics(self, data: Any) -> Dict[str, Any]:
        """통계 생성"""
        stats = {}
        
        if hasattr(data, 'shape'):
            stats['shape'] = data.shape
            stats['columns'] = list(data.columns) if hasattr(data, 'columns') else []
        
        return stats
    
    def _generate_summary(self, analysis: Dict[str, Any]) -> str:
        """요약 생성"""
        summary_parts = []
        
        if 'summary' in analysis:
            summary_parts.append("데이터 통계 분석이 완료되었습니다.")
        
        if 'correlation' in analysis:
            summary_parts.append("상관관계 분석이 포함되었습니다.")
        
        return " ".join(summary_parts)'''
        
        else:
            return '''    def _classify_task(self, query: str) -> str:
        """작업 분류"""
        query_lower = query.lower()
        
        if any(word in query_lower for word in ["정보", "알려", "무엇", "어떻게"]):
            return "information"
        elif any(word in query_lower for word in ["실행", "처리", "만들어", "생성"]):
            return "action"
        else:
            return "general"
    
    async def _process_information_request(self, query: str, context: Dict) -> Dict[str, Any]:
        """정보 요청 처리"""
        return {
            "type": "information",
            "query": query,
            "response": "요청하신 정보를 처리했습니다."
        }
    
    async def _process_action_request(self, query: str, context: Dict) -> Dict[str, Any]:
        """작업 요청 처리"""
        return {
            "type": "action",
            "query": query,
            "status": "completed",
            "result": "작업이 완료되었습니다."
        }
    
    async def _process_general_request(self, query: str, context: Dict) -> Dict[str, Any]:
        """일반 요청 처리"""
        return {
            "type": "general",
            "query": query,
            "processed": True
        }'''
    
    def _get_test_queries(self, agent_type: str) -> str:
        """테스트 쿼리 생성"""
        queries_map = {
            "calculator": '["10 더하기 5는?", "100에서 25를 빼면?", "(7 * 8) + 10은?"]',
            "data_analysis": '["데이터를 분석해줘", "통계 요약을 보여줘", "트렌드를 찾아줘"]',
            "api_integration": '["API 데이터를 가져와줘", "서버 상태 확인", "데이터 동기화"]',
            "web_scraping": '["웹페이지 데이터 수집", "링크 추출해줘", "콘텐츠 파싱"]',
            "automation": '["작업을 자동화해줘", "스케줄 설정", "프로세스 실행"]',
            "document_processing": '["문서를 분석해줘", "텍스트 추출", "형식 변환"]',
            "chatbot": '["안녕하세요", "도움이 필요해요", "정보를 찾아줘"]',
            "monitoring": '["시스템 상태 확인", "성능 모니터링", "알림 설정"]'
        }
        
        return queries_map.get(agent_type, '["테스트 쿼리 1", "테스트 쿼리 2"]')
    
    def _get_scraping_logic(self, features: List[str]) -> str:
        """웹 스크래핑 로직"""
        return '''            # 웹 스크래핑 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "웹 스크래핑 기능"})'''
    
    def _get_automation_logic(self, features: List[str]) -> str:
        """자동화 로직"""
        return '''            # 자동화 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "자동화 기능"})'''
    
    def _get_document_logic(self, features: List[str]) -> str:
        """문서 처리 로직"""
        return '''            # 문서 처리 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "문서 처리 기능"})'''
    
    def _get_chatbot_logic(self, features: List[str]) -> str:
        """챗봇 로직"""
        return '''            # 챗봇 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "챗봇 응답"})'''
    
    def _get_monitoring_logic(self, features: List[str]) -> str:
        """모니터링 로직"""
        return '''            # 모니터링 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "모니터링 기능"})'''
    
    def _generate_logosai_code(self, analysis: Dict[str, Any]) -> str:
        """LogosAI 프레임워크 기반 코드 생성 - 템플릿 활용"""
        from pathlib import Path  # Use Path instead of os for security
        
        # 템플릿 매칭 시도 (specialized 템플릿 우선)
        template_path = None
        template_info = None
        
        if self.template_matcher:
            try:
                # 원본 쿼리를 사용하여 최적의 템플릿 찾기
                query = analysis.get("original_query", analysis.get("description", ""))
                
                # Since match_template is async and we're in a sync context,
                # we'll use a simpler keyword-based matching for now
                template_id = None
                score = 0.0
                
                # Simple keyword matching fallback
                query_lower = query.lower()
                for tid, tmeta in self.template_matcher.templates_metadata.items():
                    keywords = tmeta.get("keywords", [])
                    matches = sum(1 for kw in keywords if kw.lower() in query_lower)
                    if matches > 0:
                        current_score = matches / len(keywords) if keywords else 0
                        if current_score > score:
                            template_id = tid
                            score = current_score
                # Convert to expected format
                template_info = {
                    "path": self.template_matcher.templates_metadata.get(template_id, {}).get("path"),
                    "template_id": template_id,
                    "score": score
                } if template_id and score > 0.3 else None
                
                if template_info and template_info.get("path"):
                    # specialized 템플릿 경로 구성
                    template_path = Path(__file__).parent.parent / "templates" / template_info["path"]
                    if template_path.exists():
                        logger.info(f"🎯 특화 템플릿 선택: {template_info['path']} (점수: {template_info.get('score', 0):.2f})")
                    else:
                        logger.warning(f"⚠️ 특화 템플릿 파일이 없음: {template_path}")
                        template_path = None
            except Exception as e:
                logger.warning(f"템플릿 매칭 중 오류: {e}")
        
        # 기본 템플릿 폴백
        if not template_path:
            template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template.py.template"
            logger.info("📋 기본 템플릿 사용")
        
        # 템플릿 파일 읽기
        if template_path.exists():
            with open(template_path, 'r', encoding='utf-8') as f:
                template = f.read()
            logger.info(f"✅ 템플릿 파일 로드 완료: {template_path}")
        else:
            logger.warning(f"⚠️ 템플릿 파일이 없음. 기존 방식 사용: {template_path}")
            # 템플릿 파일이 없으면 기존 방식 사용
            return self._generate_logosai_code_legacy(analysis)
        
        agent_name = analysis["agent_name"]
        description = analysis["description"]
        agent_type = analysis["agent_type"]
        features = analysis["features"]
        
        # 에이전트 클래스 이름 생성
        agent_class_name = agent_name if agent_name.endswith('Agent') else f"{agent_name}Agent"
        
        # 타입별 커스텀 설정
        custom_config = self._get_custom_config_for_logosai(analysis)
        custom_init = self._get_custom_init_for_logosai(analysis)
        custom_async_init = self._get_custom_async_init_for_logosai(analysis)
        
        # 쿼리 추출 프롬프트 생성
        query_extraction_prompt = self._get_query_extraction_prompt(analysis)
        
        # 핵심 비즈니스 로직 생성
        core_business_logic = self._get_logosai_core_business_logic(analysis)
        
        # 응답 생성 프롬프트
        response_generation_prompt = self._get_response_generation_prompt(analysis)
        
        # 테스트 쿼리 생성
        test_queries = self._get_test_queries_for_logosai(analysis)
        
        # 샘플 데이터 코드 생성
        sample_data_code = self._get_sample_data_code_for_logosai(analysis)
        
        # 커스텀 클린업
        custom_cleanup = self._get_custom_cleanup_for_logosai(analysis)
        
        # 템플릿 변수 치환 (백틱 안전성 검사 포함)
        def safe_replace(text: str, placeholder: str, value: str, is_code: bool = False) -> str:
            """백틱 안전성 검사를 포함한 템플릿 치환
            
            Args:
                text: 템플릿 텍스트
                placeholder: 치환할 플레이스홀더
                value: 치환 값
                is_code: True면 Python 코드로 간주하여 이스케이프하지 않음
            """
            # 백틱 제거
            if '```' in str(value):
                logger.warning(f"⚠️ 템플릿 변수 '{placeholder}'에 백틱 패턴 발견, 제거 중")
                value = str(value).replace('```', '').replace('`', '')
            
            value_str = str(value)
            
            # Debug logging for description
            if placeholder == "{agent_description}":
                logger.info(f"🔍 Processing description: {repr(value_str[:50])}")
            
            # Python 코드가 아닌 경우에만 이스케이프
            if not is_code:
                # 여러 줄 문자열을 Python 문자열로 안전하게 이스케이프
                # description 같은 여러 줄 텍스트가 Python 코드에 들어갈 때 문법 오류 방지
                value_str = value_str.replace('\\', '\\\\')  # 백슬래시를 먼저 이스케이프
                value_str = value_str.replace('"', '\\"')    # 큰따옴표 이스케이프
                value_str = value_str.replace('\n', '\\n')   # 개행 문자를 \n으로
                value_str = value_str.replace('\r', '\\r')   # 캐리지 리턴을 \r로
                value_str = value_str.replace('\t', '\\t')   # 탭을 \t로
                
                if placeholder == "{agent_description}":
                    logger.info(f"🔍 After escaping: {repr(value_str[:80])}")
            
            return text.replace(placeholder, value_str)
        
        code = safe_replace(template, "{agent_class_name}", agent_class_name)
        code = safe_replace(code, "{agent_name}", agent_name)
        logger.info(f"DEBUG: description = {repr(description[:100])}")
        code = safe_replace(code, "{agent_description}", description)
        code = safe_replace(code, "{custom_config}", custom_config, is_code=True)  # Python code
        code = safe_replace(code, "{custom_init}", custom_init, is_code=True)  # Python code
        code = safe_replace(code, "{custom_async_init}", custom_async_init, is_code=True)  # Python code
        code = safe_replace(code, "{query_extraction_prompt}", query_extraction_prompt)
        code = safe_replace(code, "{core_business_logic}", core_business_logic, is_code=True)  # Python code
        code = safe_replace(code, "{response_generation_prompt}", response_generation_prompt)
        code = safe_replace(code, "{test_queries}", json.dumps(test_queries, ensure_ascii=False), is_code=True)  # Python code - JSON array
        code = safe_replace(code, "{sample_data_code}", sample_data_code, is_code=True)  # Python code
        code = safe_replace(code, "{custom_cleanup}", custom_cleanup, is_code=True)  # Python code
        
        # 템플릿에서 사용된 이중 중괄호를 단일 중괄호로 변환
        # {{와 }}는 템플릿에서 리터럴 중괄호를 나타내는 이스케이프 시퀀스
        code = code.replace("{{", "{")
        code = code.replace("}}", "}")
        
        # 백틱 제거 및 검증 로직 (포괄적 백틱 제거기 사용)
        from .backtick_sanitizer import sanitize_code_safe, is_code_safe_for_exec
        
        code = sanitize_code_safe(code, "final_forge_system")
        
        # 추가 안전성 검증
        if not is_code_safe_for_exec(code):
            logger.error("❌ exec() 안전성 검사 실패, 긴급 정리 실행")
            from .backtick_sanitizer import BacktickSanitizer
            code = BacktickSanitizer.emergency_cleanup(code)
        
        logger.info(f"✅ LogosAI 에이전트 코드 생성 완료: {agent_class_name}")
        logger.info(f"🔍 최종 코드 백틱 개수: {code.count('```')}")
        
        return code
    
    def _generate_logosai_code_legacy(self, analysis: Dict[str, Any]) -> str:
        """LogosAI 호환 코드 생성 (레거시 - 템플릿 없을 때)"""
        
        agent_name = analysis["agent_name"]
        description = analysis["description"]
        agent_type = analysis["agent_type"]
        features = analysis["features"]
        
        # LogosAI framework imports
        imports = '''import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from loguru import logger

# LogosAI framework imports
from logosai import (
    LogosAIAgent,
    AgentConfig,
    AgentType,
    AgentResponse,
    AgentResponseType
)
from logosai.llm import LLMClient'''
        
        # 에이전트 타입별 추가 imports
        if agent_type == "data_analysis":
            imports += "\nimport pandas as pd\nimport numpy as np"
        elif agent_type == "api_integration":
            imports += "\nimport aiohttp\nimport asyncio"
        elif agent_type == "web_scraping":
            imports += "\nfrom bs4 import BeautifulSoup\nimport aiohttp"
        
        # 핵심 비즈니스 로직 생성
        business_logic = self._get_logosai_business_logic(agent_type, features)
        
        # 헬퍼 메서드들
        helper_methods = self._get_logosai_helper_methods(agent_type, features)
        
        code = f'''"""
{agent_name} - LogosAI Framework Agent (Legacy)
{'='*40}
{description}

Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Type: {agent_type}
Framework: LogosAI
"""

{imports}


class {agent_name}(LogosAIAgent):
    """
    {description}
    
    This agent demonstrates:
    - Natural language query processing using LLM
    - Async/await pattern for all operations
    - Proper error handling and logging
    - LogosAI framework integration
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        """Initialize the agent with configuration."""
        if config is None:
            config = AgentConfig(
                name="{agent_name}",
                agent_type=AgentType.CUSTOM,
                description="{description}",
                config={{
                    "model": "gemini-2.5-flash-lite",
                    "temperature": 0.7,
                    "max_tokens": 15000  # 충분한 토큰으로 증가
                }}
            )
        
        super().__init__(config)
        
        # Initialize instance variables
        self.llm_client: Optional[LLMClient] = None
        self.is_initialized = False
        
        logger.info(f"{{self.name}} initialized with config: {{self.config}}")
    
    async def initialize(self) -> bool:
        """
        Async initialization for resources that require await.
        This is called after __init__ and before the agent starts processing.
        """
        try:
            # Initialize LLM client
            self.llm_client = LLMClient(
                model=self.config.config.get("model", "gemini-2.5-flash-lite"),
                temperature=self.config.config.get("temperature", 0.7),
                max_tokens=self.config.config.get("max_tokens", 15000)  # 기본값도 15000으로 증가
            )
            
            self.is_initialized = True
            logger.info(f"{{self.name}} initialization completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize {{self.name}}: {{str(e)}}")
            return False
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """
        Main processing method for the agent.
        
        Args:
            query: The user's query or request
            context: Optional context dictionary
            
        Returns:
            AgentResponse with appropriate type and content
        """
        try:
            # Ensure agent is initialized
            if not self.is_initialized:
                if not await self.initialize():
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={{"error": "Failed to initialize agent"}}
                    )
            
            logger.info(f"Processing query: {{query}}")
            
{business_logic}
            
        except Exception as e:
            logger.error(f"Error in {{self.name}}.process: {{str(e)}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e), "message": "처리 중 오류가 발생했습니다"}}
            )
    
{helper_methods}
    
    async def cleanup(self):
        """Clean up resources when agent is shutting down."""
        try:
            # Clean up any resources
            if hasattr(self, 'llm_client') and self.llm_client:
                # Close any open connections
                pass
            
            logger.info(f"{{self.name}} cleanup completed")
        except Exception as e:
            logger.error(f"Error during cleanup: {{str(e)}}")


# Example usage
if __name__ == "__main__":
    async def main():
        # Create agent
        agent = {agent_name}()
        
        # Initialize
        if await agent.initialize():
            # Test query
            response = await agent.process("테스트 쿼리")
            print(f"Response: {{response}}")
            
            # Cleanup
            await agent.cleanup()
    
    # Run the example
    asyncio.run(main())
'''
        
        return code
    
    def _get_logosai_business_logic(self, agent_type: str, features: List[str]) -> str:
        """LogosAI 에이전트용 비즈니스 로직 생성"""
        
        if agent_type == "calculator":
            return '''            # Extract calculation request using LLM
            if self.llm_client:
                prompt = f"Extract the mathematical expression from: {query}"
                extraction_result = await self.llm_client.generate(prompt)
                
                # Perform calculation
                try:
                    result = eval(extraction_result)  # In production, use safer eval
                    return AgentResponse(
                        type=AgentResponseType.SUCCESS,
                        content={"result": result, "expression": extraction_result}
                    )
                except Exception as calc_error:
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={"error": str(calc_error)}
                    )
            else:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": "LLM client not initialized"}
                )'''
                
        elif agent_type == "data_analysis":
            return '''            # Data analysis logic
            try:
                # Extract data requirements using LLM
                if self.llm_client:
                    analysis_prompt = f"Analyze the data request: {query}"
                    analysis_plan = await self.llm_client.generate(analysis_prompt)
                    
                    # Perform analysis (simplified)
                    result = {
                        "analysis": analysis_plan,
                        "status": "completed",
                        "timestamp": datetime.now().isoformat()
                    }
                    
                    return AgentResponse(
                        type=AgentResponseType.SUCCESS,
                        content=result
                    )
                else:
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={"error": "LLM client not initialized"}
                    )
            except Exception as analysis_error:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": str(analysis_error)}
                )'''
                
        elif agent_type == "api_integration":
            return '''            # API integration logic
            try:
                # Extract API request details using LLM
                if self.llm_client:
                    api_prompt = f"Extract API endpoint and parameters from: {query}"
                    api_details = await self.llm_client.generate(api_prompt)
                    
                    # Make API call (simplified)
                    async with aiohttp.ClientSession() as session:
                        # This is a placeholder - real implementation would parse api_details
                        response_data = {"status": "success", "message": "API call simulated"}
                    
                    return AgentResponse(
                        type=AgentResponseType.SUCCESS,
                        content=response_data
                    )
                else:
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={"error": "LLM client not initialized"}
                    )
            except Exception as api_error:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": str(api_error)}
                )'''
                
        else:
            # Default logic for other types
            return '''            # Process query using LLM
            if self.llm_client:
                # Generate response using LLM
                response_text = await self.llm_client.generate(f"Process this request: {query}")
                
                return AgentResponse(
                    type=AgentResponseType.SUCCESS,
                    content={"response": response_text, "query": query}
                )
            else:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": "LLM client not initialized"}
                )'''
    
    def _get_custom_config_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 커스텀 설정 생성"""
        agent_type = analysis.get('agent_type', 'general')
        config_items = []
        
        if agent_type == "data_analysis":
            config_items.append('"enable_visualization": True')
            config_items.append('"max_data_rows": 10000')
        elif agent_type == "api_integration":
            config_items.append('"timeout": 30')
            config_items.append('"retry_count": 3')
        elif agent_type == "web_scraping":
            config_items.append('"user_agent": "Mozilla/5.0"')
            config_items.append('"timeout": 20')
        
        # 항상 기본 설정 포함
        if not config_items:
            config_items.append('"timeout": 60')
            config_items.append('"retry_attempts": 3')
        
        # 쉼표로 시작하지 않도록 수정
        return ",\n                    " + ",\n                    ".join(config_items)
    
    def _get_custom_init_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 커스텀 초기화 코드"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type == "data_analysis":
            return """
        self.data_cache = {}
        self.analysis_history = []"""
        elif agent_type == "api_integration":
            return """
        self.api_cache = {}
        self.rate_limiter = None"""
        elif agent_type == "web_scraping":
            return """
        self.session = None
        self.scraped_data = []"""
        
        return """
        # Custom initialization"""
    
    def _get_custom_async_init_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 비동기 초기화 코드"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type == "api_integration":
            return """# Initialize HTTP session
            import aiohttp
            self.session = aiohttp.ClientSession()"""
        elif agent_type == "web_scraping":
            return """# Initialize web scraping session
            import aiohttp
            self.session = aiohttp.ClientSession()"""
        
        return "# Additional async initialization"
    
    def _get_query_extraction_prompt(self, analysis: Dict[str, Any]) -> str:
        """쿼리 추출 프롬프트 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        prompts = {
            "calculator": "Extract the mathematical expression and numbers from the query.",
            "data_analysis": "Extract the data source, analysis type, and filters from the query.",
            "api_integration": "Extract the API endpoint, method, parameters, and authentication details.",
            "web_scraping": "Extract the target URL, data to scrape, and any filters.",
            "automation": "Extract the task to automate, schedule, and conditions.",
            "document_processing": "Extract the document type, processing requirements, and output format.",
            "chatbot": "Extract the user intent, context, and required response type.",
            "monitoring": "Extract the metrics to monitor, thresholds, and alert conditions."
        }
        
        return prompts.get(agent_type, "Extract the key information and requirements from the query.")
    
    def _get_logosai_core_business_logic(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 핵심 비즈니스 로직 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        logic_templates = {
            "calculator": """# 계산 수행
            if 'expression' in extracted_info:
                try:
                    # 안전한 계산 수행 (실제로는 더 안전한 방법 사용)
                    result = eval(extracted_info['expression'])
                    return {{"data": {{"result": result, "expression": extracted_info['expression']}}}}
                except Exception as e:
                    raise ValueError(f"계산 오류: {{str(e)}}")
            else:
                raise ValueError("수식을 찾을 수 없습니다")""",
            
            "data_analysis": """# 데이터 분석 수행
            import pandas as pd
            import numpy as np
            
            # 샘플 데이터 생성 또는 로드
            if 'data_source' in extracted_info:
                # 실제 데이터 로드 로직
                data = pd.DataFrame()  # Placeholder
            else:
                # 샘플 데이터 생성
                data = pd.DataFrame({{
                    'date': pd.date_range('2024-01-01', periods=100),
                    'value': np.random.randn(100).cumsum() + 100,
                    'category': np.random.choice(['A', 'B', 'C'], 100)
                }})
            
            # 분석 수행
            analysis_results = {{
                "summary": data.describe().to_dict(),
                "shape": data.shape,
                "columns": list(data.columns)
            }}
            
            return {{"data": analysis_results}}""",
            
            "api_integration": """# API 호출 수행
            api_url = extracted_info.get('url', 'https://api.example.com/data')
            method = extracted_info.get('method', 'GET')
            
            # 실제 API 호출 (샘플)
            api_response = {{
                "status": "success",
                "data": {{"sample": "response"}},
                "timestamp": datetime.now().isoformat()
            }}
            
            return {{"data": api_response}}"""
        }
        
        return logic_templates.get(agent_type, 
            """# 범용 처리 로직
            result = {{
                "processed": True,
                "info": extracted_info,
                "timestamp": datetime.now().isoformat()
            }}
            return {{"data": result}}""")
    
    def _get_response_generation_prompt(self, analysis: Dict[str, Any]) -> str:
        """응답 생성 프롬프트 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        prompts = {
            "calculator": "Format the calculation result clearly with the expression and answer.",
            "data_analysis": "Present the analysis results with key insights and statistics.",
            "api_integration": "Format the API response data in a readable manner.",
            "web_scraping": "Present the scraped data in an organized format.",
            "automation": "Describe the automation task status and results.",
            "document_processing": "Summarize the document processing results.",
            "chatbot": "Generate a natural and helpful response to the user.",
            "monitoring": "Present the monitoring status and any alerts."
        }
        
        return prompts.get(agent_type, "Generate a clear and informative response based on the results.")
    
    def _get_test_queries_for_logosai(self, analysis: Dict[str, Any]) -> List[str]:
        """LogosAI용 테스트 쿼리 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        test_queries = {
            "calculator": ["10 더하기 20은?", "100에서 45를 빼면?", "7 곱하기 8은 얼마?"],
            "data_analysis": ["데이터 요약 보여줘", "통계 분석 수행해줘", "카테고리별 분포는?"],
            "api_integration": ["API 상태 확인", "데이터 가져오기", "POST 요청 보내기"],
            "web_scraping": ["웹페이지 데이터 수집", "제목 추출하기", "링크 목록 가져오기"],
            "automation": ["작업 자동화 시작", "스케줄 확인", "자동화 상태 보기"],
            "document_processing": ["문서 분석하기", "텍스트 추출", "요약 생성"],
            "chatbot": ["안녕하세요", "도움이 필요해요", "정보 알려줘"],
            "monitoring": ["시스템 상태 확인", "알림 설정", "메트릭 보기"]
        }
        
        return test_queries.get(agent_type, ["테스트 쿼리 1", "테스트 쿼리 2", "테스트 쿼리 3"])
    
    def _get_sample_data_code_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 샘플 데이터 코드 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type == "data_analysis":
            return """# Generate sample data
    import pandas as pd
    import numpy as np
    
    sample_data = pd.DataFrame({
        'date': pd.date_range('2024-01-01', periods=100),
        'sales': np.random.randint(100, 1000, 100),
        'category': np.random.choice(['Electronics', 'Clothing', 'Food'], 100),
        'region': np.random.choice(['North', 'South', 'East', 'West'], 100)
    })"""
        
        return "# Sample data generation (if needed)"
    
    def _get_custom_cleanup_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 커스텀 클린업 코드"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type in ["api_integration", "web_scraping"]:
            return """# Close HTTP session
            if hasattr(self, 'session') and self.session:
                await self.session.close()"""
        
        return "# Custom cleanup code"
    
    def _get_logosai_helper_methods(self, agent_type: str, features: List[str]) -> str:
        """LogosAI 에이전트용 헬퍼 메서드 생성"""
        
        methods = []
        
        # Common helper method for all agents
        methods.append('''    async def _extract_query_info(self, query: str) -> Dict[str, Any]:
        """
        Use LLM to extract structured information from natural language query.
        """
        if not self.llm_client:
            return {"error": "LLM client not initialized"}
        
        try:
            prompt = f"""
            Extract key information from this query:
            Query: {query}
            
            IMPORTANT: Output ONLY a valid Python dictionary (NOT JSON format).
            Example format:
            {{'key1': 'value1', 'key2': 'value2', 'key3': ['item1', 'item2']}}
            
            Do NOT include markdown, backticks, or explanations.
            Output the dictionary directly.
            """
            
            result = await self.llm_client.generate(prompt)
            return json.loads(result) if isinstance(result, str) else result
        except Exception as e:
            logger.error(f"Failed to extract query info: {e}")
            return {"error": str(e)}''')
        
        # Add type-specific helper methods
        if agent_type == "data_analysis":
            methods.append('''    
    async def _analyze_data(self, data: Any) -> Dict[str, Any]:
        """Analyze data and return insights."""
        try:
            # Simplified data analysis
            if isinstance(data, (list, dict)):
                return {
                    "row_count": len(data) if isinstance(data, list) else 1,
                    "data_type": type(data).__name__,
                    "summary": "Data analysis completed"
                }
            return {"error": "Unsupported data type"}
        except Exception as e:
            return {"error": str(e)}''')
            
        elif agent_type == "api_integration":
            methods.append('''    
    async def _make_api_call(self, endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Make an API call with given parameters."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(endpoint, params=params) as response:
                    return await response.json()
        except Exception as e:
            logger.error(f"API call failed: {e}")
            return {"error": str(e)}''')
        
        return '\n'.join(methods)
    
    def _validate_code(self, code: str) -> Dict[str, Any]:
        """코드 검증"""
        try:
            # 디버깅: 코드의 111번 줄 근처 출력 (필요시만 활성화)
            lines = code.split('\n')
            # if len(lines) > 110:
            #     logger.debug(f"🔍 Line 109: {lines[108][:100] if len(lines) > 108 else 'N/A'}")
            #     logger.debug(f"🔍 Line 110: {lines[109][:100] if len(lines) > 109 else 'N/A'}")
            #     logger.debug(f"🔍 Line 111: {lines[110][:100] if len(lines) > 110 else 'N/A'}")
            #     logger.debug(f"🔍 Line 112: {lines[111][:100] if len(lines) > 111 else 'N/A'}")
            #     logger.debug(f"🔍 Line 113: {lines[112][:100] if len(lines) > 112 else 'N/A'}")
            
            # 구문 검사
            try:
                compile(code, '<string>', 'exec')
            except SyntaxError as se:
                # 369번째 줄 근처 출력
                if hasattr(se, 'lineno') and se.lineno:
                    error_line = se.lineno
                    logger.error(f"🔴 Syntax error at line {error_line}")
                    
                    # 에러 줄 근처 출력 (5줄 전후)
                    start = max(0, error_line - 6)
                    end = min(len(lines), error_line + 5)
                    
                    logger.error("🔴 Code around error line:")
                    for i in range(start, end):
                        marker = " >>> " if i == error_line - 1 else "     "
                        line_content = lines[i] if i < len(lines) else "N/A"
                        # 백슬래시 문제 표시
                        if '\\' in line_content and i == error_line - 1:
                            logger.error(f"{marker}Line {i+1:3d}: {line_content[:200]} ⚠️ BACKSLASH FOUND")
                        else:
                            logger.error(f"{marker}Line {i+1:3d}: {line_content[:200]}")
                    
                    # 에러 코드를 파일로 저장 (디버깅용)
                    import tempfile
                    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                        f.write(code)
                        logger.error(f"💾 Error code saved to: {f.name}")
                
                raise
            
            # 필수 요소 확인 - 상속 포함 클래스도 인식
            has_class = re.search(r'class \w+(\(.*\))?:', code)
            has_process = 'async def process' in code or 'def process' in code
            has_init = 'def __init__' in code
            
            errors = []
            if not has_class:
                errors.append("클래스 정의가 없습니다")
            if not has_process:
                errors.append("process 메서드가 없습니다")
            if not has_init:
                errors.append("__init__ 메서드가 없습니다")
            
            return {
                "valid": len(errors) == 0,
                "errors": errors
            }
            
        except SyntaxError as e:
            return {
                "valid": False,
                "errors": [f"구문 오류: {str(e)}"]
            }
    
    def _generate_metadata(self, analysis: Dict[str, Any], request: ForgeRequest) -> Dict[str, Any]:
        """메타데이터 생성"""
        agent_id = str(uuid.uuid4())[:8]
        
        return {
            "agent_id": agent_id,
            "agent_name": analysis["agent_name"],
            "agent_type": analysis["agent_type"],
            "description": analysis["description"],
            "created_at": datetime.now().isoformat(),
            "created_by": request.user_email,
            "session_id": request.session_id,
            "version": "1.0.0",
            "complexity": analysis["complexity"],
            "features": analysis["features"],
            "confidence": analysis["confidence"]
        }
    
    def _save_agent(self, code: str, metadata: Dict[str, Any]) -> str:
        """에이전트 파일 저장"""
        filename = f"{metadata['agent_name'].lower()}_{metadata['agent_id']}.py"
        file_path = self.output_dir / filename
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)
        
        # 메타데이터도 저장
        metadata_path = file_path.with_suffix('.json')
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        
        return str(file_path)
    
    async def _test_agent(self, code: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """에이전트 테스트"""
        try:
            # 코드 실행을 위한 네임스페이스
            namespace = {}
            exec(code, namespace)
            
            # 에이전트 클래스 찾기
            agent_class = None
            for name, obj in namespace.items():
                if isinstance(obj, type) and name == analysis["agent_name"]:
                    agent_class = obj
                    break
            
            if not agent_class:
                return {
                    "status": "error",
                    "error": "에이전트 클래스를 찾을 수 없습니다"
                }
            
            # 에이전트 인스턴스 생성
            agent = agent_class()
            
            # 간단한 테스트 실행
            test_query = "테스트 쿼리"
            result = await agent.process(test_query)
            
            return {
                "status": "success",
                "test_result": result,
                "agent_info": agent.get_info() if hasattr(agent, 'get_info') else {}
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }


# CLI 인터페이스
async def main():
    """메인 실행 함수"""
    system = FinalForgeSystem()
    
    print("\n" + "="*60)
    print("FORGE AI - 에이전트 자동 생성 시스템")
    print("="*60)
    
    # 예제 요청들
    example_requests = [
        "간단한 계산기 에이전트를 만들어줘",
        "CSV 파일을 분석하고 차트를 그리는 데이터 분석 에이전트",
        "REST API와 연동해서 데이터를 가져오는 에이전트",
        "실시간으로 웹사이트를 모니터링하는 에이전트"
    ]
    
    print("\n예제 요청:")
    for i, req in enumerate(example_requests, 1):
        print(f"{i}. {req}")
    
    # 사용자 입력 또는 예제 선택
    choice = input("\n선택 (1-4) 또는 직접 입력: ").strip()
    
    if choice.isdigit() and 1 <= int(choice) <= len(example_requests):
        query = example_requests[int(choice) - 1]
    else:
        query = choice if choice else example_requests[0]
    
    print(f"\n선택된 요청: {query}")
    print("-"*60)
    
    # 에이전트 생성
    request = ForgeRequest(
        query=query,
        enable_testing=True,
        save_to_file=True
    )
    
    result = await system.create_agent(request)
    
    # 결과 출력
    if result.success:
        print("\n✅ 에이전트 생성 성공!")
        print(f"파일: {result.file_path}")
        print(f"타입: {result.metadata['agent_type']}")
        print(f"복잡도: {result.metadata['complexity']}")
        print(f"기능: {', '.join(result.metadata['features'])}")
        
        if result.test_results and result.test_results["status"] == "success":
            print("\n✅ 테스트 통과!")
            print(f"테스트 결과: {json.dumps(result.test_results['test_result'], ensure_ascii=False, indent=2)}")
    else:
        print(f"\n❌ 에이전트 생성 실패: {result.error}")


if __name__ == "__main__":
    asyncio.run(main())