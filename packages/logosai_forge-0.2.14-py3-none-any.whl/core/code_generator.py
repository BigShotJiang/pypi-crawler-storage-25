"""
Code Generator for FORGE AI

Generates agent code using templates and LLM-driven decisions.
All decisions are made by LLM, not hardcoded.
"""

from typing import Dict, Any, Optional, List, Tuple, Callable
from dataclasses import dataclass
from loguru import logger
import json
from pathlib import Path
import uuid
from datetime import datetime
import time
import re

from .llm_orchestrator import LLMOrchestrator, TaskType
from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .json_utils import extract_json_from_text, ensure_json_fields, create_json_prompt_template
from .prompts import prompt_registry
from .generation_artifacts import GenerationArtifacts, PromptRecord
from .code_post_processor import CodePostProcessor

# Import LogosAI template system
try:
    from logosai.templates import TemplateEngine
except ImportError:
    # Fallback for testing
    class TemplateEngine:
        def list_templates(self, category=None):
            return ["base/basic_agent.py.jinja2", "base/async_agent.py.jinja2"]
        def get_metadata(self, template):
            return None
        def render(self, template, context):
            return f"# Generated from {template}"

@dataclass
class GeneratedCode:
    """Represents generated agent code with full artifacts"""
    code: str
    template_used: str
    context_values: Dict[str, Any]
    metadata: Dict[str, Any]
    suggestions: List[str]
    artifacts: Optional[GenerationArtifacts] = None  # Full generation artifacts
    
    def save(self, file_path: Path):
        """Save generated code to file"""
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(self.code)
            
        # Also save artifacts if available
        if self.artifacts:
            artifacts_path = file_path.with_suffix('.artifacts.json')
            self.artifacts.save_to_file(artifacts_path)
            
    def as_agent(self):
        """Convert to agent object (for compatibility)"""
        return type('GeneratedAgent', (), {
            'code': self.code,
            'name': self.context_values.get('agent_name', 'GeneratedAgent')
        })


class CodeGenerator:
    """Generates agent code using LLM-driven decisions"""
    
    def __init__(self, 
                 template_manager: Optional[Any] = None,
                 llm_orchestrator: Optional[LLMOrchestrator] = None):
        """
        Initialize code generator.
        
        Args:
            template_manager: Template manager (dual-source when implemented)
            llm_orchestrator: LLM orchestrator for decisions
        """
        self.template_manager = template_manager
        self.llm = llm_orchestrator
        self.logosai_engine = TemplateEngine()
        self.generation_history = []
        self.artifacts_storage_path = Path("forge_artifacts")  # Storage for artifacts
        self.artifacts_storage_path.mkdir(exist_ok=True)
        self.post_processor = CodePostProcessor()
        
    async def generate(self, 
                      analysis: QueryAnalysis,
                      context: Context,
                      template: Optional[str] = None,
                      stream_callback: Optional[Callable] = None) -> GeneratedCode:
        """
        Generate agent code based on analysis and context.
        All decisions are made by LLM.
        
        Args:
            analysis: Query analysis results
            context: Conversation context with gathered info
            template: Optional specific template to use
            
        Returns:
            Generated agent code
        """
        logger.info(f"Starting code generation for: {analysis.intent}")
        
        # Initialize artifacts tracking
        start_time = time.time()
        artifacts = GenerationArtifacts(
            generation_id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            original_query=analysis.query,
            user_context=context.to_dict(),
            query_analysis=analysis.to_dict()
        )
        
        # 1. Select template (LLM decision)
        if not template:
            if stream_callback:
                await stream_callback(
                    "generating",
                    "📋 최적의 템플릿을 분석하고 있습니다...",
                    {"phase": "template_analysis"}
                )
            template = await self._select_template(analysis, context, artifacts)
            
        logger.info(f"Selected template: {template}")
        
        if stream_callback:
            await stream_callback(
                "generating",
                f"✅ 템플릿 선택 완료: {template}",
                {"template": template, "phase": "template_selected"}
            )
        
        # 2. Prepare context values (LLM decision)
        if stream_callback:
            await stream_callback(
                "generating",
                "🔍 에이전트 요구사항을 분석하고 있습니다...",
                {"phase": "context_preparation"}
            )
            
        context_values = await self._prepare_context_values(
            analysis, context, template, artifacts
        )
        artifacts.template_context_values = context_values
        
        if stream_callback:
            await stream_callback(
                "generating",
                "✅ 요구사항 분석 완료",
                {"phase": "context_ready", "agent_name": context_values.get('agent_name', 'Agent')}
            )
        
        # 3. Generate additional code sections (LLM decision)
        additional_code = await self._generate_additional_code(
            analysis, context, template, artifacts
        )
        
        # Merge additional code into context
        if additional_code:
            context_values.update(additional_code)
            
        # 4. Render template
        if stream_callback:
            await stream_callback(
                "generating",
                "⚙️ 에이전트 코드를 생성하고 있습니다...",
                {"phase": "rendering_template"}
            )
            
        try:
            # Check if template has source prefix
            if ':' in template:
                source, template_name = template.split(':', 1)
                
                # Special handling for our comprehensive template
                if template_name == "logosai_agent_template.py.template":
                    # Read the template file directly
                    template_path = Path(__file__).parent.parent / "templates" / template_name
                    if template_path.exists():
                        with open(template_path, 'r', encoding='utf-8') as f:
                            template_content = f.read()
                        
                        # Use simple string replacement approach for our custom template format
                        try:
                            # Convert template to use simple placeholders
                            rendered_code = template_content
                            
                            # Replace template variables using simple string replacement
                            # Our template uses {variable} format, not Jinja2's {{variable}}
                            for key, value in context_values.items():
                                placeholder = f"{{{key}}}"
                                if placeholder in rendered_code:
                                    # Convert value to string and handle special cases
                                    replacement = str(value)
                                    
                                    # Don't escape backslashes in multiline code blocks
                                    if '\n' not in replacement:
                                        replacement = replacement.replace('\\', '\\\\')
                                    
                                    # Remove any Jinja2-like syntax that might have been generated
                                    replacement = replacement.replace('{% ', '# ')
                                    replacement = replacement.replace(' %}', '')
                                    replacement = replacement.replace('{{ ', '')
                                    replacement = replacement.replace(' }}', '')
                                    
                                    rendered_code = rendered_code.replace(placeholder, replacement)
                                    logger.debug(f"Replaced {placeholder} with value of length {len(replacement)}")
                            
                            logger.info(f"Successfully rendered LogosAI template with context: {list(context_values.keys())}")
                            
                            # Check if any template variables remain unreplaced
                            remaining_vars = re.findall(r'(?<!\{)\{([^{}]+)\}(?!\})', rendered_code)
                            if remaining_vars:
                                logger.warning(f"Unreplaced template variables found: {remaining_vars}")
                            
                            # Log first few lines of rendered code for verification
                            lines = rendered_code.split('\n')[:10]
                            logger.debug("First 10 lines of rendered code:\n" + '\n'.join(lines))
                            
                        except Exception as e:
                            logger.error(f"Template rendering failed: {e}", exc_info=True)
                            # Fallback to direct generation
                            rendered_code = await self._generate_code_directly(analysis, context, artifacts)
                    else:
                        logger.error(f"Template file not found: {template_path}")
                        rendered_code = await self._generate_code_directly(analysis, context)
                elif self.template_manager:
                    # Use DualTemplateManager for rendering
                    logger.info(f"Rendering template {template_name} from {source} with context values")
                    rendered_code = await self.template_manager.render_template(
                        template_name, context_values, source
                    )
                else:
                    # Fallback to LogosAI engine
                    rendered_code = self.logosai_engine.render(template_name, context_values)
            else:
                # No source prefix, use LogosAI engine directly
                rendered_code = self.logosai_engine.render(template, context_values)
                
            logger.info(f"Successfully rendered template: {template}")
            artifacts.generated_code_raw = rendered_code
        except Exception as e:
            logger.error(f"Template rendering failed: {e}")
            artifacts.errors.append({"type": "template_rendering", "error": str(e)})
            # Fallback to direct LLM generation
            rendered_code = await self._generate_code_directly(analysis, context, artifacts)
            artifacts.generated_code_raw = rendered_code
            
        # 5. Optimize generated code (LLM decision)
        if stream_callback:
            await stream_callback(
                "generating",
                "🔧 생성된 코드를 최적화하고 있습니다...",
                {"phase": "optimizing"}
            )
            
        optimized_code = await self._optimize_code(rendered_code, analysis, context, artifacts)
        artifacts.optimized_code = optimized_code
        
        if stream_callback:
            await stream_callback(
                "generating",
                "✅ 코드 최적화 완료",
                {"phase": "optimization_complete"}
            )
        
        # 5.5. Apply post-processing to fix common syntax errors
        if stream_callback:
            await stream_callback(
                "generating",
                "🔍 코드 구문을 검증하고 있습니다...",
                {"phase": "post_processing"}
            )
            
        logger.info("Applying code post-processing...")
        processed_code, fixes_applied = self.post_processor.process(optimized_code)
        
        if fixes_applied:
            logger.info(f"Applied automatic fixes: {fixes_applied}")
            # Update artifacts with post-processing info
            artifacts.metadata['post_processing'] = {
                'fixes_applied': fixes_applied,
                'timestamp': datetime.now().isoformat()
            }
            optimized_code = processed_code
            artifacts.optimized_code = optimized_code
            
            if stream_callback:
                await stream_callback(
                    "generating",
                    f"✅ 자동으로 {len(fixes_applied)}개의 구문 오류를 수정했습니다",
                    {"phase": "post_processing_complete", "fixes": fixes_applied}
                )
        
        # 6. Generate suggestions (LLM decision)
        suggestions = await self._generate_suggestions(optimized_code, analysis, artifacts)
        artifacts.improvement_suggestions = suggestions
        
        # Calculate final metrics
        end_time = time.time()
        artifacts.total_generation_time_ms = int((end_time - start_time) * 1000)
        
        # Save template info
        artifacts.selected_template = template
        if template == "forge:logosai_agent_template.py.template":
            template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template.py.template"
            if template_path.exists():
                with open(template_path, 'r', encoding='utf-8') as f:
                    artifacts.template_content = f.read()
        
        # Create result with artifacts
        result = GeneratedCode(
            code=optimized_code,
            template_used=template,
            context_values=context_values,
            metadata={
                'analysis': analysis.to_dict(),
                'context': context.to_dict(),
                'generation_timestamp': context.updated_at.isoformat()
            },
            suggestions=suggestions,
            artifacts=artifacts  # Include full artifacts
        )
        
        # Track history
        self.generation_history.append(result)
        
        return result
        
    async def _select_template(self, analysis: QueryAnalysis, 
                              context: Context,
                              artifacts: GenerationArtifacts) -> str:
        """Let LLM select the best template"""
        
        # First, check if we should use the new LogosAI template
        use_new_template_prompt = f"""Based on this analysis, should we use the comprehensive LogosAI template?

Query: {analysis.query}
Intent: {analysis.intent}
Capabilities: {', '.join(analysis.required_capabilities)}

The comprehensive LogosAI template includes:
- Async/await pattern
- LLM integration for natural language processing
- External API integration patterns
- Proper error handling and logging
- Structured response format
- Resource lifecycle management

Use comprehensive template? (yes/no):"""
        
        # Record prompt
        prompt_start = time.time()
        use_new_response = await self.llm.generate(
            use_new_template_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.2
        )
        prompt_end = time.time()
        
        # Save to artifacts
        artifacts.add_prompt_record(PromptRecord(
            prompt_type="template_selection_initial",
            system_prompt="Determine if comprehensive template should be used",
            user_prompt=use_new_template_prompt,
            response=use_new_response,
            model=self.llm.config.get('model', 'unknown'),
            temperature=0.2,
            timestamp=datetime.now(),
            latency_ms=int((prompt_end - prompt_start) * 1000)
        ))
        
        if 'yes' in use_new_response.lower():
            logger.info("Using comprehensive LogosAI template")
            return "forge:logosai_agent_template.py.template"
        
        # Get available templates from BOTH sources if we have a template manager
        if self.template_manager:
            # Use DualTemplateManager to get templates from both LogosAI and FORGE
            all_templates = await self.template_manager.list_all_templates(include_metadata=True)
            
            # Format template info
            template_info = []
            for tmpl in all_templates:
                if tmpl.get('description'):
                    template_info.append(
                        f"- {tmpl['name']} [{tmpl['source']}]: {tmpl['description']} "
                        f"(tags: {', '.join(tmpl.get('tags', []))})"
                    )
                else:
                    template_info.append(f"- {tmpl['name']} [{tmpl['source']}]")
            
            # Prefer LogosAI templates for base functionality
            logosai_templates = [t for t in all_templates if t['source'] == 'logosai']
            forge_templates = [t for t in all_templates if t['source'] == 'forge']
            
            # Log template availability
            logger.info(f"Found {len(logosai_templates)} LogosAI templates and {len(forge_templates)} FORGE templates")
        else:
            # Fallback to direct LogosAI engine
            templates = self.logosai_engine.list_templates()
            
            # Format template info
            template_info = []
            for template in templates:
                metadata = self.logosai_engine.get_metadata(template)
                if metadata:
                    template_info.append(
                        f"- {template}: {metadata.description} "
                        f"(tags: {', '.join(metadata.tags)})"
                    )
                else:
                    template_info.append(f"- {template}")
                
        # Use prompt registry with emphasis on LogosAI templates
        prompt = prompt_registry.render_prompt(
            "code_template_selection",
            query=analysis.query,
            intent=analysis.intent,
            capabilities=', '.join(analysis.required_capabilities),
            complexity=analysis.complexity.value,
            available_templates='\n'.join(template_info)
        )
        
        # Add instruction to prefer LogosAI templates
        prompt += "\n\nIMPORTANT: Prefer LogosAI templates [logosai] over FORGE templates [forge] unless the FORGE template is specifically optimized for this use case."
        
        # Record prompt
        prompt_start = time.time()
        response = await self.llm.generate(
            prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.3
        )
        prompt_end = time.time()
        
        # Save to artifacts
        artifacts.add_prompt_record(PromptRecord(
            prompt_type="template_selection_main",
            system_prompt="Select best template from available options",
            user_prompt=prompt,
            response=response,
            model=self.llm.config.get('model', 'unknown'),
            temperature=0.3,
            timestamp=datetime.now(),
            latency_ms=int((prompt_end - prompt_start) * 1000)
        ))
        
        # Extract template from response
        selected = response.strip()
        
        # If using template manager, use its selection logic
        if self.template_manager:
            # Parse template name and source from response
            template_name = None
            source = 'logosai'  # Default to LogosAI
            
            # Look for exact matches first
            for tmpl in all_templates:
                if tmpl['name'] in selected or selected in tmpl['name']:
                    template_name = tmpl['name']
                    source = tmpl['source']
                    logger.info(f"Selected template: {template_name} from {source}")
                    return f"{source}:{template_name}"
            
            # If no exact match, use template manager's selection
            template_name, source = await self.template_manager.select_template(
                {
                    'intent': analysis.intent,
                    'capabilities': analysis.required_capabilities,
                    'complexity': analysis.complexity.value
                },
                context.to_dict()
            )
            return f"{source}:{template_name}"
        else:
            # Validate selection for direct LogosAI
            for template in templates:
                if template in selected or selected in template:
                    return template
                
        # Default fallback (let LLM decide the default too)
        if self.template_manager:
            # Get default LogosAI templates
            logosai_defaults = [t for t in all_templates if t['source'] == 'logosai'][:5]
            if logosai_defaults:
                default_prompt = f"""No exact match found. Choose the most appropriate default from these LogosAI templates:
{chr(10).join([f"- {t['name']}: {t.get('description', '')}" for t in logosai_defaults])}

Best default choice:"""
                
                default_response = await self.llm.generate(
                    default_prompt,
                    task_type=TaskType.CODE_GENERATION,
                    temperature=0.1
                )
                
                # Extract template
                for tmpl in logosai_defaults:
                    if tmpl['name'] in default_response:
                        return f"logosai:{tmpl['name']}"
                
                # Ultimate fallback to first LogosAI template
                return f"logosai:{logosai_defaults[0]['name']}"
            else:
                # No LogosAI templates, fallback to any template
                return f"{all_templates[0]['source']}:{all_templates[0]['name']}"
        else:
            default_prompt = f"""No exact match found. Choose the most appropriate default from:
{chr(10).join(templates[:5])}

Best default choice:"""
            
            default_response = await self.llm.generate(
                default_prompt,
                task_type=TaskType.CODE_GENERATION,
                temperature=0.1
            )
            
            # Extract template
            for template in templates:
                if template in default_response:
                    return template
                    
            return templates[0]  # Ultimate fallback
        
    async def _prepare_context_values(self, analysis: QueryAnalysis,
                                     context: Context,
                                     template: str,
                                     artifacts: GenerationArtifacts) -> Dict[str, Any]:
        """Let LLM prepare context values for template"""
        
        # Special handling for the comprehensive LogosAI template
        if template == "forge:logosai_agent_template.py.template":
            # Define the expected structure
            example_values = {
                "agent_class_name": "ExampleAgent",
                "agent_name": "example_agent",
                "agent_description": "Clear description of what the agent does",
                "custom_config": ",\n                    \"timeout\": 30,\n                    \"max_retries\": 3",
                "custom_init": "self.cache = {}",
                "custom_async_init": "# Initialize async resources here",
                "query_extraction_prompt": "Extract key information from: {query}",
                "core_logic": """# Process the data
        result = {{
            "status": "success",
            "data": extracted_info,
            "timestamp": datetime.now().isoformat()
        }}
        return result""",
                "response_generation_prompt": "Generate response based on: {result}",
                "custom_cleanup": "# Cleanup resources",
                "test_queries": "['example query 1', 'example query 2']"
            }
            
            description = f"""Prepare context values for the LogosAI comprehensive template.

Query: {analysis.query}
Intent: {analysis.intent}
Capabilities: {', '.join(analysis.required_capabilities)}
Domain: {analysis.domain or 'general'}

IMPORTANT RULES:
1. custom_config should contain ONLY dictionary key-value pairs (e.g., "timeout": 30, "max_retries": 3)
2. custom_init should contain initialization code for self variables (e.g., self.cache = {{}})
3. DO NOT mix initialization code with config values
4. Keep custom_config as a valid dictionary content string
5. NEVER use Jinja2 template syntax like {{% %}}, {{ }}, {{# #}} in any field
6. Use plain Python code without any template directives
7. For core_logic field, write actual Python code, not template instructions

Generate appropriate values for each field based on the query."""
            
            prepare_prompt = create_json_prompt_template(example_values, description)
            
            # Use the optimized model selection based on task
            logger.info(f"Generating context values with LLM for template: {template}")
            
            response = await self.llm.generate(
                prepare_prompt,
                task_type=TaskType.CODE_GENERATION,
                temperature=0.3  # Lower temperature for more consistent JSON
            )
            
            try:
                # Use the robust JSON extraction utility
                context_values = extract_json_from_text(response)
                
                if context_values is None:
                    raise ValueError("No valid JSON found in response")
                # Ensure all required fields are present
                required_fields = [
                    'agent_class_name', 'agent_name', 'agent_description',
                    'custom_config', 'custom_init', 'custom_async_init',
                    'query_extraction_prompt', 'core_logic', 
                    'response_generation_prompt', 'custom_cleanup', 'test_queries'
                ]
                
                # Use the utility function to ensure fields with better defaults
                defaults = {
                    'custom_config': "{}",
                    'custom_init': "",
                    'custom_async_init': "",
                    'query_extraction_prompt': "Extract relevant information from: {query}",
                    'core_logic': "# TODO: Implement core logic",
                    'response_generation_prompt': "Generate response based on: {result}",
                    'custom_cleanup': "",
                    'test_queries': "[]"
                }
                
                context_values = ensure_json_fields(context_values, required_fields, defaults)
                
                logger.info(f"Prepared context values for comprehensive template: {list(context_values.keys())}")
                return context_values
            except json.JSONDecodeError as e:
                # Fallback to structured extraction
                logger.warning(f"Failed to parse JSON: {e}. Response was: {response[:200]}...")
                logger.info("Using structured extraction as fallback")
                return self._extract_template_values_structured(response, analysis)
            except Exception as e:
                logger.error(f"Unexpected error preparing context values: {e}")
                return self._extract_template_values_structured("", analysis)
        
        
        # Get template requirements
        metadata = None
        if ':' in template:
            source, template_name = template.split(':', 1)
            if self.template_manager and source == 'forge':
                # Get FORGE template metadata
                forge_meta = self.template_manager.forge_templates.get(template_name)
                if forge_meta:
                    metadata = type('Metadata', (), {
                        'required_params': list(forge_meta.parameters.keys()),
                        'optional_params': forge_meta.parameters
                    })
            else:
                # Use LogosAI engine
                metadata = self.logosai_engine.get_metadata(template_name)
        else:
            metadata = self.logosai_engine.get_metadata(template)
        
        if metadata:
            required_params = metadata.required_params
            optional_params = metadata.optional_params
        else:
            # Let LLM infer requirements
            infer_prompt = f"""Infer the likely required parameters for template: {template}

Common parameters include:
- agent_name: Name of the agent
- agent_class_name: Python class name
- description: Agent description
- required_fields: List of required input fields

List likely required parameters:"""
            
            param_response = await self.llm.generate(
                infer_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.3
            )
            
            required_params = [p.strip() for p in param_response.strip().split('\n')]
            optional_params = {}
            
        # Use prompt to generate values
        prompt = prompt_registry.render_prompt(
            "code_context_preparation",
            query=analysis.query,
            analysis=json.dumps(analysis.to_dict(), indent=2),
            template_requirements=json.dumps({
                'required': required_params,
                'optional': optional_params
            }, indent=2),
            gathered_info=json.dumps(context.gathered_info, indent=2)
        )
        
        response = await self.llm.generate(
            prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.5
        )
        
        # Parse response as JSON
        try:
            context_values = json.loads(response)
        except json.JSONDecodeError:
            # Let LLM fix the JSON
            fix_prompt = f"""Fix this JSON response:
{response}

Valid JSON:"""
            
            fixed_response = await self.llm.generate(
                fix_prompt,
                task_type=TaskType.CODE_GENERATION,
                temperature=0.1
            )
            
            try:
                context_values = json.loads(fixed_response)
            except:
                # Manual extraction as last resort
                context_values = self._extract_context_manually(response, required_params)
                
        return context_values
        
    async def _generate_additional_code(self, analysis: QueryAnalysis,
                                       context: Context,
                                       template: str,
                                       artifacts: GenerationArtifacts) -> Dict[str, Any]:
        """Let LLM generate additional code sections"""
        
        # Ask LLM what additional code is needed
        assess_prompt = f"""Based on the requirements, what additional code sections are needed?

Query: {analysis.query}
Template: {template}
Capabilities: {', '.join(analysis.required_capabilities)}

Consider:
1. Custom methods needed
2. Helper functions
3. Integration code
4. Error handling
5. Configuration

List needed code sections:"""
        
        sections_response = await self.llm.generate(
            assess_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.5
        )
        
        # Generate each section
        additional_code = {}
        
        # Let LLM parse its own response
        parse_prompt = f"""Extract the code sections to generate from this response:
{sections_response}

Format as JSON list of section names:"""
        
        parse_response = await self.llm.generate(
            parse_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.1
        )
        
        try:
            sections = json.loads(parse_response)
            if not isinstance(sections, list):
                sections = []
        except:
            sections = []
            
        # Generate each section
        for section in sections[:5]:  # Limit to prevent too much generation
            section_prompt = f"""Generate Python code for: {section}

Context:
- Query: {analysis.query}
- Capabilities: {', '.join(analysis.required_capabilities)}
- Domain: {analysis.domain or 'general'}

Generate clean, well-documented Python code:"""
            
            code = await self.llm.generate(
                section_prompt,
                task_type=TaskType.CODE_GENERATION,
                temperature=0.7
            )
            
            # Store based on section type (let LLM decide the key)
            key_prompt = f"""What should be the template variable name for this section?
Section: {section}

Common names: additional_methods, processing_logic, setup_steps, helper_functions

Best variable name:"""
            
            key_response = await self.llm.generate(
                key_prompt,
                task_type=TaskType.ANALYSIS,
                temperature=0.1
            )
            
            key = key_response.strip().replace(' ', '_').lower()
            
            if key not in additional_code:
                additional_code[key] = []
                
            additional_code[key].append(code)
            
        return additional_code
        
    async def _optimize_code(self, code: str, analysis: QueryAnalysis,
                            context: Context, artifacts: Optional[GenerationArtifacts] = None) -> str:
        """Let LLM optimize the generated code"""
        
        # First, check if optimization is needed
        check_prompt = f"""Should this code be optimized?

Requirements:
- Query: {analysis.query}
- Performance needs: {analysis.constraints.get('performance', 'standard')}
- Complexity: {analysis.complexity.value}

Code length: {len(code)} characters

Needs optimization? (yes/no):"""
        
        check_response = await self.llm.generate(
            check_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.1
        )
        
        if 'no' in check_response.lower():
            return code
            
        # Get optimization suggestions
        prompt = prompt_registry.render_prompt(
            "code_optimization_suggestions",
            code_summary=code[:1000] + "..." if len(code) > 1000 else code,
            requirements=json.dumps({
                'query': analysis.query,
                'capabilities': analysis.required_capabilities
            }),
            constraints=json.dumps(analysis.constraints)
        )
        
        suggestions = await self.llm.generate(
            prompt,
            task_type=TaskType.OPTIMIZATION,
            temperature=0.5
        )
        
        # Apply optimizations
        optimize_prompt = f"""Apply these optimizations to the code:

Optimizations:
{suggestions}

Original code:
{code}

Optimized code:"""
        
        optimized = await self.llm.generate(
            optimize_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.3,
            max_tokens=4000
        )
        
        return optimized
        
    async def _generate_suggestions(self, code: str, 
                                   analysis: QueryAnalysis,
                                   artifacts: Optional[GenerationArtifacts] = None) -> List[str]:
        """Let LLM generate improvement suggestions"""
        
        suggest_prompt = f"""Review this generated agent code and suggest future improvements:

Agent Purpose: {analysis.intent}
Capabilities: {', '.join(analysis.required_capabilities)}

Consider:
1. Additional features that could be useful
2. Performance enhancements
3. Better error handling
4. Integration possibilities
5. Testing recommendations

Provide 3-5 actionable suggestions:"""
        
        response = await self.llm.generate(
            suggest_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.7
        )
        
        # Parse suggestions
        suggestions = []
        for line in response.strip().split('\n'):
            line = line.strip()
            if line and not line.startswith('#'):
                # Clean up numbering, bullets, etc.
                cleaned = line.lstrip('0123456789.-• ').strip()
                if cleaned:
                    suggestions.append(cleaned)
                    
        return suggestions[:5]
        
    async def _generate_code_directly(self, analysis: QueryAnalysis,
                                     context: Context,
                                     artifacts: Optional[GenerationArtifacts] = None) -> str:
        """Fallback: Let LLM generate code directly without template"""
        
        direct_prompt = f"""Generate a complete LogosAI agent based on these requirements:

Query: {analysis.query}
Intent: {analysis.intent}
Required Capabilities: {', '.join(analysis.required_capabilities)}
Context: {json.dumps(context.gathered_info, indent=2)}

Requirements:
1. Inherit from LogosAIAgent
2. Implement all required methods (setup, process, validate_input, format_output)
3. Include proper error handling
4. Add type hints
5. Include docstrings

Generate complete, working Python code:"""
        
        code = await self.llm.generate(
            direct_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.7,
            max_tokens=4000
        )
        
        return code
        
    def _extract_context_manually(self, response: str, 
                                 required_params: List[str]) -> Dict[str, Any]:
        """Manual context extraction as last resort"""
        context = {}
        
        # Use reasonable defaults based on param names
        for param in required_params:
            if 'name' in param:
                context[param] = "GeneratedAgent"
            elif 'class' in param:
                context[param] = "GeneratedAgentClass"
            elif 'description' in param:
                context[param] = "AI-generated agent"
            else:
                context[param] = ""
                
        return context
    
    def _extract_template_values_structured(self, response: str, 
                                          analysis: QueryAnalysis) -> Dict[str, Any]:
        """Extract template values from unstructured response"""
        # Generate reasonable defaults based on analysis
        agent_name = analysis.intent.replace(' ', '_').lower()
        if agent_name.endswith('_agent'):
            agent_name = agent_name[:-6]  # Remove '_agent' suffix to avoid duplication
        
        class_name = ''.join(word.capitalize() for word in analysis.intent.split())
        if not class_name.endswith('Agent'):
            class_name = f"{class_name}Agent"
        
        # Generate more complete default implementations
        return {
            'agent_class_name': class_name,
            'agent_name': agent_name,
            'agent_description': f"Agent for {analysis.intent}",
            'custom_config': ',\n                    "max_retries": 3,\n                    "timeout": 30',
            'custom_init': """
        # Custom initialization
        self.data_cache = {}
        self.processing_count = 0""",
            'custom_async_init': """
        # Async initialization - e.g., API clients, database connections
        try:
            # Example: self.api_client = await create_api_client()
            pass
        except Exception as e:
            logger.error(f"Failed to initialize external resources: {e}")""",
            'query_extraction_prompt': f"""Extract the key information from the user query about {analysis.intent}.
Identify:
1. Main intent
2. Required parameters
3. Any constraints or preferences

Return as JSON with relevant fields.""",
            'core_logic': f"""
        # Core processing logic for {analysis.intent}
        try:
            # Process the extracted information
            result = {{
                "status": "success",
                "data": extracted_info,
                "timestamp": datetime.now().isoformat()
            }}
            
            # Add your specific processing logic here
            # Example: result["processed_data"] = await self.process_data(extracted_info)
            
            return result
        except Exception as e:
            logger.error(f"Processing error: {{e}}")
            return {{
                "status": "error",
                "error": str(e),
                "data": extracted_info
            }}""",
            'response_generation_prompt': f"""Generate a helpful and informative response about {analysis.intent}.
Include:
1. Clear explanation of what was done
2. Key results or findings
3. Any relevant recommendations

Keep the response concise and user-friendly.""",
            'custom_cleanup': """
        # Cleanup resources
        if hasattr(self, 'api_client'):
            await self.api_client.close()
        self.data_cache.clear()""",
            'test_queries': json.dumps([
                analysis.query,
                f"Can you help me with {analysis.intent}?",
                f"Show me information about {analysis.intent}"
            ])
        }
        
    async def regenerate_with_feedback(self, previous_result: GeneratedCode,
                                      feedback: str) -> GeneratedCode:
        """Regenerate code based on user feedback"""
        
        regen_prompt = f"""Regenerate the agent code based on this feedback:

Feedback: {feedback}

Previous code summary:
- Template: {previous_result.template_used}
- Intent: {previous_result.metadata['analysis']['intent']}

Understand the feedback and generate improved code:"""
        
        response = await self.llm.generate(
            regen_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.7
        )
        
        # Reuse the original analysis but generate new code
        analysis_dict = previous_result.metadata['analysis']
        
        # Create new analysis object from dict
        from .query_analyzer import QueryAnalysis, Complexity, WorkflowType
        analysis = QueryAnalysis(
            query=analysis_dict['query'],
            intent=analysis_dict['intent'],
            complexity=Complexity(analysis_dict['complexity']),
            workflow_type=WorkflowType(analysis_dict['workflow_type'])
        )
        analysis.required_capabilities = analysis_dict['required_capabilities']
        
        # Create context
        from .context_manager import Context
        context_dict = previous_result.metadata['context']
        context = Context(
            session_id=context_dict['session_id'],
            user_query=context_dict['user_query']
        )
        context.gathered_info = context_dict['gathered_info']
        
        # Generate with feedback incorporated
        return await self.generate(analysis, context)