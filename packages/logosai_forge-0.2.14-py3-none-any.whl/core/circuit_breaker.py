"""
CircuitBreaker — Prevents cascading failures by blocking repeatedly failing agents.

States:
- CLOSED:    Normal operation, tracking consecutive failures
- OPEN:      Agent blocked, cooldown active (1 hour default)
- HALF_OPEN: Cooldown expired, allowing 1 trial execution

Transitions:
- CLOSED → OPEN:      3 consecutive failures
- OPEN → HALF_OPEN:   Cooldown expires
- HALF_OPEN → CLOSED: Trial succeeds
- HALF_OPEN → OPEN:   Trial fails (extended cooldown)
"""

import sqlite3
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from pathlib import Path
from loguru import logger


class CircuitBreaker:
    """Circuit breaker for agent failure management."""

    def __init__(self, db_path: str = None):
        # Load thresholds from config (overridable via YAML or env vars)
        try:
            from config import get_value
            self.FAILURE_THRESHOLD = get_value("circuit_breaker", "failure_threshold", 3)
            self.COOLDOWN_SECONDS = get_value("circuit_breaker", "cooldown_seconds", 3600)
            self.EXTENDED_COOLDOWN_SECONDS = get_value("circuit_breaker", "extended_cooldown_seconds", 7200)
        except Exception:
            self.FAILURE_THRESHOLD = 3
            self.COOLDOWN_SECONDS = 3600
            self.EXTENDED_COOLDOWN_SECONDS = 7200

        if db_path is None:
            db_path = str(Path(__file__).parent.parent / "prototype" / "backend" / "forge_evolution.db")
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS circuit_breaker_state (
                    agent_id TEXT PRIMARY KEY,
                    state TEXT DEFAULT 'closed',
                    consecutive_failures INTEGER DEFAULT 0,
                    last_failure_at TEXT,
                    cooldown_until TEXT,
                    total_trips INTEGER DEFAULT 0
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def _get_state(self, agent_id: str) -> Dict[str, Any]:
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                "SELECT state, consecutive_failures, last_failure_at, cooldown_until, total_trips FROM circuit_breaker_state WHERE agent_id = ?",
                (agent_id,),
            )
            row = cursor.fetchone()
        finally:
            conn.close()

        if not row:
            return {"state": "closed", "consecutive_failures": 0, "last_failure_at": None, "cooldown_until": None, "total_trips": 0}

        return {
            "state": row[0],
            "consecutive_failures": row[1],
            "last_failure_at": row[2],
            "cooldown_until": row[3],
            "total_trips": row[4],
        }

    def _save_state(self, agent_id: str, state: Dict[str, Any]):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                """INSERT INTO circuit_breaker_state (agent_id, state, consecutive_failures, last_failure_at, cooldown_until, total_trips)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(agent_id) DO UPDATE SET
                     state=excluded.state,
                     consecutive_failures=excluded.consecutive_failures,
                     last_failure_at=excluded.last_failure_at,
                     cooldown_until=excluded.cooldown_until,
                     total_trips=excluded.total_trips""",
                (
                    agent_id,
                    state["state"],
                    state["consecutive_failures"],
                    state["last_failure_at"],
                    state["cooldown_until"],
                    state["total_trips"],
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def can_execute(self, agent_id: str) -> Dict[str, Any]:
        """Check if an agent is allowed to execute.

        Returns:
            {"allowed": bool, "state": str, "reason": str, "cooldown_remaining_seconds": int}
        """
        state = self._get_state(agent_id)
        current_state = state["state"]

        if current_state == "closed":
            return {"allowed": True, "state": "closed", "reason": "Normal operation"}

        if current_state == "open":
            # Check if cooldown has expired
            if state["cooldown_until"]:
                cooldown_end = datetime.fromisoformat(state["cooldown_until"])
                now = datetime.now()
                if now >= cooldown_end:
                    # Transition to half_open
                    state["state"] = "half_open"
                    self._save_state(agent_id, state)
                    logger.info(f"[CircuitBreaker] {agent_id}: OPEN → HALF_OPEN (cooldown expired)")
                    return {"allowed": True, "state": "half_open", "reason": "Trial execution allowed"}
                else:
                    remaining = int((cooldown_end - now).total_seconds())
                    return {
                        "allowed": False,
                        "state": "open",
                        "reason": f"Circuit open, cooldown {remaining}s remaining",
                        "cooldown_remaining_seconds": remaining,
                    }
            return {"allowed": False, "state": "open", "reason": "Circuit open"}

        if current_state == "half_open":
            return {"allowed": True, "state": "half_open", "reason": "Trial execution"}

        return {"allowed": True, "state": current_state, "reason": "Unknown state, allowing"}

    def record_success(self, agent_id: str):
        """Record a successful execution."""
        state = self._get_state(agent_id)

        if state["state"] == "half_open":
            # Trial succeeded → close circuit
            state["state"] = "closed"
            state["consecutive_failures"] = 0
            state["cooldown_until"] = None
            logger.info(f"[CircuitBreaker] {agent_id}: HALF_OPEN → CLOSED (trial succeeded)")
        else:
            # Reset failure counter
            state["consecutive_failures"] = 0

        self._save_state(agent_id, state)

    def record_failure(self, agent_id: str) -> Dict[str, Any]:
        """Record a failure and potentially trip the circuit.

        Returns:
            {"tripped": bool, "state": str, "consecutive_failures": int}
        """
        state = self._get_state(agent_id)
        state["consecutive_failures"] += 1
        state["last_failure_at"] = datetime.now().isoformat()

        tripped = False

        if state["state"] == "half_open":
            # Trial failed → re-open with extended cooldown
            state["state"] = "open"
            state["cooldown_until"] = (datetime.now() + timedelta(seconds=self.EXTENDED_COOLDOWN_SECONDS)).isoformat()
            state["total_trips"] += 1
            tripped = True
            logger.warning(f"[CircuitBreaker] {agent_id}: HALF_OPEN → OPEN (trial failed, extended cooldown)")

        elif state["state"] == "closed" and state["consecutive_failures"] >= self.FAILURE_THRESHOLD:
            # Threshold reached → trip circuit
            state["state"] = "open"
            state["cooldown_until"] = (datetime.now() + timedelta(seconds=self.COOLDOWN_SECONDS)).isoformat()
            state["total_trips"] += 1
            tripped = True
            logger.warning(f"[CircuitBreaker] {agent_id}: CLOSED → OPEN ({state['consecutive_failures']} consecutive failures)")

        self._save_state(agent_id, state)

        return {
            "tripped": tripped,
            "state": state["state"],
            "consecutive_failures": state["consecutive_failures"],
            "total_trips": state["total_trips"],
        }

    def reset(self, agent_id: str):
        """Manually reset circuit breaker to closed state."""
        state = {
            "state": "closed",
            "consecutive_failures": 0,
            "last_failure_at": None,
            "cooldown_until": None,
            "total_trips": self._get_state(agent_id)["total_trips"],
        }
        self._save_state(agent_id, state)
        logger.info(f"[CircuitBreaker] {agent_id}: Manually reset to CLOSED")

    def get_all_states(self) -> list:
        """Get circuit breaker states for all agents."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                "SELECT agent_id, state, consecutive_failures, cooldown_until, total_trips FROM circuit_breaker_state ORDER BY total_trips DESC"
            )
            rows = cursor.fetchall()
        finally:
            conn.close()

        return [
            {
                "agent_id": r[0],
                "state": r[1],
                "consecutive_failures": r[2],
                "cooldown_until": r[3],
                "total_trips": r[4],
            }
            for r in rows
        ]
