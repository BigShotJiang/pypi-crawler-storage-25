"""
FunctionGraph — Unified view over all function data sources.

Connects: registry.json templates, function_pairs (composition),
function_metrics (telemetry), function_versions (history).
"""

import json
import sqlite3
from typing import Dict, Any, List, Optional
from pathlib import Path
from loguru import logger

_FORGE_ROOT = Path(__file__).parent.parent
_REGISTRY_PATH = _FORGE_ROOT / "templates" / "functions" / "registry.json"
_DB_PATH = _FORGE_ROOT / "prototype" / "backend" / "forge_evolution.db"


class FunctionGraph:
    """Unified function knowledge graph built from existing data sources."""

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._registry: Dict[str, Any] = {}
        self._categories: Dict[str, Any] = {}
        self._load_registry()

    # ── Data loading ──────────────────────────────────────────────

    def _load_registry(self):
        try:
            with open(_REGISTRY_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._registry = data.get("templates", {})
            self._categories = data.get("categories", {})
        except Exception as e:
            logger.debug(f"[FuncGraph] Registry load failed: {e}")

    def _db(self):
        return sqlite3.connect(str(_DB_PATH))

    # ── Catalog (all functions organized by category) ─────────────

    def get_catalog(self) -> Dict[str, Any]:
        """Full function catalog: categories with their functions + counts."""
        cat_map: Dict[str, List[Dict]] = {}

        for key, tpl in self._registry.items():
            cat = tpl.get("category", "unknown")
            entry = {
                "id": key,
                "name": tpl.get("function", key),
                "description": tpl.get("description", ""),
                "parameters": tpl.get("parameters", {}),
                "returns": tpl.get("returns", ""),
                "keywords": tpl.get("keywords", []),
                "imports": tpl.get("required_imports", []),
            }
            cat_map.setdefault(cat, []).append(entry)

        # Merge with category metadata
        categories = []
        for cat_name in sorted(cat_map.keys()):
            funcs = cat_map[cat_name]
            meta = self._categories.get(cat_name, {})
            categories.append({
                "name": cat_name,
                "label": meta.get("label", cat_name.replace("_", " ").title()),
                "description": meta.get("description", ""),
                "icon": meta.get("icon", ""),
                "count": len(funcs),
                "functions": sorted(funcs, key=lambda f: f["name"]),
            })

        return {
            "total_templates": len(self._registry),
            "total_categories": len(cat_map),
            "categories": sorted(categories, key=lambda c: -c["count"]),
        }

    # ── Function detail with all relationships ────────────────────

    def get_function_detail(self, func_name: str) -> Dict[str, Any]:
        """All info about a function: template + telemetry + pairs + versions."""
        # Template info
        tpl = None
        for key, val in self._registry.items():
            if val.get("function") == func_name or key == func_name:
                tpl = val
                break

        result: Dict[str, Any] = {
            "name": func_name,
            "template": tpl,
        }

        # Telemetry
        try:
            conn = self._db()
            row = conn.execute("""
                SELECT COUNT(*) as cnt,
                       SUM(CASE WHEN success=1 THEN 1 ELSE 0 END) as ok,
                       AVG(duration_ms) as avg_ms
                FROM function_metrics WHERE func_name=?
            """, (func_name,)).fetchone()
            if row and row[0] > 0:
                result["telemetry"] = {
                    "call_count": row[0],
                    "success_rate": round(row[1] / max(row[0], 1), 3),
                    "avg_duration_ms": round(row[2] or 0, 1),
                }

            # Composition companions
            pairs = conn.execute("""
                SELECT CASE WHEN func_a=? THEN func_b ELSE func_a END as companion,
                       cooccurrence, joint_success
                FROM function_pairs WHERE func_a=? OR func_b=?
                ORDER BY cooccurrence DESC LIMIT 5
            """, (func_name, func_name, func_name)).fetchall()
            if pairs:
                result["companions"] = [
                    {"name": r[0], "cooccurrence": r[1],
                     "success_rate": round(r[2] / max(r[1], 1), 3)}
                    for r in pairs
                ]

            # Version history
            versions = conn.execute("""
                SELECT version, quality_score, change_reason, created_at
                FROM function_versions WHERE func_name=?
                ORDER BY id DESC LIMIT 5
            """, (func_name,)).fetchall()
            if versions:
                result["versions"] = [
                    {"version": r[0], "quality": r[1], "reason": r[2], "date": r[3]}
                    for r in versions
                ]

            conn.close()
        except Exception as e:
            logger.debug(f"[FuncGraph] DB query failed: {e}")

        # Same-category siblings
        if tpl:
            cat = tpl.get("category", "")
            siblings = [
                v.get("function", k)
                for k, v in self._registry.items()
                if v.get("category") == cat and v.get("function") != func_name
            ]
            result["same_category"] = siblings[:10]

            # Type-compatible functions (output→input matching)
            my_return = tpl.get("returns", "")
            if my_return:
                compatible = []
                for k, v in self._registry.items():
                    if v.get("function") == func_name:
                        continue
                    params = v.get("parameters", {})
                    for ptype in params.values():
                        if _types_compatible(my_return, ptype):
                            compatible.append(v.get("function", k))
                            break
                result["type_compatible"] = compatible[:10]

        return result

    # ── Graph data for D3 visualization ───────────────────────────

    def get_graph_data(self) -> Dict[str, Any]:
        """D3-ready nodes and links for function relationship graph."""
        nodes = []
        links = []
        node_ids = set()

        # Category nodes
        cat_map: Dict[str, List[str]] = {}
        for key, tpl in self._registry.items():
            cat = tpl.get("category", "unknown")
            fname = tpl.get("function", key)
            cat_map.setdefault(cat, []).append(fname)

        for cat, funcs in cat_map.items():
            cat_id = f"cat_{cat}"
            meta = self._categories.get(cat, {})
            nodes.append({
                "id": cat_id,
                "label": meta.get("label", cat.replace("_", " ").title()),
                "type": "category",
                "count": len(funcs),
            })
            node_ids.add(cat_id)

            for fname in funcs:
                if fname not in node_ids:
                    nodes.append({
                        "id": fname,
                        "label": fname,
                        "type": "function",
                        "category": cat,
                    })
                    node_ids.add(fname)
                links.append({
                    "source": cat_id,
                    "target": fname,
                    "type": "belongs_to",
                })

        # Composition links from DB
        try:
            conn = self._db()
            pairs = conn.execute("""
                SELECT func_a, func_b, cooccurrence, joint_success
                FROM function_pairs WHERE cooccurrence >= 1
                ORDER BY cooccurrence DESC LIMIT 50
            """).fetchall()
            for fa, fb, co, js in pairs:
                # Ensure nodes exist
                for fn in (fa, fb):
                    if fn not in node_ids:
                        nodes.append({"id": fn, "label": fn, "type": "function", "category": "runtime"})
                        node_ids.add(fn)
                links.append({
                    "source": fa, "target": fb,
                    "type": "composed_with",
                    "weight": co,
                    "success_rate": round(js / max(co, 1), 3),
                })

            # Telemetry enrichment
            metrics = conn.execute("""
                SELECT func_name,
                       COUNT(*) as cnt,
                       ROUND(AVG(CASE WHEN success=1 THEN 1.0 ELSE 0.0 END), 3) as rate
                FROM function_metrics GROUP BY func_name
            """).fetchall()
            metric_map = {r[0]: {"calls": r[1], "success_rate": r[2]} for r in metrics}
            for node in nodes:
                if node["type"] == "function" and node["id"] in metric_map:
                    node["metrics"] = metric_map[node["id"]]

            conn.close()
        except Exception as e:
            logger.debug(f"[FuncGraph] Graph DB query failed: {e}")

        return {
            "nodes": nodes,
            "links": links,
            "stats": {
                "total_nodes": len(nodes),
                "total_links": len(links),
                "categories": len(cat_map),
                "functions": len([n for n in nodes if n["type"] == "function"]),
            },
        }


def _types_compatible(output_type: str, input_type: str) -> bool:
    """Check basic type compatibility between function output and input."""
    out = output_type.lower().strip()
    inp = input_type.lower().strip()
    # Direct match
    if out == inp:
        return True
    # Common compatible patterns
    compat = [
        ("dict", "dict"), ("dataframe", "dataframe"),
        ("list", "list"), ("str", "str"),
        ("tuple", "tuple"),
    ]
    for o, i in compat:
        if o in out and i in inp:
            return True
    return False
