#!/usr/bin/env python3
"""
AST 기반 코드 생성기 for FORGE System
들여쓰기 오류를 원천적으로 방지하는 구조적 코드 생성

주요 개선사항 (2025-08-23):
- 5줄 제한 제거: 전체 비즈니스 로직 활용
- 자가 수정 모듈 추가: 구문 에러 자동 수정
- logger 문장 보존: 디버깅 가능
"""

import ast
from typing import List, Dict, Any, Optional
from datetime import datetime
import textwrap
import asyncio
import json
from .smart_sample_generator import SmartSampleGenerator

class ForgeASTGenerator:
    """FORGE 시스템용 AST 코드 생성기"""
    
    def __init__(self, llm_client=None):
        self.imports = []
        self.class_methods = []
        self.additional_imports = []  # Store imports found in business logic
        self.agent_type = 'general'  # Store agent type for test samples
        self.sample_generator = SmartSampleGenerator(llm_client=llm_client)
        self.business_logic_text = ''  # Store business logic for sample generation
        self.query = ''  # Store original query for sample generation
        
    def create_logosai_agent_ast(
        self, 
        agent_name: str,
        agent_class_name: str,
        description: str,
        agent_type: str,
        business_logic_text: str = None
    ) -> str:
        """LogosAI 호환 에이전트 클래스를 AST로 생성"""
        
        # Store for test sample generation
        self.query = description
        self.business_logic_text = business_logic_text or ''
        self.agent_type = agent_type
        
        # Reset additional imports for each generation
        self.additional_imports = []
        
        # 1. Import statements
        imports = self._create_imports()
        
        # 2. Class definition (this will populate additional_imports if found)
        class_def = self._create_agent_class(
            agent_class_name,
            agent_name,
            description,
            agent_type,
            business_logic_text
        )
        
        # 3. Main block
        main_block = self._create_main_block()
        
        # 4. Combine into module (including additional imports found in business logic)
        module = ast.Module(
            body=imports + self.additional_imports + [class_def] + main_block,
            type_ignores=[]
        )
        
        # 5. Fix locations and convert to code
        ast.fix_missing_locations(module)
        
        # Python 3.9+ has ast.unparse, older versions need astor
        try:
            code = ast.unparse(module)
        except AttributeError:
            # Fallback for older Python versions
            import astor
            code = astor.to_source(module)
            
        return code
    
    def _create_imports(self) -> List[ast.stmt]:
        """필요한 import 문 생성"""
        imports = []
        
        # Standard imports
        imports.append(ast.Import(names=[ast.alias(name='asyncio', asname=None)]))
        imports.append(ast.Import(names=[ast.alias(name='json', asname=None)]))
        imports.append(ast.ImportFrom(
            module='typing',
            names=[
                ast.alias(name='Dict', asname=None),
                ast.alias(name='Any', asname=None),
                ast.alias(name='Optional', asname=None),
                ast.alias(name='List', asname=None)
            ],
            level=0
        ))
        imports.append(ast.ImportFrom(
            module='datetime',
            names=[ast.alias(name='datetime', asname=None)],
            level=0
        ))
        imports.append(ast.ImportFrom(
            module='loguru',
            names=[ast.alias(name='logger', asname=None)],
            level=0
        ))
        
        # LogosAI imports
        imports.append(ast.ImportFrom(
            module='logosai',
            names=[
                ast.alias(name='LogosAIAgent', asname=None),
                ast.alias(name='AgentConfig', asname=None),
                ast.alias(name='AgentType', asname=None),
                ast.alias(name='AgentResponse', asname=None),
                ast.alias(name='AgentResponseType', asname=None)
            ],
            level=0
        ))
        
        return imports
    
    def _create_agent_class(
        self,
        class_name: str,
        agent_name: str,
        description: str,
        agent_type: str,
        business_logic_text: str = None
    ) -> ast.ClassDef:
        # Store class name and type for use in methods
        self.agent_class_name = class_name
        self.agent_type = agent_type  # Store for test samples
        """에이전트 클래스 생성"""
        
        # Class docstring
        docstring = ast.Expr(value=ast.Constant(
            value=f"{agent_name} - LogosAI Agent\n{description}"
        ))
        
        # __init__ method
        init_method = self._create_init_method(agent_name, description, agent_type)
        
        # _process_core_logic method
        process_method = self._create_process_method(business_logic_text)
        
        # process method (main entry point)
        main_process_method = self._create_main_process_method()
        
        # Class definition
        class_def = ast.ClassDef(
            name=class_name,
            bases=[ast.Name(id='LogosAIAgent', ctx=ast.Load())],
            keywords=[],
            body=[docstring, init_method, process_method, main_process_method],
            decorator_list=[]
        )
        
        return class_def
    
    def _create_init_method(self, agent_name: str, description: str, agent_type: str) -> ast.FunctionDef:
        """__init__ 메서드 생성"""
        
        body = []
        
        # Config creation - Fix: Map agent_type to valid AgentType values
        # Map agent types to valid LogosAI AgentType enum values
        agent_type_mapping = {
            'calculator': 'GENERAL',
            'weather': 'GENERAL',
            'data_analysis': 'GENERAL',
            'api_integration': 'GENERAL',
            'automation': 'GENERAL',
            'general': 'GENERAL',
            'custom': 'CUSTOM'
        }
        
        mapped_agent_type = agent_type_mapping.get(agent_type.lower(), 'GENERAL')
        
        config_dict = ast.Dict(
            keys=[
                ast.Constant(value='name'),
                ast.Constant(value='description'),
                ast.Constant(value='agent_type'),
                ast.Constant(value='version')
            ],
            values=[
                ast.Constant(value=agent_name),
                ast.Constant(value=description),
                # Fixed: Use mapped agent type that exists in AgentType enum
                ast.Attribute(
                    value=ast.Name(id='AgentType', ctx=ast.Load()),
                    attr=mapped_agent_type,
                    ctx=ast.Load()
                ),
                ast.Constant(value='1.0.0')
            ]
        )
        
        # config = AgentConfig(**{...})
        body.append(ast.Assign(
            targets=[ast.Name(id='config', ctx=ast.Store())],
            value=ast.Call(
                func=ast.Name(id='AgentConfig', ctx=ast.Load()),
                args=[],
                keywords=[ast.keyword(arg=None, value=config_dict)]
            )
        ))
        
        # super().__init__(config)
        body.append(ast.Expr(value=ast.Call(
            func=ast.Attribute(
                value=ast.Call(
                    func=ast.Name(id='super', ctx=ast.Load()),
                    args=[],
                    keywords=[]
                ),
                attr='__init__',
                ctx=ast.Load()
            ),
            args=[ast.Name(id='config', ctx=ast.Load())],
            keywords=[]
        )))
        
        # logger.info(...)
        body.append(ast.Expr(value=ast.Call(
            func=ast.Attribute(
                value=ast.Name(id='logger', ctx=ast.Load()),
                attr='info',
                ctx=ast.Load()
            ),
            args=[ast.Constant(value=f'Initialized {self.agent_class_name}')],
            keywords=[]
        )))
        
        return ast.FunctionDef(
            name='__init__',
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg='self', annotation=None)],
                kwonlyargs=[],
                kw_defaults=[],
                defaults=[]
            ),
            body=body,
            decorator_list=[],
            returns=None
        )
    
    def _create_process_method(self, business_logic_text: str = None) -> ast.FunctionDef:
        """_process_core_logic 메서드 생성 - 비즈니스 로직 포함"""
        
        # Method docstring
        docstring = ast.Expr(value=ast.Constant(value="Core processing logic"))
        
        # Try block body
        try_body = []
        
        if business_logic_text and business_logic_text.strip():
            # LLM이 생성한 비즈니스 로직을 안전하게 처리
            try_body = self._safe_parse_business_logic(business_logic_text)
        else:
            # 기본 비즈니스 로직 (AST로 생성)
            try_body = self._create_default_business_logic()
        
        # Except handler
        except_handler = ast.ExceptHandler(
            type=ast.Name(id='Exception', ctx=ast.Load()),
            name='e',
            body=[
                ast.Expr(value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(id='logger', ctx=ast.Load()),
                        attr='error',
                        ctx=ast.Load()
                    ),
                    args=[ast.JoinedStr(values=[
                        ast.Constant(value='Error in core logic: '),
                        ast.FormattedValue(value=ast.Name(id='e', ctx=ast.Load()), conversion=-1)
                    ])],
                    keywords=[]
                )),
                ast.Raise(exc=None, cause=None)
            ]
        )
        
        # Try-except block
        try_except = ast.Try(
            body=try_body,
            handlers=[except_handler],
            orelse=[],
            finalbody=[]
        )
        
        # Method definition
        return ast.AsyncFunctionDef(
            name='_process_core_logic',
            args=ast.arguments(
                posonlyargs=[],
                args=[
                    ast.arg(arg='self', annotation=None),
                    ast.arg(arg='extracted_info', annotation=ast.Name(id='Any', ctx=ast.Load()))
                ],
                kwonlyargs=[],
                kw_defaults=[],
                defaults=[]
            ),
            body=[docstring, try_except],
            decorator_list=[],
            returns=ast.Name(id='Dict', ctx=ast.Load())
        )
    
    def _safe_parse_business_logic(self, logic_text: str) -> List[ast.stmt]:
        """비즈니스 로직 텍스트를 완전히 파싱하고 AST로 변환
        
        주요 개선사항:
        1. 전체 비즈니스 로직 활용 (5줄 제한 제거)
        2. logger 문장 보존
        3. 명확한 에러 처리
        """
        from loguru import logger
        
        # 빈 로직 처리
        if not logic_text or not logic_text.strip():
            logger.warning("비즈니스 로직이 비어있음 - 기본 로직 사용")
            return self._create_default_logic_ast()
        
        # 들여쓰기 정규화 (들여쓰기 구조 보존)
        lines = logic_text.strip().split('\n')
        normalized_lines = []
        
        # 최소 들여쓰기 찾기 (빈 줄 제외)
        min_indent = float('inf')
        for line in lines:
            if line.strip():  # 빈 줄이 아닌 경우
                # 현재 줄의 들여쓰기 계산
                indent = len(line) - len(line.lstrip())
                min_indent = min(min_indent, indent)
        
        # 최소 들여쓰기만큼 제거하여 정규화
        if min_indent == float('inf'):
            min_indent = 0
            
        for line in lines:
            if not line.strip():  # 빈 줄
                normalized_lines.append('')
            else:
                # 최소 들여쓰기만큼 제거하여 상대적 들여쓰기 보존
                if len(line) >= min_indent and line[:min_indent].strip() == '':
                    normalized_lines.append(line[min_indent:])
                else:
                    # 들여쓰기가 부족한 경우 그대로 사용
                    normalized_lines.append(line.strip())
        
        # 안전한 기본 로직으로 래핑
        safe_logic = []
        
        # data 변수 설정
        safe_logic.append(ast.Assign(
            targets=[ast.Name(id='data', ctx=ast.Store())],
            value=ast.IfExp(
                test=ast.Call(
                    func=ast.Name(id='isinstance', ctx=ast.Load()),
                    args=[
                        ast.Name(id='extracted_info', ctx=ast.Load()),
                        ast.Name(id='dict', ctx=ast.Load())
                    ],
                    keywords=[]
                ),
                body=ast.Name(id='extracted_info', ctx=ast.Load()),
                orelse=ast.Dict(
                    keys=[ast.Constant(value='input')],
                    values=[ast.Call(
                        func=ast.Name(id='str', ctx=ast.Load()),
                        args=[ast.Name(id='extracted_info', ctx=ast.Load())],
                        keywords=[]
                    )]
                )
            )
        ))
        
        # 전체 비즈니스 로직 파싱 (5줄 제한 제거!)
        added_vars = {'data', 'result'}
        if normalized_lines:
            # 전체 코드를 파싱 (제한 없음)
            full_code = '\n'.join(normalized_lines)  # 전체 사용!
            logger.info(f"🔄 전체 비즈니스 로직 파싱 시도: {len(full_code)} 문자")
            
            try:
                parsed = ast.parse(full_code)
                logger.info(f"✅ 파싱 성공: {len(parsed.body)} 노드")
                
                # 파싱된 코드 추가 (import 문 분리 및 중복 방지)
                for node in parsed.body:
                    # Import 문은 별도로 저장
                    if isinstance(node, (ast.Import, ast.ImportFrom)):
                        self.additional_imports.append(node)
                        logger.info(f"📦 Import 문 발견, 모듈 레벨로 이동: {ast.unparse(node) if hasattr(ast, 'unparse') else 'import'}")
                        continue
                    
                    if isinstance(node, ast.Assign):
                        # 변수 이름 확인하여 중복 방지
                        skip_node = False
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                if target.id in added_vars:
                                    skip_node = True
                                    break
                                added_vars.add(target.id)
                        if not skip_node:
                            safe_logic.append(node)
                    else:
                        # Assign이 아닌 모든 노드도 포함 (함수 호출, 조건문 등)
                        safe_logic.append(node)
                        
            except SyntaxError as e:
                # 구문 에러 시 자가 수정 시도
                logger.error(f"❌ 비즈니스 로직 파싱 실패: {e}")
                logger.info("🔧 자가 수정 시도...")
                
                # 자가 수정 시도
                fixed_code = self._attempt_self_healing(full_code, e)
                if fixed_code:
                    try:
                        parsed = ast.parse(fixed_code)
                        logger.info("✅ 자가 수정 성공!")
                        for node in parsed.body:
                            safe_logic.append(node)
                    except:
                        # 자가 수정도 실패 시 에러 발생
                        error_msg = f"비즈니스 로직 파싱 실패: {e}\n코드:\n{full_code[:500]}"
                        logger.error(error_msg)
                        # 에러를 발생시키지 않고 기본 로직 사용
                        logger.warning("⚠️ 기본 비즈니스 로직으로 fallback")
                else:
                    logger.warning("⚠️ 자가 수정 실패 - 기본 로직 사용")
            except Exception as e:
                # 기타 에러
                logger.error(f"❌ 예상치 못한 에러: {e}")
                logger.warning("⚠️ 기본 비즈니스 로직으로 fallback")
        
        # result 변수 설정 - 중복 방지 확인
        if 'result' not in added_vars or len(safe_logic) == 1:  # data만 있는 경우
            safe_logic.append(ast.Assign(
            targets=[ast.Name(id='result', ctx=ast.Store())],
            value=ast.Dict(
                keys=[
                    ast.Constant(value='status'),
                    ast.Constant(value='data'),
                    ast.Constant(value='timestamp'),
                    ast.Constant(value='message')
                ],
                values=[
                    ast.Constant(value='success'),
                    ast.Name(id='data', ctx=ast.Load()),
                    ast.Call(
                        func=ast.Attribute(
                            value=ast.Call(
                                func=ast.Attribute(
                                    value=ast.Name(id='datetime', ctx=ast.Load()),
                                    attr='now',
                                    ctx=ast.Load()
                                ),
                                args=[],
                                keywords=[]
                            ),
                            attr='isoformat',
                            ctx=ast.Load()
                        ),
                        args=[],
                        keywords=[]
                    ),
                    ast.Constant(value='Processing completed successfully')
                ]
            )
        ))
        
        # return result - only add if not already present
        has_return = any(isinstance(node, ast.Return) for node in safe_logic)
        if not has_return:
            safe_logic.append(ast.Return(value=ast.Name(id='result', ctx=ast.Load())))
        
        return safe_logic
    
    def _create_default_logic_ast(self) -> List[ast.stmt]:
        """기본 비즈니스 로직 AST 생성"""
        # 기본 result 딕셔너리 반환
        return [
            ast.Assign(
                targets=[ast.Name(id='result', ctx=ast.Store())],
                value=ast.Dict(
                    keys=[
                        ast.Constant(value='status'),
                        ast.Constant(value='data'),
                        ast.Constant(value='timestamp'),
                        ast.Constant(value='message')
                    ],
                    values=[
                        ast.Constant(value='success'),
                        ast.Name(id='data', ctx=ast.Load()),
                        ast.Call(
                            func=ast.Attribute(
                                value=ast.Call(
                                    func=ast.Attribute(
                                        value=ast.Name(id='datetime', ctx=ast.Load()),
                                        attr='now',
                                        ctx=ast.Load()
                                    ),
                                    args=[],
                                    keywords=[]
                                ),
                                attr='isoformat',
                                ctx=ast.Load()
                            ),
                            args=[],
                            keywords=[]
                        ),
                        ast.Constant(value='Default processing completed')
                    ]
                )
            ),
            ast.Return(value=ast.Name(id='result', ctx=ast.Load()))
        ]
    
    def _attempt_self_healing(self, code: str, error: SyntaxError) -> Optional[str]:
        """자가 수정 시도"""
        from loguru import logger
        
        try:
            # 들여쓰기 에러 수정
            if 'indent' in str(error).lower():
                logger.info("🔧 들여쓰기 에러 수정 시도...")
                return self._fix_indentation(code)
            
            # 괄호 불일치 수정
            if any(x in str(error) for x in ['(', ')', '[', ']', '{', '}']):
                logger.info("🔧 괄호 불일치 수정 시도...")
                return self._fix_brackets(code)
            
            # 콜론 누락 수정
            if ':' in str(error):
                logger.info("🔧 콜론 누락 수정 시도...")
                return self._fix_missing_colon(code)
            
            return None
        except:
            return None
    
    def _fix_indentation(self, code: str) -> str:
        """들여쓰기 자동 수정"""
        lines = code.split('\n')
        fixed_lines = []
        indent_level = 0
        
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                fixed_lines.append(line)
                continue
            
            # 들여쓰기 레벨 감소
            if stripped.startswith(('return', 'break', 'continue', 'pass')):
                fixed_lines.append('    ' * indent_level + stripped)
                if indent_level > 0:
                    indent_level -= 1
            # 들여쓰기 레벨 증가
            elif stripped.endswith(':'):
                fixed_lines.append('    ' * indent_level + stripped)
                indent_level += 1
            # elif, else, except, finally
            elif stripped.startswith(('elif ', 'else:', 'except:', 'finally:')):
                if indent_level > 0:
                    indent_level -= 1
                fixed_lines.append('    ' * indent_level + stripped)
                indent_level += 1
            else:
                fixed_lines.append('    ' * indent_level + stripped)
        
        return '\n'.join(fixed_lines)
    
    def _fix_brackets(self, code: str) -> str:
        """괄호 불일치 수정"""
        # 간단한 괄호 카운트 기반 수정
        open_parens = code.count('(')
        close_parens = code.count(')')
        
        if open_parens > close_parens:
            code += ')' * (open_parens - close_parens)
        elif close_parens > open_parens:
            code = '(' * (close_parens - open_parens) + code
        
        return code
    
    def _fix_missing_colon(self, code: str) -> str:
        """콜론 누락 수정"""
        lines = code.split('\n')
        fixed_lines = []
        
        for line in lines:
            stripped = line.strip()
            # if, for, while, def, class 등에서 콜론 누락 체크
            if any(stripped.startswith(kw) for kw in ['if ', 'for ', 'while ', 'def ', 'class ', 'try', 'except']):
                if not stripped.endswith(':'):
                    line = line + ':'
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _create_default_business_logic(self) -> List[ast.stmt]:
        """기본 비즈니스 로직 생성"""
        return self._safe_parse_business_logic("")
    
    def _create_main_process_method(self) -> ast.AsyncFunctionDef:
        """메인 process 메서드 생성"""
        
        body = []
        
        # Docstring
        body.append(ast.Expr(value=ast.Constant(
            value="Main entry point for agent processing"
        )))
        
        # Try block
        try_body = [
            # result = await self._process_core_logic(query)
            ast.Assign(
                targets=[ast.Name(id='result', ctx=ast.Store())],
                value=ast.Await(value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(id='self', ctx=ast.Load()),
                        attr='_process_core_logic',
                        ctx=ast.Load()
                    ),
                    args=[ast.Name(id='query', ctx=ast.Load())],
                    keywords=[]
                ))
            ),
            
            # return AgentResponse(...)
            ast.Return(value=ast.Call(
                func=ast.Name(id='AgentResponse', ctx=ast.Load()),
                args=[],
                keywords=[
                    ast.keyword(
                        arg='type',
                        value=ast.Attribute(
                            value=ast.Name(id='AgentResponseType', ctx=ast.Load()),
                            attr='SUCCESS',
                            ctx=ast.Load()
                        )
                    ),
                    ast.keyword(arg='content', value=ast.Name(id='result', ctx=ast.Load()))
                ]
            ))
        ]
        
        # Except handler
        except_handler = ast.ExceptHandler(
            type=ast.Name(id='Exception', ctx=ast.Load()),
            name='e',
            body=[
                ast.Return(value=ast.Call(
                    func=ast.Name(id='AgentResponse', ctx=ast.Load()),
                    args=[],
                    keywords=[
                        ast.keyword(
                            arg='type',
                            value=ast.Attribute(
                                value=ast.Name(id='AgentResponseType', ctx=ast.Load()),
                                attr='ERROR',
                                ctx=ast.Load()
                            )
                        ),
                        ast.keyword(
                            arg='content',
                            value=ast.Dict(
                                keys=[ast.Constant(value='error')],
                                values=[ast.Call(
                                    func=ast.Name(id='str', ctx=ast.Load()),
                                    args=[ast.Name(id='e', ctx=ast.Load())],
                                    keywords=[]
                                )]
                            )
                        )
                    ]
                ))
            ]
        )
        
        body.append(ast.Try(
            body=try_body,
            handlers=[except_handler],
            orelse=[],
            finalbody=[]
        ))
        
        return ast.AsyncFunctionDef(
            name='process',
            args=ast.arguments(
                posonlyargs=[],
                args=[
                    ast.arg(arg='self', annotation=None),
                    ast.arg(arg='query', annotation=ast.Name(id='str', ctx=ast.Load())),
                    ast.arg(
                        arg='context',
                        annotation=ast.Subscript(
                            value=ast.Name(id='Optional', ctx=ast.Load()),
                            slice=ast.Subscript(
                                value=ast.Name(id='Dict', ctx=ast.Load()),
                                slice=ast.Tuple(
                                    elts=[
                                        ast.Name(id='str', ctx=ast.Load()),
                                        ast.Name(id='Any', ctx=ast.Load())
                                    ],
                                    ctx=ast.Load()
                                ),
                                ctx=ast.Load()
                            ),
                            ctx=ast.Load()
                        )
                    )
                ],
                kwonlyargs=[],
                kw_defaults=[],
                defaults=[ast.Constant(value=None)]
            ),
            body=body,
            decorator_list=[],
            returns=ast.Name(id='AgentResponse', ctx=ast.Load())
        )
    
    def _create_main_block(self) -> List[ast.stmt]:
        """if __name__ == '__main__': 블록 생성 - 실제 테스트 샘플 포함"""
        
        # Get test samples based on agent type
        test_samples = self._get_test_samples_for_agent_type()
        
        # Create test function
        test_func_body = [
            # agent = AgentClass()
            ast.Assign(
                targets=[ast.Name(id='agent', ctx=ast.Store())],
                value=ast.Call(
                    func=ast.Name(id=self.agent_class_name, ctx=ast.Load()),
                    args=[],
                    keywords=[]
                )
            ),
            
            # Print header
            ast.Expr(value=ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[ast.Constant(value=f"\n{'='*60}\nTesting {self.agent_class_name}\n{'='*60}\n")],
                keywords=[]
            )),
            
            # Test samples
            ast.Assign(
                targets=[ast.Name(id='test_samples', ctx=ast.Store())],
                value=ast.List(
                    elts=[ast.Dict(
                        keys=[ast.Constant(value=k) for k in sample.keys()],
                        values=[ast.Constant(value=v) for v in sample.values()]
                    ) if isinstance(sample, dict) else ast.Constant(value=sample) 
                    for sample in test_samples],
                    ctx=ast.Load()
                )
            ),
            
            # For loop through samples
            ast.For(
                target=ast.Name(id='sample', ctx=ast.Store()),
                iter=ast.Name(id='test_samples', ctx=ast.Load()),
                body=[
                    # Print input
                    ast.Expr(value=ast.Call(
                        func=ast.Name(id='print', ctx=ast.Load()),
                        args=[ast.BinOp(
                            left=ast.Constant(value='📝 Input: '),
                            op=ast.Add(),
                            right=ast.Call(
                                func=ast.Name(id='str', ctx=ast.Load()),
                                args=[ast.Name(id='sample', ctx=ast.Load())],
                                keywords=[]
                            )
                        )],
                        keywords=[]
                    )),
                    
                    # Prepare input based on type
                    ast.Assign(
                        targets=[ast.Name(id='input_data', ctx=ast.Store())],
                        value=ast.IfExp(
                            test=ast.Call(
                                func=ast.Name(id='isinstance', ctx=ast.Load()),
                                args=[ast.Name(id='sample', ctx=ast.Load()), ast.Name(id='dict', ctx=ast.Load())],
                                keywords=[]
                            ),
                            body=ast.Call(
                                func=ast.Attribute(
                                    value=ast.Name(id='json', ctx=ast.Load()),
                                    attr='dumps',
                                    ctx=ast.Load()
                                ),
                                args=[ast.Name(id='sample', ctx=ast.Load())],
                                keywords=[ast.keyword(arg='ensure_ascii', value=ast.Constant(value=False))]
                            ),
                            orelse=ast.Name(id='sample', ctx=ast.Load())
                        )
                    ),
                    
                    # result = await agent.process(input_data)
                    ast.Assign(
                        targets=[ast.Name(id='result', ctx=ast.Store())],
                        value=ast.Await(value=ast.Call(
                            func=ast.Attribute(
                                value=ast.Name(id='agent', ctx=ast.Load()),
                                attr='process',
                                ctx=ast.Load()
                            ),
                            args=[ast.Name(id='input_data', ctx=ast.Load())],
                            keywords=[]
                        ))
                    ),
                    
                    # Print result
                    ast.Expr(value=ast.Call(
                        func=ast.Name(id='print', ctx=ast.Load()),
                        args=[ast.BinOp(
                            left=ast.Constant(value='✅ Result: '),
                            op=ast.Add(),
                            right=ast.Call(
                                func=ast.Name(id='str', ctx=ast.Load()),
                                args=[ast.Name(id='result', ctx=ast.Load())],
                                keywords=[]
                            )
                        )],
                        keywords=[]
                    )),
                    
                    # Print separator
                    ast.Expr(value=ast.Call(
                        func=ast.Name(id='print', ctx=ast.Load()),
                        args=[ast.Constant(value='-' * 60)],
                        keywords=[]
                    ))
                ],
                orelse=[]
            )
        ]
        
        # Create async test function
        test_func = ast.AsyncFunctionDef(
            name='test',
            args=ast.arguments(
                posonlyargs=[],
                args=[],
                kwonlyargs=[],
                kw_defaults=[],
                defaults=[]
            ),
            body=test_func_body,
            decorator_list=[],
            returns=None
        )
        
        # Main block
        test_body = [
            test_func,
            
            # asyncio.run(test())
            ast.Expr(value=ast.Call(
                func=ast.Attribute(
                    value=ast.Name(id='asyncio', ctx=ast.Load()),
                    attr='run',
                    ctx=ast.Load()
                ),
                args=[ast.Call(
                    func=ast.Name(id='test', ctx=ast.Load()),
                    args=[],
                    keywords=[]
                )],
                keywords=[]
            ))
        ]
        
        # if __name__ == '__main__':
        main_block = ast.If(
            test=ast.Compare(
                left=ast.Name(id='__name__', ctx=ast.Load()),
                ops=[ast.Eq()],
                comparators=[ast.Constant(value='__main__')]
            ),
            body=test_body,
            orelse=[]
        )
        
        return [main_block]
    
    def _get_test_samples_for_agent_type(self) -> List:
        """에이전트 타입에 따른 테스트 샘플 반환 - 스마트 샘플 생성기 활용"""
        
        # Try to use SmartSampleGenerator for dynamic samples
        try:
            # Check if there's already an event loop running
            try:
                loop = asyncio.get_running_loop()
                # If we're already in async context, create task
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        self.sample_generator.generate_samples(
                            agent_type=self.agent_type,
                            business_logic=self.business_logic_text,
                            query=self.query,
                            use_llm=bool(self.sample_generator.llm_client)
                        )
                    )
                    samples = future.result(timeout=10)
            except RuntimeError:
                # No event loop is running, create a new one
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    samples = loop.run_until_complete(
                        self.sample_generator.generate_samples(
                            agent_type=self.agent_type,
                            business_logic=self.business_logic_text,
                            query=self.query,
                            use_llm=bool(self.sample_generator.llm_client)
                        )
                    )
                finally:
                    loop.close()
            
            if samples:
                print(f"✅ Smart samples generated: {len(samples)} samples")
                return samples
                
        except Exception as e:
            # Log but don't fail - fall back to defaults
            print(f"⚠️ Smart sample generation failed: {e}, using defaults")
        
        # Fallback to static samples if smart generation fails
        # Sentiment analysis agent samples
        if 'sentiment' in self.agent_type.lower() or 'analysis' in self.agent_type.lower():
            return [
                {"text": "이 제품은 정말 훌륭합니다! 매우 만족스러워요."},
                {"text": "최악이에요. 다시는 구매하지 않을 거예요."},
                {"text": "그냥 평범해요. 특별할 것 없네요."},
                {"text": "This product is amazing! Best purchase ever!"},
                {"text": "Terrible experience, would not recommend."}
            ]
        
        # Calculator agent samples
        elif 'calculator' in self.agent_type.lower():
            return [
                {"expression": "2 + 2"},
                {"expression": "10 * 5"},
                {"expression": "100 / 4"},
                {"expression": "(5 + 3) * 2"}
            ]
        
        # Weather agent samples
        elif 'weather' in self.agent_type.lower():
            return [
                {"city": "Seoul"},
                {"city": "New York"},
                {"city": "Tokyo"}
            ]
        
        # Data analysis agent samples
        elif 'data' in self.agent_type.lower():
            return [
                {"data": [1, 2, 3, 4, 5], "operation": "mean"},
                {"data": [10, 20, 30], "operation": "sum"},
                {"data": [5, 5, 5], "operation": "median"}
            ]
        
        # News aggregator samples
        elif 'news' in self.agent_type.lower():
            return [
                {"topic": "technology", "limit": 5},
                {"topic": "business", "limit": 3},
                {"topic": "AI", "limit": 10}
            ]
        
        # Translator agent samples
        elif 'translator' in self.agent_type.lower():
            return [
                {"text": "Hello, how are you?", "target_language": "ko"},
                {"text": "안녕하세요", "target_language": "en"},
                {"text": "Bonjour", "target_language": "ja"}
            ]
        
        # Image analyzer samples
        elif 'image' in self.agent_type.lower():
            return [
                {"image_url": "https://example.com/sample1.jpg"},
                {"image_path": "/path/to/local/image.png"},
                {"image_base64": "base64_encoded_image_data..."}
            ]
        
        # API tester samples
        elif 'api' in self.agent_type.lower():
            return [
                {"url": "https://api.example.com/health", "method": "GET"},
                {"url": "https://api.example.com/data", "method": "POST", "data": {"key": "value"}}
            ]
        
        # Default generic samples
        else:
            return [
                "Test query 1",
                "Test query 2",
                {"input": "Test input", "type": "generic"},
                {"data": "Sample data for processing"}
            ]


def test_ast_generator():
    """AST 생성기 테스트"""
    generator = ForgeASTGenerator()
    
    # 테스트 비즈니스 로직 (문제가 될 수 있는 코드)
    problematic_logic = """
            logger.info("Processing financial data")  # 이 라인이 문제였음!
    data = extracted_info
    risk_score = calculate_risk(data)
    return {"status": "success", "risk": risk_score}
    """
    
    # AST로 안전하게 코드 생성
    code = generator.create_logosai_agent_ast(
        agent_name="Financial Risk Agent",
        agent_class_name="FinancialRiskAgent",
        description="Agent for financial risk analysis",
        agent_type="CUSTOM",
        business_logic_text=problematic_logic
    )
    
    print("Generated Code:")
    print("=" * 60)
    print(code)
    print("=" * 60)
    
    # 컴파일 테스트
    try:
        compile(code, '<string>', 'exec')
        print("✅ Code compiles successfully!")
    except SyntaxError as e:
        print(f"❌ Compilation error: {e}")
    
    return code


if __name__ == "__main__":
    print("🚀 Testing AST Code Generator for FORGE\n")
    test_ast_generator()