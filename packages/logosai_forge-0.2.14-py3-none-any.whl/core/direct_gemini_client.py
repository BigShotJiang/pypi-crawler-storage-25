"""
Direct Gemini API Client - bypasses LogosAI dependency issues
"""

import google.generativeai as genai
import os
import asyncio
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


class DirectGeminiClient:
    """Direct Gemini API client that works independently"""
    
    def __init__(self, model_name: str = "gemini-2.5-flash-lite", api_key: Optional[str] = None):
        """Initialize direct Gemini client"""
        self.model_name = model_name
        self.api_key = api_key or os.getenv('GOOGLE_API_KEY')
        
        if not self.api_key:
            raise ValueError("Google API key not found. Set GOOGLE_API_KEY environment variable.")
        
        # Configure Gemini
        genai.configure(api_key=self.api_key)
        
        # Initialize model
        self.model = genai.GenerativeModel(self.model_name)
        
        logger.info(f"DirectGeminiClient initialized with model: {self.model_name}")
    
    async def generate(self, prompt: str, **kwargs) -> str:
        """Generate response using Gemini API"""
        try:
            # Extract parameters
            temperature = kwargs.get('temperature', 0.7)
            max_tokens = kwargs.get('max_tokens', 15000)  # 충분한 토큰으로 증가
            
            # NOTE: Removed code block format instruction to prevent markdown artifacts
            # The FunctionGenerator's prompt already specifies the output format
            # and _extract_code_from_response handles markdown extraction
            
            # Generate response
            logger.debug(f"Generating response with Gemini {self.model_name}")
            logger.debug(f"Parameters - temperature: {temperature}, max_tokens: {max_tokens}")
            
            # Create generation config
            generation_config = genai.types.GenerationConfig(
                temperature=temperature,
                max_output_tokens=max_tokens if max_tokens else 15000,
            )

            # Run in thread pool to avoid blocking the event loop
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.model.generate_content(
                    prompt,
                    generation_config=generation_config
                )
            )

            # Extract text safely (handle safety filters, empty responses)
            try:
                if hasattr(response, 'text') and response.text:
                    result = response.text
                    logger.debug(f"Generated response: {len(result)} characters")
                    return result
            except ValueError:
                # finish_reason=SAFETY or no valid parts
                if response.candidates:
                    for part in response.candidates[0].content.parts:
                        if hasattr(part, 'text') and part.text:
                            return part.text

            logger.warning("No text in response")
            return ""
            
        except Exception as e:
            logger.error(f"Gemini generation failed: {e}")
            raise
    
    # Compatibility methods for LogosAI interface
    async def invoke(self, prompt: str, **kwargs) -> str:
        """Compatibility method for LogosAI interface"""
        return await self.generate(prompt, **kwargs)
    
    async def invoke_messages(self, messages, **kwargs):
        """Compatibility method for message-based interface"""
        # Convert messages to single prompt without "role:" prefix for Gemini
        if isinstance(messages, list):
            # Gemini doesn't need role prefixes - just combine the content
            parts = []
            for msg in messages:
                content = msg.get('content', '')
                role = msg.get('role', 'user')
                
                # Add appropriate formatting based on role
                if role == 'system':
                    # System messages get special formatting
                    parts.append(f"Instructions: {content}")
                else:
                    # User and assistant messages are just content
                    parts.append(content)
            
            prompt = "\n\n".join(parts)
        else:
            prompt = str(messages)
        
        result = await self.generate(prompt, **kwargs)
        
        # Return object with content attribute
        class Response:
            def __init__(self, content):
                self.content = content
        
        return Response(result)