"""
Forge AI Unified Logging System
실시간 모니터링 및 스트리밍을 위한 통합 로깅 시스템
"""

import logging
import json
import asyncio
import time
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from enum import Enum
import sys
from collections import deque
import threading

class LogLevel(Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"
    PROGRESS = "PROGRESS"  # 진행상황 전용

@dataclass
class LogEntry:
    """구조화된 로그 엔트리"""
    timestamp: str
    level: str
    module: str
    phase: str
    message: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    progress: Optional[float] = None  # 0-100 진행률
    duration_ms: Optional[int] = None

class StreamingLogger:
    """실시간 스트리밍을 지원하는 로거"""
    
    def __init__(self, 
                 name: str,
                 log_dir: str = "forge/logs",
                 max_buffer_size: int = 1000):
        self.name = name
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # 로그 파일 설정
        self.log_file = self.log_dir / f"{name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
        
        # 스트리밍 버퍼
        self.buffer = deque(maxlen=max_buffer_size)
        self.subscribers: List[Callable] = []
        
        # 성능 메트릭
        self.phase_timers: Dict[str, float] = {}
        self.metrics: Dict[str, Any] = {
            "total_logs": 0,
            "errors": 0,
            "warnings": 0,
            "average_duration": 0,
            "phases_completed": []
        }
        
        # 로거 설정
        self._setup_logger()
        
    def _setup_logger(self):
        """Python 로거 설정"""
        self.logger = logging.getLogger(self.name)
        self.logger.setLevel(logging.DEBUG)
        
        # 콘솔 핸들러
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        
        # 파일 핸들러 (JSON Lines)
        file_handler = logging.FileHandler(self.log_file)
        file_handler.setLevel(logging.DEBUG)
        
        # 포맷터
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - [%(levelname)s] %(message)s'
        )
        console_handler.setFormatter(console_formatter)
        
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)
        
    def log(self, 
            level: LogLevel,
            module: str,
            phase: str,
            message: str,
            metadata: Optional[Dict[str, Any]] = None,
            progress: Optional[float] = None):
        """구조화된 로그 생성"""
        
        # 타이밍 계산
        duration_ms = None
        if phase in self.phase_timers:
            duration_ms = int((time.time() - self.phase_timers[phase]) * 1000)
        
        # 로그 엔트리 생성
        entry = LogEntry(
            timestamp=datetime.now().isoformat(),
            level=level.value,
            module=module,
            phase=phase,
            message=message,
            metadata=metadata or {},
            progress=progress,
            duration_ms=duration_ms
        )
        
        # 메트릭 업데이트
        self._update_metrics(entry)
        
        # 로그 기록
        self._write_log(entry)
        
        # 스트리밍
        self._stream_log(entry)
        
        return entry
    
    def start_phase(self, phase: str):
        """특정 단계 시작 기록"""
        self.phase_timers[phase] = time.time()
        self.log(
            LogLevel.INFO,
            module=self.name,
            phase=phase,
            message=f"Phase '{phase}' started",
            progress=0
        )
    
    def end_phase(self, phase: str, success: bool = True):
        """특정 단계 종료 기록"""
        if phase in self.phase_timers:
            duration = int((time.time() - self.phase_timers[phase]) * 1000)
            status = "completed" if success else "failed"
            
            self.log(
                LogLevel.INFO if success else LogLevel.ERROR,
                module=self.name,
                phase=phase,
                message=f"Phase '{phase}' {status}",
                metadata={"duration_ms": duration},
                progress=100 if success else None
            )
            
            del self.phase_timers[phase]
            self.metrics["phases_completed"].append(phase)
    
    def progress(self, phase: str, current: int, total: int, message: str = ""):
        """진행 상황 업데이트"""
        if total > 0:
            progress = (current / total) * 100
            self.log(
                LogLevel.PROGRESS,
                module=self.name,
                phase=phase,
                message=message or f"Progress: {current}/{total}",
                metadata={"current": current, "total": total},
                progress=progress
            )
    
    def _write_log(self, entry: LogEntry):
        """로그를 파일에 기록"""
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(asdict(entry), ensure_ascii=False) + '\n')
        
        # Python 로거에도 기록
        log_level = getattr(logging, entry.level, logging.INFO)
        self.logger.log(log_level, entry.message)
    
    def _stream_log(self, entry: LogEntry):
        """구독자들에게 로그 스트리밍"""
        self.buffer.append(entry)
        
        # 모든 구독자에게 전송
        for subscriber in self.subscribers:
            try:
                subscriber(entry)
            except Exception as e:
                self.logger.error(f"Failed to stream to subscriber: {e}")
    
    def _update_metrics(self, entry: LogEntry):
        """메트릭 업데이트"""
        self.metrics["total_logs"] += 1
        
        if entry.level == LogLevel.ERROR.value:
            self.metrics["errors"] += 1
        elif entry.level == LogLevel.WARNING.value:
            self.metrics["warnings"] += 1
        
        if entry.duration_ms:
            # 평균 소요 시간 계산 (누적 평균)
            current_avg = self.metrics["average_duration"]
            total = self.metrics["total_logs"]
            self.metrics["average_duration"] = (
                (current_avg * (total - 1) + entry.duration_ms) / total
            )
    
    def subscribe(self, callback: Callable[[LogEntry], None]):
        """로그 스트리밍 구독"""
        self.subscribers.append(callback)
    
    def unsubscribe(self, callback: Callable):
        """구독 해제"""
        if callback in self.subscribers:
            self.subscribers.remove(callback)
    
    def get_recent_logs(self, count: int = 100) -> List[LogEntry]:
        """최근 로그 조회"""
        return list(self.buffer)[-count:]
    
    def get_metrics(self) -> Dict[str, Any]:
        """현재 메트릭 조회"""
        return self.metrics.copy()
    
    def clear_metrics(self):
        """메트릭 초기화"""
        self.metrics = {
            "total_logs": 0,
            "errors": 0,
            "warnings": 0,
            "average_duration": 0,
            "phases_completed": []
        }

class ForgeLogManager:
    """Forge AI 전체 로깅 관리자"""
    
    def __init__(self):
        self.loggers: Dict[str, StreamingLogger] = {}
        self.global_subscribers: List[Callable] = []
        
    def get_logger(self, name: str) -> StreamingLogger:
        """모듈별 로거 생성/조회"""
        if name not in self.loggers:
            logger = StreamingLogger(name)
            # 전역 구독자 등록
            for subscriber in self.global_subscribers:
                logger.subscribe(subscriber)
            self.loggers[name] = logger
        
        return self.loggers[name]
    
    def subscribe_all(self, callback: Callable):
        """모든 로거에 구독"""
        self.global_subscribers.append(callback)
        for logger in self.loggers.values():
            logger.subscribe(callback)
    
    def get_all_metrics(self) -> Dict[str, Any]:
        """모든 모듈의 메트릭 조회"""
        return {
            name: logger.get_metrics()
            for name, logger in self.loggers.items()
        }
    
    async def stream_logs_async(self, websocket):
        """WebSocket을 통한 실시간 스트리밍"""
        def send_log(entry: LogEntry):
            asyncio.create_task(
                websocket.send_json(asdict(entry))
            )
        
        self.subscribe_all(send_log)

# 전역 로그 매니저 인스턴스
log_manager = ForgeLogManager()

def get_logger(name: str) -> StreamingLogger:
    """로거 인스턴스 획득"""
    return log_manager.get_logger(name)