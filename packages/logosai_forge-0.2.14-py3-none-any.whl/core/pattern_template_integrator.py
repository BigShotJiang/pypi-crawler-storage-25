"""
🔗 Pattern Template Integrator
패턴 기반 시스템과 기존 템플릿 시스템을 통합하는 핵심 어댑터

역할:
1. Business Patterns Implementation 시스템의 결과를 FORGE AI 형식으로 변환
2. 기존 템플릿 변수 치환 실패 문제 해결
3. 메타데이터 보강 및 품질 보증
4. 점진적 전환을 위한 Feature Flag 지원
"""

import sys
import os
import asyncio
import uuid
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from loguru import logger

# Business Patterns Implementation 시스템 임포트
patterns_impl_path = os.path.join(os.path.dirname(__file__), '../business_patterns_implementation')
if os.path.exists(patterns_impl_path):
    sys.path.insert(0, patterns_impl_path)
    
    try:
        # 직접 import로 충돌 방지
        import importlib.util
        
        # SmartPatternSelector 임포트
        selector_spec = importlib.util.spec_from_file_location(
            "smart_pattern_selector", 
            os.path.join(patterns_impl_path, "selectors", "smart_pattern_selector.py")
        )
        selector_module = importlib.util.module_from_spec(selector_spec)
        selector_spec.loader.exec_module(selector_module)
        SmartPatternSelector = selector_module.SmartPatternSelector
        
        # PatternCodeGenerator 임포트  
        generator_spec = importlib.util.spec_from_file_location(
            "pattern_code_generator", 
            os.path.join(patterns_impl_path, "generators", "pattern_code_generator.py")
        )
        generator_module = importlib.util.module_from_spec(generator_spec)
        generator_spec.loader.exec_module(generator_module)
        PatternCodeGenerator = generator_module.PatternCodeGenerator
        CodeExecutionContext = generator_module.CodeExecutionContext
        
        PATTERNS_AVAILABLE = True
        logger.info("✅ Business Patterns Implementation system loaded successfully")
        
    except Exception as e:
        logger.warning(f"⚠️ Business Patterns Implementation system not available: {e}")
        PATTERNS_AVAILABLE = False
        SmartPatternSelector = None
        PatternCodeGenerator = None
        CodeExecutionContext = None
else:
    PATTERNS_AVAILABLE = False
    logger.warning("⚠️ Business Patterns Implementation directory not found")


class PatternTemplateIntegrator:
    """
    패턴 시스템과 템플릿 시스템을 통합하는 핵심 어댑터
    
    기존 TemplateBasedGenerator.generate_business_logic()를 대체하여
    우리의 패턴 기반 시스템 결과를 FORGE AI 템플릿 시스템 형식으로 변환
    """
    
    def __init__(self):
        self.integration_id = str(uuid.uuid4())[:8]
        
        # 패턴 시스템 초기화
        if PATTERNS_AVAILABLE:
            self.pattern_selector = SmartPatternSelector()
            self.code_generator = PatternCodeGenerator()
            self.patterns_enabled = True
            logger.info(f"🔗 PatternTemplateIntegrator initialized with patterns support [ID: {self.integration_id}]")
        else:
            self.pattern_selector = None
            self.code_generator = None
            self.patterns_enabled = False
            logger.warning(f"🔗 PatternTemplateIntegrator initialized WITHOUT patterns support [ID: {self.integration_id}]")
        
        # 통합 통계
        self.integration_stats = {
            'total_requests': 0,
            'pattern_system_used': 0,
            'legacy_fallback': 0,
            'success_rate': 0.0,
            'avg_execution_time': 0.0
        }
    
    async def enhanced_generate_business_logic(self, 
                                             template_id: str, 
                                             user_request: str, 
                                             llm_client: Any) -> Dict[str, Any]:
        """
        기존 generate_business_logic()를 대체하는 통합 메서드
        
        패턴 시스템 우선 사용 → 실패시 레거시 폴백 → 메타데이터 보강
        """
        start_time = datetime.now()
        self.integration_stats['total_requests'] += 1
        
        logger.info(f"🔗 [Integration-{self.integration_id}] Enhanced business logic generation started")
        logger.info(f"  📋 Template: {template_id}")
        logger.info(f"  📝 Request: {user_request[:100]}...")
        
        try:
            # Phase 1: 패턴 시스템 사용 여부 결정
            if self._should_use_pattern_system(template_id, user_request):
                logger.info("🆕 Using Pattern-Based Business Logic System")
                
                try:
                    # Phase 2: 패턴 기반 비즈니스 로직 생성
                    pattern_result = await self._generate_with_patterns(
                        template_id, user_request, llm_client
                    )
                    
                    # Phase 3: 템플릿 시스템 형식으로 변환
                    business_logic = await self._convert_to_template_format(
                        pattern_result, template_id, user_request
                    )
                    
                    # Phase 4: 메타데이터 보강 (실패 원인 해결)
                    enhanced_logic = self._enhance_metadata(
                        business_logic, template_id, user_request
                    )
                    
                    # Phase 5: 품질 검증
                    if self._validate_business_logic(enhanced_logic):
                        execution_time = (datetime.now() - start_time).total_seconds()
                        self.integration_stats['pattern_system_used'] += 1
                        self._update_success_metrics(execution_time, True)
                        
                        logger.info(f"✅ Pattern system succeeded in {execution_time:.2f}s")
                        return enhanced_logic
                    else:
                        logger.warning("⚠️ Pattern system result failed validation, falling back")
                        
                except Exception as e:
                    logger.error(f"❌ Pattern system failed: {e}")
                    logger.info("🔄 Falling back to legacy system...")
            
            # Phase 6: 레거시 시스템 폴백
            logger.info("🔄 Using Legacy Business Logic System")
            legacy_result = await self._legacy_fallback(template_id, user_request, llm_client)
            
            # 레거시 결과도 메타데이터 보강
            enhanced_legacy = self._enhance_metadata(legacy_result, template_id, user_request)
            
            execution_time = (datetime.now() - start_time).total_seconds()
            self.integration_stats['legacy_fallback'] += 1
            self._update_success_metrics(execution_time, False)
            
            logger.info(f"✅ Legacy system completed in {execution_time:.2f}s")
            return enhanced_legacy
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            logger.error(f"💥 Integration failed after {execution_time:.2f}s: {e}")
            
            # 최후 응급 처치
            return self._generate_emergency_business_logic(template_id, user_request)
    
    def _should_use_pattern_system(self, template_id: str, user_request: str) -> bool:
        """패턴 시스템 사용 여부 결정"""
        
        if not self.patterns_enabled:
            return False
        
        # Feature Flag 확인
        if os.getenv('FORGE_DISABLE_PATTERNS', 'false').lower() == 'true':
            return False
        
        user_request_lower = user_request.lower()
        
        # 데이터 분석 관련 키워드
        data_keywords = [
            'csv', 'excel', '데이터', '분석', 'analysis', '차트', 'chart', 
            '대시보드', 'dashboard', '시각화', '통계', '상관관계', '예측', 'prediction'
        ]
        
        # 비즈니스 로직 패턴 키워드  
        business_keywords = [
            '고객', 'customer', '세그멘테이션', 'segmentation', '위험', 'risk',
            'kpi', '모니터링', 'monitoring', '금융', 'financial', 'rfm'
        ]
        
        # 복잡한 로직 키워드
        complex_keywords = [
            '포트폴리오', 'portfolio', 'var', '클러스터링', 'clustering',
            '트렌드', 'trend', '품질', 'quality', '이상치', 'outlier'
        ]
        
        # 🔧 NEW: AutoML/ML 관련 키워드
        automl_keywords = [
            'ml', 'ML', '머신러닝', 'machine learning', 'automl', 'AutoML',
            '알고리즘', 'algorithm', '모델', 'model', 'modeling',
            '하이퍼파라미터', 'hyperparameter', '튜닝', 'tuning', 'optimization',
            '성능', 'performance', '평가', 'evaluation', 'validation',
            '배포', 'deployment', '학습', 'training', 'sklearn', 'scikit-learn',
            'classification', '분류', 'regression', '회귀', '앙상블', 'ensemble'
        ]
        
        all_keywords = data_keywords + business_keywords + complex_keywords + automl_keywords
        matched_keywords = [kw for kw in all_keywords if kw in user_request_lower]
        
        should_use = len(matched_keywords) >= 2  # 최소 2개 키워드 매칭
        
        logger.info(f"🤖 Pattern system decision: {'YES' if should_use else 'NO'}")
        if should_use:
            logger.info(f"   Matched keywords: {matched_keywords}")
        
        return should_use
    
    async def _generate_with_patterns(self, template_id: str, 
                                    user_request: str, 
                                    llm_client: Any) -> Dict[str, Any]:
        """패턴 기반 시스템으로 비즈니스 로직 생성"""
        
        logger.info("🧠 Analyzing query with Smart Pattern Selector...")
        
        # Step 1: 지능적 패턴 선택
        selection_result = self.pattern_selector.select_optimal_patterns(
            user_request, max_patterns=4, time_constraint=None
        )
        
        if not selection_result['selected_patterns']:
            raise Exception("No patterns selected")
        
        logger.info(f"✅ Selected {len(selection_result['selected_patterns'])} patterns:")
        for pattern in selection_result['selected_patterns']:
            logger.info(f"   - {pattern}")
        
        # Step 2: 패턴별 코드 생성
        logger.info("🏭 Generating pattern-based code...")
        
        context = CodeExecutionContext(
            data_variable_name="extracted_info",
            enable_visualization=True,
            enable_logging=True
        )
        
        generated_codes = self.code_generator.generate_multiple_patterns_code(
            pattern_ids=selection_result['selected_patterns'],
            context=context,
            query_analysis=selection_result['query_analysis']
        )
        
        total_code_length = sum(len(code.code_content) for code in generated_codes)
        logger.info(f"✅ Generated {total_code_length:,} characters of code across {len(generated_codes)} patterns")
        
        # 패턴별 코드를 하나의 비즈니스 로직으로 결합
        combined_business_logic = self._combine_pattern_codes(generated_codes)
        
        return {
            'selection_result': selection_result,
            'generated_codes': generated_codes,
            'total_code_length': total_code_length,
            'confidence_score': selection_result['confidence_score'],
            'combined_business_logic': combined_business_logic
        }
    
    def _combine_pattern_codes(self, generated_codes) -> str:
        """여러 패턴 코드를 하나의 비즈니스 로직으로 결합"""
        combined_lines = []
        
        # 모든 패턴 코드를 순차적으로 결합
        for i, code in enumerate(generated_codes):
            if i > 0:
                combined_lines.append("\n# " + "="*60)
                combined_lines.append(f"# Pattern {i+1}: {code.pattern_id}")
                combined_lines.append("# " + "="*60 + "\n")
            
            # 코드 내용 추가 (code_content 또는 code 사용)
            code_content = code.code_content if hasattr(code, 'code_content') else code.code
            combined_lines.append(code_content)
        
        return "\n".join(combined_lines)
    
    async def _convert_to_template_format(self, pattern_result: Dict[str, Any], 
                                        template_id: str, 
                                        user_request: str) -> Dict[str, Any]:
        """패턴 시스템 결과를 FORGE AI 템플릿 시스템 형식으로 변환"""
        
        logger.info("🔄 Converting pattern results to template format...")
        
        generated_codes = pattern_result['generated_codes']
        selection_result = pattern_result['selection_result']
        
        # 패턴별 코드를 템플릿 섹션으로 매핑
        combined_logic = []
        combined_imports = set()
        
        for i, code in enumerate(generated_codes):
            # 각 패턴의 코드를 함수로 래핑
            function_name = f"execute_{code.pattern_id}"
            
            wrapped_code = f"""
    async def {function_name}(self, extracted_info):
        \"\"\"
        {code.description}
        Generated by Pattern: {code.pattern_id}
        \"\"\"
{self._indent_code(code.code_content, 8)}
        
        return result
"""
            combined_logic.append(wrapped_code)
            combined_imports.update(code.imports)
        
        # 메인 실행 로직 생성
        pattern_calls = []
        for code in generated_codes:
            function_name = f"execute_{code.pattern_id}"
            pattern_calls.append(f"""
        # Execute {code.pattern_id}
        {code.pattern_id}_result = await self.{function_name}(extracted_info)
        results['{code.pattern_id}'] = {code.pattern_id}_result""")
        
        main_logic = f"""
    async def process_main_logic(self, extracted_info):
        \"\"\"
        Main business logic orchestrator
        Generated by Pattern Template Integrator
        \"\"\"
        results = {{}}
        
        try:
{"".join(pattern_calls)}
            
            # Generate comprehensive insights
            insights = self._generate_combined_insights(results)
            
            return {{
                'status': 'success',
                'results': results,
                'insights': insights,
                'patterns_used': {selection_result['selected_patterns']},
                'confidence_score': {pattern_result['confidence_score']:.3f}
            }}
            
        except Exception as e:
            logger.error(f"Pattern execution failed: {{e}}")
            return {{
                'status': 'error',
                'error': str(e),
                'partial_results': results
            }}
    
    def _generate_combined_insights(self, results):
        \"\"\"Generate combined insights from all pattern results\"\"\"
        insights = []
        
        for pattern_name, result in results.items():
            if isinstance(result, dict) and 'insights' in result:
                result_insights = result['insights']
                if isinstance(result_insights, list):
                    insights.extend([f"[{pattern_name.replace('_', ' ').title()}] {insight_text}" for insight_text in result_insights])
                elif isinstance(result_insights, str):
                    insights.append(f"[{pattern_name.replace('_', ' ').title()}] {result_insights}")
        
        return insights
"""
        
        # 전체 프로세스 로직 조합
        process_logic = "".join(combined_logic) + main_logic
        
        # 초기화 로직
        init_logic = """
        # Pattern-based system initialization
        self.pattern_results = {}
        self.confidence_score = 0.0
        
        logger.info("🆕 Pattern-based agent initialized")
        logger.info(f"🎯 Patterns: {', '.join(self.get_supported_patterns())}")
"""
        
        # 샘플 코드 생성
        sample_code = self._generate_sample_code(generated_codes, user_request)
        
        # FORGE AI 템플릿 형식으로 변환
        template_format = {
            'process_logic': process_logic,
            'init_logic': init_logic,
            'sample_code': sample_code,
            'imports': list(combined_imports),
            'patterns_used': selection_result['selected_patterns'],
            'generation_method': 'pattern_based',
            'confidence_score': pattern_result['confidence_score'],
            'business_logic': pattern_result.get('combined_business_logic', process_logic)  # 실제 비즈니스 로직 추가
        }
        
        logger.info(f"✅ Converted to template format: {len(process_logic)} chars process_logic")
        logger.info(f"✅ Business logic: {len(template_format.get('business_logic', '')):,} chars")
        
        return template_format
    
    def _enhance_metadata(self, business_logic: Dict[str, Any], 
                         template_id: str, user_request: str) -> Dict[str, Any]:
        """메타데이터 보강으로 템플릿 변수 치환 실패 문제 해결"""
        
        logger.info("🏷️ Enhancing metadata...")
        
        # 기존 비즈니스 로직 복사
        enhanced = business_logic.copy()
        
        # 🔑 핵심: 누락되는 필수 메타데이터들 보강
        enhanced.update({
            # 에이전트 클래스 이름 생성
            'agent_class_name': self._generate_agent_class_name(user_request),
            
            # 커스텀 설정 생성
            'custom_config': self._generate_custom_config(template_id, user_request),
            
            # 설명 및 문서화
            'agent_description': self._generate_agent_description(user_request),
            
            # 에이전트 버전 및 메타데이터
            'agent_version': '1.0.0',
            'generated_at': datetime.now().isoformat(),
            'template_id': template_id,
            'integration_id': self.integration_id,
            
            # 추가 설정
            'supported_formats': ['json', 'csv', 'excel'],
            'default_timeout': 300,
            'enable_logging': True,
            
            # 패턴 관련 메타데이터 (있는 경우)
            'patterns_metadata': enhanced.get('patterns_used', []),
            'generation_confidence': enhanced.get('confidence_score', 0.5)
        })
        
        # 빈 값들을 기본값으로 대체
        for key, value in enhanced.items():
            if value is None or value == '':
                if key.endswith('_logic'):
                    enhanced[key] = '# Auto-generated placeholder logic\npass'
                elif key.endswith('_code'):
                    enhanced[key] = '# Sample code placeholder\nprint("Agent ready")'
                else:
                    enhanced[key] = f'auto_generated_{key}'
        
        logger.info(f"✅ Enhanced metadata: {len(enhanced)} fields total")
        logger.info(f"   🎯 Agent class: {enhanced['agent_class_name']}")
        logger.info(f"   📝 Description: {enhanced['agent_description'][:50]}...")
        
        return enhanced
    
    def _generate_agent_class_name(self, user_request: str) -> str:
        """사용자 요청으로부터 적절한 에이전트 클래스명 생성"""
        
        # 키워드 기반 클래스명 생성
        request_lower = user_request.lower()
        
        if any(kw in request_lower for kw in ['csv', 'excel', '데이터']):
            base_name = 'DataAnalysis'
        elif any(kw in request_lower for kw in ['고객', 'customer']):
            base_name = 'Customer'
        elif any(kw in request_lower for kw in ['금융', 'financial', '위험', 'risk']):
            base_name = 'Financial'
        elif any(kw in request_lower for kw in ['대시보드', 'dashboard', 'kpi']):
            base_name = 'Dashboard'
        elif any(kw in request_lower for kw in ['모니터링', 'monitoring']):
            base_name = 'Monitoring'
        else:
            base_name = 'Smart'
        
        return f"{base_name}Agent"
    
    def _generate_custom_config(self, template_id: str, user_request: str) -> str:
        """템플릿과 요청에 맞는 커스텀 설정 생성"""
        
        config_dict = {
            'template_id': template_id,
            'auto_generated': True,
            'supports_streaming': True,
            'max_retries': 3,
            'timeout_seconds': 300
        }
        
        # 요청 내용에 따른 특화 설정
        request_lower = user_request.lower()
        
        if 'csv' in request_lower or 'excel' in request_lower:
            config_dict['supported_formats'] = ['csv', 'xlsx', 'json']
            config_dict['max_file_size'] = '50MB'
        
        if 'real' in request_lower or '실시간' in request_lower:
            config_dict['realtime_mode'] = True
            config_dict['update_interval'] = 60
        
        if '대시보드' in request_lower or 'dashboard' in request_lower:
            config_dict['enable_visualization'] = True
            config_dict['chart_types'] = ['line', 'bar', 'scatter', 'heatmap']
        
        return str(config_dict)
    
    def _generate_agent_description(self, user_request: str) -> str:
        """사용자 요청으로부터 에이전트 설명 생성"""
        
        # 요청을 요약하여 설명 생성
        description = f"AI Agent generated from user request: {user_request[:100]}"
        
        if len(user_request) > 100:
            description += "..."
        
        description += f" | Generated at {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        description += f" | Integration ID: {self.integration_id}"
        
        return description
    
    def _generate_sample_code(self, generated_codes: List[Any], user_request: str) -> str:
        """패턴 코드들로부터 샘플 코드 생성"""
        
        sample_code = f'''
# Generated Sample Code for Pattern-Based Agent
# User Request: {user_request[:100]}...

import pandas as pd
import numpy as np
from datetime import datetime

# Initialize agent
agent = AgentClass()

# Sample data preparation
data = {{
    'sample_data': 'This is sample data for testing',
    'timestamp': datetime.now(),
    'status': 'ready'
}}

# Execute main logic
try:
    result = await agent.process_main_logic(data)
    print("Agent execution successful:")
    print(f"Status: {{result.get('status', 'unknown')}}")
    
    if 'insights' in result:
        print("Generated Insights:")
        for insight in result['insights'][:3]:  # Show first 3 insights
            print(f"  - {{insight}}")
    
    print(f"Confidence Score: {{result.get('confidence_score', 0.0):.2f}}")
    
except Exception as e:
    print(f"Agent execution failed: {{e}}")

# Sample usage with different data types
sample_csv_data = pd.DataFrame({{
    'column1': [1, 2, 3, 4, 5],
    'column2': ['A', 'B', 'C', 'D', 'E'],
    'values': [10, 20, 30, 40, 50]
}})

print("Sample CSV data shape:", sample_csv_data.shape)
'''
        
        return sample_code
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """코드 들여쓰기"""
        lines = code.strip().split('\n')
        indent = ' ' * spaces
        return '\n'.join(indent + line if line.strip() else line for line in lines)
    
    def _validate_business_logic(self, business_logic: Dict[str, Any]) -> bool:
        """비즈니스 로직 품질 검증"""
        
        required_fields = ['process_logic', 'agent_class_name', 'custom_config']
        
        for field in required_fields:
            if field not in business_logic or not business_logic[field]:
                logger.warning(f"❌ Validation failed: missing {field}")
                return False
        
        # 코드 길이 확인
        if len(business_logic.get('process_logic', '')) < 100:
            logger.warning("❌ Validation failed: process_logic too short")
            return False
        
        logger.info("✅ Business logic validation passed")
        return True
    
    async def _legacy_fallback(self, template_id: str, 
                             user_request: str, llm_client: Any) -> Dict[str, Any]:
        """레거시 시스템 폴백"""
        
        logger.info("🔄 Executing legacy fallback...")
        
        # 기본적인 비즈니스 로직 생성 (간단한 구현)
        return {
            'process_logic': f'''
    async def process_main_logic(self, extracted_info):
        """
        Legacy fallback business logic
        Template: {template_id}
        """
        try:
            # Basic processing logic
            result = {{
                'status': 'success',
                'message': 'Legacy system processing completed',
                'data': extracted_info,
                'processed_at': str(datetime.now())
            }}
            
            return result
            
        except Exception as e:
            logger.error(f"Legacy processing failed: {{e}}")
            return {{
                'status': 'error',
                'error': str(e)
            }}
''',
            'init_logic': '''
        # Legacy system initialization
        self.legacy_mode = True
        logger.info("🔄 Agent initialized in legacy mode")
''',
            'sample_code': f'''
# Legacy Sample Code
agent = AgentClass()
result = await agent.process_main_logic({{"sample": "data"}})
print(result)
''',
            'generation_method': 'legacy_fallback'
        }
    
    def _generate_emergency_business_logic(self, template_id: str, 
                                         user_request: str) -> Dict[str, Any]:
        """최후 응급 처치용 비즈니스 로직"""
        
        logger.warning("🚨 Generating emergency business logic...")
        
        return {
            'process_logic': '''
    async def process_main_logic(self, extracted_info):
        """Emergency fallback logic"""
        return {
            'status': 'emergency_mode',
            'message': 'Agent generated in emergency mode',
            'data': extracted_info
        }
''',
            'init_logic': '# Emergency initialization\npass',
            'sample_code': '# Emergency sample\nprint("Emergency agent ready")',
            'agent_class_name': 'EmergencyAgent',
            'custom_config': '{"emergency_mode": true}',
            'agent_description': 'Emergency agent generated as fallback',
            'generation_method': 'emergency'
        }
    
    def _update_success_metrics(self, execution_time: float, used_patterns: bool):
        """성공 메트릭 업데이트"""
        
        # 평균 실행시간 업데이트
        total_requests = self.integration_stats['total_requests']
        current_avg = self.integration_stats['avg_execution_time']
        new_avg = ((current_avg * (total_requests - 1)) + execution_time) / total_requests
        self.integration_stats['avg_execution_time'] = new_avg
        
        # 성공률 업데이트 (간단히 패턴 사용 여부로 판단)
        if used_patterns:
            success_count = self.integration_stats['pattern_system_used']
            self.integration_stats['success_rate'] = success_count / total_requests * 100
    
    def get_integration_stats(self) -> Dict[str, Any]:
        """통합 통계 반환"""
        return {
            'integration_id': self.integration_id,
            'patterns_available': self.patterns_enabled,
            'stats': self.integration_stats.copy(),
            'generated_at': datetime.now().isoformat()
        }


# 전역 통합 인스턴스 (싱글톤 패턴)
_global_integrator = None

def get_pattern_integrator() -> PatternTemplateIntegrator:
    """전역 통합기 인스턴스 반환"""
    global _global_integrator
    
    if _global_integrator is None:
        _global_integrator = PatternTemplateIntegrator()
    
    return _global_integrator


if __name__ == "__main__":
    # 통합기 테스트
    async def test_integrator():
        integrator = PatternTemplateIntegrator()
        
        test_request = "CSV 파일을 업로드해서 데이터 품질을 검증하고 상관관계를 분석한 후 대시보드를 생성하는 에이전트"
        
        class MockLLMClient:
            async def invoke(self, prompt):
                return "Mock LLM response"
        
        result = await integrator.enhanced_generate_business_logic(
            "data_analysis", test_request, MockLLMClient()
        )
        
        print("✅ Integration test completed!")
        print(f"Result keys: {list(result.keys())}")
        print(f"Agent class: {result.get('agent_class_name')}")
        
        stats = integrator.get_integration_stats()
        print(f"Integration stats: {stats}")
    
    asyncio.run(test_integrator())
