"""
스마트 테스트 샘플 생성기
LLM과 규칙 기반을 결합한 하이브리드 접근
"""

import json
from typing import List, Dict, Any, Optional
from loguru import logger

class SmartSampleGenerator:
    """지능형 테스트 샘플 생성기"""
    
    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        
        # 기본 샘플 템플릿 (폴백용)
        self.default_samples = {
            'sentiment': [
                {"text": "이 제품은 정말 훌륭합니다! 매우 만족스러워요."},
                {"text": "최악이에요. 다시는 구매하지 않을 거예요."},
                {"text": "그냥 평범해요. 특별할 것 없네요."}
            ],
            'calculator': [
                {"expression": "2 + 2"},
                {"expression": "10 * 5"},
                {"expression": "(5 + 3) * 2"}
            ],
            'weather': [
                {"city": "Seoul"},
                {"city": "New York"},
                {"city": "Tokyo"}
            ],
            'translator': [
                {"text": "Hello", "target": "ko"},
                {"text": "안녕하세요", "target": "en"}
            ]
        }
        
    async def generate_samples(
        self, 
        agent_type: str, 
        business_logic: str,
        query: str,
        use_llm: bool = True
    ) -> List[Dict[str, Any]]:
        """
        테스트 샘플 생성 - 하이브리드 접근
        
        1단계: 비즈니스 로직 분석
        2단계: LLM으로 맞춤형 샘플 생성 시도
        3단계: 검증 및 폴백
        """
        
        # 1. 비즈니스 로직에서 입력 구조 분석
        input_structure = self._analyze_input_structure(business_logic)
        logger.info(f"📊 Detected input structure: {input_structure}")
        
        # 2. LLM 사용 가능하고 활성화된 경우
        if use_llm and self.llm_client:
            try:
                llm_samples = await self._generate_with_llm(
                    agent_type, 
                    query, 
                    input_structure,
                    business_logic
                )
                
                # 3. LLM 생성 샘플 검증
                validated_samples = self._validate_samples(llm_samples, input_structure)
                
                if validated_samples:
                    logger.info(f"✅ Using LLM-generated samples: {len(validated_samples)} samples")
                    return validated_samples
                    
            except Exception as e:
                logger.warning(f"⚠️ LLM sample generation failed: {e}")
        
        # 4. 폴백: 규칙 기반 샘플 생성
        rule_based_samples = self._generate_rule_based(agent_type, input_structure)
        logger.info(f"📋 Using rule-based samples: {len(rule_based_samples)} samples")
        
        return rule_based_samples
    
    def _analyze_input_structure(self, business_logic: str) -> Dict[str, Any]:
        """비즈니스 로직에서 예상 입력 구조 추출"""
        
        structure = {
            'fields': [],
            'types': {},
            'required': []
        }
        
        # 간단한 패턴 매칭으로 필드 추출
        import re
        
        # .get() 패턴 찾기
        get_patterns = re.findall(r'\.get\(["\'](\w+)["\']', business_logic)
        for field in get_patterns:
            structure['fields'].append(field)
            
        # 특정 키워드로 타입 추론
        if 'text' in business_logic.lower():
            structure['types']['text'] = 'string'
        if 'number' in business_logic or 'float' in business_logic or 'int' in business_logic:
            structure['types']['value'] = 'number'
        if 'list' in business_logic or 'array' in business_logic:
            structure['types']['data'] = 'array'
            
        return structure
    
    async def _generate_with_llm(
        self, 
        agent_type: str,
        query: str,
        input_structure: Dict,
        business_logic: str
    ) -> List[Dict]:
        """LLM을 사용한 맞춤형 샘플 생성"""
        
        prompt = f"""
사용자가 요청한 에이전트: {query}
에이전트 타입: {agent_type}
예상 입력 구조: {json.dumps(input_structure, ensure_ascii=False)}

비즈니스 로직 일부:
```python
{business_logic[:500]}  # 처음 500자만
```

이 에이전트를 테스트하기 위한 5개의 실제적인 테스트 샘플을 JSON 형식으로 생성하세요.
각 샘플은 다양한 케이스를 커버해야 합니다 (긍정적, 부정적, 엣지 케이스 등).

응답 형식:
[
    {{"필드1": "값1", "필드2": "값2"}},
    ...
]

JSON만 반환하고 다른 설명은 하지 마세요.
"""
        
        response = await self.llm_client.generate(prompt)
        
        try:
            # JSON 파싱
            samples = json.loads(response)
            return samples if isinstance(samples, list) else []
        except:
            return []
    
    def _validate_samples(self, samples: List[Dict], structure: Dict) -> List[Dict]:
        """생성된 샘플 검증"""
        
        validated = []
        
        for sample in samples:
            if not isinstance(sample, dict):
                continue
                
            # 필수 필드 체크
            valid = True
            for required_field in structure.get('required', []):
                if required_field not in sample:
                    valid = False
                    break
            
            # 타입 체크 (간단한 검증)
            if valid:
                validated.append(sample)
                
            if len(validated) >= 5:  # 최대 5개
                break
                
        return validated
    
    def _generate_rule_based(
        self, 
        agent_type: str, 
        structure: Dict
    ) -> List[Dict]:
        """규칙 기반 샘플 생성"""
        
        # 에이전트 타입별 기본 샘플
        for key in ['sentiment', 'analysis', 'emotion']:
            if key in agent_type.lower():
                return self.default_samples.get('sentiment', [])
        
        for key in ['calc', 'math']:
            if key in agent_type.lower():
                return self.default_samples.get('calculator', [])
                
        for key in ['weather', '날씨']:
            if key in agent_type.lower():
                return self.default_samples.get('weather', [])
                
        for key in ['translate', '번역']:
            if key in agent_type.lower():
                return self.default_samples.get('translator', [])
        
        # 구조 기반 제네릭 샘플
        if structure['fields']:
            generic_samples = []
            for i in range(3):
                sample = {}
                for field in structure['fields'][:3]:  # 최대 3개 필드
                    field_type = structure['types'].get(field, 'string')
                    
                    if field_type == 'string':
                        sample[field] = f"Test {field} {i+1}"
                    elif field_type == 'number':
                        sample[field] = (i+1) * 10
                    elif field_type == 'array':
                        sample[field] = [i+1, i+2, i+3]
                    else:
                        sample[field] = f"Sample {i+1}"
                        
                generic_samples.append(sample)
                
            return generic_samples
        
        # 최종 폴백
        return [
            {"input": "Test input 1"},
            {"input": "Test input 2"},
            {"input": "Test input 3"}
        ]
    
    def generate_inline_test_code(
        self, 
        agent_class: str,
        samples: List[Dict]
    ) -> str:
        """테스트 코드 문자열 생성"""
        
        test_code = f'''
# === 자동 생성된 테스트 코드 ===
if __name__ == "__main__":
    import asyncio
    import json
    
    async def test():
        agent = {agent_class}()
        print("\\n" + "="*60)
        print(f"Testing {{agent.__class__.__name__}}")
        print("="*60 + "\\n")
        
        test_samples = {json.dumps(samples, ensure_ascii=False, indent=8)}
        
        for i, sample in enumerate(test_samples, 1):
            print(f"\\n[Test {{i}}]")
            print(f"📝 Input: {{sample}}")
            
            # JSON 변환
            if isinstance(sample, dict):
                input_data = json.dumps(sample, ensure_ascii=False)
            else:
                input_data = str(sample)
            
            try:
                result = await agent.process(input_data)
                print(f"✅ Result: {{result}}")
                
                # 결과가 AgentResponse인 경우 content 출력
                if hasattr(result, 'content'):
                    print(f"📊 Content: {{result.content}}")
                    
            except Exception as e:
                print(f"❌ Error: {{e}}")
            
            print("-" * 60)
        
        print("\\n✨ Test completed!")
    
    # 실행
    asyncio.run(test())
'''
        return test_code


# 사용 예시
async def example_usage():
    """사용 예시"""
    
    generator = SmartSampleGenerator()
    
    # 비즈니스 로직 예시
    business_logic = '''
    text = extracted_info.get("text", "")
    language = extracted_info.get("language", "auto")
    
    # 감정 분석 수행
    sentiment = analyze_sentiment(text)
    confidence = calculate_confidence(sentiment)
    '''
    
    # 샘플 생성
    samples = await generator.generate_samples(
        agent_type="sentiment_analyzer",
        business_logic=business_logic,
        query="감정 분석 에이전트를 만들어줘",
        use_llm=True  # LLM 사용 여부
    )
    
    print("Generated samples:", samples)
    
    # 테스트 코드 생성
    test_code = generator.generate_inline_test_code(
        "SentimentAgent",
        samples
    )
    
    print("Generated test code:")
    print(test_code)


if __name__ == "__main__":
    import asyncio
    asyncio.run(example_usage())