"""
Self-Generation System for FORGE AI

패턴이나 템플릿이 없을 때 자동으로 생성하는 시스템입니다.
기존 패턴들을 학습하여 새로운 패턴과 템플릿을 생성합니다.
"""

import json
import re
import logging
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import asyncio

logger = logging.getLogger(__name__)


class SelfGenerationSystem:
    """자가 생성 시스템 - 패턴과 템플릿 자동 생성"""
    
    def __init__(self, patterns_dir: Path = None, templates_dir: Path = None, llm_client=None):
        """
        자가 생성 시스템 초기화
        
        Args:
            patterns_dir: 패턴 디렉토리
            templates_dir: 템플릿 디렉토리
            llm_client: LLM 클라이언트
        """
        self.patterns_dir = patterns_dir or Path(__file__).parent.parent / 'patterns'
        self.templates_dir = templates_dir or Path(__file__).parent.parent / 'templates'
        self.llm_client = llm_client
        
        # 기존 패턴과 템플릿 로드
        self.existing_patterns = self._load_existing_patterns()
        self.existing_templates = self._load_existing_templates()
        
        logger.info(f"🧬 Self-Generation System initialized")
        logger.info(f"   - Loaded {len(self.existing_patterns)} patterns")
        logger.info(f"   - Loaded {len(self.existing_templates)} templates")
    
    def _load_existing_patterns(self) -> List[Dict[str, Any]]:
        """기존 패턴들 로드"""
        patterns = []
        
        # 패턴 디렉토리에서 JSON 파일들 읽기
        if self.patterns_dir.exists():
            for pattern_file in self.patterns_dir.glob('*.json'):
                try:
                    with open(pattern_file, 'r', encoding='utf-8') as f:
                        pattern = json.load(f)
                        patterns.append(pattern)
                except Exception as e:
                    logger.warning(f"Failed to load pattern {pattern_file}: {e}")
        
        # 기본 패턴들 (하드코딩)
        default_patterns = [
            {
                "id": "data_processing",
                "name": "데이터 처리 패턴",
                "keywords": ["데이터", "처리", "분석", "변환"],
                "code_template": "import pandas as pd\n# 데이터 처리 로직"
            },
            {
                "id": "api_integration",
                "name": "API 통합 패턴",
                "keywords": ["API", "REST", "HTTP", "요청"],
                "code_template": "import requests\n# API 호출 로직"
            }
        ]
        
        patterns.extend(default_patterns)
        return patterns
    
    def _load_existing_templates(self) -> List[Dict[str, Any]]:
        """기존 템플릿들 로드"""
        templates = []
        
        # 템플릿 디렉토리에서 파일들 읽기
        if self.templates_dir.exists():
            for template_file in self.templates_dir.glob('*.template'):
                try:
                    with open(template_file, 'r', encoding='utf-8') as f:
                        template = {
                            'name': template_file.stem,
                            'content': f.read(),
                            'file': str(template_file)
                        }
                        templates.append(template)
                except Exception as e:
                    logger.warning(f"Failed to load template {template_file}: {e}")
        
        return templates
    
    async def generate_pattern(self, requirements: str, context: Dict[str, Any] = None) -> Tuple[bool, Dict[str, Any]]:
        """
        요구사항에 맞는 새로운 패턴 생성
        
        Args:
            requirements: 패턴 요구사항
            context: 추가 컨텍스트
            
        Returns:
            (성공 여부, 생성된 패턴 또는 에러 메시지)
        """
        logger.info(f"🧬 Generating new pattern for: {requirements[:100]}...")
        
        # 1. 유사한 기존 패턴 찾기
        similar_patterns = self._find_similar_patterns(requirements)
        
        # 2. LLM이 있으면 LLM 기반 생성
        if self.llm_client:
            success, pattern = await self._generate_pattern_with_llm(requirements, similar_patterns, context)
            if success:
                # 생성된 패턴 저장
                self._save_pattern(pattern)
                return True, pattern
        
        # 3. 규칙 기반 생성 (LLM이 없거나 실패한 경우)
        pattern = self._generate_pattern_rule_based(requirements, similar_patterns)
        
        if pattern:
            self._save_pattern(pattern)
            return True, pattern
        
        return False, {"error": "Failed to generate pattern"}
    
    def _find_similar_patterns(self, requirements: str) -> List[Dict[str, Any]]:
        """요구사항과 유사한 패턴 찾기"""
        similar = []
        req_keywords = set(requirements.lower().split())
        
        for pattern in self.existing_patterns:
            # 키워드 매칭
            pattern_keywords = set()
            if 'keywords' in pattern:
                pattern_keywords.update([k.lower() for k in pattern['keywords']])
            if 'name' in pattern:
                pattern_keywords.update(pattern['name'].lower().split())
            
            # 유사도 계산 (겹치는 키워드 비율)
            if pattern_keywords:
                similarity = len(req_keywords & pattern_keywords) / len(pattern_keywords)
                if similarity > 0.3:  # 30% 이상 유사하면 포함
                    similar.append(pattern)
        
        # 최대 3개까지만 반환
        return similar[:3]
    
    async def _generate_pattern_with_llm(self, requirements: str, similar_patterns: List[Dict[str, Any]], 
                                        context: Dict[str, Any] = None) -> Tuple[bool, Dict[str, Any]]:
        """LLM을 사용하여 패턴 생성"""
        try:
            # 프롬프트 생성
            prompt = f"""
다음 요구사항에 맞는 새로운 코드 패턴을 생성해주세요.

요구사항:
{requirements}

참고할 수 있는 유사한 패턴들:
{json.dumps(similar_patterns, ensure_ascii=False, indent=2) if similar_patterns else "없음"}

다음 JSON 형식으로 패턴을 생성해주세요:
{{
    "id": "패턴_아이디",
    "name": "패턴 이름",
    "description": "패턴 설명",
    "keywords": ["키워드1", "키워드2", ...],
    "code_template": "# Python 코드 템플릿",
    "requirements": ["필요한 라이브러리"],
    "example_usage": "# 사용 예제 코드"
}}

JSON만 출력하고 다른 설명은 하지 마세요.
"""
            
            # LLM 호출
            response = await self.llm_client.generate(prompt)
            
            # JSON 파싱
            pattern = self._extract_json_from_response(response)
            
            if pattern:
                # ID가 없으면 자동 생성
                if 'id' not in pattern:
                    pattern['id'] = f"generated_{len(self.existing_patterns) + 1}"
                
                logger.info(f"✅ LLM generated pattern: {pattern.get('name', 'Unknown')}")
                return True, pattern
            
        except Exception as e:
            logger.error(f"LLM pattern generation failed: {e}")
        
        return False, {}
    
    def _generate_pattern_rule_based(self, requirements: str, similar_patterns: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """규칙 기반으로 패턴 생성"""
        # 요구사항에서 키워드 추출
        keywords = self._extract_keywords(requirements)
        
        # 기본 패턴 구조 생성
        pattern = {
            "id": f"auto_generated_{len(self.existing_patterns) + 1}",
            "name": f"자동 생성 패턴 - {keywords[0] if keywords else 'Unknown'}",
            "description": requirements[:200],
            "keywords": keywords,
            "code_template": self._generate_basic_code_template(keywords, similar_patterns),
            "requirements": self._guess_requirements(keywords),
            "auto_generated": True
        }
        
        logger.info(f"📝 Rule-based pattern generated: {pattern['name']}")
        return pattern
    
    def _extract_keywords(self, text: str) -> List[str]:
        """텍스트에서 키워드 추출"""
        # 불용어 제거
        stopwords = {'을', '를', '이', '가', '은', '는', '의', '에', '에서', '으로', '와', '과', '하고', '하는', '만들어', '생성', '구현'}
        
        # 단어 추출
        words = re.findall(r'[가-힣]+|[a-zA-Z]+', text.lower())
        
        # 키워드 필터링
        keywords = [w for w in words if w not in stopwords and len(w) > 1]
        
        # 중복 제거하면서 순서 유지
        seen = set()
        unique_keywords = []
        for k in keywords:
            if k not in seen:
                seen.add(k)
                unique_keywords.append(k)
        
        return unique_keywords[:10]  # 최대 10개
    
    def _generate_basic_code_template(self, keywords: List[str], similar_patterns: List[Dict[str, Any]]) -> str:
        """기본 코드 템플릿 생성"""
        template_lines = []
        
        # Import 문 생성
        imports = set()
        
        # 키워드 기반 import 추론
        keyword_imports = {
            'data': 'import pandas as pd',
            '데이터': 'import pandas as pd',
            'api': 'import requests',
            'web': 'import requests',
            'file': 'import os',
            '파일': 'import os',
            'json': 'import json',
            'database': 'import sqlite3',
            'db': 'import sqlite3',
            'ml': 'import sklearn',
            'ai': 'import torch',
            'plot': 'import matplotlib.pyplot as plt',
            '그래프': 'import matplotlib.pyplot as plt'
        }
        
        for keyword in keywords:
            for key, imp in keyword_imports.items():
                if key in keyword.lower():
                    imports.add(imp)
        
        # 유사 패턴에서 import 추출
        for pattern in similar_patterns:
            if 'code_template' in pattern:
                import_lines = [line for line in pattern['code_template'].split('\n') 
                              if line.strip().startswith('import') or line.strip().startswith('from')]
                imports.update(import_lines)
        
        # 기본 import 추가
        imports.add('import logging')
        imports.add('from typing import Dict, Any, List, Optional')
        
        template_lines.extend(sorted(imports))
        template_lines.append('')
        template_lines.append('logger = logging.getLogger(__name__)')
        template_lines.append('')
        template_lines.append('# TODO: Implement logic here')
        template_lines.append('def process(data: Any) -> Any:')
        template_lines.append('    """Process the data"""')
        template_lines.append('    # Auto-generated template')
        template_lines.append('    result = data')
        template_lines.append('    return result')
        
        return '\n'.join(template_lines)
    
    def _guess_requirements(self, keywords: List[str]) -> List[str]:
        """키워드 기반으로 필요한 라이브러리 추측"""
        requirements = []
        
        keyword_requirements = {
            'data': 'pandas',
            '데이터': 'pandas',
            'api': 'requests',
            'web': 'requests',
            'scraping': 'beautifulsoup4',
            'ml': 'scikit-learn',
            'ai': 'torch',
            'plot': 'matplotlib',
            '그래프': 'matplotlib',
            'excel': 'openpyxl',
            'database': 'sqlalchemy'
        }
        
        for keyword in keywords:
            for key, req in keyword_requirements.items():
                if key in keyword.lower() and req not in requirements:
                    requirements.append(req)
        
        return requirements
    
    def _extract_json_from_response(self, response: str) -> Optional[Dict[str, Any]]:
        """LLM 응답에서 JSON 추출"""
        # JSON 블록 찾기
        json_pattern = r'```json\n(.*?)\n```'
        matches = re.findall(json_pattern, response, re.DOTALL)
        
        if matches:
            try:
                return json.loads(matches[0])
            except json.JSONDecodeError:
                pass
        
        # 전체 응답이 JSON일 수도 있음
        try:
            return json.loads(response.strip())
        except json.JSONDecodeError:
            pass
        
        return None
    
    def _save_pattern(self, pattern: Dict[str, Any]):
        """생성된 패턴 저장"""
        # 메모리에 추가
        self.existing_patterns.append(pattern)
        
        # 파일로 저장 (옵션)
        if self.patterns_dir:
            pattern_file = self.patterns_dir / f"{pattern['id']}.json"
            try:
                with open(pattern_file, 'w', encoding='utf-8') as f:
                    json.dump(pattern, f, ensure_ascii=False, indent=2)
                logger.info(f"💾 Pattern saved to {pattern_file}")
            except Exception as e:
                logger.warning(f"Failed to save pattern to file: {e}")
    
    async def generate_template(self, agent_type: str, requirements: str) -> Tuple[bool, str]:
        """
        새로운 템플릿 생성
        
        Args:
            agent_type: 에이전트 타입
            requirements: 템플릿 요구사항
            
        Returns:
            (성공 여부, 생성된 템플릿 또는 에러 메시지)
        """
        logger.info(f"🧬 Generating new template for {agent_type}")
        
        # 유사한 템플릿 찾기
        similar_templates = self._find_similar_templates(agent_type)
        
        # LLM 기반 생성
        if self.llm_client:
            success, template = await self._generate_template_with_llm(
                agent_type, requirements, similar_templates
            )
            if success:
                return True, template
        
        # 규칙 기반 생성
        template = self._generate_template_rule_based(agent_type, similar_templates)
        return True, template
    
    def _find_similar_templates(self, agent_type: str) -> List[Dict[str, Any]]:
        """유사한 템플릿 찾기"""
        similar = []
        
        for template in self.existing_templates:
            # 이름이 유사한지 확인
            if agent_type.lower() in template['name'].lower():
                similar.append(template)
        
        return similar[:2]
    
    async def _generate_template_with_llm(self, agent_type: str, requirements: str, 
                                         similar_templates: List[Dict[str, Any]]) -> Tuple[bool, str]:
        """LLM을 사용한 템플릿 생성"""
        try:
            prompt = f"""
다음 요구사항에 맞는 LogosAI 에이전트 템플릿을 생성해주세요.

에이전트 타입: {agent_type}
요구사항: {requirements}

{"참고 템플릿: " + similar_templates[0]['content'][:1000] if similar_templates else ""}

LogosAI 에이전트 클래스를 상속받는 Python 코드를 생성해주세요.
코드만 출력하고 설명은 하지 마세요.
"""
            
            response = await self.llm_client.generate(prompt)
            
            # 코드 추출
            code = self._extract_code_from_response(response)
            
            if code:
                logger.info(f"✅ LLM generated template for {agent_type}")
                return True, code
            
        except Exception as e:
            logger.error(f"LLM template generation failed: {e}")
        
        return False, ""
    
    def _generate_template_rule_based(self, agent_type: str, similar_templates: List[Dict[str, Any]]) -> str:
        """규칙 기반 템플릿 생성"""
        # 기본 템플릿 구조
        template = f'''"""
Auto-generated {agent_type} Agent Template
"""

from typing import Dict, Any, Optional
from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType
import logging

logger = logging.getLogger(__name__)


class {self._to_class_name(agent_type)}(LogosAIAgent):
    """Auto-generated {agent_type} agent"""
    
    def __init__(self, config: Optional[AgentConfig] = None):
        if config is None:
            config = AgentConfig(
                name="{agent_type}",
                agent_type=AgentType.CUSTOM,
                description="Auto-generated {agent_type} agent"
            )
        super().__init__(config)
    
    async def initialize(self) -> bool:
        """Initialize the agent"""
        await super().initialize()
        # TODO: Add initialization logic
        return True
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Process the query"""
        try:
            # TODO: Implement processing logic
            result = {{"answer": f"Processed: {{query}}"}}
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result
            )
        except Exception as e:
            logger.error(f"Error: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}}
            )
'''
        
        logger.info(f"📝 Rule-based template generated for {agent_type}")
        return template
    
    def _to_class_name(self, text: str) -> str:
        """텍스트를 클래스 이름으로 변환"""
        # 특수문자 제거하고 CamelCase로 변환
        words = re.findall(r'[a-zA-Z]+', text)
        return ''.join(word.capitalize() for word in words) + 'Agent'
    
    def _extract_code_from_response(self, response: str) -> Optional[str]:
        """응답에서 코드 추출"""
        # 코드 블록 찾기
        code_pattern = r'```python\n(.*?)\n```'
        matches = re.findall(code_pattern, response, re.DOTALL)
        
        if matches:
            return matches[0]
        
        # 전체가 코드일 수도 있음
        if 'class' in response and 'def' in response:
            return response.strip()
        
        return None


# 싱글톤 인스턴스
_generation_system = None


def get_generation_system(patterns_dir=None, templates_dir=None, llm_client=None) -> SelfGenerationSystem:
    """싱글톤 자가 생성 시스템 반환"""
    global _generation_system
    if _generation_system is None:
        _generation_system = SelfGenerationSystem(patterns_dir, templates_dir, llm_client)
    return _generation_system