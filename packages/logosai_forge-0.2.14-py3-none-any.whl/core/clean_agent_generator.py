"""
Clean Agent Generator - 완전히 새로운 접근
=========================================
템플릿 없이 직접 코드를 생성하는 깔끔한 생성기
"""

import json
import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path
from loguru import logger


class CleanAgentGenerator:
    """깔끔하고 단순한 에이전트 생성기"""
    
    def __init__(self):
        """초기화"""
        self.agent_types = {
            "data_analysis": "DATA_ANALYSIS",
            "api_integration": "API_INTEGRATION", 
            "web_scraping": "WEB_SCRAPING",
            "calculator": "CUSTOM",
            "document_processing": "DOCUMENT_PROCESSING",
            "general_purpose": "CUSTOM"
        }
        logger.info("🚀 CleanAgentGenerator 초기화 완료")
    
    async def generate_agent(self, user_request: str) -> Dict[str, Any]:
        """사용자 요청에서 에이전트 생성"""
        
        # 1. 요청 분석
        analysis = self._analyze_request(user_request)
        
        # 2. 에이전트 코드 생성
        agent_code = self._generate_agent_code(analysis)
        
        # 3. 메타데이터 생성
        metadata = self._generate_metadata(analysis)
        
        return {
            "code": agent_code,
            "metadata": metadata,
            "analysis": analysis
        }
    
    def _analyze_request(self, request: str) -> Dict[str, Any]:
        """요청 분석"""
        request_lower = request.lower()
        
        # 에이전트 타입 감지
        if any(word in request_lower for word in ['데이터', '분석', 'csv', 'excel']):
            agent_type = "data_analysis"
        elif any(word in request_lower for word in ['api', 'rest', 'endpoint']):
            agent_type = "api_integration"
        elif any(word in request_lower for word in ['웹', '크롤링', 'scraping']):
            agent_type = "web_scraping"
        elif any(word in request_lower for word in ['계산', 'calculator']):
            agent_type = "calculator"
        else:
            agent_type = "general_purpose"
        
        # 에이전트 이름 생성
        if '계산' in request_lower:
            agent_name = "CalculatorAgent"
        elif '분석' in request_lower:
            agent_name = "DataAnalysisAgent"
        elif 'api' in request_lower:
            agent_name = "APIIntegrationAgent"
        elif '웹' in request_lower:
            agent_name = "WebScrapingAgent"
        else:
            agent_name = "CustomAgent"
        
        return {
            "agent_type": agent_type,
            "agent_name": agent_name,
            "description": request,
            "request": request
        }
    
    def _generate_agent_code(self, analysis: Dict[str, Any]) -> str:
        """에이전트 코드 생성"""
        
        agent_type = analysis["agent_type"]
        agent_name = analysis["agent_name"]
        description = analysis["description"]
        
        # 에이전트 타입별 핵심 로직
        core_logic = self._get_core_logic(agent_type, analysis)
        
        # 전체 코드 생성
        code = f'''"""
{agent_name} - LogosAI Agent
{'='*30}
{description}
"""

import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from loguru import logger

from logosai import (
    LogosAIAgent,
    AgentConfig,
    AgentType,
    AgentResponse,
    AgentResponseType
)


class {agent_name}(LogosAIAgent):
    """{description}"""
    
    def __init__(self, config: Optional[AgentConfig] = None):
        """Initialize the agent with configuration"""
        if config is None:
            config = AgentConfig(
                name="{agent_name}",
                agent_type=AgentType.{self.agent_types[agent_type]},
                description="{description}",
                config={{
                    "model": "gemini-2.5-flash",
                    "temperature": 0.7,
                    "max_tokens": 2000
                }}
            )
        
        super().__init__(config)
        logger.info(f"{{self.name}} initialized")
    
    async def initialize(self) -> bool:
        """Async initialization"""
        try:
            # Initialize any required resources
            return True
        except Exception as e:
            logger.error(f"Failed to initialize: {{e}}")
            return False
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Process user query"""
        try:
            logger.info(f"Processing query: {{query}}")
            
            # Validate input
            if not query:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={{"error": "Empty query"}}
                )
            
            # Initialize context
            if context is None:
                context = {{}}
            
{core_logic}
            
        except Exception as e:
            logger.error(f"Processing error: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}}
            )
    
    async def cleanup(self) -> None:
        """Cleanup resources"""
        try:
            # Cleanup any resources
            logger.info(f"{{self.name}} cleanup completed")
        except Exception as e:
            logger.error(f"Cleanup error: {{e}}")


# Test the agent
if __name__ == "__main__":
    async def test():
        agent = {agent_name}()
        await agent.initialize()
        
        # Test query
        response = await agent.process("Test query")
        print(f"Response: {{response}}")
        
        await agent.cleanup()
    
    asyncio.run(test())
'''
        
        return code
    
    def _get_core_logic(self, agent_type: str, analysis: Dict[str, Any]) -> str:
        """에이전트 타입별 핵심 로직 생성"""
        
        if agent_type == "calculator":
            return '''            # Extract numbers and operation
            import re
            
            # Simple calculation logic
            numbers = re.findall(r'-?\d+\.?\d*', query)
            if len(numbers) >= 2:
                num1, num2 = float(numbers[0]), float(numbers[1])
                
                # Detect operation
                if '+' in query or '더하기' in query:
                    result = num1 + num2
                    operation = "addition"
                elif '-' in query or '빼기' in query:
                    result = num1 - num2
                    operation = "subtraction"
                elif '*' in query or '곱하기' in query:
                    result = num1 * num2
                    operation = "multiplication"
                elif '/' in query or '나누기' in query:
                    if num2 != 0:
                        result = num1 / num2
                        operation = "division"
                    else:
                        return AgentResponse(
                            type=AgentResponseType.ERROR,
                            content={"error": "Division by zero"}
                        )
                else:
                    result = num1 + num2  # Default to addition
                    operation = "addition"
                
                return AgentResponse(
                    type=AgentResponseType.SUCCESS,
                    content={
                        "result": result,
                        "operation": operation,
                        "expression": f"{num1} {operation} {num2} = {result}"
                    }
                )
            else:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": "Not enough numbers found in query"}
                )'''
        
        elif agent_type == "data_analysis":
            return '''            # Data analysis logic
            import pandas as pd
            import numpy as np
            
            # Get data from context
            data_source = context.get('data_source', None)
            
            if data_source:
                try:
                    # Load data
                    if isinstance(data_source, str) and data_source.endswith('.csv'):
                        df = pd.read_csv(data_source)
                    elif isinstance(data_source, pd.DataFrame):
                        df = data_source
                    else:
                        # Create sample data
                        df = pd.DataFrame({
                            'date': pd.date_range('2024-01-01', periods=100),
                            'value': np.random.randn(100).cumsum() + 100,
                            'category': np.random.choice(['A', 'B', 'C'], 100)
                        })
                    
                    # Perform analysis
                    analysis_results = {
                        "shape": df.shape,
                        "columns": list(df.columns),
                        "summary": df.describe().to_dict() if not df.empty else {},
                        "null_counts": df.isnull().sum().to_dict(),
                        "data_types": df.dtypes.astype(str).to_dict()
                    }
                    
                    # Category analysis if exists
                    if 'category' in df.columns:
                        analysis_results["category_counts"] = df['category'].value_counts().to_dict()
                    
                    return AgentResponse(
                        type=AgentResponseType.SUCCESS,
                        content={
                            "analysis": analysis_results,
                            "message": "Data analysis completed successfully"
                        }
                    )
                    
                except Exception as e:
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={"error": f"Data analysis failed: {str(e)}"}
                    )
            else:
                # No data provided - return sample analysis
                return AgentResponse(
                    type=AgentResponseType.SUCCESS,
                    content={
                        "message": "No data provided. Here's what I can analyze:",
                        "capabilities": [
                            "Statistical summary",
                            "Data visualization",
                            "Trend analysis",
                            "Correlation analysis",
                            "Missing data detection"
                        ]
                    }
                )'''
        
        elif agent_type == "api_integration":
            return '''            # API integration logic
            import aiohttp
            import asyncio
            
            # Get API details from context
            api_url = context.get('api_url', 'https://jsonplaceholder.typicode.com/posts/1')
            method = context.get('method', 'GET')
            headers = context.get('headers', {})
            data = context.get('data', None)
            
            try:
                async with aiohttp.ClientSession() as session:
                    # Make API request
                    async with session.request(
                        method=method,
                        url=api_url,
                        headers=headers,
                        json=data if method in ['POST', 'PUT'] else None
                    ) as response:
                        # Get response
                        response_data = await response.json()
                        
                        return AgentResponse(
                            type=AgentResponseType.SUCCESS,
                            content={
                                "status_code": response.status,
                                "data": response_data,
                                "headers": dict(response.headers),
                                "url": str(response.url)
                            }
                        )
                        
            except Exception as e:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": f"API request failed: {str(e)}"}
                )'''
        
        else:  # general_purpose
            return '''            # General purpose processing
            # Process based on query content
            response_data = {
                "query": query,
                "processed_at": datetime.now().isoformat(),
                "context_keys": list(context.keys()) if context else [],
                "message": f"Processed your request: {query[:50]}..."
            }
            
            # Add any specific processing based on query
            if "help" in query.lower():
                response_data["help"] = "I can help you with various tasks. Please be specific about what you need."
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=response_data
            )'''
    
    def _generate_metadata(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """메타데이터 생성"""
        
        agent_id = str(uuid.uuid4())[:8]
        
        return {
            "agent_id": agent_id,
            "agent_name": analysis["agent_name"],
            "agent_type": analysis["agent_type"],
            "description": analysis["description"],
            "created_at": datetime.now().isoformat(),
            "version": "1.0.0",
            "capabilities": self._get_capabilities(analysis["agent_type"]),
            "requirements": self._get_requirements(analysis["agent_type"])
        }
    
    def _get_capabilities(self, agent_type: str) -> List[str]:
        """에이전트 타입별 기능 목록"""
        capabilities_map = {
            "calculator": ["basic_arithmetic", "number_extraction", "expression_evaluation"],
            "data_analysis": ["csv_processing", "statistical_analysis", "data_visualization", "trend_detection"],
            "api_integration": ["rest_api_calls", "async_requests", "response_parsing", "error_handling"],
            "web_scraping": ["html_parsing", "data_extraction", "pagination_handling", "dynamic_content"],
            "general_purpose": ["text_processing", "context_handling", "flexible_responses"]
        }
        
        return capabilities_map.get(agent_type, ["general_processing"])
    
    def _get_requirements(self, agent_type: str) -> List[str]:
        """에이전트 타입별 요구사항"""
        requirements_map = {
            "calculator": ["logosai"],
            "data_analysis": ["logosai", "pandas", "numpy"],
            "api_integration": ["logosai", "aiohttp"],
            "web_scraping": ["logosai", "beautifulsoup4", "aiohttp"],
            "general_purpose": ["logosai"]
        }
        
        return requirements_map.get(agent_type, ["logosai"])


# 테스트 코드
if __name__ == "__main__":
    async def test():
        generator = CleanAgentGenerator()
        
        # 테스트 요청들
        test_requests = [
            "간단한 계산기 에이전트를 만들어줘",
            "CSV 파일을 분석하는 에이전트",
            "REST API와 연동하는 에이전트"
        ]
        
        for request in test_requests:
            print(f"\n{'='*60}")
            print(f"요청: {request}")
            print('='*60)
            
            result = await generator.generate_agent(request)
            
            print(f"에이전트 이름: {result['metadata']['agent_name']}")
            print(f"에이전트 타입: {result['metadata']['agent_type']}")
            print(f"코드 길이: {len(result['code'])} 문자")
            print("\n생성된 코드 일부:")
            print(result['code'][:500] + "...")
    
    import asyncio
    asyncio.run(test())