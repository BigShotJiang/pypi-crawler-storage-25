#!/usr/bin/env python3
"""
DataAnalysisAgent - Standalone Agent
==============================
CSV 파일을 분석하는 에이전트

이 에이전트는 외부 의존성 없이 독립적으로 실행됩니다.
"""

import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataAnalysisAgent:
    """CSV 파일을 분석하는 에이전트"""
    
    def __init__(self):
        """Initialize the agent"""
        self.name = "DataAnalysisAgent"
        self.description = "CSV 파일을 분석하는 에이전트"
        self.agent_type = "data_analysis"
        logger.info(f"{self.name} initialized")
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Process user query"""
        try:
            logger.info(f"Processing query: {query}")
            
            # Validate input
            if not query:
                return {
                    "status": "error",
                    "error": "Empty query"
                }
            
            # Initialize context
            if context is None:
                context = {}
            
            # 데이터 분석 로직
            # 간단한 데이터 분석 시뮬레이션
            data = context.get('data', None)
            
            if data:
                # 실제 데이터가 제공된 경우
                analysis_results = {
                    "data_received": True,
                    "data_type": type(data).__name__,
                    "analysis": "데이터 분석을 수행했습니다"
                }
            else:
                # 샘플 분석 결과
                analysis_results = {
                    "sample_analysis": {
                        "total_records": 1000,
                        "average_value": 52.3,
                        "max_value": 98.7,
                        "min_value": 12.1,
                        "categories": ["A", "B", "C"],
                        "trend": "increasing"
                    },
                    "message": "샘플 데이터 분석 결과입니다"
                }
            
            return {
                "status": "success",
                "analysis": analysis_results,
                "query": query
            }
            
        except Exception as e:
            logger.error(f"Processing error: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent information"""
        return {
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "capabilities": self._get_capabilities()
        }
    
    def _get_capabilities(self) -> List[str]:
        """Get agent capabilities"""
        capabilities_map = {
            "calculator": ["basic_arithmetic", "expression_evaluation"],
            "data_analysis": ["data_processing", "statistical_analysis"],
            "api_integration": ["http_requests", "json_parsing"],
            "web_scraping": ["html_parsing", "data_extraction"],
            "general_purpose": ["text_processing", "general_tasks"]
        }
        return capabilities_map.get(self.agent_type, ["general_processing"])


# 메인 실행 함수
async def main():
    """테스트 실행"""
    agent = DataAnalysisAgent()
    
    print(f"\n============================================================")
    print(f"{agent.name} 테스트")
    print('='*60)
    print(f"설명: {agent.description}")
    print(f"타입: {agent.agent_type}")
    print(f"기능: {', '.join(agent._get_capabilities())}")
    print('='*60)
    
    # 테스트 쿼리
    test_queries = ["데이터를 분석해줘", "트렌드를 보여줘", "통계 요약을 해줘"]
    
    for query in test_queries:
        print(f"\n쿼리: {query}")
        result = await agent.process(query)
        print(f"결과: {json.dumps(result, ensure_ascii=False, indent=2)}")
    
    print(f"\n============================================================")
    print("테스트 완료!")


if __name__ == "__main__":
    asyncio.run(main())
