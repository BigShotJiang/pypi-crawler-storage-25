"""
Automatic Template Generation System
=====================================
사용자 패턴 학습 기반 자동 템플릿 생성 시스템
"""

import os
import json
import re
import ast
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import hashlib
from loguru import logger

# LLM imports
try:
    from logosai.utils import LLMClient
except ImportError:
    try:
        import sys
        current_dir = Path(__file__).parent if '__file__' in globals() else Path.cwd()
        forge_core = current_dir.parent / 'forge' / 'core'
        if forge_core.exists():
            sys.path.insert(0, str(forge_core))
        from llm_integration import LLMClient
    except ImportError:
        class LLMClient:
            def __init__(self, model=None, temperature=0.7):
                pass
            async def invoke(self, prompt):
                return "# Mock generated code"


class AutoTemplateGenerator:
    """자동 템플릿 생성기"""
    
    def __init__(self, template_dir: str = None):
        self.template_dir = Path(template_dir or Path(__file__).parent.parent / "templates")
        self.generated_dir = self.template_dir / "auto_generated"
        self.generated_dir.mkdir(exist_ok=True)
        
        # LLM 클라이언트
        self.llm_client = LLMClient(
            model="gemini-2.5-flash-lite",
            temperature=0.7
        )
        
        # 학습 데이터
        self.query_patterns = defaultdict(list)
        self.generation_history = []
        self.template_cache = {}
        
        # 템플릿 구성 요소
        self.template_components = self._load_template_components()
        
        logger.info("AutoTemplateGenerator initialized")
    
    def _load_template_components(self) -> Dict[str, Any]:
        """템플릿 구성 요소 로드"""
        return {
            'imports': {
                'basic': [
                    "import asyncio",
                    "import json",
                    "from typing import Dict, Any, Optional, List",
                    "from datetime import datetime",
                    "from loguru import logger"
                ],
                'logosai': [
                    "from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType"
                ],
                'agentic': [
                    "from logosai.agentic import AgenticCore, AgenticReasoning, AgenticTools, AgenticMemory, AgenticLearning"
                ]
            },
            'class_structure': '''class {class_name}(LogosAIAgent):
    """
    {description}
    
    Features:
    {features}
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        """Initialize agent"""
        if config is None:
            config = AgentConfig(
                name="{agent_name}",
                agent_type=AgentType.CUSTOM,
                description="{description}",
                config={{
{config_dict}
                }}
            )
        
        super().__init__(config)
{custom_init}
        
        logger.info(f"{{self.name}} initialized")
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Main processing method"""
        try:
{process_logic}
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result,
                message="Processing completed successfully"
            )
            
        except Exception as e:
            logger.error(f"Processing error: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}},
                message=f"Processing failed: {{str(e)}}"
            )
    
{additional_methods}
''',
            'method_templates': {
                'data_processing': '''
    async def _process_data(self, data: Any) -> Dict[str, Any]:
        """Process input data"""
        result = {}
        # Data processing logic
        return result
''',
                'api_integration': '''
    async def _call_api(self, endpoint: str, params: Dict) -> Dict[str, Any]:
        """Call external API"""
        # API calling logic
        return {"response": "API result"}
''',
                'analysis': '''
    async def _analyze(self, content: Any) -> Dict[str, Any]:
        """Analyze content"""
        analysis_result = {}
        # Analysis logic
        return analysis_result
''',
                'monitoring': '''
    async def _monitor(self, target: str) -> None:
        """Monitor target"""
        while self.monitoring:
            # Monitoring logic
            await asyncio.sleep(self.monitor_interval)
'''
            }
        }
    
    async def analyze_query_pattern(self, query: str) -> Dict[str, Any]:
        """쿼리 패턴 분석"""
        analysis = {
            'query': query,
            'intent': self._detect_intent(query),
            'domain': self._detect_domain(query),
            'capabilities': self._extract_capabilities(query),
            'complexity': self._assess_complexity(query),
            'existing_match': False,
            'generation_needed': False
        }
        
        # 기존 템플릿 매칭 확인
        existing_templates = self._check_existing_templates(analysis)
        
        if not existing_templates or len(existing_templates) == 0:
            analysis['generation_needed'] = True
            analysis['reason'] = 'No matching templates found'
        elif max(t['score'] for t in existing_templates) < 0.5:
            analysis['generation_needed'] = True
            analysis['reason'] = 'Low confidence in existing templates'
        else:
            analysis['existing_match'] = True
            analysis['matching_templates'] = existing_templates
        
        # 패턴 저장
        pattern_key = f"{analysis['intent']}_{analysis['domain']}"
        self.query_patterns[pattern_key].append({
            'query': query,
            'timestamp': datetime.now().isoformat(),
            'analysis': analysis
        })
        
        return analysis
    
    def _detect_intent(self, query: str) -> str:
        """의도 감지"""
        query_lower = query.lower()
        
        intents = {
            'create': ['생성', '만들', 'create', 'make', 'build'],
            'analyze': ['분석', '조사', 'analyze', 'examine'],
            'monitor': ['모니터', '감시', 'monitor', 'watch'],
            'integrate': ['통합', '연동', 'integrate', 'connect'],
            'automate': ['자동화', 'automate', 'automatic']
        }
        
        for intent, keywords in intents.items():
            if any(kw in query_lower for kw in keywords):
                return intent
        
        return 'general'
    
    def _detect_domain(self, query: str) -> str:
        """도메인 감지"""
        query_lower = query.lower()
        
        domains = {
            'healthcare': ['의료', '건강', 'health', 'medical'],
            'finance': ['금융', '투자', 'finance', 'investment'],
            'education': ['교육', '학습', 'education', 'learning'],
            'security': ['보안', '안전', 'security', 'safety'],
            'retail': ['판매', '쇼핑', 'retail', 'shopping'],
            'gaming': ['게임', 'game', 'gaming'],
            'social': ['소셜', 'social', 'community']
        }
        
        for domain, keywords in domains.items():
            if any(kw in query_lower for kw in keywords):
                return domain
        
        return 'general'
    
    def _extract_capabilities(self, query: str) -> List[str]:
        """필요 기능 추출"""
        capabilities = []
        query_lower = query.lower()
        
        capability_map = {
            'real_time': ['실시간', 'real-time', 'realtime'],
            'ai_powered': ['AI', '인공지능', 'artificial intelligence'],
            'data_analysis': ['분석', 'analysis', 'analyze'],
            'automation': ['자동화', 'automation', 'automatic'],
            'integration': ['통합', 'integration', 'api'],
            'monitoring': ['모니터링', 'monitoring', 'tracking']
        }
        
        for capability, keywords in capability_map.items():
            if any(kw in query_lower for kw in keywords):
                capabilities.append(capability)
        
        return capabilities
    
    def _assess_complexity(self, query: str) -> str:
        """복잡도 평가"""
        score = 0
        
        if len(query) > 100:
            score += 1
        if '그리고' in query or 'and' in query.lower():
            score += 1
        if '실시간' in query or 'real-time' in query.lower():
            score += 1
        if 'AI' in query or '머신러닝' in query:
            score += 1
        
        if score >= 3:
            return 'high'
        elif score >= 2:
            return 'medium'
        else:
            return 'low'
    
    def _check_existing_templates(self, analysis: Dict[str, Any]) -> List[Dict]:
        """기존 템플릿 확인"""
        # 간단한 매칭 로직
        templates = []
        
        # 생성된 템플릿 확인
        for template_file in self.generated_dir.glob("*.py.template"):
            with open(template_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            score = 0
            # 도메인 매칭
            if analysis['domain'] in content.lower():
                score += 0.3
            # 의도 매칭
            if analysis['intent'] in content.lower():
                score += 0.2
            # 기능 매칭
            for capability in analysis['capabilities']:
                if capability.replace('_', ' ') in content.lower():
                    score += 0.1
            
            if score > 0:
                templates.append({
                    'file': template_file.name,
                    'score': min(score, 1.0)
                })
        
        return sorted(templates, key=lambda x: x['score'], reverse=True)
    
    async def generate_template(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """템플릿 자동 생성"""
        logger.info(f"Generating template for: {analysis['intent']} in {analysis['domain']}")
        
        # 캐시 확인
        cache_key = self._generate_cache_key(analysis)
        if cache_key in self.template_cache:
            logger.info("Using cached template")
            return self.template_cache[cache_key]
        
        # 템플릿 생성
        template_code = await self._generate_template_code(analysis)
        
        # 템플릿 검증
        is_valid, errors = self._validate_template(template_code)
        
        if not is_valid:
            # 오류 수정 시도
            template_code = await self._fix_template_errors(template_code, errors)
            is_valid, errors = self._validate_template(template_code)
        
        # 파일명 생성
        template_name = self._generate_template_name(analysis)
        template_path = self.generated_dir / f"{template_name}.py.template"
        
        # 템플릿 저장
        with open(template_path, 'w', encoding='utf-8') as f:
            f.write(template_code)
        
        # 메타데이터 생성
        metadata = self._generate_metadata(analysis, template_name)
        
        # 결과 준비
        result = {
            'success': is_valid,
            'template_name': template_name,
            'template_path': str(template_path),
            'metadata': metadata,
            'errors': errors if not is_valid else None,
            'code_preview': template_code[:500] + "..." if len(template_code) > 500 else template_code
        }
        
        # 캐시 저장
        self.template_cache[cache_key] = result
        
        # 히스토리 저장
        self.generation_history.append({
            'timestamp': datetime.now().isoformat(),
            'analysis': analysis,
            'result': result
        })
        
        return result
    
    async def _generate_template_code(self, analysis: Dict[str, Any]) -> str:
        """템플릿 코드 생성"""
        # 구성 요소 선택
        imports = self._select_imports(analysis)
        methods = self._select_methods(analysis)
        config = self._generate_config(analysis)
        
        # LLM으로 비즈니스 로직 생성
        business_logic = await self._generate_business_logic(analysis)
        
        # 템플릿 조립
        class_name = self._generate_class_name(analysis)
        agent_name = f"{analysis['domain'].title()} {analysis['intent'].title()} Agent"
        
        features = "\n    ".join([f"- {cap.replace('_', ' ').title()}" for cap in analysis['capabilities']])
        
        # Format config dictionary properly
        config_lines = []
        if config:
            for key, value in config.items():
                if isinstance(value, str):
                    config_lines.append(f'                "{key}": "{value}"')
                else:
                    config_lines.append(f'                "{key}": {json.dumps(value)}')
        config_dict = ',\n'.join(config_lines) if config_lines else ''
        
        template = self.template_components['class_structure'].format(
            class_name=class_name,
            agent_name=agent_name,
            description=f"Auto-generated agent for {analysis['domain']} {analysis['intent']}",
            features=features,
            config_dict=config_dict,
            custom_init="        # Custom initialization",
            process_logic=business_logic,
            additional_methods="\n".join(methods)
        )
        
        # 전체 템플릿 조합
        full_template = f'''"""
Auto-Generated Template: {agent_name}
=====================================
Generated at: {datetime.now().isoformat()}
Domain: {analysis['domain']}
Intent: {analysis['intent']}
"""

{chr(10).join(imports)}

{template}

# Test the template
if __name__ == "__main__":
    import asyncio
    
    async def test():
        agent = {class_name}()
        response = await agent.process("Test query")
        print(f"Test result: {{response.content}}")
    
    asyncio.run(test())
'''
        
        return full_template
    
    def _select_imports(self, analysis: Dict[str, Any]) -> List[str]:
        """필요한 import 선택"""
        imports = self.template_components['imports']['basic'].copy()
        imports.extend(self.template_components['imports']['logosai'])
        
        # Agentic 기능이 필요한 경우
        if analysis['complexity'] == 'high' or 'ai_powered' in analysis['capabilities']:
            imports.extend(self.template_components['imports']['agentic'])
        
        # 추가 라이브러리
        if 'data_analysis' in analysis['capabilities']:
            imports.append("import pandas as pd")
            imports.append("import numpy as np")
        
        if 'real_time' in analysis['capabilities']:
            imports.append("import asyncio")
            imports.append("from concurrent.futures import ThreadPoolExecutor")
        
        return imports
    
    def _select_methods(self, analysis: Dict[str, Any]) -> List[str]:
        """필요한 메서드 선택"""
        methods = []
        
        if 'data_analysis' in analysis['capabilities']:
            methods.append(self.template_components['method_templates']['data_processing'])
            methods.append(self.template_components['method_templates']['analysis'])
        
        if 'integration' in analysis['capabilities']:
            methods.append(self.template_components['method_templates']['api_integration'])
        
        if 'monitoring' in analysis['capabilities']:
            methods.append(self.template_components['method_templates']['monitoring'])
        
        return methods
    
    def _generate_config(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """설정 생성"""
        config = {
            "model": "gemini-2.5-flash-lite",
            "temperature": 0.7 if analysis['intent'] == 'create' else 0.3,
            "max_tokens": 3000 if analysis['complexity'] == 'high' else 2000
        }
        
        # 도메인별 설정
        if analysis['domain'] == 'finance':
            config['temperature'] = 0.2  # 더 정확한 응답
            config['risk_management'] = True
        elif analysis['domain'] == 'healthcare':
            config['privacy_mode'] = True
            config['compliance'] = 'HIPAA'
        
        # 기능별 설정
        if 'real_time' in analysis['capabilities']:
            config['streaming'] = True
            config['update_interval'] = 100
        
        if 'ai_powered' in analysis['capabilities']:
            config['enable_agentic'] = True
            config['memory_capacity'] = 100
        
        return config
    
    async def _generate_business_logic(self, analysis: Dict[str, Any]) -> str:
        """비즈니스 로직 생성"""
        prompt = f"""
Generate Python business logic for an AI agent with these specifications:
- Intent: {analysis['intent']}
- Domain: {analysis['domain']}
- Capabilities: {', '.join(analysis['capabilities'])}
- Complexity: {analysis['complexity']}

Generate only the core processing logic (no imports or class definitions).
The logic should:
1. Extract information from the query
2. Process according to the intent
3. Return a result dictionary

Keep it concise and functional.
"""
        
        try:
            response = await self.llm_client.invoke(prompt)
            
            # Handle LLMResponse object properly
            logic = getattr(response, 'content', str(response)) if hasattr(response, 'content') else str(response)
            
            # 코드 블록 추출
            if '```python' in logic:
                logic = logic.split('```python')[1].split('```')[0]
            elif '```' in logic:
                logic = logic.split('```')[1].split('```')[0]
            
            # 들여쓰기 조정
            lines = logic.strip().split('\n')
            indented_lines = ['        ' + line if line.strip() else line for line in lines]
            
            return '\n'.join(indented_lines)
            
        except Exception as e:
            logger.error(f"Failed to generate business logic: {e}")
            # 폴백 로직
            return '''        # Process the query
        result = {
            'status': 'success',
            'query': query,
            'domain': '""" + analysis['domain'] + """',
            'intent': '""" + analysis['intent'] + """',
            'data': {}
        }
        
        # Additional processing based on context
        if context:
            result['context'] = context
        
        return result'''
    
    def _generate_class_name(self, analysis: Dict[str, Any]) -> str:
        """클래스명 생성"""
        parts = [
            analysis['domain'].title(),
            analysis['intent'].title(),
            'Agent'
        ]
        
        # 특수문자 제거
        class_name = ''.join(parts).replace(' ', '').replace('-', '')
        
        # 숫자로 시작하면 앞에 언더스코어 추가
        if class_name[0].isdigit():
            class_name = '_' + class_name
        
        return class_name
    
    def _generate_template_name(self, analysis: Dict[str, Any]) -> str:
        """템플릿 파일명 생성"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        name_parts = [
            analysis['domain'].lower(),
            analysis['intent'].lower(),
            'agent',
            timestamp
        ]
        
        return '_'.join(name_parts)
    
    def _generate_cache_key(self, analysis: Dict[str, Any]) -> str:
        """캐시 키 생성"""
        key_data = f"{analysis['domain']}_{analysis['intent']}_{','.join(sorted(analysis['capabilities']))}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def _validate_template(self, template_code: str) -> Tuple[bool, List[str]]:
        """템플릿 검증"""
        errors = []
        
        # 문법 검사
        try:
            ast.parse(template_code)
        except SyntaxError as e:
            errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
        
        # 필수 요소 확인
        required_elements = [
            ('class.*LogosAIAgent', 'Missing LogosAIAgent inheritance'),
            ('async def process', 'Missing process method'),
            ('AgentResponse', 'Missing AgentResponse usage')
        ]
        
        for pattern, error_msg in required_elements:
            if not re.search(pattern, template_code):
                errors.append(error_msg)
        
        # 들여쓰기 확인
        lines = template_code.split('\n')
        for i, line in enumerate(lines):
            if line and not line[0].isspace() and not line.startswith('#') and \
               not line.startswith('"""') and not line.startswith("'''") and \
               not line.startswith('class') and not line.startswith('def') and \
               not line.startswith('import') and not line.startswith('from') and \
               not line.startswith('if __name__'):
                if i > 0:  # 첫 줄은 제외
                    errors.append(f"Indentation error at line {i + 1}")
        
        return len(errors) == 0, errors
    
    async def _fix_template_errors(self, template_code: str, errors: List[str]) -> str:
        """템플릿 오류 수정"""
        if not errors:
            return template_code
        
        prompt = f"""
Fix the following errors in this Python template code:

Errors:
{chr(10).join(errors)}

Code:
{template_code[:2000]}  # First 2000 chars

Return the fixed code.
"""
        
        try:
            response = await self.llm_client.invoke(prompt)
            
            # Handle LLMResponse object properly
            fixed_code = getattr(response, 'content', str(response)) if hasattr(response, 'content') else str(response)
            
            # 코드 블록 추출
            if '```python' in fixed_code:
                fixed_code = fixed_code.split('```python')[1].split('```')[0]
            elif '```' in fixed_code:
                fixed_code = fixed_code.split('```')[1].split('```')[0]
            
            return fixed_code.strip()
            
        except Exception as e:
            logger.error(f"Failed to fix template errors: {e}")
            return template_code
    
    def _generate_metadata(self, analysis: Dict[str, Any], template_name: str) -> Dict[str, Any]:
        """메타데이터 생성"""
        return {
            'template_id': template_name,
            'generated_at': datetime.now().isoformat(),
            'domain': analysis['domain'],
            'intent': analysis['intent'],
            'capabilities': analysis['capabilities'],
            'complexity': analysis['complexity'],
            'auto_generated': True,
            'version': '1.0.0',
            'keywords': self._extract_keywords_from_analysis(analysis),
            'use_cases': self._generate_use_cases(analysis)
        }
    
    def _extract_keywords_from_analysis(self, analysis: Dict[str, Any]) -> List[str]:
        """분석에서 키워드 추출"""
        keywords = [
            analysis['domain'],
            analysis['intent']
        ]
        
        # 기능을 키워드로 변환
        for cap in analysis['capabilities']:
            keywords.extend(cap.split('_'))
        
        # 중복 제거
        return list(set(keywords))
    
    def _generate_use_cases(self, analysis: Dict[str, Any]) -> List[str]:
        """사용 사례 생성"""
        use_cases = []
        
        # 의도별 사용 사례
        intent_cases = {
            'create': ['생성 작업', '자동 생성', '콘텐츠 제작'],
            'analyze': ['데이터 분석', '패턴 인식', '인사이트 도출'],
            'monitor': ['실시간 모니터링', '상태 추적', '알림 관리'],
            'integrate': ['시스템 통합', 'API 연동', '데이터 동기화'],
            'automate': ['작업 자동화', '프로세스 최적화', '워크플로우 관리']
        }
        
        use_cases.extend(intent_cases.get(analysis['intent'], []))
        
        # 도메인별 사용 사례
        domain_cases = {
            'healthcare': ['진단 지원', '환자 관리', '의료 기록 분석'],
            'finance': ['투자 분석', '리스크 관리', '거래 모니터링'],
            'education': ['학습 지원', '콘텐츠 생성', '평가 자동화']
        }
        
        use_cases.extend(domain_cases.get(analysis['domain'], []))
        
        return use_cases[:5]  # 최대 5개
    
    async def learn_from_usage(self, template_id: str, usage_data: Dict[str, Any]):
        """사용 데이터에서 학습"""
        # 사용 패턴 저장
        if 'success' in usage_data:
            # 성공적인 사용 패턴 강화
            pattern = usage_data.get('pattern')
            if pattern:
                self.query_patterns[pattern].append({
                    'template_id': template_id,
                    'success': True,
                    'timestamp': datetime.now().isoformat()
                })
        
        # 개선이 필요한 경우
        if usage_data.get('improvement_needed'):
            await self._improve_template(template_id, usage_data.get('feedback'))
    
    async def _improve_template(self, template_id: str, feedback: str):
        """템플릿 개선"""
        # 템플릿 로드
        template_path = self.generated_dir / f"{template_id}.py.template"
        
        if not template_path.exists():
            logger.warning(f"Template {template_id} not found for improvement")
            return
        
        with open(template_path, 'r', encoding='utf-8') as f:
            current_code = f.read()
        
        # LLM으로 개선
        prompt = f"""
Improve this template based on user feedback:

Feedback: {feedback}

Current template (first 1000 chars):
{current_code[:1000]}

Generate improved version.
"""
        
        try:
            response = await self.llm_client.invoke(prompt)
            
            # Handle LLMResponse object properly
            improved_code = getattr(response, 'content', str(response)) if hasattr(response, 'content') else str(response)
            
            # 백업 생성
            backup_path = template_path.with_suffix('.backup')
            with open(backup_path, 'w', encoding='utf-8') as f:
                f.write(current_code)
            
            # 개선된 코드 저장
            with open(template_path, 'w', encoding='utf-8') as f:
                f.write(improved_code.strip())
            
            logger.info(f"Template {template_id} improved based on feedback")
            
        except Exception as e:
            logger.error(f"Failed to improve template: {e}")
    
    def get_generation_statistics(self) -> Dict[str, Any]:
        """생성 통계 반환"""
        total_generated = len(list(self.generated_dir.glob("*.py.template")))
        
        # 도메인별 통계
        domain_stats = defaultdict(int)
        intent_stats = defaultdict(int)
        
        for history in self.generation_history:
            analysis = history['analysis']
            domain_stats[analysis['domain']] += 1
            intent_stats[analysis['intent']] += 1
        
        return {
            'total_generated': total_generated,
            'total_generations': len(self.generation_history),
            'cache_hits': len(self.template_cache),
            'by_domain': dict(domain_stats),
            'by_intent': dict(intent_stats),
            'success_rate': sum(1 for h in self.generation_history if h['result']['success']) / max(len(self.generation_history), 1)
        }


# 테스트
async def test_auto_generation():
    """자동 생성 테스트"""
    generator = AutoTemplateGenerator()
    
    test_queries = [
        "의료 데이터를 실시간으로 분석하는 AI 에이전트 만들어줘",
        "게임 내 플레이어 행동을 모니터링하는 에이전트가 필요해",
        "교육 콘텐츠를 자동으로 생성하는 AI 에이전트",
        "보안 취약점을 스캔하고 분석하는 에이전트"
    ]
    
    for query in test_queries:
        print(f"\n{'='*60}")
        print(f"Query: {query}")
        print('='*60)
        
        # 패턴 분석
        analysis = await generator.analyze_query_pattern(query)
        print(f"\nAnalysis:")
        print(f"  - Intent: {analysis['intent']}")
        print(f"  - Domain: {analysis['domain']}")
        print(f"  - Capabilities: {analysis['capabilities']}")
        print(f"  - Generation needed: {analysis['generation_needed']}")
        
        # 템플릿 생성
        if analysis['generation_needed']:
            result = await generator.generate_template(analysis)
            print(f"\nGeneration Result:")
            print(f"  - Success: {result['success']}")
            print(f"  - Template: {result['template_name']}")
            print(f"  - Path: {result['template_path']}")
    
    # 통계 출력
    stats = generator.get_generation_statistics()
    print(f"\n{'='*60}")
    print("Generation Statistics:")
    print(f"  - Total generated: {stats['total_generated']}")
    print(f"  - Success rate: {stats['success_rate']:.2%}")
    print(f"  - By domain: {stats['by_domain']}")
    print(f"  - By intent: {stats['by_intent']}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_auto_generation())