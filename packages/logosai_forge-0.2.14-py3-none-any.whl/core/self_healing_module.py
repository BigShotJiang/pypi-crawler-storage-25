#!/usr/bin/env python3
"""
FORGE AI 자가 수정 모듈
에러를 스스로 진단하고 수정하는 지능형 시스템
"""

import ast
import re
from typing import Optional, List, Dict, Any
from loguru import logger
from .exceptions import SelfHealingError, AgentGenerationError


class SelfHealingModule:
    """
    AST 생성 과정에서 발생하는 에러를 자동으로 수정
    """
    
    def __init__(self, max_attempts: int = 5):
        """
        Args:
            max_attempts: 최대 자가 수정 시도 횟수
        """
        self.max_attempts = max_attempts
        self.fix_history = []
        self.error_patterns = {
            'IndentationError': self.fix_indentation,
            'SyntaxError': self.fix_syntax,
            'NameError': self.fix_undefined_names,
            'ImportError': self.fix_undefined_names,  # ImportError도 같은 메서드 사용
            'TypeError': self.fix_type_errors,
            'AttributeError': self.fix_attribute_errors
        }
    
    def generate_with_self_healing(
        self,
        generator,
        agent_name: str,
        agent_class_name: str,
        description: str,
        agent_type: str,
        business_logic_text: str,
        domain_module=None
    ) -> ast.Module:
        """
        자가 수정을 통한 AST 생성
        
        Args:
            generator: ForgeASTGenerator 인스턴스
            agent_name: 에이전트 이름
            agent_class_name: 클래스 이름
            description: 설명
            agent_type: 에이전트 타입
            business_logic_text: 비즈니스 로직 텍스트
            domain_module: 도메인 전문 모듈 (옵션)
            
        Returns:
            생성된 AST Module
            
        Raises:
            AgentGenerationError: 자가 수정 실패 시
        """
        attempt = 0
        current_logic = business_logic_text
        
        while attempt < self.max_attempts:
            try:
                # AST 생성 시도
                logger.info(f"🔄 AST 생성 시도 {attempt + 1}/{self.max_attempts}")
                
                code = generator.create_logosai_agent_ast(
                    agent_name=agent_name,
                    agent_class_name=agent_class_name,
                    description=description,
                    agent_type=agent_type,
                    business_logic_text=current_logic
                )
                
                # 코드를 AST로 파싱하여 검증
                tree = ast.parse(code)
                
                # 의미론적 검증
                semantic_errors = self.semantic_validation(tree)
                if semantic_errors:
                    logger.warning(f"⚠️ 의미론적 에러 발견: {semantic_errors}")
                    current_logic = self.fix_semantic_errors(current_logic, semantic_errors)
                    attempt += 1
                    continue
                
                # 도메인 모듈 통합 (있으면)
                if domain_module:
                    tree = self.integrate_domain_module(tree, domain_module)
                
                # 성공
                logger.info(f"✅ AST 생성 성공 (시도: {attempt + 1})")
                return tree
                
            except SyntaxError as e:
                # 구문 에러 자가 수정
                logger.warning(f"🔧 구문 에러 발생: {e}")
                
                # 에러 타입별 수정 전략
                error_type = type(e).__name__
                if error_type in self.error_patterns:
                    fixed_logic = self.error_patterns[error_type](current_logic, e)
                    
                    if fixed_logic and fixed_logic != current_logic:
                        self.fix_history.append({
                            'attempt': attempt,
                            'error': str(e),
                            'fix_applied': error_type,
                            'success': False  # 아직 모름
                        })
                        current_logic = fixed_logic
                        attempt += 1
                    else:
                        # 수정 실패 - LLM에게 재생성 요청
                        current_logic = self.request_llm_fix(current_logic, e)
                        attempt += 1
                else:
                    # 알 수 없는 에러 - LLM 도움 요청
                    current_logic = self.request_llm_fix(current_logic, e)
                    attempt += 1
                    
            except Exception as e:
                # 기타 에러
                logger.error(f"❌ 예상치 못한 에러: {e}")
                attempt += 1
                if attempt < self.max_attempts:
                    current_logic = self.request_llm_fix(current_logic, e)
                else:
                    break
        
        # 최대 시도 횟수 초과
        raise AgentGenerationError(
            f"자가 수정 실패 (시도: {self.max_attempts})",
            code=current_logic,
            fix_history=self.fix_history,
            suggestion="더 간단한 쿼리로 시도하거나 수동으로 코드를 검토하세요"
        )
    
    def fix_syntax(self, code: str, error: SyntaxError) -> Optional[str]:
        """구문 에러 자동 수정"""
        logger.info("🔧 구문 에러 수정 시도...")

        # 여러 수정 전략 시도
        error_msg = str(error).lower()

        # try-except 블록 문제 (truncated try block)
        if 'except' in error_msg or 'finally' in error_msg:
            return self.fix_try_without_except(code, error)

        # 들여쓰기 문제
        if 'indent' in error_msg:
            fixed = self.fix_indentation(code, error)
            # 들여쓰기 수정 후에도 truncated block 문제 있을 수 있음
            fixed = self.fix_truncated_blocks(fixed, error)
            return fixed

        # 괄호 문제 (truncated expression)
        if any(x in error_msg for x in ['(', ')', '[', ']', '{', '}', 'never closed', 'was never closed']):
            return self.fix_truncated_expression(code, error)

        # 콜론 누락
        if 'expected' in error_msg and ':' in error_msg:
            return self.fix_missing_colon(code, error)

        # 따옴표 문제 (unterminated string)
        if any(x in error_msg for x in ["'", '"', 'string', 'unterminated']):
            return self.fix_unterminated_string(code, error)

        # 일반 truncated code 수정
        return self.fix_truncated_blocks(code, error)
    
    def fix_indentation(self, code: str, error: Any) -> str:
        """들여쓰기 자동 수정"""
        logger.info("🔧 들여쓰기 수정 중...")
        
        lines = code.split('\n')
        fixed_lines = []
        indent_stack = [0]
        
        for i, line in enumerate(lines):
            stripped = line.lstrip()
            if not stripped or stripped.startswith('#'):
                fixed_lines.append(line)
                continue
            
            # 블록 시작
            if any(stripped.startswith(kw) for kw in ['def ', 'class ', 'if ', 'for ', 'while ', 'try:', 'with ']):
                indent = indent_stack[-1]
                fixed_lines.append(' ' * indent + stripped)
                if stripped.endswith(':'):
                    indent_stack.append(indent + 4)
            # 블록 중간
            elif any(stripped.startswith(kw) for kw in ['elif ', 'else:', 'except:', 'finally:']):
                if len(indent_stack) > 1:
                    indent_stack.pop()
                indent = indent_stack[-1]
                fixed_lines.append(' ' * indent + stripped)
                if stripped.endswith(':'):
                    indent_stack.append(indent + 4)
            # 블록 종료
            elif stripped in ('pass', 'break', 'continue') or stripped.startswith('return'):
                indent = indent_stack[-1]
                fixed_lines.append(' ' * indent + stripped)
                if len(indent_stack) > 1:
                    indent_stack.pop()
            # 일반 라인
            else:
                indent = indent_stack[-1]
                fixed_lines.append(' ' * indent + stripped)
        
        return '\n'.join(fixed_lines)
    
    def fix_brackets(self, code: str, error: Any) -> str:
        """괄호 불일치 수정"""
        logger.info("🔧 괄호 수정 중...")
        
        # 각 괄호 타입별 카운트
        brackets = {
            '(': code.count('('),
            ')': code.count(')'),
            '[': code.count('['),
            ']': code.count(']'),
            '{': code.count('{'),
            '}': code.count('}')
        }
        
        # 괄호 균형 맞추기
        if brackets['('] > brackets[')']:
            code += ')' * (brackets['('] - brackets[')'])
        if brackets['['] > brackets[']']:
            code += ']' * (brackets['['] - brackets[']'])
        if brackets['{'] > brackets['}']:
            code += '}' * (brackets['{'] - brackets['}'])
        
        return code
    
    def fix_missing_colon(self, code: str, error: Any) -> str:
        """콜론 누락 수정"""
        logger.info("🔧 콜론 수정 중...")
        
        lines = code.split('\n')
        fixed_lines = []
        
        keywords = ['if ', 'elif ', 'else', 'for ', 'while ', 'def ', 'class ', 'try', 'except', 'finally', 'with ']
        
        for line in lines:
            stripped = line.strip()
            # 키워드로 시작하지만 콜론으로 끝나지 않는 경우
            if any(stripped.startswith(kw) for kw in keywords):
                if not stripped.endswith(':'):
                    line = line.rstrip() + ':'
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def fix_quotes(self, code: str, error: Any) -> str:
        """따옴표 문제 수정"""
        logger.info("🔧 따옴표 수정 중...")
        
        # 따옴표 짝 맞추기
        single_quotes = code.count("'") - code.count("\\'")
        double_quotes = code.count('"') - code.count('\\"')
        
        # 홀수면 하나 더 추가
        if single_quotes % 2 != 0:
            code += "'"
        if double_quotes % 2 != 0:
            code += '"'
        
        return code
    
    def fix_undefined_names(self, code: str, error: Any) -> str:
        """정의되지 않은 이름 수정"""
        logger.info("🔧 undefined names 수정 중...")
        
        # 일반적인 누락 import 추가
        common_imports = [
            'import logging',
            'from typing import Dict, Any, Optional, List',
            'from datetime import datetime',
            'import json',
            'import asyncio'
        ]
        
        # 필요한 import 추가
        imports_to_add = []
        if 'logger' in code and 'import logger' not in code:
            imports_to_add.append('from loguru import logger')
        if 'pd.' in code and 'import pandas' not in code:
            imports_to_add.append('import pandas as pd')
        if 'np.' in code and 'import numpy' not in code:
            imports_to_add.append('import numpy as np')
        
        if imports_to_add:
            code = '\n'.join(imports_to_add) + '\n\n' + code
        
        return code
    
    def semantic_validation(self, tree: ast.Module) -> List[str]:
        """의미론적 검증"""
        errors = []
        
        # 클래스 정의 확인
        classes = [node for node in tree.body if isinstance(node, ast.ClassDef)]
        if not classes:
            errors.append("No class definition found")
        
        # 필수 메서드 확인
        for cls in classes:
            methods = [node.name for node in cls.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
            if '__init__' not in methods:
                errors.append(f"Class {cls.name} missing __init__ method")
            if 'process' not in methods:
                errors.append(f"Class {cls.name} missing process method")
        
        return errors
    
    def fix_semantic_errors(self, code: str, errors: List[str]) -> str:
        """의미론적 에러 수정"""
        logger.info(f"🔧 의미론적 에러 수정: {errors}")
        
        # 각 에러에 대한 수정 적용
        for error in errors:
            if "missing __init__" in error:
                # __init__ 메서드 추가
                code = self.add_init_method(code)
            elif "missing process" in error:
                # process 메서드 추가
                code = self.add_process_method(code)
        
        return code
    
    def add_init_method(self, code: str) -> str:
        """__init__ 메서드 추가"""
        # 간단한 __init__ 템플릿
        init_template = """
    def __init__(self):
        super().__init__()
        logger.info("Agent initialized")
"""
        # 클래스 정의 찾아서 추가
        lines = code.split('\n')
        for i, line in enumerate(lines):
            if line.strip().startswith('class '):
                # 클래스 다음 줄에 추가
                lines.insert(i + 1, init_template)
                break
        
        return '\n'.join(lines)
    
    def add_process_method(self, code: str) -> str:
        """process 메서드 추가"""
        # 간단한 process 템플릿
        process_template = """
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict:
        result = await self._process_core_logic(query)
        return result
"""
        # 클래스 끝에 추가
        return code + '\n' + process_template
    
    def integrate_domain_module(self, tree: ast.Module, domain_module) -> ast.Module:
        """도메인 모듈 통합"""
        logger.info(f"🔧 도메인 모듈 통합: {domain_module.__class__.__name__}")
        
        # 도메인 특화 import 추가
        if hasattr(domain_module, 'get_required_imports'):
            imports = domain_module.get_required_imports()
            for imp in imports:
                # AST import 노드 생성
                if '.' in imp:
                    module, name = imp.rsplit('.', 1)
                    import_node = ast.ImportFrom(
                        module=module,
                        names=[ast.alias(name=name, asname=None)],
                        level=0
                    )
                else:
                    import_node = ast.Import(
                        names=[ast.alias(name=imp, asname=None)]
                    )
                tree.body.insert(0, import_node)
        
        return tree
    
    def request_llm_fix(self, code: str, error: Exception) -> str:
        """LLM에게 코드 수정 요청"""
        logger.info("🤖 LLM에게 수정 요청...")
        
        # 실제 구현에서는 LLM API 호출
        # 여기서는 간단한 fallback 로직
        error_str = str(error)
        
        # 일반적인 수정 시도
        if 'indent' in error_str.lower():
            return self.fix_indentation(code, error)
        elif 'syntax' in error_str.lower():
            return self.fix_syntax(code, error)
        else:
            # 수정 불가능 - 원본 반환
            return code
    
    def fix_type_errors(self, code: str, error: Any) -> str:
        """타입 에러 수정"""
        logger.info("🔧 타입 에러 수정 중...")
        
        # 타입 힌트 제거 (임시 해결책)
        code = re.sub(r':\s*\w+\[.*?\]', '', code)  # Generic 타입 힌트 제거
        code = re.sub(r':\s*\w+\s*=', ' =', code)  # 일반 타입 힌트 제거
        
        return code
    
    def fix_attribute_errors(self, code: str, error: Any) -> str:
        """속성 에러 수정"""
        logger.info("🔧 속성 에러 수정 중...")

        # self. 누락 추가
        lines = code.split('\n')
        fixed_lines = []

        for line in lines:
            # 메서드 내부에서 변수 접근 시 self. 추가
            if 'def ' in line:
                in_method = True
            if in_method and not line.strip().startswith('self.'):
                # 변수명 패턴 매칭
                line = re.sub(r'\b([a-z_]\w*)\s*=', r'self.\1 =', line)

            fixed_lines.append(line)

        return '\n'.join(fixed_lines)

    def fix_try_without_except(self, code: str, error: Any) -> str:
        """try 블록에 except 누락 수정 (코드 잘림 대응)"""
        logger.info("🔧 try-except 블록 수정 중...")

        lines = code.split('\n')
        fixed_lines = []
        try_stack = []  # (line_index, indent_level)

        for i, line in enumerate(lines):
            stripped = line.lstrip()
            current_indent = len(line) - len(stripped)

            # try: 블록 시작
            if stripped.startswith('try:'):
                try_stack.append((i, current_indent))

            # except/finally 발견 시 매칭되는 try 제거
            elif stripped.startswith(('except', 'finally:')):
                if try_stack:
                    try_stack.pop()

            # 새로운 메서드/클래스 정의 발견 시 열린 try 블록 처리
            elif stripped.startswith(('def ', 'async def ', 'class ')):
                while try_stack:
                    try_idx, try_indent = try_stack.pop()
                    # try와 같은 레벨이거나 낮은 레벨의 def/class면 except 삽입 필요
                    if current_indent <= try_indent:
                        except_block = ' ' * (try_indent + 4) + 'pass\n'
                        except_block += ' ' * try_indent + 'except Exception as e:\n'
                        except_block += ' ' * (try_indent + 4) + 'logger.error(f"Error: {e}")\n'
                        except_block += ' ' * (try_indent + 4) + 'return {"error": str(e)}\n'
                        fixed_lines.append(except_block)

            fixed_lines.append(line)

        # 파일 끝에 열린 try 블록 처리
        while try_stack:
            try_idx, try_indent = try_stack.pop()
            except_block = '\n' + ' ' * (try_indent + 4) + 'pass\n'
            except_block += ' ' * try_indent + 'except Exception as e:\n'
            except_block += ' ' * (try_indent + 4) + 'logger.error(f"Error: {e}")\n'
            except_block += ' ' * (try_indent + 4) + 'return {"error": str(e)}'
            fixed_lines.append(except_block)

        return '\n'.join(fixed_lines)

    def fix_truncated_blocks(self, code: str, error: Any) -> str:
        """잘린 코드 블록 수정 (if/elif/else/try without body)"""
        logger.info("🔧 잘린 코드 블록 수정 중...")

        lines = code.split('\n')
        fixed_lines = []

        for i, line in enumerate(lines):
            stripped = line.lstrip()
            current_indent = len(line) - len(stripped)

            # 코드 블록 시작 키워드
            block_starters = ['if ', 'elif ', 'else:', 'for ', 'while ', 'try:', 'except', 'finally:', 'with ', 'def ', 'async def ', 'class ']

            # 현재 라인이 블록 시작인지 확인
            is_block_start = any(stripped.startswith(kw) for kw in block_starters)

            # 다음 라인 확인
            next_line = lines[i + 1].lstrip() if i + 1 < len(lines) else ''
            next_indent = len(lines[i + 1]) - len(lines[i + 1].lstrip()) if i + 1 < len(lines) else 0

            fixed_lines.append(line)

            # 블록 시작인데 다음 라인이 같거나 낮은 들여쓰기면 pass 추가
            if is_block_start and stripped.endswith(':'):
                if i + 1 >= len(lines) or next_indent <= current_indent:
                    # 다음 라인이 없거나, 다음 라인이 블록 내용이 아니면 pass 추가
                    if not next_line or any(next_line.startswith(kw) for kw in ['elif ', 'else:', 'except', 'finally:']):
                        continue  # except/else 등은 pass 없이 진행
                    fixed_lines.append(' ' * (current_indent + 4) + 'pass')

        return '\n'.join(fixed_lines)

    def fix_truncated_expression(self, code: str, error: Any) -> str:
        """잘린 표현식 수정 (괄호/연산자로 끝나는 코드)"""
        logger.info("🔧 잘린 표현식 수정 중...")

        lines = code.split('\n')
        fixed_lines = []

        for i, line in enumerate(lines):
            stripped = line.rstrip()

            # 잘린 표현식 패턴 감지
            truncation_patterns = [
                (r'\(\s*$', '0)'),  # ( 로 끝남
                (r',\s*$', 'None)'),  # , 로 끝남 (함수 인자 중간)
                (r'\+\s*$', '0'),  # + 로 끝남
                (r'-\s*$', '0'),  # - 로 끝남
                (r'\*\s*$', '1'),  # * 로 끝남
                (r'/\s*$', '1'),  # / 로 끝남
                (r'=\s*$', 'None'),  # = 로 끝남
                (r'\[\s*$', '0]'),  # [ 로 끝남
                (r'\{\s*$', '}'),  # { 로 끝남
                (r':\s*$', ''),  # : 로 끝남 (딕셔너리 키 다음)
            ]

            for pattern, replacement in truncation_patterns:
                if re.search(pattern, stripped):
                    stripped = stripped + replacement
                    break

            fixed_lines.append(stripped)

        # 전체 괄호 균형 맞추기
        result = '\n'.join(fixed_lines)
        return self.fix_brackets(result, error)

    def fix_unterminated_string(self, code: str, error: Any) -> str:
        """미완성 문자열 수정"""
        logger.info("🔧 미완성 문자열 수정 중...")

        lines = code.split('\n')
        fixed_lines = []

        for line in lines:
            fixed_line = line

            # 라인에서 문자열 리터럴 분석
            in_string = False
            string_char = None
            escaped = False

            for j, char in enumerate(line):
                if escaped:
                    escaped = False
                    continue
                if char == '\\':
                    escaped = True
                    continue
                if char in ('"', "'") and not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char and in_string:
                    in_string = False
                    string_char = None

            # 문자열이 닫히지 않았으면 닫기
            if in_string and string_char:
                fixed_line = line.rstrip() + string_char

            fixed_lines.append(fixed_line)

        return '\n'.join(fixed_lines)