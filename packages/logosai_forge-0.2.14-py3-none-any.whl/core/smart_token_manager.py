#!/usr/bin/env python3
"""
🧠 지능형 토큰 관리 시스템
실시간 토큰 측정, 적응형 할당, 비용 최적화를 제공하는 고급 토큰 매니저
"""

import re
import json
import logging
from typing import Dict, Any, Tuple, Optional, List
from dataclasses import dataclass
from enum import Enum
import tiktoken  # OpenAI 토큰 카운터 (Google Gemini와 유사한 카운팅)

logger = logging.getLogger(__name__)

class CodeComplexity(Enum):
    """코드 복잡도 레벨"""
    SIMPLE = "simple"      # ~50줄, 간단한 수정
    MEDIUM = "medium"      # ~200줄, 일반적인 수정  
    LARGE = "large"        # ~500줄, 대형 파일
    XLARGE = "xlarge"      # ~1000줄, 매우 큰 파일
    MASSIVE = "massive"    # 1000줄+, 극대형 파일

@dataclass
class TokenStrategy:
    """토큰 할당 전략"""
    max_tokens: int
    temperature: float
    chunk_size: Optional[int] = None  # 청크 분할이 필요한 경우
    use_chunking: bool = False
    cost_tier: str = "standard"  # low, standard, high, premium
    
class SmartTokenManager:
    """지능형 토큰 관리 시스템"""
    
    def __init__(self):
        """초기화"""
        try:
            # tiktoken을 사용해 토큰 측정 (GPT-4 기준, Gemini와 유사)
            self.tokenizer = tiktoken.get_encoding("cl100k_base")
            logger.info("✅ Tiktoken 토큰화 엔진 초기화 완료")
        except Exception as e:
            logger.warning(f"⚠️ Tiktoken 초기화 실패: {e}, 대체 방식 사용")
            self.tokenizer = None
            
        # 토큰 전략 매핑
        self.strategies = {
            CodeComplexity.SIMPLE: TokenStrategy(
                max_tokens=2000,
                temperature=0.1,
                cost_tier="low"
            ),
            CodeComplexity.MEDIUM: TokenStrategy(
                max_tokens=4000, 
                temperature=0.1,
                cost_tier="standard"
            ),
            CodeComplexity.LARGE: TokenStrategy(
                max_tokens=8000,
                temperature=0.1,
                cost_tier="high"
            ),
            CodeComplexity.XLARGE: TokenStrategy(
                max_tokens=15000,
                temperature=0.1,
                cost_tier="high"
            ),
            CodeComplexity.MASSIVE: TokenStrategy(
                max_tokens=20000,
                temperature=0.1,
                use_chunking=True,
                chunk_size=800,
                cost_tier="premium"
            )
        }
        
        # 토큰 사용량 통계 추적
        self.usage_stats = {
            'total_requests': 0,
            'total_tokens_used': 0,
            'avg_tokens_per_request': 0,
            'complexity_distribution': {complexity.value: 0 for complexity in CodeComplexity}
        }
        
    def count_tokens(self, text: str) -> int:
        """정확한 토큰 수 계산"""
        if self.tokenizer:
            try:
                return len(self.tokenizer.encode(text))
            except Exception as e:
                logger.warning(f"토큰 계산 실패: {e}, 추정 방식 사용")
        
        # Fallback: 경험적 추정 (1 token ≈ 4 characters for code)
        return max(1, len(text) // 4)
    
    def analyze_code_complexity(self, code: str, error: str = "") -> CodeComplexity:
        """코드 복잡도 자동 분석"""
        code_lines = len(code.split('\n'))
        code_chars = len(code)
        
        # 구조적 복잡도 요소 분석
        complexity_indicators = {
            'classes': len(re.findall(r'class\s+\w+', code)),
            'functions': len(re.findall(r'def\s+\w+', code)),
            'imports': len(re.findall(r'import\s+\w+|from\s+\w+', code)),
            'decorators': len(re.findall(r'@\w+', code)),
            'loops': len(re.findall(r'for\s+\w+|while\s+\w+', code)),
            'conditionals': len(re.findall(r'if\s+\w+|elif\s+\w+', code)),
            'try_blocks': len(re.findall(r'try:|except\s+\w+:', code))
        }
        
        # 에러 복잡도 분석
        error_complexity_score = 0
        complex_error_patterns = [
            'ImportError', 'ModuleNotFoundError', 'StructureError', 
            'RefactoringNeeded', 'TypeError', 'AttributeError'
        ]
        
        for pattern in complex_error_patterns:
            if pattern in error:
                error_complexity_score += 1
                
        # 전체 복잡도 점수 계산
        structural_score = sum(complexity_indicators.values())
        
        # 라인 수 기반 기본 복잡도
        if code_lines <= 50 and structural_score <= 3:
            complexity = CodeComplexity.SIMPLE
        elif code_lines <= 200 and structural_score <= 10:
            complexity = CodeComplexity.MEDIUM
        elif code_lines <= 500 and structural_score <= 25:
            complexity = CodeComplexity.LARGE
        elif code_lines <= 1000:
            complexity = CodeComplexity.XLARGE
        else:
            complexity = CodeComplexity.MASSIVE
            
        # 에러 복잡도로 인한 승격
        if error_complexity_score >= 2:
            complexity_values = list(CodeComplexity)
            current_index = complexity_values.index(complexity)
            if current_index < len(complexity_values) - 1:
                complexity = complexity_values[current_index + 1]
                
        logger.info(f"🔍 코드 복잡도 분석: {complexity.value}")
        logger.debug(f"📊 분석 지표 - 라인: {code_lines}, 구조: {structural_score}, 에러: {error_complexity_score}")
        
        return complexity
    
    def calculate_optimal_tokens(
        self, 
        code: str, 
        error: str = "", 
        context: str = ""
    ) -> Tuple[int, TokenStrategy, Dict[str, Any]]:
        """최적 토큰 수와 전략 계산"""
        
        # 1. 코드 복잡도 분석
        complexity = self.analyze_code_complexity(code, error)
        
        # 2. 기본 전략 가져오기
        strategy = self.strategies[complexity]
        
        # 3. 실제 토큰 수 측정
        input_tokens = (
            self.count_tokens(code) + 
            self.count_tokens(error) + 
            self.count_tokens(context) +
            200  # 프롬프트 오버헤드
        )
        
        # 4. 응답 토큰 추정 (입력 토큰의 1.2배 + 안전 마진 30%)
        estimated_response_tokens = int(input_tokens * 1.2 * 1.3)
        
        # 5. 동적 토큰 조정
        dynamic_max_tokens = max(strategy.max_tokens, estimated_response_tokens)
        
        # 6. 상한선 적용 (비용 제한)
        if dynamic_max_tokens > 25000:  # 극단적 케이스 방지
            logger.warning(f"⚠️ 토큰 요구량이 매우 큼: {dynamic_max_tokens}, 청킹 사용")
            strategy.use_chunking = True
            strategy.chunk_size = 1000
            dynamic_max_tokens = 20000
        
        # 7. 최종 전략 업데이트
        final_strategy = TokenStrategy(
            max_tokens=dynamic_max_tokens,
            temperature=strategy.temperature,
            chunk_size=strategy.chunk_size,
            use_chunking=strategy.use_chunking,
            cost_tier=strategy.cost_tier
        )
        
        # 8. 분석 메트릭 생성
        analysis_metrics = {
            'complexity': complexity.value,
            'input_tokens': input_tokens,
            'estimated_response_tokens': estimated_response_tokens,
            'final_max_tokens': dynamic_max_tokens,
            'cost_tier': final_strategy.cost_tier,
            'use_chunking': final_strategy.use_chunking,
            'code_lines': len(code.split('\n')),
            'code_chars': len(code)
        }
        
        # 9. 통계 업데이트
        self.usage_stats['total_requests'] += 1
        self.usage_stats['complexity_distribution'][complexity.value] += 1
        
        logger.info(f"🎯 최적 토큰 계산 완료: {dynamic_max_tokens} tokens ({complexity.value})")
        
        return dynamic_max_tokens, final_strategy, analysis_metrics
    
    def should_use_chunking(self, code: str, max_tokens: int) -> bool:
        """청킹 사용 여부 결정"""
        code_tokens = self.count_tokens(code)
        
        # 코드만으로 토큰의 60% 이상 사용하면 청킹 고려
        return code_tokens > (max_tokens * 0.6)
    
    def split_code_into_chunks(self, code: str, chunk_size: int = 800) -> List[str]:
        """코드를 의미있는 청크로 분할"""
        lines = code.split('\n')
        chunks = []
        current_chunk = []
        current_size = 0
        
        for line in lines:
            line_tokens = self.count_tokens(line)
            
            # 청크 크기 초과시 새로운 청크 시작
            if current_size + line_tokens > chunk_size and current_chunk:
                chunks.append('\n'.join(current_chunk))
                current_chunk = [line]
                current_size = line_tokens
            else:
                current_chunk.append(line)
                current_size += line_tokens
        
        # 마지막 청크 추가
        if current_chunk:
            chunks.append('\n'.join(current_chunk))
        
        logger.info(f"📦 코드를 {len(chunks)}개 청크로 분할")
        return chunks
    
    def get_cost_estimation(self, tokens: int, cost_tier: str) -> Dict[str, float]:
        """비용 추정 (Gemini 2.5 Flash 기준)"""
        # 2024년 기준 대략적인 비용 (실제 비용은 Google 요금표 참조)
        cost_per_1k_tokens = {
            'low': 0.002,      # 간단한 요청
            'standard': 0.004,  # 일반 요청
            'high': 0.006,     # 복잡한 요청
            'premium': 0.010   # 최고급 요청
        }
        
        cost = (tokens / 1000) * cost_per_1k_tokens.get(cost_tier, 0.004)
        
        return {
            'estimated_cost_usd': round(cost, 4),
            'tokens_used': tokens,
            'cost_tier': cost_tier
        }
    
    def update_usage_stats(self, tokens_used: int, complexity: str, success: bool):
        """사용량 통계 업데이트"""
        self.usage_stats['total_tokens_used'] += tokens_used
        
        if self.usage_stats['total_requests'] > 0:
            self.usage_stats['avg_tokens_per_request'] = (
                self.usage_stats['total_tokens_used'] / 
                self.usage_stats['total_requests']
            )
    
    def get_optimization_suggestions(self) -> List[str]:
        """토큰 사용 최적화 제안"""
        suggestions = []
        
        if self.usage_stats['total_requests'] < 10:
            return ["📊 충분한 사용 데이터가 쌓이면 최적화 제안을 드리겠습니다."]
        
        avg_tokens = self.usage_stats['avg_tokens_per_request']
        
        if avg_tokens > 10000:
            suggestions.append("🔧 평균 토큰 사용량이 높습니다. 코드를 더 작은 단위로 나누어 수정을 요청해보세요.")
        
        massive_ratio = (
            self.usage_stats['complexity_distribution']['massive'] / 
            self.usage_stats['total_requests']
        )
        
        if massive_ratio > 0.3:
            suggestions.append("📦 대형 코드 비율이 높습니다. 청킹 전략을 더 적극적으로 사용하는 것을 권장합니다.")
        
        if not suggestions:
            suggestions.append("✅ 토큰 사용량이 효율적입니다!")
        
        return suggestions
    
    def export_metrics(self) -> Dict[str, Any]:
        """메트릭 내보내기"""
        return {
            'usage_stats': self.usage_stats,
            'available_strategies': {k.value: {
                'max_tokens': v.max_tokens,
                'cost_tier': v.cost_tier,
                'use_chunking': v.use_chunking
            } for k, v in self.strategies.items()},
            'optimization_suggestions': self.get_optimization_suggestions()
        }
