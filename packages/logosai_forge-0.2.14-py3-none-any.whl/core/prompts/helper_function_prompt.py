"""
Helper 함수 생성을 위한 강력한 프롬프트 템플릿
"""

HELPER_FUNCTION_GENERATION_PROMPT = """
당신은 Python 코드 생성 전문가입니다. 반드시 완전하고 실행 가능한 코드를 생성해야 합니다.

⚠️ 절대 규칙 - 위반 시 실패:
1. 모든 함수는 완전한 구현체를 가져야 함
2. 주석으로 대체 금지
3. pass 문 사용 금지
4. TODO 작성 금지

사용자 요구사항: {user_query}

🎯 당신의 임무:
아래 형식으로 정확히 helper 함수들과 메인 실행 코드를 작성하세요.

===== 필수 생성 코드 구조 =====

# Step 1: Helper 함수들 (필요한 경우)
{helper_definitions}

# Step 2: 메인 실행 코드
{main_execution}

===== 코드 생성 =====

예시 (반드시 이 형식을 따르세요):

```python
# Helper 함수 정의
def calculate_score(data1, data2):
    common = set(data1) & set(data2)
    total = set(data1) | set(data2)
    if total:
        return len(common) / len(total) * 100
    return 0

def validate_data(data):
    if not data or not isinstance(data, (list, dict)):
        return False
    if isinstance(data, dict):
        return len(data) > 0
    return len(data) > 0

# 메인 실행 코드
if not validate_data(extracted_info):
    result = {{"status": "error", "message": "Invalid data"}}
else:
    score = calculate_score(data1, data2)
    result = {{"status": "success", "score": score}}
```

반드시 위 예시처럼 완전한 함수 구현을 작성하세요.
주석이나 pass로 대체하면 안 됩니다.

지금 코드를 생성하세요:
"""

VALIDATE_HELPER_PROMPT = """
다음 코드를 검토하고 helper 함수가 제대로 구현되었는지 확인하세요:

{code}

검사 항목:
1. 모든 호출된 함수가 정의되어 있는가?
2. 함수 구현이 완전한가? (pass나 주석이 아닌)
3. 함수 호출과 정의의 파라미터가 일치하는가?

문제가 있다면 수정된 코드를 제공하세요.
"""