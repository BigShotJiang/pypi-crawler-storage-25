"""
Prompt Registry for FORGE AI

Global registry for prompt management with A/B testing support.
"""

from typing import Dict, Optional, List, Any
import random
import logging
from .prompt_manager import PromptManager, PromptTemplate

logger = logging.getLogger(__name__)


class PromptRegistry:
    """Global prompt registry with A/B testing support"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
        
    def __init__(self):
        if self._initialized:
            return
            
        self.prompt_manager = PromptManager()
        self.ab_tests: Dict[str, Dict[str, Any]] = {}
        self.usage_stats: Dict[str, Dict[str, int]] = {}
        self._initialized = True
        
    def get_prompt(self, prompt_id: str, ab_test: bool = True) -> PromptTemplate:
        """
        Get prompt with optional A/B testing.
        
        Args:
            prompt_id: Prompt identifier
            ab_test: Whether to use A/B testing
            
        Returns:
            Selected prompt template
        """
        # Check for active A/B test
        if ab_test and prompt_id in self.ab_tests:
            return self._select_ab_variant(prompt_id)
            
        # Return default prompt
        prompt = self.prompt_manager.get_prompt(prompt_id)
        if prompt:
            self._record_usage(prompt_id, "default")
            
        return prompt
        
    def render_prompt(self, prompt_id: str, **kwargs) -> str:
        """Render prompt with A/B testing support"""
        prompt = self.get_prompt(prompt_id)
        if not prompt:
            raise ValueError(f"Prompt not found: {prompt_id}")
            
        return prompt.render(**kwargs)
        
    def start_ab_test(self, prompt_id: str, variants: List[PromptTemplate],
                     weights: Optional[List[float]] = None):
        """
        Start A/B test for a prompt.
        
        Args:
            prompt_id: Base prompt ID
            variants: List of variant prompts
            weights: Optional weights for each variant
        """
        if not weights:
            weights = [1.0 / len(variants)] * len(variants)
            
        self.ab_tests[prompt_id] = {
            'variants': variants,
            'weights': weights,
            'results': {v.id: {'usage': 0, 'success': 0} for v in variants}
        }
        
        logger.info(f"Started A/B test for {prompt_id} with {len(variants)} variants")
        
    def _select_ab_variant(self, prompt_id: str) -> PromptTemplate:
        """Select variant for A/B test"""
        test_data = self.ab_tests[prompt_id]
        variants = test_data['variants']
        weights = test_data['weights']
        
        # Weighted random selection
        selected = random.choices(variants, weights=weights)[0]
        
        # Record selection
        test_data['results'][selected.id]['usage'] += 1
        self._record_usage(prompt_id, selected.id)
        
        return selected
        
    def record_result(self, prompt_id: str, variant_id: str, success: bool):
        """Record A/B test result"""
        if prompt_id in self.ab_tests:
            results = self.ab_tests[prompt_id]['results']
            if variant_id in results and success:
                results[variant_id]['success'] += 1
                
    def _record_usage(self, prompt_id: str, variant: str):
        """Record prompt usage statistics"""
        if prompt_id not in self.usage_stats:
            self.usage_stats[prompt_id] = {}
            
        if variant not in self.usage_stats[prompt_id]:
            self.usage_stats[prompt_id][variant] = 0
            
        self.usage_stats[prompt_id][variant] += 1
        
    def get_stats(self, prompt_id: Optional[str] = None) -> Dict[str, Any]:
        """Get usage statistics"""
        if prompt_id:
            return {
                'usage': self.usage_stats.get(prompt_id, {}),
                'ab_test': self.ab_tests.get(prompt_id)
            }
            
        return {
            'total_prompts': len(self.prompt_manager.prompts),
            'active_ab_tests': len(self.ab_tests),
            'usage_stats': self.usage_stats
        }
        
    def stop_ab_test(self, prompt_id: str, winner_id: Optional[str] = None):
        """Stop A/B test and optionally set winner"""
        if prompt_id not in self.ab_tests:
            return
            
        test_data = self.ab_tests[prompt_id]
        
        # If winner specified, update default
        if winner_id:
            winner = next((v for v in test_data['variants'] if v.id == winner_id), None)
            if winner:
                self.prompt_manager.prompts[prompt_id] = winner
                logger.info(f"A/B test winner for {prompt_id}: {winner_id}")
                
        # Remove test
        del self.ab_tests[prompt_id]
        
    @classmethod
    def get_instance(cls) -> 'PromptRegistry':
        """Get singleton instance"""
        return cls()


# Global instance
prompt_registry = PromptRegistry.get_instance()