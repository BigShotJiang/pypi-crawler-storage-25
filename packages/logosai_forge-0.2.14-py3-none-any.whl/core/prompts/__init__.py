"""
FORGE AI Prompt Management System

Centralized prompt management for all LLM interactions.
Supports versioning, A/B testing, and easy updates.
"""

from .prompt_manager import PromptManager, PromptTemplate
from .prompt_registry import PromptRegistry

# Create global instance
prompt_registry = PromptRegistry()

__all__ = [
    'PromptManager',
    'PromptTemplate',
    'PromptRegistry',
    'prompt_registry'
]