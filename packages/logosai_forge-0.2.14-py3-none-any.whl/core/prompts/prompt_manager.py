"""
Prompt Manager for FORGE AI

Manages all prompts with versioning and easy updates.
"""

import os
import json
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class PromptTemplate:
    """Represents a prompt template"""
    id: str
    name: str
    description: str
    template: str
    variables: List[str]
    version: str = "1.0.0"
    category: str = "general"
    tags: List[str] = None
    examples: Dict[str, Any] = None
    metadata: Dict[str, Any] = None
    created_at: datetime = None
    updated_at: datetime = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []
        if self.examples is None:
            self.examples = {}
        if self.metadata is None:
            self.metadata = {}
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.updated_at is None:
            self.updated_at = datetime.now()
            
    def render(self, **kwargs) -> str:
        """Render the prompt with given variables"""
        try:
            # Check for missing variables
            missing = set(self.variables) - set(kwargs.keys())
            if missing:
                logger.warning(f"Missing variables for prompt {self.id}: {missing}")
                
            # Render template
            return self.template.format(**kwargs)
        except Exception as e:
            logger.error(f"Failed to render prompt {self.id}: {e}")
            raise
            
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'template': self.template,
            'variables': self.variables,
            'version': self.version,
            'category': self.category,
            'tags': self.tags,
            'examples': self.examples,
            'metadata': self.metadata,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class PromptManager:
    """Manages prompts for FORGE AI"""
    
    def __init__(self, prompts_dir: Optional[Path] = None):
        """
        Initialize prompt manager.
        
        Args:
            prompts_dir: Directory containing prompt files
        """
        self.prompts_dir = prompts_dir or Path(__file__).parent / "templates"
        self.prompts: Dict[str, PromptTemplate] = {}
        self._load_prompts()
        
    def _load_prompts(self):
        """Load all prompts from files"""
        # Load from YAML files
        yaml_files = list(self.prompts_dir.glob("*.yaml")) + list(self.prompts_dir.glob("*.yml"))
        for file in yaml_files:
            self._load_yaml_prompts(file)
            
        # Load from JSON files
        json_files = list(self.prompts_dir.glob("*.json"))
        for file in json_files:
            self._load_json_prompts(file)
            
        # Load built-in prompts if no files found
        if not self.prompts:
            self._load_builtin_prompts()
            
        logger.info(f"Loaded {len(self.prompts)} prompts")
        
    def _load_yaml_prompts(self, file_path: Path):
        """Load prompts from YAML file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
                
            if 'prompts' in data:
                for prompt_data in data['prompts']:
                    prompt = PromptTemplate(**prompt_data)
                    self.prompts[prompt.id] = prompt
                    
        except Exception as e:
            logger.error(f"Failed to load YAML prompts from {file_path}: {e}")
            
    def _load_json_prompts(self, file_path: Path):
        """Load prompts from JSON file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            if 'prompts' in data:
                for prompt_data in data['prompts']:
                    prompt = PromptTemplate(**prompt_data)
                    self.prompts[prompt.id] = prompt
                    
        except Exception as e:
            logger.error(f"Failed to load JSON prompts from {file_path}: {e}")
            
    def _load_builtin_prompts(self):
        """Load built-in prompts"""
        builtin_prompts = [
            # Query Analysis Prompts
            PromptTemplate(
                id="query_intent_extraction",
                name="Extract Query Intent",
                description="Extract the main intent from user query",
                template="""Analyze this query and identify the primary intent in a concise phrase (3-5 words).

Query: {query}

Examples of intents:
- "automate data processing"
- "monitor system health"
- "integrate external api"
- "schedule periodic tasks"
- "analyze customer behavior"

Primary intent:""",
                variables=["query"],
                category="query_analysis",
                tags=["analysis", "intent"]
            ),
            
            PromptTemplate(
                id="query_entity_extraction",
                name="Extract Query Entities",
                description="Extract entities and key terms from query",
                template="""Extract key entities from this query and categorize them.

Query: {query}

Categories to consider:
- data_sources: databases, files, APIs, streams
- actions: process, analyze, monitor, alert
- targets: where to send results
- conditions: when/if statements
- timeframes: scheduling, frequencies

Format as JSON with categories as keys and lists of entities as values:""",
                variables=["query"],
                category="query_analysis",
                tags=["analysis", "entities", "nlp"]
            ),
            
            PromptTemplate(
                id="query_capabilities_identification",
                name="Identify Required Capabilities",
                description="Identify agent capabilities needed for the query",
                template="""Based on this query, what capabilities does the agent need?

Query: {query}

Available capabilities:
{available_capabilities}

Analyze the query and list ONLY the required capabilities from the available list.
Consider both explicit and implicit requirements.

Required capabilities (one per line):""",
                variables=["query", "available_capabilities"],
                category="query_analysis",
                tags=["analysis", "capabilities"]
            ),
            
            # Code Generation Prompts
            PromptTemplate(
                id="code_template_selection",
                name="Select Best Template",
                description="Select the most appropriate template for agent generation",
                template="""Select the best template for creating an agent based on these requirements:

Query: {query}
Intent: {intent}
Required Capabilities: {capabilities}
Complexity: {complexity}

Available Templates:
{available_templates}

Consider:
1. Match between template features and requirements
2. Complexity level appropriateness
3. Capability coverage

Selected template (provide template ID only):""",
                variables=["query", "intent", "capabilities", "complexity", "available_templates"],
                category="code_generation",
                tags=["template", "selection"]
            ),
            
            PromptTemplate(
                id="code_context_preparation",
                name="Prepare Template Context",
                description="Prepare context values for template rendering",
                template="""Prepare the context values for template rendering based on the analysis:

Query: {query}
Analysis: {analysis}
Template Requirements: {template_requirements}
Gathered Information: {gathered_info}

Generate appropriate values for each required parameter.
Ensure names follow Python conventions.
Make the values specific to the user's requirements.

Format as JSON with parameter names as keys:""",
                variables=["query", "analysis", "template_requirements", "gathered_info"],
                category="code_generation",
                tags=["template", "context"]
            ),
            
            PromptTemplate(
                id="code_optimization_suggestions",
                name="Suggest Code Optimizations",
                description="Suggest optimizations for generated code",
                template="""Review this generated code and suggest optimizations:

Code Summary:
{code_summary}

Requirements:
{requirements}

Performance Constraints:
{constraints}

Suggest specific optimizations for:
1. Performance improvements
2. Error handling enhancements
3. Resource efficiency
4. Code maintainability

Provide actionable suggestions (one per line):""",
                variables=["code_summary", "requirements", "constraints"],
                category="code_generation",
                tags=["optimization", "code_quality"]
            ),
            
            # Validation Prompts
            PromptTemplate(
                id="validation_security_check",
                name="Security Validation",
                description="Check code for security issues",
                template="""Analyze this code for potential security vulnerabilities:

Code Snippet:
{code_snippet}

Context: {context}

Check for:
1. Injection vulnerabilities (SQL, command, etc.)
2. Insecure data handling
3. Authentication/authorization issues
4. Sensitive data exposure
5. Resource exhaustion risks

Report issues in this format:
- Issue: [description]
  Severity: [high/medium/low]
  Line: [approximate location]
  Fix: [suggested fix]

Security issues found:""",
                variables=["code_snippet", "context"],
                category="validation",
                tags=["security", "validation"]
            ),
            
            # Context Management Prompts
            PromptTemplate(
                id="context_missing_info",
                name="Identify Missing Information",
                description="Identify what information is still needed",
                template="""Based on the requirements and current context, what information is missing?

User Query: {query}
Intent: {intent}
Required Capabilities: {capabilities}
Current Context: {current_context}

Identify missing information from these categories:
{info_categories}

For each missing item, explain why it's needed.

Missing information (format: category - reason):""",
                variables=["query", "intent", "capabilities", "current_context", "info_categories"],
                category="context_management",
                tags=["context", "information_gathering"]
            ),
            
            PromptTemplate(
                id="context_clarifying_question",
                name="Generate Clarifying Question",
                description="Generate natural clarifying questions",
                template="""Generate a natural, user-friendly question to gather this information:

Information Needed: {info_type}
Context: {context}
User's Original Query: {original_query}

Make the question:
1. Clear and specific
2. Contextually relevant
3. Easy to understand
4. Include examples if helpful

Question:""",
                variables=["info_type", "context", "original_query"],
                category="context_management",
                tags=["context", "questions", "ux"]
            ),
            
            # Error Handling Prompts
            PromptTemplate(
                id="error_analysis",
                name="Analyze Error",
                description="Analyze error and suggest fixes",
                template="""Analyze this error and suggest how to fix it:

Error Type: {error_type}
Error Message: {error_message}
Code Context:
{code_context}

Identify:
1. Root cause of the error
2. Why it occurred
3. How to fix it
4. How to prevent it in the future

Provide a specific fix that can be applied:""",
                variables=["error_type", "error_message", "code_context"],
                category="error_handling",
                tags=["error", "debugging", "fixes"]
            ),
            
            # Evolution Prompts
            PromptTemplate(
                id="evolution_performance_analysis",
                name="Analyze Performance for Evolution",
                description="Analyze performance metrics to identify improvements",
                template="""Analyze these performance metrics and suggest evolutionary improvements:

Agent: {agent_name}
Metrics:
{metrics}

Bottlenecks Identified:
{bottlenecks}

Historical Performance:
{history}

Suggest specific improvements for:
1. Performance optimization
2. Resource efficiency
3. Error reduction
4. Feature enhancements

Prioritize suggestions by impact and feasibility:""",
                variables=["agent_name", "metrics", "bottlenecks", "history"],
                category="evolution",
                tags=["evolution", "performance", "optimization"]
            )
        ]
        
        # Add built-in prompts
        for prompt in builtin_prompts:
            self.prompts[prompt.id] = prompt
            
    def get_prompt(self, prompt_id: str, version: Optional[str] = None) -> Optional[PromptTemplate]:
        """
        Get a prompt by ID and optional version.
        
        Args:
            prompt_id: Prompt identifier
            version: Optional specific version
            
        Returns:
            PromptTemplate or None
        """
        if version:
            # Look for specific version
            versioned_id = f"{prompt_id}_v{version}"
            if versioned_id in self.prompts:
                return self.prompts[versioned_id]
                
        return self.prompts.get(prompt_id)
        
    def render_prompt(self, prompt_id: str, **kwargs) -> str:
        """
        Render a prompt with given variables.
        
        Args:
            prompt_id: Prompt identifier
            **kwargs: Variables for rendering
            
        Returns:
            Rendered prompt string
        """
        prompt = self.get_prompt(prompt_id)
        if not prompt:
            raise ValueError(f"Prompt not found: {prompt_id}")
            
        return prompt.render(**kwargs)
        
    def list_prompts(self, category: Optional[str] = None, 
                    tags: Optional[List[str]] = None) -> List[PromptTemplate]:
        """List prompts with optional filters"""
        prompts = list(self.prompts.values())
        
        if category:
            prompts = [p for p in prompts if p.category == category]
            
        if tags:
            prompts = [p for p in prompts if any(tag in p.tags for tag in tags)]
            
        return sorted(prompts, key=lambda p: p.id)
        
    def update_prompt(self, prompt_id: str, template: Optional[str] = None,
                     **kwargs) -> PromptTemplate:
        """Update a prompt (creates new version)"""
        prompt = self.get_prompt(prompt_id)
        if not prompt:
            raise ValueError(f"Prompt not found: {prompt_id}")
            
        # Create new version
        current_version = prompt.version
        major, minor, patch = map(int, current_version.split('.'))
        new_version = f"{major}.{minor}.{patch + 1}"
        
        # Create updated prompt
        updated_data = prompt.to_dict()
        updated_data['version'] = new_version
        updated_data['updated_at'] = datetime.now()
        
        if template:
            updated_data['template'] = template
            
        for key, value in kwargs.items():
            if key in updated_data:
                updated_data[key] = value
                
        # Store with versioned ID
        versioned_id = f"{prompt_id}_v{new_version}"
        updated_prompt = PromptTemplate(**updated_data)
        updated_prompt.id = versioned_id
        
        self.prompts[versioned_id] = updated_prompt
        
        # Update main reference
        self.prompts[prompt_id] = updated_prompt
        
        logger.info(f"Updated prompt {prompt_id} to version {new_version}")
        return updated_prompt
        
    def add_prompt(self, prompt: PromptTemplate):
        """Add a new prompt"""
        self.prompts[prompt.id] = prompt
        logger.info(f"Added prompt: {prompt.id}")
        
    def save_prompts(self, file_path: Optional[Path] = None):
        """Save prompts to file"""
        if not file_path:
            file_path = self.prompts_dir / "prompts.yaml"
            
        data = {
            'version': '1.0.0',
            'prompts': [p.to_dict() for p in self.prompts.values()]
        }
        
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
            
        logger.info(f"Saved {len(self.prompts)} prompts to {file_path}")