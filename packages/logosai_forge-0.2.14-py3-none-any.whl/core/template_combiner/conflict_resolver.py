"""
Conflict Resolver
패턴 간 충돌 해결 모듈
"""

from typing import List, Dict, Any
from dataclasses import dataclass
from loguru import logger


@dataclass
class ConflictResolution:
    """충돌 해결 결과"""
    field: str
    conflicting_patterns: List[str]
    winner: str
    strategy: str  # priority, merge, split, etc.
    reasoning: str


class ConflictResolver:
    """충돌 해결기"""
    
    def __init__(self):
        self.resolution_strategies = {
            "priority": self._resolve_by_priority,
            "merge": self._resolve_by_merge,
            "split": self._resolve_by_split,
            "conditional": self._resolve_by_condition
        }
    
    def resolve(self, conflicts: List[Dict]) -> List[ConflictResolution]:
        """충돌 해결"""
        resolutions = []
        
        for conflict in conflicts:
            strategy = self._select_strategy(conflict)
            resolution = self.resolution_strategies[strategy](conflict)
            resolutions.append(resolution)
        
        return resolutions
    
    def _select_strategy(self, conflict: Dict) -> str:
        """해결 전략 선택"""
        # 간단한 휴리스틱
        if len(conflict.get("conflicting_patterns", [])) == 2:
            return "priority"
        elif len(conflict.get("conflicting_patterns", [])) > 2:
            return "merge"
        else:
            return "conditional"
    
    def _resolve_by_priority(self, conflict: Dict) -> ConflictResolution:
        """우선순위 기반 해결"""
        return ConflictResolution(
            field=conflict["field"],
            conflicting_patterns=conflict["conflicting_patterns"],
            winner=conflict["conflicting_patterns"][0],
            strategy="priority",
            reasoning="Higher priority pattern wins"
        )
    
    def _resolve_by_merge(self, conflict: Dict) -> ConflictResolution:
        """병합을 통한 해결"""
        return ConflictResolution(
            field=conflict["field"],
            conflicting_patterns=conflict["conflicting_patterns"],
            winner="merged",
            strategy="merge",
            reasoning="All patterns merged into composite logic"
        )
    
    def _resolve_by_split(self, conflict: Dict) -> ConflictResolution:
        """분할을 통한 해결"""
        return ConflictResolution(
            field=conflict["field"],
            conflicting_patterns=conflict["conflicting_patterns"],
            winner="split",
            strategy="split",
            reasoning="Field split into multiple sub-fields"
        )
    
    def _resolve_by_condition(self, conflict: Dict) -> ConflictResolution:
        """조건부 해결"""
        return ConflictResolution(
            field=conflict["field"],
            conflicting_patterns=conflict["conflicting_patterns"],
            winner="conditional",
            strategy="conditional",
            reasoning="Applied conditionally based on context"
        )