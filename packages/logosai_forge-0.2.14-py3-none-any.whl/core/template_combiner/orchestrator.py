"""
Template Orchestrator
템플릿 오케스트레이션 모듈
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
from loguru import logger


class ExecutionMode(Enum):
    """실행 모드"""
    SYNC = "sync"
    ASYNC = "async"
    BATCH = "batch"
    STREAM = "stream"


@dataclass
class OrchestrationPlan:
    """오케스트레이션 계획"""
    steps: List[Dict[str, Any]]
    execution_mode: ExecutionMode
    parallelism_level: int
    timeout_seconds: int
    retry_policy: Dict[str, Any]


class TemplateOrchestrator:
    """템플릿 오케스트레이터"""
    
    def __init__(self):
        self.execution_strategies = {
            ExecutionMode.SYNC: self._execute_sync,
            ExecutionMode.ASYNC: self._execute_async,
            ExecutionMode.BATCH: self._execute_batch,
            ExecutionMode.STREAM: self._execute_stream
        }
    
    def create_plan(self, 
                   pattern_count: int,
                   complexity: float,
                   requirements: Dict[str, Any]) -> OrchestrationPlan:
        """오케스트레이션 계획 생성"""
        
        # 실행 모드 결정
        if requirements.get("realtime", False):
            mode = ExecutionMode.STREAM
        elif pattern_count > 10:
            mode = ExecutionMode.BATCH
        elif complexity > 0.7:
            mode = ExecutionMode.ASYNC
        else:
            mode = ExecutionMode.SYNC
        
        # 병렬 수준 결정
        parallelism = min(pattern_count, 4) if mode == ExecutionMode.ASYNC else 1
        
        # 타임아웃 설정
        timeout = 30 if mode == ExecutionMode.SYNC else 60
        
        # 재시도 정책
        retry_policy = {
            "max_retries": 3,
            "backoff": "exponential",
            "retry_on": ["timeout", "connection_error"]
        }
        
        # 스텝 생성
        steps = self._create_execution_steps(pattern_count, mode)
        
        return OrchestrationPlan(
            steps=steps,
            execution_mode=mode,
            parallelism_level=parallelism,
            timeout_seconds=timeout,
            retry_policy=retry_policy
        )
    
    def _create_execution_steps(self, pattern_count: int, mode: ExecutionMode) -> List[Dict]:
        """실행 스텝 생성"""
        steps = []
        
        if mode == ExecutionMode.SYNC:
            for i in range(pattern_count):
                steps.append({
                    "step": f"pattern_{i+1}",
                    "type": "execute",
                    "wait": True
                })
        
        elif mode == ExecutionMode.ASYNC:
            # 병렬 실행 그룹 생성
            for i in range(0, pattern_count, 4):
                group = []
                for j in range(min(4, pattern_count - i)):
                    group.append(f"pattern_{i+j+1}")
                steps.append({
                    "step": f"group_{i//4+1}",
                    "type": "parallel",
                    "patterns": group
                })
        
        elif mode == ExecutionMode.BATCH:
            # 배치 실행
            batch_size = 10
            for i in range(0, pattern_count, batch_size):
                steps.append({
                    "step": f"batch_{i//batch_size+1}",
                    "type": "batch",
                    "start": i,
                    "end": min(i+batch_size, pattern_count)
                })
        
        else:  # STREAM
            steps.append({
                "step": "stream_pipeline",
                "type": "stream",
                "patterns": list(range(1, pattern_count+1))
            })
        
        return steps
    
    def _execute_sync(self, plan: OrchestrationPlan) -> Dict[str, Any]:
        """동기 실행"""
        logger.info("Executing in SYNC mode")
        return {"mode": "sync", "steps": len(plan.steps)}
    
    def _execute_async(self, plan: OrchestrationPlan) -> Dict[str, Any]:
        """비동기 실행"""
        logger.info(f"Executing in ASYNC mode with parallelism={plan.parallelism_level}")
        return {"mode": "async", "parallelism": plan.parallelism_level}
    
    def _execute_batch(self, plan: OrchestrationPlan) -> Dict[str, Any]:
        """배치 실행"""
        logger.info("Executing in BATCH mode")
        return {"mode": "batch", "batches": len(plan.steps)}
    
    def _execute_stream(self, plan: OrchestrationPlan) -> Dict[str, Any]:
        """스트림 실행"""
        logger.info("Executing in STREAM mode")
        return {"mode": "stream", "pipeline": True}