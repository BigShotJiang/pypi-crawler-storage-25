"""
Dependency Manager
패턴 간 의존성 관리 모듈
"""

from typing import List, Dict, Set, Optional
from dataclasses import dataclass
from collections import defaultdict
from loguru import logger


@dataclass
class DependencyGraph:
    """의존성 그래프"""
    nodes: List[str]  # 패턴 ID들
    edges: Dict[str, List[str]]  # 의존성 엣지
    execution_order: List[str]  # 실행 순서


class DependencyManager:
    """의존성 관리자"""
    
    def __init__(self):
        self.dependency_rules = self._load_dependency_rules()
    
    def _load_dependency_rules(self) -> Dict:
        """의존성 규칙 로드"""
        return {
            # 패턴 간 의존성 정의
            "data_validation": {
                "requires": ["data_transformation"],
                "provides": ["validated_data"]
            },
            "discount_rate_apply": {
                "requires": ["tier_based_filtering"],
                "provides": ["discounted_price"]
            },
            "data_ranking": {
                "requires": ["data_aggregation"],
                "provides": ["ranked_data"]
            },
            "threshold_alert": {
                "requires": [],
                "provides": ["alert_status"]
            }
        }
    
    def analyze(self, pattern_ids: List[str]) -> DependencyGraph:
        """의존성 분석"""
        edges = defaultdict(list)
        
        # 의존성 엣지 구축
        for pattern_id in pattern_ids:
            if pattern_id in self.dependency_rules:
                deps = self.dependency_rules[pattern_id].get("requires", [])
                for dep in deps:
                    if dep in pattern_ids:
                        edges[dep].append(pattern_id)
        
        # 실행 순서 계산 (위상 정렬)
        execution_order = self._topological_sort(pattern_ids, edges)
        
        return DependencyGraph(
            nodes=pattern_ids,
            edges=dict(edges),
            execution_order=execution_order
        )
    
    def _topological_sort(self, nodes: List[str], edges: Dict[str, List[str]]) -> List[str]:
        """위상 정렬"""
        visited = set()
        stack = []
        
        def visit(node: str):
            if node in visited:
                return
            visited.add(node)
            
            # 이 노드에 의존하는 노드들 먼저 방문
            for dependent in edges.get(node, []):
                visit(dependent)
            
            stack.append(node)
        
        # 모든 노드 방문
        for node in nodes:
            visit(node)
        
        # 역순이 실행 순서
        return list(reversed(stack))
    
    def find_cycles(self, graph: DependencyGraph) -> List[List[str]]:
        """순환 의존성 찾기"""
        cycles = []
        visited = set()
        rec_stack = set()
        
        def find_cycles_util(node: str, path: List[str]) -> bool:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)
            
            for neighbor in graph.edges.get(node, []):
                if neighbor not in visited:
                    if find_cycles_util(neighbor, path.copy()):
                        return True
                elif neighbor in rec_stack:
                    # 순환 발견
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:])
            
            path.pop()
            rec_stack.remove(node)
            return False
        
        for node in graph.nodes:
            if node not in visited:
                find_cycles_util(node, [])
        
        return cycles