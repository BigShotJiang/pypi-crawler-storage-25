"""
Advanced Template Combiner
패턴 조합, 충돌 해결, 의존성 관리를 통한 고급 템플릿 생성
"""

from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from loguru import logger
import json

from ..business_patterns.pattern_matcher import PatternMatch
from ..business_logic.logic_generator import GeneratedLogic


class CombinationStrategy(Enum):
    """패턴 조합 전략"""
    SEQUENTIAL = "sequential"      # 순차 실행
    PARALLEL = "parallel"          # 병렬 실행
    CONDITIONAL = "conditional"    # 조건부 실행
    PIPELINE = "pipeline"          # 파이프라인 체이닝
    HYBRID = "hybrid"             # 혼합 전략


@dataclass
class CombinedResult:
    """조합된 결과"""
    code: str                          # 최종 생성 코드
    template_type: str                 # 선택된 템플릿 타입
    combination_strategy: CombinationStrategy  # 사용된 조합 전략
    execution_order: List[str]         # 실행 순서
    dependencies: Dict[str, List[str]] # 의존성 맵
    conflicts_resolved: List[Dict]     # 해결된 충돌
    metadata: Dict[str, Any]          # 메타데이터


class AdvancedTemplateCombiner:
    """고급 템플릿 조합기"""
    
    def __init__(self):
        """초기화"""
        self.templates = self._load_advanced_templates()
        self.combination_rules = self._load_combination_rules()
        logger.info("AdvancedTemplateCombiner initialized")
    
    def _load_advanced_templates(self) -> Dict[str, str]:
        """고급 템플릿 로드"""
        return {
            "microservice": """
# Microservice Architecture Template
{imports}
import asyncio
from typing import Optional
from dataclasses import dataclass

@dataclass
class ServiceConfig:
    name: str = "{service_name}"
    version: str = "1.0.0"
    port: int = 8000

class {class_name}Service:
    \"\"\"마이크로서비스 비즈니스 로직\"\"\"
    
    def __init__(self, config: ServiceConfig = None):
        self.config = config or ServiceConfig()
        self.handlers = {{}}
        self._setup_handlers()
    
    def _setup_handlers(self):
        \"\"\"핸들러 설정\"\"\"
{handler_setup}
    
{methods}
    
    async def process_request(self, request_type: str, data: Dict):
        \"\"\"요청 처리\"\"\"
        handler = self.handlers.get(request_type)
        if not handler:
            raise ValueError(f"Unknown request type: {{request_type}}")
        
        # 실행 체인
{execution_chain}
        
        return result
    
    async def run(self):
        \"\"\"서비스 실행\"\"\"
        logger.info(f"Starting {{self.config.name}} v{{self.config.version}}")
        # 서비스 로직
        await self.process_request("default", {{}})
""",
            
            "event_driven": """
# Event-Driven Architecture Template
{imports}
from typing import Callable
from collections import defaultdict
import asyncio

class EventBus:
    \"\"\"이벤트 버스\"\"\"
    def __init__(self):
        self.handlers = defaultdict(list)
    
    def on(self, event: str, handler: Callable):
        self.handlers[event].append(handler)
    
    async def emit(self, event: str, data: Any):
        for handler in self.handlers[event]:
            await handler(data)

class {class_name}EventProcessor:
    \"\"\"이벤트 기반 비즈니스 로직\"\"\"
    
    def __init__(self):
        self.event_bus = EventBus()
        self._register_handlers()
    
    def _register_handlers(self):
        \"\"\"이벤트 핸들러 등록\"\"\"
{event_registration}
    
{methods}
    
    async def process_event_chain(self, initial_event: str, data: Dict):
        \"\"\"이벤트 체인 처리\"\"\"
        # 이벤트 처리 플로우
{event_flow}
        
        return processed_data
""",
            
            "batch_processor": """
# Batch Processing Template
{imports}
from concurrent.futures import ThreadPoolExecutor
import asyncio

class {class_name}BatchProcessor:
    \"\"\"배치 처리 비즈니스 로직\"\"\"
    
    def __init__(self, batch_size: int = 100, workers: int = 4):
        self.batch_size = batch_size
        self.executor = ThreadPoolExecutor(max_workers=workers)
    
{methods}
    
    def process_batch(self, items: List[Dict]) -> List[Dict]:
        \"\"\"배치 처리\"\"\"
        results = []
        
        # 배치 단위로 처리
        for i in range(0, len(items), self.batch_size):
            batch = items[i:i+self.batch_size]
            
            # 배치 처리 로직
{batch_logic}
            
            results.extend(batch_results)
        
        return results
    
    async def process_parallel(self, items: List[Dict]) -> List[Dict]:
        \"\"\"병렬 배치 처리\"\"\"
        loop = asyncio.get_event_loop()
        
        # 병렬 처리 로직
{parallel_logic}
        
        return await asyncio.gather(*tasks)
""",
            
            "realtime_stream": """
# Real-time Stream Processing Template
{imports}
import asyncio
from collections import deque
from datetime import datetime

class {class_name}StreamProcessor:
    \"\"\"실시간 스트림 처리 로직\"\"\"
    
    def __init__(self, window_size: int = 100):
        self.window = deque(maxlen=window_size)
        self.processors = []
        self._setup_processors()
    
    def _setup_processors(self):
        \"\"\"프로세서 설정\"\"\"
{processor_setup}
    
{methods}
    
    async def process_stream(self, item: Dict) -> Optional[Dict]:
        \"\"\"스트림 아이템 처리\"\"\"
        # 윈도우에 추가
        self.window.append(item)
        
        # 스트림 처리 체인
{stream_chain}
        
        return result
    
    async def run_stream(self, stream_source):
        \"\"\"스트림 실행\"\"\"
        async for item in stream_source:
            result = await self.process_stream(item)
            if result:
                yield result
""",
            
            "orchestrated": """
# Orchestrated Workflow Template
{imports}
from enum import Enum
from typing import Any, Callable
import asyncio

class StepStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"

class {class_name}Orchestrator:
    \"\"\"오케스트레이션 워크플로우\"\"\"
    
    def __init__(self):
        self.steps = {{}}
        self.step_order = []
        self.results = {{}}
        self._define_workflow()
    
    def _define_workflow(self):
        \"\"\"워크플로우 정의\"\"\"
{workflow_definition}
    
{methods}
    
    async def execute_workflow(self, input_data: Dict) -> Dict:
        \"\"\"워크플로우 실행\"\"\"
        context = {{"input": input_data}}
        
        for step_name in self.step_order:
            step_func = self.steps[step_name]
            
            try:
                # 스텝 실행
{step_execution}
                
                context[step_name] = result
                self.results[step_name] = StepStatus.SUCCESS
                
            except Exception as e:
                logger.error(f"Step {{step_name}} failed: {{e}}")
                self.results[step_name] = StepStatus.FAILED
                
                # 실패 처리
{failure_handling}
        
        return context
"""
        }
    
    def _load_combination_rules(self) -> Dict[str, Any]:
        """조합 규칙 로드"""
        return {
            "strategy_selection": {
                # 패턴 개수와 복잡도에 따른 전략 선택
                "simple": {  # 1-2개 패턴
                    "default": CombinationStrategy.SEQUENTIAL
                },
                "moderate": {  # 3-5개 패턴
                    "independent": CombinationStrategy.PARALLEL,
                    "dependent": CombinationStrategy.PIPELINE,
                    "mixed": CombinationStrategy.HYBRID
                },
                "complex": {  # 6개 이상 패턴
                    "workflow": CombinationStrategy.PIPELINE,
                    "event_based": CombinationStrategy.CONDITIONAL,
                    "default": CombinationStrategy.HYBRID
                }
            },
            
            "template_selection": {
                # 패턴 타입에 따른 템플릿 선택
                "realtime": ["threshold_alert", "consecutive_event_alert"],
                "batch": ["data_aggregation", "data_transformation"],
                "event": ["pattern_detection_alert", "conditional_filter"],
                "service": ["tier_based_filtering", "discount_rate_apply"],
                "workflow": ["data_validation", "data_ranking"]
            },
            
            "conflict_priorities": {
                # 충돌 시 우선순위
                "data_modification": ["validation", "transformation", "aggregation"],
                "filtering": ["security", "tier", "condition", "count"],
                "alerting": ["critical", "warning", "info"],
                "pricing": ["discount", "tier", "dynamic", "coupon"]
            }
        }
    
    def combine(self, 
                pattern_matches: List[PatternMatch],
                generated_logic: List[GeneratedLogic],
                user_query: str) -> CombinedResult:
        """
        패턴과 로직을 조합하여 최종 코드 생성
        
        Args:
            pattern_matches: 매칭된 패턴들
            generated_logic: 생성된 로직들
            user_query: 원본 사용자 쿼리
            
        Returns:
            조합된 결과
        """
        logger.info(f"Combining {len(pattern_matches)} patterns with advanced templates")
        
        # 1. 조합 전략 결정
        strategy = self._determine_strategy(pattern_matches, generated_logic)
        logger.info(f"Selected strategy: {strategy}")
        
        # 2. 템플릿 선택
        template_type = self._select_template(pattern_matches, strategy)
        logger.info(f"Selected template: {template_type}")
        
        # 3. 의존성 분석
        dependencies = self._analyze_dependencies(pattern_matches, generated_logic)
        
        # 4. 실행 순서 결정
        execution_order = self._determine_execution_order(pattern_matches, dependencies)
        
        # 5. 충돌 해결
        conflicts_resolved = self._resolve_conflicts(pattern_matches, generated_logic)
        
        # 6. 코드 생성
        code = self._generate_combined_code(
            template_type,
            strategy,
            generated_logic,
            execution_order,
            dependencies
        )
        
        return CombinedResult(
            code=code,
            template_type=template_type,
            combination_strategy=strategy,
            execution_order=execution_order,
            dependencies=dependencies,
            conflicts_resolved=conflicts_resolved,
            metadata={
                "pattern_count": len(pattern_matches),
                "query": user_query,
                "confidence_avg": sum(p.confidence_score for p in pattern_matches) / len(pattern_matches)
            }
        )
    
    def _determine_strategy(self, 
                          patterns: List[PatternMatch],
                          logic: List[GeneratedLogic]) -> CombinationStrategy:
        """조합 전략 결정"""
        pattern_count = len(patterns)
        
        # 패턴 간 의존성 확인
        has_dependencies = self._check_dependencies(patterns)
        
        # 병렬 실행 가능 여부
        can_parallel = self._check_parallel_capability(logic)
        
        if pattern_count <= 2:
            return CombinationStrategy.SEQUENTIAL
        elif pattern_count <= 5:
            if not has_dependencies and can_parallel:
                return CombinationStrategy.PARALLEL
            elif has_dependencies:
                return CombinationStrategy.PIPELINE
            else:
                return CombinationStrategy.HYBRID
        else:
            # 복잡한 경우
            if self._requires_orchestration(patterns):
                return CombinationStrategy.PIPELINE
            else:
                return CombinationStrategy.HYBRID
    
    def _select_template(self, patterns: List[PatternMatch], strategy: CombinationStrategy) -> str:
        """템플릿 선택"""
        # 패턴 타입 분석
        pattern_types = [p.pattern_id for p in patterns]
        
        # 실시간 처리 패턴이 있는지
        if any(pt in self.combination_rules["template_selection"]["realtime"] for pt in pattern_types):
            return "realtime_stream"
        
        # 배치 처리 패턴이 있는지
        if any(pt in self.combination_rules["template_selection"]["batch"] for pt in pattern_types):
            return "batch_processor"
        
        # 이벤트 기반 패턴이 있는지
        if any(pt in self.combination_rules["template_selection"]["event"] for pt in pattern_types):
            return "event_driven"
        
        # 워크플로우 패턴이 있는지
        if any(pt in self.combination_rules["template_selection"]["workflow"] for pt in pattern_types):
            return "orchestrated"
        
        # 기본: 마이크로서비스
        return "microservice"
    
    def _analyze_dependencies(self, 
                             patterns: List[PatternMatch],
                             logic: List[GeneratedLogic]) -> Dict[str, List[str]]:
        """의존성 분석"""
        dependencies = {}
        
        for i, pattern in enumerate(patterns):
            pattern_deps = []
            
            # 다른 패턴의 출력을 입력으로 사용하는지 확인
            for j, other in enumerate(patterns):
                if i != j:
                    if self._depends_on(pattern, other):
                        pattern_deps.append(other.pattern_id)
            
            dependencies[pattern.pattern_id] = pattern_deps
        
        return dependencies
    
    def _determine_execution_order(self, 
                                  patterns: List[PatternMatch],
                                  dependencies: Dict[str, List[str]]) -> List[str]:
        """실행 순서 결정 (위상 정렬)"""
        # 의존성 그래프를 기반으로 위상 정렬
        visited = set()
        order = []
        
        def visit(pattern_id: str):
            if pattern_id in visited:
                return
            visited.add(pattern_id)
            
            # 의존하는 패턴들을 먼저 방문
            for dep in dependencies.get(pattern_id, []):
                visit(dep)
            
            order.append(pattern_id)
        
        for pattern in patterns:
            visit(pattern.pattern_id)
        
        return order
    
    def _resolve_conflicts(self, 
                         patterns: List[PatternMatch],
                         logic: List[GeneratedLogic]) -> List[Dict]:
        """충돌 해결"""
        conflicts = []
        
        # 같은 필드를 수정하는 패턴들 찾기
        field_modifiers = {}
        for pattern in patterns:
            for slot_name in pattern.extracted_slots:
                if slot_name not in field_modifiers:
                    field_modifiers[slot_name] = []
                field_modifiers[slot_name].append(pattern.pattern_id)
        
        # 충돌 해결
        for field, modifiers in field_modifiers.items():
            if len(modifiers) > 1:
                # 우선순위에 따라 해결
                resolution = self._resolve_field_conflict(field, modifiers)
                conflicts.append(resolution)
        
        return conflicts
    
    def _generate_combined_code(self,
                               template_type: str,
                               strategy: CombinationStrategy,
                               logic_list: List[GeneratedLogic],
                               execution_order: List[str],
                               dependencies: Dict[str, List[str]]) -> str:
        """조합된 코드 생성"""
        template = self.templates.get(template_type, self.templates["microservice"])
        
        # imports 통합
        all_imports = set()
        for logic in logic_list:
            all_imports.update(logic.imports)
        imports_str = "\n".join(sorted(all_imports))
        
        # methods 통합
        methods = []
        for logic in logic_list:
            # 들여쓰기 조정
            indented_code = "\n".join(f"    {line}" if line else "" 
                                     for line in logic.code.split("\n"))
            methods.append(indented_code)
        methods_str = "\n".join(methods)
        
        # 실행 체인 생성
        execution_chain = self._create_execution_chain(
            strategy, 
            logic_list, 
            execution_order,
            dependencies
        )
        
        # 템플릿별 특수 처리
        if template_type == "microservice":
            code = self._fill_microservice_template(
                template, imports_str, methods_str, execution_chain, logic_list
            )
        elif template_type == "event_driven":
            code = self._fill_event_template(
                template, imports_str, methods_str, execution_chain, logic_list
            )
        elif template_type == "batch_processor":
            code = self._fill_batch_template(
                template, imports_str, methods_str, execution_chain, logic_list
            )
        elif template_type == "realtime_stream":
            code = self._fill_stream_template(
                template, imports_str, methods_str, execution_chain, logic_list
            )
        else:  # orchestrated
            code = self._fill_orchestrated_template(
                template, imports_str, methods_str, execution_chain, logic_list
            )
        
        return code
    
    def _create_execution_chain(self,
                               strategy: CombinationStrategy,
                               logic_list: List[GeneratedLogic],
                               execution_order: List[str],
                               dependencies: Dict[str, List[str]]) -> str:
        """실행 체인 생성"""
        chain_code = []
        
        if strategy == CombinationStrategy.SEQUENTIAL:
            # 순차 실행
            chain_code.append("# Sequential Execution")
            for pattern_id in execution_order:
                logic = next((l for l in logic_list if l.pattern_id == pattern_id), None)
                if logic:
                    func_name = self._extract_function_name(logic.code)
                    chain_code.append(f"        result = await self.{func_name}(result)")
        
        elif strategy == CombinationStrategy.PARALLEL:
            # 병렬 실행
            chain_code.append("# Parallel Execution")
            chain_code.append("        tasks = []")
            for logic in logic_list:
                func_name = self._extract_function_name(logic.code)
                chain_code.append(f"        tasks.append(self.{func_name}(data))")
            chain_code.append("        results = await asyncio.gather(*tasks)")
            chain_code.append("        result = self._merge_results(results)")
        
        elif strategy == CombinationStrategy.PIPELINE:
            # 파이프라인 실행
            chain_code.append("# Pipeline Execution")
            chain_code.append("        pipeline_data = data")
            for pattern_id in execution_order:
                logic = next((l for l in logic_list if l.pattern_id == pattern_id), None)
                if logic:
                    func_name = self._extract_function_name(logic.code)
                    deps = dependencies.get(pattern_id, [])
                    if deps:
                        chain_code.append(f"        # Depends on: {', '.join(deps)}")
                    chain_code.append(f"        pipeline_data = await self.{func_name}(pipeline_data)")
            chain_code.append("        result = pipeline_data")
        
        else:  # HYBRID or CONDITIONAL
            # 혼합 실행
            chain_code.append("# Hybrid Execution")
            chain_code.append("        result = data")
            for logic in logic_list:
                func_name = self._extract_function_name(logic.code)
                chain_code.append(f"        if self._should_execute('{logic.pattern_id}', result):")
                chain_code.append(f"            result = await self.{func_name}(result)")
        
        return "\n".join(chain_code)
    
    def _extract_function_name(self, code: str) -> str:
        """코드에서 함수 이름 추출"""
        import re
        match = re.search(r'def (\w+)\(', code)
        if match:
            return match.group(1)
        return "process"
    
    def _fill_microservice_template(self, template, imports, methods, chain, logic_list):
        """마이크로서비스 템플릿 채우기"""
        # 핸들러 설정 생성
        handler_setup = []
        for logic in logic_list:
            func_name = self._extract_function_name(logic.code)
            handler_setup.append(f"        self.handlers['{logic.pattern_id}'] = self.{func_name}")
        
        return template.format(
            imports=imports,
            service_name="BusinessLogic",
            class_name="BusinessLogic",
            handler_setup="\n".join(handler_setup),
            methods=methods,
            execution_chain=chain
        )
    
    def _fill_event_template(self, template, imports, methods, chain, logic_list):
        """이벤트 템플릿 채우기"""
        # 이벤트 등록 생성
        event_registration = []
        for logic in logic_list:
            func_name = self._extract_function_name(logic.code)
            event_registration.append(
                f"        self.event_bus.on('{logic.pattern_id}_event', self.{func_name})"
            )
        
        # 이벤트 플로우 생성
        event_flow = []
        for logic in logic_list:
            event_flow.append(
                f"        await self.event_bus.emit('{logic.pattern_id}_event', data)"
            )
        event_flow.append("        processed_data = data")
        
        return template.format(
            imports=imports,
            class_name="BusinessLogic",
            event_registration="\n".join(event_registration),
            methods=methods,
            event_flow="\n".join(event_flow)
        )
    
    def _fill_batch_template(self, template, imports, methods, chain, logic_list):
        """배치 템플릿 채우기"""
        # 배치 로직 생성
        batch_logic = []
        for logic in logic_list:
            func_name = self._extract_function_name(logic.code)
            batch_logic.append(f"            batch_results = [self.{func_name}(item) for item in batch]")
        
        # 병렬 로직 생성
        parallel_logic = []
        parallel_logic.append("        tasks = []")
        for logic in logic_list:
            func_name = self._extract_function_name(logic.code)
            parallel_logic.append(
                f"        tasks.extend([loop.run_in_executor(self.executor, self.{func_name}, item) for item in items])"
            )
        
        return template.format(
            imports=imports,
            class_name="BusinessLogic",
            methods=methods,
            batch_logic="\n".join(batch_logic) if batch_logic else "            batch_results = batch",
            parallel_logic="\n".join(parallel_logic)
        )
    
    def _fill_stream_template(self, template, imports, methods, chain, logic_list):
        """스트림 템플릿 채우기"""
        # 프로세서 설정 생성
        processor_setup = []
        for logic in logic_list:
            func_name = self._extract_function_name(logic.code)
            processor_setup.append(f"        self.processors.append(self.{func_name})")
        
        # 스트림 체인 생성
        stream_chain = []
        stream_chain.append("        result = item")
        for logic in logic_list:
            func_name = self._extract_function_name(logic.code)
            stream_chain.append(f"        result = await self.{func_name}(result)")
        
        return template.format(
            imports=imports,
            class_name="BusinessLogic",
            processor_setup="\n".join(processor_setup),
            methods=methods,
            stream_chain="\n".join(stream_chain)
        )
    
    def _fill_orchestrated_template(self, template, imports, methods, chain, logic_list):
        """오케스트레이션 템플릿 채우기"""
        # 워크플로우 정의 생성
        workflow_definition = []
        for i, logic in enumerate(logic_list):
            func_name = self._extract_function_name(logic.code)
            workflow_definition.append(f"        self.steps['step_{i+1}'] = self.{func_name}")
            workflow_definition.append(f"        self.step_order.append('step_{i+1}')")
        
        # 스텝 실행 생성
        step_execution = "                result = await step_func(context)"
        
        # 실패 처리 생성
        failure_handling = """                if self.results[step_name] == StepStatus.FAILED:
                    # 실패 시 중단 또는 복구 로직
                    break"""
        
        return template.format(
            imports=imports,
            class_name="BusinessLogic",
            workflow_definition="\n".join(workflow_definition),
            methods=methods,
            step_execution=step_execution,
            failure_handling=failure_handling
        )
    
    # 헬퍼 메서드들
    def _check_dependencies(self, patterns: List[PatternMatch]) -> bool:
        """패턴 간 의존성 확인"""
        # 간단한 휴리스틱: 데이터 변환 후 필터링 등
        pattern_types = [p.pattern_id for p in patterns]
        
        # 의존성이 있는 패턴 조합
        dependent_pairs = [
            ("data_transformation", "data_validation"),
            ("tier_based_filtering", "discount_rate_apply"),
            ("data_aggregation", "data_ranking"),
        ]
        
        for dep1, dep2 in dependent_pairs:
            if dep1 in pattern_types and dep2 in pattern_types:
                return True
        
        return False
    
    def _check_parallel_capability(self, logic: List[GeneratedLogic]) -> bool:
        """병렬 실행 가능 여부 확인"""
        # 모든 로직이 독립적인지 확인
        # 간단한 휴리스틱: 상태 변경이 없는 읽기 전용 작업
        for l in logic:
            if "self." in l.code or "global" in l.code:
                return False
        return True
    
    def _requires_orchestration(self, patterns: List[PatternMatch]) -> bool:
        """오케스트레이션 필요 여부"""
        # 복잡한 워크플로우가 필요한지 확인
        return len(patterns) > 5 or any(p.confidence_score < 0.5 for p in patterns)
    
    def _depends_on(self, pattern1: PatternMatch, pattern2: PatternMatch) -> bool:
        """pattern1이 pattern2에 의존하는지 확인"""
        # 간단한 휴리스틱: pattern2의 출력이 pattern1의 입력인지
        # 실제로는 더 복잡한 로직 필요
        deps_map = {
            "data_validation": ["data_transformation"],
            "discount_rate_apply": ["tier_based_filtering"],
            "data_ranking": ["data_aggregation"],
        }
        
        return pattern2.pattern_id in deps_map.get(pattern1.pattern_id, [])
    
    def _resolve_field_conflict(self, field: str, modifiers: List[str]) -> Dict:
        """필드 충돌 해결"""
        # 우선순위에 따라 해결
        priorities = self.combination_rules["conflict_priorities"]
        
        # 카테고리별 우선순위 확인
        for category, priority_list in priorities.items():
            relevant_modifiers = [m for m in modifiers if any(p in m for p in priority_list)]
            if relevant_modifiers:
                # 우선순위가 높은 것 선택
                winner = relevant_modifiers[0]
                return {
                    "field": field,
                    "conflicting_patterns": modifiers,
                    "resolution": winner,
                    "strategy": "priority_based"
                }
        
        # 기본: 첫 번째 것 선택
        return {
            "field": field,
            "conflicting_patterns": modifiers,
            "resolution": modifiers[0],
            "strategy": "first_wins"
        }