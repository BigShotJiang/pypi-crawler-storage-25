"""
Ultimate Template Combiner - 완벽한 템플릿 조합
모든 에러 케이스 처리 및 타입 일관성 보장
"""

import re
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass
from enum import Enum
from datetime import datetime
from loguru import logger

try:
    from ..business_patterns.pattern_matcher import PatternMatch
except:
    PatternMatch = None
    
try:
    from ..business_logic.logic_generator import GeneratedLogic
except:
    GeneratedLogic = None


class UltimateTemplateCombiner:
    """완벽한 템플릿 결합기 - 모든 통합 문제 해결"""
    
    def __init__(self):
        self.templates = self._load_templates()
        
    def _load_templates(self) -> Dict[str, str]:
        """Load all template types"""
        return {
            "microservice": self._get_microservice_template(),
            "event_driven": self._get_event_driven_template(),
            "batch_processor": self._get_batch_processor_template(),
            "realtime_stream": self._get_realtime_stream_template(),
            "orchestrated": self._get_orchestrated_template()
        }
    
    def _get_microservice_template(self) -> str:
        return '''# Microservice Architecture Template
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import asyncio
{imports}

app = FastAPI()

class BusinessLogicService:
    """마이크로서비스 비즈니스 로직"""
    
    def __init__(self):
        self.config = {{}}
    
{business_logic}
    
    async def health_check(self):
        """헬스 체크"""
        return {{"status": "healthy", "service": "business_logic"}}

# API Endpoints
service = BusinessLogicService()

@app.get("/health")
async def health():
    return await service.health_check()

@app.post("/process")
async def process_request(data: dict):
    return await service.process(data)
'''

    def _get_event_driven_template(self) -> str:
        return '''# Event-Driven Architecture Template
from typing import List, Dict, Any, Optional
from typing import Callable
from collections import defaultdict
import asyncio
{imports}

class EventBus:
    """이벤트 버스"""
    def __init__(self):
        self.handlers = defaultdict(list)
    
    def on(self, event: str, handler: Callable):
        self.handlers[event].append(handler)
    
    async def emit(self, event: str, data: Any):
        for handler in self.handlers[event]:
            await handler(data)

class BusinessLogicEventProcessor:
    """이벤트 기반 비즈니스 로직"""
    
    def __init__(self):
        self.event_bus = EventBus()
        self._register_handlers()
    
    def _register_handlers(self):
        """이벤트 핸들러 등록"""
        # Register handlers based on available methods
        pass
    
{business_logic}
    
    async def process_event_chain(self, initial_event: str, data: Dict):
        """이벤트 체인 처리"""
        await self.event_bus.emit(initial_event, data)
        return data
'''

    def _get_batch_processor_template(self) -> str:
        return '''# Batch Processing Template
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor
import asyncio
{imports}

class BusinessLogicBatchProcessor:
    """배치 처리 비즈니스 로직"""
    
    def __init__(self, batch_size: int = 100, workers: int = 4):
        self.batch_size = batch_size
        self.executor = ThreadPoolExecutor(max_workers=workers)
    
{business_logic}
    
    def process_batch(self, items: List[Dict]) -> List[Dict]:
        """배치 처리"""
        results = []
        
        # 배치 단위로 처리
        for i in range(0, len(items), self.batch_size):
            batch = items[i:i+self.batch_size]
            
            # 배치 처리 로직
            batch_results = [self.process(item) for item in batch]
            results.extend(batch_results)
        
        return results
    
    async def process_parallel(self, items: List[Dict]) -> List[Dict]:
        """병렬 배치 처리"""
        loop = asyncio.get_event_loop()
        
        # 병렬 처리
        tasks = [loop.run_in_executor(self.executor, self.process, item) for item in items]
        return await asyncio.gather(*tasks)
'''

    def _get_realtime_stream_template(self) -> str:
        return '''# Real-time Stream Processing Template
from typing import List, Dict, Any, Optional
import asyncio
from collections import deque
from datetime import datetime
{imports}

class BusinessLogicStreamProcessor:
    """실시간 스트림 처리 로직"""
    
    def __init__(self, window_size: int = 100):
        self.window = deque(maxlen=window_size)
        self.processors = []
        self._setup_processors()
    
    def _setup_processors(self):
        """프로세서 설정"""
        # Setup will be configured based on available methods
        pass
    
{business_logic}
    
    async def process_stream(self, item: Dict) -> Optional[Dict]:
        """스트림 아이템 처리"""
        # 윈도우에 추가
        self.window.append(item)
        
        # 처리 로직 실행
        result = await self.process(item)
        return result
    
    async def run_stream(self, stream_source):
        """스트림 실행"""
        async for item in stream_source:
            result = await self.process_stream(item)
            if result:
                yield result
'''

    def _get_orchestrated_template(self) -> str:
        return '''# Orchestrated Workflow Template
from typing import List, Dict, Any, Optional
from enum import Enum
import asyncio
import logging
{imports}

logger = logging.getLogger(__name__)

class StepStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"

class BusinessLogicOrchestrator:
    """오케스트레이션 워크플로우"""
    
    def __init__(self):
        self.steps = {{}}
        self.step_order = []
        self.results = {{}}
        self._define_workflow()
    
    def _define_workflow(self):
        """워크플로우 정의"""
        # Workflow will be configured based on available methods
        pass
    
{business_logic}
    
    async def execute_workflow(self, input_data: Dict) -> Dict:
        """워크플로우 실행"""
        context = {{"input": input_data}}
        
        for step_name in self.step_order:
            if step_name in self.steps:
                step_func = self.steps[step_name]
                
                try:
                    # 스텝 실행
                    if asyncio.iscoroutinefunction(step_func):
                        result = await step_func(context)
                    else:
                        result = step_func(context)
                    
                    context[step_name] = result
                    self.results[step_name] = StepStatus.SUCCESS
                    
                except Exception as e:
                    logger.error(f"Step {{step_name}} failed: {{e}}")
                    self.results[step_name] = StepStatus.FAILED
                    break
        
        return context
'''
    
    def select_template(self, patterns: List[str]) -> str:
        """Select appropriate template based on patterns"""
        # Template selection logic
        if any('realtime' in p or 'stream' in p for p in patterns):
            return 'realtime_stream'
        elif any('event' in p or 'async' in p for p in patterns):
            return 'event_driven'
        elif any('batch' in p or 'bulk' in p for p in patterns):
            return 'batch_processor'
        elif any('workflow' in p or 'orchestr' in p for p in patterns):
            return 'orchestrated'
        else:
            return 'microservice'
    
    def combine(self, template_type: str, business_logic: Dict[str, Any], patterns: List[str]) -> str:
        """Combine template with business logic - perfect integration"""
        
        # Get template
        template = self.templates.get(template_type, self.templates['microservice'])
        
        # Process business logic functions
        functions = business_logic.get('functions', [])
        imports = business_logic.get('imports', [])
        
        # Ensure all functions are properly formatted as methods
        processed_functions = []
        for func_code in functions:
            # Function is already properly formatted with self parameter
            # Just need to indent it properly
            indented_code = '\n'.join(f"    {line}" if line else "" 
                                     for line in func_code.split('\n'))
            processed_functions.append(indented_code)
        
        # Join functions with proper spacing
        business_logic_code = '\n\n'.join(processed_functions)
        
        # Join imports
        imports_code = '\n'.join(imports)
        
        # Replace placeholders
        final_code = template.replace('{business_logic}', business_logic_code)
        final_code = final_code.replace('{imports}', imports_code)
        
        # Clean up double braces that might cause issues
        final_code = final_code.replace('{{{{', '{{')
        final_code = final_code.replace('}}}}', '}}')
        
        # Fix any f-string issues
        final_code = self._fix_fstring_issues(final_code)
        
        return final_code
    
    def _fix_fstring_issues(self, code: str) -> str:
        """Fix common f-string formatting issues"""
        # Fix f-strings with literal braces inside expressions
        # Example: f'{value}' is fine, f'{{value}}' needs to be f'{value}'
        
        # Pattern to find f-strings
        fstring_pattern = r"f['\"].*?['\"]"
        
        def fix_fstring(match):
            fstring = match.group(0)
            # Remove double braces inside f-string expressions
            # But keep literal braces that should be displayed
            fixed = re.sub(r'\{\{(\w+)\}\}', r'{\1}', fstring)
            return fixed
        
        # Apply fixes
        fixed_code = re.sub(fstring_pattern, fix_fstring, code, flags=re.DOTALL)
        
        return fixed_code