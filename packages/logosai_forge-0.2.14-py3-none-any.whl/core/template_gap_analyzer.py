"""
Template Gap Analyzer
=====================
템플릿 커버리지 분석 및 갭 식별 시스템
"""

import json
from typing import Dict, List, Set, Tuple, Any
from pathlib import Path
from collections import defaultdict
from loguru import logger


class TemplateGapAnalyzer:
    """템플릿 갭 분석기"""
    
    def __init__(self, template_metadata: Dict[str, Dict]):
        self.template_metadata = template_metadata
        self.coverage_map = self._build_coverage_map()
        self.identified_gaps = []
    
    def _build_coverage_map(self) -> Dict[str, Set[str]]:
        """커버리지 맵 구축"""
        coverage = {
            'domains': set(),
            'capabilities': set(),
            'categories': set(),
            'complexities': set(),
            'frameworks': set(),
            'use_cases': set()
        }
        
        for template in self.template_metadata.values():
            coverage['categories'].add(template.get('category', ''))
            coverage['capabilities'].update(template.get('capabilities', []))
            coverage['complexities'].add(template.get('difficulty', ''))
            coverage['frameworks'].add(template.get('framework', ''))
            
            # 도메인 추출
            keywords = template.get('keywords', [])
            for keyword in keywords:
                if keyword in ['금융', 'finance', '데이터', 'data', '웹', 'web']:
                    coverage['domains'].add(keyword)
            
            coverage['use_cases'].update(template.get('use_cases', []))
        
        return coverage
    
    def analyze_gaps(self) -> Dict[str, List[str]]:
        """갭 분석 수행"""
        gaps = {
            'missing_domains': [],
            'missing_capabilities': [],
            'missing_complexities': [],
            'missing_integrations': [],
            'missing_use_cases': []
        }
        
        # 예상 도메인 vs 실제 커버리지
        expected_domains = {
            'healthcare', 'education', 'retail', 'manufacturing',
            'gaming', 'social_media', 'iot', 'blockchain', 'security'
        }
        
        current_domains = {d.lower() for d in self.coverage_map['domains']}
        gaps['missing_domains'] = list(expected_domains - current_domains)
        
        # 예상 기능 vs 실제 커버리지
        expected_capabilities = {
            'voice_recognition', 'video_processing', 'blockchain_integration',
            'iot_communication', 'edge_computing', 'quantum_ready',
            'ar_vr_support', 'multi_language', 'distributed_processing',
            'event_streaming', 'graphql_api', 'microservices'
        }
        
        current_capabilities = self.coverage_map['capabilities']
        gaps['missing_capabilities'] = list(expected_capabilities - current_capabilities)
        
        # 통합 갭
        expected_integrations = {
            'slack', 'discord', 'telegram', 'whatsapp',
            'google_workspace', 'microsoft_365', 'salesforce',
            'aws', 'azure', 'gcp', 'kubernetes', 'docker'
        }
        
        # 현재 통합 확인
        current_integrations = set()
        for template in self.template_metadata.values():
            keywords = ' '.join(template.get('keywords', [])).lower()
            for integration in expected_integrations:
                if integration in keywords:
                    current_integrations.add(integration)
        
        gaps['missing_integrations'] = list(expected_integrations - current_integrations)
        
        # 사용 사례 갭
        expected_use_cases = {
            '의료 진단 지원', '교육 콘텐츠 생성', '게임 AI',
            'DevOps 자동화', '보안 취약점 스캔', 'IoT 디바이스 관리',
            '블록체인 거래 분석', '소셜 미디어 영향력 분석',
            '음성 비서', '영상 콘텐츠 생성'
        }
        
        current_use_cases = self.coverage_map['use_cases']
        gaps['missing_use_cases'] = list(expected_use_cases - current_use_cases)
        
        self.identified_gaps = gaps
        return gaps
    
    def prioritize_gaps(self) -> List[Dict[str, Any]]:
        """갭 우선순위 결정"""
        prioritized = []
        
        # 각 갭에 대한 점수 계산
        for domain in self.identified_gaps['missing_domains']:
            score = self._calculate_gap_score(domain, 'domain')
            prioritized.append({
                'type': 'domain',
                'name': domain,
                'score': score,
                'impact': self._assess_impact(domain, 'domain')
            })
        
        for capability in self.identified_gaps['missing_capabilities']:
            score = self._calculate_gap_score(capability, 'capability')
            prioritized.append({
                'type': 'capability',
                'name': capability,
                'score': score,
                'impact': self._assess_impact(capability, 'capability')
            })
        
        # 점수순 정렬
        prioritized.sort(key=lambda x: x['score'], reverse=True)
        
        return prioritized[:10]  # 상위 10개
    
    def _calculate_gap_score(self, item: str, item_type: str) -> float:
        """갭 점수 계산"""
        base_score = 0.5
        
        # 트렌드 점수
        trending_items = {
            'ai', 'ml', 'blockchain', 'iot', 'edge', 'quantum',
            'voice', 'video', 'realtime', 'streaming'
        }
        
        if any(trend in item.lower() for trend in trending_items):
            base_score += 0.3
        
        # 중요도 점수
        if item_type == 'capability':
            if 'security' in item or 'distributed' in item:
                base_score += 0.2
        elif item_type == 'domain':
            if item in ['healthcare', 'security', 'education']:
                base_score += 0.2
        
        return min(base_score, 1.0)
    
    def _assess_impact(self, item: str, item_type: str) -> str:
        """영향도 평가"""
        high_impact = ['security', 'healthcare', 'realtime', 'distributed']
        medium_impact = ['education', 'iot', 'voice', 'blockchain']
        
        item_lower = item.lower()
        
        if any(hi in item_lower for hi in high_impact):
            return 'high'
        elif any(mi in item_lower for mi in medium_impact):
            return 'medium'
        else:
            return 'low'
    
    def generate_recommendations(self) -> List[Dict[str, Any]]:
        """템플릿 추천 생성"""
        recommendations = []
        prioritized_gaps = self.prioritize_gaps()
        
        for gap in prioritized_gaps[:5]:  # 상위 5개 갭
            template_spec = self._create_template_specification(gap)
            recommendations.append(template_spec)
        
        return recommendations
    
    def _create_template_specification(self, gap: Dict[str, Any]) -> Dict[str, Any]:
        """템플릿 사양 생성"""
        spec = {
            'template_id': f"{gap['name'].replace(' ', '_').lower()}_agent",
            'name': f"{gap['name'].title()} Agent",
            'category': gap['type'],
            'priority': int(gap['score'] * 10),
            'impact': gap['impact'],
            'description': self._generate_description(gap),
            'suggested_capabilities': self._suggest_capabilities(gap),
            'suggested_keywords': self._suggest_keywords(gap)
        }
        
        return spec
    
    def _generate_description(self, gap: Dict[str, Any]) -> str:
        """설명 생성"""
        descriptions = {
            'voice_recognition': "음성 인식 및 처리를 위한 AI 에이전트",
            'blockchain_integration': "블록체인 네트워크와 상호작용하는 에이전트",
            'iot_communication': "IoT 디바이스와 통신하는 스마트 에이전트",
            'healthcare': "의료 데이터 분석 및 진단 지원 에이전트",
            'education': "교육 콘텐츠 생성 및 학습 지원 에이전트",
            'security': "보안 취약점 스캔 및 위협 탐지 에이전트"
        }
        
        return descriptions.get(gap['name'], f"{gap['name']} 전문 AI 에이전트")
    
    def _suggest_capabilities(self, gap: Dict[str, Any]) -> List[str]:
        """기능 제안"""
        capability_map = {
            'voice_recognition': ['speech_recognition', 'audio_processing', 'nlp'],
            'blockchain_integration': ['web3', 'smart_contract', 'crypto'],
            'iot_communication': ['mqtt', 'coap', 'device_management'],
            'healthcare': ['medical_nlp', 'diagnosis_support', 'data_privacy'],
            'education': ['content_generation', 'adaptive_learning', 'assessment']
        }
        
        return capability_map.get(gap['name'], ['data_processing', 'api_integration'])
    
    def _suggest_keywords(self, gap: Dict[str, Any]) -> List[str]:
        """키워드 제안"""
        keyword_map = {
            'voice_recognition': ['음성', 'voice', 'speech', 'audio', 'STT', 'TTS'],
            'blockchain_integration': ['블록체인', 'blockchain', 'crypto', 'smart contract'],
            'iot_communication': ['IoT', '사물인터넷', 'sensor', 'device', 'MQTT'],
            'healthcare': ['의료', 'health', 'medical', '진단', 'diagnosis'],
            'education': ['교육', 'education', '학습', 'learning', 'teaching']
        }
        
        return keyword_map.get(gap['name'], [gap['name']])


def analyze_template_coverage():
    """템플릿 커버리지 분석 실행"""
    # 메타데이터 로드
    metadata_file = Path(__file__).parent.parent / 'templates' / 'template_metadata_full.json'
    
    if metadata_file.exists():
        with open(metadata_file, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
    else:
        logger.warning("Metadata file not found, using empty metadata")
        metadata = {}
    
    # 갭 분석
    analyzer = TemplateGapAnalyzer(metadata)
    gaps = analyzer.analyze_gaps()
    
    print("\n📊 Template Gap Analysis Report")
    print("="*50)
    
    print(f"\n🔍 Identified Gaps:")
    for gap_type, items in gaps.items():
        if items:
            print(f"\n  {gap_type.replace('_', ' ').title()}:")
            for item in items[:5]:  # 상위 5개만
                print(f"    - {item}")
    
    # 우선순위
    prioritized = analyzer.prioritize_gaps()
    print(f"\n⭐ Top Priority Gaps:")
    for i, gap in enumerate(prioritized[:5], 1):
        print(f"  {i}. {gap['name']} ({gap['type']})")
        print(f"     Score: {gap['score']:.2f}, Impact: {gap['impact']}")
    
    # 추천
    recommendations = analyzer.generate_recommendations()
    print(f"\n💡 Recommended New Templates:")
    for rec in recommendations:
        print(f"\n  📦 {rec['name']}")
        print(f"     Category: {rec['category']}")
        print(f"     Priority: {rec['priority']}/10")
        print(f"     Impact: {rec['impact']}")
        print(f"     Description: {rec['description']}")
    
    return analyzer, recommendations


if __name__ == "__main__":
    analyzer, recommendations = analyze_template_coverage()