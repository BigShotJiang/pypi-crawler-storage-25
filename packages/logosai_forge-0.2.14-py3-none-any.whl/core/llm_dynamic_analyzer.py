"""
LLM 기반 동적 쿼리 분석 시스템
====================================
하드코딩된 규칙을 완전히 대체하는 지능형 분석 엔진

Version: 3.2
Author: FORGE AI Team  
Date: 2025-08-26
"""

import os
import json
import re
import asyncio
import hashlib
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict
from loguru import logger

# LogosAI LLM Client import
try:
    from logosai.utils import LLMClient
except ImportError:
    logger.warning("LogosAI not available - using mock LLM")
    LLMClient = None


class LLMDynamicAnalyzer:
    """
    LLM 기반 완전 동적 쿼리 분석 시스템
    
    Features:
    - 하드코딩 제로: 모든 분석이 LLM 기반
    - 실시간 패턴 학습: 성공/실패 패턴 자동 축적
    - 컨텍스트 기반 의도 추론: 부정문, 복합문 처리
    - 신규 도메인 자동 적응: 트렌드 반영
    """
    
    def __init__(self, cache_dir: str = None):
        """초기화"""
        self.cache_dir = cache_dir or "/tmp/forge_llm_cache"
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # LLM 클라이언트 초기화
        if LLMClient:
            self.llm_client = LLMClient(
                provider="google",
                model="gemini-2.5-flash-lite",
                temperature=0.1  # 일관성 우선
            )
        else:
            self.llm_client = None
            logger.warning("LLM client not available - using fallback")
        
        # 분석 캐시 시스템
        self.analysis_cache = self._load_cache()
        self.cache_hits = 0
        self.cache_misses = 0
        
        # 성능 추적
        self.analysis_history = []
        self.success_patterns = defaultdict(list)
        self.domain_patterns = defaultdict(int)
        
        # 프롬프트 템플릿
        self.prompts = self._initialize_prompts()
        
        logger.info("🧠 LLMDynamicAnalyzer v3.2 initialized")
        logger.info(f"   Cache directory: {self.cache_dir}")
        logger.info(f"   LLM client: {'✅ Available' if self.llm_client else '❌ Mock mode'}")
    
    def _initialize_prompts(self) -> Dict[str, str]:
        """프롬프트 템플릿 초기화"""
        return {
            'intent_analysis': '''
사용자 쿼리의 진짜 의도를 정확히 파악해주세요.

쿼리: "{query}"

다음 JSON 형식으로만 응답해주세요:
{{
    "primary_intent": "create|analyze|monitor|automate|integrate|optimize|process|learn",
    "secondary_intents": ["보조 의도들"],
    "confidence_score": 0.95,
    "context_clues": ["의도 판단 근거"],
    "intent_reasoning": "이렇게 판단한 이유",
    "complexity_level": "low|medium|high|expert",
    "action_type": "single|multi_step|continuous|conditional"
}}

중요한 분석 기준:
1. 단순 키워드가 아닌 전체 문맥으로 판단
2. 부정문 처리: "하지 않는", "제외한" 등 고려
3. 복합 의도: "분석하고 보고서 생성" = analyze + create
4. 조건문: "만약 ~라면" 등의 조건부 로직
5. 한국어 뉘앙스와 문화적 컨텍스트 반영
''',
            
            'domain_detection': '''
쿼리에서 주요 도메인과 세부 분야를 식별해주세요.

쿼리: "{query}"

JSON 형식으로만 응답:
{{
    "primary_domain": "구체적 도메인명",
    "sub_domains": ["세부분야1", "세부분야2"],  
    "emerging_domain": "새로운 도메인이면 여기에",
    "domain_confidence": 0.85,
    "key_indicators": ["도메인 식별 키워드들"],
    "related_domains": ["연관 도메인들"],
    "industry_context": "산업/비즈니스 맥락",
    "trend_keywords": ["최신 트렌드 키워드들"]
}}

도메인 감지 기준:
1. 전통적 도메인: finance, healthcare, education, technology, retail 등
2. 융합 도메인: fintech, healthtech, edtech, martech 등  
3. 신규 도메인: web3, metaverse, sustainability, creator economy 등
4. 한국 특화: K-pop, 배달, 전자상거래, 게임 등
5. 산업 트렌드 반영: ESG, 디지털 전환, 원격근무 등
''',
            
            'capability_extraction': '''
쿼리에서 필요한 AI 에이전트 기능들을 정확히 추출해주세요.

쿼리: "{query}"
도메인 컨텍스트: "{domain_context}"

JSON 형식으로만 응답:
{{
    "core_capabilities": ["반드시 필요한 핵심 기능들"],
    "optional_capabilities": ["있으면 좋은 추가 기능들"],
    "technical_requirements": ["기술적 요구사항"],
    "performance_requirements": ["성능 요구사항"],
    "integration_needs": ["외부 연동 필요사항"],
    "data_requirements": ["필요한 데이터 유형"],
    "agentic_features": {{
        "autonomous_reasoning": true/false,
        "continuous_learning": true/false,  
        "memory_management": true/false,
        "planning_capability": true/false,
        "reflection_ability": true/false,
        "multi_agent_coordination": true/false
    }},
    "real_time_needs": true/false,
    "scalability_needs": "low|medium|high",
    "security_requirements": ["보안 요구사항들"]
}}

분석 기준:
1. 명시적 요구사항: 직접 언급된 기능들
2. 암시적 요구사항: 도메인/용도에서 추론되는 기능들  
3. 기술적 제약사항: 성능, 보안, 확장성 등
4. 도메인별 필수 요구사항 자동 추가
   - healthcare: 개인정보보호, 규제준수
   - finance: 실시간처리, 보안, 정확성
   - education: 다국어지원, 접근성
5. 최신 기술 트렌드 반영: AI/ML, 클라우드, API 등
''',
            
            'quality_assessment': '''
분석 결과의 품질을 평가해주세요.

원본 쿼리: "{query}"
분석 결과: {analysis_result}

JSON 형식으로만 응답:
{{
    "overall_quality": 0.85,
    "intent_accuracy": 0.90,
    "domain_precision": 0.80,
    "capability_completeness": 0.85,
    "analysis_confidence": 0.88,
    "potential_issues": ["잠재적 문제점들"],
    "improvement_suggestions": ["개선 제안사항들"],
    "missing_elements": ["놓친 요소들"]
}}
'''
        }
    
    def _load_cache(self) -> Dict:
        """분석 캐시 로드"""
        cache_file = os.path.join(self.cache_dir, "analysis_cache.json")
        try:
            if os.path.exists(cache_file):
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                    # 24시간 이상 된 캐시 정리
                    current_time = datetime.now()
                    cleaned_cache = {}
                    for key, entry in cache_data.items():
                        cache_time = datetime.fromisoformat(entry.get('timestamp', '2000-01-01'))
                        if current_time - cache_time < timedelta(hours=24):
                            cleaned_cache[key] = entry
                    logger.info(f"📚 Analysis cache loaded: {len(cleaned_cache)} entries")
                    return cleaned_cache
        except Exception as e:
            logger.warning(f"Cache loading failed: {e}")
        return {}
    
    def _save_cache(self):
        """분석 캐시 저장"""
        cache_file = os.path.join(self.cache_dir, "analysis_cache.json")
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.analysis_cache, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Cache saving failed: {e}")
    
    def _generate_cache_key(self, query: str, analysis_type: str = "full") -> str:
        """캐시 키 생성"""
        normalized_query = re.sub(r'\s+', ' ', query.lower().strip())
        key_data = f"{analysis_type}:{normalized_query}"
        return hashlib.md5(key_data.encode()).hexdigest()[:16]
    
    def _calculate_similarity(self, query1: str, query2: str) -> float:
        """쿼리 유사도 계산 (간단한 토큰 기반)"""
        tokens1 = set(re.findall(r'\w+', query1.lower()))
        tokens2 = set(re.findall(r'\w+', query2.lower()))
        
        if not tokens1 or not tokens2:
            return 0.0
        
        intersection = len(tokens1 & tokens2)
        union = len(tokens1 | tokens2)
        
        return intersection / union if union > 0 else 0.0
    
    def _find_similar_cache(self, query: str, threshold: float = 0.85) -> Optional[Dict]:
        """유사한 캐시 엔트리 찾기"""
        for cache_key, cache_entry in self.analysis_cache.items():
            cached_query = cache_entry.get('original_query', '')
            similarity = self._calculate_similarity(query, cached_query)
            
            if similarity >= threshold:
                cache_entry['similarity_score'] = similarity
                cache_entry['hit_count'] = cache_entry.get('hit_count', 0) + 1
                logger.debug(f"🎯 Cache hit: {similarity:.3f} similarity")
                return cache_entry
        
        return None
    
    async def _call_llm_with_retry(self, prompt: str, max_retries: int = 2) -> Optional[str]:
        """LLM 호출 with 재시도"""
        if not self.llm_client:
            logger.warning("LLM client not available - using fallback")
            return self._generate_fallback_response(prompt)
        
        for attempt in range(max_retries + 1):
            try:
                response = await self.llm_client.invoke(prompt)
                
                # LLMResponse 객체에서 텍스트 추출
                if hasattr(response, 'content'):
                    response_text = response.content
                else:
                    response_text = str(response)
                
                # JSON 추출 시도
                json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
                if json_match:
                    json_str = json_match.group()
                    # JSON 유효성 검증
                    json.loads(json_str)  # 파싱 테스트
                    return json_str
                else:
                    logger.warning(f"No JSON found in LLM response (attempt {attempt + 1})")
                    
            except Exception as e:
                logger.warning(f"LLM call failed (attempt {attempt + 1}): {e}")
                if attempt < max_retries:
                    await asyncio.sleep(0.5 * (attempt + 1))  # 지수적 백오프
        
        logger.error("All LLM retry attempts failed")
        return None
    
    def _generate_fallback_response(self, prompt: str) -> str:
        """LLM 실패 시 폴백 응답 생성"""
        if "intent" in prompt.lower():
            return json.dumps({
                "primary_intent": "create",
                "secondary_intents": [],
                "confidence_score": 0.5,
                "context_clues": ["fallback mode"],
                "intent_reasoning": "LLM unavailable - using fallback",
                "complexity_level": "medium",
                "action_type": "single"
            })
        elif "domain" in prompt.lower():
            return json.dumps({
                "primary_domain": "general",
                "sub_domains": [],
                "emerging_domain": "",
                "domain_confidence": 0.5,
                "key_indicators": [],
                "related_domains": [],
                "industry_context": "general purpose",
                "trend_keywords": []
            })
        elif "capability" in prompt.lower():
            return json.dumps({
                "core_capabilities": ["basic_processing"],
                "optional_capabilities": [],
                "technical_requirements": [],
                "performance_requirements": [],
                "integration_needs": [],
                "data_requirements": ["text_input"],
                "agentic_features": {
                    "autonomous_reasoning": False,
                    "continuous_learning": False,
                    "memory_management": False,
                    "planning_capability": False,
                    "reflection_ability": False,
                    "multi_agent_coordination": False
                },
                "real_time_needs": False,
                "scalability_needs": "low",
                "security_requirements": []
            })
        
        return "{}"
    
    async def analyze_intent(self, query: str) -> Dict[str, Any]:
        """의도 분석 엔진"""
        cache_key = self._generate_cache_key(query, "intent")
        
        # 캐시 확인
        cached = self._find_similar_cache(query)
        if cached and 'intent_analysis' in cached:
            self.cache_hits += 1
            return cached['intent_analysis']
        
        # LLM 분석
        prompt = self.prompts['intent_analysis'].format(query=query)
        response = await self._call_llm_with_retry(prompt)
        
        if response:
            try:
                result = json.loads(response)
                # 캐시 저장
                self.analysis_cache[cache_key] = {
                    'original_query': query,
                    'timestamp': datetime.now().isoformat(),
                    'intent_analysis': result,
                    'hit_count': 1
                }
                self.cache_misses += 1
                return result
            except json.JSONDecodeError as e:
                logger.error(f"Intent analysis JSON parse error: {e}")
        
        # 폴백
        return {
            "primary_intent": "create",
            "confidence_score": 0.3,
            "intent_reasoning": "Analysis failed - using fallback"
        }
    
    async def detect_domain(self, query: str) -> Dict[str, Any]:
        """도메인 감지 엔진"""
        cache_key = self._generate_cache_key(query, "domain")
        
        # 캐시 확인  
        cached = self._find_similar_cache(query)
        if cached and 'domain_analysis' in cached:
            self.cache_hits += 1
            return cached['domain_analysis']
        
        # LLM 분석
        prompt = self.prompts['domain_detection'].format(query=query)
        response = await self._call_llm_with_retry(prompt)
        
        if response:
            try:
                result = json.loads(response)
                # 도메인 패턴 학습
                domain = result.get('primary_domain', 'general')
                self.domain_patterns[domain] += 1
                
                # 캐시 저장
                cache_entry = self.analysis_cache.get(cache_key, {})
                cache_entry.update({
                    'original_query': query,
                    'timestamp': datetime.now().isoformat(),
                    'domain_analysis': result,
                    'hit_count': cache_entry.get('hit_count', 0) + 1
                })
                self.analysis_cache[cache_key] = cache_entry
                self.cache_misses += 1
                return result
            except json.JSONDecodeError as e:
                logger.error(f"Domain analysis JSON parse error: {e}")
        
        # 폴백
        return {
            "primary_domain": "general",
            "domain_confidence": 0.3,
            "key_indicators": []
        }
    
    async def extract_capabilities(self, query: str, domain_context: str = "") -> Dict[str, Any]:
        """기능 추출 엔진"""
        cache_key = self._generate_cache_key(f"{query}:{domain_context}", "capability")
        
        # 캐시 확인
        cached = self._find_similar_cache(query)
        if cached and 'capability_analysis' in cached:
            self.cache_hits += 1
            return cached['capability_analysis']
        
        # LLM 분석
        prompt = self.prompts['capability_extraction'].format(
            query=query,
            domain_context=domain_context
        )
        response = await self._call_llm_with_retry(prompt)
        
        if response:
            try:
                result = json.loads(response)
                # 캐시 저장
                cache_entry = self.analysis_cache.get(cache_key, {})
                cache_entry.update({
                    'original_query': query,
                    'timestamp': datetime.now().isoformat(),
                    'capability_analysis': result,
                    'hit_count': cache_entry.get('hit_count', 0) + 1
                })
                self.analysis_cache[cache_key] = cache_entry
                self.cache_misses += 1
                return result
            except json.JSONDecodeError as e:
                logger.error(f"Capability analysis JSON parse error: {e}")
        
        # 폴백
        return {
            "core_capabilities": ["basic_processing"],
            "agentic_features": {
                "autonomous_reasoning": False,
                "continuous_learning": False,
                "memory_management": False,
                "planning_capability": False,
                "reflection_ability": False
            },
            "real_time_needs": False
        }
    
    async def comprehensive_analyze(self, query: str) -> Dict[str, Any]:
        """통합 분석 엔진"""
        start_time = datetime.now()
        
        logger.info(f"🧠 Starting comprehensive analysis for: {query[:50]}...")
        
        # 병렬 분석 실행
        intent_task = asyncio.create_task(self.analyze_intent(query))
        domain_task = asyncio.create_task(self.detect_domain(query))
        
        # Intent와 Domain 완료 대기
        intent_result = await intent_task
        domain_result = await domain_task
        
        # Domain context로 Capability 분석
        domain_context = f"Domain: {domain_result.get('primary_domain', 'general')}"
        capability_result = await self.extract_capabilities(query, domain_context)
        
        # 통합 결과 생성
        comprehensive_result = {
            'query': query,
            'analysis_timestamp': start_time.isoformat(),
            
            # Intent 분석 결과
            'intent': intent_result.get('primary_intent', 'create'),
            'secondary_intents': intent_result.get('secondary_intents', []),
            'complexity': intent_result.get('complexity_level', 'medium'),
            'action_type': intent_result.get('action_type', 'single'),
            'intent_confidence': intent_result.get('confidence_score', 0.5),
            
            # Domain 분석 결과  
            'domain': domain_result.get('primary_domain', 'general'),
            'sub_domains': domain_result.get('sub_domains', []),
            'emerging_domain': domain_result.get('emerging_domain', ''),
            'domain_confidence': domain_result.get('domain_confidence', 0.5),
            'industry_context': domain_result.get('industry_context', ''),
            
            # Capability 분석 결과
            'required_capabilities': capability_result.get('core_capabilities', []),
            'optional_capabilities': capability_result.get('optional_capabilities', []),
            'technical_requirements': capability_result.get('technical_requirements', []),
            'integration_needs': capability_result.get('integration_needs', []),
            
            # Agentic AI 기능
            'needs_agentic': any(capability_result.get('agentic_features', {}).values()),
            'agentic_features': capability_result.get('agentic_features', {}),
            
            # 기타 요구사항
            'real_time_needs': capability_result.get('real_time_needs', False),
            'scalability_needs': capability_result.get('scalability_needs', 'low'),
            'security_requirements': capability_result.get('security_requirements', []),
            
            # 메타데이터
            'analysis_duration': (datetime.now() - start_time).total_seconds(),
            'llm_model': 'gemini-2.5-flash-lite',
            'cache_hit': self.cache_hits > 0,
            
            # 원본 분석 결과 (디버깅용)
            '_raw_intent': intent_result,
            '_raw_domain': domain_result,
            '_raw_capability': capability_result
        }
        
        # 분석 히스토리 저장
        self.analysis_history.append(comprehensive_result)
        
        # 캐시 저장 (주기적)
        if len(self.analysis_history) % 10 == 0:
            self._save_cache()
        
        analysis_time = comprehensive_result['analysis_duration']
        logger.info(f"✅ Analysis completed in {analysis_time:.2f}s")
        logger.info(f"   Intent: {comprehensive_result['intent']} ({comprehensive_result['intent_confidence']:.2f})")
        logger.info(f"   Domain: {comprehensive_result['domain']} ({comprehensive_result['domain_confidence']:.2f})")
        logger.info(f"   Agentic: {comprehensive_result['needs_agentic']}")
        
        return comprehensive_result
    
    def get_statistics(self) -> Dict[str, Any]:
        """분석 통계 반환"""
        total_analyses = len(self.analysis_history)
        total_cache_requests = self.cache_hits + self.cache_misses
        
        return {
            'total_analyses': total_analyses,
            'cache_performance': {
                'hits': self.cache_hits,
                'misses': self.cache_misses,
                'hit_rate': self.cache_hits / max(total_cache_requests, 1),
                'cache_size': len(self.analysis_cache)
            },
            'domain_distribution': dict(self.domain_patterns),
            'avg_analysis_time': (
                sum(a.get('analysis_duration', 0) for a in self.analysis_history) /
                max(total_analyses, 1)
            ),
            'recent_analyses': self.analysis_history[-5:] if self.analysis_history else []
        }
    
    def clear_cache(self):
        """캐시 초기화"""
        self.analysis_cache.clear()
        self.cache_hits = 0
        self.cache_misses = 0
        logger.info("🗑️ Analysis cache cleared")


# 테스트 함수
async def test_llm_dynamic_analyzer():
    """LLM Dynamic Analyzer 테스트"""
    analyzer = LLMDynamicAnalyzer()
    
    test_queries = [
        "지능형 자율 에이전트를 만들어줘. 스스로 학습하고 개선할 수 있어야 해.",
        "실시간 주식 가격 모니터링하고 이상 패턴 감지하는 시스템",
        "고객 리뷰를 분석해서 감정과 키워드를 추출하는 에이전트",  
        "블록체인 NFT 거래 데이터를 수집하고 트렌드 분석",
        "메타버스 환경에서 사용자 행동 패턴을 학습하는 AI"
    ]
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n{'='*60}")
        print(f"Test {i}: {query}")
        print('='*60)
        
        result = await analyzer.comprehensive_analyze(query)
        
        print(f"🎯 Intent: {result['intent']} ({result['intent_confidence']:.2f})")
        print(f"🏢 Domain: {result['domain']} ({result['domain_confidence']:.2f})")
        print(f"⚙️ Capabilities: {', '.join(result['required_capabilities'][:3])}")
        print(f"🤖 Agentic: {result['needs_agentic']}")
        print(f"⏱️ Analysis time: {result['analysis_duration']:.2f}s")
    
    # 통계 출력
    stats = analyzer.get_statistics()
    print(f"\n{'='*60}")
    print("📊 Analysis Statistics")
    print('='*60)
    print(f"Total analyses: {stats['total_analyses']}")
    print(f"Cache hit rate: {stats['cache_performance']['hit_rate']:.1%}")
    print(f"Avg analysis time: {stats['avg_analysis_time']:.2f}s")
    print(f"Domain distribution: {stats['domain_distribution']}")


if __name__ == "__main__":
    asyncio.run(test_llm_dynamic_analyzer())