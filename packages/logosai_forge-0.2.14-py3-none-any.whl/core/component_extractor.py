"""
Component Extractor for FORGE AI
Extracts reusable components from generated code
"""

import ast
import hashlib
import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import re

@dataclass
class CodeComponent:
    """Represents a reusable code component"""
    id: str
    name: str
    type: str  # 'function', 'class', 'pattern', 'utility'
    code_snippet: str
    description: str
    category: str
    tags: List[str]
    dependencies: List[str]
    signature: str  # For deduplication
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'type': self.type,
            'code_snippet': self.code_snippet,
            'description': self.description,
            'category': self.category,
            'tags': json.dumps(self.tags),
            'dependencies': json.dumps(self.dependencies),
            'signature': self.signature
        }


class ComponentExtractor:
    """Extracts reusable components from code"""
    
    # 추천: 함수와 클래스 단위로 추출
    EXTRACTION_UNITS = {
        'function': {
            'min_lines': 5,  # 5줄 이상의 함수만 추출
            'max_lines': 100,  # 너무 큰 함수는 제외
            'exclude_patterns': ['__init__', 'setup', 'teardown']
        },
        'class': {
            'min_methods': 2,  # 메서드가 2개 이상인 클래스만
            'max_lines': 500,
            'exclude_patterns': ['Test', 'Mock', 'Stub']
        },
        'pattern': {
            'patterns': [
                'retry_with_backoff',
                'rate_limiter',
                'circuit_breaker',
                'singleton',
                'factory'
            ]
        }
    }
    
    def extract_components(self, code: str, agent_category: str = 'general') -> List[CodeComponent]:
        """Extract reusable components from code"""
        components = []
        
        try:
            tree = ast.parse(code)
            
            # Extract functions
            components.extend(self._extract_functions(tree, code, agent_category))
            
            # Extract classes
            components.extend(self._extract_classes(tree, code, agent_category))
            
            # Extract patterns
            components.extend(self._extract_patterns(code, agent_category))
            
        except SyntaxError as e:
            print(f"Syntax error in code: {e}")
            
        return components
    
    def _extract_functions(self, tree: ast.AST, source: str, category: str) -> List[CodeComponent]:
        """Extract function components"""
        components = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Check if function meets criteria
                if node.name in self.EXTRACTION_UNITS['function']['exclude_patterns']:
                    continue
                    
                func_lines = ast.get_source_segment(source, node)
                if not func_lines:
                    continue
                    
                line_count = func_lines.count('\n') + 1
                if (line_count < self.EXTRACTION_UNITS['function']['min_lines'] or
                    line_count > self.EXTRACTION_UNITS['function']['max_lines']):
                    continue
                
                # Extract function info
                dependencies = self._extract_dependencies(node)
                tags = self._generate_tags(node.name, func_lines)
                
                component = CodeComponent(
                    id=self._generate_id(node.name, func_lines),
                    name=node.name,
                    type='function',
                    code_snippet=func_lines,
                    description=ast.get_docstring(node) or f"Function: {node.name}",
                    category=category,
                    tags=tags,
                    dependencies=dependencies,
                    signature=self._generate_signature(func_lines)
                )
                
                components.append(component)
                
        return components
    
    def _extract_classes(self, tree: ast.AST, source: str, category: str) -> List[CodeComponent]:
        """Extract class components"""
        components = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Check if class meets criteria
                if any(pattern in node.name for pattern in self.EXTRACTION_UNITS['class']['exclude_patterns']):
                    continue
                
                # Count methods
                method_count = sum(1 for n in node.body if isinstance(n, ast.FunctionDef))
                if method_count < self.EXTRACTION_UNITS['class']['min_methods']:
                    continue
                
                class_lines = ast.get_source_segment(source, node)
                if not class_lines:
                    continue
                
                dependencies = self._extract_dependencies(node)
                tags = self._generate_tags(node.name, class_lines)
                
                component = CodeComponent(
                    id=self._generate_id(node.name, class_lines),
                    name=node.name,
                    type='class',
                    code_snippet=class_lines,
                    description=ast.get_docstring(node) or f"Class: {node.name}",
                    category=category,
                    tags=tags,
                    dependencies=dependencies,
                    signature=self._generate_signature(class_lines)
                )
                
                components.append(component)
                
        return components
    
    def _extract_patterns(self, code: str, category: str) -> List[CodeComponent]:
        """Extract common patterns"""
        components = []
        
        for pattern_name in self.EXTRACTION_UNITS['pattern']['patterns']:
            if pattern_name in code.lower():
                # Simple pattern matching for now
                pattern_regex = rf'(def|class)\s+.*{pattern_name}.*?(?=\n(?:def|class)|\Z)'
                matches = re.findall(pattern_regex, code, re.IGNORECASE | re.DOTALL)
                
                for match in matches:
                    component = CodeComponent(
                        id=self._generate_id(pattern_name, match),
                        name=f"{pattern_name}_pattern",
                        type='pattern',
                        code_snippet=match,
                        description=f"Implementation of {pattern_name} pattern",
                        category=category,
                        tags=[pattern_name, 'pattern', 'utility'],
                        dependencies=[],
                        signature=self._generate_signature(match)
                    )
                    components.append(component)
                    
        return components
    
    def _extract_dependencies(self, node: ast.AST) -> List[str]:
        """Extract import dependencies from AST node"""
        dependencies = set()
        
        for child in ast.walk(node):
            if isinstance(child, ast.Import):
                for alias in child.names:
                    dependencies.add(alias.name)
            elif isinstance(child, ast.ImportFrom):
                module = child.module or ''
                for alias in child.names:
                    dependencies.add(f"{module}.{alias.name}")
                    
        return list(dependencies)
    
    def _generate_tags(self, name: str, code: str) -> List[str]:
        """Generate tags based on code content"""
        tags = []
        
        # Add tags based on common keywords
        tag_keywords = {
            'async': ['async', 'asynchronous'],
            'api': ['request', 'response', 'endpoint'],
            'database': ['query', 'insert', 'update', 'delete'],
            'file': ['open', 'read', 'write', 'path'],
            'validation': ['validate', 'check', 'verify'],
            'transformation': ['transform', 'convert', 'parse']
        }
        
        code_lower = code.lower()
        for tag, keywords in tag_keywords.items():
            if any(keyword in code_lower for keyword in keywords):
                tags.append(tag)
                
        # Add name-based tags
        tags.extend(name.lower().split('_'))
        
        return list(set(tags))
    
    def _generate_id(self, name: str, code: str) -> str:
        """Generate unique ID for component"""
        content = f"{name}:{code}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def _generate_signature(self, code: str) -> str:
        """Generate signature for deduplication"""
        # Remove whitespace and comments for consistent signature
        cleaned = re.sub(r'#.*$', '', code, flags=re.MULTILINE)
        cleaned = re.sub(r'\s+', ' ', cleaned).strip()
        return hashlib.sha256(cleaned.encode()).hexdigest()


# Example usage
if __name__ == "__main__":
    sample_code = '''
import asyncio
from typing import Dict, Any

async def fetch_data_with_retry(url: str, max_retries: int = 3) -> Dict[str, Any]:
    """Fetch data from URL with exponential backoff retry"""
    for attempt in range(max_retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    return await response.json()
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            await asyncio.sleep(2 ** attempt)
    
class DataProcessor:
    """Process and transform data"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        
    def validate_data(self, data: Dict[str, Any]) -> bool:
        """Validate data against schema"""
        required_fields = self.config.get('required_fields', [])
        return all(field in data for field in required_fields)
        
    def transform_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform data according to rules"""
        # Transform logic here
        return data
'''
    
    extractor = ComponentExtractor()
    components = extractor.extract_components(sample_code, 'data_processing')
    
    for comp in components:
        print(f"\nFound {comp.type}: {comp.name}")
        print(f"Tags: {comp.tags}")
        print(f"Description: {comp.description}")