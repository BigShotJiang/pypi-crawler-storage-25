"""
강력한 System Prompt와 Self-Correction 시스템
Powerful system prompt and self-correction approach
"""

class PowerfulPromptSystem:
    """제대로 된 프롬프트로 Gemini 2.5 Flash 활용"""
    
    def get_system_prompt(self) -> str:
        """강력하고 명확한 System Prompt"""
        return """You are an expert Python developer. Generate SYNTACTICALLY PERFECT Python code.

CRITICAL RULES - FOLLOW EXACTLY:

1. STRINGS - ALWAYS use quotes:
   ✅ CORRECT: self.name = "CalculatorAgent"  
   ❌ WRONG: self.name = CalculatorAgent

2. F-STRINGS - Quote MUST come after f:
   ✅ CORRECT: f"Processing query: {query}"
   ❌ WRONG: f Processing query: {query}

3. DICTIONARY KEYS - MUST be strings with quotes:
   ✅ CORRECT: {"success": True, "data": result}
   ❌ WRONG: {success: True, data: result}

4. INDENTATION - Method body uses 8 spaces:
   ✅ CORRECT:
        try:            # 8 spaces
            result = 1  # 12 spaces
   ❌ WRONG: try:  # Less than 8 spaces

5. OPERATORS IN STRINGS - Must be quoted:
   ✅ CORRECT: if "add" in query or "+" in query:
   ❌ WRONG: if add in query or + in query:

GENERATE SIMPLE, WORKING CODE. NO SYNTAX ERRORS."""

    def get_generation_prompt(self, intent: str) -> str:
        """코드 생성 프롬프트"""
        return f"""Generate Python method body for: {intent}

EXACT FORMAT TO FOLLOW:
        # 8 spaces before each line
        try:
            # Your logic here
            result = "your result"  # STRINGS NEED QUOTES!
            return {{"success": True, "data": result}}  # DICTIONARY KEYS NEED QUOTES!
        except Exception as e:
            return {{"success": False, "error": str(e)}}

CRITICAL REMINDERS:
- ALL strings must have quotes: "string"
- Dictionary keys are strings: {{"key": value}}
- F-strings: f"text {{variable}}"
- Start EVERY line with 8 spaces

Generate SIMPLE, WORKING code for: {intent}"""

    def get_correction_prompt(self, broken_code: str, error: str) -> str:
        """코드 수정 프롬프트"""
        return f"""Fix this Python code that has an error.

BROKEN CODE:
```python
{broken_code}
```

ERROR:
{error}

Generate the CORRECTED version:
1. Fix all syntax errors
2. Ensure proper indentation (8 spaces per line)
3. Fix any string formatting issues
4. Make sure all brackets and quotes are closed
5. Return only the fixed code, no explanations

FIXED CODE:"""

    def fix_code_with_llm(self, llm_manager, broken_code: str, error_msg: str) -> str:
        """
        LLM을 사용해서 코드 자동 수정
        
        Args:
            llm_manager: LLM 매니저
            broken_code: 문제가 있는 코드
            error_msg: 에러 메시지
            
        Returns:
            수정된 코드
        """
        import asyncio
        
        correction_prompt = self.get_correction_prompt(broken_code, error_msg)
        system_prompt = self.get_system_prompt()
        
        # LLM에게 수정 요청
        async def correct():
            response = await llm_manager.generate(
                correction_prompt,
                temperature=0.1,  # 매우 낮은 temperature로 일관성 확보
                system_prompt=system_prompt
            )
            return response.content if response.success else broken_code
        
        # 동기적으로 실행
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # 이미 실행 중인 loop에서
                task = asyncio.create_task(correct())
                return asyncio.run_until_complete(task)
            else:
                # 새 loop에서
                return asyncio.run(correct())
        except:
            return broken_code
            
    def clean_and_validate(self, code: str) -> tuple[bool, str, str]:
        """
        코드 정리 및 검증
        
        Returns:
            (성공여부, 정리된 코드, 에러 메시지)
        """
        # 1. 기본 정리
        lines = code.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # 빈 줄은 그대로
            if not line.strip():
                cleaned_lines.append(line)
                continue
                
            # 코드 줄은 최소 8칸 들여쓰기 확인
            if line.strip() and not line.startswith('        '):
                # 들여쓰기 수정
                stripped = line.lstrip()
                cleaned_lines.append('        ' + stripped)
            else:
                cleaned_lines.append(line)
        
        cleaned_code = '\n'.join(cleaned_lines)
        
        # 2. 문법 검증
        try:
            compile(cleaned_code, '<string>', 'exec')
            return True, cleaned_code, ""
        except SyntaxError as e:
            return False, cleaned_code, f"{e.msg} at line {e.lineno}"