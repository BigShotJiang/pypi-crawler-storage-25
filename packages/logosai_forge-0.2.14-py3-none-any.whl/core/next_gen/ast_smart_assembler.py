"""
AST-based Smart Code Assembler for FORGE AI
===========================================
Revolutionary approach to solve indentation issues permanently
Uses AST manipulation instead of text substitution
"""

import ast
import re
import json
import textwrap
import logging
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ASTNode:
    """Represents an AST node with metadata"""
    node: ast.AST
    node_type: str
    indent_level: int
    source: str  # 'template', 'generated', 'merged'
    

class ASTSmartAssembler:
    """
    Smart code assembler using AST manipulation
    Solves indentation issues permanently
    """
    
    def __init__(self):
        """Initialize AST assembler"""
        self.template_ast = None
        self.business_logic_ast = None
        self.final_ast = None
        
    def assemble(self, 
                 template_code: str,
                 business_logic: str,
                 agent_metadata: Dict[str, Any]) -> str:
        """
        Main assembly method
        
        Args:
            template_code: Template code or None for auto-generation
            business_logic: Generated business logic
            agent_metadata: Agent metadata (name, type, etc.)
            
        Returns:
            Assembled Python code
        """
        try:
            logger.info("🔧 Starting AST-based code assembly")
            
            # Check if business logic is already a complete class
            if 'class ' in business_logic and 'def execute(' in business_logic:
                logger.info("Business logic is already a complete class, using it directly")
                # Validate and return the complete class
                if self._validate_code(business_logic):
                    logger.info("✅ Complete class validates successfully")
                    return business_logic
                else:
                    # Try to fix it
                    logger.info("⚠️ Complete class has issues, attempting to fix")
                    fixed_code = self._self_heal_code(business_logic)
                    if fixed_code and self._validate_code(fixed_code):
                        logger.info("✅ Fixed class validates successfully")
                        return fixed_code
                    # If fixing fails, continue with regular assembly
                    logger.warning("Could not fix complete class, falling back to template assembly")
            
            # Step 1: Parse or generate template
            if template_code:
                # Replace template placeholders with actual values before parsing
                template_code = self._replace_template_placeholders(template_code, agent_metadata)
                self.template_ast = self._parse_template(template_code)
            else:
                self.template_ast = self._generate_template_ast(agent_metadata)
                
            # Step 2: Parse business logic
            self.business_logic_ast = self._parse_business_logic(business_logic)
            
            # Step 3: Merge ASTs intelligently
            self.final_ast = self._merge_asts(
                self.template_ast,
                self.business_logic_ast,
                agent_metadata
            )
            
            # Step 4: Generate final code
            final_code = self._generate_code(self.final_ast)
            
            # Step 5: Validate
            if self._validate_code(final_code):
                logger.info("✅ AST assembly successful")
                return final_code
            else:
                logger.warning("⚠️ Validation failed, attempting self-healing")
                return self._self_heal_code(final_code)
                
        except Exception as e:
            logger.error(f"❌ AST assembly failed: {e}")
            return self._fallback_generation(agent_metadata, business_logic)
            
    def _replace_template_placeholders(self, template_code: str, metadata: Dict[str, Any]) -> str:
        """
        Replace template placeholders with actual values
        
        Args:
            template_code: Template code with placeholders
            metadata: Agent metadata dictionary
            
        Returns:
            Template code with placeholders replaced
        """
        # Map metadata keys to template placeholder names
        placeholder_map = {
            'agent_class_name': metadata.get('class_name', 'CustomAgent'),
            'agent_name': metadata.get('name', 'Custom Agent'),
            'agent_description': metadata.get('description', 'A custom AI agent'),
            'agent_type': metadata.get('agent_type', 'CUSTOM'),
            'custom_config': {},  # Empty dict for now
            'memory_context': '',  # Empty for now
        }
        
        # Replace placeholders in template
        import re
        result = template_code
        
        for placeholder, value in placeholder_map.items():
            # Pattern to match {{placeholder}} (double braces)
            pattern = r'\{\{' + re.escape(placeholder) + r'\}\}'
            
            # Handle different value types
            if isinstance(value, str):
                # For Python strings in code, don't add extra quotes since they're in the template
                # Just escape internal quotes and special characters
                escaped_value = value.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
                result = re.sub(pattern, escaped_value, result)
            elif isinstance(value, dict):
                # Convert dict to string representation
                result = re.sub(pattern, str(value), result)
            else:
                result = re.sub(pattern, str(value), result)
        
        # Log the replacement for debugging
        logger.debug(f"Replaced placeholders: {list(placeholder_map.keys())}")
        
        return result
    
    def _parse_template(self, template_code: str) -> ast.Module:
        """
        Parse template code into AST
        
        Args:
            template_code: Template Python code (with placeholders already replaced)
            
        Returns:
            AST Module
        """
        try:
            # Template should already have placeholders replaced
            tree = ast.parse(template_code)
            return tree
        except SyntaxError as e:
            logger.error(f"Template parsing failed: {e}")
            # Log the problematic lines for debugging
            lines = template_code.split('\n')
            if hasattr(e, 'lineno') and e.lineno:
                start = max(0, e.lineno - 3)
                end = min(len(lines), e.lineno + 2)
                logger.error("Context around error:")
                for i in range(start, end):
                    marker = " >>> " if i == e.lineno - 1 else "     "
                    logger.error(f"{marker}{i+1:4}: {lines[i]}")
            raise
            
    def _generate_template_ast(self, metadata: Dict[str, Any]) -> ast.Module:
        """
        Generate template AST from scratch
        
        Args:
            metadata: Agent metadata
            
        Returns:
            AST Module
        """
        logger.info("🏗️ Generating template AST from scratch")
        
        # Create imports
        imports = self._create_imports()
        
        # Create class definition
        class_def = self._create_class(metadata)
        
        # Create main block
        main_block = self._create_main()
        
        # Combine into module
        module = ast.Module(
            body=imports + [class_def] + main_block,
            type_ignores=[]
        )
        
        ast.fix_missing_locations(module)
        return module
        
    def _parse_business_logic(self, logic_code: str) -> List[ast.stmt]:
        """
        Parse business logic into AST statements
        
        Args:
            logic_code: Business logic Python code
            
        Returns:
            List of AST statements
        """
        # Clean the code first
        logic_code = self._clean_logic_code(logic_code)
        
        # Try to parse as complete code
        try:
            tree = ast.parse(logic_code)
            return tree.body
        except SyntaxError:
            # Try to parse as indented block
            try:
                # Wrap in a function to parse
                wrapped = f"async def _temp():\n{textwrap.indent(logic_code, '    ')}"
                tree = ast.parse(wrapped)
                # Extract the function body
                func_def = tree.body[0]
                return func_def.body
            except SyntaxError as e:
                logger.warning(f"Failed to parse business logic: {e}")
                # Return as string expression (fallback)
                return [ast.Expr(value=ast.Constant(value=logic_code))]
                
    def _clean_logic_code(self, code: str) -> str:
        """
        Clean business logic code
        
        Args:
            code: Raw code
            
        Returns:
            Cleaned code
        """
        # Remove markdown code blocks
        if '```' in code:
            lines = code.split('\n')
            cleaned = []
            in_block = False
            
            for line in lines:
                if line.strip().startswith('```'):
                    in_block = not in_block
                    continue
                if not line.strip().startswith('```'):
                    cleaned.append(line)
                    
            code = '\n'.join(cleaned)
            
        # Normalize indentation
        lines = code.split('\n')
        if lines:
            # Find minimum indentation
            min_indent = float('inf')
            for line in lines:
                if line.strip():
                    indent = len(line) - len(line.lstrip())
                    min_indent = min(min_indent, indent)
                    
            if min_indent != float('inf') and min_indent > 0:
                # Remove minimum indentation
                lines = [line[min_indent:] if len(line) > min_indent else line 
                        for line in lines]
                code = '\n'.join(lines)
                
        return code
        
    def _merge_asts(self, 
                   template_ast: ast.Module,
                   logic_stmts: List[ast.stmt],
                   metadata: Dict[str, Any]) -> ast.Module:
        """
        Merge template and business logic ASTs
        
        Args:
            template_ast: Template AST
            logic_stmts: Business logic statements
            metadata: Agent metadata
            
        Returns:
            Merged AST Module
        """
        logger.info("🔀 Merging template and business logic ASTs")
        
        # Deep copy template to avoid modifying original
        import copy
        merged_ast = copy.deepcopy(template_ast)
        
        # Find the class definition
        class_def = None
        for node in merged_ast.body:
            if isinstance(node, ast.ClassDef):
                class_def = node
                break
                
        if not class_def:
            raise ValueError("No class definition found in template")
            
        # Find or create process method
        process_method = None
        for item in class_def.body:
            if isinstance(item, ast.AsyncFunctionDef) and item.name == 'process':
                process_method = item
                break
                
        if not process_method:
            # Create process method
            process_method = self._create_process_method()
            class_def.body.append(process_method)
            
        # Find insertion point for business logic
        insertion_point = self._find_insertion_point(process_method)
        
        # Insert business logic
        if insertion_point is not None:
            # Replace placeholder or insert at position
            process_method.body[insertion_point:insertion_point+1] = logic_stmts
        else:
            # Append to method body
            process_method.body.extend(logic_stmts)
            
        # Fix missing locations
        ast.fix_missing_locations(merged_ast)
        
        return merged_ast
        
    def _find_insertion_point(self, method: ast.AsyncFunctionDef) -> Optional[int]:
        """
        Find where to insert business logic in method
        
        Args:
            method: Method AST node
            
        Returns:
            Index for insertion or None
        """
        for i, stmt in enumerate(method.body):
            # Look for placeholder comment or pass statement
            if isinstance(stmt, ast.Expr):
                if isinstance(stmt.value, ast.Constant):
                    value = stmt.value.value
                    if isinstance(value, str) and 'PLACEHOLDER' in value:
                        return i
            elif isinstance(stmt, ast.Pass):
                return i
                
        # Look for try block
        for i, stmt in enumerate(method.body):
            if isinstance(stmt, ast.Try):
                # Insert at beginning of try block
                return i + 1
                
        # Default: insert before return statement if exists
        for i in range(len(method.body) - 1, -1, -1):
            if isinstance(method.body[i], ast.Return):
                return i
                
        return None
        
    def _generate_code(self, tree: ast.Module) -> str:
        """
        Generate Python code from AST
        
        Args:
            tree: AST Module
            
        Returns:
            Python code string
        """
        try:
            # Python 3.9+ has ast.unparse
            code = ast.unparse(tree)
        except AttributeError:
            # Fallback for older versions
            try:
                import astor
                code = astor.to_source(tree)
            except ImportError:
                # Manual generation as last resort
                code = self._manual_code_generation(tree)
                
        # Post-process the code
        code = self._post_process_code(code)
        
        return code
        
    def _post_process_code(self, code: str) -> str:
        """
        Post-process generated code
        
        Args:
            code: Generated code
            
        Returns:
            Post-processed code
        """
        # Fix common issues
        lines = code.split('\n')
        processed = []
        
        for line in lines:
            # Remove duplicate blank lines
            if not line.strip() and processed and not processed[-1].strip():
                continue
                
            # Fix string formatting
            line = line.replace("'PLACEHOLDER_", "").replace("'", "")
            
            processed.append(line)
            
        return '\n'.join(processed)
        
    def _validate_code(self, code: str) -> bool:
        """
        Validate generated code
        
        Args:
            code: Python code
            
        Returns:
            True if valid
        """
        try:
            compile(code, '<string>', 'exec')
            return True
        except SyntaxError as e:
            logger.error(f"Validation failed: {e}")
            return False
            
    def _self_heal_code(self, code: str) -> str:
        """
        Attempt to self-heal invalid code
        
        Args:
            code: Invalid code
            
        Returns:
            Healed code
        """
        logger.info("🔧 Attempting self-healing")
        
        # Common fixes
        fixes = [
            # Fix unclosed strings
            (r'(["\'])([^"\']*?)$', r'\1\2\1'),
            # Fix unclosed brackets
            (r'\([^)]*$', lambda m: m.group() + ')'),
            (r'\[[^\]]*$', lambda m: m.group() + ']'),
            (r'\{[^}]*$', lambda m: m.group() + '}'),
            # Fix indentation
            (r'^( *)([^ ])', self._fix_indentation),
        ]
        
        healed = code
        for pattern, replacement in fixes:
            if callable(replacement):
                healed = re.sub(pattern, replacement, healed, flags=re.MULTILINE)
            else:
                healed = re.sub(pattern, replacement, healed, flags=re.MULTILINE)
                
        # Validate again
        if self._validate_code(healed):
            logger.info("✅ Self-healing successful")
            return healed
        else:
            logger.warning("⚠️ Self-healing failed")
            return code
            
    def _fix_indentation(self, match) -> str:
        """Fix indentation in match"""
        spaces = match.group(1)
        char = match.group(2)
        # Ensure multiple of 4 spaces
        indent_level = len(spaces) // 4
        return '    ' * indent_level + char
        
    def _create_imports(self) -> List[ast.stmt]:
        """Create import statements"""
        imports = []
        
        # Standard imports
        imports.append(ast.Import(names=[ast.alias(name='asyncio', asname=None)]))
        imports.append(ast.Import(names=[ast.alias(name='json', asname=None)]))
        imports.append(ast.Import(names=[ast.alias(name='logging', asname=None)]))
        
        # Type imports
        imports.append(ast.ImportFrom(
            module='typing',
            names=[
                ast.alias(name='Dict', asname=None),
                ast.alias(name='Any', asname=None),
                ast.alias(name='Optional', asname=None),
                ast.alias(name='List', asname=None)
            ],
            level=0
        ))
        
        # LogosAI imports
        imports.append(ast.ImportFrom(
            module='logosai.agents.base',
            names=[ast.alias(name='LogosAIAgent', asname=None)],
            level=0
        ))
        imports.append(ast.ImportFrom(
            module='logosai.agent_types',
            names=[
                ast.alias(name='AgentType', asname=None),
                ast.alias(name='AgentResponse', asname=None),
                ast.alias(name='AgentResponseType', asname=None)
            ],
            level=0
        ))
        imports.append(ast.ImportFrom(
            module='logosai.config',
            names=[ast.alias(name='AgentConfig', asname=None)],
            level=0
        ))
        
        return imports
        
    def _create_class(self, metadata: Dict[str, Any]) -> ast.ClassDef:
        """Create class definition"""
        class_name = metadata.get('class_name', 'CustomAgent')
        
        # Create __init__ method
        init_method = self._create_init_method(metadata)
        
        # Create process method
        process_method = self._create_process_method()
        
        # Create class
        class_def = ast.ClassDef(
            name=class_name,
            bases=[ast.Name(id='LogosAIAgent', ctx=ast.Load())],
            keywords=[],
            body=[init_method, process_method],
            decorator_list=[]
        )
        
        return class_def
        
    def _create_init_method(self, metadata: Dict[str, Any]) -> ast.FunctionDef:
        """Create __init__ method"""
        # Method signature
        args = ast.arguments(
            posonlyargs=[],
            args=[
                ast.arg(arg='self', annotation=None),
                ast.arg(arg='config', annotation=None)
            ],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[ast.Constant(value=None)]
        )
        
        # Method body
        body = [
            # config = config or AgentConfig(...)
            ast.Assign(
                targets=[ast.Name(id='config', ctx=ast.Store())],
                value=ast.BoolOp(
                    op=ast.Or(),
                    values=[
                        ast.Name(id='config', ctx=ast.Load()),
                        ast.Call(
                            func=ast.Name(id='AgentConfig', ctx=ast.Load()),
                            args=[],
                            keywords=[
                                ast.keyword(arg='name', value=ast.Constant(value=metadata.get('name', 'Custom Agent'))),
                                ast.keyword(arg='agent_type', value=ast.Attribute(
                                    value=ast.Name(id='AgentType', ctx=ast.Load()),
                                    attr='CUSTOM',
                                    ctx=ast.Load()
                                )),
                                ast.keyword(arg='description', value=ast.Constant(value=metadata.get('description', 'Auto-generated agent'))),
                                ast.keyword(arg='version', value=ast.Constant(value='1.0.0'))
                            ]
                        )
                    ]
                )
            ),
            # super().__init__(config)
            ast.Expr(
                value=ast.Call(
                    func=ast.Call(
                        func=ast.Name(id='super', ctx=ast.Load()),
                        args=[],
                        keywords=[]
                    ),
                    args=[ast.Name(id='config', ctx=ast.Load())],
                    keywords=[]
                )
            ),
            # logger setup
            ast.Assign(
                targets=[ast.Attribute(
                    value=ast.Name(id='self', ctx=ast.Load()),
                    attr='logger',
                    ctx=ast.Store()
                )],
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(id='logging', ctx=ast.Load()),
                        attr='getLogger',
                        ctx=ast.Load()
                    ),
                    args=[ast.Name(id='__name__', ctx=ast.Load())],
                    keywords=[]
                )
            )
        ]
        
        return ast.FunctionDef(
            name='__init__',
            args=args,
            body=body,
            decorator_list=[],
            returns=None
        )
        
    def _create_process_method(self) -> ast.AsyncFunctionDef:
        """Create process method"""
        # Method signature
        args = ast.arguments(
            posonlyargs=[],
            args=[
                ast.arg(arg='self', annotation=None),
                ast.arg(arg='query', annotation=ast.Name(id='str', ctx=ast.Load())),
                ast.arg(arg='context', annotation=Optional[Dict[str, Any]])
            ],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[ast.Constant(value=None)]
        )
        
        # Method body with try-except
        body = [
            ast.Try(
                body=[
                    # Placeholder for business logic
                    ast.Pass()
                ],
                handlers=[
                    ast.ExceptHandler(
                        type=ast.Name(id='Exception', ctx=ast.Load()),
                        name='e',
                        body=[
                            ast.Expr(
                                value=ast.Call(
                                    func=ast.Attribute(
                                        value=ast.Attribute(
                                            value=ast.Name(id='self', ctx=ast.Load()),
                                            attr='logger',
                                            ctx=ast.Load()
                                        ),
                                        attr='error',
                                        ctx=ast.Load()
                                    ),
                                    args=[ast.JoinedStr(
                                        values=[
                                            ast.Constant(value='Error in process: '),
                                            ast.FormattedValue(
                                                value=ast.Name(id='e', ctx=ast.Load()),
                                                conversion=-1,
                                                format_spec=None
                                            )
                                        ]
                                    )],
                                    keywords=[]
                                )
                            ),
                            ast.Return(
                                value=ast.Call(
                                    func=ast.Name(id='AgentResponse', ctx=ast.Load()),
                                    args=[],
                                    keywords=[
                                        ast.keyword(arg='type', value=ast.Attribute(
                                            value=ast.Name(id='AgentResponseType', ctx=ast.Load()),
                                            attr='ERROR',
                                            ctx=ast.Load()
                                        )),
                                        ast.keyword(arg='content', value=ast.Dict(
                                            keys=[ast.Constant(value='error')],
                                            values=[ast.Call(
                                                func=ast.Name(id='str', ctx=ast.Load()),
                                                args=[ast.Name(id='e', ctx=ast.Load())],
                                                keywords=[]
                                            )]
                                        ))
                                    ]
                                )
                            )
                        ]
                    )
                ],
                orelse=[],
                finalbody=[]
            )
        ]
        
        return ast.AsyncFunctionDef(
            name='process',
            args=args,
            body=body,
            decorator_list=[],
            returns=ast.Name(id='AgentResponse', ctx=ast.Load())
        )
        
    def _create_main(self) -> List[ast.stmt]:
        """Create main block"""
        return [
            ast.If(
                test=ast.Compare(
                    left=ast.Name(id='__name__', ctx=ast.Load()),
                    ops=[ast.Eq()],
                    comparators=[ast.Constant(value='__main__')]
                ),
                body=[
                    ast.Expr(
                        value=ast.Call(
                            func=ast.Attribute(
                                value=ast.Name(id='asyncio', ctx=ast.Load()),
                                attr='run',
                                ctx=ast.Load()
                            ),
                            args=[ast.Call(
                                func=ast.Name(id='main', ctx=ast.Load()),
                                args=[],
                                keywords=[]
                            )],
                            keywords=[]
                        )
                    )
                ],
                orelse=[]
            )
        ]
        
    def _fallback_generation(self, metadata: Dict[str, Any], business_logic: str) -> str:
        """
        Fallback code generation when AST fails
        Now uses smart LLM integration
        
        Args:
            metadata: Agent metadata
            business_logic: Business logic code
            
        Returns:
            Generated code
        """
        logger.warning("⚠️ Using fallback generation with smart integration")
        
        # Try smart LLM integration first
        try:
            import asyncio
            from forge.core.next_gen.smart_integration import smart_integrate
            
            # Run async smart integration
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If already in async context, create task
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        smart_integrate(
                            agent_name=metadata.get('name', 'Custom Agent'),
                            agent_type=metadata.get('agent_type', 'CUSTOM'),
                            description=metadata.get('description', 'Auto-generated agent'),
                            business_logic=business_logic,
                            complexity=metadata.get('complexity', 'medium'),
                            domain=metadata.get('domain', 'general')
                        )
                    )
                    integrated_code = future.result(timeout=30)
            else:
                # Run directly
                integrated_code = asyncio.run(
                    smart_integrate(
                        agent_name=metadata.get('name', 'Custom Agent'),
                        agent_type=metadata.get('agent_type', 'CUSTOM'),
                        description=metadata.get('description', 'Auto-generated agent'),
                        business_logic=business_logic,
                        complexity=metadata.get('complexity', 'medium'),
                        domain=metadata.get('domain', 'general')
                    )
                )
            
            if integrated_code and self._validate_code(integrated_code):
                logger.info("✅ Smart LLM integration successful")
                return integrated_code
            else:
                logger.warning("Smart integration validation failed, using simple fallback")
                
        except Exception as e:
            logger.warning(f"Smart integration failed: {e}, using simple fallback")
        
        # Simple fallback if smart integration fails
        template = '''
import asyncio
import json
import logging
from typing import Dict, Any, Optional, List

# LogosAI Framework - simplified imports
from logosai.agent import LogosAIAgent
from logosai.config import AgentConfig
from logosai.agent_types import AgentType, AgentResponse, AgentResponseType

logger = logging.getLogger(__name__)

class {class_name}(LogosAIAgent):
    """
    {description}
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        config = config or AgentConfig(
            name="{name}",
            agent_type=AgentType.CUSTOM,
            description="""{description}""",
            version="1.0.0"
        )
        super().__init__(config)
        self.logger = logger
        
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Process user query"""
        try:
            {business_logic}
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={{"result": "Processing completed"}}
            )
            
        except Exception as e:
            self.logger.error(f"Error in process: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}}
            )

if __name__ == "__main__":
    async def main():
        agent = {class_name}()
        result = await agent.process("Test query")
        print(result)
        
    asyncio.run(main())
'''
        
        # Use safe string replacement instead of format() to avoid curly brace conflicts
        # Replace placeholders with safe markers first
        safe_template = template.replace('{class_name}', '<<<CLASS_NAME>>>')
        safe_template = safe_template.replace('{name}', '<<<NAME>>>')
        safe_template = safe_template.replace('{description}', '<<<DESCRIPTION>>>')
        safe_template = safe_template.replace('{business_logic}', '<<<BUSINESS_LOGIC>>>')
        
        # Now do the replacements
        result = safe_template
        result = result.replace('<<<CLASS_NAME>>>', metadata.get('class_name', 'CustomAgent'))
        result = result.replace('<<<NAME>>>', metadata.get('name', 'Custom Agent'))
        result = result.replace('<<<DESCRIPTION>>>', metadata.get('description', 'Auto-generated agent'))
        
        # Clean and indent business logic
        cleaned_logic = self._clean_business_logic(business_logic)
        indented_logic = textwrap.indent(cleaned_logic, '            ')
        result = result.replace('<<<BUSINESS_LOGIC>>>', indented_logic)
        
        return result
    
    def _clean_business_logic(self, logic: str) -> str:
        """
        Clean up generated business logic
        
        Args:
            logic: Raw business logic from LLM
            
        Returns:
            Cleaned business logic
        """
        # Remove excessive indentation
        lines = logic.split('\n')
        if lines:
            # Find minimum indentation
            min_indent = float('inf')
            for line in lines:
                if line.strip():
                    indent = len(line) - len(line.lstrip())
                    min_indent = min(min_indent, indent)
            
            # Remove minimum indentation from all lines
            if min_indent < float('inf') and min_indent > 0:
                cleaned_lines = []
                for line in lines:
                    if line.strip():
                        cleaned_lines.append(line[min_indent:])
                    else:
                        cleaned_lines.append('')
                logic = '\n'.join(cleaned_lines)
        
        # Remove docstring if it exists at the beginning
        if logic.strip().startswith('"""'):
            # Find the closing docstring
            parts = logic.split('"""', 2)
            if len(parts) >= 3:
                logic = parts[2].strip()
        
        # Remove 'try:' at the beginning if present (it's already in template)
        if logic.strip().startswith('try:'):
            lines = logic.strip().split('\n')[1:]  # Skip the 'try:' line
            logic = '\n'.join(lines)
        
        return logic
        
    def _manual_code_generation(self, tree: ast.Module) -> str:
        """
        Manual code generation from AST (last resort)
        
        Args:
            tree: AST Module
            
        Returns:
            Python code
        """
        # This is a simplified manual generation
        # In production, you'd want a more complete implementation
        code_lines = []
        
        for node in tree.body:
            if isinstance(node, ast.Import):
                names = ', '.join(alias.name for alias in node.names)
                code_lines.append(f"import {names}")
            elif isinstance(node, ast.ImportFrom):
                names = ', '.join(alias.name for alias in node.names)
                code_lines.append(f"from {node.module} import {names}")
            elif isinstance(node, ast.ClassDef):
                code_lines.append(f"\nclass {node.name}(LogosAIAgent):")
                code_lines.append('    """Auto-generated agent"""')
                code_lines.append('    pass')
                
        return '\n'.join(code_lines)