"""
Smart Assembler for FORGE AI Next Generation
============================================
Main integration component that orchestrates the entire code generation pipeline
"""

import os
import json
import logging
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path

try:
    from .llm_integration import ForgeLLMManager
    from .intelligent_analyzer import IntelligentAnalyzer, QueryAnalysis
    from .business_logic_generator import BusinessLogicGenerator
    from .template_manager import TemplateManager, Template
    from .ast_smart_assembler import ASTSmartAssembler
except ImportError:
    # Absolute imports for standalone execution
    from forge.core.next_gen.llm_integration import ForgeLLMManager
    from forge.core.next_gen.intelligent_analyzer import IntelligentAnalyzer, QueryAnalysis
    from forge.core.next_gen.business_logic_generator import BusinessLogicGenerator
    from forge.core.next_gen.template_manager import TemplateManager, Template
    from forge.core.next_gen.ast_smart_assembler import ASTSmartAssembler

logger = logging.getLogger(__name__)


@dataclass
class AssemblyResult:
    """Result of code assembly process"""
    success: bool
    code: str
    metadata: Dict[str, Any]
    template_used: Optional[str] = None
    errors: Optional[list] = None
    warnings: Optional[list] = None
    

class SmartAssembler:
    """
    Main orchestrator for the FORGE AI code generation pipeline
    Integrates all components and manages the flow
    """
    
    def __init__(self,
                 llm_provider: str = "google",
                 db_path: str = None):
        """
        Initialize Smart Assembler
        
        Args:
            llm_provider: Primary LLM provider
            db_path: Database path for templates
        """
        logger.info("🚀 Initializing FORGE AI Next Generation Smart Assembler")
        
        # Initialize components
        self.llm_manager = ForgeLLMManager(primary_provider=llm_provider)
        self.analyzer = IntelligentAnalyzer(self.llm_manager)
        self.logic_generator = BusinessLogicGenerator(self.llm_manager)
        self.template_manager = TemplateManager(db_path)
        self.ast_assembler = ASTSmartAssembler()
        
        # Statistics
        self.stats = {
            'total_generations': 0,
            'successful': 0,
            'failed': 0
        }
        
    async def generate_agent(self, 
                           query: str,
                           user_email: str = "default@forge.ai",
                           output_type: str = "standalone") -> AssemblyResult:
        """
        Main entry point for agent generation
        
        Args:
            query: User query describing the agent
            user_email: User email
            output_type: Output type (standalone, logosai)
            
        Returns:
            AssemblyResult with generated code
        """
        logger.info(f"📝 Starting agent generation for query: {query[:100]}...")
        self.stats['total_generations'] += 1
        
        try:
            # Step 1: Analyze query
            logger.info("🔍 Step 1: Analyzing query...")
            analysis = await self.analyzer.analyze(query)
            logger.info(f"   Analysis complete: {analysis.domain.value}/{analysis.complexity.value}")
            
            # Step 2: Design architecture
            logger.info("🏗️ Step 2: Designing architecture...")
            design = await self.llm_manager.design_architecture(
                self.analyzer.export_analysis(analysis)
            )
            logger.info(f"   Architecture designed with {len(design.get('components', []))} components")
            
            # Step 3: Generate business logic
            logger.info("💡 Step 3: Generating business logic...")
            business_logic_result = await self.logic_generator.generate(analysis, design)
            business_logic = business_logic_result['code']
            logger.info(f"   Generated {business_logic_result.get('metadata', {}).get('line_count', 0)} lines of business logic")
            
            # Step 4: Select or generate template
            logger.info("📋 Step 4: Selecting template...")
            template = self.template_manager.select_template(
                analysis.domain,
                analysis.complexity,
                analysis.features
            )
            logger.info(f"   Selected template: {template.name}")
            
            # Step 5: Check if business logic is already a complete valid class
            logger.info("🔧 Step 5: Assembling code...")
            agent_metadata = {
                'class_name': self._generate_class_name(analysis.suggested_name),
                'name': analysis.suggested_name,
                'description': analysis.description,
                'agent_type': self._map_domain_to_type(analysis.domain),
                'domain': analysis.domain.value,
                'complexity': analysis.complexity.value,
                'email': user_email
            }
            
            # Always use the template for consistency
            logger.info("   Using template-based assembly")
            
            # Prepare template variables
            from datetime import datetime
            
            # Extract just the business logic code (without the class wrapper)
            business_logic_core = business_logic
            if 'class ' in business_logic and 'def execute(' in business_logic:
                # Try to extract just the execute method body
                lines = business_logic.split('\n')
                in_execute = False
                execute_lines = []
                indent_level = 0
                
                for line in lines:
                    if 'def execute(' in line or 'def _process_query(' in line:
                        in_execute = True
                        indent_level = len(line) - len(line.lstrip()) + 4  # Add 4 for method body indent
                    elif in_execute and line.strip() and not line.strip().startswith('def '):
                        # Remove the base indentation
                        if len(line) - len(line.lstrip()) >= indent_level:
                            execute_lines.append(line[indent_level:])
                        else:
                            execute_lines.append(line.strip())
                
                if execute_lines:
                    business_logic_core = '\n'.join(execute_lines)
            
            # Generate test queries based on agent type
            test_queries = self._generate_test_queries(analysis.intent, agent_metadata['agent_type'])
            
            # Use smart integration for intelligent code merging
            logger.info("   Using smart integration for intelligent code merging...")
            
            # Debug: Check template content
            if '[BUSINESS_LOGIC_START]' in template.code:
                logger.warning("   ⚠️ Template contains [BUSINESS_LOGIC_START] marker!")
            
            # Import smart integration
            from .smart_integration import smart_integrate
            
            # Prepare context for smart integration
            try:
                final_code = await smart_integrate(
                    agent_name=agent_metadata['name'],
                    agent_type=agent_metadata['agent_type'],
                    description=agent_metadata['description'],
                    business_logic=business_logic_core,
                    complexity=agent_metadata['complexity'],
                    domain=agent_metadata['domain'],
                    template_code=template.code,
                    test_queries=test_queries
                )
                logger.info("   ✅ Smart integration completed successfully")
                
                # Debug: Check if markers still exist
                if '[BUSINESS_LOGIC_START]' in final_code:
                    logger.error("   ❌ Smart integration failed to remove [BUSINESS_LOGIC_START] marker!")
                if '{business_logic}' in final_code:
                    logger.error("   ❌ Smart integration failed to remove {business_logic} placeholder!")
                    
            except Exception as e:
                logger.warning(f"   ⚠️ Smart integration failed: {e}, falling back to simple replacement")
                # Fallback to simple replacement
                template_vars = {
                    'agent_class_name': agent_metadata['class_name'],
                    'agent_name': agent_metadata['name'],
                    'agent_description': agent_metadata['description'],
                    'agent_type': agent_metadata['agent_type'],
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'complexity': agent_metadata['complexity'],
                    'capabilities': 'general',
                    'business_logic': business_logic_core,
                    'test_queries': json.dumps(test_queries, ensure_ascii=False)
                }
                
                final_code = template.code
                for var, value in template_vars.items():
                    placeholder = '{' + var + '}'
                    final_code = final_code.replace(placeholder, str(value))
            
            logger.info("   Code assembly completed")
            
            # Step 6: Validate generated code
            logger.info("✅ Step 6: Validating generated code...")
            validation = await self._validate_code(final_code)
            
            if not validation['is_valid']:
                # Check if these are just warnings (not syntax errors)
                if validation.get('issues'):
                    # Check severity levels
                    severities = [issue.get('severity', 'high').lower() for issue in validation['issues'] if isinstance(issue, dict)]
                    has_critical = any(sev in ['critical', 'high'] for sev in severities)
                    
                    if has_critical:
                        logger.warning(f"   Validation found critical issues: {validation['issues']}")
                        # Only attempt self-healing for syntax errors, not security warnings
                        # Check if the code actually compiles
                        try:
                            compile(final_code, '<string>', 'exec')
                            logger.info("   Code compiles despite warnings, skipping self-healing")
                        except SyntaxError:
                            logger.info("   Code has syntax errors, attempting self-healing")
                            final_code = await self._self_heal_code(final_code, validation['issues'])
                    else:
                        logger.info(f"   Validation found non-critical issues: {validation['issues']}")
                
            # Step 7: Record usage for learning
            logger.info("📊 Step 7: Recording usage for learning...")
            self.template_manager.record_usage(
                template.id,
                query,
                validation['is_valid'],
                error_message=str(validation.get('issues')) if not validation['is_valid'] else None
            )
            
            # Prepare result
            self.stats['successful'] += 1
            logger.info(f"✨ Agent generation completed successfully!")
            
            return AssemblyResult(
                success=True,
                code=final_code,
                metadata={
                    'analysis': asdict(analysis),
                    'design': design,
                    'business_logic_patterns': business_logic_result.get('patterns_used', []),
                    'template_id': template.id,
                    'agent_metadata': agent_metadata,
                    'validation': validation,
                    'timestamp': datetime.now().isoformat()
                },
                template_used=template.name,
                warnings=validation.get('suggestions', [])
            )
            
        except Exception as e:
            logger.error(f"❌ Agent generation failed: {e}")
            self.stats['failed'] += 1
            
            return AssemblyResult(
                success=False,
                code="",
                metadata={'error': str(e)},
                errors=[str(e)]
            )
            
    async def _validate_code(self, code: str) -> Dict[str, Any]:
        """
        Validate generated code
        
        Args:
            code: Generated Python code
            
        Returns:
            Validation result
        """
        # Basic syntax validation
        try:
            compile(code, '<string>', 'exec')
            syntax_valid = True
            syntax_errors = []
        except SyntaxError as e:
            syntax_valid = False
            syntax_errors = [f"Syntax error at line {e.lineno}: {e.msg}"]
            
        # Skip LLM validation for speed (can be re-enabled with a flag)
        # LLM-based validation
        # llm_validation = await self.llm_manager.validate_code(code)
        llm_validation = {'is_valid': True, 'issues': [], 'suggestions': []}
        
        # Combine results
        is_valid = syntax_valid and llm_validation.get('is_valid', True)
        issues = syntax_errors + llm_validation.get('issues', [])
        
        return {
            'is_valid': is_valid,
            'syntax_valid': syntax_valid,
            'issues': issues,
            'suggestions': llm_validation.get('suggestions', []),
            'severity': llm_validation.get('severity', 'low' if is_valid else 'high')
        }
        
    async def _self_heal_code(self, code: str, issues: list) -> str:
        """
        Attempt to self-heal code issues
        
        Args:
            code: Code with issues
            issues: List of issues
            
        Returns:
            Healed code
        """
        logger.info("🔧 Attempting self-healing...")
        
        # Skip self-healing if issues are just warnings (not syntax errors)
        if issues and all(issue.get('severity') in ['low', 'medium'] for issue in issues if isinstance(issue, dict)):
            logger.info("   Issues are only warnings, skipping self-healing")
            return code
            
        # Use AST assembler's self-healing
        healed = self.ast_assembler._self_heal_code(code)
        
        # If still has issues, try LLM-based healing
        validation = await self._validate_code(healed)
        if not validation['is_valid'] and validation.get('issues'):
            prompt = f"""Fix the following Python code issues:

Code:
```python
{code}
```

Issues:
{json.dumps(issues, indent=2)}

Return the corrected code only, no explanations."""

            response = await self.llm_manager.generate(prompt, temperature=0.2)
            if response.success:
                healed = response.content
                # Clean markdown if present
                if '```' in healed:
                    lines = healed.split('\n')
                    healed = '\n'.join([l for l in lines if not l.strip().startswith('```')])
                    
        return healed
        
    def _generate_test_queries(self, intent: str, agent_type: str) -> List[str]:
        """Generate test queries based on agent type and intent"""
        
        # Default test queries by agent type
        test_queries_map = {
            'calculator': ["10 더하기 5", "100 - 25", "7 곱하기 8"],
            'data_analysis': ["데이터 분석해줘", "통계 보여줘", "상관관계 분석"],
            'api_integration': ["API 호출 테스트", "데이터 동기화", "상태 확인"],
            'web_scraping': ["웹사이트 크롤링", "데이터 추출", "페이지 분석"],
            'chatbot': ["안녕하세요", "도움이 필요해요", "질문이 있습니다"],
            'monitoring': ["시스템 상태 확인", "에러 로그 보기", "성능 리포트"],
            'automation': ["작업 자동화", "스케줄 설정", "워크플로우 실행"],
            'document_processing': ["문서 분석", "텍스트 추출", "포맷 변환"]
        }
        
        # Get default queries for the agent type
        default_queries = test_queries_map.get(agent_type, [])
        
        # Add intent-based queries
        if intent:
            intent_lower = intent.lower()
            if "계산" in intent_lower or "calc" in intent_lower or "add" in intent_lower:
                return ["5 더하기 10", "20에서 7 빼기", "3 곱하기 4"]
            elif "분석" in intent_lower or "analysis" in intent_lower:
                return ["데이터 분석", "통계 요약", "트렌드 확인"]
            elif "검색" in intent_lower or "search" in intent_lower:
                return ["정보 검색", "데이터 찾기", "결과 조회"]
        
        # Return default queries or generic ones
        return default_queries if default_queries else ["테스트 쿼리 1", "테스트 쿼리 2", "테스트 쿼리 3"]
    
    def _generate_class_name(self, suggested_name: str) -> str:
        """
        Generate valid Python class name
        
        Args:
            suggested_name: Suggested name
            
        Returns:
            Valid class name
        """
        # Remove special characters and capitalize
        import re
        name = re.sub(r'[^a-zA-Z0-9]', '', suggested_name)
        
        # Ensure starts with letter
        if name and not name[0].isalpha():
            name = 'Agent' + name
            
        # Capitalize first letter of each word
        name = ''.join(word.capitalize() for word in name.split())
        
        # Add 'Agent' suffix if not present
        if not name.endswith('Agent'):
            name += 'Agent'
            
        return name or 'CustomAgent'
        
    def _map_domain_to_type(self, domain) -> str:
        """
        Map domain to agent type
        
        Args:
            domain: AgentDomain enum
            
        Returns:
            Agent type string
        """
        # Map to actual LogosAI AgentType enum values
        mapping = {
            'data_analysis': 'ANALYSIS',      # Maps to AgentType.ANALYSIS
            'api': 'CUSTOM',                   # No specific API type, use CUSTOM
            'nlp': 'CUSTOM',                   # No specific NLP type, use CUSTOM
            'ml': 'CUSTOM',                    # No specific ML type, use CUSTOM
            'web_scraping': 'INTERNET_SEARCH', # Maps to AgentType.INTERNET_SEARCH
            'database': 'CUSTOM',              # No specific DB type, use CUSTOM
            'utility': 'CUSTOM',               # Use CUSTOM for utility
            'integration': 'CUSTOM',           # Use CUSTOM for integration
            'automation': 'CUSTOM',            # Use CUSTOM for automation
            'general': 'GENERAL'               # Maps to AgentType.GENERAL
        }
        
        return mapping.get(domain.value, 'CUSTOM')
        
    def get_statistics(self) -> Dict[str, Any]:
        """Get generation statistics"""
        success_rate = (self.stats['successful'] / self.stats['total_generations'] 
                       if self.stats['total_generations'] > 0 else 0)
        
        return {
            **self.stats,
            'success_rate': success_rate,
            'template_insights': self.template_manager.get_learning_insights()
        }
        
    def save_agent(self, result: AssemblyResult, output_dir: str = None) -> str:
        """
        Save generated agent to file
        
        Args:
            result: Assembly result
            output_dir: Output directory
            
        Returns:
            Path to saved file
        """
        if not result.success:
            raise ValueError("Cannot save failed generation result")
            
        # Default output directory
        if not output_dir:
            output_dir = "/Users/maior/Development/skku/Logos/forge/generated"
            
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate filename
        class_name = result.metadata['agent_metadata']['class_name']
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{class_name}_{timestamp}.py"
        filepath = os.path.join(output_dir, filename)
        
        # Save code
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(result.code)
            
        # Save metadata
        metadata_file = filepath.replace('.py', '_metadata.json')
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(result.metadata, f, indent=2, ensure_ascii=False)
            
        logger.info(f"💾 Agent saved to: {filepath}")
        return filepath
        
    def close(self):
        """Cleanup resources"""
        self.template_manager.close()
        logger.info("Smart Assembler closed")


# Convenience functions
async def generate_agent(query: str, **kwargs) -> AssemblyResult:
    """
    Generate agent from query
    
    Args:
        query: User query
        **kwargs: Additional parameters
        
    Returns:
        AssemblyResult
    """
    assembler = SmartAssembler()
    try:
        result = await assembler.generate_agent(query, **kwargs)
        return result
    finally:
        assembler.close()


async def generate_and_save(query: str, output_dir: str = None, **kwargs) -> str:
    """
    Generate agent and save to file
    
    Args:
        query: User query
        output_dir: Output directory
        **kwargs: Additional parameters
        
    Returns:
        Path to saved file
    """
    assembler = SmartAssembler()
    try:
        result = await assembler.generate_agent(query, **kwargs)
        if result.success:
            return assembler.save_agent(result, output_dir)
        else:
            raise ValueError(f"Generation failed: {result.errors}")
    finally:
        assembler.close()