"""
Code Validator for FORGE AI Next Generation
===========================================
Comprehensive code validation and testing
"""

import ast
import asyncio
import json
import logging
import subprocess
import tempfile
import os
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)


class ValidationLevel(Enum):
    """Validation levels"""
    SYNTAX = "syntax"          # Basic syntax check
    STRUCTURE = "structure"    # Code structure validation
    IMPORTS = "imports"        # Import validation
    LOGIC = "logic"           # Business logic validation
    EXECUTION = "execution"    # Actual execution test
    FULL = "full"             # All validations
    

class IssueSeverity(Enum):
    """Issue severity levels"""
    ERROR = "error"           # Must fix
    WARNING = "warning"       # Should fix
    INFO = "info"            # Nice to fix
    

@dataclass
class ValidationIssue:
    """Validation issue"""
    level: ValidationLevel
    severity: IssueSeverity
    message: str
    line_number: Optional[int] = None
    suggestion: Optional[str] = None
    

@dataclass 
class ValidationResult:
    """Validation result"""
    is_valid: bool
    issues: List[ValidationIssue]
    metadata: Dict[str, Any]
    execution_result: Optional[Dict[str, Any]] = None
    

class Validator:
    """
    Comprehensive code validator
    """
    
    def __init__(self):
        """Initialize validator"""
        self.required_imports = {
            'logosai': ['LogosAIAgent'],
            'logosai.agent_types': ['AgentType', 'AgentResponse', 'AgentResponseType'],
            'logosai.config': ['AgentConfig']
        }
        
    async def validate(self, 
                       code: str,
                       level: ValidationLevel = ValidationLevel.FULL) -> ValidationResult:
        """
        Validate code at specified level
        
        Args:
            code: Python code to validate
            level: Validation level
            
        Returns:
            ValidationResult
        """
        logger.info(f"🔍 Validating code at level: {level.value}")
        
        issues = []
        metadata = {}
        
        # Level-based validation
        if level in [ValidationLevel.SYNTAX, ValidationLevel.FULL]:
            syntax_issues = self._validate_syntax(code)
            issues.extend(syntax_issues)
            metadata['syntax_valid'] = len(syntax_issues) == 0
            
        if level in [ValidationLevel.STRUCTURE, ValidationLevel.FULL]:
            structure_issues = self._validate_structure(code)
            issues.extend(structure_issues)
            metadata['structure_valid'] = len(structure_issues) == 0
            
        if level in [ValidationLevel.IMPORTS, ValidationLevel.FULL]:
            import_issues = self._validate_imports(code)
            issues.extend(import_issues)
            metadata['imports_valid'] = len(import_issues) == 0
            
        if level in [ValidationLevel.LOGIC, ValidationLevel.FULL]:
            logic_issues = await self._validate_logic(code)
            issues.extend(logic_issues)
            metadata['logic_valid'] = len(logic_issues) == 0
            
        execution_result = None
        if level in [ValidationLevel.EXECUTION, ValidationLevel.FULL]:
            execution_result = await self._validate_execution(code)
            if not execution_result['success']:
                issues.append(ValidationIssue(
                    level=ValidationLevel.EXECUTION,
                    severity=IssueSeverity.ERROR,
                    message=f"Execution failed: {execution_result.get('error', 'Unknown error')}"
                ))
            metadata['execution_valid'] = execution_result['success']
            
        # Determine overall validity
        has_errors = any(issue.severity == IssueSeverity.ERROR for issue in issues)
        is_valid = not has_errors
        
        return ValidationResult(
            is_valid=is_valid,
            issues=issues,
            metadata=metadata,
            execution_result=execution_result
        )
        
    def _validate_syntax(self, code: str) -> List[ValidationIssue]:
        """
        Validate Python syntax
        
        Args:
            code: Python code
            
        Returns:
            List of syntax issues
        """
        issues = []
        
        try:
            ast.parse(code)
            logger.info("✅ Syntax validation passed")
        except SyntaxError as e:
            issues.append(ValidationIssue(
                level=ValidationLevel.SYNTAX,
                severity=IssueSeverity.ERROR,
                message=f"Syntax error: {e.msg}",
                line_number=e.lineno,
                suggestion="Check indentation and syntax at the specified line"
            ))
            logger.error(f"❌ Syntax error at line {e.lineno}: {e.msg}")
            
        return issues
        
    def _validate_structure(self, code: str) -> List[ValidationIssue]:
        """
        Validate code structure
        
        Args:
            code: Python code
            
        Returns:
            List of structure issues
        """
        issues = []
        
        try:
            tree = ast.parse(code)
            
            # Check for required class
            has_agent_class = False
            has_process_method = False
            has_init_method = False
            
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    # Check if inherits from LogosAIAgent
                    for base in node.bases:
                        if isinstance(base, ast.Name) and base.id == 'LogosAIAgent':
                            has_agent_class = True
                            
                            # Check for required methods
                            for item in node.body:
                                if isinstance(item, ast.FunctionDef):
                                    if item.name == '__init__':
                                        has_init_method = True
                                elif isinstance(item, ast.AsyncFunctionDef):
                                    if item.name == 'process':
                                        has_process_method = True
                                        
            if not has_agent_class:
                issues.append(ValidationIssue(
                    level=ValidationLevel.STRUCTURE,
                    severity=IssueSeverity.ERROR,
                    message="No class inheriting from LogosAIAgent found",
                    suggestion="Add a class that inherits from LogosAIAgent"
                ))
                
            if has_agent_class and not has_init_method:
                issues.append(ValidationIssue(
                    level=ValidationLevel.STRUCTURE,
                    severity=IssueSeverity.WARNING,
                    message="No __init__ method found",
                    suggestion="Add __init__ method to initialize the agent"
                ))
                
            if has_agent_class and not has_process_method:
                issues.append(ValidationIssue(
                    level=ValidationLevel.STRUCTURE,
                    severity=IssueSeverity.ERROR,
                    message="No async process method found",
                    suggestion="Add async process(self, query, context) method"
                ))
                
            if not issues:
                logger.info("✅ Structure validation passed")
            else:
                logger.warning(f"⚠️ Structure validation found {len(issues)} issues")
                
        except Exception as e:
            issues.append(ValidationIssue(
                level=ValidationLevel.STRUCTURE,
                severity=IssueSeverity.ERROR,
                message=f"Failed to analyze structure: {e}"
            ))
            
        return issues
        
    def _validate_imports(self, code: str) -> List[ValidationIssue]:
        """
        Validate required imports
        
        Args:
            code: Python code
            
        Returns:
            List of import issues
        """
        issues = []
        
        try:
            tree = ast.parse(code)
            
            # Extract imports
            imports = {}
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    module = node.module
                    if module not in imports:
                        imports[module] = []
                    for alias in node.names:
                        imports[module].append(alias.name)
                        
            # Check required imports
            for module, required_names in self.required_imports.items():
                if module not in imports:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.IMPORTS,
                        severity=IssueSeverity.ERROR,
                        message=f"Missing import: from {module} import ...",
                        suggestion=f"Add: from {module} import {', '.join(required_names)}"
                    ))
                else:
                    for name in required_names:
                        if name not in imports[module]:
                            issues.append(ValidationIssue(
                                level=ValidationLevel.IMPORTS,
                                severity=IssueSeverity.WARNING,
                                message=f"Missing import: {name} from {module}",
                                suggestion=f"Add {name} to imports from {module}"
                            ))
                            
            if not issues:
                logger.info("✅ Import validation passed")
            else:
                logger.warning(f"⚠️ Import validation found {len(issues)} issues")
                
        except Exception as e:
            issues.append(ValidationIssue(
                level=ValidationLevel.IMPORTS,
                severity=IssueSeverity.ERROR,
                message=f"Failed to analyze imports: {e}"
            ))
            
        return issues
        
    async def _validate_logic(self, code: str) -> List[ValidationIssue]:
        """
        Validate business logic
        
        Args:
            code: Python code
            
        Returns:
            List of logic issues
        """
        issues = []
        
        try:
            tree = ast.parse(code)
            
            # Check for common logic issues
            for node in ast.walk(tree):
                # Check for empty except blocks
                if isinstance(node, ast.ExceptHandler):
                    if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                        issues.append(ValidationIssue(
                            level=ValidationLevel.LOGIC,
                            severity=IssueSeverity.WARNING,
                            message="Empty except block found",
                            line_number=getattr(node, 'lineno', None),
                            suggestion="Add proper error handling or logging"
                        ))
                        
                # Check for hardcoded credentials
                if isinstance(node, ast.Constant):
                    value = str(node.value).lower()
                    if any(keyword in value for keyword in ['password', 'secret', 'key', 'token']):
                        issues.append(ValidationIssue(
                            level=ValidationLevel.LOGIC,
                            severity=IssueSeverity.WARNING,
                            message="Possible hardcoded credential found",
                            line_number=getattr(node, 'lineno', None),
                            suggestion="Use environment variables or configuration files"
                        ))
                        
            # Check for return statements in process method
            has_return = False
            for node in ast.walk(tree):
                if isinstance(node, ast.AsyncFunctionDef) and node.name == 'process':
                    for stmt in ast.walk(node):
                        if isinstance(stmt, ast.Return):
                            has_return = True
                            # Check if returns AgentResponse
                            if isinstance(stmt.value, ast.Call):
                                if isinstance(stmt.value.func, ast.Name):
                                    if stmt.value.func.id != 'AgentResponse':
                                        issues.append(ValidationIssue(
                                            level=ValidationLevel.LOGIC,
                                            severity=IssueSeverity.WARNING,
                                            message="process method should return AgentResponse",
                                            suggestion="Return AgentResponse object"
                                        ))
                                        
            if not has_return:
                issues.append(ValidationIssue(
                    level=ValidationLevel.LOGIC,
                    severity=IssueSeverity.ERROR,
                    message="process method has no return statement",
                    suggestion="Add return AgentResponse(...) statement"
                ))
                
            if not issues:
                logger.info("✅ Logic validation passed")
            else:
                logger.warning(f"⚠️ Logic validation found {len(issues)} issues")
                
        except Exception as e:
            issues.append(ValidationIssue(
                level=ValidationLevel.LOGIC,
                severity=IssueSeverity.ERROR,
                message=f"Failed to analyze logic: {e}"
            ))
            
        return issues
        
    async def _validate_execution(self, code: str) -> Dict[str, Any]:
        """
        Validate by executing the code
        
        Args:
            code: Python code
            
        Returns:
            Execution result
        """
        logger.info("🚀 Attempting execution validation...")
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_file = f.name
            
        try:
            # Add test execution code
            test_code = f"""
import sys
sys.path.insert(0, '/Users/maior/Development/skku/Logos/logosai')

{code}

# Test execution
import asyncio

async def test():
    # Find agent class
    import inspect
    for name, obj in globals().items():
        if inspect.isclass(obj) and name.endswith('Agent'):
            try:
                agent = obj()
                result = await agent.process("Test query")
                print(f"SUCCESS: {{result.type}}")
                return True
            except Exception as e:
                print(f"ERROR: {{e}}")
                return False
    print("ERROR: No agent class found")
    return False
    
if __name__ == "__main__":
    success = asyncio.run(test())
    sys.exit(0 if success else 1)
"""
            
            # Write test code
            with open(temp_file, 'w') as f:
                f.write(test_code)
                
            # Execute
            result = subprocess.run(
                ['python', temp_file],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            success = result.returncode == 0
            output = result.stdout + result.stderr
            
            if success:
                logger.info("✅ Execution validation passed")
            else:
                logger.error(f"❌ Execution validation failed: {output}")
                
            return {
                'success': success,
                'output': output,
                'return_code': result.returncode
            }
            
        except subprocess.TimeoutExpired:
            logger.error("❌ Execution timeout")
            return {
                'success': False,
                'error': 'Execution timeout (10 seconds)',
                'output': ''
            }
        except Exception as e:
            logger.error(f"❌ Execution error: {e}")
            return {
                'success': False,
                'error': str(e),
                'output': ''
            }
        finally:
            # Clean up
            if os.path.exists(temp_file):
                os.remove(temp_file)
                
    def format_issues(self, issues: List[ValidationIssue]) -> str:
        """
        Format issues for display
        
        Args:
            issues: List of validation issues
            
        Returns:
            Formatted string
        """
        if not issues:
            return "No issues found ✅"
            
        lines = []
        
        # Group by severity
        errors = [i for i in issues if i.severity == IssueSeverity.ERROR]
        warnings = [i for i in issues if i.severity == IssueSeverity.WARNING]
        info = [i for i in issues if i.severity == IssueSeverity.INFO]
        
        if errors:
            lines.append(f"❌ Errors ({len(errors)}):")
            for issue in errors:
                line = f"  - [{issue.level.value}] {issue.message}"
                if issue.line_number:
                    line += f" (line {issue.line_number})"
                if issue.suggestion:
                    line += f"\n    💡 {issue.suggestion}"
                lines.append(line)
                
        if warnings:
            lines.append(f"\n⚠️ Warnings ({len(warnings)}):")
            for issue in warnings:
                line = f"  - [{issue.level.value}] {issue.message}"
                if issue.line_number:
                    line += f" (line {issue.line_number})"
                if issue.suggestion:
                    line += f"\n    💡 {issue.suggestion}"
                lines.append(line)
                
        if info:
            lines.append(f"\nℹ️ Info ({len(info)}):")
            for issue in info:
                line = f"  - [{issue.level.value}] {issue.message}"
                if issue.suggestion:
                    line += f"\n    💡 {issue.suggestion}"
                lines.append(line)
                
        return '\n'.join(lines)