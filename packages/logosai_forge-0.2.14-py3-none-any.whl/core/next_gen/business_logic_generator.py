"""
Business Logic Generator for FORGE AI
======================================
Intelligent business logic generation with pattern learning
"""

import re
import json
import ast
import textwrap
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from .llm_integration import ForgeLLMManager
from .intelligent_analyzer import QueryAnalysis, AgentDomain, ComplexityLevel

logger = logging.getLogger(__name__)


class LogicPattern(Enum):
    """Business logic patterns"""
    DATA_PROCESSING = "data_processing"
    API_CALL = "api_call"
    DATABASE_QUERY = "database_query"
    FILE_OPERATION = "file_operation"
    WEB_SCRAPING = "web_scraping"
    ML_INFERENCE = "ml_inference"
    TEXT_PROCESSING = "text_processing"
    VALIDATION = "validation"
    TRANSFORMATION = "transformation"
    AGGREGATION = "aggregation"


@dataclass
class CodeBlock:
    """Represents a code block"""
    pattern: LogicPattern
    code: str
    imports: List[str]
    dependencies: List[str]
    variables: Dict[str, Any]
    

class BusinessLogicGenerator:
    """
    Generates business logic code based on analysis and patterns
    """
    
    def __init__(self, llm_manager: Optional[ForgeLLMManager] = None):
        """
        Initialize generator
        
        Args:
            llm_manager: LLM manager instance
        """
        self.llm_manager = llm_manager or ForgeLLMManager()
        self._init_patterns()
        self._load_examples()
        
    def _init_patterns(self):
        """Initialize logic patterns"""
        self.patterns = {
            LogicPattern.DATA_PROCESSING: {
                'template': '''
        # Data processing logic
        try:
            {processing_code}
            result = {result_variable}
            logger.info("Data processed successfully")
        except Exception as e:
            logger.error(f"Data processing failed: {{e}}")
            raise
                ''',
                'imports': ['import pandas as pd', 'import numpy as np'],
                'keywords': ['process', 'transform', 'clean', 'filter']
            },
            
            LogicPattern.API_CALL: {
                'template': '''
        # API call logic
        try:
            {api_setup}
            response = await {api_call}
            
            if response.status_code == 200:
                data = response.json()
                {response_processing}
                result = {result_format}
            else:
                raise Exception(f"API call failed: {{response.status_code}}")
                
        except Exception as e:
            logger.error(f"API call error: {{e}}")
            raise
                ''',
                'imports': ['import aiohttp', 'import json'],
                'keywords': ['api', 'request', 'endpoint', 'http']
            },
            
            LogicPattern.DATABASE_QUERY: {
                'template': '''
        # Database query logic
        try:
            {connection_setup}
            query = {query_string}
            {query_execution}
            {result_processing}
            result = {result_format}
            
        except Exception as e:
            logger.error(f"Database query failed: {{e}}")
            raise
                ''',
                'imports': ['import sqlite3', 'import asyncpg'],
                'keywords': ['database', 'query', 'sql', 'select']
            },
            
            LogicPattern.TEXT_PROCESSING: {
                'template': '''
        # Text processing logic
        try:
            {text_input}
            {processing_steps}
            result = {processed_text}
            
        except Exception as e:
            logger.error(f"Text processing failed: {{e}}")
            raise
                ''',
                'imports': ['import re', 'from typing import List'],
                'keywords': ['text', 'nlp', 'parse', 'extract']
            }
        }
        
    def _load_examples(self):
        """Load example agents for learning"""
        self.examples = {}
        examples_path = Path("/Users/maior/Development/skku/Logos/logosai/logosai/examples/agents")
        
        if examples_path.exists():
            for agent_file in examples_path.glob("*.py"):
                try:
                    with open(agent_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                        self.examples[agent_file.stem] = content
                        logger.info(f"Loaded example: {agent_file.stem}")
                except Exception as e:
                    logger.warning(f"Failed to load example {agent_file}: {e}")
                    
    async def generate(self, analysis: QueryAnalysis, design: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate business logic based on analysis and design
        
        Args:
            analysis: Query analysis result
            design: Architecture design
            
        Returns:
            Generated business logic dictionary
        """
        logger.info(f"Generating business logic for: {analysis.suggested_name}")
        
        # Step 1: Identify required patterns
        patterns = self._identify_patterns(analysis, design)
        
        # Step 2: Generate code blocks for each pattern
        code_blocks = await self._generate_code_blocks(patterns, analysis, design)
        
        # Step 3: Combine code blocks intelligently
        combined_logic = await self._combine_code_blocks(code_blocks, analysis)
        
        # Step 4: Normalize and validate
        final_logic = self._normalize_code(combined_logic)
        
        # Step 5: Extract metadata
        metadata = self._extract_metadata(final_logic, code_blocks)
        
        return {
            'code': final_logic,
            'imports': metadata['imports'],
            'dependencies': metadata['dependencies'],
            'patterns_used': [p.value for p in patterns],
            'complexity': analysis.complexity.value,
            'metadata': metadata
        }
        
    def _identify_patterns(self, analysis: QueryAnalysis, design: Dict[str, Any]) -> List[LogicPattern]:
        """
        Identify required logic patterns
        
        Args:
            analysis: Query analysis
            design: Architecture design
            
        Returns:
            List of required patterns
        """
        patterns = []
        
        # Domain-based pattern selection
        domain_patterns = {
            AgentDomain.DATA_ANALYSIS: [LogicPattern.DATA_PROCESSING, LogicPattern.AGGREGATION],
            AgentDomain.API: [LogicPattern.API_CALL, LogicPattern.VALIDATION],
            AgentDomain.DATABASE: [LogicPattern.DATABASE_QUERY, LogicPattern.DATA_PROCESSING],
            AgentDomain.NLP: [LogicPattern.TEXT_PROCESSING, LogicPattern.TRANSFORMATION],
            AgentDomain.WEB_SCRAPING: [LogicPattern.WEB_SCRAPING, LogicPattern.DATA_PROCESSING]
        }
        
        # Add domain-specific patterns
        if analysis.domain in domain_patterns:
            patterns.extend(domain_patterns[analysis.domain])
            
        # Add patterns based on features
        for feature in analysis.features:
            feature_lower = feature.lower()
            for pattern, info in self.patterns.items():
                if any(keyword in feature_lower for keyword in info['keywords']):
                    if pattern not in patterns:
                        patterns.append(pattern)
                        
        # Ensure at least one pattern
        if not patterns:
            patterns.append(LogicPattern.DATA_PROCESSING)
            
        return patterns
        
    async def _generate_code_blocks(self, patterns: List[LogicPattern], 
                                   analysis: QueryAnalysis, 
                                   design: Dict[str, Any]) -> List[CodeBlock]:
        """
        Generate code blocks for each pattern
        
        Args:
            patterns: Required patterns
            analysis: Query analysis
            design: Architecture design
            
        Returns:
            List of code blocks
        """
        code_blocks = []
        
        # Use enhanced prompt system with rich examples
        from .enhanced_prompt_system import EnhancedPromptSystem
        enhanced_system = EnhancedPromptSystem()
        
        # Generate a complete class with enhanced prompts
        agent_name = analysis.suggested_name.replace(" ", "")  # Remove spaces from name
        
        # Use a very explicit prompt with multiple examples of correct syntax
        prompt = f"""Generate ONLY Python code for a class named {agent_name}Logic.

This class should {analysis.intent}.

CRITICAL SYNTAX RULES - MUST FOLLOW:
✅ ALL strings MUST be quoted: "text" or 'text'  
✅ Dictionary keys MUST be quoted: {{"key": "value"}}
✅ String values in dicts MUST be quoted: {{"type": "calculation"}}
✅ Return statements: return {{"success": True, "data": result}}

❌ NEVER write: {{key: value}} or {{"type": calculation}} or return {{success: True}}

```python
class {agent_name}Logic:
    def __init__(self):
        self.name = "{agent_name}"  # String is quoted
        self.description = "{analysis.intent}"  # String is quoted
    
    def execute(self, query: str) -> dict:
        try:
            # Implement actual logic to {analysis.intent}
            # Parse and process the query properly
            result = self._process_query(query)
            
            # Return dict with ALL keys and string values quoted
            return {{"success": True, "data": result, "type": "processed"}}
        except Exception as e:
            # Error dict with quoted keys and string values
            return {{"success": False, "error": str(e)}}
    
    def _process_query(self, query: str):
        # Implement the actual logic here
        # Return properly formatted data
        return {{"result": "value", "status": "complete"}}
```

Generate a COMPLETE implementation with actual logic. ALL strings and dict keys MUST be quoted. Output ONLY Python code:"""
        
        logger.info(f"Using explicit prompt with template")
        
        # Generate with very low temperature for consistency
        response = await self.llm_manager.generate(
            prompt, 
            temperature=0.1
        )
        
        if response.success:
            code = response.content
            
            # Clean markdown formatting if present
            if '```python' in code:
                lines = code.split('\n')
                in_code = False
                clean_lines = []
                
                for line in lines:
                    if line.strip() == '```python':
                        in_code = True
                        continue
                    elif line.strip() == '```':
                        in_code = False
                        continue
                    elif in_code:
                        clean_lines.append(line)
                
                code = '\n'.join(clean_lines)
            
            # Validate and enhance the generated code
            is_valid, enhanced_code, feedback = enhanced_system.validate_and_enhance(code)
            
            if is_valid:
                logger.info(f"✅ Code validation passed! Enhancements: {feedback}")
                
                # Pass the complete class code instead of just execute body
                # The AST assembler will handle merging properly
                code_block = CodeBlock(
                    pattern=LogicPattern.DATA_PROCESSING,  # Default pattern
                    code=enhanced_code,  # Pass complete class
                    imports=self._extract_imports_from_class(enhanced_code),
                    dependencies=self._extract_dependencies(enhanced_code),
                    variables=self._extract_variables(enhanced_code)
                )
                code_blocks.append(code_block)
                
            else:
                logger.warning(f"Code validation failed: {feedback}")
                
                # Try to fix with correction prompt
                correction_prompt = enhanced_system.get_correction_prompt(code, str(feedback))
                correction_response = await self.llm_manager.generate(
                    correction_prompt,
                    temperature=0.1  # Very low for corrections
                )
                
                if correction_response.success:
                    corrected_code = correction_response.content
                    
                    # Clean markdown if needed
                    if '```python' in corrected_code:
                        lines = corrected_code.split('\n')
                        in_code = False
                        clean_lines = []
                        
                        for line in lines:
                            if line.strip() == '```python':
                                in_code = True
                                continue
                            elif line.strip() == '```':
                                in_code = False
                                continue
                            elif in_code:
                                clean_lines.append(line)
                        
                        corrected_code = '\n'.join(clean_lines)
                    
                    # Validate corrected code
                    is_valid2, enhanced_code2, feedback2 = enhanced_system.validate_and_enhance(corrected_code)
                    
                    if is_valid2:
                        logger.info("✅ Corrected code validation passed!")
                        
                        # Pass the complete class code
                        code_block = CodeBlock(
                            pattern=LogicPattern.DATA_PROCESSING,
                            code=enhanced_code2,  # Pass complete class
                            imports=self._extract_imports_from_class(enhanced_code2),
                            dependencies=self._extract_dependencies(enhanced_code2),
                            variables=self._extract_variables(enhanced_code2)
                        )
                        code_blocks.append(code_block)
                else:
                    # Use fallback
                    fallback_code = self._generate_fallback_code(analysis, LogicPattern.DATA_PROCESSING)
                    code_block = CodeBlock(
                        pattern=LogicPattern.DATA_PROCESSING,
                        code=fallback_code,
                        imports=[],
                        dependencies=[],
                        variables={}
                    )
                    code_blocks.append(code_block)
        else:
            logger.warning(f"Failed to generate class")
            # Use fallback
            fallback_code = self._generate_fallback_code(analysis, LogicPattern.DATA_PROCESSING)
            code_block = CodeBlock(
                pattern=LogicPattern.DATA_PROCESSING,
                code=fallback_code,
                imports=[],
                dependencies=[],
                variables={}
            )
            code_blocks.append(code_block)
                
        return code_blocks
    
    def _extract_execute_body(self, class_code: str) -> str:
        """
        Extract the body of the execute method from a class
        
        Args:
            class_code: Complete class code
            
        Returns:
            Just the method body with proper indentation (8 spaces)
        """
        try:
            # Find the execute method
            lines = class_code.split('\n')
            in_execute = False
            body_lines = []
            base_indent = None
            
            for line in lines:
                if 'def execute(' in line:
                    in_execute = True
                    base_indent = len(line) - len(line.lstrip())
                    continue
                elif in_execute:
                    # Check if we've reached the end of the method
                    if line.strip() and base_indent is not None:
                        current_indent = len(line) - len(line.lstrip())
                        if current_indent <= base_indent:
                            # End of method
                            break
                    
                    # Add the line with proper 8-space indentation
                    if line.strip():
                        # Remove original indentation and add 8 spaces
                        body_lines.append('        ' + line.strip())
                    else:
                        body_lines.append('')
            
            if body_lines:
                return '\n'.join(body_lines)
            
        except Exception as e:
            logger.error(f"Failed to extract execute method: {e}")
        
        # Fallback
        return """        try:
            result = f"Processing: {query}"
            return {"success": True, "data": result}
        except Exception as e:
            return {"success": False, "error": str(e)}"""
    
    def _extract_imports_from_class(self, class_code: str) -> List[str]:
        """
        Extract import statements from class code
        
        Args:
            class_code: Complete class code
            
        Returns:
            List of import statements
        """
        imports = []
        lines = class_code.split('\n')
        
        for line in lines:
            if line.strip().startswith('import ') or line.strip().startswith('from '):
                imports.append(line.strip())
        
        return imports
        
    async def _combine_code_blocks(self, code_blocks: List[CodeBlock], 
                                  analysis: QueryAnalysis) -> str:
        """
        Intelligently combine code blocks
        
        Args:
            code_blocks: List of code blocks
            analysis: Query analysis
            
        Returns:
            Combined code string
        """
        if not code_blocks:
            return "pass  # No logic generated"
            
        if len(code_blocks) == 1:
            return code_blocks[0].code
            
        # Use LLM to combine blocks intelligently
        blocks_desc = "\n".join([f"Block {i+1} ({b.pattern.value}):\n{b.code}" 
                                 for i, b in enumerate(code_blocks)])
        
        prompt = f"""Combine these code blocks into a cohesive business logic:

{blocks_desc}

Requirements:
1. Maintain logical flow
2. Avoid duplication
3. Preserve error handling
4. Keep proper indentation (8 spaces base)
5. Return complete working code

Context: {analysis.intent}

Generate the combined code:"""

        response = await self.llm_manager.generate(prompt, temperature=0.3)
        
        if response.success:
            return self._clean_generated_code(response.content)
        else:
            # Fallback: simple concatenation
            return "\n".join([block.code for block in code_blocks])
            
    def _normalize_code(self, code: str) -> str:
        """
        Normalize code indentation and format
        
        Args:
            code: Raw code string
            
        Returns:
            Normalized code
        """
        if not code or code.strip() == "pass":
            return "        pass  # Placeholder logic"
            
        # Split into lines
        lines = code.split('\n')
        
        # Find minimum indentation (excluding empty lines)
        min_indent = float('inf')
        for line in lines:
            if line.strip():
                indent = len(line) - len(line.lstrip())
                min_indent = min(min_indent, indent)
                
        if min_indent == float('inf'):
            min_indent = 0
            
        # Normalize to 8 spaces base indentation
        normalized_lines = []
        base_indent = 8
        
        for line in lines:
            if line.strip():
                current_indent = len(line) - len(line.lstrip())
                relative_indent = current_indent - min_indent
                new_indent = base_indent + relative_indent
                normalized_lines.append(' ' * new_indent + line.lstrip())
            else:
                normalized_lines.append('')
                
        return '\n'.join(normalized_lines)
        
    def _generate_fallback_code(self, analysis: QueryAnalysis, pattern: LogicPattern) -> str:
        """
        Generate simple fallback code when LLM generation fails
        
        Args:
            analysis: Query analysis
            pattern: Logic pattern
            
        Returns:
            Simple but working code
        """
        # Use clean, simple code without complex string escaping
        intent_safe = analysis.intent.replace('"', '\\"')
        
        fallback_code = f'''        # Fallback implementation
        try:
            logger.info(f"Processing query: {{query}}")
            
            # Simple processing logic
            result = {{
                "intent": "{intent_safe}",
                "response": f"Processed: {{query}}",
                "status": "completed"
            }}
            
            return {{
                "success": True,
                "data": result,
                "metadata": {{
                    "agent": self.name,
                    "timestamp": datetime.now().isoformat()
                }}
            }}
            
        except Exception as e:
            logger.error(f"Processing failed: {{str(e)}}")
            return {{"success": False, "error": str(e)}}'''
        
        return fallback_code
    
    def _clean_generated_code(self, code: str) -> str:
        """
        Clean generated code from LLM
        
        Args:
            code: Raw generated code
            
        Returns:
            Cleaned code
        """
        # Remove markdown code blocks
        if '```' in code:
            lines = code.split('\n')
            cleaned_lines = []
            in_code_block = False
            
            for line in lines:
                if line.strip().startswith('```'):
                    in_code_block = not in_code_block
                    continue
                if in_code_block or not line.strip().startswith('```'):
                    cleaned_lines.append(line)
                    
            code = '\n'.join(cleaned_lines)
            
        # Remove leading/trailing whitespace
        code = code.strip()
        
        # Ensure it's valid Python (basic check)
        try:
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            logger.warning(f"Generated code has syntax error: {e}")
            # Try to fix common issues
            code = self._fix_common_syntax_errors(code)
            
        return code
        
    def _fix_common_syntax_errors(self, code: str) -> str:
        """
        Fix common syntax errors in generated code
        
        Args:
            code: Code with potential errors
            
        Returns:
            Fixed code
        """
        # Fix unclosed strings
        code = re.sub(r'(["\'])([^"\']*?)$', r'\1\2\1', code, flags=re.MULTILINE)
        
        # Fix unclosed brackets
        open_parens = code.count('(') - code.count(')')
        if open_parens > 0:
            code += ')' * open_parens
            
        open_brackets = code.count('[') - code.count(']')
        if open_brackets > 0:
            code += ']' * open_brackets
            
        open_braces = code.count('{') - code.count('}')
        if open_braces > 0:
            code += '}' * open_braces
            
        return code
        
    def _extract_dependencies(self, code: str) -> List[str]:
        """
        Extract dependencies from code
        
        Args:
            code: Python code
            
        Returns:
            List of dependencies
        """
        dependencies = []
        
        # Common package patterns
        import_patterns = [
            r'import\s+(\w+)',
            r'from\s+(\w+)',
        ]
        
        for pattern in import_patterns:
            matches = re.findall(pattern, code)
            dependencies.extend(matches)
            
        # Remove duplicates and standard library
        stdlib = {'os', 'sys', 're', 'json', 'logging', 'typing', 'datetime'}
        dependencies = list(set(dependencies) - stdlib)
        
        return dependencies
        
    def _extract_variables(self, code: str) -> Dict[str, Any]:
        """
        Extract variables from code
        
        Args:
            code: Python code
            
        Returns:
            Variables dictionary
        """
        variables = {}
        
        # Try to parse with AST
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            variables[target.id] = 'assigned'
        except:
            # Fallback to regex
            pattern = r'(\w+)\s*='
            matches = re.findall(pattern, code)
            for match in matches:
                variables[match] = 'assigned'
                
        return variables
        
    def _extract_metadata(self, code: str, code_blocks: List[CodeBlock]) -> Dict[str, Any]:
        """
        Extract metadata from generated code
        
        Args:
            code: Final code
            code_blocks: Code blocks used
            
        Returns:
            Metadata dictionary
        """
        all_imports = set()
        all_dependencies = set()
        
        for block in code_blocks:
            all_imports.update(block.imports)
            all_dependencies.update(block.dependencies)
            
        # Add discovered imports from final code
        import_lines = re.findall(r'^import .*$|^from .* import .*$', code, re.MULTILINE)
        all_imports.update(import_lines)
        
        return {
            'imports': list(all_imports),
            'dependencies': list(all_dependencies),
            'line_count': len(code.split('\n')),
            'has_error_handling': 'try' in code and 'except' in code,
            'has_logging': 'logger' in code or 'logging' in code,
            'is_async': 'async' in code or 'await' in code
        }
        
    def validate_logic(self, code: str) -> Tuple[bool, List[str]]:
        """
        Validate generated business logic
        
        Args:
            code: Generated code
            
        Returns:
            Tuple of (is_valid, issues)
        """
        issues = []
        
        # Check syntax
        try:
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            issues.append(f"Syntax error: {e}")
            
        # Check for required elements
        if not code.strip() or code.strip() == 'pass':
            issues.append("No substantial logic generated")
            
        # Check indentation
        lines = code.split('\n')
        for i, line in enumerate(lines):
            if line and not line[0].isspace() and line.strip() != 'pass':
                issues.append(f"Line {i+1}: Improper indentation")
                
        # Check for common issues
        if 'TODO' in code or 'FIXME' in code:
            issues.append("Contains TODO/FIXME markers")
            
        return len(issues) == 0, issues