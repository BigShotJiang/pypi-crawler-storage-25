"""
FORGE AI Next Generation System
================================
차세대 FORGE AI 시스템 - 지능형 에이전트 코드 생성 파이프라인
"""

from .intelligent_analyzer import IntelligentAnalyzer
from .business_logic_generator import BusinessLogicGenerator
from .template_manager import TemplateManager
from .smart_assembler import SmartAssembler

__all__ = [
    'IntelligentAnalyzer',
    'BusinessLogicGenerator', 
    'TemplateManager',
    'SmartAssembler'
]

__version__ = '2.0.0'