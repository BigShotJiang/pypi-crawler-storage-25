"""
Template Manager for FORGE AI Next Generation
=============================================
Simplified template system with learning capability
"""

import os
import json
import sqlite3
import logging
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime
from enum import Enum

from .intelligent_analyzer import AgentDomain, ComplexityLevel

logger = logging.getLogger(__name__)


class TemplateType(Enum):
    """Template types"""
    MINIMAL = "minimal"          # Bare minimum structure
    STANDARD = "standard"        # Standard LogosAI agent
    AGENTIC = "agentic"         # Agentic AI enhanced
    CUSTOM = "custom"           # Custom generated
    

@dataclass
class Template:
    """Template data structure"""
    id: str
    name: str
    type: TemplateType
    domain: AgentDomain
    complexity: ComplexityLevel
    code: str
    variables: List[str]
    success_rate: float = 0.0
    usage_count: int = 0
    created_at: str = ""
    updated_at: str = ""
    

class TemplateManager:
    """
    Manages templates with intelligent selection and generation
    """
    
    def __init__(self, db_path: str = None):
        """
        Initialize template manager
        
        Args:
            db_path: Path to SQLite database
        """
        self.db_path = db_path or "/Users/maior/Development/skku/Logos/forge/data/templates.db"
        self.templates_dir = Path("/Users/maior/Development/skku/Logos/forge/templates")
        self.core_templates = {}
        
        self._init_database()
        self._load_core_templates()
        
    def _init_database(self):
        """Initialize SQLite database"""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        cursor = self.conn.cursor()
        
        # Create templates table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS templates (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                domain TEXT NOT NULL,
                complexity TEXT NOT NULL,
                code TEXT NOT NULL,
                variables TEXT,  -- JSON array
                success_rate REAL DEFAULT 0.0,
                usage_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create learning history table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS template_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                template_id TEXT NOT NULL,
                query TEXT NOT NULL,
                success BOOLEAN,
                error_message TEXT,
                feedback TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (template_id) REFERENCES templates(id)
            )
        ''')
        
        self.conn.commit()
        logger.info("✅ Template database initialized")
        
    def _load_core_templates(self):
        """Load core templates from files and memory"""
        
        # Load the main LogosAI template file
        logosai_template_path = self.templates_dir / "logosai_agent_template.py.template"
        if logosai_template_path.exists():
            with open(logosai_template_path, 'r', encoding='utf-8') as f:
                self.core_templates['standard'] = f.read()
                logger.info(f"✅ Loaded LogosAI template from {logosai_template_path}")
        else:
            # Fallback to embedded standard template
            self.core_templates['standard'] = '''
import asyncio
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from logosai.agents.base import LogosAIAgent
from logosai.agents.base import AgentType, AgentResponse, AgentResponseType
from logosai.agents.base import AgentConfig
from logosai.utils.llm_client import LLMClient

logger = logging.getLogger(__name__)

class {class_name}(LogosAIAgent):
    """
    {description}
    
    Domain: {domain}
    Complexity: {complexity}
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        config = config or AgentConfig(
            name="{agent_name}",
            agent_type=AgentType.{agent_type},
            description="""{description}""",
            version="1.0.0",
            config={{
                "model": "gemini-2.5-flash",
                "temperature": 0.7,
                "max_tokens": 2000
            }}
        )
        super().__init__(config)
        
        # Initialize components
        self.logger = logger
        self.llm_client = None
        
    async def initialize(self):
        """Initialize agent components"""
        if not self.llm_client:
            self.llm_client = LLMClient(
                provider="google",
                model=self.config.config.get("model", "gemini-2.5-flash")
            )
            self.logger.info(f"{{self.config.name}} initialized")
            
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """
        Process user query
        
        Args:
            query: User input query
            context: Optional context
            
        Returns:
            AgentResponse with processing result
        """
        try:
            # Ensure initialization
            await self.initialize()
            
            self.logger.info(f"Processing query: {{query[:100]}}")
            
            # Core business logic
            {business_logic}
            
            # Return success response
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={{
                    "answer": result,
                    "metadata": {{
                        "query": query,
                        "timestamp": datetime.now().isoformat(),
                        "agent": self.config.name
                    }}
                }},
                message="Query processed successfully"
            )
            
        except Exception as e:
            self.logger.error(f"Error processing query: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}},
                message=f"Processing failed: {{str(e)}}"
            )
            
    async def cleanup(self):
        """Cleanup resources"""
        self.logger.info(f"{{self.config.name}} cleanup completed")
        
# Main execution
if __name__ == "__main__":
    async def main():
        agent = {class_name}()
        await agent.initialize()
        
        # Test query
        result = await agent.process("Test query")
        print(json.dumps(result.to_dict(), indent=2))
        
        await agent.cleanup()
        
    asyncio.run(main())
'''
            logger.warning("Using fallback standard template")

        # Load simplified template for minimal cases
        simplified_template_path = self.templates_dir / "logosai_agent_template_simplified.py.template"
        if simplified_template_path.exists():
            with open(simplified_template_path, 'r', encoding='utf-8') as f:
                self.core_templates['minimal'] = f.read()
                logger.info(f"✅ Loaded simplified template from {simplified_template_path}")
        else:
            # Fallback minimal template
            self.core_templates['minimal'] = '''
import asyncio
from typing import Dict, Any, Optional
from logosai.agents.base import LogosAIAgent
from logosai.agents.base import AgentType, AgentResponse, AgentResponseType
from logosai.agents.base import AgentConfig

class {class_name}(LogosAIAgent):
    def __init__(self, config=None):
        config = config or AgentConfig(
            name="{agent_name}",
            agent_type=AgentType.{agent_type},
            description="{description}"
        )
        super().__init__(config)
        
    async def process(self, query: str, context=None) -> AgentResponse:
        try:
            {business_logic}
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={{"result": result}}
            )
        except Exception as e:
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}}
            )
'''

        # Load domain-specific templates
        domain_templates = {
            'data_analysis': 'data_analysis_agent.py.template',
            'api_integration': 'api_integration_agent.py.template',
            'web_scraping': 'web_scraping_agent.py.template',
            'database': 'database_integration_agent.py.template',
            'document_processing': 'document_processing_agent.py.template',
            'monitoring': 'realtime_monitoring_agent.py.template',
            'workflow': 'workflow_automation_agent.py.template'
        }
        
        for domain_key, template_file in domain_templates.items():
            template_path = self.templates_dir / template_file
            if template_path.exists():
                with open(template_path, 'r', encoding='utf-8') as f:
                    self.core_templates[domain_key] = f.read()
                    logger.info(f"✅ Loaded {domain_key} template from {template_file}")

        # Store all loaded templates in database
        for template_type, code in self.core_templates.items():
            # Determine domain and complexity based on template type
            if template_type in ['minimal', 'standard']:
                domain = AgentDomain.GENERAL
                complexity = ComplexityLevel.SIMPLE if template_type == 'minimal' else ComplexityLevel.MODERATE
            elif template_type == 'data_analysis':
                domain = AgentDomain.DATA_ANALYSIS  # Fixed: DATA_PROCESSING -> DATA_ANALYSIS
                complexity = ComplexityLevel.MODERATE
            elif template_type == 'api_integration':
                domain = AgentDomain.API  # Fixed: API_INTEGRATION -> API
                complexity = ComplexityLevel.MODERATE
            elif template_type == 'web_scraping':
                domain = AgentDomain.WEB_SCRAPING
                complexity = ComplexityLevel.MODERATE
            elif template_type == 'database':
                domain = AgentDomain.DATABASE
                complexity = ComplexityLevel.MODERATE
            elif template_type == 'monitoring':
                domain = AgentDomain.AUTOMATION
                complexity = ComplexityLevel.MODERATE
            elif template_type == 'workflow':
                domain = AgentDomain.AUTOMATION
                complexity = ComplexityLevel.COMPLEX
            elif template_type == 'document_processing':
                domain = AgentDomain.NLP
                complexity = ComplexityLevel.MODERATE
            else:
                domain = AgentDomain.GENERAL
                complexity = ComplexityLevel.MODERATE
            
            self._store_template(
                Template(
                    id=f"core_{template_type}",
                    name=f"Core {template_type.replace('_', ' ').title()} Template",
                    type=TemplateType.STANDARD if template_type != 'minimal' else TemplateType.MINIMAL,
                    domain=domain,
                    complexity=complexity,
                    code=code,
                    variables=self._extract_variables(code),
                    success_rate=0.8,  # Initial high confidence for core templates
                    usage_count=0
                )
            )
            
    def _extract_variables(self, template_code: str) -> List[str]:
        """Extract template variables from code"""
        import re
        pattern = r'\{([^}]+)\}'
        variables = re.findall(pattern, template_code)
        return list(set(variables))
        
    def select_template(self, 
                        domain: AgentDomain,
                        complexity: ComplexityLevel,
                        features: List[str] = None) -> Template:
        """
        Select best template based on requirements
        
        Args:
            domain: Agent domain
            complexity: Complexity level
            features: Required features
            
        Returns:
            Selected template
        """
        logger.info(f"Selecting template for domain: {domain.value}, complexity: {complexity.value}")
        
        # Try to find domain-specific template first
        domain_template_key = domain.value.lower()
        if domain_template_key in self.core_templates:
            logger.info(f"Found domain-specific template: {domain_template_key}")
            return self._get_core_template(domain_template_key, domain, complexity)
        
        # Select based on complexity level
        if complexity == ComplexityLevel.SIMPLE:
            logger.info("Using minimal template for simple complexity")
            return self._get_core_template('minimal', domain, complexity)
        else:
            logger.info("Using standard template for moderate/complex complexity")
            return self._get_core_template('standard', domain, complexity)
            
    def _get_core_template(self, 
                          template_type: str,
                          domain: AgentDomain,
                          complexity: ComplexityLevel) -> Template:
        """Get core template with metadata"""
        code = self.core_templates.get(template_type, self.core_templates['minimal'])
        
        return Template(
            id=f"core_{template_type}_{datetime.now().timestamp()}",
            name=f"Core {template_type.title()} Template",
            type=TemplateType.STANDARD if template_type == 'standard' else TemplateType.MINIMAL,
            domain=domain,
            complexity=complexity,
            code=code,
            variables=self._extract_variables(code)
        )
        
    def generate_template(self,
                         domain: AgentDomain,
                         complexity: ComplexityLevel,
                         features: List[str],
                         llm_manager: Any) -> Template:
        """
        Generate new template using LLM
        
        Args:
            domain: Agent domain
            complexity: Complexity level
            features: Required features
            llm_manager: LLM manager for generation
            
        Returns:
            Generated template
        """
        logger.info(f"Generating new template for {domain.value}/{complexity.value}")
        
        # This would use LLM to generate a new template
        # For now, return modified standard template
        base_template = self._get_core_template('standard', domain, complexity)
        
        # Store the generated template
        base_template.id = f"gen_{domain.value}_{complexity.value}_{datetime.now().timestamp()}"
        base_template.name = f"Generated {domain.value} Template"
        base_template.type = TemplateType.CUSTOM
        
        self._store_template(base_template)
        
        return base_template
        
    def _store_template(self, template: Template):
        """Store template in database"""
        cursor = self.conn.cursor()
        
        # Check if exists
        cursor.execute('SELECT id FROM templates WHERE id = ?', (template.id,))
        exists = cursor.fetchone() is not None
        
        if exists:
            # Update
            cursor.execute('''
                UPDATE templates
                SET name = ?, type = ?, domain = ?, complexity = ?,
                    code = ?, variables = ?, success_rate = ?,
                    usage_count = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (
                template.name, template.type.value, template.domain.value,
                template.complexity.value, template.code,
                json.dumps(template.variables), template.success_rate,
                template.usage_count, template.id
            ))
        else:
            # Insert
            cursor.execute('''
                INSERT INTO templates (
                    id, name, type, domain, complexity, code,
                    variables, success_rate, usage_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                template.id, template.name, template.type.value,
                template.domain.value, template.complexity.value,
                template.code, json.dumps(template.variables),
                template.success_rate, template.usage_count
            ))
            
        self.conn.commit()
        
    def record_usage(self,
                    template_id: str,
                    query: str,
                    success: bool,
                    error_message: str = None,
                    feedback: str = None):
        """
        Record template usage for learning
        
        Args:
            template_id: Template ID
            query: User query
            success: Whether generation was successful
            error_message: Error message if failed
            feedback: User feedback
        """
        cursor = self.conn.cursor()
        
        # Insert history record
        cursor.execute('''
            INSERT INTO template_history (
                template_id, query, success, error_message, feedback
            ) VALUES (?, ?, ?, ?, ?)
        ''', (template_id, query, success, error_message, feedback))
        
        # Update template success rate
        cursor.execute('''
            SELECT COUNT(*) as total,
                   SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successes
            FROM template_history
            WHERE template_id = ?
        ''', (template_id,))
        
        row = cursor.fetchone()
        if row and row['total'] > 0:
            success_rate = row['successes'] / row['total']
            
            cursor.execute('''
                UPDATE templates
                SET success_rate = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (success_rate, template_id))
            
        self.conn.commit()
        logger.info(f"Recorded usage for template {template_id}: success={success}")
        
    def get_learning_insights(self) -> Dict[str, Any]:
        """Get learning insights from usage history"""
        cursor = self.conn.cursor()
        
        # Get overall statistics
        cursor.execute('''
            SELECT 
                COUNT(*) as total_uses,
                SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successes,
                COUNT(DISTINCT template_id) as templates_used
            FROM template_history
        ''')
        
        stats = dict(cursor.fetchone())
        
        # Get top performing templates
        cursor.execute('''
            SELECT t.name, t.domain, t.complexity, t.success_rate, t.usage_count
            FROM templates t
            WHERE t.usage_count > 0
            ORDER BY t.success_rate DESC, t.usage_count DESC
            LIMIT 5
        ''')
        
        top_templates = [dict(row) for row in cursor.fetchall()]
        
        # Get common error patterns
        cursor.execute('''
            SELECT error_message, COUNT(*) as count
            FROM template_history
            WHERE success = 0 AND error_message IS NOT NULL
            GROUP BY error_message
            ORDER BY count DESC
            LIMIT 5
        ''')
        
        error_patterns = [dict(row) for row in cursor.fetchall()]
        
        return {
            'statistics': stats,
            'top_templates': top_templates,
            'error_patterns': error_patterns,
            'success_rate': stats['successes'] / stats['total_uses'] if stats['total_uses'] > 0 else 0
        }
        
    def _update_usage_count(self, template_id: str):
        """Update template usage count"""
        cursor = self.conn.cursor()
        cursor.execute('''
            UPDATE templates
            SET usage_count = usage_count + 1,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (template_id,))
        self.conn.commit()
        
    def _row_to_template(self, row) -> Template:
        """Convert database row to Template object"""
        return Template(
            id=row['id'],
            name=row['name'],
            type=TemplateType(row['type']),
            domain=AgentDomain(row['domain']),
            complexity=ComplexityLevel(row['complexity']),
            code=row['code'],
            variables=json.loads(row['variables']) if row['variables'] else [],
            success_rate=row['success_rate'],
            usage_count=row['usage_count'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
        
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logger.info("Template database closed")