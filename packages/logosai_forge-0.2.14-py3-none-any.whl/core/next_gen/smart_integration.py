"""
Smart LLM-based Integration System for FORGE AI
===============================================
Intelligent code integration using LLM for seamless template-business logic merging
"""

import re
import json
import logging
import textwrap
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class IntegrationContext:
    """컨텍스트 정보를 담는 데이터 클래스"""
    agent_name: str
    agent_type: str
    description: str
    complexity: str
    domain: str
    business_logic: str
    template_code: Optional[str] = None
    test_queries: Optional[List[str]] = None
    examples: List[Dict[str, Any]] = None
    requirements: List[str] = None
    
    def __post_init__(self):
        if self.examples is None:
            self.examples = []
        if self.requirements is None:
            self.requirements = []


class SmartIntegrationEngine:
    """
    LLM 기반 스마트 코드 통합 엔진
    비즈니스 로직과 템플릿을 지능적으로 병합
    """
    
    def __init__(self):
        """초기화"""
        self.llm_client = None
        self._initialize_llm()
        
    def _initialize_llm(self):
        """LLM 클라이언트 초기화"""
        try:
            from .llm_integration import ForgeLLMManager
            self.llm_integration = ForgeLLMManager()
            logger.info("✅ LLM Integration initialized")
        except Exception as e:
            logger.warning(f"⚠️ LLM Integration failed: {e}")
            self.llm_integration = None
    
    async def integrate(self, context: IntegrationContext) -> str:
        """
        메인 통합 메서드
        
        Args:
            context: 통합 컨텍스트 정보
            
        Returns:
            통합된 에이전트 코드
        """
        logger.info(f"🔧 Starting smart integration for {context.agent_name}")
        
        # Step 1: 비즈니스 로직 전처리
        processed_logic = self._preprocess_business_logic(context.business_logic)
        
        # Step 2: 템플릿 선택 또는 생성
        template = self._select_template(context)
        
        # Step 3: LLM 프롬프트 생성
        prompt = self._create_integration_prompt(context, processed_logic, template)
        
        # Step 4: LLM을 통한 코드 생성
        integrated_code = await self._generate_with_llm(prompt, context)
        
        # Step 5: 후처리 및 검증
        final_code = self._postprocess_code(integrated_code, context)
        
        logger.info(f"✅ Smart integration completed for {context.agent_name}")
        return final_code
    
    def _preprocess_business_logic(self, logic: str) -> str:
        """
        비즈니스 로직 전처리
        
        Args:
            logic: 원본 비즈니스 로직
            
        Returns:
            정리된 비즈니스 로직
        """
        # 불필요한 들여쓰기 제거
        lines = logic.split('\n')
        if lines:
            # 최소 들여쓰기 찾기
            min_indent = float('inf')
            for line in lines:
                if line.strip():
                    indent = len(line) - len(line.lstrip())
                    min_indent = min(min_indent, indent)
            
            # 최소 들여쓰기 제거
            if min_indent < float('inf') and min_indent > 0:
                processed_lines = []
                for line in lines:
                    if line.strip():
                        processed_lines.append(line[min_indent:])
                    else:
                        processed_lines.append('')
                logic = '\n'.join(processed_lines)
        
        # docstring 정리
        logic = self._clean_docstrings(logic)
        
        # 중복 try/except 제거
        logic = self._remove_duplicate_try(logic)
        
        return logic
    
    def _clean_docstrings(self, code: str) -> str:
        """Docstring 정리"""
        # 시작 부분의 docstring 제거
        if code.strip().startswith('"""'):
            parts = code.split('"""', 2)
            if len(parts) >= 3:
                code = parts[2].strip()
        return code
    
    def _remove_duplicate_try(self, code: str) -> str:
        """중복된 try 구문 제거"""
        if code.strip().startswith('try:'):
            lines = code.strip().split('\n')
            # try: 라인 제거하고 들여쓰기 조정
            if len(lines) > 1:
                new_lines = []
                for line in lines[1:]:
                    if line.startswith('    '):
                        new_lines.append(line[4:])  # 들여쓰기 4칸 제거
                    else:
                        new_lines.append(line)
                code = '\n'.join(new_lines)
        return code
    
    def _select_template(self, context: IntegrationContext) -> str:
        """
        컨텍스트에 맞는 템플릿 선택
        
        Args:
            context: 통합 컨텍스트
            
        Returns:
            선택된 템플릿 코드
        """
        if context.template_code:
            return context.template_code
        
        # 기본 LogosAI 템플릿
        template = """
import asyncio
import json
import logging
from typing import Dict, Any, Optional, List, Union
from datetime import datetime

# LogosAI Framework
from logosai.agent import LogosAIAgent
from logosai.config import AgentConfig
from logosai.agent_types import AgentType, AgentResponse, AgentResponseType

logger = logging.getLogger(__name__)


class {class_name}(LogosAIAgent):
    \"\"\"{description}\"\"\"
    
    def __init__(self, config: Optional[AgentConfig] = None):
        \"\"\"에이전트 초기화\"\"\"
        if config is None:
            config = AgentConfig(
                name="{name}",
                agent_type=AgentType.CUSTOM,  # 모든 에이전트는 CUSTOM 타입 사용
                description=\"\"\"{description}\"\"\",
                config={{
                    "provider": "google",
                    "model": "gemini-2.5-flash",
                    "temperature": 0.7,
                    "max_tokens": 3000
                }}
            )
        
        super().__init__(config)
        self.name = config.name
        self.description = config.description
        self.agent_type = config.agent_type
        self.logger = logger
        
        # 초기화
        self._initialize()
        self.logger.info(f"{{self.name}} initialized")
    
    def _initialize(self):
        \"\"\"리소스 초기화\"\"\"
        # TODO: Agent-specific initialization
        pass
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        \"\"\"Process user query\"\"\"
        try:
            if context is None:
                context = {{}}
            
            # Business logic integration point
            {business_logic_placeholder}
            
        except Exception as e:
            self.logger.error(f"Error in process: {{e}}", exc_info=True)
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e), "timestamp": datetime.now().isoformat()}}
            )


# Test code
if __name__ == "__main__":
    async def test():
        agent = {class_name}()
        result = await agent.process("Test query")
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    
    asyncio.run(test())
"""
        return template
    
    def _create_integration_prompt(self, context: IntegrationContext, 
                                  processed_logic: str, template: str) -> str:
        """
        LLM 통합을 위한 프롬프트 생성
        
        Args:
            context: 통합 컨텍스트
            processed_logic: 전처리된 비즈니스 로직
            template: 템플릿 코드
            
        Returns:
            생성된 프롬프트
        """
        # 템플릿 준비 - 플레이스홀더를 마커로 표시
        template_with_marker = template.replace('{business_logic_placeholder}', 
            '# [BUSINESS_LOGIC_INTEGRATION_POINT]\n            # Insert business logic here')
        
        prompt = f"""You are an expert Python developer specializing in AI agent development with the LogosAI framework.

Your task is to intelligently integrate business logic into an agent template to create a complete, working agent.

## Agent Context:
- Name: {context.agent_name}
- Type: {context.agent_type}
- Description: {context.description}
- Complexity: {context.complexity}
- Domain: {context.domain}

## Template Code:
```python
{template_with_marker}
```

## Business Logic to Integrate:
```python
{processed_logic}
```

## Integration Instructions:
1. Find the comment "# [BUSINESS_LOGIC_INTEGRATION_POINT]" in the template
2. Replace that comment and the "# Insert business logic here" line with the actual business logic
3. The business logic should be properly indented to match the try block context
4. Ensure the business logic flows naturally within the process method
5. If the business logic returns a dict, wrap it in AgentResponse with SUCCESS type
6. If the business logic has its own try-except, integrate it properly without duplication
7. Keep all imports and class structure from the template
8. DO NOT duplicate the try-except blocks
9. Ensure all braces are single (not doubled like {{{{}}}} )

## Important Guidelines:
- The business logic should replace the integration point marker completely
- Maintain proper Python indentation (the business logic is inside a try block)
- If business logic returns a value, create AgentResponse from it
- Keep error handling from the template
- Don't add unnecessary comments or docstrings inside the process method
- Make sure the final code is syntactically correct Python

Generate the complete agent code with the business logic properly integrated at the marked point:
"""
        return prompt
    
    async def _generate_with_llm(self, prompt: str, context: IntegrationContext) -> str:
        """
        LLM을 사용한 코드 생성
        
        Args:
            prompt: 생성 프롬프트
            context: 통합 컨텍스트
            
        Returns:
            생성된 코드
        """
        if not self.llm_integration:
            logger.warning("LLM not available, using fallback")
            return self._fallback_integration(context)
        
        try:
            # LLM 생성
            response = await self.llm_integration.generate(
                prompt=prompt,
                temperature=0.3,  # 낮은 온도로 일관성 있는 코드 생성
                max_tokens=4000
            )
            
            if response.success and response.content and response.content.strip():
                # 코드 추출
                code = self._extract_code_from_response(response.content)
                return code
            else:
                logger.warning(f"LLM response failed or empty: {response.error if hasattr(response, 'error') else 'No content'}")
                return self._fallback_integration(context)
                
        except Exception as e:
            logger.error(f"LLM generation error: {e}")
            return self._fallback_integration(context)
    
    def _extract_code_from_response(self, response: str) -> str:
        """LLM 응답에서 코드 추출"""
        code = response.strip()
        
        # 코드 블록 추출
        if '```python' in code:
            parts = code.split('```python')
            if len(parts) > 1:
                code = parts[1].split('```')[0]
        elif '```' in code:
            parts = code.split('```')
            if len(parts) > 2:
                code = parts[1]
        
        return code.strip()
    
    def _fallback_integration(self, context: IntegrationContext) -> str:
        """LLM 없을 때의 fallback 통합"""
        template = self._select_template(context)
        
        # 안전한 치환을 위해 먼저 모든 중괄호를 이스케이프
        safe_template = template.replace('{', '{{').replace('}', '}}')
        
        # 플레이스홀더만 다시 원래대로
        placeholders_to_restore = [
            'class_name', 'name', 'agent_type', 'description', 'business_logic_placeholder'
        ]
        for placeholder in placeholders_to_restore:
            safe_template = safe_template.replace('{{' + placeholder + '}}', '{' + placeholder + '}')
        
        # 플레이스홀더 교체
        replacements = {
            'class_name': context.agent_name.replace(' ', '').replace('-', ''),
            'name': context.agent_name,
            'agent_type': context.agent_type.upper(),
            'description': context.description,
            'business_logic_placeholder': textwrap.indent(context.business_logic, '            ')
        }
        
        # format 사용하여 안전하게 치환
        try:
            code = safe_template.format(**replacements)
        except KeyError as e:
            logger.error(f"Missing placeholder in template: {e}")
            # 직접 치환 fallback
            code = template
            for key, value in replacements.items():
                code = code.replace('{' + key + '}', value)
        
        return code
    
    def _postprocess_code(self, code: str, context: IntegrationContext) -> str:
        """
        생성된 코드 후처리
        
        Args:
            code: 생성된 코드
            context: 통합 컨텍스트
            
        Returns:
            후처리된 코드
        """
        # 1. import 정리
        code = self._organize_imports(code)
        
        # 2. 들여쓰기 수정
        code = self._fix_indentation(code)
        
        # 3. 문법 검증
        code = self._validate_syntax(code)
        
        # 4. 테스트 코드 추가 (없으면)
        if '__main__' not in code:
            code = self._add_test_code(code, context)
        
        return code
    
    def _organize_imports(self, code: str) -> str:
        """import 문 정리"""
        lines = code.split('\n')
        
        # import 문 수집
        standard_imports = []
        third_party_imports = []
        logosai_imports = []
        local_imports = []
        other_lines = []
        
        in_imports = True
        for line in lines:
            if in_imports:
                if line.startswith('import ') or line.startswith('from '):
                    if 'logosai' in line:
                        logosai_imports.append(line)
                    elif any(pkg in line for pkg in ['asyncio', 'json', 'logging', 'typing', 'datetime', 're', 'os', 'sys']):
                        standard_imports.append(line)
                    elif line.startswith('from .'):
                        local_imports.append(line)
                    else:
                        third_party_imports.append(line)
                elif line.strip() and not line.startswith('#'):
                    in_imports = False
                    other_lines.append(line)
                elif line.startswith('#') and 'LogosAI' in line:
                    continue  # Skip LogosAI comments
                else:
                    other_lines.append(line)
            else:
                other_lines.append(line)
        
        # 재구성
        organized = []
        
        # 표준 라이브러리
        if standard_imports:
            organized.extend(sorted(set(standard_imports)))
            organized.append('')
        
        # 서드파티
        if third_party_imports:
            organized.extend(sorted(set(third_party_imports)))
            organized.append('')
        
        # LogosAI
        if logosai_imports:
            organized.append('# LogosAI Framework')
            organized.extend(sorted(set(logosai_imports)))
            organized.append('')
        
        # 로컬
        if local_imports:
            organized.extend(sorted(set(local_imports)))
            organized.append('')
        
        # 나머지 코드
        organized.extend(other_lines)
        
        return '\n'.join(organized)
    
    def _fix_indentation(self, code: str) -> str:
        """들여쓰기 수정"""
        # 탭을 공백으로 변환
        code = code.replace('\t', '    ')
        
        # 연속된 빈 줄 제거
        lines = code.split('\n')
        fixed_lines = []
        prev_empty = False
        
        for line in lines:
            if not line.strip():
                if not prev_empty:
                    fixed_lines.append(line)
                    prev_empty = True
            else:
                fixed_lines.append(line)
                prev_empty = False
        
        return '\n'.join(fixed_lines)
    
    def _validate_syntax(self, code: str) -> str:
        """문법 검증"""
        try:
            compile(code, '<string>', 'exec')
            logger.info("✅ Syntax validation passed")
            return code
        except SyntaxError as e:
            logger.warning(f"⚠️ Syntax error detected: {e}")
            # 간단한 자동 수정 시도
            return self._auto_fix_syntax(code, str(e))
    
    def _auto_fix_syntax(self, code: str, error_msg: str) -> str:
        """간단한 문법 오류 자동 수정"""
        lines = code.split('\n')
        
        # 일반적인 오류 패턴 수정
        if 'unexpected indent' in error_msg:
            # 들여쓰기 오류 수정
            fixed_lines = []
            for line in lines:
                # 잘못된 들여쓰기 감지 및 수정
                if line and line[0] == ' ' and len(line) - len(line.lstrip()) % 4 != 0:
                    # 4의 배수로 조정
                    indent = len(line) - len(line.lstrip())
                    new_indent = (indent // 4) * 4
                    fixed_lines.append(' ' * new_indent + line.lstrip())
                else:
                    fixed_lines.append(line)
            code = '\n'.join(fixed_lines)
            
        elif 'was never closed' in error_msg:
            # 미완성된 괄호나 문자열 수정
            fixed_lines = []
            for i, line in enumerate(lines):
                # logger 문이 미완성된 경우
                if 'self.logger.' in line and line.strip() and not line.strip().endswith(')'):
                    # 뒤에 내용이 없으면 완성
                    if i == len(lines) - 1 or not lines[i+1].strip():
                        line = line.rstrip() + 'f"Error occurred")'
                fixed_lines.append(line)
            
            # 마지막 줄 정리
            while fixed_lines and not fixed_lines[-1].strip():
                fixed_lines.pop()
                
            code = '\n'.join(fixed_lines)
            
        elif 'invalid syntax' in error_msg:
            # 갑자기 끊긴 코드 처리
            # 마지막 미완성 부분 제거
            for i in range(len(lines) - 1, -1, -1):
                if lines[i].strip() and not lines[i].strip().startswith('#'):
                    # 미완성된 줄 찾기
                    if 'self.logger' in lines[i] and not lines[i].strip().endswith(')'):
                        lines = lines[:i]  # 미완성 부분 제거
                    break
            code = '\n'.join(lines)
        
        return code
    
    def _add_test_code(self, code: str, context: IntegrationContext) -> str:
        """테스트 코드 추가"""
        test_code = f"""

# ========================================
# 테스트 코드
# ========================================
if __name__ == "__main__":
    async def test():
        \"\"\"에이전트 테스트\"\"\"
        print("\\n" + "="*60)
        print("{context.agent_name} 테스트")
        print("="*60)
        
        # 에이전트 생성
        agent = {context.agent_name.replace(' ', '').replace('-', '')}()
        
        # 테스트 쿼리
        test_queries = ["테스트 쿼리 1", "테스트 쿼리 2"]
        
        for query in test_queries:
            print(f"\\n쿼리: {{query}}")
            result = await agent.process(query)
            if hasattr(result, 'to_dict'):
                print(f"결과: {{json.dumps(result.to_dict(), ensure_ascii=False, indent=2)}}")
            else:
                print(f"결과: {{result}}")
        
        print("\\n" + "="*60)
        print("✅ 테스트 완료!")
        print("="*60)
    
    # 실행
    import asyncio
    asyncio.run(test())
"""
        return code + test_code


# 전역 인스턴스
_engine = None

def get_engine() -> SmartIntegrationEngine:
    """싱글톤 엔진 인스턴스 반환"""
    global _engine
    if _engine is None:
        _engine = SmartIntegrationEngine()
    return _engine


async def smart_integrate(
    agent_name: str,
    agent_type: str,
    description: str,
    business_logic: str,
    complexity: str = "medium",
    domain: str = "general",
    template_code: Optional[str] = None,
    test_queries: Optional[List[str]] = None
) -> str:
    """
    스마트 통합 헬퍼 함수
    
    Args:
        agent_name: 에이전트 이름
        agent_type: 에이전트 타입
        description: 설명
        business_logic: 비즈니스 로직
        complexity: 복잡도
        domain: 도메인
        template_code: 템플릿 코드 (옵션)
        
    Returns:
        통합된 에이전트 코드
    """
    context = IntegrationContext(
        agent_name=agent_name,
        agent_type=agent_type,
        description=description,
        complexity=complexity,
        domain=domain,
        business_logic=business_logic,
        template_code=template_code,
        test_queries=test_queries
    )
    
    engine = get_engine()
    return await engine.integrate(context)