"""
LLM Integration Manager for FORGE AI
====================================
Multi-provider LLM support with LogosAI LLMClient
"""

import os
import json
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

# Setup logger first
logger = logging.getLogger(__name__)

# Direct LLMClient import to avoid circular dependency
try:
    import sys
    import os
    # Add logosai to path
    logosai_path = '/Users/maior/Development/skku/Logos/logosai'
    if logosai_path not in sys.path:
        sys.path.insert(0, logosai_path)
    # Import directly from utils
    from logosai.utils.llm_client import LLMClient
    logger.info("Successfully imported LogosAI LLMClient")
except ImportError as e:
    logger.warning(f"LogosAI LLMClient import failed: {e}, using direct Gemini client")
    
    # Use direct Google Gemini client
    try:
        import google.generativeai as genai
        
        class LLMClient:
            def __init__(self, provider="google", model="gemini-2.5-flash-lite"):
                self.provider = provider
                self.model = model
                self._initialized = False
                self.client = None
                
            async def initialize(self):
                if not self._initialized:
                    api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
                    if api_key:
                        genai.configure(api_key=api_key)
                        self.client = genai.GenerativeModel(self.model)
                        self._initialized = True
                        logger.info(f"Initialized Gemini client with model: {self.model}")
                    else:
                        logger.warning("No Google API key found")
                
            async def invoke(self, prompt, **kwargs):
                if not self._initialized:
                    await self.initialize()
                    
                if self.client:
                    try:
                        # Generate with Gemini
                        response = self.client.generate_content(prompt)
                        from dataclasses import dataclass
                        @dataclass
                        class Response:
                            content: str
                        return Response(content=response.text)
                    except Exception as e:
                        logger.error(f"Gemini generation failed: {e}")
                        from dataclasses import dataclass
                        @dataclass
                        class Response:
                            content: str
                        return Response(content="# Error generating code\npass")
                else:
                    # Fallback response
                    from dataclasses import dataclass
                    @dataclass
                    class Response:
                        content: str
                    return Response(content="# No LLM available\npass")
                    
    except ImportError:
        logger.warning("Google generativeai not available, using fallback")
        
        class LLMClient:
            def __init__(self, provider="google", model="gemini-2.5-flash-lite"):
                self.provider = provider
                self.model = model
                self._initialized = False
                
            async def initialize(self):
                self._initialized = True
                
            async def invoke(self, prompt, **kwargs):
                # Fallback response
                from dataclasses import dataclass
                @dataclass
                class Response:
                    content: str
                return Response(content="# Fallback - no LLM available\npass")


@dataclass
class LLMResponse:
    """LLM response wrapper"""
    content: str
    provider: str
    model: str
    success: bool
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class LLMIntegration:
    """Alias for ForgeLLMManager for compatibility"""
    def __init__(self):
        self.manager = ForgeLLMManager()
    
    async def generate(self, prompt: str, temperature: float = 0.7, max_tokens: int = 3000, **kwargs) -> str:
        """Generate code using LLM"""
        response = await self.manager.generate(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs
        )
        if response.success:
            return response.content
        else:
            raise Exception(f"LLM generation failed: {response.error}")


class ForgeLLMManager:
    """
    Centralized LLM management for FORGE AI
    Supports multiple providers with fallback mechanism
    """
    
    def __init__(self, primary_provider: str = "google"):
        """
        Initialize LLM Manager
        
        Args:
            primary_provider: Primary LLM provider (google, openai, anthropic)
        """
        self.primary_provider = primary_provider
        self._initialize_clients()
        
    def _initialize_clients(self):
        """Initialize LLM clients for different providers"""
        self.clients = {}
        
        # Google (Primary) - Upgraded to Pro for better quality
        try:
            # Use Gemini 2.5 Flash Lite - cost optimized
            # Available models: gemini-2.5-pro, gemini-2.5-flash, gemini-2.5-flash-lite
            model_name = os.getenv("GOOGLE_MODEL", "gemini-2.5-flash-lite")  # Using Lite model for cost reduction
            self.clients['google'] = LLMClient(
                provider="google",
                model=model_name,
                max_tokens=8000  # 증가: 2000 -> 8000
            )
            logger.info(f"Google LLM client initialized with model: {model_name}")
        except Exception as e:
            logger.warning(f"Failed to initialize Google client: {e}")
            
        # OpenAI (Fallback)
        if os.getenv("OPENAI_API_KEY"):
            try:
                self.clients['openai'] = LLMClient(
                    provider="openai",
                    model=os.getenv("OPENAI_MODEL", "gpt-4")
                )
                logger.info("OpenAI LLM client initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize OpenAI client: {e}")
                
        # Anthropic (Fallback)
        if os.getenv("ANTHROPIC_API_KEY"):
            try:
                self.clients['anthropic'] = LLMClient(
                    provider="anthropic",
                    model=os.getenv("ANTHROPIC_MODEL", "claude-3-sonnet-20240229")
                )
                logger.info("Anthropic LLM client initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize Anthropic client: {e}")
                
        # Open source support placeholder
        # self.clients['ollama'] = LLMClient(provider="ollama", model="llama2")
        
    async def _call_llm(self, provider: str, prompt: str, **kwargs) -> LLMResponse:
        """
        Call specific LLM provider
        
        Args:
            provider: Provider name
            prompt: Prompt text
            **kwargs: Additional parameters
            
        Returns:
            LLMResponse object
        """
        if provider not in self.clients:
            return LLMResponse(
                content="",
                provider=provider,
                model="",
                success=False,
                error=f"Provider {provider} not available"
            )
            
        try:
            client = self.clients[provider]
            response = await client.invoke(prompt, **kwargs)
            
            # Extract content from LogosAI LLMResponse
            if hasattr(response, 'content'):
                content = response.content
            else:
                content = str(response)
            
            return LLMResponse(
                content=content,
                provider=provider,
                model=getattr(client, 'model', 'unknown'),
                success=True,
                metadata=kwargs
            )
        except Exception as e:
            logger.error(f"LLM call failed for {provider}: {e}")
            return LLMResponse(
                content="",
                provider=provider,
                model="",
                success=False,
                error=str(e)
            )
            
    async def generate(self, prompt: str, **kwargs) -> LLMResponse:
        """
        Generate response with automatic fallback
        
        Args:
            prompt: Prompt text
            **kwargs: Additional parameters
            
        Returns:
            LLMResponse object
        """
        # Try primary provider first
        response = await self._call_llm(self.primary_provider, prompt, **kwargs)
        if response.success:
            return response
            
        # Fallback to other providers
        for provider in self.clients:
            if provider != self.primary_provider:
                logger.info(f"Falling back to {provider}")
                response = await self._call_llm(provider, prompt, **kwargs)
                if response.success:
                    return response
                    
        # All providers failed
        return LLMResponse(
            content="",
            provider="none",
            model="",
            success=False,
            error="All LLM providers failed"
        )
        
    async def analyze_query(self, query: str) -> Dict[str, Any]:
        """
        Analyze user query to extract requirements
        
        Args:
            query: User input query
            
        Returns:
            Analysis result dictionary
        """
        prompt = f"""Analyze the following user query for agent generation:

Query: {query}

Extract and return a JSON object with:
1. intent: Main purpose of the agent
2. features: List of required features
3. domain: Domain category (data_analysis, api, nlp, ml, utility, etc.)
4. complexity: Complexity level (simple, moderate, complex)
5. requirements: Specific technical requirements
6. suggested_name: Suggested agent name
7. description: Brief description

Return ONLY valid JSON, no additional text."""

        response = await self.generate(prompt, temperature=0.3)
        
        if response.success:
            try:
                # Clean markdown json blocks if present
                content = response.content.strip()
                if content.startswith('```json'):
                    content = content[7:]  # Remove ```json
                if content.startswith('```'):
                    content = content[3:]  # Remove ```
                if content.endswith('```'):
                    content = content[:-3]  # Remove trailing ```
                content = content.strip()
                
                return json.loads(content)
            except json.JSONDecodeError:
                # Fallback parsing
                logger.warning("Failed to parse JSON, using fallback")
                return {
                    "intent": query,
                    "features": [],
                    "domain": "general",
                    "complexity": "moderate",
                    "requirements": [],
                    "suggested_name": "CustomAgent",
                    "description": query
                }
        else:
            return {
                "error": response.error,
                "intent": query,
                "features": [],
                "domain": "unknown",
                "complexity": "unknown"
            }
            
    async def generate_business_logic(self, context: Dict[str, Any]) -> str:
        """
        Generate business logic code based on context
        
        Args:
            context: Context dictionary with requirements
            
        Returns:
            Generated Python code string
        """
        prompt = f"""Generate Python business logic code for the following requirements:

Context:
{json.dumps(context, indent=2)}

Requirements:
1. Use async/await pattern
2. Include proper error handling
3. Follow LogosAI framework patterns
4. Return structured response
5. Include logging

Generate ONLY the core business logic code that will be inserted into the agent template.
Do NOT include class definition or imports.
Start with proper indentation (use 8 spaces for method-level code).

Return clean Python code without markdown markers."""

        response = await self.generate(prompt, temperature=0.5)
        
        if response.success:
            # Clean and normalize the code
            code = response.content.strip()
            # Remove markdown if present
            if code.startswith("```"):
                lines = code.split('\n')
                code = '\n'.join(lines[1:-1] if lines[-1] == "```" else lines[1:])
            return code
        else:
            logger.error(f"Failed to generate business logic: {response.error}")
            return "# Error generating business logic\npass"
            
    async def design_architecture(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Design agent architecture based on analysis
        
        Args:
            analysis: Query analysis result
            
        Returns:
            Architecture design dictionary
        """
        prompt = f"""Design the architecture for an agent based on this analysis:

{json.dumps(analysis, indent=2)}

Return a JSON object with:
1. components: List of required components
2. workflow: Execution workflow steps
3. dependencies: External dependencies needed
4. data_flow: How data flows through the agent
5. error_handling: Error handling strategy
6. logging_strategy: What should be logged
7. performance_considerations: Performance optimization points

Return ONLY valid JSON."""

        response = await self.generate(prompt, temperature=0.4)
        
        if response.success:
            try:
                # Clean markdown json blocks if present
                content = response.content.strip()
                if content.startswith('```json'):
                    content = content[7:]  # Remove ```json
                if content.startswith('```'):
                    content = content[3:]  # Remove ```
                if content.endswith('```'):
                    content = content[:-3]  # Remove trailing ```
                content = content.strip()
                
                return json.loads(content)
            except json.JSONDecodeError:
                logger.warning("Failed to parse architecture JSON")
                return {
                    "components": [],
                    "workflow": [],
                    "dependencies": [],
                    "data_flow": "linear",
                    "error_handling": "try-except",
                    "logging_strategy": "basic",
                    "performance_considerations": []
                }
        else:
            return {"error": response.error}
            
    async def validate_code(self, code: str) -> Dict[str, Any]:
        """
        Validate generated code using LLM
        
        Args:
            code: Generated code to validate
            
        Returns:
            Validation result dictionary
        """
        prompt = f"""Validate the following Python code for issues:

```python
{code}
```

Check for:
1. Syntax errors
2. Logic errors
3. Security issues
4. Performance problems
5. Best practice violations

Return a JSON object with:
- is_valid: boolean
- issues: list of issues found
- suggestions: list of improvement suggestions
- severity: overall severity (low, medium, high)

Return ONLY valid JSON."""

        response = await self.generate(prompt, temperature=0.2)
        
        if response.success:
            try:
                # Clean markdown json blocks if present
                content = response.content.strip()
                if content.startswith('```json'):
                    content = content[7:]  # Remove ```json
                if content.startswith('```'):
                    content = content[3:]  # Remove ```
                if content.endswith('```'):
                    content = content[:-3]  # Remove trailing ```
                content = content.strip()
                
                return json.loads(content)
            except json.JSONDecodeError:
                return {
                    "is_valid": True,
                    "issues": [],
                    "suggestions": [],
                    "severity": "low"
                }
        else:
            return {
                "is_valid": False,
                "issues": [f"Validation failed: {response.error}"],
                "suggestions": [],
                "severity": "high"
            }