"""
클래스 기반 비즈니스 로직 생성 시스템
Class-based business logic generation system
"""

class ClassBasedPromptSystem:
    """독립적인 비즈니스 로직 클래스 생성"""
    
    def get_business_logic_prompt(self, intent: str, agent_name: str) -> str:
        """
        완전한 비즈니스 로직 클래스 생성 프롬프트
        
        핵심:
        1. 완전한 클래스 생성 (들여쓰기 0부터)
        2. 독립적으로 실행 가능
        3. 명확한 인터페이스
        """
        
        prompt = f"""Create a complete Python class for: {intent}

Generate a standalone business logic class with this exact structure:

```python
class {agent_name}Logic:
    \"\"\"Business logic for {intent}\"\"\"
    
    def __init__(self):
        \"\"\"Initialize the business logic\"\"\"
        pass
    
    def execute(self, query: str) -> dict:
        \"\"\"
        Execute the business logic
        
        Args:
            query: User query string
            
        Returns:
            Dictionary with 'success' and 'data' keys
        \"\"\"
        try:
            # YOUR LOGIC HERE
            result = self.process_query(query)
            return {{"success": True, "data": result}}
        except Exception as e:
            return {{"success": False, "error": str(e)}}
    
    def process_query(self, query: str):
        \"\"\"Process the query - implement your logic here\"\"\"
        # IMPLEMENT YOUR LOGIC
        pass
```

REQUIREMENTS:
1. Class must start at column 0 (no indentation)
2. Use double quotes for strings
3. Dictionary keys must be strings: {{"key": value}}
4. Include proper error handling
5. The execute() method is the main entry point
6. Add helper methods as needed

Now generate the complete class for: {intent}
Make it simple but functional."""
        
        return prompt
    
    def get_simple_class_prompt(self, intent: str, agent_name: str) -> str:
        """더 간단한 버전"""
        
        prompt = f"""Create a Python class named {agent_name}Logic that does: {intent}

Example structure:
```python
class ExampleLogic:
    def execute(self, query: str) -> dict:
        try:
            # Process the query
            result = "processed: " + query
            return {{"success": True, "data": result}}
        except Exception as e:
            return {{"success": False, "error": str(e)}}
```

Generate a similar class for: {intent}
Class name: {agent_name}Logic
Start at column 0, no indentation for class definition."""
        
        return prompt
    
    def validate_generated_class(self, code: str) -> tuple[bool, list]:
        """
        생성된 클래스 검증
        
        Returns:
            (성공 여부, 오류 목록)
        """
        errors = []
        
        # 1. 클래스 정의 확인
        if not code.strip().startswith('class '):
            errors.append("Code doesn't start with class definition")
        
        # 2. execute 메서드 확인
        if 'def execute(' not in code:
            errors.append("Missing execute() method")
        
        # 3. 문법 검증
        try:
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            errors.append(f"Syntax error: {e}")
            return False, errors
        
        # 4. 들여쓰기 확인 (클래스는 0부터 시작해야 함)
        first_line = code.strip().split('\n')[0]
        if first_line.startswith(' ') or first_line.startswith('\t'):
            errors.append("Class definition should start at column 0")
        
        return len(errors) == 0, errors