"""
Enhanced Prompt System for FORGE AI
고품질 코드 생성을 위한 개선된 프롬프트 시스템
"""

from typing import Dict, Any, List
from dataclasses import dataclass
import json

@dataclass
class PromptTemplate:
    """프롬프트 템플릿 클래스"""
    name: str
    system_prompt: str
    user_prompt: str
    examples: List[Dict[str, str]]
    validation_rules: List[str]
    
class ImprovedPromptSystem:
    """개선된 프롬프트 시스템"""
    
    def __init__(self):
        self.templates = self._create_templates()
        
    def _create_templates(self) -> Dict[str, PromptTemplate]:
        """개선된 프롬프트 템플릿 생성"""
        
        return {
            "business_logic": PromptTemplate(
                name="Business Logic Generator",
                system_prompt="""You are an expert Python developer specializing in clean, production-ready code.
Your code MUST:
1. Be syntactically correct Python 3.11+
2. Use proper async/await patterns
3. Include comprehensive error handling
4. Follow PEP 8 style guidelines
5. Be well-commented and self-documenting
6. NEVER have unterminated strings or syntax errors
7. Use f-strings correctly: f"text {variable}"
8. Handle all edge cases gracefully""",
                
                user_prompt="""Generate Python business logic for: {intent}

CONTEXT:
- Agent Name: {agent_name}
- Domain: {domain}
- Features: {features}
- Pattern: {pattern}

STRICT REQUIREMENTS:
1. Generate ONLY the method body code (no class definition)
2. START each line with EXACTLY 8 spaces (no more, no less)
3. Include try-except blocks for ALL operations
4. Use proper logging with logger.info/warning/error
5. Return a dictionary with 'success' and 'data' keys
6. Handle None/empty inputs gracefully
7. Use type hints for all parameters

EXAMPLE STRUCTURE:
```python
        # Input validation
        if not query:
            logger.warning("Empty query provided")
            return {{"success": False, "error": "Query cannot be empty"}}
        
        try:
            # Main logic here
            logger.info(f"Processing query: {{query}}")
            
            # Process data
            result = await self._process_data(query)
            
            # Return success
            return {{
                "success": True,
                "data": result,
                "metadata": {{"processed_at": datetime.now().isoformat()}}
            }}
            
        except Exception as e:
            logger.error(f"Processing failed: {{str(e)}}")
            return {{"success": False, "error": str(e)}}
```

NOW GENERATE CODE FOR: {specific_requirement}

CRITICAL FORMATTING RULES:
- EVERY line must start with EXACTLY 8 spaces (not tabs)
- DO NOT add extra indentation at the beginning
- f-strings must be properly quoted: f"text {{variable}}"
- Dictionary keys must be strings: {{"key": value}}
- No syntax errors allowed!""",
                
                examples=[
                    {
                        "input": "Create calculator logic",
                        "output": """        # Calculator logic implementation
        if not query:
            return {"success": False, "error": "No calculation query provided"}
        
        try:
            logger.info(f"Processing calculation: {query}")
            
            # Parse the calculation
            query_lower = query.lower()
            result = None
            
            if "add" in query_lower or "+" in query_lower:
                # Extract numbers for addition
                numbers = [float(s) for s in query.split() if s.replace('.','').isdigit()]
                if len(numbers) >= 2:
                    result = sum(numbers)
                    operation = "addition"
                else:
                    return {"success": False, "error": "Need at least 2 numbers for addition"}
                    
            elif "subtract" in query_lower or "-" in query_lower:
                numbers = [float(s) for s in query.split() if s.replace('.','').isdigit()]
                if len(numbers) >= 2:
                    result = numbers[0] - sum(numbers[1:])
                    operation = "subtraction"
                else:
                    return {"success": False, "error": "Need at least 2 numbers for subtraction"}
                    
            elif "multiply" in query_lower or "*" in query_lower:
                numbers = [float(s) for s in query.split() if s.replace('.','').isdigit()]
                if len(numbers) >= 2:
                    result = 1
                    for num in numbers:
                        result *= num
                    operation = "multiplication"
                else:
                    return {"success": False, "error": "Need at least 2 numbers for multiplication"}
                    
            elif "divide" in query_lower or "/" in query_lower:
                numbers = [float(s) for s in query.split() if s.replace('.','').isdigit()]
                if len(numbers) >= 2:
                    if any(n == 0 for n in numbers[1:]):
                        return {"success": False, "error": "Cannot divide by zero"}
                    result = numbers[0]
                    for num in numbers[1:]:
                        result /= num
                    operation = "division"
                else:
                    return {"success": False, "error": "Need at least 2 numbers for division"}
            else:
                return {"success": False, "error": "Unknown operation. Supported: add, subtract, multiply, divide"}
            
            # Return the result
            return {
                "success": True,
                "data": {
                    "result": result,
                    "operation": operation,
                    "input": query
                },
                "metadata": {
                    "processed_at": datetime.now().isoformat(),
                    "numbers_found": len(numbers) if 'numbers' in locals() else 0
                }
            }
            
        except ValueError as e:
            logger.error(f"Value error in calculation: {str(e)}")
            return {"success": False, "error": f"Invalid number format: {str(e)}"}
        except Exception as e:
            logger.error(f"Unexpected error in calculator: {str(e)}")
            return {"success": False, "error": f"Calculation failed: {str(e)}"}"""
                    }
                ],
                
                validation_rules=[
                    "No unterminated strings",
                    "All brackets must be closed",
                    "Proper indentation (8 spaces base)",
                    "All f-strings properly formatted",
                    "Try-except blocks present",
                    "Returns dictionary with success key",
                    "No syntax errors when compiled"
                ]
            ),
            
            "simple_logic": PromptTemplate(
                name="Simple Logic Generator",
                system_prompt="""You are a Python code generator that creates simple, error-free code.
Focus on clarity and correctness over complexity.""",
                
                user_prompt="""Generate a simple Python method body for: {intent}

Requirements:
1. Keep it simple and working
2. Use 8 spaces indentation
3. Always return a dictionary
4. Handle errors with try-except

Example pattern:
```python
        try:
            # Your logic here
            result = "processed"
            return {{"success": True, "data": result}}
        except Exception as e:
            return {{"success": False, "error": str(e)}}
```

Generate code for: {specific_requirement}""",
                
                examples=[],
                validation_rules=["Must compile", "Must return dict"]
            )
        }
    
    def get_improved_prompt(self, 
                          intent: str,
                          agent_name: str,
                          domain: str,
                          features: List[str],
                          pattern: str,
                          use_simple: bool = False) -> str:
        """
        개선된 프롬프트 생성
        
        Args:
            intent: 사용자 의도
            agent_name: 에이전트 이름
            domain: 도메인
            features: 기능 목록
            pattern: 패턴 타입
            use_simple: 간단한 버전 사용 여부
            
        Returns:
            완성된 프롬프트
        """
        template_key = "simple_logic" if use_simple else "business_logic"
        template = self.templates[template_key]
        
        # Fill in the template
        prompt = template.user_prompt.format(
            intent=intent,
            agent_name=agent_name,
            domain=domain,
            features=", ".join(features),
            pattern=pattern,
            specific_requirement=intent
        )
        
        # Add examples if available
        if template.examples:
            example_text = "\n\nEXAMPLE:\n"
            for ex in template.examples[:1]:  # Use first example
                example_text += f"Input: {ex['input']}\n"
                example_text += f"Output:\n{ex['output']}\n"
            prompt = prompt.replace("EXAMPLE STRUCTURE:", example_text + "\nSTRUCTURE:")
        
        return prompt
    
    def validate_generated_code(self, code: str) -> tuple[bool, List[str]]:
        """
        생성된 코드 검증
        
        Args:
            code: 생성된 코드
            
        Returns:
            (성공 여부, 오류 목록)
        """
        errors = []
        
        # 1. 문법 체크
        try:
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
            return False, errors
        
        # 2. 기본 구조 체크
        if "return {" not in code:
            errors.append("Missing return statement with dictionary")
        
        if "try:" not in code:
            errors.append("Missing try-except block")
            
        if "except" not in code:
            errors.append("Missing except clause")
        
        # 3. 문자열 체크
        import re
        # Check for unterminated f-strings
        if re.search(r'f"[^"]*\{[^}]*$', code):
            errors.append("Possible unterminated f-string")
        
        # 4. 들여쓰기 체크
        lines = code.split('\n')
        for i, line in enumerate(lines):
            if line and not line.startswith('        '):  # 8 spaces
                if line.strip() and not line.strip().startswith('#'):
                    errors.append(f"Incorrect indentation at line {i+1}")
                    break
        
        return len(errors) == 0, errors
    
    def auto_fix_code(self, code: str) -> str:
        """
        일반적인 코드 오류 자동 수정
        
        Args:
            code: 원본 코드
            
        Returns:
            수정된 코드
        """
        # 1. 들여쓰기 수정
        lines = code.split('\n')
        fixed_lines = []
        for line in lines:
            if line.strip():
                # Ensure minimum 8 spaces
                stripped = line.lstrip()
                current_indent = len(line) - len(stripped)
                if current_indent < 8 and not stripped.startswith('#'):
                    fixed_lines.append('        ' + stripped)
                else:
                    fixed_lines.append(line)
            else:
                fixed_lines.append(line)
        
        code = '\n'.join(fixed_lines)
        
        # 2. 누락된 따옴표 수정
        import re
        # Fix unclosed f-strings
        code = re.sub(r'(f"[^"]*)\n', r'\1"\n', code)
        
        # 3. 누락된 콜론 추가
        code = re.sub(r'(try|except|if|elif|else|for|while|with|def|class)([^:]*)\n', 
                     r'\1\2:\n', code)
        
        # 4. 기본 try-except 추가 (없는 경우)
        if 'try:' not in code:
            code = f"""        try:
{code}
        except Exception as e:
            return {{"success": False, "error": str(e)}}"""
        
        return code


# Quality improvement strategies
QUALITY_IMPROVEMENT_STRATEGIES = {
    "prompt_engineering": {
        "description": "프롬프트 엔지니어링 개선",
        "techniques": [
            "Few-shot learning with examples",
            "Clear structure templates",
            "Explicit error handling requirements",
            "Step-by-step instructions",
            "Validation rules in prompt"
        ]
    },
    "iterative_refinement": {
        "description": "반복적 개선",
        "techniques": [
            "Generate -> Validate -> Fix cycle",
            "Multiple attempts with different prompts",
            "Learning from failures",
            "Progressive complexity increase"
        ]
    },
    "code_validation": {
        "description": "코드 검증 강화",
        "techniques": [
            "Syntax checking",
            "Structure validation",
            "Pattern matching",
            "Auto-fixing common errors",
            "Test execution"
        ]
    },
    "hybrid_approach": {
        "description": "하이브리드 접근",
        "techniques": [
            "Template-based skeleton",
            "LLM for business logic only",
            "Rule-based validation",
            "Fallback to simpler patterns",
            "Caching successful patterns"
        ]
    }
}