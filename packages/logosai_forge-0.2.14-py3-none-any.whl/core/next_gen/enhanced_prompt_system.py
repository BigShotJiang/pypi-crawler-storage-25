"""
Enhanced Prompt System for FORGE AI
====================================
Rich prompts with examples and detailed instructions
"""

import json
from typing import Dict, Any, List, Optional

class EnhancedPromptSystem:
    """풍부한 예제와 명확한 지침을 포함한 향상된 프롬프트 시스템"""
    
    def get_system_prompt(self) -> str:
        """강력하고 상세한 System Prompt"""
        return """You are an expert Python developer. Generate ONLY syntactically perfect Python code.

CRITICAL RULES:
1. ALL strings MUST be in quotes: "string" or 'string' - NEVER write bare strings
2. ALL dictionary keys MUST be quoted: {"key": value} - NEVER {key: value}
3. ALL f-strings MUST have f prefix: f"text {variable}"
4. NEVER use unquoted strings except Python keywords (def, class, return, if, else, try, except, etc.)
5. ALWAYS use proper Python syntax
6. When returning dictionaries: return {"status": "success", "data": data} NOT return {status: success}
7. String values in dictionaries MUST be quoted: {"type": "calculation"} NOT {"type": calculation}

Generate a complete Python class for a LogosAI agent."""

    def get_generation_prompt(self, intent: str, agent_name: str, examples: Optional[List[Dict]] = None) -> str:
        """
        생성 프롬프트 with rich examples
        
        Args:
            intent: What the agent should do
            agent_name: Name of the agent class
            examples: Optional examples of similar agents
        """
        
        # Agent type에 따른 특화된 예제
        agent_examples = self._get_agent_examples(intent)
        
        prompt = f"""Generate a complete Python class named {agent_name}Logic.

Purpose: {intent}

Requirements:
1. Class must have __init__ and execute methods
2. execute(query: str) -> dict must return {{"success": bool, "data": any}} or {{"success": bool, "error": str}}
3. Implement actual logic for: {intent}
4. Use proper Python syntax with ALL strings quoted
5. Handle errors with try-except

Generate ONLY the Python code, no explanations:"""
        
        return prompt
    
    def _get_agent_examples(self, intent: str) -> str:
        """Get relevant examples based on agent intent"""
        
        intent_lower = intent.lower()
        
        # Calculator agent example
        if any(word in intent_lower for word in ['calculator', 'math', '계산', '수학']):
            return """
EXAMPLE - Calculator Agent:
```python
class CalculatorLogic:
    def __init__(self):
        self.name = "CalculatorAgent"
        self.description = "Performs mathematical calculations"
        self.operations = {
            '+': lambda a, b: a + b,
            '-': lambda a, b: a - b,
            '*': lambda a, b: a * b,
            '/': lambda a, b: a / b if b != 0 else None
        }
    
    def execute(self, query: str) -> dict:
        try:
            # Parse the query for numbers and operation
            parts = query.replace(',', '').split()
            numbers = []
            operation = None
            
            for part in parts:
                if part in self.operations:
                    operation = part
                else:
                    try:
                        num = float(part)
                        numbers.append(num)
                    except ValueError:
                        continue
            
            if len(numbers) >= 2 and operation:
                result = self.operations[operation](numbers[0], numbers[1])
                if result is not None:
                    return {
                        "success": True,
                        "data": {
                            "expression": f"{numbers[0]} {operation} {numbers[1]}",
                            "result": result,
                            "type": "calculation"
                        }
                    }
            
            return {
                "success": False,
                "error": "Please provide two numbers and an operation (+, -, *, /)"
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
```"""
        
        # Weather agent example
        elif any(word in intent_lower for word in ['weather', '날씨', 'temperature', '온도']):
            return """
EXAMPLE - Weather Agent:
```python
class WeatherLogic:
    def __init__(self):
        self.name = "WeatherAgent"
        self.description = "Provides weather information"
        # Mock weather data for demonstration
        self.weather_data = {
            "seoul": {"temp": 15, "condition": "Partly Cloudy", "humidity": 60},
            "new york": {"temp": 10, "condition": "Sunny", "humidity": 45},
            "london": {"temp": 8, "condition": "Rainy", "humidity": 80}
        }
    
    def execute(self, query: str) -> dict:
        try:
            query_lower = query.lower()
            
            # Extract city from query
            city = None
            for location in self.weather_data.keys():
                if location in query_lower:
                    city = location
                    break
            
            if city:
                weather = self.weather_data[city]
                return {
                    "success": True,
                    "data": {
                        "city": city.title(),
                        "temperature": f"{weather['temp']}°C",
                        "condition": weather['condition'],
                        "humidity": f"{weather['humidity']}%",
                        "message": f"Current weather in {city.title()}: {weather['temp']}°C, {weather['condition']}"
                    }
                }
            else:
                return {
                    "success": True,
                    "data": {
                        "message": "Please specify a city for weather information",
                        "available_cities": list(self.weather_data.keys())
                    }
                }
                
        except Exception as e:
            return {"success": False, "error": str(e)}
```"""
        
        # Data analysis agent example
        elif any(word in intent_lower for word in ['data', 'analysis', '데이터', '분석', 'process']):
            return """
EXAMPLE - Data Analysis Agent:
```python
class DataAnalysisLogic:
    def __init__(self):
        self.name = "DataAnalysisAgent"
        self.description = "Analyzes and processes data"
    
    def execute(self, query: str) -> dict:
        try:
            # Simple data analysis example
            if "analyze" in query.lower():
                # Mock data analysis
                sample_data = [10, 20, 30, 40, 50]
                analysis = {
                    "count": len(sample_data),
                    "sum": sum(sample_data),
                    "average": sum(sample_data) / len(sample_data),
                    "min": min(sample_data),
                    "max": max(sample_data)
                }
                
                return {
                    "success": True,
                    "data": {
                        "type": "statistical_analysis",
                        "results": analysis,
                        "message": f"Analysis complete: {len(sample_data)} data points processed"
                    }
                }
            else:
                return {
                    "success": True,
                    "data": {
                        "message": "Please specify what data to analyze",
                        "available_operations": ["statistical analysis", "trend analysis", "data cleaning"]
                    }
                }
                
        except Exception as e:
            return {"success": False, "error": str(e)}
```"""
        
        # Default example for general agents
        else:
            return """
EXAMPLE - General Purpose Agent:
```python
class GeneralLogic:
    def __init__(self):
        self.name = "GeneralAgent"
        self.description = "General purpose agent"
    
    def execute(self, query: str) -> dict:
        try:
            # Process the query
            query_lower = query.lower()
            
            # Implement your specific logic here
            if "help" in query_lower:
                return {
                    "success": True,
                    "data": {
                        "message": "I'm here to help! What would you like to know?",
                        "capabilities": ["process queries", "provide information", "assist with tasks"]
                    }
                }
            else:
                # Process the query and return results
                result = f"Processed query: {query}"
                return {
                    "success": True,
                    "data": {
                        "result": result,
                        "query_length": len(query),
                        "timestamp": "2024-01-01 00:00:00"
                    }
                }
                
        except Exception as e:
            return {"success": False, "error": str(e)}
```"""
    
    def _get_specific_requirements(self, intent: str) -> str:
        """Get specific requirements based on intent"""
        
        intent_lower = intent.lower()
        requirements = []
        
        # Analyze intent and add specific requirements
        if 'calculator' in intent_lower or 'math' in intent_lower or '계산' in intent_lower:
            requirements = [
                "1. Parse mathematical expressions from natural language",
                "2. Support basic operations (+, -, *, /)",
                "3. Handle division by zero gracefully",
                "4. Return both the expression and the result",
                "5. Support decimal numbers"
            ]
        elif 'weather' in intent_lower or '날씨' in intent_lower:
            requirements = [
                "1. Extract location from query",
                "2. Return temperature, conditions, and other weather data",
                "3. Handle unknown locations gracefully",
                "4. Format response in a user-friendly way",
                "5. Include units (Celsius, percentage, etc.)"
            ]
        elif 'data' in intent_lower or 'analysis' in intent_lower or '분석' in intent_lower:
            requirements = [
                "1. Identify the type of analysis requested",
                "2. Process data and generate statistics",
                "3. Return structured analysis results",
                "4. Include summary and insights",
                "5. Handle various data formats"
            ]
        elif 'search' in intent_lower or '검색' in intent_lower:
            requirements = [
                "1. Extract search keywords from query",
                "2. Perform search operation",
                "3. Return relevant results",
                "4. Include result ranking or relevance",
                "5. Handle no results case"
            ]
        else:
            requirements = [
                "1. Parse and understand the user query",
                "2. Perform the requested operation",
                "3. Return structured, meaningful results",
                "4. Include helpful error messages",
                "5. Provide clear response formatting"
            ]
        
        return "\n".join(requirements)
    
    def get_correction_prompt(self, broken_code: str, error: str) -> str:
        """
        Prompt for fixing broken code
        
        Args:
            broken_code: Code with errors
            error: Error message
            
        Returns:
            Correction prompt
        """
        return f"""Fix this Python code that has a syntax or runtime error.

BROKEN CODE:
```python
{broken_code}
```

ERROR MESSAGE:
{error}

COMMON ISSUES TO CHECK:
1. Unquoted strings - All strings need quotes: "string" or 'string'
2. F-strings - Must have 'f' before the quote: f"text {{variable}}"
3. Dictionary keys - Must be strings with quotes: {{"key": value}}
4. Indentation - Python requires consistent indentation
5. Missing colons - After if, for, def, class statements
6. Unclosed brackets - Check all (), [], {{}}
7. Import statements - Ensure all used modules are imported

FIX THE CODE:
1. Identify the exact error
2. Fix the syntax/logic issue
3. Ensure the code will run without errors
4. Maintain the original functionality
5. Keep proper Python style

RETURN ONLY THE FIXED CODE, no explanations:"""
    
    def validate_and_enhance(self, code: str) -> tuple[bool, str, list]:
        """
        Validate and enhance generated code
        
        Args:
            code: Generated code to validate
            
        Returns:
            (is_valid, enhanced_code, issues)
        """
        issues = []
        enhanced_code = code
        
        # Check for class definition
        if 'class' not in code:
            issues.append("Missing class definition")
            return False, code, issues
        
        # Check for execute method
        if 'def execute(' not in code:
            issues.append("Missing execute() method")
            return False, code, issues
        
        # Try to compile
        try:
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            issues.append(f"Syntax error: {e}")
            return False, code, issues
        
        # Enhancements
        enhancements_made = []
        
        # Add logging import if missing
        if 'logger' in code and 'import logging' not in code:
            enhanced_code = "import logging\nlogger = logging.getLogger(__name__)\n\n" + enhanced_code
            enhancements_made.append("Added logging import")
        
        # Add datetime import if used but not imported
        if 'datetime' in code and 'import datetime' not in code and 'from datetime import' not in code:
            enhanced_code = "from datetime import datetime\n" + enhanced_code
            enhancements_made.append("Added datetime import")
        
        # Add type hints import if missing
        if '-> dict' in code and 'from typing import' not in code:
            enhanced_code = "from typing import Dict, Any, Optional\n" + enhanced_code
            enhancements_made.append("Added typing imports")
        
        return True, enhanced_code, enhancements_made