"""
Intelligent Query Analyzer for FORGE AI
========================================
LLM-powered query analysis and requirement extraction
"""

import re
import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum

from .llm_integration import ForgeLLMManager, LLMResponse

logger = logging.getLogger(__name__)


class AgentDomain(Enum):
    """Agent domain categories"""
    DATA_ANALYSIS = "data_analysis"
    API = "api"
    NLP = "nlp"
    ML = "ml"
    WEB_SCRAPING = "web_scraping"
    DATABASE = "database"
    UTILITY = "utility"
    INTEGRATION = "integration"
    AUTOMATION = "automation"
    GENERAL = "general"


class ComplexityLevel(Enum):
    """Complexity levels for agent generation"""
    SIMPLE = "simple"      # Basic single-function agent
    MODERATE = "moderate"  # Multi-function with some logic
    COMPLEX = "complex"    # Complex workflow with multiple components
    ADVANCED = "advanced"  # Advanced with learning/adaptation


@dataclass
class QueryAnalysis:
    """Query analysis result"""
    query: str
    intent: str
    features: List[str]
    domain: AgentDomain
    complexity: ComplexityLevel
    requirements: Dict[str, Any]
    suggested_name: str
    description: str
    keywords: List[str]
    entities: Dict[str, Any]
    confidence: float
    

class IntelligentAnalyzer:
    """
    Intelligent query analyzer using LLM for deep understanding
    """
    
    def __init__(self, llm_manager: Optional[ForgeLLMManager] = None):
        """
        Initialize analyzer
        
        Args:
            llm_manager: LLM manager instance
        """
        self.llm_manager = llm_manager or ForgeLLMManager()
        self._init_patterns()
        
    def _init_patterns(self):
        """Initialize pattern matchers"""
        # Domain detection patterns
        self.domain_patterns = {
            AgentDomain.DATA_ANALYSIS: [
                r'분석', r'데이터', r'통계', r'차트', r'그래프',
                r'analysis', r'data', r'statistics', r'chart', r'graph',
                r'visualization', r'pandas', r'numpy'
            ],
            AgentDomain.API: [
                r'api', r'rest', r'endpoint', r'서버', r'요청',
                r'request', r'response', r'http', r'webhook'
            ],
            AgentDomain.NLP: [
                r'자연어', r'텍스트', r'번역', r'감정',
                r'nlp', r'text', r'language', r'sentiment', r'translation'
            ],
            AgentDomain.ML: [
                r'머신러닝', r'딥러닝', r'학습', r'예측', r'모델',
                r'machine learning', r'deep learning', r'model', r'predict'
            ],
            AgentDomain.WEB_SCRAPING: [
                r'크롤링', r'스크래핑', r'웹.*수집',
                r'crawl', r'scrape', r'web.*extract'
            ],
            AgentDomain.DATABASE: [
                r'데이터베이스', r'db', r'sql', r'쿼리',
                r'database', r'query', r'table', r'mongodb'
            ],
            AgentDomain.AUTOMATION: [
                r'자동화', r'스케줄', r'반복', r'배치',
                r'automate', r'schedule', r'batch', r'cron'
            ]
        }
        
        # Complexity indicators
        self.complexity_indicators = {
            'simple': ['simple', 'basic', '간단', '기본', 'single'],
            'moderate': ['moderate', '중간', 'multiple', 'several'],
            'complex': ['complex', '복잡', 'advanced', 'sophisticated'],
            'advanced': ['learning', 'adaptive', '학습', '적응', 'intelligent']
        }
        
    async def analyze(self, query: str) -> QueryAnalysis:
        """
        Analyze user query comprehensively
        
        Args:
            query: User input query
            
        Returns:
            QueryAnalysis object with detailed analysis
        """
        logger.info(f"Analyzing query: {query}")
        
        # Step 1: Pattern-based initial analysis
        initial_analysis = self._pattern_analysis(query)
        
        # Step 2: LLM-powered deep analysis
        llm_analysis = await self._llm_analysis(query)
        
        # Step 3: Merge and validate analysis
        final_analysis = self._merge_analysis(initial_analysis, llm_analysis)
        
        # Step 4: Calculate confidence score
        final_analysis['confidence'] = self._calculate_confidence(final_analysis)
        
        # Create QueryAnalysis object
        return QueryAnalysis(
            query=query,
            intent=final_analysis.get('intent', ''),
            features=final_analysis.get('features', []),
            domain=self._determine_domain(final_analysis),
            complexity=self._determine_complexity(final_analysis),
            requirements=final_analysis.get('requirements', {}),
            suggested_name=final_analysis.get('suggested_name', 'CustomAgent'),
            description=final_analysis.get('description', query),
            keywords=final_analysis.get('keywords', []),
            entities=final_analysis.get('entities', {}),
            confidence=final_analysis.get('confidence', 0.5)
        )
        
    def _pattern_analysis(self, query: str) -> Dict[str, Any]:
        """
        Pattern-based query analysis
        
        Args:
            query: User query
            
        Returns:
            Initial analysis dictionary
        """
        analysis = {
            'domains': [],
            'keywords': [],
            'complexity_hints': []
        }
        
        # Extract keywords
        words = re.findall(r'\w+', query.lower())
        analysis['keywords'] = words
        
        # Domain detection
        for domain, patterns in self.domain_patterns.items():
            for pattern in patterns:
                if re.search(pattern, query.lower()):
                    analysis['domains'].append(domain.value)
                    break
                    
        # Complexity hints
        for level, indicators in self.complexity_indicators.items():
            for indicator in indicators:
                if indicator in query.lower():
                    analysis['complexity_hints'].append(level)
                    
        return analysis
        
    async def _llm_analysis(self, query: str) -> Dict[str, Any]:
        """
        LLM-powered deep analysis
        
        Args:
            query: User query
            
        Returns:
            LLM analysis dictionary
        """
        # Call LLM for analysis
        llm_result = await self.llm_manager.analyze_query(query)
        
        # Enhance with additional analysis
        if 'error' not in llm_result:
            # Extract entities
            entities = await self._extract_entities(query)
            llm_result['entities'] = entities
            
            # Identify technical requirements
            tech_reqs = await self._identify_technical_requirements(query, llm_result)
            llm_result['technical_requirements'] = tech_reqs
            
        return llm_result
        
    async def _extract_entities(self, query: str) -> Dict[str, Any]:
        """
        Extract entities from query
        
        Args:
            query: User query
            
        Returns:
            Entities dictionary
        """
        prompt = f"""Extract entities from this query:
{query}

Identify:
- Actions (verbs)
- Objects (nouns)
- Conditions
- Parameters

Return as JSON with these keys: actions, objects, conditions, parameters"""

        response = await self.llm_manager.generate(prompt, temperature=0.2)
        
        if response.success:
            try:
                return json.loads(response.content)
            except:
                return {}
        return {}
        
    async def _identify_technical_requirements(self, query: str, initial_analysis: Dict) -> Dict[str, Any]:
        """
        Identify technical requirements
        
        Args:
            query: User query
            initial_analysis: Initial analysis results
            
        Returns:
            Technical requirements dictionary
        """
        prompt = f"""Based on this query and analysis, identify technical requirements:

Query: {query}
Initial Analysis: {json.dumps(initial_analysis, indent=2)}

Identify:
1. Required Python packages
2. External APIs needed
3. Data formats
4. Performance requirements
5. Security considerations

Return as JSON."""

        response = await self.llm_manager.generate(prompt, temperature=0.3)
        
        if response.success:
            try:
                return json.loads(response.content)
            except:
                return {}
        return {}
        
    def _merge_analysis(self, pattern_analysis: Dict, llm_analysis: Dict) -> Dict[str, Any]:
        """
        Merge pattern and LLM analysis results
        
        Args:
            pattern_analysis: Pattern-based analysis
            llm_analysis: LLM-based analysis
            
        Returns:
            Merged analysis dictionary
        """
        merged = {
            'intent': llm_analysis.get('intent', ''),
            'features': llm_analysis.get('features', []),
            'requirements': llm_analysis.get('requirements', {}),
            'suggested_name': llm_analysis.get('suggested_name', 'CustomAgent'),
            'description': llm_analysis.get('description', ''),
            'keywords': list(set(
                pattern_analysis.get('keywords', []) + 
                llm_analysis.get('keywords', [])
            )),
            'entities': llm_analysis.get('entities', {}),
            'domains': pattern_analysis.get('domains', []),
            'complexity_hints': pattern_analysis.get('complexity_hints', []),
            'technical_requirements': llm_analysis.get('technical_requirements', {})
        }
        
        # Merge domain from LLM if available
        if 'domain' in llm_analysis:
            if llm_analysis['domain'] not in merged['domains']:
                merged['domains'].append(llm_analysis['domain'])
                
        # Merge complexity from LLM
        if 'complexity' in llm_analysis:
            merged['complexity_hints'].append(llm_analysis['complexity'])
            
        return merged
        
    def _determine_domain(self, analysis: Dict) -> AgentDomain:
        """
        Determine primary domain from analysis
        
        Args:
            analysis: Merged analysis
            
        Returns:
            AgentDomain enum
        """
        domains = analysis.get('domains', [])
        
        if domains:
            # Return first matched domain
            for domain in AgentDomain:
                if domain.value in domains:
                    return domain
                    
        # Check LLM suggested domain
        if 'domain' in analysis:
            for domain in AgentDomain:
                if domain.value == analysis['domain']:
                    return domain
                    
        return AgentDomain.GENERAL
        
    def _determine_complexity(self, analysis: Dict) -> ComplexityLevel:
        """
        Determine complexity level from analysis
        
        Args:
            analysis: Merged analysis
            
        Returns:
            ComplexityLevel enum
        """
        hints = analysis.get('complexity_hints', [])
        features = analysis.get('features', [])
        
        # Count features as complexity indicator
        feature_count = len(features)
        
        if 'advanced' in hints or feature_count > 10:
            return ComplexityLevel.ADVANCED
        elif 'complex' in hints or feature_count > 7:
            return ComplexityLevel.COMPLEX
        elif 'moderate' in hints or feature_count > 3:
            return ComplexityLevel.MODERATE
        else:
            return ComplexityLevel.SIMPLE
            
    def _calculate_confidence(self, analysis: Dict) -> float:
        """
        Calculate confidence score for analysis
        
        Args:
            analysis: Analysis dictionary
            
        Returns:
            Confidence score (0.0 - 1.0)
        """
        score = 0.0
        factors = 0
        
        # Check intent clarity
        if analysis.get('intent'):
            score += 0.2
            factors += 1
            
        # Check feature identification
        if len(analysis.get('features', [])) > 0:
            score += 0.2
            factors += 1
            
        # Check domain identification
        if analysis.get('domains'):
            score += 0.2
            factors += 1
            
        # Check requirements
        if analysis.get('requirements'):
            score += 0.2
            factors += 1
            
        # Check technical requirements
        if analysis.get('technical_requirements'):
            score += 0.2
            factors += 1
            
        return min(score, 1.0)
        
    def export_analysis(self, analysis: QueryAnalysis) -> Dict[str, Any]:
        """
        Export analysis as dictionary
        
        Args:
            analysis: QueryAnalysis object
            
        Returns:
            Dictionary representation
        """
        result = asdict(analysis)
        result['domain'] = analysis.domain.value
        result['complexity'] = analysis.complexity.value
        return result