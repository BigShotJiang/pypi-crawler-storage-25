"""
심플하고 명확한 프롬프트 시스템
Simple and clear prompt system
"""

class SimplePromptSystem:
    """더 간단하고 명확한 프롬프트"""
    
    def get_simple_prompt(self, intent: str, agent_name: str) -> str:
        """
        매우 간단한 프롬프트 생성
        
        핵심:
        1. 들여쓰기 명확히
        2. 짧고 간단한 예제
        3. 명확한 형식 지정
        """
        
        prompt = f"""Generate Python code for: {intent}

IMPORTANT: Generate ONLY the method body. Each line MUST start with exactly 8 spaces.

FORMAT:
--------# Comment
--------if not query:
------------return {{"success": False, "error": "Empty query"}}
--------
--------try:
------------# Your logic here
------------result = "processed"
------------return {{"success": True, "data": result}}
--------except Exception as e:
------------return {{"success": False, "error": str(e)}}

RULES:
- Replace -------- with 8 spaces (shown as dashes for clarity)
- Use double quotes for strings: "text"
- Dictionary keys are strings: {{"key": value}}
- f-strings use single braces: f"Hello {{name}}"

Now generate simple code for: {intent}
Output format - start every line with 8 spaces:"""
        
        return prompt
    
    def get_ultra_simple_prompt(self, intent: str) -> str:
        """초간단 프롬프트"""
        
        prompt = f"""Write Python method body for: {intent}

Start each line with 8 spaces. Example:

        try:
            result = "Hello World"
            return {{"success": True, "data": result}}
        except Exception as e:
            return {{"success": False, "error": str(e)}}

Now write similar code for: {intent}"""
        
        return prompt