"""
Enhanced Template Matcher Service v2.0
======================================
모든 템플릿을 활용하고 지능형 매칭을 제공하는 향상된 템플릿 매처
"""

import os
import json
import re
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from loguru import logger

# Template Analyzer import
from template_analyzer import TemplateAnalyzer

# LLM Dynamic Analyzer import
from llm_dynamic_analyzer import LLMDynamicAnalyzer

# LogosAI LLM Client import
try:
    from logosai.utils import LLMClient
except ImportError:
    logger.warning("LogosAI not available - using mock LLM")
    LLMClient = None


class EnhancedTemplateMatcher:
    """향상된 템플릿 매칭 서비스 v2.0"""
    
    def __init__(self, template_dir: str = None):
        """초기화"""
        self.template_dir = Path(template_dir or Path(__file__).parent.parent / "templates")
        
        # 템플릿 분석기로 모든 템플릿 메타데이터 로드
        self.analyzer = TemplateAnalyzer(str(self.template_dir))
        self.templates_metadata = self._load_all_templates()
        
        # LLM Dynamic Analyzer 초기화
        self.dynamic_analyzer = LLMDynamicAnalyzer()
        
        # LLM 클라이언트 초기화 (폴백용)
        if LLMClient:
            self.llm_client = LLMClient(
                provider="google",
                model="gemini-2.5-flash-lite",
                temperature=0.3
            )
        else:
            self.llm_client = None
        
        # 매칭 통계
        self.matching_stats = {
            'total_queries': 0,
            'successful_matches': 0,
            'template_usage': {},
            'llm_analysis_usage': 0,
            'fallback_usage': 0
        }
        
        logger.info(f"✨ EnhancedTemplateMatcher v3.2 initialized with {len(self.templates_metadata)} templates")
        logger.info(f"🧠 LLM Dynamic Analyzer integrated")
    
    def _load_all_templates(self) -> Dict[str, Dict]:
        """모든 템플릿 메타데이터 로드"""
        # 템플릿 분석기로 메타데이터 생성
        metadata = self.analyzer.analyze_all_templates()
        
        # 메타데이터 파일로 저장
        metadata_file = self.template_dir / 'template_metadata_full.json'
        if metadata_file.exists():
            # 기존 메타데이터와 병합
            with open(metadata_file, 'r', encoding='utf-8') as f:
                existing = json.load(f)
                metadata.update(existing)
        
        logger.info(f"📚 Loaded {len(metadata)} templates with full metadata")
        return metadata
    
    async def analyze_query_advanced(self, query: str) -> Dict[str, Any]:
        """고급 쿼리 분석 - LLM Dynamic Analyzer 사용"""
        try:
            # LLM Dynamic Analyzer로 종합 분석
            llm_analysis = await self.dynamic_analyzer.comprehensive_analyze(query)
            self.matching_stats['llm_analysis_usage'] += 1
            
            # Enhanced Template Matcher 형식으로 변환
            analysis = {
                'original_query': query,
                'intent': llm_analysis.get('intent', 'create'),
                'complexity': llm_analysis.get('complexity', 'medium'),
                'domain': llm_analysis.get('domain', 'general'),
                'required_capabilities': llm_analysis.get('required_capabilities', []),
                'preferred_framework': 'logosai',
                'needs_agentic': llm_analysis.get('needs_agentic', False),
                'urgency': 'normal',
                'language': 'ko' if any(ord(c) > 127 for c in query) else 'en',
                
                # LLM 분석 추가 정보
                'secondary_intents': llm_analysis.get('secondary_intents', []),
                'sub_domains': llm_analysis.get('sub_domains', []),
                'emerging_domain': llm_analysis.get('emerging_domain', ''),
                'technical_requirements': llm_analysis.get('technical_requirements', []),
                'integration_needs': llm_analysis.get('integration_needs', []),
                'agentic_features': llm_analysis.get('agentic_features', {}),
                'real_time_needs': llm_analysis.get('real_time_needs', False),
                'scalability_needs': llm_analysis.get('scalability_needs', 'low'),
                'security_requirements': llm_analysis.get('security_requirements', []),
                
                # 메타데이터
                'analysis_method': 'llm_dynamic',
                'analysis_confidence': llm_analysis.get('intent_confidence', 0.8),
                'analysis_duration': llm_analysis.get('analysis_duration', 0),
                
                # 원본 분석 결과 (디버깅용)
                '_llm_raw': llm_analysis
            }
            
            logger.info(f"🧠 LLM Dynamic Analysis completed: {analysis['intent']}/{analysis['domain']}")
            return analysis
            
        except Exception as e:
            logger.warning(f"LLM Dynamic Analysis failed: {e}, falling back to rule-based")
            self.matching_stats['fallback_usage'] += 1
            
            # 폴백: 기존 하드코딩 분석
            return await self._analyze_query_fallback(query)
    
    async def _analyze_query_fallback(self, query: str) -> Dict[str, Any]:
        """폴백: 기존 하드코딩 분석 방식"""
        analysis = {
            'original_query': query,
            'intent': self._detect_intent_fallback(query),
            'complexity': self._assess_complexity_fallback(query),
            'domain': self._detect_domain_fallback(query),
            'required_capabilities': [],
            'preferred_framework': 'logosai',
            'needs_agentic': False,
            'urgency': 'normal',
            'language': 'ko' if any(ord(c) > 127 for c in query) else 'en',
            'analysis_method': 'rule_based_fallback',
            'analysis_confidence': 0.5  # 낮은 신뢰도
        }
        
        # 키워드 기반 분석으로 보강
        keyword_analysis = self._keyword_based_analysis_fallback(query)
        
        # 병합
        for key, value in keyword_analysis.items():
            if key not in analysis or not analysis[key]:
                analysis[key] = value
        
        return analysis
    
    def _detect_intent_fallback(self, query: str) -> str:
        """사용자 의도 파악"""
        query_lower = query.lower()
        
        # 의도 패턴
        intent_patterns = {
            'create': ['만들', '생성', '개발', 'create', 'make', 'develop', 'build'],
            'analyze': ['분석', '조사', '파악', 'analyze', 'investigate', 'examine'],
            'automate': ['자동화', '자동', 'automate', 'automatic'],
            'integrate': ['통합', '연동', 'integrate', 'connect', 'api'],
            'monitor': ['모니터링', '감시', '추적', 'monitor', 'track', 'watch'],
            'predict': ['예측', '예보', '예상', 'predict', 'forecast', 'estimate'],
            'process': ['처리', '가공', '변환', 'process', 'transform', 'convert'],
            'learn': ['학습', '훈련', '개선', 'learn', 'train', 'improve']
        }
        
        for intent, keywords in intent_patterns.items():
            if any(kw in query_lower for kw in keywords):
                return intent
        
        return 'general'
    
    def _assess_complexity_fallback(self, query: str) -> str:
        """복잡도 평가 (폴백용)"""
        complexity_score = 0
        
        # 복잡도 지표
        if '자율' in query or 'autonomous' in query.lower():
            complexity_score += 3
        if '실시간' in query or 'real-time' in query.lower():
            complexity_score += 2
        if '머신러닝' in query or 'machine learning' in query.lower():
            complexity_score += 2
        if len(query) > 100:
            complexity_score += 1
        if '그리고' in query or 'and' in query.lower():
            complexity_score += 1
        
        if complexity_score >= 4:
            return 'high'
        elif complexity_score >= 2:
            return 'medium'
        else:
            return 'low'
    
    def _detect_domain_fallback(self, query: str) -> str:
        """도메인 감지"""
        query_lower = query.lower()
        
        domain_keywords = {
            'finance': ['금융', '주식', '투자', 'stock', 'finance', 'investment'],
            'data': ['데이터', 'data', '분석', 'analysis', '통계'],
            'web': ['웹', 'web', '크롤링', 'scraping', 'api'],
            'ai': ['ai', '머신러닝', 'machine learning', '딥러닝', '인공지능'],
            'document': ['문서', 'document', 'pdf', 'excel', '파일'],
            'communication': ['이메일', 'email', '메시지', 'message', '알림'],
            'monitoring': ['모니터링', 'monitoring', '대시보드', 'dashboard', 'kpi']
        }
        
        for domain, keywords in domain_keywords.items():
            if any(kw in query_lower for kw in keywords):
                return domain
        
        return 'general'
    
    def _keyword_based_analysis_fallback(self, query: str) -> Dict[str, Any]:
        """키워드 기반 분석"""
        query_lower = query.lower()
        
        capabilities = []
        
        # 기능 감지
        if any(word in query_lower for word in ['자율', 'autonomous', '스스로']):
            capabilities.append('autonomous_reasoning')
        if any(word in query_lower for word in ['학습', 'learn', '개선']):
            capabilities.append('continuous_learning')
        if any(word in query_lower for word in ['계획', 'plan', '전략']):
            capabilities.append('planning')
        if any(word in query_lower for word in ['메모리', 'memory', '기억']):
            capabilities.append('memory_management')
        if any(word in query_lower for word in ['실시간', 'real-time', '스트림']):
            capabilities.append('real_time')
        
        # Agentic AI 필요 여부
        needs_agentic = any(word in query_lower for word in [
            '지능형', '자율', '학습', '추론', 'intelligent', 
            'autonomous', 'learning', 'reasoning', 'agentic'
        ])
        
        return {
            'required_capabilities': capabilities,
            'needs_agentic': needs_agentic
        }
    
    async def _analyze_with_llm(self, query: str) -> Dict[str, Any]:
        """LLM을 사용한 심층 분석"""
        prompt = f"""
사용자의 AI 에이전트 생성 요청을 분석해주세요.

사용자 요청: {query}

다음 정보를 JSON 형식으로 추출해주세요:
{{
    "intent": "create|analyze|automate|integrate|monitor|predict|process|learn",
    "required_capabilities": ["capability1", "capability2"],
    "complexity": "low|medium|high",
    "needs_agentic": true/false,
    "suggested_template_category": "카테고리명"
}}

- intent: 사용자의 주요 의도
- required_capabilities: 필요한 기능들 (autonomous_reasoning, memory_management, tool_usage, continuous_learning, planning, reflection, real_time, data_analysis 등)
- complexity: 작업의 복잡도
- needs_agentic: Agentic AI (자율적 추론, 학습) 기능이 필요한지
- suggested_template_category: 추천 템플릿 카테고리
"""
        
        try:
            response = await self.llm_client.invoke(prompt)
            
            # Handle LLMResponse object properly
            response_text = getattr(response, 'content', str(response)) if hasattr(response, 'content') else str(response)
            
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except Exception as e:
            logger.error(f"LLM analysis error: {e}")
        
        return {}
    
    async def match_template_advanced(self, query: str, analysis: Dict[str, Any] = None) -> Tuple[str, float, Dict]:
        """고급 템플릿 매칭"""
        if not analysis:
            analysis = await self.analyze_query_advanced(query)
        
        # 각 템플릿에 대한 점수 계산
        scores = {}
        details = {}
        
        for template_id, template_meta in self.templates_metadata.items():
            score, match_details = self._calculate_template_score(
                query, analysis, template_id, template_meta
            )
            scores[template_id] = score
            details[template_id] = match_details
        
        # 최고 점수 템플릿 선택
        if not scores:
            # 폴백: 기본 템플릿
            return 'ultra_simple_agent', 0.5, {'reason': 'No matching templates, using default'}
        
        # 상위 3개 템플릿
        top_templates = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:3]
        
        # 최종 선택
        best_template, best_score = top_templates[0]
        
        # 통계 업데이트
        self.matching_stats['total_queries'] += 1
        if best_score > 0.3:
            self.matching_stats['successful_matches'] += 1
        self.matching_stats['template_usage'][best_template] = \
            self.matching_stats['template_usage'].get(best_template, 0) + 1
        
        logger.info(f"🎯 Template Matching Results:")
        logger.info(f"  Query: {query[:50]}...")
        logger.info(f"  Analysis: intent={analysis.get('intent')}, complexity={analysis.get('complexity')}")
        logger.info(f"  Top 3 matches:")
        for tmpl, score in top_templates:
            logger.info(f"    - {tmpl}: {score:.3f}")
        
        return best_template, best_score, details[best_template]
    
    async def find_best_template(self, query: str, analysis: Dict[str, Any] = None) -> Dict[str, Any]:
        """최적 템플릿 찾기 - 통합 인터페이스"""
        try:
            template_name, confidence, details = await self.match_template_advanced(query, analysis)
            
            # 템플릿 메타데이터 가져오기
            template_meta = self.templates_metadata.get(template_name, {})
            
            return {
                'template_name': template_name,
                'confidence': confidence,
                'template_type': template_meta.get('template_type', 'general'),
                'capabilities': template_meta.get('capabilities', []),
                'category': template_meta.get('category', 'general'),
                'match_details': details,
                'template_path': self.template_dir / f"{template_name}.json"
            }
            
        except Exception as e:
            logger.error(f"Template matching error: {e}")
            return {
                'template_name': 'No match',
                'confidence': 0.0,
                'template_type': 'unknown',
                'capabilities': [],
                'category': 'general',
                'match_details': {'error': str(e)},
                'template_path': None
            }
    
    def _calculate_template_score(self, query: str, analysis: Dict[str, Any], 
                                 template_id: str, template_meta: Dict) -> Tuple[float, Dict]:
        """향상된 템플릿 점수 계산"""
        score = 0.0
        match_details = {
            'keyword_matches': 0,
            'capability_matches': 0,
            'category_match': False,
            'intent_match': False,
            'semantic_matches': 0,
            'priority_bonus': 0,
            'agentic_match': False,
            'template_type_bonus': 0
        }
        
        query_lower = query.lower()
        
        # 1. 향상된 키워드 매칭 (25%)
        keywords = template_meta.get('keywords', [])
        keyword_score = 0
        keyword_count = 0
        
        for kw in keywords:
            kw_lower = kw.lower()
            if kw_lower in query_lower:
                keyword_count += 1
                # 가중치: 긴 키워드가 더 중요
                weight = max(1.0, len(kw) / 5.0)
                keyword_score += 0.04 * weight
        
        # 동의어 매칭
        synonym_matches = self._check_synonym_matches(query_lower, keywords)
        keyword_score += synonym_matches * 0.02
        
        match_details['keyword_matches'] = keyword_count
        match_details['semantic_matches'] = synonym_matches
        score += min(keyword_score, 0.25)
        
        # 2. 의도 매칭 (20%) - 새로 추가
        template_intent = template_meta.get('intent', '')
        query_intent = analysis.get('intent', '')
        if template_intent and query_intent:
            if template_intent.lower() == query_intent.lower():
                match_details['intent_match'] = True
                score += 0.2
            elif self._are_related_intents(template_intent, query_intent):
                score += 0.1  # 부분 점수
        
        # 3. 향상된 기능 매칭 (25%)
        required_caps = set(analysis.get('required_capabilities', []))
        template_caps = set(template_meta.get('capabilities', []))
        
        if required_caps:
            # 직접 매칭
            direct_matches = len(required_caps & template_caps)
            capability_overlap = direct_matches / len(required_caps)
            
            # 간접 매칭 (유사 기능)
            indirect_matches = self._count_indirect_capability_matches(required_caps, template_caps)
            indirect_overlap = indirect_matches / len(required_caps) * 0.5  # 50% 가중치
            
            total_capability_score = (capability_overlap + indirect_overlap) * 0.25
            match_details['capability_matches'] = direct_matches + indirect_matches
            score += min(total_capability_score, 0.25)
        elif template_caps:
            # 범용 템플릿 보너스
            score += 0.05
        
        # 4. 향상된 카테고리/도메인 매칭 (15%)
        category_score = 0
        query_domain = analysis.get('domain', '')
        template_category = template_meta.get('category', '')
        
        if query_domain and template_category:
            # 직접 매칭
            if query_domain.lower() in template_category.lower() or template_category.lower() in query_domain.lower():
                match_details['category_match'] = True
                category_score = 0.15
            # 관련 도메인 매칭
            elif self._are_related_domains(query_domain, template_category):
                category_score = 0.08
        elif template_category.lower() == 'general' or query_domain == 'general':
            category_score = 0.03  # 범용 템플릿 보너스
        
        score += category_score
        
        # 5. 유연한 복잡도 매칭 (10%)
        template_difficulty = template_meta.get('difficulty', 'intermediate')
        query_complexity = analysis.get('complexity', 'medium')
        
        complexity_score = self._calculate_complexity_score(query_complexity, template_difficulty)
        score += complexity_score * 0.1
        
        # 6. 템플릿 타입 우선순위 (10%)
        template_type_score = self._calculate_template_type_score(template_meta, analysis)
        match_details['template_type_bonus'] = template_type_score
        score += template_type_score * 0.1
        
        # 7. Agentic AI 매칭 (10%)
        if analysis.get('needs_agentic') and template_meta.get('has_agentic'):
            match_details['agentic_match'] = True
            score += 0.1
        elif not analysis.get('needs_agentic') and not template_meta.get('has_agentic'):
            score += 0.03  # 일치하지 않아도 작은 보너스
        
        # 8. 우선순위 보너스 (5%)
        priority = template_meta.get('priority', 5)
        priority_bonus = min((priority / 10) * 0.05, 0.05)
        match_details['priority_bonus'] = priority_bonus
        score += priority_bonus
        
        # 정규화 및 최소 점수 보장
        score = min(score, 1.0)
        
        # LogosAI 프레임워크 템플릿에 약간의 보너스
        if template_meta.get('framework') == 'logosai':
            score = min(score + 0.02, 1.0)
        
        return score, match_details
    
    def _check_synonym_matches(self, query: str, keywords: List[str]) -> int:
        """동의어 매칭 확인"""
        synonym_map = {
            # 기술 관련
            'ai': ['인공지능', 'artificial intelligence', '머신러닝', 'machine learning'],
            'data': ['데이터', '정보', 'information'],
            'analysis': ['분석', '해석', 'interpret', '조사'],
            'automation': ['자동화', '자동', 'automatic'],
            'monitoring': ['모니터링', '감시', 'surveillance', '추적'],
            
            # 도메인 관련
            'finance': ['금융', '재정', 'financial', '투자'],
            'healthcare': ['의료', '건강', 'medical', 'health'],
            'education': ['교육', '학습', 'learning', '훈련'],
            'security': ['보안', '안전', 'safety', '방어'],
            
            # 의도 관련
            'create': ['생성', '만들', 'generate', 'build', '구축'],
            'analyze': ['분석', '조사', 'examine', 'investigate'],
            'integrate': ['통합', '연동', 'connect', '결합'],
            'process': ['처리', '가공', 'transform', '변환']
        }
        
        matches = 0
        query_lower = query.lower()
        
        for keyword in keywords:
            kw_lower = keyword.lower()
            if kw_lower in synonym_map:
                synonyms = synonym_map[kw_lower]
                if any(syn in query_lower for syn in synonyms):
                    matches += 1
            
            # 역방향 확인
            for key, synonyms in synonym_map.items():
                if kw_lower in synonyms and key in query_lower:
                    matches += 1
                    break
        
        return matches
    
    def _are_related_intents(self, intent1: str, intent2: str) -> bool:
        """관련 의도 확인"""
        related_intents = {
            'create': ['generate', 'build', 'develop'],
            'analyze': ['examine', 'investigate', 'study'],
            'automate': ['process', 'optimize'],
            'integrate': ['connect', 'combine', 'merge'],
            'monitor': ['track', 'watch', 'observe']
        }
        
        intent1_lower = intent1.lower()
        intent2_lower = intent2.lower()
        
        # 직접 관련성 확인
        if intent1_lower in related_intents.get(intent2_lower, []):
            return True
        if intent2_lower in related_intents.get(intent1_lower, []):
            return True
        
        return False
    
    def _count_indirect_capability_matches(self, required_caps: set, template_caps: set) -> int:
        """간접 기능 매칭 계산"""
        capability_groups = {
            'ai_features': {'autonomous_reasoning', 'machine_learning', 'ai_powered', 'intelligent'},
            'data_handling': {'data_analysis', 'data_processing', 'analytics', 'statistics'},
            'real_time': {'real_time', 'streaming', 'live_data', 'continuous'},
            'integration': {'api_integration', 'external_apis', 'webhook', 'connectivity'},
            'automation': {'task_automation', 'workflow', 'scheduling', 'batch_processing'},
            'memory': {'memory_management', 'caching', 'persistence', 'state_management'}
        }
        
        matches = 0
        
        for group_caps in capability_groups.values():
            required_in_group = required_caps & group_caps
            template_in_group = template_caps & group_caps
            
            if required_in_group and template_in_group:
                # 같은 그룹 내에서 일부라도 매칭되면 카운트
                matches += min(len(required_in_group), len(template_in_group))
        
        return matches
    
    def _are_related_domains(self, domain1: str, domain2: str) -> bool:
        """관련 도메인 확인"""
        domain_relations = {
            'finance': ['business', 'economics', 'trading'],
            'healthcare': ['medical', 'wellness', 'pharmacy'],
            'education': ['training', 'academic', 'learning'],
            'technology': ['ai', 'software', 'development'],
            'security': ['safety', 'privacy', 'protection'],
            'communication': ['social', 'messaging', 'notification']
        }
        
        domain1_lower = domain1.lower()
        domain2_lower = domain2.lower()
        
        # 직접 관련성 확인
        if domain1_lower in domain_relations.get(domain2_lower, []):
            return True
        if domain2_lower in domain_relations.get(domain1_lower, []):
            return True
        
        return False
    
    def _calculate_complexity_score(self, query_complexity: str, template_difficulty: str) -> float:
        """복잡도 매칭 점수 계산"""
        # 복잡도 레벨 매핑
        complexity_levels = {'low': 1, 'medium': 2, 'high': 3}
        difficulty_levels = {'beginner': 1, 'intermediate': 2, 'advanced': 3}
        
        query_level = complexity_levels.get(query_complexity, 2)
        template_level = difficulty_levels.get(template_difficulty, 2)
        
        # 정확히 일치하면 1.0
        if query_level == template_level:
            return 1.0
        
        # 1단계 차이면 0.6
        if abs(query_level - template_level) == 1:
            return 0.6
        
        # 2단계 차이면 0.2
        return 0.2
    
    def _calculate_template_type_score(self, template_meta: Dict, analysis: Dict[str, Any]) -> float:
        """템플릿 타입별 우선순위 점수"""
        score = 0.0
        
        # Agentic 템플릿 우선순위
        if template_meta.get('has_agentic'):
            if analysis.get('needs_agentic'):
                score += 0.5
            else:
                score += 0.2  # Agentic 템플릿은 일반적으로 더 강력함
        
        # Strategic 템플릿 보너스
        if 'strategic' in template_meta.get('path', '').lower():
            score += 0.3
        
        # 최신 템플릿 우선
        if template_meta.get('version', '1.0.0').startswith('2.'):
            score += 0.2
        
        return min(score, 1.0)
    
    def load_template(self, template_id: str) -> str:
        """템플릿 파일 로드"""
        template_meta = self.templates_metadata.get(template_id)
        if not template_meta:
            raise ValueError(f"Template not found: {template_id}")
        
        template_path = self.template_dir / template_meta['path']
        if not template_path.exists():
            raise FileNotFoundError(f"Template file not found: {template_path}")
        
        with open(template_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    async def generate_agent_with_template(self, query: str, template_id: str = None) -> Dict[str, Any]:
        """템플릿 기반 에이전트 생성"""
        # 분석
        analysis = await self.analyze_query_advanced(query)
        
        # 템플릿 선택
        if not template_id:
            template_id, confidence, match_details = await self.match_template_advanced(query, analysis)
        else:
            confidence = 1.0
            match_details = {'manual_selection': True}
        
        # 템플릿 로드
        template_content = self.load_template(template_id)
        
        # 변수 채우기
        agent_code = await self._fill_template_advanced(
            template_content,
            query,
            analysis,
            template_id
        )
        
        return {
            'success': True,
            'template_used': template_id,
            'confidence': confidence,
            'agent_code': agent_code,
            'analysis': analysis,
            'match_details': match_details,
            'metadata': self.templates_metadata[template_id]
        }
    
    async def _fill_template_advanced(self, template: str, query: str,
                                     analysis: Dict[str, Any], template_id: str) -> str:
        """고급 템플릿 변수 채우기"""
        # 에이전트 이름 생성
        agent_name = self._generate_agent_name(query, analysis)
        agent_class = self._generate_class_name(agent_name)
        
        # 비즈니스 로직 생성
        if self.llm_client:
            business_logic = await self._generate_business_logic_with_llm(
                query, analysis, template_id
            )
        else:
            business_logic = self._generate_business_logic_fallback(
                query, analysis, template_id
            )
        
        # 템플릿 변수 매핑
        replacements = {
            'agent_name': agent_name,
            'agent_class_name': agent_class,
            'agent_description': f"{analysis.get('intent', 'general')} agent for {analysis.get('domain', 'general')} domain",
            'business_logic': business_logic,
            'custom_config': self._generate_custom_config(analysis),
            'custom_init': '# Custom initialization',
            'tool_implementation': '# Tool implementation'
        }
        
        # 변수 치환
        result = template
        for key, value in replacements.items():
            # {{key}} 또는 {key} 패턴 모두 처리
            result = result.replace(f'{{{{{key}}}}}', value)
            result = result.replace(f'{{{key}}}', value)
        
        return result
    
    def _generate_agent_name(self, query: str, analysis: Dict[str, Any]) -> str:
        """에이전트 이름 생성"""
        intent = analysis.get('intent', 'general')
        domain = analysis.get('domain', 'general')
        
        # 의도와 도메인 기반 이름 생성
        name_parts = []
        
        if domain != 'general':
            name_parts.append(domain.title())
        
        intent_names = {
            'create': 'Creator',
            'analyze': 'Analyzer',
            'automate': 'Automator',
            'integrate': 'Integrator',
            'monitor': 'Monitor',
            'predict': 'Predictor',
            'process': 'Processor',
            'learn': 'Learner'
        }
        
        name_parts.append(intent_names.get(intent, 'Agent'))
        
        return ' '.join(name_parts)
    
    def _generate_class_name(self, agent_name: str) -> str:
        """클래스명 생성"""
        # 공백을 제거하고 CamelCase로 변환
        parts = agent_name.split()
        class_name = ''.join(part.title() for part in parts)
        if not class_name.endswith('Agent'):
            class_name += 'Agent'
        return class_name
    
    async def _generate_business_logic_with_llm(self, query: str, 
                                               analysis: Dict[str, Any],
                                               template_id: str) -> str:
        """LLM으로 비즈니스 로직 생성"""
        prompt = f"""
Generate Python business logic for an AI agent based on this request:
{query}

Context:
- Intent: {analysis.get('intent')}
- Domain: {analysis.get('domain')}
- Complexity: {analysis.get('complexity')}
- Required capabilities: {analysis.get('required_capabilities')}

Generate clean Python code for the core business logic.
Focus on the main processing logic without imports or class definitions.
"""
        
        try:
            response = await self.llm_client.invoke(prompt)
            
            # Handle LLMResponse object properly
            logic = getattr(response, 'content', str(response)) if hasattr(response, 'content') else str(response)
            
            # 코드 블록 추출
            if '```python' in logic:
                logic = logic.split('```python')[1].split('```')[0]
            elif '```' in logic:
                logic = logic.split('```')[1].split('```')[0]
            return logic.strip()
        except Exception as e:
            logger.error(f"LLM generation failed: {e}")
            return self._generate_business_logic_fallback(query, analysis, template_id)
    
    def _generate_business_logic_fallback(self, query: str, 
                                         analysis: Dict[str, Any],
                                         template_id: str) -> str:
        """폴백 비즈니스 로직 생성"""
        intent = analysis.get('intent', 'general')
        
        logic_templates = {
            'analyze': """
        # Analyze data
        results = {
            'analysis_type': 'comprehensive',
            'data_points': len(data) if 'data' in locals() else 0,
            'insights': []
        }
        
        # Perform analysis
        if extracted_info:
            for key, value in extracted_info.items():
                insight = f"Found {key}: {value}"
                results['insights'].append(insight)
        
        return results
""",
            'automate': """
        # Automation logic
        tasks = extracted_info.get('tasks', [])
        completed = []
        
        for task in tasks:
            # Execute task
            result = await self.execute_task(task)
            completed.append({
                'task': task,
                'status': 'completed',
                'result': result
            })
        
        return {'completed_tasks': completed}
""",
            'default': """
        # Process request
        result = {
            'status': 'success',
            'data': extracted_info
        }
        
        # Additional processing
        if 'query' in extracted_info:
            result['processed_query'] = extracted_info['query']
        
        return result
"""
        }
        
        return logic_templates.get(intent, logic_templates['default'])
    
    def _generate_custom_config(self, analysis: Dict[str, Any]) -> str:
        """커스텀 설정 생성"""
        config = {}
        
        # 복잡도에 따른 설정
        if analysis.get('complexity') == 'high':
            config['max_retries'] = 5
            config['timeout'] = 300
        elif analysis.get('complexity') == 'low':
            config['max_retries'] = 2
            config['timeout'] = 60
        
        # Agentic 기능 설정
        if analysis.get('needs_agentic'):
            config['enable_agentic'] = True
            config['memory_capacity'] = 100
            config['learning_rate'] = 0.1
        
        if not config:
            return ''
        
        # Dict를 문자열로 변환
        config_str = json.dumps(config, indent=8)[1:-1]  # Remove outer braces
        return ',\n' + config_str if config_str else ''
    
    def get_statistics(self) -> Dict[str, Any]:
        """매칭 통계 반환"""
        total_analyses = self.matching_stats['llm_analysis_usage'] + self.matching_stats['fallback_usage']
        
        stats = {
            'total_templates': len(self.templates_metadata),
            'total_queries': self.matching_stats['total_queries'],
            'success_rate': (
                self.matching_stats['successful_matches'] / 
                max(self.matching_stats['total_queries'], 1)
            ),
            'most_used_templates': sorted(
                self.matching_stats['template_usage'].items(),
                key=lambda x: x[1],
                reverse=True
            )[:5],
            
            # LLM Dynamic Analyzer 통계
            'analysis_methods': {
                'llm_dynamic_usage': self.matching_stats['llm_analysis_usage'],
                'rule_based_fallback': self.matching_stats['fallback_usage'],
                'llm_success_rate': (
                    self.matching_stats['llm_analysis_usage'] / 
                    max(total_analyses, 1)
                ),
                'total_analyses': total_analyses
            }
        }
        
        # LLM Dynamic Analyzer 자체 통계도 포함
        if hasattr(self, 'dynamic_analyzer'):
            llm_stats = self.dynamic_analyzer.get_statistics()
            stats['llm_analyzer_stats'] = llm_stats
        
        return stats


async def test_enhanced_matcher():
    """향상된 매처 테스트 v3.2 - LLM Dynamic Analyzer 통합"""
    matcher = EnhancedTemplateMatcher()
    
    # 다양한 테스트 쿼리 (더 복잡하고 트렌드 반영)
    test_queries = [
        "지능형 자율 에이전트를 만들어줘. 스스로 학습하고 개선할 수 있어야 해.",
        "실시간 암호화폐 거래 패턴 분석하고 자동 매매 신호 생성",
        "메타버스 내 사용자 행동 데이터를 수집하고 개인화 추천 시스템",
        "NFT 마켓플레이스 거래량과 가격 트렌드를 모니터링하는 봇",
        "ESG 관련 뉴스를 실시간으로 수집하고 기업별 리스크 스코어 계산",
        "ChatGPT와 연동해서 고객 문의에 자동 응답하는 시스템",
        "블록체인 DeFi 프로토콜의 수익률과 리스크를 분석하는 에이전트"
    ]
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n{'='*80}")
        print(f"🧪 Test {i}: {query}")
        print('='*80)
        
        # 분석
        analysis = await matcher.analyze_query_advanced(query)
        print(f"\n🧠 LLM Analysis Results:")
        print(f"  - Method: {analysis.get('analysis_method', 'unknown')}")
        print(f"  - Intent: {analysis.get('intent')} (confidence: {analysis.get('analysis_confidence', 0):.2f})")
        print(f"  - Domain: {analysis.get('domain')}")
        print(f"  - Complexity: {analysis.get('complexity')}")
        print(f"  - Agentic Features: {analysis.get('needs_agentic')}")
        
        if analysis.get('emerging_domain'):
            print(f"  - 🆕 Emerging Domain: {analysis.get('emerging_domain')}")
        
        if analysis.get('secondary_intents'):
            print(f"  - Secondary Intents: {', '.join(analysis.get('secondary_intents'))}")
        
        # 매칭
        template_id, confidence, details = await matcher.match_template_advanced(query)
        print(f"\n🎯 Template Matching:")
        print(f"  - Selected Template: {template_id}")
        print(f"  - Confidence: {confidence:.2%}")
        print(f"  - Match Details: {dict(list(details.items())[:3])}")  # 상위 3개만 표시
    
    # 통계 출력
    print(f"\n{'='*80}")
    print("📊 Comprehensive Statistics")
    print('='*80)
    
    stats = matcher.get_statistics()
    print(f"Template System:")
    print(f"  - Total Templates: {stats['total_templates']}")
    print(f"  - Total Queries: {stats['total_queries']}")
    print(f"  - Overall Success Rate: {stats['success_rate']:.1%}")
    
    analysis_methods = stats.get('analysis_methods', {})
    print(f"\nAnalysis Methods:")
    print(f"  - LLM Dynamic Usage: {analysis_methods.get('llm_dynamic_usage', 0)}")
    print(f"  - Rule-based Fallback: {analysis_methods.get('rule_based_fallback', 0)}")
    print(f"  - LLM Success Rate: {analysis_methods.get('llm_success_rate', 0):.1%}")
    
    llm_stats = stats.get('llm_analyzer_stats', {})
    if llm_stats:
        cache_perf = llm_stats.get('cache_performance', {})
        print(f"\nLLM Analyzer Performance:")
        print(f"  - Total Analyses: {llm_stats.get('total_analyses', 0)}")
        print(f"  - Cache Hit Rate: {cache_perf.get('hit_rate', 0):.1%}")
        print(f"  - Avg Analysis Time: {llm_stats.get('avg_analysis_time', 0):.2f}s")
        print(f"  - Domain Distribution: {llm_stats.get('domain_distribution', {})}")


if __name__ == "__main__":
    asyncio.run(test_enhanced_matcher())