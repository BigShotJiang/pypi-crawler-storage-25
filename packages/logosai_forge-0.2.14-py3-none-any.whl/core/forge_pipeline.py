"""
FORGE AI Pipeline Integration
Orchestrates all components of the agent generation pipeline
"""

import asyncio
import json
import sqlite3
import re
import os
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime
from pathlib import Path
import uuid

from .query_analyzer import QueryAnalyzer, QueryAnalysis
from .business_logic_extractor import BusinessLogicExtractor, BusinessDomain
from .component_extractor import ComponentExtractor
from .intelligent_data_generator import IntelligentDataGenerator
from .sandbox_executor import SandboxExecutor, SecurityLevel
from .streaming_executor import StreamingExecutor, ExecutionContext, ExecutionMode, StreamEvent
from .learning_system import LearningSystem
from .simplified_code_generator import SimplifiedCodeGenerator
from .progressive_code_generator import ProgressiveCodeGenerator
from .simple_single_pass_generator import SimpleSinglePassGenerator
from .enhanced_smart_template_generator import EnhancedSmartTemplateGenerator
from .llm_orchestrator import LLMOrchestrator
from .db_template_manager import DBTemplateManager
from .final_forge_system import FinalForgeSystem, ForgeRequest, ForgeResult
from .final_forge_system_llm import FinalForgeSystemLLM

from loguru import logger

# Import sanitize function
import sys
sys.path.append(str(Path(__file__).parent.parent / "prototype" / "backend"))
try:
    from app.core.utils import sanitize_agent_name
except ImportError:
    # Fallback if import fails
    def sanitize_agent_name(name: str, max_length: int = 50) -> str:
        import re
        if not name or not isinstance(name, str):
            return "GeneratedAgent"
        name = re.sub(r'[Aa]gent$', '', name.strip())
        words = re.split(r'[^a-zA-Z0-9]+', name)
        words = [word.capitalize() for word in words if word]
        cleaned_name = ''.join(words)
        if not cleaned_name:
            return "GeneratedAgent"
        cleaned_name = cleaned_name[0].upper() + cleaned_name[1:] if len(cleaned_name) > 1 else cleaned_name.upper()
        if not cleaned_name.endswith('Agent'):
            cleaned_name += 'Agent'
        if len(cleaned_name) > max_length:
            cleaned_name = cleaned_name[:max_length-5] + 'Agent'
        return cleaned_name


class ForgePipeline:
    """Main pipeline for FORGE AI agent generation"""
    
    def __init__(self, 
                 db_path: str = "forge_agents.db",
                 llm_config_path: Optional[str] = None):
        """Initialize pipeline with all components"""
        
        self.db_path = db_path
        self.db_conn = sqlite3.connect(db_path)
        
        # Initialize components
        # Load config if path provided
        config = {}
        if llm_config_path and Path(llm_config_path).exists():
            import yaml
            with open(llm_config_path, 'r') as f:
                config = yaml.safe_load(f)
        
        self.llm = LLMOrchestrator(config=config)
        
        # Initialize template manager with database path
        # Pass the correct DB path for the backend
        backend_db_path = str(Path(__file__).parent.parent / "prototype" / "backend" / "forge_agents.db")
        self.template_manager = DBTemplateManager(db_path=backend_db_path, llm_orchestrator=self.llm)
        
        self.query_analyzer = QueryAnalyzer(self.llm)
        self.business_logic_extractor = BusinessLogicExtractor()
        
        # Use LLM-based FinalForgeSystem if API key is available
        # Temporarily use template-based for testing
        use_llm_forge = False  # bool(os.getenv('GOOGLE_API_KEY'))
        if use_llm_forge:
            logger.info("🚀 Using LLM-based FinalForgeSystem")
            self.forge_system = FinalForgeSystemLLM()
        else:
            logger.info("📋 Using template-based FinalForgeSystem")
            self.forge_system = FinalForgeSystem()
        
        # Keep legacy generator as fallback
        self.code_generator = EnhancedSmartTemplateGenerator(self.llm, SandboxExecutor(SecurityLevel.MEDIUM))
        self.component_extractor = ComponentExtractor()
        self.data_generator = IntelligentDataGenerator()
        self.sandbox_executor = SandboxExecutor(SecurityLevel.MEDIUM)
        self.streaming_executor = StreamingExecutor(self.llm)
        self.learning_system = LearningSystem(db_path)
        
        # Pipeline state
        self.current_generation_id = None
        self.stream_callback = None
        
    async def generate_agent(self,
                           query: str,
                           user_email: str,
                           stream_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """Main entry point for agent generation"""
        
        self.current_generation_id = str(uuid.uuid4())[:8]
        self.stream_callback = stream_callback
        
        logger.info(f"🚀 Starting agent generation - ID: {self.current_generation_id}")
        logger.info(f"📝 Query: {query[:100]}...")
        logger.info(f"👤 User: {user_email}")
        
        generation_log = {
            'id': self.current_generation_id,
            'query': query,
            'user_email': user_email,
            'started_at': datetime.now().isoformat(),
            'phases': {}
        }
        
        try:
            # Phase 1: Query Analysis
            logger.info(f"[{self.current_generation_id}] Phase 1: Starting query analysis")
            await self._update_status("analyzing", "🔍 Analyzing your request...")
            
            analysis_start = datetime.now()
            analysis = await self._analyze_query(query)
            analysis_time = (datetime.now() - analysis_start).total_seconds()
            
            logger.info(f"[{self.current_generation_id}] Query analysis completed in {analysis_time:.2f}s")
            logger.info(f"[{self.current_generation_id}] - Intent: {analysis.intent}")
            logger.info(f"[{self.current_generation_id}] - Domain: {analysis.domain}")
            logger.info(f"[{self.current_generation_id}] - Complexity: {analysis.complexity}")
            logger.info(f"[{self.current_generation_id}] - Required capabilities: {analysis.required_capabilities}")
            
            generation_log['phases']['analysis'] = {
                'status': 'completed',
                'result': analysis.to_dict(),
                'duration_seconds': analysis_time
            }
            
            # Phase 2: Get Learning Recommendations
            recommendations = self.learning_system.get_recommendations({
                'query_type': analysis.intent,
                'domain': analysis.domain,
                'llm_model': 'gemini-2.5-pro'
            })
            
            # Phase 3: Search for Components
            await self._update_status("searching", "🔎 Searching for reusable components...")
            components = await self._search_components(analysis)
            generation_log['phases']['component_search'] = {
                'status': 'completed',
                'components_found': len(components)
            }
            
            # Phase 4: Extract Business Logic
            await self._update_status("extracting", "💡 Extracting business logic...")
            business_logic = self.business_logic_extractor.extract_business_logic(
                query, 
                {'domain': analysis.domain}
            )
            generation_log['phases']['business_logic'] = {
                'status': 'completed',
                'result': business_logic.to_dict()
            }
            
            # Phase 5: Generate Code using FinalForgeSystem
            logger.info(f"[{self.current_generation_id}] Phase 5: Starting code generation with FinalForgeSystem")
            
            await self._update_status("generating", "🚀 Generating agent code with advanced AI...")
            
            gen_start = datetime.now()
            
            # Create ForgeRequest - Use LogosAI framework
            forge_request = ForgeRequest(
                query=query,
                user_email=user_email,
                session_id=self.current_generation_id,
                output_type="logosai",  # Changed to LogosAI framework
                enable_testing=True,
                save_to_file=False  # We'll save it ourselves
            )
            
            # Generate using FinalForgeSystem
            forge_result = await self.forge_system.create_agent(forge_request)
            
            gen_time = (datetime.now() - gen_start).total_seconds()
            
            # Initialize variables for later use
            forge_success = forge_result.success if forge_result else False
            
            if not forge_success:
                # Fallback to legacy generator
                logger.warning(f"[{self.current_generation_id}] FinalForgeSystem failed, using fallback generator")
                generated_code = await self.code_generator.generate_progressively(
                    analysis,
                    context={'components': components, 'business_logic': business_logic},
                    stream_callback=self.stream_callback
                )
            else:
                # Create a compatible object
                class GeneratedCode:
                    def __init__(self, code, template_used="final_forge_system"):
                        self.code = code
                        self.template_used = template_used
                
                generated_code = GeneratedCode(forge_result.agent_code)
                logger.info(f"[{self.current_generation_id}] ✅ FinalForgeSystem generation successful")
            
            logger.info(f"[{self.current_generation_id}] Code generation completed in {gen_time:.2f}s")
            logger.info(f"[{self.current_generation_id}] - Generated code length: {len(generated_code.code)} chars")
            logger.info(f"[{self.current_generation_id}] - Template used: {getattr(generated_code, 'template_used', 'unknown')}")
            
            # Verify no backticks in generated code (should not happen with JSON)
            backtick_count = generated_code.code.count('```')
            if backtick_count > 0:
                logger.error(f"[{self.current_generation_id}] ❌ Unexpected: Generated code contains {backtick_count} backtick patterns!")
                logger.error(f"[{self.current_generation_id}] This should not happen with JSON-based generation.")
            else:
                logger.info(f"[{self.current_generation_id}] ✅ Clean code generation confirmed")
            
            generation_log['phases']['code_generation'] = {
                'status': 'completed',
                'code_length': len(generated_code.code),
                'duration_seconds': gen_time,
                'template_used': getattr(generated_code, 'template_used', 'unknown')
            }
            
            # Phase 6: Generate Test Data
            await self._update_status("preparing_data", "📊 Generating test data...")
            
            # Use test data from FinalForgeSystem if available
            if forge_success and forge_result and forge_result.test_results:
                # Use the test data from FinalForgeSystem
                test_data = type('TestData', (), {
                    'minimal': forge_result.test_results.get('test_input', {}),
                    'comprehensive': forge_result.test_results.get('test_input', {})
                })()
                logger.info(f"[{self.current_generation_id}] Using test data from FinalForgeSystem")
            else:
                # Generate test data normally
                requirements = self.data_generator.analyze_code_requirements(generated_code.code)
                test_data = self.data_generator.generate_test_data(
                    requirements, 
                    domain=analysis.domain or 'general'
                )
            
            generation_log['phases']['test_data'] = {
                'status': 'completed',
                'data_generated': True
            }
            
            # Phase 7: Execute and Validate with Streaming
            await self._update_status("validating", "🧪 Testing generated agent...")
            
            # Use streaming executor if requested
            use_streaming = self.stream_callback is not None
            
            if use_streaming:
                # Create streaming context
                async def execution_stream_callback(event: StreamEvent):
                    # Forward execution events to main stream callback
                    await self._update_status(
                        "validating",
                        f"Execution: {event.data.get('message', event.data.get('line', ''))}",
                        {"execution_event": event.to_dict()}
                    )
                
                exec_context = ExecutionContext(
                    code=generated_code.code,
                    input_data=test_data.minimal,
                    mode=ExecutionMode.QUICK_TEST,
                    timeout=30,
                    stream_callback=execution_stream_callback
                )
                
                streaming_result = await self.streaming_executor.execute(exec_context)
                
                # Convert to standard ExecutionResult format
                from .sandbox_executor import ExecutionResult
                execution_result = ExecutionResult(
                    success=streaming_result['success'],
                    output=streaming_result['output'],
                    stdout=streaming_result['stdout'],
                    stderr=streaming_result['stderr'],
                    exit_code=0 if streaming_result['success'] else -1,
                    execution_time_ms=streaming_result['execution_time_ms'],
                    memory_used_mb=0,
                    security_violations=[]
                )
            else:
                # Use standard executor
                execution_result = await self.sandbox_executor.execute(
                    generated_code.code,
                    test_data.minimal,
                    timeout=30
                )
            
            generation_log['phases']['validation'] = {
                'status': 'completed',
                'execution_success': execution_result.success,
                'execution_time_ms': execution_result.execution_time_ms
            }
            
            # Phase 8: Auto-fix if needed
            if not execution_result.success and execution_result.stderr:
                await self._update_status("fixing", "🔧 Fixing errors...")
                fixed_code = await self._auto_fix_errors(
                    generated_code.code,
                    execution_result
                )
                if fixed_code:
                    # Re-execute with fixed code
                    execution_result = await self.sandbox_executor.execute(
                        fixed_code,
                        test_data.minimal,
                        timeout=30
                    )
                    generated_code.code = fixed_code
            
            # Phase 9: Extract and Store Components
            new_components = self.component_extractor.extract_components(
                generated_code.code,
                analysis.domain or 'general'
            )
            for component in new_components:
                self._store_component(component)
            
            # Phase 10: Save Agent
            agent_id = await self._save_agent(
                generated_code.code,
                analysis,
                business_logic,
                execution_result,
                user_email
            )
            
            # Phase 11: Record Learning
            self.learning_system.record_generation_outcome(
                generation_log,
                execution_result.to_dict() if execution_result else None
            )
            
            # Phase 12: Final Status
            await self._update_status(
                "completed", 
                "✅ Agent successfully created!",
                {
                    'agent_id': agent_id,
                    'execution_success': execution_result.success,
                    'test_output': execution_result.output if execution_result.success else None
                }
            )
            
            return {
                'success': True,
                'agent_id': agent_id,
                'code': generated_code.code,
                'execution_result': execution_result.to_dict(),
                'test_data': test_data.minimal,
                'generation_log': generation_log
            }
            
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            
            logger.error(f"Pipeline error: {e}")
            logger.error(f"Error trace:\n{error_trace}")
            
            # 에러 타입 분석
            error_type = type(e).__name__
            error_message = str(e)
            
            # 구체적인 에러 메시지 생성
            if "gemini" in error_message.lower() or "api" in error_message.lower():
                user_friendly_message = "AI 모델 연결 오류가 발생했습니다. 잠시 후 다시 시도해주세요."
                error_category = "api_error"
            elif "timeout" in error_message.lower():
                user_friendly_message = "처리 시간이 초과되었습니다. 더 간단한 요청으로 시도해주세요."
                error_category = "timeout"
            elif "validation" in error_message.lower() or "syntax" in error_message.lower():
                user_friendly_message = "생성된 코드에 문법 오류가 있습니다. 다시 시도해주세요."
                error_category = "validation_error"
            elif "forge" in error_message.lower():
                user_friendly_message = "에이전트 생성 시스템 오류입니다. 관리자에게 문의해주세요."
                error_category = "system_error"
            else:
                user_friendly_message = f"에이전트 생성 중 오류가 발생했습니다: {error_message[:100]}"
                error_category = "unknown_error"
            
            generation_log['error'] = {
                'type': error_type,
                'category': error_category,
                'message': error_message,
                'user_message': user_friendly_message,
                'trace': error_trace[:500]
            }
            generation_log['phases']['error'] = {
                'status': 'failed',
                'error': error_message,
                'error_type': error_type
            }
            
            # Record failure for learning
            self.learning_system.record_generation_outcome(generation_log)
            
            # 스트리밍으로 상세 에러 정보 전달
            await self._update_status(
                "error",
                user_friendly_message,
                {
                    'error': error_message,
                    'error_type': error_type,
                    'error_category': error_category,
                    'suggestion': self._get_error_suggestion(error_category),
                    'generation_id': self.current_generation_id
                }
            )
            
            return {
                'success': False,
                'error': user_friendly_message,
                'error_details': {
                    'original_error': error_message,
                    'error_type': error_type,
                    'error_category': error_category,
                    'suggestion': self._get_error_suggestion(error_category)
                },
                'generation_log': generation_log
            }
    
    def _get_error_suggestion(self, error_category: str) -> str:
        """에러 카테고리별 해결 제안"""
        suggestions = {
            "api_error": "1. API 키 확인\n2. 네트워크 연결 확인\n3. 잠시 후 재시도",
            "timeout": "1. 더 간단한 요청으로 시도\n2. 요청을 작은 단위로 분할\n3. 시스템 리소스 확인",
            "validation_error": "1. 요청 내용 검토\n2. 더 구체적인 설명 추가\n3. 예제 코드 참조",
            "system_error": "1. 서버 로그 확인\n2. 시스템 관리자 문의\n3. 서버 재시작 시도",
            "unknown_error": "1. 요청 내용 확인\n2. 다른 방식으로 시도\n3. 지원팀 문의"
        }
        return suggestions.get(error_category, "지원팀에 문의해주세요.")
    
    async def _analyze_query(self, query: str) -> QueryAnalysis:
        """Analyze user query"""
        return await self.query_analyzer.analyze(query)
    
    async def _search_components(self, analysis: QueryAnalysis) -> List[Dict[str, Any]]:
        """Search for reusable components"""
        components = []
        
        try:
            # Search by capabilities
            for capability in analysis.required_capabilities:
                cursor = self.db_conn.cursor()
                cursor.execute('''
                    SELECT * FROM components 
                    WHERE category = ? OR tags LIKE ?
                    ORDER BY usage_count DESC, success_rate DESC
                    LIMIT 5
                ''', (capability, f'%"{capability}"%'))
                
                for row in cursor.fetchall():
                    components.append({
                        'id': row[0],
                        'name': row[1],
                        'type': row[2],
                        'code_snippet': row[3],
                        'usage_count': row[7],
                        'success_rate': row[8]
                    })
        except Exception as e:
            # Components table might not exist yet
            logger.warning(f"Could not search components: {e}")
            # Return empty list to continue without components
        
        return components
    
    async def _auto_fix_errors(self, 
                              code: str, 
                              execution_result) -> Optional[str]:
        """Attempt to automatically fix errors"""
        
        import re  # Move import to function start
        
        logger.info(f"[{self.current_generation_id}] 🔧 Attempting to auto-fix errors")
        logger.info(f"[{self.current_generation_id}] Error type: {execution_result.stderr.split(':')[0] if ':' in execution_result.stderr else 'Unknown'}")
        
        # 강화된 백틱 제거 로직 (최종 방어선)
        if "```" in code:
            logger.warning(f"[{self.current_generation_id}] ⚠️ Unexpected backticks found in code")
            original_length = len(code)
            
            # 다단계 백틱 제거
            fixed_code = code
            
            # 1. 코드 블록 제거
            fixed_code = re.sub(r'```[a-zA-Z]*\n', '', fixed_code)
            fixed_code = re.sub(r'\n```', '', fixed_code)
            
            # 2. f-string 내 백틱 제거
            fixed_code = re.sub(r'(f["\'])([^"\']*?)```([^"\']*?)(["\'])', r'\1\2\3\4', fixed_code)
            
            # 3. 문자열 내 백틱 제거
            fixed_code = re.sub(r'(["\'])([^"\']*?)```([^"\']*?)(["\'])', r'\1\2\3\4', fixed_code)
            
            # 4. 모든 백틱 제거
            fixed_code = fixed_code.replace('```', '')
            fixed_code = fixed_code.replace('`', '')
            
            # 검증
            final_backticks = fixed_code.count('```')
            if final_backticks == 0:
                logger.info(f"[{self.current_generation_id}] ✅ 모든 백틱 제거 완료 ({original_length} → {len(fixed_code)} 문자)")
                return fixed_code
            else:
                logger.error(f"[{self.current_generation_id}] ❌ 백틱 제거 실패: {final_backticks}개 남음")
                # 강제 제거
                fixed_code = fixed_code.replace('`', '')
                logger.info(f"[{self.current_generation_id}] 🔧 강제 백틱 제거 완료")
                return fixed_code
        
        # Fix common security violations
        if "Blocked import: os" in execution_result.stderr:
            logger.info(f"[{self.current_generation_id}] 🔒 Fixing os import security violation")
            fixed_code = code.replace("import os", "from pathlib import Path")
            fixed_code = fixed_code.replace("os.path.join", "str(Path")
            fixed_code = fixed_code.replace("os.path.exists", "Path.exists")
            fixed_code = fixed_code.replace("os.makedirs", "Path.mkdir")
            return fixed_code
        
        # Use LLM to fix errors - request pure Python code
        error_prompt = f"""Fix the following Python code error:

Error: {execution_result.stderr}

Code with error:
{code}

CRITICAL REQUIREMENTS:
1. Return ONLY the fixed Python code
2. Do NOT use JSON format like {{"code": "..."}}
3. Do NOT use markdown backticks like ```python
4. Do NOT include any explanations or comments outside the code
5. Start directly with 'import' or 'from' or 'class' statements
6. Make sure the code is complete and not truncated

Output the complete fixed Python code now:"""

        try:
            logger.info(f"[{self.current_generation_id}] 🤖 Using LLM to fix error")
            
            fixed_response = await self.llm.generate(
                error_prompt,
                model_override="gemini-2.5-flash-lite",
                temperature=0.1
            )
            
            # Parse response - expecting pure Python code
            if isinstance(fixed_response, str):
                cleaned_response = fixed_response.strip()
                
                # Check if response contains unwanted patterns and clean them
                if '```python' in cleaned_response or '```' in cleaned_response:
                    # Try to extract from code blocks if they exist
                    code_match = re.search(r'```(?:python)?\n?(.*?)\n?```', cleaned_response, re.DOTALL)
                    if code_match:
                        cleaned_response = code_match.group(1).strip()
                        logger.info(f"[{self.current_generation_id}] ✅ Extracted code from code block")
                
                # Check for JSON contamination
                if cleaned_response.startswith('{') and '"code"' in cleaned_response:
                    # Try to extract from JSON if it exists
                    try:
                        response_data = json.loads(cleaned_response)
                        if isinstance(response_data, dict) and 'code' in response_data:
                            cleaned_response = response_data['code']
                            logger.warning(f"[{self.current_generation_id}] ⚠️ Extracted code from JSON (unexpected)")
                    except (json.JSONDecodeError, KeyError):
                        # If JSON parsing fails, try to extract code portion
                        if '{"code":' in cleaned_response:
                            # Remove JSON wrapper
                            cleaned_response = re.sub(r'^\s*\{\s*"code"\s*:\s*"', '', cleaned_response)
                            cleaned_response = re.sub(r'"\s*\}\s*$', '', cleaned_response)
                            cleaned_response = cleaned_response.replace('\\n', '\n').replace('\\"', '"')
                            logger.warning(f"[{self.current_generation_id}] ⚠️ Cleaned JSON contamination")
                
                # Validate that we have Python code
                if not cleaned_response:
                    cleaned_response = None
                elif ('def ' in cleaned_response or 'class ' in cleaned_response or 
                      'import ' in cleaned_response or 'from ' in cleaned_response):
                    logger.info(f"[{self.current_generation_id}] ✅ Valid Python code detected")
                else:
                    logger.warning(f"[{self.current_generation_id}] ⚠️ Response may not be valid Python code")
                
                # Check if response is valid Python code
                if cleaned_response and cleaned_response.strip() and ('class' in cleaned_response or 'def' in cleaned_response):
                    logger.info(f"[{self.current_generation_id}] ✅ LLM fix successful")
                    return cleaned_response.strip()
                else:
                    logger.warning(f"[{self.current_generation_id}] ⚠️ LLM response doesn't look like valid Python code")
                    
        except Exception as e:
            logger.error(f"[{self.current_generation_id}] ❌ Auto-fix failed: {e}")
            
        return None
    
    async def _save_agent(self,
                         code: str,
                         analysis: QueryAnalysis,
                         business_logic,
                         execution_result,
                         user_email: str) -> str:
        """Save agent to database"""
        
        agent_id = f"agent_{uuid.uuid4().hex[:12]}"
        
        # Generate a proper agent name based on intent and capabilities
        agent_name = self._generate_agent_name(analysis)
        
        # The full analysis rule (what was previously stored in name)
        agent_rule = str(analysis)  # This will contain the full analysis output
        
        cursor = self.db_conn.cursor()
        cursor.execute('''
            INSERT INTO agents 
            (id, name, description, code, template_used, capabilities,
             tags, category, version, created_at, created_by, status,
             performance_score, usage_count, metadata, user_email, rule)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            agent_id,
            agent_name,  # Now using a proper agent name
            analysis.query[:200],  # Original query as description
            code,
            'forge_generated',
            json.dumps(analysis.required_capabilities),
            json.dumps(analysis.required_capabilities),
            analysis.domain or 'general',
            '1.0.0',
            datetime.now().isoformat(),
            user_email,
            'active' if execution_result.success else 'draft',
            0.8 if execution_result.success else 0.3,
            0,
            json.dumps({
                'generation_id': self.current_generation_id,
                'business_logic': business_logic.to_dict(),
                'execution_result': execution_result.to_dict()
            }),
            user_email,
            agent_rule  # Store the full analysis in the rule column
        ))
        
        self.db_conn.commit()
        
        return agent_id
    
    def _generate_agent_name(self, analysis: QueryAnalysis) -> str:
        """Generate a proper name for the agent based on analysis"""
        intent = analysis.intent.lower()
        capabilities = [cap.lower() for cap in analysis.required_capabilities]
        
        # Common agent type mappings
        raw_name = ""
        if 'data' in intent and any(term in intent for term in ['analys', 'process']):
            raw_name = "Data Analysis Agent"
        elif 'csv' in intent or 'excel' in intent:
            raw_name = "CSV Processing Agent"
        elif 'api' in intent:
            raw_name = "API Integration Agent"
        elif 'web' in intent and 'scrap' in intent:
            raw_name = "Web Scraping Agent"
        elif 'test' in intent:
            raw_name = "Test Agent"
        elif 'calculat' in intent:
            raw_name = "Calculator Agent"
        elif 'debug' in intent:
            raw_name = "Debugging Agent"
        elif 'monitor' in intent:
            raw_name = "Monitoring Agent"
        elif 'report' in intent:
            raw_name = "Report Generation Agent"
        elif 'automat' in intent:
            raw_name = "Automation Agent"
        elif 'email' in intent:
            raw_name = "Email Processing Agent"
        elif 'database' in intent or 'sql' in intent:
            raw_name = "Database Agent"
        elif 'file' in intent:
            raw_name = "File Processing Agent"
        elif 'search' in intent:
            raw_name = "Search Agent"
        else:
            # Create a name from the intent
            words = analysis.intent.replace('_', ' ').split()
            if len(words) > 0:
                raw_name = f"{' '.join(words[:2]).title()} Agent"
            else:
                raw_name = "Custom Agent"
        
        # Apply sanitization to ensure consistency
        return sanitize_agent_name(raw_name)
    
    def _store_component(self, component):
        """Store extracted component"""
        try:
            cursor = self.db_conn.cursor()
            
            # Check if component already exists by name and type
            cursor.execute(
                'SELECT id FROM components WHERE name = ? AND type = ?',
                (component.name, component.type)
            )
            
            if not cursor.fetchone():
                cursor.execute('''
                    INSERT INTO components 
                    (id, name, type, code_snippet, description, category,
                     tags, usage_count, dependencies, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    component.id,
                    component.name,
                    component.type,
                    component.code_snippet,
                    component.description,
                    component.category,
                    json.dumps(component.tags),
                    0,
                    json.dumps(component.dependencies),
                    datetime.now().isoformat()
                ))
                
                self.db_conn.commit()
        except Exception as e:
            # Components table might not exist yet
            logger.warning(f"Could not store component: {e}")
    
    async def _update_status(self, status: str, message: str, data: Dict[str, Any] = None):
        """Update generation status"""
        if self.stream_callback:
            await self.stream_callback(status, message, data or {})


# Example usage
async def example_usage():
    """Example of using the FORGE pipeline"""
    
    # Create pipeline
    pipeline = ForgePipeline()
    
    # Example callback for progress updates
    async def progress_callback(status, message, data):
        print(f"[{status}] {message}")
        if data:
            print(f"  Data: {json.dumps(data, indent=2)}")
    
    # Generate agent
    result = await pipeline.generate_agent(
        query="Create a customer order analysis system that tracks purchase patterns and identifies VIP customers",
        user_email="user@example.com",
        stream_callback=progress_callback
    )
    
    if result['success']:
        print(f"\nAgent created successfully!")
        print(f"Agent ID: {result['agent_id']}")
        print(f"Execution successful: {result['execution_result']['success']}")
        if result['execution_result']['success']:
            print(f"Output: {result['execution_result']['output']}")
    else:
        print(f"\nAgent creation failed: {result['error']}")


if __name__ == "__main__":
    asyncio.run(example_usage())