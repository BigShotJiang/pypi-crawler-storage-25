"""
통합 Agentic AI 템플릿 생성기
================================
실제 AI 에이전트를 생성하는 완전 통합 시스템

핵심 기능:
1. 진짜 AI 에이전트 - 실제로 생각하고 결정
2. 고성능 - 빠른 처리 + 깊은 사고  
3. 확장 가능 - 에이전트 간 협업 자동화
4. 자가 개선 - 스스로 학습하고 진화
"""

import asyncio
import json
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
from pathlib import Path
import re

from loguru import logger
from template_based_generator import TemplateBasedGenerator
from agentic_engine import AgenticEngine, AgenticContext


class UnifiedAgenticGenerator(TemplateBasedGenerator):
    """
    통합 Agentic AI 생성기
    - 실제 LLM 사용
    - Agentic Engine 통합
    - 에이전트 간 협업
    - 자가 학습 시스템
    """
    
    def __init__(self, templates_dir: str = "forge/templates"):
        super().__init__(templates_dir)
        self.agentic_templates_dir = Path(templates_dir) / "agentic"
        self._ensure_agentic_templates()
        
    def _ensure_agentic_templates(self):
        """Agentic 템플릿 디렉토리 생성"""
        self.agentic_templates_dir.mkdir(parents=True, exist_ok=True)
        
    async def generate_agentic_agent(
        self, 
        user_request: str, 
        llm_client: Any,
        use_real_llm: bool = True,
        enable_collaboration: bool = True,
        enable_self_improvement: bool = True,
        metadata: Dict[str, Any] = None
    ) -> Tuple[str, Dict[str, Any]]:
        """
        완전한 Agentic AI 에이전트 생성
        
        Args:
            user_request: 사용자 요청
            llm_client: LLM 클라이언트 (실제 또는 Mock)
            use_real_llm: 실제 LLM 사용 여부
            enable_collaboration: 에이전트 협업 활성화
            enable_self_improvement: 자가 개선 활성화
            metadata: 추가 메타데이터
            
        Returns:
            Tuple[generated_code, metadata]
        """
        try:
            # 1. Agentic Context 생성
            agentic_context = await self._create_agentic_context(
                user_request, metadata
            )
            
            # 2. 최적 템플릿 선택 (AI 기반)
            template_id, confidence = await self._select_agentic_template(
                user_request, agentic_context, llm_client
            )
            
            # 3. Agentic 비즈니스 로직 생성
            business_logic = await self._generate_agentic_logic(
                template_id, 
                user_request, 
                llm_client,
                agentic_context,
                use_real_llm
            )
            
            # 4. 통합 에이전트 코드 생성
            agent_code = await self._assemble_agentic_agent(
                template_id,
                business_logic,
                enable_collaboration,
                enable_self_improvement
            )
            
            # 5. 메타데이터 생성
            generation_metadata = {
                "template_used": template_id,
                "template_confidence": confidence,
                "agentic_features": {
                    "real_llm": use_real_llm,
                    "collaboration": enable_collaboration,
                    "self_improvement": enable_self_improvement,
                    "agentic_context": agentic_context
                },
                "generation_timestamp": datetime.now().isoformat(),
                "request_summary": user_request[:100] + "..." if len(user_request) > 100 else user_request
            }
            
            logger.info(f"🤖 Agentic AI 에이전트 생성 완료: {template_id}")
            return agent_code, generation_metadata
            
        except Exception as e:
            logger.error(f"Agentic AI 생성 실패: {e}")
            raise
    
    async def _create_agentic_context(
        self, 
        user_request: str, 
        metadata: Optional[Dict] = None
    ) -> AgenticContext:
        """사용자 요청에서 Agentic Context 추출"""
        
        # 요청 분석
        request_lower = user_request.lower()
        
        # 비즈니스 도메인 추출
        business_domain = "general"
        if any(word in request_lower for word in ['데이터', '분석', 'csv', 'excel']):
            business_domain = "data_analysis"
        elif any(word in request_lower for word in ['웹', '모니터링', '스크래핑']):
            business_domain = "web_automation"
        elif any(word in request_lower for word in ['ml', '머신러닝', '예측', '모델']):
            business_domain = "machine_learning"
        elif any(word in request_lower for word in ['계약', '문서', '이력서']):
            business_domain = "document_processing"
        
        # 긴급도 수준
        urgency_level = "normal"
        if any(word in request_lower for word in ['실시간', 'real-time', '즉시', '긴급']):
            urgency_level = "high"
        elif any(word in request_lower for word in ['천천히', '여유', '장기']):
            urgency_level = "low"
        
        # 품질 요구사항
        quality_requirement = "balanced"
        if any(word in request_lower for word in ['정확', '완벽', '상세', '깊이']):
            quality_requirement = "high_quality"
        elif any(word in request_lower for word in ['빠른', '간단', '대략']):
            quality_requirement = "fast_delivery"
        
        # 데이터 프로필 (간단한 분석)
        data_profile = {
            "has_numerical_data": any(word in request_lower for word in ['수치', '통계', '매출', '금액']),
            "has_text_data": any(word in request_lower for word in ['텍스트', '문서', '내용']),
            "has_structured_data": any(word in request_lower for word in ['테이블', 'csv', 'excel', '데이터베이스']),
            "estimated_complexity": "medium"
        }
        
        # AgenticContext 생성
        context = AgenticContext(
            user_intent=user_request,
            data_profile=data_profile,
            business_domain=business_domain,
            urgency_level=urgency_level,
            quality_requirement=quality_requirement,
            previous_results=None
        )
        
        return context
    
    async def _select_agentic_template(
        self,
        user_request: str,
        agentic_context: AgenticContext,
        llm_client: Any
    ) -> Tuple[str, float]:
        """AI 기반 최적 템플릿 선택"""
        
        # 기본 템플릿 선택 (부모 클래스 메서드)
        template_id, base_confidence = await self.select_template(
            user_request, {"agentic_context": agentic_context}
        )
        
        # AI로 템플릿 적합성 재평가
        if hasattr(llm_client, 'invoke'):
            evaluation_prompt = f"""
            사용자 요청: {user_request}
            선택된 템플릿: {template_id}
            
            이 템플릿이 사용자 요청에 적합한지 평가하고,
            더 나은 템플릿이 있다면 제안해주세요.
            
            응답 형식:
            {{
                "is_suitable": true/false,
                "confidence": 0.0-1.0,
                "better_template": "template_id or null",
                "reasoning": "설명"
            }}
            """
            
            try:
                response = await llm_client.invoke(evaluation_prompt)
                # LLMResponse를 문자열로 변환
                response_text = str(response)
                # JSON 코드 블록 제거
                if '```json' in response_text:
                    response_text = response_text.split('```json')[1].split('```')[0].strip()
                evaluation = json.loads(response_text)
                
                if not evaluation.get('is_suitable') and evaluation.get('better_template'):
                    template_id = evaluation['better_template']
                    base_confidence = evaluation.get('confidence', 0.8)
                    
            except Exception as e:
                logger.warning(f"AI 템플릿 평가 실패: {e}")
        
        return template_id, base_confidence
    
    async def _generate_agentic_logic(
        self,
        template_id: str,
        user_request: str,
        llm_client: Any,
        agentic_context: AgenticContext,
        use_real_llm: bool
    ) -> Dict[str, str]:
        """Agentic 비즈니스 로직 생성"""
        
        business_logic = {}
        
        # 1. 전략적 사고 로직
        strategic_prompt = f"""
사용자 요청: {user_request}
컨텍스트: {agentic_context}

다음 Python 메서드를 생성하세요. 들여쓰기 없이 시작하세요:

IMPORTANT: Do NOT use f-string triple quotes (f\"\"\") in your code. Use regular strings or format() method instead.

async def _strategic_thinking(self, query: str, context: Dict) -> Dict[str, Any]:
    '''AI 기반 전략적 사고와 계획 수립'''
    
    # 사용자 요청에 맞는 구체적인 전략적 사고 로직을 구현하세요
    # 1. 목표 분석
    goals = await self._analyze_goals(query, context)
    
    # 2. 전략 수립
    strategy = await self._create_strategy(goals, context)
    
    # 3. 실행 계획
    plan = await self._create_execution_plan(strategy, context)
    
    return {{"goals": goals, "strategy": strategy, "plan": plan}}

# _analyze_goals, _create_strategy, _create_execution_plan 메서드도 구현하세요
# 문자열 포맷팅이 필요한 경우 format() 메서드나 % 포맷팅을 사용하세요
"""
        
        if use_real_llm:
            response = await llm_client.invoke(strategic_prompt)
            business_logic['strategic_thinking'] = str(response)
        else:
            business_logic['strategic_thinking'] = self._get_default_strategic_logic()
        
        # 2. 자율적 의사결정 로직
        decision_prompt = f"""
사용자 요청: {user_request}
컨텍스트: {agentic_context}

다음 Python 메서드를 생성하세요. 들여쓰기 없이 시작하세요:

IMPORTANT: Do NOT use f-string triple quotes (f\"\"\") in your code. Use regular strings or format() method instead.

async def _autonomous_decision_making(self, situation: Dict[str, Any]) -> Dict[str, Any]:
    '''자율적 의사결정 로직'''
    
    # 상황 평가
    assessment = await self._assess_situation(situation)
    
    # 옵션 생성
    options = await self._generate_options(assessment)
    
    # 최적 선택
    decision = await self._make_decision(options, assessment)
    
    return {{"assessment": assessment, "options": options, "decision": decision}}

# Implement helper methods as needed
# For string formatting, use format() method or % formatting instead of f-strings
"""
        
        if use_real_llm:
            response = await llm_client.invoke(decision_prompt)
            business_logic['decision_making'] = str(response)
        else:
            business_logic['decision_making'] = self._get_default_decision_logic()
        
        # 3. 협업 로직
        if agentic_context.business_domain in ['data_analysis', 'machine_learning'] or 'collaboration' in user_request.lower():
            collaboration_prompt = f"""
사용자 요청: {user_request}
컨텍스트: {agentic_context}

다음 Python 메서드를 생성하세요. 들여쓰기 없이 시작하세요:

IMPORTANT: Do NOT use f-string triple quotes (f\"\"\") in your code. Use regular strings or format() method instead.

async def _collaborate_with_agents(self, task: Dict[str, Any]) -> Dict[str, Any]:
    '''다른 에이전트와의 협업'''
    
    # 필요한 에이전트 식별
    required_agents = await self._identify_collaborators(task)
    
    # 작업 분배
    distributed_tasks = await self._distribute_tasks(task, required_agents)
    
    # 결과 통합
    integrated_result = await self._integrate_results(distributed_tasks)
    
    return integrated_result

# Implement helper methods as needed
# For string formatting, use format() method or % formatting instead of f-strings
"""
            
            if use_real_llm:
                response = await llm_client.invoke(collaboration_prompt)
                business_logic['collaboration'] = str(response)
            else:
                business_logic['collaboration'] = self._get_default_collaboration_logic()
        
        # 4. 자가 개선 로직
        if agentic_context.quality_requirement == "high_quality" or 'learning' in user_request.lower():
            learning_prompt = f"""
사용자 요청: {user_request}
컨텍스트: {agentic_context}

다음 Python 메서드를 생성하세요. 들여쓰기 없이 시작하세요:

IMPORTANT: Do NOT use f-string triple quotes (f\"\"\") in your code. Use regular strings or format() method instead.

async def _self_improve(self, experience: Dict[str, Any]) -> None:
    '''경험을 통한 자가 개선'''
    
    # 성과 분석
    performance = await self._analyze_performance(experience)
    
    # 개선점 도출
    improvements = await self._identify_improvements(performance)
    
    # 학습 적용
    await self._apply_learnings(improvements)
    
    # 진화
    await self._evolve_capabilities(improvements)

# Implement helper methods as needed
# For string formatting, use format() method or % formatting instead of f-strings
"""
            
            if use_real_llm:
                response = await llm_client.invoke(learning_prompt)
                business_logic['self_improvement'] = str(response)
            else:
                business_logic['self_improvement'] = self._get_default_learning_logic()
        
        return business_logic
    
    async def _assemble_agentic_agent(
        self,
        template_id: str,
        business_logic: Dict[str, str],
        enable_collaboration: bool,
        enable_self_improvement: bool
    ) -> str:
        """통합 Agentic 에이전트 코드 조립"""
        
        # Agentic 템플릿 로드
        template_path = self._get_agentic_template_path()
        
        with open(template_path, 'r', encoding='utf-8') as f:
            template_code = f.read()
        
        # 비즈니스 로직 주입
        for section, code in business_logic.items():
            # 코드 정리 (마크다운 블록 제거 및 인덴트 조정)
            code = self._clean_llm_code(code)
            # 여러 줄 문자열 문제 수정 - 특히 f-string 삼중 따옴표
            code = self._fix_multiline_strings(code)
            
            # 추가 정리: 코드 끝부분에 잘못된 패턴 제거
            code = code.rstrip()
            if code.endswith('"""'):
                code = code[:-3].rstrip()
            if code.endswith('}"'):
                code = code[:-1] + '}'
            
            marker_start = f"# ========== {section} 시작 =========="
            marker_end = f"# ========== {section} 끝 =========="
            
            if marker_start in template_code and marker_end in template_code:
                start_idx = template_code.find(marker_start) + len(marker_start)
                end_idx = template_code.find(marker_end)
                
                # 현재 마커의 인덴트 레벨 찾기
                line_start = template_code.rfind('\n', 0, template_code.find(marker_start)) + 1
                marker_line = template_code[line_start:template_code.find(marker_start)]
                base_indent = len(marker_line) - len(marker_line.lstrip())
                
                # 코드의 각 줄에 적절한 인덴트 추가
                indented_lines = []
                for line in code.split('\n'):
                    if line.strip():  # 빈 줄이 아닌 경우
                        indented_lines.append(' ' * base_indent + line)
                    else:
                        indented_lines.append('')  # 빈 줄 유지
                
                indented_code = '\n'.join(indented_lines)
                
                # 코드 주입
                template_code = (
                    template_code[:start_idx] + 
                    '\n' + indented_code + '\n' +
                    template_code[end_idx:]
                )
        
        # 기능 활성화/비활성화
        if not enable_collaboration:
            template_code = template_code.replace(
                "self.enable_collaboration = True",
                "self.enable_collaboration = False"
            )
            
        if not enable_self_improvement:
            template_code = template_code.replace(
                "self.enable_self_improvement = True", 
                "self.enable_self_improvement = False"
            )
        
        return template_code
    
    def _get_agentic_template_path(self) -> Path:
        """Agentic 템플릿 경로 반환"""
        # 단순화된 템플릿 우선 사용
        simplified_template = Path(__file__).parent.parent / "templates" / "logosai_agent_template_simplified.py.template"
        
        # 단순화된 템플릿이 있으면 사용
        if simplified_template.exists():
            logger.info("✅ Using simplified Agentic template (Framework-managed)")
            return simplified_template
        
        # 없으면 기존 템플릿 사용
        template_path = self.agentic_templates_dir / "unified_agentic_template.py.template"
        
        # 템플릿이 없으면 생성
        if not template_path.exists():
            self._create_unified_agentic_template()
            
        return template_path
    
    def _create_unified_agentic_template(self):
        """통합 Agentic 템플릿 생성"""
        template_content = '''"""
통합 Agentic AI 에이전트 템플릿
================================
실제 AI 사고, 협업, 자가 개선이 가능한 진정한 Agentic AI
"""

import asyncio
from typing import Dict, Any, Optional, List
from datetime import datetime
from loguru import logger

from logosai import (
    LogosAIAgent,
    AgentConfig,
    AgentType,
    AgentResponse,
    AgentResponseType
)
from logosai.utils.llm_client import LLMClient
from logosai.dialogue_protocol import DialogueProtocol
from logosai.agent_self_assessment import AgentSelfAssessment


class UnifiedAgenticAgent(LogosAIAgent):
    """
    통합 Agentic AI 에이전트
    
    핵심 능력:
    1. 진짜 AI 사고 - LLM 기반 의사결정
    2. 고성능 처리 - Fast + Slow 사고
    3. 에이전트 협업 - 자동 협업 시스템
    4. 자가 개선 - 경험 기반 진화
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        if config is None:
            config = AgentConfig(
                name="Unified Agentic AI Agent",
                agent_type=AgentType.CUSTOM,
                description="실제 AI 사고와 협업이 가능한 통합 에이전트",
                version="2.0.0"
            )
        super().__init__(config)
        
        # LLM 클라이언트
        self.llm_client = LLMClient(
            provider="google",
            model="gemini-2.5-flash-lite",
            temperature=0.7
        )
        
        # 협업 시스템
        self.dialogue = DialogueProtocol()
        self.enable_collaboration = True
        
        # 자가 평가 시스템
        self.self_assessment = AgentSelfAssessment()
        self.enable_self_improvement = True
        
        # 경험 저장소
        self.experience_memory = []
        
    async def initialize(self) -> None:
        """에이전트 초기화"""
        await super().initialize()
        logger.info(f"🤖 {self.name} 초기화 완료 - Agentic AI 준비됨")
        
    async def process(self, query: str, context: Optional[Dict] = None) -> AgentResponse:
        """
        통합 Agentic 처리 파이프라인
        """
        try:
            # Phase 1: 전략적 사고
            strategy = await self._strategic_thinking(query, context or {})
            
            # Phase 2: 자율적 의사결정
            decision = await self._autonomous_decision_making({
                "query": query,
                "strategy": strategy,
                "context": context
            })
            
            # Phase 3: 실행 (협업 포함)
            if self.enable_collaboration and self._needs_collaboration(decision):
                result = await self._collaborate_with_agents(decision)
            else:
                result = await self._execute_decision(decision)
            
            # Phase 4: 자가 평가 및 개선
            if self.enable_self_improvement:
                experience = {
                    "query": query,
                    "strategy": strategy,
                    "decision": decision,
                    "result": result,
                    "timestamp": datetime.now()
                }
                await self._self_improve(experience)
            
            # 응답 생성
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={
                    "result": result,
                    "strategy": strategy,
                    "decision": decision,
                    "message": "Agentic AI 처리 완료"
                }
            )
            
        except Exception as e:
            logger.error(f"Agentic 처리 오류: {e}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={"error": str(e)}
            )
    
    # ========== strategic_thinking 시작 ==========
    # 전략적 사고 로직이 여기에 주입됩니다
    # ========== strategic_thinking 끝 ==========
    
    # ========== decision_making 시작 ==========
    # 자율적 의사결정 로직이 여기에 주입됩니다
    # ========== decision_making 끝 ==========
    
    # ========== collaboration 시작 ==========
    # 협업 로직이 여기에 주입됩니다
    # ========== collaboration 끝 ==========
    
    # ========== self_improvement 시작 ==========
    # 자가 개선 로직이 여기에 주입됩니다
    # ========== self_improvement 끝 ==========
    
    def _needs_collaboration(self, decision: Dict) -> bool:
        """협업 필요 여부 판단"""
        # 결정의 복잡도나 필요 리소스에 따라 판단
        return decision.get('requires_collaboration', False)
    
    async def _execute_decision(self, decision: Dict) -> Dict[str, Any]:
        """단독 실행"""
        # 기본 실행 로직
        return {
            "status": "executed",
            "decision": decision,
            "timestamp": datetime.now().isoformat()
        }


# 기본 로직 제공 (LLM이 실패할 경우를 위한 폴백)
def _get_default_strategic_logic():
    return """
    goals = {"primary": "사용자 요청 처리", "secondary": []}
    strategy = {"approach": "직접 처리", "steps": ["분석", "처리", "검증"]}
    plan = {"timeline": "즉시", "resources": ["self"]}
    return {"goals": goals, "strategy": strategy, "plan": plan}
    """

def _get_default_decision_logic():
    return """
    assessment = {"complexity": "medium", "feasibility": "high"}
    options = [{"option": "직접 처리", "score": 0.9}]
    decision = {"selected": options[0], "confidence": 0.85}
    return {"assessment": assessment, "options": options, "decision": decision}
    """

def _get_default_collaboration_logic():
    return """
    required_agents = []
    distributed_tasks = {"self": task}
    integrated_result = await self._execute_decision(task)
    return integrated_result
    """

def _get_default_learning_logic():
    return """
    performance = {"success_rate": 0.9, "efficiency": 0.8}
    improvements = ["처리 속도 개선", "정확도 향상"]
    self.experience_memory.append(experience)
    logger.info(f"경험 저장: {len(self.experience_memory)}개")
    """
'''
        
        # 템플릿 저장
        template_path = self.agentic_templates_dir / "unified_agentic_template.py.template"
        with open(template_path, 'w', encoding='utf-8') as f:
            f.write(template_content)
            
        logger.info(f"✅ 통합 Agentic 템플릿 생성: {template_path}")
    
    # 기본 로직 메서드들
    def _get_default_strategic_logic(self) -> str:
        return '''
    goals = {"primary": "사용자 요청 처리", "secondary": []}
    strategy = {"approach": "직접 처리", "steps": ["분석", "처리", "검증"]}
    plan = {"timeline": "즉시", "resources": ["self"]}
    return {"goals": goals, "strategy": strategy, "plan": plan}
    '''
    
    def _get_default_decision_logic(self) -> str:
        return '''
    assessment = {"complexity": "medium", "feasibility": "high"}
    options = [{"option": "직접 처리", "score": 0.9}]
    decision = {"selected": options[0], "confidence": 0.85}
    return {"assessment": assessment, "options": options, "decision": decision}
    '''
    
    def _get_default_collaboration_logic(self) -> str:
        return '''
    required_agents = []
    distributed_tasks = {"self": task}
    integrated_result = await self._execute_decision(task)
    return integrated_result
    '''
    
    def _get_default_learning_logic(self) -> str:
        return '''
    performance = {"success_rate": 0.9, "efficiency": 0.8}
    improvements = ["처리 속도 개선", "정확도 향상"]
    self.experience_memory.append(experience)
    logger.info(f"경험 저장: {len(self.experience_memory)}개")
    '''
    
    def _clean_llm_code(self, code: str) -> str:
        """LLM 응답에서 순수 코드만 추출"""
        # 먼저 모든 종류의 백틱 패턴을 제거
        # 1. 마크다운 코드 블록 패턴들
        code = re.sub(r'```python\s*\n?', '', code)
        code = re.sub(r'```py\s*\n?', '', code)
        code = re.sub(r'```\s*\n?', '', code)
        code = re.sub(r'\n?```', '', code)
        
        # 2. 코드 블록 내부에 남아있을 수 있는 백틱 제거
        # 라인별로 처리하여 독립적인 백틱 라인 제거
        lines = code.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # 백틱만 있는 라인 제거
            if line.strip() in ['```', '```python', '```py']:
                continue
            # 라인 내부의 백틱도 제거 (문자열 내부가 아닌 경우)
            if '```' in line and not ('"' in line or "'" in line):
                line = line.replace('```', '')
            cleaned_lines.append(line)
        
        code = '\n'.join(cleaned_lines)
        
        # 3. 들여쓰기 정규화
        lines = code.split('\n')
        normalized_lines = []
        
        # 최소 인덴트 찾기 (빈 줄 제외)
        min_indent = float('inf')
        for line in lines:
            if line.strip():  # 빈 줄이 아닌 경우
                indent_count = len(line) - len(line.lstrip())
                min_indent = min(min_indent, indent_count)
        
        # 모든 줄에서 최소 인덴트만큼 제거
        if min_indent < float('inf') and min_indent > 0:
            for line in lines:
                # 중복 import 제거
                if line.strip().startswith('from typing import') or \
                   line.strip().startswith('import json') or \
                   line.strip().startswith('import pandas') or \
                   line.strip().startswith('import asyncio') or \
                   line.strip().startswith('from datetime import'):
                    continue
                
                if line.strip():  # 빈 줄이 아닌 경우
                    if len(line) >= min_indent:
                        normalized_lines.append(line[min_indent:])
                    else:
                        normalized_lines.append(line)
                else:
                    normalized_lines.append('')  # 빈 줄 유지
        else:
            # 최소 인덴트가 없는 경우 그대로 사용
            for line in lines:
                if not (line.strip().startswith('from typing import') or \
                       line.strip().startswith('import json') or \
                       line.strip().startswith('import pandas')):
                    normalized_lines.append(line)
        
        result = '\n'.join(normalized_lines).strip()
        
        # 4. 추가 정리 - 코드 끝부분의 잘못된 패턴 제거
        result = result.replace('```python\n', '')
        result = result.replace('\n```', '')
        result = result.replace('```', '')
        
        return result
    
    def _fix_multiline_strings(self, code: str) -> str:
        """여러 줄 문자열 문제를 수정 - 특히 f-string 삼중 따옴표 처리"""
        # 먼저 가장 문제가 되는 패턴들을 직접 수정
        # 1. 라인 끝에 }""" 패턴
        code = code.replace(']}"""', ']}')
        code = code.replace('"}"""', '"}')
        code = code.replace(']}"""', ']}')
        
        lines = code.split('\n')
        fixed_lines = []
        
        # 삼중 따옴표 추적
        in_triple_quotes = False
        triple_quote_type = None
        is_f_string = False
        quote_start_line = -1
        
        for i, line in enumerate(lines):
            # 라인 끝에 삼중 따옴표가 혼자 있는 경우를 특별 처리
            if line.strip() == '"""' and in_triple_quotes:
                # 닫는 삼중 따옴표로 처리
                in_triple_quotes = False
                triple_quote_type = None
                is_f_string = False
                fixed_lines.append(line)
                continue
            
            # f""" 패턴 찾기
            if 'f"""' in line:
                # f-string 삼중 따옴표를 일반 따옴표로 변경
                line = line.replace('f"""', 'f"')
                is_f_string = True
                in_triple_quotes = True
                triple_quote_type = '"""'
                quote_start_line = i
            elif '"""' in line and not in_triple_quotes:
                # 삼중 따옴표 시작
                in_triple_quotes = True
                triple_quote_type = '"""'
                quote_start_line = i
            elif '"""' in line and in_triple_quotes and i != quote_start_line:
                # 삼중 따옴표 종료
                in_triple_quotes = False
                triple_quote_type = None
                is_f_string = False
            elif in_triple_quotes and is_f_string:
                # f-string 내부에서 줄바꿈 처리
                # 줄 끝에 \n 추가하고 다음 줄과 연결
                if i < len(lines) - 1:
                    line = line.rstrip() + '\\n" + f"'
            
            # 마지막 줄인데 삼중 따옴표가 닫히지 않은 경우
            if i == len(lines) - 1 and in_triple_quotes:
                # 라인의 내용을 확인해서 적절히 닫기
                if '"]' in line and '"""' not in line:
                    # 리스트 내부의 문자열인 경우 아무것도 추가하지 않음
                    pass
                elif is_f_string:
                    line += '"'
                else:
                    line += '"""'
            
            fixed_lines.append(line)
        
        # 추가적인 문자열 정리
        result = '\n'.join(fixed_lines)
        
        # f-string 내부의 백틱 제거
        result = result.replace('```', '')
        
        # 닫히지 않은 괄호 처리
        open_parens = result.count('(') - result.count(')')
        if open_parens > 0:
            result += ')' * open_parens
        
        return result