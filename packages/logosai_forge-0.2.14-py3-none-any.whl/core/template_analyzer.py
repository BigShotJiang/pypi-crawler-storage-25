"""
Template Analyzer - 템플릿 자동 분석 및 메타데이터 추출
========================================================
모든 템플릿을 분석하여 자동으로 메타데이터를 추출하는 시스템
"""

import os
import re
import ast
import json
from pathlib import Path
from typing import Dict, List, Any, Optional
from loguru import logger


class TemplateAnalyzer:
    """템플릿 자동 분석기"""
    
    def __init__(self, template_dir: str = None):
        self.template_dir = Path(template_dir or Path(__file__).parent.parent / "templates")
        self.templates_metadata = {}
        
    def analyze_all_templates(self) -> Dict[str, Dict]:
        """모든 템플릿 분석"""
        logger.info(f"🔍 Analyzing templates in {self.template_dir}")
        
        # 모든 템플릿 파일 찾기
        template_files = list(self.template_dir.rglob("*.template"))
        template_files.extend(list(self.template_dir.rglob("*.py.template")))
        
        for template_file in template_files:
            try:
                metadata = self.analyze_single_template(template_file)
                if metadata:
                    template_id = self.generate_template_id(template_file)
                    self.templates_metadata[template_id] = metadata
                    logger.info(f"✅ Analyzed: {template_id}")
            except Exception as e:
                logger.error(f"❌ Failed to analyze {template_file}: {e}")
        
        logger.info(f"📊 Total templates analyzed: {len(self.templates_metadata)}")
        return self.templates_metadata
    
    def analyze_single_template(self, template_path: Path) -> Dict[str, Any]:
        """단일 템플릿 분석"""
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        metadata = {
            'path': str(template_path.relative_to(self.template_dir)),
            'size': len(content),
            'category': self.detect_category(template_path, content),
            'keywords': self.extract_keywords(content),
            'description': self.extract_description(content),
            'capabilities': self.detect_capabilities(content),
            'difficulty': self.assess_difficulty(content),
            'use_cases': self.identify_use_cases(content),
            'priority': self.calculate_priority(template_path, content),
            'framework': self.detect_framework(content),
            'imports': self.extract_imports(content),
            'has_agentic': self.has_agentic_features(content),
            'has_llm': 'llm' in content.lower() or 'gpt' in content.lower(),
            'async_support': 'async def' in content,
            'template_variables': self.extract_template_variables(content)
        }
        
        return metadata
    
    def generate_template_id(self, template_path: Path) -> str:
        """템플릿 ID 생성"""
        # 파일명에서 .py.template 또는 .template 제거
        name = template_path.stem
        if name.endswith('.py'):
            name = name[:-3]
        
        # 특수문자를 언더스코어로 변환
        name = re.sub(r'[^a-zA-Z0-9_]', '_', name)
        
        # 폴더 구조 반영
        if template_path.parent.name != 'templates':
            prefix = template_path.parent.name
            return f"{prefix}_{name}"
        
        return name
    
    def detect_category(self, path: Path, content: str) -> str:
        """카테고리 감지"""
        # 경로 기반 카테고리
        if 'specialized' in str(path):
            # 세부 카테고리 분석
            if 'csv' in str(path).lower() or 'excel' in str(path).lower():
                return 'data_analysis'
            elif 'kpi' in str(path).lower() or 'dashboard' in str(path).lower():
                return 'monitoring'
            elif 'financial' in str(path).lower() or 'stock' in str(path).lower():
                return 'finance'
            elif 'email' in str(path).lower():
                return 'communication'
            elif 'pdf' in str(path).lower() or 'document' in str(path).lower():
                return 'document_processing'
            elif 'image' in str(path).lower():
                return 'computer_vision'
            elif 'price' in str(path).lower():
                return 'web_scraping'
            elif 'automl' in str(path).lower():
                return 'machine_learning'
            elif 'news' in str(path).lower():
                return 'web_automation'
            elif 'sentiment' in str(path).lower():
                return 'nlp'
            elif 'time_series' in str(path).lower():
                return 'forecasting'
            else:
                return 'specialized'
        elif 'agentic' in str(path):
            return 'agentic_ai'
        elif 'logosai' in str(path):
            return 'logosai_framework'
        elif 'experimental' in str(path):
            return 'experimental'
        elif 'optimized' in str(path):
            return 'optimized'
        
        # 내용 기반 카테고리
        if 'AgenticCore' in content or 'AgenticReasoning' in content:
            return 'agentic_ai'
        elif 'workflow' in content.lower():
            return 'workflow'
        elif 'api' in content.lower():
            return 'integration'
        
        return 'general'
    
    def extract_keywords(self, content: str) -> List[str]:
        """키워드 추출"""
        keywords = set()
        
        # 클래스명과 함수명에서 추출
        class_pattern = r'class\s+(\w+)'
        func_pattern = r'def\s+(\w+)'
        
        for match in re.finditer(class_pattern, content):
            # CamelCase를 단어로 분리
            words = re.findall(r'[A-Z][a-z]+|[a-z]+', match.group(1))
            keywords.update([w.lower() for w in words])
        
        for match in re.finditer(func_pattern, content):
            # snake_case를 단어로 분리
            words = match.group(1).split('_')
            keywords.update([w.lower() for w in words if len(w) > 2])
        
        # 주요 기술 키워드 추가
        tech_keywords = {
            'pandas': ['데이터', 'data', '분석', 'analysis'],
            'numpy': ['수치', 'numerical', '계산', 'computation'],
            'sklearn': ['머신러닝', 'machine learning', 'ML'],
            'tensorflow': ['딥러닝', 'deep learning', 'DL', 'AI'],
            'aiohttp': ['비동기', 'async', 'HTTP', 'API'],
            'beautifulsoup': ['웹스크래핑', 'web scraping', '크롤링'],
            'AgenticCore': ['에이전틱', 'agentic', '자율', 'autonomous'],
            'LLMClient': ['LLM', '언어모델', 'GPT', 'AI']
        }
        
        for tech, words in tech_keywords.items():
            if tech in content:
                keywords.update(words)
        
        # 한글 키워드 추출
        korean_pattern = r'[가-힣]+'
        korean_words = re.findall(korean_pattern, content)
        keywords.update([w for w in korean_words if len(w) >= 2])
        
        return list(keywords)
    
    def extract_description(self, content: str) -> str:
        """설명 추출"""
        # Docstring 추출
        docstring_pattern = r'"""(.*?)"""'
        matches = re.findall(docstring_pattern, content, re.DOTALL)
        
        if matches:
            # 첫 번째 docstring의 첫 줄 사용
            first_doc = matches[0].strip()
            lines = first_doc.split('\n')
            if lines:
                return lines[0].strip()
        
        # 클래스명 기반 설명 생성
        class_pattern = r'class\s+(\w+)'
        match = re.search(class_pattern, content)
        if match:
            class_name = match.group(1)
            # CamelCase를 읽기 쉬운 형태로 변환
            words = re.findall(r'[A-Z][a-z]+|[a-z]+', class_name)
            return ' '.join(words) + ' Agent'
        
        return "Custom AI Agent"
    
    def detect_capabilities(self, content: str) -> List[str]:
        """기능 감지"""
        capabilities = []
        
        # 기능 매핑
        capability_patterns = {
            'async_processing': r'async\s+def|asyncio|aiohttp',
            'data_analysis': r'pandas|numpy|DataFrame|analysis',
            'web_scraping': r'beautifulsoup|requests|selenium|scraping',
            'machine_learning': r'sklearn|tensorflow|keras|model\.fit',
            'natural_language': r'nltk|spacy|transformers|sentiment',
            'api_integration': r'requests|aiohttp|api|REST',
            'database': r'sql|mongodb|redis|database',
            'file_processing': r'csv|excel|pdf|docx',
            'image_processing': r'PIL|opencv|image',
            'real_time': r'websocket|streaming|real.?time',
            'autonomous_reasoning': r'AgenticReasoning|reasoning|think',
            'memory_management': r'AgenticMemory|memory|cache',
            'tool_usage': r'AgenticTools|tools|function',
            'continuous_learning': r'AgenticLearning|learning|improve',
            'planning': r'plan|strategy|workflow',
            'reflection': r'reflect|evaluate|feedback'
        }
        
        for capability, pattern in capability_patterns.items():
            if re.search(pattern, content, re.IGNORECASE):
                capabilities.append(capability)
        
        return capabilities
    
    def assess_difficulty(self, content: str) -> str:
        """난이도 평가"""
        score = 0
        
        # 복잡도 지표
        if 'AgenticCore' in content or 'AgenticReasoning' in content:
            score += 3
        if len(re.findall(r'class\s+\w+', content)) > 2:
            score += 2
        if len(re.findall(r'async\s+def', content)) > 5:
            score += 2
        if 'ThreadPoolExecutor' in content or 'ProcessPoolExecutor' in content:
            score += 2
        if len(content) > 10000:
            score += 1
        
        if score >= 5:
            return 'expert'
        elif score >= 3:
            return 'advanced'
        elif score >= 1:
            return 'intermediate'
        else:
            return 'beginner'
    
    def identify_use_cases(self, content: str) -> List[str]:
        """사용 사례 식별"""
        use_cases = []
        
        # 패턴 기반 사용 사례
        use_case_patterns = {
            '실시간 모니터링': r'monitor|real.?time|dashboard',
            '데이터 분석': r'analysis|analyze|pandas|statistics',
            '예측 및 예보': r'forecast|predict|future|trend',
            '자동화': r'automat|workflow|schedule',
            '웹 스크래핑': r'scraping|crawl|extract.*web',
            'API 통합': r'api|integration|rest|graphql',
            '문서 처리': r'document|pdf|excel|csv',
            '이미지 분석': r'image|vision|opencv|pil',
            '감정 분석': r'sentiment|emotion|feeling',
            '주식 분석': r'stock|trading|finance|market',
            '머신러닝': r'machine.?learning|sklearn|model',
            '자율 에이전트': r'autonomous|agentic|self'
        }
        
        for use_case, pattern in use_case_patterns.items():
            if re.search(pattern, content, re.IGNORECASE):
                use_cases.append(use_case)
        
        return use_cases if use_cases else ['범용 AI 에이전트']
    
    def calculate_priority(self, path: Path, content: str) -> int:
        """우선순위 계산"""
        priority = 5  # 기본값
        
        # Agentic AI는 최고 우선순위
        if 'agentic' in str(path).lower() or 'AgenticCore' in content:
            priority = 10
        # LogosAI 프레임워크는 높은 우선순위
        elif 'logosai' in str(path).lower():
            priority = 8
        # Specialized는 중간 우선순위
        elif 'specialized' in str(path):
            priority = 6
        # 실험적/최적화는 낮은 우선순위
        elif 'experimental' in str(path) or 'optimized' in str(path):
            priority = 4
        
        # 복잡도에 따른 조정
        difficulty = self.assess_difficulty(content)
        if difficulty == 'expert':
            priority += 1
        elif difficulty == 'beginner':
            priority -= 1
        
        return max(1, min(10, priority))  # 1-10 범위
    
    def detect_framework(self, content: str) -> str:
        """프레임워크 감지"""
        if 'LogosAIAgent' in content:
            return 'logosai'
        elif 'FastAPI' in content:
            return 'fastapi'
        elif 'Flask' in content:
            return 'flask'
        elif 'Django' in content:
            return 'django'
        else:
            return 'standalone'
    
    def extract_imports(self, content: str) -> List[str]:
        """Import 문 추출"""
        imports = []
        
        # import 문 패턴
        import_pattern = r'^(?:from\s+(\S+)\s+)?import\s+(.+)$'
        
        for line in content.split('\n'):
            match = re.match(import_pattern, line.strip())
            if match:
                module = match.group(1) or match.group(2).split()[0]
                if module and not module.startswith('.'):
                    imports.append(module.split('.')[0])
        
        return list(set(imports))
    
    def has_agentic_features(self, content: str) -> bool:
        """Agentic AI 기능 포함 여부"""
        agentic_indicators = [
            'AgenticCore',
            'AgenticReasoning',
            'AgenticMemory',
            'AgenticLearning',
            'AgenticTools',
            'Think-Plan-Act-Reflect',
            'autonomous',
            'self-improvement'
        ]
        
        return any(indicator in content for indicator in agentic_indicators)
    
    def extract_template_variables(self, content: str) -> List[str]:
        """템플릿 변수 추출"""
        # {{VARIABLE}} 또는 {variable} 패턴
        pattern1 = r'\{\{(\w+)\}\}'
        pattern2 = r'\{(\w+)\}'
        
        variables = set()
        variables.update(re.findall(pattern1, content))
        variables.update(re.findall(pattern2, content))
        
        # Python 포맷 스트링 제외
        exclude = {'self', 'cls', '0', '1', '2', 'i', 'j', 'k'}
        variables = [v for v in variables if v not in exclude and not v.isdigit()]
        
        return list(variables)
    
    def export_metadata(self, output_file: str = None) -> None:
        """메타데이터를 파일로 내보내기"""
        output_file = output_file or str(self.template_dir / 'template_metadata_full.json')
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.templates_metadata, f, indent=2, ensure_ascii=False)
        
        logger.info(f"📁 Metadata exported to {output_file}")


def main():
    """메인 실행 함수"""
    analyzer = TemplateAnalyzer()
    metadata = analyzer.analyze_all_templates()
    analyzer.export_metadata()
    
    # 통계 출력
    print(f"\n📊 Template Analysis Summary")
    print(f"{'='*50}")
    print(f"Total Templates: {len(metadata)}")
    
    # 카테고리별 통계
    categories = {}
    for tmpl in metadata.values():
        cat = tmpl['category']
        categories[cat] = categories.get(cat, 0) + 1
    
    print(f"\n📂 By Category:")
    for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True):
        print(f"  - {cat}: {count}")
    
    # Agentic AI 템플릿
    agentic_templates = [k for k, v in metadata.items() if v.get('has_agentic')]
    print(f"\n🤖 Agentic AI Templates: {len(agentic_templates)}")
    for tmpl in agentic_templates[:5]:
        print(f"  - {tmpl}")
    
    # 우선순위 높은 템플릿
    high_priority = sorted(metadata.items(), key=lambda x: x[1]['priority'], reverse=True)[:5]
    print(f"\n⭐ High Priority Templates:")
    for tmpl_id, tmpl_data in high_priority:
        print(f"  - {tmpl_id} (priority: {tmpl_data['priority']})")


if __name__ == "__main__":
    main()