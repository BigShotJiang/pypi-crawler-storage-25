"""
Intelligent Data Generator for FORGE AI
Generates test data based on code analysis and domain knowledge
"""

import ast
import json
import random
import string
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
import re

@dataclass
class DataRequirement:
    """Represents data requirements extracted from code"""
    field_name: str
    data_type: str
    constraints: Dict[str, Any]
    is_required: bool
    default_value: Any = None
    
@dataclass
class TestDataSuite:
    """Collection of test data for different scenarios"""
    minimal: Dict[str, Any]
    normal: Dict[str, Any]
    edge_cases: List[Dict[str, Any]]
    error_cases: List[Dict[str, Any]]
    stress_test: Optional[Dict[str, Any]] = None


class IntelligentDataGenerator:
    """Generates intelligent test data based on code analysis"""
    
    # 추천: 도메인별 현실적 데이터 패턴
    DOMAIN_DATA_PATTERNS = {
        'ecommerce': {
            'customer_id': lambda: f"CUST-{random.randint(10000, 99999)}",
            'order_amount': lambda: round(random.gauss(150, 50), 2),  # Normal distribution around $150
            'product_category': lambda: random.choice(['Electronics', 'Clothing', 'Home', 'Sports']),
            'order_date': lambda: datetime.now() - timedelta(days=random.randint(0, 365)),
            'customer_tier': lambda: random.choices(['Regular', 'Silver', 'Gold', 'VIP'], 
                                                   weights=[60, 25, 10, 5])[0]
        },
        'finance': {
            'account_number': lambda: f"ACC{random.randint(100000000, 999999999)}",
            'transaction_amount': lambda: round(random.lognormvariate(4, 2), 2),  # Log-normal for amounts
            'transaction_type': lambda: random.choice(['deposit', 'withdrawal', 'transfer']),
            'risk_score': lambda: round(random.betavariate(2, 5), 3),  # Beta distribution (0-1)
            'currency': lambda: random.choice(['USD', 'EUR', 'GBP', 'JPY'])
        },
        'user_data': {
            'name': lambda: f"{random.choice(['John', 'Jane', 'Bob', 'Alice'])} {random.choice(['Smith', 'Johnson', 'Williams', 'Brown'])}",
            'email': lambda: f"user{random.randint(1000, 9999)}@example.com",
            'age': lambda: random.randint(18, 80),
            'phone': lambda: f"+1-{random.randint(200, 999)}-{random.randint(200, 999)}-{random.randint(1000, 9999)}",
            'address': lambda: f"{random.randint(100, 9999)} {random.choice(['Main', 'Oak', 'Maple', 'First'])} St"
        }
    }
    
    # Edge case patterns
    EDGE_CASE_PATTERNS = {
        'string': ['', ' ', 'null', 'undefined', 'A' * 1000, '特殊文字テスト', '🎉emoji🎉'],
        'number': [0, -1, 0.0000001, float('inf'), -float('inf'), 999999999],
        'date': ['1970-01-01', '2038-01-19', 'invalid-date', None],
        'email': ['test@test', '@example.com', 'test@', 'test..test@example.com'],
        'array': [[], [None], [1] * 10000],
        'object': [{}, {'': ''}, None]
    }
    
    def analyze_code_requirements(self, code: str) -> List[DataRequirement]:
        """Extract data requirements from code"""
        requirements = []
        
        try:
            tree = ast.parse(code)
            
            # Extract from function signatures
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    requirements.extend(self._extract_from_function(node, code))
                elif isinstance(node, ast.ClassDef):
                    requirements.extend(self._extract_from_class(node, code))
            
            # Extract from data access patterns
            requirements.extend(self._extract_from_data_access(code))
            
        except SyntaxError:
            # Fallback to regex-based extraction
            requirements.extend(self._extract_with_regex(code))
            
        return requirements
    
    def generate_test_data(self, requirements: List[DataRequirement], 
                          domain: str = 'general') -> TestDataSuite:
        """Generate comprehensive test data suite"""
        
        # 1. Minimal valid data (1-5 records)
        minimal = self._generate_minimal_data(requirements, domain)
        
        # 2. Normal realistic data (100-1000 records)
        normal = self._generate_normal_data(requirements, domain, count=100)
        
        # 3. Edge cases
        edge_cases = self._generate_edge_cases(requirements)
        
        # 4. Error-inducing data
        error_cases = self._generate_error_cases(requirements)
        
        # 5. Stress test data (optional, 10k+ records)
        stress_test = None
        if self._needs_stress_test(requirements):
            stress_test = self._generate_stress_data(requirements, domain, count=10000)
        
        return TestDataSuite(
            minimal=minimal,
            normal=normal,
            edge_cases=edge_cases,
            error_cases=error_cases,
            stress_test=stress_test
        )
    
    def _extract_from_function(self, node: ast.FunctionDef, code: str) -> List[DataRequirement]:
        """Extract requirements from function definition"""
        requirements = []
        
        # Analyze parameters
        for arg in node.args.args:
            param_name = arg.arg
            
            # Try to infer type from annotations
            data_type = 'any'
            if arg.annotation:
                data_type = ast.unparse(arg.annotation)
            
            # Check for type hints in docstring
            docstring = ast.get_docstring(node)
            if docstring:
                type_match = re.search(rf'{param_name}.*?:\s*(\w+)', docstring)
                if type_match:
                    data_type = type_match.group(1)
            
            req = DataRequirement(
                field_name=param_name,
                data_type=data_type,
                constraints={},
                is_required=True
            )
            requirements.append(req)
        
        return requirements
    
    def _extract_from_class(self, node: ast.ClassDef, code: str) -> List[DataRequirement]:
        """Extract requirements from class definition"""
        requirements = []
        
        # Look for __init__ method
        for item in node.body:
            if isinstance(item, ast.FunctionDef) and item.name == '__init__':
                # Extract instance variables
                for stmt in ast.walk(item):
                    if isinstance(stmt, ast.Assign):
                        for target in stmt.targets:
                            if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name) and target.value.id == 'self':
                                field_name = target.attr
                                data_type = self._infer_type_from_value(stmt.value)
                                
                                req = DataRequirement(
                                    field_name=field_name,
                                    data_type=data_type,
                                    constraints={},
                                    is_required=True
                                )
                                requirements.append(req)
        
        return requirements
    
    def _extract_from_data_access(self, code: str) -> List[DataRequirement]:
        """Extract from data access patterns like df['column'] or data.get('field')"""
        requirements = []
        seen_fields = set()
        
        # Pattern 1: DataFrame column access
        df_pattern = r"(?:df|data|dataset)\[['\"]([\w_]+)['\"]\]"
        for match in re.finditer(df_pattern, code):
            field_name = match.group(1)
            if field_name not in seen_fields:
                seen_fields.add(field_name)
                requirements.append(DataRequirement(
                    field_name=field_name,
                    data_type='any',
                    constraints={},
                    is_required=True
                ))
        
        # Pattern 2: Dictionary access
        dict_pattern = r"\.get\(['\"](\w+)['\"]"
        for match in re.finditer(dict_pattern, code):
            field_name = match.group(1)
            if field_name not in seen_fields:
                seen_fields.add(field_name)
                requirements.append(DataRequirement(
                    field_name=field_name,
                    data_type='any',
                    constraints={},
                    is_required=False  # .get() implies optional
                ))
        
        return requirements
    
    def _extract_with_regex(self, code: str) -> List[DataRequirement]:
        """Fallback regex-based extraction"""
        requirements = []
        
        # Look for common validation patterns
        validation_patterns = [
            (r'if\s+(\w+)\s*>\s*(\d+)', 'number', 'min'),
            (r'if\s+(\w+)\s*<\s*(\d+)', 'number', 'max'),
            (r'if\s+len\((\w+)\)\s*[<>]\s*(\d+)', 'string', 'length'),
            (r'if\s+(\w+)\s+in\s+\[(.*?)\]', 'enum', 'values')
        ]
        
        for pattern, data_type, constraint_type in validation_patterns:
            for match in re.finditer(pattern, code):
                field_name = match.group(1)
                constraint_value = match.group(2)
                
                req = DataRequirement(
                    field_name=field_name,
                    data_type=data_type,
                    constraints={constraint_type: constraint_value},
                    is_required=True
                )
                requirements.append(req)
        
        return requirements
    
    def _infer_type_from_value(self, value_node: ast.AST) -> str:
        """Infer data type from AST value node"""
        if isinstance(value_node, ast.Constant):
            return type(value_node.value).__name__
        elif isinstance(value_node, ast.List):
            return 'list'
        elif isinstance(value_node, ast.Dict):
            return 'dict'
        elif isinstance(value_node, ast.Call):
            if hasattr(value_node.func, 'id'):
                func_name = value_node.func.id
                if func_name in ['int', 'float', 'str', 'bool']:
                    return func_name
        return 'any'
    
    def _generate_minimal_data(self, requirements: List[DataRequirement], domain: str) -> Dict[str, Any]:
        """Generate minimal valid dataset"""
        data = {}
        
        # If no requirements provided, use domain defaults
        if not requirements and domain in self.DOMAIN_DATA_PATTERNS:
            # Generate one sample using all domain patterns
            for field_name, generator_func in self.DOMAIN_DATA_PATTERNS[domain].items():
                data[field_name] = generator_func()
        else:
            # Generate based on requirements
            for req in requirements:
                if req.field_name in self.DOMAIN_DATA_PATTERNS.get(domain, {}):
                    # Use domain-specific pattern
                    data[req.field_name] = self.DOMAIN_DATA_PATTERNS[domain][req.field_name]()
                else:
                    # Generate based on type
                    data[req.field_name] = self._generate_value_by_type(req.data_type, req.constraints)
        
        return data
    
    def _generate_normal_data(self, requirements: List[DataRequirement], 
                             domain: str, count: int) -> List[Dict[str, Any]]:
        """Generate normal realistic dataset"""
        data_list = []
        
        # If no requirements provided, use domain defaults
        if not requirements and domain in self.DOMAIN_DATA_PATTERNS:
            # Generate data using all domain patterns
            for i in range(count):
                record = {}
                for field_name, generator_func in self.DOMAIN_DATA_PATTERNS[domain].items():
                    record[field_name] = generator_func()
                data_list.append(record)
        else:
            # Generate data based on requirements
            for i in range(count):
                record = {}
                for req in requirements:
                    if req.field_name in self.DOMAIN_DATA_PATTERNS.get(domain, {}):
                        record[req.field_name] = self.DOMAIN_DATA_PATTERNS[domain][req.field_name]()
                    else:
                        record[req.field_name] = self._generate_value_by_type(req.data_type, req.constraints)
                
                data_list.append(record)
        
        # Add correlations for realism
        if domain == 'ecommerce':
            self._add_ecommerce_correlations(data_list)
        elif domain == 'finance':
            self._add_finance_correlations(data_list)
        
        return data_list
    
    def _generate_edge_cases(self, requirements: List[DataRequirement]) -> List[Dict[str, Any]]:
        """Generate edge case data"""
        edge_cases = []
        
        for req in requirements:
            if req.data_type in self.EDGE_CASE_PATTERNS:
                for edge_value in self.EDGE_CASE_PATTERNS[req.data_type]:
                    edge_case = {req.field_name: edge_value}
                    # Fill other fields with normal values
                    for other_req in requirements:
                        if other_req.field_name != req.field_name:
                            edge_case[other_req.field_name] = self._generate_value_by_type(
                                other_req.data_type, other_req.constraints
                            )
                    edge_cases.append(edge_case)
        
        return edge_cases
    
    def _generate_error_cases(self, requirements: List[DataRequirement]) -> List[Dict[str, Any]]:
        """Generate error-inducing data"""
        error_cases = []
        
        # Type mismatch cases
        for req in requirements:
            if req.data_type != 'any':
                error_case = {}
                # Wrong type for this field
                wrong_types = {
                    'string': 123,
                    'number': 'abc',
                    'list': 'not_a_list',
                    'dict': ['not', 'a', 'dict'],
                    'bool': 'yes'
                }
                if req.data_type in wrong_types:
                    error_case[req.field_name] = wrong_types[req.data_type]
                    # Fill other fields normally
                    for other_req in requirements:
                        if other_req.field_name != req.field_name:
                            error_case[other_req.field_name] = self._generate_value_by_type(
                                other_req.data_type, other_req.constraints
                            )
                    error_cases.append(error_case)
        
        # Missing required fields
        for req in requirements:
            if req.is_required:
                error_case = {}
                for other_req in requirements:
                    if other_req.field_name != req.field_name:
                        error_case[other_req.field_name] = self._generate_value_by_type(
                            other_req.data_type, other_req.constraints
                        )
                error_cases.append(error_case)
        
        return error_cases
    
    def _generate_stress_data(self, requirements: List[DataRequirement], 
                             domain: str, count: int) -> List[Dict[str, Any]]:
        """Generate large dataset for stress testing"""
        # Similar to normal data but with more volume
        return self._generate_normal_data(requirements, domain, count)
    
    def _generate_value_by_type(self, data_type: str, constraints: Dict[str, Any]) -> Any:
        """Generate value based on type and constraints"""
        if data_type == 'string' or data_type == 'str':
            length = constraints.get('length', 10)
            return ''.join(random.choices(string.ascii_letters, k=int(length)))
        elif data_type in ['number', 'int', 'float']:
            min_val = float(constraints.get('min', 0))
            max_val = float(constraints.get('max', 1000))
            if data_type == 'int':
                return random.randint(int(min_val), int(max_val))
            else:
                return round(random.uniform(min_val, max_val), 2)
        elif data_type == 'bool':
            return random.choice([True, False])
        elif data_type == 'list':
            return [self._generate_value_by_type('string', {}) for _ in range(3)]
        elif data_type == 'dict':
            return {'key': 'value', 'number': 42}
        elif data_type == 'date':
            return datetime.now().isoformat()
        else:
            return 'sample_value'
    
    def _add_ecommerce_correlations(self, data_list: List[Dict[str, Any]]):
        """Add realistic correlations for e-commerce data"""
        for record in data_list:
            # VIP customers tend to have higher order amounts
            if record.get('customer_tier') == 'VIP':
                record['order_amount'] = record.get('order_amount', 100) * 2.5
            
            # Electronics tend to be more expensive
            if record.get('product_category') == 'Electronics':
                record['order_amount'] = record.get('order_amount', 100) * 1.8
    
    def _add_finance_correlations(self, data_list: List[Dict[str, Any]]):
        """Add realistic correlations for finance data"""
        for record in data_list:
            # Large transactions have higher risk scores
            if record.get('transaction_amount', 0) > 10000:
                record['risk_score'] = min(record.get('risk_score', 0.5) * 1.5, 1.0)
    
    def _needs_stress_test(self, requirements: List[DataRequirement]) -> bool:
        """Determine if stress testing is needed"""
        # Stress test if dealing with collections or performance-critical fields
        for req in requirements:
            if req.data_type in ['list', 'array'] or 'performance' in req.field_name.lower():
                return True
        return False


# Example usage
if __name__ == "__main__":
    sample_code = '''
def process_order(customer_id: str, order_amount: float, customer_tier: str):
    """Process customer order with tier-based discounts"""
    if order_amount > 1000 and customer_tier == "VIP":
        discount = 0.2
    elif order_amount > 500:
        discount = 0.1
    else:
        discount = 0
    
    final_amount = order_amount * (1 - discount)
    return {
        "customer_id": customer_id,
        "original_amount": order_amount,
        "discount_applied": discount,
        "final_amount": final_amount
    }
'''
    
    generator = IntelligentDataGenerator()
    
    # Extract requirements
    requirements = generator.analyze_code_requirements(sample_code)
    print("Extracted requirements:")
    for req in requirements:
        print(f"  - {req.field_name}: {req.data_type}")
    
    # Generate test data
    test_suite = generator.generate_test_data(requirements, domain='ecommerce')
    
    print("\nMinimal test data:")
    print(json.dumps(test_suite.minimal, indent=2))
    
    print("\nSample normal data (first 3 records):")
    print(json.dumps(test_suite.normal[:3], indent=2))
    
    print(f"\nGenerated {len(test_suite.edge_cases)} edge cases")
    print(f"Generated {len(test_suite.error_cases)} error cases")