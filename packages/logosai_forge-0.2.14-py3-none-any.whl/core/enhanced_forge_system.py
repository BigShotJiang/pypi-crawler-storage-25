"""
Enhanced FORGE System with Intelligent Error Handling
지능형 에러 처리가 통합된 향상된 FORGE 시스템
"""

import asyncio
import logging
from typing import Dict, Any, Optional
from datetime import datetime
import google.generativeai as genai
import os

import sys
from pathlib import Path

# Add forge/core to path for absolute imports
forge_core_path = Path(__file__).parent
if str(forge_core_path) not in sys.path:
    sys.path.insert(0, str(forge_core_path))

from final_forge_system import FinalForgeSystem
from intelligent_error_handler import (
    IntelligentErrorHandler, 
    ErrorType, 
    ErrorContext,
    RecoveryStrategy
)
from retry_handler import SmartRetryManager
from enhanced_query_analyzer import EnhancedQueryAnalyzer
from ast_code_generator import ForgeASTGenerator

logger = logging.getLogger(__name__)


class EnhancedForgeSystem(FinalForgeSystem):
    """지능형 에러 처리가 통합된 향상된 FORGE 시스템"""
    
    def __init__(self):
        super().__init__()
        
        # LLM Manager 초기화 (템플릿 로직 커스터마이징용)
        self.llm_manager = None
        self._llm_manager = None
        try:
            from llm_manager import FORGELLMManager
            self.llm_manager = FORGELLMManager()
            self._llm_manager = self.llm_manager
            logger.info("✅ LLM Manager initialized for template customization")
        except Exception as e:
            logger.warning(f"⚠️ LLM Manager initialization failed: {e}")
            # LLM Manager가 없어도 기본 템플릿은 작동하도록 함
        
        # 지능형 컴포넌트 초기화 (LLM Manager를 AST Generator에 전달)
        self.error_handler = IntelligentErrorHandler()
        self.retry_manager = SmartRetryManager()
        self.query_analyzer = EnhancedQueryAnalyzer()
        self.ast_generator = ForgeASTGenerator(llm_client=self.llm_manager)
        
        # 메트릭 추적
        self.metrics = {
            'total_requests': 0,
            'successful_generations': 0,
            'auto_fixed_errors': 0,
            'fallback_used': 0,
            'avg_generation_time': 0.0
        }
    
    async def generate_agent_with_intelligence(
        self, 
        query: str, 
        user_email: str = "user@forge.ai"
    ) -> Dict[str, Any]:
        """지능형 에러 처리를 포함한 에이전트 생성"""
        
        start_time = datetime.now()
        self.metrics['total_requests'] += 1
        
        try:
            # 1️⃣ 향상된 쿼리 분석
            logger.info("🧠 Step 1: Enhanced Query Analysis")
            analysis_result = self.query_analyzer.analyze_query(query)
            
            context = {
                'query': query,
                'user_email': user_email,
                'agent_type': analysis_result.intent.value,
                'domain': analysis_result.domain.value,
                'features': analysis_result.features,
                'complexity': analysis_result.complexity_score,
                'libraries': analysis_result.required_libraries,
                'estimated_size': analysis_result.estimated_code_size
            }
            
            logger.info(f"📊 Analysis: {context['agent_type']} agent, {context['complexity']:.1%} complexity")
            
            # 2️⃣ 템플릿 우선 시도
            logger.info("📚 Step 2: Template-First Generation")
            
            # Try to use template system first
            template_business_logic = None
            if self.template_matcher:
                try:
                    logger.info("🎯 Checking template system...")
                    template_business_logic = self._get_logosai_core_business_logic({
                        'original_query': query,
                        'agent_type': context['agent_type'],
                        'description': query
                    })
                    if template_business_logic and len(template_business_logic) > 100:
                        logger.info(f"✅ Template-based business logic found: {len(template_business_logic)} characters")
                        context['business_logic'] = template_business_logic
                        context['template_used'] = True
                except Exception as e:
                    logger.warning(f"⚠️ Template system failed: {e}")
            
            # 3️⃣ 스마트 재시도로 LLM 생성 (템플릿이 없을 때만)
            if not template_business_logic:
                logger.info("🤖 Step 3: Smart LLM Generation with Retry")
                
                generation_result = await self._generate_with_smart_retry(context)
                
                if not generation_result['success']:
                    # 4️⃣ 지능형 에러 처리
                    logger.warning("⚠️ Generation failed, attempting intelligent recovery")
                    recovery_result = await self._handle_generation_error(
                        generation_result.get('error'),
                        context
                    )
                    
                    if recovery_result['success']:
                        generation_result = recovery_result
                        self.metrics['auto_fixed_errors'] += 1
            else:
                # Use template-based result - Generate full agent code from template business logic
                logger.info("🎯 Generating agent code from template business logic")
                
                # Use AST generator to create complete agent from template business logic
                agent_code = self.ast_generator.create_logosai_agent_ast(
                    agent_name=f"{context['agent_type'].title()}Agent",
                    agent_class_name=f"{context['agent_type'].title()}Agent",
                    description=context['query'],
                    agent_type=context['agent_type'],
                    business_logic_text=context.get('business_logic', '')
                )
                
                generation_result = {
                    'success': True,
                    'code': agent_code,  # Now we have the code!
                    'result': context,
                    'metadata': {'template_used': True},
                    'model': 'template-based',
                    'attempts': 1
                }
            
            # 4️⃣ AST 검증 및 자동 수정
            logger.info("🔧 Step 3: AST Validation and Auto-Fix")
            final_code = await self._validate_and_fix_code(
                generation_result.get('code', ''),
                context
            )
            
            # 5️⃣ 데이터베이스 저장
            logger.info("💾 Step 4: Save to Database")
            agent_id = await self._save_agent_to_db(final_code, context)
            
            # 메트릭 업데이트
            generation_time = (datetime.now() - start_time).total_seconds()
            self._update_metrics(True, generation_time)
            
            return {
                'success': True,
                'agent_id': agent_id,
                'code': final_code,
                'metadata': {
                    'generation_time': generation_time,
                    'complexity': context['complexity'],
                    'features': context['features'],
                    'auto_fixes_applied': generation_result.get('fixes_applied', 0),
                    'model_used': generation_result.get('model', 'unknown')
                },
                'statistics': self.get_statistics()
            }
            
        except Exception as e:
            logger.error(f"❌ Fatal error in generation: {e}")
            
            # 최종 폴백
            fallback_result = await self._ultimate_fallback(query, str(e))
            self.metrics['fallback_used'] += 1
            
            generation_time = (datetime.now() - start_time).total_seconds()
            self._update_metrics(False, generation_time)
            
            return fallback_result
    
    async def _generate_with_smart_retry(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """스마트 재시도를 사용한 생성"""
        
        retry_result = await self.retry_manager.execute_with_smart_retry(
            query=context['query'],
            task_type="generate_code"
        )
        
        if retry_result.success:
            # 템플릿에서 가져온 비즈니스 로직이 있으면 사용
            business_logic = context.get('business_logic', retry_result.result)
            
            # 생성된 코드를 AST로 완전한 에이전트로 변환
            agent_code = self.ast_generator.create_logosai_agent_ast(
                agent_name=f"{context['agent_type'].title()}Agent",
                agent_class_name=f"{context['agent_type'].title()}Agent",
                description=context['query'],
                agent_type=context['agent_type'],
                business_logic_text=business_logic
            )
            
            return {
                'success': True,
                'code': agent_code,
                'model': retry_result.final_model,
                'attempts': retry_result.attempts
            }
        else:
            return {
                'success': False,
                'error': f"All models failed after {retry_result.attempts} attempts",
                'errors': retry_result.errors
            }
    
    async def _handle_generation_error(
        self, 
        error: Any, 
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """지능형 에러 처리"""
        
        error_result = await self.error_handler.handle_error(
            error if error else Exception("Generation failed"),
            context
        )
        
        if error_result.get('regenerate'):
            # 수정된 프롬프트로 재생성
            logger.info("🔄 Regenerating with modified prompt")
            
            # Gemini Lite로 재시도
            try:
                gemini_api_key = os.getenv('GEMINI_API_KEY', os.getenv('GOOGLE_API_KEY', ''))
                genai.configure(api_key=gemini_api_key)
                model = genai.GenerativeModel('gemini-2.5-flash-lite')
                
                response = model.generate_content(error_result['prompt'])
                
                return {
                    'success': True,
                    'code': response.text,
                    'model': 'gemini-lite-recovery',
                    'fixes_applied': 1
                }
            except Exception as e:
                logger.error(f"Recovery generation failed: {e}")
        
        elif error_result.get('simplify'):
            # 단순화된 요구사항으로 재생성
            logger.info("📉 Simplifying requirements")
            context['features'] = error_result['features']
            return await self._generate_with_smart_retry(context)
        
        elif error_result.get('decompose'):
            # 작업 분해
            logger.info("🔀 Decomposing task")
            subtasks = error_result['subtasks']
            
            # 첫 번째 서브태스크만 처리 (데모)
            if subtasks:
                context['query'] = subtasks[0]['query']
                return await self._generate_with_smart_retry(context)
        
        elif error_result.get('fallback'):
            # 템플릿 폴백 사용
            return {
                'success': True,
                'code': error_result['code'],
                'model': 'template-fallback',
                'fixes_applied': 0
            }
        
        return {'success': False, 'error': 'Recovery failed'}
    
    async def _validate_and_fix_code(
        self, 
        code: str, 
        context: Dict[str, Any]
    ) -> str:
        """코드 검증 및 자동 수정"""
        
        # Simple AST validation
        try:
            import ast
            ast.parse(code)
            logger.info("✅ Code validation passed")
            return code
        except SyntaxError as e:
            logger.warning(f"⚠️ Code validation failed: {e}")
            
            # 자동 수정 시도
            error_context = ErrorContext(
                error_type=ErrorType.SYNTAX_ERROR,
                error_message=str(e),
                error_traceback="",
                query=code,
                agent_type=context['agent_type'],
                features=context['features'],
                attempt_number=1,
                previous_attempts=[],
                timestamp=datetime.now().timestamp()
            )
            
            fix_result = await self.error_handler._attempt_auto_fix(error_context)
            
            if fix_result['success']:
                code = fix_result['fix']
                logger.info(f"✅ Auto-fixed syntax error")
            
        return code
    
    async def _save_agent_to_db(self, code: str, context: Dict[str, Any]) -> str:
        """데이터베이스에 에이전트 저장"""
        
        # 기존 FinalForgeSystem의 저장 로직 활용
        agent_id = f"agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{context['agent_type']}"
        
        # 실제 DB 저장 로직 (생략)
        logger.info(f"💾 Agent saved with ID: {agent_id}")
        
        return agent_id
    
    async def _ultimate_fallback(self, query: str, error: str) -> Dict[str, Any]:
        """최종 폴백 메커니즘"""
        
        template = f"""
from logosai.agent import LogosAIAgent
from logosai.config import AgentConfig

class FallbackAgent(LogosAIAgent):
    '''Fallback agent generated due to system error'''
    
    def __init__(self):
        config = AgentConfig(
            name="Fallback Agent",
            description="Generated after error: {error[:100]}"
        )
        super().__init__(config)
    
    async def _process_core_logic(self, extracted_info):
        # Fallback implementation
        return {{
            'status': 'fallback',
            'message': 'This is a fallback agent',
            'query': '{query[:100]}',
            'data': extracted_info
        }}
"""
        
        return {
            'success': False,
            'code': template,
            'error': error,
            'fallback': True
        }
    
    def _update_metrics(self, success: bool, generation_time: float):
        """메트릭 업데이트"""
        if success:
            self.metrics['successful_generations'] += 1
        
        # 평균 생성 시간 업데이트
        total = self.metrics['total_requests']
        current_avg = self.metrics['avg_generation_time']
        self.metrics['avg_generation_time'] = (
            (current_avg * (total - 1) + generation_time) / total
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """시스템 통계 반환"""
        
        error_stats = self.error_handler.get_error_statistics()
        
        return {
            'forge_metrics': self.metrics,
            'error_statistics': error_stats,
            'success_rate': (
                self.metrics['successful_generations'] / self.metrics['total_requests']
                if self.metrics['total_requests'] > 0 else 0
            ),
            'auto_fix_rate': (
                self.metrics['auto_fixed_errors'] / self.metrics['total_requests']
                if self.metrics['total_requests'] > 0 else 0
            )
        }


# 사용 예제
async def main():
    forge = EnhancedForgeSystem()
    
    # 다양한 쿼리 테스트
    test_queries = [
        "주식 트레이딩 봇을 만들어줘. 실시간 데이터 분석과 매매 신호 생성 기능이 필요해",
        "고객 서비스 챗봇 에이전트를 생성해줘",
        "이미지에서 객체를 탐지하는 컴퓨터 비전 에이전트"
    ]
    
    for query in test_queries:
        logger.info(f"\n{'='*60}")
        logger.info(f"Testing: {query}")
        logger.info(f"{'='*60}")
        
        result = await forge.generate_agent_with_intelligence(query)
        
        if result['success']:
            logger.info(f"✅ Success! Agent ID: {result.get('agent_id')}")
            logger.info(f"📊 Generation time: {result['metadata']['generation_time']:.2f}s")
            logger.info(f"🔧 Auto-fixes applied: {result['metadata']['auto_fixes_applied']}")
            logger.info(f"🤖 Model used: {result['metadata']['model_used']}")
        else:
            logger.error(f"❌ Failed: {result.get('error')}")
            if result.get('fallback'):
                logger.info("📦 Fallback template was used")
    
    # 통계 출력
    stats = forge.get_statistics()
    logger.info(f"\n📈 Final Statistics:")
    logger.info(f"Success Rate: {stats['success_rate']:.1%}")
    logger.info(f"Auto-Fix Rate: {stats['auto_fix_rate']:.1%}")
    logger.info(f"Average Generation Time: {stats['forge_metrics']['avg_generation_time']:.2f}s")


if __name__ == "__main__":
    asyncio.run(main())