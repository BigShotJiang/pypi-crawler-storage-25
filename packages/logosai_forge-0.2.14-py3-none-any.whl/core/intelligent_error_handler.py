"""
Intelligent Error Handler for FORGE AI System
지능형 에러 처리 및 자가 치유 시스템
"""

import asyncio
import time
import re
import ast
import json
import logging
from typing import Any, Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict, deque
import traceback
import hashlib

logger = logging.getLogger(__name__)


class ErrorType(Enum):
    """에러 타입 분류"""
    SYNTAX_ERROR = "syntax_error"           # 문법 오류
    IMPORT_ERROR = "import_error"           # 임포트 오류
    INDENTATION_ERROR = "indentation_error" # 들여쓰기 오류
    TOKEN_LIMIT = "token_limit"             # 토큰 한도 초과
    TIMEOUT = "timeout"                     # 타임아웃
    API_ERROR = "api_error"                 # API 오류
    RATE_LIMIT = "rate_limit"              # API 사용량 제한
    NETWORK_ERROR = "network_error"         # 네트워크 오류
    VALIDATION_ERROR = "validation_error"   # 검증 오류
    BUSINESS_LOGIC = "business_logic"       # 비즈니스 로직 오류
    UNKNOWN = "unknown"                     # 알 수 없는 오류


class RecoveryStrategy(Enum):
    """복구 전략"""
    AUTO_FIX = "auto_fix"                   # 자동 수정
    REGENERATE = "regenerate"               # 재생성
    SIMPLIFY = "simplify"                   # 단순화
    DECOMPOSE = "decompose"                 # 분해
    FALLBACK = "fallback"                   # 폴백
    RETRY = "retry"                         # 재시도
    CIRCUIT_BREAK = "circuit_break"         # 회로 차단
    MANUAL = "manual"                       # 수동 개입 필요


@dataclass
class ErrorContext:
    """에러 컨텍스트"""
    error_type: ErrorType
    error_message: str
    error_traceback: str
    query: str
    agent_type: str
    features: List[str]
    attempt_number: int
    previous_attempts: List[Dict]
    timestamp: float
    recovery_strategy: Optional[RecoveryStrategy] = None
    fix_applied: Optional[str] = None
    
    def to_hash(self) -> str:
        """에러 패턴 해시 생성"""
        pattern = f"{self.error_type.value}:{self.error_message[:100]}"
        return hashlib.md5(pattern.encode()).hexdigest()


@dataclass
class ErrorPattern:
    """에러 패턴 학습"""
    pattern_hash: str
    error_type: ErrorType
    occurrences: int = 0
    successful_fixes: List[str] = field(default_factory=list)
    failed_fixes: List[str] = field(default_factory=list)
    avg_recovery_time: float = 0.0
    last_seen: float = 0.0
    
    def success_rate(self) -> float:
        total = len(self.successful_fixes) + len(self.failed_fixes)
        return len(self.successful_fixes) / total if total > 0 else 0.0


class CircuitBreaker:
    """Circuit Breaker 패턴 구현"""
    
    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 60.0):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.last_failure_time = 0.0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        
    def call(self, func: Callable, *args, **kwargs):
        """회로 차단기를 통한 호출"""
        if self.state == "OPEN":
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = "HALF_OPEN"
                logger.info("Circuit breaker entering HALF_OPEN state")
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = func(*args, **kwargs)
            if self.state == "HALF_OPEN":
                self.state = "CLOSED"
                self.failure_count = 0
                logger.info("Circuit breaker recovered to CLOSED state")
            return result
            
        except Exception as e:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
                logger.warning(f"Circuit breaker OPEN after {self.failure_count} failures")
            
            raise e


class IntelligentErrorHandler:
    """지능형 에러 핸들러"""
    
    def __init__(self):
        # 에러 패턴 학습 저장소
        self.error_patterns: Dict[str, ErrorPattern] = {}
        
        # 에러 히스토리 (최근 100개)
        self.error_history = deque(maxlen=100)
        
        # 회로 차단기 (서비스별)
        self.circuit_breakers = {
            "gemini": CircuitBreaker(),
            "openai": CircuitBreaker(),
            "claude": CircuitBreaker()
        }
        
        # 자동 수정 전략
        self.auto_fix_strategies = {
            ErrorType.SYNTAX_ERROR: self._fix_syntax_error,
            ErrorType.INDENTATION_ERROR: self._fix_indentation,
            ErrorType.IMPORT_ERROR: self._fix_imports,
            ErrorType.TOKEN_LIMIT: self._reduce_tokens,
            ErrorType.VALIDATION_ERROR: self._fix_validation
        }
        
    async def handle_error(self, error: Exception, context: Dict[str, Any]) -> Dict[str, Any]:
        """지능형 에러 처리"""
        
        # 1. 에러 분석
        error_context = self._analyze_error(error, context)
        
        # 2. 에러 패턴 학습
        self._learn_from_error(error_context)
        
        # 3. 복구 전략 결정
        recovery_strategy = self._determine_recovery_strategy(error_context)
        error_context.recovery_strategy = recovery_strategy
        
        # 4. 자가 치유 시도
        if recovery_strategy == RecoveryStrategy.AUTO_FIX:
            fixed_result = await self._attempt_auto_fix(error_context)
            if fixed_result['success']:
                self._record_successful_fix(error_context, fixed_result['fix'])
                return fixed_result
        
        # 5. 대체 전략 실행
        return await self._execute_recovery_strategy(error_context)
    
    def _analyze_error(self, error: Exception, context: Dict[str, Any]) -> ErrorContext:
        """에러 분석 및 분류"""
        
        error_type = ErrorType.UNKNOWN
        error_msg = str(error)
        
        # 에러 타입 분류
        if isinstance(error, SyntaxError):
            error_type = ErrorType.SYNTAX_ERROR
        elif isinstance(error, IndentationError):
            error_type = ErrorType.INDENTATION_ERROR
        elif isinstance(error, ImportError):
            error_type = ErrorType.IMPORT_ERROR
        elif "token" in error_msg.lower() or "limit" in error_msg.lower():
            error_type = ErrorType.TOKEN_LIMIT
        elif isinstance(error, asyncio.TimeoutError):
            error_type = ErrorType.TIMEOUT
        elif "rate limit" in error_msg.lower():
            error_type = ErrorType.RATE_LIMIT
        elif "network" in error_msg.lower() or "connection" in error_msg.lower():
            error_type = ErrorType.NETWORK_ERROR
        elif "validation" in error_msg.lower():
            error_type = ErrorType.VALIDATION_ERROR
        
        return ErrorContext(
            error_type=error_type,
            error_message=error_msg,
            error_traceback=traceback.format_exc(),
            query=context.get('query', ''),
            agent_type=context.get('agent_type', ''),
            features=context.get('features', []),
            attempt_number=context.get('attempt', 1),
            previous_attempts=context.get('previous_attempts', []),
            timestamp=time.time()
        )
    
    def _learn_from_error(self, error_context: ErrorContext):
        """에러 패턴 학습"""
        pattern_hash = error_context.to_hash()
        
        if pattern_hash not in self.error_patterns:
            self.error_patterns[pattern_hash] = ErrorPattern(
                pattern_hash=pattern_hash,
                error_type=error_context.error_type
            )
        
        pattern = self.error_patterns[pattern_hash]
        pattern.occurrences += 1
        pattern.last_seen = time.time()
        
        # 히스토리 추가
        self.error_history.append(error_context)
        
        # 패턴 분석
        if pattern.occurrences > 3:
            logger.warning(f"Recurring error pattern detected: {pattern_hash} ({pattern.occurrences} times)")
    
    def _determine_recovery_strategy(self, error_context: ErrorContext) -> RecoveryStrategy:
        """복구 전략 결정"""
        
        # 이전 성공 패턴 확인
        pattern_hash = error_context.to_hash()
        if pattern_hash in self.error_patterns:
            pattern = self.error_patterns[pattern_hash]
            if pattern.success_rate() > 0.7 and pattern.successful_fixes:
                return RecoveryStrategy.AUTO_FIX
        
        # 에러 타입별 기본 전략
        strategy_map = {
            ErrorType.SYNTAX_ERROR: RecoveryStrategy.AUTO_FIX,
            ErrorType.INDENTATION_ERROR: RecoveryStrategy.AUTO_FIX,
            ErrorType.IMPORT_ERROR: RecoveryStrategy.AUTO_FIX,
            ErrorType.TOKEN_LIMIT: RecoveryStrategy.SIMPLIFY,
            ErrorType.TIMEOUT: RecoveryStrategy.DECOMPOSE,
            ErrorType.RATE_LIMIT: RecoveryStrategy.RETRY,
            ErrorType.API_ERROR: RecoveryStrategy.FALLBACK,
            ErrorType.NETWORK_ERROR: RecoveryStrategy.RETRY,
            ErrorType.VALIDATION_ERROR: RecoveryStrategy.REGENERATE
        }
        
        return strategy_map.get(error_context.error_type, RecoveryStrategy.FALLBACK)
    
    async def _attempt_auto_fix(self, error_context: ErrorContext) -> Dict[str, Any]:
        """자동 수정 시도"""
        
        fix_strategy = self.auto_fix_strategies.get(error_context.error_type)
        if not fix_strategy:
            return {'success': False, 'reason': 'No auto-fix strategy available'}
        
        try:
            fixed_content = await fix_strategy(error_context)
            return {
                'success': True,
                'fix': fixed_content,
                'strategy': error_context.error_type.value
            }
        except Exception as e:
            logger.error(f"Auto-fix failed: {e}")
            return {'success': False, 'reason': str(e)}
    
    async def _fix_syntax_error(self, error_context: ErrorContext) -> str:
        """문법 오류 자동 수정"""
        code = error_context.query  # 실제로는 생성된 코드
        
        # 일반적인 문법 오류 패턴 수정
        fixes = [
            (r'(\w+)\s*\(\s*\)', r'\1()'),  # 함수 호출 괄호
            (r':\s*$', ':'),  # 콜론 뒤 공백
            (r'^\s*except\s+(\w+)\s*$', r'except \1:'),  # except 문
            (r'^\s*else\s*$', r'else:'),  # else 문
        ]
        
        for pattern, replacement in fixes:
            code = re.sub(pattern, replacement, code, flags=re.MULTILINE)
        
        # AST로 검증
        try:
            ast.parse(code)
            return code
        except SyntaxError as e:
            # 더 복잡한 수정 필요
            logger.debug(f"Complex syntax error: {e}")
            raise
    
    async def _fix_indentation(self, error_context: ErrorContext) -> str:
        """들여쓰기 오류 수정"""
        code = error_context.query
        
        # 스마트 들여쓰기 수정
        lines = code.split('\n')
        fixed_lines = []
        indent_level = 0
        
        for line in lines:
            stripped = line.lstrip()
            if not stripped or stripped.startswith('#'):
                fixed_lines.append(line)
                continue
            
            # 들여쓰기 레벨 조정
            if stripped.startswith(('def ', 'class ', 'if ', 'elif ', 'else:', 'for ', 'while ', 'try:', 'except', 'finally:', 'with ')):
                fixed_lines.append('    ' * indent_level + stripped)
                if stripped.endswith(':'):
                    indent_level += 1
            elif stripped in ('pass', 'break', 'continue', 'return'):
                fixed_lines.append('    ' * indent_level + stripped)
                indent_level = max(0, indent_level - 1)
            else:
                fixed_lines.append('    ' * indent_level + stripped)
        
        return '\n'.join(fixed_lines)
    
    async def _fix_imports(self, error_context: ErrorContext) -> str:
        """임포트 오류 수정"""
        code = error_context.query
        missing_module = re.search(r"No module named '(\w+)'", error_context.error_message)
        
        if missing_module:
            module_name = missing_module.group(1)
            
            # 표준 라이브러리 매핑
            import_map = {
                'numpy': 'import numpy as np',
                'pandas': 'import pandas as pd',
                'requests': 'import requests',
                'beautifulsoup4': 'from bs4 import BeautifulSoup',
                'sklearn': 'from sklearn import *',
            }
            
            if module_name in import_map:
                # 코드 앞에 임포트 추가
                return import_map[module_name] + '\n\n' + code
        
        return code
    
    async def _reduce_tokens(self, error_context: ErrorContext) -> str:
        """토큰 수 줄이기"""
        query = error_context.query
        
        # 1. 불필요한 공백 제거
        query = re.sub(r'\s+', ' ', query)
        
        # 2. 주석 제거
        query = re.sub(r'#.*$', '', query, flags=re.MULTILINE)
        
        # 3. 중복 제거
        lines = query.split('\n')
        seen = set()
        unique_lines = []
        for line in lines:
            if line not in seen:
                seen.add(line)
                unique_lines.append(line)
        
        return '\n'.join(unique_lines)
    
    async def _fix_validation(self, error_context: ErrorContext) -> str:
        """검증 오류 수정"""
        # 검증 규칙에 맞게 수정
        code = error_context.query
        
        # LogosAI 에이전트 필수 구조 확인
        if 'class' not in code:
            code = f"""
class GeneratedAgent(LogosAIAgent):
    def __init__(self):
        super().__init__(AgentConfig(name="Generated"))
    
    async def _process_core_logic(self, extracted_info):
        {code}
"""
        
        return code
    
    async def _execute_recovery_strategy(self, error_context: ErrorContext) -> Dict[str, Any]:
        """복구 전략 실행"""
        
        strategy = error_context.recovery_strategy
        
        if strategy == RecoveryStrategy.REGENERATE:
            # 다른 프롬프트로 재생성
            return await self._regenerate_with_modified_prompt(error_context)
            
        elif strategy == RecoveryStrategy.SIMPLIFY:
            # 요구사항 단순화
            return await self._simplify_requirements(error_context)
            
        elif strategy == RecoveryStrategy.DECOMPOSE:
            # 작업 분해
            return await self._decompose_task(error_context)
            
        elif strategy == RecoveryStrategy.RETRY:
            # 지수 백오프로 재시도
            await asyncio.sleep(2 ** error_context.attempt_number)
            return {'retry': True}
            
        elif strategy == RecoveryStrategy.FALLBACK:
            # 템플릿 폴백
            return self._get_template_fallback(error_context)
            
        else:
            return {'success': False, 'strategy': strategy.value}
    
    async def _regenerate_with_modified_prompt(self, error_context: ErrorContext) -> Dict[str, Any]:
        """수정된 프롬프트로 재생성"""
        
        # 에러 정보를 프롬프트에 추가
        modified_prompt = f"""
Previous attempt failed with: {error_context.error_type.value}
Error: {error_context.error_message}

Please generate the code again, avoiding this error.
Original query: {error_context.query}

Requirements:
1. Fix the {error_context.error_type.value}
2. Ensure the code is syntactically correct
3. Include proper error handling
"""
        
        return {
            'success': True,
            'regenerate': True,
            'prompt': modified_prompt
        }
    
    async def _simplify_requirements(self, error_context: ErrorContext) -> Dict[str, Any]:
        """요구사항 단순화"""
        
        # 기능 우선순위 정하기
        essential_features = error_context.features[:3] if len(error_context.features) > 3 else error_context.features
        
        return {
            'success': True,
            'simplify': True,
            'features': essential_features,
            'message': f"Simplified to essential features: {', '.join(essential_features)}"
        }
    
    async def _decompose_task(self, error_context: ErrorContext) -> Dict[str, Any]:
        """작업 분해"""
        
        # 복잡한 작업을 여러 단계로 분해
        subtasks = []
        for i, feature in enumerate(error_context.features):
            subtasks.append({
                'step': i + 1,
                'feature': feature,
                'query': f"Implement {feature} for {error_context.agent_type}"
            })
        
        return {
            'success': True,
            'decompose': True,
            'subtasks': subtasks,
            'message': f"Decomposed into {len(subtasks)} subtasks"
        }
    
    def _get_template_fallback(self, error_context: ErrorContext) -> Dict[str, Any]:
        """템플릿 폴백"""
        
        template = f"""
class {error_context.agent_type.replace(' ', '')}Agent(LogosAIAgent):
    def __init__(self):
        super().__init__(AgentConfig(
            name="{error_context.agent_type}",
            description="Auto-generated agent after error recovery"
        ))
    
    async def _process_core_logic(self, extracted_info):
        # Template fallback due to: {error_context.error_type.value}
        try:
            result = {{
                'status': 'success',
                'message': 'Processing completed (template)',
                'data': extracted_info
            }}
            return result
        except Exception as e:
            logger.error(f"Error: {{e}}")
            return {{'status': 'error', 'error': str(e)}}
"""
        
        return {
            'success': True,
            'fallback': True,
            'code': template,
            'message': f"Using template fallback due to {error_context.error_type.value}"
        }
    
    def _record_successful_fix(self, error_context: ErrorContext, fix: str):
        """성공적인 수정 기록"""
        pattern_hash = error_context.to_hash()
        
        if pattern_hash in self.error_patterns:
            pattern = self.error_patterns[pattern_hash]
            pattern.successful_fixes.append(fix[:100])  # 처음 100자만 저장
            
            # 평균 복구 시간 업데이트
            recovery_time = time.time() - error_context.timestamp
            pattern.avg_recovery_time = (
                (pattern.avg_recovery_time * (pattern.occurrences - 1) + recovery_time) 
                / pattern.occurrences
            )
    
    def get_error_statistics(self) -> Dict[str, Any]:
        """에러 통계 반환"""
        
        stats = {
            'total_errors': len(self.error_history),
            'error_types': defaultdict(int),
            'recovery_strategies': defaultdict(int),
            'success_rates': {},
            'avg_recovery_times': {},
            'circuit_breaker_states': {}
        }
        
        # 에러 타입별 통계
        for error in self.error_history:
            stats['error_types'][error.error_type.value] += 1
            if error.recovery_strategy:
                stats['recovery_strategies'][error.recovery_strategy.value] += 1
        
        # 패턴별 성공률
        for pattern_hash, pattern in self.error_patterns.items():
            stats['success_rates'][pattern.error_type.value] = pattern.success_rate()
            stats['avg_recovery_times'][pattern.error_type.value] = pattern.avg_recovery_time
        
        # 회로 차단기 상태
        for name, breaker in self.circuit_breakers.items():
            stats['circuit_breaker_states'][name] = breaker.state
        
        return stats


# 사용 예제
async def example_usage():
    handler = IntelligentErrorHandler()
    
    # 에러 발생 시뮬레이션
    try:
        # 코드 생성 중 에러 발생
        raise SyntaxError("unexpected EOF while parsing")
    except Exception as e:
        context = {
            'query': 'Create a trading bot agent',
            'agent_type': 'TradingBot',
            'features': ['real_time_data', 'technical_analysis', 'trading_signals'],
            'attempt': 1
        }
        
        # 지능형 에러 처리
        result = await handler.handle_error(e, context)
        
        if result.get('success'):
            logger.info(f"Error recovered: {result}")
        else:
            logger.error(f"Recovery failed: {result}")
    
    # 통계 확인
    stats = handler.get_error_statistics()
    logger.info(f"Error statistics: {json.dumps(stats, indent=2)}")


if __name__ == "__main__":
    asyncio.run(example_usage())