"""
LLM Integration Module for FORGE AI
====================================
실제 LLM API 통합을 위한 모듈
- OpenAI, Gemini, Claude 지원
- 자동 폴백 메커니즘
- 비용 효율적인 모델 선택
"""

import os
import json
import asyncio
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)

class LLMProvider(Enum):
    """지원되는 LLM 제공자"""
    OPENAI = "openai"
    GEMINI = "gemini"
    CLAUDE = "claude"
    MOCK = "mock"  # 테스트용

@dataclass
class LLMConfig:
    """LLM 설정"""
    provider: LLMProvider
    model: str
    api_key: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 2000
    timeout: int = 30

class LLMClient:
    """통합 LLM 클라이언트"""
    
    def __init__(self, 
                 model: str = "gpt-3.5-turbo", 
                 temperature: float = 0.7,
                 max_tokens: int = 2000):
        """
        LLM 클라이언트 초기화
        
        Args:
            model: 사용할 모델명
            temperature: 생성 온도 (0-1)
            max_tokens: 최대 토큰 수
        """
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.provider = self._detect_provider(model)
        self.client = None
        
        # API 키 확인
        self.api_key = self._get_api_key()
        
        # 클라이언트 초기화
        self._initialize_client()
        
    def _detect_provider(self, model: str) -> LLMProvider:
        """모델명으로 제공자 감지"""
        if "gpt" in model.lower() or "turbo" in model.lower():
            return LLMProvider.OPENAI
        elif "gemini" in model.lower():
            return LLMProvider.GEMINI
        elif "claude" in model.lower():
            return LLMProvider.CLAUDE
        else:
            logger.warning(f"Unknown model {model}, using mock provider")
            return LLMProvider.MOCK
    
    def _get_api_key(self) -> Optional[str]:
        """환경변수에서 API 키 가져오기"""
        if self.provider == LLMProvider.OPENAI:
            return os.getenv("OPENAI_API_KEY")
        elif self.provider == LLMProvider.GEMINI:
            return os.getenv("GOOGLE_API_KEY")
        elif self.provider == LLMProvider.CLAUDE:
            return os.getenv("ANTHROPIC_API_KEY")
        return None
    
    def _initialize_client(self):
        """제공자별 클라이언트 초기화"""
        try:
            if self.provider == LLMProvider.OPENAI:
                self._init_openai()
            elif self.provider == LLMProvider.GEMINI:
                self._init_gemini()
            elif self.provider == LLMProvider.CLAUDE:
                self._init_claude()
            else:
                logger.info("Using mock LLM client")
        except Exception as e:
            logger.error(f"Failed to initialize {self.provider.value} client: {e}")
            logger.info("Falling back to mock client")
            self.provider = LLMProvider.MOCK
    
    def _init_openai(self):
        """OpenAI 클라이언트 초기화"""
        try:
            import openai
            if self.api_key:
                openai.api_key = self.api_key
                self.client = openai
                logger.info("OpenAI client initialized")
            else:
                raise ValueError("OpenAI API key not found")
        except ImportError:
            logger.warning("OpenAI library not installed. Run: pip install openai")
            self.provider = LLMProvider.MOCK
    
    def _init_gemini(self):
        """Gemini 클라이언트 초기화"""
        try:
            import google.generativeai as genai
            if self.api_key:
                genai.configure(api_key=self.api_key)
                self.client = genai.GenerativeModel(self.model)
                logger.info("Gemini client initialized")
            else:
                raise ValueError("Google API key not found")
        except ImportError:
            logger.warning("Google Generative AI library not installed. Run: pip install google-generativeai")
            self.provider = LLMProvider.MOCK
    
    def _init_claude(self):
        """Claude 클라이언트 초기화"""
        try:
            import anthropic
            if self.api_key:
                self.client = anthropic.Anthropic(api_key=self.api_key)
                logger.info("Claude client initialized")
            else:
                raise ValueError("Anthropic API key not found")
        except ImportError:
            logger.warning("Anthropic library not installed. Run: pip install anthropic")
            self.provider = LLMProvider.MOCK
    
    async def invoke(self, prompt: str) -> Any:
        """
        간단한 프롬프트 기반 LLM 호출
        
        Args:
            prompt: 단일 프롬프트 문자열
        
        Returns:
            Response object with .content attribute
        """
        # 프롬프트를 메시지 형식으로 변환
        messages = [{"role": "user", "content": prompt}]
        return await self.invoke_messages(messages)
    
    async def invoke_messages(self, messages: List[Dict[str, str]]) -> Any:
        """
        메시지 기반 LLM 호출
        
        Args:
            messages: [{"role": "system|user|assistant", "content": "..."}]
        
        Returns:
            Response object with .content attribute
        """
        if self.provider == LLMProvider.OPENAI:
            return await self._call_openai(messages)
        elif self.provider == LLMProvider.GEMINI:
            return await self._call_gemini(messages)
        elif self.provider == LLMProvider.CLAUDE:
            return await self._call_claude(messages)
        else:
            return await self._call_mock(messages)
    
    async def _call_openai(self, messages: List[Dict[str, str]]):
        """OpenAI API 호출"""
        try:
            import openai
            
            # 동기 함수를 비동기로 실행
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: openai.ChatCompletion.create(
                    model=self.model,
                    messages=messages,
                    temperature=self.temperature,
                    max_tokens=self.max_tokens
                )
            )
            
            class OpenAIResponse:
                def __init__(self, content):
                    self.content = content
            
            return OpenAIResponse(response.choices[0].message.content)
            
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return await self._call_mock(messages)
    
    async def _call_gemini(self, messages: List[Dict[str, str]]):
        """Gemini API 호출"""
        try:
            # 메시지를 Gemini 형식으로 변환
            prompt = "\n".join([
                f"{msg['role']}: {msg['content']}" 
                for msg in messages
            ])
            
            # 동기 함수를 비동기로 실행
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.client.generate_content(prompt)
            )
            
            class GeminiResponse:
                def __init__(self, content):
                    self.content = content
            
            return GeminiResponse(response.text)
            
        except Exception as e:
            logger.error(f"Gemini API error: {e}")
            return await self._call_mock(messages)
    
    async def _call_claude(self, messages: List[Dict[str, str]]):
        """Claude API 호출"""
        try:
            # 시스템 메시지 추출
            system_message = ""
            user_messages = []
            
            for msg in messages:
                if msg["role"] == "system":
                    system_message = msg["content"]
                else:
                    user_messages.append({
                        "role": msg["role"],
                        "content": msg["content"]
                    })
            
            # Claude API 호출
            response = await asyncio.to_thread(
                self.client.messages.create,
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                system=system_message,
                messages=user_messages
            )
            
            class ClaudeResponse:
                def __init__(self, content):
                    self.content = content
            
            return ClaudeResponse(response.content[0].text)
            
        except Exception as e:
            logger.error(f"Claude API error: {e}")
            return await self._call_mock(messages)
    
    async def _call_mock(self, messages: List[Dict[str, str]]):
        """Mock 응답 생성"""
        # 마지막 사용자 메시지 찾기
        user_message = ""
        for msg in reversed(messages):
            if msg["role"] == "user":
                user_message = msg["content"]
                break
        
        user_message_lower = user_message.lower()
        
        # 코드 생성 요청 감지
        if '"code"' in user_message and ('json' in user_message_lower or 'python' in user_message_lower):
            # 코드 생성 요청에 대한 기본 응답
            if "calculator" in user_message_lower or "계산" in user_message_lower:
                code = """
def calculate(expression: str) -> float:
    # 간단한 계산기 구현
    try:
        result = eval(expression)
        return result
    except Exception as e:
        return f"Error: {str(e)}"
"""
            elif "portfolio" in user_message_lower or "포트폴리오" in user_message_lower or "투자" in user_message_lower:
                code = """
def optimize_portfolio(goals: Dict, risk_preference: str) -> Dict:
    # 포트폴리오 최적화 로직
    portfolio = {
        'stocks': 0.5 if risk_preference == 'high' else 0.3,
        'bonds': 0.3 if risk_preference == 'low' else 0.2,
        'cash': 0.2
    }
    return portfolio
"""
            elif "social" in user_message_lower or "소셜" in user_message_lower:
                code = """
def generate_response(comment: str, brand_tone: str) -> str:
    # 브랜드 톤에 맞는 응답 생성
    responses = {
        'friendly': f"안녕하세요! {comment}에 대해 감사드립니다.",
        'professional': f"고객님의 의견을 소중히 받아들이겠습니다.",
        'casual': f"헤이! 좋은 의견 감사해요!"
    }
    return responses.get(brand_tone, responses['friendly'])
"""
            else:
                code = """
# 기본 비즈니스 로직
result = await self.process_request(extracted_info)
return {"status": "success", "data": result}
"""
            
            content = json.dumps({"code": code.strip()})
            
        # 일반 패턴 매칭
        elif "계산" in user_message_lower or "더하기" in user_message_lower:
            content = json.dumps({
                "expression": "10 + 20",
                "numbers": [10, 20],
                "operation": "addition"
            })
        elif "분석" in user_message_lower or "데이터" in user_message_lower:
            content = json.dumps({
                "data_source": "sample.csv",
                "analysis_type": "statistical",
                "filters": {}
            })
        elif "웹" in user_message_lower or "수집" in user_message_lower:
            content = json.dumps({
                "url": "https://example.com",
                "data_type": "news",
                "selector": ".article"
            })
        else:
            content = json.dumps({
                "query": user_message,
                "response": "이해했습니다"
            })
        
        class MockResponse:
            def __init__(self, content):
                self.content = content
        
        await asyncio.sleep(0.1)  # 실제 API 호출 시뮬레이션
        return MockResponse(content)
    
    async def generate(self, prompt: str) -> str:
        """
        간단한 텍스트 생성 (하위 호환성)
        
        Args:
            prompt: 생성할 프롬프트
            
        Returns:
            생성된 텍스트
        """
        messages = [{"role": "user", "content": prompt}]
        response = await self.invoke_messages(messages)
        return response.content

# 전역 LLM 클라이언트 팩토리
def create_llm_client(model: str = None, **kwargs) -> LLMClient:
    """
    LLM 클라이언트 생성 헬퍼
    
    Args:
        model: 모델명 (None일 경우 자동 선택)
        **kwargs: 추가 설정
    
    Returns:
        LLMClient 인스턴스
    """
    if model is None:
        # 우선순위: Gemini > OpenAI > Claude > Mock
        if os.getenv("GOOGLE_API_KEY"):
            model = "gemini-pro"
        elif os.getenv("OPENAI_API_KEY"):
            model = "gpt-3.5-turbo"
        elif os.getenv("ANTHROPIC_API_KEY"):
            model = "claude-3-haiku-20240307"
        else:
            model = "mock"
            logger.warning("No API keys found, using mock LLM")
    
    return LLMClient(model=model, **kwargs)

# 비용 효율적인 모델 선택
COST_EFFICIENT_MODELS = {
    LLMProvider.OPENAI: "gpt-3.5-turbo",
    LLMProvider.GEMINI: "gemini-pro",
    LLMProvider.CLAUDE: "claude-3-haiku-20240307"
}

POWERFUL_MODELS = {
    LLMProvider.OPENAI: "gpt-4-turbo-preview",
    LLMProvider.GEMINI: "gemini-ultra",
    LLMProvider.CLAUDE: "claude-3-opus-20240229"
}