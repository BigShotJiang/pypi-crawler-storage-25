"""
Fixed Progressive Code Generator for FORGE AI
Generates code incrementally with proper template handling
"""

import asyncio
from typing import Optional, Any, Callable, Dict, List
from datetime import datetime
from pathlib import Path
import re
from loguru import logger

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts


class FixedProgressiveGenerator:
    """
    Fixed version that properly handles template placeholders
    and prevents Korean text from appearing in code
    """
    
    def __init__(self, llm_orchestrator: LLMOrchestrator):
        """Initialize with clean template"""
        self.llm = llm_orchestrator
        self.template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template_clean.py.template"
        
        # Load clean template
        try:
            with open(self.template_path, 'r') as f:
                self.template = f.read()
        except Exception as e:
            logger.error(f"Could not load template: {e}")
            self.template = ""
    
    async def generate_progressively(self, analysis: QueryAnalysis, context: Context,
                                    stream_callback: Optional[Callable] = None) -> Any:
        """Generate agent code progressively with visible stages"""
        
        start_time = datetime.now()
        
        try:
            # Extract basic info first
            agent_info = self._extract_agent_info(analysis)
            
            # Stage 1: Generate template variables (10 seconds)
            await self._stream_update(stream_callback, "preparing", 
                                    "📋 Preparing agent configuration...", 
                                    {"progress": 10, "stage": 1})
            
            template_vars = await self._generate_template_variables(analysis, agent_info)
            
            await self._stream_update(stream_callback, "preview",
                                    "Configuration ready",
                                    {"progress": 20})
            
            # Stage 2: Generate core business logic (15 seconds)
            await asyncio.sleep(0.5)
            await self._stream_update(stream_callback, "implementing",
                                    "💡 Implementing core business logic...",
                                    {"progress": 40, "stage": 2})
            
            core_logic = await self._generate_core_logic(analysis)
            template_vars['core_business_logic'] = self._indent_code(core_logic, 12)
            
            # Stage 3: Generate initialization code (5 seconds)
            await asyncio.sleep(0.5)
            await self._stream_update(stream_callback, "initializing",
                                    "🔧 Adding initialization logic...",
                                    {"progress": 60, "stage": 3})
            
            init_code = await self._generate_init_code(analysis)
            template_vars['custom_init'] = self._indent_code(init_code, 8)
            template_vars['custom_async_init'] = self._indent_code(
                await self._generate_async_init_code(analysis), 12
            )
            
            # Stage 4: Generate sample data and tests (10 seconds)
            await asyncio.sleep(0.5)
            await self._stream_update(stream_callback, "testing",
                                    "🧪 Adding sample data and tests...",
                                    {"progress": 80, "stage": 4})
            
            sample_data = await self._generate_sample_data(analysis)
            test_queries = await self._generate_test_queries(analysis)
            
            template_vars['sample_data'] = self._indent_code(sample_data, 4)
            template_vars['test_queries'] = test_queries
            template_vars['custom_cleanup'] = self._indent_code("# No additional cleanup required", 12)
            
            # Stage 5: Final assembly (5 seconds)
            await asyncio.sleep(0.5)
            await self._stream_update(stream_callback, "assembling",
                                    "🔨 Assembling final code...",
                                    {"progress": 90, "stage": 5})
            
            # Apply template variables
            final_code = self.template
            for key, value in template_vars.items():
                final_code = final_code.replace(f"{{{key}}}", str(value))
            
            # Complete
            await self._stream_update(stream_callback, "complete",
                                    "🎉 Agent generation complete!",
                                    {"progress": 100, "stages_completed": 5,
                                     "total_time": (datetime.now() - start_time).total_seconds()})
            
            # Create artifacts
            artifacts = GenerationArtifacts(
                generation_id=f"fixed_gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            
            artifacts.query_analysis = {
                "intent": analysis.intent,
                "domain": analysis.domain,
                "complexity": analysis.complexity.value,
                "capabilities": analysis.required_capabilities
            }
            
            artifacts.generated_code_raw = final_code
            artifacts.optimized_code = final_code
            artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            
            # Return result
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "fixed_progressive_generation"
            
            return GeneratedCode(code=final_code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Progressive generation failed: {e}")
            await self._stream_update(stream_callback, "error",
                                    f"❌ Generation failed: {str(e)}",
                                    {"error": str(e)})
            raise
    
    def _extract_agent_info(self, analysis: QueryAnalysis) -> Dict[str, str]:
        """Extract basic agent information from analysis"""
        # Generate agent name from query
        query_words = analysis.query.split()[:5]
        agent_name = ''.join(word.capitalize() for word in query_words if len(word) > 2)
        if not agent_name.endswith('Agent'):
            agent_name += 'Agent'
        
        return {
            'agent_class_name': agent_name,
            'agent_name': agent_name.replace('Agent', ' Agent'),
            'agent_type': 'CUSTOM',
            'agent_description': analysis.query[:200]
        }
    
    async def _generate_template_variables(self, analysis: QueryAnalysis, 
                                         agent_info: Dict[str, str]) -> Dict[str, Any]:
        """Generate all template variables"""
        
        prompt = f"""Generate configuration for a LogosAI agent.

Query: {analysis.query}

Generate ONLY a Python dictionary with these exact keys:
- model: LLM model name (string)
- temperature: float between 0 and 1
- max_tokens: integer (2000-8000)
- timeout: integer seconds
- retry_attempts: integer
- cache_enabled: boolean (lowercase)

Return ONLY the dictionary, no explanations."""

        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=500,
            temperature=0.3,
            model_override="gemini-2.5-flash-lite"
        )
        
        # Extract config dict
        config_str = self._extract_dict(result)
        
        return {
            'agent_class_name': agent_info['agent_class_name'],
            'agent_name': agent_info['agent_name'],
            'agent_type': agent_info['agent_type'],
            'agent_description': agent_info['agent_description'],
            'custom_config': config_str
        }
    
    async def _generate_core_logic(self, analysis: QueryAnalysis) -> str:
        """Generate only the core business logic"""
        
        prompt = f"""Generate ONLY the core business logic Python code for this agent request:
{analysis.query}

Requirements:
1. Generate ONLY Python code - no explanations, no Korean text
2. Include all necessary imports at the top
3. Implement the actual logic to fulfill the request
4. Use try/except for error handling
5. Return a dictionary with results

The code should:
- Process the extracted_info parameter
- Implement the requested functionality
- Return a dict with 'status' and 'data' keys

Generate ONLY executable Python code, nothing else."""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=6000,
            temperature=0.4,
            model_override="gemini-2.5-flash-lite"
        )
        
        # Clean and extract code
        code = self._extract_and_clean_code(result)
        return code
    
    async def _generate_init_code(self, analysis: QueryAnalysis) -> str:
        """Generate initialization code"""
        
        prompt = f"""Generate ONLY Python code for initializing instance variables for this agent:
{analysis.query}

Generate variable initialization code like:
self.data_cache = dict()
self.api_client = None
self.config_params = dict()

ONLY Python code, no comments, no explanations."""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=1000,
            temperature=0.3,
            model_override="gemini-2.5-flash-lite"
        )
        
        code = self._extract_and_clean_code(result)
        return code if code else "# No additional initialization required"
    
    async def _generate_async_init_code(self, analysis: QueryAnalysis) -> str:
        """Generate async initialization code"""
        
        prompt = f"""Generate ONLY Python code for async initialization for this agent:
{analysis.query}

Generate code like:
# Initialize external connections
self.session = aiohttp.ClientSession()
# Load configuration
config_data = await self._load_config()

ONLY Python code for async operations."""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=1000,
            temperature=0.3,
            model_override="gemini-2.5-flash-lite"
        )
        
        code = self._extract_and_clean_code(result)
        return code if code else "# No additional async initialization required"
    
    async def _generate_sample_data(self, analysis: QueryAnalysis) -> str:
        """Generate sample data for testing"""
        
        prompt = f"""Generate ONLY Python code to create sample data for testing this agent:
{analysis.query}

Create realistic sample data using pandas, numpy, or plain Python.
The code should create variables that can be used for testing.

ONLY Python code, no explanations."""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=3000,
            temperature=0.4,
            model_override="gemini-2.5-flash-lite"
        )
        
        return self._extract_and_clean_code(result)
    
    async def _generate_test_queries(self, analysis: QueryAnalysis) -> str:
        """Generate test queries as a Python list"""
        
        prompt = f"""Generate a Python list of 3-5 test queries for this agent:
{analysis.query}

Return ONLY a Python list like:
[
    "First test query",
    "Second test query",
    "Third test query"
]

ONLY the Python list, no explanations."""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=1000,
            temperature=0.5,
            model_override="gemini-2.5-flash-lite"
        )
        
        # Extract list
        list_match = re.search(r'\[[\s\S]*?\]', result, re.MULTILINE)
        if list_match:
            return list_match.group(0)
        
        # Fallback
        return '["Test the agent functionality", "Analyze sample data", "Generate report"]'
    
    def _extract_and_clean_code(self, response: str) -> str:
        """Extract code and remove any Korean text or explanations"""
        
        # First try to extract from code blocks
        python_match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        if python_match:
            code = python_match.group(1)
        else:
            # Try any code block
            code_match = re.search(r'```\n(.*?)```', response, re.DOTALL)
            if code_match:
                code = code_match.group(1)
            else:
                code = response
        
        # Remove lines that contain Korean characters (except in strings)
        lines = []
        for line in code.split('\n'):
            # Skip lines that are clearly Korean explanations
            if re.search(r'^[^"\']*[\u3131-\u3163\uac00-\ud7a3]+[^"\']*$', line):
                continue
            # Skip lines starting with Korean text
            if re.match(r'^\s*[\u3131-\u3163\uac00-\ud7a3]+', line):
                continue
            lines.append(line)
        
        return '\n'.join(lines).strip()
    
    def _extract_dict(self, response: str) -> str:
        """Extract dictionary from response"""
        
        # Try to find dict pattern
        dict_match = re.search(r'\{[^}]+\}', response, re.MULTILINE | re.DOTALL)
        if dict_match:
            return dict_match.group(0)
        
        # Fallback
        return """{
    "model": "gemini-2.5-flash-lite",
    "temperature": 0.7,
    "max_tokens": 4000,
    "timeout": 30,
    "retry_attempts": 3,
    "cache_enabled": true
}"""
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by specified spaces"""
        if not code:
            return ""
        
        indent = ' ' * spaces
        lines = code.split('\n')
        return '\n'.join(indent + line if line.strip() else line for line in lines)
    
    async def _stream_update(self, callback: Optional[Callable], status: str, 
                           message: str, data: Dict[str, Any] = None):
        """Send streaming update if callback is provided"""
        if callback:
            await callback(status, message, data or {})