"""
Generation Artifacts - Complete record of agent generation process
==================================================================

This module captures ALL artifacts from the agent generation process,
enabling full reproducibility, debugging, and improvement.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
import json
import yaml
from enum import Enum


class ArtifactType(Enum):
    """Types of artifacts in the generation process"""
    QUERY = "query"
    ANALYSIS = "analysis"
    PROMPT = "prompt"
    LLM_RESPONSE = "llm_response"
    TEMPLATE = "template"
    CONTEXT = "context"
    CODE = "code"
    VALIDATION = "validation"
    OPTIMIZATION = "optimization"
    ERROR = "error"


@dataclass
class PromptRecord:
    """Record of a single prompt and its response"""
    prompt_type: str  # e.g., "template_selection", "context_preparation"
    system_prompt: str
    user_prompt: str
    response: str
    model: str
    temperature: float
    timestamp: datetime
    tokens_used: Optional[Dict[str, int]] = None
    latency_ms: Optional[int] = None


@dataclass
class GenerationArtifacts:
    """Complete artifacts from agent generation"""
    
    # Basic info
    generation_id: str
    timestamp: datetime
    
    # Input
    original_query: str
    user_context: Dict[str, Any] = field(default_factory=dict)
    
    # Analysis
    query_analysis: Dict[str, Any] = field(default_factory=dict)
    
    # Template selection
    template_selection_process: List[PromptRecord] = field(default_factory=list)
    selected_template: str = ""
    template_content: str = ""
    template_metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Context preparation
    context_preparation_process: List[PromptRecord] = field(default_factory=list)
    template_context_values: Dict[str, Any] = field(default_factory=dict)
    
    # Code generation
    code_generation_process: List[PromptRecord] = field(default_factory=list)
    generated_code_raw: str = ""  # Before optimization
    
    # Optimization
    optimization_process: List[PromptRecord] = field(default_factory=list)
    optimized_code: str = ""  # Final code
    
    # Validation
    validation_results: Dict[str, Any] = field(default_factory=dict)
    
    # Suggestions
    improvement_suggestions: List[str] = field(default_factory=list)
    
    # Errors and warnings
    errors: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[Dict[str, Any]] = field(default_factory=list)
    
    # Performance metrics
    total_generation_time_ms: int = 0
    llm_calls_count: int = 0
    total_tokens_used: int = 0
    
    # Additional metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_prompt_record(self, record: PromptRecord):
        """Add a prompt record to the appropriate category"""
        if "template_selection" in record.prompt_type:
            self.template_selection_process.append(record)
        elif "context_preparation" in record.prompt_type:
            self.context_preparation_process.append(record)
        elif "code_generation" in record.prompt_type:
            self.code_generation_process.append(record)
        elif "optimization" in record.prompt_type:
            self.optimization_process.append(record)
        
        # Update metrics
        self.llm_calls_count += 1
        if record.tokens_used:
            self.total_tokens_used += sum(record.tokens_used.values())
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'generation_id': self.generation_id,
            'timestamp': self.timestamp.isoformat(),
            'original_query': self.original_query,
            'user_context': self.user_context,
            'query_analysis': self.query_analysis,
            'template': {
                'selected': self.selected_template,
                'content': self.template_content,
                'metadata': self.template_metadata,
                'selection_process': [
                    {
                        'prompt_type': r.prompt_type,
                        'system_prompt': r.system_prompt,
                        'user_prompt': r.user_prompt,
                        'response': r.response,
                        'model': r.model,
                        'temperature': r.temperature,
                        'timestamp': r.timestamp.isoformat()
                    } for r in self.template_selection_process
                ]
            },
            'context_values': self.template_context_values,
            'context_preparation_process': [
                {
                    'prompt_type': r.prompt_type,
                    'system_prompt': r.system_prompt,
                    'user_prompt': r.user_prompt,
                    'response': r.response,
                    'model': r.model,
                    'temperature': r.temperature,
                    'timestamp': r.timestamp.isoformat()
                } for r in self.context_preparation_process
            ],
            'code': {
                'raw': self.generated_code_raw,
                'optimized': self.optimized_code,
                'generation_process': [
                    {
                        'prompt_type': r.prompt_type,
                        'system_prompt': r.system_prompt,
                        'user_prompt': r.user_prompt,
                        'response': r.response,
                        'model': r.model,
                        'temperature': r.temperature,
                        'timestamp': r.timestamp.isoformat()
                    } for r in self.code_generation_process
                ],
                'optimization_process': [
                    {
                        'prompt_type': r.prompt_type,
                        'system_prompt': r.system_prompt,
                        'user_prompt': r.user_prompt,
                        'response': r.response,
                        'model': r.model,
                        'temperature': r.temperature,
                        'timestamp': r.timestamp.isoformat()
                    } for r in self.optimization_process
                ]
            },
            'validation_results': self.validation_results,
            'improvement_suggestions': self.improvement_suggestions,
            'errors': self.errors,
            'warnings': self.warnings,
            'metrics': {
                'total_generation_time_ms': self.total_generation_time_ms,
                'llm_calls_count': self.llm_calls_count,
                'total_tokens_used': self.total_tokens_used
            },
            'metadata': self.metadata
        }
    
    def save_to_file(self, file_path: Path, format: str = 'json'):
        """Save artifacts to file"""
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        data = self.to_dict()
        
        if format == 'json':
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        elif format == 'yaml':
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
    
    @classmethod
    def load_from_file(cls, file_path: Path) -> 'GenerationArtifacts':
        """Load artifacts from file"""
        with open(file_path, 'r', encoding='utf-8') as f:
            if file_path.suffix == '.json':
                data = json.load(f)
            elif file_path.suffix in ['.yaml', '.yml']:
                data = yaml.safe_load(f)
            else:
                raise ValueError(f"Unsupported file format: {file_path.suffix}")
        
        # Reconstruct the object
        artifacts = cls(
            generation_id=data['generation_id'],
            timestamp=datetime.fromisoformat(data['timestamp']),
            original_query=data['original_query'],
            user_context=data.get('user_context', {}),
            query_analysis=data.get('query_analysis', {}),
            selected_template=data['template']['selected'],
            template_content=data['template']['content'],
            template_metadata=data['template']['metadata'],
            template_context_values=data['context_values'],
            generated_code_raw=data['code']['raw'],
            optimized_code=data['code']['optimized'],
            validation_results=data.get('validation_results', {}),
            improvement_suggestions=data.get('improvement_suggestions', []),
            errors=data.get('errors', []),
            warnings=data.get('warnings', []),
            total_generation_time_ms=data['metrics']['total_generation_time_ms'],
            llm_calls_count=data['metrics']['llm_calls_count'],
            total_tokens_used=data['metrics']['total_tokens_used'],
            metadata=data.get('metadata', {})
        )
        
        # Reconstruct prompt records
        for record_data in data['template']['selection_process']:
            artifacts.template_selection_process.append(
                PromptRecord(
                    prompt_type=record_data['prompt_type'],
                    system_prompt=record_data['system_prompt'],
                    user_prompt=record_data['user_prompt'],
                    response=record_data['response'],
                    model=record_data['model'],
                    temperature=record_data['temperature'],
                    timestamp=datetime.fromisoformat(record_data['timestamp'])
                )
            )
        
        # Add other prompt records similarly...
        
        return artifacts
    
    def get_reproducibility_package(self) -> Dict[str, Any]:
        """Get everything needed to reproduce this generation"""
        return {
            'query': self.original_query,
            'context': self.user_context,
            'template': {
                'name': self.selected_template,
                'content': self.template_content,
                'context_values': self.template_context_values
            },
            'prompts': {
                'template_selection': [
                    {
                        'system': r.system_prompt,
                        'user': r.user_prompt,
                        'model': r.model,
                        'temperature': r.temperature
                    } for r in self.template_selection_process
                ],
                'context_preparation': [
                    {
                        'system': r.system_prompt,
                        'user': r.user_prompt,
                        'model': r.model,
                        'temperature': r.temperature
                    } for r in self.context_preparation_process
                ],
                'code_generation': [
                    {
                        'system': r.system_prompt,
                        'user': r.user_prompt,
                        'model': r.model,
                        'temperature': r.temperature
                    } for r in self.code_generation_process
                ]
            },
            'final_code': self.optimized_code
        }
    
    def generate_report(self) -> str:
        """Generate a human-readable report"""
        report = f"""
# Agent Generation Report
Generated: {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
ID: {self.generation_id}

## Query
{self.original_query}

## Analysis
Intent: {self.query_analysis.get('intent', 'N/A')}
Complexity: {self.query_analysis.get('complexity', 'N/A')}
Required Capabilities: {', '.join(self.query_analysis.get('required_capabilities', []))}

## Template
Selected: {self.selected_template}
{self.template_metadata.get('description', '')}

## Generation Process
- LLM Calls: {self.llm_calls_count}
- Total Tokens: {self.total_tokens_used:,}
- Generation Time: {self.total_generation_time_ms}ms

## Code Statistics
- Raw Code Length: {len(self.generated_code_raw)} characters
- Optimized Code Length: {len(self.optimized_code)} characters
- Optimization Ratio: {(1 - len(self.optimized_code) / len(self.generated_code_raw)) * 100:.1f}% reduction

## Suggestions for Improvement
{chr(10).join([f"- {s}" for s in self.improvement_suggestions])}

## Errors and Warnings
Errors: {len(self.errors)}
Warnings: {len(self.warnings)}
"""
        return report


class ArtifactsViewer:
    """View and analyze generation artifacts"""
    
    @staticmethod
    def create_interactive_view(artifacts: GenerationArtifacts) -> Dict[str, Any]:
        """Create an interactive view structure for UI"""
        return {
            'overview': {
                'query': artifacts.original_query,
                'generation_time': artifacts.timestamp.isoformat(),
                'template_used': artifacts.selected_template,
                'success': len(artifacts.errors) == 0
            },
            'tabs': {
                'prompts': {
                    'template_selection': [
                        {
                            'title': f"Prompt {i+1}",
                            'system': r.system_prompt,
                            'user': r.user_prompt,
                            'response': r.response,
                            'model': r.model
                        } for i, r in enumerate(artifacts.template_selection_process)
                    ],
                    'context_preparation': [
                        {
                            'title': f"Context Prep {i+1}",
                            'system': r.system_prompt,
                            'user': r.user_prompt,
                            'response': r.response,
                            'model': r.model
                        } for i, r in enumerate(artifacts.context_preparation_process)
                    ]
                },
                'template': {
                    'name': artifacts.selected_template,
                    'content': artifacts.template_content,
                    'context_values': artifacts.template_context_values
                },
                'code': {
                    'raw': artifacts.generated_code_raw,
                    'optimized': artifacts.optimized_code,
                    'diff': None  # Could add diff view
                },
                'validation': artifacts.validation_results,
                'metrics': {
                    'llm_calls': artifacts.llm_calls_count,
                    'tokens': artifacts.total_tokens_used,
                    'time_ms': artifacts.total_generation_time_ms
                }
            }
        }