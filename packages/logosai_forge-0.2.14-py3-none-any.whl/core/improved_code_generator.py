"""
Improved Code Generator for FORGE AI
Generates clean, working agent code without explanations mixed in
"""

import logging
from typing import Optional, Any, Callable, Dict
from datetime import datetime
from pathlib import Path
import json
import re

# Use loguru for consistent logging
from loguru import logger

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts


class ImprovedCodeGenerator:
    """Improved code generator that generates clean, working agent code"""
    
    def __init__(self, llm_orchestrator: LLMOrchestrator):
        """Initialize improved code generator"""
        self.llm = llm_orchestrator
        self.template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template.py.template"
        
        # Load template
        try:
            with open(self.template_path, 'r') as f:
                self.template = f.read()
        except Exception as e:
            logger.error(f"Could not load template: {e}")
            self.template = ""
    
    async def generate_agent(self, analysis: QueryAnalysis, context: Context, 
                           stream_callback: Optional[Callable] = None) -> Any:
        """Generate agent code using improved single-prompt approach"""
        
        start_time = datetime.now()
        
        try:
            # Step 1: Generate complete agent code in one go
            if stream_callback:
                await stream_callback(
                    "generating",
                    "🚀 에이전트 코드를 생성하고 있습니다...",
                    {"stage": "code_generation", "phase": "processing"}
                )
            
            # Create comprehensive but focused prompt
            comprehensive_prompt = f"""You are an expert Python developer creating a LogosAI agent.

USER REQUEST: {analysis.query}

Generate a complete, working LogosAI agent that fulfills this request.

TEMPLATE TO USE:
{self.template}

REQUIREMENTS:
1. Replace ALL template variables with actual working code
2. Generate ONLY Python code - no explanations or comments in Korean
3. Include realistic sample data generation
4. Implement complete business logic
5. Add proper error handling
6. Make sure the code is syntactically correct and will run

VARIABLE REPLACEMENTS:
- {{agent_class_name}}: Generate appropriate class name based on the request
- {{agent_name}}: Human-readable agent name
- {{agent_description}}: Description based on user request
- {{custom_config}}: Any additional configuration needed
- {{custom_init}}: Initialization code
- {{custom_async_init}}: Async initialization code
- {{query_extraction_prompt}}: Prompt for extracting info from queries
- {{core_business_logic}}: Complete implementation of requested functionality
- {{response_generation_prompt}}: Prompt for generating responses
- {{custom_cleanup}}: Cleanup code
- {{sample_data_code}}: Code to generate sample data
- {{test_queries}}: List of test queries

IMPORTANT:
- Use ONLY English for code comments
- Generate complete, runnable code
- Do NOT include explanations outside of code
- Make sure all imports are included
- Ensure the code follows LogosAI patterns

Generate the complete agent code now:"""
            
            # Generate code with appropriate model
            result = await self.llm.generate(
                prompt=comprehensive_prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=10000,  # Sufficient tokens
                temperature=0.3,   # Lower temperature for consistent code
                model_override="gemini-2.5-flash-lite"  # Use faster model
            )
            
            # Extract code from response
            code = self._extract_clean_code(result)
            
            # Validate and clean the code
            code = self._validate_and_clean_code(code, analysis)
            
            # Create artifacts
            artifacts = GenerationArtifacts(
                generation_id=f"improved_gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            
            artifacts.query_analysis = {
                "intent": analysis.intent,
                "domain": analysis.domain,
                "complexity": analysis.complexity.value,
                "capabilities": analysis.required_capabilities
            }
            
            artifacts.generated_code_raw = code
            artifacts.optimized_code = code
            artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            artifacts.llm_calls_count = 1  # Single call approach
            
            if stream_callback:
                await stream_callback(
                    "complete",
                    "✨ 에이전트가 성공적으로 생성되었습니다!",
                    {
                        "stage": "complete",
                        "code_length": len(code),
                        "generation_time": (datetime.now() - start_time).total_seconds()
                    }
                )
            
            # Return GeneratedCode object
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "improved_single_prompt"
            
            return GeneratedCode(code=code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Code generation failed: {e}")
            raise
    
    def _extract_clean_code(self, response: str) -> str:
        """Extract clean Python code from LLM response"""
        
        # Try JSON format first
        import json
        try:
            json_response = json.loads(response.strip())
            if 'code' in json_response:
                return json_response['code'].strip()
        except json.JSONDecodeError:
            pass
        
        # Try to find code block as fallback
        python_block_match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        if python_block_match:
            return python_block_match.group(1).strip()
        
        # Try any code block
        code_block_match = re.search(r'```\n(.*?)```', response, re.DOTALL)
        if code_block_match:
            return code_block_match.group(1).strip()
        
        # If no code blocks, look for import statements
        lines = response.split('\n')
        code_lines = []
        in_code = False
        
        for line in lines:
            # Skip Korean explanations
            if any(korean_char in line for korean_char in ['네', '알겠습니다', '드리겠습니다']):
                continue
            
            if line.strip().startswith(('import ', 'from ', 'class ', 'def ', 'async def')):
                in_code = True
            
            if in_code:
                code_lines.append(line)
        
        if code_lines:
            return '\n'.join(code_lines)
        
        # Last resort - return everything
        return response
    
    def _validate_and_clean_code(self, code: str, analysis: QueryAnalysis) -> str:
        """Validate and clean the generated code"""
        
        # Remove any Korean text that slipped through
        lines = code.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Skip lines with Korean explanations
            if re.search(r'[가-힣]', line) and not line.strip().startswith(('#', '"', "'")):
                continue
            cleaned_lines.append(line)
        
        code = '\n'.join(cleaned_lines)
        
        # Ensure all template variables are replaced
        template_vars = re.findall(r'\{[^{}]+\}', code)
        # Filter out f-string patterns
        template_vars = [var for var in template_vars if not any(c in var for c in ':.[]()')]
        
        if template_vars:
            # Generate replacements for any remaining variables
            replacements = {
                '{agent_class_name}': self._generate_class_name(analysis),
                '{agent_name}': self._generate_agent_name(analysis),
                '{agent_description}': analysis.query,
                '{custom_config}': '"timeout": 60, "retry_attempts": 3',
                '{custom_init}': '# Custom initialization',
                '{custom_async_init}': '# Async initialization',
                '{core_business_logic}': '# Business logic implementation',
                '{query_extraction_prompt}': 'Extract key information from the user query',
                '{response_generation_prompt}': 'Generate a helpful response',
                '{custom_cleanup}': '# Cleanup resources',
                '{sample_data_code}': '# Sample data generation',
                '{test_queries}': '["Test query 1", "Test query 2"]'
            }
            
            for var, replacement in replacements.items():
                code = code.replace(var, replacement)
        
        # Fix double curly braces issue
        code = code.replace('{{', '{')
        code = code.replace('}}', '}')
        
        return code
    
    def _generate_class_name(self, analysis: QueryAnalysis) -> str:
        """Generate appropriate class name from analysis"""
        domain = (analysis.domain or 'general').lower()
        
        # Map domain to class name
        domain_map = {
            'customer': 'CustomerAnalysisAgent',
            'data': 'DataAnalysisAgent',
            'api': 'APIIntegrationAgent',
            'web': 'WebScrapingAgent',
            'finance': 'FinancialAnalysisAgent',
            'marketing': 'MarketingAnalyticsAgent',
            'sales': 'SalesAnalyticsAgent',
            'behavior': 'BehaviorAnalysisAgent',
            'analytics': 'AnalyticsAgent'
        }
        
        # Check for keywords in query
        query_lower = analysis.query.lower()
        for key, class_name in domain_map.items():
            if key in query_lower:
                return class_name
        
        # Default based on domain
        return domain_map.get(domain, 'CustomBusinessAgent')
    
    def _generate_agent_name(self, analysis: QueryAnalysis) -> str:
        """Generate human-readable agent name from analysis"""
        domain = (analysis.domain or 'General').title()
        
        # Extract key functionality from query
        query_lower = analysis.query.lower()
        if '고객' in analysis.query or 'customer' in query_lower:
            return "Customer Analytics Agent"
        elif '데이터' in analysis.query or 'data' in query_lower:
            return "Data Analysis Agent"
        elif 'api' in query_lower:
            return "API Integration Agent"
        else:
            return f"{domain} Assistant Agent"