#!/usr/bin/env python3
"""
백틱 제거 및 코드 안전성 검사 유틸리티
다시는 백틱 문제가 발생하지 않도록 하는 포괄적 솔루션
"""

import re
import logging
from typing import Tuple

logger = logging.getLogger(__name__)

class BacktickSanitizer:
    """백틱 제거 및 코드 안전성 검사를 위한 유틸리티 클래스"""
    
    @staticmethod
    def sanitize_code(code: str, strict_mode: bool = True) -> Tuple[str, int, bool]:
        """
        코드에서 모든 백틱 패턴을 안전하게 제거
        
        Args:
            code: 검사할 코드
            strict_mode: True시 모든 백틱(`), False시 코드블록(```)만 제거
            
        Returns:
            (sanitized_code, removed_count, is_safe)
        """
        if not code or not isinstance(code, str):
            return code, 0, True
        
        original_backticks = code.count('```')
        original_single_backticks = code.count('`') - (original_backticks * 3)
        
        if original_backticks == 0 and (not strict_mode or original_single_backticks == 0):
            return code, 0, True
        
        logger.info(f"🔍 백틱 패턴 발견: 코드블록 {original_backticks}개, 단일백틱 {original_single_backticks}개")
        
        sanitized = code
        
        # 1단계: 코드 블록 패턴 제거
        sanitized = BacktickSanitizer._remove_code_blocks(sanitized)
        
        # 2단계: f-string 내 백틱 제거  
        sanitized = BacktickSanitizer._remove_fstring_backticks(sanitized)
        
        # 3단계: 문자열 리터럴 내 백틱 제거
        sanitized = BacktickSanitizer._remove_string_backticks(sanitized)
        
        # 4단계: 남은 모든 백틱 제거
        sanitized = sanitized.replace('```', '')
        
        if strict_mode:
            # 모든 백틱 제거
            sanitized = sanitized.replace('`', '')
        
        # 검증
        final_backticks = sanitized.count('```')
        final_single_backticks = sanitized.count('`')
        is_safe = final_backticks == 0 and (not strict_mode or final_single_backticks == 0)
        
        removed_count = original_backticks + (original_single_backticks if strict_mode else 0)
        
        if is_safe:
            logger.info(f"✅ 백틱 제거 성공: {removed_count}개 제거됨")
        else:
            logger.error(f"❌ 백틱 제거 실패: 여전히 {final_backticks + final_single_backticks}개 남음")
        
        return sanitized, removed_count, is_safe
    
    @staticmethod
    def _remove_code_blocks(code: str) -> str:
        """코드 블록 패턴 제거 (```python, ```json 등)"""
        # 언어 지정 코드 블록 (개선된 패턴)
        # ```python, ```javascript, ```json 등 + 선택적 새줄
        code = re.sub(r'```[a-zA-Z0-9_+-]+(?:\n|$)', '', code)
        
        # 남은 언어 지시자들 제거 (더 직접적인 방법)
        lines = code.split('\n')
        language_keywords = {
            'python', 'javascript', 'js', 'typescript', 'ts', 
            'json', 'yaml', 'yml', 'xml', 'html', 'css',
            'sql', 'bash', 'shell', 'java', 'cpp', 'c++',
            'csharp', 'c#', 'go', 'rust', 'ruby', 'php',
            'swift', 'kotlin', 'scala'
        }
        
        cleaned_lines = []
        for line in lines:
            stripped = line.strip()
            # 독립적인 언어 지시자인 줄은 제거
            if stripped.lower() in language_keywords:
                continue  # 이 줄을 제거
            # 공백만 있는 줄에 언어 지시자가 있으면 제거
            elif stripped.lower().replace(' ', '') in language_keywords:
                continue  # 이 줄을 제거
            else:
                cleaned_lines.append(line)
        
        code = '\n'.join(cleaned_lines)
        
        # 일반 코드 블록 시작
        code = re.sub(r'```\n', '', code) 
        # 코드 블록 끝
        code = re.sub(r'\n```', '', code)
        # 인라인 코드 블록
        code = re.sub(r'```', '', code)
        
        return code
    
    @staticmethod
    def _remove_fstring_backticks(code: str) -> str:
        """f-string 내부의 백틱 제거"""
        # f"...```..." 패턴
        code = re.sub(r'(f"[^"]*?)```([^"]*?")', r'\1\2', code)
        # f'...```...' 패턴  
        code = re.sub(r"(f'[^']*?)```([^']*?')", r'\1\2', code)
        
        return code
    
    @staticmethod
    def _remove_string_backticks(code: str) -> str:
        """일반 문자열 내부의 백틱 제거"""
        # "...```..." 패턴
        code = re.sub(r'("[^"]*?)```([^"]*?")', r'\1\2', code)
        # '...```...' 패턴
        code = re.sub(r"('[^']*?)```([^']*?')", r'\1\2', code)
        
        return code
    
    @staticmethod
    def is_exec_safe(code: str) -> bool:
        """exec() 실행에 안전한지 검사"""
        if not code:
            return True
            
        # 백틱 검사
        if '```' in code:
            logger.warning("exec() 안전성 검사 실패: 코드 블록 백틱 발견")
            return False
        
        # 삼중 따옴표 내부에 백틱이 있는지 검사
        triple_quote_blocks = re.findall(r'""".*?"""', code, re.DOTALL)
        for block in triple_quote_blocks:
            if '`' in block:
                logger.warning("exec() 안전성 검사 실패: 삼중따옴표 블록 내 백틱 발견")
                return False
        
        triple_quote_blocks_single = re.findall(r"'''.*?'''", code, re.DOTALL)
        for block in triple_quote_blocks_single:
            if '`' in block:
                logger.warning("exec() 안전성 검사 실패: 삼중따옴표 블록 내 백틱 발견")
                return False
        
        return True
    
    @staticmethod
    def emergency_cleanup(code: str) -> str:
        """긴급 백틱 제거 (모든 백틱 강제 제거)"""
        logger.warning("🚨 긴급 백틱 제거 모드 활성화")
        
        if not code:
            return code
        
        # 모든 백틱 제거
        cleaned = code.replace('`', '')
        
        removed = code.count('`')
        logger.info(f"🔧 긴급 제거 완료: {removed}개 백틱 제거")
        
        return cleaned
    
    @staticmethod
    def validate_and_fix(code: str, context: str = "unknown") -> str:
        """코드 검증 및 자동 수정"""
        logger.info(f"🔍 백틱 검증 시작 (컨텍스트: {context})")
        
        if not code:
            return code
        
        # 1차: 일반 정리
        sanitized, removed, is_safe = BacktickSanitizer.sanitize_code(code, strict_mode=False)
        
        if is_safe:
            if removed > 0:
                logger.info(f"✅ 백틱 정리 완료: {removed}개 제거")
            return sanitized
        
        # 2차: 엄격 모드
        logger.warning("⚠️ 1차 정리 실패, 엄격 모드로 재시도")
        sanitized, removed, is_safe = BacktickSanitizer.sanitize_code(code, strict_mode=True)
        
        if is_safe:
            logger.info(f"✅ 엄격 모드 정리 완료: {removed}개 제거")
            return sanitized
        
        # 3차: 긴급 모드
        logger.error("❌ 엄격 모드도 실패, 긴급 모드 활성화")
        return BacktickSanitizer.emergency_cleanup(code)


def sanitize_code_safe(code: str, context: str = "general") -> str:
    """간단한 백틱 제거 함수 (전역 사용)"""
    return BacktickSanitizer.validate_and_fix(code, context)


def is_code_safe_for_exec(code: str) -> bool:
    """exec() 실행 전 안전성 검사"""
    return BacktickSanitizer.is_exec_safe(code)


# 테스트 함수
def test_backtick_sanitizer():
    """백틱 제거 로직 테스트"""
    test_cases = [
        # 기본 코드 블록
        'def test():\n    print("hello")\n```python\nprint("world")\n```',
        
        # f-string 내 백틱
        'f"결과는 ```{result}``` 입니다"',
        
        # 문자열 내 백틱
        '"이것은 ```코드블록``` 예시입니다"',
        
        # 혼합 패턴
        '''def example():
    ```python
    return f"값은 ```{value}``` 입니다"
    ```
    print("정상 코드")''',
    ]
    
    for i, test_code in enumerate(test_cases, 1):
        print(f"\n=== 테스트 케이스 {i} ===")
        print(f"원본: {test_code[:50]}...")
        
        sanitized = sanitize_code_safe(test_code, f"test_case_{i}")
        
        print(f"결과: {sanitized[:50]}...")
        print(f"안전성: {'✅' if is_code_safe_for_exec(sanitized) else '❌'}")


if __name__ == "__main__":
    test_backtick_sanitizer()