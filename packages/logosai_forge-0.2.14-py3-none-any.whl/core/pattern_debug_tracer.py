"""
🔍 Pattern Debug Tracer
패턴 시스템 호출 과정을 상세히 추적하여 미작동 원인을 정확히 파악하는 디버깅 시스템

목적:
1. 패턴 시스템 호출 여부 실시간 추적
2. 키워드 매칭 과정 상세 로깅
3. 실패 지점 정확한 파악
4. 성능 및 호출 빈도 모니터링
"""

import os
import json
import time
from typing import Dict, Any, List, Optional
from datetime import datetime
from dataclasses import dataclass, asdict
from pathlib import Path
from loguru import logger


@dataclass
class PatternDecisionTrace:
    """패턴 시스템 사용 결정 추적 정보"""
    timestamp: str
    template_id: str
    user_request: str
    request_length: int
    
    # 환경 변수 체크
    env_force_patterns: bool
    env_enable_patterns: bool
    env_pattern_debug: bool
    
    # 키워드 매칭 분석
    detected_keywords: List[str]
    keyword_count: int
    keyword_threshold: int
    keyword_match_passed: bool
    
    # 템플릿 기반 결정
    template_friendly: bool
    template_in_whitelist: bool
    
    # 최종 결정
    final_decision: bool
    decision_reason: str
    
    # 실행 정보
    execution_time_ms: float
    patterns_available: bool


@dataclass
class PatternExecutionTrace:
    """패턴 시스템 실행 추적 정보"""
    timestamp: str
    execution_id: str
    success: bool
    error_message: Optional[str]
    
    # 패턴 선택 과정
    query_analysis_time_ms: float
    pattern_selection_time_ms: float
    code_generation_time_ms: float
    template_conversion_time_ms: float
    
    # 선택된 패턴들
    selected_patterns: List[str]
    confidence_score: float
    generated_code_length: int
    
    # 품질 지표
    syntax_valid: bool
    has_imports: bool
    has_functions: bool
    has_classes: bool


class PatternDebugTracer:
    """패턴 시스템 디버깅 추적기"""
    
    def __init__(self):
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.trace_file = Path(__file__).parent.parent / "business_patterns_implementation" / "logs" / f"pattern_debug_{self.session_id}.json"
        self.trace_file.parent.mkdir(exist_ok=True)
        
        self.decision_traces = []
        self.execution_traces = []
        
        # 실시간 통계
        self.stats = {
            'total_decisions': 0,
            'pattern_system_chosen': 0,
            'pattern_system_success': 0,
            'pattern_system_failures': 0,
            'avg_decision_time': 0.0,
            'avg_execution_time': 0.0
        }
        
        logger.info(f"🔍 Pattern Debug Tracer initialized - Session: {self.session_id}")
    
    def trace_pattern_decision(self, template_id: str, user_request: str) -> PatternDecisionTrace:
        """패턴 시스템 사용 결정 과정 추적"""
        
        start_time = time.time()
        
        # 환경 변수 체크
        env_force_patterns = os.getenv('FORGE_FORCE_PATTERNS', 'false').lower() == 'true'
        env_enable_patterns = os.getenv('FORGE_ENABLE_PATTERNS', 'true').lower() == 'true'
        env_pattern_debug = os.getenv('FORGE_PATTERN_DEBUG', 'false').lower() == 'true'
        
        # 키워드 분석
        detected_keywords, keyword_analysis = self._analyze_keywords(user_request)
        
        # 템플릿 분석
        template_analysis = self._analyze_template(template_id)
        
        # 최종 결정 시뮬레이션
        final_decision, decision_reason = self._simulate_decision(
            env_force_patterns, env_enable_patterns, 
            keyword_analysis, template_analysis
        )
        
        execution_time = (time.time() - start_time) * 1000
        
        # 패턴 시스템 가용성 체크
        patterns_available = self._check_pattern_availability()
        
        trace = PatternDecisionTrace(
            timestamp=datetime.now().isoformat(),
            template_id=template_id,
            user_request=user_request[:200] + "..." if len(user_request) > 200 else user_request,
            request_length=len(user_request),
            
            env_force_patterns=env_force_patterns,
            env_enable_patterns=env_enable_patterns,
            env_pattern_debug=env_pattern_debug,
            
            detected_keywords=detected_keywords,
            keyword_count=keyword_analysis['count'],
            keyword_threshold=keyword_analysis['threshold'],
            keyword_match_passed=keyword_analysis['passed'],
            
            template_friendly=template_analysis['friendly'],
            template_in_whitelist=template_analysis['in_whitelist'],
            
            final_decision=final_decision,
            decision_reason=decision_reason,
            
            execution_time_ms=execution_time,
            patterns_available=patterns_available
        )
        
        self.decision_traces.append(trace)
        self._update_decision_stats(trace)
        
        # 실시간 로깅
        if env_pattern_debug:
            self._log_decision_trace(trace)
        
        return trace
    
    def trace_pattern_execution(self, execution_id: str, success: bool, 
                               error_message: Optional[str] = None, 
                               **execution_data) -> PatternExecutionTrace:
        """패턴 시스템 실행 과정 추적"""
        
        trace = PatternExecutionTrace(
            timestamp=datetime.now().isoformat(),
            execution_id=execution_id,
            success=success,
            error_message=error_message,
            
            query_analysis_time_ms=execution_data.get('query_analysis_time', 0.0),
            pattern_selection_time_ms=execution_data.get('pattern_selection_time', 0.0),
            code_generation_time_ms=execution_data.get('code_generation_time', 0.0),
            template_conversion_time_ms=execution_data.get('template_conversion_time', 0.0),
            
            selected_patterns=execution_data.get('selected_patterns', []),
            confidence_score=execution_data.get('confidence_score', 0.0),
            generated_code_length=execution_data.get('code_length', 0),
            
            syntax_valid=execution_data.get('syntax_valid', False),
            has_imports=execution_data.get('has_imports', False),
            has_functions=execution_data.get('has_functions', False),
            has_classes=execution_data.get('has_classes', False)
        )
        
        self.execution_traces.append(trace)
        self._update_execution_stats(trace)
        
        # 실시간 로깅
        if os.getenv('FORGE_PATTERN_DEBUG', 'false').lower() == 'true':
            self._log_execution_trace(trace)
        
        return trace
    
    def _analyze_keywords(self, user_request: str) -> tuple:
        """키워드 분석"""
        
        # 현재 패턴 시스템에서 사용하는 키워드들
        pattern_keywords = [
            'csv', 'excel', '데이터', '분석', 'analysis', '차트', 
            '대시보드', 'dashboard', '고객', 'customer', '위험', 'risk',
            '시각화', 'visualization', '예측', 'prediction', '품질', 'quality',
            'kpi', '모니터링', 'monitoring', '세그멘테이션', 'segmentation'
        ]
        
        user_lower = user_request.lower()
        detected = [kw for kw in pattern_keywords if kw in user_lower]
        
        # 현재 임계값 확인
        threshold = 1  # 현재 시스템에서 사용하는 값
        passed = len(detected) >= threshold
        
        analysis = {
            'count': len(detected),
            'threshold': threshold,
            'passed': passed,
            'keywords': detected
        }
        
        return detected, analysis
    
    def _analyze_template(self, template_id: str) -> Dict[str, Any]:
        """템플릿 분석"""
        
        # 패턴 친화적 템플릿들
        pattern_friendly_templates = [
            'data_analysis', 'comprehensive', 'advanced', 
            'business_intelligence', 'analytics'
        ]
        
        friendly = template_id in pattern_friendly_templates
        in_whitelist = template_id in pattern_friendly_templates
        
        return {
            'friendly': friendly,
            'in_whitelist': in_whitelist,
            'template_id': template_id
        }
    
    def _simulate_decision(self, env_force: bool, env_enable: bool,
                         keyword_analysis: Dict, template_analysis: Dict) -> tuple:
        """결정 과정 시뮬레이션"""
        
        if not env_enable:
            return False, "FORGE_ENABLE_PATTERNS=false"
        
        if env_force:
            return True, "FORGE_FORCE_PATTERNS=true (forced)"
        
        if template_analysis['friendly']:
            return True, f"Template '{template_analysis['template_id']}' is pattern-friendly"
        
        if keyword_analysis['passed']:
            return True, f"Keyword match passed ({keyword_analysis['count']}/{keyword_analysis['threshold']}): {keyword_analysis['keywords']}"
        
        return False, f"Insufficient keyword matches ({keyword_analysis['count']}/{keyword_analysis['threshold']})"
    
    def _check_pattern_availability(self) -> bool:
        """패턴 시스템 가용성 체크"""
        try:
            # 패턴 시스템 모듈 import 테스트
            patterns_path = Path(__file__).parent.parent / "business_patterns_implementation"
            return patterns_path.exists()
        except:
            return False
    
    def _update_decision_stats(self, trace: PatternDecisionTrace):
        """결정 통계 업데이트"""
        self.stats['total_decisions'] += 1
        
        if trace.final_decision:
            self.stats['pattern_system_chosen'] += 1
        
        # 평균 결정 시간 업데이트
        current_avg = self.stats['avg_decision_time']
        n = self.stats['total_decisions']
        new_avg = ((current_avg * (n-1)) + trace.execution_time_ms) / n
        self.stats['avg_decision_time'] = new_avg
    
    def _update_execution_stats(self, trace: PatternExecutionTrace):
        """실행 통계 업데이트"""
        if trace.success:
            self.stats['pattern_system_success'] += 1
        else:
            self.stats['pattern_system_failures'] += 1
        
        total_execution_time = (
            trace.query_analysis_time_ms + 
            trace.pattern_selection_time_ms + 
            trace.code_generation_time_ms + 
            trace.template_conversion_time_ms
        )
        
        executions = self.stats['pattern_system_success'] + self.stats['pattern_system_failures']
        if executions > 0:
            current_avg = self.stats['avg_execution_time']
            new_avg = ((current_avg * (executions-1)) + total_execution_time) / executions
            self.stats['avg_execution_time'] = new_avg
    
    def _log_decision_trace(self, trace: PatternDecisionTrace):
        """결정 과정 상세 로깅"""
        logger.info("🔍 PATTERN DECISION TRACE")
        logger.info(f"  📋 Template: {trace.template_id}")
        logger.info(f"  📝 Request: {trace.user_request[:60]}...")
        logger.info(f"  🌍 Environment:")
        logger.info(f"    - FORGE_FORCE_PATTERNS: {trace.env_force_patterns}")
        logger.info(f"    - FORGE_ENABLE_PATTERNS: {trace.env_enable_patterns}")
        logger.info(f"    - FORGE_PATTERN_DEBUG: {trace.env_pattern_debug}")
        logger.info(f"  🔑 Keywords: {trace.detected_keywords} ({trace.keyword_count}/{trace.keyword_threshold})")
        logger.info(f"  📋 Template Analysis:")
        logger.info(f"    - Pattern Friendly: {trace.template_friendly}")
        logger.info(f"    - In Whitelist: {trace.template_in_whitelist}")
        logger.info(f"  🎯 FINAL DECISION: {'✅ USE PATTERNS' if trace.final_decision else '❌ USE LEGACY'}")
        logger.info(f"  💭 Reason: {trace.decision_reason}")
        logger.info(f"  ⏱️ Decision Time: {trace.execution_time_ms:.2f}ms")
    
    def _log_execution_trace(self, trace: PatternExecutionTrace):
        """실행 과정 상세 로깅"""
        logger.info("🚀 PATTERN EXECUTION TRACE")
        logger.info(f"  🆔 Execution ID: {trace.execution_id}")
        logger.info(f"  ✅ Success: {trace.success}")
        if trace.error_message:
            logger.error(f"  ❌ Error: {trace.error_message}")
        logger.info(f"  🎯 Patterns: {trace.selected_patterns}")
        logger.info(f"  📊 Confidence: {trace.confidence_score:.2f}")
        logger.info(f"  📏 Code Length: {trace.generated_code_length}")
        logger.info(f"  ⏱️ Timing:")
        logger.info(f"    - Query Analysis: {trace.query_analysis_time_ms:.2f}ms")
        logger.info(f"    - Pattern Selection: {trace.pattern_selection_time_ms:.2f}ms")
        logger.info(f"    - Code Generation: {trace.code_generation_time_ms:.2f}ms")
        logger.info(f"    - Template Conversion: {trace.template_conversion_time_ms:.2f}ms")
    
    def save_traces(self) -> Path:
        """추적 데이터 파일로 저장"""
        
        trace_data = {
            'session_id': self.session_id,
            'generated_at': datetime.now().isoformat(),
            'statistics': self.stats,
            'decision_traces': [asdict(trace) for trace in self.decision_traces],
            'execution_traces': [asdict(trace) for trace in self.execution_traces]
        }
        
        with open(self.trace_file, 'w', encoding='utf-8') as f:
            json.dump(trace_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"🔍 Debug traces saved to: {self.trace_file}")
        return self.trace_file
    
    def get_current_stats(self) -> Dict[str, Any]:
        """현재 통계 반환"""
        stats = self.stats.copy()
        stats['session_id'] = self.session_id
        stats['total_traces'] = len(self.decision_traces)
        stats['pattern_usage_rate'] = (
            (stats['pattern_system_chosen'] / max(stats['total_decisions'], 1)) * 100
        )
        stats['pattern_success_rate'] = (
            (stats['pattern_system_success'] / max(stats['pattern_system_chosen'], 1)) * 100
        )
        return stats
    
    def print_summary(self):
        """요약 정보 출력"""
        stats = self.get_current_stats()
        
        print("🔍 PATTERN DEBUG TRACER SUMMARY")
        print("=" * 50)
        print(f"Session ID: {stats['session_id']}")
        print(f"Total Decisions: {stats['total_decisions']}")
        print(f"Pattern System Chosen: {stats['pattern_system_chosen']} ({stats['pattern_usage_rate']:.1f}%)")
        print(f"Pattern System Success: {stats['pattern_system_success']}")
        print(f"Pattern System Failures: {stats['pattern_system_failures']}")
        print(f"Success Rate: {stats['pattern_success_rate']:.1f}%")
        print(f"Avg Decision Time: {stats['avg_decision_time']:.2f}ms")
        print(f"Avg Execution Time: {stats['avg_execution_time']:.2f}ms")


# 전역 디버거 인스턴스
_global_tracer = None

def get_pattern_tracer() -> PatternDebugTracer:
    """전역 패턴 디버거 인스턴스 반환"""
    global _global_tracer
    
    if _global_tracer is None:
        _global_tracer = PatternDebugTracer()
    
    return _global_tracer


# 편의 함수들
def trace_pattern_decision(template_id: str, user_request: str) -> PatternDecisionTrace:
    """패턴 결정 추적 편의 함수"""
    return get_pattern_tracer().trace_pattern_decision(template_id, user_request)

def trace_pattern_execution(execution_id: str, success: bool, **kwargs) -> PatternExecutionTrace:
    """패턴 실행 추적 편의 함수"""
    return get_pattern_tracer().trace_pattern_execution(execution_id, success, **kwargs)


if __name__ == "__main__":
    # 테스트
    tracer = PatternDebugTracer()
    
    # 테스트 케이스들
    test_cases = [
        ("data_analysis", "CSV 파일을 분석해서 데이터 품질을 확인하고 차트를 생성해줘"),
        ("comprehensive", "고객 데이터를 세그멘테이션하고 마케팅 전략을 추천해줘"),
        ("basic", "안녕하세요 테스트입니다"),
        ("advanced", "주식 포트폴리오 리스크 분석과 VaR 계산해줘")
    ]
    
    print("🧪 패턴 디버거 테스트 중...")
    
    for template_id, user_request in test_cases:
        trace = tracer.trace_pattern_decision(template_id, user_request)
        print(f"✅ {template_id}: {'패턴 사용' if trace.final_decision else '레거시 사용'} - {trace.decision_reason}")
    
    tracer.print_summary()
    tracer.save_traces()
