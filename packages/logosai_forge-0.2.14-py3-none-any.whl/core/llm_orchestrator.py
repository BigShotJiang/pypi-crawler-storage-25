"""
LLM Orchestrator for FORGE AI

Manages multiple LLM models and selects the optimal model for each task.
"""

import os
from enum import Enum
from typing import Dict, Optional, Any, List
import asyncio
import logging
from datetime import datetime
import json

logger = logging.getLogger(__name__)

# Import cache system
from .llm_cache import llm_cache

# LogosAI LLM client을 사용
try:
    from logosai.utils.llm_client import LLMClient, LLMProvider
    LOGOSAI_AVAILABLE = True
except ImportError:
    # Use direct Gemini client when LogosAI is not available
    from .direct_gemini_client import DirectGeminiClient
    LOGOSAI_AVAILABLE = False
    logger.warning("LogosAI LLMClient not available, using DirectGeminiClient")
    
    class LLMProvider:
        OPENAI = "openai"
        GOOGLE = "google"


class TaskType(Enum):
    """Types of tasks for LLM selection"""
    ANALYSIS = "analysis"
    CODE_GENERATION = "code_generation"
    VALIDATION = "validation"
    OPTIMIZATION = "optimization"
    DOCUMENTATION = "documentation"
    CONVERSATION = "conversation"
    ERROR_FIXING = "error_fixing"
    BUSINESS_LOGIC_EXTRACTION = "business_logic_extraction"
    CODE_FIXING = "code_fixing"


class ModelCapability:
    """Model capabilities and characteristics"""
    def __init__(self, model_id: str, capabilities: Dict[str, float], 
                 cost_per_1k: float = 0.0, latency_ms: int = 1000):
        self.model_id = model_id
        self.capabilities = capabilities  # Task type -> performance score (0-1)
        self.cost_per_1k = cost_per_1k
        self.latency_ms = latency_ms
        self.usage_count = 0
        self.success_rate = 1.0
        self.total_tokens = 0


class LLMOrchestrator:
    """Orchestrates multiple LLM models for optimal task execution"""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the orchestrator.
        
        Args:
            config: Configuration dictionary with API keys and settings
        """
        self.config = config or {}
        self.models: Dict[str, ModelCapability] = {}
        self.clients: Dict[str, LLMClient] = {}
        self.usage_stats: Dict[str, Dict] = {}
        
        # Initialize models
        self._initialize_models()
        
    def _initialize_models(self):
        """Initialize available models with their capabilities"""
        
        # Gemini Flash Lite - Fast and efficient for simple tasks
        if self.config.get('gemini_api_key') or os.getenv('GOOGLE_API_KEY'):
            self.models['gemini_flash_lite'] = ModelCapability(
                model_id='gemini-2.5-flash-lite',
                capabilities={
                    TaskType.ANALYSIS: 0.85,
                    TaskType.VALIDATION: 0.80,
                    TaskType.CONVERSATION: 0.90,
                    TaskType.ERROR_FIXING: 0.75,
                    TaskType.CODE_GENERATION: 0.70,
                    TaskType.OPTIMIZATION: 0.65,
                    TaskType.DOCUMENTATION: 0.75,
                    TaskType.BUSINESS_LOGIC_EXTRACTION: 0.80,
                    TaskType.CODE_FIXING: 0.75
                },
                cost_per_1k=0.001,
                latency_ms=500
            )
            
            # Gemini Pro - High quality for complex tasks
            self.models['gemini_pro'] = ModelCapability(
                model_id='gemini-2.5-flash-lite',
                capabilities={
                    TaskType.ANALYSIS: 0.90,
                    TaskType.CODE_GENERATION: 0.95,
                    TaskType.VALIDATION: 0.85,
                    TaskType.OPTIMIZATION: 0.90,
                    TaskType.DOCUMENTATION: 0.95,
                    TaskType.CONVERSATION: 0.85,
                    TaskType.ERROR_FIXING: 0.90,
                    TaskType.BUSINESS_LOGIC_EXTRACTION: 0.90,
                    TaskType.CODE_FIXING: 0.90
                },
                cost_per_1k=0.01,
                latency_ms=2000
            )

            # Gemini Flash - High quality for complex tasks
            self.models['gemini_flash'] = ModelCapability(
                model_id='gemini-2.5-flash',
                capabilities={
                    TaskType.ANALYSIS: 0.90,
                    TaskType.CODE_GENERATION: 0.95,
                    TaskType.VALIDATION: 0.85,
                    TaskType.OPTIMIZATION: 0.90,
                    TaskType.DOCUMENTATION: 0.95,
                    TaskType.CONVERSATION: 0.85,
                    TaskType.ERROR_FIXING: 0.90,
                    TaskType.BUSINESS_LOGIC_EXTRACTION: 0.90,
                    TaskType.CODE_FIXING: 0.90
                },
                cost_per_1k=0.01,
                latency_ms=1000
            )
            
            # Initialize clients based on availability
            for model_name in ['gemini_flash_lite', 'gemini_pro', 'gemini_flash']:
                if LOGOSAI_AVAILABLE:
                    self.clients[model_name] = LLMClient(
                        provider="google",
                        model=self.models[model_name].model_id,
                        api_key=self.config.get('gemini_api_key', os.getenv('GOOGLE_API_KEY')),
                        temperature=0.7
                    )
                else:
                    # Use direct Gemini client
                    self.clients[model_name] = DirectGeminiClient(
                        model_name=self.models[model_name].model_id,
                        api_key=self.config.get('gemini_api_key', os.getenv('GOOGLE_API_KEY'))
                    )
                
        # OpenAI models (if configured)
        if self.config.get('openai_api_key') or os.getenv('OPENAI_API_KEY'):
            self.models['gpt4'] = ModelCapability(
                model_id='gpt-4.1-mini',
                capabilities={
                    TaskType.ANALYSIS: 0.95,
                    TaskType.CODE_GENERATION: 0.90,
                    TaskType.VALIDATION: 0.90,
                    TaskType.OPTIMIZATION: 0.95,
                    TaskType.DOCUMENTATION: 0.90,
                    TaskType.CONVERSATION: 0.95,
                    TaskType.ERROR_FIXING: 0.85
                },
                cost_per_1k=0.03,
                latency_ms=3000
            )
            
            if LOGOSAI_AVAILABLE:
                self.clients['gpt4'] = LLMClient(
                    provider="openai",
                    model='gpt-4.1-mini',
                    api_key=self.config.get('openai_api_key', os.getenv('OPENAI_API_KEY')),
                    temperature=0.7
                )
            # Note: DirectGeminiClient doesn't support OpenAI, so skip if LogosAI unavailable
            
        # Local models (if configured)
        if self.config.get('use_local_models', False):
            self.models['local_llama'] = ModelCapability(
                model_id='llama2:7b',
                capabilities={
                    TaskType.ANALYSIS: 0.70,
                    TaskType.CODE_GENERATION: 0.65,
                    TaskType.VALIDATION: 0.75,
                    TaskType.OPTIMIZATION: 0.60,
                    TaskType.DOCUMENTATION: 0.70,
                    TaskType.CONVERSATION: 0.75,
                    TaskType.ERROR_FIXING: 0.65
                },
                cost_per_1k=0.0,
                latency_ms=1000
            )
            
        logger.info(f"Initialized {len(self.models)} models")
        
    async def select_model(self, task_type: TaskType, 
                          requirements: Optional[Dict] = None) -> str:
        """
        Select the optimal model for a task.
        Now enhanced with smart selection from llm_config.yaml
        
        Args:
            task_type: Type of task to perform
            requirements: Optional requirements (speed, quality, cost)
            
        Returns:
            Selected model name
        """
        requirements = requirements or {}
        
        # Try smart selection from llm_config.yaml first
        try:
            from .llm_manager import FORGELLMManager
            llm_manager = FORGELLMManager()
            
            # Map TaskType enum to config task names
            task_mapping = {
                TaskType.ANALYSIS: "query_understanding",
                TaskType.CODE_GENERATION: "complex_code_generation",
                TaskType.VALIDATION: "agent_validation",
                TaskType.OPTIMIZATION: "performance_optimization",
                TaskType.DOCUMENTATION: "documentation_generation",
                TaskType.CONVERSATION: "conversation",
                TaskType.ERROR_FIXING: "complex_debugging",
                TaskType.BUSINESS_LOGIC_EXTRACTION: "query_understanding",
                TaskType.CODE_FIXING: "complex_debugging"
            }
            
            # Consider urgency requirements
            if requirements.get('speed') == 'fast':
                # Override to use faster models
                task_mapping[TaskType.CODE_GENERATION] = "simple_code_generation"
                task_mapping[TaskType.VALIDATION] = "basic_validation"
            
            config_task = task_mapping.get(task_type)
            if config_task:
                model_key = llm_manager.config['task_model_mapping'].get(config_task)
                if model_key:
                    # Map config model to our model names
                    model_mapping = {
                        "gemini.flash_lite": "gemini_flash_lite",
                        "gemini.flash": "gemini_flash",
                        "gemini.pro": "gemini_pro"
                    }
                    
                    model_name = model_mapping.get(model_key)
                    if model_name and model_name in self.models:
                        logger.info(f"Selected {model_name} for {task_type.value} based on llm_config.yaml")
                        return model_name
        except Exception as e:
            logger.warning(f"Failed to use llm_config.yaml: {e}")
        
        # Priority overrides
        if requirements.get('model'):
            return requirements['model']
            
        # Filter available models
        available_models = [
            (name, model) for name, model in self.models.items()
            if name in self.clients
        ]
        
        if not available_models:
            raise ValueError("No models available")
            
        # Score models based on requirements
        scores = {}
        
        for name, model in available_models:
            # Base score from capability
            score = model.capabilities.get(task_type, 0.5)
            
            # Adjust for requirements
            if requirements.get('speed') == 'critical':
                # Prefer low latency
                latency_score = 1.0 - (model.latency_ms / 5000)
                score = score * 0.7 + latency_score * 0.3
                
            elif requirements.get('quality') == 'critical':
                # Prefer high capability
                score = score * 1.2
                
            elif requirements.get('cost') == 'critical':
                # Prefer low cost
                cost_score = 1.0 - (model.cost_per_1k / 0.1)
                score = score * 0.7 + cost_score * 0.3
                
            # Adjust for success rate
            score *= model.success_rate
            
            scores[name] = score
            
        # Select best model
        best_model = max(scores.items(), key=lambda x: x[1])[0]
        
        logger.debug(f"Selected {best_model} for {task_type.value} (scores: {scores})")
        return best_model
    
    async def process_task(self, prompt: str, task_type: TaskType, **kwargs) -> str:
        """
        Legacy method name for backward compatibility.
        Delegates to generate() method.
        
        Args:
            prompt: Input prompt
            task_type: Type of task
            **kwargs: Additional generation parameters
            
        Returns:
            Generated response
        """
        return await self.generate(prompt, task_type, **kwargs)
        
    async def generate(self, prompt: str, 
                      task_type: TaskType = TaskType.ANALYSIS,
                      model: Optional[str] = None,
                      **kwargs) -> str:
        """
        Generate response using the optimal model.
        
        Args:
            prompt: Input prompt
            task_type: Type of task
            model: Optional specific model to use
            **kwargs: Additional generation parameters
            
        Returns:
            Generated response
        """
        # Select model if not specified
        if not model:
            model = await self.select_model(task_type, kwargs)
        
        # Override with model_override if provided
        if 'model_override' in kwargs:
            model_override = kwargs['model_override']
            # Map common model names to internal names
            model_name_mapping = {
                'gemini-2.5-pro': 'gemini_pro',
                'gemini-2.5-flash': 'gemini_flash',
                'gemini-2.5-flash-lite': 'gemini_flash_lite',
                'gpt-4.1-mini': 'gpt4'
            }
            model = model_name_mapping.get(model_override, model_override)
            
        if model not in self.clients:
            raise ValueError(f"Model {model} not available")
        
        # Check cache first
        temperature = kwargs.get('temperature', 0.7)
        cached_response = llm_cache.get(prompt, model, temperature)
        if cached_response and not kwargs.get('force_refresh', False):
            logger.info(f"Using cached response for {model}")
            return cached_response
            
        # Optimize prompt for model
        optimized_prompt = self._optimize_prompt(prompt, model, task_type)
        
        # Add JSON format instruction for code generation tasks
        if task_type in [TaskType.CODE_GENERATION, TaskType.BUSINESS_LOGIC_EXTRACTION, TaskType.CODE_FIXING]:
            if '```' not in optimized_prompt and 'json' not in optimized_prompt.lower():
                optimized_prompt = optimized_prompt + '\n\nPlease return your response in JSON format only. Do not use code blocks (backticks). Return pure JSON structure.'
        
        # Track usage
        start_time = asyncio.get_event_loop().time()
        
        try:
            # Track API call for streaming
            if 'stream_callback' in kwargs:
                await kwargs['stream_callback'](
                    'api_calling',
                    f'Google Gemini API 호출 중... (Model: {model})',
                    {
                        'endpoint': 'https://generativelanguage.googleapis.com/v1beta/models/generateContent',
                        'model': model,
                        'task_type': task_type.value
                    }
                )
            
            # Generate response using appropriate client
            client = self.clients[model]
            api_start_time = asyncio.get_event_loop().time()
            
            if LOGOSAI_AVAILABLE:
                response = await client.invoke(
                    optimized_prompt,
                    temperature=kwargs.get('temperature', 0.7),
                    max_tokens=kwargs.get('max_tokens', 15000)  # 충분한 토큰으로 증가
                )
            else:
                # Use DirectGeminiClient's generate method
                response = await client.generate(
                    optimized_prompt,
                    temperature=kwargs.get('temperature', 0.7),
                    max_tokens=kwargs.get('max_tokens', 15000)  # 충분한 토큰으로 추가
                )
            
            api_end_time = asyncio.get_event_loop().time()
            api_duration = (api_end_time - api_start_time) * 1000  # Convert to ms
            
            # Extract text content from response
            if isinstance(response, str):
                # DirectGeminiClient returns string directly
                response_text = response
            elif hasattr(response, 'content'):
                response_text = response.content
            elif hasattr(response, 'text'):
                response_text = response.text
            else:
                response_text = str(response)
            
            # Track API response for streaming
            if 'stream_callback' in kwargs:
                await kwargs['stream_callback'](
                    'api_calling',
                    f'API 응답 수신 완료 ({api_duration:.0f}ms)',
                    {
                        'response_time': api_duration,
                        'tokens': len(response_text.split()),
                        'model': model
                    }
                )
            
            # Update statistics
            self._update_stats(model, True, start_time)
            
            # Cache the response
            llm_cache.set(prompt, model, temperature, response_text)
            
            return response_text
            
        except Exception as e:
            logger.error(f"Generation failed with {model}: {e}")
            self._update_stats(model, False, start_time)
            
            # Try fallback
            return await self._fallback_generate(prompt, task_type, kwargs, exclude=[model])
            
    async def _fallback_generate(self, prompt: str, task_type: TaskType,
                                kwargs: Dict, exclude: List[str]) -> str:
        """Fallback generation with alternative model"""
        
        # Get alternative models
        available = [m for m in self.models.keys() if m not in exclude and m in self.clients]
        
        if not available:
            raise Exception("All models failed")
            
        # Try next best model
        requirements = kwargs.copy()
        requirements['exclude'] = exclude
        
        fallback_model = await self.select_model(task_type, requirements)
        
        logger.info(f"Falling back to {fallback_model}")
        
        return await self.generate(
            prompt, task_type, model=fallback_model, **kwargs
        )
        
    def _optimize_prompt(self, prompt: str, model: str, task_type: TaskType) -> str:
        """Optimize prompt for specific model"""
        
        # For now, return the original prompt without generic prefixes
        # The code generator creates specialized prompts that shouldn't be wrapped
        return prompt
        
        # Model-specific optimizations (disabled to avoid generic prefixes)
        if False and 'gemini' in model:
            # Gemini prefers structured prompts
            if task_type == TaskType.CODE_GENERATION:
                return f"""Generate Python code for the following requirement:

{prompt}

Requirements:
- Follow Python best practices
- Include proper error handling
- Add type hints
- Include docstrings
"""
            elif task_type == TaskType.ANALYSIS:
                return f"""Analyze the following query and extract key information:

Query: {prompt}

Provide a structured analysis including:
1. Main intent
2. Required capabilities
3. Constraints or requirements
4. Suggested approach
"""
                
        elif 'gpt' in model:
            # GPT works well with conversational prompts
            if task_type == TaskType.CODE_GENERATION:
                return f"As an expert Python developer, {prompt}"
                
        # Default optimization
        return prompt
        
    def _update_stats(self, model: str, success: bool, start_time: float):
        """Update model usage statistics"""
        
        duration = asyncio.get_event_loop().time() - start_time
        
        if model not in self.usage_stats:
            self.usage_stats[model] = {
                'total_requests': 0,
                'successful_requests': 0,
                'total_duration': 0.0,
                'errors': []
            }
            
        stats = self.usage_stats[model]
        stats['total_requests'] += 1
        stats['total_duration'] += duration
        
        if success:
            stats['successful_requests'] += 1
        else:
            stats['errors'].append({
                'timestamp': datetime.now().isoformat(),
                'duration': duration
            })
            
        # Update model success rate
        model_cap = self.models.get(model)
        if model_cap:
            model_cap.usage_count += 1
            model_cap.success_rate = stats['successful_requests'] / stats['total_requests']
            
    async def batch_generate(self, prompts: List[Dict[str, Any]]) -> List[str]:
        """
        Generate responses for multiple prompts in parallel.
        
        Args:
            prompts: List of dicts with 'prompt', 'task_type', and optional params
            
        Returns:
            List of generated responses
        """
        tasks = []
        
        for prompt_data in prompts:
            task = self.generate(
                prompt_data['prompt'],
                prompt_data.get('task_type', TaskType.ANALYSIS),
                **prompt_data.get('kwargs', {})
            )
            tasks.append(task)
            
        return await asyncio.gather(*tasks)
        
    def get_stats(self) -> Dict[str, Any]:
        """Get usage statistics"""
        return {
            'models': {
                name: {
                    'capabilities': model.capabilities,
                    'usage_count': model.usage_count,
                    'success_rate': model.success_rate,
                    'cost_per_1k': model.cost_per_1k,
                    'latency_ms': model.latency_ms
                }
                for name, model in self.models.items()
            },
            'usage': self.usage_stats
        }
        
    def estimate_cost(self, tokens: int, model: str) -> float:
        """Estimate cost for token usage"""
        model_cap = self.models.get(model)
        if model_cap:
            return (tokens / 1000) * model_cap.cost_per_1k
        return 0.0