"""
Code Post-Processor for FORGE AI
Automatically fixes common syntax errors in generated code
"""

import ast
import re
from typing import Tuple, List, Optional
from loguru import logger


class CodePostProcessor:
    """Post-process generated code to fix common issues"""
    
    def __init__(self):
        self.common_fixes = [
            self._fix_dict_syntax_errors,
            self._fix_unmatched_braces,
            self._fix_incomplete_strings,
            self._fix_mixed_indentation,
            self._fix_template_placeholders
        ]
    
    def process(self, code: str) -> Tuple[str, List[str]]:
        """
        Process code and fix common issues
        
        Returns:
            (fixed_code, list_of_fixes_applied)
        """
        fixes_applied = []
        fixed_code = code
        
        # Apply each fix
        for fix_func in self.common_fixes:
            result, was_fixed = fix_func(fixed_code)
            if was_fixed:
                fixed_code = result
                fixes_applied.append(fix_func.__name__)
        
        # Validate final code
        is_valid = self._validate_syntax(fixed_code)
        
        if not is_valid:
            logger.warning("Code still has syntax errors after post-processing")
        else:
            logger.info(f"Code post-processing complete. Fixes applied: {fixes_applied}")
        
        return fixed_code, fixes_applied
    
    def _fix_dict_syntax_errors(self, code: str) -> Tuple[str, bool]:
        """Fix dictionary syntax errors like missing colons"""
        lines = code.split('\n')
        fixed_lines = []
        was_fixed = False
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Check for config={{ pattern
            if 'config={{' in line or 'config={' in line:
                # Start of a config dict
                fixed_lines.append(line)
                i += 1
                
                # Process lines inside the dict
                brace_count = 1
                inside_config = True
                while i < len(lines) and brace_count > 0:
                    dict_line = lines[i]
                    
                    # Count braces
                    brace_count += dict_line.count('{') - dict_line.count('}')
                    
                    # Check if this line contains code that should be outside the config
                    stripped = dict_line.strip()
                    
                    # Pattern 1: self.something = ... (should be in custom_init)
                    if stripped.startswith('self.') and '=' in stripped and inside_config:
                        # This is initialization code that should be outside config
                        indent = len(dict_line) - len(dict_line.lstrip())
                        
                        # Close the config dict first
                        closing_braces = '}' * brace_count
                        fixed_lines.append(' ' * (indent - 8) + closing_braces)
                        fixed_lines.append(' ' * (indent - 8) + ')')
                        fixed_lines.append('')
                        fixed_lines.append(' ' * 8 + 'super().__init__(config)')
                        fixed_lines.append('')
                        fixed_lines.append(' ' * 8 + '# Initialize instance variables')
                        fixed_lines.append(' ' * 8 + 'self.llm_client: Optional[LLMClient] = None')
                        fixed_lines.append(' ' * 8 + 'self.dialogue_capability = DialogueCapability(self)')
                        fixed_lines.append('')
                        fixed_lines.append(' ' * 8 + '# Add any custom initialization here')
                        fixed_lines.append(' ' * 8 + stripped)
                        
                        i += 1
                        was_fixed = True
                        inside_config = False
                        brace_count = 0
                        continue
                    
                    # Check for comment followed by code without proper structure
                    if '# ' in dict_line and i + 1 < len(lines):
                        next_line = lines[i + 1].strip()
                        
                        # If next line starts with self. and current line is comment inside dict
                        if next_line.startswith('self.') and brace_count > 0 and inside_config:
                            # This is likely a misplaced statement
                            # Close the dict first
                            indent = len(lines[i]) - len(lines[i].lstrip())
                            fixed_lines.append(lines[i])  # Keep the comment
                            
                            # Close the config dict
                            closing_braces = '}' * brace_count
                            fixed_lines.append(' ' * (indent - 4) + closing_braces)
                            fixed_lines.append(' ' * (indent - 4) + ')')
                            fixed_lines.append('')
                            fixed_lines.append(' ' * 8 + 'super().__init__(config)')
                            fixed_lines.append('')
                            fixed_lines.append(' ' * 8 + '# Initialize instance variables')
                            fixed_lines.append(' ' * 8 + 'self.llm_client: Optional[LLMClient] = None')
                            fixed_lines.append(' ' * 8 + 'self.dialogue_capability = DialogueCapability(self)')
                            fixed_lines.append('')
                            fixed_lines.append(' ' * 8 + '# Add any custom initialization here')
                            fixed_lines.append(' ' * 8 + next_line)
                            
                            i += 2  # Skip both lines
                            was_fixed = True
                            inside_config = False
                            brace_count = 0  # Exit the dict processing
                            continue
                    
                    # Normal dict line
                    fixed_lines.append(dict_line)
                    i += 1
                
                # If we exited the config dict processing normally, continue with remaining lines
                if inside_config:
                    inside_config = False
            else:
                fixed_lines.append(line)
                i += 1
        
        return '\n'.join(fixed_lines), was_fixed
    
    def _fix_unmatched_braces(self, code: str) -> Tuple[str, bool]:
        """Fix unmatched braces and parentheses"""
        # Count all braces and parentheses
        open_braces = code.count('{')
        close_braces = code.count('}')
        open_parens = code.count('(')
        close_parens = code.count(')')
        
        was_fixed = False
        
        # Add missing closing braces
        if open_braces > close_braces:
            code += '\n' + '}' * (open_braces - close_braces)
            was_fixed = True
        
        # Add missing closing parentheses
        if open_parens > close_parens:
            code += ')' * (open_parens - close_parens)
            was_fixed = True
        
        return code, was_fixed
    
    def _fix_incomplete_strings(self, code: str) -> Tuple[str, bool]:
        """Fix incomplete string literals"""
        lines = code.split('\n')
        fixed_lines = []
        was_fixed = False
        
        for line in lines:
            # Count quotes
            single_quotes = line.count("'") - line.count("\\'")
            double_quotes = line.count('"') - line.count('\\"')
            
            # Fix odd number of quotes
            if single_quotes % 2 == 1:
                line += "'"
                was_fixed = True
            
            if double_quotes % 2 == 1:
                line += '"'
                was_fixed = True
            
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines), was_fixed
    
    def _fix_mixed_indentation(self, code: str) -> Tuple[str, bool]:
        """Fix mixed tabs and spaces"""
        if '\t' in code:
            # Replace tabs with 4 spaces
            return code.replace('\t', '    '), True
        return code, False
    
    def _fix_template_placeholders(self, code: str) -> Tuple[str, bool]:
        """Remove or fix template placeholders that weren't replaced"""
        # Pattern for unreplaced template variables
        pattern = r'\{[a-zA-Z_]+\}'
        
        # Check if there are unreplaced placeholders
        if re.search(pattern, code):
            # Replace with empty strings or comments
            fixed = re.sub(pattern, '""', code)
            return fixed, True
        
        return code, False
    
    def _validate_syntax(self, code: str) -> bool:
        """Validate Python syntax"""
        try:
            ast.parse(code)
            return True
        except SyntaxError as e:
            logger.debug(f"Syntax error: {e}")
            return False
    
    def extract_syntax_error_line(self, code: str) -> Optional[int]:
        """Get the line number of the first syntax error"""
        try:
            ast.parse(code)
            return None
        except SyntaxError as e:
            return e.lineno