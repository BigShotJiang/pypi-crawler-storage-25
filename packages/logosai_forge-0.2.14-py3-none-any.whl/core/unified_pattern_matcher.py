"""
Unified Pattern Matcher for FORGE AI
통합된 패턴 매칭 시스템 - 키워드 기반과 LLM 기반을 효율적으로 결합

Author: FORGE AI Team
Date: 2025-01-21  
Version: 1.0.0
"""

from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
import re
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)


class PatternType(Enum):
    """Pattern types for categorization"""
    DATA_PROCESSING = "data_processing"
    API_INTEGRATION = "api_integration"
    FILE_HANDLING = "file_handling"
    WEB_SCRAPING = "web_scraping"
    ML_AI = "ml_ai"
    DATABASE = "database"
    MONITORING = "monitoring"
    AUTOMATION = "automation"
    COMMUNICATION = "communication"
    ANALYTICS = "analytics"
    SECURITY = "security"
    VISUALIZATION = "visualization"
    GENERAL = "general"


@dataclass
class PatternMatch:
    """Result of pattern matching"""
    pattern_id: str
    pattern_type: PatternType
    confidence: float
    matched_keywords: List[str] = field(default_factory=list)
    template_id: Optional[str] = None
    business_logic_hints: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'pattern_id': self.pattern_id,
            'pattern_type': self.pattern_type.value,
            'confidence': self.confidence,
            'matched_keywords': self.matched_keywords,
            'template_id': self.template_id,
            'business_logic_hints': self.business_logic_hints,
            'metadata': self.metadata
        }


# Alias for compatibility with pipeline
PatternMatchResult = PatternMatch


@dataclass  
class PatternMatchResult:
    """Result of pattern matching for pipeline compatibility"""
    patterns: List[str] = field(default_factory=list)
    template_type: str = "general"
    confidence: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_pattern_match(cls, match: PatternMatch) -> 'PatternMatchResult':
        """Convert PatternMatch to PatternMatchResult"""
        return cls(
            patterns=[match.pattern_id],
            template_type=match.template_id or "general",
            confidence=match.confidence,
            metadata=match.metadata
        )


class UnifiedPatternMatcher:
    """
    통합된 패턴 매칭 시스템
    키워드 기반 매칭을 주로 사용하고, 복잡한 경우 LLM 지원
    """
    
    # 핵심 패턴 정의 (확장 및 개선됨)
    PATTERNS = {
        'sentiment_analysis': {
            'type': PatternType.ML_AI,
            'keywords': ['sentiment', 'emotion', 'feeling', 'opinion', 'attitude', '감정', '의견', 'positive', 'negative', 'neutral'],
            'template_id': 'sentiment_analyzer',
            'weight': 1.2,
            'business_logic': {
                'input_type': 'text',
                'output_type': 'sentiment_score',
                'processing_steps': ['text_preprocessing', 'sentiment_extraction', 'score_calculation']
            }
        },
        'data_analyzer': {
            'type': PatternType.DATA_PROCESSING,
            'keywords': ['analyze', 'data', 'statistics', 'aggregate', 'calculate', '분석', '데이터', '통계', 'pandas', 'dataframe'],
            'template_id': 'data_analyzer',
            'weight': 1.1,
            'business_logic': {
                'input_type': 'structured_data',
                'output_type': 'analysis_results',
                'processing_steps': ['data_loading', 'data_cleaning', 'statistical_analysis', 'report_generation']
            }
        },
        'api_integration': {
            'type': PatternType.API_INTEGRATION,
            'keywords': ['api', 'rest', 'endpoint', 'http', 'request', 'webhook', 'integration', '연동', 'fetch', 'post', 'get'],
            'template_id': 'api_agent',
            'weight': 1.0,
            'business_logic': {
                'input_type': 'api_request',
                'output_type': 'api_response',
                'processing_steps': ['request_validation', 'api_call', 'response_parsing', 'error_handling']
            }
        },
        'web_scraper': {
            'type': PatternType.WEB_SCRAPING,
            'keywords': ['scrape', 'crawl', 'extract', 'web', 'html', 'selenium', 'beautifulsoup', '크롤링', 'spider', 'parse'],
            'template_id': 'web_scraper',
            'weight': 1.0,
            'business_logic': {
                'input_type': 'url',
                'output_type': 'extracted_data',
                'processing_steps': ['url_validation', 'page_fetch', 'data_extraction', 'data_structuring']
            }
        },
        'file_processor': {
            'type': PatternType.FILE_HANDLING,
            'keywords': ['file', 'csv', 'excel', 'json', 'xml', 'pdf', 'read', 'write', 'parse', '파일', 'document'],
            'template_id': 'file_handler',
            'weight': 0.9,
            'business_logic': {
                'input_type': 'file_path',
                'output_type': 'processed_content',
                'processing_steps': ['file_validation', 'content_reading', 'data_processing', 'output_formatting']
            }
        },
        'database_agent': {
            'type': PatternType.DATABASE,
            'keywords': ['database', 'sql', 'query', 'table', 'postgres', 'mysql', 'mongodb', '데이터베이스', 'select', 'insert'],
            'template_id': 'database_agent',
            'weight': 1.1,
            'business_logic': {
                'input_type': 'sql_query',
                'output_type': 'query_results',
                'processing_steps': ['connection_setup', 'query_execution', 'result_processing', 'connection_cleanup']
            }
        },
        'monitoring_agent': {
            'type': PatternType.MONITORING,
            'keywords': ['monitor', 'track', 'watch', 'alert', 'metric', 'log', '모니터링', '감시', 'observe', 'detect'],
            'template_id': 'monitor_agent',
            'weight': 1.0,
            'business_logic': {
                'input_type': 'metric_source',
                'output_type': 'monitoring_alerts',
                'processing_steps': ['metric_collection', 'threshold_checking', 'alert_generation', 'notification']
            }
        },
        'scheduler': {
            'type': PatternType.AUTOMATION,
            'keywords': ['schedule', 'cron', 'periodic', 'recurring', 'daily', 'hourly', '스케줄', '주기', 'automate', 'trigger'],
            'template_id': 'scheduler_agent',
            'weight': 0.9,
            'business_logic': {
                'input_type': 'schedule_config',
                'output_type': 'execution_results',
                'processing_steps': ['schedule_parsing', 'task_execution', 'result_logging', 'next_run_scheduling']
            }
        },
        'notification_agent': {
            'type': PatternType.COMMUNICATION,
            'keywords': ['email', 'notify', 'alert', 'message', 'slack', 'sms', '알림', '메시지', 'send', 'notification'],
            'template_id': 'notification_agent',
            'weight': 0.8,
            'business_logic': {
                'input_type': 'message_content',
                'output_type': 'delivery_status',
                'processing_steps': ['recipient_validation', 'message_formatting', 'channel_selection', 'delivery']
            }
        },
        'ml_predictor': {
            'type': PatternType.ML_AI,
            'keywords': ['predict', 'forecast', 'machine learning', 'model', 'train', 'classify', '예측', '머신러닝', 'neural', 'ai'],
            'template_id': 'ml_agent',
            'weight': 1.3,
            'business_logic': {
                'input_type': 'training_data',
                'output_type': 'predictions',
                'processing_steps': ['data_preprocessing', 'model_training', 'prediction', 'confidence_scoring']
            }
        },
        'report_generator': {
            'type': PatternType.ANALYTICS,
            'keywords': ['report', 'summary', 'analytics', 'dashboard', 'metrics', '보고서', '요약', 'kpi', 'visualization'],
            'template_id': 'report_agent',
            'weight': 1.0,
            'business_logic': {
                'input_type': 'raw_data',
                'output_type': 'formatted_report',
                'processing_steps': ['data_aggregation', 'metric_calculation', 'visualization_generation', 'report_formatting']
            }
        },
        'security_scanner': {
            'type': PatternType.SECURITY,
            'keywords': ['security', 'scan', 'vulnerability', 'audit', 'compliance', '보안', '취약점', 'penetration', 'risk'],
            'template_id': 'security_agent',
            'weight': 1.2,
            'business_logic': {
                'input_type': 'target_system',
                'output_type': 'security_report',
                'processing_steps': ['vulnerability_scanning', 'risk_assessment', 'compliance_checking', 'report_generation']
            }
        },
        'translation_agent': {
            'type': PatternType.COMMUNICATION,
            'keywords': ['translate', 'translation', 'language', '번역', '언어', 'multilingual', 'localization'],
            'template_id': 'translator',
            'weight': 0.9,
            'business_logic': {
                'input_type': 'source_text',
                'output_type': 'translated_text',
                'processing_steps': ['language_detection', 'translation', 'quality_check', 'formatting']
            }
        },
        'calculator': {
            'type': PatternType.DATA_PROCESSING,
            'keywords': ['calculate', 'compute', 'math', 'arithmetic', '계산', '수학', 'formula', 'equation'],
            'template_id': 'calculator',
            'weight': 0.8,
            'business_logic': {
                'input_type': 'expression',
                'output_type': 'calculation_result',
                'processing_steps': ['expression_parsing', 'calculation', 'result_formatting']
            }
        },
        'weather_agent': {
            'type': PatternType.API_INTEGRATION,
            'keywords': ['weather', 'temperature', 'forecast', '날씨', '기온', '예보', 'climate', 'rain'],
            'template_id': 'weather_info',
            'weight': 0.9,
            'business_logic': {
                'input_type': 'location',
                'output_type': 'weather_data',
                'processing_steps': ['location_validation', 'api_fetch', 'data_parsing', 'forecast_formatting']
            }
        }
    }
    
    def __init__(self):
        """Initialize the unified pattern matcher"""
        self.pattern_cache = {}
        self._compile_patterns()
        logger.info("UnifiedPatternMatcher initialized with %d patterns", len(self.PATTERNS))
    
    def _compile_patterns(self):
        """Compile regex patterns for efficient matching"""
        for pattern_id, pattern_data in self.PATTERNS.items():
            keywords = pattern_data['keywords']
            # Create regex pattern - use word boundaries for English, but not for Korean
            patterns = []
            for kw in keywords:
                # Check if keyword contains Korean characters
                if any('\u3131' <= char <= '\u3163' or '\uac00' <= char <= '\ud7a3' for char in kw):
                    # Korean keyword - don't use word boundaries
                    patterns.append(re.escape(kw))
                else:
                    # English keyword - use word boundaries
                    patterns.append(r'\b' + re.escape(kw) + r'\b')
            
            pattern_regex = '|'.join(patterns)
            self.pattern_cache[pattern_id] = re.compile(pattern_regex, re.IGNORECASE)
    
    def match(self, query: str, threshold: float = 0.2) -> List[PatternMatch]:
        """
        Match query against all patterns
        
        Args:
            query: User query string
            threshold: Minimum confidence threshold
            
        Returns:
            List of pattern matches sorted by confidence
        """
        matches = []
        query_lower = query.lower()
        
        for pattern_id, pattern_data in self.PATTERNS.items():
            confidence, matched_keywords = self._calculate_pattern_confidence(
                query_lower, pattern_id, pattern_data
            )
            
            if confidence >= threshold:
                match = PatternMatch(
                    pattern_id=pattern_id,
                    pattern_type=pattern_data['type'],
                    confidence=confidence,
                    matched_keywords=matched_keywords,
                    template_id=pattern_data.get('template_id'),
                    business_logic_hints=pattern_data.get('business_logic', {}),
                    metadata={
                        'weight': pattern_data.get('weight', 1.0),
                        'timestamp': datetime.now().isoformat()
                    }
                )
                matches.append(match)
        
        # Sort by confidence (highest first)
        matches.sort(key=lambda x: x.confidence, reverse=True)
        
        logger.info(f"Found {len(matches)} pattern matches for query")
        return matches
    
    def _calculate_pattern_confidence(
        self, query: str, pattern_id: str, pattern_data: Dict
    ) -> Tuple[float, List[str]]:
        """
        Calculate confidence score for a pattern match
        
        Args:
            query: Lowercased query string
            pattern_id: Pattern identifier
            pattern_data: Pattern configuration
            
        Returns:
            Tuple of (confidence_score, matched_keywords)
        """
        pattern_regex = self.pattern_cache.get(pattern_id)
        if not pattern_regex:
            return 0.0, []
        
        # Find all matches
        matches = pattern_regex.findall(query)
        if not matches:
            return 0.0, []
        
        # Calculate base confidence
        keywords = pattern_data['keywords']
        match_count = len(matches)
        unique_matches = list(set(matches))
        
        # Base confidence: ratio of matched keywords
        base_confidence = len(unique_matches) / len(keywords)
        
        # Boost confidence based on:
        # 1. Number of matches (repetition)
        repetition_boost = min(match_count / 10, 0.2)  # Max 0.2 boost
        
        # 2. Pattern weight
        weight = pattern_data.get('weight', 1.0)
        
        # 3. Position in query (earlier matches are stronger)
        position_boost = 0.0
        for match in unique_matches[:3]:  # Check first 3 unique matches
            pos = query.find(match.lower())
            if pos < len(query) / 3:  # In first third of query
                position_boost += 0.05
        
        # Calculate final confidence
        confidence = (base_confidence * weight) + repetition_boost + position_boost
        confidence = min(confidence, 1.0)  # Cap at 1.0
        
        return confidence, unique_matches
    
    def get_best_match(self, query: str) -> Optional[PatternMatch]:
        """
        Get the best matching pattern for a query
        
        Args:
            query: User query string
            
        Returns:
            Best pattern match or None
        """
        matches = self.match(query)
        return matches[0] if matches else None
    
    def get_template_for_query(self, query: str) -> Optional[str]:
        """
        Get the most suitable template ID for a query
        
        Args:
            query: User query string
            
        Returns:
            Template ID or None
        """
        best_match = self.get_best_match(query)
        return best_match.template_id if best_match else None
    
    def get_business_logic_hints(self, query: str) -> Dict[str, Any]:
        """
        Get business logic hints for a query
        
        Args:
            query: User query string
            
        Returns:
            Business logic configuration hints
        """
        best_match = self.get_best_match(query)
        if best_match:
            return best_match.business_logic_hints
        
        # Return default hints
        return {
            'input_type': 'generic',
            'output_type': 'processed_result',
            'processing_steps': ['input_validation', 'processing', 'output_formatting']
        }
    
    def enhance_with_llm(self, query: str, matches: List[PatternMatch]) -> List[PatternMatch]:
        """
        Enhance pattern matching with LLM analysis (placeholder for future LLM integration)
        This method can be extended to use LLM for complex pattern recognition
        
        Args:
            query: User query string
            matches: Initial pattern matches
            
        Returns:
            Enhanced pattern matches
        """
        # For now, just return the original matches
        # In future, this can call an LLM to refine confidence scores
        # or identify patterns that keyword matching missed
        return matches
    
    async def match_for_pipeline(self, query_result) -> PatternMatchResult:
        """
        Match patterns for pipeline compatibility
        
        Args:
            query_result: QueryAnalysisResult from query analyzer
            
        Returns:
            PatternMatchResult for use in pipeline
        """
        # Extract query from result
        query = query_result.query if hasattr(query_result, 'query') else str(query_result)
        
        # Get pattern matches
        matches = self.match(query)
        
        # Convert to PatternMatchResult
        if matches:
            best_match = matches[0]  # Get best match
            result = PatternMatchResult(
                patterns=[m.pattern_id for m in matches],
                template_type=best_match.template_id or "general",
                confidence=best_match.confidence,
                metadata={
                    'matched_keywords': best_match.matched_keywords,
                    'business_logic_hints': best_match.business_logic_hints
                }
            )
        else:
            result = PatternMatchResult(
                patterns=[],
                template_type="general",
                confidence=0.0,
                metadata={}
            )
        
        return result


# Singleton instance
pattern_matcher = UnifiedPatternMatcher()


def match_patterns(query: str) -> List[PatternMatch]:
    """
    Convenience function for pattern matching
    
    Args:
        query: User query string
        
    Returns:
        List of pattern matches
    """
    return pattern_matcher.match(query)


def get_template_id(query: str) -> Optional[str]:
    """
    Convenience function to get template ID
    
    Args:
        query: User query string
        
    Returns:
        Template ID or None
    """
    return pattern_matcher.get_template_for_query(query)