"""
사전 정의된 Helper 함수 라이브러리
자주 사용되는 helper 함수들을 미리 정의
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, List, Union, Optional
from datetime import datetime
import re
import json

class HelperLibrary:
    """사전 정의된 helper 함수 모음"""
    
    # ==================== 매칭/스코어링 함수 ====================
    
    @staticmethod
    def get_match_score_functions():
        """매칭 점수 계산 관련 함수들"""
        return '''
def calculate_match_score(items1, items2):
    """두 리스트 간의 매칭 점수 계산"""
    if not items1 or not items2:
        return 0.0
    
    set1 = set(items1) if isinstance(items1, list) else {items1}
    set2 = set(items2) if isinstance(items2, list) else {items2}
    
    common = set1 & set2
    total = set1 | set2
    
    if total:
        score = len(common) / len(total) * 100
        return round(score, 2)
    return 0.0

def calculate_weighted_score(scores_dict, weights_dict=None):
    """가중치가 적용된 점수 계산"""
    if not scores_dict:
        return 0.0
    
    if not weights_dict:
        # 동일 가중치
        return sum(scores_dict.values()) / len(scores_dict)
    
    total_weight = sum(weights_dict.values())
    if total_weight == 0:
        return 0.0
    
    weighted_sum = sum(
        scores_dict.get(key, 0) * weights_dict.get(key, 0)
        for key in scores_dict.keys()
    )
    
    return round(weighted_sum / total_weight, 2)

def evaluate_experience(required_years, actual_years):
    """경력 연수 평가"""
    try:
        req = float(required_years) if required_years else 0
        act = float(actual_years) if actual_years else 0
        
        if req == 0:
            return 100.0  # 경력 요구사항 없음
        
        if act >= req:
            # 요구 경력 이상
            return min(100.0, (act / req) * 100)
        else:
            # 요구 경력 미달
            return max(0.0, (act / req) * 80)
    except (ValueError, TypeError):
        return 50.0  # 기본값
'''

    # ==================== 데이터 검증 함수 ====================
    
    @staticmethod
    def get_validation_functions():
        """데이터 검증 관련 함수들"""
        return '''
def validate_data(data):
    """데이터 유효성 검증"""
    if data is None:
        return False
    
    if isinstance(data, (list, tuple)):
        return len(data) > 0
    
    if isinstance(data, dict):
        return len(data) > 0 and any(v is not None for v in data.values())
    
    if isinstance(data, pd.DataFrame):
        return not data.empty
    
    return True

def check_missing_values(df):
    """데이터프레임의 결측값 검사"""
    if not isinstance(df, pd.DataFrame):
        return {"error": "Not a DataFrame"}
    
    missing_count = df.isnull().sum()
    missing_percent = (missing_count / len(df)) * 100
    
    return {
        "total_missing": int(missing_count.sum()),
        "by_column": missing_count.to_dict(),
        "percent_by_column": missing_percent.to_dict()
    }

def detect_outliers(data, method='iqr', threshold=1.5):
    """이상치 탐지"""
    if not isinstance(data, (list, np.ndarray, pd.Series)):
        return []
    
    arr = np.array(data) if not isinstance(data, np.ndarray) else data
    
    if method == 'iqr':
        Q1 = np.percentile(arr, 25)
        Q3 = np.percentile(arr, 75)
        IQR = Q3 - Q1
        
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        
        outliers = arr[(arr < lower_bound) | (arr > upper_bound)]
        return outliers.tolist()
    
    elif method == 'zscore':
        mean = np.mean(arr)
        std = np.std(arr)
        
        z_scores = np.abs((arr - mean) / std)
        outliers = arr[z_scores > threshold]
        return outliers.tolist()
    
    return []

def check_duplicates(df, subset=None):
    """중복 데이터 검사"""
    if not isinstance(df, pd.DataFrame):
        return {"error": "Not a DataFrame"}
    
    duplicates = df.duplicated(subset=subset)
    duplicate_count = duplicates.sum()
    
    if duplicate_count > 0:
        duplicate_rows = df[duplicates]
        return {
            "has_duplicates": True,
            "count": int(duplicate_count),
            "percentage": round((duplicate_count / len(df)) * 100, 2),
            "duplicate_indices": duplicate_rows.index.tolist()
        }
    
    return {
        "has_duplicates": False,
        "count": 0,
        "percentage": 0.0
    }
'''

    # ==================== 금융/리스크 분석 함수 ====================
    
    @staticmethod
    def get_financial_functions():
        """금융 및 리스크 분석 관련 함수들"""
        return '''
def calculate_var(returns, confidence_level=0.95):
    """Value at Risk (VaR) 계산"""
    if not returns or len(returns) == 0:
        return 0.0
    
    returns_array = np.array(returns)
    
    # Historical VaR
    var_percentile = (1 - confidence_level) * 100
    var = np.percentile(returns_array, var_percentile)
    
    return round(var, 4)

def calculate_sharpe_ratio(returns, risk_free_rate=0.02):
    """샤프 비율 계산"""
    if not returns or len(returns) < 2:
        return 0.0
    
    returns_array = np.array(returns)
    
    excess_returns = returns_array - risk_free_rate / 252  # 일간 무위험 수익률
    
    if np.std(excess_returns) == 0:
        return 0.0
    
    sharpe = np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
    
    return round(sharpe, 2)

def calculate_portfolio_risk(weights, returns_df):
    """포트폴리오 리스크 계산"""
    if not isinstance(returns_df, pd.DataFrame) or len(weights) != len(returns_df.columns):
        return {"error": "Invalid input"}
    
    # 공분산 행렬
    cov_matrix = returns_df.cov()
    
    # 포트폴리오 분산
    portfolio_variance = np.dot(weights, np.dot(cov_matrix, weights))
    
    # 포트폴리오 표준편차 (리스크)
    portfolio_risk = np.sqrt(portfolio_variance)
    
    return {
        "portfolio_risk": round(portfolio_risk, 4),
        "portfolio_variance": round(portfolio_variance, 6),
        "annualized_risk": round(portfolio_risk * np.sqrt(252), 4)
    }

def analyze_returns(returns):
    """수익률 분석"""
    if not returns or len(returns) == 0:
        return {"error": "No returns data"}
    
    returns_array = np.array(returns)
    
    return {
        "mean_return": round(np.mean(returns_array), 4),
        "std_dev": round(np.std(returns_array), 4),
        "min_return": round(np.min(returns_array), 4),
        "max_return": round(np.max(returns_array), 4),
        "skewness": round(float(pd.Series(returns_array).skew()), 4),
        "kurtosis": round(float(pd.Series(returns_array).kurtosis()), 4)
    }
'''

    # ==================== 텍스트 처리 함수 ====================
    
    @staticmethod
    def get_text_processing_functions():
        """텍스트 처리 관련 함수들"""
        return '''
def extract_skills(text):
    """텍스트에서 스킬 추출"""
    if not text:
        return []
    
    # 일반적인 기술 스킬 패턴
    skill_patterns = [
        r'Python', r'Java', r'JavaScript', r'C\+\+', r'SQL', r'React', r'Node\.js',
        r'Docker', r'Kubernetes', r'AWS', r'Azure', r'GCP', r'Machine Learning',
        r'Deep Learning', r'Data Science', r'DevOps', r'CI/CD', r'Git'
    ]
    
    skills = []
    text_lower = text.lower()
    
    for pattern in skill_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            skills.append(pattern.replace('\\', ''))
    
    return list(set(skills))

def calculate_text_similarity(text1, text2):
    """두 텍스트의 유사도 계산 (Jaccard similarity)"""
    if not text1 or not text2:
        return 0.0
    
    # 단어 토큰화
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    
    # Jaccard similarity
    intersection = words1 & words2
    union = words1 | words2
    
    if not union:
        return 0.0
    
    similarity = len(intersection) / len(union)
    return round(similarity * 100, 2)

def extract_numbers(text):
    """텍스트에서 숫자 추출"""
    if not text:
        return []
    
    # 숫자 패턴 (정수, 소수, 퍼센트 등)
    numbers = re.findall(r'-?\d+\.?\d*%?', text)
    
    # 숫자로 변환
    result = []
    for num in numbers:
        if '%' in num:
            result.append(float(num.replace('%', '')) / 100)
        else:
            try:
                if '.' in num:
                    result.append(float(num))
                else:
                    result.append(int(num))
            except ValueError:
                continue
    
    return result
'''

    # ==================== 통계 분석 함수 ====================
    
    @staticmethod
    def get_statistical_functions():
        """통계 분석 관련 함수들"""
        return '''
def calculate_statistics(data):
    """기본 통계량 계산"""
    if not data or len(data) == 0:
        return {"error": "No data"}
    
    arr = np.array(data)
    
    return {
        "count": len(arr),
        "mean": round(np.mean(arr), 2),
        "median": round(np.median(arr), 2),
        "std": round(np.std(arr), 2),
        "min": round(np.min(arr), 2),
        "max": round(np.max(arr), 2),
        "q1": round(np.percentile(arr, 25), 2),
        "q3": round(np.percentile(arr, 75), 2)
    }

def calculate_correlation(data1, data2):
    """두 데이터 시리즈의 상관관계 계산"""
    if len(data1) != len(data2) or len(data1) < 2:
        return {"error": "Invalid data"}
    
    correlation = np.corrcoef(data1, data2)[0, 1]
    
    return {
        "correlation": round(correlation, 4),
        "strength": "strong" if abs(correlation) > 0.7 else "moderate" if abs(correlation) > 0.3 else "weak"
    }
'''

    @staticmethod
    def get_helper_functions_for_query(query: str) -> str:
        """쿼리에 맞는 helper 함수들을 반환"""
        functions = []
        query_lower = query.lower()
        
        # 매칭/스코어링 관련
        if any(keyword in query_lower for keyword in ['match', 'score', '매칭', '점수', '평가', 'experience', '경력']):
            functions.append(HelperLibrary.get_match_score_functions())
        
        # 검증 관련
        if any(keyword in query_lower for keyword in ['validate', 'check', '검증', '검사', 'missing', '결측', 'outlier', '이상치', 'duplicate', '중복']):
            functions.append(HelperLibrary.get_validation_functions())
        
        # 금융/리스크 관련
        if any(keyword in query_lower for keyword in ['var', 'risk', 'sharpe', 'portfolio', '리스크', '포트폴리오', '수익률', 'return', '금융']):
            functions.append(HelperLibrary.get_financial_functions())
        
        # 텍스트 처리 관련
        if any(keyword in query_lower for keyword in ['text', 'skill', 'extract', '텍스트', '스킬', '추출', 'similarity', '유사도']):
            functions.append(HelperLibrary.get_text_processing_functions())
        
        # 통계 관련
        if any(keyword in query_lower for keyword in ['statistic', 'correlation', '통계', '상관', 'mean', 'median', '평균']):
            functions.append(HelperLibrary.get_statistical_functions())
        
        # 기본적으로 매칭과 검증 함수는 항상 포함
        if not functions:
            functions.append(HelperLibrary.get_match_score_functions())
            functions.append(HelperLibrary.get_validation_functions())
        
        return '\n\n'.join(functions)