"""
Unified FORGE Pipeline
통합된 FORGE AI 파이프라인 - 모든 모듈을 효율적으로 연결

Author: FORGE AI Team
Date: 2025-01-21
Version: 1.0.0
"""

import asyncio
import logging
from typing import Dict, Any, Optional, Tuple
from datetime import datetime
from pathlib import Path
import json
import traceback

# Import unified modules
from .unified_query_analyzer import UnifiedQueryAnalyzer, analyze_query
from .unified_pattern_matcher import UnifiedPatternMatcher, match_patterns
from .unified_business_logic_generator import UnifiedBusinessLogicGenerator, generate_business_logic
from .unified_template_generator import UnifiedTemplateGenerator, generate_agent_code

logger = logging.getLogger(__name__)


class UnifiedForgePipeline:
    """
    통합된 FORGE AI 파이프라인
    모든 모듈을 순차적으로 연결하여 에이전트 생성
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the unified pipeline
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        
        # Initialize modules
        self.query_analyzer = UnifiedQueryAnalyzer()
        self.pattern_matcher = UnifiedPatternMatcher()
        self.logic_generator = UnifiedBusinessLogicGenerator()
        self.template_generator = UnifiedTemplateGenerator()
        
        # Statistics
        self.generation_stats = {
            'total': 0,
            'success': 0,
            'failed': 0,
            'emergency': 0
        }
        
        logger.info("UnifiedForgePipeline initialized successfully")
    
    async def generate_agent(self, query: str, user_email: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate a complete agent from user query
        
        Args:
            query: User query describing the desired agent
            user_email: Optional user email for tracking
            
        Returns:
            Dictionary containing generated agent code and metadata
        """
        start_time = datetime.now()
        logger.info(f"Starting agent generation for: {query[:100]}...")
        
        result = {
            'success': False,
            'code': '',
            'metadata': {},
            'errors': [],
            'generation_time': 0
        }
        
        try:
            # Step 1: Analyze query
            logger.info("Step 1: Analyzing query...")
            analysis_result = await self.query_analyzer.analyze(query)
            result['metadata']['analysis'] = analysis_result.to_dict()
            
            # Step 2: Match patterns
            logger.info("Step 2: Matching patterns...")
            pattern_matches = self.pattern_matcher.match(query)
            best_pattern = pattern_matches[0] if pattern_matches else None
            
            if best_pattern:
                result['metadata']['pattern'] = best_pattern.to_dict()
                template_id = best_pattern.template_id
                logger.info(f"Matched pattern: {best_pattern.pattern_id} (confidence: {best_pattern.confidence:.2f})")
            else:
                template_id = None
                logger.info("No pattern matched, will use generic approach")
            
            # Step 3: Generate business logic
            logger.info("Step 3: Generating business logic...")
            business_logic_result = await self.logic_generator.generate(
                query=query,
                analysis_result=analysis_result.to_dict(),
                pattern_match=best_pattern.to_dict() if best_pattern else None,
                template_id=template_id
            )
            
            if not business_logic_result.is_valid:
                logger.warning(f"Business logic validation failed: {business_logic_result.validation_errors}")
                # Try emergency fallback
                business_logic_result = self.logic_generator.generate_emergency_logic(query)
                self.generation_stats['emergency'] += 1
            
            result['metadata']['business_logic'] = {
                'method': business_logic_result.generation_method,
                'confidence': business_logic_result.confidence,
                'is_valid': business_logic_result.is_valid
            }
            
            # Step 4: Generate agent code
            logger.info("Step 4: Generating agent code...")
            agent_code = self.template_generator.generate(
                business_logic=business_logic_result.to_dict(),
                template_id=template_id
            )
            
            # Step 5: Validate generated code
            logger.info("Step 5: Validating generated code...")
            validation_result = self._validate_agent_code(agent_code)
            
            if validation_result['is_valid']:
                result['success'] = True
                result['code'] = agent_code
                self.generation_stats['success'] += 1
                logger.info("Agent generation successful!")
            else:
                result['errors'] = validation_result['errors']
                # Try to fix common issues
                fixed_code = self._attempt_code_fixes(agent_code, validation_result['errors'])
                if fixed_code:
                    result['code'] = fixed_code
                    result['success'] = True
                    result['metadata']['fixed'] = True
                    self.generation_stats['success'] += 1
                    logger.info("Agent generation successful after fixes!")
                else:
                    self.generation_stats['failed'] += 1
                    logger.error(f"Agent generation failed: {validation_result['errors']}")
            
            # Add final metadata
            result['metadata']['agent_info'] = {
                'name': business_logic_result.agent_name,
                'class_name': business_logic_result.agent_class_name,
                'description': business_logic_result.agent_description,
                'type': business_logic_result.agent_type,
                'template_id': template_id
            }
            
            # Add test samples
            result['metadata']['test_samples'] = analysis_result.test_samples
            
        except Exception as e:
            logger.error(f"Pipeline error: {e}")
            logger.error(traceback.format_exc())
            result['errors'].append(str(e))
            result['metadata']['exception'] = traceback.format_exc()
            self.generation_stats['failed'] += 1
        
        finally:
            # Calculate generation time
            generation_time = (datetime.now() - start_time).total_seconds()
            result['generation_time'] = generation_time
            result['metadata']['timestamp'] = datetime.now().isoformat()
            result['metadata']['user_email'] = user_email
            
            # Update total statistics
            self.generation_stats['total'] += 1
            
            logger.info(f"Generation completed in {generation_time:.2f} seconds")
            logger.info(f"Stats: {self.generation_stats}")
        
        return result
    
    def _validate_agent_code(self, code: str) -> Dict[str, Any]:
        """
        Validate generated agent code
        
        Args:
            code: Generated Python code
            
        Returns:
            Validation result dictionary
        """
        errors = []
        warnings = []
        
        # Check for class definition
        if 'class ' not in code:
            errors.append("Missing class definition")
        
        # Check for required methods
        required_methods = ['__init__', 'process', '_process_core_logic']
        for method in required_methods:
            if f'def {method}' not in code and f'async def {method}' not in code:
                errors.append(f"Missing required method: {method}")
        
        # Check for unresolved template variables (skip f-strings)
        import re
        # Find all brace patterns but exclude those in f-strings
        lines = code.split('\n')
        invalid_vars = []
        for line in lines:
            # Skip lines that look like f-strings
            if 'f"' in line or "f'" in line or 'logger.' in line or 'print(' in line:
                continue
            # Look for template variable patterns
            matches = re.findall(r'\{([^}]+)\}', line)
            for match in matches:
                # Skip common Python patterns
                if any(x in match for x in ['self', ':', '=', '+', '-', '*', '/', 
                                           'i', 'j', 'k', 'e', 'error', 'result', 
                                           'data', 'item', 'status', 'message', 
                                           'value', 'key', 'sample', 'test']):
                    continue
                # Skip dictionary literals
                if '"' in match or "'" in match:
                    continue
                invalid_vars.append(match)
        
        if invalid_vars:
            errors.append(f"Unresolved template variables: {invalid_vars}")
        
        # Check for syntax errors
        try:
            compile(code, '<generated>', 'exec')
        except SyntaxError as e:
            errors.append(f"Syntax error: {e}")
        
        # Check for imports
        if 'import ' not in code:
            warnings.append("No import statements found")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }
    
    def _attempt_code_fixes(self, code: str, errors: list) -> Optional[str]:
        """
        Attempt to fix common code issues
        
        Args:
            code: Generated code with issues
            errors: List of validation errors
            
        Returns:
            Fixed code or None if unable to fix
        """
        fixed_code = code
        
        # Fix unresolved template variables
        if any('Unresolved template variables' in e for e in errors):
            import re
            # Replace remaining template variables with defaults
            fixed_code = re.sub(r'\{agent_class_name\}', 'GeneratedAgent', fixed_code)
            fixed_code = re.sub(r'\{agent_name\}', 'Generated Agent', fixed_code)
            fixed_code = re.sub(r'\{agent_description\}', 'Auto-generated agent', fixed_code)
            fixed_code = re.sub(r'\{agent_type\}', 'CUSTOM', fixed_code)
            fixed_code = re.sub(r'\{custom_config\}', '{}', fixed_code)
            fixed_code = re.sub(r'\{custom_init\}', 'pass', fixed_code)
            fixed_code = re.sub(r'\{imports\}', '', fixed_code)
            fixed_code = re.sub(r'\{test_samples\}', '[]', fixed_code)
            fixed_code = re.sub(r'\{generation_date\}', datetime.now().strftime('%Y-%m-%d'), fixed_code)
        
        # Fix syntax errors
        if any('Syntax error' in e for e in errors):
            # Try to fix common syntax issues
            lines = fixed_code.split('\n')
            fixed_lines = []
            for line in lines:
                # Fix empty blocks
                if line.strip().endswith(':') and not any(lines[i+1].strip() for i in range(lines.index(line)+1, min(lines.index(line)+2, len(lines)))):
                    fixed_lines.append(line)
                    fixed_lines.append('        pass')
                else:
                    fixed_lines.append(line)
            fixed_code = '\n'.join(fixed_lines)
        
        # Re-validate
        validation = self._validate_agent_code(fixed_code)
        if validation['is_valid']:
            logger.info("Successfully fixed code issues")
            return fixed_code
        else:
            logger.warning(f"Unable to fix all issues: {validation['errors']}")
            return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get generation statistics"""
        total = self.generation_stats['total']
        if total == 0:
            return self.generation_stats
        
        return {
            **self.generation_stats,
            'success_rate': self.generation_stats['success'] / total,
            'failure_rate': self.generation_stats['failed'] / total,
            'emergency_rate': self.generation_stats['emergency'] / total
        }
    
    async def batch_generate(self, queries: list, user_email: Optional[str] = None) -> list:
        """
        Generate multiple agents in batch
        
        Args:
            queries: List of user queries
            user_email: Optional user email
            
        Returns:
            List of generation results
        """
        logger.info(f"Starting batch generation for {len(queries)} queries")
        
        tasks = [
            self.generate_agent(query, user_email)
            for query in queries
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle any exceptions
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Batch generation error for query {i}: {result}")
                results[i] = {
                    'success': False,
                    'code': '',
                    'metadata': {'query': queries[i]},
                    'errors': [str(result)]
                }
        
        return results


# Singleton instance
forge_pipeline = UnifiedForgePipeline()


async def generate_agent(query: str, user_email: Optional[str] = None) -> Dict[str, Any]:
    """
    Convenience function for generating an agent
    
    Args:
        query: User query
        user_email: Optional user email
        
    Returns:
        Generation result dictionary
    """
    return await forge_pipeline.generate_agent(query, user_email)