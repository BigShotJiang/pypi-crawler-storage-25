"""
Enhanced Complexity Calculator
==============================
Paper1 기반 복잡도 계산 수식 구현

C(q) = α·L(q) + β·D(q) + γ·N(q) + δ·U(q)

Where:
- L(q) = Linguistic complexity (vocabulary, syntax)
- D(q) = Domain complexity (technical depth)
- N(q) = Novelty score (similarity to known problems)
- U(q) = Uncertainty measure (ambiguity level)
- α, β, γ, δ = learned weights (Σ = 1)
"""

import re
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from loguru import logger


@dataclass
class ComplexityBreakdown:
    """복잡도 세부 분석 결과"""
    linguistic: float  # L(q)
    domain: float      # D(q)
    novelty: float     # N(q)
    uncertainty: float  # U(q)
    total: float       # 최종 복잡도
    factors: Dict[str, Any]  # 상세 요소


class EnhancedComplexityCalculator:
    """
    Paper1 기반 향상된 복잡도 계산기

    기존 단순 조건문 대신 가중치 기반 수식 사용
    """

    def __init__(self):
        # 학습된 가중치 (논문 기반 초기값)
        self.weights = {
            'linguistic': 0.25,   # α
            'domain': 0.30,       # β
            'novelty': 0.25,      # γ
            'uncertainty': 0.20   # δ
        }

        # 도메인별 복잡도 점수
        self.domain_complexity_scores = {
            # 고복잡도 도메인 (0.8-1.0)
            'high': [
                'machine learning', 'neural network', 'deep learning',
                'optimization', 'algorithm design', 'distributed system',
                'natural language processing', 'computer vision',
                'security audit', 'compliance assessment',
                # 한국어
                '기계학습', '딥러닝', '인공지능', '최적화', '알고리즘',
                '분산처리', '자연어처리', '컴퓨터비전', '보안감사'
            ],
            # 중복잡도 도메인 (0.5-0.7)
            'medium': [
                'data analysis', 'statistical analysis', 'prediction',
                'classification', 'time series', 'api integration',
                'sentiment analysis', 'trend analysis', 'portfolio',
                'stock analysis', 'moving average', 'trading',
                # 한국어
                '데이터분석', '통계분석', '예측', '분류', '시계열',
                'API연동', '감정분석', '트렌드', '포트폴리오',
                '주식분석', '이동평균', '트레이딩'
            ],
            # 저복잡도 도메인 (0.2-0.4)
            'low': [
                'calculator', 'arithmetic', 'basic math',
                'file read', 'data load', 'simple query',
                'display', 'list', 'format', 'convert',
                # 한국어
                '계산기', '산술', '기본계산', '파일읽기',
                '데이터불러오기', '표시', '목록', '변환'
            ]
        }

        # 모호한 표현 (불확실성 증가)
        self.ambiguous_terms = [
            # English
            'something', 'somehow', 'maybe', 'probably', 'kind of',
            'sort of', 'like', 'similar', 'various', 'etc',
            'whatever', 'anything', 'stuff', 'things',
            # Korean
            '어떤', '대충', '뭔가', '아마', '그런',
            '비슷한', '여러', '등등', '기타', '무엇이든'
        ]

        # 알려진 패턴 (신규성 감소)
        self.known_patterns = [
            'calculator', 'data analysis', 'csv processing',
            'api integration', 'email notification', 'chart generation',
            'sentiment analysis', 'stock analysis', 'weather forecast',
            # Korean equivalents
            '계산기', '데이터분석', 'CSV처리', 'API연동',
            '이메일알림', '차트생성', '감정분석', '주식분석'
        ]

        logger.info("Enhanced Complexity Calculator initialized with weighted formula")

    def calculate(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ComplexityBreakdown:
        """
        복잡도 계산: C(q) = α·L(q) + β·D(q) + γ·N(q) + δ·U(q)

        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트 (capabilities, entities 등)

        Returns:
            ComplexityBreakdown: 복잡도 분석 결과
        """
        context = context or {}

        # 각 요소 계산
        L = self._linguistic_complexity(query)
        D = self._domain_complexity(query, context)
        N = self._novelty_score(query)
        U = self._uncertainty_measure(query)

        # 가중치 적용
        total = (
            self.weights['linguistic'] * L +
            self.weights['domain'] * D +
            self.weights['novelty'] * N +
            self.weights['uncertainty'] * U
        )

        # 0-1 범위로 정규화
        total = max(0.0, min(1.0, total))

        breakdown = ComplexityBreakdown(
            linguistic=round(L, 3),
            domain=round(D, 3),
            novelty=round(N, 3),
            uncertainty=round(U, 3),
            total=round(total, 3),
            factors={
                'word_count': len(query.split()),
                'unique_ratio': self._get_unique_ratio(query),
                'domain_level': self._get_domain_level(query),
                'known_pattern_matches': self._count_known_patterns(query),
                'ambiguous_terms_count': self._count_ambiguous_terms(query)
            }
        )

        logger.debug(
            f"Complexity calculated: L={L:.2f}, D={D:.2f}, N={N:.2f}, U={U:.2f} → Total={total:.2f}"
        )

        return breakdown

    def _linguistic_complexity(self, query: str) -> float:
        """
        L(q): 언어적 복잡도 (어휘, 구문)

        - 단어 수
        - 고유 단어 비율
        - 평균 단어 길이
        - 문장 수
        """
        words = query.split()
        if not words:
            return 0.0

        word_count = len(words)
        unique_words = set(w.lower() for w in words)
        unique_ratio = len(unique_words) / word_count

        # 평균 단어 길이 (한국어 포함)
        avg_word_length = sum(len(w) for w in words) / word_count

        # 문장 수 추정
        sentence_markers = query.count('.') + query.count('?') + query.count('!') + query.count('。')
        sentence_count = max(1, sentence_markers)

        # 각 요소 정규화 및 조합
        complexity = (
            min(1.0, word_count / 50) * 0.25 +      # 50단어까지 선형
            unique_ratio * 0.30 +                     # 고유 단어 비율
            min(1.0, avg_word_length / 12) * 0.25 +  # 평균 길이 12자까지
            min(1.0, sentence_count / 5) * 0.20      # 5문장까지
        )

        return complexity

    def _domain_complexity(
        self,
        query: str,
        context: Dict[str, Any]
    ) -> float:
        """
        D(q): 도메인 기술 복잡도

        - 전문 용어 사용
        - 도메인 깊이
        - 기능 수
        """
        query_lower = query.lower()

        # 도메인 수준 확인
        domain_level = self._get_domain_level(query)

        if domain_level == 'high':
            base_score = 0.85
        elif domain_level == 'medium':
            base_score = 0.55
        else:
            base_score = 0.25

        # Capability 수에 따른 조정
        capabilities = context.get('capabilities', [])
        cap_count = len(capabilities)

        if cap_count > 5:
            base_score += 0.15
        elif cap_count > 3:
            base_score += 0.10

        # 다중 도메인 감지
        domains_found = 0
        domain_keywords = {
            'finance': ['stock', 'portfolio', 'trading', '주식', '포트폴리오'],
            'ml': ['predict', 'classify', 'model', '예측', '분류'],
            'web': ['api', 'webhook', 'http', 'url'],
            'data': ['csv', 'database', 'json', '데이터'],
            'social': ['twitter', 'instagram', 'social', '소셜']
        }

        for domain, keywords in domain_keywords.items():
            if any(kw in query_lower for kw in keywords):
                domains_found += 1

        if domains_found > 2:
            base_score += 0.10

        return min(1.0, base_score)

    def _novelty_score(self, query: str) -> float:
        """
        N(q): 신규성 점수 (낮을수록 익숙한 패턴)

        알려진 패턴과의 유사도를 측정하여 반전
        """
        query_lower = query.lower()

        # 알려진 패턴 매칭 수
        matches = self._count_known_patterns(query)

        # 매칭이 많을수록 신규성 낮음
        if matches >= 3:
            novelty = 0.2  # 매우 익숙한 패턴
        elif matches >= 2:
            novelty = 0.4
        elif matches >= 1:
            novelty = 0.6
        else:
            novelty = 0.9  # 새로운 유형

        return novelty

    def _uncertainty_measure(self, query: str) -> float:
        """
        U(q): 불확실성/모호성 측정

        - 모호한 표현 수
        - 질문 형태 여부
        - 구체성 부족
        """
        query_lower = query.lower()

        # 모호한 표현 카운트
        ambiguity_count = self._count_ambiguous_terms(query)

        # 질문 형태
        is_question = '?' in query or '?' in query or '어떻게' in query or 'how' in query_lower

        # 구체성 확인 (숫자, 구체적 값 포함 여부)
        has_specifics = bool(re.search(r'\d+', query)) or any(
            specific in query_lower for specific in
            ['specific', 'exactly', 'precisely', '정확히', '구체적으로']
        )

        # 불확실성 점수 계산
        uncertainty = 0.0

        # 모호한 표현당 +0.15
        uncertainty += min(0.6, ambiguity_count * 0.15)

        # 질문 형태면 +0.2
        if is_question:
            uncertainty += 0.2

        # 구체적이면 -0.2
        if has_specifics:
            uncertainty -= 0.2

        return max(0.0, min(1.0, uncertainty))

    def _get_unique_ratio(self, query: str) -> float:
        """고유 단어 비율 계산"""
        words = query.split()
        if not words:
            return 0.0
        unique_words = set(w.lower() for w in words)
        return len(unique_words) / len(words)

    def _get_domain_level(self, query: str) -> str:
        """도메인 복잡도 레벨 결정"""
        query_lower = query.lower()

        # 고복잡도 체크
        for term in self.domain_complexity_scores['high']:
            if term.lower() in query_lower:
                return 'high'

        # 중복잡도 체크
        for term in self.domain_complexity_scores['medium']:
            if term.lower() in query_lower:
                return 'medium'

        # 기본 저복잡도
        return 'low'

    def _count_known_patterns(self, query: str) -> int:
        """알려진 패턴 매칭 수"""
        query_lower = query.lower()
        return sum(1 for pattern in self.known_patterns if pattern.lower() in query_lower)

    def _count_ambiguous_terms(self, query: str) -> int:
        """모호한 표현 수"""
        query_lower = query.lower()
        return sum(1 for term in self.ambiguous_terms if term.lower() in query_lower)

    def get_complexity_level(self, score: float) -> str:
        """
        복잡도 점수를 레벨로 변환

        Returns:
            'low', 'medium', or 'high'
        """
        if score < 0.35:
            return 'low'
        elif score < 0.65:
            return 'medium'
        else:
            return 'high'


# 싱글톤 인스턴스
_calculator_instance = None


def get_complexity_calculator() -> EnhancedComplexityCalculator:
    """싱글톤 계산기 인스턴스 반환"""
    global _calculator_instance
    if _calculator_instance is None:
        _calculator_instance = EnhancedComplexityCalculator()
    return _calculator_instance
