"""
Performance Monitor for V2 System
==================================
V2 시스템의 성능을 실시간으로 모니터링하는 모듈
"""

import time
import asyncio
import psutil
import json
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from loguru import logger
from functools import wraps
import statistics


@dataclass
class PerformanceMetrics:
    """성능 메트릭"""
    operation: str
    start_time: float
    end_time: float
    duration_ms: float
    memory_before_mb: float
    memory_after_mb: float
    memory_delta_mb: float
    cpu_percent: float
    success: bool
    error: Optional[str] = None
    metadata: Optional[Dict] = None
    
    def to_dict(self) -> Dict:
        """딕셔너리로 변환"""
        return {
            **asdict(self),
            'timestamp': datetime.fromtimestamp(self.start_time).isoformat()
        }


class PerformanceMonitor:
    """성능 모니터링 시스템"""
    
    def __init__(self, log_dir: Optional[str] = None):
        """
        Args:
            log_dir: 성능 로그를 저장할 디렉토리
        """
        self.metrics: List[PerformanceMetrics] = []
        self.log_dir = Path(log_dir) if log_dir else Path("performance_logs")
        self.log_dir.mkdir(exist_ok=True)
        
        # 임계값 설정
        self.thresholds = {
            'duration_ms': 5000,  # 5초
            'memory_delta_mb': 100,  # 100MB
            'cpu_percent': 80,  # 80%
        }
        
        # 실시간 모니터링
        self.monitoring_active = False
        self.monitoring_task = None
        
        # 통계
        self.stats = {
            'total_operations': 0,
            'successful_operations': 0,
            'failed_operations': 0,
            'total_duration_ms': 0,
            'operations_by_type': {}
        }
        
        logger.info("Performance monitor initialized")
    
    def profile(self, operation_name: str = None):
        """
        데코레이터: 함수 성능 프로파일링
        
        Usage:
            @monitor.profile("generate_agent")
            def generate_agent(query):
                ...
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                name = operation_name or func.__name__
                metrics = self._start_monitoring(name)
                
                try:
                    result = func(*args, **kwargs)
                    self._end_monitoring(metrics, success=True)
                    return result
                except Exception as e:
                    self._end_monitoring(metrics, success=False, error=str(e))
                    raise
            
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                name = operation_name or func.__name__
                metrics = self._start_monitoring(name)
                
                try:
                    result = await func(*args, **kwargs)
                    self._end_monitoring(metrics, success=True)
                    return result
                except Exception as e:
                    self._end_monitoring(metrics, success=False, error=str(e))
                    raise
            
            return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
        
        return decorator
    
    def _start_monitoring(self, operation: str) -> Dict:
        """모니터링 시작"""
        process = psutil.Process()
        
        return {
            'operation': operation,
            'start_time': time.time(),
            'memory_before': process.memory_info().rss / 1024 / 1024,  # MB
            'cpu_before': process.cpu_percent()
        }
    
    def _end_monitoring(self, metrics: Dict, success: bool, error: Optional[str] = None):
        """모니터링 종료"""
        process = psutil.Process()
        end_time = time.time()
        
        # 메트릭 생성
        perf_metrics = PerformanceMetrics(
            operation=metrics['operation'],
            start_time=metrics['start_time'],
            end_time=end_time,
            duration_ms=(end_time - metrics['start_time']) * 1000,
            memory_before_mb=metrics['memory_before'],
            memory_after_mb=process.memory_info().rss / 1024 / 1024,
            memory_delta_mb=(process.memory_info().rss / 1024 / 1024) - metrics['memory_before'],
            cpu_percent=process.cpu_percent(),
            success=success,
            error=error
        )
        
        # 저장
        self.metrics.append(perf_metrics)
        
        # 통계 업데이트
        self._update_stats(perf_metrics)
        
        # 임계값 체크
        self._check_thresholds(perf_metrics)
        
        # 로그
        self._log_metrics(perf_metrics)
    
    def _update_stats(self, metrics: PerformanceMetrics):
        """통계 업데이트"""
        self.stats['total_operations'] += 1
        
        if metrics.success:
            self.stats['successful_operations'] += 1
        else:
            self.stats['failed_operations'] += 1
        
        self.stats['total_duration_ms'] += metrics.duration_ms
        
        # 작업 유형별 통계
        op_type = metrics.operation
        if op_type not in self.stats['operations_by_type']:
            self.stats['operations_by_type'][op_type] = {
                'count': 0,
                'total_duration_ms': 0,
                'failures': 0
            }
        
        self.stats['operations_by_type'][op_type]['count'] += 1
        self.stats['operations_by_type'][op_type]['total_duration_ms'] += metrics.duration_ms
        if not metrics.success:
            self.stats['operations_by_type'][op_type]['failures'] += 1
    
    def _check_thresholds(self, metrics: PerformanceMetrics):
        """임계값 체크 및 경고"""
        warnings = []
        
        if metrics.duration_ms > self.thresholds['duration_ms']:
            warnings.append(f"Duration exceeded: {metrics.duration_ms:.2f}ms > {self.thresholds['duration_ms']}ms")
        
        if metrics.memory_delta_mb > self.thresholds['memory_delta_mb']:
            warnings.append(f"Memory usage high: {metrics.memory_delta_mb:.2f}MB > {self.thresholds['memory_delta_mb']}MB")
        
        if metrics.cpu_percent > self.thresholds['cpu_percent']:
            warnings.append(f"CPU usage high: {metrics.cpu_percent:.1f}% > {self.thresholds['cpu_percent']}%")
        
        if warnings:
            logger.warning(f"Performance warnings for '{metrics.operation}': {'; '.join(warnings)}")
    
    def _log_metrics(self, metrics: PerformanceMetrics):
        """메트릭 로깅"""
        log_level = logger.info if metrics.success else logger.error
        
        log_level(
            f"[{metrics.operation}] "
            f"Duration: {metrics.duration_ms:.2f}ms | "
            f"Memory: {metrics.memory_delta_mb:+.2f}MB | "
            f"CPU: {metrics.cpu_percent:.1f}% | "
            f"{'✅' if metrics.success else '❌'}"
        )
    
    async def start_realtime_monitoring(self, interval: float = 1.0):
        """실시간 모니터링 시작"""
        if self.monitoring_active:
            logger.warning("Monitoring already active")
            return
        
        self.monitoring_active = True
        self.monitoring_task = asyncio.create_task(self._monitor_loop(interval))
        logger.info(f"Started realtime monitoring with {interval}s interval")
    
    async def stop_realtime_monitoring(self):
        """실시간 모니터링 중지"""
        if not self.monitoring_active:
            return
        
        self.monitoring_active = False
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
        
        logger.info("Stopped realtime monitoring")
    
    async def _monitor_loop(self, interval: float):
        """모니터링 루프"""
        process = psutil.Process()
        
        while self.monitoring_active:
            try:
                # 시스템 메트릭 수집
                cpu_percent = process.cpu_percent()
                memory_mb = process.memory_info().rss / 1024 / 1024
                
                # 임계값 체크
                if cpu_percent > self.thresholds['cpu_percent']:
                    logger.warning(f"High CPU usage: {cpu_percent:.1f}%")
                
                if memory_mb > 500:  # 500MB 이상
                    logger.warning(f"High memory usage: {memory_mb:.2f}MB")
                
                await asyncio.sleep(interval)
                
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(interval)
    
    def get_summary(self) -> Dict:
        """성능 요약 반환"""
        if not self.metrics:
            return {"message": "No metrics collected yet"}
        
        durations = [m.duration_ms for m in self.metrics]
        memory_deltas = [m.memory_delta_mb for m in self.metrics]
        
        return {
            'total_operations': len(self.metrics),
            'successful': sum(1 for m in self.metrics if m.success),
            'failed': sum(1 for m in self.metrics if not m.success),
            'duration': {
                'avg_ms': statistics.mean(durations),
                'min_ms': min(durations),
                'max_ms': max(durations),
                'median_ms': statistics.median(durations),
                'total_ms': sum(durations)
            },
            'memory': {
                'avg_delta_mb': statistics.mean(memory_deltas),
                'max_delta_mb': max(memory_deltas),
                'total_delta_mb': sum(memory_deltas)
            },
            'operations_by_type': self.stats['operations_by_type']
        }
    
    def get_bottlenecks(self, top_n: int = 5) -> List[Dict]:
        """성능 병목 지점 식별"""
        if not self.metrics:
            return []
        
        # 가장 느린 작업들
        slowest = sorted(self.metrics, key=lambda m: m.duration_ms, reverse=True)[:top_n]
        
        return [
            {
                'operation': m.operation,
                'duration_ms': m.duration_ms,
                'memory_delta_mb': m.memory_delta_mb,
                'timestamp': datetime.fromtimestamp(m.start_time).isoformat()
            }
            for m in slowest
        ]
    
    def save_report(self, filename: Optional[str] = None) -> str:
        """성능 보고서 저장"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"performance_report_{timestamp}.json"
        
        filepath = self.log_dir / filename
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'summary': self.get_summary(),
            'bottlenecks': self.get_bottlenecks(),
            'thresholds': self.thresholds,
            'metrics': [m.to_dict() for m in self.metrics[-100:]]  # 최근 100개만
        }
        
        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"Performance report saved to: {filepath}")
        return str(filepath)
    
    def reset(self):
        """메트릭 초기화"""
        self.metrics.clear()
        self.stats = {
            'total_operations': 0,
            'successful_operations': 0,
            'failed_operations': 0,
            'total_duration_ms': 0,
            'operations_by_type': {}
        }
        logger.info("Performance metrics reset")


# 싱글톤 인스턴스
_monitor_instance = None

def get_monitor() -> PerformanceMonitor:
    """싱글톤 모니터 인스턴스 반환"""
    global _monitor_instance
    if _monitor_instance is None:
        _monitor_instance = PerformanceMonitor()
    return _monitor_instance


# 사용 예제
if __name__ == "__main__":
    import asyncio
    
    monitor = get_monitor()
    
    # 동기 함수 프로파일링
    @monitor.profile("test_sync_operation")
    def slow_operation():
        time.sleep(0.5)
        return "done"
    
    # 비동기 함수 프로파일링
    @monitor.profile("test_async_operation")
    async def async_operation():
        await asyncio.sleep(0.3)
        return "async done"
    
    # 테스트 실행
    async def test():
        # 실시간 모니터링 시작
        await monitor.start_realtime_monitoring(interval=2.0)
        
        # 작업 실행
        slow_operation()
        await async_operation()
        
        # 일부러 실패하는 작업
        try:
            @monitor.profile("failing_operation")
            def will_fail():
                raise ValueError("Test error")
            will_fail()
        except:
            pass
        
        # 모니터링 중지
        await monitor.stop_realtime_monitoring()
        
        # 결과 출력
        print("\n📊 Performance Summary:")
        print(json.dumps(monitor.get_summary(), indent=2))
        
        print("\n🔥 Bottlenecks:")
        print(json.dumps(monitor.get_bottlenecks(), indent=2))
        
        # 보고서 저장
        report_path = monitor.save_report()
        print(f"\n📄 Report saved to: {report_path}")
    
    asyncio.run(test())