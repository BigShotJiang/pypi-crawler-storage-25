"""
Logic Synthesizer
==================
Paper1 기반 비즈니스 로직 합성기

비즈니스 로직을 3단계로 분리하여 생성:
1. Core Algorithm Generation - 핵심 알고리즘
2. Error Handling Addition - 에러 처리
3. Logic Optimization - 최적화

이 분리된 접근법은 더 구조화되고 유지보수 가능한 코드를 생성합니다.
"""

from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from loguru import logger
import re


class DomainType(Enum):
    """도메인 유형"""
    CALCULATION = "calculation"
    ANALYSIS = "analysis"
    PREDICTION = "prediction"
    DATA_PROCESSING = "data_processing"
    INTEGRATION = "integration"
    VISUALIZATION = "visualization"
    FINANCE = "finance"
    SOCIAL = "social"
    PRIVACY = "privacy"
    GENERAL = "general"


@dataclass
class RequirementSpec:
    """기능 요구사항 명세"""
    name: str
    domain: DomainType
    description: str
    inputs: Dict[str, str] = field(default_factory=dict)
    outputs: List[str] = field(default_factory=list)
    complexity: float = 0.5
    resources: Dict[str, Any] = field(default_factory=dict)
    constraints: List[str] = field(default_factory=list)


@dataclass
class BusinessLogic:
    """생성된 비즈니스 로직"""
    core_algorithm: str
    error_handling: str
    validations: List[str]
    optimizations: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_complete_code(self) -> str:
        """완성된 코드 반환"""
        validation_code = "\n        ".join(self.validations) if self.validations else ""

        code = f"""
        # Input Validations
        {validation_code}

        try:
            # Core Algorithm
{self.core_algorithm}
{self.error_handling}
"""
        return code.strip()


class LogicSynthesizer:
    """
    Paper1 기반 비즈니스 로직 합성기

    비즈니스 로직을 3단계로 분리하여 생성:
    1. Core Algorithm - 도메인별 핵심 알고리즘
    2. Error Handling - 도메인별 에러 처리
    3. Optimization - 리소스 제약에 맞는 최적화
    """

    def __init__(self):
        # 도메인별 알고리즘 템플릿
        self.algorithm_templates = self._load_algorithm_templates()

        # 도메인별 에러 패턴
        self.error_patterns = self._load_error_patterns()

        # 최적화 규칙
        self.optimization_rules = self._load_optimization_rules()

        logger.info("LogicSynthesizer initialized")

    def synthesize(
        self,
        requirements: RequirementSpec,
        template_code: Optional[str] = None
    ) -> BusinessLogic:
        """
        비즈니스 로직 합성

        Args:
        requirements: 기능 요구사항 명세
        template_code: 선택적 템플릿 코드

        Returns:
        BusinessLogic: 생성된 비즈니스 로직
        """
        logger.info(f"Synthesizing logic for: {requirements.name} (domain: {requirements.domain.value})")

        # Step 1: Generate core algorithm
        algorithm = self._generate_algorithm(requirements, template_code)

        # Step 2: Add error handling
        error_handling = self._generate_error_handling(requirements.domain, algorithm)

        # Step 3: Generate validations
        validations = self._generate_validations(requirements)

        # Step 4: Apply optimizations
        optimized_algorithm, optimizations = self._optimize_logic(
        algorithm,
        requirements.resources,
        requirements.complexity
        )

        return BusinessLogic(
        core_algorithm=optimized_algorithm,
        error_handling=error_handling,
        validations=validations,
        optimizations=optimizations,
        metadata={
            'domain': requirements.domain.value,
            'complexity': requirements.complexity,
            'input_count': len(requirements.inputs),
            'output_count': len(requirements.outputs)
        }
        )

    def _generate_algorithm(
        self,
        requirements: RequirementSpec,
        template_code: Optional[str]
    ) -> str:
        """핵심 알고리즘 생성"""

        domain = requirements.domain

        # 템플릿 코드가 있으면 활용
        if template_code:
            return self._adapt_template(template_code, requirements)

        # 도메인별 알고리즘 생성
        if domain == DomainType.CALCULATION:
            return self._generate_calculation_algorithm(requirements)
        elif domain == DomainType.ANALYSIS:
            return self._generate_analysis_algorithm(requirements)
        elif domain == DomainType.PREDICTION:
            return self._generate_prediction_algorithm(requirements)
        elif domain == DomainType.DATA_PROCESSING:
            return self._generate_data_processing_algorithm(requirements)
        elif domain == DomainType.FINANCE:
            return self._generate_finance_algorithm(requirements)
        elif domain == DomainType.SOCIAL:
            return self._generate_social_algorithm(requirements)
        elif domain == DomainType.PRIVACY:
            return self._generate_privacy_algorithm(requirements)
        elif domain == DomainType.INTEGRATION:
            return self._generate_integration_algorithm(requirements)
        elif domain == DomainType.VISUALIZATION:
            return self._generate_visualization_algorithm(requirements)
        else:
            return self._generate_general_algorithm(requirements)

    def _generate_calculation_algorithm(self, req: RequirementSpec) -> str:
        """계산 도메인 알고리즘"""
        return '''
        # Calculation Logic
        result = None

        if operation == "add":
            result = sum(operands)
        elif operation == "subtract":
            result = operands[0] - sum(operands[1:])
        elif operation == "multiply":
            result = 1
            for op in operands:
                result *= op
        elif operation == "divide":
            if len(operands) >= 2 and operands[1] != 0:
                result = operands[0] / operands[1]
            else:
                raise ValueError("Division by zero or insufficient operands")
        else:
            raise ValueError(f"Unknown operation: {operation}")

        return {
            "success": True,
            "result": result,
            "operation": operation,
            "operands": operands
        }'''

    def _generate_analysis_algorithm(self, req: RequirementSpec) -> str:
        """분석 도메인 알고리즘"""
        return '''
        # Analysis Logic
        import statistics

        # Process data
        if isinstance(data, pd.DataFrame):
            numeric_cols = data.select_dtypes(include=[np.number]).columns

            analysis_results = {}
            for col in numeric_cols:
                col_data = data[col].dropna()
                analysis_results[col] = {
                    "mean": float(col_data.mean()),
                    "median": float(col_data.median()),
                    "std": float(col_data.std()),
                    "min": float(col_data.min()),
                    "max": float(col_data.max()),
                    "count": int(len(col_data))
                }

            insights = self._generate_insights(analysis_results)

            return {
                "success": True,
                "statistics": analysis_results,
                "insights": insights,
                "columns_analyzed": list(numeric_cols)
            }
        else:
            raise ValueError("Data must be a pandas DataFrame")'''

    def _generate_prediction_algorithm(self, req: RequirementSpec) -> str:
        """예측 도메인 알고리즘"""
        return '''
        # Prediction Logic
        from sklearn.model_selection import train_test_split

        # Prepare features and target
        X = data.drop(columns=[target_column])
        y = data[target_column]

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

        # Train model
        model = self._get_model(model_type)
        model.fit(X_train, y_train)

        # Make predictions
        predictions = model.predict(X_test)

        # Calculate metrics
        accuracy = model.score(X_test, y_test)

        return {
            "success": True,
            "predictions": predictions.tolist(),
            "accuracy": float(accuracy),
            "model_type": model_type
        }'''

    def _generate_data_processing_algorithm(self, req: RequirementSpec) -> str:
        """데이터 처리 도메인 알고리즘"""
        return '''
        # Data Processing Logic
        processed_data = data.copy()

        # Handle missing values
        if handle_missing:
            for col in processed_data.columns:
                if processed_data[col].isnull().any():
                    if processed_data[col].dtype in ['int64', 'float64']:
                        processed_data[col].fillna(processed_data[col].median(), inplace=True)
                    else:
                        processed_data[col].fillna(processed_data[col].mode()[0], inplace=True)

        # Remove duplicates
        if remove_duplicates:
            processed_data = processed_data.drop_duplicates()

        # Apply transformations
        for transform in transformations:
            processed_data = self._apply_transform(processed_data, transform)

        return {
            "success": True,
            "processed_data": processed_data,
            "rows_processed": len(processed_data),
            "columns": list(processed_data.columns)
        }'''

    def _generate_finance_algorithm(self, req: RequirementSpec) -> str:
        """금융 도메인 알고리즘"""
        return '''
        # Finance Logic
        import numpy as np

        # Calculate moving averages
        if 'close' in price_data.columns:
            prices = price_data['close']
        else:
            prices = price_data.iloc[:, 0]

        ma_short = prices.rolling(window=short_window).mean()
        ma_long = prices.rolling(window=long_window).mean()

        # Generate signals
        signals = pd.DataFrame(index=price_data.index)
        signals['price'] = prices
        signals['ma_short'] = ma_short
        signals['ma_long'] = ma_long
        signals['signal'] = 0

        # Buy signal: short MA crosses above long MA
        signals.loc[ma_short > ma_long, 'signal'] = 1
        # Sell signal: short MA crosses below long MA
        signals.loc[ma_short < ma_long, 'signal'] = -1

        # Calculate returns
        signals['returns'] = prices.pct_change()

        return {
            "success": True,
            "signals": signals.to_dict(),
            "current_signal": int(signals['signal'].iloc[-1]),
            "recommendation": "BUY" if signals['signal'].iloc[-1] == 1 else "SELL" if signals['signal'].iloc[-1] == -1 else "HOLD"
        }'''

    def _generate_social_algorithm(self, req: RequirementSpec) -> str:
        """소셜 미디어 도메인 알고리즘"""
        return '''
        # Social Media Analysis Logic
        from collections import Counter

        results = {
            "mentions": [],
            "sentiment_summary": {"positive": 0, "negative": 0, "neutral": 0},
            "top_hashtags": [],
            "engagement_metrics": {}
        }

        for post in posts:
            # Extract mentions
            if keyword.lower() in post.get('text', '').lower():
                results["mentions"].append({
                    "text": post['text'],
                    "timestamp": post.get('timestamp'),
                    "platform": post.get('platform'),
                    "engagement": post.get('likes', 0) + post.get('shares', 0)
                })

                # Analyze sentiment
                sentiment = self._analyze_sentiment(post['text'])
                results["sentiment_summary"][sentiment] += 1

        # Calculate engagement metrics
        total_engagement = sum(m['engagement'] for m in results["mentions"])
        results["engagement_metrics"] = {
            "total_mentions": len(results["mentions"]),
            "total_engagement": total_engagement,
            "avg_engagement": total_engagement / max(len(results["mentions"]), 1)
        }

        return {
            "success": True,
            "results": results,
            "crisis_detected": results["sentiment_summary"]["negative"] > results["sentiment_summary"]["positive"] * 2
        }'''

    def _generate_privacy_algorithm(self, req: RequirementSpec) -> str:
        """개인정보 보호 도메인 알고리즘"""
        return '''
        # Privacy Compliance Logic
        import re

        pii_patterns = {
            "email": r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            "phone": r'\b\d{3}[-.]?\d{3,4}[-.]?\d{4}\b',
            "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
            "credit_card": r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
            "korean_rrn": r'\b\d{6}[-]?\d{7}\b'
        }

        findings = {
            "personal_data_found": [],
            "compliance_issues": [],
            "recommendations": []
        }

        # Scan for PII
        for content in scan_targets:
            for pii_type, pattern in pii_patterns.items():
                matches = re.findall(pattern, str(content))
                if matches:
                    findings["personal_data_found"].append({
                        "type": pii_type,
                        "count": len(matches),
                        "locations": "masked for security"
                    })

        # Check GDPR requirements
        if standards and 'gdpr' in [s.lower() for s in standards]:
            gdpr_checks = self._check_gdpr_compliance(findings)
            findings["compliance_issues"].extend(gdpr_checks)

        # Generate recommendations
        findings["recommendations"] = self._generate_privacy_recommendations(findings)

        return {
            "success": True,
            "findings": findings,
            "compliance_status": len(findings["compliance_issues"]) == 0,
            "risk_level": "HIGH" if len(findings["personal_data_found"]) > 10 else "MEDIUM" if len(findings["personal_data_found"]) > 0 else "LOW"
        }'''

    def _generate_integration_algorithm(self, req: RequirementSpec) -> str:
        """통합 도메인 알고리즘"""
        return '''
        # API Integration Logic
        import aiohttp

        async with aiohttp.ClientSession() as session:
            headers = {
                "Content-Type": "application/json",
                **additional_headers
            }

            if method.upper() == "GET":
                async with session.get(url, headers=headers, params=params) as response:
                    status_code = response.status
                    response_data = await response.json()
            elif method.upper() == "POST":
                async with session.post(url, headers=headers, json=payload) as response:
                    status_code = response.status
                    response_data = await response.json()
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

        return {
            "success": status_code < 400,
            "status_code": status_code,
            "response": response_data,
            "endpoint": url
        }'''

    def _generate_visualization_algorithm(self, req: RequirementSpec) -> str:
        """시각화 도메인 알고리즘"""
        return '''
        # Visualization Logic
        import plotly.express as px
        import plotly.graph_objects as go

        fig = None

        if chart_type == "bar":
            fig = px.bar(data, x=x_column, y=y_column, title=title)
        elif chart_type == "line":
            fig = px.line(data, x=x_column, y=y_column, title=title)
        elif chart_type == "scatter":
            fig = px.scatter(data, x=x_column, y=y_column, title=title)
        elif chart_type == "pie":
            fig = px.pie(data, values=y_column, names=x_column, title=title)
        elif chart_type == "heatmap":
            fig = px.imshow(data.corr(), title=title or "Correlation Heatmap")
        else:
            raise ValueError(f"Unsupported chart type: {chart_type}")

        # Apply styling
        fig.update_layout(
            template="plotly_white",
            font=dict(size=12)
        )

        chart_html = fig.to_html(include_plotlyjs='cdn')

        return {
            "success": True,
            "chart_html": chart_html,
            "chart_type": chart_type
        }'''

    def _generate_general_algorithm(self, req: RequirementSpec) -> str:
        """일반 도메인 알고리즘"""
        # Get the first parameter name from inputs (usually the data parameter)
        first_param = list(req.inputs.keys())[0] if req.inputs else "data"

        return f'''
        # General Processing Logic for {req.name}
        result = {{}}

        # Process inputs - using {first_param} as main data parameter
        if isinstance({first_param}, dict):
            for key, value in {first_param}.items():
                result[key] = value
        else:
            result["input"] = {first_param}

        # Return processed result
        return {{
            "success": True,
            "result": result,
            "processed_at": datetime.now().isoformat()
        }}'''

    def _adapt_template(self, template: str, req: RequirementSpec) -> str:
        """템플릿 코드를 요구사항에 맞게 조정"""
        # 변수명 치환
        adapted = template

        # 입력 파라미터 반영
        for input_name, input_type in req.inputs.items():
            adapted = adapted.replace("INPUT_PLACEHOLDER", input_name, 1)

        return adapted

    def _generate_error_handling(self, domain: DomainType, algorithm: str) -> str:
        """도메인별 에러 처리 생성"""

        error_patterns = self.error_patterns.get(domain, self.error_patterns[DomainType.GENERAL])

        handlers = []
        for error_type, message, recovery in error_patterns:
            # 🔥 FIX: Use 4 spaces so after code_assembler adds 4 more = 8 (same as try:)
            handler = f'''
    except {error_type} as e:
        logger.error(f"{message}: {{e}}")
        {recovery}'''
            handlers.append(handler)

        return '\n'.join(handlers)

    def _generate_validations(self, req: RequirementSpec) -> List[str]:
        """입력 검증 코드 생성"""

        validations = []

        for input_name, input_type in req.inputs.items():
            if input_type == 'str':
                validations.append(
                    f'if not isinstance({input_name}, str): '
                    f'raise TypeError("{input_name} must be a string")'
                )
                validations.append(
                    f'if not {input_name}: '
                    f'raise ValueError("{input_name} cannot be empty")'
                )
            elif input_type in ['int', 'float', 'number']:
                validations.append(
                    f'if not isinstance({input_name}, (int, float)): '
                    f'raise TypeError("{input_name} must be a number")'
                )
            elif input_type == 'List' or input_type.startswith('List['):
                validations.append(
                    f'if not isinstance({input_name}, list): '
                    f'raise TypeError("{input_name} must be a list")'
                )
            elif input_type == 'Dict' or input_type.startswith('Dict['):
                validations.append(
                    f'if not isinstance({input_name}, dict): '
                    f'raise TypeError("{input_name} must be a dictionary")'
                )
            elif 'DataFrame' in input_type:
                validations.append(
                    f'if not isinstance({input_name}, pd.DataFrame): '
                    f'raise TypeError("{input_name} must be a pandas DataFrame")'
                )
                validations.append(
                    f'if {input_name}.empty: '
                    f'raise ValueError("{input_name} cannot be empty")'
                )

        return validations

    def _optimize_logic(
        self,
        algorithm: str,
        resources: Dict[str, Any],
        complexity: float
    ) -> Tuple[str, List[str]]:
        """리소스 제약에 맞게 최적화"""

        optimizations = []
        optimized = algorithm

        # 메모리 최적화
        if resources.get('memory_constrained', False):
            optimizations.append("memory_optimization")
            # Generator 표현식 권장 코멘트 추가
            if 'for' in optimized and 'list' not in optimized:
                optimized = optimized.replace(
                    '# Core Algorithm',
                    '# Core Algorithm (memory optimized - use generators where possible)'
                )

        # 시간 최적화
        if resources.get('time_sensitive', False):
            optimizations.append("time_optimization")
            # 캐싱 힌트 추가
            optimized = optimized.replace(
                '# Core Algorithm',
                '# Core Algorithm (time optimized - consider caching frequent operations)'
            )

        # 복잡도 기반 최적화
        if complexity > 0.7:
            optimizations.append("high_complexity_handling")
            # 배치 처리 권장
            optimized = optimized.replace(
                '# Core Algorithm',
                '# Core Algorithm (high complexity - batch processing recommended)'
            )

        # 병렬화 기회
        if resources.get('parallelizable', False):
            optimizations.append("parallel_processing")
            optimized = optimized.replace(
                '# Core Algorithm',
                '# Core Algorithm (parallelizable - consider async/concurrent execution)'
            )

        return optimized, optimizations

    def _load_algorithm_templates(self) -> Dict[DomainType, str]:
        """도메인별 알고리즘 템플릿 로드"""
        return {
        DomainType.CALCULATION: "calculation_template",
        DomainType.ANALYSIS: "analysis_template",
        DomainType.PREDICTION: "prediction_template",
        DomainType.DATA_PROCESSING: "data_processing_template",
        DomainType.FINANCE: "finance_template",
        DomainType.SOCIAL: "social_template",
        DomainType.PRIVACY: "privacy_template",
        DomainType.INTEGRATION: "integration_template",
        DomainType.VISUALIZATION: "visualization_template",
        DomainType.GENERAL: "general_template"
        }

    def _load_error_patterns(self) -> Dict[DomainType, List[Tuple[str, str, str]]]:
        """도메인별 에러 패턴 로드"""
        return {
        DomainType.CALCULATION: [
            ('ValueError', 'Invalid calculation input', 'return {"success": False, "error": "Invalid input", "details": str(e)}'),
            ('ZeroDivisionError', 'Division by zero attempted', 'return {"success": False, "error": "Division by zero", "details": str(e)}'),
            ('OverflowError', 'Numeric overflow occurred', 'return {"success": False, "error": "Overflow", "details": str(e)}'),
        ],
        DomainType.ANALYSIS: [
            ('ValueError', 'Invalid data format', 'return {"success": False, "error": "Invalid data", "details": str(e)}'),
            ('KeyError', 'Missing required column', 'return {"success": False, "error": "Missing column", "details": str(e)}'),
            ('TypeError', 'Incompatible data types', 'return {"success": False, "error": "Type error", "details": str(e)}'),
        ],
        DomainType.PREDICTION: [
            ('ValueError', 'Model training failed', 'return {"success": False, "error": "Training failed", "details": str(e)}'),
            ('KeyError', 'Target column not found', 'return {"success": False, "error": "Missing target", "details": str(e)}'),
        ],
        DomainType.DATA_PROCESSING: [
            ('FileNotFoundError', 'Data file not found', 'return {"success": False, "error": "File not found", "details": str(e)}'),
            ('ValueError', 'Data parsing error', 'return {"success": False, "error": "Parse error", "details": str(e)}'),
        ],
        DomainType.FINANCE: [
            ('ValueError', 'Invalid financial data', 'return {"success": False, "error": "Invalid data", "details": str(e)}'),
            ('KeyError', 'Missing price column', 'return {"success": False, "error": "Missing column", "details": str(e)}'),
        ],
        DomainType.SOCIAL: [
            ('ConnectionError', 'Social API connection failed', 'return {"success": False, "error": "Connection failed", "details": str(e)}'),
            ('TimeoutError', 'API request timed out', 'return {"success": False, "error": "Timeout", "details": str(e)}'),
        ],
        DomainType.PRIVACY: [
            ('PermissionError', 'Access denied to scan target', 'return {"success": False, "error": "Access denied", "details": str(e)}'),
            ('ValueError', 'Invalid scan configuration', 'return {"success": False, "error": "Invalid config", "details": str(e)}'),
        ],
        DomainType.INTEGRATION: [
            ('ConnectionError', 'API connection failed', 'return {"success": False, "error": "Connection failed", "details": str(e)}'),
            ('TimeoutError', 'Request timed out', 'return {"success": False, "error": "Timeout", "details": str(e)}'),
            ('JSONDecodeError', 'Invalid JSON response', 'return {"success": False, "error": "Invalid JSON", "details": str(e)}'),
        ],
        DomainType.VISUALIZATION: [
            ('ValueError', 'Invalid chart configuration', 'return {"success": False, "error": "Invalid config", "details": str(e)}'),
            ('KeyError', 'Missing data column', 'return {"success": False, "error": "Missing column", "details": str(e)}'),
        ],
        DomainType.GENERAL: [
            ('Exception', 'General processing error', 'return {"success": False, "error": "Processing error", "details": str(e)}'),
        ]
        }

    def _load_optimization_rules(self) -> Dict[str, Any]:
        """최적화 규칙 로드"""
        return {
        'memory_optimization': {
            'use_generators': True,
            'chunk_processing': True,
            'lazy_loading': True
        },
        'time_optimization': {
            'caching': True,
            'early_termination': True,
            'batch_processing': True
        },
        'parallel_processing': {
            'async_enabled': True,
            'thread_pool': True,
            'process_pool': False
        }
        }

    def get_domain_from_capabilities(self, capabilities: List[str]) -> DomainType:
        """capability 리스트에서 도메인 유형 추론"""

        domain_mapping = {
        # Calculation
        'arithmetic_operations': DomainType.CALCULATION,
        'addition': DomainType.CALCULATION,
        'subtraction': DomainType.CALCULATION,
        'multiplication': DomainType.CALCULATION,
        'division': DomainType.CALCULATION,

        # Analysis
        'statistical_analysis': DomainType.ANALYSIS,
        'data_aggregation': DomainType.ANALYSIS,
        'trend_analysis': DomainType.ANALYSIS,

        # Prediction
        'machine_learning': DomainType.PREDICTION,
        'weather_prediction': DomainType.PREDICTION,

        # Data Processing
        'csv_processing': DomainType.DATA_PROCESSING,
        'json_handling': DomainType.DATA_PROCESSING,
        'data_cleaning': DomainType.DATA_PROCESSING,

        # Finance
        'stock_data_collection': DomainType.FINANCE,
        'moving_average': DomainType.FINANCE,
        'trading_signals': DomainType.FINANCE,
        'portfolio_analysis': DomainType.FINANCE,
        'technical_analysis': DomainType.FINANCE,
        'fundamental_analysis': DomainType.FINANCE,

        # Social
        'social_monitoring': DomainType.SOCIAL,
        'brand_monitoring': DomainType.SOCIAL,
        'social_sentiment': DomainType.SOCIAL,
        'sentiment_analysis': DomainType.SOCIAL,
        'crisis_detection': DomainType.SOCIAL,

        # Privacy
        'privacy_compliance': DomainType.PRIVACY,
        'gdpr_compliance': DomainType.PRIVACY,
        'privacy_scanning': DomainType.PRIVACY,

        # Integration
        'web_integration': DomainType.INTEGRATION,
        'api_integration': DomainType.INTEGRATION,
        'email_notifications': DomainType.INTEGRATION,

        # Visualization
        'data_visualization': DomainType.VISUALIZATION,
        }

        # Count domain occurrences
        domain_counts = {}
        for cap in capabilities:
            domain = domain_mapping.get(cap, DomainType.GENERAL)
            domain_counts[domain] = domain_counts.get(domain, 0) + 1

        if not domain_counts:
            return DomainType.GENERAL

        # Return most common domain
        return max(domain_counts, key=domain_counts.get)


# 싱글톤 인스턴스
_synthesizer_instance = None


def get_logic_synthesizer() -> LogicSynthesizer:
    """싱글톤 LogicSynthesizer 인스턴스 반환"""
    global _synthesizer_instance
    if _synthesizer_instance is None:
        _synthesizer_instance = LogicSynthesizer()
    return _synthesizer_instance
