"""
Query Analyzer for Business Logic Generation
=============================================
Enhanced with:
- Word boundary matching to prevent false positives
- Improved Korean keyword support
- Integration with EnhancedComplexityCalculator
"""

from typing import Dict, Any, List, Optional, Set, Tuple
from dataclasses import dataclass
from enum import Enum
from loguru import logger
import re
import json

# Import enhanced complexity calculator
try:
    from .enhanced_complexity_calculator import (
        EnhancedComplexityCalculator,
        get_complexity_calculator,
        ComplexityBreakdown
    )
    ENHANCED_COMPLEXITY_AVAILABLE = True
except ImportError:
    ENHANCED_COMPLEXITY_AVAILABLE = False
    logger.warning("Enhanced complexity calculator not available, using basic calculation")

# Import LLM client for semantic analysis
try:
    from ..llm_client import LLMClient
    LLM_CLIENT_AVAILABLE = True
except ImportError:
    LLM_CLIENT_AVAILABLE = False
    logger.warning("LLM client not available, using pattern-based capability identification")


class QueryIntent(Enum):
    """Query intent categories"""
    DATA_PROCESSING = "data_processing"
    ANALYSIS = "analysis"
    PREDICTION = "prediction"
    VISUALIZATION = "visualization"
    INTEGRATION = "integration"
    TRANSFORMATION = "transformation"
    AUTOMATION = "automation"


@dataclass
class QueryAnalysis:
    """Query analysis result"""
    original_query: str
    intent: QueryIntent
    entities: Dict[str, List[str]]
    keywords: List[str]
    required_capabilities: List[str]
    complexity_score: float
    language: str = "en"


@dataclass
class FunctionSpec:
    """Function specification"""
    name: str
    category: str
    inputs: Dict[str, str]
    outputs: List[str]
    description: str
    template_id: Optional[str] = None
    customizations: Optional[Dict[str, str]] = None
    business_rules: Optional[str] = None  # Original business rules from user query
    test_cases: Optional[List[Dict]] = None  # Test cases for guiding LLM generation


class QueryAnalyzer:
    """Analyzes user queries to determine required functions"""

    def __init__(self, use_llm_analysis: bool = True):
        """
        Initialize QueryAnalyzer.

        Args:
            use_llm_analysis: Whether to use LLM for semantic capability identification.
                             Falls back to pattern matching if LLM unavailable.
        """
        self.use_llm_analysis = use_llm_analysis and LLM_CLIENT_AVAILABLE
        self.llm_client = None

        if self.use_llm_analysis:
            try:
                self.llm_client = LLMClient()
                logger.info("QueryAnalyzer initialized with LLM-based semantic analysis")
            except Exception as e:
                logger.warning(f"Failed to initialize LLM client: {e}")
                self.use_llm_analysis = False

        self.intent_keywords = {
            QueryIntent.DATA_PROCESSING: [
                "load", "read", "import", "fetch", "get", "retrieve",
                "데이터", "불러오기", "읽기", "가져오기"
            ],
            QueryIntent.ANALYSIS: [
                "analyze", "calculate", "compute", "statistics", "mean", "average",
                "분석", "계산", "통계", "평균", "집계"
            ],
            QueryIntent.PREDICTION: [
                "predict", "forecast", "estimate", "classify", "model",
                "예측", "예상", "추정", "분류", "모델"
            ],
            QueryIntent.VISUALIZATION: [
                "chart", "plot", "graph", "visualize", "dashboard", "display",
                "차트", "그래프", "시각화", "대시보드", "표시"
            ],
            QueryIntent.INTEGRATION: [
                "send", "notify", "email", "webhook", "api", "integrate",
                "전송", "알림", "이메일", "연동", "통합"
            ],
            QueryIntent.TRANSFORMATION: [
                "clean", "transform", "convert", "aggregate", "normalize",
                "정제", "변환", "변경", "집계", "정규화"
            ],
            QueryIntent.AUTOMATION: [
                "automate", "schedule", "trigger", "workflow", "pipeline",
                "자동화", "스케줄", "워크플로우", "파이프라인"
            ]
        }
        
        # capability_patterns: Use MULTI-WORD patterns to prevent false positives.
        # Single generic words like "text", "add", "model" cause wrong capability matches.
        self.capability_patterns = {
            "csv_processing": ["csv file", "csv data", "comma separated", "csv 파일"],
            "json_handling": ["json data", "parse json", "json file", "json 파일"],
            "database_operations": ["database", "sql query", "데이터베이스"],
            "statistical_analysis": ["statistical analysis", "standard deviation", "통계 분석", "통계적 분석"],
            "machine_learning": ["machine learning", "train model", "ml model", "머신러닝", "딥러닝"],
            # Business Analytics
            "churn_prediction": ["churn", "customer retention", "attrition", "고객 이탈", "유지율"],
            "customer_segmentation": ["customer segment", "segmentation", "clustering", "고객 세분화", "군집 분석"],
            "campaign_optimization": ["campaign optimization", "marketing campaign", "캠페인 최적화", "마케팅 캠페인"],
            "customer_journey": ["customer journey", "customer lifecycle", "고객 여정", "라이프사이클"],
            "retention_analysis": ["retention analysis", "customer loyalty", "lifetime value", "ltv", "clv", "충성도 분석", "생애가치"],
            "scoring_model": ["scoring model", "credit score", "점수 모델", "스코어링 모델"],
            "probability_calculation": ["probability calculation", "risk score", "확률 계산", "위험도 계산"],
            "factor_analysis": ["factor analysis", "feature importance", "요인 분석", "변수 분석"],
            "text_processing": ["nlp processing", "text classification", "classify text", "텍스트 분류", "자연어 처리"],
            "sentiment_analysis": ["sentiment analysis", "emotion analysis", "감정 분석", "감성 분석"],
            "review_analysis": ["review analysis", "feedback analysis", "리뷰 분석", "후기 분석"],
            "data_visualization": ["data chart", "data plot", "data graph", "데이터 차트", "데이터 그래프"],
            "email_notifications": ["send email", "email notification", "이메일 발송", "이메일 알림"],
            "web_integration": ["webhook", "http request", "rest api call", "api call"],
            "data_cleaning": ["data cleaning", "missing values", "remove duplicates", "데이터 정제"],
            "data_aggregation": ["data aggregation", "group by", "summarize data", "데이터 집계"],
            # Mathematical operations - require explicit math context
            "arithmetic_operations": ["calculator", "arithmetic", "계산기", "산술 연산", "사칙연산"],
            "addition": ["add numbers", "addition", "plus", "sum numbers", "더하기", "덧셈"],
            "subtraction": ["subtract numbers", "subtraction", "minus", "빼기", "뺄셈"],
            "multiplication": ["multiply numbers", "multiplication", "times", "곱하기", "곱셈"],
            "division": ["divide numbers", "division", "quotient", "나누기", "나눗셈"],
            # Weather analysis
            "weather_analysis": ["weather analysis", "weather data", "climate data", "날씨 분석", "기상 분석", "일기예보"],
            "temperature_processing": ["temperature data", "celsius fahrenheit", "온도 데이터", "기온 분석"],
            "humidity_analysis": ["humidity data", "humidity analysis", "습도 분석", "습도 데이터"],
            "weather_prediction": ["weather prediction", "weather forecast", "날씨 예측", "날씨 예보"],
            # Computer Vision - require explicit vision context
            "computer_vision": ["computer vision", "image processing", "비전 처리", "영상 처리"],
            "object_detection": ["object detection", "detect objects", "객체 탐지", "객체 감지"],
            "face_recognition": ["face recognition", "facial recognition", "얼굴 인식"],
            "ocr": ["ocr", "text extraction from image", "이미지에서 텍스트", "문자 인식"],
            "image_quality": ["image quality", "picture quality", "video quality", "화질 평가", "이미지 품질"],
            "visualization": ["bounding box", "detection visualization", "바운딩 박스", "결과 시각화"],
            "batch_processing": ["batch processing", "bulk processing", "배치 처리", "일괄 처리"],
            "api_integration": ["api integration", "api 연동", "api 통합", "외부 api"],
            # Privacy and Security
            "privacy_compliance": ["privacy compliance", "gdpr compliance", "ccpa compliance", "개인정보 보호", "프라이버시 준수"],
            "data_protection": ["data protection", "data security", "데이터 보호", "데이터 보안"],
            "privacy_scanning": ["privacy scan", "privacy audit", "개인정보 스캔", "개인정보 검사"],
            "gdpr_compliance": ["gdpr", "general data protection", "eu privacy", "개인정보보호법"],
            "ccpa_compliance": ["ccpa", "california consumer privacy", "캘리포니아 소비자"],
            "privacy_policy": ["privacy policy", "처리방침", "개인정보 정책"],
            "compliance_report": ["compliance report", "audit report", "준수 보고서", "감사 보고서"],
            "data_discovery": ["data discovery", "personal data discovery", "개인정보 파악", "데이터 발견"],
            "privacy_recommendations": ["privacy recommendation", "privacy improvement", "개인정보 개선", "보안 권고"],
            # Social Media and Listening
            "social_monitoring": ["social media monitor", "social listening", "소셜 모니터링", "SNS 모니터링"],
            "social_platforms": ["twitter", "instagram", "facebook", "reddit", "linkedin", "tiktok", "youtube", "트위터", "인스타그램"],
            "brand_monitoring": ["brand monitoring", "brand mention", "브랜드 모니터링", "브랜드 멘션"],
            "social_sentiment": ["social media sentiment", "social sentiment", "소셜 감정 분석"],
            "influence_measurement": ["influence measurement", "social influence", "영향력 측정", "소셜 영향력"],
            "crisis_detection": ["crisis detection", "social crisis", "위기 감지", "위기 탐지"],
            "competitor_tracking": ["competitor tracking", "competitor analysis", "경쟁사 추적", "경쟁사 분석"],
            "trend_analysis": ["trend analysis", "trending topics", "트렌드 분석", "추세 분석"],
            "social_analytics": ["social analytics", "social media analytics", "소셜 분석", "SNS 분석"],
            "real_time_monitoring": ["real-time monitoring", "realtime monitoring", "실시간 모니터링"],
            # Stock and Financial Analysis
            "stock_data_collection": ["stock data", "stock price", "주식 데이터", "주가 데이터", "ticker", "종목 데이터"],
            "moving_average": ["moving average", "이동평균", "이동평균선", "exponential moving", "simple moving"],
            "trading_signals": ["trading signal", "buy signal", "sell signal", "매수 신호", "매도 신호", "트레이딩 시그널"],
            "portfolio_analysis": ["portfolio analysis", "portfolio management", "포트폴리오 분석", "자산 배분"],
            "risk_assessment": ["risk assessment", "value at risk", "위험 분석", "리스크 분석", "변동성 분석"],
            "investment_recommendation": ["investment recommendation", "investment advice", "투자 추천", "투자 조언"],
            "technical_analysis": ["technical analysis", "chart pattern", "기술적 분석", "차트 패턴", "지지 저항"],
            "fundamental_analysis": ["fundamental analysis", "financial analysis", "기본적 분석", "재무 분석", "실적 분석"]
        }

        # Patterns that require exact word boundary matching (prevent false positives)
        # These won't match partial words like "per" in "performs"
        # NOTE: Do NOT add generic single words like "price", "track", "monitor" here.
        # "price" was removed because it false-matched crypto/general pricing queries to stock templates.
        self.exact_match_patterns = {
            "moving_average": ["ma", "ema", "sma"],  # Won't match "make", "email"
            "fundamental_analysis": ["per", "pbr", "eps"],  # Won't match "performs", "personal"
        }
        
        logger.info("Query analyzer initialized")
    
    async def analyze(self, query: str) -> QueryAnalysis:
        """Analyze user query"""
        
        logger.info(f"Starting analysis for query: {query}")
        
        # Detect language
        language = self._detect_language(query)
        logger.debug(f"Language detected: {language}")
        
        # Extract keywords
        keywords = self._extract_keywords(query)
        logger.info(f"Keywords extracted: {keywords}")
        
        # Determine intent
        intent = self._determine_intent(query, keywords)
        logger.info(f"Intent determined: {intent.value}")
        
        # Extract entities
        entities = self._extract_entities(query)
        logger.debug(f"Entities extracted: {entities}")

        # Identify required capabilities using LLM semantic analysis if available
        if self.use_llm_analysis and self.llm_client:
            logger.info("Using LLM-based semantic capability identification")
            capabilities = await self._identify_capabilities_semantic(query, keywords)
            # None = LLM call failed → fallback to pattern matching
            # [] = LLM intentionally returned empty (valid for simple utility agents) → no fallback
            if capabilities is None:
                logger.warning("LLM analysis failed, falling back to pattern matching")
                capabilities = self._identify_capabilities(query, keywords)
            else:
                logger.info(f"LLM returned {len(capabilities)} capabilities (empty=valid for simple agents)")
        else:
            logger.info("Using pattern-based capability identification")
            capabilities = self._identify_capabilities(query, keywords)
        logger.info(f"Capabilities identified: {capabilities}")
        
        # Check for privacy compliance query and enhance capabilities if needed
        if self._is_privacy_compliance_query(query):
            capabilities = self._enhance_privacy_capabilities(capabilities, query)
            logger.info(f"Enhanced privacy capabilities: {capabilities}")
        
        # Calculate complexity
        complexity = self._calculate_complexity(query, capabilities, entities)
        
        analysis = QueryAnalysis(
            original_query=query,
            intent=intent,
            entities=entities,
            keywords=keywords,
            required_capabilities=capabilities,
            complexity_score=complexity,
            language=language
        )
        
        logger.info(f"Query analysis completed: intent={intent.value}, capabilities={len(capabilities)}, complexity={complexity:.2f}")
        
        return analysis
    
    def _detect_language(self, query: str) -> str:
        """Detect query language"""
        
        korean_chars = re.findall(r'[가-힣]', query)
        if len(korean_chars) > len(query) * 0.1:  # More than 10% Korean
            return "ko"
        return "en"
    
    def _extract_keywords(self, query: str) -> List[str]:
        """Extract keywords from query"""
        
        # Remove common words
        stopwords = {
            "en": ["the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
                   "of", "with", "by", "from", "that", "which", "this", "these", "those",
                   "create", "make", "build", "generate", "implement"],
            "ko": ["그", "저", "이", "것", "수", "등", "및", "와", "과", "을", "를",
                   "에", "의", "로", "으로", "부터", "까지", "만들어", "생성", "구현"]
        }
        
        words = re.findall(r'\b[\w가-힣]+\b', query.lower())
        
        # Filter stopwords
        all_stopwords = stopwords["en"] + stopwords["ko"]
        keywords = [w for w in words if w not in all_stopwords and len(w) > 1]
        
        return keywords
    
    def _determine_intent(self, query: str, keywords: List[str]) -> QueryIntent:
        """Determine query intent"""
        
        query_lower = query.lower()
        intent_scores = {}
        
        for intent, intent_keywords in self.intent_keywords.items():
            score = 0
            for keyword in intent_keywords:
                if keyword in query_lower:
                    score += 2  # Direct match
                elif any(keyword in kw for kw in keywords):
                    score += 1  # Partial match
            
            intent_scores[intent] = score
        
        # Return intent with highest score
        if max(intent_scores.values()) > 0:
            return max(intent_scores, key=intent_scores.get)
        
        # Default to data processing
        return QueryIntent.DATA_PROCESSING
    
    def _extract_entities(self, query: str) -> Dict[str, List[str]]:
        """Extract entities from query"""
        
        entities = {
            "data_sources": [],
            "operations": [],
            "targets": [],
            "formats": [],
            "metrics": []
        }
        
        # Extract file formats
        formats = re.findall(r'\b(csv|json|xml|excel|pdf|txt)\b', query.lower())
        entities["formats"] = formats
        
        # Extract operations
        operations = re.findall(
            r'\b(load|read|analyze|calculate|predict|visualize|send|clean|aggregate)\b',
            query.lower()
        )
        entities["operations"] = operations
        
        # Extract metrics
        metrics = re.findall(
            r'\b(mean|average|sum|count|min|max|median|std|variance)\b',
            query.lower()
        )
        entities["metrics"] = metrics
        
        # Extract data source indicators
        if "file" in query.lower() or "파일" in query:
            entities["data_sources"].append("file")
        if "database" in query.lower() or "데이터베이스" in query:
            entities["data_sources"].append("database")
        if "api" in query.lower():
            entities["data_sources"].append("api")
        
        return entities
    
    def _identify_capabilities(
        self,
        query: str,
        keywords: List[str]
    ) -> List[str]:
        """Identify required capabilities with word boundary matching"""

        capabilities = []
        query_lower = query.lower()

        logger.debug(f"Identifying capabilities for query: {query_lower}")
        logger.debug(f"Keywords: {keywords}")

        for capability, patterns in self.capability_patterns.items():
            found = False
            for pattern in patterns:
                if pattern in query_lower:
                    logger.info(f"  ✅ Found capability '{capability}' via pattern '{pattern}' in query")
                    capabilities.append(capability)
                    found = True
                    break
                elif any(pattern in kw for kw in keywords):
                    logger.info(f"  ✅ Found capability '{capability}' via pattern '{pattern}' in keywords")
                    capabilities.append(capability)
                    found = True
                    break

            # Check exact match patterns with word boundaries (prevent false positives)
            if not found and capability in self.exact_match_patterns:
                for exact_pattern in self.exact_match_patterns[capability]:
                    # Use word boundary regex to avoid matching partial words
                    # e.g., "per" won't match "performs", "ma" won't match "make"
                    pattern_regex = r'\b' + re.escape(exact_pattern) + r'\b'
                    if re.search(pattern_regex, query_lower):
                        logger.info(f"  ✅ Found capability '{capability}' via exact pattern '{exact_pattern}' (word boundary)")
                        capabilities.append(capability)
                        break

        logger.info(f"Total capabilities identified (pattern-based): {list(set(capabilities))}")
        return list(set(capabilities))

    async def _identify_capabilities_semantic(
        self,
        query: str,
        keywords: List[str]
    ) -> Optional[List[str]]:
        """
        Identify required capabilities using LLM semantic analysis.

        This method analyzes the full query context to determine which capabilities
        are actually needed, avoiding false positives from naive pattern matching.

        Args:
            query: The user's original query
            keywords: Extracted keywords from the query

        Returns:
            List of relevant capability names if LLM succeeds (can be empty []),
            None if LLM call fails (caller should fall back to pattern matching)
        """
        if not self.llm_client:
            logger.warning("LLM client not available")
            return None

        # Get available capabilities for the prompt
        available_capabilities = list(self.capability_patterns.keys())

        # Build capability descriptions for the LLM
        capability_descriptions = {
            # Business/Analytics
            "csv_processing": "Load and process CSV files",
            "json_handling": "Parse and handle JSON data",
            "database_operations": "Interact with databases using SQL",
            "statistical_analysis": "Calculate statistics like mean, median, std",
            "data_visualization": "Create charts, plots, graphs",
            "data_cleaning": "Clean data, handle missing values, duplicates",
            "data_aggregation": "Group, summarize, aggregate data",
            "trend_analysis": "Analyze trends and patterns over time",

            # ML/AI
            "machine_learning": "Train/use ML models for prediction",
            "text_processing": "Process and classify text data",
            "sentiment_analysis": "Analyze sentiment/emotion in text",
            "review_analysis": "Analyze customer reviews and feedback",

            # Business Analytics (for experiment tasks)
            "churn_prediction": "Predict customer churn/attrition probability",
            "customer_segmentation": "Segment customers into groups/clusters",
            "campaign_optimization": "Optimize marketing campaigns and targeting",
            "customer_journey": "Analyze customer journey and lifecycle",
            "retention_analysis": "Analyze customer retention and loyalty",
            "scoring_model": "Score and rank items by priority/importance",
            "probability_calculation": "Calculate probabilities and likelihoods",
            "factor_analysis": "Analyze contributing factors and variables",

            # Integration
            "email_notifications": "Send email notifications",
            "web_integration": "Call webhooks and external APIs",
            "api_integration": "Integrate with external API services",

            # Mathematical (ONLY for explicit numeric arithmetic like "2+2", "5*3")
            # DO NOT select these for business calculations like "calculate churn rate"
            "arithmetic_operations": "ONLY for explicit numeric math like '2+2', '10/5', NOT for business calculations",
            "addition": "ONLY for explicit addition like '5+3', NOT 'add factors' or 'add features'",
            "subtraction": "ONLY for explicit subtraction like '10-3'",
            "multiplication": "ONLY for explicit multiplication like '4*5'",
            "division": "ONLY for explicit division like '20/4'",

            # Weather
            "weather_analysis": "Analyze weather/climate data",
            "temperature_processing": "Process temperature readings",
            "humidity_analysis": "Analyze humidity levels",
            "weather_prediction": "Forecast future weather",

            # Computer Vision
            "computer_vision": "Process images/video",
            "object_detection": "Detect objects in images",
            "face_recognition": "Recognize faces in images",
            "ocr": "Extract text from images",
            "image_quality": "Assess image/video quality",
            "visualization": "Visualize results with bounding boxes",
            "batch_processing": "Process multiple items in batch",

            # Privacy
            "privacy_compliance": "Assess privacy compliance (GDPR, CCPA)",
            "privacy_scanning": "Scan for personal data",
            "gdpr_compliance": "Check GDPR compliance",
            "ccpa_compliance": "Check CCPA compliance",
            "privacy_policy": "Analyze privacy policies",
            "compliance_report": "Generate compliance reports",
            "data_discovery": "Discover personal data",
            "privacy_recommendations": "Generate privacy improvements",
            "data_protection": "Implement data protection measures",

            # Social Media
            "social_monitoring": "Monitor social media platforms",
            "brand_monitoring": "Track brand mentions",
            "social_sentiment": "Analyze social media sentiment",
            "influence_measurement": "Measure social media influence",
            "crisis_detection": "Detect potential crisis situations",
            "competitor_tracking": "Track competitor activity",
            "social_analytics": "Generate social media analytics",
            "real_time_monitoring": "Real-time social monitoring",
            "social_platforms": "Work with specific social platforms",

            # Finance (STOCK MARKET only — NOT for cryptocurrency/bitcoin/general pricing)
            "stock_data_collection": "Collect STOCK MARKET ticker data using yfinance (NOT for cryptocurrency, NOT for general price tracking)",
            "moving_average": "Calculate moving averages (SMA, EMA)",
            "trading_signals": "Analyze buy/sell trading signals",
            "portfolio_analysis": "Analyze portfolio composition",
            "risk_assessment": "Assess investment risk (VaR, volatility)",
            "investment_recommendation": "Generate investment recommendations",
            "technical_analysis": "Perform technical chart analysis",
            "fundamental_analysis": "Analyze company financials",
        }

        # Build prompt for LLM
        system_prompt = """You are an expert at analyzing user queries for an AI agent generation system.
Your task is to identify which capabilities are ACTUALLY needed based on the FULL CONTEXT of the query.

CRITICAL RULES:
1. Analyze the ENTIRE query context, not individual words
2. "add" in "add risk factors" means INCLUDE/INCORPORATE, NOT arithmetic addition
3. "sum" in "summary" or "in sum" means SUMMARIZE, NOT arithmetic addition
4. "calculate" in business context (calculate churn rate, calculate discount, calculate probability) means DETERMINE/COMPUTE using business logic, NOT arithmetic operations
5. NEVER select arithmetic_operations, addition, subtraction, multiplication, or division for BUSINESS calculations
6. arithmetic_operations is ONLY for explicit math like "2+2", "5*3", "10/2" - NOT for "calculate order discount" or "calculate churn probability"
7. Business analytics capabilities (churn_prediction, scoring_model, probability_calculation, etc.) ALREADY include the calculation logic needed
8. Select capabilities that match the user's business intent
9. For SIMPLE utility agents (converter, password generator, todo list, timer, crypto tracker, etc.), return an EMPTY array []. These agents need CUSTOM logic generated by LLM, not predefined templates.
10. Do NOT select web_integration, email_notifications, or text_processing unless the query EXPLICITLY asks for webhooks, sending emails, or NLP text classification.
11. stock_data_collection is ONLY for stock market tickers (e.g., "AAPL stock price"). Do NOT use it for cryptocurrency, bitcoin, general price tracking, or pricing models.
12. Be CONSERVATIVE - only select capabilities you are very confident about. When in doubt, return [].
13. MINIMIZE selection: select the FEWEST capabilities that cover the query. If ONE capability covers the task, return ONLY that one. Do NOT add csv_processing, json_handling, data_cleaning, machine_learning, etc. unless the query EXPLICITLY asks for those features.
14. For a query like "calculate churn probability", return ONLY ["churn_prediction"] — do NOT add data_cleaning, statistical_analysis, etc.

Return ONLY a JSON array of capability names, nothing else.
Example for "calculate churn probability": ["churn_prediction"]
Example for "analyze CSV data and build ML model": ["csv_processing", "machine_learning"]"""

        # Format capability list for prompt
        cap_list = "\n".join([f"- {cap}: {desc}" for cap, desc in capability_descriptions.items()])

        user_prompt = f"""Analyze this query and identify the required capabilities:

QUERY: "{query}"

AVAILABLE CAPABILITIES:
{cap_list}

Based on the FULL CONTEXT of the query, which capabilities are needed?

IMPORTANT REMINDERS:
- "add" in business context = "include/incorporate", NOT arithmetic addition
- "sum" in business context = "summarize", NOT arithmetic addition
- "calculate" in business context = "determine/compute business logic", NOT arithmetic
- DO NOT select arithmetic_operations for queries like "calculate discount", "calculate probability", "calculate score"
- Business capabilities (churn_prediction, scoring_model, probability_calculation) INCLUDE calculation logic
- For simple utility agents (converter, password, todo, timer, crypto tracker, etc.), return [] — they need custom LLM-generated logic
- stock_data_collection is ONLY for stock market tickers (AAPL, TSLA) — NOT for cryptocurrency/bitcoin/general pricing
- Do NOT select web_integration unless query explicitly mentions webhooks/HTTP calls
- Do NOT select email_notifications unless query explicitly mentions sending emails
- Do NOT select text_processing unless query explicitly mentions NLP/sentiment/classification
- When unsure, return fewer capabilities (or empty []) — it's better to use LLM generation than wrong templates
- MINIMIZE: return the SMALLEST set of capabilities. ONE capability per core task. Do NOT pad with supporting capabilities (csv, json, data_cleaning) unless explicitly requested.

Return ONLY a JSON array of capability names (no explanation):"""

        try:
            response = await self.llm_client.generate(
                prompt=user_prompt,
                system_prompt=system_prompt,
                temperature=0.1,  # Low temperature for consistent results
                max_tokens=500
            )

            if response.success and response.content:
                # Parse JSON response
                content = response.content.strip()
                # Remove markdown code blocks if present
                if content.startswith("```"):
                    content = content.split("```")[1]
                    if content.startswith("json"):
                        content = content[4:]
                    content = content.strip()
                if content.endswith("```"):
                    content = content[:-3].strip()

                try:
                    capabilities = json.loads(content)
                    if isinstance(capabilities, list):
                        # Filter to only valid capabilities
                        valid_caps = [c for c in capabilities if c in available_capabilities]
                        logger.info(f"LLM identified capabilities: {valid_caps}")
                        return valid_caps
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse LLM response as JSON: {e}")

        except Exception as e:
            logger.error(f"LLM capability identification failed: {e}")

        # Return None to signal failure (caller decides whether to fallback)
        logger.warning("LLM semantic analysis failed, returning None")
        return None

    def _calculate_complexity(
        self,
        query: str,
        capabilities: List[str],
        entities: Dict[str, List[str]]
    ) -> float:
        """
        Calculate query complexity score (0-1)

        Uses EnhancedComplexityCalculator if available (Paper1 formula):
        C(q) = α·L(q) + β·D(q) + γ·N(q) + δ·U(q)

        Fallback to simple heuristic calculation if not available.
        """

        # Try enhanced complexity calculator first (Paper1 methodology)
        if ENHANCED_COMPLEXITY_AVAILABLE:
            try:
                calculator = get_complexity_calculator()
                context = {
                    'capabilities': capabilities,
                    'entities': entities
                }
                breakdown = calculator.calculate(query, context)
                logger.info(f"Enhanced complexity: L={breakdown.linguistic:.2f}, D={breakdown.domain:.2f}, "
                           f"N={breakdown.novelty:.2f}, U={breakdown.uncertainty:.2f} → Total={breakdown.total:.2f}")
                return breakdown.total
            except Exception as e:
                logger.warning(f"Enhanced complexity calculation failed, falling back to basic: {e}")

        # Fallback: Basic complexity calculation
        complexity = 0.0

        # Base complexity from query length
        words = len(query.split())
        if words > 50:
            complexity += 0.3
        elif words > 20:
            complexity += 0.2
        else:
            complexity += 0.1

        # Complexity from number of capabilities
        cap_count = len(capabilities)
        if cap_count > 5:
            complexity += 0.3
        elif cap_count > 3:
            complexity += 0.2
        else:
            complexity += 0.1

        # Complexity from operations
        op_count = len(entities.get("operations", []))
        if op_count > 4:
            complexity += 0.2
        elif op_count > 2:
            complexity += 0.1

        # Complexity from data sources
        source_count = len(entities.get("data_sources", []))
        if source_count > 2:
            complexity += 0.2
        elif source_count > 1:
            complexity += 0.1

        # Cap at 1.0
        return min(complexity, 1.0)
    
    def identify_required_functions(
        self,
        analysis: QueryAnalysis,
        explicit_business_rules: Optional[str] = None,
        input_schema: Optional[Dict[str, str]] = None
    ) -> List[FunctionSpec]:
        """Identify required functions based on analysis

        Args:
            analysis: QueryAnalysis result
            explicit_business_rules: Optional string containing explicit business rules
                                     (e.g., "base_probability = 0.10\nprobability += factor * 0.15")
            input_schema: Optional dict of expected input field names and types
                         (e.g., {"months_inactive": "int", "usage_decline_pct": "float"})

        Returns:
            List of FunctionSpec objects with business_rules populated
        """

        functions = []

        logger.info(f"Identifying functions for capabilities: {analysis.required_capabilities}")

        # 🎯 Determine business rules to use
        # Priority: explicit_business_rules > original_query
        business_rules_to_use = explicit_business_rules if explicit_business_rules else analysis.original_query

        if explicit_business_rules:
            logger.info(f"📋 Using explicit business rules:\n{explicit_business_rules[:200]}...")
        else:
            logger.info("📝 Using original query as business rules (no explicit rules provided)")

        # 🎯 Multi-step workflow detection: if the query explicitly lists N steps/stages,
        # create one FunctionSpec per step instead of mapping to generic capabilities.
        workflow_steps = self._extract_workflow_steps(analysis.original_query)
        if workflow_steps and len(workflow_steps) >= 3:
            logger.info(f"🔗 Detected {len(workflow_steps)}-step workflow, creating per-step functions")
            inputs_to_use = input_schema if input_schema else {"data": "Dict[str, Any]"}
            total_steps = len(workflow_steps)
            for i, step_name in enumerate(workflow_steps):
                func_name = f"_{step_name.lower().replace(' ', '_').replace('-', '_')}"
                # Ensure valid Python identifier
                func_name = re.sub(r'[^a-z0-9_]', '', func_name)
                if not func_name.startswith('_'):
                    func_name = f"_{func_name}"

                # Build step-specific context so LLM knows exactly what to implement
                prev_step = workflow_steps[i-1] if i > 0 else None
                next_step = workflow_steps[i+1] if i < total_steps - 1 else None
                step_desc = f"Step {i+1}/{total_steps} in workflow: {step_name}"
                if prev_step:
                    step_desc += f". Receives output from previous step '{prev_step}'"
                if next_step:
                    step_desc += f". Passes result to next step '{next_step}'"

                # Step-specific business rules instead of entire query
                step_rules = (
                    f"This is step {i+1} of {total_steps} in this workflow: "
                    f"{', '.join(workflow_steps)}.\n"
                    f"Implement ONLY the '{step_name}' step.\n"
                    f"Input: data dict from {'user input' if i == 0 else f'previous step ({prev_step})'}.\n"
                    f"Output: dict with results for this step."
                )

                functions.append(FunctionSpec(
                    name=func_name,
                    category="workflow_step",
                    inputs=inputs_to_use,
                    outputs=["result"],
                    description=step_desc,
                    template_id=None,
                    customizations=None,
                    business_rules=step_rules
                ))
            logger.info(f"Created {len(functions)} workflow step functions: {[f.name for f in functions]}")
            return functions

        # Map capabilities to function specifications
        capability_function_map = {
            "csv_processing": FunctionSpec(
                name="_load_csv_data",
                category="data_io",
                inputs={"file_path": "str", "options": "Optional[Dict]"},
                outputs=["dataframe", "metadata"],
                description="Load and process CSV data",
                template_id="csv_reader"
            ),
            "json_handling": FunctionSpec(
                name="_parse_json_data",
                category="data_io",
                inputs={"source": "Union[str, Dict]", "schema": "Optional[Dict]"},
                outputs=["parsed_data", "metadata"],
                description="Parse JSON data",
                template_id="json_parser"
            ),
            "statistical_analysis": FunctionSpec(
                name="_perform_statistical_analysis",
                category="analysis",
                inputs={"data": "pd.DataFrame", "columns": "Optional[List[str]]"},
                outputs=["statistics", "insights"],
                description="Perform statistical analysis",
                template_id="statistical_analysis"
            ),
            "text_processing": FunctionSpec(
                name="_classify_text",
                category="ml_ai",
                inputs={"texts": "List[str]", "model_type": "str"},
                outputs=["predictions", "confidence_scores"],
                description="Classify text data",
                template_id="text_classification"
            ),
            "data_visualization": FunctionSpec(
                name="_generate_charts",
                category="visualization",
                inputs={"data": "pd.DataFrame", "chart_type": "str"},
                outputs=["chart_html", "metadata"],
                description="Generate data visualizations",
                template_id="chart_generator"
            ),
            "email_notifications": FunctionSpec(
                name="_send_email_notification",
                category="integration",
                inputs={"recipient": "str", "subject": "str", "body": "str"},
                outputs=["status", "message_id"],
                description="Send email notifications",
                template_id="email_sender"
            ),
            "web_integration": FunctionSpec(
                name="_call_webhook",
                category="integration",
                inputs={"url": "str", "payload": "Dict", "method": "str"},
                outputs=["response", "status_code"],
                description="Call external webhook",
                template_id="webhook_caller"
            ),
            "data_cleaning": FunctionSpec(
                name="_clean_data",
                category="transformation",
                inputs={"data": "pd.DataFrame", "config": "Optional[Dict]"},
                outputs=["cleaned_data", "report"],
                description="Clean and preprocess data",
                template_id="data_cleaner"
            ),
            "data_aggregation": FunctionSpec(
                name="_aggregate_data",
                category="transformation",
                inputs={"data": "pd.DataFrame", "group_by": "Optional[List[str]]"},
                outputs=["aggregated_data", "statistics"],
                description="Aggregate and summarize data",
                template_id="data_aggregator"
            ),
            # Business Analytics (for experiment tasks)
            "churn_prediction": FunctionSpec(
                name="_calculate_churn_probability",
                category="business_analytics",
                inputs={"customer_data": "Dict", "factors": "Optional[List[str]]"},
                outputs=["churn_probability", "risk_factors", "recommendations"],
                description="Calculate customer churn probability based on behavioral factors",
                template_id="churn_predictor"
            ),
            "customer_segmentation": FunctionSpec(
                name="_segment_customers",
                category="business_analytics",
                inputs={"customer_data": "pd.DataFrame", "criteria": "Optional[Dict]"},
                outputs=["segments", "segment_profiles", "recommendations"],
                description="Segment customers into distinct groups",
                template_id="customer_segmenter"
            ),
            "campaign_optimization": FunctionSpec(
                name="_optimize_campaign",
                category="business_analytics",
                inputs={"campaign_data": "Dict", "target_audience": "Optional[Dict]"},
                outputs=["optimized_campaign", "targeting_recommendations", "expected_roi"],
                description="Optimize marketing campaign targeting and messaging",
                template_id="campaign_optimizer"
            ),
            "customer_journey": FunctionSpec(
                name="_analyze_customer_journey",
                category="business_analytics",
                inputs={"journey_data": "List[Dict]", "customer_id": "Optional[str]"},
                outputs=["journey_analysis", "touchpoints", "optimization_opportunities"],
                description="Analyze customer journey and identify optimization opportunities",
                template_id="journey_analyzer"
            ),
            "retention_analysis": FunctionSpec(
                name="_analyze_retention",
                category="business_analytics",
                inputs={"customer_data": "pd.DataFrame", "time_period": "Optional[str]"},
                outputs=["retention_metrics", "at_risk_customers", "recommendations"],
                description="Analyze customer retention and identify at-risk customers",
                template_id="retention_analyzer"
            ),
            "scoring_model": FunctionSpec(
                name="_calculate_score",
                category="business_analytics",
                inputs={"data": "Dict", "scoring_criteria": "Optional[Dict]"},
                outputs=["score", "score_breakdown", "ranking"],
                description="Calculate scores based on multiple criteria",
                template_id="scoring_model"
            ),
            "probability_calculation": FunctionSpec(
                name="_calculate_probability",
                category="business_analytics",
                inputs={"factors": "Dict", "model_type": "Optional[str]"},
                outputs=["probability", "confidence", "contributing_factors"],
                description="Calculate probability based on input factors",
                template_id="probability_calculator"
            ),
            "factor_analysis": FunctionSpec(
                name="_analyze_factors",
                category="business_analytics",
                inputs={"data": "pd.DataFrame", "target_variable": "str"},
                outputs=["factor_importance", "correlations", "insights"],
                description="Analyze contributing factors and their importance",
                template_id="factor_analyzer"
            ),
            # Mathematical operations
            "arithmetic_operations": FunctionSpec(
                name="_perform_calculation",
                category="calculation",
                inputs={"operation": "str", "operands": "List[float]"},
                outputs=["result", "calculation_details"],
                description="Perform arithmetic calculations",
                template_id="calculator"
            ),
            "addition": FunctionSpec(
                name="_add_numbers",
                category="calculation",
                inputs={"a": "float", "b": "float"},
                outputs=["sum"],
                description="Add two numbers",
                template_id="addition"
            ),
            "subtraction": FunctionSpec(
                name="_subtract_numbers",
                category="calculation",
                inputs={"a": "float", "b": "float"},
                outputs=["difference"],
                description="Subtract two numbers",
                template_id="subtraction"
            ),
            "multiplication": FunctionSpec(
                name="_multiply_numbers",
                category="calculation",
                inputs={"a": "float", "b": "float"},
                outputs=["product"],
                description="Multiply two numbers",
                template_id="multiplication"
            ),
            "division": FunctionSpec(
                name="_divide_numbers",
                category="calculation",
                inputs={"a": "float", "b": "float"},
                outputs=["quotient"],
                description="Divide two numbers",
                template_id="division"
            ),
            # Weather analysis
            "weather_analysis": FunctionSpec(
                name="_analyze_weather_data",
                category="analysis",
                inputs={"weather_data": "Dict", "location": "Optional[str]"},
                outputs=["analysis", "insights"],
                description="Analyze weather data",
                template_id="weather_analyzer"
            ),
            "temperature_processing": FunctionSpec(
                name="_process_temperature",
                category="analysis",
                inputs={"temp_data": "List[float]", "unit": "str"},
                outputs=["processed_temp", "statistics"],
                description="Process temperature data",
                template_id="temperature_processor"
            ),
            "humidity_analysis": FunctionSpec(
                name="_analyze_humidity",
                category="analysis",
                inputs={"humidity_data": "List[float]"},
                outputs=["analysis", "comfort_level"],
                description="Analyze humidity levels",
                template_id="humidity_analyzer"
            ),
            "weather_prediction": FunctionSpec(
                name="_predict_weather",
                category="prediction",
                inputs={"historical_data": "pd.DataFrame", "days_ahead": "int"},
                outputs=["forecast", "confidence"],
                description="Predict future weather",
                template_id="weather_predictor"
            ),
            # Computer Vision functions
            "computer_vision": FunctionSpec(
                name="_process_vision",
                category="vision",
                inputs={"media": "Union[Image, Video]", "config": "Optional[Dict]"},
                outputs=["processed_data", "metadata"],
                description="Process image or video data",
                template_id=None
            ),
            "object_detection": FunctionSpec(
                name="_detect_objects",
                category="vision",
                inputs={"image": "np.ndarray", "confidence_threshold": "float"},
                outputs=["detections", "bounding_boxes", "confidences"],
                description="Detect objects in images",
                template_id=None
            ),
            "face_recognition": FunctionSpec(
                name="_recognize_faces",
                category="vision",
                inputs={"image": "np.ndarray", "known_faces": "Optional[List]"},
                outputs=["faces", "identities", "locations"],
                description="Recognize faces in images",
                template_id=None
            ),
            "ocr": FunctionSpec(
                name="_extract_text",
                category="vision",
                inputs={"image": "np.ndarray", "language": "str"},
                outputs=["text", "boxes", "confidence"],
                description="Extract text from images using OCR",
                template_id=None
            ),
            "image_quality": FunctionSpec(
                name="_assess_quality",
                category="vision",
                inputs={"image": "np.ndarray"},
                outputs=["quality_score", "metrics", "recommendations"],
                description="Assess image quality",
                template_id=None
            ),
            "visualization": FunctionSpec(
                name="_visualize_results",
                category="vision",
                inputs={"image": "np.ndarray", "results": "Dict"},
                outputs=["annotated_image", "summary"],
                description="Visualize detection results with bounding boxes",
                template_id=None
            ),
            "batch_processing": FunctionSpec(
                name="_process_batch",
                category="processing",
                inputs={"items": "List[Any]", "function": "Callable"},
                outputs=["results", "statistics"],
                description="Process multiple items in batch",
                template_id=None
            ),
            "api_integration": FunctionSpec(
                name="_integrate_api",
                category="integration",
                inputs={"endpoint": "str", "data": "Dict", "method": "str"},
                outputs=["response", "status"],
                description="Integrate with external APIs",
                template_id=None
            ),
            # Privacy and Security functions (NEW)
            "privacy_compliance": FunctionSpec(
                name="_assess_privacy_compliance",
                category="privacy",
                inputs={"system": "str", "standards": "List[str]"},
                outputs=["compliance_status", "violations", "recommendations"],
                description="Assess privacy compliance against standards",
                template_id="privacy_compliance_checker"
            ),
            "privacy_scanning": FunctionSpec(
                name="_scan_for_personal_data",
                category="privacy",
                inputs={"source": "Union[str, Dict]", "scan_type": "str"},
                outputs=["personal_data_found", "locations", "data_types"],
                description="Scan website or database for personal data",
                template_id="privacy_scanner"
            ),
            "gdpr_compliance": FunctionSpec(
                name="_check_gdpr_compliance",
                category="privacy",
                inputs={"data_processing": "Dict", "policies": "Dict"},
                outputs=["gdpr_status", "requirements", "gaps"],
                description="Check GDPR compliance requirements",
                template_id="gdpr_checker"
            ),
            "ccpa_compliance": FunctionSpec(
                name="_check_ccpa_compliance",
                category="privacy",
                inputs={"data_collection": "Dict", "user_rights": "Dict"},
                outputs=["ccpa_status", "requirements", "gaps"],
                description="Check CCPA compliance requirements",
                template_id="ccpa_checker"
            ),
            "privacy_policy": FunctionSpec(
                name="_analyze_privacy_policy",
                category="privacy",
                inputs={"policy_text": "str", "requirements": "List[str]"},
                outputs=["analysis", "missing_elements", "suggestions"],
                description="Analyze privacy policy document",
                template_id="privacy_policy_analyzer"
            ),
            "compliance_report": FunctionSpec(
                name="_generate_compliance_report",
                category="privacy",
                inputs={"scan_results": "Dict", "standards": "List[str]"},
                outputs=["report", "summary", "action_items"],
                description="Generate privacy compliance report",
                template_id="compliance_report_generator"
            ),
            "data_discovery": FunctionSpec(
                name="_discover_personal_data",
                category="privacy",
                inputs={"database": "str", "patterns": "List[str]"},
                outputs=["discovered_data", "data_map", "classification"],
                description="Discover and classify personal data",
                template_id="data_discovery"
            ),
            "privacy_recommendations": FunctionSpec(
                name="_generate_privacy_improvements",
                category="privacy",
                inputs={"current_state": "Dict", "target_standards": "List[str]"},
                outputs=["recommendations", "priority", "implementation_plan"],
                description="Generate privacy improvement recommendations",
                template_id="privacy_recommender"
            ),
            # Social Media and Listening functions (NEW)
            "social_monitoring": FunctionSpec(
                name="_monitor_social_media",
                category="social",
                inputs={"platforms": "List[str]", "keywords": "List[str]", "options": "Optional[Dict]"},
                outputs=["posts", "mentions", "metadata"],
                description="Monitor social media platforms for keywords and mentions",
                template_id="social_monitor"
            ),
            "brand_monitoring": FunctionSpec(
                name="_track_brand_mentions",
                category="social",
                inputs={"brand_name": "str", "platforms": "List[str]", "period": "str"},
                outputs=["mentions", "reach", "sentiment"],
                description="Track brand mentions across social platforms",
                template_id="brand_tracker"
            ),
            "social_sentiment": FunctionSpec(
                name="_analyze_sentiment",
                category="analysis",
                inputs={"texts": "List[str]", "context": "Optional[str]"},
                outputs=["sentiment_scores", "overall_sentiment", "emotions"],
                description="Analyze sentiment of social media posts",
                template_id="sentiment_analyzer"
            ),
            "influence_measurement": FunctionSpec(
                name="_measure_influence",
                category="social",
                inputs={"user_data": "Dict", "metrics": "List[str]"},
                outputs=["influence_score", "reach", "engagement_rate"],
                description="Measure social media influence and reach",
                template_id="influence_calculator"
            ),
            "crisis_detection": FunctionSpec(
                name="_detect_crisis",
                category="social",
                inputs={"posts": "List[Dict]", "thresholds": "Dict"},
                outputs=["crisis_level", "alerts", "recommendations"],
                description="Detect potential crisis situations from social media",
                template_id="crisis_detector"
            ),
            "competitor_tracking": FunctionSpec(
                name="_track_competitors",
                category="social",
                inputs={"competitors": "List[str]", "metrics": "List[str]"},
                outputs=["competitor_data", "comparison", "insights"],
                description="Track competitor activity and performance",
                template_id="competitor_analyzer"
            ),
            "trend_analysis": FunctionSpec(
                name="_analyze_trends",
                category="analysis",
                inputs={"data": "pd.DataFrame", "time_period": "str"},
                outputs=["trends", "predictions", "insights"],
                description="Analyze and predict social media trends",
                template_id="trend_analyzer"
            ),
            "social_analytics": FunctionSpec(
                name="_generate_analytics",
                category="social",
                inputs={"data": "Dict", "report_type": "str"},
                outputs=["analytics", "visualizations", "report"],
                description="Generate social media analytics and reports",
                template_id="social_reporter"
            ),
            "real_time_monitoring": FunctionSpec(
                name="_monitor_realtime",
                category="social",
                inputs={"stream_config": "Dict", "callback": "Optional[Callable]"},
                outputs=["stream", "events", "statistics"],
                description="Real-time social media monitoring",
                template_id=None
            ),
            # Stock and Financial Analysis functions (NEW)
            "stock_data_collection": FunctionSpec(
                name="_collect_stock_data",
                category="finance",
                inputs={"symbols": "List[str]", "period": "str", "interval": "str"},
                outputs=["stock_data", "metadata"],
                description="Collect stock price data from market APIs",
                template_id="stock_data_collector"
            ),
            "moving_average": FunctionSpec(
                name="_calculate_moving_averages",
                category="finance",
                inputs={"price_data": "pd.DataFrame", "windows": "List[int]"},
                outputs=["ma_data", "signals"],
                description="Calculate simple and exponential moving averages",
                template_id="moving_average_calculator"
            ),
            "trading_signals": FunctionSpec(
                name="_analyze_trading_signals",
                category="finance",
                inputs={"price_data": "pd.DataFrame", "indicators": "Dict"},
                outputs=["signals", "recommendations", "confidence"],
                description="Analyze buy/sell trading signals based on technical indicators",
                template_id="trading_signal_analyzer"
            ),
            "portfolio_analysis": FunctionSpec(
                name="_analyze_portfolio",
                category="finance",
                inputs={"holdings": "List[Dict]", "market_data": "pd.DataFrame"},
                outputs=["portfolio_metrics", "allocation", "performance"],
                description="Analyze portfolio composition and performance",
                template_id="portfolio_analyzer"
            ),
            "risk_assessment": FunctionSpec(
                name="_assess_portfolio_risk",
                category="finance",
                inputs={"portfolio": "Dict", "historical_data": "pd.DataFrame"},
                outputs=["risk_metrics", "var", "recommendations"],
                description="Assess portfolio risk including VaR and volatility",
                template_id="risk_assessor"
            ),
            "investment_recommendation": FunctionSpec(
                name="_generate_investment_recommendations",
                category="finance",
                inputs={"analysis_results": "Dict", "risk_profile": "str"},
                outputs=["recommendations", "rationale", "action_items"],
                description="Generate investment recommendations based on analysis",
                template_id="investment_recommender"
            ),
            "technical_analysis": FunctionSpec(
                name="_perform_technical_analysis",
                category="finance",
                inputs={"price_data": "pd.DataFrame", "indicators": "List[str]"},
                outputs=["technical_indicators", "chart_patterns", "signals"],
                description="Perform technical analysis with various indicators",
                template_id="technical_analyzer"
            ),
            "fundamental_analysis": FunctionSpec(
                name="_perform_fundamental_analysis",
                category="finance",
                inputs={"company_data": "Dict", "financial_statements": "Dict"},
                outputs=["fundamental_metrics", "valuation", "rating"],
                description="Perform fundamental analysis of company financials",
                template_id="fundamental_analyzer"
            )
        }
        
        # Add functions based on capabilities - WITH explicit business rules
        for capability in analysis.required_capabilities:
            if capability in capability_function_map:
                base_spec = capability_function_map[capability]

                # 🎯 Derive context-specific function name from query
                # Instead of generic "_calculate_score", use "_calculate_order_discount" etc.
                func_name = self._derive_function_name(base_spec.name, analysis.original_query)
                func_desc = self._derive_description(base_spec.description, analysis.original_query)
                logger.info(f"  Found capability '{capability}': {base_spec.name} → {func_name}")

                # 🎯 Use input_schema if provided, otherwise use default inputs
                inputs_to_use = input_schema if input_schema else base_spec.inputs

                # Create new FunctionSpec with business_rules (explicit or original query)
                functions.append(FunctionSpec(
                    name=func_name,
                    category=base_spec.category,
                    inputs=inputs_to_use,
                    outputs=base_spec.outputs,
                    description=func_desc,
                    template_id=base_spec.template_id,
                    customizations=base_spec.customizations,
                    business_rules=business_rules_to_use  # 🎯 Use explicit rules if provided
                ))
            else:
                logger.warning(f"  No direct mapping for capability: {capability}")

        # Add custom functions for unmatched capabilities
        unmatched = set(analysis.required_capabilities) - set(capability_function_map.keys())
        for capability in unmatched:
            logger.info(f"  Creating custom function for unmatched capability: {capability}")

            # 🎯 Use input_schema if provided
            inputs_to_use = input_schema if input_schema else {"data": "Any"}

            functions.append(FunctionSpec(
                name=f"_handle_{capability.replace(' ', '_')}",
                category="custom",
                inputs=inputs_to_use,
                outputs=["result"],
                description=f"Handle {capability}",
                template_id=None,
                customizations={
                    "implementation": f"Custom implementation for {capability}"
                },
                business_rules=business_rules_to_use  # 🎯 Use explicit rules if provided
            ))
        
        logger.info(f"Identified {len(functions)} required functions")
        
        return functions
    
    def _derive_function_name(self, base_name: str, query: str) -> str:
        """Derive a context-specific function name from query.

        Instead of generic '_calculate_score', produce '_calculate_order_discount'
        based on what the query actually asks for.
        """
        # Only rename generic function names
        generic_names = {'_calculate_score', '_calculate_probability', '_analyze_factors',
                         '_perform_statistical_analysis', '_handle_database_operations',
                         '_integrate_api', '_parse_json_data', '_load_csv_data'}
        if base_name not in generic_names:
            return base_name

        # Extract key action+subject from query
        query_lower = query.lower()

        # Korean patterns: "X를 계산", "X 점수를 계산", "X를 분석"
        import re as _re
        # Try longer match first: "X Y를 계산" (e.g., "신용 리스크 점수를 계산")
        m = _re.search(r'([가-힣a-z_ ]{2,20})\s*(?:을|를)\s*(?:계산|분석|처리|평가|산출|판정|측정)', query_lower)
        if m:
            subject = m.group(1).strip()
            # Translate common Korean terms to English for function name
            kr_to_en = {
                '이탈 확률': 'churn_probability', '이탈': 'churn',
                '할인율': 'discount_rate', '할인': 'discount',
                '신용 리스크': 'credit_risk', '신용': 'credit_score', '리스크': 'risk',
                '우선순위': 'priority', '우선 순위': 'priority',
                '추천 점수': 'recommendation_score', '추천': 'recommendation',
                'bmi': 'bmi', '체질량': 'bmi',
                '대출': 'loan_evaluation', '재고': 'inventory', '주문': 'order',
                '세그먼트': 'segment', '분류': 'classification',
                '사기': 'fraud_detection', '이상 탐지': 'anomaly_detection',
                '성과': 'performance', '평가': 'evaluation',
                '가격': 'pricing', '견적': 'quote',
                '수요 예측': 'demand_forecast', '예측': 'forecast',
            }
            for kr, en in kr_to_en.items():
                if kr in subject:
                    return f"_calculate_{en}"

        # English patterns: "calculate X", "compute X", "evaluate X"
        m = _re.search(r'(?:calculate|compute|evaluate|assess|determine|predict)\s+([a-z_]+(?:\s+[a-z_]+)?)', query_lower)
        if m:
            subject = m.group(1).strip().replace(' ', '_')
            return f"_calculate_{subject}"

        return base_name

    def _derive_description(self, base_desc: str, query: str) -> str:
        """Make description more specific using query context."""
        # Append query summary to base description for LLM context
        short_query = query[:100].strip()
        if short_query and short_query not in base_desc:
            return f"{base_desc}. Context: {short_query}"
        return base_desc

    def _extract_workflow_steps(self, query: str) -> Optional[List[str]]:
        """Extract explicit workflow steps from query if present.

        Detects patterns like:
          - "8-step workflow: validate, authenticate, inventory, ..."
          - "3 stages: collect, analyze, report"
          - "steps: 1) validate 2) calculate 3) output"

        Returns list of step names or None if no explicit workflow detected.
        """
        query_lower = query.lower()

        # Pattern 1: "N-step" or "N step" or "N stages" followed by a colon and comma-separated list
        m = re.search(
            r'(\d+)[\s-]*(step|stage|phase|단계)\s*[^:]*:\s*(.+)',
            query_lower
        )
        if m:
            expected_count = int(m.group(1))
            steps_str = m.group(3)
            # Split on commas, "and", or numbered patterns
            steps = [s.strip().strip('.').strip() for s in re.split(r'[,;]\s*|\band\b', steps_str) if s.strip()]
            # Clean numbered prefixes like "1)" or "1."
            steps = [re.sub(r'^\d+[).]\s*', '', s).strip() for s in steps]
            steps = [s for s in steps if s and len(s) < 50]  # Filter garbage
            if len(steps) >= 3 and len(steps) >= expected_count * 0.5:
                return steps[:expected_count]

        # Pattern 2: Colon-separated step list without explicit count
        m = re.search(r'(?:workflow|pipeline|process|steps?)\s*:\s*(.+)', query_lower)
        if m:
            steps_str = m.group(1)
            steps = [s.strip().strip('.').strip() for s in re.split(r'[,;]\s*|\band\b', steps_str) if s.strip()]
            steps = [re.sub(r'^\d+[).]\s*', '', s).strip() for s in steps]
            steps = [s for s in steps if s and len(s) < 50]
            if len(steps) >= 3:
                return steps

        # Pattern 3: "including X, Y, Z" or "with X, Y, Z" (common in natural language queries)
        m = re.search(r'(?:including|with|containing|consists?\s+of)\s+(.+)', query_lower)
        if m:
            steps_str = m.group(1)
            steps = [s.strip().strip('.').strip() for s in re.split(r'[,;]\s*|\band\b', steps_str) if s.strip()]
            steps = [re.sub(r'^\d+[).]\s*', '', s).strip() for s in steps]
            steps = [s for s in steps if s and len(s) < 50]
            if len(steps) >= 3:
                return steps

        return None

    def _is_privacy_compliance_query(self, query: str) -> bool:
        """Check if query is related to privacy compliance"""
        
        privacy_indicators = [
            # Korean privacy terms
            "개인정보", "프라이버시", "개인정보보호", "정보보호",
            "컴플라이언스", "준수", "감사", "스캔", "점검",
            "처리방침", "보호법", "규정", "정책",
            
            # English privacy terms (specific to privacy, not generic words)
            "privacy", "personal data", "personal information", "pii",
            "gdpr", "ccpa", "data protection", "privacy policy",
            "privacy audit", "privacy scan", "privacy assessment", "privacy check",
            
            # Compliance standards
            "general data protection", "california consumer",
            "eu privacy", "data subject rights", "consent",
            "right to erasure", "data portability", "privacy by design",
            "opt-out", "sale of personal", "consumer rights"
        ]
        
        query_lower = query.lower()
        for indicator in privacy_indicators:
            if indicator in query_lower:
                logger.info(f"Privacy compliance query detected: '{indicator}' found")
                return True
        
        return False
    
    def _enhance_privacy_capabilities(self, capabilities: List[str], query: str) -> List[str]:
        """Enhance capabilities list with privacy-specific capabilities"""
        
        enhanced = capabilities.copy()
        query_lower = query.lower()
        
        # Add specific privacy capabilities based on query content
        privacy_mappings = {
            ("gdpr", "eu", "유럽"): ["gdpr_compliance", "privacy_compliance"],
            ("ccpa", "california", "캘리포니아"): ["ccpa_compliance", "privacy_compliance"],
            ("scan", "스캔", "검사"): ["privacy_scanning", "data_discovery"],
            ("policy", "처리방침", "정책"): ["privacy_policy"],
            ("report", "보고서", "리포트"): ["compliance_report"],
            ("recommend", "제안", "개선", "suggest"): ["privacy_recommendations"],
            ("discover", "파악", "발견", "identify"): ["data_discovery"],
            ("compliance", "준수", "컴플라이언스"): ["privacy_compliance"]
        }
        
        for keywords, caps in privacy_mappings.items():
            if any(kw in query_lower for kw in keywords):
                for cap in caps:
                    if cap not in enhanced:
                        logger.info(f"Adding privacy capability: {cap}")
                        enhanced.append(cap)
        
        # If privacy-related but no specific capabilities, add general privacy compliance
        if self._is_privacy_compliance_query(query) and not any("privacy" in c or "compliance" in c for c in enhanced):
            enhanced.append("privacy_compliance")
            logger.info("Adding general privacy_compliance capability")
        
        return enhanced