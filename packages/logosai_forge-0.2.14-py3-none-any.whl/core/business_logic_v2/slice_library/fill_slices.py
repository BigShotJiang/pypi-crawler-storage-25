#!/usr/bin/env python3
"""
Slice Filling Script — Generate actual code for all empty slices using LLM.

Uses gemini-2.5-flash-lite to fill 168 metadata-only slices with real async business logic.

Usage:
  python -m core.business_logic_v2.slice_library.fill_slices                # Fill all
  python -m core.business_logic_v2.slice_library.fill_slices --domain finance  # One domain
  python -m core.business_logic_v2.slice_library.fill_slices --dry-run         # Preview only
  python -m core.business_logic_v2.slice_library.fill_slices --max 10          # Limit count
"""

import os
import sys
import json
import asyncio
import ast
import functools
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

print = functools.partial(print, flush=True)

SCRIPT_DIR = Path(__file__).parent
FORGE_ROOT = SCRIPT_DIR.parent.parent.parent
sys.path.insert(0, str(FORGE_ROOT))

os.environ["GRPC_DNS_RESOLVER"] = "native"

OUTPUT_PATH = SCRIPT_DIR / "filled_slices.json"
MODEL_NAME = "gemini-2.5-flash-lite"


def build_prompt(slice_obj) -> str:
    """Build LLM prompt from slice metadata."""
    name = slice_obj.name
    desc = slice_obj.description or name
    keywords = slice_obj.keywords
    if isinstance(keywords, dict):
        kw_list = keywords.get('en', []) + keywords.get('ko', [])
    else:
        kw_list = keywords if isinstance(keywords, list) else []

    inputs_desc = []
    for p in getattr(slice_obj, 'inputs', []):
        inputs_desc.append(f"{p.name}: {p.param_type}")

    outputs_desc = []
    for p in getattr(slice_obj, 'outputs', []):
        outputs_desc.append(f"{p.name}: {p.param_type}")

    func_name = slice_obj.function_name or f"_{name.replace('.', '_').replace('-', '_')}"

    prompt = f"""Write ONLY a Python async function. Start with "async def" on the first line.
Do NOT include imports, class, or explanation. ONLY the function.

async def {func_name}(self, data: Dict[str, Any]) -> Dict[str, Any]:
    \"\"\"
    {desc}
    Keywords: {', '.join(kw_list[:8])}
    \"\"\"
    # Implementation:"""

    if inputs_desc:
        prompt += f"\n    # Inputs: {', '.join(inputs_desc)}"
    if outputs_desc:
        prompt += f"\n    # Outputs: {', '.join(outputs_desc)}"

    prompt += """

Rules: Use data.get() for inputs. Return dict. Real logic, not stubs. 10-40 lines. stdlib only. Handle edge cases."""
    return prompt


async def generate_one(model, slice_obj) -> Optional[str]:
    """Generate code for one slice."""
    prompt = build_prompt(slice_obj)
    func_name = slice_obj.function_name or f"_{slice_obj.name.replace('.', '_').replace('-', '_')}"

    try:
        loop = asyncio.get_event_loop()
        response = await asyncio.wait_for(
            loop.run_in_executor(None, lambda: model.generate_content(prompt)),
            timeout=30.0,
        )

        text = response.text if hasattr(response, 'text') else None
        if not text:
            return None

        code = text.strip()
        # Remove markdown fences
        if '```python' in code:
            code = code.split('```python')[1].split('```')[0].strip()
        elif '```' in code:
            code = code.split('```')[1].split('```')[0].strip()

        # Normalize indentation
        import textwrap

        if not code.startswith('async def'):
            # Body only — wrap in function signature
            body = textwrap.dedent(code)
            body_lines = body.split('\n')
            indented = '\n'.join(f'    {line}' if line.strip() else '' for line in body_lines)
            func_name_clean = func_name if func_name.startswith('_') else f'_{func_name}'
            code = f"async def {func_name_clean}(self, data: Dict[str, Any]) -> Dict[str, Any]:\n{indented}"

        # Dedent entire function to 0 base, then add 4-space class method indent
        code = textwrap.dedent(code)
        lines = code.split('\n')
        code = '\n'.join(f'    {line}' if line.strip() else '' for line in lines)

        # Validate syntax
        test_code = f"from typing import Dict, Any, List, Optional\nimport math\nclass _T:\n{code}\n"
        ast.parse(test_code)

        return code

    except asyncio.TimeoutError:
        print(f"       timeout")
        return None
    except SyntaxError as e:
        print(f"       syntax: {e}")
        return None
    except Exception as e:
        print(f"       error: {str(e)[:80]}")
        return None


async def fill_all_slices(domain_filter: str = None, dry_run: bool = False, max_slices: int = 0):
    """Fill empty slices with LLM-generated code."""
    from core.business_logic_v2.slice_library.library import SliceLibrary
    from core.business_logic_v2.slice_library.core_slices import create_core_slices
    from core.business_logic_v2.slice_library.common_slices import create_common_slices
    from core.business_logic_v2.slice_library.domain_slices import create_all_domain_slices

    lib = SliceLibrary()
    lib.register_many(create_core_slices())
    lib.register_many(create_common_slices())
    lib.register_many(create_all_domain_slices())

    # Find empty slices (no real async def code)
    empty_slices = []
    for name, s in lib._slices.items():
        ct = s.code_template or ''
        if 'async def' not in ct or 'return' not in ct:
            domain = name.split('.')[0]
            if domain_filter and domain != domain_filter:
                continue
            empty_slices.append((name, s))

    print(f"Empty slices: {len(empty_slices)}")
    if max_slices > 0:
        empty_slices = empty_slices[:max_slices]
        print(f"Limited to: {max_slices}")

    if dry_run:
        for name, s in empty_slices:
            print(f"  [DRY] {name} — {(s.description or '')[:60]}")
        return

    # Init Gemini
    import google.generativeai as genai
    genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
    model = genai.GenerativeModel(MODEL_NAME)
    print(f"Model: {MODEL_NAME}")

    results = {"filled": 0, "failed": 0, "slices": []}
    total = len(empty_slices)

    for i, (name, s) in enumerate(empty_slices):
        code = await generate_one(model, s)

        # Retry once on failure
        if not code:
            await asyncio.sleep(0.5)
            code = await generate_one(model, s)

        if code:
            results["filled"] += 1
            lines = len(code.strip().split('\n'))
            results["slices"].append({
                "name": name,
                "description": (s.description or '')[:100],
                "domain": name.split('.')[0],
                "code_template": code,
                "keywords": s.keywords if isinstance(s.keywords, list) else
                            (s.keywords.get('en', []) + s.keywords.get('ko', []))[:10],
                "function_name": s.function_name,
                "category": str(s.category.value) if hasattr(s.category, 'value') else str(s.category),
                "generated_at": datetime.now().isoformat(),
            })
            print(f"  [{i+1:3d}/{total}] ✅ {name:40s} ({lines} lines)")
        else:
            results["failed"] += 1
            print(f"  [{i+1:3d}/{total}] ❌ {name:40s}")

        # Rate limit: 1s pause every 10 calls
        if (i + 1) % 10 == 0:
            await asyncio.sleep(1)

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    print(f"\n=== Result ===")
    print(f"Filled: {results['filled']}/{total}")
    print(f"Failed: {results['failed']}/{total}")
    print(f"Saved: {OUTPUT_PATH}")


async def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--domain', type=str, default=None)
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--max', type=int, default=0)
    args = parser.parse_args()
    await fill_all_slices(domain_filter=args.domain, dry_run=args.dry_run, max_slices=args.max)


if __name__ == '__main__':
    asyncio.run(main())
