"""
Slice Library
=============
Function Slice 기반 비즈니스 로직 조합 라이브러리

Paper1 업데이트: 모놀리식 도메인 알고리즘 → Function Slice 조합 방식

구조:
- models.py: FunctionSlice, SliceCategory 등 데이터 모델
- library.py: SliceLibrary 싱글톤 클래스
- core_slices.py: Core Slices (4개, 모든 에이전트 필수)
- common_slices.py: Common Slices (40개, 다수 도메인 공유)
- domain_slices/: Domain-Specific Slices (80개)
  - customer_slices.py: Customer 도메인 (25개)
  - finance_slices.py: Finance 도메인 (30개)
  - ml_ai_slices.py: ML/AI 도메인 (25개)
- composition_engine.py: Slice Composition Engine
"""

from .models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceTestCase,
    SliceMetadata,
    SliceCompositionResult,
    SliceDict,
    KeywordIndex,
    DependencyGraph
)

from .library import (
    SliceLibrary,
    get_slice_library
)

from .core_slices import (
    create_core_slices,
    get_core_slice_ids
)

from .common_slices import (
    create_common_slices,
    create_data_loading_slices,
    create_data_processing_slices,
    create_statistical_slices,
    create_visualization_slices,
    create_utility_slices,
    get_common_slice_count
)

from .domain_slices import (
    create_all_domain_slices,
    create_domain_slices,
    get_domain_slice_count
)

from .composition_engine import (
    SemanticMatcher,
    DependencyResolver,
    DataFlowDesigner,
    CodeComposer,
    SliceCompositionEngine,
    MatchResult,
    DataFlowNode,
    CompositionPlan,
    compose_agent,
    preview_composition
)

# Self-Growing System (Paper2)
from .self_growing import (
    SelfGrowingSystem,
    SliceCoverageAnalyzer,
    TemplateRetriever,
    SliceGenerator,
    SliceValidator,
    QualityGate,
    CoverageGap,
    GenerationResult,
    ValidationResult,
    ValidationStage,
    create_self_growing_system
)


def initialize_library(include_common: bool = True, include_domain: bool = True) -> SliceLibrary:
    """
    슬라이스 라이브러리 초기화 및 Slices 등록

    Args:
        include_common: Common Slices 포함 여부
        include_domain: Domain-Specific Slices 포함 여부

    Returns:
        SliceLibrary: 초기화된 라이브러리 인스턴스

    Summary:
        - Core Slices: 4개 (필수)
        - Common Slices: 40개 (선택)
        - Domain Slices: 80개 (선택)
          - Customer: 25개
          - Finance: 30개
          - ML/AI: 25개
        - Total: 124개
    """
    library = get_slice_library()

    # Core Slices 등록 (4개 - 필수)
    core_slices = create_core_slices()
    library.register_many(core_slices)

    # Common Slices 등록 (40개)
    if include_common:
        common_slices = create_common_slices()
        library.register_many(common_slices)

    # Domain-Specific Slices 등록 (80개)
    if include_domain:
        domain_slices = create_all_domain_slices()
        library.register_many(domain_slices)

    return library


def get_library_statistics() -> dict:
    """
    라이브러리 통계 조회

    Returns:
        슬라이스 카운트 통계
    """
    return {
        "core": 4,
        "common": get_common_slice_count(),
        "domain": get_domain_slice_count(),
        "total": 4 + get_common_slice_count()["total"] + sum(get_domain_slice_count().values())
    }


__all__ = [
    # Models
    "FunctionSlice",
    "SliceCategory",
    "SliceDomain",
    "SliceParameter",
    "SliceTestCase",
    "SliceMetadata",
    "SliceCompositionResult",
    "SliceDict",
    "KeywordIndex",
    "DependencyGraph",

    # Library
    "SliceLibrary",
    "get_slice_library",
    "initialize_library",
    "get_library_statistics",

    # Core Slices
    "create_core_slices",
    "get_core_slice_ids",

    # Common Slices
    "create_common_slices",
    "create_data_loading_slices",
    "create_data_processing_slices",
    "create_statistical_slices",
    "create_visualization_slices",
    "create_utility_slices",
    "get_common_slice_count",

    # Domain Slices
    "create_all_domain_slices",
    "create_domain_slices",
    "get_domain_slice_count",

    # Composition Engine
    "SemanticMatcher",
    "DependencyResolver",
    "DataFlowDesigner",
    "CodeComposer",
    "SliceCompositionEngine",
    "MatchResult",
    "DataFlowNode",
    "CompositionPlan",
    "compose_agent",
    "preview_composition",

    # Self-Growing System (Paper2)
    "SelfGrowingSystem",
    "SliceCoverageAnalyzer",
    "TemplateRetriever",
    "SliceGenerator",
    "SliceValidator",
    "QualityGate",
    "CoverageGap",
    "GenerationResult",
    "ValidationResult",
    "ValidationStage",
    "create_self_growing_system",
]
