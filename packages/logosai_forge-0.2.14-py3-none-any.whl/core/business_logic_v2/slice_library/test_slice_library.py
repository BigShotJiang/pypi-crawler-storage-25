"""
Slice Library Integration Tests
===============================
Function Slice 라이브러리 통합 테스트

테스트 항목:
1. 라이브러리 초기화
2. 슬라이스 등록 및 조회
3. 쿼리 매칭
4. 의존성 해결
5. 코드 조합
"""

import sys
import os

# 프로젝트 루트 경로 추가
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))

from typing import List
import unittest


class TestSliceLibrary(unittest.TestCase):
    """SliceLibrary 기본 기능 테스트"""

    @classmethod
    def setUpClass(cls):
        """테스트 클래스 설정 - 한 번만 라이브러리 초기화"""
        from forge.core.business_logic_v2.slice_library import (
            initialize_library,
            get_slice_library,
            SliceLibrary
        )
        # 싱글톤 리셋
        SliceLibrary._instance = None
        cls.library = initialize_library(include_common=True, include_domain=True)

    def setUp(self):
        """테스트 설정"""
        self.library = self.__class__.library

    def test_library_initialization(self):
        """라이브러리 초기화 테스트"""
        self.assertIsNotNone(self.library)

        # 통계 확인
        stats = self.library.get_statistics()
        print(f"\n[Library Statistics]")
        print(f"  Total Slices: {stats['total_slices']}")
        print(f"  By Category: {stats['by_category']}")
        print(f"  By Domain: {stats['by_domain']}")

        # 최소 슬라이스 수 확인
        self.assertGreaterEqual(stats['total_slices'], 44)  # 4 core + 40 common

    def test_core_slices_registered(self):
        """Core 슬라이스 등록 테스트"""
        from forge.core.business_logic_v2.slice_library import get_core_slice_ids

        core_ids = get_core_slice_ids()
        self.assertEqual(len(core_ids), 4)

        for core_id in core_ids:
            slice_obj = self.library.get(core_id)
            self.assertIsNotNone(slice_obj, f"Core slice not found: {core_id}")
            print(f"  Core Slice: {core_id} - {slice_obj.name}")

    def test_common_slices_registered(self):
        """Common 슬라이스 등록 테스트"""
        from forge.core.business_logic_v2.slice_library import get_common_slice_count

        total_count = get_common_slice_count()
        print(f"\n[Common Slices Count]: {total_count}")

        self.assertEqual(total_count, 40)

    def test_domain_slices_registered(self):
        """Domain 슬라이스 등록 테스트"""
        from forge.core.business_logic_v2.slice_library import get_domain_slice_count

        counts = get_domain_slice_count()
        print(f"\n[Domain Slices Count]")
        for domain, count in counts.items():
            print(f"  {domain}: {count}")

        self.assertEqual(counts['customer'], 25)
        self.assertEqual(counts['finance'], 30)
        self.assertEqual(counts['ml_ai'], 25)

    def test_slice_search_by_keyword(self):
        """키워드 검색 테스트"""
        # 한국어 키워드 검색
        results = self.library.search_by_keywords(["고객", "세그멘테이션"])
        print(f"\n[Search '고객 세그멘테이션']")
        for slice_obj, score in results[:5]:
            print(f"  {slice_obj.id}: score={score:.2f}")
        self.assertGreater(len(results), 0)

        # 영어 키워드 검색
        results = self.library.search_by_keywords(["machine", "learning", "prediction"])
        print(f"\n[Search 'machine learning prediction']")
        for slice_obj, score in results[:5]:
            print(f"  {slice_obj.id}: score={score:.2f}")
        self.assertGreater(len(results), 0)

    def test_slice_get_by_id(self):
        """ID로 슬라이스 조회 테스트"""
        # Core slice (ID format: core.xxx)
        error_handling = self.library.get("core.error_handling")
        self.assertIsNotNone(error_handling)
        self.assertEqual(error_handling.name, "Error Handling")

        # Common slice (ID format: common.xxx.yyy)
        load_csv = self.library.get("common.data.load_csv")
        self.assertIsNotNone(load_csv)

        # Domain slice (ID format: domain.category.name)
        kmeans = self.library.get("customer.segment.kmeans")
        self.assertIsNotNone(kmeans)


class TestSemanticMatcher(unittest.TestCase):
    """SemanticMatcher 테스트"""

    @classmethod
    def setUpClass(cls):
        """테스트 클래스 설정"""
        from forge.core.business_logic_v2.slice_library import (
            get_slice_library,
            SemanticMatcher
        )
        cls.library = get_slice_library()  # 기존 싱글톤 사용
        cls.matcher = SemanticMatcher(cls.library)

    def setUp(self):
        """테스트 설정"""
        self.library = self.__class__.library
        self.matcher = self.__class__.matcher

    def test_query_matching_korean(self):
        """한국어 쿼리 매칭 테스트"""
        query = "고객 이탈 예측 모델을 만들어주세요"
        results = self.matcher.match_query(query, top_k=10)

        print(f"\n[Query: {query}]")
        for r in results:
            print(f"  {r.slice_id}: score={r.score:.2f}, keywords={r.matched_keywords}")

        self.assertGreater(len(results), 0)

    def test_query_matching_english(self):
        """영어 쿼리 매칭 테스트"""
        query = "Create a random forest classifier for customer segmentation"
        results = self.matcher.match_query(query, top_k=10)

        print(f"\n[Query: {query}]")
        for r in results:
            print(f"  {r.slice_id}: score={r.score:.2f}, keywords={r.matched_keywords}")

        self.assertGreater(len(results), 0)

    def test_domain_inference(self):
        """도메인 추론 테스트"""
        # Customer 도메인
        domains = self.matcher._infer_domains("고객 분석 및 세그멘테이션")
        print(f"\n[Domain Inference '고객 분석']")
        print(f"  Inferred: {domains}")
        from forge.core.business_logic_v2.slice_library import SliceDomain
        self.assertIn(SliceDomain.CUSTOMER, domains)

        # Finance 도메인
        domains = self.matcher._infer_domains("매출 예측 및 재무 분석")
        print(f"[Domain Inference '매출 예측']")
        print(f"  Inferred: {domains}")
        self.assertIn(SliceDomain.FINANCE, domains)

        # ML/AI 도메인
        domains = self.matcher._infer_domains("머신러닝 분류 모델 학습")
        print(f"[Domain Inference '머신러닝 분류']")
        print(f"  Inferred: {domains}")
        self.assertIn(SliceDomain.ML_AI, domains)

    def test_task_type_detection(self):
        """작업 유형 감지 테스트"""
        self.assertEqual(self.matcher.get_task_type("데이터 분석해줘"), "analysis")
        self.assertEqual(self.matcher.get_task_type("매출 예측 모델"), "prediction")
        self.assertEqual(self.matcher.get_task_type("고객 분류하기"), "classification")


class TestDependencyResolver(unittest.TestCase):
    """DependencyResolver 테스트"""

    @classmethod
    def setUpClass(cls):
        """테스트 클래스 설정"""
        from forge.core.business_logic_v2.slice_library import (
            get_slice_library,
            DependencyResolver
        )
        cls.library = get_slice_library()
        cls.resolver = DependencyResolver(cls.library)

    def setUp(self):
        """테스트 설정"""
        self.library = self.__class__.library
        self.resolver = self.__class__.resolver

    def test_dependency_resolution(self):
        """의존성 해결 테스트"""
        slice_ids = ["ml.model.classification_train", "ml.feature.scaling"]
        order, warnings = self.resolver.resolve(slice_ids)

        print(f"\n[Dependency Resolution]")
        print(f"  Input: {slice_ids}")
        print(f"  Output Order: {order}")
        print(f"  Warnings: {warnings}")

        # Core slices should be added
        self.assertGreater(len(order), 0)

    def test_core_slices_included(self):
        """Core 슬라이스 자동 포함 테스트"""
        from forge.core.business_logic_v2.slice_library import get_core_slice_ids

        slice_ids = ["common.data.load_csv"]
        order, _ = self.resolver.resolve(slice_ids, include_core=True)

        core_ids = get_core_slice_ids()
        print(f"\n[Core Slices Test]")
        print(f"  Core IDs: {core_ids}")
        print(f"  Order: {order}")
        for core_id in core_ids:
            self.assertIn(core_id, order, f"Core slice {core_id} should be included")


class TestSliceCompositionEngine(unittest.TestCase):
    """SliceCompositionEngine 통합 테스트"""

    @classmethod
    def setUpClass(cls):
        """테스트 클래스 설정"""
        from forge.core.business_logic_v2.slice_library import (
            get_slice_library,
            SliceCompositionEngine
        )
        cls.library = get_slice_library()
        cls.engine = SliceCompositionEngine(cls.library)

    def setUp(self):
        """테스트 설정"""
        self.library = self.__class__.library
        self.engine = self.__class__.engine

    def test_compose_from_query(self):
        """쿼리 기반 조합 테스트"""
        query = "고객 데이터를 분석하고 이탈 예측 모델을 만들어주세요"
        result = self.engine.compose_from_query(query, agent_name="CustomerChurnPredictor")

        print(f"\n[Compose from Query]")
        print(f"  Query: {query}")
        print(f"  Success: {result.success}")
        print(f"  Slice IDs: {result.slice_ids}")
        print(f"  Dependencies: {result.dependencies}")
        print(f"  Execution Time: {result.execution_time:.3f}s")

        if result.warnings:
            print(f"  Warnings: {result.warnings}")

        self.assertTrue(result.success)
        self.assertGreater(len(result.slice_ids), 0)
        # Note: Class name uses capitalize() which lowercases all but first letter
        self.assertIn("class CustomerchurnpredictorAgent", result.composed_code)

    def test_compose_finance_agent(self):
        """재무 분석 에이전트 조합 테스트"""
        query = "재무 리스크 분석 및 매출 예측"
        result = self.engine.compose_from_query(query, agent_name="FinanceAnalyzer")

        print(f"\n[Finance Agent Composition]")
        print(f"  Query: {query}")
        print(f"  Success: {result.success}")
        print(f"  Slice IDs: {result.slice_ids[:5]}...")

        self.assertTrue(result.success)

    def test_compose_ml_agent(self):
        """ML 에이전트 조합 테스트"""
        query = "Create a machine learning classification model with hyperparameter tuning"
        result = self.engine.compose_from_query(query, agent_name="MLClassifier")

        print(f"\n[ML Agent Composition]")
        print(f"  Query: {query}")
        print(f"  Success: {result.success}")
        print(f"  Slice IDs: {result.slice_ids[:5]}...")

        self.assertTrue(result.success)

    def test_composition_plan(self):
        """조합 계획 미리보기 테스트"""
        query = "고객 세그멘테이션 분석"
        plan = self.engine.get_composition_plan(query)

        print(f"\n[Composition Plan]")
        print(f"  Query: {query}")
        print(f"  Selected Slices: {plan.selected_slices}")
        print(f"  Execution Order: {plan.execution_order}")
        print(f"  Estimated Complexity: {plan.estimated_complexity:.2f}")

        self.assertGreater(len(plan.selected_slices), 0)
        self.assertGreater(len(plan.execution_order), 0)


class TestConvenienceFunctions(unittest.TestCase):
    """편의 함수 테스트"""

    @classmethod
    def setUpClass(cls):
        """테스트 클래스 설정 - 라이브러리가 이미 초기화되어 있음"""
        pass

    def setUp(self):
        """테스트 설정"""
        pass

    def test_compose_agent_function(self):
        """compose_agent 함수 테스트"""
        from forge.core.business_logic_v2.slice_library import compose_agent

        result = compose_agent("데이터 분석 에이전트", agent_name="DataAnalyzer")
        self.assertTrue(result.success)
        print(f"\n[compose_agent Result]")
        print(f"  Slices Used: {len(result.slice_ids)}")

    def test_preview_composition_function(self):
        """preview_composition 함수 테스트"""
        from forge.core.business_logic_v2.slice_library import preview_composition

        plan = preview_composition("매출 예측 및 분석")
        print(f"\n[preview_composition Result]")
        print(f"  Selected: {len(plan.selected_slices)}")
        print(f"  Execution Order: {len(plan.execution_order)}")


def run_all_tests():
    """모든 테스트 실행"""
    print("=" * 60)
    print("Function Slice Library - Integration Tests")
    print("=" * 60)

    # 테스트 스위트 생성
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # 테스트 클래스 추가
    suite.addTests(loader.loadTestsFromTestCase(TestSliceLibrary))
    suite.addTests(loader.loadTestsFromTestCase(TestSemanticMatcher))
    suite.addTests(loader.loadTestsFromTestCase(TestDependencyResolver))
    suite.addTests(loader.loadTestsFromTestCase(TestSliceCompositionEngine))
    suite.addTests(loader.loadTestsFromTestCase(TestConvenienceFunctions))

    # 테스트 실행
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    print(f"  Tests Run: {result.testsRun}")
    print(f"  Failures: {len(result.failures)}")
    print(f"  Errors: {len(result.errors)}")
    print(f"  Success: {result.wasSuccessful()}")

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
