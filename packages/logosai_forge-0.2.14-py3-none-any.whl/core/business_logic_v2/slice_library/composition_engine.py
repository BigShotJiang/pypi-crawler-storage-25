"""
Slice Composition Engine
========================
Function Slice 기반 비즈니스 로직 조합 엔진

Paper1 핵심 구현: Query → Slice Selection → Dependency Resolution → Code Composition

구성요소:
- SemanticMatcher: 쿼리와 슬라이스 시맨틱 매칭
- DependencyResolver: 슬라이스 의존성 해결 및 토폴로지 정렬
- DataFlowDesigner: 슬라이스 간 데이터 흐름 설계
- CodeComposer: 최종 에이전트 코드 조합
"""

from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field
from collections import defaultdict
import re

from .models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceCompositionResult,
    DependencyGraph
)
from .library import SliceLibrary, get_slice_library


# =============================================================================
# Data Classes for Composition
# =============================================================================

@dataclass
class MatchResult:
    """슬라이스 매칭 결과"""
    slice_id: str
    score: float
    matched_keywords: List[str]
    domain_match: bool = False
    category_match: bool = False


@dataclass
class DataFlowNode:
    """데이터 흐름 노드"""
    slice_id: str
    inputs: Dict[str, str]  # param_name -> source (slice_id.output or "input")
    outputs: Dict[str, str]  # param_name -> target (slice_id.input or "output")


@dataclass
class CompositionPlan:
    """조합 계획"""
    query: str
    selected_slices: List[str]
    execution_order: List[str]
    data_flow: List[DataFlowNode]
    estimated_complexity: float
    warnings: List[str] = field(default_factory=list)


# =============================================================================
# SemanticMatcher: Query-Slice Matching
# =============================================================================

class SemanticMatcher:
    """
    시맨틱 매처: 쿼리와 슬라이스 간 의미적 매칭

    매칭 방법:
    1. 키워드 매칭 (한국어/영어)
    2. 도메인 추론
    3. 작업 유형 분석
    """

    # 도메인 키워드 매핑
    DOMAIN_KEYWORDS = {
        SliceDomain.CUSTOMER: [
            "customer", "고객", "user", "사용자", "churn", "이탈", "segment", "세그먼트",
            "loyalty", "충성도", "retention", "유지", "acquisition", "획득", "clv", "ltv"
        ],
        SliceDomain.FINANCE: [
            "finance", "금융", "revenue", "매출", "profit", "수익", "cost", "비용",
            "budget", "예산", "cashflow", "현금흐름", "risk", "리스크", "roi", "투자"
        ],
        SliceDomain.ML_AI: [
            "ml", "머신러닝", "machine learning", "ai", "인공지능", "model", "모델",
            "predict", "예측", "classification", "분류", "regression", "회귀",
            "clustering", "클러스터링", "training", "학습", "feature", "피처"
        ],
        SliceDomain.ANALYTICS: [
            "analytics", "분석", "analysis", "data", "데이터", "report", "리포트",
            "dashboard", "대시보드", "metric", "지표", "kpi", "insight", "인사이트"
        ],
        SliceDomain.DATA_IO: [
            "load", "로드", "import", "가져오기", "export", "내보내기", "csv", "json",
            "excel", "database", "데이터베이스", "api", "file", "파일"
        ],
        # New domains for 82% coverage
        SliceDomain.INVENTORY: [
            "inventory", "재고", "stock", "재고관리", "warehouse", "창고", "supply", "공급",
            "chain", "공급망", "reorder", "발주", "eoq", "경제적주문량", "lead time", "리드타임",
            "safety stock", "안전재고", "demand", "수요", "forecast", "예측", "abc", "vendor", "공급업체"
        ],
        SliceDomain.HR: [
            "hr", "인사", "payroll", "급여", "salary", "월급", "overtime", "초과근무", "야근",
            "employee", "직원", "performance", "성과", "kpi", "attendance", "출근", "근태",
            "leave", "휴가", "연차", "bonus", "보너스", "성과급", "tax", "세금"
        ],
        SliceDomain.ORDER: [
            "order", "주문", "purchase", "구매", "discount", "할인", "shipping", "배송",
            "fulfillment", "이행", "tracking", "추적", "송장", "cart", "장바구니",
            "checkout", "결제", "quote", "견적", "price", "가격", "coupon", "쿠폰"
        ],
        SliceDomain.PROJECT: [
            "project", "프로젝트", "task", "태스크", "작업", "sprint", "스프린트", "agile", "애자일",
            "deadline", "마감", "milestone", "마일스톤", "resource", "리소스", "capacity", "용량",
            "velocity", "속도", "burndown", "번다운", "priority", "우선순위", "assign", "할당"
        ]
    }

    # 작업 유형 키워드
    TASK_KEYWORDS = {
        "analysis": ["analyze", "분석", "investigate", "조사", "examine", "검토"],
        "prediction": ["predict", "예측", "forecast", "전망", "estimate", "추정"],
        "classification": ["classify", "분류", "categorize", "카테고리", "segment"],
        "visualization": ["visualize", "시각화", "chart", "차트", "graph", "그래프"],
        "processing": ["process", "처리", "transform", "변환", "clean", "정제"],
        "calculation": ["calculate", "계산", "compute", "산출", "measure", "측정"]
    }

    def __init__(self, library: Optional[SliceLibrary] = None):
        self.library = library or get_slice_library()
        self._keyword_index = self._build_keyword_index()

    def _get_all_keywords(self, slice_obj: FunctionSlice) -> List[str]:
        """슬라이스에서 모든 키워드 추출 (두 형식 지원)"""
        keywords = slice_obj.keywords
        if isinstance(keywords, list):
            return keywords
        elif isinstance(keywords, dict):
            all_kw = []
            all_kw.extend(keywords.get("ko", []))
            all_kw.extend(keywords.get("en", []))
            return all_kw
        return []

    def _build_keyword_index(self) -> Dict[str, List[str]]:
        """키워드 → 슬라이스 ID 인덱스 구축"""
        index = defaultdict(list)
        for slice_obj in self.library._slices.values():
            all_keywords = self._get_all_keywords(slice_obj)
            for keyword in all_keywords:
                # 키워드 정규화 (소문자, 공백 제거)
                normalized = keyword.lower().strip()
                index[normalized].append(slice_obj.id)
        return dict(index)

    def match_query(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.1,
        required_domains: Optional[List[SliceDomain]] = None
    ) -> List[MatchResult]:
        """
        쿼리와 슬라이스 매칭

        Args:
            query: 사용자 쿼리
            top_k: 상위 K개 결과
            min_score: 최소 점수 임계값
            required_domains: 필수 도메인 (지정 시 해당 도메인만 검색)

        Returns:
            매칭된 슬라이스 목록 (점수 내림차순)
        """
        query_lower = query.lower()
        query_tokens = self._tokenize(query_lower)

        # 도메인 추론
        inferred_domains = self._infer_domains(query_lower)
        if required_domains:
            inferred_domains = set(required_domains) & inferred_domains if inferred_domains else set(required_domains)

        results = []

        for slice_id, slice_obj in self.library._slices.items():
            score = 0.0
            matched_keywords = []

            # 1. 키워드 매칭 (가장 중요)
            all_keywords = self._get_all_keywords(slice_obj)
            for keyword in all_keywords:
                keyword_lower = keyword.lower()
                if keyword_lower in query_lower:
                    score += 1.0
                    matched_keywords.append(keyword)
                else:
                    # 부분 매칭
                    for token in query_tokens:
                        if token in keyword_lower or keyword_lower in token:
                            score += 0.5
                            matched_keywords.append(keyword)
                            break

            # 2. 도메인 매칭 보너스
            domain_match = False
            if inferred_domains and slice_obj.domain in inferred_domains:
                score += 0.5
                domain_match = True

            # 3. 카테고리 가중치 (Core > Common > Domain)
            category_match = slice_obj.category == SliceCategory.CORE
            if category_match:
                score += 0.3

            # 4. 정규화
            if all_keywords:
                score = score / len(all_keywords)

            if score >= min_score:
                results.append(MatchResult(
                    slice_id=slice_id,
                    score=score,
                    matched_keywords=list(set(matched_keywords)),
                    domain_match=domain_match,
                    category_match=category_match
                ))

        # 점수순 정렬 후 상위 K개
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]

    def _tokenize(self, text: str) -> List[str]:
        """텍스트 토큰화 (한국어/영어 지원)"""
        # 특수문자 제거 및 공백 분리
        tokens = re.split(r'[\s,;.!?]+', text)
        # 빈 문자열 제거 및 2글자 이상만
        return [t for t in tokens if len(t) >= 2]

    def _infer_domains(self, query: str) -> Set[SliceDomain]:
        """쿼리에서 도메인 추론"""
        domains = set()
        for domain, keywords in self.DOMAIN_KEYWORDS.items():
            for keyword in keywords:
                if keyword in query:
                    domains.add(domain)
                    break
        return domains

    def get_task_type(self, query: str) -> Optional[str]:
        """쿼리에서 작업 유형 추론"""
        query_lower = query.lower()
        for task_type, keywords in self.TASK_KEYWORDS.items():
            for keyword in keywords:
                if keyword in query_lower:
                    return task_type
        return None


# =============================================================================
# DependencyResolver: Slice Dependency Resolution
# =============================================================================

class DependencyResolver:
    """
    의존성 해결기: 슬라이스 간 의존성 분석 및 실행 순서 결정

    기능:
    1. 의존성 그래프 구축
    2. 순환 의존성 감지
    3. 토폴로지 정렬로 실행 순서 결정
    4. 누락된 의존성 자동 추가
    """

    def __init__(self, library: Optional[SliceLibrary] = None):
        self.library = library or get_slice_library()

    def resolve(
        self,
        slice_ids: List[str],
        include_core: bool = True,
        auto_add_missing: bool = True
    ) -> Tuple[List[str], List[str]]:
        """
        슬라이스 의존성 해결

        Args:
            slice_ids: 선택된 슬라이스 ID 목록
            include_core: Core 슬라이스 자동 포함
            auto_add_missing: 누락된 의존성 자동 추가

        Returns:
            (실행 순서 목록, 경고 메시지 목록)
        """
        warnings = []
        required_slices = set(slice_ids)

        # 1. Core 슬라이스 추가
        if include_core:
            core_ids = self.library.get_core_slice_ids()
            required_slices.update(core_ids)

        # 2. 의존성 해결 (재귀적)
        if auto_add_missing:
            all_deps = self._collect_all_dependencies(list(required_slices))
            missing = all_deps - required_slices
            if missing:
                warnings.append(f"Auto-added missing dependencies: {missing}")
                required_slices.update(missing)

        # 3. 의존성 그래프 구축
        graph = self._build_dependency_graph(list(required_slices))

        # 4. 순환 의존성 감지
        cycles = self._detect_cycles(graph)
        if cycles:
            warnings.append(f"Circular dependencies detected: {cycles}")

        # 5. 토폴로지 정렬
        execution_order = self._topological_sort(graph, list(required_slices))

        return execution_order, warnings

    def _collect_all_dependencies(self, slice_ids: List[str]) -> Set[str]:
        """모든 의존성 재귀 수집"""
        all_deps = set(slice_ids)
        queue = list(slice_ids)

        while queue:
            current = queue.pop(0)
            slice_obj = self.library.get(current)
            if slice_obj and slice_obj.dependencies:
                for dep in slice_obj.dependencies:
                    if dep not in all_deps and self.library.get(dep):
                        all_deps.add(dep)
                        queue.append(dep)

        return all_deps

    def _build_dependency_graph(self, slice_ids: List[str]) -> Dict[str, List[str]]:
        """의존성 그래프 구축"""
        graph = defaultdict(list)
        for slice_id in slice_ids:
            slice_obj = self.library.get(slice_id)
            if slice_obj:
                for dep in slice_obj.dependencies:
                    if dep in slice_ids:
                        graph[slice_id].append(dep)
        return dict(graph)

    def _detect_cycles(self, graph: Dict[str, List[str]]) -> List[List[str]]:
        """순환 의존성 감지 (DFS 기반)"""
        cycles = []
        visited = set()
        rec_stack = set()
        path = []

        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    # 순환 발견
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:])
                    return True

            path.pop()
            rec_stack.remove(node)
            return False

        for node in graph:
            if node not in visited:
                dfs(node)

        return cycles

    def _topological_sort(self, graph: Dict[str, List[str]], slice_ids: List[str]) -> List[str]:
        """토폴로지 정렬 (Kahn's Algorithm)"""
        # 진입 차수 계산
        in_degree = defaultdict(int)
        for node in slice_ids:
            if node not in in_degree:
                in_degree[node] = 0

        for node, deps in graph.items():
            for dep in deps:
                in_degree[node] += 1

        # 진입 차수가 0인 노드부터 시작
        queue = [node for node in slice_ids if in_degree[node] == 0]
        result = []

        while queue:
            # 안정적인 정렬을 위해 알파벳순 정렬
            queue.sort()
            node = queue.pop(0)
            result.append(node)

            # 이 노드에 의존하는 노드들의 진입 차수 감소
            for other in slice_ids:
                if node in graph.get(other, []):
                    in_degree[other] -= 1
                    if in_degree[other] == 0 and other not in result:
                        queue.append(other)

        # 순환이 있으면 일부 노드가 누락될 수 있음
        for node in slice_ids:
            if node not in result:
                result.append(node)

        return result


# =============================================================================
# DataFlowDesigner: Data Flow Design
# =============================================================================

class DataFlowDesigner:
    """
    데이터 흐름 설계자: 슬라이스 간 데이터 연결 설계

    기능:
    1. 입출력 호환성 분석
    2. 데이터 파이프라인 설계
    3. 변수명 매핑
    """

    def __init__(self, library: Optional[SliceLibrary] = None):
        self.library = library or get_slice_library()

    def design_flow(
        self,
        execution_order: List[str],
        initial_inputs: Optional[Dict[str, str]] = None
    ) -> List[DataFlowNode]:
        """
        데이터 흐름 설계

        Args:
            execution_order: 슬라이스 실행 순서
            initial_inputs: 초기 입력 변수 매핑

        Returns:
            데이터 흐름 노드 목록
        """
        initial_inputs = initial_inputs or {}
        flow_nodes = []
        available_outputs: Dict[str, str] = {}  # output_name -> source_slice_id

        for slice_id in execution_order:
            slice_obj = self.library.get(slice_id)
            if not slice_obj:
                continue

            node = DataFlowNode(
                slice_id=slice_id,
                inputs={},
                outputs={}
            )

            # 입력 매핑
            for param in slice_obj.inputs:
                if param.name in initial_inputs:
                    node.inputs[param.name] = f"input.{initial_inputs[param.name]}"
                elif param.name in available_outputs:
                    source = available_outputs[param.name]
                    node.inputs[param.name] = f"{source}.{param.name}"
                elif not param.required:
                    node.inputs[param.name] = "default"
                else:
                    # 타입 기반 매칭 시도
                    matched = self._find_compatible_output(param.param_type, available_outputs)
                    if matched:
                        node.inputs[param.name] = matched
                    else:
                        node.inputs[param.name] = "missing"

            # 출력 등록
            for param in slice_obj.outputs:
                available_outputs[param.name] = slice_id
                node.outputs[param.name] = f"output.{param.name}"

            flow_nodes.append(node)

        return flow_nodes

    def _find_compatible_output(
        self,
        required_type: str,
        available: Dict[str, str]
    ) -> Optional[str]:
        """타입 호환 가능한 출력 찾기"""
        type_aliases = {
            "pd.DataFrame": ["DataFrame", "data", "df"],
            "np.ndarray": ["array", "ndarray", "data"],
            "List": ["list", "items", "results"],
            "Dict": ["dict", "mapping", "result"]
        }

        base_type = required_type.split("[")[0]
        aliases = type_aliases.get(base_type, [base_type.lower()])

        for output_name, source in available.items():
            if any(alias in output_name.lower() for alias in aliases):
                return f"{source}.{output_name}"

        return None

    def validate_flow(self, flow_nodes: List[DataFlowNode]) -> List[str]:
        """데이터 흐름 유효성 검증"""
        issues = []

        for node in flow_nodes:
            for param_name, source in node.inputs.items():
                if source == "missing":
                    issues.append(f"Missing input '{param_name}' for slice '{node.slice_id}'")

        return issues


# =============================================================================
# CodeComposer: Final Code Composition
# =============================================================================

class CodeComposer:
    """
    코드 조합기: 슬라이스들을 최종 에이전트 코드로 조합

    기능:
    1. Import 구문 생성
    2. 함수 코드 조합
    3. 메인 실행 로직 생성
    4. LogosAI 에이전트 클래스 래핑
    """

    STANDARD_IMPORTS = """
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
"""

    AGENT_TEMPLATE = '''
from logosai import LogosAIAgent
from logosai.config import AgentConfig
from logosai.agent_types import AgentType, AgentResponse, AgentResponseType

class {class_name}(LogosAIAgent):
    """
    {description}

    Generated using Function Slice Composition
    Slices used: {slice_list}
    """

    def __init__(self):
        config = AgentConfig(
            name="{agent_name}",
            agent_type=AgentType.CUSTOM,
            description="{description}",
            version="1.0.0",
            agentic_config={{
                "tools": {tools},
                "capabilities": {capabilities},
                "composed_slices": {slice_ids}
            }}
        )
        super().__init__(config)

    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Process query using composed slices"""
        try:
            context = context or {{}}
            result = await self._execute_slices(query, context)

            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result,
                message="Processing completed successfully"
            )
        except Exception as e:
            logger.error(f"Error in {{self.__class__.__name__}}: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}},
                message=f"Error: {{str(e)}}"
            )

    async def _execute_slices(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute composed slices in order"""
        results = {{}}

{slice_execution_code}

        return results
'''

    def __init__(self, library: Optional[SliceLibrary] = None):
        self.library = library or get_slice_library()

    def compose(
        self,
        agent_name: str,
        execution_order: List[str],
        flow_nodes: List[DataFlowNode],
        description: str = ""
    ) -> SliceCompositionResult:
        """
        슬라이스들을 에이전트 코드로 조합

        Args:
            agent_name: 에이전트 이름
            execution_order: 슬라이스 실행 순서
            flow_nodes: 데이터 흐름 노드
            description: 에이전트 설명

        Returns:
            조합 결과
        """
        # 1. Import 구문 수집
        imports = self._collect_imports(execution_order)

        # 2. 함수 코드 생성
        function_code = self._generate_function_code(execution_order, flow_nodes)

        # 3. 슬라이스 실행 코드 생성
        slice_execution = self._generate_slice_execution(execution_order, flow_nodes)

        # 4. 도구 및 기능 추출
        tools, capabilities = self._extract_tools_capabilities(execution_order)

        # 5. 클래스 이름 생성
        class_name = self._to_class_name(agent_name)

        # 6. 최종 코드 조합
        agent_code = self.AGENT_TEMPLATE.format(
            class_name=class_name,
            agent_name=agent_name,
            description=description or f"Agent composed from {len(execution_order)} slices",
            slice_list=", ".join(execution_order[:5]) + ("..." if len(execution_order) > 5 else ""),
            slice_ids=execution_order,
            tools=tools,
            capabilities=capabilities,
            slice_execution_code=slice_execution
        )

        full_code = f"{self.STANDARD_IMPORTS}\n{imports}\n{function_code}\n{agent_code}"

        # 7. 의존성 추출
        dependencies = self._extract_dependencies(execution_order)

        return SliceCompositionResult(
            success=True,
            composed_code=full_code,
            slice_ids=execution_order,
            warnings=[],
            dependencies=dependencies,
            execution_time=0.0
        )

    def _collect_imports(self, slice_ids: List[str]) -> str:
        """슬라이스에서 필요한 import 구문 수집"""
        imports = set()

        common_sklearn = [
            "from sklearn.model_selection import train_test_split, cross_val_score",
            "from sklearn.preprocessing import StandardScaler, LabelEncoder",
            "from sklearn.metrics import accuracy_score, mean_squared_error"
        ]

        for slice_id in slice_ids:
            slice_obj = self.library.get(slice_id)
            if not slice_obj:
                continue

            code = slice_obj.code_template

            # sklearn 관련
            if "sklearn" in code:
                imports.update(common_sklearn)

            # xgboost
            if "xgboost" in code or "xgb" in code:
                imports.add("try:\n    import xgboost as xgb\nexcept ImportError:\n    xgb = None")

            # shap
            if "shap" in code.lower():
                imports.add("try:\n    import shap\nexcept ImportError:\n    shap = None")

        return "\n".join(sorted(imports))

    def _generate_function_code(
        self,
        slice_ids: List[str],
        flow_nodes: List[DataFlowNode]
    ) -> str:
        """슬라이스 함수 코드 생성 - 각 슬라이스를 함수로 래핑"""
        import textwrap
        functions = []

        for slice_id in slice_ids:
            slice_obj = self.library.get(slice_id)
            if not slice_obj or not slice_obj.code_template:
                continue

            # 함수명 생성 (slice_id를 안전한 함수명으로 변환)
            func_name = self._slice_id_to_func_name(slice_id)

            # 파라미터 목록 생성
            params = self._build_function_params(slice_obj)

            # 리턴 타입 추론
            return_type = self._infer_return_type(slice_obj)

            # code_template 들여쓰기 정규화
            code_body = self._normalize_indentation(slice_obj.code_template)

            # 함수 docstring 생성
            docstring = f'"""{slice_obj.description}"""'

            # 함수 정의 생성
            function_code = f'''
# ===== Slice: {slice_id} =====
def {func_name}({params}) -> {return_type}:
    {docstring}
{self._indent_code(code_body, 4)}
'''
            functions.append(function_code)

        return "\n".join(functions)

    def _slice_id_to_func_name(self, slice_id: str) -> str:
        """slice_id를 안전한 함수명으로 변환"""
        # 점(.)을 밑줄(_)로 변환하고, 소문자로 통일
        func_name = slice_id.replace(".", "_").replace("-", "_").lower()
        # 숫자로 시작하면 앞에 'slice_' 추가
        if func_name[0].isdigit():
            func_name = f"slice_{func_name}"
        return f"slice_{func_name}"

    def _build_function_params(self, slice_obj: FunctionSlice) -> str:
        """슬라이스의 입력 파라미터로 함수 시그니처 생성

        Python에서 필수 파라미터(기본값 없음)는 선택 파라미터(기본값 있음)보다 먼저 와야 함
        """
        required_params = []
        optional_params = []

        for param in slice_obj.inputs:
            if param.required:
                required_params.append(f"{param.name}: {param.param_type}")
            else:
                default_val = self._format_default_value(param.default)
                optional_params.append(f"{param.name}: {param.param_type} = {default_val}")

        # 필수 파라미터를 먼저, 그 다음 선택 파라미터
        all_params = required_params + optional_params
        return ", ".join(all_params)

    def _format_default_value(self, value: Any) -> str:
        """기본값을 Python 코드 문자열로 포맷"""
        if value is None:
            return "None"
        elif isinstance(value, str):
            return f'"{value}"'
        elif isinstance(value, bool):
            return "True" if value else "False"
        elif isinstance(value, dict):
            if not value:
                return "{}"
            return str(value)
        elif isinstance(value, list):
            if not value:
                return "[]"
            return str(value)
        else:
            return str(value)

    def _infer_return_type(self, slice_obj: FunctionSlice) -> str:
        """출력 파라미터에서 리턴 타입 추론"""
        if not slice_obj.outputs:
            return "Any"
        if len(slice_obj.outputs) == 1:
            return slice_obj.outputs[0].param_type
        # 여러 출력이면 Dict로 반환
        return "Dict[str, Any]"

    def _normalize_indentation(self, code: str) -> str:
        """code_template의 들여쓰기 정규화"""
        import textwrap

        if not code:
            return "pass"

        # 먼저 dedent 적용 (strip 전에!)
        # 이렇게 하면 모든 줄의 공통 들여쓰기가 제거됨
        code = textwrap.dedent(code)

        # 그 다음 앞뒤 빈 줄 제거
        code = code.strip()

        # 빈 코드면 pass 반환
        if not code:
            return "pass"

        # 코드가 return문으로 시작하지 않으면 result 변수 반환 추가
        lines = code.split('\n')

        # return문이 없으면 마지막에 추가
        if not any(line.strip().startswith('return ') for line in lines):
            # 코드 내에 result 변수가 있으면 그것을 반환
            if 'result' in code:
                code += "\nreturn result"
            else:
                code += "\nreturn None"

        return code

    def _indent_code(self, code: str, spaces: int) -> str:
        """코드 블록에 들여쓰기 추가"""
        indent = " " * spaces
        lines = code.split('\n')
        return '\n'.join(indent + line if line.strip() else line for line in lines)

    def _generate_slice_execution(
        self,
        slice_ids: List[str],
        flow_nodes: List[DataFlowNode]
    ) -> str:
        """슬라이스 실행 코드 생성"""
        lines = []
        indent = "        "

        for i, slice_id in enumerate(slice_ids):
            slice_obj = self.library.get(slice_id)
            if not slice_obj:
                continue

            # 새 함수명 규칙 사용
            func_name = self._slice_id_to_func_name(slice_id)

            # 실행 코드 생성
            lines.append(f"{indent}# Step {i+1}: {slice_obj.name}")
            lines.append(f"{indent}try:")

            # 입력 파라미터 구성
            params = self._build_execution_params(slice_obj, flow_nodes, i)
            lines.append(f"{indent}    result_{i} = {func_name}({params})")
            lines.append(f"{indent}    results['{slice_id}'] = result_{i}")
            lines.append(f"{indent}except Exception as e:")
            lines.append(f"{indent}    logger.warning(f'Slice {slice_id} failed: {{e}}')")
            lines.append(f"{indent}    results['{slice_id}'] = None")
            lines.append("")

        return "\n".join(lines)

    def _build_execution_params(
        self,
        slice_obj: FunctionSlice,
        flow_nodes: List[DataFlowNode],
        step: int
    ) -> str:
        """실행 시 함수 호출 파라미터 문자열 생성"""
        params = []

        for param in slice_obj.inputs:
            if param.required:
                # 이전 결과에서 가져오기 또는 context에서 가져오기
                params.append(f"{param.name}=context.get('{param.name}')")
            # optional 파라미터는 기본값 사용하므로 생략

        return ", ".join(params) if params else ""

    def _extract_tools_capabilities(self, slice_ids: List[str]) -> Tuple[List[str], List[str]]:
        """슬라이스에서 도구 및 기능 추출"""
        tools = set()
        capabilities = set()

        for slice_id in slice_ids:
            slice_obj = self.library.get(slice_id)
            if not slice_obj:
                continue

            # 도메인 기반 도구 추론
            if slice_obj.domain == SliceDomain.ML_AI:
                tools.add("model_training")
                capabilities.add("machine_learning")
            elif slice_obj.domain == SliceDomain.FINANCE:
                tools.add("financial_analysis")
                capabilities.add("risk_analysis")
            elif slice_obj.domain == SliceDomain.CUSTOMER:
                tools.add("customer_analysis")
                capabilities.add("segmentation")

            # 태그 기반 기능 추론
            if slice_obj.metadata and slice_obj.metadata.tags:
                capabilities.update(slice_obj.metadata.tags[:3])

        return list(tools), list(capabilities)

    def _extract_dependencies(self, slice_ids: List[str]) -> List[str]:
        """필요한 외부 패키지 의존성 추출"""
        deps = {"numpy", "pandas"}  # 기본 의존성

        for slice_id in slice_ids:
            slice_obj = self.library.get(slice_id)
            if not slice_obj:
                continue

            code = slice_obj.code_template.lower()

            if "sklearn" in code:
                deps.add("scikit-learn")
            if "xgboost" in code or "xgb" in code:
                deps.add("xgboost")
            if "shap" in code:
                deps.add("shap")
            if "umap" in code:
                deps.add("umap-learn")

        return sorted(list(deps))

    def _to_class_name(self, name: str) -> str:
        """문자열을 PascalCase 클래스명으로 변환"""
        # 특수문자 제거 및 공백으로 분리
        words = re.sub(r'[^a-zA-Z0-9\s가-힣]', '', name).split()
        # 각 단어 첫 글자 대문자
        return ''.join(word.capitalize() for word in words) + "Agent"


# =============================================================================
# SliceCompositionEngine: Main Orchestrator
# =============================================================================

class SliceCompositionEngine:
    """
    슬라이스 조합 엔진: 전체 파이프라인 오케스트레이션

    Flow:
    Query → SemanticMatcher → DependencyResolver → DataFlowDesigner → CodeComposer → Agent Code
    """

    def __init__(self, library: Optional[SliceLibrary] = None):
        self.library = library or get_slice_library()
        self.matcher = SemanticMatcher(self.library)
        self.resolver = DependencyResolver(self.library)
        self.flow_designer = DataFlowDesigner(self.library)
        self.composer = CodeComposer(self.library)

    def compose_from_query(
        self,
        query: str,
        agent_name: Optional[str] = None,
        top_k: int = 10,
        min_match_score: float = 0.1,
        required_domains: Optional[List[SliceDomain]] = None
    ) -> SliceCompositionResult:
        """
        쿼리로부터 에이전트 코드 조합

        Args:
            query: 사용자 쿼리
            agent_name: 에이전트 이름 (미지정 시 자동 생성)
            top_k: 상위 K개 슬라이스 선택
            min_match_score: 최소 매칭 점수
            required_domains: 필수 도메인

        Returns:
            조합 결과
        """
        import time
        start_time = time.time()

        try:
            # 1. 쿼리 매칭
            matches = self.matcher.match_query(
                query,
                top_k=top_k,
                min_score=min_match_score,
                required_domains=required_domains
            )

            if not matches:
                return SliceCompositionResult(
                    success=False,
                    composed_code="",
                    slice_ids=[],
                    warnings=["No matching slices found for query"],
                    dependencies=[],
                    execution_time=time.time() - start_time
                )

            # 2. 슬라이스 ID 추출
            slice_ids = [m.slice_id for m in matches]

            # 3. 의존성 해결
            execution_order, dep_warnings = self.resolver.resolve(slice_ids)

            # 4. 데이터 흐름 설계
            flow_nodes = self.flow_designer.design_flow(execution_order)
            flow_issues = self.flow_designer.validate_flow(flow_nodes)

            # 5. 코드 조합
            agent_name = agent_name or self._generate_agent_name(query)
            result = self.composer.compose(
                agent_name=agent_name,
                execution_order=execution_order,
                flow_nodes=flow_nodes,
                description=query
            )

            # 6. 경고 통합
            all_warnings = dep_warnings + flow_issues
            result.warnings = all_warnings
            result.execution_time = time.time() - start_time

            return result

        except Exception as e:
            return SliceCompositionResult(
                success=False,
                composed_code="",
                slice_ids=[],
                warnings=[f"Composition failed: {str(e)}"],
                dependencies=[],
                execution_time=time.time() - start_time
            )

    def compose_from_slices(
        self,
        slice_ids: List[str],
        agent_name: str,
        description: str = ""
    ) -> SliceCompositionResult:
        """
        지정된 슬라이스들로 에이전트 코드 조합

        Args:
            slice_ids: 슬라이스 ID 목록
            agent_name: 에이전트 이름
            description: 에이전트 설명

        Returns:
            조합 결과
        """
        import time
        start_time = time.time()

        try:
            # 1. 의존성 해결
            execution_order, dep_warnings = self.resolver.resolve(slice_ids)

            # 2. 데이터 흐름 설계
            flow_nodes = self.flow_designer.design_flow(execution_order)
            flow_issues = self.flow_designer.validate_flow(flow_nodes)

            # 3. 코드 조합
            result = self.composer.compose(
                agent_name=agent_name,
                execution_order=execution_order,
                flow_nodes=flow_nodes,
                description=description
            )

            result.warnings = dep_warnings + flow_issues
            result.execution_time = time.time() - start_time

            return result

        except Exception as e:
            return SliceCompositionResult(
                success=False,
                composed_code="",
                slice_ids=[],
                warnings=[f"Composition failed: {str(e)}"],
                dependencies=[],
                execution_time=time.time() - start_time
            )

    def get_composition_plan(
        self,
        query: str,
        top_k: int = 10
    ) -> CompositionPlan:
        """
        조합 계획 미리보기 (코드 생성 없이)

        Args:
            query: 사용자 쿼리
            top_k: 상위 K개 슬라이스

        Returns:
            조합 계획
        """
        # 1. 매칭
        matches = self.matcher.match_query(query, top_k=top_k)
        slice_ids = [m.slice_id for m in matches]

        # 2. 의존성 해결
        execution_order, warnings = self.resolver.resolve(slice_ids)

        # 3. 데이터 흐름 설계
        flow_nodes = self.flow_designer.design_flow(execution_order)

        # 4. 복잡도 추정
        complexity = self._estimate_complexity(execution_order)

        return CompositionPlan(
            query=query,
            selected_slices=slice_ids,
            execution_order=execution_order,
            data_flow=flow_nodes,
            estimated_complexity=complexity,
            warnings=warnings
        )

    def _generate_agent_name(self, query: str) -> str:
        """쿼리에서 에이전트 이름 생성"""
        # 작업 유형 추출
        task_type = self.matcher.get_task_type(query) or "custom"

        # 도메인 추출
        domains = self.matcher._infer_domains(query.lower())
        domain_str = list(domains)[0].value if domains else "general"

        return f"{domain_str}_{task_type}_agent"

    def _estimate_complexity(self, slice_ids: List[str]) -> float:
        """슬라이스 기반 복잡도 추정"""
        if not slice_ids:
            return 0.0

        total_complexity = 0.0
        for slice_id in slice_ids:
            slice_obj = self.library.get(slice_id)
            if slice_obj and slice_obj.metadata:
                total_complexity += slice_obj.metadata.complexity

        return total_complexity / len(slice_ids)


# =============================================================================
# Convenience Functions
# =============================================================================

def compose_agent(query: str, agent_name: Optional[str] = None) -> SliceCompositionResult:
    """
    편의 함수: 쿼리로부터 에이전트 조합

    Example:
        >>> result = compose_agent("고객 세그멘테이션 및 이탈 예측 분석")
        >>> print(result.composed_code)
    """
    engine = SliceCompositionEngine()
    return engine.compose_from_query(query, agent_name)


def preview_composition(query: str) -> CompositionPlan:
    """
    편의 함수: 조합 계획 미리보기

    Example:
        >>> plan = preview_composition("매출 예측 및 재무 분석")
        >>> print(f"Selected slices: {plan.selected_slices}")
    """
    engine = SliceCompositionEngine()
    return engine.get_composition_plan(query)


__all__ = [
    # Core Classes
    "SemanticMatcher",
    "DependencyResolver",
    "DataFlowDesigner",
    "CodeComposer",
    "SliceCompositionEngine",

    # Data Classes
    "MatchResult",
    "DataFlowNode",
    "CompositionPlan",

    # Convenience Functions
    "compose_agent",
    "preview_composition"
]
