"""
Slice Library
=============
Function Slice 라이브러리 관리 클래스

슬라이스 등록, 조회, 검색, 의존성 관리 기능을 제공합니다.
"""

from typing import Dict, List, Optional, Set, Tuple, Any
from collections import defaultdict
from loguru import logger
import re

from .models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceDict,
    KeywordIndex,
    DependencyGraph
)


class SliceLibrary:
    """
    Function Slice 라이브러리

    200개 이상의 재사용 가능한 슬라이스를 관리합니다.
    - Core: 4개 (모든 에이전트 필수)
    - Common: 40개 (다수 도메인 공유)
    - Domain: 160+개 (도메인 특화)
    """

    _instance: Optional["SliceLibrary"] = None

    def __new__(cls) -> "SliceLibrary":
        """싱글톤 패턴"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        # 슬라이스 저장소
        self._slices: SliceDict = {}

        # 카테고리별 인덱스
        self._by_category: Dict[SliceCategory, List[str]] = defaultdict(list)

        # 도메인별 인덱스
        self._by_domain: Dict[SliceDomain, List[str]] = defaultdict(list)

        # 키워드 인덱스 (다국어)
        self._keyword_index_ko: KeywordIndex = defaultdict(list)
        self._keyword_index_en: KeywordIndex = defaultdict(list)

        # 의존성 그래프
        self._dependency_graph: DependencyGraph = defaultdict(list)
        self._reverse_dependency_graph: DependencyGraph = defaultdict(list)

        self._initialized = True
        logger.info("SliceLibrary initialized")

    def register(self, slice_obj: FunctionSlice) -> bool:
        """
        슬라이스 등록

        Args:
            slice_obj: 등록할 FunctionSlice

        Returns:
            bool: 등록 성공 여부
        """
        if slice_obj.id in self._slices:
            logger.warning(f"Slice already exists: {slice_obj.id}")
            return False

        # 저장
        self._slices[slice_obj.id] = slice_obj

        # 카테고리 인덱스 업데이트
        self._by_category[slice_obj.category].append(slice_obj.id)

        # 도메인 인덱스 업데이트
        self._by_domain[slice_obj.domain].append(slice_obj.id)

        # 키워드 인덱스 업데이트 (두 형식 모두 지원)
        keywords = slice_obj.keywords
        if isinstance(keywords, list):
            # 리스트 형식: 자동 언어 분류
            for keyword in keywords:
                keyword_lower = keyword.lower()
                # 한글 포함 여부로 판단
                if any('\uac00' <= c <= '\ud7a3' for c in keyword):
                    self._keyword_index_ko[keyword_lower].append(slice_obj.id)
                else:
                    self._keyword_index_en[keyword_lower].append(slice_obj.id)
        elif isinstance(keywords, dict):
            # 딕셔너리 형식: ko/en 키 사용
            for keyword in keywords.get("ko", []):
                self._keyword_index_ko[keyword.lower()].append(slice_obj.id)
            for keyword in keywords.get("en", []):
                self._keyword_index_en[keyword.lower()].append(slice_obj.id)

        # 의존성 그래프 업데이트
        for dep_id in slice_obj.dependencies:
            self._dependency_graph[slice_obj.id].append(dep_id)
            self._reverse_dependency_graph[dep_id].append(slice_obj.id)

        logger.debug(f"Registered slice: {slice_obj.id} ({slice_obj.category.value}/{slice_obj.domain.value})")
        return True

    def register_many(self, slices: List[FunctionSlice]) -> int:
        """
        여러 슬라이스 일괄 등록

        Args:
            slices: 등록할 슬라이스 목록

        Returns:
            int: 등록된 슬라이스 수
        """
        count = 0
        for slice_obj in slices:
            if self.register(slice_obj):
                count += 1
        logger.info(f"Registered {count}/{len(slices)} slices")
        return count

    def get(self, slice_id: str) -> Optional[FunctionSlice]:
        """
        슬라이스 조회

        Args:
            slice_id: 슬라이스 ID

        Returns:
            FunctionSlice or None
        """
        return self._slices.get(slice_id)

    def get_many(self, slice_ids: List[str]) -> List[FunctionSlice]:
        """
        여러 슬라이스 조회

        Args:
            slice_ids: 슬라이스 ID 목록

        Returns:
            List[FunctionSlice]
        """
        return [self._slices[sid] for sid in slice_ids if sid in self._slices]

    def get_by_category(self, category: SliceCategory) -> List[FunctionSlice]:
        """
        카테고리별 슬라이스 조회

        Args:
            category: 슬라이스 카테고리

        Returns:
            List[FunctionSlice]
        """
        slice_ids = self._by_category.get(category, [])
        return self.get_many(slice_ids)

    def get_by_domain(self, domain: SliceDomain) -> List[FunctionSlice]:
        """
        도메인별 슬라이스 조회

        Args:
            domain: 슬라이스 도메인

        Returns:
            List[FunctionSlice]
        """
        slice_ids = self._by_domain.get(domain, [])
        return self.get_many(slice_ids)

    def get_core_slice_ids(self) -> List[str]:
        """
        Core 슬라이스 ID 목록 조회

        Returns:
            List[str]: Core 슬라이스 ID 목록
        """
        return list(self._by_category.get(SliceCategory.CORE, []))

    def search_by_keywords(
        self,
        keywords: List[str],
        language: str = "auto",
        threshold: float = 0.3
    ) -> List[Tuple[FunctionSlice, float]]:
        """
        키워드 기반 슬라이스 검색

        Args:
            keywords: 검색 키워드 목록
            language: 언어 ("ko", "en", "auto")
            threshold: 최소 매칭 점수

        Returns:
            List[Tuple[FunctionSlice, float]]: (슬라이스, 매칭 점수) 목록
        """
        if not keywords:
            return []

        # 언어 자동 감지
        if language == "auto":
            language = self._detect_language(keywords)

        # 키워드 정규화
        normalized_keywords = [k.lower().strip() for k in keywords]

        # 슬라이스별 매칭 점수 계산
        scores: Dict[str, float] = defaultdict(float)

        # 키워드 인덱스 선택
        keyword_index = self._keyword_index_ko if language == "ko" else self._keyword_index_en

        # 정확한 키워드 매칭
        for keyword in normalized_keywords:
            if keyword in keyword_index:
                for slice_id in keyword_index[keyword]:
                    scores[slice_id] += 1.0

            # 부분 매칭
            for indexed_keyword, slice_ids in keyword_index.items():
                if keyword in indexed_keyword or indexed_keyword in keyword:
                    for slice_id in slice_ids:
                        scores[slice_id] += 0.5

        # 정규화 및 필터링
        max_score = len(normalized_keywords)
        results = []

        for slice_id, score in scores.items():
            normalized_score = score / max_score if max_score > 0 else 0
            if normalized_score >= threshold:
                slice_obj = self.get(slice_id)
                if slice_obj:
                    results.append((slice_obj, normalized_score))

        # 점수 순 정렬
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def _detect_language(self, keywords: List[str]) -> str:
        """키워드 언어 감지"""
        korean_pattern = re.compile(r'[가-힣]')
        korean_count = sum(1 for k in keywords if korean_pattern.search(k))
        return "ko" if korean_count > len(keywords) / 2 else "en"

    def get_dependencies(self, slice_id: str, recursive: bool = True) -> Set[str]:
        """
        슬라이스 의존성 조회

        Args:
            slice_id: 슬라이스 ID
            recursive: 재귀적으로 모든 의존성 조회

        Returns:
            Set[str]: 의존 슬라이스 ID 집합
        """
        if slice_id not in self._slices:
            return set()

        deps = set(self._dependency_graph.get(slice_id, []))

        if recursive:
            all_deps = set(deps)
            to_process = list(deps)

            while to_process:
                current = to_process.pop()
                for dep in self._dependency_graph.get(current, []):
                    if dep not in all_deps:
                        all_deps.add(dep)
                        to_process.append(dep)

            return all_deps

        return deps

    def get_dependents(self, slice_id: str) -> Set[str]:
        """
        이 슬라이스에 의존하는 슬라이스 조회

        Args:
            slice_id: 슬라이스 ID

        Returns:
            Set[str]: 의존하는 슬라이스 ID 집합
        """
        return set(self._reverse_dependency_graph.get(slice_id, []))

    def topological_sort(self, slice_ids: List[str]) -> List[str]:
        """
        슬라이스 위상 정렬 (실행 순서 결정)

        Args:
            slice_ids: 정렬할 슬라이스 ID 목록

        Returns:
            List[str]: 실행 순서대로 정렬된 슬라이스 ID
        """
        # 관련 슬라이스만 필터링
        relevant_ids = set(slice_ids)

        # 의존성 포함
        for sid in slice_ids:
            relevant_ids.update(self.get_dependencies(sid))

        # 진입 차수 계산
        in_degree: Dict[str, int] = defaultdict(int)
        for sid in relevant_ids:
            deps = self._dependency_graph.get(sid, [])
            for dep in deps:
                if dep in relevant_ids:
                    in_degree[sid] += 1

        # 진입 차수 0인 노드부터 시작
        queue = [sid for sid in relevant_ids if in_degree[sid] == 0]
        result = []

        while queue:
            current = queue.pop(0)
            result.append(current)

            # 이 슬라이스에 의존하는 슬라이스 처리
            for dependent in self._reverse_dependency_graph.get(current, []):
                if dependent in relevant_ids:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        queue.append(dependent)

        # 순환 의존성 체크
        if len(result) != len(relevant_ids):
            logger.warning(f"Circular dependency detected in slices: {relevant_ids - set(result)}")

        return result

    def get_core_slices(self) -> List[FunctionSlice]:
        """Core 슬라이스 조회 (모든 에이전트 필수)"""
        return self.get_by_category(SliceCategory.CORE)

    def get_common_slices(self) -> List[FunctionSlice]:
        """Common 슬라이스 조회"""
        return self.get_by_category(SliceCategory.COMMON)

    def get_statistics(self) -> Dict[str, Any]:
        """라이브러리 통계"""
        return {
            "total_slices": len(self._slices),
            "by_category": {
                cat.value: len(ids) for cat, ids in self._by_category.items()
            },
            "by_domain": {
                dom.value: len(ids) for dom, ids in self._by_domain.items()
            },
            "keyword_count": {
                "ko": len(self._keyword_index_ko),
                "en": len(self._keyword_index_en)
            }
        }

    def clear(self):
        """라이브러리 초기화"""
        self._slices.clear()
        self._by_category.clear()
        self._by_domain.clear()
        self._keyword_index_ko.clear()
        self._keyword_index_en.clear()
        self._dependency_graph.clear()
        self._reverse_dependency_graph.clear()
        logger.info("SliceLibrary cleared")


# 글로벌 라이브러리 인스턴스
_library: Optional[SliceLibrary] = None


def get_slice_library() -> SliceLibrary:
    """슬라이스 라이브러리 싱글톤 인스턴스 반환"""
    global _library
    if _library is None:
        _library = SliceLibrary()
    return _library
