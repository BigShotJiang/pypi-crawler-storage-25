#!/usr/bin/env python3
"""
Self-Growing System 테스트
==========================

Self-Growing 시스템의 전체 파이프라인을 테스트합니다.

실행 방법:
    cd /Users/maior/Development/skku/Logos
    source .venv/bin/activate
    python -m forge.core.business_logic_v2.slice_library.test_self_growing

또는:
    cd /Users/maior/Development/skku/Logos/forge/core/business_logic_v2/slice_library
    python test_self_growing.py
"""

import sys
import os
import json
from datetime import datetime
from typing import Dict, List, Any

# 경로 설정
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

from loguru import logger

# 로거 설정
logger.remove()
logger.add(sys.stdout, level="INFO", format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}")


def setup_test_library():
    """테스트용 라이브러리 설정"""
    from forge.core.business_logic_v2.slice_library.library import get_slice_library, SliceLibrary
    from forge.core.business_logic_v2.slice_library.models import (
        FunctionSlice, SliceCategory, SliceDomain, SliceParameter
    )

    # 싱글톤 초기화
    library = get_slice_library()
    library.clear()

    # 테스트용 기본 슬라이스 등록
    test_slices = [
        FunctionSlice(
            id="core.agent_config",
            name="Agent Configuration",
            description="에이전트 기본 설정",
            category=SliceCategory.CORE,
            domain=SliceDomain.CORE,
            keywords={"ko": ["설정", "구성", "config"], "en": ["config", "configuration", "setup"]},
            code_template="""        config = {
            "name": self.name,
            "version": "1.0.0"
        }
        return config""",
            inputs=[],
            outputs=[SliceParameter(name="config", param_type="Dict[str, Any]", description="Agent configuration")]
        ),
        FunctionSlice(
            id="common.data_validation",
            name="Data Validation",
            description="데이터 유효성 검증",
            category=SliceCategory.COMMON,
            domain=SliceDomain.COMMON,
            keywords={"ko": ["검증", "유효성", "validation"], "en": ["validate", "validation", "check"]},
            code_template="""        if not data:
            return {"valid": False, "error": "Empty data"}
        return {"valid": True, "data": data}""",
            inputs=[SliceParameter(name="data", param_type="Dict[str, Any]", description="Data to validate")],
            outputs=[SliceParameter(name="result", param_type="Dict[str, Any]", description="Validation result")]
        ),
        FunctionSlice(
            id="customer.analyze_behavior",
            name="Customer Behavior Analysis",
            description="고객 행동 분석",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            keywords={"ko": ["고객", "행동", "분석"], "en": ["customer", "behavior", "analysis"]},
            code_template="""        try:
            behaviors = data.get("behaviors", [])
            analysis = {
                "total_actions": len(behaviors),
                "patterns": self._detect_patterns(behaviors)
            }
            return {"success": True, "analysis": analysis}
        except Exception as e:
            return {"success": False, "error": str(e)}""",
            inputs=[SliceParameter(name="data", param_type="Dict[str, Any]", description="Customer data")],
            outputs=[SliceParameter(name="analysis", param_type="Dict[str, Any]", description="Behavior analysis")]
        ),
        FunctionSlice(
            id="finance.calculate_roi",
            name="ROI Calculation",
            description="투자 수익률 계산",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            keywords={"ko": ["ROI", "수익률", "투자", "계산"], "en": ["roi", "return", "investment", "calculate"]},
            code_template="""        try:
            investment = data.get("investment", 0)
            return_value = data.get("return", 0)
            if investment == 0:
                return {"error": "Investment cannot be zero"}
            roi = (return_value - investment) / investment * 100
            return {"roi": roi, "unit": "percent"}
        except Exception as e:
            return {"error": str(e)}""",
            inputs=[SliceParameter(name="data", param_type="Dict[str, Any]", description="Investment data")],
            outputs=[SliceParameter(name="roi", param_type="Dict[str, Any]", description="ROI result")]
        ),
        FunctionSlice(
            id="ml.predict_model",
            name="Model Prediction",
            description="ML 모델 예측",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            keywords={"ko": ["예측", "모델", "머신러닝"], "en": ["predict", "model", "machine learning", "ml"]},
            code_template="""        try:
            features = data.get("features", [])
            # 간단한 예측 로직
            prediction = sum(features) / len(features) if features else 0
            return {"prediction": prediction, "confidence": 0.85}
        except Exception as e:
            return {"error": str(e)}""",
            inputs=[SliceParameter(name="data", param_type="Dict[str, Any]", description="Feature data")],
            outputs=[SliceParameter(name="prediction", param_type="Dict[str, Any]", description="Prediction result")]
        )
    ]

    count = library.register_many(test_slices)
    logger.info(f"Registered {count} test slices")

    return library


def test_coverage_analyzer():
    """커버리지 분석기 테스트"""
    print("\n" + "="*60)
    print("TEST 1: Coverage Analyzer")
    print("="*60)

    from forge.core.business_logic_v2.slice_library.self_growing import SliceCoverageAnalyzer

    library = setup_test_library()
    analyzer = SliceCoverageAnalyzer(library)

    # 테스트 요구사항 (일부는 커버, 일부는 갭)
    required_functions = [
        {
            "name": "validate_input",
            "description": "입력 데이터 검증",
            "keywords": ["validate", "validation", "check"]
        },
        {
            "name": "calculate_roi",
            "description": "ROI 계산",
            "keywords": ["roi", "return", "investment"]
        },
        {
            "name": "send_notification",  # 갭 - 라이브러리에 없음
            "description": "알림 전송",
            "keywords": ["notification", "alert", "send"]
        },
        {
            "name": "process_payment",  # 갭 - 라이브러리에 없음
            "description": "결제 처리",
            "keywords": ["payment", "process", "transaction"]
        }
    ]

    coverage, gaps = analyzer.analyze_coverage(required_functions, language="en")

    print(f"\nCoverage: {coverage*100:.1f}%")
    print(f"Gaps found: {len(gaps)}")

    for gap in gaps:
        print(f"  - {gap.function_name}: max_similarity={gap.max_similarity:.2f}")
        if gap.closest_slice_id:
            print(f"    closest: {gap.closest_slice_id}")

    # 검증
    assert 0 < coverage < 1, "Coverage should be partial"
    assert len(gaps) == 2, f"Expected 2 gaps, got {len(gaps)}"

    print("\n✅ Coverage Analyzer Test PASSED")
    return True


def test_template_retriever():
    """템플릿 검색기 테스트"""
    print("\n" + "="*60)
    print("TEST 2: Template Retriever")
    print("="*60)

    from forge.core.business_logic_v2.slice_library.self_growing import (
        TemplateRetriever, CoverageGap, SliceDomain
    )

    library = setup_test_library()
    retriever = TemplateRetriever(library)

    # 갭 정의
    gap = CoverageGap(
        function_name="send_notification",
        description="알림 전송 기능",
        keywords=["notification", "send", "alert"],
        max_similarity=0.3,
        domain_hint=SliceDomain.COMMON
    )

    templates = retriever.retrieve_templates(gap, language="en")

    print(f"\nRetrieved {len(templates)} templates for '{gap.function_name}':")
    for t in templates:
        print(f"  - {t.id}: {t.name}")

    # 검증
    assert len(templates) > 0, "Should retrieve at least one template"

    print("\n✅ Template Retriever Test PASSED")
    return True


def test_slice_generator():
    """슬라이스 생성기 테스트"""
    print("\n" + "="*60)
    print("TEST 3: Slice Generator")
    print("="*60)

    from forge.core.business_logic_v2.slice_library.self_growing import (
        SliceGenerator, CoverageGap, SliceDomain
    )
    from forge.core.business_logic_v2.slice_library.models import FunctionSlice

    library = setup_test_library()
    generator = SliceGenerator()

    # 갭 정의
    gap = CoverageGap(
        function_name="send_notification",
        description="사용자에게 알림을 전송합니다",
        keywords=["notification", "send", "alert", "message"],
        max_similarity=0.3,
        domain_hint=SliceDomain.COMMON
    )

    # 템플릿 가져오기
    templates = list(library._slices.values())[:2]

    # 슬라이스 생성
    generated_slice = generator.generate_slice(gap, templates)

    print(f"\nGenerated slice:")
    print(f"  ID: {generated_slice.id}")
    print(f"  Name: {generated_slice.name}")
    print(f"  Domain: {generated_slice.domain.value}")
    print(f"  Category: {generated_slice.category.value}")
    print(f"\nCode template (first 200 chars):")
    print(generated_slice.code_template[:200])

    # 검증
    assert generated_slice is not None, "Should generate a slice"
    assert generated_slice.id.startswith("sg_"), "ID should start with 'sg_'"
    assert generated_slice.code_template, "Should have code template"

    print("\n✅ Slice Generator Test PASSED")
    return True


def test_slice_validator():
    """슬라이스 검증기 테스트"""
    print("\n" + "="*60)
    print("TEST 4: Slice Validator")
    print("="*60)

    from forge.core.business_logic_v2.slice_library.self_growing import (
        SliceValidator, ValidationStage
    )
    from forge.core.business_logic_v2.slice_library.models import (
        FunctionSlice, SliceCategory, SliceDomain, SliceParameter
    )

    validator = SliceValidator()

    # 유효한 슬라이스
    valid_slice = FunctionSlice(
        id="test.valid_slice",
        name="Valid Test Slice",
        description="테스트용 유효한 슬라이스입니다",
        category=SliceCategory.DOMAIN,
        domain=SliceDomain.COMMON,
        keywords={"ko": ["테스트"], "en": ["test", "valid"]},
        code_template="""        try:
            result = {"status": "success", "data": data}
            return result
        except Exception as e:
            return {"status": "error", "error": str(e)}""",
        inputs=[SliceParameter(name="data", param_type="Dict[str, Any]", description="Input data")],
        outputs=[SliceParameter(name="result", param_type="Dict[str, Any]", description="Result")]
    )

    results = validator.validate(valid_slice)

    print(f"\nValidation results for '{valid_slice.id}':")
    for result in results:
        status = "✅" if result.passed else "❌"
        print(f"  {status} {result.stage.value}: {result.message}")
        print(f"      Time: {result.execution_time_ms:.2f}ms")

    # 모든 필수 단계 통과 확인
    syntax_passed = any(r.stage == ValidationStage.SYNTAX and r.passed for r in results)
    type_passed = any(r.stage == ValidationStage.TYPE and r.passed for r in results)

    assert syntax_passed, "Syntax validation should pass"
    assert type_passed, "Type validation should pass"

    print("\n✅ Slice Validator Test PASSED")
    return True


def test_quality_gate():
    """품질 게이트 테스트"""
    print("\n" + "="*60)
    print("TEST 5: Quality Gate")
    print("="*60)

    from forge.core.business_logic_v2.slice_library.self_growing import (
        QualityGate, SliceValidator, ValidationResult, ValidationStage
    )
    from forge.core.business_logic_v2.slice_library.models import (
        FunctionSlice, SliceCategory, SliceDomain, SliceParameter
    )

    gate = QualityGate(quality_threshold=0.60)
    validator = SliceValidator()

    # 고품질 슬라이스
    high_quality_slice = FunctionSlice(
        id="test.high_quality",
        name="High Quality Slice",
        description="이 슬라이스는 고품질의 기능을 제공합니다. 입력 데이터를 처리하고 결과를 반환합니다.",
        category=SliceCategory.DOMAIN,
        domain=SliceDomain.COMMON,
        keywords={"ko": ["고품질", "테스트", "처리"], "en": ["high", "quality", "test", "process"]},
        code_template="""        try:
            if not data:
                return {"status": "error", "message": "No data provided"}
            processed = {"input": data, "processed": True}
            result = {"status": "success", "data": processed}
            return result
        except Exception as e:
            return {"status": "error", "error": str(e)}""",
        inputs=[SliceParameter(name="data", param_type="Dict[str, Any]", description="Input data to process")],
        outputs=[SliceParameter(name="result", param_type="Dict[str, Any]", description="Processed result")]
    )

    validation_results = validator.validate(high_quality_slice)
    admitted, score, reason = gate.evaluate(high_quality_slice, validation_results)

    print(f"\nHigh Quality Slice Evaluation:")
    print(f"  Admitted: {admitted}")
    print(f"  Score: {score:.2f}")
    print(f"  Reason: {reason}")

    assert admitted, f"High quality slice should be admitted, got score {score}"

    # 저품질 슬라이스
    low_quality_slice = FunctionSlice(
        id="test.low_quality",
        name="Low",
        description="",  # 설명 없음
        category=SliceCategory.DOMAIN,
        domain=SliceDomain.COMMON,
        keywords={},  # 키워드 없음
        code_template="""        return {}""",  # 최소 코드
        inputs=[],
        outputs=[]
    )

    validation_results_low = validator.validate(low_quality_slice)
    admitted_low, score_low, reason_low = gate.evaluate(low_quality_slice, validation_results_low)

    print(f"\nLow Quality Slice Evaluation:")
    print(f"  Admitted: {admitted_low}")
    print(f"  Score: {score_low:.2f}")
    print(f"  Reason: {reason_low}")

    # 저품질은 거부되어야 함
    assert not admitted_low or score_low < score, "Low quality slice should have lower score"

    print("\n✅ Quality Gate Test PASSED")
    return True


def test_full_self_growing_pipeline():
    """전체 Self-Growing 파이프라인 테스트"""
    print("\n" + "="*60)
    print("TEST 6: Full Self-Growing Pipeline")
    print("="*60)

    from forge.core.business_logic_v2.slice_library.self_growing import SelfGrowingSystem

    library = setup_test_library()
    initial_count = len(library._slices)
    print(f"\nInitial library size: {initial_count} slices")

    # Self-Growing 시스템 생성
    system = SelfGrowingSystem(
        library=library,
        quality_threshold=0.50,  # 테스트를 위해 낮은 임계값
        auto_admit=True
    )

    # 테스트 요구사항 (갭이 있는 것들)
    required_functions = [
        {
            "name": "send_email",
            "description": "이메일 발송 기능",
            "keywords": ["email", "send", "notification", "mail"]
        },
        {
            "name": "generate_report",
            "description": "리포트 생성",
            "keywords": ["report", "generate", "create", "document"]
        },
        {
            "name": "validate_input",  # 이미 있음
            "description": "입력 검증",
            "keywords": ["validate", "validation", "check"]
        }
    ]

    print("\nProcessing requirements...")
    results = system.process_requirements(required_functions, language="en")

    print(f"\nGeneration Results:")
    for result in results:
        if result.success:
            print(f"  ✅ {result.slice.id}")
            print(f"     Quality: {result.quality_score:.2f}")
            print(f"     Admitted: {result.admitted_to_library}")
            print(f"     Time: {result.generation_time_ms:.2f}ms")
        else:
            print(f"  ❌ Failed: {result.error_message}")

    # 통계 출력
    stats = system.get_statistics()
    print(f"\nStatistics:")
    print(f"  Total Generated: {stats['total_generated']}")
    print(f"  Total Admitted: {stats['total_admitted']}")
    print(f"  Total Rejected: {stats['total_rejected']}")
    print(f"  Admission Rate: {stats['admission_rate']*100:.1f}%")
    print(f"  Coverage: {stats['coverage_before']*100:.1f}% → {stats['coverage_after']*100:.1f}%")
    print(f"  Library Size: {stats['library_size']} slices")

    final_count = len(library._slices)
    print(f"\nFinal library size: {final_count} slices (+{final_count - initial_count})")

    # 검증
    assert stats['total_generated'] >= 1, "Should generate at least 1 slice"

    print("\n✅ Full Pipeline Test PASSED")
    return True


def run_all_tests():
    """모든 테스트 실행"""
    print("\n" + "="*60)
    print("SELF-GROWING SYSTEM TESTS")
    print("="*60)
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    tests = [
        ("Coverage Analyzer", test_coverage_analyzer),
        ("Template Retriever", test_template_retriever),
        ("Slice Generator", test_slice_generator),
        ("Slice Validator", test_slice_validator),
        ("Quality Gate", test_quality_gate),
        ("Full Pipeline", test_full_self_growing_pipeline),
    ]

    results = []

    for name, test_func in tests:
        try:
            success = test_func()
            results.append((name, success, None))
        except Exception as e:
            logger.error(f"Test '{name}' failed with error: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False, str(e)))

    # 결과 요약
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)

    passed = sum(1 for _, success, _ in results if success)
    total = len(results)

    for name, success, error in results:
        status = "✅ PASSED" if success else f"❌ FAILED: {error}"
        print(f"  {name}: {status}")

    print(f"\n{passed}/{total} tests passed")

    if passed == total:
        print("\n🎉 ALL TESTS PASSED!")
        return True
    else:
        print("\n⚠️ SOME TESTS FAILED")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
