"""
Core Function Slices
====================
모든 에이전트에 필수적인 4개의 Core Slices 정의

Core Slices:
1. error_handling - 에러 처리 및 복구
2. input_validation - 입력 데이터 검증
3. output_formatting - 출력 데이터 포맷팅
4. lifecycle_management - 에이전트 생명주기 관리
"""

from typing import List
from .models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceTestCase,
    SliceMetadata
)


def create_core_slices() -> List[FunctionSlice]:
    """Core Slices 생성 및 반환"""
    return [
        _create_error_handling_slice(),
        _create_input_validation_slice(),
        _create_output_formatting_slice(),
        _create_lifecycle_management_slice(),
    ]


def _create_error_handling_slice() -> FunctionSlice:
    """에러 처리 슬라이스"""
    return FunctionSlice(
        id="core.error_handling",
        name="Error Handling",
        description="에이전트 실행 중 발생하는 에러를 안전하게 처리하고 복구합니다.",
        category=SliceCategory.CORE,
        domain=SliceDomain.CORE,
        inputs=[
            SliceParameter(
                name="operation",
                param_type="Callable",
                description="실행할 작업 함수",
                required=True
            ),
            SliceParameter(
                name="error_handlers",
                param_type="Dict[Type[Exception], Callable]",
                description="예외 타입별 핸들러 매핑",
                default={},
                required=False
            ),
            SliceParameter(
                name="max_retries",
                param_type="int",
                description="최대 재시도 횟수",
                default=3,
                required=False
            ),
            SliceParameter(
                name="fallback_value",
                param_type="Any",
                description="실패 시 반환할 기본값",
                default=None,
                required=False
            )
        ],
        outputs=[
            SliceParameter(
                name="result",
                param_type="Any",
                description="작업 실행 결과 또는 fallback 값"
            )
        ],
        dependencies=[],
        keywords={
            "ko": ["에러", "오류", "예외", "처리", "복구", "재시도", "안전"],
            "en": ["error", "exception", "handling", "recovery", "retry", "safe", "fallback"]
        },
        code_template='''
        import time
        from typing import Any, Callable, Dict, Type
        from loguru import logger

        retries = 0
        last_error = None

        while retries <= max_retries:
            try:
                result = operation()
                return result
            except Exception as e:
                last_error = e
                error_type = type(e)

                # 커스텀 핸들러가 있으면 사용
                if error_type in error_handlers:
                    try:
                        return error_handlers[error_type](e)
                    except Exception as handler_error:
                        logger.warning(f"Handler failed: {handler_error}")

                retries += 1
                if retries <= max_retries:
                    wait_time = 2 ** retries  # Exponential backoff
                    logger.warning(f"Retry {retries}/{max_retries} after {wait_time}s: {e}")
                    time.sleep(wait_time)

        logger.error(f"All retries failed: {last_error}")
        return fallback_value
''',
        function_name="_handle_error",
        test_cases=[
            SliceTestCase(
                name="test_successful_operation",
                inputs={"operation": lambda: 42, "max_retries": 3},
                expected_output=42,
                description="성공적인 작업 실행"
            ),
            SliceTestCase(
                name="test_fallback_on_failure",
                inputs={
                    "operation": lambda: 1/0,
                    "max_retries": 0,
                    "fallback_value": -1
                },
                expected_output=-1,
                description="실패 시 fallback 값 반환"
            )
        ],
        metadata=SliceMetadata(
            author="FORGE AI",
            version="1.0.0",
            complexity=0.3,
            reliability=0.99,
            performance_score=0.95,
            tags=["core", "error-handling", "reliability"]
        )
    )


def _create_input_validation_slice() -> FunctionSlice:
    """입력 검증 슬라이스"""
    return FunctionSlice(
        id="core.input_validation",
        name="Input Validation",
        description="입력 데이터의 유효성을 검증하고 정규화합니다.",
        category=SliceCategory.CORE,
        domain=SliceDomain.CORE,
        inputs=[
            SliceParameter(
                name="data",
                param_type="Any",
                description="검증할 입력 데이터",
                required=True
            ),
            SliceParameter(
                name="schema",
                param_type="Dict[str, Any]",
                description="검증 스키마 (필드별 타입, 필수 여부, 범위 등)",
                required=True
            ),
            SliceParameter(
                name="strict",
                param_type="bool",
                description="엄격 모드 (True: 추가 필드 불허)",
                default=False,
                required=False
            )
        ],
        outputs=[
            SliceParameter(
                name="validated_data",
                param_type="Dict[str, Any]",
                description="검증 및 정규화된 데이터"
            ),
            SliceParameter(
                name="errors",
                param_type="List[str]",
                description="검증 실패 메시지 목록"
            )
        ],
        dependencies=[],
        keywords={
            "ko": ["검증", "유효성", "입력", "확인", "검사", "스키마", "타입"],
            "en": ["validate", "validation", "input", "check", "verify", "schema", "type"]
        },
        code_template='''
        from typing import Any, Dict, List, Tuple

        errors: List[str] = []
        validated: Dict[str, Any] = {}

        if not isinstance(data, dict):
            try:
                data = dict(data)
            except (TypeError, ValueError):
                errors.append(f"Input must be dict-like, got {type(data).__name__}")
                return ({}, errors)

        # 필수 필드 검증
        for field, rules in schema.items():
            required = rules.get("required", False)
            field_type = rules.get("type", Any)
            default = rules.get("default", None)
            min_val = rules.get("min", None)
            max_val = rules.get("max", None)
            choices = rules.get("choices", None)

            if field not in data:
                if required:
                    errors.append(f"Required field missing: {field}")
                elif default is not None:
                    validated[field] = default
                continue

            value = data[field]

            # 타입 검증
            if field_type != Any and not isinstance(value, field_type):
                try:
                    value = field_type(value)
                except (TypeError, ValueError):
                    errors.append(f"Field '{field}' must be {field_type.__name__}")
                    continue

            # 범위 검증
            if min_val is not None and value < min_val:
                errors.append(f"Field '{field}' must be >= {min_val}")
                continue
            if max_val is not None and value > max_val:
                errors.append(f"Field '{field}' must be <= {max_val}")
                continue

            # 선택지 검증
            if choices is not None and value not in choices:
                errors.append(f"Field '{field}' must be one of {choices}")
                continue

            validated[field] = value

        # 엄격 모드: 추가 필드 검증
        if strict:
            extra_fields = set(data.keys()) - set(schema.keys())
            if extra_fields:
                errors.append(f"Unknown fields: {extra_fields}")

        return (validated, errors)
''',
        function_name="_validate_input",
        test_cases=[
            SliceTestCase(
                name="test_valid_input",
                inputs={
                    "data": {"name": "test", "count": 10},
                    "schema": {
                        "name": {"type": str, "required": True},
                        "count": {"type": int, "required": True, "min": 0}
                    }
                },
                expected_output=({"name": "test", "count": 10}, []),
                description="유효한 입력 데이터"
            ),
            SliceTestCase(
                name="test_missing_required",
                inputs={
                    "data": {"name": "test"},
                    "schema": {
                        "name": {"type": str, "required": True},
                        "count": {"type": int, "required": True}
                    }
                },
                expected_output=({"name": "test"}, ["Required field missing: count"]),
                description="필수 필드 누락"
            )
        ],
        metadata=SliceMetadata(
            author="FORGE AI",
            version="1.0.0",
            complexity=0.4,
            reliability=0.98,
            performance_score=0.90,
            tags=["core", "validation", "input", "schema"]
        )
    )


def _create_output_formatting_slice() -> FunctionSlice:
    """출력 포맷팅 슬라이스"""
    return FunctionSlice(
        id="core.output_formatting",
        name="Output Formatting",
        description="에이전트 결과를 다양한 형식으로 포맷팅합니다.",
        category=SliceCategory.CORE,
        domain=SliceDomain.CORE,
        inputs=[
            SliceParameter(
                name="data",
                param_type="Any",
                description="포맷팅할 데이터",
                required=True
            ),
            SliceParameter(
                name="format_type",
                param_type="str",
                description="출력 형식 (json, markdown, html, text, table)",
                default="json",
                required=False
            ),
            SliceParameter(
                name="options",
                param_type="Dict[str, Any]",
                description="포맷팅 옵션 (indent, headers, etc.)",
                default={},
                required=False
            )
        ],
        outputs=[
            SliceParameter(
                name="formatted",
                param_type="str",
                description="포맷팅된 출력 문자열"
            )
        ],
        dependencies=[],
        keywords={
            "ko": ["출력", "포맷", "형식", "변환", "표시", "렌더링"],
            "en": ["output", "format", "formatting", "convert", "render", "display"]
        },
        code_template='''
        import json
        from typing import Any, Dict

        indent = options.get("indent", 2)
        headers = options.get("headers", None)
        title = options.get("title", "")

        if format_type == "json":
            return json.dumps(data, indent=indent, ensure_ascii=False, default=str)

        elif format_type == "markdown":
            lines = []
            if title:
                lines.append(f"# {title}\\n")

            if isinstance(data, dict):
                for key, value in data.items():
                    lines.append(f"**{key}**: {value}")
            elif isinstance(data, list):
                for item in data:
                    lines.append(f"- {item}")
            else:
                lines.append(str(data))

            return "\\n".join(lines)

        elif format_type == "html":
            if isinstance(data, dict):
                rows = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in data.items())
                return f"<table>{rows}</table>"
            elif isinstance(data, list):
                items = "".join(f"<li>{item}</li>" for item in data)
                return f"<ul>{items}</ul>"
            else:
                return f"<p>{data}</p>"

        elif format_type == "table":
            if isinstance(data, list) and len(data) > 0:
                if isinstance(data[0], dict):
                    cols = headers or list(data[0].keys())
                    header_row = " | ".join(cols)
                    separator = " | ".join(["---"] * len(cols))
                    rows = []
                    for item in data:
                        row = " | ".join(str(item.get(col, "")) for col in cols)
                        rows.append(row)
                    return f"{header_row}\\n{separator}\\n" + "\\n".join(rows)
            return str(data)

        else:  # text
            if isinstance(data, dict):
                return "\\n".join(f"{k}: {v}" for k, v in data.items())
            elif isinstance(data, list):
                return "\\n".join(str(item) for item in data)
            return str(data)
''',
        function_name="_format_output",
        test_cases=[
            SliceTestCase(
                name="test_json_format",
                inputs={
                    "data": {"name": "test", "value": 42},
                    "format_type": "json"
                },
                expected_output='{\n  "name": "test",\n  "value": 42\n}',
                description="JSON 포맷 출력"
            ),
            SliceTestCase(
                name="test_markdown_format",
                inputs={
                    "data": {"status": "success", "count": 10},
                    "format_type": "markdown"
                },
                expected_output="**status**: success\n**count**: 10",
                description="Markdown 포맷 출력"
            )
        ],
        metadata=SliceMetadata(
            author="FORGE AI",
            version="1.0.0",
            complexity=0.3,
            reliability=0.99,
            performance_score=0.95,
            tags=["core", "output", "formatting", "serialization"]
        )
    )


def _create_lifecycle_management_slice() -> FunctionSlice:
    """생명주기 관리 슬라이스"""
    return FunctionSlice(
        id="core.lifecycle_management",
        name="Lifecycle Management",
        description="에이전트의 초기화, 실행, 종료 등 생명주기를 관리합니다.",
        category=SliceCategory.CORE,
        domain=SliceDomain.CORE,
        inputs=[
            SliceParameter(
                name="agent_config",
                param_type="Dict[str, Any]",
                description="에이전트 설정",
                required=True
            ),
            SliceParameter(
                name="lifecycle_hooks",
                param_type="Dict[str, Callable]",
                description="생명주기 훅 함수 (on_init, on_start, on_stop, on_error)",
                default={},
                required=False
            )
        ],
        outputs=[
            SliceParameter(
                name="lifecycle_context",
                param_type="Dict[str, Any]",
                description="생명주기 컨텍스트 (상태, 시작 시간, 메트릭스 등)"
            )
        ],
        dependencies=[],
        keywords={
            "ko": ["생명주기", "초기화", "시작", "종료", "상태", "관리"],
            "en": ["lifecycle", "init", "start", "stop", "state", "management"]
        },
        code_template='''
        import time
        from typing import Any, Callable, Dict
        from loguru import logger
        from enum import Enum

        class AgentState(Enum):
            CREATED = "created"
            INITIALIZING = "initializing"
            READY = "ready"
            RUNNING = "running"
            STOPPING = "stopping"
            STOPPED = "stopped"
            ERROR = "error"

        context = {
            "state": AgentState.CREATED.value,
            "created_at": time.time(),
            "started_at": None,
            "stopped_at": None,
            "config": agent_config,
            "metrics": {
                "executions": 0,
                "errors": 0,
                "total_time": 0.0
            }
        }

        def transition(new_state: AgentState, hook_name: str = None):
            old_state = context["state"]
            context["state"] = new_state.value
            logger.debug(f"State transition: {old_state} -> {new_state.value}")

            if hook_name and hook_name in lifecycle_hooks:
                try:
                    lifecycle_hooks[hook_name](context)
                except Exception as e:
                    logger.error(f"Hook '{hook_name}' failed: {e}")

        def initialize():
            transition(AgentState.INITIALIZING, "on_init")
            # 설정 검증 및 리소스 초기화
            context["started_at"] = time.time()
            transition(AgentState.READY)

        def start():
            if context["state"] != AgentState.READY.value:
                raise RuntimeError(f"Cannot start from state: {context['state']}")
            transition(AgentState.RUNNING, "on_start")

        def stop():
            transition(AgentState.STOPPING, "on_stop")
            context["stopped_at"] = time.time()
            transition(AgentState.STOPPED)

        def on_error(error: Exception):
            context["metrics"]["errors"] += 1
            transition(AgentState.ERROR, "on_error")
            logger.error(f"Agent error: {error}")

        # 컨텍스트에 컨트롤 함수 추가
        context["_controls"] = {
            "initialize": initialize,
            "start": start,
            "stop": stop,
            "on_error": on_error,
            "transition": transition
        }

        return context
''',
        function_name="_manage_lifecycle",
        test_cases=[
            SliceTestCase(
                name="test_lifecycle_creation",
                inputs={
                    "agent_config": {"name": "TestAgent", "version": "1.0"},
                    "lifecycle_hooks": {}
                },
                expected_output={"state": "created"},
                description="생명주기 컨텍스트 생성"
            )
        ],
        metadata=SliceMetadata(
            author="FORGE AI",
            version="1.0.0",
            complexity=0.5,
            reliability=0.98,
            performance_score=0.90,
            tags=["core", "lifecycle", "state-management"]
        )
    )


# 편의 함수
def get_core_slice_ids() -> List[str]:
    """Core Slice ID 목록 반환"""
    return [
        "core.error_handling",
        "core.input_validation",
        "core.output_formatting",
        "core.lifecycle_management"
    ]
