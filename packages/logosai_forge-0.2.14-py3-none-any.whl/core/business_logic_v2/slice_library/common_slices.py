"""
Common Function Slices
======================
다수 도메인에서 공유되는 40개의 Common Slices 정의

카테고리:
1. Data Loading (8개) - 다양한 소스에서 데이터 로드
2. Data Processing (10개) - 데이터 변환 및 처리
3. Statistical Analysis (8개) - 통계 분석 및 계산
4. Visualization (6개) - 시각화 및 보고서
5. Utilities (8개) - 범용 유틸리티
"""

from typing import List
from .models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceTestCase,
    SliceMetadata
)


def create_common_slices() -> List[FunctionSlice]:
    """모든 Common Slices 생성 및 반환"""
    slices = []
    slices.extend(create_data_loading_slices())
    slices.extend(create_data_processing_slices())
    slices.extend(create_statistical_slices())
    slices.extend(create_visualization_slices())
    slices.extend(create_utility_slices())
    return slices


# =============================================================================
# Data Loading Slices (8개)
# =============================================================================

def create_data_loading_slices() -> List[FunctionSlice]:
    """Data Loading Slices 생성"""
    return [
        _create_load_csv_slice(),
        _create_load_json_slice(),
        _create_load_excel_slice(),
        _create_load_database_slice(),
        _create_load_api_slice(),
        _create_load_file_slice(),
        _create_load_stream_slice(),
        _create_load_batch_slice(),
    ]


def _create_load_csv_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_csv",
        name="Load CSV",
        description="CSV 파일을 로드하여 데이터프레임으로 변환합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="file_path", param_type="str", description="CSV 파일 경로", required=True),
            SliceParameter(name="encoding", param_type="str", description="파일 인코딩", default="utf-8", required=False),
            SliceParameter(name="delimiter", param_type="str", description="구분자", default=",", required=False),
            SliceParameter(name="header", param_type="bool", description="헤더 포함 여부", default=True, required=False),
        ],
        outputs=[SliceParameter(name="data", param_type="pd.DataFrame", description="로드된 데이터프레임")],
        dependencies=[],
        keywords={
            "ko": ["CSV", "파일", "로드", "읽기", "데이터", "불러오기"],
            "en": ["csv", "file", "load", "read", "data", "import"]
        },
        code_template='''
        import pandas as pd

        df = pd.read_csv(
            file_path,
            encoding=encoding,
            delimiter=delimiter,
            header=0 if header else None
        )
        return df
''',
        function_name="_load_csv",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["data", "io", "csv"])
    )


def _create_load_json_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_json",
        name="Load JSON",
        description="JSON 파일 또는 문자열을 파싱합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="source", param_type="str", description="JSON 파일 경로 또는 JSON 문자열", required=True),
            SliceParameter(name="is_file", param_type="bool", description="파일 여부", default=True, required=False),
        ],
        outputs=[SliceParameter(name="data", param_type="Dict", description="파싱된 JSON 데이터")],
        dependencies=[],
        keywords={
            "ko": ["JSON", "파일", "로드", "파싱", "읽기"],
            "en": ["json", "file", "load", "parse", "read"]
        },
        code_template='''
        import json

        if is_file:
            with open(source, 'r', encoding='utf-8') as f:
                data = json.load(f)
        else:
            data = json.loads(source)
        return data
''',
        function_name="_load_json",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["data", "io", "json"])
    )


def _create_load_excel_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_excel",
        name="Load Excel",
        description="Excel 파일을 로드합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="file_path", param_type="str", description="Excel 파일 경로", required=True),
            SliceParameter(name="sheet_name", param_type="str", description="시트 이름", default=None, required=False),
        ],
        outputs=[SliceParameter(name="data", param_type="pd.DataFrame", description="로드된 데이터프레임")],
        dependencies=[],
        keywords={
            "ko": ["엑셀", "Excel", "파일", "로드", "시트"],
            "en": ["excel", "xlsx", "file", "load", "sheet"]
        },
        code_template='''
        import pandas as pd

        df = pd.read_excel(file_path, sheet_name=sheet_name)
        return df
''',
        function_name="_load_excel",
        metadata=SliceMetadata(complexity=0.2, reliability=0.95, tags=["data", "io", "excel"])
    )


def _create_load_database_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_database",
        name="Load Database",
        description="데이터베이스에서 쿼리 결과를 로드합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="connection_string", param_type="str", description="DB 연결 문자열", required=True),
            SliceParameter(name="query", param_type="str", description="SQL 쿼리", required=True),
            SliceParameter(name="params", param_type="Dict", description="쿼리 파라미터", default={}, required=False),
        ],
        outputs=[SliceParameter(name="data", param_type="pd.DataFrame", description="쿼리 결과")],
        dependencies=["core.error_handling"],
        keywords={
            "ko": ["데이터베이스", "DB", "SQL", "쿼리", "로드"],
            "en": ["database", "db", "sql", "query", "load"]
        },
        code_template='''
        import pandas as pd
        from sqlalchemy import create_engine

        engine = create_engine(connection_string)
        df = pd.read_sql(query, engine, params=params)
        return df
''',
        function_name="_load_database",
        metadata=SliceMetadata(complexity=0.4, reliability=0.92, tags=["data", "io", "database", "sql"])
    )


def _create_load_api_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_api",
        name="Load API",
        description="REST API에서 데이터를 가져옵니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="url", param_type="str", description="API URL", required=True),
            SliceParameter(name="method", param_type="str", description="HTTP 메서드", default="GET", required=False),
            SliceParameter(name="headers", param_type="Dict", description="요청 헤더", default={}, required=False),
            SliceParameter(name="params", param_type="Dict", description="쿼리 파라미터", default={}, required=False),
            SliceParameter(name="body", param_type="Dict", description="요청 본문", default=None, required=False),
        ],
        outputs=[SliceParameter(name="response", param_type="Dict", description="API 응답")],
        dependencies=["core.error_handling"],
        keywords={
            "ko": ["API", "REST", "HTTP", "요청", "응답", "웹"],
            "en": ["api", "rest", "http", "request", "response", "web"]
        },
        code_template='''
        import requests

        if method.upper() == "GET":
            response = requests.get(url, headers=headers, params=params)
        elif method.upper() == "POST":
            response = requests.post(url, headers=headers, params=params, json=body)
        elif method.upper() == "PUT":
            response = requests.put(url, headers=headers, params=params, json=body)
        elif method.upper() == "DELETE":
            response = requests.delete(url, headers=headers, params=params)
        else:
            raise ValueError(f"Unsupported method: {method}")

        response.raise_for_status()
        return response.json()
''',
        function_name="_load_api",
        metadata=SliceMetadata(complexity=0.3, reliability=0.90, tags=["data", "io", "api", "http"])
    )


def _create_load_file_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_file",
        name="Load File",
        description="일반 텍스트 파일을 로드합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="file_path", param_type="str", description="파일 경로", required=True),
            SliceParameter(name="mode", param_type="str", description="읽기 모드", default="r", required=False),
            SliceParameter(name="encoding", param_type="str", description="인코딩", default="utf-8", required=False),
        ],
        outputs=[SliceParameter(name="content", param_type="str", description="파일 내용")],
        dependencies=[],
        keywords={
            "ko": ["파일", "텍스트", "로드", "읽기"],
            "en": ["file", "text", "load", "read"]
        },
        code_template='''
        with open(file_path, mode, encoding=encoding) as f:
            content = f.read()
        return content
''',
        function_name="_load_file",
        metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["data", "io", "file"])
    )


def _create_load_stream_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_stream",
        name="Load Stream",
        description="스트리밍 데이터를 청크 단위로 로드합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="source", param_type="Iterator", description="데이터 스트림", required=True),
            SliceParameter(name="chunk_size", param_type="int", description="청크 크기", default=1024, required=False),
            SliceParameter(name="max_chunks", param_type="int", description="최대 청크 수", default=None, required=False),
        ],
        outputs=[SliceParameter(name="chunks", param_type="List", description="청크 목록")],
        dependencies=[],
        keywords={
            "ko": ["스트림", "청크", "실시간", "로드"],
            "en": ["stream", "chunk", "realtime", "load"]
        },
        code_template='''
        chunks = []
        count = 0
        for chunk in source:
            chunks.append(chunk)
            count += 1
            if max_chunks and count >= max_chunks:
                break
        return chunks
''',
        function_name="_load_stream",
        metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["data", "io", "stream"])
    )


def _create_load_batch_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.data.load_batch",
        name="Load Batch",
        description="여러 파일을 배치로 로드합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="file_paths", param_type="List[str]", description="파일 경로 목록", required=True),
            SliceParameter(name="loader_func", param_type="Callable", description="로더 함수", required=True),
            SliceParameter(name="parallel", param_type="bool", description="병렬 로드 여부", default=False, required=False),
        ],
        outputs=[SliceParameter(name="data_list", param_type="List", description="로드된 데이터 목록")],
        dependencies=["core.error_handling"],
        keywords={
            "ko": ["배치", "다중", "파일", "병렬", "로드"],
            "en": ["batch", "multiple", "files", "parallel", "load"]
        },
        code_template='''
        from concurrent.futures import ThreadPoolExecutor

        if parallel:
            with ThreadPoolExecutor() as executor:
                data_list = list(executor.map(loader_func, file_paths))
        else:
            data_list = [loader_func(path) for path in file_paths]
        return data_list
''',
        function_name="_load_batch",
        metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["data", "io", "batch", "parallel"])
    )


# =============================================================================
# Data Processing Slices (10개)
# =============================================================================

def create_data_processing_slices() -> List[FunctionSlice]:
    """Data Processing Slices 생성"""
    return [
        _create_filter_data_slice(),
        _create_sort_data_slice(),
        _create_group_data_slice(),
        _create_aggregate_data_slice(),
        _create_merge_data_slice(),
        _create_transform_data_slice(),
        _create_clean_data_slice(),
        _create_validate_data_slice(),
        _create_normalize_data_slice(),
        _create_encode_data_slice(),
    ]


def _create_filter_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.filter",
        name="Filter Data",
        description="조건에 따라 데이터를 필터링합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="conditions", param_type="Dict", description="필터 조건 {column: value}", required=True),
            SliceParameter(name="operator", param_type="str", description="조건 연산자 (and/or)", default="and", required=False),
        ],
        outputs=[SliceParameter(name="filtered", param_type="pd.DataFrame", description="필터링된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["필터", "조건", "선택", "추출", "걸러내기"],
            "en": ["filter", "condition", "select", "extract", "where"]
        },
        code_template='''
        import pandas as pd

        mask = None
        for col, val in conditions.items():
            if isinstance(val, list):
                col_mask = data[col].isin(val)
            elif isinstance(val, tuple) and len(val) == 2:
                col_mask = (data[col] >= val[0]) & (data[col] <= val[1])
            else:
                col_mask = data[col] == val

            if mask is None:
                mask = col_mask
            elif operator == "and":
                mask = mask & col_mask
            else:
                mask = mask | col_mask

        return data[mask] if mask is not None else data
''',
        function_name="_filter_data",
        metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["data", "process", "filter"])
    )


def _create_sort_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.sort",
        name="Sort Data",
        description="데이터를 정렬합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="by", param_type="List[str]", description="정렬 기준 컬럼", required=True),
            SliceParameter(name="ascending", param_type="bool", description="오름차순 여부", default=True, required=False),
        ],
        outputs=[SliceParameter(name="sorted", param_type="pd.DataFrame", description="정렬된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["정렬", "순서", "오름차순", "내림차순"],
            "en": ["sort", "order", "ascending", "descending"]
        },
        code_template='''
        return data.sort_values(by=by, ascending=ascending)
''',
        function_name="_sort_data",
        metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["data", "process", "sort"])
    )


def _create_group_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.group",
        name="Group Data",
        description="데이터를 그룹화합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="by", param_type="List[str]", description="그룹화 기준 컬럼", required=True),
            SliceParameter(name="agg_func", param_type="Dict", description="집계 함수 {컬럼: 함수}", required=True),
        ],
        outputs=[SliceParameter(name="grouped", param_type="pd.DataFrame", description="그룹화된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["그룹", "집계", "분류", "묶기"],
            "en": ["group", "aggregate", "groupby", "cluster"]
        },
        code_template='''
        grouped = data.groupby(by).agg(agg_func).reset_index()
        return grouped
''',
        function_name="_group_data",
        metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["data", "process", "group"])
    )


def _create_aggregate_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.aggregate",
        name="Aggregate Data",
        description="데이터를 집계합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="functions", param_type="Dict", description="집계 함수 {컬럼: [함수들]}", required=True),
        ],
        outputs=[SliceParameter(name="aggregated", param_type="Dict", description="집계 결과")],
        dependencies=[],
        keywords={
            "ko": ["집계", "합계", "평균", "개수", "통계"],
            "en": ["aggregate", "sum", "mean", "count", "stats"]
        },
        code_template='''
        result = {}
        for col, funcs in functions.items():
            if not isinstance(funcs, list):
                funcs = [funcs]
            for func in funcs:
                key = f"{col}_{func}"
                if func == "sum":
                    result[key] = data[col].sum()
                elif func == "mean":
                    result[key] = data[col].mean()
                elif func == "count":
                    result[key] = data[col].count()
                elif func == "min":
                    result[key] = data[col].min()
                elif func == "max":
                    result[key] = data[col].max()
        return result
''',
        function_name="_aggregate_data",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["data", "process", "aggregate"])
    )


def _create_merge_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.merge",
        name="Merge Data",
        description="두 데이터셋을 병합합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="left", param_type="pd.DataFrame", description="왼쪽 데이터", required=True),
            SliceParameter(name="right", param_type="pd.DataFrame", description="오른쪽 데이터", required=True),
            SliceParameter(name="on", param_type="List[str]", description="조인 키", required=True),
            SliceParameter(name="how", param_type="str", description="조인 방식", default="inner", required=False),
        ],
        outputs=[SliceParameter(name="merged", param_type="pd.DataFrame", description="병합된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["병합", "조인", "결합", "합치기"],
            "en": ["merge", "join", "combine", "concat"]
        },
        code_template='''
        return left.merge(right, on=on, how=how)
''',
        function_name="_merge_data",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["data", "process", "merge", "join"])
    )


def _create_transform_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.transform",
        name="Transform Data",
        description="데이터 변환 함수를 적용합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="transformations", param_type="Dict", description="변환 함수 {컬럼: 함수}", required=True),
        ],
        outputs=[SliceParameter(name="transformed", param_type="pd.DataFrame", description="변환된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["변환", "적용", "매핑", "처리"],
            "en": ["transform", "apply", "map", "process"]
        },
        code_template='''
        result = data.copy()
        for col, func in transformations.items():
            if col in result.columns:
                result[col] = result[col].apply(func)
        return result
''',
        function_name="_transform_data",
        metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["data", "process", "transform"])
    )


def _create_clean_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.clean",
        name="Clean Data",
        description="데이터를 정제합니다 (결측치, 중복 처리).",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="drop_na", param_type="bool", description="결측치 제거", default=False, required=False),
            SliceParameter(name="fill_na", param_type="Any", description="결측치 대체값", default=None, required=False),
            SliceParameter(name="drop_duplicates", param_type="bool", description="중복 제거", default=False, required=False),
        ],
        outputs=[SliceParameter(name="cleaned", param_type="pd.DataFrame", description="정제된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["정제", "클린", "결측치", "중복", "정리"],
            "en": ["clean", "cleanse", "missing", "duplicate", "null"]
        },
        code_template='''
        result = data.copy()
        if drop_na:
            result = result.dropna()
        elif fill_na is not None:
            result = result.fillna(fill_na)
        if drop_duplicates:
            result = result.drop_duplicates()
        return result
''',
        function_name="_clean_data",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["data", "process", "clean"])
    )


def _create_validate_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.validate_data",
        name="Validate Data",
        description="데이터 품질을 검증합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="rules", param_type="Dict", description="검증 규칙", required=True),
        ],
        outputs=[
            SliceParameter(name="is_valid", param_type="bool", description="검증 통과 여부"),
            SliceParameter(name="errors", param_type="List", description="오류 목록"),
        ],
        dependencies=[],
        keywords={
            "ko": ["검증", "품질", "확인", "체크"],
            "en": ["validate", "quality", "check", "verify"]
        },
        code_template='''
        errors = []
        for col, rule in rules.items():
            if col not in data.columns:
                errors.append(f"Column missing: {col}")
                continue
            if "not_null" in rule and data[col].isnull().any():
                errors.append(f"Null values in: {col}")
            if "unique" in rule and data[col].duplicated().any():
                errors.append(f"Duplicate values in: {col}")
            if "min" in rule and (data[col] < rule["min"]).any():
                errors.append(f"Values below min in: {col}")
            if "max" in rule and (data[col] > rule["max"]).any():
                errors.append(f"Values above max in: {col}")
        return (len(errors) == 0, errors)
''',
        function_name="_validate_data",
        metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["data", "process", "validate"])
    )


def _create_normalize_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.normalize",
        name="Normalize Data",
        description="데이터를 정규화합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="columns", param_type="List[str]", description="정규화할 컬럼", required=True),
            SliceParameter(name="method", param_type="str", description="정규화 방법", default="minmax", required=False),
        ],
        outputs=[SliceParameter(name="normalized", param_type="pd.DataFrame", description="정규화된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["정규화", "스케일링", "표준화"],
            "en": ["normalize", "scale", "standardize", "minmax"]
        },
        code_template='''
        result = data.copy()
        for col in columns:
            if col not in result.columns:
                continue
            if method == "minmax":
                min_val = result[col].min()
                max_val = result[col].max()
                result[col] = (result[col] - min_val) / (max_val - min_val + 1e-10)
            elif method == "zscore":
                mean = result[col].mean()
                std = result[col].std()
                result[col] = (result[col] - mean) / (std + 1e-10)
        return result
''',
        function_name="_normalize_data",
        metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["data", "process", "normalize"])
    )


def _create_encode_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.process.encode",
        name="Encode Data",
        description="범주형 데이터를 인코딩합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="입력 데이터", required=True),
            SliceParameter(name="columns", param_type="List[str]", description="인코딩할 컬럼", required=True),
            SliceParameter(name="method", param_type="str", description="인코딩 방법", default="label", required=False),
        ],
        outputs=[SliceParameter(name="encoded", param_type="pd.DataFrame", description="인코딩된 데이터")],
        dependencies=[],
        keywords={
            "ko": ["인코딩", "범주형", "원핫", "라벨"],
            "en": ["encode", "categorical", "onehot", "label"]
        },
        code_template='''
        import pandas as pd

        result = data.copy()
        for col in columns:
            if col not in result.columns:
                continue
            if method == "label":
                result[col] = result[col].astype('category').cat.codes
            elif method == "onehot":
                dummies = pd.get_dummies(result[col], prefix=col)
                result = result.drop(col, axis=1)
                result = pd.concat([result, dummies], axis=1)
        return result
''',
        function_name="_encode_data",
        metadata=SliceMetadata(complexity=0.3, reliability=0.96, tags=["data", "process", "encode"])
    )


# =============================================================================
# Statistical Analysis Slices (8개)
# =============================================================================

def create_statistical_slices() -> List[FunctionSlice]:
    """Statistical Analysis Slices 생성"""
    return [
        _create_calculate_mean_slice(),
        _create_calculate_median_slice(),
        _create_calculate_std_slice(),
        _create_calculate_correlation_slice(),
        _create_calculate_percentile_slice(),
        _create_detect_outliers_slice(),
        _create_calculate_distribution_slice(),
        _create_statistical_test_slice(),
    ]


def _create_calculate_mean_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.mean",
        name="Calculate Mean",
        description="평균을 계산합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="List[float]", description="숫자 데이터", required=True),
            SliceParameter(name="weights", param_type="List[float]", description="가중치", default=None, required=False),
        ],
        outputs=[SliceParameter(name="mean", param_type="float", description="평균값")],
        dependencies=[],
        keywords={
            "ko": ["평균", "산술평균", "가중평균"],
            "en": ["mean", "average", "weighted"]
        },
        code_template='''
        import numpy as np
        if weights is not None:
            return np.average(data, weights=weights)
        return np.mean(data)
''',
        function_name="_calculate_mean",
        metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["stats", "mean"])
    )


def _create_calculate_median_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.median",
        name="Calculate Median",
        description="중앙값을 계산합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="List[float]", description="숫자 데이터", required=True),
        ],
        outputs=[SliceParameter(name="median", param_type="float", description="중앙값")],
        dependencies=[],
        keywords={
            "ko": ["중앙값", "중간값", "미디언"],
            "en": ["median", "middle"]
        },
        code_template='''
        import numpy as np
        return np.median(data)
''',
        function_name="_calculate_median",
        metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["stats", "median"])
    )


def _create_calculate_std_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.std",
        name="Calculate Standard Deviation",
        description="표준편차를 계산합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="List[float]", description="숫자 데이터", required=True),
            SliceParameter(name="ddof", param_type="int", description="자유도 보정", default=1, required=False),
        ],
        outputs=[SliceParameter(name="std", param_type="float", description="표준편차")],
        dependencies=[],
        keywords={
            "ko": ["표준편차", "분산", "변동성"],
            "en": ["std", "standard deviation", "variance"]
        },
        code_template='''
        import numpy as np
        return np.std(data, ddof=ddof)
''',
        function_name="_calculate_std",
        metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["stats", "std"])
    )


def _create_calculate_correlation_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.correlation",
        name="Calculate Correlation",
        description="상관관계를 계산합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="x", param_type="List[float]", description="첫 번째 변수", required=True),
            SliceParameter(name="y", param_type="List[float]", description="두 번째 변수", required=True),
            SliceParameter(name="method", param_type="str", description="상관계수 방법", default="pearson", required=False),
        ],
        outputs=[SliceParameter(name="correlation", param_type="float", description="상관계수")],
        dependencies=[],
        keywords={
            "ko": ["상관관계", "상관계수", "피어슨", "스피어만"],
            "en": ["correlation", "pearson", "spearman"]
        },
        code_template='''
        import numpy as np
        from scipy import stats

        if method == "pearson":
            corr, _ = stats.pearsonr(x, y)
        elif method == "spearman":
            corr, _ = stats.spearmanr(x, y)
        else:
            corr = np.corrcoef(x, y)[0, 1]
        return corr
''',
        function_name="_calculate_correlation",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["stats", "correlation"])
    )


def _create_calculate_percentile_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.percentile",
        name="Calculate Percentile",
        description="백분위수를 계산합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="List[float]", description="숫자 데이터", required=True),
            SliceParameter(name="percentiles", param_type="List[float]", description="백분위수 (0-100)", required=True),
        ],
        outputs=[SliceParameter(name="values", param_type="Dict", description="백분위수별 값")],
        dependencies=[],
        keywords={
            "ko": ["백분위", "분위수", "퍼센타일"],
            "en": ["percentile", "quantile"]
        },
        code_template='''
        import numpy as np
        result = {}
        for p in percentiles:
            result[f"p{int(p)}"] = np.percentile(data, p)
        return result
''',
        function_name="_calculate_percentile",
        metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["stats", "percentile"])
    )


def _create_detect_outliers_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.outliers",
        name="Detect Outliers",
        description="이상치를 탐지합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="List[float]", description="숫자 데이터", required=True),
            SliceParameter(name="method", param_type="str", description="탐지 방법", default="iqr", required=False),
            SliceParameter(name="threshold", param_type="float", description="임계값", default=1.5, required=False),
        ],
        outputs=[
            SliceParameter(name="outliers", param_type="List[int]", description="이상치 인덱스"),
            SliceParameter(name="bounds", param_type="Tuple", description="정상 범위 (lower, upper)"),
        ],
        dependencies=[],
        keywords={
            "ko": ["이상치", "아웃라이어", "탐지", "감지"],
            "en": ["outlier", "anomaly", "detect", "abnormal"]
        },
        code_template='''
        import numpy as np

        data = np.array(data)
        if method == "iqr":
            q1 = np.percentile(data, 25)
            q3 = np.percentile(data, 75)
            iqr = q3 - q1
            lower = q1 - threshold * iqr
            upper = q3 + threshold * iqr
        elif method == "zscore":
            mean = np.mean(data)
            std = np.std(data)
            lower = mean - threshold * std
            upper = mean + threshold * std

        outlier_idx = np.where((data < lower) | (data > upper))[0].tolist()
        return (outlier_idx, (lower, upper))
''',
        function_name="_detect_outliers",
        metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["stats", "outlier"])
    )


def _create_calculate_distribution_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.distribution",
        name="Calculate Distribution",
        description="데이터 분포를 분석합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="List[float]", description="숫자 데이터", required=True),
            SliceParameter(name="bins", param_type="int", description="히스토그램 빈 수", default=10, required=False),
        ],
        outputs=[SliceParameter(name="stats", param_type="Dict", description="분포 통계")],
        dependencies=[],
        keywords={
            "ko": ["분포", "히스토그램", "왜도", "첨도"],
            "en": ["distribution", "histogram", "skewness", "kurtosis"]
        },
        code_template='''
        import numpy as np
        from scipy import stats as sp_stats

        data = np.array(data)
        hist, bin_edges = np.histogram(data, bins=bins)

        return {
            "mean": float(np.mean(data)),
            "std": float(np.std(data)),
            "skewness": float(sp_stats.skew(data)),
            "kurtosis": float(sp_stats.kurtosis(data)),
            "histogram": {"counts": hist.tolist(), "edges": bin_edges.tolist()}
        }
''',
        function_name="_calculate_distribution",
        metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["stats", "distribution"])
    )


def _create_statistical_test_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.stats.test",
        name="Statistical Test",
        description="통계적 가설 검정을 수행합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="sample1", param_type="List[float]", description="첫 번째 샘플", required=True),
            SliceParameter(name="sample2", param_type="List[float]", description="두 번째 샘플", default=None, required=False),
            SliceParameter(name="test_type", param_type="str", description="검정 유형", default="ttest", required=False),
            SliceParameter(name="alpha", param_type="float", description="유의수준", default=0.05, required=False),
        ],
        outputs=[SliceParameter(name="result", param_type="Dict", description="검정 결과")],
        dependencies=[],
        keywords={
            "ko": ["검정", "가설", "t검정", "카이제곱"],
            "en": ["test", "hypothesis", "ttest", "chi-square"]
        },
        code_template='''
        from scipy import stats

        if test_type == "ttest":
            if sample2 is not None:
                stat, pvalue = stats.ttest_ind(sample1, sample2)
            else:
                stat, pvalue = stats.ttest_1samp(sample1, 0)
        elif test_type == "shapiro":
            stat, pvalue = stats.shapiro(sample1)
        elif test_type == "anova" and sample2 is not None:
            stat, pvalue = stats.f_oneway(sample1, sample2)

        return {
            "statistic": float(stat),
            "pvalue": float(pvalue),
            "significant": pvalue < alpha
        }
''',
        function_name="_statistical_test",
        metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["stats", "test", "hypothesis"])
    )


# =============================================================================
# Visualization Slices (6개)
# =============================================================================

def create_visualization_slices() -> List[FunctionSlice]:
    """Visualization Slices 생성"""
    return [
        _create_chart_slice(),
        _create_table_slice(),
        _create_report_slice(),
        _create_format_output_slice(),
        _create_export_data_slice(),
        _create_summary_slice(),
    ]


def _create_chart_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.viz.chart",
        name="Create Chart",
        description="차트를 생성합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="차트 데이터", required=True),
            SliceParameter(name="chart_type", param_type="str", description="차트 유형", default="line", required=False),
            SliceParameter(name="x", param_type="str", description="X축 컬럼", required=True),
            SliceParameter(name="y", param_type="str", description="Y축 컬럼", required=True),
            SliceParameter(name="title", param_type="str", description="차트 제목", default="", required=False),
        ],
        outputs=[SliceParameter(name="chart", param_type="Any", description="차트 객체")],
        dependencies=[],
        keywords={
            "ko": ["차트", "그래프", "시각화", "플롯"],
            "en": ["chart", "graph", "visualization", "plot"]
        },
        code_template='''
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(10, 6))

        if chart_type == "line":
            ax.plot(data[x], data[y])
        elif chart_type == "bar":
            ax.bar(data[x], data[y])
        elif chart_type == "scatter":
            ax.scatter(data[x], data[y])
        elif chart_type == "pie":
            ax.pie(data[y], labels=data[x], autopct='%1.1f%%')

        ax.set_xlabel(x)
        ax.set_ylabel(y)
        ax.set_title(title)

        return fig
''',
        function_name="_create_chart",
        metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["viz", "chart"])
    )


def _create_table_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.viz.table",
        name="Create Table",
        description="테이블을 생성합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="테이블 데이터", required=True),
            SliceParameter(name="format_type", param_type="str", description="출력 형식", default="markdown", required=False),
            SliceParameter(name="max_rows", param_type="int", description="최대 행 수", default=None, required=False),
        ],
        outputs=[SliceParameter(name="table", param_type="str", description="테이블 문자열")],
        dependencies=[],
        keywords={
            "ko": ["테이블", "표", "데이터"],
            "en": ["table", "data", "grid"]
        },
        code_template='''
        if max_rows:
            data = data.head(max_rows)

        if format_type == "markdown":
            return data.to_markdown()
        elif format_type == "html":
            return data.to_html()
        elif format_type == "csv":
            return data.to_csv(index=False)
        return str(data)
''',
        function_name="_create_table",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["viz", "table"])
    )


def _create_report_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.viz.report",
        name="Create Report",
        description="분석 보고서를 생성합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="title", param_type="str", description="보고서 제목", required=True),
            SliceParameter(name="sections", param_type="List[Dict]", description="섹션 목록", required=True),
            SliceParameter(name="format_type", param_type="str", description="출력 형식", default="markdown", required=False),
        ],
        outputs=[SliceParameter(name="report", param_type="str", description="보고서 문자열")],
        dependencies=[],
        keywords={
            "ko": ["보고서", "리포트", "문서"],
            "en": ["report", "document", "summary"]
        },
        code_template='''
        lines = [f"# {title}\\n"]

        for section in sections:
            lines.append(f"## {section.get('title', 'Section')}\\n")
            content = section.get('content', '')
            if isinstance(content, dict):
                for k, v in content.items():
                    lines.append(f"- **{k}**: {v}")
            else:
                lines.append(str(content))
            lines.append("")

        return "\\n".join(lines)
''',
        function_name="_create_report",
        metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["viz", "report"])
    )


def _create_format_output_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.viz.format",
        name="Format Output",
        description="출력을 포맷팅합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="Any", description="포맷팅할 데이터", required=True),
            SliceParameter(name="template", param_type="str", description="포맷 템플릿", required=True),
        ],
        outputs=[SliceParameter(name="formatted", param_type="str", description="포맷팅된 문자열")],
        dependencies=[],
        keywords={
            "ko": ["포맷", "형식", "출력"],
            "en": ["format", "output", "template"]
        },
        code_template='''
        if isinstance(data, dict):
            return template.format(**data)
        elif isinstance(data, (list, tuple)):
            return template.format(*data)
        return template.format(data)
''',
        function_name="_format_output",
        metadata=SliceMetadata(complexity=0.1, reliability=0.98, tags=["viz", "format"])
    )


def _create_export_data_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.viz.export",
        name="Export Data",
        description="데이터를 파일로 내보냅니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.DATA_IO,
        inputs=[
            SliceParameter(name="data", param_type="Any", description="내보낼 데이터", required=True),
            SliceParameter(name="file_path", param_type="str", description="저장 경로", required=True),
            SliceParameter(name="format_type", param_type="str", description="파일 형식", default="json", required=False),
        ],
        outputs=[SliceParameter(name="success", param_type="bool", description="성공 여부")],
        dependencies=["core.error_handling"],
        keywords={
            "ko": ["내보내기", "저장", "출력"],
            "en": ["export", "save", "output"]
        },
        code_template='''
        import json
        import pandas as pd

        try:
            if format_type == "json":
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            elif format_type == "csv" and isinstance(data, pd.DataFrame):
                data.to_csv(file_path, index=False)
            elif format_type == "excel" and isinstance(data, pd.DataFrame):
                data.to_excel(file_path, index=False)
            return True
        except Exception:
            return False
''',
        function_name="_export_data",
        metadata=SliceMetadata(complexity=0.2, reliability=0.95, tags=["viz", "export", "io"])
    )


def _create_summary_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.viz.summary",
        name="Generate Summary",
        description="데이터 요약을 생성합니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.ANALYTICS,
        inputs=[
            SliceParameter(name="data", param_type="pd.DataFrame", description="요약할 데이터", required=True),
            SliceParameter(name="include", param_type="List[str]", description="포함할 통계", default=None, required=False),
        ],
        outputs=[SliceParameter(name="summary", param_type="Dict", description="요약 통계")],
        dependencies=[],
        keywords={
            "ko": ["요약", "통계", "개요"],
            "en": ["summary", "statistics", "overview"]
        },
        code_template='''
        summary = {
            "shape": data.shape,
            "columns": list(data.columns),
            "dtypes": {col: str(dtype) for col, dtype in data.dtypes.items()},
            "missing": data.isnull().sum().to_dict(),
            "describe": data.describe().to_dict()
        }
        return summary
''',
        function_name="_generate_summary",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["viz", "summary"])
    )


# =============================================================================
# Utility Slices (8개)
# =============================================================================

def create_utility_slices() -> List[FunctionSlice]:
    """Utility Slices 생성"""
    return [
        _create_date_utils_slice(),
        _create_string_utils_slice(),
        _create_math_utils_slice(),
        _create_type_utils_slice(),
        _create_cache_utils_slice(),
        _create_logging_utils_slice(),
        _create_config_utils_slice(),
        _create_async_utils_slice(),
    ]


def _create_date_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.date",
        name="Date Utilities",
        description="날짜/시간 유틸리티 함수들입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="date_str", param_type="str", description="날짜 문자열", required=True),
            SliceParameter(name="format_in", param_type="str", description="입력 형식", default="%Y-%m-%d", required=False),
            SliceParameter(name="format_out", param_type="str", description="출력 형식", default=None, required=False),
        ],
        outputs=[SliceParameter(name="result", param_type="Any", description="변환된 날짜")],
        dependencies=[],
        keywords={
            "ko": ["날짜", "시간", "변환", "포맷"],
            "en": ["date", "time", "convert", "format"]
        },
        code_template='''
        from datetime import datetime

        dt = datetime.strptime(date_str, format_in)
        if format_out:
            return dt.strftime(format_out)
        return dt
''',
        function_name="_date_utils",
        metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["util", "date"])
    )


def _create_string_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.string",
        name="String Utilities",
        description="문자열 유틸리티 함수들입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="text", param_type="str", description="입력 문자열", required=True),
            SliceParameter(name="operation", param_type="str", description="연산 유형", required=True),
            SliceParameter(name="args", param_type="Dict", description="추가 인자", default={}, required=False),
        ],
        outputs=[SliceParameter(name="result", param_type="str", description="처리된 문자열")],
        dependencies=[],
        keywords={
            "ko": ["문자열", "텍스트", "변환"],
            "en": ["string", "text", "convert"]
        },
        code_template='''
        import re

        if operation == "upper":
            return text.upper()
        elif operation == "lower":
            return text.lower()
        elif operation == "strip":
            return text.strip()
        elif operation == "replace":
            return text.replace(args.get("old", ""), args.get("new", ""))
        elif operation == "split":
            return text.split(args.get("delimiter", " "))
        elif operation == "regex":
            pattern = args.get("pattern", "")
            return re.findall(pattern, text)
        return text
''',
        function_name="_string_utils",
        metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["util", "string"])
    )


def _create_math_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.math",
        name="Math Utilities",
        description="수학 유틸리티 함수들입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="operation", param_type="str", description="연산 유형", required=True),
            SliceParameter(name="values", param_type="List[float]", description="입력 값", required=True),
        ],
        outputs=[SliceParameter(name="result", param_type="float", description="계산 결과")],
        dependencies=[],
        keywords={
            "ko": ["수학", "계산", "연산"],
            "en": ["math", "calculate", "compute"]
        },
        code_template='''
        import math

        if operation == "sum":
            return sum(values)
        elif operation == "product":
            result = 1
            for v in values:
                result *= v
            return result
        elif operation == "power":
            return math.pow(values[0], values[1])
        elif operation == "sqrt":
            return math.sqrt(values[0])
        elif operation == "log":
            return math.log(values[0], values[1] if len(values) > 1 else math.e)
        return 0
''',
        function_name="_math_utils",
        metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["util", "math"])
    )


def _create_type_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.type",
        name="Type Utilities",
        description="타입 변환 및 검사 유틸리티입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="value", param_type="Any", description="입력 값", required=True),
            SliceParameter(name="target_type", param_type="str", description="목표 타입", required=True),
        ],
        outputs=[SliceParameter(name="result", param_type="Any", description="변환된 값")],
        dependencies=[],
        keywords={
            "ko": ["타입", "변환", "캐스팅"],
            "en": ["type", "convert", "cast"]
        },
        code_template='''
        type_map = {
            "int": int,
            "float": float,
            "str": str,
            "bool": bool,
            "list": list,
            "dict": dict,
        }

        if target_type in type_map:
            return type_map[target_type](value)
        return value
''',
        function_name="_type_utils",
        metadata=SliceMetadata(complexity=0.1, reliability=0.97, tags=["util", "type"])
    )


def _create_cache_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.cache",
        name="Cache Utilities",
        description="캐싱 유틸리티입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="key", param_type="str", description="캐시 키", required=True),
            SliceParameter(name="value", param_type="Any", description="캐시 값", default=None, required=False),
            SliceParameter(name="operation", param_type="str", description="연산 (get/set/delete)", default="get", required=False),
        ],
        outputs=[SliceParameter(name="result", param_type="Any", description="캐시 결과")],
        dependencies=[],
        keywords={
            "ko": ["캐시", "저장", "조회"],
            "en": ["cache", "store", "retrieve"]
        },
        code_template='''
        from functools import lru_cache

        # Simple in-memory cache
        if not hasattr(self, '_cache'):
            self._cache = {}

        if operation == "get":
            return self._cache.get(key)
        elif operation == "set":
            self._cache[key] = value
            return True
        elif operation == "delete":
            if key in self._cache:
                del self._cache[key]
            return True
        elif operation == "clear":
            self._cache.clear()
            return True
        return None
''',
        function_name="_cache_utils",
        metadata=SliceMetadata(complexity=0.2, reliability=0.95, tags=["util", "cache"])
    )


def _create_logging_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.logging",
        name="Logging Utilities",
        description="로깅 유틸리티입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="message", param_type="str", description="로그 메시지", required=True),
            SliceParameter(name="level", param_type="str", description="로그 레벨", default="info", required=False),
            SliceParameter(name="context", param_type="Dict", description="추가 컨텍스트", default={}, required=False),
        ],
        outputs=[SliceParameter(name="logged", param_type="bool", description="로깅 성공 여부")],
        dependencies=[],
        keywords={
            "ko": ["로깅", "로그", "기록"],
            "en": ["logging", "log", "record"]
        },
        code_template='''
        from loguru import logger

        log_func = getattr(logger, level, logger.info)
        log_func(f"{message} | {context}")
        return True
''',
        function_name="_logging_utils",
        metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["util", "logging"])
    )


def _create_config_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.config",
        name="Config Utilities",
        description="설정 관리 유틸리티입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="config_path", param_type="str", description="설정 파일 경로", required=True),
            SliceParameter(name="key", param_type="str", description="설정 키", default=None, required=False),
            SliceParameter(name="default", param_type="Any", description="기본값", default=None, required=False),
        ],
        outputs=[SliceParameter(name="config", param_type="Any", description="설정 값")],
        dependencies=["common.data.load_json"],
        keywords={
            "ko": ["설정", "구성", "환경"],
            "en": ["config", "configuration", "settings"]
        },
        code_template='''
        import os
        import json
        import yaml

        if config_path.endswith('.json'):
            with open(config_path) as f:
                config = json.load(f)
        elif config_path.endswith(('.yaml', '.yml')):
            with open(config_path) as f:
                config = yaml.safe_load(f)
        elif config_path.startswith('env:'):
            env_key = config_path[4:]
            return os.getenv(env_key, default)

        if key:
            keys = key.split('.')
            for k in keys:
                config = config.get(k, {})
            return config if config else default
        return config
''',
        function_name="_config_utils",
        metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["util", "config"])
    )


def _create_async_utils_slice() -> FunctionSlice:
    return FunctionSlice(
        id="common.util.async",
        name="Async Utilities",
        description="비동기 처리 유틸리티입니다.",
        category=SliceCategory.COMMON,
        domain=SliceDomain.COMMON,
        inputs=[
            SliceParameter(name="tasks", param_type="List[Callable]", description="실행할 태스크 목록", required=True),
            SliceParameter(name="max_concurrent", param_type="int", description="최대 동시 실행 수", default=10, required=False),
        ],
        outputs=[SliceParameter(name="results", param_type="List", description="실행 결과 목록")],
        dependencies=["core.error_handling"],
        keywords={
            "ko": ["비동기", "동시", "병렬"],
            "en": ["async", "concurrent", "parallel"]
        },
        code_template='''
        import asyncio
        from typing import List, Callable

        async def run_tasks(tasks: List[Callable], max_concurrent: int):
            semaphore = asyncio.Semaphore(max_concurrent)

            async def run_with_semaphore(task):
                async with semaphore:
                    if asyncio.iscoroutinefunction(task):
                        return await task()
                    return task()

            results = await asyncio.gather(*[run_with_semaphore(t) for t in tasks])
            return results

        return asyncio.run(run_tasks(tasks, max_concurrent))
''',
        function_name="_async_utils",
        metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["util", "async"])
    )


# 편의 함수
def get_common_slice_count() -> int:
    """Common Slice 총 개수 반환"""
    return (
        len(create_data_loading_slices()) +
        len(create_data_processing_slices()) +
        len(create_statistical_slices()) +
        len(create_visualization_slices()) +
        len(create_utility_slices())
    )
