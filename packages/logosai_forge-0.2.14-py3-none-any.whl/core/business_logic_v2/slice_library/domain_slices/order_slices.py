"""
Order Management Domain Function Slices
========================================
주문 관리 도메인 특화 슬라이스 (10개)

카테고리:
1. Order Processing (4개) - 주문 처리
2. Pricing & Discount (3개) - 가격/할인
3. Order Fulfillment (3개) - 주문 이행
"""

from typing import List
from ..models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceMetadata
)


def create_order_slices() -> List[FunctionSlice]:
    """Order Management Domain Slices 생성"""
    slices = []
    slices.extend(_create_order_processing_slices())
    slices.extend(_create_pricing_slices())
    slices.extend(_create_fulfillment_slices())
    return slices


# =============================================================================
# Order Processing Slices (4개)
# =============================================================================

def _create_order_processing_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="order.process.validate",
            name="Order Validation",
            description="주문 데이터를 검증합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_data", param_type="Dict[str, Any]", description="주문 데이터", required=True),
                SliceParameter(name="required_fields", param_type="List[str]", description="필수 필드", default=["customer_id", "items", "total"], required=False),
            ],
            outputs=[SliceParameter(name="validation_result", param_type="Dict[str, Any]", description="검증 결과")],
            dependencies=["core.input_validation"],
            keywords={
                "ko": ["주문검증", "주문확인", "데이터검증", "주문유효성"],
                "en": ["order", "validate", "validation", "check", "verify"]
            },
            code_template='''
        errors = []
        warnings = []

        # 필수 필드 검증
        for field in required_fields:
            if field not in order_data or order_data[field] is None:
                errors.append(f"Missing required field: {field}")

        # 주문 항목 검증
        items = order_data.get("items", [])
        if not items:
            errors.append("Order must have at least one item")
        else:
            for i, item in enumerate(items):
                if item.get("quantity", 0) <= 0:
                    errors.append(f"Item {i}: quantity must be positive")
                if item.get("price", 0) < 0:
                    errors.append(f"Item {i}: price cannot be negative")

        # 총액 검증
        total = order_data.get("total", 0)
        if total < 0:
            errors.append("Total amount cannot be negative")

        validation_result = {
            "is_valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
        return validation_result
''',
            function_name="_validate_order",
            metadata=SliceMetadata(complexity=0.4, reliability=0.98, tags=["order", "validation", "process"])
        ),
        FunctionSlice(
            id="order.process.status",
            name="Order Status Tracker",
            description="주문 상태를 추적하고 업데이트합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="current_status", param_type="str", description="현재 상태", required=True),
                SliceParameter(name="action", param_type="str", description="수행 액션", required=True),
            ],
            outputs=[SliceParameter(name="new_status", param_type="str", description="새 상태")],
            dependencies=[],
            keywords={
                "ko": ["주문상태", "상태추적", "주문현황", "진행상황"],
                "en": ["order", "status", "track", "tracking", "state"]
            },
            code_template='''
        # 상태 전이 규칙
        status_transitions = {
            "pending": {"confirm": "confirmed", "cancel": "cancelled"},
            "confirmed": {"process": "processing", "cancel": "cancelled"},
            "processing": {"ship": "shipped", "cancel": "cancelled"},
            "shipped": {"deliver": "delivered", "return": "returning"},
            "delivered": {"complete": "completed", "return": "returning"},
            "returning": {"refund": "refunded"}
        }

        allowed_transitions = status_transitions.get(current_status, {})
        new_status = allowed_transitions.get(action, current_status)

        return new_status
''',
            function_name="_update_order_status",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["order", "status", "tracking"])
        ),
        FunctionSlice(
            id="order.process.priority",
            name="Order Priority Calculator",
            description="주문 우선순위를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_value", param_type="float", description="주문 금액", required=True),
                SliceParameter(name="customer_tier", param_type="str", description="고객 등급", required=True),
                SliceParameter(name="is_express", param_type="bool", description="빠른 배송 여부", default=False, required=False),
                SliceParameter(name="wait_time_hours", param_type="float", description="대기 시간(시간)", default=0, required=False),
            ],
            outputs=[SliceParameter(name="priority_score", param_type="float", description="우선순위 점수")],
            dependencies=[],
            keywords={
                "ko": ["주문우선순위", "우선순위", "처리순서", "중요도"],
                "en": ["order", "priority", "score", "ranking", "importance"]
            },
            code_template='''
        # 기본 점수
        base_score = 50

        # 주문 금액 가중치
        value_score = min(order_value / 1000, 20)  # 최대 20점

        # 고객 등급 가중치
        tier_scores = {"vip": 20, "gold": 15, "silver": 10, "bronze": 5, "normal": 0}
        tier_score = tier_scores.get(customer_tier.lower(), 0)

        # 빠른 배송 가중치
        express_score = 15 if is_express else 0

        # 대기 시간 가중치 (오래 기다릴수록 높은 점수)
        wait_score = min(wait_time_hours * 2, 15)

        priority_score = base_score + value_score + tier_score + express_score + wait_score
        return priority_score
''',
            function_name="_calculate_order_priority",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["order", "priority", "score"])
        ),
        FunctionSlice(
            id="order.process.split",
            name="Order Splitting",
            description="주문을 여러 배송으로 분할합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_items", param_type="List[Dict]", description="주문 항목 목록", required=True),
                SliceParameter(name="warehouse_inventory", param_type="Dict[str, Dict]", description="창고별 재고", required=True),
            ],
            outputs=[SliceParameter(name="shipments", param_type="List[Dict]", description="분할된 배송 목록")],
            dependencies=[],
            keywords={
                "ko": ["주문분할", "분할배송", "부분배송", "멀티배송"],
                "en": ["order", "split", "shipment", "partial", "multi"]
            },
            code_template='''
        shipments = []
        unallocated = []

        for item in order_items:
            item_id = item.get("id")
            quantity_needed = item.get("quantity", 0)
            allocated = 0

            for warehouse, inventory in warehouse_inventory.items():
                available = inventory.get(item_id, 0)
                if available > 0 and allocated < quantity_needed:
                    allocate_qty = min(available - allocated, quantity_needed - allocated)
                    if allocate_qty > 0:
                        shipments.append({
                            "warehouse": warehouse,
                            "item_id": item_id,
                            "quantity": allocate_qty
                        })
                        allocated += allocate_qty

            if allocated < quantity_needed:
                unallocated.append({
                    "item_id": item_id,
                    "quantity": quantity_needed - allocated
                })

        return {"shipments": shipments, "unallocated": unallocated}
''',
            function_name="_split_order",
            metadata=SliceMetadata(complexity=0.5, reliability=0.92, tags=["order", "split", "shipment"])
        ),
    ]


# =============================================================================
# Pricing & Discount Slices (3개)
# =============================================================================

def _create_pricing_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="order.pricing.discount",
            name="Order Discount Calculator",
            description="주문에 적용할 할인을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_total", param_type="float", description="주문 총액", required=True),
                SliceParameter(name="customer_tier", param_type="str", description="고객 등급", required=True),
                SliceParameter(name="coupon_discount", param_type="float", description="쿠폰 할인액", default=0, required=False),
            ],
            outputs=[SliceParameter(name="discount_info", param_type="Dict[str, float]", description="할인 정보")],
            dependencies=[],
            keywords={
                "ko": ["할인", "할인계산", "쿠폰", "주문할인", "고객할인"],
                "en": ["discount", "order", "coupon", "calculate", "tier"]
            },
            code_template='''
        # 고객 등급별 할인율
        tier_discounts = {
            "vip": 0.15,
            "gold": 0.10,
            "silver": 0.05,
            "bronze": 0.03,
            "normal": 0
        }

        tier_rate = tier_discounts.get(customer_tier.lower(), 0)
        tier_discount = order_total * tier_rate

        # 총 할인액
        total_discount = tier_discount + coupon_discount

        discount_info = {
            "tier_discount": tier_discount,
            "tier_rate": tier_rate,
            "coupon_discount": coupon_discount,
            "total_discount": total_discount,
            "final_amount": order_total - total_discount
        }
        return discount_info
''',
            function_name="_calculate_order_discount",
            metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["order", "discount", "pricing"])
        ),
        FunctionSlice(
            id="order.pricing.shipping",
            name="Shipping Cost Calculator",
            description="배송비를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_total", param_type="float", description="주문 총액", required=True),
                SliceParameter(name="weight_kg", param_type="float", description="총 무게(kg)", required=True),
                SliceParameter(name="distance_km", param_type="float", description="배송 거리(km)", required=True),
                SliceParameter(name="free_shipping_threshold", param_type="float", description="무료배송 기준금액", default=50000, required=False),
            ],
            outputs=[SliceParameter(name="shipping_cost", param_type="float", description="배송비")],
            dependencies=[],
            keywords={
                "ko": ["배송비", "운송비", "무료배송", "배송료"],
                "en": ["shipping", "cost", "delivery", "free", "freight"]
            },
            code_template='''
        # 무료배송 체크
        if order_total >= free_shipping_threshold:
            return 0

        # 기본 배송비 계산
        base_cost = 3000

        # 무게 기반 추가 비용
        weight_cost = max(0, (weight_kg - 1) * 500)  # 1kg 초과시 kg당 500원

        # 거리 기반 추가 비용
        distance_cost = 0
        if distance_km > 100:
            distance_cost = (distance_km - 100) * 10  # 100km 초과시 km당 10원

        shipping_cost = base_cost + weight_cost + distance_cost
        return shipping_cost
''',
            function_name="_calculate_shipping_cost",
            metadata=SliceMetadata(complexity=0.3, reliability=0.96, tags=["order", "shipping", "cost"])
        ),
        FunctionSlice(
            id="order.pricing.quote",
            name="Price Quote Generator",
            description="주문 견적서를 생성합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="items", param_type="List[Dict]", description="주문 항목", required=True),
                SliceParameter(name="customer_tier", param_type="str", description="고객 등급", required=True),
                SliceParameter(name="validity_days", param_type="int", description="견적 유효일", default=30, required=False),
            ],
            outputs=[SliceParameter(name="quote", param_type="Dict[str, Any]", description="견적서")],
            dependencies=[],
            keywords={
                "ko": ["견적", "견적서", "가격견적", "quote"],
                "en": ["quote", "price", "quotation", "estimate", "proposal"]
            },
            code_template='''
        from datetime import datetime, timedelta

        # 소계 계산
        subtotal = sum(item.get("price", 0) * item.get("quantity", 1) for item in items)

        # 할인율 적용
        tier_discounts = {"vip": 0.15, "gold": 0.10, "silver": 0.05, "bronze": 0.03, "normal": 0}
        discount_rate = tier_discounts.get(customer_tier.lower(), 0)
        discount_amount = subtotal * discount_rate

        # 세금 계산 (10%)
        tax_rate = 0.10
        taxable_amount = subtotal - discount_amount
        tax_amount = taxable_amount * tax_rate

        # 총액
        total = taxable_amount + tax_amount

        # 유효기간
        valid_until = (datetime.now() + timedelta(days=validity_days)).strftime("%Y-%m-%d")

        quote = {
            "items": items,
            "subtotal": subtotal,
            "discount_rate": discount_rate,
            "discount_amount": discount_amount,
            "tax_rate": tax_rate,
            "tax_amount": tax_amount,
            "total": total,
            "valid_until": valid_until,
            "customer_tier": customer_tier
        }
        return quote
''',
            function_name="_generate_price_quote",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["order", "quote", "pricing"])
        ),
    ]


# =============================================================================
# Order Fulfillment Slices (3개)
# =============================================================================

def _create_fulfillment_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="order.fulfill.warehouse_selection",
            name="Warehouse Selection",
            description="최적 배송 창고를 선택합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_items", param_type="List[Dict]", description="주문 항목", required=True),
                SliceParameter(name="warehouses", param_type="List[Dict]", description="창고 정보", required=True),
                SliceParameter(name="delivery_address", param_type="Dict[str, float]", description="배송지 좌표", required=True),
            ],
            outputs=[SliceParameter(name="selected_warehouse", param_type="Dict[str, Any]", description="선택된 창고")],
            dependencies=[],
            keywords={
                "ko": ["창고선택", "물류센터", "배송창고", "풀필먼트"],
                "en": ["warehouse", "selection", "fulfillment", "center", "logistics"]
            },
            code_template='''
        import math

        def calculate_distance(lat1, lon1, lat2, lon2):
            # 간단한 유클리드 거리 (실제는 하버사인 공식 사용)
            return math.sqrt((lat2 - lat1)**2 + (lon2 - lon1)**2) * 111  # km 근사

        best_warehouse = None
        best_score = float('inf')

        for wh in warehouses:
            # 재고 확인
            has_all_items = all(
                wh.get("inventory", {}).get(item["id"], 0) >= item.get("quantity", 1)
                for item in order_items
            )

            if not has_all_items:
                continue

            # 거리 계산
            distance = calculate_distance(
                delivery_address.get("lat", 0),
                delivery_address.get("lon", 0),
                wh.get("lat", 0),
                wh.get("lon", 0)
            )

            if distance < best_score:
                best_score = distance
                best_warehouse = wh

        return best_warehouse or warehouses[0] if warehouses else None
''',
            function_name="_select_warehouse",
            metadata=SliceMetadata(complexity=0.5, reliability=0.93, tags=["order", "warehouse", "fulfillment"])
        ),
        FunctionSlice(
            id="order.fulfill.tracking",
            name="Tracking Number Generator",
            description="배송 추적 번호를 생성합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_id", param_type="str", description="주문 ID", required=True),
                SliceParameter(name="carrier", param_type="str", description="배송 업체", required=True),
            ],
            outputs=[SliceParameter(name="tracking_info", param_type="Dict[str, str]", description="추적 정보")],
            dependencies=[],
            keywords={
                "ko": ["추적번호", "송장번호", "배송조회", "트래킹"],
                "en": ["tracking", "number", "shipment", "carrier", "delivery"]
            },
            code_template='''
        import hashlib
        from datetime import datetime

        # 추적번호 생성 (업체코드 + 날짜 + 주문ID 해시)
        carrier_codes = {
            "cj": "CJ",
            "hanjin": "HJ",
            "lotte": "LT",
            "post": "KP",
            "fedex": "FX",
            "ups": "UP"
        }

        carrier_code = carrier_codes.get(carrier.lower(), "XX")
        date_code = datetime.now().strftime("%y%m%d")
        order_hash = hashlib.md5(order_id.encode()).hexdigest()[:8].upper()

        tracking_number = f"{carrier_code}{date_code}{order_hash}"

        tracking_info = {
            "tracking_number": tracking_number,
            "carrier": carrier,
            "carrier_code": carrier_code,
            "created_at": datetime.now().isoformat()
        }
        return tracking_info
''',
            function_name="_generate_tracking_number",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["order", "tracking", "shipment"])
        ),
        FunctionSlice(
            id="order.fulfill.notification",
            name="Order Notification Generator",
            description="주문 알림 메시지를 생성합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ORDER,
            inputs=[
                SliceParameter(name="order_id", param_type="str", description="주문 ID", required=True),
                SliceParameter(name="status", param_type="str", description="주문 상태", required=True),
                SliceParameter(name="customer_name", param_type="str", description="고객명", required=True),
                SliceParameter(name="tracking_number", param_type="str", description="송장번호", default=None, required=False),
            ],
            outputs=[SliceParameter(name="notification", param_type="Dict[str, str]", description="알림 메시지")],
            dependencies=[],
            keywords={
                "ko": ["알림", "주문알림", "배송알림", "통지"],
                "en": ["notification", "order", "alert", "message", "update"]
            },
            code_template='''
        templates = {
            "confirmed": f"{customer_name}님, 주문이 확인되었습니다. (주문번호: {order_id})",
            "processing": f"{customer_name}님, 주문 상품을 준비 중입니다. (주문번호: {order_id})",
            "shipped": f"{customer_name}님, 상품이 발송되었습니다. 송장번호: {tracking_number or 'N/A'}",
            "delivered": f"{customer_name}님, 상품이 배송 완료되었습니다. 감사합니다!",
            "cancelled": f"{customer_name}님, 주문이 취소되었습니다. (주문번호: {order_id})"
        }

        message = templates.get(status, f"주문 상태가 '{status}'(으)로 변경되었습니다.")

        notification = {
            "order_id": order_id,
            "status": status,
            "message": message,
            "type": "sms" if status in ["shipped", "delivered"] else "email"
        }
        return notification
''',
            function_name="_generate_order_notification",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["order", "notification", "message"])
        ),
    ]
