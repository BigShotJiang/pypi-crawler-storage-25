"""
Customer Domain Function Slices
===============================
고객 분석 도메인 특화 슬라이스 (25개)

카테고리:
1. Segmentation (5개) - 고객 세그멘테이션
2. Churn Prediction (5개) - 이탈 예측
3. Behavior Analysis (5개) - 행동 분석
4. Value Analysis (5개) - 가치 분석
5. Preference Analysis (5개) - 선호도 분석
"""

from typing import List
from ..models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceMetadata
)


def create_customer_slices() -> List[FunctionSlice]:
    """Customer Domain Slices 생성"""
    slices = []
    slices.extend(_create_segmentation_slices())
    slices.extend(_create_churn_slices())
    slices.extend(_create_behavior_slices())
    slices.extend(_create_value_slices())
    slices.extend(_create_preference_slices())
    return slices


# =============================================================================
# Segmentation Slices (5개)
# =============================================================================

def _create_segmentation_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="customer.segment.kmeans",
            name="K-Means Segmentation",
            description="K-Means 클러스터링으로 고객을 세그멘테이션합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="features", param_type="List[str]", description="세그멘테이션 피처", required=True),
                SliceParameter(name="n_clusters", param_type="int", description="클러스터 수", default=5, required=False),
            ],
            outputs=[SliceParameter(name="segments", param_type="pd.DataFrame", description="세그멘트 라벨 포함 데이터")],
            dependencies=["common.process.normalize"],
            keywords={
                "ko": ["세그멘테이션", "군집화", "클러스터링", "고객분류", "K-Means"],
                "en": ["segmentation", "clustering", "kmeans", "customer", "group"]
            },
            code_template='''
        from sklearn.cluster import KMeans
        from sklearn.preprocessing import StandardScaler

        # 피처 정규화
        scaler = StandardScaler()
        X = scaler.fit_transform(customer_data[features])

        # K-Means 클러스터링
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        customer_data["segment"] = kmeans.fit_predict(X)

        return customer_data
''',
            function_name="_segment_kmeans",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["customer", "segmentation", "ml"])
        ),
        FunctionSlice(
            id="customer.segment.rfm",
            name="RFM Segmentation",
            description="RFM(Recency, Frequency, Monetary) 분석으로 고객을 분류합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="transactions", param_type="pd.DataFrame", description="거래 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="date_col", param_type="str", description="거래일 컬럼", required=True),
                SliceParameter(name="amount_col", param_type="str", description="거래금액 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="rfm", param_type="pd.DataFrame", description="RFM 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["RFM", "고객분석", "세그멘테이션", "최근성", "빈도", "금액"],
                "en": ["rfm", "recency", "frequency", "monetary", "customer", "analysis"]
            },
            code_template='''
        import pandas as pd
        from datetime import datetime

        # 기준일
        reference_date = transactions[date_col].max() + pd.Timedelta(days=1)

        # RFM 계산
        rfm = transactions.groupby(customer_id_col).agg({
            date_col: lambda x: (reference_date - x.max()).days,  # Recency
            customer_id_col: 'count',  # Frequency
            amount_col: 'sum'  # Monetary
        }).reset_index()

        rfm.columns = [customer_id_col, 'recency', 'frequency', 'monetary']

        # RFM 스코어 (1-5)
        for col in ['recency', 'frequency', 'monetary']:
            rfm[f'{col}_score'] = pd.qcut(rfm[col], 5, labels=[5,4,3,2,1] if col == 'recency' else [1,2,3,4,5], duplicates='drop')

        rfm['rfm_score'] = rfm['recency_score'].astype(str) + rfm['frequency_score'].astype(str) + rfm['monetary_score'].astype(str)

        return rfm
''',
            function_name="_segment_rfm",
            metadata=SliceMetadata(complexity=0.5, reliability=0.97, tags=["customer", "rfm", "segmentation"])
        ),
        FunctionSlice(
            id="customer.segment.demographic",
            name="Demographic Segmentation",
            description="인구통계학적 특성으로 고객을 분류합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="age_col", param_type="str", description="나이 컬럼", required=True),
                SliceParameter(name="gender_col", param_type="str", description="성별 컬럼", default=None, required=False),
                SliceParameter(name="location_col", param_type="str", description="지역 컬럼", default=None, required=False),
            ],
            outputs=[SliceParameter(name="segments", param_type="pd.DataFrame", description="인구통계 세그먼트")],
            dependencies=[],
            keywords={
                "ko": ["인구통계", "연령", "성별", "지역", "세그멘테이션"],
                "en": ["demographic", "age", "gender", "location", "segment"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()

        # 연령대 분류
        bins = [0, 20, 30, 40, 50, 60, 100]
        labels = ['10대', '20대', '30대', '40대', '50대', '60대+']
        result['age_group'] = pd.cut(result[age_col], bins=bins, labels=labels)

        # 복합 세그먼트
        segment_parts = [result['age_group'].astype(str)]
        if gender_col:
            segment_parts.append(result[gender_col].astype(str))
        if location_col:
            segment_parts.append(result[location_col].astype(str))

        result['demographic_segment'] = segment_parts[0]
        for part in segment_parts[1:]:
            result['demographic_segment'] = result['demographic_segment'] + '_' + part

        return result
''',
            function_name="_segment_demographic",
            metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["customer", "demographic", "segmentation"])
        ),
        FunctionSlice(
            id="customer.segment.behavioral",
            name="Behavioral Segmentation",
            description="행동 패턴으로 고객을 분류합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="behavior_data", param_type="pd.DataFrame", description="행동 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="action_col", param_type="str", description="행동 유형 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="segments", param_type="pd.DataFrame", description="행동 세그먼트")],
            dependencies=[],
            keywords={
                "ko": ["행동", "패턴", "세그멘테이션", "활동"],
                "en": ["behavioral", "pattern", "activity", "segment"]
            },
            code_template='''
        import pandas as pd

        # 고객별 행동 집계
        behavior_matrix = behavior_data.pivot_table(
            index=customer_id_col,
            columns=action_col,
            aggfunc='size',
            fill_value=0
        )

        # 주요 행동 기반 분류
        result = pd.DataFrame(index=behavior_matrix.index)
        result['primary_behavior'] = behavior_matrix.idxmax(axis=1)
        result['total_actions'] = behavior_matrix.sum(axis=1)
        result['behavior_diversity'] = (behavior_matrix > 0).sum(axis=1)

        return result.reset_index()
''',
            function_name="_segment_behavioral",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["customer", "behavioral", "segmentation"])
        ),
        FunctionSlice(
            id="customer.segment.value_tier",
            name="Value Tier Segmentation",
            description="고객 가치 등급으로 분류합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="value_col", param_type="str", description="가치 지표 컬럼", required=True),
                SliceParameter(name="n_tiers", param_type="int", description="등급 수", default=4, required=False),
            ],
            outputs=[SliceParameter(name="tiers", param_type="pd.DataFrame", description="가치 등급 데이터")],
            dependencies=[],
            keywords={
                "ko": ["가치", "등급", "VIP", "티어", "고객등급"],
                "en": ["value", "tier", "vip", "grade", "customer"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()
        tier_labels = ['Bronze', 'Silver', 'Gold', 'Platinum'][:n_tiers]

        result['value_tier'] = pd.qcut(
            result[value_col],
            n_tiers,
            labels=tier_labels,
            duplicates='drop'
        )

        return result
''',
            function_name="_segment_value_tier",
            metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["customer", "value", "tier"])
        ),
    ]


# =============================================================================
# Churn Prediction Slices (5개)
# =============================================================================

def _create_churn_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="customer.churn.predict",
            name="Churn Prediction",
            description="고객 이탈 확률을 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="features", param_type="List[str]", description="예측 피처", required=True),
                SliceParameter(name="model", param_type="Any", description="학습된 모델", default=None, required=False),
            ],
            outputs=[SliceParameter(name="predictions", param_type="pd.DataFrame", description="이탈 예측 결과")],
            dependencies=["common.process.normalize"],
            keywords={
                "ko": ["이탈", "예측", "고객이탈", "해지", "churn"],
                "en": ["churn", "prediction", "attrition", "customer", "predict"]
            },
            code_template='''
        import pandas as pd
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.preprocessing import StandardScaler

        result = customer_data.copy()
        X = result[features]

        # 모델이 없으면 기본 모델 사용 (실제로는 학습된 모델 필요)
        if model is None:
            model = RandomForestClassifier(random_state=42)

        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        result['churn_probability'] = model.predict_proba(X_scaled)[:, 1]
        result['churn_predicted'] = model.predict(X_scaled)

        return result
''',
            function_name="_predict_churn",
            metadata=SliceMetadata(complexity=0.6, reliability=0.90, tags=["customer", "churn", "prediction", "ml"])
        ),
        FunctionSlice(
            id="customer.churn.features",
            name="Churn Features",
            description="이탈 예측용 피처를 생성합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="transaction_data", param_type="pd.DataFrame", description="거래 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="features", param_type="pd.DataFrame", description="이탈 예측 피처")],
            dependencies=[],
            keywords={
                "ko": ["이탈", "피처", "특성", "변수"],
                "en": ["churn", "features", "variables", "engineering"]
            },
            code_template='''
        import pandas as pd
        from datetime import datetime

        # 거래 기반 피처
        tx_features = transaction_data.groupby(customer_id_col).agg({
            'amount': ['sum', 'mean', 'std', 'count'],
            'date': ['min', 'max']
        }).reset_index()

        tx_features.columns = [customer_id_col, 'total_amount', 'avg_amount', 'std_amount',
                               'transaction_count', 'first_purchase', 'last_purchase']

        # 기간 피처
        reference_date = datetime.now()
        tx_features['days_since_last_purchase'] = (reference_date - tx_features['last_purchase']).dt.days
        tx_features['customer_tenure'] = (tx_features['last_purchase'] - tx_features['first_purchase']).dt.days

        # 고객 데이터와 병합
        result = customer_data.merge(tx_features, on=customer_id_col, how='left')

        return result
''',
            function_name="_create_churn_features",
            metadata=SliceMetadata(complexity=0.5, reliability=0.95, tags=["customer", "churn", "features"])
        ),
        FunctionSlice(
            id="customer.churn.risk_score",
            name="Churn Risk Score",
            description="이탈 위험 점수를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="risk_factors", param_type="Dict", description="위험 요인 가중치", required=True),
            ],
            outputs=[SliceParameter(name="risk_scores", param_type="pd.DataFrame", description="위험 점수 데이터")],
            dependencies=[],
            keywords={
                "ko": ["위험", "점수", "이탈위험", "리스크"],
                "en": ["risk", "score", "churn", "assessment"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()
        result['risk_score'] = 0.0

        for factor, weight in risk_factors.items():
            if factor in result.columns:
                # 정규화 후 가중치 적용
                normalized = (result[factor] - result[factor].min()) / (result[factor].max() - result[factor].min() + 1e-10)
                result['risk_score'] += normalized * weight

        # 0-100 스케일링
        result['risk_score'] = (result['risk_score'] / sum(risk_factors.values()) * 100).round(2)
        result['risk_level'] = pd.cut(result['risk_score'], bins=[0, 25, 50, 75, 100],
                                       labels=['Low', 'Medium', 'High', 'Critical'])

        return result
''',
            function_name="_calculate_churn_risk",
            metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["customer", "churn", "risk"])
        ),
        FunctionSlice(
            id="customer.churn.intervention",
            name="Churn Intervention",
            description="이탈 방지를 위한 개입 전략을 추천합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="위험 점수 포함 고객 데이터", required=True),
                SliceParameter(name="risk_col", param_type="str", description="위험 점수 컬럼", required=True),
                SliceParameter(name="value_col", param_type="str", description="고객 가치 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="interventions", param_type="pd.DataFrame", description="개입 전략 추천")],
            dependencies=["customer.churn.risk_score"],
            keywords={
                "ko": ["개입", "전략", "이탈방지", "리텐션"],
                "en": ["intervention", "strategy", "retention", "prevention"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()

        # 위험 * 가치 매트릭스 기반 전략
        def recommend_strategy(row):
            risk = row[risk_col]
            value = row[value_col]

            if risk > 75 and value > 75:
                return 'VIP_URGENT: 즉시 개인화 연락, 특별 혜택'
            elif risk > 75:
                return 'HIGH_RISK: 할인 쿠폰, 재활성화 캠페인'
            elif risk > 50 and value > 50:
                return 'VALUABLE_AT_RISK: 로열티 프로그램, 맞춤 오퍼'
            elif risk > 50:
                return 'MEDIUM_RISK: 이메일 캠페인, 리마인더'
            else:
                return 'MAINTAIN: 일반 마케팅'

        result['intervention_strategy'] = result.apply(recommend_strategy, axis=1)

        return result
''',
            function_name="_recommend_intervention",
            metadata=SliceMetadata(complexity=0.3, reliability=0.90, tags=["customer", "churn", "intervention"])
        ),
        FunctionSlice(
            id="customer.churn.cohort",
            name="Churn Cohort Analysis",
            description="코호트별 이탈율을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="cohort_col", param_type="str", description="코호트 컬럼", required=True),
                SliceParameter(name="churn_col", param_type="str", description="이탈 여부 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="cohort_analysis", param_type="pd.DataFrame", description="코호트 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["코호트", "분석", "이탈율", "집단"],
                "en": ["cohort", "analysis", "churn", "rate"]
            },
            code_template='''
        import pandas as pd

        cohort_analysis = customer_data.groupby(cohort_col).agg({
            churn_col: ['sum', 'count', 'mean']
        }).reset_index()

        cohort_analysis.columns = [cohort_col, 'churned_count', 'total_count', 'churn_rate']
        cohort_analysis['retention_rate'] = 1 - cohort_analysis['churn_rate']

        return cohort_analysis
''',
            function_name="_analyze_churn_cohort",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["customer", "churn", "cohort"])
        ),
    ]


# =============================================================================
# Behavior Analysis Slices (5개)
# =============================================================================

def _create_behavior_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="customer.behavior.journey",
            name="Customer Journey Analysis",
            description="고객 여정을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="event_data", param_type="pd.DataFrame", description="이벤트 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="event_col", param_type="str", description="이벤트 유형 컬럼", required=True),
                SliceParameter(name="timestamp_col", param_type="str", description="타임스탬프 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="journeys", param_type="pd.DataFrame", description="고객 여정 데이터")],
            dependencies=[],
            keywords={
                "ko": ["여정", "고객여정", "터치포인트", "경로"],
                "en": ["journey", "touchpoint", "path", "customer"]
            },
            code_template='''
        import pandas as pd

        # 시간순 정렬
        sorted_data = event_data.sort_values([customer_id_col, timestamp_col])

        # 고객별 여정 시퀀스
        journeys = sorted_data.groupby(customer_id_col)[event_col].agg(list).reset_index()
        journeys.columns = [customer_id_col, 'journey_sequence']

        # 여정 길이
        journeys['journey_length'] = journeys['journey_sequence'].apply(len)

        # 시작점, 끝점
        journeys['first_touchpoint'] = journeys['journey_sequence'].apply(lambda x: x[0])
        journeys['last_touchpoint'] = journeys['journey_sequence'].apply(lambda x: x[-1])

        return journeys
''',
            function_name="_analyze_journey",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["customer", "journey", "behavior"])
        ),
        FunctionSlice(
            id="customer.behavior.frequency",
            name="Behavior Frequency Analysis",
            description="행동 빈도를 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="behavior_data", param_type="pd.DataFrame", description="행동 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="action_col", param_type="str", description="행동 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="frequency", param_type="pd.DataFrame", description="빈도 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["빈도", "횟수", "활동", "분석"],
                "en": ["frequency", "count", "activity", "analysis"]
            },
            code_template='''
        import pandas as pd

        frequency = behavior_data.groupby([customer_id_col, action_col]).size().unstack(fill_value=0)
        frequency['total_actions'] = frequency.sum(axis=1)
        frequency['primary_action'] = frequency.drop('total_actions', axis=1).idxmax(axis=1)

        return frequency.reset_index()
''',
            function_name="_analyze_frequency",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["customer", "frequency", "behavior"])
        ),
        FunctionSlice(
            id="customer.behavior.pattern",
            name="Behavior Pattern Detection",
            description="행동 패턴을 감지합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="behavior_data", param_type="pd.DataFrame", description="행동 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="timestamp_col", param_type="str", description="타임스탬프 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="patterns", param_type="pd.DataFrame", description="패턴 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["패턴", "반복", "규칙", "감지"],
                "en": ["pattern", "detection", "recurring", "behavior"]
            },
            code_template='''
        import pandas as pd

        result = behavior_data.copy()
        result[timestamp_col] = pd.to_datetime(result[timestamp_col])

        # 시간대별 패턴
        result['hour'] = result[timestamp_col].dt.hour
        result['day_of_week'] = result[timestamp_col].dt.dayofweek
        result['is_weekend'] = result['day_of_week'] >= 5

        # 고객별 활동 패턴
        patterns = result.groupby(customer_id_col).agg({
            'hour': lambda x: x.mode()[0] if len(x.mode()) > 0 else 12,
            'day_of_week': lambda x: x.mode()[0] if len(x.mode()) > 0 else 0,
            'is_weekend': 'mean'
        }).reset_index()

        patterns.columns = [customer_id_col, 'preferred_hour', 'preferred_day', 'weekend_ratio']

        return patterns
''',
            function_name="_detect_patterns",
            metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["customer", "pattern", "behavior"])
        ),
        FunctionSlice(
            id="customer.behavior.engagement",
            name="Engagement Score",
            description="고객 참여도 점수를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="engagement_factors", param_type="Dict", description="참여도 요인 {컬럼: 가중치}", required=True),
            ],
            outputs=[SliceParameter(name="engagement", param_type="pd.DataFrame", description="참여도 점수")],
            dependencies=[],
            keywords={
                "ko": ["참여도", "인게이지먼트", "활성화", "점수"],
                "en": ["engagement", "score", "activity", "active"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()
        result['engagement_score'] = 0.0

        for factor, weight in engagement_factors.items():
            if factor in result.columns:
                normalized = (result[factor] - result[factor].min()) / (result[factor].max() - result[factor].min() + 1e-10)
                result['engagement_score'] += normalized * weight

        result['engagement_score'] = (result['engagement_score'] / sum(engagement_factors.values()) * 100).round(2)
        result['engagement_level'] = pd.cut(result['engagement_score'],
                                            bins=[0, 25, 50, 75, 100],
                                            labels=['Low', 'Medium', 'High', 'Very High'])

        return result
''',
            function_name="_calculate_engagement",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["customer", "engagement", "behavior"])
        ),
        FunctionSlice(
            id="customer.behavior.session",
            name="Session Analysis",
            description="세션 행동을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="event_data", param_type="pd.DataFrame", description="이벤트 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="timestamp_col", param_type="str", description="타임스탬프 컬럼", required=True),
                SliceParameter(name="session_timeout", param_type="int", description="세션 타임아웃(분)", default=30, required=False),
            ],
            outputs=[SliceParameter(name="sessions", param_type="pd.DataFrame", description="세션 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["세션", "방문", "체류", "분석"],
                "en": ["session", "visit", "duration", "analysis"]
            },
            code_template='''
        import pandas as pd

        data = event_data.copy()
        data[timestamp_col] = pd.to_datetime(data[timestamp_col])
        data = data.sort_values([customer_id_col, timestamp_col])

        # 세션 구분
        data['time_diff'] = data.groupby(customer_id_col)[timestamp_col].diff()
        data['new_session'] = data['time_diff'] > pd.Timedelta(minutes=session_timeout)
        data['session_id'] = data.groupby(customer_id_col)['new_session'].cumsum()

        # 세션별 집계
        sessions = data.groupby([customer_id_col, 'session_id']).agg({
            timestamp_col: ['min', 'max', 'count']
        }).reset_index()

        sessions.columns = [customer_id_col, 'session_id', 'session_start', 'session_end', 'event_count']
        sessions['session_duration'] = (sessions['session_end'] - sessions['session_start']).dt.total_seconds() / 60

        return sessions
''',
            function_name="_analyze_sessions",
            metadata=SliceMetadata(complexity=0.5, reliability=0.93, tags=["customer", "session", "behavior"])
        ),
    ]


# =============================================================================
# Value Analysis Slices (5개)
# =============================================================================

def _create_value_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="customer.value.clv",
            name="Customer Lifetime Value",
            description="고객 생애 가치(CLV)를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="avg_order_value", param_type="str", description="평균 주문 가치 컬럼", required=True),
                SliceParameter(name="purchase_frequency", param_type="str", description="구매 빈도 컬럼", required=True),
                SliceParameter(name="customer_lifespan", param_type="float", description="예상 고객 수명(년)", default=3.0, required=False),
            ],
            outputs=[SliceParameter(name="clv", param_type="pd.DataFrame", description="CLV 데이터")],
            dependencies=[],
            keywords={
                "ko": ["CLV", "생애가치", "LTV", "고객가치"],
                "en": ["clv", "lifetime", "value", "ltv", "customer"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()

        # 기본 CLV = AOV * 구매빈도 * 고객수명
        result['clv'] = result[avg_order_value] * result[purchase_frequency] * customer_lifespan

        # CLV 등급
        result['clv_tier'] = pd.qcut(result['clv'], 5, labels=['Very Low', 'Low', 'Medium', 'High', 'Very High'], duplicates='drop')

        return result
''',
            function_name="_calculate_clv",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["customer", "clv", "value"])
        ),
        FunctionSlice(
            id="customer.value.profitability",
            name="Customer Profitability",
            description="고객 수익성을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="revenue_col", param_type="str", description="수익 컬럼", required=True),
                SliceParameter(name="cost_col", param_type="str", description="비용 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="profitability", param_type="pd.DataFrame", description="수익성 데이터")],
            dependencies=[],
            keywords={
                "ko": ["수익성", "이익", "마진", "ROI"],
                "en": ["profitability", "profit", "margin", "roi"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()

        result['profit'] = result[revenue_col] - result[cost_col]
        result['profit_margin'] = (result['profit'] / result[revenue_col] * 100).round(2)
        result['is_profitable'] = result['profit'] > 0

        return result
''',
            function_name="_analyze_profitability",
            metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["customer", "profitability", "value"])
        ),
        FunctionSlice(
            id="customer.value.growth",
            name="Customer Value Growth",
            description="고객 가치 성장률을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="period_data", param_type="pd.DataFrame", description="기간별 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="value_col", param_type="str", description="가치 컬럼", required=True),
                SliceParameter(name="period_col", param_type="str", description="기간 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="growth", param_type="pd.DataFrame", description="성장률 데이터")],
            dependencies=[],
            keywords={
                "ko": ["성장", "증가", "추세", "변화"],
                "en": ["growth", "increase", "trend", "change"]
            },
            code_template='''
        import pandas as pd

        # 기간별 정렬
        sorted_data = period_data.sort_values([customer_id_col, period_col])

        # 성장률 계산
        result = sorted_data.copy()
        result['prev_value'] = result.groupby(customer_id_col)[value_col].shift(1)
        result['value_growth'] = ((result[value_col] - result['prev_value']) / result['prev_value'] * 100).round(2)

        # 성장 추세
        growth_summary = result.groupby(customer_id_col).agg({
            'value_growth': 'mean'
        }).reset_index()
        growth_summary.columns = [customer_id_col, 'avg_growth_rate']
        growth_summary['growth_trend'] = growth_summary['avg_growth_rate'].apply(
            lambda x: 'Growing' if x > 5 else ('Stable' if x > -5 else 'Declining')
        )

        return growth_summary
''',
            function_name="_analyze_growth",
            metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["customer", "growth", "value"])
        ),
        FunctionSlice(
            id="customer.value.acquisition_cost",
            name="Customer Acquisition Cost",
            description="고객 획득 비용(CAC)을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="marketing_spend", param_type="float", description="마케팅 비용", required=True),
                SliceParameter(name="new_customers", param_type="int", description="신규 고객 수", required=True),
                SliceParameter(name="channel", param_type="str", description="채널명", default="total", required=False),
            ],
            outputs=[SliceParameter(name="cac", param_type="Dict", description="CAC 데이터")],
            dependencies=[],
            keywords={
                "ko": ["획득비용", "CAC", "마케팅", "고객획득"],
                "en": ["cac", "acquisition", "cost", "marketing"]
            },
            code_template='''
        cac = marketing_spend / new_customers if new_customers > 0 else 0

        return {
            "channel": channel,
            "marketing_spend": marketing_spend,
            "new_customers": new_customers,
            "cac": round(cac, 2)
        }
''',
            function_name="_calculate_cac",
            metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["customer", "cac", "value"])
        ),
        FunctionSlice(
            id="customer.value.retention_value",
            name="Retention Value Analysis",
            description="유지 고객의 가치를 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_data", param_type="pd.DataFrame", description="고객 데이터", required=True),
                SliceParameter(name="tenure_col", param_type="str", description="가입 기간 컬럼", required=True),
                SliceParameter(name="value_col", param_type="str", description="가치 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="retention_value", param_type="pd.DataFrame", description="유지 가치 분석")],
            dependencies=[],
            keywords={
                "ko": ["유지", "리텐션", "장기고객", "가치"],
                "en": ["retention", "value", "loyalty", "long-term"]
            },
            code_template='''
        import pandas as pd

        result = customer_data.copy()

        # 가입 기간별 그룹화
        result['tenure_group'] = pd.cut(result[tenure_col],
                                        bins=[0, 30, 90, 180, 365, float('inf')],
                                        labels=['0-30d', '31-90d', '91-180d', '181-365d', '365d+'])

        # 그룹별 가치 분석
        retention_analysis = result.groupby('tenure_group').agg({
            value_col: ['mean', 'sum', 'count']
        }).reset_index()

        retention_analysis.columns = ['tenure_group', 'avg_value', 'total_value', 'customer_count']

        return retention_analysis
''',
            function_name="_analyze_retention_value",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["customer", "retention", "value"])
        ),
    ]


# =============================================================================
# Preference Analysis Slices (5개)
# =============================================================================

def _create_preference_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="customer.preference.product",
            name="Product Preference",
            description="제품 선호도를 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="purchase_data", param_type="pd.DataFrame", description="구매 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="product_col", param_type="str", description="제품 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="preferences", param_type="pd.DataFrame", description="제품 선호도")],
            dependencies=[],
            keywords={
                "ko": ["선호도", "제품", "상품", "취향"],
                "en": ["preference", "product", "favorite", "taste"]
            },
            code_template='''
        import pandas as pd

        # 고객별 제품 구매 빈도
        product_freq = purchase_data.groupby([customer_id_col, product_col]).size().unstack(fill_value=0)

        # 선호 제품 추출
        result = pd.DataFrame(index=product_freq.index)
        result['top_product'] = product_freq.idxmax(axis=1)
        result['top_product_count'] = product_freq.max(axis=1)
        result['product_diversity'] = (product_freq > 0).sum(axis=1)

        return result.reset_index()
''',
            function_name="_analyze_product_preference",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["customer", "preference", "product"])
        ),
        FunctionSlice(
            id="customer.preference.channel",
            name="Channel Preference",
            description="채널 선호도를 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="interaction_data", param_type="pd.DataFrame", description="상호작용 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="channel_col", param_type="str", description="채널 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="channel_pref", param_type="pd.DataFrame", description="채널 선호도")],
            dependencies=[],
            keywords={
                "ko": ["채널", "선호", "터치포인트", "미디어"],
                "en": ["channel", "preference", "touchpoint", "media"]
            },
            code_template='''
        import pandas as pd

        channel_freq = interaction_data.groupby([customer_id_col, channel_col]).size().unstack(fill_value=0)

        result = pd.DataFrame(index=channel_freq.index)
        result['preferred_channel'] = channel_freq.idxmax(axis=1)
        result['channel_usage_count'] = channel_freq.max(axis=1)
        result['omnichannel_score'] = (channel_freq > 0).sum(axis=1)

        return result.reset_index()
''',
            function_name="_analyze_channel_preference",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["customer", "preference", "channel"])
        ),
        FunctionSlice(
            id="customer.preference.timing",
            name="Timing Preference",
            description="시간대 선호도를 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="event_data", param_type="pd.DataFrame", description="이벤트 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="timestamp_col", param_type="str", description="타임스탬프 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="timing_pref", param_type="pd.DataFrame", description="시간대 선호도")],
            dependencies=[],
            keywords={
                "ko": ["시간대", "선호", "타이밍", "활동시간"],
                "en": ["timing", "preference", "time", "schedule"]
            },
            code_template='''
        import pandas as pd

        data = event_data.copy()
        data[timestamp_col] = pd.to_datetime(data[timestamp_col])
        data['hour'] = data[timestamp_col].dt.hour
        data['day_of_week'] = data[timestamp_col].dt.day_name()

        result = data.groupby(customer_id_col).agg({
            'hour': lambda x: x.mode()[0] if len(x.mode()) > 0 else 12,
            'day_of_week': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Monday'
        }).reset_index()

        result.columns = [customer_id_col, 'preferred_hour', 'preferred_day']

        # 시간대 분류
        result['time_of_day'] = result['preferred_hour'].apply(
            lambda h: 'Morning' if h < 12 else ('Afternoon' if h < 18 else 'Evening')
        )

        return result
''',
            function_name="_analyze_timing_preference",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["customer", "preference", "timing"])
        ),
        FunctionSlice(
            id="customer.preference.price",
            name="Price Sensitivity",
            description="가격 민감도를 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="purchase_data", param_type="pd.DataFrame", description="구매 데이터", required=True),
                SliceParameter(name="customer_id_col", param_type="str", description="고객 ID 컬럼", required=True),
                SliceParameter(name="price_col", param_type="str", description="가격 컬럼", required=True),
                SliceParameter(name="discount_col", param_type="str", description="할인 여부 컬럼", default=None, required=False),
            ],
            outputs=[SliceParameter(name="price_sensitivity", param_type="pd.DataFrame", description="가격 민감도")],
            dependencies=[],
            keywords={
                "ko": ["가격", "민감도", "할인", "프로모션"],
                "en": ["price", "sensitivity", "discount", "promotion"]
            },
            code_template='''
        import pandas as pd

        result = purchase_data.groupby(customer_id_col).agg({
            price_col: ['mean', 'std', 'min', 'max']
        }).reset_index()

        result.columns = [customer_id_col, 'avg_price', 'price_std', 'min_price', 'max_price']
        result['price_range'] = result['max_price'] - result['min_price']

        # 할인 선호도
        if discount_col:
            discount_rate = purchase_data.groupby(customer_id_col)[discount_col].mean().reset_index()
            discount_rate.columns = [customer_id_col, 'discount_preference']
            result = result.merge(discount_rate, on=customer_id_col)

        # 가격 민감도 분류
        result['price_sensitivity'] = pd.qcut(result['price_std'], 3, labels=['Low', 'Medium', 'High'], duplicates='drop')

        return result
''',
            function_name="_analyze_price_sensitivity",
            metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["customer", "preference", "price"])
        ),
        FunctionSlice(
            id="customer.preference.recommendation",
            name="Preference-based Recommendation",
            description="선호도 기반 추천을 생성합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.CUSTOMER,
            inputs=[
                SliceParameter(name="customer_preferences", param_type="pd.DataFrame", description="고객 선호도 데이터", required=True),
                SliceParameter(name="product_catalog", param_type="pd.DataFrame", description="제품 카탈로그", required=True),
                SliceParameter(name="customer_id", param_type="str", description="추천 대상 고객 ID", required=True),
                SliceParameter(name="n_recommendations", param_type="int", description="추천 수", default=5, required=False),
            ],
            outputs=[SliceParameter(name="recommendations", param_type="List", description="추천 제품 목록")],
            dependencies=["customer.preference.product"],
            keywords={
                "ko": ["추천", "개인화", "맞춤", "제안"],
                "en": ["recommendation", "personalize", "suggest", "propose"]
            },
            code_template='''
        import pandas as pd

        # 고객 선호도 조회
        customer_pref = customer_preferences[customer_preferences['customer_id'] == customer_id]

        if customer_pref.empty:
            # 인기 제품 추천
            recommendations = product_catalog.head(n_recommendations)['product_id'].tolist()
        else:
            # 선호 카테고리/브랜드 기반 추천
            preferred = customer_pref.iloc[0]
            matching_products = product_catalog[
                (product_catalog['category'] == preferred.get('preferred_category')) |
                (product_catalog['brand'] == preferred.get('preferred_brand'))
            ]
            recommendations = matching_products.head(n_recommendations)['product_id'].tolist()

        return recommendations
''',
            function_name="_generate_recommendations",
            metadata=SliceMetadata(complexity=0.5, reliability=0.88, tags=["customer", "preference", "recommendation"])
        ),
    ]
