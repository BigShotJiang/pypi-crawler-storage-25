"""
Domain-Specific Function Slices
===============================
도메인별 특화된 Function Slices

도메인:
- Customer (25개): 고객 분석, 세그멘테이션, 이탈 예측
- Finance (30개): 재무 분석, 리스크 분석, 예측
- ML/AI (25개): 피처 엔지니어링, 모델 학습, 예측
- Inventory (15개): 재고 관리, 공급망, 수요 예측 [NEW]
- HR (10개): 급여, 성과 평가, 근태 관리 [NEW]
- Order (10개): 주문 처리, 가격/할인, 주문 이행 [NEW]
- Project (10개): 태스크 관리, 리소스 계획, 진행 추적 [NEW]
"""

from typing import List, Optional
from ..models import FunctionSlice, SliceDomain


def create_all_domain_slices() -> List[FunctionSlice]:
    """모든 도메인 슬라이스 생성"""
    from .customer_slices import create_customer_slices
    from .finance_slices import create_finance_slices
    from .ml_ai_slices import create_ml_ai_slices
    from .inventory_slices import create_inventory_slices
    from .hr_slices import create_hr_slices
    from .order_slices import create_order_slices
    from .project_slices import create_project_slices

    slices = []
    slices.extend(create_customer_slices())
    slices.extend(create_finance_slices())
    slices.extend(create_ml_ai_slices())
    slices.extend(create_inventory_slices())
    slices.extend(create_hr_slices())
    slices.extend(create_order_slices())
    slices.extend(create_project_slices())
    return slices


def create_domain_slices(domain: SliceDomain) -> List[FunctionSlice]:
    """특정 도메인 슬라이스만 생성"""
    from .customer_slices import create_customer_slices
    from .finance_slices import create_finance_slices
    from .ml_ai_slices import create_ml_ai_slices
    from .inventory_slices import create_inventory_slices
    from .hr_slices import create_hr_slices
    from .order_slices import create_order_slices
    from .project_slices import create_project_slices

    if domain == SliceDomain.CUSTOMER:
        return create_customer_slices()
    elif domain == SliceDomain.FINANCE:
        return create_finance_slices()
    elif domain == SliceDomain.ML_AI:
        return create_ml_ai_slices()
    elif domain == SliceDomain.INVENTORY:
        return create_inventory_slices()
    elif domain == SliceDomain.HR:
        return create_hr_slices()
    elif domain == SliceDomain.ORDER:
        return create_order_slices()
    elif domain == SliceDomain.PROJECT:
        return create_project_slices()
    return []


def get_domain_slice_count() -> dict:
    """도메인별 슬라이스 개수"""
    from .customer_slices import create_customer_slices
    from .finance_slices import create_finance_slices
    from .ml_ai_slices import create_ml_ai_slices
    from .inventory_slices import create_inventory_slices
    from .hr_slices import create_hr_slices
    from .order_slices import create_order_slices
    from .project_slices import create_project_slices

    return {
        "customer": len(create_customer_slices()),
        "finance": len(create_finance_slices()),
        "ml_ai": len(create_ml_ai_slices()),
        "inventory": len(create_inventory_slices()),
        "hr": len(create_hr_slices()),
        "order": len(create_order_slices()),
        "project": len(create_project_slices()),
    }


__all__ = [
    "create_all_domain_slices",
    "create_domain_slices",
    "get_domain_slice_count",
]
