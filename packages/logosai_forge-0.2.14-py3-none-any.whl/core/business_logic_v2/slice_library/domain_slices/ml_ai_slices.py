"""
ML/AI Domain Slices
===================
머신러닝/AI 도메인 특화 Function Slices (25개)

카테고리:
- Feature Engineering (8개): 피처 생성, 변환, 선택
- Model Training/Prediction (10개): 모델 학습 및 예측
- Evaluation/Optimization (7개): 모델 평가 및 최적화
"""

from typing import List
from ..models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceMetadata
)


def create_ml_ai_slices() -> List[FunctionSlice]:
    """ML/AI 도메인 슬라이스 생성 (25개)"""
    slices = []
    slices.extend(_create_feature_engineering_slices())
    slices.extend(_create_model_training_slices())
    slices.extend(_create_evaluation_slices())
    return slices


def _create_feature_engineering_slices() -> List[FunctionSlice]:
    """Feature Engineering 슬라이스 (8개)"""
    return [
        # 1. Feature Extraction
        FunctionSlice(
            id="ml_feature_extraction",
            name="Feature Extraction",
            description="Extract features from raw data for ML models",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="data", param_type="pd.DataFrame", description="Raw input data"),
                SliceParameter(name="feature_config", param_type="Dict[str, Any]", description="Feature extraction configuration", required=False)
            ],
            outputs=[
                SliceParameter(name="features", param_type="pd.DataFrame", description="Extracted features"),
                SliceParameter(name="feature_names", param_type="List[str]", description="List of feature names")
            ],
            dependencies=["common_validate_data", "common_transform"],
            keywords=["feature extraction", "피처 추출", "feature engineering", "피처 엔지니어링", "특징 추출"],
            code_template='''
def extract_features(data: pd.DataFrame, feature_config: Optional[Dict[str, Any]] = None) -> Tuple[pd.DataFrame, List[str]]:
    """Extract features from raw data"""
    config = feature_config or {}
    features = data.copy()

    # Numeric features
    numeric_cols = features.select_dtypes(include=[np.number]).columns.tolist()

    # Categorical encoding
    categorical_cols = features.select_dtypes(include=['object', 'category']).columns.tolist()
    for col in categorical_cols:
        if config.get('encoding', 'label') == 'onehot':
            dummies = pd.get_dummies(features[col], prefix=col)
            features = pd.concat([features.drop(col, axis=1), dummies], axis=1)
        else:
            features[col] = features[col].astype('category').cat.codes

    feature_names = features.columns.tolist()
    return features, feature_names
''',
            metadata=SliceMetadata(complexity=0.6, reliability=0.9, tags=["ml", "feature", "extraction"])
        ),

        # 2. Feature Scaling
        FunctionSlice(
            id="ml_feature_scaling",
            name="Feature Scaling",
            description="Scale features using various normalization methods",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="features", param_type="pd.DataFrame", description="Features to scale"),
                SliceParameter(name="method", param_type="str", description="Scaling method: standard, minmax, robust", required=False)
            ],
            outputs=[
                SliceParameter(name="scaled_features", param_type="pd.DataFrame", description="Scaled features"),
                SliceParameter(name="scaler", param_type="Any", description="Fitted scaler object")
            ],
            dependencies=["ml_feature_extraction"],
            keywords=["scaling", "스케일링", "normalization", "정규화", "standardization", "표준화"],
            code_template='''
def scale_features(features: pd.DataFrame, method: str = "standard") -> Tuple[pd.DataFrame, Any]:
    """Scale features using specified method"""
    from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

    scalers = {
        "standard": StandardScaler(),
        "minmax": MinMaxScaler(),
        "robust": RobustScaler()
    }
    scaler = scalers.get(method, StandardScaler())

    numeric_cols = features.select_dtypes(include=[np.number]).columns
    scaled_data = features.copy()
    scaled_data[numeric_cols] = scaler.fit_transform(features[numeric_cols])

    return scaled_data, scaler
''',
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["ml", "scaling", "preprocessing"])
        ),

        # 3. Feature Selection
        FunctionSlice(
            id="ml_feature_selection",
            name="Feature Selection",
            description="Select most important features for model training",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="X", param_type="pd.DataFrame", description="Feature matrix"),
                SliceParameter(name="y", param_type="pd.Series", description="Target variable"),
                SliceParameter(name="method", param_type="str", description="Selection method: mutual_info, chi2, rfe", required=False),
                SliceParameter(name="n_features", param_type="int", description="Number of features to select", required=False)
            ],
            outputs=[
                SliceParameter(name="selected_features", param_type="pd.DataFrame", description="Selected features"),
                SliceParameter(name="feature_importance", param_type="Dict[str, float]", description="Feature importance scores")
            ],
            dependencies=["ml_feature_scaling"],
            keywords=["feature selection", "피처 선택", "변수 선택", "feature importance", "변수 중요도"],
            code_template='''
def select_features(X: pd.DataFrame, y: pd.Series, method: str = "mutual_info", n_features: int = 10) -> Tuple[pd.DataFrame, Dict[str, float]]:
    """Select important features"""
    from sklearn.feature_selection import SelectKBest, mutual_info_classif, chi2
    from sklearn.feature_selection import RFE
    from sklearn.ensemble import RandomForestClassifier

    n_features = min(n_features, X.shape[1])

    if method == "rfe":
        estimator = RandomForestClassifier(n_estimators=50, random_state=42)
        selector = RFE(estimator, n_features_to_select=n_features)
        selector.fit(X, y)
        mask = selector.support_
        importance = dict(zip(X.columns, selector.ranking_))
    else:
        score_func = mutual_info_classif if method == "mutual_info" else chi2
        selector = SelectKBest(score_func, k=n_features)
        selector.fit(X, y)
        mask = selector.get_support()
        importance = dict(zip(X.columns, selector.scores_))

    selected = X.loc[:, mask]
    return selected, importance
''',
            metadata=SliceMetadata(complexity=0.7, reliability=0.85, tags=["ml", "feature", "selection"])
        ),

        # 4. Dimensionality Reduction
        FunctionSlice(
            id="ml_dimensionality_reduction",
            name="Dimensionality Reduction",
            description="Reduce feature dimensions using PCA, t-SNE, or UMAP",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="features", param_type="pd.DataFrame", description="High-dimensional features"),
                SliceParameter(name="method", param_type="str", description="Reduction method: pca, tsne, umap", required=False),
                SliceParameter(name="n_components", param_type="int", description="Target dimensions", required=False)
            ],
            outputs=[
                SliceParameter(name="reduced_features", param_type="np.ndarray", description="Reduced feature matrix"),
                SliceParameter(name="explained_variance", param_type="float", description="Variance explained (for PCA)")
            ],
            dependencies=["ml_feature_scaling"],
            keywords=["dimensionality reduction", "차원 축소", "PCA", "t-SNE", "UMAP", "embedding"],
            code_template='''
def reduce_dimensions(features: pd.DataFrame, method: str = "pca", n_components: int = 2) -> Tuple[np.ndarray, float]:
    """Reduce feature dimensions"""
    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE

    explained_variance = 0.0

    if method == "pca":
        reducer = PCA(n_components=n_components, random_state=42)
        reduced = reducer.fit_transform(features)
        explained_variance = sum(reducer.explained_variance_ratio_)
    elif method == "tsne":
        reducer = TSNE(n_components=n_components, random_state=42, perplexity=min(30, len(features)-1))
        reduced = reducer.fit_transform(features)
    else:  # umap
        try:
            import umap
            reducer = umap.UMAP(n_components=n_components, random_state=42)
            reduced = reducer.fit_transform(features)
        except ImportError:
            reducer = PCA(n_components=n_components)
            reduced = reducer.fit_transform(features)

    return reduced, explained_variance
''',
            metadata=SliceMetadata(complexity=0.6, reliability=0.9, tags=["ml", "dimensionality", "pca", "tsne"])
        ),

        # 5. Feature Encoding
        FunctionSlice(
            id="ml_feature_encoding",
            name="Feature Encoding",
            description="Encode categorical features for ML models",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="data", param_type="pd.DataFrame", description="Data with categorical features"),
                SliceParameter(name="columns", param_type="List[str]", description="Columns to encode", required=False),
                SliceParameter(name="method", param_type="str", description="Encoding method: onehot, label, target", required=False)
            ],
            outputs=[
                SliceParameter(name="encoded_data", param_type="pd.DataFrame", description="Encoded data"),
                SliceParameter(name="encoders", param_type="Dict[str, Any]", description="Fitted encoders")
            ],
            dependencies=["common_validate_data"],
            keywords=["encoding", "인코딩", "categorical", "범주형", "one-hot", "label encoding"],
            code_template='''
def encode_features(data: pd.DataFrame, columns: Optional[List[str]] = None, method: str = "onehot") -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """Encode categorical features"""
    from sklearn.preprocessing import LabelEncoder, OneHotEncoder

    if columns is None:
        columns = data.select_dtypes(include=['object', 'category']).columns.tolist()

    encoded = data.copy()
    encoders = {}

    for col in columns:
        if col not in encoded.columns:
            continue

        if method == "onehot":
            dummies = pd.get_dummies(encoded[col], prefix=col)
            encoded = pd.concat([encoded.drop(col, axis=1), dummies], axis=1)
            encoders[col] = {"type": "onehot", "categories": data[col].unique().tolist()}
        else:  # label
            le = LabelEncoder()
            encoded[col] = le.fit_transform(encoded[col].astype(str))
            encoders[col] = {"type": "label", "encoder": le}

    return encoded, encoders
''',
            metadata=SliceMetadata(complexity=0.5, reliability=0.9, tags=["ml", "encoding", "categorical"])
        ),

        # 6. Missing Value Imputation
        FunctionSlice(
            id="ml_imputation",
            name="Missing Value Imputation",
            description="Handle missing values with various imputation strategies",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="data", param_type="pd.DataFrame", description="Data with missing values"),
                SliceParameter(name="strategy", param_type="str", description="Imputation strategy: mean, median, mode, knn", required=False)
            ],
            outputs=[
                SliceParameter(name="imputed_data", param_type="pd.DataFrame", description="Data without missing values"),
                SliceParameter(name="imputer", param_type="Any", description="Fitted imputer")
            ],
            dependencies=["common_validate_data"],
            keywords=["imputation", "결측치", "missing values", "누락값", "보간", "interpolation"],
            code_template='''
def impute_missing(data: pd.DataFrame, strategy: str = "mean") -> Tuple[pd.DataFrame, Any]:
    """Impute missing values"""
    from sklearn.impute import SimpleImputer, KNNImputer

    imputed = data.copy()
    numeric_cols = data.select_dtypes(include=[np.number]).columns

    if strategy == "knn":
        imputer = KNNImputer(n_neighbors=5)
    else:
        imputer = SimpleImputer(strategy=strategy)

    if len(numeric_cols) > 0:
        imputed[numeric_cols] = imputer.fit_transform(data[numeric_cols])

    # Categorical columns: mode imputation
    cat_cols = data.select_dtypes(include=['object', 'category']).columns
    for col in cat_cols:
        imputed[col].fillna(data[col].mode()[0] if len(data[col].mode()) > 0 else "unknown", inplace=True)

    return imputed, imputer
''',
            metadata=SliceMetadata(complexity=0.5, reliability=0.9, tags=["ml", "imputation", "missing"])
        ),

        # 7. Feature Interaction
        FunctionSlice(
            id="ml_feature_interaction",
            name="Feature Interaction",
            description="Create interaction features between existing features",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="features", param_type="pd.DataFrame", description="Original features"),
                SliceParameter(name="degree", param_type="int", description="Polynomial degree", required=False),
                SliceParameter(name="interaction_only", param_type="bool", description="Only interaction terms", required=False)
            ],
            outputs=[
                SliceParameter(name="interaction_features", param_type="pd.DataFrame", description="Features with interactions"),
                SliceParameter(name="feature_names", param_type="List[str]", description="New feature names")
            ],
            dependencies=["ml_feature_scaling"],
            keywords=["feature interaction", "피처 상호작용", "polynomial", "다항식", "cross features"],
            code_template='''
def create_interactions(features: pd.DataFrame, degree: int = 2, interaction_only: bool = False) -> Tuple[pd.DataFrame, List[str]]:
    """Create feature interactions"""
    from sklearn.preprocessing import PolynomialFeatures

    numeric_cols = features.select_dtypes(include=[np.number]).columns
    poly = PolynomialFeatures(degree=degree, interaction_only=interaction_only, include_bias=False)

    poly_features = poly.fit_transform(features[numeric_cols])
    feature_names = poly.get_feature_names_out(numeric_cols)

    result = pd.DataFrame(poly_features, columns=feature_names, index=features.index)
    return result, feature_names.tolist()
''',
            metadata=SliceMetadata(complexity=0.5, reliability=0.9, tags=["ml", "feature", "interaction", "polynomial"])
        ),

        # 8. Time Series Features
        FunctionSlice(
            id="ml_time_series_features",
            name="Time Series Feature Engineering",
            description="Extract time-based features from datetime columns",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="data", param_type="pd.DataFrame", description="Data with datetime column"),
                SliceParameter(name="datetime_col", param_type="str", description="Datetime column name"),
                SliceParameter(name="features", param_type="List[str]", description="Features to extract: year, month, day, hour, dayofweek, lag", required=False)
            ],
            outputs=[
                SliceParameter(name="ts_features", param_type="pd.DataFrame", description="Data with time features"),
                SliceParameter(name="feature_names", param_type="List[str]", description="Generated feature names")
            ],
            dependencies=["common_validate_data"],
            keywords=["time series", "시계열", "temporal", "시간 피처", "lag", "지연", "datetime"],
            code_template='''
def extract_time_features(data: pd.DataFrame, datetime_col: str, features: Optional[List[str]] = None) -> Tuple[pd.DataFrame, List[str]]:
    """Extract time series features"""
    features = features or ["year", "month", "day", "dayofweek", "hour"]
    result = data.copy()
    generated = []

    dt = pd.to_datetime(result[datetime_col])

    feature_extractors = {
        "year": lambda x: x.year,
        "month": lambda x: x.month,
        "day": lambda x: x.day,
        "dayofweek": lambda x: x.dayofweek,
        "hour": lambda x: x.hour,
        "quarter": lambda x: x.quarter,
        "is_weekend": lambda x: (x.dayofweek >= 5).astype(int),
        "week": lambda x: x.isocalendar().week
    }

    for feat in features:
        if feat in feature_extractors:
            col_name = f"{datetime_col}_{feat}"
            result[col_name] = feature_extractors[feat](dt)
            generated.append(col_name)
        elif feat.startswith("lag_"):
            lag = int(feat.split("_")[1])
            for col in result.select_dtypes(include=[np.number]).columns:
                col_name = f"{col}_lag{lag}"
                result[col_name] = result[col].shift(lag)
                generated.append(col_name)

    return result, generated
''',
            metadata=SliceMetadata(complexity=0.6, reliability=0.85, tags=["ml", "timeseries", "temporal"])
        ),
    ]


def _create_model_training_slices() -> List[FunctionSlice]:
    """Model Training/Prediction 슬라이스 (10개)"""
    return [
        # 1. Train Test Split
        FunctionSlice(
            id="ml_train_test_split",
            name="Train Test Split",
            description="Split data into training and testing sets",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="X", param_type="pd.DataFrame", description="Feature matrix"),
                SliceParameter(name="y", param_type="pd.Series", description="Target variable"),
                SliceParameter(name="test_size", param_type="float", description="Test set ratio", required=False),
                SliceParameter(name="stratify", param_type="bool", description="Stratified split", required=False)
            ],
            outputs=[
                SliceParameter(name="X_train", param_type="pd.DataFrame", description="Training features"),
                SliceParameter(name="X_test", param_type="pd.DataFrame", description="Test features"),
                SliceParameter(name="y_train", param_type="pd.Series", description="Training target"),
                SliceParameter(name="y_test", param_type="pd.Series", description="Test target")
            ],
            dependencies=["ml_feature_scaling"],
            keywords=["train test split", "데이터 분할", "훈련 테스트", "holdout", "검증 데이터"],
            code_template='''
def split_data(X: pd.DataFrame, y: pd.Series, test_size: float = 0.2, stratify: bool = True) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Split data into train and test sets"""
    from sklearn.model_selection import train_test_split

    stratify_param = y if stratify else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=stratify_param
    )
    return X_train, X_test, y_train, y_test
''',
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["ml", "split", "validation"])
        ),

        # 2. Classification Model Training
        FunctionSlice(
            id="ml_classification_train",
            name="Classification Model Training",
            description="Train classification models with various algorithms",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="X_train", param_type="pd.DataFrame", description="Training features"),
                SliceParameter(name="y_train", param_type="pd.Series", description="Training labels"),
                SliceParameter(name="algorithm", param_type="str", description="Algorithm: random_forest, xgboost, logistic, svm", required=False),
                SliceParameter(name="params", param_type="Dict[str, Any]", description="Model parameters", required=False)
            ],
            outputs=[
                SliceParameter(name="model", param_type="Any", description="Trained model"),
                SliceParameter(name="training_metrics", param_type="Dict[str, float]", description="Training performance metrics")
            ],
            dependencies=["ml_train_test_split", "ml_feature_scaling"],
            keywords=["classification", "분류", "classifier", "분류기", "training", "학습", "random forest", "xgboost"],
            code_template='''
def train_classifier(X_train: pd.DataFrame, y_train: pd.Series, algorithm: str = "random_forest", params: Optional[Dict[str, Any]] = None) -> Tuple[Any, Dict[str, float]]:
    """Train a classification model"""
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    from sklearn.metrics import accuracy_score, f1_score

    params = params or {}

    models = {
        "random_forest": RandomForestClassifier(n_estimators=100, random_state=42, **params),
        "gradient_boosting": GradientBoostingClassifier(random_state=42, **params),
        "logistic": LogisticRegression(random_state=42, max_iter=1000, **params),
        "svm": SVC(random_state=42, **params)
    }

    try:
        import xgboost as xgb
        models["xgboost"] = xgb.XGBClassifier(random_state=42, **params)
    except ImportError:
        pass

    model = models.get(algorithm, models["random_forest"])
    model.fit(X_train, y_train)

    y_pred = model.predict(X_train)
    metrics = {
        "accuracy": accuracy_score(y_train, y_pred),
        "f1_score": f1_score(y_train, y_pred, average="weighted")
    }

    return model, metrics
''',
            metadata=SliceMetadata(complexity=0.7, reliability=0.9, tags=["ml", "classification", "training"])
        ),

        # 3. Regression Model Training
        FunctionSlice(
            id="ml_regression_train",
            name="Regression Model Training",
            description="Train regression models with various algorithms",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="X_train", param_type="pd.DataFrame", description="Training features"),
                SliceParameter(name="y_train", param_type="pd.Series", description="Training target"),
                SliceParameter(name="algorithm", param_type="str", description="Algorithm: linear, ridge, lasso, random_forest, xgboost", required=False),
                SliceParameter(name="params", param_type="Dict[str, Any]", description="Model parameters", required=False)
            ],
            outputs=[
                SliceParameter(name="model", param_type="Any", description="Trained model"),
                SliceParameter(name="training_metrics", param_type="Dict[str, float]", description="Training performance metrics")
            ],
            dependencies=["ml_train_test_split", "ml_feature_scaling"],
            keywords=["regression", "회귀", "regressor", "예측", "prediction", "linear", "선형"],
            code_template='''
def train_regressor(X_train: pd.DataFrame, y_train: pd.Series, algorithm: str = "random_forest", params: Optional[Dict[str, Any]] = None) -> Tuple[Any, Dict[str, float]]:
    """Train a regression model"""
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.linear_model import LinearRegression, Ridge, Lasso
    from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

    params = params or {}

    models = {
        "linear": LinearRegression(**params),
        "ridge": Ridge(random_state=42, **params),
        "lasso": Lasso(random_state=42, **params),
        "random_forest": RandomForestRegressor(n_estimators=100, random_state=42, **params),
        "gradient_boosting": GradientBoostingRegressor(random_state=42, **params)
    }

    try:
        import xgboost as xgb
        models["xgboost"] = xgb.XGBRegressor(random_state=42, **params)
    except ImportError:
        pass

    model = models.get(algorithm, models["random_forest"])
    model.fit(X_train, y_train)

    y_pred = model.predict(X_train)
    metrics = {
        "rmse": np.sqrt(mean_squared_error(y_train, y_pred)),
        "mae": mean_absolute_error(y_train, y_pred),
        "r2": r2_score(y_train, y_pred)
    }

    return model, metrics
''',
            metadata=SliceMetadata(complexity=0.7, reliability=0.9, tags=["ml", "regression", "training"])
        ),

        # 4. Clustering
        FunctionSlice(
            id="ml_clustering",
            name="Clustering",
            description="Perform clustering analysis on data",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="X", param_type="pd.DataFrame", description="Feature matrix"),
                SliceParameter(name="algorithm", param_type="str", description="Algorithm: kmeans, dbscan, hierarchical", required=False),
                SliceParameter(name="n_clusters", param_type="int", description="Number of clusters", required=False)
            ],
            outputs=[
                SliceParameter(name="labels", param_type="np.ndarray", description="Cluster labels"),
                SliceParameter(name="model", param_type="Any", description="Clustering model"),
                SliceParameter(name="metrics", param_type="Dict[str, float]", description="Clustering metrics")
            ],
            dependencies=["ml_feature_scaling"],
            keywords=["clustering", "클러스터링", "군집화", "kmeans", "dbscan", "segmentation", "세그멘테이션"],
            code_template='''
def cluster_data(X: pd.DataFrame, algorithm: str = "kmeans", n_clusters: int = 5) -> Tuple[np.ndarray, Any, Dict[str, float]]:
    """Perform clustering"""
    from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
    from sklearn.metrics import silhouette_score, calinski_harabasz_score

    models = {
        "kmeans": KMeans(n_clusters=n_clusters, random_state=42, n_init=10),
        "dbscan": DBSCAN(eps=0.5, min_samples=5),
        "hierarchical": AgglomerativeClustering(n_clusters=n_clusters)
    }

    model = models.get(algorithm, models["kmeans"])
    labels = model.fit_predict(X)

    n_unique = len(set(labels)) - (1 if -1 in labels else 0)
    metrics = {"n_clusters": n_unique}

    if n_unique > 1:
        metrics["silhouette"] = silhouette_score(X, labels)
        metrics["calinski_harabasz"] = calinski_harabasz_score(X, labels)

    return labels, model, metrics
''',
            metadata=SliceMetadata(complexity=0.6, reliability=0.85, tags=["ml", "clustering", "unsupervised"])
        ),

        # 5. Model Prediction
        FunctionSlice(
            id="ml_predict",
            name="Model Prediction",
            description="Make predictions using trained model",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="model", param_type="Any", description="Trained model"),
                SliceParameter(name="X", param_type="pd.DataFrame", description="Features for prediction"),
                SliceParameter(name="return_proba", param_type="bool", description="Return probabilities", required=False)
            ],
            outputs=[
                SliceParameter(name="predictions", param_type="np.ndarray", description="Predictions"),
                SliceParameter(name="probabilities", param_type="np.ndarray", description="Prediction probabilities (if applicable)")
            ],
            dependencies=["ml_classification_train"],
            keywords=["prediction", "예측", "inference", "추론", "predict", "score"],
            code_template='''
def make_prediction(model: Any, X: pd.DataFrame, return_proba: bool = False) -> Tuple[np.ndarray, Optional[np.ndarray]]:
    """Make predictions using trained model"""
    predictions = model.predict(X)
    probabilities = None

    if return_proba and hasattr(model, 'predict_proba'):
        probabilities = model.predict_proba(X)

    return predictions, probabilities
''',
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["ml", "prediction", "inference"])
        ),

        # 6. Cross Validation
        FunctionSlice(
            id="ml_cross_validation",
            name="Cross Validation",
            description="Perform k-fold cross validation",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="model", param_type="Any", description="Model to validate"),
                SliceParameter(name="X", param_type="pd.DataFrame", description="Features"),
                SliceParameter(name="y", param_type="pd.Series", description="Target"),
                SliceParameter(name="cv", param_type="int", description="Number of folds", required=False),
                SliceParameter(name="scoring", param_type="str", description="Scoring metric", required=False)
            ],
            outputs=[
                SliceParameter(name="cv_scores", param_type="np.ndarray", description="Cross validation scores"),
                SliceParameter(name="mean_score", param_type="float", description="Mean CV score"),
                SliceParameter(name="std_score", param_type="float", description="Std of CV scores")
            ],
            dependencies=["ml_classification_train"],
            keywords=["cross validation", "교차 검증", "k-fold", "validation", "검증", "cv"],
            code_template='''
def cross_validate(model: Any, X: pd.DataFrame, y: pd.Series, cv: int = 5, scoring: str = "accuracy") -> Tuple[np.ndarray, float, float]:
    """Perform cross validation"""
    from sklearn.model_selection import cross_val_score

    scores = cross_val_score(model, X, y, cv=cv, scoring=scoring)
    return scores, scores.mean(), scores.std()
''',
            metadata=SliceMetadata(complexity=0.5, reliability=0.9, tags=["ml", "validation", "cross-validation"])
        ),

        # 7. Hyperparameter Tuning
        FunctionSlice(
            id="ml_hyperparameter_tuning",
            name="Hyperparameter Tuning",
            description="Optimize model hyperparameters using grid search or random search",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="model", param_type="Any", description="Base model"),
                SliceParameter(name="X", param_type="pd.DataFrame", description="Features"),
                SliceParameter(name="y", param_type="pd.Series", description="Target"),
                SliceParameter(name="param_grid", param_type="Dict[str, List]", description="Parameter grid"),
                SliceParameter(name="method", param_type="str", description="Search method: grid, random", required=False)
            ],
            outputs=[
                SliceParameter(name="best_model", param_type="Any", description="Best model"),
                SliceParameter(name="best_params", param_type="Dict[str, Any]", description="Best parameters"),
                SliceParameter(name="best_score", param_type="float", description="Best score")
            ],
            dependencies=["ml_cross_validation"],
            keywords=["hyperparameter", "하이퍼파라미터", "tuning", "튜닝", "grid search", "그리드 서치", "optimization"],
            code_template='''
def tune_hyperparameters(model: Any, X: pd.DataFrame, y: pd.Series, param_grid: Dict[str, List], method: str = "grid") -> Tuple[Any, Dict[str, Any], float]:
    """Tune model hyperparameters"""
    from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

    if method == "random":
        search = RandomizedSearchCV(model, param_grid, n_iter=20, cv=5, random_state=42, n_jobs=-1)
    else:
        search = GridSearchCV(model, param_grid, cv=5, n_jobs=-1)

    search.fit(X, y)
    return search.best_estimator_, search.best_params_, search.best_score_
''',
            metadata=SliceMetadata(complexity=0.7, reliability=0.85, tags=["ml", "hyperparameter", "optimization"])
        ),

        # 8. Ensemble Learning
        FunctionSlice(
            id="ml_ensemble",
            name="Ensemble Learning",
            description="Create ensemble models using voting or stacking",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="models", param_type="List[Any]", description="List of base models"),
                SliceParameter(name="X_train", param_type="pd.DataFrame", description="Training features"),
                SliceParameter(name="y_train", param_type="pd.Series", description="Training target"),
                SliceParameter(name="method", param_type="str", description="Ensemble method: voting, stacking, bagging", required=False)
            ],
            outputs=[
                SliceParameter(name="ensemble_model", param_type="Any", description="Trained ensemble model"),
                SliceParameter(name="metrics", param_type="Dict[str, float]", description="Ensemble performance")
            ],
            dependencies=["ml_classification_train"],
            keywords=["ensemble", "앙상블", "voting", "투표", "stacking", "스태킹", "bagging", "배깅"],
            code_template='''
def create_ensemble(models: List[Any], X_train: pd.DataFrame, y_train: pd.Series, method: str = "voting") -> Tuple[Any, Dict[str, float]]:
    """Create ensemble model"""
    from sklearn.ensemble import VotingClassifier, StackingClassifier, BaggingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import accuracy_score

    estimators = [(f"model_{i}", m) for i, m in enumerate(models)]

    if method == "stacking":
        ensemble = StackingClassifier(estimators=estimators, final_estimator=LogisticRegression())
    elif method == "bagging":
        ensemble = BaggingClassifier(estimator=models[0], n_estimators=10, random_state=42)
    else:  # voting
        ensemble = VotingClassifier(estimators=estimators, voting="soft")

    ensemble.fit(X_train, y_train)
    y_pred = ensemble.predict(X_train)

    metrics = {"accuracy": accuracy_score(y_train, y_pred)}
    return ensemble, metrics
''',
            metadata=SliceMetadata(complexity=0.7, reliability=0.85, tags=["ml", "ensemble", "voting", "stacking"])
        ),

        # 9. Neural Network Training
        FunctionSlice(
            id="ml_neural_network",
            name="Neural Network Training",
            description="Train neural network models",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="X_train", param_type="pd.DataFrame", description="Training features"),
                SliceParameter(name="y_train", param_type="pd.Series", description="Training target"),
                SliceParameter(name="hidden_layers", param_type="Tuple[int, ...]", description="Hidden layer sizes", required=False),
                SliceParameter(name="epochs", param_type="int", description="Training epochs", required=False)
            ],
            outputs=[
                SliceParameter(name="model", param_type="Any", description="Trained neural network"),
                SliceParameter(name="history", param_type="Dict[str, List]", description="Training history")
            ],
            dependencies=["ml_feature_scaling", "ml_train_test_split"],
            keywords=["neural network", "신경망", "deep learning", "딥러닝", "MLP", "perceptron"],
            code_template='''
def train_neural_network(X_train: pd.DataFrame, y_train: pd.Series, hidden_layers: Tuple[int, ...] = (100, 50), epochs: int = 100) -> Tuple[Any, Dict[str, List]]:
    """Train neural network"""
    from sklearn.neural_network import MLPClassifier

    model = MLPClassifier(
        hidden_layer_sizes=hidden_layers,
        max_iter=epochs,
        random_state=42,
        early_stopping=True,
        validation_fraction=0.1
    )
    model.fit(X_train, y_train)

    history = {
        "loss": model.loss_curve_ if hasattr(model, 'loss_curve_') else [],
        "n_iter": model.n_iter_
    }

    return model, history
''',
            metadata=SliceMetadata(complexity=0.8, reliability=0.8, tags=["ml", "neural", "deep-learning"])
        ),

        # 10. AutoML
        FunctionSlice(
            id="ml_automl",
            name="AutoML",
            description="Automated machine learning model selection and tuning",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="X_train", param_type="pd.DataFrame", description="Training features"),
                SliceParameter(name="y_train", param_type="pd.Series", description="Training target"),
                SliceParameter(name="task", param_type="str", description="Task type: classification, regression", required=False),
                SliceParameter(name="time_budget", param_type="int", description="Time budget in seconds", required=False)
            ],
            outputs=[
                SliceParameter(name="best_model", param_type="Any", description="Best model found"),
                SliceParameter(name="model_ranking", param_type="List[Dict]", description="Model performance ranking"),
                SliceParameter(name="best_score", param_type="float", description="Best model score")
            ],
            dependencies=["ml_train_test_split", "ml_feature_scaling"],
            keywords=["automl", "자동 머신러닝", "automated", "자동화", "model selection", "모델 선택"],
            code_template='''
def run_automl(X_train: pd.DataFrame, y_train: pd.Series, task: str = "classification", time_budget: int = 60) -> Tuple[Any, List[Dict], float]:
    """Run AutoML for model selection"""
    from sklearn.model_selection import cross_val_score
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
    from sklearn.linear_model import LogisticRegression, Ridge

    if task == "classification":
        models = [
            ("RandomForest", RandomForestClassifier(n_estimators=100, random_state=42)),
            ("GradientBoosting", GradientBoostingClassifier(random_state=42)),
            ("LogisticRegression", LogisticRegression(random_state=42, max_iter=1000))
        ]
        scoring = "accuracy"
    else:
        models = [
            ("RandomForest", RandomForestRegressor(n_estimators=100, random_state=42)),
            ("GradientBoosting", GradientBoostingRegressor(random_state=42)),
            ("Ridge", Ridge(random_state=42))
        ]
        scoring = "r2"

    results = []
    for name, model in models:
        try:
            scores = cross_val_score(model, X_train, y_train, cv=3, scoring=scoring)
            results.append({"model": name, "score": scores.mean(), "std": scores.std(), "estimator": model})
        except Exception as e:
            results.append({"model": name, "score": 0, "std": 0, "error": str(e)})

    results.sort(key=lambda x: x["score"], reverse=True)
    best = results[0]
    best["estimator"].fit(X_train, y_train)

    return best["estimator"], results, best["score"]
''',
            metadata=SliceMetadata(complexity=0.8, reliability=0.8, tags=["ml", "automl", "automation"])
        ),
    ]


def _create_evaluation_slices() -> List[FunctionSlice]:
    """Evaluation/Optimization 슬라이스 (7개)"""
    return [
        # 1. Classification Metrics
        FunctionSlice(
            id="ml_classification_metrics",
            name="Classification Metrics",
            description="Calculate classification performance metrics",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="y_true", param_type="np.ndarray", description="True labels"),
                SliceParameter(name="y_pred", param_type="np.ndarray", description="Predicted labels"),
                SliceParameter(name="y_proba", param_type="np.ndarray", description="Prediction probabilities", required=False)
            ],
            outputs=[
                SliceParameter(name="metrics", param_type="Dict[str, float]", description="All classification metrics"),
                SliceParameter(name="confusion_matrix", param_type="np.ndarray", description="Confusion matrix")
            ],
            dependencies=["ml_predict"],
            keywords=["classification metrics", "분류 평가", "accuracy", "정확도", "precision", "recall", "f1", "auc"],
            code_template='''
def calculate_classification_metrics(y_true: np.ndarray, y_pred: np.ndarray, y_proba: Optional[np.ndarray] = None) -> Tuple[Dict[str, float], np.ndarray]:
    """Calculate classification metrics"""
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
    from sklearn.metrics import confusion_matrix, roc_auc_score, classification_report

    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "recall": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "f1": f1_score(y_true, y_pred, average="weighted", zero_division=0)
    }

    if y_proba is not None:
        try:
            if len(y_proba.shape) > 1 and y_proba.shape[1] == 2:
                metrics["auc"] = roc_auc_score(y_true, y_proba[:, 1])
            else:
                metrics["auc"] = roc_auc_score(y_true, y_proba, multi_class="ovr")
        except:
            metrics["auc"] = None

    cm = confusion_matrix(y_true, y_pred)
    return metrics, cm
''',
            metadata=SliceMetadata(complexity=0.5, reliability=0.95, tags=["ml", "evaluation", "classification"])
        ),

        # 2. Regression Metrics
        FunctionSlice(
            id="ml_regression_metrics",
            name="Regression Metrics",
            description="Calculate regression performance metrics",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="y_true", param_type="np.ndarray", description="True values"),
                SliceParameter(name="y_pred", param_type="np.ndarray", description="Predicted values")
            ],
            outputs=[
                SliceParameter(name="metrics", param_type="Dict[str, float]", description="All regression metrics")
            ],
            dependencies=["ml_predict"],
            keywords=["regression metrics", "회귀 평가", "mse", "rmse", "mae", "r2", "mape"],
            code_template='''
def calculate_regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Calculate regression metrics"""
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
    from sklearn.metrics import mean_absolute_percentage_error

    metrics = {
        "mse": mean_squared_error(y_true, y_pred),
        "rmse": np.sqrt(mean_squared_error(y_true, y_pred)),
        "mae": mean_absolute_error(y_true, y_pred),
        "r2": r2_score(y_true, y_pred)
    }

    try:
        metrics["mape"] = mean_absolute_percentage_error(y_true, y_pred)
    except:
        metrics["mape"] = None

    return metrics
''',
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["ml", "evaluation", "regression"])
        ),

        # 3. Feature Importance Analysis
        FunctionSlice(
            id="ml_feature_importance",
            name="Feature Importance Analysis",
            description="Analyze and visualize feature importance",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="model", param_type="Any", description="Trained model"),
                SliceParameter(name="feature_names", param_type="List[str]", description="Feature names"),
                SliceParameter(name="X", param_type="pd.DataFrame", description="Features for SHAP analysis", required=False)
            ],
            outputs=[
                SliceParameter(name="importance", param_type="Dict[str, float]", description="Feature importance scores"),
                SliceParameter(name="ranked_features", param_type="List[Tuple[str, float]]", description="Ranked features")
            ],
            dependencies=["ml_classification_train"],
            keywords=["feature importance", "피처 중요도", "변수 중요도", "SHAP", "permutation"],
            code_template='''
def analyze_feature_importance(model: Any, feature_names: List[str], X: Optional[pd.DataFrame] = None) -> Tuple[Dict[str, float], List[Tuple[str, float]]]:
    """Analyze feature importance"""
    importance = {}

    if hasattr(model, 'feature_importances_'):
        importance = dict(zip(feature_names, model.feature_importances_))
    elif hasattr(model, 'coef_'):
        coef = model.coef_.flatten() if len(model.coef_.shape) > 1 else model.coef_
        importance = dict(zip(feature_names, np.abs(coef)))
    else:
        importance = {name: 0.0 for name in feature_names}

    ranked = sorted(importance.items(), key=lambda x: x[1], reverse=True)
    return importance, ranked
''',
            metadata=SliceMetadata(complexity=0.5, reliability=0.85, tags=["ml", "feature", "importance"])
        ),

        # 4. Model Comparison
        FunctionSlice(
            id="ml_model_comparison",
            name="Model Comparison",
            description="Compare multiple models on same dataset",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="models", param_type="List[Tuple[str, Any]]", description="List of (name, model) tuples"),
                SliceParameter(name="X", param_type="pd.DataFrame", description="Features"),
                SliceParameter(name="y", param_type="pd.Series", description="Target"),
                SliceParameter(name="cv", param_type="int", description="Cross validation folds", required=False)
            ],
            outputs=[
                SliceParameter(name="comparison_results", param_type="pd.DataFrame", description="Comparison table"),
                SliceParameter(name="best_model", param_type="str", description="Name of best model")
            ],
            dependencies=["ml_cross_validation"],
            keywords=["model comparison", "모델 비교", "benchmark", "벤치마크", "comparison"],
            code_template='''
def compare_models(models: List[Tuple[str, Any]], X: pd.DataFrame, y: pd.Series, cv: int = 5) -> Tuple[pd.DataFrame, str]:
    """Compare multiple models"""
    from sklearn.model_selection import cross_val_score

    results = []
    for name, model in models:
        try:
            scores = cross_val_score(model, X, y, cv=cv, scoring="accuracy")
            results.append({
                "model": name,
                "mean_score": scores.mean(),
                "std_score": scores.std(),
                "min_score": scores.min(),
                "max_score": scores.max()
            })
        except Exception as e:
            results.append({
                "model": name,
                "mean_score": 0,
                "std_score": 0,
                "error": str(e)
            })

    df = pd.DataFrame(results).sort_values("mean_score", ascending=False)
    best = df.iloc[0]["model"]
    return df, best
''',
            metadata=SliceMetadata(complexity=0.6, reliability=0.9, tags=["ml", "comparison", "benchmark"])
        ),

        # 5. Model Explainability
        FunctionSlice(
            id="ml_explainability",
            name="Model Explainability",
            description="Generate model explanations using SHAP or LIME",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="model", param_type="Any", description="Trained model"),
                SliceParameter(name="X", param_type="pd.DataFrame", description="Features to explain"),
                SliceParameter(name="method", param_type="str", description="Explanation method: shap, lime", required=False)
            ],
            outputs=[
                SliceParameter(name="explanations", param_type="Any", description="Model explanations"),
                SliceParameter(name="summary", param_type="Dict[str, Any]", description="Explanation summary")
            ],
            dependencies=["ml_feature_importance"],
            keywords=["explainability", "설명가능성", "SHAP", "LIME", "interpretability", "해석가능성", "XAI"],
            code_template='''
def explain_model(model: Any, X: pd.DataFrame, method: str = "shap") -> Tuple[Any, Dict[str, Any]]:
    """Generate model explanations"""
    summary = {"method": method, "n_samples": len(X)}

    try:
        if method == "shap":
            import shap
            explainer = shap.TreeExplainer(model) if hasattr(model, 'feature_importances_') else shap.KernelExplainer(model.predict, X.sample(min(100, len(X))))
            shap_values = explainer.shap_values(X)

            if isinstance(shap_values, list):
                shap_values = shap_values[1] if len(shap_values) > 1 else shap_values[0]

            mean_abs_shap = np.abs(shap_values).mean(axis=0)
            summary["feature_importance"] = dict(zip(X.columns, mean_abs_shap))
            return shap_values, summary
        else:
            # Fallback to permutation importance
            from sklearn.inspection import permutation_importance
            result = permutation_importance(model, X, np.zeros(len(X)), n_repeats=10, random_state=42)
            summary["feature_importance"] = dict(zip(X.columns, result.importances_mean))
            return result, summary
    except ImportError:
        summary["error"] = "SHAP library not installed"
        return None, summary
''',
            metadata=SliceMetadata(complexity=0.8, reliability=0.75, tags=["ml", "explainability", "shap", "xai"])
        ),

        # 6. Model Persistence
        FunctionSlice(
            id="ml_model_persistence",
            name="Model Persistence",
            description="Save and load ML models",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="model", param_type="Any", description="Model to save", required=False),
                SliceParameter(name="filepath", param_type="str", description="Path to save/load model"),
                SliceParameter(name="operation", param_type="str", description="Operation: save, load")
            ],
            outputs=[
                SliceParameter(name="result", param_type="Any", description="Loaded model or save status"),
                SliceParameter(name="metadata", param_type="Dict[str, Any]", description="Model metadata")
            ],
            dependencies=[],
            keywords=["model save", "모델 저장", "model load", "모델 로드", "persistence", "pickle", "joblib"],
            code_template='''
def persist_model(model: Optional[Any] = None, filepath: str = "model.pkl", operation: str = "save") -> Tuple[Any, Dict[str, Any]]:
    """Save or load ML model"""
    import joblib
    import os
    from datetime import datetime

    metadata = {"filepath": filepath, "operation": operation, "timestamp": datetime.now().isoformat()}

    if operation == "save":
        if model is None:
            raise ValueError("Model required for save operation")
        joblib.dump(model, filepath)
        metadata["status"] = "saved"
        metadata["size_bytes"] = os.path.getsize(filepath)
        return True, metadata
    else:  # load
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found: {filepath}")
        loaded_model = joblib.load(filepath)
        metadata["status"] = "loaded"
        metadata["model_type"] = type(loaded_model).__name__
        return loaded_model, metadata
''',
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["ml", "persistence", "save", "load"])
        ),

        # 7. Learning Curve Analysis
        FunctionSlice(
            id="ml_learning_curve",
            name="Learning Curve Analysis",
            description="Analyze model learning curves for bias/variance diagnosis",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.ML_AI,
            inputs=[
                SliceParameter(name="model", param_type="Any", description="Model to analyze"),
                SliceParameter(name="X", param_type="pd.DataFrame", description="Features"),
                SliceParameter(name="y", param_type="pd.Series", description="Target"),
                SliceParameter(name="train_sizes", param_type="List[float]", description="Training set sizes", required=False)
            ],
            outputs=[
                SliceParameter(name="train_sizes_abs", param_type="np.ndarray", description="Absolute training sizes"),
                SliceParameter(name="train_scores", param_type="np.ndarray", description="Training scores"),
                SliceParameter(name="test_scores", param_type="np.ndarray", description="Test scores"),
                SliceParameter(name="diagnosis", param_type="str", description="Bias/variance diagnosis")
            ],
            dependencies=["ml_cross_validation"],
            keywords=["learning curve", "학습 곡선", "bias", "편향", "variance", "분산", "overfitting", "과적합"],
            code_template='''
def analyze_learning_curve(model: Any, X: pd.DataFrame, y: pd.Series, train_sizes: Optional[List[float]] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    """Analyze learning curves"""
    from sklearn.model_selection import learning_curve

    train_sizes = train_sizes or [0.1, 0.25, 0.5, 0.75, 1.0]

    train_sizes_abs, train_scores, test_scores = learning_curve(
        model, X, y, train_sizes=train_sizes, cv=5, n_jobs=-1, scoring="accuracy"
    )

    # Diagnosis
    train_mean = train_scores.mean(axis=1)
    test_mean = test_scores.mean(axis=1)
    gap = train_mean[-1] - test_mean[-1]

    if gap > 0.1:
        diagnosis = "High Variance (Overfitting) - Consider more data or regularization"
    elif test_mean[-1] < 0.7:
        diagnosis = "High Bias (Underfitting) - Consider more features or complex model"
    else:
        diagnosis = "Good Fit - Model generalizes well"

    return train_sizes_abs, train_scores, test_scores, diagnosis
''',
            metadata=SliceMetadata(complexity=0.6, reliability=0.85, tags=["ml", "learning-curve", "diagnosis"])
        ),
    ]


# Export function
def get_ml_ai_slice_ids() -> List[str]:
    """ML/AI 슬라이스 ID 목록 반환"""
    slices = create_ml_ai_slices()
    return [s.id for s in slices]
