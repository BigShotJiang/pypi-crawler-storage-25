"""
Inventory/Supply Chain Domain Function Slices
==============================================
재고 및 공급망 관리 도메인 특화 슬라이스 (15개)

카테고리:
1. Inventory Management (5개) - 재고 관리
2. Supply Chain (5개) - 공급망 관리
3. Demand Forecasting (5개) - 수요 예측
"""

from typing import List
from ..models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceMetadata
)


def create_inventory_slices() -> List[FunctionSlice]:
    """Inventory/Supply Chain Domain Slices 생성"""
    slices = []
    slices.extend(_create_inventory_management_slices())
    slices.extend(_create_supply_chain_slices())
    slices.extend(_create_demand_forecasting_slices())
    return slices


# =============================================================================
# Inventory Management Slices (5개)
# =============================================================================

def _create_inventory_management_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="inventory.stock.reorder_point",
            name="Reorder Point Calculator",
            description="안전 재고와 리드타임을 고려한 재주문점을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="daily_sales", param_type="float", description="일평균 판매량", required=True),
                SliceParameter(name="lead_time_days", param_type="int", description="리드타임(일)", required=True),
                SliceParameter(name="safety_stock", param_type="float", description="안전재고", required=True),
            ],
            outputs=[SliceParameter(name="reorder_point", param_type="float", description="재주문점")],
            dependencies=[],
            keywords={
                "ko": ["재주문점", "발주점", "재고", "리드타임", "안전재고", "inventory"],
                "en": ["reorder", "point", "inventory", "lead", "time", "safety", "stock"]
            },
            code_template='''
        # 재주문점 = (일평균 판매량 × 리드타임) + 안전재고
        reorder_point = (daily_sales * lead_time_days) + safety_stock
        return reorder_point
''',
            function_name="_calculate_reorder_point",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["inventory", "reorder", "stock"])
        ),
        FunctionSlice(
            id="inventory.stock.eoq",
            name="Economic Order Quantity",
            description="경제적 주문량(EOQ)을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="annual_demand", param_type="float", description="연간 수요량", required=True),
                SliceParameter(name="order_cost", param_type="float", description="주문 비용", required=True),
                SliceParameter(name="holding_cost", param_type="float", description="보관 비용(단위당)", required=True),
            ],
            outputs=[SliceParameter(name="eoq", param_type="float", description="경제적 주문량")],
            dependencies=[],
            keywords={
                "ko": ["경제적주문량", "EOQ", "주문량", "발주량", "재고비용"],
                "en": ["economic", "order", "quantity", "eoq", "inventory", "cost"]
            },
            code_template='''
        import math
        # EOQ = sqrt((2 × 연간수요 × 주문비용) / 보관비용)
        eoq = math.sqrt((2 * annual_demand * order_cost) / holding_cost)
        return eoq
''',
            function_name="_calculate_eoq",
            metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["inventory", "eoq", "optimization"])
        ),
        FunctionSlice(
            id="inventory.stock.turnover",
            name="Inventory Turnover Ratio",
            description="재고회전율을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="cost_of_goods_sold", param_type="float", description="매출원가", required=True),
                SliceParameter(name="average_inventory", param_type="float", description="평균재고", required=True),
            ],
            outputs=[SliceParameter(name="turnover_ratio", param_type="float", description="재고회전율")],
            dependencies=[],
            keywords={
                "ko": ["재고회전율", "회전율", "재고효율", "inventory", "turnover"],
                "en": ["inventory", "turnover", "ratio", "efficiency", "stock"]
            },
            code_template='''
        # 재고회전율 = 매출원가 / 평균재고
        turnover_ratio = cost_of_goods_sold / average_inventory if average_inventory > 0 else 0
        return turnover_ratio
''',
            function_name="_calculate_turnover_ratio",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["inventory", "turnover", "ratio"])
        ),
        FunctionSlice(
            id="inventory.stock.abc_analysis",
            name="ABC Inventory Analysis",
            description="재고를 가치 기준으로 ABC 분류합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="inventory_data", param_type="pd.DataFrame", description="재고 데이터", required=True),
                SliceParameter(name="value_col", param_type="str", description="가치 컬럼", required=True),
                SliceParameter(name="item_col", param_type="str", description="품목 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="classified", param_type="pd.DataFrame", description="ABC 분류 결과")],
            dependencies=[],
            keywords={
                "ko": ["ABC분석", "재고분류", "파레토", "중요도", "재고관리"],
                "en": ["abc", "analysis", "pareto", "inventory", "classification"]
            },
            code_template='''
        import pandas as pd

        result = inventory_data.copy()
        result = result.sort_values(by=value_col, ascending=False)
        result['cumulative_value'] = result[value_col].cumsum()
        total_value = result[value_col].sum()
        result['cumulative_pct'] = result['cumulative_value'] / total_value * 100

        # ABC 분류
        result['abc_class'] = 'C'
        result.loc[result['cumulative_pct'] <= 80, 'abc_class'] = 'A'
        result.loc[(result['cumulative_pct'] > 80) & (result['cumulative_pct'] <= 95), 'abc_class'] = 'B'

        return result
''',
            function_name="_abc_analysis",
            metadata=SliceMetadata(complexity=0.4, reliability=0.97, tags=["inventory", "abc", "classification"])
        ),
        FunctionSlice(
            id="inventory.stock.days_on_hand",
            name="Days of Inventory on Hand",
            description="재고 보유일수를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="current_inventory", param_type="float", description="현재 재고량", required=True),
                SliceParameter(name="daily_usage", param_type="float", description="일평균 사용량", required=True),
            ],
            outputs=[SliceParameter(name="days_on_hand", param_type="float", description="재고 보유일수")],
            dependencies=[],
            keywords={
                "ko": ["재고보유일", "보유일수", "재고일", "재고기간"],
                "en": ["days", "inventory", "hand", "stock", "duration"]
            },
            code_template='''
        # 재고 보유일수 = 현재 재고 / 일평균 사용량
        days_on_hand = current_inventory / daily_usage if daily_usage > 0 else float('inf')
        return days_on_hand
''',
            function_name="_calculate_days_on_hand",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["inventory", "days", "stock"])
        ),
    ]


# =============================================================================
# Supply Chain Slices (5개)
# =============================================================================

def _create_supply_chain_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="supply.vendor.evaluation",
            name="Vendor Performance Score",
            description="공급업체 성과를 평가합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="delivery_rate", param_type="float", description="납기 준수율 (0-1)", required=True),
                SliceParameter(name="quality_rate", param_type="float", description="품질 적합율 (0-1)", required=True),
                SliceParameter(name="price_competitiveness", param_type="float", description="가격 경쟁력 (0-1)", required=True),
                SliceParameter(name="weights", param_type="Dict[str, float]", description="가중치", default={"delivery": 0.4, "quality": 0.4, "price": 0.2}, required=False),
            ],
            outputs=[SliceParameter(name="score", param_type="float", description="공급업체 성과 점수")],
            dependencies=[],
            keywords={
                "ko": ["공급업체", "벤더", "평가", "성과", "납기", "품질"],
                "en": ["vendor", "supplier", "evaluation", "performance", "score"]
            },
            code_template='''
        score = (
            delivery_rate * weights.get("delivery", 0.4) +
            quality_rate * weights.get("quality", 0.4) +
            price_competitiveness * weights.get("price", 0.2)
        )
        return min(max(score, 0), 1)  # 0-1 범위로 제한
''',
            function_name="_evaluate_vendor",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["supply", "vendor", "evaluation"])
        ),
        FunctionSlice(
            id="supply.lead.time_analysis",
            name="Lead Time Analysis",
            description="리드타임을 분석하고 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="historical_lead_times", param_type="List[float]", description="과거 리드타임 데이터", required=True),
            ],
            outputs=[SliceParameter(name="analysis", param_type="Dict[str, float]", description="리드타임 분석 결과")],
            dependencies=["common.stats.outliers"],
            keywords={
                "ko": ["리드타임", "납기", "소요시간", "분석", "예측"],
                "en": ["lead", "time", "analysis", "delivery", "forecast"]
            },
            code_template='''
        import statistics

        mean_lt = statistics.mean(historical_lead_times)
        std_lt = statistics.stdev(historical_lead_times) if len(historical_lead_times) > 1 else 0
        max_lt = max(historical_lead_times)
        min_lt = min(historical_lead_times)

        analysis = {
            "mean": mean_lt,
            "std": std_lt,
            "max": max_lt,
            "min": min_lt,
            "safety_lead_time": mean_lt + (2 * std_lt)  # 95% 신뢰구간
        }
        return analysis
''',
            function_name="_analyze_lead_time",
            metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["supply", "lead", "time"])
        ),
        FunctionSlice(
            id="supply.order.optimal_quantity",
            name="Optimal Order Quantity",
            description="최적 발주 수량을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="forecast_demand", param_type="float", description="예측 수요", required=True),
                SliceParameter(name="current_stock", param_type="float", description="현재 재고", required=True),
                SliceParameter(name="safety_stock", param_type="float", description="안전 재고", required=True),
                SliceParameter(name="min_order_qty", param_type="float", description="최소 주문량", default=0, required=False),
            ],
            outputs=[SliceParameter(name="order_qty", param_type="float", description="최적 발주량")],
            dependencies=[],
            keywords={
                "ko": ["발주량", "주문량", "최적", "수량", "발주"],
                "en": ["order", "quantity", "optimal", "purchase", "stock"]
            },
            code_template='''
        # 필요량 = 예측수요 + 안전재고 - 현재재고
        required = forecast_demand + safety_stock - current_stock
        order_qty = max(required, 0)

        # 최소 주문량 적용
        if order_qty > 0 and order_qty < min_order_qty:
            order_qty = min_order_qty

        return order_qty
''',
            function_name="_calculate_optimal_order",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["supply", "order", "quantity"])
        ),
        FunctionSlice(
            id="supply.cost.total_cost",
            name="Total Supply Chain Cost",
            description="총 공급망 비용을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="purchase_cost", param_type="float", description="구매 비용", required=True),
                SliceParameter(name="ordering_cost", param_type="float", description="주문 비용", required=True),
                SliceParameter(name="holding_cost", param_type="float", description="보관 비용", required=True),
                SliceParameter(name="shortage_cost", param_type="float", description="품절 비용", default=0, required=False),
            ],
            outputs=[SliceParameter(name="total_cost", param_type="float", description="총 공급망 비용")],
            dependencies=[],
            keywords={
                "ko": ["공급망비용", "총비용", "물류비용", "재고비용"],
                "en": ["supply", "chain", "cost", "total", "logistics"]
            },
            code_template='''
        total_cost = purchase_cost + ordering_cost + holding_cost + shortage_cost
        return total_cost
''',
            function_name="_calculate_supply_chain_cost",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["supply", "cost", "total"])
        ),
        FunctionSlice(
            id="supply.fulfillment.rate",
            name="Order Fulfillment Rate",
            description="주문 이행율을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="orders_fulfilled", param_type="int", description="완료 주문 수", required=True),
                SliceParameter(name="total_orders", param_type="int", description="총 주문 수", required=True),
            ],
            outputs=[SliceParameter(name="fulfillment_rate", param_type="float", description="주문 이행율")],
            dependencies=[],
            keywords={
                "ko": ["이행율", "충족율", "주문완료", "배송"],
                "en": ["fulfillment", "rate", "order", "completion", "delivery"]
            },
            code_template='''
        fulfillment_rate = orders_fulfilled / total_orders if total_orders > 0 else 0
        return fulfillment_rate
''',
            function_name="_calculate_fulfillment_rate",
            metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["supply", "fulfillment", "rate"])
        ),
    ]


# =============================================================================
# Demand Forecasting Slices (5개)
# =============================================================================

def _create_demand_forecasting_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="demand.forecast.moving_average",
            name="Moving Average Forecast",
            description="이동평균으로 수요를 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="historical_demand", param_type="List[float]", description="과거 수요 데이터", required=True),
                SliceParameter(name="periods", param_type="int", description="이동평균 기간", default=3, required=False),
            ],
            outputs=[SliceParameter(name="forecast", param_type="float", description="예측 수요")],
            dependencies=[],
            keywords={
                "ko": ["수요예측", "이동평균", "예측", "판매예측"],
                "en": ["demand", "forecast", "moving", "average", "prediction"]
            },
            code_template='''
        if len(historical_demand) < periods:
            forecast = sum(historical_demand) / len(historical_demand) if historical_demand else 0
        else:
            forecast = sum(historical_demand[-periods:]) / periods
        return forecast
''',
            function_name="_forecast_moving_average",
            metadata=SliceMetadata(complexity=0.3, reliability=0.90, tags=["demand", "forecast", "moving_average"])
        ),
        FunctionSlice(
            id="demand.forecast.exponential_smoothing",
            name="Exponential Smoothing Forecast",
            description="지수평활법으로 수요를 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="historical_demand", param_type="List[float]", description="과거 수요 데이터", required=True),
                SliceParameter(name="alpha", param_type="float", description="평활계수 (0-1)", default=0.3, required=False),
            ],
            outputs=[SliceParameter(name="forecast", param_type="float", description="예측 수요")],
            dependencies=[],
            keywords={
                "ko": ["지수평활", "수요예측", "예측", "평활법"],
                "en": ["exponential", "smoothing", "demand", "forecast"]
            },
            code_template='''
        if not historical_demand:
            return 0

        forecast = historical_demand[0]
        for demand in historical_demand[1:]:
            forecast = alpha * demand + (1 - alpha) * forecast
        return forecast
''',
            function_name="_forecast_exponential_smoothing",
            metadata=SliceMetadata(complexity=0.4, reliability=0.88, tags=["demand", "forecast", "exponential"])
        ),
        FunctionSlice(
            id="demand.forecast.seasonal",
            name="Seasonal Demand Forecast",
            description="계절성을 고려한 수요를 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="historical_demand", param_type="pd.DataFrame", description="과거 수요 데이터", required=True),
                SliceParameter(name="date_col", param_type="str", description="날짜 컬럼", required=True),
                SliceParameter(name="demand_col", param_type="str", description="수요 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="seasonal_factors", param_type="Dict[int, float]", description="월별 계절 지수")],
            dependencies=[],
            keywords={
                "ko": ["계절성", "시즌", "월별수요", "계절예측"],
                "en": ["seasonal", "demand", "forecast", "monthly", "pattern"]
            },
            code_template='''
        import pandas as pd

        df = historical_demand.copy()
        df['month'] = pd.to_datetime(df[date_col]).dt.month

        monthly_avg = df.groupby('month')[demand_col].mean()
        overall_avg = df[demand_col].mean()

        seasonal_factors = (monthly_avg / overall_avg).to_dict()
        return seasonal_factors
''',
            function_name="_analyze_seasonal_demand",
            metadata=SliceMetadata(complexity=0.5, reliability=0.85, tags=["demand", "seasonal", "forecast"])
        ),
        FunctionSlice(
            id="demand.forecast.safety_stock",
            name="Safety Stock Calculator",
            description="수요 변동성을 고려한 안전재고를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="demand_std", param_type="float", description="수요 표준편차", required=True),
                SliceParameter(name="lead_time_days", param_type="int", description="리드타임(일)", required=True),
                SliceParameter(name="service_level", param_type="float", description="서비스 수준 (0-1)", default=0.95, required=False),
            ],
            outputs=[SliceParameter(name="safety_stock", param_type="float", description="안전재고")],
            dependencies=[],
            keywords={
                "ko": ["안전재고", "버퍼재고", "서비스수준", "재고"],
                "en": ["safety", "stock", "buffer", "service", "level"]
            },
            code_template='''
        import math
        from scipy import stats

        # Z-score 계산 (서비스 수준에 따른)
        z_score = stats.norm.ppf(service_level)

        # 안전재고 = Z × 수요표준편차 × sqrt(리드타임)
        safety_stock = z_score * demand_std * math.sqrt(lead_time_days)
        return safety_stock
''',
            function_name="_calculate_safety_stock",
            metadata=SliceMetadata(complexity=0.4, reliability=0.92, tags=["safety", "stock", "demand"])
        ),
        FunctionSlice(
            id="demand.forecast.accuracy",
            name="Forecast Accuracy Metrics",
            description="수요 예측 정확도를 측정합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.INVENTORY,
            inputs=[
                SliceParameter(name="actual", param_type="List[float]", description="실제 수요", required=True),
                SliceParameter(name="predicted", param_type="List[float]", description="예측 수요", required=True),
            ],
            outputs=[SliceParameter(name="metrics", param_type="Dict[str, float]", description="정확도 지표")],
            dependencies=[],
            keywords={
                "ko": ["예측정확도", "MAPE", "MAE", "정확도", "오차"],
                "en": ["forecast", "accuracy", "mape", "mae", "error"]
            },
            code_template='''
        import statistics

        n = len(actual)
        if n != len(predicted) or n == 0:
            return {"error": "Invalid input"}

        errors = [a - p for a, p in zip(actual, predicted)]
        abs_errors = [abs(e) for e in errors]
        pct_errors = [abs(a - p) / a * 100 for a, p in zip(actual, predicted) if a != 0]

        metrics = {
            "mae": statistics.mean(abs_errors),
            "mape": statistics.mean(pct_errors) if pct_errors else 0,
            "rmse": (sum(e**2 for e in errors) / n) ** 0.5,
            "bias": statistics.mean(errors)
        }
        return metrics
''',
            function_name="_calculate_forecast_accuracy",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["forecast", "accuracy", "metrics"])
        ),
    ]
