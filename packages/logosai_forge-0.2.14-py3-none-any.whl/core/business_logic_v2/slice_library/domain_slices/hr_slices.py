"""
HR/Payroll Domain Function Slices
=================================
인사/급여 관리 도메인 특화 슬라이스 (10개)

카테고리:
1. Payroll Management (4개) - 급여 관리
2. Performance Evaluation (3개) - 성과 평가
3. Attendance/Leave (3개) - 근태/휴가 관리
"""

from typing import List
from ..models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceMetadata
)


def create_hr_slices() -> List[FunctionSlice]:
    """HR/Payroll Domain Slices 생성"""
    slices = []
    slices.extend(_create_payroll_slices())
    slices.extend(_create_performance_slices())
    slices.extend(_create_attendance_slices())
    return slices


# =============================================================================
# Payroll Management Slices (4개)
# =============================================================================

def _create_payroll_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="hr.payroll.overtime",
            name="Overtime Pay Calculator",
            description="초과근무 수당을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="hours_worked", param_type="float", description="총 근무 시간", required=True),
                SliceParameter(name="hourly_rate", param_type="float", description="시급", required=True),
                SliceParameter(name="standard_hours", param_type="float", description="기준 근무 시간", default=40, required=False),
                SliceParameter(name="overtime_multiplier", param_type="float", description="초과근무 배율", default=1.5, required=False),
            ],
            outputs=[SliceParameter(name="overtime_pay", param_type="float", description="초과근무 수당")],
            dependencies=[],
            keywords={
                "ko": ["초과근무", "야근", "수당", "시간외근무", "오버타임", "급여"],
                "en": ["overtime", "pay", "hours", "worked", "rate", "extra"]
            },
            code_template='''
        overtime_hours = max(0, hours_worked - standard_hours)
        overtime_pay = overtime_hours * hourly_rate * overtime_multiplier
        return overtime_pay
''',
            function_name="_calculate_overtime_pay",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["hr", "payroll", "overtime"])
        ),
        FunctionSlice(
            id="hr.payroll.net_salary",
            name="Net Salary Calculator",
            description="세금 및 공제 후 실수령액을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="gross_salary", param_type="float", description="총 급여", required=True),
                SliceParameter(name="tax_rate", param_type="float", description="세율 (0-1)", required=True),
                SliceParameter(name="deductions", param_type="float", description="공제액", default=0, required=False),
            ],
            outputs=[SliceParameter(name="net_salary", param_type="float", description="실수령액")],
            dependencies=[],
            keywords={
                "ko": ["실수령액", "순급여", "세금", "공제", "급여"],
                "en": ["net", "salary", "pay", "tax", "deduction", "gross"]
            },
            code_template='''
        tax_amount = gross_salary * tax_rate
        net_salary = gross_salary - tax_amount - deductions
        return max(0, net_salary)
''',
            function_name="_calculate_net_salary",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["hr", "payroll", "salary"])
        ),
        FunctionSlice(
            id="hr.payroll.bonus",
            name="Bonus Calculator",
            description="성과급/보너스를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="base_salary", param_type="float", description="기본급", required=True),
                SliceParameter(name="performance_score", param_type="float", description="성과 점수 (0-100)", required=True),
                SliceParameter(name="bonus_pool_ratio", param_type="float", description="보너스 풀 비율", default=0.1, required=False),
            ],
            outputs=[SliceParameter(name="bonus", param_type="float", description="보너스 금액")],
            dependencies=[],
            keywords={
                "ko": ["보너스", "성과급", "인센티브", "상여금"],
                "en": ["bonus", "incentive", "performance", "pay", "reward"]
            },
            code_template='''
        # 성과 점수에 따른 보너스 계수
        performance_multiplier = performance_score / 100
        bonus = base_salary * bonus_pool_ratio * performance_multiplier
        return bonus
''',
            function_name="_calculate_bonus",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["hr", "payroll", "bonus"])
        ),
        FunctionSlice(
            id="hr.payroll.tax_withholding",
            name="Tax Withholding Calculator",
            description="원천징수세를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="gross_income", param_type="float", description="총 소득", required=True),
                SliceParameter(name="tax_brackets", param_type="List[Dict]", description="세율 구간", required=True),
            ],
            outputs=[SliceParameter(name="tax_amount", param_type="float", description="원천징수세")],
            dependencies=[],
            keywords={
                "ko": ["원천징수", "세금", "소득세", "세액계산"],
                "en": ["tax", "withholding", "income", "bracket", "calculation"]
            },
            code_template='''
        tax_amount = 0
        remaining_income = gross_income

        for bracket in sorted(tax_brackets, key=lambda x: x.get('min', 0)):
            bracket_min = bracket.get('min', 0)
            bracket_max = bracket.get('max', float('inf'))
            rate = bracket.get('rate', 0)

            if remaining_income <= 0:
                break

            taxable_in_bracket = min(remaining_income, bracket_max - bracket_min)
            tax_amount += taxable_in_bracket * rate
            remaining_income -= taxable_in_bracket

        return tax_amount
''',
            function_name="_calculate_tax_withholding",
            metadata=SliceMetadata(complexity=0.5, reliability=0.95, tags=["hr", "payroll", "tax"])
        ),
    ]


# =============================================================================
# Performance Evaluation Slices (3개)
# =============================================================================

def _create_performance_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="hr.performance.score",
            name="Performance Score Calculator",
            description="KPI 기반 성과 점수를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="kpi_scores", param_type="Dict[str, float]", description="KPI별 점수", required=True),
                SliceParameter(name="kpi_weights", param_type="Dict[str, float]", description="KPI별 가중치", required=True),
            ],
            outputs=[SliceParameter(name="performance_score", param_type="float", description="종합 성과 점수")],
            dependencies=[],
            keywords={
                "ko": ["성과", "KPI", "평가", "점수", "실적"],
                "en": ["performance", "score", "kpi", "evaluation", "rating"]
            },
            code_template='''
        total_score = 0
        total_weight = 0

        for kpi, score in kpi_scores.items():
            weight = kpi_weights.get(kpi, 1)
            total_score += score * weight
            total_weight += weight

        performance_score = total_score / total_weight if total_weight > 0 else 0
        return performance_score
''',
            function_name="_calculate_performance_score",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["hr", "performance", "kpi"])
        ),
        FunctionSlice(
            id="hr.performance.rating",
            name="Performance Rating Classifier",
            description="성과 점수를 등급으로 분류합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="performance_score", param_type="float", description="성과 점수 (0-100)", required=True),
                SliceParameter(name="thresholds", param_type="Dict[str, float]", description="등급 기준", default={"A": 90, "B": 80, "C": 70, "D": 60}, required=False),
            ],
            outputs=[SliceParameter(name="rating", param_type="str", description="성과 등급")],
            dependencies=[],
            keywords={
                "ko": ["등급", "평가등급", "성과등급", "분류"],
                "en": ["rating", "grade", "classification", "performance"]
            },
            code_template='''
        sorted_thresholds = sorted(thresholds.items(), key=lambda x: x[1], reverse=True)

        for grade, threshold in sorted_thresholds:
            if performance_score >= threshold:
                return grade

        return "F"  # 최저 등급
''',
            function_name="_classify_performance_rating",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["hr", "performance", "rating"])
        ),
        FunctionSlice(
            id="hr.performance.recommendation",
            name="HR Action Recommendation",
            description="성과에 따른 인사 조치를 추천합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="performance_score", param_type="float", description="성과 점수 (0-100)", required=True),
                SliceParameter(name="tenure_years", param_type="float", description="근속 연수", required=True),
                SliceParameter(name="peer_rank_percentile", param_type="float", description="동료 대비 순위 백분위", default=50, required=False),
            ],
            outputs=[SliceParameter(name="recommendations", param_type="List[str]", description="인사 조치 추천")],
            dependencies=[],
            keywords={
                "ko": ["인사조치", "추천", "승진", "교육", "보상"],
                "en": ["hr", "action", "recommendation", "promotion", "training"]
            },
            code_template='''
        recommendations = []

        if performance_score >= 90:
            recommendations.append("승진 검토")
            recommendations.append("인센티브 지급")
        elif performance_score >= 80:
            recommendations.append("성과급 지급")
            if tenure_years >= 3:
                recommendations.append("핵심인재 지정")
        elif performance_score >= 70:
            recommendations.append("역량 개발 교육")
        else:
            recommendations.append("성과 개선 계획(PIP) 수립")
            if performance_score < 50:
                recommendations.append("경고 조치")

        if peer_rank_percentile >= 90:
            recommendations.append("리더십 후보")

        return recommendations
''',
            function_name="_recommend_hr_action",
            metadata=SliceMetadata(complexity=0.4, reliability=0.90, tags=["hr", "performance", "recommendation"])
        ),
    ]


# =============================================================================
# Attendance/Leave Slices (3개)
# =============================================================================

def _create_attendance_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="hr.attendance.rate",
            name="Attendance Rate Calculator",
            description="출근율을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="days_worked", param_type="int", description="실제 출근일", required=True),
                SliceParameter(name="working_days", param_type="int", description="총 근무일", required=True),
            ],
            outputs=[SliceParameter(name="attendance_rate", param_type="float", description="출근율")],
            dependencies=[],
            keywords={
                "ko": ["출근율", "근태", "출석률", "결근"],
                "en": ["attendance", "rate", "presence", "absence"]
            },
            code_template='''
        attendance_rate = days_worked / working_days if working_days > 0 else 0
        return attendance_rate
''',
            function_name="_calculate_attendance_rate",
            metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["hr", "attendance", "rate"])
        ),
        FunctionSlice(
            id="hr.leave.balance",
            name="Leave Balance Calculator",
            description="잔여 휴가일수를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="annual_leave", param_type="int", description="연차 부여일", required=True),
                SliceParameter(name="used_leave", param_type="int", description="사용 휴가일", required=True),
                SliceParameter(name="carried_over", param_type="int", description="이월 휴가일", default=0, required=False),
            ],
            outputs=[SliceParameter(name="balance", param_type="int", description="잔여 휴가일")],
            dependencies=[],
            keywords={
                "ko": ["휴가", "연차", "잔여휴가", "휴가잔액"],
                "en": ["leave", "balance", "vacation", "annual", "pto"]
            },
            code_template='''
        balance = annual_leave + carried_over - used_leave
        return max(0, balance)
''',
            function_name="_calculate_leave_balance",
            metadata=SliceMetadata(complexity=0.1, reliability=0.99, tags=["hr", "leave", "balance"])
        ),
        FunctionSlice(
            id="hr.leave.accrual",
            name="Leave Accrual Calculator",
            description="근속 기간에 따른 연차를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.HR,
            inputs=[
                SliceParameter(name="tenure_years", param_type="float", description="근속 연수", required=True),
                SliceParameter(name="base_leave", param_type="int", description="기본 연차", default=15, required=False),
                SliceParameter(name="increment_per_year", param_type="int", description="연간 추가 연차", default=1, required=False),
                SliceParameter(name="max_leave", param_type="int", description="최대 연차", default=25, required=False),
            ],
            outputs=[SliceParameter(name="annual_leave", param_type="int", description="부여 연차")],
            dependencies=[],
            keywords={
                "ko": ["연차발생", "휴가발생", "근속연차", "연차계산"],
                "en": ["leave", "accrual", "tenure", "vacation", "calculation"]
            },
            code_template='''
        import math

        # 근속 년수에 따른 추가 연차
        additional_leave = math.floor(tenure_years) * increment_per_year
        annual_leave = min(base_leave + additional_leave, max_leave)
        return annual_leave
''',
            function_name="_calculate_leave_accrual",
            metadata=SliceMetadata(complexity=0.2, reliability=0.98, tags=["hr", "leave", "accrual"])
        ),
    ]
