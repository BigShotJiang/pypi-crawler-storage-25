"""
Project Management Domain Function Slices
==========================================
프로젝트 관리 도메인 특화 슬라이스 (10개)

카테고리:
1. Task Management (4개) - 태스크 관리
2. Resource Planning (3개) - 리소스 계획
3. Progress Tracking (3개) - 진행 추적
"""

from typing import List
from ..models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceMetadata
)


def create_project_slices() -> List[FunctionSlice]:
    """Project Management Domain Slices 생성"""
    slices = []
    slices.extend(_create_task_management_slices())
    slices.extend(_create_resource_planning_slices())
    slices.extend(_create_progress_tracking_slices())
    return slices


# =============================================================================
# Task Management Slices (4개)
# =============================================================================

def _create_task_management_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="project.task.priority",
            name="Task Priority Calculator",
            description="태스크 우선순위를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="urgency", param_type="int", description="긴급도 (1-5)", required=True),
                SliceParameter(name="importance", param_type="int", description="중요도 (1-5)", required=True),
                SliceParameter(name="deadline_days", param_type="int", description="마감까지 남은 일수", required=True),
                SliceParameter(name="dependencies_count", param_type="int", description="의존 태스크 수", default=0, required=False),
            ],
            outputs=[SliceParameter(name="priority_score", param_type="float", description="우선순위 점수")],
            dependencies=[],
            keywords={
                "ko": ["태스크우선순위", "작업우선순위", "업무우선순위", "중요도", "긴급도"],
                "en": ["task", "priority", "score", "urgency", "importance", "deadline"]
            },
            code_template='''
        # 아이젠하워 매트릭스 기반 + 마감일 가중치
        base_score = (urgency * 2 + importance * 2) / 4  # 1-5 스케일

        # 마감일 가중치 (가까울수록 높은 점수)
        if deadline_days <= 1:
            deadline_weight = 2.0
        elif deadline_days <= 3:
            deadline_weight = 1.5
        elif deadline_days <= 7:
            deadline_weight = 1.2
        else:
            deadline_weight = 1.0

        # 의존성 가중치 (많을수록 먼저 처리)
        dependency_weight = 1 + (dependencies_count * 0.1)

        priority_score = base_score * deadline_weight * dependency_weight
        return min(priority_score, 10)  # 최대 10점
''',
            function_name="_calculate_task_priority",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["project", "task", "priority"])
        ),
        FunctionSlice(
            id="project.task.estimate",
            name="Task Duration Estimator",
            description="태스크 소요 시간을 추정합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="optimistic", param_type="float", description="낙관적 추정(시간)", required=True),
                SliceParameter(name="most_likely", param_type="float", description="가장 가능한 추정(시간)", required=True),
                SliceParameter(name="pessimistic", param_type="float", description="비관적 추정(시간)", required=True),
            ],
            outputs=[SliceParameter(name="estimate", param_type="Dict[str, float]", description="추정 결과")],
            dependencies=[],
            keywords={
                "ko": ["소요시간", "추정", "예상시간", "태스크시간", "PERT"],
                "en": ["task", "estimate", "duration", "time", "pert"]
            },
            code_template='''
        import math

        # PERT 공식: (낙관 + 4×가능 + 비관) / 6
        expected = (optimistic + 4 * most_likely + pessimistic) / 6

        # 표준편차: (비관 - 낙관) / 6
        std_dev = (pessimistic - optimistic) / 6

        estimate = {
            "expected_hours": round(expected, 2),
            "std_deviation": round(std_dev, 2),
            "confidence_range": {
                "low": round(expected - std_dev, 2),
                "high": round(expected + std_dev, 2)
            }
        }
        return estimate
''',
            function_name="_estimate_task_duration",
            metadata=SliceMetadata(complexity=0.3, reliability=0.90, tags=["project", "task", "estimate"])
        ),
        FunctionSlice(
            id="project.task.assign",
            name="Task Assignment Optimizer",
            description="최적의 담당자에게 태스크를 할당합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="task_skills", param_type="List[str]", description="필요 스킬", required=True),
                SliceParameter(name="team_members", param_type="List[Dict]", description="팀원 정보", required=True),
                SliceParameter(name="task_hours", param_type="float", description="예상 소요시간", required=True),
            ],
            outputs=[SliceParameter(name="assignment", param_type="Dict[str, Any]", description="할당 결과")],
            dependencies=[],
            keywords={
                "ko": ["태스크할당", "업무배정", "담당자", "리소스할당"],
                "en": ["task", "assign", "assignment", "allocate", "resource"]
            },
            code_template='''
        best_member = None
        best_score = -1

        for member in team_members:
            member_skills = set(member.get("skills", []))
            required_skills = set(task_skills)

            # 스킬 매칭 점수
            skill_match = len(member_skills & required_skills) / len(required_skills) if required_skills else 0

            # 가용성 점수 (현재 작업량 대비)
            current_workload = member.get("current_hours", 0)
            max_capacity = member.get("max_hours", 40)
            availability = max(0, (max_capacity - current_workload - task_hours) / max_capacity)

            # 종합 점수
            score = skill_match * 0.6 + availability * 0.4

            if score > best_score:
                best_score = score
                best_member = member

        assignment = {
            "assigned_to": best_member.get("name") if best_member else None,
            "match_score": round(best_score, 2),
            "skill_coverage": skill_match if best_member else 0
        }
        return assignment
''',
            function_name="_assign_task",
            metadata=SliceMetadata(complexity=0.5, reliability=0.88, tags=["project", "task", "assignment"])
        ),
        FunctionSlice(
            id="project.task.dependency",
            name="Task Dependency Analyzer",
            description="태스크 의존성을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="tasks", param_type="List[Dict]", description="태스크 목록 (id, dependencies)", required=True),
            ],
            outputs=[SliceParameter(name="analysis", param_type="Dict[str, Any]", description="의존성 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["의존성", "종속성", "태스크순서", "선행작업"],
                "en": ["dependency", "task", "order", "predecessor", "sequence"]
            },
            code_template='''
        from collections import deque

        # 진입 차수 계산
        in_degree = {t["id"]: 0 for t in tasks}
        graph = {t["id"]: [] for t in tasks}

        for task in tasks:
            for dep in task.get("dependencies", []):
                if dep in graph:
                    graph[dep].append(task["id"])
                    in_degree[task["id"]] += 1

        # 토폴로지 정렬
        queue = deque([tid for tid, deg in in_degree.items() if deg == 0])
        execution_order = []
        while queue:
            current = queue.popleft()
            execution_order.append(current)
            for neighbor in graph[current]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # 사이클 감지
        has_cycle = len(execution_order) != len(tasks)

        analysis = {
            "execution_order": execution_order,
            "has_cycle": has_cycle,
            "critical_path_start": execution_order[0] if execution_order else None
        }
        return analysis
''',
            function_name="_analyze_dependencies",
            metadata=SliceMetadata(complexity=0.5, reliability=0.95, tags=["project", "task", "dependency"])
        ),
    ]


# =============================================================================
# Resource Planning Slices (3개)
# =============================================================================

def _create_resource_planning_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="project.resource.capacity",
            name="Team Capacity Calculator",
            description="팀 가용 용량을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="team_members", param_type="List[Dict]", description="팀원 정보", required=True),
                SliceParameter(name="sprint_days", param_type="int", description="스프린트 기간(일)", required=True),
                SliceParameter(name="hours_per_day", param_type="float", description="일일 업무시간", default=8, required=False),
            ],
            outputs=[SliceParameter(name="capacity", param_type="Dict[str, float]", description="용량 정보")],
            dependencies=[],
            keywords={
                "ko": ["용량", "가용량", "팀용량", "리소스용량", "스프린트"],
                "en": ["capacity", "team", "sprint", "resource", "planning"]
            },
            code_template='''
        total_capacity = 0
        member_capacities = []

        for member in team_members:
            availability = member.get("availability", 1.0)  # 0-1
            vacation_days = member.get("vacation_days", 0)
            working_days = sprint_days - vacation_days

            member_capacity = working_days * hours_per_day * availability
            member_capacities.append({
                "name": member.get("name"),
                "capacity_hours": member_capacity
            })
            total_capacity += member_capacity

        capacity = {
            "total_hours": total_capacity,
            "member_breakdown": member_capacities,
            "sprint_days": sprint_days
        }
        return capacity
''',
            function_name="_calculate_team_capacity",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["project", "resource", "capacity"])
        ),
        FunctionSlice(
            id="project.resource.workload",
            name="Workload Balancer",
            description="팀원별 업무량을 균형있게 분배합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="team_workloads", param_type="Dict[str, float]", description="팀원별 현재 업무량(시간)", required=True),
                SliceParameter(name="target_capacity", param_type="float", description="목표 용량(시간)", required=True),
            ],
            outputs=[SliceParameter(name="balance_info", param_type="Dict[str, Any]", description="균형 분석")],
            dependencies=[],
            keywords={
                "ko": ["업무량", "워크로드", "균형", "분배", "밸런싱"],
                "en": ["workload", "balance", "distribution", "team", "allocation"]
            },
            code_template='''
        workloads = list(team_workloads.values())
        avg_workload = sum(workloads) / len(workloads) if workloads else 0

        overloaded = []
        underloaded = []

        for member, hours in team_workloads.items():
            utilization = hours / target_capacity if target_capacity > 0 else 0
            if utilization > 1.0:
                overloaded.append({"member": member, "hours": hours, "excess": hours - target_capacity})
            elif utilization < 0.7:
                underloaded.append({"member": member, "hours": hours, "available": target_capacity - hours})

        balance_info = {
            "average_workload": round(avg_workload, 2),
            "overloaded_members": overloaded,
            "underloaded_members": underloaded,
            "is_balanced": len(overloaded) == 0
        }
        return balance_info
''',
            function_name="_analyze_workload_balance",
            metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["project", "resource", "workload"])
        ),
        FunctionSlice(
            id="project.resource.budget",
            name="Project Budget Calculator",
            description="프로젝트 예산을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="labor_hours", param_type="float", description="총 인건비 시간", required=True),
                SliceParameter(name="hourly_rate", param_type="float", description="시간당 비용", required=True),
                SliceParameter(name="overhead_rate", param_type="float", description="간접비율", default=0.2, required=False),
                SliceParameter(name="contingency_rate", param_type="float", description="예비비율", default=0.1, required=False),
            ],
            outputs=[SliceParameter(name="budget", param_type="Dict[str, float]", description="예산 내역")],
            dependencies=[],
            keywords={
                "ko": ["예산", "비용", "프로젝트예산", "인건비"],
                "en": ["budget", "cost", "project", "estimate", "labor"]
            },
            code_template='''
        labor_cost = labor_hours * hourly_rate
        overhead_cost = labor_cost * overhead_rate
        subtotal = labor_cost + overhead_cost
        contingency = subtotal * contingency_rate
        total = subtotal + contingency

        budget = {
            "labor_cost": round(labor_cost, 2),
            "overhead_cost": round(overhead_cost, 2),
            "subtotal": round(subtotal, 2),
            "contingency": round(contingency, 2),
            "total": round(total, 2)
        }
        return budget
''',
            function_name="_calculate_project_budget",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["project", "budget", "cost"])
        ),
    ]


# =============================================================================
# Progress Tracking Slices (3개)
# =============================================================================

def _create_progress_tracking_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="project.progress.completion",
            name="Project Completion Calculator",
            description="프로젝트 완료율을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="tasks", param_type="List[Dict]", description="태스크 목록 (status, weight)", required=True),
            ],
            outputs=[SliceParameter(name="completion", param_type="Dict[str, float]", description="완료 정보")],
            dependencies=[],
            keywords={
                "ko": ["완료율", "진행률", "진척률", "프로젝트진행"],
                "en": ["completion", "progress", "percentage", "project", "status"]
            },
            code_template='''
        total_weight = 0
        completed_weight = 0
        status_counts = {}

        for task in tasks:
            weight = task.get("weight", 1)
            status = task.get("status", "pending")
            total_weight += weight

            status_counts[status] = status_counts.get(status, 0) + 1

            if status == "completed":
                completed_weight += weight
            elif status == "in_progress":
                completed_weight += weight * 0.5  # 진행중은 50%

        completion_rate = completed_weight / total_weight if total_weight > 0 else 0

        completion = {
            "completion_rate": round(completion_rate * 100, 2),
            "total_tasks": len(tasks),
            "status_breakdown": status_counts
        }
        return completion
''',
            function_name="_calculate_completion",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["project", "progress", "completion"])
        ),
        FunctionSlice(
            id="project.progress.velocity",
            name="Sprint Velocity Calculator",
            description="스프린트 속도를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="completed_points", param_type="List[float]", description="완료 스토리 포인트 (스프린트별)", required=True),
            ],
            outputs=[SliceParameter(name="velocity", param_type="Dict[str, float]", description="속도 분석")],
            dependencies=[],
            keywords={
                "ko": ["속도", "벨로시티", "스프린트속도", "생산성"],
                "en": ["velocity", "sprint", "agile", "productivity", "points"]
            },
            code_template='''
        import statistics

        if not completed_points:
            return {"average": 0, "trend": "insufficient_data"}

        avg_velocity = statistics.mean(completed_points)
        std_dev = statistics.stdev(completed_points) if len(completed_points) > 1 else 0

        # 트렌드 분석 (최근 3개 vs 이전)
        if len(completed_points) >= 4:
            recent = statistics.mean(completed_points[-3:])
            earlier = statistics.mean(completed_points[:-3])
            trend = "improving" if recent > earlier else "declining" if recent < earlier else "stable"
        else:
            trend = "stable"

        velocity = {
            "average": round(avg_velocity, 2),
            "std_deviation": round(std_dev, 2),
            "trend": trend,
            "last_sprint": completed_points[-1] if completed_points else 0,
            "predicted_next": round(avg_velocity, 2)
        }
        return velocity
''',
            function_name="_calculate_velocity",
            metadata=SliceMetadata(complexity=0.4, reliability=0.90, tags=["project", "velocity", "agile"])
        ),
        FunctionSlice(
            id="project.progress.burndown",
            name="Burndown Chart Data Generator",
            description="번다운 차트 데이터를 생성합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.PROJECT,
            inputs=[
                SliceParameter(name="total_points", param_type="float", description="총 스토리 포인트", required=True),
                SliceParameter(name="sprint_days", param_type="int", description="스프린트 일수", required=True),
                SliceParameter(name="daily_completed", param_type="List[float]", description="일별 완료 포인트", required=True),
            ],
            outputs=[SliceParameter(name="burndown", param_type="Dict[str, Any]", description="번다운 차트 데이터")],
            dependencies=[],
            keywords={
                "ko": ["번다운", "차트", "스프린트진행", "잔여작업"],
                "en": ["burndown", "chart", "sprint", "remaining", "progress"]
            },
            code_template='''
        # 이상적인 번다운 라인
        ideal_rate = total_points / sprint_days
        ideal_line = [total_points - (i * ideal_rate) for i in range(sprint_days + 1)]

        # 실제 번다운 라인
        actual_line = [total_points]
        remaining = total_points
        for completed in daily_completed:
            remaining -= completed
            actual_line.append(remaining)

        # 예상 완료일 계산
        if len(daily_completed) > 0:
            avg_velocity = sum(daily_completed) / len(daily_completed)
            days_remaining = remaining / avg_velocity if avg_velocity > 0 else float('inf')
        else:
            days_remaining = sprint_days

        burndown = {
            "ideal_line": [round(v, 2) for v in ideal_line],
            "actual_line": [round(v, 2) for v in actual_line],
            "remaining_points": round(remaining, 2),
            "days_elapsed": len(daily_completed),
            "estimated_days_to_complete": round(days_remaining, 1),
            "on_track": remaining <= ideal_line[len(daily_completed)] if len(daily_completed) < len(ideal_line) else remaining <= 0
        }
        return burndown
''',
            function_name="_generate_burndown_data",
            metadata=SliceMetadata(complexity=0.4, reliability=0.93, tags=["project", "burndown", "chart"])
        ),
    ]
