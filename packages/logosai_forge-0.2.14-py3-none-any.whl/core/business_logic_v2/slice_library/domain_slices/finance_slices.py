"""
Finance Domain Function Slices
==============================
재무/금융 도메인 특화 슬라이스 (30개)

카테고리:
1. Financial Analysis (10개) - 재무 분석
2. Risk Analysis (10개) - 리스크 분석
3. Forecasting (10개) - 예측
"""

from typing import List
from ..models import (
    FunctionSlice,
    SliceCategory,
    SliceDomain,
    SliceParameter,
    SliceMetadata
)


def create_finance_slices() -> List[FunctionSlice]:
    """Finance Domain Slices 생성"""
    slices = []
    slices.extend(_create_financial_analysis_slices())
    slices.extend(_create_risk_analysis_slices())
    slices.extend(_create_forecasting_slices())
    return slices


# =============================================================================
# Financial Analysis Slices (10개)
# =============================================================================

def _create_financial_analysis_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="finance.analysis.ratio",
            name="Financial Ratio Analysis",
            description="주요 재무 비율을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="financial_data", param_type="pd.DataFrame", description="재무 데이터", required=True),
                SliceParameter(name="ratios", param_type="List[str]", description="계산할 비율 목록", default=["all"], required=False),
            ],
            outputs=[SliceParameter(name="ratios", param_type="pd.DataFrame", description="재무 비율 데이터")],
            dependencies=[],
            keywords={
                "ko": ["재무비율", "유동비율", "부채비율", "ROE", "ROA"],
                "en": ["ratio", "financial", "liquidity", "debt", "roe", "roa"]
            },
            code_template='''
        import pandas as pd

        result = financial_data.copy()

        # 수익성 비율
        if "all" in ratios or "roe" in ratios:
            result['roe'] = (result['net_income'] / result['equity'] * 100).round(2)
        if "all" in ratios or "roa" in ratios:
            result['roa'] = (result['net_income'] / result['total_assets'] * 100).round(2)
        if "all" in ratios or "profit_margin" in ratios:
            result['profit_margin'] = (result['net_income'] / result['revenue'] * 100).round(2)

        # 유동성 비율
        if "all" in ratios or "current_ratio" in ratios:
            result['current_ratio'] = (result['current_assets'] / result['current_liabilities']).round(2)
        if "all" in ratios or "quick_ratio" in ratios:
            result['quick_ratio'] = ((result['current_assets'] - result['inventory']) / result['current_liabilities']).round(2)

        # 부채 비율
        if "all" in ratios or "debt_ratio" in ratios:
            result['debt_ratio'] = (result['total_debt'] / result['total_assets'] * 100).round(2)
        if "all" in ratios or "debt_to_equity" in ratios:
            result['debt_to_equity'] = (result['total_debt'] / result['equity']).round(2)

        return result
''',
            function_name="_calculate_ratios",
            metadata=SliceMetadata(complexity=0.4, reliability=0.98, tags=["finance", "ratio", "analysis"])
        ),
        FunctionSlice(
            id="finance.analysis.cashflow",
            name="Cashflow Analysis",
            description="현금흐름을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="cashflow_data", param_type="pd.DataFrame", description="현금흐름 데이터", required=True),
                SliceParameter(name="period_col", param_type="str", description="기간 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="analysis", param_type="pd.DataFrame", description="현금흐름 분석")],
            dependencies=[],
            keywords={
                "ko": ["현금흐름", "캐시플로우", "영업활동", "투자활동", "재무활동"],
                "en": ["cashflow", "operating", "investing", "financing", "cash"]
            },
            code_template='''
        import pandas as pd

        result = cashflow_data.copy()

        # 현금흐름 합계
        result['total_cashflow'] = result['operating_cf'] + result['investing_cf'] + result['financing_cf']

        # FCF (자유현금흐름)
        result['free_cashflow'] = result['operating_cf'] - result['capex']

        # 현금흐름 비율
        result['cf_to_revenue'] = (result['operating_cf'] / result['revenue'] * 100).round(2)

        return result
''',
            function_name="_analyze_cashflow",
            metadata=SliceMetadata(complexity=0.4, reliability=0.97, tags=["finance", "cashflow", "analysis"])
        ),
        FunctionSlice(
            id="finance.analysis.profitability",
            name="Profitability Analysis",
            description="수익성을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="income_data", param_type="pd.DataFrame", description="손익 데이터", required=True),
            ],
            outputs=[SliceParameter(name="profitability", param_type="pd.DataFrame", description="수익성 분석")],
            dependencies=[],
            keywords={
                "ko": ["수익성", "이익률", "마진", "영업이익"],
                "en": ["profitability", "margin", "profit", "operating"]
            },
            code_template='''
        import pandas as pd

        result = income_data.copy()

        result['gross_margin'] = ((result['revenue'] - result['cogs']) / result['revenue'] * 100).round(2)
        result['operating_margin'] = (result['operating_income'] / result['revenue'] * 100).round(2)
        result['net_margin'] = (result['net_income'] / result['revenue'] * 100).round(2)
        result['ebitda_margin'] = (result['ebitda'] / result['revenue'] * 100).round(2)

        return result
''',
            function_name="_analyze_profitability",
            metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["finance", "profitability", "analysis"])
        ),
        FunctionSlice(
            id="finance.analysis.budget",
            name="Budget Analysis",
            description="예산 대비 실적을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="actual_data", param_type="pd.DataFrame", description="실적 데이터", required=True),
                SliceParameter(name="budget_data", param_type="pd.DataFrame", description="예산 데이터", required=True),
                SliceParameter(name="categories", param_type="List[str]", description="분석 항목", required=True),
            ],
            outputs=[SliceParameter(name="variance", param_type="pd.DataFrame", description="예산 차이 분석")],
            dependencies=[],
            keywords={
                "ko": ["예산", "실적", "차이분석", "편차"],
                "en": ["budget", "actual", "variance", "analysis"]
            },
            code_template='''
        import pandas as pd

        result = pd.DataFrame()
        result['category'] = categories

        for cat in categories:
            result.loc[result['category'] == cat, 'budget'] = budget_data[cat].sum()
            result.loc[result['category'] == cat, 'actual'] = actual_data[cat].sum()

        result['variance'] = result['actual'] - result['budget']
        result['variance_pct'] = (result['variance'] / result['budget'] * 100).round(2)
        result['status'] = result['variance'].apply(lambda x: 'Under' if x < 0 else 'Over')

        return result
''',
            function_name="_analyze_budget",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["finance", "budget", "variance"])
        ),
        FunctionSlice(
            id="finance.analysis.trend",
            name="Financial Trend Analysis",
            description="재무 추세를 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="time_series_data", param_type="pd.DataFrame", description="시계열 재무 데이터", required=True),
                SliceParameter(name="metrics", param_type="List[str]", description="분석 지표", required=True),
                SliceParameter(name="period_col", param_type="str", description="기간 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="trends", param_type="pd.DataFrame", description="추세 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["추세", "트렌드", "성장", "변화"],
                "en": ["trend", "growth", "change", "analysis"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        result = time_series_data.sort_values(period_col).copy()

        for metric in metrics:
            # 전기 대비 변화율
            result[f'{metric}_pct_change'] = result[metric].pct_change() * 100

            # 이동평균
            result[f'{metric}_ma3'] = result[metric].rolling(3).mean()

            # 선형 추세
            x = np.arange(len(result))
            slope, _ = np.polyfit(x, result[metric].fillna(0), 1)
            result[f'{metric}_trend'] = 'Up' if slope > 0 else 'Down'

        return result
''',
            function_name="_analyze_trend",
            metadata=SliceMetadata(complexity=0.5, reliability=0.93, tags=["finance", "trend", "analysis"])
        ),
        FunctionSlice(
            id="finance.analysis.revenue",
            name="Revenue Analysis",
            description="매출을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="revenue_data", param_type="pd.DataFrame", description="매출 데이터", required=True),
                SliceParameter(name="segment_col", param_type="str", description="세그먼트 컬럼", default=None, required=False),
            ],
            outputs=[SliceParameter(name="analysis", param_type="pd.DataFrame", description="매출 분석")],
            dependencies=[],
            keywords={
                "ko": ["매출", "수익", "판매", "분석"],
                "en": ["revenue", "sales", "income", "analysis"]
            },
            code_template='''
        import pandas as pd

        if segment_col:
            result = revenue_data.groupby(segment_col).agg({
                'revenue': ['sum', 'mean', 'count']
            }).reset_index()
            result.columns = [segment_col, 'total_revenue', 'avg_revenue', 'transaction_count']
            result['revenue_share'] = (result['total_revenue'] / result['total_revenue'].sum() * 100).round(2)
        else:
            result = pd.DataFrame({
                'total_revenue': [revenue_data['revenue'].sum()],
                'avg_revenue': [revenue_data['revenue'].mean()],
                'transaction_count': [len(revenue_data)],
                'max_revenue': [revenue_data['revenue'].max()],
                'min_revenue': [revenue_data['revenue'].min()]
            })

        return result
''',
            function_name="_analyze_revenue",
            metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["finance", "revenue", "analysis"])
        ),
        FunctionSlice(
            id="finance.analysis.cost",
            name="Cost Analysis",
            description="비용을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="cost_data", param_type="pd.DataFrame", description="비용 데이터", required=True),
                SliceParameter(name="category_col", param_type="str", description="비용 카테고리 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="analysis", param_type="pd.DataFrame", description="비용 분석")],
            dependencies=[],
            keywords={
                "ko": ["비용", "원가", "경비", "분석"],
                "en": ["cost", "expense", "analysis", "spending"]
            },
            code_template='''
        import pandas as pd

        result = cost_data.groupby(category_col).agg({
            'amount': ['sum', 'mean', 'count']
        }).reset_index()

        result.columns = [category_col, 'total_cost', 'avg_cost', 'item_count']
        result['cost_share'] = (result['total_cost'] / result['total_cost'].sum() * 100).round(2)
        result = result.sort_values('total_cost', ascending=False)

        return result
''',
            function_name="_analyze_cost",
            metadata=SliceMetadata(complexity=0.3, reliability=0.98, tags=["finance", "cost", "analysis"])
        ),
        FunctionSlice(
            id="finance.analysis.breakeven",
            name="Break-even Analysis",
            description="손익분기점을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="fixed_costs", param_type="float", description="고정비용", required=True),
                SliceParameter(name="variable_cost_per_unit", param_type="float", description="단위당 변동비", required=True),
                SliceParameter(name="price_per_unit", param_type="float", description="단위당 판매가", required=True),
            ],
            outputs=[SliceParameter(name="breakeven", param_type="Dict", description="손익분기점 분석")],
            dependencies=[],
            keywords={
                "ko": ["손익분기점", "BEP", "손익분석", "고정비"],
                "en": ["breakeven", "bep", "analysis", "fixed", "variable"]
            },
            code_template='''
        contribution_margin = price_per_unit - variable_cost_per_unit
        breakeven_units = fixed_costs / contribution_margin if contribution_margin > 0 else float('inf')
        breakeven_revenue = breakeven_units * price_per_unit

        return {
            "fixed_costs": fixed_costs,
            "variable_cost_per_unit": variable_cost_per_unit,
            "price_per_unit": price_per_unit,
            "contribution_margin": round(contribution_margin, 2),
            "breakeven_units": round(breakeven_units, 2),
            "breakeven_revenue": round(breakeven_revenue, 2)
        }
''',
            function_name="_analyze_breakeven",
            metadata=SliceMetadata(complexity=0.2, reliability=0.99, tags=["finance", "breakeven", "analysis"])
        ),
        FunctionSlice(
            id="finance.analysis.working_capital",
            name="Working Capital Analysis",
            description="운전자본을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="balance_sheet", param_type="pd.DataFrame", description="재무상태표 데이터", required=True),
            ],
            outputs=[SliceParameter(name="analysis", param_type="pd.DataFrame", description="운전자본 분석")],
            dependencies=[],
            keywords={
                "ko": ["운전자본", "유동자산", "유동부채", "NWC"],
                "en": ["working", "capital", "current", "nwc"]
            },
            code_template='''
        import pandas as pd

        result = balance_sheet.copy()

        result['working_capital'] = result['current_assets'] - result['current_liabilities']
        result['wc_ratio'] = (result['current_assets'] / result['current_liabilities']).round(2)

        # 운전자본 회전율 (매출 데이터 있을 경우)
        if 'revenue' in result.columns:
            result['wc_turnover'] = (result['revenue'] / result['working_capital']).round(2)

        return result
''',
            function_name="_analyze_working_capital",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["finance", "working", "capital"])
        ),
        FunctionSlice(
            id="finance.analysis.valuation",
            name="Valuation Analysis",
            description="기업 가치를 평가합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="financial_data", param_type="pd.DataFrame", description="재무 데이터", required=True),
                SliceParameter(name="market_data", param_type="pd.DataFrame", description="시장 데이터", default=None, required=False),
            ],
            outputs=[SliceParameter(name="valuation", param_type="pd.DataFrame", description="가치평가 결과")],
            dependencies=["finance.analysis.ratio"],
            keywords={
                "ko": ["가치평가", "밸류에이션", "PER", "PBR", "EV"],
                "en": ["valuation", "per", "pbr", "ev", "ebitda"]
            },
            code_template='''
        import pandas as pd

        result = financial_data.copy()

        if market_data is not None:
            result = result.merge(market_data, how='left')

            # PER, PBR
            result['per'] = (result['market_cap'] / result['net_income']).round(2)
            result['pbr'] = (result['market_cap'] / result['equity']).round(2)

            # EV/EBITDA
            result['ev'] = result['market_cap'] + result['total_debt'] - result['cash']
            result['ev_ebitda'] = (result['ev'] / result['ebitda']).round(2)

        return result
''',
            function_name="_analyze_valuation",
            metadata=SliceMetadata(complexity=0.5, reliability=0.90, tags=["finance", "valuation", "analysis"])
        ),
    ]


# =============================================================================
# Risk Analysis Slices (10개)
# =============================================================================

def _create_risk_analysis_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="finance.risk.credit_score",
            name="Credit Risk Scoring",
            description="신용 위험 점수를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="borrower_data", param_type="pd.DataFrame", description="차주 데이터", required=True),
                SliceParameter(name="scoring_model", param_type="str", description="스코어링 모델", default="simple", required=False),
            ],
            outputs=[SliceParameter(name="credit_scores", param_type="pd.DataFrame", description="신용 점수 데이터")],
            dependencies=[],
            keywords={
                "ko": ["신용", "위험", "점수", "스코어", "등급"],
                "en": ["credit", "risk", "score", "rating", "scoring"]
            },
            code_template='''
        import pandas as pd

        result = borrower_data.copy()

        if scoring_model == "simple":
            # 간단한 가중 스코어링
            result['credit_score'] = 0

            # 소득 점수 (0-30)
            result['credit_score'] += (result['annual_income'] / result['annual_income'].max() * 30).clip(0, 30)

            # 부채비율 점수 (0-30, 낮을수록 높은 점수)
            result['credit_score'] += ((1 - result['debt_ratio']) * 30).clip(0, 30)

            # 연체 이력 점수 (0-40)
            result['credit_score'] += ((1 - result['delinquency_rate']) * 40).clip(0, 40)

        result['credit_score'] = result['credit_score'].round(0).astype(int)
        result['credit_grade'] = pd.cut(result['credit_score'],
                                        bins=[0, 40, 55, 70, 85, 100],
                                        labels=['F', 'D', 'C', 'B', 'A'])

        return result
''',
            function_name="_calculate_credit_score",
            metadata=SliceMetadata(complexity=0.5, reliability=0.92, tags=["finance", "risk", "credit"])
        ),
        FunctionSlice(
            id="finance.risk.var",
            name="Value at Risk",
            description="VaR(Value at Risk)를 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="returns", param_type="List[float]", description="수익률 데이터", required=True),
                SliceParameter(name="confidence_level", param_type="float", description="신뢰수준", default=0.95, required=False),
                SliceParameter(name="method", param_type="str", description="계산 방법", default="historical", required=False),
            ],
            outputs=[SliceParameter(name="var", param_type="Dict", description="VaR 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["VaR", "리스크", "위험", "손실", "가치"],
                "en": ["var", "risk", "value", "loss", "volatility"]
            },
            code_template='''
        import numpy as np
        from scipy import stats

        returns = np.array(returns)

        if method == "historical":
            var = np.percentile(returns, (1 - confidence_level) * 100)
        elif method == "parametric":
            mean = np.mean(returns)
            std = np.std(returns)
            z_score = stats.norm.ppf(1 - confidence_level)
            var = mean + z_score * std
        else:
            var = np.percentile(returns, (1 - confidence_level) * 100)

        # CVaR (Conditional VaR)
        cvar = returns[returns <= var].mean()

        return {
            "var": round(var, 4),
            "cvar": round(cvar, 4),
            "confidence_level": confidence_level,
            "method": method
        }
''',
            function_name="_calculate_var",
            metadata=SliceMetadata(complexity=0.5, reliability=0.93, tags=["finance", "risk", "var"])
        ),
        FunctionSlice(
            id="finance.risk.volatility",
            name="Volatility Analysis",
            description="변동성을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="price_data", param_type="pd.DataFrame", description="가격 데이터", required=True),
                SliceParameter(name="price_col", param_type="str", description="가격 컬럼", required=True),
                SliceParameter(name="window", param_type="int", description="이동 윈도우", default=20, required=False),
            ],
            outputs=[SliceParameter(name="volatility", param_type="pd.DataFrame", description="변동성 분석")],
            dependencies=[],
            keywords={
                "ko": ["변동성", "리스크", "표준편차", "볼라틸리티"],
                "en": ["volatility", "risk", "std", "deviation"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        result = price_data.copy()

        # 일일 수익률
        result['returns'] = result[price_col].pct_change()

        # 이동 변동성
        result['volatility'] = result['returns'].rolling(window).std() * np.sqrt(252)

        # 볼린저 밴드
        result['ma'] = result[price_col].rolling(window).mean()
        result['upper_band'] = result['ma'] + 2 * result[price_col].rolling(window).std()
        result['lower_band'] = result['ma'] - 2 * result[price_col].rolling(window).std()

        return result
''',
            function_name="_analyze_volatility",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["finance", "risk", "volatility"])
        ),
        FunctionSlice(
            id="finance.risk.default_probability",
            name="Default Probability",
            description="채무 불이행 확률을 계산합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="borrower_data", param_type="pd.DataFrame", description="차주 데이터", required=True),
                SliceParameter(name="model", param_type="Any", description="예측 모델", default=None, required=False),
            ],
            outputs=[SliceParameter(name="pd_scores", param_type="pd.DataFrame", description="부도 확률 데이터")],
            dependencies=["finance.risk.credit_score"],
            keywords={
                "ko": ["부도", "불이행", "확률", "PD"],
                "en": ["default", "probability", "pd", "bankruptcy"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        result = borrower_data.copy()

        if model is not None:
            # 모델 기반 예측
            features = result.select_dtypes(include=[np.number]).dropna(axis=1)
            result['default_probability'] = model.predict_proba(features)[:, 1]
        else:
            # 간단한 로직 기반 추정
            result['default_probability'] = (
                0.3 * (1 - result['credit_score'] / 100) +
                0.3 * result['debt_ratio'] +
                0.4 * result['delinquency_rate']
            ).clip(0, 1)

        result['risk_level'] = pd.cut(result['default_probability'],
                                      bins=[0, 0.1, 0.3, 0.5, 1.0],
                                      labels=['Low', 'Medium', 'High', 'Very High'])

        return result
''',
            function_name="_calculate_default_probability",
            metadata=SliceMetadata(complexity=0.6, reliability=0.88, tags=["finance", "risk", "default"])
        ),
        FunctionSlice(
            id="finance.risk.concentration",
            name="Concentration Risk",
            description="집중 위험을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="portfolio_data", param_type="pd.DataFrame", description="포트폴리오 데이터", required=True),
                SliceParameter(name="segment_col", param_type="str", description="세그먼트 컬럼", required=True),
                SliceParameter(name="value_col", param_type="str", description="가치 컬럼", required=True),
            ],
            outputs=[SliceParameter(name="concentration", param_type="pd.DataFrame", description="집중도 분석")],
            dependencies=[],
            keywords={
                "ko": ["집중", "위험", "분산", "포트폴리오"],
                "en": ["concentration", "risk", "diversification", "portfolio"]
            },
            code_template='''
        import pandas as pd

        # 세그먼트별 비중
        result = portfolio_data.groupby(segment_col)[value_col].sum().reset_index()
        total = result[value_col].sum()
        result['share'] = (result[value_col] / total * 100).round(2)

        # HHI (Herfindahl-Hirschman Index)
        hhi = (result['share'] ** 2).sum()

        # 상위 집중도
        result = result.sort_values('share', ascending=False)
        result['cumulative_share'] = result['share'].cumsum()

        # 집중 위험 수준
        top_concentration = result.head(3)['share'].sum()
        risk_level = 'High' if top_concentration > 50 else ('Medium' if top_concentration > 30 else 'Low')

        result['hhi'] = hhi
        result['concentration_risk'] = risk_level

        return result
''',
            function_name="_analyze_concentration",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["finance", "risk", "concentration"])
        ),
        FunctionSlice(
            id="finance.risk.liquidity",
            name="Liquidity Risk",
            description="유동성 위험을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="balance_data", param_type="pd.DataFrame", description="재무상태 데이터", required=True),
            ],
            outputs=[SliceParameter(name="liquidity_risk", param_type="pd.DataFrame", description="유동성 위험 분석")],
            dependencies=[],
            keywords={
                "ko": ["유동성", "위험", "현금", "단기"],
                "en": ["liquidity", "risk", "cash", "short-term"]
            },
            code_template='''
        import pandas as pd

        result = balance_data.copy()

        # 유동성 비율
        result['current_ratio'] = result['current_assets'] / result['current_liabilities']
        result['quick_ratio'] = (result['current_assets'] - result['inventory']) / result['current_liabilities']
        result['cash_ratio'] = result['cash'] / result['current_liabilities']

        # 유동성 위험 수준
        def assess_liquidity_risk(row):
            if row['current_ratio'] < 1:
                return 'Critical'
            elif row['current_ratio'] < 1.5:
                return 'High'
            elif row['current_ratio'] < 2:
                return 'Medium'
            return 'Low'

        result['liquidity_risk'] = result.apply(assess_liquidity_risk, axis=1)

        return result
''',
            function_name="_analyze_liquidity_risk",
            metadata=SliceMetadata(complexity=0.3, reliability=0.97, tags=["finance", "risk", "liquidity"])
        ),
        FunctionSlice(
            id="finance.risk.market",
            name="Market Risk",
            description="시장 위험을 분석합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="portfolio_returns", param_type="List[float]", description="포트폴리오 수익률", required=True),
                SliceParameter(name="market_returns", param_type="List[float]", description="시장 수익률", required=True),
            ],
            outputs=[SliceParameter(name="market_risk", param_type="Dict", description="시장 위험 분석")],
            dependencies=[],
            keywords={
                "ko": ["시장", "위험", "베타", "체계적"],
                "en": ["market", "risk", "beta", "systematic"]
            },
            code_template='''
        import numpy as np
        from scipy import stats

        portfolio_returns = np.array(portfolio_returns)
        market_returns = np.array(market_returns)

        # 베타 계산
        covariance = np.cov(portfolio_returns, market_returns)[0, 1]
        market_variance = np.var(market_returns)
        beta = covariance / market_variance if market_variance > 0 else 1

        # 알파
        alpha = np.mean(portfolio_returns) - beta * np.mean(market_returns)

        # R-squared
        correlation = np.corrcoef(portfolio_returns, market_returns)[0, 1]
        r_squared = correlation ** 2

        return {
            "beta": round(beta, 4),
            "alpha": round(alpha, 4),
            "r_squared": round(r_squared, 4),
            "correlation": round(correlation, 4)
        }
''',
            function_name="_analyze_market_risk",
            metadata=SliceMetadata(complexity=0.4, reliability=0.95, tags=["finance", "risk", "market"])
        ),
        FunctionSlice(
            id="finance.risk.fraud_detection",
            name="Fraud Detection",
            description="이상 거래를 탐지합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="transaction_data", param_type="pd.DataFrame", description="거래 데이터", required=True),
                SliceParameter(name="threshold", param_type="float", description="이상 탐지 임계값", default=3.0, required=False),
            ],
            outputs=[SliceParameter(name="fraud_flags", param_type="pd.DataFrame", description="이상 거래 플래그")],
            dependencies=["common.stats.outliers"],
            keywords={
                "ko": ["사기", "이상", "탐지", "부정"],
                "en": ["fraud", "detection", "anomaly", "suspicious"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        result = transaction_data.copy()

        # 금액 기반 이상 탐지
        amount_mean = result['amount'].mean()
        amount_std = result['amount'].std()
        result['amount_zscore'] = (result['amount'] - amount_mean) / amount_std
        result['amount_anomaly'] = np.abs(result['amount_zscore']) > threshold

        # 빈도 기반 이상 탐지
        daily_counts = result.groupby(['customer_id', result['timestamp'].dt.date]).size().reset_index(name='daily_count')
        count_mean = daily_counts['daily_count'].mean()
        count_std = daily_counts['daily_count'].std()
        daily_counts['count_anomaly'] = daily_counts['daily_count'] > count_mean + threshold * count_std

        # 종합 플래그
        result['fraud_flag'] = result['amount_anomaly']
        result['fraud_score'] = np.abs(result['amount_zscore'])

        return result
''',
            function_name="_detect_fraud",
            metadata=SliceMetadata(complexity=0.5, reliability=0.88, tags=["finance", "risk", "fraud"])
        ),
        FunctionSlice(
            id="finance.risk.stress_test",
            name="Stress Testing",
            description="스트레스 테스트를 수행합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="portfolio_value", param_type="float", description="포트폴리오 가치", required=True),
                SliceParameter(name="scenarios", param_type="Dict", description="시나리오별 충격", required=True),
            ],
            outputs=[SliceParameter(name="stress_results", param_type="Dict", description="스트레스 테스트 결과")],
            dependencies=[],
            keywords={
                "ko": ["스트레스", "테스트", "시나리오", "충격"],
                "en": ["stress", "test", "scenario", "shock"]
            },
            code_template='''
        results = {}

        for scenario_name, shock_pct in scenarios.items():
            shocked_value = portfolio_value * (1 + shock_pct)
            loss = portfolio_value - shocked_value
            loss_pct = (loss / portfolio_value) * 100

            results[scenario_name] = {
                "shock_applied": shock_pct * 100,
                "original_value": portfolio_value,
                "stressed_value": round(shocked_value, 2),
                "loss_amount": round(loss, 2),
                "loss_percentage": round(loss_pct, 2)
            }

        return results
''',
            function_name="_run_stress_test",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["finance", "risk", "stress"])
        ),
        FunctionSlice(
            id="finance.risk.sensitivity",
            name="Sensitivity Analysis",
            description="민감도 분석을 수행합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="base_value", param_type="float", description="기준 값", required=True),
                SliceParameter(name="variables", param_type="Dict", description="변수별 범위 {변수명: (min, max)}", required=True),
                SliceParameter(name="calculation_func", param_type="Callable", description="계산 함수", required=True),
            ],
            outputs=[SliceParameter(name="sensitivity", param_type="pd.DataFrame", description="민감도 분석 결과")],
            dependencies=[],
            keywords={
                "ko": ["민감도", "분석", "변수", "영향"],
                "en": ["sensitivity", "analysis", "variable", "impact"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        results = []

        for var_name, (var_min, var_max) in variables.items():
            values = np.linspace(var_min, var_max, 11)
            for val in values:
                result_value = calculation_func(**{var_name: val})
                change = (result_value - base_value) / base_value * 100

                results.append({
                    'variable': var_name,
                    'value': val,
                    'result': result_value,
                    'change_pct': round(change, 2)
                })

        return pd.DataFrame(results)
''',
            function_name="_analyze_sensitivity",
            metadata=SliceMetadata(complexity=0.5, reliability=0.90, tags=["finance", "risk", "sensitivity"])
        ),
    ]


# =============================================================================
# Forecasting Slices (10개)
# =============================================================================

def _create_forecasting_slices() -> List[FunctionSlice]:
    return [
        FunctionSlice(
            id="finance.forecast.revenue",
            name="Revenue Forecast",
            description="매출을 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="historical_data", param_type="pd.DataFrame", description="과거 매출 데이터", required=True),
                SliceParameter(name="date_col", param_type="str", description="날짜 컬럼", required=True),
                SliceParameter(name="value_col", param_type="str", description="매출 컬럼", required=True),
                SliceParameter(name="periods", param_type="int", description="예측 기간", default=12, required=False),
            ],
            outputs=[SliceParameter(name="forecast", param_type="pd.DataFrame", description="매출 예측 결과")],
            dependencies=[],
            keywords={
                "ko": ["매출", "예측", "수익", "전망"],
                "en": ["revenue", "forecast", "predict", "projection"]
            },
            code_template='''
        import pandas as pd
        import numpy as np
        from sklearn.linear_model import LinearRegression

        data = historical_data.copy()
        data[date_col] = pd.to_datetime(data[date_col])
        data = data.sort_values(date_col)

        # 선형 회귀 기반 예측
        X = np.arange(len(data)).reshape(-1, 1)
        y = data[value_col].values

        model = LinearRegression()
        model.fit(X, y)

        # 미래 예측
        future_X = np.arange(len(data), len(data) + periods).reshape(-1, 1)
        predictions = model.predict(future_X)

        # 결과 생성
        last_date = data[date_col].max()
        future_dates = pd.date_range(start=last_date, periods=periods + 1, freq='M')[1:]

        forecast = pd.DataFrame({
            date_col: future_dates,
            'forecast': predictions,
            'lower_bound': predictions * 0.9,
            'upper_bound': predictions * 1.1
        })

        return forecast
''',
            function_name="_forecast_revenue",
            metadata=SliceMetadata(complexity=0.5, reliability=0.85, tags=["finance", "forecast", "revenue"])
        ),
        FunctionSlice(
            id="finance.forecast.expense",
            name="Expense Forecast",
            description="비용을 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="expense_data", param_type="pd.DataFrame", description="과거 비용 데이터", required=True),
                SliceParameter(name="date_col", param_type="str", description="날짜 컬럼", required=True),
                SliceParameter(name="categories", param_type="List[str]", description="비용 카테고리", required=True),
                SliceParameter(name="periods", param_type="int", description="예측 기간", default=12, required=False),
            ],
            outputs=[SliceParameter(name="forecast", param_type="pd.DataFrame", description="비용 예측 결과")],
            dependencies=["finance.forecast.revenue"],
            keywords={
                "ko": ["비용", "예측", "경비", "전망"],
                "en": ["expense", "forecast", "cost", "predict"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        data = expense_data.copy()
        data[date_col] = pd.to_datetime(data[date_col])

        forecasts = []
        for cat in categories:
            cat_data = data[data['category'] == cat]
            avg = cat_data['amount'].mean()
            growth = cat_data['amount'].pct_change().mean()

            for i in range(periods):
                forecasts.append({
                    'category': cat,
                    'period': i + 1,
                    'forecast': avg * (1 + growth) ** (i + 1)
                })

        return pd.DataFrame(forecasts)
''',
            function_name="_forecast_expense",
            metadata=SliceMetadata(complexity=0.4, reliability=0.85, tags=["finance", "forecast", "expense"])
        ),
        FunctionSlice(
            id="finance.forecast.cashflow",
            name="Cashflow Forecast",
            description="현금흐름을 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="cashflow_data", param_type="pd.DataFrame", description="현금흐름 데이터", required=True),
                SliceParameter(name="periods", param_type="int", description="예측 기간", default=12, required=False),
            ],
            outputs=[SliceParameter(name="forecast", param_type="pd.DataFrame", description="현금흐름 예측")],
            dependencies=[],
            keywords={
                "ko": ["현금흐름", "예측", "캐시플로우"],
                "en": ["cashflow", "forecast", "cash", "prediction"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        # 평균 현금흐름 패턴 계산
        avg_operating = cashflow_data['operating_cf'].mean()
        avg_investing = cashflow_data['investing_cf'].mean()
        avg_financing = cashflow_data['financing_cf'].mean()

        forecasts = []
        cumulative = cashflow_data['ending_cash'].iloc[-1] if 'ending_cash' in cashflow_data.columns else 0

        for i in range(periods):
            net_cf = avg_operating + avg_investing + avg_financing
            cumulative += net_cf

            forecasts.append({
                'period': i + 1,
                'operating_cf': avg_operating,
                'investing_cf': avg_investing,
                'financing_cf': avg_financing,
                'net_cashflow': net_cf,
                'ending_cash': cumulative
            })

        return pd.DataFrame(forecasts)
''',
            function_name="_forecast_cashflow",
            metadata=SliceMetadata(complexity=0.4, reliability=0.85, tags=["finance", "forecast", "cashflow"])
        ),
        FunctionSlice(
            id="finance.forecast.time_series",
            name="Time Series Forecast",
            description="시계열 예측을 수행합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="data", param_type="pd.DataFrame", description="시계열 데이터", required=True),
                SliceParameter(name="date_col", param_type="str", description="날짜 컬럼", required=True),
                SliceParameter(name="value_col", param_type="str", description="값 컬럼", required=True),
                SliceParameter(name="periods", param_type="int", description="예측 기간", default=30, required=False),
                SliceParameter(name="method", param_type="str", description="예측 방법", default="ema", required=False),
            ],
            outputs=[SliceParameter(name="forecast", param_type="pd.DataFrame", description="시계열 예측 결과")],
            dependencies=[],
            keywords={
                "ko": ["시계열", "예측", "트렌드", "ARIMA"],
                "en": ["time", "series", "forecast", "arima", "trend"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        data = data.copy()
        data[date_col] = pd.to_datetime(data[date_col])
        data = data.sort_values(date_col)

        if method == "ema":
            # 지수이동평균 기반
            ema = data[value_col].ewm(span=20).mean().iloc[-1]
            trend = (data[value_col].iloc[-1] - data[value_col].iloc[-20]) / 20

            forecasts = []
            last_date = data[date_col].max()

            for i in range(periods):
                forecast_date = last_date + pd.Timedelta(days=i+1)
                forecast_value = ema + trend * (i + 1)
                forecasts.append({date_col: forecast_date, 'forecast': forecast_value})

        elif method == "ma":
            # 이동평균 기반
            ma = data[value_col].rolling(20).mean().iloc[-1]
            forecasts = [{date_col: data[date_col].max() + pd.Timedelta(days=i+1), 'forecast': ma} for i in range(periods)]

        return pd.DataFrame(forecasts)
''',
            function_name="_forecast_time_series",
            metadata=SliceMetadata(complexity=0.5, reliability=0.80, tags=["finance", "forecast", "timeseries"])
        ),
        FunctionSlice(
            id="finance.forecast.budget",
            name="Budget Forecast",
            description="예산을 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="historical_budget", param_type="pd.DataFrame", description="과거 예산 데이터", required=True),
                SliceParameter(name="growth_assumptions", param_type="Dict", description="성장률 가정", required=True),
            ],
            outputs=[SliceParameter(name="budget_forecast", param_type="pd.DataFrame", description="예산 예측")],
            dependencies=[],
            keywords={
                "ko": ["예산", "예측", "계획", "전망"],
                "en": ["budget", "forecast", "plan", "projection"]
            },
            code_template='''
        import pandas as pd

        result = historical_budget.copy()
        last_year = result.iloc[-1].to_dict()

        forecast = {}
        for category, value in last_year.items():
            growth = growth_assumptions.get(category, 0.05)  # 기본 5% 성장
            if isinstance(value, (int, float)):
                forecast[category] = value * (1 + growth)
            else:
                forecast[category] = value

        return pd.DataFrame([forecast])
''',
            function_name="_forecast_budget",
            metadata=SliceMetadata(complexity=0.3, reliability=0.90, tags=["finance", "forecast", "budget"])
        ),
        FunctionSlice(
            id="finance.forecast.scenario",
            name="Scenario Forecast",
            description="시나리오별 예측을 수행합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="base_case", param_type="Dict", description="기본 시나리오", required=True),
                SliceParameter(name="scenarios", param_type="Dict", description="시나리오 정의", required=True),
            ],
            outputs=[SliceParameter(name="scenario_forecast", param_type="pd.DataFrame", description="시나리오별 예측")],
            dependencies=[],
            keywords={
                "ko": ["시나리오", "예측", "낙관", "비관", "기본"],
                "en": ["scenario", "forecast", "optimistic", "pessimistic", "base"]
            },
            code_template='''
        import pandas as pd

        results = [{'scenario': 'Base', **base_case}]

        for scenario_name, adjustments in scenarios.items():
            scenario_result = {'scenario': scenario_name}
            for key, value in base_case.items():
                adjustment = adjustments.get(key, 1.0)
                scenario_result[key] = value * adjustment
            results.append(scenario_result)

        return pd.DataFrame(results)
''',
            function_name="_forecast_scenario",
            metadata=SliceMetadata(complexity=0.3, reliability=0.95, tags=["finance", "forecast", "scenario"])
        ),
        FunctionSlice(
            id="finance.forecast.monte_carlo",
            name="Monte Carlo Simulation",
            description="몬테카를로 시뮬레이션을 수행합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="base_value", param_type="float", description="기준 값", required=True),
                SliceParameter(name="volatility", param_type="float", description="변동성", required=True),
                SliceParameter(name="periods", param_type="int", description="예측 기간", default=252, required=False),
                SliceParameter(name="simulations", param_type="int", description="시뮬레이션 수", default=1000, required=False),
            ],
            outputs=[SliceParameter(name="simulation_results", param_type="Dict", description="시뮬레이션 결과")],
            dependencies=[],
            keywords={
                "ko": ["몬테카를로", "시뮬레이션", "확률", "예측"],
                "en": ["monte", "carlo", "simulation", "probability"]
            },
            code_template='''
        import numpy as np

        np.random.seed(42)
        dt = 1/252  # 일별

        paths = np.zeros((simulations, periods))
        paths[:, 0] = base_value

        for t in range(1, periods):
            random_shock = np.random.normal(0, 1, simulations)
            paths[:, t] = paths[:, t-1] * np.exp((-0.5 * volatility**2) * dt + volatility * np.sqrt(dt) * random_shock)

        final_values = paths[:, -1]

        return {
            "mean": float(np.mean(final_values)),
            "median": float(np.median(final_values)),
            "std": float(np.std(final_values)),
            "percentile_5": float(np.percentile(final_values, 5)),
            "percentile_95": float(np.percentile(final_values, 95)),
            "min": float(np.min(final_values)),
            "max": float(np.max(final_values))
        }
''',
            function_name="_monte_carlo_simulation",
            metadata=SliceMetadata(complexity=0.6, reliability=0.85, tags=["finance", "forecast", "montecarlo"])
        ),
        FunctionSlice(
            id="finance.forecast.growth",
            name="Growth Forecast",
            description="성장률을 예측합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="historical_data", param_type="pd.DataFrame", description="과거 데이터", required=True),
                SliceParameter(name="value_col", param_type="str", description="값 컬럼", required=True),
                SliceParameter(name="periods", param_type="int", description="예측 기간", default=5, required=False),
            ],
            outputs=[SliceParameter(name="growth_forecast", param_type="pd.DataFrame", description="성장률 예측")],
            dependencies=[],
            keywords={
                "ko": ["성장", "예측", "증가율", "CAGR"],
                "en": ["growth", "forecast", "cagr", "rate"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        values = historical_data[value_col].values
        n = len(values)

        # CAGR 계산
        cagr = (values[-1] / values[0]) ** (1 / n) - 1

        # 예측
        forecasts = []
        last_value = values[-1]

        for i in range(periods):
            forecast_value = last_value * (1 + cagr) ** (i + 1)
            forecasts.append({
                'period': i + 1,
                'forecast': forecast_value,
                'growth_rate': cagr * 100
            })

        result = pd.DataFrame(forecasts)
        result['cagr'] = cagr * 100

        return result
''',
            function_name="_forecast_growth",
            metadata=SliceMetadata(complexity=0.3, reliability=0.90, tags=["finance", "forecast", "growth"])
        ),
        FunctionSlice(
            id="finance.forecast.seasonal",
            name="Seasonal Forecast",
            description="계절성을 반영한 예측을 수행합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="data", param_type="pd.DataFrame", description="시계열 데이터", required=True),
                SliceParameter(name="date_col", param_type="str", description="날짜 컬럼", required=True),
                SliceParameter(name="value_col", param_type="str", description="값 컬럼", required=True),
                SliceParameter(name="seasonality", param_type="int", description="계절성 주기", default=12, required=False),
            ],
            outputs=[SliceParameter(name="forecast", param_type="pd.DataFrame", description="계절성 예측 결과")],
            dependencies=[],
            keywords={
                "ko": ["계절성", "예측", "주기", "패턴"],
                "en": ["seasonal", "forecast", "cycle", "pattern"]
            },
            code_template='''
        import pandas as pd
        import numpy as np

        data = data.copy()
        data[date_col] = pd.to_datetime(data[date_col])
        data['month'] = data[date_col].dt.month

        # 월별 계절성 지수 계산
        overall_mean = data[value_col].mean()
        seasonal_index = data.groupby('month')[value_col].mean() / overall_mean

        # 트렌드 추출
        data = data.sort_values(date_col)
        x = np.arange(len(data))
        slope, intercept = np.polyfit(x, data[value_col], 1)

        # 예측 생성
        forecasts = []
        last_date = data[date_col].max()

        for i in range(seasonality):
            forecast_date = last_date + pd.DateOffset(months=i+1)
            month = forecast_date.month
            trend_value = intercept + slope * (len(data) + i)
            seasonal_value = trend_value * seasonal_index[month]

            forecasts.append({
                date_col: forecast_date,
                'trend': trend_value,
                'seasonal_factor': seasonal_index[month],
                'forecast': seasonal_value
            })

        return pd.DataFrame(forecasts)
''',
            function_name="_forecast_seasonal",
            metadata=SliceMetadata(complexity=0.5, reliability=0.85, tags=["finance", "forecast", "seasonal"])
        ),
        FunctionSlice(
            id="finance.forecast.regression",
            name="Regression Forecast",
            description="회귀 분석 기반 예측을 수행합니다.",
            category=SliceCategory.DOMAIN,
            domain=SliceDomain.FINANCE,
            inputs=[
                SliceParameter(name="data", param_type="pd.DataFrame", description="학습 데이터", required=True),
                SliceParameter(name="target_col", param_type="str", description="타겟 컬럼", required=True),
                SliceParameter(name="feature_cols", param_type="List[str]", description="피처 컬럼", required=True),
                SliceParameter(name="prediction_data", param_type="pd.DataFrame", description="예측 데이터", default=None, required=False),
            ],
            outputs=[SliceParameter(name="predictions", param_type="pd.DataFrame", description="예측 결과")],
            dependencies=[],
            keywords={
                "ko": ["회귀", "예측", "모델", "변수"],
                "en": ["regression", "forecast", "model", "predict"]
            },
            code_template='''
        import pandas as pd
        from sklearn.linear_model import LinearRegression
        from sklearn.metrics import r2_score

        X = data[feature_cols]
        y = data[target_col]

        model = LinearRegression()
        model.fit(X, y)

        # 예측
        if prediction_data is not None:
            X_pred = prediction_data[feature_cols]
            predictions = model.predict(X_pred)
            result = prediction_data.copy()
            result['prediction'] = predictions
        else:
            result = data.copy()
            result['prediction'] = model.predict(X)
            result['r2_score'] = r2_score(y, result['prediction'])

        # 계수 정보
        coefficients = dict(zip(feature_cols, model.coef_))
        result.attrs['coefficients'] = coefficients
        result.attrs['intercept'] = model.intercept_

        return result
''',
            function_name="_forecast_regression",
            metadata=SliceMetadata(complexity=0.5, reliability=0.85, tags=["finance", "forecast", "regression"])
        ),
    ]
