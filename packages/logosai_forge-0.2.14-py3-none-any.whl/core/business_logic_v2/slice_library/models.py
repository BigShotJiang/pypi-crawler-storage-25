"""
Function Slice Models
=====================
Paper1 기반 Function Slice 데이터 모델 정의

Function Slice는 단일 책임 원칙(SRP)을 따르는 최소 단위의 비즈니스 로직 조각입니다.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Any, Optional, Callable, Union
import hashlib
import json


class SliceCategory(Enum):
    """슬라이스 카테고리"""
    CORE = "core"           # 모든 에이전트 필수 (4개)
    COMMON = "common"       # 다수 도메인 공유 (40개)
    DOMAIN = "domain"       # 도메인 특화 (160+개)


class SliceDomain(Enum):
    """슬라이스 도메인"""
    # Core/Common
    CORE = "core"
    COMMON = "common"

    # Domain-specific
    CUSTOMER = "customer"
    FINANCE = "finance"
    MARKETING = "marketing"
    PRODUCT = "product"
    ML_AI = "ml_ai"

    # Extended domains
    DATA_IO = "data_io"
    SECURITY = "security"
    PRIVACY = "privacy"
    ANALYTICS = "analytics"
    INTEGRATION = "integration"

    # New domains for 82% coverage
    INVENTORY = "inventory"           # 재고/공급망 관리
    HR = "hr"                         # 인사/급여 관리
    ORDER = "order"                   # 주문 관리
    PROJECT = "project"               # 프로젝트 관리


@dataclass
class SliceParameter:
    """슬라이스 파라미터 정의"""
    name: str
    param_type: str
    description: str = ""
    default: Any = None
    required: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "type": self.param_type,
            "description": self.description,
            "default": self.default,
            "required": self.required
        }


@dataclass
class SliceTestCase:
    """슬라이스 테스트 케이스"""
    name: str
    inputs: Dict[str, Any]
    expected_output: Any
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "inputs": self.inputs,
            "expected_output": self.expected_output,
            "description": self.description
        }


@dataclass
class SliceMetadata:
    """슬라이스 메타데이터"""
    author: str = "FORGE AI"
    version: str = "1.0.0"
    created_at: str = ""
    updated_at: str = ""
    complexity: float = 0.5  # 0.0 ~ 1.0
    reliability: float = 1.0  # 0.0 ~ 1.0
    performance_score: float = 1.0  # 0.0 ~ 1.0
    usage_count: int = 0
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "author": self.author,
            "version": self.version,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "complexity": self.complexity,
            "reliability": self.reliability,
            "performance_score": self.performance_score,
            "usage_count": self.usage_count,
            "tags": self.tags
        }


@dataclass
class FunctionSlice:
    """
    Function Slice 정의

    Function Slice는 단일 책임 원칙을 따르는 최소 단위의 비즈니스 로직 조각입니다.
    수학적 정의: S = (id, inputs, outputs, deps, code, meta)
    """
    # 기본 식별 정보
    id: str
    name: str
    description: str

    # 분류
    category: SliceCategory
    domain: SliceDomain

    # 입출력 정의
    inputs: List[SliceParameter] = field(default_factory=list)
    outputs: List[SliceParameter] = field(default_factory=list)

    # 의존성
    dependencies: List[str] = field(default_factory=list)  # 의존하는 슬라이스 ID 목록

    # 다국어 키워드 (의미론적 매칭용)
    # 지원 형식:
    # 1. Dict[str, List[str]]: {"ko": ["키워드"], "en": ["keyword"]}
    # 2. List[str]: ["키워드1", "keyword1"] (자동 분류)
    keywords: Union[Dict[str, List[str]], List[str]] = field(default_factory=lambda: {"ko": [], "en": []})

    # 코드 템플릿
    code_template: str = ""
    function_name: str = ""  # 생성될 함수명

    # 테스트 케이스
    test_cases: List[SliceTestCase] = field(default_factory=list)

    # 메타데이터
    metadata: SliceMetadata = field(default_factory=SliceMetadata)

    def __post_init__(self):
        """초기화 후 처리"""
        if not self.function_name:
            self.function_name = self._generate_function_name()

    def _generate_function_name(self) -> str:
        """함수명 생성"""
        # ID에서 함수명 생성 (snake_case)
        return f"_{self.id.replace('-', '_').replace('.', '_')}"

    def get_input_signature(self) -> str:
        """입력 시그니처 생성"""
        params = []
        for param in self.inputs:
            if param.default is not None:
                params.append(f"{param.name}: {param.param_type} = {repr(param.default)}")
            elif not param.required:
                params.append(f"{param.name}: Optional[{param.param_type}] = None")
            else:
                params.append(f"{param.name}: {param.param_type}")
        return ", ".join(params)

    def get_output_type(self) -> str:
        """출력 타입 생성"""
        if len(self.outputs) == 0:
            return "None"
        elif len(self.outputs) == 1:
            return self.outputs[0].param_type
        else:
            types = [o.param_type for o in self.outputs]
            return f"Tuple[{', '.join(types)}]"

    def generate_function_code(self) -> str:
        """함수 코드 생성"""
        signature = self.get_input_signature()
        return_type = self.get_output_type()

        # 독스트링 생성
        docstring_parts = [f'"""{self.description}']
        if self.inputs:
            docstring_parts.append("\n        Args:")
            for param in self.inputs:
                docstring_parts.append(f"            {param.name}: {param.description}")
        if self.outputs:
            docstring_parts.append("\n        Returns:")
            for out in self.outputs:
                docstring_parts.append(f"            {out.param_type}: {out.description}")
        docstring_parts.append('"""')

        docstring = "\n        ".join(docstring_parts)

        code = f'''
    def {self.function_name}(self, {signature}) -> {return_type}:
        {docstring}
{self.code_template}
'''
        return code

    def get_hash(self) -> str:
        """슬라이스 해시 생성 (버전 관리용)"""
        content = json.dumps({
            "id": self.id,
            "code": self.code_template,
            "inputs": [p.to_dict() for p in self.inputs],
            "outputs": [o.to_dict() for o in self.outputs]
        }, sort_keys=True)
        return hashlib.md5(content.encode()).hexdigest()[:8]

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리 변환"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "domain": self.domain.value,
            "inputs": [p.to_dict() for p in self.inputs],
            "outputs": [o.to_dict() for o in self.outputs],
            "dependencies": self.dependencies,
            "keywords": self.keywords,
            "code_template": self.code_template,
            "function_name": self.function_name,
            "test_cases": [t.to_dict() for t in self.test_cases],
            "metadata": self.metadata.to_dict()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FunctionSlice":
        """딕셔너리에서 생성"""
        inputs = [SliceParameter(**p) for p in data.get("inputs", [])]
        outputs = [SliceParameter(**o) for o in data.get("outputs", [])]
        test_cases = [SliceTestCase(**t) for t in data.get("test_cases", [])]
        metadata = SliceMetadata(**data.get("metadata", {}))

        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            category=SliceCategory(data.get("category", "common")),
            domain=SliceDomain(data.get("domain", "common")),
            inputs=inputs,
            outputs=outputs,
            dependencies=data.get("dependencies", []),
            keywords=data.get("keywords", {"ko": [], "en": []}),
            code_template=data.get("code_template", ""),
            function_name=data.get("function_name", ""),
            test_cases=test_cases,
            metadata=metadata
        )


@dataclass
class SliceCompositionResult:
    """슬라이스 조합 결과"""
    success: bool = True
    composed_code: str = ""
    slice_ids: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    execution_time: float = 0.0
    # Legacy fields for backwards compatibility
    selected_slices: List[FunctionSlice] = field(default_factory=list)
    execution_order: List[str] = field(default_factory=list)
    data_flow: Dict[str, List[str]] = field(default_factory=dict)
    new_slices_created: int = 0
    reuse_rate: float = 0.0

    @property
    def generated_code(self) -> str:
        """Alias for composed_code (backwards compatibility)"""
        return self.composed_code

    @property
    def composition_time_ms(self) -> float:
        """Alias for execution_time in ms"""
        return self.execution_time * 1000

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "composed_code": self.composed_code,
            "slice_ids": self.slice_ids,
            "warnings": self.warnings,
            "dependencies": self.dependencies,
            "execution_time": self.execution_time,
            "execution_order": self.execution_order,
            "data_flow": self.data_flow,
            "new_slices_created": self.new_slices_created,
            "reuse_rate": self.reuse_rate
        }


# Type aliases for convenience
SliceDict = Dict[str, FunctionSlice]
KeywordIndex = Dict[str, List[str]]  # {키워드: [슬라이스ID]}
DependencyGraph = Dict[str, List[str]]  # {슬라이스ID: [의존 슬라이스ID]}
