"""
Comprehensive Pipeline Test
============================
Function Slice 시스템의 전체 파이프라인을 테스트하고
각 단계별 결과를 상세히 출력하는 테스트 스크립트

테스트 목적:
1. 사용자 쿼리 분석 과정 검증
2. 슬라이스 매칭 알고리즘 검증
3. 의존성 해결 과정 검증
4. 코드 조합 및 생성 검증
5. 최종 결과물 품질 검증
"""

import sys
import os
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

# 프로젝트 루트 경로 추가
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))


def print_section(title: str, char: str = "="):
    """섹션 헤더 출력"""
    print(f"\n{char * 60}")
    print(f" {title}")
    print(f"{char * 60}")


def print_subsection(title: str):
    """서브섹션 헤더 출력"""
    print(f"\n{'─' * 40}")
    print(f" {title}")
    print(f"{'─' * 40}")


class PipelineTestRunner:
    """파이프라인 테스트 실행기"""

    def __init__(self):
        self.results = {
            "test_date": datetime.now().isoformat(),
            "test_cases": [],
            "summary": {}
        }

    def initialize_library(self):
        """라이브러리 초기화"""
        print_section("STEP 0: 라이브러리 초기화")

        from forge.core.business_logic_v2.slice_library import (
            initialize_library,
            get_slice_library,
            SliceLibrary
        )

        # 싱글톤 리셋
        SliceLibrary._instance = None

        # 라이브러리 초기화
        self.library = initialize_library(include_common=True, include_domain=True)

        # 통계 출력
        stats = self.library.get_statistics()
        print(f"\n✅ 라이브러리 초기화 완료")
        print(f"   - 총 슬라이스: {stats['total_slices']}개")
        print(f"   - 카테고리별: {stats['by_category']}")
        print(f"   - 도메인별: {stats['by_domain']}")
        print(f"   - 키워드 인덱스: 한국어 {stats['keyword_count']['ko']}개, 영어 {stats['keyword_count']['en']}개")

        self.results["library_stats"] = stats
        return self.library

    def run_pipeline_test(self, query: str, agent_name: str, test_name: str) -> Dict[str, Any]:
        """전체 파이프라인 테스트 실행"""

        test_result = {
            "test_name": test_name,
            "query": query,
            "agent_name": agent_name,
            "steps": {}
        }

        print_section(f"TEST CASE: {test_name}")
        print(f"\n📝 입력 쿼리: \"{query}\"")
        print(f"📦 에이전트 이름: {agent_name}")

        # ─────────────────────────────────────────────────────────────
        # STEP 1: 쿼리 분석 (Query Analysis)
        # ─────────────────────────────────────────────────────────────
        print_subsection("STEP 1: 쿼리 분석 (Query Analysis)")

        from forge.core.business_logic_v2.slice_library import SemanticMatcher

        matcher = SemanticMatcher(self.library)

        # 쿼리 토큰화
        query_lower = query.lower()
        tokens = matcher._tokenize(query_lower)
        print(f"\n1.1 쿼리 토큰화:")
        print(f"    원본: \"{query}\"")
        print(f"    소문자: \"{query_lower}\"")
        print(f"    토큰: {tokens}")

        # 도메인 추론
        inferred_domains = matcher._infer_domains(query_lower)
        print(f"\n1.2 도메인 추론:")
        print(f"    추론된 도메인: {[d.value for d in inferred_domains]}")

        # 작업 유형 감지
        task_type = matcher.get_task_type(query)
        print(f"\n1.3 작업 유형 감지:")
        print(f"    감지된 유형: {task_type}")

        test_result["steps"]["query_analysis"] = {
            "tokens": tokens,
            "inferred_domains": [d.value for d in inferred_domains],
            "task_type": task_type
        }

        # ─────────────────────────────────────────────────────────────
        # STEP 2: 슬라이스 매칭 (Slice Matching)
        # ─────────────────────────────────────────────────────────────
        print_subsection("STEP 2: 슬라이스 매칭 (Slice Matching)")

        matches = matcher.match_query(query, top_k=15, min_score=0.1)

        print(f"\n2.1 매칭된 슬라이스 (상위 15개):")
        print(f"    {'순위':<4} {'슬라이스 ID':<35} {'점수':<8} {'매칭 키워드'}")
        print(f"    {'-'*80}")

        for i, match in enumerate(matches, 1):
            keywords_str = ", ".join(match.matched_keywords[:3])
            if len(match.matched_keywords) > 3:
                keywords_str += "..."
            print(f"    {i:<4} {match.slice_id:<35} {match.score:<8.3f} {keywords_str}")

        test_result["steps"]["slice_matching"] = {
            "total_matches": len(matches),
            "matches": [
                {
                    "slice_id": m.slice_id,
                    "score": m.score,
                    "matched_keywords": m.matched_keywords,
                    "domain_match": m.domain_match
                }
                for m in matches
            ]
        }

        # ─────────────────────────────────────────────────────────────
        # STEP 3: 의존성 해결 (Dependency Resolution)
        # ─────────────────────────────────────────────────────────────
        print_subsection("STEP 3: 의존성 해결 (Dependency Resolution)")

        from forge.core.business_logic_v2.slice_library import DependencyResolver

        resolver = DependencyResolver(self.library)
        slice_ids = [m.slice_id for m in matches]

        print(f"\n3.1 입력 슬라이스 ({len(slice_ids)}개):")
        for sid in slice_ids[:10]:
            print(f"    - {sid}")
        if len(slice_ids) > 10:
            print(f"    ... 외 {len(slice_ids) - 10}개")

        execution_order, warnings = resolver.resolve(slice_ids, include_core=True)

        print(f"\n3.2 실행 순서 ({len(execution_order)}개):")
        for i, sid in enumerate(execution_order, 1):
            slice_obj = self.library.get(sid)
            category = slice_obj.category.value if slice_obj else "unknown"
            print(f"    {i:>3}. [{category:<6}] {sid}")

        if warnings:
            print(f"\n3.3 경고 사항:")
            for w in warnings:
                print(f"    ⚠️  {w}")

        test_result["steps"]["dependency_resolution"] = {
            "input_count": len(slice_ids),
            "output_count": len(execution_order),
            "execution_order": execution_order,
            "warnings": warnings
        }

        # ─────────────────────────────────────────────────────────────
        # STEP 4: 데이터 흐름 설계 (Data Flow Design)
        # ─────────────────────────────────────────────────────────────
        print_subsection("STEP 4: 데이터 흐름 설계 (Data Flow Design)")

        from forge.core.business_logic_v2.slice_library import DataFlowDesigner

        flow_designer = DataFlowDesigner(self.library)
        flow_nodes = flow_designer.design_flow(execution_order)
        flow_issues = flow_designer.validate_flow(flow_nodes)

        print(f"\n4.1 데이터 흐름 노드 ({len(flow_nodes)}개):")
        for i, node in enumerate(flow_nodes[:10], 1):
            inputs_str = ", ".join(list(node.inputs.keys())[:3]) or "없음"
            outputs_str = ", ".join(list(node.outputs.keys())[:3]) or "없음"
            print(f"    {i:>3}. {node.slice_id:<30}")
            print(f"         입력: {inputs_str}")
            print(f"         출력: {outputs_str}")

        if len(flow_nodes) > 10:
            print(f"    ... 외 {len(flow_nodes) - 10}개 노드")

        if flow_issues:
            print(f"\n4.2 데이터 흐름 이슈 ({len(flow_issues)}개):")
            for issue in flow_issues[:5]:
                print(f"    ⚠️  {issue}")
            if len(flow_issues) > 5:
                print(f"    ... 외 {len(flow_issues) - 5}개")

        test_result["steps"]["data_flow"] = {
            "node_count": len(flow_nodes),
            "issues_count": len(flow_issues),
            "sample_nodes": [
                {
                    "slice_id": n.slice_id,
                    "inputs": dict(n.inputs),
                    "outputs": dict(n.outputs)
                }
                for n in flow_nodes[:5]
            ]
        }

        # ─────────────────────────────────────────────────────────────
        # STEP 5: 코드 조합 (Code Composition)
        # ─────────────────────────────────────────────────────────────
        print_subsection("STEP 5: 코드 조합 (Code Composition)")

        from forge.core.business_logic_v2.slice_library import CodeComposer

        composer = CodeComposer(self.library)
        composition_result = composer.compose(
            agent_name=agent_name,
            execution_order=execution_order,
            flow_nodes=flow_nodes,
            description=query
        )

        print(f"\n5.1 조합 결과:")
        print(f"    성공 여부: {'✅ 성공' if composition_result.success else '❌ 실패'}")
        print(f"    사용된 슬라이스: {len(composition_result.slice_ids)}개")
        print(f"    필요 의존성: {composition_result.dependencies}")

        # 코드 구조 분석
        code = composition_result.composed_code
        code_lines = code.count('\n')
        import_count = code.count('import ')
        class_count = code.count('class ')
        def_count = code.count('def ')

        print(f"\n5.2 생성된 코드 통계:")
        print(f"    총 라인 수: {code_lines}")
        print(f"    import 문: {import_count}개")
        print(f"    클래스 정의: {class_count}개")
        print(f"    함수 정의: {def_count}개")

        test_result["steps"]["code_composition"] = {
            "success": composition_result.success,
            "slice_count": len(composition_result.slice_ids),
            "dependencies": composition_result.dependencies,
            "code_stats": {
                "lines": code_lines,
                "imports": import_count,
                "classes": class_count,
                "functions": def_count
            }
        }

        # ─────────────────────────────────────────────────────────────
        # STEP 6: 최종 결과물 검증 (Final Validation)
        # ─────────────────────────────────────────────────────────────
        print_subsection("STEP 6: 최종 결과물 검증 (Final Validation)")

        validation_results = self._validate_generated_code(code, agent_name)

        print(f"\n6.1 구문 검증:")
        print(f"    Python 구문: {'✅ 유효' if validation_results['syntax_valid'] else '❌ 오류'}")

        print(f"\n6.2 구조 검증:")
        print(f"    LogosAIAgent 상속: {'✅' if validation_results['has_agent_class'] else '❌'}")
        print(f"    process 메서드: {'✅' if validation_results['has_process_method'] else '❌'}")
        print(f"    AgentConfig 설정: {'✅' if validation_results['has_agent_config'] else '❌'}")
        print(f"    agentic_config: {'✅' if validation_results['has_agentic_config'] else '❌'}")

        print(f"\n6.3 슬라이스 함수:")
        print(f"    포함된 슬라이스 코드: {validation_results['slice_function_count']}개")

        test_result["steps"]["validation"] = validation_results
        test_result["success"] = all([
            validation_results['syntax_valid'],
            validation_results['has_agent_class'],
            validation_results['has_process_method']
        ])

        # ─────────────────────────────────────────────────────────────
        # 생성된 코드 미리보기
        # ─────────────────────────────────────────────────────────────
        print_subsection("생성된 코드 미리보기 (처음 100줄)")

        code_preview = "\n".join(code.split("\n")[:100])
        print(code_preview)
        print(f"\n... (총 {code_lines}줄 중 100줄 표시)")

        test_result["generated_code_preview"] = code_preview
        test_result["generated_code_full"] = code

        self.results["test_cases"].append(test_result)

        return test_result

    def _validate_generated_code(self, code: str, agent_name: str) -> Dict[str, Any]:
        """생성된 코드 검증"""
        results = {
            "syntax_valid": False,
            "has_agent_class": False,
            "has_process_method": False,
            "has_agent_config": False,
            "has_agentic_config": False,
            "slice_function_count": 0,
            "errors": []
        }

        # 구문 검증
        try:
            compile(code, '<string>', 'exec')
            results["syntax_valid"] = True
        except SyntaxError as e:
            results["errors"].append(f"Syntax error: {e}")

        # 구조 검증
        results["has_agent_class"] = "class " in code and "Agent" in code and "LogosAIAgent" in code
        results["has_process_method"] = "async def process" in code
        results["has_agent_config"] = "AgentConfig" in code
        results["has_agentic_config"] = "agentic_config" in code

        # 슬라이스 함수 카운트
        results["slice_function_count"] = code.count("# ===== Slice:")

        return results

    def run_all_tests(self):
        """모든 테스트 실행"""
        print_section("🚀 Function Slice Pipeline 종합 테스트", "═")
        print(f"\n테스트 시작 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        # 라이브러리 초기화
        self.initialize_library()

        # 테스트 케이스 정의
        test_cases = [
            {
                "query": "고객 이탈 예측 모델을 만들어주세요",
                "agent_name": "CustomerChurnPredictor",
                "test_name": "한국어 - 고객 이탈 예측"
            },
            {
                "query": "Create a machine learning classification model for customer segmentation",
                "agent_name": "MLClassifier",
                "test_name": "English - ML Classification"
            },
            {
                "query": "재무 리스크 분석 및 매출 예측 시스템",
                "agent_name": "FinanceRiskAnalyzer",
                "test_name": "한국어 - 재무 분석"
            },
            {
                "query": "데이터 전처리와 통계 분석을 수행하는 에이전트",
                "agent_name": "DataProcessor",
                "test_name": "한국어 - 데이터 처리"
            }
        ]

        # 각 테스트 실행
        for tc in test_cases:
            self.run_pipeline_test(
                query=tc["query"],
                agent_name=tc["agent_name"],
                test_name=tc["test_name"]
            )

        # 최종 요약
        self._print_summary()

        return self.results

    def _print_summary(self):
        """테스트 결과 요약"""
        print_section("📊 테스트 결과 요약", "═")

        total_tests = len(self.results["test_cases"])
        passed_tests = sum(1 for tc in self.results["test_cases"] if tc.get("success", False))

        print(f"\n총 테스트: {total_tests}개")
        print(f"성공: {passed_tests}개")
        print(f"실패: {total_tests - passed_tests}개")
        print(f"성공률: {(passed_tests/total_tests)*100:.1f}%")

        print(f"\n{'테스트명':<35} {'결과':<10} {'슬라이스':<10} {'라인수'}")
        print(f"{'-'*70}")

        for tc in self.results["test_cases"]:
            name = tc["test_name"][:33]
            result = "✅ PASS" if tc.get("success", False) else "❌ FAIL"
            slices = tc["steps"]["code_composition"]["slice_count"]
            lines = tc["steps"]["code_composition"]["code_stats"]["lines"]
            print(f"{name:<35} {result:<10} {slices:<10} {lines}")

        self.results["summary"] = {
            "total_tests": total_tests,
            "passed": passed_tests,
            "failed": total_tests - passed_tests,
            "success_rate": (passed_tests/total_tests)*100
        }

        print(f"\n{'═' * 60}")
        print(" 테스트 완료")
        print(f"{'═' * 60}")


def main():
    """메인 실행 함수"""
    runner = PipelineTestRunner()
    results = runner.run_all_tests()

    # 결과를 JSON 파일로 저장
    output_file = os.path.join(os.path.dirname(__file__), "pipeline_test_results.json")
    with open(output_file, 'w', encoding='utf-8') as f:
        # 코드 전체는 너무 길어서 미리보기만 저장
        save_results = results.copy()
        for tc in save_results.get("test_cases", []):
            if "generated_code_full" in tc:
                del tc["generated_code_full"]
        json.dump(save_results, f, ensure_ascii=False, indent=2)

    print(f"\n📁 결과 저장: {output_file}")

    return results


if __name__ == "__main__":
    main()
