"""
Workflow Orchestrator for Function Integration
"""

from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from loguru import logger
import re


class WorkflowStrategy(Enum):
    """Workflow execution strategies"""
    SEQUENTIAL = "sequential"  # Execute functions one after another
    PARALLEL = "parallel"      # Execute independent functions simultaneously
    CONDITIONAL = "conditional"  # Execute based on conditions
    LOOP = "loop"              # Execute in a loop with iterations
    PIPELINE = "pipeline"      # Data flows through functions


@dataclass
class WorkflowStep:
    """Single step in a workflow"""
    function_name: str
    inputs: Dict[str, Any]
    outputs: List[str]
    dependencies: List[str]
    condition: Optional[str] = None
    strategy: WorkflowStrategy = WorkflowStrategy.SEQUENTIAL


@dataclass
class Workflow:
    """Complete workflow definition"""
    steps: List[WorkflowStep]
    strategy: WorkflowStrategy
    error_handling: str = "stop_on_error"
    parallel_limit: int = 3
    timeout: int = 300


class WorkflowOrchestrator:
    """Orchestrates function execution and data flow"""
    
    def __init__(self):
        self.execution_patterns = {
            "data_pipeline": self._generate_pipeline_pattern,
            "parallel_analysis": self._generate_parallel_pattern,
            "conditional_processing": self._generate_conditional_pattern,
            "iterative_improvement": self._generate_loop_pattern,
            "sequential_workflow": self._generate_sequential_pattern
        }
        
        logger.info("Workflow orchestrator initialized")
    
    def generate_orchestration_code(
        self,
        workflow: Workflow,
        generated_functions: Dict[str, str]
    ) -> str:
        """Generate orchestration code for the workflow"""
        
        # Determine orchestration pattern
        pattern = self._determine_pattern(workflow)
        
        # Generate orchestration code based on pattern
        if pattern == "data_pipeline":
            return self._generate_pipeline_pattern(workflow, generated_functions)
        elif pattern == "parallel_analysis":
            return self._generate_parallel_pattern(workflow, generated_functions)
        elif pattern == "conditional_processing":
            return self._generate_conditional_pattern(workflow, generated_functions)
        elif pattern == "iterative_improvement":
            return self._generate_loop_pattern(workflow, generated_functions)
        else:
            return self._generate_sequential_pattern(workflow, generated_functions)
    
    def _determine_pattern(self, workflow: Workflow) -> str:
        """Determine the best orchestration pattern"""
        
        # Check for pipeline pattern (each step feeds the next)
        if self._is_pipeline(workflow):
            return "data_pipeline"
        
        # Check for parallel pattern (independent steps)
        if self._has_parallel_steps(workflow):
            return "parallel_analysis"
        
        # Check for conditional pattern
        if self._has_conditions(workflow):
            return "conditional_processing"
        
        # Check for loop pattern
        if workflow.strategy == WorkflowStrategy.LOOP:
            return "iterative_improvement"
        
        # Default to sequential
        return "sequential_workflow"
    
    def _is_pipeline(self, workflow: Workflow) -> bool:
        """Check if workflow is a data pipeline"""
        for i, step in enumerate(workflow.steps[:-1]):
            next_step = workflow.steps[i + 1]
            # Check if output of current step is input to next
            if not any(output in str(next_step.inputs) for output in step.outputs):
                return False
        return len(workflow.steps) > 1
    
    def _has_parallel_steps(self, workflow: Workflow) -> bool:
        """Check if workflow has parallel steps"""
        # Find steps with no dependencies on each other
        for i, step1 in enumerate(workflow.steps):
            for step2 in workflow.steps[i+1:]:
                # If neither depends on the other, they can be parallel
                if (step1.function_name not in step2.dependencies and
                    step2.function_name not in step1.dependencies):
                    return True
        return False
    
    def _has_conditions(self, workflow: Workflow) -> bool:
        """Check if workflow has conditional steps"""
        return any(step.condition is not None for step in workflow.steps)
    
    def _generate_pipeline_pattern(
        self,
        workflow: Workflow,
        generated_functions: Dict[str, str]
    ) -> str:
        """Generate pipeline orchestration code"""
        
        code = '''
    async def execute_workflow(self, initial_data: Any) -> Dict[str, Any]:
        """Execute data pipeline workflow"""
        
        results = {}
        current_data = initial_data
        pipeline_metadata = {
            "start_time": datetime.now(),
            "steps_completed": [],
            "errors": []
        }
        
        try:
'''
        
        # Generate pipeline steps
        for i, step in enumerate(workflow.steps):
            code += f'''
            # Step {i+1}: {step.function_name}
            logger.info(f"Executing pipeline step {i+1}: {step.function_name}")
            
            try:
                result = await self.{step.function_name}(current_data)
                results["{step.function_name}"] = result
                pipeline_metadata["steps_completed"].append("{step.function_name}")
                
                # Pass result to next step
                current_data = result.get("data", result)
                
            except Exception as e:
                logger.error(f"Pipeline step {i+1} failed: {{e}}")
                pipeline_metadata["errors"].append({{
                    "step": "{step.function_name}",
                    "error": str(e)
                }})
                {"raise" if workflow.error_handling == "stop_on_error" else "pass"}
'''
        
        code += '''
            # Pipeline completed successfully
            pipeline_metadata["end_time"] = datetime.now()
            pipeline_metadata["duration"] = (
                pipeline_metadata["end_time"] - pipeline_metadata["start_time"]
            ).total_seconds()

            # Build flat output: merge last step result with pipeline metadata
            flat_output = {
                "success": True,
                "status": "completed",
                "steps_completed": len(pipeline_metadata["steps_completed"]),
            }
            # If the final step produced a dict, merge its keys into the output
            if isinstance(current_data, dict):
                flat_output.update(current_data)
            else:
                flat_output["final_output"] = current_data
            flat_output["intermediate_results"] = results
            flat_output["metadata"] = pipeline_metadata

            return flat_output

        except Exception as e:
            logger.error(f"Pipeline execution failed: {e}")
            return {
                "success": False,
                "status": "failed",
                "error": str(e),
                "steps_completed": len(pipeline_metadata.get("steps_completed", [])),
                "intermediate_results": results,
                "metadata": pipeline_metadata
            }
'''
        
        return code
    
    def _generate_parallel_pattern(
        self,
        workflow: Workflow,
        generated_functions: Dict[str, str]
    ) -> str:
        """Generate parallel execution orchestration code with concrete function names"""

        # Separate independent steps (no deps) from dependent ones
        independent = [s for s in workflow.steps if not s.dependencies]
        dependent = [s for s in workflow.steps if s.dependencies]

        # Build parallel tasks list
        parallel_calls = []
        for step in independent:
            parallel_calls.append(f'self.{step.function_name}(input_data)')

        sequential_calls = []
        for step in dependent:
            sequential_calls.append(step.function_name)

        code = '''
    async def execute_workflow(self, input_data: Any) -> Dict[str, Any]:
        """Execute parallel workflow with asyncio.gather"""

        import asyncio

        results = {}
        errors = []
        start_time = datetime.now()

        try:
'''
        # Parallel group
        if parallel_calls:
            func_names_str = ', '.join(f'"{s.function_name}"' for s in independent)
            code += f'            # Execute independent steps in parallel\n'
            code += f'            parallel_names = [{func_names_str}]\n'
            code += f'            parallel_tasks = [\n'
            for call in parallel_calls:
                code += f'                {call},\n'
            code += f'            ]\n'
            code += f'            parallel_results = await asyncio.gather(*parallel_tasks, return_exceptions=True)\n'
            code += f'\n'
            code += f'            for name, result in zip(parallel_names, parallel_results):\n'
            code += f'                if isinstance(result, Exception):\n'
            code += f'                    logger.error(f"Parallel task {{name}} failed: {{result}}")\n'
            code += f'                    errors.append({{"step": name, "error": str(result)}})\n'
            code += f'                else:\n'
            code += f'                    results[name] = result\n'
            code += f'\n'

        # Sequential dependent steps
        for func_name in sequential_calls:
            code += f'            # Sequential step: {func_name} (has dependencies)\n'
            code += f'            try:\n'
            code += f'                results["{func_name}"] = await self.{func_name}({{**input_data, **results}})\n'
            code += f'            except Exception as e:\n'
            code += f'                logger.error(f"Step {func_name} failed: {{e}}")\n'
            code += f'                errors.append({{"step": "{func_name}", "error": str(e)}})\n'
            code += f'\n'

        code += '''
            duration = (datetime.now() - start_time).total_seconds()

            # Build flat output with steps_completed count
            flat_output = {
                "success": len(errors) == 0,
                "status": "completed" if len(errors) == 0 else "failed",
                "steps_completed": len(results),
                "results": results,
                "errors": errors,
                "metadata": {"duration": duration, "steps": len(results)}
            }
            # Merge last result into top-level for direct key access
            if results:
                last_result = list(results.values())[-1]
                if isinstance(last_result, dict):
                    flat_output.update(last_result)
                    flat_output["results"] = results  # Restore after update

            return flat_output

        except Exception as e:
            logger.error(f"Parallel execution failed: {e}")
            return {
                "success": False,
                "status": "failed",
                "error": str(e),
                "steps_completed": len(results),
                "partial_results": results
            }
'''

        return code
    
    def _generate_conditional_pattern(
        self,
        workflow: Workflow,
        generated_functions: Dict[str, str]
    ) -> str:
        """Generate conditional execution orchestration code"""

        code = '''
    async def execute_workflow(self, input_data: Any) -> Dict[str, Any]:
        """Execute conditional workflow"""

        results = {}
        conditions_log = []
        branches_taken = []
        errors = []

        try:
'''

        # Generate conditional steps with correct indentation
        for step in workflow.steps:
            if step.condition:
                error_action = "raise" if workflow.error_handling == "stop_on_error" else "pass"
                # Validate condition is valid Python expression; fallback to True
                validated_condition = step.condition
                try:
                    compile(step.condition, "<condition>", "eval")
                except SyntaxError:
                    validated_condition = "True"  # Natural language → always execute
                safe_condition = validated_condition.replace('"', '\\"')
                code += f'''            # Conditional step: {step.function_name}
            condition_{step.function_name} = {validated_condition}
            conditions_log.append({{
                "step": "{step.function_name}",
                "condition": "{safe_condition}",
                "result": condition_{step.function_name}
            }})

            if condition_{step.function_name}:
                logger.info("Condition met, executing: {step.function_name}")
                branches_taken.append("{step.function_name}")
                try:
                    results["{step.function_name}"] = await self.{step.function_name}(input_data)
                except Exception as e:
                    logger.error(f"Step {step.function_name} failed: {{e}}")
                    errors.append({{"step": "{step.function_name}", "error": str(e)}})
                    {error_action}
            else:
                logger.info("Condition not met, skipping: {step.function_name}")

'''
            else:
                error_action = "raise" if workflow.error_handling == "stop_on_error" else "pass"
                code += f'''            # Unconditional step: {step.function_name}
            logger.info("Executing: {step.function_name}")
            try:
                results["{step.function_name}"] = await self.{step.function_name}(input_data)
            except Exception as e:
                logger.error(f"Step {step.function_name} failed: {{e}}")
                errors.append({{"step": "{step.function_name}", "error": str(e)}})
                {error_action}

'''

        code += '''
            flat_output = {
                "success": len(errors) == 0,
                "status": "completed" if len(errors) == 0 else "failed",
                "steps_completed": len(branches_taken),
                "results": results,
                "conditions": conditions_log,
                "branches_taken": branches_taken,
                "errors": errors
            }
            if results:
                last_result = list(results.values())[-1]
                if isinstance(last_result, dict):
                    flat_output.update(last_result)
                    flat_output["results"] = results

            return flat_output

        except Exception as e:
            logger.error(f"Conditional workflow failed: {e}")
            return {
                "success": False,
                "status": "failed",
                "error": str(e),
                "steps_completed": 0,
                "partial_results": results
            }
'''

        return code
    
    def _generate_loop_pattern(
        self,
        workflow: Workflow,
        generated_functions: Dict[str, str]
    ) -> str:
        """Generate iterative loop orchestration code"""
        
        code = '''
    async def execute_workflow(
        self,
        input_data: Any,
        max_iterations: int = 10,
        convergence_threshold: float = 0.01
    ) -> Dict[str, Any]:
        """Execute iterative improvement workflow"""
        
        results = []
        loop_metadata = {
            "start_time": datetime.now(),
            "iterations": [],
            "convergence_achieved": False,
            "errors": []
        }
        
        current_data = input_data
        previous_score = None
        
        try:
            for iteration in range(max_iterations):
                logger.info(f"Starting iteration {iteration + 1}")
                
                iteration_results = {}
                iteration_start = datetime.now()
                
                # Execute workflow steps for this iteration
'''
        
        for step in workflow.steps:
            code += f'''
                try:
                    result = await self.{step.function_name}(current_data)
                    iteration_results["{step.function_name}"] = result
                    current_data = result.get("data", result)
                except Exception as e:
                    logger.error(f"Iteration {{iteration + 1}} step {step.function_name} failed: {{e}}")
                    loop_metadata["errors"].append({{
                        "iteration": iteration + 1,
                        "step": "{step.function_name}",
                        "error": str(e)
                    }})
                    {"raise" if workflow.error_handling == "stop_on_error" else "pass"}
'''
        
        code += '''
                # Calculate improvement score
                current_score = self._calculate_improvement_score(iteration_results)
                
                # Check for convergence
                if previous_score is not None:
                    improvement = abs(current_score - previous_score)
                    if improvement < convergence_threshold:
                        logger.info(f"Convergence achieved at iteration {iteration + 1}")
                        loop_metadata["convergence_achieved"] = True
                        break
                
                # Record iteration metadata
                iteration_duration = (datetime.now() - iteration_start).total_seconds()
                loop_metadata["iterations"].append({
                    "iteration": iteration + 1,
                    "score": current_score,
                    "improvement": improvement if previous_score else None,
                    "duration": iteration_duration,
                    "results": iteration_results
                })
                
                results.append(iteration_results)
                previous_score = current_score
            
            loop_metadata["end_time"] = datetime.now()
            loop_metadata["total_duration"] = (
                loop_metadata["end_time"] - loop_metadata["start_time"]
            ).total_seconds()
            loop_metadata["total_iterations"] = len(results)
            
            return {
                "success": True,
                "final_output": current_data,
                "iterations": results,
                "metadata": loop_metadata,
                "convergence": loop_metadata["convergence_achieved"]
            }
            
        except Exception as e:
            logger.error(f"Loop workflow failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "partial_results": results,
                "metadata": loop_metadata
            }
    
    def _calculate_improvement_score(self, results: Dict[str, Any]) -> float:
        """Calculate improvement score for convergence check"""
        # This is a placeholder - actual implementation depends on use case
        score = 0.0
        
        for key, value in results.items():
            if isinstance(value, dict):
                # Look for quality metrics
                if "quality_score" in value:
                    score += value["quality_score"]
                elif "accuracy" in value:
                    score += value["accuracy"]
                elif "success_rate" in value:
                    score += value["success_rate"]
        
        return score / max(len(results), 1)
'''
        
        return code
    
    def _generate_sequential_pattern(
        self,
        workflow: Workflow,
        generated_functions: Dict[str, str]
    ) -> str:
        """Generate sequential execution orchestration code with data piping"""

        code = '''
    async def _process_core_logic(self, extracted_info: Dict) -> Dict:
        """Core business logic orchestration with data piping between steps"""

        steps_completed = []
        step_results = {}

        try:
'''

        # Generate sequential steps with data piping
        for i, step in enumerate(workflow.steps):
            if step.dependencies:
                # Build dep merge lines: each dep's result merged into input
                dep_merges = ""
                for dep in step.dependencies:
                    dep_merges += f"""
            _dep_data = step_results.get("{dep}", {{}})
            if isinstance(_dep_data, dict):
                step_input.update(_dep_data)"""
                code += f'''            # Step {i+1}: {step.function_name} (depends on: {", ".join(step.dependencies)})
            logger.info("Executing {step.function_name}")
            step_input = dict(extracted_info){dep_merges}
            step_results["{step.function_name}"] = await self.{step.function_name}(step_input)
            steps_completed.append("{step.function_name}")

'''
            else:
                code += f'''            # Step {i+1}: {step.function_name}
            logger.info("Executing {step.function_name}")
            step_results["{step.function_name}"] = await self.{step.function_name}(extracted_info)
            steps_completed.append("{step.function_name}")

'''

        code += '''
            # Build flat output: merge last step result with orchestration metadata
            flat_output = {
                "success": True,
                "status": "completed",
                "steps_completed": len(steps_completed),
            }
            # Merge the last step's result into top-level for direct key access
            if step_results:
                last_result = list(step_results.values())[-1]
                if isinstance(last_result, dict):
                    flat_output.update(last_result)
            flat_output["results"] = step_results
            flat_output["metadata"] = {
                "steps_executed": len(steps_completed),
                "timestamp": datetime.now().isoformat()
            }

            return flat_output

        except Exception as e:
            logger.error(f"Processing failed: {e}")
            return {
                "success": False,
                "status": "failed",
                "error": str(e),
                "steps_completed": len(steps_completed),
                "partial_results": step_results
            }
'''

        return code
    
    def analyze_dependencies(
        self,
        function_specs: List[Dict[str, Any]]
    ) -> Dict[str, List[str]]:
        """Analyze dependencies between functions"""
        
        dependencies = {}
        
        for i, spec in enumerate(function_specs):
            func_name = spec.get("name", f"function_{i}")
            deps = []
            
            # Check if this function uses output from others
            for j, other_spec in enumerate(function_specs):
                if i != j:
                    other_name = other_spec.get("name", f"function_{j}")
                    
                    # Check if outputs of other function are inputs to this
                    other_outputs = other_spec.get("outputs", [])
                    this_inputs = spec.get("inputs", {})
                    
                    for output in other_outputs:
                        if output in str(this_inputs):
                            deps.append(other_name)
                            break
            
            dependencies[func_name] = deps
        
        return dependencies
    
    def optimize_workflow(self, workflow: Workflow) -> Workflow:
        """Optimize workflow for better performance"""
        
        # Identify parallel opportunities
        parallel_groups = self._identify_parallel_groups(workflow)
        
        # Reorder steps for optimal execution
        optimized_steps = self._reorder_steps(workflow.steps, parallel_groups)
        
        # Update workflow strategy if beneficial
        if len(parallel_groups) > 1:
            workflow.strategy = WorkflowStrategy.PARALLEL
        
        workflow.steps = optimized_steps
        
        logger.info(f"Workflow optimized: {len(parallel_groups)} parallel groups identified")
        
        return workflow
    
    def _identify_parallel_groups(self, workflow: Workflow) -> List[List[WorkflowStep]]:
        """Identify groups of steps that can run in parallel"""
        
        groups = []
        processed = set()
        
        for step in workflow.steps:
            if step.function_name not in processed:
                # Find all steps that don't depend on this one and vice versa
                group = [step]
                processed.add(step.function_name)
                
                for other in workflow.steps:
                    if other.function_name not in processed:
                        # Check if they can be parallel
                        if (step.function_name not in other.dependencies and
                            other.function_name not in step.dependencies):
                            group.append(other)
                            processed.add(other.function_name)
                
                groups.append(group)
        
        return groups
    
    def _reorder_steps(
        self,
        steps: List[WorkflowStep],
        parallel_groups: List[List[WorkflowStep]]
    ) -> List[WorkflowStep]:
        """Reorder steps for optimal execution"""
        
        reordered = []
        
        # Add groups in dependency order
        for group in parallel_groups:
            # Sort within group by number of dependencies (fewer first)
            sorted_group = sorted(group, key=lambda x: len(x.dependencies))
            reordered.extend(sorted_group)
        
        return reordered