"""
Code Assembler for Final Agent Generation

Uses string.Template-based templates (base_agent.py.template, agentic_agent.py.template)
for clean code generation with $variable substitution.
"""

from typing import Dict, List, Any, Optional
from loguru import logger
from datetime import datetime
from string import Template
from pathlib import Path
import json
import re


class CodeAssembler:
    """Assembles final agent code from components using template files"""

    def __init__(self):
        self._template_cache: Dict[str, str] = {}
        self._template_dir = Path(__file__).parent.parent.parent / "templates"
        logger.info("Code assembler initialized")

    def _load_template(self, name: str) -> Template:
        """Load a template file and return a string.Template instance.

        Args:
            name: Template name without extension (e.g. 'base_agent')

        Returns:
            string.Template ready for safe_substitute()
        """
        template_path = self._template_dir / f"{name}.py.template"

        if not template_path.exists():
            logger.warning(f"Template {template_path} not found, falling back to base_agent")
            template_path = self._template_dir / "base_agent.py.template"

        # Check cache (using mtime for invalidation)
        cache_key = str(template_path)
        mtime = template_path.stat().st_mtime
        cached = self._template_cache.get(cache_key)

        if cached and cached[0] == mtime:
            return Template(cached[1])

        content = template_path.read_text(encoding="utf-8")
        self._template_cache[cache_key] = (mtime, content)
        logger.debug(f"Loaded template: {template_path.name} ({len(content)} chars)")
        return Template(content)

    def find_domain_template(self, description: str, detected_patterns: Optional[List[str]] = None) -> Optional[Dict[str, Any]]:
        """Search the template registry for a specialized template matching the query.

        Args:
            description: Agent description / user query
            detected_patterns: Optional list of detected pattern keywords from PatternDetector

        Returns:
            Dict with template info (name, file, category, required_packages, score)
            or None if no strong match found.
        """
        registry_path = self._template_dir / "template_registry.json"
        if not registry_path.exists():
            return None

        try:
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.warning(f"Failed to load template registry: {e}")
            return None

        templates = registry.get("templates", {})
        desc_lower = description.lower()
        pattern_tokens = set(p.lower() for p in (detected_patterns or []))

        best_match = None
        best_score = 0

        for tpl_id, tpl_info in templates.items():
            keywords = [k.lower() for k in tpl_info.get("keywords", [])]
            if not keywords:
                continue

            # Score: count keyword hits in description + detected patterns
            hits = sum(1 for kw in keywords if kw in desc_lower)
            pattern_hits = sum(1 for kw in keywords if kw in pattern_tokens)
            score = hits + pattern_hits * 1.5  # Boost pattern matches

            if score > best_score:
                best_score = score
                best_match = {
                    "id": tpl_id,
                    "name": tpl_info.get("name", tpl_id),
                    "file": tpl_info.get("file", ""),
                    "category": tpl_info.get("category", "general"),
                    "required_packages": tpl_info.get("required_packages", []),
                    "difficulty": tpl_info.get("difficulty", "beginner"),
                    "score": score,
                }

        # Require at least 2 keyword hits for a meaningful match
        if best_match and best_match["score"] >= 2:
            # Check if the template file actually exists
            tpl_file = self._template_dir / best_match["file"]
            best_match["file_exists"] = tpl_file.exists()
            logger.info(f"Domain template match: {best_match['name']} (score={best_match['score']:.1f}, exists={best_match['file_exists']})")
            return best_match

        return None

    def _sanitize_class_name(self, name: str) -> str:
        """
        Sanitize agent name to create a valid Python class name.

        Converts names like "Customer Behavior Insights Agent" to "CustomerBehaviorInsightsAgent"

        Rules:
        - Remove spaces and convert to PascalCase
        - Remove special characters that are invalid in Python identifiers
        - Ensure the name starts with a letter (not a digit)

        Args:
            name: The original agent name (may contain spaces)

        Returns:
            A valid Python class name in PascalCase
        """
        if not name:
            return "GeneratedAgent"

        # Split by spaces and other common separators
        words = re.split(r'[\s\-_]+', name)

        # Capitalize each word and join (PascalCase)
        sanitized_parts = []
        for word in words:
            if word:
                # Remove any non-alphanumeric characters
                cleaned = re.sub(r'[^a-zA-Z0-9]', '', word)
                if cleaned:
                    # Capitalize first letter
                    sanitized_parts.append(cleaned[0].upper() + cleaned[1:])

        result = ''.join(sanitized_parts)

        # Ensure the name starts with a letter
        if result and result[0].isdigit():
            result = 'Agent' + result

        # Fallback if result is empty
        if not result:
            result = "GeneratedAgent"

        logger.debug(f"Sanitized class name: '{name}' -> '{result}'")
        return result
    
    def assemble(
        self,
        agent_name: str,
        description: str,
        generated_functions: Dict[str, str],
        orchestration_code: str,
        imports: Optional[List[str]] = None,
        use_enhanced_agent: bool = False,
        agentic_config: Optional[Dict[str, Any]] = None,
        detected_patterns: Optional[List[str]] = None
    ) -> str:
        """Assemble complete agent code"""
        # Log agentic detection results
        logger.info(f"CodeAssembler.assemble called with use_enhanced_agent={use_enhanced_agent}")
        if use_enhanced_agent:
            logger.info(f"Agentic config: {agentic_config}")
        
        if use_enhanced_agent:
            logger.info("Using LogosAIAgent with agentic features enabled via config")
        else:
            logger.info("Using LogosAIAgent in basic mode (no agentic config)")

        # Check for matching domain template (adds required_packages to imports)
        domain_match = self.find_domain_template(description, detected_patterns)
        extra_imports = list(imports or [])
        if domain_match:
            for pkg in domain_match.get("required_packages", []):
                imp = f"import {pkg}" if "." not in pkg else f"from {pkg.rsplit('.', 1)[0]} import {pkg.rsplit('.', 1)[1]}"
                if imp not in extra_imports:
                    extra_imports.append(imp)

        # Sanitize agent name for valid Python class/function names
        class_name = self._sanitize_class_name(agent_name)
        logger.info(f"Sanitized class name: '{agent_name}' -> '{class_name}'")

        # Generate imports
        import_section = self._generate_imports(extra_imports, generated_functions)
        
        # Combine all functions
        functions_section = self._combine_functions(generated_functions)
        
        # Detect orchestration method name from generated code
        orch_method = "_process_core_logic"
        if "execute_workflow" in orchestration_code:
            orch_method = "execute_workflow"

        # Generate main execution method (agentic-aware, calls orchestration)
        main_method = self._generate_main_method(agent_name, generated_functions, use_agentic=use_enhanced_agent, orchestration_method=orch_method)

        # Generate agentic initialization code
        agentic_init_code = ""
        if use_enhanced_agent and agentic_config:
            agentic_init_code = self._generate_agentic_init(agentic_config, generated_functions)

        # Generate intelligent sample data based on functions
        sample_data = self._generate_sample_data(generated_functions, description)

        # Build agent configuration string
        if use_enhanced_agent and agentic_config:
            # Ensure agentic_config has runtime activation flags
            enriched_config = dict(agentic_config)
            enriched_config.setdefault("enable_agentic", True)
            ac = enriched_config.setdefault("agentic_config", {})
            ac.setdefault("tools_enabled", True)
            ac.setdefault("reasoning_type", "chain_of_thought")
            ac.setdefault("memory_capacity", 100)
            ac.setdefault("learning_rate", 0.01)
            # Convert the agentic config to Python code format (not JSON)
            config_dict_str = self._format_dict_as_python(enriched_config, indent=16)
            config_str = f"""config = AgentConfig(
            name="{agent_name}",
            description="{description}",
            agent_type=AgentType.CUSTOM,
            config={config_dict_str}
        )"""
            init_log = f'logger.info(f"Initialized {{self.config.name}} with agentic AI features")'
            class_docstring_extra = "\n    This agent uses agentic AI capabilities"
        else:
            config_str = f"""config = AgentConfig(
            name="{agent_name}",
            description="{description}",
            agent_type=AgentType.CUSTOM,
            config={{}}
        )"""
            init_log = f'logger.info(f"Initialized {{self.config.name}}")'
            class_docstring_extra = ""
        
        # Select and load template
        template_name = "agentic_agent" if use_enhanced_agent else "base_agent"
        template = self._load_template(template_name)

        # Substitute template variables
        substitutions = {
            "agent_description": f"AI Agent generated from query: {description}",
            "timestamp": datetime.now().isoformat(),
            "num_functions": str(len(generated_functions)),
            "import_section": import_section,
            "agent_class_name": class_name,
            "class_docstring_extra": class_docstring_extra,
            "config_str": config_str,
            "agent_name": agent_name,
            "init_log": init_log,
            "functions_section": functions_section,
            "orchestration_code": orchestration_code,
            "main_method": main_method,
            "sample_data": sample_data,
        }
        if use_enhanced_agent:
            substitutions["agentic_init_code"] = agentic_init_code

        code = template.safe_substitute(substitutions)
        logger.info(f"Agent code assembled via {template_name} template: {len(code)} characters")

        return code
    
    # Imports already present in both base_agent.py.template and agentic_agent.py.template.
    # _generate_imports() must NOT duplicate these.
    _TEMPLATE_BUILTIN_IMPORTS = frozenset({
        "import asyncio",
        "import json",
        "import os",
        "from typing import Dict, Any, List, Optional, Union, Tuple, Callable",
        "from datetime import datetime",
        "from dataclasses import dataclass",
        "from loguru import logger",
    })

    def _generate_imports(
        self,
        custom_imports: List[str],
        generated_functions: Dict[str, str]
    ) -> str:
        """Generate additional import statements (beyond template built-ins)"""

        imports: List[str] = []

        # Add custom imports (from domain template packages, etc.)
        imports.extend(custom_imports)

        # Detect needed imports from generated functions
        all_code = '\n'.join(generated_functions.values())

        # Auto-detect standard library module usage in generated functions
        stdlib_patterns = {
            r'\bmath\.': "import math",
            r'\bre\.': "import re",
            r'\brandom\.': "import random",
            r'\bstring\.': "import string",
            r'\bhashlib\.': "import hashlib",
            r'\bsecrets\.': "import secrets",
            r'\bcollections\.': "import collections",
            r'\bstatistics\.': "import statistics",
            r'\buuid\.': "import uuid",
            r'\bbase64\.': "import base64",
            r'\bhtml\.': "import html",
            r'\burllib\.': "import urllib",
            r'\bdecimal\.': "import decimal",
            r'\btextwrap\.': "import textwrap",
            r'\bcsv\.': "import csv",
            r'\bio\.': "import io",
            r'\bcopy\.': "import copy",
            r'\bpathlib\.': "import pathlib",
            r'\bstruct\.': "import struct",
            r'\bitertools\.': "import itertools",
            r'\bfunctools\.': "import functools",
            r'\btime\.': "import time",
            r'\bsocket\.': "import socket",
            r'\bhttp\.': "import http",
        }
        for pattern, imp_stmt in stdlib_patterns.items():
            if re.search(pattern, all_code) and imp_stmt not in imports:
                imports.append(imp_stmt)

        # Check for pandas usage (regex-based detection)
        if re.search(r'(?:import pandas|from pandas|pd\.)', all_code):
            imports.append("import pandas as pd")
            imports.append("import numpy as np")
        elif "DataFrame" in all_code:
            imports.append("import pandas as pd")

        # Check for ML libraries (specific imports instead of wildcard)
        if re.search(r'(?:sklearn|StandardScaler|MinMaxScaler)', all_code):
            if "StandardScaler" in all_code or "MinMaxScaler" in all_code:
                imports.append("from sklearn.preprocessing import StandardScaler, MinMaxScaler")
            if re.search(r'(?:train_test_split|cross_val)', all_code):
                imports.append("from sklearn.model_selection import train_test_split")
            if re.search(r'(?:accuracy_score|precision|recall|f1_score)', all_code):
                imports.append("from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score")
            if not any("sklearn" in imp for imp in imports):
                imports.append("import sklearn")

        if "transformers" in all_code:
            imports.append("from transformers import pipeline")

        # Check for visualization
        if "plotly" in all_code:
            imports.append("import plotly.graph_objects as go")
            imports.append("import plotly.express as px")
        elif "matplotlib" in all_code:
            imports.append("import matplotlib.pyplot as plt")

        # Check for web/API
        if "aiohttp" in all_code:
            imports.append("import aiohttp")
        elif "requests" in all_code:
            imports.append("import requests")

        # Check for email
        if "smtplib" in all_code:
            imports.append("import smtplib")
            imports.append("from email.mime.text import MIMEText")
            imports.append("from email.mime.multipart import MIMEMultipart")

        # Deduplicate against template built-ins, then sort
        imports = sorted(set(imports) - self._TEMPLATE_BUILTIN_IMPORTS)

        return '\n'.join(imports)
    
    def _combine_functions(self, generated_functions: Dict[str, str]) -> str:
        """Combine all generated functions"""

        # Indent all functions for class
        indented_functions = []

        for func_name, func_code in generated_functions.items():
            # Clean up markdown code blocks first
            func_code = self._strip_markdown(func_code)

            # Clean up any import statements that might have slipped in
            lines = func_code.split('\n')
            cleaned_lines = []

            for line in lines:
                # Skip only TOP-LEVEL import lines (no indentation)
                # Preserve indented imports inside function bodies (e.g., "    import string")
                stripped = line.lstrip()
                is_import = stripped.startswith(('import ', 'from '))
                is_top_level = (len(line) == len(stripped))  # no indentation
                if is_import and is_top_level:
                    logger.info(f"Removing top-level import from {func_name}: {line.strip()}")
                    continue
                # Skip markdown code block markers
                if line.strip() in ('```python', '```', '```py'):
                    logger.warning(f"Removing markdown from {func_name}: {line.strip()}")
                    continue
                cleaned_lines.append(line)
            
            # Remove leading empty lines
            while cleaned_lines and not cleaned_lines[0].strip():
                cleaned_lines.pop(0)
            
            # Indent each line for class
            indented_lines = []
            for line in cleaned_lines:
                if line.strip():  # Non-empty lines
                    indented_lines.append('    ' + line)
                else:  # Empty lines
                    indented_lines.append('')
            
            indented_functions.append('\n'.join(indented_lines))
        
        return '\n\n'.join(indented_functions)

    def _strip_markdown(self, code: str) -> str:
        """Strip markdown code block markers from code"""
        if not code:
            return code

        # Remove ```python ... ``` blocks - extract content only
        # Pattern for ```python or ```py code blocks
        pattern = r'```(?:python|py)?\s*(.*?)```'
        matches = re.findall(pattern, code, re.DOTALL)

        if matches:
            # Join all code blocks found
            code = '\n\n'.join(matches)
        else:
            # If no proper code blocks found, strip any remaining markers
            lines = code.split('\n')
            cleaned = []
            for line in lines:
                stripped = line.strip()
                if stripped in ('```python', '```py', '```'):
                    continue
                cleaned.append(line)
            code = '\n'.join(cleaned)

        return code.strip()

    def _generate_agentic_init(self, agentic_config: Dict, generated_functions: Dict) -> str:
        """Generate agentic tool registration code for __init__"""
        lines = []
        lines.append("")
        lines.append("        # Register generated functions as agentic tools")
        lines.append("        if hasattr(self, '_agentic_tools') and self._agentic_tools:")

        for func_name in generated_functions:
            clean_name = func_name.lstrip('_')
            lines.append(f'            try:')
            lines.append(f'                from logosai.agentic.tools import Tool, ToolCategory')
            lines.append(f'                self._agentic_tools.register_tool(Tool(')
            lines.append(f'                    name="{clean_name}",')
            lines.append(f'                    description="Auto-registered: {clean_name}",')
            lines.append(f'                    category=ToolCategory.CUSTOM,')
            lines.append(f'                    function=self.{func_name},')
            lines.append(f'                    parameters=[],')
            lines.append(f'                    returns="Dict"')
            lines.append(f'                ))')
            lines.append(f'            except Exception:')
            lines.append(f'                pass')

        return '\n'.join(lines)

    def _generate_query_parser_method(self) -> str:
        """Generate _extract_structured_input() helper that bridges NL queries to structured params"""
        return '''    def _extract_structured_input(self, query: str) -> Dict[str, Any]:
        """Extract structured parameters from a natural language query.

        Bridges the gap between user-facing NL queries and function-expected structured input.
        Handles: math expressions, number extraction, operation detection.

        Output keys (standardized contract):
          - query: original query string
          - operands/numbers: list of extracted numbers
          - operation: symbol form ("+", "-", "*", "/", "**", "%")
          - operation_name: word form ("add", "subtract", "multiply", "divide", "power", "modulo")
          - value/a/b: first/second operands for convenience
          - expression: math expression string
          - computed_result: evaluated result
        """
        import re
        params = {}

        # Extract numbers from query
        numbers = [float(n) if '.' in n else int(n)
                   for n in re.findall(r'-?\\d+(?:\\.\\d+)?', query)]
        if numbers:
            params["operands"] = numbers
            params["numbers"] = numbers
            # Convenience aliases for first/second operands
            params["value"] = numbers[0]
            params["a"] = numbers[0]
            if len(numbers) > 1:
                params["b"] = numbers[1]

        # Bidirectional operation mapping: word ↔ symbol
        op_map = {
            "add": "+", "plus": "+", "sum": "+",
            "subtract": "-", "minus": "-",
            "multiply": "*", "times": "*",
            "divide": "/",
            "power": "**", "exponent": "**",
            "modulo": "%", "mod ": "%", "remainder": "%",
        }
        # Reverse map: symbol → canonical word
        symbol_to_name = {
            "+": "add", "-": "subtract", "*": "multiply",
            "/": "divide", "**": "power", "%": "modulo",
        }

        query_lower = query.lower()
        for word, op in op_map.items():
            if word in query_lower:
                params["operation"] = op
                params["operation_name"] = symbol_to_name.get(op, word)
                break

        # Detect math operator symbols between numbers (e.g. "125 * 48")
        if "operation" not in params:
            ops = re.findall(r'(?<=\\d)\\s*([+\\-*/^%])\\s*(?=\\d)', query)
            if ops:
                unique_ops = set(ops)
                if len(unique_ops) == 1:
                    op = ops[0]
                    if op == '^':
                        op = '**'
                    params["operation"] = op
                    params["operation_name"] = symbol_to_name.get(op, op)

        # Try to safely evaluate the full math expression
        math_expr = re.sub(r'[a-zA-Z\\u3131-\\ud79d?!,;:=]+', ' ', query).strip()
        math_expr = re.sub(r'\\s+', ' ', math_expr).strip()
        if math_expr and re.match(r'^[\\d\\s+\\-*/().^%]+$', math_expr):
            expr = math_expr.replace('^', '**')
            try:
                result = eval(expr, {"__builtins__": {}}, {})
                params["expression"] = expr.strip()
                params["computed_result"] = result
            except Exception:
                pass

        return params
'''

    def _generate_main_method(self, agent_name: str, generated_functions: Dict[str, str], use_agentic: bool = False, orchestration_method: str = "_process_core_logic") -> str:
        """Generate main process method that calls the orchestration code.

        Unified method: one process() with optional agentic fallback.
        Eliminates the previous 2-method duplication (agentic vs basic).
        """
        query_parser = self._generate_query_parser_method()

        # Agentic as enhancement AFTER orchestration, not replacement
        # Orchestration (slice-based functions) is FORGE's core value.
        # Agentic is supplementary reasoning on top of orchestration results.
        agentic_block = ""
        if use_agentic:
            agentic_block = f'''
            # Enhance result with agentic reasoning (supplementary, not replacement)
            if hasattr(self, '_agentic_core') and self._agentic_core:
                try:
                    agentic_insight = await self._agentic_core.execute_cycle(
                        f"Analyze this result: {{json.dumps(result)[:500]}}"
                    )
                    if agentic_insight and isinstance(agentic_insight, dict):
                        result["agentic_insight"] = agentic_insight
                except Exception:
                    pass  # Agentic enhancement is optional
'''

        process_method = f'''    async def process(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> AgentResponse:
        """Main processing method for {agent_name}"""

        try:
            logger.info(f"Starting {agent_name} processing: {{query[:80]}}")

            # Parse query into structured input
            if isinstance(query, str):
                try:
                    input_data = json.loads(query)
                    if not isinstance(input_data, dict):
                        input_data = {{"query": query, "data": input_data}}
                except (json.JSONDecodeError, TypeError):
                    input_data = {{"query": query}}
                    try:
                        extracted = self._extract_structured_input(query)
                        if extracted:
                            input_data.update(extracted)
                    except Exception:
                        pass
            else:
                input_data = query if isinstance(query, dict) else {{"query": str(query)}}

            if context:
                input_data.update(context)

            # Execute via orchestration method (single code path — FORGE's core)
            result = await self.{orchestration_method}(input_data)
{agentic_block}
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={{
                    "answer": result,
                    "metadata": self.metadata,
                    "processing_time": datetime.now().isoformat()
                }}
            )

        except Exception as e:
            logger.error(f"{agent_name} processing failed: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e), "metadata": self.metadata}}
            )'''

        return query_parser + "\n" + process_method

    def _build_function_dispatch(self, func_names: List[str], indent: int = 12) -> str:
        """Build direct function dispatch code for generated functions.

        Replaces the old dir(self) scanning anti-pattern with explicit calls
        to the known generated functions.
        """
        pad = ' ' * indent
        lines = []
        for fname in func_names:
            lines.append(f'{pad}try:')
            lines.append(f'{pad}    if asyncio.iscoroutinefunction(self.{fname}):')
            lines.append(f'{pad}        results["{fname}"] = await self.{fname}(query)')
            lines.append(f'{pad}    else:')
            lines.append(f'{pad}        results["{fname}"] = self.{fname}(query)')
            lines.append(f'{pad}except Exception as _err:')
            lines.append(f'{pad}    logger.warning(f"Method {fname} failed: {{_err}}")')
        if not func_names:
            lines.append(f'{pad}pass  # No generated functions')
        return '\n'.join(lines)
    
    def _format_dict_as_python(self, d: Dict, indent: int = 4) -> str:
        """Format a dictionary as Python code with proper indentation and Python booleans"""
        def format_value(v, current_indent: int = 0):
            if isinstance(v, bool):
                return 'True' if v else 'False'
            elif isinstance(v, str):
                return f'"{v}"'
            elif isinstance(v, (int, float)):
                return str(v)
            elif isinstance(v, dict):
                if not v:
                    return '{}'
                lines = ['{']
                indent_str = ' ' * (current_indent + 4)
                for key, value in v.items():
                    formatted_value = format_value(value, current_indent + 4)
                    lines.append(f'{indent_str}"{key}": {formatted_value},')
                lines.append(' ' * current_indent + '}')
                return '\n'.join(lines)
            elif isinstance(v, list):
                return str(v)
            else:
                return str(v)
        
        return format_value(d, indent)
    
    def assemble_function(
        self,
        function_name: str,
        parameters: Dict[str, str],
        business_rules: List[str],
        return_type: str = "float",
        description: str = ""
    ) -> str:
        """
        Assemble standalone function code (Self-Growing mode).

        This generates a focused function instead of a full agent class,
        useful for benchmark evaluation and direct integration.

        Args:
            function_name: Name of the function to generate
            parameters: Dict of parameter names to their types
            business_rules: List of business rule expressions or function names
            return_type: Return type of the function
            description: Description of what the function does

        Returns:
            Generated Python function code
        """
        logger.info(f"Assembling function: {function_name}")
        logger.debug(f"Parameters: {parameters}")
        logger.debug(f"Business rules: {business_rules}")

        # Import FunctionGenerator from LogosAI
        try:
            from logosai.generation import FunctionGenerator
            generator = FunctionGenerator(use_type_hints=True)

            code = generator.generate_with_imports(
                function_name=function_name,
                parameters=parameters,
                business_rules=business_rules,
                return_type=return_type,
                docstring=description if description else None
            )

            logger.info(f"Function assembled successfully: {len(code)} characters")
            return code

        except ImportError as e:
            logger.warning(f"LogosAI FunctionGenerator not available: {e}")
            # Fallback: generate simple function inline
            return self._generate_simple_function(
                function_name, parameters, business_rules, return_type, description
            )

    def _generate_simple_function(
        self,
        function_name: str,
        parameters: Dict[str, str],
        business_rules: List[str],
        return_type: str,
        description: str
    ) -> str:
        """Fallback simple function generator"""
        # Build parameter string
        param_str = ", ".join(f"{name}: {typ}" for name, typ in parameters.items())

        # Build function body from business rules
        body_lines = []
        for rule in business_rules:
            rule = rule.strip()
            if rule:
                body_lines.append(f"    {rule}")

        # Add return if not present
        if not any("return " in line for line in body_lines):
            body_lines.append("    return result")

        body = "\n".join(body_lines)

        code = f'''from typing import Dict, List, Any, Optional

def {function_name}({param_str}) -> {return_type}:
    """
    {description if description else function_name}
    """
{body}
'''
        return code

    def _generate_sample_data(self, generated_functions: Dict[str, str], description: str) -> str:
        """Generate a test_query string appropriate for the agent's domain.

        Since process() now takes query: str, the test section needs a natural
        language query string instead of a data dictionary.
        """
        desc_lower = description.lower()
        all_code = '\n'.join(generated_functions.values())
        function_names = list(generated_functions.keys())

        # Determine best test query based on agent domain
        # Also check function names for domain hints
        func_names_lower = ' '.join(function_names).lower()
        search_text = f"{desc_lower} {func_names_lower}"

        if any(p in search_text for p in ['계산', 'calculator', 'arithmetic', 'math', 'compute',
                                           'calculation', '더하', '빼', '곱하', '나누',
                                           'add', 'subtract', 'multiply', 'divide',
                                           'calculate', 'operation']):
            # Check if function expects structured input (operation/operands pattern)
            if any(kw in all_code for kw in ['operation', 'operands']):
                test_query = json.dumps({"operation": "*", "operands": [125, 48]})
            else:
                test_query = "Calculate 125 * 48 + 372"
        elif any(p in desc_lower for p in ['날씨', 'weather', '온도', '기상']):
            test_query = "What is the weather forecast for Seoul today?"
        elif any(p in desc_lower for p in ['번역', 'translat']):
            test_query = "Translate 'Hello, how are you?' to Korean"
        elif any(p in desc_lower for p in ['감정', 'sentiment', '감성', '리뷰']):
            test_query = "Analyze sentiment: This product is amazing! I love the quality."
        elif any(p in desc_lower for p in ['요약', 'summar']):
            test_query = "Summarize the key points of artificial intelligence in education"
        elif any(p in desc_lower for p in ['csv', 'dataframe', '데이터 분석', 'data analy']):
            test_query = "Analyze the sales data and provide key statistics"
        elif any(p in desc_lower for p in ['api', '연동', 'webhook', 'endpoint']):
            test_query = "Fetch data from the user API endpoint"
        elif any(p in desc_lower for p in ['이미지', 'image', 'vision', '객체', '탐지']):
            test_query = "Detect objects in the provided image"
        elif any(p in desc_lower for p in ['재무', 'finance', 'financial', '투자']):
            test_query = "Analyze the Q1 2024 financial report"
        elif any(p in desc_lower for p in ['위험', 'risk', '리스크']):
            test_query = "Assess the risk factors for the new market entry"
        elif any(p in desc_lower for p in ['작성', 'writ', '이메일', 'email']):
            test_query = "Write a professional email to schedule a meeting"
        elif any(p in desc_lower for p in ['크롤', 'crawl', 'scrap', '웹']):
            test_query = "Crawl and extract data from https://example.com"
        elif any(p in desc_lower for p in ['모니터', 'monitor', '알림', 'alert']):
            test_query = "Check system health and report any anomalies"
        else:
            # Generic test query derived from description
            short_desc = description[:60].rstrip('.')
            test_query = f"Process the following request: {short_desc}"

        # Format as indented Python code for the test section
        # Use single quotes for JSON strings (contain double quotes), double quotes otherwise
        if test_query.startswith('{'):
            return f"\n        test_query = '{test_query}'"
        return f'\n        test_query = "{test_query}"'