"""
Lightweight Validator for V2 System
=====================================
AST 없이 빠른 코드 검증을 수행하는 경량 검증기
"""

import re
import ast
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from loguru import logger
import time


@dataclass
class ValidationResult:
    """검증 결과"""
    is_valid: bool
    errors: List[str] = None
    warnings: List[str] = None
    suggestions: List[str] = None
    performance_ms: float = 0.0
    
    def __post_init__(self):
        self.errors = self.errors or []
        self.warnings = self.warnings or []
        self.suggestions = self.suggestions or []


class LightweightValidator:
    """경량 코드 검증기 - AST 없이 빠른 검증"""
    
    def __init__(self):
        logger.info("Lightweight validator initialized")
        
        # 일반적인 구문 패턴
        self.patterns = {
            'missing_colon': re.compile(r'^\s*(if|for|while|def|class|try|except|with)\s+[^:]+$'),
            'unclosed_bracket': re.compile(r'[\[\({][^\]\)}]*$'),
            'unclosed_string': re.compile(r'["\'](?:[^"\'\\]|\\.)*$'),
            'invalid_indent': re.compile(r'^( {1,3}|\t| \t|\t )\S'),  # 1-3 spaces or mixed tabs
            'trailing_comma': re.compile(r',\s*[\]\)}]'),
            'double_operators': re.compile(r'(\+\+|--|\*\*\*|///|===)'),
            'missing_self': re.compile(r'def\s+\w+\([^)]*\)(?!.*self)'),  # instance method without self
        }
        
        # 필수 import 체크
        self.required_imports = {
            'LogosAIAgent': 'from logosai import LogosAIAgent',
            'AgentConfig': 'from logosai import AgentConfig',
            'logger': 'from loguru import logger',
            'asyncio': 'import asyncio',
            'Dict': 'from typing import Dict',
        }
        
        # 성능 메트릭
        self.validation_times = []
    
    def validate(self, code: str, context: Optional[Dict[str, Any]] = None) -> ValidationResult:
        """
        코드를 빠르게 검증 (AST 없이)
        
        Args:
            code: 검증할 Python 코드
            context: 추가 컨텍스트 (agent_name, requirements 등)
            
        Returns:
            ValidationResult: 검증 결과
        """
        start_time = time.time()
        result = ValidationResult(is_valid=True)
        
        try:
            # 1단계: 빠른 컴파일 체크
            if not self._quick_compile_check(code, result):
                result.is_valid = False
            
            # 2단계: 구문 패턴 체크
            self._check_syntax_patterns(code, result)
            
            # 3단계: 들여쓰기 체크
            self._check_indentation(code, result)
            
            # 4단계: 필수 구조 체크
            self._check_required_structure(code, result, context)
            
            # 5단계: Import 체크
            self._check_imports(code, result)
            
            # 6단계: 비즈니스 로직 체크
            self._check_business_logic(code, result, context)
            
        except Exception as e:
            logger.error(f"Validation error: {e}")
            result.is_valid = False
            result.errors.append(f"Validation failed: {str(e)}")
        
        # 성능 기록
        performance_ms = (time.time() - start_time) * 1000
        result.performance_ms = performance_ms
        self.validation_times.append(performance_ms)
        
        if performance_ms > 100:  # 100ms 이상이면 경고
            logger.warning(f"Validation took {performance_ms:.2f}ms - consider optimization")
        
        return result
    
    def _quick_compile_check(self, code: str, result: ValidationResult) -> bool:
        """빠른 컴파일 가능성 체크"""
        try:
            compile(code, '<validation>', 'exec')
            return True
        except SyntaxError as e:
            result.errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
            if e.text:
                result.errors.append(f"  Problem: {e.text.strip()}")
            
            # 일반적인 수정 제안
            if "invalid syntax" in str(e.msg):
                if ":" in str(e.text):
                    result.suggestions.append("Check for missing colons after if/for/def statements")
                else:
                    result.suggestions.append("Check for unclosed brackets or quotes")
            
            return False
        except Exception as e:
            result.errors.append(f"Compilation failed: {str(e)}")
            return False
    
    def _check_syntax_patterns(self, code: str, result: ValidationResult):
        """일반적인 구문 패턴 체크"""
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # 빈 줄은 스킵
            if not line.strip():
                continue
            
            # 누락된 콜론
            if self.patterns['missing_colon'].match(line):
                result.warnings.append(f"Line {i}: Missing colon after control statement")
                result.suggestions.append(f"Add ':' at the end of line {i}")
            
            # 닫히지 않은 괄호
            if self.patterns['unclosed_bracket'].match(line):
                open_count = line.count('(') + line.count('[') + line.count('{')
                close_count = line.count(')') + line.count(']') + line.count('}')
                if open_count != close_count:
                    result.warnings.append(f"Line {i}: Unclosed bracket detected")
            
            # 잘못된 연산자
            if self.patterns['double_operators'].search(line):
                result.warnings.append(f"Line {i}: Invalid operator pattern detected")
    
    def _check_indentation(self, code: str, result: ValidationResult):
        """들여쓰기 일관성 체크"""
        lines = code.split('\n')
        indent_type = None  # 'spaces' or 'tabs'
        indent_size = None
        
        for i, line in enumerate(lines, 1):
            if not line or not line[0].isspace():
                continue
            
            # 첫 들여쓰기 감지
            if indent_type is None:
                if line[0] == '\t':
                    indent_type = 'tabs'
                elif line[0] == ' ':
                    indent_type = 'spaces'
                    # 스페이스 개수 세기
                    spaces = len(line) - len(line.lstrip())
                    indent_size = spaces
            
            # 혼합된 들여쓰기 체크
            if self.patterns['invalid_indent'].match(line):
                result.warnings.append(f"Line {i}: Inconsistent indentation (mixed tabs/spaces)")
                result.suggestions.append("Use either tabs or spaces consistently (4 spaces recommended)")
    
    def _check_required_structure(self, code: str, result: ValidationResult, context: Optional[Dict]):
        """필수 구조 체크"""
        # 에이전트 클래스 존재 여부
        if context and 'agent_name' in context:
            agent_name = context['agent_name']
            if f"class {agent_name}" not in code:
                result.errors.append(f"Agent class '{agent_name}' not found")
                result.suggestions.append(f"Ensure class {agent_name}(LogosAIAgent) is defined")
        
        # process 메서드 존재 여부
        if "async def process" not in code:
            result.warnings.append("Required 'process' method not found")
            result.suggestions.append("Add async def process(self, query, context=None)")
        
        # __init__ 메서드 체크
        if "def __init__" not in code:
            result.warnings.append("__init__ method not found")
            result.suggestions.append("Add __init__ method with AgentConfig initialization")
        
        # main block 체크
        if '__name__ == "__main__"' in code:
            if "asyncio.run" not in code:
                result.warnings.append("Main block lacks asyncio.run()")
                result.suggestions.append("Use asyncio.run() to execute async test function")
    
    def _check_imports(self, code: str, result: ValidationResult):
        """필수 import 체크"""
        missing_imports = []
        
        for key, import_stmt in self.required_imports.items():
            if key not in code:
                # 해당 키워드가 사용되는지 체크
                if f"{key}(" in code or f" {key}" in code:
                    if import_stmt not in code:
                        missing_imports.append(import_stmt)
        
        if missing_imports:
            result.warnings.append("Missing required imports")
            for imp in missing_imports:
                result.suggestions.append(f"Add: {imp}")
    
    def _check_business_logic(self, code: str, result: ValidationResult, context: Optional[Dict]):
        """비즈니스 로직 완성도 체크"""
        # 빈 함수 체크
        if "pass" in code and "TODO" not in code:
            lines_with_pass = [i+1 for i, line in enumerate(code.split('\n')) if 'pass' in line]
            if lines_with_pass:
                result.warnings.append(f"Empty implementations found at lines: {lines_with_pass}")
                result.suggestions.append("Implement actual business logic instead of 'pass'")
        
        # Error handling 체크
        try_count = code.count("try:")
        except_count = code.count("except")
        if try_count < except_count / 2:  # try가 너무 적으면
            result.warnings.append("Limited error handling detected")
            result.suggestions.append("Consider adding try-except blocks for robust error handling")
        
        # Logging 체크
        if "logger" not in code:
            result.warnings.append("No logging found")
            result.suggestions.append("Add logging for debugging and monitoring")
    
    def get_performance_stats(self) -> Dict[str, float]:
        """성능 통계 반환"""
        if not self.validation_times:
            return {"avg_ms": 0, "min_ms": 0, "max_ms": 0}
        
        return {
            "avg_ms": sum(self.validation_times) / len(self.validation_times),
            "min_ms": min(self.validation_times),
            "max_ms": max(self.validation_times),
            "total_validations": len(self.validation_times)
        }
    
    def validate_and_suggest_fixes(self, code: str) -> Tuple[bool, str, ValidationResult]:
        """
        검증하고 가능한 경우 수정 제안
        
        Returns:
            Tuple[검증 성공 여부, 수정된 코드 (없으면 원본), 검증 결과]
        """
        result = self.validate(code)
        
        if result.is_valid:
            return True, code, result
        
        # 간단한 자동 수정 시도
        fixed_code = self._attempt_simple_fixes(code, result)
        
        # 수정 후 재검증
        if fixed_code != code:
            revalidation = self.validate(fixed_code)
            if revalidation.is_valid:
                logger.info("Code automatically fixed!")
                return True, fixed_code, revalidation
        
        return False, code, result
    
    def _attempt_simple_fixes(self, code: str, result: ValidationResult) -> str:
        """간단한 자동 수정 시도"""
        fixed = code
        
        # 누락된 콜론 추가
        if any("Missing colon" in w for w in result.warnings):
            lines = fixed.split('\n')
            for i, line in enumerate(lines):
                if self.patterns['missing_colon'].match(line):
                    lines[i] = line + ':'
            fixed = '\n'.join(lines)
        
        # 들여쓰기 정규화 (4 spaces)
        if any("indentation" in w.lower() for w in result.warnings):
            lines = fixed.split('\n')
            normalized = []
            for line in lines:
                if line and line[0] in ' \t':
                    # 탭을 4 스페이스로 변경
                    line = line.replace('\t', '    ')
                    # 1-3 스페이스를 4의 배수로 정규화
                    indent = len(line) - len(line.lstrip())
                    if indent % 4 != 0:
                        indent = ((indent // 4) + 1) * 4
                        line = ' ' * indent + line.lstrip()
                normalized.append(line)
            fixed = '\n'.join(normalized)
        
        return fixed


# 사용 예제
if __name__ == "__main__":
    validator = LightweightValidator()
    
    # 테스트 코드
    test_code = '''
from logosai import LogosAIAgent, AgentConfig
from loguru import logger

class TestAgent(LogosAIAgent):
    def __init__(self):
        config = AgentConfig(name="Test")
        super().__init__(config)
    
    async def process(self, query, context=None):
        return {"result": "success"}
'''
    
    result = validator.validate(test_code, {"agent_name": "TestAgent"})
    print(f"Valid: {result.is_valid}")
    print(f"Performance: {result.performance_ms:.2f}ms")
    if result.warnings:
        print(f"Warnings: {result.warnings}")
    if result.suggestions:
        print(f"Suggestions: {result.suggestions}")