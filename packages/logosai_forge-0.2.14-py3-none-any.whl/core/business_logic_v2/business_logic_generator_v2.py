"""
Business Logic Generator V2 - Template-based with LLM hybrid generation
"""

import asyncio
import json
import re
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from dataclasses import dataclass
from loguru import logger

# Import core components
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from template_system.base_templates import BaseTemplates, FunctionCategory
from template_system.generation_rules import GenerationRules
from ..llm_client import LLMClient

# Import the proper QueryAnalyzer and related classes
from .query_analyzer import QueryAnalyzer as ProperQueryAnalyzer
from .query_analyzer import FunctionSpec  # Use the proper FunctionSpec directly
from .function_generator import FunctionGenerator
from .workflow_orchestrator import WorkflowOrchestrator, Workflow, WorkflowStep, WorkflowStrategy
from .code_assembler import CodeAssembler

# Import agentic detection
AGENTIC_DETECTOR_AVAILABLE = False
AgenticDetector = None

# Try multiple import methods
try:
    # Method 1: Direct relative import
    from ...utils.agentic_detector import AgenticDetector
    AGENTIC_DETECTOR_AVAILABLE = True
    logger.info("✅ Agentic detector loaded successfully (relative import)")
except ImportError:
    try:
        # Method 2: Absolute path with sys.path modification
        import sys
        import os
        forge_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        if forge_dir not in sys.path:
            sys.path.insert(0, forge_dir)
        from utils.agentic_detector import AgenticDetector
        AGENTIC_DETECTOR_AVAILABLE = True
        logger.info("✅ Agentic detector loaded successfully (absolute path)")
    except ImportError:
        try:
            # Method 3: Direct file import using importlib
            import importlib.util
            from pathlib import Path
            detector_path = Path(__file__).parent.parent.parent / "utils" / "agentic_detector.py"
            if detector_path.exists():
                spec = importlib.util.spec_from_file_location("agentic_detector", detector_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                AgenticDetector = module.AgenticDetector
                AGENTIC_DETECTOR_AVAILABLE = True
                logger.info(f"✅ Agentic detector loaded successfully (direct import from {detector_path})")
            else:
                logger.warning(f"❌ Agentic detector file not found at: {detector_path}")
        except Exception as e:
            logger.warning(f"❌ Agentic detector not available: {e}")

# Log final status
if AGENTIC_DETECTOR_AVAILABLE:
    logger.info("🚀 Agentic AI detection system is ACTIVE")
else:
    logger.warning("⚠️ Agentic AI detection system is NOT available - will use standard LogosAIAgent")


def safe_get(obj: Any, key: str, default: Any = None) -> Any:
    """Safely get attribute from dict or dataclass"""
    if isinstance(obj, dict):
        return obj.get(key, default)
    else:
        return getattr(obj, key, default)


@dataclass
class SimpleFunctionSpec:
    """Specification for a function to generate (DEPRECATED - Use ProperFunctionSpec)"""
    name: str
    category: str
    purpose: str
    inputs: Dict[str, str]
    outputs: Dict[str, str]
    requirements: List[str]
    

@dataclass
class SimpleWorkflow:
    """Simple workflow specification (DEPRECATED - Use imported Workflow)"""
    steps: List[Dict[str, Any]]
    data_flow: Dict[str, Any]
    execution_order: List[str]
    parallel_groups: List[List[str]]


class SimpleQueryAnalyzer:
    """Analyzes natural language queries to extract requirements (DEPRECATED - Use ProperQueryAnalyzer)"""
    
    def __init__(self):
        self.llm_client = LLMClient()
        self.keyword_patterns = {
            "data_io": ["load", "read", "save", "fetch", "import", "export", "csv", "json", "database", "api"],
            "analysis": ["analyze", "calculate", "statistics", "pattern", "trend", "anomaly", "correlation"],
            "ml_ai": ["predict", "classify", "train", "model", "ai", "machine learning", "sentiment"],
            "visualization": ["chart", "plot", "graph", "visualize", "dashboard", "display"],
            "transformation": ["transform", "convert", "clean", "aggregate", "filter", "normalize"],
            "integration": ["send", "email", "webhook", "notify", "connect", "integrate", "api"]
        }
    
    async def analyze(self, query: str) -> Dict[str, Any]:
        """Analyze query to extract requirements"""
        
        # Extract operations from query
        operations = self._extract_operations(query)
        
        # Use LLM for detailed analysis
        prompt = f"""
        Analyze this query and extract the required functions:
        Query: {query}
        
        Return as JSON with this structure:
        {{
            "operations": ["list of operations needed"],
            "entities": ["data entities involved"],
            "requirements": ["specific requirements"],
            "workflow": "sequential or parallel or mixed"
        }}
        """
        
        try:
            response = await self.llm_client.generate(prompt)
            analysis = json.loads(response)
        except:
            # Fallback to keyword-based analysis
            analysis = {
                "operations": operations,
                "entities": self._extract_entities(query),
                "requirements": [],
                "workflow": "sequential"
            }
        
        return analysis
    
    def _extract_operations(self, query: str) -> List[str]:
        """Extract operations from query using keywords"""
        query_lower = query.lower()
        operations = []
        
        for category, keywords in self.keyword_patterns.items():
            if any(kw in query_lower for kw in keywords):
                operations.append(category)
        
        return operations
    
    def _extract_entities(self, query: str) -> List[str]:
        """Extract data entities from query"""
        entities = []
        entity_keywords = ["customer", "sales", "product", "inventory", "user", "order", "review"]
        
        query_lower = query.lower()
        for entity in entity_keywords:
            if entity in query_lower:
                entities.append(entity)
        
        return entities
    
    def identify_required_functions(self, analysis: Dict) -> List[SimpleFunctionSpec]:
        """Convert analysis to function specifications"""
        functions = []
        
        for operation in safe_get(analysis, "required_capabilities", []):
            spec = SimpleFunctionSpec(
                name=f"_{operation}_data",
                category=operation,
                purpose=f"Perform {operation} operation",
                inputs={"data": "Any"},
                outputs={"result": "Any"},
                requirements=safe_get(analysis, "required_capabilities", [])
            )
            functions.append(spec)
        
        return functions


class WorkflowDesigner:
    """Designs execution workflow from function specifications"""
    
    def create_workflow(self, functions: List[FunctionSpec], query_analysis: Dict) -> Workflow:
        """Create workflow from function specifications"""
        
        workflow_steps = []
        
        # Convert FunctionSpecs to WorkflowSteps
        for i, func in enumerate(functions):
            step = WorkflowStep(
                function_name=func.name,
                inputs=func.inputs if isinstance(func.inputs, dict) else {"data": "Any"},
                outputs=func.outputs if isinstance(func.outputs, list) else ["result"],
                dependencies=[functions[i-1].name] if i > 0 else [],
                condition=None
            )
            workflow_steps.append(step)
        
        # Determine strategy based on analysis
        strategy = self._determine_strategy(workflow_steps, query_analysis)
        
        return Workflow(
            steps=workflow_steps,
            strategy=strategy,
            error_handling="continue_on_error",  # For computer vision, we want to continue even if one step fails
            parallel_limit=3,
            timeout=300
        )
    
    def _determine_strategy(self, steps: List[WorkflowStep], query_analysis: Dict) -> WorkflowStrategy:
        """Determine the best workflow strategy based on steps and query"""
        
        # Check if steps have dependencies
        has_dependencies = any(step.dependencies for step in steps)
        
        # Check if query mentions batch or parallel processing
        query_lower = str(query_analysis).lower()
        wants_parallel = "parallel" in query_lower or "배치" in query_lower or "일괄" in query_lower
        
        # Determine strategy
        if wants_parallel and not has_dependencies:
            return WorkflowStrategy.PARALLEL
        elif has_dependencies:
            return WorkflowStrategy.PIPELINE
        else:
            return WorkflowStrategy.SEQUENTIAL
    
    def _identify_parallel_groups(self, steps: List[Dict]) -> List[List[str]]:
        """Identify functions that can run in parallel"""
        parallel_groups = []
        
        # Simple heuristic: functions with same dependencies can run in parallel
        dependency_groups = {}
        for step in steps:
            deps = tuple(step.get("depends_on", []))
            if deps not in dependency_groups:
                dependency_groups[deps] = []
            dependency_groups[deps].append(step["function"])
        
        for group in dependency_groups.values():
            if len(group) > 1:
                parallel_groups.append(group)
        
        return parallel_groups


class SimpleFunctionGenerator:
    """Generates functions using templates or LLM (DEPRECATED - Use imported FunctionGenerator)"""
    
    def __init__(self):
        self.llm_client = LLMClient()
        self.base_templates = BaseTemplates()
        self.generation_rules = GenerationRules()
    
    async def generate(self, spec: FunctionSpec) -> str:
        """Generate function from specification"""
        
        # Get base template and rules
        category = FunctionCategory[spec.category.upper()] if spec.category.upper() in FunctionCategory.__members__ else FunctionCategory.GENERAL
        template = self.base_templates.get_template(category)
        rules = self.generation_rules.get_rules(spec.category)
        
        # Create generation prompt
        prompt = self._create_generation_prompt(spec, template, rules)
        
        # Generate with LLM
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = await self.llm_client.generate(prompt)
                
                # Check if LLM call was successful
                if not response.success:
                    logger.warning(f"LLM generation failed: {response.error}")
                    continue
                
                generated_code = response.content
                
                # Extract code from markdown or explanatory text
                generated_code = self._extract_code_from_response(generated_code)
                
                # Validate generated code
                if self._validate_basic_structure(generated_code, spec.category):
                    return generated_code
                
                # If validation fails, create fix prompt
                prompt = self._create_fix_prompt(generated_code, spec)
                
            except Exception as e:
                logger.error(f"Generation attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    # Return fallback implementation
                    return self._create_fallback_implementation(spec)
        
        return self._create_fallback_implementation(spec)
    
    def _create_generation_prompt(self, spec: FunctionSpec, template: str, rules: Any) -> str:
        """Create detailed generation prompt"""
        
        rules_prompt = self.generation_rules.get_generation_prompt(spec.category) if rules else ""
        
        prompt = f"""
Generate a Python function with these specifications:

FUNCTION SPECIFICATION:
- Name: {spec.name}
- Purpose: {spec.purpose}
- Category: {spec.category}
- Inputs: {json.dumps(spec.inputs)}
- Outputs: {json.dumps(spec.outputs)}
- Requirements: {', '.join(spec.requirements)}

BASE TEMPLATE STRUCTURE TO FOLLOW:
{template[:500]}...  # Showing first 500 chars of template

{rules_prompt}

IMPORTANT INSTRUCTIONS:
1. Generate COMPLETE, WORKING implementation (no TODO, pass, or placeholders)
2. Include proper error handling with try-except blocks
3. Add logging statements for important operations
4. Use type hints for all parameters and returns
5. Include comprehensive docstring
6. Return structured data (Dict or Tuple) as specified
7. Handle edge cases gracefully

Generate the complete function code now:
"""
        
        return prompt
    
    def _extract_code_from_response(self, response: str) -> str:
        """Extract code from LLM response, removing markdown and explanatory text"""
        
        # Check if response contains markdown code blocks
        if "```python" in response or "```" in response:
            # Extract code from markdown blocks
            import re
            code_pattern = r'```(?:python)?\n(.*?)\n```'
            matches = re.findall(code_pattern, response, re.DOTALL)
            if matches:
                # Return the first complete code block
                return matches[0].strip()
        
        # Check if response starts with explanatory text
        lines = response.split('\n')
        code_lines = []
        in_code = False
        
        for line in lines:
            # Skip explanatory lines
            if line.strip().startswith('Here is') or line.strip().startswith('Here\'s'):
                continue
            if line.strip() == '' and not in_code:
                continue
                
            # Start collecting when we see import or def
            if re.match(r'^(import |from |async def |def |class )', line):
                in_code = True
            
            if in_code:
                code_lines.append(line)
        
        if code_lines:
            return '\n'.join(code_lines)
        
        # If no extraction worked, return original (may be clean already)
        return response.strip()
    
    def _validate_basic_structure(self, code: str, category: str) -> bool:
        """Validate basic structure of generated code"""
        
        # Check for forbidden patterns
        violations = self.generation_rules.check_forbidden_patterns(code, category)
        if violations:
            logger.warning(f"Validation failed: {violations}")
            return False
        
        # Check for function definition
        if not re.search(r'(async\s+)?def\s+_\w+\s*\(', code):
            logger.warning("No valid function definition found")
            return False
        
        # Check for docstring
        if '"""' not in code:
            logger.warning("No docstring found")
            return False
        
        # Check for return statement
        if 'return' not in code:
            logger.warning("No return statement found")
            return False
        
        return True
    
    def _create_fix_prompt(self, code: str, spec: FunctionSpec) -> str:
        """Create prompt to fix issues in generated code"""
        
        return f"""
The following generated code has issues. Please fix them:

ORIGINAL CODE:
{code}

ISSUES TO FIX:
1. Remove any TODO, pass, or placeholder statements
2. Ensure all error handling is complete
3. Add any missing implementations
4. Ensure function follows the naming pattern for {spec.category}
5. Make sure it returns the correct format

Please provide the complete, fixed function:
"""
    
    def _create_fallback_implementation(self, spec: FunctionSpec) -> str:
        """Create basic fallback implementation"""
        
        return f"""
async def {spec.name}(self, data: Any, options: Optional[Dict] = None) -> Dict[str, Any]:
    '''
    {spec.purpose}
    
    Args:
        data: Input data
        options: Optional configuration
    
    Returns:
        Dict with operation results
    '''
    result = {{
        "operation": "{spec.name}",
        "status": "not_implemented",
        "message": "This function needs to be implemented",
        "timestamp": datetime.now().isoformat()
    }}
    
    logger.warning(f"{{spec.name}} called but not fully implemented")
    
    # Basic structure for category: {spec.category}
    try:
        # Placeholder for actual implementation
        result["data"] = data
        result["status"] = "partial"
        
    except Exception as e:
        logger.error(f"Error in {{spec.name}}: {{e}}")
        result["error"] = str(e)
        result["status"] = "error"
    
    return result
"""


class SimpleWorkflowOrchestrator:
    """Orchestrates function execution flow (DEPRECATED - Use imported WorkflowOrchestrator)"""
    
    def generate_orchestration_code(self, workflow: Workflow, functions: Dict[str, str]) -> str:
        """Generate the main orchestration code"""
        
        # Build imports
        imports = set()
        for func_code in functions.values():
            if "asyncio" in func_code:
                imports.add("asyncio")
            if "pandas" in func_code:
                imports.add("pandas as pd")
            if "numpy" in func_code:
                imports.add("numpy as np")
        
        # Generate orchestration logic
        orchestration = '''
    async def _process_core_logic(self, extracted_info: Dict) -> Dict:
        """
        Core business logic orchestration
        
        Args:
            extracted_info: Input data and parameters
        
        Returns:
            Dict with processing results
        """
        result = {
            "status": "processing",
            "timestamp": datetime.now().isoformat(),
            "steps_completed": [],
            "data": {}
        }
        
        try:
'''
        
        # Add sequential steps
        for step in workflow.steps:
            func_name = step["function"]
            orchestration += f'''
            # Execute: {func_name}
            logger.info("Executing {{func_name}}")
            '''
            
            # Handle dependencies
            if step["depends_on"]:
                orchestration += f'''
            # Uses output from: {', '.join(step["depends_on"])}
            input_data = result["data"]["{step["depends_on"][0]}"] if "{step["depends_on"][0]}" in result["data"] else extracted_info
            '''
            else:
                orchestration += '''
            input_data = extracted_info
            '''
            
            orchestration += f'''
            step_result = await self.{func_name}(input_data)
            result["data"]["{func_name}"] = step_result
            result["steps_completed"].append("{func_name}")
            '''
        
        # Handle parallel execution if any
        if workflow.parallel_groups:
            orchestration += '''
            
            # Parallel execution for better performance
            '''
            for group in workflow.parallel_groups:
                orchestration += f'''
            parallel_tasks = [
                {', '.join(f'self.{func}(input_data)' for func in group)}
            ]
            parallel_results = await asyncio.gather(*parallel_tasks)
            '''
                for i, func in enumerate(group):
                    orchestration += f'''
            result["data"]["{func}"] = parallel_results[{i}]
            '''
        
        # Complete the orchestration
        orchestration += '''
            
            # Mark as complete
            result["status"] = "completed"
            result["success"] = True
            
            # Compile final output
            final_output = {
                "summary": self._generate_summary(result["data"]),
                "details": result["data"],
                "metadata": {
                    "steps_executed": len(result["steps_completed"]),
                    "timestamp": result["timestamp"]
                }
            }
            
            return final_output
            
        except Exception as e:
            logger.error(f"Processing failed: {e}")
            result["status"] = "error"
            result["error"] = str(e)
            return result

    def _generate_summary(self, data: Dict) -> Dict:
        """Generate summary from processed data"""
        summary = {
            "total_operations": len(data),
            "successful_operations": sum(1 for v in data.values() if isinstance(v, dict) and v.get("success", True))
        }
        return summary
'''
        
        return orchestration


class SimpleCodeAssembler:
    """Assembles final agent code (DEPRECATED - Use imported CodeAssembler)"""
    
    def assemble(self, agent_name: str, description: str, functions: Dict[str, str], 
                 orchestration: str, category: FunctionCategory = FunctionCategory.GENERAL,
                 use_enhanced_agent: bool = False, agentic_config: Dict[str, Any] = None) -> str:
        """Assemble complete agent code"""
        
        # Get imports
        imports = BaseTemplates.get_imports_for_category(category)
        imports_str = '\n'.join(imports)
        
        # Add LogosAI imports based on agentic detection
        if use_enhanced_agent:
            logos_imports = '''
from logosai.agent_enhanced import EnhancedLogosAIAgent
from logosai import AgentConfig, AgentType, AgentResponse, AgentResponseType
'''
            base_class = 'EnhancedLogosAIAgent'
        else:
            logos_imports = '''
from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType
'''
            base_class = 'LogosAIAgent'
        
        # Build class
        class_code = f'''
class {agent_name}({base_class}):
    """
    {description}
    
    This agent was generated by Forge AI Business Logic Generator V2
    """
    
    def __init__(self):
        config = AgentConfig(
            name="{agent_name}",
            description="{description}",
            agent_type=AgentType.CUSTOM,
            version="1.0.0"
        )
        super().__init__(config)
        logger.info(f"Initialized {{self.config.name}}")
'''
        
        # Combine all functions with proper indentation
        indented_functions = []
        for func_code in functions.values():
            # Add 4 spaces indentation to each line
            lines = func_code.split('\n')
            indented_lines = []
            for line in lines:
                if line.strip():  # Non-empty lines
                    indented_lines.append('    ' + line)
                else:  # Empty lines
                    indented_lines.append('')
            indented_functions.append('\n'.join(indented_lines))
        
        all_functions = '\n\n'.join(indented_functions)
        
        # Main process method
        main_process = '''
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Main entry point for agent processing"""
        try:
            # Parse input
            if isinstance(query, str):
                try:
                    extracted_info = json.loads(query)
                except json.JSONDecodeError:
                    extracted_info = {"query": query}
            else:
                extracted_info = query
            
            # Add context if provided
            if context:
                extracted_info.update(context)
            
            # Execute core logic
            result = await self._process_core_logic(extracted_info)
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result
            )
            
        except Exception as e:
            logger.error(f"Processing failed: {e}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={"error": str(e)}
            )
'''
        
        # Test code
        test_code = '''
# Test the agent
if __name__ == "__main__":
    async def test():
        agent = ''' + agent_name + '''()
        
        test_input = {
            "data": "test data",
            "operation": "test"
        }
        
        result = await agent.process(json.dumps(test_input))
        print(f"Result: {result}")
    
    asyncio.run(test())
'''
        
        # Assemble complete code
        complete_code = f'''
{imports_str}

{logos_imports}

{class_code}

{all_functions}

{orchestration}

{main_process}

{test_code}
'''
        
        return complete_code


class BusinessLogicGeneratorV2:
    """Main business logic generator with template and LLM hybrid approach"""
    
    def __init__(self):
        self.query_analyzer = ProperQueryAnalyzer()
        self.workflow_designer = WorkflowDesigner()
        self.function_generator = FunctionGenerator()
        self.orchestrator = WorkflowOrchestrator()
        self.assembler = CodeAssembler()
        
        logger.info("Business Logic Generator V2 initialized")
    
    def _preprocess_korean_query(self, query: str) -> str:
        """Preprocess Korean complex queries for better understanding"""
        
        # Korean to English capability mappings for better understanding
        korean_mappings = {
            "웹사이트와 데이터베이스를 스캔": "scan website and database",
            "개인정보 수집 현황": "personal data collection status",
            "준수 여부를 체크": "check compliance",
            "처리방침 검토": "review privacy policy",
            "개선 방안을 제안": "suggest improvements",
            "컴플라이언스 에이전트": "compliance agent",
            "프라이버시 컴플라이언스": "privacy compliance",
            "설계해주세요": "design",
            "만들어주세요": "create",
            "생성해주세요": "generate",
            "분석해주세요": "analyze",
            "처리해주세요": "process",
            # Social listening terms
            "브랜드 키워드를 모니터링": "monitor brand keywords",
            "감정 분석": "sentiment analysis",
            "영향력 측정": "influence measurement",
            "위기 상황 조기 탐지": "early crisis detection",
            "자동 알림": "automatic alerts",
            "경쟁사 분석": "competitor analysis",
            "트렌드 예측": "trend prediction",
            "소셜 리스닝": "social listening",
            "소셜 미디어": "social media"
        }
        
        # Preserve original query but add English hints for better understanding
        enhanced_query = query
        for korean, english in korean_mappings.items():
            if korean in query:
                # Add English translation as a hint without removing Korean
                enhanced_query = enhanced_query.replace(korean, f"{korean} ({english})")
                logger.info(f"Enhanced Korean term: {korean} -> {korean} ({english})")
        
        return enhanced_query
    
    async def generate(self, query: str, agent_name: str = "GeneratedAgent",
                      description: str = "Auto-generated agent",
                      stream_callback: Optional[callable] = None,
                      business_rules: Optional[List[str]] = None,
                      input_schema: Optional[Dict[str, str]] = None,
                      gap_context: Optional[List[Dict[str, Any]]] = None,
                      test_cases: Optional[List[Dict]] = None) -> str:
        """Generate complete agent code from query

        Args:
            query: User query for agent generation
            agent_name: Name for the generated agent
            description: Description for the agent
            stream_callback: Optional async callback for streaming progress
                             Signature: async def callback(stage: str, message: str, data: Dict)
            business_rules: Optional list of explicit business rules (e.g., ["base_probability = 0.10", "probability += factor * 0.15"])
            input_schema: Optional dict of expected input field names and types (e.g., {"months_inactive": "int", "usage_decline_pct": "float"})
            gap_context: Optional list of gap info dicts from Self-Growing pre-generation
                         Each dict has: name, description, best_match_score, is_gap
            test_cases: Optional list of test case dicts for guiding function generation
                        Each dict has: input, expected, tolerance

        Returns:
            Generated agent code as string
        """

        async def emit(stage: str, message: str, data: Dict = None):
            """Helper to emit streaming events"""
            if stream_callback:
                try:
                    await stream_callback(stage, message, data or {})
                except Exception as e:
                    logger.warning(f"Stream callback error: {e}")

        try:
            logger.info(f"Starting generation for query: {query[:100]}...")
            
            # 🎨 Step 0: Emit start event
            await emit("generation_start", "🚀 코드 생성 파이프라인 시작", {
                "query": query[:100],
                "agent_name": agent_name,
                "total_steps": 6
            })

            # Preprocess Korean queries for better understanding
            enhanced_query = self._preprocess_korean_query(query)
            if enhanced_query != query:
                logger.info(f"Enhanced query: {enhanced_query[:200]}...")
                await emit("query_enhanced", "🌐 한국어 쿼리 전처리 완료", {
                    "original": query[:100],
                    "enhanced": enhanced_query[:150]
                })

            # 0. Detect if agentic features are needed
            use_enhanced_agent = False
            agentic_config = None
            logger.info(f"AGENTIC_DETECTOR_AVAILABLE: {AGENTIC_DETECTOR_AVAILABLE}")
            if AGENTIC_DETECTOR_AVAILABLE:
                logger.info(f"🔍 Running agentic detection for query: {query[:100]}...")
                await emit("agentic_detection", "🔍 Agentic AI 기능 탐지 중...", {"status": "detecting"})

                agentic_info = AgenticDetector.detect_agentic_requirements(query, [])
                use_enhanced_agent = agentic_info["needs_agentic"]
                agentic_config = agentic_info["recommended_config"]
                logger.info(f"📊 Agentic detection result: needs_agentic={use_enhanced_agent}, confidence={agentic_info['confidence']:.2f}")

                await emit("agentic_detection_result", "📊 Agentic 탐지 완료", {
                    "needs_agentic": use_enhanced_agent,
                    "confidence": agentic_info['confidence'],
                    "detected_features": agentic_info.get('detected_features', []),
                    "base_class": "EnhancedLogosAIAgent" if use_enhanced_agent else "LogosAIAgent"
                })

                if use_enhanced_agent:
                    logger.info(f"✅ Agentic AI features DETECTED with confidence: {agentic_info['confidence']:.2f}")
                    logger.info(f"🎯 Detected features: {agentic_info['detected_features']}")
                    logger.info(f"🚀 Will use EnhancedLogosAIAgent as base class")
                    logger.info(f"⚙️ Agentic config: {agentic_config}")
                else:
                    logger.info(f"ℹ️ No agentic features needed for this query (confidence: {agentic_info['confidence']:.2f})")
            else:
                logger.warning("⚠️ Agentic detector not available, using standard LogosAIAgent")
                await emit("agentic_detection_skip", "⚠️ Agentic 탐지기 사용 불가, 표준 LogosAIAgent 사용", {})
            
            # ============================================================
            # 🎯 점진적 코드 성장 스트리밍 (Progressive Code Growth)
            # 각 단계마다 누적된 코드 상태를 전송하여 코드가 "성장"하는 모습을 보여줌
            # ============================================================

            # 누적 코드 상태를 추적하는 변수
            cumulative_code = {
                "imports": "",
                "class_header": "",
                "init_method": "",
                "functions": {},
                "orchestration": "",
                "main_method": "",
                "test_code": ""
            }

            def build_current_code() -> str:
                """현재까지 누적된 코드를 조립"""
                parts = []
                if cumulative_code["imports"]:
                    parts.append(cumulative_code["imports"])
                if cumulative_code["class_header"]:
                    parts.append(cumulative_code["class_header"])
                if cumulative_code["init_method"]:
                    parts.append(cumulative_code["init_method"])
                for fname, fcode in cumulative_code["functions"].items():
                    if fcode:
                        parts.append(fcode)
                if cumulative_code["orchestration"]:
                    parts.append(cumulative_code["orchestration"])
                if cumulative_code["main_method"]:
                    parts.append(cumulative_code["main_method"])
                if cumulative_code["test_code"]:
                    parts.append(cumulative_code["test_code"])
                return "\n\n".join(parts)

            # 1. Analyze query
            logger.info("Analyzing query...")
            await emit("query_analysis_start", "🧠 Step 1/6: 쿼리 분석 시작...", {"step": 1, "total_steps": 6})
            analysis = await self.query_analyzer.analyze(enhanced_query)
            # Safely extract analysis data for streaming (QueryAnalysis is a dataclass)
            entities_data = safe_get(analysis, "entities", {})
            entities_preview = list(entities_data.keys())[:5] if isinstance(entities_data, dict) else entities_data[:5] if isinstance(entities_data, list) else []

            # 🎯 Step 1 완료: 기본 구조(스켈레톤) 생성
            cumulative_code["imports"] = f'''"""
AI Agent: {agent_name}
Generated by: FORGE AI Business Logic Generator V2
Date: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Query: {query[:80]}...
"""

import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from loguru import logger
from logosai import LogosAIAgent
from logosai.config import AgentConfig
from logosai.agent_types import AgentType, AgentResponse, AgentResponseType'''

            cumulative_code["class_header"] = f'''
class {agent_name}(LogosAIAgent):
    """
    {description[:200]}

    Auto-generated agent with the following capabilities:
    - [분석 중...]
    """'''

            cumulative_code["init_method"] = f'''
    def __init__(self):
        config = AgentConfig(
            name="{agent_name}",
            description="{description[:100]}",
            agent_type=AgentType.CUSTOM,
            config={{}}  # 추후 설정 예정
        )
        super().__init__(config)
        logger.info(f"Initialized {{self.config.name}}")

        # TODO: 함수 식별 후 초기화 코드 추가 예정'''

            await emit("query_analysis_complete", "✅ 쿼리 분석 완료 - 기본 구조 생성됨", {
                "step": 1,
                "analysis_result": {
                    "operations": safe_get(analysis, "required_capabilities", [])[:5],
                    "entities": entities_preview,
                    "requirements": safe_get(analysis, "required_capabilities", [])[:3],
                    "workflow_type": "sequential",
                    "keywords": safe_get(analysis, "keywords", [])[:5],
                    "complexity": safe_get(analysis, "complexity_score", 0.5)
                },
                "cumulative_code": build_current_code(),
                "code_sections_added": ["imports", "class_header", "init_method"],
                "code_growth_stage": "skeleton"
            })

            # 2. Identify required functions
            logger.info("Identifying required functions...")
            await emit("function_identification_start", "🔍 Step 2/6: 필요 함수 식별 중...", {"step": 2})

            # 🎯 Format business rules as a string for the LLM prompt
            formatted_business_rules = None
            if business_rules:
                formatted_business_rules = "\n".join(business_rules)
                logger.info(f"📋 Using explicit business rules ({len(business_rules)} rules)")

            function_specs = self.query_analyzer.identify_required_functions(
                analysis,
                explicit_business_rules=formatted_business_rules,
                input_schema=input_schema
            )

            # 🎯 Inject test_cases into FunctionSpecs for LLM generation guidance
            if test_cases:
                for spec in function_specs:
                    spec.test_cases = test_cases
                logger.info(f"📋 Injected {len(test_cases)} test cases into {len(function_specs)} FunctionSpecs")

                # 🎯 Extract output key names from test_cases to correct FunctionSpec.outputs
                # This tells the LLM what KEY NAMES to return (not values)
                first_expected = test_cases[0].get('expected', {})
                if isinstance(first_expected, dict) and first_expected:
                    expected_keys = list(first_expected.keys())
                    for spec in function_specs:
                        spec.outputs = expected_keys
                    logger.info(f"📋 Updated FunctionSpec outputs to match expected keys: {expected_keys}")

            if not function_specs:
                logger.warning("No functions identified, creating query-driven function spec")

                # Derive function name from query
                import re as _re
                func_name = "_process_data"
                # Try to extract a meaningful name: "calculates BMI" → "_calculate_bmi"
                calc_match = _re.search(r'(?:calculate|compute|assess|evaluate|analyze|predict|determine|estimate)\w*\s+(\w[\w\s]{0,30}?)(?:\.|,|\s+and\s|\s+based|\s+from|\s+with)', enhanced_query.lower())
                if calc_match:
                    raw = calc_match.group(1).strip().replace(' ', '_')
                    verb = _re.match(r'(calculate|compute|assess|evaluate|analyze|predict|determine|estimate)', enhanced_query.lower())
                    verb_str = verb.group(1) if verb else "calculate"
                    func_name = f"_{verb_str}_{raw}"
                    func_name = _re.sub(r'[^a-z0-9_]', '', func_name)

                # Use input_schema if available, or derive from test_cases
                inputs_to_use = input_schema if input_schema else {"data": "Any"}
                if not input_schema and test_cases:
                    first_input = test_cases[0].get('input', {})
                    if isinstance(first_input, dict):
                        inputs_to_use = {k: type(v).__name__ for k, v in first_input.items()}

                # Derive outputs from test_cases
                outputs_list = ["result"]
                if test_cases:
                    first_expected = test_cases[0].get('expected', {})
                    if isinstance(first_expected, dict):
                        outputs_list = list(first_expected.keys())

                function_specs = [
                    FunctionSpec(
                        name=func_name,
                        category="custom",
                        description=enhanced_query[:200],
                        inputs=inputs_to_use,
                        outputs=outputs_list,
                        template_id=None,
                        customizations=None,
                        business_rules=enhanced_query
                    )
                ]
                logger.info(f"📋 Created query-driven spec: {func_name} inputs={list(inputs_to_use.keys())} outputs={outputs_list}")

            # 🎯 Step 2 완료: 함수 시그니처(스텁) 추가 - 코드가 성장함!
            # 클래스 docstring 업데이트
            capabilities_list = "\n    ".join([f"- {spec.name}: {getattr(spec, 'description', getattr(spec, 'purpose', 'N/A'))[:50]}" for spec in function_specs[:5]])
            cumulative_code["class_header"] = f'''
class {agent_name}(LogosAIAgent):
    """
    {description[:200]}

    Auto-generated agent with the following capabilities:
    {capabilities_list}
    """'''

            # 함수 스텁(시그니처만) 추가
            for spec in function_specs:
                func_desc = getattr(spec, 'description', getattr(spec, 'purpose', 'N/A'))[:80]
                cumulative_code["functions"][spec.name] = f'''
    async def {spec.name}(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        {func_desc}
        Category: {spec.category}

        Args:
            data: Input data dictionary

        Returns:
            Dict containing processed results
        """
        # TODO: 함수 본문 생성 중... (Step 4에서 완성)
        raise NotImplementedError("Function body will be generated in Step 4")'''

            await emit("function_identification_complete", "✅ 필요 함수 식별 완료 - 함수 시그니처 추가됨", {
                "step": 2,
                "function_count": len(function_specs),
                "functions": [
                    {
                        "name": spec.name,
                        "category": spec.category,
                        "description": getattr(spec, 'description', getattr(spec, 'purpose', 'N/A'))[:100]
                    }
                    for spec in function_specs[:5]
                ],
                "cumulative_code": build_current_code(),
                "code_sections_added": ["function_stubs"],
                "code_growth_stage": "function_signatures",
                "diff_hint": {
                    "type": "additions",
                    "sections": [spec.name for spec in function_specs]
                }
            })
            
            # 3. Create workflow
            logger.info("Creating workflow...")
            await emit("workflow_design_start", "📋 Step 3/6: 워크플로우 설계 중...", {"step": 3})
            workflow = self.workflow_designer.create_workflow(function_specs, analysis)

            # 🎯 Step 3 완료: 워크플로우 실행 메서드 스텁 추가
            strategy_name = str(workflow.strategy.value) if hasattr(workflow.strategy, 'value') else str(workflow.strategy)
            workflow_steps = "\n        ".join([f"# Step {i+1}: {step.function_name} (deps: {step.dependencies})" for i, step in enumerate(workflow.steps[:5])])

            cumulative_code["orchestration"] = f'''
    async def execute_workflow(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the workflow with strategy: {strategy_name}

        Workflow Steps:
        {workflow_steps}
        """
        results = {{}}
        errors = []

        # TODO: 오케스트레이션 로직 생성 중... (Step 5에서 완성)
        logger.info("Executing workflow with {len(workflow.steps)} steps")

        return {{"status": "pending", "message": "Orchestration will be generated in Step 5"}}'''

            await emit("workflow_design_complete", "✅ 워크플로우 설계 완료 - 실행 메서드 추가됨", {
                "step": 3,
                "workflow": {
                    "strategy": strategy_name,
                    "step_count": len(workflow.steps),
                    "steps": [
                        {"name": step.function_name, "dependencies": step.dependencies[:2]}
                        for step in workflow.steps[:5]
                    ]
                },
                "cumulative_code": build_current_code(),
                "code_sections_added": ["orchestration_stub"],
                "code_growth_stage": "workflow_skeleton",
                "diff_hint": {
                    "type": "additions",
                    "sections": ["execute_workflow"]
                }
            })

            # 4. Generate functions - 🎯 각 함수마다 스텁이 실제 코드로 교체됨!
            logger.info(f"Generating {len(function_specs)} functions...")
            await emit("function_generation_start", f"⚡ Step 4/6: {len(function_specs)}개 함수 생성 시작...", {
                "step": 4,
                "total_functions": len(function_specs),
                "cumulative_code": build_current_code(),
                "code_growth_stage": "function_generation_start"
            })
            generated_functions = {}
            for i, spec in enumerate(function_specs):
                logger.info(f"Generating function: {spec.name}")
                await emit("function_generating", f"🔧 함수 생성 중: {spec.name} ({i+1}/{len(function_specs)})", {
                    "function_index": i + 1,
                    "function_name": spec.name,
                    "function_category": spec.category,
                    "previous_code": cumulative_code["functions"].get(spec.name, "")[:200],
                    "message": f"스텁 코드를 실제 구현으로 교체 중..."
                })

                func_code = await self.function_generator.generate(spec, context={"gap_context": gap_context} if gap_context else None)
                generated_functions[spec.name] = func_code

                # 🎯 핵심: 스텁을 실제 생성된 코드로 교체!
                # 함수 코드를 클래스 메서드 형태로 변환 (인덴트 추가)
                indented_func_code = func_code
                if not func_code.strip().startswith("async def") and not func_code.strip().startswith("def"):
                    # 이미 메서드 형태가 아니면 래핑
                    indented_func_code = f"    {func_code}"
                elif not func_code.startswith("    "):
                    # 인덴트가 없으면 추가
                    indented_func_code = "\n".join(["    " + line if line.strip() else line for line in func_code.split("\n")])

                # 누적 코드에서 해당 함수 업데이트
                cumulative_code["functions"][spec.name] = indented_func_code

                # 생성된 코드 미리보기 스트리밍 + 전체 누적 코드
                code_preview = func_code[:500] if len(func_code) > 500 else func_code
                await emit("function_generated", f"✅ 함수 생성 완료: {spec.name} ({i+1}/{len(function_specs)})", {
                    "function_name": spec.name,
                    "function_index": i + 1,
                    "total_functions": len(function_specs),
                    "code_preview": code_preview,
                    "code_length": len(func_code),
                    "cumulative_code": build_current_code(),
                    "code_growth_stage": f"function_{i+1}_of_{len(function_specs)}",
                    "diff_hint": {
                        "type": "replacement",
                        "section": spec.name,
                        "old_marker": "# TODO: 함수 본문 생성 중",
                        "description": f"{spec.name} 스텁이 실제 구현으로 교체됨"
                    }
                })
            
            # 5. Generate orchestration - 🎯 워크플로우 스텁이 실제 로직으로 교체됨!
            logger.info("Generating orchestration code...")
            await emit("orchestration_start", "🔗 Step 5/6: 오케스트레이션 코드 생성 중...", {
                "step": 5,
                "previous_orchestration": cumulative_code["orchestration"][:300],
                "message": "워크플로우 스텁을 실제 오케스트레이션 로직으로 교체 중..."
            })

            orchestration = self.orchestrator.generate_orchestration_code(workflow, generated_functions)

            # 🎯 핵심: 오케스트레이션 스텁을 실제 코드로 교체!
            # 인덴트 처리
            indented_orchestration = orchestration
            if not orchestration.strip().startswith("async def") and not orchestration.strip().startswith("def"):
                indented_orchestration = f"    {orchestration}"
            elif not orchestration.startswith("    "):
                indented_orchestration = "\n".join(["    " + line if line.strip() else line for line in orchestration.split("\n")])

            cumulative_code["orchestration"] = indented_orchestration

            orchestration_preview = orchestration[:600] if len(orchestration) > 600 else orchestration
            await emit("orchestration_complete", "✅ 오케스트레이션 코드 생성 완료 - 워크플로우 로직 교체됨", {
                "step": 5,
                "orchestration_preview": orchestration_preview,
                "orchestration_length": len(orchestration),
                "cumulative_code": build_current_code(),
                "code_growth_stage": "orchestration_complete",
                "diff_hint": {
                    "type": "replacement",
                    "section": "execute_workflow",
                    "old_marker": "# TODO: 오케스트레이션 로직 생성 중",
                    "description": "워크플로우 실행 로직이 실제 구현으로 교체됨"
                }
            })

            # 6. Assemble final code - 🎯 main 메서드와 테스트 코드 추가!
            logger.info("Assembling final code...")
            await emit("code_assembly_start", "🏗️ Step 6/6: 최종 코드 조립 중...", {
                "step": 6,
                "cumulative_code": build_current_code(),
                "message": "main 메서드, 테스트 코드, 최종 정리 진행 중..."
            })

            # Clean generated functions before assembly
            # Only remove TOP-LEVEL imports (no indentation).
            # Preserve INDENTED imports inside function bodies (e.g. "    import string").
            cleaned_functions = {}
            for name, code in generated_functions.items():
                lines = code.split('\n')
                cleaned_lines = []
                for line in lines:
                    stripped = line.lstrip()
                    is_import = stripped.startswith(('import ', 'from '))
                    is_top_level = (len(line) == len(stripped))  # no indentation
                    if is_import and is_top_level:
                        logger.info(f"Removing top-level import from {name}: {line.strip()}")
                    else:
                        cleaned_lines.append(line)
                while cleaned_lines and not cleaned_lines[0].strip():
                    cleaned_lines.pop(0)
                cleaned_functions[name] = '\n'.join(cleaned_lines)

            # Determine primary category
            if function_specs:
                primary_category = FunctionCategory[function_specs[0].category.upper()] \
                    if function_specs[0].category.upper() in FunctionCategory.__members__ \
                    else FunctionCategory.GENERAL
            else:
                primary_category = FunctionCategory.GENERAL

            # 🎯 Step 6-1: process 메서드 추가
            cumulative_code["main_method"] = f'''
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Main entry point for the agent"""
        try:
            logger.info(f"Processing query: {{query[:50]}}...")

            # Parse input
            if isinstance(query, str):
                try:
                    input_data = json.loads(query)
                except json.JSONDecodeError:
                    input_data = {{"query": query}}
            else:
                input_data = query

            # Execute workflow
            result = await self.execute_workflow(input_data)

            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result,
                message="Processing completed successfully"
            )
        except Exception as e:
            logger.error(f"Error in process: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}},
                message=f"Error: {{str(e)}}"
            )'''

            await emit("code_assembly_progress", "📝 process 메서드 추가됨", {
                "sub_step": "process_method",
                "cumulative_code": build_current_code(),
                "code_growth_stage": "process_method_added"
            })

            # 🎯 Step 6-2: 테스트 코드 추가
            cumulative_code["test_code"] = f'''

if __name__ == "__main__":
    async def test():
        """Test the generated agent"""
        agent = {agent_name}()
        print(f"Testing {{agent.config.name}}...")

        # Test with sample input
        test_input = {{"test": "data", "value": 42}}
        result = await agent.process(json.dumps(test_input))
        print(f"Result: {{result}}")

    asyncio.run(test())'''

            await emit("code_assembly_progress", "🧪 테스트 코드 추가됨", {
                "sub_step": "test_code",
                "cumulative_code": build_current_code(),
                "code_growth_stage": "test_code_added"
            })

            # Pass agentic detection results to assembler for final polish
            final_code = self.assembler.assemble(
                agent_name,
                description or query[:100],
                cleaned_functions,
                orchestration,
                use_enhanced_agent=use_enhanced_agent,
                agentic_config=agentic_config
            )

            logger.info("Generation completed successfully")

            # 🎯 최종 완성된 코드 전송
            await emit("code_assembly_complete", "✅ 최종 코드 조립 완료!", {
                "step": 6,
                "agent_name": agent_name,
                "final_code": final_code,
                "cumulative_code": build_current_code(),  # 점진적으로 성장한 코드
                "total_lines": len(final_code.split('\n')),
                "total_chars": len(final_code),
                "code_growth_stage": "final",
                "growth_summary": {
                    "step_1": "skeleton (imports, class, init)",
                    "step_2": "function_signatures (스텁 추가)",
                    "step_3": "workflow_skeleton (execute_workflow 스텁)",
                    "step_4": "function_implementations (각 함수 실제 구현)",
                    "step_5": "orchestration (워크플로우 로직)",
                    "step_6": "final (process, test code)"
                }
            })

            await emit("generation_complete", "🎉 에이전트 코드 생성 완료!", {
                "agent_name": agent_name,
                "success": True,
                "total_functions": len(generated_functions),
                "code_length": len(final_code),
                "final_code": final_code
            })

            return final_code
            
        except Exception as e:
            logger.error(f"Generation failed: {e}")
            # Return minimal working agent
            return self._create_minimal_agent(agent_name, description, str(e))
    
    def _create_minimal_agent(self, agent_name: str, description: str, error: str) -> str:
        """Create minimal working agent when generation fails"""
        
        return f'''
import asyncio
import json
from typing import Dict, Any, Optional
from datetime import datetime
from loguru import logger
from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType

# Note: Using basic LogosAIAgent. For advanced features, consider using EnhancedLogosAIAgent
class {agent_name}(LogosAIAgent):
    """
    {description}
    
    Note: Generation partially failed - {error}
    """
    
    def __init__(self):
        config = AgentConfig(
            name="{agent_name}",
            description="{description}",
            agent_type=AgentType.CUSTOM,
            version="1.0.0"
        )
        super().__init__(config)
        logger.info(f"Initialized {{self.config.name}}")
    
    async def _process_core_logic(self, extracted_info: Dict) -> Dict:
        """Basic processing logic"""
        return {{
            "status": "partial_implementation",
            "message": "Agent needs further implementation",
            "input": extracted_info,
            "timestamp": datetime.now().isoformat()
        }}
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """Main entry point"""
        try:
            if isinstance(query, str):
                try:
                    extracted_info = json.loads(query)
                except:
                    extracted_info = {{"query": query}}
            else:
                extracted_info = query
            
            result = await self._process_core_logic(extracted_info)
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result
            )
        except Exception as e:
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}}
            )

if __name__ == "__main__":
    async def test():
        agent = {agent_name}()
        result = await agent.process('{{"test": "data"}}')
        print(f"Result: {{result}}")
    
    asyncio.run(test())
'''