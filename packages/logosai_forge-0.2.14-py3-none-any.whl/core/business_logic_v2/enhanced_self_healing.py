"""
Enhanced Self-Healing Module with AST-based Fixes
==================================================
AST를 활용한 강력한 코드 자동 수정 시스템
"""

import ast
import re
import astor  # AST를 코드로 변환
from typing import Dict, List, Tuple, Optional, Any
from loguru import logger
from dataclasses import dataclass, field


@dataclass
class HealingResult:
    """치유 결과"""
    success: bool
    original_code: str
    healed_code: str
    fixes_applied: List[str]
    confidence: float  # 0.0 - 1.0
    error_details: Optional[str] = None
    suggestions: List[str] = field(default_factory=list)


class EnhancedSelfHealingModule:
    """AST 기반 강화된 자가 치유 모듈"""
    
    def __init__(self):
        logger.info("Enhanced Self-Healing Module initialized with AST support")
        
        # 규칙 기반 수정 (빠른 수정용)
        self.quick_healing_rules = {
            'indentation': self._fix_indentation,
            'missing_colons': self._fix_missing_colons,
            'unclosed_brackets': self._fix_unclosed_brackets,
            'string_quotes': self._fix_string_quotes,
            'trailing_whitespace': self._fix_trailing_whitespace,
        }
        
        # AST 기반 수정 (정교한 수정용)
        self.ast_healing_rules = {
            'incomplete_functions': self._fix_incomplete_functions,
            'missing_self': self._fix_missing_self,
            'incorrect_returns': self._fix_incorrect_returns,
            'orphan_code': self._fix_orphan_code,
            'async_issues': self._fix_async_issues,
            'missing_imports': self._fix_missing_imports,
            'type_errors': self._fix_type_errors,
        }
        
        # 통계
        self.stats = {
            'total_attempts': 0,
            'successful_heals': 0,
            'failed_heals': 0,
            'fixes_by_type': {},
            'avg_confidence': 0.0
        }
    
    def heal(self, code: str, error_info: Optional[Dict] = None) -> HealingResult:
        """
        코드 자동 치유 (규칙 기반 + AST 기반 2단계)
        
        Args:
            code: 문제가 있는 코드
            error_info: 에러 정보
            
        Returns:
            HealingResult
        """
        self.stats['total_attempts'] += 1
        original_code = code
        fixes_applied = []
        confidence = 1.0
        suggestions = []
        
        try:
            # Stage 1: Quick Healing (규칙 기반)
            logger.info("Stage 1: Applying quick healing rules...")
            healed_code = code
            for rule_name, rule_func in self.quick_healing_rules.items():
                try:
                    fixed, was_fixed = rule_func(healed_code, error_info)
                    if was_fixed:
                        healed_code = fixed
                        fixes_applied.append(f"quick:{rule_name}")
                        confidence *= 0.98
                        logger.info(f"  ✅ Applied {rule_name}")
                except Exception as e:
                    logger.warning(f"  ❌ Quick rule '{rule_name}' failed: {e}")
            
            # Stage 2: AST-based Healing (정교한 수정)
            logger.info("Stage 2: Applying AST-based healing...")
            try:
                tree = ast.parse(healed_code)
                ast_fixed = False
                
                for rule_name, rule_func in self.ast_healing_rules.items():
                    try:
                        tree, was_fixed = rule_func(tree, error_info)
                        if was_fixed:
                            ast_fixed = True
                            fixes_applied.append(f"ast:{rule_name}")
                            confidence *= 0.95
                            logger.info(f"  ✅ Applied AST {rule_name}")
                    except Exception as e:
                        logger.warning(f"  ❌ AST rule '{rule_name}' failed: {e}")
                
                if ast_fixed:
                    # AST를 코드로 변환
                    try:
                        healed_code = ast.unparse(tree)
                    except:
                        # astor 사용 (fallback)
                        try:
                            import astor
                            healed_code = astor.to_source(tree)
                        except:
                            logger.warning("AST unparsing failed, keeping previous code")
                
            except SyntaxError as e:
                logger.warning(f"Cannot parse AST (syntax error): {e}")
                suggestions.append("Code has fundamental syntax errors that prevent AST parsing")
                confidence *= 0.7
            
            # Stage 3: Final validation and corrections
            logger.info("Stage 3: Final validation...")
            healed_code, final_fixes = self._final_validation_fixes(healed_code)
            fixes_applied.extend(final_fixes)
            
            # Verify healed code
            success = self._verify_healed_code(healed_code)
            
            if not success:
                error_details = self._get_error_details(healed_code)
                suggestions.extend(self._generate_suggestions(error_details, fixes_applied))
                
                # 실패시 원본 반환
                if confidence < 0.5:
                    healed_code = original_code
                    confidence = 0.0
            
            # Update stats
            if success:
                self.stats['successful_heals'] += 1
                logger.info(f"✅ Healing successful with {len(fixes_applied)} fixes (confidence: {confidence:.2f})")
            else:
                self.stats['failed_heals'] += 1
                logger.warning(f"⚠️ Healing failed (confidence: {confidence:.2f})")
            
            for fix in fixes_applied:
                self.stats['fixes_by_type'][fix] = self.stats['fixes_by_type'].get(fix, 0) + 1
            
            return HealingResult(
                success=success,
                original_code=original_code,
                healed_code=healed_code,
                fixes_applied=fixes_applied,
                confidence=confidence,
                error_details=error_details if not success else None,
                suggestions=suggestions
            )
            
        except Exception as e:
            logger.error(f"Critical healing failure: {e}")
            self.stats['failed_heals'] += 1
            return HealingResult(
                success=False,
                original_code=original_code,
                healed_code=original_code,
                fixes_applied=[],
                confidence=0.0,
                error_details=str(e),
                suggestions=["Critical error during healing process"]
            )
    
    # ========== Quick Healing Rules ==========
    
    def _fix_indentation(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """들여쓰기 수정 (개선됨)"""
        lines = code.split('\n')
        fixed_lines = []
        was_fixed = False
        indent_level = 0
        
        for i, line in enumerate(lines):
            stripped = line.lstrip()
            
            if not stripped or stripped.startswith('#'):
                fixed_lines.append(line)
                continue
            
            # 현재 줄의 예상 들여쓰기
            expected_indent = indent_level
            
            # 들여쓰기 감소 키워드 (블록 끝)
            if any(stripped.startswith(kw) for kw in ['return', 'break', 'continue', 'pass']):
                expected_indent = max(0, indent_level - 1)
            elif stripped.startswith(('else:', 'elif ', 'except', 'finally:')):
                expected_indent = max(0, indent_level - 1)
            
            # 현재 줄 고정
            current_indent = len(line) - len(stripped)
            if current_indent != expected_indent * 4:
                fixed_line = '    ' * expected_indent + stripped
                fixed_lines.append(fixed_line)
                was_fixed = True
            else:
                fixed_lines.append(line)
            
            # 다음 줄을 위한 들여쓰기 레벨 업데이트
            if stripped.endswith(':') and not stripped.startswith('#'):
                indent_level += 1
            elif any(stripped.startswith(kw) for kw in ['return', 'break', 'continue', 'pass']):
                indent_level = max(0, indent_level)
        
        return '\n'.join(fixed_lines), was_fixed
    
    def _fix_missing_colons(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """누락된 콜론 추가"""
        was_fixed = False
        lines = code.split('\n')
        fixed_lines = []
        
        for line in lines:
            stripped = line.strip()
            # 콜론이 필요한 구문인데 없는 경우
            if any(stripped.startswith(kw) for kw in 
                   ['def ', 'async def ', 'class ', 'if ', 'elif ', 'else', 
                    'for ', 'while ', 'try', 'except', 'finally', 'with ']):
                if not stripped.endswith(':') and '#' not in stripped:
                    line = line.rstrip() + ':'
                    was_fixed = True
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines), was_fixed
    
    def _fix_unclosed_brackets(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """닫히지 않은 괄호 수정"""
        was_fixed = False
        
        # 각 종류의 괄호 카운트
        open_count = {'(': code.count('('), '[': code.count('['), '{': code.count('{')}
        close_count = {')': code.count(')'), ']': code.count(']'), '}': code.count('}')}
        
        brackets = {'(': ')', '[': ']', '{': '}'}
        
        for open_br, close_br in brackets.items():
            diff = open_count[open_br] - close_count[close_br]
            if diff > 0:
                # 닫는 괄호 추가
                code += close_br * diff
                was_fixed = True
        
        return code, was_fixed
    
    def _fix_string_quotes(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """문자열 따옴표 수정"""
        was_fixed = False
        
        # 홀수 개의 따옴표 수정
        if code.count('"') % 2 != 0:
            code += '"'
            was_fixed = True
        
        if code.count("'") % 2 != 0:
            code += "'"
            was_fixed = True
        
        return code, was_fixed
    
    def _fix_trailing_whitespace(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """줄 끝 공백 제거"""
        lines = code.split('\n')
        fixed_lines = [line.rstrip() for line in lines]
        was_fixed = any(line != fixed for line, fixed in zip(lines, fixed_lines))
        return '\n'.join(fixed_lines), was_fixed
    
    # ========== AST-based Healing Rules ==========
    
    def _fix_incomplete_functions(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """불완전한 함수 수정"""
        was_fixed = False
        
        class FunctionFixer(ast.NodeTransformer):
            def visit_FunctionDef(self, node):
                self.generic_visit(node)
                # 함수 body가 비어있거나 오직 docstring만 있는 경우
                if not node.body or (len(node.body) == 1 and isinstance(node.body[0], ast.Expr)):
                    # pass 문 추가
                    node.body.append(ast.Pass())
                    nonlocal was_fixed
                    was_fixed = True
                return node
            
            def visit_AsyncFunctionDef(self, node):
                return self.visit_FunctionDef(node)
        
        tree = FunctionFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_missing_self(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """클래스 메서드에 self 파라미터 추가"""
        was_fixed = False
        
        class SelfFixer(ast.NodeTransformer):
            def __init__(self):
                self.in_class = False
            
            def visit_ClassDef(self, node):
                self.in_class = True
                self.generic_visit(node)
                self.in_class = False
                return node
            
            def visit_FunctionDef(self, node):
                if self.in_class and not node.name.startswith('_'):
                    # 첫 번째 파라미터가 self가 아닌 경우
                    if not node.args.args or node.args.args[0].arg != 'self':
                        # self 파라미터 추가
                        self_arg = ast.arg(arg='self', annotation=None)
                        node.args.args.insert(0, self_arg)
                        nonlocal was_fixed
                        was_fixed = True
                return node
        
        tree = SelfFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_incorrect_returns(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """잘못된 return 문 수정"""
        was_fixed = False
        
        class ReturnFixer(ast.NodeTransformer):
            def visit_Return(self, node):
                # return 문이 함수 밖에 있는지 확인은 복잡하므로 패스
                # 대신 return 값이 없는 경우 None 추가
                if node.value is None:
                    node.value = ast.Constant(value=None)
                    nonlocal was_fixed
                    was_fixed = True
                return node
        
        tree = ReturnFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_orphan_code(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """고아 코드 블록 수정"""
        was_fixed = False
        
        # 모든 statement가 적절한 컨텍스트에 있는지 확인
        # 복잡한 로직이므로 일단 기본 구조만
        
        return tree, was_fixed
    
    def _fix_async_issues(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """async/await 관련 이슈 수정"""
        was_fixed = False
        
        class AsyncFixer(ast.NodeTransformer):
            def visit_FunctionDef(self, node):
                # async 함수에서 await 없이 async 함수 호출하는 경우
                # (복잡한 로직, 일단 패스)
                return node
        
        tree = AsyncFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_missing_imports(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """누락된 import 추가"""
        was_fixed = False
        
        # 코드에서 사용된 이름 추출
        used_names = set()
        
        class NameCollector(ast.NodeVisitor):
            def visit_Name(self, node):
                used_names.add(node.id)
        
        NameCollector().visit(tree)
        
        # 일반적인 import 매핑
        common_imports = {
            'asyncio': ['asyncio'],
            'json': ['json'],
            'datetime': ['from datetime import datetime'],
            'logger': ['from loguru import logger'],
            'Dict': ['from typing import Dict, Any, List, Optional'],
            'Any': ['from typing import Dict, Any, List, Optional'],
            'Optional': ['from typing import Dict, Any, List, Optional'],
        }
        
        # 필요한 import 찾기
        needed_imports = set()
        for name in used_names:
            if name in common_imports:
                needed_imports.update(common_imports[name])
        
        if needed_imports:
            # import 문 추가 (AST 시작 부분에)
            for import_stmt in needed_imports:
                if import_stmt.startswith('from'):
                    # from ... import ... 파싱
                    parts = import_stmt.split()
                    module = parts[1]
                    names = parts[3].split(',')
                    import_node = ast.ImportFrom(
                        module=module,
                        names=[ast.alias(name=n.strip(), asname=None) for n in names],
                        level=0
                    )
                else:
                    # import ... 파싱
                    module = import_stmt.split()[1]
                    import_node = ast.Import(names=[ast.alias(name=module, asname=None)])
                
                tree.body.insert(0, import_node)
                was_fixed = True
        
        return tree, was_fixed
    
    def _fix_type_errors(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """타입 관련 오류 수정"""
        was_fixed = False
        # 타입 힌트 관련 수정 (복잡하므로 기본만)
        return tree, was_fixed
    
    # ========== Helper Methods ==========
    
    def _final_validation_fixes(self, code: str) -> Tuple[str, List[str]]:
        """최종 검증 및 수정"""
        fixes = []
        
        # UTF-8 BOM 제거
        if code.startswith('\ufeff'):
            code = code[1:]
            fixes.append('final:remove_bom')
        
        # 연속된 빈 줄 제거 (3개 이상)
        while '\n\n\n\n' in code:
            code = code.replace('\n\n\n\n', '\n\n\n')
            fixes.append('final:remove_extra_blank_lines')
        
        # 파일 끝에 개행 추가
        if not code.endswith('\n'):
            code += '\n'
            fixes.append('final:add_trailing_newline')
        
        return code, fixes
    
    def _verify_healed_code(self, code: str) -> bool:
        """치유된 코드 검증"""
        try:
            compile(code, '<string>', 'exec')
            return True
        except SyntaxError:
            return False
        except Exception:
            return False
    
    def _get_error_details(self, code: str) -> str:
        """에러 상세 정보 추출"""
        try:
            compile(code, '<string>', 'exec')
            return ""
        except SyntaxError as e:
            return f"SyntaxError at line {e.lineno}: {e.msg}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def _generate_suggestions(self, error_details: str, fixes_applied: List[str]) -> List[str]:
        """개선 제안 생성"""
        suggestions = []
        
        if "SyntaxError" in error_details:
            if not any('indentation' in f for f in fixes_applied):
                suggestions.append("Check indentation - Python requires consistent 4-space indentation")
            if not any('colons' in f for f in fixes_applied):
                suggestions.append("Ensure all control structures (if, for, def, class) end with colons")
        
        if len(fixes_applied) > 5:
            suggestions.append("Code had many issues - consider reviewing the logic")
        
        return suggestions
    
    def get_stats(self) -> Dict[str, Any]:
        """통계 반환"""
        if self.stats['total_attempts'] > 0:
            self.stats['success_rate'] = self.stats['successful_heals'] / self.stats['total_attempts']
        return self.stats


# Backward compatibility - wrap the enhanced module
class SelfHealingModule(EnhancedSelfHealingModule):
    """Backward compatible wrapper"""
    pass


if __name__ == "__main__":
    # 테스트
    healer = EnhancedSelfHealingModule()
    
    # 테스트 케이스 1: 들여쓰기 오류
    bad_code1 = '''
def test():
print("hello")
return "world"
'''
    
    result1 = healer.heal(bad_code1)
    print(f"Test 1 - Success: {result1.success}, Fixes: {result1.fixes_applied}")
    
    # 테스트 케이스 2: 누락된 콜론
    bad_code2 = '''
def test()
    if True
        return "hello"
'''
    
    result2 = healer.heal(bad_code2)
    print(f"Test 2 - Success: {result2.success}, Fixes: {result2.fixes_applied}")
    
    print(f"\nStats: {healer.get_stats()}")

