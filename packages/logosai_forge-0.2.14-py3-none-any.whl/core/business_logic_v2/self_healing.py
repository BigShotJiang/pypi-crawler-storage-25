"""
Enhanced Self-Healing Module with AST-based Fixes
==================================================
AST를 활용한 강력한 코드 자동 수정 시스템
"""

import ast
import re
import sys
from typing import Dict, List, Tuple, Optional, Any
from loguru import logger
from dataclasses import dataclass, field


# Python 버전 체크
PYTHON_39_PLUS = sys.version_info >= (3, 9)


@dataclass
class HealingResult:
    """치유 결과"""
    success: bool
    original_code: str
    healed_code: str
    fixes_applied: List[str]
    confidence: float  # 0.0 - 1.0
    error_details: Optional[str] = None
    suggestions: List[str] = field(default_factory=list)


class EnhancedSelfHealingModule:
    """AST 기반 강화된 자가 치유 모듈"""
    
    def __init__(self):
        logger.info("Enhanced Self-Healing Module initialized with AST support")
        
        # 규칙 기반 수정 (빠른 수정용)
        self.quick_healing_rules = {
            'indentation': self._fix_indentation,
            'missing_colons': self._fix_missing_colons,
            'unclosed_brackets': self._fix_unclosed_brackets,
            'string_quotes': self._fix_string_quotes,
            'trailing_whitespace': self._fix_trailing_whitespace,
            'empty_blocks': self._fix_empty_blocks,  # Fix empty try/if/for/while bodies
            'try_without_except': self._fix_try_without_except,  # Fix truncated try blocks
            'truncated_code': self._fix_truncated_code,  # Fix code truncated mid-statement
        }
        
        # AST 기반 수정 (정교한 수정용)
        self.ast_healing_rules = {
            'incomplete_functions': self._fix_incomplete_functions,
            'missing_self': self._fix_missing_self,
            'incorrect_returns': self._fix_incorrect_returns,
            'orphan_code': self._fix_orphan_code,
            'async_issues': self._fix_async_issues,
            'missing_imports': self._fix_missing_imports,
            'type_errors': self._fix_type_errors,
        }
        
        # 통계
        self.stats = {
            'total_attempts': 0,
            'successful_heals': 0,
            'failed_heals': 0,
            'fixes_by_type': {},
            'avg_confidence': 0.0
        }
    
    def heal(self, code: str, error_info: Optional[Dict] = None) -> HealingResult:
        """
        코드 자동 치유 (규칙 기반 + AST 기반 2단계)
        
        Args:
            code: 문제가 있는 코드
            error_info: 에러 정보
            
        Returns:
            HealingResult
        """
        self.stats['total_attempts'] += 1
        original_code = code
        fixes_applied = []
        confidence = 1.0
        suggestions = []
        
        try:
            # Stage 1: Quick Healing (규칙 기반)
            logger.info("Stage 1: Applying quick healing rules...")
            healed_code = code
            for rule_name, rule_func in self.quick_healing_rules.items():
                try:
                    fixed, was_fixed = rule_func(healed_code, error_info)
                    if was_fixed:
                        healed_code = fixed
                        fixes_applied.append(f"quick:{rule_name}")
                        confidence *= 0.98
                        logger.info(f"  ✅ Applied {rule_name}")
                except Exception as e:
                    logger.warning(f"  ❌ Quick rule '{rule_name}' failed: {e}")
            
            # Stage 2: AST-based Healing (정교한 수정)
            logger.info("Stage 2: Applying AST-based healing...")
            try:
                tree = ast.parse(healed_code)
                ast_fixed = False
                
                for rule_name, rule_func in self.ast_healing_rules.items():
                    try:
                        tree, was_fixed = rule_func(tree, error_info)
                        if was_fixed:
                            ast_fixed = True
                            fixes_applied.append(f"ast:{rule_name}")
                            confidence *= 0.95
                            logger.info(f"  ✅ Applied AST {rule_name}")
                    except Exception as e:
                        logger.warning(f"  ❌ AST rule '{rule_name}' failed: {e}")
                
                if ast_fixed:
                    # AST를 코드로 변환
                    try:
                        if PYTHON_39_PLUS:
                            healed_code = ast.unparse(tree)
                        else:
                            # Python 3.8 이하에서는 AST 수정 스킵
                            logger.warning("Python < 3.9: AST unparsing not available, skipping AST changes")
                            ast_fixed = False
                    except Exception as e:
                        logger.warning(f"AST unparsing failed: {e}, keeping previous code")
                
            except SyntaxError as e:
                logger.warning(f"Cannot parse AST (syntax error): {e}")
                suggestions.append("Code has fundamental syntax errors that prevent AST parsing")
                confidence *= 0.7
            
            # Stage 3: Final validation and corrections
            logger.info("Stage 3: Final validation...")
            healed_code, final_fixes = self._final_validation_fixes(healed_code)
            fixes_applied.extend(final_fixes)
            
            # Verify healed code
            success = self._verify_healed_code(healed_code)
            
            if not success:
                error_details = self._get_error_details(healed_code)
                suggestions.extend(self._generate_suggestions(error_details, fixes_applied))
                
                # 실패시 원본 반환
                if confidence < 0.5:
                    healed_code = original_code
                    confidence = 0.0
            
            # Update stats
            if success:
                self.stats['successful_heals'] += 1
                logger.info(f"✅ Healing successful with {len(fixes_applied)} fixes (confidence: {confidence:.2f})")
            else:
                self.stats['failed_heals'] += 1
                logger.warning(f"⚠️ Healing failed (confidence: {confidence:.2f})")
            
            for fix in fixes_applied:
                self.stats['fixes_by_type'][fix] = self.stats['fixes_by_type'].get(fix, 0) + 1
            
            return HealingResult(
                success=success,
                original_code=original_code,
                healed_code=healed_code,
                fixes_applied=fixes_applied,
                confidence=confidence,
                error_details=error_details if not success else None,
                suggestions=suggestions
            )
            
        except Exception as e:
            logger.error(f"Critical healing failure: {e}")
            self.stats['failed_heals'] += 1
            return HealingResult(
                success=False,
                original_code=original_code,
                healed_code=original_code,
                fixes_applied=[],
                confidence=0.0,
                error_details=str(e),
                suggestions=["Critical error during healing process"]
            )
    
    # ========== Quick Healing Rules ==========
    
    def _fix_indentation(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """들여쓰기 수정 (개선됨 - 컨텍스트 인식 알고리즘)

        개선된 점:
        1. class/def 컨텍스트 추적
        2. dedent 키워드(else, elif, except, finally) 올바른 처리
        3. 실제 들여쓰기 레벨과 기대 레벨 비교
        4. multiline string/bracket 처리
        """
        lines = code.split('\n')
        fixed_lines = []
        was_fixed = False

        # 컨텍스트 추적 스택: (indent_level, block_type)
        # block_type: 'class', 'def', 'if', 'for', 'while', 'try', 'with', 'else', 'elif', 'except', 'finally'
        context_stack = [(0, 'module')]

        # multiline 상태 추적
        in_multiline_string = False
        open_brackets = 0  # 열린 괄호 수 ((), [], {})

        # Dedent 키워드들 (같은 레벨로 돌아가는 키워드)
        dedent_keywords = ('else:', 'elif ', 'except:', 'except ', 'finally:')

        for i, line in enumerate(lines):
            original_line = line
            stripped = line.lstrip()

            # 빈 줄 처리
            if not stripped:
                fixed_lines.append('')
                continue

            # 주석만 있는 줄 - 현재 컨텍스트 레벨 유지
            if stripped.startswith('#'):
                current_level = context_stack[-1][0]
                fixed_line = '    ' * current_level + stripped
                fixed_lines.append(fixed_line)
                if len(line) - len(line.lstrip()) != current_level * 4:
                    was_fixed = True
                continue

            # Multiline string 체크 (간단한 검사)
            triple_count = stripped.count('"""') + stripped.count("'''")
            if triple_count % 2 == 1:
                in_multiline_string = not in_multiline_string

            if in_multiline_string:
                fixed_lines.append(original_line)
                continue

            # 괄호 카운트 업데이트
            for char in stripped:
                if char in '([{':
                    open_brackets += 1
                elif char in ')]}':
                    open_brackets -= 1

            # 열린 괄호가 있으면 들여쓰기 유지
            if open_brackets > 0:
                current_level = context_stack[-1][0] + 1
                fixed_line = '    ' * current_level + stripped
                fixed_lines.append(fixed_line)
                continue

            # Dedent 키워드 처리 (else, elif, except, finally)
            if any(stripped.startswith(kw) for kw in dedent_keywords):
                # 이전 if/elif/try/except와 같은 레벨로 맞춤
                while len(context_stack) > 1:
                    top_level, top_type = context_stack[-1]
                    if top_type in ('if', 'elif', 'else', 'try', 'except', 'finally', 'for', 'while', 'with'):
                        context_stack.pop()
                        break
                    elif top_type == 'def' or top_type == 'class':
                        # def/class 안쪽은 빠져나가지 않음
                        break
                    else:
                        context_stack.pop()
                        if not context_stack:
                            context_stack = [(0, 'module')]
                            break

            # 현재 레벨 결정
            current_level = context_stack[-1][0]

            # class/def 정의는 상위 컨텍스트 레벨
            if stripped.startswith('class ') or stripped.startswith('async def ') or stripped.startswith('def '):
                # class/def는 부모 컨텍스트의 레벨+1 (module=0, class body=1, method body=2)
                if context_stack[-1][1] == 'class':
                    current_level = context_stack[-1][0]  # class 안의 def는 class와 같은 레벨
                elif context_stack[-1][1] == 'module':
                    current_level = 0  # 최상위 class/def는 레벨 0

            # 줄 고정
            fixed_line = '    ' * current_level + stripped
            fixed_lines.append(fixed_line)

            # 들여쓰기 변경 확인
            original_indent = len(original_line) - len(original_line.lstrip())
            expected_indent = current_level * 4
            if original_indent != expected_indent:
                was_fixed = True

            # 블록 시작 감지 (콜론으로 끝나는 줄)
            if stripped.endswith(':'):
                # 블록 타입 결정
                if stripped.startswith('class '):
                    block_type = 'class'
                elif stripped.startswith('async def ') or stripped.startswith('def '):
                    block_type = 'def'
                elif stripped.startswith('if ') or stripped == 'if:':
                    block_type = 'if'
                elif stripped.startswith('elif ') or stripped == 'elif:':
                    block_type = 'elif'
                elif stripped.startswith('else') or stripped == 'else:':
                    block_type = 'else'
                elif stripped.startswith('for '):
                    block_type = 'for'
                elif stripped.startswith('while '):
                    block_type = 'while'
                elif stripped.startswith('try') or stripped == 'try:':
                    block_type = 'try'
                elif stripped.startswith('except') or stripped == 'except:':
                    block_type = 'except'
                elif stripped.startswith('finally') or stripped == 'finally:':
                    block_type = 'finally'
                elif stripped.startswith('with '):
                    block_type = 'with'
                else:
                    block_type = 'other'

                # 새 컨텍스트 추가 (다음 레벨)
                context_stack.append((current_level + 1, block_type))

            # return/break/continue 후에 컨텍스트 유지 (블록을 벗어나지 않음)
            # 이 키워드들은 블록 끝을 의미하지 않음

        return '\n'.join(fixed_lines), was_fixed
    
    def _fix_missing_colons(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """누락된 콜론 추가"""
        was_fixed = False
        lines = code.split('\n')
        fixed_lines = []
        
        for line in lines:
            stripped = line.strip()
            # 콜론이 필요한 구문인데 없는 경우
            if any(stripped.startswith(kw) for kw in 
                   ['def ', 'async def ', 'class ', 'if ', 'elif ', 'else', 
                    'for ', 'while ', 'try', 'except', 'finally', 'with ']):
                if not stripped.endswith(':') and '#' not in stripped:
                    line = line.rstrip() + ':'
                    was_fixed = True
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines), was_fixed
    
    def _fix_unclosed_brackets(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """닫히지 않은 괄호 수정"""
        was_fixed = False
        
        # 각 종류의 괄호 카운트
        open_count = {'(': code.count('('), '[': code.count('['), '{': code.count('{')}
        close_count = {')': code.count(')'), ']': code.count(']'), '}': code.count('}')}
        
        brackets = {'(': ')', '[': ']', '{': '}'}
        
        for open_br, close_br in brackets.items():
            diff = open_count[open_br] - close_count[close_br]
            if diff > 0:
                # 닫는 괄호 추가
                code += close_br * diff
                was_fixed = True
        
        return code, was_fixed
    
    def _fix_string_quotes(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """문자열 따옴표 수정 + f-string 줄바꿈 수정"""
        was_fixed = False

        # Fix multiline f-strings: f"...{var}\n..." → f"...{var} ..."
        # LLM sometimes generates f-strings with line breaks which is invalid Python
        lines = code.split('\n')
        fixed_lines = []
        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.rstrip()

            # Detect unterminated f-string or regular string on this line
            # Check if line has an opening f" or " that isn't closed
            in_fstring = False
            quote_char = None
            for ci, ch in enumerate(stripped):
                if ch in ('"', "'") and not in_fstring:
                    # Check it's not a triple quote
                    triple = stripped[ci:ci+3]
                    if triple in ('"""', "'''"):
                        break  # triple quotes handled separately
                    in_fstring = True
                    quote_char = ch
                elif ch == quote_char and in_fstring:
                    in_fstring = False
                    quote_char = None

            if in_fstring and quote_char and i + 1 < len(lines):
                # This line has an unterminated string — merge with next lines until closed
                merged = stripped
                j = i + 1
                while j < len(lines) and j < i + 5:  # Max 5 lines merge
                    next_line = lines[j].strip()
                    merged += " " + next_line
                    if quote_char in next_line:
                        break
                    j += 1
                if merged != stripped:
                    fixed_lines.append(line[:len(line)-len(stripped)] + merged)
                    was_fixed = True
                    i = j + 1
                    continue

            fixed_lines.append(line)
            i += 1

        code = '\n'.join(fixed_lines)

        # 홀수 개의 따옴표 수정
        if code.count('"') % 2 != 0:
            code += '"'
            was_fixed = True

        if code.count("'") % 2 != 0:
            code += "'"
            was_fixed = True

        return code, was_fixed
    
    def _fix_trailing_whitespace(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """줄 끝 공백 제거"""
        lines = code.split('\n')
        fixed_lines = [line.rstrip() for line in lines]
        was_fixed = any(line != fixed for line, fixed in zip(lines, fixed_lines))
        return '\n'.join(fixed_lines), was_fixed

    def _fix_empty_blocks(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """Fix empty block bodies — insert 'pass' when try/if/for/while/with/else/except has no body.

        Catches: 'expected an indented block after try/if/for/while statement'
        """
        lines = code.split('\n')
        result_lines = []
        was_fixed = False
        block_starters = ('try:', 'else:', 'finally:', 'if ', 'elif ', 'for ', 'while ', 'with ', 'except:', 'except ')

        for i, line in enumerate(lines):
            result_lines.append(line)
            stripped = line.lstrip()

            # Check if this line starts a block
            starts_block = False
            for starter in block_starters:
                if stripped.startswith(starter) and stripped.rstrip().endswith(':'):
                    starts_block = True
                    break
            # Also check: 'async def' and 'def' with colon
            if stripped.startswith(('def ', 'async def ', 'class ')) and stripped.rstrip().endswith(':'):
                starts_block = True

            if not starts_block:
                continue

            # Check if next non-empty line is at the correct indent (body)
            indent = len(line) - len(stripped)
            body_indent = indent + 4
            has_body = False

            for j in range(i + 1, min(i + 5, len(lines))):
                next_stripped = lines[j].lstrip()
                if not next_stripped:  # empty line
                    continue
                next_indent = len(lines[j]) - len(next_stripped)
                if next_indent >= body_indent:
                    has_body = True  # Next non-empty line is properly indented
                break  # Only check first non-empty line

            if not has_body:
                # Insert 'pass' as the body
                result_lines.append(' ' * body_indent + 'pass')
                was_fixed = True
                logger.info(f"Fixed empty block at line {i + 1}: {stripped[:40]}")

        return '\n'.join(result_lines), was_fixed

    def _fix_try_without_except(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """
        Fix try blocks that are missing except clauses.
        This happens when code is truncated mid-generation.

        Pattern detected:
        - try: block starts but no except: found before next method/class definition
        - Error message: "expected 'except' or 'finally' block"
        """
        import re

        # Check if error is about missing except
        error_msg = error_info.get('message', '') if error_info else ''
        if 'except' not in error_msg.lower() and 'finally' not in error_msg.lower():
            # Also check for common truncation patterns
            if not re.search(r'try:\s*\n(?:.*\n)*?(?:async\s+)?def\s+', code):
                return code, False

        lines = code.split('\n')
        was_fixed = False
        result_lines = []

        try_stack = []  # Stack of (line_index, indent_level)

        for i, line in enumerate(lines):
            stripped = line.lstrip()
            indent = len(line) - len(stripped)

            # Track try blocks
            if stripped.startswith('try:'):
                try_stack.append((i, indent))

            # Check for except/finally that closes a try
            elif stripped.startswith(('except', 'finally:')):
                if try_stack:
                    try_stack.pop()

            # Check if a new method/class starts while try is open
            elif stripped.startswith(('async def ', 'def ', 'class ')) and try_stack:
                # There's an unclosed try block - need to close it
                try_line_idx, try_indent = try_stack.pop()

                # Insert except block before the new method definition
                # Use same indent as try: for except:
                except_indent = ' ' * try_indent
                body_indent = ' ' * (try_indent + 4)

                except_lines = [
                    f'{body_indent}# Auto-healed: completing truncated try block',
                    f'{body_indent}result = {{"status": "partial", "message": "processing incomplete"}}',
                    f'{except_indent}except Exception as e:',
                    f'{body_indent}logger.error(f"Processing error: {{e}}")',
                    f'{body_indent}result = {{"error": str(e)}}',
                    f'{except_indent}return result',
                    '',
                ]

                # Add except block before the new method
                result_lines.extend(except_lines)
                was_fixed = True
                logger.info(f"Fixed try without except at line {try_line_idx + 1}")

            result_lines.append(line)

        # Handle any remaining unclosed try blocks at end of code
        if try_stack:
            try_line_idx, try_indent = try_stack[-1]
            except_indent = ' ' * try_indent
            body_indent = ' ' * (try_indent + 4)

            except_lines = [
                '',
                f'{body_indent}result = {{"status": "completed"}}',
                f'{except_indent}except Exception as e:',
                f'{body_indent}logger.error(f"Processing error: {{e}}")',
                f'{body_indent}result = {{"error": str(e)}}',
                f'{except_indent}return result',
            ]
            result_lines.extend(except_lines)
            was_fixed = True
            logger.info(f"Fixed unclosed try block at end of code (line {try_line_idx + 1})")

        return '\n'.join(result_lines), was_fixed

    def _fix_truncated_code(self, code: str, error_info: Optional[Dict]) -> Tuple[str, bool]:
        """
        Fix code that was truncated mid-statement.

        Patterns detected:
        - Line ending with incomplete expression: "min(a + b"
        - Incomplete string assignment
        - elif/else without body
        """
        import re

        lines = code.split('\n')
        was_fixed = False
        fixed_lines = []

        for i, line in enumerate(lines):
            stripped = line.lstrip()
            indent = len(line) - len(stripped)

            # Check for truncated expressions (unclosed parentheses at end)
            if re.search(r'[=:]\s*\w+\([^)]*$', line) and not stripped.endswith(','):
                # Line like: "result = min(a + b" without closing
                # Add a closing with a default value
                fixed_line = line.rstrip() + ', 0)  # Auto-healed: closed truncated expression'
                fixed_lines.append(fixed_line)
                was_fixed = True
                logger.info(f"Fixed truncated expression at line {i + 1}")
                continue

            # Check for elif/else without body (next line is a new statement at same/lower indent)
            if stripped.startswith(('elif ', 'else:')) and i + 1 < len(lines):
                next_line = lines[i + 1]
                next_stripped = next_line.lstrip()
                next_indent = len(next_line) - len(next_stripped)

                # If next line is at same or lower indent and is a statement (not continuation)
                if next_indent <= indent and next_stripped and not next_stripped.startswith('#'):
                    if next_stripped.startswith(('async def ', 'def ', 'class ', 'elif ', 'else:', 'except', 'finally:')):
                        # Need to add a pass or placeholder
                        fixed_lines.append(line)
                        fixed_lines.append(f'{" " * (indent + 4)}pass  # Auto-healed: added missing body')
                        was_fixed = True
                        logger.info(f"Fixed elif/else without body at line {i + 1}")
                        continue

            # Check for unterminated string literals
            string_fixed = False
            for quote_char in ['"', "'"]:
                triple = quote_char * 3
                if triple in stripped:
                    continue
                count = stripped.count(quote_char) - stripped.count(f'\\{quote_char}')
                if count % 2 != 0:
                    fixed_line = line.rstrip() + quote_char
                    fixed_lines.append(fixed_line)
                    was_fixed = True
                    string_fixed = True
                    logger.info(f"Fixed unterminated string at line {i + 1}")
                    break
            if string_fixed:
                continue

            # Check for incomplete elif condition
            if stripped.startswith('elif ') and not stripped.rstrip().endswith(':'):
                # Truncated elif like "elif operation =="
                if '==' in stripped or '!=' in stripped or ' in ' in stripped:
                    fixed_line = line.rstrip() + ' "unknown":  # Auto-healed'
                else:
                    fixed_line = line.rstrip() + ':"  # Auto-healed'
                fixed_lines.append(fixed_line)
                fixed_lines.append(f'{" " * (indent + 4)}pass  # Auto-healed: placeholder')
                was_fixed = True
                logger.info(f"Fixed incomplete elif at line {i + 1}")
                continue

            fixed_lines.append(line)

        return '\n'.join(fixed_lines), was_fixed

    # ========== AST-based Healing Rules ==========
    
    def _fix_incomplete_functions(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """불완전한 함수 수정"""
        was_fixed = False
        
        class FunctionFixer(ast.NodeTransformer):
            def visit_FunctionDef(self, node):
                self.generic_visit(node)
                # 함수 body가 비어있거나 오직 docstring만 있는 경우
                if not node.body or (len(node.body) == 1 and isinstance(node.body[0], ast.Expr)):
                    # pass 문 추가
                    node.body.append(ast.Pass())
                    nonlocal was_fixed
                    was_fixed = True
                return node
            
            def visit_AsyncFunctionDef(self, node):
                return self.visit_FunctionDef(node)
        
        tree = FunctionFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_missing_self(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """클래스 메서드에 self 파라미터 추가"""
        was_fixed = False
        
        class SelfFixer(ast.NodeTransformer):
            def __init__(self):
                self.in_class = False
            
            def visit_ClassDef(self, node):
                self.in_class = True
                self.generic_visit(node)
                self.in_class = False
                return node
            
            def visit_FunctionDef(self, node):
                if self.in_class and not node.name.startswith('_'):
                    # 첫 번째 파라미터가 self가 아닌 경우
                    if not node.args.args or node.args.args[0].arg != 'self':
                        # self 파라미터 추가
                        self_arg = ast.arg(arg='self', annotation=None)
                        node.args.args.insert(0, self_arg)
                        nonlocal was_fixed
                        was_fixed = True
                return node
        
        tree = SelfFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_incorrect_returns(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """잘못된 return 문 수정"""
        was_fixed = False
        
        class ReturnFixer(ast.NodeTransformer):
            def visit_Return(self, node):
                # return 문이 함수 밖에 있는지 확인은 복잡하므로 패스
                # 대신 return 값이 없는 경우 None 추가
                if node.value is None:
                    node.value = ast.Constant(value=None)
                    nonlocal was_fixed
                    was_fixed = True
                return node
        
        tree = ReturnFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_orphan_code(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """고아 코드 블록 수정"""
        was_fixed = False
        
        # 모든 statement가 적절한 컨텍스트에 있는지 확인
        # 복잡한 로직이므로 일단 기본 구조만
        
        return tree, was_fixed
    
    def _fix_async_issues(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """async/await 관련 이슈 수정"""
        was_fixed = False
        
        class AsyncFixer(ast.NodeTransformer):
            def visit_FunctionDef(self, node):
                # async 함수에서 await 없이 async 함수 호출하는 경우
                # (복잡한 로직, 일단 패스)
                return node
        
        tree = AsyncFixer().visit(tree)
        return tree, was_fixed
    
    def _fix_missing_imports(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """누락된 import 추가"""
        was_fixed = False
        
        # 코드에서 사용된 이름 추출
        used_names = set()
        
        class NameCollector(ast.NodeVisitor):
            def visit_Name(self, node):
                used_names.add(node.id)
        
        NameCollector().visit(tree)
        
        # 일반적인 import 매핑
        common_imports = {
            'asyncio': ['asyncio'],
            'json': ['json'],
            'datetime': ['from datetime import datetime'],
            'logger': ['from loguru import logger'],
            'Dict': ['from typing import Dict, Any, List, Optional'],
            'Any': ['from typing import Dict, Any, List, Optional'],
            'Optional': ['from typing import Dict, Any, List, Optional'],
        }
        
        # 필요한 import 찾기
        needed_imports = set()
        for name in used_names:
            if name in common_imports:
                needed_imports.update(common_imports[name])
        
        if needed_imports:
            # import 문 추가 (AST 시작 부분에)
            for import_stmt in needed_imports:
                if import_stmt.startswith('from'):
                    # from ... import ... 파싱
                    parts = import_stmt.split()
                    module = parts[1]
                    names = parts[3].split(',')
                    import_node = ast.ImportFrom(
                        module=module,
                        names=[ast.alias(name=n.strip(), asname=None) for n in names],
                        level=0
                    )
                else:
                    # import ... 파싱
                    module = import_stmt.split()[1]
                    import_node = ast.Import(names=[ast.alias(name=module, asname=None)])
                
                tree.body.insert(0, import_node)
                was_fixed = True
        
        return tree, was_fixed
    
    def _fix_type_errors(self, tree: ast.AST, error_info: Optional[Dict]) -> Tuple[ast.AST, bool]:
        """타입 관련 오류 수정"""
        was_fixed = False
        # 타입 힌트 관련 수정 (복잡하므로 기본만)
        return tree, was_fixed
    
    # ========== Helper Methods ==========
    
    def _final_validation_fixes(self, code: str) -> Tuple[str, List[str]]:
        """최종 검증 및 수정"""
        fixes = []
        
        # UTF-8 BOM 제거
        if code.startswith('\ufeff'):
            code = code[1:]
            fixes.append('final:remove_bom')
        
        # 연속된 빈 줄 제거 (3개 이상)
        while '\n\n\n\n' in code:
            code = code.replace('\n\n\n\n', '\n\n\n')
            fixes.append('final:remove_extra_blank_lines')
        
        # 파일 끝에 개행 추가
        if not code.endswith('\n'):
            code += '\n'
            fixes.append('final:add_trailing_newline')
        
        return code, fixes
    
    def _verify_healed_code(self, code: str) -> bool:
        """치유된 코드 검증"""
        try:
            compile(code, '<string>', 'exec')
            return True
        except SyntaxError:
            return False
        except Exception:
            return False
    
    def _get_error_details(self, code: str) -> str:
        """에러 상세 정보 추출"""
        try:
            compile(code, '<string>', 'exec')
            return ""
        except SyntaxError as e:
            return f"SyntaxError at line {e.lineno}: {e.msg}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def _generate_suggestions(self, error_details: str, fixes_applied: List[str]) -> List[str]:
        """개선 제안 생성"""
        suggestions = []
        
        if "SyntaxError" in error_details:
            if not any('indentation' in f for f in fixes_applied):
                suggestions.append("Check indentation - Python requires consistent 4-space indentation")
            if not any('colons' in f for f in fixes_applied):
                suggestions.append("Ensure all control structures (if, for, def, class) end with colons")
        
        if len(fixes_applied) > 5:
            suggestions.append("Code had many issues - consider reviewing the logic")
        
        return suggestions
    
    def get_stats(self) -> Dict[str, Any]:
        """통계 반환"""
        if self.stats['total_attempts'] > 0:
            self.stats['success_rate'] = self.stats['successful_heals'] / self.stats['total_attempts']
        return self.stats


# Backward compatibility - wrap the enhanced module
class SelfHealingModule(EnhancedSelfHealingModule):
    """Backward compatible wrapper"""
    pass


if __name__ == "__main__":
    # 테스트
    healer = EnhancedSelfHealingModule()
    
    # 테스트 케이스 1: 들여쓰기 오류
    bad_code1 = '''
def test():
print("hello")
return "world"
'''
    
    result1 = healer.heal(bad_code1)
    print(f"Test 1 - Success: {result1.success}, Fixes: {result1.fixes_applied}")
    
    # 테스트 케이스 2: 누락된 콜론
    bad_code2 = '''
def test()
    if True
        return "hello"
'''
    
    result2 = healer.heal(bad_code2)
    print(f"Test 2 - Success: {result2.success}, Fixes: {result2.fixes_applied}")
    
    print(f"\nStats: {healer.get_stats()}")

