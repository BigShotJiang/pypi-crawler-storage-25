"""
Function Generator for Business Logic
======================================
Enhanced with LogicSynthesizer integration (Paper1 methodology)

비즈니스 로직 생성 흐름:
1. Template 검색 → 발견 시 template 사용
2. LogicSynthesizer로 도메인별 로직 합성 시도
3. LLM 기반 생성 (fallback)
4. Stub 생성 (last resort)
"""

import json
from pathlib import Path
from typing import Dict, Any, Optional, List
from ..template_system.template_manager import TemplateManager
from .query_analyzer import FunctionSpec
from loguru import logger

# Try to use DirectGeminiClient (preferred) or fallback to LLMClient
try:
    from ..direct_gemini_client import DirectGeminiClient
    USE_GEMINI = True
    logger.info("Using DirectGeminiClient for function generation")
except ImportError:
    from ..llm_client import LLMClient
    USE_GEMINI = False
    logger.warning("DirectGeminiClient not available, using LLMClient")

# Import LogicSynthesizer
try:
    from .logic_synthesizer import (
        LogicSynthesizer,
        get_logic_synthesizer,
        RequirementSpec,
        DomainType,
        BusinessLogic
    )
    LOGIC_SYNTHESIZER_AVAILABLE = True
except ImportError:
    LOGIC_SYNTHESIZER_AVAILABLE = False
    logger.warning("LogicSynthesizer not available, using basic generation")



# Heavy external libraries that are NOT available in standard environments.
# Templates using these should be skipped in favor of LLM generation with stdlib.
HEAVY_EXTERNAL_LIBRARIES = {
    'pandas', 'numpy', 'scipy', 'sklearn', 'scikit-learn',
    'transformers', 'torch', 'tensorflow', 'keras',
    'cv2', 'opencv', 'pillow', 'PIL',
    'requests', 'httpx', 'aiohttp',
    'plotly', 'matplotlib', 'seaborn',
    'yfinance', 'ta', 'stockstats',
    'nltk', 'spacy', 'gensim',
}

# Domain-specific hints for LLM prompt (replaces 20+ "If this is X" blocks)
DOMAIN_HINTS = {
    "calculation": "Implement actual arithmetic operations (+, -, *, /, **, %). Use math module for complex ops.",
    "finance": "Use financial formulas (SMA, EMA, RSI, MACD, Sharpe, VaR). Handle stock/portfolio data.",
    "analysis": "Process and analyze data. Calculate metrics (mean, median, std). Return insights.",
    "processing": "Transform and process input data. Handle various data formats (CSV, JSON, text).",
    "prediction": "Build prediction logic using statistical methods or ML patterns. Return confidence scores.",
    "privacy": "Check compliance standards (GDPR, CCPA). Scan for PII patterns. Generate audit reports.",
    "social": "Analyze social media data. Calculate sentiment, engagement, reach metrics.",
    "vision": "Use cv2/PIL/numpy for image processing. Return detection results with bounding boxes.",
    "business_analytics": "Calculate scores from weighted factors. Implement segmentation, churn, LTV models.",
    "data_io": "Read/write data from files, APIs, databases. Handle encoding and error recovery.",
    "transformation": "Transform data between formats. Apply cleaning, normalization, encoding.",
    "visualization": "Generate chart data structures. Prepare data for plotly/matplotlib rendering.",
    "integration": "Connect to external APIs. Handle auth, pagination, rate limiting.",
    "custom": "Implement the specific logic described in the query.",
    # ACP-specific categories
    "file_creation": "Create files using python-pptx (PPT), openpyxl (Excel), python-docx (Word). Save to tempfile.gettempdir(). MUST return dict with file_path (absolute) and file_name keys. Use professional themes/styles.",
    "file_search": "Search files using subprocess: mdfind (Spotlight, fastest), grep -ril (text), pdfgrep (PDF content), textutil (DOCX→text). MUST return dict with files key (list of absolute paths).",
    "desktop_automation": "Use subprocess + osascript for macOS automation. Control apps via AppleScript. Return dict with success and detail keys.",
    "document_generation": "Generate structured documents (reports, summaries). Use LLMClient for content. If creating file, save to tempfile.gettempdir() and return file_path.",
}


class FunctionGenerator:
    """Generates functions from templates, slice library, or LLM.

    Search order (FORGE Slice Architecture):
      1. template_manager (30 utility templates)
      2. slice_library (169 pre-built business logic slices) ← CORE OF FORGE
      3. LLM generation (fallback only)
    """

    def __init__(self):
        self.template_manager = TemplateManager()

        # Initialize Slice Library — the core of FORGE's value
        self.slice_library = None
        try:
            from core.business_logic_v2.slice_library.library import SliceLibrary
            from core.business_logic_v2.slice_library.core_slices import create_core_slices
            from core.business_logic_v2.slice_library.common_slices import create_common_slices

            self.slice_library = SliceLibrary()
            self.slice_library.register_many(create_core_slices())
            self.slice_library.register_many(create_common_slices())

            # Load domain slices (125+ business logic slices)
            try:
                from core.business_logic_v2.slice_library.domain_slices import create_all_domain_slices
                domain_slices = create_all_domain_slices()
                self.slice_library.register_many(domain_slices)
            except Exception as e:
                logger.warning(f"Failed to load domain slices: {e}")

            logger.info(f"SliceLibrary loaded: {len(self.slice_library._slices)} slices")
        except Exception as e:
            logger.warning(f"SliceLibrary not available: {e}")

        # Initialize LLM client (prefer Gemini)
        if USE_GEMINI:
            self.llm_client = DirectGeminiClient(model_name="gemini-2.5-flash-lite")
            self.use_gemini = True
        else:
            self.llm_client = LLMClient()
            self.use_gemini = False

        # Initialize LogicSynthesizer if available
        self.logic_synthesizer = None
        if LOGIC_SYNTHESIZER_AVAILABLE:
            try:
                self.logic_synthesizer = get_logic_synthesizer()
                logger.info("LogicSynthesizer integrated successfully")
            except Exception as e:
                logger.warning(f"Failed to initialize LogicSynthesizer: {e}")

        # Load filled slices (LLM-generated code for metadata-only slices)
        self._filled_slices_path = Path(__file__).parent / "slice_library" / "filled_slices.json"
        self._load_filled_slices()

        # Persistent storage for Self-Growing generated slices
        self._generated_slices_path = Path(__file__).parent / "slice_library" / "generated_slices.json"
        self._load_generated_slices()

        # Track generation sources for metadata
        self._generation_stats = {"slice": 0, "llm": 0, "template": 0, "self_growing": 0}

        logger.info("Function generator initialized")

    def _load_filled_slices(self):
        """Load filled slices — inject LLM-generated code into existing metadata-only slices."""
        if not self.slice_library or not self._filled_slices_path.exists():
            return

        try:
            import json as _json
            with open(self._filled_slices_path, 'r', encoding='utf-8') as f:
                data = _json.load(f)

            filled = data.get('slices', [])
            count = 0
            for entry in filled:
                name = entry.get('name', '')
                code = entry.get('code_template', '')
                if not name or not code:
                    continue
                # Find existing slice and update its code_template
                if name in self.slice_library._slices:
                    existing = self.slice_library._slices[name]
                    if not existing.code_template or ('async def' not in existing.code_template):
                        existing.code_template = code
                        count += 1

            if count > 0:
                logger.info(f"📦 Filled {count} slices with generated code")
        except Exception as e:
            logger.warning(f"Failed to load filled slices: {e}")

    def _load_generated_slices(self):
        """Load previously generated slices from persistent storage."""
        if not self.slice_library or not self._generated_slices_path.exists():
            return

        try:
            import json as _json
            with open(self._generated_slices_path, 'r', encoding='utf-8') as f:
                saved = _json.load(f)

            from core.business_logic_v2.slice_library.models import (
                FunctionSlice, SliceCategory, SliceDomain, SliceParameter
            )

            count = 0
            for entry in saved:
                slice_obj = FunctionSlice(
                    id=entry["id"],
                    name=entry["name"],
                    description=entry["description"],
                    category=SliceCategory.DOMAIN,
                    domain=SliceDomain(entry.get("domain", "common")),
                    inputs=[SliceParameter(**p) for p in entry.get("inputs", [])],
                    outputs=[SliceParameter(**p) for p in entry.get("outputs", [])],
                    keywords=entry.get("keywords", []),
                    code_template=entry.get("code_template", ""),
                    function_name=entry.get("function_name", ""),
                )
                if self.slice_library.register(slice_obj):
                    count += 1

            if count > 0:
                logger.info(f"🌱 Self-Growing: loaded {count} previously generated slices")
        except Exception as e:
            logger.warning(f"Failed to load generated slices: {e}")

    def _register_generated_slice(self, spec: FunctionSpec, code: str):
        """Register a successfully generated function as a new slice (Self-Growing).

        This is the CORE of Self-Growing: verified code → library → future reuse.
        """
        if not self.slice_library:
            return

        try:
            import json as _json, re as _re
            from core.business_logic_v2.slice_library.models import (
                FunctionSlice, SliceCategory, SliceDomain, SliceParameter
            )

            # Determine domain from category
            domain_map = {
                'business_analytics': 'analytics', 'customer_analytics': 'customer',
                'finance': 'finance', 'ecommerce': 'order', 'hr': 'hr',
                'project_management': 'project', 'inventory': 'inventory',
                'workflow_step': 'common', 'custom': 'common',
            }
            domain_str = domain_map.get(spec.category, 'common')

            # Create unique ID
            slice_id = f"generated.{spec.category}.{spec.name.lstrip('_')}"

            # Check if already registered
            if slice_id in self.slice_library._slices:
                return

            # Extract code body (strip method signature for template)
            body = code
            body = _re.sub(r'^\s*(async\s+)?def\s+\w+\([^)]*\)\s*(->\s*[^:]+)?\s*:', '', body, count=1)
            # Remove leading docstring if present
            body = _re.sub(r'^\s*""".*?"""\s*', '', body, flags=_re.DOTALL)

            # Build keywords from spec
            keywords = list(set(
                spec.name.lstrip('_').split('_') +
                _re.findall(r'[a-z]+', spec.description.lower())[:5]
            ))

            # Build input parameters
            inputs = []
            if spec.inputs and isinstance(spec.inputs, dict):
                for k, v in spec.inputs.items():
                    inputs.append(SliceParameter(name=k, param_type=v, description=k))

            slice_obj = FunctionSlice(
                id=slice_id,
                name=spec.description[:50] if spec.description else spec.name,
                description=spec.description or spec.name,
                category=SliceCategory.DOMAIN,
                domain=SliceDomain(domain_str) if domain_str in [d.value for d in SliceDomain] else SliceDomain.COMMON,
                inputs=inputs,
                keywords=keywords,
                code_template=body.strip(),
                function_name=spec.name,
            )

            if self.slice_library.register(slice_obj):
                logger.info(f"🌱 Self-Growing: registered new slice '{slice_id}' ({len(body)} chars)")
                self._save_generated_slices()
            else:
                logger.debug(f"Slice already exists: {slice_id}")

        except Exception as e:
            logger.warning(f"Failed to register generated slice: {e}")

    def _save_generated_slices(self):
        """Save all generated slices to persistent storage."""
        if not self.slice_library:
            return

        try:
            import json as _json

            # Collect only generated slices (id starts with "generated.")
            generated = []
            for sid, s in self.slice_library._slices.items():
                if sid.startswith("generated."):
                    entry = {
                        "id": s.id,
                        "name": s.name,
                        "description": s.description,
                        "domain": s.domain.value if hasattr(s.domain, 'value') else str(s.domain),
                        "inputs": [{"name": p.name, "param_type": p.param_type, "description": p.description}
                                   for p in s.inputs],
                        "outputs": [{"name": p.name, "param_type": p.param_type, "description": p.description}
                                    for p in s.outputs],
                        "keywords": s.keywords if isinstance(s.keywords, list) else [],
                        "code_template": s.code_template,
                        "function_name": s.function_name,
                    }
                    generated.append(entry)

            with open(self._generated_slices_path, 'w', encoding='utf-8') as f:
                _json.dump(generated, f, indent=2, ensure_ascii=False)

            logger.debug(f"Saved {len(generated)} generated slices to {self._generated_slices_path}")

        except Exception as e:
            logger.warning(f"Failed to save generated slices: {e}")

    def _search_slice_library(self, spec: FunctionSpec) -> Optional[str]:
        """Search the slice library for a matching pre-built function.

        This is the CORE of FORGE's Slice Architecture: reuse verified business logic
        instead of having LLM generate from scratch.

        Returns function code string if found, None otherwise.
        """
        if not self.slice_library or not self.slice_library._slices:
            return None

        import re as _re

        # Build search keywords from spec (more sources = better matching)
        keywords = []
        # From function name: _calculate_discount → ["calculate", "discount"]
        name_parts = spec.name.lstrip('_').split('_')
        keywords.extend(name_parts)
        # From description
        if spec.description:
            keywords.extend(_re.findall(r'[a-z]+', spec.description.lower()))
        # From category
        if spec.category:
            keywords.extend(spec.category.lower().split('_'))
        # From input parameter names (e.g., customer_tier → customer, tier)
        if spec.inputs and isinstance(spec.inputs, dict):
            for key in spec.inputs:
                keywords.extend(key.split('_'))

        # Remove only generic stop words (keep domain words like "order", "customer")
        stop_words = {'the', 'a', 'an', 'and', 'or', 'for', 'of', 'in', 'to', 'with',
                      'based', 'on', 'from', 'by', 'get', 'process', 'self',
                      'data', 'result', 'context', 'step', 'dict', 'str', 'int', 'float', 'bool', 'list'}
        keywords = [k for k in keywords if k not in stop_words and len(k) > 2]

        if not keywords:
            return None

        # Search slice library
        results = self.slice_library.search_by_keywords(keywords, language="auto", threshold=0.3)

        if not results:
            logger.debug(f"No slices found for keywords: {keywords[:5]}")
            return None

        # Find best usable slice (skip heavy-lib slices, try next best)
        heavy_libs = ['sklearn', 'pandas', 'numpy', 'tensorflow', 'torch', 'scipy']
        best_slice = None
        best_score = 0

        for candidate, score in results:
            if score < 0.4:
                break  # Below threshold, stop searching
            if not candidate.code_template:
                continue
            if any(lib in candidate.code_template for lib in heavy_libs):
                logger.debug(f"🧩 Skipping {candidate.name} (heavy libs), trying next")
                continue
            best_slice = candidate
            best_score = score
            break

        if not best_slice:
            logger.debug(f"No usable slice found (all heavy or below threshold)")
            return None

        logger.info(f"🧩 Slice match: {best_slice.name} (score={best_score:.2f}) for {spec.name}")

        try:
            code = self._wrap_slice_as_dict_method(best_slice, spec.name, spec=spec)
            logger.info(f"✅ Generated code from slice: {best_slice.name} ({len(code)} chars)")
            return code
        except Exception as e:
            logger.warning(f"Failed to generate code from slice {best_slice.name}: {e}")
            return None

    def _wrap_slice_as_dict_method(self, slice_obj, target_name: str, spec=None) -> str:
        """Wrap a slice's code into an async method with (self, data: Dict) signature.

        Slices define functions with explicit parameters:
          def _calc(self, urgency: int, importance: int) -> float
        But orchestration calls with a single dict:
          await self._calculate_priority(data)

        This wrapper extracts parameters from data dict and calls the slice logic.
        When spec.inputs provides the actual input key names, maps them to slice params.
        """
        import re as _re

        # Get slice's parameter info
        params = []
        for p in slice_obj.inputs:
            default = repr(p.default) if p.default is not None else (
                '0' if p.param_type in ('int', 'float') else
                'False' if p.param_type == 'bool' else
                '""' if p.param_type == 'str' else
                '[]' if 'List' in p.param_type else
                'None'
            )
            params.append((p.name, p.param_type, default))

        # Map spec.inputs keys to slice param names when they differ
        # e.g., spec has "order_amount" but slice expects "order_total"
        spec_keys = list(spec.inputs.keys()) if spec and spec.inputs and isinstance(spec.inputs, dict) else []

        # Build data extraction lines with key mapping
        extract_lines = []
        for idx, (name, ptype, default) in enumerate(params):
            # Try to find matching key from spec.inputs
            data_key = name  # default: use slice's param name
            if spec_keys:
                # Exact match first
                if name in spec_keys:
                    data_key = name
                elif idx < len(spec_keys):
                    # Positional fallback: map by order
                    data_key = spec_keys[idx]
                else:
                    # Fuzzy: find similar key
                    for sk in spec_keys:
                        # Simple similarity: shared words
                        name_parts = set(name.lower().split('_'))
                        sk_parts = set(sk.lower().split('_'))
                        if name_parts & sk_parts:
                            data_key = sk
                            break

            if data_key != name:
                extract_lines.append(f'        {name} = data.get("{data_key}", data.get("{name}", {default}))')
            else:
                extract_lines.append(f'        {name} = data.get("{name}", {default})')

        # Get the slice's code_template (the actual business logic body)
        body = slice_obj.code_template.strip()

        # Remove any leading function definition if present in template
        body = _re.sub(r'^(async\s+)?def\s+\w+\([^)]*\)\s*(->\s*\w+)?\s*:', '', body).strip()

        # Re-indent body: strip original indentation, add 8 spaces (inside try block)
        body_lines = []
        # Find minimum indentation of non-empty lines
        non_empty = [l for l in body.split('\n') if l.strip()]
        min_indent = min((len(l) - len(l.lstrip())) for l in non_empty) if non_empty else 0

        for line in body.split('\n'):
            stripped = line.strip()
            if stripped:
                # Remove original base indent, add 8 spaces for try block
                original_indent = len(line) - len(line.lstrip())
                relative_indent = original_indent - min_indent
                body_lines.append('        ' + '    ' * (relative_indent // 4) + stripped)
            else:
                body_lines.append('')

        body_indented = '\n'.join(body_lines)

        # Build the wrapper method
        extract_section = '\n'.join(extract_lines)

        # Build output key mapping comment for the wrapper
        output_keys = spec.outputs if spec and spec.outputs else []
        output_note = ""
        if output_keys:
            output_note = f"\n        # Expected output keys: {output_keys}"

        # Determine the primary output key name from spec.outputs or slice name
        primary_key = output_keys[0] if output_keys else target_name.lstrip('_')

        code = f'''    async def {target_name}(self, data: Dict[str, Any]) -> Dict:
        """{slice_obj.description}
        (Generated from slice: {slice_obj.id})
        """{output_note}
        try:
{extract_section}

{body_indented}

        except Exception as e:
            logger.error(f"{target_name} failed: {{e}}")
            return {{"error": str(e)}}'''

        # Post-process: ensure function returns a Dict
        # If slice code returns a scalar, wrap the last return statement
        import re as _re2
        # Find return statements that return non-dict values
        lines = code.split('\n')
        fixed_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('return ') and not stripped.startswith('return {') and not stripped.startswith('return {'):
                # e.g., "return priority_score" → "return {"score": priority_score}"
                return_val = stripped[7:].strip()
                if return_val and return_val not in ('None', 'result', '_raw_result'):
                    indent = line[:len(line)-len(line.lstrip())]
                    fixed_lines.append(f'{indent}return {{"{primary_key}": {return_val}}}')
                    continue
            fixed_lines.append(line)
        code = '\n'.join(fixed_lines)

        return code
    
    async def generate(
        self,
        spec: FunctionSpec,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate function code from specification"""
        
        # Always try to find a template first based on category/name
        template = None
        if spec.template_id:
            template = self.template_manager.get_template(spec.template_id)
        else:
            # Try to find template by category or name
            possible_templates = [
                f"{spec.category}_{spec.name}",
                spec.name,
                spec.category,
                spec.name.replace('_', ''),
            ]
            for template_id in possible_templates:
                template = self.template_manager.get_template(template_id)
                if template:
                    logger.info(f"Found template by search: {template_id}")
                    break
        
        if template:
            # Check if template uses heavy external libraries not available at runtime
            if self._template_has_heavy_deps(template):
                logger.warning(f"Template for {spec.name} uses heavy external libraries, skipping → LLM generation")
                template = None

        if template:
            logger.info(f"Using template for: {spec.name}")
            self._generation_stats["template"] += 1

            # Apply customizations if provided
            if spec.customizations:
                code = await self._apply_template_with_llm(
                    template.function_code,
                    spec.customizations,
                    context or {}
                )
            else:
                code = self._clean_template_placeholders(template.function_code)

            # Replace function name using regex to avoid duplication
            import re
            code = re.sub(r'async def \w+\(', f'async def {spec.name}(', code, count=1)

            return code

        # Step 2: Search Slice Library
        has_test_cases = bool(getattr(spec, 'test_cases', None))
        slice_code = self._search_slice_library(spec)
        if slice_code:
            logger.info(f"✅ Using slice from library for: {spec.name}")
            self._generation_stats["slice"] += 1
            return slice_code

        # Step 3: Generate with LLM + syntax check + validate + retry
        import asyncio
        max_attempts = 3  # Always allow retries for syntax errors
        last_code = None
        feedback = ""

        for attempt in range(max_attempts):
            try:
                if attempt == 0:
                    logger.info(f"⚠️ No slice found, generating with LLM: {spec.name}")
                    code = await asyncio.wait_for(
                        self._generate_with_llm(spec, context or {}),
                        timeout=30.0
                    )
                else:
                    logger.info(f"🔄 Retry {attempt}/{max_attempts-1} for {spec.name}: {feedback[:80]}")
                    code = await asyncio.wait_for(
                        self._generate_with_llm_retry(spec, feedback=feedback),
                        timeout=20.0
                    )
            except asyncio.TimeoutError:
                logger.warning(f"LLM timeout for {spec.name} (attempt {attempt+1})")
                continue

            if not code:
                continue
            last_code = code

            # Step 3a: Syntax check (compile) — catch errors BEFORE assembly
            syntax_error = self._check_function_syntax(code, spec.name)
            if syntax_error:
                feedback = syntax_error
                logger.info(f"❌ Syntax error in {spec.name}: {feedback[:80]}")
                continue  # Retry with error feedback

            # Step 3b: Validate against test cases if available
            if getattr(spec, 'test_cases', None):
                validation = self._quick_validate(code, spec)
                if validation["passed"]:
                    logger.info(f"✅ Function {spec.name} passed validation (attempt {attempt+1})")
                    self._register_generated_slice(spec, code)
                    self._generation_stats["llm"] += 1
                    return code
                else:
                    feedback = validation["feedback"]
                    logger.info(f"❌ Validation failed for {spec.name}: {feedback[:80]}")
                    continue  # Retry with feedback
            else:
                logger.info(f"✅ Function {spec.name} syntax OK (attempt {attempt+1})")
                self._register_generated_slice(spec, code)
                self._generation_stats["llm"] += 1
                return code

        # Return last generated code (best effort) but DO NOT register to library —
        # validation failed, registering unvalidated code pollutes the slice library.
        if last_code:
            logger.warning(f"⚠️ {spec.name}: returning unvalidated code (NOT registered to library)")
            self._generation_stats["llm"] += 1
            return last_code

        return self._generate_fallback(spec)

    def _check_function_syntax(self, func_code: str, func_name: str) -> Optional[str]:
        """Check if generated function code has syntax errors.

        Wraps the function in a minimal class and compiles it.
        Returns error message string if syntax error, None if OK.
        """
        # Wrap in minimal class for compilation
        test_code = (
            "import json, math, re, os, logging\n"
            "from datetime import datetime\n"
            "from typing import Dict, Any, List, Optional, Union, Tuple\n"
            "try:\n"
            "    from loguru import logger\n"
            "except ImportError:\n"
            "    logger = logging.getLogger('test')\n"
            "from collections import defaultdict\n"
            "\n"
            "class _Check:\n"
            "    metadata = {}\n"
            + func_code + "\n"
        )
        try:
            compile(test_code, f'<{func_name}>', 'exec')
            return None  # No error
        except SyntaxError as e:
            # Calculate line number relative to function code
            # test_code has 9 header lines before func_code
            func_line = (e.lineno or 0) - 10
            return f"SyntaxError at line {func_line}: {e.msg}"

    def _quick_validate(self, func_code: str, spec: FunctionSpec) -> dict:
        """Quick validation: execute function with test case inputs, check outputs.

        Returns {"passed": bool, "feedback": str}
        """
        import json as _json

        test_cases = getattr(spec, 'test_cases', None)
        if not test_cases:
            return {"passed": True, "feedback": ""}

        # Build a minimal executable wrapper
        # func_code is already indented 4 spaces (class method), so it fits inside a class
        wrapper = (
            "import json, math, re, os, logging\n"
            "from datetime import datetime\n"
            "from typing import Dict, Any, List, Optional, Union, Tuple\n"
            "from dataclasses import dataclass\n"
            "try:\n"
            "    from loguru import logger\n"
            "except ImportError:\n"
            "    logger = logging.getLogger('test')\n"
            "try:\n"
            "    from collections import defaultdict\n"
            "except: pass\n"
            "\n"
            "class _TestAgent:\n"
            "    def __init__(self): pass\n"
            "    metadata = {}\n"
            + func_code + "\n"
            "\n"
            "_agent = _TestAgent()\n"
        )
        try:
            ns = {"__builtins__": __builtins__}
            exec(wrapper, ns)
            agent = ns.get("_agent")
            if not agent:
                return {"passed": False, "feedback": "Could not instantiate test agent"}

            func = getattr(agent, spec.name, None)
            if not func:
                # Try to find any callable method (LLM may rename)
                for attr_name in dir(agent):
                    if attr_name.startswith('_') and not attr_name.startswith('__'):
                        candidate = getattr(agent, attr_name, None)
                        if callable(candidate) and attr_name != '__init__':
                            func = candidate
                            break
            if not func:
                # Method not found in validation wrapper — this is OK,
                # the function will be found when assembled into the full agent class.
                # Don't fail validation for this.
                return {"passed": True, "feedback": ""}

            # Test first test case — only check execution (not output values/keys)
            # Output quality is evaluated later by the full pipeline
            tc_input = test_cases[0].get("input", {})

            try:
                if asyncio.iscoroutinefunction(func):
                    import asyncio as _aio
                    loop = _aio.new_event_loop()
                    result = loop.run_until_complete(func(tc_input))
                    loop.close()
                else:
                    result = func(tc_input)

                # Only fail if function returned an error or None
                if result is None:
                    return {"passed": False, "feedback": "Function returned None"}
                if isinstance(result, dict) and result.get("error"):
                    return {"passed": False, "feedback": f"Runtime error: {result['error'][:60]}"}

                return {"passed": True, "feedback": ""}

            except Exception as e:
                return {"passed": False, "feedback": f"Execution error: {type(e).__name__}: {str(e)[:50]}"}

        except SyntaxError as e:
            return {"passed": False, "feedback": f"Syntax error in generated code: line {e.lineno}"}
        except Exception as e:
            return {"passed": False, "feedback": f"Validation error: {type(e).__name__}: {str(e)[:50]}"}
    
    def _clean_template_placeholders(self, code: str) -> str:
        """Remove LLM_CUSTOMIZE placeholders from template code.

        Templates contain patterns like:
            # [LLM_CUSTOMIZE: data_preparation]
            # Add data preprocessing logic
            {data_preparation}

        Some templates also have bare {placeholder} lines without markers.
        All of these cause NameError at runtime because Python interprets
        {word} as a set literal referencing an undefined variable.
        """
        import re
        cleaned_lines = []
        skip_comment = False
        for line in code.split('\n'):
            stripped = line.strip()
            # Skip [LLM_CUSTOMIZE: ...] comment lines
            if re.match(r'#\s*\[LLM_CUSTOMIZE:', stripped):
                skip_comment = True
                continue
            # Skip description comments following the marker
            if skip_comment and stripped.startswith('#'):
                continue
            skip_comment = False
            # Skip ALL bare {placeholder} lines (with or without marker)
            if re.match(r'^\s*\{[a-z_]+\}\s*$', line):
                continue
            cleaned_lines.append(line)
        result = '\n'.join(cleaned_lines)
        removed = len(code.split('\n')) - len(cleaned_lines)
        if removed > 0:
            logger.debug(f"Cleaned template: removed {removed} placeholder lines")
        return result

    async def _apply_template_with_llm(
        self,
        template_code: str,
        customizations: Dict[str, str],
        context: Dict[str, Any]
    ) -> str:
        """Apply LLM customizations to template"""
        
        code = await self.llm_client.generate_code(
            template_code,
            customizations,
            context
        )
        
        return code
    
    async def _generate_with_llm(
        self,
        spec: FunctionSpec,
        context: Dict[str, Any]
    ) -> str:
        """Generate function completely with LLM"""

        # Include original business rules if available
        business_rules_section = ""
        if hasattr(spec, 'business_rules') and spec.business_rules:
            business_rules_section = f"""
ORIGINAL USER QUERY WITH SPECIFIC BUSINESS RULES:
{spec.business_rules}

YOU MUST implement the EXACT business logic specified above. Extract and implement:
- All formulas (e.g., probability += factor * 0.15)
- All thresholds and caps (e.g., min/max values)
- All calculation steps in the correct order
"""

        # Get domain-specific hint (1-2 lines instead of 20+ "If this is X" blocks)
        domain_hint = DOMAIN_HINTS.get(spec.category, "Implement the core logic for the described task.")

        # Build gap context section if available (from Self-Growing pre-generation)
        gap_section = ""
        if context and context.get("gap_context"):
            gap_descriptions = []
            for gap in context["gap_context"]:
                gap_name = gap.get("name", gap.get("function_name", "unknown"))
                gap_desc = gap.get("description", "")
                gap_score = gap.get("best_match_score", gap.get("score", 0))
                if gap_desc:
                    gap_descriptions.append(f"- {gap_name}: {gap_desc} (library match: {gap_score:.2f})")
            if gap_descriptions:
                gap_section = f"""
MISSING CAPABILITIES (detected by Self-Growing system - no existing templates for these):
{chr(10).join(gap_descriptions)}
You MUST implement the logic for these capabilities from scratch. Do NOT rely on external templates.
"""

        # Build test cases section for LLM guidance
        test_cases_section = self._build_test_cases_section(spec)

        # Extract variable names from business rules formula for input guidance
        input_keys_section = self._build_input_keys_section(spec)

        prompt = f"""Generate a Python async CLASS METHOD with ACTUAL BUSINESS LOGIC.

Method Name: {spec.name}
Category: {spec.category}
Description: {spec.description}
{business_rules_section}{gap_section}
Expected Outputs: {', '.join(spec.outputs)}
{test_cases_section}
DOMAIN HINT: {domain_hint}

SIGNATURE: async def {spec.name}(self, data: Dict[str, Any]) -> Dict:
- Extract values from 'data' dict: value = data.get("key_name", default_value)
{input_keys_section}

RULES:
1. CLASS METHOD with 'self' - async function
2. Implement REAL business logic, NOT placeholders
3. Wrap ALL code in try/except — EVERY try MUST have a matching except
4. Use 'logger' from loguru (already imported - DO NOT import again)
5. If you need standard library modules, use INLINE import inside the function body (e.g., `import string`, `import hashlib`, `import random`, `from collections import defaultdict`). NO nested function definitions.
6. Return a dictionary with computed outputs
7. Start directly with "async def"
8. Maximum 50-60 lines, focus on core logic
9. Use EXACTLY 4 spaces per indentation level
10. Prefer Python standard library. These external libraries ARE allowed (already installed): python-pptx, openpyxl, python-docx, PyPDF2, aiohttp. Use subprocess for system tools (mdfind, pdfgrep, textutil, grep).
11. NEVER use multiline f-strings. Keep f-strings on ONE line. BAD: f"text\n{var}" GOOD: f"text {var}"
12. NEVER leave an empty try block. Always put code INSIDE the try block with proper indentation.
13. Structure: async def → try: → logic → return dict → except: → return error dict
14. Example:
    async def method(self, data: Dict[str, Any]) -> Dict:
        try:
            value = data.get("value", 0)
            op = data.get("operation", "+")
            if op == "+":
                result = value + data.get("b", 0)
            return {{"result": result}}
        except Exception as e:
            return {{"error": str(e)}}

Generate a CONCISE, WORKING method:
"""

        # Call LLM - handle both DirectGeminiClient (returns string) and LLMClient (returns object)
        # Note: max_tokens=4000 to avoid truncation for complex multi-step functions
        # Use lower temperature when exact formula is provided for consistent implementation
        has_formula = hasattr(spec, 'business_rules') and spec.business_rules and any(
            c in str(spec.business_rules) for c in ['=', '+', '-', '*', '/']
        )
        temp = 0.1 if has_formula else 0.5
        response = await self.llm_client.generate(
            prompt,
            temperature=temp,
            max_tokens=4000
        )

        # Handle response based on client type
        if self.use_gemini:
            # DirectGeminiClient returns string directly
            response_content = response if isinstance(response, str) else ""
            response_success = bool(response_content)
        else:
            # LLMClient returns response object
            response_success = getattr(response, 'success', False)
            response_content = getattr(response, 'content', '') if response_success else ''

        if response_success and response_content:
            code = self._extract_code_from_response(response_content)

            # Ensure function name matches spec.name
            if code and 'async def' in code:
                import re
                code = re.sub(r'async def \w+\(', f'async def {spec.name}(', code, count=1)

            # Unified validation: accept if code has basic structure
            if self._is_valid_generated_code(code, spec.name):
                return code

            logger.warning(f"Validation failed for {spec.name}, will retry")
        else:
            error_msg = "Empty response" if not response_content else "Unknown error"
            if not self.use_gemini and hasattr(response, 'error'):
                error_msg = response.error
            logger.error(f"LLM generation failed for {spec.name}: {error_msg}")

        # Retry with shorter prompt before falling back to stub
        retry_code = await self._generate_with_llm_retry(spec)
        if retry_code:
            return retry_code

        # Return a stub function as last resort
        return self._generate_fallback(spec)

    def _is_valid_generated_code(self, code: str, func_name: str) -> bool:
        """Unified validation: accept LLM-generated code if it has basic structure."""
        if not code:
            logger.warning(f"Empty code extracted for {func_name}")
            return False

        if 'async def' not in code:
            logger.warning(f"No 'async def' in code for {func_name}")
            return False

        line_count = len(code.strip().split('\n'))
        has_return = 'return' in code

        if line_count > 5 and has_return:
            logger.info(f"Generated logic for {func_name} ({line_count} lines)")
            return True

        logger.warning(f"Code too simple for {func_name} (lines={line_count}, return={has_return})")
        return False

    async def _generate_with_llm_retry(self, spec: FunctionSpec, feedback: str = "") -> Optional[str]:
        """Retry LLM generation with a shorter, more focused prompt."""
        try:
            domain_hint = DOMAIN_HINTS.get(spec.category, "Implement the described logic.")

            # Build test case examples for retry (compact format)
            tc_hint = ""
            if getattr(spec, 'test_cases', None):
                tc_lines = []
                for i, tc in enumerate(spec.test_cases[:2]):
                    tc_lines.append(f"  Test{i+1}: {json.dumps(tc.get('input', {}), ensure_ascii=False)} → {json.dumps(tc.get('expected', {}), ensure_ascii=False)}")
                tc_hint = "\nMUST match these test cases:\n" + "\n".join(tc_lines)

            prompt = f"""Generate Python async method. REAL logic, NOT placeholder.
{feedback}
async def {spec.name}(self, data: Dict[str, Any]) -> Dict:
    # {spec.description}
    # Domain: {domain_hint}
    # Inputs: {', '.join(spec.inputs.keys())}
    # Outputs: {', '.join(spec.outputs)}
{tc_hint}
Rules: class method, try/except (EVERY try MUST have except), use logger (already imported), INLINE imports for stdlib, max 40 lines.
CRITICAL: NO multiline f-strings. NO empty try blocks. EVERY try must have matching except.
Structure: async def → try: → logic → return dict → except: → return error dict.
ONLY use standard library.
"""
            import asyncio
            response = await asyncio.wait_for(
                self.llm_client.generate(prompt, temperature=0.7, max_tokens=3000),
                timeout=20.0
            )

            if self.use_gemini:
                content = response if isinstance(response, str) else ""
            else:
                content = getattr(response, 'content', '') if getattr(response, 'success', False) else ''

            if content:
                code = self._extract_code_from_response(content)
                if code and 'async def' in code:
                    import re
                    code = re.sub(r'async def \w+\(', f'async def {spec.name}(', code, count=1)
                if self._is_valid_generated_code(code, f"{spec.name}_retry"):
                    logger.info(f"Retry succeeded for {spec.name}")
                    return code

        except asyncio.TimeoutError:
            logger.warning(f"LLM retry timeout for {spec.name}")
        except Exception as e:
            logger.warning(f"LLM retry failed for {spec.name}: {e}")

        return None

    def _build_input_keys_section(self, spec: FunctionSpec) -> str:
        """Build input keys guidance for LLM.

        Priority: spec.inputs (from input_schema) > formula variables > generic fallback.
        This ensures the generated function uses the EXACT key names that callers will provide.
        """
        import re as _re

        # Priority 1: Use spec.inputs if available (from input_schema or capability map)
        if spec.inputs and isinstance(spec.inputs, dict):
            # Filter out generic entries like "data": "Any"
            real_inputs = {k: v for k, v in spec.inputs.items()
                          if k not in ('data', 'query', 'options') and v not in ('Any',)}
            if real_inputs:
                lines = ["\nINPUT VARIABLES (extract EXACTLY these keys from data dict):"]
                for k, v in real_inputs.items():
                    default = '0' if v in ('int', 'float') else 'False' if v == 'bool' else '""' if v == 'str' else '[]' if v == 'list' else '{}'
                    lines.append(f'- {k} = data.get("{k}", {default})  # type: {v}')
                lines.append(f"\nCRITICAL: Use EXACTLY these key names. Do NOT rename them.")
                return "\n".join(lines)

        # Priority 2: Extract variable names from business rules formula
        if hasattr(spec, 'business_rules') and spec.business_rules:
            rules_str = str(spec.business_rules)
            all_names = set(_re.findall(r'\b([a-z_][a-z0-9_]*)\b', rules_str))
            exclude = {'min', 'max', 'abs', 'round', 'int', 'float', 'str', 'len', 'sum',
                       'true', 'false', 'none', 'and', 'or', 'not', 'if', 'else', 'for', 'in',
                       'return', 'def', 'class', 'import', 'from', 'async', 'await', 'self',
                       'result', 'data', 'dict', 'list', 'set', 'step', 'this', 'is', 'of',
                       'where', 'no', 'at', 'capped', 'discount', 'bonus', 'tier'}
            var_names = sorted(all_names - exclude)
            if var_names:
                lines = ["\nINPUT VARIABLES (extract these from data dict):"]
                for v in var_names:
                    lines.append(f'- {v} = data.get("{v}", 0)')
                lines.append(f"\nCRITICAL: Use EXACTLY these variable names.")
                return "\n".join(lines)

        # Fallback: generic
        return """
INPUT: Extract relevant values from `data` dict using data.get("key_name", default_value).
"""

    def _build_test_cases_section(self, spec: FunctionSpec) -> str:
        """Build structured test cases section for LLM prompt."""
        if not getattr(spec, 'test_cases', None):
            return ""

        lines = ["\nTEST CASES (your function MUST produce these EXACT outputs for the given inputs):"]
        for i, tc in enumerate(spec.test_cases[:3]):  # Max 3 examples
            tc_input = tc.get('input', {})
            tc_expected = tc.get('expected', {})
            tc_tolerance = tc.get('tolerance', 0)

            lines.append(f"\n  Test {i+1}:")
            lines.append(f"    Input:    {json.dumps(tc_input, ensure_ascii=False)}")
            lines.append(f"    Expected: {json.dumps(tc_expected, ensure_ascii=False)}")
            if tc_tolerance:
                lines.append(f"    Tolerance: ±{tc_tolerance}")

        # Extract output structure guidance from test cases
        first_expected = spec.test_cases[0].get('expected', {})
        if isinstance(first_expected, dict):
            lines.append(f"\nOUTPUT STRUCTURE (return dict with EXACTLY these keys):")
            lines.append("  return {")
            for k, v in first_expected.items():
                if isinstance(v, str):
                    # Collect all possible string values
                    str_vals = set()
                    for tc in spec.test_cases:
                        ev = tc.get('expected', {})
                        if isinstance(ev, dict) and k in ev and isinstance(ev[k], str):
                            str_vals.add(ev[k])
                    lines.append(f'      "{k}": <str>  # possible values: {sorted(str_vals)}')
                elif isinstance(v, bool):
                    lines.append(f'      "{k}": <bool>')
                elif isinstance(v, int):
                    lines.append(f'      "{k}": <int>')
                elif isinstance(v, float):
                    lines.append(f'      "{k}": <float>')
                else:
                    lines.append(f'      "{k}": <{type(v).__name__}>')
            lines.append("  }")

        return "\n".join(lines)

    def _format_inputs(self, inputs: Dict[str, str]) -> str:
        """Format inputs for prompt"""

        formatted = []
        for name, type_hint in inputs.items():
            formatted.append(f"- {name}: {type_hint}")

        return '\n'.join(formatted)
    
    def _extract_code_from_response(self, response: str) -> str:
        """Extract code from LLM response"""
        
        # Remove markdown code blocks
        if "```python" in response:
            start = response.find("```python") + 9
            end = response.find("```", start)
            if end > start:
                code = response[start:end].strip()
            else:
                code = response.strip()
        elif "```" in response:
            start = response.find("```") + 3
            end = response.find("```", start)
            if end > start:
                code = response[start:end].strip()
            else:
                code = response.strip()
        else:
            code = response.strip()
        
        # Clean up the code
        lines = code.split('\n')
        cleaned_lines = []
        skip_class_def = False
        found_async_def = False
        
        for line in lines:
            # Skip only TOP-LEVEL import statements (no indentation)
            # Preserve indented imports inside function bodies (e.g., "    import string")
            stripped = line.lstrip()
            if (stripped.startswith('import ') or stripped.startswith('from ')) and (len(line) == len(stripped)):
                continue
            
            # Skip class definitions and decorators
            if line.strip().startswith('class '):
                skip_class_def = True
                continue
            if line.strip().startswith('@'):
                continue
                
            # Start capturing from async def
            if 'async def' in line:
                found_async_def = True
                skip_class_def = False
            
            # If we found async def, start adding lines
            if found_async_def:
                # Fix indentation if this was inside a class
                if line and line[0] in ' \t' and 'async def' in line:
                    # Remove one level of indentation
                    if line.startswith('    '):
                        line = line[4:]
                    elif line.startswith('\t'):
                        line = line[1:]
                cleaned_lines.append(line)
            elif not skip_class_def:
                # Include lines that aren't part of a class definition
                if line.strip():
                    cleaned_lines.append(line)
        
        # Remove leading empty lines
        while cleaned_lines and not cleaned_lines[0].strip():
            cleaned_lines.pop(0)
        
        # If we didn't find an async def, look for a regular def
        if not found_async_def and not cleaned_lines:
            for line in lines:
                if 'def ' in line and not line.strip().startswith('class'):
                    # Convert to async def if needed
                    if 'async def' not in line:
                        line = line.replace('def ', 'async def ')
                    cleaned_lines.append(line)
                    # Get the rest of the function
                    start_index = lines.index(line)
                    indent_level = len(line) - len(line.lstrip())
                    for next_line in lines[start_index + 1:]:
                        if next_line.strip() and not next_line[indent_level:].startswith(' '):
                            # End of function
                            break
                        cleaned_lines.append(next_line)
                    break
        
        result = '\n'.join(cleaned_lines)

        # Final validation - ensure it starts with async def
        if result and 'async def' not in result:
            # Try to extract just the method body if all else fails
            if 'def ' in result:
                result = result.replace('def ', 'async def ', 1)

        # Auto-inject missing stdlib imports into function body
        # LLM often uses stdlib modules without importing them
        result = self._inject_missing_imports(result)

        return result

    def _inject_missing_imports(self, code: str) -> str:
        """Auto-detect stdlib module usage and inject inline imports if missing."""
        # Map module references to import statements
        stdlib_modules = {
            're.': 'import re',
            'string.': 'import string',
            'random.': 'import random',
            'hashlib.': 'import hashlib',
            'secrets.': 'import secrets',
            'math.': 'import math',
            'collections.': 'import collections',
            'itertools.': 'import itertools',
            'functools.': 'import functools',
            'uuid.': 'import uuid',
            'base64.': 'import base64',
            'html.': 'import html',
            'urllib.': 'import urllib',
            'decimal.': 'import decimal',
            'statistics.': 'import statistics',
            'textwrap.': 'import textwrap',
            'difflib.': 'import difflib',
            'csv.': 'import csv',
            'io.': 'import io',
            'pathlib.': 'import pathlib',
            'copy.': 'import copy',
            'struct.': 'import struct',
            'datetime.': 'import datetime',
            'json.': 'import json',
            'os.path': 'import os',
            'os.environ': 'import os',
        }

        needed_imports = []
        for ref, imp in stdlib_modules.items():
            if ref in code and imp not in code:
                needed_imports.append(imp)

        if not needed_imports:
            return code

        # Find the function body start (after 'async def ...:' line)
        lines = code.split('\n')
        for i, line in enumerate(lines):
            if line.strip().startswith('async def ') and line.rstrip().endswith(':'):
                # Find the indentation level of the function body
                body_indent = '        '  # default 8 spaces (method body)
                for j in range(i + 1, len(lines)):
                    if lines[j].strip():
                        body_indent = lines[j][:len(lines[j]) - len(lines[j].lstrip())]
                        break
                # Insert imports right after the def line (before docstring/body)
                import_lines = [f'{body_indent}{imp}' for imp in needed_imports]
                lines = lines[:i+1] + import_lines + lines[i+1:]
                break

        return '\n'.join(lines)
    
    def _template_has_heavy_deps(self, template) -> bool:
        """Check if a template requires heavy external libraries not available at runtime."""
        # Check required_imports field
        if hasattr(template, 'required_imports') and template.required_imports:
            for imp in template.required_imports:
                imp_lower = imp.lower()
                for lib in HEAVY_EXTERNAL_LIBRARIES:
                    if lib in imp_lower:
                        logger.info(f"Template uses heavy library: {lib} (from import: {imp})")
                        return True

        # Check function code for import statements referencing heavy libs
        if hasattr(template, 'function_code') and template.function_code:
            for line in template.function_code.split('\n'):
                stripped = line.strip()
                if stripped.startswith(('import ', 'from ')):
                    stripped_lower = stripped.lower()
                    for lib in HEAVY_EXTERNAL_LIBRARIES:
                        if lib in stripped_lower:
                            logger.info(f"Template code imports heavy library: {lib}")
                            return True

        return False

    def _generate_fallback(self, spec: FunctionSpec) -> str:
        """Generate a stub function as fallback, using LogicSynthesizer when available"""

        # Skip LogicSynthesizer if business_rules are present (need LLM for custom logic)
        # LogicSynthesizer only has hardcoded templates that ignore specific business rules
        has_business_rules = hasattr(spec, 'business_rules') and spec.business_rules

        if has_business_rules:
            logger.info(f"Skipping LogicSynthesizer for {spec.name} - has custom business rules, needs LLM")
            return self._generate_basic_stub(spec)

        # Try LogicSynthesizer for generic domain-specific logic (no custom rules)
        if self.logic_synthesizer and LOGIC_SYNTHESIZER_AVAILABLE:
            try:
                return self._generate_with_synthesizer(spec)
            except Exception as e:
                logger.warning(f"LogicSynthesizer failed for {spec.name}: {e}, using stub")

        # Fallback to basic stub
        return self._generate_basic_stub(spec)

    def _generate_with_synthesizer(self, spec: FunctionSpec) -> str:
        """Generate function using LogicSynthesizer"""

        # Map category to DomainType
        category_to_domain = {
            'calculation': DomainType.CALCULATION,
            'analysis': DomainType.ANALYSIS,
            'prediction': DomainType.PREDICTION,
            'data_io': DomainType.DATA_PROCESSING,
            'processing': DomainType.DATA_PROCESSING,
            'transformation': DomainType.DATA_PROCESSING,
            'finance': DomainType.FINANCE,
            'social': DomainType.SOCIAL,
            'privacy': DomainType.PRIVACY,
            'integration': DomainType.INTEGRATION,
            'visualization': DomainType.VISUALIZATION,
            'vision': DomainType.GENERAL,
            'custom': DomainType.GENERAL,
            # Business analytics uses ANALYSIS domain for scoring, segmentation, prediction
            'business_analytics': DomainType.ANALYSIS,
        }

        domain = category_to_domain.get(spec.category, DomainType.GENERAL)

        # Create requirement spec - include business_rules in description if available
        description_with_rules = spec.description
        if hasattr(spec, 'business_rules') and spec.business_rules:
            description_with_rules = f"{spec.description}\n\nORIGINAL USER QUERY WITH BUSINESS RULES:\n{spec.business_rules}"

        requirements = RequirementSpec(
            name=spec.name,
            domain=domain,
            description=description_with_rules,
            inputs=spec.inputs,
            outputs=spec.outputs,
            complexity=0.5,  # Default complexity
            resources={},
            constraints=[]
        )

        # Synthesize business logic
        business_logic = self.logic_synthesizer.synthesize(requirements)

        # Generate extraction code for each input parameter
        extraction_lines = []
        for name, type_hint in spec.inputs.items():
            if type_hint.startswith("Optional"):
                extraction_lines.append(f'{name} = data.get("{name}", None)')
            elif type_hint in ["int", "float"]:
                extraction_lines.append(f'{name} = data.get("{name}", 0)')
            elif type_hint == "str":
                extraction_lines.append(f'{name} = data.get("{name}", "")')
            elif type_hint.startswith("List"):
                extraction_lines.append(f'{name} = data.get("{name}", [])')
            elif type_hint.startswith("Dict") or type_hint == "Dict":
                extraction_lines.append(f'{name} = data.get("{name}", {{}})')
            elif type_hint == "pd.DataFrame":
                extraction_lines.append(f'{name} = data.get("{name}", pd.DataFrame())')
            else:
                extraction_lines.append(f'{name} = data.get("{name}")')
        extraction_code = "\n    ".join(extraction_lines)

        # Build complete function with synthesized logic
        # 🔥 FIX: Use 4 spaces to match template indentation (not 8)
        validation_code = "\n    ".join(business_logic.validations) if business_logic.validations else "pass  # No validations"

        code = f'''
async def {spec.name}(self, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    {spec.description}

    Generated by LogicSynthesizer (Paper1 methodology)
    Domain: {domain.value}

    Args:
        data: Dict containing {', '.join(spec.inputs.keys())}

    Returns:
        Dict containing: {', '.join(spec.outputs)}
    """

    # Extract inputs from data dict
    {extraction_code}

    # Input Validations (Generated)
    {validation_code}

    try:
{business_logic.core_algorithm}
{business_logic.error_handling}
'''

        logger.info(f"Generated {spec.name} with LogicSynthesizer (domain: {domain.value})")
        return code

    def _generate_basic_stub(self, spec: FunctionSpec) -> str:
        """Generate a basic stub function as last resort"""

        # Generate extraction code for each input parameter
        extraction_lines = []
        for name, type_hint in spec.inputs.items():
            if type_hint.startswith("Optional"):
                extraction_lines.append(f'{name} = data.get("{name}", None)')
            elif type_hint in ["int", "float"]:
                extraction_lines.append(f'{name} = data.get("{name}", 0)')
            elif type_hint == "str":
                extraction_lines.append(f'{name} = data.get("{name}", "")')
            elif type_hint.startswith("List"):
                extraction_lines.append(f'{name} = data.get("{name}", [])')
            elif type_hint.startswith("Dict") or type_hint == "Dict":
                extraction_lines.append(f'{name} = data.get("{name}", {{}})')
            elif type_hint == "pd.DataFrame":
                extraction_lines.append(f'{name} = data.get("{name}", pd.DataFrame())')
            else:
                extraction_lines.append(f'{name} = data.get("{name}")')
        extraction_code = "\n        ".join(extraction_lines)

        code = f'''
async def {spec.name}(self, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    {spec.description}

    Args:
        data: Dict containing {', '.join(spec.inputs.keys())}

    Returns:
        Dict containing: {', '.join(spec.outputs)}
    """

    result = {{}}

    try:
        # Extract inputs from data dict
        {extraction_code}

        # Input validation
        if not all([{', '.join(spec.inputs.keys())}]):
            raise ValueError("Missing required inputs")

        # Core logic placeholder
        logger.info(f"Executing {spec.name}")

        # Generate outputs
        {self._generate_output_placeholders(spec.outputs)}

        logger.info(f"{spec.name} completed successfully")
        return result

    except Exception as e:
        logger.error(f"{spec.name} failed: {{e}}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''

        return code
    
    def _format_docstring_args(self, inputs: Dict[str, str]) -> str:
        """Format arguments for docstring"""
        
        args = []
        for name, type_hint in inputs.items():
            args.append(f"{name}: {type_hint}")
        
        return '\n        '.join(args)
    
    def _generate_output_placeholders(self, outputs: List[str]) -> str:
        """Generate placeholder code for outputs"""
        
        placeholders = []
        for output in outputs:
            if output == "dataframe":
                placeholders.append(f'result["{output}"] = pd.DataFrame()')
            elif output == "metadata":
                placeholders.append(f'result["{output}"] = {{"timestamp": datetime.now().isoformat()}}')
            elif output == "status":
                placeholders.append(f'result["{output}"] = "success"')
            else:
                placeholders.append(f'result["{output}"] = None  # TODO: Generate {output}')
        
        return '\n        '.join(placeholders)