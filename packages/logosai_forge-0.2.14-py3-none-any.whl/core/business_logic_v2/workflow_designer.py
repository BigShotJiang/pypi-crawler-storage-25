"""
Workflow Designer for Function Integration
"""

from typing import List, Dict, Any, Optional
from .query_analyzer import QueryAnalysis, FunctionSpec
from .workflow_orchestrator import Workflow, WorkflowStep, WorkflowStrategy
from loguru import logger


class WorkflowDesigner:
    """Designs optimal workflows for function integration"""
    
    def __init__(self):
        logger.info("Workflow designer initialized")
    
    def create_workflow(
        self,
        function_specs: List[FunctionSpec],
        analysis: QueryAnalysis
    ) -> Workflow:
        """Create workflow from function specifications"""
        
        # Determine workflow strategy
        strategy = self._determine_strategy(function_specs, analysis)
        
        # Create workflow steps
        steps = self._create_steps(function_specs, strategy)
        
        # Optimize step order
        steps = self._optimize_step_order(steps)
        
        workflow = Workflow(
            steps=steps,
            strategy=strategy,
            error_handling="log_and_continue" if analysis.complexity_score > 0.7 else "stop_on_error",
            parallel_limit=3,
            timeout=300
        )
        
        logger.info(f"Workflow created with {len(steps)} steps, strategy: {strategy.value}")
        
        return workflow
    
    def _determine_strategy(
        self,
        function_specs: List[FunctionSpec],
        analysis: QueryAnalysis
    ) -> WorkflowStrategy:
        """Determine optimal workflow strategy"""
        
        # Check for pipeline pattern
        if self._is_pipeline_workflow(function_specs):
            return WorkflowStrategy.PIPELINE
        
        # Check for parallel opportunities
        if self._has_parallel_opportunities(function_specs):
            return WorkflowStrategy.PARALLEL
        
        # Check for loop requirements
        if any(keyword in analysis.keywords for keyword in ["iterate", "loop", "repeat"]):
            return WorkflowStrategy.LOOP
        
        # Default to sequential
        return WorkflowStrategy.SEQUENTIAL
    
    def _is_pipeline_workflow(self, function_specs: List[FunctionSpec]) -> bool:
        """Check if functions form a pipeline"""
        
        # Check if outputs of one function feed inputs of next
        for i in range(len(function_specs) - 1):
            current = function_specs[i]
            next_func = function_specs[i + 1]
            
            # Check if any output matches any input
            for output in current.outputs:
                for input_key in next_func.inputs.keys():
                    if output in input_key or input_key in output:
                        return True
        
        return False
    
    def _has_parallel_opportunities(self, function_specs: List[FunctionSpec]) -> bool:
        """Check for parallel execution opportunities"""
        
        # Functions in same category often can run in parallel
        categories = [spec.category for spec in function_specs]
        
        # If multiple analysis or transformation functions, they might be parallel
        if categories.count("analysis") > 1 or categories.count("transformation") > 1:
            return True
        
        return False
    
    def _create_steps(
        self,
        function_specs: List[FunctionSpec],
        strategy: WorkflowStrategy
    ) -> List[WorkflowStep]:
        """Create workflow steps from function specifications"""
        
        steps = []
        
        for i, spec in enumerate(function_specs):
            # Determine dependencies
            dependencies = []
            if strategy == WorkflowStrategy.PIPELINE and i > 0:
                # In pipeline, each step depends on previous
                dependencies = [function_specs[i-1].name]
            elif strategy == WorkflowStrategy.SEQUENTIAL and i > 0:
                # In sequential, might depend on previous data operations
                if spec.category in ["analysis", "transformation", "visualization"]:
                    # These usually need data from previous steps
                    for j in range(i):
                        if function_specs[j].category == "data_io":
                            dependencies.append(function_specs[j].name)
                            break
            
            step = WorkflowStep(
                function_name=spec.name,
                inputs=spec.inputs,
                outputs=spec.outputs,
                dependencies=dependencies,
                condition=None,
                strategy=strategy
            )
            
            steps.append(step)
        
        return steps
    
    def _optimize_step_order(self, steps: List[WorkflowStep]) -> List[WorkflowStep]:
        """Optimize step execution order"""
        
        # Sort by dependencies (topological sort)
        sorted_steps = []
        remaining = steps.copy()
        
        while remaining:
            # Find steps with no unresolved dependencies
            ready = []
            for step in remaining:
                if all(dep in [s.function_name for s in sorted_steps] 
                      for dep in step.dependencies):
                    ready.append(step)
            
            if not ready:
                # No progress possible, add remaining as is
                sorted_steps.extend(remaining)
                break
            
            # Add ready steps (prefer data_io first, then others)
            ready.sort(key=lambda s: 0 if "load" in s.function_name or "read" in s.function_name else 1)
            sorted_steps.extend(ready)
            
            # Remove from remaining
            for step in ready:
                remaining.remove(step)
        
        return sorted_steps