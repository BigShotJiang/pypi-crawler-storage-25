"""
Template-Based Agent Code Generator
템플릿 기반 에이전트 코드 생성기
"""

import os
import json
import asyncio
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import re
from pathlib import Path

from loguru import logger


class TemplateBasedGenerator:
    """
    템플릿 기반 에이전트 생성기
    - 템플릿 자동 선택
    - 비즈니스 로직만 LLM 생성
    - 코드 조립 및 검증
    """
    
    def __init__(self, templates_dir: str = None):
        if templates_dir is None:
            # 현재 파일의 부모 디렉토리에서 templates 폴더 찾기
            current_file = Path(__file__).resolve()
            forge_root = current_file.parent.parent  # forge/ 디렉토리
            templates_dir = forge_root / "templates"
        self.templates_dir = Path(templates_dir)
        self.template_registry = self._load_template_registry()
        self.category_mapping = self._build_category_mapping()
        
    def _load_template_registry(self) -> Dict[str, Any]:
        """템플릿 레지스트리를 로드합니다."""
        registry_path = self.templates_dir / "template_registry.json"
        
        # 기본 레지스트리 구조
        registry = {
            "templates": {
                # 데이터 분석 카테고리
                "csv_excel_analyzer": {
                    "file": "specialized/csv_excel_analyzer_template.py.template",
                    "category": "data_analysis",
                    "name": "CSV/Excel 데이터 분석기",
                    "keywords": ["csv", "excel", "데이터 분석", "통계", "차트", "대시보드"],
                    "description": "데이터 품질 검증, 통계 분석, 이상치 탐지"
                },
                "kpi_dashboard": {
                    "file": "specialized/kpi_dashboard_template.py.template",
                    "category": "data_analysis",
                    "name": "실시간 KPI 대시보드",
                    "keywords": ["kpi", "대시보드", "실시간", "모니터링", "지표"],
                    "description": "실시간 비즈니스 지표 모니터링"
                },
                
                # 웹 자동화 카테고리
                "price_monitoring": {
                    "file": "specialized/price_monitoring_template.py.template",
                    "category": "web_automation",
                    "name": "스마트 가격 모니터링",
                    "keywords": ["가격", "모니터링", "경쟁사", "가격 추적", "동적 가격"],
                    "description": "경쟁사 가격 추적 및 전략 제안"
                },
                "social_media_monitor": {
                    "file": "specialized/social_media_monitor_template.py.template",
                    "category": "web_automation",
                    "name": "소셜 미디어 모니터링",
                    "keywords": ["소셜", "sns", "브랜드", "멘션", "트렌드"],
                    "description": "브랜드 멘션과 트렌드 추적"
                },
                
                # AI/ML 카테고리
                "automl_pipeline": {
                    "file": "specialized/automl_pipeline_template.py.template",
                    "category": "ai_ml",
                    "name": "자동 ML 파이프라인",
                    "keywords": ["ml", "머신러닝", "자동", "모델", "학습", "예측"],
                    "description": "코딩 없는 머신러닝 모델 구축"
                },
                "computer_vision": {
                    "file": "specialized/computer_vision_template.py.template",
                    "category": "ai_ml",
                    "name": "컴퓨터 비전 분석기",
                    "keywords": ["이미지", "비디오", "객체 탐지", "얼굴 인식", "ocr"],
                    "description": "이미지와 비디오 분석"
                },
                
                # 비즈니스 자동화 카테고리
                "contract_analyzer": {
                    "file": "specialized/contract_analyzer_template.py.template",
                    "category": "business_automation",
                    "name": "스마트 계약서 분석기",
                    "keywords": ["계약서", "법률", "문서", "리스크", "조항"],
                    "description": "법률 문서 분석 및 리스크 식별"
                },
                "hr_screening": {
                    "file": "specialized/hr_screening_template.py.template",
                    "category": "business_automation",
                    "name": "HR 후보자 스크리닝",
                    "keywords": ["이력서", "채용", "hr", "후보자", "스크리닝"],
                    "description": "이력서 분석 및 후보자 추천"
                },
                
                # 기본 템플릿 (폴백용)
                "comprehensive": {
                    "file": "logosai_agent_template.py.template",
                    "category": "general",
                    "name": "종합 에이전트",
                    "keywords": [],
                    "description": "범용 에이전트 템플릿"
                }
            },
            "categories": {
                "data_analysis": "데이터 분석 & BI",
                "web_automation": "웹 자동화 & 스크래핑",
                "ai_ml": "AI/ML 도구",
                "business_automation": "비즈니스 자동화",
                "security": "보안 & 모니터링",
                "communication": "커뮤니케이션",
                "general": "일반"
            }
        }
        
        # 실제 파일이 있으면 로드
        if registry_path.exists():
            try:
                with open(registry_path, 'r', encoding='utf-8') as f:
                    loaded_registry = json.load(f)
                    registry.update(loaded_registry)
            except Exception as e:
                logger.warning(f"레지스트리 로드 실패, 기본값 사용: {e}")
        
        return registry
    
    def _build_category_mapping(self) -> Dict[str, List[str]]:
        """카테고리별 템플릿 매핑을 구축합니다."""
        mapping = {}
        for template_id, template_info in self.template_registry["templates"].items():
            category = template_info["category"]
            if category not in mapping:
                mapping[category] = []
            mapping[category].append(template_id)
        return mapping
    
    async def select_template(self, user_request: str, metadata: Dict[str, Any] = None) -> Tuple[str, float]:
        """
        사용자 요청에 가장 적합한 템플릿을 선택합니다.
        
        Returns:
            Tuple[template_id, confidence_score]
        """
        scores = {}
        request_lower = user_request.lower()
        
        # 각 템플릿에 대한 점수 계산
        for template_id, template_info in self.template_registry["templates"].items():
            score = 0.0
            
            # 키워드 매칭
            for keyword in template_info["keywords"]:
                if keyword.lower() in request_lower:
                    score += 0.3
            
            # 카테고리 매칭 (메타데이터에 카테고리 힌트가 있는 경우)
            if metadata and metadata.get("category") == template_info["category"]:
                score += 0.5
            
            # 설명 매칭
            if template_info["description"]:
                desc_keywords = template_info["description"].lower().split()
                for word in desc_keywords:
                    if len(word) > 3 and word in request_lower:
                        score += 0.1
            
            scores[template_id] = min(score, 1.0)  # 최대 1.0
        
        # 최고 점수 템플릿 선택
        if not scores:
            return "comprehensive", 0.5  # 기본 템플릿
        
        best_template = max(scores.items(), key=lambda x: x[1])
        
        # 점수가 너무 낮으면 기본 템플릿 사용
        if best_template[1] < 0.2:
            return "comprehensive", 0.5
        
        logger.info(f"선택된 템플릿: {best_template[0]} (점수: {best_template[1]:.2f})")
        return best_template
    
    async def generate_business_logic(self, template_id: str, user_request: str, 
                                    llm_client: Any) -> Dict[str, str]:
        """
        선택된 템플릿에 맞는 비즈니스 로직 생성
        점진적 마이그레이션: 새로운 안전 시스템 우선 사용
        """
        logger.info(f"📋 Starting business logic generation for template: {template_id}")
        logger.info(f"📝 User request: {user_request[:100]}...")
        
        # 🛡️ NEW: Pattern Template Integration System
        if self._should_use_pattern_integration(template_id, user_request):
            logger.info("🔗 Using Pattern Template Integration System")
            try:
                from .pattern_template_integrator import get_pattern_integrator
                integrator = get_pattern_integrator()
                
                pattern_result = await integrator.enhanced_generate_business_logic(
                    template_id, user_request, llm_client
                )
                logger.info(f"✅ Pattern integration succeeded with method: {pattern_result.get('generation_method', 'unknown')}")
                return pattern_result
            except Exception as e:
                logger.error(f"❌ Pattern integration failed, falling back: {e}")
                # Fall through to next system
        
        # 🛡️ BACKUP: Safety-first generation system
        if self._should_use_new_system(template_id):
            logger.info("🆕 Using NEW safety-first generation system")
            try:
                new_result = await self._generate_business_logic_with_safety_net(template_id, user_request, llm_client)
                logger.info(f"✅ New system succeeded with method: {new_result.get('generation_method', 'unknown')}")
                return new_result
            except Exception as e:
                logger.error(f"❌ New system failed, falling back to legacy: {e}")
                # Fall through to legacy system
        
        # 🔄 LEGACY: 기존 시스템 (점진적으로 교체될 예정)
        logger.info("🔄 Using LEGACY generation system")
        
        template_info = self.template_registry["templates"].get(template_id)
        if not template_info:
            logger.error(f"Template not found: {template_id}")
            raise ValueError(f"템플릿을 찾을 수 없습니다: {template_id}")
        
        logger.info(f"✅ Template found: {template_info['name']}")
        logger.info(f"📂 Category: {template_info['category']}")
        
        # 템플릿별 프롬프트 생성
        prompts = self._get_template_specific_prompts(template_id, user_request)
        logger.info(f"📋 Generated {len(prompts)} prompts for sections: {list(prompts.keys())}")
        
        business_logic = {}
        
        # 각 비즈니스 로직 섹션별로 생성
        for section, prompt in prompts.items():
            try:
                logger.info(f"🔧 Generating section: {section}")
                logger.debug(f"Prompt preview: {prompt[:200]}...")
                
                response = await llm_client.invoke(prompt)
                # response 객체에서 실제 내용 추출
                if hasattr(response, 'content'):
                    raw_response = response.content
                elif isinstance(response, str):
                    raw_response = response
                else:
                    raw_response = str(response)
                
                # LLM이 에러 메시지를 반환한 경우 처리
                if raw_response == "MAIN_LOGIC" or "MAIN_LOGIC" in raw_response[:20]:
                    logger.warning(f"⚠️ LLM returned MAIN_LOGIC error, using fallback")
                    raise ValueError("LLM returned MAIN_LOGIC placeholder")
                logger.info(f"🔍 Raw LLM response: {raw_response[:500] if raw_response else 'None'}...")  # 응답 내용 로깅
                raw_response_len = len(raw_response) if raw_response else 0
                logger.info(f"📥 LLM response received for {section}: {raw_response_len} chars")
                
                # Parse JSON response
                cleaned_code = self._parse_json_code_response(raw_response)
                cleaned_len = len(cleaned_code)
                logger.info(f"🧹 Parsed code for {section}: {cleaned_len} chars")
                
                # Verify no backticks in result
                backtick_count = cleaned_code.count('```')
                if backtick_count > 0:
                    logger.warning(f"⚠️ Found {backtick_count} backticks after JSON parsing, applying cleanup")
                    cleaned_code = self._clean_code_response(cleaned_code)
                    final_count = cleaned_code.count('```')
                    if final_count == 0:
                        logger.info(f"✅ Successfully removed all backticks")
                    else:
                        logger.error(f"❌ Still {final_count} backticks remain")
                else:
                    logger.info(f"✅ No backticks in parsed code for {section}")
                
                business_logic[section] = cleaned_code
                logger.info(f"✅ Successfully generated {section}")
                
            except Exception as e:
                logger.error(f"❌ Failed to generate {section}: {str(e)}")
                logger.error(f"Error type: {type(e).__name__}")
                # 실패 시 기본 구현 제공
                fallback = self._get_fallback_implementation(section)
                logger.info(f"🔄 Using fallback implementation for {section}: {len(fallback)} chars")
                business_logic[section] = fallback
        
        # 샘플 코드 생성
        if "_agentic_analysis" in business_logic:
            logger.info("📝 Generating sample execution code")
            try:
                sample_code = await self._generate_sample_code(
                    template_info['name'],
                    business_logic,
                    user_request,
                    llm_client
                )
                business_logic["sample_code"] = sample_code
                logger.info(f"✅ Sample code generated: {len(sample_code)} chars")
            except Exception as e:
                logger.error(f"❌ Failed to generate sample code: {e}")
                business_logic["sample_code"] = self._get_default_sample_code(template_id)
        
        # 기본 메타데이터 추가
        self._add_default_metadata(business_logic, template_id, user_request)
        
        # 중요: _agentic_analysis를 core_business_logic으로도 매핑
        # 이렇게 하면 템플릿이 둘 중 어느 변수를 사용하든 작동합니다
        if '_agentic_analysis' in business_logic and business_logic['_agentic_analysis']:
            # _agentic_analysis가 있고 비어있지 않으면 core_business_logic에도 할당
            if 'core_business_logic' not in business_logic or not business_logic['core_business_logic'] or \
               business_logic['core_business_logic'] == 'pass  # Business logic placeholder':
                business_logic['core_business_logic'] = business_logic['_agentic_analysis']
                logger.info(f"📋 Mapped _agentic_analysis to core_business_logic ({len(business_logic['_agentic_analysis'])} chars)")
        
        logger.info(f"✅ Business logic generation completed. Generated {len(business_logic)} sections")
        return business_logic
        
    def _add_default_metadata(self, business_logic: Dict[str, str], template_id: str, user_request: str):
        """비즈니스 로직에 기본 메타데이터를 추가합니다."""
        
        # 클래스 이름 생성
        if 'agent_class_name' not in business_logic:
            class_name = self._generate_class_name_from_request(user_request, template_id)
            business_logic['agent_class_name'] = class_name
            logger.info(f"  Generated class name: {class_name}")
        
        # 에이전트 이름 생성
        if 'agent_name' not in business_logic:
            agent_name = self._generate_agent_name_from_class(business_logic['agent_class_name'])
            business_logic['agent_name'] = agent_name
            logger.info(f"  Generated agent name: {agent_name}")
        
        # 에이전트 설명 생성
        if 'agent_description' not in business_logic:
            business_logic['agent_description'] = user_request[:200] + ("..." if len(user_request) > 200 else "")
            logger.info(f"  Generated description: {business_logic['agent_description'][:50]}...")
        
        # 기본 설정값들
        if 'agent_type' not in business_logic:
            business_logic['agent_type'] = 'CUSTOM'
        
        if 'custom_config' not in business_logic:
            business_logic['custom_config'] = '{"timeout": 60, "retry_attempts": 3}'
        
        if 'custom_init' not in business_logic:
            business_logic['custom_init'] = '# Custom initialization based on template'
        
        if 'custom_async_init' not in business_logic:
            business_logic['custom_async_init'] = '# Async initialization if needed'
    
    def _generate_class_name_from_request(self, user_request: str, template_id: str) -> str:
        """사용자 요청과 템플릿 ID로부터 적절한 클래스 이름을 생성합니다."""
        # 템플릿 기반 기본 이름
        template_names = {
            'csv_excel_analyzer': 'CSVExcelAnalyzerAgent',
            'price_monitoring': 'PriceMonitoringAgent',
            'automl_pipeline': 'AutoMLPipelineAgent',
            'contract_analyzer': 'ContractAnalyzerAgent',
            'unified_agentic': 'UnifiedAgenticAgent'
        }
        
        if template_id in template_names:
            return template_names[template_id]
        
        # 사용자 요청에서 키워드 추출
        keywords = []
        if 'csv' in user_request.lower() or 'excel' in user_request.lower():
            keywords.append('DataAnalyzer')
        elif 'price' in user_request.lower() or 'monitoring' in user_request.lower():
            keywords.append('PriceMonitor')
        elif 'contract' in user_request.lower() or 'document' in user_request.lower():
            keywords.append('ContractAnalyzer')
        elif 'ml' in user_request.lower() or 'machine learning' in user_request.lower():
            keywords.append('MLPipeline')
        else:
            keywords.append('Custom')
        
        return f"{''.join(keywords)}Agent"
    
    def _generate_agent_name_from_class(self, class_name: str) -> str:
        """클래스 이름으로부터 사용자 친화적인 에이전트 이름을 생성합니다."""
        # CamelCase를 공백으로 분리
        import re
        name = re.sub('(.)([A-Z][a-z]+)', r'\1 \2', class_name)
        name = re.sub('([a-z0-9])([A-Z])', r'\1 \2', name)
        # Agent 제거
        name = name.replace(' Agent', '').strip()
        return name
    
    def _get_template_specific_prompts(self, template_id: str, user_request: str) -> Dict[str, str]:
        """템플릿별 특화된 프롬프트를 반환합니다."""
        base_prompt = """## 작업 개요
사용자가 요청한 기능: USER_REQUEST_PLACEHOLDER

## 응답 형식 (매우 중요!)

반드시 다음 JSON 형식으로만 응답하세요. JSON 앞뒤에 어떤 텍스트도 추가하지 마세요:
{
    "code": "여기에 완전한 Python 코드 작성"
}

## 코드 작성 규칙

### 필수 요구사항:
1. **완전한 코드**: 모든 함수는 완전히 구현되어야 합니다. 절대 ... 이나 pass만 있으면 안됩니다.
2. **async/await 패턴**: 
   - 모든 함수는 async def로 선언
   - 비동기 호출은 반드시 await 사용
   - 예: result = await self.some_async_method()
3. **타입 힌트 필수**: 
   - 모든 매개변수에 타입 힌트
   - 반환 타입 명시
   - 예: async def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
4. **완전한 에러 처리**:
   ```python
   try:
       # 실제 로직
       result = await self.process_data(data)
       return result
   except SpecificException as e:
       logger.error(f"특정 오류: {e}")
       return {"error": str(e)}
   except Exception as e:
       logger.error(f"예상치 못한 오류: {e}")
       return {"error": f"처리 중 오류: {str(e)}"}}
   ```
5. **import 문 제외**: 필요한 import는 템플릿에 이미 있으므로 제외

### 금지 사항:
- JSON 외부에 어떤 텍스트도 절대 금지
- 불완전한 코드 금지 (함수가 중간에 끝나면 안됨)
- 코드 내 ... 또는 TODO 금지
- 함수가 \\ 로 끝나면 안됨
- Markdown 코드 블록 (```) 사용 금지

### 코드 예시 구조:
async def _process_main_logic(self, data: Any, query: str) -> Dict[str, Any]:
    \"\"\"메인 처리 로직\"\"\"
    try:
        # 1. 데이터 검증
        if not data:
            return {"error": "No data provided"}
        
        # 2. 실제 처리
        processed_result = await self._do_processing(data)
        
        # 3. 결과 반환
        return {
            "success": True,
            "result": processed_result,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"처리 오류: {str(e)}")
        return {"error": str(e), "success": False}
```

## 구체적 구현 지침"""
        
        template_prompts = {
            "csv_excel_analyzer": {
                "_agentic_analysis": base_prompt + """

### CSV/Excel 데이터 분석 함수 구현

함수 시그니처:
async def _agentic_analysis(self, df: pd.DataFrame, user_query: str) -> Dict[str, Any]:

### 구현 요구사항:

1. **입력 데이터 처리**
   - DataFrame 유효성 검증
   - 데이터 타입 분석
   - 기본 정보 추출

2. **완전한 구현 예시**:
```python
async def _agentic_analysis(self, df: pd.DataFrame, user_query: str) -> Dict[str, Any]:
    start_time = datetime.now()
    try:
        # 1. 데이터 기본 정보
        row_count = len(df)
        column_count = len(df.columns)
        numeric_columns = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # 2. 기본 통계 계산
        basic_stats = {
            "row_count": row_count,
            "column_count": column_count,
            "numeric_columns": numeric_columns,
            "missing_values": df.isnull().sum().to_dict(),
            "data_types": df.dtypes.astype(str).to_dict()
        }
        
        if numeric_columns:
            basic_stats["summary"] = df[numeric_columns].describe().to_dict()
        
        # 3. 상관관계 분석
        correlations = {}
        if len(numeric_columns) > 1:
            corr_matrix = df[numeric_columns].corr()
            correlations = corr_matrix.to_dict()
            
            # 높은 상관관계 찾기
            high_correlations = []
            for i in range(len(numeric_columns)):
                for j in range(i+1, len(numeric_columns)):
                    corr_value = corr_matrix.iloc[i, j]
                    if abs(corr_value) > 0.7:
                        high_correlations.append({
                            "pair": f"{numeric_columns[i]} - {numeric_columns[j]}",
                            "correlation": round(corr_value, 3)
                        })
        
        # 4. 이상치 탐지 (Z-score 방법)
        anomalies_list = []
        for col in numeric_columns:
            z_scores = np.abs(stats.zscore(df[col].dropna()))
            anomaly_indices = np.where(z_scores > 3)[0]
            if len(anomaly_indices) > 0:
                anomalies_list.append({
                    "column": col,
                    "count": len(anomaly_indices),
                    "percentage": round(len(anomaly_indices) / row_count * 100, 2)
                })
        
        # 5. 비즈니스 인사이트 생성
        key_findings = [
            f"데이터셋은 {row_count}개의 레코드와 {column_count}개의 필드로 구성되어 있습니다",
            f"숫자형 필드는 {len(numeric_columns)}개입니다"
        ]
        
        if high_correlations:
            key_findings.append(f"{len(high_correlations)}개의 강한 상관관계가 발견되었습니다")
        
        if anomalies_list:
            total_anomalies = sum(a['count'] for a in anomalies_list)
            key_findings.append(f"총 {total_anomalies}개의 이상치가 {len(anomalies_list)}개 필드에서 발견되었습니다")
        
        # 6. 실행 정보
        execution_time = (datetime.now() - start_time).total_seconds()
        
        # 7. 전체 결과 반환
        return {
            "execution_info": {
                "strategy": "comprehensive_analysis",
                "execution_time": execution_time,
                "plan_confidence": 0.95,
                "phases_completed": ["validation", "statistics", "correlation", "anomaly_detection", "insights"]
            },
            "data_analysis": {
                "basic_stats": basic_stats,
                "correlations": correlations,
                "high_correlations": high_correlations if 'high_correlations' in locals() else [],
                "anomalies": anomalies_list
            },
            "business_insights": {
                "key_findings": key_findings,
                "business_insights": [
                    "데이터 품질과 완전성이 분석 결과의 신뢰도를 결정합니다",
                    "상관관계가 높은 지표들은 비즈니스 의사결정에 중요한 통찰을 제공합니다",
                    "이상치는 특별한 비즈니스 이벤트나 데이터 오류를 나타낼 수 있습니다"
                ],
                "action_recommendations": [
                    "정기적인 데이터 품질 모니터링 시스템을 구축하세요",
                    "높은 상관관계를 보이는 지표들을 함께 추적하여 통합적인 인사이트를 도출하세요",
                    "이상치 패턴을 분석하여 비즈니스 프로세스 개선 기회를 찾으세요"
                ]
            },
            "context": {
                "business_domain": "data_analytics",
                "analysis_type": "comprehensive"
            },
            "metadata": {
                "llm_decisions": 3,
                "analysis_timestamp": datetime.now().isoformat(),
                "query": user_query
            }
        }
        
    except Exception as e:
        logger.error(f"Agentic analysis error: {str(e)}")
        return {
            "error": str(e),
            "message": "데이터 분석 중 오류가 발생했습니다"
        }
```

### 중요 주의사항:
- 모든 f-string에서 변수는 단일 중괄호만 사용하세요 (예: 변수명을 중괄호로 감싸기)
- # TODO 주석이나 Replace 텍스트를 절대 포함하지 마세요
- 백슬래시로 끝나는 불완전한 라인을 만들지 마세요
- 모든 변수는 사용 전에 반드시 초기화하세요
- try-except로 모든 오류를 처리하세요
"""
            },
            
            "price_monitoring": {
                "_track_price_changes": base_prompt + """

### 가격 변동 추적 함수 구현

함수 시그니처:
async def _track_price_changes(self, product_id: str, price: float, competitor: str) -> Dict[str, Any]:

### 완전한 구현 예시:
```python
async def _track_price_changes(self, product_id: str, price: float, competitor: str) -> Dict[str, Any]:
    try:
        # 1. 가격 히스토리 초기화
        if product_id not in self.price_history:
            self.price_history[product_id] = []
        
        # 2. 이전 가격 찾기
        previous_price = None
        if self.price_history[product_id]:
            # 같은 경쟁사의 마지막 가격 찾기
            competitor_prices = [p for p in self.price_history[product_id] if p['competitor'] == competitor]
            if competitor_prices:
                previous_price = competitor_prices[-1]['price']
        
        # 3. 가격 변동률 계산
        change_percentage = 0.0
        if previous_price:
            change_percentage = ((price - previous_price) / previous_price) * 100
        
        # 4. 새 가격 기록 저장
        price_record = {
            'timestamp': datetime.now().isoformat(),
            'price': price,
            'competitor': competitor,
            'change_percentage': round(change_percentage, 2),
            'previous_price': previous_price
        }
        self.price_history[product_id].append(price_record)
        
        # 5. 알림 필요 여부 확인
        alert_threshold = self.config.config.get('price_threshold', 5.0)
        alert_needed = abs(change_percentage) >= alert_threshold
        
        # 6. 결과 반환
        return {
            'previous': previous_price,
            'current': price,
            'change_percentage': change_percentage,
            'alert_needed': alert_needed,
            'record_saved': True,
            'timestamp': price_record['timestamp']
        }
        
    except Exception as e:
        logger.error(f"가격 추적 오류: {str(e)}")
        return {
            'error': str(e),
            'previous': None,
            'current': price,
            'change_percentage': 0
        }
```

### 필수 import 추가:
```python
from app_agent.llm_client import LLMClient, LLMMessage
import aiohttp
import numpy as np
```
""",
                "_analyze_price_trends": base_prompt + """

### 가격 트렌드 분석 함수 구현

함수 시그니처:
async def _analyze_price_trends(self, product_id: str) -> Dict[str, Any]:

### 완전한 구현:
```python
async def _analyze_price_trends(self, product_id: str) -> Dict[str, Any]:
    try:
        # 1. 가격 히스토리 확인
        if product_id not in self.price_history or not self.price_history[product_id]:
            return {
                'trend': 'no_data',
                'average': 0,
                'volatility': 0,
                'min_price': 0,
                'max_price': 0,
                'price_range': 0,
                'trend_direction': 'unknown'
            }
        
        # 2. 최근 30개 데이터 또는 전체 데이터 사용
        history = self.price_history[product_id][-30:]
        prices = [h['price'] for h in history]
        timestamps = [datetime.fromisoformat(h['timestamp']) for h in history]
        
        # 3. 기본 통계 계산
        avg_price = np.mean(prices)
        price_volatility = np.std(prices) if len(prices) > 1 else 0
        min_price = min(prices)
        max_price = max(prices)
        price_range = max_price - min_price
        
        # 4. 트렌드 방향 분석
        if len(prices) >= 2:
            # 선형 회귀로 트렌드 방향 파악
            x = np.arange(len(prices))
            slope, _ = np.polyfit(x, prices, 1)
            
            if slope > 0.01:
                trend_direction = 'increasing'
            elif slope < -0.01:
                trend_direction = 'decreasing'
            else:
                trend_direction = 'stable'
        else:
            trend_direction = 'insufficient_data'
        
        # 5. 경쟁사별 분석
        competitor_stats = {}
        competitors = set(h['competitor'] for h in history)
        for comp in competitors:
            comp_prices = [h['price'] for h in history if h['competitor'] == comp]
            if comp_prices:
                competitor_stats[comp] = {
                    'average': round(np.mean(comp_prices), 2),
                    'latest': comp_prices[-1],
                    'count': len(comp_prices)
                }
        
        # 6. 시간대별 패턴 분석
        hourly_patterns = {}
        for h in history:
            hour = datetime.fromisoformat(h['timestamp']).hour
            if hour not in hourly_patterns:
                hourly_patterns[hour] = []
            hourly_patterns[hour].append(h['price'])
        
        # 7. 결과 반환
        return {
            'trend': trend_direction,
            'average': round(avg_price, 2),
            'volatility': round(price_volatility, 2),
            'min_price': min_price,
            'max_price': max_price,
            'price_range': round(price_range, 2),
            'trend_direction': trend_direction,
            'data_points': len(prices),
            'competitor_analysis': competitor_stats,
            'volatility_percentage': round((price_volatility / avg_price * 100), 2) if avg_price > 0 else 0
        }
        
    except Exception as e:
        logger.error(f"트렌드 분석 오류: {str(e)}")
        return {
            'trend': 'error',
            'average': 0,
            'volatility': 0,
            'error': str(e)
        }
```
""",
                "_generate_pricing_strategy": base_prompt + """

### 가격 전략 생성 함수

함수 시그니처:
async def _generate_pricing_strategy(self, product_id: str, our_price: float) -> Dict[str, Any]:

### 구현:
```python
async def _generate_pricing_strategy(self, product_id: str, our_price: float) -> Dict[str, Any]:
    try:
        # 1. 트렌드 분석 결과 가져오기
        trends = await self._analyze_price_trends(product_id)
        
        # 2. 경쟁사 대비 포지션 분석
        market_average = trends.get('average', our_price)
        price_difference = our_price - market_average
        price_difference_pct = (price_difference / market_average * 100) if market_average > 0 else 0
        
        # 3. 전략 결정
        if price_difference_pct > 10:
            position = 'premium'
            recommended_action = 'consider_reduction'
            suggested_price = market_average * 1.05  # 시장 평균보다 5% 높게
        elif price_difference_pct < -10:
            position = 'discount'
            recommended_action = 'consider_increase'
            suggested_price = market_average * 0.98  # 시장 평균보다 2% 낮게
        else:
            position = 'competitive'
            recommended_action = 'maintain'
            suggested_price = our_price
        
        # 4. 세부 전략 수립
        strategy_details = {
            'short_term': [],
            'long_term': []
        }
        
        # 단기 전략
        if trends['volatility_percentage'] > 10:
            strategy_details['short_term'].append('높은 변동성으로 인해 동적 가격 조정 필요')
        if recommended_action == 'consider_reduction':
            strategy_details['short_term'].append('프로모션이나 할인을 통한 경쟁력 확보')
        
        # 장기 전략
        if trends['trend_direction'] == 'increasing':
            strategy_details['long_term'].append('시장 가격 상승 추세를 활용한 점진적 가격 인상')
        elif trends['trend_direction'] == 'decreasing':
            strategy_details['long_term'].append('비용 절감을 통한 마진 유지 전략 필요')
        
        # 5. 전체 전략 반환
        return {
            'current_position': position,
            'recommended_action': recommended_action,
            'suggested_price': round(suggested_price, 2),
            'price_difference': round(price_difference, 2),
            'price_difference_percentage': round(price_difference_pct, 2),
            'market_average': round(market_average, 2),
            'rationale': f'현재 가격이 시장 평균 대비 {round(price_difference_pct, 1)}% {("높음" if price_difference_pct > 0 else "낮음")}',
            'strategy_details': strategy_details,
            'confidence_score': 0.8 if trends['data_points'] >= 10 else 0.5
        }
        
    except Exception as e:
        logger.error(f"가격 전략 생성 오류: {str(e)}")
        return {
            'recommended_action': 'maintain',
            'suggested_price': our_price,
            'error': str(e),
            'confidence_score': 0.0
        }
```
""",
                "_generate_competitive_report": base_prompt + """

### 경쟁 분석 리포트 생성

함수 시그니처:
async def _generate_competitive_report(self, data: Dict[str, Any]) -> Dict[str, Any]:

### 구현:
```python
async def _generate_competitive_report(self, data: Dict[str, Any]) -> Dict[str, Any]:
    try:
        # LLM을 사용한 인사이트 생성
        prompt = f'''
        다음 가격 데이터를 분석하여 경쟁 전략 리포트를 생성해주세요:
        
        트렌드: {json.dumps(data.get('trends', dict()), ensure_ascii=False)}
        전략: {json.dumps(data.get('strategy', dict()), ensure_ascii=False)}
        
        다음 형식으로 응답해주세요:
        1. 시장 현황 요약
        2. 경쟁 우위 분석
        3. 위험 요소
        4. 기회 요소
        5. 실행 권장사항
        '''
        
        messages = [LLMMessage(role='user', content=prompt)]
        response = await self.llm_client.invoke_messages(messages)
        
        return {
            'report': response.content,
            'generated_at': datetime.now().isoformat(),
            'data_basis': {
                'trend_direction': data.get('trends', dict()).get('trend_direction', 'unknown'),
                'price_position': data.get('strategy', dict()).get('current_position', 'unknown'),
                'recommended_action': data.get('strategy', dict()).get('recommended_action', 'maintain')
            }
        }
        
    except Exception as e:
        logger.error(f"리포트 생성 오류: {str(e)}")
        return {
            'report': '리포트 생성 중 오류가 발생했습니다.',
            'error': str(e),
            'generated_at': datetime.now().isoformat()
        }
```

### 주의사항:
- LLMClient import 필수: from app_agent.llm_client import LLMClient, LLMMessage
- 모든 변수는 사용 전 초기화
- f-string에서 이중 중괄호 사용 금지
- 백슬래시로 끝나는 라인 금지
"""
            },
            
            "automl_pipeline": {
                "_select_best_model": base_prompt + """

### AutoML 모델 선택 함수 구현

함수 시그니처:
async def _select_best_model(self, X: Any, y: Any, task_type: str = 'classification') -> Dict[str, Any]:

### 완전한 구현:
```python
async def _select_best_model(self, X: Any, y: Any, task_type: str = 'classification') -> Dict[str, Any]:
    try:
        from sklearn.model_selection import train_test_split, cross_val_score
        from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, RandomForestRegressor, GradientBoostingRegressor
        from sklearn.linear_model import LogisticRegression, LinearRegression
        from sklearn.svm import SVC, SVR
        from sklearn.metrics import accuracy_score, mean_squared_error, r2_score
        
        # 1. 데이터 분할
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # 2. 모델 정의 (작업 유형에 따라)
        if task_type == 'classification':
            models = {
                'random_forest': RandomForestClassifier(n_estimators=100, random_state=42),
                'gradient_boosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
                'logistic_regression': LogisticRegression(random_state=42, max_iter=1000),
                'svm': SVC(random_state=42)
            }
            scoring = 'accuracy'
        else:  # regression
            models = {
                'random_forest': RandomForestRegressor(n_estimators=100, random_state=42),
                'gradient_boosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
                'linear_regression': LinearRegression(),
                'svr': SVR()
            }
            scoring = 'r2'
        
        # 3. 모델 평가
        results = {}
        best_score = -np.inf
        best_model = None
        best_model_name = None
        
        for name, model in models.items():
            try:
                # 교차 검증
                cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring=scoring)
                mean_cv_score = np.mean(cv_scores)
                
                # 모델 학습
                model.fit(X_train, y_train)
                
                # 테스트 세트 평가
                y_pred = model.predict(X_test)
                
                if task_type == 'classification':
                    test_score = accuracy_score(y_test, y_pred)
                else:
                    test_score = r2_score(y_test, y_pred)
                    mse = mean_squared_error(y_test, y_pred)
                
                # 결과 저장
                results[name] = {
                    'cv_score': mean_cv_score,
                    'cv_scores': cv_scores.tolist(),
                    'test_score': test_score,
                    'model': model
                }
                
                if task_type == 'regression':
                    results[name]['mse'] = mse
                
                # 최고 모델 추적
                if mean_cv_score > best_score:
                    best_score = mean_cv_score
                    best_model = model
                    best_model_name = name
                    
            except Exception as e:
                logger.warning(f"모델 {name} 평가 실패: {str(e)}")
                results[name] = {'error': str(e)}
        
        # 4. 특성 중요도 추출 (가능한 경우)
        feature_importance = None
        if hasattr(best_model, 'feature_importances_'):
            feature_importance = best_model.feature_importances_.tolist()
        
        # 5. 결과 반환
        return {
            'best_model_name': best_model_name,
            'best_model': best_model,
            'best_score': best_score,
            'all_results': results,
            'feature_importance': feature_importance,
            'task_type': task_type,
            'training_samples': len(X_train),
            'test_samples': len(X_test)
        }
        
    except Exception as e:
        logger.error(f"모델 선택 오류: {str(e)}")
        return {
            'error': str(e),
            'best_model_name': None,
            'best_model': None
        }
```
""",
                "_tune_hyperparameters": base_prompt + """

### 하이퍼파라미터 튜닝 함수

함수 시그니처:
async def _tune_hyperparameters(self, model: Any, X: Any, y: Any, param_grid: Dict = None) -> Dict[str, Any]:

### 구현:
```python
async def _tune_hyperparameters(self, model: Any, X: Any, y: Any, param_grid: Dict = None) -> Dict[str, Any]:
    try:
        from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
        
        # 1. 기본 파라미터 그리드 설정
        if param_grid is None:
            model_name = type(model).__name__
            
            if 'RandomForest' in model_name:
                param_grid = {
                    'n_estimators': [100, 200, 300],
                    'max_depth': [10, 20, 30, None],
                    'min_samples_split': [2, 5, 10],
                    'min_samples_leaf': [1, 2, 4]
                }
            elif 'GradientBoosting' in model_name:
                param_grid = {
                    'n_estimators': [100, 200],
                    'learning_rate': [0.01, 0.1, 0.3],
                    'max_depth': [3, 5, 7],
                    'subsample': [0.8, 1.0]
                }
            elif 'SV' in model_name:  # SVC or SVR
                param_grid = {
                    'C': [0.1, 1, 10],
                    'kernel': ['linear', 'rbf'],
                    'gamma': ['scale', 'auto']
                }
            else:
                # 기본 파라미터 (대부분의 모델에 적용 가능)
                param_grid = {}
        
        # 2. 그리드 서치 수행
        n_params = np.prod([len(v) for v in param_grid.values()]) if param_grid else 0
        
        if n_params > 50:
            # 파라미터 조합이 많으면 RandomizedSearchCV 사용
            search = RandomizedSearchCV(
                model, 
                param_grid, 
                n_iter=20,
                cv=5,
                scoring='accuracy' if hasattr(model, 'predict_proba') else 'r2',
                n_jobs=-1,
                random_state=42
            )
        else:
            # 그리드 서치
            search = GridSearchCV(
                model,
                param_grid,
                cv=5,
                scoring='accuracy' if hasattr(model, 'predict_proba') else 'r2',
                n_jobs=-1
            )
        
        # 3. 서치 실행
        search.fit(X, y)
        
        # 4. 결과 정리
        results = {
            'best_params': search.best_params_,
            'best_score': search.best_score_,
            'best_model': search.best_estimator_,
            'cv_results': {
                'mean_test_scores': search.cv_results_['mean_test_score'].tolist()[:10],  # 상위 10개
                'params': [dict(p) for p in search.cv_results_['params'][:10]]
            },
            'search_type': type(search).__name__,
            'n_iterations': len(search.cv_results_['params'])
        }
        
        return results
        
    except Exception as e:
        logger.error(f"하이퍼파라미터 튜닝 오류: {str(e)}")
        return {
            'error': str(e),
            'best_params': {},
            'best_model': model
        }
```
""",
                "_generate_ml_report": base_prompt + """

### ML 결과 리포트 생성

함수 시그니처:
async def _generate_ml_report(self, results: Dict[str, Any]) -> str:

### 구현:
```python
async def _generate_ml_report(self, results: Dict[str, Any]) -> str:
    try:
        report_lines = [
            "=== AutoML 파이프라인 실행 결과 ===",
            "",
            f"작업 유형: {results.get('task_type', 'unknown')}",
            f"총 샘플 수: {results.get('total_samples', 0)}",
            f"학습 샘플: {results.get('training_samples', 0)}",
            f"테스트 샘플: {results.get('test_samples', 0)}",
            "",
            "--- 최적 모델 ---",
            f"모델: {results.get('best_model_name', 'None')}",
            f"교차 검증 점수: {results.get('best_score', 0):.4f}",
            f"테스트 점수: {results.get('test_score', 0):.4f}",
            ""
        ]
        
        # 하이퍼파라미터 정보
        if 'best_params' in results:
            report_lines.extend([
                "--- 최적 하이퍼파라미터 ---"
            ])
            for param, value in results['best_params'].items():
                report_lines.append(f"{param}: {value}")
            report_lines.append("")
        
        # 모든 모델 성능 비교
        if 'all_models' in results:
            report_lines.extend([
                "--- 모델 성능 비교 ---"
            ])
            for model_name, scores in results['all_models'].items():
                if 'cv_score' in scores:
                    report_lines.append(f"{model_name}: {scores['cv_score']:.4f}")
            report_lines.append("")
        
        # 특성 중요도
        if 'feature_importance' in results and results['feature_importance']:
            report_lines.extend([
                "--- 상위 5개 중요 특성 ---"
            ])
            importance = results['feature_importance']
            if 'feature_names' in results:
                features = list(zip(results['feature_names'], importance))
                features.sort(key=lambda x: x[1], reverse=True)
                for i, (name, imp) in enumerate(features[:5]):
                    report_lines.append(f"{i+1}. {name}: {imp:.4f}")
            report_lines.append("")
        
        # 권장사항
        report_lines.extend([
            "--- 권장사항 ---",
            "1. 모델 성능이 만족스럽다면 프로덕션 배포를 고려하세요",
            "2. 추가 데이터 수집으로 모델 성능을 개선할 수 있습니다",
            "3. 정기적인 모델 재학습으로 성능을 유지하세요"
        ])
        
        return "\\n".join(report_lines)
        
    except Exception as e:
        logger.error(f"리포트 생성 오류: {str(e)}")
        return f"리포트 생성 중 오류 발생: {str(e)}"
```

### 필수 import:
```python
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib
import numpy as np
```
"""
            },
            
            "contract_analyzer": {
                "_parse_contract": base_prompt + """

### 계약서 파싱 함수 구현

함수 시그니처:
async def _parse_contract(self, contract_text: str) -> Dict[str, Any]:

### 완전한 구현:
```python
async def _parse_contract(self, contract_text: str) -> Dict[str, Any]:
    try:
        import re
        from datetime import datetime
        
        # 1. 섹션별로 문서 분리
        sections = {}
        
        # 일반적인 계약서 섹션 패턴
        section_patterns = [
            r'제\s*(\d+)\s*조\s*\(([^)]+)\)',  # 제1조 (목적)
            r'제\s*(\d+)\s*조\s+([^\n]+)',     # 제1조 목적
            r'(\d+)\.\s*([^\n]+)',              # 1. Title
            r'Article\s+(\d+)[:\s]+([^\n]+)',  # Article 1: Title
        ]
        
        # 섹션 추출
        for pattern in section_patterns:
            matches = re.finditer(pattern, contract_text)
            for match in matches:
                section_num = match.group(1)
                section_title = match.group(2).strip()
                
                # 섹션 내용 추출 (다음 섹션까지)
                start = match.end()
                # 다음 섹션 찾기
                next_match = re.search(r'(제\s*\d+\s*조|\d+\.|Article\s+\d+)', contract_text[start:])
                if next_match:
                    end = start + next_match.start()
                else:
                    end = len(contract_text)
                
                sections[f"{section_num}_{section_title}"] = contract_text[start:end].strip()
        
        # 2. 주요 정보 추출
        extracted_info = {
            'parties': self._extract_parties(contract_text),
            'dates': self._extract_dates(contract_text),
            'amounts': self._extract_amounts(contract_text),
            'terms': self._extract_key_terms(contract_text),
            'sections': sections
        }
        
        return extracted_info
        
    except Exception as e:
        logger.error(f"계약서 파싱 오류: {str(e)}")
        return {
            'error': str(e),
            'sections': {},
            'parties': [],
            'dates': [],
            'amounts': []
        }

def _extract_parties(self, text: str) -> List[Dict[str, str]]:
    \"\"\"계약 당사자 추출\"\"\"
    parties = []
    
    # 패턴: "갑"과 "을", "Party A/B", "Buyer/Seller" 등
    party_patterns = [
        r'(갑|甲)\s*[:：]\s*([^,\n]+)',
        r'(을|乙)\s*[:：]\s*([^,\n]+)',
        r'(Party\s+[AB]|Buyer|Seller|Lessor|Lessee)\s*[:：]\s*([^,\n]+)',
        r'(계약자|발주자|수주자|임대인|임차인)\s*[:：]\s*([^,\n]+)'
    ]
    
    for pattern in party_patterns:
        matches = re.finditer(pattern, text, re.IGNORECASE)
        for match in matches:
            parties.append({
                'role': match.group(1),
                'name': match.group(2).strip(),
                'type': 'party'
            })
    
    return parties

def _extract_dates(self, text: str) -> List[Dict[str, str]]:
    \"\"\"날짜 정보 추출\"\"\"
    dates = []
    
    # 다양한 날짜 형식 패턴
    date_patterns = [
        r'(\d{4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일',
        r'(\d{4})[-./](\d{1,2})[-./](\d{1,2})',
        r'(\d{1,2})[-./](\d{1,2})[-./](\d{4})',
    ]
    
    # 날짜 유형 키워드
    date_keywords = {
        '계약일': 'contract_date',
        '시작일': 'start_date',
        '종료일': 'end_date',
        '만료일': 'expiry_date',
        '체결일': 'signing_date'
    }
    
    for pattern in date_patterns:
        matches = re.finditer(pattern, text)
        for match in matches:
            # 주변 컨텍스트에서 날짜 유형 찾기
            context_start = max(0, match.start() - 50)
            context = text[context_start:match.start()]
            
            date_type = 'unknown'
            for keyword, dtype in date_keywords.items():
                if keyword in context:
                    date_type = dtype
                    break
            
            dates.append({
                'date': match.group(0),
                'type': date_type,
                'position': match.start()
            })
    
    return dates

def _extract_amounts(self, text: str) -> List[Dict[str, Any]]:
    \"\"\"금액 정보 추출\"\"\"
    amounts = []
    
    # 금액 패턴
    amount_patterns = [
        r'([0-9,]+)\s*(원|달러|USD|KRW|\\$)',
        r'금\s*([0-9,]+)\s*(원|달러)',
        r'\\$\s*([0-9,]+(?:\\.[0-9]{2})?)',
        r'([0-9]+(?:,[0-9]{3})*(?:\\.[0-9]{2})?)\s*(원|달러|USD|KRW)'
    ]
    
    for pattern in amount_patterns:
        matches = re.finditer(pattern, text, re.IGNORECASE)
        for match in matches:
            amount_str = match.group(1).replace(',', '')
            try:
                amount = float(amount_str)
                currency = match.group(2) if len(match.groups()) > 1 else 'KRW'
                
                # 금액 유형 추정
                context_start = max(0, match.start() - 30)
                context = text[context_start:match.start()].lower()
                
                amount_type = 'other'
                if '계약금' in context:
                    amount_type = 'down_payment'
                elif '총' in context or '합계' in context:
                    amount_type = 'total'
                elif '월' in context:
                    amount_type = 'monthly'
                
                amounts.append({
                    'amount': amount,
                    'currency': currency,
                    'type': amount_type,
                    'original': match.group(0)
                })
            except ValueError:
                continue
    
    return amounts

def _extract_key_terms(self, text: str) -> Dict[str, Any]:
    \"\"\"주요 계약 조건 추출\"\"\"
    terms = {
        'duration': None,
        'payment_terms': [],
        'termination_clauses': [],
        'penalties': [],
        'confidentiality': False,
        'jurisdiction': None
    }
    
    # 계약 기간
    duration_match = re.search(r'계약\s*기간\s*[:：]\s*([^\n]+)', text)
    if duration_match:
        terms['duration'] = duration_match.group(1).strip()
    
    # 지급 조건
    payment_patterns = [
        r'(선급금|계약금|중도금|잔금)\s*[:：]\s*([^\n]+)',
        r'지급\s*조건\s*[:：]\s*([^\n]+)'
    ]
    for pattern in payment_patterns:
        matches = re.finditer(pattern, text)
        for match in matches:
            terms['payment_terms'].append(match.group(0))
    
    # 해지 조항
    if '해지' in text or '종료' in text:
        termination_patterns = [
            r'(해지|종료)\s*조건\s*[:：]\s*([^\n]+)',
            r'계약\s*(해지|종료)\s*[:：]\s*([^\n]+)'
        ]
        for pattern in termination_patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                terms['termination_clauses'].append(match.group(0))
    
    # 기밀유지 조항
    if '기밀' in text or '비밀' in text or 'confidential' in text.lower():
        terms['confidentiality'] = True
    
    return terms
```
""",
                "_assess_risks": base_prompt + """

### 계약서 리스크 평가 함수

함수 시그니처:
async def _assess_risks(self, contract_sections: Dict[str, Any]) -> List[Dict[str, Any]]:

### 구현:
```python
async def _assess_risks(self, contract_sections: Dict[str, Any]) -> List[Dict[str, Any]]:
    try:
        risks = []
        
        # 리스크 키워드와 심각도 매핑
        risk_keywords = {
            'high': {
                'keywords': ['손해배상', '위약금', '해지', '책임', '보증', '담보', '파산', '도산'],
                'weight': 0.9
            },
            'medium': {
                'keywords': ['지연', '변경', '수정', '협의', '통지', '승인', '동의'],
                'weight': 0.6
            },
            'low': {
                'keywords': ['협력', '노력', '선의', '상호', '합의'],
                'weight': 0.3
            }
        }
        
        # 1. 섹션별 리스크 분석
        for section_key, content in contract_sections.items():
            if not isinstance(content, str):
                continue
                
            section_risks = []
            
            # 리스크 키워드 검색
            for severity, info in risk_keywords.items():
                for keyword in info['keywords']:
                    if keyword in content:
                        # 컨텍스트 추출
                        keyword_index = content.find(keyword)
                        context_start = max(0, keyword_index - 50)
                        context_end = min(len(content), keyword_index + 50)
                        context = content[context_start:context_end]
                        
                        risk = {
                            'section': section_key,
                            'type': keyword,
                            'severity': severity,
                            'score': info['weight'],
                            'context': context.strip(),
                            'description': f'{section_key}에서 {keyword} 관련 조항 발견'
                        }
                        
                        # 구체적인 리스크 설명 추가
                        if keyword in ['손해배상', '위약금']:
                            risk['mitigation'] = '명확한 책임 한계 설정 및 보험 가입 검토'
                        elif keyword in ['해지', '종료']:
                            risk['mitigation'] = '해지 조건 명확화 및 충분한 통지 기간 확보'
                        elif keyword in ['책임', '보증']:
                            risk['mitigation'] = '책임 범위 제한 및 면책 조항 추가'
                        else:
                            risk['mitigation'] = '조항 검토 및 협상 필요'
                        
                        section_risks.append(risk)
            
            # 섹션별 최고 리스크만 추가 (중복 방지)
            if section_risks:
                highest_risk = max(section_risks, key=lambda x: x['score'])
                risks.append(highest_risk)
        
        # 2. 특수 리스크 패턴 분석
        special_risks = self._analyze_special_risk_patterns(contract_sections)
        risks.extend(special_risks)
        
        # 3. 리스크 점수순 정렬
        risks.sort(key=lambda x: x['score'], reverse=True)
        
        return risks
        
    except Exception as e:
        logger.error(f"리스크 평가 오류: {str(e)}")
        return [{
            'type': 'error',
            'severity': 'high',
            'description': f'리스크 평가 중 오류 발생: {str(e)}'
        }]

def _analyze_special_risk_patterns(self, sections: Dict[str, Any]) -> List[Dict[str, Any]]:
    \"\"\"특수 리스크 패턴 분석\"\"\"
    special_risks = []
    
    # 전체 텍스트 결합
    full_text = ' '.join(str(v) for v in sections.values() if isinstance(v, str))
    
    # 1. 일방적 조항 검사
    if full_text.count('갑') > full_text.count('을') * 1.5:
        special_risks.append({
            'type': 'unbalanced_terms',
            'severity': 'medium',
            'score': 0.7,
            'description': '계약 조항이 일방에게 유리하게 작성됨',
            'mitigation': '양 당사자의 권리와 의무 균형 재검토'
        })
    
    # 2. 불명확한 용어 검사
    vague_terms = ['합리적', '상당한', '적절한', '필요한 경우']
    vague_count = sum(1 for term in vague_terms if term in full_text)
    if vague_count > 3:
        special_risks.append({
            'type': 'vague_terms',
            'severity': 'low',
            'score': 0.4,
            'description': '불명확한 용어 다수 사용',
            'mitigation': '구체적인 기준과 정의 추가'
        })
    
    # 3. 관할권 리스크
    if '외국' in full_text or 'foreign' in full_text.lower():
        special_risks.append({
            'type': 'jurisdiction',
            'severity': 'high',
            'score': 0.8,
            'description': '국제 계약에 따른 관할권 이슈',
            'mitigation': '명확한 준거법 및 분쟁해결 조항 필요'
        })
    
    return special_risks
```
""",
                "_generate_contract_report": base_prompt + """

### 계약서 분석 리포트 생성

함수 시그니처:
async def _generate_contract_report(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:

### 구현:
```python
async def _generate_contract_report(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
    try:
        # LLM을 사용한 종합 리포트 생성
        prompt = f'''
        다음 계약서 분석 결과를 바탕으로 종합 리포트를 작성해주세요:
        
        파싱 결과: {json.dumps(analysis_results.get('parsed_data', dict()), ensure_ascii=False)}
        리스크 평가: {json.dumps(analysis_results.get('risks', []), ensure_ascii=False)}
        
        다음 형식으로 작성해주세요:
        
        1. 계약 개요
           - 계약 당사자
           - 계약 기간
           - 주요 금액
        
        2. 핵심 조항 요약
           - 주요 권리와 의무
           - 지급 조건
           - 종료 조건
        
        3. 리스크 분석
           - 고위험 사항
           - 중위험 사항
           - 권장 조치사항
        
        4. 협상 포인트
           - 우선 검토 사항
           - 수정 제안 사항
        
        5. 종합 의견
        '''
        
        messages = [LLMMessage(role='user', content=prompt)]
        response = await self.llm_client.invoke_messages(messages)
        
        # 구조화된 리포트 생성
        report = {
            'summary': response.content,
            'risk_summary': {
                'high_risks': [r for r in analysis_results.get('risks', []) if r.get('severity') == 'high'],
                'medium_risks': [r for r in analysis_results.get('risks', []) if r.get('severity') == 'medium'],
                'low_risks': [r for r in analysis_results.get('risks', []) if r.get('severity') == 'low']
            },
            'key_findings': {
                'parties': analysis_results.get('parsed_data', dict()).get('parties', []),
                'important_dates': analysis_results.get('parsed_data', dict()).get('dates', []),
                'financial_terms': analysis_results.get('parsed_data', dict()).get('amounts', [])
            },
            'recommendations': self._generate_recommendations(analysis_results),
            'generated_at': datetime.now().isoformat()
        }
        
        return report
        
    except Exception as e:
        logger.error(f"리포트 생성 오류: {str(e)}")
        return {
            'error': str(e),
            'summary': '리포트 생성 중 오류가 발생했습니다.',
            'generated_at': datetime.now().isoformat()
        }

def _generate_recommendations(self, analysis: Dict[str, Any]) -> List[str]:
    \"\"\"분석 결과 기반 권장사항 생성\"\"\"
    recommendations = []
    
    risks = analysis.get('risks', [])
    high_risks = [r for r in risks if r.get('severity') == 'high']
    
    if high_risks:
        recommendations.append('고위험 조항에 대한 법률 자문을 받으시기 바랍니다.')
        
    if any('손해배상' in r.get('type', '') for r in risks):
        recommendations.append('손해배상 한도를 명확히 설정하고 보험 가입을 검토하세요.')
        
    if any('해지' in r.get('type', '') for r in risks):
        recommendations.append('계약 해지 조건과 절차를 명확히 하고 충분한 통지 기간을 확보하세요.')
    
    if not analysis.get('parsed_data', dict()).get('amounts'):
        recommendations.append('금액 관련 조항이 명확하지 않으므로 구체적인 금액을 명시하세요.')
    
    return recommendations
```

### 필수 import:
```python
import re
from datetime import datetime
import json
from app_agent.llm_client import LLMClient, LLMMessage
```
"""
            },
            "financial_risk": {
                "_agentic_analysis": base_prompt + """

### 재무 위험 분석 및 포트폴리오 관리 구현

사용자 요청: {user_request}

다음 기능들을 구현하세요:

1. **포트폴리오 분석**:
   - 자산 배분 분석
   - 위험도 계산 (VaR, Sharpe Ratio 등)
   - 수익률 분석

2. **리밸런싱 로직**:
   - 목표 비중 대비 현재 비중 분석
   - 리밸런싱 추천 생성
   - 세금 효율적 매매 타이밍 제안

3. **리스크 관리**:
   - 시장 변동성 모니터링
   - 손실 한도 관리
   - 헤지 전략 제안

4. **보고서 생성**:
   - 포트폴리오 성과 요약
   - 리스크 지표 시각화
   - 추천 액션 아이템

### 코드 예시:
```python
async def _agentic_analysis(self, data: Dict[str, Any], user_query: str) -> Dict[str, Any]:
    from datetime import datetime
    import logging
    
    logger = logging.getLogger(__name__)
    
    try:
        # 포트폴리오 데이터 검증
        portfolio = data.get('portfolio', {})
        risk_preference = data.get('risk_preference', 'moderate')
        investment_goal = data.get('investment_goal', 'growth')
        
        # 포트폴리오 분석
        analysis_result = {
            "portfolio_value": self._calculate_portfolio_value(portfolio),
            "risk_metrics": self._calculate_risk_metrics(portfolio),
            "allocation": self._analyze_allocation(portfolio),
            "performance": self._calculate_performance(portfolio)
        }
        
        # 리밸런싱 추천
        rebalancing = self._generate_rebalancing_recommendation(
            portfolio, risk_preference, investment_goal
        )
        
        # 리스크 평가
        risk_assessment = self._assess_market_risk(portfolio)
        
        return {
            "status": "success",
            "analysis": analysis_result,
            "rebalancing": rebalancing,
            "risk_assessment": risk_assessment,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"포트폴리오 분석 중 오류: {str(e)}")
        return {"error": str(e), "status": "failed"}

def _calculate_portfolio_value(self, portfolio):
    # 포트폴리오 총 가치 계산
    total_value = sum(asset['value'] for asset in portfolio.values())
    return total_value

def _calculate_risk_metrics(self, portfolio):
    # VaR, Sharpe Ratio 등 계산
    return {
        "var_95": 0.0,  # 실제 계산 로직 구현
        "sharpe_ratio": 0.0,
        "volatility": 0.0
    }

def _analyze_allocation(self, portfolio):
    # 자산 배분 분석
    return {}

def _calculate_performance(self, portfolio):
    # 수익률 계산
    return {}

def _generate_rebalancing_recommendation(self, portfolio, risk_preference, goal):
    # 리밸런싱 추천 생성
    return {
        "recommended_actions": [],
        "tax_efficiency_tips": []
    }

def _assess_market_risk(self, portfolio):
    # 시장 리스크 평가
    return {
        "risk_level": "moderate",
        "warnings": []
    }
```
"""
            },
            "customer_behavior": {
                "_agentic_analysis": base_prompt + """

### 고객 행동 분석 구현

사용자 요청: {user_request}

다음 기능들을 구현하세요:

1. **고객 세그멘테이션**:
   - RFM 분석 (Recency, Frequency, Monetary)
   - 클러스터링을 통한 고객 그룹 분류
   - 고객 생애 가치(CLV) 계산

2. **행동 패턴 분석**:
   - 구매 패턴 및 트렌드 분석
   - 이탈 예측 모델
   - 상품 추천 로직

### 코드 예시:
```python
async def _agentic_analysis(self, data: Dict[str, Any], user_query: str) -> Dict[str, Any]:
    from datetime import datetime
    import pandas as pd
    
    try:
        customer_data = data.get('customers', pd.DataFrame())
        
        # RFM 분석
        rfm_scores = self._calculate_rfm(customer_data)
        
        # 세그멘테이션
        segments = self._segment_customers(rfm_scores)
        
        # 이탈 예측
        churn_risk = self._predict_churn(customer_data)
        
        return {
            "status": "success",
            "segments": segments,
            "churn_risk": churn_risk,
            "rfm_analysis": rfm_scores,
            "recommendations": self._generate_recommendations(segments)
        }
    except Exception as e:
        return {"error": str(e), "status": "failed"}
```
"""
            },
            "real_estate_analyzer": {
                "_agentic_analysis": base_prompt + """

### 부동산 시장 분석 구현

사용자 요청: {user_request}

다음 기능들을 구현하세요:

1. **시장 분석**:
   - 지역별 시세 분석
   - 가격 트렌드 예측
   - 투자 수익률 계산

2. **매물 평가**:
   - 적정 가격 산정
   - 투자 가치 평가
   - 위험 요소 분석

### 코드 예시:
```python
async def _agentic_analysis(self, data: Dict[str, Any], user_query: str) -> Dict[str, Any]:
    try:
        properties = data.get('properties', [])
        location = data.get('location', '')
        
        # 시장 분석
        market_analysis = await self._analyze_market(location)
        
        # 가격 평가
        price_evaluation = self._evaluate_prices(properties, market_analysis)
        
        # 투자 분석
        investment_analysis = self._calculate_roi(properties)
        
        return {
            "status": "success",
            "market_analysis": market_analysis,
            "price_evaluation": price_evaluation,
            "investment_roi": investment_analysis,
            "recommendations": self._generate_investment_advice(investment_analysis)
        }
    except Exception as e:
        return {"error": str(e), "status": "failed"}
```
"""
            },
            "ecommerce_tracker": {
                "_agentic_analysis": base_prompt + """

### 전자상거래 추적 구현

사용자 요청: {user_request}

다음 기능들을 구현하세요:

1. **상품 모니터링**:
   - 가격 변동 추적
   - 재고 상태 확인
   - 리뷰 분석

2. **경쟁사 분석**:
   - 경쟁 상품 비교
   - 가격 경쟁력 분석

### 코드 예시:
```python
async def _agentic_analysis(self, data: Dict[str, Any], user_query: str) -> Dict[str, Any]:
    try:
        products = data.get('products', [])
        
        # 가격 모니터링
        price_changes = await self._track_prices(products)
        
        # 재고 확인
        stock_status = await self._check_inventory(products)
        
        # 리뷰 분석
        review_analysis = await self._analyze_reviews(products)
        
        return {
            "status": "success",
            "price_changes": price_changes,
            "stock_status": stock_status,
            "review_insights": review_analysis,
            "alerts": self._generate_alerts(price_changes, stock_status)
        }
    except Exception as e:
        return {"error": str(e), "status": "failed"}
```
"""
            }
        }
        
        # 기본 템플릿용 프롬프트
        default_prompts = {
            "_agentic_analysis": base_prompt + """

### 핵심 처리 로직 구현

사용자 요청: {user_request}

함수 시그니처:
async def _agentic_analysis(self, data: Any, user_query: str) -> Dict[str, Any]:

### 구현 가이드:
```python
async def _agentic_analysis(self, data: Any, user_query: str) -> Dict[str, Any]:
    start_time = datetime.now()
    try:
        # 1. 입력 데이터 검증
        if not data:
            return {
                "error": "No data provided",
                "message": "처리할 데이터가 없습니다"
            }
        
        # 2. 사용자 요청에 따른 처리
        # TODO: 여기에 {user_request}에 맞는 구체적인 로직 구현
        result = {}
        
        # 3. 데이터 처리 예시
        if isinstance(data, dict):
            # 딕셔너리 데이터 처리
            processed_data = {}
            for key, value in data.items():
                # 각 항목 처리
                processed_data[key] = self._process_item(value)
            result['processed_data'] = processed_data
            
        elif isinstance(data, list):
            # 리스트 데이터 처리
            processed_items = []
            for item in data:
                processed_items.append(self._process_item(item))
            result['processed_items'] = processed_items
            
        else:
            # 기타 데이터 타입
            result['raw_data'] = str(data)
        
        # 4. 메타데이터 추가
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            "status": "success",
            "result": result,
            "metadata": {
                "execution_time": execution_time,
                "user_query": user_query,
                "data_type": type(data).__name__,
                "timestamp": datetime.now().isoformat()
            }
        }
        
    except Exception as e:
        logger.error(f"처리 중 오류: {str(e)}")
        return {
            "error": str(e),
            "message": f"요청 처리 중 오류가 발생했습니다: {str(e)}",
            "execution_time": (datetime.now() - start_time).total_seconds()
        }

def _process_item(self, item: Any) -> Any:
    \"\"\"개별 항목 처리 헬퍼 함수\"\"\"
    # 실제 처리 로직 구현
    return item  # 예시로 그대로 반환
```

### 주의사항:
- 모든 변수는 사용 전 초기화
- f-string에서 이중 중괄호 사용 금지
- 백틱(```) 사용 금지
- 에러 처리 필수
"""
        }
        
        # Replace the placeholder with actual user request
        base_prompt = base_prompt.replace("USER_REQUEST_PLACEHOLDER", user_request)
        
        # Build final prompts with replaced base_prompt
        final_prompts = {}
        if template_id in template_prompts:
            logger.info(f"✅ Using specific prompts for template: {template_id}")
            for key, value in template_prompts[template_id].items():
                # Each value is base_prompt + additional template-specific content
                final_prompts[key] = value.replace("USER_REQUEST_PLACEHOLDER", user_request)
        else:
            logger.warning(f"⚠️ Template '{template_id}' has no specific prompts, using default prompts")
            for key, value in default_prompts.items():
                final_prompts[key] = value.replace("USER_REQUEST_PLACEHOLDER", user_request)
        
        # Ensure prompts are never empty
        if not final_prompts:
            logger.error(f"❌ No prompts available for template '{template_id}', forcing default")
            final_prompts = {
                "_agentic_analysis": base_prompt + f"\n\n사용자 요청: {user_request}\n\n핵심 로직을 구현하세요."
            }
        
        return final_prompts
    
    def _clean_code_response(self, code: str) -> str:
        """LLM 응답에서 순수 코드만 추출합니다 - JSON 파싱 실패 시 fallback"""
        logger.debug(f"🧹 Cleaning code response - Original length: {len(code)}")
        
        # Remove markdown code blocks if present
        if '```' in code:
            logger.warning(f"⚠️ Found backticks in response, removing...")
            # Remove all markdown patterns
            code = re.sub(r'```(?:python|py)?\s*\n?', '', code)
            code = re.sub(r'\n?```', '', code)
        
        # Remove leading comments or explanations
        lines = code.split('\n')
        cleaned_lines = []
        code_started = False
        
        for line in lines:
            # Skip empty lines at the beginning
            if not code_started and not line.strip():
                continue
            
            # Skip comment lines at the beginning (but not docstrings)
            if not code_started and line.strip().startswith('#') and not line.strip().startswith('"""'):
                continue
            
            # Mark code as started when we see actual code
            if line.strip() and (not line.strip().startswith('#') or line.strip().startswith('"""')):
                code_started = True
            
            if code_started:
                cleaned_lines.append(line)
        
        result = '\n'.join(cleaned_lines).strip()
        logger.debug(f"✅ Cleaned code - Final length: {len(result)}")
        return result
    
    def _fix_multiline_string_issues(self, code: str) -> str:
        """여러 줄에 걸친 문자열 문제를 수정합니다."""
        lines = code.split('\n')
        fixed_lines = []
        
        # initialize_llm 메서드의 백틱 문제 해결
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # initialize_llm 메서드 호출 패턴 감지
            if 'await self.agentic_engine.initialize_llm(' in line:
                logger.warning(f"Found initialize_llm call at line {i}: {line.strip()}")
                fixed_lines.append(line)
                i += 1
                
                # 파라미터들을 수집
                params = []
                while i < len(lines) and ')' not in lines[i-1]:
                    param_line = lines[i].strip()
                    
                    # 백틱이나 중복된 라인 제거
                    if param_line in ['```', '```python', '```py'] or param_line.startswith('```'):
                        logger.debug(f"  Skipping backtick line {i}: {param_line}")
                        i += 1
                        continue
                    
                    # model= 파라미터가 중복되었는지 확인
                    if 'model=' in param_line and any('model=' in p for p in params):
                        logger.debug(f"  Skipping duplicate model line {i}: {param_line}")
                        i += 1
                        continue
                        
                    # temperature= 파라미터가 중복되었는지 확인
                    if 'temperature=' in param_line:
                        # 이미 temperature가 있으면 건너뜀
                        if any('temperature=' in p for p in params):
                            logger.debug(f"  Skipping duplicate temperature line {i}: {param_line}")
                            i += 1
                            continue
                        # 백틱 제거
                        param_line = param_line.replace('```python', '').replace('```py', '').replace('```', '').strip()
                        # 끝에 쉼표가 없으면 추가
                        if param_line and not param_line.endswith(',') and not param_line.endswith(')'):
                            param_line += ','
                    
                    if param_line:
                        params.append('                ' + param_line)
                    i += 1
                
                # 파라미터들을 fixed_lines에 추가
                fixed_lines.extend(params)
                continue
            
            # 문자열이 시작되었지만 끝나지 않은 경우 확인
            quote_count = line.count('"') - line.count('\\"')
            single_quote_count = line.count("'") - line.count("\\'")
            
            # 홀수 개의 따옴표가 있으면 문자열이 닫히지 않은 것
            if quote_count % 2 == 1:
                # 줄 끝에 닫는 따옴표 추가
                line = line.rstrip() + '"'
                # 함수 호출이 끝나지 않은 경우를 대비해 괄호도 닫기
                if '(' in line and ')' not in line:
                    line += ')'
            elif single_quote_count % 2 == 1:
                line = line.rstrip() + "'"
                if '(' in line and ')' not in line:
                    line += ')'
            
            # 특정 패턴 수정 - 빈 plotting 함수는 placeholder로 처리
            # df 변수가 정의되지 않은 상태에서 참조하지 않도록 수정
            if line.strip().endswith('plt.scatter('):
                line = line.rstrip('(') + '([], [])'  # 빈 데이터로 초기화
            elif line.strip().endswith('plt.hist('):
                line = line.rstrip('(') + '([])'  # 빈 데이터로 초기화
            elif line.strip().endswith('plt.plot('):
                line = line.rstrip('(') + '([], [])'  # 빈 데이터로 초기화
            
            fixed_lines.append(line)
            i += 1
        
        return '\n'.join(fixed_lines)
    
    async def inject_business_logic(self, template_path: Path, 
                                  business_logic: Dict[str, str]) -> str:
        """
        템플릿에 비즈니스 로직을 주입하여 완성된 코드를 생성합니다.
        """
        # 템플릿 파일 읽기
        with open(template_path, 'r', encoding='utf-8') as f:
            template_code = f.read()
        
        # 비즈니스 로직 슬롯 찾기 및 교체
        for section, code in business_logic.items():
            # Skip non-string values (like metadata dicts)
            if not isinstance(code, str):
                continue
                
            # 슬롯 패턴: # ==================== [section] 슬롯 시작 ====================
            #           ... 기존 코드 ...
            #           # ==================== [section] 슬롯 끝 ====================
            
            start_marker = f"# ==================== 비즈니스 로직 슬롯 시작 ===================="
            end_marker = f"# ==================== 비즈니스 로직 슬롯 끝 ===================="
            
            # 더 구체적인 섹션 마커가 있으면 사용
            section_start = f"# ==================== {section} 시작 ===================="
            section_end = f"# ==================== {section} 끝 ===================="
            
            if section_start in template_code and section_end in template_code:
                start_marker = section_start
                end_marker = section_end
            
            # 슬롯 교체
            if start_marker in template_code and end_marker in template_code:
                start_idx = template_code.find(start_marker) + len(start_marker)
                end_idx = template_code.find(end_marker)
                
                # 기존 코드의 인덴트 레벨 유지
                existing_code = template_code[start_idx:end_idx]
                indent_match = re.match(r'\n(\s*)', existing_code)
                indent = indent_match.group(1) if indent_match else '    '
                
                # 코드 정제 - 문자열 문제 수정
                cleaned_code = self._fix_multiline_string_issues(code)
                
                # 새 코드에 인덴트 적용
                indented_code = '\n'.join(
                    indent + line if line.strip() else line
                    for line in cleaned_code.split('\n')
                )
                
                # 코드 교체
                template_code = (
                    template_code[:start_idx] + 
                    '\n' + indented_code + '\n' + indent +
                    template_code[end_idx:]
                )
        
        # 템플릿 변수 치환 적용
        logger.info(f"🔄 About to apply template variables. Business logic has {len(business_logic)} keys")
        for key, value in business_logic.items():
            logger.info(f"  {key}: {str(value)[:100]}...")
        template_code = self._apply_template_variables(template_code, business_logic)
        
        # 사용자 정의 설정 적용
        template_code = self._apply_custom_config(template_code, business_logic)
        
        # 샘플 코드 추가
        if "sample_code" in business_logic:
            logger.info("📝 Adding sample code to template")
            sample_code = business_logic["sample_code"]
            
            # 템플릿 끝에 샘플 코드 추가
            template_code = template_code.rstrip() + "\n\n\n# ==================== 샘플 실행 코드 ====================\n\n" + sample_code
        
        # 최종 백틱 정리 - 모든 백틱 패턴을 완전히 제거
        logger.info("🧹 Final cleanup - removing any remaining backticks")
        
        # 백틱 개수 확인
        initial_backtick_count = template_code.count('```')
        if initial_backtick_count > 0:
            logger.warning(f"⚠️ Found {initial_backtick_count} backticks in assembled code")
            
            # 모든 백틱 패턴 제거
            template_code = re.sub(r'```python\s*\n?', '', template_code)
            template_code = re.sub(r'```py\s*\n?', '', template_code)
            template_code = re.sub(r'```\s*\n?', '', template_code)
            template_code = re.sub(r'\n?```', '', template_code)
            
            # 라인별 정리
            lines = template_code.split('\n')
            cleaned_lines = []
            skip_next_lines = 0
            
            for i, line in enumerate(lines):
                # 건너뛸 라인이 있으면 건너뜀
                if skip_next_lines > 0:
                    skip_next_lines -= 1
                    logger.debug(f"  Skipping line {i} in final cleanup: {line.strip()}")
                    continue
                    
                # 백틱만 있는 라인 제거
                if line.strip() in ['```', '```python', '```py']:
                    logger.debug(f"  Removing line {i}: {line.strip()}")
                    continue
                    
                # temperature 파라미터 특별 처리
                if 'temperature=' in line and 'get(' in line and '```' in line:
                    logger.warning(f"  Found temperature line with backticks in final cleanup: {line.strip()}")
                    line = line.replace('```python', '').replace('```py', '').replace('```', '')
                    # 다음 몇 줄 확인
                    for j in range(1, min(6, len(lines) - i)):
                        if i + j < len(lines):
                            next_line = lines[i + j]
                            if '```' in next_line or ('temperature=' in next_line and 'get(' in next_line):
                                skip_next_lines += 1
                            else:
                                break
                    
                # 라인 내 백틱 제거
                elif '```' in line:
                    original_line = line
                    line = line.replace('```python', '')
                    line = line.replace('```py', '')
                    line = line.replace('```', '')
                    if line != original_line:
                        logger.debug(f"  Cleaned line {i}: {original_line[:50]}... -> {line[:50]}...")
                
                cleaned_lines.append(line)
            
            template_code = '\n'.join(cleaned_lines)
            
            # 최종 확인
            final_backtick_count = template_code.count('```')
            if final_backtick_count > 0:
                logger.error(f"❌ Still {final_backtick_count} backticks remain after final cleanup!")
            else:
                logger.info(f"✅ Successfully removed all {initial_backtick_count} backticks")
        else:
            logger.info("✅ No backticks found in assembled code")
        
        return template_code
    
    def _apply_template_variables(self, code: str, business_logic: Dict[str, str]) -> str:
        """템플릿 변수를 실제 값으로 치환합니다."""
        logger.info("🔄 Applying template variables substitution")
        logger.info(f"📊 Business logic keys: {list(business_logic.keys())}")
        logger.info(f"🎯 agent_class_name: {business_logic.get('agent_class_name', 'NOT_FOUND')}")
        
        # EMERGENCY FIX: 필수 메타데이터 강제 생성
        self._ensure_required_metadata(business_logic)
        
        # Check for template variables in input code
        import re
        input_vars = re.findall(r'\{[^}]+\}', code)
        if input_vars:
            logger.info(f"📝 Input template variables: {input_vars}")
        else:
            logger.info("📝 No template variables found in input code")
        
        # 기본 변수들 생성 (향상된 기본값)
        replacements = {
            '{agent_class_name}': business_logic.get('agent_class_name', 'GeneratedAgent'),
            '{agent_name}': business_logic.get('agent_name', 'Generated Agent'),
            '{agent_description}': business_logic.get('agent_description', 'Auto-generated agent for data processing'),
            '{agent_type}': business_logic.get('agent_type', 'CUSTOM'),
            '{custom_config}': business_logic.get('custom_config', '{"timeout": 60, "retry_attempts": 3}'),
            '{custom_init}': business_logic.get('custom_init', '# Custom initialization'),
            '{custom_async_init}': business_logic.get('custom_async_init', '# Async initialization'),
            '{core_business_logic}': business_logic.get('core_business_logic', 'pass  # Business logic placeholder'),
            '{initialization}': business_logic.get('initialization', '# Initialization code'),
            '{sample_data}': business_logic.get('sample_data', '{"sample": "data"}'),
            '{test_queries}': business_logic.get('test_queries', '["test query"]'),
            '{query_extraction_prompt}': 'Extract key information from the user query',
            '{response_generation_prompt}': 'Generate a helpful response based on analysis',
            '{insights_generation_prompt}': 'Provide insights from the processed data',
            '{custom_cleanup}': '# Cleanup code',
        }
        
        # 변수 치환 실행 with proper indentation
        for placeholder, value in replacements.items():
            if placeholder in code:
                logger.info(f"  Replacing {placeholder} with: {value[:50]}...")
                
                # Special handling for multi-line code blocks
                if '\n' in value and placeholder in ['{custom_init}', '{core_business_logic}', '{initialization}']:
                    # Find the indentation of the placeholder line
                    lines = code.split('\n')
                    for i, line in enumerate(lines):
                        if placeholder in line:
                            # Get the indentation of this line up to the placeholder
                            import re
                            indent_match = re.match(r'^(\s*)', line)
                            base_indent = indent_match.group(1) if indent_match else ''
                            
                            # Apply this indentation to all lines of the value
                            value_lines = value.split('\n')
                            indented_lines = []
                            for j, value_line in enumerate(value_lines):
                                if j == 0:
                                    # First line doesn't need extra indent
                                    indented_lines.append(value_line)
                                else:
                                    # Other lines need the base indentation
                                    indented_lines.append(base_indent + value_line if value_line.strip() else value_line)
                            
                            value = '\n'.join(indented_lines)
                            break
                
                code = code.replace(placeholder, value)
        
        # 런타임 변수는 보호 (Python 코드에서 실행 시 사용되는 변수들)
        RUNTIME_VARIABLES = {
            '{query}': 'query',  # 변수 참조로 치환
            '{extracted_info}': 'extracted_info',  # 변수 참조로 치환
            '{je}': 'e',  # 예외 변수 (json exception을 je로 약칭)
            '{e}': 'e',  # 일반 예외 변수
            '{result}': 'result',  # 결과 변수
            '{data}': 'data',  # 데이터 변수
        }
        
        # 남아있는 템플릿 변수가 있는지 확인 (alphanumeric names only, excluding JSON)
        remaining_var_names = re.findall(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}', code)
        remaining_vars = [f'{{{var}}}' for var in remaining_var_names]
        
        if remaining_vars:
            logger.warning(f"⚠️ Remaining template variables: {remaining_vars}")
            # 기본값으로 치환 - 실제 동작하는 코드로
            default_replacements = {
                **RUNTIME_VARIABLES,  # 런타임 변수들
                '{sample_data_code}': '# Sample data generation code',
                '{custom_config}': '{}',  # 빈 딕셔너리로 치환
                '{custom_init}': '# Custom initialization based on template',
                '{custom_async_init}': '# Async initialization if needed',
                '{custom_cleanup}': '# Cleanup code',
                '{{query}}': '{query}',  # 이중 중괄호는 단일로
                '{{extracted_info}}': '{extracted_info}',
            }
            
            for var in remaining_vars:
                if var in default_replacements:
                    replacement = default_replacements[var]
                    code = code.replace(var, replacement)
                    logger.info(f"  Replaced {var} with: {replacement[:50]}...")
                else:
                    var_name = var.strip('{}')
                    if var_name not in ['user_request', 'sample_data_code']:
                        # 변수명만 남기기 (주석 대신)
                        code = code.replace(var, var_name)
                        logger.info(f"  Replaced {var} with variable name: {var_name}")
        
        # 🔥 CRITICAL: Apply f-string fixes
        code = self._fix_fstring_syntax_errors(code)
        return code

    def _apply_custom_config(self, code: str, business_logic: Dict[str, Any]) -> str:
        """사용자 정의 설정을 적용합니다."""
        # 에이전트 이름 커스터마이징
        if "agent_name" in business_logic:
            code = code.replace(
                'name="CSV/Excel Data Analyzer"',
                f'name="{business_logic["agent_name"]}"'
            )
        
        # 설명 커스터마이징
        if "agent_description" in business_logic:
            code = code.replace(
                'description="복잡한 데이터셋을 분석하여 비즈니스 인사이트와 예측 모델을 생성합니다"',
                f'description="{business_logic["agent_description"]}"'
            )
        
        return code
    
    async def generate_agent_code(self, user_request: str, llm_client: Any, 
                                metadata: Dict[str, Any] = None) -> Tuple[str, Dict[str, Any]]:
        """
        전체 에이전트 코드 생성 파이프라인
        
        Returns:
            Tuple[generated_code, generation_metadata]
        """
        try:
            # 1. 템플릿 선택
            template_id, confidence = await self.select_template(user_request, metadata)
            
            # 2. 비즈니스 로직 생성
            business_logic = await self.generate_business_logic(
                template_id, user_request, llm_client
            )
            
            # 3. 템플릿 파일 경로 확인
            template_info = self.template_registry["templates"][template_id]
            template_path = self.templates_dir / template_info["file"]
            
            if not template_path.exists():
                # 폴백: 기본 템플릿 사용
                logger.warning(f"⚠️ 템플릿 파일을 찾을 수 없음: {template_path}")
                # comprehensive 템플릿을 기본으로 사용 (더 완전한 템플릿)
                fallback_path = self.templates_dir / "comprehensive_agent.py.template"
                if fallback_path.exists():
                    logger.info(f"✅ Using comprehensive template as fallback")
                    template_path = fallback_path
                else:
                    logger.info(f"📋 Using basic LogosAI template as fallback")
                    template_path = self.templates_dir / "logosai_agent_template.py.template"
            
            # 4. 비즈니스 로직 주입
            generated_code = await self.inject_business_logic(template_path, business_logic)
            
            # 4.5. 최종 백틱 확인
            final_backtick_count = generated_code.count('```')
            if final_backtick_count > 0:
                logger.error(f"❌ CRITICAL: {final_backtick_count} backticks found in final code!")
                logger.error("This should not happen with JSON-based generation. Check LLM response format.")
            
            # 5. 메타데이터 생성
            generation_metadata = {
                "template_used": template_id,
                "template_confidence": confidence,
                "template_category": template_info["category"],
                "business_logic_sections": list(business_logic.keys()),
                "generation_timestamp": datetime.now().isoformat(),
                "request_summary": user_request[:100] + "..." if len(user_request) > 100 else user_request,
                "backticks_removed": final_backtick_count > 0
            }
            
            logger.info(f"에이전트 코드 생성 완료: {template_id} 템플릿 사용")
            return generated_code, generation_metadata
            
        except Exception as e:
            logger.error(f"에이전트 코드 생성 실패: {e}")
            raise
    
    def get_available_templates(self) -> Dict[str, List[Dict[str, Any]]]:
        """사용 가능한 템플릿 목록을 카테고리별로 반환합니다."""
        categorized_templates = {}
        
        for category_id, category_name in self.template_registry["categories"].items():
            categorized_templates[category_name] = []
            
            for template_id in self.category_mapping.get(category_id, []):
                template_info = self.template_registry["templates"][template_id]
                categorized_templates[category_name].append({
                    "id": template_id,
                    "name": template_info["name"],
                    "description": template_info["description"],
                    "keywords": template_info["keywords"]
                })
        
        return categorized_templates
    
    def _clean_code_response(self, response: str) -> str:
        """LLM 응답에서 순수 코드만 추출"""
        # 모든 종류의 백틱 패턴을 체계적으로 제거
        # 1. 마크다운 코드 블록 시작/끝 패턴
        response = re.sub(r'```python\s*\n?', '', response)
        response = re.sub(r'```py\s*\n?', '', response)
        response = re.sub(r'```\s*\n?', '', response)
        response = re.sub(r'\n?```', '', response)
        
        # 2. 코드 블록 내부에 있을 수 있는 백틱 라인 제거
        lines = response.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # 백틱만 있는 라인 완전 제거
            if line.strip() in ['```', '```python', '```py']:
                continue
            # 라인 내 백틱 패턴 제거 (문자열 내부가 아닌 경우)
            if '```' in line:
                # 문자열 내부가 아닌 백틱은 제거
                if not ('"' in line.split('```')[0] or "'" in line.split('```')[0]):
                    line = line.replace('```', '')
            cleaned_lines.append(line)
        
        response = '\n'.join(cleaned_lines).strip()
        
        # 3. 추가 정리 - 남아있을 수 있는 패턴들
        response = response.replace('```python', '')
        response = response.replace('```py', '')
        response = response.replace('```', '')
        
        return response
    
    def _get_fallback_implementation(self, section: str) -> str:
        """실패 시 기본 구현 제공"""
        fallback_implementations = {
            "data_processing": """
    # 기본 데이터 처리 구현
    try:
        result = {
            "row_count": len(df),
            "columns": list(df.columns),
            "data_types": df.dtypes.to_dict()
        }
        return result
    except Exception as e:
        logger.error(f"데이터 처리 실패: {e}")
        return {"error": str(e)}
""",
            "analysis": """
    # 기본 분석 구현
    try:
        return {
            "status": "basic_analysis",
            "message": "기본 분석이 수행되었습니다.",
            "data": processed_data
        }
    except Exception as e:
        logger.error(f"분석 실패: {e}")
        return {"error": str(e)}
""",
            "scraping": """
    # 기본 스크래핑 구현
    results = []
    for url in urls:
        results.append({
            "url": url,
            "status": "not_implemented",
            "timestamp": datetime.now().isoformat()
        })
    return results
""",
            "alert_logic": """
    # 기본 알림 로직
    alerts = []
    if changes:
        alerts.append({
            "type": "info",
            "message": "변경사항이 감지되었습니다.",
            "timestamp": datetime.now().isoformat()
        })
    return alerts
""",
            "ml_processing": """
    # 기본 ML 처리
    return {
        "status": "basic_prediction",
        "confidence": 0.5,
        "result": "기본 예측 결과"
    }
""",
            "prediction": """
    # 기본 예측
    return {
        "prediction": None,
        "confidence": 0.0,
        "message": "예측 기능이 구현되지 않았습니다."
    }
""",
            "sentiment": """
    # 기본 감정 분석
    return {
        "sentiment": "neutral",
        "confidence": 0.5,
        "scores": {"positive": 0.33, "neutral": 0.34, "negative": 0.33}
    }
""",
            "classification": """
    # 기본 분류
    return {
        "category": "unknown",
        "confidence": 0.0,
        "message": "분류 기능이 구현되지 않았습니다."
    }
""",
            "performance_check": """
    # 기본 성능 체크
    return {
        "status": "unknown",
        "metrics": {},
        "timestamp": datetime.now().isoformat()
    }
""",
            "optimization": """
    # 기본 최적화
    return {
        "optimized": False,
        "suggestions": ["최적화 기능이 구현되지 않았습니다."],
        "current_metrics": metrics
    }
""",
            "kpi_calculation": """
    # 기본 KPI 계산
    return {
        "kpis": {},
        "status": "not_calculated",
        "timestamp": datetime.now().isoformat()
    }
""",
            "visualization": """
    # 기본 시각화 데이터
    return {
        "chart_type": "none",
        "data": [],
        "message": "시각화 데이터가 준비되지 않았습니다."
    }
"""
        }
        
        # 섹션에 맞는 기본 구현 반환, 없으면 최소 구현
        return fallback_implementations.get(section, """
    # 기본 구현
    logger.warning(f"{section} - 기본 구현 사용")
    return {"status": "not_implemented", "section": section}
""")
    
    async def _generate_sample_code(self, agent_name: str, business_logic: Dict[str, str], 
                                  user_request: str, llm_client: Any) -> str:
        """Generate appropriate sample code based on the agent type"""
        
        # Get agent class name from business logic
        agent_class = business_logic.get('agent_class_name', 'Agent')
        
        prompt = f"""Generate Python sample code to demonstrate the {agent_name} agent.

User request: {user_request}
Agent class name: {agent_class}

## Response Format (VERY IMPORTANT!)

You must respond ONLY with a JSON object in the following format. Do not add any text before or after the JSON:
{{
    "code": "Complete Python sample code here"
}}

Requirements for the code:
1. Create a realistic test scenario with proper sample data
2. Show how to import and instantiate the {agent_class} class
3. Include detailed sample data creation (at least 5-10 data points)
4. Execute the agent with the sample data
5. Print the results clearly with formatted output
6. Handle any errors gracefully with try-except blocks
7. Make it self-contained and runnable
8. DO NOT include 'if __name__ == "__main__":' wrapper - the template already has it
9. Focus only on the main() function content that will replace {{sample_code}} placeholder
10. Code should be indented with 4 spaces (for inside main function)
11. IMPORTANT: Generate COMPLETE code, at least 500 characters. Do not truncate or use ellipsis.

Example structure:
    # Import necessary modules
    import pandas as pd
    from datetime import datetime
    
    # Create sample data
    sample_data = {{
        "field1": ["value1", "value2", "value3"],
        "field2": [100, 200, 300],
        # ... more fields
    }}
    
    # Create agent instance
    agent = {agent_class}()
    await agent.initialize()
    
    # Process the data
    try:
        result = await agent.process({{"data": sample_data, "query": "analyze this"}})
        print("Results:", result.content)
    except Exception as e:
        print("Error:", e)

Remember: Return ONLY the JSON object in the format specified above."""

        try:
            response = await llm_client.invoke(prompt)
            # response 객체에서 실제 내용 추출 (invoke와 동일한 방식)
            if hasattr(response, 'content'):
                raw_response = response.content
            else:
                raw_response = str(response)
            sample_code = self._parse_json_code_response(raw_response)
            
            # Remove any accidentally added main wrapper to prevent duplicates
            import re
            sample_code = re.sub(r'if __name__ == "__main__":[\\s\\S]*?asyncio\\.run\\([^)]+\\)\\s*$', '', sample_code).strip()
            
            # If the code doesn't start with proper indentation, assume it's main content
            if sample_code and not sample_code.startswith('    '):
                # Indent all lines for main() function content
                indented_lines = ['    ' + line if line.strip() else line for line in sample_code.split('\n')]
                sample_code = '\n'.join(indented_lines)
            
            # Clean up any trailing backslashes
            if sample_code.endswith('\\'):
                sample_code = sample_code.rstrip('\\').rstrip()
            
            # If sample code is still empty or very short, provide default content
            if len(sample_code.strip()) < 300:  # Increased minimum length
                agent_class = business_logic.get('agent_class_name', 'Agent')
                sample_code = f"""    # Import necessary modules
    import pandas as pd
    from datetime import datetime
    
    # Create sample data for testing
    sample_data = {{
        "data": pd.DataFrame({{
            "date": ["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05"],
            "product": ["Product A", "Product B", "Product A", "Product C", "Product B"],
            "quantity": [10, 15, 20, 5, 12],
            "price": [100.0, 150.0, 100.0, 200.0, 150.0],
            "customer": ["Customer 1", "Customer 2", "Customer 3", "Customer 1", "Customer 2"]
        }}),
        "query": "Analyze the sales data and provide insights"
    }}
    
    # Create and initialize agent
    print("Creating agent instance...")
    agent = {agent_class}()
    
    print("Initializing agent...")
    await agent.initialize()
    
    print("Processing request...")
    try:
        # Process the request
        response = await agent.process(sample_data)
        
        # Print results
        if response.type == AgentResponseType.SUCCESS:
            print("\\n✅ Success!")
            print(f"Answer: {response.content.get('answer', 'No answer')}")
            
            # Print additional details if available
            if 'analysis' in response.content:
                print(f"\\nAnalysis: {response.content['analysis']}")
            if 'metrics' in response.content:
                print(f"\\nMetrics: {response.content['metrics']}")
        else:
            print(f"\\n❌ Error: {response.content.get('error', 'Unknown error')}")
            
    except Exception as e:
        print(f"\\n❌ Exception occurred: {str(e)}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Cleanup
        print("\\nShutting down agent...")
        await agent.shutdown()
        print("Done!")"""
            
            return sample_code
            
        except Exception as e:
            logger.error(f"Sample code generation failed: {e}")
            return self._get_default_sample_code(agent_name)
    
    def _get_default_sample_code(self, template_id: str) -> str:
        """Get default sample code for a template"""
        
        default_samples = {
            "csv_excel_analyzer": """    # Create and initialize agent
    agent = CSVExcelAnalyzerAgent()
    await agent.initialize()
    
    # Sample data
    import pandas as pd
    data = pd.DataFrame({
        'A': [1, 2, 3, 4, 5],
        'B': [10, 20, 30, 40, 50]
    })
    
    # Process request
    response = await agent.process({
        'data': data,
        'query': 'Analyze this data'
    })
    
    print(response.content)
    
    await agent.shutdown()"""
        }
        
        # Return content without main wrapper (templates already have it)
        template_content = default_samples.get(template_id, """    print("Sample code not available for this template")""")
        
        # Remove main wrapper if accidentally included
        import re
        template_content = re.sub(r'if __name__ == "__main__":[\\s\\S]*?asyncio\\.run\\([^)]+\\)\\s*$', '', template_content).strip()
        
        # Ensure proper indentation for main() function content
        if template_content and not template_content.startswith('    '):
            indented_lines = ['    ' + line if line.strip() else line for line in template_content.split('\n')]
            template_content = '\n'.join(indented_lines)
        
        return template_content
    
    def _emergency_backtick_removal(self, code: str) -> str:
        """긴급 백틱 제거 - 모든 백틱을 완전히 제거"""
        logger.warning("🚨 Emergency backtick removal activated!")
        
        # 1. 정규식으로 모든 백틱 패턴 제거
        code = re.sub(r'```python\s*\n?', '', code)
        code = re.sub(r'```py\s*\n?', '', code)
        code = re.sub(r'```\s*\n?', '', code)
        code = re.sub(r'\n?```', '', code)
        
        # 2. 라인별 처리
        lines = code.split('\n')
        cleaned_lines = []
        skip_lines = 0
        
        for i, line in enumerate(lines):
            if skip_lines > 0:
                skip_lines -= 1
                continue
                
            # 백틱만 있는 라인 제거
            if line.strip() in ['```', '```python', '```py']:
                continue
                
            # initialize_llm 특별 처리
            if 'await self.agentic_engine.initialize_llm(' in line or 'self.agentic_engine.initialize_llm(' in line:
                cleaned_lines.append(line)
                # 다음 라인들을 수집하여 중복 제거
                j = i + 1
                params_seen = set()
                param_lines = []
                
                while j < len(lines) and ')' not in lines[j-1]:
                    param_line = lines[j].strip()
                    
                    # 백틱이나 빈 라인 건너뛰기
                    if '```' in param_line or not param_line:
                        j += 1
                        continue
                    
                    # 파라미터 추출
                    if '=' in param_line:
                        param_name = param_line.split('=')[0].strip()
                        # 이미 본 파라미터면 스킵
                        if param_name in params_seen:
                            j += 1
                            continue
                            
                        params_seen.add(param_name)
                        # 백틱 제거
                        param_line = param_line.replace('```python', '').replace('```py', '').replace('```', '')
                        # 쉼표 처리
                        if not param_line.endswith(',') and not param_line.endswith(')'):
                            param_line += ','
                        param_lines.append('                ' + param_line)
                    elif param_line == ')':
                        param_lines.append('            )')
                        j += 1
                        break
                    
                    j += 1
                
                # 정리된 파라미터 추가
                cleaned_lines.extend(param_lines)
                skip_lines = j - i - 1
                continue
            
            # 일반 라인의 백틱 제거
            if '```' in line:
                line = line.replace('```python', '').replace('```py', '').replace('```', '')
            
            cleaned_lines.append(line)
        
        cleaned_code = '\n'.join(cleaned_lines)
        
        # 3. 최종 확인 및 정리
        remaining = cleaned_code.count('```')
        if remaining > 0:
            logger.error(f"🚨 Emergency removal incomplete: {remaining} backticks remain")
            # 무차별 제거
            cleaned_code = cleaned_code.replace('```', '')
        
        # 4. 중복된 model= 라인 제거
        final_lines = []
        prev_line = ""
        for line in cleaned_code.split('\n'):
            # 연속된 중복 라인 제거
            if line.strip() == prev_line.strip() and 'model=' in line:
                continue
            final_lines.append(line)
            prev_line = line
            
        return '\n'.join(final_lines)
    
    def _clean_json_contamination(self, response: str) -> str:
        """JSON 응답에서 오염 요소를 제거합니다."""
        # JSON 블록만 추출
        if '```json' in response:
            start = response.find('```json') + 7
            end = response.find('```', start)
            if end != -1:
                response = response[start:end].strip()
        
        # 오염 패턴 제거
        contamination_patterns = [
            'exec("""',
            '""")',
            '{"code": "from logosai',  # 잘못된 시작
        ]
        
        for pattern in contamination_patterns:
            response = response.replace(pattern, '')
        
        # 이중 이스케이프 정리
        response = response.replace('\\\\n', '\\n')
        response = response.replace('\\\\t', '\\t')
        response = response.replace('\\\\"', '\\"')
        
        return response.strip()
    
    def _parse_json_code_response(self, response: str) -> str:
        """Parse JSON response containing code - UPGRADED with UniversalCodeParser"""
        
        logger.info("🚀 Using UPGRADED UniversalCodeParser for 99% success rate")
        
        # Import required modules at the beginning
        import json
        import re
        
        try:
            # 🔥 STRATEGY 0: Handle markdown JSON blocks BEFORE cleaning (```json ... ```)
            if '```json' in response:
                logger.info("📝 Detected JSON in markdown block, extracting...")
                start_idx = response.find('```json') + 7
                end_idx = response.find('```', start_idx)
                if end_idx != -1:
                    json_str = response[start_idx:end_idx].strip()
                    try:
                        data = json.loads(json_str)
                        if 'code' in data and isinstance(data['code'], str):
                            extracted_code = data['code']
                            logger.info(f"✅ Markdown JSON extraction SUCCESS: {len(extracted_code)} chars")
                            # Clean up escaped characters
                            cleaned = extracted_code.replace('\\n', '\n').replace('\\t', '    ').replace('\\"', '"')
                            return cleaned
                    except json.JSONDecodeError as e:
                        logger.warning(f"Markdown JSON parsing failed: {e}")
            
            # 🧹 Clean JSON contamination if markdown parsing failed
            response = self._clean_json_contamination(response)
            
            # 🔥 STRATEGY 1: Direct JSON parsing for {"code": "..."} format
            response_stripped = response.strip()
            
            # Check if it's a JSON object with "code" field
            if response_stripped.startswith('{') and '"code"' in response_stripped:
                logger.info("📝 Detected JSON with 'code' field, parsing...")
                try:
                    data = json.loads(response_stripped)
                    if 'code' in data and isinstance(data['code'], str):
                        extracted_code = data['code']
                        logger.info(f"✅ JSON extraction SUCCESS: {len(extracted_code)} chars")
                        # Clean up escaped characters
                        cleaned = extracted_code.replace('\\n', '\n').replace('\\t', '    ').replace('\\"', '"')
                        return cleaned
                except json.JSONDecodeError as e:
                    logger.warning(f"Direct JSON parsing failed: {e}")
            
            # 🔥 STRATEGY 2: Regex extraction for {"code": "..."} pattern
            json_pattern = r'\{\s*"code"\s*:\s*"([^"]*(?:\\"[^"]*)*)"'
            match = re.search(json_pattern, response_stripped, re.DOTALL)
            if match:
                code_content = match.group(1)
                logger.info(f"✅ Regex JSON extraction SUCCESS: {len(code_content)} chars")
                # Unescape and clean
                cleaned = code_content.replace('\\"', '"').replace('\\n', '\n').replace('\\t', '    ')
                return cleaned
            
            # 🔥 STRATEGY 3: UniversalCodeParser fallback
            logger.info("🔧 Fallback: UniversalCodeParser")
            from .universal_code_parser import UniversalCodeParser
            parser = UniversalCodeParser()
            parsed_code = parser.parse(response)
            if parsed_code and len(parsed_code.strip()) > 10:
                logger.info(f"✅ UniversalCodeParser SUCCESS: {len(parsed_code)} chars")
                return parsed_code
            
            # 🔥 STRATEGY 4: Enhanced JSON parsing
            logger.info("🔧 Final fallback: Enhanced JSON parsing")
            return self._enhanced_json_parsing(response)
            
        except Exception as e:
            logger.error(f"UniversalCodeParser failed: {e}")
            return self._enhanced_json_parsing(response)
    
    def _enhanced_json_parsing(self, response: str) -> str:
        """Enhanced JSON parsing with multiple strategies"""
        
        try:
            response = response.strip()
            
            # Strategy 1: Direct JSON parsing
            try:
                import json
                data = json.loads(response)
                if isinstance(data, dict) and 'code' in data:
                    logger.info("✅ Direct JSON parsing success")
                    return str(data['code'])
            except json.JSONDecodeError:
                pass
            
            # Strategy 2: Find JSON block
            if '{"code":' in response:
                start = response.find('{"code":')
                # Find matching closing brace
                brace_count = 0
                end = start
                for i, char in enumerate(response[start:], start):
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        brace_count -= 1
                        if brace_count == 0:
                            end = i + 1
                            break
                
                if end > start:
                    json_str = response[start:end]
                    try:
                        data = json.loads(json_str)
                        if 'code' in data:
                            logger.info("✅ JSON block extraction success")
                            return str(data['code'])
                    except:
                        pass
            
            # Strategy 3: Regex extraction
            import re
            patterns = [
                r'"code"\s*:\s*"([^"]*)"',
                r'"code"\s*:\s*`([^`]*)`',
                r'"code"\s*:\s*([^,}]*)',
            ]
            
            for pattern in patterns:
                match = re.search(pattern, response, re.DOTALL)
                if match:
                    logger.info(f"✅ Regex extraction success: {pattern[:20]}...")
                    return match.group(1).strip()
            
            # Strategy 4: Clean response (no JSON found)
            logger.warning("No JSON found, returning cleaned response")
            return self._clean_code_response(response)
            
        except Exception as e:
            logger.error(f"Enhanced JSON parsing failed: {e}")
            return self._clean_code_response(response)
    
    def _ensure_required_metadata(self, business_logic: Dict[str, str]):
        """필수 메타데이터 강제 생성"""
        
        required_keys = {
            'agent_class_name': 'GeneratedAgent',
            'agent_name': 'Generated Agent', 
            'agent_description': 'Auto-generated agent',
            'agent_type': 'CUSTOM',
            'custom_config': '{"timeout": 60, "retry_attempts": 3}'
        }
        
        for key, default_value in required_keys.items():
            if key not in business_logic or not business_logic[key]:
                business_logic[key] = default_value
                logger.info(f"🔧 Added missing metadata: {key} = {default_value}")
    
    def _fix_fstring_syntax_errors(self, code: str) -> str:
        """Fix f-string syntax errors that cause compilation issues"""
        import re
        
        logger.info("🔧 Applying f-string syntax fixes...")
        
        # 먼저 이중 중괄호를 단일 중괄호로 변환 (f-string 내부에서)
        # f"...{{something}}..." -> f"...{something}..."
        fixed_code = re.sub(r'(f"[^"]*?){{([^}]+)}}([^"]*?")', r'\1{\2}\3', code)
        
        # f-string 외부의 이중 중괄호도 처리 (logger 등)
        fixed_code = re.sub(r'(logger\.\w+\(f"[^"]*?){{{{([^}]+)}}}}([^"]*?"\))', r'\1{\2}\3', fixed_code)
        
        # Pattern 1: Fix {# TODO: Replace {var}} patterns
        pattern1 = r'\{# TODO: Replace \{([^}]+)\}\}'
        fixed_code = re.sub(pattern1, r'{\1}', fixed_code)
        
        # Pattern 2: Fix logger.debug(f"...{# TODO...}")
        pattern2 = r'(logger\.\w+\(f"[^"]*)\{# TODO[^}]*\{([^}]+)\}[^}]*\}([^"]*"\))'
        fixed_code = re.sub(pattern2, r'\1{\2}\3', fixed_code)
        
        # Pattern 3: More aggressive f-string cleaning
        pattern3 = r'f"([^"]*)\{# [^}]*\{([^}]+)\}[^}]*\}([^"]*)"'
        fixed_code = re.sub(pattern3, r'f"\1{\2}\3"', fixed_code)
        
        # Pattern 4: Remove any # comments inside f-string braces (더 정밀하게)
        # f-string 내부에서만 적용하도록 제한
        fstring_pattern = r'(f"[^"]*?)(\{[^#}]*)(#[^}]*)(\}[^"]*?")'
        fixed_code = re.sub(fstring_pattern, r'\1\2\4', fixed_code)
        
        if fixed_code != code:
            logger.info("✅ Fixed f-string syntax errors")
            
        return fixed_code

    # ============================================================================
    # 🛡️ NEW SAFETY-FIRST BUSINESS LOGIC GENERATION SYSTEM
    # ============================================================================

    async def _generate_business_logic_with_safety_net(self, template_id: str, user_request: str, llm_client: Any) -> Dict[str, Any]:
        """
        다단계 안전장치를 포함한 비즈니스 로직 생성
        Phase 1: Enhanced Prompt -> Phase 2: Legacy + Enhancement -> Phase 3: Smart Emergency
        """
        import uuid
        
        generation_id = str(uuid.uuid4())[:8]
        logger.info(f"[{generation_id}] 🛡️ Starting safety-first business logic generation")
        logger.info(f"[{generation_id}] Template: {template_id}, Query: {user_request[:100]}...")
        
        # Phase 1: Enhanced Prompt (목표 70% 성공률)
        try:
            logger.info(f"[{generation_id}] 🚀 Phase 1: Enhanced JSON prompt attempt")
            result = await self._try_enhanced_json_prompt(template_id, user_request, llm_client)
            
            if self._validate_complete_metadata(result):
                logger.info(f"[{generation_id}] ✅ Phase 1 SUCCESS - Complete metadata validated")
                result['generation_method'] = 'enhanced_prompt'
                return result
            else:
                logger.warning(f"[{generation_id}] ⚠️ Phase 1 partial success, trying enhancement")
                enhanced = self._enhance_partial_metadata(result, user_request, template_id)
                if self._validate_basic_requirements(enhanced):
                    enhanced['generation_method'] = 'enhanced_prompt_boosted'
                    logger.info(f"[{generation_id}] ✅ Phase 1 SUCCESS after enhancement")
                    return enhanced
                    
        except Exception as e:
            logger.warning(f"[{generation_id}] ❌ Phase 1 failed: {e}")
        
        # Phase 2: Legacy + Enhancement (목표 85% 성공률)
        try:
            logger.info(f"[{generation_id}] 🔄 Phase 2: Legacy + metadata boost attempt")
            result = await self._try_legacy_with_metadata_boost(template_id, user_request, llm_client)
            
            if self._validate_basic_requirements(result):
                result['generation_method'] = 'legacy_boosted'
                logger.info(f"[{generation_id}] ✅ Phase 2 SUCCESS")
                return result
                
        except Exception as e:
            logger.warning(f"[{generation_id}] ❌ Phase 2 failed: {e}")
        
        # Phase 3: Smart Emergency (목표 95% 성공률)
        logger.info(f"[{generation_id}] 🚨 Phase 3: Smart emergency generation")
        result = self._generate_smart_emergency_logic(user_request, template_id)
        result['generation_method'] = 'smart_emergency'
        logger.info(f"[{generation_id}] ✅ Phase 3 COMPLETE (emergency)")
        
        return result

    async def _try_enhanced_json_prompt(self, template_id: str, user_request: str, llm_client: Any) -> Dict[str, Any]:
        """개선된 JSON 프롬프트 (실패 가능성 인정하되 최선 시도)"""
        
        # 쿼리 기반 기본 정보 추론
        inferred_info = self._infer_basic_info_from_query(user_request)
        
        prompt = f"""사용자 요청: {user_request}
템플릿: {template_id}

다음 JSON 형식으로 응답을 생성하세요 (정확한 형식 필수):

{{
    "core_business_logic": "async def _process_core_logic(self, data: Dict) -> Dict:\\n    # 여기에 실제 비즈니스 로직 구현\\n    # 사용자 요청에 맞는 구체적인 처리 로직\\n    try:\\n        result = {{'status': 'processed', 'data': data}}\\n        return result\\n    except Exception as e:\\n        logger.error(f'Processing failed: {{e}}')\\n        return {{'status': 'error', 'error': str(e)}}",
    "agent_class_name": "{inferred_info['class_name']}",
    "agent_name": "{inferred_info['display_name']}",
    "agent_description": "{inferred_info['description']}",
    "agent_type": "CUSTOM",
    "custom_config": "{{\\"timeout\\": 60, \\"retry_attempts\\": 3}}",
    "initialization": "# 초기화 코드",
    "imports": ["from typing import Dict, Any", "import logging"]
}}

⚠️ 중요 요구사항: 
1. 반드시 유효한 JSON 형식으로 응답
2. core_business_logic는 완전한 Python 메서드 (self 파라미터 포함)
3. 모든 키가 포함되어야 함
4. JSON 외 다른 설명이나 텍스트 금지
5. 실제 비즈니스 로직을 구현하세요

JSON:"""

        try:
            response = await llm_client.invoke(prompt)
            parsed = self._parse_json_response_safely(response)
            
            # 기본 검증
            if not parsed.get('core_business_logic'):
                raise ValueError("core_business_logic missing in response")
            
            return parsed
            
        except Exception as e:
            logger.error(f"Enhanced prompt failed: {e}")
            raise

    async def _try_legacy_with_metadata_boost(self, template_id: str, user_request: str, llm_client: Any) -> Dict[str, Any]:
        """기존 방식 + 메타데이터 보강"""
        
        logger.info("🔄 Trying legacy approach with metadata boost")
        
        # 기존 방식으로 코드 생성
        legacy_prompts = self._get_template_specific_prompts(template_id, user_request)
        
        result = {}
        for section, prompt in legacy_prompts.items():
            try:
                response = await llm_client.invoke(prompt)
                parsed = self._parse_json_code_response(response)
                result.update(parsed)
            except Exception as e:
                logger.warning(f"Legacy section {section} failed: {e}")
        
        # 메타데이터 보강
        self._boost_metadata_from_context(result, user_request, template_id)
        
        return result

    def _generate_smart_emergency_logic(self, user_request: str, template_id: str) -> Dict[str, Any]:
        """스마트한 Emergency 로직 (100% 성공 보장)"""
        
        # 쿼리 분석으로 의미있는 정보 추출
        inferred_info = self._infer_detailed_info_from_query(user_request)
        
        # 도메인별 특화 로직
        domain_logic = self._get_domain_specific_logic(inferred_info['domain'])
        
        return {
            'core_business_logic': f'''async def _process_core_logic(self, extracted_info: Dict) -> Dict[str, Any]:
    """
    {inferred_info['description']}
    Generated for: {user_request[:100]}...
    """
    try:
        # Domain: {inferred_info['domain']}
        logger.info(f"Processing {inferred_info['domain']} request")
        
        {domain_logic}
        
        # 기본 응답 구조
        result = {{
            "status": "processed",
            "query": extracted_info.get("original_query", ""),
            "data": extracted_info,
            "domain": "{inferred_info['domain']}",
            "timestamp": datetime.now().isoformat(),
            "processing_notes": ["Emergency logic used", "Safe processing applied"]
        }}
        
        return result
        
    except Exception as e:
        logger.error(f"Emergency processing failed: {{e}}")
        return {{
            "status": "error", 
            "error": str(e),
            "fallback_data": extracted_info
        }}''',
            'agent_class_name': inferred_info['class_name'],
            'agent_name': inferred_info['display_name'],
            'agent_description': inferred_info['description'],
            'agent_type': 'CUSTOM',
            'custom_config': json.dumps({
                "timeout": 60, 
                "retry_attempts": 3, 
                "emergency_mode": True,
                "domain": inferred_info['domain']
            }),
            'initialization': f'# Emergency initialization for {inferred_info["domain"]} domain',
            'imports': ['from datetime import datetime', 'import json', 'import logging']
        }

    def _infer_basic_info_from_query(self, query: str) -> Dict[str, str]:
        """쿼리에서 기본 정보 추론 (간단한 버전)"""
        
        query_lower = query.lower()
        
        # 간단한 키워드 기반 추론
        if 'csv' in query_lower or 'excel' in query_lower or '분석' in query_lower:
            base_name = 'DataAnalyzer'
            description = 'Data analysis and processing agent'
        elif '주식' in query_lower or '금융' in query_lower or 'finance' in query_lower:
            base_name = 'FinanceAgent'
            description = 'Financial data processing agent'  
        elif '모니터링' in query_lower or 'monitor' in query_lower:
            base_name = 'MonitoringAgent'
            description = 'Monitoring and alerting agent'
        else:
            # 쿼리에서 첫 단어 추출 시도
            words = query.replace('에이전트', '').replace('만들어', '').strip().split()[:2]
            if words:
                base_name = ''.join(word.capitalize() for word in words if word.isalpha())
                if not base_name:
                    base_name = 'CustomAgent'
            else:
                base_name = 'CustomAgent'
            description = f'Custom agent for: {query[:100]}...'
        
        return {
            'class_name': base_name,
            'display_name': base_name.replace('Agent', ' Agent'),
            'description': description
        }

    def _infer_detailed_info_from_query(self, query: str) -> Dict[str, str]:
        """쿼리에서 상세 정보 추론 (키워드 기반, 신뢰성 높음)"""
        
        query_lower = query.lower()
        
        # 도메인 감지
        domain_keywords = {
            'finance': ['주식', '금융', '투자', '환율', 'price', 'stock', 'finance', '가격'],
            'data_analysis': ['분석', '데이터', 'csv', 'excel', 'analysis', 'data'],
            'monitoring': ['모니터링', '감시', '체크', 'monitor', 'check', 'alert'],
            'communication': ['이메일', '메시지', '알림', 'email', 'message', 'notification'],
            'file_processing': ['파일', '처리', '변환', 'file', 'process', 'convert'],
            'web': ['웹', '크롤링', '스크래핑', 'web', 'crawl', 'scrape'],
            'general': []  # 기본값
        }
        
        detected_domain = 'general'
        for domain, keywords in domain_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                detected_domain = domain
                break
        
        # 에이전트 이름 생성
        if detected_domain == 'general':
            # 쿼리에서 핵심 단어 추출
            words = query.replace('에이전트', '').replace('만들어', '').strip().split()[:2]
            base_name = ''.join(word.capitalize() for word in words if word.isalpha()) or 'Custom'
        else:
            base_name = detected_domain.replace('_', ' ').title().replace(' ', '')
        
        class_name = f"{base_name}Agent"
        display_name = f"{base_name} Agent"
        description = f"AI agent for {detected_domain.replace('_', ' ')} tasks: {query[:100]}..."
        
        return {
            'domain': detected_domain,
            'class_name': class_name,
            'display_name': display_name,
            'description': description
        }

    def _get_domain_specific_logic(self, domain: str) -> str:
        """도메인별 특화 로직"""
        
        domain_logics = {
            'finance': '''# 금융 데이터 처리
        if 'price' in extracted_info or 'amount' in extracted_info:
            numeric_data = {k: v for k, v in extracted_info.items() 
                          if isinstance(v, (int, float))}
            result.update({"financial_data": numeric_data})''',
            'data_analysis': '''# 데이터 분석 처리
        if isinstance(extracted_info.get('data'), list):
            result.update({
                "row_count": len(extracted_info['data']),
                "analysis_type": "batch_processing"
            })''',
            'monitoring': '''# 모니터링 처리
        result.update({
            "monitoring_status": "active",
            "check_timestamp": datetime.now().isoformat()
        })'''
        }
        
        return domain_logics.get(domain, '''# 범용 처리
        result.update({"processing_method": "general"})''')

    def _validate_complete_metadata(self, data: Dict) -> bool:
        """완전한 메타데이터 검증"""
        required_keys = [
            'core_business_logic', 'agent_class_name', 'agent_name', 
            'agent_description', 'custom_config'
        ]
        
        for key in required_keys:
            if not data.get(key) or (isinstance(data[key], str) and not data[key].strip()):
                return False
        
        # 코드 기본 검증
        if 'def _process_core_logic' not in data.get('core_business_logic', ''):
            return False
        
        return True

    def _validate_basic_requirements(self, data: Dict) -> bool:
        """기본 요구사항 검증 (더 관대함)"""
        return bool(
            data.get('core_business_logic') and 
            data.get('agent_class_name') and
            '{' not in str(data.get('agent_class_name', ''))  # 템플릿 변수 없음
        )

    def _enhance_partial_metadata(self, data: Dict, user_request: str, template_id: str) -> Dict[str, Any]:
        """부분적 메타데이터를 보강"""
        
        if not data.get('agent_class_name'):
            inferred = self._infer_basic_info_from_query(user_request)
            data['agent_class_name'] = inferred['class_name']
            data['agent_name'] = inferred['display_name']
            data['agent_description'] = inferred['description']
        
        if not data.get('custom_config'):
            data['custom_config'] = '{"timeout": 60, "retry_attempts": 3}'
        
        if not data.get('initialization'):
            data['initialization'] = '# Initialization code'
        
        return data

    def _boost_metadata_from_context(self, data: Dict, user_request: str, template_id: str) -> None:
        """컨텍스트에서 메타데이터 보강"""
        
        # 기존 메타데이터 보강 로직 호출
        self._ensure_required_metadata(data)
        
        # 추가적인 컨텍스트 기반 개선
        if not data.get('agent_description') or data['agent_description'] == 'Auto-generated agent for processing requests':
            inferred = self._infer_basic_info_from_query(user_request)
            data['agent_description'] = inferred['description']

    def _parse_json_response_safely(self, response: str) -> Dict[str, Any]:
        """안전한 JSON 파싱"""
        
        try:
            # 기존 JSON 파싱 로직 활용
            return self._parse_json_code_response(response)
        except Exception as e:
            logger.error(f"JSON parsing failed: {e}")
            raise

    def _should_use_pattern_integration(self, template_id: str, user_request: str) -> bool:
        """패턴 통합 시스템 사용 여부 결정"""
        
        import os
        
        # 환경 변수로 제어 가능
        if os.getenv('FORGE_ENABLE_PATTERNS', 'true').lower() == 'false':
            return False
        
        # 특정 템플릿들에 대해 패턴 시스템 우선 사용
        pattern_friendly_templates = [
            'data_analysis', 'comprehensive', 'advanced', 
            'business_intelligence', 'analytics'
        ]
        
        if template_id in pattern_friendly_templates:
            return True
        
        # 키워드 기반 결정
        pattern_keywords = [
            'csv', 'excel', '데이터', '분석', 'analysis', '차트', 
            '대시보드', 'dashboard', '고객', 'customer', '위험', 'risk'
        ]
        
        user_lower = user_request.lower()
        matched = sum(1 for kw in pattern_keywords if kw in user_lower)
        
        return matched >= 2  # 2개 이상 키워드 매칭시 패턴 시스템 사용

    def _should_use_new_system(self, template_id: str) -> bool:
        """새 시스템 사용 여부 결정 (Feature Flag)"""
        
        # 안전한 템플릿들부터 점진적 적용
        safe_templates = [
            'logosai_agent_template', 
            'comprehensive_agent',
            'csv_excel_analyzer'
        ]
        
        # 환경변수로 제어도 가능
        import os
        if os.getenv('FORGE_USE_NEW_SAFETY_SYSTEM', 'false').lower() == 'true':
            return True
        
        return template_id in safe_templates