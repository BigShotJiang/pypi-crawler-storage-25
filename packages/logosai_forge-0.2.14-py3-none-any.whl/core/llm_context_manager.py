"""
LLM Context Manager — Token-aware prompt compression.

Replaces hardcoded code[:2000], code[:3000] with priority-based context fitting.
Priority 1 = always include (truncate if needed), 2 = if space, 3 = optional.
"""

from typing import Dict, Any, List


def estimate_tokens(text: str) -> int:
    """Estimate token count (words × 1.3 heuristic)."""
    if not text:
        return 0
    return int(len(text.split()) * 1.3)


def fit_to_context(sections: List[Dict], max_tokens: int) -> Dict[str, Any]:
    """Fit sections into max_tokens by priority.

    Args:
        sections: [{"content": str, "priority": int (1=must, 2=want, 3=optional), "label": str}]
        max_tokens: Maximum token budget

    Returns:
        {"sections": [...], "total_tokens": int, "text": str, "sections_included": int}
    """
    sorted_sections = sorted(sections, key=lambda s: s.get("priority", 99))
    result = []
    used_tokens = 0

    for sec in sorted_sections:
        content = sec.get("content", "")
        tokens = estimate_tokens(content)

        if used_tokens + tokens <= max_tokens:
            result.append(sec)
            used_tokens += tokens
        elif sec.get("priority", 99) == 1:
            # Priority 1: always include (truncate if needed)
            available = max(max_tokens - used_tokens, 20)
            words = content.split()
            max_words = max(int(available / 1.3), 5)
            truncated = " ".join(words[:max_words])
            result.append({**sec, "content": truncated, "truncated": True})
            used_tokens += estimate_tokens(truncated)

    return {
        "sections": result,
        "total_tokens": used_tokens,
        "max_tokens": max_tokens,
        "sections_included": len(result),
        "sections_total": len(sections),
        "text": "\n\n".join(f"[{s.get('label', '')}]\n{s['content']}" for s in result),
    }
