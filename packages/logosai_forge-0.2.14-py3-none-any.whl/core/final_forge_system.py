# 🔥 FORCE DEBUG - MODULE RELOAD VERIFICATION
print("🚨 FORCE DEBUG: final_forge_system.py LOADED AT MODULE LEVEL!")
import sys
print(f"🚨 FORCE DEBUG: Python sys.path[0] = {sys.path[0] if sys.path else 'EMPTY'}")
print(f"🚨 FORCE DEBUG: Current file = {__file__ if '__file__' in globals() else 'NO FILE'}")

# 🚨 NUCLEAR VERIFICATION - THIS SHOULD APPEAR IN LOGS
print("🚨🚨🚨 NUCLEAR: FINAL_FORGE_SYSTEM LOADED WITH NUCLEAR RESTART! 🚨🚨🚨")
print("🔬 NUCLEAR: No more selection_result errors should occur!")
import datetime
print(f"🕐 NUCLEAR: Loaded at {datetime.datetime.now()}")





"""
FORGE AI - 최종 통합 시스템
===========================
효율적이고 에러 없는 에이전트 자동 생성 시스템

핵심 개선사항:
1. 단일 생성기로 통합
2. 템플릿 없이 직접 코드 생성
3. 독립형 실행 가능 코드
4. 완벽한 에러 처리
5. 실시간 검증
"""

import asyncio
import json
import uuid
import re
import os
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Error Collector 임포트
try:
    from .error_collector import error_collector, ForgeError, TemplateError, ValidationError
except ImportError:
    # Fallback if error_collector is not available
    error_collector = None

# 새로운 모듈들 임포트
try:
    from .ast_code_generator import ForgeASTGenerator
    from .self_healing_module import SelfHealingModule
    from .domain_modules import get_domain_module
    logger.info("✅ 새로운 AST 생성기, 자가 수정, 도메인 모듈 로드 성공")
except ImportError as e:
    logger.warning(f"⚠️ 새 모듈 로드 실패: {e}")
    ForgeASTGenerator = None
    SelfHealingModule = None
    get_domain_module = None
    ForgeError = Exception
    TemplateError = Exception
    ValidationError = Exception

# 패턴 시스템 통합 모듈 임포트
try:
    from .pattern_template_integrator import PatternTemplateIntegrator
    logger.info("✅ PatternTemplateIntegrator 로드 성공")
except ImportError as e:
    logger.warning(f"⚠️ PatternTemplateIntegrator 로드 실패: {e}")
    PatternTemplateIntegrator = None

# Template Matcher Service 임포트
TemplateMatcherService = None
try:
    # Try absolute import first
    from forge.core.template_matcher import TemplateMatcherService
    logger.info("✅ TemplateMatcherService 로드 성공 (absolute import)")
except ImportError:
    try:
        # Fallback to relative import
        from .template_matcher import TemplateMatcherService
        logger.info("✅ TemplateMatcherService 로드 성공 (relative import)")
    except ImportError:
        try:
            # Try direct import for test environments
            from template_matcher import TemplateMatcherService
            logger.info("✅ TemplateMatcherService 로드 성공 (direct import)")
        except ImportError as e:
            logger.warning(f"TemplateMatcherService not available - using default template: {e}")
            TemplateMatcherService = None


@dataclass
class ForgeRequest:
    """FORGE 요청 구조"""
    query: str
    user_email: str = "default@forge.ai"
    session_id: Optional[str] = None
    output_type: str = "standalone"  # standalone, logosai
    enable_testing: bool = True
    save_to_file: bool = True
    stream_callback: Optional[callable] = None  # 🎨 스트리밍 콜백
    business_rules: Optional[list] = None  # 🎯 명시적 비즈니스 규칙 (예: ["base_probability = 0.10", "probability += months_inactive * 0.15"])
    input_schema: Optional[Dict[str, str]] = None  # 🎯 입력 필드 스키마 (예: {"months_inactive": "int", "usage_decline_pct": "float"})


@dataclass
class ForgeResult:
    """FORGE 결과 구조"""
    success: bool
    agent_code: str
    metadata: Dict[str, Any]
    agent_name: Optional[str] = None  # 에이전트 이름 필드 추가
    test_results: Optional[Dict[str, Any]] = None
    file_path: Optional[str] = None
    error: Optional[str] = None


class FinalForgeSystem:
    """최종 FORGE AI 시스템"""
    
    def __init__(self):
        """초기화"""
        self.output_dir = Path("forge/agents/generated")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Template Matcher Service 초기화
        if TemplateMatcherService:
            try:
                self.template_matcher = TemplateMatcherService()
                logger.info("✅ TemplateMatcherService 초기화 완료")
            except Exception as e:
                logger.warning(f"TemplateMatcherService 초기화 실패: {e}")
                self.template_matcher = None
        else:
            self.template_matcher = None
        
        # Pattern Template Integrator 초기화
        if PatternTemplateIntegrator:
            try:
                self.pattern_integrator = PatternTemplateIntegrator()
                logger.info("✅ PatternTemplateIntegrator 초기화 완료")
            except Exception as e:
                logger.warning(f"PatternTemplateIntegrator 초기화 실패: {e}")
                self.pattern_integrator = None
        else:
            self.pattern_integrator = None
            
        # 🔧 NEW: 템플릿 생성기 초기화 (템플릿 변수 치환용)
        try:
            from .template_based_generator import TemplateBasedGenerator
            self.template_generator = TemplateBasedGenerator()
            logger.info("✅ TemplateBasedGenerator 초기화 완료 - 템플릿 변수 치환 지원")
        except Exception as e:
            logger.warning(f"TemplateBasedGenerator 초기화 실패: {e}")
            self.template_generator = None
        
        # 에이전트 타입 매핑
        self.agent_types = {
            "calculator": ("계산기", ["계산기", "계산", "더하기", "빼기", "곱하기", "나누기", "calculator", "calc"]),
            "weather": ("날씨", ["날씨", "기온", "온도", "weather", "비", "눈", "맑음", "흐림", "일기예보"]),
            "data_analysis": ("데이터 분석", ["데이터", "분석", "csv", "excel", "통계", "차트"]),
            "api_integration": ("API 통합", ["api", "rest", "endpoint", "서비스", "요청"]),
            "web_scraping": ("웹 스크래핑", ["웹", "크롤링", "스크래핑", "수집", "파싱"]),
            "automation": ("자동화", ["자동", "스케줄", "반복", "작업", "프로세스"]),
            "document_processing": ("문서 처리", ["문서", "텍스트", "파일", "pdf", "워드"]),
            "chatbot": ("챗봇", ["챗봇", "대화", "응답", "질문", "답변"]),
            "monitoring": ("모니터링", ["모니터링", "감시", "알림", "상태", "체크"]),
            "news_aggregator": ("뉴스 수집", ["뉴스", "news", "기사", "언론", "RSS"]),
            "sentiment_analyzer": ("감정 분석", ["감정", "sentiment", "긍정", "부정", "분석"]),
            "time_series": ("시계열 예측", ["시계열", "예측", "forecast", "트렌드"])
        }
        
        logger.info("🚀 FinalForgeSystem 초기화 완료")
    
    async def _create_business_logic_for_domain(self, analysis: Dict, domain_module, request_query: str) -> str:
        """도메인별 비즈니스 로직 생성 - 패턴 시스템 우선 사용"""
        
        # 1. Pattern System 사용 (최우선)
        if self.pattern_integrator:
            try:
                logger.info("🎯 패턴 시스템을 사용한 비즈니스 로직 생성 시도...")
                
                # 간단한 LLM 클라이언트 mock (실제로는 LLM 클라이언트 필요)
                class SimpleLLMClient:
                    async def generate(self, prompt):
                        # 간단한 응답 생성
                        return {"business_logic": "Pattern-based logic"}
                
                llm_client = SimpleLLMClient()
                template_id = analysis.get('agent_type', 'general')
                
                # PatternTemplateIntegrator 사용
                pattern_result = await self.pattern_integrator.enhanced_generate_business_logic(
                    template_id=template_id,
                    user_request=request_query,
                    llm_client=llm_client
                )
                
                # 패턴 시스템이 생성한 비즈니스 로직 추출
                if isinstance(pattern_result, dict):
                    if 'business_logic' in pattern_result:
                        logger.info("✅ 패턴 시스템으로부터 비즈니스 로직 생성 성공")
                        return pattern_result['business_logic']
                    elif 'code' in pattern_result:
                        logger.info("✅ 패턴 시스템으로부터 코드 생성 성공")
                        return pattern_result['code']
                
            except Exception as e:
                logger.warning(f"⚠️ 패턴 시스템 사용 실패: {e}")
        
        # 2. 도메인 모듈 사용 (두 번째 우선순위)
        if domain_module and hasattr(domain_module, 'generate_business_logic'):
            logger.info(f"🎯 도메인 모듈 사용: {domain_module.domain}")
            return domain_module.generate_business_logic()
        
        # 3. 기본 로직 (최후의 수단)
        logger.warning("⚠️ 패턴 시스템과 도메인 모듈 모두 사용 불가 - 기본 로직 사용")
        agent_type = analysis.get('agent_type', 'general')
        description = analysis.get('description', '')
        
        # 간단한 비즈니스 로직 템플릿
        logic = f'''
# {agent_type} 비즈니스 로직
logger.info("Processing {agent_type} request")

# 입력 처리
input_data = extracted_info if isinstance(extracted_info, dict) else {{'input': str(extracted_info)}}

# 핵심 처리 로직
result = {{
    "status": "success",
    "type": "{agent_type}",
    "description": "{description}",
    "data": input_data,
    "timestamp": datetime.now().isoformat()
}}

logger.info(f"Completed {{result['type']}} processing")
return result
'''
        return logic
    
    async def create_agent(self, request) -> ForgeResult:
        """에이전트 생성 메인 함수"""
        try:
            # Handle both string, dict, and ForgeRequest types
            if isinstance(request, str):
                # Create ForgeRequest from string
                from dataclasses import dataclass
                @dataclass
                class ForgeRequest:
                    query: str
                    user_email: str = "default@forge.ai"
                    session_id: Optional[str] = None
                    output_type: str = "logosai"  # Change default to logosai
                    enable_testing: bool = True
                    save_to_file: bool = True
                request = ForgeRequest(query=request)
            elif isinstance(request, dict):
                # Handle dict input from server
                from dataclasses import dataclass
                @dataclass
                class ForgeRequest:
                    query: str
                    user_email: str = "default@forge.ai"
                    session_id: Optional[str] = None
                    output_type: str = "logosai"  # Change default to logosai
                    enable_testing: bool = True
                    save_to_file: bool = True
                
                # Extract or build query
                if 'query' not in request:
                    agent_name = request.get('name', 'CustomAgent')
                    agent_type = request.get('type', 'general')
                    description = request.get('description', '')
                    query = f"Create a {agent_name} agent of type {agent_type}"
                    if description:
                        query += f" that {description}"
                else:
                    query = request.get('query')
                
                # Create ForgeRequest with proper fields
                request = ForgeRequest(
                    query=query,
                    user_email=request.get('user_email', 'default@forge.ai'),
                    session_id=request.get('session_id'),
                    output_type=request.get('output_type', 'logosai'),
                    enable_testing=request.get('enable_testing', True),
                    save_to_file=request.get('save_to_file', True)
                )
                
            logger.info(f"📋 에이전트 생성 시작: {request.query}")
            
            # 1. 요청 분석
            analysis = self._analyze_request(request.query)
            logger.info(f"✅ 요청 분석 완료: {analysis['agent_type']}")
            
            # 2. 코드 생성 - 템플릿 우선, 패턴 차선 정책 적용
            agent_code = None
            
            # 🚨 TEMPLATE FIRST POLICY: 템플릿 시스템 우선 사용
            logger.info("🎯 Starting template-first policy check...")
            logger.info(f"🎯 Query: {request.query[:100]}...")
            
            business_logic = None
            
            # 🔥 PRIORITY 1: Try template system first
            if self.template_matcher:
                logger.info("📚 Checking template system for business logic...")
                try:
                    # Try to get template-based business logic
                    temp_business_logic = self._get_logosai_core_business_logic(analysis)
                    if temp_business_logic and len(temp_business_logic) > 100:
                        business_logic = temp_business_logic
                        logger.info(f"✅ Template-based business logic generated: {len(business_logic)} characters")
                except Exception as e:
                    logger.warning(f"⚠️ Template system failed: {e}")
            
            # 🔥 PRIORITY 2: If no template logic, try pattern system
            if not business_logic:
                should_use_patterns = self._should_use_pattern_system_for_business_logic(request.query, analysis.get('agent_type', 'general'))
                logger.info(f"📊 Pattern decision result: {should_use_patterns}")
                
                if should_use_patterns:
                    logger.info("✅ Pattern matched → Using pattern system for business logic generation")
                    # Use pattern system to generate business logic
                    business_logic = self._generate_business_logic_with_patterns(analysis, request.query)
                    logger.info(f"✅ Pattern-based business logic generated: {len(business_logic) if business_logic else 0} characters")
            
            # ALWAYS use AST generator for final code generation
            if ForgeASTGenerator and SelfHealingModule and get_domain_module:
                try:
                    logger.info("🔄 AST 생성기 사용 시작...")
                    
                    # 도메인 모듈 가져오기
                    domain = analysis.get('agent_type', 'general')
                    domain_module = get_domain_module(domain)
                    
                    # 비즈니스 로직 생성 (template/pattern system을 사용하지 않은 경우에만)
                    if not business_logic:
                        logger.info("📝 도메인 모듈로 비즈니스 로직 생성...")
                        business_logic = await self._create_business_logic_for_domain(analysis, domain_module, request.query)
                    
                    # AST 생성기와 자가 수정 모듈 초기화
                    ast_generator = ForgeASTGenerator()
                    self_healing = SelfHealingModule(max_attempts=5)
                    
                    # 자가 수정과 함께 AST 생성
                    ast_tree = self_healing.generate_with_self_healing(
                        generator=ast_generator,
                        agent_name=analysis.get('agent_name', 'CustomAgent'),
                        agent_class_name=analysis.get('agent_name', 'CustomAgent').replace(' ', ''),
                        description=analysis.get('description', request.query),
                        agent_type=analysis.get('agent_type', 'GENERAL'),
                        business_logic_text=business_logic,
                        domain_module=domain_module
                    )
                    
                    # AST를 코드로 변환
                    import ast
                    agent_code = ast.unparse(ast_tree)
                    logger.info(f"✅ AST 생성기로 코드 생성 완료: {len(agent_code)} 문자")
                    
                except Exception as e:
                    logger.warning(f"⚠️ AST 생성 실패, 기존 방식으로 전환: {e}")
                    agent_code = None
            
            # 기존 방식으로 fallback
            if not agent_code:
                # 비즈니스 로직이 있으면 analysis에 추가
                if business_logic:
                    analysis['business_logic'] = business_logic
                    logger.info(f"💾 Business logic added to analysis: {len(business_logic)} chars")
                
                if request.output_type == "standalone":
                    agent_code = self._generate_standalone_code(analysis)
                else:
                    agent_code = self._generate_logosai_code(analysis)
                logger.info(f"✅ 기존 방식으로 코드 생성 완료: {len(agent_code)} 문자")
            
            # 중복 import 제거
            if agent_code:
                agent_code = self._deduplicate_imports(agent_code)
                logger.info("✅ 중복 import 제거 완료")

            # 생성된 코드를 저장 (self-healing을 위해)
            self._last_generated_code = agent_code

            # 3. 메타데이터 생성
            metadata = self._generate_metadata(analysis, request)

            # 4. 코드 검증 + Self-Healing
            validation_result = self._validate_code(agent_code)
            if not validation_result["valid"]:
                # Self-healing 시도
                logger.info("🔧 코드 검증 실패 - Self-healing 시도...")
                if SelfHealingModule:
                    healer = SelfHealingModule(max_attempts=5)
                    healed_code = agent_code

                    for attempt in range(5):
                        try:
                            compile(healed_code, '<string>', 'exec')
                            agent_code = healed_code
                            logger.info(f"✅ Self-healing 성공 (시도: {attempt + 1})")
                            validation_result = {"valid": True, "errors": []}
                            break
                        except SyntaxError as e:
                            # 에러 타입에 따른 수정 시도
                            error_msg = str(e).lower()
                            if 'except' in error_msg or 'finally' in error_msg:
                                healed_code = healer.fix_try_without_except(healed_code, e)
                            elif 'indent' in error_msg:
                                healed_code = healer.fix_indentation(healed_code, e)
                                healed_code = healer.fix_truncated_blocks(healed_code, e)
                            elif any(x in error_msg for x in ['(', ')', 'never closed']):
                                healed_code = healer.fix_truncated_expression(healed_code, e)
                            elif any(x in error_msg for x in ['string', 'unterminated']):
                                healed_code = healer.fix_unterminated_string(healed_code, e)
                            else:
                                healed_code = healer.fix_syntax(healed_code, e)
                            logger.info(f"🔧 Self-healing 시도 {attempt + 1}: {error_msg[:50]}")

                if not validation_result["valid"]:
                    # 디버깅을 위해 에러 코드 저장
                    self._last_generated_code = agent_code
                    raise ValueError(f"코드 검증 실패: {validation_result['errors']}")
            logger.info("✅ 코드 검증 통과")
            
            # 5. 파일 저장 (옵션)
            file_path = None
            if request.save_to_file:
                file_path = self._save_agent(agent_code, metadata)
                logger.info(f"✅ 파일 저장 완료: {file_path}")
            
            # 6. 테스트 실행 (옵션)
            test_results = None
            if request.enable_testing:
                test_results = await self._test_agent(agent_code, analysis)
                logger.info(f"✅ 테스트 완료: {test_results['status']}")
            
            return ForgeResult(
                success=True,
                agent_code=agent_code,
                metadata=metadata,
                agent_name=metadata.get('agent_name', 'CustomAgent'),  # agent_name 전달
                test_results=test_results,
                file_path=file_path
            )
            
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"❌ 에이전트 생성 실패: {e}")
            logger.error(f"📍 에러 상세:\n{error_trace}")
            
            # 에러 수집
            if error_collector:
                error_context = {
                    "request": {
                        "query": request.query,
                        "output_type": request.output_type
                    },
                    "analysis": analysis if 'analysis' in locals() else None,
                    "stage": "create_agent"
                }
                error_id = error_collector.collect(e, error_context)
                logger.info(f"📝 Error collected: {error_id}")
            
            # 에러 타입별 구체적 메시지
            error_message = str(e)
            if "API" in error_message or "api" in error_message:
                error_detail = f"AI API 호출 실패: {error_message}"
            elif "timeout" in error_message.lower():
                error_detail = f"처리 시간 초과: {error_message}"
            elif "validation" in error_message.lower():
                error_detail = f"코드 검증 실패: {error_message}"
            elif "syntax" in error_message.lower():
                error_detail = f"문법 오류: {error_message}"
            else:
                error_detail = f"생성 중 오류: {error_message}"
            
            return ForgeResult(
                success=False,
                agent_code="",
                metadata={
                    "error_type": type(e).__name__,
                    "error_detail": error_detail,
                    "error_trace": error_trace[:500]  # 처음 500자만
                },
                agent_name=None,  # 실패 시에도 agent_name 필드 포함
                error=str(e)
            )
    
    def _analyze_request(self, query: str) -> Dict[str, Any]:
        """✅ NEW: LLM 기반 스마트 요청 분석 (이름 생성 포함)"""
        try:
            # 🧠 IntelligentPatternSystem으로 통합 분석
            import sys
            from pathlib import Path
            
            patterns_root = Path(__file__).parent.parent / "business_patterns_implementation"
            if str(patterns_root) not in sys.path:
                sys.path.insert(0, str(patterns_root))
            
            from intelligent_pattern_system import IntelligentPatternSystem
            
            logger.info("🧠 Using Intelligent Pattern System for smart naming")
            
            # LLM 기반 분석 수행
            intelligent_system = IntelligentPatternSystem()
            action, pattern_data = intelligent_system.analyze_and_select_pattern(query, "general")
            
            # 분석 결과에서 정보 추출
            analysis_obj = pattern_data.get('analysis')
            if not analysis_obj:
                logger.warning("⚠️ No analysis object found, using fallback")
                return self._fallback_legacy_analysis(query)
            
            # 기존 features 추출 로직 유지 (호환성을 위해)
            features = self._extract_features_from_query(query)
            
            # 에이전트 타입을 쿼리에서 직접 추출
            detected_agent_type = self._detect_agent_type_from_query(query)
            
            # 클래스 이름 생성 (agent_name에서 파생)
            # PatternAnalysis의 기본값이 CustomAgent인 경우 직접 추출
            if analysis_obj.suggested_agent_name == "CustomAgent":
                agent_name = self._extract_meaningful_name_from_query(query, detected_agent_type)
                logger.info(f"✅ Extracted meaningful name: {agent_name} from query")
            else:
                agent_name = analysis_obj.suggested_agent_name
            
            agent_class_name = self._generate_class_name(agent_name)
            
            return {
                "agent_type": detected_agent_type,  # 쿼리에서 직접 추출한 타입 사용
                "agent_name": agent_name,  # ✅ LLM이 생성한 스마트 이름
                "agent_class_name": agent_class_name,  # ✅ 클래스 이름 추가
                "display_name": analysis_obj.suggested_display_name,
                "file_name_base": analysis_obj.suggested_file_name,
                "name_reasoning": analysis_obj.name_reasoning,
                "description": query,
                "original_query": query,
                "confidence": analysis_obj.similarity_score,
                "features": features,
                "complexity": analysis_obj.complexity_level,
                
                # 패턴 시스템 정보
                "pattern_action": action,
                "pattern_analysis": analysis_obj.to_dict() if hasattr(analysis_obj, 'to_dict') else str(analysis_obj)
            }
            
        except Exception as e:
            logger.error(f"❌ Smart analysis failed: {e}")
            # 에러 시 기존 방식 사용
            return self._fallback_legacy_analysis(query)
    
    def _fallback_legacy_analysis(self, query: str) -> Dict[str, Any]:
        """레거시 분석 방식 (기존 코드) + 스마트 이름 추출"""
        query_lower = query.lower()
        
        # 에이전트 타입 감지
        agent_type = "general"
        confidence = 0.0
        
        for type_key, (type_name, keywords) in self.agent_types.items():
            matches = sum(1 for keyword in keywords if keyword in query_lower)
            match_ratio = matches / len(keywords)
            
            if match_ratio > confidence:
                confidence = match_ratio
                agent_type = type_key
        
        # ✅ 향상된 이름 생성 - 쿼리에서 의미 있는 이름 추출
        agent_name = self._extract_meaningful_name_from_query(query, agent_type)
        logger.info(f"✅ Fallback analysis: query='{query[:50]}', type={agent_type}, name={agent_name}")
        
        agent_class_name = self._generate_class_name(agent_name)
        features = self._extract_features_from_query(query)
        
        return {
            "agent_type": agent_type,
            "agent_name": agent_name,
            "agent_class_name": agent_class_name,  # ✅ 클래스 이름 추가
            "display_name": agent_name.replace('Agent', ' 에이전트'),
            "file_name_base": agent_name.lower(),
            "name_reasoning": "Legacy rule-based naming",
            "description": query,
            "original_query": query,
            "confidence": confidence,
            "features": features,
            "complexity": self._assess_complexity(query, features)
        }
    
    def _detect_agent_type_from_query(self, query: str) -> str:
        """쿼리에서 에이전트 타입 감지"""
        query_lower = query.lower()
        
        # 에이전트 타입 감지
        agent_type = "general"
        confidence = 0.0
        
        for type_key, (type_name, keywords) in self.agent_types.items():
            matches = sum(1 for keyword in keywords if keyword in query_lower)
            match_ratio = matches / len(keywords) if keywords else 0
            
            if match_ratio > confidence:
                confidence = match_ratio
                agent_type = type_key
        
        logger.info(f"✅ Detected agent type: {agent_type} (confidence: {confidence:.2f})")
        return agent_type
    
    def _extract_features_from_query(self, query: str) -> List[str]:
        """쿼리에서 기능 추출 (기존 로직 분리)"""
        query_lower = query.lower()
        features = []
        
        if "실시간" in query_lower:
            features.append("realtime")
        if "데이터베이스" in query_lower or "db" in query_lower:
            features.append("database")
        if "시각화" in query_lower or "차트" in query_lower:
            features.append("visualization")
        if "머신러닝" in query_lower or "ml" in query_lower:
            features.append("machine_learning")
        
        return features
    
    def _assess_complexity(self, query: str, features: List[str]) -> str:
        """복잡도 평가"""
        complexity_score = len(features)
        
        if len(query) > 100:
            complexity_score += 1
        if any(word in query.lower() for word in ["복잡한", "고급", "전문", "통합"]):
            complexity_score += 2
        
        if complexity_score >= 4:
            return "high"
        elif complexity_score >= 2:
            return "medium"
        else:
            return "low"
    
    def _generate_class_name(self, agent_name: str) -> str:
        """에이전트 이름에서 클래스 이름 생성 (Python 식별자 규칙 준수)"""
        import re

        # Remove all non-alphanumeric characters except spaces, hyphens, underscores
        cleaned = re.sub(r'[^\w\s\-]', '', agent_name)

        # Split by spaces, hyphens, underscores and capitalize each word
        words = re.split(r'[\s\-_]+', cleaned)
        class_name = ''.join(word.capitalize() for word in words if word)

        # Remove any existing 'agent' suffix (case insensitive) before adding
        if class_name.lower().endswith('agent'):
            class_name = class_name[:-5]  # Remove 'agent' (5 chars)

        # Ensure it ends with 'Agent'
        class_name += 'Agent'

        # Ensure it starts with a letter (not a number)
        if class_name and not class_name[0].isalpha():
            class_name = 'Agent' + class_name

        # Remove any remaining invalid characters (extra safety)
        class_name = re.sub(r'[^\w]', '', class_name)

        # If empty or invalid, use default
        if not class_name or class_name == 'Agent':
            class_name = 'GeneratedAgent'

        return class_name
    
    def _extract_meaningful_name_from_query(self, query: str, agent_type: str) -> str:
        """쿼리에서 의미있는 에이전트 이름 추출"""
        import re
        
        # 한국어-영어 키워드 매핑
        korean_to_english = {
            "계산기": "Calculator",
            "계산": "Calculator", 
            "날씨": "Weather",
            "일기예보": "Weather",
            "데이터 분석": "DataAnalysis",
            "데이터분석": "DataAnalysis",
            "분석": "Analysis",
            "번역": "Translation",
            "번역기": "Translator",
            "요약": "Summary", 
            "요약기": "Summarizer",
            "검색": "Search",
            "모니터링": "Monitoring",
            "감시": "Monitor",
            "추천": "Recommendation",
            "예측": "Prediction",
            "분류": "Classification",
            "클러스터링": "Clustering",
            "시각화": "Visualization",
            "채팅": "Chat",
            "챗봇": "ChatBot",
            "음성": "Voice",
            "이미지": "Image",
            "텍스트": "Text",
            "파일": "File",
            "문서": "Document",
            "이메일": "Email",
            "고객": "Customer",
            "주문": "Order",
            "판매": "Sales",
            "재고": "Inventory",
            "금융": "Financial",
            "보안": "Security",
            "로그": "Log",
            "알림": "Notification"
        }
        
        # 영어 키워드도 직접 추출
        english_keywords = [
            "calculator", "weather", "data", "analysis", "translator", "translation", "summary",
            "search", "monitor", "recommendation", "prediction", "classification",
            "clustering", "visualization", "chat", "voice", "image", "text",
            "file", "document", "email", "customer", "order", "sales", 
            "inventory", "financial", "security", "log", "notification", "processor"
        ]
        
        query_lower = query.lower()
        
        # 1. 한국어 키워드 찾기
        for korean, english in korean_to_english.items():
            if korean in query:
                return f"{english}Agent"
        
        # 2. 영어 키워드 찾기
        for keyword in english_keywords:
            if keyword in query_lower:
                return f"{keyword.title()}Agent"
        
        # 3. 에이전트 타입 기반 이름 생성
        type_to_name = {
            "data_analysis": "DataAnalysisAgent",
            "web_search": "WebSearchAgent", 
            "weather_info": "WeatherInfoAgent",
            "calculator": "CalculatorAgent",
            "file_processor": "FileProcessorAgent",
            "monitoring": "MonitoringAgent"
        }
        
        if agent_type in type_to_name:
            return type_to_name[agent_type]
        
        # 4. 패턴 기반 추출 시도
        # "~을/를 ~는 에이전트" 패턴 
        pattern_match = re.search(r'(\w+).*?에이전트', query)
        if pattern_match:
            base_word = pattern_match.group(1)
            if base_word in korean_to_english:
                return f"{korean_to_english[base_word]}Agent"
        
        # 5. 마지막 디폴트
        return "CustomAgent"
    
    def _generate_standalone_code(self, analysis: Dict[str, Any]) -> str:
        """독립형 실행 가능한 코드 생성"""
        
        agent_name = analysis["agent_name"]
        description = analysis["description"]
        agent_type = analysis["agent_type"]
        features = analysis["features"]
        
        # 옵션 1과 2 적용: 설명 텍스트 안전하게 처리
        # 옵션 2: 줄바꿈 이스케이프 처리
        escaped_description = description.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
        
        # 옵션 1: 여러 줄 텍스트를 위한 삼중 따옴표 사용 여부 결정
        if '\n' in description and len(description) > 200:
            # 긴 여러 줄 텍스트는 docstring으로 처리
            description_str = '"""' + description.replace('"""', '\\"\\"\\"') + '"""'
        else:
            # 짧은 텍스트는 일반 문자열로 처리
            description_str = '"' + escaped_description + '"'
        
        # 기능별 import 추가
        imports = self._get_imports(agent_type, features)
        
        # 핵심 로직 생성
        core_logic = self._get_advanced_core_logic(agent_type, features)
        
        # 헬퍼 메서드들
        helper_methods = self._get_helper_methods(agent_type, features)
        
        code = f'''#!/usr/bin/env python3
"""
{agent_name} - Advanced Standalone Agent
{'='*40}
{description}

생성일: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
타입: {agent_type}
복잡도: {analysis["complexity"]}
기능: {", ".join(features) if features else "기본"}
"""

{imports}


class {agent_name}:
    """에이전트 클래스"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """에이전트 초기화"""
        self.name = "{agent_name}"
        self.description = {description_str}
        self.agent_type = "{agent_type}"
        self.config = config or {{}}
        self.logger = logging.getLogger(self.name)
        
        # 초기화
        self._initialize()
        self.logger.info(f"{{self.name}} 초기화 완료")
    
    def _initialize(self):
        """리소스 초기화"""
        # 에이전트별 초기화 로직
        pass
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """쿼리 처리 - 메인 함수"""
        try:
            self.logger.info(f"쿼리 처리 시작: {{query[:50]}}...")
            
            # 입력 검증
            if not query:
                return self._error_response("빈 쿼리입니다")
            
            # 컨텍스트 초기화
            if context is None:
                context = {{}}
            
            # 쿼리 전처리
            processed_query = self._preprocess_query(query)
            
{core_logic}
            
        except Exception as e:
            self.logger.error(f"처리 중 오류 발생: {{e}}", exc_info=True)
            return self._error_response(str(e))
    
    def _preprocess_query(self, query: str) -> str:
        """쿼리 전처리"""
        # 기본 정규화
        query = query.strip()
        # 추가 전처리 로직
        return query
    
    def _error_response(self, error_msg: str) -> AgentResponse:
        """에러 응답 생성"""
        return AgentResponse(
            type=AgentResponseType.ERROR,
            content={{"error": error_msg, "timestamp": datetime.now().isoformat()}}
        )
    
    def _success_response(self, data: Any, message: str = "성공") -> AgentResponse:
        """성공 응답 생성"""
        return AgentResponse(
            type=AgentResponseType.SUCCESS,
            content={{"data": data, "message": message, "timestamp": datetime.now().isoformat()}}
        )
    
    def get_info(self) -> Dict[str, Any]:
        """에이전트 정보"""
        return {{
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "version": "1.0.0",
            "capabilities": self._get_capabilities(),
            "config": self.config
        }}
    
    def _get_capabilities(self) -> List[str]:
        """에이전트 기능 목록"""
        base_capabilities = {{
            "calculator": ["arithmetic", "expression_evaluation", "unit_conversion"],
            "data_analysis": ["statistics", "visualization", "trend_analysis", "reporting"],
            "api_integration": ["rest_api", "authentication", "data_sync", "webhooks"],
            "web_scraping": ["html_parsing", "dynamic_content", "data_extraction", "automation"],
            "automation": ["scheduling", "workflow", "monitoring", "alerts"],
            "document_processing": ["text_extraction", "format_conversion", "nlp", "search"],
            "chatbot": ["conversation", "context_management", "nlp", "response_generation"],
            "monitoring": ["health_check", "metrics", "alerts", "reporting"]
        }}
        
        return base_capabilities.get(self.agent_type, ["general_processing"])


# 테스트 함수
async def test_agent():
    """에이전트 테스트"""
    agent = {agent_name}()
    
    print(f"\\n{'='*60}")
    print(f"{{agent.name}} 테스트")
    print('='*60)
    info = agent.get_info()
    print(f"설명: {{info['description']}}")
    print(f"타입: {{info['agent_type']}}")
    print(f"기능: {{', '.join(info['capabilities'])}}")
    print('='*60)
    
    # 테스트 쿼리
    test_queries = {self._get_test_queries(agent_type)}
    
    for query in test_queries:
        print(f"\\n쿼리: {{query}}")
        result = await agent.process(query)
        print(f"결과: {{json.dumps(result, ensure_ascii=False, indent=2)}}")
    
    print(f"\\n{'='*60}")
    print("✅ 테스트 완료!")


if __name__ == "__main__":
    # 로깅 설정
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # 테스트 실행
    asyncio.run(test_agent())
'''
        
        return code
    
    def _deduplicate_imports(self, code: str) -> str:
        """중복 import 문 제거 (개선된 버전)"""
        lines = code.split('\n')
        
        # import 문들을 수집
        regular_imports = {}  # module -> line
        from_imports = {}     # module -> {items}
        other_lines = []
        in_imports_section = True
        
        for line in lines:
            stripped = line.strip()
            
            # 빈 줄은 유지
            if not stripped:
                if in_imports_section:
                    continue  # import 섹션의 빈 줄은 무시
                else:
                    other_lines.append(line)
                continue
            
            # import 문 처리
            if stripped.startswith('import '):
                module = stripped[7:].strip()
                # datetime처럼 모듈명이 겹치는 경우 처리
                if module not in regular_imports:
                    regular_imports[module] = line
            # from X import Y 형태 처리
            elif stripped.startswith('from '):
                if ' import ' in stripped:
                    parts = stripped.split(' import ')
                    from_module = parts[0].strip()
                    import_items = parts[1].strip()
                    
                    # datetime 특수 처리: from datetime import datetime
                    if from_module == 'from datetime' and import_items == 'datetime':
                        # import datetime이 이미 있으면 skip
                        if 'datetime' in regular_imports:
                            continue
                    
                    if from_module not in from_imports:
                        from_imports[from_module] = set()
                    
                    # 각 import 항목 추가
                    for item in import_items.split(','):
                        from_imports[from_module].add(item.strip())
            else:
                # import가 아닌 코드 발견 - import 섹션 종료
                in_imports_section = False
                other_lines.append(line)
        
        # 재구성된 코드 생성
        result_lines = []
        
        # 1. 표준 라이브러리 imports
        std_libs = ['sys', 'os', 're', 'asyncio', 'json', 'datetime']
        for lib in std_libs:
            if lib in regular_imports:
                result_lines.append(regular_imports[lib])
        
        # 2. from imports (표준 라이브러리)
        for from_module, items in sorted(from_imports.items()):
            if any(std in from_module for std in ['typing', 'datetime', 'collections']):
                if items:
                    items_str = ', '.join(sorted(items))
                    result_lines.append(f"{from_module} import {items_str}")
        
        # 3. 서드파티 imports
        for module, line in regular_imports.items():
            if module not in std_libs:
                result_lines.append(line)
        
        # 4. from imports (서드파티)
        for from_module, items in sorted(from_imports.items()):
            if not any(std in from_module for std in ['typing', 'datetime', 'collections']):
                if items:
                    items_str = ', '.join(sorted(items))
                    result_lines.append(f"{from_module} import {items_str}")
        
        # 5. 빈 줄 추가
        if result_lines:
            result_lines.append('')
        
        # 6. 나머지 코드
        result_lines.extend(other_lines)
        
        return '\n'.join(result_lines)
    
    def _get_imports(self, agent_type: str, features: List[str]) -> str:
        """필요한 import 문 생성"""
        base_imports = """import asyncio
import json
import logging
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
import re"""
        
        additional_imports = []
        
        # 에이전트 타입별 imports
        if agent_type == "data_analysis":
            additional_imports.extend([
                "import pandas as pd",
                "import numpy as np"
            ])
            if "visualization" in features:
                additional_imports.append("import matplotlib.pyplot as plt")
        
        elif agent_type == "api_integration":
            additional_imports.extend([
                "import aiohttp",
                "import asyncio"
            ])
        
        elif agent_type == "web_scraping":
            additional_imports.extend([
                "from bs4 import BeautifulSoup",
                "import aiohttp"
            ])
        
        if "database" in features:
            additional_imports.append("import sqlite3")
        
        if "machine_learning" in features:
            additional_imports.append("from sklearn import preprocessing, model_selection")
        
        return base_imports + "\n" + "\n".join(additional_imports) if additional_imports else base_imports
    
    def _get_advanced_core_logic(self, agent_type: str, features: List[str]) -> str:
        """🧠 스마트 통합 기반 핵심 로직 생성 (Pattern System Integrated)"""
        print("🚨 DEBUG: _get_advanced_core_logic called with smart integration!")  # 강제 디버그
        
        # ✅ 실제 사용되는 analysis 데이터 구성
        analysis = {
            'agent_type': agent_type,
            'features': features,
            'original_query': f"{agent_type} 에이전트를 만들어주세요",
            'description': f"{agent_type} 에이전트",
            'complexity': 'moderate'
        }
        
        try:
            # 🔥 우리가 수정한 스마트 통합 시스템 호출!
            print("🚨 DEBUG: Calling pattern-based business logic from standalone!")  # 강제 디버그
            smart_logic = self._generate_pattern_based_business_logic(
                query=analysis['original_query'], 
                analysis=analysis
            )
            
            if smart_logic:
                print(f"✅ Smart integration generated {len(smart_logic)} characters")  # 강제 디버그
                return smart_logic
            else:
                print("⚠️ Smart integration returned empty, using legacy fallback")  # 강제 디버그
                
        except Exception as e:
            print(f"❌ Smart integration failed: {e}")  # 강제 디버그
            logger.error(f"Smart integration error in standalone: {e}")
        
        # 🔄 Legacy fallback (기존 하드코딩된 로직)
        print("🔄 Using legacy hardcoded logic as fallback")  # 강제 디버그
        logic_map = {
            "calculator": self._get_calculator_logic(),
            "data_analysis": self._get_data_analysis_logic(features),
            "api_integration": self._get_api_logic(features),
            "web_scraping": self._get_scraping_logic(features),
            "automation": self._get_automation_logic(features),
            "document_processing": self._get_document_logic(features),
            "chatbot": self._get_chatbot_logic(features),
            "monitoring": self._get_monitoring_logic(features)
        }
        
        return logic_map.get(agent_type, self._get_general_logic())
    
    def _get_calculator_logic(self) -> str:
        """계산기 로직"""
        return '''            # 계산기 핵심 로직
            try:
                # 수식 파싱
                expression = self._parse_expression(processed_query)
                
                # 계산 수행
                result = self._calculate(expression)
                
                # 단위 변환 (있는 경우)
                if "단위" in context:
                    result = self._convert_units(result, context["단위"])
                
                return self._success_response({
                    "result": result,
                    "expression": expression,
                    "formatted": self._format_result(result)
                })
                
            except Exception as e:
                return self._error_response(f"계산 오류: {str(e)}")'''
    
    def _get_data_analysis_logic(self, features: List[str]) -> str:
        """데이터 분석 로직"""
        visualization = "visualization" in features
        
        return f'''            # 데이터 분석 핵심 로직
            try:
                # 데이터 로드
                data = await self._load_data(context.get("data_source"))
                
                # 데이터 전처리
                cleaned_data = self._preprocess_data(data)
                
                # 분석 수행
                analysis_results = await self._perform_analysis(cleaned_data, processed_query)
                
                # 통계 생성
                statistics = self._generate_statistics(cleaned_data)
                
                {"# 시각화" if visualization else ""}
                {"visualizations = self._create_visualizations(cleaned_data, analysis_results)" if visualization else ""}
                
                return self._success_response({{
                    "analysis": analysis_results,
                    "statistics": statistics,
                    {"'visualizations': visualizations," if visualization else ""}
                    "summary": self._generate_summary(analysis_results)
                }})
                
            except Exception as e:
                return self._error_response(f"분석 오류: {{str(e)}}")'''
    
    def _get_api_logic(self, features: List[str]) -> str:
        """API 통합 로직"""
        return '''            # API 통합 핵심 로직
            try:
                # API 설정
                api_config = self._prepare_api_config(context)
                
                # 인증 처리
                auth_headers = await self._handle_authentication(api_config)
                
                # API 호출
                response = await self._make_api_request(
                    api_config["url"],
                    api_config.get("method", "GET"),
                    headers=auth_headers,
                    data=api_config.get("data")
                )
                
                # 응답 처리
                processed_response = self._process_api_response(response)
                
                # 데이터 변환
                transformed_data = self._transform_data(processed_response)
                
                return self._success_response({
                    "data": transformed_data,
                    "status_code": response.get("status_code"),
                    "headers": response.get("headers")
                })
                
            except Exception as e:
                return self._error_response(f"API 오류: {str(e)}")'''
    
    def _get_general_logic(self) -> str:
        """범용 로직"""
        return '''            # 범용 처리 로직
            try:
                # 작업 분류
                task_type = self._classify_task(processed_query)
                
                # 작업별 처리
                if task_type == "information":
                    result = await self._process_information_request(processed_query, context)
                elif task_type == "action":
                    result = await self._process_action_request(processed_query, context)
                else:
                    result = await self._process_general_request(processed_query, context)
                
                return self._success_response(result)
                
            except Exception as e:
                return self._error_response(f"처리 오류: {str(e)}")'''
    
    def _get_helper_methods(self, agent_type: str, features: List[str]) -> str:
        """헬퍼 메서드 생성"""
        
        if agent_type == "calculator":
            return '''    def _parse_expression(self, query: str) -> str:
        """수식 파싱"""
        # 한글 연산자를 기호로 변환
        query = query.replace("더하기", "+").replace("빼기", "-")
        query = query.replace("곱하기", "*").replace("나누기", "/")
        
        # 숫자와 연산자 추출
        pattern = r'[\d\.\+\-\*\/\(\)\s]+'
        matches = re.findall(pattern, query)
        
        return "".join(matches).strip()
    
    def _calculate(self, expression: str) -> float:
        """안전한 계산 수행"""
        # eval 대신 안전한 파서 사용
        try:
            # 간단한 검증
            if not re.match(r'^[\d\.\+\-\*\/\(\)\s]+$', expression):
                raise ValueError("유효하지 않은 수식")
            
            # 계산 (실제로는 더 안전한 방법 사용 권장)
            result = eval(expression)
            return float(result)
        except:
            raise ValueError("계산할 수 없는 수식입니다")
    
    def _format_result(self, result: float) -> str:
        """결과 포맷팅"""
        if result.is_integer():
            return str(int(result))
        else:
            return f"{result:.2f}"'''
        
        elif agent_type == "data_analysis":
            return '''    async def _load_data(self, data_source: Any) -> Any:
        """데이터 로드"""
        if data_source is None:
            # 샘플 데이터 생성
            import pandas as pd
            return pd.DataFrame({
                'date': pd.date_range('2024-01-01', periods=100),
                'value': np.random.randn(100).cumsum() + 100,
                'category': np.random.choice(['A', 'B', 'C'], 100)
            })
        elif isinstance(data_source, str) and data_source.endswith('.csv'):
            return pd.read_csv(data_source)
        else:
            return data_source
    
    def _preprocess_data(self, data: Any) -> Any:
        """데이터 전처리"""
        if hasattr(data, 'dropna'):
            data = data.dropna()
        return data
    
    async def _perform_analysis(self, data: Any, query: str) -> Dict[str, Any]:
        """분석 수행"""
        results = {}
        
        if hasattr(data, 'describe'):
            results['summary'] = data.describe().to_dict()
        
        if hasattr(data, 'corr'):
            results['correlation'] = data.select_dtypes(include=[np.number]).corr().to_dict()
        
        return results
    
    def _generate_statistics(self, data: Any) -> Dict[str, Any]:
        """통계 생성"""
        stats = {}
        
        if hasattr(data, 'shape'):
            stats['shape'] = data.shape
            stats['columns'] = list(data.columns) if hasattr(data, 'columns') else []
        
        return stats
    
    def _generate_summary(self, analysis: Dict[str, Any]) -> str:
        """요약 생성"""
        summary_parts = []
        
        if 'summary' in analysis:
            summary_parts.append("데이터 통계 분석이 완료되었습니다.")
        
        if 'correlation' in analysis:
            summary_parts.append("상관관계 분석이 포함되었습니다.")
        
        return " ".join(summary_parts)'''
        
        else:
            return '''    def _classify_task(self, query: str) -> str:
        """작업 분류"""
        query_lower = query.lower()
        
        if any(word in query_lower for word in ["정보", "알려", "무엇", "어떻게"]):
            return "information"
        elif any(word in query_lower for word in ["실행", "처리", "만들어", "생성"]):
            return "action"
        else:
            return "general"
    
    async def _process_information_request(self, query: str, context: Dict) -> Dict[str, Any]:
        """정보 요청 처리"""
        return {
            "type": "information",
            "query": query,
            "response": "요청하신 정보를 처리했습니다."
        }
    
    async def _process_action_request(self, query: str, context: Dict) -> Dict[str, Any]:
        """작업 요청 처리"""
        return {
            "type": "action",
            "query": query,
            "status": "completed",
            "result": "작업이 완료되었습니다."
        }
    
    async def _process_general_request(self, query: str, context: Dict) -> Dict[str, Any]:
        """일반 요청 처리"""
        return {
            "type": "general",
            "query": query,
            "processed": True
        }'''
    
    def _get_test_queries(self, agent_type: str) -> str:
        """테스트 쿼리 생성"""
        queries_map = {
            "calculator": '["10 더하기 5는?", "100에서 25를 빼면?", "(7 * 8) + 10은?"]',
            "data_analysis": '["데이터를 분석해줘", "통계 요약을 보여줘", "트렌드를 찾아줘"]',
            "api_integration": '["API 데이터를 가져와줘", "서버 상태 확인", "데이터 동기화"]',
            "web_scraping": '["웹페이지 데이터 수집", "링크 추출해줘", "콘텐츠 파싱"]',
            "automation": '["작업을 자동화해줘", "스케줄 설정", "프로세스 실행"]',
            "document_processing": '["문서를 분석해줘", "텍스트 추출", "형식 변환"]',
            "chatbot": '["안녕하세요", "도움이 필요해요", "정보를 찾아줘"]',
            "monitoring": '["시스템 상태 확인", "성능 모니터링", "알림 설정"]'
        }
        
        return queries_map.get(agent_type, '["테스트 쿼리 1", "테스트 쿼리 2"]')
    
    def _get_scraping_logic(self, features: List[str]) -> str:
        """웹 스크래핑 로직"""
        return '''            # 웹 스크래핑 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "웹 스크래핑 기능"})'''
    
    def _get_automation_logic(self, features: List[str]) -> str:
        """자동화 로직"""
        return '''            # 자동화 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "자동화 기능"})'''
    
    def _get_document_logic(self, features: List[str]) -> str:
        """문서 처리 로직"""
        return '''            # 문서 처리 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "문서 처리 기능"})'''
    
    def _get_chatbot_logic(self, features: List[str]) -> str:
        """챗봇 로직"""
        return '''            # 챗봇 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "챗봇 응답"})'''
    
    def _get_monitoring_logic(self, features: List[str]) -> str:
        """모니터링 로직"""
        return '''            # 모니터링 로직
            # 실제 구현 시 추가
            return self._success_response({"message": "모니터링 기능"})'''
    
    def _generate_logosai_code(self, analysis: Dict[str, Any]) -> str:
        """LogosAI 에이전트 코드 생성 - AST 기반으로 개선"""
        
        # AST 생성기 사용 옵션 체크
        use_ast = os.getenv('FORGE_USE_AST', 'true').lower() == 'true'
        
        if use_ast:
            try:
                # Try different import methods
                try:
                    from .ast_code_generator import ForgeASTGenerator
                except ImportError:
                    try:
                        from ast_code_generator import ForgeASTGenerator
                    except ImportError:
                        import sys
                        import os as os_module
                        sys.path.insert(0, os_module.path.dirname(os_module.path.abspath(__file__)))
                        from ast_code_generator import ForgeASTGenerator
                
                logger.info("✅ AST generator successfully imported!")
                return self._generate_logosai_code_ast(analysis)
            except ImportError as e:
                logger.warning(f"AST generator not available: {e}, falling back to template")
        
        # 기존 템플릿 방식 (fallback)
        return self._generate_logosai_code_template(analysis)
    
    def _generate_logosai_code_ast(self, analysis: Dict[str, Any]) -> str:
        """AST 기반 LogosAI 에이전트 코드 생성 - 들여쓰기 오류 방지"""
        # Import AST generator
        try:
            from .ast_code_generator import ForgeASTGenerator
        except ImportError:
            try:
                from ast_code_generator import ForgeASTGenerator
            except ImportError:
                import sys
                import os as os_module
                sys.path.insert(0, os_module.path.dirname(os_module.path.abspath(__file__)))
                from ast_code_generator import ForgeASTGenerator
        
        logger.info("🚀 Using AST-based code generation (no indentation errors!)")
        
        agent_name = analysis["agent_name"]
        # Use the class name from analysis or generate from agent_name
        agent_class_name = analysis.get("agent_class_name") or self._generate_class_name(agent_name)
        description = analysis.get("description", "Generated agent")
        agent_type = analysis.get("agent_type", "CUSTOM")
        
        # 비즈니스 로직 가져오기 (analysis에 이미 있으면 사용, 없으면 생성)
        if 'business_logic' in analysis and analysis['business_logic']:
            business_logic = analysis['business_logic']
            logger.info(f"📦 Using pre-generated business logic from analysis: {len(business_logic)} chars")
        else:
            business_logic = self._get_logosai_core_business_logic(analysis)
        
        # AST 생성기 사용
        generator = ForgeASTGenerator()
        code = generator.create_logosai_agent_ast(
            agent_name=agent_name,
            agent_class_name=agent_class_name,
            description=description,
            agent_type=agent_type,
            business_logic_text=business_logic
        )
        
        logger.info(f"✅ AST generated {len(code)} characters of error-free code")
        return code
    
    def _generate_logosai_code_template(self, analysis: Dict[str, Any]) -> str:
        """LogosAI 프레임워크 기반 코드 생성 - 템플릿 활용"""
        from pathlib import Path  # Use Path instead of os for security
        
        # 템플릿 매칭 시도 (specialized 템플릿 우선)
        template_path = None
        template_info = None
        
        if self.template_matcher:
            try:
                # 원본 쿼리를 사용하여 최적의 템플릿 찾기
                query = analysis.get("original_query", analysis.get("description", ""))
                
                # Since match_template is async and we're in a sync context,
                # we'll use a simpler keyword-based matching for now
                template_id = None
                score = 0.0
                
                # Simple keyword matching fallback
                query_lower = query.lower()
                for tid, tmeta in self.template_matcher.templates_metadata.items():
                    keywords = tmeta.get("keywords", [])
                    matches = sum(1 for kw in keywords if kw.lower() in query_lower)
                    if matches > 0:
                        current_score = matches / len(keywords) if keywords else 0
                        if current_score > score:
                            template_id = tid
                            score = current_score
                # Convert to expected format
                template_info = {
                    "path": self.template_matcher.templates_metadata.get(template_id, {}).get("path"),
                    "template_id": template_id,
                    "score": score
                } if template_id and score > 0.3 else None
                
                if template_info and template_info.get("path"):
                    # specialized 템플릿 경로 구성
                    template_path = Path(__file__).parent.parent / "templates" / template_info["path"]
                    if template_path.exists():
                        logger.info(f"🎯 특화 템플릿 선택: {template_info['path']} (점수: {template_info.get('score', 0):.2f})")
                    else:
                        logger.warning(f"⚠️ 특화 템플릿 파일이 없음: {template_path}")
                        template_path = None
            except Exception as e:
                logger.warning(f"템플릿 매칭 중 오류: {e}")
        
        # 기본 템플릿 폴백
        if not template_path:
            template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template.py.template"
            logger.info("📋 기본 템플릿 사용")
        
        # 템플릿 파일 읽기
        if template_path.exists():
            with open(template_path, 'r', encoding='utf-8') as f:
                template = f.read()
            logger.info(f"✅ 템플릿 파일 로드 완료: {template_path}")
        else:
            logger.warning(f"⚠️ 템플릿 파일이 없음. 기존 방식 사용: {template_path}")
            # 템플릿 파일이 없으면 기존 방식 사용
            return self._generate_logosai_code_legacy(analysis)
        
        agent_name = analysis["agent_name"]
        description = analysis["description"]
        agent_type = analysis["agent_type"]
        features = analysis["features"]
        
        # 에이전트 클래스 이름 생성 (공백 및 특수문자 제거)
        agent_class_name = self._generate_class_name(agent_name)
        
        # 타입별 커스텀 설정
        custom_config = self._get_custom_config_for_logosai(analysis)
        custom_init = self._get_custom_init_for_logosai(analysis)
        custom_async_init = self._get_custom_async_init_for_logosai(analysis)
        
        # 쿼리 추출 프롬프트 생성
        query_extraction_prompt = self._get_query_extraction_prompt(analysis)
        
        # 핵심 비즈니스 로직 생성
        print("🚨 DEBUG: About to call _get_logosai_core_business_logic!")  # 강제 디버그
        try:
            core_business_logic = self._get_logosai_core_business_logic(analysis)
            print(f"🚨 DEBUG: core_business_logic length: {len(core_business_logic)}")  # 강제 디버그
            
            # 안전장치: None 또는 빈 값 확인
            if not core_business_logic or core_business_logic.strip() == "":
                logger.warning("⚠️ Empty core business logic, using default")
                core_business_logic = '''# 기본 처리 로직 (try 블록용)
                logger.info("🔄 Using default processing logic")
                
                # 입력 데이터 처리
                if isinstance(extracted_info, dict):
                    data = extracted_info
                else:
                    data = {"input": str(extracted_info)}
                
                # 결과 생성
                result = {
                    "status": "success", 
                    "data": data,
                    "message": "Default processing completed",
                    "timestamp": datetime.now().isoformat()
                }
                
                logger.info("✅ Default processing completed")
                return result'''
                
            # Helper 함수를 클래스 메서드로 변환
            if 'def ' in core_business_logic:
                logger.info("🔧 Helper functions detected, converting to class methods")
                lines = core_business_logic.split('\n')
                processed_lines = []
                helper_methods = []
                execution_lines = []
                in_function = False
                function_indent = 0
                
                i = 0
                while i < len(lines):
                    line = lines[i]
                    
                    # Helper 함수 시작 감지
                    if line.strip().startswith('def ') and not line.strip().startswith('def _process_core_logic'):
                        in_function = True
                        function_indent = len(line) - len(line.lstrip())
                        # Helper 함수를 클래스 메서드로 변환
                        function_name = line.strip().split('(')[0].replace('def ', '')
                        # self 파라미터 추가
                        if '(self' not in line:
                            if '()' in line:
                                line = line.replace('()', '(self)')
                            else:
                                line = line.replace('(', '(self, ', 1)
                        helper_methods.append(line)
                        i += 1
                        continue
                    
                    # Helper 함수 내용
                    elif in_function:
                        current_indent = len(line) - len(line.lstrip()) if line.strip() else function_indent + 4
                        if current_indent > function_indent or not line.strip():
                            helper_methods.append(line)
                        else:
                            in_function = False
                            # 현재 라인을 실행 코드로 처리
                            if not line.strip().startswith('def '):
                                execution_lines.append(line)
                        i += 1
                        continue
                    
                    # 일반 실행 코드
                    else:
                        # 함수 호출을 self.method() 형태로 변경
                        for method_line in helper_methods:
                            if 'def ' in method_line:
                                func_name = method_line.strip().split('(')[0].replace('def ', '')
                                if func_name + '(' in line and 'self.' + func_name not in line:
                                    line = line.replace(func_name + '(', 'self.' + func_name + '(')
                        execution_lines.append(line)
                        i += 1
                
                # Helper 메서드와 실행 코드 결합
                if helper_methods:
                    # Helper 메서드들을 별도로 저장 (나중에 클래스에 추가)
                    self._helper_methods = '\n'.join(helper_methods)
                    logger.info(f"✅ Extracted {len([m for m in helper_methods if 'def ' in m])} helper methods")
                else:
                    self._helper_methods = ""
                
                # 실행 코드만 core_business_logic에 유지
                core_business_logic = '\n'.join(execution_lines) if execution_lines else '''# 기본 처리 로직
                result = {"status": "success", "data": extracted_info}
                return result'''
                    
        except Exception as e:
            logger.error(f"❌ Core business logic generation failed: {e}")
            core_business_logic = '''# 오류 대응 기본 로직
                try:
                    result = {"status": "success", "data": extracted_info}
                    return result  
                except Exception as e:
                    return {"status": "error", "error": str(e)}'''
        
        # 🔧 후처리: Helper 함수 자동 추가
        try:
            try:
                from forge.core.helper_post_processor import HelperPostProcessor
            except ImportError:
                # Fallback for when forge is not in path
                import sys
                import os
                core_path = os.path.dirname(os.path.abspath(__file__))
                sys.path.insert(0, os.path.dirname(core_path))
                from core.helper_post_processor import HelperPostProcessor
            processor = HelperPostProcessor()
            
            # 🔧 DISABLED: Helper 함수 처리 임시 비활성화 (들여쓰기 충돌 방지)
            query = analysis.get('original_query', analysis.get('query', ''))
            logger.info("ℹ️ Helper post processor 임시 비활성화 (Nuclear Indentation Fix와 충돌 방지)")
            
            # 원래 코드 (비활성화됨):
            # processed_logic = processor.process_business_logic(core_business_logic, query)
            # is_valid, fixed_logic = processor.validate_and_fix(processed_logic, query)
            # if is_valid:
            #     logger.info("✅ Helper 함수 후처리 완료")
            #     core_business_logic = fixed_logic
            # else:
            #     logger.warning("⚠️ Helper 함수 후처리 실패, 원본 사용")
                
        except Exception as e:
            logger.error(f"❌ Helper 후처리 중 오류: {e}")
        
        # 응답 생성 프롬프트
        response_generation_prompt = self._get_response_generation_prompt(analysis)
        
        # 테스트 쿼리 생성
        test_queries = self._get_test_queries_for_logosai(analysis)
        
        # 샘플 데이터 코드 생성
        sample_data_code = self._get_sample_data_code_for_logosai(analysis)
        
        # 커스텀 클린업
        custom_cleanup = self._get_custom_cleanup_for_logosai(analysis)
        
        # 템플릿 변수 치환 (백틱 안전성 검사 포함)
        def safe_replace(text: str, placeholder: str, value: str, is_code: bool = False) -> str:
            """백틱 안전성 검사를 포함한 템플릿 치환
            
            Args:
                text: 템플릿 텍스트
                placeholder: 치환할 플레이스홀더
                value: 치환 값
                is_code: True면 Python 코드로 간주하여 이스케이프하지 않음
            """
            import re
            
            # 백틱 제거 강화
            if '```' in str(value) or '`' in str(value):
                logger.warning(f"⚠️ 템플릿 변수 '{placeholder}'에 백틱 패턴 발견, 제거 중")
                # 코드 블록 백틱 제거
                value = re.sub(r'```[\w]*\n?', '', str(value))  # 코드 블록 시작
                value = re.sub(r'\n?```', '', value)            # 코드 블록 끝
                value = value.replace('`', '')                  # 단일 백틱
            
            value_str = str(value)
            
            # 🔍 Enhanced logging for all placeholders
            code_placeholders = [
                "{core_business_logic}",
                "{agent_imports}",
                "{initialization_code}",
                "{business_logic_implementation}",
                "{processing_logic}",
                "{helper_methods}"
            ]
            
            # Log all placeholder replacements for monitoring
            logger.debug(f"📋 Processing placeholder: {placeholder[:50]}... ({len(value_str)} chars)")
            
            # Check for potential indentation issues
            if placeholder in code_placeholders:
                lines = value_str.split('\n')
                if lines:
                    first_line_indent = len(lines[0]) - len(lines[0].lstrip()) if lines[0].strip() else 0
                    avg_indent = sum(len(l) - len(l.lstrip()) for l in lines if l.strip()) / max(1, len([l for l in lines if l.strip()]))
                    if first_line_indent > 0 and abs(first_line_indent - avg_indent) > 8:
                        logger.warning(f"⚠️ Potential indentation issue in {placeholder}: first={first_line_indent}, avg={avg_indent:.1f}")
            
            # Debug logging for description - 전체 길이 사용
            if placeholder == "{agent_description}":
                logger.info(f"🔍 Processing description: full length = {len(value_str)} chars")
            
            # 🔧 NUCLEAR INDENTATION FIX: 완전히 새로운 접근 방식
            if placeholder == "{core_business_logic}":
                logger.info(f"🔧 Nuclear indentation fix for core_business_logic ({len(value_str)} chars)")
                lines = value_str.split('\n')
                
                # STEP 1: 모든 들여쓰기 제거 (완전히 왼쪽 정렬)
                normalized_lines = []
                for line in lines:
                    normalized_lines.append(line.lstrip())  # 모든 앞 공백 제거
                
                # STEP 2: 깨끗한 12칸 들여쓰기 적용
                final_lines = []
                for line in normalized_lines:
                    if line.strip():  # 비어있지 않은 줄
                        # 모든 코드에 균등하게 12칸 들여쓰기 적용
                        final_lines.append('            ' + line)  # 정확히 12칸
                    else:  # 빈 줄
                        final_lines.append('')
                
                value_str = '\n'.join(final_lines)
                logger.info(f"✅ Nuclear indentation fix applied: all lines normalized to 12 spaces")
            
            elif placeholder == "{core_business_logic}_OLD":
                # 이전 복잡한 로직 (비활성화)
                indents = []
                if indents:
                    # 첫 번째 줄을 제외한 나머지 줄들의 최소 들여쓰기 확인
                    if len(indents) > 1:
                        rest_indents = indents[1:]
                        min_rest_indent = min(rest_indents) if rest_indents else 0
                        
                        # 첫 번째 줄이 과도하게 들여쓰기되어 있는지 확인
                        if indents[0] > min_rest_indent + 4:  # 4칸 이상 차이나면 과도한 것
                            logger.warning(f"⚠️ First line has excessive indentation: {indents[0]} vs {min_rest_indent}")
                            base_indent = min_rest_indent
                            # 첫 번째 줄을 정규화
                            if lines[0].strip():
                                lines[0] = ' ' * min_rest_indent + lines[0].strip()
                        else:
                            base_indent = min(indents)
                    else:
                        base_indent = indents[0]
                else:
                    base_indent = 0
                
                # 이미 들여쓰기가 12칸인 경우 조정하지 않음
                if base_indent == 12:
                    logger.info(f"📐 Code already indented {base_indent} spaces, no adjustment needed")
                    value_str = '\n'.join(lines)
                elif base_indent > 12:
                    # 12칸 이상 들여쓰기 된 경우, 모든 라인에서 초과분만큼 뺌
                    logger.info(f"📐 Code over-indented {base_indent} spaces, normalizing to 12 spaces")
                    adjusted_lines = []
                    excess_indent = base_indent - 12
                    
                    for line in lines:
                        if line.strip():
                            # 초과 들여쓰기 제거
                            if len(line) > excess_indent and line[:excess_indent].strip() == '':
                                adjusted_line = line[excess_indent:]
                            else:
                                adjusted_line = line.lstrip()
                                # 12칸 들여쓰기 추가
                                if adjusted_line:
                                    adjusted_line = '            ' + adjusted_line
                            adjusted_lines.append(adjusted_line)
                        else:
                            adjusted_lines.append(line)
                    
                    value_str = '\n'.join(adjusted_lines)
                    logger.info(f"✅ Over-indentation fixed")
                else:
                    logger.info(f"📐 Base indentation detected: {base_indent} spaces, adjusting to 12 spaces")
                    
                    # 첫 번째 비어있지 않은 줄의 들여쓰기가 과도한지 체크
                    first_non_empty_indent = None
                    for line in lines:
                        if line.strip():
                            first_non_empty_indent = len(line) - len(line.lstrip())
                            break
                    
                    # 과도한 들여쓰기 감지 (20칸 이상이면 과도한 것으로 간주)
                    if first_non_empty_indent and first_non_empty_indent >= 20:
                        logger.warning(f"⚠️ Excessive first line indentation detected: {first_non_empty_indent} spaces, normalizing...")
                        base_indent = first_non_empty_indent  # 첫 줄을 베이스로 설정
                    
                    adjusted_lines = []
                    for line in lines:
                        if line.strip():  # 빈 줄이 아닌 경우
                            # 딕셔너리 문자열 안전 처리
                            # "key": "value 형태에서 value가 끊기지 않도록 처리
                            stripped_line = line.lstrip()
                            if '": "' in stripped_line and not stripped_line.rstrip().endswith(('",', '"}', '"')):
                                # 문자열이 완료되지 않은 경우 종료 추가
                                if not stripped_line.rstrip().endswith('"'):
                                    stripped_line = stripped_line.rstrip() + '"'
                                    logger.debug(f"🔧 Fixed incomplete string: {stripped_line[:50]}...")
                            
                            # 원본 들여쓰기에서 베이스를 빼서 상대적 들여쓰기 계산
                            original_indent = len(line) - len(line.lstrip())
                            relative_indent = max(0, original_indent - base_indent)
                            
                            # 12칸 베이스 + 상대적 들여쓰기
                            new_indent = '            ' + (' ' * relative_indent)  # 12 + relative
                            adjusted_line = new_indent + stripped_line
                            adjusted_lines.append(adjusted_line)
                        else:
                            # 빈 줄은 그대로 유지
                            adjusted_lines.append(line)
                    
                    value_str = '\n'.join(adjusted_lines)
                    logger.info(f"✅ Smart indentation adjustment completed")
            
            # Python 코드가 아닌 경우에만 이스케이프
            if not is_code:
                # 여러 줄 문자열을 Python 문자열로 안전하게 이스케이프
                # description 같은 여러 줄 텍스트가 Python 코드에 들어갈 때 문법 오류 방지
                value_str = value_str.replace('\\', '\\\\')  # 백슬래시를 먼저 이스케이프
                value_str = value_str.replace('"', '\\"')    # 큰따옴표 이스케이프
                value_str = value_str.replace('\n', '\\n')   # 개행 문자를 \n으로
                value_str = value_str.replace('\r', '\\r')   # 캐리지 리턴을 \r로
                value_str = value_str.replace('\t', '\\t')   # 탭을 \t로
                
                # 긴 문자열 처리를 위한 추가 안전장치
                # 100자 이상의 문자열은 분할하여 처리
                if len(value_str) > 100:
                    # 문자열을 안전한 크기로 분할
                    max_chunk_size = 80
                    chunks = []
                    for i in range(0, len(value_str), max_chunk_size):
                        chunk = value_str[i:i+max_chunk_size]
                        # 분할 지점이 이스케이프 시퀀스 중간이 아닌지 확인
                        if i + max_chunk_size < len(value_str) and chunk.endswith('\\'):
                            # 이스케이프 시퀀스를 분할하지 않도록 조정
                            chunk = value_str[i:i+max_chunk_size-1]
                        chunks.append(chunk)
                    # 문자열 연결 (Python 코드에서 연결될 때를 고려)
                    value_str = '" + "'.join(chunks)
                
                if placeholder == "{agent_description}":
                    logger.info(f"🔍 After escaping: total length = {len(value_str)} chars")
            
            return text.replace(placeholder, value_str)
        
        code = safe_replace(template, "{agent_class_name}", agent_class_name)
        code = safe_replace(code, "{agent_name}", agent_name)
        logger.info(f"DEBUG: description = full length: {len(description)} chars")
        code = safe_replace(code, "{agent_description}", description)
        code = safe_replace(code, "{custom_config}", custom_config, is_code=True)  # Python code
        code = safe_replace(code, "{custom_init}", custom_init, is_code=True)  # Python code
        code = safe_replace(code, "{custom_async_init}", custom_async_init, is_code=True)  # Python code
        code = safe_replace(code, "{query_extraction_prompt}", query_extraction_prompt)
        code = safe_replace(code, "{core_business_logic}", core_business_logic, is_code=True)  # Python code
        
        # Helper 메서드 추가 (있는 경우)
        if hasattr(self, '_helper_methods') and self._helper_methods:
            logger.info(f"🔧 Adding helper methods to agent class")
            # {helper_methods} 플레이스홀더가 있으면 그곳에 추가
            if "{helper_methods}" in code:
                code = safe_replace(code, "{helper_methods}", self._helper_methods, is_code=True)
            else:
                # 없으면 _process_core_logic 메서드 앞에 추가
                process_core_logic_idx = code.find("async def _process_core_logic")
                if process_core_logic_idx > 0:
                    # 적절한 들여쓰기 찾기
                    lines_before = code[:process_core_logic_idx].split('\n')
                    indent = "    "  # 기본 클래스 메서드 들여쓰기
                    
                    # Helper 메서드 들여쓰기 조정
                    helper_lines = self._helper_methods.split('\n')
                    adjusted_helpers = []
                    for line in helper_lines:
                        if line.strip():
                            if line.strip().startswith('def '):
                                adjusted_helpers.append(f"\n{indent}{line.strip()}")
                            else:
                                adjusted_helpers.append(f"{indent}{line}")
                        else:
                            adjusted_helpers.append("")
                    
                    helper_code = '\n'.join(adjusted_helpers) + "\n\n"
                    code = code[:process_core_logic_idx] + helper_code + code[process_core_logic_idx:]
                    logger.info(f"✅ Added {len([l for l in adjusted_helpers if 'def ' in l])} helper methods to class")
        
        # 🔧 추가: 후처리된 helper 함수도 클래스에 추가
        try:
            # core_business_logic에서 정의되지 않은 함수 감지
            undefined_in_logic = self._find_undefined_functions_in_logic(core_business_logic)
            
            if undefined_in_logic:
                logger.warning(f"⚠️ Undefined functions in business logic: {undefined_in_logic}")
                
                # Helper 라이브러리에서 함수 가져오기
                try:
                    from forge.core.helper_library import HelperLibrary
                except ImportError:
                    import sys
                    import os
                    core_path = os.path.dirname(os.path.abspath(__file__))
                    sys.path.insert(0, os.path.dirname(core_path))
                    from core.helper_library import HelperLibrary
                helper_lib = HelperLibrary()
                query = analysis.get('original_query', analysis.get('query', ''))
                library_helpers = helper_lib.get_helper_functions_for_query(query)
                
                # 클래스 메서드로 추가
                helper_methods_to_add = []
                for func_name in undefined_in_logic:
                    # 라이브러리에서 함수 찾기
                    pattern = rf'def\s+{func_name}\s*\([^)]*\):.*?(?=\n(?:def\s+\w+|$))'
                    import re
                    match = re.search(pattern, library_helpers, re.DOTALL)
                    
                    if match:
                        # self 파라미터 추가
                        func_code = match.group(0)
                        if '(self' not in func_code:
                            func_code = func_code.replace(f'def {func_name}(', f'def {func_name}(self, ', 1)
                        helper_methods_to_add.append(func_code)
                        logger.info(f"✅ Found {func_name} in library")
                
                # 클래스에 메서드 추가
                if helper_methods_to_add:
                    process_core_logic_idx = code.find("async def _process_core_logic")
                    if process_core_logic_idx > 0:
                        helper_code = "\n    ".join(helper_methods_to_add) + "\n\n"
                        code = code[:process_core_logic_idx] + "    " + helper_code + code[process_core_logic_idx:]
                        logger.info(f"✅ Added {len(helper_methods_to_add)} helper methods from library")
                        
        except Exception as e:
            logger.error(f"❌ Failed to add library helpers: {e}")
        
        code = safe_replace(code, "{response_generation_prompt}", response_generation_prompt)
        code = safe_replace(code, "{test_queries}", json.dumps(test_queries, ensure_ascii=False), is_code=True)  # Python code - JSON array
        code = safe_replace(code, "{sample_data_code}", sample_data_code, is_code=True)  # Python code
        code = safe_replace(code, "{custom_cleanup}", custom_cleanup, is_code=True)  # Python code
        
        # 템플릿에서 사용된 이중 중괄호를 단일 중괄호로 변환
        # {{와 }}는 템플릿에서 리터럴 중괄호를 나타내는 이스케이프 시퀀스
        code = code.replace("{{", "{")
        code = code.replace("}}", "}")
        
        # 백틱 제거 및 검증 로직 (포괄적 백틱 제거기 사용)
        try:
            from .backtick_sanitizer import sanitize_code_safe, is_code_safe_for_exec
        except ImportError:
            # Fallback for server environment
            import sys
            import os
            core_path = os.path.join(os.path.dirname(__file__))
            sys.path.insert(0, core_path)
            from backtick_sanitizer import sanitize_code_safe, is_code_safe_for_exec
        
        code = sanitize_code_safe(code, "final_forge_system")
        
        # 추가 안전성 검증
        if not is_code_safe_for_exec(code):
            logger.error("❌ exec() 안전성 검사 실패, 긴급 정리 실행")
            from .backtick_sanitizer import BacktickSanitizer
            code = BacktickSanitizer.emergency_cleanup(code)
        
        logger.info(f"✅ LogosAI 에이전트 코드 생성 완료: {agent_class_name}")
        logger.info(f"🔍 최종 코드 백틱 개수: {code.count('```')}")
        
        return code
    
    def _generate_logosai_code_legacy(self, analysis: Dict[str, Any]) -> str:
        """LogosAI 호환 코드 생성 (레거시 - 템플릿 없을 때)"""

        agent_name = analysis["agent_name"]
        # 클래스 이름 sanitization (공백 및 특수문자 제거)
        agent_class_name = self._generate_class_name(agent_name)
        description = analysis["description"]
        agent_type = analysis["agent_type"]
        features = analysis["features"]
        
        # LogosAI framework imports
        imports = '''import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from loguru import logger

# LogosAI framework imports
from logosai import (
    LogosAIAgent,
    AgentConfig,
    AgentType,
    AgentResponse,
    AgentResponseType
)
from logosai.llm import LLMClient'''
        
        # 에이전트 타입별 추가 imports
        if agent_type == "data_analysis":
            imports += "\nimport pandas as pd\nimport numpy as np"
        elif agent_type == "api_integration":
            imports += "\nimport aiohttp\nimport asyncio"
        elif agent_type == "web_scraping":
            imports += "\nfrom bs4 import BeautifulSoup\nimport aiohttp"
        
        # 핵심 비즈니스 로직 생성
        business_logic = self._get_logosai_business_logic(agent_type, features)
        
        # 헬퍼 메서드들
        helper_methods = self._get_logosai_helper_methods(agent_type, features)
        
        code = f'''"""
{agent_name} - LogosAI Framework Agent (Legacy)
{'='*40}
{description}

Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Type: {agent_type}
Framework: LogosAI
"""

{imports}


class {agent_class_name}(LogosAIAgent):
    """
    {description}

    This agent demonstrates:
    - Natural language query processing using LLM
    - Async/await pattern for all operations
    - Proper error handling and logging
    - LogosAI framework integration
    """

    def __init__(self, config: Optional[AgentConfig] = None):
        """Initialize the agent with configuration."""
        if config is None:
            config = AgentConfig(
                name="{agent_name}",
                agent_type=AgentType.CUSTOM,
                description="{description}",
                config={{
                    "model": "gemini-2.5-flash-lite",
                    "temperature": 0.7,
                    "max_tokens": 15000  # 충분한 토큰으로 증가
                }}
            )
        
        super().__init__(config)
        
        # Initialize instance variables
        self.llm_client: Optional[LLMClient] = None
        self.is_initialized = False
        
        logger.info(f"{{self.name}} initialized with config: {{self.config}}")
    
    async def initialize(self) -> bool:
        """
        Async initialization for resources that require await.
        This is called after __init__ and before the agent starts processing.
        """
        try:
            # Initialize LLM client
            self.llm_client = LLMClient(
                model=self.config.config.get("model", "gemini-2.5-flash-lite"),
                temperature=self.config.config.get("temperature", 0.7),
                max_tokens=self.config.config.get("max_tokens", 15000)  # 기본값도 15000으로 증가
            )
            
            self.is_initialized = True
            logger.info(f"{{self.name}} initialization completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize {{self.name}}: {{str(e)}}")
            return False
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        """
        Main processing method for the agent.
        
        Args:
            query: The user's query or request
            context: Optional context dictionary
            
        Returns:
            AgentResponse with appropriate type and content
        """
        try:
            # Ensure agent is initialized
            if not self.is_initialized:
                if not await self.initialize():
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={{"error": "Failed to initialize agent"}}
                    )
            
            logger.info(f"Processing query: {{query}}")
            
{business_logic}
            
        except Exception as e:
            logger.error(f"Error in {{self.name}}.process: {{str(e)}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e), "message": "처리 중 오류가 발생했습니다"}}
            )
    
{helper_methods}
    
    async def cleanup(self):
        """Clean up resources when agent is shutting down."""
        try:
            # Clean up any resources
            if hasattr(self, 'llm_client') and self.llm_client:
                # Close any open connections
                pass
            
            logger.info(f"{{self.name}} cleanup completed")
        except Exception as e:
            logger.error(f"Error during cleanup: {{str(e)}}")


# Example usage
if __name__ == "__main__":
    async def main():
        # Create agent
        agent = {agent_name}()
        
        # Initialize
        if await agent.initialize():
            # Test query
            response = await agent.process("테스트 쿼리")
            print(f"Response: {{response}}")
            
            # Cleanup
            await agent.cleanup()
    
    # Run the example
    asyncio.run(main())
'''
        
        return code
    
    def _get_logosai_business_logic(self, agent_type: str, features: List[str]) -> str:
        """LogosAI 에이전트용 비즈니스 로직 생성"""
        
        if agent_type == "calculator":
            return '''            # Extract calculation request using LLM
            if self.llm_client:
                prompt = f"Extract the mathematical expression from: {query}"
                extraction_result = await self.llm_client.generate(prompt)
                
                # Perform calculation
                try:
                    result = eval(extraction_result)  # In production, use safer eval
                    return AgentResponse(
                        type=AgentResponseType.SUCCESS,
                        content={"result": result, "expression": extraction_result}
                    )
                except Exception as calc_error:
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={"error": str(calc_error)}
                    )
            else:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": "LLM client not initialized"}
                )'''
                
        elif agent_type == "data_analysis":
            return '''            # Data analysis logic
            try:
                # Extract data requirements using LLM
                if self.llm_client:
                    analysis_prompt = f"Analyze the data request: {query}"
                    analysis_plan = await self.llm_client.generate(analysis_prompt)
                    
                    # Perform analysis (simplified)
                    result = {
                        "analysis": analysis_plan,
                        "status": "completed",
                        "timestamp": datetime.now().isoformat()
                    }
                    
                    return AgentResponse(
                        type=AgentResponseType.SUCCESS,
                        content=result
                    )
                else:
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={"error": "LLM client not initialized"}
                    )
            except Exception as analysis_error:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": str(analysis_error)}
                )'''
                
        elif agent_type == "api_integration":
            return '''            # API integration logic
            try:
                # Extract API request details using LLM
                if self.llm_client:
                    api_prompt = f"Extract API endpoint and parameters from: {query}"
                    api_details = await self.llm_client.generate(api_prompt)
                    
                    # Make API call (simplified)
                    async with aiohttp.ClientSession() as session:
                        # This is a placeholder - real implementation would parse api_details
                        response_data = {"status": "success", "message": "API call simulated"}
                    
                    return AgentResponse(
                        type=AgentResponseType.SUCCESS,
                        content=response_data
                    )
                else:
                    return AgentResponse(
                        type=AgentResponseType.ERROR,
                        content={"error": "LLM client not initialized"}
                    )
            except Exception as api_error:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": str(api_error)}
                )'''
                
        else:
            # Default logic for other types
            return '''            # Process query using LLM
            if self.llm_client:
                # Generate response using LLM
                response_text = await self.llm_client.generate(f"Process this request: {query}")
                
                return AgentResponse(
                    type=AgentResponseType.SUCCESS,
                    content={"response": response_text, "query": query}
                )
            else:
                return AgentResponse(
                    type=AgentResponseType.ERROR,
                    content={"error": "LLM client not initialized"}
                )'''
    
    def _get_custom_config_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 커스텀 설정 생성 - 완전한 딕셔너리 반환"""
        agent_type = analysis.get('agent_type', 'general')
        config_dict = {}
        
        if agent_type == "data_analysis":
            config_dict["enable_visualization"] = True
            config_dict["max_data_rows"] = 10000
        elif agent_type == "api_integration":
            config_dict["timeout"] = 30
            config_dict["retry_count"] = 3
        elif agent_type == "web_scraping":
            config_dict["user_agent"] = "Mozilla/5.0"
            config_dict["timeout"] = 20
        
        # 항상 기본 설정 포함
        if not config_dict:
            config_dict["timeout"] = 60
            config_dict["retry_attempts"] = 3
        
        # 🔧 FIXED: 완전한 딕셔너리 반환
        import json
        return json.dumps(config_dict, ensure_ascii=False)
    
    def _get_custom_init_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 커스텀 초기화 코드"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type == "data_analysis":
            return """
        self.data_cache = {}
        self.analysis_history = []"""
        elif agent_type == "api_integration":
            return """
        self.api_cache = {}
        self.rate_limiter = None"""
        elif agent_type == "web_scraping":
            return """
        self.session = None
        self.scraped_data = []"""
        
        return """
        # Custom initialization"""
    
    def _get_custom_async_init_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 비동기 초기화 코드"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type == "api_integration":
            return """# Initialize HTTP session
            import aiohttp
            self.session = aiohttp.ClientSession()"""
        elif agent_type == "web_scraping":
            return """# Initialize web scraping session
            import aiohttp
            self.session = aiohttp.ClientSession()"""
        
        return "# Additional async initialization"
    
    def _get_query_extraction_prompt(self, analysis: Dict[str, Any]) -> str:
        """쿼리 추출 프롬프트 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        prompts = {
            "calculator": "Extract the mathematical expression and numbers from the query.",
            "data_analysis": "Extract the data source, analysis type, and filters from the query.",
            "api_integration": "Extract the API endpoint, method, parameters, and authentication details.",
            "web_scraping": "Extract the target URL, data to scrape, and any filters.",
            "automation": "Extract the task to automate, schedule, and conditions.",
            "document_processing": "Extract the document type, processing requirements, and output format.",
            "chatbot": "Extract the user intent, context, and required response type.",
            "monitoring": "Extract the metrics to monitor, thresholds, and alert conditions."
        }
        
        return prompts.get(agent_type, "Extract the key information and requirements from the query.")
    
    async def _get_logosai_core_business_logic_async(self, analysis: Dict[str, Any]) -> str:
        """🚀 Template-First Business Logic Generation with Fallback Options (Async)"""
        logger.info(f"🎯 Generating business logic with Template-First approach")
        
        # Extract query and agent type
        query = analysis.get('original_query', analysis.get('description', analysis.get('query', 'data analysis')))
        agent_type = analysis.get('agent_type', 'general')
        
        logger.info(f"Query: '{query}', AgentType: '{agent_type}'")
        
        # 🔥 PRIORITY 1: Template Matcher Service (템플릿 우선 사용)
        if self.template_matcher:
            logger.info("🎯 Attempting to use Template Matcher Service for business logic")
            try:
                # Generate complete agent code using template
                result = await self.template_matcher.generate_agent_code(query)
                
                if result and result.get('confidence', 0) > 0.3:
                    template_id = result.get('template_used')
                    confidence = result.get('confidence', 0)
                    agent_code = result.get('agent_code', '')
                    
                    logger.info(f"✅ Found matching template: {template_id} with confidence: {confidence}")
                    
                    # Extract business logic from generated agent code
                    if agent_code:
                        business_logic = self._extract_business_logic_from_template(agent_code, query, analysis)
                        if business_logic and len(business_logic) > 50:
                            logger.info(f"✅ Template-based business logic generated: {len(business_logic)} characters")
                            return business_logic
                        else:
                            # If extraction fails, try to get the BUSINESS_LOGIC section directly
                            import re
                            # Look for the BUSINESS_LOGIC replacement in the template
                            match = re.search(r'# BUSINESS_LOGIC START(.*?)# BUSINESS_LOGIC END', agent_code, re.DOTALL)
                            if not match:
                                # Look for _process_core_logic content
                                match = re.search(r'async def _process_core_logic.*?:\s*""".*?"""(.*?)(?=async def|def|\Z)', agent_code, re.DOTALL)
                            
                            if match:
                                business_logic = match.group(1).strip()
                                if business_logic and len(business_logic) > 50:
                                    logger.info(f"✅ Extracted template business logic: {len(business_logic)} characters")
                                    return business_logic
                    
                    logger.info(f"⚠️ Could not extract substantial business logic from template {template_id}")
                else:
                    logger.info(f"⚠️ No matching template found or low confidence: {result.get('confidence', 0) if result else 0}")
            except Exception as e:
                logger.error(f"❌ Template Matcher failed: {e}")
        
        # 🔥 PRIORITY 2: 특정 에이전트 타입에 대한 직접 로직 생성
        if agent_type == 'calculator':
            logger.info("🧮 Using calculator-specific logic")
            return self._get_calculator_business_logic()
        elif agent_type == 'weather':
            logger.info("🌤️ Using weather-specific logic")
            return self._get_weather_business_logic()
        
        # 🔥 PRIORITY 3: Direct LLM Generation for all other agent types
        logger.info("🤖 Using Direct LLM Generation for business logic")
        try:
            # Generate business logic directly with LLM
            business_logic = self._generate_direct_llm_business_logic(query, analysis)
            if business_logic:
                logger.info(f"✅ Direct LLM generated {len(business_logic)} characters of business logic")
                return business_logic
        except Exception as e:
            logger.error(f"❌ Direct LLM generation failed: {e}")
        
        # 🔥 PRIORITY 4: Fallback to type-specific logic if LLM fails
        logger.info(f"🔄 Using type-specific fallback for {agent_type}")
        return self._get_type_specific_business_logic(agent_type, analysis)
    
    def _get_logosai_core_business_logic(self, analysis: Dict[str, Any]) -> str:
        """🚀 Sync wrapper for async template-first business logic generation"""
        
        # Check if business logic already exists in analysis
        if 'business_logic' in analysis and analysis['business_logic']:
            logger.info(f"📦 Using pre-generated business logic from analysis: {len(analysis['business_logic'])} chars")
            return analysis['business_logic']
        
        try:
            # Check if we're already in an async context
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # We're already in an async context, create a task
                logger.info("📡 Already in async context, creating task for template matching")
                future = asyncio.ensure_future(self._get_logosai_core_business_logic_async(analysis))
                # Run the event loop until the future completes
                import concurrent.futures
                import threading
                
                result = None
                exception = None
                
                def run_in_thread():
                    nonlocal result, exception
                    try:
                        new_loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(new_loop)
                        result = new_loop.run_until_complete(self._get_logosai_core_business_logic_async(analysis))
                        new_loop.close()
                    except Exception as e:
                        exception = e
                
                thread = threading.Thread(target=run_in_thread)
                thread.start()
                thread.join(timeout=30)  # 30 second timeout
                
                if exception:
                    raise exception
                if result:
                    return result
                else:
                    logger.warning("⚠️ Template matching timed out, using fallback")
            else:
                # We're not in an async context, we can use asyncio.run
                logger.info("📡 Not in async context, using asyncio.run")
                return asyncio.run(self._get_logosai_core_business_logic_async(analysis))
        except Exception as e:
            logger.error(f"❌ Error in async business logic generation: {e}")
            
        # Fallback to synchronous logic generation
        logger.info("🔄 Falling back to synchronous business logic generation")
        query = analysis.get('original_query', analysis.get('description', analysis.get('query', 'data analysis')))
        agent_type = analysis.get('agent_type', 'general')
        
        # Try type-specific logic
        if agent_type == 'calculator':
            return self._get_calculator_business_logic()
        elif agent_type == 'weather':
            return self._get_weather_business_logic()
        
        # Default fallback
        return self._get_type_specific_business_logic(agent_type, analysis)
    
    def _extract_business_logic_from_template(self, template_content: str, query: str, analysis: Dict[str, Any]) -> str:
        """템플릿에서 비즈니스 로직을 추출하고 사용자 쿼리에 맞게 적응"""
        try:
            logger.info("📝 Extracting business logic from template")
            
            # Template에서 business logic 섹션 찾기
            # 템플릿은 일반적으로 _process_core_logic 메서드 안에 핵심 로직을 포함
            import re
            
            # _process_core_logic 메서드 찾기
            pattern = r'async def _process_core_logic\(self.*?\).*?:\s*""".*?"""(.*?)(?=async def|\Z)'
            match = re.search(pattern, template_content, re.DOTALL)
            
            if match:
                business_logic = match.group(1).strip()
                
                # 템플릿 플레이스홀더 제거
                import re
                business_logic = re.sub(r'\{\{[^}]+\|', '', business_logic)  # Remove {{PLACEHOLDER| patterns
                business_logic = re.sub(r'\|\}\}', '', business_logic)  # Remove |}} patterns
                business_logic = re.sub(r'\}\}', '', business_logic)  # Remove }} patterns
                
                # Check if the template has try/except structure
                has_try_except = 'try:' in business_logic[:100] and 'except' in business_logic
                
                if has_try_except:
                    # Extract only the content inside the try block
                    # Find the content between try: and except
                    try_match = re.search(r'try:\s*\n(.*?)(?=\n\s*except)', business_logic, re.DOTALL)
                    if try_match:
                        business_logic = try_match.group(1)
                        logger.info(f"📝 Extracted try block content: {len(business_logic)} chars")
                
                # 들여쓰기 정규화 - 상대적 들여쓰기 유지
                lines = business_logic.split('\n')
                
                # 최소 들여쓰기 찾기 (빈 줄과 주석 제외, try: 줄도 제외)
                min_indent = float('inf')
                for line in lines:
                    if line.strip() and not line.lstrip().startswith('#'):
                        # Skip try: lines that have 0 indentation
                        if line.strip() == 'try:' and len(line) - len(line.lstrip()) == 0:
                            continue
                        indent = len(line) - len(line.lstrip())
                        if indent < min_indent and indent > 0:  # Only consider lines with some indentation
                            min_indent = indent
                
                # 최소 들여쓰기가 없으면 0으로 설정
                if min_indent == float('inf'):
                    min_indent = 0
                
                # 최소 들여쓰기만큼 제거하여 상대적 들여쓰기 유지
                normalized_lines = []
                
                for line in lines:
                    if line.strip():
                        # 빈 줄이 아니면 최소 들여쓰기만큼 제거
                        if len(line) >= min_indent:
                            normalized_lines.append(line[min_indent:])
                        else:
                            normalized_lines.append(line.lstrip())
                    else:
                        # 빈 줄은 그대로 유지
                        normalized_lines.append('')
                
                business_logic = '\n'.join(normalized_lines)
                
                # Remove any remaining leading whitespace on the first line
                # (AST generator expects unindented code)
                if business_logic:
                    lines = business_logic.split('\n')
                    if lines and lines[0].strip():
                        # Remove leading spaces from first line if it has any
                        first_line = lines[0].lstrip()
                        # Check if subsequent lines need adjustment
                        if lines[0] != first_line:
                            indent_removed = len(lines[0]) - len(first_line)
                            adjusted_lines = [first_line]
                            for line in lines[1:]:
                                if line.strip():
                                    # Remove the same amount of indent from other lines
                                    if len(line) >= indent_removed and line[:indent_removed].isspace():
                                        adjusted_lines.append(line[indent_removed:])
                                    else:
                                        adjusted_lines.append(line)
                                else:
                                    adjusted_lines.append(line)
                            business_logic = '\n'.join(adjusted_lines)
                
                # 쿼리 기반 커스터마이징 (필요시 LLM 사용)
                llm_manager = getattr(self, 'llm_manager', None) or getattr(self, '_llm_manager', None)
                if llm_manager and len(business_logic) > 100:
                    try:
                        # LLM을 사용해 템플릿 로직을 쿼리에 맞게 조정
                        adaptation_prompt = f"""
Create a complete business logic implementation for this query: "{query}"
Agent type: {analysis.get('agent_type', 'general')}

Requirements:
1. Generate a complete _process_core_logic method implementation
2. Include ALL helper methods that are called (e.g., if you call self._perform_seo_research(), you must implement it)
3. Each method should have actual working code, not just "pass" or placeholder
4. Use try-except blocks for error handling
5. Return proper JSON results with success/failure status

Template reference:
```python
{business_logic[:1000]}  # 처음 1000자만
```

Return ONLY the complete Python code with all method implementations. No explanations or markdown.
"""
                        # Use the correct method name for FORGELLMManager
                        if hasattr(llm_manager, 'generate_text_sync'):
                            adapted_logic = llm_manager.generate_text_sync(adaptation_prompt)
                        elif hasattr(llm_manager, 'generate'):
                            adapted_logic = llm_manager.generate(adaptation_prompt)
                        else:
                            logger.warning("LLM Manager doesn't have generate method, using original template")
                            adapted_logic = None
                        if adapted_logic and len(adapted_logic) > 50:
                            # Remove markdown code blocks if present
                            import re
                            if '```python' in adapted_logic:
                                adapted_logic = re.sub(r'```python\s*\n?', '', adapted_logic)
                                adapted_logic = re.sub(r'\n?```', '', adapted_logic)
                            elif '```' in adapted_logic:
                                adapted_logic = re.sub(r'```\s*\n?', '', adapted_logic)
                                adapted_logic = re.sub(r'\n?```', '', adapted_logic)
                            
                            # 메서드 구현 누락 확인 및 경고
                            missing_methods = self._check_missing_method_implementations(adapted_logic)
                            if missing_methods:
                                logger.warning(f"⚠️ Missing method implementations detected: {missing_methods}")
                                # 누락된 메서드들을 위한 기본 구현 추가
                                adapted_logic = self._add_missing_method_implementations(adapted_logic, missing_methods)
                            
                            logger.info("✅ Template logic adapted with LLM")
                            return adapted_logic.strip()
                    except Exception as e:
                        logger.warning(f"⚠️ LLM adaptation failed: {e}, using original template logic")
                
                logger.info(f"✅ Extracted {len(business_logic)} characters of business logic from template")
                return business_logic
            else:
                # 전체 템플릿에서 유용한 코드 추출 시도
                logger.info("⚠️ Could not find _process_core_logic, attempting alternative extraction")
                
                # 대안: process 메서드나 다른 핵심 로직 찾기
                patterns = [
                    r'async def process\(self.*?\).*?:\s*""".*?"""(.*?)(?=async def|\Z)',
                    r'def process_data\(self.*?\).*?:\s*""".*?"""(.*?)(?=def|\Z)',
                    r'# Business Logic Start(.*?)# Business Logic End',
                ]
                
                for pattern in patterns:
                    match = re.search(pattern, template_content, re.DOTALL)
                    if match:
                        business_logic = match.group(1).strip()
                        if len(business_logic) > 50:
                            logger.info(f"✅ Alternative extraction successful: {len(business_logic)} characters")
                            return business_logic
                
                # 최후의 수단: 템플릿에서 의미있는 코드 블록 찾기
                code_blocks = re.findall(r'((?:^|\n)(?:    |\t)+.*(?:\n(?:    |\t)+.*)*)', template_content, re.MULTILINE)
                for block in code_blocks:
                    if len(block) > 200 and any(keyword in block for keyword in ['result', 'data', 'process', 'analyze']):
                        logger.info(f"✅ Found code block: {len(block)} characters")
                        return block.strip()
                
        except Exception as e:
            logger.error(f"❌ Failed to extract business logic from template: {e}")
        
        return None

    def _check_missing_method_implementations(self, code: str) -> List[str]:
        """코드에서 호출되지만 구현되지 않은 메서드들을 찾음"""
        import re
        
        # self._method_name() 형태의 호출 패턴 찾기
        method_calls = re.findall(r'self\.(_[a-zA-Z_][a-zA-Z0-9_]*)\s*\(', code)
        
        # async def _method_name 형태의 정의 패턴 찾기  
        method_definitions = re.findall(r'async def (_[a-zA-Z_][a-zA-Z0-9_]*)\s*\(', code)
        
        # 호출되지만 정의되지 않은 메서드들
        missing_methods = []
        for method_call in method_calls:
            if method_call not in method_definitions and method_call != '_process_core_logic':
                missing_methods.append(method_call)
        
        return list(set(missing_methods))  # 중복 제거

    def _add_missing_method_implementations(self, code: str, missing_methods: List[str]) -> str:
        """누락된 메서드들을 위한 기본 구현 추가"""
        if not missing_methods:
            return code
        
        additional_methods = []
        
        for method_name in missing_methods:
            # 메서드 이름을 기반으로 기본 구현 생성
            if 'seo' in method_name.lower():
                implementation = self._generate_seo_method_implementation(method_name)
            elif 'content' in method_name.lower() or 'strategy' in method_name.lower():
                implementation = self._generate_content_method_implementation(method_name)
            elif 'metadata' in method_name.lower():
                implementation = self._generate_metadata_method_implementation(method_name)
            elif 'social' in method_name.lower():
                implementation = self._generate_social_method_implementation(method_name)
            elif 'link' in method_name.lower():
                implementation = self._generate_linking_method_implementation(method_name)
            else:
                implementation = self._generate_generic_method_implementation(method_name)
            
            additional_methods.append(implementation)
        
        # 기존 코드에 메서드 구현들을 추가
        methods_code = '\n\n'.join(additional_methods)
        return code + '\n\n' + methods_code

    def _generate_seo_method_implementation(self, method_name: str) -> str:
        """SEO 관련 메서드 구현 생성"""
        return f'''    async def {method_name}(self, keywords: str, *args) -> Dict[str, Any]:
        """SEO 연구 및 분석"""
        try:
            # 키워드 분석
            keyword_list = [kw.strip() for kw in keywords.split(',') if kw.strip()]
            
            # 기본 SEO 연구 결과 생성
            seo_data = {{
                "primary_keywords": keyword_list[:3],  # 주요 키워드
                "long_tail_keywords": [f"{kw} 방법" for kw in keyword_list[:3]],  # 롱테일 키워드
                "search_volume": {{kw: f"{{kw}} 관련 검색량 예상: 높음" for kw in keyword_list[:3]}},
                "difficulty_score": {{kw: f"{{kw}} 경쟁도: 중간" for kw in keyword_list[:3]}},
                "related_topics": [f"{{kw}} 관련 주제" for kw in keyword_list[:3]],
                "seasonal_trends": "연간 트렌드 분석 필요",
                "competitor_keywords": [f"{{kw}} 경쟁사 분석" for kw in keyword_list[:3]]
            }}
            
            return {{
                "success": True,
                "data": seo_data,
                "message": f"{{len(keyword_list)}}개 키워드에 대한 SEO 연구 완료"
            }}
            
        except Exception as e:
            return {{
                "success": False,
                "error": f"SEO 연구 중 오류: {{str(e)}}"
            }}'''

    def _generate_content_method_implementation(self, method_name: str) -> str:
        """콘텐츠 전략 관련 메서드 구현 생성"""
        return f'''    async def {method_name}(self, keywords: str, *args) -> Dict[str, Any]:
        """콘텐츠 전략 개발"""
        try:
            keyword_list = [kw.strip() for kw in keywords.split(',') if kw.strip()]
            
            # 콘텐츠 전략 개발
            content_strategy = {{
                "content_pillars": [f"{{kw}} 전문성" for kw in keyword_list[:3]],
                "content_types": ["블로그 포스트", "인포그래픽", "동영상 콘텐츠", "가이드"],
                "publishing_schedule": "주 2-3회 발행",
                "target_audience": f"{{keyword_list[0] if keyword_list else '일반'}} 관심층",
                "content_calendar": {{
                    "week_1": f"{{keyword_list[0] if keyword_list else '주제'}} 기초 가이드",
                    "week_2": f"{{keyword_list[1] if len(keyword_list) > 1 else '관련'}} 심화 내용",
                    "week_3": "케이스 스터디 및 사례 분석",
                    "week_4": "트렌드 및 업데이트 정보"
                }},
                "engagement_tactics": ["질문 유도", "댓글 상호작용", "소셜 미디어 연동"]
            }}
            
            return {{
                "success": True,
                "data": content_strategy,
                "message": "콘텐츠 전략 개발 완료"
            }}
            
        except Exception as e:
            return {{
                "success": False,
                "error": f"콘텐츠 전략 개발 중 오류: {{str(e)}}"
            }}'''

    def _generate_metadata_method_implementation(self, method_name: str) -> str:
        """메타데이터 관련 메서드 구현 생성"""
        return f'''    async def {method_name}(self, keywords: str, *args) -> Dict[str, Any]:
        """메타데이터 생성"""
        try:
            keyword_list = [kw.strip() for kw in keywords.split(',') if kw.strip()]
            primary_keyword = keyword_list[0] if keyword_list else "키워드"
            
            # 메타데이터 생성
            metadata = {{
                "title": f"{{primary_keyword}} 완벽 가이드 | 전문가 분석 2024",
                "meta_description": f"{{primary_keyword}}에 대한 완벽한 가이드입니다. 전문가 분석과 실무 팁을 통해 {{primary_keyword}} 마스터하기.",
                "keywords": ", ".join(keyword_list),
                "og_title": f"{{primary_keyword}} 전문가 가이드",
                "og_description": f"{{primary_keyword}} 관련 최신 정보와 전문가 팁을 확인하세요.",
                "og_image": f"/images/{{primary_keyword.lower().replace(' ', '-')}}-guide.jpg",
                "twitter_title": f"{{primary_keyword}} 완벽 분석",
                "twitter_description": f"{{primary_keyword}} 전문가 분석과 실무 가이드",
                "canonical_url": f"/blog/{{primary_keyword.lower().replace(' ', '-')}}-guide",
                "schema_markup": {{
                    "@type": "Article",
                    "headline": f"{{primary_keyword}} 완벽 가이드",
                    "author": "전문가팀",
                    "datePublished": "2024-01-01",
                    "keywords": keyword_list
                }}
            }}
            
            return {{
                "success": True,
                "data": metadata,
                "message": "메타데이터 생성 완료"
            }}
            
        except Exception as e:
            return {{
                "success": False,
                "error": f"메타데이터 생성 중 오류: {{str(e)}}"
            }}'''

    def _generate_social_method_implementation(self, method_name: str) -> str:
        """소셜 미디어 관련 메서드 구현 생성"""
        return f'''    async def {method_name}(self, keywords: str, *args) -> Dict[str, Any]:
        """소셜 미디어 요약 생성"""
        try:
            keyword_list = [kw.strip() for kw in keywords.split(',') if kw.strip()]
            primary_keyword = keyword_list[0] if keyword_list else "키워드"
            
            # 소셜 미디어 콘텐츠 생성
            social_content = {{
                "facebook_post": {{
                    "text": f"🔥 {{primary_keyword}} 완벽 가이드가 업데이트되었습니다!\\n\\n✅ 핵심 포인트\\n✅ 실무 팁\\n✅ 최신 트렌드\\n\\n지금 확인해보세요! 👇",
                    "hashtags": ["#" + kw.replace(" ", "") for kw in keyword_list[:5]]
                }},
                "twitter_post": {{
                    "text": f"🚀 {{primary_keyword}} 마스터하기\\n\\n📚 완벽한 가이드\\n💡 전문가 팁\\n📈 최신 트렌드\\n\\n#{{primary_keyword.replace(' ', '')}}",
                    "hashtags": ["#" + kw.replace(" ", "") for kw in keyword_list[:3]]
                }},
                "linkedin_post": {{
                    "text": f"전문가가 정리한 {{primary_keyword}} 완벽 가이드를 공유합니다.\\n\\n주요 내용:\\n• 기본 개념 정리\\n• 실무 적용 방법\\n• 트렌드 분석\\n\\n업계 전문가들의 인사이트를 확인해보세요.",
                    "hashtags": ["#" + kw.replace(" ", "") for kw in keyword_list[:3]]
                }},
                "instagram_post": {{
                    "caption": f"📖 {{primary_keyword}} 완벽 정리! \\n\\n✨ 핵심만 쏙쏙\\n💪 바로 적용 가능\\n🎯 결과 보장\\n\\n스토리에서 더 많은 팁 확인! 👆",
                    "hashtags": ["#" + kw.replace(" ", "") for kw in keyword_list[:8]]
                }}
            }}
            
            return {{
                "success": True,
                "data": social_content,
                "message": "소셜 미디어 콘텐츠 생성 완료"
            }}
            
        except Exception as e:
            return {{
                "success": False,
                "error": f"소셜 미디어 콘텐츠 생성 중 오류: {{str(e)}}"
            }}'''

    def _generate_linking_method_implementation(self, method_name: str) -> str:
        """내부 링크 최적화 관련 메서드 구현 생성"""
        return f'''    async def {method_name}(self, keywords: str, *args) -> Dict[str, Any]:
        """내부 링크 최적화"""
        try:
            keyword_list = [kw.strip() for kw in keywords.split(',') if kw.strip()]
            
            # 내부 링크 전략 개발
            linking_strategy = {{
                "anchor_text_strategy": {{
                    kw: [f"{{kw}} 가이드", f"{{kw}} 방법", f"{{kw}} 팁"] for kw in keyword_list[:3]
                }},
                "related_pages": {{
                    kw: [
                        f"/blog/{{kw.lower().replace(' ', '-')}}-basics",
                        f"/guide/{{kw.lower().replace(' ', '-')}}-advanced",
                        f"/tips/{{kw.lower().replace(' ', '-')}}-best-practices"
                    ] for kw in keyword_list[:3]
                }},
                "link_structure": {{
                    "pillar_pages": [f"{{kw}} 종합 가이드" for kw in keyword_list[:2]],
                    "cluster_pages": [f"{{kw}} 세부 토픽" for kw in keyword_list[2:5]],
                    "supporting_pages": [f"{{kw}} 관련 리소스" for kw in keyword_list[:3]]
                }},
                "internal_link_count": {{
                    "recommended_per_page": "5-10개",
                    "main_navigation": 3,
                    "contextual_links": "3-7개",
                    "footer_links": "2-5개"
                }},
                "optimization_tips": [
                    "자연스러운 앵커 텍스트 사용",
                    "관련성 높은 페이지 간 연결",
                    "사용자 경험을 고려한 링크 배치",
                    "링크 깊이 최소화 (3클릭 이내)"
                ]
            }}
            
            return {{
                "success": True,
                "data": linking_strategy,
                "message": "내부 링크 최적화 전략 개발 완료"
            }}
            
        except Exception as e:
            return {{
                "success": False,
                "error": f"내부 링크 최적화 중 오류: {{str(e)}}"
            }}'''

    def _generate_generic_method_implementation(self, method_name: str) -> str:
        """일반적인 메서드 구현 생성"""
        return f'''    async def {method_name}(self, *args, **kwargs) -> Dict[str, Any]:
        """{{method_name}} 처리 메서드"""
        try:
            # 입력 데이터 처리
            input_data = args[0] if args else {{}}
            
            # 기본 처리 로직
            result = {{
                "method": "{method_name}",
                "input": str(input_data) if input_data else "No input provided",
                "processed": True,
                "timestamp": datetime.now().isoformat()
            }}
            
            return {{
                "success": True,
                "data": result,
                "message": f"{{method_name}} 처리 완료"
            }}
            
        except Exception as e:
            return {{
                "success": False,
                "error": f"{{method_name}} 처리 중 오류: {{str(e)}}"
            }}'''
    
    def _get_calculator_business_logic(self) -> str:
        """계산기 에이전트를 위한 비즈니스 로직"""
        return '''import re
import operator
from datetime import datetime

# 입력 파싱
query_str = str(extracted_info) if not isinstance(extracted_info, dict) else extracted_info.get('query', str(extracted_info))

# 숫자와 연산자 추출
numbers = re.findall(r'[\d.]+', query_str)
operators = re.findall(r'[+\-*/]', query_str)

# 한글 연산자 변환
korean_ops = {'더하기': '+', '빼기': '-', '곱하기': '*', '나누기': '/'}
for k, v in korean_ops.items():
    if k in query_str:
        operators.append(v)

# 계산 수행
try:
    if len(numbers) >= 2 and operators:
        num1 = float(numbers[0])
        num2 = float(numbers[1])
        op = operators[0]
        
        ops_map = {'+': operator.add, '-': operator.sub, '*': operator.mul, '/': operator.truediv}
        if op in ops_map:
            result_value = ops_map[op](num1, num2)
            
            result = {
                "status": "success",
                "calculation": f"{num1} {op} {num2} = {result_value}",
                "result": result_value,
                "expression": f"{num1} {op} {num2}",
                "timestamp": datetime.now().isoformat()
            }
        else:
            result = {"status": "error", "message": f"Unknown operator: {op}"}
    else:
        # 간단한 계산 시도
        if "더하기" in query_str or "+" in query_str:
            if len(numbers) >= 2:
                result_value = float(numbers[0]) + float(numbers[1])
                result = {
                    "status": "success",
                    "result": result_value,
                    "calculation": f"{numbers[0]} + {numbers[1]} = {result_value}",
                    "timestamp": datetime.now().isoformat()
                }
            else:
                result = {"status": "error", "message": "Not enough numbers for calculation"}
        else:
            result = {"status": "error", "message": "Could not parse expression"}
except Exception as calc_error:
    result = {"status": "error", "message": f"Calculation error: {str(calc_error)}"}

logger.info(f"✅ Calculator result: {result}")
return result'''
    
    def _get_weather_business_logic(self) -> str:
        """날씨 에이전트를 위한 비즈니스 로직"""
        return '''# 날씨 정보 핵심 로직
import random
from datetime import datetime

# 입력 파싱
query_str = str(extracted_info) if not isinstance(extracted_info, dict) else extracted_info.get('query', str(extracted_info))

# 도시 추출
cities = ['서울', '부산', '대구', '인천', '광주', '대전', 'Seoul', 'Busan']
city = '서울'  # 기본값
for c in cities:
    if c in query_str:
        city = c
        break

# 모의 날씨 데이터 생성 (실제로는 API 호출)
weather_conditions = ['맑음', '구름 조금', '흐림', '비', '눈']
temperature = random.randint(-5, 35)
humidity = random.randint(30, 90)
condition = random.choice(weather_conditions)

result = {
    "status": "success",
    "city": city,
    "weather": {
        "temperature": f"{temperature}°C",
        "condition": condition,
        "humidity": f"{humidity}%",
        "wind_speed": f"{random.randint(0, 20)}m/s"
    },
    "forecast": "날씨가 점차 개선될 예정입니다",
    "timestamp": datetime.now().isoformat()
}

logger.info(f"✅ Weather info for {city}: {result}")
return result'''
    
    def _get_type_specific_business_logic(self, agent_type: str, analysis: Dict[str, Any]) -> str:
        """에이전트 타입별 기본 비즈니스 로직 생성"""
        
        # 타입별 특화 로직
        type_specific_logic = {
            'data_analysis': self._get_data_analysis_business_logic(),
            'api_integration': self._get_api_integration_business_logic(),
            'automation': self._get_automation_business_logic(),
        }
        
        if agent_type in type_specific_logic:
            return type_specific_logic[agent_type]
        
        # 기본 로직
        return '''# 기본 처리 로직
                data = extracted_info if isinstance(extracted_info, dict) else {"input": str(extracted_info)}
                
                result = {
                    "status": "success",
                    "data": data,
                    "message": "Processing completed",
                    "timestamp": datetime.now().isoformat(),
                    "agent_type": "''' + agent_type + '''"
                }
                
                logger.info("✅ Processing completed")
                return result'''
    
    def _get_data_analysis_business_logic(self) -> str:
        """데이터 분석 에이전트를 위한 비즈니스 로직"""
        return '''# 데이터 분석 핵심 로직
                import json
                
                data = extracted_info if isinstance(extracted_info, dict) else {"input": str(extracted_info)}
                
                # 분석 수행 (예시)
                analysis_results = {
                    "data_points": len(str(data)),
                    "data_type": type(data).__name__,
                    "summary": "Data analysis completed"
                }
                
                result = {
                    "status": "success",
                    "analysis": analysis_results,
                    "data": data,
                    "timestamp": datetime.now().isoformat()
                }
                
                return result'''
    
    def _get_api_integration_business_logic(self) -> str:
        """API 통합 에이전트를 위한 비즈니스 로직"""
        return '''# API 통합 핵심 로직
                data = extracted_info if isinstance(extracted_info, dict) else {"query": str(extracted_info)}
                
                # API 호출 시뮬레이션
                api_response = {
                    "endpoint": "simulated_api",
                    "method": "GET",
                    "status_code": 200,
                    "response": {"message": "API call simulated"}
                }
                
                result = {
                    "status": "success",
                    "api_response": api_response,
                    "original_data": data,
                    "timestamp": datetime.now().isoformat()
                }
                
                return result'''
    
    def _get_automation_business_logic(self) -> str:
        """자동화 에이전트를 위한 비즈니스 로직"""
        return '''# 자동화 핵심 로직
                data = extracted_info if isinstance(extracted_info, dict) else {"task": str(extracted_info)}
                
                # 자동화 작업 시뮬레이션
                automation_result = {
                    "task_id": "auto_" + str(hash(str(data)))[:8],
                    "status": "completed",
                    "steps_executed": 3,
                    "time_saved": "2 hours"
                }
                
                result = {
                    "status": "success",
                    "automation": automation_result,
                    "original_request": data,
                    "timestamp": datetime.now().isoformat()
                }
                
                return result'''
    
    def _should_use_pattern_system_for_business_logic(self, query: str, agent_type: str) -> bool:
        """🧠 LLM 기반 지능적 패턴 시스템 사용 여부 결정"""
        
        try:
            # 🧠 NEW: LLM 기반 패턴 매칭 시스템 사용
            from .llm_pattern_matcher import get_llm_pattern_matcher
            
            # LLM 클라이언트 가져오기 (사용 가능한 경우)
            llm_client = None
            try:
                if hasattr(self, 'llm_client'):
                    llm_client = self.llm_client
                elif hasattr(self, '_llm_manager'):
                    llm_client = self._llm_manager
                else:
                    # core.llm_manager에서 가져오기 시도
                    from .llm_manager import FORGELLMManager
                    llm_client = FORGELLMManager()
            except Exception as e:
                logger.warning(f"LLM client 초기화 실패: {e}")
            
            # LLM 패턴 매칭 수행
            pattern_matcher = get_llm_pattern_matcher(llm_client)
            
            # 비동기 호출이므로 동기적으로 실행
            import asyncio
            
            # 🚀 EMERGENCY FIX: 타이밍 문제 해결을 위해 fallback 우선 사용
            logger.warning("🔄 비동기 타이밍 문제로 인해 개선된 fallback 사용")
            should_use, analysis = pattern_matcher._fallback_pattern_matching(query, agent_type)
                
            # 결과 로깅
            logger.info(f"🧠 LLM 패턴 매칭 결과: {should_use}")
            logger.info(f"🎯 감지된 도메인: {analysis.get('detected_domain', 'unknown')}")
            logger.info(f"🔍 복잡도: {analysis.get('complexity', 'unknown')}")
            logger.info(f"💡 판단 근거: {analysis.get('reasoning', 'N/A')}")
            
            return should_use
            
        except Exception as e:
            logger.error(f"❌ LLM 패턴 매칭 실패: {e}")
            logger.info("🔄 하드코딩된 fallback 사용")
            
            # 🔄 FALLBACK: 개선된 키워드 기반 판단
            return self._legacy_keyword_pattern_matching(query, agent_type)
    
    def _legacy_keyword_pattern_matching(self, query: str, agent_type: str) -> bool:
        """🔄 개선된 키워드 기반 패턴 매칭 (LLM 실패시 fallback)"""
        
        # 환경 변수 확인
        if os.getenv('FORGE_ENABLE_PATTERNS', 'true').lower() == 'false':
            logger.info("🔧 Pattern system DISABLED by environment variable")
            return False
        
        # 패턴 친화적인 에이전트 타입
        pattern_friendly_types = [
            'data_analysis', 'analytics', 'business_intelligence', 
            'comprehensive', 'advanced', 'api_integration'
        ]
        
        if agent_type in pattern_friendly_types:
            logger.info(f"🎯 Agent type '{agent_type}' is pattern-friendly")
            return True
        
        # 🔧 개선된 키워드 기반 판단 (도메인별 가중치 적용)
        domain_keywords = {
            'data_analysis': ['csv', 'excel', '데이터', '분석', 'analysis', '차트', '대시보드', 'dashboard', '시각화', 'visualization'],
            'machine_learning': ['ml', 'ML', '머신러닝', 'machine learning', 'automl', 'AutoML', '알고리즘', 'algorithm', '모델', 'model', '하이퍼파라미터', 'hyperparameter', '튜닝', 'tuning', '성능', 'performance', '평가', 'evaluation'],
            'financial': ['금융', 'financial', '포트폴리오', 'portfolio', '투자', 'investment', '리스크', 'risk', '거래', 'trading'],
            'business': ['고객', 'customer', '위험', 'risk', '품질', 'quality', '상관관계', 'correlation', '트렌드', 'trend', '세그멘테이션', 'segmentation']
        }
        
        query_lower = query.lower()
        domain_scores = {}
        
        # 도메인별 점수 계산
        for domain, keywords in domain_keywords.items():
            matches = sum(1 for keyword in keywords if keyword in query_lower)
            domain_scores[domain] = matches
        
        total_matches = sum(domain_scores.values())
        best_domain = max(domain_scores.items(), key=lambda x: x[1]) if domain_scores else ('general', 0)
        
        should_use = total_matches >= 1  # 1개 이상 매칭
        
        logger.info(f"🔍 Legacy 키워드 분석: {total_matches} matches, 최고 도메인: {best_domain[0]} ({best_domain[1]} matches)")
        logger.info(f"🎯 패턴 시스템 사용 결정: {'USE' if should_use else 'SKIP'}")
        
        return should_use
    
    def _generate_business_logic_with_patterns(self, analysis: Dict[str, Any], query: str) -> str:
        """Wrapper method to generate business logic using pattern system"""
        return self._generate_pattern_based_business_logic(query, analysis)
    
    def _generate_direct_llm_business_logic(self, query: str, analysis: Dict[str, Any]) -> str:
        """🤖 Direct LLM Generation for Business Logic (No Pattern System)"""
        try:
            import google.generativeai as genai
            from datetime import datetime
            import os
            
            # Get API key from environment
            gemini_api_key = os.getenv('GEMINI_API_KEY', os.getenv('GOOGLE_API_KEY', ''))
            if not gemini_api_key:
                logger.error("❌ No Gemini API key found in environment")
                return None
            
            # Configure Gemini with lite model as requested by user
            genai.configure(api_key=gemini_api_key)
            model = genai.GenerativeModel('gemini-2.5-flash-lite')
            
            # Extract features from query for better generation
            features = analysis.get('features', [])
            agent_type = analysis.get('agent_type', 'general')
            
            # Create comprehensive prompt for direct business logic generation
            prompt = f"""You are an expert Python developer creating business logic for a LogosAI agent.

Query: {query}
Agent Type: {agent_type}
Features Required: {', '.join(features) if features else 'Based on query'}

Generate COMPLETE Python business logic code that:
1. Directly implements ALL features mentioned in the query
2. Uses real Python libraries and actual implementation (not placeholders)
3. Handles errors properly
4. Returns structured results

IMPORTANT:
- For computer vision: Use actual CV libraries (cv2, PIL, etc.) and implement object detection, face recognition, OCR, etc.
- For real estate: Implement actual web scraping, data analysis, ROI calculation, prediction models
- For data analysis: Use pandas, numpy, sklearn for actual analysis
- For API integration: Implement actual HTTP requests and response handling

CRITICAL RULES - FOLLOW EXACTLY:
- NEVER define nested functions or helper methods using 'def' or 'async def' inside the code
- NO 'def helper_function():', 'def _validate():', 'def _calculate():', etc.
- All logic must be implemented INLINE - no nested function definitions
- If you need helper logic, use lambda expressions or direct code
- Use EXACTLY 4 spaces per indentation level

Generate ONLY the Python code that goes inside the _process_core_logic method.
The code should:
- Start with necessary imports (but these will be at module level)
- Process the 'extracted_info' parameter
- Return a dictionary with results
- Include actual implementation, not stub methods
- NO nested def statements!

Example structure:
```python
# Process the input
data = extracted_info if isinstance(extracted_info, dict) else {{'query': str(extracted_info)}}

# Actual implementation here - ALL INLINE, NO NESTED FUNCTIONS
# ... real code that does the work ...

# Return results
result = {{
    'status': 'success',
    'data': processed_data,
    # ... other relevant fields
}}
return result
```

Now generate the complete business logic code (remember: NO nested 'def' statements):"""

            # Call Gemini for generation
            response = model.generate_content(prompt)
            generated_code = response.text
            
            # Clean up the generated code
            if '```python' in generated_code:
                # Extract code block
                start = generated_code.find('```python') + 9
                end = generated_code.find('```', start)
                if end > start:
                    generated_code = generated_code[start:end].strip()
            elif '```' in generated_code:
                # Extract any code block
                start = generated_code.find('```') + 3
                end = generated_code.find('```', start)
                if end > start:
                    generated_code = generated_code[start:end].strip()
            
            # IMPORTANT: AST generator expects unindented code
            # Just clean up but don't add indentation - AST generator will handle it
            lines = generated_code.split('\n')
            cleaned_lines = []
            
            for line in lines:
                # Remove any leading spaces/tabs but preserve relative indentation
                if line.strip():
                    # Find the minimum indentation across all lines
                    cleaned_lines.append(line)
                else:
                    cleaned_lines.append('')
            
            # Remove common leading whitespace from all lines
            # This preserves relative indentation but removes unnecessary leading spaces
            import textwrap
            final_code = textwrap.dedent('\n'.join(cleaned_lines))
            
            # Debug: Save the generated code to see what we're getting
            debug_file = f"/tmp/direct_llm_debug_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
            with open(debug_file, 'w') as f:
                f.write(final_code)
            logger.info(f"📝 Debug: Saved raw LLM output to {debug_file}")
            
            logger.info(f"✅ Direct LLM generated {len(final_code)} characters of business logic")
            return final_code
            
        except Exception as e:
            logger.error(f"❌ Direct LLM generation error: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _generate_pattern_based_business_logic(self, query: str, analysis: Dict[str, Any]) -> str:
        """🧠 LLM 기반 지능형 패턴 시스템으로 비즈니스 로직 생성"""
        try:
            # 🔗 패턴 시스템 경로 설정
            import sys
            from pathlib import Path
            
            patterns_root = Path(__file__).parent.parent / "business_patterns_implementation"
            if str(patterns_root) not in sys.path:
                sys.path.insert(0, str(patterns_root))
            
            # 🧠 새로운 지능형 패턴 시스템 import
            from intelligent_pattern_system import IntelligentPatternSystem
            
            logger.info("🧠 Using Intelligent Pattern System (LLM-based)")
            
            # 🎯 Phase 1: LLM 기반 패턴 분석 및 선택
            intelligent_system = IntelligentPatternSystem()
            agent_type = analysis.get('agent_type', 'general')
            
            action, pattern_data = intelligent_system.analyze_and_select_pattern(query, agent_type)
            
            logger.info(f"🎯 Pattern analysis result: {action}")
            
            # 🚀 Phase 2: 선택된 액션에 따른 코드 생성
            pattern_code = intelligent_system.get_pattern_code(action, pattern_data)
            
            if not pattern_code:
                logger.error("❌ Failed to generate pattern code")
                return None
            
            # 🔧 Phase 3: 템플릿에 맞게 코드 조합
            combined_logic = self._wrap_intelligent_pattern_code(
                pattern_code, 
                action, 
                pattern_data.get('analysis', None)
            )
            
            if combined_logic is None:
                logger.error("❌ Failed to wrap intelligent pattern code")
                return None
            
            logger.info(f"✅ Generated intelligent pattern-based business logic: {len(combined_logic)} characters")
            
            # 분석 정보 추출 (PatternAnalysis 객체에서 직접 속성 접근)
            analysis = pattern_data.get('analysis')
            domain = analysis.business_domain if analysis else 'general'
            logger.info(f"📊 Pattern type: {action}, Domain: {domain}")
            
            return combined_logic
            
        except Exception as e:
            logger.error(f"❌ Intelligent pattern-based business logic generation failed: {e}")
            import traceback
            logger.error(f"❌ Full traceback: {traceback.format_exc()}")
            return None
    
    def _normalize_business_logic_indentation(self, code: str) -> str:
        """비즈니스 로직의 들여쓰기를 정규화 - 완전 재설정 방식"""
        if not code or not code.strip():
            return code
        
        # Try to use the comprehensive fix function
        try:
            from fix_forge_indentation import fix_indentation_comprehensive
            return fix_indentation_comprehensive(code, base_indent=16)
        except ImportError:
            pass
            
        lines = code.split('\n')
        normalized_lines = []
        base_indent = 16  # try 블록 내부 기본 들여쓰기 (12 -> 16으로 변경)
        current_indent_level = 0
        
        control_keywords = [
            'if ', 'elif ', 'else:', 'for ', 'while ', 
            'try:', 'except', 'finally:', 'with ', 'def ', 'class '
        ]
        
        for line in lines:
            stripped = line.strip()
            
            if not stripped:
                normalized_lines.append('')
                continue
            
            # Handle block-closing keywords
            if any(stripped.startswith(kw) for kw in ['else:', 'elif ', 'except', 'finally:']):
                current_indent_level = max(0, current_indent_level - 1)
            
            # Apply indentation
            indent_spaces = base_indent + (current_indent_level * 4)
            normalized_lines.append(' ' * indent_spaces + stripped)
            
            # Check if line opens new block
            if stripped.endswith(':') and any(stripped.startswith(kw) for kw in control_keywords):
                current_indent_level += 1
            
            # Decrease indent after return
            if stripped.startswith('return '):
                current_indent_level = max(0, current_indent_level - 1)
        
        return '\n'.join(normalized_lines)
    
    def _validate_business_logic_syntax(self, code: str) -> bool:
        """비즈니스 로직의 문법을 검증 - 강화된 버전"""
        try:
            # 임시로 함수로 감싸서 검증
            test_code = f"""
def test_function():
    try:
{code}
    except Exception:
        pass
"""
            compile(test_code, '<string>', 'exec')
            return True
        except SyntaxError as e:
            logger.warning(f"❌ Business logic syntax error: {e}")
            
            # 들여쓰기 관련 에러인지 확인
            if "IndentationError" in str(type(e)) or "unindent" in str(e).lower():
                logger.error(f"🔍 Indentation error detected at line {e.lineno}: {e.text}")
                
                # 코드의 각 줄 들여쓰기 분석
                lines = code.split('\n')
                logger.error("📊 Code indentation analysis:")
                for i, line in enumerate(lines[:10], 1):  # 처음 10줄만 분석
                    if line.strip():
                        indent = len(line) - len(line.lstrip())
                        logger.error(f"   Line {i}: {indent} spaces - '{line[:50]}...'")
                        
            return False
        except Exception as e:
            logger.error(f"❌ Unexpected validation error: {e}")
            return False
    
    def _fix_business_logic_syntax(self, code: str) -> str:
        """비즈니스 로직의 문법 오류 수정 시도 - 강화된 버전"""
        logger.info("🔧 Attempting to fix business logic syntax...")
        
        try:
            lines = code.split('\n')
            fixed_lines = []
            base_indent = 12  # try 블록 내부 기본 들여쓰기
            
            # Analysis phase: understand the structure
            content_lines = [(i, line) for i, line in enumerate(lines) if line.strip()]
            if not content_lines:
                return code
                
            logger.info(f"📊 Analyzing {len(content_lines)} content lines for syntax issues")
            
            # Check for common indentation patterns
            indents = [len(line) - len(line.lstrip()) for _, line in content_lines]
            unique_indents = sorted(set(indents))
            logger.info(f"   Unique indentations found: {unique_indents}")
            
            # Strategy 1: Smart normalization with context awareness
            for i, line in enumerate(lines):
                line_no = i + 1
                if not line.strip():
                    fixed_lines.append(line)
                    continue
                
                original_indent = len(line) - len(line.lstrip())
                stripped = line.strip()
                
                # Debugging info for first few lines
                if i < 5:
                    logger.info(f"   Line {line_no}: {original_indent} spaces - '{stripped[:50]}...'")
                
                # Apply intelligent fixes based on content type
                if stripped.startswith(('import ', 'from ')):
                    # Imports get base indentation
                    fixed_lines.append(' ' * base_indent + stripped)
                elif stripped.startswith('#'):
                    # Comments get base indentation
                    fixed_lines.append(' ' * base_indent + stripped)
                elif stripped.startswith(('return ', 'break', 'continue', 'pass', 'raise')):
                    # Control flow statements get base indentation
                    fixed_lines.append(' ' * base_indent + stripped)
                elif any(stripped.startswith(op) for op in ['if ', 'elif ', 'else:', 'for ', 'while ', 'try:', 'except', 'finally:', 'with ']):
                    # Control structures get base indentation
                    fixed_lines.append(' ' * base_indent + stripped)
                elif stripped.endswith(':') and not stripped.startswith(('"', "'")):
                    # Likely a dictionary key or function definition
                    fixed_lines.append(' ' * (base_indent + 4) + stripped)
                elif any(stripped.startswith(char) for char in ['"', "'", '}', ']', ')']):
                    # String literals, closing brackets
                    if stripped in ['}', ']', ')']:
                        fixed_lines.append(' ' * base_indent + stripped)
                    else:
                        fixed_lines.append(' ' * (base_indent + 4) + stripped)
                else:
                    # Regular statements - apply comprehensive indentation fix
                    if original_indent > 24:  # Extremely excessive
                        logger.warning(f"🔧 Line {line_no}: Extreme indentation {original_indent} → {base_indent}")
                        fixed_lines.append(' ' * base_indent + stripped)
                    elif original_indent > 20:  # Very excessive
                        logger.warning(f"🔧 Line {line_no}: High indentation {original_indent} → {base_indent}")
                        fixed_lines.append(' ' * base_indent + stripped)
                    elif original_indent == 0:  # No indentation
                        logger.info(f"   Line {line_no}: Adding base indentation 0 → {base_indent}")
                        fixed_lines.append(' ' * base_indent + stripped)
                    elif original_indent < base_indent:  # Too little
                        logger.info(f"   Line {line_no}: Increasing indentation {original_indent} → {base_indent}")
                        fixed_lines.append(' ' * base_indent + stripped)
                    else:
                        # Cap at reasonable maximum
                        final_indent = min(original_indent, 18)
                        if final_indent != original_indent:
                            logger.info(f"   Line {line_no}: Capping indentation {original_indent} → {final_indent}")
                        fixed_lines.append(' ' * final_indent + stripped)
            
            fixed_code = '\n'.join(fixed_lines)
            
            logger.info("🧪 Testing Strategy 1 (Smart normalization)...")
            if self._validate_business_logic_syntax(fixed_code):
                logger.info("✅ Strategy 1 successful - Business logic syntax fixed")
                return fixed_code
            
            # Strategy 2: Emergency uniform normalization
            logger.warning("⚠️ Strategy 1 failed, applying Strategy 2 (Emergency uniform normalization)...")
            emergency_lines = []
            for line in lines:
                if line.strip():
                    # Everything gets base_indent for maximum compatibility
                    emergency_lines.append(' ' * base_indent + line.strip())
                else:
                    emergency_lines.append(line)
                    
            emergency_code = '\n'.join(emergency_lines)
            
            logger.info("🧪 Testing Strategy 2 (Emergency normalization)...")
            if self._validate_business_logic_syntax(emergency_code):
                logger.info("✅ Strategy 2 successful - Emergency normalization worked")
                return emergency_code
            
            # Strategy 3: Minimal fallback
            logger.warning("⚠️ Strategy 2 failed, applying Strategy 3 (Minimal fallback)...")
            minimal_lines = []
            for line in lines:
                if line.strip():
                    minimal_lines.append(' ' * base_indent + line.strip())
                else:
                    minimal_lines.append('')  # Clean empty lines
                    
            minimal_code = '\n'.join(minimal_lines)
            
            if self._validate_business_logic_syntax(minimal_code):
                logger.info("✅ Strategy 3 successful - Minimal fallback worked")
                return minimal_code
            else:
                logger.error("❌ All 3 fix strategies failed")
                return None
                
        except Exception as e:
            logger.error(f"❌ Error in syntax fix attempt: {e}")
            import traceback
            logger.error(f"Full traceback: {traceback.format_exc()}")
            return None
    
    def _find_undefined_functions_in_logic(self, code: str) -> set:
        """비즈니스 로직에서 호출되지만 정의되지 않은 함수 찾기"""
        import ast
        import re
        
        undefined_functions = set()
        
        try:
            # 함수 호출 패턴 찾기 (함수명 뒤에 괄호가 오는 패턴)
            # self.xxx는 제외 (클래스 메서드이므로)
            function_calls = re.findall(r'\b(?<!self\.)(?<!def )([a-zA-Z_][a-zA-Z0-9_]*)\s*\(', code)
            
            # 정의된 함수 찾기
            defined_functions = re.findall(r'def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(', code)
            
            # Python 내장 함수와 일반적인 라이브러리 함수 제외
            builtin_functions = set(dir(__builtins__))
            common_functions = {
                'print', 'len', 'str', 'int', 'float', 'dict', 'list', 'tuple', 'set',
                'range', 'enumerate', 'zip', 'map', 'filter', 'sorted', 'reversed',
                'open', 'isinstance', 'hasattr', 'getattr', 'setattr', 'delattr',
                'logger', 'pd', 'np', 'json', 'datetime', 'asyncio', 'aiohttp',
                'BeautifulSoup', 'requests', 'os', 'sys', 're', 'math', 'random',
                # Logging functions
                'info', 'error', 'warning', 'debug', 'critical',
                # Datetime functions
                'now', 'today', 'isoformat', 'strftime', 'strptime',
                # Common methods
                'get', 'append', 'extend', 'update', 'items', 'keys', 'values',
                # Constants and special
                'INTEGRATION', 'PATTERN', 'CONFIG', 'STATUS', 'True', 'False', 'None'
            }
            
            # 정의되지 않은 함수 찾기
            for func_call in function_calls:
                if (func_call not in defined_functions and 
                    func_call not in builtin_functions and
                    func_call not in common_functions and
                    not func_call.startswith('_')):  # private 함수 제외
                    undefined_functions.add(func_call)
            
            # 특별히 validate_data, calculate_match_score 같은 helper 함수들 확인
            helper_function_patterns = [
                'validate_data', 'calculate_match_score', 'evaluate_experience',
                'calculate_statistics', 'detect_outliers', 'process_data',
                'analyze_trends', 'generate_report', 'check_compliance'
            ]
            
            for helper_func in helper_function_patterns:
                if helper_func in function_calls and helper_func not in defined_functions:
                    undefined_functions.add(helper_func)
            
            if undefined_functions:
                logger.warning(f"⚠️ Found undefined functions in business logic: {undefined_functions}")
            
            return undefined_functions
            
        except Exception as e:
            logger.error(f"Error finding undefined functions: {e}")
            return set()
    
    def _wrap_intelligent_pattern_code(self, pattern_code: str, action: str, analysis) -> str:
        """🧠 지능형 패턴 시스템의 코드를 LogosAI 템플릿에 맞게 래핑"""
        try:
            # 분석 정보 추출
            domain = getattr(analysis, 'business_domain', 'general') if analysis else 'general'
            complexity = getattr(analysis, 'complexity_level', 'moderate') if analysis else 'moderate'
            
            # ✅ NEW: LLM 기반 스마트 통합 호출 (사용자 요청 반영)
            logger.info(f"🧠 Attempting LLM-based smart integration for {domain}/{complexity}...")
            
            # 1단계: LLM 스마트 통합 시도
            smart_integration = self._llm_smart_integration(pattern_code, action, domain, complexity, analysis)
            
            if smart_integration:
                logger.info("✅ LLM smart integration successful!")
                return smart_integration
            else:
                logger.warning("⚠️ LLM integration failed, using enhanced fallback...")
                return self._enhanced_fallback_integration(pattern_code, action, domain, complexity)
            
        except Exception as e:
            logger.error(f"❌ Failed to wrap intelligent pattern code: {e}")
            return self._basic_fallback_integration(pattern_code, action, domain, complexity)
    
    def _llm_smart_integration(self, pattern_code: str, action: str, domain: str, complexity: str, analysis) -> str:
        """🧠 LLM이 패턴 코드를 분석하고 메서드별로 분리하여 템플릿에 통합"""
        try:
            # LLM Manager 임포트 시도
            try:
                from core.llm_manager import FORGELLMManager
                llm_manager = FORGELLMManager()
                logger.info("✅ LLM Manager loaded for smart integration")
            except Exception as e:
                logger.warning(f"⚠️ LLM Manager not available: {e}")
                return None
            
            # 사용자 쿼리 정보 추출
            user_query = getattr(analysis, 'user_query', 'Unknown request') if analysis else 'Unknown request'
            
            # LLM에게 스마트 통합 요청 (try 블록용 실행 코드만)
            integration_prompt = f"""Generate Python execution code for try block. NO def/class.

User: {user_query[:100]}
Domain: {domain}

Requirements:
- Execution code only (no function definitions)
- Use extracted_info parameter
- Return dict result

Example structure:
```
logger.info("Processing {domain}")
data = extracted_info if isinstance(extracted_info, dict) else {{"input": str(extracted_info)}}
result = {{"status": "success", "data": data, "domain": "{domain}"}}
return result
```

Generate concise code without markdown:"""
            
            # LLM에게 요청
            logger.info("🤖 Requesting smart integration from LLM...")
            
            # 동기 wrapper 사용 (LLMManager의 generate_text는 이제 async)
            if hasattr(llm_manager, 'generate_text_sync'):
                response = llm_manager.generate_text_sync(integration_prompt)
            else:
                # 폴백: 기존 방식 시도
                try:
                    import asyncio
                    response = asyncio.run(llm_manager.generate_text(integration_prompt))
                except Exception as async_error:
                    logger.warning(f"Async LLM call failed: {async_error}")
                    response = None
            
            if response and len(response.strip()) > 50:  # Reduced from 200 to 50 for simpler responses
                logger.info(f"✅ LLM generated {len(response)} chars of smart integration code")
                
                # 🧹 Clean up LLM response (remove markdown, etc.)
                cleaned_response = response.strip()
                
                # Remove markdown code blocks if present - more aggressive removal
                import re
                # Remove all variations of markdown code blocks
                cleaned_response = re.sub(r'```python\s*', '', cleaned_response)
                cleaned_response = re.sub(r'```\s*', '', cleaned_response)
                cleaned_response = re.sub(r'```', '', cleaned_response)
                
                # If there are still backticks, extract code between them
                if '```' in cleaned_response:
                    code_match = re.search(r'```\s*(.*?)```', cleaned_response, re.DOTALL)
                    if code_match:
                        cleaned_response = code_match.group(1).strip()
                        
                # Final cleanup - remove any remaining backticks
                cleaned_response = cleaned_response.replace('```', '').strip()
                
                # 🔧 SMART INDENTATION - Preserve code structure
                # 코드 구조를 유지하면서 들여쓰기 정규화
                lines = cleaned_response.split('\n')
                fixed_lines = []
                base_indent = 16  # try 블록 내부 기본 들여쓰기
                current_indent_level = 0
                
                for line in lines:
                    stripped = line.strip()
                    if not stripped:
                        fixed_lines.append('')
                        continue
                    
                    # 들여쓰기 레벨 조정
                    if stripped.startswith(('except', 'elif', 'else', 'finally')):
                        # 블록 전환 키워드
                        current_indent_level = max(0, current_indent_level - 1)
                        fixed_lines.append(' ' * (base_indent + current_indent_level * 4) + stripped)
                        if stripped.endswith(':'):
                            current_indent_level += 1
                    elif stripped.endswith(':'):
                        # 새 블록 시작
                        fixed_lines.append(' ' * (base_indent + current_indent_level * 4) + stripped)
                        current_indent_level += 1
                    elif stripped.startswith(('return', 'break', 'continue', 'pass')):
                        # 제어문
                        fixed_lines.append(' ' * (base_indent + current_indent_level * 4) + stripped)
                        if stripped.startswith('return'):
                            # return 후 들여쓰기 레벨 감소
                            current_indent_level = max(0, current_indent_level - 1)
                    else:
                        # 일반 코드 라인
                        fixed_lines.append(' ' * (base_indent + current_indent_level * 4) + stripped)
                        
                        # 단일 라인에서 블록이 끝나는 경우 처리
                        if current_indent_level > 0 and not any(stripped.startswith(kw) for kw in ['if', 'for', 'while', 'with', 'try', 'def', 'class']):
                            # 다음 라인을 위해 들여쓰기 레벨 확인
                            pass
                
                cleaned_response = '\n'.join(fixed_lines)
                logger.info("✅ Applied SMART indentation (preserving code structure)")
                
                # 🔧 생성된 비즈니스 로직 들여쓰기 정규화
                cleaned_response = self._normalize_business_logic_indentation(cleaned_response)
                
                # 🧪 문법 검증
                if self._validate_business_logic_syntax(cleaned_response):
                    logger.info("✅ Business logic syntax validated")
                    return cleaned_response
                else:
                    logger.warning("⚠️ Business logic has syntax errors, attempting to fix...")
                    fixed_response = self._fix_business_logic_syntax(cleaned_response)
                    if fixed_response:
                        return fixed_response
                    return None
            else:
                logger.warning("❌ LLM response too short or empty")
                return None
                
        except Exception as e:
            logger.error(f"❌ LLM smart integration error: {e}")
            return None
    
    def _enhanced_fallback_integration(self, pattern_code: str, action: str, domain: str, complexity: str) -> str:
        """🔧 향상된 규칙 기반 통합 (LLM 실패 시)"""
        logger.info("🔧 Using enhanced rule-based integration...")
        
        # 정확한 12칸 들여쓰기로 코드 반환 - 각 줄을 개별적으로 처리
        code_lines = [
            "# ✅ ENHANCED RULE-BASED INTEGRATION (Method-Internal Version)",
            f"# Domain: {domain} | Complexity: {complexity} | Action: {action}",
            "",
            "# 메서드 내부에서 실행 가능한 스마트 통합 로직",
            "try:",
            "    logger.info('🚀 Smart enhanced execution started')",
            "    ",
            "    # 스마트 데이터 준비",
            "    if 'data' in extracted_info:",
            "        business_data = extracted_info['data']",
            "    else:",
            "        business_data = extracted_info",
            "    ",
            "    # 도메인별 스마트 분석",
            f"    if '{domain}' == 'finance':",
            "        analysis_metrics = {",
            "            'risk_score': 0.75,",
            "            'volatility': 0.23,",
            "            'confidence': 0.85",
            "        }",
            f"    elif '{domain}' == 'marketing':",
            "        analysis_metrics = {",
            "            'conversion_rate': 0.12,",
            "            'ctr': 0.05,",
            "            'engagement_score': 0.78",
            "        }",
            "    else:",
            "        analysis_metrics = {",
            "            'processing_score': 0.85,",
            "            'accuracy': 0.92",
            "        }",
            "    ",
            "    # 복잡도별 처리",
            f"    if '{complexity}' == 'high':",
            "        processing_depth = 'advanced_analytics'",
            f"    elif '{complexity}' == 'low':",
            "        processing_depth = 'basic_processing'",
            "    else:",
            "        processing_depth = 'standard_analysis'",
            "    ",
            "    # 스마트 결과 생성",
            "    smart_result = {",
            "        'processed_data': business_data,",
            "        'analysis_metrics': analysis_metrics,",
            "        'processing_method': 'enhanced_rule_based',",
            "        'processing_depth': processing_depth,",
            f"        'domain': '{domain}',",
            f"        'complexity': '{complexity}',",
            f"        'action': '{action}',",
            "        'timestamp': datetime.now().isoformat(),",
            "        'integration_version': 'v2.0_method_internal'",
            "    }",
            "    ",
            "    logger.info('✅ Smart enhanced execution completed')",
            "    result = {",
            "        'status': 'success',",
            "        'data': smart_result",
            "    }",
            "except Exception as e:",
            "    logger.error(f'❌ Enhanced execution failed: {e}')",
            "    result = {'status': 'error', 'error': str(e)}",
            "",
            "return result"
        ]
        
        # 각 줄에 정확히 12칸 들여쓰기 추가
        indented_lines = []
        for line in code_lines:
            if line.strip():  # 빈 줄이 아닌 경우
                indented_lines.append(' ' * 12 + line)
            else:  # 빈 줄
                indented_lines.append('')
        
        return '\n'.join(indented_lines)
    
    def _basic_fallback_integration(self, pattern_code: str, action: str, domain: str, complexity: str) -> str:
        """📦 기본 Fallback (최후 수단)"""
        logger.warning("📦 Using basic fallback integration (last resort)...")
        
        # 정확한 12칸 들여쓰기로 코드 반환 - 각 줄을 개별적으로 처리
        code_lines = [
            "# 📦 BASIC FALLBACK INTEGRATION (Last Resort)",
            f"# Domain: {domain} | Complexity: {complexity}",
            "",
            "from datetime import datetime",
            "import logging",
            "",
            "logger = logging.getLogger(__name__)",
            "logger.info('🔧 Executing basic fallback integration...')",
            "",
            "# 최소한의 처리",
            "basic_result = {",
            "    'status': 'basic_fallback_executed',",
            f"    'domain': '{domain}',",
            f"    'action': '{action}',",
            f"    'complexity': '{complexity}',",
            "    'timestamp': datetime.now().isoformat(),",
            "    'message': 'Basic processing completed'",
            "}",
            "",
            "logger.info('📦 Basic fallback integration completed')",
            "result = {'data': basic_result, 'status': 'success'}",
            "return result"
        ]
        
        # 각 줄에 정확히 12칸 들여쓰기 추가
        indented_lines = []
        for line in code_lines:
            if line.strip():  # 빈 줄이 아닌 경우
                indented_lines.append(' ' * 12 + line)
            else:  # 빈 줄
                indented_lines.append('')
        
        return '\n'.join(indented_lines)
    
    def _combine_pattern_codes_for_template(self, pattern_codes, context) -> str:
        """패턴 코드들을 템플릿에 맞게 조합"""
        try:
            if not pattern_codes:
                return None
            
            # 모든 패턴의 실행 로직을 결합
            execution_blocks = []
            
            for i, code in enumerate(pattern_codes):
                pattern_name = code.pattern_id
                
                # 🔧 Pattern code extraction - fix variable definition issue
                if hasattr(code, 'code_content'):
                    pattern_code = code.code_content
                elif hasattr(code, 'code'):
                    pattern_code = code.code
                else:
                    pattern_code = str(code)
                
                # Indent the pattern code properly
                indented_pattern_code = self._indent_code(pattern_code, 16)
                
                execution_block = f"""
            # 🎯 Pattern {i+1}: {pattern_name}
            try:
                logger.info("Executing {pattern_name} pattern...")
                
                # Extract data from query info
                data_source = extracted_info.get('data', {{}})
                
                # Execute pattern logic
{indented_pattern_code}
                
                # Store pattern result
                if 'pattern_results' not in locals():
                    pattern_results = {{}}
                pattern_results['{pattern_name}'] = locals().get('result', {{}})
                
                logger.info(f"✅ {pattern_name} pattern completed")
                
            except Exception as pattern_error:
                logger.error(f"❌ {pattern_name} pattern failed: {{pattern_error}}")
                if 'pattern_results' not in locals():
                    pattern_results = {{}}
                pattern_results['{pattern_name}'] = {{'error': str(pattern_error)}}
"""
                execution_blocks.append(execution_block)
            
            # 최종 결과 조합 로직
            final_logic = f"""
            # 🚀 PATTERN-BASED BUSINESS LOGIC
            import pandas as pd
            import numpy as np
            import matplotlib.pyplot as plt
            from datetime import datetime
            import json
            
            # Initialize pattern results
            pattern_results = {{}}
            final_insights = []
            visualizations = []
            
{''.join(execution_blocks)}
            
            # 🎯 Combine all pattern results (with JSON serialization fix)
            combined_results = {{
                "pattern_execution": pattern_results,
                "insights": final_insights,
                "visualizations": visualizations,
                "execution_summary": {{
                    "total_patterns": {len(pattern_codes)},
                    "successful_patterns": sum(1 for r in pattern_results.values() if 'error' not in r),
                    "timestamp": datetime.now().isoformat()
                }}
            }}
            
            # 🔧 Fix JSON serialization issues with pandas objects
            import json
            def json_serializer(obj):
                '''JSON serializer for pandas and datetime objects'''
                if hasattr(obj, 'to_dict'):
                    return obj.to_dict()
                elif hasattr(obj, 'isoformat'):
                    return obj.isoformat()
                elif hasattr(obj, 'tolist'):
                    return obj.tolist()
                elif str(type(obj)).startswith("<class 'pandas"):
                    return str(obj)
                else:
                    return str(obj)
            
            # Apply serialization fix to results
            try:
                # Test JSON serialization and fix if needed
                json.dumps(combined_results, default=json_serializer)
                logger.info("✅ Results are JSON serializable")
            except Exception as json_error:
                logger.warning(f"⚠️ JSON serialization issue: {{json_error}}")
                # Convert problematic objects to strings
                combined_results = json.loads(json.dumps(combined_results, default=json_serializer))
            
            # Return in expected format
            return {{"data": combined_results}}"""
            
            return final_logic
            
        except Exception as e:
            logger.error(f"❌ Failed to combine pattern codes: {e}")
            logger.error(f"🔍 Pattern codes debug: {[type(code).__name__ for code in pattern_codes]}")
            logger.error(f"🔍 First code attributes: {dir(pattern_codes[0]) if pattern_codes else 'No codes'}")
            return None
    
    def _indent_code(self, code: str, indent_spaces: int) -> str:
        """코드 들여쓰기"""
        if not code:
            return ""
        
        indent = " " * indent_spaces
        lines = code.strip().split('\n')
        indented_lines = [indent + line if line.strip() else line for line in lines]
        return '\n'.join(indented_lines)
    
    def _get_legacy_hardcoded_logic(self, agent_type: str) -> str:
        """기존 하드코딩된 로직 (폴백용)"""
        logic_templates = {
            "calculator": """# 계산 수행
            if 'expression' in extracted_info:
                try:
                    # 안전한 계산 수행 (실제로는 더 안전한 방법 사용)
                    result = eval(extracted_info['expression'])
                    return {{"data": {{"result": result, "expression": extracted_info['expression']}}}}
                except Exception as e:
                    raise ValueError(f"계산 오류: {{str(e)}}")
            else:
                raise ValueError("수식을 찾을 수 없습니다")""",
            
            "data_analysis": """# 데이터 분석 수행 (Legacy)
            import pandas as pd
            import numpy as np
            
            # 샘플 데이터 생성 또는 로드
            if 'data_source' in extracted_info:
                # 실제 데이터 로드 로직
                data = pd.DataFrame()  # Placeholder
            else:
                # 샘플 데이터 생성
                data = pd.DataFrame({{
                    'date': pd.date_range('2024-01-01', periods=100),
                    'value': np.random.randn(100).cumsum() + 100,
                    'category': np.random.choice(['A', 'B', 'C'], 100)
                }})
            
            # 분석 수행
            analysis_results = {{
                "summary": data.describe().to_dict(),
                "shape": data.shape,
                "columns": list(data.columns),
                "method": "pattern_based"
            }}
            
            return {{"data": analysis_results}}""",
            
            "api_integration": """# API 호출 수행
            api_url = extracted_info.get('url', 'https://api.example.com/data')
            method = extracted_info.get('method', 'GET')
            
            # 실제 API 호출 (샘플)
            api_response = {{
                "status": "success",
                "data": {{"sample": "response"}},
                "timestamp": datetime.now().isoformat(),
                "method": "pattern_based"
            }}
            
            return {{"data": api_response}}"""
        }
        
        return logic_templates.get(agent_type, 
            """# 범용 처리 로직 (Legacy)
            result = {{
                "processed": True,
                "info": extracted_info,
                "timestamp": datetime.now().isoformat(),
                "method": "pattern_based"
            }}
            return {{"data": result}}""")
    
    def _get_response_generation_prompt(self, analysis: Dict[str, Any]) -> str:
        """응답 생성 프롬프트 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        prompts = {
            "calculator": "Format the calculation result clearly with the expression and answer.",
            "data_analysis": "Present the analysis results with key insights and statistics.",
            "api_integration": "Format the API response data in a readable manner.",
            "web_scraping": "Present the scraped data in an organized format.",
            "automation": "Describe the automation task status and results.",
            "document_processing": "Summarize the document processing results.",
            "chatbot": "Generate a natural and helpful response to the user.",
            "monitoring": "Present the monitoring status and any alerts."
        }
        
        return prompts.get(agent_type, "Generate a clear and informative response based on the results.")
    
    def _get_test_queries_for_logosai(self, analysis: Dict[str, Any]) -> List[str]:
        """LogosAI용 테스트 쿼리 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        test_queries = {
            "calculator": ["10 더하기 20은?", "100에서 45를 빼면?", "7 곱하기 8은 얼마?"],
            "data_analysis": ["데이터 요약 보여줘", "통계 분석 수행해줘", "카테고리별 분포는?"],
            "api_integration": ["API 상태 확인", "데이터 가져오기", "POST 요청 보내기"],
            "web_scraping": ["웹페이지 데이터 수집", "제목 추출하기", "링크 목록 가져오기"],
            "automation": ["작업 자동화 시작", "스케줄 확인", "자동화 상태 보기"],
            "document_processing": ["문서 분석하기", "텍스트 추출", "요약 생성"],
            "chatbot": ["안녕하세요", "도움이 필요해요", "정보 알려줘"],
            "monitoring": ["시스템 상태 확인", "알림 설정", "메트릭 보기"]
        }
        
        return test_queries.get(agent_type, ["테스트 쿼리 1", "테스트 쿼리 2", "테스트 쿼리 3"])
    
    def _get_sample_data_code_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 샘플 데이터 코드 생성"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type == "data_analysis":
            return """# Generate sample data
    import pandas as pd
    import numpy as np
    
    sample_data = pd.DataFrame({
        'date': pd.date_range('2024-01-01', periods=100),
        'sales': np.random.randint(100, 1000, 100),
        'category': np.random.choice(['Electronics', 'Clothing', 'Food'], 100),
        'region': np.random.choice(['North', 'South', 'East', 'West'], 100)
    })"""
        
        return "# Sample data generation (if needed)"
    
    def _get_custom_cleanup_for_logosai(self, analysis: Dict[str, Any]) -> str:
        """LogosAI용 커스텀 클린업 코드"""
        agent_type = analysis.get('agent_type', 'general')
        
        if agent_type in ["api_integration", "web_scraping"]:
            return """# Close HTTP session
            if hasattr(self, 'session') and self.session:
                await self.session.close()"""
        
        return "# Custom cleanup code"
    
    def _get_logosai_helper_methods(self, agent_type: str, features: List[str]) -> str:
        """LogosAI 에이전트용 헬퍼 메서드 생성"""
        
        methods = []
        
        # Common helper method for all agents
        methods.append('''    async def _extract_query_info(self, query: str) -> Dict[str, Any]:
        """
        Use LLM to extract structured information from natural language query.
        """
        if not self.llm_client:
            return {"error": "LLM client not initialized"}
        
        try:
            prompt = f"""
            Extract key information from this query:
            Query: {query}
            
            IMPORTANT: Output ONLY a valid Python dictionary (NOT JSON format).
            Example format:
            {{'key1': 'value1', 'key2': 'value2', 'key3': ['item1', 'item2']}}
            
            Do NOT include markdown, backticks, or explanations.
            Output the dictionary directly.
            """
            
            result = await self.llm_client.generate(prompt)
            return json.loads(result) if isinstance(result, str) else result
        except Exception as e:
            logger.error(f"Failed to extract query info: {e}")
            return {"error": str(e)}''')
        
        # Add type-specific helper methods
        if agent_type == "data_analysis":
            methods.append('''    
    async def _analyze_data(self, data: Any) -> Dict[str, Any]:
        """Analyze data and return insights."""
        try:
            # Simplified data analysis
            if isinstance(data, (list, dict)):
                return {
                    "row_count": len(data) if isinstance(data, list) else 1,
                    "data_type": type(data).__name__,
                    "summary": "Data analysis completed"
                }
            return {"error": "Unsupported data type"}
        except Exception as e:
            return {"error": str(e)}''')
            
        elif agent_type == "api_integration":
            methods.append('''    
    async def _make_api_call(self, endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Make an API call with given parameters."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(endpoint, params=params) as response:
                    return await response.json()
        except Exception as e:
            logger.error(f"API call failed: {e}")
            return {"error": str(e)}''')
        
        return '\n'.join(methods)

    def _validate_imports(self, code: str) -> List[str]:
        """실제 import 문을 실행하여 런타임 에러 감지

        Returns:
            List of import error messages (empty if all imports are valid)
        """
        import_errors = []

        # import 문 추출
        import_lines = []
        for line in code.split('\n'):
            stripped = line.strip()
            if stripped.startswith('import ') or stripped.startswith('from '):
                # Skip __future__ imports (they have special handling)
                if 'from __future__' in stripped:
                    continue
                import_lines.append(stripped)

        if not import_lines:
            return []

        # 각 import 문을 개별적으로 테스트
        for import_line in import_lines:
            try:
                # import 문만 포함한 코드 실행
                exec(import_line, {'__name__': '__main__'})
            except ImportError as e:
                # 구체적인 import 에러 메시지
                error_msg = f"Import 에러: {import_line} → {str(e)}"
                import_errors.append(error_msg)
                logger.error(f"🔴 {error_msg}")
            except Exception as e:
                # 기타 에러 (이름 에러 등)
                error_msg = f"Import 실행 에러: {import_line} → {type(e).__name__}: {str(e)}"
                import_errors.append(error_msg)
                logger.error(f"🔴 {error_msg}")

        if not import_errors:
            logger.info(f"✅ All {len(import_lines)} imports validated successfully")

        return import_errors

    def _validate_undefined_variables(self, code: str) -> List[str]:
        """AST 기반 undefined 변수 검증

        Returns:
            List of undefined variable warnings (empty if no issues found)
        """
        import ast

        undefined_errors = []

        try:
            tree = ast.parse(code)
        except SyntaxError:
            # 구문 에러는 _validate_code에서 처리
            return []

        # Python 내장 이름들
        builtins = set(dir(__builtins__)) if isinstance(__builtins__, dict) else set(dir(__builtins__))
        builtins.update({
            'True', 'False', 'None', 'self', 'cls',
            'Exception', 'TypeError', 'ValueError', 'KeyError', 'IndexError',
            'AttributeError', 'RuntimeError', 'ImportError', 'NameError',
            'ZeroDivisionError', 'OverflowError', 'StopIteration',
            'print', 'len', 'range', 'str', 'int', 'float', 'bool', 'list', 'dict', 'set', 'tuple',
            'isinstance', 'hasattr', 'getattr', 'setattr', 'type', 'super',
            'sum', 'min', 'max', 'abs', 'round', 'sorted', 'reversed', 'enumerate', 'zip', 'map', 'filter',
            'open', 'input', 'format', 'repr', 'id', 'hash', 'iter', 'next',
            'any', 'all', 'ord', 'chr', 'hex', 'oct', 'bin',
            '__name__', '__main__', '__file__', '__doc__',
        })

        # 정의된 이름 수집
        defined_names = set()

        class NameCollector(ast.NodeVisitor):
            def __init__(self):
                self.scope_stack = [set()]  # 스코프 스택

            def current_scope(self):
                return self.scope_stack[-1]

            def all_defined(self):
                """모든 스코프에서 정의된 이름"""
                all_names = set()
                for scope in self.scope_stack:
                    all_names.update(scope)
                return all_names

            def visit_Import(self, node):
                for alias in node.names:
                    name = alias.asname if alias.asname else alias.name.split('.')[0]
                    self.current_scope().add(name)
                self.generic_visit(node)

            def visit_ImportFrom(self, node):
                for alias in node.names:
                    name = alias.asname if alias.asname else alias.name
                    if name != '*':
                        self.current_scope().add(name)
                self.generic_visit(node)

            def visit_ClassDef(self, node):
                self.current_scope().add(node.name)
                self.scope_stack.append(set())
                self.generic_visit(node)
                self.scope_stack.pop()

            def visit_FunctionDef(self, node):
                self.current_scope().add(node.name)
                self.scope_stack.append(set())
                # 함수 매개변수 추가
                for arg in node.args.args:
                    self.current_scope().add(arg.arg)
                if node.args.vararg:
                    self.current_scope().add(node.args.vararg.arg)
                if node.args.kwarg:
                    self.current_scope().add(node.args.kwarg.arg)
                self.generic_visit(node)
                self.scope_stack.pop()

            visit_AsyncFunctionDef = visit_FunctionDef

            def visit_For(self, node):
                if isinstance(node.target, ast.Name):
                    self.current_scope().add(node.target.id)
                elif isinstance(node.target, ast.Tuple):
                    for elt in node.target.elts:
                        if isinstance(elt, ast.Name):
                            self.current_scope().add(elt.id)
                self.generic_visit(node)

            def visit_With(self, node):
                for item in node.items:
                    if item.optional_vars:
                        if isinstance(item.optional_vars, ast.Name):
                            self.current_scope().add(item.optional_vars.id)
                self.generic_visit(node)

            def visit_ExceptHandler(self, node):
                if node.name:
                    self.current_scope().add(node.name)
                self.generic_visit(node)

            def visit_Assign(self, node):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        self.current_scope().add(target.id)
                    elif isinstance(target, ast.Tuple):
                        for elt in target.elts:
                            if isinstance(elt, ast.Name):
                                self.current_scope().add(elt.id)
                self.generic_visit(node)

            def visit_AnnAssign(self, node):
                if isinstance(node.target, ast.Name):
                    self.current_scope().add(node.target.id)
                self.generic_visit(node)

            def visit_NamedExpr(self, node):
                if isinstance(node.target, ast.Name):
                    self.current_scope().add(node.target.id)
                self.generic_visit(node)

            def visit_comprehension(self, node):
                if isinstance(node.target, ast.Name):
                    self.current_scope().add(node.target.id)
                self.generic_visit(node)

        # 이름 수집
        collector = NameCollector()
        collector.visit(tree)
        defined_names = collector.all_defined()

        # 사용된 이름 검사
        class UndefinedChecker(ast.NodeVisitor):
            def __init__(self, defined, builtins):
                self.defined = defined
                self.builtins = builtins
                self.local_scopes = [set()]  # 스코프 스택
                self.errors = []

            def enter_scope(self):
                self.local_scopes.append(set())

            def exit_scope(self):
                self.local_scopes.pop()

            def add_local(self, name):
                self.local_scopes[-1].add(name)

            def is_defined(self, name):
                # 모든 로컬 스코프 확인
                for scope in self.local_scopes:
                    if name in scope:
                        return True
                return name in self.defined or name in self.builtins

            def visit_FunctionDef(self, node):
                self.add_local(node.name)
                self.enter_scope()
                for arg in node.args.args:
                    self.add_local(arg.arg)
                if node.args.vararg:
                    self.add_local(node.args.vararg.arg)
                if node.args.kwarg:
                    self.add_local(node.args.kwarg.arg)
                self.generic_visit(node)
                self.exit_scope()

            visit_AsyncFunctionDef = visit_FunctionDef

            def visit_ClassDef(self, node):
                self.add_local(node.name)
                self.enter_scope()
                self.generic_visit(node)
                self.exit_scope()

            def visit_For(self, node):
                if isinstance(node.target, ast.Name):
                    self.add_local(node.target.id)
                elif isinstance(node.target, ast.Tuple):
                    for elt in node.target.elts:
                        if isinstance(elt, ast.Name):
                            self.add_local(elt.id)
                self.generic_visit(node)

            def visit_ExceptHandler(self, node):
                if node.name:
                    self.add_local(node.name)
                self.generic_visit(node)

            def visit_Assign(self, node):
                # 먼저 값 평가
                self.visit(node.value)
                # 그 다음 대상 정의
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        self.add_local(target.id)
                    elif isinstance(target, ast.Tuple):
                        for elt in target.elts:
                            if isinstance(elt, ast.Name):
                                self.add_local(elt.id)

            def visit_Name(self, node):
                # Load 컨텍스트만 검사 (사용되는 경우만)
                if isinstance(node.ctx, ast.Load):
                    if not self.is_defined(node.id):
                        self.errors.append(f"Undefined 변수: '{node.id}' (line {node.lineno})")

        checker = UndefinedChecker(defined_names, builtins)
        checker.visit(tree)

        if checker.errors:
            # 중복 제거
            unique_errors = list(dict.fromkeys(checker.errors))
            for error in unique_errors:
                logger.warning(f"⚠️ {error}")
            return unique_errors

        logger.info("✅ No undefined variables found")
        return []

    def _validate_code(self, code: str) -> Dict[str, Any]:
        """코드 검증 - 문법 + 실제 import 테스트"""
        try:
            lines = code.split('\n')

            # 1. 구문 검사
            try:
                compile(code, '<string>', 'exec')
            except SyntaxError as se:
                # 369번째 줄 근처 출력
                if hasattr(se, 'lineno') and se.lineno:
                    error_line = se.lineno
                    logger.error(f"🔴 Syntax error at line {error_line}")
                    
                    # 에러 줄 근처 출력 (5줄 전후)
                    start = max(0, error_line - 6)
                    end = min(len(lines), error_line + 5)
                    
                    logger.error("🔴 Code around error line:")
                    for i in range(start, end):
                        marker = " >>> " if i == error_line - 1 else "     "
                        line_content = lines[i] if i < len(lines) else "N/A"
                        # 백슬래시 문제 표시
                        if '\\' in line_content and i == error_line - 1:
                            logger.error(f"{marker}Line {i+1:3d}: {line_content[:200]} ⚠️ BACKSLASH FOUND")
                        else:
                            logger.error(f"{marker}Line {i+1:3d}: {line_content[:200]}")
                    
                    # 에러 코드를 파일로 저장 (디버깅용)
                    import tempfile
                    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                        f.write(code)
                        logger.error(f"💾 Error code saved to: {f.name}")
                
                raise
            
            # 2. 필수 요소 확인 - 상속 포함 클래스도 인식
            has_class = re.search(r'class \w+(\(.*\))?:', code)
            has_process = 'async def process' in code or 'def process' in code
            has_init = 'def __init__' in code

            errors = []
            if not has_class:
                errors.append("클래스 정의가 없습니다")
            if not has_process:
                errors.append("process 메서드가 없습니다")
            if not has_init:
                errors.append("__init__ 메서드가 없습니다")

            # 3. 실제 Import 테스트 (런타임 에러 감지)
            import_errors = self._validate_imports(code)
            if import_errors:
                errors.extend(import_errors)
                logger.warning(f"⚠️ Import validation errors: {import_errors}")

            # 4. Undefined 변수 검증 (AST 기반)
            undefined_errors = self._validate_undefined_variables(code)
            if undefined_errors:
                errors.extend(undefined_errors)
                logger.warning(f"⚠️ Undefined variable errors: {undefined_errors}")

            return {
                "valid": len(errors) == 0,
                "errors": errors
            }
            
        except SyntaxError as e:
            return {
                "valid": False,
                "errors": [f"구문 오류: {str(e)}"]
            }
    
    def _generate_metadata(self, analysis: Dict[str, Any], request: ForgeRequest) -> Dict[str, Any]:
        """✅ NEW: 스마트 이름 포함 메타데이터 생성"""
        agent_id = str(uuid.uuid4())[:8]
        
        # ✅ 스마트 이름 시스템의 정보들 포함
        metadata = {
            "agent_id": agent_id,
            "agent_name": analysis["agent_name"],              # 클래스명 (스마트 생성)
            "display_name": analysis.get("display_name", analysis["agent_name"]), # 사용자 친화적 이름
            "file_name_base": analysis.get("file_name_base", analysis["agent_name"].lower()), # 파일명 베이스
            "name_reasoning": analysis.get("name_reasoning", "Generated by system"), # 이름 선택 근거
            "agent_type": analysis["agent_type"],
            "description": analysis["description"],
            "created_at": datetime.now().isoformat(),
            "created_by": request.user_email,
            "session_id": request.session_id,
            "version": "1.0.0",
            "complexity": analysis["complexity"],
            "features": analysis["features"],
            "confidence": analysis["confidence"]
        }
        
        # ✅ 패턴 시스템 정보 추가 (있는 경우)
        if "pattern_action" in analysis:
            metadata["pattern_info"] = {
                "action": analysis["pattern_action"],
                "system": "intelligent_llm_based"
            }
        
        return metadata
    
    def _save_agent(self, code: str, metadata: Dict[str, Any]) -> str:
        """✅ NEW: 스마트 이름 기반 에이전트 파일 저장"""
        from datetime import datetime
        
        # ✅ 의미 있는 파일명 생성 (타임스탬프 포함)
        file_name_base = metadata.get('file_name_base', metadata['agent_name'].lower())
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{file_name_base}_{timestamp}.py"
        
        file_path = self.output_dir / filename
        
        logger.info(f"💾 Saving agent with smart filename: {filename}")
        logger.info(f"📝 Display name: {metadata.get('display_name', 'Unknown')}")
        logger.info(f"🤖 Class name: {metadata.get('agent_name', 'Unknown')}")
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)
        
        # ✅ 확장된 메타데이터 저장
        enhanced_metadata = metadata.copy()
        enhanced_metadata.update({
            'saved_filename': filename,
            'saved_at': datetime.now().isoformat(),
            'naming_system': 'smart_llm_based'
        })
        
        metadata_path = file_path.with_suffix('.json')
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(enhanced_metadata, f, ensure_ascii=False, indent=2)
        
        return str(file_path)
    
    async def _test_agent(self, code: str, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """에이전트 테스트"""
        try:
            # 코드 실행을 위한 네임스페이스
            namespace = {}
            exec(code, namespace)
            
            # 에이전트 클래스 찾기
            agent_class = None
            for name, obj in namespace.items():
                if isinstance(obj, type) and name == analysis["agent_name"]:
                    agent_class = obj
                    break
            
            if not agent_class:
                return {
                    "status": "error",
                    "error": "에이전트 클래스를 찾을 수 없습니다"
                }
            
            # 에이전트 인스턴스 생성
            agent = agent_class()
            
            # 간단한 테스트 실행
            test_query = "테스트 쿼리"
            result = await agent.process(test_query)
            
            return {
                "status": "success",
                "test_result": result,
                "agent_info": agent.get_info() if hasattr(agent, 'get_info') else {}
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }


# CLI 인터페이스
async def main():
    """메인 실행 함수"""
    system = FinalForgeSystem()
    
    print("\n" + "="*60)
    print("FORGE AI - 에이전트 자동 생성 시스템")
    print("="*60)
    
    # 예제 요청들
    example_requests = [
        "간단한 계산기 에이전트를 만들어줘",
        "CSV 파일을 분석하고 차트를 그리는 데이터 분석 에이전트",
        "REST API와 연동해서 데이터를 가져오는 에이전트",
        "실시간으로 웹사이트를 모니터링하는 에이전트"
    ]
    
    print("\n예제 요청:")
    for i, req in enumerate(example_requests, 1):
        print(f"{i}. {req}")
    
    # 사용자 입력 또는 예제 선택
    choice = input("\n선택 (1-4) 또는 직접 입력: ").strip()
    
    if choice.isdigit() and 1 <= int(choice) <= len(example_requests):
        query = example_requests[int(choice) - 1]
    else:
        query = choice if choice else example_requests[0]
    
    print(f"\n선택된 요청: {query}")
    print("-"*60)
    
    # 에이전트 생성
    request = ForgeRequest(
        query=query,
        enable_testing=True,
        save_to_file=True
    )
    
    result = await system.create_agent(request)
    
    # 결과 출력
    if result.success:
        print("\n✅ 에이전트 생성 성공!")
        print(f"파일: {result.file_path}")
        print(f"타입: {result.metadata['agent_type']}")
        print(f"복잡도: {result.metadata['complexity']}")
        print(f"기능: {', '.join(result.metadata['features'])}")
        
        if result.test_results and result.test_results["status"] == "success":
            print("\n✅ 테스트 통과!")
            print(f"테스트 결과: {json.dumps(result.test_results['test_result'], ensure_ascii=False, indent=2)}")
    else:
        print(f"\n❌ 에이전트 생성 실패: {result.error}")


if __name__ == "__main__":
    asyncio.run(main())