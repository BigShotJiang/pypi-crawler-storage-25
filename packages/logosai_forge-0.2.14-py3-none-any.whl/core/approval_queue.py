"""
ApprovalQueue — Human approval workflow for low-confidence improvements.

When confidence < 0.95, improvements go into the approval queue
instead of auto-deploying. Humans can approve, reject, or provide feedback.
"""

import json
import sqlite3
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path
from loguru import logger


class ApprovalQueue:
    """Manages pending improvements that need human review."""

    STATUSES = {"pending", "approved", "rejected", "expired"}

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = str(Path(__file__).parent.parent / "prototype" / "backend" / "forge_evolution.db")
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Initialize approval_queue table."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS approval_queue (
                    id TEXT PRIMARY KEY,
                    agent_id TEXT NOT NULL,
                    improvement_type TEXT NOT NULL,
                    original_code TEXT,
                    improved_code TEXT,
                    diff TEXT,
                    changes TEXT DEFAULT '[]',
                    confidence REAL DEFAULT 0.0,
                    pattern_id TEXT,
                    pattern_description TEXT,
                    test_results TEXT,
                    status TEXT DEFAULT 'pending',
                    reviewer TEXT,
                    feedback TEXT,
                    created_at TEXT NOT NULL,
                    resolved_at TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_approval_status ON approval_queue(status)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_approval_agent ON approval_queue(agent_id)
            """)
            conn.commit()
        finally:
            conn.close()

    async def enqueue(
        self,
        agent_id: str,
        improvement_type: str,
        original_code: str,
        improved_code: str,
        diff: str = "",
        changes: List[str] = None,
        confidence: float = 0.0,
        pattern_id: str = None,
        pattern_description: str = None,
        test_results: Dict = None,
    ) -> str:
        """Add an improvement to the approval queue.

        Returns:
            Approval item ID
        """
        item_id = f"approval_{uuid.uuid4().hex[:10]}"

        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                """INSERT INTO approval_queue
                   (id, agent_id, improvement_type, original_code, improved_code,
                    diff, changes, confidence, pattern_id, pattern_description,
                    test_results, status, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)""",
                (
                    item_id,
                    agent_id,
                    improvement_type,
                    original_code[:50000],
                    improved_code[:50000],
                    diff[:10000],
                    json.dumps(changes or []),
                    confidence,
                    pattern_id,
                    pattern_description,
                    json.dumps(test_results) if test_results else None,
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()
        finally:
            conn.close()

        logger.info(f"[ApprovalQueue] Enqueued {item_id} for {agent_id} (conf={confidence:.2f})")
        return item_id

    def get_queue(self, status: str = "pending", limit: int = 50) -> List[Dict]:
        """Get items from the approval queue."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                """SELECT id, agent_id, improvement_type, confidence, pattern_id,
                          pattern_description, status, created_at
                   FROM approval_queue
                   WHERE status = ?
                   ORDER BY created_at DESC LIMIT ?""",
                (status, limit),
            )
            rows = cursor.fetchall()
        finally:
            conn.close()

        return [
            {
                "id": r[0],
                "agent_id": r[1],
                "improvement_type": r[2],
                "confidence": r[3],
                "pattern_id": r[4],
                "pattern_description": r[5],
                "status": r[6],
                "created_at": r[7],
            }
            for r in rows
        ]

    def get_item(self, item_id: str) -> Optional[Dict]:
        """Get full details of an approval item."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                """SELECT id, agent_id, improvement_type, original_code, improved_code,
                          diff, changes, confidence, pattern_id, pattern_description,
                          test_results, status, reviewer, feedback, created_at, resolved_at
                   FROM approval_queue WHERE id = ?""",
                (item_id,),
            )
            r = cursor.fetchone()
        finally:
            conn.close()

        if not r:
            return None

        return {
            "id": r[0],
            "agent_id": r[1],
            "improvement_type": r[2],
            "original_code": r[3],
            "improved_code": r[4],
            "diff": r[5],
            "changes": json.loads(r[6]) if r[6] else [],
            "confidence": r[7],
            "pattern_id": r[8],
            "pattern_description": r[9],
            "test_results": json.loads(r[10]) if r[10] else None,
            "status": r[11],
            "reviewer": r[12],
            "feedback": r[13],
            "created_at": r[14],
            "resolved_at": r[15],
        }

    async def approve(self, item_id: str, reviewer: str = "system") -> Dict[str, Any]:
        """Approve an improvement → triggers registration."""
        item = self.get_item(item_id)
        if not item:
            return {"success": False, "error": "Item not found"}
        if item["status"] != "pending":
            return {"success": False, "error": f"Item is {item['status']}, not pending"}

        # Register the approved code
        from core.agent_registrar import AgentRegistrar
        registrar = AgentRegistrar()
        reg_result = await registrar.register(
            agent_code=item["improved_code"],
            agent_name=item["agent_id"],
            agent_id=item["agent_id"],
            description=f"Approved improvement ({item['improvement_type']})",
        )

        # Update status
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                """UPDATE approval_queue SET status = 'approved', reviewer = ?, resolved_at = ?
                   WHERE id = ?""",
                (reviewer, datetime.now().isoformat(), item_id),
            )
            conn.commit()
        finally:
            conn.close()

        # Mark related failures as resolved
        try:
            from core.agentic.failure_collector_agent import FailureCollectorAgent
            collector = FailureCollectorAgent()
            collector.mark_resolved(item["agent_id"], "approved_fix")
        except Exception:
            pass

        # Feedback loop: learn from approved fix
        try:
            from core.agentic.base import ForgeAgent
            fix_key = f"learned_fix:{item['improvement_type']}:{item['agent_id']}"
            ForgeAgent.remember(fix_key, {
                "improvement_type": item["improvement_type"],
                "pattern_id": item.get("pattern_id"),
                "pattern_description": item.get("pattern_description"),
                "changes": item.get("changes", []),
                "confidence": item["confidence"],
                "diff_summary": item.get("diff", "")[:500],
            }, {"source": "approved_fix", "reviewer": reviewer})
            logger.info(f"[ApprovalQueue] Learned fix pattern: {fix_key}")
        except Exception as e:
            logger.debug(f"[ApprovalQueue] Could not save fix pattern: {e}")

        logger.info(f"[ApprovalQueue] Approved {item_id} for {item['agent_id']} by {reviewer}")
        return {
            "success": True,
            "registered": reg_result.success,
            "registration_message": reg_result.message,
        }

    def reject(self, item_id: str, reviewer: str = "system", feedback: str = "") -> Dict[str, Any]:
        """Reject an improvement with feedback."""
        item = self.get_item(item_id)
        if not item:
            return {"success": False, "error": "Item not found"}
        if item["status"] != "pending":
            return {"success": False, "error": f"Item is {item['status']}, not pending"}

        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                """UPDATE approval_queue SET status = 'rejected', reviewer = ?,
                          feedback = ?, resolved_at = ?
                   WHERE id = ?""",
                (reviewer, feedback, datetime.now().isoformat(), item_id),
            )
            conn.commit()
        finally:
            conn.close()

        logger.info(f"[ApprovalQueue] Rejected {item_id} by {reviewer}: {feedback[:50]}")
        return {"success": True}

    def get_stats(self) -> Dict[str, Any]:
        """Get approval queue statistics."""
        conn = sqlite3.connect(self.db_path)
        try:
            stats = {}
            for row in conn.execute("SELECT status, COUNT(*) FROM approval_queue GROUP BY status"):
                stats[row[0]] = row[1]
            total = conn.execute("SELECT COUNT(*) FROM approval_queue").fetchone()[0]
        finally:
            conn.close()

        return {
            "total": total,
            "pending": stats.get("pending", 0),
            "approved": stats.get("approved", 0),
            "rejected": stats.get("rejected", 0),
        }
