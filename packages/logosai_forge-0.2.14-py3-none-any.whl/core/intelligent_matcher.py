"""
Intelligent Template Matcher with ML
=====================================
머신러닝 기반 지능형 템플릿 매칭 시스템
"""

import json
import pickle
import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
from collections import defaultdict
from datetime import datetime
from loguru import logger

# Scikit-learn imports (optional, with fallback)
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.naive_bayes import MultinomialNB
    from sklearn.ensemble import RandomForestClassifier
    SKLEARN_AVAILABLE = True
except ImportError:
    logger.warning("Scikit-learn not available - using fallback matching")
    SKLEARN_AVAILABLE = False


class IntelligentMatcher:
    """머신러닝 기반 지능형 템플릿 매처"""
    
    def __init__(self, template_metadata: Dict[str, Dict]):
        self.template_metadata = template_metadata
        self.model_dir = Path(__file__).parent / 'models'
        self.model_dir.mkdir(exist_ok=True)
        
        # 학습 데이터
        self.training_data = []
        self.usage_history = defaultdict(list)
        
        # ML 모델들
        self.vectorizer = None
        self.template_vectors = None
        self.classifier = None
        self.ensemble_model = None
        
        # 초기화
        self._initialize_models()
        self._load_training_data()
    
    def _initialize_models(self):
        """ML 모델 초기화"""
        if not SKLEARN_AVAILABLE:
            logger.warning("ML models not available - using rule-based matching")
            return
        
        # TF-IDF 벡터라이저
        self.vectorizer = TfidfVectorizer(
            max_features=500,
            ngram_range=(1, 3),
            stop_words=None,  # 한글과 영어 모두 처리
            analyzer='char_wb'  # 문자 단위 분석 (한글 지원)
        )
        
        # 템플릿 특징 벡터 생성
        self._create_template_vectors()
        
        # 분류기 초기화
        self.classifier = MultinomialNB()
        self.ensemble_model = RandomForestClassifier(n_estimators=100, random_state=42)
    
    def _create_template_vectors(self):
        """템플릿 특징 벡터 생성"""
        if not SKLEARN_AVAILABLE or not self.vectorizer:
            return
        
        # 각 템플릿의 텍스트 표현 생성
        template_texts = []
        self.template_ids = []
        
        for template_id, metadata in self.template_metadata.items():
            # 템플릿의 텍스트 표현 생성
            text_parts = [
                metadata.get('description', ''),
                ' '.join(metadata.get('keywords', [])),
                ' '.join(metadata.get('capabilities', [])),
                ' '.join(metadata.get('use_cases', [])),
                metadata.get('category', '')
            ]
            
            template_text = ' '.join(filter(None, text_parts))
            template_texts.append(template_text)
            self.template_ids.append(template_id)
        
        # TF-IDF 벡터 생성
        if template_texts:
            self.template_vectors = self.vectorizer.fit_transform(template_texts)
            logger.info(f"Created vectors for {len(template_texts)} templates")
    
    def _load_training_data(self):
        """학습 데이터 로드"""
        training_file = self.model_dir / 'training_data.json'
        
        if training_file.exists():
            with open(training_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.training_data = data.get('training_data', [])
                self.usage_history = defaultdict(list, data.get('usage_history', {}))
                logger.info(f"Loaded {len(self.training_data)} training examples")
    
    def save_training_data(self):
        """학습 데이터 저장"""
        training_file = self.model_dir / 'training_data.json'
        
        data = {
            'training_data': self.training_data,
            'usage_history': dict(self.usage_history),
            'updated_at': datetime.now().isoformat()
        }
        
        with open(training_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def match_with_ml(self, query: str, analysis: Dict[str, Any]) -> List[Tuple[str, float]]:
        """머신러닝 기반 매칭"""
        if not SKLEARN_AVAILABLE or self.template_vectors is None:
            return self._fallback_matching(query, analysis)
        
        try:
            # 쿼리 벡터 생성
            query_text = self._create_query_text(query, analysis)
            query_vector = self.vectorizer.transform([query_text])
            
            # 코사인 유사도 계산
            similarities = cosine_similarity(query_vector, self.template_vectors)[0]
            
            # 결과 정렬
            template_scores = [
                (self.template_ids[i], float(similarities[i]))
                for i in range(len(self.template_ids))
            ]
            
            # 사용 이력 기반 보정
            template_scores = self._adjust_with_history(template_scores, query)
            
            # 정렬하여 반환
            return sorted(template_scores, key=lambda x: x[1], reverse=True)
            
        except Exception as e:
            logger.error(f"ML matching failed: {e}")
            return self._fallback_matching(query, analysis)
    
    def _create_query_text(self, query: str, analysis: Dict[str, Any]) -> str:
        """쿼리 텍스트 표현 생성"""
        text_parts = [
            query,
            analysis.get('intent', ''),
            analysis.get('domain', ''),
            ' '.join(analysis.get('required_capabilities', [])),
            'agentic' if analysis.get('needs_agentic') else ''
        ]
        
        return ' '.join(filter(None, text_parts))
    
    def _adjust_with_history(self, scores: List[Tuple[str, float]], 
                           query: str) -> List[Tuple[str, float]]:
        """사용 이력 기반 점수 조정"""
        adjusted = []
        
        for template_id, score in scores:
            # 성공적인 사용 이력이 있으면 보너스
            history = self.usage_history.get(template_id, [])
            success_rate = self._calculate_success_rate(history)
            
            # 최근 사용 빈도
            recent_usage = self._calculate_recent_usage(history)
            
            # 조정된 점수
            adjusted_score = score * (1 + 0.1 * success_rate + 0.05 * recent_usage)
            adjusted.append((template_id, min(adjusted_score, 1.0)))
        
        return adjusted
    
    def _calculate_success_rate(self, history: List[Dict]) -> float:
        """성공률 계산"""
        if not history:
            return 0.0
        
        successful = sum(1 for h in history if h.get('success', False))
        return successful / len(history)
    
    def _calculate_recent_usage(self, history: List[Dict]) -> float:
        """최근 사용 빈도 계산"""
        if not history:
            return 0.0
        
        # 최근 10개 사용 기록
        recent = history[-10:]
        return min(len(recent) / 10, 1.0)
    
    def _fallback_matching(self, query: str, analysis: Dict[str, Any]) -> List[Tuple[str, float]]:
        """폴백 매칭 (ML 사용 불가 시)"""
        scores = []
        
        for template_id, metadata in self.template_metadata.items():
            score = self._calculate_rule_based_score(query, analysis, metadata)
            scores.append((template_id, score))
        
        return sorted(scores, key=lambda x: x[1], reverse=True)
    
    def _calculate_rule_based_score(self, query: str, analysis: Dict[str, Any], 
                                   metadata: Dict) -> float:
        """규칙 기반 점수 계산"""
        score = 0.0
        query_lower = query.lower()
        
        # 키워드 매칭
        keywords = metadata.get('keywords', [])
        keyword_matches = sum(1 for kw in keywords if kw.lower() in query_lower)
        score += min(keyword_matches * 0.1, 0.3)
        
        # 카테고리 매칭
        if analysis.get('domain') == metadata.get('category'):
            score += 0.2
        
        # 기능 매칭
        required_caps = set(analysis.get('required_capabilities', []))
        template_caps = set(metadata.get('capabilities', []))
        if required_caps:
            overlap = len(required_caps & template_caps) / len(required_caps)
            score += overlap * 0.3
        
        # 우선순위
        priority = metadata.get('priority', 5)
        score += (priority / 10) * 0.2
        
        return min(score, 1.0)
    
    def record_usage(self, template_id: str, query: str, success: bool, 
                    confidence: float):
        """사용 기록 저장"""
        record = {
            'template_id': template_id,
            'query': query[:100],  # 처음 100자만
            'success': success,
            'confidence': confidence,
            'timestamp': datetime.now().isoformat()
        }
        
        self.usage_history[template_id].append(record)
        
        # 학습 데이터 추가
        if success and confidence > 0.7:
            self.training_data.append({
                'query': query,
                'template_id': template_id,
                'confidence': confidence
            })
        
        # 주기적으로 저장
        if len(self.training_data) % 10 == 0:
            self.save_training_data()
    
    def train_classifier(self):
        """분류기 학습"""
        if not SKLEARN_AVAILABLE or not self.training_data:
            logger.warning("Cannot train classifier - no data or sklearn unavailable")
            return
        
        try:
            # 학습 데이터 준비
            X = []
            y = []
            
            for data in self.training_data:
                X.append(data['query'])
                y.append(data['template_id'])
            
            if len(set(y)) < 2:
                logger.warning("Not enough template diversity for training")
                return
            
            # TF-IDF 변환
            X_vectors = self.vectorizer.transform(X)
            
            # 분류기 학습
            self.classifier.fit(X_vectors, y)
            
            # 모델 저장
            model_file = self.model_dir / 'classifier.pkl'
            with open(model_file, 'wb') as f:
                pickle.dump(self.classifier, f)
            
            logger.info(f"Trained classifier with {len(X)} examples")
            
        except Exception as e:
            logger.error(f"Training failed: {e}")
    
    def predict_template(self, query: str) -> Optional[Tuple[str, float]]:
        """템플릿 예측"""
        if not SKLEARN_AVAILABLE or self.classifier is None:
            return None
        
        try:
            # 쿼리 벡터 생성
            query_vector = self.vectorizer.transform([query])
            
            # 예측
            prediction = self.classifier.predict(query_vector)[0]
            
            # 확률
            probabilities = self.classifier.predict_proba(query_vector)[0]
            confidence = float(max(probabilities))
            
            return prediction, confidence
            
        except Exception as e:
            logger.debug(f"Prediction failed: {e}")
            return None


class PatternLearner:
    """패턴 학습기"""
    
    def __init__(self):
        self.patterns = defaultdict(list)
        self.pattern_templates = defaultdict(set)
    
    def learn_pattern(self, query: str, template_id: str, success: bool):
        """패턴 학습"""
        # 쿼리에서 패턴 추출
        patterns = self._extract_patterns(query)
        
        for pattern in patterns:
            self.patterns[pattern].append({
                'template_id': template_id,
                'success': success,
                'timestamp': datetime.now().isoformat()
            })
            
            if success:
                self.pattern_templates[pattern].add(template_id)
    
    def _extract_patterns(self, query: str) -> List[str]:
        """쿼리에서 패턴 추출"""
        patterns = []
        
        # 동사 + 명사 패턴
        verb_noun_patterns = [
            ('만들', '에이전트'),
            ('분석', '데이터'),
            ('자동화', '작업'),
            ('모니터링', '시스템'),
            ('예측', '값'),
            ('처리', '문서')
        ]
        
        query_lower = query.lower()
        for verb, noun in verb_noun_patterns:
            if verb in query and noun in query:
                patterns.append(f"{verb}+{noun}")
        
        # 기술 스택 패턴
        tech_keywords = ['실시간', 'AI', '머신러닝', 'API', '웹', '데이터베이스']
        for tech in tech_keywords:
            if tech.lower() in query_lower:
                patterns.append(f"tech:{tech}")
        
        return patterns
    
    def suggest_template(self, query: str) -> List[str]:
        """패턴 기반 템플릿 제안"""
        patterns = self._extract_patterns(query)
        template_scores = defaultdict(float)
        
        for pattern in patterns:
            # 해당 패턴에 성공적으로 사용된 템플릿들
            for template_id in self.pattern_templates.get(pattern, []):
                template_scores[template_id] += 1.0
        
        # 정렬하여 반환
        sorted_templates = sorted(
            template_scores.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        return [tmpl for tmpl, _ in sorted_templates[:5]]


class UserPreferenceTracker:
    """사용자 선호도 추적기"""
    
    def __init__(self):
        self.preferences = defaultdict(lambda: defaultdict(float))
        self.feedback = []
    
    def track_preference(self, user_id: str, template_id: str, 
                        rating: float):
        """사용자 선호도 기록"""
        self.preferences[user_id][template_id] = (
            0.7 * self.preferences[user_id][template_id] + 
            0.3 * rating
        )
    
    def get_user_preferences(self, user_id: str) -> Dict[str, float]:
        """사용자 선호도 반환"""
        return dict(self.preferences[user_id])
    
    def record_feedback(self, user_id: str, query: str, 
                       template_id: str, feedback: str):
        """피드백 기록"""
        self.feedback.append({
            'user_id': user_id,
            'query': query,
            'template_id': template_id,
            'feedback': feedback,
            'timestamp': datetime.now().isoformat()
        })
    
    def get_personalized_recommendations(self, user_id: str, 
                                        candidates: List[str]) -> List[str]:
        """개인화된 추천"""
        user_prefs = self.preferences[user_id]
        
        # 선호도 기반 정렬
        scored_candidates = [
            (tmpl, user_prefs.get(tmpl, 0.5))
            for tmpl in candidates
        ]
        
        sorted_candidates = sorted(
            scored_candidates,
            key=lambda x: x[1],
            reverse=True
        )
        
        return [tmpl for tmpl, _ in sorted_candidates]


class TemplateEvolutionEngine:
    """템플릿 진화 엔진"""
    
    def __init__(self, template_metadata: Dict[str, Dict]):
        self.template_metadata = template_metadata
        self.evolution_history = []
        self.performance_metrics = defaultdict(lambda: {
            'usage_count': 0,
            'success_count': 0,
            'avg_confidence': 0.0,
            'last_used': None
        })
    
    def track_performance(self, template_id: str, success: bool, 
                         confidence: float):
        """템플릿 성능 추적"""
        metrics = self.performance_metrics[template_id]
        
        metrics['usage_count'] += 1
        if success:
            metrics['success_count'] += 1
        
        # 이동 평균 계산
        alpha = 0.1
        metrics['avg_confidence'] = (
            (1 - alpha) * metrics['avg_confidence'] + 
            alpha * confidence
        )
        
        metrics['last_used'] = datetime.now().isoformat()
    
    def identify_evolution_candidates(self) -> List[str]:
        """진화 후보 식별"""
        candidates = []
        
        for template_id, metrics in self.performance_metrics.items():
            # 사용률이 높지만 성공률이 낮은 템플릿
            if metrics['usage_count'] > 10:
                success_rate = metrics['success_count'] / metrics['usage_count']
                if success_rate < 0.6:
                    candidates.append(template_id)
        
        return candidates
    
    def suggest_improvements(self, template_id: str) -> Dict[str, Any]:
        """개선 제안"""
        metrics = self.performance_metrics[template_id]
        metadata = self.template_metadata.get(template_id, {})
        
        suggestions = {
            'template_id': template_id,
            'current_performance': {
                'success_rate': metrics['success_count'] / max(metrics['usage_count'], 1),
                'avg_confidence': metrics['avg_confidence']
            },
            'improvements': []
        }
        
        # 낮은 신뢰도 개선
        if metrics['avg_confidence'] < 0.5:
            suggestions['improvements'].append({
                'type': 'keywords',
                'action': 'expand',
                'reason': 'Low confidence suggests poor keyword matching'
            })
        
        # 복잡도 조정
        if metadata.get('difficulty') == 'expert' and \
           metrics['success_count'] / max(metrics['usage_count'], 1) < 0.5:
            suggestions['improvements'].append({
                'type': 'complexity',
                'action': 'simplify',
                'reason': 'High complexity with low success rate'
            })
        
        return suggestions
    
    def evolve_template(self, template_id: str, 
                       improvements: Dict[str, Any]) -> Dict[str, Any]:
        """템플릿 진화"""
        metadata = self.template_metadata.get(template_id, {}).copy()
        
        for improvement in improvements.get('improvements', []):
            if improvement['type'] == 'keywords' and improvement['action'] == 'expand':
                # 키워드 확장
                current_keywords = metadata.get('keywords', [])
                # 관련 키워드 추가 (간단한 예시)
                new_keywords = self._generate_related_keywords(current_keywords)
                metadata['keywords'] = list(set(current_keywords + new_keywords))
            
            elif improvement['type'] == 'complexity' and improvement['action'] == 'simplify':
                # 복잡도 감소
                metadata['difficulty'] = 'intermediate'
        
        # 진화 기록
        self.evolution_history.append({
            'template_id': template_id,
            'timestamp': datetime.now().isoformat(),
            'improvements': improvements,
            'new_metadata': metadata
        })
        
        return metadata
    
    def _generate_related_keywords(self, keywords: List[str]) -> List[str]:
        """관련 키워드 생성"""
        related = []
        
        # 간단한 규칙 기반 확장
        for keyword in keywords:
            if '분석' in keyword:
                related.extend(['조사', '파악', '탐색'])
            elif 'data' in keyword.lower():
                related.extend(['정보', 'information', '데이터'])
            elif '자동' in keyword:
                related.extend(['automatic', '자동화', 'automation'])
        
        return related[:5]  # 최대 5개


def create_intelligent_matching_system(template_metadata: Dict[str, Dict]) -> Dict[str, Any]:
    """지능형 매칭 시스템 생성"""
    return {
        'ml_matcher': IntelligentMatcher(template_metadata),
        'pattern_learner': PatternLearner(),
        'preference_tracker': UserPreferenceTracker(),
        'evolution_engine': TemplateEvolutionEngine(template_metadata)
    }


# 테스트
if __name__ == "__main__":
    # 샘플 메타데이터
    sample_metadata = {
        'template1': {
            'keywords': ['분석', 'data'],
            'capabilities': ['data_analysis'],
            'category': 'data',
            'priority': 8
        }
    }
    
    # 시스템 생성
    system = create_intelligent_matching_system(sample_metadata)
    
    # ML 매칭 테스트
    matcher = system['ml_matcher']
    results = matcher.match_with_ml(
        "데이터를 분석하는 에이전트",
        {'domain': 'data', 'required_capabilities': ['data_analysis']}
    )
    
    print("ML Matching Results:", results[:3])