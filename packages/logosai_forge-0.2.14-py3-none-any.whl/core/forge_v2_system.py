"""
FORGE V2 Enhanced System Integration
=====================================
V2 시스템 with 경량 검증, 자가 수정, 성능 모니터링
"""

import asyncio
import json
import os
import sys
from typing import Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from loguru import logger

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import Business Logic Generator V2 components
from .business_logic_v2 import (
    BusinessLogicGeneratorV2,
    QueryAnalyzer,
    WorkflowDesigner,
    FunctionGenerator,
    WorkflowOrchestrator,
    CodeAssembler
)

# Import Business Logic Validator
try:
    from .business_logic_validator import BusinessLogicValidator
    BUSINESS_LOGIC_VALIDATOR_AVAILABLE = True
    logger.info("✅ BusinessLogicValidator available")
except ImportError as e:
    logger.warning(f"BusinessLogicValidator not available: {e}")
    BUSINESS_LOGIC_VALIDATOR_AVAILABLE = False
    BusinessLogicValidator = None

# Import new enhancement modules
try:
    from .business_logic_v2.lightweight_validator import LightweightValidator
    from .business_logic_v2.self_healing import SelfHealingModule
    from .business_logic_v2.performance_monitor import get_monitor
    from config.system_config import get_config
    ENHANCEMENTS_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Enhancement modules not available: {e}")
    ENHANCEMENTS_AVAILABLE = False

# Import SmartAssembler components for enhanced analysis
try:
    from .next_gen.intelligent_analyzer import IntelligentAnalyzer, QueryAnalysis
    from .next_gen.smart_integration import smart_integrate
    SMART_ASSEMBLER_AVAILABLE = True
    logger.info("✅ SmartAssembler components available for enhanced analysis")
except ImportError as e:
    logger.warning(f"SmartAssembler components not available: {e}")
    SMART_ASSEMBLER_AVAILABLE = False
    IntelligentAnalyzer = None
    smart_integrate = None

# Import Self-Evolution system (Paper2 integration)
try:
    from .self_evolution import EvolutionOrchestrator, EvolutionConfig
    EVOLUTION_AVAILABLE = True
    logger.info("✅ Self-Evolution system available")
except ImportError as e:
    logger.warning(f"Self-Evolution system not available: {e}")
    EVOLUTION_AVAILABLE = False

# Import CodeFixer for auto-debugging
try:
    from .code_fixer import CodeFixer
    CODE_FIXER_AVAILABLE = True
    logger.info("✅ CodeFixer available for auto-debugging")
except ImportError as e:
    logger.warning(f"CodeFixer not available: {e}")
    CODE_FIXER_AVAILABLE = False


@dataclass
class ForgeV2Request:
    """Request for FORGE V2 system"""
    query: str
    user_email: str = "user@forge.ai"
    output_type: str = "logosai"
    enable_testing: bool = True
    save_to_file: bool = True
    agent_name: Optional[str] = None
    stream_callback: Optional[callable] = None  # 🎨 스트리밍 콜백 추가
    business_rules: Optional[list] = None  # 🎯 Explicit business rules for accurate code generation
    input_schema: Optional[Dict[str, str]] = None  # 🎯 Expected input field names and types
    test_cases: Optional[list] = None  # 🎯 Test cases for guiding function generation


@dataclass
class ForgeV2Result:
    """Result from FORGE V2 system"""
    success: bool
    agent_code: str = ""
    file_path: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    test_results: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class ForgeV2System:
    """FORGE V2 Enhanced System with validation, self-healing, and monitoring"""
    
    def __init__(self, use_smart_analyzer: bool = True, use_business_logic_validator: bool = True):
        """Initialize FORGE V2 Enhanced System
        
        Args:
            use_smart_analyzer: Use IntelligentAnalyzer from SmartAssembler for enhanced analysis
            use_business_logic_validator: Use BusinessLogicValidator for requirement validation
        """
        self.generator = BusinessLogicGeneratorV2()
        self.output_dir = Path("generated")
        self.output_dir.mkdir(exist_ok=True)
        
        # Initialize enhancement modules if available
        if ENHANCEMENTS_AVAILABLE:
            self.config = get_config()
            self.validator = LightweightValidator() if self.config.ENABLE_LIGHTWEIGHT_VALIDATION else None
            self.healer = SelfHealingModule() if self.config.ENABLE_SELF_HEALING else None
            self.monitor = get_monitor() if self.config.ENABLE_PERFORMANCE_MONITORING else None
            logger.info("FORGE V2 Enhanced System initialized with all enhancements")
        else:
            self.config = None
            self.validator = None
            self.healer = None
            self.monitor = None
            logger.info("FORGE V2 System initialized (basic mode)")
        
        # Initialize SmartAssembler components if available
        self.use_smart_analyzer = use_smart_analyzer and SMART_ASSEMBLER_AVAILABLE
        if self.use_smart_analyzer:
            try:
                from .next_gen.llm_integration import ForgeLLMManager
                self.intelligent_analyzer = IntelligentAnalyzer(ForgeLLMManager())
                logger.info("✅ IntelligentAnalyzer initialized for enhanced query analysis")
            except Exception as e:
                logger.warning(f"Failed to initialize IntelligentAnalyzer: {e}")
                self.intelligent_analyzer = None
                self.use_smart_analyzer = False
        else:
            self.intelligent_analyzer = None
        
        # Initialize BusinessLogicValidator if available
        self.use_business_logic_validator = use_business_logic_validator and BUSINESS_LOGIC_VALIDATOR_AVAILABLE
        if self.use_business_logic_validator:
            self.business_logic_validator = BusinessLogicValidator()
            logger.info("✅ BusinessLogicValidator initialized for requirement validation")
        else:
            self.business_logic_validator = None

        # Initialize CodeFixer for auto-debugging
        self.code_fixer = CodeFixer() if CODE_FIXER_AVAILABLE else None

        # Initialize Self-Evolution system (Paper2 integration)
        self.evolution_config = EvolutionConfig.from_env() if EVOLUTION_AVAILABLE else None
        if self.evolution_config and self.evolution_config.enabled:
            self.evolution = EvolutionOrchestrator(self.evolution_config)
            logger.info("✅ Self-Evolution (Paper2) initialized")
        else:
            self.evolution = None
    
    async def create_agent(self, request: ForgeV2Request) -> ForgeV2Result:
        """
        Create an agent using Business Logic Generator V2
        
        Args:
            request: ForgeV2Request with query and options
        
        Returns:
            ForgeV2Result with generated agent code
        """
        try:
            logger.info(f"Creating agent with FORGE V2 for query: {request.query}")
            
            # Generate agent name if not provided
            if not request.agent_name:
                # Extract meaningful name from query
                import re
                
                # Check if query contains Korean
                has_korean = any(ord(char) >= 0xAC00 and ord(char) <= 0xD7A3 for char in request.query)
                
                if has_korean:
                    # Korean query handling
                    # Extract key Korean words
                    korean_keywords = {
                        "객체": "Object", "탐지": "Detection", "얼굴": "Face",
                        "인식": "Recognition", "텍스트": "Text", "추출": "Extraction",
                        "품질": "Quality", "평가": "Assessment", "시각화": "Visualization",
                        "배치": "Batch", "처리": "Processing", "컴퓨터": "Computer",
                        "비전": "Vision", "이미지": "Image", "비디오": "Video",
                        "분석": "Analysis", "예측": "Prediction", "분류": "Classification",
                        "계산": "Calculator", "날씨": "Weather", "데이터": "Data",
                        "웹": "Web", "크롤링": "Crawling", "자동화": "Automation"
                    }
                    
                    # Find matching Korean keywords
                    found_keywords = []
                    for ko_word, en_word in korean_keywords.items():
                        if ko_word in request.query:
                            found_keywords.append(en_word)
                    
                    if found_keywords:
                        # Use first 2-3 keywords for name
                        agent_name = "".join(found_keywords[:2]) + "Agent"
                    else:
                        # Fallback for Korean without known keywords
                        agent_name = f"KoreanAgent_{int(datetime.now().timestamp())}"
                else:
                    # English query handling (existing logic)
                    # Clean query: remove punctuation and split
                    cleaned_query = re.sub(r'[^\w\s]', ' ', request.query.lower())
                    query_words = cleaned_query.split()
                    
                    # Remove common words
                    stopwords = ["create", "an", "agent", "that", "for", "to", "with", "and", "or", "the", "a"]
                    meaningful_words = [w for w in query_words if w not in stopwords]
                    
                    # Take first 2-3 meaningful words
                    if meaningful_words:
                        name_parts = meaningful_words[:3]
                        # Sanitize each part and capitalize
                        sanitized_parts = [re.sub(r'[^a-zA-Z0-9]', '', w).capitalize() for w in name_parts]
                        agent_name = "".join(sanitized_parts) + "Agent"
                    else:
                        agent_name = f"Agent_{int(datetime.now().timestamp())}"
            else:
                agent_name = request.agent_name
            
            # Generate description
            description = f"{request.query}"
            
            # 🚀 Enhanced Analysis with IntelligentAnalyzer (if available)
            enhanced_metadata = {}
            if self.use_smart_analyzer and self.intelligent_analyzer:
                try:
                    logger.info("🧠 Using IntelligentAnalyzer for enhanced query understanding...")
                    analysis_result = await self.intelligent_analyzer.analyze(request.query)
                    
                    # Use analysis results to improve agent generation
                    if analysis_result:
                        enhanced_metadata = {
                            "intelligent_analysis": {
                                "intent": analysis_result.intent,
                                "domain": analysis_result.domain.value,
                                "complexity": analysis_result.complexity.value,
                                "features": analysis_result.features,
                                "confidence": analysis_result.confidence,
                                "suggested_name": analysis_result.suggested_name,
                                "keywords": analysis_result.keywords
                            }
                        }
                        
                        # Override agent_name if IntelligentAnalyzer suggests better one
                        if analysis_result.confidence > 0.7 and analysis_result.suggested_name:
                            logger.info(f"✨ Using IntelligentAnalyzer suggested name: {analysis_result.suggested_name}")
                            agent_name = analysis_result.suggested_name
                        
                        # Enhance description with analysis
                        if analysis_result.description:
                            description = analysis_result.description
                        
                        logger.info(f"✅ Enhanced analysis: {analysis_result.domain.value}/{analysis_result.complexity.value} (confidence: {analysis_result.confidence:.2f})")
                except Exception as e:
                    logger.warning(f"IntelligentAnalyzer failed, using basic analysis: {e}")
            
            # === Self-Evolution: Pre-Generation (gap detection) ===
            evolution_context = {}
            if self.evolution:
                try:
                    logger.info(f"🧬 [Evolution] Pre-generation: detecting gaps for query '{request.query[:80]}'...")
                    pre_result = await self.evolution.pre_generation(
                        query=request.query,
                        stream_callback=request.stream_callback
                    )
                    evolution_context['pre_generation'] = pre_result
                    logger.info(
                        f"🧬 [Evolution] Pre-generation complete: "
                        f"coverage={pre_result.coverage*100:.1f}%, "
                        f"gaps={pre_result.gaps_detected}, "
                        f"library_size={pre_result.library_size}"
                    )
                    if pre_result.gaps:
                        for g in pre_result.gaps:
                            gap_status = "GAP" if g.is_gap else "COVERED"
                            logger.info(
                                f"  🧬 [{gap_status}] {g.function_name}: "
                                f"{g.description[:80]} (match={g.best_match_score:.3f})"
                            )
                except Exception as e:
                    logger.warning(f"Self-Evolution pre-generation failed: {e}")

            # Generate agent code with performance monitoring
            logger.info("Generating agent code with Business Logic Generator V2...")
            logger.info(f"🔍 Analyzing query for agentic features: {request.query[:100]}...")

            # Start performance monitoring if available
            if self.monitor:
                perf_context = self.monitor._start_monitoring(f"generate_{agent_name}")

            # Extract gap context from pre-generation for Self-Growing connection
            gap_context = None
            if evolution_context.get('pre_generation'):
                pre_result = evolution_context['pre_generation']
                if pre_result.gaps:
                    gap_context = [
                        {
                            "name": g.function_name,
                            "description": g.description,
                            "best_match_score": g.best_match_score,
                            "is_gap": g.is_gap,
                        }
                        for g in pre_result.gaps if g.is_gap
                    ]
                    if gap_context:
                        logger.info(f"🧬 Passing {len(gap_context)} gaps to function generator for enhanced generation")

            agent_code = await self.generator.generate(
                query=request.query,
                agent_name=agent_name,
                description=description,
                stream_callback=request.stream_callback,  # 🎨 스트리밍 콜백 전달
                business_rules=request.business_rules,  # 🎯 명시적 비즈니스 규칙 전달
                input_schema=request.input_schema,  # 🎯 입력 스키마 전달
                gap_context=gap_context,  # 🧬 Self-Growing gap context
                test_cases=request.test_cases  # 🎯 Test cases for function generation
            )
            
            # End performance monitoring
            if self.monitor:
                self.monitor._end_monitoring(perf_context, success=True)
            
            # Initialize metadata first
            metadata = {
                "agent_name": agent_name,
                "description": description,
                "query": request.query,
                "generator": "Business Logic Generator V2",
                "timestamp": datetime.now().isoformat(),
                "features": [],  # Will be populated later
                "statistics": {},  # Will be populated later
                "validation": {  # Initialize validation metadata
                    "performed": False,
                    "errors": [],
                    "warnings": [],
                    "suggestions": []
                },
                "healing": {  # Initialize healing metadata
                    "applied": False,
                    "confidence": 0.0,
                    "fixes": []
                }
            }
            
            # Merge enhanced metadata if available
            if enhanced_metadata:
                metadata.update(enhanced_metadata)

            # === Self-Evolution: Post-Generation (evaluation + healing + admission) ===
            if self.evolution:
                try:
                    logger.info(f"🧬 [Evolution] Post-generation: evaluating + healing code ({len(agent_code)} chars)...")
                    post_result = await self.evolution.post_generation(
                        code=agent_code,
                        query=request.query,
                        metadata=metadata,
                        stream_callback=request.stream_callback,
                    )
                    evolution_context['post_generation'] = post_result

                    # Apply healed code if available
                    if post_result.healed_code:
                        old_len = len(agent_code)
                        agent_code = post_result.healed_code
                        logger.info(
                            f"🔧 [Evolution] Self-Healing applied: "
                            f"code {old_len}→{len(agent_code)} chars"
                        )

                    # Add quality metrics
                    if post_result.evaluation:
                        metadata['evolution_quality'] = post_result.evaluation.to_dict()
                        evd = post_result.evaluation.to_dict()
                        logger.info(
                            f"📊 [Evolution] Quality score: overall={evd.get('overall', 0):.3f} "
                            f"(functional={evd.get('functional', 0):.2f}, "
                            f"code_quality={evd.get('code_quality', 0):.2f}, "
                            f"performance={evd.get('performance', 0):.2f})"
                        )

                    # Add admission info
                    if post_result.admission:
                        metadata['evolution_admission'] = post_result.admission.to_dict()
                        adm = post_result.admission
                        logger.info(
                            f"🧬 [Evolution] Admission: decision={getattr(adm, 'decision', 'N/A')}, "
                            f"reason={getattr(adm, 'reason', 'N/A')}"
                        )

                except Exception as e:
                    logger.warning(f"Self-Evolution post-generation failed: {e}")

            # === Auto-Debugging: compile + execute + fix loop ===
            # Skip auto-debug if code already compiles fine — prevents LLM from breaking working code
            try:
                compile(agent_code, '<pre-debug>', 'exec')
                _needs_debug = False
                logger.info("✅ Pre-debug syntax check passed — skipping auto-debug")
            except SyntaxError:
                _needs_debug = True

            if _needs_debug:
                auto_debug_results = await self._auto_debug_code(agent_code, agent_name, request.stream_callback)
                if auto_debug_results["fixed"]:
                    agent_code = auto_debug_results["code"]
                    logger.info(f"🔧 Auto-debug applied {auto_debug_results['iterations']} fix(es)")

                # If still broken after auto-debug, retry entire generation once
                try:
                    compile(agent_code, '<post-debug>', 'exec')
                except SyntaxError:
                    if not hasattr(request, '_retry_done'):
                        logger.warning("⚠️ Post-debug syntax still broken — retrying full generation")
                        request._retry_done = True
                        return await self.create_agent(request)
                    else:
                        logger.warning("⚠️ Retry also failed — returning best effort code")
            else:
                auto_debug_results = {"fixed": False, "iterations": 0, "errors_found": [], "fixes_applied": [], "code": agent_code}
            metadata["auto_debug"] = {
                "performed": True,
                "iterations": auto_debug_results["iterations"],
                "fixed": auto_debug_results["fixed"],
                "errors_found": auto_debug_results["errors_found"],
                "fixes_applied": auto_debug_results["fixes_applied"],
            }

            # 🎯 Business Logic Validation (if available)
            if self.use_business_logic_validator and self.business_logic_validator:
                try:
                    logger.info("🔍 Validating business logic against requirements...")
                    bl_validation = self.business_logic_validator.validate(
                        agent_code=agent_code,
                        user_query=request.query,
                        metadata=metadata
                    )
                    
                    metadata["business_logic_validation"] = {
                        "performed": True,
                        "is_valid": bl_validation.is_valid,
                        "coverage_score": bl_validation.coverage_score,
                        "missing_requirements": bl_validation.missing_requirements,
                        "implemented_requirements": bl_validation.implemented_requirements,
                        "suggestions": bl_validation.suggestions,
                        "details": bl_validation.details
                    }
                    
                    if bl_validation.is_valid:
                        logger.info(f"✅ Business logic validation passed (coverage: {bl_validation.coverage_score:.1%})")
                    else:
                        logger.warning(f"⚠️  Business logic validation failed (coverage: {bl_validation.coverage_score:.1%})")
                        logger.warning(f"Missing requirements: {bl_validation.missing_requirements}")
                        logger.info(f"Suggestions: {bl_validation.suggestions}")
                    
                    # Generate test cases
                    test_cases = self.business_logic_validator.generate_test_cases(
                        agent_code,
                        request.query,
                        bl_validation
                    )
                    metadata["auto_generated_tests"] = test_cases
                    logger.info(f"✅ Generated {len(test_cases)} automatic test cases")
                    
                except Exception as e:
                    logger.warning(f"Business logic validation failed: {e}")
                    metadata["business_logic_validation"] = {
                        "performed": False,
                        "error": str(e)
                    }
            
            # Validate generated code if validator available
            if self.validator:
                logger.info("Validating generated code...")
                validation_result = self.validator.validate(
                    agent_code,
                    {"agent_name": agent_name}
                )
                
                metadata["validation"]["performed"] = True
                
                if not validation_result.is_valid:
                    logger.warning(f"Generated code has issues: {validation_result.errors}")
                    metadata["validation"]["errors"] = validation_result.errors
                    metadata["validation"]["warnings"] = validation_result.warnings
                    metadata["validation"]["suggestions"] = validation_result.suggestions
                    
                    # Attempt self-healing if available
                    if self.healer:
                        logger.info("Attempting to heal code...")
                        healing_result = self.healer.heal(agent_code)
                        
                        if healing_result.success:
                            logger.info(f"Code healed successfully! Fixes: {healing_result.fixes_applied}")
                            agent_code = healing_result.healed_code
                            metadata["healing"]["applied"] = True
                            metadata["healing"]["confidence"] = healing_result.confidence
                            metadata["healing"]["fixes"] = healing_result.fixes_applied
                        else:
                            logger.warning("Healing failed, using original code")
                else:
                    logger.info(f"Code validation passed ({validation_result.performance_ms:.2f}ms)")
                    metadata["validation"]["performance_ms"] = validation_result.performance_ms
            
            # Update metadata with extracted features and statistics
            metadata.update({
                "features": self._extract_features(agent_code),
                "statistics": {
                    "lines_of_code": len(agent_code.split('\n')),
                    "characters": len(agent_code),
                    "functions": agent_code.count("async def "),
                    "imports": agent_code.count("import ")
                }
            })
            
            # === Self-Evolution: Enrich result with evolution context ===
            if self.evolution and evolution_context:
                evo_meta = {}
                if 'pre_generation' in evolution_context:
                    evo_meta['pre_generation'] = evolution_context['pre_generation'].to_dict()
                if 'post_generation' in evolution_context:
                    evo_meta['post_generation'] = evolution_context['post_generation'].to_dict()
                metadata['evolution'] = evo_meta

            # Add function generation source stats
            try:
                fg = self.generator.function_generator
                gen_stats = getattr(fg, '_generation_stats', {})
                metadata['generation_sources'] = dict(gen_stats)
                metadata['slice_used'] = gen_stats.get('slice', 0) > 0
                metadata['generation_mode'] = 'slice' if gen_stats.get('slice', 0) > 0 else 'llm'
            except Exception:
                pass

            # Save to file if requested
            file_path = None
            if request.save_to_file:
                file_path = await self._save_agent_code(
                    agent_code,
                    agent_name,
                    metadata
                )
                logger.info(f"Agent code saved to: {file_path}")
            
            # Run tests if enabled
            test_results = None
            if request.enable_testing:
                test_results = await self._test_agent(agent_code, agent_name)
                logger.info(f"Test results: {test_results}")
            
            # Return success result
            return ForgeV2Result(
                success=True,
                agent_code=agent_code,
                file_path=str(file_path) if file_path else None,
                metadata=metadata,
                test_results=test_results
            )
            
        except Exception as e:
            logger.error(f"Failed to create agent: {e}")
            return ForgeV2Result(
                success=False,
                error=str(e)
            )
    
    async def _auto_debug_code(
        self, code: str, agent_name: str, stream_callback=None, max_iterations: int = 5
    ) -> Dict[str, Any]:
        """
        Auto-debugging loop: compile → execute → catch errors → fix → repeat.

        Returns dict with: code, fixed, iterations, errors_found, fixes_applied
        """
        logger.info(f"🔧 [Auto-Debug] Starting for '{agent_name}' (max {max_iterations} iterations, code={len(code)} chars)")
        result = {
            "code": code,
            "fixed": False,
            "iterations": 0,
            "errors_found": [],
            "fixes_applied": [],
        }

        current_code = code

        # Pre-pass: bulk sanitize common issues (no LLM, instant)
        sanitized = self._bulk_sanitize_code(current_code)
        if sanitized != current_code:
            logger.info(f"🔧 [Auto-Debug] Pre-pass sanitization applied (delta: {abs(len(sanitized) - len(current_code))} chars)")
            current_code = sanitized
            result["fixed"] = True
            result["code"] = current_code
            result["fixes_applied"].append("pre-pass: bulk sanitize (leading zeros, unicode chars)")

        for iteration in range(max_iterations):
            logger.info(f"🔧 [Auto-Debug] Iteration {iteration+1}/{max_iterations}: checking code...")
            error_msg = self._check_code_errors(current_code, agent_name)
            if not error_msg:
                # No errors — code is clean
                if iteration > 0:
                    logger.info(f"✅ [Auto-Debug] Code is CLEAN after {iteration} fix(es) — all errors resolved")
                else:
                    logger.info(f"✅ [Auto-Debug] Code passed on first check — no errors detected")
                break

            result["errors_found"].append(error_msg[:300])
            logger.warning(f"🔍 [Auto-Debug] Error detected (iter {iteration+1}): {error_msg[:200]}")

            if stream_callback:
                try:
                    await stream_callback(
                        "auto_debug",
                        f"🔧 자동 디버깅 {iteration+1}/{max_iterations}: 오류 감지 → 수정 중...",
                        {"iteration": iteration + 1, "error": error_msg[:150]}
                    )
                except Exception:
                    pass

            # Try to fix with CodeFixer
            logger.info(f"🔧 [Auto-Debug] Attempting fix (iter {iteration+1})...")
            fixed_code = await self._try_fix_code(current_code, error_msg)
            if fixed_code and fixed_code != current_code:
                # Verify fix didn't introduce NEW errors
                try:
                    compile(fixed_code, '<fix-check>', 'exec')
                    fix_is_better = True  # No syntax error = better
                except SyntaxError:
                    # Fixed code still has errors — check if it's a different (possibly worse) error
                    try:
                        compile(current_code, '<orig-check>', 'exec')
                        fix_is_better = True  # Original also had errors
                    except SyntaxError:
                        fix_is_better = True  # Both have errors, try the fix

                if not fix_is_better:
                    logger.warning(f"⚠️ [Auto-Debug] Fix introduced new errors, reverting")
                    break

                # Calculate diff size
                old_lines = len(current_code.splitlines())
                new_lines = len(fixed_code.splitlines())
                diff_chars = abs(len(fixed_code) - len(current_code))
                fix_desc = f"iteration_{iteration+1}: {error_msg[:80]}"
                result["fixes_applied"].append(fix_desc)
                current_code = fixed_code
                result["iterations"] = iteration + 1
                result["fixed"] = True
                result["code"] = current_code
                logger.info(
                    f"✅ [Auto-Debug] Fix applied (iter {iteration+1}): "
                    f"lines {old_lines}→{new_lines}, chars changed ~{diff_chars}"
                )
            else:
                logger.warning(
                    f"❌ [Auto-Debug] Fix FAILED at iteration {iteration+1} — "
                    f"could not resolve: {error_msg[:120]}"
                )
                break
        else:
            # Exhausted all iterations
            logger.warning(
                f"⚠️ [Auto-Debug] Exhausted {max_iterations} iterations for '{agent_name}'. "
                f"Errors remaining: {len(result['errors_found'])}"
            )

        logger.info(
            f"🔧 [Auto-Debug] Complete for '{agent_name}': "
            f"fixed={result['fixed']}, iterations={result['iterations']}, "
            f"errors_found={len(result['errors_found'])}, fixes_applied={len(result['fixes_applied'])}"
        )
        return result

    def _check_code_errors(self, code: str, agent_name: str) -> Optional[str]:
        """Check generated code for compile and basic runtime errors."""
        logger.debug(f"🔍 [Check] Syntax check for '{agent_name}' ({len(code)} chars)...")
        # Step 1: Syntax check
        try:
            compile(code, f"{agent_name}.py", "exec")
            logger.debug(f"🔍 [Check] Syntax OK — proceeding to exec check")
        except SyntaxError as e:
            msg = f"SyntaxError: {e.msg} (line {e.lineno})"
            logger.warning(f"🔍 [Check] {msg}")
            return msg

        # Step 2: Try exec in isolated namespace to catch import/name errors
        logger.debug(f"🔍 [Check] Exec check in isolated namespace...")
        try:
            namespace = {"__builtins__": __builtins__}
            exec(code, namespace)
            logger.debug(f"🔍 [Check] Exec OK — no errors")
        except ImportError as e:
            msg = f"ImportError: {e}"
            logger.warning(f"🔍 [Check] {msg}")
            return msg
        except NameError as e:
            msg = f"NameError: {e}"
            logger.warning(f"🔍 [Check] {msg}")
            return msg
        except TypeError as e:
            msg = f"TypeError: {e}"
            logger.warning(f"🔍 [Check] {msg}")
            return msg
        except Exception as e:
            error_type = type(e).__name__
            msg = f"{error_type}: {e}"
            logger.warning(f"🔍 [Check] Runtime error: {msg}")
            return msg

        return None  # No errors

    async def _try_fix_code(self, code: str, error: str) -> Optional[str]:
        """Attempt to fix code using available fixers."""
        logger.info(f"🔧 [Fix] Attempting to fix error: {error[:150]}")

        # Strategy 0: Quick regex fixes for common patterns (no LLM needed)
        quick_fix = self._quick_syntax_fix(code, error)
        if quick_fix and quick_fix != code:
            logger.info(f"✅ [Fix] Quick regex fix applied (delta: {abs(len(quick_fix) - len(code))} chars)")
            return quick_fix

        # Strategy 0.5: ImportError — fix import lines only, never send to LLM
        # LLM tends to add duplicate process() methods when rewriting for ImportError
        if "ImportError" in error or "ModuleNotFoundError" in error:
            import re as _re
            fixed = code
            # Fix LogosAIAgent import — use try/except pattern
            if "LogosAIAgent" in error:
                # Replace direct import with try/except fallback
                old_import = "from logosai import LogosAIAgent"
                fallback_import = (
                    "try:\n"
                    "    from logosai.agent import LogosAIAgent\n"
                    "except ImportError:\n"
                    "    try:\n"
                    "        from logosai import LogosAIAgent\n"
                    "    except ImportError:\n"
                    "        class LogosAIAgent:\n"
                    '            def __init__(self, config=None): self.config = config\n'
                    '            async def process(self, *a, **kw): raise NotImplementedError'
                )
                if old_import in fixed:
                    fixed = fixed.replace(old_import, fallback_import, 1)
                elif "from logosai.agent import LogosAIAgent" in fixed:
                    fixed = fixed.replace("from logosai.agent import LogosAIAgent", fallback_import, 1)
            # Generic: comment out failing import
            else:
                module_match = _re.search(r"cannot import name '(\w+)' from '([\w.]+)'", error)
                if module_match:
                    name, mod = module_match.group(1), module_match.group(2)
                    bad_import = f"from {mod} import {name}"
                    if bad_import in fixed:
                        fixed = fixed.replace(bad_import, f"# {bad_import}  # auto-disabled", 1)
            if fixed != code:
                logger.info(f"✅ [Fix] ImportError handled without LLM (delta: {abs(len(fixed) - len(code))} chars)")
                return fixed

        # Strategy 1: CodeFixer (LLM + rules)
        if self.code_fixer:
            logger.info(f"🔧 [Fix] Strategy 1: CodeFixer (targeted rules → self-healing AST → LLM → global rules)")
            try:
                success, fixed_code, explanation = await self.code_fixer.fix_code(
                    code, error
                )
                if success:
                    logger.info(f"✅ [Fix] CodeFixer succeeded: {explanation[:150]}")
                    return fixed_code
                else:
                    logger.info(f"🔧 [Fix] CodeFixer returned success=False, trying next strategy")
            except Exception as e:
                logger.warning(f"🔧 [Fix] CodeFixer exception: {type(e).__name__}: {str(e)[:100]}")
        else:
            logger.info(f"🔧 [Fix] CodeFixer not available, skipping Strategy 1")

        # Strategy 2: Auto-fix imports (stdlib injection + external fallback)
        logger.info(f"🔧 [Fix] Strategy 2: Auto-fix imports")
        fixed = self._auto_fix_imports(code, error)
        if fixed != code:
            logger.info(f"✅ [Fix] Auto-fix imports succeeded (delta: {abs(len(fixed) - len(code))} chars)")
            return fixed
        else:
            logger.info(f"🔧 [Fix] Auto-fix imports: no changes made")

        logger.warning(f"❌ [Fix] All strategies exhausted — could not fix: {error[:100]}")
        return None

    def _bulk_sanitize_code(self, code: str) -> str:
        """Bulk sanitize generated code — remove common LLM generation artifacts.
        Runs once before the auto-debug loop. No LLM needed, instant."""
        import re
        original = code

        # 1. Remove non-ASCII characters outside of string literals
        # Split by lines and clean each
        lines = code.splitlines()
        cleaned_lines = []
        for line in lines:
            stripped = line.strip()
            # Skip comment lines — they may have unicode intentionally
            if stripped.startswith('#'):
                # But still remove truly problematic chars
                clean = re.sub(r'[^\x00-\x7F\u3000-\u9FFF\uAC00-\uD7AF]', '', line)
                cleaned_lines.append(clean)
            else:
                # For code lines: remove non-ASCII non-Korean/CJK chars
                # Keep Korean (AC00-D7AF), CJK (3000-9FFF) for string content
                clean = re.sub(r'[^\x00-\x7F\u3000-\u9FFF\uAC00-\uD7AF]', '', line)
                cleaned_lines.append(clean)
        code = "\n".join(cleaned_lines)

        # 2. Fix leading zeros in decimal literals (0123 → 123)
        # But don't touch 0x, 0o, 0b prefixes, or 0.123 floats
        code = re.sub(r'(?<![.\w])0+(\d+)(?![\w.])', lambda m: m.group(1), code)

        if code != original:
            changes = abs(len(code) - len(original))
            logger.info(f"🔧 [Sanitize] Bulk sanitized: removed {changes} chars of LLM artifacts")

        return code

    def _quick_syntax_fix(self, code: str, error: str) -> Optional[str]:
        """Quick regex-based fixes for common SyntaxErrors — no LLM needed."""
        import re

        # Fix leading zeros (0123 → 123, 001 → 1)
        if "leading zeros" in error.lower():
            fixed = re.sub(r'(?<!\w)0+(\d+)(?!\w)', lambda m: m.group(1), code)
            if fixed != code:
                logger.info(f"🔧 [QuickFix] Removed leading zeros in decimal literals")
                return fixed

        # Fix "invalid decimal literal" — usually LLM adds bad version/date at top
        if "invalid decimal literal" in error.lower():
            match = re.search(r'line (\d+)', error)
            if match:
                line_no = int(match.group(1))
                lines = code.splitlines()
                if 0 < line_no <= len(lines):
                    bad_line = lines[line_no - 1]
                    stripped = bad_line.strip()
                    # If it's a comment-like line or metadata, remove it
                    if stripped.startswith('#') or stripped.startswith('//'):
                        lines[line_no - 1] = '# ' + stripped.lstrip('#/ ')
                        logger.info(f"🔧 [QuickFix] Fixed comment with invalid literal at line {line_no}")
                        return "\n".join(lines)
                    # If it's a bare number/version at top of file (lines 1-10), comment it out
                    if line_no <= 10 and not any(stripped.startswith(kw) for kw in ['import ', 'from ', 'class ', 'def ', 'async ']):
                        lines[line_no - 1] = '# ' + stripped
                        logger.info(f"🔧 [QuickFix] Commented out invalid literal at line {line_no}: {stripped[:60]}")
                        return "\n".join(lines)
                    # Try removing just the invalid token (digit-letter sequence)
                    fixed_line = re.sub(r'\b\d+[a-zA-Z_]\w*\b', '0', bad_line)
                    if fixed_line != bad_line:
                        lines[line_no - 1] = fixed_line
                        logger.info(f"🔧 [QuickFix] Fixed invalid decimal token at line {line_no}")
                        return "\n".join(lines)

        # Fix invalid characters (unicode symbols like ▶, ●, etc.)
        if "invalid character" in error.lower():
            match = re.search(r'line (\d+)', error)
            if match:
                line_no = int(match.group(1))
                lines = code.splitlines()
                if 0 < line_no <= len(lines):
                    old_line = lines[line_no - 1]
                    # Remove non-ASCII characters that aren't in strings
                    cleaned = re.sub(r'[^\x00-\x7F]+', '', old_line)
                    if cleaned.strip():  # Don't remove entire line
                        lines[line_no - 1] = cleaned
                        logger.info(f"🔧 [QuickFix] Removed invalid unicode characters at line {line_no}")
                        return "\n".join(lines)
                    else:
                        # Line was all unicode — comment it out
                        indent = len(old_line) - len(old_line.lstrip())
                        lines[line_no - 1] = " " * indent + "# (removed invalid unicode line)"
                        logger.info(f"🔧 [QuickFix] Commented out unicode-only line {line_no}")
                        return "\n".join(lines)

        # Fix unterminated string literal — remove the broken line
        if "unterminated string" in error.lower():
            match = re.search(r'line (\d+)', error)
            if match:
                line_no = int(match.group(1))
                lines = code.splitlines()
                if 0 < line_no <= len(lines):
                    bad_line = lines[line_no - 1]
                    # Try to close the string
                    stripped = bad_line.rstrip()
                    for q in ['"""', "'''", '"', "'"]:
                        if q in stripped:
                            count = stripped.count(q)
                            if count % 2 != 0:
                                lines[line_no - 1] = stripped + q
                                logger.info(f"🔧 [QuickFix] Closed unterminated string at line {line_no} with '{q}'")
                                return "\n".join(lines)

        return None

    def _auto_fix_imports(self, code: str, error: str) -> str:
        """Auto-fix common import issues in generated code."""
        if "ImportError" not in error and "ModuleNotFoundError" not in error:
            logger.debug(f"🔧 [AutoImport] Error is not import-related, skipping")
            return code

        # Extract the module name that failed
        import re
        match = re.search(r"No module named ['\"]?(\w+)", error)
        if not match:
            logger.debug(f"🔧 [AutoImport] Could not extract module name from error")
            return code

        missing_module = match.group(1)
        logger.info(f"🔧 [AutoImport] Missing module detected: '{missing_module}'")

        # Standard library modules that can be imported
        stdlib_auto_imports = {
            "json", "math", "re", "datetime", "os", "sys", "collections",
            "statistics", "hashlib", "base64", "urllib", "csv", "io",
            "random", "string", "pathlib", "copy", "uuid", "decimal",
            "itertools", "functools", "textwrap", "html", "typing",
            "time", "socket", "http", "struct",
        }

        if missing_module in stdlib_auto_imports:
            import_line = f"import {missing_module}"
            if import_line not in code:
                lines = code.split("\n")
                insert_idx = 0
                for i, line in enumerate(lines):
                    if line.startswith(("import ", "from ")):
                        insert_idx = i + 1
                lines.insert(insert_idx, import_line)
                logger.info(f"✅ [AutoImport] Injected stdlib import: '{import_line}' at line {insert_idx+1}")
                return "\n".join(lines)
            else:
                logger.debug(f"🔧 [AutoImport] '{import_line}' already exists in code")

        # For external modules, wrap the import in try/except
        external_fallbacks = {
            "logosai": (
                "from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse, AgentResponseType",
                "# logosai not available — define minimal stubs\n"
                "class AgentType: CUSTOM = 'custom'\n"
                "class AgentResponseType: SUCCESS = 'success'; ERROR = 'error'\n"
                "class AgentResponse:\n"
                "    def __init__(self, type=None, content=None, message=''): self.type=type; self.content=content; self.message=message\n"
                "class AgentConfig:\n"
                "    def __init__(self, **kw): [setattr(self, k, v) for k, v in kw.items()]\n"
                "class LogosAIAgent:\n"
                "    def __init__(self, config): self.config=config\n"
            ),
        }

        if missing_module in external_fallbacks:
            original_import, fallback = external_fallbacks[missing_module]
            if original_import in code:
                replacement = f"try:\n    {original_import}\nexcept ImportError:\n    {fallback}"
                code = code.replace(original_import, replacement)
                logger.info(f"✅ [AutoImport] Wrapped '{missing_module}' import with try/except + stub fallback")
                return code

        # For unknown external modules: wrap with try/except + empty fallback
        logger.info(f"🔧 [AutoImport] Unknown external module '{missing_module}' — attempting try/except wrap")
        # Find the import line in code
        for pattern in [
            f"import {missing_module}",
            f"from {missing_module}",
        ]:
            if pattern in code:
                # Find the full import line
                for line in code.splitlines():
                    stripped = line.strip()
                    if stripped.startswith(pattern):
                        indent = line[:len(line) - len(line.lstrip())]
                        replacement = (
                            f"{indent}try:\n"
                            f"{indent}    {stripped}\n"
                            f"{indent}except ImportError:\n"
                            f"{indent}    pass  # {missing_module} not available"
                        )
                        code = code.replace(line, replacement, 1)
                        logger.info(f"✅ [AutoImport] Wrapped external import '{stripped}' with try/except pass")
                        return code

        logger.warning(f"❌ [AutoImport] Could not fix import for '{missing_module}' — import line not found in code")
        return code

    def _extract_features(self, agent_code: str) -> list:
        """Extract features from generated code"""
        features = []
        
        # Check for common features
        feature_patterns = {
            "CSV Processing": ["csv", "pd.read_csv", "DataFrame"],
            "JSON Handling": ["json", "json.loads", "json.dumps"],
            "Statistical Analysis": ["statistics", "mean", "median", "std"],
            "Machine Learning": ["sklearn", "model", "predict", "classify"],
            "Data Visualization": ["plot", "chart", "graph", "plotly", "matplotlib"],
            "Email Integration": ["email", "smtp", "send_email"],
            "Web Integration": ["webhook", "requests", "aiohttp", "api"],
            "Data Cleaning": ["clean", "missing", "dropna", "fillna"],
            "Data Aggregation": ["groupby", "aggregate", "sum", "count"],
            "Error Handling": ["try:", "except", "finally"],
            "Async Support": ["async def", "await", "asyncio"],
            "Logging": ["logger", "logging"]
        }
        
        code_lower = agent_code.lower()
        for feature, patterns in feature_patterns.items():
            if any(pattern.lower() in code_lower for pattern in patterns):
                features.append(feature)
        
        return features
    
    async def _save_agent_code(
        self,
        agent_code: str,
        agent_name: str,
        metadata: Dict[str, Any]
    ) -> Path:
        """Save agent code to file"""
        
        # Generate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{agent_name.lower()}_{timestamp}.py"
        file_path = self.output_dir / filename
        
        # Add metadata as comments at the top
        header = f'''"""
{metadata.get('description', agent_name)}

Generated by: {metadata.get('generator', 'FORGE V2')}
Date: {metadata.get('timestamp', datetime.now().isoformat())}
Query: {metadata.get('query', 'N/A')}

Features:
{chr(10).join(f"- {feature}" for feature in metadata.get('features', []))}

Statistics:
- Lines of code: {metadata['statistics']['lines_of_code']}
- Characters: {metadata['statistics']['characters']}
- Functions: {metadata['statistics']['functions']}
- Imports: {metadata['statistics']['imports']}
"""

'''
        
        # Write file
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(header + agent_code)
        
        return file_path
    
    async def _test_agent(self, agent_code: str, agent_name: str) -> Dict[str, Any]:
        """Test generated agent code"""
        
        test_results = {
            "syntax_check": False,
            "imports_available": False,
            "class_instantiation": False,
            "execution_test": False,
            "errors": []
        }
        
        try:
            # 1. Syntax check
            compile(agent_code, f"{agent_name}.py", 'exec')
            test_results["syntax_check"] = True
            logger.info("✅ Syntax check passed")
            
            # 2. Check imports (basic check)
            import_errors = []
            if "pandas" in agent_code and not self._check_import("pandas"):
                import_errors.append("pandas not installed")
            if "numpy" in agent_code and not self._check_import("numpy"):
                import_errors.append("numpy not installed")
            if "sklearn" in agent_code and not self._check_import("sklearn"):
                import_errors.append("sklearn not installed")
            
            if not import_errors:
                test_results["imports_available"] = True
                logger.info("✅ Import check passed")
            else:
                test_results["errors"].extend(import_errors)
                logger.warning(f"⚠️ Import issues: {import_errors}")
            
            # 3. Try to execute (in isolated namespace)
            namespace = {}
            exec(agent_code, namespace)
            
            # Check if agent class exists
            agent_class = None
            for name, obj in namespace.items():
                if isinstance(obj, type) and name == agent_name:
                    agent_class = obj
                    break
            
            if agent_class:
                test_results["class_instantiation"] = True
                logger.info(f"✅ Agent class {agent_name} found")
                
                # Try to instantiate
                try:
                    agent_instance = agent_class()
                    
                    # Check for required methods
                    if hasattr(agent_instance, 'process'):
                        test_results["execution_test"] = True
                        logger.info("✅ Agent has process method")
                    else:
                        test_results["errors"].append("Missing process method")
                        
                except Exception as e:
                    test_results["errors"].append(f"Instantiation error: {str(e)}")
            else:
                test_results["errors"].append(f"Agent class {agent_name} not found")
                
        except SyntaxError as e:
            test_results["errors"].append(f"Syntax error: {str(e)}")
        except Exception as e:
            test_results["errors"].append(f"Execution error: {str(e)}")
        
        # Calculate overall success
        test_results["overall_success"] = all([
            test_results["syntax_check"],
            test_results["class_instantiation"]
        ])
        
        return test_results
    
    def get_performance_stats(self) -> Optional[Dict]:
        """Get performance statistics if monitoring is enabled"""
        if self.monitor:
            return self.monitor.get_summary()
        return None
    
    def get_validation_stats(self) -> Optional[Dict]:
        """Get validation statistics if validator is enabled"""
        if self.validator:
            return self.validator.get_performance_stats()
        return None
    
    def get_healing_stats(self) -> Optional[Dict]:
        """Get self-healing statistics if healer is enabled"""
        if self.healer:
            return self.healer.get_stats()
        return None
    
    def save_performance_report(self) -> Optional[str]:
        """Save comprehensive performance report"""
        if self.monitor:
            return self.monitor.save_report()
        return None
    
    def _check_import(self, module_name: str) -> bool:
        """Check if a module can be imported"""
        try:
            __import__(module_name)
            return True
        except ImportError:
            return False


# Create singleton instance
forge_v2_system = ForgeV2System()