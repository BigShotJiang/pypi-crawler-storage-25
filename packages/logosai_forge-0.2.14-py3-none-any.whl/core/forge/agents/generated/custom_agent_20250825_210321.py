import re
import asyncio
import json
from datetime import datetime
from typing import Any, Dict, List, Optional
import operator
from logosai import AgentConfig, AgentResponse, AgentResponseType, AgentType, LogosAIAgent
from loguru import logger

class CalculatorAgent(LogosAIAgent):
    """CalculatorAgent - LogosAI Agent
간단한 계산기 에이전트를 만들어줘"""

    def __init__(self):
        config = AgentConfig(**{'name': 'CalculatorAgent', 'description': '간단한 계산기 에이전트를 만들어줘', 'agent_type': AgentType.GENERAL, 'version': '1.0.0'})
        super().__init__(config)
        logger.info('Initialized CalculatorAgent')

    async def _process_core_logic(self, extracted_info: Any) -> Dict:
        """Core processing logic"""
        try:
            data = extracted_info if isinstance(extracted_info, dict) else {'input': str(extracted_info)}
            query_str = str(extracted_info) if not isinstance(extracted_info, dict) else extracted_info.get('query', str(extracted_info))
            numbers = re.findall('[\\d.]+', query_str)
            operators = re.findall('[+\\-*/]', query_str)
            korean_ops = {'더하기': '+', '빼기': '-', '곱하기': '*', '나누기': '/'}
            for k, v in korean_ops.items():
                if k in query_str:
                    operators.append(v)
            try:
                if len(numbers) >= 2 and operators:
                    num1 = float(numbers[0])
                    num2 = float(numbers[1])
                    op = operators[0]
                    ops_map = {'+': operator.add, '-': operator.sub, '*': operator.mul, '/': operator.truediv}
                    if op in ops_map:
                        result_value = ops_map[op](num1, num2)
                        result = {'status': 'success', 'calculation': f'{num1} {op} {num2} = {result_value}', 'result': result_value, 'expression': f'{num1} {op} {num2}', 'timestamp': datetime.now().isoformat()}
                    else:
                        result = {'status': 'error', 'message': f'Unknown operator: {op}'}
                elif '더하기' in query_str or '+' in query_str:
                    if len(numbers) >= 2:
                        result_value = float(numbers[0]) + float(numbers[1])
                        result = {'status': 'success', 'result': result_value, 'calculation': f'{numbers[0]} + {numbers[1]} = {result_value}', 'timestamp': datetime.now().isoformat()}
                    else:
                        result = {'status': 'error', 'message': 'Not enough numbers for calculation'}
                else:
                    result = {'status': 'error', 'message': 'Could not parse expression'}
            except Exception as calc_error:
                result = {'status': 'error', 'message': f'Calculation error: {str(calc_error)}'}
            logger.info(f'✅ Calculator result: {result}')
            return result
        except Exception as e:
            logger.error(f'Error in core logic: {e}')
            raise

    async def process(self, query: str, context: Optional[Dict[str, Any]]=None) -> AgentResponse:
        """Main entry point for agent processing"""
        try:
            result = await self._process_core_logic(query)
            return AgentResponse(type=AgentResponseType.SUCCESS, content=result)
        except Exception as e:
            return AgentResponse(type=AgentResponseType.ERROR, content={'error': str(e)})
if __name__ == '__main__':
    agent = CalculatorAgent()
    asyncio.run(agent.process('Test query'))