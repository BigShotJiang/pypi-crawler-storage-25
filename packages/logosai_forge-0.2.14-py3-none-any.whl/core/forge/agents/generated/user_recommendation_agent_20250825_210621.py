import asyncio
import json
from datetime import datetime
from typing import Any, Dict, List, Optional
from logosai import AgentConfig, AgentResponse, AgentResponseType, AgentType, LogosAIAgent
from loguru import logger

class UserrecommendationAgent(LogosAIAgent):
    """UserRecommendationAgent - LogosAI Agent
사용자의 선호도와 알레르기를 고려해서 음식을 추천하는 에이전트를 만들어줘"""

    def __init__(self):
        config = AgentConfig(**{'name': 'UserRecommendationAgent', 'description': '사용자의 선호도와 알레르기를 고려해서 음식을 추천하는 에이전트를 만들어줘', 'agent_type': AgentType.GENERAL, 'version': '1.0.0'})
        super().__init__(config)
        logger.info('Initialized UserrecommendationAgent')

    async def _process_core_logic(self, extracted_info: Any) -> Dict:
        """Core processing logic"""
        try:
            data = extracted_info if isinstance(extracted_info, dict) else {'input': str(extracted_info)}
            data = extracted_info if isinstance(extracted_info, dict) else {'input': str(extracted_info)}
            result = {'status': 'success', 'data': data, 'message': 'Processing completed', 'timestamp': datetime.now().isoformat(), 'agent_type': 'general'}
            logger.info('✅ Processing completed')
            return result
        except Exception as e:
            logger.error(f'Error in core logic: {e}')
            raise

    async def process(self, query: str, context: Optional[Dict[str, Any]]=None) -> AgentResponse:
        """Main entry point for agent processing"""
        try:
            result = await self._process_core_logic(query)
            return AgentResponse(type=AgentResponseType.SUCCESS, content=result)
        except Exception as e:
            return AgentResponse(type=AgentResponseType.ERROR, content={'error': str(e)})
if __name__ == '__main__':
    agent = UserrecommendationAgent()
    asyncio.run(agent.process('Test query'))