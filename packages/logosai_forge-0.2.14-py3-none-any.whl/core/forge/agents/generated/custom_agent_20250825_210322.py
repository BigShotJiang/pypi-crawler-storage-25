import asyncio
import json
from datetime import datetime
from typing import Any, Dict, List, Optional
import random
from logosai import AgentConfig, AgentResponse, AgentResponseType, AgentType, LogosAIAgent
from loguru import logger

class WeatherAgent(LogosAIAgent):
    """WeatherAgent - LogosAI Agent
날씨 정보를 알려주는 에이전트 생성해줘"""

    def __init__(self):
        config = AgentConfig(**{'name': 'WeatherAgent', 'description': '날씨 정보를 알려주는 에이전트 생성해줘', 'agent_type': AgentType.GENERAL, 'version': '1.0.0'})
        super().__init__(config)
        logger.info('Initialized WeatherAgent')

    async def _process_core_logic(self, extracted_info: Any) -> Dict:
        """Core processing logic"""
        try:
            data = extracted_info if isinstance(extracted_info, dict) else {'input': str(extracted_info)}
            query_str = str(extracted_info) if not isinstance(extracted_info, dict) else extracted_info.get('query', str(extracted_info))
            cities = ['서울', '부산', '대구', '인천', '광주', '대전', 'Seoul', 'Busan']
            city = '서울'
            for c in cities:
                if c in query_str:
                    city = c
                    break
            weather_conditions = ['맑음', '구름 조금', '흐림', '비', '눈']
            temperature = random.randint(-5, 35)
            humidity = random.randint(30, 90)
            condition = random.choice(weather_conditions)
            logger.info(f'✅ Weather info for {city}: {result}')
            return result
        except Exception as e:
            logger.error(f'Error in core logic: {e}')
            raise

    async def process(self, query: str, context: Optional[Dict[str, Any]]=None) -> AgentResponse:
        """Main entry point for agent processing"""
        try:
            result = await self._process_core_logic(query)
            return AgentResponse(type=AgentResponseType.SUCCESS, content=result)
        except Exception as e:
            return AgentResponse(type=AgentResponseType.ERROR, content={'error': str(e)})
if __name__ == '__main__':
    agent = WeatherAgent()
    asyncio.run(agent.process('Test query'))