"""
Enhanced FORGE AI Pipeline with Integrated Components
QueryAnalyzer, EnhancedTemplateGenerator, IntelligentDataGenerator 통합
"""

import asyncio
from typing import Dict, Any, Optional, Callable
from datetime import datetime
from pathlib import Path
import uuid

from .forge_pipeline import ForgePipeline
from .query_analyzer import QueryAnalyzer
from .enhanced_template_generator import EnhancedTemplateGenerator
from .intelligent_data_generator import IntelligentDataGenerator
from .llm_orchestrator import LLMOrchestrator, TaskType
from loguru import logger


class EnhancedForgePipeline(ForgePipeline):
    """
    개선된 FORGE 파이프라인
    - QueryAnalyzer와 TemplateGenerator 통합
    - IntelligentDataGenerator 실제 활용
    - 통합된 플로우
    """
    
    def __init__(self, db_path: str = "forge_agents.db", llm_config_path: Optional[str] = None):
        # 부모 클래스 초기화를 건너뛰고 직접 초기화
        self.db_path = db_path
        self.current_generation_id = None
        self.stream_callback = None
        
        # LLM 초기화
        config = {}
        if llm_config_path and Path(llm_config_path).exists():
            import yaml
            with open(llm_config_path, 'r') as f:
                config = yaml.safe_load(f)
        
        self.llm = LLMOrchestrator(config=config)
        
        # 개선된 컴포넌트 사용
        self.query_analyzer = QueryAnalyzer(self.llm)
        self.template_generator = EnhancedTemplateGenerator()  # 개선된 버전 사용
        self.data_generator = IntelligentDataGenerator()
        
        logger.info("🚀 Enhanced FORGE Pipeline initialized")
        
    async def generate_agent(self, query: str, user_email: str, 
                           stream_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """통합된 에이전트 생성 프로세스"""
        
        self.current_generation_id = str(uuid.uuid4())[:8]
        self.stream_callback = stream_callback
        
        logger.info(f"🎯 Starting enhanced agent generation - ID: {self.current_generation_id}")
        logger.info(f"📝 Query: {query}")
        
        try:
            # Phase 1: 쿼리 분석
            await self._update_status("analyzing", "🔍 요청을 분석하고 있습니다...")
            analysis = await self.query_analyzer.analyze(query)
            
            logger.info(f"✅ Query analysis complete:")
            logger.info(f"  - Intent: {analysis.intent}")
            logger.info(f"  - Domain: {analysis.domain}")
            logger.info(f"  - Capabilities: {analysis.required_capabilities}")
            logger.info(f"  - Complexity: {analysis.complexity}")
            
            # Phase 2: 템플릿 선택 (개선된 알고리즘 사용)
            await self._update_status("selecting", "🎯 최적의 템플릿을 선택하고 있습니다...")
            
            template_id, confidence = await self.template_generator.select_template(
                user_request=query,
                analysis=analysis  # 분석 결과 전달
            )
            
            logger.info(f"✅ Template selected: {template_id} (confidence: {confidence:.2f})")
            
            if confidence < 0.5:
                logger.warning(f"Low template confidence: {confidence:.2f}")
            
            # Phase 3: 비즈니스 로직 생성 (도메인 인식)
            await self._update_status("generating", "💡 비즈니스 로직을 생성하고 있습니다...")
            
            # LLM 클라이언트 래퍼 생성
            class LLMClient:
                def __init__(self, orchestrator):
                    self.orchestrator = orchestrator
                    
                async def invoke(self, prompt: str) -> str:
                    return await self.orchestrator.generate(
                        prompt=prompt,
                        task_type=TaskType.CODE_GENERATION,
                        max_tokens=2000
                    )
            
            llm_client = LLMClient(self.llm)
            
            business_logic = await self.template_generator.generate_business_logic(
                template_id=template_id,
                user_request=query,
                analysis=analysis,  # 분석 결과 전달
                llm_client=llm_client
            )
            
            logger.info(f"✅ Business logic generated with {len(business_logic)} sections")
            
            # Phase 4: 최종 코드 조립
            await self._update_status("assembling", "🔧 에이전트 코드를 조립하고 있습니다...")
            
            # 템플릿 경로 구성
            template_info = self.template_generator.template_registry["templates"].get(template_id, {})
            template_file = template_info.get("file", f"{template_id}.py")
            template_path = self.template_generator.templates_dir / template_file
            
            # 템플릿에 비즈니스 로직 주입
            final_code = await self.template_generator.inject_business_logic(
                template_path,
                business_logic
            )
            
            logger.info(f"✅ Final code assembled: {len(final_code)} characters")
            
            # Phase 5: 코드 검증
            await self._update_status("validating", "✅ 생성된 코드를 검증하고 있습니다...")
            
            validation_result = self.template_generator.validate_generated_code(
                final_code,
                analysis
            )
            
            if not validation_result['is_valid']:
                logger.warning(f"Code validation issues: {validation_result['issues']}")
            
            # Phase 6: 샘플 데이터 준비
            test_data = business_logic.get("test_data", {})
            if not test_data and analysis.domain:
                # IntelligentDataGenerator로 테스트 데이터 생성
                requirements = self.data_generator.analyze_code_requirements(final_code)
                test_suite = self.data_generator.generate_test_data(
                    requirements,
                    domain=analysis.domain
                )
                test_data = test_suite.normal
            
            # Phase 7: 결과 준비
            await self._update_status("completed", "🎉 에이전트 생성이 완료되었습니다!")
            
            # 템플릿 사용 기록
            self.template_generator.record_template_usage(
                template_id,
                query,
                validation_result['is_valid']
            )
            
            result = {
                'success': True,
                'agent_id': self.current_generation_id,
                'code': final_code,
                'template_used': template_id,
                'confidence': confidence,
                'analysis': analysis.to_dict(),
                'business_logic': business_logic,
                'validation': validation_result,
                'test_data': test_data,
                'metadata': {
                    'generation_time': datetime.now().isoformat(),
                    'domain': analysis.domain,
                    'intent': analysis.intent,
                    'capabilities': analysis.required_capabilities
                }
            }
            
            logger.info(f"🎉 Agent generation completed successfully!")
            return result
            
        except Exception as e:
            logger.error(f"❌ Agent generation failed: {e}")
            import traceback
            error_details = traceback.format_exc()
            logger.error(f"Full error trace:\n{error_details}")
            
            await self._update_status("failed", f"❌ 에이전트 생성 실패: {str(e)}")
            
            return {
                'success': False,
                'error': str(e),
                'error_details': error_details,
                'generation_id': self.current_generation_id
            }
            
    async def _update_status(self, status: str, message: str, data: Dict = None):
        """상태 업데이트"""
        if self.stream_callback:
            await self.stream_callback(status, message, data or {})