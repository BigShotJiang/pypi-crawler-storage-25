"""
Growing Adapter
================
Wraps Paper2 SelfGrowingSystem for production integration.
"""

import sys
import os
import logging
from typing import Dict, Any, Optional, List

from ..config import EvolutionConfig
from ..models import PreGenerationResult, GapInfo, AdmissionInfo

logger = logging.getLogger(__name__)

# Add Paper2 implementations to path
_paper2_path = os.path.join(
    os.path.dirname(__file__), '..', '..', '..',
    'forge', 'paper', 'paper2', 'v1_self_evolution', 'experiments', 'implementations'
)
_paper2_path = os.path.normpath(_paper2_path)


def _import_paper2_growing():
    """Lazy import of Paper2 SelfGrowingSystem."""
    if _paper2_path not in sys.path:
        sys.path.insert(0, _paper2_path)
    try:
        from self_growing import (
            SelfGrowingSystem, FunctionExtractor, EmbeddingService,
            FunctionSlice, FunctionSliceMetadata, SliceOrigin
        )
        return SelfGrowingSystem, FunctionExtractor, EmbeddingService
    except ImportError as e:
        logger.error(f"Failed to import Paper2 SelfGrowingSystem: {e}")
        return None, None, None


def _load_library() -> Dict:
    """Load the 169-slice production library."""
    try:
        # Try library_adapter from Paper2 experiments
        if _paper2_path not in sys.path:
            sys.path.insert(0, _paper2_path)

        # Also add experiment root for library_adapter
        exp_path = os.path.join(
            os.path.dirname(__file__), '..', '..', '..',
            'forge', 'paper', 'paper2', 'v1_self_evolution', 'experiments'
        )
        exp_path = os.path.normpath(exp_path)
        if exp_path not in sys.path:
            sys.path.insert(0, exp_path)

        from library_adapter import load_real_library
        library = load_real_library()
        logger.info(f"Loaded production library: {len(library)} slices")
        return library
    except ImportError:
        logger.warning("library_adapter not available, using empty library")
        return {}
    except Exception as e:
        logger.warning(f"Failed to load library: {e}")
        return {}


class GrowingAdapter:
    """Adapter wrapping Paper2 SelfGrowingSystem for production use."""

    def __init__(self, config: EvolutionConfig):
        self.config = config
        self._system = None
        self._extractor = None
        self._library = None
        self._initialized = False

    def _ensure_initialized(self):
        """Lazy initialization of Paper2 components."""
        if self._initialized:
            return

        SelfGrowingSystem, FunctionExtractor, _ = _import_paper2_growing()

        if SelfGrowingSystem:
            self._system = SelfGrowingSystem(
                tau_match=self.config.tau_match,
                tau_quality=self.config.tau_quality,
                enable_rate_limiting=self.config.enable_rate_limiting,
            )
            logger.info(f"SelfGrowingSystem initialized (tau_match={self.config.tau_match})")

        if FunctionExtractor:
            self._extractor = FunctionExtractor(model_name=self.config.llm_model)
            logger.info("FunctionExtractor initialized")

        # Load library
        self._library = _load_library()

        self._initialized = True

    async def analyze_coverage(self, query: str, stream_callback=None) -> PreGenerationResult:
        """
        Analyze query coverage against slice library.

        Args:
            query: User query for agent generation
            stream_callback: Optional callback for streaming progress

        Returns:
            PreGenerationResult with coverage and gap information
        """
        self._ensure_initialized()

        if not self._system or not self._extractor:
            return PreGenerationResult(details={"error": "Self-Growing system not available"})

        try:
            # Stream: gap detection started
            if stream_callback:
                await stream_callback({
                    "type": "progress",
                    "stage": "evolution_gap_detection",
                    "message": "Analyzing coverage gaps...",
                })

            # Extract function requirements from query
            requirements = self._extractor.extract(query)
            logger.info(f"Extracted {len(requirements)} function requirements")

            # Analyze coverage
            coverage, gap_results = self._system.coverage_analyzer.analyze_coverage(
                requirements, self._library
            )

            gaps = []
            for gap_result in gap_results:
                gaps.append(GapInfo(
                    function_name=gap_result.function.name,
                    description=gap_result.function.description,
                    best_match_score=gap_result.best_match_score,
                    is_gap=gap_result.is_gap,
                ))

            gap_count = sum(1 for g in gaps if g.is_gap)

            # Stream: gap detection complete
            if stream_callback:
                await stream_callback({
                    "type": "progress",
                    "stage": "evolution_gap_detection",
                    "message": f"Coverage: {coverage*100:.1f}% ({gap_count} gaps detected)",
                    "data": {"coverage": coverage, "gaps": gap_count},
                })

            return PreGenerationResult(
                coverage=coverage,
                gaps_detected=gap_count,
                gaps=gaps,
                templates_retrieved=0,
                library_size=len(self._library),
            )

        except Exception as e:
            logger.error(f"Coverage analysis failed: {e}")
            return PreGenerationResult(details={"error": str(e)})

    async def admit_to_library(
        self, code: str, query: str, quality_score: Optional[float] = None,
        stream_callback=None
    ) -> AdmissionInfo:
        """
        Attempt to admit generated code as a new slice to the library.

        Args:
            code: Generated agent code
            query: Original query
            quality_score: Quality score from evaluation
            stream_callback: Optional streaming callback

        Returns:
            AdmissionInfo with decision
        """
        self._ensure_initialized()

        if not self._system:
            return AdmissionInfo(decision="skip", message="Self-Growing not available")

        if quality_score is not None and quality_score < self.config.tau_quality:
            return AdmissionInfo(
                decision="reject",
                message=f"Quality {quality_score:.3f} below threshold {self.config.tau_quality}"
            )

        if stream_callback:
            await stream_callback({
                "type": "progress",
                "stage": "evolution_admission",
                "message": "Library admission decision...",
            })

        # Quality gate: check telemetry success rate if available
        telemetry_ok = True
        try:
            from core.function_telemetry import FunctionTelemetry
            tel = FunctionTelemetry.get_instance()
            # Extract function names from code to check their telemetry
            import re
            func_names = re.findall(r'async def (_\w+)\(', code)
            for fn in func_names:
                stats = tel.get_function_stats(fn)
                if stats["call_count"] >= 3 and stats["success_rate"] < self.config.tau_quality:
                    telemetry_ok = False
                    logger.info(f"[Growing] {fn} blocked: success_rate={stats['success_rate']}")
                    break
        except Exception:
            pass  # Telemetry not available — skip check

        # Auto-admit if quality + telemetry are both good
        if quality_score is not None and quality_score >= self.config.tau_quality and telemetry_ok:
            try:
                admitted = self._system.admit_to_library(code, query, quality_score)
                if admitted:
                    return AdmissionInfo(
                        decision="admit",
                        message=f"Admitted to library (quality={quality_score:.3f})"
                    )
            except Exception as e:
                logger.debug(f"Library admission failed, using session cache: {e}")

        return AdmissionInfo(
            decision="session_cache",
            message="Added to session cache"
        )

    def get_statistics(self) -> Dict[str, Any]:
        """Get Self-Growing statistics."""
        if self._system:
            stats = self._system.get_statistics()
            stats["library_size"] = len(self._library) if self._library else 0
            return stats
        return {"status": "not_initialized"}
