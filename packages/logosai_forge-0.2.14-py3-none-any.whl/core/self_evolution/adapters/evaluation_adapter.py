"""
Evaluation Adapter
===================
Wraps Paper2 SelfEvaluationSystem for production integration.
"""

import sys
import os
import hashlib
import logging
from typing import Optional

from ..config import EvolutionConfig
from ..models import EvaluationScore

logger = logging.getLogger(__name__)

# Add Paper2 implementations to path
_paper2_path = os.path.join(
    os.path.dirname(__file__), '..', '..', '..',
    'forge', 'paper', 'paper2', 'v1_self_evolution', 'experiments', 'implementations'
)
_paper2_path = os.path.normpath(_paper2_path)


def _import_paper2_evaluation():
    """Lazy import of Paper2 SelfEvaluationSystem."""
    if _paper2_path not in sys.path:
        sys.path.insert(0, _paper2_path)
    try:
        from self_evaluation import SelfEvaluationSystem
        return SelfEvaluationSystem
    except ImportError as e:
        logger.error(f"Failed to import Paper2 SelfEvaluationSystem: {e}")
        return None


class EvaluationAdapter:
    """Adapter wrapping Paper2 SelfEvaluationSystem for production use."""

    def __init__(self, config: EvolutionConfig):
        self.config = config
        self._system = None
        self._initialized = False
        self._eval_count = 0

    def _ensure_initialized(self):
        """Lazy initialization of Paper2 evaluation system."""
        if self._initialized:
            return

        SelfEvaluationSystem = _import_paper2_evaluation()

        if SelfEvaluationSystem:
            self._system = SelfEvaluationSystem(
                use_llm=True,
                model_name=self.config.llm_model,
            )
            logger.info(f"SelfEvaluationSystem initialized (LLM: {self.config.llm_model})")

        self._initialized = True

    async def evaluate(
        self, code: str, query: str, stream_callback=None
    ) -> Optional[EvaluationScore]:
        """
        Evaluate generated agent code quality.

        Args:
            code: Generated agent code
            query: Original user query
            stream_callback: Optional streaming callback

        Returns:
            EvaluationScore with multi-dimensional quality metrics
        """
        self._ensure_initialized()

        if not self._system:
            return None

        try:
            if stream_callback:
                await stream_callback({
                    "type": "progress",
                    "stage": "evolution_evaluation",
                    "message": "Evaluating agent quality...",
                })

            # Generate agent ID from code hash
            agent_id = f"forge_{hashlib.md5(code[:200].encode()).hexdigest()[:8]}"

            # Run Paper2 evaluation
            result = self._system.evaluate(
                agent_id=agent_id,
                agent_code=code,
                query=query,
                test_cases=[{"input": query, "required_elements": ["LogosAIAgent", "process"]}],
            )

            self._eval_count += 1

            logger.info(
                f"Raw eval scores: functional={result.functional_score:.3f}, "
                f"code_quality={result.code_quality_score:.3f}, "
                f"func_details={result.details.get('functional', {})}"
            )

            score = EvaluationScore(
                functional=result.functional_score,
                code_quality=result.code_quality_score,
                performance=result.performance_score,
                user_feedback=result.user_feedback_score,
                llm_semantic=result.details.get("llm_semantic", {}).get("semantic_evaluation", {}).get("overall", 0.0),
                overall=result.overall_score,
                recommendations=result.recommendations or [],
            )

            if stream_callback:
                await stream_callback({
                    "type": "progress",
                    "stage": "evolution_evaluation",
                    "message": f"Quality score: {score.overall:.3f}",
                    "data": score.to_dict(),
                })

            logger.info(f"Evaluation complete: overall={score.overall:.3f}")
            return score

        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return None

    def get_eval_count(self) -> int:
        """Get total evaluation count."""
        return self._eval_count
