"""
Healing Adapter
================
Wraps Paper2 SelfHealingSystem for production integration.
"""

import sys
import os
import logging
from typing import Dict, Any, Optional

from ..config import EvolutionConfig
from ..models import HealingInfo

logger = logging.getLogger(__name__)

# Add Paper2 implementations to path
_paper2_path = os.path.join(
    os.path.dirname(__file__), '..', '..', '..',
    'forge', 'paper', 'paper2', 'v1_self_evolution', 'experiments', 'implementations'
)
_paper2_path = os.path.normpath(_paper2_path)


def _import_paper2_healing():
    """Lazy import of Paper2 SelfHealingSystem."""
    if _paper2_path not in sys.path:
        sys.path.insert(0, _paper2_path)
    try:
        from self_healing import SelfHealingSystem
        return SelfHealingSystem
    except ImportError as e:
        logger.error(f"Failed to import Paper2 SelfHealingSystem: {e}")
        return None


class HealingAdapter:
    """Adapter wrapping Paper2 SelfHealingSystem for production use."""

    def __init__(self, config: EvolutionConfig):
        self.config = config
        self._system = None
        self._initialized = False

    def _ensure_initialized(self):
        """Lazy initialization of Paper2 healing system."""
        if self._initialized:
            return

        SelfHealingSystem = _import_paper2_healing()

        if SelfHealingSystem:
            self._system = SelfHealingSystem(enable_llm=True)
            logger.info("Paper2 SelfHealingSystem initialized")

        self._initialized = True

    async def heal(
        self, code: str, quality_score: Optional[float] = None,
        stream_callback=None
    ) -> tuple:
        """
        Heal generated agent code using Paper2's 3-stage process.

        Args:
            code: Generated agent code to heal
            quality_score: Quality score from evaluation (for prioritization)
            stream_callback: Optional streaming callback

        Returns:
            Tuple of (healed_code_or_None, HealingInfo)
        """
        self._ensure_initialized()

        if not self._system:
            return None, HealingInfo()

        try:
            if stream_callback:
                await stream_callback({
                    "type": "progress",
                    "stage": "evolution_healing",
                    "message": "Applying self-healing...",
                })

            # Run Paper2 healing (synchronous - HealingResult is a dataclass)
            result = self._system.heal(code, quality_score=quality_score)

            # Access dataclass fields with getattr (not .get())
            success = getattr(result, 'success', False)
            healed_code = getattr(result, 'healed_code', code)
            stage_used = getattr(result, 'stage_used', None)
            repairs_applied = getattr(result, 'repairs_applied', [])
            errors_fixed = getattr(result, 'errors_fixed', [])
            errors_remaining = getattr(result, 'errors_remaining', [])
            confidence = getattr(result, 'confidence', 0.0)

            info = HealingInfo(
                success=success,
                stage_used=stage_used.value if stage_used else "",
                repairs_count=len(repairs_applied),
                confidence=confidence,
                errors_fixed=len(errors_fixed),
                errors_remaining=len(errors_remaining),
            )

            if stream_callback:
                status = "healed" if success else "partial"
                await stream_callback({
                    "type": "progress",
                    "stage": "evolution_healing",
                    "message": f"Healing {status}: {len(repairs_applied)} repairs, confidence {confidence:.2f}",
                    "data": info.to_dict(),
                })

            # Only return healed code if it actually changed
            changed_code = healed_code if healed_code != code else None

            logger.info(f"Healing {'success' if success else 'partial'}: {len(repairs_applied)} repairs")
            return changed_code, info

        except Exception as e:
            logger.error(f"Healing failed: {e}")
            return None, HealingInfo()

    def get_statistics(self) -> Dict[str, Any]:
        """Get healing statistics."""
        if self._system:
            return self._system.get_statistics()
        return {"status": "not_initialized"}
