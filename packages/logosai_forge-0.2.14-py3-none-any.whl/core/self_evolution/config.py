"""
Evolution Configuration
========================
Feature flags and threshold management for Self-Evolution integration.
"""

import os
from dataclasses import dataclass, field


@dataclass
class EvolutionConfig:
    """Configuration for Self-Evolution integration."""

    # Master switch (default ON for full lifecycle integration)
    enabled: bool = True

    # Individual system toggles
    enable_growing: bool = True
    enable_evaluation: bool = True
    enable_healing: bool = True

    # Self-Growing thresholds
    tau_match: float = 0.40
    tau_quality: float = 0.70
    top_k: int = 3

    # LLM settings
    llm_model: str = "gemini-2.5-flash-lite"

    # Library path (None = auto-detect from forge/core/slice_library/)
    library_path: str = None

    # Rate limiting
    enable_rate_limiting: bool = True

    @classmethod
    def from_env(cls) -> 'EvolutionConfig':
        """Load configuration from environment variables."""
        return cls(
            enabled=os.getenv('FORGE_ENABLE_SELF_EVOLUTION', 'true').lower() == 'true',
            enable_growing=os.getenv('FORGE_EVOLUTION_GROWING', 'true').lower() == 'true',
            enable_evaluation=os.getenv('FORGE_EVOLUTION_EVALUATION', 'true').lower() == 'true',
            enable_healing=os.getenv('FORGE_EVOLUTION_HEALING', 'true').lower() == 'true',
            tau_match=float(os.getenv('FORGE_EVOLUTION_TAU_MATCH', '0.40')),
            tau_quality=float(os.getenv('FORGE_EVOLUTION_TAU_QUALITY', '0.70')),
            top_k=int(os.getenv('FORGE_EVOLUTION_TOP_K', '3')),
            llm_model=os.getenv('FORGE_EVOLUTION_LLM_MODEL', 'gemini-2.5-flash-lite'),
        )
