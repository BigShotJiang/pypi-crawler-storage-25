"""
FORGE Self-Evolution Module
============================
Production integration of Paper2 Self-Evolution systems.

Provides:
- EvolutionOrchestrator: Main facade for pre/post-generation evolution
- EvolutionConfig: Feature flags and threshold configuration
- Adapters: Wrappers around Paper2 SelfGrowing, SelfEvaluation, SelfHealing
"""

from .config import EvolutionConfig
from .orchestrator import EvolutionOrchestrator
from .models import PreGenerationResult, PostGenerationResult, EvolutionMetrics

__all__ = [
    "EvolutionConfig",
    "EvolutionOrchestrator",
    "PreGenerationResult",
    "PostGenerationResult",
    "EvolutionMetrics",
]
