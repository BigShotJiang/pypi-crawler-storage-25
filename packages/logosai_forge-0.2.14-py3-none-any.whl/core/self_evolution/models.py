"""
Evolution Data Models
======================
Data classes for Self-Evolution integration results.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List


@dataclass
class GapInfo:
    """Information about a detected coverage gap."""
    function_name: str
    description: str
    best_match_score: float
    is_gap: bool


@dataclass
class PreGenerationResult:
    """Result of pre-generation evolution analysis."""
    coverage: float = 1.0
    gaps_detected: int = 0
    gaps: List[GapInfo] = field(default_factory=list)
    templates_retrieved: int = 0
    library_size: int = 0
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "coverage": self.coverage,
            "gaps_detected": self.gaps_detected,
            "gaps": [{"name": g.function_name, "score": g.best_match_score, "is_gap": g.is_gap} for g in self.gaps],
            "templates_retrieved": self.templates_retrieved,
            "library_size": self.library_size,
        }


@dataclass
class EvaluationScore:
    """Quality evaluation scores from Self-Evaluation."""
    functional: float = 0.0
    code_quality: float = 0.0
    performance: float = 0.0
    user_feedback: float = 0.0
    llm_semantic: float = 0.0
    overall: float = 0.0
    recommendations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "functional": self.functional,
            "code_quality": self.code_quality,
            "performance": self.performance,
            "user_feedback": self.user_feedback,
            "llm_semantic": self.llm_semantic,
            "overall": self.overall,
            "recommendations": self.recommendations[:5],
        }


@dataclass
class HealingInfo:
    """Information about healing applied."""
    success: bool = False
    stage_used: str = ""
    repairs_count: int = 0
    confidence: float = 0.0
    errors_fixed: int = 0
    errors_remaining: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "stage_used": self.stage_used,
            "repairs_count": self.repairs_count,
            "confidence": self.confidence,
            "errors_fixed": self.errors_fixed,
            "errors_remaining": self.errors_remaining,
        }


@dataclass
class AdmissionInfo:
    """Information about library admission decision."""
    decision: str = "skip"  # admit, session_cache, reject, skip
    message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"decision": self.decision, "message": self.message}


@dataclass
class PostGenerationResult:
    """Result of post-generation evolution processing."""
    evaluation: Optional[EvaluationScore] = None
    healing: Optional[HealingInfo] = None
    healed_code: Optional[str] = None
    admission: Optional[AdmissionInfo] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        result = {}
        if self.evaluation:
            result["evaluation"] = self.evaluation.to_dict()
        if self.healing:
            result["healing"] = self.healing.to_dict()
        if self.admission:
            result["admission"] = self.admission.to_dict()
        return result


@dataclass
class EvolutionMetrics:
    """Aggregate metrics for evolution system."""
    growing_stats: Dict[str, Any] = field(default_factory=dict)
    evaluation_count: int = 0
    healing_stats: Dict[str, Any] = field(default_factory=dict)
    library_size: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "growing": self.growing_stats,
            "evaluation_count": self.evaluation_count,
            "healing": self.healing_stats,
            "library_size": self.library_size,
        }
