"""
Evolution Orchestrator
=======================
Main facade for Self-Evolution integration into ForgeV2System.

Provides pre_generation() and post_generation() hooks that wrap
Paper2's SelfGrowing, SelfEvaluation, and SelfHealing systems.
"""

import logging
from typing import Dict, Any, Optional

from .config import EvolutionConfig
from .models import PreGenerationResult, PostGenerationResult, EvolutionMetrics
from .adapters import GrowingAdapter, EvaluationAdapter, HealingAdapter

logger = logging.getLogger(__name__)


class EvolutionOrchestrator:
    """
    Main facade for Self-Evolution integration.

    Usage in ForgeV2System.create_agent():
        1. pre_generation(query) → gap detection, coverage analysis
        2. [existing code generation]
        3. post_generation(code, query) → evaluation, healing, admission
    """

    def __init__(self, config: EvolutionConfig):
        self.config = config

        self.growing = GrowingAdapter(config) if config.enable_growing else None
        self.evaluator = EvaluationAdapter(config) if config.enable_evaluation else None
        self.healer = HealingAdapter(config) if config.enable_healing else None

        logger.info(
            f"EvolutionOrchestrator initialized "
            f"(growing={config.enable_growing}, "
            f"evaluation={config.enable_evaluation}, "
            f"healing={config.enable_healing})"
        )

    async def pre_generation(
        self, query: str, stream_callback=None
    ) -> PreGenerationResult:
        """
        Pre-generation hook: analyze query coverage against slice library.

        Args:
            query: User query for agent generation
            stream_callback: Optional callback for streaming progress events

        Returns:
            PreGenerationResult with coverage and gap information
        """
        if not self.growing:
            return PreGenerationResult()

        try:
            return await self.growing.analyze_coverage(query, stream_callback)
        except Exception as e:
            logger.error(f"Pre-generation failed: {e}")
            return PreGenerationResult(details={"error": str(e)})

    async def post_generation(
        self,
        code: str,
        query: str,
        metadata: Dict[str, Any],
        stream_callback=None,
    ) -> PostGenerationResult:
        """
        Post-generation hook: evaluate quality, heal errors, decide admission.

        Args:
            code: Generated agent code
            query: Original user query
            metadata: Generation metadata
            stream_callback: Optional streaming callback

        Returns:
            PostGenerationResult with evaluation, healing, and admission info
        """
        result = PostGenerationResult()
        current_code = code

        try:
            # Step 1: Heal first (fix syntax/structural errors)
            if self.healer:
                healed_code, healing_info = await self.healer.heal(
                    current_code, None, stream_callback
                )
                result.healing = healing_info

                if healed_code:
                    result.healed_code = healed_code
                    current_code = healed_code

            # Step 2: Evaluate quality (on healed code for accurate scores)
            if self.evaluator:
                evaluation = await self.evaluator.evaluate(
                    current_code, query, stream_callback
                )
                result.evaluation = evaluation

            # Step 3: Library admission
            if self.growing:
                quality = result.evaluation.overall if result.evaluation else None
                admission = await self.growing.admit_to_library(
                    current_code, query, quality, stream_callback
                )
                result.admission = admission

        except Exception as e:
            logger.error(f"Post-generation failed: {e}")
            result.details["error"] = str(e)

        return result

    def get_metrics(self) -> EvolutionMetrics:
        """Get aggregate evolution metrics."""
        metrics = EvolutionMetrics()

        if self.growing:
            metrics.growing_stats = self.growing.get_statistics()
            metrics.library_size = metrics.growing_stats.get("library_size", 0)

        if self.evaluator:
            metrics.evaluation_count = self.evaluator.get_eval_count()

        if self.healer:
            metrics.healing_stats = self.healer.get_statistics()

        return metrics
