"""
Business Logic Extractor for FORGE AI
Extracts business logic from user queries and converts to pseudo-code
"""

import json
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

class BusinessDomain(Enum):
    """Business domains with specific patterns"""
    ECOMMERCE = "ecommerce"
    FINANCE = "finance" 
    HEALTHCARE = "healthcare"
    EDUCATION = "education"
    LOGISTICS = "logistics"
    GENERAL = "general"

@dataclass
class BusinessRule:
    """Represents a business rule"""
    condition: str
    action: str
    parameters: Dict[str, Any]
    priority: int = 0

@dataclass 
class BusinessLogic:
    """Extracted business logic"""
    domain: BusinessDomain
    intent: str
    entities: Dict[str, List[str]]
    rules: List[BusinessRule]
    pseudo_code: str
    template_variables: Dict[str, str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'domain': self.domain.value,
            'intent': self.intent,
            'entities': self.entities,
            'rules': [
                {
                    'condition': r.condition,
                    'action': r.action,
                    'parameters': r.parameters,
                    'priority': r.priority
                } for r in self.rules
            ],
            'pseudo_code': self.pseudo_code,
            'template_variables': self.template_variables
        }


class BusinessLogicExtractor:
    """Extracts business logic from queries"""
    
    # 추천: 도메인별 비즈니스 패턴 정의
    DOMAIN_PATTERNS = {
        BusinessDomain.ECOMMERCE: {
            'entities': ['customer', 'order', 'product', 'cart', 'payment', 'inventory'],
            'actions': ['purchase', 'checkout', 'discount', 'recommend', 'track'],
            'rules': [
                ('discount', 'IF customer.loyalty_level >= {threshold} THEN apply_discount({percentage})'),
                ('inventory', 'IF product.stock < {min_stock} THEN trigger_reorder()'),
                ('recommendation', 'IF customer.purchase_history CONTAINS {category} THEN recommend_similar()')
            ]
        },
        BusinessDomain.FINANCE: {
            'entities': ['account', 'transaction', 'balance', 'risk', 'portfolio'],
            'actions': ['transfer', 'calculate', 'validate', 'alert', 'analyze'],
            'rules': [
                ('risk', 'IF transaction.amount > {limit} THEN require_approval()'),
                ('alert', 'IF account.balance < {minimum} THEN send_notification()'),
                ('fraud', 'IF transaction.pattern MATCHES {suspicious} THEN flag_for_review()')
            ]
        },
        BusinessDomain.HEALTHCARE: {
            'entities': ['patient', 'appointment', 'medication', 'diagnosis', 'treatment'],
            'actions': ['schedule', 'prescribe', 'monitor', 'alert', 'update'],
            'rules': [
                ('medication', 'IF patient.allergies CONTAINS {drug} THEN block_prescription()'),
                ('monitoring', 'IF vital_signs OUTSIDE {normal_range} THEN alert_doctor()'),
                ('appointment', 'IF no_show_count > {threshold} THEN send_reminder()')
            ]
        }
    }
    
    def extract_business_logic(self, query: str, context: Optional[Dict[str, Any]] = None) -> BusinessLogic:
        """Extract business logic from query"""
        
        # 1. Identify domain
        domain = self._identify_domain(query)
        
        # 2. Extract entities and intent
        entities = self._extract_entities(query, domain)
        intent = self._extract_intent(query, entities)
        
        # 3. Generate business rules
        rules = self._generate_rules(query, domain, entities)
        
        # 4. Create pseudo-code
        pseudo_code = self._generate_pseudo_code(intent, entities, rules)
        
        # 5. Extract template variables
        template_vars = self._extract_template_variables(pseudo_code)
        
        return BusinessLogic(
            domain=domain,
            intent=intent,
            entities=entities,
            rules=rules,
            pseudo_code=pseudo_code,
            template_variables=template_vars
        )
    
    def _identify_domain(self, query: str) -> BusinessDomain:
        """Identify business domain from query"""
        query_lower = query.lower()
        
        # Score each domain based on keyword matches
        domain_scores = {}
        
        for domain, patterns in self.DOMAIN_PATTERNS.items():
            score = 0
            for entity in patterns['entities']:
                if entity in query_lower:
                    score += 2
            for action in patterns['actions']:
                if action in query_lower:
                    score += 1
            domain_scores[domain] = score
        
        # Return domain with highest score, default to GENERAL
        if max(domain_scores.values()) > 0:
            return max(domain_scores, key=domain_scores.get)
        return BusinessDomain.GENERAL
    
    def _extract_entities(self, query: str, domain: BusinessDomain) -> Dict[str, List[str]]:
        """Extract business entities from query"""
        entities = {
            'primary': [],
            'secondary': [],
            'actions': [],
            'conditions': []
        }
        
        query_lower = query.lower()
        
        if domain in self.DOMAIN_PATTERNS:
            patterns = self.DOMAIN_PATTERNS[domain]
            
            # Extract domain-specific entities
            for entity in patterns['entities']:
                if entity in query_lower:
                    entities['primary'].append(entity)
            
            # Extract actions
            for action in patterns['actions']:
                if action in query_lower:
                    entities['actions'].append(action)
        
        # Extract conditions
        condition_keywords = ['if', 'when', 'where', 'unless', 'while']
        for keyword in condition_keywords:
            if keyword in query_lower:
                entities['conditions'].append(keyword)
        
        return entities
    
    def _extract_intent(self, query: str, entities: Dict[str, List[str]]) -> str:
        """Extract primary intent from query"""
        # Simple heuristic based on actions and entities
        if entities['actions']:
            primary_action = entities['actions'][0]
            if entities['primary']:
                primary_entity = entities['primary'][0]
                return f"{primary_action}_{primary_entity}"
            return primary_action
        
        # Fallback to verb extraction
        verbs = ['create', 'analyze', 'process', 'monitor', 'generate', 'validate']
        query_lower = query.lower()
        for verb in verbs:
            if verb in query_lower:
                return verb
                
        return 'process_data'
    
    def _generate_rules(self, query: str, domain: BusinessDomain, entities: Dict[str, List[str]]) -> List[BusinessRule]:
        """Generate business rules based on query and domain"""
        rules = []
        
        # Apply domain-specific rule templates
        if domain in self.DOMAIN_PATTERNS:
            domain_rules = self.DOMAIN_PATTERNS[domain].get('rules', [])
            
            for rule_type, rule_template in domain_rules:
                # Check if rule type is relevant to query
                if any(keyword in query.lower() for keyword in [rule_type] + entities['actions']):
                    rule = BusinessRule(
                        condition=self._extract_condition(rule_template),
                        action=self._extract_action(rule_template),
                        parameters=self._extract_parameters(rule_template),
                        priority=self._calculate_priority(rule_type)
                    )
                    rules.append(rule)
        
        # Add custom rules based on query patterns
        if 'threshold' in query.lower() or 'limit' in query.lower():
            rules.append(BusinessRule(
                condition='value EXCEEDS threshold',
                action='trigger_action',
                parameters={'threshold': 'configurable'},
                priority=1
            ))
        
        return rules
    
    def _generate_pseudo_code(self, intent: str, entities: Dict[str, List[str]], rules: List[BusinessRule]) -> str:
        """Generate pseudo-code representation"""
        pseudo_code = f"""
FUNCTION {intent}(input_data):
    # Initialize
    result = initialize_result()
    
    # Validate input
    IF NOT validate_input(input_data):
        RETURN error("Invalid input")
    
    # Extract entities
"""
        
        # Add entity extraction
        for entity_type, entity_list in entities.items():
            if entity_list:
                pseudo_code += f"    {entity_type} = extract_{entity_type}(input_data)\n"
        
        # Add business rules
        if rules:
            pseudo_code += "\n    # Apply business rules\n"
            for rule in sorted(rules, key=lambda r: r.priority, reverse=True):
                pseudo_code += f"    IF {rule.condition}:\n"
                pseudo_code += f"        {rule.action}\n"
        
        # Add processing logic
        pseudo_code += """
    # Main processing
    processed_data = process_entities(entities)
    
    # Generate output
    result = format_output(processed_data)
    
    RETURN result
"""
        
        return pseudo_code
    
    def _extract_template_variables(self, pseudo_code: str) -> Dict[str, str]:
        """Extract variables that need to be configured"""
        import re
        
        variables = {}
        
        # Find {variable} patterns
        var_pattern = r'\{(\w+)\}'
        matches = re.findall(var_pattern, pseudo_code)
        
        for var in matches:
            # Infer type based on name
            if 'threshold' in var or 'limit' in var:
                variables[var] = 'number'
            elif 'name' in var or 'category' in var:
                variables[var] = 'string'
            elif 'flag' in var or 'enabled' in var:
                variables[var] = 'boolean'
            else:
                variables[var] = 'any'
                
        return variables
    
    def _extract_condition(self, rule_template: str) -> str:
        """Extract condition from rule template"""
        if 'IF' in rule_template and 'THEN' in rule_template:
            return rule_template.split('THEN')[0].replace('IF', '').strip()
        return 'condition'
    
    def _extract_action(self, rule_template: str) -> str:
        """Extract action from rule template"""
        if 'THEN' in rule_template:
            return rule_template.split('THEN')[1].strip()
        return 'action()'
    
    def _extract_parameters(self, rule_template: str) -> Dict[str, Any]:
        """Extract parameters from rule template"""
        import re
        params = {}
        
        # Find {param} patterns
        matches = re.findall(r'\{(\w+)\}', rule_template)
        for match in matches:
            params[match] = 'configurable'
            
        return params
    
    def _calculate_priority(self, rule_type: str) -> int:
        """Calculate rule priority"""
        priority_map = {
            'security': 10,
            'validation': 8,
            'risk': 7,
            'discount': 5,
            'notification': 3,
            'default': 1
        }
        return priority_map.get(rule_type, priority_map['default'])


# Example usage
if __name__ == "__main__":
    # E-commerce example
    ecommerce_query = """
    Create an order processing system that applies discounts for VIP customers,
    checks inventory levels, and sends notifications when stock is low
    """
    
    extractor = BusinessLogicExtractor()
    logic = extractor.extract_business_logic(ecommerce_query)
    
    print("Domain:", logic.domain.value)
    print("Intent:", logic.intent)
    print("\nEntities:", json.dumps(logic.entities, indent=2))
    print("\nRules:")
    for rule in logic.rules:
        print(f"  - IF {rule.condition} THEN {rule.action}")
    print("\nPseudo-code:")
    print(logic.pseudo_code)
    print("\nTemplate variables:", logic.template_variables)