#!/usr/bin/env python3
"""
CalculatorAgent - Standalone Agent
==============================
간단한 계산기 에이전트를 만들어줘

이 에이전트는 외부 의존성 없이 독립적으로 실행됩니다.
"""

import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class CalculatorAgent:
    """간단한 계산기 에이전트를 만들어줘"""
    
    def __init__(self):
        """Initialize the agent"""
        self.name = "CalculatorAgent"
        self.description = "간단한 계산기 에이전트를 만들어줘"
        self.agent_type = "calculator"
        logger.info(f"{self.name} initialized")
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Process user query"""
        try:
            logger.info(f"Processing query: {query}")
            
            # Validate input
            if not query:
                return {
                    "status": "error",
                    "error": "Empty query"
                }
            
            # Initialize context
            if context is None:
                context = {}
            
            # 계산기 로직
            import re
            
            # 숫자 추출
            numbers = re.findall(r'-?\d+\.?\d*', query)
            if len(numbers) >= 2:
                num1, num2 = float(numbers[0]), float(numbers[1])
                
                # 연산 감지
                if '+' in query or '더하기' in query:
                    result = num1 + num2
                    operation = "더하기"
                elif '-' in query or '빼기' in query:
                    result = num1 - num2
                    operation = "빼기"
                elif '*' in query or '곱하기' in query:
                    result = num1 * num2
                    operation = "곱하기"
                elif '/' in query or '나누기' in query:
                    if num2 != 0:
                        result = num1 / num2
                        operation = "나누기"
                    else:
                        return {
                            "status": "error",
                            "error": "0으로 나눌 수 없습니다"
                        }
                else:
                    result = num1 + num2
                    operation = "더하기 (기본)"
                
                return {
                    "status": "success",
                    "result": result,
                    "operation": operation,
                    "expression": f"{num1} {operation} {num2} = {result}"
                }
            else:
                return {
                    "status": "error",
                    "error": "쿼리에서 충분한 숫자를 찾을 수 없습니다"
                }
            
        except Exception as e:
            logger.error(f"Processing error: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent information"""
        return {
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "capabilities": self._get_capabilities()
        }
    
    def _get_capabilities(self) -> List[str]:
        """Get agent capabilities"""
        capabilities_map = {
            "calculator": ["basic_arithmetic", "expression_evaluation"],
            "data_analysis": ["data_processing", "statistical_analysis"],
            "api_integration": ["http_requests", "json_parsing"],
            "web_scraping": ["html_parsing", "data_extraction"],
            "general_purpose": ["text_processing", "general_tasks"]
        }
        return capabilities_map.get(self.agent_type, ["general_processing"])


# 메인 실행 함수
async def main():
    """테스트 실행"""
    agent = CalculatorAgent()
    
    print(f"\n============================================================")
    print(f"{agent.name} 테스트")
    print('='*60)
    print(f"설명: {agent.description}")
    print(f"타입: {agent.agent_type}")
    print(f"기능: {', '.join(agent._get_capabilities())}")
    print('='*60)
    
    # 테스트 쿼리
    test_queries = ["10 더하기 5는?", "100에서 25 빼면?", "7 곱하기 8"]
    
    for query in test_queries:
        print(f"\n쿼리: {query}")
        result = await agent.process(query)
        print(f"결과: {json.dumps(result, ensure_ascii=False, indent=2)}")
    
    print(f"\n============================================================")
    print("테스트 완료!")


if __name__ == "__main__":
    asyncio.run(main())
