"""
Progressive Code Generator for FORGE AI
Generates code incrementally with visible progress
"""

import asyncio
from typing import Optional, Any, Callable, Dict, List
from datetime import datetime
from pathlib import Path
import re
from loguru import logger

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts


class ProgressiveCodeGenerator:
    """
    Generates code progressively in multiple stages, 
    allowing users to see the code being built step by step
    """
    
    def __init__(self, llm_orchestrator: LLMOrchestrator):
        """Initialize progressive code generator"""
        self.llm = llm_orchestrator
        self.template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template.py.template"
        
        # Load template
        try:
            with open(self.template_path, 'r') as f:
                self.template = f.read()
        except Exception as e:
            logger.error(f"Could not load template: {e}")
            self.template = ""
    
    async def generate_progressively(self, analysis: QueryAnalysis, context: Context,
                                    stream_callback: Optional[Callable] = None) -> Any:
        """Generate agent code progressively with visible stages"""
        
        start_time = datetime.now()
        code_stages = []
        
        try:
            # Stage 1: Basic structure (5 seconds)
            await self._stream_update(stream_callback, "structuring", 
                                    "📐 Creating agent structure...", 
                                    {"progress": 10, "stage": 1})
            
            basic_structure = await self._generate_basic_structure(analysis)
            code_stages.append(basic_structure)
            
            await self._stream_update(stream_callback, "preview",
                                    "Agent structure created",
                                    {"code_preview": basic_structure, "progress": 20})
            
            # Stage 2: Add initialization (5 seconds)
            await asyncio.sleep(0.5)  # Brief pause for visual effect
            await self._stream_update(stream_callback, "initializing",
                                    "🔧 Adding initialization logic...",
                                    {"progress": 30, "stage": 2})
            
            init_code = await self._add_initialization(analysis, basic_structure)
            code_stages.append(init_code)
            
            await self._stream_update(stream_callback, "preview",
                                    "Initialization added",
                                    {"code_preview": init_code[:500], "progress": 40})
            
            # Stage 3: Core business logic (10 seconds)
            await asyncio.sleep(0.5)
            await self._stream_update(stream_callback, "implementing",
                                    "💡 Implementing core business logic...",
                                    {"progress": 50, "stage": 3})
            
            business_code = await self._add_business_logic(analysis, init_code)
            code_stages.append(business_code)
            
            await self._stream_update(stream_callback, "preview",
                                    "Business logic implemented",
                                    {"code_preview": self._extract_method_preview(business_code, "process"),
                                     "progress": 70})
            
            # Stage 4: Add sample data and testing (5 seconds)
            await asyncio.sleep(0.5)
            await self._stream_update(stream_callback, "testing",
                                    "🧪 Adding sample data and tests...",
                                    {"progress": 80, "stage": 4})
            
            complete_code = await self._add_sample_data_and_tests(analysis, business_code)
            code_stages.append(complete_code)
            
            # Stage 5: Final optimization (5 seconds)
            await asyncio.sleep(0.5)
            await self._stream_update(stream_callback, "optimizing",
                                    "✨ Optimizing and polishing code...",
                                    {"progress": 90, "stage": 5})
            
            final_code = await self._optimize_and_polish(analysis, complete_code)
            
            # Complete
            await self._stream_update(stream_callback, "complete",
                                    "🎉 Agent generation complete!",
                                    {"progress": 100, "stages_completed": 5,
                                     "total_time": (datetime.now() - start_time).total_seconds()})
            
            # Create artifacts
            artifacts = GenerationArtifacts(
                generation_id=f"prog_gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            
            artifacts.query_analysis = {
                "intent": analysis.intent,
                "domain": analysis.domain,
                "complexity": analysis.complexity.value,
                "capabilities": analysis.required_capabilities
            }
            
            artifacts.generated_code_raw = final_code
            artifacts.optimized_code = final_code
            artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            artifacts.code_stages = code_stages  # Store all stages
            
            # Return result
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "progressive_generation"
            
            return GeneratedCode(code=final_code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Progressive generation failed: {e}")
            await self._stream_update(stream_callback, "error",
                                    f"❌ Generation failed: {str(e)}",
                                    {"error": str(e)})
            raise
    
    async def _stream_update(self, callback: Optional[Callable], status: str, 
                           message: str, data: Dict[str, Any] = None):
        """Send streaming update if callback is provided"""
        if callback:
            await callback(status, message, data or {})
    
    async def _generate_basic_structure(self, analysis: QueryAnalysis) -> str:
        """Generate basic agent structure"""
        
        prompt = f"""Create a basic LogosAI agent structure for this request:
{analysis.query}

Generate ONLY the class definition with imports and basic structure.
Include proper docstring but no implementation yet.

Example:
```python
from logosai import LogosAIAgent, AgentConfig, AgentType, AgentResponse
import pandas as pd

class MyAgent(LogosAIAgent):
    '''Agent description'''
    
    def __init__(self, config=None):
        # TODO: Initialize
        pass
    
    async def process(self, query):
        # TODO: Implement
        pass
```
"""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=2000,
            temperature=0.3,
            model_override="gemini-2.5-flash-lite"
        )
        
        return self._extract_code(result)
    
    async def _add_initialization(self, analysis: QueryAnalysis, current_code: str) -> str:
        """Add proper initialization to the agent"""
        
        # Extract agent name from the query or use default
        agent_name = self._extract_agent_name(analysis.query)
        
        prompt = f"""Add proper initialization to this agent:

Current code:
```python
{current_code}
```

Requirements:
- Initialize with proper AgentConfig with REQUIRED parameters
- Set agent name, type, and description based on: {analysis.query}
- Add any necessary instance variables
- Keep existing structure

IMPORTANT: AgentConfig requires 'name' and 'agent_type' parameters. Use this format:
```python
def __init__(self, config=None):
    if config is None:
        config = AgentConfig(
            name="{agent_name}",  # REQUIRED
            agent_type=AgentType.CUSTOM,  # REQUIRED
            description="Agent that {analysis.query.lower()}",
            config={{
                "model": "gemini-2.5-flash-lite",
                "temperature": 0.7,
                "max_tokens": 2000
            }}
        )
    super().__init__(config)
    
    # Initialize instance variables
    self.llm_client = None
```

Return the complete updated code with proper AgentConfig initialization.
"""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=3000,
            temperature=0.3,
            model_override="gemini-2.5-flash-lite"
        )
        
        return self._extract_code(result)
    
    async def _add_business_logic(self, analysis: QueryAnalysis, current_code: str) -> str:
        """Add core business logic implementation"""
        
        prompt = f"""Implement the core business logic for this agent:

Current code:
```python
{current_code}
```

Requirements based on user request: {analysis.query}

Key features to implement:
{chr(10).join([f"- {cap}" for cap in analysis.required_capabilities])}

Add complete implementation of:
1. An async initialize() method that sets up the LLM client:
   ```python
   async def initialize(self) -> bool:
       try:
           # Initialize LLM client or any external services
           self.llm_client = LLMClient(
               model=self.config.config.get("model", "gemini-2.5-flash-lite"),
               temperature=self.config.config.get("temperature", 0.7)
           )
           return True
       except Exception as e:
           logger.error(f"Failed to initialize: {{e}}")
           return False
   ```

2. Helper methods for data processing specific to this agent

3. Main process() method with PROPER parameter format:
   ```python
   async def process(self, query: str, context: Dict[str, Any] = None) -> AgentResponse:
       # Process the query
       # Return AgentResponse with correct format
   ```

4. IMPORTANT: AgentResponse must use this format:
   ```python
   return AgentResponse(
       type=AgentResponseType.SUCCESS,  # NOT status="SUCCESS"
       content={{"message": "...", "data": {{}}}}  # NOT separate message and data parameters
   )
   ```

5. For errors:
   ```python
   return AgentResponse(
       type=AgentResponseType.ERROR,
       content={{"error": str(e), "message": "Error message"}}
   )
   ```

Return the complete updated code with full implementation using the CORRECT AgentResponse format.
"""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=6000,
            temperature=0.4,
            model_override="gemini-2.5-flash-lite"
        )
        
        return self._extract_code(result)
    
    async def _add_sample_data_and_tests(self, analysis: QueryAnalysis, current_code: str) -> str:
        """Add sample data generation and test code"""
        
        prompt = f"""Add sample data and test code to this agent:

Current code:
```python
{current_code}
```

Add:
1. A method to generate realistic sample data
2. Main block with test scenarios
3. Example usage demonstrating all features

Make sure the test data is relevant to: {analysis.query}

Return the complete code with tests.
"""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=4000,
            temperature=0.4,
            model_override="gemini-2.5-flash-lite"
        )
        
        return self._extract_code(result)
    
    async def _optimize_and_polish(self, analysis: QueryAnalysis, current_code: str) -> str:
        """Final optimization and polishing pass"""
        
        prompt = f"""Polish and optimize this agent code:

```python
{current_code}
```

Improvements to make:
1. Add comprehensive docstrings
2. Optimize any inefficient code
3. Add type hints where missing
4. Ensure all imports are correct
5. Fix any syntax issues
6. Make sure it follows LogosAI best practices

Return the polished, production-ready code.
"""
        
        result = await self.llm.generate(
            prompt=prompt,
            task_type=TaskType.CODE_GENERATION,
            max_tokens=8000,
            temperature=0.2,
            model_override="gemini-2.5-flash-lite"
        )
        
        return self._extract_code(result)
    
    def _extract_code(self, response: str) -> str:
        """Extract Python code from LLM response"""
        
        # Try to find code block
        python_match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        if python_match:
            return python_match.group(1).strip()
        
        # Try any code block
        code_match = re.search(r'```\n(.*?)```', response, re.DOTALL)
        if code_match:
            return code_match.group(1).strip()
        
        # Return as is
        return response.strip()
    
    def _extract_agent_name(self, query: str) -> str:
        """Extract a suitable agent name from the query"""
        # Common patterns to extract agent names
        patterns = [
            r'(?:create|make|build|develop)\s+(?:a\s+)?(\w+)\s+agent',
            r'(\w+)\s+에이전트',
            r'agent\s+(?:for|that|to)\s+(\w+)',
            r'(\w+)\s+(?:monitoring|analyzing|managing|processing)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, query.lower())
            if match:
                name = match.group(1).title()
                return f"{name} Agent"
        
        # Default fallback
        if "calculator" in query.lower() or "계산" in query.lower():
            return "Calculator Agent"
        elif "weather" in query.lower() or "날씨" in query.lower():
            return "Weather Agent"
        elif "stock" in query.lower() or "주식" in query.lower():
            return "Stock Agent"
        elif "inventory" in query.lower() or "재고" in query.lower():
            return "Inventory Agent"
        elif "customer" in query.lower() or "고객" in query.lower():
            return "Customer Agent"
        else:
            return "Custom Agent"
    
    def _extract_method_preview(self, code: str, method_name: str) -> str:
        """Extract a preview of a specific method from code"""
        
        # Find the method
        pattern = rf'(async\s+)?def\s+{method_name}\s*\([^)]*\):[^:]*?(?=\n\s*(async\s+)?def|\nclass|\Z)'
        match = re.search(pattern, code, re.DOTALL)
        
        if match:
            preview = match.group(0).strip()
            if len(preview) > 500:
                preview = preview[:500] + "..."
            return preview
        
        return f"def {method_name}(...): # Implementation added"