"""
Business Logic Generation Module
"""

from .logic_generator import BusinessLogicGenerator, GeneratedLogic

__all__ = [
    'BusinessLogicGenerator',
    'GeneratedLogic'
]