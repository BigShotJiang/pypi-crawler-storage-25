"""
Ultimate Final Business Logic Generator - 모든 문제 해결
self 파라미터, 타입 import, 템플릿 이슈 모두 수정
"""

from typing import Dict, List, Any, Optional
import random
import re
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class UltimateFinalBusinessLogicGenerator:
    """완벽한 비즈니스 로직 생성기 - 모든 문법 문제 근본 해결"""
    
    def __init__(self):
        self.business_functions = self._load_business_functions()
        
    def _load_business_functions(self) -> Dict[str, Dict]:
        """클래스 메서드로 깨끗한 템플릿 로드"""
        return {
            "validate_data": {
                "description": "데이터 유효성 검증",
                "is_async": False,
                "template": '''def validate_data(self, data: Dict, validation_rules: Optional[Dict[str, Dict]] = None):
        """데이터 유효성 검증"""
        if validation_rules is None:
            validation_rules = {
                'email': {'type': 'string', 'pattern': r'^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$'},
                'age': {'type': 'int', 'min': 0, 'max': 120}
            }
        
        errors = []
        warnings = []
        
        for field, rules in validation_rules.items():
            value = data.get(field)
            
            if rules.get('required') and value is None:
                errors.append(f"{field} is required")
                continue
            
            if value is None:
                continue
            
            expected_type = rules.get('type')
            if expected_type:
                type_map = {'string': str, 'int': int, 'float': float, 'bool': bool, 'list': list, 'dict': dict}
                if expected_type in type_map and not isinstance(value, type_map[expected_type]):
                    errors.append(f"{field} must be {expected_type}, got {type(value).__name__}")
            
            if 'min' in rules and value < rules['min']:
                errors.append(f"{field} must be >= {rules['min']}, got {value}")
            if 'max' in rules and value > rules['max']:
                errors.append(f"{field} must be <= {rules['max']}, got {value}")
            
            if 'pattern' in rules:
                import re
                if not re.match(rules['pattern'], str(value)):
                    errors.append(f"{field} doesn't match pattern {rules['pattern']}")
            
            if 'choices' in rules and value not in rules['choices']:
                errors.append(f"{field} must be one of {rules['choices']}, got {value}")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'data': data
        }'''
            },
            
            "apply_discount": {
                "description": "할인율 적용",
                "is_async": False,
                "params": ["discount_rate"],
                "template": '''def apply_discount(self, price: float, discount_rate: float = <<<discount_rate>>>, min_price: float = 0):
        """할인율 적용"""
        if not 0 <= discount_rate <= 100:
            raise ValueError(f"Invalid discount rate: {discount_rate}")
        
        discounted_price = price * (1 - discount_rate / 100)
        final_price = max(discounted_price, min_price)
        
        return {
            'original_price': price,
            'discount_rate': discount_rate,
            'discount_amount': price - final_price,
            'final_price': final_price
        }'''
            },
            
            "check_threshold": {
                "description": "임계값 모니터링 및 알림",
                "is_async": True,
                "params": ["threshold", "monitor_field", "comparison"],
                "template": '''async def check_threshold(self, value: float, threshold: float = <<<threshold>>>, monitor_field: str = '<<<monitor_field>>>', comparison: str = '<<<comparison>>>'):
        """임계값 모니터링 및 알림"""
        alert_triggered = False
        
        if comparison == '<=':
            alert_triggered = value <= threshold
        elif comparison == '>=':
            alert_triggered = value >= threshold
        elif comparison == '<':
            alert_triggered = value < threshold
        elif comparison == '>':
            alert_triggered = value > threshold
        
        if alert_triggered:
            # f-string을 변수로 분리하여 dict literal과 충돌 방지
            alert_message = f'{monitor_field} alert: {value} {comparison} {threshold}'
            return {
                'alert': True,
                'message': alert_message,
                'severity': 'high' if abs(value - threshold) > threshold * 0.2 else 'medium',
                'value': value,
                'threshold': threshold
            }
        return {'alert': False}'''
            },
            
            "aggregate_data": {
                "description": "데이터 집계",
                "is_async": False,
                "params": ["group_by", "aggregation_field", "operation"],
                "template": '''def aggregate_data(self, data: List[Dict], group_by: str = '<<<group_by>>>', aggregation_field: str = '<<<aggregation_field>>>', operation: str = '<<<operation>>>'):
        """데이터 집계"""
        from collections import defaultdict
        import statistics
        
        groups = defaultdict(list)
        
        for item in data:
            key = item.get(group_by, 'unknown')
            value = item.get(aggregation_field, 0)
            groups[key].append(value)
        
        results = {}
        for key, values in groups.items():
            if not values:
                results[key] = 0
                continue
                
            if operation == 'sum':
                results[key] = sum(values)
            elif operation == 'avg' or operation == 'mean':
                results[key] = statistics.mean(values)
            elif operation == 'min':
                results[key] = min(values)
            elif operation == 'max':
                results[key] = max(values)
            elif operation == 'count':
                results[key] = len(values)
            elif operation == 'median':
                results[key] = statistics.median(values)
            else:
                results[key] = values
        
        return results'''
            },
            
            "transform_data": {
                "description": "데이터 변환",
                "is_async": False,
                "template": '''def transform_data(self, data: List[Dict], transformation_rules: Optional[Dict[str, Any]] = None):
        """데이터 변환"""
        if transformation_rules is None:
            transformation_rules = {}
            
        transformed = []
        
        for item in data:
            new_item = {}
            
            for field, rule in transformation_rules.items():
                if isinstance(rule, str):
                    new_item[field] = item.get(rule)
                elif isinstance(rule, dict):
                    source_field = rule.get('source')
                    transform_type = rule.get('type')
                    
                    value = item.get(source_field)
                    
                    if transform_type == 'uppercase':
                        new_item[field] = str(value).upper()
                    elif transform_type == 'lowercase':
                        new_item[field] = str(value).lower()
                    elif transform_type == 'multiply':
                        new_item[field] = value * rule.get('factor', 1)
                    elif transform_type == 'format':
                        format_str = rule.get('format', '{}')
                        new_item[field] = format_str.format(value)
                    else:
                        new_item[field] = value
                else:
                    new_item[field] = rule
            
            transformed.append(new_item)
        
        return transformed'''
            },
            
            "filter_by_tier": {
                "description": "등급별 필터링",
                "is_async": False,
                "template": '''def filter_by_tier(self, data: List[Dict], tier_field: str = 'user_tier', allowed_tiers: Optional[List[str]] = None):
        """등급별 필터링"""
        if allowed_tiers is None:
            allowed_tiers = ['A', 'B', 'C']
        return [item for item in data if item.get(tier_field) in allowed_tiers]'''
            },
            
            "calculate_tiered_price": {
                "description": "계층별 가격 책정",
                "is_async": True,
                "template": '''async def calculate_tiered_price(self, quantity: float, tier_config: Optional[Dict[str, Dict]] = None):
        """계층별 가격 책정"""
        if tier_config is None:
            tier_config = {
                'tier1': {'min_quantity': 0, 'max_quantity': 100, 'price_per_unit': 10},
                'tier2': {'min_quantity': 100, 'max_quantity': 500, 'price_per_unit': 8},
                'tier3': {'min_quantity': 500, 'max_quantity': float('inf'), 'price_per_unit': 6}
            }
            
        total_price = 0
        remaining = quantity
        
        for tier_name, tier_info in sorted(tier_config.items(), key=lambda x: x[1].get('min_quantity', 0)):
            min_qty = tier_info.get('min_quantity', 0)
            max_qty = tier_info.get('max_quantity', float('inf'))
            price_per_unit = tier_info.get('price_per_unit', 0)
            
            if remaining <= 0:
                break
                
            tier_quantity = min(remaining, max_qty - min_qty)
            if quantity >= min_qty:
                total_price += tier_quantity * price_per_unit
                remaining -= tier_quantity
        
        return {
            'quantity': quantity,
            'total_price': total_price,
            'average_price': total_price / quantity if quantity > 0 else 0
        }'''
            },
            
            "process": {
                "description": "기본 처리 함수",
                "is_async": False,
                "template": '''def process(self, data: Dict) -> Dict:
        """기본 데이터 처리"""
        return {"status": "processed", "data": data}'''
            }
        }
    
    def _generate_param_values(self, query: str, func_name: str) -> Dict[str, Any]:
        """쿼리 기반 파라미터 값 생성"""
        values = {}
        
        numbers = re.findall(r'\d+', query)
        
        if func_name == "apply_discount":
            if "50%" in query or "50" in query:
                values["discount_rate"] = 50.0
            elif "30%" in query or "30" in query:
                values["discount_rate"] = 30.0
            else:
                values["discount_rate"] = 10.0
                
        elif func_name == "check_threshold":
            if numbers:
                values["threshold"] = float(numbers[0])
            else:
                values["threshold"] = 100.0
            
            if "금액" in query or "price" in query.lower():
                values["monitor_field"] = "amount"
            elif "점수" in query or "score" in query.lower():
                values["monitor_field"] = "score"
            elif "온도" in query or "temperature" in query.lower():
                values["monitor_field"] = "temperature"
            else:
                values["monitor_field"] = "value"
            
            if "초과" in query or "greater" in query.lower():
                values["comparison"] = ">"
            elif "이상" in query:
                values["comparison"] = ">="
            elif "미만" in query or "less" in query.lower():
                values["comparison"] = "<"
            elif "이하" in query:
                values["comparison"] = "<="
            else:
                values["comparison"] = ">"
                
        elif func_name == "aggregate_data":
            if "카테고리" in query or "category" in query.lower():
                values["group_by"] = "category"
            elif "부서" in query or "department" in query.lower():
                values["group_by"] = "department"
            elif "등급" in query or "tier" in query.lower():
                values["group_by"] = "tier"
            else:
                values["group_by"] = "type"
            
            if "금액" in query or "amount" in query.lower():
                values["aggregation_field"] = "amount"
            elif "수량" in query or "quantity" in query.lower():
                values["aggregation_field"] = "quantity"
            else:
                values["aggregation_field"] = "value"
            
            if "평균" in query or "average" in query.lower():
                values["operation"] = "avg"
            elif "합계" in query or "sum" in query.lower():
                values["operation"] = "sum"
            elif "최대" in query or "max" in query.lower():
                values["operation"] = "max"
            elif "최소" in query or "min" in query.lower():
                values["operation"] = "min"
            else:
                values["operation"] = "sum"
        
        return values
    
    def _get_required_imports(self, functions: List[str]) -> List[str]:
        """생성된 함수들에 필요한 import 문 자동 생성"""
        imports = set()
        
        # 기본 타입 import
        imports.add("from typing import Dict, List, Any, Optional")
        
        # 모든 코드 검사
        all_code = "\n".join(functions)
        
        # 패턴 기반 import 감지
        if "defaultdict" in all_code:
            imports.add("from collections import defaultdict")
        if "deque" in all_code:
            imports.add("from collections import deque")
        if "statistics" in all_code:
            imports.add("import statistics")
        if "re.match" in all_code or "re.compile" in all_code or "import re" in all_code:
            imports.add("import re")
        if "asyncio" in all_code or "async def" in all_code:
            imports.add("import asyncio")
        if "datetime" in all_code:
            imports.add("from datetime import datetime")
        if "random" in all_code:
            imports.add("import random")
        if "json" in all_code:
            imports.add("import json")
        if "logging" in all_code or "logger" in all_code:
            imports.add("import logging")
        
        return sorted(list(imports))
    
    def generate(self, query: str, matched_patterns: List[str]) -> Dict[str, Any]:
        """완벽한 문법의 비즈니스 로직 생성 (self 파라미터 포함)"""
        try:
            selected_functions = []
            
            # 빈 패턴 리스트 처리
            if not matched_patterns:
                matched_patterns = ["process"]  # 기본 패턴
            
            pattern_to_function = {
                "discount": ["apply_discount"],
                "validation": ["validate_data"],
                "filtering": ["filter_by_tier"],
                "aggregation": ["aggregate_data"],
                "transformation": ["transform_data"],
                "monitoring": ["check_threshold"],
                "tiered_pricing": ["calculate_tiered_price"],
                "multi_step": ["validate_data", "apply_discount"],
                "ml_pipeline": ["transform_data", "aggregate_data"],
                "realtime": ["check_threshold", "transform_data"],
                # 추가 패턴 매핑
                "discount_rate_apply": ["apply_discount"],
                "threshold_alert": ["check_threshold"],
                "coupon_apply": ["apply_discount"],
                "data_aggregation": ["aggregate_data"],
                "data_transformation": ["transform_data"],
                "data_validation": ["validate_data"],
                "tier_based_filtering": ["filter_by_tier"]
            }
            
            for pattern in matched_patterns:
                pattern_key = pattern.split('_')[0] if '_' in pattern else pattern
                # 정확한 패턴 이름도 체크
                if pattern in pattern_to_function:
                    selected_functions.extend(pattern_to_function[pattern])
                elif pattern_key in pattern_to_function:
                    selected_functions.extend(pattern_to_function[pattern_key])
            
            selected_functions = list(dict.fromkeys(selected_functions))
            
            if len(selected_functions) < 2:
                selected_functions.append("process")
                if len(selected_functions) < 2:
                    available_funcs = list(self.business_functions.keys())
                    while len(selected_functions) < 2:
                        func = random.choice(available_funcs)
                        if func not in selected_functions:
                            selected_functions.append(func)
            
            generated_code = []
            
            for func_name in selected_functions:
                if func_name in self.business_functions:
                    func_info = self.business_functions[func_name]
                    template = func_info["template"]
                    
                    # <<<placeholder>>> 방식으로 파라미터 치환
                    param_values = self._generate_param_values(query, func_name)
                    
                    code = template
                    for param_name, param_value in param_values.items():
                        placeholder = f"<<<{param_name}>>>"
                        if placeholder in code:
                            if isinstance(param_value, str):
                                code = code.replace(placeholder, param_value)
                            else:
                                code = code.replace(placeholder, str(param_value))
                    
                    # 남은 플레이스홀더 기본값 처리
                    code = code.replace("<<<discount_rate>>>", "10.0")
                    code = code.replace("<<<threshold>>>", "100.0")
                    code = code.replace("<<<monitor_field>>>", "value")
                    code = code.replace("<<<comparison>>>", ">")
                    code = code.replace("<<<group_by>>>", "type")
                    code = code.replace("<<<aggregation_field>>>", "value")
                    code = code.replace("<<<operation>>>", "sum")
                    
                    generated_code.append(code)
            
            # 필요한 import 자동 생성
            imports_needed = self._get_required_imports(generated_code)
            
            return {
                "functions": generated_code,
                "imports": imports_needed,
                "metadata": {
                    "query": query,
                    "patterns": matched_patterns,
                    "function_count": len(generated_code),
                    "selected_functions": selected_functions,
                    "timestamp": datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Error generating business logic: {e}")
            # 에러 시에도 기본 함수 반환 (self 파라미터 포함)
            return {
                "functions": [
                    '''def process(self, data: Dict) -> Dict:
        """Default processing function"""
        return {"status": "processed", "data": data}'''
                ],
                "imports": ["from typing import Dict"],
                "metadata": {
                    "query": query,
                    "patterns": matched_patterns,
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
            }