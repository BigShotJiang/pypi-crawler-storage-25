"""
Business Logic Generator
패턴 매칭 결과를 실제 비즈니스 로직 코드로 생성
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from loguru import logger
import json

from ..business_patterns.pattern_matcher import PatternMatch
from ..business_patterns.pattern_library import get_pattern_by_id


@dataclass
class GeneratedLogic:
    """생성된 비즈니스 로직"""
    pattern_id: str
    pattern_name: str
    code: str
    imports: List[str]
    dependencies: List[str]
    validation_rules: List[str]
    test_cases: List[Dict[str, Any]]
    confidence: float


class BusinessLogicGenerator:
    """비즈니스 로직 생성기"""
    
    def __init__(self):
        """로직 생성기 초기화"""
        self.generation_templates = self._load_generation_templates()
        logger.info("BusinessLogicGenerator initialized")
    
    def _load_generation_templates(self) -> Dict[str, str]:
        """각 패턴별 코드 생성 템플릿"""
        return {
            # Filtering 패턴들
            "tier_based_filtering": """
def filter_by_tier(data: List[Dict], tier_field: str = '{tier_field}', allowed_tiers: List[str] = {allowed_tiers}):
    \"\"\"등급별 필터링\"\"\"
    return [item for item in data if item.get(tier_field) in allowed_tiers]
""",
            
            "count_limit_filter": """
def limit_count(data: List[Dict], max_count: int = {max_count}, count_field: str = '{count_field}'):
    \"\"\"수량 제한 필터\"\"\"
    result = []
    for item in data:
        if item.get(count_field, 0) <= max_count:
            result.append(item)
    return result[:max_count] if max_count > 0 else result
""",
            
            "conditional_filter": """
def apply_conditional_filter(data: List[Dict], condition_field: str = '{condition_field}', condition_value: Any = {condition_value}, comparison: str = '{comparison}'):
    \"\"\"조건부 필터링\"\"\"
    def check_condition(item):
        value = item.get(condition_field)
        if comparison == '==':
            return value == condition_value
        elif comparison == '>':
            return value > condition_value
        elif comparison == '<':
            return value < condition_value
        elif comparison == '>=':
            return value >= condition_value
        elif comparison == '<=':
            return value <= condition_value
        elif comparison == '!=':
            return value != condition_value
        elif comparison == 'in':
            return value in condition_value
        elif comparison == 'contains':
            return condition_value in str(value)
        return False
    
    return [item for item in data if check_condition(item)]
""",
            
            # Alert 패턴들
            "threshold_alert": """
def check_threshold(value: float, threshold: float = {threshold_value}, monitor_field: str = '{monitor_field}', comparison: str = '{comparison}'):
    \"\"\"임계값 모니터링 및 알림\"\"\"
    alert_triggered = False
    
    if comparison == '<=':
        alert_triggered = value <= threshold
    elif comparison == '>=':
        alert_triggered = value >= threshold
    elif comparison == '<':
        alert_triggered = value < threshold
    elif comparison == '>':
        alert_triggered = value > threshold
    
    if alert_triggered:
        return {{
            'alert': True,
            'message': f'{{monitor_field}} alert: {{value}} {{comparison}} {{threshold}}',
            'severity': 'high' if abs(value - threshold) > threshold * 0.2 else 'medium',
            'value': value,
            'threshold': threshold
        }}
    return {{'alert': False}}
""",
            
            "consecutive_event_alert": """
def track_consecutive_events(events: List[Dict], event_type: str = '{event_type}', consecutive_threshold: int = {consecutive_count}):
    \"\"\"연속 이벤트 감지 및 알림\"\"\"
    consecutive_count = 0
    alerts = []
    
    for event in events:
        if event.get('type') == event_type:
            consecutive_count += 1
            if consecutive_count >= consecutive_threshold:
                alerts.append({{
                    'alert': True,
                    'message': f'{{consecutive_count}} consecutive {{event_type}} events detected',
                    'count': consecutive_count,
                    'timestamp': event.get('timestamp')
                }})
        else:
            consecutive_count = 0
    
    return alerts
""",
            
            # Pricing 패턴들
            "discount_rate_apply": """
def apply_discount(price: float, discount_rate: float = {discount_rate}, min_price: float = 0):
    \"\"\"할인율 적용\"\"\"
    if not 0 <= discount_rate <= 100:
        raise ValueError(f"Invalid discount rate: {{discount_rate}}")
    
    discounted_price = price * (1 - discount_rate / 100)
    final_price = max(discounted_price, min_price)
    
    return {{
        'original_price': price,
        'discount_rate': discount_rate,
        'discount_amount': price - final_price,
        'final_price': final_price
    }}
""",
            
            "tiered_pricing": """
def calculate_tiered_price(quantity: float, tier_config: Dict[str, Dict] = {tier_config}):
    \"\"\"계층별 가격 책정\"\"\"
    total_price = 0
    remaining = quantity
    
    for tier_name, tier_info in sorted(tier_config.items(), key=lambda x: x[1].get('min_quantity', 0)):
        min_qty = tier_info.get('min_quantity', 0)
        max_qty = tier_info.get('max_quantity', float('inf'))
        price_per_unit = tier_info.get('price_per_unit', 0)
        
        if remaining <= 0:
            break
            
        tier_quantity = min(remaining, max_qty - min_qty)
        if quantity >= min_qty:
            total_price += tier_quantity * price_per_unit
            remaining -= tier_quantity
    
    return {{
        'quantity': quantity,
        'total_price': total_price,
        'average_price': total_price / quantity if quantity > 0 else 0
    }}
""",
            
            # Data Processing 패턴들
            "data_aggregation": """
def aggregate_data(data: List[Dict], group_by: str = '{group_by}', aggregation_field: str = '{aggregation_field}', operation: str = '{operation}'):
    \"\"\"데이터 집계\"\"\"
    from collections import defaultdict
    import statistics
    
    groups = defaultdict(list)
    
    # 그룹화
    for item in data:
        key = item.get(group_by, 'unknown')
        value = item.get(aggregation_field, 0)
        groups[key].append(value)
    
    # 집계 연산
    results = {{}}
    for key, values in groups.items():
        if not values:
            results[key] = 0
            continue
            
        if operation == 'sum':
            results[key] = sum(values)
        elif operation == 'avg' or operation == 'mean':
            results[key] = statistics.mean(values)
        elif operation == 'min':
            results[key] = min(values)
        elif operation == 'max':
            results[key] = max(values)
        elif operation == 'count':
            results[key] = len(values)
        elif operation == 'median':
            results[key] = statistics.median(values)
        else:
            results[key] = values
    
    return results
""",
            
            "data_transformation": """
def transform_data(data: List[Dict], transformation_rules: Dict[str, Any] = {transformation_rules}):
    \"\"\"데이터 변환\"\"\"
    transformed = []
    
    for item in data:
        new_item = {{}}
        
        for field, rule in transformation_rules.items():
            if isinstance(rule, str):
                # 필드 매핑
                new_item[field] = item.get(rule)
            elif isinstance(rule, dict):
                # 복잡한 변환
                source_field = rule.get('source')
                transform_type = rule.get('type')
                
                value = item.get(source_field)
                
                if transform_type == 'uppercase':
                    new_item[field] = str(value).upper()
                elif transform_type == 'lowercase':
                    new_item[field] = str(value).lower()
                elif transform_type == 'multiply':
                    new_item[field] = value * rule.get('factor', 1)
                elif transform_type == 'format':
                    new_item[field] = rule.get('format', '{{}}').format(value)
                else:
                    new_item[field] = value
            else:
                new_item[field] = rule
        
        transformed.append(new_item)
    
    return transformed
""",
            
            "data_validation": """
def validate_data(data: Dict, validation_rules: Dict[str, Dict] = {validation_rules}):
    \"\"\"데이터 유효성 검증\"\"\"
    errors = []
    warnings = []
    
    for field, rules in validation_rules.items():
        value = data.get(field)
        
        # 필수 필드 체크
        if rules.get('required') and value is None:
            errors.append(f"{{field}} is required")
            continue
        
        if value is None:
            continue
        
        # 타입 체크
        expected_type = rules.get('type')
        if expected_type:
            type_map = {{'string': str, 'int': int, 'float': float, 'bool': bool, 'list': list, 'dict': dict}}
            if expected_type in type_map and not isinstance(value, type_map[expected_type]):
                errors.append(f"{{field}} must be {{expected_type}}, got {{type(value).__name__}}")
        
        # 범위 체크
        if 'min' in rules and value < rules['min']:
            errors.append(f"{{field}} must be >= {{rules['min']}}, got {{value}}")
        if 'max' in rules and value > rules['max']:
            errors.append(f"{{field}} must be <= {{rules['max']}}, got {{value}}")
        
        # 패턴 체크
        if 'pattern' in rules:
            import re
            if not re.match(rules['pattern'], str(value)):
                errors.append(f"{{field}} doesn't match pattern {{rules['pattern']}}")
        
        # 선택지 체크
        if 'choices' in rules and value not in rules['choices']:
            errors.append(f"{{field}} must be one of {{rules['choices']}}, got {{value}}")
    
    return {{
        'valid': len(errors) == 0,
        'errors': errors,
        'warnings': warnings,
        'data': data
    }}
""",
            
            "data_ranking": """
def rank_data(data: List[Dict], rank_by: str = '{rank_by}', order: str = '{order}', top_n: int = {top_n}):
    \"\"\"데이터 순위 매기기\"\"\"
    # 정렬
    reverse = (order == 'desc')
    sorted_data = sorted(data, key=lambda x: x.get(rank_by, 0), reverse=reverse)
    
    # 순위 추가
    for i, item in enumerate(sorted_data, 1):
        item['rank'] = i
        item['percentile'] = (i / len(sorted_data)) * 100 if sorted_data else 0
    
    # Top N 반환
    if top_n and top_n > 0:
        return sorted_data[:top_n]
    
    return sorted_data
"""
        }
    
    def generate_logic(self, pattern_match: PatternMatch) -> GeneratedLogic:
        """
        패턴 매칭 결과로부터 비즈니스 로직 생성
        
        Args:
            pattern_match: 패턴 매칭 결과
            
        Returns:
            생성된 비즈니스 로직
        """
        pattern = get_pattern_by_id(pattern_match.pattern_id)
        if not pattern:
            raise ValueError(f"Pattern not found: {pattern_match.pattern_id}")
        
        # 템플릿 가져오기
        template = self.generation_templates.get(pattern_match.pattern_id, "")
        
        # 슬롯 값으로 템플릿 채우기
        code = self._fill_template(template, pattern_match.extracted_slots)
        
        # imports 생성
        imports = self._generate_imports(pattern_match.pattern_id)
        
        # dependencies 생성
        dependencies = self._generate_dependencies(pattern_match.pattern_id)
        
        # validation rules 생성
        validation_rules = self._generate_validation_rules(pattern, pattern_match.extracted_slots)
        
        # test cases 생성
        test_cases = self._generate_test_cases(pattern_match.pattern_id, pattern_match.extracted_slots)
        
        return GeneratedLogic(
            pattern_id=pattern_match.pattern_id,
            pattern_name=pattern.name,
            code=code,
            imports=imports,
            dependencies=dependencies,
            validation_rules=validation_rules,
            test_cases=test_cases,
            confidence=pattern_match.confidence_score
        )
    
    def _fill_template(self, template: str, slots: Dict[str, Any]) -> str:
        """템플릿에 슬롯 값 채우기"""
        code = template
        
        for slot_name, slot_value in slots.items():
            # 문자열은 따옴표 추가 (함수 파라미터의 기본값 부분인지 확인)
            if isinstance(slot_value, str):
                # 템플릿에서 이 슬롯이 파라미터 기본값으로 사용되는지 확인
                # 예: tier_field: str = '{tier_field}'
                pattern = f": str = '{{{slot_name}}}'"
                if pattern in template:
                    # 이미 템플릿에 따옴표가 있으므로 따옴표 없이 값만 삽입
                    formatted_value = slot_value.replace("'", "\\'")
                else:
                    # 일반적인 경우 따옴표 추가
                    escaped_value = slot_value.replace("'", "\\'")
                    formatted_value = f"'{escaped_value}'"
            # 리스트나 딕셔너리는 repr 사용 (Python 코드로 직접 사용 가능)
            elif isinstance(slot_value, (list, dict)):
                formatted_value = repr(slot_value)
            # 나머지는 그대로
            else:
                formatted_value = str(slot_value)
            
            code = code.replace(f"{{{slot_name}}}", formatted_value)
        
        # 채워지지 않은 슬롯은 기본값으로
        import re
        unfilled = re.findall(r'\{(\w+)\}', code)
        for slot in unfilled:
            if slot in ['tier_field', 'count_field', 'monitor_field', 'condition_field', 
                       'event_type', 'group_by', 'aggregation_field', 'rank_by']:
                code = code.replace(f"{{{slot}}}", "'id'")
            elif slot in ['allowed_tiers', 'choices']:
                code = code.replace(f"{{{slot}}}", "[]")
            elif slot in ['max_count', 'threshold_value', 'consecutive_count', 
                         'discount_rate', 'top_n']:
                code = code.replace(f"{{{slot}}}", "10")
            elif slot in ['comparison', 'operation', 'order']:
                code = code.replace(f"{{{slot}}}", "'=='")
            elif slot in ['condition_value']:
                code = code.replace(f"{{{slot}}}", "None")
            elif slot in ['tier_config', 'transformation_rules', 'validation_rules']:
                code = code.replace(f"{{{slot}}}", "{}")
        
        return code
    
    def _generate_imports(self, pattern_id: str) -> List[str]:
        """필요한 import 문 생성"""
        imports = ["from typing import List, Dict, Any, Optional"]
        
        if pattern_id in ["data_aggregation", "data_transformation"]:
            imports.append("from collections import defaultdict")
            imports.append("import statistics")
        
        if pattern_id == "data_validation":
            imports.append("import re")
        
        if pattern_id in ["threshold_alert", "consecutive_event_alert"]:
            imports.append("from datetime import datetime")
        
        return imports
    
    def _generate_dependencies(self, pattern_id: str) -> List[str]:
        """외부 의존성 생성"""
        deps = []
        
        if pattern_id in ["threshold_alert", "consecutive_event_alert", "pattern_detection_alert"]:
            deps.append("notification_service")
        
        if pattern_id in ["data_aggregation", "data_transformation", "data_ranking"]:
            deps.append("pandas")  # 옵션
        
        return deps
    
    def _generate_validation_rules(self, pattern, slots: Dict[str, Any]) -> List[str]:
        """유효성 검증 규칙 생성"""
        rules = []
        
        for slot in pattern.slots:
            if slot.required and slot.name not in slots:
                rules.append(f"{slot.name} is required")
            
            if slot.name in slots:
                value = slots[slot.name]
                # 타입 검증 (PatternSlot의 type 필드 사용)
                if slot.type == "int" and not isinstance(value, int):
                    rules.append(f"{slot.name} must be an integer")
                elif slot.type == "float" and not isinstance(value, (int, float)):
                    rules.append(f"{slot.name} must be a number")
                elif slot.type == "str" and not isinstance(value, str):
                    rules.append(f"{slot.name} must be a string")
                elif slot.type == "list" and not isinstance(value, list):
                    rules.append(f"{slot.name} must be a list")
                elif slot.type == "dict" and not isinstance(value, dict):
                    rules.append(f"{slot.name} must be a dictionary")
        
        return rules
    
    def _generate_test_cases(self, pattern_id: str, slots: Dict[str, Any]) -> List[Dict[str, Any]]:
        """테스트 케이스 생성"""
        test_cases = []
        
        # 기본 성공 케이스
        test_cases.append({
            "name": f"test_{pattern_id}_basic",
            "input": self._generate_sample_input(pattern_id),
            "expected_output": self._generate_expected_output(pattern_id),
            "slots": slots
        })
        
        # 엣지 케이스
        test_cases.append({
            "name": f"test_{pattern_id}_edge",
            "input": self._generate_edge_input(pattern_id),
            "expected_output": self._generate_edge_output(pattern_id),
            "slots": slots
        })
        
        return test_cases
    
    def _generate_sample_input(self, pattern_id: str) -> Any:
        """샘플 입력 데이터 생성"""
        if pattern_id in ["tier_based_filtering", "count_limit_filter", "conditional_filter"]:
            return [
                {"id": 1, "name": "Item1", "tier": "VIP", "count": 5},
                {"id": 2, "name": "Item2", "tier": "Normal", "count": 10},
                {"id": 3, "name": "Item3", "tier": "VIP", "count": 3}
            ]
        elif pattern_id == "threshold_alert":
            return 5.0
        elif pattern_id == "discount_rate_apply":
            return 10000.0
        elif pattern_id == "data_aggregation":
            return [
                {"category": "A", "value": 100},
                {"category": "B", "value": 200},
                {"category": "A", "value": 150}
            ]
        else:
            return {}
    
    def _generate_expected_output(self, pattern_id: str) -> Any:
        """예상 출력 데이터 생성"""
        if pattern_id == "tier_based_filtering":
            return [{"id": 1, "name": "Item1", "tier": "VIP", "count": 5}]
        elif pattern_id == "threshold_alert":
            return {"alert": True, "message": "Threshold exceeded"}
        elif pattern_id == "discount_rate_apply":
            return {"original_price": 10000, "final_price": 7000}
        elif pattern_id == "data_aggregation":
            return {"A": 250, "B": 200}
        else:
            return {}
    
    def _generate_edge_input(self, pattern_id: str) -> Any:
        """엣지 케이스 입력 생성"""
        if pattern_id in ["tier_based_filtering", "count_limit_filter"]:
            return []  # 빈 리스트
        elif pattern_id == "threshold_alert":
            return 0.0  # 경계값
        elif pattern_id == "discount_rate_apply":
            return -100.0  # 음수
        else:
            return None
    
    def _generate_edge_output(self, pattern_id: str) -> Any:
        """엣지 케이스 예상 출력"""
        if pattern_id in ["tier_based_filtering", "count_limit_filter"]:
            return []
        elif pattern_id == "threshold_alert":
            return {"alert": False}
        elif pattern_id == "discount_rate_apply":
            return {"error": "Invalid price"}
        else:
            return {}
    
    def generate_multiple(self, pattern_matches: List[PatternMatch]) -> List[GeneratedLogic]:
        """
        여러 패턴 매칭 결과로부터 로직 생성
        
        Args:
            pattern_matches: 패턴 매칭 결과 리스트
            
        Returns:
            생성된 로직 리스트
        """
        generated = []
        
        for match in pattern_matches:
            try:
                logic = self.generate_logic(match)
                generated.append(logic)
                logger.info(f"Generated logic for pattern: {match.pattern_id}")
            except Exception as e:
                logger.error(f"Failed to generate logic for {match.pattern_id}: {e}")
        
        return generated
    
    def combine_logic(self, logic_list: List[GeneratedLogic]) -> str:
        """
        여러 로직을 하나의 파일로 결합
        
        Args:
            logic_list: 생성된 로직 리스트
            
        Returns:
            결합된 Python 코드
        """
        # imports 통합
        all_imports = set()
        for logic in logic_list:
            all_imports.update(logic.imports)
        
        # 코드 결합
        combined_code = "\n".join(sorted(all_imports))
        combined_code += "\n\n# Generated Business Logic\n"
        
        for logic in logic_list:
            combined_code += f"\n# Pattern: {logic.pattern_name} (confidence: {logic.confidence:.0%})\n"
            combined_code += logic.code
            combined_code += "\n"
        
        return combined_code