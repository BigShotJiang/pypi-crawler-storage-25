"""
Ultimate Business Logic Generator - Complete fix for all syntax issues
"""

from typing import Dict, List, Any, Optional
import random
import re
import json
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class UltimateBusinessLogicGenerator:
    """완벽한 비즈니스 로직 생성기 - 모든 문법 오류 해결"""
    
    def __init__(self):
        self.business_functions = self._load_business_functions()
        
    def _load_business_functions(self) -> Dict[str, Dict]:
        """Load business function templates with perfect syntax"""
        return {
            "validate_data": {
                "description": "데이터 유효성 검증",
                "is_async": False,
                "template": '''def validate_data(self, data: Dict, validation_rules: Optional[Dict[str, Dict]] = None):
        """데이터 유효성 검증"""
        if validation_rules is None:
            validation_rules = {
                'email': {'type': 'string', 'pattern': r'^[\\w\\.-]+@[\\w\\.-]+\\.\\w+$'},
                'age': {'type': 'int', 'min': 0, 'max': 120}
            }
        
        errors = []
        warnings = []
        
        for field, rules in validation_rules.items():
            value = data.get(field)
            
            # 필수 필드 체크
            if rules.get('required') and value is None:
                errors.append(f"{field} is required")
                continue
            
            if value is None:
                continue
            
            # 타입 체크
            expected_type = rules.get('type')
            if expected_type:
                type_map = {'string': str, 'int': int, 'float': float, 'bool': bool, 'list': list, 'dict': dict}
                if expected_type in type_map and not isinstance(value, type_map[expected_type]):
                    errors.append(f"{field} must be {expected_type}, got {type(value).__name__}")
            
            # 범위 체크
            if 'min' in rules and value < rules['min']:
                errors.append(f"{field} must be >= {rules['min']}, got {value}")
            if 'max' in rules and value > rules['max']:
                errors.append(f"{field} must be <= {rules['max']}, got {value}")
            
            # 패턴 체크
            if 'pattern' in rules:
                import re
                if not re.match(rules['pattern'], str(value)):
                    errors.append(f"{field} doesn't match pattern {rules['pattern']}")
            
            # 선택지 체크
            if 'choices' in rules and value not in rules['choices']:
                errors.append(f"{field} must be one of {rules['choices']}, got {value}")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'data': data
        }'''
            },
            
            "apply_discount": {
                "description": "할인율 적용",
                "is_async": False,
                "template": '''def apply_discount(self, price: float, discount_rate: float = {discount_rate}, min_price: float = 0):
        """할인율 적용"""
        if not 0 <= discount_rate <= 100:
            raise ValueError(f"Invalid discount rate: {{discount_rate}}")
        
        discounted_price = price * (1 - discount_rate / 100)
        final_price = max(discounted_price, min_price)
        
        return {{
            'original_price': price,
            'discount_rate': discount_rate,
            'discount_amount': price - final_price,
            'final_price': final_price
        }}'''
            },
            
            "check_threshold": {
                "description": "임계값 모니터링 및 알림",
                "is_async": True,
                "template": '''async def check_threshold(self, value: float, threshold: float = {threshold}, monitor_field: str = '{monitor_field}', comparison: str = '{comparison}'):
        """임계값 모니터링 및 알림"""
        alert_triggered = False
        
        if comparison == '<=':
            alert_triggered = value <= threshold
        elif comparison == '>=':
            alert_triggered = value >= threshold
        elif comparison == '<':
            alert_triggered = value < threshold
        elif comparison == '>':
            alert_triggered = value > threshold
        
        if alert_triggered:
            return {{
                'alert': True,
                'message': f'{{{{monitor_field}}}} alert: {{{{value}}}} {{{{comparison}}}} {{{{threshold}}}}',
                'severity': 'high' if abs(value - threshold) > threshold * 0.2 else 'medium',
                'value': value,
                'threshold': threshold
            }}
        return {{'alert': False}}'''
            },
            
            "aggregate_data": {
                "description": "데이터 집계",
                "is_async": False,
                "template": '''def aggregate_data(self, data: List[Dict], group_by: str = '{group_by}', aggregation_field: str = '{aggregation_field}', operation: str = '{operation}'):
        """데이터 집계"""
        from collections import defaultdict
        import statistics
        
        groups = defaultdict(list)
        
        # 그룹화
        for item in data:
            key = item.get(group_by, 'unknown')
            value = item.get(aggregation_field, 0)
            groups[key].append(value)
        
        # 집계 연산
        results = {{}}
        for key, values in groups.items():
            if not values:
                results[key] = 0
                continue
                
            if operation == 'sum':
                results[key] = sum(values)
            elif operation == 'avg' or operation == 'mean':
                results[key] = statistics.mean(values)
            elif operation == 'min':
                results[key] = min(values)
            elif operation == 'max':
                results[key] = max(values)
            elif operation == 'count':
                results[key] = len(values)
            elif operation == 'median':
                results[key] = statistics.median(values)
            else:
                results[key] = values
        
        return results'''
            },
            
            "transform_data": {
                "description": "데이터 변환",
                "is_async": False,
                "template": '''def transform_data(self, data: List[Dict], transformation_rules: Optional[Dict[str, Any]] = None):
        """데이터 변환"""
        if transformation_rules is None:
            transformation_rules = {{}}
            
        transformed = []
        
        for item in data:
            new_item = {{}}
            
            for field, rule in transformation_rules.items():
                if isinstance(rule, str):
                    # 필드 매핑
                    new_item[field] = item.get(rule)
                elif isinstance(rule, dict):
                    # 복잡한 변환
                    source_field = rule.get('source')
                    transform_type = rule.get('type')
                    
                    value = item.get(source_field)
                    
                    if transform_type == 'uppercase':
                        new_item[field] = str(value).upper()
                    elif transform_type == 'lowercase':
                        new_item[field] = str(value).lower()
                    elif transform_type == 'multiply':
                        new_item[field] = value * rule.get('factor', 1)
                    elif transform_type == 'format':
                        new_item[field] = rule.get('format', '{{}}').format(value)
                    else:
                        new_item[field] = value
                else:
                    new_item[field] = rule
            
            transformed.append(new_item)
        
        return transformed'''
            },
            
            "filter_by_tier": {
                "description": "등급별 필터링",
                "is_async": False,
                "template": '''def filter_by_tier(self, data: List[Dict], tier_field: str = 'user_tier', allowed_tiers: Optional[List[str]] = None):
        """등급별 필터링"""
        if allowed_tiers is None:
            allowed_tiers = ['A', 'B', 'C']
        return [item for item in data if item.get(tier_field) in allowed_tiers]'''
            },
            
            "calculate_tiered_price": {
                "description": "계층별 가격 책정",
                "is_async": True,
                "template": '''async def calculate_tiered_price(self, quantity: float, tier_config: Optional[Dict[str, Dict]] = None):
        """계층별 가격 책정"""
        if tier_config is None:
            tier_config = {{
                'tier1': {{'min_quantity': 0, 'max_quantity': 100, 'price_per_unit': 10}},
                'tier2': {{'min_quantity': 100, 'max_quantity': 500, 'price_per_unit': 8}},
                'tier3': {{'min_quantity': 500, 'max_quantity': float('inf'), 'price_per_unit': 6}}
            }}
            
        total_price = 0
        remaining = quantity
        
        for tier_name, tier_info in sorted(tier_config.items(), key=lambda x: x[1].get('min_quantity', 0)):
            min_qty = tier_info.get('min_quantity', 0)
            max_qty = tier_info.get('max_quantity', float('inf'))
            price_per_unit = tier_info.get('price_per_unit', 0)
            
            if remaining <= 0:
                break
                
            tier_quantity = min(remaining, max_qty - min_qty)
            if quantity >= min_qty:
                total_price += tier_quantity * price_per_unit
                remaining -= tier_quantity
        
        return {{
            'quantity': quantity,
            'total_price': total_price,
            'average_price': total_price / quantity if quantity > 0 else 0
        }}'''
            },
            
            "process": {
                "description": "기본 처리 함수",
                "is_async": False,
                "template": '''def process(self, data: Dict) -> Dict:
        """기본 데이터 처리"""
        return {{"status": "processed", "data": data}}'''
            }
        }
    
    def _generate_param_values(self, query: str, func_name: str) -> Dict[str, Any]:
        """Generate context-appropriate parameter values based on query"""
        values = {}
        
        # Extract numbers from query for thresholds
        numbers = re.findall(r'\d+', query)
        
        if func_name == "apply_discount":
            # Find discount rates in query
            if "50%" in query or "50" in query:
                values["discount_rate"] = 50.0
            elif "30%" in query or "30" in query:
                values["discount_rate"] = 30.0
            else:
                values["discount_rate"] = 10.0
                
        elif func_name == "check_threshold":
            if numbers:
                values["threshold"] = float(numbers[0])
            else:
                values["threshold"] = 100.0
            
            # Set monitor field based on context
            if "금액" in query or "price" in query.lower():
                values["monitor_field"] = "amount"
            elif "점수" in query or "score" in query.lower():
                values["monitor_field"] = "score"
            elif "온도" in query or "temperature" in query.lower():
                values["monitor_field"] = "temperature"
            else:
                values["monitor_field"] = "value"
            
            # Set comparison operator
            if "초과" in query or "greater" in query.lower():
                values["comparison"] = ">"
            elif "이상" in query:
                values["comparison"] = ">="
            elif "미만" in query or "less" in query.lower():
                values["comparison"] = "<"
            elif "이하" in query:
                values["comparison"] = "<="
            else:
                values["comparison"] = ">"
                
        elif func_name == "aggregate_data":
            # Set grouping field
            if "카테고리" in query or "category" in query.lower():
                values["group_by"] = "category"
            elif "부서" in query or "department" in query.lower():
                values["group_by"] = "department"
            elif "등급" in query or "tier" in query.lower():
                values["group_by"] = "tier"
            else:
                values["group_by"] = "type"
            
            # Set aggregation field
            if "금액" in query or "amount" in query.lower():
                values["aggregation_field"] = "amount"
            elif "수량" in query or "quantity" in query.lower():
                values["aggregation_field"] = "quantity"
            else:
                values["aggregation_field"] = "value"
            
            # Set operation
            if "평균" in query or "average" in query.lower():
                values["operation"] = "avg"
            elif "합계" in query or "sum" in query.lower():
                values["operation"] = "sum"
            elif "최대" in query or "max" in query.lower():
                values["operation"] = "max"
            elif "최소" in query or "min" in query.lower():
                values["operation"] = "min"
            else:
                values["operation"] = "sum"
        
        return values
    
    def generate(self, query: str, matched_patterns: List[str]) -> Dict[str, Any]:
        """Generate business logic with perfect syntax"""
        try:
            # Select functions based on patterns
            selected_functions = []
            
            # Map patterns to functions
            pattern_to_function = {
                "discount": ["apply_discount"],
                "validation": ["validate_data"],
                "filtering": ["filter_by_tier"],
                "aggregation": ["aggregate_data"],
                "transformation": ["transform_data"],
                "monitoring": ["check_threshold"],
                "tiered_pricing": ["calculate_tiered_price"],
                "multi_step": ["validate_data", "apply_discount"],
                "ml_pipeline": ["transform_data", "aggregate_data"],
                "realtime": ["check_threshold", "transform_data"]
            }
            
            # Select functions based on patterns
            for pattern in matched_patterns:
                pattern_key = pattern.split('_')[0] if '_' in pattern else pattern
                if pattern_key in pattern_to_function:
                    selected_functions.extend(pattern_to_function[pattern_key])
            
            # Remove duplicates while preserving order
            selected_functions = list(dict.fromkeys(selected_functions))
            
            # Ensure we have at least 2 functions
            if len(selected_functions) < 2:
                # Add process as a default function
                selected_functions.append("process")
                if len(selected_functions) < 2:
                    available_funcs = list(self.business_functions.keys())
                    while len(selected_functions) < 2:
                        func = random.choice(available_funcs)
                        if func not in selected_functions:
                            selected_functions.append(func)
            
            # Generate code for each function
            generated_code = []
            imports_needed = set()
            
            for func_name in selected_functions:
                if func_name in self.business_functions:
                    func_info = self.business_functions[func_name]
                    template = func_info["template"]
                    
                    # Generate parameter values
                    param_values = self._generate_param_values(query, func_name)
                    
                    # Replace template variables
                    code = template
                    for param_name, param_value in param_values.items():
                        if isinstance(param_value, str):
                            # For string values, ensure proper quoting
                            code = code.replace(f"{{{param_name}}}", param_value)
                        else:
                            # For numeric values
                            code = code.replace(f"{{{param_name}}}", str(param_value))
                    
                    # Clean up any remaining template variables with safe defaults
                    code = re.sub(r'{discount_rate}', '10.0', code)
                    code = re.sub(r'{threshold}', '100.0', code)
                    code = re.sub(r'{monitor_field}', 'value', code)
                    code = re.sub(r'{comparison}', '>', code)
                    code = re.sub(r'{group_by}', 'type', code)
                    code = re.sub(r'{aggregation_field}', 'value', code)
                    code = re.sub(r'{operation}', 'sum', code)
                    
                    # Fix f-string formatting - convert {{{{var}}}} to {var}
                    code = re.sub(r'\{\{(\w+)\}\}', r'{\1}', code)
                    
                    generated_code.append(code)
                    
                    # Collect imports
                    if "defaultdict" in code:
                        imports_needed.add("from collections import defaultdict")
                    if "statistics" in code:
                        imports_needed.add("import statistics")
                    if "re.match" in code or "re.compile" in code:
                        imports_needed.add("import re")
                    if "asyncio" in code or "async def" in code:
                        imports_needed.add("import asyncio")
                    if "Optional" in code:
                        imports_needed.add("from typing import Optional")
            
            return {
                "functions": generated_code,
                "imports": list(imports_needed),
                "metadata": {
                    "query": query,
                    "patterns": matched_patterns,
                    "function_count": len(generated_code),
                    "selected_functions": selected_functions,
                    "timestamp": datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Error generating business logic: {e}")
            # Return safe default with self parameter
            return {
                "functions": [
                    '''def process(self, data: Dict) -> Dict:
        """Default processing function"""
        return {"status": "processed", "data": data}'''
                ],
                "imports": [],
                "metadata": {
                    "query": query,
                    "patterns": matched_patterns,
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
            }