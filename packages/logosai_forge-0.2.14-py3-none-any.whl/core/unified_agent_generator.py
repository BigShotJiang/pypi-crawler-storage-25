"""
FORGE AI 통합 에이전트 생성기
============================
단일 책임 원칙에 따른 통합 에이전트 생성 시스템

핵심 철학:
1. 단일 통합 생성기 - 복잡성 제거
2. 비즈니스 로직 우선 - 템플릿은 구조만
3. 자동 검증 및 수정 - 에러 방지
4. 최소 LLM 호출 - 효율성 극대화
"""

import asyncio
import json
import re
import uuid
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass

from loguru import logger


@dataclass
class AgentGenerationRequest:
    """에이전트 생성 요청 구조"""
    user_request: str
    user_email: str = "default@logos.ai"
    session_id: Optional[str] = None
    project_id: Optional[str] = None
    template_preference: Optional[str] = None
    quality_level: str = "balanced"  # fast, balanced, high_quality
    enable_streaming: bool = True


@dataclass
class AgentGenerationResult:
    """에이전트 생성 결과"""
    agent_code: str
    metadata: Dict[str, Any]
    validation_status: str
    execution_test_result: Optional[Dict] = None
    error_log: List[str] = None


class BusinessLogicExtractor:
    """비즈니스 로직 추출 및 생성"""
    
    def __init__(self, llm_client=None):
        self.llm_client = llm_client
        
    async def extract_requirements(self, user_request: str) -> Dict[str, Any]:
        """사용자 요청에서 핵심 요구사항 추출"""
        
        # 키워드 기반 빠른 분석
        requirements = {
            "agent_type": self._detect_agent_type(user_request),
            "data_sources": self._detect_data_sources(user_request),
            "output_format": self._detect_output_format(user_request),
            "complexity": self._assess_complexity(user_request),
            "primary_function": self._extract_primary_function(user_request),
            "user_request": user_request
        }
        
        return requirements
    
    def _detect_agent_type(self, request: str) -> str:
        """에이전트 타입 감지"""
        request_lower = request.lower()
        
        if any(word in request_lower for word in ['데이터', '분석', 'csv', 'excel', '차트']):
            return "data_analysis"
        elif any(word in request_lower for word in ['웹', '크롤링', '스크래핑', 'url']):
            return "web_scraping"
        elif any(word in request_lower for word in ['api', 'rest', 'endpoint', '서비스']):
            return "api_integration"
        elif any(word in request_lower for word in ['계산', '수학', '공식', 'calculator']):
            return "calculator"
        elif any(word in request_lower for word in ['문서', '텍스트', '파일', 'document']):
            return "document_processing"
        else:
            return "general_purpose"
    
    def _detect_data_sources(self, request: str) -> List[str]:
        """데이터 소스 감지"""
        sources = []
        request_lower = request.lower()
        
        if any(word in request_lower for word in ['csv', '엑셀', 'excel']):
            sources.append("csv_file")
        if any(word in request_lower for word in ['api', 'rest', 'json']):
            sources.append("api")
        if any(word in request_lower for word in ['데이터베이스', 'db', 'sql']):
            sources.append("database")
        if any(word in request_lower for word in ['웹', 'url', '사이트']):
            sources.append("web")
        
        return sources if sources else ["user_input"]
    
    def _detect_output_format(self, request: str) -> str:
        """출력 형식 감지"""
        request_lower = request.lower()
        
        if any(word in request_lower for word in ['차트', '그래프', '시각화', 'chart']):
            return "visualization"
        elif any(word in request_lower for word in ['파일', '저장', 'export']):
            return "file"
        elif any(word in request_lower for word in ['json', 'api', '데이터']):
            return "structured_data"
        else:
            return "text_response"
    
    def _assess_complexity(self, request: str) -> str:
        """복잡도 평가"""
        request_lower = request.lower()
        complexity_indicators = 0
        
        # 복잡도 지표들
        if any(word in request_lower for word in ['여러', '다양한', '복합', '통합']):
            complexity_indicators += 1
        if any(word in request_lower for word in ['분석', '처리', '계산', '변환']):
            complexity_indicators += 1
        if any(word in request_lower for word in ['실시간', '자동', '주기적']):
            complexity_indicators += 1
        if len(request) > 100:  # 긴 요청은 복잡할 가능성
            complexity_indicators += 1
        
        if complexity_indicators >= 3:
            return "high"
        elif complexity_indicators >= 1:
            return "medium"
        else:
            return "low"
    
    def _extract_primary_function(self, request: str) -> str:
        """주요 기능 추출"""
        request_lower = request.lower()
        
        # 동사 패턴 매칭
        if any(word in request_lower for word in ['분석', '분석해', 'analyze']):
            return "analyze_data"
        elif any(word in request_lower for word in ['계산', '계산해', 'calculate']):
            return "calculate"
        elif any(word in request_lower for word in ['생성', '만들어', 'generate', 'create']):
            return "generate_content"
        elif any(word in request_lower for word in ['검색', '찾아', 'search', 'find']):
            return "search_data"
        elif any(word in request_lower for word in ['변환', '바꿔', 'convert', 'transform']):
            return "transform_data"
        else:
            return "process_request"
    
    async def generate_business_logic(self, requirements: Dict[str, Any]) -> Dict[str, str]:
        """요구사항에서 비즈니스 로직 생성"""
        
        agent_type = requirements["agent_type"]
        primary_function = requirements["primary_function"]
        complexity = requirements["complexity"]
        
        # 템플릿 기반 비즈니스 로직 생성
        business_logic = {}
        
        # 1. 핵심 처리 로직
        business_logic["core_logic"] = self._generate_core_logic(
            agent_type, primary_function, requirements
        )
        
        # 2. 데이터 처리 로직
        if requirements["data_sources"]:
            business_logic["data_processing"] = self._generate_data_processing_logic(
                requirements["data_sources"], requirements["output_format"]
            )
        
        # 3. 에러 처리 로직
        business_logic["error_handling"] = self._generate_error_handling_logic(complexity)
        
        # 4. 결과 포맷팅 로직
        business_logic["result_formatting"] = self._generate_result_formatting_logic(
            requirements["output_format"]
        )
        
        return business_logic
    
    def _generate_core_logic(self, agent_type: str, primary_function: str, requirements: Dict) -> str:
        """핵심 처리 로직 생성"""
        
        if agent_type == "data_analysis":
            return f'''
    async def _process_data_analysis(self, query: str, context: Dict) -> Dict[str, Any]:
        """데이터 분석 처리"""
        try:
            # 1. 데이터 로드
            data = await self._load_data(context.get("data_source"))
            
            # 2. 분석 수행
            analysis_result = await self._perform_analysis(data, query)
            
            # 3. 결과 검증
            validated_result = await self._validate_analysis(analysis_result)
            
            return {{
                "status": "success",
                "data": validated_result,
                "timestamp": datetime.now().isoformat()
            }}
            
        except Exception as e:
            logger.error(f"데이터 분석 오류: {{e}}")
            return {{"status": "error", "error": str(e)}}
            '''
        
        elif agent_type == "calculator":
            return f'''
    async def _process_calculation(self, query: str, context: Dict) -> Dict[str, Any]:
        """계산 처리"""
        try:
            # 1. 수식 추출
            expression = await self._extract_expression(query)
            
            # 2. 안전한 계산 수행
            result = await self._safe_calculate(expression)
            
            # 3. 결과 포맷팅
            formatted_result = await self._format_calculation_result(result, expression)
            
            return {{
                "status": "success",
                "result": formatted_result,
                "expression": expression,
                "timestamp": datetime.now().isoformat()
            }}
            
        except Exception as e:
            logger.error(f"계산 오류: {{e}}")
            return {{"status": "error", "error": str(e)}}
            '''
        
        else:  # general_purpose
            return f'''
    async def _process_general_request(self, query: str, context: Dict) -> Dict[str, Any]:
        """일반 요청 처리"""
        try:
            # 1. 요청 분석
            analyzed_request = await self._analyze_request(query)
            
            # 2. 처리 수행
            processing_result = await self._execute_processing(analyzed_request, context)
            
            # 3. 결과 생성
            final_result = await self._generate_response(processing_result)
            
            return {{
                "status": "success",
                "result": final_result,
                "timestamp": datetime.now().isoformat()
            }}
            
        except Exception as e:
            logger.error(f"처리 오류: {{e}}")
            return {{"status": "error", "error": str(e)}}
            '''
    
    def _generate_data_processing_logic(self, data_sources: List[str], output_format: str) -> str:
        """데이터 처리 로직 생성"""
        return '''
    async def _load_data(self, data_source: str) -> Any:
        """데이터 로드"""
        if data_source.endswith('.csv'):
            import pandas as pd
            return pd.read_csv(data_source)
        elif data_source.startswith('http'):
            import requests
            response = requests.get(data_source)
            return response.json() if response.headers.get('content-type', '').startswith('application/json') else response.text
        else:
            return data_source  # 직접 데이터로 처리
    
    async def _process_data(self, data: Any, operation: str) -> Any:
        """데이터 처리"""
        if hasattr(data, 'describe'):  # pandas DataFrame
            if operation == 'analyze':
                return data.describe().to_dict()
            elif operation == 'summarize':
                return {
                    'shape': data.shape,
                    'columns': list(data.columns),
                    'types': data.dtypes.to_dict()
                }
        return data
        '''
    
    def _generate_error_handling_logic(self, complexity: str) -> str:
        """에러 처리 로직 생성"""
        if complexity == "high":
            return '''
    async def _handle_error(self, error: Exception, context: Dict) -> Dict[str, Any]:
        """고급 에러 처리"""
        error_type = type(error).__name__
        error_message = str(error)
        
        # 에러 분류 및 복구 시도
        if error_type == "FileNotFoundError":
            return await self._handle_file_error(error_message, context)
        elif error_type == "ConnectionError":
            return await self._handle_connection_error(error_message, context)
        elif error_type == "ValueError":
            return await self._handle_value_error(error_message, context)
        else:
            return {
                "status": "error",
                "error_type": error_type,
                "error_message": error_message,
                "recovery_suggestion": "시스템 관리자에게 문의하세요."
            }
            '''
        else:
            return '''
    async def _handle_error(self, error: Exception, context: Dict) -> Dict[str, Any]:
        """기본 에러 처리"""
        return {
            "status": "error",
            "error": str(error),
            "timestamp": datetime.now().isoformat()
        }
        '''
    
    def _generate_result_formatting_logic(self, output_format: str) -> str:
        """결과 포맷팅 로직 생성"""
        if output_format == "visualization":
            return '''
    async def _format_result(self, result: Any) -> Dict[str, Any]:
        """시각화 결과 포맷팅"""
        if isinstance(result, dict) and 'data' in result:
            return {
                "formatted_result": result,
                "visualization_ready": True,
                "chart_type": "auto_detect"
            }
        return {"formatted_result": result, "visualization_ready": False}
        '''
        else:
            return '''
    async def _format_result(self, result: Any) -> Dict[str, Any]:
        """기본 결과 포맷팅"""
        return {
            "formatted_result": result,
            "timestamp": datetime.now().isoformat()
        }
        '''


class StandardResponseParser:
    """표준화된 LLM 응답 파싱"""
    
    def parse_llm_response(self, response: Any) -> str:
        """LLM 응답을 표준 형식으로 파싱"""
        
        # 응답 타입에 따른 처리
        if hasattr(response, 'content'):
            text = response.content
        elif hasattr(response, 'text'):
            text = response.text
        else:
            text = str(response)
        
        # 마크다운 코드 블록 제거
        text = self._remove_markdown_blocks(text)
        
        # JSON 응답 처리
        json_content = self._extract_json_if_present(text)
        if json_content:
            return json_content.get('code', text)
        
        # 순수 코드 추출
        return self._extract_pure_code(text)
    
    def _remove_markdown_blocks(self, text: str) -> str:
        """마크다운 코드 블록 제거"""
        # 모든 종류의 코드 블록 패턴 제거
        patterns = [
            r'```python\s*\n?',
            r'```py\s*\n?', 
            r'```\s*\n?',
            r'\n?```'
        ]
        
        for pattern in patterns:
            text = re.sub(pattern, '', text)
        
        return text.strip()
    
    def _extract_json_if_present(self, text: str) -> Optional[Dict]:
        """JSON이 포함된 경우 추출"""
        try:
            # JSON 패턴 찾기
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
        return None
    
    def _extract_pure_code(self, text: str) -> str:
        """순수 코드만 추출"""
        lines = text.split('\n')
        code_lines = []
        
        for line in lines:
            # 주석이나 설명 제외
            if line.strip() and not line.strip().startswith('#'):
                # 들여쓰기 정규화
                if line.startswith('    '):
                    code_lines.append(line)
                elif line.strip():
                    code_lines.append(line)
        
        return '\n'.join(code_lines)


class AgentCodeAssembler:
    """에이전트 코드 조립"""
    
    def __init__(self, templates_dir: str = "forge/templates"):
        self.templates_dir = Path(templates_dir)
        
    async def assemble_agent(
        self, 
        requirements: Dict[str, Any], 
        business_logic: Dict[str, str]
    ) -> str:
        """비즈니스 로직을 템플릿에 조립"""
        
        # 1. 최적 템플릿 선택
        template_path = self._select_template(requirements)
        
        # 2. 템플릿 로드
        template_code = self._load_template(template_path)
        
        # 3. 변수 치환
        assembled_code = self._substitute_variables(template_code, business_logic, requirements)
        
        # 4. 코드 정리
        cleaned_code = self._clean_assembled_code(assembled_code)
        
        return cleaned_code
    
    def _select_template(self, requirements: Dict[str, Any]) -> Path:
        """요구사항에 맞는 템플릿 선택"""
        agent_type = requirements["agent_type"]
        
        # 타입별 템플릿 매핑
        template_map = {
            "data_analysis": "data_analysis_agent.py",
            "calculator": "comprehensive_agent.py", 
            "web_scraping": "web_scraping_agent.py",
            "api_integration": "api_integration_agent.py",
            "document_processing": "document_processing_agent.py",
            "general_purpose": "comprehensive_agent.py"
        }
        
        template_name = template_map.get(agent_type, "comprehensive_agent.py")
        template_path = self.templates_dir / template_name
        
        # 템플릿이 없으면 기본 템플릿 사용
        if not template_path.exists():
            template_path = self.templates_dir / "comprehensive_agent.py.template"
            
        return template_path
    
    def _load_template(self, template_path: Path) -> str:
        """템플릿 로드"""
        try:
            with open(template_path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            logger.warning(f"템플릿 파일을 찾을 수 없음: {template_path}")
            return self._get_default_template()
    
    def _get_default_template(self) -> str:
        """기본 템플릿 반환"""
        return '''"""
자동 생성된 LogosAI 에이전트
"""

import asyncio
from typing import Dict, Any, Optional
from datetime import datetime
from loguru import logger

from logosai import (
    LogosAIAgent,
    AgentConfig, 
    AgentType,
    AgentResponse,
    AgentResponseType
)


class GeneratedAgent(LogosAIAgent):
    """자동 생성된 에이전트"""
    
    def __init__(self, config: Optional[AgentConfig] = None):
        if config is None:
            config = AgentConfig(
                name="Generated Agent",
                agent_type=AgentType.CUSTOM,
                description="자동 생성된 에이전트",
                version="1.0.0"
            )
        super().__init__(config)
        logger.info(f"✅ {{self.name}} 초기화 완료")
    
    async def process(self, query: str, context: Optional[Dict] = None) -> AgentResponse:
        """메인 처리 로직"""
        try:
            logger.info(f"🔄 처리 시작: {{query[:50]}}...")
            
            # BUSINESS_LOGIC_CORE
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content={{"result": "처리 완료"}},
                message="에이전트 처리 완료"
            )
            
        except Exception as e:
            logger.error(f"❌ 처리 오류: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e)}},
                message=f"처리 오류: {{str(e)}}"
            )
    
    # BUSINESS_LOGIC_METHODS
'''
    
    def _substitute_variables(
        self, 
        template_code: str, 
        business_logic: Dict[str, str],
        requirements: Dict[str, Any]
    ) -> str:
        """템플릿 변수 치환"""
        
        # 1. 핵심 비즈니스 로직 치환
        if "core_logic" in business_logic:
            template_code = template_code.replace(
                "# BUSINESS_LOGIC_CORE",
                self._indent_code(business_logic["core_logic"], 12)
            )
        
        # 2. 추가 메서드들 치환
        additional_methods = []
        for key, logic in business_logic.items():
            if key != "core_logic":
                additional_methods.append(self._indent_code(logic, 4))
        
        if additional_methods:
            template_code = template_code.replace(
                "# BUSINESS_LOGIC_METHODS",
                "\n".join(additional_methods)
            )
        
        # 3. 메타데이터 치환
        template_code = template_code.replace(
            "Generated Agent",
            f"Generated {requirements['agent_type'].title()} Agent"
        )
        
        template_code = template_code.replace(
            "자동 생성된 에이전트",
            f"{requirements['primary_function']} 전용 에이전트"
        )
        
        return template_code
    
    def _indent_code(self, code: str, indent_level: int) -> str:
        """코드 들여쓰기"""
        indent = " " * indent_level
        lines = code.strip().split('\n')
        indented_lines = [indent + line if line.strip() else "" for line in lines]
        return '\n'.join(indented_lines)
    
    def _clean_assembled_code(self, code: str) -> str:
        """조립된 코드 정리"""
        # 빈 마커 제거
        code = code.replace("# BUSINESS_LOGIC_CORE", "pass")
        code = code.replace("# BUSINESS_LOGIC_METHODS", "")
        
        # 중복 import 제거
        lines = code.split('\n')
        seen_imports = set()
        cleaned_lines = []
        
        for line in lines:
            if line.strip().startswith(('import ', 'from ')):
                if line not in seen_imports:
                    seen_imports.add(line)
                    cleaned_lines.append(line)
            else:
                cleaned_lines.append(line)
        
        return '\n'.join(cleaned_lines)


class CodeValidator:
    """코드 검증 및 수정"""
    
    async def validate_and_fix(self, code: str) -> Tuple[str, List[str]]:
        """코드 검증 및 자동 수정"""
        errors = []
        
        # 1. 구문 검증
        syntax_valid, syntax_errors = self._check_syntax(code)
        if not syntax_valid:
            errors.extend(syntax_errors)
            code = self._fix_syntax_errors(code, syntax_errors)
        
        # 2. Import 검증
        import_valid, import_errors = self._check_imports(code)
        if not import_valid:
            errors.extend(import_errors)
            code = self._fix_import_errors(code)
        
        # 3. 논리적 구조 검증
        structure_valid, structure_errors = self._check_structure(code)
        if not structure_valid:
            errors.extend(structure_errors)
            code = self._fix_structure_errors(code)
        
        return code, errors
    
    def _check_syntax(self, code: str) -> Tuple[bool, List[str]]:
        """구문 검증"""
        try:
            compile(code, '<string>', 'exec')
            return True, []
        except SyntaxError as e:
            return False, [f"구문 오류: {e.msg} (라인 {e.lineno})"]
    
    def _check_imports(self, code: str) -> Tuple[bool, List[str]]:
        """Import 검증"""
        errors = []
        
        # 필수 import 확인
        required_imports = [
            "from logosai import",
            "from loguru import logger"
        ]
        
        for required in required_imports:
            if required not in code:
                errors.append(f"필수 import 누락: {required}")
        
        return len(errors) == 0, errors
    
    def _check_structure(self, code: str) -> Tuple[bool, List[str]]:
        """구조 검증"""
        errors = []
        
        # 필수 메서드 확인
        if "async def process(" not in code:
            errors.append("process 메서드 누락")
        
        if "class " not in code:
            errors.append("클래스 정의 누락")
        
        return len(errors) == 0, errors
    
    def _fix_syntax_errors(self, code: str, errors: List[str]) -> str:
        """구문 오류 수정"""
        # 일반적인 구문 오류 패턴 수정
        fixes = [
            (r'f"""([^"]*?)"""', r'f"\1"'),  # f-string 삼중 따옴표 수정
            (r'}}"""', r'}}'),  # 잘못된 따옴표 종료
            (r'```', ''),  # 마크다운 블록 제거
        ]
        
        for pattern, replacement in fixes:
            code = re.sub(pattern, replacement, code, flags=re.DOTALL)
        
        return code
    
    def _fix_import_errors(self, code: str) -> str:
        """Import 오류 수정"""
        lines = code.split('\n')
        
        # 필수 import가 없으면 추가
        if "from loguru import logger" not in code:
            lines.insert(0, "from loguru import logger")
        
        return '\n'.join(lines)
    
    def _fix_structure_errors(self, code: str) -> str:
        """구조 오류 수정"""
        # 기본 구조가 없으면 템플릿 적용
        if "async def process(" not in code:
            code += '''
    
    async def process(self, query: str, context: Optional[Dict] = None) -> AgentResponse:
        """기본 처리 메서드"""
        return AgentResponse(
            type=AgentResponseType.SUCCESS,
            content={"result": "기본 응답"},
            message="처리 완료"
        )
'''
        
        return code


class UnifiedAgentGenerator:
    """통합 에이전트 생성기 - 단일 책임, 최고 성능"""
    
    def __init__(self, templates_dir: str = "forge/templates"):
        self.templates_dir = templates_dir
        self.business_logic_extractor = BusinessLogicExtractor()
        self.response_parser = StandardResponseParser()
        self.code_assembler = AgentCodeAssembler(templates_dir)
        self.code_validator = CodeValidator()
        
        logger.info("🚀 UnifiedAgentGenerator 초기화 완료")
    
    async def generate_agent(
        self, 
        request: AgentGenerationRequest,
        llm_client=None
    ) -> AgentGenerationResult:
        """
        통합 에이전트 생성 - 단일 진입점
        
        Args:
            request: 에이전트 생성 요청
            llm_client: LLM 클라이언트 (선택적)
            
        Returns:
            AgentGenerationResult: 완성된 에이전트와 메타데이터
        """
        
        start_time = datetime.now()
        generation_id = str(uuid.uuid4())[:8]
        
        logger.info(f"🏗️ 에이전트 생성 시작 [{generation_id}]: {request.user_request[:50]}...")
        
        try:
            # Phase 1: 요구사항 분석
            logger.info(f"📋 [1/5] 요구사항 분석 중...")
            requirements = await self.business_logic_extractor.extract_requirements(
                request.user_request
            )
            
            # Phase 2: 비즈니스 로직 생성
            logger.info(f"🧠 [2/5] 비즈니스 로직 생성 중...")
            business_logic = await self.business_logic_extractor.generate_business_logic(
                requirements
            )
            
            # Phase 3: 코드 조립
            logger.info(f"🔧 [3/5] 에이전트 코드 조립 중...")
            assembled_code = await self.code_assembler.assemble_agent(
                requirements, business_logic
            )
            
            # Phase 4: 검증 및 수정
            logger.info(f"✅ [4/5] 코드 검증 및 수정 중...")
            validated_code, validation_errors = await self.code_validator.validate_and_fix(
                assembled_code
            )
            
            # Phase 5: 메타데이터 생성
            logger.info(f"📊 [5/5] 메타데이터 생성 중...")
            generation_time = (datetime.now() - start_time).total_seconds()
            
            metadata = {
                "generation_id": generation_id,
                "timestamp": datetime.now().isoformat(),
                "generation_time_seconds": generation_time,
                "requirements": requirements,
                "business_logic_keys": list(business_logic.keys()),
                "validation_errors": validation_errors,
                "user_email": request.user_email,
                "session_id": request.session_id,
                "quality_level": request.quality_level,
                "template_used": requirements["agent_type"],
                "success": True
            }
            
            logger.success(f"🎉 에이전트 생성 완료 [{generation_id}] - {generation_time:.2f}초")
            
            return AgentGenerationResult(
                agent_code=validated_code,
                metadata=metadata,
                validation_status="success" if not validation_errors else "warning",
                error_log=validation_errors if validation_errors else None
            )
            
        except Exception as e:
            logger.error(f"❌ 에이전트 생성 실패 [{generation_id}]: {e}")
            
            # 실패 시에도 기본 에이전트 제공
            fallback_code = self._generate_fallback_agent(request.user_request)
            generation_time = (datetime.now() - start_time).total_seconds()
            
            return AgentGenerationResult(
                agent_code=fallback_code,
                metadata={
                    "generation_id": generation_id,
                    "timestamp": datetime.now().isoformat(),
                    "generation_time_seconds": generation_time,
                    "error": str(e),
                    "fallback_used": True,
                    "success": False
                },
                validation_status="fallback",
                error_log=[str(e)]
            )
    
    def _generate_fallback_agent(self, user_request: str) -> str:
        """실패 시 폴백 에이전트 생성"""
        return '''"""
폴백 에이전트 - 기본 처리 기능
사용자 요청: ''' + user_request[:100] + '''...
"""

import asyncio
from typing import Dict, Any, Optional
from datetime import datetime
from loguru import logger

from logosai import (
    LogosAIAgent,
    AgentConfig,
    AgentType, 
    AgentResponse,
    AgentResponseType
)


class FallbackAgent(LogosAIAgent):
    """폴백 에이전트 - 기본 기능만 제공"""
    
    def __init__(self, config: Optional[AgentConfig] = None):
        if config is None:
            config = AgentConfig(
                name="Fallback Agent",
                agent_type=AgentType.CUSTOM,
                description="기본 처리 기능을 제공하는 폴백 에이전트",
                version="1.0.0"
            )
        super().__init__(config)
        logger.info(f"⚠️ {self.name} 초기화 (폴백 모드)")
    
    async def process(self, query: str, context: Optional[Dict] = None) -> AgentResponse:
        """기본 처리"""
        try:
            logger.info(f"🔄 폴백 처리: {query[:50]}...")
            
            result = {
                "message": "폴백 에이전트가 기본 응답을 제공합니다.",
                "query": query,
                "processed_at": datetime.now().isoformat(),
                "note": "더 정확한 처리를 위해 요청을 다시 시도해주세요."
            }
            
            return AgentResponse(
                type=AgentResponseType.SUCCESS,
                content=result,
                message="폴백 처리 완료"
            )
            
        except Exception as e:
            logger.error(f"❌ 폴백 처리 오류: {e}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={"error": str(e)},
                message=f"폴백 처리 오류: {str(e)}"
            )
'''

    async def test_generated_agent(self, agent_code: str, test_query: str = "테스트") -> Dict[str, Any]:
        """생성된 에이전트 테스트"""
        try:
            # 간단한 구문 검증
            compile(agent_code, '<string>', 'exec')
            
            return {
                "syntax_valid": True,
                "test_status": "passed",
                "message": "에이전트 코드가 문법적으로 올바릅니다."
            }
            
        except SyntaxError as e:
            return {
                "syntax_valid": False,
                "test_status": "failed", 
                "error": str(e),
                "line": e.lineno
            }
        except Exception as e:
            return {
                "syntax_valid": False,
                "test_status": "error",
                "error": str(e)
            }


# 편의 함수
async def generate_agent_simple(user_request: str, user_email: str = "default@logos.ai") -> str:
    """간단한 에이전트 생성 함수"""
    generator = UnifiedAgentGenerator()
    request = AgentGenerationRequest(
        user_request=user_request,
        user_email=user_email
    )
    
    result = await generator.generate_agent(request)
    return result.agent_code


if __name__ == "__main__":
    # 테스트 실행
    async def test():
        request = AgentGenerationRequest(
            user_request="CSV 파일을 분석해서 차트로 보여주는 에이전트를 만들어줘"
        )
        
        generator = UnifiedAgentGenerator()
        result = await generator.generate_agent(request)
        
        print("🎉 생성 완료!")
        print(f"검증 상태: {result.validation_status}")
        print(f"생성 시간: {result.metadata['generation_time_seconds']:.2f}초")
        print("=" * 50)
        print(result.agent_code[:500] + "...")
    
    asyncio.run(test())