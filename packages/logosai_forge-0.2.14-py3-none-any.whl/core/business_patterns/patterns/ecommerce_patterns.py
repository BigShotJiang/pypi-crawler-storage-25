"""
E-commerce Patterns - 이커머스 관련 비즈니스 패턴
장바구니, 주문, 결제, 배송, 재고 관리 등
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# SHOPPING CART - 장바구니 관리
# ============================================================================

SHOPPING_CART_PATTERN = BusinessPattern(
    id="ecommerce_cart",
    name="장바구니 관리 패턴",
    name_en="Shopping Cart Pattern",
    category=PatternCategory.AUTOMATION,
    description="장바구니 상품 추가, 수정, 삭제 관리 패턴",
    trigger_keywords=[
        "장바구니", "cart", "카트", "담기", "add to cart",
        "basket", "쇼핑백"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        ),
        PatternSlot(
            name="product_id",
            type="str",
            required=True,
            description="상품 ID"
        ),
        PatternSlot(
            name="quantity",
            type="int",
            required=False,
            default=1,
            description="수량"
        )
    ],
    code_template="""
class ShoppingCart:
    async def add_to_cart(self, user_id: str, product_id: str, quantity: int = 1):
        '''장바구니에 상품 추가'''
        
        # 상품 정보 조회
        product = await self.db.products.find_one({'id': product_id})
        
        if not product:
            return {'status': 'error', 'error': 'Product not found'}
        
        # 재고 확인
        if product['stock'] < quantity:
            return {
                'status': 'error',
                'error': 'Insufficient stock',
                'available': product['stock']
            }
        
        # 장바구니 조회/생성
        cart = await self.db.carts.find_one({'user_id': user_id})
        
        if not cart:
            cart = {
                'user_id': user_id,
                'items': [],
                'total': 0,
                'created_at': datetime.now()
            }
        
        # 기존 상품 확인
        existing_item = next(
            (item for item in cart['items'] if item['product_id'] == product_id),
            None
        )
        
        if existing_item:
            existing_item['quantity'] += quantity
            existing_item['subtotal'] = existing_item['quantity'] * product['price']
        else:
            cart['items'].append({
                'product_id': product_id,
                'product_name': product['name'],
                'price': product['price'],
                'quantity': quantity,
                'subtotal': product['price'] * quantity
            })
        
        # 총액 계산
        cart['total'] = sum(item['subtotal'] for item in cart['items'])
        
        # 저장
        await self.db.carts.replace_one(
            {'user_id': user_id},
            cart,
            upsert=True
        )
        
        return {
            'status': 'success',
            'cart': cart,
            'item_count': len(cart['items'])
        }
    
    async def update_cart_item(self, user_id: str, product_id: str, quantity: int):
        '''장바구니 상품 수량 수정'''
        if quantity <= 0:
            return await self.remove_from_cart(user_id, product_id)
        
        # 나머지 로직...
""",
    priority=10
)

# ============================================================================
# ORDER PROCESSING - 주문 처리
# ============================================================================

ORDER_PROCESSING_PATTERN = BusinessPattern(
    id="ecommerce_order",
    name="주문 처리 패턴",
    name_en="Order Processing Pattern",
    category=PatternCategory.AUTOMATION,
    description="주문 생성, 처리, 상태 관리 패턴",
    trigger_keywords=[
        "주문", "order", "구매", "purchase", "결제",
        "checkout", "buy", "주문하기"
    ],
    slots=[
        PatternSlot(
            name="cart_id",
            type="str",
            required=True,
            description="장바구니 ID"
        ),
        PatternSlot(
            name="payment_method",
            type="str",
            required=True,
            description="결제 방법"
        )
    ],
    code_template="""
async def create_order(self, user_id: str, shipping_address: Dict, payment_method: str):
    '''주문 생성 및 처리'''
    
    # 장바구니 조회
    cart = await self.db.carts.find_one({'user_id': user_id})
    
    if not cart or not cart['items']:
        return {'status': 'error', 'error': 'Cart is empty'}
    
    # 재고 재확인
    for item in cart['items']:
        product = await self.db.products.find_one({'id': item['product_id']})
        if product['stock'] < item['quantity']:
            return {
                'status': 'error',
                'error': f'Insufficient stock for {item["product_name"]}'
            }
    
    # 주문 생성
    order = {
        'id': self.generate_order_id(),
        'user_id': user_id,
        'items': cart['items'],
        'subtotal': cart['total'],
        'shipping_fee': self.calculate_shipping_fee(shipping_address),
        'tax': self.calculate_tax(cart['total']),
        'total': 0,  # 계산 예정
        'shipping_address': shipping_address,
        'payment_method': payment_method,
        'status': 'pending',
        'created_at': datetime.now()
    }
    
    order['total'] = order['subtotal'] + order['shipping_fee'] + order['tax']
    
    # 결제 처리
    payment_result = await self.process_payment(order, payment_method)
    
    if payment_result['status'] != 'success':
        return {
            'status': 'error',
            'error': 'Payment failed',
            'details': payment_result
        }
    
    # 재고 차감
    for item in cart['items']:
        await self.db.products.update_one(
            {'id': item['product_id']},
            {'$inc': {'stock': -item['quantity']}}
        )
    
    # 주문 저장
    order['status'] = 'confirmed'
    order['payment_id'] = payment_result['payment_id']
    await self.db.orders.insert_one(order)
    
    # 장바구니 비우기
    await self.db.carts.delete_one({'user_id': user_id})
    
    # 주문 확인 이메일
    await self.send_order_confirmation_email(user_id, order)
    
    return {
        'status': 'success',
        'order_id': order['id'],
        'total': order['total']
    }
""",
    priority=10
)

# ============================================================================
# PAYMENT PROCESSING - 결제 처리
# ============================================================================

PAYMENT_PROCESSING_PATTERN = BusinessPattern(
    id="ecommerce_payment",
    name="결제 처리 패턴",
    name_en="Payment Processing Pattern",
    category=PatternCategory.AUTOMATION,
    description="다양한 결제 수단을 통한 결제 처리 패턴",
    trigger_keywords=[
        "결제", "payment", "pay", "카드", "card",
        "이체", "transfer", "페이", "checkout"
    ],
    slots=[
        PatternSlot(
            name="amount",
            type="float",
            required=True,
            description="결제 금액"
        ),
        PatternSlot(
            name="method",
            type="str",
            required=True,
            description="결제 방법"
        )
    ],
    code_template="""
class PaymentProcessor:
    async def process_payment(self, order: Dict, method: str):
        '''결제 처리'''
        
        payment = {
            'id': self.generate_payment_id(),
            'order_id': order['id'],
            'amount': order['total'],
            'method': method,
            'status': 'processing',
            'created_at': datetime.now()
        }
        
        try:
            if method == 'credit_card':
                result = await self.process_card_payment(payment)
            elif method == 'bank_transfer':
                result = await self.process_bank_transfer(payment)
            elif method == 'paypal':
                result = await self.process_paypal(payment)
            elif method == 'kakao_pay':
                result = await self.process_kakao_pay(payment)
            else:
                return {'status': 'error', 'error': 'Unsupported payment method'}
            
            payment['status'] = result['status']
            payment['transaction_id'] = result.get('transaction_id')
            
            # 결제 기록 저장
            await self.db.payments.insert_one(payment)
            
            return result
            
        except Exception as e:
            payment['status'] = 'failed'
            payment['error'] = str(e)
            await self.db.payments.insert_one(payment)
            
            return {'status': 'error', 'error': str(e)}
    
    async def process_card_payment(self, payment: Dict):
        '''신용카드 결제'''
        # Stripe API 예제
        import stripe
        
        charge = stripe.Charge.create(
            amount=int(payment['amount'] * 100),
            currency='krw',
            source=payment['card_token'],
            description=f"Order {payment['order_id']}"
        )
        
        return {
            'status': 'success',
            'transaction_id': charge.id
        }
""",
    priority=9
)

# ============================================================================
# INVENTORY MANAGEMENT - 재고 관리
# ============================================================================

INVENTORY_MANAGEMENT_PATTERN = BusinessPattern(
    id="ecommerce_inventory",
    name="재고 관리 패턴",
    name_en="Inventory Management Pattern",
    category=PatternCategory.AUTOMATION,
    description="상품 재고를 추적하고 관리하는 패턴",
    trigger_keywords=[
        "재고", "inventory", "stock", "입고", "출고",
        "재고확인", "stock check", "품절"
    ],
    slots=[
        PatternSlot(
            name="product_id",
            type="str",
            required=True,
            description="상품 ID"
        ),
        PatternSlot(
            name="quantity",
            type="int",
            required=True,
            description="수량"
        )
    ],
    code_template="""
class InventoryManager:
    async def check_stock(self, product_id: str):
        '''재고 확인'''
        product = await self.db.products.find_one({'id': product_id})
        
        if not product:
            return {'status': 'error', 'error': 'Product not found'}
        
        return {
            'status': 'success',
            'product_id': product_id,
            'stock': product['stock'],
            'reserved': product.get('reserved', 0),
            'available': product['stock'] - product.get('reserved', 0)
        }
    
    async def update_stock(self, product_id: str, quantity: int, operation: str):
        '''재고 업데이트'''
        
        if operation == 'add':
            # 입고
            result = await self.db.products.update_one(
                {'id': product_id},
                {'$inc': {'stock': quantity}}
            )
            
            # 재고 변동 이력
            await self.record_stock_movement(
                product_id, quantity, 'inbound', 'Stock added'
            )
            
        elif operation == 'remove':
            # 출고
            product = await self.db.products.find_one({'id': product_id})
            
            if product['stock'] < quantity:
                return {'status': 'error', 'error': 'Insufficient stock'}
            
            result = await self.db.products.update_one(
                {'id': product_id},
                {'$inc': {'stock': -quantity}}
            )
            
            await self.record_stock_movement(
                product_id, -quantity, 'outbound', 'Stock removed'
            )
        
        # 재고 부족 알림
        await self.check_low_stock_alert(product_id)
        
        return {'status': 'success', 'updated': result.modified_count > 0}
""",
    priority=8
)

# ============================================================================
# SHIPPING TRACKING - 배송 추적
# ============================================================================

SHIPPING_TRACKING_PATTERN = BusinessPattern(
    id="ecommerce_shipping",
    name="배송 추적 패턴",
    name_en="Shipping Tracking Pattern",
    category=PatternCategory.MONITORING,
    description="배송 상태를 추적하고 업데이트하는 패턴",
    trigger_keywords=[
        "배송", "shipping", "delivery", "택배", "tracking",
        "배송추적", "운송장", "track"
    ],
    slots=[
        PatternSlot(
            name="order_id",
            type="str",
            required=True,
            description="주문 ID"
        ),
        PatternSlot(
            name="tracking_number",
            type="str",
            required=False,
            description="운송장 번호"
        )
    ],
    code_template="""
async def track_shipment(self, order_id: str):
    '''배송 추적'''
    
    order = await self.db.orders.find_one({'id': order_id})
    
    if not order:
        return {'status': 'error', 'error': 'Order not found'}
    
    shipment = await self.db.shipments.find_one({'order_id': order_id})
    
    if not shipment:
        return {
            'status': 'pending',
            'message': 'Shipment not yet created'
        }
    
    # 배송업체 API 호출
    tracking_info = await self.get_carrier_tracking(
        shipment['carrier'],
        shipment['tracking_number']
    )
    
    # 상태 업데이트
    shipment['status'] = tracking_info['status']
    shipment['current_location'] = tracking_info.get('location')
    shipment['estimated_delivery'] = tracking_info.get('estimated_delivery')
    shipment['tracking_history'] = tracking_info.get('history', [])
    
    await self.db.shipments.replace_one(
        {'order_id': order_id},
        shipment
    )
    
    # 고객 알림
    if shipment['status'] in ['out_for_delivery', 'delivered']:
        await self.notify_customer_shipment_update(order['user_id'], shipment)
    
    return {
        'status': 'success',
        'shipment': shipment
    }
""",
    priority=8
)

# ============================================================================
# PRODUCT RECOMMENDATION - 상품 추천
# ============================================================================

PRODUCT_RECOMMENDATION_PATTERN = BusinessPattern(
    id="ecommerce_recommendation",
    name="상품 추천 패턴",
    name_en="Product Recommendation Pattern",
    category=PatternCategory.ANALYTICS,
    description="사용자 맞춤 상품을 추천하는 패턴",
    trigger_keywords=[
        "추천", "recommendation", "suggest", "관련상품",
        "추천상품", "similar", "맞춤상품"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=False,
            description="사용자 ID"
        ),
        PatternSlot(
            name="product_id",
            type="str",
            required=False,
            description="기준 상품 ID"
        )
    ],
    code_template="""
async def get_recommendations(self, user_id: str = None, product_id: str = None):
    '''상품 추천 생성'''
    
    recommendations = []
    
    if user_id:
        # 사용자 기반 추천
        user_history = await self.get_user_purchase_history(user_id)
        user_preferences = await self.analyze_user_preferences(user_history)
        
        # 협업 필터링
        similar_users = await self.find_similar_users(user_id)
        collaborative_recs = await self.get_collaborative_recommendations(similar_users)
        
        recommendations.extend(collaborative_recs[:5])
        
    if product_id:
        # 상품 기반 추천
        product = await self.db.products.find_one({'id': product_id})
        
        # 컨텐츠 기반 필터링
        similar_products = await self.find_similar_products(
            product['category'],
            product['tags'],
            product['price_range']
        )
        
        recommendations.extend(similar_products[:5])
    
    # 인기 상품 추가
    if len(recommendations) < 10:
        trending = await self.get_trending_products()
        recommendations.extend(trending[:10-len(recommendations)])
    
    # 중복 제거 및 순위 조정
    recommendations = self.rank_recommendations(recommendations)
    
    return {
        'status': 'success',
        'recommendations': recommendations[:10]
    }
""",
    priority=7
)

# ============================================================================
# COUPON MANAGEMENT - 쿠폰 관리
# ============================================================================

COUPON_MANAGEMENT_PATTERN = BusinessPattern(
    id="ecommerce_coupon",
    name="쿠폰 관리 패턴",
    name_en="Coupon Management Pattern",
    category=PatternCategory.PRICING,
    description="할인 쿠폰을 생성하고 관리하는 패턴",
    trigger_keywords=[
        "쿠폰", "coupon", "할인", "discount", "프로모션",
        "promotion", "voucher", "할인코드"
    ],
    slots=[
        PatternSlot(
            name="code",
            type="str",
            required=True,
            description="쿠폰 코드"
        ),
        PatternSlot(
            name="discount_type",
            type="str",
            required=True,
            description="할인 타입 (percentage/fixed)"
        )
    ],
    code_template="""
class CouponManager:
    async def create_coupon(self, code: str, discount_type: str, 
                           discount_value: float, conditions: Dict = None):
        '''쿠폰 생성'''
        
        # 중복 확인
        if await self.db.coupons.find_one({'code': code}):
            return {'status': 'error', 'error': 'Coupon code already exists'}
        
        coupon = {
            'code': code,
            'type': discount_type,
            'value': discount_value,
            'conditions': conditions or {},
            'usage_count': 0,
            'max_usage': conditions.get('max_usage', 100),
            'valid_from': conditions.get('valid_from', datetime.now()),
            'valid_until': conditions.get('valid_until'),
            'active': True,
            'created_at': datetime.now()
        }
        
        await self.db.coupons.insert_one(coupon)
        
        return {'status': 'success', 'coupon': coupon}
    
    async def apply_coupon(self, code: str, cart_total: float, user_id: str):
        '''쿠폰 적용'''
        
        coupon = await self.db.coupons.find_one({'code': code, 'active': True})
        
        if not coupon:
            return {'status': 'error', 'error': 'Invalid coupon'}
        
        # 유효기간 확인
        if coupon.get('valid_until') and coupon['valid_until'] < datetime.now():
            return {'status': 'error', 'error': 'Coupon expired'}
        
        # 사용 횟수 확인
        if coupon['usage_count'] >= coupon['max_usage']:
            return {'status': 'error', 'error': 'Coupon usage limit reached'}
        
        # 할인 계산
        if coupon['type'] == 'percentage':
            discount = cart_total * (coupon['value'] / 100)
        else:
            discount = min(coupon['value'], cart_total)
        
        return {
            'status': 'success',
            'discount': discount,
            'final_total': cart_total - discount
        }
""",
    priority=7
)

# ============================================================================
# REFUND PROCESSING - 환불 처리
# ============================================================================

REFUND_PROCESSING_PATTERN = BusinessPattern(
    id="ecommerce_refund",
    name="환불 처리 패턴",
    name_en="Refund Processing Pattern",
    category=PatternCategory.AUTOMATION,
    description="주문 취소 및 환불을 처리하는 패턴",
    trigger_keywords=[
        "환불", "refund", "취소", "cancel", "반품",
        "return", "교환", "exchange"
    ],
    slots=[
        PatternSlot(
            name="order_id",
            type="str",
            required=True,
            description="주문 ID"
        ),
        PatternSlot(
            name="reason",
            type="str",
            required=True,
            description="환불 사유"
        )
    ],
    code_template="""
async def process_refund(self, order_id: str, reason: str, items: List[Dict] = None):
    '''환불 처리'''
    
    order = await self.db.orders.find_one({'id': order_id})
    
    if not order:
        return {'status': 'error', 'error': 'Order not found'}
    
    # 환불 가능 상태 확인
    if order['status'] not in ['confirmed', 'shipped']:
        return {'status': 'error', 'error': 'Order cannot be refunded'}
    
    # 부분/전체 환불 결정
    if items:
        # 부분 환불
        refund_amount = sum(
            item['price'] * item['quantity'] 
            for item in items
        )
    else:
        # 전체 환불
        refund_amount = order['total']
        items = order['items']
    
    # 환불 생성
    refund = {
        'id': self.generate_refund_id(),
        'order_id': order_id,
        'amount': refund_amount,
        'reason': reason,
        'items': items,
        'status': 'pending',
        'created_at': datetime.now()
    }
    
    # 결제 취소
    payment_result = await self.reverse_payment(
        order['payment_id'],
        refund_amount
    )
    
    if payment_result['status'] == 'success':
        refund['status'] = 'completed'
        refund['completed_at'] = datetime.now()
        
        # 재고 복원
        for item in items:
            await self.db.products.update_one(
                {'id': item['product_id']},
                {'$inc': {'stock': item['quantity']}}
            )
        
        # 주문 상태 업데이트
        await self.db.orders.update_one(
            {'id': order_id},
            {'$set': {'status': 'refunded'}}
        )
    
    # 환불 기록 저장
    await self.db.refunds.insert_one(refund)
    
    # 고객 알림
    await self.send_refund_notification(order['user_id'], refund)
    
    return {'status': 'success', 'refund': refund}
""",
    priority=8
)

# ============================================================================
# WISHLIST MANAGEMENT - 위시리스트 관리
# ============================================================================

WISHLIST_MANAGEMENT_PATTERN = BusinessPattern(
    id="ecommerce_wishlist",
    name="위시리스트 관리 패턴",
    name_en="Wishlist Management Pattern",
    category=PatternCategory.AUTOMATION,
    description="사용자 위시리스트를 관리하는 패턴",
    trigger_keywords=[
        "위시리스트", "wishlist", "찜", "관심상품",
        "즐겨찾기", "favorites", "좋아요"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        ),
        PatternSlot(
            name="product_id",
            type="str",
            required=True,
            description="상품 ID"
        )
    ],
    code_template="""
async def manage_wishlist(self, user_id: str, product_id: str, action: str):
    '''위시리스트 관리'''
    
    wishlist = await self.db.wishlists.find_one({'user_id': user_id})
    
    if not wishlist:
        wishlist = {
            'user_id': user_id,
            'items': [],
            'created_at': datetime.now()
        }
    
    if action == 'add':
        # 추가
        if product_id not in [item['product_id'] for item in wishlist['items']]:
            product = await self.db.products.find_one({'id': product_id})
            
            wishlist['items'].append({
                'product_id': product_id,
                'product_name': product['name'],
                'price': product['price'],
                'added_at': datetime.now()
            })
            
            # 가격 변동 알림 설정
            await self.setup_price_alert(user_id, product_id)
    
    elif action == 'remove':
        # 제거
        wishlist['items'] = [
            item for item in wishlist['items'] 
            if item['product_id'] != product_id
        ]
    
    # 저장
    await self.db.wishlists.replace_one(
        {'user_id': user_id},
        wishlist,
        upsert=True
    )
    
    return {
        'status': 'success',
        'wishlist': wishlist,
        'item_count': len(wishlist['items'])
    }
""",
    priority=6
)

# ============================================================================
# REVIEW RATING - 리뷰 및 평점
# ============================================================================

REVIEW_RATING_PATTERN = BusinessPattern(
    id="ecommerce_review",
    name="리뷰 및 평점 패턴",
    name_en="Review & Rating Pattern",
    category=PatternCategory.AUTOMATION,
    description="상품 리뷰와 평점을 관리하는 패턴",
    trigger_keywords=[
        "리뷰", "review", "평점", "rating", "별점",
        "후기", "평가", "feedback"
    ],
    slots=[
        PatternSlot(
            name="product_id",
            type="str",
            required=True,
            description="상품 ID"
        ),
        PatternSlot(
            name="rating",
            type="int",
            required=True,
            description="평점 (1-5)"
        )
    ],
    code_template="""
async def submit_review(self, user_id: str, product_id: str, 
                       rating: int, comment: str = None, images: List[str] = None):
    '''리뷰 제출'''
    
    # 구매 확인
    purchase = await self.db.orders.find_one({
        'user_id': user_id,
        'items.product_id': product_id,
        'status': 'delivered'
    })
    
    if not purchase:
        return {'status': 'error', 'error': 'Product not purchased'}
    
    # 중복 리뷰 확인
    existing = await self.db.reviews.find_one({
        'user_id': user_id,
        'product_id': product_id
    })
    
    if existing:
        return {'status': 'error', 'error': 'Already reviewed'}
    
    # 리뷰 생성
    review = {
        'id': self.generate_id(),
        'user_id': user_id,
        'product_id': product_id,
        'rating': rating,
        'comment': comment,
        'images': images or [],
        'verified_purchase': True,
        'helpful_count': 0,
        'created_at': datetime.now()
    }
    
    await self.db.reviews.insert_one(review)
    
    # 상품 평점 업데이트
    await self.update_product_rating(product_id)
    
    # 포인트 지급
    if comment or images:
        await self.award_review_points(user_id, 100)
    
    return {'status': 'success', 'review': review}
""",
    priority=6
)

# 패턴 등록
register_pattern(SHOPPING_CART_PATTERN)
register_pattern(ORDER_PROCESSING_PATTERN)
register_pattern(PAYMENT_PROCESSING_PATTERN)
register_pattern(INVENTORY_MANAGEMENT_PATTERN)
register_pattern(SHIPPING_TRACKING_PATTERN)
register_pattern(PRODUCT_RECOMMENDATION_PATTERN)
register_pattern(COUPON_MANAGEMENT_PATTERN)
register_pattern(REFUND_PROCESSING_PATTERN)
register_pattern(WISHLIST_MANAGEMENT_PATTERN)
register_pattern(REVIEW_RATING_PATTERN)