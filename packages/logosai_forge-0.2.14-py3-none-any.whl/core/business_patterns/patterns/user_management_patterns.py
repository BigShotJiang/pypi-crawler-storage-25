"""
User Management Patterns - 사용자 관리 관련 비즈니스 패턴
회원가입, 로그인, 프로필, 권한 관리 등
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# USER REGISTRATION - 사용자 등록
# ============================================================================

USER_REGISTRATION_PATTERN = BusinessPattern(
    id="user_registration",
    name="사용자 등록 패턴",
    name_en="User Registration Pattern",
    category=PatternCategory.AUTOMATION,
    description="새로운 사용자를 등록하고 검증하는 패턴",
    trigger_keywords=[
        "회원가입", "registration", "signup", "sign up", "등록",
        "사용자 생성", "create account", "계정 생성"
    ],
    slots=[
        PatternSlot(
            name="email",
            type="str",
            required=True,
            description="사용자 이메일"
        ),
        PatternSlot(
            name="password",
            type="str",
            required=True,
            description="비밀번호"
        ),
        PatternSlot(
            name="username",
            type="str",
            required=False,
            description="사용자명"
        )
    ],
    code_template="""
async def register_user(self, email: str, password: str, username: str = None, 
                       profile_data: Dict = None):
    '''사용자 등록 처리'''
    import hashlib
    import secrets
    from datetime import datetime
    
    # 이메일 중복 검사
    if await self.check_email_exists(email):
        return {
            'status': 'error',
            'error': 'Email already registered'
        }
    
    # 사용자명 중복 검사
    if username and await self.check_username_exists(username):
        return {
            'status': 'error',
            'error': 'Username already taken'
        }
    
    # 비밀번호 강도 검사
    if not self.validate_password_strength(password):
        return {
            'status': 'error',
            'error': 'Password does not meet requirements'
        }
    
    # 비밀번호 해싱
    salt = secrets.token_hex(32)
    password_hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    ).hex()
    
    # 사용자 생성
    user = {
        'id': self.generate_id(),
        'email': email,
        'username': username or email.split('@')[0],
        'password_hash': password_hash,
        'salt': salt,
        'created_at': datetime.now(),
        'email_verified': False,
        'status': 'pending',
        'profile': profile_data or {}
    }
    
    # DB 저장
    await self.db.users.insert_one(user)
    
    # 이메일 인증 토큰 생성
    verification_token = secrets.token_urlsafe(32)
    await self.store_verification_token(user['id'], verification_token)
    
    # 인증 이메일 발송
    await self.send_verification_email(email, verification_token)
    
    return {
        'status': 'success',
        'user_id': user['id'],
        'message': 'Registration successful. Please verify your email.'
    }
""",
    priority=10
)

# ============================================================================
# USER LOGIN - 사용자 로그인
# ============================================================================

USER_LOGIN_PATTERN = BusinessPattern(
    id="user_login",
    name="사용자 로그인 패턴",
    name_en="User Login Pattern",
    category=PatternCategory.AUTOMATION,
    description="사용자 인증 및 로그인 처리 패턴",
    trigger_keywords=[
        "로그인", "login", "signin", "sign in", "인증",
        "authentication", "접속"
    ],
    slots=[
        PatternSlot(
            name="email",
            type="str",
            required=True,
            description="이메일 또는 사용자명"
        ),
        PatternSlot(
            name="password",
            type="str",
            required=True,
            description="비밀번호"
        )
    ],
    code_template="""
async def login_user(self, email_or_username: str, password: str, 
                    device_info: Dict = None):
    '''사용자 로그인 처리'''
    import hashlib
    import jwt
    from datetime import datetime, timedelta
    
    # 사용자 찾기
    user = await self.db.users.find_one({
        '$or': [
            {'email': email_or_username},
            {'username': email_or_username}
        ]
    })
    
    if not user:
        return {
            'status': 'error',
            'error': 'Invalid credentials'
        }
    
    # 비밀번호 검증
    password_hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        user['salt'].encode('utf-8'),
        100000
    ).hex()
    
    if password_hash != user['password_hash']:
        # 실패 횟수 업데이트
        await self.increment_failed_attempts(user['id'])
        return {
            'status': 'error',
            'error': 'Invalid credentials'
        }
    
    # 계정 상태 확인
    if user['status'] == 'suspended':
        return {
            'status': 'error',
            'error': 'Account suspended'
        }
    
    # JWT 토큰 생성
    token_payload = {
        'user_id': str(user['id']),
        'email': user['email'],
        'exp': datetime.utcnow() + timedelta(hours=24)
    }
    
    access_token = jwt.encode(
        token_payload,
        self.jwt_secret,
        algorithm='HS256'
    )
    
    # 리프레시 토큰 생성
    refresh_token = secrets.token_urlsafe(32)
    await self.store_refresh_token(user['id'], refresh_token)
    
    # 로그인 기록
    await self.record_login(user['id'], device_info)
    
    return {
        'status': 'success',
        'access_token': access_token,
        'refresh_token': refresh_token,
        'user': {
            'id': str(user['id']),
            'email': user['email'],
            'username': user['username']
        }
    }
""",
    priority=10
)

# ============================================================================
# PASSWORD RESET - 비밀번호 재설정
# ============================================================================

PASSWORD_RESET_PATTERN = BusinessPattern(
    id="user_password_reset",
    name="비밀번호 재설정 패턴",
    name_en="Password Reset Pattern",
    category=PatternCategory.AUTOMATION,
    description="비밀번호를 잊어버린 사용자를 위한 재설정 패턴",
    trigger_keywords=[
        "비밀번호 찾기", "password reset", "forgot password",
        "비밀번호 재설정", "reset", "비밀번호 변경"
    ],
    slots=[
        PatternSlot(
            name="email",
            type="str",
            required=True,
            description="사용자 이메일"
        )
    ],
    code_template="""
async def reset_password(self, email: str, token: str = None, new_password: str = None):
    '''비밀번호 재설정 처리'''
    
    if not token:
        # 재설정 토큰 요청
        user = await self.db.users.find_one({'email': email})
        
        if not user:
            # 보안상 이유로 존재 여부 노출하지 않음
            return {
                'status': 'success',
                'message': 'If email exists, reset link has been sent'
            }
        
        # 재설정 토큰 생성
        reset_token = secrets.token_urlsafe(32)
        expiry = datetime.now() + timedelta(hours=1)
        
        await self.db.password_resets.insert_one({
            'user_id': user['id'],
            'token': reset_token,
            'expiry': expiry,
            'used': False
        })
        
        # 재설정 이메일 발송
        await self.send_password_reset_email(email, reset_token)
        
        return {
            'status': 'success',
            'message': 'If email exists, reset link has been sent'
        }
    
    else:
        # 비밀번호 재설정 실행
        reset_record = await self.db.password_resets.find_one({
            'token': token,
            'used': False
        })
        
        if not reset_record or reset_record['expiry'] < datetime.now():
            return {
                'status': 'error',
                'error': 'Invalid or expired token'
            }
        
        # 새 비밀번호 설정
        salt = secrets.token_hex(32)
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            new_password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        
        await self.db.users.update_one(
            {'id': reset_record['user_id']},
            {'$set': {
                'password_hash': password_hash,
                'salt': salt,
                'updated_at': datetime.now()
            }}
        )
        
        # 토큰 사용 처리
        await self.db.password_resets.update_one(
            {'token': token},
            {'$set': {'used': True}}
        )
        
        return {
            'status': 'success',
            'message': 'Password reset successful'
        }
""",
    priority=9
)

# ============================================================================
# USER PROFILE - 사용자 프로필
# ============================================================================

USER_PROFILE_PATTERN = BusinessPattern(
    id="user_profile",
    name="사용자 프로필 관리",
    name_en="User Profile Management",
    category=PatternCategory.AUTOMATION,
    description="사용자 프로필 조회 및 업데이트 패턴",
    trigger_keywords=[
        "프로필", "profile", "프로필 수정", "개인정보",
        "내 정보", "my info", "settings"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        )
    ],
    code_template="""
class UserProfile:
    async def get_profile(self, user_id: str, include_private: bool = False):
        '''사용자 프로필 조회'''
        user = await self.db.users.find_one({'id': user_id})
        
        if not user:
            return {'status': 'error', 'error': 'User not found'}
        
        profile = {
            'id': user['id'],
            'username': user['username'],
            'display_name': user.get('display_name'),
            'avatar_url': user.get('avatar_url'),
            'bio': user.get('bio'),
            'created_at': user['created_at']
        }
        
        if include_private:
            profile.update({
                'email': user['email'],
                'phone': user.get('phone'),
                'settings': user.get('settings', {})
            })
        
        return {'status': 'success', 'profile': profile}
    
    async def update_profile(self, user_id: str, updates: Dict):
        '''프로필 업데이트'''
        
        # 허용된 필드만 업데이트
        allowed_fields = [
            'display_name', 'bio', 'avatar_url', 'phone',
            'settings', 'preferences'
        ]
        
        filtered_updates = {
            k: v for k, v in updates.items() 
            if k in allowed_fields
        }
        
        if not filtered_updates:
            return {'status': 'error', 'error': 'No valid fields to update'}
        
        filtered_updates['updated_at'] = datetime.now()
        
        await self.db.users.update_one(
            {'id': user_id},
            {'$set': filtered_updates}
        )
        
        return {
            'status': 'success',
            'updated_fields': list(filtered_updates.keys())
        }
""",
    priority=8
)

# ============================================================================
# ROLE PERMISSION - 역할 및 권한 관리
# ============================================================================

ROLE_PERMISSION_PATTERN = BusinessPattern(
    id="user_role_permission",
    name="역할 및 권한 관리",
    name_en="Role & Permission Management",
    category=PatternCategory.AUTOMATION,
    description="사용자 역할과 권한을 관리하는 패턴",
    trigger_keywords=[
        "역할", "role", "권한", "permission", "access",
        "admin", "moderator", "authorization"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        ),
        PatternSlot(
            name="role",
            type="str",
            required=True,
            description="역할 이름"
        )
    ],
    code_template="""
class RolePermissionManager:
    def __init__(self):
        self.roles = {
            'admin': ['read', 'write', 'delete', 'manage_users'],
            'moderator': ['read', 'write', 'delete'],
            'user': ['read', 'write'],
            'guest': ['read']
        }
    
    async def assign_role(self, user_id: str, role: str):
        '''역할 할당'''
        if role not in self.roles:
            return {'status': 'error', 'error': 'Invalid role'}
        
        await self.db.users.update_one(
            {'id': user_id},
            {'$set': {'role': role}}
        )
        
        return {
            'status': 'success',
            'role': role,
            'permissions': self.roles[role]
        }
    
    async def check_permission(self, user_id: str, permission: str):
        '''권한 확인'''
        user = await self.db.users.find_one({'id': user_id})
        
        if not user:
            return False
        
        user_role = user.get('role', 'guest')
        role_permissions = self.roles.get(user_role, [])
        
        return permission in role_permissions
    
    async def add_custom_permission(self, user_id: str, permission: str):
        '''커스텀 권한 추가'''
        await self.db.users.update_one(
            {'id': user_id},
            {'$addToSet': {'custom_permissions': permission}}
        )
        
        return {'status': 'success', 'permission': permission}
""",
    priority=8
)

# ============================================================================
# TWO FACTOR AUTH - 2단계 인증
# ============================================================================

TWO_FACTOR_AUTH_PATTERN = BusinessPattern(
    id="user_2fa",
    name="2단계 인증 패턴",
    name_en="Two Factor Authentication",
    category=PatternCategory.SECURITY,
    description="TOTP/SMS 기반 2단계 인증 패턴",
    trigger_keywords=[
        "2fa", "two factor", "2단계 인증", "otp",
        "totp", "authenticator", "보안 인증"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        ),
        PatternSlot(
            name="method",
            type="str",
            required=False,
            default="totp",
            description="2FA 방법 (totp/sms)"
        )
    ],
    code_template="""
import pyotp
import qrcode
from io import BytesIO

class TwoFactorAuth:
    async def enable_2fa(self, user_id: str, method: str = 'totp'):
        '''
2FA 활성화'''
        
        if method == 'totp':
            # TOTP 시크릿 생성
            secret = pyotp.random_base32()
            
            # QR 코드 생성
            user = await self.db.users.find_one({'id': user_id})
            totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
                name=user['email'],
                issuer_name=self.app_name
            )
            
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(totp_uri)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            buf = BytesIO()
            img.save(buf, format='PNG')
            qr_code = buf.getvalue()
            
            # 시크릿 저장
            await self.db.users.update_one(
                {'id': user_id},
                {'$set': {
                    '2fa_enabled': True,
                    '2fa_method': 'totp',
                    '2fa_secret': secret
                }}
            )
            
            return {
                'status': 'success',
                'secret': secret,
                'qr_code': qr_code,
                'backup_codes': self.generate_backup_codes()
            }
            
        elif method == 'sms':
            # SMS 2FA 설정
            await self.db.users.update_one(
                {'id': user_id},
                {'$set': {
                    '2fa_enabled': True,
                    '2fa_method': 'sms'
                }}
            )
            
            return {'status': 'success', 'method': 'sms'}
    
    async def verify_2fa(self, user_id: str, code: str):
        '''
2FA 코드 검증'''
        user = await self.db.users.find_one({'id': user_id})
        
        if not user.get('2fa_enabled'):
            return {'status': 'error', 'error': '2FA not enabled'}
        
        if user['2fa_method'] == 'totp':
            totp = pyotp.TOTP(user['2fa_secret'])
            if totp.verify(code, valid_window=1):
                return {'status': 'success', 'verified': True}
        
        return {'status': 'error', 'error': 'Invalid code'}
""",
    priority=9
)

# ============================================================================
# SESSION MANAGEMENT - 세션 관리
# ============================================================================

SESSION_MANAGEMENT_PATTERN = BusinessPattern(
    id="user_session",
    name="세션 관리 패턴",
    name_en="Session Management Pattern",
    category=PatternCategory.SECURITY,
    description="사용자 세션을 관리하고 보안을 유지하는 패턴",
    trigger_keywords=[
        "세션", "session", "로그아웃", "logout", "token",
        "리프레시", "refresh", "만료"
    ],
    slots=[
        PatternSlot(
            name="session_id",
            type="str",
            required=True,
            description="세션 ID"
        )
    ],
    code_template="""
class SessionManager:
    async def create_session(self, user_id: str, device_info: Dict = None):
        '''세션 생성'''
        session = {
            'id': self.generate_id(),
            'user_id': user_id,
            'created_at': datetime.now(),
            'last_activity': datetime.now(),
            'expires_at': datetime.now() + timedelta(hours=24),
            'device_info': device_info or {},
            'ip_address': self.get_client_ip(),
            'active': True
        }
        
        await self.db.sessions.insert_one(session)
        
        return {
            'status': 'success',
            'session_id': session['id'],
            'expires_at': session['expires_at']
        }
    
    async def validate_session(self, session_id: str):
        '''세션 유효성 검사'''
        session = await self.db.sessions.find_one({
            'id': session_id,
            'active': True
        })
        
        if not session:
            return {'valid': False, 'reason': 'Session not found'}
        
        if session['expires_at'] < datetime.now():
            await self.invalidate_session(session_id)
            return {'valid': False, 'reason': 'Session expired'}
        
        # 활동 시간 업데이트
        await self.db.sessions.update_one(
            {'id': session_id},
            {'$set': {'last_activity': datetime.now()}}
        )
        
        return {'valid': True, 'user_id': session['user_id']}
    
    async def invalidate_session(self, session_id: str):
        '''세션 무효화'''
        await self.db.sessions.update_one(
            {'id': session_id},
            {'$set': {'active': False}}
        )
        
        return {'status': 'success', 'message': 'Session invalidated'}
""",
    priority=8
)

# ============================================================================
# USER PREFERENCES - 사용자 환경설정
# ============================================================================

USER_PREFERENCES_PATTERN = BusinessPattern(
    id="user_preferences",
    name="사용자 환경설정 패턴",
    name_en="User Preferences Pattern",
    category=PatternCategory.AUTOMATION,
    description="사용자 환경설정과 기본설정을 관리하는 패턴",
    trigger_keywords=[
        "환경설정", "preferences", "settings", "설정",
        "알림 설정", "notification settings", "테마"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        ),
        PatternSlot(
            name="category",
            type="str",
            required=False,
            description="설정 카테고리"
        )
    ],
    code_template="""
class UserPreferences:
    def __init__(self):
        self.default_preferences = {
            'notifications': {
                'email': True,
                'push': True,
                'sms': False,
                'marketing': False
            },
            'privacy': {
                'profile_visibility': 'public',
                'show_online_status': True,
                'allow_messages': 'friends'
            },
            'display': {
                'theme': 'light',
                'language': 'ko',
                'timezone': 'Asia/Seoul',
                'date_format': 'YYYY-MM-DD'
            }
        }
    
    async def get_preferences(self, user_id: str, category: str = None):
        '''환경설정 조회'''
        user = await self.db.users.find_one({'id': user_id})
        
        if not user:
            return {'status': 'error', 'error': 'User not found'}
        
        preferences = user.get('preferences', self.default_preferences)
        
        if category:
            return {
                'status': 'success',
                'preferences': preferences.get(category, {})
            }
        
        return {'status': 'success', 'preferences': preferences}
    
    async def update_preferences(self, user_id: str, updates: Dict):
        '''환경설정 업데이트'''
        # 기존 설정 가져오기
        user = await self.db.users.find_one({'id': user_id})
        current_prefs = user.get('preferences', self.default_preferences)
        
        # 딥 머지
        for category, settings in updates.items():
            if category in current_prefs:
                current_prefs[category].update(settings)
        
        await self.db.users.update_one(
            {'id': user_id},
            {'$set': {'preferences': current_prefs}}
        )
        
        return {'status': 'success', 'preferences': current_prefs}
""",
    priority=7
)

# ============================================================================
# ACCOUNT DELETION - 계정 삭제
# ============================================================================

ACCOUNT_DELETION_PATTERN = BusinessPattern(
    id="user_account_deletion",
    name="계정 삭제 패턴",
    name_en="Account Deletion Pattern",
    category=PatternCategory.AUTOMATION,
    description="사용자 계정을 안전하게 삭제하는 패턴",
    trigger_keywords=[
        "계정 삭제", "delete account", "회원 탈퇴",
        "탈퇴", "withdraw", "close account"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        ),
        PatternSlot(
            name="reason",
            type="str",
            required=False,
            description="탈퇴 사유"
        )
    ],
    code_template="""
async def delete_account(self, user_id: str, password: str, reason: str = None):
    '''계정 삭제 처리'''
    
    # 비밀번호 확인
    if not await self.verify_password(user_id, password):
        return {'status': 'error', 'error': 'Invalid password'}
    
    # 사용자 데이터 백업
    user_data = await self.backup_user_data(user_id)
    
    # 관련 데이터 삭제
    deletion_tasks = [
        self.delete_user_posts(user_id),
        self.delete_user_messages(user_id),
        self.delete_user_files(user_id),
        self.invalidate_all_sessions(user_id)
    ]
    
    await asyncio.gather(*deletion_tasks)
    
    # 사용자 계정 삭제 또는 비활성화
    if self.config['soft_delete']:
        # 소프트 삭제
        await self.db.users.update_one(
            {'id': user_id},
            {'$set': {
                'status': 'deleted',
                'deleted_at': datetime.now(),
                'deletion_reason': reason
            }}
        )
    else:
        # 하드 삭제
        await self.db.users.delete_one({'id': user_id})
    
    # 탈퇴 이메일 발송
    await self.send_account_deletion_email(user_data['email'])
    
    # 탈퇴 통계 기록
    await self.record_deletion_stats(reason)
    
    return {
        'status': 'success',
        'message': 'Account deleted successfully',
        'backup_id': user_data['backup_id']
    }
""",
    priority=7
)

# ============================================================================
# SOCIAL LOGIN - 소셜 로그인
# ============================================================================

SOCIAL_LOGIN_PATTERN = BusinessPattern(
    id="user_social_login",
    name="소셜 로그인 패턴",
    name_en="Social Login Pattern",
    category=PatternCategory.AUTOMATION,
    description="OAuth를 통한 소셜 로그인 패턴",
    trigger_keywords=[
        "소셜 로그인", "oauth", "google login", "facebook login",
        "kakao login", "naver login", "github login"
    ],
    slots=[
        PatternSlot(
            name="provider",
            type="str",
            required=True,
            description="OAuth 제공자"
        ),
        PatternSlot(
            name="code",
            type="str",
            required=True,
            description="OAuth 인증 코드"
        )
    ],
    code_template="""
class SocialLoginHandler:
    def __init__(self):
        self.providers = {
            'google': {
                'client_id': os.getenv('GOOGLE_CLIENT_ID'),
                'client_secret': os.getenv('GOOGLE_CLIENT_SECRET'),
                'token_url': 'https://oauth2.googleapis.com/token',
                'user_info_url': 'https://www.googleapis.com/oauth2/v2/userinfo'
            },
            'kakao': {
                'client_id': os.getenv('KAKAO_CLIENT_ID'),
                'client_secret': os.getenv('KAKAO_CLIENT_SECRET'),
                'token_url': 'https://kauth.kakao.com/oauth/token',
                'user_info_url': 'https://kapi.kakao.com/v2/user/me'
            }
        }
    
    async def social_login(self, provider: str, code: str):
        '''소셜 로그인 처리'''
        
        if provider not in self.providers:
            return {'status': 'error', 'error': 'Unsupported provider'}
        
        config = self.providers[provider]
        
        # 액세스 토큰 획득
        token_response = await self.exchange_code_for_token(
            config['token_url'],
            code,
            config['client_id'],
            config['client_secret']
        )
        
        if not token_response.get('access_token'):
            return {'status': 'error', 'error': 'Failed to get access token'}
        
        # 사용자 정보 조회
        user_info = await self.get_user_info(
            config['user_info_url'],
            token_response['access_token']
        )
        
        # 사용자 찾기 또는 생성
        user = await self.find_or_create_social_user(
            provider,
            user_info
        )
        
        # JWT 토큰 생성
        access_token = self.generate_jwt_token(user['id'])
        
        return {
            'status': 'success',
            'access_token': access_token,
            'user': user
        }
""",
    priority=8
)

# 패턴 등록
register_pattern(USER_REGISTRATION_PATTERN)
register_pattern(USER_LOGIN_PATTERN)
register_pattern(PASSWORD_RESET_PATTERN)
register_pattern(USER_PROFILE_PATTERN)
register_pattern(ROLE_PERMISSION_PATTERN)
register_pattern(TWO_FACTOR_AUTH_PATTERN)
register_pattern(SESSION_MANAGEMENT_PATTERN)
register_pattern(USER_PREFERENCES_PATTERN)
register_pattern(ACCOUNT_DELETION_PATTERN)
register_pattern(SOCIAL_LOGIN_PATTERN)