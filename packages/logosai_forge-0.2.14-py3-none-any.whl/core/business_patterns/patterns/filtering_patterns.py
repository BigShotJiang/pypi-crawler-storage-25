"""
Filtering Patterns - 필터링/선별 관련 비즈니스 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# Pattern 1: 등급별 차등 제공
TIER_BASED_FILTERING = BusinessPattern(
    id="tier_based_filtering",
    name="등급별 차등 제공",
    name_en="Tier-based Filtering",
    category=PatternCategory.FILTERING,
    description="사용자 등급에 따라 콘텐츠나 기능을 차등 제공",
    trigger_keywords=["등급", "tier", "vip", "premium", "차등", "회원", "레벨", "멤버십"],
    slots=[
        PatternSlot(
            name="tier_field",
            type="str",
            required=True,
            default="user_tier",
            examples={
                "회원등급": "user_tier", 
                "고객등급": "customer_level", 
                "멤버십": "membership",
                "레벨": "level"
            },
            description="등급을 나타내는 필드명"
        ),
        PatternSlot(
            name="tier_limits",
            type="dict",
            required=True,
            extraction_regex=r"(\w+).*?(\d+)",
            default={"vip": 999, "premium": 50, "regular": 5},
            description="등급별 제한 수량"
        )
    ],
    code_template='''
# 등급별 필터링 로직
{tier_field} = context.get('{tier_field}', 'regular')
tier_limits = {tier_limits}

# 콘텐츠 제한 적용
max_allowed = tier_limits.get({tier_field}, tier_limits.get('regular', 5))
filtered_items = items[:max_allowed]

# 등급별 추가 처리
if {tier_field} in ['vip', 'premium']:
    # 프리미엄 기능 활성화
    if hasattr(self, '_add_premium_features'):
        filtered_items = self._add_premium_features(filtered_items)
    
# 로그 기록
logger.info(f"Applied tier filtering: {tier_field}={{{tier_field}}}, limit={{max_allowed}}")
''',
    compatibility=["news_aggregator", "content_provider", "data_analyzer", "all"],
    priority=8,
    test_cases=[
        {
            "query": "VIP 회원은 모든 뉴스, 일반 회원은 5개만",
            "expected_slots": {
                "tier_field": "user_tier", 
                "tier_limits": {"vip": 999, "regular": 5}
            }
        }
    ]
)

# Pattern 2: 개수 제한 필터
COUNT_LIMIT_FILTER = BusinessPattern(
    id="count_limit_filter",
    name="개수 제한 필터",
    name_en="Count Limit Filter",
    category=PatternCategory.FILTERING,
    description="특정 개수만큼만 데이터를 제한",
    trigger_keywords=["개만", "개까지", "제한", "limit", "최대", "maximum"],
    slots=[
        PatternSlot(
            name="limit_count",
            type="int",
            required=True,
            extraction_regex=r"(\d+)개?",
            description="제한할 개수"
        ),
        PatternSlot(
            name="target_field",
            type="str",
            required=False,
            default="items",
            examples={
                "뉴스": "articles",
                "데이터": "data_items",
                "결과": "results"
            },
            description="제한할 대상 필드"
        )
    ],
    code_template='''
# 개수 제한
limit_count = {limit_count}
{target_field} = {target_field}[:limit_count]
logger.info(f"Limited {{target_field}} to {{limit_count}} items")
''',
    compatibility=["all"],
    priority=5
)

# Pattern 3: 조건부 필터링
CONDITIONAL_FILTER = BusinessPattern(
    id="conditional_filter",
    name="조건부 필터링",
    name_en="Conditional Filter",
    category=PatternCategory.FILTERING,
    description="특정 조건을 만족하는 항목만 필터링",
    trigger_keywords=["만", "경우", "조건", "필터", "선택", "골라"],
    slots=[
        PatternSlot(
            name="filter_field",
            type="str",
            required=True,
            examples={
                "카테고리": "category",
                "상태": "status",
                "타입": "type"
            },
            description="필터링할 필드"
        ),
        PatternSlot(
            name="filter_value",
            type="str",
            required=True,
            description="필터링 값"
        ),
        PatternSlot(
            name="filter_operator",
            type="str",
            required=False,
            default="==",
            examples={
                "같은": "==",
                "다른": "!=",
                "포함": "in"
            }
        )
    ],
    code_template='''
# 조건부 필터링
filtered_items = []
for item in items:
    if item.get('{filter_field}') {filter_operator} '{filter_value}':
        filtered_items.append(item)

logger.info(f"Filtered by {filter_field} {filter_operator} {filter_value}: {{len(filtered_items)}} items")
items = filtered_items
''',
    compatibility=["all"],
    priority=6
)

# Pattern 4: 시간 기반 필터링
TIME_BASED_FILTER = BusinessPattern(
    id="time_based_filter",
    name="시간 기반 필터링",
    name_en="Time-based Filter",
    category=PatternCategory.FILTERING,
    description="시간 범위에 따른 데이터 필터링",
    trigger_keywords=["오늘", "어제", "최근", "이번주", "이번달", "기간"],
    slots=[
        PatternSlot(
            name="time_range",
            type="str",
            required=True,
            examples={
                "오늘": "today",
                "어제": "yesterday",
                "이번주": "this_week",
                "이번달": "this_month",
                "최근": "recent"
            },
            description="시간 범위"
        ),
        PatternSlot(
            name="date_field",
            type="str",
            required=False,
            default="created_at",
            examples={
                "생성일": "created_at",
                "수정일": "updated_at",
                "발행일": "published_at"
            }
        )
    ],
    code_template='''
# 시간 기반 필터링
from datetime import datetime, timedelta

now = datetime.now()
time_range = '{time_range}'
date_field = '{date_field}'

# 시간 범위 계산
if time_range == 'today':
    start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
elif time_range == 'yesterday':
    start_date = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
elif time_range == 'this_week':
    start_date = now - timedelta(days=now.weekday())
elif time_range == 'this_month':
    start_date = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
else:  # recent (최근 7일)
    start_date = now - timedelta(days=7)

# 필터링 적용
filtered_items = []
for item in items:
    item_date = item.get(date_field)
    if item_date and item_date >= start_date:
        filtered_items.append(item)

items = filtered_items
logger.info(f"Time filter applied: {{time_range}}, {{len(items)}} items remaining")
''',
    compatibility=["news_aggregator", "data_analyzer", "monitoring"],
    priority=7
)

# 패턴 등록
register_pattern(TIER_BASED_FILTERING)
register_pattern(COUNT_LIMIT_FILTER)
register_pattern(CONDITIONAL_FILTER)
register_pattern(TIME_BASED_FILTER)