"""
Content Management Patterns - 콘텐츠 관리 관련 비즈니스 패턴
CMS, 블로그, 미디어, 버전 관리 등
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# CONTENT CRUD - 콘텐츠 CRUD
# ============================================================================

CONTENT_CRUD_PATTERN = BusinessPattern(
    id="content_crud",
    name="콘텐츠 CRUD 패턴",
    name_en="Content CRUD Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠 생성, 읽기, 수정, 삭제 관리 패턴",
    trigger_keywords=[
        "콘텐츠", "content", "글", "post", "article",
        "생성", "수정", "삭제", "crud"
    ],
    slots=[
        PatternSlot(
            name="content_type",
            type="str",
            required=True,
            description="콘텐츠 타입"
        ),
        PatternSlot(
            name="title",
            type="str",
            required=True,
            description="제목"
        )
    ],
    code_template="""
class ContentManager:
    async def create_content(self, content_type: str, title: str, 
                            body: str, metadata: Dict = None):
        '''콘텐츠 생성'''
        
        content = {
            'id': self.generate_id(),
            'type': content_type,
            'title': title,
            'slug': self.generate_slug(title),
            'body': body,
            'metadata': metadata or {},
            'status': 'draft',
            'author_id': self.current_user_id,
            'created_at': datetime.now(),
            'updated_at': datetime.now(),
            'version': 1
        }
        
        # 콘텐츠 검증
        validation = self.validate_content(content)
        if not validation['valid']:
            return {'status': 'error', 'errors': validation['errors']}
        
        # SEO 메타데이터 생성
        content['seo'] = {
            'meta_title': metadata.get('meta_title', title),
            'meta_description': self.generate_meta_description(body),
            'keywords': self.extract_keywords(body)
        }
        
        await self.db.contents.insert_one(content)
        
        return {'status': 'success', 'content': content}
    
    async def update_content(self, content_id: str, updates: Dict):
        '''콘텐츠 수정'''
        
        content = await self.db.contents.find_one({'id': content_id})
        
        if not content:
            return {'status': 'error', 'error': 'Content not found'}
        
        # 버전 관리
        await self.save_version(content)
        
        updates['updated_at'] = datetime.now()
        updates['version'] = content['version'] + 1
        
        await self.db.contents.update_one(
            {'id': content_id},
            {'$set': updates}
        )
        
        return {'status': 'success', 'version': updates['version']}
""",
    priority=9
)

# ============================================================================
# VERSION CONTROL - 버전 관리
# ============================================================================

VERSION_CONTROL_PATTERN = BusinessPattern(
    id="content_version",
    name="콘텐츠 버전 관리 패턴",
    name_en="Version Control Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠 버전을 추적하고 관리하는 패턴",
    trigger_keywords=[
        "버전", "version", "이력", "history", "되돌리기",
        "rollback", "revision", "변경이력"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=True,
            description="콘텐츠 ID"
        )
    ],
    code_template="""
class VersionControl:
    async def save_version(self, content: Dict):
        '''버전 저장'''
        
        version = {
            'content_id': content['id'],
            'version_number': content['version'],
            'data': content.copy(),
            'created_at': datetime.now(),
            'created_by': self.current_user_id
        }
        
        await self.db.content_versions.insert_one(version)
        
        # 오래된 버전 정리 (최근 10개만 유지)
        old_versions = await self.db.content_versions.find(
            {'content_id': content['id']}
        ).sort('version_number', -1).skip(10).to_list(None)
        
        if old_versions:
            await self.db.content_versions.delete_many({
                '_id': {'$in': [v['_id'] for v in old_versions]}
            })
    
    async def get_version_history(self, content_id: str):
        '''버전 이력 조회'''
        
        versions = await self.db.content_versions.find(
            {'content_id': content_id}
        ).sort('version_number', -1).to_list(None)
        
        return {
            'status': 'success',
            'versions': versions,
            'total': len(versions)
        }
    
    async def rollback_to_version(self, content_id: str, version_number: int):
        '''특정 버전으로 롤백'''
        
        version = await self.db.content_versions.find_one({
            'content_id': content_id,
            'version_number': version_number
        })
        
        if not version:
            return {'status': 'error', 'error': 'Version not found'}
        
        # 현재 버전 백업
        current = await self.db.contents.find_one({'id': content_id})
        await self.save_version(current)
        
        # 롤백
        rollback_data = version['data'].copy()
        rollback_data['version'] = current['version'] + 1
        rollback_data['updated_at'] = datetime.now()
        rollback_data['rollback_from'] = current['version']
        
        await self.db.contents.replace_one(
            {'id': content_id},
            rollback_data
        )
        
        return {'status': 'success', 'rolled_back_to': version_number}
""",
    priority=8
)

# ============================================================================
# MEDIA MANAGEMENT - 미디어 관리
# ============================================================================

MEDIA_MANAGEMENT_PATTERN = BusinessPattern(
    id="content_media",
    name="미디어 관리 패턴",
    name_en="Media Management Pattern",
    category=PatternCategory.AUTOMATION,
    description="이미지, 비디오 등 미디어 파일을 관리하는 패턴",
    trigger_keywords=[
        "미디어", "media", "이미지", "image", "비디오",
        "video", "파일", "업로드", "upload"
    ],
    slots=[
        PatternSlot(
            name="file_type",
            type="str",
            required=True,
            description="파일 타입"
        )
    ],
    code_template="""
class MediaManager:
    async def upload_media(self, file_data: bytes, filename: str, 
                          content_type: str):
        '''미디어 업로드'''
        
        # 파일 검증
        if not self.validate_file_type(content_type):
            return {'status': 'error', 'error': 'Invalid file type'}
        
        file_size = len(file_data)
        if file_size > self.max_file_size:
            return {'status': 'error', 'error': 'File too large'}
        
        # 파일명 생성
        file_ext = filename.split('.')[-1]
        safe_filename = f"{self.generate_id()}.{file_ext}"
        
        # S3 업로드
        s3_key = f"media/{datetime.now().year}/{datetime.now().month}/{safe_filename}"
        
        await self.s3_client.put_object(
            Bucket=self.s3_bucket,
            Key=s3_key,
            Body=file_data,
            ContentType=content_type
        )
        
        # 썸네일 생성 (이미지인 경우)
        thumbnails = {}
        if content_type.startswith('image/'):
            thumbnails = await self.generate_thumbnails(file_data)
        
        # 메타데이터 저장
        media = {
            'id': self.generate_id(),
            'filename': filename,
            'safe_filename': safe_filename,
            's3_key': s3_key,
            'url': f"{self.cdn_url}/{s3_key}",
            'content_type': content_type,
            'size': file_size,
            'thumbnails': thumbnails,
            'uploaded_by': self.current_user_id,
            'uploaded_at': datetime.now()
        }
        
        await self.db.media.insert_one(media)
        
        return {'status': 'success', 'media': media}
    
    async def generate_thumbnails(self, image_data: bytes):
        '''썸네일 생성'''
        from PIL import Image
        import io
        
        thumbnails = {}
        sizes = {'small': (150, 150), 'medium': (300, 300), 'large': (600, 600)}
        
        img = Image.open(io.BytesIO(image_data))
        
        for size_name, dimensions in sizes.items():
            thumb = img.copy()
            thumb.thumbnail(dimensions)
            
            # 썸네일 저장
            thumb_io = io.BytesIO()
            thumb.save(thumb_io, format='JPEG')
            
            thumb_key = f"thumbnails/{size_name}/{self.generate_id()}.jpg"
            await self.s3_client.put_object(
                Bucket=self.s3_bucket,
                Key=thumb_key,
                Body=thumb_io.getvalue()
            )
            
            thumbnails[size_name] = f"{self.cdn_url}/{thumb_key}"
        
        return thumbnails
""",
    priority=8
)

# ============================================================================
# PUBLISHING WORKFLOW - 발행 워크플로우
# ============================================================================

PUBLISHING_WORKFLOW_PATTERN = BusinessPattern(
    id="content_publishing",
    name="콘텐츠 발행 워크플로우",
    name_en="Publishing Workflow Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠 작성, 검토, 승인, 발행 프로세스 관리",
    trigger_keywords=[
        "발행", "publish", "게시", "공개", "승인",
        "approval", "검토", "review"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=True,
            description="콘텐츠 ID"
        ),
        PatternSlot(
            name="action",
            type="str",
            required=True,
            description="액션 (submit/approve/publish)"
        )
    ],
    code_template="""
async def handle_publishing_workflow(self, content_id: str, action: str):
    '''발행 워크플로우 처리'''
    
    content = await self.db.contents.find_one({'id': content_id})
    
    if not content:
        return {'status': 'error', 'error': 'Content not found'}
    
    if action == 'submit':
        # 검토 요청
        if content['status'] != 'draft':
            return {'status': 'error', 'error': 'Only drafts can be submitted'}
        
        content['status'] = 'pending_review'
        content['submitted_at'] = datetime.now()
        content['submitted_by'] = self.current_user_id
        
        # 검토자에게 알림
        await self.notify_reviewers(content)
        
    elif action == 'approve':
        # 승인
        if content['status'] != 'pending_review':
            return {'status': 'error', 'error': 'Content not pending review'}
        
        content['status'] = 'approved'
        content['approved_at'] = datetime.now()
        content['approved_by'] = self.current_user_id
        
    elif action == 'publish':
        # 발행
        if content['status'] != 'approved':
            return {'status': 'error', 'error': 'Content not approved'}
        
        content['status'] = 'published'
        content['published_at'] = datetime.now()
        content['published_by'] = self.current_user_id
        
        # 발행 후처리
        await self.post_publish_tasks(content)
    
    await self.db.contents.replace_one({'id': content_id}, content)
    
    return {'status': 'success', 'content_status': content['status']}
""",
    priority=8
)

# ============================================================================
# SEARCH INDEXING - 검색 인덱싱
# ============================================================================

SEARCH_INDEXING_PATTERN = BusinessPattern(
    id="content_search",
    name="콘텐츠 검색 인덱싱 패턴",
    name_en="Search Indexing Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠를 검색 가능하도록 인덱싱하는 패턴",
    trigger_keywords=[
        "검색", "search", "인덱싱", "indexing", "색인",
        "찾기", "find", "query"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=True,
            description="콘텐츠 ID"
        )
    ],
    code_template="""
class SearchIndexer:
    async def index_content(self, content: Dict):
        '''콘텐츠 인덱싱'''
        
        # 인덱싱할 데이터 준비
        index_data = {
            'id': content['id'],
            'title': content['title'],
            'body': self.strip_html(content['body']),
            'type': content['type'],
            'author': content['author_id'],
            'tags': content.get('tags', []),
            'categories': content.get('categories', []),
            'created_at': content['created_at'],
            'status': content['status']
        }
        
        # 전문 검색 엔진에 인덱싱 (Elasticsearch 예제)
        await self.es_client.index(
            index='contents',
            id=content['id'],
            body=index_data
        )
        
        # 키워드 추출 및 저장
        keywords = self.extract_keywords(content['body'])
        await self.db.content_keywords.replace_one(
            {'content_id': content['id']},
            {
                'content_id': content['id'],
                'keywords': keywords,
                'updated_at': datetime.now()
            },
            upsert=True
        )
        
        return {'status': 'indexed', 'keywords': keywords}
    
    async def search_contents(self, query: str, filters: Dict = None):
        '''콘텐츠 검색'''
        
        # Elasticsearch 쿼리 구성
        es_query = {
            'bool': {
                'must': [
                    {'multi_match': {
                        'query': query,
                        'fields': ['title^2', 'body', 'tags']
                    }}
                ]
            }
        }
        
        # 필터 적용
        if filters:
            for field, value in filters.items():
                es_query['bool']['filter'] = {'term': {field: value}}
        
        results = await self.es_client.search(
            index='contents',
            body={'query': es_query, 'size': 20}
        )
        
        return {
            'status': 'success',
            'total': results['hits']['total']['value'],
            'results': results['hits']['hits']
        }
""",
    priority=7
)

# ============================================================================
# COMMENT SYSTEM - 댓글 시스템
# ============================================================================

COMMENT_SYSTEM_PATTERN = BusinessPattern(
    id="content_comments",
    name="댓글 시스템 패턴",
    name_en="Comment System Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠에 대한 댓글을 관리하는 패턴",
    trigger_keywords=[
        "댓글", "comment", "답글", "reply", "피드백",
        "의견", "discussion"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=True,
            description="콘텐츠 ID"
        ),
        PatternSlot(
            name="comment_text",
            type="str",
            required=True,
            description="댓글 내용"
        )
    ],
    code_template="""
class CommentSystem:
    async def add_comment(self, content_id: str, text: str, 
                         parent_id: str = None):
        '''댓글 추가'''
        
        # 스팸 체크
        if await self.is_spam(text):
            return {'status': 'error', 'error': 'Comment marked as spam'}
        
        comment = {
            'id': self.generate_id(),
            'content_id': content_id,
            'parent_id': parent_id,  # 답글인 경우
            'text': text,
            'author_id': self.current_user_id,
            'status': 'pending' if self.moderation_enabled else 'approved',
            'likes': 0,
            'created_at': datetime.now(),
            'edited': False
        }
        
        await self.db.comments.insert_one(comment)
        
        # 알림 발송
        if parent_id:
            parent_comment = await self.db.comments.find_one({'id': parent_id})
            await self.notify_comment_reply(parent_comment['author_id'], comment)
        else:
            content = await self.db.contents.find_one({'id': content_id})
            await self.notify_new_comment(content['author_id'], comment)
        
        # 댓글 수 업데이트
        await self.db.contents.update_one(
            {'id': content_id},
            {'$inc': {'comment_count': 1}}
        )
        
        return {'status': 'success', 'comment': comment}
    
    async def moderate_comment(self, comment_id: str, action: str):
        '''댓글 검토'''
        
        if action == 'approve':
            await self.db.comments.update_one(
                {'id': comment_id},
                {'$set': {'status': 'approved'}}
            )
        elif action == 'reject':
            await self.db.comments.update_one(
                {'id': comment_id},
                {'$set': {'status': 'rejected'}}
            )
        elif action == 'spam':
            await self.db.comments.update_one(
                {'id': comment_id},
                {'$set': {'status': 'spam'}}
            )
            # 스팸 학습
            comment = await self.db.comments.find_one({'id': comment_id})
            await self.train_spam_filter(comment['text'], is_spam=True)
        
        return {'status': 'success', 'action': action}
""",
    priority=7
)

# ============================================================================
# TAGGING SYSTEM - 태그 시스템
# ============================================================================

TAGGING_SYSTEM_PATTERN = BusinessPattern(
    id="content_tagging",
    name="태그 시스템 패턴",
    name_en="Tagging System Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠 태그를 관리하고 분류하는 패턴",
    trigger_keywords=[
        "태그", "tag", "라벨", "label", "분류",
        "category", "키워드"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=True,
            description="콘텐츠 ID"
        ),
        PatternSlot(
            name="tags",
            type="list",
            required=True,
            description="태그 목록"
        )
    ],
    code_template="""
class TaggingSystem:
    async def add_tags(self, content_id: str, tags: List[str]):
        '''태그 추가'''
        
        # 태그 정규화
        normalized_tags = [self.normalize_tag(tag) for tag in tags]
        
        # 콘텐츠에 태그 추가
        await self.db.contents.update_one(
            {'id': content_id},
            {'$addToSet': {'tags': {'$each': normalized_tags}}}
        )
        
        # 태그 통계 업데이트
        for tag in normalized_tags:
            await self.db.tags.update_one(
                {'name': tag},
                {
                    '$inc': {'count': 1},
                    '$setOnInsert': {'created_at': datetime.now()}
                },
                upsert=True
            )
        
        # 자동 태그 제안
        suggested_tags = await self.suggest_related_tags(normalized_tags)
        
        return {
            'status': 'success',
            'tags': normalized_tags,
            'suggested': suggested_tags
        }
    
    async def get_trending_tags(self, limit: int = 20):
        '''인기 태그 조회'''
        
        tags = await self.db.tags.find().sort('count', -1).limit(limit).to_list(None)
        
        # 태그 클라우드 데이터 생성
        max_count = tags[0]['count'] if tags else 1
        
        tag_cloud = [
            {
                'name': tag['name'],
                'count': tag['count'],
                'weight': (tag['count'] / max_count) * 100
            }
            for tag in tags
        ]
        
        return {'status': 'success', 'tags': tag_cloud}
    
    def normalize_tag(self, tag: str) -> str:
        '''태그 정규화'''
        return tag.lower().strip().replace(' ', '-')
""",
    priority=6
)

# ============================================================================
# CONTENT SCHEDULING - 콘텐츠 예약
# ============================================================================

CONTENT_SCHEDULING_PATTERN = BusinessPattern(
    id="content_scheduling",
    name="콘텐츠 예약 발행 패턴",
    name_en="Content Scheduling Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠를 예약하여 자동 발행하는 패턴",
    trigger_keywords=[
        "예약", "schedule", "예약발행", "자동발행",
        "scheduled", "future", "나중에"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=True,
            description="콘텐츠 ID"
        ),
        PatternSlot(
            name="publish_at",
            type="datetime",
            required=True,
            description="발행 예정 시간"
        )
    ],
    code_template="""
class ContentScheduler:
    async def schedule_content(self, content_id: str, publish_at: datetime):
        '''콘텐츠 예약'''
        
        content = await self.db.contents.find_one({'id': content_id})
        
        if not content:
            return {'status': 'error', 'error': 'Content not found'}
        
        if content['status'] != 'approved':
            return {'status': 'error', 'error': 'Only approved content can be scheduled'}
        
        # 예약 정보 저장
        schedule = {
            'content_id': content_id,
            'publish_at': publish_at,
            'status': 'scheduled',
            'created_at': datetime.now()
        }
        
        await self.db.content_schedules.insert_one(schedule)
        
        # 콘텐츠 상태 업데이트
        await self.db.contents.update_one(
            {'id': content_id},
            {'$set': {
                'status': 'scheduled',
                'scheduled_publish_at': publish_at
            }}
        )
        
        return {'status': 'success', 'scheduled_at': publish_at}
    
    async def process_scheduled_contents(self):
        '''예약된 콘텐츠 처리 (크론잡)'''
        
        now = datetime.now()
        
        # 발행 시간이 된 콘텐츠 조회
        scheduled = await self.db.content_schedules.find({
            'publish_at': {'$lte': now},
            'status': 'scheduled'
        }).to_list(None)
        
        for schedule in scheduled:
            try:
                # 콘텐츠 발행
                await self.db.contents.update_one(
                    {'id': schedule['content_id']},
                    {'$set': {
                        'status': 'published',
                        'published_at': now
                    }}
                )
                
                # 예약 상태 업데이트
                await self.db.content_schedules.update_one(
                    {'_id': schedule['_id']},
                    {'$set': {'status': 'published'}}
                )
                
                # 발행 후처리
                content = await self.db.contents.find_one({'id': schedule['content_id']})
                await self.post_publish_tasks(content)
                
            except Exception as e:
                self.logger.error(f"Failed to publish scheduled content: {e}")
""",
    priority=7
)

# ============================================================================
# CONTENT ANALYTICS - 콘텐츠 분석
# ============================================================================

CONTENT_ANALYTICS_PATTERN = BusinessPattern(
    id="content_analytics",
    name="콘텐츠 분석 패턴",
    name_en="Content Analytics Pattern",
    category=PatternCategory.ANALYTICS,
    description="콘텐츠 조회수, 참여도 등을 분석하는 패턴",
    trigger_keywords=[
        "분석", "analytics", "조회수", "views", "통계",
        "statistics", "인사이트", "metrics"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=False,
            description="콘텐츠 ID"
        ),
        PatternSlot(
            name="period",
            type="str",
            required=False,
            default="7d",
            description="분석 기간"
        )
    ],
    code_template="""
class ContentAnalytics:
    async def track_view(self, content_id: str, user_id: str = None):
        '''조회수 추적'''
        
        # 중복 조회 방지
        if user_id:
            recent_view = await self.db.content_views.find_one({
                'content_id': content_id,
                'user_id': user_id,
                'viewed_at': {'$gte': datetime.now() - timedelta(hours=1)}
            })
            
            if recent_view:
                return  # 1시간 내 재조회는 카운트하지 않음
        
        # 조회 기록
        await self.db.content_views.insert_one({
            'content_id': content_id,
            'user_id': user_id,
            'ip_address': self.get_client_ip(),
            'user_agent': self.get_user_agent(),
            'referrer': self.get_referrer(),
            'viewed_at': datetime.now()
        })
        
        # 조회수 증가
        await self.db.contents.update_one(
            {'id': content_id},
            {'$inc': {'view_count': 1}}
        )
    
    async def get_content_analytics(self, content_id: str, period: str = '7d'):
        '''콘텐츠 분석 데이터 조회'''
        
        # 기간 파싱
        days = int(period[:-1]) if period.endswith('d') else 7
        start_date = datetime.now() - timedelta(days=days)
        
        # 조회수 통계
        views = await self.db.content_views.aggregate([
            {
                '$match': {
                    'content_id': content_id,
                    'viewed_at': {'$gte': start_date}
                }
            },
            {
                '$group': {
                    '_id': {'$dateToString': {'format': '%Y-%m-%d', 'date': '$viewed_at'}},
                    'count': {'$sum': 1},
                    'unique_users': {'$addToSet': '$user_id'}
                }
            },
            {'$sort': {'_id': 1}}
        ]).to_list(None)
        
        # 참여도 메트릭
        engagement = await self.calculate_engagement_metrics(content_id, start_date)
        
        return {
            'status': 'success',
            'period': period,
            'views': views,
            'engagement': engagement,
            'total_views': sum(v['count'] for v in views),
            'unique_visitors': len(set(u for v in views for u in v['unique_users']))
        }
""",
    priority=6
)

# ============================================================================
# TRANSLATION MANAGEMENT - 번역 관리
# ============================================================================

TRANSLATION_MANAGEMENT_PATTERN = BusinessPattern(
    id="content_translation",
    name="콘텐츠 번역 관리 패턴",
    name_en="Translation Management Pattern",
    category=PatternCategory.AUTOMATION,
    description="다국어 콘텐츠를 관리하는 패턴",
    trigger_keywords=[
        "번역", "translation", "다국어", "multilingual",
        "언어", "language", "localization"
    ],
    slots=[
        PatternSlot(
            name="content_id",
            type="str",
            required=True,
            description="콘텐츠 ID"
        ),
        PatternSlot(
            name="target_language",
            type="str",
            required=True,
            description="대상 언어"
        )
    ],
    code_template="""
class TranslationManager:
    async def translate_content(self, content_id: str, target_language: str,
                               auto_translate: bool = False):
        '''콘텐츠 번역'''
        
        content = await self.db.contents.find_one({'id': content_id})
        
        if not content:
            return {'status': 'error', 'error': 'Content not found'}
        
        # 기존 번역 확인
        existing = await self.db.content_translations.find_one({
            'content_id': content_id,
            'language': target_language
        })
        
        if existing:
            return {'status': 'exists', 'translation': existing}
        
        translation = {
            'id': self.generate_id(),
            'content_id': content_id,
            'source_language': content.get('language', 'ko'),
            'target_language': target_language,
            'status': 'pending',
            'created_at': datetime.now()
        }
        
        if auto_translate:
            # 자동 번역 (Google Translate API 예제)
            from google.cloud import translate_v2 as translate
            
            translate_client = translate.Client()
            
            result = translate_client.translate(
                content['body'],
                target_language=target_language,
                source_language=content.get('language', 'ko')
            )
            
            translation['title'] = translate_client.translate(
                content['title'],
                target_language=target_language
            )['translatedText']
            
            translation['body'] = result['translatedText']
            translation['status'] = 'auto_translated'
            translation['auto_translated'] = True
        else:
            # 수동 번역 작업 생성
            translation['title'] = content['title']
            translation['body'] = content['body']
            translation['status'] = 'pending_translation'
        
        await self.db.content_translations.insert_one(translation)
        
        return {'status': 'success', 'translation': translation}
    
    async def get_available_languages(self, content_id: str):
        '''사용 가능한 언어 조회'''
        
        translations = await self.db.content_translations.find(
            {'content_id': content_id, 'status': {'$in': ['completed', 'auto_translated']}}
        ).to_list(None)
        
        languages = [t['target_language'] for t in translations]
        
        # 원본 언어 추가
        content = await self.db.contents.find_one({'id': content_id})
        languages.insert(0, content.get('language', 'ko'))
        
        return {'status': 'success', 'languages': languages}
""",
    priority=6
)

# ============================================================================
# CONTENT BACKUP - 콘텐츠 백업
# ============================================================================

CONTENT_BACKUP_PATTERN = BusinessPattern(
    id="content_backup",
    name="콘텐츠 백업 패턴",
    name_en="Content Backup Pattern",
    category=PatternCategory.AUTOMATION,
    description="콘텐츠를 백업하고 복원하는 패턴",
    trigger_keywords=[
        "백업", "backup", "복원", "restore", "복구",
        "recovery", "보관", "archive"
    ],
    slots=[
        PatternSlot(
            name="backup_type",
            type="str",
            required=False,
            default="full",
            description="백업 타입 (full/incremental)"
        )
    ],
    code_template="""
class ContentBackup:
    async def create_backup(self, backup_type: str = 'full'):
        '''콘텐츠 백업 생성'''
        
        backup = {
            'id': self.generate_id(),
            'type': backup_type,
            'status': 'in_progress',
            'started_at': datetime.now()
        }
        
        try:
            if backup_type == 'full':
                # 전체 백업
                contents = await self.db.contents.find().to_list(None)
                media = await self.db.media.find().to_list(None)
                
                backup_data = {
                    'contents': contents,
                    'media': media,
                    'total_contents': len(contents),
                    'total_media': len(media)
                }
                
            else:
                # 증분 백업 (최근 변경사항만)
                last_backup = await self.db.backups.find_one(
                    {'status': 'completed'},
                    sort=[('completed_at', -1)]
                )
                
                since = last_backup['completed_at'] if last_backup else datetime.min
                
                contents = await self.db.contents.find(
                    {'updated_at': {'$gte': since}}
                ).to_list(None)
                
                backup_data = {
                    'contents': contents,
                    'since': since,
                    'total_contents': len(contents)
                }
            
            # S3에 저장
            backup_key = f"backups/{backup['id']}.json"
            await self.s3_client.put_object(
                Bucket=self.backup_bucket,
                Key=backup_key,
                Body=json.dumps(backup_data, default=str)
            )
            
            backup['status'] = 'completed'
            backup['completed_at'] = datetime.now()
            backup['s3_key'] = backup_key
            backup['size'] = len(json.dumps(backup_data))
            
        except Exception as e:
            backup['status'] = 'failed'
            backup['error'] = str(e)
        
        await self.db.backups.insert_one(backup)
        
        return {'status': backup['status'], 'backup': backup}
    
    async def restore_backup(self, backup_id: str):
        '''백업 복원'''
        
        backup = await self.db.backups.find_one({'id': backup_id})
        
        if not backup or backup['status'] != 'completed':
            return {'status': 'error', 'error': 'Invalid backup'}
        
        # S3에서 백업 데이터 가져오기
        response = await self.s3_client.get_object(
            Bucket=self.backup_bucket,
            Key=backup['s3_key']
        )
        
        backup_data = json.loads(response['Body'].read())
        
        # 복원
        restored_count = 0
        for content in backup_data['contents']:
            await self.db.contents.replace_one(
                {'id': content['id']},
                content,
                upsert=True
            )
            restored_count += 1
        
        return {
            'status': 'success',
            'restored_count': restored_count
        }
""",
    priority=5
)

# 패턴 등록
register_pattern(CONTENT_CRUD_PATTERN)
register_pattern(VERSION_CONTROL_PATTERN)
register_pattern(MEDIA_MANAGEMENT_PATTERN)
register_pattern(PUBLISHING_WORKFLOW_PATTERN)
register_pattern(SEARCH_INDEXING_PATTERN)
register_pattern(COMMENT_SYSTEM_PATTERN)
register_pattern(TAGGING_SYSTEM_PATTERN)
register_pattern(CONTENT_SCHEDULING_PATTERN)
register_pattern(CONTENT_ANALYTICS_PATTERN)
register_pattern(TRANSLATION_MANAGEMENT_PATTERN)
register_pattern(CONTENT_BACKUP_PATTERN)