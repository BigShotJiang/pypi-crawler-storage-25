"""
Pricing Patterns - 가격/할인 관련 비즈니스 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# Pattern 1: 할인율 적용
DISCOUNT_RATE_APPLY = BusinessPattern(
    id="discount_rate_apply",
    name="할인율 적용",
    name_en="Discount Rate Apply",
    category=PatternCategory.PRICING,
    description="특정 조건에 따른 할인율 적용",
    trigger_keywords=["할인", "discount", "세일", "인하", "%", "퍼센트"],
    slots=[
        PatternSlot(
            name="discount_rate",
            type="float",
            required=True,
            extraction_regex=r"(\d+(?:\.\d+)?)[%퍼센트]?",
            description="할인율 (0-100)"
        ),
        PatternSlot(
            name="condition_field",
            type="str",
            required=False,
            default="category",
            examples={
                "카테고리": "category",
                "브랜드": "brand",
                "시즌": "season",
                "회원": "membership"
            },
            description="할인 조건 필드"
        ),
        PatternSlot(
            name="condition_value",
            type="str",
            required=False,
            default="all",
            description="할인 조건 값"
        )
    ],
    code_template='''
# 할인율 적용
discount_rate = {discount_rate} / 100.0
condition_field = '{condition_field}'
condition_value = '{condition_value}'

for item in items:
    # 조건 확인
    if condition_value == 'all' or item.get(condition_field) == condition_value:
        original_price = item.get('price', 0)
        discount_amount = original_price * discount_rate
        item['discounted_price'] = original_price - discount_amount
        item['discount_applied'] = True
        item['discount_rate'] = discount_rate * 100
        
        logger.info(f"Applied {{discount_rate*100}}% discount to item {{item.get('id', 'unknown')}}")
''',
    compatibility=["ecommerce", "pricing_engine", "shopping_cart"],
    priority=9,
    test_cases=[
        {
            "query": "전자제품 30% 할인",
            "expected_slots": {
                "discount_rate": 30,
                "condition_field": "category",
                "condition_value": "전자제품"
            }
        }
    ]
)

# Pattern 2: 구간별 가격 책정
TIERED_PRICING = BusinessPattern(
    id="tiered_pricing",
    name="구간별 가격 책정",
    name_en="Tiered Pricing",
    category=PatternCategory.PRICING,
    description="수량이나 조건에 따른 구간별 가격",
    trigger_keywords=["구간", "이상", "이하", "단위", "구매시", "bulk"],
    slots=[
        PatternSlot(
            name="pricing_tiers",
            type="list",
            required=True,
            default=[
                {"min": 1, "max": 10, "price": 1000},
                {"min": 11, "max": 50, "price": 900},
                {"min": 51, "max": 999999, "price": 800}
            ],
            description="구간별 가격 정보"
        ),
        PatternSlot(
            name="quantity_field",
            type="str",
            required=False,
            default="quantity",
            description="수량 필드명"
        )
    ],
    code_template='''
# 구간별 가격 적용
pricing_tiers = {pricing_tiers}
quantity_field = '{quantity_field}'

def get_tier_price(quantity):
    for tier in pricing_tiers:
        if tier['min'] <= quantity <= tier['max']:
            return tier['price']
    return pricing_tiers[-1]['price']  # 기본값

# 각 항목에 구간별 가격 적용
for item in items:
    quantity = item.get(quantity_field, 1)
    tier_price = get_tier_price(quantity)
    item['unit_price'] = tier_price
    item['total_price'] = tier_price * quantity
    
    logger.debug(f"Applied tiered pricing: quantity={{quantity}}, price={{tier_price}}")
''',
    compatibility=["ecommerce", "b2b_sales", "wholesale"],
    priority=8
)

# Pattern 3: 쿠폰 적용
COUPON_APPLY = BusinessPattern(
    id="coupon_apply",
    name="쿠폰 적용",
    name_en="Coupon Apply",
    category=PatternCategory.PRICING,
    description="쿠폰 코드에 따른 할인 적용",
    trigger_keywords=["쿠폰", "코드", "프로모션", "voucher", "promotion"],
    slots=[
        PatternSlot(
            name="coupon_type",
            type="str",
            required=True,
            examples={
                "금액": "amount",
                "퍼센트": "percentage",
                "무료배송": "free_shipping"
            },
            description="쿠폰 타입"
        ),
        PatternSlot(
            name="coupon_value",
            type="float",
            required=True,
            extraction_regex=r"(\d+(?:\.\d+)?)",
            description="쿠폰 값"
        ),
        PatternSlot(
            name="min_purchase",
            type="float",
            required=False,
            default=0,
            description="최소 구매 금액"
        )
    ],
    code_template='''
# 쿠폰 적용
coupon_type = '{coupon_type}'
coupon_value = {coupon_value}
min_purchase = {min_purchase}

total_amount = sum(item.get('price', 0) * item.get('quantity', 1) for item in items)

if total_amount >= min_purchase:
    if coupon_type == 'percentage':
        discount = total_amount * (coupon_value / 100)
    elif coupon_type == 'amount':
        discount = min(coupon_value, total_amount)
    else:  # free_shipping
        discount = shipping_cost if 'shipping_cost' in locals() else 0
    
    final_amount = total_amount - discount
    
    result = {{
        'original_amount': total_amount,
        'discount': discount,
        'final_amount': final_amount,
        'coupon_applied': True
    }}
    
    logger.info(f"Coupon applied: type={{coupon_type}}, discount={{discount}}")
else:
    result = {{
        'original_amount': total_amount,
        'discount': 0,
        'final_amount': total_amount,
        'coupon_applied': False,
        'message': f'Minimum purchase amount not met: {{min_purchase}}'
    }}
''',
    compatibility=["ecommerce", "shopping_cart", "checkout"],
    priority=7
)

# Pattern 4: 동적 가격 조정
DYNAMIC_PRICING = BusinessPattern(
    id="dynamic_pricing",
    name="동적 가격 조정",
    name_en="Dynamic Pricing",
    category=PatternCategory.PRICING,
    description="수요, 시간, 재고에 따른 동적 가격 조정",
    trigger_keywords=["동적", "실시간", "변동", "surge", "dynamic"],
    slots=[
        PatternSlot(
            name="pricing_factor",
            type="str",
            required=True,
            examples={
                "수요": "demand",
                "시간": "time",
                "재고": "inventory",
                "경쟁": "competition"
            },
            description="가격 결정 요인"
        ),
        PatternSlot(
            name="adjustment_range",
            type="dict",
            required=False,
            default={"min": 0.8, "max": 1.5},
            description="가격 조정 범위 (배수)"
        )
    ],
    code_template='''
# 동적 가격 조정
from datetime import datetime

pricing_factor = '{pricing_factor}'
adjustment_range = {adjustment_range}

def calculate_price_multiplier(factor_value):
    # 정규화 (0-1 범위로)
    normalized = min(max(factor_value, 0), 1)
    
    # 조정 범위 내에서 계산
    min_mult = adjustment_range['min']
    max_mult = adjustment_range['max']
    
    return min_mult + (max_mult - min_mult) * normalized

# 각 항목에 동적 가격 적용
for item in items:
    base_price = item.get('base_price', item.get('price', 0))
    
    # 요인별 계산
    if pricing_factor == 'demand':
        factor_value = item.get('demand_score', 0.5)
    elif pricing_factor == 'inventory':
        # 재고가 적을수록 가격 상승
        stock = item.get('stock', 100)
        factor_value = 1 - (stock / 100)
    elif pricing_factor == 'time':
        # 피크 시간대 확인
        hour = datetime.now().hour
        factor_value = 1.0 if 18 <= hour <= 21 else 0.5
    else:
        factor_value = 0.5
    
    multiplier = calculate_price_multiplier(factor_value)
    item['dynamic_price'] = base_price * multiplier
    item['price_multiplier'] = multiplier
    
    logger.debug(f"Dynamic pricing: factor={{pricing_factor}}, multiplier={{multiplier}}")
''',
    compatibility=["ecommerce", "ride_sharing", "hotel_booking"],
    priority=6
)

# 패턴 등록
register_pattern(DISCOUNT_RATE_APPLY)
register_pattern(TIERED_PRICING)
register_pattern(COUPON_APPLY)
register_pattern(DYNAMIC_PRICING)