"""
Workflow Patterns - 워크플로우 관련 비즈니스 패턴
순차, 병렬, 조건부, 승인 등 프로세스 흐름 제어 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# SEQUENTIAL WORKFLOW - 순차 처리 워크플로우
# ============================================================================

SEQUENTIAL_WORKFLOW = BusinessPattern(
    id="workflow_sequential",
    name="순차 처리 워크플로우",
    name_en="Sequential Workflow",
    category=PatternCategory.AUTOMATION,
    description="여러 작업을 순서대로 처리하는 워크플로우 패턴",
    trigger_keywords=[
        "순차", "순서대로", "차례대로", "단계별", "step by step",
        "sequential", "one by one", "in order", "다음", "그다음"
    ],
    slots=[
        PatternSlot(
            name="steps",
            type="list",
            required=True,
            description="실행할 단계들",
            examples={"검증": "validate", "처리": "process", "저장": "save"}
        ),
        PatternSlot(
            name="stop_on_error",
            type="bool",
            required=False,
            default=True,
            description="오류 시 중단 여부"
        )
    ],
    code_template="""
async def execute_sequential_workflow(self, steps: List[Dict], stop_on_error: bool = True):
    '''순차적으로 작업 실행'''
    results = []
    
    for i, step in enumerate(steps, 1):
        try:
            self.logger.info(f"Step {i}/{len(steps)}: {step['name']}")
            
            # 단계 실행
            if step['type'] == 'function':
                result = await step['function'](*step.get('args', []))
            elif step['type'] == 'api_call':
                result = await self.call_api(step['endpoint'], step.get('data'))
            elif step['type'] == 'validation':
                result = await self.validate(step['data'], step['rules'])
            else:
                result = await self.execute_step(step)
            
            results.append({
                'step': step['name'],
                'status': 'success',
                'result': result
            })
            
        except Exception as e:
            self.logger.error(f"Step {i} failed: {e}")
            results.append({
                'step': step['name'],
                'status': 'error',
                'error': str(e)
            })
            
            if stop_on_error:
                break
    
    return {
        'completed': len([r for r in results if r['status'] == 'success']),
        'total': len(steps),
        'results': results
    }
""",
    priority=10,
    test_cases=[
        {
            "input": {"steps": [{"name": "validate"}, {"name": "process"}]},
            "expected": "sequential execution"
        }
    ]
)

# ============================================================================
# PARALLEL WORKFLOW - 병렬 처리 워크플로우
# ============================================================================

PARALLEL_WORKFLOW = BusinessPattern(
    id="workflow_parallel",
    name="병렬 처리 워크플로우",
    name_en="Parallel Workflow",
    category=PatternCategory.AUTOMATION,
    description="여러 작업을 동시에 병렬로 처리하는 워크플로우 패턴",
    trigger_keywords=[
        "동시에", "병렬", "parallel", "concurrent", "simultaneously",
        "한번에", "같이", "동시 처리", "비동기", "async"
    ],
    slots=[
        PatternSlot(
            name="tasks",
            type="list",
            required=True,
            description="병렬로 실행할 작업들"
        ),
        PatternSlot(
            name="max_workers",
            type="int",
            required=False,
            default=5,
            description="최대 동시 실행 수"
        )
    ],
    code_template="""
async def execute_parallel_workflow(self, tasks: List[Dict], max_workers: int = 5):
    '''병렬로 작업 실행'''
    import asyncio
    from asyncio import Semaphore
    
    semaphore = Semaphore(max_workers)
    
    async def run_task(task):
        async with semaphore:
            try:
                self.logger.info(f"Starting task: {task['name']}")
                
                if task['type'] == 'api_call':
                    result = await self.call_api(task['endpoint'], task.get('data'))
                elif task['type'] == 'processing':
                    result = await self.process_data(task['data'])
                else:
                    result = await self.execute_task(task)
                
                return {
                    'task': task['name'],
                    'status': 'success',
                    'result': result
                }
            except Exception as e:
                self.logger.error(f"Task {task['name']} failed: {e}")
                return {
                    'task': task['name'],
                    'status': 'error',
                    'error': str(e)
                }
    
    # 모든 작업 병렬 실행
    results = await asyncio.gather(*[run_task(task) for task in tasks])
    
    return {
        'total': len(tasks),
        'successful': len([r for r in results if r['status'] == 'success']),
        'failed': len([r for r in results if r['status'] == 'error']),
        'results': results
    }
""",
    priority=10
)

# ============================================================================
# CONDITIONAL WORKFLOW - 조건부 분기 워크플로우
# ============================================================================

CONDITIONAL_WORKFLOW = BusinessPattern(
    id="workflow_conditional",
    name="조건부 분기 워크플로우",
    name_en="Conditional Workflow",
    category=PatternCategory.AUTOMATION,
    description="조건에 따라 다른 경로로 분기하는 워크플로우",
    trigger_keywords=[
        "조건", "분기", "if", "else", "경우", "때", "따라",
        "conditional", "branch", "switch", "case", "조건부"
    ],
    slots=[
        PatternSlot(
            name="conditions",
            type="list",
            required=True,
            description="조건과 실행 경로"
        )
    ],
    code_template="""
async def execute_conditional_workflow(self, data: Dict, conditions: List[Dict]):
    '''조건에 따라 분기 처리'''
    
    for condition in conditions:
        # 조건 평가
        if await self.evaluate_condition(condition['rule'], data):
            self.logger.info(f"Condition met: {condition['name']}")
            
            # 해당 경로 실행
            if condition['action'] == 'execute':
                result = await self.execute_action(condition['workflow'])
            elif condition['action'] == 'notify':
                result = await self.send_notification(condition['message'])
            elif condition['action'] == 'transform':
                result = await self.transform_data(data, condition['transformation'])
            else:
                result = await self.handle_action(condition)
            
            return {
                'matched_condition': condition['name'],
                'action_taken': condition['action'],
                'result': result
            }
    
    # 기본 경로
    return {
        'matched_condition': 'default',
        'action_taken': 'default',
        'result': await self.execute_default_action(data)
    }
""",
    priority=9
)

# ============================================================================
# APPROVAL WORKFLOW - 승인 프로세스 워크플로우
# ============================================================================

APPROVAL_WORKFLOW = BusinessPattern(
    id="workflow_approval",
    name="승인 프로세스",
    name_en="Approval Workflow",
    category=PatternCategory.AUTOMATION,
    description="승인 단계가 포함된 워크플로우",
    trigger_keywords=[
        "승인", "결재", "approval", "approve", "확인", "허가",
        "sign off", "authorize", "confirm", "검토"
    ],
    slots=[
        PatternSlot(
            name="approval_levels",
            type="list",
            required=True,
            description="승인 레벨"
        ),
        PatternSlot(
            name="timeout",
            type="int",
            required=False,
            default=86400,
            description="승인 타임아웃(초)"
        )
    ],
    code_template="""
async def execute_approval_workflow(self, request: Dict, approval_levels: List[Dict]):
    '''승인 프로세스 실행'''
    
    approval_chain = []
    current_status = 'pending'
    
    for level in approval_levels:
        self.logger.info(f"Requesting approval from: {level['approver']}")
        
        # 승인 요청 생성
        approval_request = {
            'id': self.generate_id(),
            'level': level['level'],
            'approver': level['approver'],
            'request_data': request,
            'created_at': self.get_timestamp()
        }
        
        # 알림 발송
        await self.notify_approver(approval_request)
        
        # 승인 대기
        approval_result = await self.wait_for_approval(
            approval_request['id'],
            timeout=level.get('timeout', 86400)
        )
        
        approval_chain.append({
            'level': level['level'],
            'approver': level['approver'],
            'status': approval_result['status'],
            'timestamp': approval_result['timestamp'],
            'comments': approval_result.get('comments')
        })
        
        if approval_result['status'] == 'rejected':
            current_status = 'rejected'
            break
        elif approval_result['status'] == 'approved':
            current_status = 'approved'
        else:
            current_status = 'timeout'
            break
    
    return {
        'status': current_status,
        'approval_chain': approval_chain,
        'final_approver': approval_chain[-1]['approver'] if approval_chain else None
    }
""",
    priority=9
)

# ============================================================================
# RETRY WORKFLOW - 재시도 로직
# ============================================================================

RETRY_WORKFLOW = BusinessPattern(
    id="workflow_retry",
    name="재시도 워크플로우",
    name_en="Retry Workflow",
    category=PatternCategory.AUTOMATION,
    description="실패 시 재시도하는 워크플로우",
    trigger_keywords=[
        "재시도", "retry", "다시", "실패시", "재실행",
        "try again", "reattempt", "failover"
    ],
    slots=[
        PatternSlot(
            name="max_retries",
            type="int",
            required=False,
            default=3,
            description="최대 재시도 횟수"
        ),
        PatternSlot(
            name="backoff_strategy",
            type="str",
            required=False,
            default="exponential",
            description="재시도 간격 전략"
        )
    ],
    code_template="""
async def execute_with_retry(self, operation: callable, max_retries: int = 3, backoff: str = 'exponential'):
    '''재시도 로직으로 작업 실행'''
    import asyncio
    
    attempt = 0
    last_error = None
    
    while attempt < max_retries:
        try:
            self.logger.info(f"Attempt {attempt + 1}/{max_retries}")
            result = await operation()
            
            return {
                'success': True,
                'attempts': attempt + 1,
                'result': result
            }
            
        except Exception as e:
            last_error = e
            attempt += 1
            
            if attempt < max_retries:
                # 백오프 전략에 따른 대기
                if backoff == 'exponential':
                    wait_time = 2 ** attempt
                elif backoff == 'linear':
                    wait_time = attempt * 2
                else:
                    wait_time = 1
                
                self.logger.warning(f"Failed, retrying in {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
    
    return {
        'success': False,
        'attempts': attempt,
        'error': str(last_error)
    }
""",
    priority=8
)

# ============================================================================
# STATE MACHINE WORKFLOW - 상태 머신
# ============================================================================

STATE_MACHINE_WORKFLOW = BusinessPattern(
    id="workflow_state_machine",
    name="상태 머신 워크플로우",
    name_en="State Machine Workflow",
    category=PatternCategory.AUTOMATION,
    description="상태 전이를 관리하는 워크플로우",
    trigger_keywords=[
        "상태", "state", "전이", "transition", "상태머신",
        "state machine", "fsm", "workflow engine"
    ],
    slots=[
        PatternSlot(
            name="states",
            type="dict",
            required=True,
            description="상태 정의"
        ),
        PatternSlot(
            name="transitions",
            type="list",
            required=True,
            description="상태 전이 규칙"
        )
    ],
    code_template="""
class StateMachine:
    def __init__(self, states: Dict, transitions: List):
        self.states = states
        self.transitions = transitions
        self.current_state = 'initial'
        self.history = []
    
    async def transition(self, event: str, data: Dict = None):
        '''상태 전이 처리'''
        # 현재 상태에서 가능한 전이 찾기
        valid_transitions = [
            t for t in self.transitions
            if t['from'] == self.current_state and t['event'] == event
        ]
        
        if not valid_transitions:
            raise ValueError(f"Invalid transition: {self.current_state} -> {event}")
        
        transition = valid_transitions[0]
        
        # 전이 조건 확인
        if 'condition' in transition:
            if not await self.evaluate_condition(transition['condition'], data):
                return {
                    'success': False,
                    'reason': 'Condition not met'
                }
        
        # 상태 전이
        old_state = self.current_state
        self.current_state = transition['to']
        
        # 히스토리 기록
        self.history.append({
            'from': old_state,
            'to': self.current_state,
            'event': event,
            'timestamp': self.get_timestamp()
        })
        
        # 새 상태의 액션 실행
        if self.current_state in self.states:
            state_def = self.states[self.current_state]
            if 'on_enter' in state_def:
                await state_def['on_enter'](data)
        
        return {
            'success': True,
            'current_state': self.current_state,
            'transition': f"{old_state} -> {self.current_state}"
        }
""",
    priority=8
)

# ============================================================================
# SCHEDULED WORKFLOW - 스케줄 실행
# ============================================================================

SCHEDULED_WORKFLOW = BusinessPattern(
    id="workflow_scheduled",
    name="스케줄 실행 워크플로우",
    name_en="Scheduled Workflow",
    category=PatternCategory.AUTOMATION,
    description="정해진 시간에 실행되는 워크플로우",
    trigger_keywords=[
        "스케줄", "예약", "주기적", "정기", "매일", "매주",
        "schedule", "cron", "periodic", "daily", "weekly"
    ],
    slots=[
        PatternSlot(
            name="schedule",
            type="str",
            required=True,
            description="스케줄 표현식 (cron)",
            examples={"매일": "0 0 * * *", "매시간": "0 * * * *"}
        )
    ],
    code_template="""
async def setup_scheduled_workflow(self, schedule: str, task: callable):
    '''스케줄 기반 워크플로우 설정'''
    import asyncio
    from croniter import croniter
    from datetime import datetime
    
    cron = croniter(schedule, datetime.now())
    
    async def run_scheduled():
        while True:
            # 다음 실행 시간 계산
            next_run = cron.get_next(datetime)
            wait_seconds = (next_run - datetime.now()).total_seconds()
            
            if wait_seconds > 0:
                self.logger.info(f"Next run scheduled at: {next_run}")
                await asyncio.sleep(wait_seconds)
            
            # 작업 실행
            try:
                self.logger.info(f"Executing scheduled task")
                result = await task()
                
                await self.record_execution({
                    'timestamp': datetime.now(),
                    'status': 'success',
                    'result': result
                })
                
            except Exception as e:
                self.logger.error(f"Scheduled task failed: {e}")
                await self.record_execution({
                    'timestamp': datetime.now(),
                    'status': 'error',
                    'error': str(e)
                })
    
    # 백그라운드 태스크로 실행
    asyncio.create_task(run_scheduled())
    
    return {
        'status': 'scheduled',
        'schedule': schedule,
        'next_run': cron.get_next(datetime)
    }
""",
    priority=7
)

# ============================================================================
# EVENT DRIVEN WORKFLOW - 이벤트 기반
# ============================================================================

EVENT_DRIVEN_WORKFLOW = BusinessPattern(
    id="workflow_event_driven",
    name="이벤트 기반 워크플로우",
    name_en="Event Driven Workflow",
    category=PatternCategory.AUTOMATION,
    description="이벤트에 반응하여 실행되는 워크플로우",
    trigger_keywords=[
        "이벤트", "event", "트리거", "trigger", "발생시",
        "when", "on", "리스너", "listener", "구독"
    ],
    slots=[
        PatternSlot(
            name="events",
            type="list",
            required=True,
            description="구독할 이벤트 목록"
        )
    ],
    code_template="""
class EventDrivenWorkflow:
    def __init__(self):
        self.event_handlers = {}
        self.event_queue = asyncio.Queue()
    
    def register_handler(self, event_type: str, handler: callable):
        '''이벤트 핸들러 등록'''
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)
    
    async def emit_event(self, event_type: str, data: Dict):
        '''이벤트 발생'''
        await self.event_queue.put({
            'type': event_type,
            'data': data,
            'timestamp': self.get_timestamp()
        })
    
    async def process_events(self):
        '''이벤트 처리 루프'''
        while True:
            event = await self.event_queue.get()
            
            if event['type'] in self.event_handlers:
                for handler in self.event_handlers[event['type']]:
                    try:
                        await handler(event['data'])
                    except Exception as e:
                        self.logger.error(f"Handler failed: {e}")
""",
    priority=7
)

# ============================================================================
# BATCH WORKFLOW - 배치 처리
# ============================================================================

BATCH_PROCESSING_WORKFLOW = BusinessPattern(
    id="workflow_batch",
    name="배치 처리 워크플로우",
    name_en="Batch Processing Workflow",
    category=PatternCategory.AUTOMATION,
    description="대량 데이터를 배치로 처리하는 워크플로우",
    trigger_keywords=[
        "배치", "batch", "대량", "일괄", "묶음",
        "bulk", "mass", "chunk", "대용량"
    ],
    slots=[
        PatternSlot(
            name="batch_size",
            type="int",
            required=False,
            default=100,
            description="배치 크기"
        )
    ],
    code_template="""
async def process_batch(self, items: List, batch_size: int = 100):
    '''배치 단위로 처리'''
    
    total_items = len(items)
    processed = 0
    results = []
    
    for i in range(0, total_items, batch_size):
        batch = items[i:i + batch_size]
        batch_num = (i // batch_size) + 1
        
        self.logger.info(f"Processing batch {batch_num}: {len(batch)} items")
        
        try:
            # 배치 처리
            batch_results = await self.process_items(batch)
            results.extend(batch_results)
            processed += len(batch)
            
            # 진행상황 업데이트
            progress = (processed / total_items) * 100
            await self.update_progress(progress)
            
        except Exception as e:
            self.logger.error(f"Batch {batch_num} failed: {e}")
            # 실패한 배치 기록
            await self.record_failed_batch(batch_num, batch, str(e))
    
    return {
        'total': total_items,
        'processed': processed,
        'batches': (total_items + batch_size - 1) // batch_size,
        'results': results
    }
""",
    priority=7
)

# ============================================================================
# ROLLBACK WORKFLOW - 롤백 처리
# ============================================================================

ROLLBACK_WORKFLOW = BusinessPattern(
    id="workflow_rollback",
    name="롤백 워크플로우",
    name_en="Rollback Workflow",
    category=PatternCategory.AUTOMATION,
    description="실패 시 이전 상태로 롤백하는 워크플로우",
    trigger_keywords=[
        "롤백", "rollback", "되돌리기", "복구", "undo",
        "revert", "restore", "취소"
    ],
    slots=[
        PatternSlot(
            name="checkpoint_enabled",
            type="bool",
            required=False,
            default=True,
            description="체크포인트 저장 여부"
        )
    ],
    code_template="""
class RollbackWorkflow:
    def __init__(self):
        self.checkpoints = []
        self.current_state = None
    
    async def save_checkpoint(self, state: Dict, name: str = None):
        '''체크포인트 저장'''
        checkpoint = {
            'id': self.generate_id(),
            'name': name or f"checkpoint_{len(self.checkpoints)}",
            'state': state.copy(),
            'timestamp': self.get_timestamp()
        }
        self.checkpoints.append(checkpoint)
        return checkpoint['id']
    
    async def execute_with_rollback(self, operations: List):
        '''롤백 가능한 실행'''
        completed_ops = []
        
        try:
            for op in operations:
                # 실행 전 상태 저장
                await self.save_checkpoint(
                    self.current_state,
                    f"before_{op['name']}"
                )
                
                # 작업 실행
                result = await op['execute']()
                completed_ops.append(op)
                
                # 상태 업데이트
                self.current_state = result
                
        except Exception as e:
            self.logger.error(f"Operation failed, rolling back: {e}")
            
            # 롤백 실행
            for op in reversed(completed_ops):
                if 'rollback' in op:
                    await op['rollback']()
            
            # 마지막 체크포인트로 복원
            if self.checkpoints:
                last_checkpoint = self.checkpoints[-1]
                self.current_state = last_checkpoint['state']
            
            raise e
    
    async def rollback_to_checkpoint(self, checkpoint_id: str):
        '''특정 체크포인트로 롤백'''
        checkpoint = next(
            (cp for cp in self.checkpoints if cp['id'] == checkpoint_id),
            None
        )
        
        if checkpoint:
            self.current_state = checkpoint['state']
            return True
        return False
""",
    priority=6
)

# 패턴 등록
register_pattern(SEQUENTIAL_WORKFLOW)
register_pattern(PARALLEL_WORKFLOW)
register_pattern(CONDITIONAL_WORKFLOW)
register_pattern(APPROVAL_WORKFLOW)
register_pattern(RETRY_WORKFLOW)
register_pattern(STATE_MACHINE_WORKFLOW)
register_pattern(SCHEDULED_WORKFLOW)
register_pattern(EVENT_DRIVEN_WORKFLOW)
register_pattern(BATCH_PROCESSING_WORKFLOW)
register_pattern(ROLLBACK_WORKFLOW)