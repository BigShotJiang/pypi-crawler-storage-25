"""
Monitoring Patterns - 모니터링/알림 관련 비즈니스 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# Pattern 1: 임계값 초과 알림
THRESHOLD_ALERT = BusinessPattern(
    id="threshold_alert",
    name="임계값 초과 알림",
    name_en="Threshold Alert",
    category=PatternCategory.MONITORING,
    description="특정 값이 임계값을 초과하면 알림 발송",
    trigger_keywords=["초과", "이상", "이하", "알림", "경고", "threshold", "넘으면", "도달"],
    slots=[
        PatternSlot(
            name="monitor_field",
            type="str",
            required=True,
            examples={
                "재고": "stock",
                "온도": "temperature",
                "사용량": "usage",
                "금액": "amount",
                "개수": "count",
                "비율": "ratio"
            },
            description="모니터링할 필드"
        ),
        PatternSlot(
            name="threshold_value",
            type="float",
            required=True,
            extraction_regex=r"(\d+(?:\.\d+)?)",
            description="임계값"
        ),
        PatternSlot(
            name="comparison",
            type="str",
            required=True,
            examples={
                "초과": ">",
                "이상": ">=",
                "이하": "<=",
                "미만": "<",
                "같으면": "=="
            },
            description="비교 연산자"
        ),
        PatternSlot(
            name="alert_action",
            type="str",
            required=False,
            default="send_notification",
            description="알림 액션 메서드명"
        )
    ],
    code_template='''
# 임계값 모니터링
current_value = data.get('{monitor_field}', 0)
threshold = {threshold_value}

if current_value {comparison} threshold:
    # 알림 발송
    alert_data = {{
        'type': 'THRESHOLD_ALERT',
        'field': '{monitor_field}',
        'current': current_value,
        'threshold': threshold,
        'condition': '{comparison}',
        'timestamp': datetime.now().isoformat()
    }}
    
    if hasattr(self, '{alert_action}'):
        await self.{alert_action}(alert_data)
    
    # 로그 기록
    logger.warning(f"Threshold exceeded: {monitor_field}={{current_value}} {comparison} {{threshold}}")
''',
    compatibility=["monitoring", "sensor", "analytics", "all"],
    priority=9,
    test_cases=[
        {
            "query": "재고가 10개 이하면 알림",
            "expected_slots": {
                "monitor_field": "stock",
                "threshold_value": 10,
                "comparison": "<="
            }
        }
    ]
)

# Pattern 2: 연속 이벤트 알림
CONSECUTIVE_EVENT_ALERT = BusinessPattern(
    id="consecutive_event_alert",
    name="연속 이벤트 알림",
    name_en="Consecutive Event Alert",
    category=PatternCategory.MONITORING,
    description="특정 이벤트가 연속으로 발생하면 알림",
    trigger_keywords=["연속", "번 연속", "consecutive", "연달아", "계속", "반복"],
    slots=[
        PatternSlot(
            name="event_type",
            type="str",
            required=True,
            examples={
                "부정": "negative",
                "부정적": "negative",
                "실패": "failure",
                "에러": "error",
                "경고": "warning",
                "긍정": "positive"
            },
            description="이벤트 타입"
        ),
        PatternSlot(
            name="consecutive_count",
            type="int",
            required=True,
            extraction_regex=r"(\d+)번?",
            description="연속 발생 횟수"
        ),
        PatternSlot(
            name="alert_message",
            type="str",
            required=False,
            default="Consecutive event detected",
            description="알림 메시지"
        )
    ],
    code_template='''
# 연속 이벤트 모니터링
if not hasattr(self, 'event_counter'):
    self.event_counter = {{}}

event_type = '{event_type}'
current_event = data.get('event_type', data.get('type', ''))

if current_event == event_type:
    self.event_counter[event_type] = self.event_counter.get(event_type, 0) + 1
    
    if self.event_counter[event_type] >= {consecutive_count}:
        # 알림 발송
        alert_data = {{
            'type': 'CONSECUTIVE_EVENT',
            'event': event_type,
            'count': self.event_counter[event_type],
            'message': '{alert_message}'
        }}
        
        if hasattr(self, 'send_alert'):
            await self.send_alert(alert_data)
        
        logger.warning(f"Consecutive event alert: {{event_type}} occurred {{self.event_counter[event_type]}} times")
        
        # 카운터 리셋
        self.event_counter[event_type] = 0
else:
    # 다른 이벤트면 카운터 리셋
    self.event_counter[event_type] = 0
''',
    compatibility=["monitoring", "analytics", "sentiment_analyzer", "all"],
    priority=8,
    test_cases=[
        {
            "query": "부정적인 리뷰 3개 연속이면 알림",
            "expected_slots": {
                "event_type": "negative",
                "consecutive_count": 3
            }
        }
    ]
)

# Pattern 3: 패턴 감지 알림
PATTERN_DETECTION_ALERT = BusinessPattern(
    id="pattern_detection_alert",
    name="패턴 감지 알림",
    name_en="Pattern Detection Alert",
    category=PatternCategory.MONITORING,
    description="특정 패턴이 감지되면 알림",
    trigger_keywords=["패턴", "감지", "발견", "찾으면", "나타나면"],
    slots=[
        PatternSlot(
            name="pattern_type",
            type="str",
            required=True,
            examples={
                "증가": "increasing",
                "감소": "decreasing",
                "급증": "spike",
                "급락": "drop",
                "이상": "anomaly"
            },
            description="감지할 패턴 유형"
        ),
        PatternSlot(
            name="sensitivity",
            type="float",
            required=False,
            default=0.2,
            extraction_regex=r"(\d+(?:\.\d+)?)",
            description="민감도 (0-1)"
        )
    ],
    code_template='''
# 패턴 감지
if not hasattr(self, 'pattern_history'):
    self.pattern_history = []

# 현재 값을 히스토리에 추가
current_value = data.get('value', 0)
self.pattern_history.append(current_value)

# 최근 10개 값만 유지
if len(self.pattern_history) > 10:
    self.pattern_history.pop(0)

# 패턴 분석
if len(self.pattern_history) >= 3:
    pattern_type = '{pattern_type}'
    sensitivity = {sensitivity}
    
    detected = False
    if pattern_type == 'increasing':
        # 연속 증가 감지
        if all(self.pattern_history[i] < self.pattern_history[i+1] for i in range(len(self.pattern_history)-1)):
            detected = True
    elif pattern_type == 'decreasing':
        # 연속 감소 감지
        if all(self.pattern_history[i] > self.pattern_history[i+1] for i in range(len(self.pattern_history)-1)):
            detected = True
    elif pattern_type == 'spike':
        # 급증 감지
        if len(self.pattern_history) >= 2:
            change_rate = (self.pattern_history[-1] - self.pattern_history[-2]) / (self.pattern_history[-2] + 0.001)
            if change_rate > sensitivity:
                detected = True
    
    if detected:
        alert_data = {{
            'type': 'PATTERN_DETECTED',
            'pattern': pattern_type,
            'values': self.pattern_history[-5:],
            'timestamp': datetime.now().isoformat()
        }}
        
        if hasattr(self, 'send_alert'):
            await self.send_alert(alert_data)
        
        logger.info(f"Pattern detected: {{pattern_type}}")
''',
    compatibility=["monitoring", "analytics", "sensor"],
    priority=7
)

# Pattern 4: 주기적 모니터링
PERIODIC_MONITORING = BusinessPattern(
    id="periodic_monitoring",
    name="주기적 모니터링",
    name_en="Periodic Monitoring",
    category=PatternCategory.MONITORING,
    description="일정 주기로 상태를 체크하고 보고",
    trigger_keywords=["매일", "매시간", "주기적", "정기적", "마다"],
    slots=[
        PatternSlot(
            name="interval",
            type="str",
            required=True,
            examples={
                "매일": "daily",
                "매시간": "hourly",
                "매분": "minutely",
                "매주": "weekly"
            },
            description="모니터링 주기"
        ),
        PatternSlot(
            name="check_items",
            type="list",
            required=False,
            default=["status", "performance", "errors"],
            description="체크할 항목들"
        )
    ],
    code_template='''
# 주기적 모니터링
from datetime import datetime, timedelta

if not hasattr(self, 'last_check_time'):
    self.last_check_time = datetime.now()

interval = '{interval}'
current_time = datetime.now()

# 인터벌 계산
interval_delta = {{
    'minutely': timedelta(minutes=1),
    'hourly': timedelta(hours=1),
    'daily': timedelta(days=1),
    'weekly': timedelta(weeks=1)
}}.get(interval, timedelta(hours=1))

# 체크 시간이 되었는지 확인
if current_time - self.last_check_time >= interval_delta:
    # 모니터링 수행
    check_results = {{}}
    check_items = {check_items}
    
    for item in check_items:
        if item in data:
            check_results[item] = data[item]
    
    # 리포트 생성
    report = {{
        'type': 'PERIODIC_MONITORING',
        'interval': interval,
        'timestamp': current_time.isoformat(),
        'results': check_results
    }}
    
    if hasattr(self, 'send_report'):
        await self.send_report(report)
    
    logger.info(f"Periodic monitoring completed: {{interval}}")
    
    # 마지막 체크 시간 업데이트
    self.last_check_time = current_time
''',
    compatibility=["monitoring", "all"],
    priority=6
)

# 패턴 등록
register_pattern(THRESHOLD_ALERT)
register_pattern(CONSECUTIVE_EVENT_ALERT)
register_pattern(PATTERN_DETECTION_ALERT)
register_pattern(PERIODIC_MONITORING)