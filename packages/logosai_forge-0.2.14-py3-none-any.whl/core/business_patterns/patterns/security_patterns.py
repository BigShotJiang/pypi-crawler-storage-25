"""
Security Patterns - 보안 관련 비즈니스 패턴
인증, 권한, 암호화, 감사 등 보안 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# AUTHENTICATION PATTERN - 인증 처리
# ============================================================================

AUTHENTICATION_PATTERN = BusinessPattern(
    id="security_authentication",
    name="인증 패턴",
    name_en="Authentication Pattern",
    category=PatternCategory.SECURITY,
    description="사용자 인증을 처리하는 보안 패턴",
    trigger_keywords=[
        "인증", "authentication", "로그인", "login", "signin",
        "auth", "credential", "비밀번호", "password"
    ],
    slots=[
        PatternSlot(
            name="auth_method",
            type="str",
            required=False,
            default="jwt",
            description="인증 방식 (jwt/oauth/basic)"
        ),
        PatternSlot(
            name="multi_factor",
            type="bool",
            required=False,
            default=False,
            description="2단계 인증 여부"
        )
    ],
    code_template="""
class AuthenticationHandler:
    def __init__(self, auth_method: str = 'jwt'):
        self.auth_method = auth_method
        self.secret_key = self._get_secret_key()
    
    async def authenticate(self, username: str, password: str, mfa_code: str = None):
        '''사용자 인증'''
        import hashlib
        import jwt
        from datetime import datetime, timedelta
        
        # 1. 사용자 확인
        user = await self.get_user(username)
        if not user:
            return {
                'success': False,
                'error': 'User not found'
            }
        
        # 2. 비밀번호 검증
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        if user['password_hash'] != password_hash:
            await self.log_failed_attempt(username)
            return {
                'success': False,
                'error': 'Invalid password'
            }
        
        # 3. MFA 검증 (활성화된 경우)
        if user.get('mfa_enabled') and mfa_code:
            if not await self.verify_mfa(user['mfa_secret'], mfa_code):
                return {
                    'success': False,
                    'error': 'Invalid MFA code'
                }
        
        # 4. 토큰 생성
        if self.auth_method == 'jwt':
            token = jwt.encode({
                'user_id': user['id'],
                'username': username,
                'exp': datetime.utcnow() + timedelta(hours=24),
                'iat': datetime.utcnow()
            }, self.secret_key, algorithm='HS256')
            
        elif self.auth_method == 'oauth':
            token = await self.generate_oauth_token(user)
            
        else:  # basic
            token = self.generate_session_token()
            await self.store_session(token, user['id'])
        
        # 5. 로그인 기록
        await self.log_successful_login(username)
        
        return {
            'success': True,
            'token': token,
            'user_id': user['id'],
            'expires_in': 86400  # 24 hours
        }
    
    async def verify_token(self, token: str):
        '''토큰 검증'''
        if self.auth_method == 'jwt':
            try:
                payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
                return {
                    'valid': True,
                    'user_id': payload['user_id'],
                    'username': payload['username']
                }
            except jwt.ExpiredSignatureError:
                return {'valid': False, 'error': 'Token expired'}
            except jwt.InvalidTokenError:
                return {'valid': False, 'error': 'Invalid token'}
        
        # 다른 인증 방식 처리...
        return {'valid': False}
    
    async def verify_mfa(self, secret: str, code: str) -> bool:
        '''MFA 코드 검증'''
        import pyotp
        totp = pyotp.TOTP(secret)
        return totp.verify(code, valid_window=1)
""",
    priority=10
)

# ============================================================================
# AUTHORIZATION PATTERN - 권한 확인
# ============================================================================

AUTHORIZATION_PATTERN = BusinessPattern(
    id="security_authorization",
    name="권한 확인 패턴",
    name_en="Authorization Pattern",
    category=PatternCategory.SECURITY,
    description="사용자 권한을 확인하고 접근을 제어하는 패턴",
    trigger_keywords=[
        "권한", "authorization", "permission", "access", "role",
        "rbac", "acl", "접근제어", "권한확인"
    ],
    slots=[
        PatternSlot(
            name="auth_model",
            type="str",
            required=False,
            default="rbac",
            description="권한 모델 (rbac/acl/abac)"
        )
    ],
    code_template="""
class AuthorizationHandler:
    def __init__(self, auth_model: str = 'rbac'):
        self.auth_model = auth_model
        self.permissions_cache = {}
    
    async def check_permission(self, user_id: str, resource: str, action: str) -> bool:
        '''권한 확인'''
        
        if self.auth_model == 'rbac':
            # Role-Based Access Control
            user_roles = await self.get_user_roles(user_id)
            
            for role in user_roles:
                permissions = await self.get_role_permissions(role)
                if self._has_permission(permissions, resource, action):
                    return True
            
        elif self.auth_model == 'acl':
            # Access Control List
            acl = await self.get_resource_acl(resource)
            
            if user_id in acl:
                allowed_actions = acl[user_id]
                if action in allowed_actions or '*' in allowed_actions:
                    return True
            
        elif self.auth_model == 'abac':
            # Attribute-Based Access Control
            user_attrs = await self.get_user_attributes(user_id)
            resource_attrs = await self.get_resource_attributes(resource)
            
            policy = await self.get_policy(action)
            return self.evaluate_policy(policy, user_attrs, resource_attrs)
        
        return False
    
    async def get_user_permissions(self, user_id: str) -> List[Dict]:
        '''사용자 권한 목록 조회'''
        # 캐시 확인
        if user_id in self.permissions_cache:
            return self.permissions_cache[user_id]
        
        permissions = []
        
        if self.auth_model == 'rbac':
            roles = await self.get_user_roles(user_id)
            for role in roles:
                role_perms = await self.get_role_permissions(role)
                permissions.extend(role_perms)
        
        # 캐시 저장
        self.permissions_cache[user_id] = permissions
        
        return permissions
    
    def _has_permission(self, permissions: List[Dict], resource: str, action: str) -> bool:
        '''권한 포함 여부 확인'''
        for perm in permissions:
            if (perm['resource'] == resource or perm['resource'] == '*') and \
               (perm['action'] == action or perm['action'] == '*'):
                return True
        return False
    
    async def enforce_permission(self, user_id: str, resource: str, action: str):
        '''권한 강제 (데코레이터용)'''
        if not await self.check_permission(user_id, resource, action):
            raise PermissionError(f"User {user_id} lacks permission for {action} on {resource}")
        return True
""",
    priority=9
)

# ============================================================================
# ENCRYPTION PATTERN - 암호화
# ============================================================================

ENCRYPTION_PATTERN = BusinessPattern(
    id="security_encryption",
    name="암호화 패턴",
    name_en="Encryption Pattern",
    category=PatternCategory.SECURITY,
    description="데이터를 암호화하고 복호화하는 패턴",
    trigger_keywords=[
        "암호화", "encryption", "decrypt", "cipher", "crypto",
        "encode", "decode", "보안", "aes", "rsa"
    ],
    slots=[
        PatternSlot(
            name="algorithm",
            type="str",
            required=False,
            default="aes",
            description="암호화 알고리즘 (aes/rsa/hybrid)"
        ),
        PatternSlot(
            name="key_size",
            type="int",
            required=False,
            default=256,
            description="키 크기 (비트)"
        )
    ],
    code_template="""
class EncryptionHandler:
    def __init__(self, algorithm: str = 'aes', key_size: int = 256):
        self.algorithm = algorithm
        self.key_size = key_size
        self._initialize_keys()
    
    def _initialize_keys(self):
        '''암호화 키 초기화'''
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.fernet import Fernet
        
        if self.algorithm == 'aes':
            # AES (대칭키)
            self.key = Fernet.generate_key()
            self.cipher = Fernet(self.key)
            
        elif self.algorithm == 'rsa':
            # RSA (비대칭키)
            self.private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=self.key_size * 8
            )
            self.public_key = self.private_key.public_key()
    
    async def encrypt(self, data: str) -> str:
        '''데이터 암호화'''
        if self.algorithm == 'aes':
            # AES 암호화
            encrypted = self.cipher.encrypt(data.encode())
            return encrypted.decode('latin-1')
            
        elif self.algorithm == 'rsa':
            # RSA 암호화
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.asymmetric import padding
            
            encrypted = self.public_key.encrypt(
                data.encode(),
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return encrypted.hex()
        
        elif self.algorithm == 'hybrid':
            # 하이브리드 (RSA + AES)
            # AES 키 생성
            from cryptography.fernet import Fernet
            aes_key = Fernet.generate_key()
            aes_cipher = Fernet(aes_key)
            
            # 데이터는 AES로 암호화
            encrypted_data = aes_cipher.encrypt(data.encode())
            
            # AES 키는 RSA로 암호화
            encrypted_key = await self._encrypt_key_with_rsa(aes_key)
            
            return {
                'encrypted_data': encrypted_data.decode('latin-1'),
                'encrypted_key': encrypted_key
            }
    
    async def decrypt(self, encrypted_data: str) -> str:
        '''데이터 복호화'''
        if self.algorithm == 'aes':
            # AES 복호화
            decrypted = self.cipher.decrypt(encrypted_data.encode('latin-1'))
            return decrypted.decode()
            
        elif self.algorithm == 'rsa':
            # RSA 복호화
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.asymmetric import padding
            
            decrypted = self.private_key.decrypt(
                bytes.fromhex(encrypted_data),
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return decrypted.decode()
    
    async def hash_data(self, data: str, salt: str = None) -> str:
        '''데이터 해싱'''
        import hashlib
        
        if salt:
            data = data + salt
        
        hash_obj = hashlib.sha256(data.encode())
        return hash_obj.hexdigest()
""",
    priority=9
)

# ============================================================================
# AUDIT LOG PATTERN - 감사 로그
# ============================================================================

AUDIT_LOG_PATTERN = BusinessPattern(
    id="security_audit_log",
    name="감사 로그 패턴",
    name_en="Audit Log Pattern",
    category=PatternCategory.SECURITY,
    description="시스템 활동을 기록하고 감사하는 패턴",
    trigger_keywords=[
        "감사", "audit", "로그", "log", "기록", "추적",
        "tracking", "trail", "감사추적"
    ],
    slots=[
        PatternSlot(
            name="log_level",
            type="str",
            required=False,
            default="info",
            description="로그 레벨 (debug/info/warning/error/critical)"
        ),
        PatternSlot(
            name="retention_days",
            type="int",
            required=False,
            default=90,
            description="로그 보관 기간(일)"
        )
    ],
    code_template="""
class AuditLogger:
    def __init__(self, log_level: str = 'info', retention_days: int = 90):
        self.log_level = log_level
        self.retention_days = retention_days
        self.log_queue = []
    
    async def log_event(self, event_type: str, user_id: str, 
                       action: str, resource: str, 
                       result: str, details: Dict = None):
        '''감사 이벤트 로깅'''
        from datetime import datetime
        import json
        
        # 로그 엔트리 생성
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'event_type': event_type,
            'user_id': user_id,
            'action': action,
            'resource': resource,
            'result': result,
            'details': details or {},
            'ip_address': await self.get_client_ip(),
            'user_agent': await self.get_user_agent(),
            'session_id': await self.get_session_id()
        }
        
        # 로그 레벨 확인
        if self._should_log(event_type):
            # 데이터베이스에 저장
            await self.save_to_database(log_entry)
            
            # 파일에 저장
            await self.save_to_file(log_entry)
            
            # 실시간 알림 (중요 이벤트)
            if event_type in ['security_breach', 'unauthorized_access', 'data_breach']:
                await self.send_alert(log_entry)
        
        return log_entry
    
    async def search_logs(self, filters: Dict) -> List[Dict]:
        '''로그 검색'''
        query = self._build_search_query(filters)
        
        # 데이터베이스에서 검색
        logs = await self.database_search(query)
        
        # 필터링 및 정렬
        if 'start_date' in filters:
            logs = [l for l in logs if l['timestamp'] >= filters['start_date']]
        if 'end_date' in filters:
            logs = [l for l in logs if l['timestamp'] <= filters['end_date']]
        if 'user_id' in filters:
            logs = [l for l in logs if l['user_id'] == filters['user_id']]
        
        return logs
    
    async def generate_audit_report(self, period: str) -> Dict:
        '''감사 보고서 생성'''
        logs = await self.get_logs_for_period(period)
        
        # 통계 분석
        report = {
            'period': period,
            'total_events': len(logs),
            'unique_users': len(set(l['user_id'] for l in logs)),
            'event_types': {},
            'failed_attempts': 0,
            'security_events': 0,
            'top_users': [],
            'suspicious_activities': []
        }
        
        # 이벤트 타입별 집계
        for log in logs:
            event_type = log['event_type']
            if event_type not in report['event_types']:
                report['event_types'][event_type] = 0
            report['event_types'][event_type] += 1
            
            if log['result'] == 'failure':
                report['failed_attempts'] += 1
            
            if 'security' in event_type:
                report['security_events'] += 1
        
        # 의심스러운 활동 탐지
        report['suspicious_activities'] = await self.detect_suspicious_activities(logs)
        
        return report
    
    async def cleanup_old_logs(self):
        '''오래된 로그 정리'''
        from datetime import datetime, timedelta
        
        cutoff_date = datetime.utcnow() - timedelta(days=self.retention_days)
        
        # 백업 생성
        old_logs = await self.get_logs_before(cutoff_date)
        if old_logs:
            await self.archive_logs(old_logs)
        
        # 삭제
        await self.delete_logs_before(cutoff_date)
        
        return {
            'archived': len(old_logs),
            'cutoff_date': cutoff_date.isoformat()
        }
""",
    priority=8
)

# ============================================================================
# INPUT VALIDATION PATTERN - 입력 검증
# ============================================================================

INPUT_VALIDATION_PATTERN = BusinessPattern(
    id="security_input_validation",
    name="입력 검증 패턴",
    name_en="Input Validation Pattern",
    category=PatternCategory.SECURITY,
    description="사용자 입력을 검증하고 정제하는 보안 패턴",
    trigger_keywords=[
        "검증", "validation", "sanitize", "입력", "input",
        "xss", "injection", "필터링"
    ],
    slots=[
        PatternSlot(
            name="validation_rules",
            type="dict",
            required=True,
            description="검증 규칙"
        )
    ],
    code_template="""
class InputValidator:
    def __init__(self):
        self.validators = {
            'email': self.validate_email,
            'phone': self.validate_phone,
            'url': self.validate_url,
            'alphanumeric': self.validate_alphanumeric,
            'numeric': self.validate_numeric,
            'date': self.validate_date
        }
    
    async def validate_input(self, data: Dict, rules: Dict) -> Dict:
        '''입력 데이터 검증'''
        errors = []
        sanitized_data = {}
        
        for field, field_rules in rules.items():
            value = data.get(field)
            
            # 필수 필드 확인
            if field_rules.get('required') and not value:
                errors.append(f"{field} is required")
                continue
            
            # 타입 검증
            if 'type' in field_rules and value:
                if not self.validate_type(value, field_rules['type']):
                    errors.append(f"{field} must be {field_rules['type']}")
                    continue
            
            # 길이 검증
            if 'min_length' in field_rules and len(str(value)) < field_rules['min_length']:
                errors.append(f"{field} must be at least {field_rules['min_length']} characters")
            
            if 'max_length' in field_rules and len(str(value)) > field_rules['max_length']:
                errors.append(f"{field} must not exceed {field_rules['max_length']} characters")
            
            # 패턴 검증
            if 'pattern' in field_rules and value:
                import re
                if not re.match(field_rules['pattern'], str(value)):
                    errors.append(f"{field} format is invalid")
            
            # 특수 검증
            if 'validator' in field_rules and value:
                validator_name = field_rules['validator']
                if validator_name in self.validators:
                    if not self.validators[validator_name](value):
                        errors.append(f"{field} is invalid")
            
            # SQL Injection 방지
            if value and isinstance(value, str):
                sanitized_value = self.sanitize_sql(value)
            else:
                sanitized_value = value
            
            # XSS 방지
            if value and isinstance(value, str):
                sanitized_value = self.sanitize_xss(sanitized_value)
            
            sanitized_data[field] = sanitized_value
        
        if errors:
            return {
                'valid': False,
                'errors': errors,
                'data': None
            }
        
        return {
            'valid': True,
            'errors': [],
            'data': sanitized_data
        }
    
    def sanitize_sql(self, value: str) -> str:
        '''SQL Injection 방지'''
        # 위험한 SQL 키워드 제거
        dangerous_keywords = ['DROP', 'DELETE', 'INSERT', 'UPDATE', 'EXEC', 'UNION']
        for keyword in dangerous_keywords:
            value = value.replace(keyword, '')
            value = value.replace(keyword.lower(), '')
        
        # 특수 문자 이스케이프
        value = value.replace("'", "''")
        value = value.replace('"', '""')
        value = value.replace(';', '')
        value = value.replace('--', '')
        
        return value
    
    def sanitize_xss(self, value: str) -> str:
        '''XSS 공격 방지'''
        import html
        
        # HTML 엔티티 이스케이프
        value = html.escape(value)
        
        # JavaScript 이벤트 핸들러 제거
        import re
        value = re.sub(r'on\w+\s*=', '', value, flags=re.IGNORECASE)
        value = re.sub(r'javascript:', '', value, flags=re.IGNORECASE)
        
        return value
    
    def validate_email(self, email: str) -> bool:
        '''이메일 검증'''
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    def validate_phone(self, phone: str) -> bool:
        '''전화번호 검증'''
        import re
        pattern = r'^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$'
        return bool(re.match(pattern, phone))
""",
    priority=8
)

# ============================================================================
# SESSION MANAGEMENT PATTERN - 세션 관리
# ============================================================================

SESSION_MANAGEMENT_PATTERN = BusinessPattern(
    id="security_session",
    name="세션 관리 패턴",
    name_en="Session Management Pattern",
    category=PatternCategory.SECURITY,
    description="사용자 세션을 안전하게 관리하는 패턴",
    trigger_keywords=[
        "세션", "session", "쿠키", "cookie", "토큰", "token",
        "로그아웃", "logout", "만료"
    ],
    slots=[
        PatternSlot(
            name="session_timeout",
            type="int",
            required=False,
            default=3600,
            description="세션 타임아웃(초)"
        ),
        PatternSlot(
            name="refresh_enabled",
            type="bool",
            required=False,
            default=True,
            description="자동 갱신 여부"
        )
    ],
    code_template="""
class SessionManager:
    def __init__(self, session_timeout: int = 3600, refresh_enabled: bool = True):
        self.session_timeout = session_timeout
        self.refresh_enabled = refresh_enabled
        self.sessions = {}
    
    async def create_session(self, user_id: str, ip_address: str) -> str:
        '''세션 생성'''
        import uuid
        from datetime import datetime, timedelta
        
        # 세션 ID 생성
        session_id = str(uuid.uuid4())
        
        # 세션 데이터
        session_data = {
            'session_id': session_id,
            'user_id': user_id,
            'ip_address': ip_address,
            'created_at': datetime.utcnow(),
            'last_accessed': datetime.utcnow(),
            'expires_at': datetime.utcnow() + timedelta(seconds=self.session_timeout),
            'is_active': True,
            'refresh_token': str(uuid.uuid4()) if self.refresh_enabled else None
        }
        
        # 저장
        self.sessions[session_id] = session_data
        await self.save_session_to_db(session_data)
        
        return session_id
    
    async def validate_session(self, session_id: str, ip_address: str) -> Dict:
        '''세션 검증'''
        from datetime import datetime
        
        # 세션 조회
        session = self.sessions.get(session_id)
        if not session:
            session = await self.load_session_from_db(session_id)
            if not session:
                return {'valid': False, 'reason': 'Session not found'}
        
        # 만료 확인
        if datetime.utcnow() > session['expires_at']:
            await self.destroy_session(session_id)
            return {'valid': False, 'reason': 'Session expired'}
        
        # IP 확인 (보안 강화)
        if session['ip_address'] != ip_address:
            await self.log_security_event('ip_mismatch', session_id)
            return {'valid': False, 'reason': 'IP address mismatch'}
        
        # 활성 상태 확인
        if not session['is_active']:
            return {'valid': False, 'reason': 'Session inactive'}
        
        # 마지막 접근 시간 업데이트
        session['last_accessed'] = datetime.utcnow()
        
        # 자동 갱신
        if self.refresh_enabled:
            time_left = (session['expires_at'] - datetime.utcnow()).total_seconds()
            if time_left < self.session_timeout / 2:
                session['expires_at'] = datetime.utcnow() + timedelta(seconds=self.session_timeout)
        
        await self.save_session_to_db(session)
        
        return {
            'valid': True,
            'user_id': session['user_id'],
            'expires_in': (session['expires_at'] - datetime.utcnow()).total_seconds()
        }
    
    async def destroy_session(self, session_id: str):
        '''세션 종료'''
        if session_id in self.sessions:
            del self.sessions[session_id]
        
        await self.delete_session_from_db(session_id)
        await self.log_session_event('logout', session_id)
    
    async def cleanup_expired_sessions(self):
        '''만료된 세션 정리'''
        from datetime import datetime
        
        expired = []
        for session_id, session in self.sessions.items():
            if datetime.utcnow() > session['expires_at']:
                expired.append(session_id)
        
        for session_id in expired:
            await self.destroy_session(session_id)
        
        return {'cleaned': len(expired)}
""",
    priority=7
)

# ============================================================================
# RATE LIMITING PATTERN - 속도 제한
# ============================================================================

RATE_LIMITING_PATTERN = BusinessPattern(
    id="security_rate_limit",
    name="속도 제한 패턴",
    name_en="Rate Limiting Pattern",
    category=PatternCategory.SECURITY,
    description="요청 속도를 제한하여 남용을 방지하는 패턴",
    trigger_keywords=[
        "속도제한", "rate limit", "throttle", "제한", "quota",
        "api limit", "요청제한"
    ],
    slots=[
        PatternSlot(
            name="max_requests",
            type="int",
            required=False,
            default=100,
            description="최대 요청 수"
        ),
        PatternSlot(
            name="window_seconds",
            type="int",
            required=False,
            default=60,
            description="시간 윈도우(초)"
        )
    ],
    code_template="""
class RateLimiter:
    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.request_history = {}
    
    async def check_rate_limit(self, client_id: str) -> Dict:
        '''속도 제한 확인'''
        from datetime import datetime, timedelta
        
        current_time = datetime.utcnow()
        window_start = current_time - timedelta(seconds=self.window_seconds)
        
        # 클라이언트 요청 기록 조회
        if client_id not in self.request_history:
            self.request_history[client_id] = []
        
        # 오래된 요청 제거
        self.request_history[client_id] = [
            req_time for req_time in self.request_history[client_id]
            if req_time > window_start
        ]
        
        # 현재 요청 수
        request_count = len(self.request_history[client_id])
        
        if request_count >= self.max_requests:
            # 제한 초과
            reset_time = min(self.request_history[client_id]) + timedelta(seconds=self.window_seconds)
            
            return {
                'allowed': False,
                'reason': 'Rate limit exceeded',
                'limit': self.max_requests,
                'remaining': 0,
                'reset_at': reset_time.isoformat(),
                'retry_after': (reset_time - current_time).total_seconds()
            }
        
        # 요청 허용
        self.request_history[client_id].append(current_time)
        
        return {
            'allowed': True,
            'limit': self.max_requests,
            'remaining': self.max_requests - request_count - 1,
            'reset_at': (current_time + timedelta(seconds=self.window_seconds)).isoformat()
        }
    
    async def apply_rate_limit(self, client_id: str):
        '''속도 제한 적용 (데코레이터용)'''
        result = await self.check_rate_limit(client_id)
        
        if not result['allowed']:
            raise RateLimitExceeded(
                f"Rate limit exceeded. Retry after {result['retry_after']} seconds"
            )
        
        return result
""",
    priority=7
)

# ============================================================================
# DATA MASKING PATTERN - 데이터 마스킹
# ============================================================================

DATA_MASKING_PATTERN = BusinessPattern(
    id="security_data_masking",
    name="데이터 마스킹 패턴",
    name_en="Data Masking Pattern",
    category=PatternCategory.SECURITY,
    description="민감한 데이터를 마스킹하여 보호하는 패턴",
    trigger_keywords=[
        "마스킹", "masking", "가리기", "민감정보", "개인정보",
        "pii", "redact", "hide"
    ],
    slots=[
        PatternSlot(
            name="masking_rules",
            type="dict",
            required=True,
            description="마스킹 규칙"
        )
    ],
    code_template="""
class DataMasker:
    def __init__(self):
        self.masking_patterns = {
            'email': self.mask_email,
            'phone': self.mask_phone,
            'ssn': self.mask_ssn,
            'credit_card': self.mask_credit_card,
            'name': self.mask_name,
            'address': self.mask_address
        }
    
    async def mask_data(self, data: Dict, rules: Dict) -> Dict:
        '''데이터 마스킹'''
        masked_data = data.copy()
        
        for field, masking_type in rules.items():
            if field in data and data[field]:
                if masking_type in self.masking_patterns:
                    masked_data[field] = self.masking_patterns[masking_type](data[field])
                else:
                    masked_data[field] = self.generic_mask(data[field])
        
        return masked_data
    
    def mask_email(self, email: str) -> str:
        '''이메일 마스킹'''
        parts = email.split('@')
        if len(parts) != 2:
            return '***@***.***'
        
        username = parts[0]
        domain = parts[1]
        
        if len(username) <= 2:
            masked_username = '*' * len(username)
        else:
            masked_username = username[0] + '*' * (len(username) - 2) + username[-1]
        
        return f"{masked_username}@{domain}"
    
    def mask_phone(self, phone: str) -> str:
        '''전화번호 마스킹'''
        # 숫자만 추출
        import re
        digits = re.sub(r'\\D', '', phone)
        
        if len(digits) >= 10:
            return f"{digits[:3]}-***-{digits[-4:]}"
        else:
            return '*' * len(phone)
    
    def mask_credit_card(self, card_number: str) -> str:
        '''신용카드 마스킹'''
        # 숫자만 추출
        import re
        digits = re.sub(r'\\D', '', card_number)
        
        if len(digits) >= 12:
            return f"{digits[:4]} **** **** {digits[-4:]}"
        else:
            return '*' * len(card_number)
    
    def mask_ssn(self, ssn: str) -> str:
        '''주민번호 마스킹'''
        # 숫자와 하이픈만 추출
        import re
        cleaned = re.sub(r'[^0-9-]', '', ssn)
        
        if len(cleaned) >= 13:
            return f"{cleaned[:6]}-*******"
        else:
            return '*' * len(ssn)
    
    def mask_name(self, name: str) -> str:
        '''이름 마스킹'''
        if len(name) <= 1:
            return '*'
        elif len(name) == 2:
            return name[0] + '*'
        else:
            return name[0] + '*' * (len(name) - 2) + name[-1]
    
    def generic_mask(self, value: str) -> str:
        '''일반 마스킹'''
        if len(value) <= 4:
            return '*' * len(value)
        else:
            visible_chars = max(1, len(value) // 4)
            return value[:visible_chars] + '*' * (len(value) - visible_chars * 2) + value[-visible_chars:]
""",
    priority=6
)

# ============================================================================
# SECURE FILE UPLOAD PATTERN - 안전한 파일 업로드
# ============================================================================

SECURE_FILE_UPLOAD_PATTERN = BusinessPattern(
    id="security_file_upload",
    name="안전한 파일 업로드 패턴",
    name_en="Secure File Upload Pattern",
    category=PatternCategory.SECURITY,
    description="파일 업로드를 안전하게 처리하는 패턴",
    trigger_keywords=[
        "파일업로드", "file upload", "업로드", "upload", "첨부",
        "attachment", "파일검증"
    ],
    slots=[
        PatternSlot(
            name="allowed_extensions",
            type="list",
            required=True,
            description="허용된 확장자"
        ),
        PatternSlot(
            name="max_file_size",
            type="int",
            required=False,
            default=10485760,  # 10MB
            description="최대 파일 크기(바이트)"
        )
    ],
    code_template="""
class SecureFileUploader:
    def __init__(self, allowed_extensions: List[str], max_file_size: int = 10485760):
        self.allowed_extensions = allowed_extensions
        self.max_file_size = max_file_size
        self.virus_scanner = None  # 바이러스 스캐너 초기화
    
    async def validate_upload(self, file_data: bytes, filename: str) -> Dict:
        '''파일 업로드 검증'''
        import os
        import hashlib
        import magic
        
        # 1. 파일 크기 확인
        if len(file_data) > self.max_file_size:
            return {
                'valid': False,
                'error': f'File size exceeds {self.max_file_size} bytes'
            }
        
        # 2. 확장자 확인
        _, ext = os.path.splitext(filename)
        ext = ext.lower().lstrip('.')
        
        if ext not in self.allowed_extensions:
            return {
                'valid': False,
                'error': f'File extension {ext} not allowed'
            }
        
        # 3. MIME 타입 확인 (Magic Number)
        mime = magic.from_buffer(file_data, mime=True)
        expected_mimes = self._get_expected_mimes(ext)
        
        if mime not in expected_mimes:
            return {
                'valid': False,
                'error': f'File content does not match extension'
            }
        
        # 4. 파일명 정제
        safe_filename = self._sanitize_filename(filename)
        
        # 5. 악성 코드 검사
        if self.virus_scanner:
            scan_result = await self.virus_scanner.scan(file_data)
            if scan_result['infected']:
                return {
                    'valid': False,
                    'error': 'Malware detected'
                }
        
        # 6. 파일 해시 생성
        file_hash = hashlib.sha256(file_data).hexdigest()
        
        return {
            'valid': True,
            'safe_filename': safe_filename,
            'mime_type': mime,
            'file_hash': file_hash,
            'file_size': len(file_data)
        }
    
    def _sanitize_filename(self, filename: str) -> str:
        '''파일명 정제'''
        import re
        
        # 위험한 문자 제거
        filename = re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
        
        # 경로 트래버설 방지
        filename = filename.replace('..', '')
        filename = filename.replace('/', '')
        filename = filename.replace('\\\\', '')
        
        # 최대 길이 제한
        if len(filename) > 255:
            name, ext = os.path.splitext(filename)
            filename = name[:250] + ext
        
        return filename
    
    def _get_expected_mimes(self, extension: str) -> List[str]:
        '''확장자별 예상 MIME 타입'''
        mime_map = {
            'jpg': ['image/jpeg'],
            'jpeg': ['image/jpeg'],
            'png': ['image/png'],
            'gif': ['image/gif'],
            'pdf': ['application/pdf'],
            'doc': ['application/msword'],
            'docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            'txt': ['text/plain'],
            'csv': ['text/csv']
        }
        return mime_map.get(extension, [])
""",
    priority=6
)

# 패턴 등록
register_pattern(AUTHENTICATION_PATTERN)
register_pattern(AUTHORIZATION_PATTERN)
register_pattern(ENCRYPTION_PATTERN)
register_pattern(AUDIT_LOG_PATTERN)
register_pattern(INPUT_VALIDATION_PATTERN)
register_pattern(SESSION_MANAGEMENT_PATTERN)
register_pattern(RATE_LIMITING_PATTERN)
register_pattern(DATA_MASKING_PATTERN)
register_pattern(SECURE_FILE_UPLOAD_PATTERN)