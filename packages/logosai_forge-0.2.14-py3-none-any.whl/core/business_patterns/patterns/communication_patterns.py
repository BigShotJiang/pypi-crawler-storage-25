"""
Communication Patterns - 커뮤니케이션 관련 비즈니스 패턴
이메일, 채팅, 알림, 메시징 등 통신 관련 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# EMAIL CAMPAIGN - 이메일 캠페인
# ============================================================================

EMAIL_CAMPAIGN_PATTERN = BusinessPattern(
    id="comm_email_campaign",
    name="이메일 캠페인",
    name_en="Email Campaign Pattern",
    category=PatternCategory.NOTIFICATION,
    description="대량 이메일 캠페인을 관리하고 발송하는 패턴",
    trigger_keywords=[
        "이메일 캠페인", "email campaign", "뉴스레터", "newsletter",
        "마케팅 메일", "대량 발송", "메일링"
    ],
    slots=[
        PatternSlot(
            name="campaign_name",
            type="str",
            required=True,
            description="캠페인 이름"
        ),
        PatternSlot(
            name="recipients",
            type="list",
            required=True,
            description="수신자 목록"
        ),
        PatternSlot(
            name="template",
            type="str",
            required=True,
            description="이메일 템플릿"
        )
    ],
    code_template="""
async def execute_email_campaign(self, campaign_name: str, recipients: List[str], 
                                 template: str, personalization: Dict = None):
    '''이메일 캠페인 실행'''
    import asyncio
    from datetime import datetime
    
    campaign = {
        'id': self.generate_id(),
        'name': campaign_name,
        'total': len(recipients),
        'sent': 0,
        'failed': 0,
        'opened': 0,
        'clicked': 0,
        'started_at': datetime.now()
    }
    
    # 배치 발송 (스팸 방지)
    batch_size = 50
    delay_between_batches = 60  # seconds
    
    for i in range(0, len(recipients), batch_size):
        batch = recipients[i:i + batch_size]
        
        for recipient in batch:
            try:
                # 개인화 처리
                personalized_content = self.personalize_template(
                    template, 
                    recipient, 
                    personalization
                )
                
                # 이메일 발송
                result = await self.send_email(
                    to=recipient,
                    subject=campaign_name,
                    body=personalized_content,
                    track=True  # 오픈/클릭 추적
                )
                
                if result['status'] == 'sent':
                    campaign['sent'] += 1
                else:
                    campaign['failed'] += 1
                    
            except Exception as e:
                self.logger.error(f"Failed to send to {recipient}: {e}")
                campaign['failed'] += 1
        
        # 배치 간 대기
        if i + batch_size < len(recipients):
            await asyncio.sleep(delay_between_batches)
    
    campaign['completed_at'] = datetime.now()
    campaign['duration'] = (campaign['completed_at'] - campaign['started_at']).total_seconds()
    
    return campaign
""",
    priority=9
)

# ============================================================================
# CHAT BOT - 챗봇 응답
# ============================================================================

CHAT_BOT_PATTERN = BusinessPattern(
    id="comm_chatbot",
    name="챗봇 응답 패턴",
    name_en="Chat Bot Pattern",
    category=PatternCategory.AUTOMATION,
    description="자동 챗봇 응답 처리 패턴",
    trigger_keywords=[
        "챗봇", "chatbot", "자동응답", "bot", "대화",
        "conversation", "chat", "메시지"
    ],
    slots=[
        PatternSlot(
            name="intent",
            type="str",
            required=True,
            description="사용자 의도"
        ),
        PatternSlot(
            name="context",
            type="dict",
            required=False,
            description="대화 컨텍스트"
        )
    ],
    code_template="""
class ChatBot:
    def __init__(self):
        self.intents = {}
        self.context = {}
        self.conversation_history = []
    
    def register_intent(self, intent: str, handler: callable):
        '''의도별 핸들러 등록'''
        self.intents[intent] = handler
    
    async def process_message(self, message: str, user_id: str):
        '''메시지 처리 및 응답 생성'''
        
        # 의도 분석
        intent = await self.analyze_intent(message)
        
        # 컨텍스트 로드
        if user_id not in self.context:
            self.context[user_id] = {'history': []}
        
        user_context = self.context[user_id]
        
        # 대화 히스토리 추가
        user_context['history'].append({
            'message': message,
            'intent': intent,
            'timestamp': self.get_timestamp()
        })
        
        # 응답 생성
        if intent in self.intents:
            response = await self.intents[intent](message, user_context)
        else:
            # 기본 응답 또는 AI 모델 사용
            response = await self.generate_ai_response(message, user_context)
        
        # 응답 기록
        user_context['history'].append({
            'response': response,
            'timestamp': self.get_timestamp()
        })
        
        return {
            'intent': intent,
            'response': response,
            'suggested_actions': self.get_suggested_actions(intent)
        }
    
    async def analyze_intent(self, message: str) -> str:
        '''NLP를 사용한 의도 분석'''
        # 간단한 키워드 매칭 또는 ML 모델 사용
        intents_keywords = {
            'greeting': ['안녕', 'hello', 'hi'],
            'help': ['도움', 'help', '문의'],
            'order': ['주문', 'order', '구매'],
            'status': ['상태', 'status', '확인']
        }
        
        message_lower = message.lower()
        for intent, keywords in intents_keywords.items():
            if any(keyword in message_lower for keyword in keywords):
                return intent
        
        return 'unknown'
""",
    priority=9
)

# ============================================================================
# PUSH NOTIFICATION - 푸시 알림
# ============================================================================

PUSH_NOTIFICATION_PATTERN = BusinessPattern(
    id="comm_push_notification",
    name="푸시 알림 패턴",
    name_en="Push Notification Pattern",
    category=PatternCategory.NOTIFICATION,
    description="모바일/웹 푸시 알림을 발송하는 패턴",
    trigger_keywords=[
        "푸시", "push", "알림", "notification", "알람",
        "fcm", "apns", "웹푸시"
    ],
    slots=[
        PatternSlot(
            name="target",
            type="str",
            required=True,
            description="대상 (user_id/topic/all)"
        ),
        PatternSlot(
            name="title",
            type="str",
            required=True,
            description="알림 제목"
        ),
        PatternSlot(
            name="body",
            type="str",
            required=True,
            description="알림 내용"
        )
    ],
    code_template="""
async def send_push_notification(self, target: str, title: str, body: str, 
                                 data: Dict = None, priority: str = 'normal'):
    '''푸시 알림 발송'''
    from firebase_admin import messaging
    
    # 메시지 생성
    notification = messaging.Notification(
        title=title,
        body=body
    )
    
    # 추가 데이터
    if data:
        message_data = {k: str(v) for k, v in data.items()}
    else:
        message_data = {}
    
    # 대상별 메시지 구성
    if target.startswith('user:'):
        # 특정 사용자
        user_id = target.replace('user:', '')
        token = await self.get_user_fcm_token(user_id)
        message = messaging.Message(
            notification=notification,
            data=message_data,
            token=token,
            android=messaging.AndroidConfig(
                priority=priority
            ),
            apns=messaging.APNSConfig(
                headers={'apns-priority': '10' if priority == 'high' else '5'}
            )
        )
        
    elif target.startswith('topic:'):
        # 토픽 구독자
        topic = target.replace('topic:', '')
        message = messaging.Message(
            notification=notification,
            data=message_data,
            topic=topic
        )
        
    else:
        # 전체 사용자 (배치 처리)
        tokens = await self.get_all_fcm_tokens()
        message = messaging.MulticastMessage(
            notification=notification,
            data=message_data,
            tokens=tokens
        )
    
    # 발송
    try:
        if isinstance(message, messaging.MulticastMessage):
            response = messaging.send_multicast(message)
            return {
                'status': 'sent',
                'success_count': response.success_count,
                'failure_count': response.failure_count
            }
        else:
            response = messaging.send(message)
            return {
                'status': 'sent',
                'message_id': response
            }
            
    except Exception as e:
        self.logger.error(f"Push notification failed: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }
""",
    priority=8
)

# ============================================================================
# VIDEO CONFERENCE - 화상 회의
# ============================================================================

VIDEO_CONFERENCE_PATTERN = BusinessPattern(
    id="comm_video_conference",
    name="화상 회의 패턴",
    name_en="Video Conference Pattern",
    category=PatternCategory.AUTOMATION,
    description="화상 회의를 생성하고 관리하는 패턴",
    trigger_keywords=[
        "화상회의", "video conference", "zoom", "teams", "meet",
        "webex", "미팅", "회의", "conference"
    ],
    slots=[
        PatternSlot(
            name="topic",
            type="str",
            required=True,
            description="회의 주제"
        ),
        PatternSlot(
            name="participants",
            type="list",
            required=True,
            description="참가자 목록"
        ),
        PatternSlot(
            name="duration",
            type="int",
            required=False,
            default=60,
            description="회의 시간(분)"
        )
    ],
    code_template="""
async def create_video_conference(self, topic: str, participants: List[str], 
                                  start_time: datetime = None, duration: int = 60):
    '''화상 회의 생성 및 초대'''
    import jwt
    from datetime import datetime, timedelta
    
    # Zoom API 예제
    meeting_config = {
        'topic': topic,
        'type': 2,  # Scheduled meeting
        'start_time': start_time or datetime.now(),
        'duration': duration,
        'timezone': 'Asia/Seoul',
        'settings': {
            'host_video': True,
            'participant_video': True,
            'join_before_host': False,
            'mute_upon_entry': True,
            'watermark': False,
            'use_pmi': False,
            'approval_type': 0,
            'audio': 'both',
            'auto_recording': 'cloud'
        }
    }
    
    # 회의 생성
    meeting = await self.zoom_api.create_meeting(meeting_config)
    
    # 참가자 초대
    for participant in participants:
        invitation = {
            'meeting_id': meeting['id'],
            'meeting_url': meeting['join_url'],
            'topic': topic,
            'start_time': meeting_config['start_time'],
            'duration': duration,
            'password': meeting.get('password')
        }
        
        # 이메일 또는 캘린더 초대 발송
        await self.send_meeting_invitation(participant, invitation)
    
    return {
        'meeting_id': meeting['id'],
        'join_url': meeting['join_url'],
        'start_url': meeting['start_url'],
        'password': meeting.get('password'),
        'invited': len(participants)
    }
""",
    priority=7
)

# ============================================================================
# VOICE CALL - 음성 통화
# ============================================================================

VOICE_CALL_PATTERN = BusinessPattern(
    id="comm_voice_call",
    name="음성 통화 패턴",
    name_en="Voice Call Pattern",
    category=PatternCategory.AUTOMATION,
    description="음성 통화를 발신하고 처리하는 패턴",
    trigger_keywords=[
        "음성통화", "voice call", "전화", "call", "voip",
        "통화", "콜", "twilio"
    ],
    slots=[
        PatternSlot(
            name="to_number",
            type="str",
            required=True,
            description="수신 전화번호"
        ),
        PatternSlot(
            name="message",
            type="str",
            required=False,
            description="TTS 메시지"
        )
    ],
    code_template="""
async def make_voice_call(self, to_number: str, message: str = None, 
                         callback_url: str = None):
    '''음성 통화 발신'''
    from twilio.rest import Client
    
    client = Client(self.twilio_sid, self.twilio_token)
    
    try:
        if message:
            # TTS 메시지 전달
            twiml = f'<Response><Say language="ko-KR">{message}</Say></Response>'
            call = client.calls.create(
                to=to_number,
                from_=self.twilio_phone,
                twiml=twiml
            )
        else:
            # 콜백 URL로 통화 처리
            call = client.calls.create(
                to=to_number,
                from_=self.twilio_phone,
                url=callback_url or self.default_callback_url,
                method='POST'
            )
        
        return {
            'status': 'initiated',
            'call_sid': call.sid,
            'to': to_number,
            'duration': None  # 통화 종료 후 업데이트
        }
        
    except Exception as e:
        self.logger.error(f"Voice call failed: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }
""",
    priority=6
)

# ============================================================================
# SLACK INTEGRATION - 슬랙 연동
# ============================================================================

SLACK_INTEGRATION_PATTERN = BusinessPattern(
    id="comm_slack",
    name="슬랙 연동 패턴",
    name_en="Slack Integration Pattern",
    category=PatternCategory.NOTIFICATION,
    description="슬랙 메시지를 발송하고 상호작용하는 패턴",
    trigger_keywords=[
        "슬랙", "slack", "workspace", "channel", "dm",
        "thread", "mention", "봇"
    ],
    slots=[
        PatternSlot(
            name="channel",
            type="str",
            required=True,
            description="슬랙 채널"
        ),
        PatternSlot(
            name="message",
            type="str",
            required=True,
            description="메시지 내용"
        )
    ],
    code_template="""
class SlackBot:
    def __init__(self, token: str):
        from slack_sdk import WebClient
        self.client = WebClient(token=token)
        self.bot_id = None
    
    async def send_message(self, channel: str, text: str, 
                          blocks: List[Dict] = None, thread_ts: str = None):
        '''슬랙 메시지 발송'''
        try:
            response = self.client.chat_postMessage(
                channel=channel,
                text=text,
                blocks=blocks,
                thread_ts=thread_ts  # 스레드 답글
            )
            
            return {
                'status': 'sent',
                'ts': response['ts'],
                'channel': response['channel']
            }
            
        except Exception as e:
            self.logger.error(f"Slack message failed: {e}")
            return {'status': 'error', 'error': str(e)}
    
    async def send_interactive_message(self, channel: str, text: str, actions: List[Dict]):
        '''인터랙티브 메시지 발송'''
        blocks = [
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": text}
            },
            {
                "type": "actions",
                "elements": actions
            }
        ]
        
        return await self.send_message(channel, text, blocks)
    
    async def handle_interaction(self, payload: Dict):
        '''버튼 클릭 등 상호작용 처리'''
        action = payload['actions'][0]
        user = payload['user']['id']
        
        # 액션별 처리
        if action['action_id'] == 'approve':
            await self.handle_approval(user, payload)
        elif action['action_id'] == 'reject':
            await self.handle_rejection(user, payload)
""",
    priority=8
)

# ============================================================================
# TEAMS INTEGRATION - MS Teams 연동
# ============================================================================

TEAMS_INTEGRATION_PATTERN = BusinessPattern(
    id="comm_teams",
    name="MS Teams 연동 패턴",
    name_en="Teams Integration Pattern",
    category=PatternCategory.NOTIFICATION,
    description="Microsoft Teams와 연동하는 패턴",
    trigger_keywords=[
        "teams", "팀즈", "microsoft teams", "ms teams",
        "채널", "팀", "멘션"
    ],
    slots=[
        PatternSlot(
            name="team_id",
            type="str",
            required=True,
            description="팀 ID"
        ),
        PatternSlot(
            name="channel_id",
            type="str",
            required=True,
            description="채널 ID"
        )
    ],
    code_template="""
async def send_teams_message(self, team_id: str, channel_id: str, 
                            message: str, card: Dict = None):
    '''Teams 메시지 발송'''
    import aiohttp
    
    # Graph API 사용
    url = f"https://graph.microsoft.com/v1.0/teams/{team_id}/channels/{channel_id}/messages"
    
    headers = {
        'Authorization': f'Bearer {self.teams_token}',
        'Content-Type': 'application/json'
    }
    
    body = {
        'body': {
            'contentType': 'html',
            'content': message
        }
    }
    
    # Adaptive Card 추가
    if card:
        body['attachments'] = [{
            'contentType': 'application/vnd.microsoft.card.adaptive',
            'content': card
        }]
    
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=body, headers=headers) as response:
            if response.status == 201:
                result = await response.json()
                return {
                    'status': 'sent',
                    'message_id': result['id']
                }
            else:
                return {
                    'status': 'error',
                    'error': await response.text()
                }
""",
    priority=7
)

# ============================================================================  
# DISCORD BOT - 디스코드 봇
# ============================================================================

DISCORD_BOT_PATTERN = BusinessPattern(
    id="comm_discord",
    name="디스코드 봇 패턴",
    name_en="Discord Bot Pattern",
    category=PatternCategory.AUTOMATION,
    description="디스코드 봇 메시지 및 상호작용 패턴",
    trigger_keywords=[
        "디스코드", "discord", "봇", "bot", "서버",
        "길드", "guild", "채널"
    ],
    slots=[
        PatternSlot(
            name="guild_id",
            type="str",
            required=True,
            description="서버(길드) ID"
        ),
        PatternSlot(
            name="channel_id",
            type="str",
            required=True,
            description="채널 ID"
        )
    ],
    code_template="""
import discord
from discord.ext import commands

class DiscordBot(commands.Bot):
    def __init__(self, command_prefix='!'):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix=command_prefix, intents=intents)
    
    async def send_embed_message(self, channel_id: int, title: str, 
                                description: str, color: int = 0x00ff00):
        '''임베드 메시지 발송'''
        channel = self.get_channel(channel_id)
        
        embed = discord.Embed(
            title=title,
            description=description,
            color=color
        )
        
        embed.add_field(name="Status", value="Active", inline=True)
        embed.set_footer(text="Bot Message")
        
        await channel.send(embed=embed)
    
    @commands.command()
    async def status(self, ctx):
        '''!status 명령어 처리'''
        await ctx.send("Bot is running!")
    
    async def on_message(self, message):
        '''메시지 이벤트 처리'''
        if message.author == self.user:
            return
        
        # 멘션 처리
        if self.user.mentioned_in(message):
            await message.channel.send(f"Hello {message.author.mention}!")
        
        await self.process_commands(message)
""",
    priority=6
)

# ============================================================================
# WHATSAPP BUSINESS - WhatsApp 비즈니스
# ============================================================================

WHATSAPP_BUSINESS_PATTERN = BusinessPattern(
    id="comm_whatsapp",
    name="WhatsApp 비즈니스 패턴",
    name_en="WhatsApp Business Pattern",
    category=PatternCategory.NOTIFICATION,
    description="WhatsApp Business API를 통한 메시징 패턴",
    trigger_keywords=[
        "왓츠앱", "whatsapp", "wa", "비즈니스 메시지",
        "템플릿 메시지", "대화형"
    ],
    slots=[
        PatternSlot(
            name="phone_number",
            type="str",
            required=True,
            description="수신자 전화번호"
        ),
        PatternSlot(
            name="template_name",
            type="str",
            required=False,
            description="메시지 템플릿"
        )
    ],
    code_template="""
async def send_whatsapp_message(self, phone_number: str, message: str, 
                               template_name: str = None, media_url: str = None):
    '''WhatsApp 메시지 발송'''
    import aiohttp
    
    url = f"https://graph.facebook.com/v17.0/{self.whatsapp_phone_id}/messages"
    headers = {
        'Authorization': f'Bearer {self.whatsapp_token}',
        'Content-Type': 'application/json'
    }
    
    if template_name:
        # 템플릿 메시지
        data = {
            'messaging_product': 'whatsapp',
            'to': phone_number,
            'type': 'template',
            'template': {
                'name': template_name,
                'language': {'code': 'ko'}
            }
        }
    elif media_url:
        # 미디어 메시지
        data = {
            'messaging_product': 'whatsapp',
            'to': phone_number,
            'type': 'image',
            'image': {
                'link': media_url,
                'caption': message
            }
        }
    else:
        # 텍스트 메시지
        data = {
            'messaging_product': 'whatsapp',
            'to': phone_number,
            'type': 'text',
            'text': {'body': message}
        }
    
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=data, headers=headers) as response:
            if response.status == 200:
                result = await response.json()
                return {
                    'status': 'sent',
                    'message_id': result['messages'][0]['id']
                }
            else:
                return {
                    'status': 'error',
                    'error': await response.text()
                }
""",
    priority=6
)

# ============================================================================
# IN-APP MESSAGING - 인앱 메시징
# ============================================================================

IN_APP_MESSAGING_PATTERN = BusinessPattern(
    id="comm_in_app",
    name="인앱 메시징 패턴",
    name_en="In-App Messaging Pattern",
    category=PatternCategory.NOTIFICATION,
    description="앱 내 실시간 메시징 패턴",
    trigger_keywords=[
        "인앱", "in-app", "실시간", "realtime", "메시징",
        "채팅", "알림", "팝업"
    ],
    slots=[
        PatternSlot(
            name="user_id",
            type="str",
            required=True,
            description="사용자 ID"
        ),
        PatternSlot(
            name="message_type",
            type="str",
            required=True,
            description="메시지 타입"
        )
    ],
    code_template="""
class InAppMessaging:
    def __init__(self):
        self.connections = {}  # WebSocket connections
        self.message_queue = {}
    
    async def send_in_app_message(self, user_id: str, message_type: str, 
                                  content: Dict, priority: str = 'normal'):
        '''인앱 메시지 발송'''
        
        message = {
            'id': self.generate_id(),
            'type': message_type,
            'content': content,
            'priority': priority,
            'timestamp': self.get_timestamp(),
            'read': False
        }
        
        # 온라인 사용자에게 즉시 전송
        if user_id in self.connections:
            ws = self.connections[user_id]
            await ws.send_json(message)
            return {'status': 'delivered', 'message_id': message['id']}
        
        # 오프라인 사용자를 위해 큐에 저장
        if user_id not in self.message_queue:
            self.message_queue[user_id] = []
        
        self.message_queue[user_id].append(message)
        
        # 푸시 알림 발송 (선택적)
        if priority == 'high':
            await self.send_push_fallback(user_id, content)
        
        return {'status': 'queued', 'message_id': message['id']}
    
    async def handle_user_connection(self, user_id: str, websocket):
        '''사용자 연결 처리'''
        self.connections[user_id] = websocket
        
        # 대기 중인 메시지 전송
        if user_id in self.message_queue:
            for message in self.message_queue[user_id]:
                await websocket.send_json(message)
            del self.message_queue[user_id]
""",
    priority=7
)

# 패턴 등록
register_pattern(EMAIL_CAMPAIGN_PATTERN)
register_pattern(CHAT_BOT_PATTERN)
register_pattern(PUSH_NOTIFICATION_PATTERN)
register_pattern(VIDEO_CONFERENCE_PATTERN)
register_pattern(VOICE_CALL_PATTERN)
register_pattern(SLACK_INTEGRATION_PATTERN)
register_pattern(TEAMS_INTEGRATION_PATTERN)
register_pattern(DISCORD_BOT_PATTERN)
register_pattern(WHATSAPP_BUSINESS_PATTERN)
register_pattern(IN_APP_MESSAGING_PATTERN)