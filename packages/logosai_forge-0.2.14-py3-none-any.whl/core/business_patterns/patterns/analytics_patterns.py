"""
Analytics Patterns - 분석 관련 비즈니스 패턴
데이터 분석, 예측, 분류, 트렌드 분석 등 AI/ML 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# TREND ANALYSIS - 트렌드 분석
# ============================================================================

TREND_ANALYSIS_PATTERN = BusinessPattern(
    id="analytics_trend",
    name="트렌드 분석 패턴",
    name_en="Trend Analysis Pattern",
    category=PatternCategory.AGGREGATION,
    description="시계열 데이터의 트렌드를 분석하는 패턴",
    trigger_keywords=[
        "트렌드", "trend", "추세", "경향", "패턴", "시계열",
        "time series", "변화", "추이"
    ],
    slots=[
        PatternSlot(
            name="time_column",
            type="str",
            required=True,
            description="시간 컬럼명"
        ),
        PatternSlot(
            name="value_column",
            type="str",
            required=True,
            description="값 컬럼명"
        ),
        PatternSlot(
            name="period",
            type="str",
            required=False,
            default="daily",
            description="분석 주기 (daily/weekly/monthly)"
        )
    ],
    code_template="""
async def analyze_trend(self, data: List[Dict], time_column: str, 
                       value_column: str, period: str = 'daily'):
    '''트렌드 분석 수행'''
    import pandas as pd
    import numpy as np
    from scipy import stats
    
    # 데이터프레임 생성
    df = pd.DataFrame(data)
    df[time_column] = pd.to_datetime(df[time_column])
    df = df.sort_values(time_column)
    
    # 주기별 집계
    if period == 'daily':
        df_grouped = df.groupby(pd.Grouper(key=time_column, freq='D'))
    elif period == 'weekly':
        df_grouped = df.groupby(pd.Grouper(key=time_column, freq='W'))
    elif period == 'monthly':
        df_grouped = df.groupby(pd.Grouper(key=time_column, freq='M'))
    else:
        df_grouped = df.groupby(time_column)
    
    aggregated = df_grouped[value_column].agg(['mean', 'sum', 'count'])
    
    # 트렌드 계산
    x = np.arange(len(aggregated))
    y = aggregated['mean'].values
    
    # 선형 회귀
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
    
    # 이동 평균
    ma_7 = aggregated['mean'].rolling(window=7, min_periods=1).mean()
    ma_30 = aggregated['mean'].rolling(window=30, min_periods=1).mean()
    
    # 트렌드 판단
    if slope > 0 and p_value < 0.05:
        trend_direction = 'increasing'
    elif slope < 0 and p_value < 0.05:
        trend_direction = 'decreasing'
    else:
        trend_direction = 'stable'
    
    # 변화율 계산
    change_rate = ((y[-1] - y[0]) / y[0] * 100) if y[0] != 0 else 0
    
    return {
        'trend_direction': trend_direction,
        'slope': float(slope),
        'r_squared': float(r_value ** 2),
        'p_value': float(p_value),
        'change_rate': float(change_rate),
        'current_value': float(y[-1]) if len(y) > 0 else 0,
        'average': float(np.mean(y)),
        'min': float(np.min(y)),
        'max': float(np.max(y)),
        'moving_average_7': ma_7.tolist(),
        'moving_average_30': ma_30.tolist()
    }
""",
    priority=10
)

# ============================================================================
# ANOMALY DETECTION - 이상 탐지
# ============================================================================

ANOMALY_DETECTION_PATTERN = BusinessPattern(
    id="analytics_anomaly",
    name="이상 탐지 패턴",
    name_en="Anomaly Detection Pattern",
    category=PatternCategory.VALIDATION,
    description="데이터에서 이상치를 탐지하는 패턴",
    trigger_keywords=[
        "이상", "anomaly", "outlier", "이상치", "비정상",
        "abnormal", "detection", "탐지"
    ],
    slots=[
        PatternSlot(
            name="method",
            type="str",
            required=False,
            default="zscore",
            description="탐지 방법 (zscore/iqr/isolation)"
        ),
        PatternSlot(
            name="threshold",
            type="float",
            required=False,
            default=3.0,
            description="이상치 임계값"
        )
    ],
    code_template="""
async def detect_anomalies(self, data: List[float], method: str = 'zscore', 
                          threshold: float = 3.0):
    '''이상치 탐지'''
    import numpy as np
    from scipy import stats
    
    data_array = np.array(data)
    anomalies = []
    
    if method == 'zscore':
        # Z-score 방법
        z_scores = np.abs(stats.zscore(data_array))
        anomaly_indices = np.where(z_scores > threshold)[0]
        
    elif method == 'iqr':
        # IQR (Interquartile Range) 방법
        Q1 = np.percentile(data_array, 25)
        Q3 = np.percentile(data_array, 75)
        IQR = Q3 - Q1
        
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        
        anomaly_indices = np.where(
            (data_array < lower_bound) | (data_array > upper_bound)
        )[0]
        
    elif method == 'isolation':
        # Isolation Forest
        from sklearn.ensemble import IsolationForest
        
        clf = IsolationForest(contamination=0.1, random_state=42)
        predictions = clf.fit_predict(data_array.reshape(-1, 1))
        anomaly_indices = np.where(predictions == -1)[0]
    
    else:
        # MAD (Median Absolute Deviation) 방법
        median = np.median(data_array)
        mad = np.median(np.abs(data_array - median))
        modified_z_scores = 0.6745 * (data_array - median) / mad
        anomaly_indices = np.where(np.abs(modified_z_scores) > threshold)[0]
    
    # 이상치 정보 수집
    for idx in anomaly_indices:
        anomalies.append({
            'index': int(idx),
            'value': float(data_array[idx]),
            'score': float(z_scores[idx]) if method == 'zscore' else None
        })
    
    # 통계 정보
    normal_data = np.delete(data_array, anomaly_indices)
    
    return {
        'anomalies_found': len(anomalies),
        'anomaly_rate': len(anomalies) / len(data) * 100,
        'anomalies': anomalies,
        'statistics': {
            'mean': float(np.mean(data_array)),
            'std': float(np.std(data_array)),
            'median': float(np.median(data_array)),
            'normal_mean': float(np.mean(normal_data)) if len(normal_data) > 0 else 0,
            'normal_std': float(np.std(normal_data)) if len(normal_data) > 0 else 0
        },
        'method_used': method,
        'threshold': threshold
    }
""",
    priority=9
)

# ============================================================================
# PREDICTION PATTERN - 예측 모델
# ============================================================================

PREDICTION_PATTERN = BusinessPattern(
    id="analytics_prediction",
    name="예측 모델 패턴",
    name_en="Prediction Pattern",
    category=PatternCategory.AGGREGATION,
    description="미래 값을 예측하는 머신러닝 패턴",
    trigger_keywords=[
        "예측", "predict", "forecast", "예상", "추정",
        "estimate", "projection", "미래"
    ],
    slots=[
        PatternSlot(
            name="model_type",
            type="str",
            required=False,
            default="linear",
            description="모델 타입 (linear/polynomial/arima)"
        ),
        PatternSlot(
            name="forecast_periods",
            type="int",
            required=False,
            default=10,
            description="예측 기간"
        )
    ],
    code_template="""
async def predict_values(self, historical_data: List[float], 
                        model_type: str = 'linear', 
                        forecast_periods: int = 10):
    '''값 예측'''
    import numpy as np
    from sklearn.linear_model import LinearRegression
    from sklearn.preprocessing import PolynomialFeatures
    
    # 데이터 준비
    X = np.arange(len(historical_data)).reshape(-1, 1)
    y = np.array(historical_data)
    
    predictions = []
    confidence_intervals = []
    
    if model_type == 'linear':
        # 선형 회귀
        model = LinearRegression()
        model.fit(X, y)
        
        # 예측
        future_X = np.arange(len(historical_data), 
                            len(historical_data) + forecast_periods).reshape(-1, 1)
        predictions = model.predict(future_X)
        
        # R-squared
        r_squared = model.score(X, y)
        
    elif model_type == 'polynomial':
        # 다항 회귀
        poly = PolynomialFeatures(degree=2)
        X_poly = poly.fit_transform(X)
        
        model = LinearRegression()
        model.fit(X_poly, y)
        
        # 예측
        future_X = np.arange(len(historical_data), 
                            len(historical_data) + forecast_periods).reshape(-1, 1)
        future_X_poly = poly.transform(future_X)
        predictions = model.predict(future_X_poly)
        
        r_squared = model.score(X_poly, y)
        
    elif model_type == 'arima':
        # ARIMA 모델
        from statsmodels.tsa.arima.model import ARIMA
        
        model = ARIMA(y, order=(1, 1, 1))
        model_fit = model.fit()
        
        # 예측
        forecast = model_fit.forecast(steps=forecast_periods)
        predictions = forecast
        
        # 신뢰구간
        # forecast_result = model_fit.get_forecast(steps=forecast_periods)
        # confidence_intervals = forecast_result.conf_int()
        
        r_squared = 0.0  # ARIMA는 R-squared 대신 AIC 사용
    
    # 예측 결과 정리
    forecast_data = []
    for i, pred in enumerate(predictions):
        forecast_data.append({
            'period': i + 1,
            'predicted_value': float(pred),
            'timestamp': f"T+{i+1}"
        })
    
    # 성능 메트릭
    if len(historical_data) > 10:
        # 백테스팅으로 정확도 계산
        train_size = int(len(historical_data) * 0.8)
        test_data = historical_data[train_size:]
        # 실제 백테스팅 구현...
        accuracy = 0.85  # 예시값
    else:
        accuracy = r_squared
    
    return {
        'model_type': model_type,
        'forecast_periods': forecast_periods,
        'predictions': forecast_data,
        'model_accuracy': float(accuracy),
        'last_actual_value': float(historical_data[-1]),
        'first_predicted_value': float(predictions[0]),
        'trend': 'up' if predictions[-1] > predictions[0] else 'down'
    }
""",
    priority=9
)

# ============================================================================
# CLASSIFICATION PATTERN - 분류 작업
# ============================================================================

CLASSIFICATION_PATTERN = BusinessPattern(
    id="analytics_classification",
    name="분류 패턴",
    name_en="Classification Pattern",
    category=PatternCategory.VALIDATION,
    description="데이터를 카테고리로 분류하는 패턴",
    trigger_keywords=[
        "분류", "classify", "classification", "카테고리", "구분",
        "categorize", "label", "태그"
    ],
    slots=[
        PatternSlot(
            name="algorithm",
            type="str",
            required=False,
            default="random_forest",
            description="분류 알고리즘"
        ),
        PatternSlot(
            name="classes",
            type="list",
            required=True,
            description="분류 클래스"
        )
    ],
    code_template="""
async def classify_data(self, features: List[Dict], labels: List[str] = None,
                       algorithm: str = 'random_forest'):
    '''데이터 분류'''
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.svm import SVC
    from sklearn.naive_bayes import GaussianNB
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    import numpy as np
    
    # 특징 추출
    X = []
    for item in features:
        X.append(list(item.values()))
    X = np.array(X)
    
    if labels:
        # 학습 모드
        le = LabelEncoder()
        y = le.fit_transform(labels)
        
        # 데이터 분할
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        # 모델 선택
        if algorithm == 'random_forest':
            model = RandomForestClassifier(n_estimators=100)
        elif algorithm == 'svm':
            model = SVC(probability=True)
        elif algorithm == 'naive_bayes':
            model = GaussianNB()
        else:
            model = RandomForestClassifier()
        
        # 학습
        model.fit(X_train, y_train)
        
        # 평가
        accuracy = model.score(X_test, y_test)
        
        # 특징 중요도 (Random Forest인 경우)
        if hasattr(model, 'feature_importances_'):
            feature_importance = model.feature_importances_.tolist()
        else:
            feature_importance = []
        
        return {
            'model_trained': True,
            'algorithm': algorithm,
            'accuracy': float(accuracy),
            'classes': le.classes_.tolist(),
            'feature_importance': feature_importance,
            'training_samples': len(X_train),
            'test_samples': len(X_test)
        }
    else:
        # 예측 모드 (사전 학습된 모델 사용)
        # 실제로는 저장된 모델을 로드해야 함
        predictions = []
        probabilities = []
        
        # 예시: 간단한 규칙 기반 분류
        for item in features:
            # 실제로는 모델.predict() 사용
            pred_class = self._simple_classify(item)
            predictions.append(pred_class)
            probabilities.append({'class': pred_class, 'confidence': 0.85})
        
        return {
            'predictions': predictions,
            'probabilities': probabilities,
            'samples_classified': len(predictions)
        }

def _simple_classify(self, item: Dict) -> str:
    '''간단한 규칙 기반 분류 (예시)'''
    # 실제로는 학습된 모델 사용
    return 'class_a'
""",
    priority=8
)

# ============================================================================
# CLUSTERING PATTERN - 클러스터링
# ============================================================================

CLUSTERING_PATTERN = BusinessPattern(
    id="analytics_clustering",
    name="클러스터링 패턴",
    name_en="Clustering Pattern",
    category=PatternCategory.AGGREGATION,
    description="유사한 데이터를 그룹으로 묶는 패턴",
    trigger_keywords=[
        "클러스터", "cluster", "그룹화", "군집", "묶기",
        "grouping", "segmentation", "분할"
    ],
    slots=[
        PatternSlot(
            name="n_clusters",
            type="int",
            required=False,
            default=3,
            description="클러스터 개수"
        ),
        PatternSlot(
            name="algorithm",
            type="str",
            required=False,
            default="kmeans",
            description="클러스터링 알고리즘"
        )
    ],
    code_template="""
async def cluster_data(self, data: List[Dict], n_clusters: int = 3,
                      algorithm: str = 'kmeans'):
    '''데이터 클러스터링'''
    from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
    from sklearn.preprocessing import StandardScaler
    import numpy as np
    
    # 데이터 준비
    X = []
    for item in data:
        X.append(list(item.values()))
    X = np.array(X)
    
    # 정규화
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # 클러스터링
    if algorithm == 'kmeans':
        model = KMeans(n_clusters=n_clusters, random_state=42)
        labels = model.fit_predict(X_scaled)
        centers = scaler.inverse_transform(model.cluster_centers_)
        
    elif algorithm == 'dbscan':
        model = DBSCAN(eps=0.5, min_samples=5)
        labels = model.fit_predict(X_scaled)
        n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
        centers = []
        
    elif algorithm == 'hierarchical':
        model = AgglomerativeClustering(n_clusters=n_clusters)
        labels = model.fit_predict(X_scaled)
        centers = []
    
    # 클러스터별 통계
    clusters = {}
    for i in range(n_clusters):
        cluster_indices = np.where(labels == i)[0]
        cluster_data = X[cluster_indices]
        
        clusters[f'cluster_{i}'] = {
            'size': len(cluster_indices),
            'percentage': len(cluster_indices) / len(data) * 100,
            'mean': cluster_data.mean(axis=0).tolist() if len(cluster_data) > 0 else [],
            'std': cluster_data.std(axis=0).tolist() if len(cluster_data) > 0 else [],
            'members': cluster_indices.tolist()
        }
    
    # Silhouette score (클러스터링 품질)
    from sklearn.metrics import silhouette_score
    if n_clusters > 1 and n_clusters < len(data):
        score = silhouette_score(X_scaled, labels)
    else:
        score = 0
    
    return {
        'algorithm': algorithm,
        'n_clusters': n_clusters,
        'clusters': clusters,
        'silhouette_score': float(score),
        'labels': labels.tolist(),
        'total_samples': len(data)
    }
""",
    priority=8
)

# ============================================================================
# CORRELATION ANALYSIS - 상관 분석
# ============================================================================

CORRELATION_ANALYSIS_PATTERN = BusinessPattern(
    id="analytics_correlation",
    name="상관 분석 패턴",
    name_en="Correlation Analysis Pattern",
    category=PatternCategory.AGGREGATION,
    description="변수 간의 상관관계를 분석하는 패턴",
    trigger_keywords=[
        "상관", "correlation", "관계", "연관", "relationship",
        "연관성", "상관관계", "관련"
    ],
    slots=[
        PatternSlot(
            name="method",
            type="str",
            required=False,
            default="pearson",
            description="상관 계수 방법 (pearson/spearman/kendall)"
        )
    ],
    code_template="""
async def analyze_correlation(self, data: Dict[str, List[float]], 
                             method: str = 'pearson'):
    '''상관관계 분석'''
    import pandas as pd
    import numpy as np
    from scipy import stats
    
    # 데이터프레임 생성
    df = pd.DataFrame(data)
    
    # 상관 계수 계산
    if method == 'pearson':
        correlation_matrix = df.corr(method='pearson')
    elif method == 'spearman':
        correlation_matrix = df.corr(method='spearman')
    elif method == 'kendall':
        correlation_matrix = df.corr(method='kendall')
    else:
        correlation_matrix = df.corr()
    
    # 상관관계 해석
    strong_correlations = []
    moderate_correlations = []
    weak_correlations = []
    
    for i in range(len(correlation_matrix.columns)):
        for j in range(i+1, len(correlation_matrix.columns)):
            var1 = correlation_matrix.columns[i]
            var2 = correlation_matrix.columns[j]
            corr_value = correlation_matrix.iloc[i, j]
            
            if abs(corr_value) >= 0.7:
                strong_correlations.append({
                    'variable1': var1,
                    'variable2': var2,
                    'correlation': float(corr_value),
                    'strength': 'strong'
                })
            elif abs(corr_value) >= 0.4:
                moderate_correlations.append({
                    'variable1': var1,
                    'variable2': var2,
                    'correlation': float(corr_value),
                    'strength': 'moderate'
                })
            elif abs(corr_value) >= 0.2:
                weak_correlations.append({
                    'variable1': var1,
                    'variable2': var2,
                    'correlation': float(corr_value),
                    'strength': 'weak'
                })
    
    # P-값 계산 (유의성 검정)
    p_values = {}
    for col1 in df.columns:
        for col2 in df.columns:
            if col1 != col2:
                if method == 'pearson':
                    _, p_value = stats.pearsonr(df[col1], df[col2])
                elif method == 'spearman':
                    _, p_value = stats.spearmanr(df[col1], df[col2])
                else:
                    _, p_value = stats.kendalltau(df[col1], df[col2])
                
                p_values[f"{col1}_vs_{col2}"] = float(p_value)
    
    return {
        'method': method,
        'correlation_matrix': correlation_matrix.to_dict(),
        'strong_correlations': strong_correlations,
        'moderate_correlations': moderate_correlations,
        'weak_correlations': weak_correlations,
        'p_values': p_values,
        'variables_analyzed': len(df.columns),
        'samples': len(df)
    }
""",
    priority=7
)

# ============================================================================
# REGRESSION PATTERN - 회귀 분석
# ============================================================================

REGRESSION_PATTERN = BusinessPattern(
    id="analytics_regression",
    name="회귀 분석 패턴",
    name_en="Regression Pattern",
    category=PatternCategory.AGGREGATION,
    description="종속 변수와 독립 변수 간의 관계를 모델링하는 패턴",
    trigger_keywords=[
        "회귀", "regression", "선형", "linear", "다항",
        "polynomial", "예측 모델"
    ],
    slots=[
        PatternSlot(
            name="regression_type",
            type="str",
            required=False,
            default="linear",
            description="회귀 타입 (linear/polynomial/ridge/lasso)"
        )
    ],
    code_template="""
async def perform_regression(self, X: List[List[float]], y: List[float],
                            regression_type: str = 'linear'):
    '''회귀 분석 수행'''
    from sklearn.linear_model import LinearRegression, Ridge, Lasso
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    import numpy as np
    
    X = np.array(X)
    y = np.array(y)
    
    # 데이터 분할
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # 모델 선택 및 학습
    if regression_type == 'linear':
        model = LinearRegression()
        model.fit(X_train, y_train)
        
    elif regression_type == 'polynomial':
        poly = PolynomialFeatures(degree=2)
        X_train_poly = poly.fit_transform(X_train)
        X_test_poly = poly.transform(X_test)
        
        model = LinearRegression()
        model.fit(X_train_poly, y_train)
        X_test = X_test_poly
        
    elif regression_type == 'ridge':
        model = Ridge(alpha=1.0)
        model.fit(X_train, y_train)
        
    elif regression_type == 'lasso':
        model = Lasso(alpha=1.0)
        model.fit(X_train, y_train)
    
    # 예측
    y_pred_train = model.predict(X_train if regression_type != 'polynomial' else X_train_poly)
    y_pred_test = model.predict(X_test)
    
    # 성능 메트릭
    train_r2 = r2_score(y_train, y_pred_train)
    test_r2 = r2_score(y_test, y_pred_test)
    mse = mean_squared_error(y_test, y_pred_test)
    mae = mean_absolute_error(y_test, y_pred_test)
    rmse = np.sqrt(mse)
    
    # 계수 및 절편
    coefficients = model.coef_.tolist() if hasattr(model, 'coef_') else []
    intercept = float(model.intercept_) if hasattr(model, 'intercept_') else 0
    
    # 잔차 분석
    residuals = y_test - y_pred_test
    
    return {
        'regression_type': regression_type,
        'coefficients': coefficients,
        'intercept': intercept,
        'metrics': {
            'train_r2': float(train_r2),
            'test_r2': float(test_r2),
            'mse': float(mse),
            'mae': float(mae),
            'rmse': float(rmse)
        },
        'residuals': {
            'mean': float(np.mean(residuals)),
            'std': float(np.std(residuals)),
            'min': float(np.min(residuals)),
            'max': float(np.max(residuals))
        },
        'training_samples': len(X_train),
        'test_samples': len(X_test)
    }
""",
    priority=7
)

# ============================================================================
# TIME SERIES ANALYSIS - 시계열 분석
# ============================================================================

TIME_SERIES_PATTERN = BusinessPattern(
    id="analytics_time_series",
    name="시계열 분석 패턴",
    name_en="Time Series Analysis Pattern",
    category=PatternCategory.AGGREGATION,
    description="시계열 데이터를 분석하고 예측하는 패턴",
    trigger_keywords=[
        "시계열", "time series", "시간", "temporal", "forecast",
        "arima", "prophet", "시간대별"
    ],
    slots=[
        PatternSlot(
            name="frequency",
            type="str",
            required=False,
            default="D",
            description="데이터 주기 (D: daily, W: weekly, M: monthly)"
        ),
        PatternSlot(
            name="periods",
            type="int",
            required=False,
            default=30,
            description="예측 기간"
        )
    ],
    code_template="""
async def analyze_time_series(self, dates: List[str], values: List[float],
                             frequency: str = 'D', periods: int = 30):
    '''시계열 데이터 분석 및 예측'''
    import pandas as pd
    import numpy as np
    from statsmodels.tsa.seasonal import seasonal_decompose
    from statsmodels.tsa.stattools import adfuller
    
    # 시계열 데이터 생성
    df = pd.DataFrame({
        'date': pd.to_datetime(dates),
        'value': values
    })
    df.set_index('date', inplace=True)
    df = df.asfreq(frequency)
    
    # 기본 통계
    stats = {
        'mean': float(df['value'].mean()),
        'std': float(df['value'].std()),
        'min': float(df['value'].min()),
        'max': float(df['value'].max()),
        'trend': 'increasing' if df['value'].iloc[-1] > df['value'].iloc[0] else 'decreasing'
    }
    
    # 정상성 검정 (ADF Test)
    adf_result = adfuller(df['value'].dropna())
    is_stationary = adf_result[1] < 0.05
    
    # 계절성 분해 (충분한 데이터가 있는 경우)
    if len(df) > 2 * 12:  # 최소 2년 데이터
        decomposition = seasonal_decompose(df['value'], model='additive', period=12)
        seasonal_component = decomposition.seasonal.tolist()
        trend_component = decomposition.trend.tolist()
    else:
        seasonal_component = []
        trend_component = []
    
    # ARIMA 예측
    try:
        from statsmodels.tsa.arima.model import ARIMA
        
        # 모델 fitting
        model = ARIMA(df['value'], order=(1, 1, 1))
        model_fit = model.fit()
        
        # 예측
        forecast = model_fit.forecast(steps=periods)
        forecast_values = forecast.tolist()
        
        # AIC, BIC
        aic = model_fit.aic
        bic = model_fit.bic
        
    except Exception as e:
        self.logger.warning(f"ARIMA failed: {e}, using simple forecast")
        # 간단한 이동평균 예측
        ma = df['value'].rolling(window=7).mean().iloc[-1]
        forecast_values = [ma] * periods
        aic = None
        bic = None
    
    # 예측 날짜 생성
    last_date = df.index[-1]
    forecast_dates = pd.date_range(start=last_date + pd.Timedelta(days=1),
                                  periods=periods, freq=frequency)
    
    return {
        'statistics': stats,
        'is_stationary': bool(is_stationary),
        'adf_pvalue': float(adf_result[1]),
        'forecast': {
            'dates': forecast_dates.strftime('%Y-%m-%d').tolist(),
            'values': forecast_values,
            'periods': periods
        },
        'model_metrics': {
            'aic': float(aic) if aic else None,
            'bic': float(bic) if bic else None
        },
        'components': {
            'seasonal': seasonal_component,
            'trend': trend_component
        }
    }
""",
    priority=8
)

# ============================================================================
# SENTIMENT ANALYSIS - 감정 분석
# ============================================================================

SENTIMENT_ANALYSIS_PATTERN = BusinessPattern(
    id="analytics_sentiment",
    name="감정 분석 패턴",
    name_en="Sentiment Analysis Pattern",
    category=PatternCategory.VALIDATION,
    description="텍스트의 감정이나 의견을 분석하는 패턴",
    trigger_keywords=[
        "감정", "sentiment", "의견", "opinion", "긍정", "부정",
        "positive", "negative", "neutral", "감성"
    ],
    slots=[
        PatternSlot(
            name="language",
            type="str",
            required=False,
            default="en",
            description="분석 언어 (en/ko)"
        )
    ],
    code_template="""
async def analyze_sentiment(self, texts: List[str], language: str = 'en'):
    '''텍스트 감정 분석'''
    from textblob import TextBlob
    import re
    
    results = []
    overall_sentiment = {'positive': 0, 'negative': 0, 'neutral': 0}
    
    for text in texts:
        # 텍스트 전처리
        cleaned_text = re.sub(r'[^a-zA-Z0-9가-힣\\s]', '', text)
        
        if language == 'en':
            # 영어 감정 분석 (TextBlob)
            blob = TextBlob(cleaned_text)
            polarity = blob.sentiment.polarity
            subjectivity = blob.sentiment.subjectivity
            
            # 감정 분류
            if polarity > 0.1:
                sentiment = 'positive'
                overall_sentiment['positive'] += 1
            elif polarity < -0.1:
                sentiment = 'negative'
                overall_sentiment['negative'] += 1
            else:
                sentiment = 'neutral'
                overall_sentiment['neutral'] += 1
            
        else:
            # 한국어 또는 다른 언어 (간단한 키워드 기반)
            positive_words = ['좋', '훌륭', '최고', '만족', '행복']
            negative_words = ['나쁘', '최악', '불만', '실망', '화나']
            
            pos_count = sum(1 for word in positive_words if word in text)
            neg_count = sum(1 for word in negative_words if word in text)
            
            if pos_count > neg_count:
                sentiment = 'positive'
                polarity = 0.5
                overall_sentiment['positive'] += 1
            elif neg_count > pos_count:
                sentiment = 'negative'
                polarity = -0.5
                overall_sentiment['negative'] += 1
            else:
                sentiment = 'neutral'
                polarity = 0
                overall_sentiment['neutral'] += 1
            
            subjectivity = 0.5
        
        results.append({
            'text': text[:100],  # 처음 100자
            'sentiment': sentiment,
            'polarity': float(polarity),
            'subjectivity': float(subjectivity),
            'confidence': abs(polarity)
        })
    
    # 전체 통계
    total = len(texts)
    sentiment_distribution = {
        'positive': overall_sentiment['positive'] / total * 100,
        'negative': overall_sentiment['negative'] / total * 100,
        'neutral': overall_sentiment['neutral'] / total * 100
    }
    
    # 평균 극성
    avg_polarity = sum(r['polarity'] for r in results) / total if total > 0 else 0
    
    return {
        'total_analyzed': total,
        'results': results,
        'sentiment_distribution': sentiment_distribution,
        'average_polarity': float(avg_polarity),
        'overall_sentiment': 'positive' if avg_polarity > 0.1 else 'negative' if avg_polarity < -0.1 else 'neutral',
        'language': language
    }
""",
    priority=7
)

# ============================================================================
# A/B TESTING PATTERN - A/B 테스트
# ============================================================================

AB_TESTING_PATTERN = BusinessPattern(
    id="analytics_ab_test",
    name="A/B 테스트 패턴",
    name_en="A/B Testing Pattern",
    category=PatternCategory.VALIDATION,
    description="두 그룹 간의 성과를 비교 분석하는 패턴",
    trigger_keywords=[
        "ab test", "a/b", "비교", "실험", "test", "control",
        "treatment", "대조군", "실험군"
    ],
    slots=[
        PatternSlot(
            name="confidence_level",
            type="float",
            required=False,
            default=0.95,
            description="신뢰수준"
        )
    ],
    code_template="""
async def perform_ab_test(self, control_data: List[float], treatment_data: List[float],
                         confidence_level: float = 0.95):
    '''A/B 테스트 수행'''
    from scipy import stats
    import numpy as np
    
    # 기본 통계
    control_mean = np.mean(control_data)
    treatment_mean = np.mean(treatment_data)
    control_std = np.std(control_data)
    treatment_std = np.std(treatment_data)
    
    # T-test
    t_stat, p_value = stats.ttest_ind(control_data, treatment_data)
    
    # 효과 크기 (Cohen's d)
    pooled_std = np.sqrt(((len(control_data) - 1) * control_std ** 2 + 
                          (len(treatment_data) - 1) * treatment_std ** 2) /
                         (len(control_data) + len(treatment_data) - 2))
    
    cohens_d = (treatment_mean - control_mean) / pooled_std if pooled_std != 0 else 0
    
    # 신뢰구간
    confidence_interval = stats.t.interval(
        confidence_level,
        len(treatment_data) - 1,
        loc=treatment_mean - control_mean,
        scale=pooled_std / np.sqrt(len(treatment_data))
    )
    
    # 통계적 유의성 판단
    is_significant = p_value < (1 - confidence_level)
    
    # 개선율
    improvement = ((treatment_mean - control_mean) / control_mean * 100) if control_mean != 0 else 0
    
    # 통계적 검정력 (Statistical Power)
    # 간단한 추정 (실제로는 더 복잡한 계산 필요)
    effect_size = abs(cohens_d)
    if effect_size < 0.2:
        power = 0.2
    elif effect_size < 0.5:
        power = 0.5
    elif effect_size < 0.8:
        power = 0.7
    else:
        power = 0.9
    
    return {
        'control': {
            'mean': float(control_mean),
            'std': float(control_std),
            'sample_size': len(control_data)
        },
        'treatment': {
            'mean': float(treatment_mean),
            'std': float(treatment_std),
            'sample_size': len(treatment_data)
        },
        'test_results': {
            't_statistic': float(t_stat),
            'p_value': float(p_value),
            'is_significant': is_significant,
            'confidence_level': confidence_level
        },
        'effect_size': {
            'cohens_d': float(cohens_d),
            'interpretation': 'small' if abs(cohens_d) < 0.5 else 'medium' if abs(cohens_d) < 0.8 else 'large'
        },
        'confidence_interval': {
            'lower': float(confidence_interval[0]),
            'upper': float(confidence_interval[1])
        },
        'improvement': float(improvement),
        'statistical_power': float(power),
        'recommendation': 'adopt treatment' if is_significant and improvement > 0 else 'keep control'
    }
""",
    priority=6
)

# 패턴 등록
register_pattern(TREND_ANALYSIS_PATTERN)
register_pattern(ANOMALY_DETECTION_PATTERN)
register_pattern(PREDICTION_PATTERN)
register_pattern(CLASSIFICATION_PATTERN)
register_pattern(CLUSTERING_PATTERN)
register_pattern(CORRELATION_ANALYSIS_PATTERN)
register_pattern(REGRESSION_PATTERN)
register_pattern(TIME_SERIES_PATTERN)
register_pattern(SENTIMENT_ANALYSIS_PATTERN)
register_pattern(AB_TESTING_PATTERN)