"""
Data Patterns - 데이터 변환/집계 관련 비즈니스 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# Pattern 1: 데이터 집계
DATA_AGGREGATION = BusinessPattern(
    id="data_aggregation",
    name="데이터 집계",
    name_en="Data Aggregation",
    category=PatternCategory.AGGREGATION,
    description="데이터를 그룹화하고 집계",
    trigger_keywords=["합계", "평균", "최대", "최소", "집계", "통계", "sum", "average", "데이터"],
    slots=[
        PatternSlot(
            name="group_by",
            type="str",
            required=True,
            examples={
                "카테고리": "category",
                "날짜": "date",
                "지역": "region",
                "부서": "department"
            },
            description="그룹화 기준 필드"
        ),
        PatternSlot(
            name="aggregate_function",
            type="str",
            required=True,
            examples={
                "합계": "sum",
                "평균": "avg",
                "최대": "max",
                "최소": "min",
                "개수": "count"
            },
            description="집계 함수"
        ),
        PatternSlot(
            name="value_field",
            type="str",
            required=True,
            default="value",
            description="집계할 값 필드"
        )
    ],
    code_template='''
# 데이터 집계
from collections import defaultdict

group_by = '{group_by}'
aggregate_function = '{aggregate_function}'
value_field = '{value_field}'

# 그룹별로 데이터 수집
groups = defaultdict(list)
for item in items:
    key = item.get(group_by, 'unknown')
    value = item.get(value_field, 0)
    groups[key].append(value)

# 집계 수행
aggregated_results = []
for key, values in groups.items():
    if aggregate_function == 'sum':
        result_value = sum(values)
    elif aggregate_function == 'avg':
        result_value = sum(values) / len(values) if values else 0
    elif aggregate_function == 'max':
        result_value = max(values) if values else 0
    elif aggregate_function == 'min':
        result_value = min(values) if values else 0
    else:  # count
        result_value = len(values)
    
    aggregated_results.append({{
        group_by: key,
        f'{{aggregate_function}}_{{value_field}}': result_value
    }})

logger.info(f"Aggregated {{len(aggregated_results)}} groups by {{group_by}}")
result = aggregated_results
''',
    compatibility=["analytics", "reporting", "dashboard"],
    priority=9,
    test_cases=[
        {
            "query": "카테고리별 매출 합계",
            "expected_slots": {
                "group_by": "category",
                "aggregate_function": "sum",
                "value_field": "sales"
            }
        }
    ]
)

# Pattern 2: 데이터 변환
DATA_TRANSFORMATION = BusinessPattern(
    id="data_transformation",
    name="데이터 변환",
    name_en="Data Transformation",
    category=PatternCategory.TRANSFORMATION,
    description="데이터 형식이나 구조 변환",
    trigger_keywords=["변환", "변경", "포맷", "형식", "convert", "transform"],
    slots=[
        PatternSlot(
            name="transform_type",
            type="str",
            required=True,
            examples={
                "날짜": "date",
                "통화": "currency",
                "단위": "unit",
                "형식": "format"
            },
            description="변환 타입"
        ),
        PatternSlot(
            name="source_format",
            type="str",
            required=False,
            default="auto",
            description="원본 형식"
        ),
        PatternSlot(
            name="target_format",
            type="str",
            required=True,
            description="대상 형식"
        )
    ],
    code_template='''
# 데이터 변환
from datetime import datetime

transform_type = '{transform_type}'
source_format = '{source_format}'
target_format = '{target_format}'

def transform_value(value, transform_type):
    try:
        if transform_type == 'date':
            # 날짜 변환
            if source_format == 'auto':
                # 자동 감지 로직
                dt = datetime.fromisoformat(str(value))
            else:
                dt = datetime.strptime(str(value), source_format)
            
            return dt.strftime(target_format)
            
        elif transform_type == 'currency':
            # 통화 변환 (예시: USD to KRW)
            exchange_rate = 1300  # 실제로는 API에서 가져와야 함
            return float(value) * exchange_rate
            
        elif transform_type == 'unit':
            # 단위 변환 (예시: kg to g)
            conversion_factor = 1000
            return float(value) * conversion_factor
            
        else:  # format
            # 문자열 포맷 변환
            return target_format.format(value)
            
    except Exception as e:
        logger.warning(f"Transform failed: {{e}}")
        return value

# 각 항목에 변환 적용
for item in items:
    for field, value in item.items():
        if should_transform(field, transform_type):
            item[f'{{field}}_transformed'] = transform_value(value, transform_type)

logger.info(f"Data transformation completed: {{transform_type}}")
''',
    compatibility=["data_processor", "etl", "analytics"],
    priority=7
)

# Pattern 3: 데이터 정규화
DATA_NORMALIZATION = BusinessPattern(
    id="data_normalization",
    name="데이터 정규화",
    name_en="Data Normalization",
    category=PatternCategory.TRANSFORMATION,
    description="데이터를 표준 범위로 정규화",
    trigger_keywords=["정규화", "표준화", "normalize", "스케일"],
    slots=[
        PatternSlot(
            name="normalization_method",
            type="str",
            required=True,
            examples={
                "최소최대": "min_max",
                "표준": "z_score",
                "백분위": "percentile"
            },
            description="정규화 방법"
        ),
        PatternSlot(
            name="target_range",
            type="dict",
            required=False,
            default={"min": 0, "max": 1},
            description="목표 범위"
        ),
        PatternSlot(
            name="fields",
            type="list",
            required=True,
            default=["value"],
            description="정규화할 필드들"
        )
    ],
    code_template='''
# 데이터 정규화
import statistics

normalization_method = '{normalization_method}'
target_range = {target_range}
fields_to_normalize = {fields}

def normalize_min_max(values, target_min, target_max):
    min_val = min(values)
    max_val = max(values)
    range_val = max_val - min_val
    
    if range_val == 0:
        return [target_min] * len(values)
    
    return [(v - min_val) / range_val * (target_max - target_min) + target_min for v in values]

def normalize_z_score(values):
    mean = statistics.mean(values)
    stdev = statistics.stdev(values) if len(values) > 1 else 1
    
    if stdev == 0:
        return [0] * len(values)
    
    return [(v - mean) / stdev for v in values]

# 각 필드별로 정규화
for field in fields_to_normalize:
    values = [item.get(field, 0) for item in items]
    
    if normalization_method == 'min_max':
        normalized = normalize_min_max(values, target_range['min'], target_range['max'])
    elif normalization_method == 'z_score':
        normalized = normalize_z_score(values)
    else:  # percentile
        sorted_values = sorted(values)
        normalized = [sorted_values.index(v) / len(values) for v in values]
    
    # 정규화된 값 적용
    for i, item in enumerate(items):
        item[f'{{field}}_normalized'] = normalized[i]

logger.info(f"Normalization completed: {{normalization_method}} on {{fields_to_normalize}}")
''',
    compatibility=["ml_preprocessing", "analytics", "data_science"],
    priority=6
)

# Pattern 4: 데이터 검증
DATA_VALIDATION = BusinessPattern(
    id="data_validation",
    name="데이터 검증",
    name_en="Data Validation",
    category=PatternCategory.VALIDATION,
    description="데이터 유효성 검증 및 정제",
    trigger_keywords=["검증", "유효성", "검사", "확인", "validate", "check"],
    slots=[
        PatternSlot(
            name="validation_rules",
            type="list",
            required=True,
            default=[
                {"field": "email", "rule": "email"},
                {"field": "phone", "rule": "phone"},
                {"field": "age", "rule": "range", "min": 0, "max": 120}
            ],
            description="검증 규칙들"
        ),
        PatternSlot(
            name="action_on_invalid",
            type="str",
            required=False,
            default="remove",
            examples={
                "제거": "remove",
                "표시": "mark",
                "수정": "fix"
            },
            description="유효하지 않은 데이터 처리 방법"
        )
    ],
    code_template='''
# 데이터 검증
import re

validation_rules = {validation_rules}
action_on_invalid = '{action_on_invalid}'

def validate_email(value):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{{2,}}$'
    return re.match(pattern, str(value)) is not None

def validate_phone(value):
    pattern = r'^[0-9]{{10,11}}$'
    return re.match(pattern, str(value).replace('-', '')) is not None

def validate_range(value, min_val, max_val):
    try:
        num_val = float(value)
        return min_val <= num_val <= max_val
    except:
        return False

# 각 항목 검증
valid_items = []
invalid_items = []

for item in items:
    is_valid = True
    validation_errors = []
    
    for rule in validation_rules:
        field = rule['field']
        rule_type = rule['rule']
        value = item.get(field)
        
        if value is None:
            is_valid = False
            validation_errors.append(f"{{field}} is missing")
            continue
        
        if rule_type == 'email':
            if not validate_email(value):
                is_valid = False
                validation_errors.append(f"{{field}} is not valid email")
        elif rule_type == 'phone':
            if not validate_phone(value):
                is_valid = False
                validation_errors.append(f"{{field}} is not valid phone")
        elif rule_type == 'range':
            if not validate_range(value, rule.get('min', 0), rule.get('max', 999999)):
                is_valid = False
                validation_errors.append(f"{{field}} is out of range")
    
    if is_valid:
        valid_items.append(item)
    else:
        if action_on_invalid == 'mark':
            item['validation_errors'] = validation_errors
            item['is_valid'] = False
            valid_items.append(item)
        elif action_on_invalid == 'fix':
            # 간단한 수정 시도 (예: 공백 제거, 형식 정리)
            for field in ['email', 'phone']:
                if field in item:
                    item[field] = str(item[field]).strip().lower()
            valid_items.append(item)
        else:  # remove
            invalid_items.append(item)

logger.info(f"Validation completed: {{len(valid_items)}} valid, {{len(invalid_items)}} invalid")
items = valid_items
''',
    compatibility=["data_processor", "form_handler", "api_gateway"],
    priority=8
)

# Pattern 5: 데이터 매핑
DATA_MAPPING = BusinessPattern(
    id="data_mapping",
    name="데이터 매핑",
    name_en="Data Mapping",
    category=PatternCategory.TRANSFORMATION,
    description="필드명이나 값을 다른 형식으로 매핑",
    trigger_keywords=["매핑", "맵핑", "대응", "연결", "mapping", "map"],
    slots=[
        PatternSlot(
            name="mapping_type",
            type="str",
            required=True,
            examples={
                "필드": "field",
                "값": "value",
                "코드": "code"
            },
            description="매핑 타입"
        ),
        PatternSlot(
            name="mapping_dict",
            type="dict",
            required=True,
            default={
                "old_name": "new_name",
                "source": "target"
            },
            description="매핑 딕셔너리"
        )
    ],
    code_template='''
# 데이터 매핑
mapping_type = '{mapping_type}'
mapping_dict = {mapping_dict}

if mapping_type == 'field':
    # 필드명 매핑
    for item in items:
        new_item = {{}}
        for old_key, value in item.items():
            new_key = mapping_dict.get(old_key, old_key)
            new_item[new_key] = value
        item.clear()
        item.update(new_item)
        
elif mapping_type == 'value':
    # 값 매핑
    for item in items:
        for field, value in item.items():
            if value in mapping_dict:
                item[field] = mapping_dict[value]
                
elif mapping_type == 'code':
    # 코드 매핑 (예: 국가코드, 통화코드)
    for item in items:
        for field in ['country', 'currency', 'status']:
            if field in item and item[field] in mapping_dict:
                item[f'{{field}}_mapped'] = mapping_dict[item[field]]

logger.info(f"Data mapping completed: {{mapping_type}}")
''',
    compatibility=["etl", "api_gateway", "data_processor"],
    priority=5
)

# Pattern 6: 데이터 샘플링
DATA_SAMPLING = BusinessPattern(
    id="data_sampling",
    name="데이터 샘플링",
    name_en="Data Sampling",
    category=PatternCategory.FILTERING,
    description="데이터에서 샘플 추출",
    trigger_keywords=["샘플", "표본", "추출", "sample", "무작위"],
    slots=[
        PatternSlot(
            name="sample_size",
            type="int",
            required=True,
            extraction_regex=r"(\d+)",
            description="샘플 크기"
        ),
        PatternSlot(
            name="sampling_method",
            type="str",
            required=False,
            default="random",
            examples={
                "무작위": "random",
                "체계적": "systematic",
                "층화": "stratified"
            },
            description="샘플링 방법"
        )
    ],
    code_template='''
# 데이터 샘플링
import random

sample_size = {sample_size}
sampling_method = '{sampling_method}'

if sampling_method == 'random':
    # 무작위 샘플링
    sample_size = min(sample_size, len(items))
    sampled_items = random.sample(items, sample_size)
    
elif sampling_method == 'systematic':
    # 체계적 샘플링 (일정 간격)
    step = max(1, len(items) // sample_size)
    sampled_items = items[::step][:sample_size]
    
elif sampling_method == 'stratified':
    # 층화 샘플링 (카테고리별 비율 유지)
    categories = {{}}
    for item in items:
        cat = item.get('category', 'default')
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(item)
    
    sampled_items = []
    for cat, cat_items in categories.items():
        cat_sample_size = max(1, sample_size * len(cat_items) // len(items))
        cat_sample_size = min(cat_sample_size, len(cat_items))
        sampled_items.extend(random.sample(cat_items, cat_sample_size))

else:
    sampled_items = items[:sample_size]

logger.info(f"Sampled {{len(sampled_items)}} items using {{sampling_method}} method")
items = sampled_items
''',
    compatibility=["analytics", "ml_training", "testing"],
    priority=5
)

# Pattern 7: 데이터 순위
DATA_RANKING = BusinessPattern(
    id="data_ranking",
    name="데이터 순위",
    name_en="Data Ranking",
    category=PatternCategory.AGGREGATION,
    description="데이터에 순위 부여",
    trigger_keywords=["순위", "랭킹", "순서", "top", "rank", "best"],
    slots=[
        PatternSlot(
            name="rank_by",
            type="str",
            required=True,
            examples={
                "점수": "score",
                "매출": "sales",
                "조회수": "views",
                "평점": "rating"
            },
            description="순위 기준 필드"
        ),
        PatternSlot(
            name="rank_order",
            type="str",
            required=False,
            default="desc",
            examples={
                "높은순": "desc",
                "낮은순": "asc"
            },
            description="순위 정렬 방향"
        ),
        PatternSlot(
            name="top_n",
            type="int",
            required=False,
            default=10,
            extraction_regex=r"(\d+)",
            description="상위 N개 선택"
        )
    ],
    code_template='''
# 데이터 순위 부여
rank_by = '{rank_by}'
rank_order = '{rank_order}'
top_n = {top_n}

# 정렬
reverse_order = (rank_order == 'desc')
sorted_items = sorted(items, key=lambda x: x.get(rank_by, 0), reverse=reverse_order)

# 순위 부여
for rank, item in enumerate(sorted_items, 1):
    item['rank'] = rank
    item['rank_score'] = item.get(rank_by, 0)

# Top N 선택
if top_n > 0:
    top_items = sorted_items[:top_n]
    logger.info(f"Selected top {{top_n}} items by {{rank_by}}")
    items = top_items
else:
    items = sorted_items

logger.info(f"Ranking completed by {{rank_by}} ({{rank_order}})")
''',
    compatibility=["leaderboard", "analytics", "recommendation"],
    priority=7
)

# Pattern 8: 데이터 중복 제거
DATA_DEDUPLICATION = BusinessPattern(
    id="data_deduplication",
    name="데이터 중복 제거",
    name_en="Data Deduplication",
    category=PatternCategory.FILTERING,
    description="중복 데이터 제거",
    trigger_keywords=["중복", "제거", "유니크", "unique", "distinct"],
    slots=[
        PatternSlot(
            name="dedupe_field",
            type="str",
            required=True,
            examples={
                "아이디": "id",
                "이메일": "email",
                "이름": "name"
            },
            description="중복 확인 필드"
        ),
        PatternSlot(
            name="keep_strategy",
            type="str",
            required=False,
            default="first",
            examples={
                "처음": "first",
                "마지막": "last",
                "최신": "newest"
            },
            description="중복시 유지 전략"
        )
    ],
    code_template='''
# 중복 제거
dedupe_field = '{dedupe_field}'
keep_strategy = '{keep_strategy}'

seen = set()
deduplicated_items = []

if keep_strategy == 'last':
    items = list(reversed(items))

for item in items:
    key = item.get(dedupe_field)
    if key and key not in seen:
        seen.add(key)
        deduplicated_items.append(item)

if keep_strategy == 'last':
    deduplicated_items = list(reversed(deduplicated_items))

original_count = len(items)
deduped_count = len(deduplicated_items)
removed_count = original_count - deduped_count

logger.info(f"Deduplication completed: removed {{removed_count}} duplicates by {{dedupe_field}}")
items = deduplicated_items
''',
    compatibility=["data_processor", "etl", "analytics"],
    priority=6
)

# 패턴 등록
register_pattern(DATA_AGGREGATION)
register_pattern(DATA_TRANSFORMATION)
register_pattern(DATA_NORMALIZATION)
register_pattern(DATA_VALIDATION)
register_pattern(DATA_MAPPING)
register_pattern(DATA_SAMPLING)
register_pattern(DATA_RANKING)
register_pattern(DATA_DEDUPLICATION)