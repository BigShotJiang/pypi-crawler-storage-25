"""
Automation Patterns - 자동화 관련 비즈니스 패턴
프로세스 자동화, 알림, 보고서 생성 등 자동화 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# REPORT GENERATION - 보고서 생성
# ============================================================================

REPORT_GENERATION_PATTERN = BusinessPattern(
    id="automation_report",
    name="보고서 생성 패턴",
    name_en="Report Generation Pattern",
    category=PatternCategory.AUTOMATION,
    description="데이터를 분석하여 보고서를 자동 생성하는 패턴",
    trigger_keywords=[
        "보고서", "report", "리포트", "문서", "document",
        "summary", "요약", "집계"
    ],
    slots=[
        PatternSlot(
            name="report_type",
            type="str",
            required=False,
            default="pdf",
            description="보고서 형식 (pdf/excel/html)"
        ),
        PatternSlot(
            name="period",
            type="str",
            required=False,
            default="monthly",
            description="보고 기간"
        )
    ],
    code_template="""
class ReportGenerator:
    def __init__(self, report_type: str = 'pdf'):
        self.report_type = report_type
        self.templates = {}
    
    async def generate_report(self, data: Dict, period: str = 'monthly') -> Dict:
        '''보고서 생성'''
        from datetime import datetime
        import pandas as pd
        
        # 보고서 메타데이터
        report_metadata = {
            'title': f'{period.capitalize()} Report',
            'generated_at': datetime.now().isoformat(),
            'period': period,
            'author': 'Automated System'
        }
        
        # 데이터 분석
        analysis = await self.analyze_data(data)
        
        # 섹션별 내용 생성
        sections = {
            'executive_summary': await self.create_executive_summary(analysis),
            'key_metrics': await self.create_key_metrics(analysis),
            'detailed_analysis': await self.create_detailed_analysis(data),
            'charts': await self.create_charts(data),
            'recommendations': await self.create_recommendations(analysis)
        }
        
        # 보고서 포맷팅
        if self.report_type == 'pdf':
            report_file = await self.generate_pdf(sections, report_metadata)
        elif self.report_type == 'excel':
            report_file = await self.generate_excel(sections, data)
        elif self.report_type == 'html':
            report_file = await self.generate_html(sections, report_metadata)
        else:
            report_file = await self.generate_markdown(sections)
        
        return {
            'status': 'success',
            'report_file': report_file,
            'metadata': report_metadata,
            'summary': sections['executive_summary']
        }
    
    async def create_executive_summary(self, analysis: Dict) -> str:
        '''요약 생성'''
        summary = f\"\"\"
        ## Executive Summary
        
        Period: {analysis.get('period', 'N/A')}
        Total Records: {analysis.get('total_records', 0)}
        
        ### Key Highlights
        - Overall performance: {analysis.get('performance', 'N/A')}
        - Growth rate: {analysis.get('growth_rate', 0):.1f}%
        - Major achievements: {', '.join(analysis.get('achievements', []))}
        
        ### Areas of Concern
        {self._format_concerns(analysis.get('concerns', []))}
        \"\"\"
        return summary
    
    async def create_charts(self, data: Dict) -> List[Dict]:
        '''차트 생성'''
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        charts = []
        
        # 시계열 차트
        if 'time_series' in data:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(data['time_series']['dates'], data['time_series']['values'])
            ax.set_title('Trend Over Time')
            
            chart_path = f'chart_trend_{datetime.now().timestamp()}.png'
            plt.savefig(chart_path)
            charts.append({'type': 'line', 'path': chart_path})
        
        # 막대 차트
        if 'categories' in data:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.bar(data['categories'].keys(), data['categories'].values())
            ax.set_title('Category Distribution')
            
            chart_path = f'chart_bar_{datetime.now().timestamp()}.png'
            plt.savefig(chart_path)
            charts.append({'type': 'bar', 'path': chart_path})
        
        return charts
    
    async def generate_pdf(self, sections: Dict, metadata: Dict) -> str:
        '''PDF 생성'''
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        
        filename = f"report_{metadata['period']}_{datetime.now().strftime('%Y%m%d')}.pdf"
        doc = SimpleDocTemplate(filename, pagesize=letter)
        
        story = []
        styles = getSampleStyleSheet()
        
        # 제목
        story.append(Paragraph(metadata['title'], styles['Title']))
        story.append(Spacer(1, 12))
        
        # 섹션별 내용 추가
        for section_name, content in sections.items():
            if isinstance(content, str):
                story.append(Paragraph(content, styles['BodyText']))
                story.append(Spacer(1, 12))
        
        doc.build(story)
        return filename
""",
    priority=9
)

# ============================================================================
# TASK SCHEDULER - 작업 스케줄러
# ============================================================================

TASK_SCHEDULER_PATTERN = BusinessPattern(
    id="automation_scheduler",
    name="작업 스케줄러 패턴",
    name_en="Task Scheduler Pattern",
    category=PatternCategory.AUTOMATION,
    description="작업을 예약하고 자동 실행하는 패턴",
    trigger_keywords=[
        "스케줄", "schedule", "예약", "자동실행", "cron",
        "timer", "periodic", "정기"
    ],
    slots=[
        PatternSlot(
            name="schedule_type",
            type="str",
            required=False,
            default="cron",
            description="스케줄 타입 (cron/interval/once)"
        )
    ],
    code_template="""
class TaskScheduler:
    def __init__(self):
        self.scheduled_tasks = {}
        self.running_tasks = {}
    
    async def schedule_task(self, task_id: str, task_func: callable, 
                           schedule: str, schedule_type: str = 'cron'):
        '''작업 스케줄링'''
        import asyncio
        from croniter import croniter
        from datetime import datetime, timedelta
        
        task_info = {
            'id': task_id,
            'function': task_func,
            'schedule': schedule,
            'type': schedule_type,
            'created_at': datetime.now(),
            'last_run': None,
            'next_run': None,
            'run_count': 0,
            'status': 'scheduled'
        }
        
        if schedule_type == 'cron':
            # Cron 표현식
            cron = croniter(schedule, datetime.now())
            task_info['next_run'] = cron.get_next(datetime)
            
        elif schedule_type == 'interval':
            # 간격 실행 (초 단위)
            interval_seconds = int(schedule)
            task_info['next_run'] = datetime.now() + timedelta(seconds=interval_seconds)
            
        elif schedule_type == 'once':
            # 한 번만 실행
            task_info['next_run'] = datetime.fromisoformat(schedule)
        
        self.scheduled_tasks[task_id] = task_info
        
        # 실행 루프 시작
        asyncio.create_task(self._run_scheduled_task(task_id))
        
        return {
            'task_id': task_id,
            'scheduled': True,
            'next_run': task_info['next_run'].isoformat()
        }
    
    async def _run_scheduled_task(self, task_id: str):
        '''스케줄된 작업 실행'''
        while task_id in self.scheduled_tasks:
            task = self.scheduled_tasks[task_id]
            
            # 실행 시간 확인
            now = datetime.now()
            if now >= task['next_run']:
                try:
                    # 작업 실행
                    self.running_tasks[task_id] = True
                    task['status'] = 'running'
                    task['last_run'] = now
                    
                    result = await task['function']()
                    
                    task['run_count'] += 1
                    task['status'] = 'scheduled'
                    
                    # 다음 실행 시간 계산
                    if task['type'] == 'cron':
                        cron = croniter(task['schedule'], now)
                        task['next_run'] = cron.get_next(datetime)
                    elif task['type'] == 'interval':
                        interval_seconds = int(task['schedule'])
                        task['next_run'] = now + timedelta(seconds=interval_seconds)
                    elif task['type'] == 'once':
                        # 한 번만 실행이므로 삭제
                        del self.scheduled_tasks[task_id]
                        break
                    
                    await self.log_execution(task_id, 'success', result)
                    
                except Exception as e:
                    task['status'] = 'error'
                    await self.log_execution(task_id, 'error', str(e))
                finally:
                    if task_id in self.running_tasks:
                        del self.running_tasks[task_id]
            
            # 대기
            await asyncio.sleep(1)
    
    async def cancel_task(self, task_id: str):
        '''작업 취소'''
        if task_id in self.scheduled_tasks:
            del self.scheduled_tasks[task_id]
            return {'cancelled': True, 'task_id': task_id}
        return {'cancelled': False, 'reason': 'Task not found'}
""",
    priority=8
)

# ============================================================================
# NOTIFICATION DISPATCHER - 알림 발송
# ============================================================================

NOTIFICATION_DISPATCHER_PATTERN = BusinessPattern(
    id="automation_notification",
    name="알림 발송 패턴",
    name_en="Notification Dispatcher Pattern",
    category=PatternCategory.NOTIFICATION,
    description="다양한 채널로 알림을 발송하는 패턴",
    trigger_keywords=[
        "알림", "notification", "notify", "alert", "push",
        "알람", "메시지", "전송"
    ],
    slots=[
        PatternSlot(
            name="channels",
            type="list",
            required=True,
            description="알림 채널 (email/sms/push/slack)"
        ),
        PatternSlot(
            name="priority",
            type="str",
            required=False,
            default="normal",
            description="우선순위"
        )
    ],
    code_template="""
class NotificationDispatcher:
    def __init__(self):
        self.channels = {
            'email': self.send_email_notification,
            'sms': self.send_sms_notification,
            'push': self.send_push_notification,
            'slack': self.send_slack_notification,
            'webhook': self.send_webhook_notification
        }
    
    async def send_notification(self, message: str, recipients: List[str],
                               channels: List[str], priority: str = 'normal'):
        '''알림 발송'''
        results = []
        
        # 우선순위별 처리
        if priority == 'urgent':
            # 긴급 알림은 모든 채널 동시 발송
            tasks = []
            for channel in channels:
                if channel in self.channels:
                    for recipient in recipients:
                        tasks.append(self.channels[channel](recipient, message))
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
        else:
            # 일반 알림은 순차 발송
            for channel in channels:
                if channel in self.channels:
                    for recipient in recipients:
                        try:
                            result = await self.channels[channel](recipient, message)
                            results.append(result)
                        except Exception as e:
                            results.append({'error': str(e)})
        
        # 발송 결과 집계
        successful = sum(1 for r in results if isinstance(r, dict) and r.get('sent'))
        failed = len(results) - successful
        
        return {
            'total_sent': len(results),
            'successful': successful,
            'failed': failed,
            'channels_used': channels,
            'priority': priority,
            'results': results
        }
    
    async def send_email_notification(self, recipient: str, message: str):
        '''이메일 알림'''
        # 이메일 발송 로직
        return {'sent': True, 'channel': 'email', 'recipient': recipient}
    
    async def send_slack_notification(self, channel: str, message: str):
        '''Slack 알림'''
        import aiohttp
        
        webhook_url = self.get_slack_webhook(channel)
        
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json={'text': message}) as response:
                return {
                    'sent': response.status == 200,
                    'channel': 'slack',
                    'slack_channel': channel
                }
    
    async def send_push_notification(self, device_token: str, message: str):
        '''푸시 알림'''
        # FCM/APNS 등 푸시 서비스 연동
        return {'sent': True, 'channel': 'push', 'device': device_token}
""",
    priority=8
)

# ============================================================================
# DATA PIPELINE - 데이터 파이프라인
# ============================================================================

DATA_PIPELINE_PATTERN = BusinessPattern(
    id="automation_data_pipeline",
    name="데이터 파이프라인 패턴",
    name_en="Data Pipeline Pattern",
    category=PatternCategory.AUTOMATION,
    description="데이터를 단계적으로 처리하는 파이프라인 패턴",
    trigger_keywords=[
        "파이프라인", "pipeline", "etl", "데이터처리", "변환",
        "extract", "transform", "load"
    ],
    slots=[
        PatternSlot(
            name="stages",
            type="list",
            required=True,
            description="파이프라인 단계"
        )
    ],
    code_template="""
class DataPipeline:
    def __init__(self, name: str):
        self.name = name
        self.stages = []
        self.metrics = {}
    
    def add_stage(self, name: str, processor: callable, error_handler: callable = None):
        '''파이프라인 단계 추가'''
        self.stages.append({
            'name': name,
            'processor': processor,
            'error_handler': error_handler or self.default_error_handler
        })
        return self
    
    async def execute(self, input_data: Any) -> Dict:
        '''파이프라인 실행'''
        from datetime import datetime
        
        start_time = datetime.now()
        current_data = input_data
        stage_results = []
        
        for i, stage in enumerate(self.stages, 1):
            stage_start = datetime.now()
            
            try:
                self.logger.info(f"Stage {i}/{len(self.stages)}: {stage['name']}")
                
                # 단계 실행
                result = await stage['processor'](current_data)
                
                # 결과 검증
                if result is None:
                    raise ValueError(f"Stage {stage['name']} returned None")
                
                current_data = result
                
                stage_results.append({
                    'stage': stage['name'],
                    'status': 'success',
                    'duration': (datetime.now() - stage_start).total_seconds(),
                    'records_processed': len(result) if hasattr(result, '__len__') else 1
                })
                
            except Exception as e:
                self.logger.error(f"Stage {stage['name']} failed: {e}")
                
                # 에러 핸들러 실행
                recovery_data = await stage['error_handler'](current_data, e)
                
                if recovery_data is None:
                    # 파이프라인 중단
                    return {
                        'status': 'failed',
                        'failed_at': stage['name'],
                        'error': str(e),
                        'stages_completed': i - 1,
                        'partial_results': stage_results
                    }
                
                current_data = recovery_data
                stage_results.append({
                    'stage': stage['name'],
                    'status': 'recovered',
                    'error': str(e)
                })
        
        # 파이프라인 완료
        total_duration = (datetime.now() - start_time).total_seconds()
        
        return {
            'status': 'success',
            'output': current_data,
            'stages_completed': len(self.stages),
            'total_duration': total_duration,
            'stage_results': stage_results,
            'metrics': self._calculate_metrics(stage_results)
        }
    
    def _calculate_metrics(self, stage_results: List[Dict]) -> Dict:
        '''메트릭 계산'''
        return {
            'total_stages': len(stage_results),
            'successful_stages': sum(1 for s in stage_results if s['status'] == 'success'),
            'average_stage_duration': sum(s.get('duration', 0) for s in stage_results) / len(stage_results),
            'total_records': sum(s.get('records_processed', 0) for s in stage_results)
        }
""",
    priority=8
)

# ============================================================================
# BACKUP AND RESTORE - 백업 및 복원
# ============================================================================

BACKUP_RESTORE_PATTERN = BusinessPattern(
    id="automation_backup",
    name="백업 및 복원 패턴",
    name_en="Backup and Restore Pattern",
    category=PatternCategory.AUTOMATION,
    description="데이터를 백업하고 복원하는 패턴",
    trigger_keywords=[
        "백업", "backup", "복원", "restore", "recovery",
        "snapshot", "archive", "보관"
    ],
    slots=[
        PatternSlot(
            name="backup_type",
            type="str",
            required=False,
            default="full",
            description="백업 타입 (full/incremental/differential)"
        ),
        PatternSlot(
            name="retention_days",
            type="int",
            required=False,
            default=30,
            description="보관 기간"
        )
    ],
    code_template="""
class BackupManager:
    def __init__(self, backup_type: str = 'full', retention_days: int = 30):
        self.backup_type = backup_type
        self.retention_days = retention_days
        self.backup_history = []
    
    async def create_backup(self, data_source: str, backup_name: str = None) -> Dict:
        '''백업 생성'''
        from datetime import datetime
        import shutil
        import tarfile
        
        backup_id = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        backup_name = backup_name or backup_id
        
        try:
            if self.backup_type == 'full':
                # 전체 백업
                backup_path = await self._full_backup(data_source, backup_name)
                
            elif self.backup_type == 'incremental':
                # 증분 백업
                last_backup = self._get_last_backup()
                backup_path = await self._incremental_backup(
                    data_source, backup_name, last_backup
                )
                
            elif self.backup_type == 'differential':
                # 차등 백업
                last_full_backup = self._get_last_full_backup()
                backup_path = await self._differential_backup(
                    data_source, backup_name, last_full_backup
                )
            
            # 메타데이터 저장
            backup_info = {
                'id': backup_id,
                'name': backup_name,
                'type': self.backup_type,
                'source': data_source,
                'path': backup_path,
                'size': self._get_file_size(backup_path),
                'created_at': datetime.now().isoformat(),
                'expires_at': (datetime.now() + timedelta(days=self.retention_days)).isoformat()
            }
            
            self.backup_history.append(backup_info)
            await self._save_backup_metadata(backup_info)
            
            return {
                'status': 'success',
                'backup_id': backup_id,
                'backup_path': backup_path,
                'size': backup_info['size'],
                'type': self.backup_type
            }
            
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    async def restore_backup(self, backup_id: str, target_path: str) -> Dict:
        '''백업 복원'''
        backup_info = self._find_backup(backup_id)
        
        if not backup_info:
            return {
                'status': 'failed',
                'error': 'Backup not found'
            }
        
        try:
            # 복원 실행
            if backup_info['type'] == 'full':
                await self._restore_full_backup(backup_info['path'], target_path)
            else:
                # 증분/차등 백업은 관련 백업도 복원
                await self._restore_with_dependencies(backup_info, target_path)
            
            return {
                'status': 'success',
                'restored_from': backup_id,
                'target_path': target_path,
                'backup_date': backup_info['created_at']
            }
            
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    async def cleanup_old_backups(self):
        '''오래된 백업 정리'''
        from datetime import datetime
        
        current_time = datetime.now()
        removed = []
        
        for backup in self.backup_history[:]:
            expires_at = datetime.fromisoformat(backup['expires_at'])
            
            if current_time > expires_at:
                # 백업 파일 삭제
                await self._delete_backup_file(backup['path'])
                self.backup_history.remove(backup)
                removed.append(backup['id'])
        
        return {
            'cleaned': len(removed),
            'removed_backups': removed
        }
""",
    priority=7
)

# ============================================================================
# LOG AGGREGATION - 로그 수집
# ============================================================================

LOG_AGGREGATION_PATTERN = BusinessPattern(
    id="automation_log_aggregation",
    name="로그 수집 패턴",
    name_en="Log Aggregation Pattern",
    category=PatternCategory.AUTOMATION,
    description="분산된 로그를 수집하고 중앙화하는 패턴",
    trigger_keywords=[
        "로그수집", "log aggregation", "centralized logging",
        "로그", "수집", "통합"
    ],
    slots=[
        PatternSlot(
            name="sources",
            type="list",
            required=True,
            description="로그 소스"
        ),
        PatternSlot(
            name="format",
            type="str",
            required=False,
            default="json",
            description="로그 형식"
        )
    ],
    code_template="""
class LogAggregator:
    def __init__(self, sources: List[str], format: str = 'json'):
        self.sources = sources
        self.format = format
        self.buffer = []
        self.processors = []
    
    async def collect_logs(self) -> Dict:
        '''로그 수집'''
        collected_logs = []
        
        for source in self.sources:
            try:
                logs = await self._collect_from_source(source)
                
                # 로그 파싱
                parsed_logs = await self._parse_logs(logs, source)
                
                # 로그 보강
                enriched_logs = await self._enrich_logs(parsed_logs, source)
                
                collected_logs.extend(enriched_logs)
                
            except Exception as e:
                self.logger.error(f"Failed to collect from {source}: {e}")
        
        # 로그 처리
        processed_logs = await self._process_logs(collected_logs)
        
        # 저장
        await self._store_logs(processed_logs)
        
        return {
            'total_collected': len(collected_logs),
            'sources_processed': len(self.sources),
            'timestamp': datetime.now().isoformat()
        }
    
    async def _parse_logs(self, raw_logs: str, source: str) -> List[Dict]:
        '''로그 파싱'''
        import json
        import re
        
        parsed = []
        
        if self.format == 'json':
            for line in raw_logs.split('\\n'):
                if line.strip():
                    try:
                        log_entry = json.loads(line)
                        parsed.append(log_entry)
                    except:
                        # JSON 파싱 실패시 텍스트로 처리
                        parsed.append({'message': line, 'source': source})
                        
        elif self.format == 'syslog':
            # Syslog 형식 파싱
            pattern = r'(\\w+\\s+\\d+\\s+\\d+:\\d+:\\d+)\\s+(\\S+)\\s+(\\S+)\\[(\\d+)\\]:\\s+(.*)'
            for line in raw_logs.split('\\n'):
                match = re.match(pattern, line)
                if match:
                    parsed.append({
                        'timestamp': match.group(1),
                        'host': match.group(2),
                        'program': match.group(3),
                        'pid': match.group(4),
                        'message': match.group(5),
                        'source': source
                    })
        
        return parsed
    
    async def search_logs(self, query: str, filters: Dict = None) -> List[Dict]:
        '''로그 검색'''
        results = []
        
        # 검색 조건 구성
        for log in self.buffer:
            if query.lower() in str(log).lower():
                if filters:
                    # 필터 적용
                    if self._match_filters(log, filters):
                        results.append(log)
                else:
                    results.append(log)
        
        return results
""",
    priority=7
)

# ============================================================================
# HEALTH CHECK - 상태 확인
# ============================================================================

HEALTH_CHECK_PATTERN = BusinessPattern(
    id="automation_health_check",
    name="상태 확인 패턴",
    name_en="Health Check Pattern",
    category=PatternCategory.MONITORING,
    description="시스템 상태를 확인하고 모니터링하는 패턴",
    trigger_keywords=[
        "헬스체크", "health check", "상태확인", "모니터링",
        "alive", "ping", "status"
    ],
    slots=[
        PatternSlot(
            name="check_interval",
            type="int",
            required=False,
            default=60,
            description="확인 간격(초)"
        )
    ],
    code_template="""
class HealthChecker:
    def __init__(self, check_interval: int = 60):
        self.check_interval = check_interval
        self.services = {}
        self.check_history = []
    
    def register_service(self, name: str, check_func: callable, critical: bool = False):
        '''서비스 등록'''
        self.services[name] = {
            'check_function': check_func,
            'critical': critical,
            'last_check': None,
            'status': 'unknown'
        }
    
    async def check_health(self) -> Dict:
        '''상태 확인'''
        results = {
            'overall': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'services': {}
        }
        
        for service_name, service in self.services.items():
            try:
                # 서비스 체크
                check_result = await service['check_function']()
                
                service['status'] = 'healthy' if check_result else 'unhealthy'
                service['last_check'] = datetime.now()
                
                results['services'][service_name] = {
                    'status': service['status'],
                    'critical': service['critical'],
                    'last_check': service['last_check'].isoformat()
                }
                
                # Critical 서비스가 unhealthy면 전체 상태도 unhealthy
                if service['critical'] and service['status'] == 'unhealthy':
                    results['overall'] = 'unhealthy'
                    
            except Exception as e:
                service['status'] = 'error'
                results['services'][service_name] = {
                    'status': 'error',
                    'error': str(e),
                    'critical': service['critical']
                }
                
                if service['critical']:
                    results['overall'] = 'unhealthy'
        
        # 이력 저장
        self.check_history.append(results)
        
        # 알림 발송 (unhealthy인 경우)
        if results['overall'] == 'unhealthy':
            await self.send_health_alert(results)
        
        return results
    
    async def get_health_metrics(self) -> Dict:
        '''상태 메트릭'''
        if not self.check_history:
            return {'error': 'No health check history'}
        
        # 최근 24시간 데이터
        recent_checks = self._get_recent_checks(hours=24)
        
        # 가용성 계산
        total_checks = len(recent_checks)
        healthy_checks = sum(1 for c in recent_checks if c['overall'] == 'healthy')
        
        availability = (healthy_checks / total_checks * 100) if total_checks > 0 else 0
        
        # 서비스별 가용성
        service_availability = {}
        for service_name in self.services:
            service_healthy = sum(
                1 for c in recent_checks 
                if c['services'].get(service_name, {}).get('status') == 'healthy'
            )
            service_availability[service_name] = (service_healthy / total_checks * 100) if total_checks > 0 else 0
        
        return {
            'availability': availability,
            'service_availability': service_availability,
            'total_checks': total_checks,
            'healthy_checks': healthy_checks,
            'period': '24h'
        }
""",
    priority=7
)

# ============================================================================
# MIGRATION PATTERN - 데이터 마이그레이션
# ============================================================================

MIGRATION_PATTERN = BusinessPattern(
    id="automation_migration",
    name="데이터 마이그레이션 패턴",
    name_en="Data Migration Pattern",
    category=PatternCategory.AUTOMATION,
    description="데이터를 다른 시스템으로 이전하는 패턴",
    trigger_keywords=[
        "마이그레이션", "migration", "이전", "이관", "transfer",
        "데이터이전", "migrate"
    ],
    slots=[
        PatternSlot(
            name="migration_type",
            type="str",
            required=False,
            default="full",
            description="마이그레이션 타입"
        )
    ],
    code_template="""
class DataMigrator:
    def __init__(self, source_config: Dict, target_config: Dict):
        self.source = source_config
        self.target = target_config
        self.migration_log = []
    
    async def migrate(self, migration_type: str = 'full') -> Dict:
        '''데이터 마이그레이션 실행'''
        start_time = datetime.now()
        
        # 1. 사전 검증
        validation = await self.pre_migration_validation()
        if not validation['valid']:
            return {
                'status': 'failed',
                'reason': 'Pre-migration validation failed',
                'errors': validation['errors']
            }
        
        # 2. 데이터 추출
        extracted_data = await self.extract_data(migration_type)
        
        # 3. 데이터 변환
        transformed_data = await self.transform_data(extracted_data)
        
        # 4. 데이터 로드
        load_result = await self.load_data(transformed_data)
        
        # 5. 사후 검증
        post_validation = await self.post_migration_validation()
        
        # 6. 롤백 포인트 생성
        rollback_point = await self.create_rollback_point()
        
        duration = (datetime.now() - start_time).total_seconds()
        
        return {
            'status': 'success' if load_result['success'] else 'failed',
            'records_migrated': load_result.get('records', 0),
            'duration': duration,
            'rollback_point': rollback_point,
            'validation': post_validation
        }
    
    async def extract_data(self, migration_type: str) -> List[Dict]:
        '''데이터 추출'''
        if migration_type == 'full':
            # 전체 데이터 추출
            query = "SELECT * FROM source_table"
        elif migration_type == 'incremental':
            # 증분 데이터만 추출
            last_sync = await self.get_last_sync_timestamp()
            query = f"SELECT * FROM source_table WHERE updated_at > '{last_sync}'"
        
        data = await self.execute_source_query(query)
        return data
    
    async def transform_data(self, data: List[Dict]) -> List[Dict]:
        '''데이터 변환'''
        transformed = []
        
        for record in data:
            # 필드 매핑
            new_record = self.map_fields(record)
            
            # 데이터 타입 변환
            new_record = self.convert_types(new_record)
            
            # 데이터 검증
            if self.validate_record(new_record):
                transformed.append(new_record)
        
        return transformed
""",
    priority=6
)

# ============================================================================
# PROCESS AUTOMATION - 프로세스 자동화
# ============================================================================

PROCESS_AUTOMATION_PATTERN = BusinessPattern(
    id="automation_process",
    name="프로세스 자동화 패턴",
    name_en="Process Automation Pattern",
    category=PatternCategory.AUTOMATION,
    description="비즈니스 프로세스를 자동화하는 패턴",
    trigger_keywords=[
        "프로세스", "process", "자동화", "automation", "rpa",
        "업무자동화", "workflow"
    ],
    slots=[
        PatternSlot(
            name="process_steps",
            type="list",
            required=True,
            description="프로세스 단계"
        )
    ],
    code_template="""
class ProcessAutomation:
    def __init__(self, process_name: str):
        self.process_name = process_name
        self.steps = []
        self.context = {}
    
    def add_step(self, step_name: str, action: callable, 
                 condition: callable = None, on_error: callable = None):
        '''프로세스 단계 추가'''
        self.steps.append({
            'name': step_name,
            'action': action,
            'condition': condition or (lambda ctx: True),
            'on_error': on_error or self.default_error_handler
        })
        return self
    
    async def execute(self, initial_context: Dict = None) -> Dict:
        '''프로세스 실행'''
        self.context = initial_context or {}
        results = []
        
        for i, step in enumerate(self.steps, 1):
            # 조건 확인
            if not step['condition'](self.context):
                results.append({
                    'step': step['name'],
                    'status': 'skipped',
                    'reason': 'Condition not met'
                })
                continue
            
            try:
                # 단계 실행
                step_result = await step['action'](self.context)
                
                # 컨텍스트 업데이트
                if isinstance(step_result, dict):
                    self.context.update(step_result)
                
                results.append({
                    'step': step['name'],
                    'status': 'completed',
                    'result': step_result
                })
                
            except Exception as e:
                # 에러 처리
                recovery = await step['on_error'](self.context, e)
                
                if not recovery:
                    return {
                        'status': 'failed',
                        'failed_at': step['name'],
                        'error': str(e),
                        'completed_steps': results
                    }
                
                results.append({
                    'step': step['name'],
                    'status': 'recovered',
                    'error': str(e)
                })
        
        return {
            'status': 'completed',
            'process': self.process_name,
            'steps_executed': len(results),
            'results': results,
            'final_context': self.context
        }
""",
    priority=6
)

# ============================================================================
# RESOURCE MONITORING - 리소스 모니터링
# ============================================================================

RESOURCE_MONITORING_PATTERN = BusinessPattern(
    id="automation_resource_monitor",
    name="리소스 모니터링 패턴",
    name_en="Resource Monitoring Pattern",
    category=PatternCategory.MONITORING,
    description="시스템 리소스를 모니터링하는 패턴",
    trigger_keywords=[
        "리소스", "resource", "cpu", "memory", "disk",
        "모니터링", "usage", "사용량"
    ],
    slots=[
        PatternSlot(
            name="metrics",
            type="list",
            required=True,
            description="모니터링할 메트릭"
        ),
        PatternSlot(
            name="alert_thresholds",
            type="dict",
            required=False,
            description="알림 임계값"
        )
    ],
    code_template="""
class ResourceMonitor:
    def __init__(self, metrics: List[str], alert_thresholds: Dict = None):
        self.metrics = metrics
        self.thresholds = alert_thresholds or {}
        self.history = []
    
    async def collect_metrics(self) -> Dict:
        '''리소스 메트릭 수집'''
        import psutil
        
        current_metrics = {
            'timestamp': datetime.now().isoformat(),
            'metrics': {}
        }
        
        if 'cpu' in self.metrics:
            current_metrics['metrics']['cpu'] = {
                'usage_percent': psutil.cpu_percent(interval=1),
                'core_count': psutil.cpu_count(),
                'frequency': psutil.cpu_freq().current if psutil.cpu_freq() else 0
            }
        
        if 'memory' in self.metrics:
            mem = psutil.virtual_memory()
            current_metrics['metrics']['memory'] = {
                'total': mem.total,
                'available': mem.available,
                'used': mem.used,
                'percent': mem.percent
            }
        
        if 'disk' in self.metrics:
            disk = psutil.disk_usage('/')
            current_metrics['metrics']['disk'] = {
                'total': disk.total,
                'used': disk.used,
                'free': disk.free,
                'percent': disk.percent
            }
        
        if 'network' in self.metrics:
            net = psutil.net_io_counters()
            current_metrics['metrics']['network'] = {
                'bytes_sent': net.bytes_sent,
                'bytes_recv': net.bytes_recv,
                'packets_sent': net.packets_sent,
                'packets_recv': net.packets_recv
            }
        
        # 임계값 확인
        alerts = await self.check_thresholds(current_metrics['metrics'])
        if alerts:
            current_metrics['alerts'] = alerts
            await self.send_resource_alerts(alerts)
        
        # 이력 저장
        self.history.append(current_metrics)
        
        return current_metrics
    
    async def check_thresholds(self, metrics: Dict) -> List[Dict]:
        '''임계값 확인'''
        alerts = []
        
        for metric_name, threshold in self.thresholds.items():
            if metric_name in metrics:
                value = metrics[metric_name].get('percent') or metrics[metric_name].get('usage_percent')
                
                if value and value > threshold:
                    alerts.append({
                        'metric': metric_name,
                        'value': value,
                        'threshold': threshold,
                        'severity': 'high' if value > threshold * 1.2 else 'medium'
                    })
        
        return alerts
""",
    priority=6
)

# 패턴 등록
register_pattern(REPORT_GENERATION_PATTERN)
register_pattern(TASK_SCHEDULER_PATTERN)
register_pattern(NOTIFICATION_DISPATCHER_PATTERN)
register_pattern(DATA_PIPELINE_PATTERN)
register_pattern(BACKUP_RESTORE_PATTERN)
register_pattern(LOG_AGGREGATION_PATTERN)
register_pattern(HEALTH_CHECK_PATTERN)
register_pattern(MIGRATION_PATTERN)
register_pattern(PROCESS_AUTOMATION_PATTERN)
register_pattern(RESOURCE_MONITORING_PATTERN)