"""
Integration Patterns - 통합 관련 비즈니스 패턴
API, 데이터베이스, 파일, 메시지큐 등 외부 시스템 통합 패턴
"""

from ..pattern_library import (
    BusinessPattern, PatternSlot, PatternCategory, register_pattern
)


# ============================================================================
# API CALL PATTERN - API 호출
# ============================================================================

API_CALL_PATTERN = BusinessPattern(
    id="integration_api_call",
    name="API 호출 패턴",
    name_en="API Call Pattern",
    category=PatternCategory.AUTOMATION,
    description="외부 API를 호출하고 응답을 처리하는 패턴",
    trigger_keywords=[
        "api", "rest", "http", "endpoint", "호출", "요청",
        "call", "request", "get", "post", "put", "delete"
    ],
    slots=[
        PatternSlot(
            name="endpoint",
            type="str",
            required=True,
            description="API 엔드포인트 URL"
        ),
        PatternSlot(
            name="method",
            type="str",
            required=False,
            default="GET",
            description="HTTP 메서드"
        ),
        PatternSlot(
            name="headers",
            type="dict",
            required=False,
            description="HTTP 헤더"
        )
    ],
    code_template="""
async def call_api(self, endpoint: str, method: str = 'GET', 
                  data: Dict = None, headers: Dict = None):
    '''API 호출 및 응답 처리'''
    import aiohttp
    import json
    
    # 기본 헤더 설정
    default_headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    if headers:
        default_headers.update(headers)
    
    # 인증 토큰 추가 (필요시)
    if hasattr(self, 'api_token'):
        default_headers['Authorization'] = f'Bearer {self.api_token}'
    
    try:
        async with aiohttp.ClientSession() as session:
            self.logger.info(f"Calling API: {method} {endpoint}")
            
            # HTTP 메서드별 처리
            if method.upper() == 'GET':
                async with session.get(endpoint, headers=default_headers, params=data) as response:
                    result = await response.json()
            elif method.upper() == 'POST':
                async with session.post(endpoint, headers=default_headers, json=data) as response:
                    result = await response.json()
            elif method.upper() == 'PUT':
                async with session.put(endpoint, headers=default_headers, json=data) as response:
                    result = await response.json()
            elif method.upper() == 'DELETE':
                async with session.delete(endpoint, headers=default_headers) as response:
                    result = await response.json()
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            # 응답 상태 확인
            if response.status >= 400:
                raise Exception(f"API error: {response.status} - {result}")
            
            return {
                'status': 'success',
                'status_code': response.status,
                'data': result
            }
            
    except aiohttp.ClientError as e:
        self.logger.error(f"API call failed: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }
""",
    priority=10
)

# ============================================================================
# DATABASE QUERY PATTERN - 데이터베이스 쿼리
# ============================================================================

DATABASE_QUERY_PATTERN = BusinessPattern(
    id="integration_database",
    name="데이터베이스 쿼리 패턴",
    name_en="Database Query Pattern",
    category=PatternCategory.AUTOMATION,
    description="데이터베이스에 쿼리를 실행하고 결과를 처리하는 패턴",
    trigger_keywords=[
        "database", "db", "쿼리", "query", "select", "insert",
        "update", "delete", "sql", "데이터베이스"
    ],
    slots=[
        PatternSlot(
            name="query_type",
            type="str",
            required=True,
            description="쿼리 타입 (select/insert/update/delete)"
        ),
        PatternSlot(
            name="table",
            type="str",
            required=True,
            description="테이블 이름"
        )
    ],
    code_template="""
async def execute_database_query(self, query_type: str, table: str, 
                                 conditions: Dict = None, data: Dict = None):
    '''데이터베이스 쿼리 실행'''
    import asyncpg
    
    # 연결 풀에서 연결 가져오기
    async with self.db_pool.acquire() as connection:
        try:
            if query_type.lower() == 'select':
                # SELECT 쿼리
                where_clause = self._build_where_clause(conditions)
                query = f"SELECT * FROM {table} {where_clause}"
                
                rows = await connection.fetch(query)
                return {
                    'status': 'success',
                    'count': len(rows),
                    'data': [dict(row) for row in rows]
                }
                
            elif query_type.lower() == 'insert':
                # INSERT 쿼리
                columns = ', '.join(data.keys())
                placeholders = ', '.join([f'${i+1}' for i in range(len(data))])
                query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders}) RETURNING *"
                
                row = await connection.fetchrow(query, *data.values())
                return {
                    'status': 'success',
                    'inserted': dict(row)
                }
                
            elif query_type.lower() == 'update':
                # UPDATE 쿼리
                set_clause = ', '.join([f"{k} = ${i+1}" for i, k in enumerate(data.keys())])
                where_clause = self._build_where_clause(conditions)
                query = f"UPDATE {table} SET {set_clause} {where_clause} RETURNING *"
                
                rows = await connection.fetch(query, *data.values())
                return {
                    'status': 'success',
                    'updated': len(rows),
                    'data': [dict(row) for row in rows]
                }
                
            elif query_type.lower() == 'delete':
                # DELETE 쿼리
                where_clause = self._build_where_clause(conditions)
                query = f"DELETE FROM {table} {where_clause} RETURNING *"
                
                rows = await connection.fetch(query)
                return {
                    'status': 'success',
                    'deleted': len(rows)
                }
                
        except Exception as e:
            self.logger.error(f"Database query failed: {e}")
            return {
                'status': 'error',
                'error': str(e)
            }

def _build_where_clause(self, conditions: Dict) -> str:
    '''WHERE 절 생성'''
    if not conditions:
        return ""
    
    clauses = [f"{k} = '{v}'" for k, v in conditions.items()]
    return f"WHERE {' AND '.join(clauses)}"
""",
    priority=10
)

# ============================================================================
# FILE HANDLING PATTERN - 파일 처리
# ============================================================================

FILE_HANDLING_PATTERN = BusinessPattern(
    id="integration_file",
    name="파일 처리 패턴",
    name_en="File Handling Pattern",
    category=PatternCategory.AUTOMATION,
    description="파일을 읽고, 쓰고, 처리하는 패턴",
    trigger_keywords=[
        "파일", "file", "읽기", "쓰기", "read", "write",
        "csv", "json", "txt", "excel", "저장", "로드"
    ],
    slots=[
        PatternSlot(
            name="operation",
            type="str",
            required=True,
            description="파일 작업 (read/write/append)"
        ),
        PatternSlot(
            name="file_path",
            type="str",
            required=True,
            description="파일 경로"
        ),
        PatternSlot(
            name="format",
            type="str",
            required=False,
            default="text",
            description="파일 형식 (text/json/csv/excel)"
        )
    ],
    code_template="""
async def handle_file(self, operation: str, file_path: str, 
                     format: str = 'text', data: Any = None):
    '''파일 처리 작업'''
    import aiofiles
    import json
    import csv
    import pandas as pd
    
    try:
        if operation == 'read':
            if format == 'text':
                async with aiofiles.open(file_path, 'r') as f:
                    content = await f.read()
                return {'status': 'success', 'content': content}
                
            elif format == 'json':
                async with aiofiles.open(file_path, 'r') as f:
                    content = await f.read()
                    data = json.loads(content)
                return {'status': 'success', 'data': data}
                
            elif format == 'csv':
                df = pd.read_csv(file_path)
                return {
                    'status': 'success',
                    'rows': len(df),
                    'columns': list(df.columns),
                    'data': df.to_dict('records')
                }
                
            elif format == 'excel':
                df = pd.read_excel(file_path)
                return {
                    'status': 'success',
                    'rows': len(df),
                    'columns': list(df.columns),
                    'data': df.to_dict('records')
                }
                
        elif operation == 'write':
            if format == 'text':
                async with aiofiles.open(file_path, 'w') as f:
                    await f.write(str(data))
                    
            elif format == 'json':
                async with aiofiles.open(file_path, 'w') as f:
                    await f.write(json.dumps(data, indent=2))
                    
            elif format == 'csv':
                df = pd.DataFrame(data)
                df.to_csv(file_path, index=False)
                
            elif format == 'excel':
                df = pd.DataFrame(data)
                df.to_excel(file_path, index=False)
            
            return {'status': 'success', 'file': file_path}
            
        elif operation == 'append':
            async with aiofiles.open(file_path, 'a') as f:
                await f.write(str(data) + '\\n')
            return {'status': 'success', 'file': file_path}
            
    except Exception as e:
        self.logger.error(f"File operation failed: {e}")
        return {'status': 'error', 'error': str(e)}
""",
    priority=9
)

# ============================================================================
# MESSAGE QUEUE PATTERN - 메시지 큐
# ============================================================================

MESSAGE_QUEUE_PATTERN = BusinessPattern(
    id="integration_message_queue",
    name="메시지 큐 패턴",
    name_en="Message Queue Pattern",
    category=PatternCategory.AUTOMATION,
    description="메시지 큐를 통한 비동기 통신 패턴",
    trigger_keywords=[
        "메시지", "큐", "message", "queue", "rabbitmq", "kafka",
        "pub", "sub", "publish", "subscribe", "브로커"
    ],
    slots=[
        PatternSlot(
            name="queue_type",
            type="str",
            required=True,
            description="큐 타입 (rabbitmq/kafka/redis)"
        ),
        PatternSlot(
            name="topic",
            type="str",
            required=True,
            description="토픽/큐 이름"
        )
    ],
    code_template="""
class MessageQueueHandler:
    def __init__(self, queue_type: str, connection_params: Dict):
        self.queue_type = queue_type
        self.connection = None
        self.setup_connection(connection_params)
    
    async def setup_connection(self, params: Dict):
        '''큐 연결 설정'''
        if self.queue_type == 'rabbitmq':
            import aio_pika
            self.connection = await aio_pika.connect_robust(
                f"amqp://{params['user']}:{params['password']}@{params['host']}/"
            )
            self.channel = await self.connection.channel()
            
        elif self.queue_type == 'kafka':
            from aiokafka import AIOKafkaProducer, AIOKafkaConsumer
            self.producer = AIOKafkaProducer(
                bootstrap_servers=params['bootstrap_servers']
            )
            await self.producer.start()
            
        elif self.queue_type == 'redis':
            import aioredis
            self.connection = await aioredis.create_redis_pool(
                f"redis://{params['host']}:{params['port']}"
            )
    
    async def publish(self, topic: str, message: Dict):
        '''메시지 발행'''
        self.logger.info(f"Publishing to {topic}: {message}")
        
        if self.queue_type == 'rabbitmq':
            exchange = await self.channel.declare_exchange(topic, 'topic')
            await exchange.publish(
                aio_pika.Message(body=json.dumps(message).encode()),
                routing_key=topic
            )
            
        elif self.queue_type == 'kafka':
            await self.producer.send(
                topic,
                json.dumps(message).encode()
            )
            
        elif self.queue_type == 'redis':
            await self.connection.publish(
                topic,
                json.dumps(message)
            )
        
        return {'status': 'published', 'topic': topic}
    
    async def subscribe(self, topic: str, handler: callable):
        '''메시지 구독'''
        self.logger.info(f"Subscribing to {topic}")
        
        if self.queue_type == 'rabbitmq':
            queue = await self.channel.declare_queue(topic)
            await queue.consume(handler)
            
        elif self.queue_type == 'kafka':
            consumer = AIOKafkaConsumer(
                topic,
                bootstrap_servers=self.connection_params['bootstrap_servers']
            )
            await consumer.start()
            async for msg in consumer:
                await handler(json.loads(msg.value))
                
        elif self.queue_type == 'redis':
            channel = (await self.connection.subscribe(topic))[0]
            while await channel.wait_message():
                msg = await channel.get()
                await handler(json.loads(msg))
""",
    priority=8
)

# ============================================================================
# WEBHOOK PATTERN - 웹훅 처리
# ============================================================================

WEBHOOK_PATTERN = BusinessPattern(
    id="integration_webhook",
    name="웹훅 패턴",
    name_en="Webhook Pattern",
    category=PatternCategory.AUTOMATION,
    description="웹훅을 수신하고 처리하는 패턴",
    trigger_keywords=[
        "웹훅", "webhook", "callback", "notification", "알림",
        "이벤트", "콜백", "push"
    ],
    slots=[
        PatternSlot(
            name="webhook_url",
            type="str",
            required=True,
            description="웹훅 URL"
        ),
        PatternSlot(
            name="secret",
            type="str",
            required=False,
            description="웹훅 시크릿 키"
        )
    ],
    code_template="""
class WebhookHandler:
    def __init__(self, webhook_url: str, secret: str = None):
        self.webhook_url = webhook_url
        self.secret = secret
        self.handlers = {}
    
    def register_handler(self, event_type: str, handler: callable):
        '''이벤트 핸들러 등록'''
        self.handlers[event_type] = handler
    
    async def receive_webhook(self, request_data: Dict, headers: Dict):
        '''웹훅 수신 및 처리'''
        
        # 서명 검증 (시크릿이 있는 경우)
        if self.secret:
            if not self.verify_signature(request_data, headers):
                return {
                    'status': 'error',
                    'error': 'Invalid signature'
                }
        
        # 이벤트 타입 추출
        event_type = request_data.get('event_type') or headers.get('X-Event-Type')
        
        # 핸들러 실행
        if event_type in self.handlers:
            try:
                result = await self.handlers[event_type](request_data)
                return {
                    'status': 'success',
                    'event_type': event_type,
                    'result': result
                }
            except Exception as e:
                self.logger.error(f"Handler failed: {e}")
                return {
                    'status': 'error',
                    'error': str(e)
                }
        else:
            self.logger.warning(f"No handler for event: {event_type}")
            return {
                'status': 'unhandled',
                'event_type': event_type
            }
    
    def verify_signature(self, data: Dict, headers: Dict) -> bool:
        '''웹훅 서명 검증'''
        import hmac
        import hashlib
        
        signature = headers.get('X-Signature')
        if not signature:
            return False
        
        expected_sig = hmac.new(
            self.secret.encode(),
            json.dumps(data).encode(),
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(signature, expected_sig)
    
    async def send_webhook(self, target_url: str, data: Dict):
        '''웹훅 발송'''
        import aiohttp
        
        headers = {
            'Content-Type': 'application/json',
            'X-Event-Type': data.get('event_type', 'notification')
        }
        
        if self.secret:
            import hmac
            import hashlib
            signature = hmac.new(
                self.secret.encode(),
                json.dumps(data).encode(),
                hashlib.sha256
            ).hexdigest()
            headers['X-Signature'] = signature
        
        async with aiohttp.ClientSession() as session:
            async with session.post(target_url, json=data, headers=headers) as response:
                return {
                    'status': 'sent',
                    'status_code': response.status,
                    'response': await response.text()
                }
""",
    priority=8
)

# ============================================================================
# EMAIL SEND PATTERN - 이메일 발송
# ============================================================================

EMAIL_SEND_PATTERN = BusinessPattern(
    id="integration_email",
    name="이메일 발송 패턴",
    name_en="Email Send Pattern",
    category=PatternCategory.NOTIFICATION,
    description="이메일을 작성하고 발송하는 패턴",
    trigger_keywords=[
        "이메일", "email", "메일", "발송", "send", "smtp",
        "편지", "알림", "notification"
    ],
    slots=[
        PatternSlot(
            name="to",
            type="str",
            required=True,
            description="수신자 이메일"
        ),
        PatternSlot(
            name="subject",
            type="str",
            required=True,
            description="제목"
        ),
        PatternSlot(
            name="body",
            type="str",
            required=True,
            description="본문"
        )
    ],
    code_template="""
async def send_email(self, to: str, subject: str, body: str, 
                     cc: List[str] = None, attachments: List[str] = None):
    '''이메일 발송'''
    import aiosmtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from email.mime.base import MIMEBase
    from email import encoders
    
    # 이메일 메시지 생성
    msg = MIMEMultipart()
    msg['From'] = self.email_config['from']
    msg['To'] = to
    msg['Subject'] = subject
    
    if cc:
        msg['Cc'] = ', '.join(cc)
    
    # 본문 추가
    msg.attach(MIMEText(body, 'html'))
    
    # 첨부파일 처리
    if attachments:
        for file_path in attachments:
            with open(file_path, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    f'attachment; filename={os.path.basename(file_path)}'
                )
                msg.attach(part)
    
    # 이메일 발송
    try:
        await aiosmtplib.send(
            msg,
            hostname=self.email_config['smtp_host'],
            port=self.email_config['smtp_port'],
            username=self.email_config['username'],
            password=self.email_config['password'],
            use_tls=True
        )
        
        self.logger.info(f"Email sent to {to}")
        return {
            'status': 'sent',
            'to': to,
            'subject': subject
        }
        
    except Exception as e:
        self.logger.error(f"Email send failed: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }
""",
    priority=7
)

# ============================================================================
# SMS SEND PATTERN - SMS 발송
# ============================================================================

SMS_SEND_PATTERN = BusinessPattern(
    id="integration_sms",
    name="SMS 발송 패턴",
    name_en="SMS Send Pattern",
    category=PatternCategory.NOTIFICATION,
    description="SMS 메시지를 발송하는 패턴",
    trigger_keywords=[
        "sms", "문자", "메시지", "text", "단문", "알림",
        "휴대폰", "mobile", "phone"
    ],
    slots=[
        PatternSlot(
            name="phone_number",
            type="str",
            required=True,
            description="수신 전화번호"
        ),
        PatternSlot(
            name="message",
            type="str",
            required=True,
            description="메시지 내용"
        )
    ],
    code_template="""
async def send_sms(self, phone_number: str, message: str):
    '''SMS 발송'''
    # Twilio 예제
    from twilio.rest import Client
    
    try:
        # Twilio 클라이언트 초기화
        client = Client(
            self.sms_config['account_sid'],
            self.sms_config['auth_token']
        )
        
        # SMS 발송
        message = client.messages.create(
            body=message[:160],  # SMS 길이 제한
            from_=self.sms_config['from_number'],
            to=phone_number
        )
        
        self.logger.info(f"SMS sent to {phone_number}: {message.sid}")
        
        return {
            'status': 'sent',
            'message_id': message.sid,
            'to': phone_number,
            'length': len(message.body)
        }
        
    except Exception as e:
        self.logger.error(f"SMS send failed: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }
""",
    priority=6
)

# ============================================================================
# CACHE PATTERN - 캐시 처리
# ============================================================================

CACHE_PATTERN = BusinessPattern(
    id="integration_cache",
    name="캐시 패턴",
    name_en="Cache Pattern",
    category=PatternCategory.AUTOMATION,
    description="데이터를 캐시하고 관리하는 패턴",
    trigger_keywords=[
        "캐시", "cache", "redis", "memcached", "저장",
        "임시", "temporary", "ttl"
    ],
    slots=[
        PatternSlot(
            name="cache_type",
            type="str",
            required=False,
            default="memory",
            description="캐시 타입 (memory/redis/memcached)"
        ),
        PatternSlot(
            name="ttl",
            type="int",
            required=False,
            default=3600,
            description="TTL (초)"
        )
    ],
    code_template="""
class CacheHandler:
    def __init__(self, cache_type: str = 'memory'):
        self.cache_type = cache_type
        
        if cache_type == 'memory':
            from cachetools import TTLCache
            self.cache = TTLCache(maxsize=1000, ttl=3600)
        elif cache_type == 'redis':
            import redis
            self.cache = redis.Redis(
                host='localhost',
                port=6379,
                decode_responses=True
            )
    
    async def get(self, key: str):
        '''캐시에서 값 가져오기'''
        try:
            if self.cache_type == 'memory':
                return self.cache.get(key)
            elif self.cache_type == 'redis':
                value = self.cache.get(key)
                if value:
                    return json.loads(value)
            return None
        except Exception as e:
            self.logger.error(f"Cache get failed: {e}")
            return None
    
    async def set(self, key: str, value: Any, ttl: int = 3600):
        '''캐시에 값 저장'''
        try:
            if self.cache_type == 'memory':
                self.cache[key] = value
            elif self.cache_type == 'redis':
                self.cache.setex(
                    key,
                    ttl,
                    json.dumps(value)
                )
            return True
        except Exception as e:
            self.logger.error(f"Cache set failed: {e}")
            return False
    
    async def delete(self, key: str):
        '''캐시에서 값 삭제'''
        try:
            if self.cache_type == 'memory':
                del self.cache[key]
            elif self.cache_type == 'redis':
                self.cache.delete(key)
            return True
        except Exception as e:
            self.logger.error(f"Cache delete failed: {e}")
            return False
    
    async def clear(self):
        '''캐시 전체 삭제'''
        if self.cache_type == 'memory':
            self.cache.clear()
        elif self.cache_type == 'redis':
            self.cache.flushdb()
""",
    priority=7
)

# ============================================================================
# STREAM PROCESSING PATTERN - 스트림 처리
# ============================================================================

STREAM_PROCESSING_PATTERN = BusinessPattern(
    id="integration_stream",
    name="스트림 처리 패턴",
    name_en="Stream Processing Pattern",
    category=PatternCategory.AUTOMATION,
    description="실시간 데이터 스트림을 처리하는 패턴",
    trigger_keywords=[
        "스트림", "stream", "실시간", "real-time", "kafka",
        "websocket", "sse", "streaming"
    ],
    slots=[
        PatternSlot(
            name="stream_type",
            type="str",
            required=True,
            description="스트림 타입 (websocket/kafka/sse)"
        )
    ],
    code_template="""
class StreamProcessor:
    def __init__(self, stream_type: str):
        self.stream_type = stream_type
        self.handlers = []
    
    async def connect_stream(self, url: str):
        '''스트림 연결'''
        if self.stream_type == 'websocket':
            import websockets
            self.connection = await websockets.connect(url)
            
        elif self.stream_type == 'kafka':
            from aiokafka import AIOKafkaConsumer
            self.consumer = AIOKafkaConsumer(
                'topic',
                bootstrap_servers='localhost:9092'
            )
            await self.consumer.start()
            
        elif self.stream_type == 'sse':
            import aiohttp_sse_client
            self.client = aiohttp_sse_client.EventSource(url)
    
    async def process_stream(self, handler: callable):
        '''스트림 데이터 처리'''
        if self.stream_type == 'websocket':
            async for message in self.connection:
                data = json.loads(message)
                await handler(data)
                
        elif self.stream_type == 'kafka':
            async for msg in self.consumer:
                data = json.loads(msg.value)
                await handler(data)
                
        elif self.stream_type == 'sse':
            async for event in self.client:
                data = json.loads(event.data)
                await handler(data)
    
    async def send_to_stream(self, data: Dict):
        '''스트림으로 데이터 전송'''
        if self.stream_type == 'websocket':
            await self.connection.send(json.dumps(data))
        # Kafka producer, SSE는 별도 구현 필요
""",
    priority=6
)

# ============================================================================
# GRAPHQL PATTERN - GraphQL 쿼리
# ============================================================================

GRAPHQL_PATTERN = BusinessPattern(
    id="integration_graphql",
    name="GraphQL 쿼리 패턴",
    name_en="GraphQL Pattern",
    category=PatternCategory.AUTOMATION,
    description="GraphQL API를 호출하고 처리하는 패턴",
    trigger_keywords=[
        "graphql", "query", "mutation", "subscription",
        "gql", "apollo", "그래프QL"
    ],
    slots=[
        PatternSlot(
            name="endpoint",
            type="str",
            required=True,
            description="GraphQL 엔드포인트"
        ),
        PatternSlot(
            name="query",
            type="str",
            required=True,
            description="GraphQL 쿼리/뮤테이션"
        )
    ],
    code_template="""
async def execute_graphql(self, endpoint: str, query: str, variables: Dict = None):
    '''GraphQL 쿼리 실행'''
    import aiohttp
    
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    # 인증 토큰 추가 (필요시)
    if hasattr(self, 'api_token'):
        headers['Authorization'] = f'Bearer {self.api_token}'
    
    payload = {
        'query': query,
        'variables': variables or {}
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(endpoint, json=payload, headers=headers) as response:
                result = await response.json()
                
                if 'errors' in result:
                    raise Exception(f"GraphQL errors: {result['errors']}")
                
                return {
                    'status': 'success',
                    'data': result.get('data')
                }
                
    except Exception as e:
        self.logger.error(f"GraphQL query failed: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }
""",
    priority=6
)

# 패턴 등록
register_pattern(API_CALL_PATTERN)
register_pattern(DATABASE_QUERY_PATTERN)
register_pattern(FILE_HANDLING_PATTERN)
register_pattern(MESSAGE_QUEUE_PATTERN)
register_pattern(WEBHOOK_PATTERN)
register_pattern(EMAIL_SEND_PATTERN)
register_pattern(SMS_SEND_PATTERN)
register_pattern(CACHE_PATTERN)
register_pattern(STREAM_PROCESSING_PATTERN)
register_pattern(GRAPHQL_PATTERN)