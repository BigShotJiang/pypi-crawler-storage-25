"""
Business Pattern Modules
각 도메인별 비즈니스 패턴 정의
"""

# 패턴 모듈들을 임포트하면 자동으로 등록됨