"""
Pattern Library - 비즈니스 패턴 라이브러리
패턴 정의, 관리, 로딩 시스템
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
import json
from pathlib import Path
from loguru import logger


class PatternCategory(Enum):
    """패턴 카테고리 정의"""
    FILTERING = "filtering"          # 필터링/선별
    PRICING = "pricing"              # 가격/할인
    MONITORING = "monitoring"        # 모니터링/알림
    VALIDATION = "validation"        # 검증/확인
    TRANSFORMATION = "transformation" # 변환/가공
    AGGREGATION = "aggregation"      # 집계/통계
    NOTIFICATION = "notification"    # 알림/통지
    AUTOMATION = "automation"        # 자동화
    SECURITY = "security"           # 보안/인증


@dataclass
class PatternSlot:
    """패턴에서 추출해야 할 정보 슬롯"""
    name: str                       # 슬롯 이름 (예: "threshold_value")
    type: str                       # 데이터 타입 (str, int, float, dict, list)
    required: bool                  # 필수 여부
    default: Any = None            # 기본값
    extraction_regex: str = ""     # 추출용 정규식
    examples: Dict = field(default_factory=dict)  # 한글-영어 매핑 예시
    validation: str = ""           # 검증 규칙
    description: str = ""          # 슬롯 설명


@dataclass
class BusinessPattern:
    """비즈니스 패턴 정의"""
    id: str                         # 고유 ID
    name: str                       # 한글 이름
    name_en: str                    # 영문 이름
    category: PatternCategory       # 카테고리
    description: str               # 상세 설명
    trigger_keywords: List[str]    # 트리거 키워드 (한글/영어)
    slots: List[PatternSlot]       # 필요한 슬롯 정보
    code_template: str             # 코드 템플릿
    priority: int = 0              # 우선순위 (높을수록 우선)
    compatibility: List[str] = field(default_factory=list)  # 호환 템플릿 목록
    test_cases: List[Dict] = field(default_factory=list)    # 테스트 케이스
    
    def to_dict(self) -> Dict:
        """딕셔너리로 변환"""
        return {
            'id': self.id,
            'name': self.name,
            'name_en': self.name_en,
            'category': self.category.value,
            'description': self.description,
            'trigger_keywords': self.trigger_keywords,
            'priority': self.priority,
            'compatibility': self.compatibility
        }


# 글로벌 패턴 저장소
_PATTERN_REGISTRY: Dict[str, BusinessPattern] = {}


def register_pattern(pattern: BusinessPattern) -> None:
    """패턴을 레지스트리에 등록"""
    if pattern.id in _PATTERN_REGISTRY:
        logger.warning(f"Pattern {pattern.id} is being overwritten")
    _PATTERN_REGISTRY[pattern.id] = pattern
    logger.debug(f"Registered pattern: {pattern.id}")


def load_all_patterns() -> Dict[str, BusinessPattern]:
    """모든 패턴 로드"""
    if not _PATTERN_REGISTRY:
        # 패턴 모듈들 임포트 (자동 등록됨)
        try:
            from .patterns import filtering_patterns
            from .patterns import monitoring_patterns
            from .patterns import pricing_patterns
            from .patterns import data_patterns
            logger.info(f"Loaded all pattern modules successfully")
        except ImportError as e:
            logger.warning(f"Some pattern modules not found: {e}")
    
    return _PATTERN_REGISTRY.copy()


def get_pattern_by_id(pattern_id: str) -> Optional[BusinessPattern]:
    """ID로 패턴 가져오기"""
    if not _PATTERN_REGISTRY:
        load_all_patterns()
    return _PATTERN_REGISTRY.get(pattern_id)


def get_patterns_by_category(category: PatternCategory) -> List[BusinessPattern]:
    """카테고리별 패턴 가져오기"""
    if not _PATTERN_REGISTRY:
        load_all_patterns()
    
    return [
        pattern for pattern in _PATTERN_REGISTRY.values()
        if pattern.category == category
    ]


def get_pattern_stats() -> Dict[str, Any]:
    """패턴 통계 정보"""
    if not _PATTERN_REGISTRY:
        load_all_patterns()
    
    stats = {
        'total_patterns': len(_PATTERN_REGISTRY),
        'categories': {}
    }
    
    for pattern in _PATTERN_REGISTRY.values():
        cat = pattern.category.value
        if cat not in stats['categories']:
            stats['categories'][cat] = 0
        stats['categories'][cat] += 1
    
    return stats