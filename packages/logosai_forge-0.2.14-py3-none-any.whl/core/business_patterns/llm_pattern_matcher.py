"""
LLM-based Pattern Matcher using Gemini
Gemini를 활용한 의미 기반 패턴 매칭
"""

import json
import os
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from loguru import logger
from functools import lru_cache
import hashlib

from .pattern_library import (
    BusinessPattern,
    load_all_patterns,
    get_pattern_by_id
)
from .pattern_matcher import PatternMatch


class LLMPatternMatcher:
    """LLM 기반 패턴 매처 (Gemini)"""
    
    # Gemini에게 줄 시스템 프롬프트
    SYSTEM_PROMPT = """You are a pattern matching expert for a business logic system.
Your task is to analyze user queries in Korean/English and match them to the most appropriate business patterns.

AVAILABLE PATTERNS:
{pattern_list}

INSTRUCTIONS:
1. Analyze the user query semantically (meaning-based, not just keyword matching)
2. Consider synonyms, similar concepts, and intent
3. Return top 3 matching patterns with confidence scores
4. Consider Korean-English equivalents (e.g., "할인" = "discount")
5. If no good match exists, return empty array

OUTPUT FORMAT (JSON only, no explanation):
{{
  "matches": [
    {{
      "pattern_id": "string",
      "confidence": 0.0-1.0,
      "reason": "brief reason in Korean",
      "extracted_values": {{}}
    }}
  ]
}}

CONFIDENCE GUIDELINES:
- 0.9-1.0: Perfect semantic match
- 0.7-0.9: Strong match with clear intent
- 0.5-0.7: Moderate match, related concept
- 0.3-0.5: Weak match, possibly related
- Below 0.3: Don't include

EXAMPLES:
Query: "VIP 고객에게 특별 할인"
→ tier_based_filtering (0.8), discount_rate_apply (0.9)

Query: "재고 부족시 알림"
→ threshold_alert (0.95)

Query: "데이터 통계 보기"
→ data_aggregation (0.9)
"""
    
    def __init__(self, api_key: str = None):
        """
        Args:
            api_key: Gemini API key (환경변수에서 자동 로드)
        """
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is required")
        
        self.patterns = load_all_patterns()
        self._init_llm_client()
        
        # 패턴 목록을 프롬프트용으로 준비
        self.pattern_descriptions = self._prepare_pattern_descriptions()
        self.system_prompt = self.SYSTEM_PROMPT.format(
            pattern_list=self.pattern_descriptions
        )
        
        logger.info(f"LLMPatternMatcher initialized with {len(self.patterns)} patterns")
    
    def _init_llm_client(self):
        """Gemini 클라이언트 초기화"""
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            # gemini-2.0-flash 모델 사용
            self.model = genai.GenerativeModel(
                'gemini-2.0-flash',
                generation_config={
                    "temperature": 0.1,  # 일관성을 위해 낮게 설정
                    "top_p": 0.95,
                    "max_output_tokens": 500,
                    "response_mime_type": "application/json"
                }
            )
            logger.info("Gemini client initialized successfully")
        except ImportError:
            logger.error("google-generativeai package not installed")
            raise ImportError("Please install google-generativeai: pip install google-generativeai")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini client: {e}")
            raise
    
    def _prepare_pattern_descriptions(self) -> str:
        """패턴을 LLM이 이해할 수 있는 형태로 준비"""
        descriptions = []
        
        for pattern_id, pattern in self.patterns.items():
            desc = f"""- ID: {pattern_id}
  Name: {pattern.name} ({pattern.name_en})
  Category: {pattern.category.value}
  Description: {pattern.description}
  Keywords: {', '.join(pattern.trigger_keywords[:10])}
  Priority: {pattern.priority}"""
            descriptions.append(desc)
        
        return "\n\n".join(descriptions)
    
    @lru_cache(maxsize=256)
    def _cached_llm_match(self, query_hash: str, query: str) -> Dict:
        """LLM 매칭 결과 캐싱"""
        try:
            # 시스템 프롬프트와 함께 쿼리 전송
            prompt = f"{self.system_prompt}\n\nUser Query: {query}"
            
            response = self.model.generate_content(prompt)
            result_text = response.text.strip()
            
            # JSON 파싱
            if result_text.startswith("```json"):
                result_text = result_text[7:-3]  # ```json 제거
            
            result = json.loads(result_text)
            logger.debug(f"LLM response for '{query}': {result}")
            
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response: {e}")
            return {"matches": []}
        except Exception as e:
            logger.error(f"LLM matching failed: {e}")
            return {"matches": []}
    
    def match_patterns(self, query: str, context: Dict[str, Any] = None) -> List[PatternMatch]:
        """
        LLM을 사용한 의미적 패턴 매칭
        
        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트
        
        Returns:
            매칭된 패턴 리스트
        """
        if not query:
            return []
        
        context = context or {}
        
        # 쿼리 해시 생성 (캐싱용)
        query_hash = hashlib.md5(query.encode()).hexdigest()
        
        # LLM 매칭 수행 (캐싱됨)
        llm_result = self._cached_llm_match(query_hash, query)
        
        # PatternMatch 객체로 변환
        matches = []
        for match_data in llm_result.get("matches", []):
            pattern_id = match_data.get("pattern_id")
            if pattern_id not in self.patterns:
                continue
            
            pattern = self.patterns[pattern_id]
            
            # 슬롯 추출 (LLM이 제공한 값 + 기존 로직)
            extracted_slots = match_data.get("extracted_values", {})
            
            # 추가 슬롯 추출 (기존 로직 활용)
            for slot in pattern.slots:
                if slot.name not in extracted_slots:
                    value = self._extract_slot_value(slot, query, context)
                    if value is not None:
                        extracted_slots[slot.name] = value
                    elif slot.default is not None:
                        extracted_slots[slot.name] = slot.default
            
            # 누락된 필수 슬롯 확인
            missing_slots = []
            for slot in pattern.slots:
                if slot.required and slot.name not in extracted_slots:
                    missing_slots.append(slot.name)
            
            match = PatternMatch(
                pattern_id=pattern_id,
                pattern_name=pattern.name,
                confidence_score=match_data.get("confidence", 0.5),
                matched_keywords=[],  # LLM은 키워드 매칭이 아님
                extracted_slots=extracted_slots,
                missing_slots=missing_slots,
                is_complete=len(missing_slots) == 0,
                match_type="semantic"  # 의미적 매칭
            )
            
            matches.append(match)
        
        # 신뢰도 순으로 정렬
        matches.sort(key=lambda x: x.confidence_score, reverse=True)
        
        logger.info(f"LLM found {len(matches)} pattern matches for query: {query[:50]}...")
        return matches
    
    def _extract_slot_value(self, slot, query: str, context: Dict) -> Any:
        """슬롯 값 추출 (기존 로직 재사용)"""
        import re
        
        # 컨텍스트에서 확인
        if slot.name in context:
            return context[slot.name]
        
        # 정규식 추출
        if slot.extraction_regex:
            match = re.search(slot.extraction_regex, query)
            if match:
                return match.group(1)
        
        # 예시 매핑
        if slot.examples:
            for korean, english in slot.examples.items():
                if korean in query:
                    return english
        
        return None
    
    def get_best_match(self, query: str, context: Dict[str, Any] = None) -> Optional[PatternMatch]:
        """가장 신뢰도 높은 매칭 결과 반환"""
        matches = self.match_patterns(query, context)
        return matches[0] if matches else None


class LLMPatternMatcherLite:
    """
    경량 버전 - API 호출 최소화
    여러 쿼리를 배치로 처리
    """
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        self.patterns = load_all_patterns()
        self._init_llm_client()
    
    def _init_llm_client(self):
        """Gemini 클라이언트 초기화"""
        import google.generativeai as genai
        genai.configure(api_key=self.api_key)
        
        self.model = genai.GenerativeModel(
            'gemini-2.0-flash',
            generation_config={
                "temperature": 0.1,
                "max_output_tokens": 1000,
                "response_mime_type": "application/json"
            }
        )
    
    def match_patterns_batch(self, queries: List[str]) -> List[List[PatternMatch]]:
        """
        여러 쿼리를 한 번에 처리 (API 호출 최소화)
        """
        # 패턴 ID와 키워드만 전송 (토큰 절약)
        pattern_info = {
            pid: {
                "name": p.name,
                "keywords": p.trigger_keywords[:5]
            }
            for pid, p in self.patterns.items()
        }
        
        prompt = f"""Match these queries to patterns. Return pattern IDs and confidence only.
Patterns: {json.dumps(pattern_info, ensure_ascii=False)}

Queries:
{json.dumps(queries, ensure_ascii=False)}

Return format:
[
  [{{"id": "pattern_id", "conf": 0.9}}],  # for query 1
  [{{"id": "pattern_id", "conf": 0.8}}],  # for query 2
  ...
]"""
        
        try:
            response = self.model.generate_content(prompt)
            results = json.loads(response.text)
            
            # PatternMatch 객체로 변환
            all_matches = []
            for query_idx, query_results in enumerate(results):
                matches = []
                for r in query_results:
                    if r["id"] in self.patterns:
                        pattern = self.patterns[r["id"]]
                        match = PatternMatch(
                            pattern_id=r["id"],
                            pattern_name=pattern.name,
                            confidence_score=r["conf"],
                            matched_keywords=[],
                            extracted_slots={},
                            missing_slots=[],
                            is_complete=False,
                            match_type="semantic_batch"
                        )
                        matches.append(match)
                all_matches.append(matches)
            
            return all_matches
            
        except Exception as e:
            logger.error(f"Batch matching failed: {e}")
            return [[] for _ in queries]