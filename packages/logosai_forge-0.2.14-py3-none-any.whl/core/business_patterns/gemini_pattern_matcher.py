"""
Gemini-1.5-Flash Pattern Matcher
최적화된 System Prompt를 활용한 경량 패턴 매칭
"""

import json
import os
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from loguru import logger
from functools import lru_cache
import hashlib

from .pattern_library import (
    BusinessPattern,
    load_all_patterns,
    get_pattern_by_id
)
from .pattern_matcher import PatternMatch


class GeminiPatternMatcher:
    """Gemini-1.5-Flash를 활용한 최적화된 패턴 매처"""
    
    # 최적화된 한국어 System Prompt
    SYSTEM_PROMPT = """당신은 비즈니스 로직 패턴 매칭 전문가입니다.

# 임무
사용자의 한국어/영어 쿼리를 분석하여 가장 적합한 비즈니스 패턴을 찾아주세요.

# 패턴 목록
{patterns}

# 매칭 규칙
1. 의미적 유사성 우선 (키워드 매칭이 아닌 의미 매칭)
2. 동의어/유사어 자동 인식
   - 할인 = 세일 = 디스카운트 = discount = sale
   - 회원 = 멤버 = 고객 = 유저 = member = user
   - 통계 = 분석 = 리포트 = 집계 = statistics = analysis
   - 알림 = 알람 = 노티 = 경고 = alert = notification
3. 오타/줄임말 처리
   - 빕 = VIP, 디비 = DB, 노티 = notification
4. 문맥 이해
   - "재고 떨어지면" = 재고 임계값 모니터링
   - "등급별로 다르게" = 등급별 차등 제공
5. 복합 의도 파악
   - 여러 패턴이 필요한 경우 모두 반환

# 신뢰도 기준
- 0.9-1.0: 완벽한 의미 매칭
- 0.7-0.8: 강한 연관성
- 0.5-0.6: 관련 있음
- 0.3-0.4: 약한 연관성
- 0.3 미만: 반환하지 않음

# 출력 형식 (JSON만, 설명 없이)
{{
  "matches": [
    {{
      "pattern_id": "패턴ID",
      "confidence": 0.95,
      "keywords_matched": ["매칭된", "키워드"],
      "slots": {{
        "추출가능한_슬롯": "값"
      }}
    }}
  ]
}}

# 예시
입력: "VIP 고객 30% 할인"
출력: {{
  "matches": [
    {{"pattern_id": "discount_rate_apply", "confidence": 0.95, "keywords_matched": ["할인", "%"], "slots": {{"discount_rate": 30}}}},
    {{"pattern_id": "tier_based_filtering", "confidence": 0.8, "keywords_matched": ["VIP", "고객"], "slots": {{"tier_field": "user_tier"}}}}
  ]
}}

입력: "재고 10개 이하 알림"
출력: {{
  "matches": [
    {{"pattern_id": "threshold_alert", "confidence": 0.95, "keywords_matched": ["재고", "이하", "알림"], "slots": {{"monitor_field": "stock", "threshold_value": 10, "comparison": "<="}}}}
  ]
}}"""

    # 경량화된 패턴 설명 템플릿
    PATTERN_TEMPLATE = """ID: {id}
이름: {name}
설명: {description}
키워드: {keywords}"""

    def __init__(self, api_key: str = None, model_name: str = "gemini-1.5-flash"):
        """
        Args:
            api_key: Gemini API key
            model_name: 모델명 (gemini-1.5-flash 권장)
        """
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is required")
        
        self.model_name = model_name
        self.patterns = load_all_patterns()
        self._init_llm_client()
        
        # 간결한 패턴 설명 생성
        self.system_prompt = self._create_optimized_prompt()
        
        logger.info(f"GeminiPatternMatcher initialized with {len(self.patterns)} patterns")
    
    def _init_llm_client(self):
        """Gemini 클라이언트 초기화"""
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            # Gemini-1.5-Flash 설정 (최적 성능)
            self.model = genai.GenerativeModel(
                self.model_name,
                generation_config={
                    "temperature": 0.1,  # 일관성을 위해 낮게
                    "top_p": 0.95,
                    "top_k": 40,
                    "max_output_tokens": 400,  # 간결한 응답
                    "response_mime_type": "application/json"
                }
            )
            logger.info(f"Gemini client initialized with {self.model_name}")
        except ImportError:
            raise ImportError("Please install: pip install google-generativeai")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")
            raise
    
    def _create_optimized_prompt(self) -> str:
        """최적화된 프롬프트 생성 (토큰 절약)"""
        patterns_desc = []
        
        for pid, pattern in self.patterns.items():
            # 간결한 설명 (필수 정보만)
            desc = self.PATTERN_TEMPLATE.format(
                id=pid,
                name=pattern.name,
                description=pattern.description[:50],  # 50자로 제한
                keywords=', '.join(pattern.trigger_keywords[:7])  # 상위 7개만
            )
            patterns_desc.append(desc)
        
        patterns_text = "\n\n".join(patterns_desc)
        return self.SYSTEM_PROMPT.format(patterns=patterns_text)
    
    @lru_cache(maxsize=512)  # 캐시 크기 증가
    def _cached_llm_match(self, query_hash: str, query: str) -> Dict:
        """LLM 매칭 결과 캐싱"""
        try:
            # 간결한 프롬프트 생성
            prompt = f"""{self.system_prompt}

# 쿼리 분석
입력: "{query}"
출력:"""
            
            response = self.model.generate_content(prompt)
            result_text = response.text.strip()
            
            # JSON 정리
            if result_text.startswith("```"):
                result_text = result_text.split("```")[1]
                if result_text.startswith("json"):
                    result_text = result_text[4:]
            
            result = json.loads(result_text.strip())
            logger.debug(f"Gemini response: {result}")
            
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}, Response: {result_text[:200]}")
            return {"matches": []}
        except Exception as e:
            logger.error(f"LLM error: {e}")
            return {"matches": []}
    
    def match_patterns(self, query: str, context: Dict[str, Any] = None, 
                      use_cache: bool = True) -> List[PatternMatch]:
        """
        Gemini를 사용한 패턴 매칭
        
        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트
            use_cache: 캐시 사용 여부
        
        Returns:
            매칭된 패턴 리스트
        """
        if not query or len(query.strip()) < 2:
            return []
        
        context = context or {}
        
        # 쿼리 정규화 및 해싱
        normalized_query = query.strip().lower()
        query_hash = hashlib.md5(normalized_query.encode()).hexdigest()
        
        # LLM 호출 (캐싱 자동 적용)
        if use_cache:
            llm_result = self._cached_llm_match(query_hash, query)
        else:
            # 캐시 무시
            llm_result = self._cached_llm_match.__wrapped__(self, query_hash, query)
        
        # PatternMatch 객체 생성
        matches = []
        for match_data in llm_result.get("matches", []):
            pattern_id = match_data.get("pattern_id")
            if pattern_id not in self.patterns:
                continue
            
            pattern = self.patterns[pattern_id]
            
            # LLM이 추출한 슬롯 + 컨텍스트 병합
            extracted_slots = match_data.get("slots", {})
            extracted_slots.update(context)  # 컨텍스트 우선
            
            # 누락된 필수 슬롯 확인
            missing_slots = []
            for slot in pattern.slots:
                if slot.required and slot.name not in extracted_slots:
                    if slot.default is not None:
                        extracted_slots[slot.name] = slot.default
                    else:
                        missing_slots.append(slot.name)
            
            match = PatternMatch(
                pattern_id=pattern_id,
                pattern_name=pattern.name,
                confidence_score=min(match_data.get("confidence", 0.5), 1.0),
                matched_keywords=match_data.get("keywords_matched", []),
                extracted_slots=extracted_slots,
                missing_slots=missing_slots,
                is_complete=len(missing_slots) == 0,
                match_type="gemini"
            )
            
            matches.append(match)
        
        # 신뢰도 순 정렬
        matches.sort(key=lambda x: x.confidence_score, reverse=True)
        
        logger.info(f"Gemini found {len(matches)} matches for: {query[:30]}...")
        return matches
    
    def get_best_match(self, query: str, context: Dict[str, Any] = None) -> Optional[PatternMatch]:
        """가장 신뢰도 높은 매칭 반환"""
        matches = self.match_patterns(query, context)
        return matches[0] if matches else None
    
    def match_batch(self, queries: List[str]) -> List[List[PatternMatch]]:
        """
        여러 쿼리 배치 처리 (API 호출 최적화)
        
        Args:
            queries: 쿼리 리스트
        
        Returns:
            각 쿼리별 매칭 결과
        """
        batch_prompt = f"""{self.system_prompt}

# 배치 쿼리 분석
다음 쿼리들을 각각 분석해주세요:

"""
        for i, query in enumerate(queries, 1):
            batch_prompt += f"{i}. \"{query}\"\n"
        
        batch_prompt += """
# 출력 형식
{
  "results": [
    {"query_num": 1, "matches": [...]},
    {"query_num": 2, "matches": [...]},
    ...
  ]
}"""
        
        try:
            response = self.model.generate_content(batch_prompt)
            result = json.loads(response.text)
            
            all_matches = []
            for query_result in result.get("results", []):
                matches = []
                for match_data in query_result.get("matches", []):
                    pattern_id = match_data.get("pattern_id")
                    if pattern_id in self.patterns:
                        pattern = self.patterns[pattern_id]
                        match = PatternMatch(
                            pattern_id=pattern_id,
                            pattern_name=pattern.name,
                            confidence_score=match_data.get("confidence", 0.5),
                            matched_keywords=match_data.get("keywords_matched", []),
                            extracted_slots=match_data.get("slots", {}),
                            missing_slots=[],
                            is_complete=True,
                            match_type="gemini_batch"
                        )
                        matches.append(match)
                all_matches.append(matches)
            
            return all_matches
            
        except Exception as e:
            logger.error(f"Batch processing failed: {e}")
            # 폴백: 개별 처리
            return [self.match_patterns(q) for q in queries]


class GeminiHybridMatcher:
    """
    하이브리드 매처 - 기본 매칭 + Gemini 폴백
    비용 최적화를 위한 전략
    """
    
    def __init__(self, api_key: str = None):
        from .pattern_matcher_v2 import ImprovedPatternMatcher
        
        self.basic_matcher = ImprovedPatternMatcher(min_confidence=0.3)
        self.gemini_matcher = GeminiPatternMatcher(api_key)
        self.gemini_threshold = 0.5  # 이 신뢰도 이하면 Gemini 호출
    
    def match_patterns(self, query: str, context: Dict[str, Any] = None) -> List[PatternMatch]:
        """
        1차: 기본 매처
        2차: 신뢰도 낮으면 Gemini
        """
        # 1. 기본 매칭 시도
        basic_matches = self.basic_matcher.match_patterns(query, context, use_fuzzy=True)
        
        # 2. 충분히 신뢰할 수 있으면 반환
        if basic_matches and basic_matches[0].confidence_score >= self.gemini_threshold:
            logger.debug(f"Using basic matcher results (confidence: {basic_matches[0].confidence_score:.2f})")
            return basic_matches
        
        # 3. Gemini로 재매칭
        logger.debug("Falling back to Gemini for better matching")
        gemini_matches = self.gemini_matcher.match_patterns(query, context)
        
        # 4. 결과 병합 (Gemini 우선)
        if gemini_matches:
            return gemini_matches
        
        return basic_matches  # Gemini도 실패하면 기본 결과 반환