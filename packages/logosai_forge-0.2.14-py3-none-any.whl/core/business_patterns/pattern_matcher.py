"""
Pattern Matching Engine - 패턴 매칭 엔진
사용자 쿼리를 분석하여 적절한 비즈니스 패턴을 찾고 슬롯 값을 추출
"""

import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from loguru import logger
import difflib

from .pattern_library import (
    BusinessPattern,
    PatternSlot,
    load_all_patterns,
    get_pattern_by_id
)


@dataclass
class PatternMatch:
    """패턴 매칭 결과"""
    pattern_id: str
    pattern_name: str
    confidence_score: float  # 0.0 ~ 1.0
    matched_keywords: List[str]
    extracted_slots: Dict[str, Any]
    missing_slots: List[str]
    is_complete: bool  # 모든 필수 슬롯이 채워졌는지
    match_type: str = "keyword"  # 매칭 타입: keyword, fuzzy, semantic, gemini_lite 등


class PatternMatcher:
    """패턴 매칭 엔진"""
    
    def __init__(self):
        """초기화"""
        self.patterns = load_all_patterns()
        logger.info(f"PatternMatcher initialized with {len(self.patterns)} patterns")
        
        # 키워드 인덱스 생성 (빠른 검색을 위해)
        self._build_keyword_index()
    
    def _build_keyword_index(self):
        """키워드 인덱스 구축"""
        self.keyword_index = {}
        
        for pattern_id, pattern in self.patterns.items():
            for keyword in pattern.trigger_keywords:
                keyword_lower = keyword.lower()
                if keyword_lower not in self.keyword_index:
                    self.keyword_index[keyword_lower] = []
                self.keyword_index[keyword_lower].append(pattern_id)
        
        logger.debug(f"Built keyword index with {len(self.keyword_index)} keywords")
    
    def match_patterns(self, query: str, context: Dict[str, Any] = None) -> List[PatternMatch]:
        """
        쿼리에 매칭되는 패턴들 찾기
        
        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트 정보
        
        Returns:
            매칭된 패턴 리스트 (신뢰도 순으로 정렬)
        """
        if not query:
            return []
        
        query_lower = query.lower()
        context = context or {}
        
        # 1. 키워드 기반 후보 패턴 찾기
        candidate_patterns = self._find_candidate_patterns(query_lower)
        
        # 2. 각 후보 패턴에 대해 매칭 수행
        matches = []
        for pattern_id in candidate_patterns:
            pattern = self.patterns[pattern_id]
            match = self._match_single_pattern(pattern, query, context)
            if match and match.confidence_score > 0.3:  # 최소 신뢰도 임계값
                matches.append(match)
        
        # 3. 신뢰도 순으로 정렬
        matches.sort(key=lambda x: x.confidence_score, reverse=True)
        
        logger.info(f"Found {len(matches)} pattern matches for query: {query[:50]}...")
        return matches
    
    def _find_candidate_patterns(self, query_lower: str) -> List[str]:
        """키워드 기반으로 후보 패턴 찾기"""
        pattern_scores = {}
        
        # 쿼리에서 각 키워드 검색
        for keyword, pattern_ids in self.keyword_index.items():
            if keyword in query_lower:
                for pattern_id in pattern_ids:
                    if pattern_id not in pattern_scores:
                        pattern_scores[pattern_id] = 0
                    pattern_scores[pattern_id] += 1
        
        # 점수 순으로 정렬
        sorted_patterns = sorted(pattern_scores.items(), key=lambda x: x[1], reverse=True)
        
        return [pattern_id for pattern_id, _ in sorted_patterns]
    
    def _match_single_pattern(self, pattern: BusinessPattern, query: str, context: Dict) -> Optional[PatternMatch]:
        """단일 패턴 매칭"""
        query_lower = query.lower()
        
        # 1. 키워드 매칭
        matched_keywords = []
        for keyword in pattern.trigger_keywords:
            if keyword.lower() in query_lower:
                matched_keywords.append(keyword)
        
        if not matched_keywords:
            return None
        
        # 2. 슬롯 추출
        extracted_slots = {}
        missing_slots = []
        
        for slot in pattern.slots:
            value = self._extract_slot_value(slot, query, context)
            if value is not None:
                extracted_slots[slot.name] = value
            elif slot.required:
                if slot.default is not None:
                    extracted_slots[slot.name] = slot.default
                else:
                    missing_slots.append(slot.name)
        
        # 3. 신뢰도 계산
        keyword_score = len(matched_keywords) / max(len(pattern.trigger_keywords), 1)
        slot_score = len(extracted_slots) / max(len(pattern.slots), 1) if pattern.slots else 1.0
        
        # 우선순위 보너스
        priority_bonus = pattern.priority / 100.0 if pattern.priority > 0 else 0
        
        confidence_score = (keyword_score * 0.5 + slot_score * 0.4 + priority_bonus * 0.1)
        
        # 4. 매칭 결과 생성
        return PatternMatch(
            pattern_id=pattern.id,
            pattern_name=pattern.name,
            confidence_score=min(confidence_score, 1.0),
            matched_keywords=matched_keywords,
            extracted_slots=extracted_slots,
            missing_slots=missing_slots,
            is_complete=len(missing_slots) == 0
        )
    
    def _extract_slot_value(self, slot: PatternSlot, query: str, context: Dict) -> Any:
        """슬롯 값 추출"""
        
        # 1. 컨텍스트에서 먼저 확인
        if slot.name in context:
            return self._convert_type(context[slot.name], slot.type)
        
        # 2. 정규식 추출
        if slot.extraction_regex:
            match = re.search(slot.extraction_regex, query)
            if match:
                value = match.group(1)
                return self._convert_type(value, slot.type)
        
        # 3. 예시 매핑을 통한 추출
        if slot.examples:
            for korean, english in slot.examples.items():
                if korean in query:
                    return english
        
        # 4. 특정 타입별 추출 로직
        if slot.type == "int":
            # 숫자 찾기
            numbers = re.findall(r'\d+', query)
            if numbers:
                return int(numbers[0])
        
        elif slot.type == "float":
            # 실수 찾기
            floats = re.findall(r'\d+(?:\.\d+)?', query)
            if floats:
                return float(floats[0])
        
        elif slot.type == "str":
            # 문자열은 특별한 추출 로직 없이 기본값 사용
            if slot.default is not None:
                return slot.default
        
        elif slot.type == "dict":
            # 딕셔너리는 기본값 사용
            if slot.default is not None:
                return slot.default
        
        elif slot.type == "list":
            # 리스트는 기본값 사용
            if slot.default is not None:
                return slot.default
        
        return None
    
    def _convert_type(self, value: Any, target_type: str) -> Any:
        """타입 변환"""
        try:
            if target_type == "int":
                return int(value)
            elif target_type == "float":
                return float(value)
            elif target_type == "str":
                return str(value)
            elif target_type == "bool":
                if isinstance(value, str):
                    return value.lower() in ['true', 'yes', '예', '네', '1']
                return bool(value)
            elif target_type == "dict":
                if isinstance(value, dict):
                    return value
                return {"value": value}
            elif target_type == "list":
                if isinstance(value, list):
                    return value
                return [value]
            else:
                return value
        except:
            return None
    
    def get_best_match(self, query: str, context: Dict[str, Any] = None) -> Optional[PatternMatch]:
        """가장 신뢰도 높은 매칭 결과 반환"""
        matches = self.match_patterns(query, context)
        return matches[0] if matches else None
    
    def combine_patterns(self, matches: List[PatternMatch]) -> Dict[str, Any]:
        """
        여러 패턴을 조합하여 통합된 비즈니스 로직 정보 생성
        
        Args:
            matches: 매칭된 패턴들
        
        Returns:
            통합된 패턴 정보
        """
        if not matches:
            return {}
        
        combined = {
            "patterns": [],
            "total_confidence": 0,
            "all_slots": {},
            "missing_slots": [],
            "is_complete": True
        }
        
        for match in matches:
            pattern_info = {
                "id": match.pattern_id,
                "name": match.pattern_name,
                "confidence": match.confidence_score,
                "slots": match.extracted_slots
            }
            combined["patterns"].append(pattern_info)
            
            # 슬롯 병합
            combined["all_slots"].update(match.extracted_slots)
            
            # 누락된 슬롯 수집
            combined["missing_slots"].extend(match.missing_slots)
            
            # 완전성 확인
            if not match.is_complete:
                combined["is_complete"] = False
            
            # 신뢰도 누적
            combined["total_confidence"] += match.confidence_score
        
        # 평균 신뢰도
        combined["average_confidence"] = combined["total_confidence"] / len(matches)
        
        return combined
    
    def suggest_missing_slots(self, match: PatternMatch) -> List[Dict[str, Any]]:
        """
        누락된 슬롯에 대한 추가 질문 생성
        
        Args:
            match: 패턴 매칭 결과
        
        Returns:
            추가 질문 리스트
        """
        if match.is_complete:
            return []
        
        pattern = self.patterns.get(match.pattern_id)
        if not pattern:
            return []
        
        questions = []
        for slot_name in match.missing_slots:
            # 슬롯 찾기
            slot = None
            for s in pattern.slots:
                if s.name == slot_name:
                    slot = s
                    break
            
            if slot:
                question = {
                    "slot_name": slot.name,
                    "slot_type": slot.type,
                    "description": slot.description or f"{slot.name}을(를) 입력해주세요",
                    "examples": list(slot.examples.keys()) if slot.examples else [],
                    "required": slot.required
                }
                questions.append(question)
        
        return questions


class FuzzyPatternMatcher(PatternMatcher):
    """퍼지 매칭을 지원하는 패턴 매처"""
    
    def __init__(self, similarity_threshold: float = 0.7):
        """
        Args:
            similarity_threshold: 유사도 임계값 (0.0 ~ 1.0)
        """
        super().__init__()
        self.similarity_threshold = similarity_threshold
    
    def _find_candidate_patterns(self, query_lower: str) -> List[str]:
        """퍼지 매칭을 사용한 후보 패턴 찾기"""
        pattern_scores = {}
        
        # 각 패턴의 키워드와 유사도 계산
        for pattern_id, pattern in self.patterns.items():
            max_similarity = 0
            
            for keyword in pattern.trigger_keywords:
                keyword_lower = keyword.lower()
                
                # 완전 일치
                if keyword_lower in query_lower:
                    max_similarity = 1.0
                    break
                
                # 부분 문자열 매칭
                if keyword_lower in query_lower or query_lower in keyword_lower:
                    max_similarity = max(max_similarity, 0.8)
                
                # 퍼지 매칭
                similarity = difflib.SequenceMatcher(None, keyword_lower, query_lower).ratio()
                
                # 단어 단위 퍼지 매칭
                query_words = query_lower.split()
                for word in query_words:
                    word_similarity = difflib.SequenceMatcher(None, keyword_lower, word).ratio()
                    similarity = max(similarity, word_similarity)
                
                max_similarity = max(max_similarity, similarity)
            
            if max_similarity >= self.similarity_threshold:
                pattern_scores[pattern_id] = max_similarity
        
        # 점수 순으로 정렬
        sorted_patterns = sorted(pattern_scores.items(), key=lambda x: x[1], reverse=True)
        
        return [pattern_id for pattern_id, _ in sorted_patterns]


def create_matcher(use_fuzzy: bool = False, **kwargs) -> PatternMatcher:
    """
    패턴 매처 생성 팩토리 함수
    
    Args:
        use_fuzzy: 퍼지 매칭 사용 여부
        **kwargs: 추가 설정 (FuzzyPatternMatcher의 경우 similarity_threshold 등)
    
    Returns:
        PatternMatcher 인스턴스
    """
    if use_fuzzy:
        return FuzzyPatternMatcher(**kwargs)
    else:
        return PatternMatcher()