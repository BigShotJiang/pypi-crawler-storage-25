"""
Gemini 2.5 Flash Lite Pattern Matcher
gemini-2.5-flash-lite 모델을 활용한 최적화된 패턴 매칭
"""

import json
import os
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from loguru import logger
from functools import lru_cache
import hashlib

from .pattern_library import (
    BusinessPattern,
    load_all_patterns,
    get_pattern_by_id
)
from .pattern_matcher import PatternMatch


class GeminiLitePatternMatcher:
    """Gemini 2.5 Flash Lite Preview를 활용한 경량 패턴 매처"""
    
    # 극도로 압축된 한국어 System Prompt (토큰 최소화)
    SYSTEM_PROMPT = """패턴매칭전문가. 한국어/영어 쿼리→비즈니스패턴 매칭.

# 패턴
{patterns}

# 규칙
- 의미매칭>키워드매칭
- 동의어인식: 할인=세일=discount, 회원=멤버=user, 통계=분석=stats, 알림=노티=alert
- 오타처리: 빕=VIP, 디비=DB
- 신뢰도: 0.9+=완벽, 0.7+=강함, 0.5+=관련, <0.3=제외

# 출력(JSON만)
{{"matches":[{{"id":"패턴ID","conf":0.9,"slots":{{}}}}]}}

예: "VIP 30% 할인"→{{"matches":[{{"id":"discount_rate_apply","conf":0.95,"slots":{{"rate":30}}}},{{"id":"tier_based_filtering","conf":0.8,"slots":{{}}}}]}}"""

    # 초압축 패턴 템플릿 (필수만)
    PATTERN_TEMPLATE = "{id}:{name}|{keywords}"

    def __init__(self, api_key: str = None):
        """
        Args:
            api_key: Gemini API key
        """
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is required")
        
        self.model_name = "gemini-2.5-flash-lite"
        self.patterns = load_all_patterns()
        self._init_llm_client()
        
        # 초압축 패턴 설명 생성
        self.system_prompt = self._create_minimal_prompt()
        
        logger.info(f"GeminiLite initialized with {len(self.patterns)} patterns using {self.model_name}")
    
    def _init_llm_client(self):
        """Gemini 클라이언트 초기화"""
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            # Gemini 2.5 Flash Lite Preview 설정 (초경량, 최고속)
            self.model = genai.GenerativeModel(
                self.model_name,
                generation_config={
                    "temperature": 0.0,  # 완전 일관성
                    "top_p": 0.9,
                    "top_k": 20,  # 더 제한적
                    "max_output_tokens": 200,  # 최소 출력
                }
            )
            logger.info(f"Gemini Lite client initialized with {self.model_name}")
        except ImportError:
            raise ImportError("Please install: pip install google-generativeai")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")
            raise
    
    def _create_minimal_prompt(self) -> str:
        """초압축 프롬프트 생성 (토큰 극소화)"""
        patterns_desc = []
        
        for pid, pattern in list(self.patterns.items())[:20]:  # 상위 20개만
            # 초압축 설명 (ID와 핵심 키워드만)
            keywords = ','.join(pattern.trigger_keywords[:3])  # 상위 3개만
            desc = self.PATTERN_TEMPLATE.format(
                id=pid,
                name=pattern.name[:15],  # 15자로 제한
                keywords=keywords
            )
            patterns_desc.append(desc)
        
        patterns_text = "\n".join(patterns_desc)  # 구분자도 최소화
        return self.SYSTEM_PROMPT.format(patterns=patterns_text)
    
    @lru_cache(maxsize=1024)  # 캐시 크기 대폭 증가
    def _cached_llm_match(self, query_hash: str, query: str) -> Dict:
        """LLM 매칭 결과 캐싱"""
        try:
            # 초압축 프롬프트
            prompt = f"{self.system_prompt}\n\nQ:\"{query}\""
            
            response = self.model.generate_content(prompt)
            result_text = response.text.strip()
            
            # JSON 정리
            if result_text.startswith("```"):
                result_text = result_text.split("```")[1]
                if result_text.startswith("json"):
                    result_text = result_text[4:]
                result_text = result_text.split("```")[0]
            
            result = json.loads(result_text.strip())
            
            # 간단한 형식 변환 (압축 응답 → 표준 형식)
            if "matches" in result:
                for match in result["matches"]:
                    # 압축 키 확장
                    if "id" in match:
                        match["pattern_id"] = match.pop("id")
                    if "conf" in match:
                        match["confidence"] = match.pop("conf")
                    if "slots" not in match:
                        match["slots"] = {}
            
            logger.debug(f"Gemini Lite response: {result}")
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}, Response: {result_text[:100]}") 
            return {"matches": []}
        except Exception as e:
            logger.error(f"LLM error: {e}")
            return {"matches": []}
    
    def match_patterns(self, query: str, context: Dict[str, Any] = None, 
                      use_cache: bool = True) -> List[PatternMatch]:
        """
        초경량 Gemini를 사용한 패턴 매칭
        
        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트
            use_cache: 캐시 사용 여부
        
        Returns:
            매칭된 패턴 리스트
        """
        if not query or len(query.strip()) < 2:
            return []
        
        context = context or {}
        
        # 쿼리 정규화 및 해싱
        normalized_query = query.strip().lower()
        query_hash = hashlib.md5(normalized_query.encode()).hexdigest()
        
        # LLM 호출 (캐싱 자동 적용)
        if use_cache:
            llm_result = self._cached_llm_match(query_hash, query)
        else:
            # 캐시 무시
            llm_result = self._cached_llm_match.__wrapped__(self, query_hash, query)
        
        # PatternMatch 객체 생성
        matches = []
        for match_data in llm_result.get("matches", []):
            pattern_id = match_data.get("pattern_id")
            if pattern_id not in self.patterns:
                continue
            
            pattern = self.patterns[pattern_id]
            
            # 슬롯 처리 (최소화)
            extracted_slots = match_data.get("slots", {})
            extracted_slots.update(context)
            
            # 필수 슬롯만 체크
            missing_slots = []
            for slot in pattern.slots:
                if slot.required and slot.name not in extracted_slots:
                    if slot.default is not None:
                        extracted_slots[slot.name] = slot.default
                    else:
                        missing_slots.append(slot.name)
            
            match = PatternMatch(
                pattern_id=pattern_id,
                pattern_name=pattern.name,
                confidence_score=min(match_data.get("confidence", 0.5), 1.0),
                matched_keywords=[],  # 생략 (토큰 절약)
                extracted_slots=extracted_slots,
                missing_slots=missing_slots,
                is_complete=len(missing_slots) == 0,
                match_type="gemini_lite"
            )
            
            matches.append(match)
        
        # 신뢰도 순 정렬
        matches.sort(key=lambda x: x.confidence_score, reverse=True)
        
        logger.info(f"Gemini Lite found {len(matches)} matches for: {query[:30]}...")
        return matches
    
    def get_best_match(self, query: str, context: Dict[str, Any] = None) -> Optional[PatternMatch]:
        """가장 신뢰도 높은 매칭 반환"""
        matches = self.match_patterns(query, context)
        return matches[0] if matches else None
    
    def match_batch(self, queries: List[str], max_batch_size: int = 10) -> List[List[PatternMatch]]:
        """
        여러 쿼리 초경량 배치 처리
        
        Args:
            queries: 쿼리 리스트
            max_batch_size: 한 번에 처리할 최대 쿼리 수
        
        Returns:
            각 쿼리별 매칭 결과
        """
        # 배치 크기 제한 (토큰 오버플로우 방지)
        batches = [queries[i:i+max_batch_size] for i in range(0, len(queries), max_batch_size)]
        all_results = []
        
        for batch in batches:
            batch_prompt = f"{self.system_prompt}\n\n배치:\n"
            for i, query in enumerate(batch, 1):
                batch_prompt += f"{i}.\"{query}\"\n"
            
            batch_prompt += '\n출력:[각쿼리별matches배열]'
            
            try:
                response = self.model.generate_content(batch_prompt)
                result = json.loads(response.text)
                
                # 결과 처리
                batch_results = []
                for query_result in result:
                    matches = []
                    for match_data in query_result.get("matches", []):
                        pattern_id = match_data.get("id") or match_data.get("pattern_id")
                        if pattern_id in self.patterns:
                            pattern = self.patterns[pattern_id]
                            match = PatternMatch(
                                pattern_id=pattern_id,
                                pattern_name=pattern.name,
                                confidence_score=match_data.get("conf", match_data.get("confidence", 0.5)),
                                matched_keywords=[],
                                extracted_slots=match_data.get("slots", {}),
                                missing_slots=[],
                                is_complete=True,
                                match_type="gemini_lite_batch"
                            )
                            matches.append(match)
                    batch_results.append(matches)
                
                all_results.extend(batch_results)
                
            except Exception as e:
                logger.error(f"Batch processing failed: {e}")
                # 폴백: 개별 처리
                for query in batch:
                    all_results.append(self.match_patterns(query))
        
        return all_results


class GeminiLiteHybridMatcher:
    """
    초경량 하이브리드 매처
    1차: 기본 매처 (무료)
    2차: Gemini Lite (초저렴)
    """
    
    def __init__(self, api_key: str = None):
        from .pattern_matcher_v2 import ImprovedPatternMatcher
        
        self.basic_matcher = ImprovedPatternMatcher(min_confidence=0.4)
        self.gemini_matcher = GeminiLitePatternMatcher(api_key)
        self.gemini_threshold = 0.6  # 더 높은 임계값
        
        logger.info("GeminiLiteHybridMatcher initialized")
    
    def match_patterns(self, query: str, context: Dict[str, Any] = None) -> List[PatternMatch]:
        """
        비용 최적화 매칭
        """
        # 1. 기본 매칭 시도
        basic_matches = self.basic_matcher.match_patterns(query, context, use_fuzzy=True)
        
        # 2. 충분히 신뢰할 수 있으면 반환
        if basic_matches and basic_matches[0].confidence_score >= self.gemini_threshold:
            logger.debug(f"Using basic matcher (confidence: {basic_matches[0].confidence_score:.2f})")
            return basic_matches
        
        # 3. Gemini Lite로 재매칭
        logger.debug("Using Gemini Lite for better matching")
        gemini_matches = self.gemini_matcher.match_patterns(query, context)
        
        return gemini_matches if gemini_matches else basic_matches
    
    def get_best_match(self, query: str, context: Dict[str, Any] = None) -> Optional[PatternMatch]:
        """가장 신뢰도 높은 매칭 반환"""
        matches = self.match_patterns(query, context)
        return matches[0] if matches else None