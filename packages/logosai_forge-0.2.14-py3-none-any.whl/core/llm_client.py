"""
LLM Client for Business Logic Generation
"""

import os
import json
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from loguru import logger


@dataclass
class LLMResponse:
    """LLM response wrapper"""
    content: str
    success: bool
    error: Optional[str] = None
    usage: Optional[Dict[str, int]] = None


class LLMClient:
    """LLM client for generating business logic"""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize LLM client"""
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model = "gpt-4o-mini"  # Use faster model
        self.temperature = 0.7
        self.max_tokens = 2000
        self.timeout = 10.0  # 10 second timeout
        
        # Try to import OpenAI
        self.openai_available = False
        self.client = None
        try:
            from openai import AsyncOpenAI
            if self.api_key:
                self.client = AsyncOpenAI(api_key=self.api_key)
                self.openai_available = True
                logger.info("OpenAI client initialized")
        except ImportError:
            logger.warning("OpenAI not available, using mock responses")
    
    async def generate(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None
    ) -> LLMResponse:
        """Generate response from LLM"""
        
        if self.openai_available and self.api_key:
            return await self._generate_openai(
                prompt,
                temperature or self.temperature,
                max_tokens or self.max_tokens,
                system_prompt
            )
        else:
            return self._generate_mock(prompt, system_prompt)
    
    async def _generate_openai(
        self,
        prompt: str,
        temperature: float,
        max_tokens: int,
        system_prompt: Optional[str]
    ) -> LLMResponse:
        """Generate using OpenAI API"""
        
        try:
            messages = []
            
            if system_prompt:
                messages.append({
                    "role": "system",
                    "content": system_prompt
                })
            
            messages.append({
                "role": "user",
                "content": prompt
            })
            
            # Add timeout to prevent hanging
            import asyncio
            response = await asyncio.wait_for(
                self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens
                ),
                timeout=self.timeout
            )
            
            content = response.choices[0].message.content
            usage = response.usage
            
            return LLMResponse(
                content=content,
                success=True,
                usage={
                    "prompt_tokens": usage.prompt_tokens,
                    "completion_tokens": usage.completion_tokens,
                    "total_tokens": usage.total_tokens
                }
            )
            
        except Exception as e:
            logger.error(f"OpenAI generation failed: {e}")
            return LLMResponse(
                content="",
                success=False,
                error=str(e)
            )
    
    def _generate_mock(
        self,
        prompt: str,
        system_prompt: Optional[str]
    ) -> LLMResponse:
        """Generate mock response for testing"""
        
        # Parse prompt to understand what's being requested
        prompt_lower = prompt.lower()
        
        if "csv" in prompt_lower and "analyze" in prompt_lower:
            content = """
# CSV Analysis Implementation

## Required imports
- pandas for data handling
- numpy for calculations
- logging for error tracking

## Implementation approach
1. Validate CSV file path
2. Load data with encoding detection
3. Perform statistical analysis
4. Generate insights and recommendations
5. Return structured results

## Error handling
- File not found errors
- Encoding issues
- Data validation errors
"""
        
        elif "email" in prompt_lower:
            content = """
# Email Sending Implementation

## Required imports
- smtplib for email sending
- email.mime for message formatting
- logging for tracking

## Implementation approach
1. Validate email addresses
2. Configure SMTP connection
3. Format message with attachments
4. Send with retry logic
5. Return status and tracking

## Error handling
- SMTP connection errors
- Authentication failures
- Invalid addresses
"""
        
        elif "sentiment" in prompt_lower or "classify" in prompt_lower:
            content = """
# Text Classification Implementation

## Required imports
- transformers for NLP models
- sklearn for fallback classification
- pandas for data handling

## Implementation approach
1. Preprocess text data
2. Load appropriate model
3. Perform classification
4. Calculate confidence scores
5. Return predictions with metadata

## Error handling
- Model loading errors
- Invalid input handling
- Memory management
"""
        
        elif "dashboard" in prompt_lower or "chart" in prompt_lower:
            content = """
# Dashboard Generation Implementation

## Required imports
- plotly for interactive charts
- pandas for data manipulation
- datetime for timestamps

## Implementation approach
1. Validate input data
2. Prepare data for visualization
3. Generate appropriate charts
4. Create dashboard layout
5. Return HTML and metadata

## Error handling
- Data validation
- Chart generation errors
- Export failures
"""
        
        else:
            # Generic business logic response
            content = """
# Business Logic Implementation

## Required imports
- Standard libraries for data processing
- Async support for performance
- Logging for monitoring

## Implementation approach
1. Input validation
2. Core business logic processing
3. Result generation
4. Error handling
5. Return structured output

## Error handling
- Input validation errors
- Processing exceptions
- Resource management
"""
        
        return LLMResponse(
            content=content,
            success=True,
            usage={
                "prompt_tokens": len(prompt.split()),
                "completion_tokens": len(content.split()),
                "total_tokens": len(prompt.split()) + len(content.split())
            }
        )
    
    async def generate_code(
        self,
        template: str,
        customizations: Dict[str, str],
        context: Dict[str, Any]
    ) -> str:
        """Generate code by filling template with LLM customizations"""
        
        code = template
        
        for placeholder, description in customizations.items():
            # Generate customization for this placeholder
            prompt = f"""
Generate Python code for the following customization point:
Context: {context.get('description', 'Business logic function')}
Placeholder: {placeholder}
Description: {description}
Requirements:
- Follow Python best practices
- Include error handling
- Add appropriate logging
- Keep it concise and focused
- Use the available variables from the template context

Generate only the code snippet, no explanations.
"""
            
            response = await self.generate(prompt)
            
            if response.success:
                # Clean up the response
                customization = response.content.strip()
                
                # Remove markdown code blocks if present
                if customization.startswith("```python"):
                    customization = customization[9:]
                if customization.startswith("```"):
                    customization = customization[3:]
                if customization.endswith("```"):
                    customization = customization[:-3]
                
                # Ensure proper indentation
                lines = customization.strip().split('\n')
                indented_lines = ['        ' + line for line in lines]
                customization = '\n'.join(indented_lines)
                
                # Replace placeholder
                code = code.replace(f"{{{placeholder}}}", customization)
            else:
                # Use default implementation
                default_impl = f"        # TODO: Implement {placeholder}\n        pass"
                code = code.replace(f"{{{placeholder}}}", default_impl)
        
        return code
    
    def validate_response(self, response: str) -> bool:
        """Validate LLM response"""
        
        # Check if response is not empty
        if not response or len(response.strip()) < 10:
            return False
        
        # Check for common error patterns
        error_patterns = [
            "I cannot",
            "I'm unable",
            "I don't have access",
            "As an AI",
            "I'm sorry"
        ]
        
        for pattern in error_patterns:
            if pattern in response:
                return False
        
        return True