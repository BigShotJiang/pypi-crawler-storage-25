"""
Sandbox Executor for FORGE AI
Executes generated agents in a secure sandboxed environment
"""

import sys
import asyncio
import tempfile
import subprocess
import resource
import json
import time
import ast
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass
from enum import Enum
import hashlib
from loguru import logger

class SecurityLevel(Enum):
    """Security levels for sandbox execution"""
    LOW = "low"        # Basic isolation
    MEDIUM = "medium"  # Resource limits + restricted imports
    HIGH = "high"      # Full isolation + monitoring

@dataclass
class ExecutionResult:
    """Result of sandbox execution"""
    success: bool
    output: Any
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: int
    memory_used_mb: int
    security_violations: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'success': self.success,
            'output': self.output,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'exit_code': self.exit_code,
            'execution_time_ms': self.execution_time_ms,
            'memory_used_mb': self.memory_used_mb,
            'security_violations': self.security_violations
        }


class SandboxExecutor:
    """Executes code in sandboxed environment"""
    
    # 추천: subprocess 격리 with 리소스 제한
    DEFAULT_LIMITS = {
        'max_memory_mb': 256,      # 256MB memory limit
        'max_cpu_seconds': 30,     # 30 second CPU time limit
        'max_file_size_mb': 10,    # 10MB file size limit
        'max_processes': 5,        # Max 5 subprocesses
        'max_open_files': 100      # Max 100 open files
    }
    
    # 위험한 operations 차단 리스트
    BLOCKED_IMPORTS = [
        'os', 'subprocess', 'sys.exit', '__import__', 'eval', 'exec',
        'compile', 'open', 'file', 'input', 'raw_input', '__builtins__'
    ]
    
    BLOCKED_OPERATIONS = [
        'socket.', 'urllib.', 'requests.', 'http.client',
        'subprocess.', 'os.system', 'os.popen', 'os.exec',
        'shutil.rmtree', 'shutil.move', 'pathlib.Path.unlink'
    ]
    
    def __init__(self, security_level: SecurityLevel = SecurityLevel.MEDIUM):
        self.security_level = security_level
        self.execution_dir = Path(tempfile.gettempdir()) / "forge_sandbox"
        self.execution_dir.mkdir(exist_ok=True)
    
    async def execute(self, 
                     code: str, 
                     input_data: Dict[str, Any],
                     timeout: int = 30) -> ExecutionResult:
        """Execute code in sandbox with given input"""
        
        logger.debug(f"Starting sandbox execution with timeout={timeout}s")
        logger.debug(f"Code length: {len(code)} chars")
        logger.debug(f"Input data: {input_data}")
        
        # 1. Security validation
        security_violations = self._validate_security(code)
        if security_violations and self.security_level != SecurityLevel.LOW:
            logger.warning(f"Security violations detected: {security_violations}")
            return ExecutionResult(
                success=False,
                output=None,
                stdout="",
                stderr="Security violations detected",
                exit_code=-1,
                execution_time_ms=0,
                memory_used_mb=0,
                security_violations=security_violations
            )
        
        # 2. Prepare sandbox environment
        sandbox_id = hashlib.md5(f"{code}{time.time()}".encode()).hexdigest()[:8]
        sandbox_dir = self.execution_dir / sandbox_id
        sandbox_dir.mkdir(exist_ok=True)
        
        logger.debug(f"Created sandbox directory: {sandbox_dir}")
        
        try:
            # 3. Create wrapper script
            wrapper_script = self._create_wrapper_script(code, input_data, sandbox_dir)
            logger.debug(f"Created wrapper script: {wrapper_script}")
            
            # 4. Execute in subprocess with limits
            result = await self._execute_subprocess(wrapper_script, sandbox_dir, timeout)
            
            logger.debug(f"Execution result: success={result.success}, exit_code={result.exit_code}")
            return result
            
        except Exception as e:
            logger.error(f"Sandbox execution error: {e}", exc_info=True)
            raise
            
        finally:
            # Cleanup
            if sandbox_dir.exists():
                logger.debug(f"Cleaning up sandbox directory: {sandbox_dir}")
                import shutil
                shutil.rmtree(sandbox_dir)
    
    def _validate_security(self, code: str) -> List[str]:
        """Validate code for security issues"""
        violations = []
        
        if self.security_level == SecurityLevel.LOW:
            return violations
        
        # Check blocked imports
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        # Allow logosai imports
                        if alias.name.startswith('logosai'):
                            continue
                        if any(blocked in alias.name for blocked in self.BLOCKED_IMPORTS):
                            violations.append(f"Blocked import: {alias.name}")
                            
                elif isinstance(node, ast.ImportFrom):
                    module = node.module or ''
                    # Allow logosai imports
                    if module.startswith('logosai'):
                        continue
                    if any(blocked in module for blocked in self.BLOCKED_IMPORTS):
                        violations.append(f"Blocked import: {module}")
        except:
            pass
        
        # Check blocked operations (string-based)
        for operation in self.BLOCKED_OPERATIONS:
            if operation in code:
                violations.append(f"Blocked operation: {operation}")
        
        # Additional checks for HIGH security
        if self.security_level == SecurityLevel.HIGH:
            # Check for file operations
            if any(op in code for op in ['open(', 'file(', 'Path(']):
                violations.append("File operations not allowed in HIGH security mode")
            
            # Check for network operations
            if any(op in code for op in ['socket', 'urllib', 'requests', 'http']):
                violations.append("Network operations not allowed in HIGH security mode")
        
        return violations
    
    def _create_wrapper_script(self, code: str, input_data: Dict[str, Any], 
                              sandbox_dir: Path) -> Path:
        """Create wrapper script for execution"""
        
        # Safe imports based on security level
        safe_imports = self._get_safe_imports()
        
        wrapper_code = f'''
import json
import sys
import traceback
import resource
import time
import re

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

# Set resource limits
try:
    resource.setrlimit(resource.RLIMIT_AS, ({self.DEFAULT_LIMITS['max_memory_mb']} * 1024 * 1024, 
                                            {self.DEFAULT_LIMITS['max_memory_mb']} * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_CPU, ({self.DEFAULT_LIMITS['max_cpu_seconds']}, 
                                             {self.DEFAULT_LIMITS['max_cpu_seconds']}))
    resource.setrlimit(resource.RLIMIT_NPROC, ({self.DEFAULT_LIMITS['max_processes']}, 
                                               {self.DEFAULT_LIMITS['max_processes']}))
except Exception as e:
    print(f"Warning: Could not set resource limits: {{e}}", file=sys.stderr)

# Load input data
input_data = {json.dumps(input_data)}

# Capture process info
start_time = time.time()
if HAS_PSUTIL:
    process = psutil.Process()
    start_memory = process.memory_info().rss / 1024 / 1024  # MB
else:
    start_memory = 0

# Restricted builtins
safe_builtins = {{
    '__name__': '__main__',
    '__doc__': None,
    'None': None,
    'False': False,
    'True': True,
    'abs': abs,
    'all': all,
    'any': any,
    'bool': bool,
    'dict': dict,
    'enumerate': enumerate,
    'filter': filter,
    'float': float,
    'int': int,
    'len': len,
    'list': list,
    'map': map,
    'max': max,
    'min': min,
    'print': print,
    'range': range,
    'round': round,
    'set': set,
    'sorted': sorted,
    'str': str,
    'sum': sum,
    'tuple': tuple,
    'type': type,
    'zip': zip,
}}

# Safe modules
safe_modules = {{
    'json': json,
    'math': __import__('math'),
    'random': __import__('random'),
    'datetime': __import__('datetime'),
    'collections': __import__('collections'),
    'itertools': __import__('itertools'),
    're': __import__('re'),
}}

# Create restricted globals
restricted_globals = {{
    '__builtins__': safe_builtins,
    'input_data': input_data,
    **safe_modules
}}

# Output container
output_data = {{'result': None, 'error': None}}

try:
    # User code to execute
    user_code = """
{code}
"""
    
    # 백틱 안전성 검사 및 제거 (exec 실행 전 최종 방어)
    if '```' in user_code:
        print(f"WARNING: Code contains backticks, removing them for safe execution", file=sys.stderr)
        # 모든 백틱 패턴 제거
        user_code = re.sub(r'```[a-zA-Z]*\\n?', '', user_code)
        user_code = re.sub(r'\\n?```', '', user_code)
        user_code = user_code.replace('```', '')
        user_code = user_code.replace('`', '')
    
    # Execute user code
    exec(user_code, restricted_globals)

# Call main function if exists
if 'main' in locals():
    output_data['result'] = main(input_data)
elif 'process' in locals():
    output_data['result'] = process(input_data)
else:
    # Try to find any function that takes input
    for name, obj in locals().items():
        if callable(obj) and not name.startswith('_'):
            try:
                output_data['result'] = obj(input_data)
                break
            except:
                pass
\"\"\", restricted_globals, {{}})
    
except Exception as e:
    output_data['error'] = {{
        'type': type(e).__name__,
        'message': str(e),
        'traceback': traceback.format_exc()
    }}

# Capture final metrics
end_time = time.time()
if HAS_PSUTIL:
    end_memory = process.memory_info().rss / 1024 / 1024  # MB
else:
    end_memory = start_memory

# Write output
output = {{
    'success': output_data['error'] is None,
    'result': output_data['result'],
    'error': output_data['error'],
    'execution_time_ms': int((end_time - start_time) * 1000),
    'memory_used_mb': int(end_memory - start_memory)
}}

with open('output.json', 'w') as f:
    json.dump(output, f)
'''
        
        # Write wrapper script
        wrapper_path = sandbox_dir / "wrapper.py"
        with open(wrapper_path, 'w') as f:
            f.write(wrapper_code)
            
        return wrapper_path
    
    async def _execute_subprocess(self, script_path: Path, 
                                 sandbox_dir: Path, timeout: int) -> ExecutionResult:
        """Execute script in subprocess with limits"""
        
        # Prepare command based on security level
        if self.security_level == SecurityLevel.HIGH:
            # Use more isolation (could use Docker in production)
            cmd = [
                sys.executable, 
                "-u",  # Unbuffered output
                "-B",  # Don't write bytecode
                str(script_path)
            ]
        else:
            cmd = [sys.executable, str(script_path)]
        
        # Execute
        start_time = time.time()
        
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(sandbox_dir),
                env=self._get_safe_env()
            )
            
            # Wait with timeout
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), 
                timeout=timeout
            )
            
            execution_time = int((time.time() - start_time) * 1000)
            
            # Parse output
            output_file = sandbox_dir / "output.json"
            if output_file.exists():
                with open(output_file, 'r') as f:
                    output_data = json.load(f)
                    
                return ExecutionResult(
                    success=output_data.get('success', False),
                    output=output_data.get('result'),
                    stdout=stdout.decode('utf-8', errors='replace'),
                    stderr=stderr.decode('utf-8', errors='replace'),
                    exit_code=process.returncode or 0,
                    execution_time_ms=output_data.get('execution_time_ms', execution_time),
                    memory_used_mb=output_data.get('memory_used_mb', 0),
                    security_violations=[]
                )
            else:
                # Execution failed
                return ExecutionResult(
                    success=False,
                    output=None,
                    stdout=stdout.decode('utf-8', errors='replace'),
                    stderr=stderr.decode('utf-8', errors='replace'),
                    exit_code=process.returncode or -1,
                    execution_time_ms=execution_time,
                    memory_used_mb=0,
                    security_violations=[]
                )
                
        except asyncio.TimeoutError:
            return ExecutionResult(
                success=False,
                output=None,
                stdout="",
                stderr="Execution timeout",
                exit_code=-1,
                execution_time_ms=timeout * 1000,
                memory_used_mb=0,
                security_violations=["Execution timeout"]
            )
    
    def _get_safe_imports(self) -> List[str]:
        """Get list of safe imports based on security level"""
        if self.security_level == SecurityLevel.LOW:
            return ['json', 'math', 'random', 'datetime', 'collections', 
                   'itertools', 're', 'numpy', 'pandas']
        elif self.security_level == SecurityLevel.MEDIUM:
            return ['json', 'math', 'random', 'datetime', 'collections', 
                   'itertools', 're']
        else:  # HIGH
            return ['json', 'math', 'random', 'datetime']
    
    def _get_safe_env(self) -> Dict[str, str]:
        """Get safe environment variables"""
        safe_env = {
            'PYTHONPATH': '',
            'PATH': '/usr/bin:/bin',
            'HOME': str(self.execution_dir),
            'TMPDIR': str(self.execution_dir),
            'PYTHONDONTWRITEBYTECODE': '1',
            'PYTHONUNBUFFERED': '1'
        }
        
        if self.security_level == SecurityLevel.HIGH:
            # Even more restricted environment
            safe_env['PYTHONHASHSEED'] = '0'  # Deterministic hashing
            
        return safe_env


# Example usage
if __name__ == "__main__":
    sample_code = '''
def analyze_data(input_data):
    """Analyze input data and return statistics"""
    values = input_data.get('values', [])
    
    if not values:
        return {'error': 'No values provided'}
    
    result = {
        'count': len(values),
        'sum': sum(values),
        'average': sum(values) / len(values),
        'min': min(values),
        'max': max(values)
    }
    
    return result
'''
    
    async def test_sandbox():
        executor = SandboxExecutor(SecurityLevel.MEDIUM)
        
        # Test normal execution
        result = await executor.execute(
            sample_code,
            {'values': [1, 2, 3, 4, 5]},
            timeout=5
        )
        
        print("Execution result:")
        print(f"Success: {result.success}")
        print(f"Output: {result.output}")
        print(f"Execution time: {result.execution_time_ms}ms")
        print(f"Memory used: {result.memory_used_mb}MB")
        
        # Test with dangerous code
        dangerous_code = '''
import os
os.system("ls -la")
'''
        
        result2 = await executor.execute(
            dangerous_code,
            {},
            timeout=5
        )
        
        print("\nDangerous code result:")
        print(f"Success: {result2.success}")
        print(f"Security violations: {result2.security_violations}")
    
    asyncio.run(test_sandbox())