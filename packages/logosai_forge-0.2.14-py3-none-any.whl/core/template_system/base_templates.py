"""
Base Templates for Function Generation
"""

from typing import Dict, Optional
from enum import Enum


class FunctionCategory(Enum):
    """Function categories"""
    DATA_IO = "data_io"
    ANALYSIS = "analysis"
    ML_AI = "ml_ai"
    VISUALIZATION = "visualization"
    TRANSFORMATION = "transformation"
    INTEGRATION = "integration"
    GENERAL = "general"


class BaseTemplates:
    """Base templates for all generated functions"""
    
    # Async function template for I/O operations
    ASYNC_FUNCTION_TEMPLATE = '''
async def {function_name}(self, {parameters}) -> {return_type}:
    """{description}
    
    Args:
        {args_description}
    
    Returns:
        {return_description}
    
    Raises:
        {raises_description}
    """
    # Initialize result/metadata
    {initialization_block}
    
    # Input validation
    try:
        {validation_block}
    except ValueError as e:
        logger.error(f"{function_name} - Input validation failed: {{e}}")
        raise
    
    # Core business logic
    try:
        {business_logic_block}
        
        # Result validation
        {result_validation}
        
        return {return_statement}
        
    except {specific_exceptions} as e:
        logger.warning(f"{function_name} - Expected error: {{e}}")
        {error_recovery}
        
    except Exception as e:
        logger.error(f"{function_name} - Unexpected error: {{e}}")
        raise
'''
    
    # Sync function template for computations
    SYNC_FUNCTION_TEMPLATE = '''
def {function_name}(self, {parameters}) -> {return_type}:
    """{description}
    
    Args:
        {args_description}
    
    Returns:
        {return_description}
    """
    try:
        # Input validation
        {validation_block}
        
        # Core logic
        {business_logic_block}
        
        return {return_statement}
        
    except Exception as e:
        logger.error(f"{function_name} error: {{e}}")
        raise
'''
    
    # Data processing function template
    DATA_PROCESSING_TEMPLATE = '''
async def {function_name}(self, data: {input_type}, options: Optional[Dict[str, Any]] = None) -> {output_type}:
    """{description}
    
    Args:
        data: Input data to process
        options: Processing options
    
    Returns:
        {output_type}: Processed data
    """
    # Option initialization
    options = options or {{}}
    {default_options}
    
    # Data validation
    if not {data_validation}:
        raise ValueError("{validation_error_message}")
    
    # Metadata tracking
    metadata = {{
        "operation": "{function_name}",
        "started_at": datetime.now().isoformat(),
        "input_shape": {input_shape_logic}
    }}
    
    # Preprocessing
    {preprocessing_block}
    
    # Main processing
    try:
        result = {processing_logic}
        
        # Postprocessing
        {postprocessing_block}
        
        # Update metadata
        metadata.update({{
            "completed_at": datetime.now().isoformat(),
            "output_shape": {output_shape_logic},
            "success": True
        }})
        
        # Logging
        logger.info(f"{{self.__class__.__name__}}.{function_name} - Processing completed")
        
        return result, metadata
        
    except Exception as e:
        metadata["error"] = str(e)
        logger.error(f"Data processing failed: {{e}}")
        {fallback_logic}
'''
    
    # Analysis function template
    ANALYSIS_TEMPLATE = '''
async def {function_name}(self, data: Any, config: Optional[Dict] = None) -> Dict[str, Any]:
    """{description}
    
    Args:
        data: Data to analyze
        config: Analysis configuration
    
    Returns:
        Dict containing:
        - summary: Summary statistics/results
        - details: Detailed analysis results
        - metrics: Numerical metrics
        - recommendations: Optional recommendations
    """
    result = {{
        "analysis_type": "{analysis_type}",
        "summary": {{}},
        "details": [],
        "metrics": {{}},
        "timestamp": datetime.now().isoformat()
    }}
    
    try:
        # Configuration setup
        config = config or {{}}
        {config_setup}
        
        # Data validation
        {validation_logic}
        
        # Analysis execution
        {analysis_logic}
        
        # Summary generation
        result["summary"] = {summary_logic}
        
        # Detail compilation
        result["details"] = {details_logic}
        
        # Metrics calculation
        result["metrics"] = {metrics_logic}
        
        # Optional recommendations
        if config.get("include_recommendations", False):
            result["recommendations"] = {recommendations_logic}
        
        logger.info(f"Analysis completed: {{result['analysis_type']}}")
        return result
        
    except Exception as e:
        logger.error(f"Analysis failed: {{e}}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''
    
    # ML/AI function template
    ML_TEMPLATE = '''
async def {function_name}(self, features: Any, model_config: Optional[Dict] = None) -> Dict[str, Any]:
    """{description}
    
    Args:
        features: Input features for model
        model_config: Model configuration
    
    Returns:
        Dict containing:
        - predictions: Model predictions
        - confidence: Confidence scores
        - model_info: Model information
        - performance: Optional performance metrics
    """
    result = {{
        "model_type": "{model_type}",
        "predictions": [],
        "confidence": [],
        "model_info": {{}},
        "timestamp": datetime.now().isoformat()
    }}
    
    try:
        # Model configuration
        model_config = model_config or {{}}
        {model_setup}
        
        # Feature validation and preprocessing
        {feature_preprocessing}
        
        # Model loading/initialization
        {model_initialization}
        
        # Prediction
        {prediction_logic}
        
        # Confidence calculation
        {confidence_logic}
        
        # Model information
        result["model_info"] = {{
            "type": "{model_type}",
            "config": model_config,
            "feature_count": {feature_count_logic}
        }}
        
        # Optional performance metrics
        if model_config.get("calculate_metrics", False):
            result["performance"] = {performance_metrics}
        
        logger.info(f"ML prediction completed: {{len(result['predictions'])}} predictions")
        return result
        
    except Exception as e:
        logger.error(f"ML operation failed: {{e}}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''
    
    # Visualization function template
    VISUALIZATION_TEMPLATE = '''
def {function_name}(self, data: Any, chart_config: Optional[Dict] = None) -> Dict[str, Any]:
    """{description}
    
    Args:
        data: Data to visualize
        chart_config: Chart configuration
    
    Returns:
        Dict containing:
        - chart_type: Type of chart
        - data: Prepared chart data
        - options: Chart options
        - html: Optional HTML representation
    """
    result = {{
        "chart_type": "{chart_type}",
        "data": {{}},
        "options": {{}},
        "timestamp": datetime.now().isoformat()
    }}
    
    try:
        # Configuration setup
        chart_config = chart_config or {{}}
        {config_setup}
        
        # Data preparation
        {data_preparation}
        
        # Chart creation
        {chart_creation}
        
        # Options configuration
        result["options"] = {{
            "responsive": chart_config.get("responsive", True),
            "title": chart_config.get("title", "{default_title}"),
            {additional_options}
        }}
        
        # HTML generation (optional)
        if chart_config.get("generate_html", False):
            result["html"] = {html_generation}
        
        logger.info(f"Chart generated: {{result['chart_type']}}")
        return result
        
    except Exception as e:
        logger.error(f"Visualization failed: {{e}}")
        result["error"] = str(e)
        result["success"] = False
        return result
'''
    
    # Integration function template
    INTEGRATION_TEMPLATE = '''
async def {function_name}(self, {parameters}) -> Dict[str, Any]:
    """{description}
    
    Args:
        {args_description}
    
    Returns:
        Dict containing:
        - status: Operation status
        - response: Response data
        - metadata: Operation metadata
    """
    result = {{
        "operation": "{operation_type}",
        "status": "pending",
        "response": None,
        "metadata": {{}},
        "timestamp": datetime.now().isoformat()
    }}
    
    try:
        # Connection/client setup
        {connection_setup}
        
        # Authentication (if needed)
        {authentication}
        
        # Request preparation
        {request_preparation}
        
        # Execute operation with retry logic
        max_retries = {max_retries}
        for attempt in range(max_retries):
            try:
                {operation_execution}
                
                result["status"] = "success"
                result["response"] = {response_processing}
                break
                
            except {retry_exceptions} as e:
                if attempt < max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise
        
        # Metadata update
        result["metadata"] = {metadata_update}
        
        logger.info(f"Integration operation completed: {{result['operation']}}")
        return result
        
    except Exception as e:
        logger.error(f"Integration failed: {{e}}")
        result["status"] = "failed"
        result["error"] = str(e)
        return result
    finally:
        # Cleanup
        {cleanup_logic}
'''
    
    @classmethod
    def get_template(cls, category: FunctionCategory, async_required: bool = True) -> str:
        """Get appropriate template for category"""
        
        template_mapping = {
            FunctionCategory.DATA_IO: cls.ASYNC_FUNCTION_TEMPLATE if async_required else cls.SYNC_FUNCTION_TEMPLATE,
            FunctionCategory.ANALYSIS: cls.ANALYSIS_TEMPLATE,
            FunctionCategory.ML_AI: cls.ML_TEMPLATE,
            FunctionCategory.VISUALIZATION: cls.VISUALIZATION_TEMPLATE,
            FunctionCategory.TRANSFORMATION: cls.DATA_PROCESSING_TEMPLATE,
            FunctionCategory.INTEGRATION: cls.INTEGRATION_TEMPLATE,
            FunctionCategory.GENERAL: cls.ASYNC_FUNCTION_TEMPLATE if async_required else cls.SYNC_FUNCTION_TEMPLATE
        }
        
        return template_mapping.get(category, cls.SYNC_FUNCTION_TEMPLATE)
    
    @classmethod
    def get_imports_for_category(cls, category: FunctionCategory) -> list:
        """Get common imports for category"""
        
        common_imports = [
            "import asyncio",
            "import json",
            "from typing import Dict, Any, Optional, List, Tuple",
            "from datetime import datetime",
            "from loguru import logger"
        ]
        
        category_imports = {
            FunctionCategory.DATA_IO: [
                "import pandas as pd",
                "import os",
                "import aiohttp",
                "import csv"
            ],
            FunctionCategory.ANALYSIS: [
                "import pandas as pd",
                "import numpy as np",
                "from scipy import stats"
            ],
            FunctionCategory.ML_AI: [
                "import numpy as np",
                "from sklearn.preprocessing import StandardScaler",
                "import joblib"
            ],
            FunctionCategory.VISUALIZATION: [
                "import plotly.graph_objects as go",
                "import plotly.express as px",
                "import matplotlib.pyplot as plt"
            ],
            FunctionCategory.TRANSFORMATION: [
                "import pandas as pd",
                "import numpy as np",
                "from sklearn.preprocessing import StandardScaler"
            ],
            FunctionCategory.INTEGRATION: [
                "import aiohttp",
                "import smtplib",
                "from email.mime.text import MIMEText"
            ]
        }
        
        return common_imports + category_imports.get(category, [])