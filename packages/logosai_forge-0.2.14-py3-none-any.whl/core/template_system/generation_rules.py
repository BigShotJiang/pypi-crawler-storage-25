"""
Function Generation Rules
"""

from typing import Dict, List, Optional
from dataclasses import dataclass
import re


@dataclass
class CategoryRules:
    """Rules for a specific function category"""
    naming_pattern: str
    async_required: bool
    must_return: str
    must_include: List[str]
    forbidden_patterns: List[str]
    structure_requirements: Dict[str, bool]
    validation_requirements: List[str]


class GenerationRules:
    """Function generation rules by category"""
    
    RULES = {
        "data_io": CategoryRules(
            naming_pattern=r"^_(?:load|read|fetch|save|write|export)_\w+$",
            async_required=True,
            must_return="Tuple[data, metadata] or Dict with 'data' and 'metadata' keys",
            must_include=[
                "input_validation",
                "error_handling",
                "logging",
                "metadata_generation"
            ],
            forbidden_patterns=["print", "global", "exec", "eval", "pass", "TODO"],
            structure_requirements={
                "try_except": True,
                "specific_exceptions": True,
                "return_metadata": True,
                "cleanup_finally": True
            },
            validation_requirements=[
                "Check if input source exists/is valid",
                "Validate data format",
                "Handle empty data cases"
            ]
        ),
        
        "analysis": CategoryRules(
            naming_pattern=r"^_analyze_\w+$",
            async_required=True,
            must_return="Dict with keys: summary, details, metrics, timestamp",
            must_include=[
                "data_validation",
                "result_structure",
                "metrics_calculation",
                "summary_generation"
            ],
            forbidden_patterns=["print", "global", "exec", "eval", "pass", "TODO"],
            structure_requirements={
                "result_dict_initialization": True,
                "timestamp": True,
                "error_info_in_result": True,
                "graceful_degradation": True
            },
            validation_requirements=[
                "Validate input data is not empty",
                "Check data types",
                "Validate analysis parameters"
            ]
        ),
        
        "ml_ai": CategoryRules(
            naming_pattern=r"^_(?:predict|classify|cluster|train|evaluate)_\w+$",
            async_required=False,
            must_return="Dict with keys: predictions/results, confidence, model_info",
            must_include=[
                "feature_validation",
                "model_handling",
                "confidence_scores",
                "model_metadata"
            ],
            forbidden_patterns=["print", "global", "exec", "eval", "pass", "TODO"],
            structure_requirements={
                "model_info_tracking": True,
                "performance_metrics": True,
                "feature_importance": False,
                "explainability": False
            },
            validation_requirements=[
                "Validate feature dimensions",
                "Check for missing values",
                "Validate model compatibility"
            ]
        ),
        
        "visualization": CategoryRules(
            naming_pattern=r"^_(?:create|generate|plot|render|draw)_\w+$",
            async_required=False,
            must_return="Dict with keys: chart_type, data, options, and optionally html/json",
            must_include=[
                "data_preparation",
                "chart_configuration",
                "output_format",
                "responsive_design"
            ],
            forbidden_patterns=["print", "global", "exec", "eval", "pass", "TODO"],
            structure_requirements={
                "chart_config": True,
                "responsive_design": True,
                "export_formats": True,
                "interactivity": False
            },
            validation_requirements=[
                "Validate data for visualization",
                "Check chart type compatibility",
                "Validate configuration options"
            ]
        ),
        
        "transformation": CategoryRules(
            naming_pattern=r"^_(?:transform|convert|normalize|aggregate|clean|filter)_\w+$",
            async_required=False,
            must_return="Transformed data with same or compatible structure, plus metadata",
            must_include=[
                "type_checking",
                "transformation_logic",
                "validation",
                "shape_preservation"
            ],
            forbidden_patterns=["print", "global", "exec", "eval", "pass", "TODO"],
            structure_requirements={
                "type_preservation": True,
                "reversibility_info": False,
                "transformation_report": True,
                "data_lineage": False
            },
            validation_requirements=[
                "Validate input data structure",
                "Check transformation compatibility",
                "Validate output consistency"
            ]
        ),
        
        "integration": CategoryRules(
            naming_pattern=r"^_(?:send|receive|connect|integrate|sync|webhook|notify)_\w+$",
            async_required=True,
            must_return="Dict with keys: status, response, metadata",
            must_include=[
                "connection_handling",
                "retry_logic",
                "timeout_handling",
                "authentication"
            ],
            forbidden_patterns=["print", "global", "exec", "eval", "pass", "TODO"],
            structure_requirements={
                "retry_mechanism": True,
                "connection_pooling": False,
                "rate_limiting": True,
                "circuit_breaker": False
            },
            validation_requirements=[
                "Validate connection parameters",
                "Check authentication credentials",
                "Validate request format"
            ]
        )
    }
    
    @classmethod
    def get_rules(cls, category: str) -> Optional[CategoryRules]:
        """Get rules for a specific category"""
        return cls.RULES.get(category)
    
    @classmethod
    def validate_function_name(cls, name: str, category: str) -> bool:
        """Validate function name against category rules"""
        rules = cls.get_rules(category)
        if not rules:
            return True  # No rules, allow any name
        
        return bool(re.match(rules.naming_pattern, name))
    
    @classmethod
    def check_forbidden_patterns(cls, code: str, category: str) -> List[str]:
        """Check for forbidden patterns in code"""
        rules = cls.get_rules(category)
        if not rules:
            return []
        
        violations = []
        for pattern in rules.forbidden_patterns:
            if pattern in code:
                violations.append(f"Forbidden pattern found: {pattern}")
        
        return violations
    
    @classmethod
    def get_required_elements(cls, category: str) -> List[str]:
        """Get required elements for a category"""
        rules = cls.get_rules(category)
        if not rules:
            return []
        
        return rules.must_include
    
    @classmethod
    def get_generation_prompt(cls, category: str) -> str:
        """Get generation prompt for a category"""
        rules = cls.get_rules(category)
        if not rules:
            return ""
        
        prompt = f"""
FUNCTION GENERATION RULES FOR {category.upper()}:

1. NAMING CONVENTION:
   - Function name MUST match pattern: {rules.naming_pattern}
   - Examples: _load_csv_data, _analyze_statistics, _create_chart

2. ASYNC REQUIREMENT:
   - Async required: {rules.async_required}
   {"- Use 'async def' and 'await' for I/O operations" if rules.async_required else "- Use regular 'def' for synchronous operations"}

3. RETURN TYPE:
   - MUST return: {rules.must_return}

4. REQUIRED ELEMENTS:
   - MUST include ALL of the following:
   {chr(10).join(f"   • {element}" for element in rules.must_include)}

5. FORBIDDEN PATTERNS:
   - DO NOT use any of these:
   {chr(10).join(f"   • {pattern}" for pattern in rules.forbidden_patterns)}

6. STRUCTURE REQUIREMENTS:
{chr(10).join(f"   • {req}: {'Required' if val else 'Optional'}" for req, val in rules.structure_requirements.items())}

7. VALIDATION REQUIREMENTS:
{chr(10).join(f"   • {req}" for req in rules.validation_requirements)}

IMPORTANT:
- Generate production-ready code with proper error handling
- Include comprehensive logging for debugging
- Use type hints for all parameters and returns
- Add detailed docstrings with Args, Returns, and Raises sections
- Handle edge cases and provide graceful degradation
"""
        
        return prompt