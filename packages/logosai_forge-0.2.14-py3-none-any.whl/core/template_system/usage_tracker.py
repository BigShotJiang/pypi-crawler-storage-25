"""
Usage Tracking System for Function Generation
"""

import sqlite3
import json
import re
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
from dataclasses import dataclass, asdict
import os
from loguru import logger


@dataclass
class GenerationRecord:
    """Record of a function generation event"""
    function_name: str
    function_pattern: str
    query_original: str
    generated_code: str
    generation_method: str  # 'template' or 'llm'
    success: bool = True
    error_message: Optional[str] = None


@dataclass
class PatternStatistics:
    """Statistics for a pattern"""
    pattern_id: str
    pattern_description: str
    category: str
    total_generations: int
    unique_queries: int
    first_seen: str
    last_seen: str
    converted_to_template: bool
    template_id: Optional[str]
    average_success_rate: float


class PatternExtractor:
    """Extract and generalize patterns from functions"""
    
    def __init__(self):
        self.entity_patterns = [
            (r'customer|user|client', '{entity}'),
            (r'sales|revenue|profit|cost', '{metric}'),
            (r'daily|weekly|monthly|yearly', '{period}'),
            (r'csv|json|xml|excel|pdf', '{format}'),
            (r'email|sms|slack|webhook', '{channel}'),
            (r'create|read|update|delete', '{operation}')
        ]
    
    def extract_pattern(self, func_name: str, func_code: str, query: str) -> Dict[str, Any]:
        """Extract reusable pattern from function"""
        
        # Extract pattern from function name
        name_pattern = self._extract_name_pattern(func_name)
        
        # Extract code structure
        code_structure = self._extract_code_structure(func_code)
        
        # Extract intent from query
        intent = self._extract_intent(query)
        
        # Generate pattern ID
        pattern_id = self._generate_pattern_id(name_pattern, code_structure)
        
        return {
            "pattern_id": pattern_id,
            "name_pattern": name_pattern,
            "code_structure": code_structure,
            "intent": intent,
            "category": self._determine_category(func_name, func_code)
        }
    
    def _extract_name_pattern(self, func_name: str) -> str:
        """Convert function name to pattern"""
        result = func_name
        
        for pattern, replacement in self.entity_patterns:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
        
        # Replace numbers with pattern
        result = re.sub(r'\d+', '{number}', result)
        
        return result
    
    def _extract_code_structure(self, func_code: str) -> Dict[str, Any]:
        """Analyze code structure"""
        structure = {
            "has_async": "async def" in func_code,
            "has_try_except": "try:" in func_code and "except" in func_code,
            "has_logging": "logger." in func_code,
            "has_validation": "if not" in func_code or "raise ValueError" in func_code,
            "returns_tuple": "Tuple[" in func_code,
            "returns_dict": "Dict[" in func_code or "return {" in func_code,
            "uses_pandas": "pd." in func_code or "DataFrame" in func_code,
            "uses_numpy": "np." in func_code or "numpy" in func_code,
            "line_count": len(func_code.split('\n'))
        }
        
        return structure
    
    def _extract_intent(self, query: str) -> List[str]:
        """Extract intent keywords from query"""
        intent_keywords = {
            "load": ["load", "read", "fetch", "get", "import"],
            "analyze": ["analyze", "calculate", "compute", "evaluate"],
            "transform": ["transform", "convert", "clean", "process"],
            "visualize": ["visualize", "plot", "chart", "graph", "display"],
            "predict": ["predict", "forecast", "estimate", "classify"],
            "integrate": ["send", "notify", "connect", "integrate", "sync"]
        }
        
        query_lower = query.lower()
        intents = []
        
        for intent, keywords in intent_keywords.items():
            if any(kw in query_lower for kw in keywords):
                intents.append(intent)
        
        return intents
    
    def _determine_category(self, func_name: str, func_code: str) -> str:
        """Determine function category"""
        categories = {
            "data_io": ["load", "read", "save", "write", "fetch"],
            "analysis": ["analyze", "calculate", "statistics", "correlation"],
            "ml_ai": ["predict", "classify", "train", "model"],
            "visualization": ["plot", "chart", "graph", "visualize"],
            "transformation": ["transform", "clean", "aggregate", "filter"],
            "integration": ["send", "webhook", "email", "notify"]
        }
        
        func_lower = func_name.lower()
        
        for category, keywords in categories.items():
            if any(kw in func_lower for kw in keywords):
                return category
        
        return "general"
    
    def _generate_pattern_id(self, name_pattern: str, structure: Dict) -> str:
        """Generate unique pattern ID"""
        # Create a simple hash from pattern elements
        elements = [
            name_pattern,
            str(structure.get("returns_dict", False)),
            str(structure.get("uses_pandas", False))
        ]
        
        # Simple string-based ID
        pattern_str = "_".join(elements).replace(" ", "_").lower()
        pattern_str = re.sub(r'[^a-z0-9_{}]', '', pattern_str)
        
        return pattern_str[:50]  # Limit length


class UsageTracker:
    """Track function generation and usage"""
    
    def __init__(self, db_path: str = None):
        if db_path is None:
            os.makedirs("forge/data", exist_ok=True)
            db_path = "forge/data/function_history.db"
        
        self.db_path = db_path
        self.pattern_extractor = PatternExtractor()
        self._init_database()
        logger.info(f"Usage tracker initialized with database: {db_path}")
    
    def _init_database(self):
        """Initialize SQLite database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Function generation history
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS function_generation (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                function_name TEXT NOT NULL,
                function_pattern TEXT NOT NULL,
                query_original TEXT NOT NULL,
                generated_code TEXT NOT NULL,
                generation_method TEXT NOT NULL,
                success BOOLEAN DEFAULT TRUE,
                error_message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                usage_count INTEGER DEFAULT 0,
                last_used TIMESTAMP
            )
        ''')
        
        # Pattern statistics
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pattern_statistics (
                pattern_id TEXT PRIMARY KEY,
                pattern_description TEXT,
                category TEXT,
                total_generations INTEGER DEFAULT 0,
                unique_queries INTEGER DEFAULT 0,
                success_count INTEGER DEFAULT 0,
                first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen TIMESTAMP,
                converted_to_template BOOLEAN DEFAULT FALSE,
                template_id TEXT
            )
        ''')
        
        # Query patterns
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS query_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT NOT NULL,
                extracted_intents TEXT,
                required_functions TEXT,
                workflow_type TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                success BOOLEAN DEFAULT TRUE
            )
        ''')
        
        # Template usage
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS template_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                template_id TEXT NOT NULL,
                query TEXT,
                customizations TEXT,
                success BOOLEAN DEFAULT TRUE,
                error_message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Learning feedback
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                function_pattern TEXT,
                feedback_type TEXT,
                details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def record_generation(
        self,
        query: str,
        function_name: str,
        function_code: str,
        generation_method: str,
        success: bool = True,
        error_message: Optional[str] = None
    ) -> None:
        """Record a function generation event"""
        
        # Extract pattern
        pattern = self.pattern_extractor.extract_pattern(
            function_name, function_code, query
        )
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Record generation
            cursor.execute('''
                INSERT INTO function_generation 
                (function_name, function_pattern, query_original, generated_code, 
                 generation_method, success, error_message)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                function_name,
                pattern['pattern_id'],
                query,
                function_code,
                generation_method,
                success,
                error_message
            ))
            
            # Update pattern statistics
            cursor.execute('''
                INSERT INTO pattern_statistics 
                (pattern_id, pattern_description, category, total_generations, 
                 unique_queries, success_count, last_seen)
                VALUES (?, ?, ?, 1, 1, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(pattern_id) DO UPDATE SET
                    total_generations = total_generations + 1,
                    success_count = success_count + ?,
                    last_seen = CURRENT_TIMESTAMP
            ''', (
                pattern['pattern_id'],
                json.dumps(pattern),
                pattern['category'],
                1 if success else 0,
                1 if success else 0
            ))
            
            # Check if pattern should be converted to template
            cursor.execute('''
                SELECT total_generations, converted_to_template
                FROM pattern_statistics
                WHERE pattern_id = ?
            ''', (pattern['pattern_id'],))
            
            row = cursor.fetchone()
            if row and row[0] >= 3 and not row[1]:
                # Mark for template conversion
                self._mark_for_template_conversion(cursor, pattern['pattern_id'])
            
            conn.commit()
            logger.info(f"Recorded generation: {function_name} using {generation_method}")
            
        except Exception as e:
            logger.error(f"Failed to record generation: {e}")
            conn.rollback()
        finally:
            conn.close()
    
    def _mark_for_template_conversion(self, cursor, pattern_id: str):
        """Mark a pattern as ready for template conversion"""
        cursor.execute('''
            INSERT INTO learning_feedback
            (function_pattern, feedback_type, details)
            VALUES (?, 'template_candidate', 'Pattern used 3+ times, ready for template conversion')
        ''', (pattern_id,))
        
        logger.info(f"Pattern '{pattern_id}' marked for template conversion")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get usage statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # Total generations
            cursor.execute('SELECT COUNT(*) FROM function_generation')
            total_generations = cursor.fetchone()[0]
            
            # Success rate
            cursor.execute('''
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful
                FROM function_generation
            ''')
            row = cursor.fetchone()
            success_rate = (row[1] / row[0] * 100) if row[0] > 0 else 0
            
            # Top patterns
            cursor.execute('''
                SELECT pattern_id, category, total_generations
                FROM pattern_statistics
                ORDER BY total_generations DESC
                LIMIT 10
            ''')
            top_patterns = [
                {"pattern_id": row[0], "category": row[1], "count": row[2]}
                for row in cursor.fetchall()
            ]
            
            # Template candidates
            cursor.execute('''
                SELECT pattern_id, total_generations
                FROM pattern_statistics
                WHERE total_generations >= 3 AND converted_to_template = 0
            ''')
            template_candidates = [
                {"pattern_id": row[0], "count": row[1]}
                for row in cursor.fetchall()
            ]
            
            # Method distribution
            cursor.execute('''
                SELECT generation_method, COUNT(*) as count
                FROM function_generation
                GROUP BY generation_method
            ''')
            method_distribution = {
                row[0]: row[1] for row in cursor.fetchall()
            }
            
            # Recent generations
            cursor.execute('''
                SELECT function_name, generation_method, created_at
                FROM function_generation
                ORDER BY created_at DESC
                LIMIT 5
            ''')
            recent_generations = [
                {
                    "function": row[0],
                    "method": row[1],
                    "timestamp": row[2]
                }
                for row in cursor.fetchall()
            ]
            
            return {
                "total_generations": total_generations,
                "success_rate": success_rate,
                "top_patterns": top_patterns,
                "template_candidates": template_candidates,
                "method_distribution": method_distribution,
                "recent_generations": recent_generations,
                "timestamp": datetime.now().isoformat()
            }
            
        finally:
            conn.close()
    
    def get_pattern_examples(self, pattern_id: str, limit: int = 5) -> List[Dict]:
        """Get example generations for a pattern"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT function_name, query_original, generated_code, created_at
                FROM function_generation
                WHERE function_pattern = ?
                ORDER BY created_at DESC
                LIMIT ?
            ''', (pattern_id, limit))
            
            examples = [
                {
                    "function_name": row[0],
                    "query": row[1],
                    "code": row[2],
                    "created_at": row[3]
                }
                for row in cursor.fetchall()
            ]
            
            return examples
            
        finally:
            conn.close()
    
    def cleanup_old_records(self, days: int = 30):
        """Clean up old records"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                DELETE FROM function_generation
                WHERE created_at < datetime('now', '-' || ? || ' days')
                AND usage_count = 0
            ''', (days,))
            
            deleted = cursor.rowcount
            conn.commit()
            
            logger.info(f"Cleaned up {deleted} old records")
            return deleted
            
        finally:
            conn.close()