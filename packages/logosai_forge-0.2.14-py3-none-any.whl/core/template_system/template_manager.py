"""
Template Manager for Function Templates
"""

import json
import os
import importlib.util
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from loguru import logger


@dataclass
class Template:
    """Function template"""
    id: str
    category: str
    name: str
    keywords: List[str]
    function_code: str
    parameters: Dict[str, str]
    returns: str
    description: str
    required_imports: List[str]


class TemplateManager:
    """Manages function template library"""
    
    def __init__(self, template_dir: str = None):
        if template_dir is None:
            template_dir = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                "templates", "functions"
            )
        
        self.template_dir = template_dir
        self.registry_path = os.path.join(template_dir, "registry.json")
        self.templates: Dict[str, Template] = {}
        self.registry: Dict = {}
        
        self._load_registry()
        self._load_templates()
        
        logger.info(f"Template manager initialized with {len(self.templates)} templates")
    
    def _load_registry(self):
        """Load template registry"""
        try:
            with open(self.registry_path, 'r', encoding='utf-8') as f:
                self.registry = json.load(f)
        except FileNotFoundError:
            logger.warning(f"Registry not found at {self.registry_path}")
            self.registry = {"templates": {}, "categories": {}}
        except Exception as e:
            logger.error(f"Failed to load registry: {e}")
            self.registry = {"templates": {}, "categories": {}}
    
    def _load_templates(self):
        """Load all templates from registry"""
        for template_id, info in self.registry.get("templates", {}).items():
            try:
                template = self._load_template(template_id, info)
                if template:
                    self.templates[template_id] = template
            except Exception as e:
                logger.error(f"Failed to load template {template_id}: {e}")
    
    def _load_template(self, template_id: str, info: Dict) -> Optional[Template]:
        """Load a single template"""
        try:
            # Build module path
            file_path = os.path.join(self.template_dir, info['file'])
            
            if not os.path.exists(file_path):
                logger.warning(f"Template file not found: {file_path}")
                return None
            
            # Load module dynamically
            spec = importlib.util.spec_from_file_location(template_id, file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Get template function
            func_name = f"get_{info['function']}"
            if not hasattr(module, func_name):
                logger.warning(f"Function {func_name} not found in {file_path}")
                return None
            
            # Get template code
            template_func = getattr(module, func_name)
            template_code = template_func()
            
            # Create Template object
            template = Template(
                id=template_id,
                category=info['category'],
                name=info.get('description', template_id),
                keywords=info.get('keywords', []),
                function_code=template_code,
                parameters=info.get('parameters', {}),
                returns=info.get('returns', 'Any'),
                description=info.get('description', ''),
                required_imports=info.get('required_imports', [])
            )
            
            return template
            
        except Exception as e:
            logger.error(f"Error loading template {template_id}: {e}")
            return None
    
    def get_template(self, template_id: str) -> Optional[Template]:
        """Get a specific template"""
        return self.templates.get(template_id)
    
    def search_templates(self, keywords: List[str]) -> List[Template]:
        """Search templates by keywords"""
        keywords_lower = [kw.lower() for kw in keywords]
        matched_templates = []
        
        for template in self.templates.values():
            # Check if any keyword matches
            template_keywords_lower = [kw.lower() for kw in template.keywords]
            
            if any(kw in template_keywords_lower for kw in keywords_lower):
                matched_templates.append(template)
                continue
            
            # Check in name and description
            name_desc_lower = (template.name + " " + template.description).lower()
            if any(kw in name_desc_lower for kw in keywords_lower):
                matched_templates.append(template)
        
        return matched_templates
    
    def get_templates_by_category(self, category: str) -> List[Template]:
        """Get all templates in a category"""
        return [
            template for template in self.templates.values()
            if template.category == category
        ]
    
    def get_template_for_query(self, query: str) -> Optional[Template]:
        """Find best matching template for a query"""
        query_lower = query.lower()
        
        # Keywords to search
        search_keywords = []
        
        # Extract keywords from query
        keyword_patterns = {
            "csv": ["csv", "comma", "separated"],
            "json": ["json", "javascript", "object"],
            "database": ["database", "sql", "query", "db"],
            "api": ["api", "endpoint", "rest", "http"],
            "statistical": ["statistic", "mean", "average", "median"],
            "pattern": ["pattern", "trend", "sequence"],
            "anomaly": ["anomaly", "outlier", "unusual"],
            "classify": ["classify", "classification", "categorize"],
            "predict": ["predict", "forecast", "estimate"],
            "chart": ["chart", "plot", "graph", "visualize"],
            "email": ["email", "mail", "send", "notify"],
            "clean": ["clean", "preprocess", "normalize"],
            "aggregate": ["aggregate", "group", "summarize"]
        }
        
        for keyword, patterns in keyword_patterns.items():
            if any(p in query_lower for p in patterns):
                search_keywords.append(keyword)
        
        if not search_keywords:
            return None
        
        # Search for matching templates
        matched_templates = self.search_templates(search_keywords)
        
        if matched_templates:
            # Return the first match (could be improved with scoring)
            return matched_templates[0]
        
        return None
    
    def list_categories(self) -> Dict[str, int]:
        """List all categories and their template counts"""
        category_counts = {}
        
        for template in self.templates.values():
            if template.category not in category_counts:
                category_counts[template.category] = 0
            category_counts[template.category] += 1
        
        return category_counts
    
    def get_required_imports(self, template_ids: List[str]) -> List[str]:
        """Get all required imports for a set of templates"""
        all_imports = set()
        
        for template_id in template_ids:
            template = self.get_template(template_id)
            if template:
                all_imports.update(template.required_imports)
        
        # Add common imports
        common_imports = [
            "import asyncio",
            "import json",
            "from typing import Dict, Any, Optional, List, Tuple",
            "from datetime import datetime",
            "from loguru import logger"
        ]
        
        all_imports.update(common_imports)
        
        # Convert to import statements
        import_statements = []
        for imp in sorted(all_imports):
            if imp in ["pandas", "numpy", "scipy", "sklearn", "transformers", 
                      "plotly", "matplotlib", "aiohttp", "requests"]:
                # Popular packages
                if imp == "pandas":
                    import_statements.append("import pandas as pd")
                elif imp == "numpy":
                    import_statements.append("import numpy as np")
                else:
                    import_statements.append(f"import {imp}")
            elif not imp.startswith("import") and not imp.startswith("from"):
                import_statements.append(f"import {imp}")
            else:
                import_statements.append(imp)
        
        return import_statements
    
    def apply_template(self, template_id: str, customizations: Dict[str, str]) -> str:
        """Apply customizations to a template"""
        template = self.get_template(template_id)
        if not template:
            raise ValueError(f"Template not found: {template_id}")
        
        # Get template code
        code = template.function_code
        
        # Apply customizations
        for placeholder, replacement in customizations.items():
            # Replace {placeholder} with actual code
            code = code.replace(f"{{{placeholder}}}", replacement)
        
        # Replace any remaining placeholders with default implementations
        default_impl = "# TODO: Implement this section"
        
        # Find all remaining placeholders
        import re
        placeholders = re.findall(r'\{(\w+)\}', code)
        
        for placeholder in placeholders:
            if placeholder not in ["self", "e", "0", "1", "2"]:  # Skip Python format placeholders
                code = code.replace(f"{{{placeholder}}}", default_impl)
        
        return code
    
    def register_new_template(self, template_id: str, template_info: Dict, 
                            template_code: str) -> bool:
        """Register a new template"""
        try:
            # Update registry
            self.registry["templates"][template_id] = template_info
            
            # Save registry
            with open(self.registry_path, 'w', encoding='utf-8') as f:
                json.dump(self.registry, f, indent=2, ensure_ascii=False)
            
            # Create template file
            file_path = os.path.join(self.template_dir, template_info['file'])
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # Write template file
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(f'''"""
Auto-generated template: {template_id}
"""

TEMPLATE_INFO = {{
    "id": "{template_id}",
    "name": "{template_info.get('description', template_id)}",
    "category": "{template_info.get('category', 'general')}",
    "version": "1.0.0",
    "auto_generated": True
}}

def get_{template_info.get('function', 'template')}():
    """Auto-generated template function"""
    return r\'\'\'
{template_code}
\'\'\'
''')
            
            # Reload templates
            self._load_templates()
            
            logger.info(f"Registered new template: {template_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to register template {template_id}: {e}")
            return False