"""
Simplified Code Generator - Single LLM call approach
Uses only Gemini-2.5-pro for all code generation
Now with database template support
"""

import logging
from typing import Optional, Any, Callable, Dict, List
from datetime import datetime
from pathlib import Path
import json
import sys

# Add prototype/backend to path for imports
sys.path.append(str(Path(__file__).parent.parent / "prototype" / "backend"))

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts

# Use loguru for consistent logging
from loguru import logger

# Import DB template repository
try:
    from app.services.db_template_repository import DBTemplateRepository
    DB_TEMPLATES_AVAILABLE = True
except ImportError:
    logger.warning("DBTemplateRepository not available, using file templates only")
    DB_TEMPLATES_AVAILABLE = False


class SimplifiedCodeGenerator:
    """Simplified code generator that uses structured approach for better quality"""
    
    def __init__(self, llm_orchestrator: LLMOrchestrator, template_manager=None):
        """Initialize structured code generator with enhanced domain patterns"""
        self.llm = llm_orchestrator
        self.template_manager = template_manager
        self.template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template.py.template"
        
        # Initialize DB template repository if available
        self.db_templates = DBTemplateRepository() if DB_TEMPLATES_AVAILABLE else None
        
        # Load default template as fallback
        try:
            with open(self.template_path, 'r') as f:
                self.template = f.read()
        except Exception as e:
            logger.warning(f"Could not load template: {e}")
            self.template = ""
        
        # Enhanced domain-specific patterns for structured generation
        self.domain_patterns = {
            "customer_analysis": {
                "imports": ["pandas as pd", "numpy as np", "matplotlib.pyplot as plt", "seaborn as sns", 
                           "sklearn.cluster", "sklearn.preprocessing", "sklearn.model_selection", 
                           "sklearn.metrics", "datetime", "json"],
                "business_rules": [
                    "고객 데이터 수집 및 정제",
                    "고객 세그멘테이션 수행 (RFM, K-means 등)",
                    "구매 패턴 분석 및 시각화",
                    "이탈 위험 고객 예측 모델링",
                    "개인화 추천 시스템 구축",
                    "마케팅 타겟팅 전략 제안",
                    "고객 생애 가치(CLV) 계산",
                    "행동 기반 인사이트 도출"
                ],
                "code_patterns": {
                    "data_loading": """# Load customer data
customer_data = pd.DataFrame()
transaction_data = pd.DataFrame()
behavior_data = pd.DataFrame()

# Merge datasets
merged_data = customer_data.merge(transaction_data, on='customer_id', how='left')
merged_data = merged_data.merge(behavior_data, on='customer_id', how='left')""",
                    "segmentation": """# RFM Analysis
from datetime import datetime
import pandas as pd

def perform_rfm_analysis(df):
    current_date = datetime.now()
    rfm = df.groupby('customer_id').agg({
        'purchase_date': lambda x: (current_date - x.max()).days,
        'order_id': 'count',
        'total_amount': 'sum'
    }).rename(columns={
        'purchase_date': 'Recency',
        'order_id': 'Frequency', 
        'total_amount': 'Monetary'
    })
    return rfm""",
                    "clustering": """# K-means clustering
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

kmeans = KMeans(n_clusters=5, random_state=42)
clusters = kmeans.fit_predict(scaled_features)
df['cluster'] = clusters"""
                }
            },
            "data_analysis": {
                "imports": ["pandas as pd", "numpy as np", "matplotlib.pyplot as plt", "seaborn as sns", "io"],
                "business_rules": [
                    "데이터 검증 및 정제",
                    "통계 분석 수행", 
                    "인사이트 도출",
                    "시각화 생성",
                    "결과 요약 및 반환"
                ],
                "code_patterns": {
                    "data_loading": """# Load and validate data
if isinstance(data, str):
    if data.endswith('.csv'):
        df = pd.read_csv(data)
    elif data.endswith('.xlsx'):
        df = pd.read_excel(data)
    else:
        df = pd.DataFrame(json.loads(data))
elif isinstance(data, dict):
    df = pd.DataFrame(data)
elif isinstance(data, pd.DataFrame):
    df = data
else:
    raise ValueError(f"Unsupported data type: {type(data)}")""",
                    "validation": """# Validate data
if df.empty:
    raise ValueError("Empty dataset provided")
    
# Check for required columns
missing_columns = set(required_columns) - set(df.columns)
if missing_columns:
    logger.warning(f"Missing columns: {missing_columns}")""",
                    "analysis": """# Perform analysis
results = {
    'summary': df.describe().to_dict(),
    'shape': df.shape,
    'columns': df.columns.tolist(),
    'dtypes': df.dtypes.astype(str).to_dict()
}"""
                }
            },
            "api_integration": {
                "imports": ["aiohttp", "asyncio", "json", "urllib.parse"],
                "business_rules": [
                    "API 엔드포인트 검증",
                    "인증 처리",
                    "요청 파라미터 구성",
                    "응답 처리 및 에러 핸들링",
                    "결과 변환 및 반환"
                ],
                "code_patterns": {
                    "api_setup": """# API configuration
self.base_url = self.config.metadata.get('api_base_url', '')
self.headers = self.config.metadata.get('headers', {})
self.timeout = aiohttp.ClientTimeout(total=30)""",
                    "request_handler": """async def make_request(self, method: str, endpoint: str, **kwargs):
    \"\"\"Make API request with error handling\"\"\"
    url = f"{self.base_url}{endpoint}"
    
    async with aiohttp.ClientSession(timeout=self.timeout) as session:
        try:
            async with session.request(method, url, headers=self.headers, **kwargs) as response:
                response.raise_for_status()
                return await response.json()
        except aiohttp.ClientError as e:
            logger.error(f"API request failed: {e}")
            raise"""
                }
            },
            "automation": {
                "imports": ["asyncio", "schedule", "time", "subprocess"],
                "business_rules": [
                    "작업 스케줄 설정",
                    "트리거 조건 확인",
                    "자동화 작업 실행",
                    "실행 결과 모니터링",
                    "실패 시 재시도 로직"
                ],
                "code_patterns": {
                    "scheduler": """# Task scheduler
self.scheduler = schedule.Scheduler()
self.tasks = []""",
                    "task_execution": """async def execute_task(self, task_name: str, params: Dict[str, Any]):
    \"\"\"Execute automation task\"\"\"
    logger.info(f"Executing task: {task_name}")
    
    try:
        # Task execution logic
        result = await self._run_task(task_name, params)
        
        # Log success
        logger.info(f"Task {task_name} completed successfully")
        return result
        
    except Exception as e:
        logger.error(f"Task {task_name} failed: {e}")
        # Retry logic
        if self.retry_count < self.max_retries:
            self.retry_count += 1
            await asyncio.sleep(self.retry_delay)
            return await self.execute_task(task_name, params)
        raise"""
                }
            },
            "file_processing": {
                "imports": ["pathlib", "pandas as pd", "PyPDF2", "python-docx", "openpyxl"],
                "business_rules": [
                    "파일 형식 검증",
                    "내용 추출",
                    "데이터 변환",
                    "결과 저장",
                    "메타데이터 수집"
                ],
                "code_patterns": {
                    "file_handler": """def process_file(self, file_path: str):
    \"\"\"Process file based on type\"\"\"
    path = Path(file_path)
    
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_type = path.suffix.lower()
    
    if file_type == '.pdf':
        return self._process_pdf(path)
    elif file_type in ['.xlsx', '.xls']:
        return self._process_excel(path)
    elif file_type == '.csv':
        return self._process_csv(path)
    elif file_type in ['.docx', '.doc']:
        return self._process_word(path)
    else:
        raise ValueError(f"Unsupported file type: {file_type}")"""
                }
            }
        }
    
    def _load_template_from_db(self, category: str, domain: str) -> Optional[str]:
        """Load best matching template from database"""
        if not self.db_templates:
            return None
            
        try:
            # Search for templates matching domain/category
            templates = self.db_templates.search_templates(
                query=f"{domain} {category}",
                limit=10
            )
            
            if not templates:
                # Try listing by category
                templates = self.db_templates.list_templates(
                    category=category,
                    limit=10
                )
            
            # Find best match based on usage count and relevance
            best_template = None
            best_score = 0
            
            for template in templates:
                score = template.get('usage_count', 0)
                
                # Boost score for exact category match
                if template.get('category', '').lower() == category.lower():
                    score += 100
                
                # Boost score for domain match in tags
                if domain.lower() in ' '.join(template.get('tags', [])).lower():
                    score += 50
                
                if score > best_score:
                    best_score = score
                    best_template = template
            
            if best_template:
                logger.info(f"Found template from DB: {best_template['name']} (score: {best_score})")
                return best_template['content']
            
        except Exception as e:
            logger.error(f"Error loading template from DB: {e}")
        
        return None
    
    def _select_template(self, analysis: QueryAnalysis) -> str:
        """Select best template based on analysis"""
        domain = (analysis.domain or 'general').lower()
        
        # Map domain to template category
        category_map = {
            'data analysis': 'data_analysis',
            'customer_analysis': 'data_analysis',
            'api': 'api_integration',
            'integration': 'api_integration',
            'automation': 'automation',
            'file': 'file_processing',
            'document': 'document_processing',
            'web': 'web_scraping',
            'database': 'database',
            'monitoring': 'monitoring'
        }
        
        category = category_map.get(domain, 'general')
        
        # Force use of file template to ensure we have the latest version
        # TODO: Re-enable database templates after verifying they are up-to-date
        logger.info("Using file template (database templates temporarily disabled)")
        return self.template
        
        # Original code - commented out temporarily
        # # Try to load from database first
        # db_template = self._load_template_from_db(category, domain)
        # if db_template:
        #     return db_template
        # 
        # # Fallback to file template
        # logger.info("Using default file template")
        # return self.template
    
    async def _extract_business_logic(self, analysis: QueryAnalysis) -> Dict[str, Any]:
        """Extract business logic and requirements from query"""
        prompt = f"""사용자 요청: {analysis.query}

이 요청에서 핵심 비즈니스 로직을 추출해주세요. JSON 형식으로 답변해주세요:
{{
    "main_purpose": "이 에이전트의 주요 목적",
    "core_functions": ["핵심 기능 1", "핵심 기능 2", ...],
    "input_types": ["예상 입력 타입"],
    "output_format": "예상 출력 형식",
    "business_rules": ["비즈니스 규칙 1", "비즈니스 규칙 2", ...],
    "error_scenarios": ["예상 에러 시나리오"]
}}"""
        
        try:
            result = await self.llm.process_task(prompt, TaskType.BUSINESS_LOGIC_EXTRACTION)
            
            # Clean the result - remove markdown and extra text
            result = result.strip()
            if result.startswith('```json'):
                result = result.replace('```json', '').replace('```', '').strip()
            elif result.startswith('```'):
                result = result.replace('```', '').strip()
            
            # Parse JSON from LLM response
            import re
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                json_str = json_match.group()
                try:
                    return json.loads(json_str)
                except json.JSONDecodeError as je:
                    logger.warning(f"JSON parsing failed: {je}")
                    # Fallback: create simple structure
                    return {
                        "main_purpose": "Agent for processing user requests",
                        "core_functions": ["process_query", "return_response"],
                        "input_types": ["string"],
                        "output_format": "json",
                        "business_rules": [],
                        "error_scenarios": ["invalid_input", "processing_error"]
                    }
            
            logger.warning("No JSON found in LLM response, using fallback")
            return {
                "main_purpose": "Agent for processing user requests", 
                "core_functions": ["process_query", "return_response"],
                "input_types": ["string"],
                "output_format": "json",
                "business_rules": [],
                "error_scenarios": ["invalid_input", "processing_error"]
            }
            
        except Exception as e:
            logger.error(f"Business logic extraction failed: {e}")
            return {
                "main_purpose": "Agent for processing user requests",
                "core_functions": ["process_query", "return_response"], 
                "input_types": ["string"],
                "output_format": "json",
                "business_rules": [],
                "error_scenarios": ["invalid_input", "processing_error"]
            }
    
    def _select_domain_patterns(self, analysis: QueryAnalysis, business_logic: Dict[str, Any]) -> Dict[str, Any]:
        """Select appropriate domain patterns based on analysis"""
        domain = (analysis.domain or '').lower()
        
        # Select best matching domain pattern
        if any(keyword in domain for keyword in ['data', 'analysis', 'csv', 'excel']):
            pattern_key = 'data_analysis'
        elif any(keyword in domain for keyword in ['api', 'integration', 'rest']):
            pattern_key = 'api_integration'
        elif any(keyword in domain for keyword in ['automation', 'schedule', 'workflow']):
            pattern_key = 'automation'
        elif any(keyword in domain for keyword in ['file', 'document', 'pdf']):
            pattern_key = 'file_processing'
        else:
            pattern_key = 'data_analysis'  # Default
        
        return {
            "domain": pattern_key,
            "patterns": self.domain_patterns.get(pattern_key, {})
        }
    
    async def _generate_dynamic_system_prompt(self, analysis: QueryAnalysis, business_logic: Dict[str, Any], 
                                           domain_info: Dict[str, Any]) -> str:
        """Generate dynamic system prompt based on analysis"""
        
        domain_expertise = {
            "data_analysis": "당신은 데이터 분석 전문가입니다. 통계, 머신러닝, 데이터 시각화에 깊은 지식을 가지고 있습니다.",
            "customer_analysis": "당신은 고객 행동 분석 전문가입니다. RFM 분석, 고객 세그멘테이션, 이탈 예측(churn prediction), 개인화 추천, 마케팅 타겟팅, 고객 생애 가치(CLV) 계산에 전문성을 가지고 있습니다. 고객 데이터를 활용한 비즈니스 인사이트 도출이 핵심입니다.",
            "api_integration": "당신은 API 통합 전문가입니다. RESTful API, 비동기 처리, 에러 핸들링에 전문성을 가지고 있습니다.",
            "web_scraping": "당신은 웹 스크래핑 전문가입니다. HTML 파싱, 동적 콘텐츠 처리, 반복 처리에 전문성을 가지고 있습니다.",
            "file_processing": "당신은 파일 처리 전문가입니다. 다양한 형식의 파일 읽기, 변환, 검증에 전문성을 가지고 있습니다."
        }
        
        domain = analysis.domain or "general"
        domain_key = domain.lower().replace(" ", "_")
        
        expertise = domain_expertise.get(domain_key, "당신은 소프트웨어 개발 전문가입니다.")
        
        system_prompt = f"""{expertise}

**전문 분야**: {domain}
**복잡도**: {analysis.complexity.value}
**필수 기능**: {', '.join(analysis.required_capabilities)}

**LogosAI 프레임워크 규칙**:
1. LogosAIAgent를 상속받는 클래스 생성
2. 적절한 AgentType 선택 (DATA_ANALYSIS, CUSTOM, API_INTEGRATION 등)
3. async def process(query, context=None) 메서드 필수 구현
4. AgentResponse 반환 (response_type: JSON, TEXT, HTML, ERROR만 사용)
5. 완전한 에러 처리 및 로깅

**도메인별 요구사항**:
{json.dumps(domain_info['patterns'], ensure_ascii=False, indent=2)}

**비즈니스 로직 구현 필수사항**:
{json.dumps(business_logic, ensure_ascii=False, indent=2)}

완전하고 실행 가능한 LogosAI 에이전트 코드를 생성해주세요."""

        return system_prompt

    async def _generate_structured_code(self, analysis: QueryAnalysis, business_logic: Dict[str, Any], 
                                      domain_info: Dict[str, Any], context: Context, 
                                      stream_callback: Optional[Callable] = None) -> str:
        """Generate code using structured approach with dynamic system prompts"""
        
        # Select appropriate template
        template = self._select_template(analysis)
        logger.info(f"Template length: {len(template)} chars")
        # Check for critical placeholders
        if '{core_business_logic}' in template:
            logger.info("✅ Template has {core_business_logic} placeholder")
        else:
            logger.warning("❌ Template missing {core_business_logic} placeholder")
        if '{core_logic}' in template:
            logger.warning("⚠️ Template has old {core_logic} placeholder")
        
        # Step 1: Generate core business logic only
        business_logic_prompt = f"""다음 요청에 대한 핵심 비즈니스 로직만 생성해주세요.
템플릿의 _process_core_logic 메서드 내부에 들어갈 코드만 작성하세요.

**사용자 요청**: {analysis.query}

**비즈니스 요구사항**:
{json.dumps(business_logic, ensure_ascii=False, indent=2)}

**필요 기능**:
{chr(10).join([f"- {capability}" for capability in analysis.required_capabilities])}

**중요**: 
- 메서드 정의나 클래스 정의는 작성하지 마세요
- extracted_info 파라미터에서 필요한 정보를 추출하세요
- 결과는 딕셔너리 형태로 반환하세요
- pandas를 사용하는 경우 'pd'로, numpy는 'np'로 참조하세요

예시 형식:
```python
# 입력 데이터 추출
file_path = extracted_info.get('file_path', 'sample_data.csv')

# 데이터 처리
df = pd.read_csv(file_path)
# ... 비즈니스 로직 ...

# 결과 반환
return {{
    "status": "success",
    "data": processed_data,
    "insights": insights
}}
```"""
        
        try:
            # Generate core business logic
            # Increase token limit for Gemini Pro to avoid MAX_TOKENS errors
            logic_result = await self.llm.generate(
                prompt=business_logic_prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=8000  # Increased from 2000
            )
            
            core_business_logic = self._extract_code_from_response(logic_result)
            logger.info(f"Extracted business logic length: {len(core_business_logic)} chars")
            logger.debug(f"Business logic preview: {core_business_logic[:200]}...")
            
            # Step 2: Generate realistic sample data for testing
            sample_data_prompt = f"""사용자 요청에 맞는 현실적인 샘플 데이터를 생성해주세요.

**사용자 요청**: {analysis.query}
**도메인**: {analysis.domain or 'General'}

다음 형식으로 Python 코드를 생성해주세요:
1. 샘플 데이터 생성 코드 (pandas DataFrame 또는 딕셔너리)
2. 최소 10-20개의 레코드
3. 현실적이고 다양한 데이터 포함

예시:
```python
sample_data = pd.DataFrame({{
    'customer_id': ['C001', 'C002', 'C003'],
    'purchase_date': ['2024-01-15', '2024-02-20', '2024-03-10'],
    'amount': [150000, 230000, 89000]
}})
```
"""
            
            sample_data_result = await self.llm.generate(
                prompt=sample_data_prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=4000  # Increased from 1000
            )
            
            sample_data_code = self._extract_code_from_response(sample_data_result)
            
            # Step 3: Generate test scenarios
            test_scenarios_prompt = f"""다음 에이전트를 테스트할 쿼리들을 생성해주세요.

**에이전트 목적**: {analysis.query}
**주요 기능**: {', '.join(analysis.required_capabilities)}

3-5개의 테스트 쿼리를 Python 리스트로 생성해주세요:
```python
[
    "첫 번째 테스트 쿼리",
    "두 번째 테스트 쿼리",
    "세 번째 테스트 쿼리"
]
```
"""
            
            test_result = await self.llm.generate(
                prompt=test_scenarios_prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=2000  # Increased from 500
            )
            
            test_queries_code = self._extract_code_from_response(test_result)
            
            # Apply template parameters
            if '{{' in template and '}}' in template:
                # Generate all template variables using LLM
                class_name = await self._generate_class_name(analysis)
                agent_name = await self._generate_agent_name(analysis)
                
                # Generate missing template variables
                data_sources = await self._generate_data_sources(analysis)
                custom_init = await self._generate_custom_init(analysis)
                custom_async_init = await self._generate_custom_async_init(analysis)
                custom_cleanup = await self._generate_custom_cleanup(analysis)
                
                # Generate custom config string for agent configuration
                # Note: No leading comma needed - it's already in the template
                custom_config = '"timeout": 30,\n                    "retry_attempts": 3,\n                    "cache_enabled": true'
                
                # For data analysis agents, create sample data file
                if 'data' in (analysis.domain or '').lower() or 'analysis' in (analysis.domain or '').lower():
                    await self._create_sample_data_files(analysis)
                
                params = {
                    'agent_class_name': class_name,
                    'agent_name': agent_name,
                    'agent_description': analysis.query,
                    'custom_config': custom_config,
                    'data_sources': data_sources,
                    'custom_init': custom_init,
                    'custom_async_init': custom_async_init,
                    'test_queries': test_queries_code,  # Use generated test queries
                    'custom_cleanup': custom_cleanup,
                    'core_business_logic': core_business_logic,  # Core logic only
                    'query_extraction_prompt': await self._generate_query_extraction_prompt(analysis),
                    'response_generation_prompt': await self._generate_response_generation_prompt(analysis),
                    'insights_generation_prompt': await self._generate_insights_prompt(analysis),
                    'sample_data_code': sample_data_code  # Add sample data generation
                }
                
                # Template rendering - handle both single and double brace formats
                rendered = template
                
                # First replace single-brace variables (but preserve f-string double braces)
                for key, value in params.items():
                    # Replace {variable} format
                    rendered = rendered.replace(f'{{{key}}}', str(value))
                
                # Then replace double-brace variables {{ variable }}
                for key, value in params.items():
                    rendered = rendered.replace(f'{{{{ {key} }}}}', str(value))
                
                # Log any remaining template variables for debugging
                import re
                remaining_single = re.findall(r'\{([^{}]+)\}', rendered)
                remaining_double = re.findall(r'\{\{\s*([^{}]+)\s*\}\}', rendered)
                
                # Filter out f-string patterns (those with : or . or [)
                remaining_single = [var for var in remaining_single if not any(c in var for c in ':.[]()')]
                
                if remaining_single:
                    logger.warning(f"Remaining single-brace template variables: {remaining_single}")
                if remaining_double:
                    logger.warning(f"Remaining double-brace template variables: {remaining_double}")
                
                return rendered
            else:
                # No template placeholders, return generated code
                return code
                
        except Exception as e:
            logger.error(f"Structured code generation failed: {e}")
            raise
    
    async def generate(self, analysis: QueryAnalysis, context: Context, 
                      stream_callback: Optional[Callable] = None) -> Any:
        """Generate code using structured multi-phase approach"""
        
        start_time = datetime.now()
        
        try:
            # Phase 1: Extract business logic from query
            if stream_callback:
                await stream_callback(
                    "generating",
                    "🔍 비즈니스 로직을 추출하고 있습니다...",
                    {"phase": "business_logic_extraction"}
                )
            business_logic = await self._extract_business_logic(analysis)
            
            # Phase 2: Select domain and patterns
            domain_info = self._select_domain_patterns(analysis, business_logic)
            
            # Phase 3: Generate structured code
            if stream_callback:
                await stream_callback(
                    "generating",
                    "🚀 구조화된 코드를 생성하고 있습니다...",
                    {"phase": "structured_generation", "domain": domain_info["domain"]}
                )
            generated_code = await self._generate_structured_code(
                analysis, business_logic, domain_info, context, stream_callback
            )
            
            # Phase 4: Validate and fix if needed
            if stream_callback:
                await stream_callback(
                    "generating",
                    "✅ 코드를 검증하고 있습니다...",
                    {"phase": "validation"}
                )
            final_code = await self._validate_and_fix(generated_code, stream_callback)
            
            # Phase 5: Add test data and main function
            complete_code = self._add_test_harness(final_code, analysis)
            
            # Create GeneratedCode object
            class GeneratedCode:
                def __init__(self, code, artifacts, suggestions=None):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "structured_generation"
                    self.suggestions = suggestions or []
            
            # Initialize artifacts
            artifacts = GenerationArtifacts(
                generation_id=f"gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            
            artifacts.query_analysis = {
                "intent": analysis.intent,
                "domain": analysis.domain,
                "complexity": analysis.complexity.value,
                "capabilities": analysis.required_capabilities,
                "business_logic": business_logic
            }
            
            artifacts.generated_code_raw = complete_code
            artifacts.optimized_code = complete_code
            artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            artifacts.llm_calls_count = 2  # business logic + code generation
            
            if stream_callback:
                await stream_callback(
                    "generating",
                    "✨ 구조화된 에이전트가 성공적으로 생성되었습니다!",
                    {
                        "phase": "completed",
                        "code_length": len(complete_code),
                        "generation_time": (datetime.now() - start_time).total_seconds()
                    }
                )
            
            return GeneratedCode(
                code=complete_code,
                artifacts=artifacts,
                suggestions=[
                    "구조화된 접근법으로 에이전트가 생성되었습니다",
                    "비즈니스 로직이 명확히 구현되었습니다",
                    "도메인별 베스트 프랙티스가 적용되었습니다"
                ]
            )
            
        except Exception as e:
            logger.error(f"Structured generation failed: {e}")
            # Fallback to simple generation
            if stream_callback:
                await stream_callback(
                    "warning",
                    "⚠️ 구조화된 생성이 실패했습니다. 간단한 방식으로 재시도합니다...",
                    {"phase": "fallback"}
                )
            return await self._simple_generate(analysis, context, stream_callback)
    
    async def _simple_generate(self, analysis: QueryAnalysis, context: Context, 
                             stream_callback: Optional[Callable] = None) -> Any:
        """Simple single-prompt generation as fallback"""
        
        start_time = datetime.now()
        
        try:
            # Create comprehensive prompt
            prompt = self._create_comprehensive_prompt(analysis, context)
            
            # Stream generation start
            if stream_callback:
                await stream_callback(
                    "generating", 
                    "🚀 AI가 에이전트 코드를 생성하고 있습니다...",
                    {"phase": "generating", "provider": "gemini"}
                )
            
            # Single LLM call
            result = await self.llm.process_task(
                prompt,
                TaskType.CODE_GENERATION,
                provider_hint="gemini",
                max_tokens=4000
            )
            
            # Extract code
            code = self._extract_code_from_response(result)
            
            # Post-process to fix common issues
            code = self._postprocess_generated_code(code)
            
            # Validate
            is_valid, issues = self._validate_generated_code(code)
            
            if not is_valid and issues:
                # Try to fix validation issues
                if stream_callback:
                    await stream_callback(
                        "fixing",
                        f"🔧 코드 문제를 수정하고 있습니다: {', '.join(issues[:2])}",
                        {"issues": issues}
                    )
                
                code = await self._fix_code_issues(code, issues)
            
            # Add test data
            complete_code = self._add_test_harness(code, analysis)
            
            # Create artifacts
            artifacts = GenerationArtifacts(
                generation_id=f"gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            
            artifacts.query_analysis = {
                "intent": analysis.intent,
                "domain": analysis.domain,
                "complexity": analysis.complexity.value,
                "capabilities": analysis.required_capabilities
            }
            
            artifacts.generated_code_raw = result
            artifacts.optimized_code = complete_code
            artifacts.code_issues = issues if not is_valid else []
            artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            artifacts.llm_calls_count = 1 if is_valid else 2
            
            # Stream completion
            if stream_callback:
                await stream_callback(
                    "complete",
                    "✅ 에이전트 코드 생성이 완료되었습니다!",
                    {
                        "code_length": len(complete_code),
                        "generation_time": (datetime.now() - start_time).total_seconds()
                    }
                )
            
            # Return GeneratedCode object
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "simple_generation"
            
            return GeneratedCode(code=complete_code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Code generation failed: {e}")
            
            if stream_callback:
                await stream_callback(
                    "error",
                    f"❌ 코드 생성 중 오류 발생: {str(e)}",
                    {"error": str(e)}
                )
            
            # Return minimal working code
            fallback_code = await self._create_fallback_code(analysis)
            
            artifacts = GenerationArtifacts(
                generation_id=f"gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            artifacts.error_message = str(e)
            
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "fallback"
            
            return GeneratedCode(code=fallback_code, artifacts=artifacts)
    
    def _create_comprehensive_prompt(self, analysis: QueryAnalysis, context: Context) -> str:
        """Create a comprehensive prompt for code generation"""
        
        # Get sample query for the domain
        sample_query = self._get_sample_query(analysis.domain)
        
        return f"""LogosAI 에이전트 코드를 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain}
의도: {analysis.intent}
필요 기능: {', '.join(analysis.required_capabilities)}

요구사항:
1. LogosAI 프레임워크를 사용한 완전한 에이전트 코드
2. 모든 필요한 import 문 포함
3. LogosAIAgent 클래스 상속
4. async def process() 메서드 구현
5. 적절한 에러 처리
6. 구조화된 로깅
7. 테스트를 위한 main() 함수와 샘플 데이터

중요 사항:
- AgentResponse를 반환할 때는 type과 content 두 개의 파라미터만 사용
- AgentResponseType은 JSON, TEXT, HTML, ERROR 중 하나만 사용 (SUCCESS, INFO 등은 사용 불가)
- 예: AgentResponse(type=AgentResponseType.JSON, content={{"result": data}})

완전하고 실행 가능한 Python 코드를 생성해주세요.
"""
    
    def _extract_code_from_response(self, response: str) -> str:
        """Extract Python code from LLM response"""
        
        # Try to find code block
        import re
        
        # Look for ```python blocks first
        python_blocks = re.findall(r'```python\n(.*?)```', response, re.DOTALL)
        if python_blocks:
            return python_blocks[0].strip()
        
        # Look for any ``` blocks
        code_blocks = re.findall(r'```\n(.*?)```', response, re.DOTALL)
        if code_blocks:
            return code_blocks[0].strip()
        
        # If no code blocks, try to extract from import statements
        lines = response.split('\n')
        code_lines = []
        in_code = False
        
        for line in lines:
            if line.strip().startswith('import ') or line.strip().startswith('from '):
                in_code = True
            
            if in_code:
                code_lines.append(line)
        
        if code_lines:
            return '\n'.join(code_lines)
        
        # Last resort - return everything
        return response
    
    def _postprocess_generated_code(self, code: str) -> str:
        """Post-process generated code to fix common issues"""
        
        # Fix wrong AgentResponseType values
        import re
        
        # Replace invalid response types with JSON
        invalid_type_pattern = r'AgentResponseType\.(SUCCESS|INFO|WARNING|FAILURE|OK|DONE)'
        def fix_response_type(match):
            invalid_type = match.group(1)
            logger.info(f"Fixing invalid AgentResponseType.{invalid_type} -> AgentResponseType.JSON")
            return 'AgentResponseType.JSON'
        
        code = re.sub(invalid_type_pattern, fix_response_type, code)
        
        # Fix message parameter in AgentResponse
        # Pattern: AgentResponse(type=..., content=..., message=...)
        message_pattern = r'AgentResponse\s*\(\s*type\s*=\s*([^,]+),\s*content\s*=\s*(\{[^}]+\}),\s*message\s*=\s*([^)]+)\)'
        def fix_message_param(match):
            type_part = match.group(1)
            content_part = match.group(2)
            message_part = match.group(3)
            
            # Add message to content dict
            logger.info("Moving message parameter into content dict")
            # Remove quotes from message_part if present
            message_clean = message_part.strip().strip('"').strip("'")
            
            # Ensure content dict has proper message field
            if content_part.strip() == '{}':
                new_content = f'{{"message": "{message_clean}"}}'
            else:
                # Insert message into existing dict
                new_content = content_part.rstrip('}') + f', "message": "{message_clean}"}}'
            
            return f'AgentResponse(type={type_part}, content={new_content})'
        
        code = re.sub(message_pattern, fix_message_param, code)
        
        # Ensure proper imports
        if 'from logosai import' not in code and 'import logosai' not in code:
            logger.info("Adding missing LogosAI imports")
            imports = """from logosai import LogosAIAgent, AgentConfig, AgentResponse, AgentResponseType, AgentType
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

"""
            code = imports + code
        
        return code
    
    def _validate_generated_code(self, code: str) -> tuple[bool, list[str]]:
        """Validate generated code for common issues"""
        
        issues = []
        
        # Check for required imports
        if 'from logosai import' not in code and 'import logosai' not in code:
            issues.append("LogosAI import missing")
        
        # Check for agent class
        if 'class ' not in code or '(LogosAIAgent)' not in code:
            issues.append("Agent class definition missing or not inheriting LogosAIAgent")
        
        # Check for process method
        if 'async def process' not in code:
            issues.append("async def process method missing")
        
        # Check for AgentResponse
        if 'AgentResponse(' not in code:
            issues.append("AgentResponse return missing")
        
        # Check for invalid AgentResponseType values
        import re
        invalid_types = re.findall(r'AgentResponseType\.(SUCCESS|INFO|WARNING|FAILURE|OK|DONE)', code)
        if invalid_types:
            issues.append(f"Invalid AgentResponseType values found: {', '.join(set(invalid_types))}")
        
        # Check for message parameter in AgentResponse
        if re.search(r'AgentResponse\s*\([^)]*message\s*=', code):
            issues.append("AgentResponse using invalid 'message' parameter")
        
        # Check basic syntax with AST
        try:
            import ast
            ast.parse(code)
        except SyntaxError as e:
            issues.append(f"Syntax error: {str(e)}")
        
        # Check for incomplete code
        if code.rstrip().endswith(('...', 'TODO', 'pass')):
            issues.append("Code appears to be incomplete")
        
        return len(issues) == 0, issues
    
    async def _fix_code_issues(self, code: str, issues: list[str]) -> str:
        """Try to fix identified code issues"""
        
        fix_prompt = f"""다음 LogosAI 에이전트 코드의 문제를 수정해주세요.

현재 코드:
```python
{code}
```

발견된 문제:
{chr(10).join(f"- {issue}" for issue in issues)}

중요 사항:
- AgentResponseType은 JSON, TEXT, HTML, ERROR 중 하나만 사용
- AgentResponse는 type과 content 파라미터만 사용 (message 파라미터 사용 불가)
- message는 content 딕셔너리 안에 포함

수정된 완전한 코드를 제공해주세요.
"""
        
        try:
            result = await self.llm.process_task(fix_prompt, TaskType.CODE_FIXING)
            fixed_code = self._extract_code_from_response(result)
            
            # Post-process again to ensure fixes
            fixed_code = self._postprocess_generated_code(fixed_code)
            
            # Validate again
            is_valid, new_issues = self._validate_generated_code(fixed_code)
            
            if is_valid or len(new_issues) < len(issues):
                # Improved or fixed
                return fixed_code
            else:
                # Fixing failed, return original with post-processing
                logger.warning("Code fixing did not improve issues, returning post-processed original")
                return self._postprocess_generated_code(code)
                
        except Exception as e:
            logger.error(f"Code fixing failed: {e}")
            return self._postprocess_generated_code(code)
    
    def _add_test_harness(self, code: str, analysis: QueryAnalysis) -> str:
        """Add test data and main function to code"""
        
        # Check if main already exists
        if 'if __name__ == "__main__"' in code:
            return code
        
        # Generate test query based on domain
        domain = (analysis.domain or '').lower()
        
        if 'data' in domain or 'analysis' in domain:
            # For data analysis agents, use comprehensive test with sample data
            test_code = f"""

# Test the agent with realistic data scenarios
if __name__ == "__main__":
    import asyncio
    import os
    
    async def test_agent():
        # Initialize agent
        agent = {self._find_class_name(code)}()
        await agent.initialize()
        
        # Test queries for data analysis
        test_queries = [
            "sample_data.csv 파일의 매출 데이터를 분석해주세요",
            "월별 매출 트렌드와 지역별 성과를 시각화해주세요", 
            "제품 카테고리별 수익성 분석을 해주세요",
            "이상치와 특이 패턴을 찾아주세요"
        ]
        
        for i, query in enumerate(test_queries, 1):
            print(f"\\n=== Test {{i}}: {{query}} ===")
            
            try:
                response = await agent.process(query)
                
                print(f"Response type: {{response.response_type}}")
                
                if hasattr(response, 'content') and isinstance(response.content, dict):
                    if 'insights' in response.content:
                        print(f"Insights: {{response.content['insights'][:200]}}...")
                    if 'statistics' in response.content:
                        stats = response.content['statistics']
                        print(f"Statistics: {{len(stats)}} analysis categories")
                    if 'visualizations' in response.content:
                        viz = response.content['visualizations']
                        print(f"Visualizations: {{len(viz)}} charts generated")
                else:
                    print(f"Response: {{str(response.content)[:200]}}...")
                    
            except Exception as e:
                print(f"Error processing query: {{e}}")
        
        # Cleanup
        await agent.cleanup()
    
    # Run test
    asyncio.run(test_agent())
"""
        else:
            # Standard test for other agent types
            test_query = self._get_sample_query(analysis.domain)
            test_code = f"""

# Test the agent
if __name__ == "__main__":
    import asyncio
    
    async def test_agent():
        # Initialize agent
        agent = {self._find_class_name(code)}()
        
        # Test query
        test_query = "{test_query}"
        context = {{"user_id": "test_user", "session_id": "test_session"}}
        
        print(f"Testing agent with query: {{test_query}}")
        
        # Process query
        response = await agent.process(test_query, context)
        
        print(f"Response type: {{response.response_type if hasattr(response, 'response_type') else 'unknown'}}")
        print(f"Response content: {{response.content}}")
    
    # Run test
    asyncio.run(test_agent())
"""
        
        return code + test_code
    
    def _find_class_name(self, code: str) -> str:
        """Find the agent class name in the code"""
        import re
        
        # Look for class definition
        match = re.search(r'class\s+(\w+)\s*\(LogosAIAgent\)', code)
        if match:
            return match.group(1)
        
        # Fallback
        return "Agent"
    
    def _get_sample_query(self, domain: str) -> str:
        """Get a sample query for the domain"""
        
        domain_lower = (domain or '').lower()
        
        if 'data' in domain_lower or 'analysis' in domain_lower:
            return "매출 데이터를 분석하고 주요 인사이트를 제공해주세요"
        elif 'api' in domain_lower:
            return "사용자 정보를 API에서 조회해주세요"
        elif 'file' in domain_lower:
            return "업로드된 파일을 처리하고 요약해주세요"
        elif 'web' in domain_lower:
            return "웹사이트에서 최신 뉴스를 수집해주세요"
        else:
            return "요청된 작업을 수행해주세요"
    
    async def _create_fallback_code(self, analysis: QueryAnalysis) -> str:
        """Create minimal fallback code when generation fails"""
        
        class_name = await self._generate_class_name(analysis)
        agent_name = await self._generate_agent_name(analysis)
        
        return f"""from logosai import LogosAIAgent, AgentConfig, AgentResponse, AgentResponseType, AgentType
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


class {class_name}(LogosAIAgent):
    \"\"\"{analysis.query}\"\"\"
    
    def __init__(self):
        config = AgentConfig(
            name="{agent_name}",
            agent_type=AgentType.CUSTOM,
            description="{analysis.query}",
            version="1.0.0"
        )
        super().__init__(config)
        logger.info(f"{{self.config.name}} initialized")
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        \"\"\"Process the query and return results\"\"\"
        try:
            # TODO: Implement the main logic here
            result = {{
                "status": "not_implemented",
                "message": "This agent is not yet implemented",
                "query": query
            }}
            
            return AgentResponse(
                type=AgentResponseType.JSON,
                content=result
            )
            
        except Exception as e:
            logger.error(f"Error processing request: {{e}}")
            return AgentResponse(
                type=AgentResponseType.ERROR,
                content={{"error": str(e), "message": f"Error: {{str(e)}}"}}
            )


# Test the agent
if __name__ == "__main__":
    import asyncio
    
    async def test_agent():
        agent = {class_name}()
        response = await agent.process("Test query")
        print(f"Response: {{response.content}}")
    
    asyncio.run(test_agent())
"""
    
    async def _generate_class_name(self, analysis: QueryAnalysis) -> str:
        """Generate appropriate class name using LLM"""
        
        prompt = f"""사용자 요청을 분석하여 적절한 Python 클래스명을 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

규칙:
1. 영어로 된 의미 있는 클래스명
2. PascalCase 형식 (예: CustomerAnalysisAgent)
3. 'Agent'로 끝나야 함
4. 2-3개 단어로 구성 (너무 길지 않게)
5. 요청의 핵심 기능을 나타내야 함

예시:
- "고객 분석 에이전트" → CustomerAnalysisAgent
- "파일 처리 도구" → FileProcessingAgent
- "웹 크롤링 봇" → WebCrawlingAgent
- "데이터 시각화" → DataVisualizationAgent

클래스명만 반환해주세요 (추가 설명 없이):"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=100)
            
            # Extract class name from response
            import re
            class_name = result.strip()
            
            # Remove any extra text and get just the class name
            lines = class_name.split('\n')
            for line in lines:
                line = line.strip()
                if line and re.match(r'^[A-Z][a-zA-Z0-9]*Agent$', line):
                    return line
            
            # Fallback: try to extract from first line
            first_line = lines[0].strip()
            words = re.findall(r'[A-Z][a-zA-Z0-9]*', first_line)
            if words:
                class_name = words[0]
                if not class_name.endswith('Agent'):
                    class_name += 'Agent'
                return class_name
            
            # Final fallback
            return 'GeneralPurposeAgent'
            
        except Exception as e:
            logger.warning(f"LLM class name generation failed: {e}")
            return self._fallback_class_name(analysis)
    
    async def _generate_agent_name(self, analysis: QueryAnalysis) -> str:
        """Generate human-readable agent name using LLM"""
        
        prompt = f"""사용자 요청을 분석하여 적절한 에이전트 이름을 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

규칙:
1. 사용자에게 표시되는 친숙한 이름
2. 한글 또는 영어 모두 가능
3. 2-4개 단어로 구성
4. "에이전트" 또는 "Agent"로 끝남
5. 요청의 목적을 명확히 표현

예시:
- "고객 분석 에이전트" → "고객 행동 분석 에이전트"
- "파일 처리 도구" → "파일 처리 에이전트"
- "웹 크롤링 봇" → "웹 크롤링 에이전트"
- "데이터 시각화" → "데이터 시각화 에이전트"

에이전트 이름만 반환해주세요 (추가 설명 없이):"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=100)
            
            # Extract agent name from response
            agent_name = result.strip()
            
            # Clean up the response
            lines = agent_name.split('\n')
            for line in lines:
                line = line.strip()
                if line and ('에이전트' in line or 'Agent' in line):
                    return line
            
            # Fallback: use first non-empty line and ensure it ends properly
            first_line = lines[0].strip()
            if first_line:
                if not (first_line.endswith('에이전트') or first_line.endswith('Agent')):
                    if any(ord(c) > 127 for c in first_line):  # Contains non-ASCII (likely Korean)
                        first_line += ' 에이전트'
                    else:
                        first_line += ' Agent'
                return first_line
            
            # Final fallback
            return self._fallback_agent_name(analysis)
            
        except Exception as e:
            logger.warning(f"LLM agent name generation failed: {e}")
            return self._fallback_agent_name(analysis)
    
    def _get_agent_type(self, analysis: QueryAnalysis) -> str:
        """Map analysis to AgentType enum value"""
        domain_lower = (analysis.domain or '').lower()
        
        # Use actual LogosAI AgentType values
        if any(keyword in domain_lower for keyword in ['search', 'find', 'query']):
            return "SEARCH"
        elif any(keyword in domain_lower for keyword in ['task', 'classify']):
            return "TASK_CLASSIFIER"
        elif any(keyword in domain_lower for keyword in ['llm', 'ai', 'model']):
            return "LLM_INTEGRATION"
        else:
            # Most agents should be CUSTOM type
            return "CUSTOM"
    
    async def _validate_and_fix(self, code: str, stream_callback: Optional[Callable] = None) -> str:
        """Enhanced validation with complete testing pipeline"""
        
        # Phase 1: Post-processing
        code = self._postprocess_generated_code(code)
        
        # Phase 2: Basic syntax validation
        is_valid, syntax_issues = self._validate_generated_code(code)
        
        # Auto-add imports if missing
        if "LogosAI import missing" in syntax_issues and 'from logosai import' not in code:
            imports = """from logosai import LogosAIAgent, AgentConfig, AgentResponse, AgentResponseType, AgentType
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

"""
            code = imports + code
            is_valid, syntax_issues = self._validate_generated_code(code)
        
        # Phase 3: Fix syntax issues
        if not is_valid and syntax_issues:
            if stream_callback:
                await stream_callback(
                    "fixing",
                    f"🔧 구문 오류를 수정하고 있습니다: {', '.join(syntax_issues[:2])}",
                    {"issues": syntax_issues}
                )
            code = await self._fix_code_issues(code, syntax_issues)
        
        # Phase 4: Structure validation
        structure_valid, structure_issues = self._validate_agent_structure(code)
        if not structure_valid:
            if stream_callback:
                await stream_callback(
                    "fixing",
                    f"🏗️ 에이전트 구조를 수정하고 있습니다: {', '.join(structure_issues[:2])}",
                    {"issues": structure_issues}
                )
            code = await self._fix_structure_issues(code, structure_issues)
        
        # Phase 5: Execution testing
        if stream_callback:
            await stream_callback(
                "testing",
                "🧪 에이전트 실행 가능성을 테스트하고 있습니다...",
                {"phase": "execution_test"}
            )
        
        execution_valid, execution_issues = await self._test_agent_execution(code)
        
        # Phase 6: Final validation report
        if stream_callback:
            if execution_valid:
                await stream_callback(
                    "validation",
                    "✅ 완전한 에이전트 검증이 완료되었습니다!",
                    {"syntax_valid": is_valid, "structure_valid": structure_valid, "execution_valid": execution_valid}
                )
            else:
                await stream_callback(
                    "warning",
                    f"⚠️ 일부 실행 문제가 발견되었습니다: {execution_issues[0] if execution_issues else 'Unknown'}",
                    {"execution_issues": execution_issues}
                )
        
        return code
    
    def _fallback_class_name(self, analysis: QueryAnalysis) -> str:
        """Fallback method for class name generation when LLM fails"""
        query = analysis.query.lower()
        
        # Simple keyword mapping as fallback
        if '고객' in query or 'customer' in query:
            return 'CustomerAnalysisAgent'
        elif '파일' in query or 'file' in query:
            return 'FileProcessingAgent'
        elif '웹' in query or 'web' in query:
            return 'WebScrapingAgent'
        elif '데이터' in query or 'data' in query:
            return 'DataProcessingAgent'
        elif '분석' in query or 'analysis' in query:
            return 'DataAnalysisAgent'
        else:
            return 'GeneralPurposeAgent'
    
    def _fallback_agent_name(self, analysis: QueryAnalysis) -> str:
        """Fallback method for agent name generation when LLM fails"""
        domain = analysis.domain or 'General'
        return f"{domain} Assistant Agent"
    
    async def _generate_data_sources(self, analysis: QueryAnalysis) -> str:
        """Generate data sources configuration for template"""
        
        prompt = f"""사용자 요청을 분석하여 적절한 데이터 소스 설정을 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

다음 형식의 Python 딕셔너리를 생성해주세요:
- 파일 기반: ["csv", "excel", "json"]
- API 기반: ["rest_api", "database"]  
- 웹 기반: ["web_scraping", "rss"]
- 실시간: ["streaming", "websocket"]

딕셔너리만 반환해주세요 (설명 없이):
예시: ["csv", "json", "database"]"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=200)
            
            # Extract list from response
            import re
            list_match = re.search(r'\[.*?\]', result)
            if list_match:
                return list_match.group()
            
            # Fallback based on domain
            return self._fallback_data_sources(analysis)
            
        except Exception as e:
            logger.warning(f"Data sources generation failed: {e}")
            return self._fallback_data_sources(analysis)
    
    def _fallback_data_sources(self, analysis: QueryAnalysis) -> str:
        """Fallback data sources based on domain"""
        domain = (analysis.domain or '').lower()
        
        if 'api' in domain:
            return '["rest_api", "json"]'
        elif 'web' in domain:
            return '["web_scraping", "json"]'
        elif 'data' in domain or 'analysis' in domain:
            # For data analysis, include realistic sample data
            return '["csv", "excel", "json", "sample_data.csv"]'
        else:
            return '["json", "csv"]'
    
    async def _generate_sample_data_file(self, analysis: QueryAnalysis) -> str:
        """Generate realistic sample data file content for data analysis agents"""
        
        prompt = f"""사용자의 데이터 분석 요청에 맞는 현실적인 CSV 샘플 데이터를 생성해주세요.

사용자 요청: {analysis.query}

다음 규칙에 따라 CSV 데이터를 생성해주세요:
1. 실제 비즈니스 상황을 반영한 현실적인 데이터
2. 20-50행 정도의 적당한 크기
3. 한국 비즈니스 컨텍스트 반영 (원화, 한국 지역명 등)
4. 다양한 데이터 타입 포함 (숫자, 날짜, 카테고리 등)
5. 분석하기 흥미로운 패턴과 트렌드 포함

예시 형태:
날짜,매출액,지역,제품카테고리,고객수
2023-01-01,15000000,서울,전자제품,245
2023-01-02,12500000,부산,의류,198

CSV 헤더와 데이터만 반환해주세요:"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=1000)
            
            # Clean the CSV data
            lines = result.strip().split('\n')
            csv_lines = []
            for line in lines:
                if line.strip() and ',' in line:
                    csv_lines.append(line.strip())
            
            if len(csv_lines) >= 2:  # At least header + 1 data row
                return '\n'.join(csv_lines)
            else:
                return self._fallback_sample_data()
                
        except Exception as e:
            logger.warning(f"Sample data generation failed: {e}")
            return self._fallback_sample_data()
    
    def _fallback_sample_data(self) -> str:
        """Fallback sample data for data analysis"""
        return '''날짜,매출액,지역,제품카테고리,고객수,평균주문금액
2023-01-01,15000000,서울,전자제품,245,61224
2023-01-02,12500000,부산,의류,198,63131
2023-01-03,18750000,대구,가전제품,312,60096
2023-01-04,9800000,인천,도서,156,62821
2023-01-05,22100000,광주,스포츠용품,387,57108
2023-01-06,16700000,대전,화장품,289,57785
2023-01-07,13900000,울산,식품,234,59402
2023-01-08,19850000,수원,전자제품,321,61839
2023-01-09,11200000,창원,의류,178,62921
2023-01-10,25600000,고양,가전제품,421,60809
2023-01-11,14300000,용인,도서,228,62719
2023-01-12,21400000,성남,스포츠용품,356,60112
2023-01-13,17800000,청주,화장품,294,60544
2023-01-14,12800000,전주,식품,209,61244
2023-01-15,23200000,안산,전자제품,378,61376'''
    
    async def _create_sample_data_files(self, analysis: QueryAnalysis) -> None:
        """Create realistic sample data files for data analysis agents"""
        try:
            import os
            
            # Create sample data directory
            sample_data_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'agents', 'sample_data')
            os.makedirs(sample_data_dir, exist_ok=True)
            
            # Generate sample CSV data
            csv_content = await self._generate_sample_data_file(analysis)
            
            # Save to sample_data.csv
            csv_file_path = os.path.join(sample_data_dir, 'sample_data.csv')
            with open(csv_file_path, 'w', encoding='utf-8') as f:
                f.write(csv_content)
            
            # Also create a JSON version for versatility
            import pandas as pd
            from io import StringIO
            
            try:
                df = pd.read_csv(StringIO(csv_content))
                json_content = df.to_json(orient='records', ensure_ascii=False, indent=2)
                
                json_file_path = os.path.join(sample_data_dir, 'sample_data.json')
                with open(json_file_path, 'w', encoding='utf-8') as f:
                    f.write(json_content)
                    
                logger.info(f"Created sample data files: {csv_file_path}, {json_file_path}")
                
            except Exception as json_error:
                logger.warning(f"Failed to create JSON sample data: {json_error}")
                
        except Exception as e:
            logger.warning(f"Failed to create sample data files: {e}")
    
    async def _generate_custom_init(self, analysis: QueryAnalysis) -> str:
        """Generate custom initialization code for template"""
        
        prompt = f"""사용자 요청을 분석하여 에이전트 초기화에 필요한 추가 코드를 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

다음과 같은 초기화 코드를 생성해주세요:
- 설정 변수 설정
- 외부 라이브러리 초기화  
- 캐시 또는 저장소 설정
- 도메인별 특수 설정

Python 코드만 반환해주세요 (주석 포함):"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=2000)
            
            # Clean and format the code
            code = self._clean_generated_code(result)
            return code if code.strip() else "# No additional initialization required"
            
        except Exception as e:
            logger.warning(f"Custom init generation failed: {e}")
            return "# No additional initialization required"
    
    async def _generate_custom_async_init(self, analysis: QueryAnalysis) -> str:
        """Generate custom async initialization code for template"""
        
        prompt = f"""사용자 요청을 분석하여 에이전트의 비동기 초기화에 필요한 코드를 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

다음과 같은 비동기 초기화 코드를 생성해주세요:
- 외부 API 연결 설정
- 데이터베이스 연결 초기화
- 웹소켓 또는 스트림 연결
- 비동기 리소스 로딩

Python async 코드만 반환해주세요 (주석 포함):"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=2000)
            
            # Clean and format the code
            code = self._clean_generated_code(result)
            return code if code.strip() else "# No additional async initialization required"
            
        except Exception as e:
            logger.warning(f"Custom async init generation failed: {e}")
            return "# No additional async initialization required"
    
    async def _generate_test_queries(self, analysis: QueryAnalysis) -> str:
        """Generate realistic test queries for template"""
        
        # For data analysis agents, generate comprehensive sample data
        if 'data' in (analysis.domain or '').lower() or 'analysis' in (analysis.domain or '').lower():
            return await self._generate_sample_data_queries(analysis)
        
        prompt = f"""사용자 요청을 분석하여 현실적인 테스트 쿼리들을 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

다음 규칙에 따라 3-5개의 테스트 쿼리를 생성해주세요:
- 실제 사용될 법한 현실적인 요청
- 다양한 복잡도 (간단/중간/복잡)
- 에러 케이스도 포함
- 한국어로 작성

Python 리스트 형태로만 반환해주세요:
예시: ["간단한 요청", "복잡한 분석 요청", "에러 케이스"]"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=400)
            
            # Extract list from response
            import re
            list_match = re.search(r'\[.*?\]', result, re.DOTALL)
            if list_match:
                return list_match.group()
            
            # Fallback
            return self._fallback_test_queries(analysis)
            
        except Exception as e:
            logger.warning(f"Test queries generation failed: {e}")
            return self._fallback_test_queries(analysis)
    
    async def _generate_sample_data_queries(self, analysis: QueryAnalysis) -> str:
        """Generate sample data with realistic datasets for data analysis agents"""
        
        prompt = f"""사용자의 데이터 분석 요청을 분석하여 현실적인 샘플 데이터와 테스트 쿼리를 생성해주세요.

사용자 요청: {analysis.query}

다음 형태로 Python 리스트를 생성해주세요:
1. 실제 CSV/JSON 데이터를 시뮬레이션하는 쿼리들
2. 다양한 분석 유형 (기본 통계, 트렌드 분석, 상관관계 등)
3. 한국 비즈니스 상황을 반영한 현실적인 데이터

예시 형태:
[
    "매출 데이터 (월별): 2023년 1월-12월 매출 분석",
    "고객 행동 데이터: 웹사이트 방문자 패턴 분석", 
    "재고 관리 데이터: 상품별 재고 현황과 회전율 분석"
]

Python 리스트만 반환해주세요:"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=600)
            
            # Extract list from response
            import re
            list_match = re.search(r'\[.*?\]', result, re.DOTALL)
            if list_match:
                return list_match.group()
            
            # Fallback to comprehensive data analysis queries
            return self._fallback_data_analysis_queries()
            
        except Exception as e:
            logger.warning(f"Sample data queries generation failed: {e}")
            return self._fallback_data_analysis_queries()
    
    def _fallback_data_analysis_queries(self) -> str:
        """Fallback comprehensive data analysis queries"""
        return '''[
    "매출 데이터 분석: 2023년 월별 매출 동향과 계절성 패턴 분석",
    "고객 세그먼테이션: RFM 분석을 통한 고객 그룹 분류 및 특성 분석",
    "재고 최적화: 상품별 회전율과 수요 예측 분석",
    "웹 트래픽 분석: 방문자 행동 패턴과 전환율 분석",
    "A/B 테스트 결과: 마케팅 캠페인 효과 측정 및 통계적 유의성 검증"
]'''
    
    def _fallback_test_queries(self, analysis: QueryAnalysis) -> str:
        """Fallback test queries based on domain"""
        domain = (analysis.domain or '').lower()
        
        if 'data' in domain or 'analysis' in domain:
            return self._fallback_data_analysis_queries()
        elif 'api' in domain:
            return '["사용자 정보를 조회해주세요", "데이터를 업데이트해주세요", "상태를 확인해주세요"]'
        elif 'web' in domain:
            return '["최신 뉴스를 수집해주세요", "특정 사이트를 모니터링해주세요", "데이터를 추출해주세요"]'
        else:
            return '["요청을 처리해주세요", "정보를 제공해주세요", "작업을 수행해주세요"]'
    
    async def _generate_custom_cleanup(self, analysis: QueryAnalysis) -> str:
        """Generate custom cleanup code for template"""
        
        prompt = f"""사용자 요청을 분석하여 에이전트 정리 시 필요한 코드를 생성해주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

다음과 같은 정리 코드를 생성해주세요:
- 연결 해제 (DB, API, 웹소켓 등)
- 파일 또는 리소스 정리
- 캐시 클리어
- 임시 데이터 삭제

Python 코드만 반환해주세요 (주석 포함):"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=2000)
            
            # Clean and format the code
            code = self._clean_generated_code(result)
            return code if code.strip() else "# No additional cleanup required"
            
        except Exception as e:
            logger.warning(f"Custom cleanup generation failed: {e}")
            return "# No additional cleanup required"
    
    async def _generate_insights_prompt(self, analysis: QueryAnalysis) -> str:
        """Generate insights generation prompt for template"""
        
        prompt = f"""사용자 요청을 분석하여 인사이트 생성에 사용할 프롬프트를 만들어주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

LLM이 데이터 분석 결과를 받아서 인사이트를 생성할 때 사용할 프롬프트를 작성해주세요.
도메인에 특화된 분석 관점과 용어를 포함해주세요.

프롬프트 텍스트만 반환해주세요:"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=2000)
            return result.strip() or "데이터 분석 결과를 바탕으로 주요 인사이트와 추천사항을 제공해주세요."
            
        except Exception as e:
            logger.warning(f"Insights prompt generation failed: {e}")
            return "데이터 분석 결과를 바탕으로 주요 인사이트와 추천사항을 제공해주세요."
    
    async def _generate_query_extraction_prompt(self, analysis: QueryAnalysis) -> str:
        """Generate query extraction prompt for template"""
        
        prompt = f"""사용자 요청을 분석하여 쿼리 추출에 사용할 프롬프트를 만들어주세요.

사용자 요청: {analysis.query}
도메인: {analysis.domain or 'General'}

사용자의 자연어 요청에서 구조화된 정보를 추출할 때 사용할 프롬프트를 작성해주세요.
도메인에 특화된 정보 추출 항목을 포함해주세요.

프롬프트 텍스트만 반환해주세요:"""

        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=2000)
            return result.strip() or "사용자 요청에서 주요 정보와 요구사항을 추출해주세요."
            
        except Exception as e:
            logger.warning(f"Query extraction prompt generation failed: {e}")
            return "사용자 요청에서 주요 정보와 요구사항을 추출해주세요."
    
    async def _generate_response_generation_prompt(self, analysis: QueryAnalysis) -> str:
        """Generate response generation prompt based on query analysis"""
        
        prompt = f"""다음 도메인에 적합한 응답 생성 프롬프트를 만들어주세요.
도메인: {analysis.domain or 'General'}
사용자 요청: {analysis.query}

응답 생성 프롬프트는 처리 결과를 사용자에게 전달할 때 사용됩니다.
명확하고 도움이 되는 응답을 생성하도록 가이드해주세요.

프롬프트만 반환해주세요 (추가 설명 없이):"""
        
        try:
            result = await self.llm.process_task(prompt, TaskType.CODE_GENERATION, max_tokens=200)
            return result.strip()
            
        except Exception as e:
            logger.warning(f"Response generation prompt generation failed: {e}")
            return "제공된 데이터를 기반으로 명확하고 도움이 되는 응답을 생성해주세요."
    
    def _clean_generated_code(self, code: str) -> str:
        """Clean generated code by removing markdown and extra text"""
        
        # Remove markdown code blocks
        import re
        code = re.sub(r'```python\n?', '', code)
        code = re.sub(r'```\n?', '', code)
        
        # Split into lines and filter
        lines = code.split('\n')
        code_lines = []
        
        for line in lines:
            # Skip empty lines at start, keep them in middle
            if not code_lines and not line.strip():
                continue
            # Skip explanatory text that doesn't look like code
            if line.strip() and not line.lstrip().startswith('#') and not any(c in line for c in '=()[]{}'):
                if line.count(' ') > len(line) * 0.7:  # Too many spaces, likely text
                    continue
            code_lines.append(line)
        
        return '\n'.join(code_lines).strip()
    
    def _validate_agent_structure(self, code: str) -> tuple[bool, List[str]]:
        """Validate LogosAI agent structure requirements"""
        issues = []
        
        # Check for required imports
        required_imports = [
            "from logosai import LogosAIAgent",
            "from logosai.agent import LogosAIAgent",
            "LogosAIAgent"
        ]
        
        has_import = any(imp in code for imp in required_imports)
        if not has_import:
            issues.append("Missing LogosAIAgent import")
        
        # Check for agent inheritance
        if "class" not in code or "LogosAIAgent" not in code:
            issues.append("Agent class does not inherit from LogosAIAgent")
        
        # Check for required methods
        if "async def process(" not in code:
            issues.append("Missing async def process() method")
        
        if "AgentResponse" not in code:
            issues.append("Missing AgentResponse return type")
        
        # Check for proper response types
        invalid_response_types = [
            "AgentResponseType.SUCCESS",
            "AgentResponseType.INFO", 
            "AgentResponseType.WARNING"
        ]
        
        for invalid_type in invalid_response_types:
            if invalid_type in code:
                issues.append(f"Using invalid response type: {invalid_type}")
        
        return len(issues) == 0, issues

    async def _fix_structure_issues(self, code: str, issues: List[str]) -> str:
        """Fix agent structure issues"""
        
        fixes_prompt = f"""다음 LogosAI 에이전트 코드의 구조적 문제를 수정해주세요:

발견된 문제들:
{chr(10).join([f"- {issue}" for issue in issues])}

수정해야 할 코드:
```python
{code}
```

다음 요구사항을 반드시 준수해주세요:
1. LogosAIAgent를 상속받는 클래스 구조
2. async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse 메서드
3. AgentResponse 반환 시 response_type은 JSON, TEXT, HTML, ERROR만 사용
4. 적절한 imports 포함
5. 완전한 에러 처리

수정된 완전한 코드만 반환해주세요:"""
        
        try:
            result = await self.llm.generate(
                prompt=fixes_prompt,
                task_type=TaskType.CODE_FIXING,
                max_tokens=4000
            )
            
            fixed_code = self._extract_code_from_response(result)
            return fixed_code if fixed_code else code
            
        except Exception as e:
            logger.error(f"Structure fixing failed: {e}")
            return code

    async def _test_agent_execution(self, code: str) -> tuple[bool, List[str]]:
        """Test if the generated agent can be executed"""
        issues = []
        
        try:
            # Create a temporary test environment
            test_globals = {}
            test_locals = {}
            
            # Add required imports to test environment
            imports_code = """
import asyncio
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

# Mock LogosAI framework for testing
class AgentResponseType:
    JSON = "JSON"
    TEXT = "TEXT"
    HTML = "HTML"
    ERROR = "ERROR"

class AgentConfig:
    def __init__(self, name, agent_type=None, description="", version="1.0.0", **kwargs):
        self.name = name
        self.agent_type = agent_type
        self.description = description
        self.version = version
        
class AgentType:
    CUSTOM = "custom"
    DATA_ANALYSIS = "data_analysis"
    API_INTEGRATION = "api_integration"

class AgentResponse:
    def __init__(self, agent_id="test", agent_name="test", response_type="JSON", content=None, metadata=None):
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.response_type = response_type
        self.content = content or {}
        self.metadata = metadata or {}

class LogosAIAgent:
    def __init__(self, config):
        self.config = config
        self.id = "test-agent"
        self.name = config.name
        
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> AgentResponse:
        raise NotImplementedError

logger = logging.getLogger(__name__)
"""
            
            # Execute imports first
            exec(imports_code, test_globals, test_locals)
            
            # Execute the agent code
            exec(code, test_globals, test_locals)
            
            # Find the agent class
            agent_class = None
            for name, obj in test_locals.items():
                if (isinstance(obj, type) and 
                    hasattr(obj, '__bases__') and 
                    any('LogosAIAgent' in str(base) for base in obj.__bases__)):
                    agent_class = obj
                    break
            
            if not agent_class:
                issues.append("No valid agent class found")
                return False, issues
            
            # Try to instantiate the agent
            try:
                agent_instance = agent_class()
                
                # Test basic process call
                result = await agent_instance.process("test query")
                
                if not hasattr(result, 'response_type'):
                    issues.append("process() method does not return proper AgentResponse")
                
            except Exception as e:
                issues.append(f"Agent instantiation/execution failed: {str(e)}")
                
        except SyntaxError as e:
            issues.append(f"Syntax error: {str(e)}")
        except Exception as e:
            issues.append(f"Execution test failed: {str(e)}")
        
        return len(issues) == 0, issues