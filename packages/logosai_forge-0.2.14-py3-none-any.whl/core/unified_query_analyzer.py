"""
Unified Query Analyzer for FORGE AI
통합된 단일 쿼리 분석기 - 모든 쿼리 분석 로직을 하나로 통합

Author: FORGE AI Team
Date: 2025-01-21
Version: 1.0.0
"""

from typing import Dict, List, Optional, Any, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import logging
import json
import re
from datetime import datetime

logger = logging.getLogger(__name__)


class Complexity(Enum):
    """Query complexity levels"""
    SIMPLE = "simple"      # Single task, clear requirements
    MEDIUM = "medium"      # Multiple steps, some ambiguity
    COMPLEX = "complex"    # Complex workflow, many requirements
    EXPERT = "expert"      # Requires domain expertise


class WorkflowType(Enum):
    """Types of agent workflows"""
    SINGLE_TASK = "single_task"
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    CONDITIONAL = "conditional"
    HYBRID = "hybrid"


@dataclass
class QueryAnalysisResult:
    """
    통합된 쿼리 분석 결과
    모든 필요한 메타데이터를 포함
    """
    # 기본 정보
    query: str
    intent: str
    domain: Optional[str] = None
    
    # 분석 결과
    entities: Dict[str, List[str]] = field(default_factory=dict)
    required_capabilities: List[str] = field(default_factory=list)
    constraints: Dict[str, Any] = field(default_factory=dict)
    
    # 복잡도 및 워크플로우
    complexity: Complexity = Complexity.SIMPLE
    workflow_type: WorkflowType = WorkflowType.SINGLE_TASK
    
    # 메타데이터 (비즈니스 로직 생성에 필수)
    agent_metadata: Dict[str, Any] = field(default_factory=dict)
    
    # 테스트 데이터
    test_samples: List[Dict[str, Any]] = field(default_factory=list)
    
    # 신뢰도 및 제안
    confidence: float = 0.0
    suggestions: List[str] = field(default_factory=list)
    
    # 실행 관련
    requires_execution: bool = False
    template_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'query': self.query,
            'intent': self.intent,
            'domain': self.domain,
            'entities': self.entities,
            'required_capabilities': self.required_capabilities,
            'constraints': self.constraints,
            'complexity': self.complexity.value,
            'workflow_type': self.workflow_type.value,
            'agent_metadata': self.agent_metadata,
            'test_samples': self.test_samples,
            'confidence': self.confidence,
            'suggestions': self.suggestions,
            'requires_execution': self.requires_execution,
            'template_id': self.template_id,
            'timestamp': datetime.now().isoformat()
        }
    
    def ensure_metadata(self):
        """메타데이터가 완전한지 확인하고 기본값 설정"""
        defaults = {
            'agent_class_name': 'GeneratedAgent',
            'agent_name': 'Generated Agent',
            'agent_description': 'Auto-generated agent for processing requests',
            'agent_type': 'CUSTOM',
            'version': '1.0.0'
        }
        
        for key, default_value in defaults.items():
            if key not in self.agent_metadata or not self.agent_metadata[key]:
                self.agent_metadata[key] = default_value
                logger.debug(f"Added default metadata: {key}={default_value}")


class UnifiedQueryAnalyzer:
    """
    통합된 쿼리 분석기
    모든 쿼리 분석 로직을 하나로 통합하여 일관성 보장
    """
    
    # 통합된 capability patterns
    CAPABILITY_PATTERNS = {
        'database': {
            'keywords': ['database', 'db', 'sql', 'query', 'table', 'postgres', 'mysql', 'mongodb', '데이터베이스', 'select', 'insert'],
            'weight': 1.0
        },
        'api': {
            'keywords': ['api', 'endpoint', 'rest', 'http', 'request', 'webhook', 'graphql', 'soap'],
            'weight': 1.0
        },
        'file': {
            'keywords': ['file', 'csv', 'excel', 'json', 'xml', 'read', 'write', 'parse', '파일', 'pdf', 'document'],
            'weight': 0.9
        },
        'data_processing': {
            'keywords': ['process', 'transform', 'analyze', 'calculate', 'aggregate', '분석', '처리', 'compute', 'extract'],
            'weight': 0.9
        },
        'ml': {
            'keywords': ['predict', 'classify', 'model', 'train', 'machine learning', 'ai', '예측', '분류', 'neural', 'deep learning'],
            'weight': 1.2
        },
        'web_scraping': {
            'keywords': ['scrape', 'extract', 'crawl', 'website', 'html', 'selenium', 'beautifulsoup', '크롤링'],
            'weight': 1.0
        },
        'monitoring': {
            'keywords': ['monitor', 'track', 'watch', 'observe', 'detect', 'alert', '모니터링', '감시', 'metric'],
            'weight': 0.8
        },
        'scheduling': {
            'keywords': ['schedule', 'cron', 'daily', 'hourly', 'periodic', 'every', '스케줄', '주기적', 'recurring'],
            'weight': 0.9
        },
        'notification': {
            'keywords': ['email', 'alert', 'notify', 'send', 'message', 'slack', 'sms', '알림', '메시지', 'push'],
            'weight': 0.8
        },
        'integration': {
            'keywords': ['integrate', 'connect', 'sync', 'bridge', 'combine', '통합', '연동', 'merge'],
            'weight': 0.9
        },
        'visualization': {
            'keywords': ['chart', 'graph', 'plot', 'dashboard', 'visualize', '차트', '그래프', '시각화', 'd3', 'plotly'],
            'weight': 0.9
        },
        'streaming': {
            'keywords': ['stream', 'real-time', 'live', 'continuous', 'websocket', '실시간', 'kafka', 'pubsub'],
            'weight': 1.1
        }
    }
    
    # 통합된 domain patterns
    DOMAIN_PATTERNS = {
        'finance': {
            'keywords': ['trading', 'finance', 'payment', 'transaction', 'bank', 'stock', 'crypto', '주식', '금융', '거래', '투자', 'portfolio', 'investment'],
            'weight': 1.2
        },
        'ecommerce': {
            'keywords': ['product', 'order', 'customer', 'cart', 'shop', 'inventory', '제품', '주문', '고객', '구매', '판매', '매출', 'catalog', 'checkout'],
            'weight': 1.1
        },
        'healthcare': {
            'keywords': ['patient', 'medical', 'health', 'diagnosis', 'treatment', '환자', '의료', '건강', '진단', '치료', 'clinical', 'prescription'],
            'weight': 1.2
        },
        'manufacturing': {
            'keywords': ['production', 'factory', 'assembly', 'quality', 'supply chain', '생산', '공장', '제조', '품질', 'logistics', 'inventory'],
            'weight': 1.0
        },
        'marketing': {
            'keywords': ['campaign', 'lead', 'conversion', 'seo', 'advertising', '캠페인', '마케팅', '광고', '홍보', 'engagement', 'analytics'],
            'weight': 1.0
        },
        'hr': {
            'keywords': ['employee', 'recruitment', 'payroll', 'attendance', 'performance', '직원', '채용', '급여', '인사', 'talent', 'onboarding'],
            'weight': 1.0
        },
        'iot': {
            'keywords': ['sensor', 'device', 'telemetry', 'mqtt', 'industrial', '센서', '기기', '장치', 'embedded', 'edge'],
            'weight': 1.1
        },
        'education': {
            'keywords': ['student', 'course', 'learning', 'education', 'training', '학생', '교육', '학습', '과정', 'curriculum', 'assessment'],
            'weight': 1.0
        },
        'social_media': {
            'keywords': ['post', 'tweet', 'share', 'follow', 'like', '게시', '팔로우', '좋아요', 'instagram', 'twitter', 'facebook'],
            'weight': 0.9
        },
        'analytics': {
            'keywords': ['analysis', 'report', 'metric', 'kpi', 'dashboard', '분석', '보고서', '지표', 'insight', 'trend'],
            'weight': 1.1
        }
    }
    
    def __init__(self):
        """Initialize the unified query analyzer"""
        self.keyword_cache = {}
        self._compile_patterns()
    
    def _compile_patterns(self):
        """Compile regex patterns for faster matching"""
        for cap_name, cap_data in self.CAPABILITY_PATTERNS.items():
            pattern = '|'.join(re.escape(kw) for kw in cap_data['keywords'])
            self.keyword_cache[f'cap_{cap_name}'] = re.compile(pattern, re.IGNORECASE)
        
        for dom_name, dom_data in self.DOMAIN_PATTERNS.items():
            pattern = '|'.join(re.escape(kw) for kw in dom_data['keywords'])
            self.keyword_cache[f'dom_{dom_name}'] = re.compile(pattern, re.IGNORECASE)
    
    async def analyze(self, query: str, user_email: Optional[str] = None) -> QueryAnalysisResult:
        """
        통합된 쿼리 분석 메서드
        
        Args:
            query: User query string
            
        Returns:
            QueryAnalysisResult with complete analysis
        """
        logger.info(f"Analyzing query: {query[:100]}...")
        
        # Initialize result
        result = QueryAnalysisResult(
            query=query,
            intent=self._extract_intent(query)
        )
        
        # Parallel analysis tasks
        tasks = [
            self._analyze_capabilities(query, result),
            self._analyze_domain(query, result),
            self._analyze_complexity(query, result),
            self._extract_entities(query, result),
            self._generate_test_samples(query, result),
            self._generate_metadata(query, result)
        ]
        
        await asyncio.gather(*tasks)
        
        # Calculate confidence
        result.confidence = self._calculate_confidence(result)
        
        # Ensure metadata completeness
        result.ensure_metadata()
        
        # Generate suggestions if confidence is low
        if result.confidence < 0.7:
            result.suggestions = self._generate_suggestions(result)
        
        logger.info(f"Analysis complete. Confidence: {result.confidence:.2f}")
        return result
    
    def _extract_intent(self, query: str) -> str:
        """Extract the primary intent from the query"""
        query_lower = query.lower()
        
        # Intent patterns
        intent_patterns = {
            'create': ['create', 'make', 'build', 'generate', '만들', '생성'],
            'analyze': ['analyze', 'examine', 'investigate', '분석', '조사'],
            'monitor': ['monitor', 'track', 'watch', '모니터', '추적'],
            'process': ['process', 'transform', 'convert', '처리', '변환'],
            'integrate': ['integrate', 'connect', 'sync', '통합', '연동'],
            'automate': ['automate', 'schedule', 'trigger', '자동화', '스케줄'],
            'extract': ['extract', 'scrape', 'fetch', '추출', '가져오기'],
            'predict': ['predict', 'forecast', 'estimate', '예측', '예상'],
            'optimize': ['optimize', 'improve', 'enhance', '최적화', '개선'],
            'report': ['report', 'summarize', 'aggregate', '보고', '요약']
        }
        
        for intent, keywords in intent_patterns.items():
            if any(kw in query_lower for kw in keywords):
                return intent
        
        return 'process'  # default intent
    
    async def _analyze_capabilities(self, query: str, result: QueryAnalysisResult):
        """Analyze required capabilities"""
        query_lower = query.lower()
        capabilities_scores = {}
        
        for cap_name, cap_data in self.CAPABILITY_PATTERNS.items():
            pattern = self.keyword_cache.get(f'cap_{cap_name}')
            if pattern and pattern.search(query):
                score = len(pattern.findall(query)) * cap_data['weight']
                capabilities_scores[cap_name] = score
        
        # Sort by score and take top capabilities
        sorted_caps = sorted(capabilities_scores.items(), key=lambda x: x[1], reverse=True)
        result.required_capabilities = [cap[0] for cap in sorted_caps[:5]]
    
    async def _analyze_domain(self, query: str, result: QueryAnalysisResult):
        """Analyze the domain of the query"""
        query_lower = query.lower()
        domain_scores = {}
        
        for dom_name, dom_data in self.DOMAIN_PATTERNS.items():
            pattern = self.keyword_cache.get(f'dom_{dom_name}')
            if pattern and pattern.search(query):
                score = len(pattern.findall(query)) * dom_data['weight']
                domain_scores[dom_name] = score
        
        if domain_scores:
            result.domain = max(domain_scores, key=domain_scores.get)
    
    async def _analyze_complexity(self, query: str, result: QueryAnalysisResult):
        """Analyze query complexity"""
        # Complexity indicators
        indicators = {
            'simple': len(result.required_capabilities) <= 2 and len(query.split()) < 20,
            'medium': 2 < len(result.required_capabilities) <= 4 or 20 <= len(query.split()) < 50,
            'complex': 4 < len(result.required_capabilities) <= 6 or 50 <= len(query.split()) < 100,
            'expert': len(result.required_capabilities) > 6 or len(query.split()) >= 100
        }
        
        for complexity_level, condition in indicators.items():
            if condition:
                result.complexity = Complexity(complexity_level)
                break
        
        # Determine workflow type based on complexity and capabilities
        if result.complexity == Complexity.SIMPLE:
            result.workflow_type = WorkflowType.SINGLE_TASK
        elif result.complexity == Complexity.MEDIUM:
            result.workflow_type = WorkflowType.SEQUENTIAL
        elif result.complexity in [Complexity.COMPLEX, Complexity.EXPERT]:
            result.workflow_type = WorkflowType.HYBRID
    
    async def _extract_entities(self, query: str, result: QueryAnalysisResult):
        """Extract entities from the query"""
        # Entity patterns
        entity_patterns = {
            'numbers': r'\b\d+(?:\.\d+)?\b',
            'urls': r'https?://[^\s]+',
            'emails': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'dates': r'\b\d{4}[-/]\d{2}[-/]\d{2}\b',
            'times': r'\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|am|pm)?\b',
            'file_paths': r'[/.][^\s]*\.[a-zA-Z]+',
            'variables': r'\b[A-Z_][A-Z0-9_]*\b'
        }
        
        for entity_type, pattern in entity_patterns.items():
            matches = re.findall(pattern, query)
            if matches:
                result.entities[entity_type] = matches
    
    async def _generate_test_samples(self, query: str, result: QueryAnalysisResult):
        """Generate intelligent test samples based on analysis"""
        samples = []
        query_lower = query.lower()
        
        # Domain-specific sample generation
        if result.domain == 'finance':
            samples.extend([
                {
                    "query": "현재 삼성전자 주가를 알려줘",
                    "stock_symbol": "005930",
                    "market": "KOSPI"
                },
                {
                    "query": "포트폴리오 리스크 분석",
                    "portfolio": [
                        {"symbol": "AAPL", "shares": 100, "purchase_price": 150.0},
                        {"symbol": "GOOGL", "shares": 50, "purchase_price": 2800.0}
                    ]
                },
                {
                    "transaction_data": {
                        "date": "2024-01-15",
                        "amount": 1000000,
                        "type": "deposit",
                        "account": "investment"
                    }
                }
            ])
        elif result.domain == 'ecommerce':
            samples.extend([
                {
                    "query": "오늘 매출 현황 보고",
                    "date": "2024-01-20",
                    "store_id": "STORE001"
                },
                {
                    "customer_data": {
                        "id": "CUST123",
                        "name": "김철수",
                        "purchase_history": [
                            {"product": "노트북", "price": 1500000, "date": "2024-01-10"},
                            {"product": "마우스", "price": 50000, "date": "2024-01-15"}
                        ]
                    }
                },
                {
                    "product_data": {
                        "sku": "PRD001",
                        "name": "무선 이어폰",
                        "price": 200000,
                        "stock": 150
                    }
                }
            ])
        elif result.domain == 'analytics':
            samples.extend([
                {
                    "query": "월별 KPI 대시보드 생성",
                    "metrics": ["revenue", "conversion_rate", "customer_satisfaction"],
                    "period": "2024-01"
                },
                {
                    "data": {
                        "sales": [120, 150, 180, 200, 175, 210],
                        "months": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                        "regions": ["서울", "부산", "대구", "인천", "광주", "대전"]
                    }
                },
                {
                    "customer_segments": {
                        "vip": 150,
                        "regular": 800,
                        "new": 1200,
                        "inactive": 350
                    }
                }
            ])
        elif result.domain == 'social_media':
            samples.extend([
                {
                    "query": "인스타그램 게시물 자동 생성",
                    "content_type": "product_launch",
                    "hashtags": ["#신제품", "#출시", "#이벤트"]
                },
                {
                    "post_data": {
                        "platform": "twitter",
                        "text": "새로운 기능이 출시되었습니다!",
                        "media_urls": ["image1.jpg", "image2.jpg"],
                        "schedule_time": "2024-01-21T10:00:00"
                    }
                },
                {
                    "analytics": {
                        "impressions": 5000,
                        "engagements": 250,
                        "clicks": 100,
                        "shares": 30
                    }
                }
            ])
        elif result.domain == 'healthcare':
            samples.extend([
                {
                    "query": "환자 데이터 분석",
                    "patient_id": "PAT001",
                    "data_types": ["vitals", "medications", "lab_results"]
                },
                {
                    "health_metrics": {
                        "blood_pressure": "120/80",
                        "heart_rate": 72,
                        "temperature": 36.5,
                        "glucose_level": 95
                    }
                },
                {
                    "appointment_data": {
                        "patient": "홍길동",
                        "doctor": "Dr. Kim",
                        "date": "2024-01-25",
                        "type": "checkup"
                    }
                }
            ])
        
        # Capability-based sample generation
        if 'database' in result.required_capabilities:
            samples.append({
                "query": "SELECT * FROM users WHERE active = true",
                "database": "production_db",
                "connection_string": "postgresql://localhost:5432/mydb"
            })
        
        if 'api' in result.required_capabilities:
            samples.append({
                "endpoint": "https://api.example.com/v1/data",
                "method": "POST",
                "headers": {"Authorization": "Bearer token123", "Content-Type": "application/json"},
                "body": {"filter": "active", "limit": 100}
            })
        
        if 'file' in result.required_capabilities and ('csv' in query_lower or 'excel' in query_lower):
            samples.append({
                "file_path": "data/sales_report.csv",
                "encoding": "utf-8",
                "delimiter": ",",
                "columns": ["date", "product", "quantity", "revenue"]
            })
        
        if 'ml' in result.required_capabilities:
            samples.append({
                "training_data": {
                    "features": [[1, 2, 3], [4, 5, 6], [7, 8, 9]],
                    "labels": [0, 1, 0]
                },
                "model_type": "classification",
                "parameters": {"n_estimators": 100, "max_depth": 5}
            })
        
        if 'visualization' in result.required_capabilities:
            samples.append({
                "chart_type": "line",
                "data": {
                    "x": [1, 2, 3, 4, 5],
                    "y": [10, 15, 13, 17, 20],
                    "labels": ["Jan", "Feb", "Mar", "Apr", "May"]
                },
                "title": "Monthly Performance",
                "options": {"color": "#007bff", "grid": True}
            })
        
        if 'streaming' in result.required_capabilities:
            samples.append({
                "stream_config": {
                    "source": "websocket://stream.example.com",
                    "buffer_size": 1000,
                    "reconnect": True
                },
                "data_format": "json",
                "processing_interval": 100
            })
        
        if 'monitoring' in result.required_capabilities:
            samples.append({
                "metrics": ["cpu_usage", "memory_usage", "response_time"],
                "threshold_rules": {
                    "cpu_usage": {"warning": 70, "critical": 90},
                    "memory_usage": {"warning": 80, "critical": 95}
                },
                "alert_channels": ["email", "slack"]
            })
        
        if 'notification' in result.required_capabilities:
            samples.append({
                "notification_type": "email",
                "recipients": ["admin@example.com", "team@example.com"],
                "subject": "Daily Report",
                "template": "report_template",
                "data": {"date": "2024-01-20", "status": "success"}
            })
        
        # Extract sample data from query if contains specific data
        if '예시' in query_lower or 'example' in query_lower or '샘플' in query_lower:
            # Try to extract structured data from query
            import re
            json_pattern = r'\{[^}]+\}'
            matches = re.findall(json_pattern, query)
            for match in matches:
                try:
                    sample_data = json.loads(match)
                    samples.append(sample_data)
                except:
                    pass
        
        # Generate comprehensive default samples if none generated
        if not samples:
            # Generate based on intent
            if result.intent == 'analyze':
                samples.append({
                    "data": [
                        {"date": "2024-01-01", "value": 100, "category": "A"},
                        {"date": "2024-01-02", "value": 150, "category": "B"},
                        {"date": "2024-01-03", "value": 120, "category": "A"}
                    ],
                    "analysis_type": "trend"
                })
            elif result.intent == 'create':
                samples.append({
                    "name": "새 프로젝트",
                    "type": "data_processing",
                    "configuration": {
                        "input_format": "csv",
                        "output_format": "json"
                    }
                })
            elif result.intent == 'monitor':
                samples.append({
                    "target": "system_health",
                    "interval": 60,
                    "metrics": ["status", "performance", "errors"]
                })
            elif result.intent == 'process':
                samples.append({
                    "input_data": "raw data string or object",
                    "processing_steps": ["validate", "transform", "aggregate"],
                    "output_format": "processed"
                })
            else:
                # Generic fallback
                samples.append({
                    "query": query[:100],
                    "input": "sample input data",
                    "context": {
                        "timestamp": "2024-01-20T10:00:00",
                        "user": "test_user"
                    }
                })
        
        # Ensure we have at least 3 diverse samples
        while len(samples) < 3:
            samples.append({
                f"test_case_{len(samples)+1}": {
                    "input": f"test input {len(samples)+1}",
                    "expected": f"expected output {len(samples)+1}",
                    "scenario": f"scenario {len(samples)+1}"
                }
            })
        
        # Limit to 5 most relevant samples
        result.test_samples = samples[:5]
    
    async def _generate_metadata(self, query: str, result: QueryAnalysisResult):
        """Generate agent metadata"""
        query_lower = query.lower()
        
        # Check if query contains Korean
        has_korean = any(ord(char) >= 0xAC00 and ord(char) <= 0xD7A3 for char in query)
        
        agent_name = None
        agent_class_name = None
        
        if has_korean:
            # Korean query handling
            korean_agent_mappings = {
                # Common Korean agent types
                "계산": "Calculator",
                "날씨": "Weather",
                "주식": "Stock",
                "재고": "Inventory",
                "고객": "Customer",
                "분석": "Analysis",
                "데이터": "Data",
                "판매": "Sales",
                "리포트": "Report",
                "모니터링": "Monitoring",
                "대시보드": "Dashboard",
                "크롤링": "Crawler",
                "웹": "Web",
                "이메일": "Email",
                "알림": "Notification",
                "자동화": "Automation",
                "번역": "Translation",
                "검색": "Search",
                "추천": "Recommendation",
                "예측": "Prediction",
                "분류": "Classification",
                "요약": "Summary",
                "이미지": "Image",
                "음성": "Voice",
                "텍스트": "Text",
                "파일": "File",
                "데이터베이스": "Database",
                "API": "API",
                "통계": "Statistics",
                "차트": "Chart",
                "리스크": "Risk",
                "포트폴리오": "Portfolio",
                "금융": "Finance",
                "투자": "Investment",
                "매출": "Revenue",
                "비용": "Cost",
                "수익": "Profit",
                "재무": "Financial",
                "회계": "Accounting",
                "세금": "Tax",
                "급여": "Payroll",
                "인사": "HR",
                "채용": "Recruitment",
                "평가": "Evaluation",
                "보안": "Security",
                "인증": "Authentication",
                "권한": "Authorization",
                "로그": "Log",
                "감사": "Audit",
                "컴플라이언스": "Compliance"
            }
            
            # Try to find matching Korean keywords
            found_keywords = []
            for korean_word, english_word in korean_agent_mappings.items():
                if korean_word in query:
                    found_keywords.append(english_word)
            
            if found_keywords:
                # Use first 2 keywords for name
                if len(found_keywords) >= 2:
                    agent_class_name = f"{found_keywords[0]}{found_keywords[1]}Agent"
                    agent_name = f"{found_keywords[0]} {found_keywords[1]} Agent"
                else:
                    agent_class_name = f"{found_keywords[0]}Agent"
                    agent_name = f"{found_keywords[0]} Agent"
            else:
                # Try to extract from domain and intent
                if result.domain:
                    # Capitalize domain properly
                    domain_name = result.domain.replace('_', ' ').title().replace(' ', '')
                    agent_class_name = f"{domain_name}{result.intent.capitalize()}Agent"
                    agent_name = f"{result.domain.replace('_', ' ').title()} {result.intent.capitalize()} Agent"
                else:
                    # Last resort: use intent with proper naming
                    agent_class_name = f"{result.intent.capitalize()}Agent"
                    agent_name = f"{result.intent.capitalize()} Agent"
        else:
            # English query handling
            # Try to extract meaningful agent name from query
            name_patterns = [
                r'(?:create|build|make|develop)\s+(?:a|an)?\s*([a-zA-Z]+(?:\s+[a-zA-Z]+)?)\s*(?:agent|bot|system|service)?',
                r'([a-zA-Z]+(?:\s+[a-zA-Z]+)?)\s+(?:agent|bot|system|service)',
                r'agent\s+(?:for|that|to)\s+([a-zA-Z]+(?:\s+[a-zA-Z]+)?)',
                r'([a-zA-Z]+(?:\s+[a-zA-Z]+)?)\s+(?:monitoring|analyzing|managing|processing|tracking)'
            ]
            
            for pattern in name_patterns:
                match = re.search(pattern, query, re.IGNORECASE)
                if match:
                    extracted_name = match.group(1).strip()
                    # Clean and capitalize properly
                    name_parts = extracted_name.split()
                    agent_class_name = ''.join(word.capitalize() for word in name_parts) + 'Agent'
                    agent_name = ' '.join(word.capitalize() for word in name_parts) + ' Agent'
                    break
            
            if not agent_class_name:
                # Use domain and intent as fallback
                if result.domain:
                    domain_name = result.domain.replace('_', ' ').title().replace(' ', '')
                    agent_class_name = f"{domain_name}{result.intent.capitalize()}Agent"
                    agent_name = f"{result.domain.replace('_', ' ').title()} {result.intent.capitalize()} Agent"
                else:
                    agent_class_name = f"{result.intent.capitalize()}Agent"
                    agent_name = f"{result.intent.capitalize()} Agent"
        
        # Final cleanup of agent_class_name to ensure valid Python identifier
        # Remove any remaining non-alphanumeric characters
        agent_class_name = re.sub(r'[^a-zA-Z0-9]', '', agent_class_name)
        
        # Ensure it starts with a letter
        if agent_class_name and not agent_class_name[0].isalpha():
            agent_class_name = 'Agent' + agent_class_name
        
        # Ensure it ends with 'Agent' if it doesn't already
        if not agent_class_name.endswith('Agent'):
            agent_class_name = agent_class_name + 'Agent'
        
        # If still empty or invalid, use a sensible default
        if not agent_class_name or agent_class_name == 'Agent':
            agent_class_name = 'CustomAgent'
            agent_name = 'Custom Agent'
        
        result.agent_metadata = {
            'agent_class_name': agent_class_name,
            'agent_name': agent_name,
            'agent_description': f"Agent for {result.intent} in {result.domain or 'general'} domain",
            'agent_type': result.domain.upper() if result.domain else 'CUSTOM',
            'version': '1.0.0',
            'author': 'FORGE AI',
            'capabilities': result.required_capabilities,
            'complexity': result.complexity.value
        }
    
    def _calculate_confidence(self, result: QueryAnalysisResult) -> float:
        """Calculate confidence score for the analysis"""
        confidence = 0.5  # Base confidence
        
        # Increase confidence based on identified features
        if result.domain:
            confidence += 0.15
        if result.required_capabilities:
            confidence += 0.1 * min(len(result.required_capabilities) / 3, 1)
        if result.entities:
            confidence += 0.1
        if result.test_samples:
            confidence += 0.1
        if result.agent_metadata:
            confidence += 0.05
        
        return min(confidence, 1.0)
    
    def _generate_suggestions(self, result: QueryAnalysisResult) -> List[str]:
        """Generate suggestions for improving the query"""
        suggestions = []
        
        if not result.domain:
            suggestions.append("Consider specifying the domain (e.g., finance, healthcare, ecommerce)")
        
        if len(result.required_capabilities) < 2:
            suggestions.append("Add more specific requirements or capabilities")
        
        if not result.entities:
            suggestions.append("Include specific data examples or parameters")
        
        if result.confidence < 0.5:
            suggestions.append("The query is too vague. Please provide more details")
        
        return suggestions


# Singleton instance for easy import
query_analyzer = UnifiedQueryAnalyzer()


async def analyze_query(query: str) -> QueryAnalysisResult:
    """
    Convenience function for analyzing queries
    
    Args:
        query: User query string
        
    Returns:
        Complete query analysis result
    """
    return await query_analyzer.analyze(query)