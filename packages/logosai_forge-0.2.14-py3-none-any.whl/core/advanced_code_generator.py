"""
Advanced Code Generator - Multi-Stage Reasoning Pipeline
Uses deep analysis and iterative refinement for high-quality agent generation
"""

import logging
from typing import Optional, Any, Callable, Dict, List
from datetime import datetime
from pathlib import Path
import json
import sys
import asyncio

# Add prototype/backend to path for imports
sys.path.append(str(Path(__file__).parent.parent / "prototype" / "backend"))

from .query_analyzer import QueryAnalysis
from .context_manager import Context
from .llm_orchestrator import LLMOrchestrator, TaskType
from .generation_artifacts import GenerationArtifacts

# Use loguru for consistent logging
from loguru import logger


class AdvancedCodeGenerator:
    """Advanced code generator using multi-stage reasoning for complete agent generation"""
    
    def __init__(self, llm_orchestrator: LLMOrchestrator):
        """Initialize advanced code generator"""
        self.llm = llm_orchestrator
        self.template_path = Path(__file__).parent.parent / "templates" / "logosai_agent_template.py.template"
        
        # Load template
        try:
            with open(self.template_path, 'r') as f:
                self.template = f.read()
        except Exception as e:
            logger.error(f"Could not load template: {e}")
            self.template = ""
    
    async def generate_complete_agent(self, analysis: QueryAnalysis, context: Context, 
                                    stream_callback: Optional[Callable] = None) -> Any:
        """Generate complete agent using multi-stage reasoning pipeline"""
        
        start_time = datetime.now()
        
        try:
            # Stage 1: Deep requirement analysis
            if stream_callback:
                await stream_callback(
                    "analyzing",
                    "🔍 깊은 요구사항 분석을 수행하고 있습니다...",
                    {"stage": 1, "phase": "requirement_analysis"}
                )
            deep_analysis = await self._deep_requirement_analysis(analysis)
            logger.info(f"Deep analysis completed: {deep_analysis.get('business_goal', 'N/A')}")
            
            # Stage 2: Architecture design
            if stream_callback:
                await stream_callback(
                    "designing",
                    "🏗️ 에이전트 아키텍처를 설계하고 있습니다...",
                    {"stage": 2, "phase": "architecture_design"}
                )
            architecture = await self._design_agent_architecture(deep_analysis, analysis)
            logger.info(f"Architecture design completed: {architecture.get('pattern', 'N/A')}")
            
            # Stage 3: Implementation planning
            if stream_callback:
                await stream_callback(
                    "planning",
                    "📋 구현 계획을 수립하고 있습니다...",
                    {"stage": 3, "phase": "implementation_planning"}
                )
            implementation_plan = await self._create_implementation_plan(architecture, deep_analysis)
            logger.info(f"Implementation plan ready: {len(implementation_plan.get('steps', []))} steps")
            
            # Stage 4: Generate complete code with full context
            if stream_callback:
                await stream_callback(
                    "generating",
                    "🚀 완전한 에이전트 코드를 생성하고 있습니다...",
                    {"stage": 4, "phase": "code_generation"}
                )
            complete_code = await self._generate_with_full_context(
                analysis=analysis,
                deep_analysis=deep_analysis,
                architecture=architecture,
                plan=implementation_plan
            )
            logger.info(f"Code generation completed: {len(complete_code)} chars")
            
            # Stage 5: Validation and refinement
            if stream_callback:
                await stream_callback(
                    "validating",
                    "✅ 코드를 검증하고 개선하고 있습니다...",
                    {"stage": 5, "phase": "validation_refinement"}
                )
            final_code = await self._validate_and_refine(complete_code, analysis)
            
            # Create artifacts
            artifacts = GenerationArtifacts(
                generation_id=f"adv_gen_{datetime.now().timestamp()}",
                timestamp=start_time,
                original_query=analysis.query
            )
            
            artifacts.query_analysis = {
                "intent": analysis.intent,
                "domain": analysis.domain,
                "complexity": analysis.complexity.value,
                "capabilities": analysis.required_capabilities,
                "deep_analysis": deep_analysis,
                "architecture": architecture,
                "implementation_plan": implementation_plan
            }
            
            artifacts.generated_code_raw = complete_code
            artifacts.optimized_code = final_code
            artifacts.total_generation_time_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            artifacts.llm_calls_count = 5  # 5 stages
            
            if stream_callback:
                await stream_callback(
                    "complete",
                    "✨ 고품질 에이전트가 성공적으로 생성되었습니다!",
                    {
                        "stage": "complete",
                        "code_length": len(final_code),
                        "generation_time": (datetime.now() - start_time).total_seconds()
                    }
                )
            
            # Return GeneratedCode object
            class GeneratedCode:
                def __init__(self, code, artifacts):
                    self.code = code
                    self.artifacts = artifacts
                    self.template_used = "advanced_multi_stage"
            
            return GeneratedCode(code=final_code, artifacts=artifacts)
            
        except Exception as e:
            logger.error(f"Advanced generation failed: {e}")
            raise
    
    async def _deep_requirement_analysis(self, analysis: QueryAnalysis) -> Dict[str, Any]:
        """Perform deep requirement analysis"""
        
        prompt = f"""사용자의 에이전트 생성 요청을 깊이 분석하세요.

요청: {analysis.query}
도메인: {analysis.domain}
필요 기능: {', '.join(analysis.required_capabilities)}

다음 측면에서 상세히 분석하고 JSON으로 응답하세요:
{{
    "business_goal": "이 에이전트가 해결하려는 비즈니스 목표",
    "data_types": ["다룰 데이터 타입들"],
    "processing_steps": ["필요한 처리 단계들"],
    "input_format": {{
        "type": "입력 데이터 형식",
        "examples": ["입력 예시들"]
    }},
    "output_format": {{
        "type": "출력 데이터 형식", 
        "structure": "출력 구조 설명"
    }},
    "error_scenarios": ["예상되는 에러 시나리오들"],
    "performance_requirements": {{
        "speed": "처리 속도 요구사항",
        "scalability": "확장성 요구사항"
    }},
    "business_rules": ["핵심 비즈니스 규칙들"],
    "success_metrics": ["성공 측정 지표들"]
}}

JSON만 반환하세요:"""
        
        try:
            result = await self.llm.generate(
                prompt=prompt,
                task_type=TaskType.ANALYSIS,
                max_tokens=3000,
                temperature=0.3
            )
            
            # Extract JSON from response
            import re
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            
            # Fallback
            return {
                "business_goal": "Process user requests efficiently",
                "data_types": ["structured", "unstructured"],
                "processing_steps": ["validate", "process", "return"],
                "input_format": {"type": "any", "examples": []},
                "output_format": {"type": "json", "structure": "flexible"},
                "error_scenarios": ["invalid_input", "processing_error"],
                "performance_requirements": {"speed": "fast", "scalability": "medium"},
                "business_rules": [],
                "success_metrics": ["accuracy", "speed"]
            }
            
        except Exception as e:
            logger.error(f"Deep analysis failed: {e}")
            return {
                "business_goal": "Process requests",
                "data_types": ["any"],
                "processing_steps": ["process"],
                "input_format": {"type": "any", "examples": []},
                "output_format": {"type": "json", "structure": "flexible"},
                "error_scenarios": ["error"],
                "performance_requirements": {"speed": "normal", "scalability": "normal"},
                "business_rules": [],
                "success_metrics": ["completion"]
            }
    
    async def _design_agent_architecture(self, deep_analysis: Dict[str, Any], 
                                       analysis: QueryAnalysis) -> Dict[str, Any]:
        """Design agent architecture based on deep analysis"""
        
        prompt = f"""에이전트 아키텍처를 설계하세요.

비즈니스 목표: {deep_analysis['business_goal']}
데이터 타입: {', '.join(deep_analysis['data_types'])}
처리 단계: {', '.join(deep_analysis['processing_steps'])}
도메인: {analysis.domain}

다음 아키텍처 요소를 JSON으로 설계하세요:
{{
    "pattern": "아키텍처 패턴 (예: pipeline, event-driven, layered)",
    "components": [
        {{
            "name": "컴포넌트명",
            "responsibility": "책임",
            "methods": ["메서드1", "메서드2"]
        }}
    ],
    "data_flow": [
        {{
            "from": "시작점",
            "to": "도착점",
            "data": "전달 데이터"
        }}
    ],
    "external_dependencies": ["필요한 외부 라이브러리들"],
    "internal_modules": ["내부 모듈 구조"],
    "error_handling_strategy": "에러 처리 전략",
    "logging_strategy": "로깅 전략",
    "caching_strategy": "캐싱 전략",
    "scalability_considerations": ["확장성 고려사항들"]
}}

JSON만 반환하세요:"""
        
        try:
            result = await self.llm.generate(
                prompt=prompt,
                task_type=TaskType.ANALYSIS,
                max_tokens=3000,
                temperature=0.4
            )
            
            # Extract JSON
            import re
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            
            # Fallback architecture
            return {
                "pattern": "pipeline",
                "components": [
                    {
                        "name": "DataValidator",
                        "responsibility": "입력 데이터 검증",
                        "methods": ["validate_input", "sanitize_data"]
                    },
                    {
                        "name": "BusinessLogicProcessor",
                        "responsibility": "핵심 비즈니스 로직 처리",
                        "methods": ["process_data", "apply_rules"]
                    },
                    {
                        "name": "ResultFormatter",
                        "responsibility": "결과 포맷팅",
                        "methods": ["format_output", "add_metadata"]
                    }
                ],
                "data_flow": [
                    {"from": "input", "to": "DataValidator", "data": "raw_input"},
                    {"from": "DataValidator", "to": "BusinessLogicProcessor", "data": "validated_data"},
                    {"from": "BusinessLogicProcessor", "to": "ResultFormatter", "data": "processed_result"}
                ],
                "external_dependencies": ["pandas", "numpy"],
                "internal_modules": ["validators", "processors", "formatters"],
                "error_handling_strategy": "try-catch with detailed logging",
                "logging_strategy": "structured logging with context",
                "caching_strategy": "LRU cache for repeated queries",
                "scalability_considerations": ["async processing", "batch operations"]
            }
            
        except Exception as e:
            logger.error(f"Architecture design failed: {e}")
            return {
                "pattern": "simple",
                "components": [{"name": "MainProcessor", "responsibility": "처리", "methods": ["process"]}],
                "data_flow": [{"from": "input", "to": "output", "data": "data"}],
                "external_dependencies": [],
                "internal_modules": [],
                "error_handling_strategy": "basic",
                "logging_strategy": "basic",
                "caching_strategy": "none",
                "scalability_considerations": []
            }
    
    async def _create_implementation_plan(self, architecture: Dict[str, Any], 
                                        deep_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Create detailed implementation plan"""
        
        prompt = f"""구현 계획을 수립하세요.

아키텍처 패턴: {architecture['pattern']}
컴포넌트: {len(architecture['components'])}개
비즈니스 규칙: {len(deep_analysis['business_rules'])}개

다음 구조로 구현 계획을 JSON으로 작성하세요:
{{
    "steps": [
        {{
            "order": 1,
            "task": "구현 작업",
            "details": "상세 설명",
            "code_snippet": "예시 코드"
        }}
    ],
    "test_scenarios": [
        {{
            "name": "시나리오명",
            "input": "테스트 입력",
            "expected_output": "예상 출력",
            "test_code": "테스트 코드"
        }}
    ],
    "validation_checklist": [
        "검증 항목 1",
        "검증 항목 2"
    ],
    "documentation_plan": {{
        "docstrings": "문서화 전략",
        "examples": "예제 전략",
        "readme": "README 내용"
    }}
}}

JSON만 반환하세요:"""
        
        try:
            result = await self.llm.generate(
                prompt=prompt,
                task_type=TaskType.ANALYSIS,
                max_tokens=4000,
                temperature=0.3
            )
            
            # Extract JSON
            import re
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            
            # Fallback plan
            return {
                "steps": [
                    {
                        "order": 1,
                        "task": "기본 구조 구현",
                        "details": "LogosAI 에이전트 클래스 생성",
                        "code_snippet": "class Agent(LogosAIAgent):"
                    },
                    {
                        "order": 2,
                        "task": "비즈니스 로직 구현",
                        "details": "핵심 처리 로직 구현",
                        "code_snippet": "async def process(self, query):"
                    }
                ],
                "test_scenarios": [
                    {
                        "name": "기본 테스트",
                        "input": "test input",
                        "expected_output": "success",
                        "test_code": "assert result['status'] == 'success'"
                    }
                ],
                "validation_checklist": [
                    "코드 구문 검증",
                    "비즈니스 로직 완성도",
                    "에러 처리 검증"
                ],
                "documentation_plan": {
                    "docstrings": "모든 메서드에 docstring",
                    "examples": "사용 예제 포함",
                    "readme": "설치 및 사용법"
                }
            }
            
        except Exception as e:
            logger.error(f"Implementation planning failed: {e}")
            return {
                "steps": [{"order": 1, "task": "implement", "details": "implement agent", "code_snippet": ""}],
                "test_scenarios": [{"name": "test", "input": "input", "expected_output": "output", "test_code": ""}],
                "validation_checklist": ["validate"],
                "documentation_plan": {"docstrings": "add", "examples": "add", "readme": "add"}
            }
    
    async def _generate_with_full_context(self, analysis: QueryAnalysis, deep_analysis: Dict[str, Any],
                                        architecture: Dict[str, Any], plan: Dict[str, Any]) -> str:
        """Generate complete code with full context awareness"""
        
        # Create a comprehensive context
        comprehensive_prompt = f"""LogosAI 에이전트를 생성합니다. 다음 분석과 설계를 기반으로 완전한 코드를 생성하세요.

=== 사용자 요청 ===
{analysis.query}

=== 깊은 요구사항 분석 ===
비즈니스 목표: {deep_analysis['business_goal']}
데이터 타입: {', '.join(deep_analysis['data_types'])}
처리 단계: {', '.join(deep_analysis['processing_steps'])}
비즈니스 규칙:
{chr(10).join([f"- {rule}" for rule in deep_analysis['business_rules']])}

=== 아키텍처 설계 ===
패턴: {architecture['pattern']}
컴포넌트:
{chr(10).join([f"- {comp['name']}: {comp['responsibility']}" for comp in architecture['components']])}

=== 구현 계획 ===
{chr(10).join([f"{step['order']}. {step['task']}: {step['details']}" for step in plan['steps'][:3]])}

=== LogosAI 프레임워크 템플릿 구조 ===
다음 템플릿을 기반으로 하되, 위 분석과 설계를 반영하여 완성하세요:

```python
{self.template}
```

=== 생성 규칙 ===
1. 템플릿의 모든 {{변수}}를 실제 값으로 대체
2. 깊은 분석 결과를 반영한 비즈니스 로직 구현
3. 아키텍처 설계에 따른 컴포넌트 구조화
4. 구현 계획의 모든 단계 반영
5. 완전한 에러 처리와 로깅
6. 실제 작동하는 샘플 데이터와 테스트 코드
7. 도메인 특화 최적화

완전하고 실행 가능한 Python 코드를 생성하세요:"""
        
        try:
            result = await self.llm.generate(
                prompt=comprehensive_prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=12000,  # 충분한 토큰
                temperature=0.3    # 일관성 있는 생성
            )
            
            # Extract code
            code = self._extract_code_from_response(result)
            
            # Ensure all template variables are replaced
            code = self._ensure_template_variables_replaced(code, analysis, deep_analysis)
            
            return code
            
        except Exception as e:
            logger.error(f"Code generation with full context failed: {e}")
            raise
    
    async def _validate_and_refine(self, code: str, analysis: QueryAnalysis) -> str:
        """Validate and iteratively refine the generated code"""
        
        max_iterations = 3
        current_code = code
        
        for iteration in range(max_iterations):
            # Validate code
            validation_prompt = f"""다음 LogosAI 에이전트 코드를 검증하세요.

코드:
```python
{current_code}
```

검증 항목:
1. LogosAI 프레임워크 규칙 준수 여부
2. 비즈니스 로직 완성도
3. 에러 처리 적절성
4. 코드 품질과 가독성
5. 테스트 가능성
6. 성능 최적화 여부

발견된 문제를 JSON으로 반환하세요:
{{
    "issues": [
        {{
            "severity": "high|medium|low",
            "category": "framework|logic|error_handling|quality|test|performance",
            "description": "문제 설명",
            "suggestion": "개선 제안"
        }}
    ],
    "overall_quality": "1-10 점수",
    "ready_for_production": true|false
}}

JSON만 반환하세요:"""
            
            try:
                validation_result = await self.llm.generate(
                    prompt=validation_prompt,
                    task_type=TaskType.ANALYSIS,
                    max_tokens=2000,
                    temperature=0.2
                )
                
                # Parse validation result
                import re
                json_match = re.search(r'\{.*\}', validation_result, re.DOTALL)
                if json_match:
                    validation = json.loads(json_match.group())
                    
                    # Check if ready
                    if validation.get('ready_for_production', False) or validation.get('overall_quality', 0) >= 8:
                        logger.info(f"Code validated successfully after {iteration + 1} iterations")
                        break
                    
                    # If not ready and has issues, refine
                    if validation.get('issues', []):
                        high_priority_issues = [
                            issue for issue in validation['issues'] 
                            if issue.get('severity') == 'high'
                        ]
                        
                        if not high_priority_issues and iteration > 0:
                            # No high priority issues after first iteration
                            break
                        
                        # Refine code
                        current_code = await self._refine_code(current_code, validation['issues'])
                
            except Exception as e:
                logger.warning(f"Validation iteration {iteration + 1} failed: {e}")
                break
        
        return current_code
    
    async def _refine_code(self, code: str, issues: List[Dict[str, Any]]) -> str:
        """Refine code based on identified issues"""
        
        refinement_prompt = f"""다음 코드의 문제점을 수정하세요.

현재 코드:
```python
{code}
```

발견된 문제들:
{chr(10).join([f"- [{issue['severity']}] {issue['category']}: {issue['description']}" for issue in issues[:5]])}

개선 제안:
{chr(10).join([f"- {issue['suggestion']}" for issue in issues[:5] if 'suggestion' in issue])}

수정 규칙:
1. 모든 high severity 문제는 반드시 수정
2. LogosAI 프레임워크 규칙 준수
3. 기존 기능 유지하면서 개선
4. 코드 구조와 가독성 향상

수정된 완전한 코드를 반환하세요:"""
        
        try:
            refined_code = await self.llm.generate(
                prompt=refinement_prompt,
                task_type=TaskType.CODE_GENERATION,
                max_tokens=12000,
                temperature=0.2
            )
            
            return self._extract_code_from_response(refined_code)
            
        except Exception as e:
            logger.error(f"Code refinement failed: {e}")
            return code  # Return original if refinement fails
    
    def _extract_code_from_response(self, response: str) -> str:
        """Extract Python code from LLM response"""
        
        # Try to find code block
        import re
        
        # Look for ```python blocks first
        python_blocks = re.findall(r'```python\n(.*?)```', response, re.DOTALL)
        if python_blocks:
            return python_blocks[0].strip()
        
        # Look for any ``` blocks
        code_blocks = re.findall(r'```\n(.*?)```', response, re.DOTALL)
        if code_blocks:
            return code_blocks[0].strip()
        
        # If no code blocks, try to extract from import statements
        lines = response.split('\n')
        code_lines = []
        in_code = False
        
        for line in lines:
            if line.strip().startswith('import ') or line.strip().startswith('from '):
                in_code = True
            
            if in_code:
                code_lines.append(line)
        
        if code_lines:
            return '\n'.join(code_lines)
        
        # Last resort - return everything
        return response
    
    def _ensure_template_variables_replaced(self, code: str, analysis: QueryAnalysis, 
                                           deep_analysis: Dict[str, Any]) -> str:
        """Ensure all template variables are properly replaced"""
        
        # Common replacements based on analysis
        replacements = {
            '{agent_class_name}': self._generate_class_name_from_analysis(analysis),
            '{agent_name}': self._generate_agent_name_from_analysis(analysis),
            '{agent_description}': analysis.query,
            '{custom_config}': '"timeout": 60, "retry_attempts": 3, "cache_enabled": true',
            '{custom_init}': '# Initialization based on deep analysis',
            '{custom_async_init}': '# Async initialization if needed',
            '{custom_cleanup}': '# Cleanup resources',
            '{data_sources}': str(deep_analysis.get('data_types', [])),
            '{insights_generation_prompt}': '데이터를 분석하여 비즈니스 인사이트를 도출하세요.',
            '{query_extraction_prompt}': '사용자 요청에서 핵심 정보를 추출하세요.',
            '{response_generation_prompt}': '분석 결과를 사용자 친화적으로 설명하세요.'
        }
        
        # Replace all variables
        for var, value in replacements.items():
            if var in code:
                code = code.replace(var, value)
        
        # Check for any remaining variables
        import re
        remaining = re.findall(r'\{[^{}]+\}', code)
        if remaining:
            # Filter out f-string patterns
            remaining = [var for var in remaining if not any(c in var for c in ':.[]()')]
            if remaining:
                logger.warning(f"Remaining template variables: {remaining}")
        
        return code
    
    def _generate_class_name_from_analysis(self, analysis: QueryAnalysis) -> str:
        """Generate appropriate class name from analysis"""
        domain = (analysis.domain or 'general').lower()
        
        if 'customer' in domain:
            return 'CustomerAnalysisAgent'
        elif 'data' in domain:
            return 'DataAnalysisAgent'
        elif 'api' in domain:
            return 'APIIntegrationAgent'
        elif 'web' in domain:
            return 'WebScrapingAgent'
        else:
            return 'CustomBusinessAgent'
    
    def _generate_agent_name_from_analysis(self, analysis: QueryAnalysis) -> str:
        """Generate human-readable agent name from analysis"""
        domain = (analysis.domain or 'General').title()
        return f"{domain} Assistant Agent"