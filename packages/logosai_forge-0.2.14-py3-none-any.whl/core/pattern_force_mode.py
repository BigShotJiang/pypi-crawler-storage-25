"""
⚡ Pattern Force Mode
환경 변수를 통해 패턴 시스템을 강제로 활성화하는 모듈

환경 변수:
- FORGE_FORCE_PATTERNS=true: 모든 요청에 패턴 시스템 강제 사용
- FORGE_PATTERN_DEBUG=true: 상세 디버깅 로그 활성화
- FORGE_BYPASS_LEGACY=true: 레거시 시스템 완전 우회
- FORGE_PATTERN_MIN_KEYWORDS=N: 최소 키워드 매칭 수 설정
"""

import os
from typing import Dict, Any, Optional
from loguru import logger


class PatternForceMode:
    """패턴 강제 모드 관리자"""
    
    def __init__(self):
        self.config = self._load_config()
        self._log_current_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """환경 변수에서 설정 로드"""
        
        config = {
            # 강제 모드들
            'force_patterns': os.getenv('FORGE_FORCE_PATTERNS', 'false').lower() == 'true',
            'pattern_debug': os.getenv('FORGE_PATTERN_DEBUG', 'false').lower() == 'true',
            'bypass_legacy': os.getenv('FORGE_BYPASS_LEGACY', 'false').lower() == 'true',
            
            # 세부 설정
            'min_keywords': int(os.getenv('FORGE_PATTERN_MIN_KEYWORDS', '1')),
            'enable_patterns': os.getenv('FORGE_ENABLE_PATTERNS', 'true').lower() == 'true',
            
            # 고급 설정
            'force_confidence': float(os.getenv('FORGE_FORCE_CONFIDENCE', '0.8')),
            'override_template_check': os.getenv('FORGE_OVERRIDE_TEMPLATE_CHECK', 'false').lower() == 'true',
            
            # 테스트 모드
            'test_mode': os.getenv('FORGE_TEST_MODE', 'false').lower() == 'true',
            'dry_run': os.getenv('FORGE_DRY_RUN', 'false').lower() == 'true'
        }
        
        return config
    
    def _log_current_config(self):
        """현재 설정 로깅"""
        if self.config['pattern_debug']:
            logger.info("⚡ Pattern Force Mode Configuration:")
            for key, value in self.config.items():
                logger.info(f"   {key}: {value}")
    
    def should_force_patterns(self, template_id: str = None, user_request: str = None) -> Dict[str, Any]:
        """패턴 시스템 강제 사용 여부 결정"""
        
        result = {
            'force': False,
            'reason': '',
            'override_conditions': [],
            'config_applied': {}
        }
        
        # 1. 기본 활성화 체크
        if not self.config['enable_patterns']:
            result.update({
                'force': False,
                'reason': 'FORGE_ENABLE_PATTERNS=false'
            })
            return result
        
        # 2. 강제 모드 체크
        if self.config['force_patterns']:
            result.update({
                'force': True,
                'reason': 'FORGE_FORCE_PATTERNS=true',
                'override_conditions': ['force_patterns']
            })
        
        # 3. 레거시 우회 모드
        if self.config['bypass_legacy']:
            result['force'] = True
            result['reason'] += ' + FORGE_BYPASS_LEGACY=true'
            result['override_conditions'].append('bypass_legacy')
        
        # 4. 테스트 모드
        if self.config['test_mode']:
            result['force'] = True
            result['reason'] += ' + FORGE_TEST_MODE=true'
            result['override_conditions'].append('test_mode')
        
        # 5. 키워드 임계값 조정
        if user_request:
            keyword_count = self._count_keywords(user_request)
            if keyword_count >= self.config['min_keywords']:
                result['force'] = True
                result['reason'] += f' + Keywords matched ({keyword_count}/{self.config["min_keywords"]})'
                result['override_conditions'].append('keyword_match')
        
        # 6. 템플릿 체크 오버라이드
        if self.config['override_template_check']:
            result['force'] = True
            result['reason'] += ' + Template check overridden'
            result['override_conditions'].append('template_override')
        
        # 적용된 설정 기록
        result['config_applied'] = {
            key: value for key, value in self.config.items() 
            if key in ['force_patterns', 'bypass_legacy', 'test_mode', 'min_keywords']
        }
        
        if self.config['pattern_debug']:
            logger.info(f"⚡ Force decision: {'FORCE PATTERNS' if result['force'] else 'ALLOW NORMAL'}")
            logger.info(f"   Reason: {result['reason']}")
            logger.info(f"   Overrides: {result['override_conditions']}")
        
        return result
    
    def _count_keywords(self, user_request: str) -> int:
        """키워드 개수 계산"""
        pattern_keywords = [
            'csv', 'excel', '데이터', '분석', 'analysis', '차트', 
            '대시보드', 'dashboard', '고객', 'customer', '위험', 'risk',
            '시각화', 'visualization', '예측', 'prediction', '품질', 'quality',
            'kpi', '모니터링', 'monitoring', '세그멘테이션', 'segmentation',
            'pandas', 'matplotlib', 'plotly', '머신러닝', 'machine learning'
        ]
        
        user_lower = user_request.lower()
        return sum(1 for kw in pattern_keywords if kw in user_lower)
    
    def get_enhanced_pattern_settings(self) -> Dict[str, Any]:
        """패턴 시스템용 향상된 설정 반환"""
        
        settings = {
            'force_mode': self.config['force_patterns'],
            'debug_mode': self.config['pattern_debug'],
            'min_confidence': self.config['force_confidence'],
            'bypass_legacy': self.config['bypass_legacy'],
            'keyword_threshold': self.config['min_keywords'],
            'test_mode': self.config['test_mode'],
            'dry_run': self.config['dry_run']
        }
        
        return settings
    
    def apply_force_mode_to_generator(self, template_generator):
        """템플릿 생성기에 강제 모드 적용"""
        
        if not hasattr(template_generator, '_original_should_use_pattern_integration'):
            # 원래 메서드 백업
            template_generator._original_should_use_pattern_integration = (
                template_generator._should_use_pattern_integration 
                if hasattr(template_generator, '_should_use_pattern_integration') 
                else None
            )
        
        # 강제 모드 래퍼 메서드
        def force_mode_pattern_decision(template_id: str, user_request: str) -> bool:
            force_result = self.should_force_patterns(template_id, user_request)
            
            if force_result['force']:
                if self.config['pattern_debug']:
                    logger.info(f"⚡ FORCE MODE: Using patterns - {force_result['reason']}")
                return True
            
            # 원래 로직 실행 (있는 경우)
            if template_generator._original_should_use_pattern_integration:
                original_result = template_generator._original_should_use_pattern_integration(
                    template_id, user_request
                )
                if self.config['pattern_debug']:
                    logger.info(f"⚡ NORMAL MODE: Original decision = {original_result}")
                return original_result
            
            # 기본 키워드 기반 결정
            keyword_count = self._count_keywords(user_request)
            result = keyword_count >= self.config['min_keywords']
            
            if self.config['pattern_debug']:
                logger.info(f"⚡ FALLBACK MODE: Keyword-based decision = {result} ({keyword_count} keywords)")
            
            return result
        
        # 메서드 교체
        if hasattr(template_generator, '_should_use_pattern_integration'):
            template_generator._should_use_pattern_integration = force_mode_pattern_decision
        else:
            # 메서드가 없으면 새로 추가
            setattr(template_generator, '_should_use_pattern_integration', force_mode_pattern_decision)
        
        logger.info("⚡ Force mode applied to template generator")
    
    def create_test_environment_script(self) -> str:
        """테스트 환경 설정 스크립트 생성"""
        
        script = f"""#!/bin/bash
# Pattern Force Mode Test Environment Setup

echo "⚡ Setting up Pattern Force Mode environment..."

# 강제 모드 활성화
export FORGE_FORCE_PATTERNS=true
export FORGE_PATTERN_DEBUG=true
export FORGE_BYPASS_LEGACY=true

# 세부 설정
export FORGE_PATTERN_MIN_KEYWORDS=1
export FORGE_FORCE_CONFIDENCE=0.9
export FORGE_OVERRIDE_TEMPLATE_CHECK=true

# 테스트 모드
export FORGE_TEST_MODE=true

echo "✅ Environment configured:"
echo "   FORGE_FORCE_PATTERNS=$FORGE_FORCE_PATTERNS"
echo "   FORGE_PATTERN_DEBUG=$FORGE_PATTERN_DEBUG"  
echo "   FORGE_BYPASS_LEGACY=$FORGE_BYPASS_LEGACY"
echo "   FORGE_PATTERN_MIN_KEYWORDS=$FORGE_PATTERN_MIN_KEYWORDS"

echo ""
echo "🚀 Run your tests now!"
echo "   python server_integration_test.py"
"""
        return script
    
    def reset_to_normal_mode(self):
        """일반 모드로 복원"""
        
        # 환경 변수 제거
        env_vars_to_clear = [
            'FORGE_FORCE_PATTERNS',
            'FORGE_PATTERN_DEBUG', 
            'FORGE_BYPASS_LEGACY',
            'FORGE_PATTERN_MIN_KEYWORDS',
            'FORGE_TEST_MODE'
        ]
        
        for var in env_vars_to_clear:
            if var in os.environ:
                del os.environ[var]
        
        # 설정 재로드
        self.config = self._load_config()
        logger.info("⚡ Pattern Force Mode reset to normal")


# 전역 강제 모드 인스턴스
_global_force_mode = None

def get_pattern_force_mode() -> PatternForceMode:
    """전역 패턴 강제 모드 인스턴스 반환"""
    global _global_force_mode
    
    if _global_force_mode is None:
        _global_force_mode = PatternForceMode()
    
    return _global_force_mode


# 편의 함수들
def should_force_patterns(template_id: str = None, user_request: str = None) -> bool:
    """패턴 강제 사용 여부 확인 편의 함수"""
    return get_pattern_force_mode().should_force_patterns(template_id, user_request)['force']

def is_debug_mode() -> bool:
    """디버그 모드 여부 확인"""
    return get_pattern_force_mode().config['pattern_debug']

def apply_force_mode(template_generator):
    """템플릿 생성기에 강제 모드 적용"""
    get_pattern_force_mode().apply_force_mode_to_generator(template_generator)


if __name__ == "__main__":
    # 테스트
    print("⚡ Pattern Force Mode Test")
    print("=" * 40)
    
    # 일반 모드 테스트
    force_mode = PatternForceMode()
    
    test_cases = [
        ("data_analysis", "CSV 파일을 분석해서 차트를 만들어줘"),
        ("basic", "안녕하세요"),
        ("comprehensive", "고객 데이터 세그멘테이션과 마케팅 전략")
    ]
    
    print("🧪 Normal mode test:")
    for template_id, request in test_cases:
        result = force_mode.should_force_patterns(template_id, request)
        print(f"   {template_id}: {'FORCE' if result['force'] else 'NORMAL'} - {result['reason']}")
    
    print("\n🧪 Setting force mode...")
    os.environ['FORGE_FORCE_PATTERNS'] = 'true'
    os.environ['FORGE_PATTERN_DEBUG'] = 'true'
    
    force_mode_test = PatternForceMode()
    
    print("🧪 Force mode test:")
    for template_id, request in test_cases:
        result = force_mode_test.should_force_patterns(template_id, request)
        print(f"   {template_id}: {'FORCE' if result['force'] else 'NORMAL'} - {result['reason']}")
    
    # 테스트 스크립트 생성
    script = force_mode_test.create_test_environment_script()
    script_path = "setup_force_mode.sh"
    with open(script_path, 'w') as f:
        f.write(script)
    print(f"\n✅ Test script generated: {script_path}")
