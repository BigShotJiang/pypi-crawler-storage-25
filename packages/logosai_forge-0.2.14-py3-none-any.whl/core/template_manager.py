"""
Dual Template Manager for FORGE AI

Manages templates from both LogosAI (read-only) and FORGE (writable).
All template selection decisions are made by LLM.
"""

import os
import json
import shutil
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import logging

from .llm_orchestrator import LLMOrchestrator, TaskType
from .prompts import prompt_registry

# Import LogosAI template system
try:
    from logosai.templates import TemplateEngine
except ImportError:
    # Fallback for testing
    class TemplateEngine:
        def list_templates(self, category=None):
            return []
        def get_metadata(self, template):
            return None
        def render(self, template, context):
            return f"# Rendered from {template}"

logger = logging.getLogger(__name__)


@dataclass 
class TemplateMetadata:
    """Enhanced template metadata"""
    name: str
    source: str  # 'logosai' or 'forge'
    path: str
    description: str
    category: str
    tags: List[str]
    parameters: Dict[str, Any]
    version: str = "1.0.0"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    usage_count: int = 0
    performance_score: float = 0.0
    parent_template: Optional[str] = None
    evolution_history: List[Dict[str, Any]] = field(default_factory=list)
    evolution_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'source': self.source,
            'path': self.path,
            'description': self.description,
            'category': self.category,
            'tags': self.tags,
            'parameters': self.parameters,
            'version': self.version,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'usage_count': self.usage_count,
            'performance_score': self.performance_score,
            'parent_template': self.parent_template,
            'evolution_history': self.evolution_history,
            'evolution_count': self.evolution_count
        }


class DualTemplateManager:
    """Manages templates from both LogosAI and FORGE sources"""
    
    def __init__(self,
                 forge_template_dir: Optional[str] = None,
                 llm_orchestrator: Optional[LLMOrchestrator] = None):
        """
        Initialize dual template manager.
        
        Args:
            forge_template_dir: Directory for FORGE templates
            llm_orchestrator: LLM for template decisions
        """
        self.forge_template_dir = Path(forge_template_dir or "forge_templates")
        self.llm = llm_orchestrator
        
        # Template engines
        self.logosai_engine = TemplateEngine()
        self.forge_templates: Dict[str, TemplateMetadata] = {}
        
        # Statistics
        self.template_usage: Dict[str, int] = {}
        self.template_performance: Dict[str, List[float]] = {}
        
        # Initialize FORGE template directory
        self._init_forge_templates()
        
    def _init_forge_templates(self):
        """Initialize FORGE template directory and load templates"""
        # Create directory structure
        self.forge_template_dir.mkdir(parents=True, exist_ok=True)
        
        categories = ['optimized', 'specialized', 'evolved', 'custom', 'experimental']
        for category in categories:
            (self.forge_template_dir / category).mkdir(exist_ok=True)
            
        # Create metadata file if not exists
        metadata_file = self.forge_template_dir / "metadata.json"
        if not metadata_file.exists():
            with open(metadata_file, 'w') as f:
                json.dump({}, f)
                
        # Load existing FORGE templates
        self._load_forge_templates()
        
    def _load_forge_templates(self):
        """Load FORGE templates from disk"""
        metadata_file = self.forge_template_dir / "metadata.json"
        
        try:
            with open(metadata_file, 'r') as f:
                metadata_dict = json.load(f)
                
            for name, meta in metadata_dict.items():
                # Handle format differences in metadata
                if 'last_updated' in meta and 'updated_at' not in meta:
                    meta['updated_at'] = meta.pop('last_updated')
                
                # Add missing required fields with defaults
                meta.setdefault('source', 'forge')
                meta.setdefault('version', '1.0.0')
                meta.setdefault('created_at', meta.get('updated_at', datetime.now().isoformat()))
                meta.setdefault('usage_count', 0)
                meta.setdefault('parent_template', None)
                meta.setdefault('evolution_history', [])
                
                # Convert ISO format strings to datetime if needed
                if isinstance(meta.get('created_at'), str):
                    meta['created_at'] = datetime.fromisoformat(meta['created_at'].replace('Z', '+00:00'))
                if isinstance(meta.get('updated_at'), str):
                    meta['updated_at'] = datetime.fromisoformat(meta['updated_at'].replace('Z', '+00:00'))
                
                self.forge_templates[name] = TemplateMetadata(**meta)
                
            logger.info(f"Loaded {len(self.forge_templates)} FORGE templates")
            
        except Exception as e:
            logger.error(f"Failed to load FORGE templates: {e}")
            
    def _save_forge_metadata(self):
        """Save FORGE template metadata to disk"""
        metadata_file = self.forge_template_dir / "metadata.json"
        
        metadata_dict = {
            name: meta.to_dict()
            for name, meta in self.forge_templates.items()
        }
        
        with open(metadata_file, 'w') as f:
            json.dump(metadata_dict, f, indent=2)
            
    async def list_all_templates(self, 
                               category: Optional[str] = None,
                               include_metadata: bool = True) -> List[Dict[str, Any]]:
        """
        List all available templates from both sources.
        
        Args:
            category: Filter by category
            include_metadata: Include full metadata
            
        Returns:
            List of template information
        """
        templates = []
        
        # Get LogosAI templates
        logosai_templates = self.logosai_engine.list_templates(category=category)
        
        for template_path in logosai_templates:
            metadata = self.logosai_engine.get_metadata(template_path)
            
            template_info = {
                'name': template_path,
                'source': 'logosai',
                'path': template_path,
                'readonly': True
            }
            
            if include_metadata and metadata:
                template_info.update({
                    'description': metadata.description,
                    'category': metadata.category,
                    'tags': metadata.tags,
                    'parameters': metadata.required_params
                })
                
            templates.append(template_info)
            
        # Get FORGE templates
        for name, metadata in self.forge_templates.items():
            if category and metadata.category != category:
                continue
                
            template_info = {
                'name': name,
                'source': 'forge',
                'path': metadata.path,
                'readonly': False
            }
            
            if include_metadata:
                template_info.update(metadata.to_dict())
                
            templates.append(template_info)
            
        return templates
        
    async def select_template(self,
                            requirements: Dict[str, Any],
                            context: Optional[Dict[str, Any]] = None) -> Tuple[str, str]:
        """
        Let LLM select the best template for given requirements.
        
        Args:
            requirements: Template requirements
            context: Additional context
            
        Returns:
            Tuple of (template_name, source)
        """
        # Get all available templates
        all_templates = await self.list_all_templates(include_metadata=True)
        
        if not all_templates:
            raise ValueError("No templates available")
            
        # Let LLM choose
        select_prompt = f"""Select the best template for these requirements:

Requirements:
{json.dumps(requirements, indent=2)}

Context:
{json.dumps(context or {}, indent=2)}

Available Templates:
{json.dumps(all_templates[:20], indent=2)}  # Limit for context

Consider:
1. Requirement match
2. Template specialization
3. Performance history
4. Evolution status (FORGE templates may be more optimized)

Select the best template and explain why:
Format: template_name|source|reason"""
        
        response = await self.llm.generate(
            select_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        # Parse response
        parts = response.strip().split('|')
        
        if len(parts) >= 2:
            template_name = parts[0].strip()
            source = parts[1].strip().lower()
            
            # Validate
            if source not in ['logosai', 'forge']:
                source = 'logosai'
                
            # Find exact match
            for template in all_templates:
                if template['name'] == template_name and template['source'] == source:
                    logger.info(f"Selected template: {template_name} from {source}")
                    return template_name, source
                    
        # Fallback to first template
        logger.warning("Failed to parse template selection, using fallback")
        return all_templates[0]['name'], all_templates[0]['source']
        
    async def get_template(self, 
                         template_name: str,
                         source: Optional[str] = None) -> str:
        """
        Get template content.
        
        Args:
            template_name: Template name
            source: Source ('logosai' or 'forge'), auto-detect if None
            
        Returns:
            Template content
        """
        if source == 'forge' or (source is None and template_name in self.forge_templates):
            # Get FORGE template
            metadata = self.forge_templates.get(template_name)
            if not metadata:
                raise ValueError(f"FORGE template not found: {template_name}")
                
            template_path = Path(metadata.path)
            if not template_path.is_absolute():
                template_path = self.forge_template_dir / template_path
                
            with open(template_path, 'r') as f:
                return f.read()
                
        else:
            # Get LogosAI template (already returns content)
            return self.logosai_engine.get_template(template_name)
            
    async def render_template(self,
                            template_name: str,
                            context: Dict[str, Any],
                            source: Optional[str] = None) -> str:
        """
        Render template with context.
        
        Args:
            template_name: Template name
            context: Template context/variables
            source: Source ('logosai' or 'forge')
            
        Returns:
            Rendered template
        """
        # Track usage
        usage_key = f"{source or 'auto'}:{template_name}"
        self.template_usage[usage_key] = self.template_usage.get(usage_key, 0) + 1
        
        if source == 'forge' or (source is None and template_name in self.forge_templates):
            # Render FORGE template
            template_content = await self.get_template(template_name, 'forge')
            
            # Use Jinja2 to render
            from jinja2 import Template
            template = Template(template_content)
            rendered = template.render(**context)
            
            # Update usage count
            if template_name in self.forge_templates:
                self.forge_templates[template_name].usage_count += 1
                self._save_forge_metadata()
                
            return rendered
            
        else:
            # Use LogosAI engine
            return self.logosai_engine.render(template_name, context)
            
    async def evolve_template(self,
                            source_template: str,
                            source: str,
                            evolution_strategy: str,
                            performance_data: Optional[Dict[str, Any]] = None) -> str:
        """
        Evolve a template and save as FORGE template.
        
        Args:
            source_template: Source template name
            source: Source of template ('logosai' or 'forge')
            evolution_strategy: Evolution strategy description
            performance_data: Performance data to guide evolution
            
        Returns:
            New evolved template name
        """
        # Get source template
        template_content = await self.get_template(source_template, source)
        
        # Get metadata
        if source == 'forge' and source_template in self.forge_templates:
            source_metadata = self.forge_templates[source_template]
        else:
            # Create metadata from LogosAI template
            logosai_meta = self.logosai_engine.get_metadata(source_template)
            source_metadata = TemplateMetadata(
                name=source_template,
                source='logosai',
                path=source_template,
                description=logosai_meta.description if logosai_meta else '',
                category=logosai_meta.category if logosai_meta else 'general',
                tags=logosai_meta.tags if logosai_meta else [],
                parameters=logosai_meta.required_params if logosai_meta else {}
            )
            
        # Let LLM evolve the template
        evolved_content = await self._evolve_template_content(
            template_content,
            source_metadata,
            evolution_strategy,
            performance_data
        )
        
        # Generate new template name
        evolved_name = await self._generate_evolved_name(
            source_template,
            evolution_strategy
        )
        
        # Determine category for evolved template
        category = await self._determine_evolved_category(
            source_metadata,
            evolution_strategy
        )
        
        # Save evolved template
        template_path = f"{category}/{evolved_name}.jinja2"
        full_path = self.forge_template_dir / template_path
        
        with open(full_path, 'w') as f:
            f.write(evolved_content)
            
        # Create metadata
        evolved_metadata = TemplateMetadata(
            name=evolved_name,
            source='forge',
            path=template_path,
            description=f"Evolved from {source_template}: {evolution_strategy}",
            category=category,
            tags=source_metadata.tags + ['evolved', category],
            parameters=source_metadata.parameters.copy(),
            parent_template=f"{source}:{source_template}",
            evolution_history=[{
                'date': datetime.now().isoformat(),
                'strategy': evolution_strategy,
                'source': f"{source}:{source_template}",
                'performance_data': performance_data
            }]
        )
        
        self.forge_templates[evolved_name] = evolved_metadata
        self._save_forge_metadata()
        
        logger.info(f"Created evolved template: {evolved_name}")
        
        return evolved_name
        
    async def _evolve_template_content(self,
                                     template_content: str,
                                     metadata: TemplateMetadata,
                                     strategy: str,
                                     performance_data: Optional[Dict[str, Any]]) -> str:
        """Let LLM evolve template content"""
        
        evolution_prompt = f"""Evolve this template based on the strategy:

Current Template:
```jinja2
{template_content}
```

Template Info:
- Description: {metadata.description}
- Category: {metadata.category}
- Parameters: {json.dumps(metadata.parameters)}

Evolution Strategy: {strategy}

Performance Data:
{json.dumps(performance_data or {}, indent=2)}

Apply the evolution strategy to improve the template.
Consider:
1. Performance optimizations
2. Better code structure
3. Enhanced error handling
4. More flexible parameters
5. Improved documentation

Evolved template:"""
        
        evolved_content = await self.llm.generate(
            evolution_prompt,
            task_type=TaskType.CODE_GENERATION,
            temperature=0.6,
            max_tokens=4000
        )
        
        return evolved_content
        
    async def _generate_evolved_name(self,
                                   source_name: str,
                                   strategy: str) -> str:
        """Let LLM generate name for evolved template"""
        
        name_prompt = f"""Generate a name for this evolved template:

Source template: {source_name}
Evolution strategy: {strategy}

The name should be:
1. Descriptive but concise
2. Include indication of evolution
3. Valid Python identifier format
4. Max 40 characters

Template name:"""
        
        response = await self.llm.generate(
            name_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.5
        )
        
        # Clean the name
        name = response.strip()
        name = ''.join(c for c in name if c.isalnum() or c in '_-')
        name = name[:40]
        
        # Ensure uniqueness
        if name in self.forge_templates:
            name = f"{name}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
        return name
        
    async def _determine_evolved_category(self,
                                        source_metadata: TemplateMetadata,
                                        strategy: str) -> str:
        """Let LLM determine category for evolved template"""
        
        category_prompt = f"""Determine the category for this evolved template:

Source category: {source_metadata.category}
Evolution strategy: {strategy}

Available categories:
- optimized: Performance-optimized templates
- specialized: Domain-specific templates
- evolved: General evolved templates
- custom: Heavily customized templates
- experimental: Experimental/testing templates

Best category:"""
        
        response = await self.llm.generate(
            category_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.3
        )
        
        category = response.strip().lower()
        
        # Validate category
        valid_categories = ['optimized', 'specialized', 'evolved', 'custom', 'experimental']
        if category not in valid_categories:
            category = 'evolved'
            
        return category
        
    def record_performance(self,
                         template_name: str,
                         source: str,
                         performance_score: float):
        """Record template performance"""
        
        key = f"{source}:{template_name}"
        
        if key not in self.template_performance:
            self.template_performance[key] = []
            
        self.template_performance[key].append(performance_score)
        
        # Update FORGE template metadata
        if source == 'forge' and template_name in self.forge_templates:
            scores = self.template_performance[key]
            avg_score = sum(scores) / len(scores)
            
            self.forge_templates[template_name].performance_score = avg_score
            self._save_forge_metadata()
            
    async def recommend_templates(self,
                                requirements: Dict[str, Any],
                                limit: int = 5) -> List[Dict[str, Any]]:
        """Let LLM recommend templates based on requirements"""
        
        all_templates = await self.list_all_templates(include_metadata=True)
        
        recommend_prompt = f"""Recommend templates for these requirements:

Requirements:
{json.dumps(requirements, indent=2)}

Available Templates (showing first 20):
{json.dumps(all_templates[:20], indent=2)}

Recommend up to {limit} templates with reasoning.
Consider:
1. Requirement match
2. Performance scores
3. Evolution status
4. Usage statistics

Format each recommendation as:
- template: name
- source: logosai/forge
- score: 0-100
- reason: why recommended"""
        
        response = await self.llm.generate(
            recommend_prompt,
            task_type=TaskType.ANALYSIS,
            temperature=0.4
        )
        
        # Parse recommendations
        recommendations = []
        current_rec = {}
        
        for line in response.split('\n'):
            line = line.strip()
            
            if line.startswith('- template:'):
                if current_rec:
                    recommendations.append(current_rec)
                current_rec = {'template': line.split(':', 1)[1].strip()}
            elif line.startswith('- ') and current_rec:
                key = line.split(':', 1)[0].replace('- ', '').strip()
                value = line.split(':', 1)[1].strip() if ':' in line else ''
                current_rec[key] = value
                
        if current_rec:
            recommendations.append(current_rec)
            
        # Convert scores to float
        for rec in recommendations:
            if 'score' in rec:
                try:
                    rec['score'] = float(rec['score'])
                except:
                    rec['score'] = 50.0
                    
        # Sort by score
        recommendations.sort(key=lambda x: x.get('score', 0), reverse=True)
        
        return recommendations[:limit]
        
    def get_statistics(self) -> Dict[str, Any]:
        """Get template usage and performance statistics"""
        
        # Count templates
        logosai_count = len(self.logosai_engine.list_templates())
        forge_count = len(self.forge_templates)
        
        # Calculate average performance
        avg_performances = {}
        for key, scores in self.template_performance.items():
            if scores:
                avg_performances[key] = sum(scores) / len(scores)
                
        # Most used templates
        most_used = sorted(
            self.template_usage.items(),
            key=lambda x: x[1],
            reverse=True
        )[:10]
        
        return {
            'total_templates': {
                'logosai': logosai_count,
                'forge': forge_count,
                'total': logosai_count + forge_count
            },
            'usage_stats': {
                'total_uses': sum(self.template_usage.values()),
                'most_used': most_used
            },
            'performance_stats': {
                'tracked_templates': len(self.template_performance),
                'average_scores': avg_performances
            },
            'evolution_stats': {
                'evolved_templates': sum(
                    1 for t in self.forge_templates.values()
                    if t.parent_template
                ),
                'categories': {
                    cat: sum(1 for t in self.forge_templates.values() if t.category == cat)
                    for cat in ['optimized', 'specialized', 'evolved', 'custom', 'experimental']
                }
            }
        }