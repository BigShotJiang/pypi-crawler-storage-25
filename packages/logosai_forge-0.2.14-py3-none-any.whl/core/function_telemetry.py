"""
FunctionTelemetry — Per-function execution metrics collection.

Tracks: call count, success rate, error types, execution time, agents using each function.
Enables: quality-based library admission, low-quality detection, reuse ranking.
"""

import sqlite3
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path
from loguru import logger


class FunctionTelemetry:
    """Collect per-function execution metrics (SQLite)."""

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            db_path = str(Path(__file__).parent.parent / "prototype" / "backend" / "forge_evolution.db")
            cls._instance = cls(db_path)
        return cls._instance

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._init_db()

    def _init_db(self):
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS function_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    func_name TEXT NOT NULL,
                    agent_id TEXT DEFAULT '',
                    success INTEGER DEFAULT 1,
                    duration_ms REAL DEFAULT 0,
                    error_type TEXT DEFAULT '',
                    executed_at TEXT NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_fm_name ON function_metrics(func_name)")
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[Telemetry] DB init: {e}")

    def record_execution(self, func_name: str, agent_id: str = "",
                          success: bool = True, duration_ms: float = 0,
                          error_type: str = ""):
        """Record a function execution result."""
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute(
                "INSERT INTO function_metrics (func_name, agent_id, success, duration_ms, error_type, executed_at) VALUES (?,?,?,?,?,?)",
                (func_name, agent_id, 1 if success else 0, duration_ms, error_type, datetime.now().isoformat())
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"[Telemetry] Record failed: {e}")

    def get_function_stats(self, func_name: str) -> Dict[str, Any]:
        """Get statistics for a specific function."""
        try:
            conn = sqlite3.connect(self._db_path)
            total = conn.execute("SELECT COUNT(*) FROM function_metrics WHERE func_name=?", (func_name,)).fetchone()[0]
            success = conn.execute("SELECT COUNT(*) FROM function_metrics WHERE func_name=? AND success=1", (func_name,)).fetchone()[0]
            avg_ms = conn.execute("SELECT AVG(duration_ms) FROM function_metrics WHERE func_name=?", (func_name,)).fetchone()[0] or 0

            errors = {}
            for row in conn.execute(
                "SELECT error_type, COUNT(*) FROM function_metrics WHERE func_name=? AND success=0 AND error_type!='' GROUP BY error_type",
                (func_name,)
            ):
                errors[row[0]] = row[1]

            agents = [r[0] for r in conn.execute(
                "SELECT DISTINCT agent_id FROM function_metrics WHERE func_name=? AND agent_id!=''", (func_name,)
            )]
            conn.close()

            return {
                "func_name": func_name,
                "call_count": total,
                "success_rate": round(success / max(total, 1), 3),
                "avg_duration_ms": round(avg_ms, 1),
                "error_types": errors,
                "agents_using": agents,
            }
        except Exception:
            return {"func_name": func_name, "call_count": 0, "success_rate": 0, "error_types": {}}

    def get_low_quality_functions(self, threshold: float = 0.85, min_calls: int = 3) -> List[Dict]:
        """Find functions with success rate below threshold."""
        try:
            conn = sqlite3.connect(self._db_path)
            rows = conn.execute("""
                SELECT func_name, COUNT(*) as total,
                       SUM(CASE WHEN success=1 THEN 1 ELSE 0 END) as successes
                FROM function_metrics GROUP BY func_name HAVING total >= ?
            """, (min_calls,)).fetchall()
            conn.close()

            result = []
            for name, total, successes in rows:
                rate = successes / total
                if rate < threshold:
                    result.append({"func_name": name, "success_rate": round(rate, 3), "call_count": total})
            return sorted(result, key=lambda x: x["success_rate"])
        except Exception:
            return []

    def get_top_reused(self, limit: int = 10) -> List[Dict]:
        """Get most reused functions ranked by call count."""
        try:
            conn = sqlite3.connect(self._db_path)
            rows = conn.execute("""
                SELECT func_name, COUNT(*) as cnt,
                       ROUND(AVG(CASE WHEN success=1 THEN 1.0 ELSE 0.0 END), 3) as rate
                FROM function_metrics GROUP BY func_name ORDER BY cnt DESC LIMIT ?
            """, (limit,)).fetchall()
            conn.close()
            return [{"func_name": r[0], "call_count": r[1], "success_rate": r[2]} for r in rows]
        except Exception:
            return []

    def get_all_stats(self) -> Dict[str, Any]:
        """Get aggregate telemetry stats."""
        try:
            conn = sqlite3.connect(self._db_path)
            total_funcs = conn.execute("SELECT COUNT(DISTINCT func_name) FROM function_metrics").fetchone()[0]
            total_calls = conn.execute("SELECT COUNT(*) FROM function_metrics").fetchone()[0]
            avg_success = conn.execute("SELECT AVG(CASE WHEN success=1 THEN 1.0 ELSE 0.0 END) FROM function_metrics").fetchone()[0] or 0
            conn.close()
            return {
                "total_functions_tracked": total_funcs,
                "total_calls": total_calls,
                "overall_success_rate": round(avg_success, 3),
            }
        except Exception:
            return {"total_functions_tracked": 0, "total_calls": 0}
