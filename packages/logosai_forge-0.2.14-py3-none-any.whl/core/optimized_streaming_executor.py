"""
Optimized Streaming Executor for FORGE AI
Enhanced performance with buffering, batching, and efficient event handling
"""

import sys
import asyncio
import json
import time
from typing import Dict, Any, Optional, List, Callable, AsyncIterator
from dataclasses import dataclass, field
from enum import Enum
from collections import deque
from pathlib import Path
import hashlib

from loguru import logger

# Import original components
from streaming_executor import (
    StreamEventType,
    StreamEvent,
    ExecutionContext,
    ExecutionMode,
    ExecutionResult
)


class EventBuffer:
    """Efficient event buffering for optimized streaming"""
    
    def __init__(self, 
                 batch_size: int = 10,
                 flush_interval: float = 0.1,
                 max_buffer_size: int = 1000):
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.max_buffer_size = max_buffer_size
        self.buffer: deque = deque(maxlen=max_buffer_size)
        self.last_flush = time.time()
        self._lock = asyncio.Lock()
        
    async def add(self, event: StreamEvent) -> Optional[List[StreamEvent]]:
        """Add event to buffer and return batch if ready"""
        async with self._lock:
            self.buffer.append(event)
            
            # Check if we should flush
            current_time = time.time()
            should_flush = (
                len(self.buffer) >= self.batch_size or
                (current_time - self.last_flush) >= self.flush_interval or
                event.type in [StreamEventType.ERROR, StreamEventType.COMPLETED]  # Priority events
            )
            
            if should_flush:
                return await self.flush()
            return None
    
    async def flush(self) -> List[StreamEvent]:
        """Flush all buffered events"""
        async with self._lock:
            if not self.buffer:
                return []
            
            events = list(self.buffer)
            self.buffer.clear()
            self.last_flush = time.time()
            return events


class StreamingMetrics:
    """Track streaming performance metrics"""
    
    def __init__(self):
        self.events_sent = 0
        self.bytes_sent = 0
        self.start_time = time.time()
        self.event_types: Dict[str, int] = {}
        self.batch_sizes: List[int] = []
        self.processing_times: List[float] = []
        
    def record_event(self, event: StreamEvent):
        """Record event metrics"""
        self.events_sent += 1
        event_data = json.dumps(event.to_dict())
        self.bytes_sent += len(event_data)
        event_type = event.type.value
        self.event_types[event_type] = self.event_types.get(event_type, 0) + 1
        
    def record_batch(self, size: int):
        """Record batch metrics"""
        self.batch_sizes.append(size)
        
    def record_processing_time(self, duration: float):
        """Record processing time"""
        self.processing_times.append(duration)
        
    def get_summary(self) -> Dict[str, Any]:
        """Get performance summary"""
        elapsed = time.time() - self.start_time
        avg_batch_size = sum(self.batch_sizes) / len(self.batch_sizes) if self.batch_sizes else 0
        avg_processing_time = sum(self.processing_times) / len(self.processing_times) if self.processing_times else 0
        
        return {
            "total_events": self.events_sent,
            "total_bytes": self.bytes_sent,
            "elapsed_seconds": elapsed,
            "events_per_second": self.events_sent / elapsed if elapsed > 0 else 0,
            "bytes_per_second": self.bytes_sent / elapsed if elapsed > 0 else 0,
            "event_distribution": self.event_types,
            "average_batch_size": avg_batch_size,
            "average_processing_time_ms": avg_processing_time * 1000,
            "total_batches": len(self.batch_sizes)
        }


class OptimizedStreamingExecutor:
    """Optimized streaming executor with enhanced performance"""
    
    def __init__(self, 
                 llm_orchestrator=None,
                 enable_buffering: bool = True,
                 batch_size: int = 10,
                 flush_interval: float = 0.1):
        self.llm_orchestrator = llm_orchestrator
        self.enable_buffering = enable_buffering
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        
        # Import original executor
        from streaming_executor import StreamingExecutor
        self.base_executor = StreamingExecutor(llm_orchestrator)
        
        # Performance tracking
        self.metrics = StreamingMetrics()
        
    async def execute_with_streaming(self, 
                                    context: ExecutionContext,
                                    stream_callback: Optional[Callable] = None) -> ExecutionResult:
        """Execute with optimized streaming"""
        
        # Create buffer if enabled
        buffer = EventBuffer(
            batch_size=self.batch_size,
            flush_interval=self.flush_interval
        ) if self.enable_buffering else None
        
        # Track execution start
        start_time = time.time()
        
        # Create optimized callback
        async def optimized_callback(event: StreamEvent):
            # Record metrics
            self.metrics.record_event(event)
            
            if self.enable_buffering and buffer:
                # Add to buffer
                batch = await buffer.add(event)
                if batch and stream_callback:
                    # Send batched events
                    self.metrics.record_batch(len(batch))
                    
                    # Send as single batch message for efficiency
                    batch_event = StreamEvent(
                        type=StreamEventType.STATUS,
                        data={
                            "batch": True,
                            "events": [e.to_dict() for e in batch],
                            "count": len(batch)
                        }
                    )
                    await stream_callback(batch_event)
            else:
                # Direct streaming without buffering
                if stream_callback:
                    await stream_callback(event)
        
        # Set optimized callback
        context.stream_callback = optimized_callback
        
        # Execute with base executor
        result = await self.base_executor.execute(context)
        
        # Flush any remaining events
        if self.enable_buffering and buffer:
            remaining = await buffer.flush()
            if remaining and stream_callback:
                batch_event = StreamEvent(
                    type=StreamEventType.STATUS,
                    data={
                        "batch": True,
                        "events": [e.to_dict() for e in remaining],
                        "count": len(remaining),
                        "final": True
                    }
                )
                await stream_callback(batch_event)
        
        # Record execution time
        execution_time = time.time() - start_time
        self.metrics.record_processing_time(execution_time)
        
        # Add metrics to result
        result.metrics = self.metrics.get_summary()
        
        return result
    
    async def execute_parallel_tests(self,
                                    code: str,
                                    test_cases: List[Dict[str, Any]],
                                    max_workers: int = 3) -> List[ExecutionResult]:
        """Execute multiple test cases in parallel for better performance"""
        
        async def run_test(test_data: Dict[str, Any], index: int) -> ExecutionResult:
            """Run single test case"""
            context = ExecutionContext(
                code=code,
                input_data=test_data,
                mode=ExecutionMode.QUICK_TEST,
                timeout=30
            )
            
            # Add test index to events
            original_callback = context.stream_callback
            async def indexed_callback(event: StreamEvent):
                event.data = {
                    "test_index": index,
                    "test_name": test_data.get("name", f"Test {index}"),
                    **event.data if isinstance(event.data, dict) else {"value": event.data}
                }
                if original_callback:
                    await original_callback(event)
            
            context.stream_callback = indexed_callback
            
            return await self.execute_with_streaming(context)
        
        # Create tasks with concurrency limit
        semaphore = asyncio.Semaphore(max_workers)
        
        async def run_with_semaphore(test_data: Dict[str, Any], index: int):
            async with semaphore:
                return await run_test(test_data, index)
        
        # Run all tests in parallel
        tasks = [
            run_with_semaphore(test_data, i)
            for i, test_data in enumerate(test_cases)
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle exceptions
        final_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Test {i} failed with exception: {result}")
                # Create error result
                error_result = ExecutionResult(
                    success=False,
                    output="",
                    error=str(result),
                    execution_time=0
                )
                final_results.append(error_result)
            else:
                final_results.append(result)
        
        return final_results


class StreamCompressor:
    """Compress streaming data for bandwidth optimization"""
    
    @staticmethod
    def compress_event(event: StreamEvent) -> Dict[str, Any]:
        """Compress event data"""
        compressed = {
            "t": event.type.value[0],  # First letter of type
            "d": event.data,
            "ts": int(event.timestamp * 1000)  # Milliseconds as int
        }
        
        # Compress common fields
        if isinstance(event.data, dict):
            if "message" in event.data:
                compressed["d"]["m"] = compressed["d"].pop("message")
            if "progress" in event.data:
                compressed["d"]["p"] = compressed["d"].pop("progress")
            if "status" in event.data:
                compressed["d"]["s"] = compressed["d"].pop("status")
        
        return compressed
    
    @staticmethod
    def decompress_event(compressed: Dict[str, Any]) -> StreamEvent:
        """Decompress event data"""
        # Map single letters back to types
        type_map = {
            "s": StreamEventType.STATUS,
            "o": StreamEventType.STDOUT,
            "e": StreamEventType.ERROR,
            "r": StreamEventType.RESULT,
            "c": StreamEventType.COMPLETED,
            "f": StreamEventType.FIX_ATTEMPT,
            "m": StreamEventType.METRICS
        }
        
        event_type = type_map.get(compressed["t"], StreamEventType.STATUS)
        
        # Decompress data
        data = compressed["d"]
        if isinstance(data, dict):
            if "m" in data:
                data["message"] = data.pop("m")
            if "p" in data:
                data["progress"] = data.pop("p")
            if "s" in data:
                data["status"] = data.pop("s")
        
        return StreamEvent(
            type=event_type,
            data=data,
            timestamp=compressed["ts"] / 1000.0
        )


# Cache for frequently used code patterns
class ExecutionCache:
    """Cache execution results for common patterns"""
    
    def __init__(self, max_size: int = 100):
        self.cache: Dict[str, ExecutionResult] = {}
        self.max_size = max_size
        self.hits = 0
        self.misses = 0
        
    def get_key(self, code: str, input_data: Dict[str, Any]) -> str:
        """Generate cache key"""
        # Hash code and input for consistent key
        content = f"{code}|{json.dumps(input_data, sort_keys=True)}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def get(self, code: str, input_data: Dict[str, Any]) -> Optional[ExecutionResult]:
        """Get cached result"""
        key = self.get_key(code, input_data)
        if key in self.cache:
            self.hits += 1
            logger.debug(f"Cache hit for key {key}")
            return self.cache[key]
        self.misses += 1
        return None
    
    def set(self, code: str, input_data: Dict[str, Any], result: ExecutionResult):
        """Cache result"""
        if len(self.cache) >= self.max_size:
            # Remove oldest entry (simple FIFO)
            oldest = next(iter(self.cache))
            del self.cache[oldest]
        
        key = self.get_key(code, input_data)
        self.cache[key] = result
        logger.debug(f"Cached result for key {key}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total = self.hits + self.misses
        return {
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": self.hits / total if total > 0 else 0,
            "size": len(self.cache),
            "max_size": self.max_size
        }


# Export optimized components
__all__ = [
    'OptimizedStreamingExecutor',
    'EventBuffer',
    'StreamingMetrics',
    'StreamCompressor',
    'ExecutionCache'
]