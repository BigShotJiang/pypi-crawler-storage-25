#!/usr/bin/env python3
"""
🔍 강화된 코드 파싱 시스템
AI 응답에서 코드를 정확하게 추출하는 고급 파서
```python 마커, 잘린 코드, 다양한 응답 형식을 완벽 처리
"""

import re
import json
import logging
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class ParsedResponse:
    """파싱된 응답 결과"""
    code: str
    explanation: str
    confidence: float  # 0.0 ~ 1.0
    is_complete: bool
    parsing_method: str
    issues: List[str]

class EnhancedCodeParser:
    """강화된 AI 응답 코드 파서"""
    
    def __init__(self):
        """초기화"""
        # 다양한 코드 블록 패턴 (우선순위 순)
        self.code_block_patterns = [
            # 가장 일반적인 패턴들
            (r'```python\s*\n(.*?)\n```', "python_block", 0.9),
            (r'```py\s*\n(.*?)\n```', "py_block", 0.9),
            (r'```\s*\n(.*?)\n```', "generic_block", 0.8),
            
            # 공백 없는 패턴들
            (r'```python\s*(.*?)\s*```', "python_inline", 0.8),
            (r'```py\s*(.*?)\s*```', "py_inline", 0.8),
            (r'```(.*?)```', "generic_inline", 0.7),
            
            # 특수한 경우들
            (r'```python(.*?)```', "python_attached", 0.6),
            (r'```py(.*?)```', "py_attached", 0.6),
        ]
        
        # JSON 응답 패턴
        self.json_patterns = [
            (r'\{[^{}]*"code"\s*:\s*"([^"]*)"[^{}]*\}', "simple_json", 0.9),
            (r'\{.*?"code"\s*:\s*"(.*?)".*?\}', "complex_json", 0.8),
        ]
        
        # 코드 완전성 검증 패턴
        self.completeness_indicators = [
            r'def\s+\w+\([^)]*\):',  # 함수 정의
            r'class\s+\w+[^:]*:',    # 클래스 정의
            r'import\s+\w+',         # import 문
            r'from\s+\w+\s+import',  # from import 문
        ]
        
        # 잘린 코드 감지 패턴
        self.truncation_indicators = [
            r'\.{3,}$',              # 끝에 ...
            r'\[\.{3}\]$',           # 끝에 [...]
            r'#.*truncated.*$',      # truncated 주석
            r'#.*continued.*$',      # continued 주석
            r'^\s*$',                # 빈 줄로 끝남 (의심)
        ]
    
    def parse_ai_response(
        self, 
        response: str, 
        original_code: str = "",
        error_context: str = ""
    ) -> ParsedResponse:
        """AI 응답을 파싱하여 코드 추출"""
        
        if not response or not response.strip():
            return ParsedResponse(
                code="",
                explanation="빈 응답",
                confidence=0.0,
                is_complete=False,
                parsing_method="empty",
                issues=["응답이 비어 있음"]
            )
        
        logger.info(f"🔍 AI 응답 파싱 시작 (길이: {len(response)} chars)")
        
        # 1단계: JSON 형식 시도
        json_result = self._try_parse_json(response)
        if json_result:
            return json_result
            
        # 2단계: 코드 블록 패턴 시도
        code_block_result = self._try_parse_code_blocks(response)
        if code_block_result:
            return code_block_result
            
        # 3단계: 순수 코드 추출 시도
        pure_code_result = self._try_parse_pure_code(response, original_code)
        if pure_code_result:
            return pure_code_result
            
        # 4단계: 응급 파싱
        return self._emergency_parse(response, original_code)
    
    def _try_parse_json(self, response: str) -> Optional[ParsedResponse]:
        """JSON 형식 파싱 시도"""
        for pattern, method, confidence in self.json_patterns:
            match = re.search(pattern, response, re.DOTALL | re.IGNORECASE)
            if match:
                try:
                    # JSON 전체 추출 시도
                    json_start = response.find('{')
                    json_end = response.rfind('}') + 1
                    if json_start != -1 and json_end > json_start:
                        json_data = json.loads(response[json_start:json_end])
                        
                        if 'code' in json_data:
                            code = json_data['code']
                            explanation = json_data.get('explanation', '')
                            
                            # 코드 정제
                            cleaned_code = self._clean_extracted_code(code)
                            is_complete = self._check_completeness(cleaned_code)
                            
                            logger.info(f"✅ JSON 파싱 성공: {method}")
                            return ParsedResponse(
                                code=cleaned_code,
                                explanation=explanation,
                                confidence=confidence,
                                is_complete=is_complete,
                                parsing_method=method,
                                issues=[] if is_complete else ["코드가 불완전할 수 있음"]
                            )
                except json.JSONDecodeError:
                    continue
        
        return None
    
    def _try_parse_code_blocks(self, response: str) -> Optional[ParsedResponse]:
        """코드 블록 패턴 파싱 시도"""
        for pattern, method, confidence in self.code_block_patterns:
            match = re.search(pattern, response, re.DOTALL)
            if match:
                extracted_code = match.group(1)
                
                # 코드 품질 검증
                if self._is_valid_code_extract(extracted_code):
                    cleaned_code = self._clean_extracted_code(extracted_code)
                    is_complete = self._check_completeness(cleaned_code)
                    
                    # 설명 추출 시도
                    explanation = self._extract_explanation(response, extracted_code)
                    
                    logger.info(f"✅ 코드 블록 파싱 성공: {method}")
                    return ParsedResponse(
                        code=cleaned_code,
                        explanation=explanation,
                        confidence=confidence,
                        is_complete=is_complete,
                        parsing_method=method,
                        issues=[] if is_complete else ["코드가 불완전할 수 있음"]
                    )
        
        return None
    
    def _try_parse_pure_code(self, response: str, original_code: str = "") -> Optional[ParsedResponse]:
        """순수 코드 추출 시도"""
        # Python 코드 특성 확인
        python_indicators = [
            'def ', 'class ', 'import ', 'from ', 'if __name__',
            'print(', 'return ', 'elif ', 'except:', 'try:', 'with '
        ]
        
        indicator_count = sum(1 for indicator in python_indicators if indicator in response)
        
        if indicator_count >= 3:  # 충분한 Python 코드 특성
            cleaned_code = self._clean_extracted_code(response)
            is_complete = self._check_completeness(cleaned_code)
            
            # 원본 코드와의 유사성 검사
            similarity = self._calculate_similarity(cleaned_code, original_code)
            confidence = min(0.7, 0.4 + similarity * 0.3)  # 최대 0.7
            
            logger.info(f"✅ 순수 코드 추출 성공 (신뢰도: {confidence:.2f})")
            return ParsedResponse(
                code=cleaned_code,
                explanation="순수 코드로 감지됨",
                confidence=confidence,
                is_complete=is_complete,
                parsing_method="pure_code",
                issues=["코드 블록 마커 없음"] if not is_complete else []
            )
        
        return None
    
    def _emergency_parse(self, response: str, original_code: str = "") -> ParsedResponse:
        """응급 파싱 (최후 수단)"""
        logger.warning("⚠️ 응급 파싱 모드 실행")
        
        # 응답에서 가장 긴 연속된 코드 라인들 찾기
        lines = response.split('\n')
        best_code_section = ""
        current_section = []
        
        for line in lines:
            # 코드 라인인지 판단
            if line.strip() and self._is_code_line(line):
                current_section.append(line)
            else:
                if len(current_section) > len(best_code_section.split('\n')):
                    best_code_section = '\n'.join(current_section)
                current_section = []
        
        # 마지막 섹션도 확인
        if len(current_section) > len(best_code_section.split('\n')):
            best_code_section = '\n'.join(current_section)
        
        if not best_code_section:
            best_code_section = original_code  # 원본 반환
        
        cleaned_code = self._clean_extracted_code(best_code_section)
        
        return ParsedResponse(
            code=cleaned_code,
            explanation="응급 파싱으로 추출됨",
            confidence=0.3,
            is_complete=False,
            parsing_method="emergency",
            issues=["파싱 신뢰도 낮음", "수동 검토 필요"]
        )
    
    def _clean_extracted_code(self, code: str) -> str:
        """추출된 코드 정제"""
        if not code:
            return ""
        
        # 기본 정제
        code = code.strip()
        
        # 인코딩 문제 수정
        replacements = [
            ('\\n', '\n'),      # 이스케이프된 개행
            ('\\t', '\t'),      # 이스케이프된 탭
            ('\\"', '"'),       # 이스케이프된 따옴표
            ("\\'", "'"),       # 이스케이프된 작은따옴표
        ]
        
        for old, new in replacements:
            code = code.replace(old, new)
        
        # 첫 줄이 설명 텍스트(자연어)면 제거, 코드 라인은 유지
        lines = code.split('\n')
        if lines and lines[0].strip() and not self._is_code_line(lines[0]):
            # 첫 줄이 설명 텍스트일 가능성
            if len(lines) > 1:
                lines = lines[1:]
                code = '\n'.join(lines)
        
        return code
    
    @staticmethod
    def _is_code_line(line: str) -> bool:
        """줄이 Python 코드인지 판단 (자연어 설명이 아닌지)"""
        stripped = line.strip()
        if not stripped:
            return True  # 빈 줄은 코드의 일부
        # 명확한 코드 시작 패턴
        code_prefixes = (
            '#', 'import ', 'from ', 'def ', 'class ', 'if ', 'elif ', 'else:',
            'for ', 'while ', 'try:', 'except', 'finally:', 'with ', 'return ',
            'yield ', 'raise ', 'pass', 'break', 'continue', 'async ', 'await ',
            '@',  # 데코레이터
        )
        if stripped.startswith(code_prefixes):
            return True
        # 대입문 (variable = ...), 함수 호출 (func(...)), 인덱싱 (x[...])
        if '=' in stripped and not stripped.startswith('='):
            return True
        if '(' in stripped:
            return True
        if stripped.startswith('[') or stripped.startswith('{'):
            return True
        # 숫자 리터럴, 문자열 리터럴
        if stripped[0].isdigit() or stripped[0] in ('"', "'"):
            return True
        # 들여쓰기가 있으면 코드 블록 내부
        if line.startswith(' ') or line.startswith('\t'):
            return True
        return False

    def _is_valid_code_extract(self, code: str) -> bool:
        """추출된 코드의 유효성 검증"""
        if not code or len(code.strip()) < 3:
            return False

        # Python 키워드 존재 확인
        python_keywords = ['def', 'class', 'import', 'from', 'if', 'for', 'while', 'try', 'except',
                           'return', 'print', 'elif', 'else', 'with', 'raise', 'yield', 'async', 'await']
        has_keywords = any(keyword in code for keyword in python_keywords)

        # 대입문이나 함수 호출도 유효한 코드
        has_assignment = '=' in code and code.strip()[0] != '='
        has_call = '(' in code and ')' in code

        return has_keywords or has_assignment or has_call
    
    def _check_completeness(self, code: str) -> bool:
        """코드 완전성 검사"""
        if not code:
            return False
        
        # 잘림 표시 확인
        for pattern in self.truncation_indicators:
            if re.search(pattern, code, re.MULTILINE):
                return False
        
        # 괄호 균형 확인
        if code.count('(') != code.count(')'):
            return False
        if code.count('[') != code.count(']'):
            return False
        if code.count('{') != code.count('}'):
            return False
        
        # 따옴표 균형 확인
        single_quotes = code.count("'") - code.count("\\'")
        double_quotes = code.count('"') - code.count('\\"')
        if single_quotes % 2 != 0 or double_quotes % 2 != 0:
            return False
        
        return True
    
    def _extract_explanation(self, response: str, code: str) -> str:
        """응답에서 설명 추출"""
        # 코드 블록 전/후 텍스트 찾기
        code_index = response.find(code)
        if code_index == -1:
            return ""
        
        # 코드 앞의 텍스트
        before_text = response[:code_index].strip()
        # 코드 뒤의 텍스트  
        after_text = response[code_index + len(code):].strip()
        
        # 설명으로 보이는 부분 추출
        explanation_parts = []
        
        if before_text and len(before_text) < 200:  # 너무 길지 않은 설명
            explanation_parts.append(before_text)
        
        if after_text and len(after_text) < 200:
            explanation_parts.append(after_text)
        
        return ' | '.join(explanation_parts)
    
    def _calculate_similarity(self, code1: str, code2: str) -> float:
        """두 코드 간 유사도 계산 (0.0 ~ 1.0)"""
        if not code1 or not code2:
            return 0.0
        
        # 간단한 토큰 기반 유사도
        tokens1 = set(re.findall(r'\w+', code1.lower()))
        tokens2 = set(re.findall(r'\w+', code2.lower()))
        
        if not tokens1 and not tokens2:
            return 1.0
        if not tokens1 or not tokens2:
            return 0.0
        
        intersection = len(tokens1.intersection(tokens2))
        union = len(tokens1.union(tokens2))
        
        return intersection / union if union > 0 else 0.0
