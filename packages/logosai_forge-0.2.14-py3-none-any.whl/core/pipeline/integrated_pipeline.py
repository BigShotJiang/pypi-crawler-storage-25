"""
Integrated Pipeline for Business Logic Generation
Step 1 → Step 2 → Step 3 통합 파이프라인
"""

import os
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from loguru import logger
import json

# Step 1: Pattern Library
from ..business_patterns.pattern_library import load_all_patterns, get_pattern_by_id

# Step 2: Pattern Matching with Gemini Lite
from ..business_patterns.gemini_lite_matcher import GeminiLiteHybridMatcher
from ..business_patterns.pattern_matcher import PatternMatch

# Step 3: Business Logic Generator
from ..business_logic.logic_generator import BusinessLogicGenerator, GeneratedLogic


@dataclass
class PipelineResult:
    """파이프라인 실행 결과"""
    query: str
    matched_patterns: List[PatternMatch]
    generated_logic: List[GeneratedLogic]
    combined_code: str
    execution_result: Optional[Dict[str, Any]]
    success: bool
    error: Optional[str]


class IntegratedPipeline:
    """통합 비즈니스 로직 생성 파이프라인"""
    
    def __init__(self, api_key: str = None):
        """
        파이프라인 초기화
        
        Args:
            api_key: Gemini API key (없으면 환경변수에서 가져옴)
        """
        # Step 1: Pattern Library 초기화
        self.patterns = load_all_patterns()
        logger.info(f"[Step 1] Loaded {len(self.patterns)} patterns")
        
        # Step 2: Pattern Matcher 초기화
        api_key = api_key or os.getenv("GEMINI_API_KEY")
        if api_key:
            self.matcher = GeminiLiteHybridMatcher(api_key)
            logger.info("[Step 2] Initialized Gemini Lite Hybrid Matcher")
        else:
            # API 키가 없으면 기본 매처만 사용
            from ..business_patterns.pattern_matcher_v2 import ImprovedPatternMatcher
            self.matcher = ImprovedPatternMatcher()
            logger.warning("[Step 2] No API key, using basic matcher only")
        
        # Step 3: Logic Generator 초기화
        self.generator = BusinessLogicGenerator()
        logger.info("[Step 3] Initialized Business Logic Generator")
        
        # 템플릿 저장소
        self.templates = self._load_templates()
    
    def _load_templates(self) -> Dict[str, str]:
        """비즈니스 로직 템플릿 로드"""
        return {
            "ecommerce": """
# E-Commerce Business Logic
{imports}

class ECommerceLogic:
    \"\"\"전자상거래 비즈니스 로직\"\"\"
    
    def __init__(self):
        self.data = []
    
{methods}
    
    def execute(self, data):
        \"\"\"비즈니스 로직 실행\"\"\"
        result = data
        {execution_flow}
        return result
""",
            
            "analytics": """
# Analytics Business Logic
{imports}

class AnalyticsLogic:
    \"\"\"데이터 분석 비즈니스 로직\"\"\"
    
{methods}
    
    def analyze(self, data):
        \"\"\"데이터 분석 실행\"\"\"
        results = {{}}
        {execution_flow}
        return results
""",
            
            "alert": """
# Alert Business Logic
{imports}

class AlertLogic:
    \"\"\"알림 비즈니스 로직\"\"\"
    
{methods}
    
    def monitor(self, data):
        \"\"\"모니터링 및 알림\"\"\"
        alerts = []
        {execution_flow}
        return alerts
""",
            
            "default": """
# Generated Business Logic
{imports}

class BusinessLogic:
    \"\"\"자동 생성된 비즈니스 로직\"\"\"
    
{methods}
    
    def process(self, data):
        \"\"\"데이터 처리\"\"\"
        result = data
        {execution_flow}
        return result
"""
        }
    
    def process_query(self, query: str, context: Dict[str, Any] = None) -> PipelineResult:
        """
        사용자 쿼리를 처리하여 비즈니스 로직 생성
        
        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트
            
        Returns:
            파이프라인 실행 결과
        """
        try:
            logger.info(f"Processing query: {query}")
            
            # Step 1 & 2: Pattern Matching
            matched_patterns = self._match_patterns(query, context)
            
            if not matched_patterns:
                return PipelineResult(
                    query=query,
                    matched_patterns=[],
                    generated_logic=[],
                    combined_code="",
                    execution_result=None,
                    success=False,
                    error="No patterns matched"
                )
            
            # Step 3: Generate Business Logic
            generated_logic = self._generate_logic(matched_patterns)
            
            # Combine with Template
            combined_code = self._combine_with_template(generated_logic, query)
            
            # Execute (optional)
            execution_result = self._execute_code(combined_code, context)
            
            return PipelineResult(
                query=query,
                matched_patterns=matched_patterns,
                generated_logic=generated_logic,
                combined_code=combined_code,
                execution_result=execution_result,
                success=True,
                error=None
            )
            
        except Exception as e:
            logger.error(f"Pipeline error: {e}")
            return PipelineResult(
                query=query,
                matched_patterns=[],
                generated_logic=[],
                combined_code="",
                execution_result=None,
                success=False,
                error=str(e)
            )
    
    def _match_patterns(self, query: str, context: Dict[str, Any] = None) -> List[PatternMatch]:
        """Step 2: 패턴 매칭"""
        logger.info("[Step 2] Matching patterns...")
        
        matches = self.matcher.match_patterns(query, context)
        
        logger.info(f"[Step 2] Found {len(matches)} patterns")
        for match in matches[:3]:  # 상위 3개만 로그
            logger.debug(f"  - {match.pattern_id}: {match.confidence_score:.0%}")
        
        return matches
    
    def _generate_logic(self, patterns: List[PatternMatch]) -> List[GeneratedLogic]:
        """Step 3: 비즈니스 로직 생성"""
        logger.info("[Step 3] Generating business logic...")
        
        logic_list = self.generator.generate_multiple(patterns)
        
        logger.info(f"[Step 3] Generated {len(logic_list)} logic modules")
        
        return logic_list
    
    def _combine_with_template(self, logic_list: List[GeneratedLogic], query: str) -> str:
        """템플릿과 결합"""
        logger.info("[Step 3] Combining with template...")
        
        # 적절한 템플릿 선택
        template_type = self._select_template(logic_list, query)
        template = self.templates.get(template_type, self.templates["default"])
        
        # imports 통합
        all_imports = set()
        for logic in logic_list:
            all_imports.update(logic.imports)
        imports_str = "\n".join(sorted(all_imports))
        
        # methods 통합 (클래스 내부 메서드로 들여쓰기)
        methods = []
        for logic in logic_list:
            # 각 메서드를 클래스 내부로 들여쓰기 (4 spaces)
            indented_code = "\n".join(f"    {line}" if line else "" for line in logic.code.split("\n"))
            methods.append(indented_code)
        methods_str = "\n".join(methods)
        
        # execution flow 생성
        execution_flow = self._generate_execution_flow(logic_list)
        
        # 템플릿 채우기
        combined_code = template.format(
            imports=imports_str,
            methods=methods_str,
            execution_flow=execution_flow
        )
        
        logger.info(f"[Step 3] Combined code: {len(combined_code)} characters")
        
        return combined_code
    
    def _select_template(self, logic_list: List[GeneratedLogic], query: str) -> str:
        """적절한 템플릿 선택"""
        # 패턴 ID를 기반으로 템플릿 선택
        pattern_ids = [logic.pattern_id for logic in logic_list]
        
        if any("alert" in pid for pid in pattern_ids):
            return "alert"
        elif any("aggregation" in pid or "data" in pid for pid in pattern_ids):
            return "analytics"
        elif any("discount" in pid or "tier" in pid for pid in pattern_ids):
            return "ecommerce"
        else:
            return "default"
    
    def _generate_execution_flow(self, logic_list: List[GeneratedLogic]) -> str:
        """실행 흐름 생성"""
        flow = []
        
        for logic in logic_list:
            # 함수 이름 추출
            import re
            func_match = re.search(r'def (\w+)\(', logic.code)
            if func_match:
                func_name = func_match.group(1)
                
                # 패턴별 실행 코드 생성
                if "filter" in logic.pattern_id:
                    flow.append(f"result = self.{func_name}(result)")
                elif "discount" in logic.pattern_id:
                    flow.append(f"for item in result:\n            item['price'] = self.{func_name}(item.get('price', 0))['final_price']")
                elif "alert" in logic.pattern_id:
                    flow.append(f"alert = self.{func_name}(result)\n        if alert.get('alert'):\n            alerts.append(alert)")
                elif "aggregation" in logic.pattern_id:
                    flow.append(f"results['aggregated'] = self.{func_name}(result)")
                else:
                    flow.append(f"result = self.{func_name}(result)")
        
        return "\n        ".join(flow) if flow else "pass"
    
    def _execute_code(self, code: str, context: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """생성된 코드 실행 (선택적)"""
        try:
            # 안전을 위해 제한된 환경에서 실행 (필요한 builtins만 허용)
            safe_builtins = {
                '__import__': __import__,
                'len': len,
                'range': range,
                'isinstance': isinstance,
                'str': str,
                'int': int,
                'float': float,
                'dict': dict,
                'list': list,
                'min': min,
                'max': max,
                'sum': sum,
                'ValueError': ValueError,
                'TypeError': TypeError,
            }
            exec_globals = {"__builtins__": safe_builtins}
            exec_locals = {}
            
            # 코드 실행
            exec(code, exec_globals, exec_locals)
            
            # 클래스 찾기
            for name, obj in exec_locals.items():
                if isinstance(obj, type) and "Logic" in name:
                    # 인스턴스 생성
                    instance = obj()
                    
                    # 테스트 데이터
                    test_data = context.get("test_data", [
                        {"id": 1, "name": "Item1", "price": 10000, "tier": "VIP"},
                        {"id": 2, "name": "Item2", "price": 20000, "tier": "Normal"},
                        {"id": 3, "name": "Item3", "price": 15000, "tier": "VIP"}
                    ])
                    
                    # 실행
                    if hasattr(instance, 'execute'):
                        result = instance.execute(test_data)
                    elif hasattr(instance, 'process'):
                        result = instance.process(test_data)
                    elif hasattr(instance, 'analyze'):
                        result = instance.analyze(test_data)
                    elif hasattr(instance, 'monitor'):
                        result = instance.monitor(test_data)
                    else:
                        result = None
                    
                    return {"success": True, "result": result}
            
            return {"success": False, "error": "No executable class found"}
            
        except Exception as e:
            logger.error(f"Execution error: {e}")
            return {"success": False, "error": str(e)}
    
    def batch_process(self, queries: List[str]) -> List[PipelineResult]:
        """
        여러 쿼리 일괄 처리
        
        Args:
            queries: 쿼리 리스트
            
        Returns:
            결과 리스트
        """
        results = []
        
        for query in queries:
            result = self.process_query(query)
            results.append(result)
        
        return results
    
    def generate_and_save(self, query: str, output_file: str) -> bool:
        """
        비즈니스 로직 생성 후 파일로 저장
        
        Args:
            query: 사용자 쿼리
            output_file: 출력 파일 경로
            
        Returns:
            성공 여부
        """
        result = self.process_query(query)
        
        if result.success and result.combined_code:
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(result.combined_code)
                logger.info(f"Saved generated code to: {output_file}")
                return True
            except Exception as e:
                logger.error(f"Failed to save file: {e}")
                return False
        
        return False