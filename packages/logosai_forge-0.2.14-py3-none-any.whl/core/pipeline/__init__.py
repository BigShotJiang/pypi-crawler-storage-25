"""
Integrated Pipeline Module
"""

from .integrated_pipeline import IntegratedPipeline, PipelineResult

__all__ = [
    'IntegratedPipeline',
    'PipelineResult'
]