"""
Advanced Pipeline with Step 4 Integration
Steps 1→2→3→4 완전 통합 파이프라인
"""

import os
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from loguru import logger
import time

# Step 1: Pattern Library
from ..business_patterns.pattern_library import load_all_patterns

# Step 2: Pattern Matching
from ..business_patterns.gemini_lite_matcher import GeminiLiteHybridMatcher
from ..business_patterns.pattern_matcher import PatternMatch
from ..business_patterns.pattern_matcher_v2 import ImprovedPatternMatcher

# Step 3: Business Logic Generator
from ..business_logic.logic_generator import BusinessLogicGenerator

# Step 4: Advanced Template Combiner
from ..template_combiner.combiner import AdvancedTemplateCombiner, CombinedResult


@dataclass
class AdvancedPipelineResult:
    """고급 파이프라인 결과"""
    query: str
    matched_patterns: List[PatternMatch]
    combined_result: CombinedResult
    execution_time_ms: float
    success: bool
    error: Optional[str]


class AdvancedPipeline:
    """Steps 1→2→3→4 통합 파이프라인"""
    
    def __init__(self, api_key: str = None):
        """
        파이프라인 초기화
        
        Args:
            api_key: Gemini API key (없으면 환경변수에서 가져옴)
        """
        logger.info("Initializing Advanced Pipeline (Steps 1→2→3→4)")
        
        # Step 1: Pattern Library
        self.patterns = load_all_patterns()
        logger.info(f"[Step 1] Loaded {len(self.patterns)} patterns")
        
        # Step 2: Pattern Matcher
        # GEMINI_API_KEY 또는 GOOGLE_API_KEY 환경변수 확인
        api_key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if api_key:
            self.matcher = GeminiLiteHybridMatcher(api_key)
            logger.info("[Step 2] Initialized Gemini Lite Hybrid Matcher")
        else:
            self.matcher = ImprovedPatternMatcher()
            logger.warning("[Step 2] No API key, using basic matcher only")
        
        # Step 3: Logic Generator
        self.generator = BusinessLogicGenerator()
        logger.info("[Step 3] Initialized Business Logic Generator")
        
        # Step 4: Advanced Template Combiner
        self.combiner = AdvancedTemplateCombiner()
        logger.info("[Step 4] Initialized Advanced Template Combiner")
    
    def process(self, query: str, context: Dict[str, Any] = None) -> AdvancedPipelineResult:
        """
        사용자 쿼리를 처리하여 고급 비즈니스 로직 생성
        
        Args:
            query: 사용자 쿼리
            context: 추가 컨텍스트
            
        Returns:
            고급 파이프라인 실행 결과
        """
        start_time = time.time()
        
        try:
            logger.info(f"Processing query: {query}")
            
            # Step 1 & 2: Pattern Matching
            logger.info("[Step 1→2] Pattern matching...")
            matched_patterns = self.matcher.match_patterns(query, context)
            
            if not matched_patterns:
                return AdvancedPipelineResult(
                    query=query,
                    matched_patterns=[],
                    combined_result=None,
                    execution_time_ms=(time.time() - start_time) * 1000,
                    success=False,
                    error="No patterns matched"
                )
            
            logger.info(f"[Step 2] Found {len(matched_patterns)} patterns:")
            for match in matched_patterns[:5]:  # 상위 5개만 로그
                logger.info(f"  - {match.pattern_id}: {match.confidence_score:.0%}")
            
            # Step 3: Generate Business Logic
            logger.info("[Step 2→3] Generating business logic...")
            generated_logic = self.generator.generate_multiple(matched_patterns)
            logger.info(f"[Step 3] Generated {len(generated_logic)} logic modules")
            
            # Step 4: Advanced Template Combination
            logger.info("[Step 3→4] Combining with advanced templates...")
            combined_result = self.combiner.combine(
                matched_patterns,
                generated_logic,
                query
            )
            
            logger.info(f"[Step 4] Template combination complete:")
            logger.info(f"  - Template: {combined_result.template_type}")
            logger.info(f"  - Strategy: {combined_result.combination_strategy.value}")
            logger.info(f"  - Code size: {len(combined_result.code)} characters")
            logger.info(f"  - Execution order: {' → '.join(combined_result.execution_order[:5])}")
            
            execution_time = (time.time() - start_time) * 1000
            logger.info(f"[Pipeline] Complete in {execution_time:.0f}ms")
            
            return AdvancedPipelineResult(
                query=query,
                matched_patterns=matched_patterns,
                combined_result=combined_result,
                execution_time_ms=execution_time,
                success=True,
                error=None
            )
            
        except Exception as e:
            logger.error(f"Pipeline error: {e}")
            return AdvancedPipelineResult(
                query=query,
                matched_patterns=[],
                combined_result=None,
                execution_time_ms=(time.time() - start_time) * 1000,
                success=False,
                error=str(e)
            )
    
    def generate_and_save(self, query: str, output_file: str) -> bool:
        """
        비즈니스 로직 생성 후 파일로 저장
        
        Args:
            query: 사용자 쿼리
            output_file: 출력 파일 경로
            
        Returns:
            성공 여부
        """
        result = self.process(query)
        
        if result.success and result.combined_result:
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    # 헤더 추가
                    f.write(f"#!/usr/bin/env python3\n")
                    f.write(f'"""\n')
                    f.write(f'Generated Business Logic\n')
                    f.write(f'Query: {query}\n')
                    f.write(f'Template: {result.combined_result.template_type}\n')
                    f.write(f'Strategy: {result.combined_result.combination_strategy.value}\n')
                    f.write(f'Generated at: {time.strftime("%Y-%m-%d %H:%M:%S")}\n')
                    f.write(f'"""\n\n')
                    
                    # 생성된 코드
                    f.write(result.combined_result.code)
                    
                    # 실행 가능한 메인 추가
                    f.write("\n\n")
                    f.write("if __name__ == '__main__':\n")
                    f.write("    import asyncio\n")
                    f.write("    import json\n")
                    f.write("    \n")
                    
                    # 템플릿별 실행 코드
                    if "Service" in result.combined_result.code:
                        f.write("    # Run microservice\n")
                        f.write("    service = BusinessLogicService()\n")
                        f.write("    asyncio.run(service.run())\n")
                    elif "EventProcessor" in result.combined_result.code:
                        f.write("    # Run event processor\n")
                        f.write("    processor = BusinessLogicEventProcessor()\n")
                        f.write("    test_data = {'event': 'test', 'data': {}}\n")
                        f.write("    asyncio.run(processor.process_event_chain('test', test_data))\n")
                    elif "BatchProcessor" in result.combined_result.code:
                        f.write("    # Run batch processor\n")
                        f.write("    processor = BusinessLogicBatchProcessor()\n")
                        f.write("    test_items = [{'id': i} for i in range(10)]\n")
                        f.write("    results = processor.process_batch(test_items)\n")
                        f.write("    print(json.dumps(results, indent=2))\n")
                    elif "StreamProcessor" in result.combined_result.code:
                        f.write("    # Run stream processor\n")
                        f.write("    processor = BusinessLogicStreamProcessor()\n")
                        f.write("    async def test_stream():\n")
                        f.write("        async def source():\n")
                        f.write("            for i in range(10):\n")
                        f.write("                yield {'id': i}\n")
                        f.write("        async for result in processor.run_stream(source()):\n")
                        f.write("            print(result)\n")
                        f.write("    asyncio.run(test_stream())\n")
                    else:
                        f.write("    # Run orchestrator\n")
                        f.write("    orchestrator = BusinessLogicOrchestrator()\n")
                        f.write("    test_input = {'data': 'test'}\n")
                        f.write("    result = asyncio.run(orchestrator.execute_workflow(test_input))\n")
                        f.write("    print(json.dumps(result, indent=2))\n")
                
                logger.info(f"Saved generated code to: {output_file}")
                return True
                
            except Exception as e:
                logger.error(f"Failed to save file: {e}")
                return False
        
        return False
    
    def analyze_query(self, query: str) -> Dict[str, Any]:
        """
        쿼리 분석 (디버깅용)
        
        Args:
            query: 사용자 쿼리
            
        Returns:
            분석 결과
        """
        # 패턴 매칭
        matches = self.matcher.match_patterns(query)
        
        # 복잡도 계산
        complexity = len(matches) * 0.1 + sum(m.confidence_score for m in matches) / len(matches) if matches else 0
        
        # 의존성 분석
        from ..template_combiner.dependency_manager import DependencyManager
        dep_manager = DependencyManager()
        pattern_ids = [m.pattern_id for m in matches]
        dep_graph = dep_manager.analyze(pattern_ids)
        
        # 템플릿 예측
        template_prediction = self.combiner._select_template(matches, None) if matches else "none"
        
        return {
            "query": query,
            "pattern_count": len(matches),
            "patterns": [{"id": m.pattern_id, "confidence": m.confidence_score} for m in matches[:10]],
            "complexity": complexity,
            "dependencies": dep_graph.edges,
            "execution_order": dep_graph.execution_order,
            "predicted_template": template_prediction
        }