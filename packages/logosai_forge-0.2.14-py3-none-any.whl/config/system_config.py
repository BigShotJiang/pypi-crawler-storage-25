"""
FORGE System Configuration
===========================
시스템 전체 설정 관리
"""

import os
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass
from loguru import logger


@dataclass
class SystemConfig:
    """시스템 설정"""
    
    # 생성기 선택
    USE_AST_GENERATOR: bool = False  # AST 생성기 비활성화 (성능 문제)
    USE_V2_GENERATOR: bool = True     # V2 생성기 활성화 (권장)
    USE_V3_GENERATOR: bool = False    # V3 생성기 (미구현)
    
    # 검증 설정
    ENABLE_LIGHTWEIGHT_VALIDATION: bool = True  # 경량 검증 활성화
    ENABLE_SELF_HEALING: bool = True           # 자가 수정 활성화
    ENABLE_PERFORMANCE_MONITORING: bool = True  # 성능 모니터링 활성화
    
    # 성능 임계값
    MAX_GENERATION_TIME_MS: int = 5000     # 최대 생성 시간 (5초)
    MAX_MEMORY_USAGE_MB: int = 500         # 최대 메모리 사용량
    MAX_CPU_USAGE_PERCENT: int = 80        # 최대 CPU 사용률
    
    # 검증 임계값
    VALIDATION_TIMEOUT_MS: int = 100       # 검증 타임아웃 (100ms)
    MIN_CONFIDENCE_SCORE: float = 0.7      # 최소 신뢰도
    MAX_AUTO_FIX_ATTEMPTS: int = 3         # 최대 자동 수정 시도
    
    # 로깅 설정
    LOG_LEVEL: str = "INFO"
    LOG_TO_FILE: bool = True
    LOG_FILE_PATH: str = "logs/forge_system.log"
    PERFORMANCE_LOG_PATH: str = "logs/performance"
    
    # 출력 설정
    OUTPUT_DIR: str = "generated"
    ENABLE_TEST_GENERATION: bool = True
    SAVE_METADATA: bool = True
    
    # 템플릿 설정
    TEMPLATE_DIR: str = "templates/functions"
    MAX_TEMPLATES_CACHE: int = 100
    
    # LLM 설정
    LLM_MODEL: str = "gpt-4o-mini"
    LLM_TEMPERATURE: float = 0.7
    LLM_MAX_TOKENS: int = 2000
    LLM_TIMEOUT: int = 30
    
    # 기능 플래그
    FEATURE_FLAGS: Dict[str, bool] = None
    
    def __post_init__(self):
        """초기화 후 처리"""
        if self.FEATURE_FLAGS is None:
            self.FEATURE_FLAGS = {
                "enhanced_samples": True,      # 향상된 샘플 생성
                "smart_templates": True,        # 스마트 템플릿 선택
                "parallel_generation": False,   # 병렬 생성 (실험적)
                "llm_caching": True,           # LLM 응답 캐싱
                "advanced_validation": True,    # 고급 검증
            }
        
        # 디렉토리 생성
        self._ensure_directories()
        
        # 환경 변수 오버라이드
        self._load_env_overrides()
    
    def _ensure_directories(self):
        """필요한 디렉토리 생성"""
        dirs = [
            self.OUTPUT_DIR,
            os.path.dirname(self.LOG_FILE_PATH),
            self.PERFORMANCE_LOG_PATH,
            self.TEMPLATE_DIR
        ]
        
        for dir_path in dirs:
            Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    def _load_env_overrides(self):
        """환경 변수로 설정 오버라이드"""
        # AST 생성기 활성화 (환경 변수로 강제)
        if os.getenv("FORGE_USE_AST", "false").lower() == "true":
            self.USE_AST_GENERATOR = True
            self.USE_V2_GENERATOR = False
            logger.warning("AST generator force-enabled via environment variable")
        
        # V2 생성기 비활성화
        if os.getenv("FORGE_DISABLE_V2", "false").lower() == "true":
            self.USE_V2_GENERATOR = False
            logger.warning("V2 generator disabled via environment variable")
        
        # 성능 모니터링
        if os.getenv("FORGE_DISABLE_MONITORING", "false").lower() == "true":
            self.ENABLE_PERFORMANCE_MONITORING = False
            logger.info("Performance monitoring disabled")
        
        # LLM 모델
        if model := os.getenv("FORGE_LLM_MODEL"):
            self.LLM_MODEL = model
            logger.info(f"Using LLM model: {model}")
    
    def get_active_generator(self) -> str:
        """활성 생성기 반환"""
        if self.USE_V2_GENERATOR:
            return "V2"
        elif self.USE_AST_GENERATOR:
            return "AST"
        elif self.USE_V3_GENERATOR:
            return "V3"
        else:
            return "None"
    
    def validate(self) -> bool:
        """설정 유효성 검증"""
        # 적어도 하나의 생성기는 활성화되어야 함
        if not any([self.USE_AST_GENERATOR, self.USE_V2_GENERATOR, self.USE_V3_GENERATOR]):
            logger.error("No generator enabled!")
            return False
        
        # 동시에 여러 생성기 활성화 경고
        enabled_count = sum([self.USE_AST_GENERATOR, self.USE_V2_GENERATOR, self.USE_V3_GENERATOR])
        if enabled_count > 1:
            logger.warning(f"{enabled_count} generators enabled simultaneously - may cause conflicts")
        
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환"""
        return {
            key: getattr(self, key)
            for key in dir(self)
            if not key.startswith('_') and not callable(getattr(self, key))
        }
    
    def log_config(self):
        """현재 설정 로깅"""
        logger.info("=" * 50)
        logger.info("FORGE System Configuration")
        logger.info("=" * 50)
        logger.info(f"Active Generator: {self.get_active_generator()}")
        logger.info(f"Validation: {'Enabled' if self.ENABLE_LIGHTWEIGHT_VALIDATION else 'Disabled'}")
        logger.info(f"Self-Healing: {'Enabled' if self.ENABLE_SELF_HEALING else 'Disabled'}")
        logger.info(f"Monitoring: {'Enabled' if self.ENABLE_PERFORMANCE_MONITORING else 'Disabled'}")
        logger.info(f"LLM Model: {self.LLM_MODEL}")
        logger.info("=" * 50)


# 싱글톤 설정 인스턴스
_config_instance: Optional[SystemConfig] = None

def get_config() -> SystemConfig:
    """싱글톤 설정 인스턴스 반환"""
    global _config_instance
    if _config_instance is None:
        _config_instance = SystemConfig()
        _config_instance.validate()
        _config_instance.log_config()
    return _config_instance


def override_config(**kwargs) -> SystemConfig:
    """설정 오버라이드"""
    config = get_config()
    for key, value in kwargs.items():
        if hasattr(config, key):
            setattr(config, key, value)
            logger.info(f"Config override: {key} = {value}")
        else:
            logger.warning(f"Unknown config key: {key}")
    return config


# 사용 예제
if __name__ == "__main__":
    # 기본 설정 가져오기
    config = get_config()
    print(f"Active Generator: {config.get_active_generator()}")
    print(f"AST Enabled: {config.USE_AST_GENERATOR}")
    print(f"V2 Enabled: {config.USE_V2_GENERATOR}")
    
    # 설정 오버라이드 테스트
    override_config(
        LLM_MODEL="gpt-4",
        MAX_GENERATION_TIME_MS=10000
    )
    
    # 설정 딕셔너리 출력
    import json
    print("\nFull Configuration:")
    print(json.dumps(config.to_dict(), indent=2, default=str))