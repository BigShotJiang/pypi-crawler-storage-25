# Configuration module initialization

import os
import yaml
from pathlib import Path
from typing import Dict, Any

_CONFIG_CACHE: Dict[str, Any] = {}

DEFAULTS = {
    "pipeline": {"max_retries": 2, "validation_timeout": 5},
    "strategy": {"slice_threshold_high": 0.7, "slice_threshold_low": 0.4, "default_strategy": "llm"},
    "improve": {"size_small": 5000, "size_large": 15000, "llm_timeout_base": 20,
                 "llm_timeout_per_5kb": 5, "max_custom_methods": 5, "custom_method_timeout": 3},
    "circuit_breaker": {"failure_threshold": 3, "cooldown_seconds": 3600, "extended_cooldown_seconds": 7200},
    "confidence": {"auto_deploy": 0.95, "approval_queue": 0.50, "auto_rollback": 0.50},
    "llm": {"model": "gemini-2.5-flash-lite", "temperature": 0.1, "max_tokens": 4000},
}


def get_config(section: str = None) -> Dict[str, Any]:
    """Load agentic pipeline config (YAML + env overrides, cached)."""
    global _CONFIG_CACHE
    if not _CONFIG_CACHE:
        config_path = Path(__file__).parent / "agentic_pipeline.yaml"
        cfg = dict(DEFAULTS)
        if config_path.exists():
            try:
                with open(config_path) as f:
                    user_cfg = yaml.safe_load(f) or {}
                for sec, values in user_cfg.items():
                    if sec in cfg and isinstance(values, dict):
                        cfg[sec].update(values)
                    else:
                        cfg[sec] = values
            except Exception:
                pass
        _CONFIG_CACHE = cfg

    if section:
        return dict(_CONFIG_CACHE.get(section, {}))
    return dict(_CONFIG_CACHE)


def get_value(section: str, key: str, default=None):
    """Get a single config value with env var override (FORGE_{SECTION}_{KEY})."""
    env_key = f"FORGE_{section.upper()}_{key.upper()}"
    env_val = os.environ.get(env_key)
    if env_val is not None:
        # Try to cast to same type as default
        if isinstance(default, int):
            return int(env_val)
        if isinstance(default, float):
            return float(env_val)
        return env_val
    cfg = get_config(section)
    return cfg.get(key, default)