"""
logosai-forge — AI Agent Generation Library

"Agents Building Agents" — 15 agentic AI agents collaborate to generate,
improve, enhance, and self-evolve agent code autonomously.

Usage:
    from logosai_forge import ForgeClient

    forge = ForgeClient()
    result = await forge.create_agent("Calculate BMI from weight and height")
    print(result.code)

Three capabilities:
    create_agent()  — Generate a new agent from natural language query
    improve_agent() — Fix bugs in existing agent code from failure feedback
    enhance_agent() — Add missing logic/functions to existing agent code
"""

__version__ = "0.2.14"

from logosai_forge.client import ForgeClient, ForgeResult

__all__ = ["ForgeClient", "ForgeResult"]
