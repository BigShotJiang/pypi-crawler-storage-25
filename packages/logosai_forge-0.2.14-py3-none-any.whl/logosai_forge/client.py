"""
ForgeClient — Public API for FORGE V6 agent generation.

Simple interface wrapping ForgeV6System internally.
No server needed — runs locally via pip install.

Usage:
    forge = ForgeClient()

    # Create new agent
    result = await forge.create_agent("Calculate BMI", test_cases=[...])

    # Fix broken agent
    result = await forge.improve_agent(code, {"error_type": "logic_error", ...})

    # Add missing functions
    result = await forge.enhance_agent(code, "add multiply and divide methods")
"""

import asyncio
import os
import sys
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from pathlib import Path


@dataclass
class ForgeResult:
    """Result from any FORGE operation."""
    success: bool
    code: str = ""
    agent_name: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    # Enhancement/Improvement-specific
    added_functions: List[str] = field(default_factory=list)
    diff: str = ""
    changes: List[str] = field(default_factory=list)
    confidence: float = 0.0
    test_cases: List[Dict] = field(default_factory=list)  # Verification test cases for ACP
    scope: str = ""  # "function_level" | "full_rewrite"


class ForgeClient:
    """Public API for FORGE V6 — generates, improves, and enhances AI agents.

    Works locally — no server needed. Just `pip install logosai-forge`.

    Args:
        forge_root: Path to forge directory (auto-detected if installed via pip)
    """

    def __init__(self, forge_root: str = None):
        self._system = None
        self._forge_root = forge_root

        # Auto-detect forge root
        if not self._forge_root:
            # Check if running from forge directory
            candidates = [
                Path(__file__).parent.parent,  # logosai_forge/../ (when inside forge/)
                Path.cwd(),
                Path.cwd().parent,
            ]
            for c in candidates:
                if (c / "core" / "agentic" / "forge_v6_system.py").exists():
                    self._forge_root = str(c)
                    break

        if self._forge_root:
            # Ensure forge is importable
            if self._forge_root not in sys.path:
                sys.path.insert(0, self._forge_root)

        # Set required env vars
        os.environ.setdefault("GRPC_DNS_RESOLVER", "native")

    def _get_system(self):
        """Lazy-load ForgeV6System."""
        if self._system is None:
            from core.agentic.forge_v6_system import ForgeV6System
            self._system = ForgeV6System()
        return self._system

    async def create_agent(
        self,
        query: str,
        agent_name: str = None,
        test_cases: List[Dict] = None,
        business_rules: List[str] = None,
    ) -> ForgeResult:
        """Generate a new agent from natural language query.

        Args:
            query: What the agent should do (e.g., "Calculate BMI from weight and height")
            agent_name: Optional name for the agent
            test_cases: Optional test cases [{input: {}, expected: {}}]
            business_rules: Optional business rules ["rule1", "rule2"]

        Returns:
            ForgeResult with generated agent code

        Example:
            result = await forge.create_agent(
                "Calculate BMI. BMI = weight/(height^2). <18.5 underweight, 18.5-25 normal",
                test_cases=[{"input": {"weight": 70, "height": 1.75}, "expected": {"bmi": 22.9}}]
            )
            print(result.code)
        """
        system = self._get_system()
        try:
            v6_result = await system.create_agent(
                query=query,
                agent_name=agent_name,
                test_cases=test_cases,
                business_rules=business_rules,
            )

            meta = v6_result.metadata or {}
            return ForgeResult(
                success=v6_result.success,
                code=v6_result.agent_code or "",
                agent_name=meta.get("agent_name", agent_name or "GeneratedAgent"),
                metadata=meta,
                error=v6_result.error,
                confidence=meta.get("quality_score", meta.get("analysis", {}).get("confidence", 0)),
            )
        except Exception as e:
            import logging
            logging.getLogger("logosai_forge").error(f"create_agent error: {e}")
            return ForgeResult(success=False, error=str(e))

    async def improve_agent(
        self,
        agent_code: str,
        failure_log: Dict[str, Any],
        dry_run: bool = False,
    ) -> ForgeResult:
        """Fix bugs in existing agent code based on failure feedback.

        Args:
            agent_code: Current agent source code
            failure_log: Failure context {
                "error_type": "logic_error" | "runtime_error" | "syntax_error",
                "error_message": str,
                "test_input": Dict,
                "expected_output": Dict,
                "actual_output": Dict,
            }
            dry_run: If True, return improvement plan without modifying code

        Returns:
            ForgeResult with improved code and diff (or plan if dry_run)
        """
        system = self._get_system()
        v6_result = await system.improve_agent(agent_code, failure_log, dry_run=dry_run)

        meta = v6_result.metadata or {}
        improvement = meta.get("improvement", {})

        # Generate test cases from failure_log for ACP shadow execution
        test_cases = []
        if failure_log.get("test_input") and failure_log.get("expected_output"):
            test_cases.append({
                "input": failure_log["test_input"],
                "expected": failure_log["expected_output"],
                "type": "regression",  # Ensure the original failure is fixed
            })
        # Add error case if available
        if failure_log.get("error_message"):
            test_cases.append({
                "input": "",
                "expected_type": "error",
                "description": f"Edge case for: {failure_log['error_message'][:50]}",
            })

        return ForgeResult(
            success=v6_result.success,
            code=v6_result.agent_code or agent_code,
            metadata=meta,
            diff=improvement.get("diff", ""),
            changes=improvement.get("changes", []),
            confidence=improvement.get("confidence", 0),
            test_cases=test_cases,
            scope=improvement.get("scope", ""),
        )

    async def enhance_agent(
        self,
        agent_code: str,
        enhancement_request: str,
        test_cases: List[Dict] = None,
    ) -> ForgeResult:
        """Add missing logic/functions to existing agent code.

        Args:
            agent_code: Current agent source code
            enhancement_request: What to add (e.g., "add multiply and divide methods")
            test_cases: Optional test cases for validation

        Returns:
            ForgeResult with enhanced code, added functions, and diff

        Example:
            result = await forge.enhance_agent(calc_code, "add multiply and divide")
            print(result.added_functions)  # ['_multiply', '_divide']
            print(result.diff)
        """
        system = self._get_system()
        v6_result = await system.enhance_agent(agent_code, enhancement_request, test_cases)

        meta = v6_result.metadata or {}
        enhancement = meta.get("enhancement", {})
        return ForgeResult(
            success=v6_result.success,
            code=v6_result.agent_code or agent_code,
            metadata=meta,
            added_functions=enhancement.get("added_functions", []),
            diff=enhancement.get("diff", ""),
            changes=enhancement.get("changes", []),
            confidence=enhancement.get("confidence", 0),
        )
