
# Getting Started with Calendar API

## Introduction

Manipulates events and other calendar data. Provides access to Google Calendar for creating, listing, patching, and deleting events, querying free/busy information, and setting up push notifications for event changes.

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install google-calendar-apimatic-sdk==1.0.3
```

You can also view the package at:
https://pypi.python.org/pypi/google-calendar-apimatic-sdk/1.0.3

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 30** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](doc/logging-configuration.md) | The SDK logging configuration for API calls |
| authorization_code_auth_credentials | [`AuthorizationCodeAuthCredentials`](__base_path/auth/oauth-2-authorization-code-grant.md) | The credential object for OAuth 2 Authorization Code Grant |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
import logging

from calendarapi.calendarapi_client import CalendarapiClient
from calendarapi.configuration import Environment
from calendarapi.http.auth.oauth_2 import AuthorizationCodeAuthCredentials
from calendarapi.logging.configuration.api_logging_configuration import LoggingConfiguration
from calendarapi.logging.configuration.api_logging_configuration import RequestLoggingConfiguration
from calendarapi.logging.configuration.api_logging_configuration import ResponseLoggingConfiguration
from calendarapi.models.oauth_scope import OauthScope

client = CalendarapiClient(
    authorization_code_auth_credentials=AuthorizationCodeAuthCredentials(
        oauth_client_id='OAuthClientId',
        oauth_client_secret='OAuthClientSecret',
        oauth_redirect_uri='OAuthRedirectUri',
        oauth_scopes=[
            OauthScope.HTTPS_WWW_GOOGLEAPIS_COM_AUTH_CALENDAR_READONLY,
            OauthScope.HTTPS_WWW_GOOGLEAPIS_COM_AUTH_CALENDAR_EVENTS
        ]
    ),
    environment=Environment.PRODUCTION,
    logging_configuration=LoggingConfiguration(
        log_level=logging.INFO,
        request_logging_config=RequestLoggingConfiguration(
            log_body=True
        ),
        response_logging_config=ResponseLoggingConfiguration(
            log_headers=True
        )
    )
)
```

### Environment-Based Client Initialization

```python
from calendarapi.calendarapi_client import CalendarapiClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = CalendarapiClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** Google Calendar API v3 |

## Authorization

This API uses the following authentication schemes.

* [`oauth2 (OAuth 2 Authorization Code Grant)`](__base_path/auth/oauth-2-authorization-code-grant.md)

## List of APIs

* [Calendar List](doc/controllers/calendar-list.md)
* [Events](doc/controllers/events.md)
* [Free Busy](doc/controllers/free-busy.md)
* [Channels](doc/controllers/channels.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](doc/proxy-settings.md)
* [Environment-Based Client Initialization](doc/environment-based-client-initialization.md)
* [AbstractLogger](doc/abstract-logger.md)
* [LoggingConfiguration](doc/logging-configuration.md)
* [RequestLoggingConfiguration](doc/request-logging-configuration.md)
* [ResponseLoggingConfiguration](doc/response-logging-configuration.md)

### HTTP

* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

### Utilities

* [ApiResponse](doc/api-response.md)
* [ApiHelper](doc/api-helper.md)
* [HttpDateTime](doc/http-date-time.md)
* [RFC3339DateTime](doc/rfc3339-date-time.md)
* [UnixDateTime](doc/unix-date-time.md)

