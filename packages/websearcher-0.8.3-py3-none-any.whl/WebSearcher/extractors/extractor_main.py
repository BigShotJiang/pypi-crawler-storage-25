from typing import Any

import bs4

from .. import utils
from ..logger import Logger

log = Logger().start(__name__)


class ExtractorMain:
    def __init__(self, soup: bs4.BeautifulSoup, components):
        self.soup = soup
        self.components = components

        # copied from Extractor.__init__
        self.layout_divs = {
            "rso": None,
            "top-bars": None,
            "left-bar": None,
        }
        self.layouts = {
            "top-bars": False,
            "left-bar": False,
            "standard": False,
            "no-rso": False,
        }
        self.layout_label = None
        self.layout_extractors = {
            "standard": self.extract_from_standard,
            "top-bars": self.extract_from_top_bar,
            "left-bar": self.extract_from_left_bar,
            "no-rso": self.extract_from_no_rso,
        }

    def extract(self):
        self.get_layout()
        self._ads_top_carousel()
        self._ads_top()
        self._ads_bottom()
        self._main_column()
        log.debug(f"main_components: {self.components.cmpt_rank_counter:,}")

    def get_layout(self):
        """Divide and label the page layout"""

        # Layout soup subsets
        layout_divs: dict[str, Any] = {}
        layout_divs["rso"] = self.soup.find("div", {"id": "rso"})
        layout_divs["left-bar"] = self.soup.find("div", {"class": "OeVqAd"})

        rcnt = self.soup.find("div", {"id": "rcnt"})
        layout_divs["top-bars"] = utils.find_all_divs(rcnt, "div", {"class": ["XqFnDf", "M8OgIe"]})

        # Layout classifications
        layouts = {}
        layouts["top-bars"] = bool(layout_divs["top-bars"])
        layouts["left-bar"] = bool(layout_divs["left-bar"])
        layouts["standard"] = (
            bool(layout_divs["rso"]) & (not layouts["top-bars"]) & (not layouts["left-bar"])
        )
        layouts["no-rso"] = not bool(layout_divs["rso"])

        if layouts["top-bars"] and bool(layout_divs["rso"]) and not layouts["left-bar"]:
            layout_label = "standard"
        else:
            # Get layout label
            label_matches = [k for k, v in layouts.items() if v]
            layout_label = label_matches[0] if label_matches else None

        # Set layout details
        log.debug(f"main_layout: {layout_label}")
        self.layout_label = layout_label
        self.layouts.update(layouts)
        self.layout_divs.update(layout_divs)

    def _ads_top_carousel(self):
        """Extract sponsored carousel ads (e.g. Sponsored hotels via atvcap)"""
        ads = self.soup.find("div", {"id": "atvcap"})
        if ads and utils.get_text(ads):
            ads.extract()
            self.components.add_component(ads, section="main", type="shopping_ads")

    def _ads_top(self):
        ads = self.soup.find("div", {"id": "tads"})
        if ads and utils.get_text(ads):
            ads.extract()
            self.components.add_component(ads, section="main", type="ad")

    def _main_column(self, drop_tags: set = set()):
        if not drop_tags:
            drop_tags = {"script", "style", None}
        if self.layout_label is None:
            raise ValueError("no layout_label set")
        try:
            extractor = self.layout_extractors[self.layout_label]
        except KeyError:
            raise ValueError(f"no extractor for layout_label: {self.layout_label}")

        column = extractor(drop_tags)
        column = utils.filter_empty_divs(column)
        for c in column:
            if ExtractorMain.is_valid(c):
                self.components.add_component(c, section="main")

    def _ads_bottom(self):
        ads = self.soup.find("div", {"id": "tadsb"})
        if ads and utils.get_text(ads):
            ads.extract()
            self.components.add_component(ads, section="main", type="ad")

    def extract_from_standard(self, drop_tags: set = set()) -> list:

        rso_div = self.layout_divs["rso"]
        if rso_div is None:
            return []
        standard_layouts = {
            "standard-0": (
                rso_div.find("div", {"id": "kp-wp-tab-overview"}),
                "div",
                [{"class": "TzHB6b"}, {"class": "A6K0A"}],
            ),
            "standard-1": (
                rso_div.find("div", {"id": "kp-wp-tab-cont-Songs", "role": "tabpanel"}),
                None,
                None,
            ),
            "standard-2": (
                rso_div.find("div", {"id": "kp-wp-tab-SportsStandings"}),
                None,
                None,
            ),
            "standard-4": (
                rso_div.find("div", {"id": "kp-wp-tab-AIRFARES"}),
                "div",
                [{"class": "A6K0A"}],
            ),
        }
        for layout_name, (
            layout_div,
            check_tag,
            check_attrs_list,
        ) in standard_layouts.items():
            if layout_div:
                if check_tag:
                    for check_attrs in (
                        check_attrs_list
                        if isinstance(check_attrs_list, list)
                        else [check_attrs_list]
                    ):
                        if layout_div.find_all(check_tag, check_attrs):
                            return self._extract_from_standard_sub_type(layout_name)
                elif layout_div.find_all("div"):
                    return self._extract_from_standard_sub_type(layout_name)

        top_divs = (
            ExtractorMain.extract_top_divs(
                self.layout_divs["top-bars"], rso=self.layout_divs["rso"]
            )
            or []
        )
        col = ExtractorMain.extract_children(rso_div, drop_tags)
        col = top_divs + col
        col = [c for c in col if ExtractorMain.is_valid(c)]
        if not col:
            self.layout_label = "standard-3"
            log.debug(f"main_layout: {self.layout_label} (update)")
            divs = rso_div.find_all("div", {"id": "kp-wp-tab-overview"})
            col = sum([d.find_all("div", {"class": "TzHB6b"}) for d in divs], [])
            if not col:
                col = sum(
                    [d.find_all("div", {"class": "A6K0A"}, recursive=False) for d in divs],
                    [],
                )
        return col

    def _extract_from_standard_sub_type(self, sub_type: str = "") -> list:

        self.layout_label = sub_type
        rso_div = self.layout_divs["rso"]
        if rso_div is None:
            return []
        log.debug(f"main_layout: {self.layout_label} (update)")

        if self.layout_label == "standard-0":
            column = []
            top_divs = (
                ExtractorMain.extract_top_divs(
                    self.layout_divs["top-bars"], rso=self.layout_divs["rso"]
                )
                or []
            )
            tab_overview = rso_div.find("div", {"id": "kp-wp-tab-overview"})
            main_divs = (
                tab_overview.find_all("div", {"class": "TzHB6b"}, recursive=False)
                if tab_overview
                else []
            )
            if not main_divs and tab_overview:
                main_divs = tab_overview.find_all("div", {"class": "A6K0A"}, recursive=False)
            column.extend(top_divs)
            column.extend(main_divs)
            log.debug(f"main_components: {len(column):,}")
            return column

        if self.layout_label == "standard-1":
            column = []
            top_divs = (
                ExtractorMain.extract_top_divs(
                    self.layout_divs["top-bars"], rso=self.layout_divs["rso"]
                )
                or []
            )
            songs_div = rso_div.find("div", {"id": "kp-wp-tab-Songs"})
            main_divs = list(songs_div.children) if songs_div else []
            column.extend(top_divs)
            column.extend(main_divs)
            column = [div for div in column if div.name not in {"script", "style"}]
            column = utils.filter_empty_divs(column)
            return column

        if self.layout_label == "standard-2":
            column = []
            top_divs = (
                ExtractorMain.extract_top_divs(
                    self.layout_divs["top-bars"], rso=self.layout_divs["rso"]
                )
                or []
            )
            sports_div = rso_div.find("div", {"id": "kp-wp-tab-SportsStandings"})
            main_divs = list(sports_div.children) if sports_div else []
            column.extend(top_divs)
            column.extend(main_divs)
            column = [div for div in column if div.name not in {"script", "style"}]
            column = utils.filter_empty_divs(column)
            return column

        if self.layout_label == "standard-4":
            column = []
            top_divs = (
                ExtractorMain.extract_top_divs(
                    self.layout_divs["top-bars"], rso=self.layout_divs["rso"]
                )
                or []
            )
            tab_airfares = rso_div.find("div", {"id": "kp-wp-tab-AIRFARES"})
            main_divs = (
                tab_airfares.find_all("div", {"class": "A6K0A"}, recursive=False)
                if tab_airfares
                else []
            )
            column.extend(top_divs)
            column.extend(main_divs)
            return column

        return []

    def extract_from_top_bar(self, drop_tags: set = set()) -> list:
        out = []
        tops = ExtractorMain.extract_top_divs(
            self.layout_divs["top-bars"], rso=self.layout_divs["rso"]
        )
        out.extend(tops)

        div_classes = [
            "cUnQKe",  # people also ask
            "g",  # general
            "Lv2Cle",  # images-medium
            "oIk2Cb",  # searches_related
            "Ww4FFb",  # discussions_and_forums
            "vtSz8d",  # videos
            "uVMCKf",  # videos
        ]

        rso_div = self.layout_divs["rso"]
        rso_divs = rso_div.find_all("div", attrs={"class": div_classes}) if rso_div else []
        if rso_divs:
            self.layout_label = "top-bars-divs"
            col = [div for div in rso_divs if div.name not in drop_tags]
        else:
            self.layout_label = "top-bars-children"
            col = ExtractorMain.extract_children(self.layout_divs["rso"], drop_tags)
        log.debug(f"main_layout: {self.layout_label} (update)")
        out.extend(col)
        return out

    @staticmethod
    def extract_top_divs(soup, drop_tags: set = set(), rso=None) -> list:
        out = []
        for tb in soup:
            if utils.check_dict_value(tb.attrs, "class", ["M8OgIe"]):
                kd = utils.find_all_divs(tb, "div", {"jscontroller": ["qTdDb", "OWrb3e"]})
                if kd:
                    out.extend(kd)
                else:
                    # Extract non-ad children (tvcap/tads handled by _ads_top)
                    for ch in tb.children:
                        if not hasattr(ch, "name") or not ch.name:
                            continue
                        if ch.find("div", {"id": "tvcap"}) or ch.find("div", {"id": "tads"}):
                            continue
                        if ch.name == "h1":
                            continue
                        out.append(ch)
            elif ExtractorMain.is_dictionary_header(tb, rso):
                continue  # Skip dictionary word header (content is in definitions component)
            else:
                out.append(tb)
        return out

    @staticmethod
    def is_dictionary_header(elem, rso=None) -> bool:
        """Check if element is a dictionary word header that duplicates an inline
        definitions component in the rso column.

        kp-wholepage-osrp is the wrapper class for many entity panels (movies,
        people, athletes, finance, streaming, dictionaries) — not just dictionary
        headers. Only skip it when the rso column also has a DictionaryHeader
        component, which is the duplication signal.
        """
        if not elem.find("div", {"class": "kp-wholepage-osrp"}):
            return False
        if rso is None:
            return False
        if rso.find("div", {"data-attrid": "DictionaryHeader"}):
            return True
        return any(
            b.get_text(strip=True) == "Dictionary" for b in rso.find_all("div", {"role": "button"})
        )

    def extract_from_left_bar(self, drop_tags: set = set()) -> list:
        return self.soup.find_all("div", {"class": "TzHB6b"})

    def extract_from_no_rso(self, drop_tags: set = set()) -> list:
        out: list[Any] = []
        sec1 = self.soup.find_all("div", {"class": "UDZeY OTFaAf"})
        for div in sec1:
            h2 = div.find("h2")
            if h2 is not None and h2.text == "Twitter Results":
                inner_div = div.find("div")
                if inner_div is not None:
                    out.append(inner_div.parent)
            elif (sec_header := div.find("g-section-with-header")) is not None:
                out.append(sec_header.parent)
            elif div.find("g-more-link"):
                out.append(div)
            elif div.find("div", {"class": "oIk2Cb"}):
                out.append(div)
            else:
                out.extend(div.find_all("div", {"class": "g"}))
            sec2 = self.soup.find("div", {"class": "WvKfwe a3spGf"})
            if sec2:
                out.extend(sec2.children)
        return [c for c in out if c is not None and c.name not in drop_tags]

    @staticmethod
    def extract_children(soup, drop_tags: set = set()) -> list:
        cts = []
        for ch in soup.children:
            if ch.name in drop_tags:
                continue
            if not ch.attrs:
                cts.extend(ch.contents)
            else:
                cts.append(ch)
        return cts

    @staticmethod
    def is_valid(c) -> bool:
        if not c:
            return False
        bad = {"Main results", "Twitter Results", ""}
        # Bound the text scan: the longest bad label is 15 chars, so once the
        # accumulated text exceeds that it cannot match and we stop walking.
        text = ""
        for s in c.strings:
            text += s
            if len(text) > 15:
                break
        if text in bad:
            return False
        # Skip bottom ads wrapper (extracted separately)
        if c.find("div", {"id": "tadsb"}):
            return False
        # hidden survey: drop components that wrap a promo-throttler in a ULSxyf
        # container. (Was guarded by `"attrs" in c`, which tested child membership
        # rather than attribute presence, so this branch never fired.)
        if (
            hasattr(c, "attrs")
            and utils.check_dict_value(c.attrs, "class", ["ULSxyf"])
            and c.find("promo-throttler")
        ):
            return False
        return True
