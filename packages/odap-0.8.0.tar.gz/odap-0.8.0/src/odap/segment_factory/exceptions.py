class SegmentNotFoundException(Exception):
    pass
