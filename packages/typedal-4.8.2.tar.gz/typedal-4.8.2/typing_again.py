from typedal import TypeDAL, TypedTable, TypedField, relationship, Relationship

from typing import reveal_type

db = TypeDAL()

reveal_type(db)

@db.define
class OtherTable(TypedTable):
    ...

@db.define
class MyTable(TypedTable):
    field = TypedField(str)

    rel = relationship(OtherTable)
    multiple = relationship(list[OtherTable])


row = MyTable.first_or_fail()

reveal_type(row) # expected: MyTable; pycharm: MyTable
reveal_type(MyTable.field) # expected: TypedField[str]; pycharm: TypedField[str]
reveal_type(row.field) # expected: str; pycharm: TypedField[str]

q = MyTable.field.belongs([""])

reveal_type(q) # expected: Query; pycharm: Query

reveal_type(MyTable.rel) # expected: Relationship[OtherTable]; pycharm: Relationship[OtherTable | None]
reveal_type(row.rel)  # expected: OtherTable | None; pycharm: Relationship[OtherTable | None]

reveal_type(MyTable.multiple) # expected: Relationship[list[OtherTable]]; pycharm: Relationship[list[OtherTable]]
reveal_type(row.multiple)  # expected: list[OtherTable]; pycharm: Relationship[list[OtherTable]]
