import pm4py
import polars as pl
from pm4py.algo.filtering.dfg import dfg_filtering
from pm4py.visualization.dfg import visualizer as dfg_vis
from pm4py.algo.discovery.dfg import algorithm as dfg_discovery


def print_stats(pdf):
    cols = {
        "mortality": "case:mortality",
        "diagnosis count": "case:diagnosis_count",
        "duration": "case:duration",
    }

    print(f"{'Metric':.<20} | {'Mean':>15} | {'Median':>15}")
    print("-" * 56)

    for label, col in cols.items():
        mean_val = pdf[col].mean()

        med_val = pdf[col].median()

        if "duration" in label:

            def format_td(td):
                # Calculate total days
                total_days = td.total_seconds() / 86400
                years = int(total_days // 365.25)
                days = int(total_days % 365.25)
                return f"{years}y {days}d"

            m_str = format_td(mean_val)
            md_str = format_td(med_val)
            print(f"{label: <20} | {m_str:>15} | {md_str:>15}")

        else:
            print(f"{label: <20} | {mean_val:>15.2f} | {med_val:>15.2f}")

    count = pdf["case:PNR"].nunique()
    print("-" * 56)
    print(f"{'Unique cases':.<20} : {count}")


def view(
    df,
    view_count,
    case_id_key="case:PNR",
    activity_key="TDiag",
    timestamp_key="startTime",
    **kwargs,
):
    pdf = df.to_pandas()
    pdf["case:concept:name"] = pdf[case_id_key]
    pdf["concept:name"] = pdf[activity_key]
    pdf["time:timestamp"] = pdf[timestamp_key]
    print_stats(pdf)
    if view_count:
        view_count(pdf, **kwargs)
    else:
        view_time(pdf, **kwargs)


def view_count(
    pdf,
    path_filter=0.25,
):
    dfg, sa, ea = pm4py.discover_dfg(pdf)

    activities_count = pm4py.get_event_attribute_values(pdf, "concept:name")

    dfg, sa, ea, activities_count = dfg_filtering.filter_dfg_on_paths_percentage(
        dfg, sa, ea, activities_count, path_filter
    )

    dfg_vis.view(dfg_vis.apply(dfg))


def view_time(pdf, path_filter=0.25):
    _, sa, ea = pm4py.discover_dfg(
        pdf,
    )
    activities_count = pm4py.get_event_attribute_values(pdf, attribute="concept:name")

    dfg_freq = dfg_discovery.apply(pdf, variant=dfg_discovery.Variants.FREQUENCY)
    dfg_perf = dfg_discovery.apply(pdf, variant=dfg_discovery.Variants.PERFORMANCE)

    # 3. Filter based on frequency (keep top 25% of paths)
    dfg_freq_filt, sa, ea, activities_count = (
        dfg_filtering.filter_dfg_on_paths_percentage(
            dfg_freq, sa, ea, activities_count, path_filter
        )
    )

    # 4. Align the Performance DFG to only include paths kept in the Frequency DFG
    dfg_perf_filt = {k: v for k, v in dfg_perf.items() if k in dfg_freq_filt}
    # 5. Visualize the filtered Performance map
    gviz = dfg_vis.apply(
        dfg_perf_filt,
        variant=dfg_vis.Variants.PERFORMANCE,
        parameters={"aggregationMeasure": "median"},
    )
    dfg_vis.view(gviz)


def view_starts(df, view_count=True, **kwargs):
    for x in ["CANCER", "CARDIO", "MUSCU"]:
        print(f"{'-' * 20} {x} {'-' * 20}")
        df_tmp = df.filter(pl.col("TDiag").str.starts_with(x).first().over("case:PNR"))
        view(df_tmp, view_count, **kwargs)
