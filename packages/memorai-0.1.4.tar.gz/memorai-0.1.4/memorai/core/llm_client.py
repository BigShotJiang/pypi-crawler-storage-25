"""
Simplified LLM Client - Single API key with retry and rate limiting
"""

import time
import random
import threading
import logging
from typing import Optional, List, Dict, Any

import warnings
with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    import google.generativeai as genai
from openai import OpenAI
from groq import Groq

from .config import settings


logger = logging.getLogger(__name__)


class LLMClient:
    """
    LLM Client with retry logic and rate limiting
    
    Supports:
    - OpenAI / OpenRouter
    - Google AI Studio (Gemini)
    - Groq
    
    Uses single API key from environment variables.
    Thread-safe for concurrent usage.
    """

    RATE_LIMIT_INDICATORS = [
        "429",
        "too many requests",
        "rate limit",
        "quota exceeded",
        "resource_exhausted",
        "daily limit",
        "daily quota",
    ]
    _client_pool: Dict[str, Any] = {}
    _pool_lock = threading.Lock()
    _google_configured_keys = set()

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        rpm_limit: Optional[int] = None,
        timeout: Optional[int] = None,
    ):
        """
        Initialize LLM Client

        Args:
            api_key: API key
            base_url: Base URL
            model: Model name
            provider: 'openai', 'google', or 'groq'
            rpm_limit: Requests per minute limit
            timeout: Request timeout in seconds
        """
        self.api_key = api_key or settings.llm_api_key
        self.base_url = base_url or settings.llm_base_url
        self.model = model or settings.llm_model
        raw_provider = provider or settings.llm_provider
        provider_norm = (raw_provider or "openai").strip().lower()
        if provider_norm in {"google", "gemini"}:
            provider_norm = "google"
        self.provider = provider_norm
        self.rpm_limit = settings.rpm_limit if rpm_limit is None else rpm_limit
        self.timeout = timeout or settings.timeout

        # Rate limiting
        # rpm_limit <= 0 means disabled throttling.
        self.min_interval = 0.0 if self.rpm_limit <= 0 else 60.0 / self.rpm_limit
        self._last_call_ts = 0.0
        self._call_lock = threading.Lock()

        self.client = self._get_or_create_client()

    def _get_or_create_client(self):
        """Get a shared provider client to avoid repeated connection setup."""
        if self.provider == "google":
            config_key = f"google:{self.api_key}"
            model_key = f"google-model:{self.api_key}:{self.model}"
            with self.__class__._pool_lock:
                if config_key not in self.__class__._google_configured_keys:
                    genai.configure(api_key=self.api_key)
                    self.__class__._google_configured_keys.add(config_key)

                client = self.__class__._client_pool.get(model_key)
                if client is None:
                    client = genai.GenerativeModel(self.model)
                    self.__class__._client_pool[model_key] = client
                return client

        if self.provider == "groq":
            pool_key = f"groq:{self.api_key}"
            with self.__class__._pool_lock:
                client = self.__class__._client_pool.get(pool_key)
                if client is None:
                    client = Groq(api_key=self.api_key)
                    self.__class__._client_pool[pool_key] = client
                return client

        pool_key = f"openai:{self.api_key}:{self.base_url}:{self.timeout}"
        with self.__class__._pool_lock:
            client = self.__class__._client_pool.get(pool_key)
            if client is None:
                client = OpenAI(
                    api_key=self.api_key,
                    base_url=self.base_url,
                    timeout=self.timeout,
                )
                self.__class__._client_pool[pool_key] = client
            return client

    def _respect_rate(self) -> None:
        """Ensure rate limit is respected (thread-safe)"""
        if self.min_interval <= 0:
            return
        with self._call_lock:
            now = time.time()
            delta = now - self._last_call_ts
            if delta < self.min_interval:
                sleep_time = self.min_interval - delta + random.uniform(0, 0.05)
                time.sleep(sleep_time)
            self._last_call_ts = time.time()

    def _is_rate_limit_error(self, error_str: str) -> bool:
        """Check if error is related to rate limiting"""
        error_lower = error_str.lower()
        return any(indicator in error_lower for indicator in self.RATE_LIMIT_INDICATORS)

    def _normalize_content(self, content: Any) -> str:
        """Normalize provider-specific content payloads into plain text."""
        if content is None:
            return ""
        if isinstance(content, str):
            return content.strip()
        if isinstance(content, list):
            parts: List[str] = []
            for item in content:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict):
                    text_val = item.get("text") or item.get("content") or ""
                    parts.append(str(text_val))
                else:
                    parts.append(str(item))
            return " ".join(p for p in parts if p).strip()
        return str(content).strip()

    def _extract_chat_text(self, response: Any) -> str:
        choices = getattr(response, "choices", None)
        if not choices:
            return ""
        first = choices[0]
        message = getattr(first, "message", None)
        if message is None and isinstance(first, dict):
            message = first.get("message")

        content = None
        if message is not None:
            content = getattr(message, "content", None)
            if content is None and isinstance(message, dict):
                content = message.get("content")
        return self._normalize_content(content)

    def call(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.1,
        max_retries: int = 5,
        backoff_base: float = 2.0,
    ) -> str:
        """
        Call LLM with retry logic
        """
        messages = []
        if self.provider in ["openai", "groq"]:
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
        else:
            # Google style
            full_prompt = prompt
            if system_prompt:
                full_prompt = f"System: {system_prompt}\n\nUser: {prompt}"

        last_error = None

        for attempt in range(max_retries):
            try:
                self._respect_rate()

                if self.provider == "google":
                    generation_config = genai.types.GenerationConfig(
                        temperature=temperature
                    )
                    response = self.client.generate_content(
                        full_prompt, generation_config=generation_config
                    )
                    text = self._normalize_content(getattr(response, "text", None))
                    if not text:
                        raise ValueError("LLM returned empty response content")
                    return text
                elif self.provider == "groq":
                    response = self.client.chat.completions.create(
                        model=self.model,
                        messages=messages,
                        temperature=temperature,
                        max_tokens=2048, # Groq needs max_tokens often
                    )
                    text = self._extract_chat_text(response)
                    if not text:
                        raise ValueError("LLM returned empty response content")
                    return text
                else:
                    response = self.client.chat.completions.create(
                        model=self.model,
                        messages=messages,
                        temperature=temperature,
                    )
                    text = self._extract_chat_text(response)
                    if not text:
                        raise ValueError("LLM returned empty response content")
                    return text

            except Exception as e:
                last_error = e
                error_str = str(e)

                # Calculate backoff
                if self._is_rate_limit_error(error_str):
                    sleep_time = (backoff_base ** (attempt + 2)) + random.uniform(0, 1)
                else:
                    sleep_time = (backoff_base ** attempt) + random.uniform(0, 0.5)

                if attempt < max_retries - 1:
                    logger.warning(
                        "LLM call failed (attempt %s/%s): %s",
                        attempt + 1,
                        max_retries,
                        error_str[:100],
                    )
                    logger.info("Retrying in %.1fs...", sleep_time)
                    time.sleep(sleep_time)

        raise RuntimeError(
            f"LLM call failed after {max_retries} retries. Last error: {last_error}"
        )

    def chat(
        self,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_retries: int = 5,
        backoff_base: float = 2.0,
    ) -> str:
        """
        Multi-turn chat (OpenAI / Groq). For Google provider, messages are flattened
        into a single prompt (no native multi-turn in current integration).
        """
        if not messages:
            raise ValueError("messages must be non-empty")

        chat_started_ts = time.perf_counter()
        last_error = None
        for attempt in range(max_retries):
            try:
                self._respect_rate()
                attempt_started_ts = time.perf_counter()

                if self.provider == "google":
                    parts = []
                    for m in messages:
                        role = m.get("role", "user")
                        parts.append(f"{role}: {m.get('content', '')}")
                    full_prompt = "\n\n".join(parts)
                    answer = self.call(
                        full_prompt, system_prompt=None, temperature=temperature, max_retries=1
                    )
                    logger.info(
                        "LLM chat success provider=%s model=%s attempt=%d/%d duration=%.3fs total=%.3fs",
                        self.provider,
                        self.model,
                        attempt + 1,
                        max_retries,
                        time.perf_counter() - attempt_started_ts,
                        time.perf_counter() - chat_started_ts,
                    )
                    return answer

                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                )
                answer = self._extract_chat_text(response)
                if not answer:
                    raise ValueError("LLM returned empty response content")
                logger.info(
                    "LLM chat success provider=%s model=%s attempt=%d/%d duration=%.3fs total=%.3fs",
                    self.provider,
                    self.model,
                    attempt + 1,
                    max_retries,
                    time.perf_counter() - attempt_started_ts,
                    time.perf_counter() - chat_started_ts,
                )
                return answer

            except Exception as e:
                last_error = e
                error_str = str(e)
                sleep_time = (backoff_base**attempt) + random.uniform(0, 0.5)
                if self._is_rate_limit_error(error_str):
                    sleep_time = (backoff_base ** (attempt + 2)) + random.uniform(0, 1)
                if attempt < max_retries - 1:
                    logger.warning(
                        "LLM chat failed (attempt %s/%s): %s",
                        attempt + 1,
                        max_retries,
                        error_str[:100],
                    )
                    logger.info("LLM chat retrying in %.1fs", sleep_time)
                    time.sleep(sleep_time)

        raise RuntimeError(
            f"LLM chat failed after {max_retries} retries. Last error: {last_error}"
        )

    def call_batch(
        self,
        prompts: List[str],
        system_prompt: Optional[str] = None,
        temperature: float = 0.1,
        max_retries: int = 5,
    ) -> List[str]:
        """Call LLM for multiple prompts sequentially"""
        results = []
        for prompt in prompts:
            result = self.call(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=temperature,
                max_retries=max_retries,
            )
            results.append(result)
        return results

