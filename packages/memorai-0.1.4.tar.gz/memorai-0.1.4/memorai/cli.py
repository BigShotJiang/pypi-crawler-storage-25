#!/usr/bin/env python3
"""
MemOrai CLI - Unified command-line interface for the pipeline
"""

import argparse
import sys

from .core import settings, EmbeddingGenerator
from .processors import (
    Segmenter,
    Filter,
    TripletExtractor,
    EntityDescriptor,
    Summarizer,
    GraphBuilder,
    SegmentChunkMapper,
    TurnConsolidator,
    GraphRebuilder,
    TimestampEmbedder,
)
from .exporters import MappingExporter, OutputConsolidator


def cmd_segment(args):
    """Run segmentation"""
    settings.validate()

    segmenter = Segmenter(max_workers=args.max_workers)

    if args.input_json:
        segmenter.run_from_json(
            input_json=args.input_json,
            output_dir=args.output_dir,
            skip_existing=args.skip_existing,
        )
    else:
        segmenter.run(
            input_dir=args.input_dir,
            output_dir=args.output_dir,
            skip_existing=args.skip_existing,
        )


def cmd_filter(args):
    """Run filtering"""
    settings.validate()

    filter_proc = Filter(max_workers=args.max_workers)
    filter_proc.run(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        skip_existing=args.skip_existing,
    )


def cmd_triplets(args):
    """Run triplet extraction"""
    settings.validate()

    embedder = None
    if args.save_embeddings:
        embedder = EmbeddingGenerator()

    extractor = TripletExtractor(
        embedding_generator=embedder,
        max_workers=args.max_workers,
    )
    extractor.run(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        file_pattern="*_filtered.json",
        skip_existing=args.skip_existing,
    )


def cmd_entities(args):
    """Run entity description generation"""
    settings.validate()

    embedder = None
    if args.save_embeddings:
        embedder = EmbeddingGenerator()

    descriptor = EntityDescriptor(
        embedding_generator=embedder,
        max_workers=args.max_workers,
    )
    descriptor.run(
        triplet_dir=args.triplet_dir,
        filtered_dir=args.filtered_dir,
        output_dir=args.output_dir,
        skip_existing=args.skip_existing,
    )


def cmd_summarize(args):
    """Run summarization"""
    settings.validate()

    embedder = None
    if args.save_embeddings:
        embedder = EmbeddingGenerator()

    summarizer = Summarizer(
        embedding_generator=embedder,
        max_workers=args.max_workers,
    )
    summarizer.run(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        skip_existing=args.skip_existing,
    )


def cmd_graph(args):
    """Run graph building"""
    builder = GraphBuilder()
    builder.run(
        triplet_dir=args.triplet_dir,
        output_dir=args.output_dir,
        output_name=args.output_name,
        formats=args.formats,
        skip_existing=args.skip_existing,
    )


def cmd_mappings(args):
    """Export mappings"""
    exporter = MappingExporter()
    exporter.run(
        segmented_dir=args.segmented_dir,
        filtered_dir=args.filtered_dir,
        summaries_dir=args.summaries_dir,
        output_dir=args.output_dir,
    )


def cmd_consolidate(args):
    """Consolidate outputs"""
    consolidator = OutputConsolidator()
    consolidator.run(
        output_dir=args.output_dir,
        segmented_dir=args.segmented_dir,
        filtered_dir=args.filtered_dir,
        summaries_dir=args.summaries_dir,
        entity_desc_dir=args.entity_desc_dir,
        triplets_dir=args.triplets_dir,
        graphs_dir=args.graphs_dir,
        mappings_dir=args.mappings_dir,
        skip_existing=args.skip_existing,
    )


# =============================================================================
# POST-PROCESSING COMMANDS
# =============================================================================


def cmd_segment_chunk_map(args):
    """Export segment to chunk mapping"""
    mapper = SegmentChunkMapper()
    mapper.run(
        segmented_dir=args.segmented_dir,
        output_dir=args.output_dir,
        verbose=True,
    )


def cmd_consolidate_turns(args):
    """Consolidate duplicate turn IDs"""
    consolidator = TurnConsolidator(max_workers=args.max_workers)
    consolidator.run(
        base_dir=args.base_dir,
        dry_run=args.dry_run,
    )


def cmd_rebuild_graph(args):
    """Rebuild graphs after turn ID consolidation"""
    rebuilder = GraphRebuilder(max_workers=args.max_workers)
    rebuilder.run(
        base_dir=args.base_dir,
        output_format=args.format,
        output_name=args.output_name,
    )


def cmd_embed_turns(args):
    """Add embeddings for turns"""
    embedder = TimestampEmbedder(
        embedding_model=args.embedding_model,
        batch_size=args.batch_size,
    )
    embedder.embed_turns(base_dir=args.base_dir)


def cmd_embed_entities(args):
    """Add embeddings with timestamp for entity descriptions"""
    embedder = TimestampEmbedder(
        embedding_model=args.embedding_model,
        batch_size=args.batch_size,
    )
    embedder.embed_entities(
        entity_dir=args.entity_dir,
        segmented_dir=args.segmented_dir,
    )


def cmd_embed_triplets(args):
    """Add embeddings with timestamp for triplets"""
    embedder = TimestampEmbedder(
        embedding_model=args.embedding_model,
        batch_size=args.batch_size,
    )
    embedder.embed_triplets(
        triplet_dir=args.triplet_dir,
        segmented_dir=args.segmented_dir,
    )


def cmd_embed_summaries(args):
    """Add embeddings for summaries"""
    embedder = TimestampEmbedder(
        embedding_model=args.embedding_model,
        batch_size=args.batch_size,
    )
    embedder.embed_summaries(summary_dir=args.summary_dir)


# =============================================================================
# RETRIEVAL & QA COMMANDS
# =============================================================================


def cmd_retrieve(args):
    """Run KG retrieval for a query"""
    import json

    from .retriever import KGRetriever

    retriever = KGRetriever(
        data_path=args.data_path,
        embedding_model=args.embedding_model,
        num_hops=args.num_hops,
        top_k_node=args.top_k_node,
        top_k_triplet=args.top_k_triplet,
        top_k_return=args.top_k_return,
        ppr_alpha=args.ppr_alpha,
        verbose=args.verbose,
    )

    result = retriever.retrieve(args.query)

    # Print results
    print("\n" + "=" * 60)
    print("RETRIEVAL RESULTS")
    print("=" * 60)

    for node_type in ["turn", "segment", "entity"]:
        nodes = result["results"].get(node_type, [])
        if nodes:
            print(f"\n{node_type.upper()} ({len(nodes)}):")
            for node_id, score in nodes[:5]:
                print(f"  {node_id}: {score:.4f}")

    print(f"\nTriplets: {len(result['triplets'])}")
    print(
        f"Subgraph: {result['subgraph_info']['num_nodes']} nodes, "
        f"{result['subgraph_info']['num_edges']} edges"
    )

    # Save to file if specified
    if args.output:
        # Convert tuples to lists for JSON
        output_data = {
            "query": args.query,
            "results": {
                k: [[n, s] for n, s in v] for k, v in result["results"].items()
            },
            "triplets": result["triplets"],
            "subgraph_info": result["subgraph_info"],
        }
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        print(f"\n✓ Saved to: {args.output}")


def cmd_qa(args):
    """Run QA pipeline: retrieve + generate answer"""
    import json

    from .retriever import KGRetriever
    from .generator import AnswerGenerator

    print("=" * 60)
    print("QA PIPELINE")
    print("=" * 60)
    print(f"Query: {args.query}")
    print(f"Data: {args.data_path}")
    print("=" * 60)

    # Initialize retriever
    print("\n[1/3] Initializing retriever...")
    retriever = KGRetriever(
        data_path=args.data_path,
        embedding_model=args.embedding_model,
        num_hops=args.num_hops,
        top_k_node=args.top_k_node,
        top_k_triplet=args.top_k_triplet,
        top_k_return=args.top_k_return,
        ppr_alpha=args.ppr_alpha,
        verbose=args.verbose,
    )

    # Retrieve
    print("\n[2/3] Retrieving relevant information...")
    retrieval_result = retriever.retrieve(args.query)

    turns = retrieval_result["results"].get("turn", [])
    print(f"  Found {len(turns)} relevant turns")

    # Generate answer
    print("\n[3/3] Generating answer...")
    generator = AnswerGenerator()
    result = generator.generate_from_retrieval(
        question=args.query,
        retrieval_result=retrieval_result,
        triplet_df=retriever.triplet_df,
        turn_df=retriever.turn_df,
    )

    # Print answer
    print("\n" + "=" * 60)
    print("ANSWER")
    print("=" * 60)
    print(result["answer"])
    print("=" * 60)
    print(f"Turns used: {result['num_turns']}")
    print(f"Triplets used: {result['num_triplets']}")

    # Save to file if specified
    if args.output:
        output_data = {
            "query": args.query,
            "answer": result["answer"],
            "context": result["context"],
            "retrieval": {
                "turns": [[n, s] for n, s in turns],
                "num_triplets": result["num_triplets"],
            },
        }
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        print(f"\n✓ Saved to: {args.output}")


def cmd_qa_batch(args):
    """Run QA pipeline on batch of questions"""
    import json

    from .retriever import KGRetriever
    from .generator import AnswerGenerator

    # Load questions
    with open(args.questions_file, "r", encoding="utf-8") as f:
        questions_data = json.load(f)

    if isinstance(questions_data, list):
        questions = questions_data
    elif isinstance(questions_data, dict) and "questions" in questions_data:
        questions = questions_data["questions"]
    else:
        raise ValueError("Invalid questions file format")

    print("=" * 60)
    print("BATCH QA PIPELINE")
    print("=" * 60)
    print(f"Questions: {len(questions)}")
    print(f"Data: {args.data_path}")
    print("=" * 60)

    # Initialize
    retriever = KGRetriever(
        data_path=args.data_path,
        embedding_model=args.embedding_model,
        num_hops=args.num_hops,
        top_k_node=args.top_k_node,
        top_k_triplet=args.top_k_triplet,
        top_k_return=args.top_k_return,
        ppr_alpha=args.ppr_alpha,
        verbose=False,
    )
    generator = AnswerGenerator()

    results = []

    for i, question in enumerate(questions, 1):
        print(f"\n[{i}/{len(questions)}] {question[:60]}...")

        try:
            # Retrieve
            retrieval_result = retriever.retrieve(question)

            # Generate
            result = generator.generate_from_retrieval(
                question=question,
                retrieval_result=retrieval_result,
                triplet_df=retriever.triplet_df,
                turn_df=retriever.turn_df,
            )

            results.append(
                {
                    "question": question,
                    "answer": result["answer"],
                    "num_turns": result["num_turns"],
                    "num_triplets": result["num_triplets"],
                    "success": True,
                }
            )
            print(f"  ✓ Answer: {result['answer'][:80]}...")

        except Exception as e:
            results.append(
                {
                    "question": question,
                    "answer": None,
                    "error": str(e),
                    "success": False,
                }
            )
            print(f"  ✗ Error: {e}")

        # Save incrementally
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "total": len(questions),
                    "completed": len(results),
                    "results": results,
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

    print("\n" + "=" * 60)
    success = sum(1 for r in results if r["success"])
    print(f"✓ Completed: {success}/{len(questions)} questions")
    print(f"✓ Saved to: {args.output}")
    print("=" * 60)


def cmd_pipeline(args):
    """Run full pipeline including post-processing"""
    import glob
    import os
    import time

    settings.validate()

    output_dir = args.output_dir
    graph_db = f"{output_dir}/graph_db"
    embedding_model = getattr(args, "embedding_model", settings.embedding_model)

    print("=" * 60)
    print("MEMORAI FULL PIPELINE")
    print("=" * 60)
    print(f"Input: {args.input_json}")
    print(f"Output: {output_dir}")
    print(f"Embedding: {embedding_model}")
    print("=" * 60)

    pipeline_start = time.perf_counter()
    timings = {}

    def _run_step(step_key: str, fn):
        step_start = time.perf_counter()
        fn()
        timings[step_key] = time.perf_counter() - step_start

    def _print_timing_summary() -> None:
        if not getattr(args, "profile_timings", False):
            return
        total = time.perf_counter() - pipeline_start
        print("\n" + "=" * 60)
        print("PIPELINE TIMINGS")
        print("=" * 60)
        for step_key, elapsed in timings.items():
            print(f"{step_key}: {elapsed:.2f}s")
        print(f"TOTAL: {total:.2f}s")
        print("=" * 60)

    embedder = EmbeddingGenerator(model_name=embedding_model) if args.save_embeddings else None

    # =========================================================================
    # PHASE 1: MAIN PIPELINE
    # =========================================================================
    print("\n" + "=" * 60)
    print("PHASE 1: MAIN PIPELINE")
    print("=" * 60)

    # Step 1: Segment
    print("\n[1/6] Segmentation...")
    segmenter = Segmenter(max_workers=args.max_workers)
    _run_step(
        "phase1.1.segmentation",
        lambda: segmenter.run_from_json(
            input_json=args.input_json,
            output_dir=f"{output_dir}/segmented",
            skip_existing=args.skip_existing,
            update=getattr(args, "update", False),
        ),
    )

    # Step 2: Filter
    print("\n[2/6] Filtering...")
    filter_proc = Filter(max_workers=args.max_workers)
    _run_step(
        "phase1.2.filtering",
        lambda: filter_proc.run(
            input_dir=f"{output_dir}/segmented",
            output_dir=f"{output_dir}/filtered",
            skip_existing=args.skip_existing,
            update=getattr(args, "update", False),
        ),
    )

    # Step 3: Triplets
    print("\n[3/6] Triplet Extraction...")
    extractor = TripletExtractor(
        embedding_generator=embedder,
        max_workers=args.max_workers,
    )
    _run_step(
        "phase1.3.triplets",
        lambda: extractor.run(
            input_dir=f"{output_dir}/filtered",
            output_dir=f"{output_dir}/triplets",
            file_pattern="*_filtered.json",
            skip_existing=args.skip_existing,
            update=getattr(args, "update", False),
        ),
    )

    # Step 4: Entity Descriptions
    print("\n[4/6] Entity Descriptions...")
    descriptor = EntityDescriptor(
        embedding_generator=embedder,
        max_workers=args.max_workers,
    )
    _run_step(
        "phase1.4.entities",
        lambda: descriptor.run(
            triplet_dir=f"{output_dir}/triplets",
            filtered_dir=f"{output_dir}/filtered",
            output_dir=f"{output_dir}/entities",
            skip_existing=args.skip_existing,
            update=getattr(args, "update", False),
        ),
    )

    # Step 5: Summaries
    print("\n[5/6] Summarization...")
    summarizer = Summarizer(
        embedding_generator=embedder,
        max_workers=args.max_workers,
    )
    _run_step(
        "phase1.5.summaries",
        lambda: summarizer.run(
            input_dir=f"{output_dir}/segmented",
            output_dir=f"{output_dir}/summaries",
            skip_existing=args.skip_existing,
            update=getattr(args, "update", False),
        ),
    )

    # Step 6: Graphs
    print("\n[6/6] Graph Building...")
    graph_builder = GraphBuilder()
    _run_step(
        "phase1.6.graph",
        lambda: graph_builder.run(
            triplet_dir=f"{output_dir}/triplets",
            output_dir=f"{output_dir}/graphs",
            formats=args.formats if hasattr(args, "formats") else ["graphml"],
            skip_existing=args.skip_existing and not getattr(args, "update", False),
        ),
    )

    if getattr(args, "fast_mode", False):
        print("\n" + "=" * 60)
        print("FAST MODE: SKIP POST-PROCESSING")
        print("=" * 60)
        print("✓ Completed phase 1 only for low-latency indexing.")
        print("Tip: run full pipeline periodically to refresh graph_db artifacts.")
        print("\n" + "=" * 60)
        print("✓ PIPELINE COMPLETED (FAST MODE)!")
        print("=" * 60)
        print(f"Output: {output_dir}")
        _print_timing_summary()
        return

    # =========================================================================
    # PHASE 2: POST-PROCESSING
    # =========================================================================
    print("\n" + "=" * 60)
    print("PHASE 2: POST-PROCESSING")
    print("=" * 60)

    # Step 7: Export mappings
    print("\n[7/13] Exporting mappings...")
    from .exporters import MappingExporter

    exporter = MappingExporter()
    _run_step(
        "phase2.7.mappings",
        lambda: exporter.run(
            segmented_dir=f"{output_dir}/segmented",
            filtered_dir=f"{output_dir}/filtered",
            summaries_dir=f"{output_dir}/summaries",
            output_dir=f"{output_dir}/mappings",
        ),
    )

    # Step 8: Consolidate outputs
    print("\n[8/13] Consolidating outputs...")
    from .exporters import OutputConsolidator

    consolidator = OutputConsolidator()
    _run_step(
        "phase2.8.consolidate",
        lambda: consolidator.run(
            output_dir=graph_db,
            segmented_dir=f"{output_dir}/segmented",
            filtered_dir=f"{output_dir}/filtered",
            summaries_dir=f"{output_dir}/summaries",
            entity_desc_dir=f"{output_dir}/entities",
            triplets_dir=f"{output_dir}/triplets",
            graphs_dir=f"{output_dir}/graphs",
            mappings_dir=f"{output_dir}/mappings",
            skip_existing=False,
        ),
    )

    # Step 9: Segment → chunk mapping
    print("\n[9/13] Exporting segment → chunk mapping...")
    seg_chunk_mapper = SegmentChunkMapper()
    _run_step(
        "phase2.9.segment_chunk",
        lambda: seg_chunk_mapper.run(
            segmented_dir=f"{output_dir}/segmented",
            output_dir=graph_db,
            verbose=True,
        ),
    )

    # Step 10: Consolidate turn IDs
    print("\n[10/13] Consolidating turn IDs...")
    turn_consolidator = TurnConsolidator(max_workers=args.max_workers)
    _run_step(
        "phase2.10.turn_consolidate",
        lambda: turn_consolidator.run(base_dir=graph_db, dry_run=False),
    )

    # Step 11: Rebuild graphs
    print("\n[11/13] Rebuilding graphs...")
    graph_rebuilder = GraphRebuilder(max_workers=args.max_workers)
    _run_step(
        "phase2.11.rebuild_graph",
        lambda: graph_rebuilder.run(
            base_dir=graph_db,
            output_format="graphml",
            output_name="knowledge_graph",
        ),
    )

    # Step 12: Embed turns
    print("\n[12/13] Embedding turns...")
    ts_embedder = TimestampEmbedder(
        embedding_model=embedding_model,
        batch_size=64,
    )
    _run_step("phase2.12.embed_turns", lambda: ts_embedder.embed_turns(base_dir=graph_db))

    # Step 13: Embed entities/triplets/summaries with timestamp
    print("\n[13/13] Embedding entities/triplets/summaries...")
    _run_step(
        "phase2.13.embed_all",
        lambda: (
            ts_embedder.embed_entities(
                entity_dir=f"{output_dir}/entities",
                segmented_dir=f"{output_dir}/segmented",
            ),
            ts_embedder.embed_triplets(
                triplet_dir=f"{output_dir}/triplets",
                segmented_dir=f"{output_dir}/segmented",
            ),
            ts_embedder.embed_summaries(summary_dir=f"{output_dir}/summaries"),
        ),
    )

    # =========================================================================
    # PHASE 3: CLEANUP
    # =========================================================================
    if args.cleanup:
        print("\n" + "=" * 60)
        print("PHASE 3: CLEANUP")
        print("=" * 60)

        # Remove *_old* files
        def _cleanup_old_files():
            old_files = glob.glob(f"{graph_db}/**/*_old*", recursive=True)
            for f in old_files:
                if os.path.isfile(f):
                    os.remove(f)
            print(f"✓ Removed {len(old_files)} backup files")

        _run_step("phase3.cleanup", _cleanup_old_files)

    # =========================================================================
    # DONE
    # =========================================================================
    print("\n" + "=" * 60)
    print("✓ FULL PIPELINE COMPLETED!")
    print("=" * 60)
    print(f"Output: {output_dir}")
    print(f"Graph DB: {graph_db}")
    print("=" * 60)
    _print_timing_summary()


def main():
    parser = argparse.ArgumentParser(
        prog="memorai",
        description="MemOrai - Conversational Memory Knowledge Graph Builder",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Common arguments
    def add_common_args(p):
        p.add_argument(
            "--max_workers",
            type=int,
            default=settings.max_workers,
            help="Max parallel workers",
        )
        p.add_argument(
            "--skip_existing", action="store_true", help="Skip if output exists"
        )

    # Segment command
    p_segment = subparsers.add_parser("segment", help="Segment conversations")
    p_segment.add_argument("--input_json", help="Input JSON file")
    p_segment.add_argument("--input_dir", help="Input directory")
    p_segment.add_argument("--output_dir", required=True, help="Output directory")
    add_common_args(p_segment)
    p_segment.set_defaults(func=cmd_segment)

    # Filter command
    p_filter = subparsers.add_parser("filter", help="Filter messages")
    p_filter.add_argument("--input_dir", required=True, help="Segmented directory")
    p_filter.add_argument("--output_dir", required=True, help="Output directory")
    add_common_args(p_filter)
    p_filter.set_defaults(func=cmd_filter)

    # Triplets command
    p_triplets = subparsers.add_parser("triplets", help="Extract triplets")
    p_triplets.add_argument("--input_dir", required=True, help="Filtered directory")
    p_triplets.add_argument("--output_dir", required=True, help="Output directory")
    p_triplets.add_argument(
        "--save_embeddings", action="store_true", help="Save embeddings"
    )
    add_common_args(p_triplets)
    p_triplets.set_defaults(func=cmd_triplets)

    # Entities command
    p_entities = subparsers.add_parser("entities", help="Generate entity descriptions")
    p_entities.add_argument("--triplet_dir", required=True, help="Triplet directory")
    p_entities.add_argument("--filtered_dir", required=True, help="Filtered directory")
    p_entities.add_argument("--output_dir", required=True, help="Output directory")
    p_entities.add_argument(
        "--save_embeddings", action="store_true", help="Save embeddings"
    )
    add_common_args(p_entities)
    p_entities.set_defaults(func=cmd_entities)

    # Summarize command
    p_summarize = subparsers.add_parser("summarize", help="Summarize segments")
    p_summarize.add_argument("--input_dir", required=True, help="Segmented directory")
    p_summarize.add_argument("--output_dir", required=True, help="Output directory")
    p_summarize.add_argument(
        "--save_embeddings", action="store_true", help="Save embeddings"
    )
    add_common_args(p_summarize)
    p_summarize.set_defaults(func=cmd_summarize)

    # Graph command
    p_graph = subparsers.add_parser("graph", help="Build knowledge graphs")
    p_graph.add_argument("--triplet_dir", required=True, help="Triplet directory")
    p_graph.add_argument("--output_dir", required=True, help="Output directory")
    p_graph.add_argument(
        "--output_name", default="knowledge_graph", help="Output file base name"
    )
    p_graph.add_argument(
        "--formats",
        nargs="+",
        default=["graphml"],
        choices=["graphml", "pickle", "json"],
        help="Output formats",
    )
    p_graph.add_argument("--skip_existing", action="store_true")
    p_graph.set_defaults(func=cmd_graph)

    # Mappings command
    p_mappings = subparsers.add_parser("mappings", help="Export ID mappings")
    p_mappings.add_argument("--segmented_dir", help="Segmented directory")
    p_mappings.add_argument("--filtered_dir", help="Filtered directory")
    p_mappings.add_argument("--summaries_dir", help="Summaries directory")
    p_mappings.add_argument("--output_dir", required=True, help="Output directory")
    p_mappings.set_defaults(func=cmd_mappings)

    # Consolidate command
    p_consolidate = subparsers.add_parser("consolidate", help="Consolidate outputs")
    p_consolidate.add_argument("--segmented_dir", help="Segmented directory")
    p_consolidate.add_argument("--filtered_dir", help="Filtered directory")
    p_consolidate.add_argument("--summaries_dir", help="Summaries directory")
    p_consolidate.add_argument(
        "--entity_desc_dir", help="Entity descriptions directory"
    )
    p_consolidate.add_argument("--triplets_dir", help="Triplets directory")
    p_consolidate.add_argument("--graphs_dir", help="Graphs directory")
    p_consolidate.add_argument("--mappings_dir", help="Mappings directory")
    p_consolidate.add_argument("--output_dir", required=True, help="Output directory")
    p_consolidate.add_argument("--skip_existing", action="store_true")
    p_consolidate.set_defaults(func=cmd_consolidate)

    # =========================================================================
    # POST-PROCESSING COMMANDS
    # =========================================================================

    # Segment to chunk mapping
    p_seg_chunk = subparsers.add_parser(
        "segment-chunk-map", help="Export segment → chunk mapping"
    )
    p_seg_chunk.add_argument(
        "--segmented_dir", required=True, help="Segmented directory"
    )
    p_seg_chunk.add_argument("--output_dir", required=True, help="Output directory")
    p_seg_chunk.set_defaults(func=cmd_segment_chunk_map)

    # Consolidate turn IDs
    p_cons_turns = subparsers.add_parser(
        "consolidate-turns", help="Consolidate duplicate turn IDs"
    )
    p_cons_turns.add_argument(
        "--base_dir", required=True, help="Base directory (graph_db output)"
    )
    p_cons_turns.add_argument(
        "--dry_run", action="store_true", help="Show changes without applying"
    )
    add_common_args(p_cons_turns)
    p_cons_turns.set_defaults(func=cmd_consolidate_turns)

    # Rebuild graphs
    p_rebuild = subparsers.add_parser(
        "rebuild-graph", help="Rebuild graphs after turn ID consolidation"
    )
    p_rebuild.add_argument(
        "--base_dir", required=True, help="Base directory (graph_db output)"
    )
    p_rebuild.add_argument(
        "--format",
        default="graphml",
        choices=["graphml", "pickle", "json"],
        help="Graph format",
    )
    p_rebuild.add_argument(
        "--output_name", default="knowledge_graph", help="Output file base name"
    )
    add_common_args(p_rebuild)
    p_rebuild.set_defaults(func=cmd_rebuild_graph)

    # Embed turns
    p_embed_turns = subparsers.add_parser(
        "embed-turns", help="Add embeddings for turns"
    )
    p_embed_turns.add_argument(
        "--base_dir", required=True, help="Base directory (graph_db output)"
    )
    p_embed_turns.add_argument(
        "--embedding_model",
        default=settings.embedding_model,
        help="Embedding model name",
    )
    p_embed_turns.add_argument("--batch_size", type=int, default=64, help="Batch size")
    p_embed_turns.set_defaults(func=cmd_embed_turns)

    # Embed entities with timestamp
    p_embed_entities = subparsers.add_parser(
        "embed-entities", help="Add embeddings with timestamp for entities"
    )
    p_embed_entities.add_argument(
        "--entity_dir", required=True, help="Entity descriptions directory"
    )
    p_embed_entities.add_argument(
        "--segmented_dir", required=True, help="Segmented directory (for timestamps)"
    )
    p_embed_entities.add_argument(
        "--embedding_model",
        default=settings.embedding_model,
        help="Embedding model name",
    )
    p_embed_entities.add_argument(
        "--batch_size", type=int, default=64, help="Batch size"
    )
    p_embed_entities.set_defaults(func=cmd_embed_entities)

    # Embed triplets with timestamp
    p_embed_triplets = subparsers.add_parser(
        "embed-triplets", help="Add embeddings with timestamp for triplets"
    )
    p_embed_triplets.add_argument(
        "--triplet_dir", required=True, help="Triplets directory"
    )
    p_embed_triplets.add_argument(
        "--segmented_dir", required=True, help="Segmented directory (for timestamps)"
    )
    p_embed_triplets.add_argument(
        "--embedding_model",
        default=settings.embedding_model,
        help="Embedding model name",
    )
    p_embed_triplets.add_argument(
        "--batch_size", type=int, default=64, help="Batch size"
    )
    p_embed_triplets.set_defaults(func=cmd_embed_triplets)

    # Embed summaries
    p_embed_summaries = subparsers.add_parser(
        "embed-summaries", help="Add embeddings for summaries"
    )
    p_embed_summaries.add_argument(
        "--summary_dir", required=True, help="Summaries directory"
    )
    p_embed_summaries.add_argument(
        "--embedding_model",
        default=settings.embedding_model,
        help="Embedding model name",
    )
    p_embed_summaries.add_argument(
        "--batch_size", type=int, default=64, help="Batch size"
    )
    p_embed_summaries.set_defaults(func=cmd_embed_summaries)

    # Pipeline command (run all)
    p_pipeline = subparsers.add_parser(
        "pipeline", help="Run full pipeline (main + post-processing)"
    )
    p_pipeline.add_argument("--input_json", required=True, help="Input JSON file")
    p_pipeline.add_argument("--output_dir", required=True, help="Output directory")
    p_pipeline.add_argument(
        "--save_embeddings", action="store_true", help="Save embeddings"
    )
    p_pipeline.add_argument(
        "--embedding_model",
        default=settings.embedding_model,
        help="Embedding model for post-processing",
    )
    p_pipeline.add_argument(
        "--cleanup",
        action="store_true",
        help="Remove *_old* backup files after completion",
    )
    p_pipeline.add_argument(
        "--update",
        action="store_true",
        help="Run incremental update mode when supported by processors",
    )
    p_pipeline.add_argument(
        "--fast_mode",
        "--fast-mode",
        dest="fast_mode",
        action="store_true",
        help="Run phase 1 only (skip post-processing) for low-latency indexing",
    )
    p_pipeline.add_argument(
        "--profile_timings",
        "--profile-timings",
        dest="profile_timings",
        action="store_true",
        help="Print elapsed time per pipeline step",
    )
    add_common_args(p_pipeline)
    p_pipeline.set_defaults(func=cmd_pipeline)

    # =========================================================================
    # RETRIEVAL & QA COMMANDS
    # =========================================================================

    # Retrieve command
    p_retrieve = subparsers.add_parser("retrieve", help="Retrieve from knowledge graph")
    p_retrieve.add_argument("--query", required=True, help="Query string")
    p_retrieve.add_argument(
        "--data_path", required=True, help="Path to graph_db directory"
    )
    p_retrieve.add_argument(
        "--embedding_model",
        default="facebook/contriever",
        help="Embedding model",
    )
    p_retrieve.add_argument("--num_hops", type=int, default=1, help="Subgraph hops")
    p_retrieve.add_argument("--top_k_node", type=int, default=10, help="Top-k nodes")
    p_retrieve.add_argument(
        "--top_k_triplet", type=int, default=10, help="Top-k triplets"
    )
    p_retrieve.add_argument("--top_k_return", type=int, default=10, help="Top-k return")
    p_retrieve.add_argument("--ppr_alpha", type=float, default=0.15, help="PPR alpha")
    p_retrieve.add_argument("--output", help="Output JSON file")
    p_retrieve.add_argument("--verbose", action="store_true", help="Verbose output")
    p_retrieve.set_defaults(func=cmd_retrieve)

    # QA command (single question)
    p_qa = subparsers.add_parser("qa", help="Answer a question using KG retrieval")
    p_qa.add_argument("--query", required=True, help="Question to answer")
    p_qa.add_argument("--data_path", required=True, help="Path to graph_db directory")
    p_qa.add_argument(
        "--embedding_model",
        default="facebook/contriever",
        help="Embedding model",
    )
    p_qa.add_argument("--num_hops", type=int, default=1, help="Subgraph hops")
    p_qa.add_argument("--top_k_node", type=int, default=10, help="Top-k nodes")
    p_qa.add_argument("--top_k_triplet", type=int, default=10, help="Top-k triplets")
    p_qa.add_argument("--top_k_return", type=int, default=10, help="Top-k return")
    p_qa.add_argument("--ppr_alpha", type=float, default=0.15, help="PPR alpha")
    p_qa.add_argument("--output", help="Output JSON file")
    p_qa.add_argument("--verbose", action="store_true", help="Verbose output")
    p_qa.set_defaults(func=cmd_qa)

    # QA batch command
    p_qa_batch = subparsers.add_parser("qa-batch", help="Answer batch of questions")
    p_qa_batch.add_argument(
        "--questions_file", required=True, help="JSON file with questions"
    )
    p_qa_batch.add_argument(
        "--data_path", required=True, help="Path to graph_db directory"
    )
    p_qa_batch.add_argument("--output", required=True, help="Output JSON file")
    p_qa_batch.add_argument(
        "--embedding_model",
        default="facebook/contriever",
        help="Embedding model",
    )
    p_qa_batch.add_argument("--num_hops", type=int, default=1, help="Subgraph hops")
    p_qa_batch.add_argument("--top_k_node", type=int, default=10, help="Top-k nodes")
    p_qa_batch.add_argument(
        "--top_k_triplet", type=int, default=10, help="Top-k triplets"
    )
    p_qa_batch.add_argument("--top_k_return", type=int, default=10, help="Top-k return")
    p_qa_batch.add_argument("--ppr_alpha", type=float, default=0.15, help="PPR alpha")
    p_qa_batch.set_defaults(func=cmd_qa_batch)

    # Parse and run
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    try:
        args.func(args)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
