"""Minimal helpers for small scripts: index by session, retrieve by session."""

from __future__ import annotations

import json
import os
import sys
import logging
import argparse
from pathlib import Path
from typing import Any, Dict, List, Optional

DEFAULT_OUTPUT_ROOT = "output"

_session_graph_paths: Dict[str, str] = {}
logger = logging.getLogger(__name__)

def _graph_db_dir(output_root: str, conversation_id: str) -> Path:
    return Path(output_root) / conversation_id / "graph_db" / conversation_id

def _history_to_chunk(messages: List[Dict[str, str]]) -> str:
    return "\n\n".join(f"{m['role']}: {m['content']}" for m in messages)


def _history_fingerprint(messages: List[Dict[str, str]]) -> str:
    payload = json.dumps(messages, ensure_ascii=False, separators=(",", ":"))
    # Keep dependency-free fingerprinting for quick duplicate detection.
    import hashlib

    return hashlib.md5(payload.encode("utf-8")).hexdigest()

def create_conversation(conversation_id: str, name: str = "user-chatbot", output_root: str = DEFAULT_OUTPUT_ROOT) -> None:
    """Initialize a new conversation area."""
    session_dir = Path(output_root) / conversation_id
    session_dir.mkdir(parents=True, exist_ok=True)
    meta_path = session_dir / "session.json"
    meta_path.write_text(
        json.dumps({"conversation_id": conversation_id, "name": name}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

def index(
    history: List[Dict[str, str]],
    conversation_id: str,
    session_id: str,
    update: bool = True,
    fast_mode: bool = True,
    full_refresh_every: int = 20,
    output_root: str = DEFAULT_OUTPUT_ROOT,
    max_workers: int = 4,
    use_subprocess: bool = False,
) -> str:
    from memorai.core.config import settings

    settings.validate()

    session_dir = Path(output_root) / conversation_id
    session_dir.mkdir(parents=True, exist_ok=True)

    inp = session_dir / "_index_input.json"
    state_path = session_dir / "_index_state.json"
    
    input_data = []
    if inp.exists():
        try:
            with open(inp, "r", encoding="utf-8") as f:
                input_data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            logger.warning("Failed to load previous session data: %s", e)
            
    state = {}
    if state_path.exists():
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except (OSError, json.JSONDecodeError):
            state = {}

    history_fp = _history_fingerprint(history)
    state_key = f"{conversation_id}:{session_id}"
    fast_runs_key = f"{state_key}:fast_runs"

    # If this exact history is already indexed, skip pipeline run.
    if state.get(state_key) == history_fp:
        graph_path = _graph_db_dir(output_root, conversation_id).resolve()
        _session_graph_paths[conversation_id] = str(graph_path)
        return str(graph_path)

    # Incremental mode: append only unseen tail of messages for this session.
    prev_len = int(state.get(f"{state_key}:len", 0) or 0)
    if prev_len < 0:
        prev_len = 0
    new_messages = history[prev_len:] if prev_len < len(history) else []
    if not new_messages and history:
        new_messages = [history[-1]]

    # Accumulate chunks under the session_id
    session_entry = next((item for item in input_data if item.get("question_id") == session_id), None)
    chunk_to_add = _history_to_chunk(new_messages if new_messages else history)
    if session_entry:
        session_entry.setdefault("chunks", []).append(chunk_to_add)
    else:
        input_data.append({"question_id": session_id, "chunks": [chunk_to_add]})

    inp.write_text(
        json.dumps(input_data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    should_use_fast_mode = fast_mode
    if fast_mode and full_refresh_every > 0:
        prev_fast_runs = int(state.get(fast_runs_key, 0) or 0)
        should_use_fast_mode = ((prev_fast_runs + 1) % full_refresh_every) != 0
        if not should_use_fast_mode:
            logger.info(
                "Triggering periodic full refresh for %s after %s fast runs.",
                state_key,
                prev_fast_runs + 1,
            )

    if use_subprocess:
        cmd = [
            sys.executable,
            "-m",
            "memorai",
            "pipeline",
            "--input_json",
            str(inp),
            "--output_dir",
            str(session_dir),
            "--save_embeddings",
            "--cleanup",
            "--max_workers",
            str(max_workers),
        ]
        if should_use_fast_mode:
            cmd.append("--fast_mode")
        if update:
            cmd.append("--update")

        cwd = os.environ.get("MEMORAI_PROJECT_ROOT") or str(Path.cwd())
        import subprocess

        subprocess.run(cmd, check=True, cwd=cwd)
    else:
        # Default to in-process execution so notebooks get the real traceback.
        from memorai.cli import cmd_pipeline

        args = argparse.Namespace(
            input_json=str(inp),
            output_dir=str(session_dir),
            save_embeddings=True,
            embedding_model=settings.embedding_model,
            cleanup=True,
            update=update,
            fast_mode=should_use_fast_mode,
            profile_timings=False,
            max_workers=max_workers,
            skip_existing=False,
            formats=["graphml"],
        )
        cmd_pipeline(args)

    state[state_key] = history_fp
    state[f"{state_key}:len"] = len(history)
    if should_use_fast_mode:
        state[fast_runs_key] = int(state.get(fast_runs_key, 0) or 0) + 1
    else:
        state[fast_runs_key] = 0
    state_path.write_text(
        json.dumps(state, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    graph_path = _graph_db_dir(output_root, conversation_id).resolve()
    _session_graph_paths[conversation_id] = str(graph_path)
    return str(graph_path)

def retrieve(
    query: str,
    conversation_id: str,
    output_root: str = DEFAULT_OUTPUT_ROOT,
    verbose: bool = False,
) -> Dict[str, Any]:
    from memorai.retriever import Neo4jRetriever

    r = Neo4jRetriever(top_k=5)
    out = r.retrieve(query, conversation_id=conversation_id)
    
    return {
        "results": out,
        "top_turn_contents": out.get("context", "")
    }

def session_graph_path(conversation_id: str, *, output_root: str = DEFAULT_OUTPUT_ROOT) -> str:
    return str(_graph_db_dir(output_root, conversation_id).resolve())
