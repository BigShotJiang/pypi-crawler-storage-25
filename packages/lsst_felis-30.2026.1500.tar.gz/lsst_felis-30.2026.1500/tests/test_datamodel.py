# This file is part of felis.
#
# Developed for the LSST Data Management System.
# This product includes software developed by the LSST Project
# (https://www.lsst.org).
# See the COPYRIGHT file at the top-level directory of this distribution
# for details of code ownership.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import difflib
import os
import pathlib
import re
import shutil
import tempfile
import unittest
from collections import defaultdict

import yaml
from lsst.resources import ResourcePath
from pydantic import ValidationError

from felis.datamodel import (
    CheckConstraint,
    Column,
    ColumnGroup,
    ColumnOverrides,
    Constraint,
    DataType,
    ForeignKeyConstraint,
    Index,
    Schema,
    SchemaVersion,
    Table,
    UniqueConstraint,
)

TEST_DIR = os.path.abspath(os.path.dirname(__file__))
TEST_YAML = os.path.join(TEST_DIR, "data", "test.yml")
TEST_SALES = os.path.join(TEST_DIR, "data", "sales.yaml")
TEST_SERIALIZATION = os.path.join(TEST_DIR, "data", "test_serialization.yaml")
TEST_ID_GENERATION = os.path.join(TEST_DIR, "data", "test_id_generation.yaml")


class ColumnTestCase(unittest.TestCase):
    """Test the ``Column`` class."""

    def test_validation(self) -> None:
        """Test Pydantic validation of the ``Column`` class."""
        # Default initialization should throw an exception.
        with self.assertRaises(ValidationError):
            Column()

        # Setting only name should throw an exception.
        with self.assertRaises(ValidationError):
            Column(name="testColumn")

        # Setting name and id should throw an exception from missing datatype.
        with self.assertRaises(ValidationError):
            Column(name="testColumn", id="#test_id")

        # Setting name, id, and datatype should not throw an exception and
        # should load data correctly.
        col = Column(name="testColumn", id="#test_id", datatype="string", length=256)
        self.assertEqual(col.name, "testColumn", "name should be 'testColumn'")
        self.assertEqual(col.id, "#test_id", "id should be '#test_id'")
        self.assertEqual(col.datatype, DataType.string, "datatype should be 'DataType.string'")

        # Creating from data dictionary should work and load data correctly.
        data = {"name": "testColumn", "id": "#test_id", "datatype": "string", "length": 256}
        col = Column(**data)
        self.assertEqual(col.name, "testColumn", "name should be 'testColumn'")
        self.assertEqual(col.id, "#test_id", "id should be '#test_id'")
        self.assertEqual(col.datatype, DataType.string, "datatype should be 'DataType.string'")

        # Setting a bad IVOA UCD should throw an error.
        with self.assertRaises(ValidationError):
            Column(**data, ivoa_ucd="bad")

        # Setting a valid IVOA UCD should not throw an error.
        col = Column(**data, ivoa_ucd="meta.id")
        self.assertEqual(col.ivoa_ucd, "meta.id", "ivoa_ucd should be 'meta.id'")

        units_data = data.copy()

        # Setting a bad IVOA unit should throw an error.
        units_data["ivoa:unit"] = "bad"
        with self.assertRaises(ValidationError):
            Column(**units_data)

        # Setting a valid IVOA unit should not throw an error.
        units_data["ivoa:unit"] = "m"
        col = Column(**units_data)
        self.assertEqual(col.ivoa_unit, "m", "ivoa_unit should be 'm'")

        units_data = data.copy()

        # Setting a bad FITS TUNIT should throw an error.
        units_data["fits:tunit"] = "bad"
        with self.assertRaises(ValidationError):
            Column(**units_data)

        # Setting a valid FITS TUNIT should not throw an error.
        units_data["fits:tunit"] = "m"
        col = Column(**units_data)
        self.assertEqual(col.fits_tunit, "m", "fits_tunit should be 'm'")

        # Setting both IVOA unit and FITS TUNIT should throw an error.
        units_data["ivoa:unit"] = "m"
        with self.assertRaises(ValidationError):
            Column(**units_data)

    def test_description(self) -> None:
        """Test Pydantic validation of the ``description`` attribute."""
        # Creating a column with a description of 'None' should throw.
        with self.assertRaises(ValueError):
            Column(
                **{
                    "name": "testColumn",
                    "@id": "#test_col_id",
                    "datatype": "string",
                    "description": None,
                }
            )

        # Creating a column with an empty description should throw.
        with self.assertRaises(ValueError):
            Column(
                **{
                    "name": "testColumn",
                    "@id": "#test_col_id",
                    "datatype": "string",
                    "description": "",
                }
            )

        # Creating a column with a description that is too short should throw.
        with self.assertRaises(ValidationError):
            Column(
                **{
                    "name": "testColumn",
                    "@id": "#test_col_id",
                    "datatype": "string",
                    "description": "xy",
                }
            )

    def test_values(self) -> None:
        """Test Pydantic validation of the ``value`` attribute."""

        # Define a function to return the default column data
        def default_coldata():
            return defaultdict(str, {"name": "testColumn", "@id": "#test_col_id"})

        # Setting both value and autoincrement should throw.
        autoincr_coldata = default_coldata()
        autoincr_coldata["datatype"] = "int"
        autoincr_coldata["autoincrement"] = True
        autoincr_coldata["value"] = 1
        with self.assertRaises(ValueError):
            Column(**autoincr_coldata)

        # Setting an invalid default on a column with an integer type should
        # throw.
        bad_numeric_coldata = default_coldata()
        for datatype in ["int", "long", "short", "byte"]:
            for value in ["bad", "1.0", "1", 1.1]:
                bad_numeric_coldata["datatype"] = datatype
                bad_numeric_coldata["value"] = value
                with self.assertRaises(ValueError):
                    Column(**bad_numeric_coldata)

        # Setting an invalid default on a column with a decimal type should
        # throw.
        bad_numeric_coldata = default_coldata()
        for datatype in ["double", "float"]:
            for value in ["bad", "1.0", "1", 1]:
                bad_numeric_coldata["datatype"] = datatype
                bad_numeric_coldata["value"] = value
                with self.assertRaises(ValueError):
                    Column(**bad_numeric_coldata)

        # Setting a bad default on a string column should throw.
        bad_str_coldata = default_coldata()
        bad_str_coldata["value"] = 1
        bad_str_coldata["length"] = 256
        for datatype in ["string", "char", "unicode", "text"]:
            for value in [1, 1.1, True, "", " ", "    ", "\n", "\t"]:
                bad_str_coldata["datatype"] = datatype
                bad_str_coldata["value"] = value
                with self.assertRaises(ValueError):
                    Column(**bad_str_coldata)

        # Setting a non-boolean value on a boolean column should throw.
        bool_coldata = default_coldata()
        bool_coldata["datatype"] = "boolean"
        bool_coldata["value"] = "bad"
        with self.assertRaises(ValueError):
            for value in ["bad", 1, 1.1]:
                bool_coldata["value"] = value
                Column(**bool_coldata)

        # Setting a valid value on a string column should be okay.
        str_coldata = default_coldata()
        str_coldata["value"] = 1
        str_coldata["length"] = 256
        str_coldata["value"] = "okay"
        for datatype in ["string", "char", "unicode", "text"]:
            str_coldata["datatype"] = datatype
            Column(**str_coldata)

        # Setting an integer value on a column with an int type should be okay.
        int_coldata = default_coldata()
        int_coldata["value"] = 1
        for datatype in ["int", "long", "short", "byte"]:
            int_coldata["datatype"] = datatype
            Column(**int_coldata)

        # Setting a decimal value on a column with a float type should be okay.
        bool_coldata = default_coldata()
        bool_coldata["datatype"] = "boolean"
        bool_coldata["value"] = True
        Column(**bool_coldata)

    def test_timestamp(self) -> None:
        """Test validation of timestamp columns."""
        # Check that the votable_xtype is set correctly for timestamp columns.
        col = Column(name="testColumn", id="#test_col_id", datatype="timestamp")
        self.assertEqual(col.votable_xtype, "timestamp")


class TableTestCase(unittest.TestCase):
    """Test Pydantic validation of the ``Table`` class."""

    def test_validation(self) -> None:
        """Test Pydantic validation of the ``Table`` class."""
        # Default initialization should throw an exception.
        with self.assertRaises(ValidationError):
            Table()

        # Setting only name should throw an exception.
        with self.assertRaises(ValidationError):
            Table(name="testTable")

        # Setting name and id should throw an exception from missing columns.
        with self.assertRaises(ValidationError):
            Index(name="testTable", id="#test_id")

        testCol = Column(name="testColumn", id="#test_id", datatype="string", length=256)

        # Setting name, id, and columns should not throw an exception and
        # should load data correctly.
        tbl = Table(name="testTable", id="#test_id", columns=[testCol])
        self.assertEqual(tbl.name, "testTable", "name should be 'testTable'")
        self.assertEqual(tbl.id, "#test_id", "id should be '#test_id'")
        self.assertEqual(tbl.columns, [testCol], "columns should be ['testColumn']")

        # Creating a table with duplicate column names should raise an
        # exception.
        with self.assertRaises(ValidationError):
            Table(name="testTable", id="#test_id", columns=[testCol, testCol])


class ColumnGroupTestCase(unittest.TestCase):
    """Test Pydantic validation of the ``ColumnGroup`` class."""

    def test_validation(self) -> None:
        """Test Pydantic validation of the ``ColumnGroup`` class."""
        # Default initialization should throw an exception.
        with self.assertRaises(ValidationError):
            ColumnGroup()

        # Setting only name should throw an exception.
        with self.assertRaises(ValidationError):
            ColumnGroup(name="testGroup")

        # Setting name and id should throw an exception from missing columns.
        with self.assertRaises(ValidationError):
            ColumnGroup(name="testGroup", id="#test_id")

        col = Column(name="testColumn", id="#test_col", datatype="string", length=256)

        # Setting name, id, and columns should not throw an exception and
        # should load data correctly.
        group = ColumnGroup(name="testGroup", id="#test_group", columns=[col], ivoa_ucd="meta")
        self.assertEqual(group.name, "testGroup", "name should be 'testGroup'")
        self.assertEqual(group.id, "#test_group", "id should be '#test_group'")
        self.assertEqual(group.columns, [col], "columns should be ['testColumn']")

        # Dereferencing columns without setting a table should raise an
        # exception.
        with self.assertRaises(ValueError):
            group._dereference_columns()

        # Creating a group with duplicate column names should raise an
        # exception.
        with self.assertRaises(ValidationError):
            ColumnGroup(name="testGroup", id="#test_group", columns=[col, col])

        # Check that including a column object in a group works correctly.
        group = ColumnGroup(name="testGroup", id="#test_group", columns=[col], ivoa_ucd="meta")
        table = Table(
            name="testTable",
            id="#test_table",
            columns=[col],
            column_groups=[group],
        )
        self.assertEqual(table.column_groups, [group], "column_groups should be [group]")
        self.assertEqual(col, table.column_groups[0].columns[0], "column_groups[0] should be testCol")

        # Check that column derefencing works correctly when group is assigned
        # to a table.
        group = ColumnGroup(name="testGroup", id="#test_group", columns=["#test_col"], ivoa_ucd="meta")
        table = Table(
            name="testTable",
            id="#test_table",
            columns=[col],
            column_groups=[group],
        )
        self.assertEqual(table.column_groups, [group], "column_groups should be [group]")
        self.assertEqual(col, table.column_groups[0].columns[0], "column_groups[0] should be testCol")

        # Creating a group with a bad column should raise an exception.
        group = ColumnGroup(name="testGroup", id="#test_group", columns=["#bad_col"], ivoa_ucd="meta")
        with self.assertRaises(ValueError):
            table = Table(
                name="testTable",
                id="#test_table",
                columns=[col],
                column_groups=[group],
            )


class ConstraintTestCase(unittest.TestCase):
    """Test Pydantic validation of the different constraint classes."""

    def test_base_constraint(self) -> None:
        """Test validation of base constraint type."""
        # Default initialization should throw an exception.
        with self.assertRaises(ValidationError):
            Constraint()

        # Setting only name should throw an exception.
        with self.assertRaises(ValidationError):
            Constraint(name="test_constraint")

        # Setting name and id should not throw an exception and should load
        # data correctly.
        Constraint(name="test_constraint", id="#test_constraint")

        # Setting initially without deferrable should throw an exception.
        with self.assertRaises(ValidationError):
            Constraint(name="test_constraint", id="#test_constraint", deferrable=False, initially="IMMEDIATE")

        # Seting a bad value for initially should throw an exception.
        with self.assertRaises(ValidationError):
            Constraint(name="test_constraint", id="#test_constraint", deferrable=True, initially="BAD_VALUE")

        # Setting a valid value for initially should not throw an exception.
        Constraint(name="test_constraint", id="#test_constraint", deferrable=True, initially="IMMEDIATE")
        Constraint(name="test_constraint", id="#test_constraint", deferrable=True, initially="DEFERRED")

    def test_unique_constraint(self) -> None:
        """Test validation of unique constraints."""
        # Setting name and id should throw an exception from missing columns.
        with self.assertRaises(ValidationError):
            UniqueConstraint(name="test_constraint", id="#test_constraint")

        # Setting name, id, and columns should not throw an exception and
        # should load data correctly.
        constraint = UniqueConstraint(name="uniq_test", id="#uniq_test", columns=["test_column"])
        self.assertEqual(constraint.name, "uniq_test", "name should be 'uniq_test'")
        self.assertEqual(constraint.id, "#uniq_test", "id should be '#uniq_test'")
        self.assertEqual(constraint.columns, ["test_column"], "columns should be ['test_column']")

        # Creating from data dictionary should work and load data correctly.
        data = {"name": "uniq_test", "id": "#uniq_test", "columns": ["test_column"]}
        constraint = UniqueConstraint(**data)
        self.assertEqual(constraint.name, "uniq_test", "name should be 'uniq_test'")
        self.assertEqual(constraint.id, "#uniq_test", "id should be '#uniq_test'")
        self.assertEqual(constraint.columns, ["test_column"], "columns should be ['test_column']")

    def test_foreign_key_constraint(self) -> None:
        """Test validation of foreign key constraints."""
        # Setting name and id should throw an exception from missing columns.
        with self.assertRaises(ValidationError):
            ForeignKeyConstraint(name="fk_test", id="#fk_test")

        # Setting name, id, and columns should not throw an exception and
        # should load data correctly.
        constraint = ForeignKeyConstraint(
            name="fk_test", id="#fk_test", columns=["test_column"], referenced_columns=["test_column"]
        )
        self.assertEqual(constraint.name, "fk_test", "name should be 'fk_test'")
        self.assertEqual(constraint.id, "#fk_test", "id should be '#fk_test'")
        self.assertEqual(constraint.columns, ["test_column"], "columns should be ['test_column']")
        self.assertEqual(
            constraint.referenced_columns, ["test_column"], "referenced_columns should be ['test_column']"
        )

        # Creating from data dictionary should work and load data correctly.
        data = {
            "name": "fk_test",
            "id": "#fk_test",
            "columns": ["test_column"],
            "referenced_columns": ["test_column"],
        }
        constraint = ForeignKeyConstraint(**data)
        self.assertEqual(constraint.name, "fk_test", "name should be 'fk_test'")
        self.assertEqual(constraint.id, "#fk_test", "id should be '#fk_test'")
        self.assertEqual(constraint.columns, ["test_column"], "columns should be ['test_column']")
        self.assertEqual(
            constraint.referenced_columns, ["test_column"], "referenced_columns should be ['test_column']"
        )

        # Creating a foreign key constraint with no columns should raise an
        # exception.
        with self.assertRaises(ValidationError):
            ForeignKeyConstraint(
                name="fk_test", id="#fk_test", columns=[], referenced_columns=["test_column"]
            )

        # Creating a foreign key constraint with no referenced columns should
        # raise an exception.
        with self.assertRaises(ValidationError):
            ForeignKeyConstraint(
                name="fk_test", id="#fk_test", columns=["test_column"], referenced_columns=[]
            )

        # Creating a foreign key constraint where the number of foreign key
        # columns does not match the number of referenced columns should raise
        # an exception.
        with self.assertRaises(ValidationError):
            ForeignKeyConstraint(
                name="fk_test",
                id="#fk_test",
                columns=["test_column", "test_column2"],
                referenced_columns=["test_column"],
            )

    def test_check_constraint(self) -> None:
        """Test validation of check constraints."""
        # Setting name and id should throw an exception from missing
        # expression.
        with self.assertRaises(ValidationError):
            CheckConstraint(name="check_test", id="#check_test")

        # Setting name, id, and expression should not throw an exception and
        # should load data correctly.
        constraint = CheckConstraint(name="check_test", id="#check_test", expression="1+2")
        self.assertEqual(constraint.name, "check_test", "name should be 'check_test'")
        self.assertEqual(constraint.id, "#check_test", "id should be '#check_test'")
        self.assertEqual(constraint.expression, "1+2", "expression should be '1+2'")

        # Creating from data dictionary should work and load data correctly.
        data = {
            "name": "check_test",
            "id": "#check_test",
            "expression": "1+2",
        }
        constraint = CheckConstraint(**data)
        self.assertEqual(constraint.name, "check_test", "name should be 'check_test'")
        self.assertEqual(constraint.id, "#check_test", "id should be '#test_id'")
        self.assertEqual(constraint.expression, "1+2", "expression should be '1+2'")

    def test_bad_constraint_type(self) -> None:
        with self.assertRaises(ValidationError):
            UniqueConstraint(name="uniq_test", id="#uniq_test", columns=["test_column"], type="BAD_TYPE")

    def test_constraint_column_checks(self) -> None:
        """Test the extra validation in the ``Schema`` that checks the
        constraint column references.
        """

        def _create_test_schema(constraint: Constraint) -> None:
            """Create a test schema with the given constraint."""
            test_col = Column(name="testColumn", id="#test_col_id", datatype="int")
            test_col2 = Column(name="testColumn2", id="#test_col_id2", datatype="int")
            test_tbl = Table(
                name="testTable", id="#test_tbl_id", columns=[test_col, test_col2], constraints=[constraint]
            )
            test_col = Column(name="testColumn", id="#test_col2_id", datatype="int")
            test_col2 = Column(name="testColumn2", id="#test_col2_id2", datatype="int")
            test_tbl2 = Table(name="testTable2", id="#test_tbl2_id", columns=[test_col, test_col2])
            Schema(name="testSchema", id="#test_schema_id", tables=[test_tbl, test_tbl2])

        # Creating a unique constraint on a bad column should raise an
        # exception.
        with self.assertRaises(ValidationError):
            _create_test_schema(
                UniqueConstraint(name="testConstraint", id="#test_constraint_id", columns=["bad_column"])
            )

        # Creating a foreign key constraint with a bad column should raise an
        # exception.
        with self.assertRaises(ValidationError):
            _create_test_schema(
                ForeignKeyConstraint(
                    name="testForeignKey",
                    id="#test_fk_id",
                    columns=["bad_column"],
                    referenced_columns=["#test_col2_id"],
                )
            )

        # Creating a foreign key constraint with a bad referenced column should
        # raise an exception.
        with self.assertRaises(ValidationError):
            _create_test_schema(
                ForeignKeyConstraint(
                    name="testForeignKey",
                    id="#test_fk_id",
                    columns=["#test_col_id"],
                    referenced_columns=["bad_column"],
                )
            )

        # Creating a foreign key constraint where the source column is not in
        # the same table as the constraint should raise an exception.
        with self.assertRaises(ValidationError):
            _create_test_schema(
                ForeignKeyConstraint(
                    name="testForeignKey",
                    id="#test_fk_id",
                    columns=["#test_col2_id"],  # This column is in test_tbl2, not test_tbl
                    referenced_columns=["#test_col_id"],
                )
            )

        # Creating a foreign key constraint where the referenced column is not
        # a column object should raise an exception.
        with self.assertRaises(ValidationError):
            _create_test_schema(
                ForeignKeyConstraint(
                    name="testForeignKey",
                    id="#test_fk_id",
                    columns=["#test_col_id"],
                    referenced_columns=["#test_schema_id"],
                )
            )

        # Creating a valid unique constraint should not raise an exception.
        _create_test_schema(
            UniqueConstraint(name="testConstraint", id="#test_constraint_id", columns=["#test_col_id"])
        )

        # Creating a valid foreign key constraint should not raise an
        # exception.
        _create_test_schema(
            ForeignKeyConstraint(
                name="testForeignKey",
                id="#test_fk_id",
                columns=["#test_col_id"],
                referenced_columns=["#test_col2_id"],
            )
        )

        # Creating a foreign key constraint with a composite key should not
        # raise an exception.
        _create_test_schema(
            ForeignKeyConstraint(
                name="testCompositeForeignKey",
                id="#test_composite_fk_id",
                columns=["#test_col_id", "#test_col_id2"],
                referenced_columns=["#test_col2_id", "#test_col2_id2"],
            )
        )


class IndexTestCase(unittest.TestCase):
    """Test Pydantic validation of the ``Index`` class."""

    def test_index_validation(self) -> None:
        """Test validation of indexes."""
        # Default initialization should throw an exception.
        with self.assertRaises(ValidationError):
            Index()

        # Setting only name should throw an exception.
        with self.assertRaises(ValidationError):
            Index(name="idx_test")

        # Setting name and id should throw an exception from missing columns.
        with self.assertRaises(ValidationError):
            Index(name="idx_test", id="#idx_test")

        # Setting name, id, and columns should not throw an exception and
        # should load data correctly.
        idx = Index(name="idx_test", id="#idx_test", columns=["#test_column"])
        self.assertEqual(idx.name, "idx_test", "name should be 'test_constraint'")
        self.assertEqual(idx.id, "#idx_test", "id should be '#test_id'")
        self.assertEqual(idx.columns, ["#test_column"], "columns should be ['test_column']")

        # Creating from data dictionary should work and load data correctly.
        data = {"name": "idx_test", "id": "#idx_test", "columns": ["test_column"]}
        idx = Index(**data)
        self.assertEqual(idx.name, "idx_test", "name should be 'idx_test'")
        self.assertEqual(idx.id, "#idx_test", "id should be '#idx_test'")
        self.assertEqual(idx.columns, ["test_column"], "columns should be ['test_column']")

        # Setting both columns and expressions on an index should throw an
        # exception.
        with self.assertRaises(ValidationError):
            Index(name="idx_test", id="#idx_test", columns=["test_column"], expressions=["1+2"])


class SchemaTestCase(unittest.TestCase):
    """Test Pydantic validation of the ``Schema`` class."""

    def test_validation(self) -> None:
        """Test Pydantic validation of the main schema class."""
        # Default initialization should throw an exception.
        with self.assertRaises(ValidationError):
            Schema()

        # Setting only name should throw an exception.
        with self.assertRaises(ValidationError):
            Schema(name="testSchema")

        # Setting name and id should throw an exception from missing columns.
        with self.assertRaises(ValidationError):
            Schema(name="testSchema", id="#test_id")

        test_col = Column(name="testColumn", id="#test_col_id", datatype="string", length=256)
        test_tbl = Table(name="testTable", id="#test_tbl_id", columns=[test_col])

        # Setting name, id, and columns should not throw an exception and
        # should load data correctly.
        sch = Schema(name="testSchema", id="#test_sch_id", tables=[test_tbl])
        self.assertEqual(sch.name, "testSchema", "name should be 'testSchema'")
        self.assertEqual(sch.id, "#test_sch_id", "id should be '#test_sch_id'")
        self.assertEqual(sch.tables, [test_tbl], "tables should be ['testTable']")

        # Creating a schema with duplicate table names should raise an
        # exception.
        with self.assertRaises(ValidationError):
            Schema(name="testSchema", id="#test_id", tables=[test_tbl, test_tbl])

        # Using an undefined YAML field should raise an exception.
        with self.assertRaises(ValidationError):
            Schema(**{"name": "testSchema", "id": "#test_sch_id", "bad_field": "1234"}, tables=[test_tbl])

        # Creating a schema containing duplicate IDs should raise an error.
        with self.assertRaises(ValidationError):
            Schema(
                name="testSchema",
                id="#test_sch_id",
                tables=[
                    Table(
                        name="testTable",
                        id="#test_tbl_id",
                        columns=[
                            Column(name="testColumn", id="#test_col_id", datatype="string"),
                            Column(name="testColumn2", id="#test_col_id", datatype="string"),
                        ],
                    )
                ],
            )

    def test_schema_object_ids(self) -> None:
        """Test that the ``id_map`` is properly populated."""
        test_col = Column(name="testColumn", id="#test_col_id", datatype="string", length=256)
        test_tbl = Table(name="testTable", id="#test_table_id", columns=[test_col])
        sch = Schema(name="testSchema", id="#test_schema_id", tables=[test_tbl])

        for id in ["#test_col_id", "#test_table_id", "#test_schema_id"]:
            # Test that the schema contains the expected id.
            self.assertTrue(id in sch, f"schema should contain '{id}'")

        # Check that types of returned objects are correct.
        self.assertIsInstance(sch["#test_col_id"], Column, "schema[id] should return a Column")
        self.assertIsInstance(sch["#test_table_id"], Table, "schema[id] should return a Table")
        self.assertIsInstance(sch["#test_schema_id"], Schema, "schema[id] should return a Schema")

        with self.assertRaises(KeyError):
            # Test that an invalid id raises an exception.
            sch["#bad_id"]

    def test_check_unique_constraint_names(self) -> None:
        """Test that constraint names are unique."""
        test_col = Column(name="testColumn", id="#test_col_id", datatype="string", length=256)
        test_tbl = Table(name="testTable", id="#test_table_id", columns=[test_col])
        test_cons = UniqueConstraint(name="testConstraint", id="#test_constraint_id", columns=["testColumn"])
        test_cons2 = UniqueConstraint(
            name="testConstraint", id="#test_constraint2_id", columns=["testColumn"]
        )
        test_tbl.constraints = [test_cons, test_cons2]
        with self.assertRaises(ValidationError):
            Schema(name="testSchema", id="#test_id", tables=[test_tbl])

    def test_check_unique_index_names(self) -> None:
        """Test that index names are unique."""
        test_col = Column(name="test_column1", id="#test_table.test_column1", datatype="int")
        test_col2 = Column(name="test_column2", id="#test_table.test_column2", datatype="string", length=256)
        test_tbl = Table(name="test_table", id="#test_table", columns=[test_col, test_col2])
        test_idx = Index(name="idx_test", id="#idx_test", columns=[test_col.id])
        test_idx2 = Index(name="idx_test", id="#idx_test2", columns=[test_col2.id])
        test_tbl.indexes = [test_idx, test_idx2]
        with self.assertRaises(ValidationError):
            Schema(name="test_schema", id="#test-schema", tables=[test_tbl])

    def test_model_validate(self) -> None:
        """Load a YAML test file and validate the schema data model."""
        with open(TEST_YAML) as test_yaml:
            data = yaml.safe_load(test_yaml)
            Schema.model_validate(data)

    def test_id_generation(self) -> None:
        """Test ID generation."""
        test_path = os.path.join(TEST_ID_GENERATION)
        with open(test_path) as test_yaml:
            yaml_data = yaml.safe_load(test_yaml)
            # Generate IDs for objects in the test schema.
            Schema.model_validate(yaml_data, context={"id_generation": True})
        with open(test_path) as test_yaml:
            yaml_data = yaml.safe_load(test_yaml)
            # Test that an error is raised when id generation is disabled.
            with self.assertRaises(ValidationError):
                Schema.model_validate(yaml_data, context={"id_generation": False})

    def test_get_table_by_column(self) -> None:
        """Test the ``get_table_by_column`` method."""
        # Test that the correct table is returned when searching by column.
        test_col = Column(name="test_column", id="#test_tbl.test_col", datatype="string", length=256)
        test_tbl = Table(name="test_table", id="#test_tbl", columns=[test_col])
        sch = Schema(name="testSchema", id="#test_sch_id", tables=[test_tbl])
        self.assertEqual(sch.get_table_by_column(test_col), test_tbl)

        # Test that an error is raised when the column is not found.
        bad_col = Column(name="bad_column", id="#test_tbl.bad_column", datatype="string", length=256)
        with self.assertRaises(ValueError):
            sch.get_table_by_column(bad_col)

    def test_find_object_by_id(self) -> None:
        test_col = Column(name="test_column", id="#test_tbl.test_col", datatype="string", length=256)
        test_tbl = Table(name="test_table", id="#test_tbl", columns=[test_col])
        sch = Schema(name="testSchema", id="#test_sch_id", tables=[test_tbl])
        self.assertEqual(sch.find_object_by_id("#test_tbl.test_col", Column), test_col)
        with self.assertRaises(KeyError):
            sch.find_object_by_id("#bad_id", Column)
        with self.assertRaises(TypeError):
            sch.find_object_by_id("#test_tbl", Column)

    def test_from_file(self) -> None:
        """Test loading a schema from a file."""
        # Test file object.
        with open(TEST_SALES) as test_file:
            schema = Schema.from_stream(test_file)
            self.assertIsInstance(schema, Schema)

        # Test path string.
        with open(TEST_SALES) as test_file:
            schema = Schema.from_stream(test_file)
        self.assertIsInstance(schema, Schema)

        # Path object.
        test_file_path = pathlib.Path(TEST_SALES)
        schema = Schema.from_uri(test_file_path)
        self.assertIsInstance(schema, Schema)

    def test_from_resource(self) -> None:
        """Test loading a schema from a resource."""
        # Test loading a schema from a resource string.
        schema = Schema.from_uri(
            "resource://felis/config/tap_schema/tap_schema_std.yaml", context={"id_generation": True}
        )
        self.assertIsInstance(schema, Schema)

        # Test loading a schema from a ResourcePath.
        schema = Schema.from_uri(
            ResourcePath("resource://felis/config/tap_schema/tap_schema_std.yaml"),
            context={"id_generation": True},
        )
        self.assertIsInstance(schema, Schema)

        # Test loading from a nonexistant resource.
        with self.assertRaises(ValueError):
            Schema.from_uri("resource://fake/schemas/bad_schema.yaml")

        # Without ID generation enabled, this schema should fail validation.
        with self.assertRaises(ValidationError):
            Schema.from_uri("resource://felis/config/tap_schema/tap_schema_std.yaml")

    def test_find_table_by_name(self) -> None:
        """Test the ``_find_table_by_name`` method."""
        # Create a simple schema with two tables
        test_col1 = Column(name="test_column1", id="#test_tbl1.test_col1", datatype="int")
        test_col2 = Column(name="test_column2", id="#test_tbl2.test_col2", datatype="string", length=256)
        test_tbl1 = Table(name="test_table1", id="#test_tbl1", columns=[test_col1])
        test_tbl2 = Table(name="test_table2", id="#test_tbl2", columns=[test_col2])
        sch = Schema(name="testSchema", id="#test_sch_id", tables=[test_tbl1, test_tbl2])

        # Test that the correct table is returned when searching by name
        self.assertEqual(sch._find_table_by_name("test_table1"), test_tbl1)
        self.assertEqual(sch._find_table_by_name("test_table2"), test_tbl2)

        # Test that a KeyError is raised when the table is not found
        with self.assertRaises(KeyError):
            sch._find_table_by_name("nonexistent_table")


class SchemaVersionTest(unittest.TestCase):
    """Test the schema version."""

    def test_validation(self) -> None:
        """Test validation of the schema version class."""
        # Default initialization should throw an exception.
        with self.assertRaises(ValidationError):
            SchemaVersion()

        # Setting current should not throw an exception and should load data
        # correctly.
        sv = SchemaVersion(current="1.0.0")
        self.assertEqual(sv.current, "1.0.0", "current should be '1.0.0'")

        # Check that schema version can be specified as a single string or
        # an object.
        data = {
            "name": "schema",
            "@id": "#schema",
            "tables": [],
            "version": "1.2.3",
        }
        schema = Schema.model_validate(data)
        self.assertEqual(schema.version, "1.2.3")

        data = {
            "name": "schema",
            "@id": "#schema",
            "tables": [],
            "version": {
                "current": "1.2.3",
                "compatible": ["1.2.0", "1.2.1", "1.2.2"],
                "read_compatible": ["1.1.0", "1.1.1"],
            },
        }
        schema = Schema.model_validate(data)
        self.assertEqual(schema.version.current, "1.2.3")
        self.assertEqual(schema.version.compatible, ["1.2.0", "1.2.1", "1.2.2"])
        self.assertEqual(schema.version.read_compatible, ["1.1.0", "1.1.1"])


class ValidationFlagsTest(unittest.TestCase):
    """Test optional validation flags on the schema."""

    def test_check_tap_table_indexes(self) -> None:
        """Test the ``check_tap_table_indexes`` validation flag."""
        cxt = {"check_tap_table_indexes": True}
        schema_dict = {
            "name": "testSchema",
            "id": "#test_schema_id",
            "tables": [
                {
                    "name": "test_table",
                    "id": "#test_table_id",
                    "columns": [{"name": "test_col", "id": "#test_col", "datatype": "int"}],
                }
            ],
        }

        # Creating a schema without a TAP table index should throw.
        with self.assertRaises(ValidationError):
            Schema.model_validate(schema_dict, context=cxt)

        # Creating a schema with a TAP table index should not throw.
        schema_dict["tables"][0]["tap_table_index"] = 1
        Schema.model_validate(schema_dict, context=cxt)
        schema_dict["tables"].append(
            {
                "name": "test_table2",
                "id": "#test_table2",
                "tap_table_index": 1,
                "columns": [{"name": "test_col2", "id": "#test_col2", "datatype": "int"}],
            }
        )

        # Creating a schema with a duplicate TAP table index should throw.
        with self.assertRaises(ValidationError):
            Schema.model_validate(schema_dict, context=cxt)

        # Multiple, unique TAP table indexes should not throw.
        schema_dict["tables"][1]["tap_table_index"] = 2
        Schema.model_validate(schema_dict, context=cxt)

    def test_check_tap_principal(self) -> None:
        """Test the ``check_tap_principal` validation flag."""
        cxt = {"check_tap_principal": True}
        schema_dict = {
            "name": "testSchema",
            "id": "#test_schema_id",
            "tables": [
                {
                    "name": "test_table",
                    "id": "#test_table_id",
                    "columns": [{"name": "test_col", "id": "#test_col", "datatype": "int"}],
                }
            ],
        }

        # Creating a table without a TAP table principal column should throw.
        with self.assertRaises(ValidationError):
            Schema.model_validate(schema_dict, context=cxt)

        # Creating a table with a TAP table principal column should not throw.
        schema_dict["tables"][0]["columns"][0]["tap_principal"] = 1
        Schema.model_validate(schema_dict, context=cxt)

    def test_check_description(self) -> None:
        """Test the ``check_description`` flag."""
        cxt = {"check_description": True}
        schema_dict = {
            "name": "testSchema",
            "id": "#test_schema_id",
            "tables": [
                {
                    "name": "test_table",
                    "id": "#test_table_id",
                    "columns": [{"name": "test_col", "id": "#test_col", "datatype": "int"}],
                }
            ],
        }

        # Creating a schema without object descriptions should throw.
        with self.assertRaises(ValidationError):
            Schema.model_validate(schema_dict, context=cxt)

        # Creating a schema with object descriptions should not throw.
        schema_dict["description"] = "Test schema"
        schema_dict["tables"][0]["description"] = "Test table"
        schema_dict["tables"][0]["columns"][0]["description"] = "Test column"
        Schema.model_validate(schema_dict, context=cxt)


class RedundantDatatypesTest(unittest.TestCase):
    """Test validation of redundant datatype definitions."""

    def test_mysql_datatypes(self) -> None:
        class ColumnGenerator:
            """Generate column data for redundant datatype testing."""

            def __init__(self, name, id, db_name):
                self.name = name
                self.id = id
                self.db_name = db_name
                self.context = {"check_redundant_datatypes": True}

            def col(self, datatype: str, db_datatype: str, length=None):
                return Column.model_validate(
                    {
                        "name": self.name,
                        "@id": self.id,
                        "datatype": datatype,
                        f"{self.db_name}:datatype": db_datatype,
                        "length": length,
                    },
                    context=self.context,
                )

        """Test that redundant datatype definitions raise an error."""
        coldata = ColumnGenerator("test_col", "#test_col_id", "mysql")

        with self.assertRaises(ValidationError):
            coldata.col("double", "DOUBLE")

        with self.assertRaises(ValidationError):
            coldata.col("int", "INTEGER")

        with self.assertRaises(ValidationError):
            coldata.col("float", "FLOAT")

        with self.assertRaises(ValidationError):
            coldata.col("char", "CHAR", length=8)

        with self.assertRaises(ValidationError):
            coldata.col("string", "VARCHAR", length=32)

        with self.assertRaises(ValidationError):
            coldata.col("byte", "TINYINT")

        with self.assertRaises(ValidationError):
            coldata.col("short", "SMALLINT")

        with self.assertRaises(ValidationError):
            coldata.col("long", "BIGINT")

        with self.assertRaises(ValidationError):
            coldata.col("boolean", "BOOLEAN")

        with self.assertRaises(ValidationError):
            coldata.col("unicode", "NVARCHAR", length=32)

        with self.assertRaises(ValidationError):
            coldata.col("timestamp", "DATETIME")

        # DM-42257: Felis does not handle unbounded text types properly.
        # coldata.col("text", "TEXT", length=32)

        with self.assertRaises(ValidationError):
            coldata.col("binary", "LONGBLOB", length=1024)

        with self.assertRaises(ValidationError):
            # Same type and length
            coldata.col("string", "VARCHAR(128)", length=128)

        # Check the old type mapping for MySQL, which is now okay
        coldata.col("boolean", "BIT(1)")

        # Different types, which is okay
        coldata.col("double", "FLOAT")

        # Same base type with different lengths, which is okay
        coldata.col("string", "VARCHAR(128)", length=32)

        # Different string types, which is okay
        coldata.col("string", "CHAR", length=32)
        coldata.col("unicode", "CHAR", length=32)

    def test_precision(self) -> None:
        """Test that precision is not allowed for datatypes other than
        timestamp.
        """
        with self.assertRaises(ValidationError):
            Column(**{"name": "testColumn", "@id": "#test_col_id", "datatype": "double", "precision": 6})


class SchemaSerializationTest(unittest.TestCase):
    """Test serialization and deserialization of the schema data model."""

    def test_serialization(self) -> None:
        """Test serialization of the schema data model."""
        # Read the original YAML content from the test_serialization.yaml file
        with open(TEST_SERIALIZATION) as file:
            original_yaml_content = file.read()

        # Load the schema from the original YAML content
        schema_out = Schema.from_uri(TEST_SERIALIZATION)
        serialized_data = schema_out.model_dump(by_alias=True, exclude_none=True, exclude_defaults=True)

        # Write the serialized data to a temporary YAML file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".yaml", mode="w+") as temp_file:
            yaml.dump(serialized_data, temp_file, default_flow_style=False, sort_keys=False)
            temp_file.seek(0)
            # Read the deserialized YAML content from the temporary file
            deserialized_yaml_content = temp_file.read()

        # Show the differences between the original and deserialized YAML
        diff = difflib.unified_diff(
            original_yaml_content.splitlines(keepends=True),
            deserialized_yaml_content.splitlines(keepends=True),
            fromfile="original.yaml",
            tofile="deserialized.yaml",
        )
        print("Differences:\n", "".join(diff))

        # Assert that the original and deserialized YAML are the same
        self.assertEqual(
            yaml.safe_load(original_yaml_content),
            yaml.safe_load(deserialized_yaml_content),
            "The original and deserialized YAML contents should be the same",
        )


class ResourceTestCase(unittest.TestCase):
    """Test loading of column definitions from external schema resources."""

    def setUp(self) -> None:
        """Set up test resources."""
        self.temp_dir = tempfile.mkdtemp()

        # Write out source schema file
        source_schema_content = """
name: source_schema
description: Test resource schema
tables:
- name: source_table
  description: Source table
  columns:
  - name: test_column
    datatype: int
    description: "Test column"
"""
        self.source_schema_path = os.path.join(self.temp_dir, "source_schema.yaml")
        with open(self.source_schema_path, "w") as f:
            f.write(source_schema_content.strip())

        # Write out referencing schema file
        ref_schema_content = """
name: ref_schema
description: Test referencing schema
resources:
  source_schema:
    uri: {resource_path}
tables:
- name: ref_table
  description: Referencing table
  columnRefs:
    source_schema:
      source_table:
        test_column: null  # Explicit null = no overrides, use same name
        renamed_column:
          ref_name: test_column
          overrides:
            description: "Renamed test column"
            datatype: short
            tap:principal: 1
            tap:column_index: 2
"""
        self.ref_schema_path = os.path.join(self.temp_dir, "ref_schema.yaml")
        ref_content = ref_schema_content.format(resource_path=self.source_schema_path)
        with open(self.ref_schema_path, "w") as f:
            f.write(ref_content.strip())

    def tearDown(self) -> None:
        """Clean up test resources."""
        shutil.rmtree(self.temp_dir)

    def test_schema_resource(self) -> None:
        """Test loading a schema as a resource with column references."""
        # First test that the source schema loads correctly on its own
        source_schema = Schema.from_uri(self.source_schema_path, context={"id_generation": True})
        self.assertEqual(source_schema.name, "source_schema")
        self.assertEqual(len(source_schema.tables), 1)
        self.assertEqual(source_schema.tables[0].name, "source_table")

        # Now test loading the ref schema
        ref_schema = Schema.from_uri(self.ref_schema_path, context={"id_generation": True})
        self.assertEqual(ref_schema.name, "ref_schema")

        # Check that the resource was loaded
        self.assertIn("source_schema", ref_schema._resource_map)

        # Check that the referencing table has the expected columns
        ref_table = ref_schema.tables[0]
        self.assertEqual(ref_table.name, "ref_table")

        # Check the column_refs structure
        column_refs = ref_table.column_refs
        self.assertIsNotNone(column_refs)
        self.assertIsInstance(column_refs, dict)

        # Check the schema resource reference
        self.assertIn("source_schema", column_refs)
        source_schema_refs = column_refs["source_schema"]
        self.assertIsInstance(source_schema_refs, dict)

        # Check the table reference
        self.assertIn("source_table", source_schema_refs)
        source_table_refs = source_schema_refs["source_table"]
        self.assertIsInstance(source_table_refs, dict)

        # Verify the column_refs structure details
        # Should have 2 column references: test_column and renamed_column
        self.assertEqual(len(source_table_refs), 2)

        # Check test_column reference (null/no overrides)
        self.assertIn("test_column", source_table_refs)
        test_column_ref = source_table_refs["test_column"]
        self.assertIsNone(test_column_ref)

        # Check renamed_column reference (with ref_name and overrides)
        self.assertIn("renamed_column", source_table_refs)
        renamed_column_ref = source_table_refs["renamed_column"]
        self.assertIsNotNone(renamed_column_ref)
        self.assertEqual(renamed_column_ref.ref_name, "test_column")
        self.assertIsNotNone(renamed_column_ref.overrides)
        self.assertEqual(renamed_column_ref.overrides.description, "Renamed test column")
        self.assertEqual(renamed_column_ref.overrides.tap_principal, 1)
        self.assertEqual(renamed_column_ref.overrides.tap_column_index, 2)
        self.assertEqual(renamed_column_ref.overrides.datatype.value, "short")

        # Now check structure of dereferenced columns in the ref_table
        self.assertEqual(len(ref_table.columns), 2)

        # Check dereferenced test_column (no overrides)
        test_col = next((col for col in ref_table.columns if col.name == "test_column"), None)
        self.assertIsNotNone(test_col)
        self.assertEqual(test_col.datatype, "int")
        self.assertEqual(test_col.description, "Test column")

        # Check dereferenced renamed_column (includes overrides)
        renamed_col = next((col for col in ref_table.columns if col.name == "renamed_column"), None)
        self.assertIsNotNone(renamed_col)
        self.assertEqual(renamed_col.datatype, "short")  # Inherited from source
        self.assertEqual(renamed_col.description, "Renamed test column")
        self.assertEqual(renamed_col.tap_principal, 1)
        self.assertEqual(renamed_col.tap_column_index, 2)

        # Verify that the columns are present in the ID map
        try:
            ref_schema.find_object_by_id(test_col.id, Column)
        except KeyError:
            self.fail(f"Test column ID '{test_col.id}' not found in schema ID map.")
        try:
            ref_schema.find_object_by_id(renamed_col.id, Column)
        except KeyError:
            self.fail(f"Renamed column ID '{renamed_col.id}' not found in schema ID map.")

    def test_schema_resource_missing_column_error(self) -> None:
        """Test that referencing a non-existent column raises an error."""
        error_ref_content = f"""
name: error_ref_schema
description: Test referencing schema with error
resources:
  source_schema:
    uri: {self.source_schema_path}
tables:
- name: error_table
  description: Table with bad reference
  columnRefs:
    source_schema:
      source_table:
        bad_column: null  # This column doesn't exist in source
"""

        error_ref_path = os.path.join(self.temp_dir, "error_ref_schema.yaml")
        with open(error_ref_path, "w") as f:
            f.write(error_ref_content.strip())

        # This should raise a ValueError
        with self.assertRaises(ValueError) as cm:
            Schema.from_uri(error_ref_path, context={"id_generation": True})

        self.assertIn("Column 'bad_column' not found", str(cm.exception))

    def test_schema_resource_missing_ref_name_error(self) -> None:
        """Test that using ref_name for non-existent column raises an error."""
        # Create a ref schema with bad ref_name
        error_ref_content = f"""
name: error_ref_schema
description: Test referencing schema with bad ref_name
resources:
  source_schema:
    uri: {self.source_schema_path}
tables:
- name: error_table
  description: Table with bad ref_name
  columnRefs:
    source_schema:
      source_table:
        some_column:
          ref_name: nonexistent_column  # This column doesn't exist
"""

        error_ref_path = os.path.join(self.temp_dir, "error_ref_schema.yaml")
        with open(error_ref_path, "w") as f:
            f.write(error_ref_content.strip())

        with self.assertRaises(ValueError) as cm:
            Schema.from_uri(error_ref_path, context={"id_generation": True})
        self.assertIn("Column 'nonexistent_column' not found", str(cm.exception))

    def test_schema_resource_not_found_error(self) -> None:
        """Test that referencing a non-existent schema resource raises an
        error.
        """
        error_ref_content = f"""
name: error_ref_schema
description: Test referencing non-existent schema resource
resources:
  source_schema:
    uri: {self.source_schema_path}
tables:
- name: error_table
  description: Table with bad schema resource reference
  columnRefs:
    nonexistent_schema:  # This schema resource doesn't exist
      some_table:
        some_column: null
"""

        error_ref_path = os.path.join(self.temp_dir, "error_ref_schema.yaml")
        with open(error_ref_path, "w") as f:
            f.write(error_ref_content.strip())

        with self.assertRaises(ValueError) as cm:
            Schema.from_uri(error_ref_path, context={"id_generation": True})
        self.assertIn("Schema resource 'nonexistent_schema' was not found in resources", str(cm.exception))

    def test_schema_resource_table_not_found_error(self) -> None:
        """Test that referencing a non-existent table in schema resource raises
        an error.
        """
        error_ref_content = f"""
name: error_ref_schema
description: Test referencing non-existent table in schema resource
resources:
  source_schema:
    uri: {self.source_schema_path}
tables:
- name: error_table
  description: Table with bad table reference
  columnRefs:
    source_schema:
      nonexistent_table:  # This table doesn't exist in source_schema
        some_column: null
"""

        error_ref_path = os.path.join(self.temp_dir, "error_ref_schema.yaml")
        with open(error_ref_path, "w") as f:
            f.write(error_ref_content.strip())

        with self.assertRaises(ValueError) as cm:
            Schema.from_uri(error_ref_path, context={"id_generation": True})
        self.assertIn("Table 'nonexistent_table' not found in resource 'source_schema'", str(cm.exception))

    def test_schema_resource_bad_uri_error(self) -> None:
        """Test that a bad URI in resource loading raises an error."""
        error_ref_content = """
name: error_ref_schema
description: Test schema with bad resource URI
resources:
  bad_resource:
    uri: /nonexistent/path/to/schema.yaml
tables:
- name: error_table
  description: Table referencing bad resource
  columnRefs:
    bad_resource:
      some_table:
        some_column: null
"""

        error_ref_path = os.path.join(self.temp_dir, "error_ref_schema.yaml")
        with open(error_ref_path, "w") as f:
            f.write(error_ref_content.strip())

        with self.assertRaises(ValueError) as cm:
            Schema.from_uri(error_ref_path, context={"id_generation": True})
        self.assertIn(
            "Failed to load resource 'bad_resource' from URI '/nonexistent/path/to/schema.yaml'",
            str(cm.exception),
        )

    def test_ref_schema_with_indexes(self) -> None:
        """Test that indexes are properly handled when loading schema
        resources.
        """
        # Write out referencing schema file
        ref_schema_content_with_indexes = """
name: ref_schema
description: Test referencing schema
resources:
  source_schema:
    uri: {resource_path}
tables:
- name: ref_table
  description: Referencing table
  columnRefs:
    source_schema:
      source_table:
        test_column: null
        renamed_column:
          ref_name: test_column
          overrides:
            description: "Renamed test column"
            tap:principal: 1
            tap:column_index: 2
  indexes:
  - name: idx_test_column
    columns:
      - "#ref_table.test_column"
  - name: idx_renamed_column
    columns:
      - "#ref_table.renamed_column"
"""

        source_schema_with_indexes_path = os.path.join(self.temp_dir, "source_schema_with_indexes.yaml")
        ref_content = ref_schema_content_with_indexes.format(resource_path=self.source_schema_path)
        with open(source_schema_with_indexes_path, "w") as f:
            f.write(ref_content.strip())

        ref_schema = Schema.from_uri(source_schema_with_indexes_path, context={"id_generation": True})

        # Check index content; columns are not automatically resolved to
        # objects by the validation.
        indexes = ref_schema.tables[0].indexes
        self.assertEqual(len(indexes), 2)
        self.assertEqual(indexes[0].name, "idx_test_column")
        self.assertEqual(indexes[0].columns, ["#ref_table.test_column"])
        self.assertEqual(indexes[1].name, "idx_renamed_column")
        self.assertEqual(indexes[1].columns, ["#ref_table.renamed_column"])

    def test_ref_schema_with_foreign_key(self) -> None:
        """Test that indexes are properly handled when loading schema
        resources.
        """
        # Write out referencing schema file
        ref_schema_content_with_foreign_key = """
name: ref_schema
description: Test referencing schema
resources:
  source_schema:
    uri: {resource_path}
tables:
- name: src_table
  description: Source table for foreign key
  primaryKey: "#src_table.test_column"
  columnRefs:
    source_schema:
      source_table:
        test_column: null
        renamed_column:
          ref_name: test_column
          overrides:
            description: "Renamed test column"
            tap:principal: 1
            tap:column_index: 2
- name: target_table
  description: Target table for foreign key
  columns:
  - name: fk_column
    datatype: int
    description: "Foreign key column"
  constraints:
  - name: fk_src_table
    '@type': ForeignKey
    columns:
    - "#target_table.fk_column"
    referencedColumns:
    - "#src_table.test_column"
"""

        source_schema_with_foreign_key_path = os.path.join(
            self.temp_dir, "source_schema_with_foreign_key.yaml"
        )
        ref_content = ref_schema_content_with_foreign_key.format(resource_path=self.source_schema_path)
        with open(source_schema_with_foreign_key_path, "w") as f:
            f.write(ref_content.strip())

        ref_schema = Schema.from_uri(source_schema_with_foreign_key_path, context={"id_generation": True})

        # Check foreign key constraint content
        fk_constraint = ref_schema.tables[1].constraints[0]
        self.assertIsInstance(fk_constraint, ForeignKeyConstraint)
        self.assertEqual(fk_constraint.name, "fk_src_table")
        self.assertEqual(fk_constraint.columns, ["#target_table.fk_column"])
        self.assertEqual(fk_constraint.referenced_columns, ["#src_table.test_column"])

    def test_ref_schema_serialization(self) -> None:
        """Test serialization of a reference schema."""
        # Load the referencing schema and then serialize it back to YAML
        ref_schema = Schema.from_uri(self.ref_schema_path, context={"id_generation": True})
        yaml_data = ref_schema.model_dump(by_alias=True, exclude_none=True, exclude_defaults=True)
        serialized_schema_path = os.path.join(self.temp_dir, "serialized_ref_schema.yaml")
        with open(serialized_schema_path, "w") as f:
            yaml.dump(yaml_data, f, default_flow_style=False, sort_keys=False)

        # Read back the serialized YAML data
        with open(serialized_schema_path) as f:
            serialized_yaml_data = yaml.safe_load(f)

        # Ensure that columns were not serialized directly in the table
        self.assertEqual(len(serialized_yaml_data["tables"][0]["columns"]), 0)

        # Deserialize the schema and check that the expected columns are
        # present
        deserialized_schema = Schema.from_uri(serialized_schema_path, context={"id_generation": True})
        self.assertEqual(len(deserialized_schema.tables[0].columns), 2)

        # Check that the columnRefs structure is still present
        try:
            ref_columns = deserialized_schema.tables[0].column_refs["source_schema"]["source_table"]
        except Exception:
            self.fail("The column refs are missing after deserialization.")
        self.assertEqual(len(ref_columns), 2)

    def test_ref_schema_with_dereference_columns(self) -> None:
        """Test loading a reference schema with dereferencing of columns so
        that column_refs is set to empty after loading.
        """
        ref_schema = Schema.from_uri(
            self.ref_schema_path, context={"id_generation": True, "dereference_resources": True}
        )

        # Check that the columns were dereferenced into the table
        ref_table = ref_schema.tables[0]
        self.assertEqual(len(ref_table.columns), 2)
        col_names = {col.name for col in ref_table.columns}
        self.assertIn("test_column", col_names)
        self.assertIn("renamed_column", col_names)

        # Check that column_refs is empty after dereferencing
        self.assertEqual(len(ref_table.column_refs), 0)

    def test_tap_column_index_with_overrides(self) -> None:
        """Test that TAP column index is correctly assigned when an override
        of that field is present in the column ref.
        """
        # Write out source schema file
        source_schema_content = """
name: source_schema
tables:
- name: source_table
  columns:
  - name: col1
    datatype: int
  - name: col2
    datatype: int
  - name: col3
    datatype: int
"""
        source_schema_path = os.path.join(self.temp_dir, "source_schema.yaml")
        with open(source_schema_path, "w") as f:
            f.write(source_schema_content.strip())

        # Write out referencing schema file
        ref_schema_content = """
name: ref_schema
resources:
  source_schema:
    uri: {resource_path}
tables:
- name: ref_table
  columnRefs:
    source_schema:
      source_table:
        col1:
        col2:
          overrides:
            tap:column_index: 15
        col3:
"""
        ref_schema_path = os.path.join(self.temp_dir, "ref_schema.yaml")
        ref_content = ref_schema_content.format(resource_path=source_schema_path)
        with open(ref_schema_path, "w") as f:
            f.write(ref_content.strip())

        ref_schema = Schema.from_uri(
            ref_schema_path,
            context={"id_generation": True, "column_ref_index_increment": 10},
        )

        for column in ref_schema.tables[0].columns:
            if column.name == "col1":
                self.assertEqual(column.tap_column_index, 10)
            elif column.name == "col2":
                self.assertEqual(column.tap_column_index, 15)
            elif column.name == "col3":
                self.assertEqual(column.tap_column_index, 20)
            else:
                self.fail(f"Unexpected column name: {column.name}")


class ColumnOverridesTestCase(unittest.TestCase):
    """Test application of overrides to a column, setting all allowed
    fields.
    """

    def test_all_override_fields_exist_on_column(self) -> None:
        """Ensure every ColumnOverrides field corresponds to an attribute on
        Column.
        """
        override_fields = set(ColumnOverrides.model_fields)
        column_fields = set(Column.model_fields)

        missing = override_fields - column_fields

        self.assertFalse(
            missing,
            f"Column is missing attributes for override fields: {sorted(missing)}",
        )

    def test_overrides_all(self) -> None:
        """Test updating all allowed column fields from overrides."""
        # Create a base column
        base_column = Column(
            name="base_column",
            id="#base_column",
            description="Base column",
            datatype="char",
            length=64,
            nullable=False,
            tap_principal=1,
            tap_column_index=10,
        )

        # Override all allowed fields with different values
        overrides = ColumnOverrides(
            description="Ref column",
            datatype="string",
            length=256,
            nullable=True,
            tap_principal=0,
            tap_column_index=100,
        )

        # Apply overrides
        base_column._update_from_overrides(overrides)

        # Check that the attributes were updated correctly
        self.assertEqual(base_column.description, "Ref column")
        self.assertEqual(base_column.datatype, "string")
        self.assertEqual(base_column.length, 256)
        self.assertEqual(base_column.nullable, True)
        self.assertEqual(base_column.tap_principal, 0)
        self.assertEqual(base_column.tap_column_index, 100)

    def test_overrides_subset(self) -> None:
        """Test updating a subset of allowed column fields from overrides."""
        # Create a base column
        base_column = Column(
            name="base_column",
            id="#base_column",
            description="Base column",
            datatype="char",
            length=64,
            nullable=False,
            tap_principal=1,
            tap_column_index=10,
        )

        # Override all allowed fields with different values
        overrides = ColumnOverrides(
            description="Ref column",
            tap_column_index=100,
        )

        # Apply overrides
        base_column._update_from_overrides(overrides)

        # Check that the attributes were updated correctly
        self.assertEqual(base_column.description, "Ref column")
        self.assertEqual(base_column.datatype, "char")
        self.assertEqual(base_column.length, 64)
        self.assertEqual(base_column.nullable, False)
        self.assertEqual(base_column.tap_principal, 1)
        self.assertEqual(base_column.tap_column_index, 100)

    def test_overrides_default(self) -> None:
        """Test that applying the default overrides is a no-op."""
        # Create a base column
        base_column = Column(
            name="base_column",
            id="#base_column",
            description="Base column",
            datatype="char",
            length=64,
            nullable=False,
            tap_principal=1,
            tap_column_index=10,
        )

        # Apply overrides
        base_column._update_from_overrides(ColumnOverrides())

        # Check that the attributes remain unchanged
        self.assertEqual(base_column.description, "Base column")
        self.assertEqual(base_column.datatype, "char")
        self.assertEqual(base_column.length, 64)
        self.assertEqual(base_column.nullable, False)
        self.assertEqual(base_column.tap_principal, 1)
        self.assertEqual(base_column.tap_column_index, 10)

    def test_overrides_with_explicit_none_values(self) -> None:
        """Test that passing explicit None values in overrides does update
        the column attributes where allowed and raises errors if it is not.
        """
        # Create a base column
        base_column = Column(
            name="base_column",
            id="#base_column",
            description="Base column",
            datatype="int",
            length=64,
            nullable=False,
            tap_principal=1,
            tap_column_index=10,
        )

        # Create overrides with explicit None values for nullable fields
        overrides = ColumnOverrides(
            description=None,
            tap_column_index=None,
        )

        # Apply overrides
        base_column._update_from_overrides(overrides)

        # Check that the attributes were updated to None where allowed
        self.assertIsNone(base_column.description)
        self.assertIsNone(base_column.tap_column_index)

        # Check that setting non-nullable fields to None raise a specific
        # ValueError on ColumnOverrides creation
        for non_nullable_field in ("datatype", "length", "nullable", "tap_principal"):
            with self.assertRaisesRegex(
                ValueError,
                re.escape(f"The '{non_nullable_field}' field cannot be overridden to null"),
            ):
                ColumnOverrides(**{non_nullable_field: None})

    def test_extra_fields_in_overrides(self) -> None:
        """Test that extra fields in ColumnOverrides raise a
        ValidationError.
        """
        with self.assertRaises(ValidationError) as cm:
            ColumnOverrides(
                description="Test column",
                extra_field="This should not be allowed",
            )

        self.assertIn("Extra inputs are not permitted", str(cm.exception))

    def test_overrides_accept_alias_keys(self) -> None:
        """Test that alias keys for TAP fields are accepted and populate the
        corresponding model fields.
        """
        overrides = ColumnOverrides(**{"tap:principal": 1, "tap:column_index": 42})

        self.assertEqual(overrides.tap_principal, 1)
        self.assertEqual(overrides.tap_column_index, 42)

        # Ensure these count as explicitly provided (for model_fields_set
        # logic).
        self.assertIn("tap_principal", overrides.model_fields_set)
        self.assertIn("tap_column_index", overrides.model_fields_set)

    def test_datatype_deserialize_and_serialize(self) -> None:
        """Test that datatype is deserialized from a string to DataType and
        serialized back to a string.
        """
        overrides = ColumnOverrides(datatype="char")

        # Deserialization should yield a DataType instance (not a raw str).
        self.assertIsInstance(overrides.datatype, DataType)
        self.assertEqual(str(overrides.datatype), "char")

        # Serialization should produce a JSON-friendly string value.
        dumped = overrides.model_dump(mode="json")
        self.assertEqual(dumped["datatype"], "char")

        # None should remain None on serialization.
        overrides_none = ColumnOverrides()
        dumped_none = overrides_none.model_dump(mode="json")
        self.assertIsNone(dumped_none["datatype"])

    def test_non_nullable_overrides_data_is_none(self) -> None:
        """Test that passing None to ``_check_non_nullable_overrides`` does not
        raise an error.
        """
        ColumnOverrides()._check_non_nullable_overrides(None)


if __name__ == "__main__":
    unittest.main()
