import operator
from typing import *

__all__ = ["iterprod"]


def iterprod(*iterables: Iterable, repeat: SupportsIndex = 1) -> Generator:
    indeces: list
    lengths: tuple
    pools: list[tuple[Any, ...]]
    repeat_: int
    repeat_ = operator.index(repeat)
    if repeat_ < 0:
        raise ValueError(
            "The keyword argument repeat cannot be negative, but %r was given." % repeat
        )
    pools = list(map(tuple, iterables)) * repeat_
    indeces = [0] * len(pools)
    lengths = tuple(map(len, pools))
    while True:
        yield tuple(map(operator.getitem, pools, indeces))
        try:
            incr(indeces, lengths)
        except IndexError:
            return


def incr(indeces: list, lengths: tuple) -> None:
    j: int
    indeces[-1] += 1
    j = -1
    while True:
        if indeces[j] < lengths[j]:
            return
        indeces[j] = 0
        indeces[j - 1] += 1
        j -= 1
