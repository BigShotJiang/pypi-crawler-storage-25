# ms365-toolkit — Project Instructions

## What This Is
Multi-consumer MS365 email + calendar toolkit with a non-negotiable safety layer. Intended for local CLI use, MCP server use, and read-only adapter integration.

## Architecture
```
src/ms365_toolkit/
├── models/         # Frozen dataclasses: EmailMessage, EmailDraft, CalendarEvent, FreeBusySlot, enums
├── auth/           # MSAL device-code flow, Keychain 2-token split, refresh, scope constants
├── client/         # GraphClient (urllib), EmailClient, CalendarClient, endpoint flexibility (/me/ vs /users/{upn}/)
├── intelligence/   # Email triage, calendar scoring, VIP, morning_brief(), day_overview()
├── safety/         # SafetyGate: OS dialog, SHA-256 draft binding, allowlists, rate limiter, audit
├── config/         # TOML loading, multi-profile (~/.ms365-toolkit/profiles/{name}/), validation
├── mcp/            # FastMCP server, 20 tools via @mcp.tool(), stdio transport
├── cli/            # Auth login/revoke, config init, profile mgmt, serve
└── adapter/        # Optional provider integration layer (read-only)
```

## TDD Workflow
```
1. RED:    Write the test first
2. GREEN:  Write minimum code to pass
3. REFACTOR: Clean up, add types, add structlog logging
4. VERIFY: make tdd → make lint
```

## Make Commands
```bash
make tdd          # Fast TDD loop: ruff fix + unit tests (--maxfail=1)
make test         # Unit tests only
make test-safety  # Adversarial safety tests only
make test-all     # All tests with coverage (fail under 80%)
make lint         # ruff check + mypy --strict
make format       # ruff format + fix
make ci           # Full pipeline: lint + all tests
make serve        # Run MCP server (stdio)
```

## Key Conventions
- **Package**: `ms365_toolkit` (under `src/ms365_toolkit/`)
- **Python**: 3.11+ (tomllib and zoneinfo are stdlib)
- **Logging**: structlog throughout. Write-ops get JSONL audit (0600 perms).
- **Types**: mypy --strict. All functions have type annotations.
- **Safety**: ALL write operations go through SafetyGate. No exceptions.
- **Tests**: pytest markers: `@pytest.mark.unit`, `@pytest.mark.safety`

## Safety Layer (Non-Negotiable)
Every write operation goes through this chain:
```
Tool call → config reload (atomic, mtime) → domain/folder allowlist
→ rate limiter (SQLite WAL) → draft SHA-256 hash → OS dialog (osascript)
→ re-verify hash → Graph API call → audit log (JSONL, 0600)
```

Key rules:
1. SafetyGate is a constructor dependency for all Write* clients — no bypass possible
2. OS dialog uses osascript — macOS only for v1, fail-closed on non-macOS
3. Hash computed from LOCAL canonical payload, never from Graph's stored draft
4. Write tokens are keychain-only by default (no env without --insecure-env-write)
5. All denials are audited with reason codes (no bodies/subjects, hashed domains)
6. Config uses atomic replace (temp+fsync+rename), pinned at gate entry

## Git Identity
identity: personal
