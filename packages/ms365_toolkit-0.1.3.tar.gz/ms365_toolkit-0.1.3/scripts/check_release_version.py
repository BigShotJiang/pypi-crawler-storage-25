import os
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ROOT_PYPROJECT = ROOT / "pyproject.toml"
WRAPPER_PYPROJECT = ROOT / "packages" / "ms365-toolkit-mcp" / "pyproject.toml"


def main() -> int:
    root_version = _read_version(ROOT_PYPROJECT)
    wrapper_version = _read_version(WRAPPER_PYPROJECT)
    if root_version != wrapper_version:
        raise SystemExit(
            f"version mismatch: root={root_version} wrapper={wrapper_version}"
        )

    git_ref = os.environ.get("GITHUB_REF_NAME")
    if git_ref:
        expected_tag = f"v{root_version}"
        if git_ref != expected_tag:
            raise SystemExit(
                f"tag mismatch: expected {expected_tag} from package version, got {git_ref}"
            )
    print(root_version)
    return 0


def _read_version(path: Path) -> str:
    parsed = tomllib.loads(path.read_text(encoding="utf-8"))
    version = parsed["project"]["version"]
    if not isinstance(version, str) or not version:
        raise SystemExit(f"missing project.version in {path}")
    return version


if __name__ == "__main__":
    raise SystemExit(main())
