#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE="default"
SERVER_NAME="ms365"
TARGET="both"
CLAUDE_SCOPE="user"
DRY_RUN=0

usage() {
  cat <<EOF
Usage: $(basename "$0") [options]

Install the repo-local MS365 MCP server and register it with Codex and/or Claude.

Options:
  --profile NAME         MS365 toolkit profile to use (default: default)
  --name NAME            MCP server name to register (default: ms365)
  --target TARGET        codex, claude, or both (default: both)
  --claude-scope SCOPE   local, user, or project (default: user)
  --dry-run              Print commands without executing them
  -h, --help             Show this help text
EOF
}

run() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '+'
    printf ' %q' "$@"
    printf '\n'
    return 0
  fi
  "$@"
}

toolkit() {
  run uv run --directory "$ROOT_DIR" ms365-toolkit --profile "$PROFILE" "$@"
}

have_command() {
  command -v "$1" >/dev/null 2>&1
}

remove_codex_server_if_present() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    run codex mcp remove "$SERVER_NAME"
    return 0
  fi
  codex mcp remove "$SERVER_NAME" >/dev/null 2>&1 || true
}

remove_claude_server_if_present() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    run claude mcp remove -s "$CLAUDE_SCOPE" "$SERVER_NAME"
    return 0
  fi
  claude mcp remove -s "$CLAUDE_SCOPE" "$SERVER_NAME" >/dev/null 2>&1 || true
}

register_codex() {
  if ! have_command codex; then
    echo "codex CLI not found on PATH" >&2
    return 1
  fi
  remove_codex_server_if_present
  run codex mcp add "$SERVER_NAME" \
    --env "MS365_TOOLKIT_PROFILE=$PROFILE" \
    -- \
    uv run --directory "$ROOT_DIR" --extra mcp ms365-toolkit-mcp
}

register_claude() {
  if ! have_command claude; then
    echo "claude CLI not found on PATH" >&2
    return 1
  fi
  remove_claude_server_if_present
  run claude mcp add -s "$CLAUDE_SCOPE" \
    "$SERVER_NAME" \
    -e "MS365_TOOLKIT_PROFILE=$PROFILE" \
    -- \
    uv run --directory "$ROOT_DIR" --extra mcp ms365-toolkit-mcp
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile)
      PROFILE="$2"
      shift 2
      ;;
    --name)
      SERVER_NAME="$2"
      shift 2
      ;;
    --target)
      TARGET="$2"
      shift 2
      ;;
    --claude-scope)
      CLAUDE_SCOPE="$2"
      shift 2
      ;;
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if [[ "$TARGET" != "codex" && "$TARGET" != "claude" && "$TARGET" != "both" ]]; then
  echo "--target must be one of: codex, claude, both" >&2
  exit 1
fi

if [[ "$CLAUDE_SCOPE" != "local" && "$CLAUDE_SCOPE" != "user" && "$CLAUDE_SCOPE" != "project" ]]; then
  echo "--claude-scope must be one of: local, user, project" >&2
  exit 1
fi

if ! have_command uv; then
  echo "uv is required but not found on PATH" >&2
  exit 1
fi

run uv sync --directory "$ROOT_DIR" --extra mcp
toolkit auth status

case "$TARGET" in
  codex)
    register_codex
    ;;
  claude)
    register_claude
    ;;
  both)
    register_codex
    register_claude
    ;;
esac

cat <<EOF
Setup complete.

Server name: $SERVER_NAME
Profile: $PROFILE
Target: $TARGET
Repo: $ROOT_DIR

Smoke test:
  uv run --directory "$ROOT_DIR" --extra mcp ms365-toolkit-mcp --help
EOF
