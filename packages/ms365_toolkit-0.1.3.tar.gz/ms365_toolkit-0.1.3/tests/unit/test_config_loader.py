from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING

import pytest

from ms365_toolkit.config.loader import ConfigError, get_config_path, load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path


def test_load_config_parses_and_tracks_metadata(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    content = _config_text()
    write_config_text(config_path, content)

    config = load_config(base_dir=tmp_path)

    assert config.profile == "default"
    assert config.auth.tenant_id == "tenant-id"
    assert config.user.endpoint == "me"
    assert config.safety.domain_allowlist == ("example.com", ".example.com")
    assert config.safety.rate_limits.send_email_per_hour == 5
    assert config.vip.emails == ("vip@example.com",)
    assert config.intelligence.action_keywords == ("urgent", "approve")
    assert config.config_hash == hashlib.sha256(content.encode("utf-8")).hexdigest()
    assert config.config_mtime == pytest.approx(config_path.stat().st_mtime)


def test_load_config_warns_when_domain_allowlist_empty(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    content = _config_text().replace(
        'domain_allowlist = ["example.com", ".example.com"]',
        "domain_allowlist = []",
    )
    write_config_text(config_path, content)

    with pytest.warns(UserWarning, match="domain_allowlist is empty"):
        load_config(base_dir=tmp_path)


def test_load_config_rejects_tld_only_allowlist_entries(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    content = _config_text().replace(
        'domain_allowlist = ["example.com", ".example.com"]',
        'domain_allowlist = [".com"]',
    )
    write_config_text(config_path, content)

    with pytest.raises(ConfigError, match="too broad"):
        load_config(base_dir=tmp_path)


def test_load_config_rejects_public_suffix_entries(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    content = _config_text().replace(
        'domain_allowlist = ["example.com", ".example.com"]',
        'domain_allowlist = [".co.uk"]',
    )
    write_config_text(config_path, content)

    with pytest.raises(ConfigError, match="public suffix"):
        load_config(base_dir=tmp_path)


def test_load_config_rejects_non_positive_rate_limits(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    content = _config_text().replace("send_email_per_hour = 5", "send_email_per_hour = 0")
    write_config_text(config_path, content)

    with pytest.raises(ConfigError, match="send_email_per_hour must be a positive integer"):
        load_config(base_dir=tmp_path)


def test_load_config_rejects_boolean_rate_limits(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    content = _config_text().replace("send_email_per_hour = 5", "send_email_per_hour = true")
    write_config_text(config_path, content)

    with pytest.raises(ConfigError, match="send_email_per_hour must be an integer"):
        load_config(base_dir=tmp_path)


def test_load_config_requires_user_principal_name_for_users_endpoint(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    content = _config_text().replace('endpoint = "me"', 'endpoint = "users"').replace(
        'user_principal_name = ""', 'user_principal_name = "leader@example.com"'
    )
    write_config_text(config_path, content)

    config = load_config(base_dir=tmp_path)

    assert config.user.endpoint == "users"
    assert config.user.user_principal_name == "leader@example.com"


def test_load_config_rejects_missing_user_principal_name_for_users_endpoint(tmp_path: Path) -> None:
    config_path = get_config_path(base_dir=tmp_path)
    write_config_text(config_path, _config_text().replace('endpoint = "me"', 'endpoint = "users"'))

    with pytest.raises(ConfigError, match=r"user\.user_principal_name is required"):
        load_config(base_dir=tmp_path)


def test_write_config_text_is_atomic_for_new_file(tmp_path: Path) -> None:
    target = tmp_path / "profiles" / "default" / "config.toml"

    write_config_text(target, "value = 1\n")

    assert target.read_text() == "value = 1\n"
    assert list(target.parent.glob(".*.tmp")) == []


def _config_text() -> str:
    return """
[auth]
tenant_id = "tenant-id"
client_id = "client-id"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com", ".example.com"]
folder_allowlist = ["Archive", "Follow Up"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = ["vip@example.com"]
domains = ["example.com"]

[intelligence]
critical_keywords = ["exec"]
noise_keywords = ["ooo"]
action_keywords = ["urgent", "approve"]
""".strip()
