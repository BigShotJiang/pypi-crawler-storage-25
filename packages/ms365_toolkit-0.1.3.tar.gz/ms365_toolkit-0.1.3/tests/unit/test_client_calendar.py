from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from ms365_toolkit.client.calendar import CalendarClient
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.config.loader import load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path


def test_list_events_uses_calendar_view_endpoint(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    client.list_events(
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
    )

    assert "/me/calendarView?" in captured["url"]
    assert "startDateTime=2026-03-12T09:00:00Z" in captured["url"]


def test_get_event_maps_graph_payload_to_calendar_event(tmp_path: Path) -> None:
    client = CalendarClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(_event_item("event-1")),
        )
    )

    event = client.get_event("event-1")

    assert event.id == "event-1"
    assert event.subject == "Planning"
    assert event.location == "Room A"
    assert event.body_content == "Agenda"
    assert event.attendees[0].email == "a@example.com"
    assert event.start == datetime(2026, 3, 12, 9, tzinfo=UTC)


def test_find_free_slots_uses_get_schedule(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        captured["body"] = req.data.decode("utf-8")
        return _response(
            {
                "value": [
                    {
                        "scheduleItems": [
                            {
                                "start": {"dateTime": "2026-03-12T09:00:00Z"},
                                "end": {"dateTime": "2026-03-12T09:30:00Z"},
                                "status": "busy",
                            }
                        ]
                    }
                ]
            }
        )

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    slots = client.find_free_slots(
        attendees=["a@example.com"],
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
        duration=30,
    )

    assert captured["url"].endswith("/me/calendar/getSchedule")
    assert '"availabilityViewInterval": 30' in captured["body"]
    assert slots[0].status == "busy"


def test_search_events_builds_filter(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    client.search_events(
        query="board",
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
    )

    assert "contains(subject,'board')" in captured["url"]
    assert "start%2FdateTime+ge+'2026-03-12T09:00:00Z'" in captured["url"]


def test_search_events_escapes_odata_quotes(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    client.search_events(query="o'brien")

    assert "contains(subject,'o''brien')" in captured["url"]


class _FakeResponse:
    def __init__(self, payload: dict[str, Any]) -> None:
        import json

        self._payload = json.dumps(payload).encode("utf-8")

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload


def _response(payload: dict[str, Any]) -> _FakeResponse:
    return _FakeResponse(payload)


def _event_item(event_id: str) -> dict[str, Any]:
    return {
        "id": event_id,
        "subject": "Planning",
        "start": {"dateTime": "2026-03-12T09:00:00Z", "timeZone": "UTC"},
        "end": {"dateTime": "2026-03-12T10:00:00Z", "timeZone": "UTC"},
        "location": {"displayName": "Room A"},
        "body": {"content": "<p>Agenda</p>"},
        "attendees": [
            {
                "emailAddress": {"address": "a@example.com", "name": "A"},
                "status": {"response": "accepted"},
                "type": "required",
            }
        ],
        "isOnlineMeeting": True,
        "isCancelled": False,
        "importance": "high",
        "categories": ["Work"],
        "recurrence": None,
        "organizer": {"emailAddress": {"address": "owner@example.com"}},
        "responseStatus": {"response": "accepted"},
        "calendar": {"id": "calendar-1"},
    }


def _config(tmp_path: Path) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
