from __future__ import annotations

import json
from datetime import UTC, datetime

from ms365_toolkit.models.calendar import Attendee, CalendarEvent
from ms365_toolkit.models.email import AttachmentInfo, EmailDraft
from ms365_toolkit.safety.canonical import (
    canonicalize_body,
    canonicalize_email,
    canonicalize_event,
    compute_hash,
)


def test_canonicalize_body_collapses_whitespace() -> None:
    assert canonicalize_body("  hello \n\t world  ") == "hello world"


def test_canonicalize_email_normalizes_addresses_and_excludes_reference_attachments() -> None:
    draft = EmailDraft(
        draft_id="draft-1",
        content_hash="unused",
        to=("B@EXAMPLE.com ", "a@example.com"),
        cc=("c@example.com",),
        bcc=(),
        subject="Subject",
        body="  Hello \n world ",
        attachments=(
            AttachmentInfo("b.txt", "text/plain", 1, "hash-b", False),
            AttachmentInfo("cloud.docx", "application/vnd", 1, "ignored", True),
            AttachmentInfo("a.txt", "text/plain", 1, "hash-a", False),
        ),
        reply_to=("Reply@Example.com",),
        importance="high",
        created_at=datetime(2026, 3, 12, tzinfo=UTC),
    )

    canonical = json.loads(canonicalize_email(draft))

    assert canonical["to"] == ["a@example.com", "b@example.com"]
    assert canonical["reply_to"] == ["reply@example.com"]
    assert canonical["body_content"] == "Hello world"
    assert canonical["attachments"] == [
        {"name": "a.txt", "sha256": "hash-a"},
        {"name": "b.txt", "sha256": "hash-b"},
    ]


def test_canonicalize_event_normalizes_attendees_and_utc_timestamps() -> None:
    event = CalendarEvent(
        id="event-1",
        subject="Planning",
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
        timezone="America/Chicago",
        location="Room A",
        body_content=" Agenda \n items ",
        attendees=(
            Attendee("B@Example.com", "B", "accepted", "required"),
            Attendee("a@example.com", "A", "accepted", "required"),
        ),
        is_online_meeting=True,
        is_cancelled=False,
        importance="normal",
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
    )

    canonical = json.loads(canonicalize_event(event))

    assert canonical["attendees"] == ["a@example.com", "b@example.com"]
    assert canonical["start"] == "2026-03-12T09:00:00Z"
    assert canonical["end"] == "2026-03-12T10:00:00Z"
    assert canonical["body_content"] == "Agenda items"


def test_compute_hash_is_stable_for_same_canonical_payload() -> None:
    canonical = '{"a":1}'

    assert compute_hash(canonical) == compute_hash(canonical)

