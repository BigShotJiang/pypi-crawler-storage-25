from __future__ import annotations

from argparse import Namespace
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from ms365_toolkit.cli.inbox import inbox_command
from ms365_toolkit.models.email import EmailMessage

if TYPE_CHECKING:
    import pytest


def test_inbox_command_prints_messages(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.inbox.build_read_clients",
        lambda config, profile: (_FakeEmailClient(), _FakeCalendarClient()),
    )

    exit_code = inbox_command(
        Namespace(profile="default", filter="focused", top=5),
        _config(),
    )

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "sender@example.com" in output
    assert "Hello" in output


class _FakeEmailClient:
    def list_inbox(self, *, mailbox_filter: str | None, top: int, skip: int) -> list[EmailMessage]:
        assert mailbox_filter == "focused"
        assert top == 5
        assert skip == 0
        return [
            EmailMessage(
                id="msg-1",
                subject="Hello",
                sender="sender@example.com",
                to=("to@example.com",),
                cc=(),
                bcc=(),
                body_preview="Preview",
                body_content="Body",
                received_at=datetime(2026, 3, 12, tzinfo=UTC),
                is_read=False,
                is_flagged=False,
                importance="normal",
                has_attachments=False,
                attachments=(),
                conversation_id="conv",
                folder_id="folder",
            )
        ]


class _FakeCalendarClient:
    pass


def _config():
    class StubAuth:
        tenant_id = "tenant"
        client_id = "client"

    class StubUser:
        endpoint = "me"
        user_principal_name = "owner@example.com"
        timezone = "UTC"

    class StubSafety:
        domain_allowlist = ("example.com",)

    class StubVip:
        emails = ()
        domains = ()

    class StubIntelligence:
        critical_keywords = ()
        noise_keywords = ()
        action_keywords = ()

    class StubConfig:
        profile = "default"
        auth = StubAuth()
        user = StubUser()
        safety = StubSafety()
        vip = StubVip()
        intelligence = StubIntelligence()
        config_hash = "hash"
        config_mtime = 0.0
        config_path = None

    return StubConfig()
