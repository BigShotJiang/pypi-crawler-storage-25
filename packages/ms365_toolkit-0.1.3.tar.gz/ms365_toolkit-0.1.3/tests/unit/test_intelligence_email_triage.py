from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pytest

from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.intelligence.email_triage import triage_email
from ms365_toolkit.models.email import EmailMessage
from ms365_toolkit.models.enums import Badge

if TYPE_CHECKING:
    from pathlib import Path


def test_triage_email_assigns_priority_and_action_required(tmp_path: Path) -> None:
    config = _config(tmp_path)
    email = _email(
        sender="vip@example.com",
        subject="Board approve request",
        body_preview="Please approve",
        body_content="Board approve request",
        importance="high",
        is_flagged=False,
    )

    result = triage_email(email, config)

    assert result.badge == Badge.PRIORITY
    assert result.action_required is True
    assert result.summary.count("\n") == 2


def test_triage_email_prefers_flagged_then_vip_then_external(tmp_path: Path) -> None:
    config = _config(tmp_path)

    flagged = triage_email(_email(sender="vip@example.com", is_flagged=True), config)
    vip = triage_email(_email(sender="vip@example.com"), config)
    external = triage_email(_email(sender="outside@outside.com"), config)

    assert flagged.badge == Badge.FLAGGED
    assert vip.badge == Badge.VIP
    assert external.badge == Badge.EXTERNAL


def test_triage_email_treats_unknown_domain_as_external_when_no_context(tmp_path: Path) -> None:
    config_path = tmp_path / "default" / "config.toml"
    write_config_text(
        config_path,
        _config_text()
        .replace('endpoint = "users"', 'endpoint = "me"')
        .replace('user_principal_name = "owner@example.com"', 'user_principal_name = ""')
        .replace('domain_allowlist = ["example.com"]', "domain_allowlist = []"),
    )
    with pytest.warns(UserWarning, match="domain_allowlist is empty"):
        config = load_config(base_dir=tmp_path)

    result = triage_email(_email(sender="outside@outside.com"), config)

    assert result.badge == Badge.EXTERNAL


def test_triage_email_treats_allowlisted_subdomain_as_internal(tmp_path: Path) -> None:
    config_path = tmp_path / "default" / "config.toml"
    write_config_text(
        config_path,
        _config_text().replace(
            'domain_allowlist = ["example.com"]',
            'domain_allowlist = [".example.com"]',
        ),
    )
    config = load_config(base_dir=tmp_path)

    result = triage_email(_email(sender="teammate@alerts.example.com"), config)

    assert result.badge == Badge.NONE


def _email(
    *,
    sender: str,
    subject: str = "Hello",
    body_preview: str = "Preview",
    body_content: str = "Body",
    importance: str = "normal",
    is_flagged: bool = False,
) -> EmailMessage:
    return EmailMessage(
        id="msg-1",
        subject=subject,
        sender=sender,
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview=body_preview,
        body_content=body_content,
        received_at=datetime(2026, 3, 12, tzinfo=UTC),
        is_read=False,
        is_flagged=is_flagged,
        importance=importance,
        has_attachments=False,
        attachments=(),
        conversation_id="conv-1",
        folder_id="folder-1",
    )


def _config(tmp_path: Path):
    config_path = tmp_path / "default" / "config.toml"
    write_config_text(config_path, _config_text())
    return load_config(base_dir=tmp_path)


def _config_text() -> str:
    return """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "users"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = ["vip@example.com"]
domains = ["vip-domain.com"]

[intelligence]
critical_keywords = ["board"]
noise_keywords = ["ooo"]
action_keywords = ["approve"]
""".strip()
