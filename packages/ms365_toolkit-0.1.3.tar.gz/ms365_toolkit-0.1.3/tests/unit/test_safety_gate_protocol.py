from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.safety.gate import (
    AuditEvent,
    DialogPreview,
    NoOpSafetyGate,
    SafetyResult,
    WriteOperation,
)

if TYPE_CHECKING:
    from ms365_toolkit.safety.gate import SafetyGate


def test_noop_safety_gate_satisfies_protocol() -> None:
    gate: SafetyGate = NoOpSafetyGate()

    assert gate.check_domain(("a@example.com",)) == SafetyResult(True, "allowed:1")
    assert gate.check_folder("folder-1") == SafetyResult(True, "folder-1")
    assert gate.check_rate_limit("send_email") == SafetyResult(True, "send_email")


def test_noop_safety_gate_records_audit_events() -> None:
    gate = NoOpSafetyGate()
    event = AuditEvent(tool_name="send_email", action="allow")

    gate.audit(event)

    assert gate.audit_log == [event]


def test_noop_safety_gate_verifies_hashes_and_full_check() -> None:
    gate = NoOpSafetyGate()

    assert gate.show_dialog(DialogPreview(title="Confirm", body="Body")) == SafetyResult(
        True, "Confirm"
    )
    assert gate.verify_hash("abc", "abc") == SafetyResult(True, "hash_match")
    assert gate.verify_hash("abc", "def") == SafetyResult(False, "hash_mismatch")
    assert gate.full_check(WriteOperation(tool_name="send_email", payload_hash="abc")) == (
        SafetyResult(True, "send_email")
    )
