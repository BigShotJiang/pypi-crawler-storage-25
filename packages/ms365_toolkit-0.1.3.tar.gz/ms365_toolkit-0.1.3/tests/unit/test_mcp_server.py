from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

import pytest
from fastmcp.exceptions import ToolError

from ms365_toolkit.client.exceptions import AuthenticationError
from ms365_toolkit.mcp import create_server
from ms365_toolkit.mcp.__main__ import main
from ms365_toolkit.models.calendar import Attendee, CalendarEvent
from ms365_toolkit.models.email import EmailMessage
from ms365_toolkit.models.teams import (
    ChannelSummary,
    TeamsChat,
    TeamsMessage,
    TeamsParticipant,
    TeamsReplyPage,
    TeamsSender,
    TeamsThread,
    TeamSummary,
)


@pytest.mark.asyncio
async def test_create_server_registers_expected_tool_names() -> None:
    server = create_server(runtime=_FakeRuntime())

    tools = await server.list_tools()

    assert [tool.name for tool in tools] == [
        "list_inbox",
        "search_emails",
        "read_email",
        "list_folders",
        "list_events",
        "get_event",
        "search_events",
        "list_calendars",
        "find_free_slots",
        "list_chats",
        "search_chats",
        "list_chat_messages",
        "search_chat_messages",
        "read_chat_message",
        "list_teams",
        "list_channels",
        "list_channel_messages",
        "search_channel_messages",
        "list_channel_replies",
        "read_channel_message",
        "read_channel_thread",
    ]


@pytest.mark.asyncio
async def test_list_inbox_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})

    assert result.structured_content == {
        "messages": [
            {
                "id": "msg-1",
                "subject": "Hello",
                "sender": "sender@example.com",
                "to": ["to@example.com"],
                "cc": [],
                "bcc": [],
                "body_preview": "Preview",
                "body_content": "<untrusted-email-content>Hello</untrusted-email-content>",
                "received_at": "2026-04-03T12:00:00Z",
                "is_read": False,
                "is_flagged": True,
                "importance": "high",
                "has_attachments": False,
                "attachments": [],
                "conversation_id": "conversation-1",
                "folder_id": "folder-1",
            }
        ]
    }


@pytest.mark.asyncio
async def test_list_events_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_events",
        {"start": "2026-04-03T09:00:00Z", "end": "2026-04-03T10:00:00Z"},
    )

    assert result.structured_content == {
        "events": [
            {
                "id": "event-1",
                "subject": "Planning",
                "start": "2026-04-03T09:00:00Z",
                "end": "2026-04-03T09:30:00Z",
                "timezone": "UTC",
                "location": "Room A",
                "body_content": "Agenda",
                "attendees": [
                    {
                        "email": "person@example.com",
                        "name": "Person",
                        "response": "accepted",
                        "type": "required",
                    }
                ],
                "is_online_meeting": False,
                "is_cancelled": False,
                "importance": "normal",
                "categories": ["Work"],
                "recurrence": None,
                "organizer": "owner@example.com",
                "response_status": "accepted",
                "calendar_id": "calendar-1",
            }
        ]
    }


@pytest.mark.asyncio
async def test_find_free_slots_returns_open_windows_after_ignores() -> None:
    runtime = _FakeRuntime(
        graph_response={
            "value": [
                {
                    "scheduleItems": [
                        {
                            "status": "busy",
                            "subject": "Lunch",
                            "start": {"dateTime": "2026-04-03T12:00:00Z"},
                            "end": {"dateTime": "2026-04-03T12:30:00Z"},
                        },
                        {
                            "status": "busy",
                            "subject": "Planning",
                            "start": {"dateTime": "2026-04-03T13:00:00Z"},
                            "end": {"dateTime": "2026-04-03T14:00:00Z"},
                        },
                    ]
                },
                {
                    "scheduleItems": [
                        {
                            "status": "tentative",
                            "subject": "Workout",
                            "start": {"dateTime": "2026-04-03T12:30:00Z"},
                            "end": {"dateTime": "2026-04-03T13:00:00Z"},
                        },
                        {
                            "status": "oof",
                            "subject": "OOO",
                            "start": {"dateTime": "2026-04-03T14:30:00Z"},
                            "end": {"dateTime": "2026-04-03T15:00:00Z"},
                        },
                    ]
                },
            ]
        }
    )
    server = create_server(runtime=runtime)

    result = await server.call_tool(
        "find_free_slots",
        {
            "attendees": ["a@example.com", "b@example.com"],
            "start": "2026-04-03T12:00:00Z",
            "end": "2026-04-03T16:00:00Z",
            "duration_minutes": 30,
            "ignore_subject_terms": ["lunch", "workout"],
        },
    )

    assert result.structured_content == {
        "windows": [
            {
                "start": "2026-04-03T12:00:00Z",
                "end": "2026-04-03T13:00:00Z",
                "duration_minutes": 60,
            },
            {
                "start": "2026-04-03T14:00:00Z",
                "end": "2026-04-03T14:30:00Z",
                "duration_minutes": 30,
            },
            {
                "start": "2026-04-03T15:00:00Z",
                "end": "2026-04-03T16:00:00Z",
                "duration_minutes": 60,
            },
        ]
    }
    assert runtime.graph_calls[0]["body"]["availabilityViewInterval"] == 30


@pytest.mark.asyncio
async def test_list_chats_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_chats", {"top": 5})

    assert result.structured_content == {
        "chats": [
            {
                "id": "chat-1",
                "topic": "Madeline",
                "display_label": "Madeline",
                "chat_type": "oneOnOne",
                "created_at": "2026-04-03T12:00:00Z",
                "last_updated_at": "2026-04-03T12:05:00Z",
                "last_message_read_at": "2026-04-03T12:06:00Z",
                "web_url": "",
                "is_hidden": False,
                "is_hidden_for_all_members": False,
                "other_participants": [
                    {
                        "display_name": "Madeline",
                        "email": "madeline@example.com",
                        "user_id": "user-2",
                    }
                ],
            }
        ]
    }


@pytest.mark.asyncio
async def test_search_chats_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("search_chats", {"query": "madeline", "top": 5})

    assert result.structured_content == {
        "chats": [
            {
                "id": "chat-1",
                "topic": "Madeline",
                "display_label": "Madeline",
                "chat_type": "oneOnOne",
                "created_at": "2026-04-03T12:00:00Z",
                "last_updated_at": "2026-04-03T12:05:00Z",
                "last_message_read_at": "2026-04-03T12:06:00Z",
                "web_url": "",
                "is_hidden": False,
                "is_hidden_for_all_members": False,
                "other_participants": [
                    {
                        "display_name": "Madeline",
                        "email": "madeline@example.com",
                        "user_id": "user-2",
                    }
                ],
            }
        ]
    }


@pytest.mark.asyncio
async def test_search_chat_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_chat_messages",
        {"chat_id": "chat-1", "query": "reply", "top": 5},
    )

    assert result.structured_content == {
        "messages": [
            {
                "id": "reply-1",
                "body_content": "Reply body",
                "content_type": "text",
                "created_at": "2026-04-03T12:06:00Z",
                "last_modified_at": "2026-04-03T12:06:00Z",
                "last_edited_at": None,
                "deleted_at": None,
                "subject": "",
                "summary": "Reply body",
                "importance": "normal",
                "message_type": "message",
                "reply_to_id": "root-1",
                "reply_count": 0,
                "web_url": "",
                "chat_id": "",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender": {
                    "display_name": "Responder",
                    "email": "responder@example.com",
                    "user_id": "user-2",
                    "kind": "user",
                },
            }
        ]
    }


@pytest.mark.asyncio
async def test_list_channel_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "top": 5},
    )

    assert result.structured_content == {
        "messages": [
            {
                "id": "teams-msg-1",
                "body_content": "Hello from Teams",
                "content_type": "text",
                "created_at": "2026-04-03T12:07:00Z",
                "last_modified_at": "2026-04-03T12:07:00Z",
                "last_edited_at": "2026-04-03T12:08:00Z",
                "deleted_at": None,
                "subject": "",
                "summary": "Hello from Teams",
                "importance": "normal",
                "message_type": "message",
                "reply_to_id": "",
                "reply_count": 2,
                "web_url": "",
                "chat_id": "chat-1",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender": {
                    "display_name": "Sender",
                    "email": "sender@example.com",
                    "user_id": "user-1",
                    "kind": "user",
                },
            }
        ]
    }


@pytest.mark.asyncio
async def test_search_channel_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "query": "hello", "top": 5},
    )

    assert result.structured_content == {
        "messages": [
            {
                "id": "teams-msg-1",
                "body_content": "Hello from Teams",
                "content_type": "text",
                "created_at": "2026-04-03T12:07:00Z",
                "last_modified_at": "2026-04-03T12:07:00Z",
                "last_edited_at": "2026-04-03T12:08:00Z",
                "deleted_at": None,
                "subject": "",
                "summary": "Hello from Teams",
                "importance": "normal",
                "message_type": "message",
                "reply_to_id": "",
                "reply_count": 2,
                "web_url": "",
                "chat_id": "chat-1",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender": {
                    "display_name": "Sender",
                    "email": "sender@example.com",
                    "user_id": "user-1",
                    "kind": "user",
                },
            }
        ]
    }


@pytest.mark.asyncio
async def test_list_channel_replies_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_replies",
        {"team_id": "team-1", "channel_id": "channel-1", "message_id": "root-1", "top": 5},
    )

    assert result.structured_content == {
        "replies": [
            {
                "id": "reply-1",
                "body_content": "Reply body",
                "content_type": "text",
                "created_at": "2026-04-03T12:06:00Z",
                "last_modified_at": "2026-04-03T12:06:00Z",
                "last_edited_at": None,
                "deleted_at": None,
                "subject": "",
                "summary": "Reply body",
                "importance": "normal",
                "message_type": "message",
                "reply_to_id": "root-1",
                "reply_count": 0,
                "web_url": "",
                "chat_id": "",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender": {
                    "display_name": "Responder",
                    "email": "responder@example.com",
                    "user_id": "user-2",
                    "kind": "user",
                },
            }
        ],
        "has_more_replies": True,
    }


@pytest.mark.asyncio
async def test_read_channel_thread_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_channel_thread",
        {"team_id": "team-1", "channel_id": "channel-1", "message_id": "root-1", "top": 5},
    )

    assert result.structured_content == {
        "root_message": {
            "id": "teams-msg-1",
            "body_content": "Hello from Teams",
            "content_type": "text",
            "created_at": "2026-04-03T12:07:00Z",
            "last_modified_at": "2026-04-03T12:07:00Z",
            "last_edited_at": "2026-04-03T12:08:00Z",
            "deleted_at": None,
            "subject": "",
            "summary": "Hello from Teams",
            "importance": "normal",
            "message_type": "message",
            "reply_to_id": "",
            "reply_count": 2,
            "web_url": "",
            "chat_id": "chat-1",
            "team_id": "team-1",
            "channel_id": "channel-1",
            "sender": {
                "display_name": "Sender",
                "email": "sender@example.com",
                "user_id": "user-1",
                "kind": "user",
            },
        },
        "replies": [
            {
                "id": "reply-1",
                "body_content": "Reply body",
                "content_type": "text",
                "created_at": "2026-04-03T12:06:00Z",
                "last_modified_at": "2026-04-03T12:06:00Z",
                "last_edited_at": None,
                "deleted_at": None,
                "subject": "",
                "summary": "Reply body",
                "importance": "normal",
                "message_type": "message",
                "reply_to_id": "root-1",
                "reply_count": 0,
                "web_url": "",
                "chat_id": "",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender": {
                    "display_name": "Responder",
                    "email": "responder@example.com",
                    "user_id": "user-2",
                    "kind": "user",
                },
            }
        ],
        "has_more_replies": True,
    }


@pytest.mark.asyncio
async def test_tool_maps_authentication_failures_to_runtime_error() -> None:
    server = create_server(runtime=_FailingRuntime())

    with pytest.raises(ToolError, match="Authentication failed"):
        await server.call_tool("list_folders", {})


def test_mcp_main_supports_help() -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["--help"])
    assert exc_info.value.code == 0


@dataclass
class _FakeRuntime:
    graph_response: dict[str, Any] | None = None
    graph_calls: list[dict[str, Any]] = field(default_factory=list)

    def email_client(self) -> _FakeEmailClient:
        return _FakeEmailClient()

    def calendar_client(self) -> _FakeCalendarClient:
        return _FakeCalendarClient()

    def teams_client(self, *, include_channel_messages: bool = False) -> _FakeTeamsClient:
        return _FakeTeamsClient()

    def graph_client(self) -> _FakeGraphClient:
        return _FakeGraphClient(self.graph_response or {"value": []}, self.graph_calls)


class _FailingRuntime(_FakeRuntime):
    def email_client(self) -> _FakeEmailClient:
        raise AuthenticationError("missing token")


class _FakeGraphClient:
    def __init__(self, response: dict[str, Any], calls: list[dict[str, Any]]) -> None:
        self._response = response
        self._calls = calls

    def post(self, path: str, *, body: dict[str, Any]) -> dict[str, Any]:
        self._calls.append({"path": path, "body": body})
        return self._response


class _FakeEmailClient:
    def list_inbox(self, *, mailbox_filter: str | None, top: int, skip: int) -> list[EmailMessage]:
        return [_message()]

    def search_emails(self, query: str, mailbox_filter: str | None = None) -> list[EmailMessage]:
        return [_message()]

    def read_email(self, message_id: str) -> EmailMessage:
        return _message()

    def list_folders(self) -> list[dict[str, str]]:
        return [{"id": "folder-1", "display_name": "Archive"}]


class _FakeCalendarClient:
    def list_events(
        self,
        *,
        start: datetime,
        end: datetime,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
    ) -> list[CalendarEvent]:
        return [_event()]

    def get_event(self, event_id: str) -> CalendarEvent:
        return _event()

    def search_events(
        self,
        *,
        query: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[CalendarEvent]:
        return [_event()]

    def list_calendars(self) -> list[dict[str, str]]:
        return [{"id": "calendar-1", "name": "Primary"}]


class _FakeTeamsClient:
    def list_chats(self, *, top: int = 25) -> list[TeamsChat]:
        return [_chat()]

    def search_chats(self, query: str, *, top: int = 10) -> list[TeamsChat]:
        return [_chat()]

    def list_chat_messages(self, chat_id: str, *, top: int = 25) -> list[TeamsMessage]:
        return [_teams_message()]

    def search_chat_messages(
        self,
        chat_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        return [_reply()]

    def get_chat_message(self, chat_id: str, message_id: str) -> TeamsMessage:
        return _teams_message()

    def list_teams(self) -> list[TeamSummary]:
        return [
            TeamSummary(
                id="team-1",
                display_name="Ops",
                description="",
                is_archived=False,
                tenant_id="tenant-1",
            )
        ]

    def list_channels(self, team_id: str) -> list[ChannelSummary]:
        return [
            ChannelSummary(
                id="channel-1",
                display_name="General",
                description="",
                membership_type="standard",
                web_url="",
            )
        ]

    def list_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 25,
    ) -> list[TeamsMessage]:
        return [_teams_message()]

    def search_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        return [_teams_message()]

    def list_channel_replies(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        top: int = 25,
    ) -> TeamsReplyPage:
        return TeamsReplyPage(replies=(_reply(),), has_more_replies=True)

    def get_channel_message(self, team_id: str, channel_id: str, message_id: str) -> TeamsMessage:
        return _teams_message()

    def read_channel_thread(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        replies_top: int = 25,
    ) -> TeamsThread:
        return TeamsThread(
            root_message=_teams_message(),
            replies=(_reply(),),
            has_more_replies=True,
        )


def _message() -> EmailMessage:
    return EmailMessage(
        id="msg-1",
        subject="Hello",
        sender="sender@example.com",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview="Preview",
        body_content="<untrusted-email-content>Hello</untrusted-email-content>",
        received_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        is_read=False,
        is_flagged=True,
        importance="high",
        has_attachments=False,
        attachments=(),
        conversation_id="conversation-1",
        folder_id="folder-1",
    )


def _event() -> CalendarEvent:
    return CalendarEvent(
        id="event-1",
        subject="Planning",
        start=datetime(2026, 4, 3, 9, 0, tzinfo=UTC),
        end=datetime(2026, 4, 3, 9, 30, tzinfo=UTC),
        timezone="UTC",
        location="Room A",
        body_content="Agenda",
        attendees=(
            Attendee(
                email="person@example.com",
                name="Person",
                response="accepted",
                type="required",
            ),
        ),
        is_online_meeting=False,
        is_cancelled=False,
        importance="normal",
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
    )


def _chat() -> TeamsChat:
    return TeamsChat(
        id="chat-1",
        topic="Madeline",
        display_label="Madeline",
        chat_type="oneOnOne",
        created_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        last_updated_at=datetime(2026, 4, 3, 12, 5, tzinfo=UTC),
        last_message_read_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        web_url="",
        is_hidden=False,
        is_hidden_for_all_members=False,
        other_participants=(
            TeamsParticipant(
                display_name="Madeline",
                email="madeline@example.com",
                user_id="user-2",
            ),
        ),
    )


def _teams_message() -> TeamsMessage:
    return TeamsMessage(
        id="teams-msg-1",
        body_content="Hello from Teams",
        content_type="text",
        created_at=datetime(2026, 4, 3, 12, 7, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 7, tzinfo=UTC),
        last_edited_at=datetime(2026, 4, 3, 12, 8, tzinfo=UTC),
        deleted_at=None,
        subject="",
        summary="Hello from Teams",
        importance="normal",
        message_type="message",
        reply_to_id="",
        reply_count=2,
        web_url="",
        chat_id="chat-1",
        team_id="team-1",
        channel_id="channel-1",
        sender=TeamsSender(
            display_name="Sender",
            email="sender@example.com",
            user_id="user-1",
            kind="user",
        ),
    )


def _reply() -> TeamsMessage:
    return TeamsMessage(
        id="reply-1",
        body_content="Reply body",
        content_type="text",
        created_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        last_edited_at=None,
        deleted_at=None,
        subject="",
        summary="Reply body",
        importance="normal",
        message_type="message",
        reply_to_id="root-1",
        reply_count=0,
        web_url="",
        chat_id="",
        team_id="team-1",
        channel_id="channel-1",
        sender=TeamsSender(
            display_name="Responder",
            email="responder@example.com",
            user_id="user-2",
            kind="user",
        ),
    )
