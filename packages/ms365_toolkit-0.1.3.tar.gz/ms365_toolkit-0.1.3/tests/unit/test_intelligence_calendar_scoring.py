from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.intelligence.calendar_scoring import score_event
from ms365_toolkit.models.calendar import Attendee, CalendarEvent

if TYPE_CHECKING:
    from pathlib import Path


def test_score_event_boosts_critical_high_importance_meetings(tmp_path: Path) -> None:
    config = _config(tmp_path)
    event = _event(
        subject="Board decision",
        body_content="Critical leadership review",
        importance="high",
        attendees=(
            Attendee("a@example.com", "A", "accepted", "required"),
            Attendee("b@example.com", "B", "accepted", "required"),
        ),
        start=datetime.now(UTC) + timedelta(hours=2),
    )

    scored = score_event(event, config)

    assert scored.score >= 80
    assert scored.category == "critical"


def test_score_event_penalizes_noise_and_personal_events(tmp_path: Path) -> None:
    config = _config(tmp_path)
    event = _event(
        subject="OOO focus block",
        body_content="focus",
        importance="low",
        attendees=(Attendee("a@example.com", "A", "accepted", "required"),),
        start=datetime.now(UTC) + timedelta(days=4),
    )

    scored = score_event(event, config)

    assert scored.score < 40
    assert scored.category == "noise"


def _event(
    *,
    subject: str,
    body_content: str,
    importance: str,
    attendees: tuple[Attendee, ...],
    start: datetime,
) -> CalendarEvent:
    return CalendarEvent(
        id="event-1",
        subject=subject,
        start=start,
        end=start + timedelta(hours=1),
        timezone="UTC",
        location="Room A",
        body_content=body_content,
        attendees=attendees,
        is_online_meeting=True,
        is_cancelled=False,
        importance=importance,
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
    )


def _config(tmp_path: Path):
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "users"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = ["vip@example.com"]
domains = ["vip-domain.com"]

[intelligence]
critical_keywords = ["board", "leadership", "critical"]
noise_keywords = ["ooo", "focus", "block"]
action_keywords = ["approve"]
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
