from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.intelligence.day_overview import day_overview
from ms365_toolkit.models.calendar import Attendee, CalendarEvent

if TYPE_CHECKING:
    from pathlib import Path


def test_day_overview_detects_gaps_and_conflicts(tmp_path: Path) -> None:
    config = _config(tmp_path)
    base = datetime(2026, 3, 12, 9, tzinfo=UTC)
    events = [
        _event("Critical board", base, 60, importance="high"),
        _event("Conflict follow-up", base + timedelta(minutes=30), 30, importance="normal"),
        _event("Later sync", base + timedelta(hours=3), 60, importance="normal"),
    ]

    overview = day_overview(events, config)

    assert overview.ranked_events[0].event.subject == "Critical board"
    assert overview.conflicts[0].first_event_id == "Critical board"
    assert overview.free_blocks[0].start_iso == (base + timedelta(hours=1)).isoformat()
    assert overview.free_blocks[0].end_iso == (base + timedelta(hours=3)).isoformat()


def _event(subject: str, start: datetime, minutes: int, *, importance: str) -> CalendarEvent:
    return CalendarEvent(
        id=subject,
        subject=subject,
        start=start,
        end=start + timedelta(minutes=minutes),
        timezone="UTC",
        location="Room A",
        body_content=subject,
        attendees=(Attendee("a@example.com", "A", "accepted", "required"),),
        is_online_meeting=True,
        is_cancelled=False,
        importance=importance,
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
    )


def _config(tmp_path: Path):
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "users"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = ["vip@example.com"]
domains = ["vip-domain.com"]

[intelligence]
critical_keywords = ["critical", "board"]
noise_keywords = ["ooo"]
action_keywords = ["approve"]
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
