from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.intelligence.vip import is_vip

if TYPE_CHECKING:
    from pathlib import Path


def test_is_vip_matches_exact_email_and_domain(tmp_path: Path) -> None:
    config = _config(tmp_path)

    assert is_vip("vip@example.com", config) is True
    assert is_vip("person@vip-domain.com", config) is True
    assert is_vip("person@alerts.vip-domain.com", config) is True
    assert is_vip("other@outside.com", config) is False


def _config(tmp_path: Path):
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "users"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = ["vip@example.com"]
domains = [".vip-domain.com"]

[intelligence]
critical_keywords = ["board"]
noise_keywords = ["ooo"]
action_keywords = ["approve"]
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
