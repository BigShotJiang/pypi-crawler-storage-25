from __future__ import annotations

from dataclasses import FrozenInstanceError
from datetime import UTC, datetime

import pytest

from ms365_toolkit.models.email import AttachmentInfo, EmailDraft, EmailMessage


def test_email_message_is_frozen() -> None:
    message = EmailMessage(
        id="msg-1",
        subject="Hello",
        sender="sender@example.com",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview="Preview",
        body_content="<untrusted-email-content>Body</untrusted-email-content>",
        received_at=datetime(2026, 3, 12, tzinfo=UTC),
        is_read=False,
        is_flagged=True,
        importance="high",
        has_attachments=True,
        attachments=(
            AttachmentInfo(
                name="doc.txt",
                content_type="text/plain",
                size=10,
                sha256="abc",
                is_reference=False,
            ),
        ),
        conversation_id="conv-1",
        folder_id="folder-1",
    )

    with pytest.raises(FrozenInstanceError):
        message.subject = "Updated"


def test_email_draft_supports_multiple_reply_to_recipients() -> None:
    draft = EmailDraft(
        draft_id="draft-1",
        content_hash="hash",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        subject="Subject",
        body="Body",
        attachments=(),
        reply_to=("reply1@example.com", "reply2@example.com"),
        importance="normal",
        created_at=datetime(2026, 3, 12, tzinfo=UTC),
    )

    assert draft.reply_to == ("reply1@example.com", "reply2@example.com")

