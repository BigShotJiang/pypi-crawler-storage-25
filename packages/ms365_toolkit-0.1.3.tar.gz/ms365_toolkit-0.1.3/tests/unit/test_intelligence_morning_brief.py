from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.intelligence.morning_brief import morning_brief
from ms365_toolkit.models.calendar import Attendee, CalendarEvent
from ms365_toolkit.models.email import EmailMessage

if TYPE_CHECKING:
    from pathlib import Path


def test_morning_brief_groups_emails_and_sorts_upcoming_events(tmp_path: Path) -> None:
    config = _config(tmp_path)
    emails = [
        _email("vip@example.com", "Hello", "Hi", is_flagged=False),
        _email("owner@example.com", "Please approve", "approve this", is_flagged=True),
    ]
    events = [
        _event("Board review", datetime.now(UTC) + timedelta(hours=2), importance="high"),
        _event("Routine sync", datetime.now(UTC) + timedelta(hours=3), importance="normal"),
    ]

    brief = morning_brief(emails, events, config)

    assert len(brief.action_required) == 1
    assert len(brief.vip) == 1
    assert len(brief.flagged) == 1
    assert brief.upcoming_events[0].event.subject == "Board review"


def _email(sender: str, subject: str, body: str, *, is_flagged: bool) -> EmailMessage:
    return EmailMessage(
        id=subject,
        subject=subject,
        sender=sender,
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview=body,
        body_content=body,
        received_at=datetime.now(UTC),
        is_read=False,
        is_flagged=is_flagged,
        importance="high" if is_flagged else "normal",
        has_attachments=False,
        attachments=(),
        conversation_id="conv",
        folder_id="folder",
    )


def _event(subject: str, start: datetime, *, importance: str) -> CalendarEvent:
    return CalendarEvent(
        id=subject,
        subject=subject,
        start=start,
        end=start + timedelta(hours=1),
        timezone="UTC",
        location="Room A",
        body_content=subject,
        attendees=(
            Attendee("a@example.com", "A", "accepted", "required"),
            Attendee("b@example.com", "B", "accepted", "required"),
        ),
        is_online_meeting=True,
        is_cancelled=False,
        importance=importance,
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
    )


def _config(tmp_path: Path):
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "users"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = ["vip@example.com"]
domains = ["vip-domain.com"]

[intelligence]
critical_keywords = ["board"]
noise_keywords = ["ooo"]
action_keywords = ["approve"]
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
