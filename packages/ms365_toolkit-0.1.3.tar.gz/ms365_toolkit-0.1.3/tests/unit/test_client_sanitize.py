from __future__ import annotations

from ms365_toolkit.client.sanitize import sanitize_email_body, strip_html, wrap_untrusted


def test_strip_html_returns_plain_text() -> None:
    assert strip_html("<p>Hello <strong>world</strong></p>") == "Hello world"


def test_wrap_untrusted_wraps_text_in_marker_tags() -> None:
    assert wrap_untrusted("Body") == "<untrusted-email-content>Body</untrusted-email-content>"


def test_sanitize_email_body_strips_then_wraps() -> None:
    assert (
        sanitize_email_body("<div>Hello<br/>world</div>")
        == "<untrusted-email-content>Hello world</untrusted-email-content>"
    )

