from __future__ import annotations

import tomllib
from pathlib import Path

from ms365_toolkit import __version__

ROOT = Path(__file__).resolve().parents[2]
ROOT_PYPROJECT = ROOT / "pyproject.toml"
WRAPPER_PYPROJECT = ROOT / "packages" / "ms365-toolkit-mcp" / "pyproject.toml"


def test_root_version_matches_package_version() -> None:
    project = _load_pyproject(ROOT_PYPROJECT)

    assert project["project"]["version"] == __version__


def test_wrapper_version_and_dependency_match_root_version() -> None:
    wrapper = _load_pyproject(WRAPPER_PYPROJECT)

    assert wrapper["project"]["version"] == __version__
    assert wrapper["project"]["dependencies"] == [f"ms365-toolkit[mcp]=={__version__}"]


def test_wrapper_exposes_mcp_console_script() -> None:
    wrapper = _load_pyproject(WRAPPER_PYPROJECT)

    assert wrapper["project"]["scripts"] == {
        "ms365-toolkit-mcp": "ms365_toolkit_mcp_wrapper:main"
    }


def _load_pyproject(path: Path) -> dict[str, object]:
    return tomllib.loads(path.read_text(encoding="utf-8"))
