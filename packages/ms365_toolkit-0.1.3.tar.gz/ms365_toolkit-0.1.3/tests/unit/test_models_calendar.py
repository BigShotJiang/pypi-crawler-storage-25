from __future__ import annotations

from dataclasses import FrozenInstanceError
from datetime import UTC, datetime

import pytest

from ms365_toolkit.models.calendar import Attendee, CalendarEvent, FreeBusySlot


def test_calendar_event_is_frozen() -> None:
    event = CalendarEvent(
        id="event-1",
        subject="Planning",
        start=datetime(2026, 3, 12, 14, tzinfo=UTC),
        end=datetime(2026, 3, 12, 15, tzinfo=UTC),
        timezone="UTC",
        location="Room A",
        body_content="Agenda",
        attendees=(
            Attendee(
                email="a@example.com",
                name="A",
                response="accepted",
                type="required",
            ),
        ),
        is_online_meeting=False,
        is_cancelled=False,
        importance="normal",
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
    )

    with pytest.raises(FrozenInstanceError):
        event.subject = "Updated"


def test_free_busy_slot_captures_status() -> None:
    slot = FreeBusySlot(
        start=datetime(2026, 3, 12, 14, tzinfo=UTC),
        end=datetime(2026, 3, 12, 15, tzinfo=UTC),
        status="busy",
    )

    assert slot.status == "busy"
