from __future__ import annotations

from argparse import Namespace
from typing import TYPE_CHECKING

from ms365_toolkit.cli.labeling_web import (
    _index_html,
    _is_loopback_host,
    _records_payload,
    launch_label_ui_command,
)
from ms365_toolkit.intelligence.labels import ThreadLabelRecord, ThreadLabels

if TYPE_CHECKING:
    import pytest


def test_records_payload_serializes_labels() -> None:
    payload = _records_payload([_record()])

    assert len(payload["records"]) == 1
    record = payload["records"][0]
    assert isinstance(record, dict)
    assert record["thread_id"] == "conv-1"
    assert isinstance(record["labels"], dict)
    assert record["labels"]["thread_class"] == "decision_request"


def test_index_html_contains_label_form() -> None:
    html = _index_html()

    assert "Thread Labels" in html
    assert "Save + Next" in html
    assert "approval_request" in html
    assert "strategic_update" in html


def test_is_loopback_host_accepts_local_only_hosts() -> None:
    assert _is_loopback_host("127.0.0.1") is True
    assert _is_loopback_host("localhost") is True
    assert _is_loopback_host("::1") is True


def test_launch_label_ui_command_rejects_non_loopback_host(
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = launch_label_ui_command(
        Namespace(profile="default", host="0.0.0.0", port=8765, no_open=True),
        _config(),
    )

    assert exit_code == 1
    assert "loopback hosts only" in capsys.readouterr().out


def _record() -> ThreadLabelRecord:
    return ThreadLabelRecord(
        thread_id="conv-1",
        message_id="msg-1",
        subject="Subject",
        sender="sender@example.com",
        sender_type="human_internal",
        received_at="2026-03-14T12:00:00+00:00",
        body_preview="Preview",
        body_content="Body",
        thread_size=1,
        cluster_size=1,
        labels=ThreadLabels(
            thread_class="decision_request",
            action_needed="yes",
            urgency="high",
            acted_by_you="replied",
            confidence=0.9,
        ),
        notes="note",
    )


def _config():
    class StubConfig:
        pass

    return StubConfig()
