from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.intelligence.labels import (
    ThreadLabelRecord,
    ThreadLabels,
    append_label_record,
    find_label_record,
    read_label_records,
    upsert_label_record,
)

if TYPE_CHECKING:
    from pathlib import Path


def test_append_and_read_label_records(tmp_path: Path) -> None:
    path = tmp_path / "labels.jsonl"
    record = _record()

    append_label_record(path, record)
    records = read_label_records(path)

    assert records == [record]


def test_upsert_label_record_replaces_existing_thread(tmp_path: Path) -> None:
    path = tmp_path / "labels.jsonl"
    first = _record()
    second = ThreadLabelRecord(
        **{
            **first.__dict__,
            "labels": ThreadLabels(
                thread_class="decision_request",
                action_needed="yes",
                urgency="high",
                acted_by_you="replied",
                confidence=0.9,
            ),
        }
    )

    append_label_record(path, first)
    upsert_label_record(path, second)

    records = read_label_records(path)
    assert records == [second]


def test_find_label_record_returns_matching_thread(tmp_path: Path) -> None:
    path = tmp_path / "labels.jsonl"
    record = _record()

    append_label_record(path, record)

    assert find_label_record(path, "conv-1") == record
    assert find_label_record(path, "missing") is None


def _record() -> ThreadLabelRecord:
    return ThreadLabelRecord(
        thread_id="conv-1",
        message_id="msg-1",
        subject="Subject",
        sender="sender@example.com",
        sender_type="human_internal",
        received_at="2026-03-14T12:00:00+00:00",
        body_preview="Preview",
        body_content="Body",
        thread_size=1,
        cluster_size=1,
        labels=None,
        notes="",
    )
