from __future__ import annotations

from argparse import Namespace
from typing import TYPE_CHECKING

from ms365_toolkit.cli.labeling import (
    _sender_type,
    apply_thread_label,
    export_label_candidates_command,
    label_thread_command,
    list_label_candidates,
    review_label_candidates_command,
)
from ms365_toolkit.intelligence.labels import ThreadLabels, read_label_records

if TYPE_CHECKING:
    from pathlib import Path

    import pytest


def test_export_label_candidates_writes_jsonl(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling.build_read_clients",
        lambda config, profile: (_FakeEmailClient(), object()),
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling.build_mailbox_index",
        lambda profile: _FakeMailboxIndex(),
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling._labels_path",
        lambda profile: tmp_path / "labels.jsonl",
    )

    exit_code = export_label_candidates_command(
        Namespace(profile="default", top=2, sync_index=False, max_pages=5),
        _config(),
    )

    assert exit_code == 0
    assert len(read_label_records(tmp_path / "labels.jsonl")) == 2


def test_label_thread_command_upserts_label(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    path = tmp_path / "labels.jsonl"
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling._labels_path",
        lambda profile: path,
    )
    _write_existing_record(path)

    exit_code = label_thread_command(
        Namespace(
            profile="default",
            thread_id="conv-1",
            thread_class="decision_request",
            action_needed="yes",
            urgency="high",
            acted_by_you="replied",
            confidence=0.9,
            notes="important thread",
        ),
        _config(),
    )

    assert exit_code == 0
    records = read_label_records(tmp_path / "labels.jsonl")
    assert records[0].labels is not None
    assert records[0].labels.thread_class == "decision_request"


def test_review_label_candidates_command_prints_unlabeled_records(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    path = tmp_path / "labels.jsonl"
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling._labels_path",
        lambda profile: path,
    )
    _write_existing_record(path)

    exit_code = review_label_candidates_command(
        Namespace(profile="default", top=5, status="unlabeled", thread_id=None),
        _config(),
    )

    assert exit_code == 0
    output = capsys.readouterr().out
    assert "Subject" in output
    assert "Labels: <unlabeled>" in output


def test_list_label_candidates_filters_labeled_status(tmp_path: Path) -> None:
    path = tmp_path / "labels.jsonl"
    _write_existing_record(path)
    apply_thread_label(
        path,
        thread_id="conv-1",
        labels=_labels(),
        notes="done",
    )

    records = list_label_candidates(path, status="labeled", top=5)

    assert len(records) == 1
    assert records[0].labels is not None


def test_apply_thread_label_preserves_record_fields(tmp_path: Path) -> None:
    path = tmp_path / "labels.jsonl"
    _write_existing_record(path)

    record = apply_thread_label(
        path,
        thread_id="conv-1",
        labels=_labels(),
        notes=None,
    )

    assert record.subject == "Subject"
    assert record.labels is not None
    assert record.notes == ""


def test_sender_type_uses_config_domains() -> None:
    assert _sender_type("teammate@example.com", _config()) == "human_internal"
    assert _sender_type("teammate@alerts.example.com", _config()) == "human_internal"
    assert _sender_type("vendor@outside.com", _config()) == "human_external"


class _FakeMailboxIndex:
    def sync(self, email_client: object, *, batch_size: int = 100, max_pages: int = 10) -> int:
        return 0

    def recent_threads(self, *, limit: int = 20) -> list[object]:
        class Thread:
            def __init__(
                self,
                conversation_id: str,
                latest_message_id: str,
                message_count: int,
            ) -> None:
                self.conversation_id = conversation_id
                self.latest_message_id = latest_message_id
                self.message_count = message_count

        return [Thread("conv-1", "msg-1", 1), Thread("conv-2", "msg-2", 2)]


class _FakeEmailClient:
    def read_email(self, message_id: str):
        class Message:
            def __init__(self, message_id: str) -> None:
                self.id = message_id
                self.subject = f"Subject {message_id}"
                self.sender = "sender@example.com"
                self.body_preview = "Preview"
                self.body_content = "<untrusted-email-content>Body</untrusted-email-content>"
                self.received_at = type(
                    "Date",
                    (),
                    {"isoformat": lambda self: "2026-03-14T12:00:00+00:00"},
                )()

        return Message(message_id)


def _config():
    class User:
        user_principal_name = "owner@example.com"

    class Safety:
        domain_allowlist = (".example.com",)

    class StubConfig:
        user = User()
        safety = Safety()

    return StubConfig()


def _write_existing_record(path: Path) -> None:
    path.write_text(
        (
            '{"thread_id":"conv-1","message_id":"msg-1","subject":"Subject",'
            '"sender":"sender@example.com","sender_type":"human_internal",'
            '"received_at":"2026-03-14T12:00:00+00:00","body_preview":"Preview",'
            '"body_content":"Body","thread_size":1,"cluster_size":1,'
            '"labels":null,"notes":""}\n'
        ),
        encoding="utf-8",
    )


def _labels():
    return ThreadLabels(
        thread_class="decision_request",
        action_needed="yes",
        urgency="high",
        acted_by_you="replied",
        confidence=0.9,
    )
