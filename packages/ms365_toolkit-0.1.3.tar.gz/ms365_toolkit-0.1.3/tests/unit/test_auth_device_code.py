from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

from ms365_toolkit.auth.credentials import CredentialStore
from ms365_toolkit.auth.device_code import DeviceCodePrompt, authenticate_device_code
from ms365_toolkit.client.exceptions import AuthenticationError
from ms365_toolkit.config.loader import load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path


def test_authenticate_device_code_presents_prompt_and_saves_cache(tmp_path: Path) -> None:
    config = _config(tmp_path)
    backend = _FakeKeyring()
    store = CredentialStore(profile="default", keyring_backend=backend)
    prompts: list[DeviceCodePrompt] = []
    app = _FakeDeviceCodeApp(
        flow={
            "verification_uri": "https://microsoft.com/devicelogin",
            "user_code": "ABCD",
            "message": "Use code ABCD",
        },
        result={"access_token": "token", "scope": "Mail.Read Calendars.Read"},
    )

    result = authenticate_device_code(
        config=config,
        credential_store=store,
        write=False,
        presenter=prompts.append,
        app_factory=lambda cache: app,
    )

    assert result["access_token"] == "token"
    assert prompts[0].user_code == "ABCD"
    assert backend.values


def test_authenticate_device_code_rejects_invalid_flow(tmp_path: Path) -> None:
    config = _config(tmp_path)
    store = CredentialStore(profile="default", keyring_backend=_FakeKeyring())
    app = _FakeDeviceCodeApp(flow={"message": "missing"}, result={"access_token": "token"})

    with pytest.raises(AuthenticationError, match="verification details"):
        authenticate_device_code(
            config=config,
            credential_store=store,
            write=False,
            presenter=lambda prompt: None,
            app_factory=lambda cache: app,
        )


class _FakeDeviceCodeApp:
    def __init__(self, *, flow: dict[str, Any], result: dict[str, Any]) -> None:
        self.flow = flow
        self.result = result

    def initiate_device_flow(self, scopes: list[str]) -> dict[str, Any]:
        return self.flow

    def acquire_token_by_device_flow(self, flow: dict[str, Any]) -> dict[str, Any]:
        return self.result


class _FakeKeyring:
    def __init__(self) -> None:
        self.values: dict[tuple[str, str], str] = {}

    def get_password(self, service_name: str, username: str) -> str | None:
        return self.values.get((service_name, username))

    def set_password(self, service_name: str, username: str, password: str) -> None:
        self.values[(service_name, username)] = password

    def delete_password(self, service_name: str, username: str) -> None:
        self.values.pop((service_name, username), None)


def _config(tmp_path: Path) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = "owner@example.com"
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
