from __future__ import annotations

from ms365_toolkit.client.exceptions import (
    AuthenticationError,
    GraphAPIError,
    InsufficientScopesError,
    RateLimitedError,
    SafetyDeniedError,
)


def test_graph_api_error_exposes_status_code_and_error_code() -> None:
    error = GraphAPIError(429, "TooManyRequests", "Slow down")

    assert error.status_code == 429
    assert error.error_code == "TooManyRequests"
    assert error.message == "Slow down"


def test_insufficient_scopes_error_formats_sets() -> None:
    error = InsufficientScopesError({"Mail.Send"}, {"Mail.Read"})

    assert error.required == frozenset({"Mail.Send"})
    assert error.actual == frozenset({"Mail.Read"})
    assert "Mail.Send" in str(error)
    assert "Mail.Read" in str(error)


def test_rate_limited_error_includes_retry_after_when_present() -> None:
    error = RateLimitedError(30)

    assert error.retry_after == 30
    assert "30" in str(error)


def test_safety_denied_error_includes_details() -> None:
    error = SafetyDeniedError("allowlist", "send_email", "external recipient")

    assert error.reason == "allowlist"
    assert error.tool == "send_email"
    assert error.details == "external recipient"
    assert "external recipient" in str(error)


def test_authentication_error_is_base_class_for_scope_errors() -> None:
    error = InsufficientScopesError({"Mail.Send"}, {"Mail.Read"})

    assert isinstance(error, AuthenticationError)
