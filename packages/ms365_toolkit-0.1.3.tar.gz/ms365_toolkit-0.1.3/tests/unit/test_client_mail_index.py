from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

from ms365_toolkit.client.email import DeltaSyncResult
from ms365_toolkit.client.mail_index import MailboxIndex
from ms365_toolkit.models.email import EmailMessage

if TYPE_CHECKING:
    from pathlib import Path


def test_mailbox_index_upserts_searches_and_removes(tmp_path: Path) -> None:
    index = MailboxIndex(tmp_path / "mail_index.db")
    message = _message("msg-1", "conv-1", "Contract renewal", "vendor@example.com")

    index.upsert_messages([message])
    results = index.search("renewal")
    index.remove_messages(["msg-1"])

    assert results[0].message_id == "msg-1"
    assert index.search("renewal") == []


def test_mailbox_index_sync_uses_delta_link(tmp_path: Path) -> None:
    index = MailboxIndex(tmp_path / "mail_index.db")
    client = _FakeEmailClient(
        [
            DeltaSyncResult(
                messages=[_message("msg-1", "conv-1", "First", "a@example.com")],
                removed_ids=[],
                next_link="https://next",
                delta_link=None,
            ),
            DeltaSyncResult(
                messages=[],
                removed_ids=["msg-1"],
                next_link=None,
                delta_link="https://delta",
            ),
        ]
    )

    changed = index.sync(client, batch_size=50, max_pages=5)

    assert changed == 2
    assert index.get_delta_link() == "https://delta"
    assert index.recent() == []


def test_mailbox_index_recent_threads_collapses_conversations(tmp_path: Path) -> None:
    index = MailboxIndex(tmp_path / "mail_index.db")
    index.upsert_messages(
        [
            _message(
                "msg-1",
                "conv-1",
                "Old",
                "a@example.com",
                received_at=datetime(2026, 3, 14, 10, tzinfo=UTC),
            ),
            _message(
                "msg-2",
                "conv-1",
                "New",
                "b@example.com",
                received_at=datetime(2026, 3, 14, 11, tzinfo=UTC),
            ),
            _message(
                "msg-3",
                "conv-2",
                "Other",
                "c@example.com",
                received_at=datetime(2026, 3, 14, 9, tzinfo=UTC),
            ),
        ]
    )

    threads = index.recent_threads(limit=10)

    assert len(threads) == 2
    assert threads[0].latest_message_id == "msg-2"


class _FakeEmailClient:
    def __init__(self, results: list[DeltaSyncResult]) -> None:
        self.results = results
        self.calls: list[str | None] = []

    def delta_sync(self, *, delta_link: str | None = None, top: int = 100) -> DeltaSyncResult:
        self.calls.append(delta_link)
        return self.results.pop(0)


def _message(
    message_id: str,
    conversation_id: str,
    subject: str,
    sender: str,
    *,
    received_at: datetime | None = None,
) -> EmailMessage:
    return EmailMessage(
        id=message_id,
        subject=subject,
        sender=sender,
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview=subject,
        body_content="<untrusted-email-content>Body</untrusted-email-content>",
        received_at=received_at or datetime(2026, 3, 14, tzinfo=UTC),
        is_read=False,
        is_flagged=False,
        importance="normal",
        has_attachments=False,
        attachments=(),
        conversation_id=conversation_id,
        folder_id="folder",
    )
