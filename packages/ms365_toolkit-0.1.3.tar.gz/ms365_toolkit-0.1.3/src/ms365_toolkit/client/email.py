from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from ms365_toolkit.client.exceptions import GraphAPIError
from ms365_toolkit.client.sanitize import sanitize_email_body
from ms365_toolkit.models.email import AttachmentInfo, EmailMessage

if TYPE_CHECKING:
    from ms365_toolkit.client.graph import GraphClient


class EmailClient:
    def __init__(self, graph: GraphClient) -> None:
        self.graph = graph

    def list_inbox(
        self,
        *,
        mailbox_filter: str | None = None,
        top: int = 10,
        skip: int = 0,
    ) -> list[EmailMessage]:
        query = {
            "$top": top,
            "$skip": skip,
            "$orderby": "receivedDateTime desc",
        }
        if mailbox_filter == "focused":
            query["$filter"] = "inferenceClassification eq 'focused'"
        try:
            response = self.graph.get("mailFolders/inbox/messages", query=query)
        except GraphAPIError as exc:
            if mailbox_filter == "focused" and _should_fallback_to_plain_inbox(exc):
                response = self.graph.get(
                    "mailFolders/inbox/messages",
                    query={"$top": top, "$skip": skip, "$orderby": "receivedDateTime desc"},
                )
                return self._messages_from_response(response)
            raise
        items = self._messages_from_response(response)
        if mailbox_filter == "focused" and not items:
            response = self.graph.get(
                "mailFolders/inbox/messages",
                query={"$top": top, "$skip": skip, "$orderby": "receivedDateTime desc"},
            )
            return self._messages_from_response(response)
        return items

    def read_email(self, message_id: str) -> EmailMessage:
        response = self.graph.get(f"messages/{message_id}")
        return self._message_from_item(response)

    def search_emails(self, query: str, mailbox_filter: str | None = None) -> list[EmailMessage]:
        search_value = f"\"{query}\""
        try:
            response = self.graph.get(
                "messages",
                query={"$search": search_value, "$top": 25},
                headers={"ConsistencyLevel": "eventual"},
            )
            messages = self._messages_from_response(response)
        except GraphAPIError as exc:
            if _should_fallback_to_subject_search(exc):
                response = self.graph.get(
                    "messages",
                    query={
                        "$filter": f"contains(subject,'{_escape_odata_string(query)}')",
                        "$top": 25,
                    },
                )
                messages = self._messages_from_response(response)
            else:
                raise
        if mailbox_filter == "focused":
            return [message for message in messages if "[ext]" not in message.subject.lower()]
        return messages

    def delta_sync(self, *, delta_link: str | None = None, top: int = 100) -> DeltaSyncResult:
        path = delta_link or "mailFolders/inbox/messages/delta"
        response = self.graph.get(
            path,
            query=None if delta_link else {"$top": top},
            headers={"ConsistencyLevel": "eventual"},
        )
        messages: list[EmailMessage] = []
        removed_ids: list[str] = []
        for item in response.get("value", []):
            if "@removed" in item:
                removed_ids.append(str(item.get("id", "")))
                continue
            messages.append(self._message_from_item(item))
        return DeltaSyncResult(
            messages=messages,
            removed_ids=removed_ids,
            next_link=_get_link(response, "@odata.nextLink"),
            delta_link=_get_link(response, "@odata.deltaLink"),
        )

    def list_folders(self) -> list[dict[str, str]]:
        response = self.graph.get("mailFolders", query={"$top": 100})
        return [
            {"id": item.get("id", ""), "display_name": item.get("displayName", "")}
            for item in response.get("value", [])
        ]

    def download_attachments(
        self,
        message_id: str,
        *,
        include_inline: bool = False,
    ) -> list[DownloadedAttachment]:
        response = self.graph.get(f"messages/{message_id}/attachments", query={"$top": 100})
        attachments: list[DownloadedAttachment] = []
        for item in response.get("value", []):
            if not isinstance(item, dict):
                continue
            if item.get("@odata.type") != "#microsoft.graph.fileAttachment":
                continue
            if not include_inline and bool(item.get("isInline", False)):
                continue
            attachment_id = str(item.get("id", ""))
            if not attachment_id:
                raise GraphAPIError(0, "InvalidAttachment", "file attachment is missing id")
            content = _attachment_content_bytes(item)
            if content is None:
                content = self.graph.get_bytes(
                    f"messages/{message_id}/attachments/{attachment_id}/$value"
                )
            attachments.append(
                DownloadedAttachment(
                    attachment_id=attachment_id,
                    name=str(item.get("name", "")),
                    content_type=str(item.get("contentType", "")),
                    size=int(item.get("size", 0)),
                    content=content,
                    is_inline=bool(item.get("isInline", False)),
                )
            )
        return attachments

    def _messages_from_response(self, response: dict[str, Any]) -> list[EmailMessage]:
        return [self._message_from_item(item) for item in response.get("value", [])]

    def _message_from_item(self, item: dict[str, Any]) -> EmailMessage:
        attachments = tuple(
            self._attachment_from_item(attachment) for attachment in item.get("attachments", [])
        )
        sender = item.get("from", {}).get("emailAddress", {}).get("address", "")
        return EmailMessage(
            id=item.get("id", ""),
            subject=item.get("subject", ""),
            sender=sender,
            to=_recipients(item.get("toRecipients")),
            cc=_recipients(item.get("ccRecipients")),
            bcc=_recipients(item.get("bccRecipients")),
            body_preview=item.get("bodyPreview", ""),
            body_content=sanitize_email_body(item.get("body", {}).get("content", "")),
            received_at=_parse_graph_datetime(item.get("receivedDateTime")),
            is_read=bool(item.get("isRead", False)),
            is_flagged=item.get("flag", {}).get("flagStatus") == "flagged",
            importance=item.get("importance", "normal"),
            has_attachments=bool(item.get("hasAttachments", False)),
            attachments=attachments,
            conversation_id=item.get("conversationId", ""),
            folder_id=item.get("parentFolderId", ""),
        )

    def _attachment_from_item(self, item: dict[str, Any]) -> AttachmentInfo:
        content_bytes = item.get("contentBytes", "")
        sha = ""
        if content_bytes:
            decoded = base64.b64decode(str(content_bytes))
            sha = hashlib.sha256(decoded).hexdigest()
        return AttachmentInfo(
            name=item.get("name", ""),
            content_type=item.get("contentType", ""),
            size=int(item.get("size", 0)),
            sha256=sha,
            is_reference=item.get("@odata.type") == "#microsoft.graph.referenceAttachment",
        )


def _recipients(items: Any) -> tuple[str, ...]:
    if not isinstance(items, list):
        return ()
    return tuple(
        item.get("emailAddress", {}).get("address", "")
        for item in items
        if isinstance(item, dict)
    )


def _parse_graph_datetime(value: Any) -> datetime:
    if not isinstance(value, str) or not value:
        return datetime.fromtimestamp(0, tz=UTC)
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _should_fallback_to_plain_inbox(error: GraphAPIError) -> bool:
    normalized_message = error.message.lower()
    return error.status_code == 400 and "too complex" in normalized_message


def _should_fallback_to_subject_search(error: GraphAPIError) -> bool:
    normalized_message = error.message.lower()
    return error.status_code == 400 and "does not support filtering" in normalized_message


def _get_link(response: dict[str, Any], key: str) -> str | None:
    value = response.get(key)
    if isinstance(value, str) and value:
        return value
    return None


def _escape_odata_string(value: str) -> str:
    return value.replace("'", "''")


@dataclass(frozen=True)
class DeltaSyncResult:
    messages: list[EmailMessage]
    removed_ids: list[str]
    next_link: str | None
    delta_link: str | None


@dataclass(frozen=True)
class DownloadedAttachment:
    attachment_id: str
    name: str
    content_type: str
    size: int
    content: bytes
    is_inline: bool


def _attachment_content_bytes(item: dict[str, Any]) -> bytes | None:
    content_bytes = item.get("contentBytes")
    if not isinstance(content_bytes, str) or not content_bytes:
        return None
    return base64.b64decode(content_bytes)
