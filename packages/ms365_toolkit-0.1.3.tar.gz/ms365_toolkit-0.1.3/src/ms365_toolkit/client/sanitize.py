from __future__ import annotations

from bs4 import BeautifulSoup


def strip_html(html: str) -> str:
    return BeautifulSoup(html, "html.parser").get_text(separator=" ", strip=True)


def wrap_untrusted(text: str) -> str:
    return f"<untrusted-email-content>{text}</untrusted-email-content>"


def sanitize_email_body(html: str) -> str:
    return wrap_untrusted(strip_html(html))

