from __future__ import annotations


class GraphAPIError(Exception):
    def __init__(self, status_code: int, error_code: str, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.message = message


class AuthenticationError(Exception):
    pass


class InsufficientScopesError(AuthenticationError):
    def __init__(
        self,
        required: set[str] | frozenset[str],
        actual: set[str] | frozenset[str],
    ) -> None:
        self.required = frozenset(required)
        self.actual = frozenset(actual)
        message = (
            "Insufficient scopes: "
            f"required={sorted(self.required)!r} actual={sorted(self.actual)!r}"
        )
        super().__init__(message)


class RateLimitedError(Exception):
    def __init__(self, retry_after: int | None = None) -> None:
        self.retry_after = retry_after
        message = "Request was rate limited"
        if retry_after is not None:
            message = f"{message}; retry after {retry_after} seconds"
        super().__init__(message)


class SafetyDeniedError(Exception):
    def __init__(self, reason: str, tool: str, details: str | None = None) -> None:
        self.reason = reason
        self.tool = tool
        self.details = details
        message = f"Safety denied for {tool}: {reason}"
        if details:
            message = f"{message} ({details})"
        super().__init__(message)
