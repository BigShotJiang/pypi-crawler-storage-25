from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from urllib.parse import quote

import jwt

from ms365_toolkit.client.exceptions import GraphAPIError
from ms365_toolkit.client.sanitize import strip_html
from ms365_toolkit.models.teams import (
    ChannelSummary,
    TeamsChat,
    TeamsMessage,
    TeamsParticipant,
    TeamsReplyPage,
    TeamsSender,
    TeamsThread,
    TeamSummary,
)

if TYPE_CHECKING:
    from ms365_toolkit.client.graph import GraphClient


class TeamsClient:
    def __init__(self, graph: GraphClient, *, channel_graph: GraphClient | None = None) -> None:
        self.graph = graph
        self.channel_graph = channel_graph or graph
        self.viewer_user_id, self.viewer_email = _viewer_identity(
            graph.token,
            graph.config.user.user_principal_name,
        )

    def list_chats(self, *, top: int = 25) -> list[TeamsChat]:
        self._ensure_supported_endpoint()
        response = self.graph.get(
            "chats",
            query={"$top": _bounded_top(top, maximum=50), "$expand": "members"},
        )
        return [self._chat_from_item(item) for item in response.get("value", [])]

    def search_chats(self, query: str, *, top: int = 10) -> list[TeamsChat]:
        normalized_query = _normalized_query(query)
        limit = _bounded_top(top, maximum=50)
        matches: list[tuple[tuple[int, int, float], TeamsChat]] = []
        for chat in self.list_chats(top=50):
            score = _chat_search_score(chat, normalized_query)
            if score is None:
                continue
            matches.append((score, chat))
        matches.sort(key=lambda item: item[0], reverse=True)
        return [chat for _, chat in matches[:limit]]

    def list_chat_messages(self, chat_id: str, *, top: int = 25) -> list[TeamsMessage]:
        self._ensure_supported_endpoint()
        response = self.graph.get(
            f"chats/{_path_segment('chat_id', chat_id)}/messages",
            query={"$top": _bounded_top(top, maximum=50), "$orderby": "createdDateTime desc"},
        )
        return [
            self._message_from_item(item, chat_id=chat_id) for item in response.get("value", [])
        ]

    def search_chat_messages(
        self,
        chat_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        normalized_query = _normalized_query(query)
        limit = _bounded_top(top, maximum=50)
        matches: list[tuple[tuple[int, float], TeamsMessage]] = []
        for message in self.list_chat_messages(chat_id, top=50):
            score = _message_search_score(message, normalized_query)
            if score is None:
                continue
            matches.append((score, message))
        matches.sort(key=lambda item: item[0], reverse=True)
        return [message for _, message in matches[:limit]]

    def get_chat_message(self, chat_id: str, message_id: str) -> TeamsMessage:
        self._ensure_supported_endpoint()
        response = self.graph.get(
            "chats/"
            f"{_path_segment('chat_id', chat_id)}/messages/"
            f"{_path_segment('message_id', message_id)}"
        )
        return self._message_from_item(response, chat_id=chat_id)

    def list_teams(self) -> list[TeamSummary]:
        self._ensure_supported_endpoint()
        response = self.graph.get("me/joinedTeams")
        return [self._team_from_item(item) for item in response.get("value", [])]

    def list_channels(self, team_id: str) -> list[ChannelSummary]:
        self._ensure_supported_endpoint()
        response = self.graph.get(f"teams/{_path_segment('team_id', team_id)}/channels")
        return [self._channel_from_item(item) for item in response.get("value", [])]

    def list_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 25,
    ) -> list[TeamsMessage]:
        self._ensure_supported_endpoint()
        try:
            response = self.channel_graph.get(
                "teams/"
                f"{_path_segment('team_id', team_id)}/channels/"
                f"{_path_segment('channel_id', channel_id)}/messages",
                query={"$top": _bounded_top(top, maximum=50), "$expand": "replies"},
            )
        except GraphAPIError as exc:
            raise _channel_permission_error(exc) from exc
        return [
            self._message_from_item(item, team_id=team_id, channel_id=channel_id)
            for item in response.get("value", [])
        ]

    def search_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        normalized_query = _normalized_query(query)
        limit = _bounded_top(top, maximum=50)
        matches: list[tuple[tuple[int, float], TeamsMessage]] = []
        for message in self.list_channel_messages(team_id, channel_id, top=50):
            score = _message_search_score(message, normalized_query)
            if score is None:
                continue
            matches.append((score, message))
        matches.sort(key=lambda item: item[0], reverse=True)
        return [message for _, message in matches[:limit]]

    def get_channel_message(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
    ) -> TeamsMessage:
        self._ensure_supported_endpoint()
        try:
            response = self.channel_graph.get(
                "teams/"
                f"{_path_segment('team_id', team_id)}/channels/"
                f"{_path_segment('channel_id', channel_id)}/messages/"
                f"{_path_segment('message_id', message_id)}"
            )
        except GraphAPIError as exc:
            raise _channel_permission_error(exc) from exc
        return self._message_from_item(response, team_id=team_id, channel_id=channel_id)

    def list_channel_replies(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        top: int = 25,
    ) -> TeamsReplyPage:
        self._ensure_supported_endpoint()
        try:
            response = self.channel_graph.get(
                "teams/"
                f"{_path_segment('team_id', team_id)}/channels/"
                f"{_path_segment('channel_id', channel_id)}/messages/"
                f"{_path_segment('message_id', message_id)}/replies",
                query={"$top": _bounded_top(top, maximum=50)},
            )
        except GraphAPIError as exc:
            raise _channel_permission_error(exc) from exc
        replies = tuple(
            _sort_messages_oldest_first(
                [
                    self._message_from_item(item, team_id=team_id, channel_id=channel_id)
                    for item in response.get("value", [])
                ]
            )
        )
        return TeamsReplyPage(
            replies=replies,
            has_more_replies=bool(response.get("@odata.nextLink")),
        )

    def read_channel_thread(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        replies_top: int = 25,
    ) -> TeamsThread:
        root_message = self.get_channel_message(team_id, channel_id, message_id)
        reply_page = self.list_channel_replies(
            team_id,
            channel_id,
            message_id,
            top=replies_top,
        )
        return TeamsThread(
            root_message=root_message,
            replies=reply_page.replies,
            has_more_replies=reply_page.has_more_replies,
        )

    def _ensure_supported_endpoint(self) -> None:
        if self.graph.config.user.endpoint != "me":
            raise ValueError("Teams tools only support user.endpoint='me'")

    def _chat_from_item(self, item: dict[str, Any]) -> TeamsChat:
        other_participants = self._other_participants(item)
        return TeamsChat(
            id=_string_value(item.get("id")),
            topic=_string_value(item.get("topic")),
            display_label=_chat_display_label(item, other_participants),
            chat_type=_string_value(item.get("chatType")),
            created_at=_parse_graph_datetime(item.get("createdDateTime")),
            last_updated_at=_parse_graph_datetime(item.get("lastUpdatedDateTime")),
            last_message_read_at=_parse_graph_datetime(item.get("lastMessageReadDateTime")),
            web_url=_string_value(item.get("webUrl")),
            is_hidden=bool(item.get("isHidden", False)),
            is_hidden_for_all_members=bool(item.get("isHiddenForAllMembers", False)),
            other_participants=other_participants,
        )

    def _team_from_item(self, item: dict[str, Any]) -> TeamSummary:
        return TeamSummary(
            id=_string_value(item.get("id")),
            display_name=_string_value(item.get("displayName")),
            description=_string_value(item.get("description")),
            is_archived=bool(item.get("isArchived", False)),
            tenant_id=_string_value(item.get("tenantId")),
        )

    def _channel_from_item(self, item: dict[str, Any]) -> ChannelSummary:
        return ChannelSummary(
            id=_string_value(item.get("id")),
            display_name=_string_value(item.get("displayName")),
            description=_string_value(item.get("description")),
            membership_type=_string_value(item.get("membershipType")),
            web_url=_string_value(item.get("webUrl")),
        )

    def _message_from_item(
        self,
        item: dict[str, Any],
        *,
        chat_id: str = "",
        team_id: str = "",
        channel_id: str = "",
    ) -> TeamsMessage:
        body = item.get("body", {})
        content_type = _string_value(body.get("contentType"))
        content = _string_value(body.get("content"))
        reply_count = 0
        replies = item.get("replies")
        if isinstance(replies, list):
            reply_count = len(replies)
        from_value = item.get("from")
        sender_root = from_value if isinstance(from_value, dict) else {}
        sender_identity = sender_root.get("user")
        if not isinstance(sender_identity, dict):
            sender_identity = (
                sender_root.get("application")
                or sender_root.get("device")
                or {}
            )
        return TeamsMessage(
            id=_string_value(item.get("id")),
            body_content=_normalize_body(content, content_type),
            content_type=content_type,
            created_at=_parse_graph_datetime(item.get("createdDateTime")),
            last_modified_at=_parse_graph_datetime(item.get("lastModifiedDateTime")),
            last_edited_at=_parse_graph_datetime(item.get("lastEditedDateTime")),
            deleted_at=_parse_graph_datetime(item.get("deletedDateTime")),
            subject=_string_value(item.get("subject")),
            summary=_string_value(item.get("summary")),
            importance=_string_value(item.get("importance")),
            message_type=_string_value(item.get("messageType")),
            reply_to_id=_string_value(item.get("replyToId")),
            reply_count=reply_count,
            web_url=_string_value(item.get("webUrl")),
            chat_id=chat_id,
            team_id=team_id,
            channel_id=channel_id,
            sender=TeamsSender(
                display_name=_string_value(sender_identity.get("displayName")),
                email=_string_value(sender_identity.get("email")),
                user_id=_string_value(sender_identity.get("id")),
                kind=_sender_kind(sender_root),
            ),
        )

    def _other_participants(self, item: dict[str, Any]) -> tuple[TeamsParticipant, ...]:
        members = item.get("members")
        if not isinstance(members, list):
            return ()
        participants: list[TeamsParticipant] = []
        for member in members:
            if not isinstance(member, dict):
                continue
            participant = TeamsParticipant(
                display_name=_string_value(member.get("displayName")),
                email=_string_value(member.get("email")),
                user_id=_string_value(member.get("userId")),
            )
            if self._is_viewer_participant(participant):
                continue
            participants.append(participant)
        return tuple(participants)

    def _is_viewer_participant(self, participant: TeamsParticipant) -> bool:
        if not self.viewer_user_id and not self.viewer_email:
            return False
        if self.viewer_user_id and participant.user_id == self.viewer_user_id:
            return True
        return bool(self.viewer_email and participant.email.lower() == self.viewer_email)


def _parse_graph_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _normalize_body(content: str, content_type: str) -> str:
    if content_type.lower() == "html":
        return strip_html(content)
    return content.strip()


def _sender_kind(value: dict[str, Any]) -> str:
    if "user" in value:
        return "user"
    if "application" in value:
        return "application"
    if "device" in value:
        return "device"
    return "unknown"


def _channel_permission_error(error: GraphAPIError) -> GraphAPIError:
    if error.status_code != 403:
        return error
    normalized_message = error.message.lower()
    if not any(
        marker in normalized_message
        for marker in (
            "channelmessage.read.all",
            "missing role permissions",
            "insufficient privileges",
        )
    ):
        return error
    return GraphAPIError(
        403,
        error.error_code,
        "Teams channel reads require admin-approved ChannelMessage.Read.All consent",
    )


def _bounded_top(value: int, *, maximum: int) -> int:
    if value <= 0:
        raise ValueError("top must be a positive integer")
    return min(value, maximum)


def _path_segment(name: str, value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{name} must be a non-empty string")
    return quote(normalized, safe="")


def _string_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    return ""


def _viewer_identity(token: str, configured_upn: str) -> tuple[str, str]:
    try:
        payload = jwt.decode(token, options={"verify_signature": False, "verify_aud": False})
    except jwt.PyJWTError:
        payload = {}
    user_id = _string_value(payload.get("oid"))
    email = _string_value(
        payload.get("preferred_username") or payload.get("upn") or payload.get("email")
    )
    if not email and configured_upn:
        email = configured_upn
    return user_id, email.lower()


def _chat_display_label(item: dict[str, Any], participants: tuple[TeamsParticipant, ...]) -> str:
    topic = _string_value(item.get("topic"))
    if topic:
        return topic
    labels = [
        label
        for participant in participants
        for label in (_participant_label(participant),)
        if label
    ]
    if labels:
        return ", ".join(labels)
    return _string_value(item.get("id"))


def _participant_label(participant: TeamsParticipant) -> str:
    return participant.display_name or participant.email


def _normalized_query(query: str) -> str:
    normalized = query.strip().lower()
    if not normalized:
        raise ValueError("query must be a non-empty string")
    return normalized


def _chat_search_score(chat: TeamsChat, query: str) -> tuple[int, int, float] | None:
    query_terms = _search_terms(query)
    exact_email = any(participant.email.lower() == query for participant in chat.other_participants)
    if exact_email:
        return _chat_rank_tuple(chat, 4)
    exact_name = any(
        query_terms and _search_terms(participant.display_name) == query_terms
        for participant in chat.other_participants
    )
    if exact_name:
        return _chat_rank_tuple(chat, 3)
    participant_match = any(
        query in participant.display_name.lower()
        or query in participant.email.lower()
        or _contains_search_terms(participant.display_name, query_terms)
        or _contains_search_terms(participant.email, query_terms)
        for participant in chat.other_participants
    )
    if participant_match:
        return _chat_rank_tuple(chat, 2)
    topic = _searchable_text(chat.topic)
    display_label = _searchable_text(chat.display_label)
    if query in topic or query in display_label:
        return _chat_rank_tuple(chat, 1)
    return None


def _chat_rank_tuple(chat: TeamsChat, bucket: int) -> tuple[int, int, float]:
    is_one_on_one = 1 if chat.chat_type == "oneOnOne" else 0
    last_updated = chat.last_updated_at.timestamp() if chat.last_updated_at is not None else 0.0
    return bucket, is_one_on_one, last_updated


def _message_search_score(message: TeamsMessage, query: str) -> tuple[int, float] | None:
    sender_display = message.sender.display_name.lower()
    sender_email = message.sender.email.lower()
    subject = _searchable_text(message.subject)
    summary = _searchable_text(message.summary)
    body = _searchable_text(message.body_content)
    combined = " ".join(
        part
        for part in (
            sender_display,
            sender_email,
            subject,
            summary,
            body,
        )
        if part
    )
    if sender_email == query:
        return _message_rank_tuple(message, 4)
    if query and _search_terms(message.sender.display_name) == _search_terms(query):
        return _message_rank_tuple(message, 3)
    if query in subject or query in summary:
        return _message_rank_tuple(message, 2)
    if query in body or query in combined:
        return _message_rank_tuple(message, 1)
    if _contains_search_terms(combined, _search_terms(query)):
        return _message_rank_tuple(message, 1)
    return None


def _message_rank_tuple(message: TeamsMessage, bucket: int) -> tuple[int, float]:
    created_at = message.created_at.timestamp() if message.created_at is not None else 0.0
    return bucket, created_at


def _search_terms(value: str) -> tuple[str, ...]:
    return tuple(sorted(re.findall(r"[a-z0-9]+", value.lower())))


def _searchable_text(value: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", value.lower()))


def _contains_search_terms(value: str, query_terms: tuple[str, ...]) -> bool:
    if not query_terms:
        return False
    value_terms = set(_search_terms(value))
    return set(query_terms).issubset(value_terms)


def _sort_messages_oldest_first(messages: list[TeamsMessage]) -> list[TeamsMessage]:
    indexed_messages = list(enumerate(messages))
    indexed_messages.sort(
        key=lambda item: (
            item[1].created_at is None,
            item[1].created_at.timestamp() if item[1].created_at is not None else 0.0,
            item[0],
        )
    )
    return [message for _, message in indexed_messages]
