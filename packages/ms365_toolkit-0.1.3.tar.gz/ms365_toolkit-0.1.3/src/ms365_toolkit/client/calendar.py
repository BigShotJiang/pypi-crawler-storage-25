from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from ms365_toolkit.client.sanitize import strip_html
from ms365_toolkit.models.calendar import Attendee, CalendarEvent, FreeBusySlot

if TYPE_CHECKING:
    from ms365_toolkit.client.graph import GraphClient


class CalendarClient:
    def __init__(self, graph: GraphClient) -> None:
        self.graph = graph

    def list_events(
        self,
        *,
        start: datetime,
        end: datetime,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
    ) -> list[CalendarEvent]:
        path = f"calendars/{calendar_id}/calendarView" if calendar_id else "calendarView"
        query: dict[str, Any] = {
            "startDateTime": _to_graph_datetime(start),
            "endDateTime": _to_graph_datetime(end),
            "$orderby": "start/dateTime",
        }
        if calendar_filter:
            query["$filter"] = calendar_filter
        response = self.graph.get(path, query=query)
        return [self._event_from_item(item) for item in response.get("value", [])]

    def get_event(self, event_id: str) -> CalendarEvent:
        response = self.graph.get(f"events/{event_id}")
        return self._event_from_item(response)

    def find_free_slots(
        self,
        *,
        attendees: list[str],
        start: datetime,
        end: datetime,
        duration: int,
    ) -> list[FreeBusySlot]:
        response = self.graph.post(
            "calendar/getSchedule",
            body={
                "schedules": attendees,
                "startTime": {"dateTime": _to_graph_datetime(start), "timeZone": "UTC"},
                "endTime": {"dateTime": _to_graph_datetime(end), "timeZone": "UTC"},
                "availabilityViewInterval": duration,
            },
        )
        slots: list[FreeBusySlot] = []
        for schedule in response.get("value", []):
            for item in schedule.get("scheduleItems", []):
                slots.append(
                    FreeBusySlot(
                        start=_parse_graph_datetime(item.get("start", {}).get("dateTime")),
                        end=_parse_graph_datetime(item.get("end", {}).get("dateTime")),
                        status=item.get("status", "unknown"),
                    )
                )
        return slots

    def list_calendars(self) -> list[dict[str, str]]:
        response = self.graph.get("calendars", query={"$top": 100})
        return [
            {"id": item.get("id", ""), "name": item.get("name", "")}
            for item in response.get("value", [])
        ]

    def search_events(
        self,
        *,
        query: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[CalendarEvent]:
        filters = [f"contains(subject,'{_escape_odata_string(query)}')"]
        if start is not None:
            filters.append(f"start/dateTime ge '{_to_graph_datetime(start)}'")
        if end is not None:
            filters.append(f"end/dateTime le '{_to_graph_datetime(end)}'")
        response = self.graph.get("events", query={"$filter": " and ".join(filters)})
        return [self._event_from_item(item) for item in response.get("value", [])]

    def _event_from_item(self, item: dict[str, Any]) -> CalendarEvent:
        attendees = tuple(self._attendee_from_item(value) for value in item.get("attendees", []))
        body = item.get("body", {}).get("content", "")
        start_time = item.get("start", {})
        end_time = item.get("end", {})
        location = item.get("location", {}).get("displayName", "")
        response_status = item.get("responseStatus", {}).get("response", "none")
        organizer = (
            item.get("organizer", {})
            .get("emailAddress", {})
            .get("address", "")
        )
        return CalendarEvent(
            id=item.get("id", ""),
            subject=item.get("subject", ""),
            start=_parse_graph_datetime(start_time.get("dateTime")),
            end=_parse_graph_datetime(end_time.get("dateTime")),
            timezone=start_time.get("timeZone", "UTC"),
            location=location,
            body_content=strip_html(body),
            attendees=attendees,
            is_online_meeting=bool(item.get("isOnlineMeeting", False)),
            is_cancelled=bool(item.get("isCancelled", False)),
            importance=item.get("importance", "normal"),
            categories=tuple(item.get("categories", [])),
            recurrence=str(item.get("recurrence")) if item.get("recurrence") is not None else None,
            organizer=organizer,
            response_status=response_status,
            calendar_id=item.get("calendar", {}).get("id", ""),
        )

    def _attendee_from_item(self, item: dict[str, Any]) -> Attendee:
        email = item.get("emailAddress", {})
        status = item.get("status", {})
        return Attendee(
            email=email.get("address", ""),
            name=email.get("name", ""),
            response=status.get("response", "none"),
            type=item.get("type", "required"),
        )


def _to_graph_datetime(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _parse_graph_datetime(value: Any) -> datetime:
    if not isinstance(value, str) or not value:
        return datetime.fromtimestamp(0, tz=UTC)
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _escape_odata_string(value: str) -> str:
    return value.replace("'", "''")
