from ms365_toolkit.client.calendar import CalendarClient
from ms365_toolkit.client.email import EmailClient
from ms365_toolkit.client.exceptions import (
    AuthenticationError,
    GraphAPIError,
    InsufficientScopesError,
    RateLimitedError,
    SafetyDeniedError,
)
from ms365_toolkit.client.graph import GraphClient, build_odata_query
from ms365_toolkit.client.mail_index import IndexedMessage, IndexedThread, MailboxIndex
from ms365_toolkit.client.sanitize import sanitize_email_body, strip_html, wrap_untrusted

__all__ = [
    "AuthenticationError",
    "CalendarClient",
    "EmailClient",
    "GraphAPIError",
    "GraphClient",
    "IndexedMessage",
    "IndexedThread",
    "InsufficientScopesError",
    "MailboxIndex",
    "RateLimitedError",
    "SafetyDeniedError",
    "build_odata_query",
    "sanitize_email_body",
    "strip_html",
    "wrap_untrusted",
]
