from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from hashlib import sha256
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable

    from ms365_toolkit.models.calendar import CalendarEvent
    from ms365_toolkit.models.email import EmailDraft

_WHITESPACE_RE = re.compile(r"\s+")


def canonicalize_email(draft: EmailDraft) -> str:
    payload = {
        "attachments": sorted(
            (
                {"name": attachment.name, "sha256": attachment.sha256}
                for attachment in draft.attachments
                if not attachment.is_reference
            ),
            key=lambda item: item["name"],
        ),
        "bcc": _normalize_emails(draft.bcc),
        "body_content": canonicalize_body(draft.body),
        "cc": _normalize_emails(draft.cc),
        "importance": draft.importance,
        "reply_to": _normalize_emails(draft.reply_to),
        "subject": draft.subject,
        "to": _normalize_emails(draft.to),
    }
    return _to_canonical_json(payload)


def canonicalize_event(event: CalendarEvent) -> str:
    payload = {
        "attendees": _normalize_emails(attendee.email for attendee in event.attendees),
        "body_content": canonicalize_body(event.body_content),
        "end": _normalize_datetime(event.end),
        "is_cancelled": event.is_cancelled,
        "is_online_meeting": event.is_online_meeting,
        "location_display_name": event.location,
        "start": _normalize_datetime(event.start),
        "subject": event.subject,
        "timezone": event.timezone,
    }
    return _to_canonical_json(payload)


def compute_hash(canonical: str) -> str:
    return sha256(canonical.encode("utf-8")).hexdigest()


def canonicalize_body(text: str) -> str:
    return _WHITESPACE_RE.sub(" ", text).strip()


def _normalize_emails(emails: Iterable[str]) -> list[str]:
    return sorted(email.strip().lower() for email in emails)


def _normalize_datetime(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _to_canonical_json(payload: dict[str, object]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))
