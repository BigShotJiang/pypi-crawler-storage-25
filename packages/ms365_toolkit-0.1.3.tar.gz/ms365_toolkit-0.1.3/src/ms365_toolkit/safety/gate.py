from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class DialogPreview:
    title: str
    body: str


@dataclass(frozen=True)
class AuditEvent:
    tool_name: str
    action: str
    reason: str = ""


@dataclass(frozen=True)
class WriteOperation:
    tool_name: str
    payload_hash: str


@dataclass(frozen=True)
class SafetyResult:
    allowed: bool
    reason: str


class SafetyGate(Protocol):
    def check_domain(self, recipients: tuple[str, ...]) -> SafetyResult: ...

    def check_folder(self, folder_id: str) -> SafetyResult: ...

    def check_rate_limit(self, tool: str) -> SafetyResult: ...

    def show_dialog(self, preview: DialogPreview) -> SafetyResult: ...

    def verify_hash(self, expected: str, actual: str) -> SafetyResult: ...

    def audit(self, event: AuditEvent) -> None: ...

    def full_check(self, operation: WriteOperation) -> SafetyResult: ...


class NoOpSafetyGate:
    def __init__(self) -> None:
        self.audit_log: list[AuditEvent] = []

    def check_domain(self, recipients: tuple[str, ...]) -> SafetyResult:
        return SafetyResult(True, f"allowed:{len(recipients)}")

    def check_folder(self, folder_id: str) -> SafetyResult:
        return SafetyResult(True, folder_id)

    def check_rate_limit(self, tool: str) -> SafetyResult:
        return SafetyResult(True, tool)

    def show_dialog(self, preview: DialogPreview) -> SafetyResult:
        return SafetyResult(True, preview.title)

    def verify_hash(self, expected: str, actual: str) -> SafetyResult:
        return SafetyResult(
            expected == actual,
            "hash_match" if expected == actual else "hash_mismatch",
        )

    def audit(self, event: AuditEvent) -> None:
        self.audit_log.append(event)

    def full_check(self, operation: WriteOperation) -> SafetyResult:
        return SafetyResult(True, operation.tool_name)
