from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable


def email_matches_domain_patterns(email: str, patterns: Iterable[str]) -> bool:
    domain = _email_domain(email)
    if domain is None:
        return False
    return any(_domain_matches_pattern(domain, pattern) for pattern in patterns)


def _email_domain(email: str) -> str | None:
    normalized = email.strip().lower()
    if "@" not in normalized:
        return None
    return normalized.rsplit("@", 1)[1].rstrip(".")


def _domain_matches_pattern(domain: str, pattern: str) -> bool:
    normalized_domain = domain.strip().lower().strip(".")
    normalized_pattern = pattern.strip().lower()
    if not normalized_domain or not normalized_pattern:
        return False
    if normalized_pattern.startswith("."):
        suffix = normalized_pattern[1:].strip(".")
        if not suffix:
            return False
        return normalized_domain == suffix or normalized_domain.endswith(f".{suffix}")
    return normalized_domain == normalized_pattern.strip(".")
