from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.cli.read_common import build_read_clients

if TYPE_CHECKING:
    from argparse import Namespace

    from ms365_toolkit.config.loader import ToolkitConfig


def inbox_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, _ = build_read_clients(config, args.profile)
    mailbox_filter = None if args.filter == "all" else args.filter
    messages = email_client.list_inbox(mailbox_filter=mailbox_filter, top=args.top, skip=0)
    if not messages:
        print("No messages found.")
        return 0
    for message in messages:
        print(
            f"{message.received_at.isoformat()} {message.id} "
            f"{message.conversation_id} {message.sender} {message.subject}"
        )
    return 0
