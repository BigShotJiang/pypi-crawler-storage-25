from __future__ import annotations

import ipaddress
import json
import webbrowser
from dataclasses import asdict
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import TYPE_CHECKING
from urllib.parse import parse_qs, unquote, urlparse

from ms365_toolkit.cli.labeling import _labels_path, apply_thread_label, list_label_candidates
from ms365_toolkit.intelligence.labels import ThreadLabelRecord, ThreadLabels

if TYPE_CHECKING:
    from argparse import Namespace

    from ms365_toolkit.config.loader import ToolkitConfig


def launch_label_ui_command(args: Namespace, config: ToolkitConfig) -> int:
    if not _is_loopback_host(args.host):
        print("Label UI supports loopback hosts only. Use 127.0.0.1, localhost, or ::1.")
        return 1
    server = ThreadingHTTPServer((args.host, args.port), _make_handler(args.profile))
    host = args.host if args.host != "0.0.0.0" else "127.0.0.1"
    url = f"http://{host}:{server.server_port}"
    print(f"Label UI available at {url}")
    if not args.no_open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping label UI")
    finally:
        server.server_close()
    return 0


def _make_handler(profile: str) -> type[BaseHTTPRequestHandler]:
    labels_path = _labels_path(profile)

    class LabelingHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path == "/":
                _write_html(self, _index_html())
                return
            if parsed.path == "/api/records":
                query = parse_qs(parsed.query)
                status = query.get("status", ["unlabeled"])[0]
                top = int(query.get("top", ["100"])[0])
                payload = _records_payload(
                    list_label_candidates(labels_path, status=status, top=top),
                )
                _write_json(self, payload)
                return
            _write_json(self, {"error": "Not found"}, status=HTTPStatus.NOT_FOUND)

        def do_POST(self) -> None:
            parsed = urlparse(self.path)
            if not parsed.path.startswith("/api/records/") or not parsed.path.endswith("/label"):
                _write_json(self, {"error": "Not found"}, status=HTTPStatus.NOT_FOUND)
                return
            thread_id = unquote(
                parsed.path.removeprefix("/api/records/").removesuffix("/label"),
            )
            content_length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(content_length) or b"{}")
            try:
                record = apply_thread_label(
                    labels_path,
                    thread_id=thread_id,
                    labels=ThreadLabels(
                        thread_class=str(payload["thread_class"]),
                        action_needed=str(payload["action_needed"]),
                        urgency=str(payload["urgency"]),
                        acted_by_you=str(payload["acted_by_you"]),
                        confidence=float(payload["confidence"]),
                    ),
                    notes=None if payload.get("notes") is None else str(payload["notes"]),
                )
            except (KeyError, ValueError) as error:
                _write_json(
                    self,
                    {"error": str(error)},
                    status=HTTPStatus.BAD_REQUEST,
                )
                return
            _write_json(self, _serialize_record(record))

        def log_message(self, message_format: str, *args: object) -> None:
            return

    return LabelingHandler


def _records_payload(records: list[ThreadLabelRecord]) -> dict[str, object]:
    return {"records": [_serialize_record(record) for record in records]}


def _serialize_record(record: ThreadLabelRecord) -> dict[str, object]:
    payload = asdict(record)
    if record.labels is None:
        payload["labels"] = None
    return payload


def _write_html(handler: BaseHTTPRequestHandler, body: str) -> None:
    encoded = body.encode("utf-8")
    handler.send_response(HTTPStatus.OK)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Content-Length", str(len(encoded)))
    handler.end_headers()
    handler.wfile.write(encoded)


def _write_json(
    handler: BaseHTTPRequestHandler,
    payload: dict[str, object],
    *,
    status: HTTPStatus = HTTPStatus.OK,
) -> None:
    encoded = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(encoded)))
    handler.end_headers()
    handler.wfile.write(encoded)


def _is_loopback_host(host: str) -> bool:
    normalized = host.strip().lower()
    if normalized == "localhost":
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def _index_html() -> str:
    return """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MS365 Thread Labels</title>
  <style>
    :root {
      --bg: #f2ede4;
      --panel: #fffaf2;
      --ink: #1e1d1b;
      --muted: #6b645c;
      --line: #d9cfbe;
      --accent: #b54d2e;
      --accent-soft: #f6d8cb;
      --ok: #345f41;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Georgia, "Iowan Old Style", serif;
      color: var(--ink);
      background:
        radial-gradient(circle at top left, #fdf3db 0, transparent 35%),
        linear-gradient(180deg, #efe5d7 0, var(--bg) 100%);
      min-height: 100vh;
    }
    .app {
      display: grid;
      grid-template-columns: 360px minmax(0, 1fr);
      min-height: 100vh;
    }
    .sidebar, .detail {
      padding: 24px;
    }
    .sidebar {
      border-right: 1px solid var(--line);
      background: rgba(255, 250, 242, 0.92);
      backdrop-filter: blur(14px);
    }
    .detail {
      display: grid;
      grid-template-rows: auto 1fr auto;
      gap: 18px;
    }
    h1, h2, h3, p { margin: 0; }
    h1 { font-size: 28px; }
    .subtle { color: var(--muted); }
    .controls, .stats, .form-grid {
      display: grid;
      gap: 12px;
    }
    .controls { margin-top: 18px; }
    .thread-list {
      margin-top: 18px;
      display: grid;
      gap: 10px;
      max-height: calc(100vh - 220px);
      overflow: auto;
      padding-right: 4px;
    }
    .thread-item {
      border: 1px solid var(--line);
      background: var(--panel);
      border-radius: 14px;
      padding: 14px;
      cursor: pointer;
      transition: transform 120ms ease, border-color 120ms ease, box-shadow 120ms ease;
    }
    .thread-item:hover, .thread-item.active {
      transform: translateY(-1px);
      border-color: var(--accent);
      box-shadow: 0 12px 24px rgba(107, 74, 53, 0.08);
    }
    .pill {
      display: inline-block;
      padding: 3px 8px;
      border-radius: 999px;
      background: var(--accent-soft);
      color: var(--accent);
      font-size: 12px;
      margin-top: 8px;
    }
    .panel {
      border: 1px solid var(--line);
      background: rgba(255, 250, 242, 0.94);
      border-radius: 18px;
      padding: 18px;
    }
    .meta {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 10px 18px;
      margin-top: 14px;
      font-size: 14px;
    }
    .body {
      white-space: pre-wrap;
      line-height: 1.55;
      max-height: 44vh;
      overflow: auto;
      color: #28251f;
    }
    label {
      display: grid;
      gap: 6px;
      font-size: 14px;
    }
    select, textarea, input, button {
      font: inherit;
    }
    select, textarea, input {
      width: 100%;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: #fffef9;
      padding: 10px 12px;
      color: var(--ink);
    }
    textarea { min-height: 100px; resize: vertical; }
    .form-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .form-grid .full { grid-column: 1 / -1; }
    .actions {
      display: flex;
      gap: 10px;
      align-items: center;
    }
    button {
      border: 0;
      border-radius: 999px;
      padding: 11px 18px;
      background: var(--accent);
      color: #fff8f0;
      cursor: pointer;
    }
    button.secondary {
      background: #e8ddcc;
      color: var(--ink);
    }
    .status-ok { color: var(--ok); }
    @media (max-width: 900px) {
      .app { grid-template-columns: 1fr; }
      .sidebar { border-right: 0; border-bottom: 1px solid var(--line); }
      .thread-list { max-height: 260px; }
      .form-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="app">
    <aside class="sidebar">
      <h1>Thread Labels</h1>
      <p class="subtle">Review exported email threads and label them quickly.</p>
      <div class="controls">
        <label>
          Status
          <select id="status">
            <option value="unlabeled" selected>Unlabeled</option>
            <option value="labeled">Labeled</option>
            <option value="all">All</option>
          </select>
        </label>
        <label>
          Max threads
          <input id="top" type="number" min="1" max="500" value="50">
        </label>
        <div class="actions">
          <button id="refresh" class="secondary" type="button">Refresh</button>
          <span id="summary" class="subtle"></span>
        </div>
      </div>
      <div id="thread-list" class="thread-list"></div>
    </aside>
    <main class="detail">
      <section class="panel">
        <h2 id="subject">No thread selected</h2>
        <p id="preview" class="subtle"></p>
        <div id="meta" class="meta"></div>
      </section>
      <section class="panel body" id="body"></section>
      <section class="panel">
        <h3>Labels</h3>
        <div class="form-grid">
          <label>
            Thread class
            <select id="thread_class">
              <option value="approval_request">approval_request</option>
              <option value="decision_request">decision_request</option>
              <option value="incident_or_risk">incident_or_risk</option>
              <option value="contract_or_renewal">contract_or_renewal</option>
              <option value="strategic_update">strategic_update</option>
              <option value="status_update">status_update</option>
              <option value="fyi_noise">fyi_noise</option>
            </select>
          </label>
          <label>
            Action needed
            <select id="action_needed">
              <option value="yes">yes</option>
              <option value="no">no</option>
              <option value="unclear">unclear</option>
            </select>
          </label>
          <label>
            Urgency
            <select id="urgency">
              <option value="high">high</option>
              <option value="medium" selected>medium</option>
              <option value="low">low</option>
            </select>
          </label>
          <label>
            Acted by you
            <select id="acted_by_you">
              <option value="replied">replied</option>
              <option value="forwarded">forwarded</option>
              <option value="ignored">ignored</option>
              <option value="archived">archived</option>
              <option value="unknown" selected>unknown</option>
            </select>
          </label>
          <label>
            Confidence
            <input id="confidence" type="number" min="0" max="1" step="0.05" value="0.8">
          </label>
          <label class="full">
            Notes
            <textarea id="notes" placeholder="Optional rationale"></textarea>
          </label>
        </div>
        <div class="actions" style="margin-top:14px;">
          <button id="save" type="button">Save + Next</button>
          <button id="reload" class="secondary" type="button">Reload Thread</button>
          <span id="message" class="subtle"></span>
        </div>
      </section>
    </main>
  </div>
  <script>
    const state = { records: [], selectedIndex: -1 };

    async function loadRecords() {
      const status = document.getElementById("status").value;
      const top = document.getElementById("top").value;
      const query =
        `/api/records?status=${encodeURIComponent(status)}&top=${encodeURIComponent(top)}`;
      const response = await fetch(query);
      const payload = await response.json();
      state.records = payload.records || [];
      state.selectedIndex = state.records.length ? 0 : -1;
      renderList();
      renderDetail();
      document.getElementById("summary").textContent = `${state.records.length} threads`;
    }

    function currentRecord() {
      return state.selectedIndex >= 0 ? state.records[state.selectedIndex] : null;
    }

    function renderList() {
      const list = document.getElementById("thread-list");
      list.innerHTML = "";
      state.records.forEach((record, index) => {
        const item = document.createElement("button");
        item.type = "button";
        item.className = `thread-item${index === state.selectedIndex ? " active" : ""}`;
        const labelText = record.labels ? record.labels.thread_class : "unlabeled";
        item.innerHTML = `<strong>${escapeHtml(record.subject)}</strong>
          <div class="subtle">${escapeHtml(record.sender)}</div>
          <div class="pill">${escapeHtml(labelText)}</div>`;
        item.addEventListener("click", () => {
          state.selectedIndex = index;
          renderList();
          renderDetail();
        });
        list.appendChild(item);
      });
      if (!state.records.length) {
        list.innerHTML = '<div class="subtle">No threads for this filter.</div>';
      }
    }

    function renderDetail() {
      const record = currentRecord();
      document.getElementById("message").textContent = "";
      if (!record) {
        document.getElementById("subject").textContent = "No thread selected";
        document.getElementById("preview").textContent = "";
        document.getElementById("meta").innerHTML = "";
        document.getElementById("body").textContent = "";
        return;
      }
      document.getElementById("subject").textContent = record.subject;
      document.getElementById("preview").textContent = record.body_preview;
      document.getElementById("meta").innerHTML = `
        <div><strong>Thread ID</strong><br>${escapeHtml(record.thread_id)}</div>
        <div><strong>Message ID</strong><br>${escapeHtml(record.message_id)}</div>
        <div><strong>From</strong><br>${escapeHtml(record.sender)}
          (${escapeHtml(record.sender_type)})</div>
        <div><strong>Received</strong><br>${escapeHtml(record.received_at)}</div>
        <div><strong>Thread Size</strong><br>${record.thread_size}</div>
        <div><strong>Cluster Size</strong><br>${record.cluster_size}</div>
      `;
      document.getElementById("body").textContent = record.body_content;
      const labels = record.labels || {
        thread_class: "status_update",
        action_needed: "unclear",
        urgency: "medium",
        acted_by_you: "unknown",
        confidence: 0.8
      };
      document.getElementById("thread_class").value = labels.thread_class;
      document.getElementById("action_needed").value = labels.action_needed;
      document.getElementById("urgency").value = labels.urgency;
      document.getElementById("acted_by_you").value = labels.acted_by_you;
      document.getElementById("confidence").value = labels.confidence;
      document.getElementById("notes").value = record.notes || "";
    }

    async function saveCurrent() {
      const record = currentRecord();
      if (!record) {
        return;
      }
      const payload = {
        thread_class: document.getElementById("thread_class").value,
        action_needed: document.getElementById("action_needed").value,
        urgency: document.getElementById("urgency").value,
        acted_by_you: document.getElementById("acted_by_you").value,
        confidence: Number(document.getElementById("confidence").value),
        notes: document.getElementById("notes").value
      };
      const response = await fetch(`/api/records/${encodeURIComponent(record.thread_id)}/label`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const updated = await response.json();
      state.records[state.selectedIndex] = updated;
      document.getElementById("message").textContent = "Saved";
      document.getElementById("message").className = "status-ok";
      const status = document.getElementById("status").value;
      if (status === "unlabeled") {
        state.records.splice(state.selectedIndex, 1);
        if (state.selectedIndex >= state.records.length) {
          state.selectedIndex = state.records.length - 1;
        }
      } else if (state.selectedIndex < state.records.length - 1) {
        state.selectedIndex += 1;
      }
      renderList();
      renderDetail();
    }

    function escapeHtml(value) {
      return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
    }

    document.getElementById("refresh").addEventListener("click", loadRecords);
    document.getElementById("reload").addEventListener("click", renderDetail);
    document.getElementById("save").addEventListener("click", saveCurrent);
    document.getElementById("status").addEventListener("change", loadRecords);
    loadRecords();
  </script>
</body>
</html>"""
