from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.auth.credentials import CredentialStore
from ms365_toolkit.auth.tokens import TokenManager
from ms365_toolkit.cli.auth import build_public_client_application
from ms365_toolkit.client.calendar import CalendarClient
from ms365_toolkit.client.email import EmailClient
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.client.mail_index import MailboxIndex
from ms365_toolkit.config.loader import get_profile_dir

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig


def build_read_clients(config: ToolkitConfig, profile: str) -> tuple[EmailClient, CalendarClient]:
    graph = build_read_graph_client(config, profile)
    return EmailClient(graph), CalendarClient(graph)


def build_read_graph_client(
    config: ToolkitConfig,
    profile: str,
    *,
    extra_scopes: frozenset[str] | None = None,
) -> GraphClient:
    store = CredentialStore(profile=profile)
    manager = TokenManager(
        config=config,
        credential_store=store,
        app_factory=lambda cache: build_public_client_application(config, cache),
    )
    bundle = manager.get_access_token(write=False, extra_scopes=extra_scopes)
    return GraphClient(config=config, token=bundle.access_token)


def build_mailbox_index(profile: str) -> MailboxIndex:
    return MailboxIndex(get_profile_dir(profile) / "mail_index.db")
