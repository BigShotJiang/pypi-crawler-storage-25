from __future__ import annotations

import re
from typing import TYPE_CHECKING

from ms365_toolkit.cli.read_common import build_mailbox_index, build_read_clients
from ms365_toolkit.intelligence.labels import (
    ThreadLabelRecord,
    ThreadLabels,
    append_label_record,
    default_labels_path,
    find_label_record,
    read_label_records,
    upsert_label_record,
)
from ms365_toolkit.safety.domains import email_matches_domain_patterns

if TYPE_CHECKING:
    from argparse import Namespace
    from pathlib import Path

    from ms365_toolkit.config.loader import ToolkitConfig


def export_label_candidates_command(args: Namespace, config: ToolkitConfig) -> int:
    email_client, _ = build_read_clients(config, args.profile)
    index = build_mailbox_index(args.profile)
    if args.sync_index:
        index.sync(email_client, batch_size=args.top, max_pages=args.max_pages)
    threads = index.recent_threads(limit=args.top)
    labels_path = _labels_path(args.profile)
    exported = 0
    for thread in threads:
        message = email_client.read_email(thread.latest_message_id)
        record = ThreadLabelRecord(
            thread_id=thread.conversation_id,
            message_id=thread.latest_message_id,
            subject=message.subject,
            sender=message.sender,
            sender_type=_sender_type(message.sender, config),
            received_at=message.received_at.isoformat(),
            body_preview=message.body_preview,
            body_content=_preview(message.body_content),
            thread_size=thread.message_count,
            cluster_size=1,
            labels=None,
            notes="",
        )
        append_label_record(labels_path, record)
        exported += 1
    print(f"Exported {exported} thread candidates to {labels_path}")
    return 0


def label_thread_command(args: Namespace, config: ToolkitConfig) -> int:
    labels_path = _labels_path(args.profile)
    apply_thread_label(
        labels_path,
        thread_id=args.thread_id,
        labels=ThreadLabels(
            thread_class=args.thread_class,
            action_needed=args.action_needed,
            urgency=args.urgency,
            acted_by_you=args.acted_by_you,
            confidence=args.confidence,
        ),
        notes=args.notes,
    )
    print(f"Labeled thread {args.thread_id} in {labels_path}")
    return 0


def review_label_candidates_command(args: Namespace, config: ToolkitConfig) -> int:
    labels_path = _labels_path(args.profile)
    records = list_label_candidates(
        labels_path,
        status=args.status,
        top=args.top,
        thread_id=args.thread_id,
    )
    if not records:
        print(f"No {args.status} label candidates found in {labels_path}")
        return 0
    for index, record in enumerate(records, start=1):
        print(f"[{index}] {record.subject}")
        print(f"Thread ID: {record.thread_id}")
        print(f"Message ID: {record.message_id}")
        print(f"From: {record.sender} ({record.sender_type})")
        print(f"Received: {record.received_at}")
        print(f"Thread size: {record.thread_size}  Cluster size: {record.cluster_size}")
        print(f"Preview: {record.body_preview}")
        print(f"Body: {record.body_content}")
        if record.labels is None:
            print("Labels: <unlabeled>")
        else:
            print(
                "Labels: "
                f"class={record.labels.thread_class}, "
                f"action_needed={record.labels.action_needed}, "
                f"urgency={record.labels.urgency}, "
                f"acted_by_you={record.labels.acted_by_you}, "
                f"confidence={record.labels.confidence:.2f}"
            )
        print(f"Notes: {record.notes or '<none>'}")
        if index != len(records):
            print()
    return 0


def list_label_candidates(
    labels_path: Path,
    *,
    status: str,
    top: int,
    thread_id: str | None = None,
) -> list[ThreadLabelRecord]:
    records = read_label_records(labels_path)
    if thread_id:
        records = [record for record in records if record.thread_id == thread_id]
    elif status == "unlabeled":
        records = [record for record in records if record.labels is None]
    elif status == "labeled":
        records = [record for record in records if record.labels is not None]
    return sorted(records, key=lambda item: item.received_at, reverse=True)[:top]


def apply_thread_label(
    labels_path: Path,
    *,
    thread_id: str,
    labels: ThreadLabels,
    notes: str | None,
) -> ThreadLabelRecord:
    existing = find_label_record(labels_path, thread_id)
    if existing is None:
        raise ValueError(f"Thread {thread_id} was not found in {labels_path}")
    record = ThreadLabelRecord(
        thread_id=existing.thread_id,
        message_id=existing.message_id,
        subject=existing.subject,
        sender=existing.sender,
        sender_type=existing.sender_type,
        received_at=existing.received_at,
        body_preview=existing.body_preview,
        body_content=existing.body_content,
        thread_size=existing.thread_size,
        cluster_size=existing.cluster_size,
        labels=labels,
        notes=notes if notes is not None else existing.notes,
    )
    upsert_label_record(labels_path, record)
    return record


def _labels_path(profile: str) -> Path:
    return default_labels_path(profile)


def _preview(body_content: str) -> str:
    plain = re.sub(r"</?untrusted-email-content>", "", body_content)
    return " ".join(plain.split())[:500]


def _sender_type(sender: str, config: ToolkitConfig) -> str:
    normalized = sender.lower()
    automated_markers = ("no-reply", "noreply", "alerts@", "automatic", "digest", "bot")
    if _is_internal_sender(normalized, config):
        if any(marker in normalized for marker in automated_markers):
            return "automated_internal"
        return "human_internal"
    if any(marker in normalized for marker in automated_markers):
        return "automated_external"
    return "human_external"


def _is_internal_sender(sender: str, config: ToolkitConfig) -> bool:
    if "@" not in sender:
        return False
    sender_domain = sender.rsplit("@", 1)[1]
    if config.user.user_principal_name and "@" in config.user.user_principal_name:
        own_domain = config.user.user_principal_name.strip().lower().rsplit("@", 1)[1]
        if sender_domain == own_domain:
            return True
    return email_matches_domain_patterns(sender, config.safety.domain_allowlist)
