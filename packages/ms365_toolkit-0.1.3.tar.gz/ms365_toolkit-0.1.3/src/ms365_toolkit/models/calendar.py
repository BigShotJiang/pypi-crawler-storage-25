from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime


@dataclass(frozen=True)
class Attendee:
    email: str
    name: str
    response: str
    type: str


@dataclass(frozen=True)
class CalendarEvent:
    id: str
    subject: str
    start: datetime
    end: datetime
    timezone: str
    location: str
    body_content: str
    attendees: tuple[Attendee, ...]
    is_online_meeting: bool
    is_cancelled: bool
    importance: str
    categories: tuple[str, ...]
    recurrence: str | None
    organizer: str
    response_status: str
    calendar_id: str


@dataclass(frozen=True)
class FreeBusySlot:
    start: datetime
    end: datetime
    status: str
