from __future__ import annotations

from enum import StrEnum


class Scope(StrEnum):
    MAIL_READ = "Mail.Read"
    CALENDARS_READ = "Calendars.Read"
    CHAT_READ = "Chat.Read"
    TEAM_READ_BASIC_ALL = "Team.ReadBasic.All"
    CHANNEL_READ_BASIC_ALL = "Channel.ReadBasic.All"
    CHANNEL_MESSAGE_READ_ALL = "ChannelMessage.Read.All"
    MAIL_READ_WRITE = "Mail.ReadWrite"
    MAIL_SEND = "Mail.Send"
    CALENDARS_READ_WRITE = "Calendars.ReadWrite"
    MAIL_READ_SHARED = "Mail.Read.Shared"
    CALENDARS_READ_SHARED = "Calendars.Read.Shared"
    MAIL_READ_WRITE_SHARED = "Mail.ReadWrite.Shared"
    MAIL_SEND_SHARED = "Mail.Send.Shared"
    CALENDARS_READ_WRITE_SHARED = "Calendars.ReadWrite.Shared"
    MAILBOX_SETTINGS_READ = "MailboxSettings.Read"
    MAILBOX_SETTINGS_READ_WRITE = "MailboxSettings.ReadWrite"


TEAMS_READ_SCOPES = frozenset(
    {
        Scope.CHAT_READ.value,
        Scope.TEAM_READ_BASIC_ALL.value,
        Scope.CHANNEL_READ_BASIC_ALL.value,
    }
)
CHANNEL_MESSAGE_READ_SCOPES = frozenset({Scope.CHANNEL_MESSAGE_READ_ALL.value})
READ_SCOPES = frozenset(
    {
        Scope.MAIL_READ.value,
        Scope.CALENDARS_READ.value,
        Scope.MAILBOX_SETTINGS_READ.value,
    }
) | TEAMS_READ_SCOPES
WRITE_SCOPES = frozenset(
    {
        Scope.MAIL_READ_WRITE.value,
        Scope.MAIL_SEND.value,
        Scope.CALENDARS_READ_WRITE.value,
        Scope.MAILBOX_SETTINGS_READ_WRITE.value,
    }
)
DELEGATED_READ_SCOPES = frozenset(
    {Scope.MAIL_READ_SHARED.value, Scope.CALENDARS_READ_SHARED.value}
)
DELEGATED_WRITE_SCOPES = frozenset(
    {
        Scope.MAIL_READ_WRITE_SHARED.value,
        Scope.MAIL_SEND_SHARED.value,
        Scope.CALENDARS_READ_WRITE_SHARED.value,
    }
)


class Badge(StrEnum):
    PRIORITY = "PRIORITY"
    FLAGGED = "FLAGGED"
    VIP = "VIP"
    EXTERNAL = "EXTERNAL"
    NONE = ""
