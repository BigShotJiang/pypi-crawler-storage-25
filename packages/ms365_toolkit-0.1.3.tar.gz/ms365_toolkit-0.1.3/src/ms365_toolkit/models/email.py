from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime


@dataclass(frozen=True)
class AttachmentInfo:
    name: str
    content_type: str
    size: int
    sha256: str
    is_reference: bool


@dataclass(frozen=True)
class EmailMessage:
    id: str
    subject: str
    sender: str
    to: tuple[str, ...]
    cc: tuple[str, ...]
    bcc: tuple[str, ...]
    body_preview: str
    body_content: str
    received_at: datetime
    is_read: bool
    is_flagged: bool
    importance: str
    has_attachments: bool
    attachments: tuple[AttachmentInfo, ...]
    conversation_id: str
    folder_id: str


@dataclass(frozen=True)
class EmailDraft:
    draft_id: str
    content_hash: str
    to: tuple[str, ...]
    cc: tuple[str, ...]
    bcc: tuple[str, ...]
    subject: str
    body: str
    attachments: tuple[AttachmentInfo, ...]
    reply_to: tuple[str, ...]
    importance: str
    created_at: datetime
