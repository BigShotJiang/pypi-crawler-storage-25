from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

LABELS_FILENAME = "thread_labels.jsonl"


@dataclass(frozen=True)
class ThreadLabels:
    thread_class: str
    action_needed: str
    urgency: str
    acted_by_you: str
    confidence: float


@dataclass(frozen=True)
class ThreadLabelRecord:
    thread_id: str
    message_id: str
    subject: str
    sender: str
    sender_type: str
    received_at: str
    body_preview: str
    body_content: str
    thread_size: int
    cluster_size: int
    labels: ThreadLabels | None
    notes: str


def default_labels_path(profile: str) -> Path:
    return Path.home() / ".ms365-toolkit" / "profiles" / profile / LABELS_FILENAME


def append_label_record(path: Path, record: ThreadLabelRecord) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(_serialize_record(record), ensure_ascii=True) + "\n")


def read_label_records(path: Path) -> list[ThreadLabelRecord]:
    if not path.exists():
        return []
    records: list[ThreadLabelRecord] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        payload = json.loads(line)
        labels = payload.get("labels")
        records.append(
            ThreadLabelRecord(
                thread_id=str(payload["thread_id"]),
                message_id=str(payload["message_id"]),
                subject=str(payload["subject"]),
                sender=str(payload["sender"]),
                sender_type=str(payload["sender_type"]),
                received_at=str(payload["received_at"]),
                body_preview=str(payload["body_preview"]),
                body_content=str(payload["body_content"]),
                thread_size=int(payload["thread_size"]),
                cluster_size=int(payload["cluster_size"]),
                labels=None if labels is None else ThreadLabels(**labels),
                notes=str(payload.get("notes", "")),
            )
        )
    return records


def find_label_record(path: Path, thread_id: str) -> ThreadLabelRecord | None:
    for record in read_label_records(path):
        if record.thread_id == thread_id:
            return record
    return None


def upsert_label_record(path: Path, record: ThreadLabelRecord) -> None:
    existing = {item.thread_id: item for item in read_label_records(path)}
    existing[record.thread_id] = record
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for item in existing.values():
            handle.write(json.dumps(_serialize_record(item), ensure_ascii=True) + "\n")


def _serialize_record(record: ThreadLabelRecord) -> dict[str, Any]:
    payload = asdict(record)
    if record.labels is None:
        payload["labels"] = None
    return payload
