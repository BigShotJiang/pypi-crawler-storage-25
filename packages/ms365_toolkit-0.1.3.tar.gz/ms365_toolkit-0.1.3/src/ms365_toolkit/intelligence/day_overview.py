from __future__ import annotations

from dataclasses import dataclass
from itertools import pairwise
from typing import TYPE_CHECKING

from ms365_toolkit.intelligence.calendar_scoring import ScoredEvent, score_event

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig
    from ms365_toolkit.models.calendar import CalendarEvent


@dataclass(frozen=True)
class FreeTimeBlock:
    start_iso: str
    end_iso: str


@dataclass(frozen=True)
class Conflict:
    first_event_id: str
    second_event_id: str


@dataclass(frozen=True)
class DayOverview:
    ranked_events: tuple[ScoredEvent, ...]
    free_blocks: tuple[FreeTimeBlock, ...]
    conflicts: tuple[Conflict, ...]


def day_overview(events: list[CalendarEvent], config: ToolkitConfig) -> DayOverview:
    ordered_events = sorted(events, key=lambda event: event.start)
    ranked_events = tuple(
        sorted(
            (score_event(event, config) for event in ordered_events),
            key=lambda item: item.score,
            reverse=True,
        )
    )
    free_blocks: list[FreeTimeBlock] = []
    conflicts: list[Conflict] = []
    for current, next_event in pairwise(ordered_events):
        if current.end < next_event.start:
            free_blocks.append(
                FreeTimeBlock(
                    start_iso=current.end.isoformat(),
                    end_iso=next_event.start.isoformat(),
                )
            )
        if current.end > next_event.start:
            conflicts.append(Conflict(first_event_id=current.id, second_event_id=next_event.id))
    return DayOverview(
        ranked_events=ranked_events,
        free_blocks=tuple(free_blocks),
        conflicts=tuple(conflicts),
    )
