from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ms365_toolkit.intelligence.labels import ThreadLabelRecord

TOKEN_PATTERN = re.compile(r"[a-z0-9$]+")


@dataclass(frozen=True)
class ThreadPrediction:
    thread_class: str
    confidence: float


@dataclass(frozen=True)
class ThreadClassifier:
    class_counts: dict[str, int]
    token_counts: dict[str, Counter[str]]
    total_tokens: dict[str, int]
    vocabulary: frozenset[str]
    total_examples: int

    def predict(
        self,
        *,
        subject: str,
        sender: str,
        sender_type: str,
        body_preview: str,
        body_content: str,
    ) -> ThreadPrediction:
        tokens = _tokens_for_thread(
            subject=subject,
            sender=sender,
            sender_type=sender_type,
            body_preview=body_preview,
            body_content=body_content,
        )
        vocabulary_size = max(len(self.vocabulary), 1)
        scores: dict[str, float] = {}
        for thread_class, count in self.class_counts.items():
            log_probability = math.log(count / self.total_examples)
            class_token_counts = self.token_counts[thread_class]
            denominator = self.total_tokens[thread_class] + vocabulary_size
            for token in tokens:
                token_count = class_token_counts.get(token, 0)
                log_probability += math.log((token_count + 1) / denominator)
            scores[thread_class] = log_probability
        winning_class = max(scores, key=lambda key: scores[key])
        probabilities = _softmax(scores)
        return ThreadPrediction(
            thread_class=winning_class,
            confidence=probabilities[winning_class],
        )


def train_thread_classifier(records: list[ThreadLabelRecord]) -> ThreadClassifier | None:
    labeled = [record for record in records if record.labels is not None]
    if len(labeled) < 8:
        return None
    class_counts = Counter(
        record.labels.thread_class
        for record in labeled
        if record.labels is not None
    )
    if len(class_counts) < 2:
        return None

    token_counts: dict[str, Counter[str]] = {
        thread_class: Counter()
        for thread_class in class_counts
    }
    total_tokens: dict[str, int] = {thread_class: 0 for thread_class in class_counts}
    vocabulary: set[str] = set()

    for record in labeled:
        assert record.labels is not None
        tokens = _tokens_for_thread(
            subject=record.subject,
            sender=record.sender,
            sender_type=record.sender_type,
            body_preview=record.body_preview,
            body_content=record.body_content,
        )
        token_counts[record.labels.thread_class].update(tokens)
        total_tokens[record.labels.thread_class] += len(tokens)
        vocabulary.update(tokens)

    return ThreadClassifier(
        class_counts=dict(class_counts),
        token_counts=token_counts,
        total_tokens=total_tokens,
        vocabulary=frozenset(vocabulary),
        total_examples=len(labeled),
    )


def _tokens_for_thread(
    *,
    subject: str,
    sender: str,
    sender_type: str,
    body_preview: str,
    body_content: str,
) -> list[str]:
    tokens: list[str] = []
    tokens.extend(_tokenize(subject))
    tokens.extend(_tokenize(subject))
    tokens.extend(_tokenize(body_preview))
    tokens.extend(_tokenize(body_content)[:120])
    tokens.append(f"sender_type:{sender_type}")
    sender_domain = _sender_domain(sender)
    if sender_domain:
        tokens.append(f"sender_domain:{sender_domain}")
    return tokens


def _sender_domain(sender: str) -> str | None:
    normalized = sender.strip().lower()
    if "@" not in normalized:
        return None
    return normalized.rsplit("@", 1)[1]


def _tokenize(value: str) -> list[str]:
    return TOKEN_PATTERN.findall(value.lower())


def _softmax(scores: dict[str, float]) -> dict[str, float]:
    max_score = max(scores.values())
    exponents = {key: math.exp(value - max_score) for key, value in scores.items()}
    total = sum(exponents.values())
    return {key: value / total for key, value in exponents.items()}
