from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ms365_toolkit.intelligence.vip import is_vip
from ms365_toolkit.models.enums import Badge
from ms365_toolkit.safety.domains import email_matches_domain_patterns

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig
    from ms365_toolkit.models.email import EmailMessage


@dataclass(frozen=True)
class TriageResult:
    email: EmailMessage
    badge: Badge
    action_required: bool
    summary: str


def triage_email(email: EmailMessage, config: ToolkitConfig) -> TriageResult:
    combined_text = f"{email.subject}\n{email.body_content}".lower()
    critical_keywords = _keywords(config.intelligence.critical_keywords)
    action_keywords = _keywords(config.intelligence.action_keywords)
    priority = any(keyword in combined_text for keyword in critical_keywords)
    action_required = any(keyword in combined_text for keyword in action_keywords)
    sender_is_vip = is_vip(email.sender, config)
    badge = _classify_badge(
        email=email,
        config=config,
        priority=priority,
        sender_is_vip=sender_is_vip,
    )
    return TriageResult(
        email=email,
        badge=badge,
        action_required=action_required,
        summary=_build_summary(email),
    )


def _classify_badge(
    *,
    email: EmailMessage,
    config: ToolkitConfig,
    priority: bool,
    sender_is_vip: bool,
) -> Badge:
    if priority:
        return Badge.PRIORITY
    if email.is_flagged:
        return Badge.FLAGGED
    if sender_is_vip:
        return Badge.VIP
    if _is_external_sender(email.sender, config):
        return Badge.EXTERNAL
    return Badge.NONE


def _build_summary(email: EmailMessage) -> str:
    sender = email.sender or "unknown sender"
    if email.importance == "high" or email.is_flagged:
        return "\n".join(
            [
                f"From: {sender}",
                f"Subject: {email.subject or '(no subject)'}",
                f"Preview: {email.body_preview}",
            ]
        )
    return f"{sender}: {email.subject or '(no subject)'}"


def _is_external_sender(sender: str, config: ToolkitConfig) -> bool:
    normalized_sender = sender.strip().lower()
    if "@" not in normalized_sender:
        return True
    sender_domain = normalized_sender.rsplit("@", 1)[1]
    if config.user.user_principal_name and "@" in config.user.user_principal_name:
        own_domain = config.user.user_principal_name.strip().lower().rsplit("@", 1)[1]
        if sender_domain == own_domain:
            return False
    if not config.safety.domain_allowlist:
        return True
    return not email_matches_domain_patterns(sender, config.safety.domain_allowlist)


def _keywords(values: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(value.lower() for value in values)
