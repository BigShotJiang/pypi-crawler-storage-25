from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.safety.domains import email_matches_domain_patterns

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig


def is_vip(email_address: str, config: ToolkitConfig) -> bool:
    normalized = email_address.strip().lower()
    if normalized in {email.lower() for email in config.vip.emails}:
        return True
    return email_matches_domain_patterns(normalized, config.vip.domains)
