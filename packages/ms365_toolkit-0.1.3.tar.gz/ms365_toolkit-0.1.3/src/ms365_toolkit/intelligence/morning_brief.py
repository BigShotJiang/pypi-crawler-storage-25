from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

from ms365_toolkit.intelligence.calendar_scoring import ScoredEvent, score_event
from ms365_toolkit.intelligence.email_triage import TriageResult, triage_email
from ms365_toolkit.models.enums import Badge

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig
    from ms365_toolkit.models.calendar import CalendarEvent
    from ms365_toolkit.models.email import EmailMessage


@dataclass(frozen=True)
class BriefResult:
    action_required: tuple[TriageResult, ...]
    vip: tuple[TriageResult, ...]
    flagged: tuple[TriageResult, ...]
    fyi: tuple[TriageResult, ...]
    upcoming_events: tuple[ScoredEvent, ...]


def morning_brief(
    emails: list[EmailMessage],
    events: list[CalendarEvent],
    config: ToolkitConfig,
) -> BriefResult:
    triaged = [triage_email(email, config) for email in emails]
    action_required = tuple(item for item in triaged if item.action_required)
    vip = tuple(item for item in triaged if item.badge == Badge.VIP)
    flagged = tuple(item for item in triaged if item.badge == Badge.FLAGGED)
    fyi = tuple(
        item
        for item in triaged
        if item not in action_required and item not in vip and item not in flagged
    )
    upcoming_events = tuple(
        sorted(
            (
                score_event(event, config)
                for event in events
                if _within_next_eight_hours(event.start)
            ),
            key=lambda item: item.score,
            reverse=True,
        )
    )
    return BriefResult(
        action_required=action_required,
        vip=vip,
        flagged=flagged,
        fyi=fyi,
        upcoming_events=upcoming_events,
    )


def _within_next_eight_hours(start: datetime) -> bool:
    now = datetime.now(UTC)
    if start.tzinfo is None:
        start = start.replace(tzinfo=UTC)
    window_end = now + timedelta(hours=8)
    start_utc = start.astimezone(UTC)
    return now <= start_utc <= window_end
