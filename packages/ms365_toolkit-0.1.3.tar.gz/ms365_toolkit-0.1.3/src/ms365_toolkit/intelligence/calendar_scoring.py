from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig
    from ms365_toolkit.models.calendar import CalendarEvent


@dataclass(frozen=True)
class ScoredEvent:
    event: CalendarEvent
    score: int
    category: str


def score_event(event: CalendarEvent, config: ToolkitConfig) -> ScoredEvent:
    combined_text = f"{event.subject}\n{event.body_content}".lower()
    score = 50
    score += _keyword_hits(combined_text, config.intelligence.critical_keywords, 20)
    score -= _keyword_hits(combined_text, config.intelligence.noise_keywords, 15)
    score += {"high": 15, "normal": 0, "low": -10}.get(event.importance, 0)
    score += _proximity_score(event.start)
    score += min(len(event.attendees), 10)
    if len(event.attendees) <= 1:
        score -= 10
    bounded = max(0, min(score, 100))
    return ScoredEvent(event=event, score=bounded, category=_category_for_score(bounded))


def _keyword_hits(text: str, keywords: tuple[str, ...], weight: int) -> int:
    return sum(weight for keyword in keywords if keyword.lower() in text)


def _proximity_score(start: datetime) -> int:
    now = datetime.now(UTC)
    if start.tzinfo is None:
        start = start.replace(tzinfo=UTC)
    delta = start.astimezone(UTC) - now
    hours = delta.total_seconds() / 3600
    if hours <= 8:
        return 15
    if hours <= 24:
        return 8
    if hours <= 72:
        return 3
    return 0


def _category_for_score(score: int) -> str:
    if score >= 80:
        return "critical"
    if score >= 65:
        return "important"
    if score >= 40:
        return "routine"
    return "noise"
