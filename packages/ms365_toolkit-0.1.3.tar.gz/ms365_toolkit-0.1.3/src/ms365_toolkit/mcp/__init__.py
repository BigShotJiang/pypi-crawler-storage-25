from ms365_toolkit.mcp.server import create_server

__all__ = ["create_server", "main"]


def main(argv: object | None = None) -> int:
    from ms365_toolkit.mcp.__main__ import main as _main

    return _main(argv)
