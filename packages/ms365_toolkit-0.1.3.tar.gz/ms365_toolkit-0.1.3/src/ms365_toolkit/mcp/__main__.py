from __future__ import annotations

import argparse
import os
from typing import TYPE_CHECKING

from ms365_toolkit.mcp.server import create_server

if TYPE_CHECKING:
    from collections.abc import Sequence


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="ms365-toolkit-mcp")
    parser.add_argument(
        "--profile",
        default=os.environ.get("MS365_TOOLKIT_PROFILE", "default"),
    )
    args = parser.parse_args(argv)
    create_server(profile=args.profile).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
