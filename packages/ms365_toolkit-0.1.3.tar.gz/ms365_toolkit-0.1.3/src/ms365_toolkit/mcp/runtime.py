from __future__ import annotations

from dataclasses import dataclass

from ms365_toolkit.auth.credentials import CredentialStore
from ms365_toolkit.auth.tokens import TokenManager
from ms365_toolkit.cli.auth import build_public_client_application
from ms365_toolkit.client.calendar import CalendarClient
from ms365_toolkit.client.email import EmailClient
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.client.teams import TeamsClient
from ms365_toolkit.config.loader import ToolkitConfig, load_config
from ms365_toolkit.models.enums import CHANNEL_MESSAGE_READ_SCOPES


@dataclass(frozen=True)
class ReadRuntime:
    profile: str
    config: ToolkitConfig

    @classmethod
    def load(cls, profile: str = "default") -> ReadRuntime:
        return cls(profile=profile, config=load_config(profile=profile))

    def graph_client(self, *, extra_scopes: frozenset[str] | None = None) -> GraphClient:
        store = CredentialStore(profile=self.profile)
        manager = TokenManager(
            config=self.config,
            credential_store=store,
            app_factory=lambda cache: build_public_client_application(self.config, cache),
        )
        bundle = manager.get_access_token(write=False, extra_scopes=extra_scopes)
        return GraphClient(config=self.config, token=bundle.access_token)

    def email_client(self) -> EmailClient:
        return EmailClient(self.graph_client())

    def calendar_client(self) -> CalendarClient:
        return CalendarClient(self.graph_client())

    def teams_client(self, *, include_channel_messages: bool = False) -> TeamsClient:
        graph = self.graph_client()
        channel_graph = (
            self.graph_client(extra_scopes=CHANNEL_MESSAGE_READ_SCOPES)
            if include_channel_messages
            else graph
        )
        return TeamsClient(graph, channel_graph=channel_graph)
