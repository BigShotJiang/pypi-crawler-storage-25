from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence


BLOCKING_STATUSES = frozenset({"busy", "tentative", "oof", "workingelsewhere", "unknown"})


def find_open_windows(
    response: dict[str, Any],
    *,
    start: datetime,
    end: datetime,
    duration_minutes: int,
    ignore_subject_terms: Sequence[str],
) -> list[tuple[datetime, datetime]]:
    if duration_minutes <= 0:
        raise ValueError("duration_minutes must be a positive integer")
    ignored = tuple(term.strip().lower() for term in ignore_subject_terms if term.strip())
    busy_ranges: list[tuple[datetime, datetime]] = []
    for schedule in response.get("value", []):
        if not isinstance(schedule, dict):
            continue
        for item in schedule.get("scheduleItems", []):
            if not isinstance(item, dict):
                continue
            status = str(item.get("status", "unknown")).lower()
            if status not in BLOCKING_STATUSES:
                continue
            subject = str(item.get("subject", ""))
            if _should_ignore_subject(subject, ignored):
                continue
            item_start = _parse_schedule_datetime(item.get("start", {}).get("dateTime"))
            item_end = _parse_schedule_datetime(item.get("end", {}).get("dateTime"))
            if item_end <= start or item_start >= end:
                continue
            busy_ranges.append((max(start, item_start), min(end, item_end)))
    merged = _merge_ranges(sorted(busy_ranges, key=lambda item: item[0]))
    return _invert_ranges(
        merged,
        start=start,
        end=end,
        duration=timedelta(minutes=duration_minutes),
    )


def _should_ignore_subject(subject: str, ignored_terms: Sequence[str]) -> bool:
    lowered = subject.strip().lower()
    return any(term in lowered for term in ignored_terms)


def _parse_schedule_datetime(value: Any) -> datetime:
    if not isinstance(value, str) or not value:
        return datetime.fromtimestamp(0, tz=UTC)
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _merge_ranges(ranges: Sequence[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    merged: list[tuple[datetime, datetime]] = []
    for start, end in ranges:
        if not merged or start > merged[-1][1]:
            merged.append((start, end))
            continue
        merged[-1] = (merged[-1][0], max(merged[-1][1], end))
    return merged


def _invert_ranges(
    ranges: Sequence[tuple[datetime, datetime]],
    *,
    start: datetime,
    end: datetime,
    duration: timedelta,
) -> list[tuple[datetime, datetime]]:
    windows: list[tuple[datetime, datetime]] = []
    cursor = start
    for blocked_start, blocked_end in ranges:
        if blocked_start > cursor and blocked_start - cursor >= duration:
            windows.append((cursor, blocked_start))
        if blocked_end > cursor:
            cursor = blocked_end
    if end > cursor and end - cursor >= duration:
        windows.append((cursor, end))
    return windows
