from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence

    from ms365_toolkit.models.calendar import Attendee, CalendarEvent
    from ms365_toolkit.models.email import AttachmentInfo, EmailMessage
    from ms365_toolkit.models.teams import (
        ChannelSummary,
        TeamsChat,
        TeamsMessage,
        TeamsParticipant,
        TeamsReplyPage,
        TeamsSender,
        TeamsThread,
        TeamSummary,
    )


def isoformat_utc(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def isoformat_utc_or_none(value: datetime | None) -> str | None:
    if value is None:
        return None
    return isoformat_utc(value)


def serialize_email(message: EmailMessage) -> dict[str, Any]:
    return {
        "id": message.id,
        "subject": message.subject,
        "sender": message.sender,
        "to": list(message.to),
        "cc": list(message.cc),
        "bcc": list(message.bcc),
        "body_preview": message.body_preview,
        "body_content": message.body_content,
        "received_at": isoformat_utc(message.received_at),
        "is_read": message.is_read,
        "is_flagged": message.is_flagged,
        "importance": message.importance,
        "has_attachments": message.has_attachments,
        "attachments": [serialize_attachment(item) for item in message.attachments],
        "conversation_id": message.conversation_id,
        "folder_id": message.folder_id,
    }


def serialize_attachment(attachment: AttachmentInfo) -> dict[str, Any]:
    return {
        "name": attachment.name,
        "content_type": attachment.content_type,
        "size": attachment.size,
        "sha256": attachment.sha256,
        "is_reference": attachment.is_reference,
    }


def serialize_event(event: CalendarEvent) -> dict[str, Any]:
    return {
        "id": event.id,
        "subject": event.subject,
        "start": isoformat_utc(event.start),
        "end": isoformat_utc(event.end),
        "timezone": event.timezone,
        "location": event.location,
        "body_content": event.body_content,
        "attendees": [serialize_attendee(item) for item in event.attendees],
        "is_online_meeting": event.is_online_meeting,
        "is_cancelled": event.is_cancelled,
        "importance": event.importance,
        "categories": list(event.categories),
        "recurrence": event.recurrence,
        "organizer": event.organizer,
        "response_status": event.response_status,
        "calendar_id": event.calendar_id,
    }


def serialize_attendee(attendee: Attendee) -> dict[str, Any]:
    return {
        "email": attendee.email,
        "name": attendee.name,
        "response": attendee.response,
        "type": attendee.type,
    }


def serialize_windows(windows: Sequence[tuple[datetime, datetime]]) -> list[dict[str, Any]]:
    serialized: list[dict[str, Any]] = []
    for start, end in windows:
        serialized.append(
            {
                "start": isoformat_utc(start),
                "end": isoformat_utc(end),
                "duration_minutes": int((end - start).total_seconds() // 60),
            }
        )
    return serialized


def serialize_chat(chat: TeamsChat) -> dict[str, Any]:
    return {
        "id": chat.id,
        "topic": chat.topic,
        "display_label": chat.display_label,
        "chat_type": chat.chat_type,
        "created_at": isoformat_utc_or_none(chat.created_at),
        "last_updated_at": isoformat_utc_or_none(chat.last_updated_at),
        "last_message_read_at": isoformat_utc_or_none(chat.last_message_read_at),
        "web_url": chat.web_url,
        "is_hidden": chat.is_hidden,
        "is_hidden_for_all_members": chat.is_hidden_for_all_members,
        "other_participants": [
            serialize_teams_participant(item) for item in chat.other_participants
        ],
    }


def serialize_team(team: TeamSummary) -> dict[str, Any]:
    return {
        "id": team.id,
        "display_name": team.display_name,
        "description": team.description,
        "is_archived": team.is_archived,
        "tenant_id": team.tenant_id,
    }


def serialize_channel(channel: ChannelSummary) -> dict[str, Any]:
    return {
        "id": channel.id,
        "display_name": channel.display_name,
        "description": channel.description,
        "membership_type": channel.membership_type,
        "web_url": channel.web_url,
    }


def serialize_teams_sender(sender: TeamsSender) -> dict[str, Any]:
    return {
        "display_name": sender.display_name,
        "email": sender.email,
        "user_id": sender.user_id,
        "kind": sender.kind,
    }


def serialize_teams_participant(participant: TeamsParticipant) -> dict[str, Any]:
    return {
        "display_name": participant.display_name,
        "email": participant.email,
        "user_id": participant.user_id,
    }


def serialize_teams_message(message: TeamsMessage) -> dict[str, Any]:
    return {
        "id": message.id,
        "body_content": message.body_content,
        "content_type": message.content_type,
        "created_at": isoformat_utc_or_none(message.created_at),
        "last_modified_at": isoformat_utc_or_none(message.last_modified_at),
        "last_edited_at": isoformat_utc_or_none(message.last_edited_at),
        "deleted_at": isoformat_utc_or_none(message.deleted_at),
        "subject": message.subject,
        "summary": message.summary,
        "importance": message.importance,
        "message_type": message.message_type,
        "reply_to_id": message.reply_to_id,
        "reply_count": message.reply_count,
        "web_url": message.web_url,
        "chat_id": message.chat_id,
        "team_id": message.team_id,
        "channel_id": message.channel_id,
        "sender": serialize_teams_sender(message.sender),
    }


def serialize_teams_reply_page(page: TeamsReplyPage) -> dict[str, Any]:
    return {
        "replies": [serialize_teams_message(item) for item in page.replies],
        "has_more_replies": page.has_more_replies,
    }


def serialize_teams_thread(thread: TeamsThread) -> dict[str, Any]:
    return {
        "root_message": serialize_teams_message(thread.root_message),
        "replies": [serialize_teams_message(item) for item in thread.replies],
        "has_more_replies": thread.has_more_replies,
    }
