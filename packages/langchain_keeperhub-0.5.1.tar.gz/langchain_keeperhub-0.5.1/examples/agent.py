"""Minimal OpenAI example: chat completions + KeeperHub tools.

Prerequisites:
    pip install langchain-keeperhub openai python-dotenv

Environment variables:
    KEEPERHUB_API_KEY  -- your org-scoped kh_ key
    OPENAI_API_KEY     -- your OpenAI API key
"""

from __future__ import annotations

import json
import os
from typing import Any

from dotenv import load_dotenv
from openai import OpenAI

from langchain_keeperhub import KeeperHubToolkit

load_dotenv()

_MAX_ROUNDS = 10


def _build_openai_tools(tools: list[Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for tool in tools:
        schema = (
            tool.args_schema.model_json_schema()
            if tool.args_schema
            else {"type": "object"}
        )
        out.append(
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description or "",
                    "parameters": schema,
                },
            }
        )
    return out


def main() -> None:
    openai_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not openai_key:
        raise ValueError("Set OPENAI_API_KEY in the environment (or .env).")

    toolkit = KeeperHubToolkit()
    tools = toolkit.get_tools()
    tool_map = {t.name: t for t in tools}
    openai_tools = _build_openai_tools(tools)

    client = OpenAI(api_key=openai_key)

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": "Be precise and concise."},
        {
            "role": "user",
            "content": (
                "What blockchain networks does KeeperHub support? Use tools when needed."
            ),
        },
    ]

    for _ in range(_MAX_ROUNDS):
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=messages,
            tools=openai_tools,
            tool_choice="auto",
            temperature=0.2,
            max_tokens=500,
        )
        msg = response.choices[0].message
        tool_calls = msg.tool_calls or []

        assistant_message: dict[str, Any] = {
            "role": "assistant",
            "content": msg.content,
        }
        if tool_calls:
            assistant_message["tool_calls"] = [tc.model_dump() for tc in tool_calls]
        messages.append(assistant_message)

        if not tool_calls:
            print(msg.content or "")
            return

        for call in tool_calls:
            tool = tool_map[call.function.name]
            try:
                args = json.loads(call.function.arguments or "{}")
                out = tool.invoke(args)
            except Exception as exc:
                out = {"error": repr(exc)}
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps(out) if isinstance(out, dict) else str(out),
                }
            )

    print("Stopped: max tool rounds reached.")


if __name__ == "__main__":
    main()
