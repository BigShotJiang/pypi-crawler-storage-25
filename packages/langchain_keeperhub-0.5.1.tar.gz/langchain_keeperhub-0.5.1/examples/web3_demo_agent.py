"""Minimal ASI One example: LangChain ReAct agent with KeeperHub tools.

Uses the OpenAI-compatible endpoint at ``https://api.asi1.ai/v1`` (model ``asi1``).

Prerequisites:
    pip install langchain-keeperhub langchain langchain-openai langgraph python-dotenv

Environment variables:
    KEEPERHUB_API_KEY  -- your org-scoped kh_ key
    ASI_ONE_API_KEY    -- your ASI One API key

Raw ``openai`` client equivalent::

    from openai import OpenAI

    client = OpenAI(
        api_key="YOUR_ASI_ONE_API_KEY",
        base_url="https://api.asi1.ai/v1",
    )

    response = client.chat.completions.create(
        model="asi1",
        messages=[...],
        temperature=0.2,
        top_p=0.9,
        max_tokens=1000,
        presence_penalty=0,
        frequency_penalty=0,
        stream=False,
        extra_body={"web_search": False},
    )
"""

from __future__ import annotations

import logging
import os

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI

from langchain_keeperhub import KeeperHubToolkit

load_dotenv()


def main() -> None:
    api_key = os.environ.get("ASI_ONE_API_KEY", "").strip()
    if not api_key:
        raise ValueError(
            "Set ASI_ONE_API_KEY in the environment (or .env) for api.asi1.ai."
        )
    logging.basicConfig(level=logging.DEBUG)

    toolkit = KeeperHubToolkit()  # reads KEEPERHUB_API_KEY from env
    tools = toolkit.get_tools()

    llm = ChatOpenAI(
        model="asi1-mini",
        api_key=api_key,
        base_url="https://api.asi1.ai/v1",
        temperature=0.2,
        top_p=0.9,
        max_tokens=1000,
        presence_penalty=0,
        frequency_penalty=0,
        streaming=False,
        extra_body={"web_search": False},
    )
    agent = create_agent(model=llm, tools=tools)

    result = agent.invoke(
        {
            "messages": [
                (
                    "user",
                    "Transfer 1 0x20c0000000000000000000000000000000000000 token to 0x3E67cc2C7fFf86d9870dB9D02c43e789B52FB296 on chainid: 42431 only, my wallet address is 0x0c30281118fdfA0e51cd517A38BBFD191C1f9b8a",
                )
            ]
        }
    )

    # result = agent.invoke(
    #     {"messages": [("user", "Transfer 2 0x036CbD53842c5426634e7929541eC2318f3dCF7e token to 0x3E67cc2C7fFf86d9870dB9D02c43e789B52FB296 on Base sepolia (chain ID: 84532), my wallet address is 0x0c30281118fdfA0e51cd517A38BBFD191C1f9b8a")]}
    # )

    # result = agent.invoke(
    #     {"messages": [("user", "Transfer 2 0x41E94Eb019C0762f9Bfcf9Fb1E58725BfB0e7582 token to 0x3E67cc2C7fFf86d9870dB9D02c43e789B52FB296 on Polygon Amoy (chain ID: 80002), my wallet address is 0x0c30281118fdfA0e51cd517A38BBFD191C1f9b8a")]}
    # )
    print(result["messages"][-1].content)


if __name__ == "__main__":
    main()
