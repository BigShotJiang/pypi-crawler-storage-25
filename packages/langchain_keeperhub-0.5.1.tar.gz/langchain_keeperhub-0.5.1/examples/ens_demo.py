"""ENS resolution demo: ``ENSClient``, LangChain tools, or a tiny agent.

Default (HTTPS to the chain's default public RPC)::

    python examples/ens_demo.py
    python examples/ens_demo.py --chain base
    python examples/ens_demo.py --chain sepolia

Optional name (default: ``vitalik.eth`` on Ethereum/Sepolia; ``nick.base.eth`` on Base)::

    python examples/ens_demo.py --chain base --name yourname.base.eth

Override RPC for **all** chains (single endpoint; use with care)::

    ENS_RPC_URL=https://... python examples/ens_demo.py

Tools via async ``_arun``::

    python examples/ens_demo.py --tools --chain 1

Agent (needs ``examples`` extras, ``KEEPERHUB_API_KEY``, ``OPENAI_API_KEY``)::

    python examples/ens_demo.py --agent
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys

from langchain_keeperhub import ENSClient, KeeperHubToolkit, ResolveENSTool
from langchain_keeperhub.tools.reverse_resolve_ens import ReverseResolveENSTool


def _default_demo_name(chain: int | str) -> str:
    s = str(chain).strip().lower().replace("_", "-")
    if s in ("8453", "base", "84532", "base-sepolia"):
        return "nick.base.eth"
    return "vitalik.eth"


def _hint_missing_primary(chain_id: int) -> str:
    if chain_id == 11155111:
        return (
            "No primary on Sepolia for this address (forward can still work); "
            "try `python examples/ens_demo.py --chain 1` to see reverse for vitalik.eth."
        )
    if chain_id == 1:
        return "No primary on Ethereum for this address (reverse never set or mismatch)."
    if chain_id in (8453, 84532):
        return "No primary on this Base network for this address."
    return "No primary name on this chain for this address."


async def direct_client_demo(chain: int | str, name: str | None) -> None:
    client = ENSClient(chain=chain)
    try:
        q = name or _default_demo_name(chain)
        addr = await client.resolve(q)
        print(f"[chain={client.default_chain_id}] resolve({q!r}) -> {addr}")
        if addr:
            rev = await client.reverse_resolve(addr)
            print(f"reverse_resolve({addr}) -> {rev!r}")
            if rev is None:
                print(_hint_missing_primary(client.default_chain_id))
    finally:
        await client.aclose()


async def tools_demo(chain: int | str, name: str | None) -> None:
    ens = ENSClient(chain=chain)
    try:
        r, rr = ResolveENSTool(ens_client=ens), ReverseResolveENSTool(ens_client=ens)
        q = name or _default_demo_name(chain)
        forward = await r._arun(name=q)
        print("resolve_ens:", forward)
        addr = forward.get("address")
        if addr:
            print("reverse_resolve_ens:", await rr._arun(address=addr))
    finally:
        await ens.aclose()


async def agent_demo() -> None:
    from dotenv import load_dotenv
    from langchain.agents import create_agent
    from langchain_openai import ChatOpenAI

    load_dotenv()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        print("Set OPENAI_API_KEY for --agent", file=sys.stderr)
        sys.exit(1)
    toolkit = KeeperHubToolkit()
    try:
        tools = [
            t
            for t in toolkit.get_tools()
            if t.name in ("resolve_ens", "reverse_resolve_ens")
        ]
        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        agent = create_agent(model=llm, tools=tools)
        result = agent.invoke(
            {
                "messages": [
                    (
                        "user",
                        "What Ethereum address does vitalik.eth resolve to on "
                        "Ethereum mainnet? Call resolve_ens with chain=1 (or "
                        "'ethereum') once and answer with the address.",
                    )
                ]
            }
        )
        print(result["messages"][-1].content)
    finally:
        await toolkit.aclose()


async def _async_main(mode: str, chain: int | str, name: str | None) -> None:
    if mode == "agent":
        await agent_demo()
    elif mode == "tools":
        await tools_demo(chain, name)
    else:
        await direct_client_demo(chain, name)


def main() -> None:
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description="ENS resolution demo")
    parser.add_argument(
        "--chain",
        default="1",
        help="Chain id or alias (ethereum, sepolia, base, base-sepolia).",
    )
    parser.add_argument(
        "--name",
        default=None,
        help="Name to resolve (defaults by chain; see module docstring).",
    )
    parser.add_argument(
        "--tools",
        action="store_true",
        help="Run ResolveENSTool / ReverseResolveENSTool via _arun.",
    )
    parser.add_argument(
        "--agent",
        action="store_true",
        help="Tiny LangChain agent (needs OPENAI_API_KEY and examples extras).",
    )
    args = parser.parse_args()
    mode = "agent" if args.agent else "tools" if args.tools else "direct"
    chain: int | str = int(args.chain) if str(args.chain).isdigit() else args.chain
    asyncio.run(_async_main(mode, chain, args.name))


if __name__ == "__main__":
    main()
