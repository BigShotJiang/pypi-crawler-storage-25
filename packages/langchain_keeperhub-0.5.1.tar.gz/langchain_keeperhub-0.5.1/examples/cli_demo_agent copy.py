"""Interactive KeeperHub CLI demo agent with real-time tool streaming.

Run:
    python examples/cli_demo_agent.py

Optional:
    python examples/cli_demo_agent.py --once "transfer 1 USDC on chain 42431 ..."

The CLI prints a demo restriction banner (chains 80002 and 42431, limited tokens).
Use ``/tokens`` to show it again. Import ``resolve_demo_token`` if you need the
same mappings from another script.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
from typing import Any

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_keeperhub import KeeperHubToolkit, SqliteExecutionStore
from langchain_openai import ChatOpenAI

MUTED, GREEN, CYAN, RED, RESET = (
    "\033[90m",
    "\033[32m",
    "\033[36m",
    "\033[31m",
    "\033[0m",
)

# Demo scope: must match KeeperHubToolkit(..., allowed_chain_ids=...) below.
DEMO_ALLOWED_CHAIN_IDS: frozenset[int] = frozenset({80002, 42431})
DEMO_CHAIN_NAMES: dict[int, str] = {
    80002: "Polygon Amoy (testnet)",
    42431: "Tempo testnet",
}
# chain_id -> SYMBOL -> contract (0x + lowercase hex)
DEMO_TOKEN_REGISTRY: dict[int, dict[str, str]] = {
    80002: {"USDC": "0x41e94eb019c0762f9bfcf9fb1e58725bfb0e7582"},
    42431: {
        "PathUSD": "0x20c0000000000000000000000000000000000000",
    },
}


def _normalize_hex_address(addr: str) -> str:
    a = addr.strip()
    if not a.startswith("0x"):
        a = "0x" + a[2:] if a.startswith("0X") else "0x" + a
    return "0x" + a[2:].lower()


def _allowed_raw_addresses_for_chain(chain_id: int) -> frozenset[str]:
    return frozenset(DEMO_TOKEN_REGISTRY.get(chain_id, {}).values())


def resolve_demo_token(chain_id: int | str, query: str) -> str | None:
    """Resolve a symbol or an allowlisted 0x address for a demo chain.

    Returns a normalized ``0x`` + 40 hex (lowercase) contract address, or
    ``None`` if the chain is not in the demo set or the token is unknown.
    """
    cid = int(str(chain_id).strip())
    if cid not in DEMO_ALLOWED_CHAIN_IDS:
        return None
    q = query.strip()
    if not q:
        return None
    allowed_raw = _allowed_raw_addresses_for_chain(cid)
    if q.startswith(("0x", "0X")) and len(q) == 42:
        hx = _normalize_hex_address(q)
        return hx if hx in allowed_raw else None
    sym = q.upper()
    return DEMO_TOKEN_REGISTRY.get(cid, {}).get(sym)


def print_demo_scope_banner() -> None:
    """Print which chains and tokens this CLI build is limited to."""
    print(f"{RED}Demo restriction:{RESET}", flush=True)
    print(
        "  This session only allows writes/workflows on these chain IDs:",
        flush=True,
    )
    for cid in sorted(DEMO_ALLOWED_CHAIN_IDS):
        print(
            f"    {CYAN}{cid}{RESET} — {DEMO_CHAIN_NAMES.get(cid, 'unknown')}",
            flush=True,
        )
    print("  Demo tokens (symbol -> contract):", flush=True)
    for cid in sorted(DEMO_ALLOWED_CHAIN_IDS):
        reg = DEMO_TOKEN_REGISTRY.get(cid, {})
        if not reg:
            continue
        print(f"    {cid}:", flush=True)
        for sym, addr in sorted(reg.items()):
            print(f"      {sym} -> {addr}", flush=True)
    print(f"  {MUTED}Native: omit token_address.{RESET}\n", flush=True)

MCP_INCLUDE = frozenset(
    {
        "ai_generate_workflow",
        "create_workflow",
        "execute_workflow",
        "get_execution_status",
        "list_workflows",
        "get_workflow",
    }
)


def _demo_token_rules_for_prompt() -> str:
    cids = ", ".join(str(x) for x in sorted(DEMO_ALLOWED_CHAIN_IDS))
    lines = [
        f"Demo/network bounds: only chain IDs {cids} are in scope for this session.",
        "Resolve user token nicknames to these contracts before building workflows or transfers:",
    ]
    for cid in sorted(DEMO_ALLOWED_CHAIN_IDS):
        label = DEMO_CHAIN_NAMES.get(cid, str(cid))
        lines.append(f"- {cid} ({label}):")
        for sym, addr in sorted(DEMO_TOKEN_REGISTRY.get(cid, {}).items()):
            lines.append(f"  - {sym} -> {addr}")
    lines.append("Native: omit token_address. Unlisted tokens: not supported in this demo.")
    return "\n".join(lines)


SYSTEM_PROMPT = (
    "You are a KeeperHub Web3 demo agent. Execute user intent using only the available "
    "tools and their schemas. For workflow runs: after create or generate, always call "
    "get_workflow (use workflow_get_workflow if that is the name in your tool list) to "
    "read the full workflow definition before execute_workflow, and infer the correct "
    "arguments for the execution call from that payload; then execute, "
    "then poll status until terminal using workflow_get_execution_status with "
    "the returned executionId. "
    "Use list_execution_history when the user asks about past transfers or writes, "
    "to find a recent execution_id to poll with get_execution_status, or to "
    "avoid duplicating an operation that already appears in history. "
    "Keep your final response concise and include proof fields when available: workflow "
    "id, execution id, status, transaction hash, and explorer link.\n\n"
    + _demo_token_rules_for_prompt()
)


def _stringify_tool_output(raw: object) -> str:
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return "<empty>"
        try:
            return json.dumps(json.loads(text), indent=2, ensure_ascii=False)
        except Exception:
            return text
    if isinstance(raw, (dict, list, tuple)):
        value = list(raw) if isinstance(raw, tuple) else raw
        return json.dumps(value, indent=2, ensure_ascii=False)
    return str(raw).strip() or "<empty>"


def _trim_for_console(text: str, head: int = 180, tail: int = 160) -> str:
    if len(text) <= head + tail + 4:
        return text
    return f"{text[:head]}....{text[-tail:]}"


def _apply_payload_to_ctx(ctx: dict[str, str], payload: object) -> None:
    """Merge workflow/on-chain proof fields from tool payloads."""
    if isinstance(payload, dict):
        ctx["workflow_id"] = str(payload.get("id") or ctx["workflow_id"])
        ctx["workflow_name"] = str(payload.get("name") or ctx["workflow_name"])
        ctx["execution_id"] = str(payload.get("executionId") or ctx["execution_id"])
        ctx["status"] = str(payload.get("status") or ctx["status"])
        ctx["tx_hash"] = str(payload.get("transactionHash") or ctx["tx_hash"])
        ctx["tx_link"] = str(payload.get("transactionLink") or ctx["tx_link"])
        if payload.get("error"):
            ctx["error"] = str(payload["error"])
        return

    if isinstance(payload, list):
        for item in payload:
            # MCP tool results often include [{"type":"text","text":"{...json...}"}]
            if isinstance(item, dict) and isinstance(item.get("text"), str):
                try:
                    _apply_payload_to_ctx(ctx, json.loads(item["text"]))
                except Exception:
                    continue
            else:
                _apply_payload_to_ctx(ctx, item)


def _print_proof(ctx: dict[str, str]) -> None:
    print(f"{MUTED}[PROOF]{RESET}", flush=True)
    print(
        "  workflow_id="
        f"{ctx['workflow_id'] or 'n/a'}"
        f" | execution_id={ctx['execution_id'] or 'n/a'}"
        f" | status={ctx['status'] or 'n/a'}",
        flush=True,
    )
    if ctx["tx_link"]:
        print(f"  explorer={CYAN}{ctx['tx_link']}{RESET}", flush=True)
    elif ctx["tx_hash"]:
        print(f"  tx_hash={CYAN}{ctx['tx_hash']}{RESET}", flush=True)
    if ctx["error"]:
        print(f"  error={RED}{ctx['error']}{RESET}", flush=True)


async def _run_turn(agent: Any, user_text: str) -> None:
    payload = {"messages": [("system", SYSTEM_PROMPT), ("user", user_text)]}
    seen = 0
    result = None
    ctx = {
        "workflow_id": "",
        "workflow_name": "",
        "execution_id": "",
        "status": "",
        "tx_hash": "",
        "tx_link": "",
        "error": "",
        "last": "",
    }

    async for state in agent.astream(
        payload, config={"recursion_limit": 40}, stream_mode="values"
    ):
        result = state
        msgs = state.get("messages", [])
        for msg in msgs[seen:]:
            if msg.type == "ai":
                for call in getattr(msg, "tool_calls", None) or []:
                    print(
                        f"{MUTED}[TOOL CALL]{RESET} {CYAN}{call.get('name', '<unknown-tool>')}{RESET}",
                        flush=True,
                    )
            elif msg.type == "tool":
                name = getattr(msg, "name", "tool")
                raw = getattr(msg, "content", "")
                txt = _stringify_tool_output(raw)
                ctx["last"] = txt
                print(f"{MUTED}[TOOL RESULT]{RESET} {CYAN}{name}{RESET}", flush=True)
                print(_trim_for_console(txt), flush=True)
                try:
                    parsed = json.loads(txt)
                except Exception:
                    parsed = None
                if parsed is not None:
                    _apply_payload_to_ctx(ctx, parsed)
                elif "error" in txt.lower():
                    ctx["error"] = txt
        seen = len(msgs)

    print(f"\n{GREEN}Assistant{RESET}", flush=True)
    final = "" if result is None else str(result["messages"][-1].content).strip()
    print(final or "No final assistant message returned.", flush=True)
    _print_proof(ctx)
    print("", flush=True)


async def amain() -> None:
    parser = argparse.ArgumentParser(description="KeeperHub interactive CLI demo agent")
    parser.add_argument(
        "--once",
        type=str,
        default="",
        help="Run a single request and exit.",
    )
    args = parser.parse_args()

    load_dotenv()
    logging.basicConfig(level=logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.CRITICAL)

    asi_key = os.environ.get("ASI_ONE_API_KEY", "").strip()
    if not asi_key:
        raise ValueError("Set ASI_ONE_API_KEY in your environment or .env file.")

    print_demo_scope_banner()

    async with KeeperHubToolkit(
        workflows=True,
        history=SqliteExecutionStore("./ledger_demo.db"),
        testnet_only=True,
        allowed_chain_ids=DEMO_ALLOWED_CHAIN_IDS,
        mcp_include=MCP_INCLUDE,
    ) as toolkit:
        tools = await toolkit.aget_tools()
        print(f"\nKeeperHub CLI Demo Agent | tools={len(tools)}", flush=True)
        print(f"{MUTED}Type /help for commands.{RESET}\n", flush=True)

        agent = create_agent(
            model=ChatOpenAI(
                model="asi1-mini",
                api_key=asi_key,
                base_url="https://api.asi1.ai/v1",
                temperature=0,
                max_retries=0,
            ),
            tools=tools,
        )

        if args.once:
            print(f"{MUTED}Request:{RESET} {args.once}\n", flush=True)
            await _run_turn(agent, args.once)
            return

        while True:
            try:
                user_text = input(f"{CYAN}you>{RESET} ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting.", flush=True)
                return

            if not user_text:
                continue
            if user_text in {"/exit", "exit", "quit", "/quit"}:
                print("Exiting.", flush=True)
                return
            if user_text in {"/help", "help"}:
                print("Commands: /help, /tools, /tokens, /exit", flush=True)
                continue
            if user_text == "/tokens":
                print_demo_scope_banner()
                continue
            if user_text == "/tools":
                for t in tools:
                    print(f"  - {t.name}", flush=True)
                continue

            await _run_turn(agent, user_text)


if __name__ == "__main__":
    asyncio.run(amain())
