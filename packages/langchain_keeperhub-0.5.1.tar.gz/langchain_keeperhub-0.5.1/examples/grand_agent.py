"""Grand KeeperHub demo using ASI1 via OpenAI-compatible API.

Flow shown to judges:
1) Generate workflow from natural language
2) Create/persist workflow
3) Execute the workflow once
4) Poll execution status and summarize result

Prerequisites:
    pip install "langchain-keeperhub[workflows,examples]"

Environment variables:
    KEEPERHUB_API_KEY  -- required, org-scoped KeeperHub key
    ASI_ONE_API_KEY    -- required, API key for https://api.asi1.ai/v1
"""

from __future__ import annotations

import asyncio
import inspect
import json
import os
from collections.abc import Sequence
from typing import Any

from dotenv import load_dotenv
from openai import AsyncOpenAI

from langchain_keeperhub import KeeperHubToolkit

MCP_INCLUDE = frozenset(
    {
        "ai_generate_workflow",
        "create_workflow",
        "execute_workflow",
        "get_execution_status",
        "list_workflows",
        "get_workflow",
    }
)

SYSTEM_PROMPT = (
    "You are a KeeperHub workflow operator. Your job is to create and run one "
    "working workflow in this session. Always prefer these steps in order: "
    "(1) generate workflow, (2) create workflow, (3) execute workflow, "
    "(4) poll execution status until terminal. "
    "Use exact runtime tool names shown in the provided tool list."
)

USER_PROMPT = (
    "Create a workflow that transfers 1 unit of token "
    "0x20c0000000000000000000000000000000000000 to "
    "0x3E67cc2C7fFf86d9870dB9D02c43e789B52FB296 on chain id 42431. "
    "Run it once and return a final ops summary that includes workflow id, "
    "execution id, final status, transaction hash/link (if present), and "
    "any error details."
)

MAX_ROUNDS = 14
TERMINAL_STATUSES = {"completed", "failed", "cancelled", "canceled"}


def _to_openai_tools(tools: Sequence[Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for tool in tools:
        schema = getattr(tool, "args_schema", None)
        if hasattr(schema, "model_json_schema"):
            params = schema.model_json_schema()
        elif isinstance(schema, dict):
            params = schema
        else:
            params = {"type": "object", "properties": {}}
        out.append(
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description or "",
                    "parameters": params,
                },
            }
        )
    return out


async def _invoke_tool(tool: Any, args: dict[str, Any]) -> str:
    if hasattr(tool, "ainvoke"):
        result = await tool.ainvoke(args)
    elif hasattr(tool, "invoke"):
        maybe = tool.invoke(args)
        result = await maybe if inspect.isawaitable(maybe) else maybe
    else:
        raise RuntimeError(f"Tool '{getattr(tool, 'name', '<unknown>')}' is not invokable.")
    return json.dumps(result) if isinstance(result, (dict, list)) else str(result)


def _parse_json_object(raw: str) -> dict[str, Any] | None:
    try:
        obj = json.loads(raw)
    except Exception:
        return None
    return obj if isinstance(obj, dict) else None


async def main() -> None:
    load_dotenv()
    asi_key = os.environ.get("ASI_ONE_API_KEY", "").strip()
    if not asi_key:
        raise ValueError("Set ASI_ONE_API_KEY in your environment or .env file.")

    client = AsyncOpenAI(api_key=asi_key, base_url="https://api.asi1.ai/v1")

    async with KeeperHubToolkit(
        workflows=True,
        testnet_only=True,
        allowed_chain_ids={80002},
        mcp_include=MCP_INCLUDE,
    ) as toolkit:
        tools = await toolkit.aget_tools()
        tool_map = {tool.name: tool for tool in tools}
        openai_tools = _to_openai_tools(tools)

        print(f"KeeperHub Grand Demo (ASI1) | tools={len(tools)}")
        for t in tools:
            print(f"  - {t.name}")
        print("\nRunning generate -> create -> execute -> verify\n")

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": USER_PROMPT},
        ]
        execution_ctx: dict[str, str] = {
            "workflow_id": "",
            "execution_id": "",
            "status": "",
            "tx_hash": "",
            "tx_link": "",
            "error": "",
        }
        status_cache: dict[str, str] = {}

        for round_idx in range(1, MAX_ROUNDS + 1):
            response = await client.chat.completions.create(
                model="asi1-mini",
                messages=messages,
                tools=openai_tools,
                # ASI1 currently expects "required" or an explicit tool dict.
                # "auto" returns 422 on their OpenAI-compatible endpoint.
                tool_choice="required",
                temperature=0,
                max_tokens=1200,
                extra_body={"web_search": False},
            )
            msg = response.choices[0].message
            tool_calls = msg.tool_calls or []

            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": msg.content or "",
            }
            if tool_calls:
                assistant_msg["tool_calls"] = [tc.model_dump() for tc in tool_calls]
            messages.append(assistant_msg)

            if not tool_calls:
                print("Final summary:\n")
                print(msg.content or "<empty final response>")
                return

            print(f"[round {round_idx}] tool calls:")
            seen_status_exec_ids: set[str] = set()
            for call in tool_calls:
                name = call.function.name
                tool = tool_map.get(name)
                if tool is None:
                    tool_output = json.dumps({"error": f"Unknown tool '{name}'"})
                else:
                    try:
                        args = json.loads(call.function.arguments or "{}")
                    except json.JSONDecodeError as exc:
                        args = {}
                        tool_output = json.dumps(
                            {"error": f"Invalid tool args JSON for '{name}': {exc}"}
                        )
                    else:
                        execution_id = str(args.get("executionId", "")).strip()
                        # ASI1 may request the same status poll multiple times
                        # in one assistant turn. Deduplicate those calls so we
                        # don't spam KeeperHub and stall the demo.
                        if (
                            name == "workflow_get_execution_status"
                            and execution_id
                            and execution_id in seen_status_exec_ids
                        ):
                            tool_output = status_cache.get(
                                execution_id,
                                json.dumps({"warning": "duplicate status poll skipped"}),
                            )
                        else:
                            tool_output = await _invoke_tool(tool, args)
                            if (
                                name == "workflow_get_execution_status"
                                and execution_id
                            ):
                                seen_status_exec_ids.add(execution_id)
                                status_cache[execution_id] = tool_output
                print(f"  -> {name}")
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.id,
                        "content": tool_output,
                    }
                )
                payload = _parse_json_object(tool_output)
                if payload:
                    execution_ctx["workflow_id"] = str(
                        payload.get("id") or execution_ctx["workflow_id"]
                    )
                    execution_ctx["execution_id"] = str(
                        payload.get("executionId") or execution_ctx["execution_id"]
                    )
                    execution_ctx["status"] = str(
                        payload.get("status") or execution_ctx["status"]
                    )
                    execution_ctx["tx_hash"] = str(
                        payload.get("transactionHash") or execution_ctx["tx_hash"]
                    )
                    execution_ctx["tx_link"] = str(
                        payload.get("transactionLink") or execution_ctx["tx_link"]
                    )
                    if payload.get("error"):
                        execution_ctx["error"] = str(payload["error"])

            # Since ASI1 requires tool_choice="required", it may never emit a
            # final assistant-only turn. Exit deterministically once terminal.
            if execution_ctx["status"].lower() in TERMINAL_STATUSES:
                print("\nFinal summary:\n")
                print(
                    json.dumps(
                        {
                            "workflow_id": execution_ctx["workflow_id"] or None,
                            "execution_id": execution_ctx["execution_id"] or None,
                            "status": execution_ctx["status"] or None,
                            "transaction_hash": execution_ctx["tx_hash"] or None,
                            "transaction_link": execution_ctx["tx_link"] or None,
                            "error": execution_ctx["error"] or None,
                        },
                        indent=2,
                    )
                )
                return

        print(f"Stopped after {MAX_ROUNDS} rounds without terminal assistant reply.")


if __name__ == "__main__":
    asyncio.run(main())
