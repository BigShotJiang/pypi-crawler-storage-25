"""Minimal Gemini example: LangChain ReAct agent with KeeperHub tools.

Prerequisites:
    pip install langchain-keeperhub langchain langchain-google-genai langgraph python-dotenv

Environment variables:
    KEEPERHUB_API_KEY  -- your org-scoped kh_ key
    GOOGLE_API_KEY     -- your Gemini API key
"""

import asyncio

from dotenv import load_dotenv

from langchain_keeperhub import KeeperHubToolkit

load_dotenv()


async def main() -> None:
    toolkit = KeeperHubToolkit(workflows=True)  # reads KEEPERHUB_API_KEY from env

    tools = await toolkit.aget_tools()
    print(tools)
    # llm = ChatGoogleGenerativeAI(model="gemini-3-flash-preview", temperature=0)
    # agent = create_agent(model=llm, tools=tools)

    # result = await agent.ainvoke(
    #     {"messages": [("user", "What blockchain networks does KeeperHub support?")]}
    # )
    # result = await agent.ainvoke({"messages": [("user", "Transfer 2 0x41E94Eb019C0762f9Bfcf9Fb1E58725BfB0e7582 token to 0x3E67cc2C7fFf86d9870dB9D02c43e789B52FB296 on Polygon Amoy (chain ID: 80002), my wallet address is 0x0c30281118fdfA0e51cd517A38BBFD191C1f9b8a")]})
    # print(result["messages"][-1].content)


if __name__ == "__main__":
    asyncio.run(main())
