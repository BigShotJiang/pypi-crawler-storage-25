from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import (
    TYPE_CHECKING, 
    Any, 
    Literal, 
    Mapping, 
    Optional, 
    TypedDict,
    Union,
    Required,
)

if TYPE_CHECKING:
    from ..resources.access_group import DriftstoneAccessGroup
    from ..resources.version import DriftstoneVersion
    from ..resources.channel import DriftstoneChannel
    from ..resources.session import DriftstoneSession
    from ..resources.profile import DriftstoneProfile
    from ..resources.instance import DriftstoneInstance

ApplicationType = Literal["claude", "openclaw"]

class AppInitLimit(TypedDict):
    name: Optional[str]
    amount: Required[int]
    interval: Required[Literal["daily", "weekly", "monthly"]]
    message: Optional[str]

class AppInitCredentialMCPOAuthNoneParam(TypedDict):
    type: Required[Literal["none"]]

class AppInitCredentialMCPOAuthBasicParam(TypedDict):
    type: Required[Literal["client_secret_basic"]]
    client_secret: Required[str]

class AppInitCredentialMCPOAuthPostParam(TypedDict):
    type: Required[Literal["client_secret_post"]]
    client_secret: Required[str]

class AppInitCredentialMCPOAuthRefresh(TypedDict):
    client_id: Required[str]
    refresh_token: Required[str]
    token_endpoint: Required[str]
    token_endpoint_auth: Required[Union[
        AppInitCredentialMCPOAuthNoneParam,
        AppInitCredentialMCPOAuthBasicParam,
        AppInitCredentialMCPOAuthPostParam,
    ]]
    resource: Optional[str]
    scope: Optional[str]

class AppInitCredentialMCPOAuth(TypedDict):
    access_token: Required[str]
    mcp_server_url: Required[str]
    type: Required[Literal["mcp_oauth"]]
    expires_at: Optional[datetime]
    refresh: Optional[AppInitCredentialMCPOAuthRefresh]

class AppInitCredentialMCPStaticBearer(TypedDict):
    token: Required[str]
    mcp_server_url: Required[str]
    type: Required[Literal["mcp_oauth"]]

AppInitCredential = Union[AppInitCredentialMCPOAuth, AppInitCredentialMCPStaticBearer]

@dataclass(frozen=True, slots=True)
class DriftstoneAppModel:
    id: str
    orgId: str
    type: ApplicationType
    name: str
    slug: str
    vaultId: str
    defaultAccessGroupId: str
    headVersionId: Optional[str]
    metadata: Optional[dict[str, str]]
    createdAt: datetime
    updatedAt: datetime

    version: DriftstoneVersion
    channel: DriftstoneChannel
    session: DriftstoneSession
    access_group: DriftstoneAccessGroup
    profile: DriftstoneProfile
    instance: DriftstoneInstance

    @classmethod
    def _from_api(
        cls,
        payload: Mapping[str, Any],
        version: DriftstoneVersion,
        channel: DriftstoneChannel,
        session: DriftstoneSession,
        access_group: DriftstoneAccessGroup,
        profile: DriftstoneProfile,
        instance: DriftstoneInstance,
    ) -> "DriftstoneAppModel":
        return cls(
            id=payload["id"],
            orgId=payload["orgId"],
            type=payload["type"],
            name=payload["name"],
            slug=payload["slug"],
            vaultId=payload["vaultId"],
            defaultAccessGroupId=payload["defaultAccessGroupId"],
            headVersionId=payload.get("headVersionId"),
            metadata=payload.get("metadata"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
            
            version=version,
            channel=channel,
            session=session,
            access_group=access_group,
            profile=profile,
            instance=instance,
        )
