
from __future__ import annotations

from typing import Optional

from .._internal.constants import AVAILABLE_APP_TYPES
from ..models.app import (
    ApplicationType,
    DriftstoneAppModel, 
    AppInitLimit, 
    AppInitCredential,
)
from ..exceptions import DriftstoneError
from ._base import ResourceBase
from .version import DriftstoneVersion
from .access_group import DriftstoneAccessGroup
from .channel import DriftstoneChannel
from .session import DriftstoneSession
from .profile import DriftstoneProfile
from .instance import DriftstoneInstance

class DriftstoneApp(ResourceBase):
    def init(
        self, 
        slug: str,
        *,
        type: ApplicationType,
        version_path: str,
        name: Optional[str] = None,
        limit: Optional[AppInitLimit] = None,
        credentials: Optional[list[AppInitCredential]] = None,
    ) -> DriftstoneAppModel:
        trimmed_slug = slug.strip()
        if not trimmed_slug:
            raise DriftstoneError("slug must be a non-empty string")
        
        if not all(c.isalnum() or c in "-_" for c in trimmed_slug):
            raise DriftstoneError("slug must be URL-safe (only contain letters, numbers, hyphens, and underscores)")

        if trimmed_slug[0] in "-_" or trimmed_slug[-1] in "-_":
            raise DriftstoneError("slug cannot start or end with a hyphen or underscore")
        
        if type not in AVAILABLE_APP_TYPES:
            raise DriftstoneError(f"type must be one of {AVAILABLE_APP_TYPES}")

        if not version_path or not isinstance(version_path, str):
            raise DriftstoneError("version_path must be a non-empty string")
        
        if name is not None and (not isinstance(name, str) or not name.strip()):
            raise DriftstoneError("name must be a non-empty string")
        
        if limit is not None and not isinstance(limit, AppInitLimit):
            raise DriftstoneError("limit must be an instance of AppInitLimit")
        
        if credentials is not None and (not isinstance(credentials, list) or not all(isinstance(cred, dict) for cred in credentials)):
            raise DriftstoneError("credentials must be a list of dictionaries")
        
        if type == "openclaw":
            raise NotImplementedError("Application type 'openclaw' is not yet supported. Please use 'claude' for now.")

        path_data = DriftstoneVersion._validate_version_path(version_path)

        additional_payload = {}
        if name is not None:
            additional_payload["name"] = name.strip()
        if limit is not None:
            additional_payload["limit"] = limit
        if credentials is not None:
            additional_payload["credentials"] = credentials

        app_create_res = self._client._request("POST", "/app/create", {
            "slug": trimmed_slug,
            "type": path_data["type"],
            **additional_payload,
            "returnIfExist": True,
        })

        app_id = app_create_res["data"]["id"]

        version = DriftstoneVersion(self._client, app_id)
        access_group = DriftstoneAccessGroup(self._client, app_id)
        channel = DriftstoneChannel(self._client, app_id)
        session = DriftstoneSession(self._client, app_id)
        profile = DriftstoneProfile(self._client, app_id)
        instance = DriftstoneInstance(self._client, app_id)

        if not app_create_res.get("exists", False) or not app_create_res["data"].get("headVersionId"):
            version.create(version_path)
        
        app_res = self._client._request("GET", f"/app/{app_id}")

        return DriftstoneAppModel._from_api(
            app_res["data"], 
            version=version,
            channel=channel,
            session=session,
            access_group=access_group,
            profile=profile,
            instance=instance,
        )
    
    def channel(self, app_id: str) -> DriftstoneChannel:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneChannel(self._client, trimmed_app_id)

    def instance(self, app_id: str) -> DriftstoneInstance:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneInstance(self._client, trimmed_app_id)

    def access_group(self, app_id: str) -> DriftstoneAccessGroup:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneAccessGroup(self._client, trimmed_app_id)

    def profile(self, app_id: str) -> DriftstoneProfile:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneProfile(self._client, trimmed_app_id)
