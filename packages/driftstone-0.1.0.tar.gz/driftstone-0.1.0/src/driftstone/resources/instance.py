from __future__ import annotations

from ..exceptions import DriftstoneError
from ..models.instance import DriftstoneInstanceModel
from ._base import AppBase

class DriftstoneInstance(AppBase):
    def retrieve(self, instance_id: str) -> DriftstoneInstanceModel:
        if not instance_id or not isinstance(instance_id, str):
            raise DriftstoneError("instance_id must be a non-empty string")

        instance_get_res = self._client._request("GET", f"/instance/{instance_id}")

        return DriftstoneInstanceModel._from_api(
            instance_get_res["data"],
        )

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[DriftstoneInstanceModel]:
        if not isinstance(page, int) or page < 1:
            raise DriftstoneError("page must be a positive integer")
        if not isinstance(page_size, int) or page_size < 1:
            raise DriftstoneError("page_size must be a positive integer")

        instance_list_res = self._client._request(
            "GET",
            "/instance/list",
            {
                "appId": self._app_id,
                "page": page,
                "pageSize": page_size,
            },
        )

        data = instance_list_res.get("data")
        if not isinstance(data, list):
            raise DriftstoneError("Expected 'data' to be a list in instance list response")

        return [DriftstoneInstanceModel._from_api(item) for item in data]
