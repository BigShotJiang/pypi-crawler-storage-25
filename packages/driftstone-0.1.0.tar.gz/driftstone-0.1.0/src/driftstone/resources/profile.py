from __future__ import annotations

from typing import Optional

from ..exceptions import DriftstoneError
from ..models.profile import DriftstoneProfileModel
from ._base import AppBase
from .state import DriftstoneState

class DriftstoneProfile(AppBase):
    def init(
        self, 
        identifier: str,
        *,
        state_path: str,
        access_group_id: Optional[str] = None,
    ) -> DriftstoneProfileModel:
        trimmed_identifier = identifier.strip()
        if not trimmed_identifier:
            raise DriftstoneError("identifier must be a non-empty string")

        if not state_path or not isinstance(state_path, str):
            raise DriftstoneError("state_path must be a non-empty string")
        
        if access_group_id is not None and (not isinstance(access_group_id, str) or not access_group_id.strip()):
            raise DriftstoneError("name must be a non-empty string")

        DriftstoneState._validate_state_path(state_path)

        additional_payload = {}
        if access_group_id is not None:
            additional_payload["accessGroupId"] = access_group_id.strip()

        profile_create_res = self._client._request("POST", "/profile/create", {
            "appId": self._app_id,
            "identifier": trimmed_identifier,
            **additional_payload,
            "returnIfExist": True,
        })

        profile_id = profile_create_res["data"]["id"]

        state = DriftstoneState(self._client, self._app_id, profile_id)

        if not profile_create_res.get("exists", False) or not profile_create_res["data"].get("headStateId"):
            state.create(state_path)
        
        profile_res = self._client._request("GET", f"/profile/{profile_id}")

        return DriftstoneProfileModel._from_api(
            profile_res["data"], 
            state=state,
        )
     
    def state(self, profile_id: str) -> DriftstoneState:
        trimmed_profile_id = profile_id.strip()
        if not profile_id:
            raise DriftstoneError("profile_id must be a non-empty string")
        return DriftstoneState(self._client, self._app_id, trimmed_profile_id)
