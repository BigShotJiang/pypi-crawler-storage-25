from __future__ import annotations

import tempfile
import zipfile
import hashlib
from pathlib import Path
from typing import TypedDict

import httpx

from .._internal.utils import safe_parse_json
from ..models.app import ApplicationType
from ..exceptions import (
    DriftstoneError, 
    DriftstoneResponseError, 
    DriftstoneAPIError
)
from ._base import AppBase


FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)

class VersionPathData(TypedDict):
    type: ApplicationType
    path: Path 

class DriftstoneVersion(AppBase):
    @staticmethod
    def _validate_version_path(version_path: str) -> VersionPathData:
        path = Path(version_path)
        if not path.is_absolute():
            path = Path.cwd() / path

        root = path.resolve()

        if not root.exists():
            raise DriftstoneError(f"Version path does not exist: {root}")
        if not root.is_dir():
            raise DriftstoneError(f"Version path must be a directory: {root}")
        
        if version_path.endswith(".claude"):
            # there must be agent.json file in the root directory
            agent_json_path = root / "agent.json"
            if not agent_json_path.exists() or not agent_json_path.is_file():
                raise DriftstoneError(f"Invalid Agent version path: missing agent.json in '{root}'")
            
            # there must be an environment.json file in the root directory
            environment_json_path = root / "environment.json"
            if not environment_json_path.exists() or not environment_json_path.is_file():
                raise DriftstoneError(f"Invalid Agent version path: missing environment.json in '{root}'")

            # agent.json must be a valid JSON file
            raw_agent_json = agent_json_path.read_text()
            agent_json = safe_parse_json(raw_agent_json)
            if not isinstance(agent_json, dict):
                raise ValueError("agent.json is not a valid JSON object")
            
            # if agent.json has skills field, it must be a list of objects with "type" field, and the type must be "anthropic"
            if "skills" in agent_json and isinstance(agent_json["skills"], list):
                for skill in agent_json["skills"]:
                    if not isinstance(skill, dict) or "type" not in skill:
                        raise ValueError("Each skill in agent.json must be an object with a 'name' field")

                    if skill["type"] != "anthropic":
                        raise ValueError("Only skills of type 'anthropic' are supported in agent.json, if you want custom skills you must add them as a folder under 'skills' directory")

            # there cant be other subdirectories except "skills"
            for item in root.iterdir():
                if item.is_dir() and item.name != "skills":
                    raise DriftstoneError(f"Invalid Agent version path: unexpected subdirectory '{item.name}' in '{root}'")
                if item.is_file() and item.name != "agent.json" and item.name != "environment.json":
                    raise DriftstoneError(f"Invalid Agent version path: unexpected file '{item.name}' in '{root}'")

            skills_dir = root / "skills"
            if skills_dir.exists() and skills_dir.is_dir():
                # each skill must be a directory containing SKILL.md file
                for skill_dir in skills_dir.iterdir():
                    if not skill_dir.is_dir():
                        raise DriftstoneError(f"Invalid Agent version path: skill '{skill_dir.name}' is not a directory in '{root}'")
                    skill_md_file = skill_dir / "SKILL.md"
                    if not skill_md_file.exists() or not skill_md_file.is_file():
                        raise DriftstoneError(f"Invalid Agent version path: missing SKILL.md in skill '{skill_dir.name}' in '{root}'")

        elif version_path.endswith(".openclaw"):
            # there must be openclaw.json file in the root directory
            openclaw_config_file = root / "openclaw.json"
            if not openclaw_config_file.exists() or not openclaw_config_file.is_file():
                raise DriftstoneError(f"Invalid OpenClaw version path: missing openclaw.json in '{root}'")
            
        else:
            raise DriftstoneError(f"Version path must end with .claude or .openclaw: {version_path}")

        return {
            "type": "claude" if version_path.endswith(".claude") else "openclaw",
            "path": root,
        }

    @staticmethod
    def _build_zip(root: Path) -> tuple[Path, str]:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp_file:
            zip_path = Path(tmp_file.name)

        with zipfile.ZipFile(zip_path, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
            files = sorted(
                (p for p in root.rglob("*") if p.is_file()),
                key=lambda p: p.relative_to(root).as_posix(),
            )
            for file_path in files:
                arcname = file_path.relative_to(root).as_posix()
                zip_info = zipfile.ZipInfo(arcname, date_time=FIXED_ZIP_TIME)
                zip_info.compress_type = zipfile.ZIP_DEFLATED
                zip_info.external_attr = 0o644 << 16
                archive.writestr(zip_info, file_path.read_bytes())

        sha256 = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        return zip_path, sha256

    def create(self, version_path: str):
        zip_path: Path | None = None
        try:
            path_data = self._validate_version_path(version_path)
            
            zip_path, sha256 = self._build_zip(path_data["path"])
            zip_bytes = zip_path.read_bytes()

            latest_res = self._client._request("GET", "/version/latest", {
                "appId": self._app_id,
            })

            latest_template_version = latest_res["data"]["version"] if latest_res.get("data") else 0

            upload_res = self._client._request("POST", "/utils/upload", {
                "appId": self._app_id,
                "paths": [{
                    "path": f"version/{latest_template_version + 1}.zip",
                    "contentType": "application/zip",
                }],
            })

            data = upload_res["data"]
            if not isinstance(data, list) or not data:
                raise DriftstoneResponseError("Missing POST URLs for template")
            
            upload_data = data[0]

            put_res = httpx.put(
                upload_data["url"],
                content=zip_bytes,
                headers={"Content-Type": "application/zip"},
                timeout=self._client.timeout,
            )
            if put_res.status_code >= 400:
                raise DriftstoneAPIError("Failed to sync template")

            storage_url = upload_data["url"].split("?")[0]
            self._client._request("POST", "/version/create", {
                "appId": self._app_id, 
                "storageUrl": storage_url,
                "sha256": sha256,
            })
        finally:
            if zip_path and zip_path.exists():
                zip_path.unlink()
