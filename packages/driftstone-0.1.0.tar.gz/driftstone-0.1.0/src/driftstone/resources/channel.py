from __future__ import annotations

import asyncio
import time
from typing import (
    AsyncIterator, 
    Iterator, 
    Literal, 
    Optional,
    Any, 
    cast, 
    overload
)

from ..models.channel import (
    DriftstoneChannelModel, 
    ChannelAPIWebhook,
    ChannelIMessageData,
    ChannelType,
)
from ..models.response import ResponseRunStreamEvent
from ..exceptions import DriftstoneError
from ._base import AppBase

class DriftstoneChannel(AppBase):
    @staticmethod
    def _validate_webhook(webhook: ChannelAPIWebhook) -> None:
        if not isinstance(webhook, dict):
            raise DriftstoneError("webhook must be a dictionary with 'name', 'url', and optional 'headers'")

        if "name" not in webhook or not isinstance(webhook["name"], str) or not webhook["name"].strip():
            raise DriftstoneError("webhook must have a non-empty string 'name' field")

        if "url" not in webhook or not isinstance(webhook["url"], str) or not webhook["url"].strip():
            raise DriftstoneError("webhook must have a non-empty string 'url' field")

        if "headers" in webhook and (
            not isinstance(webhook["headers"], dict)
            or not all(isinstance(k, str) and isinstance(v, str) for k, v in webhook["headers"].items())
        ):
            raise DriftstoneError("webhook 'headers' field must be a dictionary of string keys and values")

    @staticmethod
    def _validate_imessage_data(data: ChannelIMessageData) -> None:
        if not isinstance(data, dict):
            raise DriftstoneError("data must be a dictionary with iMessage credentials")

        required_imessage_fields = ["sendBlueAPIKey", "sendBlueSecretKey", "fromNumber"]
        for field in required_imessage_fields:
            if field not in data or not isinstance(data[field], str) or not data[field].strip():
                raise DriftstoneError(f"data must have a non-empty string '{field}' field")

    @overload
    def init(
        self, 
        slug: str, 
        *,
        type: Literal["api"], 
        name: Optional[str] = None,
        webhook: Optional[ChannelAPIWebhook] = None,
        data: None = None,
    ) -> DriftstoneChannelModel: ...

    @overload
    def init(
        self, 
        slug: str, 
        *,
        type: Literal["imessage"],
        name: Optional[str] = None,
        webhook: None = None,
        data: ChannelIMessageData = ...,
    ) -> DriftstoneChannelModel: ...

    def init(
        self, 
        slug: str,
        *,
        type: ChannelType,
        name: Optional[str] = None,
        webhook: Optional[ChannelAPIWebhook] = None,
        data: Optional[ChannelIMessageData] = None,
    ) -> DriftstoneChannelModel:
        trimmed_slug = slug.strip()
        if not trimmed_slug:
            raise DriftstoneError("slug must be a non-empty string")
        
        if not all(c.isalnum() or c in "-_" for c in trimmed_slug):
            raise DriftstoneError("slug must be URL-safe (only contain letters, numbers, hyphens, and underscores)")

        if trimmed_slug[0] in "-_" or trimmed_slug[-1] in "-_":
            raise DriftstoneError("slug cannot start or end with a hyphen or underscore")
        
        if type not in ("api", "imessage"):
            raise DriftstoneError("type must be either 'api' or 'imessage'")
        
        if name is not None and (not isinstance(name, str) or not name.strip()):
            raise DriftstoneError("name must be a non-empty string")
        
        additional_payload = {}

        if name is not None:
            additional_payload["name"] = name.strip()

        if type == "api":
            if data is not None:
                raise DriftstoneError("data field is not applicable for 'api' type channels")
            
            if webhook is not None:
                self._validate_webhook(webhook)
                additional_payload["webhook"] = webhook

        elif type == "imessage":
            if data is None:
                raise DriftstoneError("data must be provided for 'imessage' type channels")

            if webhook is not None:
                raise DriftstoneError("webhook field is not applicable for 'imessage' type channels")

            self._validate_imessage_data(data)
            additional_payload["data"] = data

        channel_create_res = self._client._request("POST", "/channel/create", {
            "appId": self._app_id,
            "type": type,
            "slug": trimmed_slug,
            **additional_payload,
            "returnIfExist": True,
        })

        return DriftstoneChannelModel._from_api(
            channel_create_res["data"],
            run=self.run,
            run_async=self.run_async,
        )

    def run(
        self, 
        channel_id: str,
        user_id: str,
        session_id: Optional[str] = None,
        input: str = "",
    ) -> Iterator[ResponseRunStreamEvent]:
        if not isinstance(input, str):
            raise DriftstoneError("input must be a string")
        
        channel = self._client._request("GET", f"/channel/{channel_id}")
        
        channel_type = channel["data"]["type"]
        if channel_type == "imessage":
            raise DriftstoneError("You must text the iMessage number directly to trigger the channel")
        
        response_run_res = self._client._request(
            "POST",
            "/response/run",
            {
                "appId": self._app_id,
                "channelId": channel_id,
                "sessionId": session_id,
                "userId": user_id,
                "input": input
            },
        )
        
        instance_id = response_run_res["data"]["instanceId"]

        # polling starts here
        next_index = 0
        backoff = 0.15
        while True:
            poll = self._client._request(
                "GET",
                f"/response/poll/{instance_id}",
                {
                    "after": next_index, 
                    "timeoutMs": 25000
                },
            )

            data = poll["data"]
            status = data.get("status", "running")
            events = data.get("events", [])

            for ev in events:
                idx = ev["index"]
                if idx < next_index:
                    continue

                next_index = idx + 1

                yield ResponseRunStreamEvent(
                    instance_id=instance_id,
                    index=idx,
                    data=ev["data"],
                    done=(status != "running"),
                    error=ev.get("error"),
                )

            if status != "running":
                return
            
            if events:
                backoff = 0.15
            else:
                time.sleep(backoff)
                backoff = min(backoff * 1.5, 1.5)

    async def run_async(
        self,
        channel_id: str,
        input: str = "",
    ) -> AsyncIterator[Any]:
        iterator = self.run(channel_id, input)
        sentinel = object()

        while True:
            event = await asyncio.to_thread(next, iterator, sentinel)
            if event is sentinel:
                return
            yield cast(Any, event)
