from __future__ import annotations

from typing import Optional

from ..exceptions import DriftstoneError
from ..models.access_group import (
    AccessGroupLimitReset,
    DriftstoneAccessGroupModel,
)
from ._base import AppBase


class DriftstoneAccessGroup(AppBase):
    def create(
        self,
        name: str,
        limit: int,
        *,
        limit_reset: AccessGroupLimitReset,
        limit_message: Optional[str] = None,
    ) -> DriftstoneAccessGroupModel:
        if not isinstance(name, str) or not name.strip():
            raise DriftstoneError("name must be a non-empty string")
        if not isinstance(limit, int) or limit <= 0:
            raise DriftstoneError("limit must be a positive integer")
        if limit_reset not in ("daily", "monthly", "yearly"):
            raise DriftstoneError("limit_reset must be one of 'daily', 'monthly', or 'yearly'")
        if limit_message is not None and not isinstance(limit_message, str):
            raise DriftstoneError("limit_message must be a string")

        payload: dict[str, object] = {
            "appId": self._app_id,
            "name": name.strip(),
            "limit": limit,
            "limitReset": limit_reset,
        }
        if limit_message is not None:
            payload["limitMessage"] = limit_message

        access_group_create_res = self._client._request("POST", "/access_group/create", payload)

        return DriftstoneAccessGroupModel._from_api(access_group_create_res["data"])

    def retrieve(self, access_group_id: str) -> DriftstoneAccessGroupModel:
        if not isinstance(access_group_id, str) or not access_group_id.strip():
            raise DriftstoneError("access_group_id must be a non-empty string")

        access_group_get_res = self._client._request("GET", f"/access_group/{access_group_id}")

        return DriftstoneAccessGroupModel._from_api(access_group_get_res["data"])

    def update(
        self,
        access_group_id: str,
        *,
        name: Optional[str] = None,
        limit: Optional[int] = None,
        limit_reset: Optional[AccessGroupLimitReset] = None,
        limit_message: Optional[str] = None,
    ) -> DriftstoneAccessGroupModel:
        if not isinstance(access_group_id, str) or not access_group_id.strip():
            raise DriftstoneError("access_group_id must be a non-empty string")
        if name is None and limit is None and limit_reset is None and limit_message is None:
            raise DriftstoneError("At least one field must be provided to update")

        payload: dict[str, object] = {}

        if name is not None:
            if not isinstance(name, str) or not name.strip():
                raise DriftstoneError("name must be a non-empty string")
            payload["name"] = name.strip()

        if limit is not None:
            if not isinstance(limit, int) or limit <= 0:
                raise DriftstoneError("limit must be a positive integer")
            payload["limit"] = limit

        if limit_reset is not None:
            if limit_reset not in ("daily", "monthly", "yearly"):
                raise DriftstoneError("limit_reset must be one of 'daily', 'monthly', or 'yearly'")
            payload["limitReset"] = limit_reset

        if limit_message is not None:
            if not isinstance(limit_message, str):
                raise DriftstoneError("limit_message must be a string")
            payload["limitMessage"] = limit_message

        access_group_update_res = self._client._request("PATCH", f"/access_group/{access_group_id}", payload)

        return DriftstoneAccessGroupModel._from_api(access_group_update_res["data"])

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[DriftstoneAccessGroupModel]:
        if not isinstance(page, int) or page < 1:
            raise DriftstoneError("page must be a positive integer")
        if not isinstance(page_size, int) or page_size < 1:
            raise DriftstoneError("page_size must be a positive integer")

        access_group_list_res = self._client._request(
            "GET",
            "/access_group/list",
            {
                "appId": self._app_id,
                "page": page,
                "pageSize": page_size,
            },
        )

        data = access_group_list_res.get("data")
        if not isinstance(data, list):
            raise DriftstoneError("Expected 'data' to be a list in access group list response")

        return [DriftstoneAccessGroupModel._from_api(item) for item in data]

    def delete(self, access_group_id: str) -> bool:
        if not isinstance(access_group_id, str) or not access_group_id.strip():
            raise DriftstoneError("access_group_id must be a non-empty string")

        self._client._request("DELETE", f"/access_group/{access_group_id}")

        return True
