from pathlib import Path
from driftstone import Driftstone

CURRENT_USER = "stephen@pickaxe.co"


client = Driftstone(api_key="dk-661f7eb4-ee24-4f73-96c4-2dc0d283a235")

config_folder = str(Path(__file__).resolve().parent / ".claude")

app = client.app.init("typedef-app", 
    type="claude",
    version_path=config_folder,
)

channel = app.channel.init("my-api", 
    type="api"
)

# profile = app.profile.init(
#     identifier=CURRENT_USER,
#     state_path=config_folder,
# )

stream = channel.run(
    session_id="my-custom-session-id",
    user_id="stephen@pickaxe.co", 
    input="Hello"
)

for event in stream:
    if event.done:
        break

    print(event)

# channel = app.channel.init("my-imessage", type="imessage", data={
#     "sendBlueAPIKey": "daf846bdbbd2d193ecc321162ab9ac4c",
#     "sendBlueSecretKey": "6f82d691172cb99fc3bb4ac2a639a242",
#     "fromNumber": "+17862139363",
# })
