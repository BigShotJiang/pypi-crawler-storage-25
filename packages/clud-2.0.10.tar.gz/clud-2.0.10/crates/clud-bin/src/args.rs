use clap::{Parser, Subcommand};
use std::path::PathBuf;

/// Fast CLI for running Claude Code and Codex in YOLO mode.
#[derive(Parser, Debug, Clone)]
#[command(
    name = "clud",
    version,
    about = "Fast CLI for running Claude Code and Codex in YOLO mode",
    after_help = "Unknown flags are forwarded directly to the backend agent."
)]
pub struct Args {
    #[arg(short = 'p', long = "prompt")]
    pub prompt: Option<String>,

    #[arg(short = 'm', long = "message")]
    pub message: Option<String>,

    #[arg(short = 'c', long = "continue")]
    pub continue_session: bool,

    #[arg(short = 'r', long = "resume")]
    pub resume: Option<Option<String>>,

    #[arg(long = "claude", conflicts_with = "codex")]
    pub claude: bool,

    #[arg(long = "codex", conflicts_with = "claude")]
    pub codex: bool,

    #[arg(long = "subprocess", conflicts_with = "pty")]
    pub subprocess: bool,

    #[arg(long = "pty", conflicts_with = "subprocess")]
    pub pty: bool,

    #[arg(long = "model")]
    pub model: Option<String>,

    #[arg(long = "safe")]
    pub safe: bool,

    #[arg(long = "dry-run")]
    pub dry_run: bool,

    #[arg(long = "detach", conflicts_with = "dry_run")]
    pub detach: bool,

    #[arg(long = "detachable", conflicts_with = "dry_run")]
    pub detachable: bool,

    #[arg(long = "name")]
    pub session_name: Option<String>,

    /// Override the in-memory attach-replay backlog cap. Accepts bytes
    /// (`262144`), or SI/binary suffixes (`256k`, `256KiB`, `1mb`). The
    /// compiled default is 256 KiB. Also honored as `CLUD_BACKLOG_BYTES`.
    #[arg(long = "backlog-size")]
    pub backlog_size: Option<String>,

    #[arg(short = 'v', long = "verbose")]
    pub verbose: bool,

    /// Disable the Windows console drag-and-drop target registration.
    /// Issue #79: by default `clud` registers an `IDropTarget` on the
    /// console window so dragged files are forwarded to the backend.
    /// Pass `--no-dnd` to opt out (no-op on POSIX, where drops already
    /// arrive as bracketed-paste stdin bytes).
    #[arg(long = "no-dnd", alias = "no-drag-drop")]
    pub no_dnd: bool,

    /// Issue #83: enumerate this repo's git worktrees and remove the
    /// stale ones. Combine with `--dry-run` to preview, `--yes` to skip
    /// confirmation, `--force` to also remove dirty/unpushed worktrees.
    #[arg(long = "clean-worktrees")]
    pub clean_worktrees: bool,

    /// Inspect Claude/Codex PreToolUse hook parity and apply explicit,
    /// repo-scoped repairs where clud can do so safely.
    #[arg(long = "fix-hooks")]
    pub fix_hooks: bool,

    /// Issue #83: minimum age before a clean worktree is treated as stale.
    /// Accepts `30s`, `5m`, `2h`, `1d`. Defaults to `1d`.
    #[arg(long = "stale-after", default_value = "1d")]
    pub stale_after: String,

    /// Issue #83: skip interactive confirmation prompts (combined with
    /// `--clean-worktrees`).
    #[arg(long = "yes", short = 'y')]
    pub yes: bool,

    /// Issue #83: allow `--clean-worktrees` to remove dirty / unpushed
    /// worktrees. Locked worktrees are still preserved.
    #[arg(long = "force")]
    pub force: bool,

    #[arg(long = "experimental-daemon-centralized", hide = true)]
    pub experimental_daemon_centralized: bool,

    #[arg(long = "daemon-state-dir", hide = true)]
    pub daemon_state_dir: Option<PathBuf>,

    /// Issue #135: reserved for forward compatibility. The merged
    /// always-on clud daemon (`__daemon`) hosts both session ops and the
    /// GC registry, so the prior `--daemon=gc` / `--daemon=session`
    /// distinction is no longer required. Kept as an accepted flag so
    /// older clud invocations don't error.
    #[arg(long = "daemon", value_name = "MODE", hide = true)]
    pub daemon_mode: Option<String>,

    /// Issue #135: opt out of the GC daemon auto-spawn for this invocation.
    /// `clud gc *` operations fail fast with this flag because they
    /// require the daemon. Other code paths skip the spawn silently.
    #[arg(long = "no-daemon")]
    pub no_daemon: bool,

    #[command(subcommand)]
    pub command: Option<Command>,

    #[arg(last = true, id = "BACKEND_ARGS")]
    pub passthrough: Vec<String>,
}

#[derive(Subcommand, Debug, Clone)]
pub enum Command {
    Loop {
        /// Prompt text, path to a local file, or a GH issue/PR URL.
        task: Option<String>,
        #[arg(long = "loop-count", default_value = "50")]
        loop_count: u32,
        /// Force re-fetch of a cached GH issue/PR body.
        #[arg(long = "refresh")]
        refresh: bool,
        /// Do not inject the DONE/BLOCKED marker contract into the prompt.
        #[arg(long = "no-done", alias = "no-done-marker", conflicts_with = "done")]
        no_done: bool,
        /// Re-enable the DONE/BLOCKED contract using a custom DONE marker path.
        #[arg(long = "done", conflicts_with = "no_done")]
        done: Option<String>,
        /// Re-run the loop after it completes, sleeping for the given duration
        /// between runs (for example `30s`, `5m`, `1h`).
        #[arg(long = "repeat")]
        repeat: Option<String>,
    },
    Up {
        #[arg(short = 'm', long = "message")]
        message: Option<String>,
        #[arg(long = "publish")]
        publish: bool,
    },
    Rebase,
    Fix {
        url: Option<String>,
    },
    Wasm {
        module: String,
        #[arg(long = "invoke", default_value = "run")]
        invoke: String,
    },
    Attach {
        session_id: Option<String>,
        #[arg(long = "last", short = 'l')]
        last: bool,
    },
    Kill {
        session_id: Option<String>,
        #[arg(long = "all")]
        all: bool,
    },
    List,
    /// pm2-style log viewer: dump or tail a session's captured output.
    ///
    /// With no session id, lists all sessions that have log files and prints
    /// the last line of each. With an id, prints the log (last `--lines` or
    /// all) and optionally keeps following new output via `--follow`.
    /// `--last` resolves to the most-recently-created session (live or
    /// exited), mirroring `clud attach --last`. Read-only: never takes
    /// exclusive ownership of the session and never evicts attached clients.
    Logs {
        session_id: Option<String>,
        /// Keep watching the file and print new output as it arrives. Exits
        /// once the session has terminated (after printing a status line).
        #[arg(long = "follow", short = 'f')]
        follow: bool,
        /// Print only the last N lines from the file. Default: all.
        #[arg(long = "lines", short = 'n')]
        lines: Option<usize>,
        /// Operate on the most recently created session (live or exited).
        #[arg(long = "last", short = 'l', conflicts_with = "session_id")]
        last: bool,
    },
    /// Issue #110: tracked-entry garbage collection (redb-backed
    /// registry at `~/.clud/data.redb`).
    ///
    /// Subcommands: `list`, `purge <duration>`, `reconcile`. Running
    /// `clud gc` with no subcommand prints this help summary.
    Gc {
        #[command(subcommand)]
        subcommand: Option<GcSubcommand>,
    },
    #[command(name = "__daemon", hide = true)]
    InternalDaemon {
        #[arg(long = "state-dir")]
        state_dir: PathBuf,
    },
    #[command(name = "__worker", hide = true)]
    InternalWorker {
        #[arg(long = "state-dir")]
        state_dir: PathBuf,
        #[arg(long = "session-id")]
        session_id: String,
        #[arg(long = "daemon-pid")]
        daemon_pid: u32,
        #[arg(long = "spec-file")]
        spec_file: PathBuf,
    },
}

/// Subcommands under `clud gc`. See `crates/clud-bin/src/gc.rs`.
#[derive(Subcommand, Debug, Clone)]
pub enum GcSubcommand {
    /// Print every tracked entry, newest first.
    List {
        /// Issue #135: emit a JSON array instead of the human-readable table.
        #[arg(long = "json")]
        json: bool,
    },
    /// Remove tracked entries older than `<duration>`. When `<duration>`
    /// is omitted, purge ALL tracked entries that are not live-locked.
    Purge {
        /// Duration (e.g. `30s`, `5m`, `2h`, `1d`). When omitted, purge
        /// every non-live-locked entry regardless of age.
        duration: Option<String>,
        /// Preview the removal plan without touching anything.
        #[arg(long = "dry-run")]
        dry_run: bool,
        /// Skip the interactive confirmation prompt.
        #[arg(long = "yes", short = 'y')]
        yes: bool,
        /// Restrict to a single entry kind (e.g. `worktree`).
        #[arg(long = "kind")]
        kind: Option<String>,
    },
    /// Walk `.claude/worktrees/` in the current repo and insert any
    /// previously-untracked worktree directories.
    Reconcile,
}

impl Args {
    pub fn parse_with_passthrough() -> Self {
        let raw: Vec<String> = std::env::args().collect();
        Self::parse_from_raw(raw)
    }

    pub fn parse_from_raw(raw: Vec<String>) -> Self {
        let (known, unknown) = split_known_unknown(&raw);
        let mut args = Args::parse_from(known);
        args.passthrough.extend(unknown);
        args
    }
}

fn split_known_unknown(raw: &[String]) -> (Vec<String>, Vec<String>) {
    let mut known = vec![raw[0].clone()];
    let mut unknown = Vec::new();
    let mut i = 1;

    let value_flags: &[&str] = &[
        "--prompt",
        "--message",
        "--resume",
        "--model",
        "--name",
        "--backlog-size",
        "--loop-count",
        "--done",
        "--repeat",
        "--daemon-state-dir",
        "--stale-after",
        "--daemon",
        "--state-dir",
    ];
    let short_value_flags: &[&str] = &["-p", "-m", "-r"];
    let bool_flags: &[&str] = &[
        "--continue",
        "--claude",
        "--codex",
        "--subprocess",
        "--pty",
        "--safe",
        "--dry-run",
        "--detach",
        "--detachable",
        "--verbose",
        "--experimental-daemon-centralized",
        "--all",
        "--last",
        "--refresh",
        "--no-done",
        "--no-done-marker",
        "--no-dnd",
        "--no-drag-drop",
        "--clean-worktrees",
        "--fix-hooks",
        "--yes",
        "--force",
        "--no-daemon",
        "--json",
        "--help",
        "--version",
    ];
    let short_bool_flags: &[&str] = &["-c", "-v", "-h", "-V", "-y"];
    let subcommands: &[&str] = &[
        "loop", "up", "rebase", "fix", "wasm", "attach", "kill", "list", "logs", "gc", "__daemon",
        "__worker",
    ];

    let mut in_subcommand = false;

    while i < raw.len() {
        let arg = &raw[i];

        if arg == "--" {
            unknown.extend_from_slice(&raw[i + 1..]);
            break;
        }

        if in_subcommand {
            known.push(arg.clone());
            i += 1;
            continue;
        }

        if subcommands.contains(&arg.as_str()) {
            known.push(arg.clone());
            in_subcommand = true;
            i += 1;
            continue;
        }

        if bool_flags.contains(&arg.as_str()) || short_bool_flags.contains(&arg.as_str()) {
            known.push(arg.clone());
            i += 1;
            continue;
        }

        if arg.starts_with("--") {
            if let Some((prefix, _)) = arg.split_once('=') {
                if value_flags.contains(&prefix) {
                    known.push(arg.clone());
                    i += 1;
                    continue;
                }
            }
        }

        if value_flags.contains(&arg.as_str()) || short_value_flags.contains(&arg.as_str()) {
            known.push(arg.clone());
            i += 1;
            if i < raw.len() {
                known.push(raw[i].clone());
            }
            i += 1;
            continue;
        }

        unknown.push(arg.clone());
        i += 1;
    }

    (known, unknown)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse(args: &[&str]) -> Args {
        let raw: Vec<String> = args.iter().map(|s| s.to_string()).collect();
        Args::parse_from_raw(raw)
    }

    #[test]
    fn test_prompt_flag() {
        let args = parse(&["clud", "-p", "hello world"]);
        assert_eq!(args.prompt.as_deref(), Some("hello world"));
        assert!(!args.safe);
    }

    #[test]
    fn test_message_flag() {
        let args = parse(&["clud", "-m", "fix the bug"]);
        assert_eq!(args.message.as_deref(), Some("fix the bug"));
    }

    #[test]
    fn test_continue_flag() {
        let args = parse(&["clud", "-c"]);
        assert!(args.continue_session);
    }

    #[test]
    fn test_claude_backend() {
        let args = parse(&["clud", "--claude"]);
        assert!(args.claude);
        assert!(!args.codex);
    }

    #[test]
    fn test_codex_backend() {
        let args = parse(&["clud", "--codex"]);
        assert!(args.codex);
        assert!(!args.claude);
    }

    #[test]
    fn test_model_flag() {
        let args = parse(&["clud", "--model", "opus"]);
        assert_eq!(args.model.as_deref(), Some("opus"));
    }

    #[test]
    fn test_subprocess_flag() {
        let args = parse(&["clud", "--subprocess"]);
        assert!(args.subprocess);
        assert!(!args.pty);
    }

    #[test]
    fn test_pty_flag() {
        let args = parse(&["clud", "--pty"]);
        assert!(args.pty);
        assert!(!args.subprocess);
    }

    #[test]
    fn test_safe_flag() {
        let args = parse(&["clud", "--safe", "-p", "hello"]);
        assert!(args.safe);
        assert_eq!(args.prompt.as_deref(), Some("hello"));
    }

    #[test]
    fn test_dry_run() {
        let args = parse(&["clud", "--dry-run", "-p", "hello"]);
        assert!(args.dry_run);
    }

    #[test]
    fn test_detach_flag() {
        let args = parse(&["clud", "--detach", "-p", "hello"]);
        assert!(args.detach);
        assert!(!args.detachable);
    }

    #[test]
    fn test_detachable_flag() {
        let args = parse(&["clud", "--detachable", "-p", "hello"]);
        assert!(args.detachable);
        assert!(!args.detach);
    }

    #[test]
    fn test_loop_subcommand() {
        let args = parse(&["clud", "loop", "do the task"]);
        match args.command {
            Some(Command::Loop {
                ref task,
                loop_count,
                refresh,
                no_done,
                ref done,
                ref repeat,
            }) => {
                assert_eq!(task.as_deref(), Some("do the task"));
                assert_eq!(loop_count, 50);
                assert!(!refresh);
                assert!(!no_done);
                assert!(done.is_none());
                assert!(repeat.is_none());
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    #[test]
    fn test_loop_with_count() {
        let args = parse(&["clud", "loop", "--loop-count", "5", "task"]);
        match args.command {
            Some(Command::Loop {
                ref task,
                loop_count,
                ..
            }) => {
                assert_eq!(task.as_deref(), Some("task"));
                assert_eq!(loop_count, 5);
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    #[test]
    fn test_loop_refresh_flag() {
        let args = parse(&[
            "clud",
            "loop",
            "--refresh",
            "https://github.com/o/r/issues/42",
        ]);
        match args.command {
            Some(Command::Loop {
                ref task,
                refresh,
                no_done,
                ref done,
                ref repeat,
                ..
            }) => {
                assert_eq!(task.as_deref(), Some("https://github.com/o/r/issues/42"));
                assert!(refresh);
                assert!(!no_done);
                assert!(done.is_none());
                assert!(repeat.is_none());
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    #[test]
    fn test_loop_no_done_flag() {
        let args = parse(&["clud", "loop", "--no-done", "task"]);
        match args.command {
            Some(Command::Loop { no_done, .. }) => {
                assert!(no_done);
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    #[test]
    fn test_loop_no_done_marker_compat_alias() {
        let args = parse(&["clud", "loop", "--no-done-marker", "task"]);
        match args.command {
            Some(Command::Loop { no_done, .. }) => {
                assert!(no_done);
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    #[test]
    fn test_loop_done_path() {
        let args = parse(&["clud", "loop", "--done", "DONE.md", "task"]);
        match args.command {
            Some(Command::Loop {
                ref done, no_done, ..
            }) => {
                assert_eq!(done.as_deref(), Some("DONE.md"));
                assert!(!no_done);
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    #[test]
    fn test_loop_repeat() {
        let args = parse(&["clud", "loop", "--repeat", "1h", "task"]);
        match args.command {
            Some(Command::Loop { ref repeat, .. }) => {
                assert_eq!(repeat.as_deref(), Some("1h"));
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    /// Issue #61: --repeat + --done <path> must parse cleanly. The two flags
    /// compose; --done overrides --repeat's implicit --no-done at the
    /// command-builder layer, but at the args layer they're orthogonal.
    #[test]
    fn test_loop_repeat_with_done() {
        let args = parse(&[
            "clud",
            "loop",
            "--repeat",
            "30m",
            "--done",
            "STATUS.md",
            "task",
        ]);
        match args.command {
            Some(Command::Loop {
                ref repeat,
                ref done,
                no_done,
                ..
            }) => {
                assert_eq!(repeat.as_deref(), Some("30m"));
                assert_eq!(done.as_deref(), Some("STATUS.md"));
                assert!(!no_done);
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    /// Issue #61: --repeat + --no-done must parse cleanly even though the
    /// command-builder treats them as overlapping (both suppress the
    /// contract). Clap should not reject the combination.
    #[test]
    fn test_loop_repeat_with_no_done() {
        let args = parse(&["clud", "loop", "--repeat", "5m", "--no-done", "task"]);
        match args.command {
            Some(Command::Loop {
                ref repeat,
                no_done,
                ref done,
                ..
            }) => {
                assert_eq!(repeat.as_deref(), Some("5m"));
                assert!(no_done);
                assert!(done.is_none());
            }
            _ => panic!("expected Loop subcommand"),
        }
    }

    /// Issue #61: --done and --no-done are mutually exclusive (clap
    /// `conflicts_with`). Supplying both must fail — we don't pin the exact
    /// error message because clap formatting drifts between versions, but
    /// `try_parse_from` must return `Err`.
    #[test]
    fn test_loop_done_and_no_done_conflict() {
        let argv: Vec<String> = ["clud", "loop", "--done", "DONE.md", "--no-done", "task"]
            .iter()
            .map(|s| s.to_string())
            .collect();
        let result = Args::try_parse_from(argv);
        assert!(
            result.is_err(),
            "clap should reject simultaneous --done and --no-done"
        );
    }

    #[test]
    fn test_up_subcommand() {
        let args = parse(&["clud", "up"]);
        assert!(matches!(args.command, Some(Command::Up { .. })));
    }

    #[test]
    fn test_up_with_message() {
        let args = parse(&["clud", "up", "-m", "bump version"]);
        match args.command {
            Some(Command::Up {
                ref message,
                publish,
            }) => {
                assert_eq!(message.as_deref(), Some("bump version"));
                assert!(!publish);
            }
            _ => panic!("expected Up subcommand"),
        }
    }

    #[test]
    fn test_up_with_publish() {
        let args = parse(&["clud", "up", "--publish"]);
        match args.command {
            Some(Command::Up {
                ref message,
                publish,
            }) => {
                assert!(message.is_none());
                assert!(publish);
            }
            _ => panic!("expected Up subcommand"),
        }
    }

    #[test]
    fn test_up_with_message_and_publish() {
        let args = parse(&["clud", "up", "-m", "release", "--publish"]);
        match args.command {
            Some(Command::Up {
                ref message,
                publish,
            }) => {
                assert_eq!(message.as_deref(), Some("release"));
                assert!(publish);
            }
            _ => panic!("expected Up subcommand"),
        }
    }

    #[test]
    fn test_rebase_subcommand() {
        let args = parse(&["clud", "rebase"]);
        assert!(matches!(args.command, Some(Command::Rebase)));
    }

    #[test]
    fn test_fix_subcommand() {
        let args = parse(&["clud", "fix"]);
        assert!(matches!(args.command, Some(Command::Fix { .. })));
    }

    #[test]
    fn test_fix_with_url() {
        let args = parse(&[
            "clud",
            "fix",
            "https://github.com/user/repo/actions/runs/123",
        ]);
        match args.command {
            Some(Command::Fix { ref url }) => {
                assert_eq!(
                    url.as_deref(),
                    Some("https://github.com/user/repo/actions/runs/123")
                );
            }
            _ => panic!("expected Fix subcommand"),
        }
    }

    #[test]
    fn test_wasm_subcommand() {
        let args = parse(&["clud", "wasm", "guest.wasm"]);
        match args.command {
            Some(Command::Wasm {
                ref module,
                ref invoke,
            }) => {
                assert_eq!(module, "guest.wasm");
                assert_eq!(invoke, "run");
            }
            _ => panic!("expected Wasm subcommand"),
        }
    }

    #[test]
    fn test_wasm_subcommand_custom_entrypoint() {
        let args = parse(&["clud", "wasm", "guest.wasm", "--invoke", "_start"]);
        match args.command {
            Some(Command::Wasm {
                ref module,
                ref invoke,
            }) => {
                assert_eq!(module, "guest.wasm");
                assert_eq!(invoke, "_start");
            }
            _ => panic!("expected Wasm subcommand"),
        }
    }

    #[test]
    fn test_attach_without_session_id() {
        let args = parse(&["clud", "attach"]);
        match args.command {
            Some(Command::Attach { session_id, last }) => {
                assert!(session_id.is_none());
                assert!(!last);
            }
            _ => panic!("expected Attach subcommand"),
        }
    }

    #[test]
    fn test_attach_with_session_id() {
        let args = parse(&["clud", "attach", "sess-123"]);
        match args.command {
            Some(Command::Attach { session_id, last }) => {
                assert_eq!(session_id.as_deref(), Some("sess-123"));
                assert!(!last);
            }
            _ => panic!("expected Attach subcommand"),
        }
    }

    #[test]
    fn test_attach_with_last() {
        let args = parse(&["clud", "attach", "--last"]);
        match args.command {
            Some(Command::Attach { session_id, last }) => {
                assert!(session_id.is_none());
                assert!(last);
            }
            _ => panic!("expected Attach subcommand"),
        }
    }

    #[test]
    fn test_kill_subcommand() {
        let args = parse(&["clud", "kill", "sess-123"]);
        match args.command {
            Some(Command::Kill { session_id, all }) => {
                assert_eq!(session_id.as_deref(), Some("sess-123"));
                assert!(!all);
            }
            _ => panic!("expected Kill subcommand"),
        }
    }

    #[test]
    fn test_kill_all() {
        let args = parse(&["clud", "kill", "--all"]);
        match args.command {
            Some(Command::Kill { session_id, all }) => {
                assert!(session_id.is_none());
                assert!(all);
            }
            _ => panic!("expected Kill subcommand"),
        }
    }

    #[test]
    fn test_name_flag() {
        let args = parse(&["clud", "--name", "my-session", "--detach", "-p", "hello"]);
        assert_eq!(args.session_name.as_deref(), Some("my-session"));
        assert!(args.detach);
    }

    #[test]
    fn test_list_subcommand() {
        let args = parse(&["clud", "list"]);
        assert!(matches!(args.command, Some(Command::List)));
    }

    #[test]
    fn test_logs_with_session_id() {
        let args = parse(&["clud", "logs", "sess-abc"]);
        match args.command {
            Some(Command::Logs {
                session_id,
                follow,
                lines,
                last,
            }) => {
                assert_eq!(session_id.as_deref(), Some("sess-abc"));
                assert!(!follow);
                assert!(lines.is_none());
                assert!(!last);
            }
            _ => panic!("expected Logs subcommand"),
        }
    }

    #[test]
    fn test_logs_follow_flag() {
        let args = parse(&["clud", "logs", "-f", "sess-abc"]);
        match args.command {
            Some(Command::Logs {
                session_id,
                follow,
                last,
                ..
            }) => {
                assert_eq!(session_id.as_deref(), Some("sess-abc"));
                assert!(follow);
                assert!(!last);
            }
            _ => panic!("expected Logs subcommand"),
        }
    }

    #[test]
    fn test_logs_lines_flag() {
        let args = parse(&["clud", "logs", "-n", "100", "sess-abc"]);
        match args.command {
            Some(Command::Logs {
                session_id,
                lines,
                last,
                ..
            }) => {
                assert_eq!(session_id.as_deref(), Some("sess-abc"));
                assert_eq!(lines, Some(100));
                assert!(!last);
            }
            _ => panic!("expected Logs subcommand"),
        }
    }

    #[test]
    fn test_logs_last_flag() {
        let args = parse(&["clud", "logs", "--last"]);
        match args.command {
            Some(Command::Logs {
                session_id,
                follow,
                last,
                ..
            }) => {
                assert!(session_id.is_none());
                assert!(!follow);
                assert!(last);
            }
            _ => panic!("expected Logs subcommand"),
        }
    }

    #[test]
    fn test_logs_last_short_flag() {
        let args = parse(&["clud", "logs", "-l"]);
        match args.command {
            Some(Command::Logs { last, .. }) => {
                assert!(last);
            }
            _ => panic!("expected Logs subcommand"),
        }
    }

    /// `--last` conflicts with positional session id (mirrors `clud attach`).
    #[test]
    fn test_logs_last_with_session_id_conflicts() {
        let argv: Vec<String> = ["clud", "logs", "--last", "sess-abc"]
            .iter()
            .map(|s| s.to_string())
            .collect();
        let result = Args::try_parse_from(argv);
        assert!(
            result.is_err(),
            "clap should reject --last combined with a session id"
        );
    }

    #[test]
    fn test_unknown_flags_passthrough() {
        let args = parse(&["clud", "--some-unknown-flag", "-p", "hello"]);
        assert_eq!(args.prompt.as_deref(), Some("hello"));
        assert_eq!(args.passthrough, vec!["--some-unknown-flag"]);
    }

    #[test]
    fn test_passthrough_after_separator() {
        let args = parse(&["clud", "-p", "hello", "--", "--verbose", "--debug"]);
        assert_eq!(args.prompt.as_deref(), Some("hello"));
        assert_eq!(args.passthrough, vec!["--verbose", "--debug"]);
    }

    #[test]
    fn test_verbose_flag() {
        let args = parse(&["clud", "-v"]);
        assert!(args.verbose);
    }

    #[test]
    fn test_default_no_flags() {
        let args = parse(&["clud"]);
        assert!(args.prompt.is_none());
        assert!(args.message.is_none());
        assert!(!args.continue_session);
        assert!(!args.claude);
        assert!(!args.codex);
        assert!(!args.subprocess);
        assert!(!args.pty);
        assert!(!args.safe);
        assert!(!args.dry_run);
        assert!(!args.detach);
        assert!(!args.detachable);
        assert!(!args.no_dnd);
        assert!(!args.clean_worktrees);
        assert!(!args.fix_hooks);
        assert!(!args.yes);
        assert!(!args.force);
        assert_eq!(args.stale_after, "1d");
        assert!(args.command.is_none());
        assert!(args.passthrough.is_empty());
    }

    #[test]
    fn test_no_dnd_flag() {
        let args = parse(&["clud", "--no-dnd"]);
        assert!(args.no_dnd);
    }

    #[test]
    fn test_no_drag_drop_alias() {
        let args = parse(&["clud", "--no-drag-drop"]);
        assert!(args.no_dnd);
    }

    #[test]
    fn test_no_dnd_default_false() {
        let args = parse(&["clud", "-p", "hello"]);
        assert!(!args.no_dnd);
    }

    /// Issue #83: top-level `--clean-worktrees` toggles the worktree-cleanup
    /// path and accepts the surrounding flags (`--stale-after`, `--yes`,
    /// `--force`, the existing `--dry-run`).
    #[test]
    fn test_clean_worktrees_flag() {
        let args = parse(&["clud", "--clean-worktrees"]);
        assert!(args.clean_worktrees);
        assert_eq!(args.stale_after, "1d");
        assert!(!args.yes);
        assert!(!args.force);
    }

    #[test]
    fn test_clean_worktrees_with_stale_after() {
        let args = parse(&["clud", "--clean-worktrees", "--stale-after", "7d"]);
        assert!(args.clean_worktrees);
        assert_eq!(args.stale_after, "7d");
    }

    #[test]
    fn test_clean_worktrees_with_yes_and_force() {
        let args = parse(&["clud", "--clean-worktrees", "--yes", "--force"]);
        assert!(args.clean_worktrees);
        assert!(args.yes);
        assert!(args.force);
    }

    #[test]
    fn test_clean_worktrees_with_dry_run() {
        let args = parse(&["clud", "--clean-worktrees", "--dry-run"]);
        assert!(args.clean_worktrees);
        assert!(args.dry_run);
    }

    #[test]
    fn test_fix_hooks_flag() {
        let args = parse(&["clud", "--fix-hooks"]);
        assert!(args.fix_hooks);
        assert!(!args.dry_run);
    }

    #[test]
    fn test_fix_hooks_dry_run_with_backend_selection() {
        let args = parse(&["clud", "--fix-hooks", "--dry-run", "--codex"]);
        assert!(args.fix_hooks);
        assert!(args.dry_run);
        assert!(args.codex);
        assert!(!args.claude);
    }

    #[test]
    fn test_yes_short_flag() {
        let args = parse(&["clud", "--clean-worktrees", "-y"]);
        assert!(args.yes);
    }

    // ---------- issue #110: `clud gc` subcommand group ----------

    /// `clud gc` with no subcommand must parse successfully and yield
    /// `Some(Command::Gc { subcommand: None })` so the runtime can print
    /// help and exit 0.
    #[test]
    fn test_gc_bare_subcommand_yields_none() {
        let args = parse(&["clud", "gc"]);
        match args.command {
            Some(Command::Gc { ref subcommand }) => assert!(subcommand.is_none()),
            _ => panic!("expected Gc subcommand"),
        }
    }

    #[test]
    fn test_gc_list() {
        let args = parse(&["clud", "gc", "list"]);
        match args.command {
            Some(Command::Gc {
                subcommand: Some(GcSubcommand::List { json }),
            }) => assert!(!json),
            _ => panic!("expected Gc::List"),
        }
    }

    #[test]
    fn test_gc_list_json() {
        // Issue #135: `clud gc list --json` emits JSON for downstream tooling.
        let args = parse(&["clud", "gc", "list", "--json"]);
        match args.command {
            Some(Command::Gc {
                subcommand: Some(GcSubcommand::List { json }),
            }) => assert!(json),
            _ => panic!("expected Gc::List --json"),
        }
    }

    #[test]
    fn test_gc_purge_with_duration() {
        let args = parse(&["clud", "gc", "purge", "1d"]);
        match args.command {
            Some(Command::Gc {
                subcommand:
                    Some(GcSubcommand::Purge {
                        ref duration,
                        dry_run,
                        yes,
                        ref kind,
                    }),
            }) => {
                assert_eq!(duration.as_deref(), Some("1d"));
                assert!(!dry_run);
                assert!(!yes);
                assert!(kind.is_none());
            }
            _ => panic!("expected Gc::Purge"),
        }
    }

    #[test]
    fn test_gc_purge_without_duration_means_purge_all() {
        // Issue #135 Phase 1: bare `clud gc purge` -> purge ALL non-live-locked.
        let args = parse(&["clud", "gc", "purge"]);
        match args.command {
            Some(Command::Gc {
                subcommand: Some(GcSubcommand::Purge { ref duration, .. }),
            }) => {
                assert!(duration.is_none(), "purge with no arg -> None duration");
            }
            _ => panic!("expected bare Gc::Purge"),
        }
    }

    #[test]
    fn test_gc_purge_dry_run_yes_kind() {
        let args = parse(&[
            "clud",
            "gc",
            "purge",
            "7d",
            "--dry-run",
            "--yes",
            "--kind",
            "worktree",
        ]);
        match args.command {
            Some(Command::Gc {
                subcommand:
                    Some(GcSubcommand::Purge {
                        ref duration,
                        dry_run,
                        yes,
                        ref kind,
                    }),
            }) => {
                assert_eq!(duration.as_deref(), Some("7d"));
                assert!(dry_run);
                assert!(yes);
                assert_eq!(kind.as_deref(), Some("worktree"));
            }
            _ => panic!("expected Gc::Purge with flags"),
        }
    }

    #[test]
    fn test_no_daemon_flag() {
        // Issue #135: `--no-daemon` disables auto-spawn.
        let args = parse(&["clud", "--no-daemon", "-p", "hi"]);
        assert!(args.no_daemon);
    }

    #[test]
    fn test_gc_reconcile() {
        let args = parse(&["clud", "gc", "reconcile"]);
        match args.command {
            Some(Command::Gc {
                subcommand: Some(GcSubcommand::Reconcile),
            }) => {}
            _ => panic!("expected Gc::Reconcile"),
        }
    }
}
