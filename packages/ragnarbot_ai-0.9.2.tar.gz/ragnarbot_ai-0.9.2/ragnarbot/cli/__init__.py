"""CLI module for ragnarbot."""
