# SPDX-FileCopyrightText: © 2026 Shaun Wilson
# SPDX-License-Identifier: MIT

from .Container import Container, Factory, RegistrationError, Target


__version__ = '0.0.5'
__commit__ = '5ed3ad9'
__all__ = [
    '__version__', '__commit__',
    'Container',
    'Factory',
    'RegistrationError',
    'Target'
]
