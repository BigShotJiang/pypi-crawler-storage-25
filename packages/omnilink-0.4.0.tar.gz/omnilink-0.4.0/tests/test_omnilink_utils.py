import json
from pathlib import Path
import sys
from typing import Any, Dict, List, Optional, Tuple

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from omnilink import (
    AgentFeedback,
    AgentQuestion,
    PendingQuestion,
    OmniLinkEngine,
    OmniLinkHTTPBridge,
    TypeRegistry,
    load_patterns_from_file,
)


def test_type_registry_default_conversion():
    registry = TypeRegistry()
    regex, converter = registry.get("int")
    assert regex == r"-?\d+"
    assert converter("42") == 42


def test_type_registry_override_and_duplicate():
    registry = TypeRegistry()
    registry.register("custom", r"[A-Z]+", lambda s: s.lower())
    registry.register("CUSTOM", r"[A-Z]+", lambda s: s[::-1])  # override case-insensitive
    _, converter = registry.get("custom")
    assert converter("ABC") == "CBA"


def test_load_patterns_from_file_handles_comments_quotes_and_bom(tmp_path: Path):
    content = """\ufeff# Comment line\n"greet_world"\n'say [text:any]'\n\ncommand_plain\n"""
    pattern_file = tmp_path / "patterns.txt"
    pattern_file.write_text(content, encoding="utf-8")

    patterns = load_patterns_from_file(pattern_file)
    assert patterns == [
        "greet_world",
        "say [text:any]",
        "command_plain",
    ]


def test_load_patterns_from_relative_path(tmp_path: Path, monkeypatch):
    pattern_file = tmp_path / "nested" / "patterns.txt"
    pattern_file.parent.mkdir(parents=True)
    pattern_file.write_text("command_one\n", encoding="utf-8")

    def fake_getsourcefile(frame):
        return str(tmp_path / "caller.py")

    monkeypatch.setattr("omnilink.getsourcefile", fake_getsourcefile)
    patterns = load_patterns_from_file(Path("nested/patterns.txt"))

    assert patterns == ["command_one"]


def test_http_bridge_handles_command():
    engine = OmniLinkEngine(["do something"])

    engine.on_template("do something", lambda evt: {"ok": True})

    bridge = OmniLinkHTTPBridge(engine, port=0, log=False)

    payload = json.dumps({
        "command": "do something",
        "meta": {"agent": {"id": "alpha"}},
    })

    result = bridge._handle_command(payload)
    assert result.get("status") == "ok" or result.get("command") == "do something"


def test_engine_exposes_messenger_to_handlers():
    engine = OmniLinkEngine(["hello"])
    seen = {}

    def before(evt):
        seen["messenger"] = evt.get("messenger")

    engine.before(before)
    engine.on_template(
        "hello",
        lambda evt: evt["messenger"].send_feedback(AgentFeedback(message="hi", ok=True)),
    )

    class DummyMessenger:
        def __init__(self, linked_engine: OmniLinkEngine):
            self.engine = linked_engine
            self.feedback: List[AgentFeedback] = []
            self.questions: List[AgentQuestion] = []
            self.waiters: List[PendingQuestion] = []
            self.acks: List[Tuple[str, Optional[str], Optional[Dict[str, Any]]]] = []

        def send_feedback(self, feedback: AgentFeedback) -> None:
            self.feedback.append(feedback)

        def ask_question(self, question: AgentQuestion) -> PendingQuestion:
            waiter = self.engine.create_question_waiter()
            self.questions.append(question)
            self.waiters.append(waiter)
            return waiter

        def acknowledge(
            self,
            status: str,
            *,
            message: Optional[str] = None,
            data: Optional[Dict[str, Any]] = None,
        ) -> None:
            self.acks.append((status, message, data))

    messenger = DummyMessenger(engine)
    engine.handle("hello", messenger=messenger)

    assert seen["messenger"] is messenger
    assert messenger.feedback and messenger.feedback[0].message == "hi"
    assert engine.history[-1].messenger is messenger


def test_pending_question_waits_for_reply():
    engine = OmniLinkEngine(["hello"])
    waiter = engine.create_question_waiter()
    payload = {"correlationId": waiter.correlation_id, "choice": "yes"}
    assert not waiter.done()
    handled = engine.receive_agent_reply(payload)
    assert handled is True
    resolved = waiter.wait(timeout=0.1)
    assert resolved["choice"] == "yes"
    assert waiter.done()
    assert waiter.result()["choice"] == "yes"


def test_pending_question_timeout_and_cancel():
    engine = OmniLinkEngine(["hello"])
    waiter = engine.create_question_waiter()
    with pytest.raises(TimeoutError):
        waiter.wait(timeout=0.01)
    waiter.cancel("abort")
    with pytest.raises(RuntimeError):
        waiter.wait(timeout=0.01)


def test_http_bridge_context_and_feedback():
    engine = OmniLinkEngine(["ping"])
    engine.on_template("ping", lambda evt: {"ok": True})

    bridge = OmniLinkHTTPBridge(engine, port=0, log=False)

    # Context publishing stores in memory
    bridge.publish_context("system ready")
    assert bridge._latest_context is not None
    assert "system ready" in bridge._latest_context

    # Command processing stores feedback
    bridge._handle_command(json.dumps({"command": "ping"}))
    import time
    time.sleep(0.5)  # give worker thread time to process
    assert bridge._latest_feedback is not None
    feedback = json.loads(bridge._latest_feedback)
    assert feedback.get("ok") is True
