"""Example use cases for the OmniLink Python engine."""
