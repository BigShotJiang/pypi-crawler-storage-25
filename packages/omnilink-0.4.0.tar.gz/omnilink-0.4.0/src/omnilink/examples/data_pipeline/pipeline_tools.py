"""Long-running data analysis tools for the pipeline demo.

Each tool performs real computation on a CSV dataset and includes a
deliberate processing delay to simulate the kind of latency you get
with large-scale data operations.  This makes the UI's progress
spinner and activity notifications visible during the demo.
"""

from __future__ import annotations

import csv
import math
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from omnilink.default_tools import DefaultTool


def _load_csv(path: Path) -> list[dict[str, str]]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _numeric(rows: list[dict[str, str]], col: str) -> list[float]:
    vals: list[float] = []
    for r in rows:
        try:
            vals.append(float(r[col]))
        except (ValueError, KeyError):
            pass
    return vals


# ── ScanDatasetTool ──────────────────────────────────────────────────

class ScanDatasetTool(DefaultTool):
    """Scan a CSV dataset and return schema, row count, and a preview.

    Simulates a 2-3 second scan of a large dataset.
    """

    name = "scan_dataset"
    description = (
        "Scan the dataset and return its schema, row count, column types, "
        "and a preview of the first rows. No arguments required."
    )
    parameters_schema: dict[str, Any] | None = {"type": "object", "properties": {}}

    def __init__(self, csv_path: str) -> None:
        self.csv_path = Path(csv_path)

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(2.5)  # simulate large-file scan
        rows = _load_csv(self.csv_path)
        if not rows:
            return {"error": "Dataset is empty."}

        columns: list[dict[str, str]] = []
        for col in rows[0].keys():
            nums = _numeric(rows, col)
            col_type = "numeric" if len(nums) > len(rows) * 0.5 else "text"
            columns.append({"name": col, "type": col_type})

        preview = rows[:5]
        return {
            "file": self.csv_path.name,
            "rows": len(rows),
            "columns": columns,
            "preview": preview,
        }


# ── AnalyzeColumnTool ────────────────────────────────────────────────

class AnalyzeColumnTool(DefaultTool):
    """Compute descriptive statistics for a numeric column.

    Simulates a 2 second aggregation pass.
    """

    name = "analyze_column"
    description = (
        "Compute statistics for a column: mean, median, min, max, "
        "std dev, and value distribution. "
        "Args: column (required, e.g. 'amount'), group_by (optional)."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "column": {"type": "string", "description": "Column name to analyze."},
            "group_by": {"type": "string", "description": "Optional column to group results by."},
        },
        "required": ["column"],
    }

    def __init__(self, csv_path: str) -> None:
        self.csv_path = Path(csv_path)

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        col = kwargs.get("column", "").strip()
        if not col:
            return {"error": "Missing required argument: column"}

        time.sleep(2)  # simulate aggregation
        rows = _load_csv(self.csv_path)
        group_by = kwargs.get("group_by", "").strip()

        def _stats(vals: list[float]) -> dict[str, Any]:
            if not vals:
                return {"count": 0}
            vals_sorted = sorted(vals)
            n = len(vals_sorted)
            mean = sum(vals_sorted) / n
            median = (
                vals_sorted[n // 2]
                if n % 2
                else (vals_sorted[n // 2 - 1] + vals_sorted[n // 2]) / 2
            )
            variance = sum((x - mean) ** 2 for x in vals_sorted) / n
            return {
                "count": n,
                "mean": round(mean, 2),
                "median": round(median, 2),
                "min": round(vals_sorted[0], 2),
                "max": round(vals_sorted[-1], 2),
                "std_dev": round(math.sqrt(variance), 2),
                "sum": round(sum(vals_sorted), 2),
            }

        if group_by:
            groups: dict[str, list[float]] = defaultdict(list)
            for r in rows:
                key = r.get(group_by, "unknown")
                try:
                    groups[key].append(float(r[col]))
                except (ValueError, KeyError):
                    pass
            return {
                "column": col,
                "group_by": group_by,
                "groups": {k: _stats(v) for k, v in sorted(groups.items())},
            }

        vals = _numeric(rows, col)
        return {"column": col, **_stats(vals)}


# ── FilterDataTool ───────────────────────────────────────────────────

class FilterDataTool(DefaultTool):
    """Filter the dataset by column value and return matching rows.

    Simulates a 1.5 second filter pass.
    """

    name = "filter_data"
    description = (
        "Filter rows where a column matches a value. Returns matching "
        "rows and count. "
        "Args: column (required), value (required), operator (optional: "
        "'eq', 'gt', 'lt', 'gte', 'lte', 'contains'; default 'eq')."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "column": {"type": "string", "description": "Column name to filter on."},
            "value": {"type": "string", "description": "Value to match against."},
            "operator": {"type": "string", "description": "Comparison operator.", "enum": ["eq", "gt", "lt", "gte", "lte", "contains"]},
        },
        "required": ["column", "value"],
    }

    def __init__(self, csv_path: str) -> None:
        self.csv_path = Path(csv_path)

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        col = kwargs.get("column", "").strip()
        value = kwargs.get("value", "").strip()
        op = kwargs.get("operator", "eq").strip().lower()
        if not col or not value:
            return {"error": "Missing required arguments: column and value"}

        time.sleep(1.5)  # simulate filter
        rows = _load_csv(self.csv_path)

        def _match(row_val: str) -> bool:
            if op == "contains":
                return value.lower() in row_val.lower()
            try:
                rv, fv = float(row_val), float(value)
                if op == "gt":
                    return rv > fv
                if op == "lt":
                    return rv < fv
                if op == "gte":
                    return rv >= fv
                if op == "lte":
                    return rv <= fv
            except ValueError:
                pass
            return row_val.strip().lower() == value.lower()

        matched = [r for r in rows if _match(r.get(col, ""))]
        return {
            "column": col,
            "operator": op,
            "value": value,
            "total_matches": len(matched),
            "rows": matched[:10],
            "truncated": len(matched) > 10,
        }


# ── FindAnomaliesTool ────────────────────────────────────────────────

class FindAnomaliesTool(DefaultTool):
    """Detect outliers in a numeric column using the IQR method.

    Simulates a 3 second anomaly detection pass.
    """

    name = "find_anomalies"
    description = (
        "Detect outliers in a numeric column using statistical analysis. "
        "Returns anomalous rows with their values and z-scores. "
        "Args: column (required, e.g. 'amount')."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "column": {"type": "string", "description": "Numeric column to check for outliers."},
        },
        "required": ["column"],
    }

    def __init__(self, csv_path: str) -> None:
        self.csv_path = Path(csv_path)

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        col = kwargs.get("column", "").strip()
        if not col:
            return {"error": "Missing required argument: column"}

        time.sleep(3)  # simulate analysis
        rows = _load_csv(self.csv_path)
        vals = _numeric(rows, col)
        if len(vals) < 4:
            return {"error": f"Not enough numeric values in column '{col}'."}

        vals_sorted = sorted(vals)
        n = len(vals_sorted)
        q1 = vals_sorted[n // 4]
        q3 = vals_sorted[3 * n // 4]
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        mean = sum(vals) / n
        std = math.sqrt(sum((x - mean) ** 2 for x in vals) / n)

        anomalies = []
        for r in rows:
            try:
                v = float(r[col])
            except (ValueError, KeyError):
                continue
            if v < lower or v > upper:
                z = round((v - mean) / std, 2) if std > 0 else 0
                anomalies.append({**r, "_z_score": z, "_direction": "high" if v > upper else "low"})

        return {
            "column": col,
            "method": "IQR (1.5x)",
            "bounds": {"lower": round(lower, 2), "upper": round(upper, 2)},
            "iqr": round(iqr, 2),
            "total_rows": n,
            "anomaly_count": len(anomalies),
            "anomalies": anomalies[:10],
        }


# ── GenerateReportTool ───────────────────────────────────────────────

class GenerateReportTool(DefaultTool):
    """Compile a summary report of the dataset.

    Simulates a 3 second report generation pass that computes
    multiple aggregations at once.
    """

    name = "generate_report"
    description = (
        "Generate a comprehensive summary report of the dataset "
        "including totals, breakdowns by region/product/rep, win "
        "rates, and top performers. No arguments required."
    )
    parameters_schema: dict[str, Any] | None = {"type": "object", "properties": {}}

    def __init__(self, csv_path: str) -> None:
        self.csv_path = Path(csv_path)

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(3)  # simulate report generation
        rows = _load_csv(self.csv_path)
        if not rows:
            return {"error": "Dataset is empty."}

        total_deals = len(rows)
        won = [r for r in rows if r.get("status") == "won"]
        lost = [r for r in rows if r.get("status") == "lost"]
        pending = [r for r in rows if r.get("status") == "pending"]

        won_amounts = _numeric(won, "amount")
        total_revenue = sum(won_amounts)

        # By region
        region_revenue: dict[str, float] = defaultdict(float)
        for r in won:
            try:
                region_revenue[r["region"]] += float(r["amount"])
            except (ValueError, KeyError):
                pass

        # By product
        product_counts: Counter[str] = Counter()
        product_revenue: dict[str, float] = defaultdict(float)
        for r in won:
            product_counts[r.get("product", "unknown")] += 1
            try:
                product_revenue[r.get("product", "unknown")] += float(r["amount"])
            except (ValueError, KeyError):
                pass

        # By rep
        rep_revenue: dict[str, float] = defaultdict(float)
        rep_deals: Counter[str] = Counter()
        for r in won:
            rep = r.get("sales_rep", "unknown")
            rep_deals[rep] += 1
            try:
                rep_revenue[rep] += float(r["amount"])
            except (ValueError, KeyError):
                pass

        top_reps = sorted(rep_revenue.items(), key=lambda x: x[1], reverse=True)[:5]

        return {
            "overview": {
                "total_deals": total_deals,
                "won": len(won),
                "lost": len(lost),
                "pending": len(pending),
                "win_rate": round(len(won) / total_deals * 100, 1) if total_deals else 0,
                "total_revenue": round(total_revenue, 2),
                "avg_deal_size": round(total_revenue / len(won), 2) if won else 0,
            },
            "by_region": {
                k: round(v, 2) for k, v in sorted(region_revenue.items(), key=lambda x: x[1], reverse=True)
            },
            "by_product": {
                p: {"deals": product_counts[p], "revenue": round(product_revenue[p], 2)}
                for p in sorted(product_counts, key=lambda p: product_revenue[p], reverse=True)
            },
            "top_performers": [
                {"rep": rep, "revenue": round(rev, 2), "deals": rep_deals[rep]}
                for rep, rev in top_reps
            ],
        }
