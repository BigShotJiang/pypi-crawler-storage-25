"""Data Pipeline Agent — long-running tools demo.

An OmniLink agent that can analyze a sales dataset using tools that
simulate real processing time.  Each tool takes 1.5–3 seconds to
execute, demonstrating the UI's progress spinner, multi-round tool
chaining, and activity notifications for long-running operations.

Usage
-----
    export OMNI_KEY=omk_...
    python -m omnilink.examples.data_pipeline.data_pipeline_demo

Then open https://www.omnilink-agents.com/build and ask questions
about the sales data.  Press Ctrl+C to stop.
"""

from __future__ import annotations

import os
import pathlib
import signal
import sys
import threading
from typing import Any

LIB_PATH = pathlib.Path(__file__).resolve().parents[4] / "src"
if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from omnilink.tool_runner import ToolRunner
from omnilink.client import OmniLinkClient

from .pipeline_tools import (
    AnalyzeColumnTool,
    FilterDataTool,
    FindAnomaliesTool,
    GenerateReportTool,
    ScanDatasetTool,
)

# ── Configuration ────────────────────────────────────────────────────

CSV_PATH = str(
    pathlib.Path(__file__).resolve().parent / "sample_data" / "sales_q3_q4_2025.csv"
)

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get(
    "OMNILINK_BASE_URL", "https://www.omnilink-agents.com"
)


# ── Runner ───────────────────────────────────────────────────────────


class DataPipelineRunner(ToolRunner):
    """An agent that runs data analysis pipelines on a sales dataset."""

    agent_name = "data-pipeline-agent"
    display_name = "Data Pipeline"
    engine = "g3-engine"
    tool_name = "run_analysis"
    tool_description = (
        "Run a data analysis pipeline on the sales dataset using the "
        "available tools."
    )
    commands = "stop_game"

    default_tools = [
        ScanDatasetTool(csv_path=CSV_PATH),
        AnalyzeColumnTool(csv_path=CSV_PATH),
        FilterDataTool(csv_path=CSV_PATH),
        FindAnomaliesTool(csv_path=CSV_PATH),
        GenerateReportTool(csv_path=CSV_PATH),
    ]

    def get_profile_settings(self) -> dict[str, Any]:
        settings = super().get_profile_settings()
        settings["mainTask"] = (
            "You are a data analyst assistant with access to a sales dataset "
            "(200 deals from Q3–Q4 2025). Use the available tools to analyze "
            "the data and answer questions.\n\n"
            "Available tools:\n"
            "- scan_dataset: get schema, row count, and preview (start here)\n"
            "- analyze_column: compute stats (mean, median, min, max, std dev) "
            "for any numeric column, optionally grouped by another column\n"
            "- filter_data: filter rows by column value with operators "
            "(eq, gt, lt, gte, lte, contains)\n"
            "- find_anomalies: detect outliers in a numeric column using "
            "IQR statistical method\n"
            "- generate_report: create a full summary report with revenue "
            "totals, win rates, breakdowns by region/product/rep\n\n"
            "When the user asks a question, chain the right tools together. "
            "For example, to find the top region by revenue, you might: "
            "scan_dataset → analyze_column(column='amount', group_by='region'). "
            "Present results clearly with numbers and insights."
        )
        settings["maxToolRounds"] = 8
        return settings

    def get_state(self) -> dict[str, Any]:
        return {}

    def execute_action(self, state: dict[str, Any]) -> None:
        pass

    def state_summary(self, state: dict[str, Any]) -> str:
        return "idle"

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return True


# ── Entry point ──────────────────────────────────────────────────────


def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY before running:  export OMNI_KEY=omk_...")
        sys.exit(1)

    runner = DataPipelineRunner()
    runner.omni_key = OMNI_KEY
    runner.base_url = BASE_URL

    client = OmniLinkClient(omni_key=OMNI_KEY, base_url=BASE_URL, timeout=60)
    runner._client = client
    runner._conversation_history = []
    runner._activity_log = []

    port = runner._start_tool_server()
    runner.tool_callback_url = f"http://127.0.0.1:{port}/tool"

    runner._ensure_profile(client)

    try:
        client.set_memory(runner._memory_agent_key(), [])
    except Exception:
        pass

    print()
    print("=" * 60)
    print("  Data Pipeline Agent — Long-Running Tools Demo")
    print("=" * 60)
    print()
    print(f"  Tool server:     http://127.0.0.1:{port}/tool")
    print(f"  Activity log:    http://127.0.0.1:{port}/activity")
    print(f"  Dataset:         {CSV_PATH}")
    print()
    print(f"  Open the UI:     {BASE_URL}/build")
    print()
    print("  Tools (each takes 1.5–3s to simulate processing):")
    print("    scan_dataset     — scan schema and preview")
    print("    analyze_column   — compute stats, optionally by group")
    print("    filter_data      — filter rows by condition")
    print("    find_anomalies   — detect outliers (IQR method)")
    print("    generate_report  — full revenue/pipeline report")
    print()
    print("  Try asking:")
    print('    "Give me a full sales report"')
    print('    "Which region has the highest revenue?"')
    print('    "Find anomalies in deal amounts"')
    print('    "Show me all deals over $20,000"')
    print('    "How is Alice Chen performing?"')
    print()
    print("  Press Ctrl+C to stop.")
    print("=" * 60)
    print()

    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    try:
        signal.signal(signal.SIGBREAK, lambda *_: stop.set())
    except AttributeError:
        pass

    stop.wait()

    print()
    print("  Shutting down.")


if __name__ == "__main__":
    main()
