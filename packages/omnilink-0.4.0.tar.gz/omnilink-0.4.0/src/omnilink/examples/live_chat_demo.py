"""Live chat demo — connects the OmniLink UI to a local command engine.

This example creates an agent profile on the platform, then enters a
polling loop that watches for new messages sent from the OmniLink web
UI.  When a user chats with the agent, the cloud AI translates the
message into a command, and this script executes it on a local
``OmniLinkEngine`` — showing the full UI-to-engine round trip.

The agent supports a small set of commands to demonstrate the
connection.  Every result is written back to the agent's short-term
memory so it is visible in the UI conversation.

Setup
-----
    export OMNI_KEY="olink_YOUR_KEY_HERE"
    python -m omnilink.examples.live_chat_demo

Then open https://www.omnilink-agents.com, select the **live-demo**
agent, and send messages like:

- "Hello"
- "Echo: the weather is great"
- "What time is it"
- "Roll a dice"
- "Status"
- "Goodbye"
"""

from __future__ import annotations

import json
import os
import random
import re
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from omnilink import OmniLinkEngine
from omnilink.client import OmniLinkClient

# ── Configuration ─────────────────────────────────────────────

AGENT_NAME = "live-demo"
POLL_INTERVAL = 3  # seconds between checks for new messages

SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You are a live command agent connected to a local Python engine. "
        "Your ONLY job is to translate user messages into commands. "
        "ALWAYS output exactly one line: Command: <command_here>\n"
        "Available commands:\n"
        "  hello               — greet the user\n"
        "  echo_<words>        — echo back the words (use underscores for spaces)\n"
        "  time                — show current time\n"
        "  roll_dice           — roll a six-sided die\n"
        "  status              — show engine status\n"
        "  goodbye             — say goodbye\n"
        "Examples:\n"
        '  User: "Hi there!" → Command: hello\n'
        '  User: "Echo: good morning" → Command: echo_good_morning\n'
        '  User: "What time is it?" → Command: time\n'
        '  User: "Roll a dice" → Command: roll_dice\n'
        "NEVER ask clarifying questions. ALWAYS output Command: <cmd>."
    ),
    "availableCommands": "hello, echo_[message], time, roll_dice, status, goodbye",
}


# ── Build local engine ────────────────────────────────────────

def build_engine() -> OmniLinkEngine:
    engine = OmniLinkEngine([
        "hello",
        "echo_[message:any]",
        "time",
        "roll_dice",
        "status",
        "goodbye",
    ])

    engine.on_template("hello", lambda evt: {
        "reply": "Hello! I'm a live OmniLink agent. Try asking me to echo something, check the time, or roll a dice.",
    })

    engine.on_template("echo_[message:any]", lambda evt: {
        "reply": evt["vars"]["message"].replace("_", " "),
    })

    engine.on_template("time", lambda evt: {
        "reply": f"The current time is {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}.",
    })

    engine.on_template("roll_dice", lambda evt: {
        "reply": f"You rolled a {random.randint(1, 6)}!",
    })

    engine.on_template("status", lambda evt: {
        "reply": f"Engine is running. Templates: {len(engine.templates)}. "
                 f"Commands processed: {len(engine.history)}.",
    })

    engine.on_template("goodbye", lambda evt: {
        "reply": "Goodbye! Send another message whenever you're ready.",
    })

    return engine


# ── Platform integration ──────────────────────────────────────

def ensure_profile(client: OmniLinkClient) -> str:
    profiles = client.list_profiles()
    existing = next((p for p in profiles if p["name"] == AGENT_NAME), None)
    if existing:
        client.update_profile(existing["id"], name=AGENT_NAME, settings=SYSTEM_INSTRUCTION)
        return existing["id"]
    result = client.create_profile(AGENT_NAME, settings=SYSTEM_INSTRUCTION)
    return result["id"]


def extract_command(ai_text: str) -> Optional[str]:
    match = re.search(r"Command:\s*(.+)", ai_text)
    if match:
        cmd = match.group(1).strip()
        if cmd.lower() != "none":
            return cmd
    return None


def send_and_execute(
    client: OmniLinkClient,
    engine: OmniLinkEngine,
    user_message: str,
) -> Dict[str, Any]:
    """Send a user message through the platform AI, execute the command locally."""

    # 1. Send to platform AI — it translates to a command
    resp = client.chat(
        prompt=user_message,
        agent_name=AGENT_NAME,
        system_instruction=SYSTEM_INSTRUCTION,
        temperature=0.1,
    )
    ai_text = resp.get("text", "")

    # 2. Extract the command
    cmd = extract_command(ai_text)
    if not cmd:
        # Fallback: use the raw message as a command
        cmd = user_message.strip().replace(" ", "_").lower()

    # 3. Execute on local engine
    result = engine.handle(cmd)
    reply = "I didn't understand that command."
    if result.get("ok") and isinstance(result.get("result"), dict):
        reply = result["result"].get("reply", str(result["result"]))

    # 4. Save to platform memory (visible in UI)
    client.set_memory(AGENT_NAME, [
        {"role": "user", "parts": [{"text": user_message}]},
        {"role": "model", "parts": [{"text": reply}]},
    ])

    return {
        "user_message": user_message,
        "ai_command": cmd,
        "engine_ok": result.get("ok", False),
        "reply": reply,
    }


# ── Main loop ─────────────────────────────────────────────────

def main() -> None:
    omni_key = os.environ.get("OMNI_KEY", "")
    if not omni_key:
        print("Error: Set OMNI_KEY environment variable.")
        print("  export OMNI_KEY=\"olink_YOUR_KEY_HERE\"")
        sys.exit(1)

    client = OmniLinkClient(omni_key=omni_key)
    engine = build_engine()

    print("=" * 50)
    print("  OmniLink Live Chat Demo")
    print("=" * 50)
    print()

    profile_id = ensure_profile(client)
    print(f"  Agent: {AGENT_NAME} (profile: {profile_id[:8]}...)")
    print(f"  Templates: {engine.templates}")
    print()

    # Run a quick self-test
    print("  Running self-test...")
    tests = [
        ("Say hello!", "hello"),
        ("Echo: test message", "echo_test_message"),
        ("What time is it?", "time"),
        ("Roll a dice", "roll_dice"),
        ("Show status", "status"),
        ("Bye!", "goodbye"),
    ]

    all_passed = True
    for user_msg, expected_cmd in tests:
        r = send_and_execute(client, engine, user_msg)
        ok = r["engine_ok"]
        status = "OK" if ok else "FAIL"
        if not ok:
            all_passed = False
        print(f"    [{status}] \"{user_msg}\" -> cmd=\"{r['ai_command']}\" -> \"{r['reply'][:60]}\"")

    print()
    if all_passed:
        print("  All tests passed!")
    else:
        print("  Some tests used fallback commands (AI didn't output Command: line)")

    print()
    print("  Agent is live at: https://www.omnilink-agents.com")
    print(f"  Select '{AGENT_NAME}' and start chatting.")
    print()

    # Clear test memory so user starts fresh
    client.clear_memory(AGENT_NAME)

    print("  Entering poll loop (Ctrl+C to stop)...")
    print("  Waiting for messages from the UI...")
    print()

    last_memory_sig = None
    try:
        while True:
            time.sleep(POLL_INTERVAL)

            # Check for new messages in memory
            try:
                memory = client.get_memory(AGENT_NAME)
            except Exception:
                continue

            if not memory:
                continue

            # Build a signature to detect new messages
            sig = json.dumps(memory, sort_keys=True)
            if sig == last_memory_sig:
                continue
            last_memory_sig = sig

            # Find the latest user message
            latest_user_msg = None
            for msg in reversed(memory):
                if isinstance(msg, dict) and msg.get("role") == "user":
                    parts = msg.get("parts", [])
                    if parts and isinstance(parts[0], dict):
                        latest_user_msg = parts[0].get("text", "")
                    break

            if not latest_user_msg:
                continue

            print(f"  >> Received: \"{latest_user_msg}\"")
            r = send_and_execute(client, engine, latest_user_msg)
            print(f"     Command:  \"{r['ai_command']}\"")
            print(f"     Reply:    \"{r['reply']}\"")
            print()

    except KeyboardInterrupt:
        print("\n  Stopped.")


if __name__ == "__main__":
    main()
