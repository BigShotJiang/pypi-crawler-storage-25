"""HTTP client for the Pac-Man game server."""

from __future__ import annotations

import json
from typing import Any

import requests

SERVER_URL = "http://127.0.0.1:5000"

# Reuse a persistent session for connection pooling.
_session = requests.Session()


def get_state() -> dict[str, Any]:
    """Fetch the current game state from the server.

    Returns the parsed game state dict with keys: player, ghosts, pellets,
    power_pellets, walkable, tunnel_rows, score, lives, level, mode,
    game_state, pellets_left, grid_width, grid_height.
    """
    r = _session.get(f"{SERVER_URL}/data", timeout=2)
    data = r.json()
    payload = data.get("payload", "{}")
    if isinstance(payload, str):
        return json.loads(payload)
    return payload


def get_raw() -> dict[str, Any]:
    """Fetch the raw server response (command, payload, version)."""
    r = _session.get(f"{SERVER_URL}/data", timeout=2)
    return r.json()


def send_action(action: str, version: int | None = None) -> None:
    """Send a direction action (UP, DOWN, LEFT, RIGHT, STOP) to the game."""
    payload: dict[str, Any] = {"action": action}
    if version is not None:
        payload["version"] = version
    _session.post(
        f"{SERVER_URL}/callback",
        json=payload,
        timeout=2,
    )
