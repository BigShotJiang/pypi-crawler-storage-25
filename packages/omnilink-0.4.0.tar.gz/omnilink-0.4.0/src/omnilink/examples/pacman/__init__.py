"""Pac-Man benchmark — BFS pathfinding with predictive ghost avoidance."""
