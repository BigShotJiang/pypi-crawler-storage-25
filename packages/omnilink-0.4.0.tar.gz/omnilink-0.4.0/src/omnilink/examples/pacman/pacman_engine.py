"""Local Pac-Man AI engine — survival-first BFS with predictive avoidance.

Every single move passes through a safety filter.  The agent never
commits to a direction that would bring it closer to danger, never
enters dead-ends when ghosts are nearby, and prefers junctions (tiles
with 3+ exits) for maximum escape options.

Strategy layers (all safety-gated):
  1. FLEE  — active ghost within DANGER_RADIUS → maximise weighted
             distance from ALL ghosts, preferring junctions.
  2. CHASE — frightened ghost reachable AND path is safe → eat it.
  3. HUNT  — nearest safe pellet; save power pellets for ambush.
"""

from __future__ import annotations

import math
from collections import deque
from typing import Any

# ── Tuning constants ─────────────────────────────────────────────────────────
DANGER_RADIUS    = 10   # BFS tiles — always-on threat detection.
CRITICAL_RADIUS  = 4    # Ghost this close = emergency, allow reverse.
SAFE_CHASE_MIN   = 5    # Min BFS dist to nearest active ghost to chase.
POWER_AMBUSH_MAX = 8    # Only eat power pellet if ghost within this range.
DEAD_END_DANGER  = 12   # Avoid dead-end paths if ghost within this range.
COMMIT_FRAMES    = 3    # Reduced commitment — recheck more often.
FLEE_COMMIT      = 1    # Almost no commitment during flee.

# ── Direction helpers ────────────────────────────────────────────────────────
OPPOSITE: dict[str, str] = {
    "LEFT": "RIGHT", "RIGHT": "LEFT", "UP": "DOWN", "DOWN": "UP",
}
DIR_VEC: dict[str, tuple[int, int]] = {
    "LEFT": (-1, 0), "RIGHT": (1, 0), "UP": (0, -1), "DOWN": (0, 1),
}
ALL_DIRS: list[str] = ["LEFT", "RIGHT", "UP", "DOWN"]

# ── Shared agent state ───────────────────────────────────────────────────────
_committed_dir: str | None = None
_commit_left: int = 0
# Precomputed maze analysis (cached per level).
_cached_walkable_id: int = 0
_junction_set: set[str] = set()        # tiles with 3+ walkable neighbours
_dead_end_set: set[str] = set()        # tiles with exactly 1 walkable neighbour
_dead_end_depth: dict[str, int] = {}   # BFS depth into dead-end corridors


def reset_commitment() -> None:
    """Reset direction commitment (call on death or level change)."""
    global _committed_dir, _commit_left
    _committed_dir = None
    _commit_left = 0


# ── Maze helpers ─────────────────────────────────────────────────────────────

def _is_walkable(x: int, y: int, state: dict) -> bool:
    w = state["grid_width"]
    h = state["grid_height"]
    walkable = state["walkable"]
    tunnel_rows = state.get("tunnel_rows", [])
    if y < 0 or y >= h:
        return False
    if x < 0 or x >= w:
        if y not in tunnel_rows:
            return False
        x = x % w
    return walkable[y][x] == "1"


def _wrap_x(x: int, y: int, state: dict) -> int:
    w = state["grid_width"]
    tunnel_rows = state.get("tunnel_rows", [])
    if y in tunnel_rows:
        return x % w
    return x


def _neighbor_count(x: int, y: int, state: dict) -> int:
    """Count how many walkable neighbours tile (x,y) has."""
    c = 0
    for dvx, dvy in DIR_VEC.values():
        nx = _wrap_x(x + dvx, y + dvy, state)
        ny = y + dvy
        if _is_walkable(nx, ny, state):
            c += 1
    return c


# ── Maze precomputation (once per level) ─────────────────────────────────────

def _precompute_maze(state: dict) -> None:
    """Identify junctions, dead-ends, and dead-end corridor depths."""
    global _cached_walkable_id, _junction_set, _dead_end_set, _dead_end_depth

    # Use hash of walkable rows as cache key.
    wid = hash(tuple(state["walkable"]))
    if wid == _cached_walkable_id:
        return
    _cached_walkable_id = wid

    w = state["grid_width"]
    h = state["grid_height"]
    _junction_set = set()
    _dead_end_set = set()
    _dead_end_depth = {}

    for y in range(h):
        for x in range(w):
            if not _is_walkable(x, y, state):
                continue
            nc = _neighbor_count(x, y, state)
            key = f"{x},{y}"
            if nc >= 3:
                _junction_set.add(key)
            elif nc == 1:
                _dead_end_set.add(key)

    # BFS outward from each dead-end to compute corridor depth.
    # depth = how many tiles deep into a dead-end corridor this tile is.
    # A tile at a junction or with 3+ exits has depth 0.
    for de_key in _dead_end_set:
        parts = de_key.split(",")
        sx, sy = int(parts[0]), int(parts[1])
        depth = 0
        cx, cy = sx, sy
        visited = {de_key}
        _dead_end_depth[de_key] = 1

        while True:
            depth += 1
            found_next = False
            for dvx, dvy in DIR_VEC.values():
                nx = _wrap_x(cx + dvx, cy + dvy, state)
                ny = cy + dvy
                nk = f"{nx},{ny}"
                if not _is_walkable(nx, ny, state) or nk in visited:
                    continue
                nc = _neighbor_count(nx, ny, state)
                if nc <= 2:
                    # Still in corridor.
                    visited.add(nk)
                    if nk not in _dead_end_depth or depth + 1 > _dead_end_depth[nk]:
                        _dead_end_depth[nk] = depth + 1
                    cx, cy = nx, ny
                    found_next = True
                    break
                # Reached junction — stop.
            if not found_next:
                break


# ── BFS utilities ────────────────────────────────────────────────────────────

def bfs_distances(sx: int, sy: int, state: dict,
                  stop_at: set[str] | None = None,
                  max_dist: int = 9999) -> dict[str, int]:
    """BFS from (sx, sy). Returns {"x,y": distance} for reachable tiles."""
    dist: dict[str, int] = {}
    queue: deque[tuple[int, int]] = deque()
    start_key = f"{sx},{sy}"
    dist[start_key] = 0
    queue.append((sx, sy))
    found = 0
    needed = len(stop_at) if stop_at else float("inf")

    while queue:
        if found >= needed:
            break
        x, y = queue.popleft()
        d = dist[f"{x},{y}"]
        if d >= max_dist:
            continue

        for direction in ALL_DIRS:
            dvx, dvy = DIR_VEC[direction]
            nx = _wrap_x(x + dvx, y + dvy, state)
            ny = y + dvy
            if not _is_walkable(nx, ny, state):
                continue
            key = f"{nx},{ny}"
            if key in dist:
                continue
            dist[key] = d + 1
            if stop_at and key in stop_at:
                found += 1
            queue.append((nx, ny))

    return dist


def bfs_first_step(sx: int, sy: int, gx: int, gy: int,
                   state: dict, forbid_reverse: str | None = None) -> str | None:
    """Return the first-step direction from (sx,sy) toward (gx,gy)."""
    if sx == gx and sy == gy:
        return None

    prev: dict[str, tuple[int, int] | None] = {}
    dir_of: dict[str, str] = {}
    queue: deque[tuple[int, int]] = deque()
    start_key = f"{sx},{sy}"
    goal_key = f"{gx},{gy}"
    prev[start_key] = None
    queue.append((sx, sy))

    while queue:
        x, y = queue.popleft()
        cur_key = f"{x},{y}"
        if cur_key == goal_key:
            break

        for direction in ALL_DIRS:
            dvx, dvy = DIR_VEC[direction]
            nx = _wrap_x(x + dvx, y + dvy, state)
            ny = y + dvy
            if not _is_walkable(nx, ny, state):
                continue
            key = f"{nx},{ny}"
            if key in prev:
                continue
            if cur_key == start_key and forbid_reverse and direction == forbid_reverse:
                continue
            prev[key] = (x, y)
            dir_of[key] = direction
            queue.append((nx, ny))

    if goal_key not in prev:
        return None

    cur = goal_key
    while True:
        p = prev[cur]
        if p is None:
            return None
        pk = f"{p[0]},{p[1]}"
        if pk == start_key:
            return dir_of[cur]
        cur = pk


# ── Ghost distance helpers ───────────────────────────────────────────────────

def _ghost_distances(from_map: dict[str, int],
                     ghosts: list[dict]) -> list[tuple[dict, float]]:
    """Return [(ghost, bfs_dist)] for all ghosts, sorted by distance."""
    result = []
    for g in ghosts:
        gkey = f"{math.floor(g['x'])},{math.floor(g['y'])}"
        d = from_map.get(gkey, float("inf"))
        result.append((g, d))
    result.sort(key=lambda t: t[1])
    return result


def _min_ghost_dist(from_map: dict[str, int],
                    active_ghosts: list[dict]) -> float:
    """Return BFS distance to the nearest active ghost."""
    mind = float("inf")
    for g in active_ghosts:
        gkey = f"{math.floor(g['x'])},{math.floor(g['y'])}"
        d = from_map.get(gkey, float("inf"))
        if d < mind:
            mind = d
    return mind


# ── Safety scoring ───────────────────────────────────────────────────────────

def _score_direction(px: int, py: int, direction: str,
                     state: dict, active_ghosts: list[dict]) -> float:
    """Score a candidate direction.  Higher = safer + better.

    Components:
      - min ghost distance from the next tile  (dominant factor)
      - sum of reciprocal ghost distances      (penalise being near ANY ghost)
      - junction bonus                         (prefer tiles with more exits)
      - dead-end penalty                       (avoid corridors near ghosts)
      - pellet bonus                           (tiebreak: pick up food)
    """
    dvx, dvy = DIR_VEC[direction]
    nx = _wrap_x(px + dvx, py + dvy, state)
    ny = py + dvy
    if not _is_walkable(nx, ny, state):
        return -float("inf")

    nk = f"{nx},{ny}"
    from_next = bfs_distances(nx, ny, state, max_dist=DANGER_RADIUS + 5)

    # Ghost distances from candidate tile.
    min_gd = float("inf")
    sum_inv = 0.0
    for g in active_ghosts:
        gkey = f"{math.floor(g['x'])},{math.floor(g['y'])}"
        d = from_next.get(gkey, float("inf"))
        if d < min_gd:
            min_gd = d
        if d > 0 and d < 50:
            sum_inv += 1.0 / d

    # Junction bonus: junctions have more escape routes.
    junction_bonus = 2.0 if nk in _junction_set else 0.0

    # Dead-end penalty: severe when ghosts are near.
    de_depth = _dead_end_depth.get(nk, 0)
    dead_end_penalty = 0.0
    if de_depth > 0 and min_gd < DEAD_END_DANGER:
        dead_end_penalty = de_depth * 5.0  # heavy penalty

    # Pellet tiebreak.
    pellets = state.get("pellets", [])
    pellet_bonus = 0.0
    for tx, ty in pellets:
        pd = from_next.get(f"{tx},{ty}", float("inf"))
        if pd <= 3:
            pellet_bonus += 0.3
            if pd == 0:
                pellet_bonus += 0.5  # immediate pellet

    score = (min_gd * 3.0          # dominant: stay far from closest ghost
             - sum_inv * 2.0       # penalise being near multiple ghosts
             + junction_bonus
             - dead_end_penalty
             + pellet_bonus)

    return score


# ── Main decision function ───────────────────────────────────────────────────

def decide_action(state: dict[str, Any]) -> str:
    """Decide the direction based on the current game state.

    Returns 'UP', 'DOWN', 'LEFT', 'RIGHT', or 'STOP'.
    """
    global _committed_dir, _commit_left

    _precompute_maze(state)

    player = state["player"]
    px = math.floor(player["x"])
    py = math.floor(player["y"])
    current_dir = player.get("dir", "LEFT")
    forbid_reverse = OPPOSITE.get(current_dir)

    ghosts = state.get("ghosts", [])
    active_ghosts = [g for g in ghosts
                     if g["state"] not in ("FRIGHTENED", "EATEN")]
    frightened_ghosts = [g for g in ghosts if g["state"] == "FRIGHTENED"]

    from_player = bfs_distances(px, py, state)
    closest_threat_dist = _min_ghost_dist(from_player, active_ghosts)

    # ── ALWAYS break commitment if danger has increased ──────────────────────
    if _committed_dir is not None and _commit_left > 0:
        if closest_threat_dist <= CRITICAL_RADIUS:
            # Emergency — reconsider immediately.
            _commit_left = 0
            _committed_dir = None
        else:
            dvx, dvy = DIR_VEC[_committed_dir]
            nx = _wrap_x(px + dvx, py + dvy, state)
            ny = py + dvy
            if _is_walkable(nx, ny, state):
                # Quick safety check: is committed direction still safe?
                nk = f"{nx},{ny}"
                from_next = bfs_distances(nx, ny, state, max_dist=DANGER_RADIUS)
                next_min_gd = _min_ghost_dist(from_next, active_ghosts)
                de_depth = _dead_end_depth.get(nk, 0)

                if next_min_gd > CRITICAL_RADIUS and not (de_depth > 0 and next_min_gd < DEAD_END_DANGER):
                    _commit_left -= 1
                    return _committed_dir
            # Wall ahead or no longer safe — reconsider.
            _commit_left = 0
            _committed_dir = None

    # ── Determine mode ───────────────────────────────────────────────────────
    if closest_threat_dist <= DANGER_RADIUS:
        mode = "FLEE"
    elif frightened_ghosts:
        mode = "CHASE"
    else:
        mode = "HUNT"

    # ── FLEE: score all directions, pick safest ──────────────────────────────
    if mode == "FLEE":
        allow_reverse = closest_threat_dist <= CRITICAL_RADIUS

        best_dir: str | None = None
        best_score = -float("inf")

        for direction in ALL_DIRS:
            if not allow_reverse and direction == forbid_reverse:
                continue
            s = _score_direction(px, py, direction, state, active_ghosts)
            if s > best_score:
                best_score = s
                best_dir = direction

        # If nothing found (shouldn't happen), allow all.
        if best_dir is None:
            for direction in ALL_DIRS:
                s = _score_direction(px, py, direction, state, active_ghosts)
                if s > best_score:
                    best_score = s
                    best_dir = direction

        chosen = best_dir if best_dir else current_dir
        _committed_dir = chosen
        _commit_left = FLEE_COMMIT
        return chosen

    # ── CHASE: BFS toward nearest frightened ghost IF path is safe ────────────
    if mode == "CHASE":
        best_dir: str | None = None
        min_dist = float("inf")

        for g in frightened_ghosts:
            gx = math.floor(g["x"])
            gy = math.floor(g["y"])
            gkey = f"{gx},{gy}"
            d = from_player.get(gkey, float("inf"))
            if d < min_dist:
                direction = bfs_first_step(px, py, gx, gy, state, forbid_reverse)
                if direction:
                    # Safety gate: check that chasing doesn't walk into an
                    # active ghost.
                    dvx, dvy = DIR_VEC[direction]
                    nx = _wrap_x(px + dvx, py + dvy, state)
                    ny = py + dvy
                    from_next = bfs_distances(nx, ny, state, max_dist=DANGER_RADIUS)
                    next_min_gd = _min_ghost_dist(from_next, active_ghosts)
                    if next_min_gd >= SAFE_CHASE_MIN:
                        min_dist = d
                        best_dir = direction

        if best_dir:
            _committed_dir = best_dir
            _commit_left = COMMIT_FRAMES
            return best_dir
        # Unsafe to chase — fall through to safe HUNT.

    # ── HUNT: nearest safe pellet ────────────────────────────────────────────
    # Strategic power-pellet usage: only eat if ghost close enough to ambush.
    pellets = state.get("pellets", [])
    power_pellets = state.get("power_pellets", [])

    want_power = closest_threat_dist <= POWER_AMBUSH_MAX
    if want_power:
        target_list = list(power_pellets) + list(pellets)
    else:
        # Avoid power pellets unless no regular pellets left.
        target_list = list(pellets) if pellets else list(power_pellets)

    best_hunt_dir: str | None = None
    best_hunt_score = -float("inf")

    for tx, ty in target_list:
        tkey = f"{tx},{ty}"
        d = from_player.get(tkey, float("inf"))
        if d == float("inf"):
            continue
        direction = bfs_first_step(px, py, tx, ty, state, forbid_reverse)
        if not direction:
            continue

        # Safety gate: check that this first step is safe.
        dvx, dvy = DIR_VEC[direction]
        nx = _wrap_x(px + dvx, py + dvy, state)
        ny = py + dvy
        nk = f"{nx},{ny}"

        from_next = bfs_distances(nx, ny, state, max_dist=DANGER_RADIUS)
        next_min_gd = _min_ghost_dist(from_next, active_ghosts)

        # Reject moves that walk into danger.
        if next_min_gd <= CRITICAL_RADIUS:
            continue

        # Reject moves into dead-end corridors when ghosts are somewhat near.
        de_depth = _dead_end_depth.get(nk, 0)
        if de_depth > 0 and next_min_gd < DEAD_END_DANGER:
            continue

        # Score: prefer closer pellets, but penalise slightly for danger.
        score = -d + next_min_gd * 0.3
        # Bonus for power pellets when ghosts are close (ambush).
        if (tx, ty) in [(pp[0], pp[1]) for pp in power_pellets] and want_power:
            score += 5.0
        # Junction bonus.
        if nk in _junction_set:
            score += 1.0

        if score > best_hunt_score:
            best_hunt_score = score
            best_hunt_dir = direction

    # If all forward pellets are blocked, allow reverse.
    if not best_hunt_dir:
        for tx, ty in target_list:
            direction = bfs_first_step(px, py, tx, ty, state)
            if direction:
                # Still check basic safety.
                dvx, dvy = DIR_VEC[direction]
                nx = _wrap_x(px + dvx, py + dvy, state)
                ny = py + dvy
                from_next = bfs_distances(nx, ny, state, max_dist=DANGER_RADIUS)
                next_min_gd = _min_ghost_dist(from_next, active_ghosts)
                if next_min_gd > CRITICAL_RADIUS:
                    best_hunt_dir = direction
                    break

    # If STILL nothing safe, fall back to safest direction (flee logic).
    if not best_hunt_dir:
        best_score = -float("inf")
        for direction in ALL_DIRS:
            s = _score_direction(px, py, direction, state, active_ghosts)
            if s > best_score:
                best_score = s
                best_hunt_dir = direction

    if best_hunt_dir:
        _committed_dir = best_hunt_dir
        _commit_left = COMMIT_FRAMES
        return best_hunt_dir

    return current_dir


# ── State summary (for OmniLink memory) ─────────────────────────────────────

def state_summary(state: dict[str, Any]) -> str:
    """Build a concise text summary of the current game state."""
    player = state.get("player", {})
    ghosts = state.get("ghosts", [])
    pellets_left = state.get("pellets_left", 0)
    lives = state.get("lives", 0)
    score = state.get("score", 0)
    level = state.get("level", 1)
    game_state = state.get("game_state", "UNKNOWN")
    mode = state.get("mode", "UNKNOWN")

    ghost_info = ", ".join(
        f"{g['name']}({g['state']})" for g in ghosts
    )

    return (
        f"Game state: {game_state}\n"
        f"Score: {score} | Level: {level} | Lives: {lives}\n"
        f"Mode: {mode}\n"
        f"Pellets remaining: {pellets_left}\n"
        f"Player position: ({player.get('x', 0):.1f}, {player.get('y', 0):.1f}) "
        f"dir={player.get('dir', '?')}\n"
        f"Ghosts: {ghost_info}"
    )
