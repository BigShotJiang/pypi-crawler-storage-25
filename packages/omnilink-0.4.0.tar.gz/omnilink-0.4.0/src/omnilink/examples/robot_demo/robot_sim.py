#!/usr/bin/env python3
"""Pygame mobile-robot simulation with HTTP server on port 5050.

Run this first, then start play_robot.py in another terminal.

    python robot_sim.py
"""

from __future__ import annotations

import http.server
import json
import math
import random
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import pygame

# ── Grid constants ────────────────────────────────────────────
COLS, ROWS = 20, 15
CELL = 40
HUD_H = 60
WIDTH = COLS * CELL
HEIGHT = ROWS * CELL + HUD_H
FPS = 30
PORT = 5050

# ── Colours ───────────────────────────────────────────────────
C_BG = (30, 30, 40)
C_GRID = (50, 50, 60)
C_FLOOR = (45, 45, 55)
C_WALL = (90, 60, 60)
C_FOG = (25, 25, 32)
C_ROBOT = (60, 200, 120)
C_ITEM_GEM = (80, 180, 255)
C_ITEM_STAR = (255, 220, 60)
C_HUD_BG = (20, 20, 28)
C_HUD_TXT = (200, 200, 210)
C_BATTERY = (100, 220, 100)
C_BATTERY_LOW = (220, 80, 80)
C_TRAIL = (40, 70, 50)

# ── Headings ──────────────────────────────────────────────────
HEADINGS = ["N", "E", "S", "W"]
DX = {"N": 0, "E": 1, "S": 0, "W": -1}
DY = {"N": -1, "E": 0, "S": 1, "W": 0}


# ── Simulation ────────────────────────────────────────────────

class RobotSim:
    def __init__(self) -> None:
        self.robot_x = 1
        self.robot_y = 1
        self.heading = "E"
        self.battery = 100
        self.speed = 1
        self.inventory: List[str] = []
        self.score = 0
        self.steps = 0
        self.message = "Robot ready."
        self.game_state = "PLAY"
        self.trail: List[Tuple[int, int]] = []

        # Build obstacles
        self.obstacles: set[Tuple[int, int]] = set()
        self._generate_obstacles()

        # Place items
        self.items: List[Dict[str, Any]] = []
        self._place_items(10)

        # Fog of war: revealed tiles
        self.revealed: set[Tuple[int, int]] = set()
        self._reveal_around(self.robot_x, self.robot_y, 2)

    def _generate_obstacles(self) -> None:
        count = int(COLS * ROWS * 0.18)
        safe = {(1, 1), (1, 2), (2, 1), (0, 0)}
        while len(self.obstacles) < count:
            x, y = random.randint(0, COLS - 1), random.randint(0, ROWS - 1)
            if (x, y) not in safe:
                self.obstacles.add((x, y))

    def _place_items(self, n: int) -> None:
        types = ["gem", "star", "crystal", "coin"]
        placed = 0
        while placed < n:
            x, y = random.randint(0, COLS - 1), random.randint(0, ROWS - 1)
            if (x, y) not in self.obstacles and (x, y) != (self.robot_x, self.robot_y):
                self.items.append({"x": x, "y": y, "type": random.choice(types)})
                placed += 1

    def _reveal_around(self, cx: int, cy: int, radius: int) -> None:
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                nx, ny = cx + dx, cy + dy
                if 0 <= nx < COLS and 0 <= ny < ROWS:
                    self.revealed.add((nx, ny))

    def _in_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < COLS and 0 <= y < ROWS

    def _can_move(self, x: int, y: int) -> bool:
        return self._in_bounds(x, y) and (x, y) not in self.obstacles

    def apply_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> str:
        if self.game_state != "PLAY":
            return "Game is not active."
        params = params or {}

        if action == "move_forward":
            return self._move(1)
        elif action == "move_backward":
            return self._move(-1)
        elif action == "turn_left":
            i = HEADINGS.index(self.heading)
            self.heading = HEADINGS[(i - 1) % 4]
            return f"Turned left, now facing {self.heading}."
        elif action == "turn_right":
            i = HEADINGS.index(self.heading)
            self.heading = HEADINGS[(i + 1) % 4]
            return f"Turned right, now facing {self.heading}."
        elif action == "scan_area":
            self._reveal_around(self.robot_x, self.robot_y, 3)
            self.battery = max(0, self.battery - 1)
            return "Area scanned (3-tile radius revealed)."
        elif action == "pick_up":
            return self._pick_up()
        elif action == "drop_item":
            return self._drop_item()
        elif action == "report_status":
            return (
                f"Position: ({self.robot_x},{self.robot_y}) heading {self.heading} | "
                f"Battery: {self.battery}% | Inventory: {self.inventory} | "
                f"Score: {self.score} | Steps: {self.steps}"
            )
        elif action == "set_speed":
            spd = int(params.get("speed", self.speed))
            self.speed = max(1, min(5, spd))
            return f"Speed set to {self.speed}."
        elif action == "go_to":
            tx, ty = int(params.get("x", self.robot_x)), int(params.get("y", self.robot_y))
            return self._go_to(tx, ty)
        elif action == "START":
            self.game_state = "PLAY"
            return "Game started."
        elif action == "PAUSE":
            self.game_state = "PAUSE"
            return "Paused."
        elif action == "RESUME":
            self.game_state = "PLAY"
            return "Resumed."
        else:
            return f"Unknown action: {action}"

    def _move(self, direction: int) -> str:
        dx = DX[self.heading] * direction
        dy = DY[self.heading] * direction
        nx, ny = self.robot_x + dx, self.robot_y + dy
        if not self._can_move(nx, ny):
            return "Blocked! Cannot move there."
        self.trail.append((self.robot_x, self.robot_y))
        self.robot_x, self.robot_y = nx, ny
        self.steps += 1
        self.battery = max(0, self.battery - 1)
        self._reveal_around(nx, ny, 1)
        if self.battery <= 0:
            self.game_state = "GAMEOVER"
            return "Battery depleted! Game over."
        label = "forward" if direction == 1 else "backward"
        return f"Moved {label} to ({nx},{ny})."

    def _pick_up(self) -> str:
        for i, item in enumerate(self.items):
            if item["x"] == self.robot_x and item["y"] == self.robot_y:
                self.inventory.append(item["type"])
                self.score += 10
                self.items.pop(i)
                return f"Picked up {item['type']}! Score: {self.score}"
        return "Nothing to pick up here."

    def _drop_item(self) -> str:
        if not self.inventory:
            return "Inventory is empty."
        item_type = self.inventory.pop()
        self.items.append({"x": self.robot_x, "y": self.robot_y, "type": item_type})
        return f"Dropped {item_type}."

    def _go_to(self, tx: int, ty: int) -> str:
        if not self._in_bounds(tx, ty):
            return f"Target ({tx},{ty}) is out of bounds."
        if (tx, ty) in self.obstacles:
            return f"Target ({tx},{ty}) is an obstacle."
        # Simplified: just face toward target and move one step
        dx = tx - self.robot_x
        dy = ty - self.robot_y
        if dx == 0 and dy == 0:
            return "Already at target."
        if abs(dx) >= abs(dy):
            self.heading = "E" if dx > 0 else "W"
        else:
            self.heading = "S" if dy > 0 else "N"
        return self._move(1)

    def get_state(self) -> Dict[str, Any]:
        return {
            "robot": {"x": self.robot_x, "y": self.robot_y, "heading": self.heading},
            "battery": self.battery,
            "inventory": list(self.inventory),
            "obstacles": [[x, y] for x, y in sorted(self.obstacles)],
            "items": list(self.items),
            "grid_width": COLS,
            "grid_height": ROWS,
            "revealed": [[x, y] for x, y in sorted(self.revealed)],
            "speed": self.speed,
            "game_state": self.game_state,
            "score": self.score,
            "steps_taken": self.steps,
            "message": self.message,
            "items_remaining": len(self.items),
        }


# ── HTTP Server ───────────────────────────────────────────────

_SIM: Optional[RobotSim] = None
_VERSION = 0


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    def do_GET(self):
        global _VERSION
        if self.path == "/data":
            _VERSION += 1
            state = _SIM.get_state() if _SIM else {}
            body = json.dumps({
                "command": "ACTIVATE" if state.get("game_state") == "PLAY" else "IDLE",
                "payload": json.dumps(state),
                "version": _VERSION,
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/context":
            state = _SIM.get_state() if _SIM else {}
            r = state.get("robot", {})
            body = json.dumps({
                "position": f"({r.get('x',0)},{r.get('y',0)})",
                "heading": r.get("heading", "?"),
                "battery": state.get("battery", 0),
                "score": state.get("score", 0),
                "items_remaining": state.get("items_remaining", 0),
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length).decode("utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {}

        if self.path == "/callback":
            action = data.get("action", "")
            params = {k: v for k, v in data.items() if k != "action"}
            msg = _SIM.apply_action(action, params) if _SIM else "No simulation."
            if _SIM:
                _SIM.message = msg
            resp = json.dumps({"status": "ok", "message": msg}).encode()
        elif self.path == "/command":
            cmd = data.get("command", "")
            msg = ""
            if _SIM and cmd.upper() in ("PAUSE", "RESUME"):
                msg = _SIM.apply_action(cmd.upper())
            resp = json.dumps({"status": "ok", "message": msg}).encode()
        elif self.path == "/tool":
            # Execute a tool against the live simulation state
            from .robot_engine import execute_tool
            tool_name = data.get("tool", "")
            tool_args = {k: v for k, v in data.items() if k != "tool"}
            state = _SIM.get_state() if _SIM else {}
            tool_result = execute_tool(tool_name, state, **tool_args)
            resp = json.dumps({"status": "ok", "tool": tool_name, "result": tool_result}).encode()
        else:
            self.send_error(404)
            return

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self._cors()
        self.end_headers()
        self.wfile.write(resp)


def _start_http(port: int) -> None:
    server = http.server.ThreadingHTTPServer(("0.0.0.0", port), Handler)
    server.serve_forever()


# ── Pygame rendering ──────────────────────────────────────────

def _draw_arrow(surface: pygame.Surface, cx: int, cy: int, heading: str, size: int, color: Tuple[int, ...]) -> None:
    """Draw a triangular arrow pointing in the heading direction."""
    half = size // 2
    if heading == "N":
        pts = [(cx, cy - half), (cx - half, cy + half), (cx + half, cy + half)]
    elif heading == "S":
        pts = [(cx, cy + half), (cx - half, cy - half), (cx + half, cy - half)]
    elif heading == "E":
        pts = [(cx + half, cy), (cx - half, cy - half), (cx - half, cy + half)]
    else:  # W
        pts = [(cx - half, cy), (cx + half, cy - half), (cx + half, cy + half)]
    pygame.draw.polygon(surface, color, pts)
    pygame.draw.polygon(surface, (255, 255, 255), pts, 2)


def _draw_item(surface: pygame.Surface, cx: int, cy: int, item_type: str) -> None:
    r = 8
    if item_type == "gem":
        pts = [(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)]
        pygame.draw.polygon(surface, C_ITEM_GEM, pts)
    elif item_type == "star":
        pygame.draw.circle(surface, C_ITEM_STAR, (cx, cy), r)
        pygame.draw.circle(surface, (200, 170, 30), (cx, cy), r, 2)
    elif item_type == "crystal":
        pts = [(cx, cy - r), (cx + r // 2, cy), (cx, cy + r), (cx - r // 2, cy)]
        pygame.draw.polygon(surface, (180, 100, 255), pts)
    else:  # coin
        pygame.draw.circle(surface, (255, 200, 50), (cx, cy), r - 1)
        pygame.draw.circle(surface, (200, 150, 20), (cx, cy), r - 1, 2)


def render(screen: pygame.Surface, sim: RobotSim, font: pygame.font.Font) -> None:
    screen.fill(C_BG)

    obstacle_set = sim.obstacles
    revealed_set = sim.revealed

    # Draw grid
    for y in range(ROWS):
        for x in range(COLS):
            rect = pygame.Rect(x * CELL, y * CELL + HUD_H, CELL, CELL)
            if (x, y) not in revealed_set:
                pygame.draw.rect(screen, C_FOG, rect)
            elif (x, y) in obstacle_set:
                pygame.draw.rect(screen, C_WALL, rect)
            else:
                pygame.draw.rect(screen, C_FLOOR, rect)
            pygame.draw.rect(screen, C_GRID, rect, 1)

    # Draw trail
    for tx, ty in sim.trail[-50:]:
        cx, cy = tx * CELL + CELL // 2, ty * CELL + CELL // 2 + HUD_H
        pygame.draw.circle(screen, C_TRAIL, (cx, cy), 4)

    # Draw items
    for item in sim.items:
        if (item["x"], item["y"]) in revealed_set:
            cx = item["x"] * CELL + CELL // 2
            cy = item["y"] * CELL + CELL // 2 + HUD_H
            _draw_item(screen, cx, cy, item["type"])

    # Draw robot
    rcx = sim.robot_x * CELL + CELL // 2
    rcy = sim.robot_y * CELL + CELL // 2 + HUD_H
    _draw_arrow(screen, rcx, rcy, sim.heading, CELL - 8, C_ROBOT)

    # HUD
    pygame.draw.rect(screen, C_HUD_BG, (0, 0, WIDTH, HUD_H))

    # Battery bar
    bw = 120
    bh = 16
    bx, by = 10, 8
    bat_pct = max(0, sim.battery) / 100
    pygame.draw.rect(screen, (60, 60, 70), (bx, by, bw, bh))
    bar_color = C_BATTERY if sim.battery > 20 else C_BATTERY_LOW
    pygame.draw.rect(screen, bar_color, (bx, by, int(bw * bat_pct), bh))
    pygame.draw.rect(screen, C_HUD_TXT, (bx, by, bw, bh), 1)
    bat_txt = font.render(f"Battery: {sim.battery}%", True, C_HUD_TXT)
    screen.blit(bat_txt, (bx + bw + 8, by - 1))

    # Score and info
    info = font.render(
        f"Score: {sim.score}  |  Steps: {sim.steps}  |  Items: {len(sim.items)}  |  "
        f"Inv: {len(sim.inventory)}  |  Pos: ({sim.robot_x},{sim.robot_y}) {sim.heading}  |  Speed: {sim.speed}",
        True, C_HUD_TXT,
    )
    screen.blit(info, (10, 30))

    # Message bar
    msg = font.render(sim.message[:80], True, (180, 180, 190))
    screen.blit(msg, (10, HUD_H + ROWS * CELL + 2))


# ── Main ──────────────────────────────────────────────────────

def main() -> None:
    global _SIM

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT + 20))
    pygame.display.set_caption("OmniLink Robot Demo")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("consolas", 14)

    _SIM = RobotSim()

    # Start HTTP server
    http_thread = threading.Thread(target=_start_http, args=(PORT,), daemon=True)
    http_thread.start()
    print(f"[robot-sim] HTTP server on http://127.0.0.1:{PORT}")
    print(f"[robot-sim] Grid: {COLS}x{ROWS}, obstacles: {len(_SIM.obstacles)}, items: {len(_SIM.items)}")

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        render(screen, _SIM, font)
        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
