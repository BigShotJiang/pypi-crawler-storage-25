"""Robot demo -- 2D grid-world mobile robot with 10 commands and 10 tools."""
