"""Robot AI engine -- 10 commands and 10 tools for the grid-world robot.

Commands (processed by OmniLinkEngine):
  move_forward, move_backward, turn_left, turn_right, scan_area,
  pick_up, drop_item, report_status, set_speed_to_[speed], go_to_[x]_[y]

Tools (pure functions on state dict):
  get_position, get_battery, get_inventory, get_obstacles, get_items,
  calculate_distance, find_path, check_collision, get_map_info,
  analyze_surroundings
"""

from __future__ import annotations

import heapq
import math
from typing import Any

from omnilink import OmniLinkEngine

from .robot_api import send_action

# ── Command templates ─────────────────────────────────────────

COMMAND_TEMPLATES = [
    "move_forward",
    "move_backward",
    "turn_left",
    "turn_right",
    "scan_area",
    "pick_up",
    "drop_item",
    "report_status",
    "set_speed_to_[speed:int]",
    "go_to_[x:int]_[y:int]",
]

# ── Tool definitions (for platform profile) ───────────────────

TOOL_DEFS = [
    {"name": "get_position", "description": "Returns robot x, y, heading."},
    {"name": "get_battery", "description": "Returns battery level 0-100."},
    {"name": "get_inventory", "description": "Returns list of carried items."},
    {"name": "get_obstacles", "description": "Returns obstacle positions within 5 tiles."},
    {"name": "get_items", "description": "Returns collectible item positions within 5 tiles."},
    {"name": "calculate_distance", "description": "Manhattan distance to target. Args: x, y."},
    {"name": "find_path", "description": "A* path to target. Args: x, y. Returns step list."},
    {"name": "check_collision", "description": "Check if moving forward is safe. Returns bool."},
    {"name": "get_map_info", "description": "Map dimensions, obstacle count, item count."},
    {"name": "analyze_surroundings", "description": "What is in each adjacent tile (N/S/E/W)."},
]


# ── Tool implementations (pure functions on state) ────────────

DX = {"N": 0, "E": 1, "S": 0, "W": -1}
DY = {"N": -1, "E": 0, "S": 1, "W": 0}
HEADINGS = ["N", "E", "S", "W"]


def get_position(state: dict[str, Any]) -> dict[str, Any]:
    r = state["robot"]
    return {"x": r["x"], "y": r["y"], "heading": r["heading"]}


def get_battery(state: dict[str, Any]) -> dict[str, Any]:
    return {"battery": state["battery"], "critical": state["battery"] < 15}


def get_inventory(state: dict[str, Any]) -> dict[str, Any]:
    return {"inventory": state["inventory"], "count": len(state["inventory"])}


def get_obstacles(state: dict[str, Any]) -> dict[str, Any]:
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    nearby = [
        o for o in state["obstacles"]
        if abs(o[0] - rx) <= 5 and abs(o[1] - ry) <= 5
    ]
    return {"obstacles": nearby, "count": len(nearby)}


def get_items(state: dict[str, Any]) -> dict[str, Any]:
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    nearby = [
        item for item in state["items"]
        if abs(item["x"] - rx) <= 5 and abs(item["y"] - ry) <= 5
    ]
    return {"items": nearby, "count": len(nearby)}


def calculate_distance(state: dict[str, Any], x: int, y: int) -> dict[str, Any]:
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    manhattan = abs(rx - x) + abs(ry - y)
    euclidean = math.sqrt((rx - x) ** 2 + (ry - y) ** 2)
    return {"manhattan": manhattan, "euclidean": round(euclidean, 2)}


def find_path(state: dict[str, Any], target_x: int, target_y: int) -> dict[str, Any]:
    """A* pathfinding from robot to target."""
    w, h = state["grid_width"], state["grid_height"]
    obstacles = {(o[0], o[1]) for o in state["obstacles"]}
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    start = (rx, ry)
    goal = (target_x, target_y)

    if goal in obstacles or not (0 <= target_x < w and 0 <= target_y < h):
        return {"path": [], "steps": 0, "reachable": False}

    open_set: list[tuple[float, tuple[int, int]]] = [(0, start)]
    came_from: dict[tuple[int, int], tuple[int, int]] = {}
    g_score: dict[tuple[int, int], float] = {start: 0}

    while open_set:
        _, current = heapq.heappop(open_set)
        if current == goal:
            path = []
            while current in came_from:
                path.append(list(current))
                current = came_from[current]
            path.reverse()
            return {"path": path, "steps": len(path), "reachable": True}

        cx, cy = current
        for ddx, ddy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            nx, ny = cx + ddx, cy + ddy
            if not (0 <= nx < w and 0 <= ny < h):
                continue
            if (nx, ny) in obstacles:
                continue
            tentative = g_score[current] + 1
            if tentative < g_score.get((nx, ny), float("inf")):
                came_from[(nx, ny)] = current
                g_score[(nx, ny)] = tentative
                f = tentative + abs(nx - target_x) + abs(ny - target_y)
                heapq.heappush(open_set, (f, (nx, ny)))

    return {"path": [], "steps": 0, "reachable": False}


def check_collision(state: dict[str, Any]) -> dict[str, Any]:
    r = state["robot"]
    heading = r["heading"]
    nx = r["x"] + DX[heading]
    ny = r["y"] + DY[heading]
    w, h = state["grid_width"], state["grid_height"]
    obstacles = {(o[0], o[1]) for o in state["obstacles"]}

    if not (0 <= nx < w and 0 <= ny < h):
        return {"safe": False, "reason": "boundary", "target": [nx, ny]}
    if (nx, ny) in obstacles:
        return {"safe": False, "reason": "obstacle", "target": [nx, ny]}
    return {"safe": True, "target": [nx, ny]}


def get_map_info(state: dict[str, Any]) -> dict[str, Any]:
    w, h = state["grid_width"], state["grid_height"]
    return {
        "width": w,
        "height": h,
        "total_cells": w * h,
        "obstacle_count": len(state["obstacles"]),
        "item_count": len(state["items"]),
        "revealed_count": len(state["revealed"]),
        "walkable": w * h - len(state["obstacles"]),
    }


def analyze_surroundings(state: dict[str, Any]) -> dict[str, Any]:
    r = state["robot"]
    rx, ry = r["x"], r["y"]
    w, h = state["grid_width"], state["grid_height"]
    obstacles = {(o[0], o[1]) for o in state["obstacles"]}
    item_positions = {(it["x"], it["y"]): it["type"] for it in state["items"]}

    result: dict[str, Any] = {}
    for heading in HEADINGS:
        nx, ny = rx + DX[heading], ry + DY[heading]
        if not (0 <= nx < w and 0 <= ny < h):
            result[heading] = "boundary"
        elif (nx, ny) in obstacles:
            result[heading] = "obstacle"
        elif (nx, ny) in item_positions:
            result[heading] = f"item:{item_positions[(nx, ny)]}"
        else:
            result[heading] = "empty"

    standing_on = item_positions.get((rx, ry))
    if standing_on:
        result["here"] = f"item:{standing_on}"
    else:
        result["here"] = "empty"
    return result


TOOLS = {
    "get_position": get_position,
    "get_battery": get_battery,
    "get_inventory": get_inventory,
    "get_obstacles": get_obstacles,
    "get_items": get_items,
    "calculate_distance": calculate_distance,
    "find_path": find_path,
    "check_collision": check_collision,
    "get_map_info": get_map_info,
    "analyze_surroundings": analyze_surroundings,
}


def execute_tool(name: str, state: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
    """Execute a tool by name. Returns the tool's result dict."""
    fn = TOOLS.get(name)
    if fn is None:
        return {"error": f"Unknown tool: {name}"}
    if kwargs:
        return fn(state, **kwargs)
    return fn(state)


# ── Engine builder (10 commands) ──────────────────────────────

def build_engine() -> OmniLinkEngine:
    """Build an OmniLinkEngine with 10 robot command templates."""
    engine = OmniLinkEngine(COMMAND_TEMPLATES)

    def _simple(action_name: str):
        def handler(evt):
            msg = send_action(action_name)
            return {"action": action_name, "message": msg}
        return handler

    for cmd in ["move_forward", "move_backward", "turn_left", "turn_right",
                "scan_area", "pick_up", "drop_item", "report_status"]:
        engine.on_template(cmd, _simple(cmd))

    def handle_set_speed(evt):
        speed = evt["vars"]["speed"]
        msg = send_action("set_speed", speed=speed)
        return {"action": "set_speed", "speed": speed, "message": msg}

    def handle_go_to(evt):
        x, y = evt["vars"]["x"], evt["vars"]["y"]
        msg = send_action("go_to", x=x, y=y)
        return {"action": "go_to", "x": x, "y": y, "message": msg}

    engine.on_template("set_speed_to_[speed:int]", handle_set_speed)
    engine.on_template("go_to_[x:int]_[y:int]", handle_go_to)

    return engine


# ── AI decision logic ─────────────────────────────────────────

def decide_action(state: dict[str, Any]) -> str:
    """Decide the next action for the robot. Called by ToolRunner."""
    battery = state.get("battery", 0)
    if battery <= 5:
        return "report_status"

    # Standing on an item? Pick it up
    rx, ry = state["robot"]["x"], state["robot"]["y"]
    for item in state.get("items", []):
        if item["x"] == rx and item["y"] == ry:
            return "pick_up"

    # Find nearest item and navigate toward it
    items = state.get("items", [])
    if items:
        nearest = min(items, key=lambda it: abs(it["x"] - rx) + abs(it["y"] - ry))
        path_result = find_path(state, nearest["x"], nearest["y"])
        if path_result["reachable"] and path_result["path"]:
            next_step = path_result["path"][0]
            nx, ny = next_step[0], next_step[1]
            dx, dy = nx - rx, ny - ry

            # Determine needed heading
            if dx > 0:
                needed = "E"
            elif dx < 0:
                needed = "W"
            elif dy > 0:
                needed = "S"
            else:
                needed = "N"

            if state["robot"]["heading"] != needed:
                # Turn toward target
                current_idx = HEADINGS.index(state["robot"]["heading"])
                needed_idx = HEADINGS.index(needed)
                diff = (needed_idx - current_idx) % 4
                return "turn_right" if diff <= 2 else "turn_left"
            else:
                collision = check_collision(state)
                if collision["safe"]:
                    return "move_forward"
                else:
                    return "turn_right"

    # No items found -- scan for more
    if len(state.get("revealed", [])) < state["grid_width"] * state["grid_height"] * 0.5:
        return "scan_area"

    # Explore: move forward if safe, else turn
    collision = check_collision(state)
    if collision["safe"]:
        return "move_forward"
    return "turn_right"


def state_summary(state: dict[str, Any]) -> str:
    """Concise text summary for OmniLink memory."""
    r = state.get("robot", {})
    return (
        f"Robot at ({r.get('x',0)},{r.get('y',0)}) facing {r.get('heading','?')} | "
        f"Battery: {state.get('battery',0)}% | "
        f"Score: {state.get('score',0)} | Steps: {state.get('steps_taken',0)} | "
        f"Inventory: {state.get('inventory',[])} | "
        f"Items remaining: {state.get('items_remaining',0)}"
    )
