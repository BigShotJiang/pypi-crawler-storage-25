#!/usr/bin/env python3
"""Bridge between the OmniLink UI and the local robot simulation.

This script polls the platform for user messages, translates them into
commands via the cloud AI, executes them on the local Pygame simulation,
and writes the results back so they appear in the UI conversation.

Start the simulation first:
    python -m omnilink.examples.robot_demo.robot_sim

Then run this bridge:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.robot_bridge

Then open https://www.omnilink-agents.com, select **robot-demo**, and
type commands like "move forward", "scan area", or "go to 10 5".
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from typing import Any, Dict, List, Optional

from omnilink.client import OmniLinkClient

from .robot_api import get_state, send_action, call_tool
from .robot_engine import (
    COMMAND_TEMPLATES,
    TOOL_DEFS,
    build_engine,
    execute_tool,
    state_summary,
)

AGENT_NAME = "robot-demo"
POLL_INTERVAL = 2.0

SYSTEM_INSTRUCTION = {
    "mainTask": (
        "You control a mobile robot on a 20x15 grid. "
        "Your ONLY job is to translate user requests into commands or tool calls.\n\n"
        "COMMANDS (output as: Command: <exact_command>):\n"
        "  move_forward, move_backward, turn_left, turn_right,\n"
        "  scan_area, pick_up, drop_item, report_status,\n"
        "  set_speed_to_<N>  (e.g. set_speed_to_3),\n"
        "  go_to_<X>_<Y>    (e.g. go_to_10_5)\n\n"
        "TOOLS (output as: Tool: <name> then Tool-Args: {json}):\n"
        "  get_position, get_battery, get_inventory, get_obstacles,\n"
        "  get_items, calculate_distance, find_path, check_collision,\n"
        "  get_map_info, analyze_surroundings\n\n"
        "Tool args examples:\n"
        '  Tool: calculate_distance  Tool-Args: {"x": 10, "y": 7}\n'
        '  Tool: find_path           Tool-Args: {"target_x": 5, "target_y": 3}\n\n'
        "RULES:\n"
        "- ALWAYS output Command: or Tool: on its own line\n"
        "- NEVER ask clarifying questions\n"
        "- For movement commands, just output the command directly\n"
        "- For queries about state, use the appropriate tool"
    ),
    "availableCommands": ", ".join(COMMAND_TEMPLATES),
    "availableTools": ", ".join(t["name"] for t in TOOL_DEFS),
    "availableToolDetails": TOOL_DEFS,
    "allowToolUse": True,
}


def _ensure_profile(client: OmniLinkClient) -> str:
    profiles = client.list_profiles()
    existing = next((p for p in profiles if p["name"] == AGENT_NAME), None)
    if existing:
        client.update_profile(existing["id"], name=AGENT_NAME, settings=SYSTEM_INSTRUCTION)
        return existing["id"]
    r = client.create_profile(AGENT_NAME, settings=SYSTEM_INSTRUCTION)
    return r["id"]


def _extract_command(text: str) -> Optional[str]:
    m = re.search(r"Command:\s*(.+)", text)
    if m:
        cmd = m.group(1).strip()
        # Clean: take only up to the first delimiter that isn't part of a command
        # Commands look like: move_forward, set_speed_to_3, go_to_5_3
        cmd = re.split(r"\s*[=>\|,;]+\s*", cmd)[0].strip()
        if cmd.lower() != "none":
            return cmd
    return None


def _extract_tool(text: str) -> Optional[tuple[str, dict]]:
    tool_m = re.search(r"Tool:\s*(\w+)", text)
    if not tool_m:
        return None
    tool_name = tool_m.group(1)
    args: dict[str, Any] = {}
    args_m = re.search(r"Tool-Args:\s*(\{[^}]+\})", text)
    if args_m:
        try:
            args = json.loads(args_m.group(1))
        except json.JSONDecodeError:
            pass
    return tool_name, args


def _process_user_message(
    client: OmniLinkClient,
    engine: Any,
    user_msg: str,
) -> str:
    """Send user message to platform AI, execute result on local sim."""

    # Ask the AI to translate to a command or tool
    resp = client.chat(
        prompt=user_msg,
        agent_name=AGENT_NAME,
        system_instruction=SYSTEM_INSTRUCTION,
        temperature=0.1,
    )
    ai_text = resp.get("text", "")

    # Try command first
    cmd = _extract_command(ai_text)
    if cmd:
        result = engine.handle(cmd)
        if result.get("ok"):
            res = result.get("result", {})
            msg = res.get("message", str(res)) if isinstance(res, dict) else str(res)
            return f"[Executed] {cmd}\n{msg}"
        else:
            # Engine didn't match -- try as direct action on sim
            msg = send_action(cmd)
            return f"[Executed] {cmd}\n{msg}" if msg else f"[Executed] {cmd}"

    # Try tool — execute via HTTP on the sim server
    tool_info = _extract_tool(ai_text)
    if tool_info:
        tool_name, tool_args = tool_info
        result = call_tool(tool_name, **tool_args)
        return f"[Tool: {tool_name}]\n{json.dumps(result, indent=2)}"

    # Fallback: try the raw user message as a command
    normalized = user_msg.strip().lower().replace(" ", "_")
    result = engine.handle(normalized)
    if result.get("ok"):
        res = result.get("result", {})
        msg = res.get("message", str(res)) if isinstance(res, dict) else str(res)
        return f"[Executed] {normalized}\n{msg}"

    # Nothing matched -- return AI's raw response
    lines = [l for l in ai_text.split("\n") if not l.startswith("Command:")]
    return " ".join(lines).strip()[:300] or "I didn't understand that command."


def _get_latest_user_message(memory: list) -> Optional[str]:
    """Extract the most recent user message from memory."""
    for msg in reversed(memory):
        if isinstance(msg, dict) and msg.get("role") == "user":
            parts = msg.get("parts", [])
            if parts and isinstance(parts[0], dict):
                return parts[0].get("text", "")
    return None


def main() -> None:
    omni_key = os.environ.get("OMNI_KEY", "")
    if not omni_key:
        print("Error: Set OMNI_KEY environment variable.")
        sys.exit(1)

    client = OmniLinkClient(omni_key=omni_key)
    engine = build_engine()

    profile_id = _ensure_profile(client)

    print("=" * 55)
    print("  OmniLink Robot Bridge")
    print("=" * 55)
    print(f"  Agent:      {AGENT_NAME}")
    print(f"  Profile:    {profile_id[:8]}...")
    print(f"  Sim server: http://127.0.0.1:5050")
    print(f"  Commands:   {len(COMMAND_TEMPLATES)}")
    print(f"  Tools:      {len(TOOL_DEFS)}")
    print()

    # Verify sim is running
    try:
        state = get_state()
        r = state["robot"]
        print(f"  Sim OK: robot at ({r['x']},{r['y']}) facing {r['heading']}, battery={state['battery']}%")
    except Exception as e:
        print(f"  ERROR: Cannot reach simulation at http://127.0.0.1:5050")
        print(f"  Start it first: python -m omnilink.examples.robot_demo.robot_sim")
        sys.exit(1)

    # Clear stale memory
    client.clear_memory(AGENT_NAME)

    print()
    print("  Bridge active. Waiting for UI messages...")
    print("  Chat at: https://www.omnilink-agents.com")
    print(f'  Select "{AGENT_NAME}" and type commands.')
    print("  Press Ctrl+C to stop.")
    print()

    last_user_msg = None
    last_memory_len = 0

    try:
        while True:
            time.sleep(POLL_INTERVAL)

            try:
                memory = client.get_memory(AGENT_NAME)
            except Exception:
                continue

            if not memory or not isinstance(memory, list):
                continue

            # Detect new messages by checking length change
            if len(memory) <= last_memory_len:
                continue

            user_msg = _get_latest_user_message(memory)
            if not user_msg or user_msg == last_user_msg:
                last_memory_len = len(memory)
                continue

            last_user_msg = user_msg
            print(f"  >> User: {user_msg}")

            # Process and execute
            reply = _process_user_message(client, engine, user_msg)
            print(f"     Reply: {reply[:120]}")

            # Write result back to memory (append to existing conversation)
            memory.append({"role": "model", "parts": [{"text": reply}]})
            client.set_memory(AGENT_NAME, memory)
            last_memory_len = len(memory)
            print()

    except KeyboardInterrupt:
        print("\n  Bridge stopped.")


if __name__ == "__main__":
    main()
