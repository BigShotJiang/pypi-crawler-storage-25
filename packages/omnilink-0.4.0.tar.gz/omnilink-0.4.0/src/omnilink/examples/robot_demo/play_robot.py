"""Play the Robot Demo using OmniLink tool calling.

The agent calls ``make_move`` to trigger the local AI controller.
The controller navigates the grid, collects items, and manages
battery -- all with one API credit.

When running, the agent also monitors the platform memory for commands
and tool calls sent from the UI.  If a user types "move forward" in
the OmniLink chat, the platform AI translates it to ``Command: move_forward``
and the runner picks it up, executes it on the sim, and writes the
result back so it appears in the UI conversation.

Start the simulation first:
    python -m omnilink.examples.robot_demo.robot_sim

Then run the agent:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.play_robot
"""

from __future__ import annotations

import json
import re
import time
from typing import Any

from omnilink.tool_runner import ToolRunner
from omnilink.client import OmniLinkClient

from .robot_api import get_state, send_action, call_tool, SERVER_URL
from .robot_engine import (
    COMMAND_TEMPLATES,
    TOOL_DEFS,
    build_engine,
    decide_action,
    execute_tool,
    state_summary,
)


class RobotRunner(ToolRunner):
    agent_name = "robot-demo"
    display_name = "Robot Demo"
    tool_description = "Run the robot AI to navigate, collect items, and manage battery."
    game_server_url = SERVER_URL
    poll_interval = 0.3
    memory_every = 5
    ask_every = 600

    def __init__(self) -> None:
        self._last_score = 0
        self._last_battery = 100
        self._engine = build_engine()
        self._last_processed_len = 0

    def get_state(self) -> dict[str, Any]:
        return get_state()

    def execute_action(self, state: dict[str, Any]) -> None:
        if state.get("game_state") != "PLAY":
            return
        action = decide_action(state)
        send_action(action)

    def state_summary(self, state: dict[str, Any]) -> str:
        return state_summary(state)

    def is_game_over(self, state: dict[str, Any]) -> bool:
        if state.get("game_state") == "GAMEOVER":
            return True
        if state.get("battery", 0) <= 0:
            return True
        if state.get("items_remaining", 1) == 0:
            return True
        return False

    def game_over_message(self, state: dict[str, Any]) -> str:
        score = state.get("score", 0)
        steps = state.get("steps_taken", 0)
        inv = len(state.get("inventory", []))
        remaining = state.get("items_remaining", 0)
        if remaining == 0:
            return f"All items collected! Score: {score}, Steps: {steps}, Inventory: {inv}"
        return f"Game over. Score: {score}, Steps: {steps}, Items collected: {inv}, Remaining: {remaining}"

    def on_start(self) -> None:
        try:
            send_action("START")
            time.sleep(0.3)
            print("  Robot simulation started.")
        except Exception:
            pass
        # Sync _last_processed_len with current memory so we only
        # process entries that arrive AFTER this point.
        try:
            client = self._client
            mem = client.get_memory(self._memory_agent_key())
            self._last_processed_len = len(mem) if isinstance(mem, list) else 0
        except Exception:
            self._last_processed_len = 0

    def log_events(self, state: dict[str, Any]) -> None:
        score = state.get("score", 0)
        battery = state.get("battery", 100)

        if score != self._last_score:
            print(f"  Score: {score}  (+{score - self._last_score})")
            self._last_score = score
        if battery < self._last_battery and battery % 10 == 0:
            print(f"  Battery: {battery}%")
        if battery <= 15 and self._last_battery > 15:
            print(f"  ** Battery critical: {battery}%!")
        self._last_battery = battery

    def _save_memory(self, client: OmniLinkClient, summary: str) -> None:
        """Override: merge with existing memory instead of replacing it.

        The base ToolRunner replaces memory entirely with its own history,
        which wipes out UI messages.  We read first, scan for unexecuted
        tool/command calls from the UI, execute them, then append our
        state update and write back.
        """
        try:
            memory = client.get_memory(self._memory_agent_key())
            if not isinstance(memory, list):
                memory = []
        except Exception:
            memory = []

        # Scan ALL model entries for unexecuted tool/command calls.
        # An entry needs execution if it contains Tool: or Command:
        # and the NEXT entry is NOT a [Tool:] or [Executed] result.
        appended = False
        for i, entry in enumerate(memory):
            if entry.get("role") != "model":
                continue
            text = ""
            for part in entry.get("parts", []):
                text = part.get("text", "")
            if not text:
                continue
            # Skip entries that are already results
            if text.startswith("[Executed]") or text.startswith("[Tool:"):
                continue
            # Skip entries that already have a result after them
            if i + 1 < len(memory):
                next_text = ""
                for part in memory[i + 1].get("parts", []):
                    next_text = part.get("text", "")
                if next_text.startswith("[Executed]") or next_text.startswith("[Tool:"):
                    continue

            # Check if this entry has a tool or command to execute
            result_text = self._try_execute_from_ai_text(text)
            if result_text:
                # Insert result right after this entry
                memory.insert(i + 1, {"role": "model", "parts": [{"text": result_text}]})
                appended = True

        # Append our state summary
        memory.append({"role": "user", "parts": [{"text": "Report current state."}]})
        memory.append({"role": "model", "parts": [{"text": f"Command: none\nResponse: {summary}"}]})

        # Trim to avoid exceeding payload limits (keep last 30 entries)
        if len(memory) > 30:
            memory = memory[-30:]

        try:
            client.set_memory(self._memory_agent_key(), memory)
        except Exception:
            pass

    def get_system_instruction(self) -> dict[str, Any]:
        return {
            "mainTask": (
                f"You control a mobile robot on a grid world. "
                f"Call {self.tool_name} to run the AI controller. "
                f"You can also call individual tools to inspect state. "
                f"Commands: {', '.join(COMMAND_TEMPLATES)}. "
                f"The robot collects items, avoids obstacles, and manages battery. "
                f"For tool queries, output Tool: <name> and Tool-Args: {{json}}."
            ),
            "availableTools": ", ".join([self.tool_name] + [t["name"] for t in TOOL_DEFS]),
            "availableToolDetails": [
                {"name": self.tool_name, "description": self.tool_description},
            ] + TOOL_DEFS,
            "availableCommands": self.commands + ", " + ", ".join(COMMAND_TEMPLATES),
            "allowToolUse": True,
        }

    # ── UI command/tool execution ──────────────────────────────

    def _check_memory_command(self, client: OmniLinkClient) -> str | None:
        """Override: check memory for UI commands/tools AND the standard stop/pause/resume."""
        try:
            memory = client.get_memory(self._memory_agent_key())
            if not memory or not isinstance(memory, list):
                return None

            # Check standard commands first
            for entry in memory:
                for part in entry.get("parts", []):
                    text = part.get("text", "")
                    if re.search(r"(?i)Command:\s*stop_game", text):
                        return "stop_game"
                    if re.search(r"(?i)Command:\s*pause_game", text):
                        return "pause_game"
                    if re.search(r"(?i)Command:\s*resume_game", text):
                        return "resume_game"

            # Check for new AI responses that contain Command: or Tool: lines
            # from UI chat (these are model messages added by the platform)
            if len(memory) <= self._last_processed_len:
                return None

            # Process new entries
            new_entries = memory[self._last_processed_len:]
            self._last_processed_len = len(memory)

            for entry in new_entries:
                role = entry.get("role", "")
                if role != "model":
                    continue
                for part in entry.get("parts", []):
                    text = part.get("text", "")
                    if not text:
                        continue

                    # Skip entries we already wrote (they start with [Executed] or [Tool:)
                    if text.startswith("[Executed]") or text.startswith("[Tool:"):
                        continue

                    result_text = self._try_execute_from_ai_text(text)
                    if result_text:
                        # Append result to memory so it shows in the UI
                        memory.append({"role": "model", "parts": [{"text": result_text}]})
                        try:
                            client.set_memory(self._memory_agent_key(), memory)
                            self._last_processed_len = len(memory)
                        except Exception:
                            pass

            return None
        except Exception:
            return None

    def _try_execute_from_ai_text(self, ai_text: str) -> str | None:
        """Parse Command: or Tool: from AI text and execute on sim.

        The AI often outputs both ``Command: none`` and ``Tool: get_position``
        in the same response.  We check tools FIRST so they don't get
        skipped when the command is "none".
        """

        # Try tool FIRST (AI often outputs Command: none + Tool: xxx)
        tool_m = re.search(r"Tool:\s*(\w+)", ai_text)
        if tool_m:
            tool_name = tool_m.group(1)
            # Skip our own tool name (make_move) — that's the autonomous loop
            if tool_name != self.tool_name:
                tool_args: dict[str, Any] = {}
                args_m = re.search(r"Tool-Args:\s*(\{[^}]+\})", ai_text)
                if args_m:
                    try:
                        tool_args = json.loads(args_m.group(1))
                    except json.JSONDecodeError:
                        pass
                try:
                    tool_result = call_tool(tool_name, **tool_args)
                except Exception:
                    state = get_state()
                    tool_result = execute_tool(tool_name, state, **tool_args)
                print(f"  >> UI tool: {tool_name}({tool_args}) -> {json.dumps(tool_result)[:80]}")
                return f"[Tool: {tool_name}]\n{json.dumps(tool_result, indent=2)}"

        # Then try command
        cmd_m = re.search(r"Command:\s*(.+)", ai_text)
        if cmd_m:
            cmd = re.split(r"\s*[=>|,;]+\s*", cmd_m.group(1).strip())[0].strip()
            if cmd.lower() not in ("none", "stop_game", "pause_game", "resume_game"):
                result = self._engine.handle(cmd)
                if result.get("ok"):
                    res = result.get("result", {})
                    msg = res.get("message", str(res)) if isinstance(res, dict) else str(res)
                    print(f"  >> UI command: {cmd} -> {msg}")
                    return f"[Executed] {cmd}\n{msg}"
                else:
                    msg = send_action(cmd)
                    if msg:
                        print(f"  >> UI action: {cmd} -> {msg}")
                        return f"[Executed] {cmd}\n{msg}"

        return None


if __name__ == "__main__":
    RobotRunner().run()
