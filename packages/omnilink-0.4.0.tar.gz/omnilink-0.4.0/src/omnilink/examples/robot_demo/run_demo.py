#!/usr/bin/env python3
"""Run the robot demo in UI-controlled mode.

The robot does NOTHING on its own. It only moves when YOU type
commands in the OmniLink UI. This script:

1. Starts the Pygame simulation (headless if no display)
2. Polls the platform memory for your messages
3. Executes commands and tools from the AI responses
4. Writes results back so they appear in the UI

Usage:
    OMNI_KEY="olink_..." python -m omnilink.examples.robot_demo.run_demo
"""

from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
from pathlib import Path
from typing import Any

from omnilink.client import OmniLinkClient

from .robot_api import get_state, send_action, call_tool, SERVER_URL
from .robot_engine import (
    COMMAND_TEMPLATES,
    TOOL_DEFS,
    build_engine,
    execute_tool,
)

AGENT_NAME = "robot-demo"
POLL_INTERVAL = 3
LOG_DIR = Path(__file__).parent / "logs"


def _init_log() -> Path:
    """Create a timestamped conversation log file."""
    LOG_DIR.mkdir(exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    path = LOG_DIR / f"conversation_{ts}.jsonl"
    path.touch()
    return path


def _log_entry(log_path: Path, role: str, text: str, meta: dict[str, Any] | None = None) -> None:
    """Append a conversation entry to the log file."""
    entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "role": role,
        "text": text,
    }
    if meta:
        entry["meta"] = meta
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def _start_headless_sim(port: int = 5050) -> None:
    """Start the sim HTTP server without a Pygame window."""
    import os as _os
    _os.environ["SDL_VIDEODRIVER"] = "dummy"
    _os.environ["SDL_AUDIODRIVER"] = "dummy"

    from . import robot_sim as sim_mod
    from .robot_sim import RobotSim, Handler
    import http.server as _hs

    sim = RobotSim()
    sim_mod._SIM = sim
    server = _hs.ThreadingHTTPServer(("0.0.0.0", port), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()


def _build_state_context() -> str:
    """Build a live state context string from the simulation."""
    try:
        s = get_state()
        r = s["robot"]
        items = s.get("items", [])
        inv = s.get("inventory", [])
        nearby = [
            f"({it['x']},{it['y']}) {it['type']}"
            for it in items
            if abs(it["x"] - r["x"]) <= 5 and abs(it["y"] - r["y"]) <= 5
        ]
        return (
            f"LIVE ROBOT STATE:\n"
            f"  Position: ({r['x']},{r['y']}), Heading: {r['heading']}\n"
            f"  Battery: {s.get('battery', '?')}%\n"
            f"  Speed: {s.get('speed', 1)}\n"
            f"  Score: {s.get('score', 0)}, Steps: {s.get('steps_taken', 0)}\n"
            f"  Inventory: {inv if inv else 'empty'}\n"
            f"  Items remaining: {s.get('items_remaining', '?')}\n"
            f"  Nearby items (within 5 tiles): {nearby if nearby else 'none'}\n"
            f"  Grid: {s.get('grid_width', 20)}x{s.get('grid_height', 15)}"
        )
    except Exception:
        return "LIVE ROBOT STATE: unavailable"


def _build_instruction() -> dict[str, Any]:
    tool_names = ", ".join(t["name"] for t in TOOL_DEFS)
    return {
        "mainTask": (
            "You control a mobile robot on a 20x15 grid. "
            "RULES:\n"
            "- Action requests → output Command: line\n"
            "- Info requests (position, battery, inventory, obstacles, "
            "distance, path, etc.) → output Tool: line\n"
        ),
        "agentName": AGENT_NAME,
        "availableCommands": ", ".join(COMMAND_TEMPLATES),
        "availableTools": tool_names,
        "availableToolDetails": TOOL_DEFS,
        "allowToolUse": True,
        "toolCallbackUrl": "http://127.0.0.1:5050/tool",
    }


def _ensure_profile(client: OmniLinkClient) -> str:
    instruction = _build_instruction()
    profiles = client.list_profiles()
    existing = next((p for p in profiles if p["name"] == AGENT_NAME), None)
    if existing:
        client.update_profile(existing["id"], name=AGENT_NAME, settings=instruction)
        return existing["id"]
    r = client.create_profile(AGENT_NAME, settings=instruction)
    return r["id"]


def _execute_ai_response(ai_text: str, engine: Any) -> str | None:
    """Parse an AI response for Tool: or Command: and execute it."""

    # Tools first (AI may output both Command: none and Tool: xxx).
    tool_m = re.search(r"Tool:\s*(\w+)", ai_text)
    if tool_m:
        tool_name = tool_m.group(1)
        tool_args: dict[str, Any] = {}
        args_m = re.search(r"Tool-Args:\s*(\{[^}]+\})", ai_text)
        if args_m:
            try:
                tool_args = json.loads(args_m.group(1))
            except json.JSONDecodeError:
                pass
        try:
            result = call_tool(tool_name, **tool_args)
        except Exception:
            state = get_state()
            result = execute_tool(tool_name, state, **tool_args)
        state_ctx = _build_state_context()
        return f"[Tool-Result] {tool_name}\n{json.dumps(result, indent=2)}\n\n{state_ctx}"

    # Commands — may be a sequence like "move_forward => move_forward => turn_left".
    cmd_m = re.search(r"Command:\s*(.+)", ai_text)
    if not cmd_m:
        return None

    raw = cmd_m.group(1).strip()
    # Strip trailing "Duration: ..." or "Response: ..." the AI sometimes appends.
    raw = re.split(r"\s+(?:Duration|Response):", raw)[0].strip()
    cmds = [c.strip() for c in re.split(r"\s*=>\s*", raw) if c.strip()]

    if not cmds or cmds[0].lower() in ("none", "stop_game", "pause_game", "resume_game"):
        return None

    results: list[str] = []
    for cmd in cmds:
        if cmd.lower() in ("none", "stop_game", "pause_game", "resume_game"):
            break
        try:
            result = engine.handle(cmd)
            if result.get("ok"):
                res = result.get("result", {})
                msg = res.get("message", str(res)) if isinstance(res, dict) else str(res)
            else:
                msg = send_action(cmd)
                if not msg:
                    continue
            results.append(f"{cmd}: {msg}")
        except Exception as exc:
            print(f"     [warn] Command {cmd} failed: {exc}")
            continue
        # Small delay between sequential commands so the sim can process.
        if len(cmds) > 1:
            time.sleep(0.3)

    if not results:
        return None

    state_ctx = _build_state_context()
    summary = "\n".join(results)
    label = " => ".join(cmds)
    return f"[Executed] {label}\n{summary}\n\n{state_ctx}"


def main() -> None:
    omni_key = os.environ.get("OMNI_KEY", "")
    if not omni_key:
        print("Set OMNI_KEY environment variable.")
        sys.exit(1)

    # Connect to running sim, or start headless one if not available.
    try:
        state = get_state()
        r = state["robot"]
        print(f"Sim connected: robot at ({r['x']},{r['y']}) facing {r['heading']}, battery={state['battery']}%")
    except Exception:
        print("No sim running — starting headless sim on port 5050...")
        _start_headless_sim()
        time.sleep(0.5)
        state = get_state()
        r = state["robot"]
        print(f"Sim started: robot at ({r['x']},{r['y']}) facing {r['heading']}, battery={state['battery']}%")

    # Setup platform
    client = OmniLinkClient(omni_key=omni_key)
    profile_id = _ensure_profile(client)
    client.clear_memory(profile_id)
    engine = build_engine()

    print()
    print("=" * 50)
    print("  Robot Demo — UI Controlled")
    print("=" * 50)
    print(f"  Agent: {AGENT_NAME}")
    print(f"  Grid:  {state['grid_width']}x{state['grid_height']}")
    print(f"  Items: {state['items_remaining']}")
    print()
    print("  Go to https://www.omnilink-agents.com")
    print(f"  Select \"{AGENT_NAME}\" and type commands.")
    print("  Ctrl+C to stop.")
    print()

    log_path = _init_log()
    print(f"  Log: {log_path}")
    print()

    processed_indices: set[int] = set()
    logged_indices: set[int] = set()
    sys.stdout.flush()

    try:
        while True:
            sys.stdout.flush()
            time.sleep(POLL_INTERVAL)

            try:
                memory = client.get_memory(profile_id)
            except Exception:
                continue
            if not isinstance(memory, list):
                continue

            # Log all new conversation entries (user + model).
            for i, entry in enumerate(memory):
                if i in logged_indices:
                    continue
                logged_indices.add(i)

                role = entry.get("role", "unknown")
                text = ""
                for part in entry.get("parts", []):
                    text = part.get("text", "")
                if not text:
                    continue

                # Skip entries we inserted ourselves.
                if text.startswith(("[Executed]", "[Tool-Result]")):
                    continue

                if role == "user":
                    print(f"  [user] {text}")
                    _log_entry(log_path, "user", text)
                elif role == "model":
                    # Truncate long responses for console, full in log.
                    display = text.replace("\n", " ")
                    if len(display) > 120:
                        display = display[:117] + "..."
                    print(f"  [agent] {display}")
                    _log_entry(log_path, "agent", text)

            # Scan for unexecuted AI responses.
            changed = False
            for i, entry in enumerate(memory):
                if i in processed_indices:
                    continue
                if entry.get("role") != "model":
                    processed_indices.add(i)
                    continue

                text = ""
                for part in entry.get("parts", []):
                    text = part.get("text", "")
                if not text:
                    processed_indices.add(i)
                    continue

                # Skip results we already wrote.
                if text.startswith(("[Executed]", "[Tool-Result]")):
                    processed_indices.add(i)
                    continue

                # Check if next entry is already a result.
                if i + 1 < len(memory):
                    next_text = memory[i + 1].get("parts", [{}])[0].get("text", "")
                    if next_text.startswith(("[Executed]", "[Tool-Result]")):
                        processed_indices.add(i)
                        continue

                # Try to execute.
                result_text = _execute_ai_response(text, engine)
                processed_indices.add(i)

                if result_text:
                    state = get_state()
                    rob = state["robot"]
                    pos = f"({rob['x']},{rob['y']}) {rob['heading']} bat={state['battery']}%"

                    print(f"  [exec] {result_text.split(chr(10))[0]}  |  {pos}")
                    _log_entry(log_path, "execution", result_text, {"sim_state": pos})

                    memory.insert(i + 1, {"role": "model", "parts": [{"text": result_text}]})
                    logged_indices.add(i + 1)  # Don't re-log the entry we just inserted.
                    changed = True

            if changed:
                if len(memory) > 40:
                    memory = memory[-40:]
                try:
                    client.set_memory(profile_id, memory)
                    processed_indices = set(range(len(memory)))
                    logged_indices = set(range(len(memory)))
                except Exception:
                    pass

    except KeyboardInterrupt:
        print("\nStopped.")
    except Exception as exc:
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
