#!/usr/bin/env python3
"""Self-contained test for the robot demo.

Starts the Pygame simulation, exercises all 10 commands and 10 tools,
and verifies each one produces the expected result. No OMNI_KEY needed.

    python -m omnilink.examples.robot_demo.test_robot
"""

from __future__ import annotations

import json
import sys
import threading
import time
from typing import Any

# Start the sim in-process (headless if possible)
from .robot_sim import RobotSim, _start_http, Handler
import http.server

# We need the sim global for the HTTP handler
import omnilink.examples.robot_demo.robot_sim as sim_module

from .robot_api import get_state, send_action, SERVER_URL
from .robot_engine import (
    COMMAND_TEMPLATES,
    TOOL_DEFS,
    build_engine,
    execute_tool,
    state_summary,
    decide_action,
)


def _start_headless_sim(port: int = 5050) -> RobotSim:
    """Start the sim and HTTP server without Pygame window."""
    robot = RobotSim()
    sim_module._SIM = robot

    server = http.server.ThreadingHTTPServer(("0.0.0.0", port), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    time.sleep(0.3)
    return robot


def _pos(state: dict) -> str:
    r = state["robot"]
    return f"({r['x']},{r['y']}) {r['heading']}"


def main() -> None:
    print("=" * 60)
    print("  Robot Demo — Full Integration Test")
    print("  (headless sim, no Pygame window, no OMNI_KEY)")
    print("=" * 60)
    print()

    sim = _start_headless_sim()
    print(f"  Sim started on {SERVER_URL}")
    print(f"  Grid: {sim.get_state()['grid_width']}x{sim.get_state()['grid_height']}")
    print(f"  Obstacles: {len(sim.obstacles)}, Items: {len(sim.items)}")
    print()

    # ── Test 10 Commands via HTTP ──────────────────────────────
    print("=" * 60)
    print("  PART 1: 10 Commands (via HTTP to sim)")
    print("=" * 60)
    print()

    s = get_state()
    print(f"  Start: {_pos(s)} battery={s['battery']}%")
    print()

    passed = 0
    total = 0

    def test_cmd(label: str, action: str, check_fn, **params: Any) -> bool:
        nonlocal passed, total
        total += 1
        before = get_state()
        msg = send_action(action, **params)
        after = get_state()
        ok = check_fn(before, after, msg)
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        print(f"  {total:2d}. [{status}] {label}")
        print(f"      Action: {action}{(' ' + str(params)) if params else ''}")
        print(f"      Result: {msg}")
        print(f"      State:  {_pos(after)} bat={after['battery']}%")
        print()
        return ok

    # 1. move_forward
    test_cmd(
        "move_forward",
        "move_forward",
        lambda b, a, m: a["robot"]["x"] != b["robot"]["x"] or a["robot"]["y"] != b["robot"]["y"] or "Blocked" in m,
    )

    # 2. move_backward
    test_cmd(
        "move_backward",
        "move_backward",
        lambda b, a, m: "Moved backward" in m or "Blocked" in m,
    )

    # 3. turn_left
    test_cmd(
        "turn_left",
        "turn_left",
        lambda b, a, m: a["robot"]["heading"] != b["robot"]["heading"],
    )

    # 4. turn_right
    test_cmd(
        "turn_right",
        "turn_right",
        lambda b, a, m: a["robot"]["heading"] != b["robot"]["heading"],
    )

    # 5. scan_area
    test_cmd(
        "scan_area",
        "scan_area",
        lambda b, a, m: len(a["revealed"]) >= len(b["revealed"]) and "scanned" in m.lower(),
    )

    # 6. pick_up
    test_cmd(
        "pick_up",
        "pick_up",
        lambda b, a, m: "Picked up" in m or "Nothing" in m,
    )

    # 7. drop_item
    test_cmd(
        "drop_item",
        "drop_item",
        lambda b, a, m: "Dropped" in m or "empty" in m.lower(),
    )

    # 8. report_status
    test_cmd(
        "report_status",
        "report_status",
        lambda b, a, m: "Position:" in m and "Battery:" in m,
    )

    # 9. set_speed
    test_cmd(
        "set_speed_to_3",
        "set_speed",
        lambda b, a, m: a["speed"] == 3 and "Speed set" in m,
        speed=3,
    )

    # 10. go_to
    test_cmd(
        "go_to_5_5",
        "go_to",
        lambda b, a, m: "Moved" in m or "Already" in m or "obstacle" in m.lower() or "out of bounds" in m.lower(),
        x=5,
        y=5,
    )

    print(f"  Commands: {passed}/{total} passed")
    print()

    # ── Test 10 Tools ──────────────────────────────────────────
    print("=" * 60)
    print("  PART 2: 10 Tools (local functions on state)")
    print("=" * 60)
    print()

    state = get_state()
    tool_passed = 0
    tool_total = 0

    def test_tool(name: str, check_fn, **kwargs: Any) -> bool:
        nonlocal tool_passed, tool_total
        tool_total += 1
        result = execute_tool(name, state, **kwargs)
        ok = check_fn(result)
        status = "PASS" if ok else "FAIL"
        if ok:
            tool_passed += 1
        display = json.dumps(result, default=str)
        if len(display) > 100:
            display = display[:100] + "..."
        print(f"  {tool_total:2d}. [{status}] {name}")
        print(f"      Result: {display}")
        print()
        return ok

    # 1. get_position
    test_tool("get_position", lambda r: "x" in r and "y" in r and "heading" in r)

    # 2. get_battery
    test_tool("get_battery", lambda r: "battery" in r and isinstance(r["battery"], int))

    # 3. get_inventory
    test_tool("get_inventory", lambda r: "inventory" in r and "count" in r)

    # 4. get_obstacles
    test_tool("get_obstacles", lambda r: "obstacles" in r and "count" in r)

    # 5. get_items
    test_tool("get_items", lambda r: "items" in r and "count" in r)

    # 6. calculate_distance
    test_tool(
        "calculate_distance",
        lambda r: "manhattan" in r and "euclidean" in r,
        x=10,
        y=7,
    )

    # 7. find_path
    test_tool(
        "find_path",
        lambda r: "reachable" in r and "steps" in r,
        target_x=10,
        target_y=7,
    )

    # 8. check_collision
    test_tool("check_collision", lambda r: "safe" in r and "target" in r)

    # 9. get_map_info
    test_tool(
        "get_map_info",
        lambda r: r.get("width") == 20 and r.get("height") == 15 and "obstacle_count" in r,
    )

    # 10. analyze_surroundings
    test_tool(
        "analyze_surroundings",
        lambda r: "N" in r and "S" in r and "E" in r and "W" in r and "here" in r,
    )

    print(f"  Tools: {tool_passed}/{tool_total} passed")
    print()

    # ── Test OmniLinkEngine command parsing ────────────────────
    print("=" * 60)
    print("  PART 3: OmniLinkEngine command parsing")
    print("=" * 60)
    print()

    engine = build_engine()
    engine_passed = 0
    engine_total = 0

    parse_tests = [
        ("move forward", "move_forward"),
        ("move backward", "move_backward"),
        ("turn left", "turn_left"),
        ("turn right", "turn_right"),
        ("scan area", "scan_area"),
        ("pick up", "pick_up"),
        ("drop item", "drop_item"),
        ("report status", "report_status"),
        ("set speed to 5", "set_speed_to_[speed:int]"),
        ("go to 12 8", "go_to_[x:int]_[y:int]"),
    ]

    for cmd_text, expected_template in parse_tests:
        engine_total += 1
        result = engine.handle(cmd_text)
        matched = result.get("ok", False)
        template = result.get("normalized_template", result.get("template"))
        ok = matched and template == expected_template
        if ok:
            engine_passed += 1
        status = "PASS" if ok else "FAIL"
        extracted_vars = result.get("vars", {})
        print(f"  [{status}] \"{cmd_text}\" -> template={template}, vars={extracted_vars}")

    print()
    print(f"  Engine parsing: {engine_passed}/{engine_total} passed")
    print()

    # ── Test AI decision logic ─────────────────────────────────
    print("=" * 60)
    print("  PART 4: AI decision logic")
    print("=" * 60)
    print()

    state = get_state()
    action = decide_action(state)
    print(f"  State: {_pos(state)}, battery={state['battery']}%, items={state['items_remaining']}")
    print(f"  AI decided: {action}")
    print()

    summary = state_summary(state)
    print(f"  State summary: {summary}")
    print()

    # ── Final summary ──────────────────────────────────────────
    total_all = total + tool_total + engine_total
    passed_all = passed + tool_passed + engine_passed

    print("=" * 60)
    print(f"  RESULTS: {passed_all}/{total_all} passed")
    print("=" * 60)
    print(f"  Commands:     {passed}/{total}")
    print(f"  Tools:        {tool_passed}/{tool_total}")
    print(f"  Engine parse: {engine_passed}/{engine_total}")
    print()

    if passed_all == total_all:
        print("  ALL TESTS PASSED.")
    else:
        print(f"  {total_all - passed_all} FAILURES.")
        sys.exit(1)


if __name__ == "__main__":
    main()
