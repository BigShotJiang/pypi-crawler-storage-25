"""Breakout benchmark — ball trajectory prediction with brick-aware aiming."""
