"""Space Invaders benchmark — lead-shot targeting with direction tracking."""
