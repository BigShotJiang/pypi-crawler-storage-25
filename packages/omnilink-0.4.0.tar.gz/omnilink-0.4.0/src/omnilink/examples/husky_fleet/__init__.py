"""Husky Fleet demo -- multi-robot waypoint navigation with 5 Husky robots."""
