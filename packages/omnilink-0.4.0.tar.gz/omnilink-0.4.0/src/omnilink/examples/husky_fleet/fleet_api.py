"""HTTP client for the Husky fleet simulator."""

from __future__ import annotations

from typing import Any

import requests

SERVER_URL = "http://127.0.0.1:5000"

ROBOT_IDS = ["husky_0", "husky_1", "husky_2", "husky_3", "husky_4"]

# Reuse a persistent session for connection pooling.
_session = requests.Session()


def get_fleet_state() -> dict[str, dict[str, Any]]:
    """Fetch poses for every robot in the fleet.

    Returns a dict keyed by robot_id, each value containing x, y, yaw.
    """
    states: dict[str, dict[str, Any]] = {}
    for rid in ROBOT_IDS:
        r = _session.get(f"{SERVER_URL}/robots/{rid}/pose", timeout=2)
        data = r.json()
        pose = data.get("pose", data)
        states[rid] = {"x": pose["x"], "y": pose["y"], "yaw": pose["yaw"]}
    return states


def get_robot_state(robot_id: str) -> dict[str, Any]:
    """Fetch pose for a single robot."""
    r = _session.get(f"{SERVER_URL}/robots/{robot_id}/pose", timeout=2)
    data = r.json()
    pose = data.get("pose", data)
    return {"x": pose["x"], "y": pose["y"], "yaw": pose["yaw"]}


def drive(robot_id: str, vx: float, wz: float, duration: float | None = None) -> None:
    """Send a raw drive command to a specific robot."""
    payload: dict[str, Any] = {"vx": vx, "wz": wz}
    if duration is not None:
        payload["duration"] = duration
    _session.post(f"{SERVER_URL}/robots/{robot_id}/drive", json=payload, timeout=2)


def stop(robot_id: str) -> None:
    """Stop a specific robot."""
    _session.post(f"{SERVER_URL}/robots/{robot_id}/stop", timeout=2)


def stop_all() -> None:
    """Stop all robots in the fleet."""
    for rid in ROBOT_IDS:
        _session.post(f"{SERVER_URL}/robots/{rid}/stop", timeout=2)


def reset_fleet() -> None:
    """Reset all robots to their initial positions."""
    _session.post(f"{SERVER_URL}/fleet/reset", timeout=2)
