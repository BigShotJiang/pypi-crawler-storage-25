"""Local fleet AI engine -- waypoint navigation for multiple Husky robots.

Each robot gets its own waypoint circuit.  The fleet navigator manages all
five robots independently, computing per-robot steering commands using
the same pure-pursuit controller as the single-husky benchmark.
"""

from __future__ import annotations

import math
from typing import Any

# Navigation constants (same as single-husky).
WAYPOINT_REACH_DIST = 0.3    # metres
MAX_VX = 0.8                 # m/s
MIN_VX = 0.1                 # m/s
MAX_WZ = 1.5                 # rad/s
KP_ANGULAR = 2.0             # proportional gain
HEADING_SLOW_THRESH = 0.4    # rad

# Fleet robot IDs.
ROBOT_IDS = ["husky_0", "husky_1", "husky_2", "husky_3", "husky_4"]

# Starting Y positions (must match husky_fleet.py formation).
_START_Y = {
    "husky_0": -2.0,
    "husky_1": -1.0,
    "husky_2":  0.0,
    "husky_3":  1.0,
    "husky_4":  2.0,
}

# Each robot drives its own square circuit offset by its starting Y.
def _make_waypoints(start_y: float) -> list[tuple[float, float]]:
    """Build a square waypoint circuit around the robot's start position."""
    return [
        ( 3.0, start_y),
        ( 3.0, start_y + 3.0),
        ( 0.0, start_y + 3.0),
        ( 0.0, start_y),
    ]


DEFAULT_FLEET_WAYPOINTS: dict[str, list[tuple[float, float]]] = {
    rid: _make_waypoints(sy) for rid, sy in _START_Y.items()
}


def _normalise_angle(a: float) -> float:
    """Wrap angle to [-pi, pi]."""
    while a > math.pi:
        a -= 2 * math.pi
    while a < -math.pi:
        a += 2 * math.pi
    return a


class RobotNavigator:
    """Waypoint navigator for a single robot within the fleet."""

    def __init__(self, robot_id: str,
                 waypoints: list[tuple[float, float]] | None = None,
                 loop: bool = True) -> None:
        self.robot_id = robot_id
        self.waypoints = list(
            waypoints or DEFAULT_FLEET_WAYPOINTS.get(robot_id, [(2.0, 0.0)])
        )
        self.loop = loop
        self.current_wp = 0
        self.laps = 0
        self.total_waypoints_reached = 0

    @property
    def finished(self) -> bool:
        if self.loop:
            return False
        return self.current_wp >= len(self.waypoints)

    @property
    def target(self) -> tuple[float, float] | None:
        if self.current_wp >= len(self.waypoints):
            return None
        return self.waypoints[self.current_wp]

    def decide_action(self, state: dict[str, Any]) -> dict[str, Any]:
        """Compute drive command for this robot given its current pose."""
        if self.finished:
            return {"vx": 0.0, "wz": 0.0, "action": "STOP"}

        rx, ry, ryaw = state["x"], state["y"], state["yaw"]
        tx, ty = self.waypoints[self.current_wp]

        dx = tx - rx
        dy = ty - ry
        dist = math.hypot(dx, dy)

        # Waypoint reached?
        if dist < WAYPOINT_REACH_DIST:
            self.total_waypoints_reached += 1
            self.current_wp += 1
            if self.current_wp >= len(self.waypoints) and self.loop:
                self.current_wp = 0
                self.laps += 1
            if self.finished:
                return {"vx": 0.0, "wz": 0.0, "action": "STOP"}
            return self.decide_action(state)

        bearing = math.atan2(dy, dx)
        heading_error = _normalise_angle(bearing - ryaw)

        wz = KP_ANGULAR * heading_error
        wz = max(-MAX_WZ, min(MAX_WZ, wz))

        if abs(heading_error) > HEADING_SLOW_THRESH:
            vx = MIN_VX
        else:
            vx = MAX_VX * (1.0 - abs(heading_error) / math.pi)
            vx = max(MIN_VX, min(MAX_VX, vx))

        if abs(heading_error) > 0.3:
            action = "LEFT" if heading_error > 0 else "RIGHT"
        else:
            action = "FORWARD"

        return {"vx": vx, "wz": wz, "action": action}


class FleetNavigator:
    """Manages waypoint navigation for all robots in the fleet."""

    def __init__(self, loop: bool = True) -> None:
        self.robots: dict[str, RobotNavigator] = {
            rid: RobotNavigator(rid, loop=loop) for rid in ROBOT_IDS
        }

    @property
    def all_finished(self) -> bool:
        return all(nav.finished for nav in self.robots.values())

    @property
    def total_waypoints_reached(self) -> int:
        return sum(nav.total_waypoints_reached for nav in self.robots.values())

    @property
    def total_laps(self) -> int:
        return sum(nav.laps for nav in self.robots.values())

    def decide_actions(
        self, fleet_state: dict[str, dict[str, Any]]
    ) -> dict[str, dict[str, Any]]:
        """Compute drive commands for all robots.

        Parameters
        ----------
        fleet_state : dict
            Keyed by robot_id, each value has x, y, yaw.

        Returns
        -------
        dict keyed by robot_id, each value has vx, wz, action.
        """
        commands: dict[str, dict[str, Any]] = {}
        for rid, nav in self.robots.items():
            if rid in fleet_state:
                commands[rid] = nav.decide_action(fleet_state[rid])
            else:
                commands[rid] = {"vx": 0.0, "wz": 0.0, "action": "STOP"}
        return commands


def fleet_state_summary(
    fleet_state: dict[str, dict[str, Any]], navigator: FleetNavigator
) -> str:
    """Build a concise text summary of the fleet state for OmniLink memory."""
    lines = [
        f"Fleet status: {'All complete' if navigator.all_finished else 'Navigating'}",
        f"Total waypoints reached: {navigator.total_waypoints_reached}",
        f"Total laps: {navigator.total_laps}",
        "",
    ]
    for rid in ROBOT_IDS:
        nav = navigator.robots[rid]
        st = fleet_state.get(rid, {"x": 0, "y": 0, "yaw": 0})
        target = nav.target
        target_str = f"({target[0]:.1f}, {target[1]:.1f})" if target else "done"
        if target:
            dist = math.hypot(target[0] - st["x"], target[1] - st["y"])
            dist_str = f"{dist:.2f}m"
        else:
            dist_str = "N/A"
        lines.append(
            f"  {rid}: pos=({st['x']:.2f}, {st['y']:.2f}) yaw={st['yaw']:.2f} | "
            f"wp {nav.current_wp + 1}/{len(nav.waypoints)} -> {target_str} ({dist_str}) | "
            f"reached={nav.total_waypoints_reached} laps={nav.laps}"
        )
    return "\n".join(lines)
