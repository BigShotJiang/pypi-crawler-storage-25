"""File-search agent demo — interactive tool server for the OmniLink UI.

Starts a local tool callback server and configures the agent profile so
that the user can ask questions directly in the OmniLink build page.
The agent calls search_files, read_file, and list_files via the local
server — no automated queries, everything is driven from the UI.

Usage
-----
    export OMNI_KEY=omk_...
    python -m omnilink.examples.file_search.file_search_demo

Then open https://www.omnilink-agents.com/build and ask a question.
The agent will use the tools through your local callback server.
Press Ctrl+C to stop.
"""

from __future__ import annotations

import os
import pathlib
import signal
import sys
import threading
from typing import Any

LIB_PATH = pathlib.Path(__file__).resolve().parents[4] / "src"
if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from omnilink.client import OmniLinkClient
from omnilink.default_tools import ListFilesTool, ReadFileTool, SearchFilesTool
from omnilink.tool_runner import ToolRunner

# ── Configuration ────────────────────────────────────────────────────

SAMPLE_DATA = str(pathlib.Path(__file__).resolve().parent / "sample_data")

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get(
    "OMNILINK_BASE_URL", "https://www.omnilink-agents.com"
)


# ── Runner ───────────────────────────────────────────────────────────


class FileSearchRunner(ToolRunner):
    """An agent that answers questions by searching local files."""

    agent_name = "file-search-agent"
    display_name = "File Search"
    engine = "g3-engine"
    tool_name = "answer_question"
    tool_description = (
        "Answer the user's question. Use search_files, read_file, "
        "and list_files first to find the relevant information, "
        "then provide a clear answer."
    )
    commands = "stop_game"

    default_tools = [
        SearchFilesTool(root_dir=SAMPLE_DATA),
        ReadFileTool(root_dir=SAMPLE_DATA),
        ListFilesTool(root_dir=SAMPLE_DATA),
    ]

    def get_profile_settings(self) -> dict[str, Any]:
        settings = super().get_profile_settings()
        settings["mainTask"] = (
            "You are a knowledge-base assistant. When the user asks a "
            "question, use the available tools to search through files, "
            "read documents, and provide accurate answers.\n\n"
            "Available tools:\n"
            "- list_files: browse directories\n"
            "- search_files: search for text across files\n"
            "- read_file: read a specific file\n\n"
            "Always search or read first, then answer. "
            "Cite the file where you found the information."
        )
        settings["maxToolRounds"] = 8
        return settings

    # The demo does not use the game loop — these are no-ops.
    def get_state(self) -> dict[str, Any]:
        return {}

    def execute_action(self, state: dict[str, Any]) -> None:
        pass

    def state_summary(self, state: dict[str, Any]) -> str:
        return "idle"

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return True


# ── Entry point ──────────────────────────────────────────────────────


def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY before running:  export OMNI_KEY=omk_...")
        sys.exit(1)

    runner = FileSearchRunner()
    runner.omni_key = OMNI_KEY
    runner.base_url = BASE_URL

    client = OmniLinkClient(omni_key=OMNI_KEY, base_url=BASE_URL, timeout=60)
    runner._client = client
    runner._conversation_history = []
    runner._activity_log = []

    # Start the tool callback server.
    port = runner._start_tool_server()
    runner.tool_callback_url = f"http://127.0.0.1:{port}/tool"

    # Configure the agent profile so the UI knows about the tools.
    runner._ensure_profile(client)

    # Clear stale memory.
    try:
        client.set_memory(runner._memory_agent_key(), [])
    except Exception:
        pass

    print()
    print("=" * 60)
    print("  File Search Agent — Interactive Demo")
    print("=" * 60)
    print()
    print(f"  Tool server:     http://127.0.0.1:{port}/tool")
    print(f"  Activity log:    http://127.0.0.1:{port}/activity")
    print(f"  Knowledge base:  {SAMPLE_DATA}")
    print()
    print(f"  Open the UI:     {BASE_URL}/build")
    print()
    print("  Ask a question in the UI — the agent will use your")
    print("  local tools to search files and answer.")
    print()
    print("  Press Ctrl+C to stop.")
    print("=" * 60)
    print()

    # Keep the server alive until interrupted.
    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    try:
        signal.signal(signal.SIGBREAK, lambda *_: stop.set())
    except AttributeError:
        pass  # SIGBREAK is Windows-only

    stop.wait()

    print()
    print("  Shutting down.")


if __name__ == "__main__":
    main()
