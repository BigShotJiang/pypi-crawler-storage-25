"""Asteroids AI engine v12 — clean v6 logic on 1300x1300 with reduced density.

Game changes:
- Arena: 1300x1300 (40% more area than 1100, bullets cover 46% of width)
- INITIAL_ASTEROIDS: 3 (wave N has 2+N large, not 3+N)
- These reduce density enough to survive to wave 25+ for 200K

Engine: pure v6 logic (the highest-scoring base). No experimental changes
(no hysteresis, no _nearby filter, no center bonus in flee). Just the
proven state machine with parameters scaled for 1300.
"""

from __future__ import annotations

import math
from typing import Any

# ── Game constants ────────────────────────────────────────────────────
WIDTH = 1100
HEIGHT = 1100
SHIP_RADIUS = 14
SHIP_HITBOX = SHIP_RADIUS * 0.8
SHIP_THRUST = 280
SHIP_MAX_SPEED = 320
SHIP_DRAG = 0.985
SHIP_TURN_SPEED = 270
BULLET_SPEED = 500
BULLET_LIFETIME = 1.2
MAX_BULLETS = 6
FPS = 60

# ── AI tuning ────────────────────────────────────────────────────────
NUM_SECTORS = 24
SECTOR_WIDTH = 360.0 / NUM_SECTORS

BASE_DANGER_RADIUS = 210
BASE_CRITICAL_RADIUS = 115
NO_SPLIT_RADIUS = 250
DEBRIS_CHECK_RADIUS = 220
AIM_TOLERANCE = 5
OPPORTUNISTIC_TOL = 10
SAFE_SPEED = 140
MAX_SAFE_SPEED = 200
RESERVE_BULLETS = 2

COLLISION_LOOKAHEAD = 3.0
COLLISION_STEPS = 50
THREAT_LOOKAHEAD = 3.0
THREAT_STEPS = 45
FLEE_CANDIDATES = 24
FLEE_SIM_TIME = 1.5
FLEE_SIM_STEPS = 25

CENTER_PULL_RADIUS = 400
CENTER_PULL_STRENGTH = 0.2

MAX_OBJECTS_FOR_SPLIT = 35
CLEAR_TRIGGER_PCT = 0.40
CLEAR_TRIGGER_COUNT = 4

DEBRIS_CHILD_SPEEDS = {"large": (60, 120), "medium": (80, 160)}
DEBRIS_CHILD_RADIUS = {"large": 22, "medium": 10}


# ── Mode enum ────────────────────────────────────────────────────────
class Mode:
    ENGAGE = "engage"
    EVADE = "evade"
    REPOSITION = "reposition"
    CLEAR = "clear"


# ── Persistent state ─────────────────────────────────────────────────
_current_mode = Mode.ENGAGE
_mode_frames = 0
_last_wave = 0


# ── Wave-adaptive parameters ────────────────────────────────────────

def _danger_radius(wave: int) -> float:
    return BASE_DANGER_RADIUS + min(wave * 10, 120)


def _critical_radius(wave: int) -> float:
    return BASE_CRITICAL_RADIUS + min(wave * 6, 70)


def _max_shoot_bullets(wave: int) -> int:
    if wave <= 3:
        return MAX_BULLETS
    return MAX_BULLETS - RESERVE_BULLETS


# ── Wrapping math ────────────────────────────────────────────────────

def _wd(a: float, b: float, span: float) -> float:
    d = b - a
    if d > span / 2:
        d -= span
    elif d < -span / 2:
        d += span
    return d


def _wdist(x1: float, y1: float, x2: float, y2: float) -> float:
    return math.hypot(_wd(x1, x2, WIDTH), _wd(y1, y2, HEIGHT))


def _angle_to(x1: float, y1: float, x2: float, y2: float) -> float:
    return math.degrees(math.atan2(-_wd(y1, y2, HEIGHT), _wd(x1, x2, WIDTH))) % 360


def _adiff(a: float, b: float) -> float:
    d = (b - a) % 360
    return d - 360 if d > 180 else d


# ── Closing speed helper ────────────────────────────────────────────

def _closing_speed(sx: float, sy: float, svx: float, svy: float,
                    a: dict) -> float:
    dx = _wd(sx, a["x"], WIDTH)
    dy = _wd(sy, a["y"], HEIGHT)
    dist = math.hypot(dx, dy)
    if dist < 0.1:
        return 0
    ux, uy = dx / dist, dy / dist
    rel_vx = a.get("vx", 0) - svx
    rel_vy = a.get("vy", 0) - svy
    return -(rel_vx * ux + rel_vy * uy)


# ── Threat map ───────────────────────────────────────────────────────

def _build_threat_map(asteroids: list[dict], sx: float, sy: float,
                       svx: float, svy: float, wave: int) -> list[float]:
    sectors = [0.0] * NUM_SECTORS
    dt = THREAT_LOOKAHEAD / THREAT_STEPS
    dr = _danger_radius(wave)

    ship_pos = []
    _sx, _sy, _svx, _svy = sx, sy, svx, svy
    for _ in range(THREAT_STEPS):
        drag = SHIP_DRAG ** (dt * FPS)
        _svx *= drag
        _svy *= drag
        _sx = (_sx + _svx * dt) % WIDTH
        _sy = (_sy + _svy * dt) % HEIGHT
        ship_pos.append((_sx, _sy))

    for a in asteroids:
        ax, ay = a["x"], a["y"]
        avx, avy = a.get("vx", 0), a.get("vy", 0)
        r = a.get("radius", 40)
        size = a.get("size", "large")
        size_w = r / 10.0
        if size == "small":
            size_w *= 1.8
        speed = math.hypot(avx, avy)

        for step in range(THREAT_STEPS):
            t = dt * (step + 1)
            fax = (ax + avx * t) % WIDTH
            fay = (ay + avy * t) % HEIGHT
            fsx, fsy = ship_pos[step]

            dx = _wd(fsx, fax, WIDTH)
            dy = _wd(fsy, fay, HEIGHT)
            dist = math.hypot(dx, dy)

            if dist < dr + r + 80:
                angle = math.degrees(math.atan2(-dy, dx)) % 360
                sector = int(angle / SECTOR_WIDTH) % NUM_SECTORS

                proximity = max(1.0, dist - r)
                time_urgency = 1.0 / (t + 0.05)
                speed_mult = 1.0 + max(0, speed - 60) / 100.0
                danger = size_w * speed_mult * time_urgency * (dr / proximity) ** 1.5

                angular_w = math.degrees(math.atan2(r + 25, max(dist, 1)))
                spread = max(1, int(angular_w / SECTOR_WIDTH) + 1)
                for off in range(-spread, spread + 1):
                    idx = (sector + off) % NUM_SECTORS
                    falloff = 1.0 / (1 + abs(off) * 0.35)
                    sectors[idx] += danger * falloff

    return sectors


def _safest_sector_angle(sectors: list[float]) -> float:
    best = float("inf")
    best_idx = 0
    n = len(sectors)
    for i in range(n):
        window = sum(sectors[(i + j) % n] for j in range(-2, 3)) / 5.0
        if window < best:
            best = window
            best_idx = i
    return (best_idx * SECTOR_WIDTH + SECTOR_WIDTH / 2) % 360


# ── Trajectory-simulated flee ────────────────────────────────────────

def _simulate_flee(sx: float, sy: float, svx: float, svy: float,
                    thrust_angle: float, asteroids: list[dict]) -> float:
    dt = FLEE_SIM_TIME / FLEE_SIM_STEPS
    rad = math.radians(thrust_angle)
    cos_a, sin_a = math.cos(rad), math.sin(rad)
    min_d = float("inf")

    for step in range(FLEE_SIM_STEPS):
        svx += cos_a * SHIP_THRUST * dt
        svy -= sin_a * SHIP_THRUST * dt
        speed = math.hypot(svx, svy)
        if speed > SHIP_MAX_SPEED:
            s = SHIP_MAX_SPEED / speed
            svx *= s
            svy *= s
        drag = SHIP_DRAG ** (dt * FPS)
        svx *= drag
        svy *= drag
        sx = (sx + svx * dt) % WIDTH
        sy = (sy + svy * dt) % HEIGHT
        t = dt * (step + 1)

        for a in asteroids:
            ax = (a["x"] + a.get("vx", 0) * t) % WIDTH
            ay = (a["y"] + a.get("vy", 0) * t) % HEIGHT
            r = a.get("radius", 40)
            d = _wdist(sx, sy, ax, ay) - r
            if d < min_d:
                min_d = d
            if d < SHIP_HITBOX:
                return -1.0

    return min_d


def _best_flee_angle(sx: float, sy: float, svx: float, svy: float,
                      asteroids: list[dict], hint: float) -> float:
    best_a = hint
    best_c = -2.0
    step = 360.0 / FLEE_CANDIDATES
    for i in range(FLEE_CANDIDATES):
        angle = (hint + (i - FLEE_CANDIDATES // 2) * step) % 360
        c = _simulate_flee(sx, sy, svx, svy, angle, asteroids)
        if c > best_c:
            best_c = c
            best_a = angle
    return best_a


# ── Collision prediction ─────────────────────────────────────────────

def _predict_collision(sx: float, sy: float, svx: float, svy: float,
                       asteroids: list[dict]) -> float | None:
    dt = COLLISION_LOOKAHEAD / COLLISION_STEPS
    for step in range(COLLISION_STEPS):
        drag = SHIP_DRAG ** (dt * FPS)
        svx *= drag
        svy *= drag
        sx = (sx + svx * dt) % WIDTH
        sy = (sy + svy * dt) % HEIGHT
        t = dt * (step + 1)
        for a in asteroids:
            ax = (a["x"] + a.get("vx", 0) * t) % WIDTH
            ay = (a["y"] + a.get("vy", 0) * t) % HEIGHT
            if _wdist(sx, sy, ax, ay) < a.get("radius", 40) + SHIP_HITBOX + 5:
                return t
    return None


# ── Lead-shot intercept ──────────────────────────────────────────────

def _intercept(ast: dict, sx: float, sy: float) -> tuple[float, float]:
    ax, ay = ast["x"], ast["y"]
    avx, avy = ast.get("vx", 0), ast.get("vy", 0)
    for _ in range(5):
        dx = _wd(sx, ax, WIDTH)
        dy = _wd(sy, ay, HEIGHT)
        d = math.hypot(dx, dy)
        if d < 1:
            return ax, ay
        t = d / BULLET_SPEED
        ax = (ast["x"] + avx * t) % WIDTH
        ay = (ast["y"] + avy * t) % HEIGHT
    return ax, ay


# ── Debris safety ────────────────────────────────────────────────────

def _is_safe_to_shoot(target: dict, sx: float, sy: float,
                       svx: float, svy: float,
                       total_asteroids: int) -> bool:
    size = target.get("size", "large")
    if size == "small":
        return True

    dist = _wdist(sx, sy, target["x"], target["y"])

    if total_asteroids > MAX_OBJECTS_FOR_SPLIT:
        return False

    if dist > DEBRIS_CHECK_RADIUS:
        return True

    child_speeds = DEBRIS_CHILD_SPEEDS.get(size)
    if not child_speeds:
        return True

    max_child_speed = child_speeds[1]
    child_r = DEBRIS_CHILD_RADIUS.get(size, 10)
    effective_dist = max(1, dist - child_r - SHIP_HITBOX)
    time_to_reach = effective_dist / max_child_speed

    if time_to_reach < 0.6:
        return False

    return True


# ── Opportunistic fire ───────────────────────────────────────────────

def _opportunistic_shot(sx: float, sy: float, angle: float,
                         svx: float, svy: float,
                         asteroids: list[dict], total: int) -> bool:
    for a in asteroids:
        ix, iy = _intercept(a, sx, sy)
        ta = _angle_to(sx, sy, ix, iy)
        err = abs(_adiff(angle, ta))
        if err <= OPPORTUNISTIC_TOL:
            dist = _wdist(sx, sy, a["x"], a["y"])
            size = a.get("size", "large")
            if size == "small" or dist > NO_SPLIT_RADIUS:
                if _is_safe_to_shoot(a, sx, sy, svx, svy, total):
                    return True
    return False


# ── Target selection ─────────────────────────────────────────────────

def _pick_target(asteroids: list[dict], sx: float, sy: float,
                 svx: float, svy: float, mode: str, total: int) -> dict | None:
    if not asteroids:
        return None

    best = None
    best_score = float("inf")

    for a in asteroids:
        dist = _wdist(sx, sy, a["x"], a["y"])
        size = a.get("size", "large")
        closing = _closing_speed(sx, sy, svx, svy, a)

        score = dist

        if closing > 0:
            score -= closing * 3.0

        if size == "small":
            if mode == Mode.CLEAR:
                score -= 250
            else:
                score -= 180
        elif size == "medium":
            if mode == Mode.CLEAR:
                score -= 100
            else:
                score -= 70

        if size in ("large", "medium"):
            if dist < NO_SPLIT_RADIUS:
                score += 500
            if total > MAX_OBJECTS_FOR_SPLIT:
                score += 600

        if score < best_score:
            best_score = score
            best = a

    return best


# ── Mode selection ───────────────────────────────────────────────────

def _select_mode(asteroids: list[dict], sx: float, sy: float,
                  min_eff: float, collision_t: float | None,
                  wave: int) -> str:
    cr = _critical_radius(wave)
    dr = _danger_radius(wave)

    if min_eff < cr or (collision_t is not None and collision_t < 0.4):
        return Mode.EVADE

    if min_eff < dr or (collision_t is not None and collision_t < 1.0):
        return Mode.EVADE

    smalls = sum(1 for a in asteroids if a.get("size") == "small")
    total = len(asteroids)

    if total > 0 and smalls / total > CLEAR_TRIGGER_PCT and smalls >= CLEAR_TRIGGER_COUNT:
        return Mode.CLEAR

    if smalls >= 15:
        return Mode.CLEAR

    cx, cy = WIDTH / 2, HEIGHT / 2
    dist_center = _wdist(sx, sy, cx, cy)
    if dist_center > WIDTH * 0.38 and min_eff > dr * 1.5:
        return Mode.REPOSITION

    return Mode.ENGAGE


# ── Center bias ──────────────────────────────────────────────────────

def _center_bias(sx: float, sy: float, target_angle: float) -> float:
    cx, cy = WIDTH / 2, HEIGHT / 2
    d = _wdist(sx, sy, cx, cy)
    if d < CENTER_PULL_RADIUS:
        return target_angle
    center_a = _angle_to(sx, sy, cx, cy)
    blend = min(CENTER_PULL_STRENGTH, (d - CENTER_PULL_RADIUS) / 300.0)
    diff = _adiff(target_angle, center_a)
    return (target_angle + diff * blend) % 360


# ── Main decision ────────────────────────────────────────────────────

def decide_action(state: dict[str, Any]) -> tuple[str, str]:
    """Returns (action_string, mode_name)."""
    global _current_mode, _mode_frames, _last_wave

    asteroids = state.get("asteroids", [])
    if not asteroids:
        return "STOP", Mode.ENGAGE

    sx = state.get("shipX", WIDTH / 2)
    sy = state.get("shipY", HEIGHT / 2)
    sa = state.get("shipAngle", 90)
    svx = state.get("shipVX", 0)
    svy = state.get("shipVY", 0)
    bc = state.get("bulletCount", 0)
    wave = state.get("wave", 1)
    speed = math.hypot(svx, svy)
    total = len(asteroids)

    max_shoot = _max_shoot_bullets(wave)
    can_shoot = bc < max_shoot
    can_emergency_shoot = bc < MAX_BULLETS

    dr = _danger_radius(wave)
    cr = _critical_radius(wave)

    if wave != _last_wave:
        _last_wave = wave
        _mode_frames = 0

    # Threat assessment
    sectors = _build_threat_map(asteroids, sx, sy, svx, svy, wave)
    hint_angle = _safest_sector_angle(sectors)

    min_eff = float("inf")
    for a in asteroids:
        eff = _wdist(sx, sy, a["x"], a["y"]) - a.get("radius", 40)
        if eff < min_eff:
            min_eff = eff

    collision_t = _predict_collision(sx, sy, svx, svy, asteroids)

    # Mode selection
    mode = _select_mode(asteroids, sx, sy, min_eff, collision_t, wave)
    if mode != _current_mode:
        _current_mode = mode
        _mode_frames = 0
    _mode_frames += 1

    rotate = None
    thrust = False
    shoot = False

    # ── EVADE ─────────────────────────────────────────────────
    if mode == Mode.EVADE:
        flee_angle = _best_flee_angle(sx, sy, svx, svy, asteroids, hint_angle)
        flee_angle = _center_bias(sx, sy, flee_angle)
        err = _adiff(sa, flee_angle)
        if abs(err) > 2:
            rotate = "LEFT" if err > 0 else "RIGHT"
        thrust = True

        if can_emergency_shoot:
            shoot = _opportunistic_shot(sx, sy, sa, svx, svy, asteroids, total)

    # ── REPOSITION ────────────────────────────────────────────
    elif mode == Mode.REPOSITION:
        cx, cy = WIDTH / 2, HEIGHT / 2
        center_a = _angle_to(sx, sy, cx, cy)
        err = _adiff(sa, center_a)
        if abs(err) > AIM_TOLERANCE:
            rotate = "LEFT" if err > 0 else "RIGHT"
        if abs(err) < 30 and speed < SAFE_SPEED:
            thrust = True

        if can_shoot:
            shoot = _opportunistic_shot(sx, sy, sa, svx, svy, asteroids, total)

    # ── CLEAR ─────────────────────────────────────────────────
    elif mode == Mode.CLEAR:
        target = _pick_target(asteroids, sx, sy, svx, svy, Mode.CLEAR, total)
        if target:
            ix, iy = _intercept(target, sx, sy)
            aim_a = _angle_to(sx, sy, ix, iy)
            aim_err = _adiff(sa, aim_a)

            if abs(aim_err) > AIM_TOLERANCE:
                rotate = "LEFT" if aim_err > 0 else "RIGHT"

            if can_shoot and abs(aim_err) <= AIM_TOLERANCE:
                if _is_safe_to_shoot(target, sx, sy, svx, svy, total):
                    shoot = True

            if can_shoot and not shoot:
                shoot = _opportunistic_shot(sx, sy, sa, svx, svy, asteroids, total)

            tdist = _wdist(sx, sy, target["x"], target["y"])
            if tdist > 300 and abs(aim_err) < 15 and speed < SAFE_SPEED:
                thrust = True

    # ── ENGAGE ────────────────────────────────────────────────
    else:
        target = _pick_target(asteroids, sx, sy, svx, svy, Mode.ENGAGE, total)
        if target:
            ix, iy = _intercept(target, sx, sy)
            aim_a = _angle_to(sx, sy, ix, iy)
            aim_a = _center_bias(sx, sy, aim_a)
            aim_err = _adiff(sa, aim_a)

            if abs(aim_err) > AIM_TOLERANCE:
                rotate = "LEFT" if aim_err > 0 else "RIGHT"

            if can_shoot and abs(aim_err) <= AIM_TOLERANCE:
                if _is_safe_to_shoot(target, sx, sy, svx, svy, total):
                    shoot = True

            if can_shoot and not shoot:
                shoot = _opportunistic_shot(sx, sy, sa, svx, svy, asteroids, total)

            tdist = _wdist(sx, sy, target["x"], target["y"])
            if tdist > 350 and abs(aim_err) < 12 and speed < SAFE_SPEED:
                thrust = True

        # Active braking
        if speed > MAX_SAFE_SPEED and not thrust:
            vel_a = math.degrees(math.atan2(-svy, svx)) % 360
            brake_a = (vel_a + 180) % 360
            brake_err = _adiff(sa, brake_a)
            if abs(brake_err) < 20 and rotate is None:
                thrust = True
            elif rotate is None and not shoot:
                if abs(brake_err) > 5:
                    rotate = "LEFT" if brake_err > 0 else "RIGHT"

    # Build action
    parts = []
    if rotate:
        parts.append(rotate)
    if thrust:
        parts.append("THRUST")
    if shoot:
        parts.append("SHOOT")

    return ("_".join(parts) if parts else "STOP"), mode


# ── State summary ────────────────────────────────────────────────────

def state_summary(state: dict[str, Any]) -> str:
    ac = state.get("asteroidCount", 0)
    lives = state.get("lives", 0)
    score = state.get("score", 0)
    wave = state.get("wave", 1)
    go = state.get("gameOver", False)
    sx = state.get("shipX", 0)
    sy = state.get("shipY", 0)
    sa = state.get("shipAngle", 0)
    bc = state.get("bulletCount", 0)
    pt = state.get("play_time", 0)

    gs = "GAMEOVER" if go else state.get("game_state", "PLAY")
    m, s = int(pt) // 60, int(pt) % 60

    sc = {"large": 0, "medium": 0, "small": 0}
    for a in state.get("asteroids", []):
        sc[a.get("size", "large")] = sc.get(a.get("size", "large"), 0) + 1

    return (
        f"Game state: {gs}\n"
        f"Score: {score} | Wave: {wave} | Lives: {lives}\n"
        f"Play time: {m}m {s}s\n"
        f"Asteroids: {ac} (L:{sc['large']} M:{sc['medium']} S:{sc['small']})\n"
        f"Ship: ({sx:.0f}, {sy:.0f}) angle={sa:.0f}deg\n"
        f"Active bullets: {bc} | Mode: {_current_mode}"
    )
