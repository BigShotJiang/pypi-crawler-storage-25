"""Asteroids demo -- strategic AI with multi-tool engagement, evasion, and analysis."""
