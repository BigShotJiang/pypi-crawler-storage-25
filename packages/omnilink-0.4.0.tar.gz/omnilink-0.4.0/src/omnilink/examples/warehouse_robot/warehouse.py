"""Simulated warehouse environment.

Maintains the robot state (position, battery, gripper, payload) and
the warehouse layout (zones, shelves, items).  All mutations go through
this module so the tools share consistent state.
"""

from __future__ import annotations

import math
import random
import threading
import time
from dataclasses import dataclass, field
from typing import Any


# ── Warehouse layout ─────────────────────────────────────────────────

ZONES: dict[str, dict[str, Any]] = {
    "dock-A": {"label": "Receiving Dock A", "x": 0, "y": 0, "type": "dock"},
    "dock-B": {"label": "Shipping Dock B", "x": 0, "y": 40, "type": "dock"},
    "aisle-1": {"label": "Aisle 1 — Electronics", "x": 20, "y": 10, "type": "storage"},
    "aisle-2": {"label": "Aisle 2 — Hardware", "x": 20, "y": 20, "type": "storage"},
    "aisle-3": {"label": "Aisle 3 — Office Supplies", "x": 20, "y": 30, "type": "storage"},
    "staging": {"label": "Staging Area", "x": 10, "y": 20, "type": "staging"},
    "charging": {"label": "Charging Station", "x": 0, "y": 20, "type": "service"},
    "inspection": {"label": "QA Inspection Bay", "x": 10, "y": 40, "type": "inspection"},
}

SHELVES: dict[str, dict[str, Any]] = {
    "E-101": {"zone": "aisle-1", "label": "Shelf E-101", "capacity": 20},
    "E-102": {"zone": "aisle-1", "label": "Shelf E-102", "capacity": 20},
    "H-201": {"zone": "aisle-2", "label": "Shelf H-201", "capacity": 15},
    "H-202": {"zone": "aisle-2", "label": "Shelf H-202", "capacity": 15},
    "O-301": {"zone": "aisle-3", "label": "Shelf O-301", "capacity": 25},
    "O-302": {"zone": "aisle-3", "label": "Shelf O-302", "capacity": 25},
    "STG-01": {"zone": "staging", "label": "Staging Rack 01", "capacity": 30},
}

INITIAL_INVENTORY: list[dict[str, Any]] = [
    {"sku": "ELEC-001", "name": "Wireless Keyboard", "shelf": "E-101", "qty": 12, "weight": 0.45},
    {"sku": "ELEC-002", "name": "USB-C Hub", "shelf": "E-101", "qty": 8, "weight": 0.15},
    {"sku": "ELEC-003", "name": "27\" Monitor", "shelf": "E-102", "qty": 4, "weight": 5.2},
    {"sku": "ELEC-004", "name": "Webcam HD Pro", "shelf": "E-102", "qty": 15, "weight": 0.2},
    {"sku": "HW-001", "name": "Power Drill", "shelf": "H-201", "qty": 6, "weight": 2.1},
    {"sku": "HW-002", "name": "Socket Wrench Set", "shelf": "H-201", "qty": 10, "weight": 3.5},
    {"sku": "HW-003", "name": "Safety Goggles (box)", "shelf": "H-202", "qty": 20, "weight": 0.8},
    {"sku": "OFF-001", "name": "A4 Paper (ream)", "shelf": "O-301", "qty": 50, "weight": 2.5},
    {"sku": "OFF-002", "name": "Whiteboard Markers (12pk)", "shelf": "O-301", "qty": 30, "weight": 0.3},
    {"sku": "OFF-003", "name": "Ergonomic Chair", "shelf": "O-302", "qty": 3, "weight": 14.0},
    {"sku": "OFF-004", "name": "Standing Desk Frame", "shelf": "O-302", "qty": 2, "weight": 22.0},
    {"sku": "MISC-01", "name": "Incoming shipment (unsorted)", "shelf": "STG-01", "qty": 8, "weight": 1.0},
]

PENDING_ORDERS: list[dict[str, Any]] = [
    {"order_id": "ORD-4401", "items": [{"sku": "ELEC-001", "qty": 2}, {"sku": "OFF-002", "qty": 3}], "destination": "dock-B", "priority": "standard"},
    {"order_id": "ORD-4402", "items": [{"sku": "HW-001", "qty": 1}, {"sku": "HW-003", "qty": 5}], "destination": "dock-B", "priority": "express"},
    {"order_id": "ORD-4403", "items": [{"sku": "ELEC-003", "qty": 1}], "destination": "inspection", "priority": "fragile"},
    {"order_id": "ORD-4404", "items": [{"sku": "OFF-001", "qty": 10}, {"sku": "OFF-003", "qty": 1}], "destination": "dock-B", "priority": "standard"},
]


# ── Robot state ──────────────────────────────────────────────────────

@dataclass
class RobotState:
    zone: str = "charging"
    navigating_to: str | None = None  # set during transit, cleared on arrival
    battery: float = 100.0
    gripper_open: bool = True
    payload: list[dict[str, Any]] = field(default_factory=list)
    max_payload_weight: float = 25.0
    speed: float = 1.0  # metres per second
    mission_log: list[str] = field(default_factory=list)
    inventory: list[dict[str, Any]] = field(default_factory=list)
    orders: list[dict[str, Any]] = field(default_factory=list)

    def payload_weight(self) -> float:
        return sum(item.get("weight", 0) * item.get("qty", 1) for item in self.payload)

    def log(self, msg: str) -> None:
        ts = time.strftime("%H:%M:%S")
        self.mission_log.append(f"[{ts}] {msg}")
        # Keep last 50 entries
        if len(self.mission_log) > 50:
            self.mission_log = self.mission_log[-50:]


# ── Singleton warehouse ──────────────────────────────────────────────

_lock = threading.Lock()
_robot: RobotState | None = None


def get_robot() -> RobotState:
    global _robot
    with _lock:
        if _robot is None:
            _robot = RobotState(
                inventory=[dict(item) for item in INITIAL_INVENTORY],
                orders=[dict(order) for order in PENDING_ORDERS],
            )
            _robot.log("Robot powered on at charging station.")
        return _robot


def reset_robot() -> RobotState:
    global _robot
    with _lock:
        _robot = RobotState(
            inventory=[dict(item) for item in INITIAL_INVENTORY],
            orders=[dict(order) for order in PENDING_ORDERS],
        )
        _robot.log("Robot reset. Warehouse initialized.")
        return _robot


def travel_time(from_zone: str, to_zone: str) -> float:
    """Simulated travel time between zones in seconds."""
    a = ZONES.get(from_zone, {"x": 0, "y": 0})
    b = ZONES.get(to_zone, {"x": 0, "y": 0})
    dist = math.sqrt((a["x"] - b["x"]) ** 2 + (a["y"] - b["y"]) ** 2)
    # Scale: 1 grid unit = 1 metre, robot speed = 1 m/s, min 1.5s, max 4s
    real_time = dist / get_robot().speed
    return max(1.5, min(4.0, real_time * 0.1 + 1.5))


def drain_battery(seconds: float) -> None:
    """Drain battery proportional to action time."""
    robot = get_robot()
    robot.battery = max(0, robot.battery - seconds * 0.4)
