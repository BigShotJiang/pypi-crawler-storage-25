"""Live warehouse visualization server.

Starts an HTTP server that serves a real-time warehouse map at
http://127.0.0.1:<port>/. The page polls /state every 500ms and
animates the robot moving between zones.
"""

from __future__ import annotations

import http.server
import json
import threading
from typing import Any

from .warehouse import ZONES, SHELVES, get_robot

VISUALIZER_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Warehouse Robot — Live View</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    background: #0a0a0f;
    color: #e0e0e0;
    font-family: 'SF Mono', 'Fira Code', 'Consolas', monospace;
    display: flex;
    height: 100vh;
    overflow: hidden;
  }
  #map-panel {
    flex: 1;
    position: relative;
    min-width: 0;
  }
  canvas {
    display: block;
    width: 100%;
    height: 100%;
  }
  #side-panel {
    width: 320px;
    background: #111118;
    border-left: 1px solid #222;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .panel-section {
    padding: 14px 16px;
    border-bottom: 1px solid #1a1a22;
  }
  .panel-section h3 {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #666;
    margin-bottom: 8px;
  }
  .stat-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 3px 0;
    font-size: 13px;
  }
  .stat-label { color: #888; }
  .stat-value { color: #e0e0e0; font-weight: 600; }
  .stat-value.low { color: #f87171; }
  .stat-value.ok { color: #4ade80; }
  .stat-value.warn { color: #facc15; }
  .battery-bar {
    height: 6px;
    border-radius: 3px;
    background: #222;
    margin-top: 4px;
    overflow: hidden;
  }
  .battery-fill {
    height: 100%;
    border-radius: 3px;
    transition: width 0.5s ease, background 0.5s ease;
  }
  .payload-item {
    font-size: 12px;
    padding: 4px 8px;
    margin: 2px 0;
    background: #1a1a25;
    border-radius: 4px;
    display: flex;
    justify-content: space-between;
  }
  .payload-empty {
    font-size: 12px;
    color: #555;
    font-style: italic;
  }
  #log-section {
    flex: 1;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }
  #log-list {
    flex: 1;
    overflow-y: auto;
    padding: 0 16px 14px;
  }
  #log-list::-webkit-scrollbar { width: 4px; }
  #log-list::-webkit-scrollbar-track { background: transparent; }
  #log-list::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }
  .log-entry {
    font-size: 11px;
    padding: 3px 0;
    color: #999;
    border-bottom: 1px solid #161620;
    line-height: 1.4;
  }
  .log-entry:last-child { border-bottom: none; }
  .zone-label {
    position: absolute;
    font-size: 9px;
    color: #666;
    pointer-events: none;
    white-space: nowrap;
  }
</style>
</head>
<body>
<div id="map-panel">
  <canvas id="warehouse-canvas"></canvas>
</div>
<div id="side-panel">
  <div class="panel-section">
    <h3>Robot Status</h3>
    <div class="stat-row">
      <span class="stat-label">Zone</span>
      <span class="stat-value" id="s-zone">—</span>
    </div>
    <div class="stat-row">
      <span class="stat-label">Battery</span>
      <span class="stat-value" id="s-battery">—</span>
    </div>
    <div class="battery-bar"><div class="battery-fill" id="s-battery-bar"></div></div>
    <div class="stat-row" style="margin-top:6px">
      <span class="stat-label">Gripper</span>
      <span class="stat-value" id="s-gripper">—</span>
    </div>
    <div class="stat-row">
      <span class="stat-label">Payload</span>
      <span class="stat-value" id="s-weight">—</span>
    </div>
  </div>
  <div class="panel-section">
    <h3>Payload</h3>
    <div id="payload-list"><span class="payload-empty">Empty</span></div>
  </div>
  <div class="panel-section" id="log-section">
    <h3>Mission Log</h3>
    <div id="log-list"></div>
  </div>
</div>

<script>
const ZONES = __ZONES_JSON__;
const POLL_MS = 500;

// Layout constants
const PAD = 60;
const ZONE_RADIUS = 28;

// Robot animation
let robotX = 0, robotY = 0;
let targetX = 0, targetY = 0;
let robotZone = '';
const LERP = 0.04;

// Canvas
const canvas = document.getElementById('warehouse-canvas');
const ctx = canvas.getContext('2d');
let W = 0, H = 0;

// Zone positions (computed from layout)
const zonePositions = {};
function computeLayout() {
  const rect = canvas.getBoundingClientRect();
  W = canvas.width = rect.width * devicePixelRatio;
  H = canvas.height = rect.height * devicePixelRatio;
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);

  // Map zone grid coords to canvas coords
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const z of Object.values(ZONES)) {
    minX = Math.min(minX, z.x); maxX = Math.max(maxX, z.x);
    minY = Math.min(minY, z.y); maxY = Math.max(maxY, z.y);
  }
  const rangeX = maxX - minX || 1;
  const rangeY = maxY - minY || 1;
  const cw = rect.width - PAD * 2;
  const ch = rect.height - PAD * 2;
  for (const [id, z] of Object.entries(ZONES)) {
    zonePositions[id] = {
      x: PAD + ((z.x - minX) / rangeX) * cw,
      y: PAD + ((z.y - minY) / rangeY) * ch,
      label: z.label,
      type: z.type,
    };
  }
  // Init robot position
  if (robotX === 0 && robotY === 0 && zonePositions['charging']) {
    robotX = targetX = zonePositions['charging'].x;
    robotY = targetY = zonePositions['charging'].y;
  }
}

const TYPE_COLORS = {
  dock: '#3b82f6',
  storage: '#a855f7',
  staging: '#f59e0b',
  service: '#4ade80',
  inspection: '#ef4444',
};

function draw() {
  const w = W / devicePixelRatio;
  const h = H / devicePixelRatio;
  ctx.clearRect(0, 0, w, h);

  // Draw connections (grid lines between zones)
  ctx.strokeStyle = '#1a1a28';
  ctx.lineWidth = 1;
  const ids = Object.keys(zonePositions);
  for (let i = 0; i < ids.length; i++) {
    for (let j = i + 1; j < ids.length; j++) {
      const a = zonePositions[ids[i]];
      const b = zonePositions[ids[j]];
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      if (dist < 250) {
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    }
  }

  // Draw zones
  for (const [id, pos] of Object.entries(zonePositions)) {
    const color = TYPE_COLORS[pos.type] || '#666';
    const isRobotHere = id === robotZone;

    // Glow if robot is here
    if (isRobotHere) {
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, ZONE_RADIUS + 8, 0, Math.PI * 2);
      ctx.fillStyle = color + '18';
      ctx.fill();
    }

    // Zone circle
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, ZONE_RADIUS, 0, Math.PI * 2);
    ctx.fillStyle = '#12121a';
    ctx.fill();
    ctx.strokeStyle = isRobotHere ? color : color + '55';
    ctx.lineWidth = isRobotHere ? 2.5 : 1.5;
    ctx.stroke();

    // Zone label
    ctx.fillStyle = '#777';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(pos.label.split(' — ')[0], pos.x, pos.y + ZONE_RADIUS + 16);

    // Zone id
    ctx.fillStyle = color + 'aa';
    ctx.font = 'bold 9px monospace';
    ctx.fillText(id, pos.x, pos.y + 4);
  }

  // Animate robot position
  robotX += (targetX - robotX) * LERP;
  robotY += (targetY - robotY) * LERP;

  // Draw robot trail
  if (Math.hypot(targetX - robotX, targetY - robotY) > 2) {
    ctx.beginPath();
    ctx.moveTo(robotX, robotY);
    ctx.lineTo(targetX, targetY);
    ctx.strokeStyle = '#4ade8044';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Draw robot
  const pulse = 1 + Math.sin(Date.now() / 300) * 0.12;
  ctx.beginPath();
  ctx.arc(robotX, robotY, 10 * pulse, 0, Math.PI * 2);
  ctx.fillStyle = '#4ade80';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(robotX, robotY, 14 * pulse, 0, Math.PI * 2);
  ctx.strokeStyle = '#4ade8066';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Robot label
  ctx.fillStyle = '#4ade80';
  ctx.font = 'bold 10px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('ROBOT', robotX, robotY - 18);

  requestAnimationFrame(draw);
}

// Poll state
async function pollState() {
  try {
    const res = await fetch('/state');
    const data = await res.json();

    robotZone = data.zone || '';
    const navTo = data.navigating_to;
    // If navigating, animate toward destination; otherwise snap to current zone
    const displayZone = navTo || robotZone;
    const pos = zonePositions[displayZone];
    if (pos) {
      targetX = pos.x;
      targetY = pos.y;
    }

    // Update side panel
    document.getElementById('s-zone').textContent = data.zone_label || data.zone;
    const bat = data.battery ?? 0;
    const batEl = document.getElementById('s-battery');
    batEl.textContent = bat.toFixed(1) + '%';
    batEl.className = 'stat-value ' + (bat < 15 ? 'low' : bat < 40 ? 'warn' : 'ok');
    const barEl = document.getElementById('s-battery-bar');
    barEl.style.width = bat + '%';
    barEl.style.background = bat < 15 ? '#f87171' : bat < 40 ? '#facc15' : '#4ade80';

    document.getElementById('s-gripper').textContent = data.gripper || '—';
    document.getElementById('s-weight').textContent =
      (data.payload_weight_kg ?? 0).toFixed(1) + ' / ' + (data.max_payload_kg ?? 25) + ' kg';

    // Payload list
    const plEl = document.getElementById('payload-list');
    if (data.payload && data.payload.length) {
      plEl.innerHTML = data.payload.map(p =>
        `<div class="payload-item"><span>${p.name || p.sku}</span><span>x${p.qty}</span></div>`
      ).join('');
    } else {
      plEl.innerHTML = '<span class="payload-empty">Empty</span>';
    }

    // Mission log
    const logEl = document.getElementById('log-list');
    if (data.mission_log) {
      logEl.innerHTML = data.mission_log.map(e =>
        `<div class="log-entry">${e}</div>`
      ).join('');
      logEl.scrollTop = logEl.scrollHeight;
    }
  } catch {}
  setTimeout(pollState, POLL_MS);
}

// Init
window.addEventListener('resize', computeLayout);
computeLayout();
requestAnimationFrame(draw);
pollState();
</script>
</body>
</html>"""


def start_visualizer_server(port: int = 0) -> int:
    """Start the warehouse visualization HTTP server.

    Returns the port the server is listening on.
    """

    zones_json = json.dumps({
        zone_id: {
            "x": zone["x"],
            "y": zone["y"],
            "label": zone["label"],
            "type": zone["type"],
        }
        for zone_id, zone in ZONES.items()
    })

    html_content = VISUALIZER_HTML.replace("__ZONES_JSON__", zones_json)
    html_bytes = html_content.encode("utf-8")

    class VisualizerHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            pass

        def do_OPTIONS(self) -> None:
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

        def do_GET(self) -> None:
            if self.path == "/state":
                robot = get_robot()
                zone_info = ZONES.get(robot.zone, {})
                state = {
                    "zone": robot.zone,
                    "zone_label": zone_info.get("label", robot.zone),
                    "navigating_to": robot.navigating_to,
                    "battery": round(robot.battery, 1),
                    "gripper": "open" if robot.gripper_open else "closed",
                    "payload": robot.payload,
                    "payload_weight_kg": round(robot.payload_weight(), 2),
                    "max_payload_kg": robot.max_payload_weight,
                    "mission_log": robot.mission_log[-15:],
                }
                body = json.dumps(state).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/" or self.path == "/index.html":
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html_bytes)
            else:
                self.send_error(404)

    server = http.server.ThreadingHTTPServer(("0.0.0.0", port), VisualizerHandler)
    actual_port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return actual_port
