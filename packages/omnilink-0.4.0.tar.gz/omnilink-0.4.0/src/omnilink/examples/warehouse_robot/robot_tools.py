"""Warehouse robot tools — long-horizon task execution.

Each tool simulates a physical robot action with realistic latency:
navigation takes 2-4s (path planning + movement), picking takes 2.5s
(arm extension + grip), scanning takes 2s (camera + barcode reader), etc.

The robot maintains persistent state — battery drains, payload
accumulates, inventory updates. This creates a realistic multi-step
planning challenge for the agent.
"""

from __future__ import annotations

import time
from typing import Any

from omnilink.default_tools import DefaultTool

from .warehouse import (
    SHELVES,
    ZONES,
    drain_battery,
    get_robot,
    travel_time,
)


# ── RobotStatusTool ──────────────────────────────────────────────────

class RobotStatusTool(DefaultTool):
    """Get the robot's current state."""

    name = "robot_status"
    description = (
        "Get the robot's current status: position, battery level, "
        "gripper state, payload contents, and recent mission log. "
        "No arguments required."
    )
    parameters_schema: dict[str, Any] | None = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(1.0)
        robot = get_robot()
        zone_info = ZONES.get(robot.zone, {})
        return {
            "zone": robot.zone,
            "zone_label": zone_info.get("label", robot.zone),
            "battery": round(robot.battery, 1),
            "gripper": "open" if robot.gripper_open else "closed",
            "payload": robot.payload,
            "payload_weight_kg": round(robot.payload_weight(), 2),
            "max_payload_kg": robot.max_payload_weight,
            "recent_log": robot.mission_log[-8:],
        }


# ── NavigateToTool ───────────────────────────────────────────────────

class NavigateToTool(DefaultTool):
    """Navigate the robot to a warehouse zone."""

    name = "navigate_to"
    description = (
        "Move the robot to a zone. Simulates path planning and "
        "physical movement (2-4 seconds). "
        "Args: zone (required — one of: "
        + ", ".join(ZONES.keys()) + ")."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "zone": {"type": "string", "description": "Target zone name.", "enum": list(ZONES.keys())},
        },
        "required": ["zone"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        target = kwargs.get("zone", "").strip()
        if not target:
            return {"error": "Missing required argument: zone"}
        if target not in ZONES:
            return {"error": f"Unknown zone: {target}. Valid zones: {', '.join(ZONES.keys())}"}

        robot = get_robot()
        if robot.battery < 5:
            return {"error": "Battery critically low. Navigate to 'charging' first."}

        if robot.zone == target:
            robot.log(f"Already at {target}.")
            return {"status": "already_there", "zone": target, "label": ZONES[target]["label"]}

        duration = travel_time(robot.zone, target)
        old_zone = robot.zone
        robot.navigating_to = target
        robot.log(f"Navigating from {old_zone} to {target}...")
        time.sleep(duration)
        drain_battery(duration)
        robot.zone = target
        robot.navigating_to = None
        robot.log(f"Arrived at {target} ({ZONES[target]['label']}).")

        return {
            "status": "arrived",
            "from": old_zone,
            "to": target,
            "label": ZONES[target]["label"],
            "travel_time_s": round(duration, 1),
            "battery": round(robot.battery, 1),
        }


# ── ScanAreaTool ─────────────────────────────────────────────────────

class ScanAreaTool(DefaultTool):
    """Scan the current zone for shelves, items, and obstacles."""

    name = "scan_area"
    parameters_schema: dict[str, Any] | None = {"type": "object", "properties": {}}
    description = (
        "Scan the robot's current zone using cameras and barcode reader. "
        "Returns shelves and items visible in this zone (2 seconds). "
        "No arguments required."
    )

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(2.0)
        robot = get_robot()
        drain_battery(2.0)
        zone = robot.zone
        zone_info = ZONES.get(zone, {})

        # Find shelves in this zone
        zone_shelves = {sid: s for sid, s in SHELVES.items() if s["zone"] == zone}

        # Find items on those shelves
        visible_items = []
        for item in robot.inventory:
            if item["shelf"] in zone_shelves:
                visible_items.append({
                    "sku": item["sku"],
                    "name": item["name"],
                    "shelf": item["shelf"],
                    "qty": item["qty"],
                    "weight_kg": item["weight"],
                })

        robot.log(f"Scanned {zone}: {len(zone_shelves)} shelves, {len(visible_items)} items visible.")

        return {
            "zone": zone,
            "label": zone_info.get("label", zone),
            "type": zone_info.get("type", "unknown"),
            "shelves": list(zone_shelves.keys()),
            "items": visible_items,
            "item_count": len(visible_items),
        }


# ── PickItemTool ─────────────────────────────────────────────────────

class PickItemTool(DefaultTool):
    """Pick up items from a shelf in the current zone."""

    name = "pick_item"
    description = (
        "Pick up items from a shelf using the robot arm (2.5 seconds). "
        "The robot must be in the same zone as the shelf. "
        "Args: sku (required), qty (optional, default 1)."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "sku": {"type": "string", "description": "Item SKU to pick up."},
            "qty": {"type": "integer", "description": "Number of units to pick (default 1)."},
        },
        "required": ["sku"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        sku = kwargs.get("sku", "").strip()
        qty = int(kwargs.get("qty", 1))
        if not sku:
            return {"error": "Missing required argument: sku"}
        if qty < 1:
            return {"error": "Quantity must be at least 1."}

        robot = get_robot()
        if robot.battery < 3:
            return {"error": "Battery too low for pick operation."}

        # Find the item in inventory
        inv_item = None
        for item in robot.inventory:
            if item["sku"].lower() == sku.lower():
                inv_item = item
                break
        if not inv_item:
            return {"error": f"SKU {sku} not found in inventory."}

        # Check robot is in the right zone
        shelf_id = inv_item["shelf"]
        shelf = SHELVES.get(shelf_id, {})
        if shelf.get("zone") != robot.zone:
            return {
                "error": f"Robot is in {robot.zone} but item is on shelf {shelf_id} in {shelf.get('zone')}. Navigate there first.",
            }

        # Check quantity
        if inv_item["qty"] < qty:
            return {"error": f"Only {inv_item['qty']} units of {sku} available, requested {qty}."}

        # Check payload capacity
        added_weight = inv_item["weight"] * qty
        if robot.payload_weight() + added_weight > robot.max_payload_weight:
            return {
                "error": f"Payload would exceed max weight ({robot.max_payload_weight}kg). "
                         f"Current: {round(robot.payload_weight(), 1)}kg, "
                         f"adding: {round(added_weight, 1)}kg.",
            }

        time.sleep(2.5)
        drain_battery(2.5)

        # Update state
        inv_item["qty"] -= qty
        robot.gripper_open = False
        robot.payload.append({
            "sku": sku,
            "name": inv_item["name"],
            "qty": qty,
            "weight": inv_item["weight"],
            "from_shelf": shelf_id,
        })
        robot.log(f"Picked {qty}x {inv_item['name']} ({sku}) from {shelf_id}.")

        return {
            "status": "picked",
            "sku": sku,
            "name": inv_item["name"],
            "qty": qty,
            "from_shelf": shelf_id,
            "payload_weight_kg": round(robot.payload_weight(), 2),
            "battery": round(robot.battery, 1),
        }


# ── PlaceItemTool ────────────────────────────────────────────────────

class PlaceItemTool(DefaultTool):
    """Place items from payload at the current location."""

    name = "place_item"
    description = (
        "Place items from the robot's payload at the current zone "
        "(2 seconds). Use this to deliver items to docks, shelves, "
        "or inspection bays. "
        "Args: sku (required), qty (optional, default all carried)."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "sku": {"type": "string", "description": "Item SKU to place."},
            "qty": {"type": "integer", "description": "Number of units to place."},
        },
        "required": ["sku"],
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        sku = kwargs.get("sku", "").strip()
        if not sku:
            return {"error": "Missing required argument: sku"}

        robot = get_robot()
        # Find item in payload
        payload_item = None
        for item in robot.payload:
            if item["sku"].lower() == sku.lower():
                payload_item = item
                break
        if not payload_item:
            return {"error": f"SKU {sku} not in robot's payload. Currently carrying: "
                             + (", ".join(f"{p['sku']} x{p['qty']}" for p in robot.payload) or "nothing")}

        qty = int(kwargs.get("qty", payload_item["qty"]))
        if qty > payload_item["qty"]:
            return {"error": f"Only carrying {payload_item['qty']} of {sku}, requested {qty}."}

        time.sleep(2.0)
        drain_battery(2.0)

        # Update payload
        payload_item["qty"] -= qty
        if payload_item["qty"] <= 0:
            robot.payload.remove(payload_item)
        if not robot.payload:
            robot.gripper_open = True

        zone_label = ZONES.get(robot.zone, {}).get("label", robot.zone)
        robot.log(f"Placed {qty}x {payload_item['name']} ({sku}) at {zone_label}.")

        return {
            "status": "placed",
            "sku": sku,
            "name": payload_item["name"],
            "qty": qty,
            "at_zone": robot.zone,
            "zone_label": zone_label,
            "remaining_payload": [
                {"sku": p["sku"], "name": p["name"], "qty": p["qty"]}
                for p in robot.payload
            ],
            "battery": round(robot.battery, 1),
        }


# ── CheckInventoryTool ───────────────────────────────────────────────

class CheckInventoryTool(DefaultTool):
    """Query warehouse inventory for item locations and quantities."""

    name = "check_inventory"
    description = (
        "Look up items in the warehouse inventory system (1.5 seconds). "
        "Args: sku (optional — search specific SKU), "
        "search (optional — search by name)."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "sku": {"type": "string", "description": "Specific SKU to look up."},
            "search": {"type": "string", "description": "Search term to match by name."},
        },
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(1.5)
        robot = get_robot()
        sku = kwargs.get("sku", "").strip().lower()
        search = kwargs.get("search", "").strip().lower()

        results = []
        for item in robot.inventory:
            if sku and item["sku"].lower() != sku:
                continue
            if search and search not in item["name"].lower() and search not in item["sku"].lower():
                continue
            shelf = SHELVES.get(item["shelf"], {})
            results.append({
                "sku": item["sku"],
                "name": item["name"],
                "shelf": item["shelf"],
                "zone": shelf.get("zone", "unknown"),
                "zone_label": ZONES.get(shelf.get("zone", ""), {}).get("label", "Unknown"),
                "qty": item["qty"],
                "weight_per_unit_kg": item["weight"],
            })

        if not results and (sku or search):
            return {"error": f"No items found matching: {sku or search}"}

        return {
            "total_skus": len(results),
            "items": results[:15],
        }


# ── CheckOrdersTool ──────────────────────────────────────────────────

class CheckOrdersTool(DefaultTool):
    """View pending orders that need fulfillment."""

    name = "check_orders"
    description = (
        "List pending orders that need to be fulfilled (1 second). "
        "Args: order_id (optional — look up a specific order)."
    )
    parameters_schema: dict[str, Any] | None = {
        "type": "object",
        "properties": {
            "order_id": {"type": "string", "description": "Specific order ID to look up."},
        },
    }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        time.sleep(1.0)
        robot = get_robot()
        order_id = kwargs.get("order_id", "").strip()

        if order_id:
            for order in robot.orders:
                if order["order_id"].lower() == order_id.lower():
                    # Enrich with item details
                    enriched_items = []
                    for oi in order["items"]:
                        inv = next((i for i in robot.inventory if i["sku"] == oi["sku"]), None)
                        enriched_items.append({
                            **oi,
                            "name": inv["name"] if inv else "Unknown",
                            "shelf": inv["shelf"] if inv else "Unknown",
                            "zone": SHELVES.get(inv["shelf"], {}).get("zone", "unknown") if inv else "unknown",
                            "in_stock": inv["qty"] if inv else 0,
                        })
                    return {
                        "order": {**order, "items": enriched_items},
                        "destination_label": ZONES.get(order["destination"], {}).get("label", order["destination"]),
                    }
            return {"error": f"Order {order_id} not found."}

        return {
            "pending_orders": len(robot.orders),
            "orders": [
                {
                    "order_id": o["order_id"],
                    "item_count": len(o["items"]),
                    "destination": o["destination"],
                    "priority": o["priority"],
                }
                for o in robot.orders
            ],
        }


# ── ChargeBatteryTool ────────────────────────────────────────────────

class ChargeBatteryTool(DefaultTool):
    """Charge the robot's battery at the charging station."""

    name = "charge_battery"
    description = (
        "Charge the robot's battery. The robot must be at the 'charging' "
        "zone. Charges 30% per cycle (3 seconds). No arguments required."
    )
    parameters_schema: dict[str, Any] | None = {"type": "object", "properties": {}}

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        robot = get_robot()
        if robot.zone != "charging":
            return {"error": "Robot must be at 'charging' zone to charge. Navigate there first."}

        time.sleep(3.0)
        old_battery = robot.battery
        robot.battery = min(100.0, robot.battery + 30.0)
        robot.log(f"Charged battery: {round(old_battery)}% → {round(robot.battery)}%.")

        return {
            "status": "charged",
            "battery_before": round(old_battery, 1),
            "battery_after": round(robot.battery, 1),
        }
