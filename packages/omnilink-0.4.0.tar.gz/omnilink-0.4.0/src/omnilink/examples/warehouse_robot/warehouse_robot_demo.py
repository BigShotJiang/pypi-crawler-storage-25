"""Warehouse Robot — long-horizon task execution demo.

An OmniLink agent controls a simulated warehouse robot that can
navigate zones, scan shelves, pick/place items, check inventory,
and fulfill orders.  Each physical action takes 1-4 seconds,
demonstrating multi-step tool chaining for complex missions.

Usage
-----
    export OMNI_KEY=omk_...
    python -m omnilink.examples.warehouse_robot.warehouse_robot_demo

Then open https://www.omnilink-agents.com/build and give the robot
a mission.  Press Ctrl+C to stop.
"""

from __future__ import annotations

import os
import pathlib
import signal
import sys
import threading
from typing import Any

LIB_PATH = pathlib.Path(__file__).resolve().parents[4] / "src"
if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from omnilink.tool_runner import ToolRunner
from omnilink.client import OmniLinkClient

from .robot_tools import (
    ChargeBatteryTool,
    CheckInventoryTool,
    CheckOrdersTool,
    NavigateToTool,
    PickItemTool,
    PlaceItemTool,
    RobotStatusTool,
    ScanAreaTool,
)
from .warehouse import reset_robot
from .visualizer import start_visualizer_server

# ── Configuration ─────────────────���───────────────────────��──────────

OMNI_KEY = os.environ.get("OMNI_KEY", "")
BASE_URL = os.environ.get(
    "OMNILINK_BASE_URL", "https://www.omnilink-agents.com"
)


# ── Runner ───────────────────────────────────────────────────────────


class WarehouseRobotRunner(ToolRunner):
    """An agent that controls a warehouse robot for order fulfillment."""

    agent_name = "warehouse-robot"
    display_name = "Warehouse Robot"
    engine = "g3-engine"
    tool_name = "execute_mission"
    tool_description = "Execute a warehouse robot mission using the available tools."
    commands = "stop_game"

    default_tools = [
        RobotStatusTool(),
        NavigateToTool(),
        ScanAreaTool(),
        PickItemTool(),
        PlaceItemTool(),
        CheckInventoryTool(),
        CheckOrdersTool(),
        ChargeBatteryTool(),
    ]

    def get_profile_settings(self) -> dict[str, Any]:
        settings = super().get_profile_settings()
        settings["mainTask"] = (
            "You are a warehouse robot controller. You operate a mobile robot "
            "in a warehouse with these zones:\n"
            "  - dock-A: Receiving Dock A (incoming goods)\n"
            "  - dock-B: Shipping Dock B (outgoing orders)\n"
            "  - aisle-1: Electronics storage\n"
            "  - aisle-2: Hardware storage\n"
            "  - aisle-3: Office Supplies storage\n"
            "  - staging: Staging area for sorting\n"
            "  - charging: Charging station\n"
            "  - inspection: QA Inspection Bay\n\n"
            "Available tools:\n"
            "  - robot_status: check position, battery, payload\n"
            "  - navigate_to: move robot to a zone (2-4s travel time)\n"
            "  - scan_area: scan current zone for shelves and items (2s)\n"
            "  - pick_item: pick items from a shelf (2.5s, needs correct zone)\n"
            "  - place_item: place items at current location (2s)\n"
            "  - check_inventory: look up item locations and quantities\n"
            "  - check_orders: view pending orders to fulfill\n"
            "  - charge_battery: charge 30% at charging station (3s)\n\n"
            "IMPORTANT RULES:\n"
            "1. Always check robot_status first to know your position and battery.\n"
            "2. You must navigate_to a zone before you can scan, pick, or place there.\n"
            "3. Monitor battery — if below 20%, navigate to charging and charge.\n"
            "4. The robot has a 25kg payload limit — plan picks accordingly.\n"
            "5. For order fulfillment: check the order, locate items, navigate to "
            "each aisle, pick items, then navigate to the destination and place them.\n\n"
            "Be methodical. Report what you're doing at each step."
        )
        settings["maxToolRounds"] = 10
        return settings

    def get_state(self) -> dict[str, Any]:
        return {}

    def execute_action(self, state: dict[str, Any]) -> None:
        pass

    def state_summary(self, state: dict[str, Any]) -> str:
        return "idle"

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return True


# ── Entry point ──────────────────────────────────────────────────────


def main() -> None:
    if not OMNI_KEY:
        print("Set OMNI_KEY before running:  export OMNI_KEY=omk_...")
        sys.exit(1)

    # Reset warehouse state for a clean demo.
    reset_robot()

    runner = WarehouseRobotRunner()
    runner.omni_key = OMNI_KEY
    runner.base_url = BASE_URL

    client = OmniLinkClient(omni_key=OMNI_KEY, base_url=BASE_URL, timeout=60)
    runner._client = client
    runner._conversation_history = []
    runner._activity_log = []

    port = runner._start_tool_server()
    runner.tool_callback_url = f"http://127.0.0.1:{port}/tool"

    # Start the live warehouse visualizer.
    viz_port = start_visualizer_server()

    runner._ensure_profile(client)

    try:
        client.set_memory(runner._memory_agent_key(), [])
    except Exception:
        pass

    print()
    print("=" * 60)
    print("  Warehouse Robot — Long-Horizon Task Demo")
    print("=" * 60)
    print()
    print(f"  Tool server:  http://127.0.0.1:{port}/tool")
    print(f"  Activity log: http://127.0.0.1:{port}/activity")
    print(f"  LIVE VIEW:    http://127.0.0.1:{viz_port}/")
    print()
    print(f"  Open the UI:  {BASE_URL}/build")
    print()
    print("  Robot tools (each simulates physical action time):")
    print("    robot_status      1.0s   current state")
    print("    navigate_to       2-4s   move between zones")
    print("    scan_area         2.0s   scan shelves & items")
    print("    pick_item         2.5s   pick from shelf")
    print("    place_item        2.0s   place at location")
    print("    check_inventory   1.5s   look up items")
    print("    check_orders      1.0s   view pending orders")
    print("    charge_battery    3.0s   charge 30%")
    print()
    print("  Try these missions:")
    print('    "What orders are pending?"')
    print('    "Fulfill order ORD-4402"')
    print('    "Find the monitors and bring one to inspection"')
    print('    "Do a full inventory scan of all aisles"')
    print('    "Check battery, charge if needed, then fulfill')
    print('     the express order"')
    print()
    print("  Press Ctrl+C to stop.")
    print("=" * 60)
    print()

    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    try:
        signal.signal(signal.SIGBREAK, lambda *_: stop.set())
    except AttributeError:
        pass

    stop.wait()

    print()
    print("  Shutting down.")


if __name__ == "__main__":
    main()
