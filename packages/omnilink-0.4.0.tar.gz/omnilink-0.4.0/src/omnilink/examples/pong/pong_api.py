"""HTTP client for the Pong game server (via http_proxy.py)."""

from __future__ import annotations

import json
from typing import Any

import requests

SERVER_URL = "http://127.0.0.1:5002"

# Reuse a persistent session for connection pooling.
_session = requests.Session()


def get_state() -> dict[str, Any]:
    """Fetch the current game state from the HTTP proxy.

    Returns the parsed game state dict with keys: ball (x, y, vx, vy),
    leftPaddleY, rightPaddleY, score (left, right).
    """
    r = _session.get(f"{SERVER_URL}/data", timeout=2)
    data = r.json()
    payload = data.get("payload", "{}")
    if isinstance(payload, str):
        try:
            return json.loads(payload)
        except (json.JSONDecodeError, ValueError):
            raise RuntimeError(f"Game not ready: {payload}")
    return payload


def send_action(action: str) -> None:
    """Send a single action (UP, DOWN, or STOP) to the game."""
    _session.post(
        f"{SERVER_URL}/callback",
        json={"action": action},
        timeout=2,
    )
