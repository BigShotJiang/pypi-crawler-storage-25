"""Play Pong using OmniLink tool calling.

The AI agent calls the ``make_move`` tool, which acts as a local
Pong AI controller.  The model never sees the game -- it simply
triggers the tool.  The tool reads the game state, predicts the ball
trajectory, and moves the paddle accordingly.

This keeps API credit usage to a minimum (one call to kick off).

Usage
-----
    python -m omnilink.examples.pong.play_pong
"""

from __future__ import annotations

from typing import Any

from omnilink.tool_runner import ToolRunner

from .pong_api import get_state, send_action, SERVER_URL
from .pong_engine import decide_action, state_summary


class PongRunner(ToolRunner):
    agent_name = "pong-agent"
    display_name = "Pong"
    tool_description = "Move paddle."
    game_server_url = SERVER_URL
    query_tools = [
        {"name": "get_score", "description": "Returns score for both players.", "parameters": {"type": "object", "properties": {}}},
        {"name": "get_ball", "description": "Returns ball position and velocity.", "parameters": {"type": "object", "properties": {}}},
        {"name": "get_paddles", "description": "Returns paddle positions.", "parameters": {"type": "object", "properties": {}}},
    ]

    def __init__(self) -> None:
        self._last_left_score = 0
        self._last_right_score = 0

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        state = get_state()
        if tool_name == "get_score":
            return state.get("score", {"left": 0, "right": 0})
        if tool_name == "get_ball":
            return {"ball": state.get("ball", {})}
        if tool_name == "get_paddles":
            return {"left": state.get("left_paddle", {}), "right": state.get("right_paddle", {})}
        return {"error": f"Unknown tool: {tool_name}"}

    def on_start(self) -> None:
        try:
            send_action("RESUME")
            print("  Game resumed.")
        except Exception:
            pass

    def get_state(self) -> dict[str, Any]:
        return get_state()

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return False

    def execute_action(self, state: dict[str, Any]) -> None:
        send_action(decide_action(state))

    def state_summary(self, state: dict[str, Any]) -> str:
        return state_summary(state)

    def log_events(self, state: dict[str, Any]) -> None:
        score = state.get("score", {})
        left_score = score.get("left", 0)
        right_score = score.get("right", 0)

        if left_score != self._last_left_score:
            print(f"  Agent scored! {left_score} - {right_score}")
            self._last_left_score = left_score
        if right_score != self._last_right_score:
            print(f"  Opponent scored. {left_score} - {right_score}")
            self._last_right_score = right_score


if __name__ == "__main__":
    PongRunner().run()
