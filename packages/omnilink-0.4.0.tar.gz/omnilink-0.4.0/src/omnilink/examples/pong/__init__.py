"""Pong benchmark — full ball trajectory simulation with opponent AI modelling."""
