"""Local Pong AI engine -- ball prediction and paddle control.

This module is the ``make_move`` tool: given the current game state it
simulates the ball trajectory (including wall bounces and right-paddle
deflection) to predict where the ball will intercept the left paddle
column and returns the optimal paddle action (UP, DOWN, or STOP).
"""

from __future__ import annotations

from typing import Any

# Game constants (must match pong.py).
WIDTH = 640
HEIGHT = 480
PADDLE_WIDTH = 10
PADDLE_HEIGHT = 80
PADDLE_X = 10            # Left paddle X position.
RIGHT_PADDLE_X = WIDTH - PADDLE_WIDTH - 10  # Right paddle X position.
BALL_RADIUS = 8
RIGHT_AI_SPEED = 3.5     # Right paddle AI speed (px/frame).
BALL_SPEED_X = 3         # Horizontal ball speed (constant magnitude).
DEADZONE = 2             # Pixels of tolerance before moving the paddle.
MAX_SIM_STEPS = 3000     # Safety cap on simulation iterations.
SIM_DT = 1.0             # Simulate one frame per step.

# Left paddle geometry for intercept target.
LEFT_PADDLE_RIGHT = PADDLE_X + PADDLE_WIDTH + BALL_RADIUS


# -- Ball trajectory simulation ------------------------------------------------

def _simulate_landing(state: dict[str, Any]) -> float:
    """Simulate the ball forward until it reaches the left paddle column.

    Uses integer truncation to match pygame.Rect behaviour exactly.
    Handles top/bottom wall bounces AND right-paddle deflection so the
    prediction is accurate across multiple volleys.

    Returns the predicted Y centre of the ball when it reaches the
    left paddle column.
    """
    ball = state.get("ball", {})

    # pygame.Rect stores integer positions; velocities are floats.
    # We mirror that: bx/by are ints, vx/vy are floats.
    bx = int(ball.get("x", WIDTH // 2))
    by = int(ball.get("y", HEIGHT // 2))
    vx = float(ball.get("vx", 0))
    vy = float(ball.get("vy", 0))

    # Ball rect edges (ball is a Rect with origin at top-left, size 2*BALL_RADIUS).
    # centerx = ball_rect.x + BALL_RADIUS, so ball_rect.x = centerx - BALL_RADIUS
    # The game state reports centerx/centery.
    ball_rect_x = bx - BALL_RADIUS
    ball_rect_y = by - BALL_RADIUS
    BALL_SIZE = BALL_RADIUS * 2

    # Right paddle state.
    right_paddle_y = int(state.get("rightPaddleY", HEIGHT // 2 - PADDLE_HEIGHT // 2))

    # Right paddle collision edge: right_paddle.left = RIGHT_PADDLE_X
    # Left paddle collision edge: left_paddle.right = PADDLE_X + PADDLE_WIDTH = 20

    for _ in range(MAX_SIM_STEPS):
        # Check if ball reached left paddle column heading left.
        # Game checks: ball.left <= left_paddle.right (= 20) and vx < 0
        if ball_rect_x <= PADDLE_X + PADDLE_WIDTH and vx < 0:
            return ball_rect_y + BALL_RADIUS  # centery

        # Step forward -- truncate to int like pygame.Rect does.
        ball_rect_x = int(ball_rect_x + vx)
        ball_rect_y = int(ball_rect_y + vy)

        # Simulate right paddle AI tracking (follows ball centery).
        ball_cy = ball_rect_y + BALL_RADIUS
        rp_center = right_paddle_y + PADDLE_HEIGHT // 2
        target_y = ball_cy - PADDLE_HEIGHT // 2
        if rp_center < target_y - 4:
            right_paddle_y += int(min(RIGHT_AI_SPEED, target_y - right_paddle_y))
        elif rp_center > target_y + 4:
            right_paddle_y -= int(min(RIGHT_AI_SPEED, right_paddle_y - target_y))
        if right_paddle_y < 0:
            right_paddle_y = 0
        if right_paddle_y + PADDLE_HEIGHT > HEIGHT:
            right_paddle_y = HEIGHT - PADDLE_HEIGHT

        # Top/bottom wall bounces (game uses ball.top / ball.bottom).
        if ball_rect_y <= 0:
            ball_rect_y = 0
            vy = abs(vy)
        elif ball_rect_y + BALL_SIZE >= HEIGHT:
            ball_rect_y = HEIGHT - BALL_SIZE
            vy = -abs(vy)

        # Right paddle collision.
        # Game: ball.right >= right_paddle.left and vx > 0
        #        and ball.bottom > right_paddle.top and ball.top < right_paddle.bottom
        ball_right = ball_rect_x + BALL_SIZE
        if ball_right >= RIGHT_PADDLE_X and vx > 0:
            ball_bottom = ball_rect_y + BALL_SIZE
            ball_top = ball_rect_y
            if ball_bottom > right_paddle_y and ball_top < right_paddle_y + PADDLE_HEIGHT:
                # Hit -- deflect with same physics as game.
                ball_rect_x = RIGHT_PADDLE_X - BALL_SIZE
                vx = -abs(vx)
                delta = (ball_rect_y + BALL_RADIUS) - (right_paddle_y + PADDLE_HEIGHT // 2)
                vy = delta * 0.1
            else:
                # Missed -- agent scores, return center.
                return HEIGHT / 2

    return ball_rect_y + BALL_RADIUS


def predict_ball_y(state: dict[str, Any]) -> float:
    """Return the predicted Y where the ball will meet the left paddle column.

    Always simulates the full trajectory, even when the ball is heading
    right, so the paddle pre-positions for the return volley.
    """
    return _simulate_landing(state)


# -- Action decision -----------------------------------------------------------

def decide_action(state: dict[str, Any]) -> str:
    """Decide the paddle action based on the current game state.

    Returns ``'UP'``, ``'DOWN'``, or ``'STOP'``.
    """
    landing_y = predict_ball_y(state)
    paddle_y = state.get("leftPaddleY", HEIGHT / 2 - PADDLE_HEIGHT / 2)
    paddle_center = paddle_y + PADDLE_HEIGHT / 2

    if paddle_center < landing_y - DEADZONE:
        return "DOWN"
    elif paddle_center > landing_y + DEADZONE:
        return "UP"
    else:
        return "STOP"


# -- State summary (for OmniLink memory) --------------------------------------

def state_summary(state: dict[str, Any]) -> str:
    """Build a concise text summary of the current game state."""
    ball = state.get("ball", {})
    score = state.get("score", {})
    left_score = score.get("left", 0)
    right_score = score.get("right", 0)
    left_paddle_y = state.get("leftPaddleY", 0)
    right_paddle_y = state.get("rightPaddleY", 0)

    ball_x = ball.get("x", 0)
    ball_y = ball.get("y", 0)
    ball_vx = ball.get("vx", 0)
    ball_vy = ball.get("vy", 0)

    return (
        f"Score: Agent {left_score} - {right_score} Opponent\n"
        f"Ball position: ({ball_x:.0f}, {ball_y:.0f})\n"
        f"Ball velocity: ({ball_vx:.1f}, {ball_vy:.1f})\n"
        f"Agent paddle Y: {left_paddle_y:.0f}\n"
        f"Opponent paddle Y: {right_paddle_y:.0f}"
    )
