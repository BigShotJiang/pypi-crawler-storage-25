"""Local chess engine — minimax with alpha-beta pruning.

This module is the ``make_move`` tool: given a board position it picks
the best move using a depth-limited search with piece-square tables.
"""

from __future__ import annotations

import math
import random

import chess

# ── Configuration ─────────────────────────────────────────────────────
SEARCH_DEPTH = 3

# ── Piece values for evaluation ──────────────────────────────────────
PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 0,
}

# Piece-square tables (white perspective, flipped for black).
PAWN_TABLE = [
     0,  0,  0,  0,  0,  0,  0,  0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
     5,  5, 10, 25, 25, 10,  5,  5,
     0,  0,  0, 20, 20,  0,  0,  0,
     5, -5,-10,  0,  0,-10, -5,  5,
     5, 10, 10,-20,-20, 10, 10,  5,
     0,  0,  0,  0,  0,  0,  0,  0,
]

KNIGHT_TABLE = [
    -50,-40,-30,-30,-30,-30,-40,-50,
    -40,-20,  0,  0,  0,  0,-20,-40,
    -30,  0, 10, 15, 15, 10,  0,-30,
    -30,  5, 15, 20, 20, 15,  5,-30,
    -30,  0, 15, 20, 20, 15,  0,-30,
    -30,  5, 10, 15, 15, 10,  5,-30,
    -40,-20,  0,  5,  5,  0,-20,-40,
    -50,-40,-30,-30,-30,-30,-40,-50,
]

PST = {
    chess.PAWN: PAWN_TABLE,
    chess.KNIGHT: KNIGHT_TABLE,
}


# ── Evaluation ────────────────────────────────────────────────────────

def evaluate(board: chess.Board) -> float:
    """Static evaluation of the board from White's perspective."""
    if board.is_checkmate():
        return -9999 if board.turn == chess.WHITE else 9999
    if board.is_stalemate() or board.is_insufficient_material():
        return 0

    score = 0.0
    for sq in chess.SQUARES:
        piece = board.piece_at(sq)
        if piece is None:
            continue
        value = PIECE_VALUES.get(piece.piece_type, 0)
        pst = PST.get(piece.piece_type)
        if pst:
            idx = sq if piece.color == chess.WHITE else chess.square_mirror(sq)
            value += pst[63 - idx]
        score += value if piece.color == chess.WHITE else -value

    # Small bonus for mobility.
    if board.turn == chess.WHITE:
        score += len(list(board.legal_moves)) * 2
    else:
        score -= len(list(board.legal_moves)) * 2

    return score


def _order_moves(board: chess.Board) -> list[chess.Move]:
    """Order moves for better alpha-beta pruning (captures first)."""
    moves = list(board.legal_moves)
    scored = []
    for m in moves:
        s = 0
        if board.is_capture(m):
            victim = board.piece_type_at(m.to_square)
            attacker = board.piece_type_at(m.from_square)
            s = PIECE_VALUES.get(victim, 0) * 10 - PIECE_VALUES.get(attacker, 0)
        if m.promotion:
            s += 800
        if board.gives_check(m):
            s += 50
        scored.append((s, m))
    scored.sort(key=lambda x: -x[0])
    return [m for _, m in scored]


def minimax(
    board: chess.Board,
    depth: int,
    alpha: float,
    beta: float,
    maximizing: bool,
) -> float:
    """Minimax with alpha-beta pruning."""
    if depth == 0 or board.is_game_over():
        return evaluate(board)

    if maximizing:
        max_eval = -math.inf
        for move in _order_moves(board):
            board.push(move)
            val = minimax(board, depth - 1, alpha, beta, False)
            board.pop()
            max_eval = max(max_eval, val)
            alpha = max(alpha, val)
            if beta <= alpha:
                break
        return max_eval
    else:
        min_eval = math.inf
        for move in _order_moves(board):
            board.push(move)
            val = minimax(board, depth - 1, alpha, beta, True)
            board.pop()
            min_eval = min(min_eval, val)
            beta = min(beta, val)
            if beta <= alpha:
                break
        return min_eval


def pick_move(board: chess.Board, depth: int | None = None) -> chess.Move:
    """Use minimax to pick the best move for the current side."""
    depth = depth or SEARCH_DEPTH
    best_move = None
    maximizing = board.turn == chess.WHITE

    if maximizing:
        best_val = -math.inf
        for move in _order_moves(board):
            board.push(move)
            val = minimax(board, depth - 1, -math.inf, math.inf, False)
            board.pop()
            if val > best_val:
                best_val = val
                best_move = move
    else:
        best_val = math.inf
        for move in _order_moves(board):
            board.push(move)
            val = minimax(board, depth - 1, -math.inf, math.inf, True)
            board.pop()
            if val < best_val:
                best_val = val
                best_move = move

    return best_move or random.choice(list(board.legal_moves))


def material_count(board: chess.Board) -> dict[str, int]:
    """Return material totals for each side."""
    white = black = 0
    for sq in chess.SQUARES:
        p = board.piece_at(sq)
        if p is None:
            continue
        val = PIECE_VALUES.get(p.piece_type, 0)
        if p.color == chess.WHITE:
            white += val
        else:
            black += val
    return {"white": white, "black": black}
