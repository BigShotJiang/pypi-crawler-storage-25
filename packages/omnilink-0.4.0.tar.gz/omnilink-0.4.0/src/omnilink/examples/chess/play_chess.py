"""Play a chess game using OmniLink tool calling.

The AI agent calls the ``make_move`` tool, which acts as a local chess
engine.  The model never sees the board — it simply triggers the tool.
The tool evaluates the position, picks the best move, and relays it to
the 3D chess UI.

Usage
-----
    python -m omnilink.examples.chess.play_chess
"""

from __future__ import annotations

from typing import Any

import chess
from omnilink.tool_runner import ToolRunner

from .chess_api import move_piece as server_move_piece
from .chess_engine import pick_move, material_count

MAX_MOVES = 150
SEARCH_DEPTH = 3
MOVE_DELAY = 3

PIECE_FROM_SYMBOL = {
    chess.PAWN: "pawn",
    chess.KNIGHT: "knight",
    chess.BISHOP: "bishop",
    chess.ROOK: "rook",
    chess.QUEEN: "queen",
    chess.KING: "king",
}


def _build_pgn(game_log: list[str]) -> str:
    pairs = []
    for i in range(0, len(game_log), 2):
        pair = f"{i // 2 + 1}. {game_log[i]}"
        if i + 1 < len(game_log):
            pair += f" {game_log[i + 1]}"
        pairs.append(pair)
    return " ".join(pairs)


def _relay_to_ui(board: chess.Board, move: chess.Move) -> None:
    color = "white" if board.turn == chess.WHITE else "black"
    piece_type = board.piece_type_at(move.from_square)
    piece = PIECE_FROM_SYMBOL.get(piece_type, "pawn")
    from_sq = chess.square_name(move.from_square)
    to_sq = chess.square_name(move.to_square)
    try:
        server_move_piece(color, piece, from_sq, to_sq)
    except Exception as e:
        print(f"  [UI] Could not relay move: {e}")


class ChessRunner(ToolRunner):
    agent_name = "chess-agent"
    display_name = "Chess"
    tool_description = "Run the chess engine and play the next move."
    poll_interval = MOVE_DELAY
    ask_every = 30
    memory_every = 12
    query_tools = [
        {"name": "get_position", "description": "Returns the current board position (FEN) and whose turn it is.", "parameters": {"type": "object", "properties": {}}},
        {"name": "get_material", "description": "Returns material count for both sides.", "parameters": {"type": "object", "properties": {}}},
        {"name": "get_moves", "description": "Returns the move history in PGN notation.", "parameters": {"type": "object", "properties": {}}},
        {"name": "get_status", "description": "Returns game status: in progress, check, checkmate, or draw.", "parameters": {"type": "object", "properties": {}}},
    ]

    def __init__(self) -> None:
        self._board = chess.Board()
        self._game_log: list[str] = []
        self._move_number = 0

    def execute_query_tool(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        board = self._board
        if tool_name == "get_position":
            turn = "White" if board.turn == chess.WHITE else "Black"
            return {"fen": board.fen(), "turn": turn, "move_number": self._move_number}
        if tool_name == "get_material":
            mat = material_count(board)
            return {"white": mat["white"] // 100, "black": mat["black"] // 100}
        if tool_name == "get_moves":
            return {"pgn": _build_pgn(self._game_log), "total_moves": len(self._game_log)}
        if tool_name == "get_status":
            if board.is_checkmate():
                winner = "Black" if board.turn == chess.WHITE else "White"
                return {"status": "checkmate", "winner": winner}
            if board.is_stalemate():
                return {"status": "stalemate"}
            if board.is_check():
                return {"status": "check"}
            if board.is_game_over():
                return {"status": "draw"}
            return {"status": "in_progress", "move_number": self._move_number}
        return {"error": f"Unknown tool: {tool_name}"}

    def on_start(self) -> None:
        print(self._board)
        print()

    def get_state(self) -> dict[str, Any]:
        board = self._board
        outcome = board.outcome()
        return {
            "board": board,
            "game_log": list(self._game_log),
            "move_number": self._move_number,
            "is_over": board.is_game_over() or self._move_number >= MAX_MOVES,
            "outcome": outcome,
        }

    def execute_action(self, state: dict[str, Any]) -> None:
        board = self._board
        if board.is_game_over() or self._move_number >= MAX_MOVES:
            return

        move = pick_move(board, SEARCH_DEPTH)
        san = board.san(move)

        _relay_to_ui(board, move)
        board.push(move)
        self._move_number += 1
        self._game_log.append(san)

        if board.turn == chess.WHITE:
            print(f"  {(self._move_number + 1) // 2}... {san}")
        else:
            print(f"  {(self._move_number + 1) // 2}. {san}", end="  ")

        if self._move_number % 4 == 0:
            print()
            print(board)
            print()

    def log_events(self, state: dict[str, Any]) -> None:
        pass

    def state_summary(self, state: dict[str, Any]) -> str:
        board = self._board
        game_log = self._game_log
        mat = material_count(board)
        turn = "White" if board.turn == chess.WHITE else "Black"
        diff = mat["white"] - mat["black"]
        if diff > 50:
            advantage = f"White is ahead by {diff // 100:.0f} points of material."
        elif diff < -50:
            advantage = f"Black is ahead by {-diff // 100:.0f} points of material."
        else:
            advantage = "Material is roughly equal."

        check = " The king is in check!" if board.is_check() else ""
        pgn = _build_pgn(game_log)

        return (
            f"Current position (FEN): {board.fen()}\n"
            f"Move {len(game_log)} — {turn} to move.{check}\n"
            f"Material — White: {mat['white']//100} pts, Black: {mat['black']//100} pts. {advantage}\n"
            f"Moves so far: {pgn}"
        )

    def is_game_over(self, state: dict[str, Any]) -> bool:
        return state["is_over"]

    def game_over_message(self, state: dict[str, Any]) -> str:
        outcome = state["outcome"]
        if outcome:
            if outcome.winner is None:
                reason = outcome.termination.name.replace("_", " ").title()
                return f"Draw — {reason}"
            winner = "White" if outcome.winner == chess.WHITE else "Black"
            reason = outcome.termination.name.replace("_", " ").title()
            return f"{winner} wins — {reason}"
        return f"Game stopped after {state['move_number']} moves (agent called stop_game)."


if __name__ == "__main__":
    ChessRunner().run()
