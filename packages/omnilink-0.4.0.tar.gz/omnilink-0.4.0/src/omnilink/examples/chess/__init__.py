"""Chess benchmark — minimax with alpha-beta pruning."""
