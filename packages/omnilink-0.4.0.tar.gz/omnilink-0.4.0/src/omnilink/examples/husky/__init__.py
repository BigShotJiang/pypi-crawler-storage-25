"""Husky demo -- single robot waypoint navigation with PyBullet physics."""
