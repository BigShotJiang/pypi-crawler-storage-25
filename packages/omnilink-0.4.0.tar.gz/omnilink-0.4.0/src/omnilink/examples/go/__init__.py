"""Go benchmark — heuristic-based move selection on a 19x19 board."""
