"""Montezuma benchmark — BFS pathfinding with enemy avoidance."""
