# sheafadapter

`sheafadapter` is the official Python package namespace for lightweight adapter
registry helpers used by the SheafLab project.

This initial public release provides adapter records, target matching, and
basic registry selection for plugging external domains into a compact workflow.

