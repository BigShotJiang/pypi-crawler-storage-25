import unittest

from sheafadapter import AdapterSpec, matching_adapters, registry_index, select_adapter


class AdapterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.adapters = [
            AdapterSpec("csv-to-text", "csv", "text", 1),
            AdapterSpec("json-to-text", "json", "text", 2),
        ]

    def test_matching_adapters(self) -> None:
        self.assertEqual([adapter.key for adapter in matching_adapters(self.adapters, target="text")], ["json-to-text", "csv-to-text"])

    def test_select_adapter(self) -> None:
        self.assertEqual(select_adapter(self.adapters, source="json", target="text").key, "json-to-text")

    def test_registry_index(self) -> None:
        self.assertEqual(registry_index(self.adapters), {"text": ["csv-to-text", "json-to-text"]})

