from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AdapterSpec:
    key: str
    source: str
    target: str
    priority: int = 0


def matching_adapters(adapters: list[AdapterSpec], *, target: str) -> list[AdapterSpec]:
    return sorted([adapter for adapter in adapters if adapter.target == target], key=lambda adapter: (-adapter.priority, adapter.key))


def select_adapter(adapters: list[AdapterSpec], *, source: str, target: str) -> AdapterSpec | None:
    matches = [adapter for adapter in adapters if adapter.source == source and adapter.target == target]
    matches.sort(key=lambda adapter: (-adapter.priority, adapter.key))
    return matches[0] if matches else None


def registry_index(adapters: list[AdapterSpec]) -> dict[str, list[str]]:
    index: dict[str, list[str]] = {}
    for adapter in adapters:
        index.setdefault(adapter.target, []).append(adapter.key)
    return {target: sorted(keys) for target, keys in index.items()}

