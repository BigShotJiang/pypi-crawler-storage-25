def project_info() -> dict[str, str]:
    return {
        "name": "sheafadapter",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheafadapter-python",
    }

