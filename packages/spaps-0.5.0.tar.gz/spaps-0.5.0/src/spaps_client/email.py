"""
Email client for SPAPS email service.

Provides methods to send emails via templates, list templates,
get template details, and preview rendered templates.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx
from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "EmailError",
    "EmailSendResult",
    "EmailTemplate",
    "EmailTemplatePreview",
    "TemplateVariable",
    "EmailClient",
]


class EmailError(Exception):
    """Raised when the SPAPS email API returns an error."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_code: Optional[str] = None,
        response: Optional[httpx.Response] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.response = response
        self.request_id = request_id


class EmailSendResult(BaseModel):
    """Result of sending an email."""

    model_config = ConfigDict(extra="ignore")

    success: bool = True
    message_id: Optional[str] = None
    error: Optional[str] = None


class TemplateVariable(BaseModel):
    """Variable definition for an email template."""

    model_config = ConfigDict(extra="ignore")

    name: str
    required: bool = False
    description: Optional[str] = None


class EmailTemplate(BaseModel):
    """Email template definition."""

    model_config = ConfigDict(extra="ignore")

    id: str
    application_id: Optional[str] = None
    template_key: str
    name: str
    description: Optional[str] = None
    subject: str
    html_body: Optional[str] = None
    text_body: Optional[str] = None
    from_email: Optional[str] = None
    from_name: Optional[str] = None
    reply_to: Optional[str] = None
    variables: List[TemplateVariable] = Field(default_factory=list)
    sample_context: Optional[Dict[str, Any]] = None
    category: Optional[str] = None
    is_active: bool = True
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class EmailTemplatePreview(BaseModel):
    """Rendered email template preview."""

    model_config = ConfigDict(extra="ignore")

    subject: str
    html: str
    text: Optional[str] = None


class EmailClient:
    """Client wrapper for SPAPS email endpoints."""

    EMAIL_PREFIX = "/api/email"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        client: Optional[httpx.Client] = None,
        request_timeout: float | httpx.Timeout = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._client = client or httpx.Client(base_url=self.base_url, timeout=request_timeout)
        self._owns_client = client is None

    def __enter__(self) -> "EmailClient":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:  # type: ignore[override]
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    # =========================================================================
    # Public API
    # =========================================================================

    def send(
        self,
        *,
        template_key: str,
        to: str,
        context: Dict[str, Any],
        user_id: Optional[str] = None,
    ) -> EmailSendResult:
        """
        Send an email using a template.

        Args:
            template_key: The template identifier (e.g., 'enrollment_reminder')
            to: Recipient email address
            context: Template variables to render
            user_id: Optional user ID for logging purposes

        Returns:
            EmailSendResult with success status and message_id if successful
        """
        payload: Dict[str, Any] = {
            "template_key": template_key,
            "to": to,
            "context": context,
        }
        if user_id is not None:
            payload["user_id"] = user_id

        data = self._post("/send", json=payload)
        return EmailSendResult.model_validate(data)

    def list_templates(self) -> List[EmailTemplate]:
        """
        List all email templates for the application.

        Returns:
            List of EmailTemplate objects
        """
        data = self._get("/templates")
        templates_list = data.get("templates", data)
        if isinstance(templates_list, list):
            return [EmailTemplate.model_validate(item) for item in templates_list]
        return []

    def get_template(self, template_key: str) -> EmailTemplate:
        """
        Get a single template by key.

        Args:
            template_key: The template identifier

        Returns:
            EmailTemplate with full details
        """
        data = self._get(f"/templates/{template_key}")
        return EmailTemplate.model_validate(data)

    def preview_template(
        self,
        template_key: str,
        *,
        context: Optional[Dict[str, Any]] = None,
    ) -> EmailTemplatePreview:
        """
        Preview a rendered template.

        Args:
            template_key: The template identifier
            context: Optional custom context variables. If not provided,
                     the template's sample_context will be used.

        Returns:
            EmailTemplatePreview with rendered subject, html, and text
        """
        if context is not None:
            # POST with custom context
            data = self._post(
                f"/templates/{template_key}/preview",
                json={"context": context},
            )
        else:
            # GET uses template's sample_context
            data = self._get(f"/templates/{template_key}/preview")

        # SPAPS wraps preview in {"preview": {...}} - extract it
        preview_data = data.get("preview", data)
        return EmailTemplatePreview.model_validate(preview_data)

    # =========================================================================
    # Internal helpers
    # =========================================================================

    def _get(self, path: str) -> Dict[str, Any]:
        response = self._client.get(
            f"{self.EMAIL_PREFIX}{path}",
            headers=self._build_headers(),
        )
        return self._parse_response(response)

    def _post(
        self,
        path: str,
        *,
        json: Dict[str, Any],
    ) -> Dict[str, Any]:
        response = self._client.post(
            f"{self.EMAIL_PREFIX}{path}",
            json=json,
            headers=self._build_headers(),
        )
        return self._parse_response(response)

    def _build_headers(self) -> Dict[str, str]:
        return {
            "X-API-Key": self.api_key,
        }

    def _parse_response(self, response: httpx.Response) -> Dict[str, Any]:
        if response.status_code >= 400:
            raise self._build_error(response)
        payload = response.json()
        return payload.get("data", payload)

    @staticmethod
    def _build_error(response: httpx.Response) -> EmailError:
        try:
            payload = response.json()
        except ValueError:  # pragma: no cover
            payload = {}
        error_info = payload.get("error", {})
        message = error_info.get("message") or response.text or "Email request failed"
        request_id = (
            response.headers.get("x-request-id")
            or payload.get("metadata", {}).get("request_id")
        )
        return EmailError(
            message,
            status_code=response.status_code,
            error_code=error_info.get("code"),
            response=response,
            request_id=request_id,
        )
