"""Async issue reporting client."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .issue_reporting import (
    IssueReport,
    IssueReportStatusResult,
    IssueReportsListResult,
    IssueReportingError,
)


class AsyncIssueReportingClient:
    """Async wrapper for shared issue-reporting endpoints."""

    PREFIX = "/api/v1/issue-reports"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        access_token: Optional[str] = None,
        client: Optional[httpx.AsyncClient] = None,
        request_timeout: float | httpx.Timeout = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.access_token = access_token
        self._client = client or httpx.AsyncClient(base_url=self.base_url, timeout=request_timeout)
        self._owns_client = client is None

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def create_issue_report(
        self,
        *,
        target: Dict[str, Any],
        note: str,
        reporter_role_hint: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        body: Dict[str, Any] = {"target": target, "note": note}
        if reporter_role_hint is not None:
            body["reporter_role_hint"] = reporter_role_hint
        payload = await self._post("", json=body, access_token_override=access_token_override)
        return IssueReport.model_validate(payload)

    async def list_issue_reports(
        self,
        *,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        access_token_override: Optional[str] = None,
    ) -> IssueReportsListResult:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        payload = await self._get("", params=params, access_token_override=access_token_override)
        return IssueReportsListResult.model_validate(payload)

    async def get_issue_report_status(
        self,
        *,
        access_token_override: Optional[str] = None,
    ) -> IssueReportStatusResult:
        payload = await self._get("/status", params=None, access_token_override=access_token_override)
        return IssueReportStatusResult.model_validate(payload)

    async def get_issue_report(
        self,
        *,
        issue_report_id: str,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        payload = await self._get(f"/{issue_report_id}", params=None, access_token_override=access_token_override)
        return IssueReport.model_validate(payload)

    async def update_issue_report(
        self,
        *,
        issue_report_id: str,
        note: str,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        payload = await self._patch(
            f"/{issue_report_id}",
            json={"note": note},
            access_token_override=access_token_override,
        )
        return IssueReport.model_validate(payload)

    async def reply_to_issue_report(
        self,
        *,
        issue_report_id: str,
        note: str,
        reporter_role_hint: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        body: Dict[str, Any] = {"note": note}
        if reporter_role_hint is not None:
            body["reporter_role_hint"] = reporter_role_hint
        payload = await self._post(
            f"/{issue_report_id}/replies",
            json=body,
            access_token_override=access_token_override,
        )
        return IssueReport.model_validate(payload)

    async def _get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = await self._client.get(
            f"{self.PREFIX}{path}",
            params=params,
            headers=self._build_headers(access_token_override),
        )
        return await self._parse_response(response)

    async def _post(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = await self._client.post(
            f"{self.PREFIX}{path}",
            json=json,
            headers=self._build_headers(access_token_override),
        )
        return await self._parse_response(response)

    async def _patch(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = await self._client.patch(
            f"{self.PREFIX}{path}",
            json=json,
            headers=self._build_headers(access_token_override),
        )
        return await self._parse_response(response)

    def _build_headers(self, access_token_override: Optional[str]) -> Dict[str, str]:
        headers: Dict[str, str] = {"X-API-Key": self.api_key}
        token = access_token_override or self.access_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    @staticmethod
    async def _parse_response(response: httpx.Response) -> Dict[str, Any]:
        if response.status_code >= 400:
            raise await AsyncIssueReportingClient._build_error(response)
        payload = response.json()
        return payload.get("data", payload)

    @staticmethod
    async def _build_error(response: httpx.Response) -> IssueReportingError:
        try:
            payload = response.json()
        except ValueError:  # pragma: no cover
            payload = {}
        error_info = payload.get("error", {})
        message = error_info.get("message") or response.text or "Issue reporting request failed"
        request_id = (
            response.headers.get("x-request-id")
            or payload.get("metadata", {}).get("request_id")
        )
        return IssueReportingError(
            message,
            status_code=response.status_code,
            error_code=error_info.get("code"),
            response=response,
            request_id=request_id,
        )


__all__ = ["AsyncIssueReportingClient"]
