"""
Device Authorization Grant (OAuth 2.0 Device Flow) client for SPAPS.

Implements RFC 8628 for CLI/headless device authentication.
"""

from __future__ import annotations

import asyncio
import sys
import time
from typing import Any, Dict, Optional

import httpx
from pydantic import BaseModel, ConfigDict

from .storage import StoredTokens, TokenStorage

__all__ = [
    "DeviceFlowClient",
    "DeviceFlowResponse",
    "DeviceFlowError",
    "DeviceFlowPendingError",
    "DeviceFlowExpiredError",
    "DeviceFlowDeniedError",
    "DeviceFlowTimeoutError",
]


# ---------------------------------------------------------------------------
# Error hierarchy
# ---------------------------------------------------------------------------


class DeviceFlowError(Exception):
    """Base error for device flow operations."""

    def __init__(
        self,
        message: str,
        status_code: int = 500,
        error_code: Optional[str] = None,
        response: Optional[httpx.Response] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.response = response


class DeviceFlowPendingError(DeviceFlowError):
    """Raised when the authorization is still pending user action."""


class DeviceFlowExpiredError(DeviceFlowError):
    """Raised when the device code has expired."""


class DeviceFlowDeniedError(DeviceFlowError):
    """Raised when the user denied the authorization request."""


class DeviceFlowTimeoutError(DeviceFlowError):
    """Raised when polling exceeds the configured timeout."""


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class DeviceFlowResponse(BaseModel):
    """Response from the device authorization endpoint."""

    model_config = ConfigDict(extra="ignore")

    device_code: str
    user_code: str
    verification_uri: str
    expires_in: int
    interval: int


class DeviceFlowTokenPair(BaseModel):
    """Token pair returned after successful device authorization."""

    model_config = ConfigDict(extra="ignore")

    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

# Default polling interval in seconds.
DEFAULT_POLL_INTERVAL = 5
# Default maximum time to wait for user authorization in seconds.
DEFAULT_TIMEOUT = 300

# Server error codes mapped to specific exceptions.
_ERROR_MAP: Dict[str, type] = {
    "authorization_pending": DeviceFlowPendingError,
    "expired_token": DeviceFlowExpiredError,
    "access_denied": DeviceFlowDeniedError,
}


class DeviceFlowClient:
    """
    OAuth 2.0 Device Authorization Grant client.

    Implements the three-step device flow:
      1. ``start()``  - request a device code
      2. ``poll()``   - poll for a token once the user authorizes
      3. ``login()``  - convenience that combines start + print + poll
    """

    DEVICE_AUTHORIZE_PATH = "/api/cli/device/authorize"
    DEVICE_TOKEN_PATH = "/api/cli/device/token"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        client: Optional[httpx.AsyncClient] = None,
        request_timeout: float = 10.0,
        poll_interval: int = DEFAULT_POLL_INTERVAL,
        timeout: int = DEFAULT_TIMEOUT,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.poll_interval = poll_interval
        self.timeout = timeout
        self._client = client or httpx.AsyncClient(
            base_url=self.base_url, timeout=request_timeout
        )
        self._owns_client = client is None
        self._token_storage = token_storage

    async def aclose(self) -> None:
        """Close the underlying HTTP client if we own it."""
        if self._owns_client:
            await self._client.aclose()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def start(self, scope: Optional[str] = None) -> DeviceFlowResponse:
        """
        Initiate the device authorization flow.

        POST /api/cli/device/authorize

        Args:
            scope: Optional OAuth scope string.

        Returns:
            DeviceFlowResponse containing the device_code, user_code,
            verification_uri, and polling parameters.
        """
        payload: Dict[str, Any] = {}
        if scope is not None:
            payload["scope"] = scope

        response = await self._client.post(
            self.DEVICE_AUTHORIZE_PATH,
            json=payload,
            headers=self._build_headers(),
        )
        if response.status_code >= 400:
            raise self._build_error(response)

        data = response.json()
        body = data.get("data", data)
        return DeviceFlowResponse.model_validate(body)

    async def poll(self, device_code: str) -> DeviceFlowTokenPair:
        """
        Poll the token endpoint until the user completes authorization.

        POST /api/cli/device/token

        Args:
            device_code: The device code obtained from ``start()``.

        Returns:
            DeviceFlowTokenPair with access and refresh tokens.

        Raises:
            DeviceFlowExpiredError: When the device code expires.
            DeviceFlowDeniedError: When the user denied authorization.
            DeviceFlowTimeoutError: When the configured timeout is exceeded.
        """
        interval = self.poll_interval
        deadline = time.monotonic() + self.timeout

        while True:
            if time.monotonic() >= deadline:
                raise DeviceFlowTimeoutError(
                    "Device flow timed out waiting for user authorization",
                    status_code=408,
                    error_code="timeout",
                )

            response = await self._client.post(
                self.DEVICE_TOKEN_PATH,
                json={"device_code": device_code},
                headers=self._build_headers(),
            )

            if response.status_code < 400:
                data = response.json()
                body = data.get("data", data)
                token_pair = DeviceFlowTokenPair.model_validate(body)
                self._store_tokens(token_pair)
                return token_pair

            # Parse the error to decide whether to keep polling.
            error = self._build_error(response)

            if isinstance(error, DeviceFlowPendingError):
                # Server told us to slow down or user hasn't authorized yet.
                if error.error_code == "slow_down":
                    interval += 5
                await asyncio.sleep(interval)
                continue

            # Terminal errors bubble up immediately.
            raise error

    async def login(self) -> DeviceFlowTokenPair:
        """
        Convenience method: start the flow, print instructions, and poll.

        Returns:
            DeviceFlowTokenPair with access and refresh tokens.
        """
        device_response = await self.start()
        print(
            f"\nTo sign in, visit: {device_response.verification_uri}"
            f"\nEnter code: {device_response.user_code}\n",
            file=sys.stdout,
        )
        return await self.poll(device_response.device_code)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_headers(self) -> Dict[str, str]:
        return {"X-API-Key": self.api_key}

    def _build_error(self, response: httpx.Response) -> DeviceFlowError:
        try:
            payload = response.json()
        except ValueError:
            payload = {}

        error_info = payload.get("error", {})
        if isinstance(error_info, str):
            error_code = error_info
            message = payload.get("error_description", error_info)
        else:
            error_code = error_info.get("code", "")
            message = (
                error_info.get("message")
                or payload.get("error_description")
                or response.text
                or "Device flow request failed"
            )

        exc_class = _ERROR_MAP.get(error_code, DeviceFlowError)
        return exc_class(
            message,
            status_code=response.status_code,
            error_code=error_code,
            response=response,
        )

    def _store_tokens(self, token_pair: DeviceFlowTokenPair) -> None:
        if not self._token_storage:
            return
        from datetime import datetime, timedelta, timezone

        expires_at = datetime.now(timezone.utc) + timedelta(seconds=token_pair.expires_in)
        self._token_storage.save(
            StoredTokens(
                access_token=token_pair.access_token,
                refresh_token=token_pair.refresh_token,
                expires_at=expires_at,
                token_type=token_pair.token_type,
            )
        )
