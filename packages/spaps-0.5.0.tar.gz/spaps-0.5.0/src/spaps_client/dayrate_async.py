"""Async dayrate client for SPAPS dayrate endpoints."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx


class DayrateError(Exception):
    """Raised when the SPAPS dayrate API returns an error."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_code: Optional[str] = None,
        response: Optional[httpx.Response] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.response = response
        self.request_id = request_id


class AsyncDayrateClient:
    """Async client wrapper for SPAPS dayrate endpoints."""

    DAYRATE_PREFIX = "/api/dayrate"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        access_token: Optional[str] = None,
        client: Optional[httpx.AsyncClient] = None,
        request_timeout: float | httpx.Timeout = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.access_token = access_token
        self._client = client or httpx.AsyncClient(base_url=self.base_url, timeout=request_timeout)
        self._owns_client = client is None

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def get_availability(self) -> Dict[str, Any]:
        """Get available dayrate slots."""
        return await self._get("/availability", require_auth=False)

    async def get_allotment(
        self,
        *,
        policy_key: str,
        user_id: Optional[str] = None,
        email: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get dayrate allotment for a policy/user."""
        params: Dict[str, Any] = {"policyKey": policy_key}
        if user_id is not None:
            params["userId"] = user_id
        if email is not None:
            params["email"] = email
        return await self._get("/allotment", params=params, require_auth=False)

    async def create_booking(
        self,
        *,
        date: str,
        slot: str,
        client_email: str,
        client_name: str,
        success_url: str,
        cancel_url: str,
        policy_key: Optional[str] = None,
        enrollment_id: Optional[str] = None,
        replaces_booking_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a dayrate booking."""
        payload: Dict[str, Any] = {
            "date": date,
            "slot": slot,
            "clientEmail": client_email,
            "clientName": client_name,
            "successUrl": success_url,
            "cancelUrl": cancel_url,
        }
        if policy_key is not None:
            payload["policyKey"] = policy_key
        if enrollment_id is not None:
            payload["enrollmentId"] = enrollment_id
        if replaces_booking_id is not None:
            payload["replacesBookingId"] = replaces_booking_id
        if user_id is not None:
            payload["userId"] = user_id
        return await self._post("/book", json=payload, require_auth=False)

    async def cancel_booking(
        self,
        *,
        booking_id: str,
        user_id: Optional[str] = None,
        email: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Cancel a dayrate booking."""
        payload: Dict[str, Any] = {"bookingId": booking_id}
        if user_id is not None:
            payload["userId"] = user_id
        if email is not None:
            payload["email"] = email
        return await self._post("/cancel", json=payload, require_auth=False)

    async def get_admin_bookings(
        self,
        *,
        status: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        client_email: Optional[str] = None,
        enrollment_id: Optional[str] = None,
        user_id: Optional[str] = None,
        is_free: Optional[bool] = None,
        limit: int = 100,
        offset: int = 0,
        access_token_override: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List dayrate bookings from the admin endpoint."""
        params: Dict[str, Any] = {"limit": str(limit), "offset": str(offset)}
        if status is not None:
            params["status"] = status
        if start_date is not None:
            params["startDate"] = start_date
        if end_date is not None:
            params["endDate"] = end_date
        if client_email is not None:
            params["clientEmail"] = client_email
        if enrollment_id is not None:
            params["enrollmentId"] = enrollment_id
        if user_id is not None:
            params["userId"] = user_id
        if is_free is not None:
            params["isFree"] = "true" if is_free else "false"
        return await self._get(
            "/admin/bookings",
            params=params,
            access_token_override=access_token_override,
            require_auth=True,
        )

    async def _get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        access_token_override: Optional[str] = None,
        require_auth: bool = False,
    ) -> Dict[str, Any]:
        response = await self._client.get(
            f"{self.DAYRATE_PREFIX}{path}",
            params=params,
            headers=self._build_headers(
                access_token_override=access_token_override,
                require_auth=require_auth,
            ),
        )
        return self._parse_response(response)

    async def _post(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str] = None,
        require_auth: bool = False,
    ) -> Dict[str, Any]:
        response = await self._client.post(
            f"{self.DAYRATE_PREFIX}{path}",
            json=json,
            headers=self._build_headers(
                access_token_override=access_token_override,
                require_auth=require_auth,
            ),
        )
        return self._parse_response(response)

    def _build_headers(
        self,
        *,
        access_token_override: Optional[str],
        require_auth: bool,
    ) -> Dict[str, str]:
        headers = {"X-API-Key": self.api_key}
        token = access_token_override or self.access_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        elif require_auth:
            raise ValueError("Access token is required for this dayrate operation")
        return headers

    def _parse_response(self, response: httpx.Response) -> Dict[str, Any]:
        if response.status_code >= 400:
            raise self._build_error(response)
        payload = response.json()
        return payload.get("data", payload)

    @staticmethod
    def _build_error(response: httpx.Response) -> DayrateError:
        try:
            payload = response.json()
        except ValueError:  # pragma: no cover
            payload = {}
        error_info = payload.get("error", {})
        message = error_info.get("message") or response.text or "Dayrate request failed"
        request_id = (
            response.headers.get("x-request-id")
            or payload.get("metadata", {}).get("request_id")
        )
        return DayrateError(
            message,
            status_code=response.status_code,
            error_code=error_info.get("code"),
            response=response,
            request_id=request_id,
        )


__all__ = ["AsyncDayrateClient", "DayrateError"]
