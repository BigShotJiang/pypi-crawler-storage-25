"""Support telemetry client for SPAPS support case APIs."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

import httpx
from pydantic import BaseModel, ConfigDict

__all__ = [
    "SupportTelemetryError",
    "SupportActor",
    "SupportCaseSummary",
    "SupportCaseEvent",
    "IngestEventResult",
    "SupportCasesListResult",
    "SupportCaseDetailResult",
    "PatchSupportCaseResult",
    "SupportCaseByExternalResult",
    "SupportTelemetryClient",
]


class SupportTelemetryError(Exception):
    """Raised when support telemetry API returns an error."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_code: Optional[str] = None,
        response: Optional[httpx.Response] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.response = response
        self.request_id = request_id


class SupportActor(BaseModel):
    """Event actor payload."""

    model_config = ConfigDict(extra="ignore")

    type: str
    id: Optional[str] = None


class SupportCaseSummary(BaseModel):
    """Canonical support case summary."""

    model_config = ConfigDict(extra="ignore")

    id: str
    application_id: str
    external_case_ref: Optional[str] = None
    title: Optional[str] = None
    status: str
    priority: str
    highest_severity: str
    assigned_to_user_id: Optional[str] = None
    first_event_at: str
    last_event_at: str
    resolved_at: Optional[str] = None
    created_at: str
    updated_at: str


class SupportCaseEvent(BaseModel):
    """Support case timeline event payload."""

    model_config = ConfigDict(extra="ignore")

    id: str
    case_id: str
    event_key: str
    source_channel: str
    event_type: str
    severity: str
    actor: SupportActor
    correlation_id: Optional[str] = None
    occurred_at: str
    received_at: str
    payload: Dict[str, Any]


class IngestEventResult(BaseModel):
    """Event ingest result."""

    model_config = ConfigDict(extra="ignore")

    event_id: str
    case_id: str
    created_case: bool
    deduplicated: bool
    case_status: str


class SupportCasesListResult(BaseModel):
    """Case list result payload."""

    model_config = ConfigDict(extra="ignore")

    items: List[SupportCaseSummary]
    total: int


class SupportCaseDetailResult(BaseModel):
    """Case detail + events payload."""

    model_config = ConfigDict(extra="ignore")

    case: SupportCaseSummary
    events: List[SupportCaseEvent]
    event_total: int


class PatchSupportCaseFields(BaseModel):
    """Patched case lifecycle fields."""

    model_config = ConfigDict(extra="ignore")

    id: str
    status: str
    priority: str
    assigned_to_user_id: Optional[str] = None
    resolved_at: Optional[str] = None
    updated_at: str


class PatchSupportCaseResult(BaseModel):
    """Patch case response payload."""

    model_config = ConfigDict(extra="ignore")

    case: PatchSupportCaseFields


class SupportCaseByExternalFields(BaseModel):
    """External ref case lookup payload."""

    model_config = ConfigDict(extra="ignore")

    id: str
    application_id: str
    external_case_ref: Optional[str] = None
    status: str
    priority: str
    assigned_to_user_id: Optional[str] = None
    resolved_at: Optional[str] = None
    updated_at: str


class SupportCaseByExternalResult(BaseModel):
    """Lookup by external ref response payload."""

    model_config = ConfigDict(extra="ignore")

    case: SupportCaseByExternalFields


class SupportTelemetryClient:
    """Client wrapper for support telemetry endpoints."""

    PREFIX = "/api/v1/support-telemetry"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        access_token: Optional[str] = None,
        client: Optional[httpx.Client] = None,
        request_timeout: float | httpx.Timeout = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.access_token = access_token
        self._client = client or httpx.Client(base_url=self.base_url, timeout=request_timeout)
        self._owns_client = client is None

    def __enter__(self) -> "SupportTelemetryClient":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:  # type: ignore[override]
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def ingest_event(
        self,
        *,
        event_key: str,
        occurred_at: datetime | str,
        source_channel: str,
        event_type: str,
        severity: str,
        actor: Dict[str, Any],
        payload: Dict[str, Any],
        application_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        external_case_ref: Optional[str] = None,
        title: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> IngestEventResult:
        body: Dict[str, Any] = {
            "event_key": event_key,
            "occurred_at": occurred_at.isoformat() if isinstance(occurred_at, datetime) else occurred_at,
            "source_channel": source_channel,
            "event_type": event_type,
            "severity": severity,
            "actor": actor,
            "payload": payload,
        }
        if application_id is not None:
            body["application_id"] = application_id
        if correlation_id is not None:
            body["correlation_id"] = correlation_id
        if external_case_ref is not None:
            body["external_case_ref"] = external_case_ref
        if title is not None:
            body["title"] = title

        data = self._post("/events", json=body, access_token_override=access_token_override)
        return IngestEventResult.model_validate(data)

    def list_cases(
        self,
        *,
        application_id: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        severity_gte: Optional[str] = None,
        assigned_to_user_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        access_token_override: Optional[str] = None,
    ) -> SupportCasesListResult:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if application_id is not None:
            params["application_id"] = application_id
        if status is not None:
            params["status"] = status
        if priority is not None:
            params["priority"] = priority
        if severity_gte is not None:
            params["severity_gte"] = severity_gte
        if assigned_to_user_id is not None:
            params["assigned_to_user_id"] = assigned_to_user_id

        data = self._get("/cases", params=params, access_token_override=access_token_override)
        return SupportCasesListResult.model_validate(data)

    def get_case(
        self,
        *,
        case_id: str,
        event_limit: int = 100,
        event_offset: int = 0,
        access_token_override: Optional[str] = None,
    ) -> SupportCaseDetailResult:
        data = self._get(
            f"/cases/{case_id}",
            params={"event_limit": event_limit, "event_offset": event_offset},
            access_token_override=access_token_override,
        )
        return SupportCaseDetailResult.model_validate(data)

    def patch_case(
        self,
        *,
        case_id: str,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        assigned_to_user_id: Optional[str] = None,
        resolution_note: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> PatchSupportCaseResult:
        body: Dict[str, Any] = {}
        if status is not None:
            body["status"] = status
        if priority is not None:
            body["priority"] = priority
        if assigned_to_user_id is not None:
            body["assigned_to_user_id"] = assigned_to_user_id
        if resolution_note is not None:
            body["resolution_note"] = resolution_note

        data = self._patch(
            f"/cases/{case_id}",
            json=body,
            access_token_override=access_token_override,
        )
        return PatchSupportCaseResult.model_validate(data)

    def get_case_by_external_ref(
        self,
        *,
        external_case_ref: str,
        application_id: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> SupportCaseByExternalResult:
        params: Dict[str, Any] = {}
        if application_id is not None:
            params["application_id"] = application_id
        data = self._get(
            f"/cases/by-external/{external_case_ref}",
            params=params,
            access_token_override=access_token_override,
        )
        return SupportCaseByExternalResult.model_validate(data)

    def _get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = self._client.get(
            f"{self.PREFIX}{path}",
            params=params,
            headers=self._build_headers(access_token_override),
        )
        return self._parse_response(response)

    def _post(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = self._client.post(
            f"{self.PREFIX}{path}",
            json=json,
            headers=self._build_headers(access_token_override),
        )
        return self._parse_response(response)

    def _patch(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = self._client.patch(
            f"{self.PREFIX}{path}",
            json=json,
            headers=self._build_headers(access_token_override),
        )
        return self._parse_response(response)

    def _build_headers(self, access_token_override: Optional[str]) -> Dict[str, str]:
        headers: Dict[str, str] = {"X-API-Key": self.api_key}
        token = access_token_override or self.access_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    @staticmethod
    def _parse_response(response: httpx.Response) -> Dict[str, Any]:
        if response.status_code >= 400:
            raise SupportTelemetryClient._build_error(response)
        payload = response.json()
        return payload.get("data", payload)

    @staticmethod
    def _build_error(response: httpx.Response) -> SupportTelemetryError:
        try:
            payload = response.json()
        except ValueError:  # pragma: no cover
            payload = {}
        error_info = payload.get("error", {})
        message = error_info.get("message") or response.text or "Support telemetry request failed"
        request_id = (
            response.headers.get("x-request-id")
            or payload.get("metadata", {}).get("request_id")
        )
        return SupportTelemetryError(
            message,
            status_code=response.status_code,
            error_code=error_info.get("code"),
            response=response,
            request_id=request_id,
        )

