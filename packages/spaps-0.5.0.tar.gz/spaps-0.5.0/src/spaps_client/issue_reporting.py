"""Issue reporting client for SPAPS shared issue-report APIs."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx
from pydantic import BaseModel, ConfigDict

__all__ = [
    "IssueReportingError",
    "IssueReportTarget",
    "LinkedCaseSummary",
    "IssueReport",
    "IssueReportsListResult",
    "IssueReportStatusResult",
    "IssueReportingClient",
]


class IssueReportingError(Exception):
    """Raised when issue-reporting API calls fail."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_code: Optional[str] = None,
        response: Optional[httpx.Response] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.response = response
        self.request_id = request_id


class IssueReportTarget(BaseModel):
    """Immutable target snapshot attached to an issue report."""

    model_config = ConfigDict(extra="ignore")

    component_key: str
    component_label: str
    page_url: str
    surface_ref: Optional[str] = None
    metadata: Dict[str, Any]


class LinkedCaseSummary(BaseModel):
    """Linked support-case summary exposed to reporters."""

    model_config = ConfigDict(extra="ignore")

    case_id: str
    status: str
    priority: str
    resolved_at: Optional[str] = None


class IssueReport(BaseModel):
    """Canonical issue-report payload."""

    model_config = ConfigDict(extra="ignore")

    id: str
    application_id: str
    reporter_user_id: str
    reporter_role_hint: Optional[str] = None
    target: IssueReportTarget
    note: str
    status: str
    parent_issue_report_id: Optional[str] = None
    linked_case: LinkedCaseSummary
    created_at: str
    updated_at: str


class IssueReportsListResult(BaseModel):
    """List issue reports response."""

    model_config = ConfigDict(extra="ignore")

    items: List[IssueReport]
    total: int


class IssueReportStatusResult(BaseModel):
    """Floating issue-entrypoint status summary."""

    model_config = ConfigDict(extra="ignore")

    has_open: bool
    has_recent_resolved: bool
    open_count: int
    recent_resolved_count: int


class IssueReportingClient:
    """Client wrapper for shared end-user issue-reporting endpoints."""

    PREFIX = "/api/v1/issue-reports"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        access_token: Optional[str] = None,
        client: Optional[httpx.Client] = None,
        request_timeout: float | httpx.Timeout = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.access_token = access_token
        self._client = client or httpx.Client(base_url=self.base_url, timeout=request_timeout)
        self._owns_client = client is None

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def create_issue_report(
        self,
        *,
        target: Dict[str, Any],
        note: str,
        reporter_role_hint: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        body: Dict[str, Any] = {"target": target, "note": note}
        if reporter_role_hint is not None:
            body["reporter_role_hint"] = reporter_role_hint
        data = self._post("", json=body, access_token_override=access_token_override)
        return IssueReport.model_validate(data)

    def list_issue_reports(
        self,
        *,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        access_token_override: Optional[str] = None,
    ) -> IssueReportsListResult:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        data = self._get("", params=params, access_token_override=access_token_override)
        return IssueReportsListResult.model_validate(data)

    def get_issue_report_status(
        self,
        *,
        access_token_override: Optional[str] = None,
    ) -> IssueReportStatusResult:
        data = self._get("/status", params=None, access_token_override=access_token_override)
        return IssueReportStatusResult.model_validate(data)

    def get_issue_report(
        self,
        *,
        issue_report_id: str,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        data = self._get(f"/{issue_report_id}", params=None, access_token_override=access_token_override)
        return IssueReport.model_validate(data)

    def update_issue_report(
        self,
        *,
        issue_report_id: str,
        note: str,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        data = self._patch(
            f"/{issue_report_id}",
            json={"note": note},
            access_token_override=access_token_override,
        )
        return IssueReport.model_validate(data)

    def reply_to_issue_report(
        self,
        *,
        issue_report_id: str,
        note: str,
        reporter_role_hint: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> IssueReport:
        body: Dict[str, Any] = {"note": note}
        if reporter_role_hint is not None:
            body["reporter_role_hint"] = reporter_role_hint
        data = self._post(
            f"/{issue_report_id}/replies",
            json=body,
            access_token_override=access_token_override,
        )
        return IssueReport.model_validate(data)

    def _get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = self._client.get(
            f"{self.PREFIX}{path}",
            params=params,
            headers=self._build_headers(access_token_override),
        )
        return self._parse_response(response)

    def _post(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = self._client.post(
            f"{self.PREFIX}{path}",
            json=json,
            headers=self._build_headers(access_token_override),
        )
        return self._parse_response(response)

    def _patch(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str],
    ) -> Dict[str, Any]:
        response = self._client.patch(
            f"{self.PREFIX}{path}",
            json=json,
            headers=self._build_headers(access_token_override),
        )
        return self._parse_response(response)

    def _build_headers(self, access_token_override: Optional[str]) -> Dict[str, str]:
        headers: Dict[str, str] = {"X-API-Key": self.api_key}
        token = access_token_override or self.access_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    @staticmethod
    def _parse_response(response: httpx.Response) -> Dict[str, Any]:
        if response.status_code >= 400:
            raise IssueReportingClient._build_error(response)
        payload = response.json()
        return payload.get("data", payload)

    @staticmethod
    def _build_error(response: httpx.Response) -> IssueReportingError:
        try:
            payload = response.json()
        except ValueError:  # pragma: no cover
            payload = {}
        error_info = payload.get("error", {})
        message = error_info.get("message") or response.text or "Issue reporting request failed"
        request_id = (
            response.headers.get("x-request-id")
            or payload.get("metadata", {}).get("request_id")
        )
        return IssueReportingError(
            message,
            status_code=response.status_code,
            error_code=error_info.get("code"),
            response=response,
            request_id=request_id,
        )

