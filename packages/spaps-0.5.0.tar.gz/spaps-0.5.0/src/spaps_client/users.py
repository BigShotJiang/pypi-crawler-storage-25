"""Users client for SPAPS users service."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx
from pydantic import BaseModel, ConfigDict

__all__ = [
    "UsersError",
    "BatchEmailsResult",
    "UserBatchInfo",
    "BatchUsersResult",
    "UsersClient",
]


class UsersError(Exception):
    """Raised when the SPAPS users API returns an error."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_code: Optional[str] = None,
        response: Optional[httpx.Response] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.response = response
        self.request_id = request_id


class BatchEmailsResult(BaseModel):
    """Result of a batch email lookup."""

    model_config = ConfigDict(extra="ignore")

    emails: Dict[str, Optional[str]]
    total: int = 0
    with_email: int = 0


class UserBatchInfo(BaseModel):
    """Per-user info from a batch users lookup."""

    model_config = ConfigDict(extra="ignore")

    email: Optional[str] = None
    active_entitlements: Optional[List[Dict[str, Any]]] = None
    upcoming_bookings: Optional[List[Dict[str, Any]]] = None


class BatchUsersResult(BaseModel):
    """Result of a batch users lookup."""

    model_config = ConfigDict(extra="ignore")

    users: Dict[str, UserBatchInfo]


class UsersClient:
    """Client wrapper for SPAPS users endpoints."""

    USERS_PREFIX = "/api/users"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        client: Optional[httpx.Client] = None,
        request_timeout: float | httpx.Timeout = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._client = client or httpx.Client(base_url=self.base_url, timeout=request_timeout)
        self._owns_client = client is None

    def __enter__(self) -> "UsersClient":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:  # type: ignore[override]
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    # =========================================================================
    # Public API
    # =========================================================================

    def get_emails_batch(self, user_ids: List[str]) -> BatchEmailsResult:
        """Get email addresses for a batch of user IDs."""
        data = self._post("/emails", json={"user_ids": user_ids})
        return BatchEmailsResult.model_validate(data)

    def get_users_batch(self, user_ids: List[str]) -> BatchUsersResult:
        """Get user info for a batch of user IDs."""
        data = self._post("/batch", json={"user_ids": user_ids})
        return BatchUsersResult.model_validate(data)

    # =========================================================================
    # Internal helpers
    # =========================================================================

    def _post(
        self,
        path: str,
        *,
        json: Dict[str, Any],
    ) -> Dict[str, Any]:
        response = self._client.post(
            f"{self.USERS_PREFIX}{path}",
            json=json,
            headers=self._build_headers(),
        )
        return self._parse_response(response)

    def _build_headers(self) -> Dict[str, str]:
        return {
            "X-API-Key": self.api_key,
        }

    def _parse_response(self, response: httpx.Response) -> Dict[str, Any]:
        if response.status_code >= 400:
            raise self._build_error(response)
        payload = response.json()
        return payload.get("data", payload)

    @staticmethod
    def _build_error(response: httpx.Response) -> UsersError:
        try:
            payload = response.json()
        except ValueError:  # pragma: no cover
            payload = {}
        error_info = payload.get("error", {})
        if isinstance(error_info, str):
            error_info = {"message": error_info}
        message = error_info.get("message") or response.text or "Users request failed"
        request_id = (
            response.headers.get("x-request-id")
            or payload.get("metadata", {}).get("request_id")
        )
        return UsersError(
            message,
            status_code=response.status_code,
            error_code=error_info.get("code"),
            response=response,
            request_id=request_id,
        )
