"""Async email client for SPAPS email service."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from .email import (
    EmailError,
    EmailSendResult,
    EmailTemplate,
    EmailTemplatePreview,
)

__all__ = ["AsyncEmailClient"]


class AsyncEmailClient:
    """Async client wrapper for SPAPS email endpoints."""

    EMAIL_PREFIX = "/api/email"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        access_token: Optional[str] = None,
        client: Optional[httpx.AsyncClient] = None,
        request_timeout: float | httpx.Timeout = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.access_token = access_token
        self._client = client or httpx.AsyncClient(base_url=self.base_url, timeout=request_timeout)
        self._owns_client = client is None

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def send(
        self,
        *,
        template_key: str,
        to: str,
        context: Dict[str, Any],
        user_id: Optional[str] = None,
        owner_id: Optional[str] = None,
        subject_override: Optional[str] = None,
        body_override: Optional[str] = None,
    ) -> EmailSendResult:
        """Send an email using a template."""
        payload: Dict[str, Any] = {
            "template_key": template_key,
            "to": to,
            "context": context,
        }
        if user_id is not None:
            payload["user_id"] = user_id
        if owner_id is not None:
            payload["owner_id"] = owner_id
        if subject_override is not None:
            payload["subject_override"] = subject_override
        if body_override is not None:
            payload["body_override"] = body_override

        data = await self._post("/send", json=payload, require_auth=False)
        return EmailSendResult.model_validate(data)

    async def list_templates(
        self,
        *,
        access_token_override: Optional[str] = None,
    ) -> List[EmailTemplate]:
        """List all email templates for the application."""
        data = await self._get(
            "/templates",
            access_token_override=access_token_override,
            require_auth=True,
        )
        templates_list = data.get("templates", data)
        if isinstance(templates_list, list):
            return [EmailTemplate.model_validate(item) for item in templates_list]
        return []

    async def get_template(
        self,
        template_key: str,
        *,
        access_token_override: Optional[str] = None,
    ) -> EmailTemplate:
        """Get a single template by key."""
        data = await self._get(
            f"/templates/{template_key}",
            access_token_override=access_token_override,
            require_auth=True,
        )
        return EmailTemplate.model_validate(data)

    async def preview_template(
        self,
        template_key: str,
        *,
        context: Optional[Dict[str, Any]] = None,
        access_token_override: Optional[str] = None,
    ) -> EmailTemplatePreview:
        """Preview a rendered template."""
        if context is not None:
            data = await self._post(
                f"/templates/{template_key}/preview",
                json={"context": context},
                access_token_override=access_token_override,
                require_auth=True,
            )
        else:
            data = await self._get(
                f"/templates/{template_key}/preview",
                access_token_override=access_token_override,
                require_auth=True,
            )
        # SPAPS wraps preview in {"preview": {...}} - extract it
        preview_data = data.get("preview", data)
        return EmailTemplatePreview.model_validate(preview_data)

    async def update_template(
        self,
        template_key: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        subject: Optional[str] = None,
        html_body: Optional[str] = None,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
        from_name: Optional[str] = None,
        reply_to: Optional[str] = None,
        variables: Optional[Dict[str, Any]] = None,
        sample_context: Optional[Dict[str, Any]] = None,
        is_active: Optional[bool] = None,
        category: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> EmailTemplate:
        """Update an email template."""
        payload: Dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if subject is not None:
            payload["subject"] = subject
        if html_body is not None:
            payload["html_body"] = html_body
        if text_body is not None:
            payload["text_body"] = text_body
        if from_email is not None:
            payload["from_email"] = from_email
        if from_name is not None:
            payload["from_name"] = from_name
        if reply_to is not None:
            payload["reply_to"] = reply_to
        if variables is not None:
            payload["variables"] = variables
        if sample_context is not None:
            payload["sample_context"] = sample_context
        if is_active is not None:
            payload["is_active"] = is_active
        if category is not None:
            payload["category"] = category

        data = await self._put(
            f"/templates/{template_key}",
            json=payload,
            access_token_override=access_token_override,
            require_auth=True,
        )
        template_data = data.get("template", data)
        return EmailTemplate.model_validate(template_data)

    async def get_override(
        self,
        template_key: str,
        *,
        access_token_override: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get a template override."""
        return await self._get(
            f"/templates/{template_key}/override",
            access_token_override=access_token_override,
            require_auth=True,
        )

    async def create_or_update_override(
        self,
        template_key: str,
        *,
        override: Optional[Dict[str, Any]] = None,
        subject_override: Optional[str] = None,
        body_override: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create or update a template override."""
        payload: Dict[str, Any] = dict(override or {})
        if subject_override is not None:
            payload["subject_override"] = subject_override
        if body_override is not None:
            payload["body_override"] = body_override

        return await self._put(
            f"/templates/{template_key}/override",
            json=payload,
            access_token_override=access_token_override,
            require_auth=True,
        )

    async def delete_override(
        self,
        template_key: str,
        *,
        access_token_override: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Delete a template override."""
        return await self._delete(
            f"/templates/{template_key}/override",
            access_token_override=access_token_override,
            require_auth=True,
        )

    async def create_template(
        self,
        *,
        template_key: str,
        name: str,
        subject: str,
        html_body: str,
        description: Optional[str] = None,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
        from_name: Optional[str] = None,
        reply_to: Optional[str] = None,
        variables: Optional[Dict[str, Any]] = None,
        sample_context: Optional[Dict[str, Any]] = None,
        is_active: Optional[bool] = None,
        category: Optional[str] = None,
        access_token_override: Optional[str] = None,
    ) -> EmailTemplate:
        """Create a template."""
        payload: Dict[str, Any] = {
            "template_key": template_key,
            "name": name,
            "subject": subject,
            "html_body": html_body,
        }
        if description is not None:
            payload["description"] = description
        if text_body is not None:
            payload["text_body"] = text_body
        if from_email is not None:
            payload["from_email"] = from_email
        if from_name is not None:
            payload["from_name"] = from_name
        if reply_to is not None:
            payload["reply_to"] = reply_to
        if variables is not None:
            payload["variables"] = variables
        if sample_context is not None:
            payload["sample_context"] = sample_context
        if is_active is not None:
            payload["is_active"] = is_active
        if category is not None:
            payload["category"] = category

        data = await self._post(
            "/templates",
            json=payload,
            access_token_override=access_token_override,
            require_auth=True,
        )
        template_data = data.get("template", data)
        return EmailTemplate.model_validate(template_data)

    async def list_email_logs(
        self,
        *,
        owner_id: Optional[str] = None,
        user_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        access_token_override: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List email logs."""
        params: Dict[str, Any] = {"limit": str(limit), "offset": str(offset)}
        if owner_id is not None:
            params["owner_id"] = owner_id
        if user_id is not None:
            params["user_id"] = user_id
        return await self._get(
            "/logs",
            params=params,
            access_token_override=access_token_override,
            require_auth=True,
        )

    async def _get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        access_token_override: Optional[str] = None,
        require_auth: bool = False,
    ) -> Dict[str, Any]:
        response = await self._client.get(
            f"{self.EMAIL_PREFIX}{path}",
            params=params,
            headers=self._build_headers(
                access_token_override=access_token_override,
                require_auth=require_auth,
            ),
        )
        return await self._parse_response(response)

    async def _post(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str] = None,
        require_auth: bool = False,
    ) -> Dict[str, Any]:
        response = await self._client.post(
            f"{self.EMAIL_PREFIX}{path}",
            json=json,
            headers=self._build_headers(
                access_token_override=access_token_override,
                require_auth=require_auth,
            ),
        )
        return await self._parse_response(response)

    async def _put(
        self,
        path: str,
        *,
        json: Dict[str, Any],
        access_token_override: Optional[str] = None,
        require_auth: bool = False,
    ) -> Dict[str, Any]:
        response = await self._client.put(
            f"{self.EMAIL_PREFIX}{path}",
            json=json,
            headers=self._build_headers(
                access_token_override=access_token_override,
                require_auth=require_auth,
            ),
        )
        return await self._parse_response(response)

    async def _delete(
        self,
        path: str,
        *,
        access_token_override: Optional[str] = None,
        require_auth: bool = False,
    ) -> Dict[str, Any]:
        response = await self._client.delete(
            f"{self.EMAIL_PREFIX}{path}",
            headers=self._build_headers(
                access_token_override=access_token_override,
                require_auth=require_auth,
            ),
        )
        return await self._parse_response(response)

    def _build_headers(
        self,
        *,
        access_token_override: Optional[str],
        require_auth: bool,
    ) -> Dict[str, str]:
        headers = {"X-API-Key": self.api_key}
        token = access_token_override or self.access_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        elif require_auth:
            raise ValueError("Access token is required for this email operation")
        return headers

    async def _parse_response(self, response: httpx.Response) -> Dict[str, Any]:
        if response.status_code >= 400:
            raise self._build_error(response)
        payload = response.json()
        return payload.get("data", payload)

    @staticmethod
    def _build_error(response: httpx.Response) -> EmailError:
        try:
            payload = response.json()
        except ValueError:  # pragma: no cover
            payload = {}
        error_info = payload.get("error", {})
        message = error_info.get("message") or response.text or "Email request failed"
        request_id = (
            response.headers.get("x-request-id")
            or payload.get("metadata", {}).get("request_id")
        )
        return EmailError(
            message,
            status_code=response.status_code,
            error_code=error_info.get("code"),
            response=response,
            request_id=request_id,
        )
