from __future__ import annotations

from datetime import UTC, datetime

import pytest
import respx
from httpx import Response

from spaps_client.support_telemetry import (
    SupportTelemetryClient,
    SupportTelemetryError,
)


@pytest.fixture()
def base_url() -> str:
    return "https://api.sweetpotato.dev"


@pytest.fixture()
def api_key() -> str:
    return "test_key_local_dev_only"


@pytest.fixture()
def access_token() -> str:
    return "access-token"


@pytest.fixture()
def telemetry_client(base_url: str, api_key: str, access_token: str) -> SupportTelemetryClient:
    return SupportTelemetryClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )


@respx.mock
def test_ingest_event_success(
    telemetry_client: SupportTelemetryClient,
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(f"{base_url}/api/v1/support-telemetry/events").mock(
        return_value=Response(
            201,
            json={
                "success": True,
                "data": {
                    "event_id": "event-1",
                    "case_id": "case-1",
                    "created_case": True,
                    "deduplicated": False,
                    "case_status": "open",
                },
            },
        )
    )

    result = telemetry_client.ingest_event(
        event_key="evt_1",
        occurred_at=datetime.now(UTC),
        source_channel="api",
        event_type="issue_reported",
        severity="warning",
        actor={"type": "service", "id": "svc-1"},
        payload={"message": "example"},
    )

    assert route.called
    request = route.calls.last.request
    assert request.headers["X-API-Key"] == api_key
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    assert result.event_id == "event-1"
    assert result.case_id == "case-1"
    assert result.created_case is True


@respx.mock
def test_list_cases_success(
    telemetry_client: SupportTelemetryClient,
    base_url: str,
) -> None:
    route = respx.get(f"{base_url}/api/v1/support-telemetry/cases").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "items": [
                        {
                            "id": "case-1",
                            "application_id": "app-1",
                            "external_case_ref": "thread_123",
                            "title": "Patient cannot reopen support thread",
                            "status": "open",
                            "priority": "high",
                            "highest_severity": "error",
                            "assigned_to_user_id": None,
                            "first_event_at": "2026-03-01T16:00:00Z",
                            "last_event_at": "2026-03-01T16:03:00Z",
                            "resolved_at": None,
                            "created_at": "2026-03-01T16:00:00Z",
                            "updated_at": "2026-03-01T16:03:00Z",
                        }
                    ],
                    "total": 1,
                },
            },
        )
    )

    result = telemetry_client.list_cases(status="open", limit=10, offset=0)

    assert route.called
    assert result.total == 1
    assert result.items[0].id == "case-1"


@respx.mock
def test_patch_case_error_raises(
    telemetry_client: SupportTelemetryClient,
    base_url: str,
) -> None:
    respx.patch(f"{base_url}/api/v1/support-telemetry/cases/case-1").mock(
        return_value=Response(
            400,
            json={
                "success": False,
                "error": {
                    "code": "SUPPORT_TELEMETRY_INVALID_TRANSITION",
                    "message": "Invalid support case lifecycle transition",
                },
            },
        )
    )

    with pytest.raises(SupportTelemetryError) as exc:
        telemetry_client.patch_case(case_id="case-1", status="resolved")

    assert exc.value.status_code == 400
    assert exc.value.error_code == "SUPPORT_TELEMETRY_INVALID_TRANSITION"


@respx.mock
def test_get_case_and_get_case_by_external_success(
    telemetry_client: SupportTelemetryClient,
    base_url: str,
) -> None:
    case_payload = {
        "success": True,
        "data": {
            "case": {
                "id": "case-1",
                "application_id": "app-1",
                "external_case_ref": "thread_123",
                "title": "Example",
                "status": "in_progress",
                "priority": "high",
                "highest_severity": "error",
                "assigned_to_user_id": None,
                "first_event_at": "2026-03-01T16:00:00Z",
                "last_event_at": "2026-03-01T16:03:00Z",
                "resolved_at": None,
                "created_at": "2026-03-01T16:00:00Z",
                "updated_at": "2026-03-01T16:03:00Z",
            },
            "events": [
                {
                    "id": "event-1",
                    "case_id": "case-1",
                    "event_key": "evt_1",
                    "source_channel": "api",
                    "event_type": "issue_reported",
                    "severity": "warning",
                    "actor": {"type": "service", "id": "svc-1"},
                    "correlation_id": None,
                    "occurred_at": "2026-03-01T16:00:00Z",
                    "received_at": "2026-03-01T16:00:01Z",
                    "payload": {"message": "example"},
                }
            ],
            "event_total": 1,
        },
    }
    by_external_payload = {
        "success": True,
        "data": {
            "case": {
                "id": "case-1",
                "application_id": "app-1",
                "external_case_ref": "thread_123",
                "status": "in_progress",
                "priority": "high",
                "assigned_to_user_id": None,
                "resolved_at": None,
                "updated_at": "2026-03-01T16:03:00Z",
            }
        },
    }

    get_case_route = respx.get(f"{base_url}/api/v1/support-telemetry/cases/case-1").mock(
        return_value=Response(200, json=case_payload)
    )
    get_external_route = respx.get(
        f"{base_url}/api/v1/support-telemetry/cases/by-external/thread_123"
    ).mock(return_value=Response(200, json=by_external_payload))

    detail = telemetry_client.get_case(case_id="case-1", event_limit=50, event_offset=0)
    by_external = telemetry_client.get_case_by_external_ref(
        external_case_ref="thread_123",
        application_id="app-1",
    )

    assert get_case_route.called
    assert get_external_route.called
    assert detail.case.id == "case-1"
    assert detail.events[0].id == "event-1"
    assert by_external.case.external_case_ref == "thread_123"


@respx.mock
def test_patch_case_success_and_token_override(
    telemetry_client: SupportTelemetryClient,
    base_url: str,
) -> None:
    route = respx.patch(f"{base_url}/api/v1/support-telemetry/cases/case-1").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "case": {
                        "id": "case-1",
                        "status": "resolved",
                        "priority": "high",
                        "assigned_to_user_id": "user-1",
                        "resolved_at": "2026-03-01T16:30:00Z",
                        "updated_at": "2026-03-01T16:30:00Z",
                    }
                },
            },
        )
    )

    result = telemetry_client.patch_case(
        case_id="case-1",
        status="resolved",
        priority="high",
        assigned_to_user_id="user-1",
        resolution_note="done",
        access_token_override="override-token",
    )

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == "Bearer override-token"
    assert result.case.status == "resolved"


@respx.mock
def test_non_json_error_fallback_message(
    telemetry_client: SupportTelemetryClient,
    base_url: str,
) -> None:
    respx.get(f"{base_url}/api/v1/support-telemetry/cases").mock(
        return_value=Response(500, text="server exploded"),
    )

    with pytest.raises(SupportTelemetryError) as exc:
        telemetry_client.list_cases()

    assert exc.value.status_code == 500
    assert "server exploded" in str(exc.value)
