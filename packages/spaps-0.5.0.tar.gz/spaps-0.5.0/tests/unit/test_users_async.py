"""Unit tests for AsyncUsersClient."""

import json

import httpx
import pytest
import respx
from httpx import Response

from spaps_client.users import UsersError, BatchEmailsResult, UserBatchInfo, BatchUsersResult
from spaps_client.users_async import AsyncUsersClient


@pytest.fixture()
def base_url() -> str:
    return "https://api.sweetpotato.dev"


@pytest.fixture()
def api_key() -> str:
    return "test_key_local_dev_only"


@pytest.mark.asyncio
@respx.mock
async def test_get_emails_batch_success(base_url: str, api_key: str) -> None:
    route = respx.post(f"{base_url}/api/users/emails").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "emails": {
                        "user-1": "user1@example.com",
                        "user-2": "user2@example.com",
                    },
                    "total": 2,
                    "with_email": 2,
                },
            },
        )
    )

    client = AsyncUsersClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.get_emails_batch(["user-1", "user-2"])
    finally:
        await client.aclose()

    assert route.called
    body = json.loads(route.calls.last.request.content)
    assert body["user_ids"] == ["user-1", "user-2"]
    assert route.calls.last.request.headers["x-api-key"] == api_key

    assert isinstance(result, BatchEmailsResult)
    assert result.emails["user-1"] == "user1@example.com"
    assert result.emails["user-2"] == "user2@example.com"
    assert result.total == 2
    assert result.with_email == 2


@pytest.mark.asyncio
@respx.mock
async def test_get_emails_batch_null_values(base_url: str, api_key: str) -> None:
    respx.post(f"{base_url}/api/users/emails").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "emails": {
                        "user-with-email": "found@example.com",
                        "wallet-user": None,
                    },
                    "total": 2,
                    "with_email": 1,
                },
            },
        )
    )

    client = AsyncUsersClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.get_emails_batch(["user-with-email", "wallet-user"])
    finally:
        await client.aclose()

    assert result.emails["user-with-email"] == "found@example.com"
    assert result.emails["wallet-user"] is None


@pytest.mark.asyncio
@respx.mock
async def test_get_emails_batch_error_raises_users_error(base_url: str, api_key: str) -> None:
    respx.post(f"{base_url}/api/users/emails").mock(
        return_value=Response(
            400,
            json={
                "success": False,
                "error": {"message": "Invalid user IDs", "code": "INVALID_INPUT"},
            },
        )
    )

    client = AsyncUsersClient(base_url=base_url, api_key=api_key)
    try:
        with pytest.raises(UsersError) as exc_info:
            await client.get_emails_batch(["bad-id"])
    finally:
        await client.aclose()

    assert exc_info.value.status_code == 400
    assert exc_info.value.error_code == "INVALID_INPUT"
    assert "Invalid user IDs" in str(exc_info.value)


@pytest.mark.asyncio
@respx.mock
async def test_get_users_batch_success(base_url: str, api_key: str) -> None:
    route = respx.post(f"{base_url}/api/users/batch").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "users": {
                        "user-1": {
                            "email": "user1@example.com",
                            "active_entitlements": [{"key": "premium"}],
                            "upcoming_bookings": [],
                        },
                        "user-2": {
                            "email": None,
                            "active_entitlements": [],
                        },
                    }
                },
            },
        )
    )

    client = AsyncUsersClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.get_users_batch(["user-1", "user-2"])
    finally:
        await client.aclose()

    assert route.called
    assert isinstance(result, BatchUsersResult)
    assert result.users["user-1"].email == "user1@example.com"
    assert result.users["user-1"].active_entitlements == [{"key": "premium"}]
    assert result.users["user-2"].email is None


@pytest.mark.asyncio
@respx.mock
async def test_get_users_batch_error(base_url: str, api_key: str) -> None:
    respx.post(f"{base_url}/api/users/batch").mock(
        return_value=Response(
            500,
            json={
                "success": False,
                "error": {"message": "Internal server error"},
            },
        )
    )

    client = AsyncUsersClient(base_url=base_url, api_key=api_key)
    try:
        with pytest.raises(UsersError) as exc_info:
            await client.get_users_batch(["user-1"])
    finally:
        await client.aclose()

    assert exc_info.value.status_code == 500


@pytest.mark.asyncio
@respx.mock
async def test_users_error_attributes(base_url: str, api_key: str) -> None:
    respx.post(f"{base_url}/api/users/emails").mock(
        return_value=Response(
            422,
            json={
                "success": False,
                "error": {"message": "Validation failed", "code": "VALIDATION_ERROR"},
                "metadata": {"request_id": "req-abc-123"},
            },
        )
    )

    client = AsyncUsersClient(base_url=base_url, api_key=api_key)
    try:
        with pytest.raises(UsersError) as exc_info:
            await client.get_emails_batch(["x"])
    finally:
        await client.aclose()

    err = exc_info.value
    assert err.status_code == 422
    assert err.error_code == "VALIDATION_ERROR"
    assert err.request_id == "req-abc-123"
    assert err.response is not None


@pytest.mark.asyncio
async def test_aclose_owned_client() -> None:
    client = AsyncUsersClient(
        base_url="https://api.test",
        api_key="key",
    )
    assert client._owns_client is True
    await client.aclose()
    assert client._client.is_closed


@pytest.mark.asyncio
async def test_aclose_injected_client() -> None:
    http_client = httpx.AsyncClient(base_url="https://api.test")
    client = AsyncUsersClient(
        base_url="https://api.test",
        api_key="key",
        client=http_client,
    )
    assert client._owns_client is False
    await client.aclose()
    # Injected client should NOT be closed
    assert not http_client.is_closed
    await http_client.aclose()


def test_batch_emails_result_model_dump() -> None:
    result = BatchEmailsResult(
        emails={"u1": "a@b.com", "u2": None},
        total=2,
        with_email=1,
    )
    d = result.model_dump()
    assert d["emails"]["u1"] == "a@b.com"
    assert d["emails"]["u2"] is None
    assert d["total"] == 2


def test_batch_users_result_model_dump() -> None:
    result = BatchUsersResult(
        users={
            "u1": UserBatchInfo(email="a@b.com", active_entitlements=[{"key": "pro"}]),
        }
    )
    d = result.model_dump()
    assert d["users"]["u1"]["email"] == "a@b.com"
    assert d["users"]["u1"]["active_entitlements"] == [{"key": "pro"}]
