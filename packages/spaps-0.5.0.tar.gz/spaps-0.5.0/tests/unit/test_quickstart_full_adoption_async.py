import json
from typing import Any

import pytest
import respx
from httpx import Response

from spaps_client.dayrate_async import AsyncDayrateClient
from spaps_client.email_async import AsyncEmailClient
from spaps_client.payments_async import AsyncPaymentsClient


@pytest.fixture()
def base_url() -> str:
    return "https://api.sweetpotato.dev"


@pytest.fixture()
def api_key() -> str:
    return "test_key_local_dev_only"


@pytest.fixture()
def access_token() -> str:
    return "admin-token"


@pytest.mark.asyncio
@respx.mock
async def test_async_email_send_supports_owner_and_overrides(
    base_url: str,
    api_key: str,
) -> None:
    route = respx.post(f"{base_url}/api/email/send").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"success": True, "message_id": "msg_123"}},
        )
    )

    client = AsyncEmailClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.send(
            template_key="welcome",
            to="patient@example.com",
            context={"first_name": "Pat"},
            user_id="user-123",
            owner_id="owner-456",
            subject_override="Custom subject",
            body_override="<p>Custom body</p>",
        )
    finally:
        await client.aclose()

    assert route.called
    body = json.loads(route.calls.last.request.content)
    assert body["owner_id"] == "owner-456"
    assert body["subject_override"] == "Custom subject"
    assert body["body_override"] == "<p>Custom body</p>"
    assert result.message_id == "msg_123"


@pytest.mark.asyncio
@respx.mock
async def test_async_email_update_template_uses_auth_header(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.put(f"{base_url}/api/email/templates/welcome").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "template": {
                        "id": "tmpl_1",
                        "template_key": "welcome",
                        "name": "Welcome",
                        "subject": "Hello",
                    }
                },
            },
        )
    )

    client = AsyncEmailClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        template = await client.update_template(
            "welcome",
            subject="Updated subject",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    assert template.template_key == "welcome"


@pytest.mark.asyncio
@respx.mock
async def test_async_email_list_logs_with_filters(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.get(f"{base_url}/api/email/logs").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"logs": [{"id": "log_1"}], "total": 1}},
        )
    )

    client = AsyncEmailClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.list_email_logs(
            owner_id="owner-1",
            user_id="user-1",
            limit=25,
            offset=5,
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.url.params["owner_id"] == "owner-1"
    assert request.url.params["user_id"] == "user-1"
    assert request.url.params["limit"] == "25"
    assert request.url.params["offset"] == "5"
    assert result["total"] == 1


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_create_authenticated_checkout_session(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(f"{base_url}/api/stripe/checkout-sessions").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"id": "cs_auth_1", "url": "https://stripe/cs_auth_1"}},
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.create_authenticated_checkout_session(
            line_items=[{"price_id": "price_123", "quantity": 1}],
            success_url="https://app/success",
            cancel_url="https://app/cancel",
            mode="payment",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["line_items"][0]["price_id"] == "price_123"
    assert result["id"] == "cs_auth_1"


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_create_price_and_set_default(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(
        f"{base_url}/api/stripe/products/super-admin/prod_123/prices/default-new"
    ).mock(
        return_value=Response(
            201,
            json={
                "success": True,
                "data": {"price": {"id": "price_new"}, "product_id": "prod_123"},
            },
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.create_price_and_set_default(
            product_id="prod_123",
            unit_amount=1500,
            currency="usd",
            recurring=True,
            interval="month",
            interval_count=1,
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["unit_amount"] == 1500
    assert body["interval"] == "month"
    assert result["price"]["id"] == "price_new"


@pytest.mark.asyncio
@respx.mock
async def test_async_dayrate_get_allotment_query_mapping(
    base_url: str,
    api_key: str,
) -> None:
    route = respx.get(f"{base_url}/api/dayrate/allotment").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {"policyKey": "checkin", "entitled": True, "allotment": {"remaining": 2}},
            },
        )
    )

    client = AsyncDayrateClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.get_allotment(
            policy_key="checkin",
            user_id="user-123",
            email="patient@example.com",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.url.params["policyKey"] == "checkin"
    assert request.url.params["userId"] == "user-123"
    assert request.url.params["email"] == "patient@example.com"
    assert result["entitled"] is True


@pytest.mark.asyncio
@respx.mock
async def test_async_dayrate_get_admin_bookings_requires_auth(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.get(f"{base_url}/api/dayrate/admin/bookings").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"bookings": [{"id": "bk_1"}], "total": 1}},
        )
    )

    client = AsyncDayrateClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result: dict[str, Any] = await client.get_admin_bookings(
            status="confirmed",
            limit=10,
            offset=0,
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    assert request.url.params["status"] == "confirmed"
    assert request.url.params["limit"] == "10"
    assert result["total"] == 1


@pytest.mark.asyncio
@respx.mock
async def test_async_email_get_override_returns_override_dict(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.get(f"{base_url}/api/email/templates/welcome/override").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {"subject_override": "Custom", "body_override": "<p>Custom</p>"},
            },
        )
    )

    client = AsyncEmailClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.get_override("welcome")
    finally:
        await client.aclose()

    assert route.called
    assert result["subject_override"] == "Custom"


@pytest.mark.asyncio
@respx.mock
async def test_async_email_create_or_update_override_returns_created(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.put(f"{base_url}/api/email/templates/welcome/override").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {"subject_override": "New", "body_override": "<p>New</p>"},
            },
        )
    )

    client = AsyncEmailClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.create_or_update_override(
            "welcome",
            subject_override="New",
            body_override="<p>New</p>",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["subject_override"] == "New"
    assert result["subject_override"] == "New"


@pytest.mark.asyncio
@respx.mock
async def test_async_email_delete_override_returns_result(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.delete(f"{base_url}/api/email/templates/welcome/override").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"deleted": True}},
        )
    )

    client = AsyncEmailClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.delete_override("welcome")
    finally:
        await client.aclose()

    assert route.called
    assert result["deleted"] is True


@pytest.mark.asyncio
@respx.mock
async def test_async_email_create_template_returns_template(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(f"{base_url}/api/email/templates").mock(
        return_value=Response(
            201,
            json={
                "success": True,
                "data": {
                    "template": {
                        "id": "tmpl_new",
                        "template_key": "new_template",
                        "name": "New Template",
                        "subject": "Welcome!",
                    }
                },
            },
        )
    )

    client = AsyncEmailClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.create_template(
            template_key="new_template",
            name="New Template",
            subject="Welcome!",
            html_body="<p>Hello</p>",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["template_key"] == "new_template"
    assert result.template_key == "new_template"


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_create_product(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(f"{base_url}/api/stripe/products").mock(
        return_value=Response(
            201,
            json={
                "success": True,
                "data": {"product": {"id": "prod_new", "name": "New Product", "active": True}},
            },
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.create_product(
            name="New Product",
            description="A new product",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["name"] == "New Product"
    assert result.id == "prod_new"


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_update_product(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.put(f"{base_url}/api/stripe/products/prod_123").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {"product": {"id": "prod_123", "name": "Updated", "active": True}},
            },
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.update_product(
            product_id="prod_123",
            name="Updated",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["name"] == "Updated"
    assert result.id == "prod_123"


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_archive_product(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.delete(f"{base_url}/api/stripe/products/prod_123").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"archived": True}},
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.archive_product(product_id="prod_123")
    finally:
        await client.aclose()

    assert route.called
    assert result["archived"] is True


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_create_price(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(f"{base_url}/api/stripe/prices").mock(
        return_value=Response(
            201,
            json={
                "success": True,
                "data": {
                    "price": {
                        "id": "price_new",
                        "unit_amount": 1000,
                        "currency": "usd",
                        "product_id": "prod_123",
                    }
                },
            },
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.create_price(
            product_id="prod_123",
            unit_amount=1000,
            currency="usd",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["unit_amount"] == 1000
    assert result.id == "price_new"


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_archive_price(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.delete(f"{base_url}/api/stripe/prices/price_123").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"archived": True}},
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.archive_price(price_id="price_123")
    finally:
        await client.aclose()

    assert route.called
    assert result["archived"] is True


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_set_default_price(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(f"{base_url}/api/stripe/products/prod_123/default-price").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "product": {
                        "id": "prod_123",
                        "name": "Product",
                        "default_price_id": "price_456",
                    }
                },
            },
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.set_default_price(
            product_id="prod_123",
            price_id="price_456",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    body = json.loads(request.content)
    assert body["price_id"] == "price_456"
    assert result.id == "prod_123"


@pytest.mark.asyncio
@respx.mock
async def test_async_payments_list_all_products(
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.get(f"{base_url}/api/stripe/products/super-admin/all").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "products": [
                        {"id": "prod_1", "name": "Product 1", "active": True},
                        {"id": "prod_2", "name": "Product 2", "active": True},
                    ],
                    "total": 2,
                },
            },
        )
    )

    client = AsyncPaymentsClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )
    try:
        result = await client.list_all_products()
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    assert len(result.products) == 2
    assert result.total == 2


@pytest.mark.asyncio
@respx.mock
async def test_async_dayrate_get_availability(
    base_url: str,
    api_key: str,
) -> None:
    route = respx.get(f"{base_url}/api/dayrate/availability").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {"slots": [{"date": "2024-01-15", "slot": "morning", "available": True}]},
            },
        )
    )

    client = AsyncDayrateClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.get_availability()
    finally:
        await client.aclose()

    assert route.called
    assert "slots" in result


@pytest.mark.asyncio
@respx.mock
async def test_async_dayrate_create_booking(
    base_url: str,
    api_key: str,
) -> None:
    route = respx.post(f"{base_url}/api/dayrate/book").mock(
        return_value=Response(
            201,
            json={
                "success": True,
                "data": {"booking_id": "bk_new", "status": "confirmed", "checkout_url": "https://stripe.com/cs_1"},
            },
        )
    )

    client = AsyncDayrateClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.create_booking(
            date="2024-01-15",
            slot="morning",
            client_email="client@example.com",
            client_name="John Doe",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    body = json.loads(request.content)
    assert body["clientEmail"] == "client@example.com"
    assert result["booking_id"] == "bk_new"


@pytest.mark.asyncio
@respx.mock
async def test_async_dayrate_cancel_booking(
    base_url: str,
    api_key: str,
) -> None:
    route = respx.post(f"{base_url}/api/dayrate/cancel").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"booking_id": "bk_123", "status": "cancelled"}},
        )
    )

    client = AsyncDayrateClient(base_url=base_url, api_key=api_key)
    try:
        result = await client.cancel_booking(
            booking_id="bk_123",
            user_id="user-456",
            email="client@example.com",
        )
    finally:
        await client.aclose()

    assert route.called
    request = route.calls.last.request
    body = json.loads(request.content)
    assert body["bookingId"] == "bk_123"
    assert body["userId"] == "user-456"
    assert result["status"] == "cancelled"
