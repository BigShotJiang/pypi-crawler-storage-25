"""Unit tests for EmailClient - TDD style."""

from typing import Any, Dict

import pytest
import respx
from httpx import Response

from spaps_client.email import (
    EmailClient,
    EmailError,
)


@pytest.fixture()
def base_url() -> str:
    return "https://api.sweetpotato.dev"


@pytest.fixture()
def api_key() -> str:
    return "test_key_local_dev_only"


@pytest.fixture()
def email_client(base_url: str, api_key: str) -> EmailClient:
    return EmailClient(base_url=base_url, api_key=api_key)


@pytest.fixture()
def send_success_payload() -> Dict[str, Any]:
    return {
        "success": True,
        "data": {
            "success": True,
            "message_id": "mailgun-msg-123abc",
        },
    }


@pytest.fixture()
def template_payload() -> Dict[str, Any]:
    return {
        "success": True,
        "data": {
            "id": "tmpl-uuid-123",
            "application_id": "app-consumer_app",
            "template_key": "enrollment_reminder",
            "name": "Enrollment Reminder",
            "description": "Sent when patient has incomplete enrollment",
            "subject": "{{patient_name}}, don't forget your {{enrollment_name}}",
            "html_body": "<html><body>Hello {{patient_name}}</body></html>",
            "text_body": "Hello {{patient_name}}",
            "from_email": "noreply@healingwithhailey.com",
            "from_name": "Healing with Hailey",
            "reply_to": "support@healingwithhailey.com",
            "variables": [
                {"name": "patient_name", "required": True},
                {"name": "enrollment_name", "required": True},
            ],
            "sample_context": {
                "patient_name": "Jane",
                "enrollment_name": "Weekly Check-in",
            },
            "category": "notification",
            "is_active": True,
            "created_at": "2026-01-10T12:00:00.000Z",
            "updated_at": "2026-01-10T12:00:00.000Z",
        },
    }


@pytest.fixture()
def templates_list_payload() -> Dict[str, Any]:
    return {
        "success": True,
        "data": {
            "templates": [
                {
                    "id": "tmpl-uuid-123",
                    "application_id": "app-consumer_app",
                    "template_key": "magic_link",
                    "name": "Magic Link",
                    "description": "Sent for passwordless login",
                    "subject": "Sign in to {{app_name}}",
                    "category": "auth",
                    "is_active": True,
                },
                {
                    "id": "tmpl-uuid-456",
                    "application_id": "app-consumer_app",
                    "template_key": "enrollment_reminder",
                    "name": "Enrollment Reminder",
                    "description": "Sent when patient has incomplete enrollment",
                    "subject": "{{patient_name}}, don't forget!",
                    "category": "notification",
                    "is_active": True,
                },
            ]
        },
    }


@pytest.fixture()
def preview_payload() -> Dict[str, Any]:
    return {
        "success": True,
        "data": {
            "subject": "Jane, don't forget your Weekly Check-in",
            "html": "<html><body>Hello Jane</body></html>",
            "text": "Hello Jane",
        },
    }


# =============================================================================
# send() tests
# =============================================================================


@respx.mock
def test_send_email_success(
    email_client: EmailClient,
    base_url: str,
    api_key: str,
    send_success_payload: Dict[str, Any],
) -> None:
    """Test successful email send."""
    route = respx.post(f"{base_url}/api/email/send").mock(
        return_value=Response(200, json=send_success_payload)
    )

    result = email_client.send(
        template_key="enrollment_reminder",
        to="patient@example.com",
        context={
            "patient_name": "Jane",
            "enrollment_name": "Weekly Check-in",
            "action_url": "https://app.healingwithhailey.com/checkin/123",
        },
    )

    assert route.called, "Send email endpoint not called"
    request = route.calls.last.request
    assert request.headers["X-API-Key"] == api_key

    assert result.success is True
    assert result.message_id == "mailgun-msg-123abc"


@respx.mock
def test_send_email_with_user_id(
    email_client: EmailClient,
    base_url: str,
    send_success_payload: Dict[str, Any],
) -> None:
    """Test email send with optional user_id for logging."""
    route = respx.post(f"{base_url}/api/email/send").mock(
        return_value=Response(200, json=send_success_payload)
    )

    email_client.send(
        template_key="welcome",
        to="user@example.com",
        context={"user_name": "John"},
        user_id="user-uuid-123",
    )

    assert route.called
    import json

    request_body = json.loads(route.calls.last.request.content)
    assert request_body["user_id"] == "user-uuid-123"


@respx.mock
def test_send_email_failure(
    email_client: EmailClient,
    base_url: str,
) -> None:
    """Test email send failure returns error."""
    respx.post(f"{base_url}/api/email/send").mock(
        return_value=Response(
            400,
            json={
                "success": False,
                "error": {
                    "code": "TEMPLATE_NOT_FOUND",
                    "message": "Template not found: nonexistent_template",
                },
            },
        )
    )

    with pytest.raises(EmailError) as exc:
        email_client.send(
            template_key="nonexistent_template",
            to="user@example.com",
            context={},
        )

    assert exc.value.status_code == 400
    assert exc.value.error_code == "TEMPLATE_NOT_FOUND"


# =============================================================================
# list_templates() tests
# =============================================================================


@respx.mock
def test_list_templates(
    email_client: EmailClient,
    base_url: str,
    api_key: str,
    templates_list_payload: Dict[str, Any],
) -> None:
    """Test listing all templates for an application."""
    route = respx.get(f"{base_url}/api/email/templates").mock(
        return_value=Response(200, json=templates_list_payload)
    )

    templates = email_client.list_templates()

    assert route.called
    request = route.calls.last.request
    assert request.headers["X-API-Key"] == api_key

    assert len(templates) == 2
    assert templates[0].template_key == "magic_link"
    assert templates[0].category == "auth"
    assert templates[1].template_key == "enrollment_reminder"
    assert templates[1].category == "notification"


@respx.mock
def test_list_templates_empty(
    email_client: EmailClient,
    base_url: str,
) -> None:
    """Test listing templates when none exist."""
    respx.get(f"{base_url}/api/email/templates").mock(
        return_value=Response(200, json={"success": True, "data": {"templates": []}})
    )

    templates = email_client.list_templates()
    assert templates == []


# =============================================================================
# get_template() tests
# =============================================================================


@respx.mock
def test_get_template(
    email_client: EmailClient,
    base_url: str,
    api_key: str,
    template_payload: Dict[str, Any],
) -> None:
    """Test getting a single template by key."""
    route = respx.get(f"{base_url}/api/email/templates/enrollment_reminder").mock(
        return_value=Response(200, json=template_payload)
    )

    template = email_client.get_template("enrollment_reminder")

    assert route.called
    assert template.template_key == "enrollment_reminder"
    assert template.name == "Enrollment Reminder"
    assert template.html_body == "<html><body>Hello {{patient_name}}</body></html>"
    assert template.from_email == "noreply@healingwithhailey.com"
    assert template.is_active is True


@respx.mock
def test_get_template_not_found(
    email_client: EmailClient,
    base_url: str,
) -> None:
    """Test getting a template that doesn't exist."""
    respx.get(f"{base_url}/api/email/templates/nonexistent").mock(
        return_value=Response(
            404,
            json={
                "success": False,
                "error": {
                    "code": "TEMPLATE_NOT_FOUND",
                    "message": "Template not found",
                },
            },
        )
    )

    with pytest.raises(EmailError) as exc:
        email_client.get_template("nonexistent")

    assert exc.value.status_code == 404


# =============================================================================
# preview_template() tests
# =============================================================================


@respx.mock
def test_preview_template(
    email_client: EmailClient,
    base_url: str,
    preview_payload: Dict[str, Any],
) -> None:
    """Test previewing a template with sample data."""
    route = respx.get(f"{base_url}/api/email/templates/enrollment_reminder/preview").mock(
        return_value=Response(200, json=preview_payload)
    )

    preview = email_client.preview_template("enrollment_reminder")

    assert route.called
    assert preview.subject == "Jane, don't forget your Weekly Check-in"
    assert "Hello Jane" in preview.html
    assert preview.text == "Hello Jane"


@respx.mock
def test_preview_template_with_custom_context(
    email_client: EmailClient,
    base_url: str,
) -> None:
    """Test previewing a template with custom context variables."""
    custom_preview = {
        "success": True,
        "data": {
            "subject": "John, your Weekly Reflection",
            "html": "<html><body>Hello John</body></html>",
            "text": "Hello John",
        },
    }
    route = respx.post(f"{base_url}/api/email/templates/enrollment_reminder/preview").mock(
        return_value=Response(200, json=custom_preview)
    )

    preview = email_client.preview_template(
        "enrollment_reminder",
        context={"patient_name": "John", "enrollment_name": "Weekly Reflection"},
    )

    assert route.called
    assert preview.subject == "John, your Weekly Reflection"


# =============================================================================
# Error handling tests
# =============================================================================


@respx.mock
def test_email_error_includes_request_id(
    email_client: EmailClient,
    base_url: str,
) -> None:
    """Test that EmailError captures request ID from response headers."""
    respx.post(f"{base_url}/api/email/send").mock(
        return_value=Response(
            500,
            json={"success": False, "error": {"message": "Internal error"}},
            headers={"x-request-id": "req-abc123"},
        )
    )

    with pytest.raises(EmailError) as exc:
        email_client.send(
            template_key="test",
            to="user@example.com",
            context={},
        )

    assert exc.value.request_id == "req-abc123"


# =============================================================================
# Context manager tests
# =============================================================================


def test_context_manager(base_url: str, api_key: str) -> None:
    """Test EmailClient as context manager."""
    with EmailClient(base_url=base_url, api_key=api_key) as client:
        assert client is not None
    # Client should be closed after exiting context
