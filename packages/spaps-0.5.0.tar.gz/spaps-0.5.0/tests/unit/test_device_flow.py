"""Tests for the DeviceFlowClient."""

from typing import Any, Dict
from unittest.mock import patch

import pytest
import respx
from httpx import Response

from spaps_client.device_flow import (
    DeviceFlowClient,
    DeviceFlowDeniedError,
    DeviceFlowError,
    DeviceFlowExpiredError,
    DeviceFlowPendingError,
    DeviceFlowResponse,
    DeviceFlowTimeoutError,
    DeviceFlowTokenPair,
)
from spaps_client.storage import InMemoryTokenStorage


@pytest.fixture()
def base_url() -> str:
    return "https://api.sweetpotato.dev"


@pytest.fixture()
def api_key() -> str:
    return "test_key_local_dev_only"


@pytest.fixture()
def token_storage() -> InMemoryTokenStorage:
    return InMemoryTokenStorage()


@pytest.fixture()
def device_client(
    base_url: str, api_key: str, token_storage: InMemoryTokenStorage
) -> DeviceFlowClient:
    return DeviceFlowClient(
        base_url=base_url,
        api_key=api_key,
        poll_interval=0,
        timeout=5,
        token_storage=token_storage,
    )


@pytest.fixture()
def authorize_payload() -> Dict[str, Any]:
    return {
        "success": True,
        "data": {
            "device_code": "dev_abc123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://sweetpotato.dev/device",
            "expires_in": 900,
            "interval": 5,
        },
    }


@pytest.fixture()
def token_payload() -> Dict[str, Any]:
    return {
        "success": True,
        "data": {
            "access_token": "access-token",
            "refresh_token": "refresh-token",
            "expires_in": 3600,
            "token_type": "Bearer",
        },
    }


class TestDeviceFlowResponse:
    """Tests for the DeviceFlowResponse model."""

    def test_parse_response(self) -> None:
        data = {
            "device_code": "dev_abc123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://sweetpotato.dev/device",
            "expires_in": 900,
            "interval": 5,
        }
        resp = DeviceFlowResponse.model_validate(data)
        assert resp.device_code == "dev_abc123"
        assert resp.user_code == "ABCD-1234"
        assert resp.verification_uri == "https://sweetpotato.dev/device"
        assert resp.expires_in == 900
        assert resp.interval == 5

    def test_extra_fields_ignored(self) -> None:
        data = {
            "device_code": "dev_abc123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://sweetpotato.dev/device",
            "expires_in": 900,
            "interval": 5,
            "extra_field": "ignored",
        }
        resp = DeviceFlowResponse.model_validate(data)
        assert resp.device_code == "dev_abc123"


class TestDeviceFlowTokenPair:
    """Tests for the DeviceFlowTokenPair model."""

    def test_parse_token_pair(self) -> None:
        data = {
            "access_token": "access-token",
            "refresh_token": "refresh-token",
            "expires_in": 3600,
            "token_type": "Bearer",
        }
        pair = DeviceFlowTokenPair.model_validate(data)
        assert pair.access_token == "access-token"
        assert pair.refresh_token == "refresh-token"
        assert pair.expires_in == 3600
        assert pair.token_type == "Bearer"

    def test_default_token_type(self) -> None:
        data = {
            "access_token": "access-token",
            "refresh_token": "refresh-token",
            "expires_in": 3600,
        }
        pair = DeviceFlowTokenPair.model_validate(data)
        assert pair.token_type == "Bearer"


class TestDeviceFlowErrors:
    """Tests for error types."""

    def test_base_error(self) -> None:
        err = DeviceFlowError("something failed", status_code=500, error_code="ERR")
        assert str(err) == "something failed"
        assert err.status_code == 500
        assert err.error_code == "ERR"

    def test_pending_error_inherits(self) -> None:
        err = DeviceFlowPendingError("still waiting")
        assert isinstance(err, DeviceFlowError)

    def test_expired_error_inherits(self) -> None:
        err = DeviceFlowExpiredError("code expired")
        assert isinstance(err, DeviceFlowError)

    def test_denied_error_inherits(self) -> None:
        err = DeviceFlowDeniedError("user denied")
        assert isinstance(err, DeviceFlowError)

    def test_timeout_error_inherits(self) -> None:
        err = DeviceFlowTimeoutError("poll timeout")
        assert isinstance(err, DeviceFlowError)


class TestDeviceFlowClientStart:
    """Tests for DeviceFlowClient.start()."""

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_start_returns_device_code(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
        authorize_payload: Dict[str, Any],
    ) -> None:
        route = respx.post(f"{base_url}/api/cli/device/authorize").mock(
            return_value=Response(200, json=authorize_payload)
        )

        result = await device_client.start()

        assert route.called
        assert isinstance(result, DeviceFlowResponse)
        assert result.device_code == "dev_abc123"
        assert result.user_code == "ABCD-1234"
        assert result.verification_uri == "https://sweetpotato.dev/device"
        assert result.expires_in == 900
        assert result.interval == 5

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_start_with_scope(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
        authorize_payload: Dict[str, Any],
    ) -> None:
        route = respx.post(f"{base_url}/api/cli/device/authorize").mock(
            return_value=Response(200, json=authorize_payload)
        )

        await device_client.start(scope="openid profile")

        assert route.called

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_start_error(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
    ) -> None:
        error_payload = {
            "error": {
                "code": "INVALID_REQUEST",
                "message": "Bad request",
            },
        }
        respx.post(f"{base_url}/api/cli/device/authorize").mock(
            return_value=Response(400, json=error_payload)
        )

        with pytest.raises(DeviceFlowError) as exc_info:
            await device_client.start()

        assert exc_info.value.status_code == 400
        assert exc_info.value.error_code == "INVALID_REQUEST"


class TestDeviceFlowClientPoll:
    """Tests for DeviceFlowClient.poll()."""

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_poll_returns_tokens(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
        token_payload: Dict[str, Any],
    ) -> None:
        route = respx.post(f"{base_url}/api/cli/device/token").mock(
            return_value=Response(200, json=token_payload)
        )

        result = await device_client.poll("dev_abc123")

        assert route.called
        assert isinstance(result, DeviceFlowTokenPair)
        assert result.access_token == "access-token"
        assert result.refresh_token == "refresh-token"

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_poll_stores_tokens(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
        token_payload: Dict[str, Any],
        token_storage: InMemoryTokenStorage,
    ) -> None:
        respx.post(f"{base_url}/api/cli/device/token").mock(
            return_value=Response(200, json=token_payload)
        )

        await device_client.poll("dev_abc123")

        stored = token_storage.load()
        assert stored is not None
        assert stored.access_token == "access-token"
        assert stored.refresh_token == "refresh-token"
        assert stored.token_type == "Bearer"
        assert stored.expires_at is not None

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_poll_handles_pending_then_success(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
        token_payload: Dict[str, Any],
    ) -> None:
        """Test that poll retries on authorization_pending then returns tokens."""
        pending_payload = {
            "error": {
                "code": "authorization_pending",
                "message": "User has not yet authorized",
            },
        }
        route = respx.post(f"{base_url}/api/cli/device/token").mock(
            side_effect=[
                Response(400, json=pending_payload),
                Response(200, json=token_payload),
            ]
        )

        result = await device_client.poll("dev_abc123")

        assert route.call_count == 2
        assert result.access_token == "access-token"

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_poll_raises_on_expired(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
    ) -> None:
        expired_payload = {
            "error": {
                "code": "expired_token",
                "message": "Device code has expired",
            },
        }
        respx.post(f"{base_url}/api/cli/device/token").mock(
            return_value=Response(400, json=expired_payload)
        )

        with pytest.raises(DeviceFlowExpiredError):
            await device_client.poll("dev_abc123")

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_poll_raises_on_denied(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
    ) -> None:
        denied_payload = {
            "error": {
                "code": "access_denied",
                "message": "User denied the authorization",
            },
        }
        respx.post(f"{base_url}/api/cli/device/token").mock(
            return_value=Response(403, json=denied_payload)
        )

        with pytest.raises(DeviceFlowDeniedError):
            await device_client.poll("dev_abc123")

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_poll_raises_timeout(
        self,
        base_url: str,
        api_key: str,
        token_storage: InMemoryTokenStorage,
    ) -> None:
        """Test that poll raises DeviceFlowTimeoutError after the deadline."""
        # Create a client with a very short timeout.
        client = DeviceFlowClient(
            base_url=base_url,
            api_key=api_key,
            poll_interval=0,
            timeout=0,  # Immediate timeout
            token_storage=token_storage,
        )
        pending_payload = {
            "error": {
                "code": "authorization_pending",
                "message": "User has not yet authorized",
            },
        }
        respx.post(f"{base_url}/api/cli/device/token").mock(
            return_value=Response(400, json=pending_payload)
        )

        with pytest.raises(DeviceFlowTimeoutError):
            await client.poll("dev_abc123")


class TestDeviceFlowClientLogin:
    """Tests for DeviceFlowClient.login()."""

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_login_orchestrates_start_and_poll(
        self,
        base_url: str,
        device_client: DeviceFlowClient,
        authorize_payload: Dict[str, Any],
        token_payload: Dict[str, Any],
    ) -> None:
        respx.post(f"{base_url}/api/cli/device/authorize").mock(
            return_value=Response(200, json=authorize_payload)
        )
        respx.post(f"{base_url}/api/cli/device/token").mock(
            return_value=Response(200, json=token_payload)
        )

        with patch("builtins.print") as mock_print:
            result = await device_client.login()

        assert isinstance(result, DeviceFlowTokenPair)
        assert result.access_token == "access-token"
        # Verify that instructions were printed.
        mock_print.assert_called_once()
        printed_text = mock_print.call_args[0][0]
        assert "ABCD-1234" in printed_text
        assert "https://sweetpotato.dev/device" in printed_text


class TestDeviceFlowClientNoStorage:
    """Tests for DeviceFlowClient without token storage."""

    @pytest.mark.asyncio(loop_scope="function")
    @respx.mock
    async def test_poll_without_storage(
        self,
        base_url: str,
        api_key: str,
    ) -> None:
        """Tokens are returned even without storage configured."""
        client = DeviceFlowClient(
            base_url=base_url,
            api_key=api_key,
            poll_interval=0,
            timeout=5,
        )
        token_payload = {
            "success": True,
            "data": {
                "access_token": "access-token",
                "refresh_token": "refresh-token",
                "expires_in": 3600,
                "token_type": "Bearer",
            },
        }
        respx.post(f"{base_url}/api/cli/device/token").mock(
            return_value=Response(200, json=token_payload)
        )

        result = await client.poll("dev_abc123")
        assert result.access_token == "access-token"
