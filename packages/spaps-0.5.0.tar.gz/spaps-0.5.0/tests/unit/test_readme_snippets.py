import logging

import pytest
import respx
from httpx import Response

from spaps_client import AsyncSpapsClient, RetryConfig, SpapsClient, default_logging_hooks


@pytest.fixture()
def base_url() -> str:
    return "https://api.sweetpotato.dev"


@pytest.fixture()
def api_key() -> str:
    return "test_key_local_dev_only"


@respx.mock
def test_readme_sync_quickstart_snippet_executes(base_url: str, api_key: str) -> None:
    """Keep the README sync quickstart example executable."""

    respx.post(f"{base_url}/api/auth/login").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "access_token": "access-token",
                    "refresh_token": "refresh-token",
                    "expires_in": 900,
                    "token_type": "Bearer",
                    "user": {"id": "user_123", "email": "user@example.com", "tier": "pro"},
                },
            },
        )
    )
    respx.get(f"{base_url}/api/sessions/current").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "session": {
                        "id": "sess_123",
                        "user_id": "user_123",
                        "application_id": "app_123",
                        "created_at": "2026-01-01T00:00:00Z",
                        "expires_at": "2026-01-01T01:00:00Z",
                    }
                },
            },
        )
    )
    respx.post(f"{base_url}/api/payments/create-checkout-session").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "session_id": "cs_test_123",
                    "checkout_url": "https://checkout.stripe.com/pay/cs_test_123",
                },
            },
        )
    )

    spaps = SpapsClient(base_url=base_url, api_key=api_key)
    try:
        spaps.auth.sign_in_with_password(email="user@example.com", password="Secret123!")
        current = spaps.sessions.get_current_session()
        checkout = spaps.payments.create_checkout_session(
            price_id="price_123",
            mode="subscription",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            require_legal_consent=True,
            legal_consent_text="I am 18+ and accept the HTMA Terms & Privacy.",
        )
    finally:
        spaps.close()

    assert current.session_id == "sess_123"
    assert checkout.session_id == "cs_test_123"


def test_readme_retry_and_logging_snippet_executes(base_url: str, api_key: str) -> None:
    """Keep README retry/logging constructor snippet executable."""

    logging.getLogger("spaps_client.http").setLevel(logging.DEBUG)
    spaps = SpapsClient(
        base_url=base_url,
        api_key=api_key,
        retry_config=RetryConfig(max_attempts=4, backoff_factor=0.2),
        logging_hooks=default_logging_hooks(),
    )
    spaps.close()


@pytest.mark.asyncio
@respx.mock
async def test_readme_async_quickstart_snippet_executes(base_url: str, api_key: str) -> None:
    """Keep the README async quickstart snippet executable."""

    respx.post(f"{base_url}/api/auth/login").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "access_token": "access-token",
                    "refresh_token": "refresh-token",
                    "expires_in": 900,
                    "token_type": "Bearer",
                    "user": {"id": "user_123", "email": "user@example.com", "tier": "pro"},
                },
            },
        )
    )
    respx.get(f"{base_url}/api/sessions").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {"sessions": [], "total": 0},
            },
        )
    )

    client = AsyncSpapsClient(base_url=base_url, api_key=api_key)
    try:
        await client.auth.sign_in_with_password(email="user@example.com", password="Secret123!")
        current = await client.sessions.list_sessions()
    finally:
        await client.aclose()

    assert current.total == 0
