from __future__ import annotations

import pytest
import respx
from httpx import Response

from spaps_client.issue_reporting import IssueReportingClient, IssueReportingError


@pytest.fixture()
def base_url() -> str:
    return "https://api.sweetpotato.dev"


@pytest.fixture()
def api_key() -> str:
    return "test_key_local_dev_only"


@pytest.fixture()
def access_token() -> str:
    return "access-token"


@pytest.fixture()
def issue_reporting_client(
    base_url: str,
    api_key: str,
    access_token: str,
) -> IssueReportingClient:
    return IssueReportingClient(
        base_url=base_url,
        api_key=api_key,
        access_token=access_token,
    )


def _issue_report_payload(*, parent_issue_report_id: str | None = None) -> dict[str, object]:
    return {
        "id": "issue-1",
        "application_id": "app-1",
        "reporter_user_id": "user-1",
        "reporter_role_hint": "practitioner",
        "target": {
            "component_key": "patient_protocol_widget",
            "component_label": "Patient Protocol Widget",
            "page_url": "/patients/123/protocol",
            "surface_ref": "daily-log",
            "metadata": {"section": "daily log"},
        },
        "note": "The save action silently fails after I edit today's protocol note.",
        "status": "open",
        "parent_issue_report_id": parent_issue_report_id,
        "linked_case": {
            "case_id": "case-1",
            "status": "open",
            "priority": "normal",
            "resolved_at": None,
        },
        "created_at": "2026-03-29T00:00:00Z",
        "updated_at": "2026-03-29T00:00:00Z",
    }


@respx.mock
def test_create_issue_report_success(
    issue_reporting_client: IssueReportingClient,
    base_url: str,
    api_key: str,
    access_token: str,
) -> None:
    route = respx.post(f"{base_url}/api/v1/issue-reports").mock(
        return_value=Response(201, json={"success": True, "data": _issue_report_payload()})
    )

    result = issue_reporting_client.create_issue_report(
        target={
            "component_key": "patient_protocol_widget",
            "component_label": "Patient Protocol Widget",
            "page_url": "/patients/123/protocol",
            "surface_ref": "daily-log",
            "metadata": {"section": "daily log"},
        },
        note="The save action silently fails after I edit today's protocol note.",
        reporter_role_hint="practitioner",
    )

    assert route.called
    request = route.calls.last.request
    assert request.headers["X-API-Key"] == api_key
    assert request.headers["Authorization"] == f"Bearer {access_token}"
    assert result.id == "issue-1"
    assert result.linked_case.case_id == "case-1"


@respx.mock
def test_list_status_get_update_and_reply(
    issue_reporting_client: IssueReportingClient,
    base_url: str,
) -> None:
    list_route = respx.get(f"{base_url}/api/v1/issue-reports").mock(
        return_value=Response(
            200,
            json={"success": True, "data": {"items": [_issue_report_payload()], "total": 1}},
        )
    )
    status_route = respx.get(f"{base_url}/api/v1/issue-reports/status").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {
                    "has_open": True,
                    "has_recent_resolved": False,
                    "open_count": 1,
                    "recent_resolved_count": 0,
                },
            },
        )
    )
    get_route = respx.get(f"{base_url}/api/v1/issue-reports/issue-1").mock(
        return_value=Response(200, json={"success": True, "data": _issue_report_payload()})
    )
    update_route = respx.patch(f"{base_url}/api/v1/issue-reports/issue-1").mock(
        return_value=Response(
            200,
            json={
                "success": True,
                "data": {**_issue_report_payload(), "note": "Updated detail with clearer reproduction steps."},
            },
        )
    )
    reply_route = respx.post(f"{base_url}/api/v1/issue-reports/issue-1/replies").mock(
        return_value=Response(
            201,
            json={
                "success": True,
                "data": _issue_report_payload(parent_issue_report_id="issue-1"),
            },
        )
    )

    listed = issue_reporting_client.list_issue_reports(status="open", limit=10, offset=0)
    status = issue_reporting_client.get_issue_report_status()
    detail = issue_reporting_client.get_issue_report(issue_report_id="issue-1")
    updated = issue_reporting_client.update_issue_report(
        issue_report_id="issue-1",
        note="Updated detail with clearer reproduction steps.",
    )
    replied = issue_reporting_client.reply_to_issue_report(
        issue_report_id="issue-1",
        note="This still fails after the reported fix.",
    )

    assert list_route.called
    assert status_route.called
    assert get_route.called
    assert update_route.called
    assert reply_route.called
    assert listed.total == 1
    assert status.open_count == 1
    assert detail.id == "issue-1"
    assert updated.note == "Updated detail with clearer reproduction steps."
    assert replied.parent_issue_report_id == "issue-1"


@respx.mock
def test_issue_reporting_error_raises(
    issue_reporting_client: IssueReportingClient,
    base_url: str,
) -> None:
    respx.get(f"{base_url}/api/v1/issue-reports/status").mock(
        return_value=Response(
            409,
            json={
                "success": False,
                "error": {
                    "code": "ISSUE_REPORT_CASE_LINK_BROKEN",
                    "message": "Issue report support-case linkage is broken",
                },
            },
        )
    )

    with pytest.raises(IssueReportingError) as exc:
        issue_reporting_client.get_issue_report_status()

    assert exc.value.status_code == 409
    assert exc.value.error_code == "ISSUE_REPORT_CASE_LINK_BROKEN"
