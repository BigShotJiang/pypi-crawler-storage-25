# Changelog

All notable changes to this project are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

- No changes yet.

## [0.4.1] - 2026-02-18

### Changed

- Relaxed required fields in email and entitlement schemas for forward compatibility.
- Relaxed `Entitlement.source` from `Literal` to `str` to accept newly introduced source types without forcing immediate client upgrades.

## [0.4.0] - 2026-02-17

### Added

- `UsersClient` and `AsyncUsersClient` for user management operations.
- Async quickstart parity wrappers aligned with server-side helpers.
- Referral fields in registration flow.

## [0.3.0] - 2026-02-11

### Changed

- Consolidated SPAPS integration patterns into published packages.
- Aligned Python client surface area with production SPAPS APIs.

## [0.2.0] - 2025-12-30

### Added

- Broader SDK coverage to support production cutover requirements.
- Email-service and set-password endpoint client stubs.

### Changed

- Standardized configuration defaults (including port `3301` and environment symlink conventions).

## [0.1.4] - 2025-11-09

### Fixed

- Session validation response parsing for the `valid` field contract.

## [0.1.3] - 2025-10-14

### Added

- Subscription list/detail/cancel/swap helpers to match TypeScript SDK behavior.
- Checkout session lookup/list/expire and guest checkout lifecycle helpers.
- Stripe payment history summaries and payment-detail retrieval.
- Client-side role/permission utilities in `spaps_client.permissions`.

### Changed

- Refreshed README examples for newly added helpers.

## [0.1.2] - 2025-10-12

### Changed

- Standardized crypto invoice lookup helper behavior and logging paths.

## [0.1.1] - 2025-10-11

### Changed

- Widened `httpx` dependency range to `<0.29` for FastAPI default-stack compatibility (`0.28.x`).

## [0.1.0] - 2025-10-11

### Added

- Initial public PyPI release under the `spaps` distribution name.
- Sync and async clients for sessions, payments (including crypto), usage, whitelist, secure messages, and metrics.
- Configurable retry/backoff behavior, logging hooks, and token storage abstractions.
- Linting/type-checking/coverage gates integrated with the release workflow.
- Python quickstart documentation and backend integration guide.
