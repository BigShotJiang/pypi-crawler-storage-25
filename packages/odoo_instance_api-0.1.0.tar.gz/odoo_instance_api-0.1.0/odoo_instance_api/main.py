import argparse
import logging
import os
from pathlib import Path
from fastapi import FastAPI, Request, Query
from fastapi.responses import HTMLResponse
from jinja2 import Environment, FileSystemLoader, select_autoescape
from typing import Optional
from .db import (
    get_db_credentials,
    get_databases,
    get_db_modules,
    get_db_uninstalled_modules,
    get_effective_core_module_exclusions,
)
from .mapping import (
    apply_status_filters,
    build_mapping_summary,
    build_package_module_mapping,
    build_package_module_relation_table,
    build_uninstalled_module_matches,
)
from .packages import (
    get_odoo_series,
    get_package_module_candidates,
    get_pip_packages,
    get_pypi_latest_version,
    get_python_version,
    is_odoo_package_name,
)
def configure_logging(log_level: str) -> None:
    """Configure root logging and quiet noisy dependency loggers.

    Args:
        log_level: Requested logging level name. Invalid values fallback to INFO.
    """
    normalized_level = (log_level or "INFO").upper()
    level = getattr(logging, normalized_level, logging.INFO)
    root_logger = logging.getLogger()

    if not root_logger.handlers:
        logging.basicConfig(
            level=level,
            format="%(asctime)s %(levelname)s %(name)s - %(message)s",
        )
    else:
        root_logger.setLevel(level)

    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)


configure_logging(os.environ.get("OIA_LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

app = FastAPI(title="Odoo Instance API")

TEMPLATES_DIR = Path(__file__).with_name("templates")
JINJA_ENV = Environment(
    loader=FileSystemLoader(TEMPLATES_DIR),
    autoescape=select_autoescape(["html", "xml"]),
)

def render_html() -> str:
    """Render the status dashboard HTML shell.

    Returns:
        Rendered HTML document for the dashboard page.
    """
    template = JINJA_ENV.get_template("status.html")
    return template.render()


def cli() -> None:
    """Run the API through the CLI entrypoint using Uvicorn."""
    parser = argparse.ArgumentParser(description="Run the Odoo Instance API server")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    parser.add_argument(
        "--log-level",
        default=os.environ.get("OIA_LOG_LEVEL", "info"),
        choices=["critical", "error", "warning", "info", "debug"],
        help="Application and Uvicorn log level (default: info)",
    )
    args = parser.parse_args()

    configure_logging(args.log_level)
    logger.info(
        "Starting API server host=%s port=%s reload=%s log_level=%s",
        args.host,
        args.port,
        args.reload,
        args.log_level,
    )

    import uvicorn
    uvicorn.run(
        "odoo_instance_api.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=args.log_level,
    )

def collect_status_data() -> dict:
    """Collect status information from Python, PyPI, and PostgreSQL sources.

    Returns:
        Dictionary payload consumed by both JSON and HTML status views.
    """
    logger.info("Collecting status payload")
    python_version = get_python_version()
    all_packages = get_pip_packages()
    logger.debug("Collected pip packages count=%s", len(all_packages))

    odoo_version = "Not found"
    if "odoo" in all_packages:
        odoo_version = all_packages["odoo"]["version"]
    odoo_series = get_odoo_series(odoo_version)

    odoo_packages = []
    for pkg_name, info in all_packages.items():
        if is_odoo_package_name(pkg_name) and pkg_name != "odoo":
            avail = get_pypi_latest_version(pkg_name, odoo_series=odoo_series)
            odoo_packages.append({
                "name": pkg_name,
                "installed_version": info["version"],
                "available_version": avail
            })

    package_module_candidates = get_package_module_candidates()
    candidate_non_empty_count = sum(
        1
        for candidate_modules in package_module_candidates.values()
        if candidate_modules
    )
    logger.debug(
        "Collected package-module candidates total=%s non_empty=%s",
        len(package_module_candidates),
        candidate_non_empty_count,
    )
    credentials = get_db_credentials()
    db_names = get_databases(credentials)
    logger.debug("Discovered databases count=%s", len(db_names))

    databases_info = []
    for db in db_names:
        modules = get_db_modules(credentials, db)
        uninstalled_modules = get_db_uninstalled_modules(credentials, db)
        databases_info.append({
            "name": db,
            "non_core_modules": modules,
            "uninstalled_non_core_modules": uninstalled_modules,
        })

    package_module_mapping = build_package_module_mapping(
        odoo_packages=odoo_packages,
        databases_info=databases_info,
        package_module_candidates=package_module_candidates,
    )
    mapping_stats = package_module_mapping.get("stats", {})
    logger.info(
        "Package-module mapping built databases=%s matched_pairs=%s unmatched_packages=%s unmatched_modules=%s",
        mapping_stats.get("databases", 0),
        mapping_stats.get("matched_pairs", 0),
        mapping_stats.get("unmatched_packages", 0),
        mapping_stats.get("unmatched_modules", 0),
    )

    for db_mapping in package_module_mapping.get("by_database", []):
        logger.debug(
            "Per-database mapping stats database=%s package_to_modules=%s unmatched_packages=%s unmatched_modules=%s",
            db_mapping.get("name"),
            len(db_mapping.get("package_to_modules", [])),
            len(db_mapping.get("unmatched_packages", [])),
            len(db_mapping.get("unmatched_modules", [])),
        )

    if mapping_stats.get("matched_pairs", 0) == 0:
        logger.warning(
            "No package-module matches found odoo_packages=%s candidate_non_empty=%s databases=%s",
            len(odoo_packages),
            candidate_non_empty_count,
            len(databases_info),
        )

    mapping_summary = build_mapping_summary(package_module_mapping)
    package_module_relation_table = build_package_module_relation_table(package_module_mapping)
    uninstalled_module_matches = build_uninstalled_module_matches(
        odoo_packages=odoo_packages,
        databases_info=databases_info,
        package_module_candidates=package_module_candidates,
    )
    core_module_exclusions = list(get_effective_core_module_exclusions())

    uninstalled_stats = uninstalled_module_matches.get("stats", {})
    logger.info(
        "Uninstalled module matches built packages=%s module_matches=%s",
        uninstalled_stats.get("packages_with_uninstalled_modules", 0),
        uninstalled_stats.get("uninstalled_module_matches", 0),
    )

    logger.info(
        "Status payload built odoo_packages=%s databases=%s mapping_rows=%s",
        len(odoo_packages),
        len(databases_info),
        package_module_relation_table.get("count", 0),
    )

    return {
        "python_version": python_version,
        "odoo_version": odoo_version,
        "core_module_exclusions": core_module_exclusions,
        "odoo_packages": odoo_packages,
        "databases": databases_info,
        "package_module_mapping": package_module_mapping,
        "mapping_summary": mapping_summary,
        "package_module_relation_table": package_module_relation_table,
        "uninstalled_module_matches": uninstalled_module_matches,
    }

@app.get("/status")
def status(
    request: Request,
    format: Optional[str] = Query(None),
    only_drift: bool = Query(False),
    database: Optional[str] = Query(None),
    limit: Optional[int] = Query(None, ge=1),
    include_uninstalled_raw: bool = Query(False),
):
    """Serve instance status as JSON by default or HTML when requested.

    Args:
        request: FastAPI request object used for Accept header negotiation.
        format: Explicit output format override, e.g. "html".
        only_drift: Keep only rows with DB-to-package installed-version drift.
        database: Optional database name filter.
        limit: Optional max number of flattened relation rows.
        include_uninstalled_raw: Include raw databases[].uninstalled_non_core_modules in JSON.

    Returns:
        HTMLResponse when HTML is requested, otherwise the JSON status payload.
    """
    accept_header = request.headers.get("accept", "")
    wants_html = format == "html" or (format is None and "text/html" in accept_header)

    if wants_html:
        return HTMLResponse(content=render_html())

    logger.debug(
        "Handling /status request format=%s only_drift=%s database=%s limit=%s include_uninstalled_raw=%s",
        format,
        only_drift,
        database,
        limit,
        include_uninstalled_raw,
    )

    data = collect_status_data()
    data = apply_status_filters(
        data=data,
        only_drift=only_drift,
        database=database,
        limit=limit,
    )

    # Keep JSON aligned with HTML by default: expose uninstalled summary/matches,
    # but hide raw per-database uninstalled module inventories unless requested.
    if not include_uninstalled_raw:
        for db in data.get("databases", []):
            db.pop("uninstalled_non_core_modules", None)

    # Return JSON by default
    return data

if __name__ == "__main__":
    cli()
