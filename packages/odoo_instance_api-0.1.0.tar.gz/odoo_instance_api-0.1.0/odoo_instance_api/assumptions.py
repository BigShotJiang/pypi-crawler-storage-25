DEFAULT_ODOO_PYTHON_PATH = "/home/odoo/pyenv/versions/odoo-16/bin/python"
DEFAULT_ODOO_CONF_PATH = "/etc/odoo/odoo.conf"
DEFAULT_ODOO_SOURCE_CODE_PATH = ""
PYPI_PACKAGE_JSON_URL_TEMPLATE = "https://pypi.org/pypi/{package_name}/json"
PYPI_HTTP_TIMEOUT_SECONDS = 5

IR_MODULE_TABLE = "ir_module_module"
IR_MODULE_VERSION_COLUMNS = ("installed_version", "latest_version")

ODOO_CORE_AUTHORS = (
    "Odoo S.A.",
    "Odoo SA",
    "OpenERP SA",
)

ODOO_CORE_MODULES = (
    "l10n_es",
)

ODOO_PACKAGE_NAME_PREFIXES = ("odoo",)
ADDON_MANIFEST_FILENAMES = ("__manifest__.py", "__openerp__.py")
