import os
import logging
import configparser
import re
import subprocess
from pathlib import Path

from .assumptions import (
    ADDON_MANIFEST_FILENAMES,
    DEFAULT_ODOO_CONF_PATH,
    DEFAULT_ODOO_PYTHON_PATH,
    DEFAULT_ODOO_SOURCE_CODE_PATH,
    IR_MODULE_TABLE,
    IR_MODULE_VERSION_COLUMNS,
    ODOO_CORE_AUTHORS,
    ODOO_CORE_MODULES,
    ODOO_PACKAGE_NAME_PREFIXES,
    PYPI_HTTP_TIMEOUT_SECONDS,
    PYPI_PACKAGE_JSON_URL_TEMPLATE,
)


logger = logging.getLogger(__name__)

def _discover_odoo_conf_path() -> str:
    """Try to infer Odoo config path from common system locations.

    Returns:
        Existing config path when found, otherwise default config path.
    """
    candidates = [DEFAULT_ODOO_CONF_PATH]

    etc_dir = Path("/etc")
    if etc_dir.is_dir():
        for pattern in ("odoo_*/odoo.conf", "odoo*/odoo.conf"):
            for match in sorted(etc_dir.glob(pattern)):
                candidates.append(str(match))

    for candidate in dict.fromkeys(candidates):
        if Path(candidate).is_file():
            return candidate

    return DEFAULT_ODOO_CONF_PATH


def _path_contains_addons(source_path: str) -> bool:
    """Check whether a candidate source path contains an addons directory.

    Args:
        source_path: Candidate Odoo source root path.

    Returns:
        True when source_path/addons exists as a directory.
    """
    return bool(source_path) and (Path(source_path) / "addons").is_dir()


def _discover_odoo_source_code_path() -> str:
    """Try to infer Odoo source path from the configured Odoo interpreter.

    Returns:
        Discovered source root path, or empty string when unavailable.
    """
    try:
        result = subprocess.run(
            [
                get_odoo_python_path(),
                "-c",
                (
                    "from pathlib import Path; import odoo; "
                    "p=Path(odoo.__file__).resolve(); "
                    "candidates=[p.parent, p.parent.parent, p.parent.parent.parent]; "
                    "print('\\n'.join(str(path) for path in candidates))"
                ),
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return ""

        candidates = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        for candidate in candidates:
            if _path_contains_addons(candidate):
                return candidate
            nested_odoo_candidate = str(Path(candidate) / "odoo")
            if _path_contains_addons(nested_odoo_candidate):
                return nested_odoo_candidate
    except Exception:
        return ""

    return ""


def _env_csv_tuple(variable_name: str, default: tuple[str, ...]) -> tuple[str, ...]:
    """Read a comma-separated environment variable as a normalized tuple.

    Args:
        variable_name: Environment variable name.
        default: Fallback tuple when the variable is unset or empty.

    Returns:
        Parsed tuple of trimmed values.
    """
    raw_value = os.environ.get(variable_name, "")
    if not raw_value.strip():
        return default
    parsed_values = tuple(value.strip() for value in raw_value.split(",") if value.strip())
    return parsed_values or default


def _env_int(variable_name: str, default: int) -> int:
    """Read an integer environment variable with graceful fallback.

    Args:
        variable_name: Environment variable name.
        default: Fallback value when parsing fails.

    Returns:
        Parsed integer value or the provided default.
    """
    raw_value = os.environ.get(variable_name)
    if raw_value is None:
        return default
    try:
        return int(raw_value)
    except ValueError:
        return default


def get_odoo_python_path() -> str:
    """Return the Python executable path used to inspect Odoo packages.

    Returns:
        Absolute path to the Odoo runtime Python interpreter.
    """
    return os.environ.get(
        "ODOO_VENV_PATH",
        os.environ.get("OIA_DEFAULT_ODOO_PYTHON_PATH", DEFAULT_ODOO_PYTHON_PATH),
    )


def get_odoo_conf_path() -> str:
    """Return the Odoo configuration file path.

    Returns:
        Path to the Odoo config used for PostgreSQL connection discovery.
    """
    explicit = os.environ.get("ODOO_CONF_PATH")
    if explicit and explicit.strip():
        return explicit

    default = os.environ.get("OIA_DEFAULT_ODOO_CONF_PATH", "").strip()
    if default:
        logger.debug("Using Odoo config path from OIA_DEFAULT_ODOO_CONF_PATH: %s", default)
        return default

    discovered = _discover_odoo_conf_path()
    logger.debug("Using auto-discovered Odoo config path: %s", discovered)
    return discovered


def get_odoo_config_options() -> dict[str, str]:
    """Read Odoo config `options` section as a normalized dictionary.

    Returns:
        Dictionary of lowercased option names to stripped string values.
    """
    conf_path = get_odoo_conf_path()
    if not os.path.exists(conf_path):
        logger.debug("Odoo config path does not exist: %s", conf_path)
        return {}

    try:
        parser = configparser.RawConfigParser()
        parser.read(conf_path)
        if "options" not in parser:
            return {}

        return {
            key: (value or "").strip()
            for key, value in parser["options"].items()
        }
    except Exception:
        logger.exception("Failed to parse Odoo config options", extra={"conf_path": conf_path})
        return {}


def get_odoo_source_code_path() -> str:
    """Return the Odoo source root path used for core addons discovery.

    Returns:
        Path to the Odoo source repository root.
    """
    explicit = os.environ.get("ODOO_SOURCE_CODE_PATH")
    if explicit and explicit.strip():
        return explicit

    default = os.environ.get("OIA_DEFAULT_ODOO_SOURCE_CODE_PATH", DEFAULT_ODOO_SOURCE_CODE_PATH)
    if default and default.strip():
        return default

    return _discover_odoo_source_code_path()


def get_odoo_source_code_paths() -> tuple[str, ...]:
    """Return normalized Odoo source-root candidates.

    The value can be a single path or a list of paths separated by commas,
    semicolons, or os.pathsep.

    Returns:
        Tuple of distinct, non-empty path strings.
    """
    split_pattern = rf"[{re.escape(os.pathsep)},;]"
    raw_source_value = (get_odoo_source_code_path() or "").strip()
    source_parts = [part.strip() for part in re.split(split_pattern, raw_source_value) if part.strip()]
    merged = tuple(dict.fromkeys(source_parts))
    logger.debug("Resolved Odoo source-root candidates: %s", merged)
    return merged


def get_odoo_addons_paths() -> tuple[str, ...]:
    """Return normalized addons_path entries parsed from odoo.conf.

    Returns:
        Tuple of distinct, non-empty path strings.
    """
    split_pattern = rf"[{re.escape(os.pathsep)},;]"
    addons_raw = get_odoo_config_options().get("addons_path", "")
    parts = [part.strip() for part in re.split(split_pattern, addons_raw) if part.strip()]
    merged = tuple(dict.fromkeys(parts))
    logger.debug("Resolved Odoo addons_path entries: %s", merged)
    return merged


def get_pypi_package_json_url_template() -> str:
    """Return the PyPI JSON endpoint template.

    Returns:
        URL template used to fetch package metadata from PyPI.
    """
    return os.environ.get("OIA_PYPI_PACKAGE_JSON_URL_TEMPLATE", PYPI_PACKAGE_JSON_URL_TEMPLATE)


def get_pypi_http_timeout_seconds() -> int:
    """Return the HTTP timeout used for PyPI requests.

    Returns:
        Timeout in seconds.
    """
    return _env_int("OIA_PYPI_HTTP_TIMEOUT_SECONDS", PYPI_HTTP_TIMEOUT_SECONDS)


def get_ir_module_table() -> str:
    """Return the ir_module table name used for module lookups.

    Returns:
        Database table name.
    """
    return os.environ.get("OIA_IR_MODULE_TABLE", IR_MODULE_TABLE)


def get_ir_module_version_columns() -> tuple[str, ...]:
    """Return preferred version columns for ir_module table schemas.

    Returns:
        Ordered tuple of version column candidates.
    """
    return _env_csv_tuple("OIA_IR_MODULE_VERSION_COLUMNS", IR_MODULE_VERSION_COLUMNS)


def get_odoo_core_authors() -> tuple[str, ...]:
    """Return author names treated as Odoo core modules.

    Returns:
        Tuple of author strings excluded from non-core results.
    """
    return _env_csv_tuple("OIA_ODOO_CORE_AUTHORS", ODOO_CORE_AUTHORS)


def get_odoo_core_modules() -> tuple[str, ...]:
    """Return module names explicitly treated as core.

    Returns:
        Tuple of module names excluded from unmatched accounting.
    """
    return _env_csv_tuple("OIA_ODOO_CORE_MODULES", ODOO_CORE_MODULES)


def get_odoo_package_name_prefixes() -> tuple[str, ...]:
    """Return valid package-name prefixes that identify Odoo packages.

    Returns:
        Lowercased tuple of accepted package prefixes.
    """
    return tuple(
        value.lower()
        for value in _env_csv_tuple("OIA_ODOO_PACKAGE_NAME_PREFIXES", ODOO_PACKAGE_NAME_PREFIXES)
    )


def get_addon_manifest_filenames() -> tuple[str, ...]:
    """Return addon manifest filenames used for module discovery.

    Returns:
        Lowercased tuple of supported manifest filenames.
    """
    return tuple(
        value.lower()
        for value in _env_csv_tuple("OIA_ADDON_MANIFEST_FILENAMES", ADDON_MANIFEST_FILENAMES)
    )


def get_postgres_host() -> str | None:
    """Return PostgreSQL host override from environment.

    Returns:
        Host value or None when not set.
    """
    return os.environ.get("PGHOST")


def get_postgres_port() -> str | None:
    """Return PostgreSQL port override from environment.

    Returns:
        Port value or None when not set.
    """
    return os.environ.get("PGPORT")


def get_postgres_user() -> str | None:
    """Return PostgreSQL user override from environment.

    Returns:
        User value or None when not set.
    """
    return os.environ.get("PGUSER")


def get_postgres_password() -> str | None:
    """Return PostgreSQL password override from environment.

    Returns:
        Password value or None when not set.
    """
    return os.environ.get("PGPASSWORD")
