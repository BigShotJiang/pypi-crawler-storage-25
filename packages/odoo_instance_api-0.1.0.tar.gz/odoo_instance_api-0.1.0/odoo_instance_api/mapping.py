from typing import Optional

from .packages import _version_diff


def build_package_module_mapping(odoo_packages: list, databases_info: list, package_module_candidates: dict) -> dict:
    """Build package-to-module matches using manifest-derived candidates.

    Args:
        odoo_packages: Installed Odoo-related Python packages with version metadata.
        databases_info: Per-database module inventories from PostgreSQL.
        package_module_candidates: Mapping of package name to candidate module names.

    Returns:
        Mapping payload grouped by database with match details and aggregate stats.
    """
    by_database = []
    total_matched_pairs = 0
    total_unmatched_packages = 0
    total_unmatched_modules = 0

    for db in databases_info:
        db_name = db.get("name")
        modules = db.get("non_core_modules", [])
        uninstalled_modules = db.get("uninstalled_non_core_modules", [])
        db_module_by_name = {mod.get("name"): mod for mod in modules if mod.get("name")}
        db_uninstalled_module_names = {
            mod.get("name")
            for mod in uninstalled_modules
            if mod.get("name")
        }

        package_to_modules = []
        matched_module_names = set()
        packages_with_uninstalled_matches = set()

        for pkg in odoo_packages:
            pkg_name = pkg.get("name")
            pkg_installed_version = pkg.get("installed_version")
            pkg_pypi_version = pkg.get("available_version")

            candidate_modules = package_module_candidates.get(pkg_name, [])
            if any(module_name in db_uninstalled_module_names for module_name in candidate_modules):
                packages_with_uninstalled_matches.add(pkg_name)
            matched_modules = []

            for module_name in candidate_modules:
                db_module = db_module_by_name.get(module_name)
                if not db_module:
                    continue

                db_module_version = db_module.get("version")
                matched_modules.append(
                    {
                        "module_name": module_name,
                        "db_module_version": db_module_version,
                        "confidence": "high",
                        "reason": "manifest_path_match",
                        "version_drift": {
                            "db_vs_package_installed": _version_diff(db_module_version, pkg_installed_version),
                            "db_vs_pypi_latest": _version_diff(db_module_version, pkg_pypi_version),
                            "package_installed_vs_pypi_latest": _version_diff(
                                pkg_installed_version, pkg_pypi_version
                            ),
                        },
                    }
                )
                matched_module_names.add(module_name)
                total_matched_pairs += 1

            package_to_modules.append(
                {
                    "package_name": pkg_name,
                    "package_installed_version": pkg_installed_version,
                    "package_pypi_latest_version": pkg_pypi_version,
                    "candidate_modules": candidate_modules,
                    "matched_modules": matched_modules,
                }
            )

        unmatched_packages = [
            {
                "package_name": item["package_name"],
                "candidate_modules": item["candidate_modules"],
                "reason": "no_manifest_match_in_database",
            }
            for item in package_to_modules
            if not item["matched_modules"]
            and item["package_name"] not in packages_with_uninstalled_matches
        ]
        unmatched_modules = [mod for mod in modules if mod.get("name") not in matched_module_names]

        total_unmatched_packages += len(unmatched_packages)
        total_unmatched_modules += len(unmatched_modules)

        by_database.append(
            {
                "name": db_name,
                "package_to_modules": package_to_modules,
                "unmatched_packages": unmatched_packages,
                "unmatched_modules": unmatched_modules,
            }
        )

    return {
        "method": "manifest_path_match",
        "by_database": by_database,
        "stats": {
            "databases": len(by_database),
            "matched_pairs": total_matched_pairs,
            "unmatched_packages": total_unmatched_packages,
            "unmatched_modules": total_unmatched_modules,
        },
    }


def build_mapping_summary(package_module_mapping: dict) -> dict:
    """Create per-database and global counters from mapping diagnostics.

    Args:
        package_module_mapping: Mapping payload from build_package_module_mapping.

    Returns:
        Summary payload with per-database rows and total counters.
    """
    by_database = package_module_mapping.get("by_database", [])

    summary_by_database = []
    unmatched_package_names_total = set()
    unmatched_module_names_total = set()
    totals = {
        "databases": len(by_database),
        "matched_pairs": 0,
        "unmatched_packages": 0,
        "unmatched_modules": 0,
        "drift_db_vs_package_installed": 0,
        "drift_db_vs_pypi_latest": 0,
        "drift_package_installed_vs_pypi_latest": 0,
    }

    for db in by_database:
        matched_pairs = 0
        drift_db_vs_package_installed = 0
        drift_db_vs_pypi_latest = 0
        drift_package_installed_vs_pypi_latest = 0

        for pkg in db.get("package_to_modules", []):
            for matched in pkg.get("matched_modules", []):
                matched_pairs += 1
                drift = matched.get("version_drift", {})
                if drift.get("db_vs_package_installed"):
                    drift_db_vs_package_installed += 1
                if drift.get("db_vs_pypi_latest"):
                    drift_db_vs_pypi_latest += 1
                if drift.get("package_installed_vs_pypi_latest"):
                    drift_package_installed_vs_pypi_latest += 1

        unmatched_packages = len(db.get("unmatched_packages", []))
        unmatched_modules = len(db.get("unmatched_modules", []))

        unmatched_package_names = sorted(
            {
                item.get("package_name")
                for item in db.get("unmatched_packages", [])
                if item.get("package_name")
            }
        )
        unmatched_module_names = sorted(
            {item.get("name") for item in db.get("unmatched_modules", []) if item.get("name")}
        )

        unmatched_package_names_total.update(unmatched_package_names)
        unmatched_module_names_total.update(unmatched_module_names)

        summary_row = {
            "database": db.get("name"),
            "matched_pairs": matched_pairs,
            "unmatched_packages": unmatched_packages,
            "unmatched_modules": unmatched_modules,
            "unmatched_package_names": unmatched_package_names,
            "unmatched_module_names": unmatched_module_names,
            "drift_db_vs_package_installed": drift_db_vs_package_installed,
            "drift_db_vs_pypi_latest": drift_db_vs_pypi_latest,
            "drift_package_installed_vs_pypi_latest": drift_package_installed_vs_pypi_latest,
        }
        summary_by_database.append(summary_row)

        totals["matched_pairs"] += matched_pairs
        totals["unmatched_packages"] += unmatched_packages
        totals["unmatched_modules"] += unmatched_modules
        totals["drift_db_vs_package_installed"] += drift_db_vs_package_installed
        totals["drift_db_vs_pypi_latest"] += drift_db_vs_pypi_latest
        totals["drift_package_installed_vs_pypi_latest"] += drift_package_installed_vs_pypi_latest

    totals_with_names = {
        **totals,
        "unmatched_package_names": sorted(unmatched_package_names_total),
        "unmatched_module_names": sorted(unmatched_module_names_total),
    }

    return {
        "method": package_module_mapping.get("method"),
        "by_database": summary_by_database,
        "totals": totals_with_names,
    }


def build_package_module_relation_table(package_module_mapping: dict) -> dict:
    """Flatten mapping diagnostics into a single relation table.

    Args:
        package_module_mapping: Mapping payload from build_package_module_mapping.

    Returns:
        Dictionary with deduplicated relation rows and row count.
    """
    rows = []
    seen = set()

    for db in package_module_mapping.get("by_database", []):
        db_name = db.get("name")
        for pkg in db.get("package_to_modules", []):
            package_name = pkg.get("package_name")
            package_installed_version = pkg.get("package_installed_version")
            package_pypi_latest_version = pkg.get("package_pypi_latest_version")

            for matched in pkg.get("matched_modules", []):
                module_name = matched.get("module_name")
                unique_key = (db_name, package_name, module_name)
                if unique_key in seen:
                    continue
                seen.add(unique_key)

                rows.append(
                    {
                        "database": db_name,
                        "pypi_package": package_name,
                        "db_module": module_name,
                        "db_module_version": matched.get("db_module_version"),
                        "package_installed_version": package_installed_version,
                        "package_pypi_latest_version": package_pypi_latest_version,
                        "drift_db_vs_package_installed": matched.get("version_drift", {}).get(
                            "db_vs_package_installed", False
                        ),
                        "drift_db_vs_pypi_latest": matched.get("version_drift", {}).get(
                            "db_vs_pypi_latest", False
                        ),
                        "drift_package_installed_vs_pypi_latest": matched.get("version_drift", {}).get(
                            "package_installed_vs_pypi_latest", False
                        ),
                        "confidence": matched.get("confidence"),
                        "reason": matched.get("reason"),
                    }
                )

    rows.sort(
        key=lambda item: (
            item.get("database") or "",
            item.get("pypi_package") or "",
            item.get("db_module") or "",
        )
    )

    return {
        "rows": rows,
        "count": len(rows),
    }


def build_uninstalled_module_matches(
    odoo_packages: list,
    databases_info: list,
    package_module_candidates: dict,
) -> dict:
    """Build package-to-module matches for modules currently uninstalled in DB.

    Args:
        odoo_packages: Installed Odoo-related Python packages with version metadata.
        databases_info: Per-database module inventories from PostgreSQL.
        package_module_candidates: Mapping of package name to candidate module names.

    Returns:
        Per-database matches and aggregate counters for uninstalled modules.
    """
    by_database = []
    total_packages = 0
    total_module_matches = 0

    for db in databases_info:
        db_name = db.get("name")
        uninstalled_modules = db.get("uninstalled_non_core_modules", [])
        db_uninstalled_by_name = {
            mod.get("name"): mod
            for mod in uninstalled_modules
            if mod.get("name")
        }

        matched_packages = []

        for pkg in odoo_packages:
            pkg_name = pkg.get("name")
            candidate_modules = package_module_candidates.get(pkg_name, [])

            matched_uninstalled_modules = []
            for module_name in candidate_modules:
                db_module = db_uninstalled_by_name.get(module_name)
                if not db_module:
                    continue

                matched_uninstalled_modules.append(
                    {
                        "module_name": module_name,
                        "db_module_version": db_module.get("version"),
                        "state": db_module.get("state", "uninstalled"),
                        "reason": "manifest_path_match_uninstalled",
                    }
                )

            if not matched_uninstalled_modules:
                continue

            total_packages += 1
            total_module_matches += len(matched_uninstalled_modules)
            matched_packages.append(
                {
                    "package_name": pkg_name,
                    "package_installed_version": pkg.get("installed_version"),
                    "package_pypi_latest_version": pkg.get("available_version"),
                    "candidate_modules": candidate_modules,
                    "matched_uninstalled_modules": matched_uninstalled_modules,
                }
            )

        by_database.append(
            {
                "name": db_name,
                "packages": matched_packages,
                "counts": {
                    "packages": len(matched_packages),
                    "module_matches": sum(
                        len(item.get("matched_uninstalled_modules", []))
                        for item in matched_packages
                    ),
                },
            }
        )

    return {
        "method": "manifest_path_match",
        "by_database": by_database,
        "stats": {
            "databases": len(by_database),
            "packages_with_uninstalled_modules": total_packages,
            "uninstalled_module_matches": total_module_matches,
        },
    }


def apply_status_filters(
    data: dict,
    only_drift: bool = False,
    database: Optional[str] = None,
    limit: Optional[int] = None,
) -> dict:
    """Apply API query filters to a collected status payload.

    Args:
        data: Unfiltered status payload.
        only_drift: Keep only relation rows with DB-versus-installed drift.
        database: Optional database name filter.
        limit: Optional max number of relation rows.

    Returns:
        Filtered status payload with recomputed derived sections.
    """
    filtered = dict(data)

    target_database = database.strip().lower() if database else None

    if target_database:
        filtered["databases"] = [
            db
            for db in filtered.get("databases", [])
            if str(db.get("name", "")).lower() == target_database
        ]

        mapping = dict(filtered.get("package_module_mapping", {}))
        mapping_by_database = [
            db
            for db in mapping.get("by_database", [])
            if str(db.get("name", "")).lower() == target_database
        ]
        mapping["by_database"] = mapping_by_database
        filtered["package_module_mapping"] = mapping

        uninstalled_matches = dict(filtered.get("uninstalled_module_matches", {}))
        uninstalled_by_database = [
            db
            for db in uninstalled_matches.get("by_database", [])
            if str(db.get("name", "")).lower() == target_database
        ]
        uninstalled_matches["by_database"] = uninstalled_by_database
        uninstalled_matches["stats"] = {
            "databases": len(uninstalled_by_database),
            "packages_with_uninstalled_modules": sum(
                len(db.get("packages", [])) for db in uninstalled_by_database
            ),
            "uninstalled_module_matches": sum(
                sum(
                    len(pkg.get("matched_uninstalled_modules", []))
                    for pkg in db.get("packages", [])
                )
                for db in uninstalled_by_database
            ),
        }
        filtered["uninstalled_module_matches"] = uninstalled_matches

    mapping_for_derived = filtered.get("package_module_mapping", {})
    relation_table = build_package_module_relation_table(mapping_for_derived)

    if only_drift:
        relation_table["rows"] = [
            row for row in relation_table.get("rows", []) if row.get("drift_db_vs_package_installed")
        ]
        relation_table["count"] = len(relation_table["rows"])

    if limit is not None and limit > 0:
        relation_table["rows"] = relation_table.get("rows", [])[:limit]
        relation_table["count"] = len(relation_table["rows"])

    filtered["package_module_relation_table"] = relation_table

    summary = build_mapping_summary(mapping_for_derived)
    if only_drift:
        summary_rows = [
            row
            for row in summary.get("by_database", [])
            if row.get("drift_db_vs_package_installed", 0) > 0
        ]
        summary["by_database"] = summary_rows

        unmatched_package_names = sorted(
            {
                name
                for row in summary_rows
                for name in row.get("unmatched_package_names", [])
                if name
            }
        )
        unmatched_module_names = sorted(
            {
                name
                for row in summary_rows
                for name in row.get("unmatched_module_names", [])
                if name
            }
        )

        totals = {
            "databases": len(summary_rows),
            "matched_pairs": sum(row.get("matched_pairs", 0) for row in summary_rows),
            "unmatched_packages": sum(row.get("unmatched_packages", 0) for row in summary_rows),
            "unmatched_modules": sum(row.get("unmatched_modules", 0) for row in summary_rows),
            "unmatched_package_names": unmatched_package_names,
            "unmatched_module_names": unmatched_module_names,
            "drift_db_vs_package_installed": sum(
                row.get("drift_db_vs_package_installed", 0) for row in summary_rows
            ),
            "drift_db_vs_pypi_latest": sum(row.get("drift_db_vs_pypi_latest", 0) for row in summary_rows),
            "drift_package_installed_vs_pypi_latest": sum(
                row.get("drift_package_installed_vs_pypi_latest", 0) for row in summary_rows
            ),
        }
        summary["totals"] = totals

    filtered["mapping_summary"] = summary

    mapping_stats = {
        "databases": len(mapping_for_derived.get("by_database", [])),
        "matched_pairs": sum(
            len(pkg.get("matched_modules", []))
            for db in mapping_for_derived.get("by_database", [])
            for pkg in db.get("package_to_modules", [])
        ),
        "unmatched_packages": sum(
            len(db.get("unmatched_packages", [])) for db in mapping_for_derived.get("by_database", [])
        ),
        "unmatched_modules": sum(
            len(db.get("unmatched_modules", [])) for db in mapping_for_derived.get("by_database", [])
        ),
    }
    filtered["package_module_mapping"] = {
        **mapping_for_derived,
        "stats": mapping_stats,
    }

    return filtered
