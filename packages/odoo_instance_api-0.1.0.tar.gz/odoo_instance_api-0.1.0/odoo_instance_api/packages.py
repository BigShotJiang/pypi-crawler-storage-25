import json
import logging
import os
import subprocess
import sys
from typing import Optional

import requests
from packaging import version

from .settings import (
    get_odoo_package_name_prefixes,
    get_odoo_python_path,
    get_pypi_http_timeout_seconds,
    get_pypi_package_json_url_template,
)
from .scripts.inspect_odoo_distributions import get_odoo_package_module_candidates


logger = logging.getLogger(__name__)


def get_venv_python_path() -> str:
    """Return the configured Python interpreter path used for Odoo inspection.

    Returns:
        Absolute path to the target Python executable.
    """
    return get_odoo_python_path()


def get_python_version() -> str:
    """Get interpreter version from the configured Odoo Python executable.

    Returns:
        Version string from the interpreter, or an error message.
    """
    try:
        result = subprocess.run([get_venv_python_path(), "--version"], capture_output=True, text=True)
        return (result.stdout or result.stderr).strip()
    except Exception as error:
        logger.exception("Error connecting to Python env")
        return f"Error connecting to Python env: {error}"


def get_pip_packages() -> dict:
    """List installed packages from the configured Odoo environment.

    Returns:
        Dictionary keyed by normalized package name with installed version values.
    """
    try:
        logger.debug("Listing pip packages python_path=%s", get_venv_python_path())
        result = subprocess.run(
            [get_venv_python_path(), "-m", "pip", "list", "--format=json"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            logger.warning("pip list failed stderr=%s", result.stderr.strip())
            return {}
        packages = json.loads(result.stdout)
        logger.debug("pip packages loaded count=%s", len(packages))
        return {pkg["name"].lower(): {"version": pkg["version"]} for pkg in packages}
    except Exception as error:
        logger.exception("Error listing pip packages")
        return {}


def get_package_module_candidates() -> dict:
    """Infer candidate Odoo module names from installed distribution metadata.

    Returns:
        Mapping of package name to candidate module names derived from manifests.
    """
    project_root = os.path.dirname(os.path.dirname(__file__))
    odoo_python_path = os.path.abspath(get_venv_python_path())
    current_python_path = os.path.abspath(sys.executable)
    logger.info(
        "Inspecting package module candidates odoo_python_path=%s current_python_path=%s",
        odoo_python_path,
        current_python_path,
    )

    if odoo_python_path == current_python_path:
        try:
            candidates = get_odoo_package_module_candidates()
            logger.info("Candidates inspected in current interpreter count=%s", len(candidates))
            return candidates
        except Exception as error:
            logger.exception("Error inspecting distribution files in current environment")
            return {}

    logger.debug("Using configured Odoo interpreter subprocess for candidate inspection")

    try:
        result = subprocess.run(
            [odoo_python_path, "-m", "odoo_instance_api.scripts.inspect_odoo_distributions"],
            capture_output=True,
            text=True,
            cwd=project_root,
        )
        if result.returncode != 0:
            logger.warning(
                "Error inspecting distribution files in pyenv environment stderr=%s",
                result.stderr.strip(),
            )
            return {}
        if not result.stdout.strip():
            logger.warning("Distribution inspection returned empty stdout")
            return {}
        candidates = json.loads(result.stdout)
        logger.info("Candidates inspected in pyenv interpreter count=%s", len(candidates))
        return candidates
    except Exception as error:
        logger.exception("Error getting package module candidates")
        return {}


def _version_components(raw_version: str) -> list:
    """Split a version string into normalized comparable components.

    Args:
        raw_version: Raw version text.

    Returns:
        Lowercased version components.
    """
    normalized = raw_version.replace("+", ".").replace("-", ".").replace("_", ".")
    return [part.strip().lower() for part in normalized.split(".") if part.strip()]


def _versions_compatible(left: Optional[str], right: Optional[str]) -> bool:
    """Check whether two versions are compatible by prefix comparison.

    Args:
        left: First version.
        right: Second version.

    Returns:
        True when versions share the same comparable prefix.
    """
    if not left or not right:
        return True

    left_parts = _version_components(left)
    right_parts = _version_components(right)

    if not left_parts or not right_parts:
        return True

    compare_length = min(len(left_parts), len(right_parts))
    return left_parts[:compare_length] == right_parts[:compare_length]


def _version_diff(left: Optional[str], right: Optional[str]) -> bool:
    """Return whether two versions should be considered mismatched.

    Args:
        left: First version.
        right: Second version.

    Returns:
        True when both versions are present and incompatible.
    """
    if not left or not right:
        return False
    return not _versions_compatible(left, right)


def get_odoo_series(odoo_version: Optional[str]) -> Optional[str]:
    """Extract Odoo major/minor series from a full version string.

    Args:
        odoo_version: Full Odoo version string.

    Returns:
        Series string like 16.0, a major-only fallback, or None.
    """
    if not odoo_version:
        return None

    parts = _version_components(odoo_version)
    if len(parts) >= 2:
        return f"{parts[0]}.{parts[1]}"
    if len(parts) == 1:
        return parts[0]
    return None


def _version_matches_series(candidate_version: str, series: Optional[str]) -> bool:
    """Check whether a release version belongs to a target Odoo series.

    Args:
        candidate_version: Candidate release version from PyPI.
        series: Target Odoo series such as 16.0.

    Returns:
        True when the candidate matches the requested series prefix.
    """
    if not series:
        return True

    candidate_parts = _version_components(candidate_version)
    series_parts = _version_components(series)
    if not candidate_parts or not series_parts:
        return False
    if len(candidate_parts) < len(series_parts):
        return False
    return candidate_parts[: len(series_parts)] == series_parts


def get_pypi_latest_version(package_name: str, odoo_series: Optional[str] = None) -> Optional[str]:
    """Fetch the latest parseable package version from PyPI.

    Args:
        package_name: Package name to query.
        odoo_series: Optional series filter applied to candidate releases.

    Returns:
        Latest matching version string, or None when unavailable.
    """
    try:
        url = get_pypi_package_json_url_template().format(package_name=package_name)
        response = requests.get(url, timeout=get_pypi_http_timeout_seconds())
        if response.status_code == 200:
            data = response.json()
            releases = data.get("releases", {})
            if releases:
                candidate_versions = [
                    rel for rel in releases.keys() if _version_matches_series(rel, odoo_series)
                ]

                if not candidate_versions:
                    return None

                parseable_versions = []
                for rel in candidate_versions:
                    try:
                        version.parse(rel)
                        parseable_versions.append(rel)
                    except Exception:
                        continue

                if not parseable_versions:
                    return None

                latest_ver = max(parseable_versions, key=version.parse)
                return latest_ver
        logger.warning(
            "PyPI request failed package=%s status_code=%s",
            package_name,
            response.status_code,
        )
    except Exception as error:
        logger.exception("Error fetching package from PyPI", extra={"package_name": package_name})
    return None


def is_odoo_package_name(name: str) -> bool:
    """Check whether a package name matches configured Odoo prefixes.

    Args:
        name: Candidate package name.

    Returns:
        True when the package belongs to configured Odoo namespaces.
    """
    normalized_name = (name or "").strip().lower()
    return normalized_name.startswith(get_odoo_package_name_prefixes())
