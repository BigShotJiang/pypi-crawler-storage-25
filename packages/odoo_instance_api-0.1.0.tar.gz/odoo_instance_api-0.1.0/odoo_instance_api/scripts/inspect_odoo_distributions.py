import json
import importlib.metadata as md

from ..settings import get_addon_manifest_filenames, get_odoo_package_name_prefixes


def get_odoo_package_module_candidates() -> dict:
    result = {}
    package_prefixes = get_odoo_package_name_prefixes()
    addon_manifest_filenames = get_addon_manifest_filenames()

    for dist in md.distributions():
        try:
            name = (dist.metadata["Name"] or "").strip()
        except KeyError:
            name = ""
        if not name:
            continue

        normalized_name = name.lower()
        if not normalized_name.startswith(package_prefixes):
            continue

        modules = set()
        for file_entry in (dist.files or []):
            path = str(file_entry).replace("\\", "/")
            lower_path = path.lower()
            if any(lower_path.endswith(f"/{manifest_name}") for manifest_name in addon_manifest_filenames):
                parts = path.split("/")
                if len(parts) >= 2:
                    module_name = parts[-2]
                    if module_name:
                        modules.add(module_name)

        result[normalized_name] = sorted(modules)

    return result


def main() -> None:
    print(json.dumps(get_odoo_package_module_candidates()))


if __name__ == "__main__":
    main()
