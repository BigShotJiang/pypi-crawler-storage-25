import functools
import logging
import os
from pathlib import Path

import psycopg2

from .settings import (
    get_addon_manifest_filenames,
    get_ir_module_table,
    get_ir_module_version_columns,
    get_odoo_addons_paths,
    get_odoo_config_options,
    get_odoo_core_authors,
    get_odoo_core_modules,
    get_odoo_source_code_paths,
    get_postgres_host,
    get_postgres_password,
    get_postgres_port,
    get_postgres_user,
)


logger = logging.getLogger(__name__)


def _is_addons_directory(path: Path, manifest_filenames: set[str]) -> bool:
    """Check whether a path behaves like an Odoo addons directory.

    Args:
        path: Candidate addons directory.
        manifest_filenames: Supported manifest filenames.

    Returns:
        True when at least one child module has a manifest file.
    """
    if not path.is_dir():
        return False

    for child in path.iterdir():
        if not child.is_dir():
            continue
        if any((child / manifest_name).is_file() for manifest_name in manifest_filenames):
            return True
    return False


def _looks_like_odoo_source_root(path: Path) -> bool:
    """Check whether a directory looks like an Odoo source root.

    Args:
        path: Candidate source root directory.

    Returns:
        True when common Odoo source markers are present.
    """
    if not path.is_dir():
        return False

    return (
        (path / "odoo-bin").is_file()
        or (path / "odoo" / "release.py").is_file()
        or (path / "odoo" / "__init__.py").is_file()
    )


def _is_core_addons_dir(path: Path, manifest_filenames: set[str]) -> bool:
    """Determine whether an addons directory should be treated as core.

    Args:
        path: Candidate addons directory.
        manifest_filenames: Supported manifest filenames.

    Returns:
        True when directory looks like addons and its hierarchy looks like Odoo source.
    """
    if not _is_addons_directory(path, manifest_filenames):
        return False

    if path.name == "addons":
        source_roots = [path.parent, path.parent.parent]
    else:
        source_roots = [path]

    return any(_looks_like_odoo_source_root(root) for root in source_roots)


def _expand_addons_candidates(root: Path) -> list[Path]:
    """Expand a root/addons entry into common addons layouts.

    Args:
        root: Source root or addons path entry.

    Returns:
        Ordered list of candidate addons directories.
    """
    candidates = [root]
    if root.name == "addons":
        candidates.append(root.parent / "odoo" / "addons")
    else:
        candidates.append(root / "addons")
        candidates.append(root / "odoo" / "addons")
    return candidates


@functools.lru_cache(maxsize=1)
def _get_source_core_module_names() -> tuple[str, ...]:
    """Discover addon module names from Odoo source addons directory.

    Returns:
        Sorted tuple of module names found under ODOO_SOURCE_CODE_PATH/addons.
    """
    source_roots = get_odoo_source_code_paths()
    addons_entries = get_odoo_addons_paths()
    if not source_roots and not addons_entries:
        return tuple()

    manifest_filenames = set(get_addon_manifest_filenames())
    addons_paths: list[Path] = []
    all_candidates: list[Path] = []
    for source_root in source_roots:
        addons_candidates = _expand_addons_candidates(Path(source_root))
        all_candidates.extend(addons_candidates)
        addons_paths.extend(
            path
            for path in addons_candidates
            if _is_core_addons_dir(path, manifest_filenames)
        )

    for addons_entry in addons_entries:
        addons_candidates = _expand_addons_candidates(Path(addons_entry))
        all_candidates.extend(addons_candidates)
        addons_paths.extend(
            path
            for path in addons_candidates
            if _is_core_addons_dir(path, manifest_filenames)
        )

    addons_paths = list(dict.fromkeys(addons_paths))
    if not addons_paths:
        logger.warning(
            "Configured Odoo source addons path does not exist or is not a directory",
            extra={"source_roots": source_roots},
        )
        return tuple()

    module_names = set()
    for addons_path in addons_paths:
        for child in addons_path.iterdir():
            if not child.is_dir():
                continue
            for manifest_name in manifest_filenames:
                if (child / manifest_name).is_file():
                    module_names.add(child.name)
                    break

    logger.debug(
        "Source core module discovery source_roots=%s addons_entries=%s addons_candidates=%s addons_paths=%s discovered_modules=%s",
        list(source_roots),
        list(addons_entries),
        [str(path) for path in dict.fromkeys(all_candidates)],
        [str(path) for path in addons_paths],
        len(module_names),
    )

    return tuple(sorted(module_names))


def _get_excluded_core_modules() -> tuple[str, ...]:
    """Return explicit and source-discovered core modules to exclude.

    Returns:
        Sorted tuple of module names treated as core.
    """
    modules = set(get_odoo_core_modules())
    modules.update(_get_source_core_module_names())
    return tuple(sorted(modules))


def get_effective_core_module_exclusions() -> tuple[str, ...]:
    """Return full effective core module exclusions used by DB queries.

    Returns:
        Tuple of module names excluded by static and source-discovered rules.
    """
    return _get_excluded_core_modules()


def _pick_module_version_expression(available_columns: set[str]) -> str:
    """Choose the first available module-version column expression.

    Args:
        available_columns: Set of column names present in ir_module table.

    Returns:
        Preferred column name, or NULL SQL expression when unavailable.
    """
    for column in get_ir_module_version_columns():
        if column in available_columns:
            return column
    return "NULL"


def get_db_credentials() -> dict:
    """Build PostgreSQL credentials from Odoo config and environment overrides.

    Returns:
        Dictionary of psycopg2 connection parameters.
    """
    params = {}
    options = get_odoo_config_options()
    if options.get("db_host"):
        params["host"] = options.get("db_host")
    if options.get("db_port"):
        params["port"] = options.get("db_port")
    if options.get("db_user"):
        params["user"] = options.get("db_user")
    if options.get("db_password"):
        params["password"] = options.get("db_password")

    if "host" not in params and get_postgres_host():
        params["host"] = get_postgres_host()
    if "port" not in params and get_postgres_port():
        params["port"] = get_postgres_port()
    if "user" not in params and get_postgres_user():
        params["user"] = get_postgres_user()
    if "password" not in params and get_postgres_password():
        params["password"] = get_postgres_password()

    return params


def get_databases(credentials: dict) -> list:
    """List non-template PostgreSQL database names.

    Args:
        credentials: psycopg2 connection keyword arguments.

    Returns:
        List of discovered database names.
    """
    conn = None
    try:
        conn = psycopg2.connect(**credentials, dbname="postgres")
    except psycopg2.OperationalError:
        try:
            conn = psycopg2.connect(**credentials, dbname="template1")
        except Exception as error:
            logger.exception("Error connecting to default DB")
            return []

    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT datname
                FROM pg_database
                WHERE datistemplate = false
                  AND datname <> 'postgres';
            """
            )
            databases = [row[0] for row in cur.fetchall()]
        return databases
    finally:
        if conn:
            conn.close()


def get_db_modules(credentials: dict, dbname: str) -> list:
    """Return installed non-core modules for one database.

    Args:
        credentials: psycopg2 connection keyword arguments.
        dbname: Target database name.

    Returns:
        List of module dictionaries with name, version, and state.
    """
    return _get_db_modules_by_state(credentials=credentials, dbname=dbname, module_state="installed")


def get_db_uninstalled_modules(credentials: dict, dbname: str) -> list:
    """Return uninstalled non-core modules for one database.

    Args:
        credentials: psycopg2 connection keyword arguments.
        dbname: Target database name.

    Returns:
        List of module dictionaries with name, version, and state.
    """
    return _get_db_modules_by_state(credentials=credentials, dbname=dbname, module_state="uninstalled")


def _get_db_modules_by_state(credentials: dict, dbname: str, module_state: str) -> list:
    """Query non-core modules by state from a specific database.

    Args:
        credentials: psycopg2 connection keyword arguments.
        dbname: Target database name.
        module_state: Odoo module state filter, e.g. installed or uninstalled.

    Returns:
        List of module dictionaries with name, version, and state.
    """
    conn_params = credentials.copy()
    conn_params["dbname"] = dbname
    modules = []
    conn = None
    ir_module_table = get_ir_module_table()
    odoo_core_authors = get_odoo_core_authors()
    odoo_core_modules = _get_excluded_core_modules()
    logger.debug(
        "DB module query filters db=%s state=%s core_authors=%s core_modules=%s",
        dbname,
        module_state,
        len(odoo_core_authors),
        len(odoo_core_modules),
    )
    try:
        conn = psycopg2.connect(**conn_params)
        with conn.cursor() as cur:
            cur.execute(
                "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = %s);",
                (ir_module_table,),
            )
            exists = cur.fetchone()[0]
            if exists:
                cur.execute(
                    """
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_name = %s
                """,
                    (ir_module_table,),
                )
                columns = {row[0] for row in cur.fetchall()}
                version_expression = _pick_module_version_expression(columns)
                author_placeholders = ", ".join(["%s"] * len(odoo_core_authors))
                module_placeholders = ", ".join(["%s"] * len(odoo_core_modules))

                cur.execute(
                    """
                    SELECT name, {version_expression}
                    FROM {table_name}
                    WHERE state = %s
                    AND COALESCE(author, '') NOT IN ({author_placeholders})
                    AND name NOT IN ({module_placeholders})
                """.format(
                        table_name=ir_module_table,
                        version_expression=version_expression,
                        author_placeholders=author_placeholders,
                        module_placeholders=module_placeholders,
                    ),
                    (module_state, *odoo_core_authors, *odoo_core_modules),
                )
                modules = [
                    {
                        "name": row[0],
                        "version": row[1],
                        "state": module_state,
                    }
                    for row in cur.fetchall()
                ]
    except Exception as error:
        logger.exception(
            "Error querying DB modules",
            extra={"dbname": dbname, "module_state": module_state},
        )
    finally:
        if conn:
            conn.close()
    return modules
