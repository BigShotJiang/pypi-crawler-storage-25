"""LimeSurvey RemoteControl 2 API client."""

import base64
import json
import os
from pathlib import Path

import httpx
from dotenv import load_dotenv

load_dotenv()

DEFAULT_SERVER = "https://lime.correlaid.org"


class LimeSurveyClient:
    """Client for the LimeSurvey RemoteControl 2 JSON-RPC API."""

    def __init__(
        self,
        server_url: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ):
        self._session_key: str | None = None
        self._rpc_id = 0
        self.server_url = (
            server_url or os.environ.get("LIME_SERVER_URL") or DEFAULT_SERVER
        ).rstrip("/")
        self._username = username or os.environ.get("LIME_USERNAME")
        self._password = password or os.environ.get("LIME_PASSWORD")
        if not self._username or not self._password:
            raise ValueError(
                "Username and password required. "
                "Set LIME_USERNAME and LIME_PASSWORD or pass them as arguments."
            )
        self._http = httpx.Client(timeout=60)

    # -- JSON-RPC transport --------------------------------------------------

    def _rpc(self, method: str, *params) -> object:
        """Make a single JSON-RPC 2.0 call.

        For all methods except get_session_key and release_session_key, the
        session key is automatically obtained (if needed) and prepended to params.
        """
        _auth_methods = ("get_session_key", "release_session_key")
        if method not in _auth_methods:
            if self._session_key is None:
                self._session_key = self._rpc(
                    "get_session_key", self._username, self._password
                )
            params = (self._session_key, *params)

        self._rpc_id += 1
        payload = {"method": method, "params": list(params), "id": self._rpc_id}
        resp = self._http.post(
            f"{self.server_url}/index.php/admin/remotecontrol",
            content=json.dumps(payload),
            headers={"Content-Type": "application/json"},
        )
        resp.raise_for_status()
        data = resp.json()
        if data.get("error"):
            raise RuntimeError(f"LimeSurvey API error in {method!r}: {data['error']}")
        return data["result"]

    def __del__(self):
        if self._session_key:
            try:
                self._rpc("release_session_key", self._session_key)
            except Exception:
                pass

    # -- surveys -------------------------------------------------------------

    def list_surveys(self) -> list[dict]:
        """Return all surveys accessible to the authenticated user."""
        result = self._rpc("list_surveys", self._username)
        if isinstance(result, dict) and result.get("status"):
            return []  # "No surveys found"
        return result

    # -- responses -----------------------------------------------------------

    def get_responses(self, survey_id: int) -> list[dict]:
        """Return all responses for a survey as a list of dicts keyed by question code."""
        result = self._rpc(
            "export_responses",
            survey_id,
            "json",
            None,       # language: use default
            "all",      # completion status
            "code",     # heading type: use question codes as keys
            "long",     # response type: full answer text
        )
        if isinstance(result, dict) and result.get("status"):
            return []   # no responses yet

        raw = base64.b64decode(result).decode("utf-8")
        data = json.loads(raw)
        rows = data.get("responses", [])
        responses = []
        for item in rows:
            if not isinstance(item, dict):
                continue
            # LimeSurvey versions differ in response wrapping:
            # - Nested: {"1": {"id": 1, "field": value, ...}}
            # - Flat:   {"id": 1, "field": value, ...}
            first_val = next(iter(item.values()), None)
            if isinstance(first_val, dict):
                responses.append(first_val)   # unwrap nested
            else:
                responses.append(item)        # already flat
        return responses

    # -- convenience: pull ---------------------------------------------------

    def pull(self, survey_id: int, output_dir: Path | None = None) -> Path:
        """Download responses into *output_dir*/<survey_id>/responses.json."""
        out = (output_dir or Path("output")) / str(survey_id)
        out.mkdir(parents=True, exist_ok=True)

        responses = self.get_responses(survey_id)
        (out / "responses.json").write_text(
            json.dumps(responses, indent=2, ensure_ascii=False)
        )
        print(f"Saved {len(responses)} responses to {out / 'responses.json'}")

        tsv_path = out / "survey.tsv"
        if not tsv_path.exists():
            print(f"Place your LimeSurvey survey-structure TSV at {tsv_path} for the transform step.")

        return out
