"""Tests for Veezoo CLI."""

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from click.testing import CliRunner

from veezoo.cli import (
    cli,
    load_config,
    save_config,
    get_api_key,
    get_base_url,
    get_kg_id,
    CONFIG_FILE,
    ENV_API_KEY,
    ENV_BASE_URL,
    ENV_KG_ID,
)


@pytest.fixture
def runner():
    """
    Create a Click CLI test runner for invoking CLI commands in tests.
    
    Returns:
        CliRunner: A new Click CliRunner instance.
    """
    return CliRunner()


@pytest.fixture
def temp_config_dir(tmp_path, monkeypatch):
    """
    Create a temporary .veezoo configuration directory and point the CLI at it.
    
    Patches veezoo.cli.CONFIG_DIR and veezoo.cli.CONFIG_FILE to use a newly created temporary
    .directory and returns the path to the temporary config.json file.
    
    Returns:
        pathlib.Path: Path to the temporary config.json file.
    """
    config_dir = tmp_path / ".veezoo"
    config_file = config_dir / "config.json"
    
    # Patch the config file location
    monkeypatch.setattr("veezoo.cli.CONFIG_DIR", config_dir)
    monkeypatch.setattr("veezoo.cli.CONFIG_FILE", config_file)
    
    return config_file


class TestConfigManagement:
    """Tests for configuration management."""

    def test_save_and_load_config(self, temp_config_dir):
        """Test saving and loading configuration."""
        config = {"api_key": "test-key", "base_url": "https://custom.url"}
        save_config(config)
        
        loaded = load_config()
        assert loaded == config

    def test_load_config_nonexistent(self, temp_config_dir):
        """Test loading config when file doesn't exist."""
        loaded = load_config()
        assert loaded == {}

    def test_get_api_key_from_argument(self, monkeypatch):
        """Test API key from command line takes priority."""
        monkeypatch.setenv(ENV_API_KEY, "env-key")
        result = get_api_key("arg-key")
        assert result == "arg-key"

    def test_get_api_key_from_env(self, monkeypatch, temp_config_dir):
        """Test API key from environment variable."""
        monkeypatch.setenv(ENV_API_KEY, "env-key")
        result = get_api_key()
        assert result == "env-key"

    def test_get_api_key_from_config(self, temp_config_dir, monkeypatch):
        """Test API key from config file."""
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        save_config({"api_key": "config-key"})
        result = get_api_key()
        assert result == "config-key"


class TestCLICommands:
    """Tests for CLI commands."""

    def test_cli_help(self, runner):
        """Test CLI help output."""
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Veezoo CLI" in result.output

    def test_cli_version(self, runner):
        """Test CLI version output."""
        result = runner.invoke(cli, ["--version"])
        # Version may fail if package not installed, that's okay for testing
        # Just verify the command doesn't crash unexpectedly
        assert result.exit_code in [0, 1]

    def test_configure_command(self, runner, temp_config_dir):
        """Test configure command."""
        result = runner.invoke(cli, ["configure"], input="test-api-key\n\n\n")
        # May fail if ping doesn't work, but config should be saved
        loaded = load_config()
        assert loaded.get("api_key") == "test-api-key"

    def test_config_command_no_config(self, runner, temp_config_dir, monkeypatch):
        """Test config command with no configuration."""
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        monkeypatch.delenv(ENV_BASE_URL, raising=False)
        monkeypatch.delenv(ENV_KG_ID, raising=False)
        
        result = runner.invoke(cli, ["config"])
        assert result.exit_code == 0
        assert "Not set" in result.output or "default" in result.output

    def test_config_command_with_config(self, runner, temp_config_dir, monkeypatch):
        """Test config command with configuration."""
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        save_config({"api_key": "my-secret-key-12345678", "kg_id": "my-kg"})
        
        result = runner.invoke(cli, ["config"])
        assert result.exit_code == 0
        # API key should be masked (first 4 chars visible)
        assert "my-s" in result.output
        # Last 4 chars should be visible
        assert "5678" in result.output
        # Full key should NOT be visible
        assert "my-secret-key-12345678" not in result.output
        # KG ID should be visible
        assert "my-kg" in result.output

    def test_logout_command(self, runner, temp_config_dir):
        """Test logout command."""
        save_config({"api_key": "test-key"})
        assert temp_config_dir.exists()
        
        result = runner.invoke(cli, ["logout"], input="y\n")
        assert result.exit_code == 0
        assert not temp_config_dir.exists()

    def test_ping_without_api_key(self, runner, temp_config_dir, monkeypatch):
        """Test ping command without API key."""
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        
        result = runner.invoke(cli, ["ping"])
        assert result.exit_code == 1
        assert "API key not configured" in result.output

    def test_query_without_api_key(self, runner, temp_config_dir, monkeypatch):
        """Test query command without API key."""
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        
        result = runner.invoke(cli, ["query", "select(1)", "-g", "my-kg"])
        assert result.exit_code == 1
        assert "API key not configured" in result.output

    def test_query_without_kg_id(self, runner, temp_config_dir, monkeypatch):
        """Test query command without Knowledge Graph ID."""
        monkeypatch.setenv(ENV_API_KEY, "test-key")
        monkeypatch.delenv(ENV_KG_ID, raising=False)
        
        result = runner.invoke(cli, ["query", "select(1)"])
        assert result.exit_code == 1
        assert "Knowledge Graph ID required" in result.output

    def test_shared_answer_without_kg_id(self, runner, temp_config_dir, monkeypatch):
        """Test shared-answer command without Knowledge Graph ID."""
        monkeypatch.setenv(ENV_API_KEY, "test-key")
        monkeypatch.delenv(ENV_KG_ID, raising=False)
        
        result = runner.invoke(cli, ["shared-answer", "answer-id"])
        assert result.exit_code == 1
        assert "Knowledge Graph ID required" in result.output

    def test_ask_raw_output_returns_full_response_json(self, runner, temp_config_dir, monkeypatch):
        """Test ask command with full raw JSON output."""
        monkeypatch.setenv(ENV_API_KEY, "test-key")
        monkeypatch.setenv(ENV_KG_ID, "my-kg")

        mock_client = MagicMock()
        mock_client.ask_raw.return_value = {
            "type": "QuestionResult",
            "conversationId": "conv-123",
            "messages": [
                {"type": "text", "content": "Hi there"},
                {
                    "type": "answer",
                    "title": "Number of Customer",
                    "data": {
                        "columns": [{"name": "Number of Customer"}],
                        "rows": [[{"value": "160425"}]],
                    },
                    "vql": "select(count(kb.Customer))",
                    "sql": "SELECT COUNT(*)",
                    "filters": [],
                },
            ],
            "isError": False,
        }

        with patch("veezoo.cli.create_client", return_value=mock_client):
            result = runner.invoke(cli, ["ask", "How many customers?", "--raw"])

        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["type"] == "QuestionResult"
        assert parsed["conversationId"] == "conv-123"
        assert parsed["messages"][0] == {"type": "text", "content": "Hi there"}
        assert parsed["messages"][1]["type"] == "answer"
        assert parsed["messages"][1]["data"]["columns"] == [{"name": "Number of Customer"}]
        assert parsed["messages"][1]["data"]["rows"] == [[{"value": "160425"}]]

    def test_ask_rejects_format_with_raw_output(self, runner, temp_config_dir, monkeypatch):
        """Test ask command rejects format when raw output is requested."""
        monkeypatch.setenv(ENV_API_KEY, "test-key")
        monkeypatch.setenv(ENV_KG_ID, "my-kg")

        result = runner.invoke(
            cli,
            ["ask", "How many customers?", "--raw", "--format", "csv"],
        )

        assert result.exit_code == 1
        assert "--format is not supported with --raw" in result.output

    def test_ask_rejects_show_vql_with_raw_output(self, runner, temp_config_dir, monkeypatch):
        """Test ask command rejects show-vql when raw output is requested."""
        monkeypatch.setenv(ENV_API_KEY, "test-key")
        monkeypatch.setenv(ENV_KG_ID, "my-kg")

        result = runner.invoke(
            cli,
            ["ask", "How many customers?", "--raw", "--show-vql"],
        )

        assert result.exit_code == 1
        assert "--show-vql is not supported with --raw" in result.output

    def test_ask_rejects_show_sql_with_raw_output(self, runner, temp_config_dir, monkeypatch):
        """Test ask command rejects show-sql when raw output is requested."""
        monkeypatch.setenv(ENV_API_KEY, "test-key")
        monkeypatch.setenv(ENV_KG_ID, "my-kg")

        result = runner.invoke(
            cli,
            ["ask", "How many customers?", "--raw", "--show-sql"],
        )

        assert result.exit_code == 1
        assert "--show-sql is not supported with --raw" in result.output

    def test_ask_human_output_supports_json_data_format(self, runner, temp_config_dir, monkeypatch):
        """Test ask command formats answer data as JSON in human output mode."""
        from veezoo.models import AnswerMessage, QuestionResult, Cell, Column, Data, Row

        monkeypatch.setenv(ENV_API_KEY, "test-key")
        monkeypatch.setenv(ENV_KG_ID, "my-kg")

        mock_client = MagicMock()
        mock_client.ask.return_value = QuestionResult(
            type="QuestionResult",
            conversation_id="conv-123",
            messages=[
                AnswerMessage(
                    type="answer",
                    title="Number of Customer",
                    data=Data(
                        columns=[Column("Number of Customer")],
                        rows=[Row([Cell("160425")])],
                    ),
                    vql=None,
                    sql=None,
                    filters=[],
                ),
            ],
            is_error=False,
        )

        with patch("veezoo.cli.create_client", return_value=mock_client):
            result = runner.invoke(
                cli,
                ["ask", "How many customers?", "--format", "json"],
            )

        assert result.exit_code == 0
        assert "Conversation ID: conv-123" in result.output
        assert '"Number of Customer": "160425"' in result.output



class TestOutputFormats:
    """Tests for output formatting."""

    def test_format_data_as_json(self):
        """Test JSON output format."""
        from veezoo.cli import format_data_as_json
        from veezoo.models import Data, Column, Row, Cell
        
        data = Data(
            columns=[Column("Name"), Column("Value")],
            rows=[Row([Cell("A"), Cell("1")]), Row([Cell("B"), Cell("2")])]
        )
        
        result = format_data_as_json(data)
        parsed = json.loads(result)
        
        assert len(parsed) == 2
        assert parsed[0] == {"Name": "A", "Value": "1"}
        assert parsed[1] == {"Name": "B", "Value": "2"}

    def test_format_data_as_csv(self):
        """
        Verify CSV formatting of a Data object into a header line and subsequent rows.
        
        Asserts that the CSV header uses the Data.columns names joined by commas and that each Data.row
        becomes a comma-separated line preserving cell values and order (e.g., header "Name,Value" and
        rows "A,1" and "B,2").
        """
        from veezoo.cli import format_data_as_csv
        from veezoo.models import Data, Column, Row, Cell
        
        data = Data(
            columns=[Column("Name"), Column("Value")],
            rows=[Row([Cell("A"), Cell("1")]), Row([Cell("B"), Cell("2")])]
        )
        
        result = format_data_as_csv(data)
        # Normalize line endings and split
        lines = result.replace("\r\n", "\n").replace("\r", "\n").strip().split("\n")
        
        assert lines[0] == "Name,Value"
        assert lines[1] == "A,1"
        assert lines[2] == "B,2"