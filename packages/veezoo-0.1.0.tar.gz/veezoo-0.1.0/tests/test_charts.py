"""Tests for CLI chart heuristics and formatting."""

import re

import pytest

from veezoo import charts
from veezoo.charts import (
    HAS_PLOTEXT,
    _CHART_BAR,
    _CHART_HBAR,
    _CHART_GROUPED_BAR,
    _CHART_LINE,
    _compact_number,
    _detect_chart_type,
    _render_grouped_bar,
    _render_hbar,
    _numeric_ticks,
    _sanitize_label,
)
from veezoo.models import Cell, Column, Data, Row


def make_data(columns, rows):
    return Data(
        columns=[Column(name=name) for name in columns],
        rows=[Row(cells=[Cell(value=str(value)) for value in row]) for row in rows],
    )


def _render_chart_snapshot(monkeypatch, data):
    if not HAS_PLOTEXT:
        pytest.skip("plotext is not installed")

    monkeypatch.setattr(charts, "_terminal_width", lambda: 80)
    rendered = charts.render_chart(data)
    assert rendered is not None

    ansi_pattern = re.compile(r"\x1b\[[0-9;]*m")
    cleaned = ansi_pattern.sub("", rendered)
    return "\n".join(line.rstrip() for line in cleaned.splitlines()).strip("\n")


def test_detect_chart_type_prefers_vertical_bar_for_small_single_series_categories():
    data = make_data(
        ["Segment", "Customers"],
        [["Private", "136433"], ["Company", "23992"]],
    )

    assert _detect_chart_type(data) == _CHART_BAR


def test_detect_chart_type_prefers_horizontal_bar_for_larger_single_series_categories():
    data = make_data(
        ["Segment", "Customers"],
        [[f"Label {i}", str(i * 1000 + 500)] for i in range(1, 14)],
    )

    assert _detect_chart_type(data) == _CHART_HBAR


def test_detect_chart_type_prefers_line_for_dates():
    data = make_data(
        ["Month", "Revenue"],
        [["2025-01", "100"], ["2025-02", "120"], ["2025-03", "90"]],
    )

    assert _detect_chart_type(data) == _CHART_LINE


def test_detect_chart_type_uses_grouped_bar_for_multi_series_categories():
    data = make_data(
        ["Region", "Revenue", "Cost"],
        [["East", "100", "80"], ["West", "120", "90"], ["North", "95", "70"]],
    )

    assert _detect_chart_type(data) == _CHART_GROUPED_BAR


def test_render_grouped_bar_uses_default_series_colors(monkeypatch):
    data = make_data(
        ["Region", "Revenue", "Cost"],
        [["East", "100", "80"], ["West", "120", "90"], ["North", "95", "70"]],
    )
    captured = {}

    monkeypatch.setattr(charts, "_setup_plot", lambda height=15: None)
    monkeypatch.setattr(charts.plt, "grid", lambda *args, **kwargs: None)
    monkeypatch.setattr(charts.plt, "yticks", lambda *args, **kwargs: None)
    monkeypatch.setattr(charts.plt, "build", lambda: "ok")

    def fake_multiple_bar(*args, **kwargs):
        captured["args"] = args
        captured["kwargs"] = kwargs

    monkeypatch.setattr(charts.plt, "multiple_bar", fake_multiple_bar)

    assert _render_grouped_bar(data) == "ok"
    assert captured["kwargs"]["color"] == ["cyan", "grey"]


def test_compact_number_uses_short_suffixes():
    assert _compact_number(136433) == "136k"
    assert _compact_number(12500) == "12.5k"
    assert _compact_number(1_250_000) == "1.25M"
    assert _compact_number(45_590) == "45.5k"


def test_numeric_ticks_start_at_zero_for_positive_series():
    ticks, labels = _numeric_ticks([12, 50, 120])

    assert ticks[0] == 0.0
    assert labels[0] == "0"
    assert labels[-1] == "120"


def test_sanitize_label_trims_and_truncates():
    assert _sanitize_label("   ") == "(blank)"
    assert _sanitize_label("This is a very long category label", max_length=18) == "This is a very..."


def test_render_bar_chart_snapshot(monkeypatch):
    data = make_data(
        ["Segment", "Customers"],
        [["Private", "136433"], ["Company", "23992"]],
    )

    assert _render_chart_snapshot(monkeypatch, data) == """\
     ┌─────────────────────────────────────────────────────────────────────┐
 136k┼███████████████████████████████──────────────────────────────────────┤
     │███████████████████████████████                                      │
     │███████████████████████████████                                      │
90.9k┼███████████████████████████████──────────────────────────────────────┤
     │███████████████████████████████                                      │
     │███████████████████████████████                                      │
     │███████████████████████████████                                      │
45.4k┼███████████████████████████████──────────────────────────────────────┤
     │███████████████████████████████       🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭🬭│
     │███████████████████████████████       ███████████████████████████████│
    0┼███████████████████████████████───────███████████████████████████████┤
     └───────────────┬─────────────────────────────────────┬───────────────┘
                  Private                               Company
Customers"""


def test_render_horizontal_bar_chart_snapshot(monkeypatch):
    monkeypatch.setattr(charts, "_terminal_width", lambda: 80)
    rendered = _render_hbar(
        make_data(
            ["Segment", "Customers"],
            [[f"Label {i}", str(i * 1000 + 500)] for i in range(1, 14)],
        )
    )
    assert rendered is not None

    ansi_pattern = re.compile(r"\x1b\[[0-9;]*m")
    cleaned = ansi_pattern.sub("", rendered)
    snapshot = "\n".join(line.rstrip() for line in cleaned.splitlines()).strip("\n")

    assert snapshot == """\
        ┌┬─────────────────────┬────────────────────┬─────────────────────┬┐
Label 13┤██████████████████████████████████████████████████████████████████│
Label 12┤█████████████████████████████████████████████████████████████    ││
Label 11┤████████████████████████████████████████████████████████▌        ││
Label 10┤███████████████████████████████████████████████████▌             ││
 Label 9┤██████████████████████████████████████████████▌                  ││
 Label 8┤█████████████████████████████████████████▌ │                     ││
 Label 7┤█████████████████████████████████████      │                     ││
 Label 6┤████████████████████████████████           │                     ││
 Label 5┤███████████████████████████                │                     ││
 Label 4┤██████████████████████▌                    │                     ││
 Label 3┤█████████████████▌    │                    │                     ││
 Label 2┤████████████▌         │                    │                     ││
 Label 1┤████████              │                    │                     ││
        └┼─────────────────────┼────────────────────┼─────────────────────┼┘
         0                   4.5k                  9k                 13.5k
                                      Customers"""


def test_render_line_chart_snapshot(monkeypatch):
    data = make_data(
        ["Month", "Revenue"],
        [["2025-01", "100"], ["2025-02", "120"], ["2025-03", "90"], ["2025-04", "160"]],
    )

    assert _render_chart_snapshot(monkeypatch, data) == """\
     ┌─────────────────────────────────────────────────────────────────────┐
  160┼ 🬗🬗 Revenue ──────────────────────────────────────────────────────🬞🬖🬅┤
     │                                                               🬞🬖🬅🬀  │
     │                                                            🬞🬖🬅🬀     │
     │                                                         🬞🬖🬅🬀        │
     │                    🬭🬭🬭🬢🬭🬏                            🬞🬖🬅🬀           │
106.6┼──────────🬭🬭🬭🬖🬋🬋🬅🬂🬂🬂─────🬁🬂🬂🬋🬋🬭🬭🬏──────────────────🬞🬖🬅🬀──────────────┤
     │🬭🬭🬭🬖🬋🬋🬋🬂🬂🬂                      🬁🬂🬈🬋🬋🬭🬭         🬞🬖🬅🬀                 │
     │                                       🬂🬂🬈🬋🬢🬭🬭🬖🬅🬀                    │
     └┬──────────────────────┬─────────────────────┬──────────────────────┬┘
   2025-01                2025-02               2025-03             2025-04
                                      Month"""


def test_render_grouped_bar_chart_snapshot(monkeypatch):
    data = make_data(
        ["Region", "Revenue", "Cost"],
        [["East", "100", "80"], ["West", "120", "90"], ["North", "95", "70"]],
    )

    assert _render_chart_snapshot(monkeypatch, data) == """\
   ┌───────────────────────────────────────────────────────────────────────┐
120┼ 🬗🬗 Revenue ────────────▐█████████▌────────────────────────────────────┤
   │ 🬗🬗 Cost                ▐█████████▌                                    │
   │██████████              ▐█████████▌             🬦🬹🬹🬹🬹🬹🬹🬹🬹🬹🬹            │
   │██████████              ▐█████████▌ ▐█████████▌ ▐██████████            │
 80┼██████████──██████████▌─▐█████████▌─▐█████████▌─▐██████████────────────┤
   │██████████  ██████████▌ ▐█████████▌ ▐█████████▌ ▐██████████  ██████████│
   │██████████  ██████████▌ ▐█████████▌ ▐█████████▌ ▐██████████  ██████████│
 40┼██████████──██████████▌─▐█████████▌─▐█████████▌─▐██████████──██████████┤
   │██████████  ██████████▌ ▐█████████▌ ▐█████████▌ ▐██████████  ██████████│
   │██████████  ██████████▌ ▐█████████▌ ▐█████████▌ ▐██████████  ██████████│
   │██████████  ██████████▌ ▐█████████▌ ▐█████████▌ ▐██████████  ██████████│
  0┼██████████──██████████▌─▐█████████▌─▐█████████▌─▐██████████──██████████┤
   └───────────┬───────────────────────┬───────────────────────┬───────────┘
             East                    West                    North"""
