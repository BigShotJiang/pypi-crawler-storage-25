"""Tests for Veezoo SDK data models."""

import pytest
from veezoo.models import (
    Cell,
    Column,
    Row,
    Data,
    QuestionResult,
    RewritingStep,
    RewritingStage,
    Rewriting,
    VqlQueryResult,
    SharedAnswerResult,
)

# Check if pandas is available for conditional tests
try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False


class TestCell:
    """Tests for Cell model."""

    def test_from_raw(self):
        cell = Cell.from_raw("test")
        assert cell.value == "test"

    def test_str(self):
        cell = Cell(value="hello")
        assert str(cell) == "hello"

    def test_as_int(self):
        cell = Cell(value="42")
        assert cell.as_int() == 42

    def test_as_float(self):
        cell = Cell(value="3.14")
        assert cell.as_float() == 3.14

    def test_as_bool_true(self):
        for value in ["true", "True", "1", "yes"]:
            cell = Cell(value=value)
            assert cell.as_bool() is True

    def test_as_bool_false(self):
        for value in ["false", "False", "0", "no"]:
            cell = Cell(value=value)
            assert cell.as_bool() is False


class TestColumn:
    """Tests for Column model."""

    def test_from_dict(self):
        column = Column.from_dict({"name": "Customer Name"})
        assert column.name == "Customer Name"


class TestRow:
    """Tests for Row model."""

    def test_from_list(self):
        row = Row.from_list(["a", "b"])
        assert len(row) == 2
        assert row[0].value == "a"
        assert row[1].value == "b"

    def test_iteration(self):
        row = Row(cells=[Cell("x"), Cell("y")])
        values = [cell.value for cell in row]
        assert values == ["x", "y"]

    def test_values(self):
        row = Row(cells=[Cell("1"), Cell("2"), Cell("3")])
        assert row.values() == ["1", "2", "3"]


class TestData:
    """Tests for Data model."""

    def test_from_dict(self):
        data_dict = {
            "columns": [{"name": "State"}, {"name": "Count"}],
            "rows": [
                ["NY", "100"],
                ["CA", "200"],
            ],
        }
        data = Data.from_dict(data_dict)
        assert len(data.columns) == 2
        assert len(data.rows) == 2
        assert data.columns[0].name == "State"

    def test_len(self):
        data = Data(
            columns=[Column("A")],
            rows=[Row([Cell("1")]), Row([Cell("2")])],
        )
        assert len(data) == 2

    def test_iteration(self):
        data = Data(
            columns=[Column("A")],
            rows=[Row([Cell("1")]), Row([Cell("2")])],
        )
        values = [row[0].value for row in data]
        assert values == ["1", "2"]

    def test_column_names(self):
        data = Data(
            columns=[Column("A"), Column("B"), Column("C")],
            rows=[],
        )
        assert data.column_names() == ["A", "B", "C"]

    def test_to_list(self):
        data = Data(
            columns=[Column("A"), Column("B")],
            rows=[
                Row([Cell("1"), Cell("2")]),
                Row([Cell("3"), Cell("4")]),
            ],
        )
        assert data.to_list() == [["1", "2"], ["3", "4"]]

    def test_to_dicts(self):
        data = Data(
            columns=[Column("Name"), Column("Age")],
            rows=[
                Row([Cell("Alice"), Cell("30")]),
                Row([Cell("Bob"), Cell("25")]),
            ],
        )
        result = data.to_dicts()
        assert result == [
            {"Name": "Alice", "Age": "30"},
            {"Name": "Bob", "Age": "25"},
        ]


class TestRewritingStep:
    """Tests for RewritingStep model."""

    def test_from_dict(self):
        step_dict = {
            "stage": "logic",
            "rule": "ImplicitSortRule",
            "rewrittenVql": "var x from kb.X\nselect(x)",
        }
        step = RewritingStep.from_dict(step_dict)
        assert step.stage == RewritingStage.LOGIC
        assert step.rule == "ImplicitSortRule"
        assert step.rewritten_vql == "var x from kb.X\nselect(x)"
        assert step.error_message is None

    def test_from_dict_with_error(self):
        step_dict = {
            "stage": "semantic",
            "rule": "SomeRule",
            "errorMessage": "Rewriting failed",
        }
        step = RewritingStep.from_dict(step_dict)
        assert step.stage == RewritingStage.SEMANTIC
        assert step.error_message == "Rewriting failed"
        assert step.rewritten_vql is None


class TestRewriting:
    """Tests for Rewriting model."""

    def test_from_dict(self):
        rewriting_dict = {
            "steps": [
                {"stage": "logic", "rule": "Rule1", "rewrittenVql": "vql1"},
                {"stage": "semantic", "rule": "Rule2", "rewrittenVql": "vql2"},
            ],
            "rewrittenVql": "final vql",
        }
        rewriting = Rewriting.from_dict(rewriting_dict)
        assert len(rewriting.steps) == 2
        assert rewriting.rewritten_vql == "final vql"
        assert rewriting.error_message is None

    def test_from_dict_empty_steps(self):
        rewriting = Rewriting.from_dict({"steps": []})
        assert len(rewriting.steps) == 0


class TestVqlQueryResult:
    """Tests for VqlQueryResult model."""

    def test_from_dict(self):
        result_dict = {
            "type": "VqlQueryResult",
            "rewriting": {
                "steps": [],
                "rewrittenVql": "var x from kb.X\nselect(x)",
            },
            "sql": "SELECT * FROM x",
            "data": {
                "columns": [{"name": "X"}],
                "rows": [["1"]],
            },
        }
        result = VqlQueryResult.from_dict(result_dict)
        assert result.type == "VqlQueryResult"
        assert result.sql == "SELECT * FROM x"
        assert len(result.data.columns) == 1
        assert len(result.data.rows) == 1

    def test_from_dict_without_sql(self):
        result_dict = {
            "type": "VqlQueryResult",
            "rewriting": {"steps": []},
            "data": {"columns": [], "rows": []},
        }
        result = VqlQueryResult.from_dict(result_dict)
        assert result.sql is None


class TestSharedAnswerResult:
    """Tests for SharedAnswerResult model."""

    def test_from_dict(self):
        result_dict = {
            "type": "SharedAnswerResult",
            "vql": "var x from kb.X\nselect(x)",
            "rewriting": {
                "steps": [],
                "rewrittenVql": "var x from kb.X\nselect(x)",
            },
            "sql": "SELECT * FROM x",
            "data": {
                "columns": [{"name": "X"}],
                "rows": [["1"]],
            },
        }
        result = SharedAnswerResult.from_dict(result_dict)
        assert result.type == "SharedAnswerResult"
        assert result.vql == "var x from kb.X\nselect(x)"
        assert result.sql == "SELECT * FROM x"

    def test_from_dict_without_optional_fields(self):
        result_dict = {
            "type": "SharedAnswerResult",
            "rewriting": {"steps": []},
            "data": {"columns": [], "rows": []},
        }
        result = SharedAnswerResult.from_dict(result_dict)
        assert result.vql is None
        assert result.sql is None


class TestQuestionResult:
    """Tests for QuestionResult model."""

    def test_from_dict_parses_answer_message_error_message(self):
        result_dict = {
            "type": "QuestionResult",
            "conversationId": "conv-123",
            "messages": [
                {
                    "type": "answer",
                    "title": "count of customers",
                    "data": None,
                    "vql": "show count of Customer",
                    "sql": None,
                    "filters": [],
                    "errorMessage": "Failed to execute answer: Query timed out",
                }
            ],
            "isError": False,
        }

        result = QuestionResult.from_dict(result_dict)
        answer = result.messages[0]
        assert answer.error_message == "Failed to execute answer: Query timed out"
        assert answer.data is None

    def test_from_dict_rejects_unknown_message_type(self):
        result_dict = {
            "type": "QuestionResult",
            "conversationId": "conv-123",
            "messages": [
                {"type": "unknown", "content": "mystery"}
            ],
            "isError": False,
        }

        with pytest.raises(ValueError, match="Unknown API message type"):
            QuestionResult.from_dict(result_dict)


@pytest.mark.skipif(not HAS_PANDAS, reason="pandas not installed")
class TestDataFrameConversion:
    """Tests for pandas DataFrame conversion."""

    def _is_string_dtype(self, dtype):
        """
        Determine whether a pandas dtype represents a string column, supporting both pandas 2.x (object dtype) and pandas 3.x (StringDtype).
        
        Parameters:
            dtype: The dtype to check (typically a pandas dtype object).
        
        Returns:
            True if `dtype` represents a string column, False otherwise.
        """
        import pandas as pd
        # In pandas 3.x, strings use StringDtype; in 2.x, they use object
        return dtype == object or (hasattr(pd, 'StringDtype') and isinstance(dtype, pd.StringDtype))

    def _is_numeric_dtype(self, dtype):
        """
        Determine whether a pandas dtype represents a numeric type.
        
        Parameters:
        	dtype: A pandas dtype or dtype-like object to test.
        
        Returns:
        	True if `dtype` is numeric, False otherwise.
        """
        import pandas as pd
        return pd.api.types.is_numeric_dtype(dtype)

    def test_to_dataframe_basic(self):
        """Test basic DataFrame conversion."""
        data = Data(
            columns=[Column("Name"), Column("Age"), Column("City")],
            rows=[
                Row([Cell("Alice"), Cell("30"), Cell("New York")]),
                Row([Cell("Bob"), Cell("25"), Cell("Los Angeles")]),
            ],
        )
        df = data.to_dataframe()
        
        assert list(df.columns) == ["Name", "Age", "City"]
        assert len(df) == 2
        assert df.iloc[0]["Name"] == "Alice"
        assert df.iloc[1]["City"] == "Los Angeles"

    def test_to_dataframe_infer_types(self):
        """Test that numeric types are inferred by default."""
        data = Data(
            columns=[Column("Name"), Column("Count"), Column("Price")],
            rows=[
                Row([Cell("Product A"), Cell("100"), Cell("19.99")]),
                Row([Cell("Product B"), Cell("50"), Cell("29.99")]),
            ],
        )
        df = data.to_dataframe(infer_types=True)
        
        # Name should remain string
        assert self._is_string_dtype(df["Name"].dtype)
        # Count should be numeric
        assert self._is_numeric_dtype(df["Count"].dtype)
        # Price should be float
        assert self._is_numeric_dtype(df["Price"].dtype)
        assert df.iloc[0]["Count"] == 100
        assert df.iloc[0]["Price"] == 19.99

    def test_to_dataframe_no_infer_types(self):
        """Test that types are not inferred when disabled."""
        data = Data(
            columns=[Column("Count")],
            rows=[Row([Cell("100")])],
        )
        df = data.to_dataframe(infer_types=False)
        
        # Should remain as string
        assert self._is_string_dtype(df["Count"].dtype)
        assert df.iloc[0]["Count"] == "100"

    def test_to_dataframe_empty(self):
        """Test DataFrame conversion with empty data."""
        data = Data(columns=[Column("A"), Column("B")], rows=[])
        df = data.to_dataframe()
        
        # Empty DataFrames may have no columns in some pandas versions
        # Just verify it's empty and doesn't error
        assert len(df) == 0

    def test_to_dataframe_mixed_numeric(self):
        """Test that mixed columns remain as strings."""
        data = Data(
            columns=[Column("Mixed")],
            rows=[
                Row([Cell("100")]),
                Row([Cell("hello")]),
                Row([Cell("200")]),
            ],
        )
        df = data.to_dataframe(infer_types=True)
        
        # Should remain string since not all values are numeric
        assert self._is_string_dtype(df["Mixed"].dtype)