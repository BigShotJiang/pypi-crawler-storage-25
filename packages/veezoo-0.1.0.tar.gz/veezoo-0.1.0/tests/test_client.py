"""Tests for Veezoo SDK client."""

import pytest
from veezoo.client import VeezooClient
from veezoo.exceptions import VeezooError
from unittest.mock import patch


class TestVeezooClientInit:
    """Tests for VeezooClient initialization."""

    def test_init_with_api_key(self):
        client = VeezooClient(api_key="test-api-key")
        assert client.api_key == "test-api-key"
        assert client.base_url == "https://app.veezoo.com/api"
        assert client.timeout == 120

    def test_init_with_custom_base_url(self):
        client = VeezooClient(
            api_key="test-key",
            base_url="https://custom.veezoo.com/api",
        )
        assert client.base_url == "https://custom.veezoo.com/api"

    def test_init_strips_trailing_slash(self):
        client = VeezooClient(
            api_key="test-key",
            base_url="https://app.veezoo.com/api/",
        )
        assert client.base_url == "https://app.veezoo.com/api"

    def test_init_with_custom_timeout(self):
        client = VeezooClient(api_key="test-key", timeout=60)
        assert client.timeout == 60

    def test_init_without_api_key_raises_error(self):
        with pytest.raises(VeezooError) as exc_info:
            VeezooClient(api_key="")
        assert "API key is required" in str(exc_info.value)

    def test_init_with_none_api_key_raises_error(self):
        with pytest.raises(VeezooError):
            VeezooClient(api_key=None)


class TestVeezooClientHeaders:
    """Tests for request headers."""

    def test_get_headers(self):
        client = VeezooClient(api_key="my-secret-key")
        headers = client._get_headers()
        assert headers["X-Api-Key"] == "my-secret-key"
        assert headers["Content-Type"] == "application/json"
        assert headers["Accept"] == "application/json"


class TestVeezooClientValidation:
    """Tests for input validation."""

    def test_run_vql_query_requires_kg_id(self):
        client = VeezooClient(api_key="test-key")
        with pytest.raises(VeezooError) as exc_info:
            client.run_vql_query(kg_id="", vql="select(1)")
        assert "Knowledge Graph ID" in str(exc_info.value)

    def test_run_vql_query_requires_vql(self):
        client = VeezooClient(api_key="test-key")
        with pytest.raises(VeezooError) as exc_info:
            client.run_vql_query(kg_id="my-kg", vql="")
        assert "VQL query is required" in str(exc_info.value)

    def test_run_shared_answer_requires_kg_id(self):
        client = VeezooClient(api_key="test-key")
        with pytest.raises(VeezooError) as exc_info:
            client.run_shared_answer(kg_id="", shared_answer_id="answer-1")
        assert "Knowledge Graph ID" in str(exc_info.value)

    def test_run_shared_answer_requires_answer_id(self):
        client = VeezooClient(api_key="test-key")
        with pytest.raises(VeezooError) as exc_info:
            client.run_shared_answer(kg_id="my-kg", shared_answer_id="")
        assert "Shared answer ID" in str(exc_info.value)

    def test_ask_raw_requires_kg_id(self):
        client = VeezooClient(api_key="test-key")
        with pytest.raises(VeezooError) as exc_info:
            client.ask_raw(kg_id="", question="How many customers?")
        assert "Knowledge Graph ID" in str(exc_info.value)

    def test_ask_raw_requires_question(self):
        client = VeezooClient(api_key="test-key")
        with pytest.raises(VeezooError) as exc_info:
            client.ask_raw(kg_id="my-kg", question="")
        assert "Question is required" in str(exc_info.value)


class TestVeezooClientAskRaw:
    """Tests for raw question responses."""

    def test_ask_raw_returns_request_response(self):
        client = VeezooClient(api_key="test-key")
        raw_response = {
            "type": "QuestionResult",
            "conversationId": "conv-123",
            "messages": [{"type": "text", "content": "Hi there"}],
            "isError": False,
        }

        with patch.object(client, "_request", return_value=raw_response) as mock_request:
            result = client.ask_raw(
                kg_id="my-kg",
                question="How many customers?",
                conversation_id="conv-123",
                language="de",
            )

        assert result == raw_response
        mock_request.assert_called_once_with(
            method="POST",
            endpoint="/questions",
            params={"kgId": "my-kg"},
            data={
                "question": "How many customers?",
                "conversationId": "conv-123",
                "language": "de",
            },
        )
