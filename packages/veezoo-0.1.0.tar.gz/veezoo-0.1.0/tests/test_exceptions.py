"""Tests for Veezoo SDK exceptions."""

import pytest
from veezoo.exceptions import (
    VeezooError,
    VeezooApiError,
    VeezooAuthenticationError,
    VeezooPaymentRequiredError,
    VeezooNotFoundError,
    VeezooRateLimitError,
    VeezooValidationError,
    VeezooServerError,
)


class TestVeezooError:
    """Tests for base VeezooError."""

    def test_message(self):
        error = VeezooError("Something went wrong")
        assert error.message == "Something went wrong"
        assert str(error) == "Something went wrong"


class TestVeezooApiError:
    """Tests for VeezooApiError."""

    def test_basic(self):
        error = VeezooApiError("API Error", 500)
        assert error.status_code == 500
        assert error.message == "API Error"
        assert error.request_id is None
        assert error.response_body is None

    def test_with_request_id(self):
        error = VeezooApiError("Error", 500, request_id="req-123")
        assert error.request_id == "req-123"
        assert "req-123" in str(error)

    def test_str_format(self):
        error = VeezooApiError("Error message", 404, request_id="abc123")
        assert str(error) == "[HTTP 404] Error message (Request ID: abc123)"

    def test_str_format_without_request_id(self):
        error = VeezooApiError("Error message", 404)
        assert str(error) == "[HTTP 404] Error message"


class TestSpecificErrors:
    """Tests for specific error types."""

    def test_authentication_error(self):
        error = VeezooAuthenticationError()
        assert error.status_code == 401
        assert "API key" in error.message

    def test_authentication_error_custom_message(self):
        error = VeezooAuthenticationError(message="Custom auth error")
        assert error.message == "Custom auth error"
        assert error.status_code == 401

    def test_payment_required_error(self):
        error = VeezooPaymentRequiredError()
        assert error.status_code == 402
        assert "subscription" in error.message.lower()

    def test_not_found_error(self):
        error = VeezooNotFoundError()
        assert error.status_code == 404

    def test_rate_limit_error(self):
        error = VeezooRateLimitError()
        assert error.status_code == 429
        assert "rate limit" in error.message.lower()

    def test_validation_error(self):
        error = VeezooValidationError()
        assert error.status_code == 400

    def test_server_error(self):
        error = VeezooServerError()
        assert error.status_code == 500

    def test_server_error_custom_status(self):
        error = VeezooServerError(status_code=503)
        assert error.status_code == 503


class TestExceptionInheritance:
    """Tests for exception inheritance."""

    def test_api_error_inherits_from_veezoo_error(self):
        error = VeezooApiError("error", 500)
        assert isinstance(error, VeezooError)

    def test_specific_errors_inherit_from_api_error(self):
        errors = [
            VeezooAuthenticationError(),
            VeezooPaymentRequiredError(),
            VeezooNotFoundError(),
            VeezooRateLimitError(),
            VeezooValidationError(),
            VeezooServerError(),
        ]
        for error in errors:
            assert isinstance(error, VeezooApiError)
            assert isinstance(error, VeezooError)
