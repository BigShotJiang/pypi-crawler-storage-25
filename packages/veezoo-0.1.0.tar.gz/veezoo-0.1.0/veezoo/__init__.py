"""
Veezoo Python SDK

A Python client library for the Veezoo API.
"""

from .client import VeezooClient
from .models import (
    VqlQueryResult,
    SharedAnswerResult,
    TextMessage,
    AnswerMessage,
    QuestionResult,
    Data,
    Column,
    Row,
    Cell,
    Rewriting,
    RewritingStep,
)
from .exceptions import (
    VeezooError,
    VeezooApiError,
    VeezooAuthenticationError,
    VeezooPaymentRequiredError,
    VeezooNotFoundError,
    VeezooRateLimitError,
    VeezooValidationError,
    VeezooServerError,
)

from importlib.metadata import version as _version

__version__ = _version("veezoo")
__all__ = [
    "VeezooClient",
    "VqlQueryResult",
    "SharedAnswerResult",
    "TextMessage",
    "AnswerMessage",
    "QuestionResult",
    "Data",
    "Column",
    "Row",
    "Cell",
    "Rewriting",
    "RewritingStep",
    "VeezooError",
    "VeezooApiError",
    "VeezooAuthenticationError",
    "VeezooPaymentRequiredError",
    "VeezooNotFoundError",
    "VeezooRateLimitError",
    "VeezooValidationError",
    "VeezooServerError",
]
