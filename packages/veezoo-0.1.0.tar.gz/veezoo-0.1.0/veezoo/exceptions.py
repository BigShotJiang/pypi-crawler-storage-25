"""
Veezoo SDK Exceptions

Custom exceptions for handling Veezoo API errors.
"""

from typing import Optional, Any, Dict


class VeezooError(Exception):
    """Base exception for all Veezoo SDK errors."""

    def __init__(self, message: str):
        """
        Base initializer for VeezooError that records the error message.
        
        Parameters:
            message (str): Human-readable error message to store on the exception instance.
        """
        self.message = message
        super().__init__(self.message)


class VeezooApiError(VeezooError):
    """
    Exception raised when the Veezoo API returns an error response.

    Attributes:
        status_code: HTTP status code from the API response
        message: Error message from the API
        request_id: The unique request ID returned by Veezoo (if available)
        response_body: The full response body (if available)
    """

    def __init__(
        self,
        message: str,
        status_code: int,
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize a Veezoo API error with HTTP status and optional request/response details.
        
        Parameters:
            message (str): Human-readable error message from the API.
            status_code (int): HTTP status code associated with the error.
            request_id (Optional[str]): Veezoo-provided request identifier, if available.
            response_body (Optional[Dict[str, Any]]): Full parsed response body returned by the API, if available.
        """
        self.status_code = status_code
        self.request_id = request_id
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        """
        Format the API error into a human-readable string.
        
        Returns:
            str: A string starting with "[HTTP {status_code}] {message}". If a request_id is present, " (Request ID: {request_id})" is appended.
        """
        parts = [f"[HTTP {self.status_code}] {self.message}"]
        if self.request_id:
            parts.append(f"(Request ID: {self.request_id})")
        return " ".join(parts)


class VeezooAuthenticationError(VeezooApiError):
    """
    Exception raised when authentication fails (HTTP 401).

    This typically occurs when:
    - The API key is missing
    - The API key is invalid
    - The API key has been revoked
    """

    def __init__(
        self,
        message: str = "Authentication failed. Please check your API key.",
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize an authentication error representing an HTTP 401 response.
        
        Parameters:
            message (str): Human-readable error message. Defaults to "Authentication failed. Please check your API key."
            request_id (Optional[str]): Optional Veezoo request identifier associated with the error.
            response_body (Optional[Dict[str, Any]]): Optional full API response body for diagnostics.
        """
        super().__init__(message, 401, request_id, response_body)


class VeezooPaymentRequiredError(VeezooApiError):
    """
    Exception raised when payment is required (HTTP 402).

    This typically occurs when:
    - The account subscription has expired
    - The account has exceeded its usage limits
    """

    def __init__(
        self,
        message: str = "Payment required. Please check your subscription status.",
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize a VeezooPaymentRequiredError representing an HTTP 402 payment-required response.
        
        Parameters:
            message (str): Human-readable error message. Defaults to "Payment required. Please check your subscription status."
            request_id (Optional[str]): Optional unique request identifier returned by the API.
            response_body (Optional[Dict[str, Any]]): Optional full API response body for debugging or inspection.
        """
        super().__init__(message, 402, request_id, response_body)


class VeezooNotFoundError(VeezooApiError):
    """
    Exception raised when a resource is not found (HTTP 404).

    This typically occurs when:
    - The knowledge graph ID is invalid
    - The shared answer ID does not exist
    """

    def __init__(
        self,
        message: str = "Resource not found.",
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize a VeezooNotFoundError for HTTP 404 responses.
        
        Parameters:
            message (str): Human-readable error message; defaults to "Resource not found."
            request_id (Optional[str]): Optional Veezoo request identifier associated with the error.
            response_body (Optional[Dict[str, Any]]): Optional full API response body returned by Veezoo.
        """
        super().__init__(message, 404, request_id, response_body)


class VeezooRateLimitError(VeezooApiError):
    """
    Exception raised when rate limit is exceeded (HTTP 429).

    Rate limits:
    - Global rate limit: 25 requests/second across all endpoints
    - Per-endpoint rate limit: 10 requests/second per endpoint
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded. Please slow down your requests.",
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ):
        """
        Create a VeezooRateLimitError representing an HTTP 429 rate-limit response.
        
        Parameters:
            message (str): Human-readable error message. Defaults to "Rate limit exceeded. Please slow down your requests."
            request_id (Optional[str]): Optional Veezoo request identifier associated with the error.
            response_body (Optional[Dict[str, Any]]): Optional full response body returned by the API.
        """
        super().__init__(message, 429, request_id, response_body)


class VeezooValidationError(VeezooApiError):
    """
    Exception raised when request validation fails (HTTP 400).

    This typically occurs when:
    - Required parameters are missing
    - Parameter values are invalid
    - The VQL query syntax is invalid
    """

    def __init__(
        self,
        message: str = "Request validation failed.",
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ):
        """
        Create a VeezooValidationError representing an HTTP 400 request validation failure.
        
        Parameters:
            message (str): Human-readable error message. Defaults to "Request validation failed.".
            request_id (Optional[str]): Optional Veezoo request identifier associated with the error.
            response_body (Optional[Dict[str, Any]]): Optional full response body or error payload returned by the API.
        """
        super().__init__(message, 400, request_id, response_body)


class VeezooServerError(VeezooApiError):
    """
    Exception raised when the server encounters an error (HTTP 5xx).

    This typically occurs when:
    - The VQL query execution fails
    - There's an internal server error
    - The database connection times out
    """

    def __init__(
        self,
        message: str = "Server error occurred.",
        status_code: int = 500,
        request_id: Optional[str] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize a server-side API error for Veezoo.
        
        Parameters:
            message (str): Human-readable error message. Defaults to "Server error occurred.".
            status_code (int): HTTP status code for the server error (typically 5xx). Defaults to 500.
            request_id (Optional[str]): Optional Veezoo request identifier associated with the error.
            response_body (Optional[Dict[str, Any]]): Optional full response payload returned by the API.
        """
        super().__init__(message, status_code, request_id, response_body)