"""
Veezoo Interactive Mode

A rich interactive REPL for running VQL queries.
"""

import os
import sys
import json
from pathlib import Path
from typing import Optional, List, Any

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.lexers import PygmentsLexer, DynamicLexer
from prompt_toolkit.styles import Style
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.formatted_text import HTML
from pygments.lexer import RegexLexer, bygroups
from pygments.token import (
    Token, Keyword, Name, String, Number, Operator, Comment, Punctuation, Whitespace
)

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from rich.markdown import Markdown, Heading as _RichHeading
from rich import box


class _LeftAlignedHeading(_RichHeading):
    """Override Rich's default center-aligned markdown headings."""

    def __rich_console__(self, console, options):
        self.text.justify = "left"
        if self.tag == "h1":
            yield Panel(self.text, box=box.HEAVY, style="markdown.h1.border")
        else:
            if self.tag == "h2":
                yield Text("")
            yield self.text


# Patch Markdown to use left-aligned headings
Markdown.elements["heading_open"] = _LeftAlignedHeading

from .client import VeezooClient
from .models import Data, VqlQueryResult, SharedAnswerResult, QuestionResult, TextMessage, AnswerMessage
from .exceptions import VeezooError, VeezooApiError


# History file location
HISTORY_DIR = Path.home() / ".veezoo"
HISTORY_FILE = HISTORY_DIR / "history"


class VqlLexer(RegexLexer):
    """Pygments lexer for VQL syntax highlighting."""
    
    name = 'VQL'
    aliases = ['vql']
    
    tokens = {
        'root': [
            # Comments
            (r'//.*$', Comment.Single),
            (r'/\*.*?\*/', Comment.Multiline),
            
            # Keywords
            (r'\b(var|from|select|by|where|and|or|not|in|as|true|false|null)\b', Keyword),
            
            # Aggregation functions
            (r'\b(count|sum|avg|min|max|median|stddev|variance)\b', Name.Function),
            
            # Other functions
            (r'\b(complement_sort|sort|filter|limit|offset|distinct)\b', Name.Function),
            
            # KB reference
            (r'\b(kb)\b', Name.Namespace),
            
            # Numbers
            (r'\b\d+\.?\d*\b', Number),
            
            # Strings
            (r'"[^"]*"', String),
            (r"'[^']*'", String),
            
            # Operators
            (r'[=<>!]+', Operator),
            (r'[+\-*/]', Operator),
            
            # Punctuation
            (r'[(),.\[\]]', Punctuation),
            
            # Identifiers
            (r'[a-zA-Z_][a-zA-Z0-9_]*', Name),
            
            # Whitespace
            (r'\s+', Whitespace),
        ],
    }


class VqlCompleter(Completer):
    """Auto-completer for VQL queries."""
    
    KEYWORDS = [
        'var', 'from', 'select', 'by', 'where', 'and', 'or', 'not', 'in', 'as',
        'true', 'false', 'null', 'kb',
    ]
    
    FUNCTIONS = [
        'count', 'sum', 'avg', 'min', 'max', 'median', 'stddev', 'variance',
        'complement_sort', 'sort', 'filter', 'limit', 'offset', 'distinct',
    ]
    
    def get_completions(self, document, complete_event):
        """
        Yield completion suggestions for the current word in the document.
        
        Parameters:
            document: The prompt_toolkit document representing the current input buffer; used to find the word before the cursor.
            complete_event: The completion event (provided by prompt_toolkit); not required for suggestion selection.
        
        Returns:
            Yields `Completion` objects for each keyword or function whose name starts with the current word (case-insensitive). Each completion is positioned to replace the current word.
        """
        word = document.get_word_before_cursor()
        
        # Combine all completions
        all_words = self.KEYWORDS + self.FUNCTIONS
        
        for w in all_words:
            if w.startswith(word.lower()):
                yield Completion(
                    w,
                    start_position=-len(word),
                    style='class:completion',
                    selected_style='class:completion.selected',
                )


class InteractiveCompleter(Completer):
    """Mode-aware completer for interactive sessions."""

    DOT_COMMANDS = [
        '.ask',
        '.chart',
        '.clear',
        '.conversation',
        '.exit',
        '.export',
        '.format',
        '.help',
        '.history',
        '.kg',
        '.mode',
        '.new-conversation',
        '.q',
        '.query',
        '.quit',
        '.sql',
        '.vql',
    ]

    def __init__(self, get_mode):
        self._get_mode = get_mode
        self._vql_completer = VqlCompleter()

    def get_completions(self, document, complete_event):
        text_before_cursor = document.text_before_cursor.lstrip()

        if text_before_cursor.startswith('.'):
            command_prefix = text_before_cursor.lower()
            for command in self.DOT_COMMANDS:
                if command.startswith(command_prefix):
                    yield Completion(
                        command,
                        start_position=-len(text_before_cursor),
                        style='class:completion',
                        selected_style='class:completion.selected',
                    )
            return

        if self._get_mode() == "vql":
            yield from self._vql_completer.get_completions(document, complete_event)


# Custom style for prompt
PROMPT_STYLE = Style.from_dict({
    # Prompt
    'prompt': '#00aa00 bold',
    'prompt.kg': '#0088ff',
    'prompt.disconnected': '#ff0000',
    'prompt.mode': '#ffb86c',
    
    # VQL syntax highlighting
    'pygments.keyword': '#ff79c6 bold',
    'pygments.name.function': '#8be9fd',
    'pygments.name.namespace': '#ffb86c',
    'pygments.string': '#f1fa8c',
    'pygments.number': '#bd93f9',
    'pygments.comment': '#6272a4 italic',
    'pygments.operator': '#ff79c6',
    
    # Completion menu
    'completion': 'bg:#333333 #ffffff',
    'completion.selected': 'bg:#0066aa #ffffff',
})


class InteractiveSession:
    """Interactive VQL session."""
    
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        kg_id: Optional[str] = None,
    ):
        """
        Initialize an InteractiveSession.
        
        Parameters:
            api_key (str): API key used to create the Veezoo client.
            base_url (Optional[str]): Optional base URL for the API.
            kg_id (Optional[str]): Optional default Knowledge Graph id to use.
        
        The initializer sets up session state (client placeholder, console, default output format,
        last query/result tracking, and connection flag), ensures the persistent history directory exists,
        and creates a PromptSession configured with history, VQL lexer, completer, styling, multiline input,
        continuation prompt, and custom key bindings.
        """
        self.api_key = api_key
        self.base_url = base_url
        self.kg_id = kg_id
        self.client: Optional[VeezooClient] = None
        self.console = Console()
        self.output_format = "table"
        self.mode = "ask"  # Default to natural language questions
        self.auto_chart = True  # Auto-render charts below tables
        self.last_result: Optional[Any] = None
        self.last_sql: Optional[str] = None
        self.conversation_id: Optional[str] = None
        self.connected = False
        
        # Ensure history directory exists
        HISTORY_DIR.mkdir(parents=True, exist_ok=True)
        
        # Setup prompt session
        self._vql_lexer = PygmentsLexer(VqlLexer)
        self.session = PromptSession(
            history=FileHistory(str(HISTORY_FILE)),
            auto_suggest=AutoSuggestFromHistory(),
            lexer=DynamicLexer(lambda: self._vql_lexer if self.mode == "vql" else None),
            completer=InteractiveCompleter(lambda: self.mode),
            style=PROMPT_STYLE,
            multiline=True,
            prompt_continuation=self._get_continuation_prompt,
            key_bindings=self._create_key_bindings(),
        )
    
    def _create_key_bindings(self) -> KeyBindings:
        """
        Create prompt_toolkit key bindings to control REPL input and submission behavior.
        
        Configures context-sensitive bindings that:
        - submit dot-commands immediately,
        - submit single-line queries on Enter,
        - submit multi-line queries when the input ends with a blank line,
        - force execution with Ctrl+Enter,
        - execute with Escape+Enter,
        - exit the application with Ctrl+D.
        
        Returns:
            KeyBindings: A configured KeyBindings instance ready to attach to the prompt session.
        """
        from prompt_toolkit.filters import Condition
        
        kb = KeyBindings()
        
        @Condition
        def is_dot_command() -> bool:
            """Check if current input is a dot command."""
            from prompt_toolkit.application import get_app
            try:
                app = get_app()
                text = app.current_buffer.text.strip()
                return text.startswith('.')
            except Exception:
                return False
        
        @Condition
        def is_single_line_query() -> bool:
            """
            Determine whether the current prompt input is a single-line VQL query (contains no newline and does not start with a dot command).
            
            Returns:
                bool: True if the current buffer contains no newline characters and the trimmed text does not start with '.', False otherwise or if the application buffer is unavailable.
            """
            from prompt_toolkit.application import get_app
            try:
                app = get_app()
                text = app.current_buffer.text
                return '\n' not in text and not text.strip().startswith('.')
            except Exception:
                return False
        
        @Condition
        def ends_with_blank_line() -> bool:
            """
            Detect whether the current prompt input ends with a blank final line (a trailing empty line).
            
            Checks the prompt_toolkit current buffer and considers the input to end with a blank line if it ends with a newline or if the final line consists only of whitespace.
            
            Returns:
                bool: `True` if the current input has a blank final line, `False` otherwise.
            """
            from prompt_toolkit.application import get_app
            try:
                app = get_app()
                text = app.current_buffer.text
                # If text ends with newline and last line is empty/whitespace
                return text.endswith('\n') or text.rstrip() != text.rstrip('\n').rstrip()
            except Exception:
                return False
        
        @Condition 
        def is_multiline_query() -> bool:
            """
            Determine whether the current prompt buffer contains a multi-line VQL query.
            
            Considers the buffer a multi-line query when it contains at least one newline and does not start with a dot-command (a leading '.').
            Returns:
                `true` if the current buffer contains a newline and does not start with '.', `false` otherwise.
            """
            from prompt_toolkit.application import get_app
            try:
                app = get_app()
                text = app.current_buffer.text
                return '\n' in text and not text.strip().startswith('.')
            except Exception:
                return False
        
        @kb.add('enter', filter=is_dot_command)
        def handle_dot_command(event):
            """
            Execute a dot command immediately when Enter is pressed.
            
            Parameters:
                event: The prompt_toolkit key event whose current buffer will be validated and handled.
            """
            event.current_buffer.validate_and_handle()
        
        @kb.add('enter', filter=is_single_line_query)
        def handle_single_line(event):
            """
            Handle Enter for single-line VQL queries by validating and submitting the current input buffer.
            
            Parameters:
                event: The key binding event whose current_buffer will be validated and handled.
            """
            event.current_buffer.validate_and_handle()
        
        @kb.add('enter', filter=is_multiline_query & ends_with_blank_line)
        def handle_multiline_submit(event):
            """
            Trigger submission of the current multiline input when the user ends with a blank line.
            
            Calls validate and handle on the prompt_toolkit event's current buffer to validate the input and execute the submission.
            
            Parameters:
                event: The prompt_toolkit key binding event containing `current_buffer`.
            """
            event.current_buffer.validate_and_handle()
        
        # Ctrl+Enter to force execute (works in multi-line)
        @kb.add('c-j')
        def handle_ctrl_enter(event):
            """
            Execute the current input buffer (submit the current entry), used for the Ctrl+Enter key binding.
            
            Parameters:
                event: The prompt_toolkit key event whose current_buffer will be validated and handled.
            """
            event.current_buffer.validate_and_handle()
        
        # Escape then Enter also works
        @kb.add('escape', 'enter')
        def handle_escape_enter(event):
            """
            Execute the current input buffer when Escape followed by Enter is pressed.
            
            Parameters:
                event: The prompt_toolkit key event whose current_buffer will be validated and handled.
            """
            event.current_buffer.validate_and_handle()
        
        @kb.add('c-d')
        def handle_exit(event):
            """
            Exit the application when invoked by a key-binding event.
            
            Parameters:
                event: The prompt_toolkit key binding event that triggered this handler.
            """
            event.app.exit(exception=EOFError())
        
        return kb
    
    def _get_prompt(self) -> HTML:
        """
        Return the formatted prompt for the interactive session, reflecting connection and knowledge graph state.
        
        Returns:
            An HTML object containing the prompt text with styling that indicates whether the session is connected and shows the current knowledge graph id (or "no kg") when connected, or a disconnected prompt when not.
        """
        if self.connected:
            kg_part = f'<prompt.kg>{self.kg_id}</prompt.kg>' if self.kg_id else '<prompt.kg>no kg</prompt.kg>'
            mode_part = f'<prompt.mode>{self.mode}</prompt.mode>'
            return HTML(f'<prompt>veezoo</prompt> [{kg_part}|{mode_part}]> ')
        else:
            return HTML('<prompt.disconnected>veezoo</prompt.disconnected> [disconnected]> ')
    
    def _get_continuation_prompt(self, width, line_number, is_soft_wrap):
        """
        Create the continuation prompt string for multi-line input.
        
        Parameters:
            width (int): Available width for the continuation prompt (number of characters).
            line_number (int): Current line index within the multi-line input (starting at 1).
            is_soft_wrap (bool): True if the continuation is due to soft wrapping, False otherwise.
        
        Returns:
            str: A prompt string consisting of dots filling the given width minus one, followed by a space.
        """
        return '.' * (width - 1) + ' '
    
    def connect(self) -> bool:
        """
        Establishes a connection to the Veezoo API and verifies connectivity.
        
        On success stores a configured VeezooClient in `self.client` and sets `self.connected` to `True`; on failure leaves `self.connected` as `False`.
        
        Returns:
            True if the connection and ping succeeded, False otherwise.
        """
        try:
            self.client = VeezooClient(
                api_key=self.api_key,
                base_url=self.base_url,
            )
            self.client.ping()
            self.connected = True
            return True
        except VeezooError as e:
            self.console.print(f"[red]Connection failed:[/red] {e.message}")
            self.connected = False
            return False
    
    def print_welcome(self):
        """
        Render and print the interactive console welcome banner.
        
        Displays an ASCII-art logo, a version/tagline line, and a Quick Start panel with usage tips to the session console using rich styling.
        """
        from rich.align import Align
        
        # Build the colored logo as a single text block
        logo_text = Text()
        logo_data = [
            ("██╗   ██╗███████╗███████╗███████╗ ██████╗ ██████╗ \n", "bold #00FFFF"),
            ("██║   ██║██╔════╝██╔════╝╚══███╔╝██╔═══████╔═══██╗\n", "bold #00DDFF"),
            ("██║   ██║█████╗  █████╗    ███╔╝ ██║   ████║   ██║\n", "bold #00BBFF"),
            ("╚██╗ ██╔╝██╔══╝  ██╔══╝   ███╔╝  ██║   ████║   ██║\n", "bold #5599FF"),
            (" ╚████╔╝ ███████╗███████╗███████╗╚██████╔═██████╔╝\n", "bold #8877FF"),
            ("  ╚═══╝  ╚══════╝╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ", "bold #AA55FF"),
        ]
        
        for line, style in logo_data:
            logo_text.append(line, style=style)
        
        self.console.print()
        self.console.print(Align.center(logo_text))
        self.console.print()
        
        # Tagline section
        tagline = Text()
        tagline.append("═" * 17, style="dim cyan")
        tagline.append(" ✨ ", style="yellow")
        tagline.append("Interactive Query Console", style="bold white")
        tagline.append(" ✨ ", style="yellow")
        tagline.append("═" * 17, style="dim cyan")
        
        self.console.print(Align.center(tagline))
        
        from veezoo import __version__
        version = Text(f"v{__version__} │ Ask your data anything", style="dim")
        self.console.print(Align.center(version))
        self.console.print()
        
        # Quick start tips in a nice box
        tips = Text()
        tips.append("  [>] ", style="cyan")
        tips.append("Type a question", style="bold yellow")
        tips.append(" in ask mode (default), ", style="dim")
        tips.append(".mode", style="bold green")
        tips.append(" to toggle VQL mode\n", style="dim")
        tips.append("  [>] ", style="cyan")
        tips.append("Ctrl+R", style="bold yellow")
        tips.append(" search history, ", style="dim")
        tips.append("Ctrl+D", style="bold yellow")
        tips.append(" exit, ", style="dim")
        tips.append("Ctrl+J", style="bold yellow")
        tips.append(" submit multi-line\n", style="dim")
        tips.append("  [>] ", style="cyan")
        tips.append(".help", style="bold green")
        tips.append(" for commands, ", style="dim")
        tips.append(".kg <id>", style="bold green")
        tips.append(" to set knowledge graph", style="dim")
        
        self.console.print(Panel(
            tips,
            border_style="cyan",
            padding=(0, 1),
            title="[bold white]Quick Start[/bold white]",
            title_align="left",
        ))
        self.console.print()
    
    def print_help(self):
        """Print help message."""
        help_text = """
## Commands

| Command | Description |
|---------|-------------|
| `.help` | Show this help message |
| `.mode` | Toggle between `ask` (natural language) and `vql` modes |
| `.mode ask` | Switch to natural language question mode |
| `.mode vql` | Switch to VQL query mode |
| `.kg <id>` | Switch to a different Knowledge Graph |
| `.ask <question>` | Ask a natural language question (works in any mode) |
| `.query <vql>` | Run a VQL query (works in any mode) |
| `.conversation` | Show current conversation ID |
| `.new-conversation` | Start a new conversation |
| `.format <fmt>` | Set output format: `table`, `json`, or `csv` |
| `.chart` | Toggle auto-charting on/off |
| `.sql` | Show SQL from the last query |
| `.export <file>` | Export last result to file (auto-detects format) |
| `.clear` | Clear the screen |
| `.history` | Show command history |
| `.exit` / `.quit` | Exit interactive mode |

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Enter` | Execute input |
| `Alt+Enter` or `Esc → Enter` | Execute multi-line input |
| `Ctrl+R` | Search command history |
| `Ctrl+D` | Exit |
| `Ctrl+C` | Cancel current input |
| `Tab` | Auto-complete |

## Modes

- **ask** (default): Type natural language questions directly
- **vql**: Type VQL queries directly

## Example

In ask mode:
```
How many customers do we have?
```

In vql mode:
```
var customers from kb.Customer
select(count(customers))
```
"""
        self.console.print(Markdown(help_text))
    
    def handle_command(self, command: str) -> bool:
        """
        Process a dot-command entered in the interactive REPL and perform the corresponding action.
        
        Supported dot-commands include:
        - .exit, .quit, .q: exit the session
        - .help: display help text
        - .kg <id>: set or show the current Knowledge Graph id
        - .format <table|json|csv>: set or show the current output format
        - .sql: display generated SQL from the last query
        - .vql: display rewritten VQL from the last result
        - .export <file>: export the last query result to a file (JSON or CSV)
        - .clear: clear the console
        - .history: show recent command history
        
        @returns
            `True` to continue the interactive session, `False` to exit.
        """
        parts = command.strip().split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else None
        
        if cmd in ('.exit', '.quit', '.q'):
            return False
        
        elif cmd == '.help':
            self.print_help()
        
        elif cmd == '.kg':
            if arg:
                self.kg_id = arg
                self.conversation_id = None
                self.console.print(f"[green]✓[/green] Switched to Knowledge Graph: [cyan]{arg}[/cyan]")
            else:
                if self.kg_id:
                    self.console.print(f"Current Knowledge Graph: [cyan]{self.kg_id}[/cyan]")
                else:
                    self.console.print("[yellow]No Knowledge Graph selected. Use: .kg <id>[/yellow]")
        
        elif cmd == '.mode':
            if arg and arg.lower() in ('ask', 'vql'):
                self.mode = arg.lower()
                if self.mode == 'ask':
                    self.console.print("[green]✓[/green] Switched to [cyan]ask[/cyan] mode (natural language questions)")
                else:
                    self.console.print("[green]✓[/green] Switched to [cyan]vql[/cyan] mode (VQL queries)")
            elif arg:
                self.console.print(f"[red]Unknown mode:[/red] {arg}")
                self.console.print("[dim]Options: ask, vql[/dim]")
            else:
                # Toggle
                self.mode = 'vql' if self.mode == 'ask' else 'ask'
                if self.mode == 'ask':
                    self.console.print("[green]✓[/green] Switched to [cyan]ask[/cyan] mode (natural language questions)")
                else:
                    self.console.print("[green]✓[/green] Switched to [cyan]vql[/cyan] mode (VQL queries)")

        elif cmd == '.format':
            if arg and arg.lower() in ('table', 'json', 'csv'):
                self.output_format = arg.lower()
                self.console.print(f"[green]✓[/green] Output format set to: [cyan]{self.output_format}[/cyan]")
            else:
                self.console.print(f"Current format: [cyan]{self.output_format}[/cyan]")
                self.console.print("[dim]Options: table, json, csv[/dim]")

        elif cmd == '.chart':
            self.auto_chart = not self.auto_chart
            state = "on" if self.auto_chart else "off"
            self.console.print(f"[green]✓[/green] Auto-charting [cyan]{state}[/cyan]")

        elif cmd == '.sql':
            if self.last_sql:
                self.console.print()
                self.console.print(Panel(
                    Syntax(self.last_sql, "sql", theme="monokai"),
                    title="Generated SQL",
                    border_style="blue",
                ))
            else:
                self.console.print("[yellow]No SQL available from last query[/yellow]")

        elif cmd == '.query':
            if arg:
                self.execute_query(arg)
            else:
                self.console.print("[yellow]Usage: .query <vql>[/yellow]")

        elif cmd == '.vql':
            if self.last_result and hasattr(self.last_result, 'rewriting'):
                vql = self.last_result.rewriting.rewritten_vql
                if vql:
                    self.console.print()
                    self.console.print(Panel(
                        vql.strip(),
                        title="Rewritten VQL",
                        border_style="magenta",
                    ))
                else:
                    self.console.print("[yellow]No rewritten VQL available[/yellow]")
            else:
                self.console.print("[yellow]No VQL available from last query[/yellow]")
        
        elif cmd == '.export':
            if not arg:
                self.console.print("[yellow]Usage: .export <filename>[/yellow]")
            else:
                data = self._get_last_result_data()
                if data is None:
                    self.console.print("[yellow]No data to export[/yellow]")
                else:
                    self._export_data(arg, data)
        
        elif cmd == '.ask':
            if arg:
                self.ask_question(arg)
            else:
                self.console.print("[yellow]Usage: .ask <question>[/yellow]")

        elif cmd == '.conversation':
            if self.conversation_id:
                self.console.print(f"Current conversation: [cyan]{self.conversation_id}[/cyan]")
            else:
                self.console.print("[yellow]No active conversation[/yellow]")

        elif cmd == '.new-conversation':
            self.conversation_id = None
            self.console.print("[green]✓[/green] Started new conversation")

        elif cmd == '.clear':
            self.console.clear()
        
        elif cmd == '.history':
            self._show_history()
        
        else:
            self.console.print(f"[red]Unknown command:[/red] {cmd}")
            self.console.print("[dim]Type .help for available commands[/dim]")
        
        return True
    
    def _export_data(self, filename: str, data: Data):
        """
        Export query result data to a file supporting JSON and CSV formats.
        
        Parameters:
            filename (str): Path to the output file. The extension determines format: `.json` for JSON, `.csv` for CSV; any other extension defaults to CSV.
            data (Data): Result set to export; must provide `to_dicts()`, `column_names()`, and `rows` (row objects exposing `values()`).
        
        Behavior:
            Writes the serialized content to `filename`. On success prints a confirmation including the exported row count; on failure prints an error message.
        """
        path = Path(filename)
        ext = path.suffix.lower()
        
        try:
            if ext == '.json':
                content = json.dumps(data.to_dicts(), indent=2)
            elif ext == '.csv':
                import csv
                import io
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(data.column_names())
                for row in data.rows:
                    writer.writerow(row.values())
                content = output.getvalue()
            else:
                # Default to CSV
                import csv
                import io
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(data.column_names())
                for row in data.rows:
                    writer.writerow(row.values())
                content = output.getvalue()
            
            path.write_text(content)
            self.console.print(f"[green]✓[/green] Exported {len(data.rows)} rows to [cyan]{filename}[/cyan]")
        except Exception as e:
            self.console.print(f"[red]Export failed:[/red] {e}")

    def _get_last_result_data(self) -> Optional[Data]:
        """Return the latest exportable data from the last query or question result."""
        if not self.last_result:
            return None

        data = getattr(self.last_result, "data", None)
        if data is not None:
            return data

        if isinstance(self.last_result, QuestionResult):
            for msg in reversed(self.last_result.messages):
                if isinstance(msg, AnswerMessage) and msg.data is not None:
                    return msg.data

        return None
    
    def _show_history(self):
        """
        Display the most recent command history entries in the console.
        
        Reads HISTORY_FILE and prints up to the last 20 saved commands. Multi-line commands are shown on a single line with newlines replaced by " ↵ ". Each entry is truncated to 60 characters and suffixed with "..." when truncated. If no history file exists, prints a notice that there is no history.
        """
        if HISTORY_FILE.exists():
            lines = HISTORY_FILE.read_text().strip().split('\n')
            # Show last 20 entries
            recent = lines[-20:] if len(lines) > 20 else lines
            
            self.console.print()
            self.console.print("[bold]Recent Commands:[/bold]")
            for i, line in enumerate(recent, 1):
                # Clean up multi-line entries
                display = line.replace('\n', ' ↵ ')[:60]
                if len(line) > 60:
                    display += '...'
                self.console.print(f"  [dim]{i:3}[/dim]  {display}")
            self.console.print()
        else:
            self.console.print("[yellow]No history yet[/yellow]")
    
    def execute_query(self, vql: str):
        """
        Execute a VQL query against the currently selected Knowledge Graph and display the results.
        
        Parameters:
            vql (str): The VQL query string to execute.
        
        Notes:
            - If no Knowledge Graph is selected the query is not run and an error is printed.
            - Attempts to reconnect if the session is not connected; if reconnection fails the query is not run.
            - On success, updates `self.last_result` and `self.last_sql`, and outputs `result.data` via `_output_data`.
            - API and client errors are caught and printed (including request ID when available).
        """
        if not self.kg_id:
            self.console.print("[red]Error:[/red] No Knowledge Graph selected. Use [bold].kg <id>[/bold]")
            return
        
        if not self.connected or not self.client:
            self.console.print("[red]Error:[/red] Not connected. Reconnecting...")
            if not self.connect():
                return
        
        try:
            with self.console.status("[cyan]Running query...[/cyan]", spinner="dots"):
                result = self.client.run_vql_query(kg_id=self.kg_id, vql=vql)
            
            self.last_result = result
            self.last_sql = result.sql
            
            self._output_data(result.data)
            
        except VeezooApiError as e:
            self.console.print(f"[red]Error:[/red] {e.message}")
            if e.request_id:
                self.console.print(f"[dim]Request ID: {e.request_id}[/dim]")
        except VeezooError as e:
            self.console.print(f"[red]Error:[/red] {e.message}")
    
    def ask_question(self, question: str):
        """
        Ask a natural language question via the API.

        Parameters:
            question (str): The natural language question to ask.
        """
        if not self.kg_id:
            self.console.print("[red]Error:[/red] No Knowledge Graph selected. Use [bold].kg <id>[/bold]")
            return

        if not self.connected or not self.client:
            self.console.print("[red]Error:[/red] Not connected. Reconnecting...")
            if not self.connect():
                return

        try:
            with self.console.status("[cyan]Asking question...[/cyan]", spinner="dots"):
                result = self.client.ask(
                    kg_id=self.kg_id,
                    question=question,
                    conversation_id=self.conversation_id,
                )

            # Update conversation ID for follow-ups
            self.conversation_id = result.conversation_id
            self.last_result = result
            self.last_sql = None

            # Display messages in order
            for msg in result.messages:
                if isinstance(msg, TextMessage):
                    self.console.print()
                    self.console.print(Markdown(msg.content))
                elif isinstance(msg, AnswerMessage):
                    if msg.title:
                        self.console.print(f"\n[bold]{msg.title}[/bold]")
                    if msg.data is not None:
                        self._output_data(msg.data)
                    if msg.sql:
                        self.last_sql = msg.sql

            if result.is_error:
                self.console.print("[red]The response indicates an error[/red]")

        except VeezooApiError as e:
            self.console.print(f"[red]Error:[/red] {e.message}")
            if e.request_id:
                self.console.print(f"[dim]Request ID: {e.request_id}[/dim]")
        except VeezooError as e:
            self.console.print(f"[red]Error:[/red] {e.message}")

    def _output_data(self, data: Data):
        """
        Render the given Data object to the session console using the configured output format.
        
        Parameters:
            data (Data): Query result container. Expected to provide:
                - data.columns: sequence of column descriptors with a `name` attribute (used for table headers).
                - data.rows: sequence of row objects with an ordered set of values accessible via `values()`.
                - data.to_dicts(): list/dict representation used for JSON output.
        
        Notes:
            The session's `output_format` controls rendering: `"table"` (default) displays a formatted table,
            `"json"` prints pretty-printed JSON, and `"csv"` prints comma-separated values.
        """
        self.console.print()
        
        if self.output_format == "json":
            self.console.print(json.dumps(data.to_dicts(), indent=2))
        
        elif self.output_format == "csv":
            self.console.print(",".join(data.column_names()))
            for row in data.rows:
                self.console.print(",".join(row.values()))
        
        else:  # table
            if not data.rows:
                self.console.print("[dim]Result contains no data[/dim]")
                return
            
            table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
            
            for col in data.columns:
                table.add_column(col.name)
            
            for row in data.rows:
                table.add_row(*row.values())

            self.console.print(table)

        if len(data.rows) > 10:
            self.console.print(f"[dim]{len(data.rows)} rows[/dim]")

        # Auto-chart (only in table mode)
        if self.auto_chart and self.output_format == "table":
            try:
                from .charts import render_chart

                chart_str = render_chart(data)
                if chart_str:
                    self.console.print()
                    self.console.print(Text.from_ansi(chart_str))
            except Exception:
                pass
    
    def run(self):
        """
        Start and run the interactive REPL for VQL queries.
        
        Prints the welcome banner, attempts to connect to the API, and then enters a prompt loop that reads user input, handles dot-commands (for example `.exit`, `.kg`, `.help`), executes VQL queries, and responds to `Ctrl+C` by cancelling the current input and to EOF by terminating the session. Prints a goodbye message when the session ends.
        """
        self.print_welcome()
        
        # Try to connect
        with self.console.status("[cyan]Connecting to Veezoo...[/cyan]", spinner="dots"):
            self.connect()
        
        if self.connected:
            self.console.print("[green]✓[/green] Connected to Veezoo")
            if self.kg_id:
                self.console.print(f"[green]✓[/green] Knowledge Graph: [cyan]{self.kg_id}[/cyan]")
            else:
                self.console.print("[yellow]![/yellow] No Knowledge Graph selected. Use [bold].kg <id>[/bold]")
        
        self.console.print()
        
        # Main loop
        while True:
            try:
                # Get input
                text = self.session.prompt(self._get_prompt)
                
                if not text.strip():
                    continue
                
                # Handle dot-commands
                if text.strip().startswith('.'):
                    if not self.handle_command(text.strip()):
                        break
                    continue

                # Dispatch based on mode
                if self.mode == "ask":
                    self.ask_question(text.strip())
                else:
                    self.execute_query(text)
                
            except KeyboardInterrupt:
                self.console.print("[dim]Use .exit to quit[/dim]")
                continue
            except EOFError:
                break
        
        self.console.print("\n[dim]Goodbye![/dim]")


def run_interactive(
    api_key: str,
    base_url: Optional[str] = None,
    kg_id: Optional[str] = None,
):
    """
    Start an interactive REPL for running VQL queries against a Veezoo Knowledge Graph.
    
    Parameters:
        api_key (str): Veezoo API key used to authenticate the session.
        base_url (Optional[str]): Optional API base URL to override the default.
        kg_id (Optional[str]): Optional initial Knowledge Graph ID to select on start.
    """
    session = InteractiveSession(
        api_key=api_key,
        base_url=base_url,
        kg_id=kg_id,
    )
    session.run()