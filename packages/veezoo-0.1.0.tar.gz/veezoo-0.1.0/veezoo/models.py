"""
Veezoo SDK Data Models

Data classes representing Veezoo API responses.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict, TYPE_CHECKING
from enum import Enum

if TYPE_CHECKING:
    import pandas


class RewritingStage(str, Enum):
    """The stage of VQL rewriting."""

    SEMANTIC = "semantic"
    LOGIC = "logic"


@dataclass
class RewritingStep:
    """
    Represents a single step during VQL rewriting.

    Attributes:
        stage: The rewriting stage (semantic or logic)
        rule: The name of the rewriting rule applied
        rewritten_vql: The VQL after this rewriting step (if successful)
        error_message: Error message if the rewriting step failed
    """

    stage: RewritingStage
    rule: str
    rewritten_vql: Optional[str] = None
    error_message: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RewritingStep":
        """Create a RewritingStep from a dictionary."""
        return cls(
            stage=RewritingStage(data["stage"]),
            rule=data["rule"],
            rewritten_vql=data.get("rewrittenVql"),
            error_message=data.get("errorMessage"),
        )


@dataclass
class Rewriting:
    """
    Contains information about VQL rewriting.

    Attributes:
        steps: The sequence of rewriting steps applied
        rewritten_vql: The final rewritten VQL (if successful)
        error_message: Error message if rewriting failed
    """

    steps: List[RewritingStep] = field(default_factory=list)
    rewritten_vql: Optional[str] = None
    error_message: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Rewriting":
        """
        Construct a Rewriting instance from a dictionary representation.
        
        Parameters:
            data (Dict[str, Any]): Dictionary with optional keys:
                - "steps": list of rewriting step dictionaries (defaults to empty list)
                - "rewrittenVql": optional final rewritten VQL string
                - "errorMessage": optional error message string
        
        Returns:
            Rewriting: An instance populated from the provided dictionary.
        """
        return cls(
            steps=[RewritingStep.from_dict(s) for s in data.get("steps", [])],
            rewritten_vql=data.get("rewrittenVql"),
            error_message=data.get("errorMessage"),
        )


@dataclass
class Cell:
    """
    Represents a data cell holding a single value.

    Attributes:
        value: The value of the cell as a string
    """

    value: str

    @classmethod
    def from_raw(cls, value: str) -> "Cell":
        """
        Construct a Cell from a raw string value.

        Parameters:
            value (str): The string value for the cell.

        Returns:
            Cell: A new Cell instance.
        """
        return cls(value=value)

    def __str__(self) -> str:
        """
        Provide the cell's string value.
        
        Returns:
            str: The cell's value.
        """
        return self.value

    def as_int(self) -> int:
        """
        Parse the cell's string value into an integer.
        
        Returns:
            int: The integer parsed from the cell's value.
        """
        return int(self.value)

    def as_float(self) -> float:
        """
        Convert the cell's value to a float.
        
        Returns:
            float: The parsed floating-point number.
        """
        return float(self.value)

    def as_bool(self) -> bool:
        """
        Determine whether the cell's value represents truth.
        
        Returns:
            `true` if the cell value (case-insensitive) is one of "true", "1", or "yes", `false` otherwise.
        """
        return self.value.lower() in ("true", "1", "yes")


@dataclass
class Column:
    """
    Represents a data column.

    Attributes:
        name: The name of the column
    """

    name: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Column":
        """
        Construct a Column instance from a dictionary.
        
        Parameters:
            data (Dict[str, Any]): Dictionary containing the column data; must include the key "name".
        
        Returns:
            Column: A new Column with `name` taken from `data["name"]`.
        """
        return cls(name=data["name"])


@dataclass
class Row:
    """
    Represents a data row.

    Attributes:
        cells: The cells in the row, in column order
    """

    cells: List[Cell]

    @classmethod
    def from_list(cls, data: List[str]) -> "Row":
        """
        Create a Row from a list of string values.

        Parameters:
            data (List[str]): List of string values, one per column.

        Returns:
            Row: Row instance containing Cell objects wrapping each value.
        """
        return cls(cells=[Cell.from_raw(v) for v in data])

    def __getitem__(self, index: int) -> Cell:
        """
        Retrieve the cell at the specified column index within the row.
        
        Parameters:
        	index (int): Zero-based column index; negative indices are supported.
        
        Returns:
        	Cell: The cell located at the given index.
        
        Raises:
        	IndexError: If the index is out of range for this row's cells.
        """
        return self.cells[index]

    def __len__(self) -> int:
        """
        Get the number of cells in the row.
        
        Returns:
            count (int): Number of cells in the row.
        """
        return len(self.cells)

    def __iter__(self):
        """
        Iterate over the row's cells.
        
        Returns:
            iterator (Iterator[Cell]): An iterator yielding the Row's Cell objects in order.
        """
        return iter(self.cells)

    def values(self) -> List[str]:
        """Get all cell values as strings."""
        return [cell.value for cell in self.cells]


@dataclass
class Data:
    """
    Contains the data returned by Veezoo.

    The data is structured as a table with column definitions and rows.

    Attributes:
        columns: The data columns
        rows: The data rows

    Example:
        >>> result = client.run_vql_query("my-kg", "select count(kb.Customer)")
        >>> for row in result.data:
        ...     print(row.values())
        ['1234']
    """

    columns: List[Column]
    rows: List[Row]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Data":
        """
        Create a Data object from a dictionary.
        
        Parameters:
            data (Dict[str, Any]): Dictionary that may contain:
                - "columns": a list of column dictionaries (each accepted by Column.from_dict).
                - "rows": a list of row representations (each accepted by Row.from_list).
        
        Returns:
            Data: Constructed Data instance with parsed columns and rows.
        """
        return cls(
            columns=[Column.from_dict(c) for c in data.get("columns", [])],
            rows=[Row.from_list(r) for r in data.get("rows", [])],
        )

    def __len__(self) -> int:
        """
        Number of rows in the data.
        
        Returns:
            int: Number of rows.
        """
        return len(self.rows)

    def __iter__(self):
        """Iterate over rows."""
        return iter(self.rows)

    def column_names(self) -> List[str]:
        """
        Return the list of column names in order.
        
        Returns:
            List[str]: Column names from the data's columns, in the same order they appear.
        """
        return [col.name for col in self.columns]

    def to_list(self) -> List[List[str]]:
        """
        Return the table as a list of rows, where each row is a list of cell string values.
        
        Returns:
            List[List[str]]: Rows of the table as lists of strings, in the same column order as the Data.columns.
        """
        return [row.values() for row in self.rows]

    def to_dicts(self) -> List[Dict[str, str]]:
        """
        Convert the table to a list of dictionaries mapping column names to cell values.
        
        Returns:
            List[Dict[str, str]]: A list where each element represents a row; keys are column names and values are the row's cell string values.
        """
        return [
            {col.name: cell.value for col, cell in zip(self.columns, row.cells)}
            for row in self.rows
        ]

    def to_dataframe(self, infer_types: bool = True) -> "pandas.DataFrame":
        """
        Convert this Data to a pandas DataFrame.
        
        Parameters:
            infer_types (bool): If True, attempt to coerce columns to numeric types when all non-missing
                values can be represented as numbers. If False, keep all columns as strings.
        
        Returns:
            pandas.DataFrame: DataFrame containing the tabular data.
        
        Raises:
            ImportError: If pandas is not installed. Install with `pip install veezoo[pandas]` or `pip install pandas`.
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for to_dataframe(). "
                "Install it with: pip install veezoo[pandas] or pip install pandas"
            )

        # Create DataFrame from dictionaries
        df = pd.DataFrame(self.to_dicts())

        # Optionally infer numeric types
        if infer_types and not df.empty:
            for col in df.columns:
                # Try to convert to numeric using coerce, which sets non-numeric to NaN
                numeric_col = pd.to_numeric(df[col], errors="coerce")
                # Only use numeric conversion if all values converted successfully
                # (no NaN values that weren't NaN in the original)
                if not numeric_col.isna().any() or df[col].isna().any():
                    # Check if we actually have numeric data (not all NaN from failed conversion)
                    if not numeric_col.isna().all():
                        df[col] = numeric_col

        return df


@dataclass
class VqlQueryResult:
    """
    The result of a VQL query.

    Attributes:
        type: The API resource type ("VqlQueryResult")
        rewriting: Information about VQL rewriting applied
        sql: The generated SQL query (may be None)
        data: The query result data
    """

    type: str
    rewriting: Rewriting
    data: Data
    sql: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VqlQueryResult":
        """
        Constructs a VqlQueryResult from a dictionary representation.
        
        Parameters:
            data (Dict[str, Any]): Dictionary with keys "type", "rewriting", and "data". "rewriting" is parsed via Rewriting.from_dict and "data" via Data.from_dict. Optional key "sql" may be included.
        
        Returns:
            VqlQueryResult: Instance populated from the provided dictionary.
        """
        return cls(
            type=data["type"],
            rewriting=Rewriting.from_dict(data["rewriting"]),
            data=Data.from_dict(data["data"]),
            sql=data.get("sql"),
        )


@dataclass
class TextMessage:
    """
    A text message in a question response.

    Attributes:
        type: Always "text"
        content: The markdown-formatted text content
    """

    type: str
    content: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TextMessage":
        """Create a TextMessage from a dictionary."""
        return cls(
            type="text",
            content=data.get("content", ""),
        )


@dataclass
class AnswerMessage:
    """
    An executed answer message with its data and query details.

    Attributes:
        type: Always "answer"
        title: What Veezoo understood for this specific answer (may be None)
        data: Structured tabular data (may be None)
        vql: The generated VQL query (may be None)
        sql: The generated SQL query (may be None)
        filters: Applied filters as strings
        error_message: Explanation of why this answer is partial (may be None)
    """

    type: str
    title: Optional[str]
    data: Optional[Data]
    vql: Optional[str]
    sql: Optional[str]
    filters: List[str]
    error_message: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnswerMessage":
        """Create an AnswerMessage from a dictionary."""
        raw_data = data.get("data")
        data_obj = Data.from_dict(raw_data) if raw_data is not None else None
        return cls(
            type="answer",
            title=data.get("title"),
            data=data_obj,
            vql=data.get("vql"),
            sql=data.get("sql"),
            filters=data.get("filters", []),
            error_message=data.get("errorMessage"),
        )


# Union type for API messages
Message = Any  # TextMessage | AnswerMessage (Python 3.10+ union not used for compat)


def parse_message(data: Dict[str, Any]) -> Any:
    """Parse an API message dict into the appropriate message type based on the 'type' field."""
    msg_type = data.get("type", "")
    if msg_type == "text":
        return TextMessage.from_dict(data)
    elif msg_type == "answer":
        return AnswerMessage.from_dict(data)
    raise ValueError(f"Unknown API message type: {msg_type!r} in payload {data!r}")


@dataclass
class QuestionResult:
    """
    The overall result of asking a natural language question.

    Attributes:
        type: The API resource type ("QuestionResult")
        conversation_id: The conversation ID, always returned for use in follow-up questions
        messages: Ordered sequence of text and answer messages, preserving the natural flow
        is_error: Whether the response represents an error
    """

    type: str
    conversation_id: str
    messages: List[Any]
    is_error: bool

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QuestionResult":
        """
        Create a QuestionResult from a dictionary.

        Parameters:
            data (Dict[str, Any]): Dictionary containing the result fields.

        Returns:
            QuestionResult: Instance populated from the provided dictionary.
        """
        return cls(
            type=data.get("type", "QuestionResult"),
            conversation_id=data["conversationId"],
            messages=[parse_message(m) for m in data.get("messages", [])],
            is_error=data.get("isError", False),
        )


@dataclass
class SharedAnswerResult:
    """
    The result of a shared answer execution.

    Attributes:
        type: The API resource type ("SharedAnswerResult")
        vql: The non-rewritten VQL of the shared answer (may be None)
        rewriting: Information about VQL rewriting applied
        sql: The generated SQL query (may be None)
        data: The query result data
    """

    type: str
    rewriting: Rewriting
    data: Data
    vql: Optional[str] = None
    sql: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SharedAnswerResult":
        """
        Construct a SharedAnswerResult from a dictionary representation.
        
        Parameters:
            data (Dict[str, Any]): Dictionary containing the SharedAnswerResult fields. Expected keys:
                - "type": resource type string
                - "rewriting": dict describing rewriting (passed to Rewriting.from_dict)
                - "data": dict containing tabular data (passed to Data.from_dict)
                - "vql" (optional): original VQL string
                - "sql" (optional): generated SQL string
        
        Returns:
            SharedAnswerResult: Instance populated from the given dictionary.
        """
        return cls(
            type=data["type"],
            rewriting=Rewriting.from_dict(data["rewriting"]),
            data=Data.from_dict(data["data"]),
            vql=data.get("vql"),
            sql=data.get("sql"),
        )