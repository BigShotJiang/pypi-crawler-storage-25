"""
Veezoo CLI chart rendering.

Auto-detects a sensible chart type from query result data and renders it
using plotext. All chart logic is encapsulated here so that callers only
need to call render_chart(data).

plotext is an optional dependency -- if it is not installed, render_chart()
returns None and no error is raised.
"""

import math
import os
import re
from typing import Optional, List, Tuple

from .models import Data

try:
    import plotext as plt

    HAS_PLOTEXT = True
except ImportError:
    HAS_PLOTEXT = False


# ---------------------------------------------------------------------------
# Value-type helpers
# ---------------------------------------------------------------------------

_DATE_PATTERNS = [
    re.compile(r"^\d{4}-\d{2}-\d{2}$"),  # YYYY-MM-DD
    re.compile(r"^\d{4}-\d{2}$"),  # YYYY-MM
    re.compile(r"^(19|20)\d{2}$"),  # YYYY (1900-2099 only)
    re.compile(r"^\d{2}/\d{2}/\d{4}$"),  # MM/DD/YYYY
    re.compile(r"^\d{2}\.\d{2}\.\d{4}$"),  # DD.MM.YYYY
    re.compile(r"^\d{4}-\d{2}-\d{2}T"),  # ISO 8601 datetime prefix
    re.compile(r"^Q[1-4]\s*\d{4}$"),  # Q1 2024
    re.compile(r"^\d{4}\s*Q[1-4]$"),  # 2024 Q1
]

_MAX_CHART_ROWS = 2499
_MAX_VERTICAL_BAR_ROWS = 12
_MAX_HORIZONTAL_BAR_ROWS = 40
_MAX_GROUPED_BAR_ROWS = 15
_MAX_X_TICKS = 8
_MAX_CATEGORY_LABEL_LENGTH = 28
_MAX_TICK_LABEL_LENGTH = 16
_DEFAULT_MARKER = "fhd"
_DEFAULT_COLOR = "cyan"
_SECONDARY_COLORS = ["grey", "darkgray"]


def _is_numeric(value: str) -> bool:
    """Return True if *value* can be parsed as a float."""
    try:
        float(value.replace(",", ""))
        return True
    except (ValueError, AttributeError):
        return False


def _is_date(value: str) -> bool:
    """Return True if *value* looks like a date or time period."""
    v = value.strip()
    return any(p.match(v) for p in _DATE_PATTERNS)


def _parse_number(value: str) -> float:
    """Parse a numeric string, stripping thousands-separator commas."""
    return float(value.replace(",", ""))


def _sanitize_label(value: str, max_length: int = _MAX_CATEGORY_LABEL_LENGTH) -> str:
    """Normalize chart labels to stay readable in a terminal."""
    label = (value or "").strip() or "(blank)"
    if len(label) <= max_length:
        return label
    return f"{label[: max_length - 3].rstrip()}..."


def _truncate_decimals(value: float, decimals: int) -> float:
    """Truncate a float toward zero to avoid overstating tick labels."""
    factor = 10**decimals
    if value >= 0:
        return math.floor(value * factor) / factor
    return math.ceil(value * factor) / factor


def _compact_number(value: float) -> str:
    """Format numeric axis labels compactly for terminal charts."""
    abs_value = abs(value)
    if abs_value >= 1_000_000:
        suffix = "M"
        scaled = value / 1_000_000
    elif abs_value >= 1_000:
        suffix = "k"
        scaled = value / 1_000
    else:
        suffix = ""
        scaled = value

    if suffix:
        if abs(scaled) >= 100:
            truncated = _truncate_decimals(scaled, 0)
            return f"{truncated:.0f}{suffix}"
        if abs(scaled) >= 10:
            truncated = _truncate_decimals(scaled, 1)
            return f"{truncated:.1f}".rstrip("0").rstrip(".") + suffix
        truncated = _truncate_decimals(scaled, 2)
        return f"{truncated:.2f}".rstrip("0").rstrip(".") + suffix

    if float(value).is_integer():
        return str(int(value))
    if abs_value >= 10:
        truncated = _truncate_decimals(value, 1)
        return f"{truncated:.1f}".rstrip("0").rstrip(".")
    truncated = _truncate_decimals(value, 2)
    return f"{truncated:.2f}".rstrip("0").rstrip(".")


def _numeric_ticks(values: List[float], count: int = 4) -> Tuple[List[float], List[str]]:
    """Build compact tick positions and labels for a numeric axis."""
    if not values:
        return [0.0], ["0"]

    minimum = min(values)
    maximum = max(values)

    if minimum == maximum:
        tick = float(minimum)
        return [tick], [_compact_number(tick)]

    start = minimum if minimum < 0 else 0.0
    span = maximum - start
    if span <= 0:
        ticks = [start, maximum]
    else:
        steps = max(count - 1, 1)
        ticks = [start + (span * i / steps) for i in range(steps + 1)]

    rounded_ticks: List[float] = []
    labels: List[str] = []
    for tick in ticks:
        normalized = 0.0 if abs(tick) < 1e-9 else tick
        if rounded_ticks and math.isclose(normalized, rounded_ticks[-1], rel_tol=1e-9, abs_tol=1e-9):
            continue
        rounded_ticks.append(normalized)
        labels.append(_sanitize_label(_compact_number(normalized), _MAX_TICK_LABEL_LENGTH))

    return rounded_ticks, labels


def _sample_ticks(labels: List[str], max_ticks: int = _MAX_X_TICKS) -> Tuple[List[int], List[str]]:
    """Sample category labels so line charts stay readable."""
    if len(labels) <= max_ticks:
        positions = list(range(len(labels)))
    else:
        steps = max_ticks - 1
        positions = sorted(
            {
                round(i * (len(labels) - 1) / steps)
                for i in range(max_ticks)
            }
        )

    sampled_labels = [_sanitize_label(labels[idx], _MAX_TICK_LABEL_LENGTH) for idx in positions]
    return positions, sampled_labels


def _series_values(data: Data, column_idx: int) -> List[float]:
    """Parse one numeric series from the table, falling back to 0.0."""
    values: List[float] = []
    for row in data.rows:
        try:
            values.append(_parse_number(row.cells[column_idx].value))
        except (ValueError, IndexError):
            values.append(0.0)
    return values


# ---------------------------------------------------------------------------
# Column classification
# ---------------------------------------------------------------------------


def _classify_columns(data: Data) -> Tuple[List[int], List[int], List[int]]:
    """Classify columns into label, numeric, and date indices.

    Samples up to the first 10 rows to decide each column's type.
    Numeric takes priority over date (pure numbers are not dates).

    Returns:
        (label_indices, numeric_indices, date_indices)
    """
    sample = data.rows[: min(10, len(data.rows))]
    label_cols: List[int] = []
    numeric_cols: List[int] = []
    date_cols: List[int] = []

    for col_idx in range(len(data.columns)):
        values = [row.cells[col_idx].value for row in sample if row.cells[col_idx].value]
        if not values:
            label_cols.append(col_idx)
            continue

        num_numeric = sum(1 for v in values if _is_numeric(v))
        num_date = sum(1 for v in values if _is_date(v))

        # If most values match a date pattern, prefer date even if they're numeric
        # (e.g. years like "2020", "2021" are both numeric and date-like)
        if num_date > len(values) / 2:
            date_cols.append(col_idx)
        elif num_numeric > len(values) / 2:
            numeric_cols.append(col_idx)
        else:
            label_cols.append(col_idx)

    return label_cols, numeric_cols, date_cols


# ---------------------------------------------------------------------------
# Chart type detection
# ---------------------------------------------------------------------------

_CHART_BAR = "bar"
_CHART_HBAR = "hbar"
_CHART_LINE = "line"
_CHART_GROUPED_BAR = "grouped_bar"


def _detect_chart_type(data: Data) -> Optional[str]:
    """Return the best chart type for *data*, or None if no chart is appropriate."""
    n_rows = len(data.rows)
    n_cols = len(data.columns)

    # Scalars or empty results: no chart
    if n_rows < 2 or n_cols < 2:
        return None

    # Too many rows: no chart
    if n_rows > _MAX_CHART_ROWS:
        return None

    label_cols, numeric_cols, date_cols = _classify_columns(data)

    # 1 date col + 1-2 numeric cols -> line chart
    if len(date_cols) == 1 and 1 <= len(numeric_cols) <= 2 and n_rows >= 3:
        return _CHART_LINE

    # 1 label col + 1 numeric col
    if (len(label_cols) == 1 or len(date_cols) == 1) and len(numeric_cols) == 1:
        if n_rows <= _MAX_VERTICAL_BAR_ROWS:
            return _CHART_BAR
        if n_rows <= _MAX_HORIZONTAL_BAR_ROWS:
            return _CHART_HBAR
        return None

    # 1 label col + 2-3 numeric cols -> grouped bar
    if (len(label_cols) == 1 or len(date_cols) == 1) and 2 <= len(numeric_cols) <= 3:
        if n_rows <= _MAX_GROUPED_BAR_ROWS:
            return _CHART_GROUPED_BAR
        return None

    return None


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------


def _terminal_width() -> int:
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80


def _setup_plot(height: int = 15) -> None:
    """Clear figure and apply common settings."""
    plt.clear_figure()
    plt.theme("clear")
    width = max(50, min(_terminal_width() - 4, 120))
    plt.plotsize(width, max(8, height))


def _label_col_index(data: Data) -> int:
    """Return the index of the first label/date column."""
    label_cols, _, date_cols = _classify_columns(data)
    if label_cols:
        return label_cols[0]
    if date_cols:
        return date_cols[0]
    return 0


def _render_bar(data: Data) -> Optional[str]:
    """Render a vertical bar chart for 1 label/date + 1 numeric column."""
    _, numeric_cols, _ = _classify_columns(data)
    label_idx = _label_col_index(data)
    num_idx = numeric_cols[0]

    labels = [_sanitize_label(row.cells[label_idx].value) for row in data.rows]
    values = _series_values(data, num_idx)

    _setup_plot(height=15)
    plt.bar(labels, values, marker=_DEFAULT_MARKER, color=_DEFAULT_COLOR)
    plt.grid(horizontal=True, vertical=False)
    plt.ylabel(data.columns[num_idx].name)

    ticks, tick_labels = _numeric_ticks(values)
    plt.yticks(ticks, tick_labels)
    return plt.build()


def _render_hbar(data: Data) -> Optional[str]:
    """Render a horizontal bar chart for 1 label/date + 1 numeric column."""
    _, numeric_cols, _ = _classify_columns(data)
    label_idx = _label_col_index(data)
    num_idx = numeric_cols[0]

    labels = [_sanitize_label(row.cells[label_idx].value) for row in data.rows]
    values = _series_values(data, num_idx)

    _setup_plot(height=max(len(labels) + 4, 10))
    plt.bar(
        labels,
        values,
        orientation="horizontal",
        marker=_DEFAULT_MARKER,
        width=0.8,
        color=_DEFAULT_COLOR,
    )
    plt.grid(horizontal=False, vertical=True)
    plt.xlabel(data.columns[num_idx].name)

    ticks, tick_labels = _numeric_ticks(values)
    plt.xticks(ticks, tick_labels)
    return plt.build()

def _render_line(data: Data) -> Optional[str]:
    """Render a line chart for 1 date/label column + 1-2 numeric columns."""
    _, numeric_cols, date_cols = _classify_columns(data)
    date_idx = date_cols[0] if date_cols else 0

    x_labels = [row.cells[date_idx].value for row in data.rows]
    x_nums = list(range(len(x_labels)))

    _setup_plot(height=12)
    all_values: List[float] = []

    for num_idx in numeric_cols[:2]:
        values = _series_values(data, num_idx)
        all_values.extend(values)
        color = _DEFAULT_COLOR if num_idx == numeric_cols[0] else _SECONDARY_COLORS[0]
        plt.plot(
            x_nums,
            values,
            label=data.columns[num_idx].name,
            marker=_DEFAULT_MARKER,
            color=color,
        )

    positions, sampled_labels = _sample_ticks(x_labels)
    plt.xticks(positions, sampled_labels)
    plt.xlabel(data.columns[date_idx].name)
    plt.grid(horizontal=True, vertical=False)

    ticks, tick_labels = _numeric_ticks(all_values)
    plt.yticks(ticks, tick_labels)

    return plt.build()


def _render_grouped_bar(data: Data) -> Optional[str]:
    """Render a grouped bar chart for 1 label + 2-3 numeric columns."""
    _, numeric_cols, _ = _classify_columns(data)
    label_idx = _label_col_index(data)

    labels = [_sanitize_label(row.cells[label_idx].value) for row in data.rows]
    series_values = [_series_values(data, num_idx) for num_idx in numeric_cols[:3]]
    series_labels = [data.columns[num_idx].name for num_idx in numeric_cols[:3]]
    series_colors = [_DEFAULT_COLOR, *_SECONDARY_COLORS][: len(series_values)]
    _setup_plot(height=15)
    plt.multiple_bar(
        labels,
        series_values,
        labels=series_labels,
        marker=_DEFAULT_MARKER,
        color=series_colors,
    )
    plt.grid(horizontal=True, vertical=False)

    all_values = [value for values in series_values for value in values]
    ticks, tick_labels = _numeric_ticks(all_values)
    plt.yticks(ticks, tick_labels)

    return plt.build()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_RENDERERS = {
    _CHART_BAR: _render_bar,
    _CHART_HBAR: _render_hbar,
    _CHART_LINE: _render_line,
    _CHART_GROUPED_BAR: _render_grouped_bar,
}


def render_chart(data: Data) -> Optional[str]:
    """Detect the best chart type for *data* and return it as an ANSI string.

    Returns None if:
    - plotext is not installed
    - the data shape does not match any chart heuristic
    - rendering fails for any reason
    """
    if not HAS_PLOTEXT:
        return None

    chart_type = _detect_chart_type(data)
    if chart_type is None:
        return None

    renderer = _RENDERERS.get(chart_type)
    if renderer is None:
        return None

    try:
        return renderer(data)
    except Exception:
        return None
