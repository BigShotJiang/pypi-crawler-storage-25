"""
Veezoo CLI

A command-line interface for the Veezoo API.
"""

import json
import os
import sys
from pathlib import Path
from typing import Optional

import click

from .client import VeezooClient
from .exceptions import VeezooError, VeezooApiError
from .models import Data

# Try to import rich for beautiful output, fall back to basic output
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.text import Text
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

# Configuration file location
CONFIG_DIR = Path.home() / ".veezoo"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Environment variable names
ENV_API_KEY = "VEEZOO_API_KEY"
ENV_BASE_URL = "VEEZOO_BASE_URL"
ENV_KG_ID = "VEEZOO_KG_ID"


def get_console() -> "Console":
    """
    Provide a Rich Console when the Rich library is available; otherwise return None.
    
    @returns A Rich Console instance if Rich is installed, `None` otherwise.
    """
    if HAS_RICH:
        return Console()
    return None


def load_config() -> dict:
    """
    Load the CLI configuration from the config file if it exists and contains valid JSON.
    
    Returns:
        dict: Parsed configuration mapping; an empty dict if the config file does not exist or cannot be read/parsed.
    """
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    return {}


def save_config(config: dict) -> None:
    """
    Persist the CLI configuration to the user's config file and set restrictive file permissions.
    
    Parameters:
        config (dict): Configuration mapping to save. Expected keys include `api_key`, `base_url`, and `kg_id` (any or all may be present).
    
    Notes:
        - Ensures the configuration directory exists, writes the JSON config to the configured file path, and sets file permissions to 0o600 to protect the API key.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    # Set restrictive permissions on config file (contains API key)
    CONFIG_FILE.chmod(0o600)


def get_api_key(ctx_api_key: Optional[str] = None) -> Optional[str]:
    """
    Resolve the API key from CLI option, environment variable, or saved config in that priority.
    
    Parameters:
        ctx_api_key (Optional[str]): API key provided via the CLI option; if set, it takes precedence.
    
    Returns:
        Optional[str]: The resolved API key string if found, otherwise `None`.
    """
    # 1. Command line option
    if ctx_api_key:
        return ctx_api_key
    # 2. Environment variable
    if os.environ.get(ENV_API_KEY):
        return os.environ[ENV_API_KEY]
    # 3. Config file
    config = load_config()
    return config.get("api_key")


def get_base_url(ctx_base_url: Optional[str] = None) -> Optional[str]:
    """
    Resolve the API base URL from the highest-priority available source.
    
    Parameters:
        ctx_base_url (Optional[str]): Base URL provided via the CLI option; if present it takes precedence.
    
    Returns:
        str or None: The resolved base URL from the CLI option, the environment, or the saved config, or `None` if no source provides one.
    """
    # 1. Command line option
    if ctx_base_url:
        return ctx_base_url
    # 2. Environment variable
    if os.environ.get(ENV_BASE_URL):
        return os.environ[ENV_BASE_URL]
    # 3. Config file
    config = load_config()
    return config.get("base_url")


def get_kg_id(ctx_kg_id: Optional[str] = None) -> Optional[str]:
    """
    Resolve the Knowledge Graph ID using the following priority: CLI option, environment variable, then saved config.
    
    Parameters:
    	ctx_kg_id (str | None): Optional KG ID provided via the CLI context or command option.
    
    Returns:
    	str | None: The resolved KG ID string if present, otherwise None.
    """
    # 1. Command line option
    if ctx_kg_id:
        return ctx_kg_id
    # 2. Environment variable
    if os.environ.get(ENV_KG_ID):
        return os.environ[ENV_KG_ID]
    # 3. Config file
    config = load_config()
    return config.get("kg_id")


def create_client(api_key: str, base_url: Optional[str] = None) -> VeezooClient:
    """
    Builds a VeezooClient configured with the provided API key and optional base URL.
    
    Parameters:
        api_key (str): API key used to authenticate requests.
        base_url (Optional[str]): Optional base URL to override the client's default API endpoint.
    
    Returns:
        VeezooClient: A client instance configured with the given credentials and base URL (if provided).
    """
    kwargs = {"api_key": api_key}
    if base_url:
        kwargs["base_url"] = base_url
    return VeezooClient(**kwargs)


def print_error(message: str, console: Optional["Console"] = None) -> None:
    """
    Display an error message to the user.
    
    When a Rich Console is provided and Rich is available, prints a styled error message to that console; otherwise writes plain text to stderr.
    
    Parameters:
        message (str): The error message to display.
        console (Optional[Console]): Optional Rich Console used for styled output when available.
    """
    if console and HAS_RICH:
        console.print(Text.assemble(("Error: ", "bold red"), message))
    else:
        click.echo(f"Error: {message}", err=True)


def print_success(message: str, console: Optional["Console"] = None) -> None:
    """
    Display a success message to the user.
    
    If a Rich Console is provided and Rich is available, the message is rendered with a green checkmark and styling; otherwise the message is printed to standard output with a plain checkmark.
    
    Parameters:
        message (str): The success text to display.
        console (Optional[Console]): Optional Rich Console for styled output; if omitted or Rich is unavailable, falls back to plain output.
    """
    if console and HAS_RICH:
        console.print(Text.assemble(("✓ ", "bold green"), message))
    else:
        click.echo(f"✓ {message}")


def print_warning(message: str, console: Optional["Console"] = None) -> None:
    """
    Display a warning message to the user.
    
    Parameters:
        message (str): The warning text to display.
        console (Optional[Console]): Optional Rich Console to render styled output; if not provided or Rich is unavailable, the message is written to stderr.
    """
    if console and HAS_RICH:
        console.print(Text.assemble(("Warning: ", "bold yellow"), message))
    else:
        click.echo(f"Warning: {message}", err=True)


def format_data_as_table(data: Data, console: "Console") -> None:
    """
    Render a Data object as a table to the given Console, using Rich formatting when available and a simple tab-separated fallback otherwise.
    
    Parameters:
        data (Data): Result set containing column metadata and rows. Expected to expose `columns` (items with `name`), `rows` (iterable of row objects with a `values()` method), and `column_names()` used by the fallback.
        console (Console): Rich Console used for formatted output when Rich is available.
    """
    if not HAS_RICH:
        # Fallback to simple output
        click.echo("\t".join(data.column_names()))
        for row in data.rows:
            click.echo("\t".join(row.values()))
        return

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    
    # Add columns
    for col in data.columns:
        table.add_column(col.name)
    
    # Add rows
    for row in data.rows:
        table.add_row(*row.values())
    
    console.print(table)
    if len(data.rows) > 10:
        console.print(f"[dim]{len(data.rows)} rows[/dim]")


def format_data_as_json(data: Data) -> str:
    """
    Serialize query result data to a pretty-printed JSON string.
    
    Returns:
        A JSON-formatted string representing the data as an array of objects, indented with two spaces.
    """
    return json.dumps(data.to_dicts(), indent=2)


def format_data_as_csv(data: Data) -> str:
    """
    Convert a Data object into a CSV-formatted string.
    
    Parameters:
        data (Data): Table-like object providing a column_names() sequence for headers and an iterable `rows`
            whose items expose a values() method returning row cell values.
    
    Returns:
        csv_string (str): CSV text including a header row and subsequent data rows.
    """
    import csv
    import io
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(data.column_names())
    for row in data.rows:
        writer.writerow(row.values())
    return output.getvalue()


def output_data(data: Data, output_format: str, console: Optional["Console"] = None) -> None:
    """
    Render Data to stdout in the chosen format.
    
    Supports "table", "json", and "csv". For "table", if a Rich Console is provided and Rich is available, a styled table is rendered; otherwise a plain tab-separated table is printed. Unrecognized formats are treated as "table".
    
    Parameters:
        data (Data): Result set containing column names and rows to output.
        output_format (str): Output format to use; one of "table", "json", or "csv".
        console (Optional[Console]): Optional Rich Console used for styled table rendering when available.
    """
    if output_format == "table":
        if not data.rows:
            if console and HAS_RICH:
                console.print("[dim]Result contains no data[/dim]")
            else:
                click.echo("Result contains no data")
            return
        if console and HAS_RICH:
            format_data_as_table(data, console)
        else:
            # Simple table fallback
            click.echo("\t".join(data.column_names()))
            for row in data.rows:
                click.echo("\t".join(row.values()))
        # Render chart below the table
        chart_str = None
        try:
            from .charts import render_chart
            chart_str = render_chart(data)
        except ImportError:
            chart_str = None
        except Exception as exc:
            print_warning(f"Chart rendering skipped: {exc}", console)

        if chart_str:
            if console and HAS_RICH:
                console.print()
                console.print(Text.from_ansi(chart_str))
            else:
                click.echo()
                click.echo(chart_str)
    elif output_format == "json":
        click.echo(format_data_as_json(data))
    elif output_format == "csv":
        click.echo(format_data_as_csv(data))
    else:
        # Default to table
        output_data(data, "table", console)


# Main CLI group
@click.group()
@click.option("--api-key", "-k", envvar=ENV_API_KEY, help="Veezoo API key")
@click.option("--base-url", "-u", envvar=ENV_BASE_URL, help="Veezoo API base URL", hidden=True)
@click.option("--kg-id", "-g", envvar=ENV_KG_ID, help="Default Knowledge Graph ID")
@click.version_option(package_name="veezoo")
@click.pass_context
def cli(ctx, api_key: Optional[str], base_url: Optional[str], kg_id: Optional[str]):
    """Veezoo CLI - query your data using natural language or VQL."""
    # Initializes the CLI context with resolved credentials (from CLI option, env var, or config file) and output console.
    ctx.ensure_object(dict)
    ctx.obj["api_key"] = get_api_key(api_key)
    ctx.obj["base_url"] = get_base_url(base_url)
    ctx.obj["kg_id"] = get_kg_id(kg_id)
    ctx.obj["console"] = get_console()


@cli.command()
@click.option("--api-key", "-k", prompt="API Key", hide_input=True, 
              help="Your Veezoo API key")
@click.option("--base-url", "-u", default=None,
              help="Custom API base URL (optional)")
@click.option("--kg-id", "-g", default=None,
              help="Default Knowledge Graph ID (optional)")
@click.pass_context
def configure(ctx, api_key: str, base_url: Optional[str], kg_id: Optional[str]):
    """Save API credentials and verify the connection."""
    console = ctx.obj.get("console")
    
    config = load_config()
    config["api_key"] = api_key
    
    if base_url:
        config["base_url"] = base_url
    elif "base_url" in config and not base_url:
        # Keep existing base_url if not specified
        pass
    
    if kg_id:
        config["kg_id"] = kg_id
    elif "kg_id" in config and not kg_id:
        # Keep existing kg_id if not specified
        pass
    
    save_config(config)
    print_success(f"Configuration saved to {CONFIG_FILE}", console)
    
    # Test the connection
    try:
        client = create_client(api_key, base_url)
        client.ping()
        print_success("API connection verified", console)
    except VeezooError as e:
        print_warning(f"Could not verify API connection: {e.message}", console)


@cli.command()
@click.pass_context
def ping(ctx):
    """Check Veezoo API connectivity and credentials."""
    console = ctx.obj.get("console")
    api_key = ctx.obj.get("api_key")
    base_url = ctx.obj.get("base_url")
    
    if not api_key:
        print_error("API key not configured. Run 'veezoo configure' or set VEEZOO_API_KEY", console)
        sys.exit(1)
    
    try:
        client = create_client(api_key, base_url)
        client.ping()
        print_success("API is reachable and authentication successful", console)
    except VeezooApiError as e:
        print_error(f"{e.message}", console)
        if e.request_id:
            click.echo(f"Request ID: {e.request_id}", err=True)
        sys.exit(1)
    except VeezooError as e:
        print_error(e.message, console)
        sys.exit(1)


@cli.command()
@click.argument("vql", required=False)
@click.option("--kg-id", "-g", help="Knowledge Graph ID")
@click.option("--file", "-i", type=click.File("r"), help="Read VQL from file")
@click.option("--format", "-f", "output_format", type=click.Choice(["table", "json", "csv"]),
              default="table", help="Output format")
@click.option("--show-sql", is_flag=True, help="Show generated SQL")
@click.option("--show-rewriting", is_flag=True, help="Show VQL rewriting steps")
@click.pass_context
def query(ctx, vql: Optional[str], kg_id: Optional[str], file, output_format: str,
          show_sql: bool, show_rewriting: bool):
    """Run a VQL query.

    VQL can be provided as an argument, from a file (--file), or via stdin.

    \b
    Examples:
      $ vz query "var x from kb.Customer; select(count(x))" -g my-kg
      $ vz query -i query.vql -g my-kg
      $ echo "select(count(kb.Customer))" | vz query -g my-kg
    """
    console = ctx.obj.get("console")
    api_key = ctx.obj.get("api_key")
    base_url = ctx.obj.get("base_url")
    
    # Get Knowledge Graph ID
    kg_id = kg_id or ctx.obj.get("kg_id")
    if not kg_id:
        print_error("Knowledge Graph ID required. Use --kg-id or configure with 'veezoo configure'", console)
        sys.exit(1)
    
    if not api_key:
        print_error("API key not configured. Run 'veezoo configure' or set VEEZOO_API_KEY", console)
        sys.exit(1)
    
    # Get VQL from argument, file, or stdin
    if file:
        vql = file.read()
    elif not vql and not sys.stdin.isatty():
        vql = sys.stdin.read()
    
    if not vql or not vql.strip():
        print_error("VQL query required. Provide as argument, --file, or via stdin", console)
        sys.exit(1)
    
    vql = vql.strip()
    
    try:
        client = create_client(api_key, base_url)
        result = client.run_vql_query(kg_id=kg_id, vql=vql)
        
        # Show rewriting steps if requested
        if show_rewriting and result.rewriting.steps:
            if console and HAS_RICH:
                console.print("\n[bold]Rewriting Steps:[/bold]")
                for i, step in enumerate(result.rewriting.steps, 1):
                    console.print(f"  {i}. [cyan]{step.rule}[/cyan] ({step.stage.value})")
                console.print()
            else:
                click.echo("\nRewriting Steps:")
                for i, step in enumerate(result.rewriting.steps, 1):
                    click.echo(f"  {i}. {step.rule} ({step.stage.value})")
                click.echo()
        
        # Show SQL if requested and available
        if show_sql and result.sql:
            if console and HAS_RICH:
                console.print("[bold]Generated SQL:[/bold]")
                syntax = Syntax(result.sql, "sql", theme="monokai", line_numbers=False)
                console.print(syntax)
                console.print()
            else:
                click.echo("\nGenerated SQL:")
                click.echo(result.sql)
                click.echo()
        
        # Output the data
        output_data(result.data, output_format, console)
        
    except VeezooApiError as e:
        print_error(f"{e.message}", console)
        if e.request_id:
            click.echo(f"Request ID: {e.request_id}", err=True)
        sys.exit(1)
    except VeezooError as e:
        print_error(e.message, console)
        sys.exit(1)


@cli.command()
@click.argument("question")
@click.option("--kg-id", "-g", help="Knowledge Graph ID")
@click.option("--conversation-id", "-c", default=None,
              help="Conversation ID for follow-up questions")
@click.option("--language", "-l", default=None,
              help="BCP-47 language code (e.g. 'en', 'de')")
@click.option("--raw", is_flag=True, help="Print the full raw API question response as JSON")
@click.option("--format", "-f", "data_format", type=click.Choice(["table", "json", "csv"]),
              default=None, help="Format for structured answer data")
@click.option("--show-vql", is_flag=True, help="Show VQL for each answer")
@click.option("--show-sql", is_flag=True, help="Show SQL for each answer")
@click.pass_context
def ask(ctx, question: str, kg_id: Optional[str], conversation_id: Optional[str],
        language: Optional[str], raw: bool, data_format: Optional[str], show_vql: bool, show_sql: bool):
    """
    Ask a natural language question.

    Examples:

        $ veezoo ask "How many customers do we have?" -g my-kg

        $ veezoo ask "Break down by region" -g my-kg -c <conversation-id>

        $ veezoo ask "Revenue last year" -g my-kg --raw

        $ veezoo ask "Revenue last year" -g my-kg --format csv
    """
    console = ctx.obj.get("console")
    api_key = ctx.obj.get("api_key")
    base_url = ctx.obj.get("base_url")

    # Get Knowledge Graph ID
    kg_id = kg_id or ctx.obj.get("kg_id")
    if not kg_id:
        print_error("Knowledge Graph ID required. Use --kg-id or configure with 'veezoo configure'", console)
        sys.exit(1)

    if not api_key:
        print_error("API key not configured. Run 'veezoo configure' or set VEEZOO_API_KEY", console)
        sys.exit(1)

    if raw and data_format is not None:
        print_error("--format is not supported with --raw", console)
        sys.exit(1)
    if raw and show_vql:
        print_error("--show-vql is not supported with --raw", console)
        sys.exit(1)
    if raw and show_sql:
        print_error("--show-sql is not supported with --raw", console)
        sys.exit(1)

    if data_format is None:
        data_format = "table"

    try:
        client = create_client(api_key, base_url)
        if raw:
            raw_result = client.ask_raw(
                kg_id=kg_id,
                question=question,
                conversation_id=conversation_id,
                language=language,
            )
            click.echo(json.dumps(raw_result, indent=2))
            if raw_result.get("isError", False):
                sys.exit(1)
            return

        result = client.ask(
            kg_id=kg_id,
            question=question,
            conversation_id=conversation_id,
            language=language,
        )

        # Display conversation ID for follow-ups
        if console and HAS_RICH:
            console.print(f"[dim]Conversation ID: {result.conversation_id}[/dim]")
        else:
            click.echo(f"Conversation ID: {result.conversation_id}")

        # Display messages in order
        from .models import TextMessage, AnswerMessage
        for msg in result.messages:
            if isinstance(msg, TextMessage):
                if console and HAS_RICH:
                    from rich.markdown import Markdown as RichMarkdown
                    console.print()
                    console.print(RichMarkdown(msg.content))
                else:
                    click.echo()
                    click.echo(msg.content)

            elif isinstance(msg, AnswerMessage):
                if msg.title:
                    if console and HAS_RICH:
                        console.print(f"\n[bold]{msg.title}[/bold]")
                    else:
                        click.echo(f"\n{msg.title}")

                if msg.data is not None:
                    output_data(msg.data, data_format, console)

                if show_vql and msg.vql:
                    if console and HAS_RICH:
                        console.print("[bold]VQL:[/bold]")
                        console.print(msg.vql)
                        console.print()
                    else:
                        click.echo("VQL:")
                        click.echo(msg.vql)
                        click.echo()

                if show_sql and msg.sql:
                    if console and HAS_RICH:
                        syntax = Syntax(msg.sql, "sql", theme="monokai", line_numbers=False)
                        console.print("[bold]SQL:[/bold]")
                        console.print(syntax)
                        console.print()
                    else:
                        click.echo("SQL:")
                        click.echo(msg.sql)
                        click.echo()

        # Show error indicator if applicable
        if result.is_error:
            print_error("The response indicates an error", console)
            sys.exit(1)

    except VeezooApiError as e:
        print_error(f"{e.message}", console)
        if e.request_id:
            click.echo(f"Request ID: {e.request_id}", err=True)
        sys.exit(1)
    except VeezooError as e:
        print_error(e.message, console)
        sys.exit(1)


@cli.command("shared-answer")
@click.argument("answer_id")
@click.option("--kg-id", "-g", help="Knowledge Graph ID")
@click.option("--format", "-f", "output_format", type=click.Choice(["table", "json", "csv"]),
              default="table", help="Output format")
@click.option("--show-sql", is_flag=True, help="Show generated SQL")
@click.option("--show-vql", is_flag=True, help="Show the VQL query")
@click.pass_context
def shared_answer(ctx, answer_id: str, kg_id: Optional[str], output_format: str,
                  show_sql: bool, show_vql: bool):
    """Execute a shared answer by ID."""
    console = ctx.obj.get("console")
    api_key = ctx.obj.get("api_key")
    base_url = ctx.obj.get("base_url")
    
    # Get Knowledge Graph ID
    kg_id = kg_id or ctx.obj.get("kg_id")
    if not kg_id:
        print_error("Knowledge Graph ID required. Use --kg-id or configure with 'veezoo configure'", console)
        sys.exit(1)
    
    if not api_key:
        print_error("API key not configured. Run 'veezoo configure' or set VEEZOO_API_KEY", console)
        sys.exit(1)
    
    try:
        client = create_client(api_key, base_url)
        result = client.run_shared_answer(kg_id=kg_id, shared_answer_id=answer_id)
        
        # Show VQL if requested and available
        if show_vql and result.vql:
            if console and HAS_RICH:
                console.print("[bold]VQL Query:[/bold]")
                console.print(Panel(result.vql.strip(), border_style="dim"))
                console.print()
            else:
                click.echo("\nVQL Query:")
                click.echo(result.vql)
                click.echo()
        
        # Show SQL if requested and available
        if show_sql and result.sql:
            if console and HAS_RICH:
                console.print("[bold]Generated SQL:[/bold]")
                syntax = Syntax(result.sql, "sql", theme="monokai", line_numbers=False)
                console.print(syntax)
                console.print()
            else:
                click.echo("\nGenerated SQL:")
                click.echo(result.sql)
                click.echo()
        
        # Output the data
        output_data(result.data, output_format, console)
        
    except VeezooApiError as e:
        print_error(f"{e.message}", console)
        if e.request_id:
            click.echo(f"Request ID: {e.request_id}", err=True)
        sys.exit(1)
    except VeezooError as e:
        print_error(e.message, console)
        sys.exit(1)


@cli.command()
@click.pass_context
def config(ctx):
    """Display current configuration."""
    console = ctx.obj.get("console")
    config = load_config()
    
    api_key = get_api_key()
    base_url = get_base_url()
    kg_id = get_kg_id()
    
    if console and HAS_RICH:
        table = Table(box=box.SIMPLE, show_header=False)
        table.add_column("Setting", style="cyan")
        table.add_column("Value")
        table.add_column("Source", style="dim")
        
        # API Key
        if api_key:
            masked = api_key[:4] + "*" * (len(api_key) - 8) + api_key[-4:] if len(api_key) > 8 else "****"
            source = "env" if os.environ.get(ENV_API_KEY) else "config"
            table.add_row("API Key", masked, source)
        else:
            table.add_row("API Key", "[red]Not set[/red]", "")
        
        # Base URL
        if base_url:
            source = "env" if os.environ.get(ENV_BASE_URL) else "config"
            table.add_row("Base URL", base_url, source)
        else:
            table.add_row("Base URL", "[dim]default[/dim]", "")
        
        # Knowledge Graph ID
        if kg_id:
            source = "env" if os.environ.get(ENV_KG_ID) else "config"
            table.add_row("KG ID", kg_id, source)
        else:
            table.add_row("KG ID", "[dim]Not set[/dim]", "")
        
        console.print(table)
        console.print(f"\n[dim]Config file: {CONFIG_FILE}[/dim]")
    else:
        click.echo("Current Configuration:")
        if api_key:
            masked = api_key[:4] + "*" * (len(api_key) - 8) + api_key[-4:] if len(api_key) > 8 else "****"
            click.echo(f"  API Key:  {masked}")
        else:
            click.echo("  API Key:  Not set")
        click.echo(f"  Base URL: {base_url or 'default'}")
        click.echo(f"  KG ID:    {kg_id or 'Not set'}")
        click.echo(f"\nConfig file: {CONFIG_FILE}")


@cli.command()
@click.confirmation_option(prompt="Are you sure you want to clear the configuration?")
@click.pass_context
def logout(ctx):
    """Clear saved configuration."""
    console = ctx.obj.get("console")
    
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
        print_success("Configuration cleared", console)
    else:
        click.echo("No configuration file found")


@cli.command()
@click.option("--kg-id", "-g", help="Knowledge Graph ID to use")
@click.pass_context
def interactive(ctx, kg_id: Optional[str]):
    """Start an interactive session with syntax highlighting and multi-line editing.

    Requires: pip install 'veezoo[interactive]'
    """
    console = ctx.obj.get("console")
    api_key = ctx.obj.get("api_key")
    base_url = ctx.obj.get("base_url")
    
    if not api_key:
        print_error("API key not configured. Run 'veezoo configure' or set VEEZOO_API_KEY", console)
        sys.exit(1)
    
    # Get KG ID from argument or config
    kg_id = kg_id or ctx.obj.get("kg_id")
    
    try:
        from .interactive import run_interactive
        run_interactive(
            api_key=api_key,
            base_url=base_url,
            kg_id=kg_id,
        )
    except ImportError as e:
        print_error(
            "Interactive mode requires additional dependencies. "
            "Install with: pip install 'veezoo[interactive]'",
            console
        )
        sys.exit(1)


# Alias for interactive mode
@cli.command("i")
@click.option("--kg-id", "-g", help="Knowledge Graph ID to use")
@click.pass_context
def interactive_alias(ctx, kg_id: Optional[str]):
    """Alias for 'interactive'."""
    ctx.invoke(interactive, kg_id=kg_id)


def main():
    """Entry point for the CLI."""
    cli(obj={})


if __name__ == "__main__":
    main()