"""
Veezoo API Client

The main client class for interacting with the Veezoo API.
"""

import json
from typing import Optional, Dict, Any
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode

from .models import VqlQueryResult, SharedAnswerResult, QuestionResult
from .exceptions import (
    VeezooError,
    VeezooApiError,
    VeezooAuthenticationError,
    VeezooPaymentRequiredError,
    VeezooNotFoundError,
    VeezooRateLimitError,
    VeezooValidationError,
    VeezooServerError,
)


class VeezooClient:
    """
    Client for interacting with the Veezoo API.

    Args:
        api_key: Your Veezoo API key. Get one from https://app.veezoo.com/admin/api/keys
        base_url: The base URL for the Veezoo API (default: https://app.veezoo.com/api)
        timeout: Request timeout in seconds (default: 120)

    Example:
        >>> client = VeezooClient(api_key="your-api-key")
        >>> result = client.run_vql_query(
        ...     kg_id="my-sales-kg",
        ...     vql="var customers from kb.Customer\\nselect(count(customers))"
        ... )
        >>> print(result.data.to_dicts())
    """

    DEFAULT_BASE_URL = "https://app.veezoo.com/api"
    API_VERSION = "beta"

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: int = 120,
    ):
        """
        Create a VeezooClient configured with an API key, optional base URL, and request timeout.
        
        Parameters:
            api_key (str): Veezoo API key; required.
            base_url (Optional[str]): Custom base URL for the API. Defaults to DEFAULT_BASE_URL; any trailing '/' is removed.
            timeout (int): Request timeout in seconds.
        
        Raises:
            VeezooError: If `api_key` is not provided.
        """
        if not api_key:
            raise VeezooError("API key is required")

        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

    def _get_headers(self) -> Dict[str, str]:
        """
        Builds HTTP headers required for Veezoo API requests.
        
        Returns:
            headers (Dict[str, str]): HTTP headers with "X-Api-Key" set to the client's API key, "Content-Type" set to "application/json", and "Accept" set to "application/json".
        """
        return {
            "X-Api-Key": self.api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _handle_error_response(
        self,
        status_code: int,
        response_body: Optional[Dict[str, Any]],
        request_id: Optional[str],
    ) -> None:
        """
        Raise a Veezoo-specific exception based on an API error response.
        
        Chooses an exception class according to the HTTP status code and raises it with the error message (preferentially taken from `response_body["message"]` when present), the provided `request_id`, and the full `response_body`.
        
        Parameters:
            status_code (int): HTTP status code returned by the API.
            response_body (Optional[Dict[str, Any]]): Parsed JSON body of the error response, if available.
            request_id (Optional[str]): Request identifier extracted from response headers, if available.
        
        Raises:
            VeezooValidationError: when status_code is 400.
            VeezooAuthenticationError: when status_code is 401.
            VeezooPaymentRequiredError: when status_code is 402.
            VeezooNotFoundError: when status_code is 404.
            VeezooRateLimitError: when status_code is 429.
            VeezooServerError: when status_code is 500 or greater.
            VeezooApiError: for all other non-success status codes.
        """
        message = "An error occurred"
        if response_body and "message" in response_body:
            message = response_body["message"]

        error_classes = {
            400: VeezooValidationError,
            401: VeezooAuthenticationError,
            402: VeezooPaymentRequiredError,
            404: VeezooNotFoundError,
            429: VeezooRateLimitError,
        }

        if status_code in error_classes:
            raise error_classes[status_code](
                message=message,
                request_id=request_id,
                response_body=response_body,
            )
        elif status_code >= 500:
            raise VeezooServerError(
                message=message,
                status_code=status_code,
                request_id=request_id,
                response_body=response_body,
            )
        else:
            raise VeezooApiError(
                message=message,
                status_code=status_code,
                request_id=request_id,
                response_body=response_body,
            )

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, str]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Perform an HTTP request against the Veezoo API and return the decoded JSON response.
        
        Parameters:
            method (str): HTTP method (e.g., "GET", "POST").
            endpoint (str): API path appended to the client's base URL and API version (e.g., "/queries/vql").
            params (Optional[Dict[str, str]]): Query parameters to append to the URL.
            data (Optional[Dict[str, Any]]): JSON-serializable body to send with the request.
        
        Returns:
            Dict[str, Any]: Parsed JSON response as a dictionary, or an empty dict if the response body is empty.
        
        Raises:
            VeezooError: On network failures or when the response cannot be parsed as JSON.
            VeezooApiError: For HTTP error responses; specific subclasses (validation, authentication, rate limit, server, etc.) are raised based on status code.
        """
        url = f"{self.base_url}/{self.API_VERSION}{endpoint}"
        if params:
            url = f"{url}?{urlencode(params)}"

        body = json.dumps(data).encode("utf-8") if data else None

        request = Request(
            url=url,
            data=body,
            headers=self._get_headers(),
            method=method,
        )

        try:
            with urlopen(request, timeout=self.timeout) as response:
                request_id = response.headers.get("X-Request-Id")
                content = response.read().decode("utf-8")
                if content:
                    return json.loads(content)
                return {}
        except HTTPError as e:
            request_id = e.headers.get("X-Request-Id") if e.headers else None
            response_body = None
            try:
                content = e.read().decode("utf-8")
                if content:
                    response_body = json.loads(content)
            except (json.JSONDecodeError, UnicodeDecodeError):
                pass
            self._handle_error_response(e.code, response_body, request_id)
        except URLError as e:
            raise VeezooError(f"Network error: {e.reason}")
        except json.JSONDecodeError as e:
            raise VeezooError(f"Failed to parse response: {e}")
        
        # This line should never be reached, but is needed for type checking
        return {}

    def ping(self) -> bool:
        """
        Check connectivity to the Veezoo API and validate the configured API key.
        
        Returns:
            `true` if the API is reachable and authentication succeeds.
        
        Raises:
            VeezooAuthenticationError: If authentication fails.
            VeezooApiError: If the API returns another error.
        """
        self._request("GET", "/ping")
        return True

    def run_vql_query(self, kg_id: str, vql: str) -> VqlQueryResult:
        """
        Run a VQL query against a Knowledge Graph.

        Args:
            kg_id: The ID of the Knowledge Graph
            vql: The VQL query to run

        Returns:
            The query result containing data and rewriting information

        Raises:
            VeezooValidationError: If the VQL syntax is invalid
            VeezooNotFoundError: If the Knowledge Graph doesn't exist
            VeezooServerError: If query execution fails
            VeezooApiError: For other API errors

        Example:
            >>> result = client.run_vql_query(
            ...     kg_id="my-sales-kg",
            ...     vql=\"\"\"
            ...     var customers from kb.Customer
            ...     var retCount = count(customers)
            ...     select(retCount)
            ...     \"\"\"
            ... )
            >>> print(f"Result: {result.data.to_dicts()}")
            >>> if result.sql:
            ...     print(f"Generated SQL: {result.sql}")
        """
        if not kg_id:
            raise VeezooError("Knowledge Graph ID (kg_id) is required")
        if not vql:
            raise VeezooError("VQL query is required")

        response = self._request(
            method="POST",
            endpoint="/queries/vql",
            params={"kgId": kg_id},
            data={"vql": vql},
        )
        return VqlQueryResult.from_dict(response)

    def run_shared_answer(self, kg_id: str, shared_answer_id: str) -> SharedAnswerResult:
        """
        Run an existing shared answer.

        Args:
            kg_id: The ID of the Knowledge Graph
            shared_answer_id: The ID of the shared answer to run

        Returns:
            The result containing data and rewriting information

        Raises:
            VeezooNotFoundError: If the shared answer or Knowledge Graph doesn't exist
            VeezooServerError: If execution fails
            VeezooApiError: For other API errors

        Example:
            >>> result = client.run_shared_answer(
            ...     kg_id="my-sales-kg",
            ...     shared_answer_id="0ece8e2d-b821-476d-bd78-986e8cb62879"
            ... )
            >>> for row in result.data:
            ...     print(row.values())
        """
        if not kg_id:
            raise VeezooError("Knowledge Graph ID (kg_id) is required")
        if not shared_answer_id:
            raise VeezooError("Shared answer ID is required")

        response = self._request(
            method="POST",
            endpoint=f"/shared-answers/{shared_answer_id}",
            params={"kgId": kg_id},
        )
        return SharedAnswerResult.from_dict(response)

    def ask(
        self,
        kg_id: str,
        question: str,
        conversation_id: Optional[str] = None,
        language: Optional[str] = None,
    ) -> QuestionResult:
        """
        Ask a natural language question.

        Args:
            kg_id: The ID of the Knowledge Graph
            question: The natural language question to ask
            conversation_id: Optional conversation ID for follow-up questions.
                If not provided, a new conversation is created and its ID is
                returned in the result.
            language: Optional BCP-47 language code (e.g. 'en', 'de')

        Returns:
            The question result containing a text answer, structured data answers,
            and a conversation ID for follow-ups

        Raises:
            VeezooValidationError: If the question is invalid
            VeezooNotFoundError: If the Knowledge Graph doesn't exist
            VeezooServerError: If question processing fails
            VeezooApiError: For other API errors

        Example:
            >>> result = client.ask(
            ...     kg_id="my-sales-kg",
            ...     question="How many customers do we have?"
            ... )
            >>> for msg in result.messages:
            ...     if hasattr(msg, "data") and msg.data:
            ...         print(msg.data.to_dicts())

            Follow-up:
            >>> follow_up = client.ask(
            ...     kg_id="my-sales-kg",
            ...     question="Break down by region",
            ...     conversation_id=result.conversation_id
            ... )
        """
        response = self.ask_raw(
            kg_id=kg_id,
            question=question,
            conversation_id=conversation_id,
            language=language,
        )
        return QuestionResult.from_dict(response)

    def ask_raw(
        self,
        kg_id: str,
        question: str,
        conversation_id: Optional[str] = None,
        language: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Ask a natural language question and return the raw API JSON response.

        This is primarily useful for CLI or integration scenarios where the exact
        API response shape should be preserved.

        Args:
            kg_id: The ID of the Knowledge Graph
            question: The natural language question to ask
            conversation_id: Optional conversation ID for follow-up questions
            language: Optional BCP-47 language code (e.g. 'en', 'de')

        Returns:
            The raw parsed JSON response from the API.
        """
        if not kg_id:
            raise VeezooError("Knowledge Graph ID (kg_id) is required")
        if not question:
            raise VeezooError("Question is required")

        data: Dict[str, Any] = {"question": question}
        if conversation_id:
            data["conversationId"] = conversation_id
        if language:
            data["language"] = language

        return self._request(
            method="POST",
            endpoint="/questions",
            params={"kgId": kg_id},
            data=data,
        )
