# Documentation

Start here:

- `../README.md`
- `guides/pypi-install-quickstart.md`

Maintainer-only guides:

- `guides/llama-server-setup.md`
- `guides/hf-to-gguf-quantization-guide.md`
- `guides/pypi-release-guide.md`
- `guides/gemma4-shared-kv-rca.md`
