# PyPI Install Quickstart (User Guide)

Use this guide for the shortest working path: install, download, run, and test.

## Requirements

- Python `>=3.10`
- Internet access for PyPI and model download
- `ai4burmese` will bootstrap a compatible standalone `llama-server` automatically on first `serve`

## 1) Install From PyPI

```bash
python3.10 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install "ai4burmese[full]"
```

If `python3.10` is not installed:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "ai4burmese[full]"
```

## 2) Check Runtime

You do not need to install `llama-server` separately for the default beginner flow.
`ai4burmese serve` will fetch a compatible standalone binary automatically if one is not already available.

## 3) Download Model

```bash
ai4burmese download --quant q8_0
```

## 4) Run Local API Server

```bash
ai4burmese serve --quant q8_0 --host 127.0.0.1 --port 8000
```

## 5) Test API With curl

In another terminal:

```bash
source .venv/bin/activate
curl http://127.0.0.1:8000/v1/models
```

```bash
source .venv/bin/activate
curl http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-no-key-required" \
  -d '{
    "model": "padauk-agent",
    "messages": [{"role": "user", "content": "မင်္ဂလာပါ"}]
  }'
```

## 6) Test With OpenAI Agents SDK

```bash
source .venv/bin/activate
python -m pip install openai-agents
```

```python
import asyncio

from openai import AsyncOpenAI
from agents import Agent, Runner, set_default_openai_api, set_default_openai_client, set_tracing_disabled

set_tracing_disabled(True)
set_default_openai_api("chat_completions")
set_default_openai_client(
    AsyncOpenAI(base_url="http://127.0.0.1:8000/v1", api_key="sk-no-key-required")
)

padauk = Agent(name="Padauk Assistant", model="padauk-agent", instructions="Reply in Burmese by default.")

async def main() -> None:
    result = await Runner.run(padauk, input="မင်္ဂလာပါ")
    print(result.final_output)

asyncio.run(main())
```
