from __future__ import annotations

import io
import tarfile
from pathlib import Path
import io
import tarfile

import pytest

from burmesegpt.bootstrap import (
    LLAMA_CPP_RELEASE_TAG,
    UnsupportedLlamaServerPlatformError,
    bootstrap_llama_server,
    managed_cache_dir,
    select_release_asset_name,
)


def _write_fake_llama_server(path: Path, version: int = 8833) -> None:
    path.write_text(
        "#!/usr/bin/env python3\n"
        "import sys\n"
        "if '--version' in sys.argv:\n"
        f"    print('llama-server version: {version}')\n",
        encoding="utf-8",
    )
    path.chmod(0o755)


def _build_fake_archive() -> bytes:
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as tar:
        content = (
            "#!/usr/bin/env python3\n"
            "import sys\n"
            "if '--version' in sys.argv:\n"
            "    print('llama-server version: 8833')\n"
        ).encode("utf-8")
        info = tarfile.TarInfo("bundle/bin/llama-server")
        info.mode = 0o755
        info.size = len(content)
        tar.addfile(info, io.BytesIO(content))
    return buffer.getvalue()


class _FakeResponse:
    def __init__(self, payload: bytes):
        self.payload = payload

    def raise_for_status(self) -> None:
        return None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def iter_content(self, chunk_size: int):
        for index in range(0, len(self.payload), chunk_size):
            yield self.payload[index : index + chunk_size]


def _make_fake_archive() -> bytes:
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as tar:
        binary = b"#!/usr/bin/env python3\nimport sys\nif '--version' in sys.argv:\n    print('llama-server version: 8833')\n"
        info = tarfile.TarInfo(name="llama-b8833/bin/llama-server")
        info.mode = 0o755
        info.size = len(binary)
        tar.addfile(info, io.BytesIO(binary))
        lib_payload = b"payload"
        lib_info = tarfile.TarInfo(name="llama-b8833/lib/libdummy.txt")
        lib_info.mode = 0o644
        lib_info.size = len(lib_payload)
        tar.addfile(lib_info, io.BytesIO(lib_payload))
    return buffer.getvalue()


def test_select_release_asset_name_supports_macos_arm64_and_x64() -> None:
    assert select_release_asset_name(system="Darwin", machine="arm64") == (
        f"llama-{LLAMA_CPP_RELEASE_TAG}-bin-macos-arm64.tar.gz"
    )
    assert select_release_asset_name(system="Darwin", machine="x86_64") == (
        f"llama-{LLAMA_CPP_RELEASE_TAG}-bin-macos-x64.tar.gz"
    )


def test_bootstrap_downloads_and_extracts_managed_binary(monkeypatch, tmp_path: Path) -> None:
    asset_name = select_release_asset_name(system="Darwin", machine="arm64")
    payload = _make_fake_archive()

    monkeypatch.setattr(
        "burmesegpt.bootstrap._fetch_release_assets",
        lambda tag: {asset_name: "https://example.invalid/llama-server.tar.gz"},
    )
    monkeypatch.setattr(
        "burmesegpt.bootstrap.requests.get",
        lambda url, **_kwargs: _FakeResponse(payload) if url.endswith(".tar.gz") else (_ for _ in ()).throw(AssertionError("unexpected request")),
    )

    resolved = bootstrap_llama_server(
        cache_root=tmp_path,
        tag=LLAMA_CPP_RELEASE_TAG,
        system="Darwin",
        machine="arm64",
    )

    assert resolved.exists()
    assert resolved.name == "llama-server"
    assert resolved.parent.name == "bin"


def test_bootstrap_reuses_cached_managed_binary_without_network(monkeypatch, tmp_path: Path) -> None:
    cache_dir = managed_cache_dir(
        cache_root=tmp_path,
        tag=LLAMA_CPP_RELEASE_TAG,
        platform_key="macos-arm64",
    )
    cache_dir.mkdir(parents=True, exist_ok=True)
    binary = cache_dir / "llama-server"
    _write_fake_llama_server(binary)

    monkeypatch.setattr(
        "burmesegpt.bootstrap.requests.get",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("network should not be used")),
    )

    resolved = bootstrap_llama_server(
        cache_root=tmp_path,
        tag=LLAMA_CPP_RELEASE_TAG,
        system="Darwin",
        machine="arm64",
    )

    assert resolved == binary


def test_bootstrap_downloads_and_extracts_managed_binary(monkeypatch, tmp_path: Path) -> None:
    archive_bytes = _build_fake_archive()
    asset_name = select_release_asset_name(system="Darwin", machine="arm64")

    class _Response:
        def __init__(self, *, payload: dict | None = None, content: bytes | None = None) -> None:
            self._payload = payload
            self._content = content

        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict:
            assert self._payload is not None
            return self._payload

        def iter_content(self, chunk_size: int):
            assert self._content is not None
            yield self._content

        def close(self) -> None:
            return None

    def fake_get(url: str, **_kwargs):
        if url.endswith(f"/releases/tags/{LLAMA_CPP_RELEASE_TAG}"):
            return _Response(
                payload={
                    "assets": [
                        {
                            "name": asset_name,
                            "browser_download_url": "https://example.invalid/llama.tar.gz",
                        }
                    ]
                }
            )
        if url == "https://example.invalid/llama.tar.gz":
            return _Response(content=archive_bytes)
        raise AssertionError(f"unexpected URL: {url}")

    monkeypatch.setattr("burmesegpt.bootstrap.requests.get", fake_get)

    resolved = bootstrap_llama_server(
        cache_root=tmp_path,
        tag=LLAMA_CPP_RELEASE_TAG,
        system="Darwin",
        machine="arm64",
    )

    assert resolved.exists()
    assert resolved.name == "llama-server"
    assert resolved.parent.name == "bin"


def test_bootstrap_rejects_unsupported_architecture() -> None:
    with pytest.raises(UnsupportedLlamaServerPlatformError, match="Unsupported llama-server architecture"):
        select_release_asset_name(system="Darwin", machine="ppc64")
