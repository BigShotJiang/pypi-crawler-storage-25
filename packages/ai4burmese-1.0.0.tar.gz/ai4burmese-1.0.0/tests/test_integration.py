from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest
import requests

from burmesegpt import padauk_agent


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def test_import_and_mocked_download_checksum(monkeypatch, tmp_path: Path) -> None:
    model_filename = "padauk-gemma-q4_k_m.gguf"
    model_bytes = b"fake-gguf-content"

    def fake_hf_hub_download(*, filename: str, local_dir: str, token: str | None = None, **_kwargs):
        path = Path(local_dir) / filename
        path.parent.mkdir(parents=True, exist_ok=True)

        if filename == model_filename:
            path.write_bytes(model_bytes)
            return str(path)

        if filename == "SHA256SUMS.txt":
            import hashlib

            sha = hashlib.sha256(model_bytes).hexdigest()
            path.write_text(f"{sha}  {model_filename}\n", encoding="utf-8")
            return str(path)

        raise AssertionError(f"unexpected file requested: {filename}")

    monkeypatch.setattr("burmesegpt.agent.hf_hub_download", fake_hf_hub_download)

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/ai4burmese-padauk-gguf",
        revision="main",
        cache_dir=tmp_path,
        hf_token="token-123",
    )

    model_path = agent.ensure_model()
    assert model_path.exists()
    assert model_path.read_bytes() == model_bytes


@pytest.mark.integration
def test_serve_test_mode_endpoints(tmp_path: Path) -> None:
    port = _free_port()

    env = os.environ.copy()
    src_path = str((Path(__file__).resolve().parents[1] / "src"))
    env["PYTHONPATH"] = src_path + os.pathsep + env.get("PYTHONPATH", "")

    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "burmesegpt.cli",
            "--cache-dir",
            str(tmp_path),
            "serve",
            "--quant",
            "q4_k_m",
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--model-alias",
            "padauk-agent",
            "--test-mode",
        ],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    try:
        base_url = f"http://127.0.0.1:{port}/v1"

        deadline = time.time() + 20
        last_error: Exception | None = None
        while time.time() < deadline:
            try:
                response = requests.get(f"{base_url}/models", timeout=1)
                if response.status_code == 200:
                    break
            except Exception as exc:  # pragma: no cover - timing dependent
                last_error = exc
            time.sleep(0.25)
        else:
            stdout, stderr = proc.communicate(timeout=2)
            raise AssertionError(
                f"test server did not start: last_error={last_error}; stdout={stdout}; stderr={stderr}"
            )

        models_payload = requests.get(f"{base_url}/models", timeout=2).json()
        assert models_payload["data"][0]["id"] == "padauk-agent"

        chat_payload = {
            "model": "padauk-agent",
            "messages": [{"role": "user", "content": "မင်္ဂလာပါ"}],
        }
        chat_response = requests.post(
            f"{base_url}/chat/completions",
            headers={"Content-Type": "application/json"},
            data=json.dumps(chat_payload),
            timeout=2,
        )
        assert chat_response.status_code == 200
        content = chat_response.json()["choices"][0]["message"]["content"]
        assert "[test-mode]" in content
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:  # pragma: no cover - safety
            proc.kill()
