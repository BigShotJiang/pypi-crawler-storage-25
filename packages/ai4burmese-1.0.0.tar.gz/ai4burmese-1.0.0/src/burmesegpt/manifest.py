from __future__ import annotations

from pathlib import Path

DEFAULT_REPO_ID = "WYNN747/ai4burmese-padauk-gguf"
DEFAULT_QUANT = "q8_0"
DEFAULT_REVISION = "main"
DEFAULT_CACHE_ROOT = Path("~/.cache/ai4burmese/models").expanduser()

QUANT_FILENAMES: dict[str, str] = {
    "q4_k_m": "padauk-gemma-q4_k_m.gguf",
    "q5_k_m": "padauk-gemma-q5_k_m.gguf",
    "q8_0": "padauk-gemma-q8_0.gguf",
}

# Release maintainers should bump hashes here whenever model artifacts are updated.
# If a value is None, runtime verification will fall back to SHA256SUMS.txt from HF repo.
PACKAGE_SHA256: dict[str, str | None] = {
    "q4_k_m": None,
    "q5_k_m": None,
    "q8_0": "2080409fb04855e695fa15e18b5618d0312f3d801b83518268bb063f9f62047a",
}


def normalize_quant(quant: str | None) -> str:
    value = (quant or DEFAULT_QUANT).lower().strip()
    if value not in QUANT_FILENAMES:
        allowed = ", ".join(sorted(QUANT_FILENAMES))
        raise ValueError(f"Unsupported quant '{quant}'. Choose one of: {allowed}")
    return value


def quant_filename(quant: str | None) -> str:
    return QUANT_FILENAMES[normalize_quant(quant)]


def expected_package_sha256(quant: str | None) -> str | None:
    return PACKAGE_SHA256[normalize_quant(quant)]


def cache_dir_for(
    repo_id: str,
    revision: str | None,
    cache_root: Path | str | None,
) -> Path:
    root = Path(cache_root).expanduser() if cache_root else DEFAULT_CACHE_ROOT
    parts = repo_id.split("/")
    if not parts or any(part in {"", ".", ".."} for part in parts):
        raise ValueError("repo_id contains invalid path segments")
    safe_revision = (revision or DEFAULT_REVISION).replace("/", "_")
    return root.joinpath(*parts, safe_revision)
