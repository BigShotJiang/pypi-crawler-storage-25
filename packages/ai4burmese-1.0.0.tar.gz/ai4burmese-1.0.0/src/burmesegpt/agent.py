from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from huggingface_hub import hf_hub_download
from huggingface_hub.errors import EntryNotFoundError, HfHubHTTPError

from .bootstrap import (
    LlamaServerBootstrapError,
    MIN_STANDALONE_LLAMA_CPP_BUILD,
    RECOMMENDED_STANDALONE_LLAMA_CPP_BUILD,
    bootstrap_llama_server,
)
from .manifest import (
    DEFAULT_QUANT,
    DEFAULT_REPO_ID,
    cache_dir_for,
    expected_package_sha256,
    normalize_quant,
    quant_filename,
)
from .release_pipeline import (
    ReleasePipelineError,
    gemma4_shared_kv_runtime_guidance,
    is_gemma4_shared_kv_runtime_error,
    looks_like_gemma4_shared_kv_metadata,
    read_gguf_metadata,
)


class HashMismatchError(RuntimeError):
    """Raised when a downloaded model fails SHA256 verification."""


class MissingChecksumError(RuntimeError):
    """Raised when no checksum is available for a requested quant."""


class ServerLaunchError(RuntimeError):
    """Raised when the local OpenAI-compatible server cannot start."""


class GGUFValidationError(RuntimeError):
    """Raised when a GGUF artifact fails structural validation."""


SERVE_BACKEND_AUTO = "auto"
SERVE_BACKEND_PYTHON = "python"
SERVE_BACKEND_STANDALONE = "standalone"
SERVE_BACKENDS = (
    SERVE_BACKEND_AUTO,
    SERVE_BACKEND_PYTHON,
    SERVE_BACKEND_STANDALONE,
)


@dataclass
class ServeConfig:
    host: str = "127.0.0.1"
    port: int = 8000
    model_alias: str = "padauk-agent"
    n_ctx: int = 8192
    n_gpu_layers: int = -1
    api_key: str = "sk-no-key-required"
    backend: str = SERVE_BACKEND_AUTO
    llama_server_path: str | None = None


def resolve_hf_token(hf_token: str | None) -> str | None:
    if hf_token:
        return hf_token
    env_token = os.getenv("HF_TOKEN")
    if env_token:
        return env_token
    return None


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def parse_sha256sums(content: str) -> dict[str, str]:
    checksums: dict[str, str] = {}
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        checksums[parts[-1]] = parts[0].lower()
    return checksums


class PadaukAgent:
    def __init__(
        self,
        quant: str = DEFAULT_QUANT,
        repo_id: str = DEFAULT_REPO_ID,
        revision: str | None = None,
        cache_dir: str | Path | None = None,
        hf_token: str | None = None,
    ) -> None:
        self.quant = normalize_quant(quant)
        self.repo_id = repo_id
        self.revision = revision
        self.cache_dir = cache_dir_for(repo_id, revision, cache_dir)
        self.hf_token = hf_token
        self.model_filename = quant_filename(self.quant)
        self.model_path = self.cache_dir / self.model_filename
        self._serve_config = ServeConfig()

    @property
    def openai_base_url(self) -> str:
        return f"http://{self._serve_config.host}:{self._serve_config.port}/v1"

    def ensure_model(self) -> Path:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        token = resolve_hf_token(self.hf_token)
        model_path = Path(
            hf_hub_download(
                repo_id=self.repo_id,
                filename=self.model_filename,
                revision=self.revision,
                token=token,
                local_dir=str(self.cache_dir),
            )
        )

        checksums = self._load_repo_checksums(token)
        expected_sha = expected_package_sha256(self.quant) or checksums.get(self.model_filename)
        if not expected_sha:
            raise MissingChecksumError(
                f"No checksum found for {self.model_filename}. "
                "Add it to PACKAGE_SHA256 or SHA256SUMS.txt in the model repo."
            )

        actual_sha = file_sha256(model_path)
        if actual_sha.lower() != expected_sha.lower():
            raise HashMismatchError(
                f"Checksum mismatch for {model_path}. expected={expected_sha}, actual={actual_sha}"
            )

        self.model_path = model_path
        return model_path

    def validate_model(self, *, runtime_check: bool = True) -> Path:
        model_path = self.ensure_model()
        self._validate_gguf_magic(model_path)
        if runtime_check:
            self._validate_runtime_load(model_path)
        return model_path

    def _validate_gguf_magic(self, model_path: Path) -> None:
        try:
            with model_path.open("rb") as fh:
                magic = fh.read(4)
        except OSError as exc:
            raise GGUFValidationError(f"Unable to read model file {model_path}: {exc}") from exc

        if magic != b"GGUF":
            raise GGUFValidationError(
                f"Invalid GGUF header for {model_path}: expected b'GGUF', found {magic!r}."
            )

    def _load_llama_class(self):
        try:
            from llama_cpp import Llama
        except ImportError as exc:
            raise RuntimeError(
                "Runtime validation requires llama-cpp-python. "
                'Install with: pip install "ai4burmese[server]" '
                'or pip install "llama-cpp-python".'
            ) from exc
        return Llama

    def _validate_runtime_load(self, model_path: Path) -> None:
        Llama = self._load_llama_class()
        llm = None
        metadata: dict[str, Any] | None = None
        try:
            metadata = read_gguf_metadata(model_path)
        except ReleasePipelineError:
            metadata = None
        try:
            llm = Llama(
                model_path=str(model_path),
                n_ctx=128,
                n_gpu_layers=0,
                verbose=False,
            )
        except Exception as exc:
            guidance = ""
            if looks_like_gemma4_shared_kv_metadata(metadata):
                guidance = (
                    " This GGUF passed package checksum and GGUF header validation. "
                    f"{gemma4_shared_kv_runtime_guidance()}"
                )
            elif is_gemma4_shared_kv_runtime_error(exc, metadata):
                guidance = f" {gemma4_shared_kv_runtime_guidance()}"
            raise RuntimeError(
                f"llama_cpp failed to load {model_path}: {exc}. "
                f"The GGUF artifact may be corrupted or incompatible.{guidance}"
            ) from exc
        finally:
            close = getattr(llm, "close", None)
            if callable(close):
                close()

    def _load_repo_checksums(self, token: str | None) -> dict[str, str]:
        try:
            checksum_path = Path(
                hf_hub_download(
                    repo_id=self.repo_id,
                    filename="SHA256SUMS.txt",
                    revision=self.revision,
                    token=token,
                    local_dir=str(self.cache_dir),
                )
            )
        except (EntryNotFoundError, HfHubHTTPError):
            return {}

        try:
            return parse_sha256sums(checksum_path.read_text(encoding="utf-8"))
        except OSError:
            return {}

    def _locate_llama_server_candidate(self, explicit_path: str | None = None) -> tuple[Path | None, str | None]:
        if explicit_path:
            candidate = Path(explicit_path).expanduser()
            if candidate.exists() and os.access(candidate, os.X_OK):
                return candidate, "explicit"
            raise ServerLaunchError(
                "Standalone llama-server was requested, but the explicit "
                f"--llama-server-path does not point to an executable file: {candidate}."
            )

        env_path = os.getenv("AI4BURMESE_LLAMA_SERVER")
        if not env_path:
            env_path = os.getenv("BURMESEGPT_LLAMA_SERVER")

        if env_path:
            candidate = Path(env_path).expanduser()
            if candidate.exists() and os.access(candidate, os.X_OK):
                return candidate, "env"
            raise ServerLaunchError(
                "AI4BURMESE_LLAMA_SERVER (or legacy BURMESEGPT_LLAMA_SERVER) is set, but it does "
                "not point to an executable file: "
                f"{candidate}."
            )

        which_path = shutil.which("llama-server")
        if which_path:
            candidate = Path(which_path)
            if candidate.exists() and os.access(candidate, os.X_OK):
                return candidate, "path"

        return None, None

    def _discover_llama_server(self, explicit_path: str | None = None) -> Path | None:
        candidate, _source = self._locate_llama_server_candidate(explicit_path)
        return candidate

    def _bootstrap_llama_server(self) -> Path:
        try:
            return bootstrap_llama_server()
        except LlamaServerBootstrapError as exc:
            raise ServerLaunchError(f"Unable to bootstrap managed llama-server: {exc}") from exc

    def _llama_server_build(self, llama_server_path: Path) -> int | None:
        try:
            result = subprocess.run(
                [str(llama_server_path), "--version"],
                capture_output=True,
                text=True,
                check=True,
            )
        except (OSError, subprocess.CalledProcessError):
            return None

        output = "\n".join(part for part in (result.stdout, result.stderr) if part)
        match = re.search(r"version:\s*(\d+)", output)
        if match is None:
            return None
        return int(match.group(1))

    def _ensure_compatible_llama_server(
        self,
        llama_server_path: Path,
        *,
        selected_backend: str,
    ) -> None:
        build = self._llama_server_build(llama_server_path)
        if build is None:
            raise ServerLaunchError(
                f"Found llama-server at {llama_server_path}, but could not determine its version. "
                f"Use a standalone llama.cpp build >= b{MIN_STANDALONE_LLAMA_CPP_BUILD}, "
                f"ideally b{RECOMMENDED_STANDALONE_LLAMA_CPP_BUILD}."
            )

        if build < MIN_STANDALONE_LLAMA_CPP_BUILD:
            backend_hint = (
                "Requested standalone backend"
                if selected_backend == SERVE_BACKEND_STANDALONE
                else "Detected standalone llama-server"
            )
            raise ServerLaunchError(
                f"{backend_hint} at {llama_server_path}, but it is too old for Padauk Gemma 4 serving "
                f"(found b{build}, need >= b{MIN_STANDALONE_LLAMA_CPP_BUILD}, "
                f"b{RECOMMENDED_STANDALONE_LLAMA_CPP_BUILD} recommended). "
                "Update llama.cpp or put a newer llama-server on PATH."
            )

    def _gemma4_standalone_server_error(
        self, *, selected_backend: str, explicit_path: str | None = None
    ) -> ServerLaunchError:
        location_hint = (
            f" via --llama-server-path {explicit_path!r}"
            if explicit_path
            else " via AI4BURMESE_LLAMA_SERVER, BURMESEGPT_LLAMA_SERVER (legacy), or by putting llama-server on PATH"
        )
        action = (
            "backend=standalone was requested"
            if selected_backend == SERVE_BACKEND_STANDALONE
            else "Gemma 4 shared-KV models should use standalone llama-server when available"
        )
        return ServerLaunchError(
            f"{action}, but no executable llama-server was found{location_hint}. "
            "Install a standalone llama.cpp build >= b8751, ideally b8833, and retry."
        )

    def _select_serve_backend(
        self,
        *,
        config: ServeConfig,
        metadata: dict[str, Any] | None,
    ) -> tuple[str, Path | None]:
        shared_kv = looks_like_gemma4_shared_kv_metadata(metadata)
        standalone_path = self._discover_llama_server(config.llama_server_path)
        source = (
            "explicit"
            if config.llama_server_path
            else "env"
            if os.getenv("AI4BURMESE_LLAMA_SERVER") or os.getenv("BURMESEGPT_LLAMA_SERVER")
            else "path"
        )
        build = self._llama_server_build(standalone_path) if standalone_path is not None else None

        if config.backend == SERVE_BACKEND_STANDALONE:
            if standalone_path is not None and build is not None and build >= MIN_STANDALONE_LLAMA_CPP_BUILD:
                return SERVE_BACKEND_STANDALONE, standalone_path
            if source in {"explicit", "env"} and standalone_path is not None:
                self._ensure_compatible_llama_server(
                    standalone_path,
                    selected_backend=config.backend,
                )
            return SERVE_BACKEND_STANDALONE, self._bootstrap_llama_server()

        if config.backend == SERVE_BACKEND_PYTHON:
            return SERVE_BACKEND_PYTHON, None

        if shared_kv:
            if standalone_path is not None and build is not None and build >= MIN_STANDALONE_LLAMA_CPP_BUILD:
                return SERVE_BACKEND_STANDALONE, standalone_path
            if source in {"explicit", "env"} and standalone_path is not None:
                self._ensure_compatible_llama_server(
                    standalone_path,
                    selected_backend=config.backend,
                )
            # Beginner flow fallback: if this Gemma 4 model needs standalone serving and
            # nothing compatible is already installed, bootstrap the managed binary.
            return SERVE_BACKEND_STANDALONE, self._bootstrap_llama_server()

        return SERVE_BACKEND_PYTHON, None

    def _build_python_server_command(self, config: ServeConfig, model_path: Path) -> list[str]:
        return [
            sys.executable,
            "-m",
            "llama_cpp.server",
            "--model",
            str(model_path),
            "--host",
            config.host,
            "--port",
            str(config.port),
            "--n_ctx",
            str(config.n_ctx),
            "--n_gpu_layers",
            str(config.n_gpu_layers),
            "--model_alias",
            config.model_alias,
            "--api_key",
            config.api_key,
        ]

    def _build_standalone_server_command(
        self,
        config: ServeConfig,
        model_path: Path,
        llama_server_path: Path,
    ) -> list[str]:
        return [
            str(llama_server_path),
            "--model",
            str(model_path),
            "--alias",
            config.model_alias,
            "--host",
            config.host,
            "--port",
            str(config.port),
            "--ctx-size",
            str(config.n_ctx),
            "--n-gpu-layers",
            str(config.n_gpu_layers),
            "--api-key",
            config.api_key,
        ]

    def serve(
        self,
        host: str = "127.0.0.1",
        port: int = 8000,
        model_alias: str = "padauk-agent",
        n_ctx: int = 8192,
        n_gpu_layers: int = -1,
        api_key: str = "sk-no-key-required",
        backend: str = SERVE_BACKEND_AUTO,
        llama_server_path: str | None = None,
        *,
        wait: bool = True,
        test_mode: bool = False,
    ) -> subprocess.Popen[str] | None:
        self._serve_config = ServeConfig(
            host=host,
            port=port,
            model_alias=model_alias,
            n_ctx=n_ctx,
            n_gpu_layers=n_gpu_layers,
            api_key=api_key,
            backend=backend,
            llama_server_path=llama_server_path,
        )

        if test_mode:
            self._serve_test_mode()
            return None

        model_path = self.ensure_model()
        metadata: dict[str, Any] | None = None
        try:
            metadata = read_gguf_metadata(model_path)
        except ReleasePipelineError:
            metadata = None

        selected_backend, standalone_path = self._select_serve_backend(
            config=self._serve_config,
            metadata=metadata,
        )

        if selected_backend == SERVE_BACKEND_PYTHON and looks_like_gemma4_shared_kv_metadata(metadata):
            try:
                self._validate_runtime_load(model_path)
            except RuntimeError as exc:
                raise ServerLaunchError(str(exc)) from exc

        if selected_backend == SERVE_BACKEND_STANDALONE:
            assert standalone_path is not None
            command = self._build_standalone_server_command(
                self._serve_config, model_path, standalone_path
            )
        else:
            command = self._build_python_server_command(self._serve_config, model_path)

        process = subprocess.Popen(command, text=True)
        if wait:
            returncode = process.wait()
            if returncode != 0:
                if selected_backend == SERVE_BACKEND_STANDALONE:
                    raise ServerLaunchError(
                        f"standalone llama-server exited with status {returncode}. "
                        "Check that your llama.cpp build is >= b8751, ideally b8833, "
                        "and that the selected binary matches your platform."
                    )
                raise ServerLaunchError(
                    f"llama_cpp.server exited with status {returncode}. "
                    "Possible causes: missing server dependencies "
                    '(install with: pip install "ai4burmese[server]") '
                    "or an invalid/incompatible GGUF artifact."
                )
            return None

        return process

    def _serve_test_mode(self) -> None:
        config = self._serve_config

        class _Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def _write_json(self, payload: dict[str, Any], status: int = 200) -> None:
                encoded = json.dumps(payload).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(encoded)))
                self.end_headers()
                self.wfile.write(encoded)

            def log_message(self, _format: str, *_args: Any) -> None:
                return

            def do_GET(self) -> None:  # noqa: N802
                if self.path == "/v1/models":
                    self._write_json(
                        {
                            "object": "list",
                            "data": [{"id": config.model_alias, "object": "model"}],
                        }
                    )
                    return
                self._write_json({"error": "not_found"}, status=404)

            def do_POST(self) -> None:  # noqa: N802
                if self.path != "/v1/chat/completions":
                    self._write_json({"error": "not_found"}, status=404)
                    return

                body = self.rfile.read(int(self.headers.get("Content-Length", 0) or 0))
                request_json = json.loads(body.decode("utf-8") or "{}")
                messages = request_json.get("messages", [])
                user_message = ""
                for message in reversed(messages):
                    if message.get("role") == "user":
                        user_message = str(message.get("content", ""))
                        break

                self._write_json(
                    {
                        "id": "chatcmpl-test",
                        "object": "chat.completion",
                        "model": config.model_alias,
                        "choices": [
                            {
                                "index": 0,
                                "message": {
                                    "role": "assistant",
                                    "content": f"[test-mode] {user_message}".strip(),
                                },
                                "finish_reason": "stop",
                            }
                        ],
                    }
                )

        server = ThreadingHTTPServer((config.host, config.port), _Handler)
        try:
            server.serve_forever()
        finally:
            server.server_close()



def padauk_agent(
    quant: str = DEFAULT_QUANT,
    repo_id: str = DEFAULT_REPO_ID,
    revision: str | None = None,
    cache_dir: str | Path | None = None,
    hf_token: str | None = None,
) -> PadaukAgent:
    return PadaukAgent(
        quant=quant,
        repo_id=repo_id,
        revision=revision,
        cache_dir=cache_dir,
        hf_token=hf_token,
    )



def wait_for_server(base_url: str, timeout: float = 30.0) -> None:
    import requests

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            response = requests.get(f"{base_url}/models", timeout=1.0)
            if 200 <= response.status_code < 300:
                return
        except requests.RequestException:
            pass
        time.sleep(0.3)
    raise TimeoutError(f"Timed out waiting for server at {base_url}")



def chat_completion(
    *,
    base_url: str,
    model: str,
    messages: list[dict[str, str]],
    api_key: str,
    timeout: float = 120.0,
) -> str:
    import requests

    response = requests.post(
        f"{base_url}/chat/completions",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        json={
            "model": model,
            "messages": messages,
        },
        timeout=timeout,
    )
    response.raise_for_status()
    payload = response.json()
    return str(payload["choices"][0]["message"]["content"])
