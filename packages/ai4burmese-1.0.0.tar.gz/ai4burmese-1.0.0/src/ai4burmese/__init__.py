"""Compatibility package for the ai4burmese distribution.

The underlying implementation still lives in :mod:`burmesegpt`.
"""

from __future__ import annotations

from burmesegpt import *  # noqa: F401,F403

__all__ = ["PadaukAgent", "padauk_agent"]
