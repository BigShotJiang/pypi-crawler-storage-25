# AI4Burmese

AI4Burmese is an open Burmese-first AI ecosystem created by Dr. Wai Yan Nyein Naing. This Python package is the main package for AI4Burmese projects, including **Padauk**, a practical agentic small language model built for Burmese language understanding, tool use, function calling, and local or edge deployment.

## Mission

**AI4Burmese exists to help ensure Myanmar is not left behind in the age of AI.**

The mission is to make AI more **open, free, accessible, and useful** for Burmese-speaking communities across different backgrounds, including users, students, builders, researchers, and developers.

AI4Burmese supports practical open-source AI that people can use, study, build on top of, and adapt for real local needs.

## Why AI4Burmese

Burmese remains a low-resource language in AI, and practical Burmese AI tooling is still limited for many real developer and end-user workflows.

AI4Burmese focuses on useful, production-minded, and developer-friendly Burmese AI systems that are:

- open for learning and contribution
- free and accessible for broader use
- practical for real workflows
- buildable so others can extend them
- designed for Burmese-first interaction with English support

The goal is not only to release models, but also to make Burmese AI easier to use, easier to deploy, and easier to build on.

## Included Ecosystem Direction

AI4Burmese is the umbrella initiative. Model families and releases can include:

- **Padauk** — Burmese-first agentic assistant model
- **Padauk GGUF** — quantized local deployment release
- **Burmese-Coder** — Burmese technical and coding model direction
- future open-source Burmese AI tools and runtimes

## Current Model Repositories

- **Source adapter model:** `WYNN747/ai4burmese-padauk`
- **GGUF local model:** `WYNN747/ai4burmese-padauk-gguf`

## End-User Install And Use

This section is the simple user flow only: install, download, run, and test the local API.

Requirements:

- Python `>=3.10`
- a working `llama-server` binary

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "ai4burmese[full]"
```

If your default `python3` is below 3.10, use an explicit interpreter:

```bash
/opt/homebrew/bin/python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "ai4burmese[full]"
```

## Download Model And Run API

```bash
export AI4BURMESE_LLAMA_SERVER="$HOME/llama.cpp/build/bin/llama-server"
ai4burmese download --quant q8_0
ai4burmese serve --quant q8_0 --backend auto --host 127.0.0.1 --port 8000
```

Keep that terminal running while you test requests.

## Test With API Call

```bash
curl http://127.0.0.1:8000/v1/models
```

```bash
curl http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-no-key-required" \
  -d '{
    "model": "padauk-agent",
    "messages": [{"role": "user", "content": "မင်္ဂလာပါ"}]
  }'
```

## Test With OpenAI Agents SDK

```bash
python -m pip install openai-agents
```

```python
import asyncio

from openai import AsyncOpenAI
from agents import Agent, Runner, set_default_openai_api, set_default_openai_client, set_tracing_disabled

set_tracing_disabled(True)
set_default_openai_api("chat_completions")
set_default_openai_client(
    AsyncOpenAI(base_url="http://127.0.0.1:8000/v1", api_key="sk-no-key-required")
)

padauk = Agent(
    name="Padauk Assistant",
    model="padauk-agent",
    instructions="Reply in Burmese by default.",
)

async def main() -> None:
    result = await Runner.run(padauk, input="မင်္ဂလာပါ")
    print(result.final_output)

asyncio.run(main())
```

## What This Package Is For

AI4Burmese is intended for:

* Burmese-first assistant applications
* local and self-hosted Burmese AI workflows
* tool-calling and function-calling assistants
* MCP-connected and skill-based systems
* practical Burmese AI experimentation
* community-accessible open AI infrastructure

## Maintainer Release Validation

If you are packaging or rebuilding the model, use maintainer-facing documentation such as:

* release guide
* Hugging Face to GGUF conversion guide
* runtime compatibility notes for Gemma 4 / llama.cpp

## Links

* **Website:** [https://ai4burmese.com/](https://ai4burmese.com/)
* **Founder:** [https://www.waiyannyeinnaing.com/](https://www.waiyannyeinnaing.com/)
* **Project page:** [https://www.waiyannyeinnaing.com/projects/padauk](https://www.waiyannyeinnaing.com/projects/padauk)
* **Source repo:** [https://github.com/WaiYanNyeinNaing/ai4burmese](https://github.com/WaiYanNyeinNaing/ai4burmese)
* **Hugging Face source adapter:** [https://huggingface.co/WYNN747/ai4burmese-padauk](https://huggingface.co/WYNN747/ai4burmese-padauk)
* **Hugging Face GGUF:** [https://huggingface.co/WYNN747/ai4burmese-padauk-gguf](https://huggingface.co/WYNN747/ai4burmese-padauk-gguf)

## License

This package may include integrations and packaging around models released under their respective upstream licenses. Model usage remains subject to the base model license and any repository-specific release notes.

## Citation

If you use AI4Burmese or Padauk in research or product work, please cite the project and model pages.

```bibtex
@misc{ai4burmese2026,
  title = {AI4Burmese: Open Burmese-First AI Ecosystem},
  author = {Wai Yan Nyein Naing},
  year = {2026},
  url = {https://ai4burmese.com/}
}
```
