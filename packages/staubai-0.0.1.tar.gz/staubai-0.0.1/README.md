# staubai

Placeholder package for [Staub AI](https://staub.ai).

The canonical package name is **`staub`** — install that instead:

```bash
pip install staub
```

This `staubai` package exists only to secure the alternate namespace.

Visit [staub.ai](https://staub.ai) or [github.com/staubai](https://github.com/staubai)
for updates.
