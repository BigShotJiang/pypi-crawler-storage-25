"""Placeholder for the staubai package. Use 'staub' instead. See https://staub.ai"""

__version__ = "0.0.1"

_MESSAGE = (
    "staubai: this PyPI package is a placeholder. "
    "The canonical package is 'staub' — run `pip install staub` instead. "
    "Visit https://staub.ai for updates."
)


def __getattr__(name: str):
    raise AttributeError(_MESSAGE)
