"""FastMCP server exposing the agy-mcp toolkit over stdio.

Tools (all return dicts with stable keys; never raise across the wire):

* ``agy`` — synchronous one-shot bridge call.
* ``agy_start`` — spawn a background job, return ``status="running"`` envelope.
* ``agy_continue`` — like ``agy``, but ``SESSION_ID`` is required.
* ``agy_status`` — poll a running job's :class:`JobRecord`.
* ``agy_read`` — read events from a job (raw or translated).
* ``agy_cancel`` — signal a running job to stop.
* ``agy_sessions`` — list recent jobs.
* ``agy_doctor`` — environment + capability probe.
* ``agy_install_skill`` — write the scaffold skill into target dirs.

Threading model: the FastMCP runtime drives tools from an asyncio loop and
calls sync tool functions inline. ``agy`` and ``agy_continue`` would block
that loop while ``_bridge_run`` waits on a subprocess, so they are declared
``async def`` and dispatch the blocking work to a worker thread via
:func:`anyio.to_thread.run_sync` (Phase 5 R1 arch P1.1).

Every tool routes its output through :class:`SafetyPolicy` before
serialisation — adapter buffers, capability warnings, and error strings
have already been scrubbed by the lower layers, but the doctor / install
helpers also redact their own paths so a transcript capture never leaks
a ``/Users/<user>/`` path.
"""

from __future__ import annotations

import asyncio
import re
import threading
import weakref
from pathlib import Path
from typing import Any

import anyio
from mcp.server.fastmcp import FastMCP

from agy_mcp import __version__
from agy_mcp.adapters.agy import AgyPrintBackend
from agy_mcp.adapters.gemini import GeminiCliBackend
from agy_mcp.bridge import _run as _bridge_run
from agy_mcp.config import Config, get_config
from agy_mcp.doctor import run_doctor
from agy_mcp.install import SkillScope, SkillTarget, install_skills
from agy_mcp.models import (
    BackendName,
    BridgeRequest,
    BridgeResponse,
    CancelToolResponse,
    DoctorToolResponse,
    InstallSkillToolResponse,
    Mode,
    OutputProtocol,
    PurgeToolResponse,
    ReadToolResponse,
    SessionsToolResponse,
    StatusToolResponse,
)
from agy_mcp.safety import SafetyPolicy
from agy_mcp.session_store import SessionStore
from agy_mcp.supervisor import Supervisor

# ---------------------------------------------------------------------------
# Module-level singletons. The FastMCP runtime imports this module exactly
# once per process; the singletons are lazily materialised on the first tool
# call so importing ``agy_mcp.server`` for tests stays cheap.
# ---------------------------------------------------------------------------

_state_lock = threading.Lock()
_config: Config | None = None
_safety: SafetyPolicy | None = None
_store: SessionStore | None = None
_supervisor: Supervisor | None = None
# Cached adapters for the doctor probe so we don't pay 4 subprocess calls
# (one help + one version per backend) on every ``agy_doctor`` invocation.
# Phase 5 R1 arch P1.5.
_agy_adapter: AgyPrintBackend | None = None
_gemini_adapter: GeminiCliBackend | None = None

# Defence-in-depth cap so a malicious or buggy caller can't burn unbounded
# memory by passing a multi-megabyte string in place of a job_id slug. We
# also pin a charset so structured failures don't echo control bytes back
# to the caller (Phase 5 R2 security P2-2). The pattern aligns with the
# session_store's own regex (`^job_[A-Za-z0-9_-]{1,80}$`, max 84 chars)
# so the server gate never accepts more than the deeper layer will store
# (Phase 5 R3 security P2).
_MAX_JOB_ID_LEN = 84
_JOB_ID_PATTERN = re.compile(r"^job_[A-Za-z0-9_-]{1,80}$")
_MAX_SESSION_ID_LEN = 96
# Conservative charset for SESSION_ID; mirrors models._SESSION_ID_RE so
# the server-side fast path and the pydantic validator stay in lockstep.
_SESSION_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,96}$")
# Concurrency limiter for the async bridge tools. anyio's default thread
# limiter is global to the process (40); ``_bridge_run`` itself spawns
# additional reader threads + a subprocess per call, so we add a finer cap
# to keep a flood of concurrent MCP calls from exhausting local resources
# (Phase 5 R2 security P1-3). ``anyio.CapacityLimiter`` is loop-affine —
# each instance is bound to the asyncio loop that created it — so we cache
# per running loop id rather than process-globally (Phase 5 R3 arch P1).
_BRIDGE_CONCURRENCY = 8
# Phase 5 R3 P3.14: keyed on the running loop object itself via
# WeakKeyDictionary so a GC'd loop drops its limiter automatically.
# (The previous ``dict[int, ...]`` keyed on ``id(loop)`` was correct
# under cache-replace-on-collision semantics, but kept stale limiters
# alive for the process lifetime when a loop was discarded.)
_bridge_limiters_by_loop: weakref.WeakKeyDictionary[
    asyncio.AbstractEventLoop, anyio.CapacityLimiter
] = weakref.WeakKeyDictionary()
_bridge_limiter_lock = threading.Lock()

# Defence-in-depth cap on the install-skill argument surface
# (Phase 5 R2 security P1-1). 16 is well above the four documented
# targets (claude, codex, antigravity, all) — large enough for forward
# extensions, small enough to refuse pathological payloads.
_MAX_INSTALL_TARGETS = 16
_ALLOWED_TARGETS: frozenset[str] = frozenset({"claude", "codex", "antigravity", "all"})

# Conservative cap on the purge cutoff. Operators occasionally want to
# nuke everything older than a few hours; we still refuse zero/negative
# (handled by SessionStore.purge_older_than) and refuse anything past 10
# years to defend against an integer typo wiping the whole store via
# ``days=99999`` evaluating to a noop cutoff.
_PURGE_MAX_DAYS = 365 * 10


def _ensure_state() -> tuple[Config, SafetyPolicy, SessionStore, Supervisor]:
    global _config, _safety, _store, _supervisor
    with _state_lock:
        if _config is None:
            _config = get_config()
        if _safety is None:
            _safety = SafetyPolicy.from_config(_config)
        if _store is None:
            _store = SessionStore(Path(_config.session_store_root()).expanduser())
        if _supervisor is None:
            _supervisor = Supervisor(
                store=_store, config=_config, safety=_safety,
            )
        return _config, _safety, _store, _supervisor


def _ensure_adapters(*, force_refresh: bool = False) -> tuple[AgyPrintBackend, GeminiCliBackend]:
    """Lazily build doctor adapter singletons.

    Each adapter probes its CLI exactly once (caching the result), so the
    doctor probe can reuse them across calls instead of forking
    ``agy --help`` / ``agy --version`` / ``gemini --help`` /
    ``gemini --version`` every invocation. The MCP server is the only
    caller; tests bypass this by passing fresh adapters directly to
    ``run_doctor``.

    ``force_refresh=True`` drops the cached singletons so an operator who
    just upgraded an underlying binary can re-probe without restarting
    the MCP server. (Phase 5 R2 security P2-1.)
    """

    global _agy_adapter, _gemini_adapter
    _, safety, _store_, _supervisor_ = _ensure_state()
    with _state_lock:
        if force_refresh:
            _agy_adapter = None
            _gemini_adapter = None
        if _agy_adapter is None:
            _agy_adapter = AgyPrintBackend(safety=safety)
        if _gemini_adapter is None:
            _gemini_adapter = GeminiCliBackend(safety=safety)
        return _agy_adapter, _gemini_adapter


async def _get_bridge_limiter() -> anyio.CapacityLimiter:
    """Return (and lazily build) the per-loop bridge concurrency cap.

    ``anyio.CapacityLimiter`` binds to the asyncio loop active when the
    instance is constructed, so a process-global singleton breaks when
    a second loop is spun up (tests using ``asyncio.run`` per call,
    embedded sidecar loops, hot reloads). We cache one limiter per
    running loop via a ``weakref.WeakKeyDictionary`` so a discarded
    loop frees its limiter automatically — and a re-used ``id(loop)``
    cannot resurrect a stale limiter from a dead loop (Phase 5 R3
    arch P1 + R3 P3.14).
    """

    loop = asyncio.get_running_loop()
    with _bridge_limiter_lock:
        limiter = _bridge_limiters_by_loop.get(loop)
        if limiter is None:
            limiter = anyio.CapacityLimiter(_BRIDGE_CONCURRENCY)
            _bridge_limiters_by_loop[loop] = limiter
        return limiter


def _reset_state_for_tests() -> None:
    """Drop the cached singletons so tests can swap in fresh stores.

    Holds ``_state_lock`` and ``_bridge_limiter_lock`` while wiping.
    **Invariant for future maintainers:** callbacks invoked while
    those locks are held MUST NOT call back into ``_ensure_state``
    / ``_ensure_adapters`` / ``_get_bridge_limiter``, or the test
    teardown will deadlock. The current implementation only mutates
    module-level globals — keep it that way (Phase 5 R2 P3.7).
    """

    global _config, _safety, _store, _supervisor, _agy_adapter, _gemini_adapter
    with _state_lock:
        _config = None
        _safety = None
        _store = None
        _supervisor = None
        _agy_adapter = None
        _gemini_adapter = None
    with _bridge_limiter_lock:
        _bridge_limiters_by_loop.clear()


# ---------------------------------------------------------------------------
# FastMCP instance and tool registrations
# ---------------------------------------------------------------------------


mcp = FastMCP(
    name="agy-mcp",
    instructions=(
        "Google Antigravity (agy) CLI bridge with long-task supervisor. "
        "Use ``agy`` for one-shot prompts, ``agy_start`` + ``agy_status`` "
        "+ ``agy_read`` + ``agy_cancel`` for detached jobs, and "
        "``agy_doctor`` to check the environment."
    ),
)


# ---------------------------------------------------------------------------
# Helpers used by the synchronous tools (``agy``, ``agy_continue``)
# ---------------------------------------------------------------------------


def _build_request(payload: dict[str, Any]) -> BridgeRequest:
    """Validate the incoming MCP arguments through the BridgeRequest schema.

    Pydantic raises ``ValidationError`` on bad input; the tool wrapper
    catches it and converts to a structured failure envelope.
    """

    return BridgeRequest(**payload)


def _structured_failure(safety: SafetyPolicy, exc: BaseException, *, cwd: str = "") -> BridgeResponse:
    """Top-level guard: any tool exception becomes a structured envelope.

    Returns a :class:`BridgeResponse` instance so the FastMCP runtime can
    emit ``structuredContent`` alongside the text fallback. Callers that
    historically expected a ``dict`` can still call ``.model_dump()`` —
    but the tool functions themselves now return the model directly.
    """

    return BridgeResponse(
        success=False,
        error=safety.redact(str(exc)),
        cwd=safety.redact(cwd),
    )


def _wrapper_failure(
    safety: SafetyPolicy,
    exc: BaseException,
    cls: type,
    **extra: Any,
):
    """Failure envelope for the metadata tools (status / read / cancel / ...).

    ``cls`` is one of the wrapper Tool response models; ``extra`` lets the
    caller pin echo fields like ``job_id`` so a client comparing input and
    output can correlate the failure with the call. Pydantic validates
    that ``extra`` fits the model's field set, so a typo blows up at
    development time, not at serialisation.
    """

    safe_extra = {
        key: safety.redact(value) if isinstance(value, str) else value
        for key, value in extra.items()
    }
    return cls(
        success=False,
        error=safety.redact(str(exc)),
        **safe_extra,
    )


def _response_to_dict(resp: BridgeResponse) -> dict[str, Any]:
    # Retained for tests / external callers that depended on the dict form.
    return resp.model_dump(mode="json")


def _validate_job_id(safety: SafetyPolicy, job_id: str) -> str | None:
    """Return a redacted error string if ``job_id`` is invalid, else None."""

    if not job_id:
        return safety.redact("job_id is required")
    if len(job_id) > _MAX_JOB_ID_LEN:
        return safety.redact(
            f"job_id exceeds {_MAX_JOB_ID_LEN} chars; refusing to look up",
        )
    if not _JOB_ID_PATTERN.match(job_id):
        # Don't echo the raw value back — it might contain control bytes.
        return safety.redact(
            "job_id must match ^job_[A-Za-z0-9_-]{1,80}$",
        )
    if safety.redact(job_id) != job_id:
        return safety.redact("job_id must not contain secret-shaped text")
    return None


def _validate_session_id(safety: SafetyPolicy, session_id: str) -> str | None:
    """Length-cap and charset-check SESSION_ID before it reaches the bridge.

    The bridge layer treats SESSION_ID as a worktree slug seed, a child-
    process env entry, and an ``--conversation=<id>`` flag value; a
    multi-megabyte value or one containing NUL/CR/LF would either crash
    ``os.execvpe`` (Linux glibc) or smuggle through on macOS. We mirror
    the BridgeRequest model validator here so the server returns a clean
    structured error before the pydantic round-trip raises. (Phase 5 R2
    arch P2 #3; Phase 8 review P1-1.)
    """

    if len(session_id) > _MAX_SESSION_ID_LEN:
        return safety.redact(
            f"SESSION_ID exceeds {_MAX_SESSION_ID_LEN} chars",
        )
    if not _SESSION_ID_RE.fullmatch(session_id):
        return safety.redact(
            "SESSION_ID must match ^[A-Za-z0-9._-]{1,96}$ "
            "(no whitespace, NUL, CR/LF, slashes, or shell metacharacters)",
        )
    return None


# ---------------------------------------------------------------------------
# Tool: agy — synchronous one-shot
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy",
    description=(
        "Run agy --print synchronously and return the assistant text + "
        "metadata. Compatible drop-in for the legacy `gemini` tool: same "
        "PROMPT / cd / sandbox / SESSION_ID / return_all_messages / model "
        "fields, with new mode / timeout / allow_write / worktree / backend "
        "/ output_protocol options."
    ),
)
async def agy_tool(
    PROMPT: str,
    cd: str = ".",
    SESSION_ID: str | None = None,
    model: str | None = None,
    sandbox: bool = False,
    return_all_messages: bool = False,
    mode: Mode = "ask",
    timeout: int = 900,
    allow_write: bool = False,
    worktree: bool | None = None,
    backend: BackendName = "auto",
    output_protocol: OutputProtocol = "claude",
    debug: bool = False,
    dry_run: bool = False,
    extra_env: dict[str, str] | None = None,
) -> BridgeResponse:
    # Phase 5 R4 P3.11: ``extra_env`` keeps ``| None = None`` on the
    # tool surface (MCP clients omit the key entirely on most callers)
    # but normalises to ``{}`` immediately so the downstream
    # ``BridgeRequest`` field (declared as ``dict[str, str]``) matches.
    # The JSON-schema view ends up as ``anyOf [{object}, {null}]``;
    # that is intentional and documented here so a future schema audit
    # doesn't try to "fix" it back to a bare ``object``.
    config, safety, _store_, _supervisor_ = _ensure_state()
    if SESSION_ID is not None:
        err = _validate_session_id(safety, SESSION_ID)
        if err is not None:
            return _structured_failure(safety, ValueError(err), cwd=cd)
    try:
        request = _build_request(
            {
                "prompt": PROMPT,
                "cwd": cd,
                "session_id": SESSION_ID,
                "model": model,
                "sandbox": sandbox,
                "return_all_messages": return_all_messages,
                "mode": mode,
                "timeout": timeout,
                "allow_write": allow_write,
                "worktree": worktree,
                "backend": backend,
                "output_protocol": output_protocol,
                "debug": debug,
                "dry_run": dry_run,
                "extra_env": extra_env or {},
            }
        )
    except Exception as exc:  # noqa: BLE001 - validation guard
        return _structured_failure(safety, exc, cwd=cd)
    # ``_bridge_run`` launches the agy subprocess and blocks until it
    # finishes — offload to a worker thread so the FastMCP asyncio loop
    # stays free to dispatch other tool calls. (Phase 5 R1 arch P1.1.)
    # The CapacityLimiter caps concurrent bridge calls per process so a
    # flood of MCP requests can't exhaust local resources. (Phase 5 R2
    # security P1-3.)
    limiter = await _get_bridge_limiter()
    response = await anyio.to_thread.run_sync(
        _bridge_run, request, config, safety, limiter=limiter,
    )
    return response


# ---------------------------------------------------------------------------
# Tool: agy_continue — same as agy but session_id is required
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_continue",
    description=(
        "Continue an existing agy session. Identical to `agy` except "
        "SESSION_ID is required and the underlying adapter resumes the "
        "Antigravity conversation."
    ),
)
async def agy_continue_tool(
    SESSION_ID: str,
    PROMPT: str,
    cd: str = ".",
    model: str | None = None,
    sandbox: bool = False,
    return_all_messages: bool = False,
    mode: Mode = "ask",
    timeout: int = 900,
    allow_write: bool = False,
    worktree: bool | None = None,
    backend: BackendName = "auto",
    output_protocol: OutputProtocol = "claude",
    debug: bool = False,
    dry_run: bool = False,
    extra_env: dict[str, str] | None = None,
) -> BridgeResponse:
    config, safety, _store_, _supervisor_ = _ensure_state()
    if not SESSION_ID:
        return _structured_failure(
            safety, ValueError("SESSION_ID is required for agy_continue"), cwd=cd,
        )
    err = _validate_session_id(safety, SESSION_ID)
    if err is not None:
        return _structured_failure(safety, ValueError(err), cwd=cd)
    try:
        request = _build_request(
            {
                "prompt": PROMPT,
                "cwd": cd,
                "session_id": SESSION_ID,
                "model": model,
                "sandbox": sandbox,
                "return_all_messages": return_all_messages,
                "mode": mode,
                "timeout": timeout,
                "allow_write": allow_write,
                "worktree": worktree,
                "backend": backend,
                "output_protocol": output_protocol,
                "debug": debug,
                "dry_run": dry_run,
                "extra_env": extra_env or {},
            }
        )
    except Exception as exc:  # noqa: BLE001
        return _structured_failure(safety, exc, cwd=cd)
    limiter = await _get_bridge_limiter()
    response = await anyio.to_thread.run_sync(
        _bridge_run, request, config, safety, limiter=limiter,
    )
    return response


# ---------------------------------------------------------------------------
# Tool: agy_start — spawn a background job
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_start",
    description=(
        "Start an agy session in the background. Returns an envelope with "
        "status='running' and a job_id you can poll via agy_status / "
        "agy_read / agy_cancel."
    ),
)
def agy_start_tool(
    PROMPT: str,
    cd: str = ".",
    SESSION_ID: str | None = None,
    model: str | None = None,
    sandbox: bool = False,
    mode: Mode = "ask",
    timeout: int = 900,
    allow_write: bool = False,
    worktree: bool | None = None,
    backend: BackendName = "auto",
    output_protocol: OutputProtocol = "claude",
    debug: bool = False,
    extra_env: dict[str, str] | None = None,
    job_id: str | None = None,
) -> BridgeResponse:
    config, safety, _store_, supervisor = _ensure_state()
    if SESSION_ID is not None:
        err = _validate_session_id(safety, SESSION_ID)
        if err is not None:
            return _structured_failure(safety, ValueError(err), cwd=cd)
    try:
        request = _build_request(
            {
                "prompt": PROMPT,
                "cwd": cd,
                "session_id": SESSION_ID,
                "model": model,
                "sandbox": sandbox,
                "return_all_messages": False,
                "mode": mode,
                "timeout": timeout,
                "detach": True,
                "allow_write": allow_write,
                "worktree": worktree,
                "backend": backend,
                "output_protocol": output_protocol,
                "debug": debug,
                "extra_env": extra_env or {},
            }
        )
    except Exception as exc:  # noqa: BLE001
        return _structured_failure(safety, exc, cwd=cd)
    if job_id is not None:
        err = _validate_job_id(safety, job_id)
        if err is not None:
            return _structured_failure(safety, ValueError(err), cwd=cd)
    try:
        response = supervisor.start(request, job_id=job_id)
    except Exception as exc:  # noqa: BLE001 - top-level guard
        return _structured_failure(safety, exc, cwd=cd)
    return response


# ---------------------------------------------------------------------------
# Tool: agy_status — poll a job's JobRecord
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_status",
    description="Return the JobRecord (status, exit code, error, timestamps) for a job_id.",
)
def agy_status_tool(job_id: str) -> StatusToolResponse:
    config, safety, _store_, supervisor = _ensure_state()
    err = _validate_job_id(safety, job_id)
    if err is not None:
        return _wrapper_failure(safety, ValueError(err), StatusToolResponse)
    try:
        record = supervisor.status(job_id)
    except Exception as exc:  # noqa: BLE001
        return _wrapper_failure(safety, exc, StatusToolResponse)
    if record is None:
        # Use the same envelope shape as other failures so consumers can
        # rely on ``success/error`` keys regardless of why the lookup
        # failed. (Phase 5 R1 arch P1.3)
        return _wrapper_failure(
            safety,
            ValueError(f"job_id {job_id!r} not found"),
            StatusToolResponse,
        )
    return StatusToolResponse(success=True, record=record)


# ---------------------------------------------------------------------------
# Tool: agy_read — read events from a job
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_read",
    description=(
        "Read events from a job's event log. ``since`` is the 0-based offset; "
        "``translate`` may be 'raw', 'claude', or 'codex' to wire-format the "
        "events (default returns canonical events as dicts)."
    ),
)
def agy_read_tool(
    job_id: str,
    since: int = 0,
    translate: OutputProtocol | None = None,
) -> ReadToolResponse:
    config, safety, _store_, supervisor = _ensure_state()
    err = _validate_job_id(safety, job_id)
    if err is not None:
        return _wrapper_failure(
            safety, ValueError(err), ReadToolResponse,
        )
    if since < 0:
        return _wrapper_failure(
            safety,
            ValueError("since must be a non-negative integer"),
            ReadToolResponse,
            job_id=job_id,
            since=since,
        )
    try:
        record = supervisor.status(job_id)
    except Exception as exc:  # noqa: BLE001
        return _wrapper_failure(safety, exc, ReadToolResponse, job_id=job_id)
    if record is None:
        return _wrapper_failure(
            safety,
            ValueError(f"job_id {job_id!r} not found"),
            ReadToolResponse,
            job_id=job_id,
        )
    try:
        if translate is None:
            events = supervisor.read_events(job_id, since=since)
            payload: list[dict[str, Any]] = [
                e.model_dump(mode="json") for e in events
            ]
        else:
            payload = supervisor.read_translated(
                job_id, since=since, protocol=translate,
            )
    except Exception as exc:  # noqa: BLE001
        return _wrapper_failure(
            safety, exc, ReadToolResponse, job_id=job_id, since=since,
        )
    return ReadToolResponse(
        success=True,
        job_id=job_id,
        since=since,
        translate=translate,
        events=payload,
        count=len(payload),
    )


# ---------------------------------------------------------------------------
# Tool: agy_cancel — signal a running job
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_cancel",
    description=(
        "Signal a running job to stop. Returns ``success=True, signalled=True`` "
        "if the worker was alive, ``signalled=False`` if it was unknown / "
        "already finished."
    ),
)
def agy_cancel_tool(job_id: str) -> CancelToolResponse:
    config, safety, _store_, supervisor = _ensure_state()
    err = _validate_job_id(safety, job_id)
    if err is not None:
        return _wrapper_failure(
            safety, ValueError(err), CancelToolResponse,
        )
    try:
        signalled = supervisor.cancel(job_id)
    except Exception as exc:  # noqa: BLE001
        return _wrapper_failure(
            safety, exc, CancelToolResponse, job_id=job_id,
        )
    return CancelToolResponse(
        success=True,
        job_id=safety.redact(job_id),
        signalled=signalled,
    )


# ---------------------------------------------------------------------------
# Tool: agy_sessions — list recent jobs
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_sessions",
    description=(
        "List recent jobs, newest first. ``limit`` defaults to 50; pass 0 "
        "for the full list."
    ),
)
def agy_sessions_tool(limit: int = 50) -> SessionsToolResponse:
    config, safety, _store_, supervisor = _ensure_state()
    if limit < 0:
        return _wrapper_failure(
            safety,
            ValueError("limit must be a non-negative integer"),
            SessionsToolResponse,
        )
    effective: int | None = limit if limit > 0 else None
    try:
        records = supervisor.list_sessions(limit=effective)
    except Exception as exc:  # noqa: BLE001
        return _wrapper_failure(safety, exc, SessionsToolResponse)
    return SessionsToolResponse(
        success=True,
        count=len(records),
        records=list(records),
    )


# ---------------------------------------------------------------------------
# Tool: agy_doctor — environment probe
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_doctor",
    description=(
        "Run capability + auth + session-store probes. Returns a structured "
        "report (no secrets) suitable for surfacing to a user via MCP. "
        "Pass ``force_refresh=true`` to drop the cached binary probe (use "
        "after upgrading the underlying agy / gemini CLI without restarting "
        "the MCP server)."
    ),
)
def agy_doctor_tool(force_refresh: bool = False) -> DoctorToolResponse:
    config, safety, store, _supervisor_ = _ensure_state()
    try:
        agy_adapter, gemini_adapter = _ensure_adapters(force_refresh=force_refresh)
    except Exception as exc:  # noqa: BLE001 - never let init crash the tool
        return _wrapper_failure(safety, exc, DoctorToolResponse, version=__version__)
    try:
        report = run_doctor(
            config=config,
            safety=safety,
            agy_adapter=agy_adapter,
            gemini_adapter=gemini_adapter,
            session_store=store,
        )
    except Exception as exc:  # noqa: BLE001
        return _wrapper_failure(safety, exc, DoctorToolResponse, version=__version__)
    return DoctorToolResponse(
        success=True,
        report=report.to_dict(),
        version=__version__,
    )


# ---------------------------------------------------------------------------
# Tool: agy_install_skill — write scaffold skill into target dirs
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_install_skill",
    description=(
        "Install the agy-mcp collaboration skill bundle into one or more "
        "agent platforms. ``targets`` may include 'claude', 'codex', "
        "'antigravity', or 'all' (default expands to all three). User "
        "scope writes to ``~/.claude/skills/``, ``~/.agents/skills/``, "
        "and ``~/.agy/skills/`` respectively; project scope writes to "
        "``.claude/skills/``, ``.agents/skills/``, and "
        "``.antigravity/skills/`` under the supplied ``project_root``. "
        "Antigravity's wrapper-owned ``~/.agy/`` is used in user scope "
        "because the standing rule 'do not write under ~/.gemini/' rules "
        "out the Antigravity CLI's own state directory. ``force=False`` "
        "(the default) skips files whose on-disk body already matches; "
        "``force=True`` rewrites every file unconditionally."
    ),
)
def agy_install_skill_tool(
    targets: list[str] | None = None,
    scope: SkillScope = "user",
    project_root: str | None = None,
    force: bool = False,
) -> InstallSkillToolResponse:
    config, safety, _store_, _supervisor_ = _ensure_state()
    if scope not in ("user", "project"):
        return _wrapper_failure(
            safety,
            ValueError(f"scope must be 'user' or 'project', got {scope!r}"),
            InstallSkillToolResponse,
        )
    chosen_targets = targets if targets else ["all"]
    # Defence-in-depth at the tool boundary. The installer's own
    # ``_expand_targets`` does the same string / allow-list check
    # again, but the MCP entry point gets reachable from arbitrary
    # caller configs, so we re-validate here AND apply
    # ``_MAX_INSTALL_TARGETS`` (which ``_expand_targets`` does not
    # know about). Phase 7 R1 arch P2-2: keep both layers but flag
    # the duplication so future contributors don't relax one and
    # leave the other exposed.
    if not isinstance(chosen_targets, list):
        return _wrapper_failure(
            safety,
            ValueError("targets must be a list of strings"),
            InstallSkillToolResponse,
        )
    if len(chosen_targets) > _MAX_INSTALL_TARGETS:
        return _wrapper_failure(
            safety,
            ValueError(
                f"targets exceeds {_MAX_INSTALL_TARGETS} entries "
                f"({len(chosen_targets)} given)",
            ),
            InstallSkillToolResponse,
        )
    cleaned: list[SkillTarget] = []
    for t in chosen_targets:
        if not isinstance(t, str):
            return _wrapper_failure(
                safety,
                ValueError("targets entries must be strings"),
                InstallSkillToolResponse,
            )
        if t not in _ALLOWED_TARGETS:
            return _wrapper_failure(
                safety,
                ValueError(f"unknown skill target: {t!r}"),
                InstallSkillToolResponse,
            )
        cleaned.append(t)  # type: ignore[arg-type]
    try:
        result = install_skills(
            targets=cleaned,
            scope=scope,
            project_root=Path(project_root) if project_root else None,
            safety=safety,
            force=force,
        )
    except Exception as exc:  # noqa: BLE001
        return _wrapper_failure(safety, exc, InstallSkillToolResponse)
    payload = result.to_dict()
    return InstallSkillToolResponse(
        success=bool(payload.get("success", False)),
        error=payload.get("error"),
        warnings=list(payload.get("warnings", [])),
        installed=list(payload.get("installed", [])),
    )


# ---------------------------------------------------------------------------
# Tool: agy_purge — drop session-store rows older than ``days``
# ---------------------------------------------------------------------------


@mcp.tool(
    name="agy_purge",
    description=(
        "Delete session-store job directories whose mtime is older than "
        "``days``. Returns the removed job ids and a coarse count of "
        "remaining jobs. ``days`` must be a positive integer <= "
        f"{_PURGE_MAX_DAYS}; zero or negative values are rejected to "
        "avoid an accidental wipe via off-by-one config."
    ),
)
def agy_purge_tool(days: int = 30) -> PurgeToolResponse:
    config, safety, store, _supervisor_ = _ensure_state()
    if not isinstance(days, int) or isinstance(days, bool):
        return _wrapper_failure(
            safety,
            ValueError("days must be a positive integer"),
            PurgeToolResponse,
        )
    if days <= 0:
        return _wrapper_failure(
            safety,
            ValueError("days must be > 0 (refusing to wipe the entire store)"),
            PurgeToolResponse,
            days=days,
        )
    if days > _PURGE_MAX_DAYS:
        return _wrapper_failure(
            safety,
            ValueError(
                f"days exceeds the {_PURGE_MAX_DAYS}-day cap; pick a smaller cutoff"
            ),
            PurgeToolResponse,
            days=days,
        )
    try:
        removed = store.purge_older_than(days)
        remaining_records = store.list_jobs(limit=None)
    except Exception as exc:  # noqa: BLE001 - top-level guard
        return _wrapper_failure(
            safety, exc, PurgeToolResponse, days=days,
        )
    return PurgeToolResponse(
        success=True,
        days=days,
        removed=[safety.redact(job_id) for job_id in removed],
        removed_count=len(removed),
        remaining=len(remaining_records),
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run() -> None:
    """Start the FastMCP stdio server."""

    # Materialise singletons before stdio takes over so any configuration
    # error surfaces with a stack trace rather than a closed pipe.
    _ensure_state()
    mcp.run(transport="stdio")


__all__ = [
    "agy_cancel_tool",
    "agy_continue_tool",
    "agy_doctor_tool",
    "agy_install_skill_tool",
    "agy_purge_tool",
    "agy_read_tool",
    "agy_sessions_tool",
    "agy_start_tool",
    "agy_status_tool",
    "agy_tool",
    "mcp",
    "run",
]
