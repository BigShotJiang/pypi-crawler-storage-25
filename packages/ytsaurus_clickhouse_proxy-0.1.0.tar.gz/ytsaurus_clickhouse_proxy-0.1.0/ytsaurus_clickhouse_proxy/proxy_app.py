# Python 3.9+
import os
import re
import json
import datetime
from typing import Dict, Optional, Tuple, List, Any
from pathlib import Path

import httpx
from fastapi import FastAPI, Request, Response

from .logical_catalog import LOGICAL_CATALOG

app = FastAPI(title="YT ↔ ClickHouse JDBC Proxy")

# =================== Config ===================
YT_TOKEN_PATH = os.environ.get("YT_TOKEN_PATH", "~/.yt/token")
YT_TOKEN = Path(YT_TOKEN_PATH).expanduser().read_text().strip()
YT_PROXY = os.environ.get("YT_PROXY", "")
if not YT_PROXY:
    raise RuntimeError("YT_PROXY environment variable is required (e.g. http://your-yt-cluster.example.com)")
CLIQUE_ALIAS = os.environ.get("CLIQUE_ALIAS", "ch_public")
DEFAULT_FORMAT = os.environ.get("DEFAULT_FORMAT", "RowBinaryWithNamesAndTypes")
MAX_TABLES_IN_COLUMNS_UNION = int(os.environ.get("MAX_TABLES_IN_COLUMNS_UNION", "100"))

# =================== Regexes ===================
SYSTEM_TABLE_ENGINES_RE = re.compile(r"\bSELECT\s+name\s+FROM\s+system\.table_engines\b", re.I)
SYSTEM_DATABASES_ANY_RE = re.compile(r"\bFROM\s+system\.databases\b", re.I)
SYSTEM_TABLES_ANY_RE    = re.compile(r"\bFROM\s+system\.tables\b", re.I)
SYSTEM_COLUMNS_ANY_RE   = re.compile(r"\bFROM\s+system\.columns\b", re.I)
DESCRIBE_TBL_RE = re.compile(
    r"^\s*(DESCRIBE|DESC)\s+(TABLE\s+)?([`\"]?)([\w\-]+)\3\.([`\"]?)([\w\-]+)\5\s*;?\s*$",
    re.I
)
CURRENT_DATABASE_FUNC_RE = re.compile(r"\bcurrentDatabase\(\)", re.I)

# =================== Helpers ===================
def _norm_ident(x: str) -> str:
    return x.strip().strip("`'\"").lower()

def _split_schema_qual(value: str) -> Tuple[Optional[str], str]:
    v = _norm_ident(value)
    if "." in v:
        parts = [p for p in v.split(".") if p]
        return (".".join(parts[:-1]) or None, parts[-1])
    return (None, v)

def _extract_db_filter(sql: str) -> Optional[str]:
    m = re.search(r"\bWHERE\b.*?\bdatabase\s*=\s*'([^']+)'", sql, re.I | re.S)
    return _norm_ident(m.group(1)) if m else None

def _extract_db_table_filter(sql: str) -> Optional[Tuple[str, str]]:
    m = re.search(r"\bWHERE\b.*?\bdatabase\s*=\s*'([^']+)'.*?\btable\s*=\s*'([^']+)'", sql, re.I | re.S)
    if m:
        return _norm_ident(m.group(1)), _norm_ident(m.group(2))
    m = re.search(r"\bWHERE\b.*?\btable\s*=\s*'([^']+)'.*?\bdatabase\s*=\s*'([^']+)'", sql, re.I | re.S)
    if m:
        return _norm_ident(m.group(2)), _norm_ident(m.group(1))
    return None

def _extract_table_only_filter(sql: str) -> Optional[str]:
    m = re.search(r"\btable\s*=\s*(['\"`])([^'\"`]+)\1", sql, re.I)
    if m:
        _, tbl = _split_schema_qual(m.group(2))
        return tbl
    m = re.search(r"\btable\s+IN\s*\(\s*(['\"`])([^'\"`]+)\1", sql, re.I)
    if m:
        _, tbl = _split_schema_qual(m.group(2))
        return tbl
    return None

def _extract_table_name_filter(sql: str) -> Optional[str]:
    m = re.search(r"\bTABLE_NAME\s*=\s*(['\"`])([^'\"`]+)\1", sql, re.I)
    if m:
        _, tbl = _split_schema_qual(m.group(2))
        return tbl
    m = re.search(r"\bTABLE_NAME\s+IN\s*\(\s*(['\"`])([^'\"`]+)\1", sql, re.I)
    if m:
        _, tbl = _split_schema_qual(m.group(2))
        return tbl
    return None

def _extract_db_filter_loose(sql: str) -> Optional[str]:
    for key in ("database", "TABLE_SCHEM", "TABLE_SCHEMA"):
        m = re.search(rf"\b{key}\s*=\s*(['\"`])([^'\"`]+)\1", sql, re.I)
        if m:
            return _norm_ident(m.group(2))
    return None

def _union_databases() -> str:
    names = list(LOGICAL_CATALOG.keys())
    if not names:
        return "SELECT CAST(NULL AS Nullable(String)) AS name WHERE 0"
    parts = [f"SELECT '{names[0]}' AS name"] + [f"SELECT '{n}'" for n in names[1:]]
    return " UNION ALL ".join(parts)

def _union_tables_for_db(db: str) -> str:
    rows: List[str] = []
    for t, meta in LOGICAL_CATALOG.get(db, {}).items():
        rows.append(
            "SELECT "
            f"  '{db}' AS database, "
            f"  '{t}'  AS name, "
            "  'YTLogical' AS engine, "
            "  0 AS is_temporary, "
            "  CAST(NULL AS Nullable(String)) AS comment"
        )
    if not rows:
        return (
            "SELECT "
            "CAST(NULL AS Nullable(String)) AS database, "
            "CAST(NULL AS Nullable(String)) AS name, "
            "CAST(NULL AS Nullable(String)) AS engine, "
            "CAST(0    AS UInt8)            AS is_temporary, "
            "CAST(NULL AS Nullable(String)) AS comment "
            "WHERE 0"
        )
    return " UNION ALL ".join(rows)

def _jdbc_type_code(ch_type: str) -> int:
    t = ch_type.lower()
    if t.startswith("nullable("):
        t = t[9:-1]
    if t.startswith("lowcardinality("):
        t = t[15:-1]
    if t.startswith("decimal"):
        return 3        # DECIMAL/NUMERIC
    if t in ("string", "fixedstring"):
        return 12       # VARCHAR
    if t in ("int8", "int16", "int32"):
        return 4        # INTEGER
    if t in ("uint8", "uint16", "uint32"):
        return 4
    if t in ("int64", "uint64", "int128", "uint128", "int256", "uint256"):
        return -5       # BIGINT
    if t in ("float32",):
        return 7        # REAL
    if t in ("float64",):
        return 8        # DOUBLE
    if t in ("date", "date32"):
        return 91       # DATE
    if t.startswith("datetime"):
        return 93       # TIMESTAMP
    if t == "uuid":
        return 12       # VARCHAR
    if t.startswith("array(") or t.startswith("tuple(") or t.startswith("map("):
        return 2003     # ARRAY
    return 1111         # OTHER

def rewrite_from_aliases(sql: str) -> str:
    rewritten = sql
    for db, tables in LOGICAL_CATALOG.items():
        for tbl, meta in tables.items():
            patt = (
                r"(?P<prefix>\bFROM\s+|JOIN\s+|INTO\s+|UPDATE\s+)"
                r"(?:`{db}`\.`{tbl}`|`{db}`\.{tbl}|{db}\.`{tbl}`|{db}\.{tbl})\b"
            ).format(db=re.escape(db), tbl=re.escape(tbl))
            if meta["type"] == "table":
                repl = r"\g<prefix>`{}`".format(meta["path"])
            else:
                repl = r"\g<prefix>concatYtTablesRange('{}')".format(meta["base"])
            rewritten = re.sub(patt, repl, rewritten, flags=re.IGNORECASE)
    return rewritten

async def chyt_binary_response(sql: str) -> Response:
    async with httpx.AsyncClient(timeout=1800.0, follow_redirects=True) as client:
        upstream = await client.post(
            f"{YT_PROXY}/chyt",
            params={"chyt.clique_alias": CLIQUE_ALIAS},
            headers={
                "Authorization": f"OAuth {YT_TOKEN}",
                "Content-Type": "text/plain",
                "Accept": "*/*",
            },
            content=sql.encode("utf-8"),
        )
    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        media_type=upstream.headers.get("Content-Type", "application/octet-stream"),
        headers={k: v for k, v in upstream.headers.items() if k.lower() != "content-encoding"},
    )

async def fetch_schema_from_chyt(yt_path: str) -> List[Dict[str, Any]]:
    sql = f"SELECT * FROM `{yt_path}` LIMIT 0 FORMAT JSON"
    async with httpx.AsyncClient(timeout=60.0, follow_redirects=True) as client:
        r = await client.post(
            f"{YT_PROXY}/chyt",
            params={"chyt.clique_alias": CLIQUE_ALIAS},
            headers={
                "Authorization": f"OAuth {YT_TOKEN}",
                "Content-Type": "text/plain",
                "Accept": "application/json",
            },
            content=sql.encode("utf-8"),
        )
        r.raise_for_status()
        payload = r.json()
        return payload.get("meta", [])

# =================== Main handler ===================
@app.api_route("/{path:path}", methods=["POST", "GET"])
async def chyt_proxy(path: str, request: Request):
    params: Dict[str, str] = dict(request.query_params)
    body_bytes = await request.body()

    try:
        query = body_bytes.decode("utf-8").strip()
    except Exception:
        query = ""
    if not query:
        query = params.get("query", "")

    # DBeaver sends compress=1 — drop it to avoid LZ4 surprises
    params.pop("compress", None)

    print("\n" + "=" * 80)
    print(f"[{datetime.datetime.now()}] POST {path or '/'}")
    print("QUERY >>>", query or "(empty)")
    print("=" * 80 + "\n")

    if not query:
        return Response(content=b"", media_type="application/octet-stream")

    # currentDatabase() → first schema from catalog
    default_db = list(LOGICAL_CATALOG.keys())[0] if LOGICAL_CATALOG else "default"
    query = CURRENT_DATABASE_FUNC_RE.sub(f"'{default_db}'", query)

    # --- system.table_engines ---
    if SYSTEM_TABLE_ENGINES_RE.search(query):
        synthetic_sql = (
            "SELECT 'YtTable' AS name "
            "UNION ALL SELECT 'Memory' "
            "UNION ALL SELECT 'View' "
            f"FORMAT {DEFAULT_FORMAT}"
        )
        return await chyt_binary_response(synthetic_sql)

    # --- DESCRIBE chyt.tbl ---
    m = DESCRIBE_TBL_RE.match(query)
    if m:
        db = _norm_ident(m.group(4)); tbl = _norm_ident(m.group(6))
        meta = LOGICAL_CATALOG.get(db, {}).get(tbl)
        if meta:
            yt_path = meta["path"] if meta["type"] == "table" else f'{meta["base"]}/{meta["sample"]}'
            query = f'DESCRIBE TABLE `{yt_path}`'

    # --- system.databases ---
    elif SYSTEM_DATABASES_ANY_RE.search(query):
        msel = re.search(r"^\s*SELECT\s+(.*?)\s+FROM", query, re.I | re.S)
        select_cols = msel.group(1) if msel else "name"
        tail = ""
        m_tail = re.search(r"\b(WHERE|ORDER\s+BY|LIMIT)\b.*$", query, re.I | re.S)
        if m_tail:
            tail = " " + m_tail.group(0)
        synthetic = _union_databases()
        query = f"SELECT {select_cols} FROM ({synthetic}) AS dbs{tail} FORMAT {DEFAULT_FORMAT}"

    # --- system.tables ---
    elif SYSTEM_TABLES_ANY_RE.search(query):
        target_db = _extract_db_filter(query) or default_db
        synthetic_core = _union_tables_for_db(target_db)

        msel = re.search(r"^\s*SELECT\s+(.*?)\s+FROM", query, re.I | re.S)
        select_cols = msel.group(1) if msel else "*"

        tail = ""
        m_tail = re.search(r"\b(WHERE|HAVING|ORDER\s+BY|LIMIT)\b.*$", query, re.I | re.S)
        if m_tail:
            tail = " " + m_tail.group(0)

        query = (
            f"SELECT {select_cols} "
            f"FROM ({synthetic_core}) AS system_tables"
            f"{tail} FORMAT {DEFAULT_FORMAT}"
        )

    # --- system.columns ---
    elif SYSTEM_COLUMNS_ANY_RE.search(query):
        tail = ""
        m_tail = re.search(r"\b(WHERE|HAVING|ORDER\s+BY|LIMIT)\b.*$", query, re.I | re.S)
        if m_tail:
            tail = " " + m_tail.group(0)

        which       = _extract_db_table_filter(query)
        tbl_only    = _extract_table_only_filter(query)
        tbl_jdbc    = _extract_table_name_filter(query)
        db_loose    = _extract_db_filter_loose(query)

        tasks: List[Tuple[str, str, str]] = []  # (db, tbl, yt_path)

        if which:
            db, tbl = _norm_ident(which[0]), _norm_ident(which[1])
            meta = LOGICAL_CATALOG.get(db, {}).get(tbl)
            if meta:
                yt_path = meta["path"] if meta["type"] == "table" else f"{meta['base']}/{meta['sample']}"
                tasks.append((db, tbl, yt_path))

        elif tbl_only or tbl_jdbc:
            tname = _norm_ident(tbl_only or tbl_jdbc)
            cand_db = db_loose or default_db
            _, t_only = _split_schema_qual(tname)
            meta = LOGICAL_CATALOG.get(cand_db, {}).get(t_only)
            if not meta:
                for dbk, tabs in LOGICAL_CATALOG.items():
                    if t_only in tabs:
                        cand_db = dbk
                        meta = tabs[t_only]
                        break
            if meta:
                yt_path = meta["path"] if meta["type"] == "table" else f"{meta['base']}/{meta['sample']}"
                tasks.append((cand_db, t_only, yt_path))

        elif db_loose:
            db = _norm_ident(db_loose)
            tables = list(LOGICAL_CATALOG.get(db, {}).items())[:MAX_TABLES_IN_COLUMNS_UNION]
            for tbl, meta in tables:
                yt_path = meta["path"] if meta["type"] == "table" else f"{meta['base']}/{meta['sample']}"
                tasks.append((db, tbl, yt_path))
        else:
            if LOGICAL_CATALOG.get(default_db):
                first_tbl, meta = next(iter(LOGICAL_CATALOG[default_db].items()))
                yt_path = meta["path"] if meta["type"] == "table" else f"{meta['base']}/{meta['sample']}"
                tasks.append((default_db, first_tbl, yt_path))

        if len(tasks) > MAX_TABLES_IN_COLUMNS_UNION:
            tasks = tasks[:MAX_TABLES_IN_COLUMNS_UNION]

        if not tasks:
            empty = (
                "SELECT "
                "CAST(NULL AS Nullable(String)) AS database, "
                "CAST(NULL AS Nullable(String)) AS table, "
                "CAST(NULL AS Nullable(String)) AS name, "
                "CAST(NULL AS Nullable(String)) AS type, "
                "CAST(0    AS UInt32)          AS position, "
                "CAST(NULL AS Nullable(String)) AS default_kind, "
                "CAST(NULL AS Nullable(String)) AS default_expression, "
                "CAST(NULL AS Nullable(String)) AS comment, "
                "CAST(NULL AS Nullable(String)) AS codec_expression, "
                "CAST(NULL AS Nullable(String)) AS ttl_expression, "
                "CAST(NULL AS Nullable(String)) AS TABLE_SCHEM, "
                "CAST(NULL AS Nullable(String)) AS TABLE_NAME, "
                "CAST(NULL AS Nullable(String)) AS COLUMN_NAME, "
                "CAST(NULL AS Nullable(Int32))  AS DATA_TYPE, "
                "CAST(NULL AS Nullable(String)) AS TYPE_NAME, "
                "CAST(NULL AS Nullable(Int32))  AS COLUMN_SIZE, "
                "CAST(NULL AS Nullable(Int32))  AS DECIMAL_DIGITS, "
                "CAST(NULL AS Nullable(Int32))  AS NUM_PREC_RADIX, "
                "CAST(0    AS UInt32)           AS ORDINAL_POSITION, "
                "CAST(NULL AS Nullable(String)) AS IS_NULLABLE "
                "WHERE 0 "
                f"FORMAT {DEFAULT_FORMAT}"
            )
            return await chyt_binary_response(empty)

        parts_sql: List[str] = []
        for db, tbl, yt_path in tasks:
            meta_cols = await fetch_schema_from_chyt(yt_path)
            if not meta_cols:
                parts_sql.append(
                    "SELECT "
                    f"'{db}' AS database, '{tbl}' AS table, "
                    "CAST(NULL AS Nullable(String)) AS name, "
                    "CAST(NULL AS Nullable(String)) AS type, "
                    "CAST(0 AS UInt32) AS position, "
                    "CAST(NULL AS Nullable(String)) AS default_kind, "
                    "CAST(NULL AS Nullable(String)) AS default_expression, "
                    "CAST(NULL AS Nullable(String)) AS comment, "
                    "CAST(NULL AS Nullable(String)) AS codec_expression, "
                    "CAST(NULL AS Nullable(String)) AS ttl_expression, "
                    f"'{db}' AS TABLE_SCHEM, "
                    f"'{tbl}' AS TABLE_NAME, "
                    "CAST(NULL AS Nullable(String)) AS COLUMN_NAME, "
                    "CAST(NULL AS Nullable(Int32))  AS DATA_TYPE, "
                    "CAST(NULL AS Nullable(String)) AS TYPE_NAME, "
                    "CAST(NULL AS Nullable(Int32))  AS COLUMN_SIZE, "
                    "CAST(NULL AS Nullable(Int32))  AS DECIMAL_DIGITS, "
                    "CAST(NULL AS Nullable(Int32))  AS NUM_PREC_RADIX, "
                    "CAST(0 AS UInt32)              AS ORDINAL_POSITION, "
                    "CAST(NULL AS Nullable(String)) AS IS_NULLABLE "
                    "WHERE 0"
                )
                continue

            rows: List[str] = []
            for i, col in enumerate(meta_cols, 1):
                name = col.get("name", "")
                ctype = col.get("type", "")
                jdbc_code = _jdbc_type_code(ctype)
                is_nullable = "YES" if ctype.lower().startswith("nullable(") else "NO"
                rows.append(
                    "SELECT "
                    f"'{db}' AS database, "
                    f"'{tbl}' AS table, "
                    f"'{name}' AS name, "
                    f"'{ctype}' AS type, "
                    f"{i} AS position, "
                    "CAST(NULL AS Nullable(String)) AS default_kind, "
                    "CAST(NULL AS Nullable(String)) AS default_expression, "
                    "CAST(NULL AS Nullable(String)) AS comment, "
                    "CAST(NULL AS Nullable(String)) AS codec_expression, "
                    "CAST(NULL AS Nullable(String)) AS ttl_expression, "
                    f"'{db}'   AS TABLE_SCHEM, "
                    f"'{tbl}'  AS TABLE_NAME, "
                    f"'{name}' AS COLUMN_NAME, "
                    f"{jdbc_code} AS DATA_TYPE, "
                    f"'{ctype}'  AS TYPE_NAME, "
                    "CAST(NULL AS Nullable(Int32))  AS COLUMN_SIZE, "
                    "CAST(NULL AS Nullable(Int32))  AS DECIMAL_DIGITS, "
                    "CAST(10   AS Nullable(Int32))  AS NUM_PREC_RADIX, "
                    f"{i} AS ORDINAL_POSITION, "
                    f"'{is_nullable}' AS IS_NULLABLE"
                )
            parts_sql.append(" UNION ALL ".join(rows))

        core = " UNION ALL ".join(f"({p})" for p in parts_sql)
        query = f"SELECT * FROM ({core}) AS system_columns{tail} FORMAT {DEFAULT_FORMAT}"

    # --- Pass-through: rewrite aliases and ensure FORMAT ---
    query = rewrite_from_aliases(query)
    if re.search(r"\bFORMAT\s+\w+", query, re.I) is None:
        query = f"{query.rstrip(';')} FORMAT {DEFAULT_FORMAT}"

    async with httpx.AsyncClient(timeout=1800.0, follow_redirects=True) as client:
        upstream = await client.post(
            f"{YT_PROXY}/chyt",
            params={"chyt.clique_alias": CLIQUE_ALIAS},
            headers={
                "Authorization": f"OAuth {YT_TOKEN}",
                "Content-Type": "text/plain",
                "Accept": "*/*",
            },
            content=query.encode("utf-8"),
        )

    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        media_type=upstream.headers.get("Content-Type", "application/octet-stream"),
        headers={k: v for k, v in upstream.headers.items() if k.lower() != "content-encoding"},
    )
