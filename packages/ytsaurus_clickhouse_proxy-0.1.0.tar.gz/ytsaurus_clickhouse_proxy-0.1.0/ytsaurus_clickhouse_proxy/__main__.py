import uvicorn


def main():
    uvicorn.run("ytsaurus_clickhouse_proxy:app", host="0.0.0.0", port=8123, log_level="info")


if __name__ == "__main__":
    main()
