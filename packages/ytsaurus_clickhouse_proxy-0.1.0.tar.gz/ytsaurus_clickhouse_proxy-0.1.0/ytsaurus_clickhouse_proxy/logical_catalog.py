from typing import Dict, Any

# ---------------------------------------------------------------------------
# LOGICAL CATALOG — define which YTsaurus tables are visible in your IDE
#
# Top-level keys  → schema/database names shown in DBeaver / DataGrip
# Second-level keys → table aliases (what you type in SQL)
#
# Two entry types:
#   type: "table"  — a single YT table; set "path" to the full YT path
#   type: "range"  — a directory of date-partitioned tables;
#                    set "base" (directory) and "sample" (one partition date)
#                    used by DESCRIBE / schema introspection
# ---------------------------------------------------------------------------

LOGICAL_CATALOG: Dict[str, Dict[str, Dict[str, Any]]] = {
    # ── Schema "analytics" ──────────────────────────────────────────────────
    "analytics": {
        # Single static table
        "orders": {
            "type": "table",
            "path": "//home/my_project/prod/orders",
        },
        "users": {
            "type": "table",
            "path": "//home/my_project/prod/users",
        },

        # Date-partitioned directory  → concatYtTablesRange(base, ...)
        "events_1d": {
            "type": "range",
            "base": "//home/my_project/logs/events/1d",
            "sample": "2024-01-01",   # used for schema inference (DESCRIBE)
        },
        "sessions_1d": {
            "type": "range",
            "base": "//home/my_project/logs/sessions/1d",
            "sample": "2024-01-01",
        },
    },

    # ── Schema "dicts" ──────────────────────────────────────────────────────
    "dicts": {
        "dict_regions": {
            "type": "range",
            "base": "//home/my_project/dicts/regions",
            "sample": "2024-01-01",
        },
        "dict_products": {
            "type": "range",
            "base": "//home/my_project/dicts/products",
            "sample": "2024-01-01",
        },
    },
}
