"""未读监听公开封装。"""

try:
    from ._unread_monitor import UnreadMessageMonitor
except ModuleNotFoundError:
    from build_src._unread_monitor import UnreadMessageMonitor

__all__ = ["UnreadMessageMonitor"]
