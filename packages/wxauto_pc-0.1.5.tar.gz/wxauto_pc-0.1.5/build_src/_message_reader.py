"""消息读取器。"""

from __future__ import annotations

from typing import Dict, List, Optional

from wxauto_pc.core.client import WeChatClient


class MessageReader:
    """微信消息读取器。"""

    def __init__(self, client: Optional[WeChatClient] = None):
        self.client = client or WeChatClient()

    def read_latest_from_chat(self, chat_name: str, count: int | None = None) -> List[Dict[str, object]]:
        if not self.client.switch_to_chat(chat_name):
            raise ValueError(f"未找到聊天: {chat_name}")

        # 判断聊天类型
        chat_type = self.client._detect_chat_type()
        is_group = chat_type == "group"
        messages = self.client.get_latest_messages(None)
        if is_group:
            messages = self._mark_my_messages(messages, chat_name, is_group)
        else:
            messages = self._format_private_messages(messages, chat_name, is_group)
        return messages[-count:] if count else messages

    def _mark_my_messages(self, messages: List[Dict[str, object]], chat_name: str, is_group: bool = False) -> List[Dict[str, object]]:
        formatted = []
        current_time = ""

        # 调用封装好的方法获取消息内容到发送人信息的映射
        content_to_sender = self.client.get_group_senders_info(messages)

        for msg in messages:
            if msg.get("is_time", False):
                current_time = msg["content"]
                continue

            content = msg["content"]
            raw_content = msg.get("raw_content", content)
            is_mine = self.client.message_cache.is_sent_by_me(content, chat_name)

            if is_mine:
                sender = "我"
                sender_id = ""
                sender_info = None
            else:
                # 根据消息内容查找发送人信息
                sender_info = content_to_sender.get(raw_content)
                if sender_info:
                    sender = sender_info.get("nickname", "群成员")
                    sender_id = sender_info.get("wechat_id", "")
                else:
                    sender = "群成员"
                    sender_id = ""

            formatted.append(
                {
                    "sender": sender,
                    "senderId": sender_id,
                    "content": content,
                    "time": current_time,
                    "formatted_content": f"[{current_time}][{sender}] {content}",
                    "raw_content": raw_content,
                    "is_group": is_group,
                    "chat_type": "group",
                    "sender_info": sender_info,
                }
            )
        return formatted

    def _format_private_messages(self, messages: List[Dict[str, object]], chat_name: str, is_group: bool = False) -> List[Dict[str, object]]:
        formatted = []
        current_time = ""

        # 获取对方的发送人信息（私聊只需要获取一次）
        sender_info = None
        try:
            info = self.client.get_sender_info(chat_name)
            if info and not info.get("error"):
                sender_info = info
        except Exception:
            pass

        for msg in messages:
            if msg.get("is_time", False):
                current_time = msg["content"]
                continue
            content = msg["content"]
            raw_content = msg.get("raw_content", content)
            is_mine = msg.get("is_mine", False)
            if msg.get("color_ambiguous", True):
                is_mine = self.client.message_cache.is_sent_by_me(content, chat_name)

            if is_mine:
                sender = "我"
                sender_id = ""
                formatted_content = f"[{current_time}][我] {content}"
            else:
                # 使用获取到的真实昵称和微信号
                if sender_info:
                    sender = sender_info.get("nickname", chat_name)
                    sender_id = sender_info.get("wechat_id", "")
                else:
                    sender = chat_name
                    sender_id = ""
                formatted_content = f"[{current_time}][{sender}] {content}"

            formatted.append(
                {
                    "sender": sender,
                    "senderId": sender_id,
                    "content": formatted_content,
                    "time": current_time,
                    "is_mine": is_mine,
                    "raw_content": raw_content,
                    "is_group": is_group,
                    "chat_type": "private",
                    "sender_info": sender_info if not is_mine else None,
                }
            )
        return formatted

    def is_group_chat(self, chat_name: str) -> bool:
        """判断指定聊天是否为群聊。

        Args:
            chat_name: 聊天名称

        Returns:
            True 表示群聊，False 表示私聊
        """
        if not self.client.switch_to_chat(chat_name):
            raise ValueError(f"未找到聊天: {chat_name}")
        chat_type = self.client._detect_chat_type()
        return chat_type == "group"

    def read_unread_messages_from_chat(self, chat_name: str, unread_count: int) -> List[Dict[str, object]]:
        """只读取指定聊天的未读消息（不读取历史消息）。

        Args:
            chat_name: 聊天名称
            unread_count: 未读消息数量

        Returns:
            未读消息列表，每条消息包含：
            - sender: 发送者昵称
            - content: 消息内容
            - timestamp: 时间戳
            - is_mine: 是否是我发送的
            - sender_info: 发送者详细信息（昵称、微信号）
        """
        from wxauto_pc.core.unread_monitor import UnreadMessageMonitor

        # 切换到该聊天
        if not self.client.switch_to_chat(chat_name):
            return []

        # 判断聊天类型
        chat_type = self.client._detect_chat_type()
        is_group = chat_type == "group"

        # 读取原始消息
        raw_messages = self.client.get_latest_messages(None)
        if not raw_messages:
            return []

        # 使用监听器识别未读消息
        monitor = UnreadMessageMonitor(client=self.client, reader=self, enable_log=False)
        if len(raw_messages) > unread_count:
            baseline_messages = raw_messages[:-unread_count]
            monitor._seed_seen(baseline_messages)
            unread_raw_messages = monitor._filter_new_messages(raw_messages)
        else:
            unread_raw_messages = raw_messages

        if not unread_raw_messages:
            return []

        # 只对未读消息获取发送者信息
        if is_group:
            content_to_sender = self.client.get_group_senders_info(unread_raw_messages)

        else:
            try:
                sender_info_result = self.client.get_sender_info(chat_name)
                content_to_sender = {}
                if sender_info_result and not sender_info_result.get("error"):
                    for msg in unread_raw_messages:
                        if not msg.get("is_mine", False):
                            content_to_sender[msg.get("raw_content", msg.get("content", ""))] = sender_info_result
            except Exception:
                content_to_sender = {}

        # 格式化未读消息
        unread_messages = []
        current_time = ""
        for msg in unread_raw_messages:
            if msg.get("is_time", False):
                current_time = msg["content"]
                continue

            content = msg["content"]
            raw_content = msg.get("raw_content", content)
            is_mine = msg.get("is_mine", False)

            if msg.get("color_ambiguous", True):
                is_mine = self.client.message_cache.is_sent_by_me(content, chat_name)

            if is_mine:
                sender = "我"
                sender_id = ""
                sender_info = None
            else:
                sender_info = content_to_sender.get(raw_content)
                if sender_info:
                    sender = sender_info.get("nickname", "未知")
                    sender_id = sender_info.get("wechat_id", "")
                else:
                    sender = "群成员" if is_group else chat_name

            unread_messages.append({
                "sender": sender,
                 "senderId": sender_id,
                "content": content,
                "timestamp": current_time,
                "is_mine": is_mine,
                "is_group": is_group,
                "chat_type": chat_type,
                "sender_info": sender_info,

            })

        return unread_messages

    def read_all_unread_messages(self, ignore_list: List[str] | None = None) -> List[Dict[str, object]]:
        """读取所有未读会话的未读消息。

        Args:
            ignore_list: 要忽略的会话名称列表

        Returns:
            所有未读消息列表，按会话分组，每个会话包含：
            - chat_name: 会话名称
            - chat_type: 会话类型（group/private）
            - unread_count: 未读数量
            - messages: 未读消息列表
        """
        # 默认忽略的系统账号
        default_ignore = {
            "服务号", "公众号", "腾讯新闻", "文件传输助手",
            "微信支付", "服务通知", "微信游戏","微信运动"
        }
        merged_ignore = set(default_ignore)
        if ignore_list:
            merged_ignore.update(ignore_list)

        # 获取未读会话列表
        unread_chats = self.client.get_unread_chats(ignore_list=list(merged_ignore))
        if not unread_chats:
            return []

        # 逐个读取未读消息
        all_unread_messages = []

        for chat in unread_chats:
            chat_name = chat['chat_name']
            unread_count = chat['unread']

            try:
                # 读取未读消息
                unread_messages = self.read_unread_messages_from_chat(chat_name, unread_count)

                if not unread_messages:
                    continue

                # 判断聊天类型
                chat_type = self.client._detect_chat_type()

                all_unread_messages.append({
                    "chat_name": chat_name,
                    "chat_type": "group" if chat_type == "group" else "private",
                    "unread_count": unread_count,
                    "messages": unread_messages,
                })

            except Exception:
                # 忽略单个会话的错误，继续处理下一个
                continue

        return all_unread_messages

